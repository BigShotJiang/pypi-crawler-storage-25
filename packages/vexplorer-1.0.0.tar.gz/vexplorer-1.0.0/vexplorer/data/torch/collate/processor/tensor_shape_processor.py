# -*- coding: utf-8 -*-
"""Spatial processors for batch collation: Pad, Crop, SmartResize, Interpolate.

Optimisations over the original implementation
----------------------------------------------
* **Template-method pattern** in ``BaseSpatialProcessor.__call__`` eliminates
  boilerplate duplicated across Pad / Crop / SmartResize.  Each subclass now
  only implements ``_process_single``.
* **Fast path**: when every tensor in the batch already has the target shape,
  ``torch.stack`` is called directly — no per-element loop.
* ``_resolve_target_shape`` uses an **index counter** instead of
  ``list.pop(0)`` (O(1) vs O(n)).
* ``InterpolateProcessor`` no longer inherits unused ``pad_value`` / ``align``
  parameters.
"""

import torch
import torch.nn.functional as F
import random
import logging
from typing import List, Union, Tuple, Set, Optional, Any

logger = logging.getLogger(__name__)

from ..base.base_processor import BaseProcessor


# ═══════════════════════════════════════════════════════════════════════════════
# Alignment helpers
# ═══════════════════════════════════════════════════════════════════════════════

class Align:
    """Alignment constants for padding and cropping."""
    START = 'start'
    END = 'end'
    CENTER = 'center'
    RANDOM = 'random'


def calc_pad_crop_params(
        current_size: int,
        target_size: int,
        align: str,
) -> Tuple[bool, Tuple[int, int]]:
    """Calculates start/end indices for cropping or left/right amounts for padding.

    Args:
        current_size: The size of the current dimension.
        target_size:  The desired target size.
        align:        Alignment strategy ('start', 'end', 'center', 'random').

    Returns:
        ``(is_pad, (a, b))`` where *is_pad* is ``True`` for padding (a=left,
        b=right) and ``False`` for cropping (a=start, b=end index).
    """
    diff = target_size - current_size

    if diff == 0:
        return True, (0, 0)

    if diff > 0:  # padding
        if align == Align.START:
            return True, (0, diff)
        if align == Align.END:
            return True, (diff, 0)
        if align == Align.CENTER:
            pad_l = diff // 2
            return True, (pad_l, diff - pad_l)
        if align == Align.RANDOM:
            pad_l = random.randint(0, diff)
            return True, (pad_l, diff - pad_l)
    else:  # cropping
        abs_diff = -diff
        if align == Align.START:
            return False, (0, target_size)
        if align == Align.END:
            return False, (abs_diff, current_size)
        if align == Align.CENTER:
            start = abs_diff // 2
            return False, (start, start + target_size)
        if align == Align.RANDOM:
            start = random.randint(0, abs_diff)
            return False, (start, start + target_size)

    return True, (0, diff)  # fallback (unreachable)


# ═══════════════════════════════════════════════════════════════════════════════
# Base spatial processor  (template-method pattern)
# ═══════════════════════════════════════════════════════════════════════════════

class BaseSpatialProcessor(BaseProcessor):
    """Base class for spatial transformations (Pad, Crop, SmartResize).

    Provides a **template ``__call__``** that handles:

    1. Empty-batch guard.
    2. ``should_mask`` resolution.
    3. Batch statistics (``max_shape`` / ``min_shape``).
    4. **Fast path** — when all tensors already match the resolved target shape,
       ``torch.stack`` is called directly with zero per-element overhead.
    5. Per-element loop delegating to ``_process_single``.
    6. Final ``torch.stack`` and optional mask assembly.

    Subclasses only need to override :meth:`_process_single`.

    Args:
        target_size: ``'max'``, ``'min'``, or a fixed ``Tuple[int, ...]``.
        pad_value:   Fill value for padding (default 0.0).
        align:       Single string or per-dim list of alignment strategies.
        ignore_dims: Dimension indices to leave untouched.
        return_mask: Whether to produce a validity mask.
    """

    def __init__(
        self,
        target_size: Union[str, Tuple[int, ...]] = 'max',
        pad_value: float = 0.0,
        align: Union[str, List[str]] = Align.CENTER,
        ignore_dims: Optional[Union[int, List[int]]] = None,
        return_mask: bool = False,
    ) -> None:
        self.target_size = target_size
        self.pad_value = pad_value
        self.align = align
        self.return_mask = return_mask

        if ignore_dims is None:
            self.ignore_dims: List[int] = []
        elif isinstance(ignore_dims, int):
            self.ignore_dims = [ignore_dims]
        else:
            self.ignore_dims = list(ignore_dims)

    # ── helpers ───────────────────────────────────────────────────────────────

    def _normalize_ignore_dims(self, ndim: int) -> Set[int]:
        """Converts negative indices to positive and returns a set."""
        normalized: Set[int] = set()
        for d in self.ignore_dims:
            if d < 0:
                d += ndim
            if 0 <= d < ndim:
                normalized.add(d)
        return normalized

    def _get_batch_stats(
        self, batch_list: List[torch.Tensor],
    ) -> Tuple[List[int], List[int]]:
        """Calculates min and max shapes across the batch in a single pass."""
        if not batch_list:
            return [], []
        ndim = batch_list[0].ndim
        max_shape = list(batch_list[0].shape)
        min_shape = list(batch_list[0].shape)
        for t in batch_list[1:]:
            for i in range(ndim):
                s = t.shape[i]
                if s > max_shape[i]:
                    max_shape[i] = s
                if s < min_shape[i]:
                    min_shape[i] = s
        return max_shape, min_shape

    def _resolve_target_shape(
        self,
        tensor: torch.Tensor,
        max_shape: List[int],
        min_shape: List[int],
    ) -> List[int]:
        """Determines the final target shape for a specific tensor.

        Uses an **index counter** (O(1) per dim) instead of ``list.pop(0)``
        (O(n) per pop) for consuming a fixed-size ``target_size`` tuple.
        """
        ndim = tensor.ndim
        ignore_set = self._normalize_ignore_dims(ndim)
        current_shape = tensor.shape
        final_shape: List[int] = []

        # Pre-compute the tuple once (avoids repeated isinstance inside loop).
        config: Optional[tuple] = None
        if isinstance(self.target_size, (tuple, list)):
            config = tuple(self.target_size)
        config_idx = 0

        for i in range(ndim):
            if i in ignore_set:
                final_shape.append(current_shape[i])
            elif self.target_size == 'max':
                final_shape.append(max_shape[i])
            elif self.target_size == 'min':
                final_shape.append(min_shape[i])
            else:
                # Fixed target_size tuple — consume via index.
                if config is not None and config_idx < len(config):
                    final_shape.append(config[config_idx])
                    config_idx += 1
                else:
                    final_shape.append(max_shape[i])  # fallback
        return final_shape

    def _get_align_list(self, ndim: int) -> List[str]:
        """Expands single alignment string to a list matching dimensions."""
        if isinstance(self.align, list):
            if len(self.align) < ndim:
                return [Align.CENTER] * (ndim - len(self.align)) + self.align
            return self.align[:ndim]
        return [self.align] * ndim

    # ── template __call__ ─────────────────────────────────────────────────────

    def __call__(
        self,
        batch_list: List[torch.Tensor],
        optional_list: Optional[List[torch.Tensor]] = None,
    ) -> Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]:
        if not batch_list:
            return torch.tensor([])

        should_mask = self.return_mask or (optional_list is not None)
        max_shape, min_shape = self._get_batch_stats(batch_list)
        ndim = batch_list[0].ndim
        aligns = self._get_align_list(ndim)

        # ── Fast path: all tensors already at the resolved target shape ──────
        if max_shape == min_shape:
            target_shape = self._resolve_target_shape(
                batch_list[0], max_shape, min_shape,
            )
            if target_shape == max_shape:
                data = torch.stack(batch_list)
                if should_mask:
                    if optional_list is not None:
                        mask = torch.stack([m.bool() for m in optional_list])
                    else:
                        mask = torch.ones_like(data, dtype=torch.bool)
                    return (data, mask)
                return data

        # ── Per-element processing ───────────────────────────────────────────
        n = len(batch_list)
        result_data: List[Optional[torch.Tensor]] = [None] * n
        result_mask: Optional[List[Optional[torch.Tensor]]] = (
            [None] * n if should_mask else None
        )

        for i, t in enumerate(batch_list):
            target_shape = self._resolve_target_shape(t, max_shape, min_shape)
            m_in = optional_list[i] if optional_list is not None else None
            d, m_out = self._process_single(t, target_shape, aligns, should_mask, m_in)
            result_data[i] = d
            if result_mask is not None:
                result_mask[i] = m_out

        data = torch.stack(result_data)  # type: ignore[arg-type]
        if should_mask:
            return (data, torch.stack(result_mask))  # type: ignore[arg-type]
        return data

    # ── abstract hook ─────────────────────────────────────────────────────────

    def _process_single(
        self,
        tensor: torch.Tensor,
        target_shape: List[int],
        aligns: List[str],
        should_mask: bool,
        mask: Optional[torch.Tensor],
    ) -> Tuple[torch.Tensor, Optional[torch.Tensor]]:
        """Process **one** tensor to *target_shape*.

        Must be overridden by every concrete subclass.

        Returns:
            ``(processed_data, processed_mask_or_None)``
        """
        raise NotImplementedError


# ═══════════════════════════════════════════════════════════════════════════════
# Concrete processors
# ═══════════════════════════════════════════════════════════════════════════════

class PadProcessor(BaseSpatialProcessor):
    """Pads tensors to a target shape.

    Accepts an optional ``optional_list`` for multi-level mask stacking: each
    existing mask is padded with ``False`` in the newly-added regions,
    naturally combining spatial-padding validity with any prior mask.

    Example::

        >>> proc = PadProcessor(target_size='max', align=Align.CENTER, pad_value=0)
        >>> batch = [torch.zeros(2, 2), torch.zeros(4, 4)]
        >>> out = proc(batch)                   # (2, 4, 4)
        >>> data, mask = proc(batch, optional_list=[torch.ones(2,2,dtype=torch.bool),
        ...                                     torch.ones(4,4,dtype=torch.bool)])
    """

    def _process_single(self, tensor, target_shape, aligns, should_mask, mask):
        ndim = tensor.ndim
        # Build F.pad tuple: reverse-dim order (last_l, last_r, …)
        pad_params: List[int] = []
        for d in range(ndim - 1, -1, -1):
            curr_s, targ_s = tensor.shape[d], target_shape[d]
            if curr_s >= targ_s:
                pad_params.extend([0, 0])
            else:
                _, (pl, pr) = calc_pad_crop_params(curr_s, targ_s, aligns[d])
                pad_params.extend([pl, pr])

        pad_tuple = tuple(pad_params)
        data = F.pad(tensor, pad_tuple, value=self.pad_value)

        m_out: Optional[torch.Tensor] = None
        if should_mask:
            if mask is not None:
                m_out = F.pad(mask.bool(), pad_tuple, value=False)
            else:
                m_out = F.pad(
                    torch.ones_like(tensor, dtype=torch.bool), pad_tuple, value=False,
                )
        return data, m_out


class CropProcessor(BaseSpatialProcessor):
    """Crops tensors to a target shape.

    When ``optional_list`` is provided, applies the identical crop slices to each
    existing mask so validity information is preserved through the crop.
    """

    def _process_single(self, tensor, target_shape, aligns, should_mask, mask):
        ndim = tensor.ndim
        slices: List[slice] = []
        for d in range(ndim):
            curr_s, targ_s = tensor.shape[d], target_shape[d]
            if curr_s <= targ_s:
                slices.append(slice(None))
            else:
                _, (start, end) = calc_pad_crop_params(curr_s, targ_s, aligns[d])
                slices.append(slice(start, end))

        slices_tuple = tuple(slices)
        data = tensor[slices_tuple]

        m_out: Optional[torch.Tensor] = None
        if should_mask:
            if mask is not None:
                m_out = mask.bool()[slices_tuple]
            else:
                m_out = torch.ones_like(data, dtype=torch.bool)
        return data, m_out


class SmartResizeProcessor(BaseSpatialProcessor):
    """Resizes tensors by Cropping (if larger) AND Padding (if smaller).

    When ``optional_list`` is provided, applies the same crop-then-pad sequence to
    each existing mask: cropped regions keep their original validity; newly
    padded regions are marked ``False``.
    """

    def _process_single(self, tensor, target_shape, aligns, should_mask, mask):
        ndim = tensor.ndim

        # Step 1: Crop dimensions that are too large.
        crop_slices: List[slice] = []
        for d in range(ndim):
            curr_s, targ_s = tensor.shape[d], target_shape[d]
            if curr_s > targ_s:
                _, (start, end) = calc_pad_crop_params(curr_s, targ_s, aligns[d])
                crop_slices.append(slice(start, end))
            else:
                crop_slices.append(slice(None))
        crop_tuple = tuple(crop_slices)
        t_cropped = tensor[crop_tuple]

        # Step 2: Pad dimensions that are still too small.
        pad_params: List[int] = []
        for d in range(ndim - 1, -1, -1):
            curr_s, targ_s = t_cropped.shape[d], target_shape[d]
            if curr_s < targ_s:
                _, (pl, pr) = calc_pad_crop_params(curr_s, targ_s, aligns[d])
                pad_params.extend([pl, pr])
            else:
                pad_params.extend([0, 0])
        pad_tuple = tuple(pad_params)
        data = F.pad(t_cropped, pad_tuple, value=self.pad_value)

        m_out: Optional[torch.Tensor] = None
        if should_mask:
            if mask is not None:
                m_cropped = mask.bool()[crop_tuple]
                m_out = F.pad(m_cropped, pad_tuple, value=False)
            else:
                m_out = F.pad(
                    torch.ones_like(t_cropped, dtype=torch.bool), pad_tuple, value=False,
                )
        return data, m_out


# ═══════════════════════════════════════════════════════════════════════════════
# InterpolateProcessor  (overrides __call__ — does NOT use the template)
# ═══════════════════════════════════════════════════════════════════════════════

class InterpolateProcessor(BaseProcessor):
    """Resizes tensors using interpolation.

    Unlike the other spatial processors this class inherits directly from
    ``BaseProcessor`` because it does **not** use batch-level min/max
    statistics, alignment strategies, or pad values — it always interpolates
    to a **fixed** ``target_size``.

    When ``optional_list`` is provided, each existing mask is resized to
    ``target_size`` via nearest-neighbor interpolation so validity regions
    are approximated in the new spatial resolution.

    Args:
        target_size:    Fixed output spatial size.
        mode:           Interpolation mode ('nearest', 'bilinear', 'trilinear', …).
        align_corners:  Align-corners flag.  Must be ``None`` for ``'nearest'``.
        return_mask:    Whether to produce a validity mask.
        ignore_dims:    Dimension indices excluded from the spatial size tuple.
    """

    def __init__(
        self,
        target_size: Tuple[int, ...],
        mode: str = 'bilinear',
        align_corners: Optional[bool] = False,
        return_mask: bool = False,
        ignore_dims: Optional[Union[int, List[int]]] = None,
    ) -> None:
        self.target_size = target_size
        self.mode = mode
        self.align_corners = None if mode == 'nearest' else align_corners
        self.return_mask = return_mask

        if ignore_dims is None:
            self.ignore_dims: List[int] = []
        elif isinstance(ignore_dims, int):
            self.ignore_dims = [ignore_dims]
        else:
            self.ignore_dims = list(ignore_dims)

    def __call__(
        self,
        batch_list: List[torch.Tensor],
        optional_list: Optional[List[torch.Tensor]] = None,
    ) -> Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]:
        if not batch_list:
            return torch.tensor([])

        should_mask = self.return_mask or (optional_list is not None)

        n = len(batch_list)
        result_list: List[Optional[torch.Tensor]] = [None] * n
        mask_out: Optional[List[Optional[torch.Tensor]]] = (
            [None] * n if should_mask else None
        )

        for i, t in enumerate(batch_list):
            original_ndim = t.ndim
            t_in = t.unsqueeze(0)  # add batch dim: (1, ...)

            added_channel = False
            if original_ndim == 2:
                t_in = t_in.unsqueeze(1)  # (1, 1, H, W)
                added_channel = True

            try:
                t_out = F.interpolate(
                    t_in,
                    size=self.target_size,
                    mode=self.mode,
                    align_corners=self.align_corners,
                )
            except Exception as e:
                logger.error(
                    "Interpolation failed. Input: %s, Target: %s, Mode: %s",
                    t.shape, self.target_size, self.mode,
                )
                raise

            if added_channel:
                t_out = t_out.squeeze(1)
            t_out = t_out.squeeze(0)
            result_list[i] = t_out

            if should_mask:
                if optional_list is not None:
                    m = optional_list[i].float().unsqueeze(0)
                    if original_ndim == 2:
                        m = m.unsqueeze(1)
                    m_out = F.interpolate(m, size=self.target_size, mode='nearest')
                    if original_ndim == 2:
                        m_out = m_out.squeeze(1)
                    mask_out[i] = m_out.squeeze(0).bool()  # type: ignore[index]
                else:
                    mask_out[i] = torch.ones_like(t_out, dtype=torch.bool)  # type: ignore[index]

        data = torch.stack(result_list)  # type: ignore[arg-type]
        if should_mask:
            return (data, torch.stack(mask_out))  # type: ignore[arg-type]
        return data
