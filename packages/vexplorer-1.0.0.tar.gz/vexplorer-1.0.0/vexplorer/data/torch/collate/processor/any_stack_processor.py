# -*- coding: utf-8 -*-
import torch
import numpy as np
from typing import List, Any, Optional, Union
from ..base.base_processor import BaseProcessor


class StackProcessor(BaseProcessor):
    """A processor that stacks a list of inputs into a single Tensor.

    It handles various input types:
    - **torch.Tensor**: Stacks them using ``torch.stack``.
    - **numpy.ndarray** or scalars: Converts to Tensor and stacks.
    - **int/float**: Converts to Tensor.
    - **Others (str, dict, etc.)**: Returns the original list (no-op).

    Args:
        stack_dim (int): The dimension to stack the tensors along. Defaults to 0.

    Example:
        >>> # Case 1: Stack Tensors
        >>> processor = StackProcessor()
        >>> data = [torch.tensor([1, 2]), torch.tensor([3, 4])]
        >>> processor(data)
        tensor([[1, 2],
                [3, 4]])

        >>> # Case 2: Stack Numpy Arrays
        >>> import numpy as np
        >>> data = [np.array([1.0]), np.array([2.0])]
        >>> processor(data)
        tensor([[1.],
                [2.]], dtype=torch.float64)

        >>> # Case 3: Pass-through Strings
        >>> data = ["hello", "world"]
        >>> processor(data)
        ['hello', 'world']
    """

    def __init__(self, stack_dim: int = 0):
        self.stack_dim = stack_dim

    def __call__(self, batch_list: List[Any], optional_list: Optional[List[Any]] = None) -> Any:


        # 1. Handle Empty or None
        if not batch_list:
            return None

        # Check the first element to determine the strategy
        first_elem = batch_list[0]

        if first_elem is None:
            return None

        # 2. Handle PyTorch Tensors
        if isinstance(first_elem, torch.Tensor):
            return torch.stack(batch_list, dim=self.stack_dim)

        # 3. Handle Numpy Arrays and Scalars
        # np.generic covers np.int32, np.float64, etc.
        elif isinstance(first_elem, (np.ndarray, np.generic)):
            # Optimization: torch.as_tensor is efficient and handles numpy conversion
            return torch.stack([torch.as_tensor(x) for x in batch_list], dim=self.stack_dim)

        # 4. Handle Python Native Numbers (int, float)
        elif isinstance(first_elem, (int, float)):
            # torch.tensor([1, 2, 3]) is faster/cleaner for simple lists of numbers
            return torch.tensor(batch_list)

        # 5. Fallback: Keep as List (e.g., strings, dicts, unknown objects)
        return batch_list


