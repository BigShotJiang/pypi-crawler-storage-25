# -*- coding: utf-8 -*-

import random
from typing import Any, Dict, List, Optional, Union
from ..base.base_manager import BaseProcessorManager
from ..base.base_processor import BaseProcessor


class RandomChoiceManager(BaseProcessorManager):
    """
    A processor manager that randomly selects a processor at call time.

    Supports both list and dict initialization:
    - List mode: pass a List[BaseProcessor]; optionally provide ``names`` to
      assign keys, otherwise keys default to ``processor_0``, ``processor_1``, …
    - Dict mode: pass a Dict[str, BaseProcessor] directly.

    Internally, processors are always stored as an ordered dict keyed by name.

    Args:
        processors: A list or dict of :class:`BaseProcessor` instances, or
            ``None`` to start with an empty collection.
        names: Key names to assign when ``processors`` is a list.  Must have
            the same length as ``processors`` when provided.
        *args: Forwarded to :class:`BaseProcessorManager`.
        **kwargs: Forwarded to :class:`BaseProcessorManager`.

    Raises:
        TypeError: If ``processors`` is neither a list, dict, nor ``None``.
        ValueError: If ``names`` length does not match ``processors`` length.
    """

    def __init__(
            self,
            processors: Union[List[BaseProcessor], Dict[str, BaseProcessor], None] = None,
            names: Optional[List[str]] = None,
            *args,
            **kwargs,
    ) -> None:
        super().__init__(*args, **kwargs)

        if processors is None:
            self.processors: Dict[str, BaseProcessor] = {}
        elif isinstance(processors, list):
            if names is not None:
                if len(names) != len(processors):
                    raise ValueError(
                        f"Length of 'names' ({len(names)}) must match "
                        f"length of 'processors' ({len(processors)})."
                    )
                self.processors = dict(zip(names, processors))
            else:
                self.processors = {f"processor_{i}": p for i, p in enumerate(processors)}
        elif isinstance(processors, dict):
            self.processors = dict(processors)
        else:
            raise TypeError(
                f"'processors' must be a list, dict, or None; got {type(processors).__name__}."
            )

    # ------------------------------------------------------------------
    # Processor management
    # ------------------------------------------------------------------

    def add_processor(self, name: str, processor: BaseProcessor, build: bool = False) -> None:
        """Register a processor under *name*.

        Args:
            name: Unique key for the processor.
            processor: The :class:`BaseProcessor` instance to register.
            build: If ``True``, call :meth:`build` after adding.
        """
        self.processors[name] = processor
        if build:
            self.build()

    def del_processor(self, name: str) -> None:
        """Remove the processor registered under *name*.

        Args:
            name: Key of the processor to remove.

        Raises:
            KeyError: If *name* is not found in the current processors.
        """
        if name not in self.processors:
            raise KeyError(f"No processor registered under the name '{name}'.")
        del self.processors[name]

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------

    def build(self) -> None:
        """Validate that at least one processor is registered.

        Raises:
            TypeError: If the internal processors store is not a non-empty dict.
        """
        if not isinstance(self.processors, dict) or len(self.processors) < 1:
            raise TypeError("'processors' must be a non-empty dict. Add at least one processor before building.")

    # ------------------------------------------------------------------
    # Inference
    # ------------------------------------------------------------------

    def __call__(
            self,
            batch_list: List[Any],
            optional_list: Optional[List[Any]] = None,
    ) -> Any:
        """Randomly select one processor and apply it to *batch_list*.

        Args:
            batch_list: Primary input batch passed to the selected processor.
            optional_list: Optional auxiliary input forwarded to the processor.

        Returns:
            The output of the randomly selected processor.

        Raises:
            RuntimeError: If no processors have been registered.
        """
        if not self.processors:
            raise RuntimeError(
                "No processors are registered. Add at least one processor before calling."
            )

        processor = random.choice(list(self.processors.values()))
        return processor(batch_list, optional_list=optional_list)