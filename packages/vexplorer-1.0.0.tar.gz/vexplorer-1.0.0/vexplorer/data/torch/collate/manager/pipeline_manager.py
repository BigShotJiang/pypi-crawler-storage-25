# -*- coding: utf-8 -*-

from typing import Any, Dict, List, Optional, Union
from ..base.base_manager import BaseProcessorManager
from ..base.base_processor import BaseProcessor


class AnyPipelineManager(BaseProcessorManager):
    """
    A processor manager that executes all registered processors sequentially
    as a pipeline, passing the output of each step as the input to the next.

    Processors and their names are stored in two parallel lists to guarantee
    stable insertion-order iteration on all Python versions.

    Supports both list and dict initialization:
    - List mode: pass a List[BaseProcessor]; optionally provide ``names`` to
      assign keys, otherwise keys default to ``processor_0``, ``processor_1``, …
    - Dict mode: pass a Dict[str, BaseProcessor] directly.

    At each pipeline step the processor may return either a plain value or a
    ``(batch_list, optional_list)`` tuple.  If a tuple is returned, both
    components are forwarded to the next processor; otherwise ``optional_list``
    is reset to ``None``.

    Args:
        processors: A list or dict of :class:`BaseProcessor` instances, or
            ``None`` to start with an empty collection.
        names: Key names to assign when ``processors`` is a list.  Must have
            the same length as ``processors`` when provided.
        *args: Forwarded to :class:`BaseProcessorManager`.
        **kwargs: Forwarded to :class:`BaseProcessorManager`.

    Raises:
        TypeError: If ``processors`` is neither a list, dict, nor ``None``.
        ValueError: If ``names`` length does not match ``processors`` length.
    """

    def __init__(
            self,
            processors: Union[List[BaseProcessor], Dict[str, BaseProcessor], None] = None,
            names: Optional[List[str]] = None,
            *args,
            **kwargs,
    ) -> None:
        super().__init__(*args, **kwargs)

        self._names: List[str] = []
        self._processors: List[BaseProcessor] = []

        if processors is None:
            pass
        elif isinstance(processors, list):
            if names is not None:
                if len(names) != len(processors):
                    raise ValueError(
                        f"Length of 'names' ({len(names)}) must match "
                        f"length of 'processors' ({len(processors)})."
                    )
                self._names = list(names)
            else:
                self._names = [f"processor_{i}" for i in range(len(processors))]
            self._processors = list(processors)
        elif isinstance(processors, dict):
            self._names = list(processors.keys())
            self._processors = list(processors.values())
        else:
            raise TypeError(
                f"'processors' must be a list, dict, or None; got {type(processors).__name__}."
            )

    # ------------------------------------------------------------------
    # Processor management
    # ------------------------------------------------------------------

    def add_processor(self, name: str, processor: BaseProcessor, build: bool = False) -> None:
        """Append a processor to the end of the pipeline under *name*.

        Args:
            name: Unique key for the processor.
            processor: The :class:`BaseProcessor` instance to register.
            build: If ``True``, call :meth:`build` after adding.

        Raises:
            ValueError: If *name* is already registered.
        """
        if name in self._names:
            raise ValueError(f"A processor named '{name}' is already registered.")
        self._names.append(name)
        self._processors.append(processor)
        if build:
            self.build()

    def del_processor(self, name: str) -> None:
        """Remove the processor registered under *name* from the pipeline.

        Args:
            name: Key of the processor to remove.

        Raises:
            KeyError: If *name* is not found in the current processors.
        """
        if name not in self._names:
            raise KeyError(f"No processor registered under the name '{name}'.")
        idx = self._names.index(name)
        self._names.pop(idx)
        self._processors.pop(idx)

    # ------------------------------------------------------------------
    # Read-only helpers
    # ------------------------------------------------------------------

    @property
    def names(self) -> List[str]:
        """Ordered list of registered processor names."""
        return list(self._names)

    @property
    def processors(self) -> List[BaseProcessor]:
        """Ordered list of registered processor objects."""
        return list(self._processors)

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------

    def build(self) -> None:
        """Validate that at least one processor is registered.

        Raises:
            TypeError: If no processors have been added yet.
        """
        if len(self._processors) < 1:
            raise TypeError(
                "'processors' must be non-empty. Add at least one processor before building."
            )

    # ------------------------------------------------------------------
    # Inference
    # ------------------------------------------------------------------

    def __call__(
            self,
            batch_list: List[Any],
            optional_list: Optional[List[Any]] = None,
    ) -> Any:
        """Run *batch_list* through every processor in pipeline order.

        Args:
            batch_list: Primary input batch for the first processor.
            optional_list: Optional auxiliary input for the first processor.

        Returns:
            The output produced by the final processor in the pipeline.

        Raises:
            RuntimeError: If no processors have been registered.
        """
        if not self._processors:
            raise RuntimeError(
                "No processors are registered. Add at least one processor before calling."
            )

        result = batch_list
        for processor in self._processors:
            result = processor(batch_list, optional_list=optional_list)
            if isinstance(result, tuple) and len(result) == 2:
                batch_list, optional_list = result
            else:
                batch_list, optional_list = result, None

        return result