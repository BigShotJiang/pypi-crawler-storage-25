# -*- coding: utf-8 -*-
import torch
import numpy as np
from typing import Any, List, Optional
from ..base.base_manager import BaseProcessorManager
from ..base.base_processor import BaseProcessor

from ..utils.any_datatype_transform import to_tensor, to_bool_mask


class AnyDtypeManager(BaseProcessorManager):
    """Wraps any ``BaseProcessor``, transparently converting non-tensor inputs.

    Allows processors that only accept ``torch.Tensor`` (e.g. all
    ``BaseSpatialProcessor`` subclasses) to be called with numpy arrays,
    Python lists, or mixed-dtype tensors.  The wrapped processor is
    otherwise completely transparent — its return value (including
    ``(data, mask)`` tuples) is passed through unchanged.

    Example::

        pad = PadProcessor(target_size='max', return_mask=True)
        wrapped = AnyDtypeManager(pad, dtype=torch.float32)

        batch = [np.zeros((2, 4)), np.zeros((3, 4))]
        data, mask = wrapped(batch)

        masks_in = [np.ones((2, 4), dtype=bool), np.ones((3, 4), dtype=bool)]
        data, mask = wrapped(batch, optional_list=masks_in)

    Args:
        processor: Any callable with signature
            ``__call__(batch_list, optional_list=None)``.
        dtype:     Target float dtype for ``batch_list`` elements.
                   ``None`` (default) preserves source dtype.
    """

    def __init__(self,
                 processor: BaseProcessor = None,
                 dtype: Optional[torch.dtype] = None, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.processor   = processor
        self.dtype       = dtype

    def add_processor(self, name=None, processor: BaseProcessor = None, build = False):
        if self.processor is None:
            if processor is None:
                raise RuntimeError('processor cannot be None')
            else:
                if not callable(processor):
                    raise RuntimeError(f'processor [{name}] {processor} must be a callable')
                self.processor = processor
        else:
            raise RuntimeError('processor has already been added')
        if build:
            self.build()

    def build(self):
        if self.processor is None:
            raise RuntimeError('processor cannot be None')
        if not callable(self.processor):
            raise RuntimeError(f'processor {type(self.processor)} must be a callable')


    def __call__(
        self,
        batch_list: List[Any],
        optional_list:  Optional[List[Any]] = None,
    ) -> Any:
        batch_list = [to_tensor(t, self.dtype) for t in batch_list]
        if optional_list is not None:
            optional_list = [to_bool_mask(m) for m in optional_list]
        return self.processor(batch_list, optional_list=optional_list)


# ── AnyDtypeMixin ─────────────────────────────────────────────────────────────

class AnyDtypeMixin:
    """Mixin that injects automatic dtype conversion into any existing processor.

    Insert before the concrete processor class in the MRO so that
    ``__call__`` converts inputs first, then delegates via ``super()``.

    Example::

        class AnyPadProcessor(AnyDtypeMixin, PadProcessor):
            pass

        # dtype is a keyword-only arg consumed by the mixin;
        # all other args are forwarded to PadProcessor.
        proc = AnyPadProcessor(target_size='max', return_mask=True,
                               dtype=torch.float16)
        data, mask = proc([np.zeros((3, 3)), np.zeros((5, 5))])  # float16

    Args:
        dtype: Target dtype passed to :func:`to_tensor`.
               ``None`` (default) preserves source dtype.
    """

    dtype: Optional[torch.dtype] = None

    def __init__(self, *args: Any, dtype: Optional[torch.dtype] = None, **kwargs: Any) -> None:
        self.dtype = dtype
        super().__init__(*args, **kwargs)  # type: ignore[call-arg]

    def __call__(
        self,
        batch_list: List[Any],
        optional_list: Optional[List[Any]] = None,
    ) -> Any:
        batch_list = [to_tensor(t, self.dtype) for t in batch_list]
        if optional_list is not None:
            optional_list = [to_bool_mask(m) for m in optional_list]
        return super().__call__(batch_list, optional_list=optional_list)  # type: ignore[call-arg]
