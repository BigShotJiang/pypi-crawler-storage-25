import torch
import numpy as np
from typing import List, Union, Tuple, Any, Optional
from ..base.base_manager import BaseProcessorManager
from ..base.base_processor import BaseProcessor

from ..utils.any_datatype_transform import to_tensor


class SequenceManager(BaseProcessorManager):
    """Applies a spatial processor globally across all frames in every sequence,
    then assembles the results into a ``(B, ..., T)`` batch with temporal padding.

    All frames from all sequences are flattened and passed to ``processor``
    in a single call, so spatial dimensions are normalised across the entire batch
    (global max/min). Temporal differences between sequences are handled via
    zero-padding and, when ``return_mask=True``, a combined spatial+temporal mask.
    The temporal axis is placed last so the output is contiguous and compatible
    with ``(B, C, D, H, W, T)`` model conventions.

    Args:
        processor: Spatial processor (e.g. ``PadProcessor``) applied to the
            flat list of all frames.
        pad_value: Scalar fill value used for temporal padding. Defaults to 0.0.
        dtype: Target dtype for frame conversion. ``None`` (default) preserves
            the source dtype (zero-copy for tensors / numpy arrays).
    """

    def __init__(self,
                 processor: BaseProcessor = None,
                 pad_value: float = 0.0,
                 dtype: Optional[torch.dtype] = None,
                 *args,
                 **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.processor      = processor
        self.pad_value      = pad_value
        self.dtype          = dtype
        self.return_mask    = getattr(processor, 'return_mask', False)

    def add_processor(self, name=None, processor: BaseProcessor = None, build = False):
        if self.processor is None:
            if processor is None:
                raise RuntimeError('processor cannot be None')
            else:
                if not callable(processor):
                    raise RuntimeError(f'processor [{name}]{processor} must be a callable')
                self.processor = processor
        else:
            raise RuntimeError('processor has already been added')

        if build:
            self.build()

    def build(self):
        if self.processor is None:
            raise RuntimeError('processor cannot be None')
        if not callable(self.processor):
            raise RuntimeError(f'processor {self.processor} must be a callable')
        self.return_mask    = getattr(self.processor, 'return_mask', False)

    def __call__(
        self,
        batch_list: List[List[Union[np.ndarray, torch.Tensor]]],
        optional_list: Optional[List[Any]] = None,
    ) -> Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]:
        if not batch_list:
            return torch.tensor([])

        lengths = [len(seq) for seq in batch_list]

        # Flatten all frames in one pass; convert type/dtype as configured.
        all_frames = [to_tensor(frame, self.dtype) for seq in batch_list for frame in seq]

        # Global spatial processing — a single processor call for the whole batch.
        spatial_out = self.processor(all_frames)
        if isinstance(spatial_out, tuple):
            spatial_data, spatial_masks = spatial_out
        else:
            spatial_data, spatial_masks = spatial_out, None

        # Pre-allocate (B, ..., T) output — temporal axis last for contiguous layout.
        batch_size = len(batch_list)
        max_t      = max(lengths)
        device     = spatial_data.device
        dtype      = spatial_data.dtype
        out_shape  = (batch_size,) + spatial_data.shape[1:] + (max_t,)

        if self.pad_value == 0.0:
            final_data = torch.zeros(out_shape, dtype=dtype, device=device)
        else:
            final_data = torch.full(out_shape, self.pad_value, dtype=dtype, device=device)

        final_mask: Optional[torch.Tensor] = None
        if self.return_mask:
            mask_shape = (batch_size,) + (
                spatial_masks.shape[1:] if spatial_masks is not None else ()
            ) + (max_t,)
            final_mask = torch.zeros(mask_shape, dtype=torch.bool, device=device)

        # Reassemble using torch.split (one Python call) instead of manual cursor.
        # movedim(0, -1): O(1) view, moves T from processor's dim-0 to last before copy.
        data_splits = torch.split(spatial_data, lengths, dim=0)
        mask_splits = (
            torch.split(spatial_masks, lengths, dim=0)
            if spatial_masks is not None else None
        )

        for i, length in enumerate(lengths):
            final_data[i, ..., :length] = data_splits[i].movedim(0, -1)
            if final_mask is not None:
                if mask_splits is not None:
                    final_mask[i, ..., :length] = mask_splits[i].movedim(0, -1)
                else:
                    final_mask[i, ..., :length] = True

        return (final_data, final_mask) if self.return_mask else final_data


class DualSequenceManager(BaseProcessorManager):
    """Two-stage sequence processor that decouples within-sequence and cross-batch normalisation.

    **Stage 1 — ``sample_processor`` (per-sequence)**:
        Applied independently to each sequence. Because the processor sees only
        the frames of *one* sequence at a time, any random spatial parameters
        (e.g. a random-crop offset) are shared by all frames in that sequence,
        guaranteeing spatial coherence within a clip.

    **Stage 2 — ``batch_processor`` (cross-batch)**:
        Applied to all frames from every sequence together. Normalises spatial
        dimensions across the entire batch. If Stage 1 produced per-frame masks
        they are forwarded as ``optional_list``, enabling multi-level mask stacking
        (spatial-padding mask ∧ Stage-1 mask).

    **Output**:
        After Stage 1, each per-sequence tensor ``(T_i, …)`` is reordered to
        ``(…, T_i)`` via a zero-copy ``movedim(0, -1)``.  ``batch_processor``
        then receives ``[(H_0, …, T_0), (H_1, …, T_1), …]`` and normalises all
        dimensions at once, producing ``(B, H_max, …, T_max)`` directly — i.e.
        **temporal axis last**, consistent with ``(B, C, D, H, W, T)`` model
        conventions.  The combined mask (spatial ∧ temporal) is returned when
        either processor has ``return_mask=True``.

    .. note::
        ``batch_processor`` operates on tensors of shape ``(…, T_i)``, where
        **the last axis is temporal**.  Configure ``ignore_dims`` relative to
        this layout.  Example: if frames have shape ``(C, H, W)``, sequences
        passed to ``batch_processor`` have shape ``(C, H, W, T)``, so to
        preserve the channel dimension use ``ignore_dims=[0]``.

    Args:

        sample_processor: Spatial processor applied per-sequence (Stage 1).

        batch_processor:  Spatial processor applied to the list of per-sequence
            tensors (Stage 2). Must accept a ``optional_list`` keyword argument
            (all built-in ``BaseSpatialProcessor`` subclasses do).

        pad_value: Scalar fill value forwarded to ``batch_processor``.
        dtype: Target dtype for frame conversion. ``None`` (default) preserves
            the source dtype (zero-copy for tensors / numpy arrays).
    """

    def __init__(self, sample_processor: BaseProcessor = None,
                 batch_processor: BaseProcessor = None,
                 pad_value: float = 0.0,
                 dtype: Optional[torch.dtype] = None,
                 *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.sample_processor = sample_processor
        self.batch_processor  = batch_processor
        self.pad_value        = pad_value
        self.dtype            = dtype
        self.return_mask = (
            getattr(self.sample_processor, 'return_mask', False)
            or getattr(self.batch_processor, 'return_mask', False)
        )

    def add_processor(self, name, processor: BaseProcessor, build = False):
        if name == 'sample_processor':
            self.sample_processor = processor
        elif name == 'batch_processor':
            self.batch_processor = processor
        else:
            raise RuntimeError(f'unknown processor {name}, should be sample_processor or batch_processor')
        if build:
            self.build()

    def build(self):
        if self.sample_processor is None:
            raise RuntimeError('sample_processor cannot be None')
        if self.batch_processor is None:
            raise RuntimeError('batch_processor cannot be None')
        self.return_mask = (
                getattr(self.sample_processor, 'return_mask', False)
                or getattr(self.batch_processor, 'return_mask', False)
        )

    def __call__(
        self,
        batch_list: List[List[Union[np.ndarray, torch.Tensor]]],
        optional_list: Optional[List[Any]] = None,
    ) -> Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]:
        if not batch_list:
            return torch.tensor([])

        # ── Stage 1: Per-sequence spatial processing ─────────────────────────
        seq_data:  List[torch.Tensor]           = []
        seq_masks: List[Optional[torch.Tensor]] = []
        sample_has_mask = False

        for seq in batch_list:
            frames = [to_tensor(f, self.dtype) for f in seq]
            out    = self.sample_processor(frames)
            if isinstance(out, tuple):
                seq_data.append(out[0])
                seq_masks.append(out[1])
                sample_has_mask = True
            else:
                seq_data.append(out)
                seq_masks.append(None)

        # ── Move T from dim-0 to last: (T, ...) → (..., T) — O(1) view ──────
        seq_data = [s.movedim(0, -1) for s in seq_data]

        # ── Stage 2: Batch-level processing → (B, ..., T_max) ────────────────
        flat_masks: Optional[List[torch.Tensor]] = None
        if sample_has_mask:
            flat_masks = [
                m.movedim(0, -1) if m is not None else torch.ones_like(d, dtype=torch.bool)
                for m, d in zip(seq_masks, seq_data)
            ]

        return self.batch_processor(seq_data, optional_list=flat_masks)


