import random
from typing import Union, Dict, List, Any, Optional
import torch

from ..base.base_manager import BaseProcessorManager
from ..processor.any_stack_processor import StackProcessor
from ..base.base_processor import BaseProcessor


class CompositeBatchManager(BaseProcessorManager):
    """Collates a list of dictionaries into a batched dictionary based on a configuration plan.

    Features:
        - **Grouping**: Groups inputs by a specific key (e.g., 'group_name').
        - **Processor Dispatch**: Applies specific processors to specific data keys.
        - **Zero-Copy**: Efficiently transposes list of dicts to dict of lists without deep copying.

    Args:
        processors (Dict): Mapping from data key to Processor instance.
        group_name (str): Key used to group micro-batches. Defaults to '__group_name__'.
    """
    def __init__(self,
                 processors: Dict[str, BaseProcessor] = None,
                 group_name: str = '__group_name__',
                 optional_name: str = '_mask',
                 *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.processors = processors if processors is not None else dict()
        self.group_name = group_name
        self.optional_name = optional_name
        self.default_processor = StackProcessor()

    def add_processor(self, name, processor: BaseProcessor, build = False):
        if not callable(processor):
            raise RuntimeError(f'processor [{name}] {processor} must be a callable')
        self.processors[name] = processor
        if build:
            self.build()

    def del_processor(self, name: str) -> None:
        """Remove the processor registered under *name*.

        Args:
            name: Key of the processor to remove.

        Raises:
            KeyError: If *name* is not found in the current processors.
        """
        if name not in self.processors:
            raise KeyError(f"No processor registered under the name '{name}'.")
        del self.processors[name]


    def build(self):
        if len(self.processors) == 0:
            raise RuntimeError('No processors defined.')

    def _get_processor(self, key: str) -> BaseProcessor:
        """Retrieves or samples a processor for the given key."""
        proc = self.processors.get(key, self.default_processor)
        return proc

    def __call__(self, batch: List[Dict[str, Any]], optional_list: Optional[List[Any]] = None) -> List[Dict[str, Any]]:
        """
        Executes the core data collation process: grouping, transposing, and processing.

        This method takes a flat list of dictionaries (usually yielded by a PyTorch Dataset),
        groups them based on a predefined key (`self.group_name`), transposes the grouped
        data from a List-of-Dicts to a Dict-of-Lists, and finally applies the registered
        processors to each corresponding data field.

        Args:
            batch (List[Dict[str, Any]]): The raw input batch from the dataloader.
                Each dictionary represents a single data sample.
            optional_list (Optional[List[Any]], optional): An optional secondary list of data.
                Defaults to None. (Note: Currently unused in the base implementation).

        Returns:
            List[Dict[str, Any]]: A list of processed "micro-batches". Each dictionary in
            the list represents a single group with its processed tensors/data.

        Example:
            Assume `self.group_name = '__group_name__'` and `self.optional_name = '_mask'`.
            Assume `self.processors` has a standard stacker for 'image' and a specialized
            processor for 'text' that returns a tuple `(padded_tokens, attention_mask)`.

            >>> # 1. Input: A flat list of 3 samples (2 in Group A, 1 in Group B)
            >>> raw_batch = [
            ...     {"__group_name__": "A", "image": img1, "text": txt1},
            ...     {"__group_name__": "A", "image": img2, "text": txt2},
            ...     {"__group_name__": "B", "image": img3, "text": txt3}
            ... ]
            >>>
            >>> # 2. What happens inside:
            >>> # Group A gets transposed to: {"image": [img1, img2], "text": [txt1, txt2]}
            >>> # Processors are applied:
            >>> #   - image_processor([img1, img2]) -> stacked_images_A
            >>> #   - text_processor([txt1, txt2]) -> (padded_text_A, text_mask_A)
            >>>
            >>> # 3. Output: A list of 2 grouped micro-batches
            >>> output = manager(raw_batch)
            >>> print(output)
            [
                {
                    "__group_name__": "A",
                    "image": <stacked_images_A>,   # Processed by image processor
                    "text": <padded_text_A>,       # First item of the text processor's tuple
                    "text_mask": <text_mask_A>     # Second item, auto-named with '_mask'
                },
                {
                    "__group_name__": "B",
                    "image": <stacked_images_B>,
                    "text": <padded_text_B>,
                    "text_mask": <text_mask_B>
                }
            ]
        """
        if not batch: return []

        # 1. Grouping
        grouped_data: Dict[str, List] = {}
        for item in batch:
            group_key = item.get(self.group_name, 'default')
            grouped_data.setdefault(group_key, []).append(item)

        final_micro_batches = []

        # 2. Processing per group
        for grp_name, items in grouped_data.items():
            if not items: continue

            # Transpose: List[Dict] -> Dict[List]
            data_keys = [k for k in items[0].keys() if k != self.group_name]
            transposed = {k: [x[k] for x in items] for k in data_keys}

            processed_group: Dict[str, Any] = {self.group_name: grp_name}

            for k, val_list in transposed.items():
                processor = self._get_processor(k)
                result = processor(val_list)

                # Handle (Data, Mask) tuple returns
                if isinstance(result, tuple) and len(result) == 2:
                    processed_group[k], processed_group[f'{k}{self.optional_name}'] = result
                else:
                    processed_group[k] = result

            final_micro_batches.append(processed_group)

        return final_micro_batches


# input 输入dataset的item
# [
#     {"__group_name__": "group_A", "image": img1, "text": txt1},
#     {"__group_name__": "group_A", "image": img2, "text": txt2},
#     {"__group_name__": "group_B", "image": img3, "text": txt3}
# ]
# output 按照组名打包的super-batch
# [
#     # 这是 group_A 打包好的微批次 (Micro-batch)
#     {
#         "__group_name__": "group_A",
#         "image": <经过 StackProcessor 处理过的 Tensor，形状如 [2, C, H, W]>,
#         "text": <经过 TextProcessor 处理过的 Tensor>,
#         "text_mask": <如果 TextProcessor 返回了 tuple，这里会自动生成掩码> # 由 self.optional_name 决定后缀
#     },
#
#     # 这是 group_B 打包好的微批次 (Micro-batch)
#     {
#         "__group_name__": "group_B",
#         "image": <处理过的 Tensor，形状如 [1, C, H, W]>,
#         "text": <处理过的 Tensor>
#     }
# ]

