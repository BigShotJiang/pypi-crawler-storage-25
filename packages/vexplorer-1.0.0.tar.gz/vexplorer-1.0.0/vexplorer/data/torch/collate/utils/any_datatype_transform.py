# -*- coding: utf-8 -*-
import torch
import numpy as np
from typing import Any, List, Optional


def to_tensor(x: Any, dtype: Optional[torch.dtype] = None) -> torch.Tensor:
    """Convert a single item of any supported type to a ``torch.Tensor``.

    When *dtype* is ``None`` the source dtype is preserved (zero-copy for
    tensors and numpy arrays when no cast is needed).  Pass an explicit dtype
    (e.g. ``torch.float32``) to force a cast.

    Conversion table:

    =====================  =====================================================
    Input type             Behaviour
    =====================  =====================================================
    ``torch.Tensor``       Cast to *dtype* when needed; identity otherwise.
    ``numpy.ndarray``      ``torch.from_numpy`` (zero-copy), cast if needed.
    ``numpy.generic``      ``torch.as_tensor``, cast if needed.
    ``list`` / ``tuple``   ``torch.tensor(x, dtype=dtype)``
    ``int`` / ``float``    ``torch.tensor(x, dtype=dtype)``
    =====================  =====================================================

    Args:
        x:     Input item.
        dtype: Target dtype, or ``None`` to preserve source dtype.

    Returns:
        ``torch.Tensor`` with the requested (or original) dtype.

    Raises:
        TypeError: If *x* is none of the supported types.
    """
    if isinstance(x, torch.Tensor):
        return x if (dtype is None or x.dtype == dtype) else x.to(dtype=dtype)

    if isinstance(x, np.ndarray):
        t = torch.from_numpy(x)                          # zero-copy
        return t if (dtype is None or t.dtype == dtype) else t.to(dtype=dtype)

    if isinstance(x, np.generic):                        # np.float32, np.int64, …
        t = torch.as_tensor(x)
        return t if (dtype is None or t.dtype == dtype) else t.to(dtype=dtype)

    if isinstance(x, (list, tuple, int, float)):
        return torch.tensor(x, dtype=dtype)              # dtype=None → inferred

    raise TypeError(
        f"to_tensor: unsupported type '{type(x).__name__}'. "
        f"Expected Tensor, ndarray, list, tuple, int, or float."
    )


def to_bool_mask(x: Any) -> torch.Tensor:
    """Convert a single item of any supported type to a bool mask tensor.

    =====================  ================================================
    Input type             Behaviour
    =====================  ================================================
    ``torch.Tensor``       ``.bool()``; zero-copy when already ``torch.bool``.
    ``numpy.ndarray``      ``torch.from_numpy(...).bool()``
    ``list`` / ``tuple``   ``torch.tensor(..., dtype=torch.bool)``
    =====================  ================================================

    Args:
        x: Input item.

    Returns:
        ``torch.Tensor`` of dtype ``torch.bool``.

    Raises:
        TypeError: If *x* is not one of the supported types.
    """
    if isinstance(x, torch.Tensor):
        return x if x.dtype == torch.bool else x.bool()

    if isinstance(x, np.ndarray):
        return torch.from_numpy(x).bool()

    if isinstance(x, (list, tuple)):
        return torch.tensor(x, dtype=torch.bool)

    raise TypeError(
        f"to_bool_mask: unsupported type '{type(x).__name__}'. "
        f"Expected Tensor, ndarray, list, or tuple."
    )

