

from ....general.collate.base import BaseProcessor