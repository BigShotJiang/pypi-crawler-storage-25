# -*- coding: utf-8 -*-
import numpy as np
import torch
import random
import logging


from .....core.general.constant.numeric import MAX_SAFE_INT




def worker_init_fn_with_set_seed(worker_id: int) -> None:
    """Initialization function for DataLoader workers to ensure deterministic behavior.

    In PyTorch's DataLoader, when ``num_workers > 0``, each worker process inherits
    the random state from the parent process. Without manual reseeding, libraries like
    ``numpy`` and ``random`` will generate the exact same sequence of random numbers
    in all workers, leading to duplicated data augmentation.

    This function ensures that each worker has a unique, deterministic seed derived
    from the PyTorch initial seed.

    Args:
        worker_id (int): The unique ID of the current worker process (0 to num_workers-1).

    Example:
        >>> from torch.utils.data import DataLoader
        >>> dataloader = DataLoader(
        ...     dataset,
        ...     batch_size=32,
        ...     num_workers=4,
        ...     worker_init_fn=worker_init_fn_with_set_seed
        ... )
    """
    # 1. Get the seed set by PyTorch for this specific worker.
    # PyTorch automatically sets the seed for each worker to:
    #    (base_seed + worker_id)
    # So `torch.initial_seed()` is already unique per worker.
    pyt_seed = torch.initial_seed()

    # 2. Ensure the seed fits within the safe integer range (uint32).
    # We add worker_id again as an extra salt, though strictly speaking
    # pyt_seed is already distinct.
    seed = (pyt_seed + worker_id) % MAX_SAFE_INT

    # 3. Set seeds for third-party libraries
    np.random.seed(seed)
    random.seed(seed)

    # Optional: Log for debugging (usually disabled in production)
    # logging.debug(f"Worker {worker_id} initialized with seed {seed}")



