# -*- coding: utf-8 -*-
"""
Base transform manager for managing and composing multiple transform.

All concrete managers inherit from :class:`BaseTransformManager` and use
``nn.ModuleDict`` / ``nn.ModuleList`` to register child transform.  This
makes them fully compatible with ``accelerate.prepare()``, ``model.to()``,
``model.cuda()``, ``model.parameters()``, etc. — no manual device transfer
is needed.
"""

from abc import ABC, abstractmethod
from typing import Any, Optional, Union

import torch
import torch.nn as nn
from torch import Tensor


__all__ = ['BaseTransformManager']


class BaseTransformManager(nn.Module, ABC):
    """
    Abstract base class for managing multiple transform.

    Subclasses store transform in ``nn.ModuleDict`` (or ``nn.ModuleList``),
    so PyTorch automatically tracks them as child modules.  This means:

    * ``manager.to(device)`` moves **all** transform recursively.
    * ``accelerate.prepare(manager)`` works out-of-the-box for mixed-device
      training (GPU / multi-GPU / TPU).
    * ``manager.parameters()`` / ``manager.state_dict()`` include all
      child-transform parameters.

    Subclasses also provide shared infrastructure for tensor preparation
    (detach / clone) before transform are applied.

    Parameters
    ----------
    detach : bool
        Whether to detach input tensors before transformation. Default: False.
    clone : bool
        Whether to clone input tensors before transformation. Default: False.
    """

    def __init__(self, detach: bool = False, clone: bool = False):
        super().__init__()
        self._detach = detach
        self._clone = clone
        # Fast flag — when both are False every _prepare_* call is a no-op
        # and we can skip the isinstance check entirely.
        self._needs_prepare: bool = detach or clone

    # ------------------------------------------------------------------
    # Tensor preparation helpers
    # ------------------------------------------------------------------

    def _prepare_tensor(self, value: Any) -> Any:
        """Detach and/or clone *value* if it is a :class:`~torch.Tensor`.

        When neither ``detach`` nor ``clone`` was requested at
        construction time, this method returns *value* unchanged
        without even checking its type (zero overhead on the hot path).
        """
        if not self._needs_prepare:
            return value
        if isinstance(value, Tensor):
            if self._detach:
                value = value.detach()
            if self._clone:
                value = value.clone()
        return value

    def _prepare_args(self, args: tuple) -> tuple:
        """Apply detach/clone to every positional argument."""
        if not self._needs_prepare:
            return args
        return tuple(self._prepare_tensor(a) for a in args)

    def _prepare_kwargs(self, kwargs: dict) -> dict:
        """Apply detach/clone to every keyword argument."""
        if not self._needs_prepare:
            return kwargs
        return {k: self._prepare_tensor(v) for k, v in kwargs.items()}

    # ------------------------------------------------------------------
    # Abstract interface
    # ------------------------------------------------------------------

    @abstractmethod
    def add_transform(
        self,
        name: str,
        transform: nn.Module,
        wrapper: Optional[Any] = None,
    ) -> None:
        """
        Register a transform with the manager.

        Parameters
        ----------
        name : str
            Unique name for the transform.
        transform : nn.Module
            Transform module.
        wrapper : optional
            Per-manager routing / configuration wrapper.

        Raises
        ------
        ValueError
            If *name* is already registered.
        """

    @abstractmethod
    def forward(self, *args, **kwargs) -> Any:
        """Apply all managed transform to the input."""

    @abstractmethod
    def del_transform(self, name: str) -> None:
        """
        Remove a transform by *name*.

        Raises
        ------
        KeyError
            If *name* is not registered.
        """

    def get_transform_names(self) -> list:
        """Return a list of all registered transform names."""
        return []

    def build(self):
        pass




