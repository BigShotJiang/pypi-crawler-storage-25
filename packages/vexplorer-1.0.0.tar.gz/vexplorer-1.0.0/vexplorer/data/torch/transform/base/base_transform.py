# -*- coding: utf-8 -*-
"""
Base transform class for all tensor transform.

"""

from abc import ABC, abstractmethod
from typing import Any

from torch import nn


__all__ = ['BaseTransform']


class BaseTransform(nn.Module, ABC):
    """
    Abstract base class for tensor transform.

    Subclasses must implement :meth:`forward`.  Since ``BaseTransform``
    inherits from :class:`torch.nn.Module`, the standard ``__call__``
    mechanism already delegates to ``forward`` — subclasses should
    **not** override ``__call__``.

    Examples
    --------
    >>> class MyTransform(BaseTransform):
    ...     def forward(self, x):
    ...         return x * 2
    >>> t = MyTransform()
    >>> t(torch.tensor([1.0, 2.0]))
    tensor([2., 4.])
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    @abstractmethod
    def forward(self, *args, **kwargs) -> Any:
        """Apply the transform."""

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}()"
