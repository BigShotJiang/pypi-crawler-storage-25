from .avg_pool_downsample import AvgPoolDownsample3D


__all__ = [

    'AvgPoolDownsample3D',
]
