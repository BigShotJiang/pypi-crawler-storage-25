# -*- coding: utf-8 -*-
"""Average-pooling downsampling transform."""

import random

import torch
import torch.nn as nn
from torch import Tensor

from ..base import BaseTransform

__all__ = ['AvgPoolDownsample3D']


class AvgPoolDownsample3D(BaseTransform):
    """
    Downsample a 3-D volume via average pooling.

    Pre-builds multiple ``AvgPool3d`` layers with varying kernel sizes
    (1 … *down_factor*) but the same stride.  When ``randomize=True``
    a random pooling kernel is chosen each forward call (data
    augmentation); otherwise the largest kernel is always used.

    Parameters
    ----------
    down_factor : int
        Stride of the average pool (also the max kernel size). Default: 2.
    randomize : bool
        Randomly choose kernel size per forward call.  Default: True.
    """

    def __init__(self, down_factor: int = 2, randomize: bool = True):
        super().__init__()
        self.down_factor = down_factor
        self.randomize = randomize
        self.pools = nn.ModuleList([
            nn.AvgPool3d(
                kernel_size=(k, k, k),
                stride=(down_factor, down_factor, down_factor),
            )
            for k in range(1, down_factor + 1)
        ])

    def forward(self, x: Tensor) -> Tensor:
        if self.randomize and self.training:
            idx = random.randint(0, self.down_factor - 1)
        else:
            idx = self.down_factor - 1
        return self.pools[idx](x)

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}("
            f"down_factor={self.down_factor}, randomize={self.randomize})"
        )
