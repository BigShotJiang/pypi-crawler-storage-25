# -*- coding: utf-8 -*-
"""
Transform managers for composing and routing multiple transform.

All managers use ``nn.ModuleDict`` / ``nn.ModuleList`` internally, so
``accelerate.prepare()``, ``model.to(device)``, and ``model.parameters()``
propagate through all children automatically.

Managers
--------
ComposeTransform          Sequential pipeline (most common).  Uses
                          ``nn.ModuleList`` + ``nn.ModuleDict`` internally;
                          call ``to_sequential()`` for JIT export.
DirectTransformManager    All transform receive the same input (broadcast).
ListTransformManager      Route list/tuple items by index.
DictTransformManager      Route dict items by key.
"""

from .compose import ComposeTransform, ComposeTransformWrapper
from .direct_manager import DirectTransformManager, DirectTransformWrapper
from .list_manager import ListTransformManager, ListTransformWrapper
from .dict_manager import DictTransformManager, DictTransformWrapper

__all__ = [
    # Compose (pipeline)
    'ComposeTransform',
    'ComposeTransformWrapper',
    # Direct manager
    'DirectTransformManager',
    'DirectTransformWrapper',
    # List manager
    'ListTransformManager',
    'ListTransformWrapper',
    # Dict manager
    'DictTransformManager',
    'DictTransformWrapper',
]
