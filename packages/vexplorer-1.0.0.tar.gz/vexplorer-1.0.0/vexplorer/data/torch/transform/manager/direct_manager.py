# -*- coding: utf-8 -*-
"""
Direct transform manager — all transform receive the same input (broadcast).

Each registered transform produces an independent output.  Results are
collected into a dict keyed by transform name.

Transforms are stored in ``nn.ModuleDict`` so that ``accelerate.prepare()``
and ``.to(device)`` propagate to all children automatically.
"""

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

import torch
import torch.nn as nn

from ..base import BaseTransformManager


__all__ = ['DirectTransformWrapper', 'DirectTransformManager']


@dataclass
class DirectTransformWrapper:
    """
    Configuration wrapper for transform in :class:`DirectTransformManager`.

    Parameters
    ----------
    priority : int
        Execution order — lower values run first. Default: 0.

    Examples
    --------
    Run ``'preprocess'`` before ``'augment'``:

    >>> manager.add_transform(
    ...     'augment', AugmentTransform(),
    ...     wrapper=DirectTransformWrapper(priority=1),
    ... )
    >>> manager.add_transform(
    ...     'preprocess', PreprocessTransform(),
    ...     wrapper=DirectTransformWrapper(priority=0),
    ... )
    """
    priority: int = 0


class DirectTransformManager(BaseTransformManager):
    """
    Broadcast manager — every transform receives the same input.

    Every registered transform receives the same ``*args`` and ``**kwargs``.
    Results are returned as ``Dict[str, Any]``, keyed by transform name in
    priority order.

    Implementation notes
    --------------------
    * Transforms are stored in ``nn.ModuleDict`` — PyTorch tracks them
      as child modules, so ``model.to(device)``, ``model.parameters()``,
      ``accelerate.prepare(model)`` all work automatically.
    * Execution order is cached in ``_sorted_entries`` (a list of
      ``(name, transform)`` tuples) and only rebuilt on
      ``add_transform`` / ``del_transform`` — no per-forward sorting or
      dict lookups.
    * When ``detach=False`` and ``clone=False`` (default), the
      ``_prepare_args`` / ``_prepare_kwargs`` calls are completely
      elided (zero overhead).

    Parameters
    ----------
    detach : bool
        Detach input tensors. Default: False.
    clone : bool
        Clone input tensors. Default: False.

    Examples
    --------
    Basic broadcast — two transform, same input:

    >>> manager = DirectTransformManager()
    >>> manager.add_transform('abs', MathFn(torch.abs))
    >>> manager.add_transform('neg', MathFn(torch.neg))
    >>> results = manager(torch.tensor([-1.0, 2.0]))
    >>> # {'abs': tensor([1., 2.]), 'neg': tensor([1., -2.])}

    Priority ordering:

    >>> manager = DirectTransformManager()
    >>> manager.add_transform(
    ...     'second', TransformB(),
    ...     wrapper=DirectTransformWrapper(priority=1),
    ... )
    >>> manager.add_transform(
    ...     'first', TransformA(),
    ...     wrapper=DirectTransformWrapper(priority=0),
    ... )
    >>> # 'first' runs before 'second' regardless of registration order

    With ``detach=True`` to stop gradient flow:

    >>> manager = DirectTransformManager(detach=True)
    >>> manager.add_transform('metric', SomeMetric())
    >>> results = manager(model_output)
    >>> # results['metric'] is detached from the computation graph
    """

    def __init__(self, detach: bool = False, clone: bool = False):
        super().__init__(detach=detach, clone=clone)
        # nn.ModuleDict — registered as submodule for automatic device
        # transfer / parameter collection
        self._transforms = nn.ModuleDict()
        # Wrapper metadata (not nn.Modules, so stored separately)
        self._wrappers: Dict[str, Optional[DirectTransformWrapper]] = {}
        # Pre-computed execution plan — list of (name, transform) tuples
        # in priority order.  Avoids dict lookups on every forward call.
        self._sorted_entries: List[Tuple[str, nn.Module]] = []

    def _rebuild_sorted(self) -> None:
        """Rebuild the cached priority-sorted execution plan."""
        names = sorted(
            self._transforms.keys(),
            key=lambda n: (
                self._wrappers[n].priority
                if self._wrappers[n] is not None else 0,
                n,
            ),
        )
        self._sorted_entries = [
            (n, self._transforms[n]) for n in names
        ]

    def add_transform(
        self,
        name: str,
        transform: nn.Module,
        wrapper: Optional[DirectTransformWrapper] = None,
    ) -> None:
        """
        Register a named transform with optional priority wrapper.

        Parameters
        ----------
        name : str
            Unique name for the transform.
        transform : nn.Module
            Transform module to register.
        wrapper : DirectTransformWrapper or None
            Priority configuration.  ``None`` uses default priority 0.

        Raises
        ------
        ValueError
            If *name* is already registered.
        """
        if name in self._transforms:
            raise ValueError(
                f"Transform '{name}' already exists in DirectTransformManager"
            )
        self._transforms[name] = transform
        self._wrappers[name] = wrapper
        self._rebuild_sorted()

    def forward(self, *args, **kwargs) -> Dict[str, Any]:
        """
        Broadcast input to all transform and collect results.

        Each transform receives the same ``*args`` / ``**kwargs``,
        pre-processed by ``detach`` / ``clone`` settings.

        Returns
        -------
        Dict[str, Any]
            Mapping of transform name → output, in priority order.

        Raises
        ------
        ValueError
            If no transform have been registered.
        """
        if not self._sorted_entries:
            raise ValueError(
                "No transform have been added to DirectTransformManager"
            )

        args = self._prepare_args(args)
        kwargs = self._prepare_kwargs(kwargs)

        return {
            name: transform(*args, **kwargs)
            for name, transform in self._sorted_entries
        }

    def del_transform(self, name: str) -> None:
        """
        Remove transform *name*.

        Raises
        ------
        KeyError
            If *name* is not registered.
        """
        if name not in self._transforms:
            raise KeyError(
                f"Transform '{name}' not found in DirectTransformManager"
            )
        del self._transforms[name]
        del self._wrappers[name]
        self._rebuild_sorted()

    def get_transform_names(self) -> list:
        """Return all registered transform names in priority order."""
        return [name for name, _ in self._sorted_entries]

    def get_transform_details(self) -> Dict[str, Dict[str, Any]]:
        """Return transform and their wrappers as a detail dict."""
        return {
            name: {
                'transform': self._transforms[name],
                'wrapper': self._wrappers[name],
            }
            for name in self._transforms
        }
