# -*- coding: utf-8 -*-
"""
Compose transform — sequential pipeline of transform.

This is the most commonly used manager pattern: transform are applied
sequentially, with the output of each feeding into the next.

Internally stores transform in ``nn.ModuleList`` for fast ordered
iteration and ``nn.ModuleDict`` for O(1) named access.  Both containers
are native PyTorch modules, so ``accelerate.prepare()`` and ``.to()``
propagate through all children automatically.
"""

from collections import OrderedDict
from dataclasses import dataclass
from typing import Any, List, Optional, Sequence, Union

import torch.nn as nn

from ..base import BaseTransformManager


__all__ = ['ComposeTransformWrapper', 'ComposeTransform']


@dataclass
class ComposeTransformWrapper:
    """
    Configuration wrapper for transform in :class:`ComposeTransform`.

    Parameters
    ----------
    index : int or None
        Position to insert at.  ``None`` (default) appends to the end.
        Supports negative indices (e.g. ``-1`` inserts before the last).

    Examples
    --------
    Append to end (default):

    >>> ComposeTransformWrapper()            # index=None → append
    >>> ComposeTransformWrapper(index=None)  # same

    Insert at the beginning:

    >>> ComposeTransformWrapper(index=0)

    Insert before the last transform:

    >>> ComposeTransformWrapper(index=-1)
    """
    index: Optional[int] = None


class ComposeTransform(BaseTransformManager):
    """
    Sequential composition of transform (pipeline).

    Transforms are applied in insertion order.  The output of each
    transform is passed as the input to the next.

    Implementation notes
    --------------------
    * ``nn.ModuleList`` drives the forward loop — its ordered iteration
      avoids dict-hashing overhead and is friendlier to ``torch.jit``.
    * ``nn.ModuleDict`` is maintained in parallel for O(1) name-based
      lookup / deletion.
    * Both are registered as submodules, so ``model.to(device)`` and
      ``accelerate.prepare()`` move everything automatically — **no
      custom** ``to()`` **needed**.
    * Auto-naming uses a **global persistent counter** (``_counter``) so
      names like ``'t3'`` are never reused even after deletions or mixed
      manual/auto registrations.
    * ``forward`` iterates ``_module_list`` directly — no
      ``nn.Sequential`` cache, so add/del never cause stale-pipeline bugs.
      (``nn.Sequential`` internally does the same loop, so there is no
      speed benefit to caching it.)
    * When ``detach=False`` and ``clone=False`` (default), the
      ``_prepare_tensor`` call is completely elided (zero overhead).

    Parameters
    ----------
    transforms : Sequence[nn.Module] or None
        Optional initial list of transform.
    names : Sequence[str or None] or None
        Optional names for *transform*.  Must have the same length as
        *transform* when provided.  Individual elements may be ``None``
        to request auto-naming for that position.  When the entire
        argument is ``None``, all transform are auto-named.
    wrappers : Sequence[ComposeTransformWrapper or None] or None
        Optional insertion wrappers for *transform*.  Must have the same
        length as *transform* when provided.  Individual elements may be
        ``None`` to use the default append behaviour for that position.
        When the entire argument is ``None``, all transform are appended.
    detach : bool
        Detach input tensors before the pipeline. Default: False.
    clone : bool
        Clone input tensors before the pipeline. Default: False.

    Raises
    ------
    ValueError
        If *names* is provided but its length differs from *transform*.
    ValueError
        If *wrappers* is provided but its length differs from *transform*.
    ValueError
        If *names* contains duplicates (ignoring ``None`` entries).

    Examples
    --------
    Construct with initial transform (explicit names):

    >>> pipe = ComposeTransform(
    ...     [MinMaxScale(0.0, 255.0), ToDtype(torch.float32)],
    ...     names=['scale', 'cast'],
    ... )
    >>> out = pipe(image_tensor)

    Construct with mixed names and wrappers:

    >>> pipe = ComposeTransform(
    ...     [MinMaxScale(0.0, 255.0), Normalize(), ToDtype(torch.float32)],
    ...     names=['scale', None, 'cast'],
    ...     wrappers=[None, ComposeTransformWrapper(index=0), None],
    ... )

    Auto-naming (names generated as ``'t0'``, ``'t1'``, …):

    >>> pipe = ComposeTransform([MinMaxScale(0.0, 255.0), ToDtype(torch.float32)])
    >>> pipe.get_transform_names()   # ['t0', 't1']

    Incremental build with ``add_transform``:

    >>> pipe = ComposeTransform()
    >>> pipe.add_transform('scale', MinMaxScale(0.0, 255.0))
    >>> pipe.add_transform(None, ToDtype(torch.float32))    # auto-named

    Batch add with ``add_transforms``:

    >>> pipe.add_transforms(
    ...     [Normalize(), ToDtype(torch.float32)],
    ...     names=['norm', None],
    ...     wrappers=[ComposeTransformWrapper(index=0), None],
    ... )

    Insert at a specific position using wrapper:

    >>> import ComposeTransformWrapper
    >>> pipe.add_transform('norm', Normalize(),
    ...                    wrapper=ComposeTransformWrapper(index=1))
    >>> pipe.get_transform_names()  # ['scale', 'norm', 't1']

    Access by name or index:

    >>> pipe['scale']               # by name
    >>> pipe[0]                     # by index

    Delete a transform:

    >>> removed = pipe.del_transform('norm')

    Export for JIT / inference:

    >>> seq = pipe.to_sequential()  # nn.Sequential (shares modules)
    """

    def __init__(
            self,
            transforms: Optional[Sequence[nn.Module]] = None,
            names: Optional[Sequence[Optional[str]]] = None,
            wrappers: Optional[Sequence[Optional[ComposeTransformWrapper]]] = None,
            detach: bool = False,
            clone: bool = False,
    ):
        super().__init__(detach=detach, clone=clone)

        # nn.ModuleList — ordered iteration (used in forward)
        self._module_list: nn.ModuleList = nn.ModuleList()
        # nn.ModuleDict — O(1) name-based access (used in add/del/get)
        self._module_dict: nn.ModuleDict = nn.ModuleDict()
        # ordered name list — single source of truth for name ↔ index mapping
        self._names: List[str] = []
        # Global persistent counter — guarantees unique auto-names across
        # the entire lifetime of this instance (survives add/del cycles).
        self._counter: int = 0

        if transforms is not None:
            self.add_transforms(transforms, names=names, wrappers=wrappers)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _resolve_name(self, name: Optional[str]) -> str:
        """
        Return *name* if given, otherwise generate the next auto-name.

        Auto-names follow the pattern ``'t{counter}'``.  The counter
        advances on every call — even for manually named transform —
        so auto-names are globally unique across the instance lifetime
        and never collide with previously deleted names.

        Raises
        ------
        ValueError
            If *name* already exists in the pipeline.
        """
        if name is None:
            # Advance counter until we find a name not already taken
            # (defensive: handles edge-case where user manually added 't0')
            while True:
                candidate = f"t{self._counter}"
                self._counter += 1
                if candidate not in self._module_dict:
                    return candidate
        # Manual name: always bump the counter so future auto-names stay ahead
        self._counter += 1
        if name in self._module_dict:
            raise ValueError(
                f"Transform '{name}' already exists in ComposeTransform. "
                "Use del_transform first if you want to replace it."
            )
        return name

    def _register(self, name: str, transform: nn.Module) -> None:
        """Append name + transform to all internal containers (no validation)."""
        self._names.append(name)
        self._module_list.append(transform)
        self._module_dict[name] = transform

    def _rebuild_module_list(self) -> None:
        """
        Rebuild ``_module_list`` from ``_names`` + ``_module_dict``.

        Called after deletions or mid-list insertions to keep ModuleList
        in sync with the authoritative ``_names`` order.
        """
        self._module_list = nn.ModuleList(
            [self._module_dict[n] for n in self._names]
        )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def add_transforms(
            self,
            transforms: Sequence[nn.Module],
            names: Optional[Sequence[Optional[str]]] = None,
            wrappers: Optional[Sequence[Optional[ComposeTransformWrapper]]] = None,
    ) -> List[str]:
        """
        Add multiple transform to the pipeline in one call.

        Transforms are added sequentially in the order given.  Each
        transform is inserted according to its corresponding wrapper
        (if any), meaning earlier inserts may shift the indices seen
        by later inserts — exactly as if ``add_transform`` were called
        one-by-one in the same order.

        Parameters
        ----------
        transforms : Sequence[nn.Module]
            Transforms to add.
        names : Sequence[str or None] or None
            Names for each transform.  Must have the same length as
            *transform* when provided.  Individual ``None`` entries
            trigger auto-naming for that position.  Pass ``None`` (the
            default) to auto-name all transform.
        wrappers : Sequence[ComposeTransformWrapper or None] or None
            Insertion wrappers for each transform.  Must have the same
            length as *transform* when provided.  Individual ``None``
            entries use the default append behaviour.  Pass ``None``
            (the default) to append all transform.

        Returns
        -------
        list[str]
            The registered names in the same order as *transform*
            (useful when some or all names were auto-generated).

        Raises
        ------
        ValueError
            If *names* is provided but its length differs from
            *transform*.
        ValueError
            If *wrappers* is provided but its length differs from
            *transform*.
        ValueError
            If *names* contains duplicate non-``None`` entries.

        Examples
        --------
        Append several transform, auto-naming all:

        >>> pipe.add_transforms([MinMaxScale(0.0, 255.0), ToDtype(torch.float32)])

        Mixed explicit / auto names:

        >>> pipe.add_transforms(
        ...     [MinMaxScale(0.0, 255.0), ToDtype(torch.float32)],
        ...     names=['scale', None],
        ... )

        With insertion wrappers:

        >>> pipe.add_transforms(
        ...     [Normalize(), Clamp()],
        ...     names=['norm', 'clamp'],
        ...     wrappers=[ComposeTransformWrapper(index=0), None],
        ... )
        """
        transforms = list(transforms)
        n = len(transforms)

        # Validate and normalise names
        if names is not None:
            names = list(names)
            if len(names) != n:
                raise ValueError(
                    f"'names' length ({len(names)}) must match "
                    f"'transform' length ({n})"
                )
            # Check for duplicates among non-None entries
            explicit = [name for name in names if name is not None]
            if len(set(explicit)) != len(explicit):
                duplicates = sorted({nm for nm in explicit if explicit.count(nm) > 1})
                raise ValueError(
                    f"'names' contains duplicates: {duplicates}"
                )
        else:
            names = [None] * n

        # Validate and normalise wrappers
        if wrappers is not None:
            wrappers = list(wrappers)
            if len(wrappers) != n:
                raise ValueError(
                    f"'wrappers' length ({len(wrappers)}) must match "
                    f"'transform' length ({n})"
                )
        else:
            wrappers = [None] * n

        registered: List[str] = []
        for transform, name, wrapper in zip(transforms, names, wrappers):
            registered_name = self.add_transform(name, transform, wrapper=wrapper)
            registered.append(registered_name)

        return registered

    def add_transform(
            self,
            name: Optional[str],
            transform: nn.Module,
            wrapper: Optional[ComposeTransformWrapper] = None,
    ) -> str:
        """
        Add a transform to the pipeline.

        Parameters
        ----------
        name : str or None
            Unique name for the transform.  When ``None`` an auto-name
            is generated (``'t0'``, ``'t1'``, …) via the global counter.
        transform : nn.Module
            Transform module to add.
        wrapper : ComposeTransformWrapper or None
            Insertion configuration.  Use ``wrapper.index`` to control
            where the transform is inserted.  ``None`` appends to end.

        Returns
        -------
        str
            The name that was registered (useful when *name* is ``None``).

        Raises
        ------
        ValueError
            If *name* already exists in the pipeline.
        IndexError
            If *index* is out of range.
        """
        name = self._resolve_name(name)
        index = wrapper.index if wrapper is not None else None

        if index is None:
            # Fast path: simple append — no ModuleList rebuild needed
            self._register(name, transform)
        else:
            length = len(self._names)
            if not (-(length + 1) <= index <= length):
                raise IndexError(
                    f"Index {index} out of range for pipeline of length {length}"
                )
            if index < 0:
                index = length + 1 + index
            self._names.insert(index, name)
            self._module_dict[name] = transform
            self._rebuild_module_list()

        return name

    def del_transform(self, name: str) -> nn.Module:
        """
        Remove and return the transform identified by *name*.

        Parameters
        ----------
        name : str
            Name of the transform to remove.

        Returns
        -------
        nn.Module
            The removed transform module.

        Raises
        ------
        KeyError
            If *name* is not found.
        """
        if name not in self._module_dict:
            raise KeyError(
                f"Transform '{name}' not found in ComposeTransform"
            )
        transform = self._module_dict.pop(name)  # remove from dict
        self._names.remove(name)
        self._rebuild_module_list()              # resync ModuleList
        return transform

    def get_transform(self, name: str) -> nn.Module:
        """Return the transform registered under *name*."""
        if name not in self._module_dict:
            raise KeyError(f"Transform '{name}' not found in ComposeTransform")
        return self._module_dict[name]

    def get_transform_names(self) -> list[str]:
        """Return an ordered copy of the transform name list."""
        return list(self._names)

    def to_sequential(self) -> nn.Sequential:
        """
        Export the current pipeline as an ``nn.Sequential``.

        Useful for inference / JIT compilation where the full manager
        API is not needed.  The returned ``nn.Sequential`` shares the
        same module objects (not copies).

        Returns
        -------
        nn.Sequential
        """
        return nn.Sequential(
            OrderedDict(zip(self._names, self._module_list))
        )

    # ------------------------------------------------------------------
    # Forward
    # ------------------------------------------------------------------

    def forward(self, x: Any) -> Any:
        """
        Apply all transform sequentially.

        Iterates ``_module_list`` directly — no intermediate
        ``nn.Sequential`` cache, so add/del operations never cause
        stale-pipeline bugs.

        Parameters
        ----------
        x : Any
            Input data.

        Returns
        -------
        Any
            Transformed output.
        """
        x = self._prepare_tensor(x)
        for transform in self._module_list:
            x = transform(x)
        return x

    def forward_debug(self, x: Any) -> Any:
        """
        Apply transform sequentially, printing shape info at each step.

        Useful for diagnosing shape mismatches during development.

        Parameters
        ----------
        x : Any
            Input data.

        Returns
        -------
        Any
            Transformed output.
        """
        x = self._prepare_tensor(x)
        for name, transform in zip(self._names, self._module_list):
            x = transform(x)
            shape = getattr(x, 'shape', type(x).__name__)
            print(f"  [{name}] → {shape}")
        return x

    # ------------------------------------------------------------------
    # Dunder helpers
    # ------------------------------------------------------------------

    def __len__(self) -> int:
        return len(self._module_list)

    def __getitem__(self, key: Union[str, int]) -> nn.Module:
        """
        Retrieve a transform by name (str) or position (int).

        Parameters
        ----------
        key : str or int
            Name or zero-based index of the transform.

        Returns
        -------
        nn.Module
        """
        if isinstance(key, str):
            return self.get_transform(key)
        if isinstance(key, int):
            return self._module_list[key]
        raise TypeError(
            f"Key must be str or int, got {type(key).__name__!r}"
        )

    def __contains__(self, name: str) -> bool:
        """Support ``'scale' in pipe`` checks."""
        return name in self._module_dict

    def __iter__(self):
        """Iterate over (name, transform) pairs in pipeline order."""
        return zip(self._names, self._module_list)

    def __repr__(self) -> str:
        lines = [f"{self.__class__.__name__}("]
        for name, t in zip(self._names, self._module_list):
            lines.append(f"  ({name}): {t}")
        lines.append(")")
        return "\n".join(lines)