# -*- coding: utf-8 -*-
"""
List transform manager — route list/tuple items through different pipelines.

When a dataset returns ``(image, mask, label)`` as a tuple, the list
manager routes each element through its designated transform.

Transforms are stored in ``nn.ModuleDict`` so that ``accelerate.prepare()``
and ``.to(device)`` propagate to all children automatically.
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence, Tuple, Union

import torch
import torch.nn as nn
from torch import Tensor

from ..base import BaseTransformManager


__all__ = ['ListTransformWrapper', 'ListTransformManager']


@dataclass
class ListTransformWrapper:
    """
    Configuration wrapper for transform in :class:`ListTransformManager`.

    Parameters
    ----------
    priority : int
        Execution order — lower values run first. Default: 0.
    input_indices : Tuple[int, ...]
        Positional indices to select from the input list/tuple.
        Selected values are passed as positional args to the transform.
        Default: empty tuple (pass all items).
    output_indices : Tuple[int, ...] or None
        Positions in the result list where outputs are written back.
        Must match the number of outputs.  If ``None``, same as
        *input_indices*.  Default: None.

    Examples
    --------
    Read element 0, transform it, write result back to element 0:

    >>> ListTransformWrapper(input_indices=(0,))

    Read elements 0 and 2, pass as two positional args:

    >>> ListTransformWrapper(input_indices=(0, 2))

    Read from index 0 but write result to index 1 (cross-routing):

    >>> ListTransformWrapper(input_indices=(0,), output_indices=(1,))

    Priority ordering — lower runs first:

    >>> ListTransformWrapper(priority=0, input_indices=(0,))  # runs first
    >>> ListTransformWrapper(priority=1, input_indices=(0,))  # runs second
    """
    priority: int = 0
    input_indices: Union[int,Tuple[int, ...]] = field(default_factory=tuple)
    output_indices: Optional[Union[int,Tuple[int, ...]]] = None

    def __post_init__(self):
        if isinstance(self.input_indices, int):
            self.input_indices = (self.input_indices,)
        if isinstance(self.output_indices, int):
            self.output_indices = (self.output_indices,)


class ListTransformManager(BaseTransformManager):
    """
    Index-based transform manager for list / tuple inputs.

    Routes elements of a list/tuple input through designated transform,
    collecting results back into the same structure.

    Implementation notes
    --------------------
    * Transforms are stored in ``nn.ModuleDict`` — PyTorch tracks them
      as child modules, so ``model.to(device)``, ``model.parameters()``,
      ``accelerate.prepare(model)`` all work automatically.
    * Execution order is cached in ``_sorted_entries`` (a list of
      ``(name, transform, wrapper)`` tuples) and only rebuilt on
      ``add_transform`` / ``del_transform`` — no per-forward sorting
      or dict lookups.
    * When ``detach=False`` and ``clone=False`` (default), tensor
      preparation is completely elided (zero overhead).

    Parameters
    ----------
    detach : bool
        Detach input tensors. Default: False.
    clone : bool
        Clone input tensors. Default: False.

    Examples
    --------
    Basic index routing — different transform per position:

    >>> import (
    ...     ListTransformManager, ListTransformWrapper
    ... )
    >>> manager = ListTransformManager()
    >>> manager.add_transform(
    ...     'scale_img',
    ...     MinMaxScale(0.0, 255.0),
    ...     wrapper=ListTransformWrapper(input_indices=(0,)),
    ... )
    >>> manager.add_transform(
    ...     'cast_mask',
    ...     ToDtype(torch.long),
    ...     wrapper=ListTransformWrapper(input_indices=(1,)),
    ... )
    >>> result = manager([img_tensor, mask_tensor, label])
    >>> # result = [scaled_img, long_mask, label]

    Cross-routing — read from one index, write to another:

    >>> manager = ListTransformManager()
    >>> manager.add_transform(
    ...     'copy_double',
    ...     DoubleTransform(),
    ...     wrapper=ListTransformWrapper(
    ...         input_indices=(0,),
    ...         output_indices=(1,),
    ...     ),
    ... )
    >>> result = manager([tensor([3.0]), tensor([0.0])])
    >>> # result[0] unchanged, result[1] = tensor([6.0])

    Multi-input — pass two elements as positional args:

    >>> manager = ListTransformManager()
    >>> manager.add_transform(
    ...     'add',
    ...     AddTransform(),
    ...     wrapper=ListTransformWrapper(
    ...         input_indices=(0, 1),
    ...         output_indices=(2,),
    ...     ),
    ... )
    >>> result = manager([tensor([1.0]), tensor([2.0]), tensor([0.0])])
    >>> # result[2] = tensor([3.0])
    """

    def __init__(self, detach: bool = False, clone: bool = False):
        super().__init__(detach=detach, clone=clone)
        # nn.ModuleDict — registered as submodule for automatic device
        # transfer / parameter collection
        self._transforms = nn.ModuleDict()
        # Wrapper metadata (not nn.Modules, so stored separately)
        self._wrappers: Dict[str, ListTransformWrapper] = {}
        # Pre-computed execution plan — avoids dict lookups on every
        # forward call.
        self._sorted_entries: List[Tuple[str, nn.Module, ListTransformWrapper]] = []

    def _rebuild_sorted(self) -> None:
        """Rebuild the cached priority-sorted execution plan."""
        names = sorted(
            self._transforms.keys(),
            key=lambda n: (self._wrappers[n].priority, n),
        )
        self._sorted_entries = [
            (n, self._transforms[n], self._wrappers[n]) for n in names
        ]

    def add_transform(
        self,
        name: str,
        transform: nn.Module,
        wrapper: Optional[ListTransformWrapper] = None,
    ) -> None:
        """
        Register a named transform with optional index-routing wrapper.

        Parameters
        ----------
        name : str
            Unique name for the transform.
        transform : nn.Module
            Transform module to register.
        wrapper : ListTransformWrapper or None
            Index routing configuration.  Defaults to an empty wrapper
            (no index selection — all items passed).

        Raises
        ------
        ValueError
            If *name* is already registered.
        """
        if name in self._transforms:
            raise ValueError(
                f"Transform '{name}' already exists in ListTransformManager"
            )
        if wrapper is None:
            wrapper = ListTransformWrapper()
        self._transforms[name] = transform
        self._wrappers[name] = wrapper
        self._rebuild_sorted()

    def forward(self, data: Sequence[Any]) -> list:
        """
        Apply transform to a list/tuple input, returning a list.

        Each transform receives the elements selected by its wrapper's
        ``input_indices`` and writes results back at ``output_indices``.
        Elements not targeted by any transform pass through unchanged.

        Parameters
        ----------
        data : Sequence[Any]
            Input list or tuple.

        Returns
        -------
        list
            Output list with transformed elements.
        """
        if not self._sorted_entries:
            return list(data)

        result = list(data)

        # Prepare tensors in-place (single pass)
        if self._needs_prepare:
            for i, item in enumerate(result):
                if isinstance(item, Tensor):
                    result[i] = self._prepare_tensor(item)

        for _name, transform, wrapper in self._sorted_entries:
            input_idx = wrapper.input_indices

            # --- gather ---
            if input_idx:
                if len(input_idx) == 1:
                    # Fast path: single index — no list allocation
                    output = transform(result[input_idx[0]])
                    outputs = (output,)
                else:
                    selected = [result[i] for i in input_idx]
                    output = transform(*selected)
                    outputs = (
                        output if isinstance(output, (list, tuple))
                        else (output,)
                    )
            else:
                # No indices — pass all items
                output = transform(*result)
                outputs = (
                    output if isinstance(output, (list, tuple))
                    else (output,)
                )

            # --- scatter ---
            out_idx = wrapper.output_indices or input_idx
            if out_idx:
                for idx, val in zip(out_idx, outputs):
                    result[idx] = val
            elif len(outputs) == len(result):
                result = list(outputs)
            else:
                raise ValueError(f"Not set output_indices and input_indices, and len(outputs) != len(result)")

        return result

    def del_transform(self, name: str) -> None:
        """
        Remove transform *name*.

        Raises
        ------
        KeyError
            If *name* is not registered.
        """
        if name not in self._transforms:
            raise KeyError(
                f"Transform '{name}' not found in ListTransformManager"
            )
        del self._transforms[name]
        del self._wrappers[name]
        self._rebuild_sorted()

    def get_transform_names(self) -> list:
        """Return all registered transform names in priority order."""
        return [name for name, _, _ in self._sorted_entries]
