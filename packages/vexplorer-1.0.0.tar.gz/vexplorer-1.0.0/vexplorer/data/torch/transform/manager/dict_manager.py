# -*- coding: utf-8 -*-
"""
Dict transform manager — apply different transform pipelines to different
keys of a dict input.

The most common use-case: a dataset sample is a dict like
``{'image': tensor, 'mask': tensor, 'label': tensor}`` and each key
needs a different transform pipeline.

Transforms are stored in ``nn.ModuleDict`` so that ``accelerate.prepare()``
and ``.to(device)`` propagate to all children automatically.
"""

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple, Union

import torch
import torch.nn as nn
from torch import Tensor

from ..base import BaseTransformManager


__all__ = ['DictTransformWrapper', 'DictTransformManager']


@dataclass
class DictTransformWrapper:
    """
    Configuration wrapper for transform in :class:`DictTransformManager`.

    Provides four routing modes via two pairs of mutually exclusive
    options:

    **Input routing** (pick at most one):

    * *input_keys* — positional: ``transform(data[k1], data[k2], …)``
    * *input_map*  — keyword:    ``transform(param1=data[k1], …)``
    * neither      — fallback:   ``transform(data)`` (whole dict)

    **Output routing** (pick at most one):

    * *output_keys* — positional: store output(s) under given key(s)
    * *output_map*  — keyword:    map transform output dict → result keys
    * neither       — fallback:   infer from input routing or transform name

    Parameters
    ----------
    priority : int
        Execution order — lower values run first.  Default: 0.
    input_map : Dict[str, str] or None
        Maps manager-side dict keys → transform keyword argument names.
        Example: ``{'image': 'x'}`` passes ``data['image']`` as
        ``transform(x=…)``.  Mutually exclusive with *input_keys*.
    input_keys : str or List[str] or None
        Manager-side dict key(s) whose values are passed as positional
        arguments to the transform.  A single string is treated as a
        one-element list.  Mutually exclusive with *input_map*.
    output_map : Dict[str, str] or None
        Maps transform output dict keys → manager-side dict keys.
        The transform must return a dict.  Mutually exclusive with
        *output_keys*.
    output_keys : str or List[str] or None
        Manager-side dict key(s) under which the transform's positional
        output(s) are stored.  A single string stores the whole output
        under that key.  A list expects the output to be a sequence and
        maps each element to the corresponding key.  Mutually exclusive
        with *output_map*.

    Raises
    ------
    ValueError
        If both *input_map* and *input_keys* are set.
    ValueError
        If both *output_map* and *output_keys* are set.

    Examples
    --------
    **input_keys + output_keys** (most common — simple positional I/O):

    >>> # Read data['image'], pass as positional arg, write back to 'image'
    >>> DictTransformWrapper(input_keys='image', output_keys='image')

    **input_keys (multiple) + output_keys**:

    >>> # Read two keys, pass as two positional args, store result
    >>> DictTransformWrapper(
    ...     input_keys=['pred', 'target'],
    ...     output_keys='loss',
    ... )

    **input_map + output_keys** (keyword routing):

    >>> # Pass data['pred'] as kwarg ``input``, data['gt'] as ``target``
    >>> DictTransformWrapper(
    ...     input_map={'pred': 'input', 'gt': 'target'},
    ...     output_keys='loss',
    ... )

    **input_keys + output_map** (dict output routing):

    >>> # Transform returns {'pos': …, 'neg': …}, map to result keys
    >>> DictTransformWrapper(
    ...     input_keys='features',
    ...     output_map={'pos': 'positive', 'neg': 'negative'},
    ... )

    **input_keys + output_keys (multi-output)**:

    >>> # Transform returns (mean, std) tuple, store each separately
    >>> DictTransformWrapper(
    ...     input_keys='data',
    ...     output_keys=['mean', 'std'],
    ... )

    **Priority ordering**:

    >>> DictTransformWrapper(priority=0, input_keys='x', output_keys='x')
    >>> DictTransformWrapper(priority=1, input_keys='x', output_keys='x')
    >>> # priority=0 runs first
    """
    priority: int = 0
    # Input routing (mutually exclusive)
    input_map: Optional[Dict[str, str]] = None
    input_keys: Optional[Union[str, List[str]]] = None
    # Output routing (mutually exclusive)
    output_map: Optional[Dict[str, str]] = None
    output_keys: Optional[Union[str, List[str]]] = None

    def __post_init__(self):
        if self.input_map is not None and self.input_keys is not None:
            raise ValueError(
                "Cannot set both 'input_map' and 'input_keys' — they are "
                "mutually exclusive."
            )
        if self.output_map is not None and self.output_keys is not None:
            raise ValueError(
                "Cannot set both 'output_map' and 'output_keys' — they are "
                "mutually exclusive."
            )
        # Normalise input_keys to list
        if isinstance(self.input_keys, str):
            self.input_keys = [self.input_keys]
        # Normalise output_keys to list
        if isinstance(self.output_keys, str):
            self.output_keys = [self.output_keys]


class DictTransformManager(BaseTransformManager):
    """
    Dict-based transform manager with key routing and per-key pipelines.

    Designed for the common pattern where data samples are dictionaries
    and different keys need different transform pipelines.

    Implementation notes
    --------------------
    * Transforms are stored in ``nn.ModuleDict`` — PyTorch tracks them
      as child modules, so ``model.to(device)``, ``model.parameters()``,
      ``accelerate.prepare(model)`` all work automatically.
    * Execution order is cached in ``_sorted_entries`` (a list of
      ``(name, transform, wrapper)`` tuples) and only rebuilt on
      ``add_transform`` / ``del_transform`` — no per-forward sorting
      or dict lookups.
    * When ``detach=False`` and ``clone=False`` (default), tensor
      preparation is completely elided (zero overhead).
    * Keys not targeted by any transform pass through unchanged.

    Parameters
    ----------
    detach : bool
        Detach input tensors. Default: False.
    clone : bool
        Clone input tensors. Default: False.

    Examples
    --------
    **input_keys + output_keys** — simplest positional routing:

    >>> import (
    ...     DictTransformManager, DictTransformWrapper
    ... )
    >>> manager = DictTransformManager()
    >>> manager.add_transform(
    ...     'scale_image',
    ...     MinMaxScale(0.0, 255.0),
    ...     wrapper=DictTransformWrapper(
    ...         input_keys='image',
    ...         output_keys='image',
    ...     ),
    ... )
    >>> manager.add_transform(
    ...     'cast_mask',
    ...     ToDtype(torch.long),
    ...     wrapper=DictTransformWrapper(
    ...         input_keys='mask',
    ...         output_keys='mask',
    ...     ),
    ... )
    >>> sample = {'image': img_tensor, 'mask': mask_tensor, 'label': 0}
    >>> result = manager(sample)
    >>> # result = {'image': scaled_img, 'mask': long_mask, 'label': 0}

    **input_map** — keyword routing (transform expects named params):

    >>> manager = DictTransformManager()
    >>> manager.add_transform(
    ...     'loss',
    ...     CrossEntropyLoss(),
    ...     wrapper=DictTransformWrapper(
    ...         input_map={'logits': 'input', 'labels': 'target'},
    ...         output_keys='ce_loss',
    ...     ),
    ... )
    >>> result = manager({'logits': pred, 'labels': gt})
    >>> # result['ce_loss'] = CrossEntropyLoss(input=pred, target=gt)

    **output_map** — transform returns a dict, remap its keys:

    >>> manager = DictTransformManager()
    >>> manager.add_transform(
    ...     'stats',
    ...     ComputeStats(),       # returns {'mu': …, 'sigma': …}
    ...     wrapper=DictTransformWrapper(
    ...         input_keys='data',
    ...         output_map={'mu': 'mean', 'sigma': 'std'},
    ...     ),
    ... )
    >>> result = manager({'data': tensor})
    >>> # result['mean'], result['std'] populated

    **output_keys (multiple)** — unpack tuple output:

    >>> manager = DictTransformManager()
    >>> manager.add_transform(
    ...     'split',
    ...     SplitTransform(),     # returns (pos, neg)
    ...     wrapper=DictTransformWrapper(
    ...         input_keys='features',
    ...         output_keys=['positive', 'negative'],
    ...     ),
    ... )

    **Priority chaining** — double then add one to same key:

    >>> manager = DictTransformManager()
    >>> manager.add_transform('double', Double(),
    ...     wrapper=DictTransformWrapper(priority=0, input_keys='x', output_keys='x'))
    >>> manager.add_transform('add_one', AddOne(),
    ...     wrapper=DictTransformWrapper(priority=1, input_keys='x', output_keys='x'))
    >>> result = manager({'x': tensor([3.0])})
    >>> # x: 3 → *2=6 → +1=7
    """

    def __init__(self, detach: bool = False, clone: bool = False):
        super().__init__(detach=detach, clone=clone)
        # nn.ModuleDict — registered as submodule for automatic device
        # transfer / parameter collection
        self._transforms = nn.ModuleDict()
        # Wrapper metadata (not nn.Modules, so stored separately)
        self._wrappers: Dict[str, DictTransformWrapper] = {}
        # Pre-computed execution plan — list of (name, transform, wrapper)
        # tuples in priority order.  Eliminates dict lookups on every
        # forward call.
        self._sorted_entries: List[Tuple[str, nn.Module, DictTransformWrapper]] = []

    def _rebuild_sorted(self) -> None:
        """Rebuild the cached priority-sorted execution plan."""
        names = sorted(
            self._transforms.keys(),
            key=lambda n: (self._wrappers[n].priority, n),
        )
        self._sorted_entries = [
            (n, self._transforms[n], self._wrappers[n]) for n in names
        ]

    def add_transform(
        self,
        name: str,
        transform: nn.Module,
        wrapper: Optional[DictTransformWrapper] = None,
    ) -> None:
        """
        Register a named transform with optional routing wrapper.

        Parameters
        ----------
        name : str
            Unique name for the transform.
        transform : nn.Module
            Transform module to register.
        wrapper : DictTransformWrapper or None
            Routing configuration.  Defaults to an empty wrapper
            (no routing — transform receives entire dict).

        Raises
        ------
        ValueError
            If *name* is already registered.
        """
        if name in self._transforms:
            raise ValueError(
                f"Transform '{name}' already exists in DictTransformManager"
            )
        if wrapper is None:
            wrapper = DictTransformWrapper()
        self._transforms[name] = transform
        self._wrappers[name] = wrapper
        self._rebuild_sorted()

    # ------------------------------------------------------------------
    # Input / output dispatch (called from forward)
    # ------------------------------------------------------------------

    def _gather_input(
        self,
        wrapper: DictTransformWrapper,
        data: dict,
    ):
        """
        Gather input for a single transform based on wrapper config.

        Returns ``(args, kwargs)`` ready for ``transform(*args, **kwargs)``.
        """
        if wrapper.input_map is not None:
            # Keyword argument routing
            kwargs: Dict[str, Any] = {}
            for mgr_key, tf_key in wrapper.input_map.items():
                if mgr_key not in data:
                    raise KeyError(
                        f"Key '{mgr_key}' not found in input dict. "
                        f"Available: {list(data.keys())}"
                    )
                value = data[mgr_key]
                if isinstance(value, Tensor):
                    value = self._prepare_tensor(value)
                kwargs[tf_key] = value
            return (), kwargs

        if wrapper.input_keys is not None:
            # Positional argument routing
            args = []
            for key in wrapper.input_keys:
                if key not in data:
                    raise KeyError(
                        f"Key '{key}' not found in input dict. "
                        f"Available: {list(data.keys())}"
                    )
                value = data[key]
                if isinstance(value, Tensor):
                    value = self._prepare_tensor(value)
                args.append(value)
            return tuple(args), {}

        # No routing — pass entire dict as single positional arg
        return (data,), {}

    @staticmethod
    def _scatter_output(
        wrapper: DictTransformWrapper,
        name: str,
        output: Any,
        result: dict,
    ) -> None:
        """
        Write transform output back into *result* dict based on wrapper.
        """
        if wrapper.output_map is not None:
            for tf_key, mgr_key in wrapper.output_map.items():
                result[mgr_key] = output[tf_key]
            return

        if wrapper.output_keys is not None:
            keys = wrapper.output_keys
            if len(keys) == 1:
                result[keys[0]] = output
            else:
                for key, val in zip(keys, output):
                    result[key] = val
            return

        # No output routing — fallback heuristics
        if wrapper.input_keys is not None and len(wrapper.input_keys) == 1:
            result[wrapper.input_keys[0]] = output
        elif wrapper.input_map is not None:
            first_mgr_key = next(iter(wrapper.input_map.keys()))
            result[first_mgr_key] = output
        elif name in result:
            result[name] = output
        elif isinstance(output, dict):
            result.update(output)

    # ------------------------------------------------------------------
    # Forward
    # ------------------------------------------------------------------

    def forward(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Apply transform to a dict input, returning a new dict.

        Untouched keys are passed through via a shallow copy.
        Transforms execute in priority order (lowest first, then
        alphabetical for equal priority).

        Parameters
        ----------
        data : Dict[str, Any]
            Input dictionary (e.g. a dataset sample).

        Returns
        -------
        Dict[str, Any]
            Output dictionary with transformed values.
        """
        if not self._sorted_entries:
            return data

        result = dict(data)  # shallow copy — untouched keys pass through

        for name, transform, wrapper in self._sorted_entries:
            args, kwargs = self._gather_input(wrapper, result)
            output = transform(*args, **kwargs)
            self._scatter_output(wrapper, name, output, result)

        return result

    def del_transform(self, name: str) -> None:
        """
        Remove transform *name*.

        Raises
        ------
        KeyError
            If *name* is not registered.
        """
        if name not in self._transforms:
            raise KeyError(
                f"Transform '{name}' not found in DictTransformManager"
            )
        del self._transforms[name]
        del self._wrappers[name]
        self._rebuild_sorted()

    def get_transform_names(self) -> list:
        """Return all registered transform names in priority order."""
        return [name for name, _, _ in self._sorted_entries]

    def build(self):
        pass