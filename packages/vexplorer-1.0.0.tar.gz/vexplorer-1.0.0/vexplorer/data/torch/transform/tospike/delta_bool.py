# -*- coding: utf-8 -*-
"""Delta-boolean change detection transform."""

import torch
from torch import Tensor

from ..base import BaseTransform

__all__ = ['DeltaBool']


class DeltaBool(BaseTransform):
    """
    Compute boolean delta masks along a time dimension.

    Given input of shape ``[B, T, C, *spatial]``, computes the difference
    along the T dimension and produces masks for values exceeding a
    threshold (positive and negative), concatenated along the C dimension.

    Output shape: ``[B, T-1, 2*C, *spatial]``

    Parameters
    ----------
    threshold : float
        Magnitude threshold for change detection. Default: 0.23.
    time_dim : int
        Dimension along which to compute differences. Default: 1.
    channel_dim : int
        Dimension along which to concatenate boolean masks. Default: 2.
    """

    def __init__(
        self,
        threshold: float = 0.23,
        time_dim: int = 1,
        channel_dim: int = 2,
    ):
        super().__init__()
        self.threshold = threshold
        self.time_dim = time_dim
        self.channel_dim = channel_dim

    def forward(self, x: Tensor) -> Tensor:
        diff = torch.diff(x, n=1, dim=self.time_dim)
        mask_gt = diff > self.threshold
        mask_lt = diff < -self.threshold
        return torch.cat([mask_gt, mask_lt], dim=self.channel_dim).to(x.device)

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(threshold={self.threshold})"
