# -- coding: utf-8 --
"""Min-max scaling transform."""
from typing import Union, Optional
import torch
from torch import Tensor
from ..base import BaseTransform

__all__ = ['MinMaxScale', 'InverseMinMaxScale']


class MinMaxScale(BaseTransform):
    """Scale tensor values to [0, 1] range using fixed min/max bounds.

    ``output = (input - min_val) / (fixed_denominator or delta * scale_factor)``

    NaN values are replaced with zero before scaling.

    Parameters
    ----------
    min_val : float
        Minimum value of the original range.
    max_val : float
        Maximum value of the original range.
    fixed_denominator : float, optional
        If provided, replaces the computed delta as the denominator.
    scale_factor : float, optional
        Multiplier applied to delta (ignored if fixed_denominator is set). Default is 1.0.
    """

    def __init__(
            self,
            min_val: float,
            max_val: float,
            fixed_denominator: Optional[float] = None,
            scale_factor: float = 1.0,
    ):
        super().__init__()
        self.min_val = min_val
        self.max_val = max_val
        self.fixed_denominator = fixed_denominator
        self.scale_factor = scale_factor

        delta = max_val - min_val
        if fixed_denominator is not None:
            self.denominator = fixed_denominator
        else:
            self.denominator = delta * scale_factor

        if self.denominator == 0:
            raise ValueError("denominator cannot be zero")


    def forward(self, x: Tensor) -> Tensor:
        return (x - self.min_val) / self.denominator

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}("
            f"min_val={self.min_val}, "
            f"max_val={self.max_val}, "
            f"fixed_denominator={self.fixed_denominator}, "
            f"scale_factor={self.scale_factor})"
        )


class InverseMinMaxScale(BaseTransform):
    """Inverse of Min-max scaling transform.

    Restores tensor values from scaled range back to their original range.
    ``output = input * (fixed_denominator or delta * scale_factor) + min_val``

    Parameters
    ----------
    min_val : float
        Minimum value of the original range.
    max_val : float
        Maximum value of the original range.
    fixed_denominator : float, optional
        If provided, replaces the computed delta as the multiplier.
    scale_factor : float, optional
        Multiplier applied to delta (ignored if fixed_denominator is set). Default is 1.0.
    """

    def __init__(
            self,
            min_val: float,
            max_val: float,
            fixed_denominator: Optional[float] = None,
            scale_factor: float = 1.0,
    ):
        super().__init__()
        self.min_val = min_val
        self.max_val = max_val
        self.fixed_denominator = fixed_denominator
        self.scale_factor = scale_factor

        delta = max_val - min_val
        if fixed_denominator is not None:
            self.denominator = fixed_denominator
        else:
            self.denominator = delta * scale_factor

        if self.denominator == 0:
            raise ValueError("denominator cannot be zero")

    def forward(self, x: Tensor) -> Tensor:
        # 反归一化公式：x_ori = x_scaled * denominator + min_val
        return x * self.denominator + self.min_val

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}("
            f"min_val={self.min_val}, "
            f"max_val={self.max_val}, "
            f"fixed_denominator={self.fixed_denominator}, "
            f"scale_factor={self.scale_factor})"
        )