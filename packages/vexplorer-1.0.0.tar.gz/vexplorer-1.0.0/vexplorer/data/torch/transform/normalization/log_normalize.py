# -*- coding: utf-8 -*-
"""Logarithmic normalization transform."""

import torch
from torch import Tensor

from ..base import BaseTransform

# 更新 __all__ 列表，暴露所有 4 个类
__all__ = [
    'Log10',
    'Log10Normalize',
    'InverseLog10',
    'InverseLog10Normalize'
]


class Log10(BaseTransform):
    """
    Apply log10 transform, optionally with an epsilon for numerical stability.

    Parameters
    ----------
    eps : float or None
        Small constant added before log10.  ``None`` disables.
        Default: 1e-12.
    """

    def __init__(self, eps: float = 1e-12):
        super().__init__()
        self.eps = eps

    def forward(self, x: Tensor) -> Tensor:
        if self.eps:
            return torch.log10(x + self.eps)
        return torch.log10(x)

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(eps={self.eps})"


class InverseLog10(BaseTransform):
    """
    Inverse of Log10 transform.

    Restores tensor values using exponential base 10.
    ``output = 10^input - eps``

    Parameters
    ----------
    eps : float or None
        Small constant subtracted after exponentiation. ``None`` disables.
        Default: 1e-12.
    """

    def __init__(self, eps: float = 1e-12):
        super().__init__()
        self.eps = eps

    def forward(self, x: Tensor) -> Tensor:
        # 10.0 ** x 也可以，但 torch.pow 显式调用或 10.0**x 在 PyTorch 中都支持
        # 为了稳定性和与张量操作对齐，使用 torch.pow
        if self.eps:
            return torch.pow(10.0, x) - self.eps
        return torch.pow(10.0, x)

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(eps={self.eps})"


class Log10Normalize(BaseTransform):
    """
    Apply ``(log10(x) + offset) / scale``.

    Default parameters map the range [1e-4, 100] → [0, 1]::

        (log10(x) + 4) / 6

    Parameters
    ----------
    offset : float
        Added to log10 result. Default: 4.0.
    scale : float
        Divides the shifted result. Default: 6.0.
    """

    def __init__(self, offset: float = 4.0, scale: float = 6.0):
        super().__init__()
        self.offset = offset
        self.scale = scale

    def forward(self, x: Tensor) -> Tensor:
        return (torch.log10(x) + self.offset) / self.scale

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(offset={self.offset}, scale={self.scale})"


class InverseLog10Normalize(BaseTransform):
    """
    Inverse of Log10Normalize transform.

    Restores tensor values from the scaled logarithmic range.
    ``output = 10 ^ (input * scale - offset)``

    Parameters
    ----------
    offset : float
        Offset used during the original Log10Normalize. Default: 4.0.
    scale : float
        Scale used during the original Log10Normalize. Default: 6.0.
    """

    def __init__(self, offset: float = 4.0, scale: float = 6.0):
        super().__init__()
        self.offset = offset
        self.scale = scale

    def forward(self, x: Tensor) -> Tensor:
        # 提取指数部分: x_scaled * scale - offset
        exponent = x * self.scale - self.offset
        return torch.pow(10.0, exponent)

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(offset={self.offset}, scale={self.scale})"



