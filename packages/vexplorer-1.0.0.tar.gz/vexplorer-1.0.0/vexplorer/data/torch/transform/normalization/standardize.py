# -*- coding: utf-8 -*-
"""Standardization transform (mean/std normalization)."""

from typing import Optional, Sequence, Union

import torch
from torch import Tensor

from ..base import BaseTransform

# 更新了 __all__ 列表，暴露所有 4 个类
__all__ = [
    'Standardize',
    'ChannelNormalize',
    'InverseStandardize',
    'InverseChannelNormalize'
]


class Standardize(BaseTransform):
    """
    Standardize tensor using pre-computed channel-wise mean and std.

    ``output = (input - mean) / std``

    Parameters
    ----------
    mean : Sequence[float]
        Per-channel means.
    std : Sequence[float]
        Per-channel standard deviations.
    device : str or None
        Device to place mean/std tensors on. Default: None (CPU).
    """

    def __init__(
            self,
            mean: Sequence[float],
            std: Sequence[float],
            device: Optional[str] = None,
    ):
        super().__init__()
        dev = torch.device(device) if device else None
        self.register_buffer('mean', torch.tensor(mean, dtype=torch.float32, device=dev))
        self.register_buffer('std', torch.tensor(std, dtype=torch.float32, device=dev))

    def forward(self, x: Tensor) -> Tensor:
        return (x - self.mean) / self.std

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}("
            f"mean={self.mean.tolist()}, std={self.std.tolist()})"
        )


class InverseStandardize(BaseTransform):
    """
    Inverse of standardization transform.

    Restores tensor values using pre-computed channel-wise mean and std.
    ``output = input * std + mean``

    Parameters
    ----------
    mean : Sequence[float]
        Per-channel means used during original standardization.
    std : Sequence[float]
        Per-channel standard deviations used during original standardization.
    device : str or None
        Device to place mean/std tensors on. Default: None (CPU).
    """

    def __init__(
            self,
            mean: Sequence[float],
            std: Sequence[float],
            device: Optional[str] = None,
    ):
        super().__init__()
        dev = torch.device(device) if device else None
        self.register_buffer('mean', torch.tensor(mean, dtype=torch.float32, device=dev))
        self.register_buffer('std', torch.tensor(std, dtype=torch.float32, device=dev))

    def forward(self, x: Tensor) -> Tensor:
        # 反标准化公式：x_ori = x_norm * std + mean
        return x * self.std + self.mean

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}("
            f"mean={self.mean.tolist()}, std={self.std.tolist()})"
        )


class ChannelNormalize(BaseTransform):
    """
    Channel-wise normalization with broadcasting for N-D tensors.

    Supports 3-D ``[C, *spatial]``, 4-D ``[B, C, *spatial]``,
    5-D ``[B, T, C, *spatial]`` layouts.

    Parameters
    ----------
    mean : Sequence[float]
        Per-channel means.
    std : Sequence[float]
        Per-channel standard deviations.
    spatial_ndim : int
        Number of spatial dimensions (2 for 2-D, 3 for 3-D).
    has_batch : bool
        Whether a batch dimension is present.
    has_time : bool
        Whether a time dimension is present (adds one leading dim).
    device : str or None
        Device. Default: None.
    """

    def __init__(
            self,
            mean: Sequence[float],
            std: Sequence[float],
            spatial_ndim: int = 3,
            has_batch: bool = False,
            has_time: bool = False,
            device: Optional[str] = None,
            mean_std_dtype: Optional[torch.dtype] = torch.float32,
    ):
        super().__init__()
        dev = torch.device(device) if device else None
        mean_t = torch.tensor(mean, dtype=mean_std_dtype, device=dev)
        std_t = torch.tensor(std, dtype=mean_std_dtype, device=dev)

        # Build shape: optional batch, optional time, C, then spatial 1s
        shape = []
        if has_batch:
            shape.append(1)
        if has_time:
            shape.append(1)
        shape.append(-1)  # channel dim
        shape.extend([1] * spatial_ndim)

        self.register_buffer('mean', mean_t.view(*shape))
        self.register_buffer('std', std_t.view(*shape))

    def forward(self, x: Tensor) -> Tensor:
        return (x - self.mean) / self.std


class InverseChannelNormalize(BaseTransform):
    """
    Inverse of channel-wise normalization with broadcasting for N-D tensors.

    Supports 3-D ``[C, *spatial]``, 4-D ``[B, C, *spatial]``,
    5-D ``[B, T, C, *spatial]`` layouts.
    ``output = input * std + mean``

    Parameters
    ----------
    mean : Sequence[float]
        Per-channel means used during original normalization.
    std : Sequence[float]
        Per-channel standard deviations used during original normalization.
    spatial_ndim : int
        Number of spatial dimensions (2 for 2-D, 3 for 3-D).
    has_batch : bool
        Whether a batch dimension is present.
    has_time : bool
        Whether a time dimension is present (adds one leading dim).
    device : str or None
        Device. Default: None.
    """

    def __init__(
            self,
            mean: Sequence[float],
            std: Sequence[float],
            spatial_ndim: int = 3,
            has_batch: bool = False,
            has_time: bool = False,
            device: Optional[str] = None,
            mean_std_dtype: Optional[torch.dtype] = torch.float32,
    ):
        super().__init__()
        dev = torch.device(device) if device else None
        mean_t = torch.tensor(mean, dtype=mean_std_dtype, device=dev)
        std_t = torch.tensor(std, dtype=mean_std_dtype, device=dev)

        # 同样构建用于 broadcasting 的 shape
        shape = []
        if has_batch:
            shape.append(1)
        if has_time:
            shape.append(1)
        shape.append(-1)  # channel dim
        shape.extend([1] * spatial_ndim)

        self.register_buffer('mean', mean_t.view(*shape))
        self.register_buffer('std', std_t.view(*shape))

    def forward(self, x: Tensor) -> Tensor:
        # 反向计算
        return x * self.std + self.mean


