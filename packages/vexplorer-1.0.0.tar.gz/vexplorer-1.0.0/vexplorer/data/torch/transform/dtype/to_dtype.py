# -*- coding: utf-8 -*-
"""Data type conversion transform."""

import torch
from torch import Tensor

from ..base import BaseTransform

__all__ = ['ToDtype']

DTYPE_MAP: dict[str, torch.dtype] = {
    # Float
    "float16": torch.float16,
    "float32": torch.float32,
    "float64": torch.float64,
    "half":    torch.float16,
    "float":   torch.float32,
    "double":  torch.float64,
    "bfloat16": torch.bfloat16,
    # Int
    "int8":    torch.int8,
    "int16":   torch.int16,
    "int32":   torch.int32,
    "int64":   torch.int64,
    "short":   torch.int16,
    "int":     torch.int32,
    "long":    torch.int64,
    # Other
    "bool":    torch.bool,
    "uint8":   torch.uint8,
}


class ToDtype(BaseTransform):
    """
    Cast tensor to a specified dtype.

    Parameters
    ----------
    dtype : torch.dtype | str
        Target data type. Accepts ``torch.dtype`` directly or a string alias
        such as ``"float32"``, ``"int64"``, ``"bool"``, etc.
        Default: ``torch.float32``.
    """

    def __init__(self, dtype: torch.dtype | str = torch.float32):
        super().__init__()
        self.dtype = self._parse_dtype(dtype)

    @staticmethod
    def _parse_dtype(dtype: torch.dtype | str) -> torch.dtype:
        if isinstance(dtype, torch.dtype):
            return dtype
        if isinstance(dtype, str):
            key = dtype.lower().replace(" ", "")
            if key in DTYPE_MAP:
                return DTYPE_MAP[key]
            raise ValueError(
                f"Unknown dtype string '{dtype}'. "
                f"Available options: {list(DTYPE_MAP.keys())}"
            )
        raise TypeError(f"dtype must be str or torch.dtype, got {type(dtype)}")

    def forward(self, x: Tensor) -> Tensor:
        return x.to(self.dtype)

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(dtype={self.dtype})"