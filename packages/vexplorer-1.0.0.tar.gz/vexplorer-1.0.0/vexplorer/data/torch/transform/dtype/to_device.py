# -*- coding: utf-8 -*-
"""
Device transfer transform with recursive and auto-synchronization support.
Optimized for high-performance pipelines.
"""

import torch
from torch import nn, Tensor
from typing import Any, Union, Optional

from ..base import BaseTransform

__all__ = ['ToDevice', 'AnyToDevice', 'AutoSyncDevice', 'AnyAutoSyncDevice']


class ToDevice(BaseTransform):
    """
    Cast a single Tensor to a specified device.

    Args:
        device (Union[str, torch.device]): Target device (e.g., 'cuda:0', 'cpu').
        non_blocking (bool): If True and the source is in pinned memory,
            the copy will be asynchronous with respect to the host. Default: False.
    """

    def __init__(self, device: Union[str, torch.device], non_blocking: bool = False):
        super().__init__()
        self.target_device = torch.device(device) if isinstance(device, str) else device
        self.non_blocking = non_blocking

    def forward(self, x: Tensor) -> Tensor:
        # Fast-path: return identity if device matches to avoid C++ dispatch overhead
        if x.device != self.target_device:
            return x.to(self.target_device, non_blocking=self.non_blocking)
        return x

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(device={self.target_device}, non_blocking={self.non_blocking})"


class AnyToDevice(ToDevice):
    """
    Recursively move all Tensors within nested containers (dict, list, tuple)
    to a specified device.
    """

    def forward(self, x: Any) -> Any:
        return self._move_recursive(x)

    def _move_recursive(self, x: Any) -> Any:
        if isinstance(x, Tensor):
            if x.device != self.target_device:
                return x.to(self.target_device, non_blocking=self.non_blocking)
            return x
        elif isinstance(x, dict):
            return {k: self._move_recursive(v) for k, v in x.items()}
        elif isinstance(x, (list, tuple)):
            # Preserves the original container type
            return type(x)([self._move_recursive(v) for v in x])
        return x


class AutoSyncDevice(BaseTransform):
    """
    Automatic device synchronization.

    Registers a buffer as a 'device anchor'. When the module is moved via
    .to(device), this transform automatically detects the new device and
    moves input Tensors to match it in the forward pass.
    """

    def __init__(self, device: Optional[Union[str, torch.device]] = None, non_blocking: bool = False):
        super().__init__()
        init_device = torch.device(device) if isinstance(device, str) else device
        # Buffer follows the module's device state but occupies zero memory
        self.register_buffer('_anchor', torch.empty(0, device=init_device), persistent=False)
        self.non_blocking = non_blocking

    def forward(self, x: Tensor) -> Tensor:
        target = self._anchor.device
        if x.device != target:
            return x.to(target, non_blocking=self.non_blocking)
        return x

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(current_device={self._anchor.device})"


class AnyAutoSyncDevice(AutoSyncDevice):
    """
    Recursive version of AutoSyncDevice.
    Suitable for complex batch inputs containing dictionaries or lists of Tensors.
    """

    def forward(self, x: Any) -> Any:
        return self._move_recursive(x)

    def _move_recursive(self, x: Any) -> Any:
        target = self._anchor.device
        if isinstance(x, Tensor):
            if x.device != target:
                return x.to(target, non_blocking=self.non_blocking)
            return x
        elif isinstance(x, dict):
            return {k: self._move_recursive(v) for k, v in x.items()}
        elif isinstance(x, (list, tuple)):
            return type(x)([self._move_recursive(v) for v in x])
        return x




