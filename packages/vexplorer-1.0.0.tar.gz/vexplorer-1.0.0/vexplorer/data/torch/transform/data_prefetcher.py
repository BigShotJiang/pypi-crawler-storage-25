# -*- coding: utf-8 -*-
"""
DataPrefetcher — overlap batch_transform (H2D + element-wise ops) with
forward/backward on NPU and CUDA.

Uses a dedicated stream to asynchronously execute the next micro-batch's
transform while the main stream runs forward + backward on the current batch.

Official recommendation from Huawei's training migration guide (§10.4.2):
    "在数据预处理时间较长而影响模型训练时，可以尝试预取数据，即 Data prefetcher。"

The pattern is device-agnostic:
    NPU  → torch.npu.Stream  / torch.npu.stream  / torch.npu.current_stream
    CUDA → torch.cuda.Stream / torch.cuda.stream / torch.cuda.current_stream
    CPU  → no-op (stream=None, transform runs synchronously)

Usage::

    prefetcher = DataPrefetcher(batch_transform, device)

    # Pre-transform the first micro batch
    next_inputs = prefetcher.prefetch(micro_batches[0])

    for i, mb in enumerate(micro_batches):
        prefetcher.wait()
        inputs = next_inputs
        if i + 1 < len(micro_batches):
            next_inputs = prefetcher.prefetch(micro_batches[i + 1])
        outputs = model(**inputs)
        backward(outputs)
"""

from typing import Any, Callable, Dict, Optional

import logging

logger = logging.getLogger(__name__)

__all__ = ['DataPrefetcher']


class DataPrefetcher:
    """Overlaps batch_transform with model computation via async streams.

    Parameters
    ----------
    batch_transform : callable or None
        The batch transform function. If None, acts as pass-through.
    device : torch.device or str
        Target device (e.g. 'npu:0', 'cuda:0', 'cpu').
    """

    def __init__(
        self,
        batch_transform: Optional[Callable],
        device: Any,
    ):
        self.batch_transform = batch_transform
        self.device = device
        self.stream = None
        self._stream_ctx_fn = None
        self._current_stream_fn = None

        dev_type = str(device).split(':')[0]

        if dev_type == 'npu':
            try:
                import torch_npu  # noqa: F401
                import torch
                self.stream = torch.npu.Stream()
                self._stream_ctx_fn = torch.npu.stream
                self._current_stream_fn = torch.npu.current_stream
                logger.debug("DataPrefetcher: using NPU stream")
            except (ImportError, AttributeError):
                logger.warning("DataPrefetcher: torch_npu not available, "
                               "falling back to synchronous mode")

        elif dev_type == 'cuda':
            import torch
            self.stream = torch.cuda.Stream()
            self._stream_ctx_fn = torch.cuda.stream
            self._current_stream_fn = torch.cuda.current_stream
            logger.debug("DataPrefetcher: using CUDA stream")

        else:
            logger.debug("DataPrefetcher: CPU mode (synchronous)")

    def prefetch(self, micro_batch: Dict) -> Dict:
        """Transform a micro_batch on the prefetch stream (async).

        The transform includes H2D transfer (.to(device, non_blocking=True))
        and element-wise ops (nan_to_num, clamp, normalize).

        Parameters
        ----------
        micro_batch : dict
            Raw batch dict from dataloader (tensors on CPU).

        Returns
        -------
        dict
            Transformed batch dict (tensors on device).
        """
        if self.batch_transform is None:
            return micro_batch

        if self.stream is not None:
            with self._stream_ctx_fn(self.stream):
                return self.batch_transform(micro_batch)
        else:
            return self.batch_transform(micro_batch)

    def wait(self) -> None:
        """Block the main compute stream until the prefetch is done.

        Must be called before using the prefetched data in forward().
        """
        if self.stream is not None:
            self._current_stream_fn().wait_stream(self.stream)

    @property
    def is_async(self) -> bool:
        """True if prefetching uses a separate stream."""
        return self.stream is not None
