# -*- coding: utf-8 -*-
"""Dimension permutation transform."""

from typing import Tuple

import torch
from torch import Tensor

from ..base import BaseTransform

__all__ = ['Permute']


class Permute(BaseTransform):
    """
    Permute tensor dimensions.

    Parameters
    ----------
    dims : Tuple[int, ...]
        Desired ordering of dimensions.

    Examples
    --------
    >>> t = Permute((0, 3, 1, 2))   # NHWC → NCHW
    >>> t(torch.randn(2, 8, 8, 3)).shape
    torch.Size([2, 3, 8, 8])
    """

    def __init__(self, dims: Tuple[int, ...]):
        super().__init__()
        assert isinstance(dims, tuple), "dims must be a tuple"
        self.dims = dims

    def forward(self, x: Tensor) -> Tensor:
        return torch.permute(x, self.dims)

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(dims={self.dims})"
