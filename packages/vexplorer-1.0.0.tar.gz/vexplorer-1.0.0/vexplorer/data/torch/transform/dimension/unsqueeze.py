# -*- coding: utf-8 -*-
"""Unsqueeze (add dimension) transform."""

from torch import Tensor

from ..base import BaseTransform

__all__ = ['Unsqueeze']


class Unsqueeze(BaseTransform):
    """
    Insert a tensor dimension at the given axis.

    Parameters
    ----------
    dim : int
        Position to insert the new dimension. Default: 0.
    """

    def __init__(self, dim: int = 0):
        super().__init__()
        self.dim = dim

    def forward(self, x: Tensor) -> Tensor:
        return x.unsqueeze(self.dim)

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(dim={self.dim})"
