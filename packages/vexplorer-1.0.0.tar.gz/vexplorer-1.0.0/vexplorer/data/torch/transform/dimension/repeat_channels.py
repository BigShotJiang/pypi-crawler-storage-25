# -*- coding: utf-8 -*-
"""Channel repetition transform."""

from typing import List

from torch import Tensor

from ..base import BaseTransform

__all__ = ['RepeatChannels']


class RepeatChannels(BaseTransform):
    """
    Expand/repeat tensor along specified dimensions.

    Uses :meth:`Tensor.expand`, so no new memory is allocated.

    Parameters
    ----------
    expand_sizes : List[int]
        Sizes for :meth:`Tensor.expand`.  Use ``-1`` to keep original
        size.  Example: ``[-1, 3, -1, -1]`` repeats dim-1 to size 3.
    """

    def __init__(self, expand_sizes: List[int]):
        super().__init__()
        self.expand_sizes = expand_sizes

    def forward(self, x: Tensor) -> Tensor:
        return x.expand(*self.expand_sizes)

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(expand_sizes={self.expand_sizes})"
