# -*- coding: utf-8 -*-
"""Squeeze (remove dimension) transform."""

from torch import Tensor

from ..base import BaseTransform

__all__ = ['Squeeze']


class Squeeze(BaseTransform):
    """
    Remove a tensor dimension at the given axis.

    Parameters
    ----------
    dim : int
        Dimension to squeeze. Default: 0.
    """

    def __init__(self, dim: int = 0):
        super().__init__()
        self.dim = dim

    def forward(self, x: Tensor) -> Tensor:
        return x.squeeze(self.dim)

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(dim={self.dim})"
