import torch
import torchvision.transforms as T
from typing import Any
from ..base import BaseTransform

class DemoTorchMNISTTransform(BaseTransform):
    r"""
    A transformation pipeline specifically designed for MNIST-like datasets.
    
    This class composes resizing, tensor conversion, and normalization steps 
    standard for MNIST training. It uses the global mean (0.1307) and 
    standard deviation (0.3081) of the MNIST dataset.

    Args:
        resize (int, optional): Desired output size (height and width) of the image. 
            Default: ``32``.

    Shape:
        - Input: PIL Image or Tensor with shape :math:`(C, H, W)`.
        - Output: :math:`(1, \text{resize}, \text{resize})` normalized Tensor.

    Examples::

        >>> # Initialize transform
        >>> transform = DemoTorchMNISTTransform(resize=28)
        >>> # Assuming 'img' is a PIL Image
        >>> output = transform(img)
        >>> print(output.shape)
        torch.Size([1, 28, 28])

    .. note::
        The normalization parameters are hardcoded to MNIST statistics:
        mean=(0.1307,), std=(0.3081,).
    """

    def __init__(self, resize: int = 32) -> None:
        super().__init__()
        self.resize = resize
        self.transform = T.Compose([
            T.Resize((resize, resize)),
            T.ToTensor(),
            T.Normalize((0.1307,), (0.3081,))
        ])

    def forward(self, x: Any) -> torch.Tensor:
        """
        Performs the transformation on the input image.

        Args:
            x (PIL.Image or torch.Tensor): The input image to be transformed.

        Returns:
            torch.Tensor: The transformed and normalized image tensor.
        """
        return self.transform(x)

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(resize={self.resize})"


