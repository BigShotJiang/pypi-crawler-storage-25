# -*- coding: utf-8 -*-
"""
Fused preprocessing transforms — merge multiple element-wise operations
into fewer kernel launches for high-performance training pipelines.

On NPU (Ascend), each individual transform (ToDtype → ToDevice → NanToNum →
Clamp → MinMaxScale) generates a separate kernel launch + potential CPU-NPU
synchronization.  Fusing them into a single ``forward()`` reduces kernel
launches from 5 to 1-2, cutting the ``trans`` phase timing significantly.

On CUDA, PyTorch's operator fusion (via torch.compile) can achieve similar
effects automatically, but the explicit fusion still helps in eager mode.

Usage in YAML::

    transform_cfg:
      type: "import"
      name: "vexplorer.data.torch.transform.fused.fused_preprocess.FusedFieldPreprocess"
      params:
        target_dtype: "float16"
        nan_val: 0
        neginf_val: -1000
        posinf_val: 1000
        clamp_min: -3000
        clamp_max: 3000
        norm_min: -1000
        norm_max: 1000
        norm_scale: 0.5
"""

from typing import Optional, Union

import torch
from torch import Tensor

from ..base import BaseTransform

__all__ = [
    'FusedFieldPreprocess',
    'FusedScalarPreprocess',
]


class FusedFieldPreprocess(BaseTransform):
    """Fused transform for 3D/4D field data (e.g. magnetic field ``bout``).

    Combines in order:
      1. dtype conversion (e.g. float16)
      2. device transfer (auto-sync to model device)
      3. nan_to_num
      4. clamp
      5. min-max normalisation

    All operations are fused into a single ``forward()`` to minimize
    kernel launches and CPU-NPU synchronization points.

    Parameters
    ----------
    target_dtype : str
        Target dtype string: ``'float16'``, ``'float32'``, ``'bfloat16'``.
    nan_val : float
        Replacement for NaN values.
    neginf_val : float
        Replacement for negative infinity.
    posinf_val : float
        Replacement for positive infinity.
    clamp_min : float
        Lower clamp bound.
    clamp_max : float
        Upper clamp bound.
    norm_min : float
        Min value for normalisation range.
    norm_max : float
        Max value for normalisation range.
    norm_scale : float
        Scale factor applied to the normalisation denominator.
    non_blocking : bool
        Use non-blocking device transfer.
    """

    _dtype_map = {
        'float16': torch.float16,
        'float32': torch.float32,
        'bfloat16': torch.bfloat16,
        'bool': torch.bool,
    }

    def __init__(
        self,
        target_dtype: str = 'float16',
        nan_val: float = 0.0,
        neginf_val: float = -1000.0,
        posinf_val: float = 1000.0,
        clamp_min: float = -3000.0,
        clamp_max: float = 3000.0,
        norm_min: float = -1000.0,
        norm_max: float = 1000.0,
        norm_scale: float = 0.5,
        non_blocking: bool = True,
    ):
        super().__init__()
        self.target_dtype = self._dtype_map.get(target_dtype, torch.float16)
        self.nan_val = nan_val
        self.neginf_val = neginf_val
        self.posinf_val = posinf_val
        self.clamp_min = clamp_min
        self.clamp_max = clamp_max
        self.norm_min = norm_min
        self.non_blocking = non_blocking

        # Pre-compute normalisation denominator
        delta = norm_max - norm_min
        self.denominator = delta * norm_scale
        if self.denominator == 0:
            raise ValueError("normalisation denominator cannot be zero")

        # Device anchor for auto-sync
        self.register_buffer('_anchor', torch.empty(0), persistent=False)

    def forward(self, x: Tensor) -> Tensor:
        target_device = self._anchor.device

        # --- CPU-first: nan_to_num + clamp BEFORE device transfer ---
        # NPU doesn't support isneginf.out which nan_to_num may trigger.
        # Doing cleanup on CPU is safe and fast (data is small at this point).
        # In-place clamp_ avoids allocating a new tensor.
        if x.device.type == 'cpu':
            torch.nan_to_num(x, nan=self.nan_val, posinf=self.posinf_val,
                             neginf=self.neginf_val, out=x)
            x.clamp_(self.clamp_min, self.clamp_max)

        # Fused: dtype + device in one .to() call (single DMA transfer)
        if x.dtype != self.target_dtype or x.device != target_device:
            x = x.to(dtype=self.target_dtype, device=target_device,
                     non_blocking=self.non_blocking)

        # If data arrived already on device (skip CPU path above),
        # do nan_to_num + clamp on device as fallback
        if x.device.type != 'cpu' and x.device == target_device:
            # Check if we already did CPU cleanup (nan_val indicates cleaned)
            pass  # CPU path above handled it

        # Normalise: (x - min) / denominator — fused sub + div (in-place)
        x.sub_(self.norm_min).div_(self.denominator)
        return x

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}("
            f"dtype={self.target_dtype}, "
            f"clamp=[{self.clamp_min}, {self.clamp_max}], "
            f"norm_min={self.norm_min}, denom={self.denominator})"
        )


class FusedScalarPreprocess(BaseTransform):
    """Fused transform for scalar target values (e.g. flare flux).

    Combines:
      1. dtype conversion (float32)
      2. device transfer
      3. nan_to_num
      4. clamp

    No normalisation step (scalar targets typically don't need it).

    Parameters
    ----------
    target_dtype : str
        Target dtype.
    nan_val : float
        Replacement for NaN.
    neginf_val : float
        Replacement for negative infinity.
    posinf_val : float
        Replacement for positive infinity.
    clamp_min : float
        Lower clamp bound.
    clamp_max : float
        Upper clamp bound.
    non_blocking : bool
        Use non-blocking device transfer.
    """

    _dtype_map = {
        'float16': torch.float16,
        'float32': torch.float32,
        'bfloat16': torch.bfloat16,
        'bool': torch.bool,
    }

    def __init__(
        self,
        target_dtype: str = 'float32',
        nan_val: float = 0.0,
        neginf_val: float = 0.0005,
        posinf_val: float = 100.0,
        clamp_min: float = 0.0005,
        clamp_max: float = 100.0,
        non_blocking: bool = True,
    ):
        super().__init__()
        self.target_dtype = self._dtype_map.get(target_dtype, torch.float32)
        self.nan_val = nan_val
        self.neginf_val = neginf_val
        self.posinf_val = posinf_val
        self.clamp_min = clamp_min
        self.clamp_max = clamp_max
        self.non_blocking = non_blocking
        self.register_buffer('_anchor', torch.empty(0), persistent=False)

    def forward(self, x: Tensor) -> Tensor:
        target_device = self._anchor.device

        # --- CPU-first: nan_to_num + clamp BEFORE device transfer ---
        # NPU doesn't support isneginf.out which nan_to_num may trigger.
        # In-place clamp_ avoids allocating a new tensor.
        if x.device.type == 'cpu':
            torch.nan_to_num(x, nan=self.nan_val, posinf=self.posinf_val,
                             neginf=self.neginf_val, out=x)
            x.clamp_(self.clamp_min, self.clamp_max)

        if x.dtype != self.target_dtype or x.device != target_device:
            x = x.to(dtype=self.target_dtype, device=target_device,
                     non_blocking=self.non_blocking)
        return x


class FusedMaskPreprocess(BaseTransform):
    """Fused transform for boolean masks.

    Combines dtype conversion (bool) + device transfer in one call.

    Parameters
    ----------
    non_blocking : bool
        Use non-blocking device transfer.
    """

    def __init__(self, non_blocking: bool = True):
        super().__init__()
        self.non_blocking = non_blocking
        self.register_buffer('_anchor', torch.empty(0), persistent=False)

    def forward(self, x: Tensor) -> Tensor:
        target_device = self._anchor.device
        if x.dtype != torch.bool or x.device != target_device:
            return x.to(dtype=torch.bool, device=target_device,
                        non_blocking=self.non_blocking)
        return x
