# -*- coding: utf-8 -*-
"""Tensor transform."""

import torch
from torch import Tensor

from ..base import BaseTransform

__all__ = ['NanToNum']


class NanToNum(BaseTransform):
    """

    """

    def __init__(self, nan: float = None, posinf: float = None, neginf: float = None):
        super().__init__()
        self.nan = nan
        self.posinf = posinf
        self.neginf = neginf

    def forward(self, x: Tensor) -> Tensor:
        return torch.nan_to_num(x, nan=self.nan, posinf=self.posinf, neginf=self.neginf, out=x)

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(nan={self.nan}, posinf={self.posinf}, neginf={self.neginf})"

