# -*- coding: utf-8 -*-
"""Arbitrary math function transform."""

import torch
import torch.nn.functional as F
from functools import partial
from typing import Callable
from torch import Tensor

from ..base import BaseTransform

__all__ = ['MathFn']

FN_MAP: dict[str, Callable[[Tensor], Tensor]] = {
    # ── Basic math ──────────────────────────────────────────────
    "abs":          torch.abs,
    "sqrt":         torch.sqrt,
    "square":       torch.square,
    "log":          torch.log,
    "log2":         torch.log2,
    "log10":        torch.log10,
    "log1p":        torch.log1p,
    "exp":          torch.exp,
    "expm1":        torch.expm1,
    "reciprocal":   torch.reciprocal,
    "neg":          torch.neg,
    "sign":         torch.sign,
    "ceil":         torch.ceil,
    "floor":        torch.floor,
    "round":        torch.round,
    "trunc":        torch.trunc,
    "frac":         torch.frac,
    # ── Trigonometry ────────────────────────────────────────────
    "sin":          torch.sin,
    "cos":          torch.cos,
    "tan":          torch.tan,
    "asin":         torch.asin,
    "acos":         torch.acos,
    "atan":         torch.atan,
    "sinh":         torch.sinh,
    "cosh":         torch.cosh,
    "tanh":         torch.tanh,
    "asinh":        torch.asinh,
    "acosh":        torch.acosh,
    "atanh":        torch.atanh,
    # ── Activation ──────────────────────────────────────────────
    "relu":         F.relu,
    "relu6":        F.relu6,
    "sigmoid":      torch.sigmoid,
    "softplus":     F.softplus,
    "silu":         F.silu,
    "mish":         F.mish,
    "gelu":         F.gelu,
    "elu":          F.elu,
    "selu":         F.selu,
    "hardsigmoid":  F.hardsigmoid,
    "hardswish":    F.hardswish,
    "hardtanh":     F.hardtanh,
    "leaky_relu":   F.leaky_relu,
    # ── Normalization ───────────────────────────────────────────
    "normalize":    partial(F.normalize, dim=-1),
    # ── Clamp ───────────────────────────────────────────────────
    "clamp_01":     partial(torch.clamp, min=0.0, max=1.0),
    # "clamp_01":     lambda x: x.clamp(0.0, 1.0),
    "clamp_11":     partial(torch.clamp, min=-1.0, max=1.0),
    "clip_01":      partial(torch.clamp, min=0.0, max=1.0),
    # ── Misc ────────────────────────────────────────────────────
    "flatten":      torch.flatten,
    "squeeze":      torch.squeeze,
    "identity":     partial(torch.as_strided,                  # zero-copy identity
                            size=None, stride=None),
    # "identity":     lambda x: x,

}

class MathFn(BaseTransform):
    """
    Apply an arbitrary callable to the input tensor.

    Parameters
    ----------
    fn : Callable[[Tensor], Tensor] | str
        A callable, or a string key from ``FN_MAP`` (e.g. ``"relu"``,
        ``"log1p"``, ``"clamp_01"``).

    Examples
    --------
    >>> t = MathFn(fn=torch.abs)
    >>> t = MathFn(fn="abs")       # equivalent, loaded from yml
    >>> t(torch.tensor([-1.0, 2.0]))
    tensor([1., 2.])
    """

    def __init__(self, fn: Callable[[Tensor], Tensor] | str):
        super().__init__()
        self.fn = self._parse_fn(fn)

    @staticmethod
    def _parse_fn(fn: Callable[[Tensor], Tensor] | str) -> Callable[[Tensor], Tensor]:
        if callable(fn):
            return fn
        if isinstance(fn, str):
            key = fn.lower().strip()
            if key in FN_MAP:
                return FN_MAP[key]
            raise ValueError(
                f"Unknown fn string '{fn}'. "
                f"Available options: {list(FN_MAP.keys())}"
            )
        raise TypeError(f"fn must be str or Callable, got {type(fn)}")

    def forward(self, x: Tensor) -> Tensor:
        return self.fn(x)

    def __repr__(self) -> str:
        fn_name = getattr(self.fn, '__name__', repr(self.fn))
        return f"{self.__class__.__name__}(fn={fn_name})"