# -*- coding: utf-8 -*-
"""Tensor Clamp transform."""

import torch
from torch import Tensor

from ..base import BaseTransform

__all__ = ['Clamp']


class Clamp(BaseTransform):
    """
    Clamp tensor values to ``[min, max]``.

    NaN values are replaced with zero before clamping.

    Parameters
    ----------
    min : float
        Lower bound.
    max : float
        Upper bound.

    """

    def __init__(self, min: float = None, max: float = None):
        super().__init__()
        self.min = min
        self.max = max

    def forward(self, x: Tensor) -> Tensor:
        return torch.clamp_(x, self.min, self.max)

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(min={self.min_val}, max={self.max_val})"

