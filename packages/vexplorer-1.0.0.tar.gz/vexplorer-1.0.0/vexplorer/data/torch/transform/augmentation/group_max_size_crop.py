# -*- coding: utf-8 -*-
"""Group-based max-size crop (and optional downsample / pad) transform.

Designed to be inserted into ``DictTransformManager`` *before*
``AutoSyncDevice`` so that oversized spatial volumes are trimmed on CPU
before moving to GPU — saving device memory.

The transform receives the **entire batch dict**, looks up the current
group name, and applies per-group crop / downsample / pad parameters.
"""

import random
import logging
from typing import Any, Dict, List, Optional, Union

logger = logging.getLogger(__name__)

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor

from ..base import BaseTransform

__all__ = ['GroupMaxSizeCrop']


class GroupMaxSizeCrop(BaseTransform):
    """Crop (and optionally downsample / pad-to-fixed) spatial dimensions per group.

    Receives the full batch dict, reads the group name, then applies
    the group-specific max-size crop and optional pooling downsample.

    Parameters
    ----------
    group_params : Dict[str, Dict[str, Any]]
        Per-group parameter dict.  Each value is a dict with keys:

        * ``max_size``  (List[int])         — max spatial size per dim.
          Dims already ≤ max are untouched.
        * ``downsample`` (bool, default False) — enable pooling downsample.
        * ``downsample_times`` (int, default 1) — how many times to pool
          (each halves the spatial dims).
        * ``downsample_method`` (str, default "avgpool") — ``"avgpool"``
          or ``"maxpool"``.
        * ``pad_to_max`` (bool, default False) — after crop, pad tensor
          to exactly ``max_size`` on each spatial dim.  Eliminates
          dynamic shapes (critical for NPU / Ascend TBE kernel caching).
        * ``pad_align`` (str | List[str], default "start") — where to
          place the original data within the padded tensor:
          ``"start"`` (pad at end), ``"end"`` (pad at start),
          ``"center"`` (pad both sides equally).
        * ``pad_value`` (float, default 0.0) — fill value for padding
          regions (mask always uses 0.0).

        Groups **not** present in the map are left unchanged.

    align : str
        Crop alignment: ``"start"``, ``"end"``, ``"center"``, ``"random"``.
        Default: ``"start"``.
    spatial_start_dim : int
        Index of the first spatial dimension (dims before this are
        batch / channel dims).  Default: 2  →  ``[B, C, *spatial]``.
    input_keys : List[str]
        Dict keys whose tensors should be cropped / downsampled.
    group_name_key : str
        Dict key holding the group name string.  Default:
        ``"__group_name__"``.
    mask_suffix : str
        If ``key + mask_suffix`` exists in the dict it will be cropped
        with the **same** slices.  Default: ``"_mask"``.

    Notes
    -----
    When ``align="random"``, the random offsets are computed **once** per
    forward call and reused for every *input_key* (and its mask) so that
    temporally-stacked frames share the same spatial window.
    """



    def __init__(
        self,
        group_params: Dict[str, Dict[str, Any]],
        align: str = 'start',
        spatial_start_dim: int = 2,
        input_keys: Optional[List[str]] = None,
        group_name_key: str = '__group_name__',
        mask_suffix: str = '_mask',
    ):
        super().__init__()
        self.group_params = group_params
        self.align = align
        self.spatial_start_dim = spatial_start_dim
        self.input_keys = input_keys or []
        self.group_name_key = group_name_key
        self.mask_suffix = mask_suffix

    # ------------------------------------------------------------------
    # Crop helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _calc_crop_offset(current: int, target: int, align: str) -> int:
        """Return the start index for cropping *current* → *target*."""
        diff = current - target
        if diff <= 0:
            return 0
        if align == 'start':
            return 0
        if align == 'end':
            return diff
        if align == 'center':
            return diff // 2
        if align == 'random':
            return random.randint(0, diff)
        return 0  # fallback

    def _build_slices(
        self,
        shape: List[int],
        max_size: List[int],
        crop_dim: List[int],
        align: Union[str, List[str]],
        offsets: Optional[List[int]] = None,
    ) -> List[slice]:
        """Build per-dim slices; uses explicitly provided `crop_dim`."""
        slices = [slice(None)] * len(shape)
        for idx, d in enumerate(crop_dim):
            if d >= len(shape):
                continue
            cur = shape[d]
            tgt = min(cur, max_size[idx]) if idx < len(max_size) else cur
            
            if cur <= tgt:
                pass  # already slice(None)
            else:
                if offsets is not None:
                    start = offsets[idx]
                else:
                    dim_align = align[idx] if isinstance(align, list) and idx < len(align) else (align if isinstance(align, str) else 'start')
                    start = self._calc_crop_offset(cur, tgt, dim_align)
                slices[d] = slice(start, start + tgt)
        return slices

    def _compute_offsets(
        self, shape: List[int], max_size: List[int], crop_dim: List[int], align: Union[str, List[str]],
    ) -> List[int]:
        """Pre-compute crop offsets so all keys share them."""
        offsets = []
        for idx, d in enumerate(crop_dim):
            if d >= len(shape):
                offsets.append(0)
                continue
            cur = shape[d]
            tgt = min(cur, max_size[idx]) if idx < len(max_size) else cur
            dim_align = align[idx] if isinstance(align, list) and idx < len(align) else (align if isinstance(align, str) else 'start')
            offsets.append(self._calc_crop_offset(cur, tgt, dim_align))
        return offsets

    # ------------------------------------------------------------------
    # Pad helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _calc_pad_offset(current: int, target: int, pad_align: str) -> tuple:
        """Return (pad_before, pad_after) for padding *current* → *target*.

        Args:
            current: Current size of the dimension.
            target:  Desired size of the dimension.
            pad_align: Where to place the original data:
                "start" — data at start, pad at end.
                "end"   — data at end, pad at start.
                "center"— data centered, pad both sides.

        Returns:
            (pad_before, pad_after) tuple.
        """
        diff = target - current
        if diff <= 0:
            return (0, 0)
        if pad_align == 'start':
            return (0, diff)
        if pad_align == 'end':
            return (diff, 0)
        if pad_align == 'center':
            before = diff // 2
            return (before, diff - before)
        return (0, diff)  # fallback = start

    @staticmethod
    def _pad_to_target(
        tensor: Tensor,
        target_sizes: List[int],
        pad_dims: List[int],
        pad_align: Union[str, List[str]] = "start",
        pad_value: float = 0.0,
    ) -> Tensor:
        """Pad tensor to exact target_sizes on specified dims.

        Args:
            tensor:       Input tensor.
            target_sizes: Target sizes for each pad_dim (same order).
            pad_dims:     Which dims to pad (same order as target_sizes).
            pad_align:    Alignment — "start" (pad end), "end" (pad start),
                          "center" (pad both sides).  Can be per-dim list.
            pad_value:    Fill value for padding regions.

        Returns:
            Padded tensor with exact target_sizes on pad_dims.
        """
        ndim = tensor.ndim
        # F.pad expects pairs (left, right) for the LAST dim, then
        # second-to-last, etc.  We build a full pad spec.
        # Start with zero-padding for all dims.
        pad_spec_per_dim = [(0, 0)] * ndim

        needs_pad = False
        for idx, d in enumerate(pad_dims):
            if d >= ndim:
                continue
            current = tensor.shape[d]
            target = target_sizes[idx]
            if current >= target:
                continue
            dim_align = (
                pad_align[idx]
                if isinstance(pad_align, list) and idx < len(pad_align)
                else (pad_align if isinstance(pad_align, str) else 'start')
            )
            before, after = GroupMaxSizeCrop._calc_pad_offset(
                current, target, dim_align
            )
            pad_spec_per_dim[d] = (before, after)
            needs_pad = True

        if not needs_pad:
            return tensor

        # F.pad takes pairs in reverse dim order: (last_left, last_right,
        # second_last_left, second_last_right, ...)
        pad_args = []
        for before, after in reversed(pad_spec_per_dim):
            pad_args.extend([before, after])
        return F.pad(tensor, pad_args, value=pad_value)

    # ------------------------------------------------------------------
    # Downsample
    # ------------------------------------------------------------------

    @staticmethod
    def _downsample(
        x: Tensor,
        times: int,
        method: str,
        active_dims: List[int],
    ) -> Tensor:
        """Apply pooling *times* times on explicitly specified dims."""
        if times <= 0 or not active_dims:
            return x

        num_pool_dims = len(active_dims)
        if num_pool_dims in (1, 2, 3):
            if num_pool_dims == 1:
                pool_cls = nn.AvgPool1d if method == 'avgpool' else nn.MaxPool1d
            elif num_pool_dims == 2:
                pool_cls = nn.AvgPool2d if method == 'avgpool' else nn.MaxPool2d
            else:
                pool_cls = nn.AvgPool3d if method == 'avgpool' else nn.MaxPool3d
                
            pool_layer = pool_cls(kernel_size=2, stride=2)
            
            for _ in range(times):
                original_shape = list(x.shape)
                
                non_active_dims = [d for d in range(x.ndim) if d not in active_dims]
                permuted_order = non_active_dims + active_dims
                x_permuted = x.permute(*permuted_order)
                
                flat_b = 1
                for d in non_active_dims:
                    flat_b *= original_shape[d]
                    
                pool_input_shape = (flat_b, 1) + tuple(original_shape[d] for d in active_dims)
                x_reshaped = x_permuted.reshape(pool_input_shape)
                
                x_pooled = pool_layer(x_reshaped)
                
                new_active_shape = list(x_pooled.shape[2:])
                restored_shape = [original_shape[d] for d in non_active_dims] + new_active_shape
                x_restored = x_pooled.reshape(restored_shape)
                
                inverse_perm = [0] * x.ndim
                for new_idx, old_idx in enumerate(permuted_order):
                    inverse_perm[old_idx] = new_idx
                    
                x = x_restored.permute(*inverse_perm)
        else:
            for _ in range(times):
                slices = [slice(None)] * x.ndim
                for d in active_dims:
                    slices[d] = slice(None, None, 2)
                x = x[tuple(slices)]
        return x

    # ------------------------------------------------------------------
    # Forward
    # ------------------------------------------------------------------

    def forward(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Apply group-based crop and optional downsample."""
        group_name = data.get(self.group_name_key)
        if group_name is None or group_name not in self.group_params:
            return data

        params = self.group_params[group_name]
        
        # Crop parameters
        crop_dim: Optional[List[int]] = params.get('crop_dim')
        max_size: Optional[List[int]] = params.get('max_size')
        align: Union[str, List[str]] = params.get('align', self.align)
        
        # Downsample parameters
        enable_ds: bool = params.get('downsample', False)
        ds_dim: Optional[List[int]] = params.get('downsample_dim')
        ds_method: str = params.get('downsample_method', 'avgpool')
        random_ds: bool = params.get('random_downsample', False)
        
        ds_times_param = params.get('downsample_times', 1)
        if enable_ds:
            if isinstance(ds_times_param, list):
                if random_ds:
                    ds_times = random.choice(ds_times_param)
                else:
                    ds_times = ds_times_param[0]
            else:
                ds_times = int(ds_times_param)
        else:
            ds_times = 0

        # Pad-to-max parameters (for NPU TBE kernel caching)
        pad_to_max: bool = params.get('pad_to_max', False)
        pad_align: Union[str, List[str]] = params.get('pad_align', 'start')
        pad_value: float = params.get('pad_value', 0.0)

        # Fallback implicit target dimensions if not provided (backward compatibility)
        if crop_dim is None:
            # Assume 3 spatial dims past spatial_start_dim
            crop_dim = [self.spatial_start_dim + i for i in range(3)]
        if enable_ds and ds_dim is None:
            ds_dim = crop_dim

        result = dict(data)  # shallow copy

        # We will compute random offsets once (for consistency across keys), 
        # but AFTER downsampling the first valid tensor.
        offsets: Optional[List[int]] = None
        offsets_computed = False

        for key in self.input_keys:
            if key not in result or not isinstance(result[key], Tensor):
                continue

            tensor = result[key]
            mask_key = key + self.mask_suffix
            mask = result.get(mask_key)

            logger.info(f"[GroupMaxSizeCrop] Processing key '{key}' from group '{group_name}', shape before: {tensor.shape}, dtype: {tensor.dtype}, device: {tensor.device}")

            # ── Downsample (first — reduce resolution) ────────────────
            if enable_ds and ds_times > 0 and ds_dim is not None:
                # filter out dims that exceed tensor ndim
                active_ds_dims = [d for d in ds_dim if d < tensor.ndim]
                if active_ds_dims:
                    logger.info(f"[GroupMaxSizeCrop] Downsampling {ds_times}x on dims {active_ds_dims} with {ds_method}")
                    
                    need_cast = (tensor.dtype == torch.float16 and tensor.device.type == 'cpu')
                    if need_cast:
                        tensor = tensor.to(torch.float32)

                    tensor = self._downsample(
                        tensor, ds_times, ds_method, active_ds_dims
                    )

                    if need_cast:
                        tensor = tensor.to(torch.float16)
                        
                    logger.info(f"[GroupMaxSizeCrop] Shape after downsample: {tensor.shape}")

                    if mask is not None and isinstance(mask, Tensor):
                        for _ in range(ds_times):
                            stride_slices = [slice(None)] * mask.ndim
                            for d in active_ds_dims:
                                stride_slices[d] = slice(None, None, 2)
                            mask = mask[tuple(stride_slices)]
                        
                        # Fix odd dimension mismatch from stride slice vs avgpool boundary
                        align_slices = [slice(None)] * mask.ndim
                        for d in active_ds_dims:
                            if d < tensor.ndim and d < mask.ndim:
                                align_slices[d] = slice(0, tensor.shape[d])
                        mask = mask[tuple(align_slices)]

            # Pre-compute random offsets once on the downsampled shape
            has_random = (align == 'random') or (isinstance(align, list) and 'random' in align)
            if max_size is not None and crop_dim is not None and has_random and not offsets_computed:
                offsets = self._compute_offsets(
                    list(tensor.shape), max_size, crop_dim, align,
                )
                offsets_computed = True

            # ── Crop (then — trim to max_size if still too large) ────
            if max_size is not None and crop_dim is not None:
                slices = self._build_slices(
                    list(tensor.shape), max_size, crop_dim, align, offsets,
                )
                sl = tuple(slices)
                tensor = tensor[sl].contiguous()
                logger.info(f"[GroupMaxSizeCrop] Shape after crop: {tensor.shape} (max_size={max_size}, align={align})")
                if mask is not None and isinstance(mask, Tensor):
                    mask = mask[sl].contiguous()

            # ── Pad to fixed max_size (NPU TBE kernel caching) ───────
            if pad_to_max and max_size is not None and crop_dim is not None:
                active_pad_dims = [d for d in crop_dim if d < tensor.ndim]
                # Build target sizes, mapping crop_dim indices to max_size
                active_target_sizes = [
                    max_size[idx]
                    for idx, d in enumerate(crop_dim)
                    if d < tensor.ndim and idx < len(max_size)
                ]
                if active_pad_dims and active_target_sizes:
                    tensor = self._pad_to_target(
                        tensor, active_target_sizes, active_pad_dims,
                        pad_align, pad_value,
                    )
                    logger.info(
                        f"[GroupMaxSizeCrop] Shape after pad_to_max: {tensor.shape} "
                        f"(target={active_target_sizes}, pad_align={pad_align})"
                    )
                    if mask is not None and isinstance(mask, Tensor):
                        # Mask dims may differ (e.g. no channel dim):
                        # find the corresponding dims in the mask tensor
                        mask_pad_dims = [
                            d for d in active_pad_dims if d < mask.ndim
                        ]
                        mask_target_sizes = [
                            active_target_sizes[i]
                            for i, d in enumerate(active_pad_dims)
                            if d < mask.ndim
                        ]
                        if mask_pad_dims:
                            mask = self._pad_to_target(
                                mask, mask_target_sizes, mask_pad_dims,
                                pad_align, pad_value=0.0,  # mask padding = 0 (invalid)
                            )

            result[key] = tensor
            if mask is not None:
                result[mask_key] = mask

        return result

    def __repr__(self) -> str:
        groups = list(self.group_params.keys())
        return (
            f"{self.__class__.__name__}("
            f"groups={groups}, align='{self.align}', "
            f"spatial_start_dim={self.spatial_start_dim}, "
            f"input_keys={self.input_keys})"
        )
