# -*- coding: utf-8 -*-
"""Random flip augmentation transform."""

import torch
from torch import Tensor

from ..base import BaseTransform

__all__ = ['RandomFlip']


class RandomFlip(BaseTransform):
    """
    Randomly flip tensor along spatial dimensions.

    Flips are applied independently along each spatial dimension with
    probability ``p``.

    Parameters
    ----------
    p : float
        Probability of flipping along each spatial axis. Default: 0.5.
    spatial_start_dim : int
        Index of the first spatial dimension (dims before this are
        considered batch/channel dims and left untouched).  Default: 2,
        which corresponds to ``[B, C, *spatial]``.
    """

    def __init__(self, p: float = 0.5, spatial_start_dim: int = 2):
        super().__init__()
        self.p = p
        self.spatial_start_dim = spatial_start_dim

    def forward(self, x: Tensor) -> Tensor:
        spatial_axes = range(self.spatial_start_dim, x.ndim)
        flips = torch.rand(len(list(spatial_axes))).lt(self.p)
        for axis, flip in zip(spatial_axes, flips):
            if flip:
                x = x.flip(dims=[axis])
        return x

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}("
            f"p={self.p}, spatial_start_dim={self.spatial_start_dim})"
        )
