# -*- coding: utf-8 -*-
"""Group-based fixed-size spatial splitting transform.

Splits large spatial volumes into multiple non-overlapping fixed-size
patches.  Each patch has exactly the same spatial dimensions, ensuring
consistent tensor shapes (critical for NPU / Ascend TBE kernel caching).

Unlike ``PadToFixedSize`` which returns a **single** tensor,
``GroupFixedSizeSplit`` returns a **list** of patch dicts — suitable
for data augmentation pipelines where multiple views per sample are desired.
"""

import random
import logging
import math
from typing import Any, Dict, List, Optional, Tuple, Union

logger = logging.getLogger(__name__)

import torch
import torch.nn.functional as F
from torch import Tensor

from ..base import BaseTransform

__all__ = ['GroupFixedSizeSplit']


class GroupFixedSizeSplit(BaseTransform):
    """Split spatial volumes into fixed-size patches per group.

    For each input tensor, generates multiple non-overlapping patches
    of exactly ``split_size``.  Residual regions (dimensions not evenly
    divisible by ``split_size``) are handled by padding according to
    ``pad_align``.

    Processing order:
      1. Pad each spatial dim to the nearest multiple of ``split_size``.
      2. Split into a grid of non-overlapping patches.
      3. Optionally select a subset (``max_patches``, ``random_select``).
      4. Return list of patch dicts (each with the same fixed shape).

    Parameters
    ----------
    group_params : Dict[str, Dict[str, Any]]
        Per-group split parameters.  Each value is a dict with keys:

        * ``split_size`` (List[int]) — fixed patch size per spatial dim.
        * ``split_dim``  (List[int], optional) — which dims to split.
          Default: ``[spatial_start_dim, ..., spatial_start_dim + len(split_size) - 1]``.
        * ``pad_align`` (str | List[str], default "start") — alignment
          for residual padding.
        * ``pad_value`` (float, default 0.0) — padding fill value.
        * ``stride`` (List[int], optional) — stride per dim (default =
          ``split_size``, i.e. non-overlapping).
        * ``max_patches`` (int, default -1) — max patches to return
          (-1 = all).
        * ``random_select`` (bool, default False) — randomly select
          subset when ``max_patches`` limits output.
        * ``crop_first`` (bool, default False) — if True, crop spatial
          dims to ``max_size`` (if provided) before splitting.
        * ``max_size`` (List[int], optional) — max spatial size per dim
          before splitting (only used if ``crop_first=True``).
        * ``crop_align`` (str | List[str], default "start") — crop
          alignment when ``crop_first`` is True.

        Groups **not** present in the map are left unchanged (returns
        a single-element list containing the original data).

    spatial_start_dim : int
        Index of the first spatial dimension.  Default: 2 → ``[B, C, *spatial]``.
    input_keys : List[str]
        Dict keys whose tensors should be split.
    group_name_key : str
        Dict key holding the group name string.  Default: ``"__group_name__"``.
    mask_suffix : str
        Suffix for corresponding mask keys.  Default: ``"_mask"``.
    output_mode : str
        ``"list"`` — return a list of patch dicts (default).
        ``"stack"`` — stack patches along batch dim (returns single dict).

    Notes
    -----
    When ``random_select=True``, the patch selection is randomised per
    forward call, providing built-in data augmentation.
    """

    def __init__(
        self,
        group_params: Dict[str, Dict[str, Any]],
        spatial_start_dim: int = 2,
        input_keys: Optional[List[str]] = None,
        group_name_key: str = '__group_name__',
        mask_suffix: str = '_mask',
        output_mode: str = 'list',
    ):
        super().__init__()
        self.group_params = group_params
        self.spatial_start_dim = spatial_start_dim
        self.input_keys = input_keys or []
        self.group_name_key = group_name_key
        self.mask_suffix = mask_suffix
        self.output_mode = output_mode

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _calc_pad_offsets(current: int, target: int, align: str) -> Tuple[int, int]:
        """Return (pad_before, pad_after) for padding *current* → *target*."""
        diff = target - current
        if diff <= 0:
            return (0, 0)
        if align == 'start':
            return (0, diff)
        if align == 'end':
            return (diff, 0)
        if align == 'center':
            before = diff // 2
            return (before, diff - before)
        return (0, diff)

    @staticmethod
    def _calc_crop_offset(current: int, target: int, align: str) -> int:
        """Start index for cropping *current* → *target*."""
        diff = current - target
        if diff <= 0:
            return 0
        if align == 'start':
            return 0
        if align == 'end':
            return diff
        if align == 'center':
            return diff // 2
        if align == 'random':
            return random.randint(0, diff)
        return 0

    @staticmethod
    def _get_align(align_param: Union[str, List[str]], idx: int) -> str:
        if isinstance(align_param, list) and idx < len(align_param):
            return align_param[idx]
        if isinstance(align_param, str):
            return align_param
        return 'start'

    def _pad_to_divisible(
        self,
        tensor: Tensor,
        split_size: List[int],
        split_dims: List[int],
        pad_align: Union[str, List[str]],
        pad_value: float,
    ) -> Tensor:
        """Pad tensor so each split_dim is divisible by split_size."""
        ndim = tensor.ndim
        pad_spec = [(0, 0)] * ndim
        needs_pad = False

        for idx, d in enumerate(split_dims):
            if d >= ndim:
                continue
            current = tensor.shape[d]
            target = math.ceil(current / split_size[idx]) * split_size[idx]
            if current < target:
                a = self._get_align(pad_align, idx)
                before, after = self._calc_pad_offsets(current, target, a)
                pad_spec[d] = (before, after)
                needs_pad = True

        if not needs_pad:
            return tensor

        pad_args = []
        for before, after in reversed(pad_spec):
            pad_args.extend([before, after])
        return F.pad(tensor, pad_args, value=pad_value)

    def _crop_to_max(
        self,
        tensor: Tensor,
        max_size: List[int],
        split_dims: List[int],
        crop_align: Union[str, List[str]],
    ) -> Tensor:
        """Crop tensor to max_size on split_dims (if exceeds)."""
        slices = [slice(None)] * tensor.ndim
        needs_crop = False
        for idx, d in enumerate(split_dims):
            if d >= tensor.ndim or idx >= len(max_size):
                continue
            current = tensor.shape[d]
            target = max_size[idx]
            if current > target:
                a = self._get_align(crop_align, idx)
                start = self._calc_crop_offset(current, target, a)
                slices[d] = slice(start, start + target)
                needs_crop = True
        if needs_crop:
            tensor = tensor[tuple(slices)].contiguous()
        return tensor

    def _split_tensor(
        self,
        tensor: Tensor,
        split_size: List[int],
        split_dims: List[int],
        stride: Optional[List[int]] = None,
    ) -> List[Tensor]:
        """Split tensor into patches along split_dims."""
        if stride is None:
            stride = split_size

        # Compute grid positions for each split dim
        grid_ranges = []
        for idx, d in enumerate(split_dims):
            if d >= tensor.ndim:
                grid_ranges.append([0])
                continue
            dim_size = tensor.shape[d]
            s = stride[idx]
            ps = split_size[idx]
            starts = list(range(0, dim_size - ps + 1, s))
            if not starts:
                starts = [0]
            grid_ranges.append(starts)

        # Generate all combinations (cartesian product)
        import itertools
        grid_positions = list(itertools.product(*grid_ranges))

        patches = []
        for pos in grid_positions:
            slices = [slice(None)] * tensor.ndim
            for idx, d in enumerate(split_dims):
                if d >= tensor.ndim:
                    continue
                start = pos[idx]
                slices[d] = slice(start, start + split_size[idx])
            patch = tensor[tuple(slices)].contiguous()
            patches.append(patch)

        return patches

    # ------------------------------------------------------------------
    # Forward
    # ------------------------------------------------------------------

    def forward(self, data: Dict[str, Any]) -> Union[List[Dict[str, Any]], Dict[str, Any]]:
        """Apply group-based fixed-size splitting.

        Returns:
            If output_mode="list": List of dicts, each containing one patch.
            If output_mode="stack": Single dict with patches stacked along batch dim.
        """
        group_name = data.get(self.group_name_key)
        if group_name is None or group_name not in self.group_params:
            # Passthrough: return as single-element list
            return [data] if self.output_mode == 'list' else data

        params = self.group_params[group_name]
        split_size: List[int] = params['split_size']
        split_dim: Optional[List[int]] = params.get('split_dim')
        pad_align: Union[str, List[str]] = params.get('pad_align', 'start')
        pad_value: float = params.get('pad_value', 0.0)
        stride: Optional[List[int]] = params.get('stride')
        max_patches: int = params.get('max_patches', -1)
        random_select: bool = params.get('random_select', False)
        crop_first: bool = params.get('crop_first', False)
        max_size: Optional[List[int]] = params.get('max_size')
        crop_align: Union[str, List[str]] = params.get('crop_align', 'start')

        if split_dim is None:
            split_dim = [self.spatial_start_dim + i for i in range(len(split_size))]

        # Process each input key → build per-key patch lists
        per_key_patches: Dict[str, List[Tensor]] = {}
        per_mask_patches: Dict[str, List[Tensor]] = {}
        num_patches = None

        for key in self.input_keys:
            if key not in data or not isinstance(data[key], Tensor):
                continue

            tensor = data[key]
            mask_key = key + self.mask_suffix
            mask = data.get(mask_key)

            logger.info(
                f"[GroupFixedSizeSplit] Processing key '{key}' from group "
                f"'{group_name}', shape: {tensor.shape}"
            )

            # Optional crop first
            if crop_first and max_size is not None:
                tensor = self._crop_to_max(tensor, max_size, split_dim, crop_align)
                if mask is not None and isinstance(mask, Tensor):
                    mask_dims = [d for d in split_dim if d < mask.ndim]
                    mask_max = [max_size[i] for i, d in enumerate(split_dim) if d < mask.ndim]
                    mask = self._crop_to_max(mask, mask_max, mask_dims, crop_align)

            # Pad to divisible by split_size
            tensor = self._pad_to_divisible(
                tensor, split_size, split_dim, pad_align, pad_value
            )
            if mask is not None and isinstance(mask, Tensor):
                mask_dims = [d for d in split_dim if d < mask.ndim]
                mask_split = [split_size[i] for i, d in enumerate(split_dim) if d < mask.ndim]
                mask = self._pad_to_divisible(
                    mask, mask_split, mask_dims, pad_align, pad_value=0.0
                )

            # Split
            patches = self._split_tensor(tensor, split_size, split_dim, stride)
            per_key_patches[key] = patches

            if mask is not None and isinstance(mask, Tensor):
                mask_dims = [d for d in split_dim if d < mask.ndim]
                mask_split = [split_size[i] for i, d in enumerate(split_dim) if d < mask.ndim]
                mask_stride = [stride[i] for i, d in enumerate(split_dim) if d < mask.ndim] if stride else None
                mask_patches = self._split_tensor(mask, mask_split, mask_dims, mask_stride)
                per_mask_patches[mask_key] = mask_patches

            if num_patches is None:
                num_patches = len(patches)

            logger.info(
                f"[GroupFixedSizeSplit] Split into {len(patches)} patches of "
                f"shape {patches[0].shape}"
            )

        if num_patches is None or num_patches == 0:
            return [data] if self.output_mode == 'list' else data

        # Select subset if max_patches is set
        indices = list(range(num_patches))
        if max_patches > 0 and max_patches < num_patches:
            if random_select:
                indices = sorted(random.sample(indices, max_patches))
            else:
                indices = indices[:max_patches]

        # Build output
        patch_dicts = []
        for i in indices:
            patch_data = dict(data)  # shallow copy non-tensor keys
            for key, patches in per_key_patches.items():
                patch_data[key] = patches[i]
            for mask_key, patches in per_mask_patches.items():
                patch_data[mask_key] = patches[i]
            patch_data['__patch_index__'] = i
            patch_data['__total_patches__'] = num_patches
            patch_dicts.append(patch_data)

        if self.output_mode == 'stack':
            # Stack all patches along batch dimension
            stacked = dict(data)
            for key in per_key_patches:
                selected = [per_key_patches[key][i] for i in indices]
                stacked[key] = torch.cat(selected, dim=0)
            for mask_key in per_mask_patches:
                selected = [per_mask_patches[mask_key][i] for i in indices]
                stacked[mask_key] = torch.cat(selected, dim=0)
            stacked['__num_patches__'] = len(indices)
            return stacked

        return patch_dicts

    def __repr__(self) -> str:
        groups = list(self.group_params.keys())
        return (
            f"{self.__class__.__name__}("
            f"groups={groups}, "
            f"spatial_start_dim={self.spatial_start_dim}, "
            f"input_keys={self.input_keys}, "
            f"output_mode='{self.output_mode}')"
        )
