# -*- coding: utf-8 -*-
"""Pad (or crop-then-pad) tensor to a fixed spatial size.

Standalone transform that ensures every output tensor has **exactly**
the specified size on the target spatial dimensions.  This eliminates
dynamic shapes, which is critical for NPU / Ascend TBE kernel caching.

Unlike ``GroupMaxSizeCrop`` (group-aware, batch-dict-level), this
transform operates on a **single tensor** and returns a **single tensor**.
"""

import logging
from typing import Any, Dict, List, Optional, Tuple, Union

logger = logging.getLogger(__name__)

import torch
import torch.nn.functional as F
from torch import Tensor

from ..base import BaseTransform

__all__ = ['PadToFixedSize']


class PadToFixedSize(BaseTransform):
    """Pad (and optionally crop) a tensor to an exact fixed spatial size.

    Processing order per spatial dim:
      1. If ``current > target`` → **crop** according to ``crop_align``.
      2. If ``current < target`` → **pad** according to ``pad_align``.
      3. If ``current == target`` → no-op.

    Parameters
    ----------
    target_size : List[int]
        Exact target size for each spatial dimension (same length as
        ``spatial_dims``).
    spatial_dims : List[int]
        Which tensor dimensions are spatial (0-indexed).
        Example: ``[2, 3, 4]`` for ``(B, C, D, H, W, T)`` → D, H, W.
    pad_align : str | List[str]
        Where to place original data when padding:
        ``"start"`` — data at start, pad at end (default),
        ``"end"``   — data at end, pad at start,
        ``"center"``— data centered, pad both sides.
    crop_align : str | List[str]
        Where to crop when current > target:
        ``"start"`` — keep start, crop end (default),
        ``"end"``   — keep end, crop start,
        ``"center"``— keep center, crop both sides,
        ``"random"``— random offset.
    pad_value : float
        Fill value for padding regions.  Default: ``0.0``.
    mask_pad_value : float
        Fill value for mask padding.  Default: ``0.0`` (invalid).

    Examples
    --------
    >>> transform = PadToFixedSize(
    ...     target_size=[128, 256, 128],
    ...     spatial_dims=[2, 3, 4],
    ...     pad_align="start",
    ...     crop_align="center",
    ... )
    >>> # Input: (B, C, 100, 300, 80, T)
    >>> # Output: (B, C, 128, 256, 128, T)
    >>> #   D: 100 → pad to 128 (start-aligned, 28 padding at end)
    >>> #   H: 300 → crop to 256 (center-aligned, remove 22 each side)
    >>> #   W:  80 → pad to 128 (start-aligned, 48 padding at end)
    """

    def __init__(
        self,
        target_size: List[int],
        spatial_dims: Optional[List[int]] = None,
        pad_align: Union[str, List[str]] = 'start',
        crop_align: Union[str, List[str]] = 'start',
        pad_value: float = 0.0,
        mask_pad_value: float = 0.0,
    ):
        super().__init__()
        self.target_size = target_size
        self.spatial_dims = spatial_dims or [2, 3, 4]
        self.pad_align = pad_align
        self.crop_align = crop_align
        self.pad_value = pad_value
        self.mask_pad_value = mask_pad_value

        if len(self.target_size) != len(self.spatial_dims):
            raise ValueError(
                f"target_size ({len(self.target_size)}) and spatial_dims "
                f"({len(self.spatial_dims)}) must have the same length."
            )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _calc_crop_offset(current: int, target: int, align: str) -> int:
        """Start index for cropping *current* → *target*."""
        import random as _random
        diff = current - target
        if diff <= 0:
            return 0
        if align == 'start':
            return 0
        if align == 'end':
            return diff
        if align == 'center':
            return diff // 2
        if align == 'random':
            return _random.randint(0, diff)
        return 0

    @staticmethod
    def _calc_pad_offsets(current: int, target: int, align: str) -> Tuple[int, int]:
        """Return (pad_before, pad_after) for padding *current* → *target*."""
        diff = target - current
        if diff <= 0:
            return (0, 0)
        if align == 'start':
            return (0, diff)
        if align == 'end':
            return (diff, 0)
        if align == 'center':
            before = diff // 2
            return (before, diff - before)
        return (0, diff)

    def _get_align(self, align_param: Union[str, List[str]], idx: int) -> str:
        """Get per-dim alignment string."""
        if isinstance(align_param, list) and idx < len(align_param):
            return align_param[idx]
        if isinstance(align_param, str):
            return align_param
        return 'start'

    # ------------------------------------------------------------------
    # Core: crop-then-pad
    # ------------------------------------------------------------------

    def _crop_and_pad(
        self,
        tensor: Tensor,
        pad_value: float,
    ) -> Tensor:
        """Crop (if exceeds) then pad (if smaller) to target_size."""
        ndim = tensor.ndim

        # ── Step 1: Crop dims that exceed target ──
        slices = [slice(None)] * ndim
        needs_crop = False
        for idx, d in enumerate(self.spatial_dims):
            if d >= ndim:
                continue
            current = tensor.shape[d]
            target = self.target_size[idx]
            if current > target:
                crop_a = self._get_align(self.crop_align, idx)
                start = self._calc_crop_offset(current, target, crop_a)
                slices[d] = slice(start, start + target)
                needs_crop = True

        if needs_crop:
            tensor = tensor[tuple(slices)].contiguous()

        # ── Step 2: Pad dims that are smaller than target ──
        pad_spec = [(0, 0)] * ndim
        needs_pad = False
        for idx, d in enumerate(self.spatial_dims):
            if d >= ndim:
                continue
            current = tensor.shape[d]
            target = self.target_size[idx]
            if current < target:
                pad_a = self._get_align(self.pad_align, idx)
                before, after = self._calc_pad_offsets(current, target, pad_a)
                pad_spec[d] = (before, after)
                needs_pad = True

        if needs_pad:
            # F.pad: pairs in reverse dim order
            pad_args = []
            for before, after in reversed(pad_spec):
                pad_args.extend([before, after])
            tensor = F.pad(tensor, pad_args, value=pad_value)

        return tensor

    # ------------------------------------------------------------------
    # Forward
    # ------------------------------------------------------------------

    def forward(self, data: Any) -> Any:
        """Apply crop-and-pad to tensor or dict of tensors.

        Accepts:
          - A single ``Tensor`` → returns processed ``Tensor``.
          - A ``dict`` → processes tensor values, returns ``dict``.
            If a key ends with ``_mask``, uses ``mask_pad_value``.
        """
        if isinstance(data, Tensor):
            result = self._crop_and_pad(data, self.pad_value)
            logger.info(
                f"[PadToFixedSize] {list(data.shape)} → {list(result.shape)} "
                f"(target={self.target_size})"
            )
            return result

        if isinstance(data, dict):
            result = dict(data)
            for key, val in data.items():
                if not isinstance(val, Tensor):
                    continue
                is_mask = key.endswith('_mask')
                pv = self.mask_pad_value if is_mask else self.pad_value
                processed = self._crop_and_pad(val, pv)
                logger.info(
                    f"[PadToFixedSize] key='{key}': {list(val.shape)} → "
                    f"{list(processed.shape)} (target={self.target_size})"
                )
                result[key] = processed
            return result

        return data

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}("
            f"target_size={self.target_size}, "
            f"spatial_dims={self.spatial_dims}, "
            f"pad_align='{self.pad_align}', "
            f"crop_align='{self.crop_align}', "
            f"pad_value={self.pad_value})"
        )
