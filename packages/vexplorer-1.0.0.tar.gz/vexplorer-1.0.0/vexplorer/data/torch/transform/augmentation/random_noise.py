# -*- coding: utf-8 -*-
"""Random Gaussian noise augmentation."""

import torch
from torch import Tensor

from ..base import BaseTransform

__all__ = ['RandomNoise']


class RandomNoise(BaseTransform):
    """
    Add random Gaussian noise to a tensor.

    With probability ``p``, additive Gaussian noise is drawn and added
    to the input.

    Parameters
    ----------
    p : float
        Probability of applying noise. Default: 0.5.
    mean : float
        Mean of the Gaussian distribution. Default: 0.0.
    std : float
        Standard deviation of the Gaussian distribution. Default: 0.1.
    """

    def __init__(self, p: float = 0.5, mean: float = 0.0, std: float = 0.1):
        super().__init__()
        self.p = p
        self.mean = mean
        self.std = std

    def forward(self, x: Tensor) -> Tensor:
        if self.training and torch.rand(1).item() < self.p:
            noise = torch.randn_like(x) * self.std + self.mean
            return x + noise
        return x

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}("
            f"p={self.p}, mean={self.mean}, std={self.std})"
        )
