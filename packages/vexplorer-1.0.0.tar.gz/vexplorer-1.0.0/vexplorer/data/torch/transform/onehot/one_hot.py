# -*- coding: utf-8 -*-
"""One-hot encoding transform."""

import torch
import torch.nn.functional as F
from torch import Tensor

from ..base import BaseTransform

__all__ = ['OneHotEncode']


class OneHotEncode(BaseTransform):
    """
    One-hot encode an integer label tensor.

    Parameters
    ----------
    num_classes : int
        Total number of classes.  ``-1`` infers from input.
    """

    def __init__(self, num_classes: int = -1):
        super().__init__()
        self.num_classes = num_classes

    def forward(self, x: Tensor) -> Tensor:
        return F.one_hot(x.long(), num_classes=self.num_classes)

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(num_classes={self.num_classes})"
