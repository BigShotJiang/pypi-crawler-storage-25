import os
from typing import Optional, Callable, Any, Tuple

from torchvision.datasets import MNIST

class DemoMNISTDataset(MNIST):
    """
    A wrapper around the MNIST dataset adapted for the Builder architecture.

    This class extends :class:`torchvision.datasets.MNIST` to ensure the root directory
    is created automatically before initialization. It serves as a demonstration
    of how to wrap standard datasets for custom pipelines.

    Args:
        root (str): Root directory of dataset where ``MNIST/raw/train-images-idx3-ubyte``
            and  ``MNIST/raw/t10k-images-idx3-ubyte`` exist.
        train (bool, optional): If True, creates dataset from ``train-images-idx3-ubyte``,
            otherwise from ``t10k-images-idx3-ubyte``. Defaults to ``True``.
        transform (callable, optional): A function/transform that  takes in an PIL image
            and returns a transformed version. E.g, ``transform.RandomCrop``.
            Defaults to ``None``.
        download (bool, optional): If true, downloads the dataset from the internet and
            puts it in root directory. If dataset is already downloaded, it is not
            downloaded again. Defaults to ``True``.

    Attributes:
        classes (list): List of the class names sorted alphabetically.
        class_to_idx (dict): Dict with items (class_name, class_index).

    Example:
        >>> from torchvision import transform
        >>> transform = transform.Compose([transform.ToTensor()])
        >>> dataset = DemoMNISTDataset(root='./data', train=True, transform=transform)
        >>> img, target = dataset[0]
    """

    def __init__(
            self,
            root: str,
            train: bool = True,
            transform: Optional[Callable] = None,
            download: bool = True
    ) -> None:
        # Ensure the directory exists before passing it to the parent class
        # This handles the case where strict folder checking might be needed externally
        os.makedirs(root, exist_ok=True)

        super().__init__(
            root=root,
            train=train,
            transform=transform,
            download=download
        )


