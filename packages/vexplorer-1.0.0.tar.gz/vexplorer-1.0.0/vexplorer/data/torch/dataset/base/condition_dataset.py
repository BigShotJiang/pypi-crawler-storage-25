"""
condition_dataset.py
==========

Production-ready PyTorch Dataset utilities for conditional filtering and
time-series sequence association.

Classes
-------
BaseConditionDataset
    Handles DataFrame loading, vectorized condition-based grouping, and
    data access with type-normalised records.

BaseSequenceConditionDataset
    Extends :class:`BaseConditionDataset` with a collision-free time-series
    neighbor graph, vectorized pre-sorting, and incomplete-sequence filtering.

Design Principles
-----------------
* All expensive work (querying, hashing, sorting) happens in ``__init__``
  or explicit registration methods; ``__getitem__`` is O(1).
* Two storage modes: ``as_dict_records=True`` (speed) vs ``False`` (memory).
* DataFrame finalization is an *explicit* step via ``release_dataframe()``.
* Neighbor graph uses Pandas ``set_index`` + ``reindex`` (C-layer MultiIndex
  hash) to guarantee zero collision risk regardless of column magnitude.
* Float compare columns are promoted to ``int64`` via
  ``round(value * float_key_scale)`` so that step arithmetic is exact integer
  subtraction before hashing.

Recommended call order (sequence subclass)::

    ds.register_seq_series(...)   # builds seq_series_indices
    ds.filter_incomplete_sequences()  # prunes group_map_idx_list
    ds.save_to_csv(...)           # optional snapshot while df is alive
    ds.release_dataframe()        # reclaim DataFrame memory

Typical Usage
-------------
>>> import pandas as pd
>>> # from condition_dataset import BaseSequenceConditionDataset
>>>
>>> df = pd.DataFrame({
...     "id":   [1, 1, 1, 1],
...     "time": [10, 20, 30, 40],
...     "val":  [0.1, 0.2, 0.3, 0.4],
... })
>>> ds = BaseSequenceConditionDataset(
...     meta_pandas_data=df,
...     condition_dict_list=[{"name": "all", "condition": "val > 0"}],
...     as_dict_records=True,
... )
>>> ds.register_seq_series(
...     match_cols=["id"], compare_cols=["time"],
...     compare_deltas=[10], seq_len=2,
... )
>>> ds.filter_incomplete_sequences()
>>> ds.save_to_csv("/tmp/out.csv")
>>> ds.release_dataframe()
"""

import json
import logging
import os
from typing import Any, Dict, List, Optional, Union, Callable
from pathlib import Path
import numpy as np
import pandas as pd
from torch.utils.data import Dataset

logger = logging.getLogger(__name__)

_ORIGINAL_INDEX_COL: str = "__original_index__"


# ---------------------------------------------------------------------------
# Record normalisation helpers
# ---------------------------------------------------------------------------

def _normalise_value(val: Any) -> Any:
    """Convert a single scalar to a native Python type.

    Conversion order is significant:

    1. Null check (``pd.isna``) is attempted first and wrapped in
       ``try/except`` because ``pd.isna`` raises ``TypeError`` for
       non-scalar array-like inputs.
    2. NumPy scalar types are mapped to ``int``, ``float``, or ``bool``.
    3. NumPy arrays are converted to nested Python lists.
    4. All other values are returned unchanged.

    .. note::
        Null values are returned as Python ``None``.  PyTorch's default
        ``collate_fn`` cannot pack ``None`` into a tensor batch; if your
        ``__getitem__`` forwards records directly to the DataLoader, either
        fill nulls in the upstream DataFrame or supply a custom
        ``collate_fn``.  Pandas nullable-integer columns that contain at
        least one ``NaN`` are internally stored as ``float64``; affected
        rows will yield Python ``float`` (or ``None`` for the ``NaN``
        cells), which is the standard Pandas behaviour and cannot be
        corrected at the record level without per-column dtype bookkeeping.

    Args:
        val: Any scalar or array value from a Pandas cell.

    Returns:
        A native Python ``int``, ``float``, ``bool``, ``list``, ``None``,
        or the original value if no conversion applies.
    """
    try:
        if not isinstance(val, (list, dict, np.ndarray)) and pd.isna(val):
            return None
    except (TypeError, ValueError):
        pass

    if isinstance(val, np.integer):
        return int(val)
    if isinstance(val, np.floating):
        return float(val)
    if isinstance(val, np.bool_):
        return bool(val)
    if isinstance(val, np.ndarray):
        return val.tolist()
    return val


def _normalise_records(df: pd.DataFrame) -> List[Dict]:
    """Convert a DataFrame to a ``List[Dict]`` with Python-native value types.

    Uses ``df.to_dict("records")`` for the C-layer batch conversion, then
    applies :func:`_normalise_value` to every value in a single Python pass.
    This is orders of magnitude faster than per-row ``iloc`` access for large
    DataFrames.

    Args:
        df (pd.DataFrame): Source DataFrame (may contain NumPy scalars or NaN).

    Returns:
        List[Dict]: One dict per row; all values are Python-native types.
    """
    raw = df.to_dict("records")
    return [{k: _normalise_value(v) for k, v in rec.items()} for rec in raw]


def _normalise_row(row: pd.Series) -> Dict:
    """Convert a single DataFrame row (Series) to a normalised dict.

    Faster than constructing a one-row DataFrame for the same purpose:
    benchmarks show ~10x lower overhead per call than
    ``_normalise_records(df.iloc[[idx]])[0]``.

    .. note::
        When a column's dtype has been promoted to ``float64`` because the
        column contains ``NaN`` values, integer values in that column will
        appear as Python ``float`` here.  This is a Pandas limitation.

    Args:
        row (pd.Series): A single row returned by ``df.iloc[idx]``.

    Returns:
        Dict: Column → Python-native value.
    """
    return {k: _normalise_value(v) for k, v in row.to_dict().items()}


# =============================================================================
# BaseConditionDataset
# =============================================================================


class BaseConditionDataset(Dataset):
    """Base dataset for condition-based row grouping with normalised data access.

    Moves all expensive operations---DataFrame loading, query evaluation, and
    index construction---into :meth:`__init__`, so that :meth:`__getitem__`
    remains O(1) at training time.

    The original upstream DataFrame index is preserved in a helper column
    (``"__original_index__"``) before ``reset_index`` is called, so every
    internal row number can be traced back to its upstream label via
    :meth:`get_original_index`.

    Both storage modes return identical Python-native value types from
    :meth:`get_records`.  In ``as_dict_records=False`` mode the hot path
    uses ``df.iloc[idx]`` (returns a ``Series``) rather than the slower
    ``df.iloc[[idx]]`` (returns a one-row ``DataFrame``), giving roughly
    10× lower per-call overhead.

    The internal DataFrame is tracked via a ``_df_released`` flag rather
    than being hard-deleted.  The public :attr:`df` property returns
    ``None`` once :meth:`release_dataframe` is called.

    .. note::
        Subclasses **must** implement :meth:`__getitem__`.

    Args:
        meta_pandas_data (pd.DataFrame, optional):
            Source DataFrame.  Mutually exclusive with ``meta_csv_path``.
        condition_dict_list (List[Dict], optional):
            Grouping config list.  Each entry must contain:

            * ``"name"`` *(str)* -- group label.
            * ``"condition"`` *(str)* -- a :meth:`pandas.DataFrame.query`
              expression, e.g. ``"val > 10"``.
            * ``"batch_size"`` *(int, optional)* -- sampler hint, default ``1``.

            Mutually exclusive with ``condition_json_path``.
        meta_csv_path (str, optional):
            CSV file path used when ``meta_pandas_data`` is ``None``.
        condition_json_path (str, optional):
            JSON file path with the same schema as ``condition_dict_list``.
        group_name (str):
            Helper column name added to the DataFrame for group labels.
            Defaults to ``"__group_name__"``.
        as_dict_records (bool):
            Storage-mode switch:

            * ``True`` -- pre-build ``List[Dict]`` for O(1) access
              (higher peak memory).
            * ``False`` -- retain the DataFrame (lower memory, slightly
              slower per-sample access).

    Attributes:
        df (pd.DataFrame or None):
            The internal DataFrame, or ``None`` after
            :meth:`release_dataframe` is called.
        data_records (List[Dict] or None):
            Pure-Python list of row dicts (populated only when
            ``as_dict_records=True``).
        group_map_idx_list (Dict[str, List[int]]):
            Group name → list of internal zero-based row indices.
        group_map_batch_size (Dict[str, int]):
            Group name → suggested batch size.
        configs (List[Dict]):
            Resolved grouping configuration list.

    Example::

        >>> df = pd.DataFrame({"id": [1,2,3,4,5], "val": [5,15,25,35,45]})
        >>> ds = BaseConditionDataset(
        ...     meta_pandas_data=df,
        ...     condition_dict_list=[
        ...         {"name": "low",  "condition": "val <= 10", "batch_size": 2},
        ...         {"name": "high", "condition": "val >  10", "batch_size": 4},
        ...     ],
        ... )
        >>> ds.get_group_map_idx_list()
        {"low": [0], "high": [1, 2, 3, 4]}
    """

    def __init__(
            self,
            meta_pandas_data: Optional[pd.DataFrame] = None,
            condition_dict_list: Optional[List[Dict]] = None,
            meta_csv_path: Optional[str] = None,
            condition_json_path: Optional[str] = None,
            group_name: str = "__group_name__",
            as_dict_records: bool = True,
            build_params: Optional[Dict[str, Any]] = None,
            transform: Optional[Callable] = None,
            is_main: bool = True,
    ) -> None:
        self.group_name_key = group_name
        self.as_dict_records = as_dict_records
        self._df_released: bool = False
        self._df: Optional[pd.DataFrame] = None
        self.build_params = build_params
        self.transform = transform
        self.is_main = is_main

        self._df = self._initialize_dataframe(meta_pandas_data, meta_csv_path)
        self.configs: List[Dict] = self._load_configs(
            condition_dict_list, condition_json_path
        )

        self.group_map_idx_list: Dict[str, List[int]] = {}
        self.group_map_batch_size: Dict[str, int] = {}
        self._perform_vectorized_grouping()

        self.data_records: Optional[List[Dict]] = None
        if self.as_dict_records:
            logger.info(
                "[BaseConditionDataset] Converting DataFrame to List[Dict] "
                "(fast access mode)."
            )
            self.data_records = _normalise_records(self._df)
        else:
            logger.info(
                "[BaseConditionDataset] Retaining Pandas DataFrame "
                "(memory-efficient mode)."
            )

        if build_params is not None:
            self.build(**build_params)

    # ------------------------------------------------------------------
    # df property
    # ------------------------------------------------------------------

    @property
    def df(self) -> Optional[pd.DataFrame]:
        """The internal DataFrame, or ``None`` if it has been released."""
        return None if self._df_released else self._df

    @df.setter
    def df(self, value: Optional[pd.DataFrame]) -> None:
        """Assign a new DataFrame or trigger release semantics via ``None``."""
        if value is None:
            self._df_released = True
        else:
            self._df = value
            self._df_released = False

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _initialize_dataframe(
            self,
            pandas_data: Optional[pd.DataFrame],
            csv_path: Optional[str],
    ) -> pd.DataFrame:
        """Load the source data, preserve its index, and return a zero-based copy.

        The caller's DataFrame index is stored in :data:`_ORIGINAL_INDEX_COL`
        before ``reset_index``.  A ``WARNING``-level log is emitted when the
        incoming index is non-default (i.e. the DataFrame appears to be a
        slice).

        Args:
            pandas_data (pd.DataFrame, optional): In-memory DataFrame.
            csv_path (str, optional): Path to a CSV file on disk.

        Returns:
            pd.DataFrame: A copy with a contiguous zero-based integer index
            and an ``__original_index__`` column.

        Raises:
            ValueError: If neither ``pandas_data`` nor a valid ``csv_path``
                is provided.
        """
        if pandas_data is not None:
            df = pandas_data.copy()
        elif csv_path is not None and os.path.exists(csv_path):
            df = pd.read_csv(csv_path)
        else:
            raise ValueError(
                "Invalid data source: provide either 'meta_pandas_data' "
                "or a valid 'meta_csv_path'."
            )

        if not df.index.equals(pd.RangeIndex(len(df))):
            logger.warning(
                "[BaseConditionDataset] Non-default DataFrame index detected "
                "(the source may be a slice). Original index values are "
                "preserved in column '%s' for traceability.",
                _ORIGINAL_INDEX_COL,
            )

        if _ORIGINAL_INDEX_COL not in df.columns:
            df[_ORIGINAL_INDEX_COL] = df.index.to_numpy()

        return df.reset_index(drop=True)

    def _load_configs(
            self,
            dict_list: Optional[List[Dict]],
            json_path: Optional[str],
    ) -> List[Dict]:
        """Resolve grouping configuration from a list or a JSON file.

        Args:
            dict_list (List[Dict], optional): In-memory config list.
            json_path (str, optional): Path to a JSON config file.

        Returns:
            List[Dict]: Resolved configuration (may be empty).
        """
        if dict_list is not None:
            return dict_list
        if json_path is not None:
            with open(json_path, "r") as fh:
                return json.load(fh)
        return []

    def _perform_vectorized_grouping(self) -> None:
        """Assign rows to groups via vectorised Pandas queries.

        First-come-first-served: a row is claimed by the first group whose
        condition it satisfies.  Unmatched rows are labelled ``"Unknown"``.

        Populates :attr:`group_map_idx_list` and :attr:`group_map_batch_size`
        in place.
        """
        self._df[self.group_name_key] = "Unknown"
        total_rows = len(self._df)
        assigned_mask = np.zeros(total_rows, dtype=bool)

        logger.info(
            "[BaseConditionDataset] Vectorized grouping (%d rows).", total_rows
        )

        for cfg in self.configs:
            name: str = cfg["name"]
            cond: str = cfg["condition"]
            bs: int = cfg.get("batch_size", 1)

            self.group_map_batch_size[name] = bs
            self.group_map_idx_list[name] = []

            try:
                subset = self._df.query(cond).index.to_numpy()
                valid = subset[~assigned_mask[subset]]
                if len(valid) > 0:
                    self._df.loc[valid, self.group_name_key] = name
                    assigned_mask[valid] = True
                    self.group_map_idx_list[name] = valid.tolist()
                logger.info(
                    "[BaseConditionDataset] Group '%s': %d rows.", name, len(valid)
                )
            except Exception as exc:  # noqa: BLE001
                logger.warning(
                    "[BaseConditionDataset] Group '%s' query failed: %s", name, exc
                )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    def build(self, save_to_csv_kwargs={}, release_dataframe_kwargs={}, *args, **kwargs) -> Any:
        """
        Build condition dataset.

        Args:
            save_to_csv_kwargs (dict, optional): Optional keyword arguments.
            release_dataframe_kwargs (dict, optional): Release dataframe kwargs.

        :return: bool
        """

        self.save_to_csv(**save_to_csv_kwargs)           # while df is still alive
        self.release_dataframe(**release_dataframe_kwargs)
        return True

    def get_records(self, idx: int) -> Dict:
        """Return the data record for a given internal row index.

        Returns Python-native types in both storage modes.  In
        ``as_dict_records=False`` mode the implementation uses
        ``df.iloc[idx]`` (Series path) rather than ``df.iloc[[idx]]``
        (one-row DataFrame path) for roughly 10× lower per-call overhead.

        Args:
            idx (int): Zero-based internal row index.

        Returns:
            Dict: Column → Python-native value.
        """
        if self.as_dict_records:
            return self.data_records[idx]
        return _normalise_row(self._df.iloc[idx])

    def get_original_index(self, idx: int) -> int:
        """Return the upstream DataFrame index for an internal row.

        Args:
            idx (int): Zero-based internal row index.

        Returns:
            int: Value of the ``__original_index__`` column for that row.
        """
        if self.as_dict_records:
            return self.data_records[idx][_ORIGINAL_INDEX_COL]
        return int(self._df.iloc[idx][_ORIGINAL_INDEX_COL])

    def get_group_map_idx_list(self) -> Dict[str, List[int]]:
        """Return the group name → row-index-list mapping."""
        return self.group_map_idx_list

    def get_group_map_batch_size(self) -> Dict[str, int]:
        """Return the group name → batch-size mapping."""
        return self.group_map_batch_size

    def release_dataframe(self,release_now=True,raise_error=True) -> None:
        """Release the internal DataFrame to reclaim memory.

        After this call :attr:`df` returns ``None``.  Any method that still
        requires the DataFrame (e.g. :meth:`save_to_csv` when
        ``as_dict_records=False``) will raise :exc:`RuntimeError`.

        Only valid when ``as_dict_records=True``.  The DataFrame is the sole
        data source in Pandas mode and must never be released.

        Args:
            release_now (bool): If ``True``, release the internal DataFrame
            raise_error (bool): If ``True``, raise an exception if

        Raises:
            RuntimeError: If called when ``as_dict_records=False``.
            RuntimeError: If called more than once.
        """
        if not release_now:
            return
        if not self.as_dict_records:
            if raise_error:
                raise RuntimeError(
                    "Cannot release the DataFrame when as_dict_records=False: "
                    "it is the sole data source."
                )
            else:
                return
        if self._df_released:
            if raise_error:
                raise RuntimeError(
                    "The DataFrame has already been released. "
                    "release_dataframe() must not be called more than once."
                )
            else:
                return
        logger.info("[BaseConditionDataset] Releasing internal DataFrame.")
        self._df_released = True
        self._df = None
        import gc
        gc.collect()

    def save_to_csv(self, output_path: str) -> None:
        """Export the current dataset state to a CSV file.

        When ``as_dict_records=True`` the export is built from
        :attr:`data_records` and is always available, even after the
        DataFrame is released.  When ``as_dict_records=False`` the DataFrame
        must still be alive.

        Args:
            output_path (str): Destination file path.

        Raises:
            RuntimeError: If ``as_dict_records=False`` and the DataFrame has
                been released.
        """
        if not self.is_main:
            return
        logger.info("[BaseConditionDataset] Saving to '%s'.", output_path)
        if self.as_dict_records:
            df_export = pd.DataFrame(self.data_records)
        elif not self._df_released:
            df_export = self._df.copy()
        else:
            raise RuntimeError(
                "Cannot save to CSV: the DataFrame has been released and "
                "as_dict_records=False -- no data source is available."
            )
        df_export.to_csv(output_path, index=False)
        logger.info("[BaseConditionDataset] Saved %d records.", len(df_export))

    # ------------------------------------------------------------------
    # Dataset protocol
    # ------------------------------------------------------------------

    def __len__(self) -> int:
        """Return the total row count (full dataset, not filtered count).

        .. note::
            Use :attr:`group_map_idx_list` in custom samplers to respect
            :meth:`~BaseSequenceConditionDataset.filter_incomplete_sequences`
            results.

        Returns:
            int: Total row count.
        """
        if self.as_dict_records:
            return len(self.data_records)
        return len(self._df)

    def __getitem__(self, idx: int):
        """Retrieve a single sample by index.

        Raises:
            NotImplementedError: Must be overridden in concrete subclasses.
        """
        raise NotImplementedError(
            f"{type(self).__name__} must implement __getitem__."
        )


# =============================================================================
# BaseSequenceConditionDataset
# =============================================================================


class BaseSequenceConditionDataset(BaseConditionDataset):
    """Dataset with time-series sequence association built on condition grouping.

    Adds three capabilities on top of :class:`BaseConditionDataset`:

    1. **Neighbor graph** (:meth:`register_seq_series`) -- builds
       :attr:`seq_series_indices`, shape ``(n_samples, seq_len)``, where
       ``-1`` marks absent steps.
    2. **Vectorised pre-sorting** -- rows sorted once so
       :meth:`get_seq_series_records` is O(seq_len).
    3. **Incomplete-sequence filtering**
       (:meth:`filter_incomplete_sequences`).

    Neighbor graph implementation
    ------------------------------
    ``_build_neighbor_matrix`` uses ``pandas.Series.set_index`` +
    ``reindex`` rather than manual polynomial hashing.  This delegates all
    key construction and collision resolution to Pandas' C-layer MultiIndex
    hash, which is collision-free by design regardless of the magnitude or
    dtype of the key columns.

    Float compare columns are multiplied by ``float_key_scale`` (default
    ``1e6``) and rounded to ``int64`` before key construction.  The same
    scale is applied to the deltas so that per-step subtraction is exact
    integer arithmetic, eliminating precision drift.

    Recommended call order::

        ds.register_seq_series(...)
        ds.filter_incomplete_sequences()
        ds.save_to_csv(...)           # while df is still alive
        ds.release_dataframe()        # reclaim memory

    Args:
        float_key_scale (float):
            Scale factor applied to floating-point compare columns before
            converting them to ``int64`` for exact hashing.
            Default ``1e6`` (microsecond resolution for second-based
            timestamps).  Set to ``1`` for integer-only columns.
        *args, **kwargs:
            Forwarded to :class:`BaseConditionDataset`.

    Attributes:
        seq_series_indices (np.ndarray or None):
            Shape ``(n_samples, seq_len)``, dtype ``int32``.
        ts_seq_len (int):
            ``seq_len`` from the most recent :meth:`register_seq_series`.
        float_key_scale (float):
            The scale factor used for float-column key promotion.

    Example::

        >>> df = pd.DataFrame({
        ...     "id":   [1, 1, 1, 1],
        ...     "time": [10, 20, 30, 40],
        ...     "val":  [0.1, 0.2, 0.3, 0.4],
        ... })
        >>> ds = BaseSequenceConditionDataset(
        ...     meta_pandas_data=df,
        ...     condition_dict_list=[{"name": "all", "condition": "val > 0"}],
        ... )
        >>> ds.register_seq_series(
        ...     match_cols=["id"], compare_cols=["time"],
        ...     compare_deltas=[10], seq_len=2,
        ... )
        >>> ds.filter_incomplete_sequences()
        >>> ds.get_group_map_idx_list()
        {"all": [2, 3]}
    """

    def __init__(self, *args, float_key_scale: float = 1e6, **kwargs) -> None:
        self.float_key_scale = float_key_scale
        self.seq_series_indices: Optional[np.ndarray] = None
        self.ts_seq_len: int = 0
        super().__init__(*args, **kwargs)

    # ------------------------------------------------------------------
    # Public sequence API
    # ------------------------------------------------------------------
    def build(self,
              register_seq_series_kwargs={},
              filter_incomplete_sequences_kwargs={},
              save_to_csv_kwargs={},
              release_dataframe_kwargs={}
              ):
        """
        Build condition dataset.

        :param register_seq_series_kwargs: kwargs for  register_seq_series
        :param filter_incomplete_sequences_kwargs: kwargs for  filter_incomplete_sequences
        :param save_to_csv_kwargs: kwargs for  save_to_csv
        :param release_dataframe_kwargs: kwargs for  release_dataframe
        :return: bool
        """
        self.register_seq_series(**register_seq_series_kwargs)
        self.filter_incomplete_sequences(**filter_incomplete_sequences_kwargs)
        self.save_to_csv(**save_to_csv_kwargs)           # while df is still alive
        self.release_dataframe(**release_dataframe_kwargs)        # reclaim memory
        return True


    def register_seq_series(
            self,
            match_cols: List[str],
            compare_cols: List[str],
            compare_deltas: List[Union[int, float]],
            seq_len: int,
            seq_direction: str = "ascending",
            seq_direction_by: Optional[str] = None,
            finalize: bool = False,
    ) -> None:
        """Build the neighbor graph and pre-sort each row's neighbors.

        For each sample ``i`` and step ``s ∈ [1, seq_len]`` this method looks
        for the row whose ``match_cols`` equal those of row ``i`` and whose
        ``compare_cols`` equal ``row_i_values - delta * s``.  Results are
        stored in ``seq_series_indices[i, s-1]``; ``-1`` when not found.

        .. note::
            Recommended call order to avoid accessing a released DataFrame::

                register_seq_series(...)
                filter_incomplete_sequences()
                save_to_csv(...)
                release_dataframe()

        Args:
            match_cols (List[str]):
                Columns that must match exactly (e.g. a sensor or entity ID).
            compare_cols (List[str]):
                Offset columns (e.g. a timestamp).  Must be the same length
                as ``compare_deltas``.

                .. warning::
                    Floating-point columns are automatically scaled to
                    ``int64`` using ``float_key_scale`` before hashing to
                    avoid accumulation errors from repeated subtraction.
                    Prefer integer timestamps when possible.

            compare_deltas (List[int or float]):
                Per-column step sizes.  Positive → look backward; negative →
                look forward.
            seq_len (int):
                Number of neighbor steps.
            seq_direction (str):
                ``"ascending"`` (oldest first, default) or
                ``"descending"`` (most-recent first).
            seq_direction_by (str, optional):
                Sort-key column; defaults to ``compare_cols[0]``.
            finalize (bool):
                If ``True`` and ``as_dict_records=True``, call
                :meth:`release_dataframe` after building the graph.
                Emits a warning and is silently skipped when
                ``as_dict_records=False``.

        Raises:
            RuntimeError: If the DataFrame has already been released.
            ValueError: If lengths of ``compare_cols`` and
                ``compare_deltas`` differ.
        """
        if self._df_released:
            raise RuntimeError(
                "The internal DataFrame has already been released. "
                "Do not call register_seq_series() after release_dataframe()."
            )

        self.ts_seq_len = seq_len
        self._build_neighbor_matrix(match_cols, compare_cols, compare_deltas, seq_len)

        sort_col = seq_direction_by if seq_direction_by else compare_cols[0]
        self._apply_vectorized_sort(sort_col, seq_direction)

        if finalize:
            if self.as_dict_records:
                self.release_dataframe()
            else:
                logger.warning(
                    "[BaseSequenceConditionDataset] finalize=True ignored: "
                    "as_dict_records=False, DataFrame is the sole data source."
                )
        else:
            logger.info(
                "[BaseSequenceConditionDataset] register_seq_series complete "
                "(finalize=False, DataFrame retained)."
            )

    def filter_incomplete_sequences(self,filter=True) -> None:
        """Remove samples with any missing neighbor from group maps.

        Modifies :attr:`group_map_idx_list` in place.  Does **not** change
        :attr:`data_records` or the backing DataFrame, so :meth:`__len__`
        still returns the full row count.  Custom samplers should iterate
        :attr:`group_map_idx_list` to skip filtered samples.

        This method operates solely on :attr:`seq_series_indices` and can
        be called before or after :meth:`release_dataframe`.  However, if
        you plan to use the filtered indices to look up rows in the
        DataFrame, call this method **before** :meth:`release_dataframe`.

        Args:
            filter (bool): apply filter

        Raises:
            RuntimeError: If :meth:`register_seq_series` has not been called.
        """
        if not filter:
            return
        if self.seq_series_indices is None:
            raise RuntimeError(
                "Call register_seq_series() before filter_incomplete_sequences()."
            )

        complete_mask = ~(self.seq_series_indices == -1).any(axis=1)
        complete_set = set(np.where(complete_mask)[0].tolist())

        total_before = sum(len(v) for v in self.group_map_idx_list.values())
        for name in self.group_map_idx_list:
            self.group_map_idx_list[name] = [
                i for i in self.group_map_idx_list[name] if i in complete_set
            ]
        total_after = sum(len(v) for v in self.group_map_idx_list.values())

        logger.info(
            "[BaseSequenceConditionDataset] filter_incomplete_sequences: "
            "%d / %d samples retained.",
            total_after,
            total_before,
        )

    def get_seq_series_idxs(self,idx):
        # if self.seq_series_indices is None:
        #     return []

        neighbors: np.ndarray = self.seq_series_indices[idx]
        # print(neighbors)
        return neighbors


    def get_seq_series_records(self, idx: int) -> List[Dict]:
        """Return pre-sorted neighbor records for sample ``idx``.

        In ``as_dict_records=False`` mode a single ``df.iloc[valid]`` call
        retrieves all neighbor rows in one C-layer round-trip.

        Args:
            idx (int): Internal row index of the current sample.

        Returns:
            List[Dict]: Neighbor records in ``seq_direction`` order.  Missing
            steps are omitted; the list may be shorter than
            :attr:`ts_seq_len`.  Returns ``[]`` before
            :meth:`register_seq_series` is called.
        """

        neighbors = self.get_seq_series_idxs(idx)

        if self.as_dict_records:
            return [self.data_records[ni] for ni in neighbors if ni != -1]

        valid = neighbors[neighbors != -1]
        if valid.size == 0:
            return []
        return _normalise_records(self._df.iloc[valid])

    # ------------------------------------------------------------------
    # Private: neighbor matrix
    # ------------------------------------------------------------------

    def _build_neighbor_matrix(
            self,
            match_cols: List[str],
            compare_cols: List[str],
            compare_deltas: List[Union[int, float]],
            seq_len: int,
    ) -> None:
        """Construct the (n_samples, seq_len) neighbor index matrix.

        Key design
        ----------
        A lookup ``pd.Series`` is built **once** via ``set_index`` on the
        combined ``match_cols + compare_cols`` key.  Pandas uses its C-layer
        MultiIndex hash for this structure, which is collision-free by design
        regardless of column magnitude, dtype, or cardinality.  This
        eliminates the integer-overflow risk of manual polynomial hashing.

        Per-step arithmetic
        -------------------
        Compare column values are extracted as a 2-D ``int64`` NumPy array
        once before the loop.  Each step applies a single broadcast
        subtraction ``(N, C) - (C,) * step``, which is pure NumPy.  The
        resulting target values are written into a temporary DataFrame for
        ``reindex``; the match columns are broadcast-filled without copying
        the full DataFrame.

        Float precision
        ---------------
        Non-integer compare columns are multiplied by ``self.float_key_scale``
        and rounded to ``int64`` before lookup table construction.  The
        deltas are scaled identically so that subtraction stays exact.

        Args:
            match_cols: Exact-match columns.
            compare_cols: Offset columns.
            compare_deltas: Per-column step sizes.
            seq_len: Number of steps.

        Raises:
            ValueError: Length mismatch between ``compare_cols`` and
                ``compare_deltas``.
            ValueError: If the ``match_cols + compare_cols`` combination is
                not unique across all rows.  Each (match, compare) key must
                identify at most one row; duplicate keys would cause
                ``reindex`` to raise ``ValueError: cannot handle a
                non-unique multi-index``.
        """
        if len(compare_cols) != len(compare_deltas):
            raise ValueError(
                f"compare_cols has {len(compare_cols)} element(s) but "
                f"compare_deltas has {len(compare_deltas)} element(s)."
            )

        join_cols = match_cols + compare_cols
        n_duplicates = self._df[join_cols].duplicated().sum()
        if n_duplicates > 0:
            raise ValueError(
                f"The combination of match_cols {match_cols} and compare_cols "
                f"{compare_cols} is not unique in the DataFrame: "
                f"{n_duplicates} duplicate row(s) found.  "
                f"Each (match, compare) key must identify at most one row."
            )

        n_samples = len(self._df)
        logger.info(
            "[BaseSequenceConditionDataset] Building neighbor matrix "
            "(n_samples=%d, seq_len=%d).",
            n_samples,
            seq_len,
        )

        # ------------------------------------------------------------------
        # 1. Scale float compare columns to int64 for exact key arithmetic.
        # ------------------------------------------------------------------
        has_float = any(
            not np.issubdtype(self._df[c].dtype, np.integer) for c in compare_cols
        )
        if has_float:
            logger.info(
                "[BaseSequenceConditionDataset] Float compare column(s) detected; "
                "scaling by %.0e for exact integer matching.",
                self.float_key_scale,
            )
            compare_int = np.round(
                self._df[compare_cols].to_numpy(dtype=np.float64) * self.float_key_scale
            ).astype(np.int64)
            scaled_deltas = np.array(
                [int(round(d * self.float_key_scale)) for d in compare_deltas],
                dtype=np.int64,
            )
        else:
            compare_int = self._df[compare_cols].to_numpy(dtype=np.int64)
            scaled_deltas = np.array(compare_deltas, dtype=np.int64)

        # ------------------------------------------------------------------
        # 2. Build lookup table once using Pandas C-layer MultiIndex hash.
        #    This is collision-free regardless of value magnitude.
        #
        #    We construct a working copy of the key columns where compare
        #    columns hold the int64-scaled values, then set_index builds the
        #    MultiIndex.  The match columns are left in their original dtype
        #    (string, int, etc.) for correct equality semantics.
        # ------------------------------------------------------------------
        work_df = self._df[match_cols].copy()
        for j, col in enumerate(compare_cols):
            work_df[col] = compare_int[:, j]

        lookup: pd.Series = (
            work_df[join_cols]
            .assign(__row_idx__=np.arange(n_samples))
            .set_index(join_cols)["__row_idx__"]
        )

        # ------------------------------------------------------------------
        # 3. Fill matrix -- per-step arithmetic is pure NumPy broadcast.
        #    Only the compare column values change each step.
        # ------------------------------------------------------------------
        self.seq_series_indices = np.full(
            (n_samples, seq_len), -1, dtype=np.int32
        )

        # Pre-allocate a single template DataFrame so the step loop only
        # overwrites the compare columns in-place rather than allocating
        # a fresh copy on every iteration.
        template_df = self._df[match_cols].copy()
        for col in compare_cols:
            template_df[col] = np.int64(0)   # placeholder column, correct dtype

        for step in range(1, seq_len + 1):
            target_compare = compare_int - scaled_deltas * np.int64(step)  # (N, C)

            for j, col in enumerate(compare_cols):
                template_df[col] = target_compare[:, j]

            target_idx = template_df.set_index(join_cols).index
            matched = lookup.reindex(target_idx)
            valid_indices = np.nan_to_num(matched.values, nan=-1).astype(np.int32)
            self.seq_series_indices[:, step - 1] = valid_indices

    def _apply_vectorized_sort(self, sort_col: str, direction: str) -> None:
        """Sort each row of :attr:`seq_series_indices` by a DataFrame column.

        Sentinel slots (``-1``) are always placed at the *tail* regardless of
        direction.

        A scalar ``+inf`` is appended to the sort-key array so that ``-1``
        slots always map to the largest value.  After ascending ``argsort``,
        for ``"descending"`` only the *valid* prefix of each row is reversed
        so the sentinel tail is undisturbed.

        Args:
            sort_col (str): Column used as sort key (numeric or datetime).
            direction (str): ``"ascending"`` or ``"descending"``.

        Raises:
            ValueError: If ``sort_col`` cannot be cast to ``float64``.
        """
        logger.info(
            "[BaseSequenceConditionDataset] Pre-sorting (%s by '%s').",
            direction,
            sort_col,
        )

        raw = self._df[sort_col].values
        if not np.issubdtype(raw.dtype, np.number):
            if np.issubdtype(raw.dtype, np.datetime64):
                raw = raw.view(np.int64)
            else:
                try:
                    raw = raw.astype(np.float64)
                except Exception as exc:
                    raise ValueError(
                        f"Sort column '{sort_col}' cannot be cast to float64: {exc}"
                    ) from exc

        extended = np.append(raw.astype(np.float64), [np.inf])
        lookup_idx = self.seq_series_indices.copy()
        lookup_idx[lookup_idx == -1] = len(raw)
        value_matrix = extended[lookup_idx]

        sorted_args = np.argsort(value_matrix, axis=1, kind="stable")

        if direction == "descending":
            valid_counts = (self.seq_series_indices != -1).sum(axis=1)
            for i, vc in enumerate(valid_counts):
                if vc > 1:
                    sorted_args[i, :vc] = sorted_args[i, :vc][::-1]

        self.seq_series_indices = np.take_along_axis(
            self.seq_series_indices, sorted_args, axis=1
        )

    # ------------------------------------------------------------------
    # I/O
    # ------------------------------------------------------------------

    def save_to_csv(self, output_path: str = None) -> None:
        """Export data and sequence indices to a CSV file.

        The neighbor index matrix is serialised as a JSON string in a helper
        column ``__seq_indices__``.

        Args:
            output_path (str): Destination file path.

        Raises:
            RuntimeError: If ``as_dict_records=False`` and the DataFrame
                has been released.
        """
        if output_path is None or not self.is_main:
            return
        logger.info(
            "[BaseSequenceConditionDataset] Saving to '%s'.", output_path
        )
        if self.as_dict_records:
            df_export = pd.DataFrame(self.data_records)
        elif not self._df_released:
            df_export = self._df.copy()
        else:
            raise RuntimeError(
                "Cannot save to CSV: the DataFrame has been released and "
                "as_dict_records=False -- no data source is available."
            )
        if self.seq_series_indices is not None:
            df_export["__seq_indices__"] = [
                json.dumps(row.tolist()) for row in self.seq_series_indices
            ]
        Path(output_path).parent.mkdir(parents=True, exist_ok=True)
        df_export.to_csv(output_path, index=False)
        logger.info(
            "[BaseSequenceConditionDataset] Saved %d records.", len(df_export)
        )

