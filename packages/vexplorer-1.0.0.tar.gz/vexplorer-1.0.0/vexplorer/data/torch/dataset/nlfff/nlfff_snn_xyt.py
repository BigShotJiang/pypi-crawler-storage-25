from ..base.condition_dataset import BaseSequenceConditionDataset
import os
import random
import numpy as np
from pathlib import Path
import logging

logger = logging.getLogger(__name__)


class NlfffSnnXYTDataset(BaseSequenceConditionDataset):
    """
    SNN spike-encoded NLFFF dataset (XY+T sequence).

    Loads pre-processed spike data from offline-encoded directories.
    Each .npz file contains a ``data`` array of shape ``(C, H, W)``
    where C = 6 (temporal_diff) or 12 (PIEE).

    Multiple time-step frames are loaded as a sequence (like the regular
    XYT dataset), and the output dict has the spike data under the
    ``dataset_add_key`` as a list of arrays.

    SNN models expect input ``(B, T, C, H, W)`` from the DataLoader.

    Parameters
    ----------
    spike_root : str
        Root directory for pre-processed spike data (e.g.
        ``/data/nlfff3d_npz_f16_clipz_spike_diff_p0.1_n0.1``).
    spike_root_down1 : str, optional
        Root directory for downsampled spike data (optional fallback).
    spike_root_down2 : str, optional
        Root directory for further downsampled spike data.
    """

    def __init__(
            self,
            flareflux_info=(
                    {
                        "pandas_raw_key": [
                            "max_flare_flux_start_0_12h",
                            "max_flare_flux_start_0_24h",
                            "max_flare_flux_start_0_48h",
                            "max_flare_flux_start_0_72h"
                        ],
                        "dataset_add_key": "flare_info",
                    },
            ),
            spike_info=(
                    {
                        "spike_root": "./",
                        "spike_root_down1": None,
                        "spike_root_down2": None,
                        "pandas_sub_path": ["batch_main", "batch_sub", "batch_save"],
                        "dataset_add_key": "bout",
                    },
            ),
            collect_info=None,
            use_mock_data=False,
            mock_data_channels=6,
            mock_data_size=(128, 128),
            mock_data_dtype=np.uint8,
            early_crop_params=None,
            *args,
            **kwargs
    ):
        super().__init__(*args, **kwargs)

        self.use_mock_data = use_mock_data
        self.mock_data_channels = mock_data_channels
        self.mock_data_size = mock_data_size
        self.mock_data_dtype = mock_data_dtype

        if collect_info is None:
            self.data_collect = None
            self.collect_add_key = "data_collect"
        else:
            self.data_collect = collect_info.get("data_collect", None)
            self.collect_add_key = collect_info.get("dataset_add_key", "data_collect")

        self.flareflux_info = flareflux_info
        self.spike_info = spike_info
        self.early_crop_params = early_crop_params or {}

    # ------------------------------------------------------------------
    # Data loading
    # ------------------------------------------------------------------

    @staticmethod
    def _build_path(root, info, row):
        path_list = []
        if root is not None:
            path_list.append(root)
        for sub_path_col_name in info["pandas_sub_path"]:
            sub_path = str(row[sub_path_col_name]).removeprefix('/')
            path_list.append(sub_path)
        if len(path_list) == 0:
            return None
        return str(Path(os.path.join(*path_list)).with_suffix('.npz'))

    def _load_spike_data(self, info, row):
        """Load spike data with root fallback chain."""
        if self.use_mock_data:
            shape = (self.mock_data_channels,) + tuple(self.mock_data_size)
            return np.random.randint(0, 2, size=shape, dtype=self.mock_data_dtype)

        # Try roots in priority order
        roots = [
            info.get("spike_root_down2"),
            info.get("spike_root_down1"),
            info.get("spike_root"),
        ]
        # Filter and reverse: prefer lower ds first, fallback up
        for root in reversed(roots):
            if root is None:
                continue
            path = self._build_path(root, info, row)
            if path and os.path.exists(path):
                return np.load(path)["data"]

        return None

    # ------------------------------------------------------------------
    # Crop helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _calc_crop_offset(current, target, align):
        diff = current - target
        if diff <= 0:
            return 0
        if align == 'start':
            return 0
        if align == 'end':
            return diff
        if align == 'center':
            return diff // 2
        if align == 'random':
            return random.randint(0, diff)
        return 0

    def _compute_crop_slices(self, shape, max_size, align):
        """Crop slices for (C, H, W) data — crops spatial dims only."""
        slices = []
        for i in range(len(max_size)):
            dim_idx = i + 1  # skip C dim
            if dim_idx >= len(shape):
                slices.append(slice(None))
                continue
            cur = shape[dim_idx]
            tgt = min(cur, max_size[i])
            if cur <= tgt:
                slices.append(slice(None))
            else:
                dim_align = (align[i] if isinstance(align, list) and i < len(align)
                             else (align if isinstance(align, str) else 'start'))
                start = self._calc_crop_offset(cur, tgt, dim_align)
                slices.append(slice(start, start + tgt))
        return tuple(slices)

    # ------------------------------------------------------------------
    # Flare helpers
    # ------------------------------------------------------------------

    def deal_flareflux_info(self, info, row, return_tuple=False):
        raw_key = info["pandas_raw_key"]
        add_key = info["dataset_add_key"]
        if isinstance(raw_key, (list, tuple)):
            extracted_value = np.array([row[k] for k in raw_key])
        else:
            extracted_value = row[raw_key]
        if return_tuple:
            return (add_key, extracted_value)
        return {add_key: extracted_value}

    # ------------------------------------------------------------------
    # __getitem__
    # ------------------------------------------------------------------

    def __getitem__(self, idx):
        row = self.get_records(idx)
        grp_key = self.group_name_key
        grp_value = row.get(self.group_name_key, 'Unknown')

        result = {grp_key: grp_value}

        for info in self.flareflux_info:
            r = self.deal_flareflux_info(info, row)
            if r is not None:
                result.update(r)
            else:
                raise Exception(f"can't get {info} {row}")

        seq_info = self.get_seq_series_records(idx)

        for info in self.spike_info:
            crop_params = self.early_crop_params.get(grp_value) if self.early_crop_params else None

            all_rows = list(seq_info) + [row]
            crop_slices = None
            result_seq = []

            for frame_row in all_rows:
                obj_data = self._load_spike_data(info, frame_row)
                if obj_data is None:
                    result_seq.append(None)
                    continue

                # Early crop
                if crop_params and crop_slices is None:
                    max_size = crop_params["max_size"]
                    align = crop_params.get("align", ["start", "start"])
                    crop_slices = self._compute_crop_slices(
                        obj_data.shape, max_size, align
                    )

                if crop_slices is not None:
                    obj_data = obj_data[:, crop_slices[0], crop_slices[1]]
                    obj_data = np.ascontiguousarray(obj_data)

                result_seq.append(obj_data)

            r_name = info["dataset_add_key"]
            if len(result_seq) > 0:
                result.update({r_name: result_seq})
            else:
                raise Exception(f"can't get {info} {row}")

        if self.data_collect is not None:
            d_collect = []
            collect = self.data_collect
            for seq_info_i in seq_info:
                d_collect.append(seq_info_i[collect])
            d_collect.append(row[collect])
            result.update({self.collect_add_key: d_collect})

        if hasattr(self, 'transform') and self.transform is not None:
            self.transform(result)

        return result
