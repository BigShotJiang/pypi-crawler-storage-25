from ..base.condition_dataset import BaseSequenceConditionDataset
import os
import random
import numpy as np
from pathlib import Path
import logging

logger = logging.getLogger(__name__)

class Nlfff3DDatasetXYT(BaseSequenceConditionDataset):
    """
    3D NLFFF dataset (XY+T sequence) with early crop, multi-root downsample,
    and offline clip-z support.

    All preprocess roots live inside each ``bdata_info`` entry::

        bdata_info:
          - bdata_root: "/data/nlfff3d_npz_f16"
            bdata_root_down1: "/data/nlfff3d_npz_f16_down1"
            bdata_root_down2: "/data/nlfff3d_npz_f16_down2"
            bdata_root_clipz: "/data/nlfff3d_npz_f16_clipz"
            bdata_root_clipz_down1: "/data/nlfff3d_npz_f16_clipz_down1"
            bdata_root_clipz_down2: "/data/nlfff3d_npz_f16_clipz_down2"
            pandas_sub_path: [...]
            dataset_add_key: "bout"

    Resolution priority (e.g. ds_times=1):
      clipz_down1 → down1 (with runtime z-slice) → clipz → original (with z-slice)
    """

    def __init__(
            self,
            flareflux_info=(
                    {
                        "pandas_raw_key": [
                            "max_flare_flux_start_0_12h",
                            "max_flare_flux_start_0_24h",
                            "max_flare_flux_start_0_48h",
                            "max_flare_flux_start_0_72h"
                        ],
                        "dataset_add_key": "flare_info",
                    },
            ),
            bdata_info=(
                    {
                        "bdata_root": "./",
                        "pandas_sub_path": ["batch_main","batch_sub","batch_save"],
                        "dataset_add_key": "bout",
                    },
            ),
            collect_info=None,
            use_mock_data=False,
            mock_data_size=(1, 32, 32, 32),
            mock_data_dtype=np.float16,
            early_crop_params=None,
            *args,
            **kwargs
    ):
        super().__init__(*args, **kwargs)

        self.use_mock_data = use_mock_data
        self.mock_data_size = mock_data_size
        self.mock_data_dtype = mock_data_dtype

        if collect_info is None:
            self.data_collect = None
            self.collect_add_key = "data_collect"
        else:
            self.data_collect = collect_info.get("data_collect", None)
            self.collect_add_key = collect_info.get("dataset_add_key", "data_collect")

        self.flareflux_info = flareflux_info
        self.bdata_info = bdata_info
        self.early_crop_params = early_crop_params or {}

    # ------------------------------------------------------------------
    # Data loading helpers
    # ------------------------------------------------------------------

    def load_bdata(self, full_path):
        """Load 3D data and take z=0 slice: (1,H,W,D) → (1,H,W)."""
        obj_data = np.load(full_path)["data"][:,:,:,0]
        return obj_data

    @staticmethod
    def _build_bdata_path(root, info, row):
        path_list = []
        if root is not None:
            path_list.append(root)
        for sub_path_col_name in info["pandas_sub_path"]:
            sub_path = str(row[sub_path_col_name]).removeprefix('/')
            path_list.append(sub_path)
        if len(path_list) == 0:
            return None
        return str(Path(os.path.join(*path_list)).with_suffix('.npz'))

    def _try_load(self, root, info, row, is_clipz):
        """Try loading from a single root.

        Parameters
        ----------
        is_clipz : bool
            If True, data is pre-clipped (already 2D), load as-is.
            If False, load full 3D and apply [:,:,:,0].

        Returns
        -------
        np.ndarray or None
        """
        if root is None:
            return None
        obj_path = self._build_bdata_path(root, info, row)
        if obj_path is None or not os.path.exists(obj_path):
            return None
        if is_clipz:
            return np.load(obj_path)["data"]  # already (1, H, W)
        else:
            return np.load(obj_path)["data"][:,:,:,0]  # (1,H,W,D) → (1,H,W)

    def _load_bdata_with_fallback(self, candidates, info, row):
        """Try loading from ordered candidates list.

        Parameters
        ----------
        candidates : list[tuple[str|None, bool]]
            Each entry is ``(root_path, is_clipz)``.
        """
        if self.use_mock_data:
            return np.random.randn(*self.mock_data_size).astype(self.mock_data_dtype)

        for root, is_clipz in candidates:
            data = self._try_load(root, info, row, is_clipz)
            if data is not None:
                return data
        return None

    # ------------------------------------------------------------------
    # Early crop helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _calc_crop_offset(current, target, align):
        diff = current - target
        if diff <= 0:
            return 0
        if align == 'start':
            return 0
        if align == 'end':
            return diff
        if align == 'center':
            return diff // 2
        if align == 'random':
            return random.randint(0, diff)
        return 0

    def _compute_crop_slices_2d(self, shape, max_size, align):
        """Compute crop slices for spatial dims of a (1, H, W) array."""
        slices = []
        for i in range(len(max_size)):
            dim_idx = i + 1
            if dim_idx >= len(shape):
                slices.append(slice(None))
                continue
            cur = shape[dim_idx]
            tgt = min(cur, max_size[i])
            if cur <= tgt:
                slices.append(slice(None))
            else:
                dim_align = (align[i] if isinstance(align, list) and i < len(align)
                             else (align if isinstance(align, str) else 'start'))
                start = self._calc_crop_offset(cur, tgt, dim_align)
                slices.append(slice(start, start + tgt))
        return tuple(slices)

    @staticmethod
    def _resolve_ds_times(crop_params):
        if not crop_params or not crop_params.get('downsample', False):
            return 0
        ds_times_param = crop_params.get('downsample_times', 1)
        random_ds = crop_params.get('random_downsample', False)
        if isinstance(ds_times_param, list):
            return random.choice(ds_times_param) if random_ds else ds_times_param[0]
        return float(ds_times_param)

    # Ordered downsample levels: highest reduction → lowest.
    # For XYT/XY, each level has a clipz variant (pre-clipped, no z-slice)
    # and a 3D variant (needs runtime z-slice).
    # Each entry: (ds_level, clipz_key, key_3d)
    _DS_LEVELS = [
        (2,   "bdata_root_clipz_down2",   "bdata_root_down2"),
        (1.5, "bdata_root_clipz_down1_5", "bdata_root_down1_5"),
        (1,   "bdata_root_clipz_down1",   "bdata_root_down1"),
        (0,   "bdata_root_clipz",         "bdata_root"),
    ]

    @classmethod
    def _build_root_chain(cls, info, ds_times):
        """Build ordered fallback chain of (root, is_clipz) candidates.

        For each level <= ds_times, tries clipz variant first (fast, 2D),
        then 3D variant (needs z-slice). Falls back to lower levels.

        e.g. ds_times=1.5 → [clipz_down1_5, down1_5(z), clipz_down1, down1(z), clipz, original(z)]
        """
        chain = []
        for level, clipz_key, key_3d in cls._DS_LEVELS:
            if level <= ds_times:
                cz = info.get(clipz_key)
                if cz is not None:
                    chain.append((cz, True))
                k3 = info.get(key_3d)
                if k3 is not None:
                    chain.append((k3, False))
        # Ensure original is always the final fallback
        original = info.get("bdata_root")
        if not any(root == original for root, _ in chain):
            chain.append((original, False))
        return chain

    # ------------------------------------------------------------------
    # Flare helpers
    # ------------------------------------------------------------------

    def deal_flareflux_info(self, info, row, return_tuple=False):
        raw_key = info["pandas_raw_key"]
        add_key = info["dataset_add_key"]
        if isinstance(raw_key, (list, tuple)):
            extracted_value = np.array([row[k] for k in raw_key])
        else:
            extracted_value = row[raw_key]
        if return_tuple:
            return (add_key, extracted_value)
        return {add_key: extracted_value}

    def deal_bdata_info(self, info, row, return_tuple=False):
        path_list = []
        if info["bdata_root"] is not None:
            path_list.append(info["bdata_root"])
        for sub_path_col_name in info["pandas_sub_path"]:
            sub_path = str(row[sub_path_col_name]).removeprefix('/')
            path_list.append(sub_path)
        if len(path_list) == 0:
            logger.error(f"path_list is empty: {info}")
            return
        obj_path = str(Path(os.path.join(*path_list)).with_suffix('.npz'))

        if self.use_mock_data:
            obj_data = np.random.randn(*self.mock_data_size).astype(self.mock_data_dtype)
        else:
            if not os.path.exists(obj_path):
                logger.info(f"{obj_path} does not exist")
                return
            obj_data = self.load_bdata(obj_path)

        if return_tuple:
            return (info["dataset_add_key"], obj_data)
        return {info["dataset_add_key"]: obj_data}

    # ------------------------------------------------------------------
    # __getitem__
    # ------------------------------------------------------------------

    def __getitem__(self, idx):
        row = self.get_records(idx)
        grp_key = self.group_name_key
        grp_value = row.get(self.group_name_key, 'Unknown')

        result = {grp_key: grp_value}

        for info in self.flareflux_info:
            r = self.deal_flareflux_info(info, row)
            if r is not None:
                result.update(r)
            else:
                raise Exception(f"can't get {info} {row}")

        seq_info = self.get_seq_series_records(idx)

        for info in self.bdata_info:
            crop_params = self.early_crop_params.get(grp_value) if self.early_crop_params else None

            if crop_params:
                ds_times = self._resolve_ds_times(crop_params)
                candidates = self._build_root_chain(info, ds_times)

                all_rows = list(seq_info) + [row]
                crop_slices = None
                result_seq = []

                for frame_row in all_rows:
                    obj_data = self._load_bdata_with_fallback(candidates, info, frame_row)
                    if obj_data is None:
                        result_seq.append(None)
                        continue

                    # Compute crop offsets once from first valid frame
                    if crop_slices is None:
                        max_size = crop_params["max_size"]
                        align = crop_params.get("align", ["start", "start"])
                        crop_slices = self._compute_crop_slices_2d(
                            obj_data.shape, max_size, align
                        )

                    # Apply crop — data is (1, H, W) after z-clip
                    obj_data = obj_data[:, crop_slices[0], crop_slices[1]]
                    obj_data = np.ascontiguousarray(obj_data)
                    result_seq.append(obj_data)

                r_name = info["dataset_add_key"]
                if len(result_seq) > 0:
                    result.update({r_name: result_seq})
                else:
                    raise Exception(f"can't get {info} {row}")
            else:
                # ── Original path ──
                result_seq = []
                for seq_info_i in seq_info:
                    _, r = self.deal_bdata_info(info, seq_info_i, return_tuple=True)
                    result_seq.append(r)
                r_name, r = self.deal_bdata_info(info, row, return_tuple=True)
                result_seq.append(r)
                if len(result_seq) > 0:
                    result.update({r_name: result_seq})
                else:
                    raise Exception(f"can't get {info} {row}")

        if self.data_collect is not None:
            d_collect = []
            collect = self.data_collect
            for seq_info_i in seq_info:
                d_collect.append(seq_info_i[collect])
            d_collect.append(row[collect])
            result.update({self.collect_add_key: d_collect})

        if hasattr(self, 'transform') and self.transform is not None:
            self.transform(result)

        return result