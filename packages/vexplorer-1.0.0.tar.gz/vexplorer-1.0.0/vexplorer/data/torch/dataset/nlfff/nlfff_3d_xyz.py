from ..base.condition_dataset import BaseConditionDataset
import os
import random
import logging
import numpy as np
from pathlib import Path

logger = logging.getLogger(__name__)

class Nlfff3DDatasetXYZ(BaseConditionDataset):
    """
    3D NLFFF dataset (single-frame, no sequence) with early crop and
    multi-root downsample support.

    Preprocess roots (``bdata_root_down1``, ``bdata_root_down2``) live
    inside each ``bdata_info`` entry alongside ``bdata_root``.

    bdata_info entry example::

        bdata_info:
          - bdata_root: "/data/nlfff3d_npz_f16"
            bdata_root_down1: "/data/nlfff3d_npz_f16_down1"
            bdata_root_down2: "/data/nlfff3d_npz_f16_down2"
            pandas_sub_path: ["batch_main", "batch_sub", "batch_save"]
            dataset_add_key: "bout"
    """
    def __init__(
            self,
            flareflux_info=(
                    {
                        "pandas_raw_key": [
                            "max_flare_flux_start_0_12h",
                            "max_flare_flux_start_0_24h",
                            "max_flare_flux_start_0_48h",
                            "max_flare_flux_start_0_72h"
                        ],
                        "dataset_add_key": "flare_info",
                    },
            ),
            bdata_info=(
                    {
                        "bdata_root": "./",
                        "pandas_sub_path": ["batch_main","batch_sub","batch_save"],
                        "dataset_add_key": "bout",
                    },
            ),
            collect_info=None,
            use_mock_data=False,
            mock_data_size=(1, 32, 32, 32),
            mock_data_dtype=np.float16,
            early_crop_params=None,
            *args,
            **kwargs
    ):
        super().__init__(*args, **kwargs)

        self.use_mock_data = use_mock_data
        self.mock_data_size = mock_data_size
        self.mock_data_dtype = mock_data_dtype

        if collect_info is None:
            self.data_collect = None
            self.collect_add_key = "data_collect"
        else:
            self.data_collect = collect_info.get("data_collect", None)
            self.collect_add_key = collect_info.get("dataset_add_key", "data_collect")

        self.flareflux_info = flareflux_info
        self.bdata_info = bdata_info
        self.early_crop_params = early_crop_params or {}

    # ------------------------------------------------------------------
    # Data loading helpers
    # ------------------------------------------------------------------

    def load_bdata(self, full_path):
        obj_data = np.load(full_path)["data"]
        return obj_data

    @staticmethod
    def _build_bdata_path(root, info, row):
        """Build the full .npz path from a given root + sub-path columns."""
        path_list = []
        if root is not None:
            path_list.append(root)
        for sub_path_col_name in info["pandas_sub_path"]:
            sub_path = str(row[sub_path_col_name]).removeprefix('/')
            path_list.append(sub_path)
        if len(path_list) == 0:
            return None
        return str(Path(os.path.join(*path_list)).with_suffix('.npz'))

    def _load_bdata_from_root(self, root, info, row):
        """Load bdata from a specific root directory."""
        if self.use_mock_data:
            return np.random.randn(*self.mock_data_size).astype(self.mock_data_dtype)
        obj_path = self._build_bdata_path(root, info, row)
        if obj_path is None or not os.path.exists(obj_path):
            return None
        return self.load_bdata(obj_path)

    def _load_bdata_with_fallback(self, root_chain, info, row):
        """Try loading from each root in *root_chain*; return first success."""
        if self.use_mock_data:
            return np.random.randn(*self.mock_data_size).astype(self.mock_data_dtype)
        for root in root_chain:
            if root is None:
                continue
            data = self._load_bdata_from_root(root, info, row)
            if data is not None:
                return data
        return None

    # ------------------------------------------------------------------
    # Early crop helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _calc_crop_offset(current, target, align):
        diff = current - target
        if diff <= 0:
            return 0
        if align == 'start':
            return 0
        if align == 'end':
            return diff
        if align == 'center':
            return diff // 2
        if align == 'random':
            return random.randint(0, diff)
        return 0

    def _compute_crop_slices(self, shape, max_size, align):
        """Compute crop slices for spatial dims of a (1, H, W, D) array."""
        slices = []
        for i in range(len(max_size)):
            dim_idx = i + 1
            if dim_idx >= len(shape):
                slices.append(slice(None))
                continue
            cur = shape[dim_idx]
            tgt = min(cur, max_size[i])
            if cur <= tgt:
                slices.append(slice(None))
            else:
                dim_align = (align[i] if isinstance(align, list) and i < len(align)
                             else (align if isinstance(align, str) else 'start'))
                start = self._calc_crop_offset(cur, tgt, dim_align)
                slices.append(slice(start, start + tgt))
        return tuple(slices)

    @staticmethod
    def _resolve_ds_times(crop_params):
        if not crop_params or not crop_params.get('downsample', False):
            return 0
        ds_times_param = crop_params.get('downsample_times', 1)
        random_ds = crop_params.get('random_downsample', False)
        if isinstance(ds_times_param, list):
            return random.choice(ds_times_param) if random_ds else ds_times_param[0]
        return float(ds_times_param)

    _DS_LEVELS = [
        (2,   "bdata_root_down2"),
        (1.5, "bdata_root_down1_5"),
        (1,   "bdata_root_down1"),
        (0,   "bdata_root"),
    ]

    @classmethod
    def _build_root_chain(cls, info, ds_times):
        """Build ordered fallback chain: preferred → original."""
        chain = []
        for level, key in cls._DS_LEVELS:
            if level <= ds_times:
                root = info.get(key)
                if root is not None:
                    chain.append(root)
        original = info.get("bdata_root")
        if original not in chain:
            chain.append(original)
        return chain

    # ------------------------------------------------------------------
    # Flare helpers (unchanged)
    # ------------------------------------------------------------------

    def deal_flareflux_info(self, info, row, return_tuple=False):
        raw_key = info["pandas_raw_key"]
        add_key = info["dataset_add_key"]
        if isinstance(raw_key, (list, tuple)):
            extracted_value = np.array([row[k] for k in raw_key])
        else:
            extracted_value = row[raw_key]
        if return_tuple:
            return (add_key, extracted_value)
        return {add_key: extracted_value}

    def deal_bdata_info(self, info, row, return_tuple=False):
        path_list = []
        if info["bdata_root"] is not None:
            path_list.append(info["bdata_root"])
        for sub_path_col_name in info["pandas_sub_path"]:
            sub_path = str(row[sub_path_col_name]).removeprefix('/')
            path_list.append(sub_path)
        if len(path_list) == 0:
            logger.error(f"path_list is empty: {info}")
            return

        obj_path = str(Path(os.path.join(*path_list)).with_suffix('.npz'))

        if self.use_mock_data:
            obj_data = np.random.randn(*self.mock_data_size).astype(self.mock_data_dtype)
        else:
            if not os.path.exists(obj_path):
                logger.info(f"{obj_path} does not exist")
                return
            obj_data = self.load_bdata(obj_path)

        if return_tuple:
            return (info["dataset_add_key"], obj_data)
        return {info["dataset_add_key"]: obj_data}

    # ------------------------------------------------------------------
    # __getitem__
    # ------------------------------------------------------------------

    def __getitem__(self, idx):
        row = self.get_records(idx)
        grp_key = self.group_name_key
        grp_value = row.get(self.group_name_key, 'Unknown')

        result = {grp_key: grp_value}

        for info in self.flareflux_info:
            r = self.deal_flareflux_info(info, row)
            if r is not None:
                result.update(r)
            else:
                raise Exception(f"can't get {info} {row}")

        for info in self.bdata_info:
            crop_params = self.early_crop_params.get(grp_value) if self.early_crop_params else None

            if crop_params:
                ds_times = self._resolve_ds_times(crop_params)
                root_chain = self._build_root_chain(info, ds_times)

                obj_data = self._load_bdata_with_fallback(root_chain, info, row)
                if obj_data is None:
                    raise Exception(f"can't get {info} {row}")

                max_size = crop_params["max_size"]
                align = crop_params.get("align", ["start", "start", "start"])
                crop_slices = self._compute_crop_slices(obj_data.shape, max_size, align)

                obj_data = obj_data[:, crop_slices[0], crop_slices[1], crop_slices[2]]
                obj_data = np.ascontiguousarray(obj_data)
                result.update({info["dataset_add_key"]: obj_data})
            else:
                r = self.deal_bdata_info(info, row)
                if r is not None:
                    result.update(r)
                else:
                    raise Exception(f"can't get {info} {row}")

        if self.data_collect is not None:
            collect = self.data_collect
            result.update({self.collect_add_key: row[collect]})

        return result