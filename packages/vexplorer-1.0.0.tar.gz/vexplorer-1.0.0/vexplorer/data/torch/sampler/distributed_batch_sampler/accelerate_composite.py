import math
import copy
import torch
import torch.distributed as dist
from torch.utils.data import Sampler, BatchSampler, RandomSampler, SequentialSampler
from typing import Dict, List, Iterator, Optional
import logging

logger = logging.getLogger(__name__)

class AccelerateCompositeBatchSampler(BatchSampler):
    r"""
    A dynamic, Accelerate-compatible Composite BatchSampler for complex heterogeneous datasets.

    This sampler is designed for distributed training scenarios (DDP) where multiple datasets
    of varying lengths need to be sampled together in specific combinations. It utilizes a
    **"Dynamic Calculation + Runtime Padding"** architecture, meaning it never mutates the
    underlying dataset lists. Instead, it dynamically catches `StopIteration` during runtime
    to loop or pad data according to strict mathematical rules.

    If providing custom group_samplers, ensure they are initialized with the same torch.Generator instance
    passed to this class, otherwise set_epoch will not synchronize their random states across DDP processes.

    The length and batch yield strategies strictly follow these rules:

    1. **If ``drop_last=True``:**
        * The sampler length is divided by ``batch_size * world_size``.
        * If remainder > 0 and ``pad_mode='as_batch'``: The remainder is dropped.
        * If remainder > 0 and ``pad_mode='as_one'``: The remainder is divided by ``world_size``.
          These form trailing batches of size 1. Any sub-remainder is dropped.

    2. **If ``drop_last=False``:**
        * If remainder > 0 and ``cycle=True``: The group restarts its iterator and appends
          data until it fulfills the full ``batch_size * world_size`` requirement.
        * If remainder > 0 and ``cycle=False``:
            * ``pad_mode='as_batch'``: Restarts and appends to fulfill ``batch_size * world_size``.
            * ``pad_mode='as_one'``: Restarts and appends to fulfill a multiple of ``world_size``,
              then yields these as trailing batches of size 1.

    Args:
        dataset (Dataset, optional): The main dataset object. If provided, must implement
            ``get_group_map_idx_list()`` and ``get_group_map_batch_size()``.
        group_map_idx_list (Dict[str, List[int]], optional): A dictionary mapping group names to
            their global dataset indices. Required if ``dataset`` is None.
        group_map_batch_size (Dict[str, int], optional): A dictionary mapping group names to
            their local batch size per GPU. Required if ``dataset`` is None.
        group_samplers (Dict[str, Sampler], optional): A dictionary of custom PyTorch Samplers
            for specific groups. If not provided for a group, defaults to RandomSampler or
            SequentialSampler based on ``shuffle``.
        merge_groups (List[List[str]], optional): A list defining how groups are combined in each
            training step. Defaults to all groups combined in a single step.
        rank (int, optional): The rank of the current process. Auto-detected if None.
        num_replicas (int, optional): Number of processes participating in distributed training.
            Auto-detected if None.
        shuffle (bool, optional): If ``True``, uses ``RandomSampler`` for groups lacking a custom
            sampler. If ``False``, uses ``SequentialSampler``. Default: ``True``.
        seed (int, optional): The base random seed. Default: ``0``.
        generator (torch.Generator, optional): An external PyTorch Generator. If provided, this
            ensures deterministic synchronization between parent and sub-samplers.
        start_epoch (int, optional): The epoch number to start the training from. Default: 0.
        cycle (bool, optional): If ``True``, exhausted groups will restart their iterators to
            pad the batch to the required size. Default: ``True``.
        debug_len (int, optional): If > 0, truncates all group indices to this length for
            fast debugging. Default: ``-1``.
        drop_last (bool, optional): If ``True``, incomplete batches at the end of the dataset
            are dropped based on ``pad_mode``. Default: ``False``.
        pad_mode (str, optional): The padding strategy for remainders. Can be ``'as_batch'``
            (pads up to standard batch size) or ``'as_one'`` (extracts tail as batch size 1).
            Default: ``'as_batch'``.
        need_rank_select_outside (bool, optional):
            * If ``True``: Yields batches for ALL ranks (Expected by Accelerate's ``prepare``).
            * If ``False``: Yields ONLY the batch for the current ``rank``. Default: ``True``.

    Example:
        >>> group_idx = {'A': [0, 1, 2, 3, 4], 'B': [5, 6, 7]}
        >>> group_bs = {'A': 2, 'B': 1}
        >>> # Assuming world_size = 2
        >>> sampler = AccelerateCompositeBatchSampler(
        ...     group_map_idx_list=group_idx,
        ...     group_map_batch_size=group_bs,
        ...     drop_last=False, cycle=True, need_rank_select_outside=False
        ... )
        >>> for batch in sampler:
        ...     print(batch) # Yields local batch tailored for the specific process rank.
    """
    def __init__(self,
                 dataset = None,
                 group_map_idx_list: Dict[str, List[int]] = None,
                 group_map_batch_size: Dict[str, int] = None,
                 group_samplers: Optional[Dict[str, Sampler]] = None,
                 merge_groups: Optional[List[List[str]]] = None,
                 rank: Optional[int] = None,
                 num_replicas: Optional[int] = None,
                 shuffle: bool = True,
                 seed: int = 0,
                 generator: Optional[torch.Generator] = None,
                 start_epoch: int = 0,
                 cycle: bool = True,
                 debug_len: int = -1,
                 drop_last: bool = False,
                 pad_mode: str = 'as_batch',
                 need_rank_select_outside: bool = True,
                 *args, **kwargs
                 ):

        # 0. Safety Checks & Mappings resolution
        if dataset is not None:
            group_map_idx_list = dataset.get_group_map_idx_list()
            group_map_batch_size = dataset.get_group_map_batch_size()
        elif not group_map_idx_list or not group_map_batch_size:
            raise ValueError("[Sampler] Initialization failed: mappings are empty.")

        # 1. Resolve Distributed status (world_size & rank)
        if num_replicas is None:
            if dist.is_available() and dist.is_initialized():
                self.num_replicas = dist.get_world_size()
            else:
                self.num_replicas = 1
        else:
            self.num_replicas = num_replicas

        self.group_map_idx_list = copy.deepcopy(group_map_idx_list)
        self.group_map_batch_size = copy.deepcopy(group_map_batch_size)

        # Apply debug truncation if requested
        if debug_len > 0:
            for name in self.group_map_idx_list:
                self.group_map_idx_list[name] = self.group_map_idx_list[name][:debug_len]

        self.cycle = cycle
        self.drop_last = drop_last
        self.pad_mode = pad_mode
        self.shuffle = shuffle
        self.epoch = start_epoch

        self.main_group_names = sorted(list(self.group_map_idx_list.keys()))
        self.merge_groups = merge_groups if merge_groups else [self.main_group_names]

        # Generator handling: Ensure consistent RNG state across parent and children
        if generator is not None:
            self.generator = generator
        else:
            self.generator = torch.Generator()
        self.seed = seed
        self.generator.manual_seed(self.seed+self.epoch)

        # Initialize sub-samplers based on defined rules
        self.group_samplers: Dict[str, Sampler] = {}
        if group_samplers is None:
            group_samplers = {}

        for name in self.main_group_names:
            global_indices = self.group_map_idx_list[name]
            if len(global_indices) == 0:
                raise ValueError(f"[Sampler] Group '{name}' has 0 samples.")

            if name in group_samplers:
                # Use externally provided sampler
                self.group_samplers[name] = group_samplers[name]
            else:
                # Create default PyTorch samplers, using the shared generator if shuffling
                dummy_ds = range(len(global_indices))
                if self.shuffle:
                    self.group_samplers[name] = RandomSampler(dummy_ds, generator=self.generator)
                else:
                    self.group_samplers[name] = SequentialSampler(dummy_ds)

        # Perform mathematical pre-calculation of batch steps
        self._calculate_steps()

        # Initialize the parent BatchSampler (Requires a dummy sampler and max expected batch size)
        max_nominal_bs = max([sum(self.group_map_batch_size[n] for n in c) for c in self.merge_groups])
        super().__init__(sampler=SequentialSampler([]), batch_size=max_nominal_bs, drop_last=False)

        # Validate and set rank selection logic
        self.rank = rank
        self.need_rank_select_outside = need_rank_select_outside
        if self.need_rank_select_outside:
            if self.rank is not None:
                raise ValueError("[Sampler] need_rank_select_outside is True, so rank parameter must be None.")
            else:
                logger.info("Setting need_rank_select_outside: True. Yielding batches for all ranks.")
        else:
            if self.rank is not None:
                logger.info(f"Setting rank {self.rank}. Yielding strictly for this rank.")
            else:
                if dist.is_available() and dist.is_initialized():
                    self.rank = dist.get_rank()
                else:
                    if self.num_replicas > 1:
                        raise ValueError("Not dist initialized, num_replicas cannot be > 1.")
                    self.num_replicas = 1
                    self.rank = 0

    def set_epoch(self, epoch: int) -> None:
        r"""
        Sets the epoch for the sampler.

        **Crucial in distributed training**: Calling this at the beginning of each epoch
        ensures that all replicas use a synchronized random seed for their generators,
        preventing dataset misalignment and NCCL deadlocks.

        Args:
            epoch (int): The current epoch number.
        """
        self.epoch = epoch
        # 可以在这里显式更新（会同步外部传入的种子，自定义采样器跟着一起，如果还有其他也会更新)，推荐在 __iter__ 中再设置作为最终防线
        self.generator.manual_seed(self.seed + self.epoch)

    def _calculate_steps(self) -> None:
        r"""
        Dynamically calculates the exact number of main batches and tail batches per group.

        This relies entirely on the sub-sampler's ``__len__`` and executes the mathematical
        logic defined by the user (Rules 1.1 to 2.1.2.2). It computes the target iteration
        limits without altering the underlying data arrays.
        """
        self.group_main_steps = {}
        self.group_tail_steps = {}

        for name in self.main_group_names:
            sampler = self.group_samplers[name]
            L = len(sampler)
            bs = self.group_map_batch_size[name]
            W = self.num_replicas
            global_bs = bs * W

            main_b = L // global_bs
            rem = L % global_bs
            tail_b = 0

            # Branch 1: drop_last == True
            if self.drop_last:
                if rem > 0:
                    if self.pad_mode == 'as_batch':
                        # Rule 1.1.1: End group iteration (Main batches remain, no tail)
                        pass
                    elif self.pad_mode == 'as_one':
                        # Rule 1.1.2: Remainder floor-divided by world_size (batch_size=1)
                        tail_b = rem // W
                        # Rule 1.1.2.1: Any leftover from the tail division is implicitly dropped

            # Branch 2: drop_last == False
            else:
                if rem > 0:
                    if self.cycle:
                        # Rule 2.1.1: Start next iteration, append until global_bs multiple is met
                        main_b += 1
                    else:
                        # Rule 2.1.2: cycle == False
                        if self.pad_mode == 'as_batch':
                            # Rule 2.1.2.1: Start next iteration, append until global_bs multiple is met
                            main_b += 1
                        elif self.pad_mode == 'as_one':
                            # Rule 2.1.2.2: Append until world_size multiple is met, tails act as bs=1
                            tail_b = math.ceil(rem / W)

            self.group_main_steps[name] = main_b
            self.group_tail_steps[name] = tail_b

        # Compute max main_steps across merged groups (Phase 1)
        self.main_steps = 0
        for comb in self.merge_groups:
            comb_max = max([self.group_main_steps[g] for g in comb]) if comb else 0
            self.main_steps = max(self.main_steps, comb_max)

        # Compute Accelerate total expectations (all processes combined)
        self.total_batches = self.main_steps * self.num_replicas

        self.phase2_batches = 0
        for name in self.main_group_names:
            self.phase2_batches += self.group_tail_steps[name] * self.num_replicas

    def __iter__(self) -> Iterator[List[int]]:
        r"""
        Returns an iterator over the batches of dataset indices.

        This method coordinates the fetching of indices from the individual sub-samplers.
        It traps ``StopIteration`` exceptions internally to seamlessly restart group iterators
        when runtime padding is required by the current configuration.

        Yields:
            List[int]: A batch of global indices. If ``need_rank_select_outside=False``,
            it yields ONLY the batch slice corresponding to the current process rank.
        """
        # Sync the internal generator state across DDP processes

        self.generator.manual_seed(self.seed + self.epoch)
        for s in self.group_samplers.values():
            if hasattr(s, "set_epoch"):
                s.set_epoch(self.epoch)

        iterators = {name: iter(sampler) for name, sampler in self.group_samplers.items()}

        def get_mini_batch(group_name: str, target_size: int) -> List[int]:
            """Helper function to extract 'target_size' indices, handling auto-restarts."""
            batch_local_idx = []
            global_indices = self.group_map_idx_list.get(group_name, [])
            if not global_indices:
                raise ValueError(f"Group {group_name} has no indices. Check your dataset.")
            while len(batch_local_idx) < target_size:
                try:
                    local_idx = next(iterators[group_name])
                except StopIteration:
                    # RUNTIME PADDING TRIGGER
                    # Implicitly fulfills the rule: "start next iteration and append"
                    iterators[group_name] = iter(self.group_samplers[group_name])
                    try:
                        local_idx = next(iterators[group_name])
                    except StopIteration:
                        # 极端兜底：如果重启后依然拿不到数据（通常不会发生，除非采样器逻辑异常）
                        # 使用该组的第一个索引强制补齐，确保 Batch 能够组成 Tensor
                        local_idx = 0
                        logger.warning(f"Sampler {group_name} exhausted immediately after reset. Using index 0 as padding.")
                batch_local_idx.append(global_indices[local_idx])
            return batch_local_idx

        # Phase 1: Main Groups Yielding
        for step in range(self.main_steps):
            current_comb = self.merge_groups[step % len(self.merge_groups)]
            for replica_id in range(self.num_replicas):
                super_batch = []
                for name in current_comb:
                    bs = self.group_map_batch_size[name]
                    # If the group is physically shorter than main_steps requires,
                    # get_mini_batch naturally catches StopIteration and restarts it.
                    super_batch.extend(get_mini_batch(name, bs))

                # Rank Filtering Logic
                if self.need_rank_select_outside or replica_id == self.rank:
                    yield super_batch

        # Phase 2: Tail Yielding (Active when pad_mode == 'as_one')
        for name in self.main_group_names:
            tail_steps = self.group_tail_steps[name]
            for _ in range(tail_steps):
                for replica_id in range(self.num_replicas):
                    # Tail batches enforce a fixed batch size of 1 per replica
                    batch = get_mini_batch(name, 1)
                    if self.need_rank_select_outside or replica_id == self.rank:
                        yield batch

    def __len__(self) -> int:
        r"""
        Returns the expected number of batches yielded by this sampler.

        **Important Interaction with Accelerate/PyTorch**:
        If ``need_rank_select_outside=True``, it returns the total number of batches across
        ALL ranks (as Accelerate's ``prepare()`` will slice it later).
        If ``False``, it returns the exact, scaled-down batch count intended for this single GPU,
        ensuring progress bars (like tqdm) calculate the epoch end correctly.

        Returns:
            int: The calculated number of batches.
        """
        if self.need_rank_select_outside:
            return self.total_batches + self.phase2_batches
        else:
            return (self.total_batches // self.num_replicas) + (self.phase2_batches // self.num_replicas)


