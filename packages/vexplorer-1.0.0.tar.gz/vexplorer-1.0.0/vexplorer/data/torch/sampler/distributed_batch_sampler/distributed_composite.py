import math
import copy
import torch
import torch.distributed as dist
import numpy as np
from torch.utils.data.distributed import DistributedSampler
from torch.utils.data import BatchSampler
from typing import Dict, List, Iterator, Optional, Union
import logging
logger = logging.getLogger(__name__)


class DistributedCompositeBatchSampler(DistributedSampler[List[int]]):
    r"""
    A Distributed-Aware Composite Batch Sampler for sampling from multiple groups with different batch sizes.

    This sampler is designed for scenarios where a dataset consists of multiple groups (e.g., different
    aspect ratios, different sources) and you need to form batches that:
    1. Comprise specific numbers of samples from each group (e.g., 2 images from Group A, 4 from Group B).
    2. Work correctly in a Distributed Data Parallel (DDP) environment without hanging or data duplication.
    3. Handle 'Validation' (Cycle=False) and 'Training' (Cycle=True) modes differently.

    Args:
        dataset (Dataset): Dataset to sample from, if not set must give group_map_idx_list and group_map_batch_size.
        group_map_idx_list (Dict[str, List[int]]): A dictionary mapping group names to a list of global indices.
            Example: ``{'large': [0, 1, 2], 'small': [3, 4, 5]}``
        group_map_batch_size (Dict[str, int]): A dictionary mapping group names to their local batch size.
            Example: ``{'large': 2, 'small': 4}``
        rank (int, optional): The rank of the current process. If None, attempts to retrieve from ``torch.distributed``.
            Defaults to 0 if DDP is not initialized.
        num_replicas (int, optional): The total number of processes also as world_size. If None, attempts to retrieve from ``torch.distributed``.
            Defaults to 1 if DDP is not initialized.
        shuffle (bool): Whether to shuffle the data at the beginning of each epoch. Default: ``True``.
        reshuffle_cycle (bool): If ``True`` and ``cycle=True``, reshuffles the data every time a group is exhausted
            and restarts. Default: ``True``.
        merge_groups (Optional[List[List[str]]]):
            A list of group combinations defining which groups are yielded together in a single super-batch step.
            This is highly useful for alternating between different tasks or resolutions to prevent OOM (Out Of Memory).
            - If ``None`` (default), all groups are merged into a single combination, meaning every super-batch
              contains data from all groups. Equivalent to: ``[['A', 'B', 'C']]``.
            - Example (Alternating): ``[['A'], ['B']]`` means Step 1 yields only group 'A', Step 2 yields only group 'B'.
            - Example (Mixed): ``[['A', 'B'], ['C']]`` means Step 1 yields 'A' and 'B', Step 2 yields 'C'.

        cycle (bool):

            - If ``True`` (Train mode): Shorter groups repeat indefinitely to match the length of the longest group.
              Ensures every batch contains data from all groups.
            - If ``False`` (Eval mode): Performs global trimming and tail collection.
              1. Trims all groups so their count is divisible by ``batch_size * num_replicas``.
              2. Collects all trimmed 'leftover' data into a special ``__Leftover_Group__``.
              3. Runs the main groups first, then runs the leftovers (with batch_size=1 per GPU) to ensure
              no data is wasted and no deadlocks occur.

        seed (int): Random seed base. The actual seed used is ``seed + epoch``. Default: ``0``.

    Example:
        >>> # Simulated Data
        >>> idx_map = {'A': list(range(20)), 'B': list(range(10))}
        >>> bs_map = {'A': 2, 'B': 1}
        >>> # Initialize Sampler
        >>> sampler = DistributedCompositeBatchSampler(group_map_idx_list=idx_map, group_map_batch_size=bs_map, num_replicas=2, rank=0, cycle=False)
        >>> # Iterate
        >>> for batch in sampler:
        ...     print(batch)
    """

    def __init__(self,
                 dataset = None,
                 group_map_idx_list: Dict[str, List[int]] = None ,
                 group_map_batch_size: Dict[str, int] = None ,
                 merge_groups: Optional[List[List[str]]] = None,
                 rank: Optional[int] = None,
                 num_replicas: Optional[int] = None,
                 shuffle: bool = True,
                 reshuffle_cycle: bool = True,
                 cycle: bool = True,
                 seed: int = 0,
                 start_epoch: int = 0,
                 debug_len: int = -1,
                 drop_last: bool = False,
                 single_rank_compatible = True,
                 leftover_group_name = "__Leftover_Group__",
                 *args, **kwargs
                 ):

        try:
            super().__init__(
                dataset=dataset,
                num_replicas=num_replicas,
                rank=rank,
                shuffle=shuffle,
                seed=seed,
                drop_last=drop_last,
            )
        except Exception as e:
            if single_rank_compatible:
                self.dataset = dataset
                self.shuffle = shuffle
                self.seed = seed
                self.num_replicas = 1
                self.rank = 0
                if dataset is None and dist.is_available():
                    self.num_replicas = dist.get_world_size()
                    self.rank = dist.get_rank()
            else:
                raise Exception(e)

        logger.debug(f"debug len {debug_len}")
        # 重写super
        self.epoch = start_epoch
        self.drop_last = drop_last
        # 重写super 不支持的参数，下面为sampler参数
        self.num_samples = None
        self.total_size = None
        # ----- 上面为兼容 DistributedSampler ----

        # 新参数
        self.reshuffle = reshuffle_cycle
        self.cycle = cycle

        if self.dataset is not None:
            group_map_idx_list = self.dataset.get_group_map_idx_list()
            group_map_batch_size = self.dataset.get_group_map_batch_size()
        elif group_map_idx_list is None or group_map_batch_size is None:
            raise ValueError("Must specify either dataset or group_map_idx_list + group_map_batch_size")
        if set(group_map_idx_list.keys()) != set(group_map_batch_size.keys()):
            raise ValueError("[Sampler] Keys mismatch between index list and batch size maps.")

        # Deepcopy to prevent modifying external data
        self.group_map_idx_list = copy.deepcopy(group_map_idx_list)
        self.group_map_batch_size = copy.deepcopy(group_map_batch_size)
        self.debug_len = debug_len
        if self.debug_len > 0:
            for name in self.group_map_idx_list:
                self.group_map_idx_list[name] = self.group_map_idx_list[name][:self.debug_len]

        # Define Group Combinations
        all_keys = list(self.group_map_idx_list.keys())
        self.merge_groups = merge_groups if merge_groups else [all_keys]
        self.main_group_names = all_keys
        self.leftover_group_name = leftover_group_name
        self.has_leftover = False

        self._check_and_validate()

        # 3. Handle Validation Mode Logic (Global Alignment)
        if not self.cycle:
            self._rebalance_data_globally()

        # 4. Pre-calculate Steps
        self.main_steps = 0
        self.leftover_steps = 0
        self._calculate_steps()

        # 兼容 BatchSampler
        # 不支持
        self.sampler = None
        # 已经设置
        # self.drop_last = drop_last
        # 计算一个名义上的 batch_size
        # 如果 merge_groups 存在，取当前所有可能组合中最大的 batch 总量
        if merge_groups:
            max_bs = 0
            for comb in merge_groups:
                comb_bs = sum(self.group_map_batch_size[name] for name in comb)
                max_bs = max(max_bs, comb_bs)
            self.batch_size = max_bs
        else:
            self.batch_size = sum(self.group_map_batch_size.values())

        self.need_rank_select_outside = False


    def _check_and_validate(self) -> None:
        """
        Validates the integrity of the input arguments to prevent silent failures
        or deeply nested runtime errors.
        """
        # 1. 检查输入是否为空
        if not self.group_map_idx_list or not self.group_map_batch_size:
            raise ValueError("[DistributedCompositeBatchSampler] group_map_idx_list and group_map_batch_size cannot be empty.")

        # 2. 检查字典的 Keys 是否完全匹配
        idx_keys = set(self.group_map_idx_list.keys())
        bs_keys = set(self.group_map_batch_size.keys())
        if idx_keys != bs_keys:
            raise ValueError(f"[DistributedCompositeBatchSampler] Keys mismatch! "
                             f"idx_list keys: {idx_keys}, batch_size keys: {bs_keys}")

        # 3. 检查 Batch Size 是否为合法正整数
        for name, bs in self.group_map_batch_size.items():
            if not isinstance(bs, int) or bs <= 0:
                raise ValueError(f"[DistributedCompositeBatchSampler] Invalid batch size for group '{name}'. "
                                 f"Expected a positive integer, got {bs}.")

        # 4. 检查 merge_groups 里有没有写错（不存在的）组名
        for comb in self.merge_groups:
            if not isinstance(comb, list):
                raise TypeError(f"[DistributedCompositeBatchSampler] merge_groups must be a List[List[str]], got {type(comb)}.")
            for name in comb:
                if name not in idx_keys:
                    raise KeyError(f"[DistributedCompositeBatchSampler] Group '{name}' found in merge_groups "
                                   f"but does not exist in group_map_idx_list.")

    def set_epoch(self, epoch: int) -> None:
        """
        Sets the epoch for the current iteration. This ensures that the random shuffle
        is different for each epoch but consistent across all DDP ranks.

        Args:
            epoch (int): The current epoch number.
        """
        self.epoch = epoch

    def next_epoch(self) -> None:
        """
        Add the epoch for the current iteration. This ensures that the random shuffle
        is different for each epoch but consistent across all DDP ranks.

        """
        self.epoch += 1

    def _rebalance_data_globally(self) -> None:
        """
        Internal method for 'cycle=False'.
        Trims data to be globally divisible by num_replicas and collects leftovers.
        """
        leftovers: List[int] = []
        # Find a safe padding index (min index)
        all_indices_flat = [idx for indices in self.group_map_idx_list.values() for idx in indices]
        pad_idx = min(all_indices_flat) if all_indices_flat else 0

        # Phase A: Trim Main Groups
        for name in self.main_group_names:
            indices = self.group_map_idx_list[name]
            bs = self.group_map_batch_size[name]
            global_bs = bs * self.num_replicas

            remainder = len(indices) % global_bs
            if remainder > 0:
                # Keep aligned part
                self.group_map_idx_list[name] = indices[:-remainder]
                # Collect tail
                leftovers.extend(indices[-remainder:])

        # Phase B: Create Leftover Group
        if leftovers:
            self.has_leftover = True
            # Leftover strategy: BS=1 per GPU => Global BS = WorldSize
            leftover_global_bs = self.num_replicas
            l_remainder = len(leftovers) % leftover_global_bs

            # Pad leftovers to ensure they don't hang DDP
            if l_remainder > 0:
                pad_num = leftover_global_bs - l_remainder
                leftovers.extend([pad_idx] * pad_num)

            self.group_map_idx_list[self.leftover_group_name] = leftovers
            self.group_map_batch_size[self.leftover_group_name] = 1

    def _calculate_steps(self) -> None:
        # 1. 计算每个组如果单独跑完，需要多少 steps
        group_needed_steps = {}
        for name in self.main_group_names:
            indices = self.group_map_idx_list[name]
            global_bs = self.group_map_batch_size[name] * self.num_replicas
            group_needed_steps[name] = math.ceil(len(indices) / global_bs) if len(indices) > 0 else 0

        # 2. 统计每个组在 merge_groups 里的出现次数
        occurrence_counts = {name: 0 for name in self.main_group_names}
        for comb in self.merge_groups:
            for name in comb:
                occurrence_counts[name] += 1

        # 3. 计算为了跑完“最难跑完”的那一组，总共需要多少个全局 step
        # 公式：总步数 = max(该组所需步数 / (该组出现次数 / 组合总数))
        total_main_steps = 0
        num_combs = len(self.merge_groups)

        for name, needed in group_needed_steps.items():
            if occurrence_counts[name] > 0:
                # 实际上是：needed * (num_combs / occurrence_counts[name])
                steps_to_finish_this_group = math.ceil(needed * num_combs / occurrence_counts[name])
                logger.debug(f"Finish {name} with {steps_to_finish_this_group} steps.")
                total_main_steps = max(total_main_steps, steps_to_finish_this_group)


        self.main_steps = total_main_steps

        # 修复：必须在这里计算 leftover_steps
        if self.has_leftover:
            indices = self.group_map_idx_list[self.leftover_group_name]
            # Leftover 组的 global batch size 就是 num_replicas (每卡 bs=1)
            self.leftover_steps = math.ceil(len(indices) / self.num_replicas)


    def _create_batches(self, name: str, generator: torch.Generator) -> List[List[int]]:
        """
        Generates a list of batches for the *current rank* using a deterministic generator.

        Args:
            name (str): Group name.
            generator (torch.Generator): Generator seeded with epoch + base_seed.

        Returns:
            List[List[int]]: A list of local batches (indices).
        """
        global_indices = self.group_map_idx_list[name]
        bs = self.group_map_batch_size[name]
        global_bs = bs * self.num_replicas

        if not global_indices:
            return []

        # 1. Global Shuffle (Must be identical across all ranks)
        indices_to_shuffle = global_indices[:]
        if self.shuffle:
            perm = torch.randperm(len(indices_to_shuffle), generator=generator).tolist()
            indices_to_shuffle = [indices_to_shuffle[i] for i in perm]

        # 2. 对齐策略 (Train/Eval 区分)
        if self.cycle:
            # [Train 模式]: 零数据丢失策略 (Wrap-around Padding)

            # A. 极小样本保底：如果总数不够一个 global batch，先倍增
            if len(indices_to_shuffle) < global_bs:
                multiplier = math.ceil(global_bs / len(indices_to_shuffle))
                indices_to_shuffle = indices_to_shuffle * multiplier

            # B. 动态环绕补齐
            remainder = len(indices_to_shuffle) % global_bs
            if remainder > 0:
                pad_num = global_bs - remainder
                # 取当前 Epoch 打乱后的头部，补到尾部
                indices_to_shuffle.extend(indices_to_shuffle[:pad_num])
        else:
            # [Eval 模式]: 严格不重复评估策略
            # 理论上经过 __init__ 中的 _rebalance_data_globally，remainder 必然为 0。
            # 这里加一个保守截断（drop_last）作为极端情况的保底防护。
            remainder = len(indices_to_shuffle) % global_bs
            if remainder > 0:
                cutlen = len(indices_to_shuffle) - remainder
                indices_to_shuffle = indices_to_shuffle[:cutlen]

        # 3. DDP Slicing (Assign specific subset to current rank)
        # 此时 len(indices_to_shuffle) 绝对是 num_replicas 的整数倍
        local_indices = indices_to_shuffle[self.rank :: self.num_replicas]

        # 4. Local Batching
        batches = [local_indices[i:i+bs] for i in range(0, len(local_indices), bs)]
        return batches

    def _generator(self, name: str, generator: torch.Generator) -> Iterator[List[int]]:
        """
        Yields batches for a specific group. Handles cycling if enabled.
        """
        # Initial batch generation
        batches = self._create_batches(name, generator)

        if not self.cycle:
            # Eval mode: Yield once and stop
            for b in batches: yield b
        else:
            # Train mode: Infinite loop
            while True:
                for b in batches: yield b

                # Safety break for empty groups
                if not batches: break

                if self.reshuffle and self.shuffle:
                    # Regenerate batches with new random state (generator state advances)
                    batches = self._create_batches(name, generator)

    def __iter__(self) -> Iterator[List[int]]:
        """
        Iterates through the sampler.
        
        Returns:
            Iterator[List[int]]: Yields a super-batch (list of indices from all groups).
        """
        # 1. Setup Generator with Epoch Seed
        g = torch.Generator()
        g.manual_seed(self.seed + self.epoch)

        # -----------------------------------------------------------
        # 自动递增 Epoch
        # 在这里 +1，是为了保证下一次调用 iter() (即下一个 epoch) 时，
        # epoch 变量已经变了，从而产生不同的随机种子。
        # -----------------------------------------------------------
        # self.epoch += 1


        # 2. Create Iterators for all groups
        all_groups = self.main_group_names + ([self.leftover_group_name] if self.has_leftover else [])
        iterators = {name: self._generator(name, g) for name in all_groups}

        # 3. Phase 1: Main Groups (Parallel)
        for step in range(self.main_steps):
            super_batch = []
            current_comb = self.merge_groups[step % len(self.merge_groups)]

            for name in current_comb:
                try:
                    batch = next(iterators[name])
                    if batch: super_batch.extend(batch)
                except StopIteration:
                    pass
            # Only yield if we collected data
            if super_batch: yield super_batch

        # 4. Phase 2: Leftover Group (Sequential, Eval mode only)
        if not self.cycle and self.has_leftover:
            for _ in range(self.leftover_steps):
                try:
                    batch = next(iterators[self.leftover_group_name])
                    if batch: yield batch
                except StopIteration:
                    break

    def __len__(self) -> int:
        """Returns the number of batches in an epoch."""
        if self.cycle:
            return self.main_steps
        else:
            return self.main_steps + self.leftover_steps


