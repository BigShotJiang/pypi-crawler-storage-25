
from .base_processor import BaseProcessor

class BaseProcessorManager(BaseProcessor):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def add_processor(self, name, processor: BaseProcessor, build = False):
        pass

    def del_processor(self, name):
        pass

    def build(self):
        pass

