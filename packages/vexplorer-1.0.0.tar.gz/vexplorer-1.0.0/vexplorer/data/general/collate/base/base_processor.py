# -*- coding: utf-8 -*-
from typing import List, Any, Union, Optional
from abc import ABC, abstractmethod


class BaseProcessor(ABC):
    """Abstract base class for data processors (collators).

    This class defines the interface for processing a list of samples into a batch.
    Subclasses that support multi-level masking may accept an optional ``optional_list``
    parameter in their ``__call__`` implementation.
    """

    @abstractmethod
    def __call__(
        self,
        batch_list: List[Any],
        optional_list: Optional[List[Any]] = None,
    ) -> Any:
        """Process a list of data elements.

        Args:
            batch_list: A list of samples to process.
            optional_list:  Optional per-sample masks for multi-level stacking.
                        Not all subclasses use this parameter; those that
                        do not may safely ignore it.

        Returns:
            The processed batch (e.g., stacked Tensor, or ``(data, mask)`` tuple).
        """
        raise NotImplementedError
