from setuptools import setup, find_packages

setup(
    name="vexplorer",
    version="1.0.0",
    packages=find_packages(),
    package_data={
        '': ['*.yaml', '*.yml'],
    },
    install_requires=[
        "torch", "torchvision", "accelerate", 
        "pyyaml"
    ],
    entry_points={
        'console_scripts': [
            'vexplorer=vexplorer.cli:main',
        ],
    },
)


