"""Inference post-processing contracts."""

