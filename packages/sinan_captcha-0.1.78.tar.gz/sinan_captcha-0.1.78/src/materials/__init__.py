"""Offline materials pack helpers."""

