"""Prediction command helpers."""
