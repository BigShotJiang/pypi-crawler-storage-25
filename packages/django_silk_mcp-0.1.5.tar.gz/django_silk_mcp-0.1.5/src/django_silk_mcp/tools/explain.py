from django.db import connection
from mcp.types import ToolAnnotations
from mcp_server.djangomcp import DjangoMCP
from silk.models import SQLQuery as SilkSQLQuery

from django_silk_mcp.helpers import (
    _mcp_error,
    _requote_sql_for_explain,
    _resolve_request,
    _to_mcp_result,
)
from django_silk_mcp.types import ExplainResult

_ANNOTATIONS = ToolAnnotations(readOnlyHint=True, idempotentHint=False)


def register(mcp: DjangoMCP) -> None:
    @mcp.tool(title="EXPLAIN ANALYZE Slow Queries", annotations=_ANNOTATIONS)
    def explain_slow_queries(
        request_path: str = "", request_id: str = "", threshold_ms: float = 50.0
    ) -> list[ExplainResult]:
        """
        Run EXPLAIN (ANALYZE, BUFFERS) on queries slower than threshold_ms for request_path.
        Reveals missing indexes, sequential scans, and bad join strategies.
        Only runs on SELECT queries to avoid side effects.

        Pass request_id (from get_slow_requests/compare_requests) to pin analysis to a
        specific request instead of the most recent one matching request_path.
        """
        req = _resolve_request(request_path, request_id)
        if not req:
            return _mcp_error(
                f"No recorded requests matching '{request_path}'. Hit the endpoint first."
            )

        slow_qs = SilkSQLQuery.objects.filter(request=req, time_taken__gte=threshold_ms).order_by(
            "-time_taken"
        )
        if not slow_qs:
            return _mcp_error(f"No queries slower than {threshold_ms}ms for '{request_path}'.")

        results = []
        with connection.cursor() as cursor:
            for q in slow_qs:
                sql = q.query.strip()
                if not sql.upper().startswith("SELECT"):
                    results.append(
                        {
                            "time_ms": round(float(q.time_taken), 2),
                            "sql_preview": sql[:120],
                            "explain": "Skipped — only SELECT queries are explained.",
                        }
                    )
                    continue
                try:
                    explain_sql = _requote_sql_for_explain(sql)
                    cursor.execute(f"EXPLAIN (ANALYZE, BUFFERS, FORMAT TEXT) {explain_sql}")
                    plan = "\n".join(row[0] for row in cursor.fetchall())
                except Exception as e:
                    plan = f"Error running EXPLAIN: {e}"
                results.append(
                    {
                        "time_ms": round(float(q.time_taken), 2),
                        "sql_preview": sql[:120] + ("..." if len(sql) > 120 else ""),
                        "explain_analyze": plan,
                    }
                )
        return _to_mcp_result(results)
