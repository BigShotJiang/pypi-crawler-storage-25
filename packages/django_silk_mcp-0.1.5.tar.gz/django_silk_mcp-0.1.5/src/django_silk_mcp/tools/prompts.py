from mcp_server.djangomcp import DjangoMCP


def register(mcp: DjangoMCP) -> None:
    @mcp.prompt(
        name="profile_endpoint",
        title="Profile an Endpoint",
        description=(
            "Full performance analysis workflow for a given endpoint. "
            "Determines whether it is DB-bound or Python-bound and guides investigation."
        ),
    )
    def profile_endpoint(path: str) -> list[dict]:
        """Guided performance profiling workflow for a Django endpoint."""
        return [
            {
                "role": "user",
                "content": {
                    "type": "text",
                    "text": (
                        f"Analyze the performance of `{path}`:\n\n"
                        "1. Run `get_request_time_breakdown` to see if it is DB-bound"
                        " or Python-bound.\n"
                        "2. If DB-bound (≥60% DB time):\n"
                        "   a. Run `get_duplicate_queries` to check for N+1 patterns.\n"
                        "   b. Run `get_query_sources` to find which code lines triggered"
                        " each query.\n"
                        "   c. Run `explain_slow_queries` for EXPLAIN ANALYZE on slow queries.\n"
                        "   d. Run `get_overfetched_fields` to find columns to defer with"
                        " .only().\n"
                        "3. If Python-bound (high python_ms, low db_ms):\n"
                        "   a. Run `get_python_profiles` for @silk_profile block timings.\n"
                        "   b. Run `get_cprofile_hotspots` for function-level CPU profiling.\n"
                        "4. Summarize: what is slow, why, and what to fix — with code pointers."
                    ),
                },
            }
        ]

    @mcp.prompt(
        name="find_n_plus_one",
        title="Find N+1 Queries",
        description=(
            "Detect N+1 query patterns for an endpoint and identify the exact code lines to fix."
        ),
    )
    def find_n_plus_one(path: str) -> list[dict]:
        """Targeted N+1 detection and fix guidance for a Django endpoint."""
        return [
            {
                "role": "user",
                "content": {
                    "type": "text",
                    "text": (
                        f"Detect N+1 query patterns on `{path}`:\n\n"
                        "1. Run `get_duplicate_queries` to identify repeated query templates.\n"
                        "2. For each N+1 group, run `get_query_sources` with `table_filter`"
                        " set to the affected table to find the triggering code line.\n"
                        "3. Explain the N+1 pattern — which relation is missing"
                        " `select_related` or `prefetch_related`.\n"
                        "4. Show the fix: the queryset line and the correct annotation to add."
                    ),
                },
            }
        ]

    @mcp.prompt(
        name="compare_optimization",
        title="Verify an Optimization",
        description=(
            "Compare request timing before and after an optimization to confirm improvement."
        ),
    )
    def compare_optimization(path: str) -> list[dict]:
        """Before/after performance comparison workflow after applying an optimization."""
        return [
            {
                "role": "user",
                "content": {
                    "type": "text",
                    "text": (
                        f"Verify the optimization applied to `{path}`:\n\n"
                        "1. Run `compare_requests` to see the last several distinct requests,"
                        " ordered newest-first with burst deduplication.\n"
                        "2. Compare `total_ms`, `db_ms`, and `num_queries` across requests —"
                        " look for a clear drop after the optimization was deployed.\n"
                        "3. If still slow, re-run `get_duplicate_queries` and"
                        " `explain_slow_queries` to identify remaining bottlenecks.\n"
                        "4. Report: did the optimization improve performance? By how much"
                        " (absolute ms and percentage)? Any remaining issues?"
                    ),
                },
            }
        ]
