from importlib.resources import files

from mcp_server.djangomcp import DjangoMCP

_SKILL_MD = files("django_silk_mcp").joinpath("SKILL.md").read_text(encoding="utf-8")


def register(mcp: DjangoMCP) -> None:
    @mcp.resource(
        "silk://guide",
        name="silk_profiler_guide",
        title="Silk Profiler Workflow Guide",
        description=(
            "Complete workflow guide: tools reference, diagnosis steps, "
            "summary table format, worktree strategy, and context-saving rules."
        ),
        mime_type="text/markdown",
    )
    def silk_profiler_guide() -> str:
        """Full workflow guide for the Silk Profiler MCP server."""
        return _SKILL_MD
