from collections import defaultdict

from mcp.types import ToolAnnotations
from mcp_server.djangomcp import DjangoMCP
from silk.models import SQLQuery as SilkSQLQuery

from django_silk_mcp.helpers import (
    _get_serializer_fields,
    _mcp_error,
    _parse_columns_by_table,
    _resolve_request,
    _to_mcp_result,
)
from django_silk_mcp.types import OverfetchResult

try:
    from rest_framework.serializers import Serializer  # noqa: F401

    HAS_DRF = True
except ImportError:
    HAS_DRF = False

_ANNOTATIONS = ToolAnnotations(readOnlyHint=True, idempotentHint=False)


def register(mcp: DjangoMCP) -> None:
    @mcp.tool(title="Overfetched SQL Columns vs Serializer Fields", annotations=_ANNOTATIONS)
    def get_overfetched_fields(request_path: str = "", request_id: str = "") -> OverfetchResult:
        """
        Compare columns fetched by SQL against fields exposed by the serializer.
        Identifies candidates for .only() to avoid loading unused columns.

        WARNING: Adding .only() can cause extra queries if anything outside the serializer
        accesses a deferred field (signals, permissions, __str__, etc.). Always verify first.

        Pass request_id (from get_slow_requests/compare_requests) to pin analysis to a
        specific request instead of the most recent one matching request_path.
        """
        req = _resolve_request(request_path, request_id)
        if not req:
            return _mcp_error(
                f"No recorded requests matching '{request_path}'. Hit the endpoint first."
            )

        queries = SilkSQLQuery.objects.filter(request=req)
        all_fetched: dict[str, list[str]] = defaultdict(list)
        for q in queries:
            if not q.query.upper().strip().startswith("SELECT"):
                continue
            for table, cols in _parse_columns_by_table(q.query).items():
                for col in cols:
                    if col not in all_fetched[table]:
                        all_fetched[table].append(col)

        if HAS_DRF:
            serializer_fields = _get_serializer_fields(req.path)
        else:
            serializer_fields = None

        serializer_info = (
            serializer_fields
            if serializer_fields is not None
            else (
                "DRF not installed — serializer introspection unavailable, compare manually."
                if not HAS_DRF
                else "Could not auto-resolve serializer — compare manually."
            )
        )

        return _to_mcp_result(
            {
                "path": req.path,
                "sql_columns_by_table": {t: sorted(c) for t, c in all_fetched.items()},
                "serializer_fields": serializer_info,
                "note": (
                    "Columns in sql_columns_by_table that are absent from serializer_fields "
                    "are candidates for .only(). Verify no signal/permission/method accesses "
                    "them before applying — deferred field access causes an extra query per row."
                ),
            }
        )
