import json
import re
from collections import defaultdict

from django.db.models import FloatField, OuterRef, Subquery, Sum
from django.urls import Resolver404, resolve
from mcp.types import CallToolResult, TextContent
from silk.models import Request as SilkRequest
from silk.models import SQLQuery as SilkSQLQuery


def _mcp_error(message: str) -> CallToolResult:
    """Return a tool error result with isError=True.

    Prefer returning this over raising exceptions from tool functions so that
    the error reaches the LLM as an actionable in-band message (isError: true)
    rather than being wrapped with a noisy "Error executing tool X:" prefix.
    """
    return CallToolResult(
        content=[TextContent(type="text", text=message)],
        isError=True,
    )


def _to_mcp_result(data: object) -> object:
    """Round-trip through JSON to produce a value safe for MCP structuredContent.

    Converts non-serializable types (Decimal, datetime, UUID) to strings via
    json.dumps default=str, then parses back to a plain Python object.
    """
    return json.loads(json.dumps(data, default=str))


def _get_latest_request(path: str) -> SilkRequest | None:
    # Priority: exact path + GET → exact path (any method) → contains + GET → contains (any method)
    for filters in [
        {"path": path, "method": "GET"},
        {"path": path},
        {"path__contains": path, "method": "GET"},
        {"path__contains": path},
    ]:
        req = SilkRequest.objects.filter(**filters).order_by("-start_time").first()
        if req:
            return req
    return None


def _resolve_request(request_path: str = "", request_id: str = "") -> SilkRequest | None:
    """Resolve a request by ID (exact) or by path (latest match). ID takes priority."""
    if request_id:
        return SilkRequest.objects.filter(id=request_id).first()
    if request_path:
        return _get_latest_request(request_path)
    return None


def _db_time_subquery() -> Subquery:
    """Subquery that returns total SQL time for a given Request pk."""
    return Subquery(
        SilkSQLQuery.objects.filter(request=OuterRef("pk"))
        .values("request")
        .annotate(total=Sum("time_taken"))
        .values("total"),
        output_field=FloatField(),
    )


def _req_db_ms(req: SilkRequest) -> float:
    """Compute total DB time for a single request by summing its SQL queries."""
    result = SilkSQLQuery.objects.filter(request=req).aggregate(total=Sum("time_taken"))
    return float(result["total"] or 0)


def _filter_project_frames(traceback_str: str) -> list[str]:
    """Return only frames from project code, stripping Django/lib internals."""
    if not traceback_str:
        return []
    result = []
    lines = traceback_str.splitlines()
    for i, line in enumerate(lines):
        if "site-packages" in line or "/lib/python" in line:
            continue
        stripped = line.strip()
        if stripped.startswith("File "):
            result.append(stripped)
            if i + 1 < len(lines):
                code_line = lines[i + 1].strip()
                if code_line:
                    result.append(f"  → {code_line}")
    return result


def _parse_columns_by_table(sql: str) -> dict[str, list[str]]:
    """
    Extract SELECT columns grouped by table from Django-generated SQL.
    Looks only at the SELECT clause to avoid picking up WHERE/JOIN columns.
    """
    sql_upper = sql.upper()
    select_idx = sql_upper.find("SELECT ")
    # Find FROM at the top level (not inside a subquery)
    from_idx = sql_upper.find("\nFROM ", select_idx)
    if from_idx == -1:
        from_idx = sql_upper.find(" FROM ", select_idx)
    if select_idx == -1 or from_idx == -1:
        return {}

    select_part = sql[select_idx + 7 : from_idx]
    # Django always quotes identifiers as "table_name"."column_name"
    pattern = r'"(\w+)"\."(\w+)"'
    matches = re.findall(pattern, select_part)
    grouped: dict[str, list[str]] = defaultdict(list)
    for table, column in matches:
        if column not in grouped[table]:
            grouped[table].append(column)
    return dict(grouped)


def _get_serializer_fields(path: str) -> list[str] | None:
    """Attempt to resolve URL → ViewSet/APIView → serializer field names."""
    try:
        match = resolve(path)
        # DRF ViewSet (router-generated views expose .cls)
        view_cls = getattr(match.func, "cls", None)
        # DRF APIView exposes .view_class
        if not view_cls:
            view_cls = getattr(match.func, "view_class", None)
        if not view_cls:
            return None
        serializer_cls = getattr(view_cls, "serializer_class", None)
        if not serializer_cls:
            return None
        return list(serializer_cls().fields.keys())
    except (Resolver404, Exception):
        return None


_SQL_KEYWORDS = frozenset(
    {
        "AND",
        "OR",
        "NOT",
        "NULL",
        "TRUE",
        "FALSE",
        "IN",
        "IS",
        "AS",
        "FROM",
        "WHERE",
        "JOIN",
        "ON",
        "SELECT",
        "LIMIT",
        "OFFSET",
        "ORDER",
        "GROUP",
        "BY",
        "HAVING",
        "UNION",
        "DISTINCT",
        "CASE",
        "WHEN",
        "THEN",
        "ELSE",
        "END",
        "ANY",
        "ALL",
        "INNER",
        "LEFT",
        "RIGHT",
        "OUTER",
        "CROSS",
        "RETURNING",
        "EXCEPT",
        "INTERSECT",
    }
)


def _requote_sql_for_explain(sql: str) -> str:
    """
    Re-quote parameters that silk/psycopg2 stored without quotes so that
    EXPLAIN (ANALYZE) can parse the SQL.

    Silk stores the final rendered SQL (as Django formats it for display), which
    omits quotes around many literal types. PostgreSQL rejects these when running
    EXPLAIN, so we patch each case with targeted regex substitutions.

    Cases handled:
      1.  Bare UUIDs:              ed9a7e8d-…    →  'ed9a7e8d-…'
      2.  Empty equality param:    = )           →  = '')
      3.  Unquoted string values:  = matter_stub →  = 'matter_stub'
                                   = WIPO Madrid →  = 'WIPO Madrid'
      4.  Bare IN-list identifiers: IN (a, b, c) →  IN ('a', 'b', 'c')
                                    IN (office action, watch) → IN ('office action', 'watch')
      5.  Unquoted regex argument: , \\d+)        →  , '\\d+')
      6.  Bare datetime+timezone:  > 2026-03-24 11:14:03.4+00:00  →  > '2026-03-24 …'
      7.  Bare date:               = 2026-03-24  →  = '2026-03-24'
      8.  Empty comma argument:    , ,           →  , '',
      9.  Empty aggregate delimiter before ORDER BY:
                                   STRING_AGG(x, \n ORDER BY) → STRING_AGG(x, '' ORDER BY)
      10. Unquoted value with hyphens after =:
                                   = hernany-costillas → = 'hernany-costillas'
      11. Unquoted THEN value in CASE expressions:
                                   THEN trademark → THEN 'trademark'
                                   THEN United States → THEN 'United States'
      12. Empty array literal:     []::uuid[]    →  '{}'::uuid[]
      13. Bare JSONB text key:     (docket_id)::text  →  'docket_id'::text
      14. Bare trailing func arg:  COALESCE(x, unknown)  →  COALESCE(x, 'unknown')
    """
    # Matches a UUID not already wrapped in single quotes.
    bare_uuid_pattern = (
        r"(?<!')\b([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})\b(?!')"
    )
    sql = re.sub(bare_uuid_pattern, r"'\1'", sql, flags=re.IGNORECASE)

    # Matches an equality operator with nothing before the closing paren: = )
    empty_equality_param_pattern = r"=\s*\)"
    sql = re.sub(empty_equality_param_pattern, "= '')", sql)

    # Matches an unquoted word/phrase after =, stopping at SQL keywords or punctuation.
    # Handles Django TextChoices and other bare string values (e.g. = unresolved, = WIPO Madrid).
    # WHEN and THEN are included in the lookahead so that CASE expression keywords are not
    # consumed as part of the value (e.g. "= opposition THEN dispute WHEN" must not quote
    # "opposition THEN dispute" as a single value — it should stop at THEN).
    unquoted_string_after_eq_pattern = (
        r"=\s+([A-Za-z][A-Za-z0-9_ ]*?)"
        r"(?=\s*(?:AND\b|OR\b|THEN\b|WHEN\b|ORDER\b|GROUP\b|LIMIT\b"
        r"|HAVING\b|WHERE\b|JOIN\b|FROM\b|\)|,|\n|$))"
    )

    def _quote_bare_value(m: re.Match) -> str:
        value = m.group(1).rstrip()
        if value.upper() in _SQL_KEYWORDS:
            return m.group(0)
        return f"= '{value}'"

    sql = re.sub(unquoted_string_after_eq_pattern, _quote_bare_value, sql, flags=re.IGNORECASE)

    # Matches IN (...) lists containing only bare identifiers (not subqueries or integers).
    # Allows multi-word items with spaces and hyphens to handle TextChoices like
    # "office action responses" or "post-registration office action responses".
    bare_in_list_pattern = (
        r"\bIN\s*\(\s*([A-Za-z][A-Za-z0-9_ -]*(?:\s*,\s*[A-Za-z][A-Za-z0-9_ -]*)*)\s*\)"
    )

    def _quote_in_list(m: re.Match) -> str:
        items = [item.strip() for item in m.group(1).split(",")]
        quoted = [
            f"'{item}'" if not item.startswith("'") and item.upper() not in _SQL_KEYWORDS else item
            for item in items
        ]
        return f"IN ({', '.join(quoted)})"

    sql = re.sub(bare_in_list_pattern, _quote_in_list, sql, flags=re.IGNORECASE)

    # Matches an unquoted regex string passed as a function argument (e.g. Django Cast with \d+).
    unquoted_regex_arg_pattern = r",\s*(\\[a-zA-Z][^\s)]*)"
    sql = re.sub(unquoted_regex_arg_pattern, lambda m: f", '{m.group(1)}'", sql)

    # Matches a bare datetime with optional fractional seconds and timezone offset/Z.
    # Must run before the bare-date rule so the full timestamp is captured first.
    bare_datetime_pattern = (
        r"(?<!')\b(\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:[+-]\d{2}:\d{2}|Z)?)(?!')"
    )
    sql = re.sub(bare_datetime_pattern, r"'\1'", sql)

    # Matches a bare date value not already inside quotes.
    bare_date_pattern = r"(?<!')\b(\d{4}-\d{2}-\d{2})\b(?!')"
    sql = re.sub(bare_date_pattern, r"'\1'", sql)

    # Matches two consecutive commas with only whitespace between them — an empty positional arg.
    empty_comma_arg_pattern = r",\s*,"
    sql = re.sub(empty_comma_arg_pattern, ", '',", sql)

    # Matches an empty aggregate delimiter that silk stored as blank whitespace before ORDER BY.
    empty_aggregate_delimiter_pattern = r",(\s*\n\s*)(ORDER\s+BY\b)"
    sql = re.sub(empty_aggregate_delimiter_pattern, r", '' ORDER BY", sql, flags=re.IGNORECASE)

    # Matches an unquoted value with hyphens/dots/at-signs after = (e.g. slugs, emails).
    unquoted_hyphenated_value_pattern = (
        r"=\s+([A-Za-z][A-Za-z0-9._@-]+)"
        r"(?=\s*(?:AND\b|OR\b|ORDER\b|GROUP\b|LIMIT\b|HAVING\b|WHERE\b|JOIN\b|FROM\b|\)|,|\n|$))"
    )
    sql = re.sub(unquoted_hyphenated_value_pattern, r"= '\1'", sql, flags=re.IGNORECASE)

    # Matches an unquoted bare string in a CASE THEN clause.
    unquoted_then_value_pattern = (
        r"\bTHEN\s+([A-Za-z][A-Za-z0-9_ ]*?)" r"(?=\s*(?:WHEN\b|ELSE\b|END\b|\)|,|\n|$))"
    )

    def _quote_then_value(m: re.Match) -> str:
        value = m.group(1).rstrip()
        if value.upper() in _SQL_KEYWORDS:
            return m.group(0)
        return f"THEN '{value}'"

    sql = re.sub(unquoted_then_value_pattern, _quote_then_value, sql, flags=re.IGNORECASE)

    # Matches an empty array literal that silk stores as [] without the ARRAY keyword.
    empty_array_literal_pattern = r"\[\]::(\w+\[\])"
    sql = re.sub(empty_array_literal_pattern, r"'{}'::\1", sql)

    # Matches a bare identifier wrapped in parens and cast to ::text, used as a JSONB key.
    bare_text_cast_pattern = r"\(([A-Za-z][A-Za-z0-9_]+)\)::text"
    sql = re.sub(bare_text_cast_pattern, r"'\1'::text", sql)

    # Matches a bare single-word string literal passed as a trailing function argument.
    bare_trailing_func_arg_pattern = r",\s*([A-Za-z][A-Za-z0-9_]*)\s*\)"

    def _quote_trailing_func_arg(m: re.Match) -> str:
        value = m.group(1)
        if value.upper() in _SQL_KEYWORDS:
            return m.group(0)
        return f", '{value}')"

    sql = re.sub(bare_trailing_func_arg_pattern, _quote_trailing_func_arg, sql)

    return sql


def _normalize_query(sql: str) -> str:
    """Replace literals with placeholders to detect structurally identical queries."""
    sql = re.sub(r"'[^']*'", "?", sql)
    # Bare UUIDs (Django omits quotes for UUID fields in psycopg2)
    sql = re.sub(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", "?", sql)
    sql = re.sub(r"\b\d+\b", "?", sql)
    return re.sub(r"\s+", " ", sql).strip()
