"""TypedDicts for tool output shapes.

Used as return type annotations so FastMCP auto-generates outputSchema for
each tool. Clients and LLMs can use these schemas to validate and parse
structured tool responses.
"""

from typing import NotRequired

from typing_extensions import (
    TypedDict,  # noqa: UP035 — Pydantic requires typing_extensions.TypedDict on Python < 3.12
)

# ---------------------------------------------------------------------------
# discovery.py
# ---------------------------------------------------------------------------


class EndpointStats(TypedDict):
    path: str
    method: str
    avg_total_ms: float
    avg_db_ms: float
    avg_python_ms: float
    avg_query_count: float
    request_count: int


class SlowQuery(TypedDict):
    request_id: str | None
    time_ms: float
    request_path: str | None
    request_method: str | None
    sql: str


class SlowRequest(TypedDict):
    request_id: str
    path: str
    method: str
    total_ms: float
    db_ms: float
    python_ms: float
    num_queries: int
    start_time: str


class RequestRow(TypedDict):
    request_id: str
    start_time: str
    method: str
    total_ms: float
    db_ms: float
    python_ms: float
    num_queries: int


class CompareRequestsResult(TypedDict):
    path: str
    requests_newest_first: list[RequestRow]
    note: str
    tip: str


# ---------------------------------------------------------------------------
# analysis.py
# ---------------------------------------------------------------------------


class TimeBreakdownResult(TypedDict):
    path: str
    method: str
    total_ms: float
    db_ms: float
    db_pct: float
    python_ms: float
    python_pct: float
    num_queries: int
    verdict: str


class DuplicateQueryExample(TypedDict):
    time_ms: float
    sql: str


class DuplicateQueryGroup(TypedDict):
    occurrences: int
    total_ms: float
    query_template: str
    examples: list[DuplicateQueryExample]


class QueryItem(TypedDict):
    """A single SQL query entry; sql is present when summary_only=False, sql_preview otherwise."""

    time_ms: float
    sql: NotRequired[str]
    sql_preview: NotRequired[str]


class RequestQueriesResult(TypedDict):
    path: str
    method: str
    total_ms: float
    db_ms: float
    num_queries: int
    queries: list[QueryItem]


class QuerySource(TypedDict):
    time_ms: float
    sql_preview: str
    project_frames: list[str]


# ---------------------------------------------------------------------------
# profiling.py
# ---------------------------------------------------------------------------


class ProfileBlock(TypedDict):
    name: str
    func_name: str
    file_path: str | None
    line_num: int | None
    time_ms: float
    db_ms: float
    python_ms: float
    num_queries: int
    exception_raised: bool


class PythonProfilesResult(TypedDict):
    path: str
    profile_blocks: list[ProfileBlock]
    tip: str


class CProfileEntry(TypedDict):
    ncalls: str
    tottime_s: float
    cumtime_s: float
    location: str


class CProfileHotspotsResult(TypedDict):
    path: str
    top_functions_by_cumtime: list[CProfileEntry]
    note: str


# ---------------------------------------------------------------------------
# explain.py
# ---------------------------------------------------------------------------


class ExplainResult(TypedDict):
    time_ms: float
    sql_preview: str
    explain_analyze: NotRequired[str]
    explain: NotRequired[str]


# ---------------------------------------------------------------------------
# overfetch.py
# ---------------------------------------------------------------------------


class OverfetchResult(TypedDict):
    path: str
    sql_columns_by_table: dict[str, list[str]]
    serializer_fields: list[str] | str
    note: str
