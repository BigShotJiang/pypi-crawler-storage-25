from django.urls import re_path
from mcp_server.views import MCPServerStreamableHttpView
from rest_framework.permissions import AllowAny

from django_silk_mcp.server import create_server

_mcp = create_server()

urlpatterns = [
    re_path(
        r"^/?$",
        MCPServerStreamableHttpView.as_view(
            mcp_server=_mcp,
            authentication_classes=[],
            permission_classes=[AllowAny],
        ),
        name="silk-mcp",
    ),
]
