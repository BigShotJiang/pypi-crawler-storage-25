from django.apps import AppConfig


class DjangoSilkMCPConfig(AppConfig):
    name = "django_silk_mcp"
    verbose_name = "Django Silk MCP"
