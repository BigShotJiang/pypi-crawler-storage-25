# Silk Profiler MCP

## Request confirmation before analysis

CRITICAL: When beginning an investigation, always use a discovery tool (`get_slow_requests`, `get_most_expensive_endpoints`, or `compare_requests`) first to identify candidate requests. Once a matching request is found:

1. **Show the matched request to the user** — display path, method, timing, query count, and `request_id`.
2. **Ask the user to confirm** — explicitly ask: *"Is this the request you want to investigate? (request_id: `<id>`)"*
3. **Wait for confirmation** before running any drill-down tools.
4. **Use the confirmed `request_id`** for all subsequent analysis (`get_request_time_breakdown`, `get_duplicate_queries`, `get_query_sources`, `explain_slow_queries`, etc.) — never rely on `request_path` fallback after the request is confirmed.

## Tools

| Tool | What it does | When to use |
|---|---|---|
| `get_most_expensive_endpoints` | Ranks all endpoints by avg DB time | Start here — find what to optimize |
| `get_request_time_breakdown` | DB% vs Python% for a path | Confirm DB is actually the bottleneck |
| `get_duplicate_queries` | Detects N+1 patterns | First optimization to check |
| `get_query_sources` | Shows which project code line triggered each query | Pinpoints exactly where to add `select_related` |
| `get_overfetched_fields` | Compares SQL columns vs serializer fields | Find candidates for `.only()` |
| `explain_slow_queries` | Runs `EXPLAIN ANALYZE` on slow queries | Reveals missing indexes and sequential scans |
| `get_request_queries` | All SQL for the latest request to a path | Full picture of what a request does |
| `get_slow_queries` | Slowest individual queries across all requests | Global worst offenders |
| `get_slow_requests` | Slowest HTTP requests overall | Global worst offenders |
| `compare_requests` | Shows last N requests with timing | Validate that an optimization worked |
| `get_cprofile_hotspots` | cProfile function-level timings for a request | Identify Python hotspots without decorators |
| `get_python_profiles` | `@silk_profile` block timings with DB/Python breakdown | Deep-dive into annotated functions |

## Full diagnosis scope — DB and Python

Always investigate **both sides** before proposing fixes:

**DB side** (use silk tools):
- N+1 queries (`get_duplicate_queries`, `get_query_sources`)
- Missing indexes / sequential scans (`explain_slow_queries`)
- Over-fetched columns (`get_overfetched_fields`)
- Repeated identical queries (singleton hits called per object)

**Python side** (read serializers, models, helpers):
- `SerializerMethodField` methods repeating the same DB call per object or per field
- Helper functions called multiple times per request with the same inputs
- Prefetched data bypassed by `.filter()` / `.exclude()` inside a method (use `.all()` + Python filtering instead)
- `to_representation` opportunities to compute something once and share it across multiple `get_*` methods via `self.context`
- Use `get_cprofile_hotspots` to identify which functions consume the most CPU time — no decorators needed, always available
- If the endpoint is heavily Python-bound (>60% Python time) and cProfile hotspots point to a specific function worth deeper inspection, suggest adding `@silk_profile` — see the Python profiling section below

## Summary table and implementation strategy

After completing diagnosis, **always produce a summary table** of all findings before writing any code:

```
| Fix | What it changes | DB savings | Python savings | Estimated impact |
|-----|----------------|------------|----------------|-----------------|
| ... | ...            | ...        | ...            | High/Med/Low    |
```

- Sort rows by estimated impact (highest first).
- Include both DB query reduction and Python-side savings in separate columns.
- Estimate impact based on: query count removed, how often the code runs per request, and whether it's in a hot path.

Then ask the user:

> **How would you like to implement these?**
> 1. **All at once** — I apply everything to the current branch now.
> 2. **Isolated worktrees** — I create one git worktree per fix so you can measure each one's impact individually before deciding what to keep.

### If the user chooses isolated worktrees

Explain the workflow:

1. Create one worktree per fix with `git worktree add ../fix-<name> -b fix/<name> <base-commit>` and write only that fix's code changes to each worktree — **no commits, no tests, no linting**.
2. To test a fix, the user applies the worktree's changed files to their running dev server, hits the endpoint, and compares results in Silk.
3. After testing all worktrees, the user picks the ones worth keeping and the assistant applies them to the main branch (and commits there).

Remind the user: worktrees are independent directories. Resetting the main branch never affects them.

**Important:** Do NOT commit inside worktrees and do NOT run tests or linters on worktrees. Just write the code changes.

### Final summary table

Once all worktree code is written, display:

```
| Worktree | Fix summary |
|----------|-------------|
| fix-<name> | one-line description of what changed |
```

## Python profiling with @silk_profile

`get_python_profiles` requires `@silk_profile` decorators to be present — it returns no data on endpoints that haven't been annotated. Use this flow only when the endpoint is heavily Python-bound and you need function-level DB/Python timing that cProfile alone can't give you.

**Workflow:**

1. Call `get_cprofile_hotspots` first — it works without any decorators and shows which functions are most expensive.
2. If the hotspots point to a specific function worth deeper inspection (e.g. a helper called many times), call `get_python_profiles`. If it returns no data, the function hasn't been annotated yet.
3. **Identify the right spots** to annotate — the function(s) flagged by cProfile hotspots, not the top-level view.
4. **Ask the user** if they want you to add the decorators.
5. If they agree: add `@silk_profile(name="<descriptive name>")` to each identified function and add the import `from silk.profiling.profiler import silk_profile` if not already present.
6. **Ask the user to hit the endpoint again**, then re-run `get_python_profiles` with the new `request_id`.

## Pinning analysis to a specific request

Discovery tools (`get_slow_requests`, `get_slow_queries`, `compare_requests`) include a
`request_id` field in their output. Pass that ID to any drill-down tool to ensure the
entire investigation targets the same request, regardless of newer traffic hitting the
same endpoint:

```
1. get_slow_requests()                              → note request_id, e.g. "abc-123"
2. get_request_time_breakdown(request_id="abc-123")
3. get_duplicate_queries(request_id="abc-123")
4. explain_slow_queries(request_id="abc-123")
```

Without `request_id`, drill-down tools fall back to the most recent request matching
`request_path` (original behaviour).

## Example prompts

- *"What are the slowest endpoints right now?"*
- *"Look at GET /api/your-endpoint/ and make it faster"*
- *"Is /api/your-endpoint/ DB-bound or Python-bound?"*
- *"Find N+1 queries in /api/your-endpoint/"*
- *"Which code lines are causing queries in /api/your-endpoint/?"*
- *"Are we over-fetching columns in /api/your-endpoint/?"*
- *"Are there missing indexes on /api/your-endpoint/?"*
- *"Did my last change to /api/your-endpoint/ improve query count?"*

## Avoiding large MCP responses

Some tools (`get_query_sources`, `get_duplicate_queries`) can return very large payloads
that fill up context quickly. Follow these rules to stay scoped:

### Use cProfile as the map, not query sources

`get_cprofile_hotspots` is always the right starting point. It returns a short ranked
list (~20 functions) that immediately identifies which file/line is expensive. Use it as
the anchor for every investigation:

1. **`get_cprofile_hotspots` + `get_request_time_breakdown`** → run these together (both are small); identify the 2-3 expensive functions and confirm DB vs Python split
2. **Gate: if `python_pct > 60%`, skip `get_duplicate_queries` entirely** — the endpoint is Python-bound; go straight to reading code at the hotspot locations. DB-side tools will have minimal impact.
3. **`get_duplicate_queries`** (only if `db_pct > 40%`) → confirm which tables have N+1 (read only occurrences + template, skip the `examples` SQL). **Never call this in the same batch as step 1** — wait for the time breakdown result first.
4. **`get_query_sources(table_filter=...)`** → drill into only the specific tables flagged above
5. **Read the code** at the flagged locations with the `Read` tool

### Always use `table_filter` with `get_query_sources`

Never call `get_query_sources` without a `table_filter`. Identify the target table from
`get_duplicate_queries` or `get_cprofile_hotspots` first, then filter:

```
# Wrong — fetches all queries for the request
get_query_sources(request_id="abc-123")

# Right — scoped to one table at a time
get_query_sources(request_id="abc-123", table_filter="myapp_mymodel")
get_query_sources(request_id="abc-123", table_filter="myapp_relatedmodel")
```

### Rule of thumb

> If a tool result needs a Bash script to summarize it, the tool was called too broadly.

Narrow scope first with discovery tools, then drill down with filters. Never fetch
everything and summarize after.

## Notes

- `get_overfetched_fields` auto-resolves the serializer from the URL when DRF is installed.
  If it can't (e.g. dynamic serializer selection or DRF not available), it returns the raw
  SQL columns for manual comparison.
- `explain_slow_queries` runs `EXPLAIN ANALYZE` which executes the query — safe for
  SELECT only (writes are skipped automatically). Requires PostgreSQL.
- Adding `.only()` can cause extra queries if signals, permissions, or `__str__` access
  deferred fields. Always verify before applying.
