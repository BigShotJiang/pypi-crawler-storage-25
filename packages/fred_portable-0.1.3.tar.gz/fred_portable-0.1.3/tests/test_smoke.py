# Copyright Thales 2026
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from fred_portable.context import Context, Environment
from fred_portable.observability import InMemoryTracer, NullTracer


def test_null_tracer_emits_noop_span() -> None:
    """
    Sanity-check the clean-room tracer surface stays importable.

    Why this exists:
    - avoid failing coverage/test runs on an empty package

    How to use it:
    - run `make test` in `genai-sdk`

    Example:
    - `python -m pytest genai-sdk/tests/test_smoke.py`
    """

    tracer = NullTracer()
    span = tracer.start_span("smoke")
    span.set_attribute("ok", True)
    span.end()


def test_inmemory_tracer_captures_context_attributes() -> None:
    ctx = Context(
        request_id="req-1",
        correlation_id="corr-1",
        actor="user:demo",
        tenant="fred",
        environment=Environment.dev,
        trace_id="trace-1",
    )
    tracer = InMemoryTracer()
    span = tracer.start_span("smoke.context", ctx)
    span.end()

    recorded = tracer.spans[0].attributes
    assert recorded["request_id"] == "req-1"
    assert recorded["correlation_id"] == "corr-1"
    assert recorded["actor"] == "user:demo"
    assert recorded["tenant"] == "fred"
    assert recorded["environment"] == "dev"
    assert recorded["trace_id"] == "trace-1"
