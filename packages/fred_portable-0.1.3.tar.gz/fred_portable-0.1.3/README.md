# Fred Portable SDK

`fred-portable` is a **zero-dependency contract layer** for Fred that makes the
runtime portable across hosting environments.

Why this exists
---------------  
Fred runs in very different contexts (local dev, on-prem, managed cloud, air‑gapped,
regulated). Those environments do not share the same observability stacks, auth
plumbing, or tracing systems. The portable SDK creates a **stable, minimal surface**
so the runtime can be wired to *whatever providers are available* without hard
dependencies or rewrites.

Think of it as the "plug‑socket" layer:
- The runtime speaks **Fred‑portable interfaces** (tracing, context, observability).
- A host environment supplies **concrete providers** (OpenTelemetry, Datadog,
  custom auth, etc.) through adapters.

Approach (clean-room)
---------------------  
This package is a clean‑room contract surface inspired by a GenAI SDK pattern,
but it **does not copy code or specs**. It stays small, explicit, and Apache‑2.0
compatible so it can be embedded anywhere without legal or dependency friction.

Goals
-----  
- Keep contracts explicit: tracing taxonomy + context model + provider protocols.
- Keep helpers minimal: just enough for tests and runtime wiring.
- Enable injection of environment‑specific providers (observability, tracing,
  auth context, telemetry) without coupling.

Non‑goals
---------  
- Shipping a full runtime or platform.
- Providing concrete production implementations of every provider.
- Re‑exporting large third‑party SDKs.

Structure
---------  
- `fred_portable/context.py`: request context contract
- `fred_portable/tracing.py`: tracing taxonomy contracts
- `fred_portable/observability`: provider interfaces + minimal tracer implementations
- `fred_portable/testkit`: small helpers for span assertions

All implementations here are intentionally minimal and meant to be extended by
Fred runtime adapters in `fred-sdk` and `agentic-backend`.
