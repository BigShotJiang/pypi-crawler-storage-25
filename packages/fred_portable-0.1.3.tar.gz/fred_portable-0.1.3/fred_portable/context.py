# Copyright Thales 2026
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Protocol, runtime_checkable


class Environment(str, Enum):
    """
    Deployment environment marker used for correlation and filtering.

    Why this exists:
    - observability pipelines need one stable environment tag across runtimes

    How to use it:
    - populate `Context.environment` with one of these values

    Example:
    - `Context(environment=Environment.dev, ...)`
    """

    dev = "dev"
    staging = "staging"
    prod = "prod"


@dataclass(frozen=True)
class Context:
    """
    Canonical request context for tracing and correlation.

    Why this exists:
    - runtime spans and events need shared identifiers for joining logs and traces

    How to use it:
    - create one per request/agent run and pass it to tracing providers

    Example:
    - `ctx = Context(request_id="req-1", correlation_id="corr-1", actor="user:alice", tenant="acme", environment=Environment.dev)`
    """

    request_id: str
    correlation_id: str
    actor: str
    tenant: str
    environment: Environment
    trace_id: str | None = None


@runtime_checkable
class ContextLike(Protocol):
    """
    Structural context contract accepted by tracing providers.

    Why this exists:
    - allow runtimes to pass richer context objects without re-wrapping

    How to use it:
    - pass any object with the required attributes to tracing providers

    Example:
    - `tracer.start_span("agent.run", context=portable_context)`
    """

    request_id: str
    correlation_id: str
    actor: str
    tenant: str

    @property
    def environment(self) -> object: ...

    trace_id: str | None
