# Copyright Thales 2026
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable


@dataclass(frozen=True)
class SpanDefinition:
    """
    Declarative definition of one span type and its required attributes.

    Why this exists:
    - all runtimes should emit the same core span metadata for querying

    How to use it:
    - include one definition per span name in a `TracingTaxonomy`

    Example:
    - `SpanDefinition(name="agent.run", required_attributes=("agent_id",))`
    """

    name: str
    required_attributes: tuple[str, ...] = ()


@dataclass(frozen=True)
class TracingTaxonomy:
    """
    Collection of span definitions used for validation and conventions.

    Why this exists:
    - keep span names and required attributes centralised and portable

    How to use it:
    - store one taxonomy in runtime config and share with tracers

    Example:
    - `TracingTaxonomy(spans=(SpanDefinition(name="agent.run"),))`
    """

    spans: tuple[SpanDefinition, ...]

    def span_names(self) -> tuple[str, ...]:
        return tuple(span.name for span in self.spans)


def normalize_required_attributes(attributes: Iterable[str] | None) -> tuple[str, ...]:
    if not attributes:
        return ()
    return tuple(sorted({attr.strip() for attr in attributes if attr.strip()}))
