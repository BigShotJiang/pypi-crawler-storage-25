# Copyright Thales 2026
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

from typing import Iterable

from fred_portable.observability import InMemoryTracer, SpanRecord


def find_spans(tracer: InMemoryTracer, *, name: str | None = None) -> list[SpanRecord]:
    """Return spans collected by an InMemoryTracer, optionally filtered by name."""
    spans = tracer.spans
    if name is None:
        return spans
    return [span for span in spans if span.name == name]


def assert_span(
    tracer: InMemoryTracer,
    *,
    name: str,
    at_least: int = 1,
    attr_contains: Iterable[str] | None = None,
) -> list[SpanRecord]:
    """Assert that a tracer has spans matching expectations."""
    spans = find_spans(tracer, name=name)
    if len(spans) < at_least:
        raise AssertionError(
            f"Expected at least {at_least} span(s) named {name!r}, got {len(spans)}"
        )
    if attr_contains:
        missing = [
            s for s in spans if not all(attr in s.attributes for attr in attr_contains)
        ]
        if missing:
            raise AssertionError(
                f"No spans matched required attributes. Missing attributes: {list(attr_contains)}"
            )
    return spans
