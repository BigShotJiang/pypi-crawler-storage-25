# Copyright Thales 2026
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

from enum import Enum
from typing import Any

from fred_portable.context import ContextLike


def context_attributes(context: ContextLike | None) -> dict[str, Any]:
    """Build span attributes from a tracing context."""
    if context is None:
        return {}

    def _coerce(value: object) -> object:
        if isinstance(value, Enum):
            return value.value
        return value

    return {
        "request_id": getattr(context, "request_id", None),
        "correlation_id": getattr(context, "correlation_id", None),
        "actor": getattr(context, "actor", None),
        "tenant": getattr(context, "tenant", None),
        "environment": _coerce(getattr(context, "environment", None)),
        "trace_id": getattr(context, "trace_id", None),
    }
