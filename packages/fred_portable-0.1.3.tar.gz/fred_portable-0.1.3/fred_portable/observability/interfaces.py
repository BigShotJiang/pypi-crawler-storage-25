# Copyright Thales 2026
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

from contextlib import AbstractContextManager
from typing import Any, Mapping, MutableMapping, Protocol, runtime_checkable

from fred_portable.context import ContextLike


@runtime_checkable
class Span(Protocol):
    """Contract for one tracing span."""

    def set_attribute(self, key: str, value: Any) -> None: ...
    def end(self) -> None: ...


class TracePropagator(Protocol):
    """Interface for trace context propagation across process boundaries."""

    def inject(self, carrier: MutableMapping[str, str]) -> None: ...
    def extract(self, carrier: Mapping[str, str]) -> ContextLike | None: ...


class NoopPropagator:
    """TracePropagator that performs no injection or extraction."""

    def inject(self, carrier: MutableMapping[str, str]) -> None:
        del carrier

    def extract(self, carrier: Mapping[str, str]) -> None:
        del carrier
        return None


@runtime_checkable
class Tracer(Protocol):
    """Contract for a tracing backend."""

    @property
    def propagator(self) -> TracePropagator: ...

    def start_span(
        self,
        name: str,
        context: ContextLike | None = None,
        *,
        attributes: Mapping[str, Any] | None = None,
    ) -> Span: ...

    def shutdown(self) -> None: ...


class MetricsProvider(Protocol):
    """Contract for a metrics backend."""

    def timer(
        self,
        name: str,
        *,
        dims: dict[str, str | None] | None = None,
        groups: list[str] | None = None,
    ) -> AbstractContextManager[dict[str, str | None]]: ...
