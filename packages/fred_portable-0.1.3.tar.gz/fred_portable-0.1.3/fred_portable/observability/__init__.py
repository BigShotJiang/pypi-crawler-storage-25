# Copyright Thales 2026
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

from fred_portable.observability.context import context_attributes
from fred_portable.observability.implementations import (
    InMemoryMetrics,
    InMemoryTracer,
    LoggingMetrics,
    LoggingTracer,
    NullMetrics,
    NullTracer,
    SpanRecord,
    TimerRecord,
)
from fred_portable.observability.interfaces import (
    MetricsProvider,
    NoopPropagator,
    Span,
    TracePropagator,
    Tracer,
)

_TRACER: Tracer | None = None
_METRICS: MetricsProvider | None = None


def set_tracer(tracer: Tracer) -> None:
    """Set the global tracer instance. Call once at startup."""
    global _TRACER
    _TRACER = tracer


def get_tracer() -> Tracer:
    """Return the current tracer, defaulting to NullTracer."""
    return _TRACER or NullTracer()


def set_metrics_provider(provider: MetricsProvider) -> None:
    """Set the global metrics provider instance. Call once at startup."""
    global _METRICS
    _METRICS = provider


def get_metrics_provider() -> MetricsProvider:
    """Return the current metrics provider, defaulting to NullMetrics."""
    return _METRICS or NullMetrics()


def shutdown() -> None:
    """Shutdown the current tracer if it supports cleanup."""
    tracer = _TRACER
    if tracer is not None:
        tracer.shutdown()


__all__ = [
    "InMemoryMetrics",
    "InMemoryTracer",
    "LoggingMetrics",
    "LoggingTracer",
    "MetricsProvider",
    "NoopPropagator",
    "NullMetrics",
    "NullTracer",
    "Span",
    "SpanRecord",
    "TimerRecord",
    "TracePropagator",
    "Tracer",
    "context_attributes",
    "get_metrics_provider",
    "get_tracer",
    "set_metrics_provider",
    "set_tracer",
    "shutdown",
]
