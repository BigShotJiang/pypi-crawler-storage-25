# Copyright Thales 2026
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

import logging
from dataclasses import dataclass
from time import time
from typing import Any, Mapping

from fred_portable.context import ContextLike
from fred_portable.observability.context import context_attributes
from fred_portable.observability.interfaces import NoopPropagator, Span, Tracer


@dataclass
class _LoggingSpan:
    name: str
    logger: logging.Logger
    attributes: dict[str, Any]
    start_time: float

    def set_attribute(self, key: str, value: Any) -> None:
        self.attributes[key] = value

    def end(self) -> None:
        payload = {
            "name": self.name,
            "attributes": self.attributes,
            "duration_ms": int((time() - self.start_time) * 1000),
        }
        self.logger.info("trace.span", extra={"span": payload})


class LoggingTracer(Tracer):
    """Tracer that logs each span as a structured payload."""

    def __init__(self, logger: logging.Logger | None = None) -> None:
        self._logger = logger or logging.getLogger("fred_portable.traces")
        self._propagator = NoopPropagator()

    @property
    def propagator(self) -> NoopPropagator:
        return self._propagator

    def shutdown(self) -> None:
        return None

    def start_span(
        self,
        name: str,
        context: ContextLike | None = None,
        *,
        attributes: Mapping[str, Any] | None = None,
    ) -> Span:
        merged = context_attributes(context)
        if attributes:
            merged.update(attributes)
        return _LoggingSpan(
            name=name, logger=self._logger, attributes=merged, start_time=time()
        )
