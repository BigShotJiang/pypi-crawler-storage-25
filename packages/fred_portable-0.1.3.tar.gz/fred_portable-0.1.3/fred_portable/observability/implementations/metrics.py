# Copyright Thales 2026
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

import logging
from contextlib import contextmanager
from dataclasses import dataclass
from time import perf_counter
from typing import Generator


@dataclass
class TimerRecord:
    name: str
    dims: dict[str, str | None]
    duration_ms: float
    groups: list[str] | None


class NullMetrics:
    """MetricsProvider that drops all emissions silently."""

    @contextmanager
    def timer(
        self,
        name: str,
        *,
        dims: dict[str, str | None] | None = None,
        groups: list[str] | None = None,
    ) -> Generator[dict[str, str | None], None, None]:
        del name, groups
        yield dict(dims) if dims else {}


class LoggingMetrics:
    """MetricsProvider that logs each timer emission as a structured entry."""

    def __init__(self, logger: logging.Logger | None = None) -> None:
        self._logger = logger or logging.getLogger("fred_portable.metrics")

    @contextmanager
    def timer(
        self,
        name: str,
        *,
        dims: dict[str, str | None] | None = None,
        groups: list[str] | None = None,
    ) -> Generator[dict[str, str | None], None, None]:
        d: dict[str, str | None] = dict(dims) if dims else {}
        start = perf_counter()
        try:
            yield d
        except Exception:
            d.setdefault("status", "error")
            raise
        finally:
            duration_ms = (perf_counter() - start) * 1000
            d.setdefault("status", "ok")
            self._logger.info(
                "metrics.timer",
                extra={
                    "metric": {
                        "name": name,
                        "dims": d,
                        "duration_ms": round(duration_ms, 2),
                        "groups": groups,
                    }
                },
            )


class InMemoryMetrics:
    """MetricsProvider that stores timer records in memory for tests and assertions."""

    def __init__(self) -> None:
        self._timers: list[TimerRecord] = []

    @property
    def timers(self) -> list[TimerRecord]:
        return list(self._timers)

    def clear(self) -> None:
        self._timers.clear()

    @contextmanager
    def timer(
        self,
        name: str,
        *,
        dims: dict[str, str | None] | None = None,
        groups: list[str] | None = None,
    ) -> Generator[dict[str, str | None], None, None]:
        d: dict[str, str | None] = dict(dims) if dims else {}
        start = perf_counter()
        try:
            yield d
        except Exception:
            d.setdefault("status", "error")
            raise
        finally:
            duration_ms = (perf_counter() - start) * 1000
            d.setdefault("status", "ok")
            self._timers.append(
                TimerRecord(
                    name=name, dims=dict(d), duration_ms=duration_ms, groups=groups
                )
            )
