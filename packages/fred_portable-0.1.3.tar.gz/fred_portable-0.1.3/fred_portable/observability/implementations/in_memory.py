# Copyright Thales 2026
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

from dataclasses import dataclass
from time import time
from typing import Any, Mapping

from fred_portable.context import ContextLike
from fred_portable.observability.context import context_attributes
from fred_portable.observability.interfaces import NoopPropagator, Span, Tracer


@dataclass
class SpanRecord:
    name: str
    attributes: dict[str, Any]
    start_time: float
    end_time: float | None = None


class _InMemorySpan:
    def __init__(self, record: SpanRecord) -> None:
        self._record = record

    def set_attribute(self, key: str, value: Any) -> None:
        self._record.attributes[key] = value

    def end(self) -> None:
        if self._record.end_time is None:
            self._record.end_time = time()


class InMemoryTracer(Tracer):
    """Tracer that stores spans in memory for tests and assertions."""

    def __init__(self) -> None:
        self._propagator = NoopPropagator()
        self._spans: list[SpanRecord] = []

    @property
    def propagator(self) -> NoopPropagator:
        return self._propagator

    @property
    def spans(self) -> list[SpanRecord]:
        return list(self._spans)

    def clear(self) -> None:
        self._spans.clear()

    def shutdown(self) -> None:
        return None

    def start_span(
        self,
        name: str,
        context: ContextLike | None = None,
        *,
        attributes: Mapping[str, Any] | None = None,
    ) -> Span:
        merged = context_attributes(context)
        if attributes:
            merged.update(attributes)
        record = SpanRecord(name=name, attributes=merged, start_time=time())
        self._spans.append(record)
        return _InMemorySpan(record)
