# Copyright Thales 2026
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping

from fred_portable.context import ContextLike
from fred_portable.observability.interfaces import NoopPropagator, Span, Tracer


@dataclass
class _NullSpan:
    name: str
    attributes: dict[str, Any] = field(default_factory=dict)

    def set_attribute(self, key: str, value: Any) -> None:
        del key, value

    def end(self) -> None:
        return None


class NullTracer(Tracer):
    """Tracer that silently drops all spans."""

    def __init__(self) -> None:
        self._propagator = NoopPropagator()

    @property
    def propagator(self) -> NoopPropagator:
        return self._propagator

    def shutdown(self) -> None:
        return None

    def start_span(
        self,
        name: str,
        context: ContextLike | None = None,
        *,
        attributes: Mapping[str, Any] | None = None,
    ) -> Span:
        del context, attributes
        return _NullSpan(name=name)
