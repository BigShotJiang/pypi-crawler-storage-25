# Copyright Thales 2026
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
fred-portable — zero-dependency portable contracts and utilities for Fred.

Sub-packages
------------
    observability   Tracer, Span, MetricsProvider protocols + implementations
    testkit         Helpers for asserting on spans in tests

Root-level types
----------------
    Context, ContextLike, Environment   Canonical request context (tracing, auth, …)
    SpanDefinition, TracingTaxonomy     Span taxonomy contracts

Example
-------
    from fred_portable.observability import Tracer, NullTracer
    from fred_portable.context import Context, Environment
"""

from fred_portable.context import Context, ContextLike, Environment
from fred_portable.tracing import (
    SpanDefinition,
    TracingTaxonomy,
    normalize_required_attributes,
)

__all__ = [
    "Context",
    "ContextLike",
    "Environment",
    "SpanDefinition",
    "TracingTaxonomy",
    "normalize_required_attributes",
]
