import json
import logging
import threading
import time
import uuid
from collections import deque
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional
from urllib import request

logger = logging.getLogger("rubric")

NODES = {
    "us": "https://rubric-protocol.com/verify",
    "sg": "https://sg.rubric-protocol.com/verify",
    "jp": "https://jp.rubric-protocol.com/verify",
    "ca": "https://ca.rubric-protocol.com/verify",
    "eu": "https://eu.rubric-protocol.com/verify",
}

@dataclass
class AttestationRequest:
    agent_id: str
    output: str
    leaf_type: str = "AGENT_OUTPUT"
    metadata: Optional[Dict[str, Any]] = None
    pipeline_id: Optional[str] = None
    confidence: Optional[float] = None
    risk: str = "normal"

@dataclass
class AttestationResult:
    attestation_id: str
    agent_id: str
    stage: str
    signed_at: str
    node: str
    hcs_topic: Optional[str] = None
    hcs_sequence: Optional[int] = None
    merkle_root: Optional[str] = None
    error: Optional[str] = None
    def __repr__(self):
        return f"<AttestationResult id={self.attestation_id[:8]}... stage={self.stage} node={self.node}>"

class BackgroundQueue:
    def __init__(self, flush_interval=5.0, batch_size=100, max_attempts=3, on_dead_letter=None):
        self._queue = deque()
        self._lock = threading.Lock()
        self._flush_interval = flush_interval
        self._batch_size = batch_size
        self._max_attempts = max_attempts
        self._on_dead_letter = on_dead_letter
        self._running = False
        self._thread = None
    def start(self):
        self._running = True
        self._thread = threading.Thread(target=self._worker, daemon=True)
        self._thread.start()
    def stop(self): self._running = False
    def enqueue(self, url, body, headers):
        with self._lock:
            self._queue.append({"url":url,"body":body,"headers":headers,"attempts":0})
    def _worker(self):
        while self._running:
            time.sleep(self._flush_interval)
            self._flush()
    def _flush(self):
        batch = []
        with self._lock:
            while self._queue and len(batch) < self._batch_size:
                batch.append(self._queue.popleft())
        for item in batch:
            try:
                _http_post(item["url"],item["body"],item["headers"],timeout=10)
            except Exception as e:
                item["attempts"] += 1
                if item["attempts"] < self._max_attempts:
                    with self._lock: self._queue.appendleft(item)
                else:
                    logger.error(f"[RubricQueue] Dead letter: {item['body'].get('attestationId')} {e}")
                    if self._on_dead_letter: self._on_dead_letter(item)

def _http_post(url, body, headers, timeout=15):
    data = json.dumps(body).encode("utf-8")
    req = request.Request(url, data=data, headers=headers, method="POST")
    with request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))

class RubricClient:
    def __init__(self, api_key, node="us", enterprise=False, background_queue=False,
                 flush_interval=5.0, batch_size=100, timeout=15, on_dead_letter=None):
        if node not in NODES and node != "auto":
            raise ValueError(f"Invalid node '{node}'. Choose from: {list(NODES.keys())} or 'auto'")
        self.api_key = api_key
        self.node = node
        self.enterprise = enterprise
        self.timeout = timeout
        self._node_keys = list(NODES.keys())
        self._node_index = 0
        self._queue = None
        if background_queue:
            self._queue = BackgroundQueue(flush_interval=flush_interval,
                batch_size=batch_size, on_dead_letter=on_dead_letter)
            self._queue.start()

    def _endpoint(self):
        if self.node == "auto":
            key = self._node_keys[self._node_index % len(self._node_keys)]
            self._node_index += 1
            return NODES[key]
        return NODES[self.node]

    def _headers(self):
        return {"x-api-key": self.api_key, "Content-Type": "application/json"}

    def attest(self, agent_id, output, leaf_type="AGENT_OUTPUT", metadata=None,
               pipeline_id=None, confidence=None, risk="normal"):
        attestation_id = str(uuid.uuid4())
        submitted_at = datetime.now(timezone.utc).isoformat()
        endpoint = self._endpoint()
        path = "/v1/tiered-attest" if self.enterprise else "/v1/attest"
        url = endpoint + path
        data = {"attestationId":attestation_id,"agentId":agent_id,"output":output,
                "leafType":leaf_type,"submittedAt":submitted_at}
        if metadata: data["metadata"] = metadata
        if confidence is not None: data["confidence"] = confidence
        body = {"attestationId":attestation_id,"sourceId":agent_id,"data":data}
        if pipeline_id: body["pipelineId"] = pipeline_id
        headers = self._headers()
        if risk == "high" or self._queue is None:
            try:
                resp = _http_post(url, body, headers, timeout=self.timeout)
                return AttestationResult(attestation_id=attestation_id,agent_id=agent_id,
                    stage=resp.get("stage","pending"),signed_at=submitted_at,node=self.node,
                    hcs_topic=resp.get("hcsTopic"),hcs_sequence=resp.get("hcsSequenceNumber"),
                    merkle_root=resp.get("merkleRoot"))
            except Exception as e:
                logger.warning(f"[RubricClient] Attestation failed (non-fatal): {e}")
                return AttestationResult(attestation_id=attestation_id,agent_id=agent_id,
                    stage="local",signed_at=submitted_at,node=self.node,error=str(e))
        self._queue.enqueue(url, body, headers)
        return AttestationResult(attestation_id=attestation_id,agent_id=agent_id,
            stage="queued",signed_at=submitted_at,node=self.node)

    def attest_request(self, req):
        return self.attest(agent_id=req.agent_id,output=req.output,leaf_type=req.leaf_type,
            metadata=req.metadata,pipeline_id=req.pipeline_id,
            confidence=req.confidence,risk=req.risk)

    def shutdown(self):
        if self._queue: self._queue.stop()

try:
    from autogen import ConversableAgent
    class RubricAutoGenHook:
        def __init__(self, client, pipeline_id=None, events=None):
            self.client = client
            self.pipeline_id = pipeline_id
            self.events = set(events or ["message","tool"])
        def register(self, agent):
            original_receive = agent.receive
            client = self.client
            pipeline_id = self.pipeline_id
            events = self.events
            def attested_receive(message, sender, request_reply=None, silent=False):
                if "message" in events:
                    content = message if isinstance(message,str) else json.dumps(message)
                    client.attest(agent_id=f"autogen:{agent.name}",output=content[:2000],
                        leaf_type="AGENT_OUTPUT",
                        metadata={"sender":str(getattr(sender,"name","unknown")),"event":"receive"},
                        pipeline_id=pipeline_id)
                return original_receive(message,sender,request_reply,silent)
            agent.receive = attested_receive
            if hasattr(agent,"register_hook"):
                agent.register_hook("process_message_before_send",self._attest_outbound)
        def _attest_outbound(self, sender, message, recipient, silent):
            if "message" in self.events:
                content = message if isinstance(message,str) else json.dumps(message)
                self.client.attest(agent_id=f"autogen:{getattr(sender,'name','unknown')}",
                    output=content[:2000],leaf_type="AGENT_OUTPUT",
                    metadata={"recipient":str(getattr(recipient,"name","unknown")),"event":"send"},
                    pipeline_id=self.pipeline_id)
            return message
except ImportError:
    class RubricAutoGenHook:
        def __init__(self,*a,**kw):
            raise ImportError("AutoGen not installed. pip install pyautogen")

try:
    from llama_index.core.callbacks.base_handler import BaseCallbackHandler as LlamaBase
    from llama_index.core.callbacks.schema import CBEventType, EventPayload
    class RubricLlamaIndexHandler(LlamaBase):
        event_starts_to_ignore=[]
        event_ends_to_ignore=[]
        def __init__(self,client,pipeline_id=None,events=None):
            self.client=client
            self.pipeline_id=pipeline_id
            self._events=set(events or ["llm","query","agent_step"])
        def on_event_start(self,event_type,payload=None,event_id="",**kw): pass
        def on_event_end(self,event_type,payload=None,event_id="",**kw):
            if payload is None: return
            if event_type==CBEventType.LLM and "llm" in self._events:
                r=payload.get(EventPayload.RESPONSE,"")
                self.client.attest(agent_id=f"llamaindex-llm:{event_id[:8]}",
                    output=str(r)[:2000],leaf_type="AGENT_OUTPUT",
                    metadata={"event":"llm_end","event_id":event_id},pipeline_id=self.pipeline_id)
            elif event_type==CBEventType.QUERY and "query" in self._events:
                r=payload.get(EventPayload.RESPONSE,"")
                self.client.attest(agent_id=f"llamaindex-query:{event_id[:8]}",
                    output=str(r)[:2000],leaf_type="AGENT_OUTPUT",
                    metadata={"event":"query_end","event_id":event_id},pipeline_id=self.pipeline_id)
            elif event_type==CBEventType.AGENT_STEP and "agent_step" in self._events:
                self.client.attest(agent_id=f"llamaindex-agent:{event_id[:8]}",
                    output=str(payload)[:2000],leaf_type="RULE_APPLIED",
                    metadata={"event":"agent_step","event_id":event_id},pipeline_id=self.pipeline_id)
        def start_trace(self,trace_id=None): pass
        def end_trace(self,trace_id=None,trace_map=None): pass
except ImportError:
    class RubricLlamaIndexHandler:
        def __init__(self,*a,**kw):
            raise ImportError("LlamaIndex not installed. pip install llama-index")

def attest_function(client, agent_id=None, leaf_type="AGENT_OUTPUT", pipeline_id=None):
    def decorator(func):
        import functools
        @functools.wraps(func)
        def wrapper(*args,**kwargs):
            result = func(*args,**kwargs)
            output = result if isinstance(result,str) else json.dumps(result)
            client.attest(agent_id=agent_id or f"fn:{func.__name__}",
                output=output[:2000],leaf_type=leaf_type,pipeline_id=pipeline_id,
                metadata={"function":func.__name__})
            return result
        return wrapper
    return decorator



# CrewAI integration
try:
    from crewai.events import (BaseEventListener,
        AgentExecutionCompletedEvent,AgentExecutionErrorEvent,
        TaskCompletedEvent,TaskFailedEvent,
        ToolUsageFinishedEvent,ToolUsageErrorEvent,
        CrewKickoffCompletedEvent)
    class RubricCrewAIListener(BaseEventListener):
        def __init__(self,client,pipeline_id=None,events=None):
            super().__init__()
            self.client=client;self.pipeline_id=pipeline_id
            self._events=set(events or ["agent","task","tool","crew"])
        def setup_listeners(self,bus):
            c=self.client;p=self.pipeline_id;ev=self._events
            if "agent" in ev:
                @bus.on(AgentExecutionCompletedEvent)
                def _a(src,event):
                    try: c.attest(agent_id="crewai:"+str(getattr(getattr(event,"agent",None),"role","agent")),output=str(getattr(event,"output",""))[:2000],leaf_type="AGENT_OUTPUT",metadata={"event":"agent_execution_completed"},pipeline_id=p)
                    except Exception as e: logger.warning("[RubricCrewAI] "+str(e))
                @bus.on(AgentExecutionErrorEvent)
                def _ae(src,event):
                    try: c.attest(agent_id="crewai:"+str(getattr(getattr(event,"agent",None),"role","agent")),output="AGENT_ERROR:"+str(getattr(event,"error","")),leaf_type="AGENT_OUTPUT",metadata={"event":"agent_execution_error"},pipeline_id=p)
                    except Exception as e: logger.warning("[RubricCrewAI] "+str(e))
            if "task" in ev:
                @bus.on(TaskCompletedEvent)
                def _t(src,event):
                    try:
                        out=getattr(event,"output",None);raw=getattr(out,"raw",str(out)) if out else ""
                        c.attest(agent_id="crewai-task:"+str(getattr(event,"task_id","unknown")),output=str(raw)[:2000],leaf_type="AGENT_OUTPUT",metadata={"event":"task_completed"},pipeline_id=p)
                    except Exception as e: logger.warning("[RubricCrewAI] "+str(e))
                @bus.on(TaskFailedEvent)
                def _tf(src,event):
                    try: c.attest(agent_id="crewai-task:"+str(getattr(event,"task_id","unknown")),output="TASK_FAILED:"+str(getattr(event,"error","")),leaf_type="AGENT_OUTPUT",metadata={"event":"task_failed"},pipeline_id=p)
                    except Exception as e: logger.warning("[RubricCrewAI] "+str(e))
            if "tool" in ev:
                @bus.on(ToolUsageFinishedEvent)
                def _to(src,event):
                    try: c.attest(agent_id="crewai-tool:"+str(getattr(event,"tool_name","unknown")),output=str(getattr(event,"output",""))[:2000],leaf_type="EXTERNAL_ORACLE",metadata={"event":"tool_usage_finished","tool":str(getattr(event,"tool_name","unknown"))},pipeline_id=p)
                    except Exception as e: logger.warning("[RubricCrewAI] "+str(e))
                @bus.on(ToolUsageErrorEvent)
                def _toe(src,event):
                    try: c.attest(agent_id="crewai-tool:"+str(getattr(event,"tool_name","unknown")),output="TOOL_ERROR:"+str(getattr(event,"error","")),leaf_type="EXTERNAL_ORACLE",metadata={"event":"tool_usage_error"},pipeline_id=p)
                    except Exception as e: logger.warning("[RubricCrewAI] "+str(e))
            if "crew" in ev:
                @bus.on(CrewKickoffCompletedEvent)
                def _cr(src,event):
                    try: c.attest(agent_id="crewai-crew:"+str(getattr(event,"crew_name","crew")),output=str(getattr(event,"output",""))[:2000],leaf_type="PIPELINE_COMPLETE",metadata={"event":"crew_kickoff_completed"},pipeline_id=p)
                    except Exception as e: logger.warning("[RubricCrewAI] "+str(e))
except ImportError:
    class RubricCrewAIListener:
        def __init__(self,*a,**k): raise ImportError("crewai not installed. pip install crewai")

# Haystack integration
try:
    from haystack import component as _hsc
    class RubricHaystackComponent:
        def __init__(self,client,agent_id="haystack-pipeline",pipeline_id=None,leaf_type="AGENT_OUTPUT"):
            self.client=client;self.agent_id=agent_id;self.pipeline_id=pipeline_id;self.leaf_type=leaf_type
        def run(self,replies:list):
            try:
                out=str(replies[0]) if replies else ""
                self.client.attest(agent_id=self.agent_id,output=out[:2000],leaf_type=self.leaf_type,metadata={"framework":"haystack","reply_count":len(replies)},pipeline_id=self.pipeline_id)
            except Exception as e: logger.warning("[RubricHaystack] "+str(e))
            return {"replies":replies}
    RubricHaystackComponent=_hsc(_hsc.output_types(replies=list)(RubricHaystackComponent))
    def rubric_haystack_callback(client,agent_id="haystack-pipeline",pipeline_id=None):
        def cb(snapshot):
            try:
                out=json.dumps(getattr(snapshot,"pipeline_outputs",{}))[:2000]
                client.attest(agent_id=agent_id,output=out,leaf_type="AGENT_OUTPUT",metadata={"framework":"haystack","event":"pipeline_snapshot"},pipeline_id=pipeline_id)
            except Exception as e: logger.warning("[RubricHaystack] "+str(e))
            return None
        return cb
except ImportError:
    class RubricHaystackComponent:
        def __init__(self,*a,**k): raise ImportError("haystack-ai not installed. pip install haystack-ai")
    def rubric_haystack_callback(*a,**k): raise ImportError("haystack-ai not installed. pip install haystack-ai")

# Semantic Kernel integration
try:
    from semantic_kernel.filters.filter_types import FilterTypes as _SKF
    from semantic_kernel.filters.functions.function_invocation_context import FunctionInvocationContext as _SKC
    def rubric_semantic_kernel_filter(client,pipeline_id=None,events=None):
        _ev=set(events or ["function"])
        async def _f(context,next_fn):
            await next_fn(context)
            if "function" not in _ev: return
            try:
                r=context.result;out=str(getattr(r,"value",r))[:2000] if r else ""
                fn=getattr(context.function,"name","unknown");pl=getattr(context.function,"plugin_name","")
                aid=("sk:"+pl+"."+fn) if pl else ("sk:"+fn)
                client.attest(agent_id=aid,output=out,leaf_type="AGENT_OUTPUT",metadata={"framework":"semantic_kernel","function":fn,"plugin":pl},pipeline_id=pipeline_id)
            except Exception as e: logger.warning("[RubricSK] "+str(e))
        return _f
except ImportError:
    def rubric_semantic_kernel_filter(*a,**k): raise ImportError("semantic-kernel not installed. pip install semantic-kernel")
__all__ = ["RubricClient","AttestationRequest","AttestationResult","RubricAutoGenHook","RubricLlamaIndexHandler","RubricCrewAIListener","RubricHaystackComponent","rubric_haystack_callback","rubric_semantic_kernel_filter","attest_function"]
__version__ = "1.1.0"
