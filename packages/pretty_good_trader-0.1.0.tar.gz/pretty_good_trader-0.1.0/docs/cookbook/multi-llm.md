# Multi-LLM: Switching Models

PGT uses [LiteLLM](https://github.com/BerriAI/litellm) as its LLM transport layer. Every provider that LiteLLM supports works out of the box — swap models by changing environment variables, no code changes required.

## How It Works

`PGTConfig` exposes three model fields, one per pipeline tier:

| Config field | Env var | Default |
|---|---|---|
| `monitor_model` | `MONITOR_MODEL` | `xai/grok-4-1-fast` |
| `research_model` | `RESEARCH_MODEL` | `xai/grok-4-1-fast` |
| `trader_model` | `TRADER_MODEL` | `xai/grok-4.20-reasoning` |

Each field is passed directly to `litellm.acompletion(model=...)`. LiteLLM resolves the provider prefix (`xai/`, `anthropic/`, `openai/`, `ollama/`) and routes to the correct API using the matching API key from your `.env`.

## Provider Configuration

### xAI Grok (Default)

```ini
MONITOR_MODEL=xai/grok-4-1-fast
RESEARCH_MODEL=xai/grok-4-1-fast
TRADER_MODEL=xai/grok-4.20-reasoning
XAI_API_KEY=xai-...
```

### Anthropic Claude

```ini
MONITOR_MODEL=anthropic/claude-haiku-3-5
RESEARCH_MODEL=anthropic/claude-sonnet-4-5
TRADER_MODEL=anthropic/claude-opus-4-6
ANTHROPIC_API_KEY=sk-ant-...
```

### OpenAI GPT-4o

```ini
MONITOR_MODEL=gpt-4o-mini
RESEARCH_MODEL=gpt-4o
TRADER_MODEL=gpt-4o
OPENAI_API_KEY=sk-...
```

### Local via Ollama

```ini
MONITOR_MODEL=ollama/llama3.2
RESEARCH_MODEL=ollama/llama3.2
TRADER_MODEL=ollama/llama3.2
# No API key needed — Ollama runs locally on port 11434
```

!!! note "Ollama limitations"
    Local models generally produce lower-quality trading decisions than frontier models. They are useful for development, prompt testing, and keeping costs at zero while iterating. Expect more false positives in the Monitor tier and looser rationale from the Decision tier.

## Mixed-Provider Setup

You can mix providers across tiers — run a cheap fast model for Monitor and a premium model for Decision:

```ini
# Cost-optimized mixed setup
MONITOR_MODEL=gpt-4o-mini         # Cheap, fast — $0.15/M tokens
RESEARCH_MODEL=anthropic/claude-haiku-3-5   # Good at research tasks
TRADER_MODEL=xai/grok-4.20-reasoning        # Best reasoning for final decision
```

## Comparing Models via Backtest

Run backtests with multiple models to compare decision quality before committing to one:

```bash
pgt backtest run \
  --start 2024-01-01 \
  --end 2024-06-30 \
  --tickers AAPL,MSFT,NVDA \
  --compare \
  --models xai/grok-4-1-fast,anthropic/claude-sonnet-4-5,gpt-4o
```

The `--compare` flag runs the full backtest once per model and outputs a side-by-side report with Sharpe ratio, max drawdown, and total return for each. Useful for selecting the best model for your strategy before paying live API costs.

## Cost Comparison

Costs below are rough estimates for a 10-ticker US equities portfolio running 6 hours/day at `MONITOR_INTERVAL=180`. Actual costs depend on prompt length, tool call frequency, and response verbosity.

| Provider / Model | Monitor tier | Research tier | Decision tier | Est. $/day |
|---|---|---|---|---|
| xAI `grok-4-1-fast` + `grok-4.20-reasoning` | ~$0.001/cycle | ~$0.015/cycle | ~$0.020/cycle | **$2–5** |
| OpenAI `gpt-4o-mini` + `gpt-4o` | ~$0.0005/cycle | ~$0.010/cycle | ~$0.025/cycle | **$2–4** |
| Anthropic `haiku-3-5` + `claude-opus-4-6` | ~$0.001/cycle | ~$0.008/cycle | ~$0.060/cycle | **$4–10** |
| Ollama `llama3.2` (local) | ~$0/cycle | ~$0/cycle | ~$0/cycle | **~$0** |

!!! note "Monitor tier filters 60–70% of cycles"
    Most cycles produce no signal and exit after the Monitor tier. The Research and Decision tiers are only hit when a signal fires, so their per-cycle cost is amortized across many no-op cycles.

## When to Use Which Model

**Use Grok for:** US equities + xStocks with real-time web search. Grok's xAI search integration means `search_web` calls return fresher results faster than routing through a generic search API. Default and recommended for most users.

**Use Claude for:** Strategies that rely heavily on long research briefs and nuanced reasoning. Claude Opus has exceptional instruction-following for complex multi-step prompts like the Debater tier. Higher cost but demonstrably better rationale quality.

**Use GPT-4o for:** Teams already on the OpenAI platform who want to minimize vendor surface area. Comparable quality to Claude Sonnet at similar price points.

**Use Ollama for:** Development, CI, and prompt iteration where cost matters more than decision quality. Never use local models for live trading on significant capital.
