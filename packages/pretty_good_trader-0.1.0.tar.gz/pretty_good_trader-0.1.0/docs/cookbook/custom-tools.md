# Custom LLM Tools

PGT's AI pipeline exposes a fixed set of tools to each tier (Monitor, Research, Decision). You can extend this set by adding custom tool definitions and registering their handlers in `ToolDispatcher`.

## How ToolDispatcher Works

Each pipeline tier instantiates a fresh `ToolDispatcher`. The dispatcher holds:
- **Tool schemas** — JSON Schema definitions passed to the LLM in the `tools` array
- **Handlers** — async callables that execute when the LLM calls a tool by name

When the LLM emits a tool call, `ToolDispatcher.dispatch(name, args)` looks up the handler by name and awaits it. Unknown tool names raise a `ToolError`. The hard cap `MAX_TOOL_CALLS` (configurable per tier) prevents infinite loops.

## Step 1 — Define the Tool Schema

Tool schemas live in `src/pgt/ai/tools.py`. Add your schema to the appropriate tier list:

```python
# src/pgt/ai/tools.py

RESEARCH_TOOLS = [
    *MONITOR_TOOLS,
    # ... existing tools ...
    {
        "type": "function",
        "function": {
            "name": "get_social_sentiment",
            "description": (
                "Fetch aggregated social media sentiment score for a ticker. "
                "Returns a score from -1.0 (very bearish) to +1.0 (very bullish)."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "ticker": {
                        "type": "string",
                        "description": "Ticker symbol (e.g. NVDA)",
                    },
                    "source": {
                        "type": "string",
                        "enum": ["reddit", "twitter", "stocktwits", "all"],
                        "default": "all",
                        "description": "Social platform to query",
                    },
                },
                "required": ["ticker"],
            },
        },
    },
]
```

Add it to `DECISION_TOOLS` as well if you want the Decision tier to access it.

## Step 2 — Implement the Handler

Create a handler function. Handlers must be `async` and accept keyword arguments matching the tool's parameter names:

```python
# src/pgt/ai/custom_tools.py

import httpx

async def handle_get_social_sentiment(ticker: str, source: str = "all") -> dict:
    """Calls a hypothetical SentimentAPI and returns a normalized score."""
    async with httpx.AsyncClient(timeout=10) as client:
        resp = await client.get(
            "https://api.sentimentapi.example/v1/score",
            params={"ticker": ticker, "source": source},
        )
        resp.raise_for_status()
        data = resp.json()

    return {
        "ticker": ticker,
        "score": data["score"],         # float -1.0 to +1.0
        "volume": data["mention_count"],
        "source": source,
    }
```

!!! note "Backtest safety"
    If your tool makes live network calls, guard it with the `is_backtest` flag so backtests return deterministic stubs:

    ```python
    async def handle_get_social_sentiment(
        ticker: str,
        source: str = "all",
        *,
        is_backtest: bool = False,
    ) -> dict:
        if is_backtest:
            return {"ticker": ticker, "score": 0.0, "volume": 0, "source": source}
        # ... live call ...
    ```

## Step 3 — Register the Handler

Register your handler in `ToolDispatcher` so the dispatcher knows how to route the tool call. Find the `_build_handlers` method in `src/pgt/ai/dispatcher.py` and add your tool:

```python
# src/pgt/ai/dispatcher.py

from pgt.ai.custom_tools import handle_get_social_sentiment

def _build_research_handlers(self) -> dict:
    return {
        # ... existing handlers ...
        "get_social_sentiment": lambda args: handle_get_social_sentiment(
            ticker=args["ticker"],
            source=args.get("source", "all"),
            is_backtest=self._is_backtest,
        ),
    }
```

## Worked Example — End-to-End

With the tool registered, the Research tier will call it automatically when the LLM decides sentiment data is relevant. Here is what a full cycle looks like:

1. Monitor tier detects a signal on `NVDA`
2. Research tier receives the signal; its system prompt lists `get_social_sentiment` as available
3. LLM emits: `{"name": "get_social_sentiment", "arguments": {"ticker": "NVDA", "source": "reddit"}}`
4. `ToolDispatcher.dispatch()` routes to `handle_get_social_sentiment`
5. Result is appended to the conversation as a tool response
6. LLM incorporates sentiment into the research brief passed to Decision tier

## Best Practices

- **Keep handlers idempotent** — the LLM may call the same tool multiple times per cycle
- **Set a timeout** — use `httpx.AsyncClient(timeout=N)` to avoid stalling the pipeline
- **Return structured data** — dicts are serialized to JSON in the tool response; keep keys consistent
- **Test with `is_backtest=True`** — stubs let you run backtests without hitting external APIs
- **Register prompt regression tests** — after adding a tool, run `pytest tests/test_prompts.py` to capture the new SHA-256 hash snapshot
