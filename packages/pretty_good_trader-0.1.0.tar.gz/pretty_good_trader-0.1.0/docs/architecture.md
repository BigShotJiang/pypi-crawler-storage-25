# Architecture

PrettyGoodTrader is built around a clean separation between AI decision-making and infrastructure plumbing.

## Overview

```
┌─────────────────────────────────────────────────────┐
│                   TradingEngine                      │
│  ┌──────────┐   ┌────────────┐   ┌───────────────┐  │
│  │ Scheduler│ → │ AIPipeline │ → │ BrokerAdapter │  │
│  └──────────┘   └────────────┘   └───────────────┘  │
│        │              │                    │         │
│  ┌──────────┐   ┌────────────┐   ┌───────────────┐  │
│  │ EventBus │   │ RiskEngine │   │  SQLiteLogger │  │
│  └──────────┘   └────────────┘   └───────────────┘  │
└─────────────────────────────────────────────────────┘
```

## 3-Tier AI Pipeline

The AI pipeline runs three sequential tiers each cycle. Each tier creates a fresh `ToolDispatcher` — no state leaks between calls.

| Tier | Model | Purpose | Typical cost/cycle |
|------|-------|---------|-------------------|
| **Monitor** | Fast/cheap (e.g., grok-3-mini) | Scan tickers, detect signals worth researching | ~$0.001 |
| **Research** | Mid-tier (e.g., grok-3) | Web search, fundamentals, news, technicals | ~$0.01–0.05 |
| **Decision** | Best available (e.g., grok-3) | Final buy/sell/hold decision + rationale | ~$0.01–0.03 |

Optional **Debater** tier fires when urgency is high — a second LLM argues against the Decision tier's conclusion. Configurable via `DEBATER_ENABLED`.

## Core Components

### BrokerAdapter

Abstract base class for all broker integrations. Concrete implementations: `AlpacaAdapter`, `KrakenAdapter`, `CCXTAdapter`, `PaperEngine`.

Key contract: `get_tradeable_tickers()` returns `None` (not supported), a non-empty set (supported), or raises `BrokerError` on failure.

### RiskEngine

Seven sequential checks before any order reaches the broker:

1. Position size limit
2. Daily loss limit
3. Duplicate order check (60-second window via `SessionMemory`)
4. Portfolio concentration
5. Ticker allow-list
6. Emergency liquidation gate
7. Logger suspension gate (audit trail required for live trading)

### ReflectionMemory

BM25Plus-indexed store of past trade reflections. The AI pipeline can query it for pattern recognition across historical decisions. Index is rebuilt after each `add_reflection()` call and never rebuilt on `search()`.

### PGTClock

Abstract clock interface enabling backtest/live code parity:

- `WallClock` — wraps `datetime.now()`, used in live trading
- `SimClock` — time advances bar-by-bar via `advance_to()`, used in `BacktestEngine`

### EventBus

Two-tier delivery model:
- **Critical events** (`order_placed`, `engine_error`, `risk_blocked`) — delivered directly, bypass queue
- **Non-critical events** — per-subscriber async queue (maxsize=1000, dropped with warning when full)

### SQLiteLogger

Primary audit trail. Falls back to JSONL on SQLite failure. If both fail, `is_suspended` is set to `True` — live trading is blocked until the logger recovers.

## Plugin System

Plugins subscribe to `EventBus` events and react asynchronously. Built-in plugins:

- `TelegramPlugin` — trade alerts via Telegram bot
- `DiscordPlugin` — trade alerts via Discord webhook
- `PrometheusPlugin` — metrics export for Grafana dashboards

Custom plugins implement a single `on_event(event: PGTEvent)` coroutine.

## Clock Abstraction and Backtest/Live Parity

`BacktestEngine` injects a `SimClock` into the pipeline. Every component that needs "current time" reads `context.clock.now()` — never `datetime.now()`. This guarantees identical code paths in backtest and live modes.
