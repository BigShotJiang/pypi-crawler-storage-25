# AI Pipeline

PGT's AI pipeline is the core decision-making engine. It runs three sequential tiers each trading cycle, each backed by a fresh `ToolDispatcher` instance — no state leaks between calls.

## 3 Tiers: Monitor → Research → Decision

### Tier 1 — Monitor

**Purpose:** Scan the watchlist and identify tickers worth researching this cycle.

- Uses a fast, cheap model (e.g., `grok-3-mini`, `gpt-4o-mini`)
- Inputs: recent price data, technical indicators, portfolio state
- Output: structured signal list — tickers with urgency scores and preliminary signals
- Skips the rest of the pipeline for cycles with no interesting signals

### Tier 2 — Research

**Purpose:** Deep dive on flagged tickers — news, web search, fundamentals, technicals.

- Uses a mid-tier model (e.g., `grok-3`, `gpt-4o`)
- Tools available: `search_web`, `get_fundamentals`, `get_news`, `get_indicators`
- In backtest mode: all tools return deterministic stubs (no live API calls)
- Output: structured research report per ticker

### Tier 3 — Decision

**Purpose:** Make the final buy/sell/hold decision with rationale.

- Uses the best available model configured
- Reads research report from Tier 2 + `ReflectionMemory` patterns
- Output: `TradingDecision` with action, size, stop-loss, take-profit, and written rationale
- Decision goes through `RiskEngine` before reaching the broker

### Optional — Debater

When `DEBATER_ENABLED=true` and urgency is high, a second LLM call is made with the counter-argument role. It argues against the Decision tier's conclusion. If the debater raises a critical concern, the order is held.

## LiteLLM Multi-Provider

PGT uses [LiteLLM](https://github.com/BerriAI/litellm) as the LLM transport layer. Any LiteLLM-supported provider works:

```bash
# xAI Grok (default)
LLM_MODEL=grok-3-mini
XAI_API_KEY=xai-...

# OpenAI
LLM_MODEL=gpt-4o-mini
OPENAI_API_KEY=sk-...

# Anthropic
LLM_MODEL=claude-haiku-3-5
ANTHROPIC_API_KEY=sk-ant-...

# Local via Ollama
LLM_MODEL=ollama/llama3.2
```

Swap providers with a single environment variable change. No code modifications.

## Cost Optimization

The 3-tier architecture is designed to minimize LLM API costs:

| Strategy | Savings |
|----------|---------|
| Fast Monitor tier filters out low-signal cycles | 60–70% of cycles never reach Research/Decision |
| Per-model assignment (cheap → Monitor, best → Decision) | 40–60% cost reduction vs. single-model approach |
| `is_backtest=True` stubs (no live API calls during backtest) | Near-zero search/data costs in backtests |
| `MAX_TOOL_CALLS` limit per dispatcher | Prevents runaway tool loops |

Typical operating cost in production: **$2–5/day** for a 10-ticker US equities portfolio on Grok.

## Tool Safety

All tools in `ToolDispatcher` are protected by:

- **Sandwich prompt injection defense** — system prompt is injected before and after user content
- **Query sanitization** — `search_web` queries are sanitized and URL-encoded before dispatch
- **`is_backtest` guards** — live data tools return stubs in backtest mode
- **`logger.is_suspended` guard** — `place_order` is blocked if the audit logger is down
- **`MAX_TOOL_CALLS`** — hard cap per dispatcher instance to prevent infinite loops

## Prompt Regression Testing

All prompts are version-controlled. Their SHA-256 hashes are stored in the `cycles` table and asserted in `test_prompts.py`. Any prompt change triggers a test failure — by design. Update the snapshot hash in the test when you intentionally modify a prompt.
