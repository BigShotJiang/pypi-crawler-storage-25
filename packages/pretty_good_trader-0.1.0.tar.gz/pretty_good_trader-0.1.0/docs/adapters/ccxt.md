# CCXT Adapter

`CCXTAdapter` connects PGT to **100+ crypto exchanges** via the [ccxt.pro](https://github.com/ccxt/ccxt) library — the async WebSocket variant. It supports both **spot** and **perpetual futures** markets and includes automatic heartbeat monitoring with exponential backoff reconnection.

## What CCXTAdapter Supports

- **Any ccxt.pro exchange** — Binance, Bybit, OKX, Kraken (futures), Bitget, Gate.io, MEXC, HTX, Coinbase Advanced Trade, and dozens more
- **Spot and perpetuals** — configure the symbol format in your ticker list
- **WebSocket lifecycle management** — heartbeat, disconnect detection, and auto-reconnect
- **24/7 operation** — crypto markets never close

## Install

```bash
pip install "pretty-good-trader[ccxt]"
```

## Environment Variables

| Variable | Required | Description |
|---|---|---|
| `CCXT_EXCHANGE` | Yes | Exchange ID as used by ccxt (e.g. `binance`, `bybit`, `okx`) |
| `CCXT_API_KEY` | Yes | Exchange API key |
| `CCXT_SECRET_KEY` | Yes | Exchange API secret |

Add to your `.env`:

```ini
CCXT_EXCHANGE=bybit
CCXT_API_KEY=xxxxxxxxxxxxxxxxxxxxxxxx
CCXT_SECRET_KEY=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

## Example Config

```python
from pgt.core.config import PGTConfig

config = PGTConfig(
    monitor_model="xai/grok-4-1-fast",
    trader_model="xai/grok-4.20-reasoning",
    paper=False,
    tickers=["BTC", "ETH", "SOL"],
    max_position_pct=0.10,
    emergency_liquidate_token="your-secret-token",
)
```

## Supported Exchanges (Examples)

| Exchange | ID | Perpetuals | Notes |
|---|---|---|---|
| Binance | `binance` | Yes | Largest volume; use `binanceusdm` for USDT-M perps |
| Bybit | `bybit` | Yes | Unified account; supports linear/inverse |
| OKX | `okx` | Yes | Broad market coverage |
| Gate.io | `gate` | Yes | Many altcoins |
| MEXC | `mexc` | Yes | New listings early |
| Bitget | `bitget` | Yes | Copy-trading exchange |
| Coinbase | `coinbase` | No | Spot only |
| Kraken | `krakenfutures` | Yes | Separate from `KrakenAdapter` (spot) |

!!! tip "Perpetuals vs. Spot"
    For perpetual futures, set `CCXT_EXCHANGE=binanceusdm` (Binance) or `CCXT_EXCHANGE=bybit` (Bybit). Symbol format for perps is typically `BTC/USDT:USDT`. PGT constructs symbols as `{ticker}/USDT` by default — verify the exact symbol string for your exchange in the ccxt docs.

## WebSocket Lifecycle

`CCXTAdapter` uses Python's async context manager protocol:

```python
async with CCXTAdapter(exchange_id="bybit", api_key="...", secret="...") as adapter:
    prices = await adapter.get_prices(["BTC", "ETH"])
```

On `__aenter__`:
1. `load_markets()` is called to fetch all tradeable symbols
2. A `_heartbeat_task` is spawned as an independent `asyncio.Task`

The heartbeat pings the exchange every **30 seconds**. LLM call latency (which can be several seconds) cannot starve the heartbeat because it runs in a separate task.

On heartbeat failure:
1. Warning is logged
2. `_reconnect()` is called with exponential backoff
3. Delays: 1s → 2s → 4s → 8s → 16s (capped at 30s), up to 5 attempts
4. If all 5 attempts fail, an error is logged and trading continues — the next heartbeat tick will retry

On `__aexit__`, the heartbeat task is cancelled cleanly before `exchange.close()` is called.

!!! warning "Use as a context manager"
    Always use `CCXTAdapter` as an `async with` block. Instantiating it without entering the context manager skips `load_markets()` and leaves the heartbeat unstarted, which will cause order failures.

## Order Behavior

All orders are submitted as **market orders** against the `{ticker}/USDT` symbol. The fill price is returned from the exchange response when available; otherwise it defaults to `0.0` and should be reconciled from the exchange's trade history.

## Limitations

- No built-in support for stop-loss or take-profit order types — use `RiskEngine` drawdown limits instead
- Symbol format assumes USDT quote currency — exchanges with BTC-quoted perps need symbol mapping
- `get_tradeable_tickers()` is not implemented (returns `None`) — configure `TICKER_ALLOWLIST` to restrict tradeable assets
