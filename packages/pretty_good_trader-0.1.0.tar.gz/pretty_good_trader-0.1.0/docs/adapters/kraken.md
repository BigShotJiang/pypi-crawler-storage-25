# Kraken Adapter

`KrakenAdapter` connects PGT to [Kraken](https://kraken.com) for trading **xStocks tokenized equities** and **spot crypto pairs**. It wraps the `python-kraken-sdk` and adds a disk-cached ticker discovery layer so PGT always knows which instruments are actually tradeable.

## What KrakenAdapter Supports

- **xStocks tokenized equities** — major US stocks (TSLA, NVDA, AAPL, MSFT, AMZN, META, GOOGL, NFLX, AMD, INTC, PLTR, MSTR, HOOD, SPY, QQQ, GLD) traded 24/7 as on-chain tokens
- **Spot crypto** — BTC, ETH, SOL, and all other Kraken spot pairs
- **Market orders** — the only order type submitted via PGT by default
- **24/7 operation** — xStocks trade outside US market hours; PGT's `weekend_interval` scheduler setting applies

!!! note "xStocks vs. real shares"
    xStocks are tokenized representations backed by real shares held in custody. They follow the same price as the underlying equity but settle on a blockchain. Settlement mechanics differ from a standard brokerage — check Kraken's documentation for the current xStocks list and custody details.

## Install

```bash
pip install "pretty-good-trader[kraken]"
```

## Environment Variables

| Variable | Required | Description |
|---|---|---|
| `KRAKEN_API_KEY` | Yes | Kraken API key (requires Trade and Query permissions) |
| `KRAKEN_SECRET_KEY` | Yes | Kraken API secret |

Add to your `.env`:

```ini
KRAKEN_API_KEY=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
KRAKEN_SECRET_KEY=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

## Example Config

```python
from pgt.core.config import PGTConfig

config = PGTConfig(
    monitor_model="xai/grok-4-1-fast",
    trader_model="xai/grok-4.20-reasoning",
    paper=False,
    tickers=["TSLA", "NVDA", "AAPL", "BTC"],
    max_position_pct=0.05,
    emergency_liquidate_token="your-secret-token",
)
```

## `get_tradeable_tickers()` Behavior

On first call, `KrakenAdapter` **probes Kraken's REST API** for each known xStocks ticker by requesting its live quote. Tickers that return valid data are considered tradeable. The result is persisted to disk with a **6-hour TTL**.

```
data/kraken_cache/kraken_tradeable_tickers  ← DiskCache file
```

On subsequent calls within the TTL window, the cached set is returned immediately — no network round-trips. After 6 hours the cache expires and re-probing occurs automatically.

!!! warning "Discovery failure"
    If **all** probes fail (e.g., Kraken is unreachable at startup), `get_tradeable_tickers()` raises `BrokerError`. The `RiskEngine` treats this as a blocking condition and will not allow orders until discovery succeeds.

## Ticker Pair Mapping

PGT tickers are mapped to Kraken pairs using the `xUSD` suffix convention:

| PGT ticker | Kraken pair |
|---|---|
| `TSLA` | `TSLAxUSD` |
| `NVDA` | `NVDAxUSD` |
| `BTC` | `BTCxUSD` |

The mapping is handled internally — you configure PGT with standard tickers.

## Supported Order Types

| Order type | Supported | Notes |
|---|---|---|
| Market | Yes | Default for all PGT orders |
| Limit | Planned | Not yet implemented in `place_order()` |

## Known Limitations

- `get_portfolio()` does not report average cost basis — Kraken's balance endpoint does not expose it; `avg_cost` is always `0.0`
- The xStocks list is static in `KRAKEN_XSTOCKS_TICKERS`; new listings require a code update until dynamic discovery is added
- No perpetuals or margin trading via this adapter — use `CCXTAdapter` for those
