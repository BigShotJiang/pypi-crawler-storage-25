# Alpaca Adapter

`AlpacaAdapter` connects PGT to [Alpaca Markets](https://alpaca.markets) for US equities trading. It wraps the official `alpaca-py` SDK and supports both paper and live trading accounts.

## What AlpacaAdapter Supports

- **US equities** — all NYSE and NASDAQ-listed stocks
- **Market and limit orders** — `DAY` time-in-force for both
- **Paper trading** — full simulation via Alpaca's paper endpoint; no real funds required
- **Live trading** — production endpoint, requires `PAPER=false` and `EMERGENCY_LIQUIDATE_TOKEN`

!!! warning "Market hours only"
    Alpaca's standard brokerage API enforces US market hours (09:30–16:00 ET, Monday–Friday). Orders submitted outside market hours will be rejected or queued depending on your account type. PGT's scheduler respects `premarket_start` and `market_close` settings to avoid this.

!!! note "No crypto"
    `AlpacaAdapter` does not support crypto pairs. Use `KrakenAdapter` or `CCXTAdapter` for crypto.

## Install

```bash
pip install "pretty-good-trader[alpaca]"
```

## Environment Variables

| Variable | Required | Description |
|---|---|---|
| `ALPACA_API_KEY` | Yes | Alpaca API key ID |
| `ALPACA_SECRET_KEY` | Yes | Alpaca API secret key |
| `ALPACA_BASE_URL` | No | Override base URL (default: paper or live endpoint inferred from `PAPER`) |

Add to your `.env`:

```ini
ALPACA_API_KEY=PKxxxxxxxxxxxxxxxxxxxxxxxx
ALPACA_SECRET_KEY=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
PAPER=true
```

## Example Config

```python
from pgt.core.config import PGTConfig

config = PGTConfig(
    monitor_model="xai/grok-4-1-fast",
    trader_model="xai/grok-4.20-reasoning",
    paper=True,
    tickers=["AAPL", "MSFT", "NVDA", "GOOGL"],
    max_position_pct=0.05,      # 5% max per position
    max_daily_loss_pct=0.03,    # 3% daily drawdown limit
)
```

PGT automatically reads `ALPACA_API_KEY` and `ALPACA_SECRET_KEY` from `.env` and constructs `AlpacaAdapter` internally. You do not need to instantiate it manually in normal usage.

## `get_tradeable_tickers()` Behavior

`AlpacaAdapter` does **not** implement `get_tradeable_tickers()` — the base class returns `None`, which signals to the `RiskEngine` that ticker filtering is not supported. The ticker allow-list (`TICKER_ALLOWLIST` in `.env`) is the recommended guard for Alpaca.

## Price Feed

Prices are fetched via `StockLatestQuoteRequest`, returning the mid-price `(ask + bid) / 2`. All SDK calls run in `asyncio.to_thread()` to avoid blocking the event loop.

## Order Types

| Order type | Supported | Notes |
|---|---|---|
| Market | Yes | `TimeInForce.DAY` |
| Limit | Yes | Requires `limit_price`; `TimeInForce.DAY` |
| Stop | No | Use the RiskEngine `stop_loss` field instead |

## Limitations

- No extended-hours trading via standard paper accounts
- No fractional shares by default (depends on account configuration)
- No options or futures
- `get_portfolio()` reports unrealized P&L based on `current_price` from Alpaca's position endpoint — may lag by a few seconds
