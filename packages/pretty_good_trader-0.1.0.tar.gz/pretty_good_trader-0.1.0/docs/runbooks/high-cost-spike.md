# Runbook: High LLM API Cost Spike

**Severity:** Medium  
**Scope:** API bill growing faster than expected; monthly projection has exceeded budget

---

## Symptoms

- Budget alert triggered from xAI / Anthropic / OpenAI dashboard
- `pgt cost --forecast` shows 30-day projection above acceptable threshold
- `pgt cycles` shows unusually high `api_cost` values per cycle
- Research-tier or Decision-tier cycles firing more frequently than normal

---

## Step 1: Project current costs

```bash
# Show total cost + 30-day forecast from last 7 days of cycles
pgt cost --forecast
```

The forecast is based on the rolling 7-day average. If the forecast is above your budget, continue to Step 2.

To drill into the most expensive individual cycles:

```bash
pgt cycles --limit 50
```

The `Type` column shows which tier fired (`monitor`, `research`, `decision`). The `Cost $` column shows per-cycle spend.

---

## Step 2: Identify the tier causing the spike

PGT uses a three-tier escalation pipeline. Each tier has its own model and cost profile.

| Tier | Env var | Config field | Default model | Cost profile |
|---|---|---|---|---|
| 1 — Monitor | `MONITOR_MODEL` | `monitor_model` | `xai/grok-4-1-fast` | Low — fires every `monitor_interval` (180 s default) |
| 2 — Research | `RESEARCH_MODEL` | `research_model` | `xai/grok-4-1-fast` | Medium — fires when urgency ≥ `min_urgency`; web search adds tokens |
| 3 — Decision | `TRADER_MODEL` | `trader_model` | `xai/grok-4.20-reasoning` | High — fires after Research; reasoning model is expensive |

Look at the `Type` column in `pgt cycles` output:
- Mostly `monitor` cycles with high cost → monitor model is too expensive or `monitor_interval` is too short
- Many `research` cycles → `min_urgency` threshold is too low
- Many `decision` cycles → urgency threshold not filtering enough signals

---

## Step 3: Switch to cheaper models

Edit `.env` to downgrade model tiers:

```bash
# Tier 1 — fastest, cheapest monitor
MONITOR_MODEL=xai/grok-3-mini-fast

# Tier 2 — research with lower cost
RESEARCH_MODEL=xai/grok-3-mini

# Tier 3 — decision, avoid heavy reasoning model
TRADER_MODEL=xai/grok-3
```

Restart the engine after editing `.env`:

```bash
# Kill the running process
kill $(cat data/pgt.pid)

# Verify it stopped
ps aux | grep "pgt run"

# Restart in paper mode to confirm models load correctly
pgt run --paper --dry-run
pgt run --paper
```

---

## Step 4: Raise urgency threshold

The `min_urgency` config field controls which Monitor signals escalate to Research. Valid values are string levels (e.g. `low`, `medium`, `high`).

Edit `.env`:

```bash
# Default is "medium" — raise to "high" to reduce Research calls
MIN_URGENCY=high
```

A higher threshold means fewer Research and Decision tier invocations, which are the main cost drivers.

Also consider increasing `monitor_interval` to reduce how often Tier 1 fires:

```bash
# Default is 180 s — increase to 300 s (5 min) to halve Monitor calls
MONITOR_INTERVAL=300
```

Restart with `pgt run --paper` after any `.env` change.

---

## Step 5: Emergency — freeze Research tier calls

If costs must be stopped immediately without a full restart:

**Option A — Raise urgency to near-maximum:**

```bash
# In .env — only the most extreme signals will escalate
MIN_URGENCY=high
```

**Option B — Disable debate and fundamentals to reduce token usage:**

```bash
# In .env
DEBATE_ENABLED=false
RISK_DEBATE_ENABLED=false
FUNDAMENTALS_ENABLED=false
```

Restart after changes:

```bash
kill $(cat data/pgt.pid)
pgt run --paper
```

---

## Natural circuit breakers

PGTConfig includes risk fields that act as implicit spending guards by halting order execution when thresholds are breached:

| Config field | Default | Purpose |
|---|---|---|
| `max_daily_loss_pct` | `0.05` (5%) | Engine stops issuing orders if daily loss exceeds this |
| `max_position_pct` | `0.05` (5%) | Single position capped at 5% of portfolio |
| `max_open_positions` | `20` | No new orders when position count is at maximum |
| `min_cash_reserve_pct` | `0.10` (10%) | Cash reserve prevents full portfolio deployment |

These do not reduce LLM calls directly, but they limit financial exposure while you diagnose the cost issue.

---

## Post-incident review

Once costs are under control:

```bash
# Review AI decision log for patterns that caused over-escalation
pgt reflections --limit 30

# Search reflections for high-urgency signals that triggered Research
pgt reflections --search "urgency"

# Check cycle breakdown by type for the last 100 cycles
pgt cycles --limit 100
```
