# Runbook: pgt Service Down

**Severity:** High  
**Scope:** Trading engine not running, no signals being processed, no trades executing

---

## Symptoms

- `pgt status` returns "No trading cycles yet" or stale timestamp
- PID file `data/pgt.pid` exists but process is not alive
- No new entries in `data/pgt.log` for longer than `monitor_interval` (default 180 s)
- Alerts from monitoring (Prometheus, Telegram) indicate engine is unreachable

---

## Step 1: Check PID file

```bash
# Read the stored PID
cat data/pgt.pid

# Verify whether that process is alive
ps aux | grep pgt
```

If the PID file exists but the process is gone (stale lock), remove it so a fresh start is possible:

```bash
rm data/pgt.pid
```

If the process is alive but appears stuck, note the PID and move to Step 3 before killing it.

---

## Step 2: Run health check

```bash
# Full health check: config validity, API keys, Docker services
pgt doctor

# Auto-repair stopped Docker services (SearXNG, Firecrawl, etc.)
pgt doctor --fix
```

`pgt doctor` checks:
- `PGTConfig` loads without error
- LLM API keys are present and validated
- `data/` directory exists
- Docker services (`pgt`, `searxng`, `searxng-redis`) are running

Resolve every failing check before proceeding to restart.

---

## Step 3: Check logs

```bash
# Last 100 lines — look for the final error or traceback
tail -100 data/pgt.log
```

Inspect recent trade records in SQLite:

```bash
sqlite3 data/pgt.db "SELECT * FROM trades ORDER BY ts DESC LIMIT 10;"
```

Also review recent LLM cycles from the CLI:

```bash
pgt cycles --limit 20
```

---

## Step 4: Safe restart

Cooldown state and session memory are persisted in SQLite (`data/pgt.db`) via `SessionMemory`. No manual cooldown reset is needed — the engine resumes where it left off.

**Always restart in paper mode first to confirm the engine is healthy before going live.**

```bash
# Step 4a: Restart in paper mode and watch one cycle
pgt run --paper --dry-run

# Step 4b: If dry-run passes, start paper mode
pgt run --paper
```

Monitor the live dashboard in a second terminal:

```bash
pgt status --watch
```

Once paper mode runs cleanly for at least one full `monitor_interval` cycle:

```bash
# Step 4c: Restart live trading (requires EMERGENCY_LIQUIDATE_TOKEN in .env)
pgt run --no-paper --confirm-live
```

---

## Escalate vs. Self-heal decision tree

| Root cause | Action | Self-heal steps |
|---|---|---|
| Config error (bad `.env` value) | Self-heal | Fix `.env`, re-run `pgt doctor` |
| API key expired or missing | Self-heal | Rotate key in `.env`, re-run `pgt doctor` |
| Docker service stopped | Self-heal | `pgt doctor --fix` or `pgt docker up` |
| Exchange outage / 5xx from broker | Self-heal | Wait; check exchange status page; retry |
| Repeated crashes within 5 min | **Escalate** | Capture full `data/pgt.log`, open GitHub issue with log excerpt and `pgt doctor` output |
| Unknown panic / segfault | **Escalate** | Attach log, Python version, and OS info to issue |

**Escalation artifact checklist:**
- [ ] `tail -500 data/pgt.log` saved to a file
- [ ] Output of `pgt doctor`
- [ ] Output of `pgt cycles --limit 5 --json`
- [ ] Python version (`python --version`) and OS
