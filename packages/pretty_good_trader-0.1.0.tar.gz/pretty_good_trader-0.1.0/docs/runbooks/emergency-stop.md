# Runbook: Emergency Trading Stop

> **WARNING:** Use this runbook when you need to halt ALL trading immediately — open orders, live positions, everything. Act fast. Verify at each step.

**Severity:** Critical  
**Scope:** Immediate halt of the pgt trading engine and all order activity

---

## Immediate halt (< 30 seconds)

```bash
# Option A: Graceful shutdown (SIGTERM — allows engine to flush state)
kill $(cat data/pgt.pid)

# Option B: If PID file is missing or Option A does not stop the process
pkill -f "pgt run"

# Verify the process has stopped (should return no pgt run lines)
ps aux | grep "pgt run"
```

If the process does not stop within 10 seconds after SIGTERM, force-kill it:

```bash
kill -9 $(cat data/pgt.pid)
```

---

## Remove PID lock after a hard kill

If the process was killed with `-9` or crashed without cleanup, the PID file will be stale and prevent restart:

```bash
rm -f data/pgt.pid
```

---

## Verify no open orders

**The engine stopping does NOT automatically cancel open orders on the exchange.**

1. Log into your exchange dashboard directly (Alpaca, Kraken, Binance, etc.) and cancel any open limit or stop orders manually.

2. Check the local database for orders that were placed and may still be open:

```bash
sqlite3 data/pgt.db "SELECT * FROM orders WHERE status='open';"
```

Cross-reference each row against your exchange dashboard and cancel accordingly.

3. If you need a programmatic snapshot and can briefly restart the engine in dry-run mode:

```bash
pgt run --dry-run
```

The dry-run displays a portfolio snapshot without placing new orders and exits after one cycle.

---

## Check position exposure

Review the current state of all positions in the database:

```bash
# All open positions
sqlite3 data/pgt.db "SELECT * FROM orders WHERE status='open';"

# Recent trade history
sqlite3 data/pgt.db "SELECT * FROM trades ORDER BY ts DESC LIMIT 20;"
```

For a human-readable summary, check the last cycle logged:

```bash
pgt status
```

---

## Post-incident review

After the engine is stopped and open orders are addressed, investigate what triggered the emergency stop.

```bash
# Last 200 log lines filtered for errors and order activity
tail -200 data/pgt.log | grep -E "ERROR|WARN|order"

# Full last 500 lines for broader context
tail -500 data/pgt.log
```

Review AI decision history:

```bash
# Review recent AI reflections and trade lessons
pgt reflections --limit 30

# Search for relevant keywords (e.g. the ticker or signal type involved)
pgt reflections --search "loss"

# Replay the specific cycle that triggered the incident (use ID from pgt cycles)
pgt cycles --limit 20
pgt replay <cycle_id>
```

Run a full health check before considering any restart:

```bash
pgt doctor
```

---

## Resume checklist

Do not restart live trading until every item below is checked off.

- [ ] Root cause identified and documented
- [ ] Open orders cancelled on exchange dashboard
- [ ] `sqlite3 data/pgt.db "SELECT * FROM orders WHERE status='open';"` returns no rows
- [ ] `pgt doctor` passes all checks (config, API keys, Docker services)
- [ ] `.env` reviewed — no misconfigured `max_position_pct`, `max_daily_loss_pct`, or model settings
- [ ] Dry-run passes: `pgt run --dry-run`
- [ ] Paper mode runs cleanly for at least 1 full `monitor_interval` cycle: `pgt run --paper`
- [ ] `pgt status --watch` shows expected cycle activity and cost
- [ ] Incident notes written (what happened, what was fixed, what to monitor)

When all items are checked:

```bash
# Live trading requires EMERGENCY_LIQUIDATE_TOKEN set in .env
pgt run --no-paper --confirm-live
```

The engine will display a 10-second countdown before going live. Press Ctrl+C to abort if anything looks wrong.
