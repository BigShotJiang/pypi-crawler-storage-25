# Quickstart

Get from zero to a running paper trade in under 5 minutes.

## Prerequisites

- Python 3.11 or higher
- At least one LLM API key (xAI/Grok, OpenAI, Anthropic, or any LiteLLM-supported provider)
- Optional: Alpaca or Kraken brokerage account for live/paper trading

## Install

```bash
pip install pretty-good-trader

# With Alpaca support
pip install "pretty-good-trader[alpaca]"

# With Kraken support
pip install "pretty-good-trader[kraken]"
```

## Initialize your project

```bash
pgt init
```

This generates a `.env` file pre-populated with all required keys. Edit it to add your API credentials.

## Run a simple backtest

```python
import asyncio
from pgt import BacktestEngine
from pgt.core.config import PGTConfig

config = PGTConfig(
    llm_model="grok-3-mini",
    paper=True,
    backtest_start="2024-01-01",
    backtest_end="2024-06-30",
    tickers=["AAPL", "MSFT", "NVDA"],
)

async def main():
    engine = BacktestEngine(config=config)
    report = await engine.run()
    print(report.summary())

asyncio.run(main())
```

Or use the CLI:

```bash
pgt backtest run --start 2024-01-01 --end 2024-06-30 --tickers AAPL,MSFT,NVDA
```

## Run paper trading live

```python
import asyncio
from pgt import TradingEngine
from pgt.core.config import PGTConfig

config = PGTConfig(
    llm_model="grok-3-mini",
    paper=True,  # Set to False for live trading (requires EMERGENCY_LIQUIDATE_TOKEN)
    tickers=["AAPL", "MSFT"],
)

async def main():
    engine = TradingEngine(config=config)
    await engine.run()

asyncio.run(main())
```

Or via CLI:

```bash
pgt run --dry-run     # Paper trading, no real orders
pgt run               # Live trading (requires PAPER=false in .env)
```

!!! warning
    Live trading requires `PAPER=false` **and** a valid `EMERGENCY_LIQUIDATE_TOKEN` in your `.env`.
    PGT will refuse to start without it.
