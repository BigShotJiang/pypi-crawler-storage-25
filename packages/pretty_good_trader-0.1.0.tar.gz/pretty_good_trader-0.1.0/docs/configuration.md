# Configuration

PGT is configured via environment variables loaded into `PGTConfig(BaseSettings)`. All values are validated at startup — the engine will refuse to start with invalid or missing required settings.

## Environment Variables

Create a `.env` file in your project root (use `pgt init` to generate a template):

### LLM Settings

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `LLM_MODEL` | Yes | `grok-3-mini` | LiteLLM model string (e.g. `gpt-4o`, `claude-haiku-3-5`) |
| `XAI_API_KEY` | If using xAI | — | xAI/Grok API key |
| `OPENAI_API_KEY` | If using OpenAI | — | OpenAI API key |
| `ANTHROPIC_API_KEY` | If using Anthropic | — | Anthropic API key |
| `LLM_TEMPERATURE` | No | `0.7` | LLM sampling temperature (0 = deterministic) |
| `MAX_TOOL_CALLS` | No | `10` | Max tool calls per ToolDispatcher instance |

### Trading Mode

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `PAPER` | No | `true` | `true` for paper trading, `false` for live trading |
| `EMERGENCY_LIQUIDATE_TOKEN` | If `PAPER=false` | — | Secret token to trigger emergency liquidation |
| `TICKERS` | Yes | — | Comma-separated watchlist (e.g. `AAPL,MSFT,NVDA`) |

### Broker Credentials

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `ALPACA_API_KEY` | If using Alpaca | — | Alpaca Markets API key |
| `ALPACA_SECRET_KEY` | If using Alpaca | — | Alpaca Markets secret key |
| `ALPACA_BASE_URL` | No | Paper URL | Alpaca API base URL |
| `KRAKEN_API_KEY` | If using Kraken | — | Kraken Exchange API key |
| `KRAKEN_SECRET_KEY` | If using Kraken | — | Kraken Exchange secret key |

### Risk Management

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `MAX_POSITION_PCT` | No | `0.10` | Max portfolio allocation per position (10%) |
| `DAILY_LOSS_LIMIT_PCT` | No | `0.05` | Stop trading if daily P&L drops below this (5%) |
| `SIGNAL_COOLDOWN_SECONDS` | No | `3600` | Minimum seconds between repeated signals for same ticker |
| `MAX_OPEN_POSITIONS` | No | `5` | Maximum concurrent open positions |

### AI Pipeline

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `MONITOR_MODEL` | No | `LLM_MODEL` | Override model for Monitor tier |
| `RESEARCH_MODEL` | No | `LLM_MODEL` | Override model for Research tier |
| `DECISION_MODEL` | No | `LLM_MODEL` | Override model for Decision tier |
| `DEBATER_ENABLED` | No | `false` | Enable the optional Debater tier |
| `DEBATER_MODEL` | No | `LLM_MODEL` | Override model for Debater tier |

### Data & Search

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `SEARXNG_URL` | No | — | Self-hosted SearXNG instance URL |
| `FIRECRAWL_URL` | No | — | Self-hosted Firecrawl instance URL |
| `FIRECRAWL_TIMEOUT` | No | `30` | Firecrawl request timeout in seconds |
| `DUCKDB_PATH` | No | `./data/catalog.duckdb` | Path to DuckDB catalog file |

### Notifications

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `TELEGRAM_BOT_TOKEN` | No | — | Telegram bot token for trade alerts |
| `TELEGRAM_CHAT_ID` | No | — | Telegram chat/channel ID |
| `DISCORD_WEBHOOK_URL` | No | — | Discord webhook URL for trade alerts |
| `PROMETHEUS_PORT` | No | `8000` | Port to expose Prometheus metrics |

## PGTConfig Fields

`PGTConfig` inherits from `pydantic_settings.BaseSettings`. All environment variables above map to typed fields with validation.

```python
from pgt.core.config import PGTConfig

# Load from environment / .env file
config = PGTConfig()

# Or override programmatically
config = PGTConfig(
    llm_model="claude-haiku-3-5",
    paper=True,
    tickers=["BTC/USD", "ETH/USD"],
    max_position_pct=0.05,
)
```

!!! danger "Live trading requirement"
    When `paper=False`, `emergency_liquidate_token` **must** be set.
    `PGTConfig` raises `ValueError` at construction time if it is missing.
    This is enforced via a `@model_validator` and cannot be bypassed.

## Backtest-Specific Config

| Field | Default | Description |
|-------|---------|-------------|
| `backtest_start` | — | Start date (ISO format: `2024-01-01`) |
| `backtest_end` | — | End date (ISO format: `2024-06-30`) |
| `backtest_temperature` | `0` | LLM temperature for backtests (default: deterministic) |
| `backtest_initial_capital` | `10000.0` | Starting portfolio value in USD |
