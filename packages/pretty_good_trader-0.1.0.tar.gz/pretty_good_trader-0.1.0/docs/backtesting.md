# Backtesting

PGT's `BacktestEngine` replays historical OHLCV data bar-by-bar through the same AI pipeline used for live trading. No code changes required between modes.

## BacktestEngine Usage

```python
import asyncio
from pgt import BacktestEngine
from pgt.core.config import PGTConfig

config = PGTConfig(
    llm_model="grok-3-mini",
    paper=True,
    backtest_start="2024-01-01",
    backtest_end="2024-06-30",
    tickers=["AAPL", "MSFT", "NVDA"],
    backtest_temperature=0,  # Deterministic LLM output for reproducibility
)

async def main():
    engine = BacktestEngine(config=config)
    report = await engine.run()

    print(f"Total return: {report.total_return_pct:.2f}%")
    print(f"Sharpe ratio: {report.sharpe_ratio:.2f}")
    print(f"Max drawdown: {report.max_drawdown_pct:.2f}%")
    print(f"Total trades: {report.total_trades}")
    print(f"Win rate: {report.win_rate_pct:.1f}%")
    print(f"Total LLM cost: ${report.total_llm_cost_usd:.4f}")

asyncio.run(main())
```

## CLI: `pgt backtest run`

```bash
# Basic backtest
pgt backtest run --start 2024-01-01 --end 2024-06-30

# With equity curve plot (rendered in terminal via plotext)
pgt backtest run --start 2024-01-01 --end 2024-06-30 --plot

# Compare multiple models on the same date range
pgt backtest compare \
  --start 2024-01-01 --end 2024-06-30 \
  --models grok-3-mini,gpt-4o-mini,claude-haiku-3-5

# Export results to JSON
pgt backtest run --start 2024-01-01 --end 2024-06-30 --output report.json
```

## `--plot` Flag

Renders an equity curve directly in the terminal using `plotext`. No GUI or browser required.

```
Portfolio value over time (2024-01-01 → 2024-06-30)
$12,500 ┤                                           ╭──
$12,000 ┤                                      ╭───╯
$11,500 ┤                              ╭───────╯
$11,000 ┤                       ╭─────╯
$10,500 ┤              ╭────────╯
$10,000 ┼──────────────╯
```

## `--compare` Flag (Multi-Model Comparison)

Runs the same date range against multiple LLM models and outputs a comparison table:

```
Model             Return    Sharpe    Drawdown  Trades  Cost
──────────────────────────────────────────────────────────────
grok-3-mini       +18.4%    1.42      -8.2%     47      $2.14
gpt-4o-mini       +14.1%    1.18      -11.3%    52      $3.87
claude-haiku-3-5  +16.8%    1.31      -9.1%     39      $1.92
```

## BacktestReport Fields

| Field | Type | Description |
|-------|------|-------------|
| `total_return_pct` | `float` | Portfolio total return (%) |
| `sharpe_ratio` | `float` | Annualized Sharpe ratio |
| `max_drawdown_pct` | `float` | Maximum peak-to-trough drawdown (%) |
| `total_trades` | `int` | Number of completed trades |
| `win_rate_pct` | `float` | Percentage of profitable trades |
| `avg_hold_days` | `float` | Average trade holding period in days |
| `total_llm_cost_usd` | `float` | Total LLM API spend during backtest |
| `cycles` | `list[CycleRecord]` | Per-cycle trace data for debugging |
| `prompt_hash` | `str` | SHA-256 hash of the prompt used |

## How It Works

1. `BacktestEngine` calls `DuckDBCatalog.load_range()` to preload OHLCV data into memory
2. For each bar, `SimClock.advance_to(bar_timestamp)` advances the clock
3. `AIPipeline.run()` is called with `is_backtest=True` — tools like `search_web` and `get_fundamentals` return deterministic stubs
4. Orders are executed against `PaperEngine` — no file I/O, purely in-memory when `is_backtest=True`
5. Results are checkpointed to the `backtest_runs` table in DuckDB for resume support

!!! note
    Backtest temperature is forced to `0` by default for reproducible results. Override with `backtest_temperature` in config.
