# PrettyGoodTrader

PrettyGoodTrader (pgt) is an LLM-native trading framework. Write a prompt, backtest it, then ship it live — with the same code. The AI makes all decisions; the framework provides reliable, broker-agnostic infrastructure with a 3-tier cost-optimized pipeline proven in production.

## Install

```bash
pip install pretty-good-trader
```

## Next steps

- [Quickstart](quickstart.md) — from zero to first paper trade in 5 minutes
- [Architecture](architecture.md) — understand the 3-tier AI pipeline and core components
- [Backtesting](backtesting.md) — replay historical data against any LLM prompt
- [AI Pipeline](ai-pipeline.md) — Monitor → Research → Decision pipeline explained
- [Configuration](configuration.md) — full `PGTConfig` reference
