# TODOS — Deferred Work Registry

Community contributions welcome. See [CONTRIBUTING.md](CONTRIBUTING.md) for how to contribute.

Items marked 🔮 **Future** require community traction before they make sense to build.

---

## TODO-9 — PrometheusPlugin metrics specification

- [ ] Implement full metrics spec

**What:** Define and implement 7 core metrics in `PrometheusPlugin`:
```
pgt_monitor_cycles_total{result="signal|no_signal|error"}
pgt_orders_placed_total{side="buy|sell", exchange="alpaca|kraken|ccxt"}
pgt_orders_blocked_total{reason="max_position|drawdown|dedup|..."}
pgt_api_cost_dollars_total{tier="monitor|research|decision"}
pgt_llm_latency_seconds{tier="monitor|research|decision"} (histogram)
pgt_monitor_signal_rate (15-min rolling gauge — tracks strategy effectiveness over time)
pgt_portfolio_value_dollars (gauge)
pgt_daily_pnl_dollars (gauge)
```

**Why:** Without metrics, operators cannot distinguish "bot is working" from "bot is stuck silently."

**Effort:** M · **Priority:** P2 · **Blocked by:** Phase 4 (`PrometheusPlugin` scaffold)

---

## TODO-10 — `pgt replay --cycle-id`

- [ ] Implement replay CLI command

**What:** CLI command to re-run a specific past cycle from SQLite `cycles` table (same inputs, same prompts, same tools), printing full decision reasoning in Rich panels. Use `trace_id` to optionally replay the full Monitor→Research→Decision chain.

**Why:** Primary production debugging tool — without it, understanding a wrong trade means reading raw JSON from SQLite. `pgt cycles --cycle-id --json` in Phase 1 covers the minimal case; full replay is Phase 3.

**Effort:** M · **Priority:** P2 · **Blocked by:** Phase 3

---

## TODO-11 (Future) 🔮 — Strategy Registry / `pgt hub`

- [ ] Design and implement strategy registry

**What:** GitHub-based strategy registry. `pgt hub install community/funding-arb` installs a strategy package. Community prompt ratings driven by anonymized backtest P&L.

**Why:** NPM-like ecosystem driver; most viral feature once community exists. `pgt backtest --compare` (Phase 3) lays the technical foundation for community benchmarking.

**Effort:** XL · **Priority:** P3 · **Blocked by:** community traction (100+ stars)

---

## TODO-12 (Future) 🔮 — RL Training Environment

- [ ] Implement gymnasium-compatible training environment

**What:** `PGTTraderEnv(gymnasium.Env)` wrapping `BacktestEngine`. Agents trained via PPO/SAC (Stable-Baselines3).

**Why:** AI/ML research community; unique positioning beyond Freqtrade.

**Effort:** XL · **Priority:** P3 · **Blocked by:** stable `BacktestEngine` API

---

## TODO-13 (Future) 🔮 — Web Dashboard

- [ ] Build Streamlit dashboard

**What:** Streamlit dashboard for portfolio monitoring, backtest visualization, cycle explorer.

**Why:** Jesse's web dashboard is cited as a key adoption driver; non-CLI users need it.

**Effort:** L · **Priority:** P3 · **Blocked by:** Phase 5 launch

---

## TODO-14 — Operational Runbooks

- [ ] Write service-down runbook (`docs/runbooks/service-down.md`)
- [ ] Write high-cost-spike runbook (`docs/runbooks/high-cost-spike.md`)
- [ ] Write emergency-stop runbook (`docs/runbooks/emergency-stop.md`)

**What:** Three runbooks in `docs/runbooks/`:
1. `service-down.md` — SearXNG/Firecrawl recovery steps
2. `high-cost-spike.md` — Identify which cycles/models caused a cost spike via `pgt cycles`
3. `emergency-stop.md` — Step-by-step: `EMERGENCY_LIQUIDATE_TOKEN`, `pgt docker down`, manual position check

**Why:** The user is the on-call engineer. Without runbooks, recovery from incidents requires remembering steps under stress.

**How to apply:** Ship with Phase 5 (launch prep). Include in `docs/` alongside architecture docs.

**Effort:** S · **Priority:** P2 · **Blocked by:** Phase 5 (launch prep)

---

## TODO-15 — CCXT WebSocket Heartbeat Isolation

- [ ] Isolate WebSocket heartbeat into a dedicated `asyncio.Task`

**What:** `CCXTAdapter` WebSocket heartbeat (every 30s) must run as a dedicated `asyncio.Task`, independent of the pipeline coroutine. LLM calls (especially reasoning models) can take 10-30s and must not starve the heartbeat.

**Why:** If the heartbeat misses its window due to LLM call latency, the WebSocket disconnects silently. Reconnect with exponential backoff exists but causes data gaps.

**How to apply:** In `CCXTAdapter.__aenter__()`, call `asyncio.create_task(self._heartbeat_loop())` and cancel it in `__aexit__()`. Never `await` the heartbeat inline.

**Effort:** S · **Priority:** P1 · **Blocked by:** Phase 4 (CCXTAdapter)
