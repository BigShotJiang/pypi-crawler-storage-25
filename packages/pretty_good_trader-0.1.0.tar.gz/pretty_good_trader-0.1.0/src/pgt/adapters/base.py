"""BrokerAdapter ABC — broker / exchange connector interface."""

from __future__ import annotations

from abc import ABC, abstractmethod

from pgt.models import (
    OrderIntent,
    OrderResult,
    PortfolioSnapshot,
)


class BrokerError(Exception):
    """Raised by adapter methods on exchange/broker failures."""


class BrokerAdapter(ABC):
    """
    Abstract broker/exchange connector.

    get_tradeable_tickers() contract:
      - Returns None   → adapter doesn't support discovery; ToolDispatcher skips check.
      - Returns non-empty set → supported; ToolDispatcher blocks untradeable tickers.
      - Raises BrokerError → query failed; ToolDispatcher blocks order (never silently bypass).
    """

    @abstractmethod
    async def get_portfolio(self) -> PortfolioSnapshot: ...

    @abstractmethod
    async def get_prices(self, tickers: list[str]) -> dict[str, float]: ...

    @abstractmethod
    async def place_order(
        self,
        intent: OrderIntent,
    ) -> OrderResult: ...

    @abstractmethod
    async def cancel_order(self, order_id: str) -> bool: ...

    @abstractmethod
    async def get_orders(self, status: str = "open") -> list[OrderResult]: ...

    async def get_tradeable_tickers(self) -> set[str] | None:
        """
        Optional: return set of tradeable tickers for this exchange.
        Default: None (skip tradeable check — adapter doesn't support discovery).
        Override in adapters that have a known universe (e.g. KrakenAdapter).
        """
        return None

    @property
    def is_paper(self) -> bool:
        return False

    @property
    def exchange_name(self) -> str:
        return self.__class__.__name__.replace("Adapter", "").lower()
