"""AlpacaAdapter — wraps alpaca-py for US equities trading."""

from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING

from pgt.adapters.base import BrokerAdapter, BrokerError
from pgt.models import (
    OrderIntent,
    OrderResult,
    OrderSide,
    OrderStatus,
    OrderType,
    PortfolioSnapshot,
    Position,
)

_log = logging.getLogger(__name__)

if TYPE_CHECKING:
    pass


class AlpacaAdapter(BrokerAdapter):
    """
    Wraps alpaca-py TradingClient + StockHistoricalDataClient.
    All sync SDK calls wrapped in asyncio.to_thread().
    Requires: pip install pretty-good-trader[alpaca]
    """

    def __init__(
        self,
        api_key: str,
        secret_key: str,
        paper: bool = True,
    ) -> None:
        try:
            from alpaca.data.historical import StockHistoricalDataClient
            from alpaca.trading.client import TradingClient
        except ImportError:
            raise ImportError(
                "alpaca-py is required: pip install pretty-good-trader[alpaca]"
            )

        self._trading = TradingClient(api_key=api_key, secret_key=secret_key, paper=paper)
        self._data = StockHistoricalDataClient(api_key=api_key, secret_key=secret_key)
        self._paper = paper

    async def get_portfolio(self) -> PortfolioSnapshot:
        try:
            account = await asyncio.to_thread(self._trading.get_account)
            positions_raw = await asyncio.to_thread(self._trading.get_all_positions)
        except Exception as exc:
            raise BrokerError(f"Alpaca get_portfolio failed: {exc}") from exc

        positions = {
            p.symbol: Position(
                ticker=p.symbol,
                qty=float(p.qty),
                avg_cost=float(p.avg_entry_price),
                current_price=float(p.current_price or 0),
            )
            for p in positions_raw
        }
        return PortfolioSnapshot(
            cash=float(account.cash),
            positions=positions,
        )

    async def get_prices(self, tickers: list[str]) -> dict[str, float]:
        from alpaca.data.requests import StockLatestQuoteRequest

        try:
            req = StockLatestQuoteRequest(symbol_or_symbols=tickers)
            quotes = await asyncio.to_thread(self._data.get_stock_latest_quote, req)
        except Exception as exc:
            raise BrokerError(f"Alpaca get_prices failed: {exc}") from exc

        return {
            symbol: float((quote.ask_price + quote.bid_price) / 2)
            for symbol, quote in quotes.items()
        }

    async def place_order(self, intent: OrderIntent) -> OrderResult:
        from alpaca.trading.enums import OrderSide as AlpacaSide
        from alpaca.trading.enums import TimeInForce
        from alpaca.trading.requests import LimitOrderRequest, MarketOrderRequest

        side = AlpacaSide.BUY if intent.side == OrderSide.BUY else AlpacaSide.SELL

        try:
            if intent.order_type == OrderType.MARKET:
                req = MarketOrderRequest(
                    symbol=intent.ticker,
                    qty=intent.qty,
                    side=side,
                    time_in_force=TimeInForce.DAY,
                )
            elif intent.order_type == OrderType.LIMIT:
                if intent.limit_price is None:
                    raise BrokerError("Limit order requires limit_price")
                req = LimitOrderRequest(
                    symbol=intent.ticker,
                    qty=intent.qty,
                    side=side,
                    time_in_force=TimeInForce.DAY,
                    limit_price=intent.limit_price,
                )
            else:
                raise BrokerError(f"Unsupported order type: {intent.order_type}")

            order = await asyncio.to_thread(self._trading.submit_order, req)
        except BrokerError:
            raise
        except Exception as exc:
            raise BrokerError(f"Alpaca place_order failed: {exc}") from exc

        return OrderResult(
            order_id=str(order.id),
            ticker=intent.ticker,
            side=intent.side,
            qty=float(order.qty or intent.qty),
            status=OrderStatus.PENDING,
            exchange="alpaca",
        )

    async def cancel_order(self, order_id: str) -> bool:
        try:
            await asyncio.to_thread(self._trading.cancel_order_by_id, order_id)
            return True
        except Exception as exc:
            _log.warning("Alpaca cancel_order failed: %s", exc)
            return False

    async def get_orders(self, status: str = "open") -> list[OrderResult]:
        from alpaca.trading.enums import QueryOrderStatus
        from alpaca.trading.requests import GetOrdersRequest

        try:
            req = GetOrdersRequest(status=QueryOrderStatus.OPEN)
            orders = await asyncio.to_thread(self._trading.get_orders, req)
        except Exception as exc:
            raise BrokerError(f"Alpaca get_orders failed: {exc}") from exc

        return [
            OrderResult(
                order_id=str(o.id),
                ticker=o.symbol,
                side=OrderSide.BUY if str(o.side) == "buy" else OrderSide.SELL,
                qty=float(o.qty or 0),
                status=OrderStatus.PENDING,
                exchange="alpaca",
            )
            for o in orders
        ]

    @property
    def exchange_name(self) -> str:
        return "alpaca"
