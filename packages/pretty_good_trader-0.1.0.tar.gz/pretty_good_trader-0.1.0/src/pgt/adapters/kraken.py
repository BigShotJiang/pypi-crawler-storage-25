"""KrakenAdapter — wraps python-kraken-sdk for xStocks and spot crypto."""

from __future__ import annotations

import asyncio
import logging
from pathlib import Path

from pgt.adapters.base import BrokerAdapter, BrokerError
from pgt.memory.cache import DiskCache
from pgt.models import (
    OrderIntent,
    OrderResult,
    OrderSide,
    OrderStatus,
    PortfolioSnapshot,
    Position,
)

_log = logging.getLogger(__name__)

# 24/7 xStocks tickers available on Kraken
KRAKEN_XSTOCKS_TICKERS = [
    "TSLA", "NVDA", "AAPL", "GOOGL", "SPY", "QQQ", "MSTR", "HOOD", "GLD",
    "MSFT", "AMZN", "META", "NFLX", "AMD", "INTC", "PLTR",
]

_TRADEABLE_CACHE_TTL = 6 * 3600  # 6 hours


def _to_pair(ticker: str) -> str:
    """Normalize PGT ticker to Kraken pair (e.g. TSLA → TSLAxUSD)."""
    return f"{ticker}xUSD"


def _from_pair(pair: str) -> str:
    """Normalize Kraken pair to PGT ticker (e.g. TSLAxUSD → TSLA)."""
    return pair.replace("xUSD", "")


class KrakenAdapter(BrokerAdapter):
    """
    Wraps python-kraken-sdk (kraken.spot.Market, Trade, User).
    All sync SDK calls wrapped in asyncio.to_thread().
    Tradeable ticker discovery: probes Kraken REST at startup, caches 6h.
    Requires: pip install pretty-good-trader[kraken]
    """

    def __init__(
        self,
        api_key: str,
        secret: str,
        data_dir: Path | str = "data",
    ) -> None:
        try:
            from kraken.spot import Market, Trade, User
        except ImportError:
            raise ImportError(
                "python-kraken-sdk is required: pip install pretty-good-trader[kraken]"
            )

        self._market = Market()
        self._trade = Trade(key=api_key, secret=secret)
        self._user = User(key=api_key, secret=secret)
        self._cache = DiskCache(Path(data_dir) / "kraken_cache")

    async def get_portfolio(self) -> PortfolioSnapshot:
        try:
            balance = await asyncio.to_thread(self._user.get_balance)
        except Exception as exc:
            raise BrokerError(f"Kraken get_portfolio failed: {exc}") from exc

        cash = float(balance.get("USD", balance.get("ZUSD", 0)))
        positions = {}

        for raw_key, qty_str in balance.items():
            qty = float(qty_str)
            if qty <= 0:
                continue
            # Map Kraken asset name to PGT ticker where possible
            ticker = raw_key.lstrip("XZ")
            if ticker in ("USD", "EUR", "GBP"):
                continue
            positions[ticker] = Position(
                ticker=ticker,
                qty=qty,
                avg_cost=0.0,  # Kraken doesn't expose avg cost directly
            )

        return PortfolioSnapshot(cash=cash, positions=positions)

    async def get_prices(self, tickers: list[str]) -> dict[str, float]:
        pairs = [_to_pair(t) for t in tickers]
        try:
            data = await asyncio.to_thread(
                self._market.get_ticker, pair=",".join(pairs)
            )
        except Exception as exc:
            raise BrokerError(f"Kraken get_prices failed: {exc}") from exc

        result = {}
        for ticker, pair in zip(tickers, pairs):
            pair_data = data.get(pair) or data.get(pair.upper())
            if pair_data:
                ask = float(pair_data["a"][0])
                bid = float(pair_data["b"][0])
                result[ticker] = (ask + bid) / 2
        return result

    async def place_order(self, intent: OrderIntent) -> OrderResult:
        pair = _to_pair(intent.ticker)
        side = "buy" if intent.side == OrderSide.BUY else "sell"

        try:
            resp = await asyncio.to_thread(
                self._trade.create_order,
                ordertype="market",
                side=side,
                volume=str(intent.qty),
                pair=pair,
            )
        except Exception as exc:
            raise BrokerError(f"Kraken place_order failed: {exc}") from exc

        txid = resp.get("txid", [""])[0] if isinstance(resp.get("txid"), list) else ""
        return OrderResult(
            order_id=txid,
            ticker=intent.ticker,
            side=intent.side,
            qty=intent.qty,
            status=OrderStatus.PENDING,
            exchange="kraken",
        )

    async def cancel_order(self, order_id: str) -> bool:
        try:
            await asyncio.to_thread(self._trade.cancel_order, txid=order_id)
            return True
        except Exception as exc:
            _log.warning("Kraken cancel_order failed: %s", exc)
            return False

    async def get_orders(self, status: str = "open") -> list[OrderResult]:
        try:
            open_orders = await asyncio.to_thread(self._trade.get_open_orders)
        except Exception as exc:
            raise BrokerError(f"Kraken get_orders failed: {exc}") from exc

        results = []
        for txid, order in (open_orders.get("open") or {}).items():
            descr = order.get("descr", {})
            results.append(
                OrderResult(
                    order_id=txid,
                    ticker=_from_pair(descr.get("pair", "")),
                    side=OrderSide.BUY if descr.get("type") == "buy" else OrderSide.SELL,
                    qty=float(order.get("vol", 0)),
                    status=OrderStatus.PENDING,
                    exchange="kraken",
                )
            )
        return results

    async def get_tradeable_tickers(self) -> set[str] | None:
        """Probes Kraken REST for tradeable xStocks, caches 6h."""
        cache_key = "kraken_tradeable_tickers"
        cached = self._cache.get(cache_key)
        if cached is not None:
            return set(cached)

        # Probe known xStocks candidates
        tradeable = set()
        for ticker in KRAKEN_XSTOCKS_TICKERS:
            pair = _to_pair(ticker)
            try:
                data = await asyncio.to_thread(self._market.get_ticker, pair=pair)
                if data and pair in data:
                    tradeable.add(ticker)
            except Exception:
                pass  # not tradeable or API error — skip

        if not tradeable:
            # If all probes failed, raise BrokerError so caller blocks order
            raise BrokerError(
                "Kraken tradeable ticker discovery failed — all probes returned no data"
            )

        self._cache.set(cache_key, list(tradeable), ttl=_TRADEABLE_CACHE_TTL)
        return tradeable

    @property
    def exchange_name(self) -> str:
        return "kraken"
