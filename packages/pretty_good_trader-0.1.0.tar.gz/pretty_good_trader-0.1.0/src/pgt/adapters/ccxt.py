"""CCXTAdapter — wraps ccxt.pro for 100+ crypto exchanges."""

from __future__ import annotations

import asyncio
import logging

from pgt.adapters.base import BrokerAdapter, BrokerError
from pgt.models import (
    OrderIntent,
    OrderResult,
    OrderSide,
    OrderStatus,
    PortfolioSnapshot,
    Position,
)

_log = logging.getLogger(__name__)


class CCXTAdapter(BrokerAdapter):
    """
    Wraps ccxt.pro (async WebSocket variant) for perpetuals + spot.
    WebSocket heartbeat runs as independent asyncio.Task (see TODO-15).
    Configuration: CCXT_EXCHANGE, CCXT_API_KEY, CCXT_SECRET
    Requires: pip install pretty-good-trader[ccxt]
    """

    def __init__(self, exchange_id: str, api_key: str, secret: str) -> None:
        try:
            import ccxt.pro as ccxtpro
        except ImportError:
            raise ImportError("ccxt is required: pip install pretty-good-trader[ccxt]")

        self._exchange_id = exchange_id
        self._exchange = getattr(ccxtpro, exchange_id)(
            {"apiKey": api_key, "secret": secret}
        )
        self._heartbeat_task: asyncio.Task | None = None

    async def __aenter__(self) -> CCXTAdapter:
        await self._exchange.load_markets()
        # Heartbeat runs independently so LLM call latency can't starve it (TODO-15)
        self._heartbeat_task = asyncio.create_task(self._heartbeat_loop())
        return self

    async def __aexit__(self, *args: object) -> None:
        if self._heartbeat_task:
            self._heartbeat_task.cancel()
            try:
                await self._heartbeat_task
            except asyncio.CancelledError:
                pass
        await self._exchange.close()

    async def _heartbeat_loop(self) -> None:
        while True:
            await asyncio.sleep(30)
            try:
                await self._exchange.ping()
            except Exception as exc:
                _log.warning("CCXT heartbeat failed: %s — attempting reconnect", exc)
                await self._reconnect()

    async def _reconnect(self) -> None:
        """Exponential backoff reconnect — max 5 retries."""
        delay = 1.0
        for attempt in range(1, 6):
            try:
                await self._exchange.close()
                await self._exchange.load_markets()
                _log.info("CCXT reconnected on attempt %d", attempt)
                return
            except Exception as exc:
                _log.warning("CCXT reconnect attempt %d failed: %s", attempt, exc)
                await asyncio.sleep(min(delay, 30.0))
                delay *= 2
        _log.error("CCXT reconnect failed after 5 attempts")

    async def get_portfolio(self) -> PortfolioSnapshot:
        try:
            balance = await self._exchange.fetch_balance()
        except Exception as exc:
            raise BrokerError(f"CCXT get_portfolio failed: {exc}") from exc

        cash = float(balance.get("USDT", {}).get("free", 0))
        positions = {}
        for asset, info in (balance.get("total") or {}).items():
            qty = float(info or 0)
            if qty > 0 and asset != "USDT":
                positions[asset] = Position(ticker=asset, qty=qty, avg_cost=0.0)

        return PortfolioSnapshot(cash=cash, positions=positions)

    async def get_prices(self, tickers: list[str]) -> dict[str, float]:
        result = {}
        for ticker in tickers:
            symbol = f"{ticker}/USDT"
            try:
                ticker_data = await self._exchange.fetch_ticker(symbol)
                result[ticker] = float(ticker_data["last"])
            except Exception as exc:
                _log.warning("CCXT get_prices %s failed: %s", ticker, exc)
        return result

    async def place_order(self, intent: OrderIntent) -> OrderResult:
        symbol = f"{intent.ticker}/USDT"
        side = "buy" if intent.side == OrderSide.BUY else "sell"
        try:
            order = await self._exchange.create_order(
                symbol=symbol,
                type="market",
                side=side,
                amount=intent.qty,
            )
        except Exception as exc:
            raise BrokerError(f"CCXT place_order failed: {exc}") from exc

        return OrderResult(
            order_id=str(order.get("id", "")),
            ticker=intent.ticker,
            side=intent.side,
            qty=float(order.get("amount", intent.qty)),
            fill_price=float(order.get("price") or 0) or None,
            status=OrderStatus.PENDING,
            exchange=self._exchange_id,
        )

    async def cancel_order(self, order_id: str) -> bool:
        try:
            await self._exchange.cancel_order(order_id)
            return True
        except Exception as exc:
            _log.warning("CCXT cancel_order failed: %s", exc)
            return False

    async def get_orders(self, status: str = "open") -> list[OrderResult]:
        try:
            orders = await self._exchange.fetch_open_orders()
        except Exception as exc:
            raise BrokerError(f"CCXT get_orders failed: {exc}") from exc

        return [
            OrderResult(
                order_id=str(o["id"]),
                ticker=o["symbol"].split("/")[0],
                side=OrderSide.BUY if o["side"] == "buy" else OrderSide.SELL,
                qty=float(o["amount"]),
                status=OrderStatus.PENDING,
                exchange=self._exchange_id,
            )
            for o in orders
        ]

    @property
    def exchange_name(self) -> str:
        return self._exchange_id
