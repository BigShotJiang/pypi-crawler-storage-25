"""PaperEngine — decorator wrapping any live BrokerAdapter for virtual fills."""

from __future__ import annotations

import asyncio
import json
import logging
import os
from pathlib import Path

from pgt.adapters.base import BrokerAdapter
from pgt.models import (
    OrderIntent,
    OrderResult,
    OrderSide,
    OrderStatus,
    PortfolioSnapshot,
    Position,
)

_log = logging.getLogger(__name__)

_STATE_FILE = Path("data/paper_state.json")


class PGTStateError(Exception):
    """Raised when paper state file is corrupted — never silently reset."""


class PaperEngine(BrokerAdapter):
    """
    Wraps any live BrokerAdapter. Uses its get_prices() for realistic fills.
    Maintains a virtual portfolio with atomic state persistence.

    is_backtest=True: in-memory state only, zero disk I/O during backtest replay.
    """

    def __init__(
        self,
        live_adapter: BrokerAdapter,
        initial_capital: float = 10_000.0,
        is_backtest: bool = False,
        state_file: Path | None = None,
    ) -> None:
        self._live = live_adapter
        self._is_backtest = is_backtest
        self._initial_capital = initial_capital
        self._state_file = state_file or _STATE_FILE
        self._lock = asyncio.Lock()  # prevents double-spend on concurrent place_order calls
        self._order_counter = 0

        if is_backtest:
            self._state = self._empty_state(initial_capital)
        else:
            self._state = self._load_state(initial_capital)

    # ─── BrokerAdapter interface ─────────────────────────────────────────

    async def get_portfolio(self) -> PortfolioSnapshot:
        prices = {}
        if self._state["positions"]:
            tickers = list(self._state["positions"].keys())
            try:
                prices = await self._live.get_prices(tickers)
            except Exception as exc:
                _log.warning("PaperEngine: get_prices failed: %s", exc)

        positions = {}
        for ticker, pos in self._state["positions"].items():
            current_price = prices.get(ticker, pos["avg_cost"])
            positions[ticker] = Position(
                ticker=ticker,
                qty=pos["qty"],
                avg_cost=pos["avg_cost"],
                current_price=current_price,
            )

        return PortfolioSnapshot(
            cash=self._state["cash"],
            positions=positions,
        )

    async def get_prices(self, tickers: list[str]) -> dict[str, float]:
        return await self._live.get_prices(tickers)

    async def place_order(self, intent: OrderIntent) -> OrderResult:
        async with self._lock:  # serializes all state mutations — prevents race conditions
            prices = await self.get_prices([intent.ticker])
            price = prices.get(intent.ticker)
            if price is None:
                return OrderResult(
                    order_id="",
                    ticker=intent.ticker,
                    side=intent.side,
                    qty=intent.qty,
                    status=OrderStatus.REJECTED,
                    error=f"Cannot get price for {intent.ticker}",
                )

            fee = price * intent.qty * 0.001  # default fee; PGTConfig not injected here

            if intent.side == OrderSide.BUY:
                cost = price * intent.qty + fee
                if self._state["cash"] < cost:
                    return OrderResult(
                        order_id="",
                        ticker=intent.ticker,
                        side=intent.side,
                        qty=intent.qty,
                        status=OrderStatus.REJECTED,
                        error="Insufficient cash",
                    )
                self._state["cash"] -= cost
                pos = self._state["positions"].get(intent.ticker)
                if pos:
                    total_qty = pos["qty"] + intent.qty
                    pos["avg_cost"] = (
                        (pos["avg_cost"] * pos["qty"] + price * intent.qty) / total_qty
                    )
                    pos["qty"] = total_qty
                else:
                    self._state["positions"][intent.ticker] = {
                        "qty": intent.qty,
                        "avg_cost": price,
                    }

            elif intent.side == OrderSide.SELL:
                pos = self._state["positions"].get(intent.ticker)
                if not pos or pos["qty"] < intent.qty:
                    return OrderResult(
                        order_id="",
                        ticker=intent.ticker,
                        side=intent.side,
                        qty=intent.qty,
                        status=OrderStatus.REJECTED,
                        error="Insufficient position",
                    )
                pos["qty"] -= intent.qty
                if pos["qty"] <= 0:
                    del self._state["positions"][intent.ticker]
                self._state["cash"] += price * intent.qty - fee

            self._order_counter += 1
            order_id = f"paper-{self._order_counter:06d}"

            if not self._is_backtest:
                self._save_state()

            return OrderResult(
                order_id=order_id,
                ticker=intent.ticker,
                side=intent.side,
                qty=intent.qty,
                fill_price=price,
                status=OrderStatus.FILLED,
                fee=fee,
                exchange="paper",
            )

    async def cancel_order(self, order_id: str) -> bool:
        # Paper orders fill immediately; nothing to cancel
        return False

    async def get_orders(self, status: str = "open") -> list[OrderResult]:
        return []

    async def get_tradeable_tickers(self) -> set[str] | None:
        return await self._live.get_tradeable_tickers()

    @property
    def is_paper(self) -> bool:
        return True

    @property
    def exchange_name(self) -> str:
        return f"paper({self._live.exchange_name})"

    # ─── State management ────────────────────────────────────────────────

    @staticmethod
    def _empty_state(initial_capital: float) -> dict:
        return {"cash": initial_capital, "positions": {}}

    def _load_state(self, initial_capital: float) -> dict:
        if not self._state_file.exists():
            return self._empty_state(initial_capital)
        try:
            with open(self._state_file) as f:
                data = json.load(f)
            if "cash" not in data or "positions" not in data:
                raise PGTStateError(
                    f"Paper state file {self._state_file} is corrupted: "
                    "missing 'cash' or 'positions' keys. "
                    "Delete the file to reset (WARNING: this will lose paper P&L history)."
                )
            return data
        except json.JSONDecodeError as exc:
            raise PGTStateError(
                f"Paper state file {self._state_file} is corrupted (invalid JSON): {exc}. "
                "Delete the file to reset."
            ) from exc

    def _save_state(self) -> None:
        """Atomic write via os.replace() — prevents partial writes."""
        tmp = self._state_file.with_suffix(".tmp")
        try:
            self._state_file.parent.mkdir(parents=True, exist_ok=True)
            with open(tmp, "w") as f:
                json.dump(self._state, f)
            os.replace(tmp, self._state_file)
        except Exception as exc:
            _log.error("PaperEngine: state save failed: %s", exc)
            try:
                tmp.unlink(missing_ok=True)
            except Exception:
                pass
