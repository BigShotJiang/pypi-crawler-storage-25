"""
PrettyGoodTrader (pgt) — The LLM-native trading framework.
Write a prompt. Backtest it. Ship it live.

    pip install pretty-good-trader
    pgt init && pgt run --dry-run
"""

from pgt.adapters.base import BrokerAdapter, BrokerError
from pgt.adapters.paper import PaperEngine
from pgt.ai.client import PGTLLMClient, PGTLLMError
from pgt.ai.pipeline import AIPipeline
from pgt.core.config import PGTConfig
from pgt.core.engines import BacktestEngine, TradingEngine

__version__ = "0.1.0"

__all__ = [
    # Engines
    "TradingEngine",
    "BacktestEngine",
    # Adapters
    "BrokerAdapter",
    "BrokerError",
    "PaperEngine",
    # AI
    "AIPipeline",
    "PGTLLMClient",
    "PGTLLMError",
    # Config
    "PGTConfig",
    # Version
    "__version__",
]
