"""SQLite WAL logger with JSONL fallback. Suspends trading on dual-failure."""

from __future__ import annotations

import json
import logging
import sqlite3
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

_log = logging.getLogger(__name__)

SCHEMA = """
CREATE TABLE IF NOT EXISTS cycles (
    id            INTEGER PRIMARY KEY,
    timestamp     TEXT    NOT NULL,
    cycle_type    TEXT    NOT NULL CHECK(cycle_type IN (
                    'monitor','research','debate','decision','eod','backtest')),
    model         TEXT    NOT NULL,
    trace_id      TEXT,
    prompt_hash   TEXT,
    signal        TEXT,
    reasoning     TEXT,
    response_text TEXT,
    portfolio_before TEXT,
    portfolio_after  TEXT,
    citations     TEXT,
    api_cost      REAL,
    latency_ms    INTEGER,
    input_tokens  INTEGER,
    output_tokens INTEGER,
    error         TEXT
);
CREATE INDEX IF NOT EXISTS idx_cycles_timestamp ON cycles(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_cycles_type      ON cycles(cycle_type);
CREATE INDEX IF NOT EXISTS idx_cycles_trace     ON cycles(trace_id);

CREATE TABLE IF NOT EXISTS tool_calls (
    id         INTEGER PRIMARY KEY,
    cycle_id   INTEGER NOT NULL REFERENCES cycles(id),
    tool_name  TEXT    NOT NULL,
    tool_type  TEXT    NOT NULL CHECK(tool_type IN ('function','server_side')),
    call_id    TEXT,
    arguments  TEXT,
    result     TEXT,
    latency_ms INTEGER,
    error      TEXT
);
CREATE INDEX IF NOT EXISTS idx_tool_calls_cycle ON tool_calls(cycle_id);
"""


class Logger:
    """
    Primary: SQLite WAL.
    Fallback: JSONL file per day.
    is_suspended: True only when BOTH fail — ToolDispatcher blocks place_order.
    """

    def __init__(self, data_dir: Path | str = "data") -> None:
        self._data_dir = Path(data_dir)
        self._data_dir.mkdir(parents=True, exist_ok=True)
        self._db_path = self._data_dir / "pgt.db"
        self._conn: sqlite3.Connection | None = None
        self._sqlite_ok = False
        self._suspended = False
        self._init_sqlite()

    def _init_sqlite(self) -> None:
        try:
            self._conn = sqlite3.connect(
                str(self._db_path), check_same_thread=False
            )
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.executescript(SCHEMA)
            self._conn.commit()
            self._sqlite_ok = True
        except Exception as exc:
            _log.error("Logger: SQLite init failed: %s", exc)
            self._sqlite_ok = False

    @property
    def is_suspended(self) -> bool:
        return self._suspended

    def log_cycle(
        self,
        *,
        cycle_type: str,
        model: str,
        trace_id: str | None = None,
        prompt_hash: str | None = None,
        signal: Any = None,
        reasoning: str | None = None,
        response_text: str | None = None,
        portfolio_before: Any = None,
        portfolio_after: Any = None,
        citations: list | None = None,
        api_cost: float | None = None,
        latency_ms: int | None = None,
        input_tokens: int | None = None,
        output_tokens: int | None = None,
        error: str | None = None,
    ) -> int | None:
        ts = datetime.now(tz=UTC).isoformat()
        row = {
            "timestamp": ts,
            "cycle_type": cycle_type,
            "model": model,
            "trace_id": trace_id,
            "prompt_hash": prompt_hash,
            "signal": json.dumps(signal) if signal is not None else None,
            "reasoning": reasoning,
            "response_text": response_text,
            "portfolio_before": (
                json.dumps(portfolio_before) if portfolio_before is not None else None
            ),
            "portfolio_after": (
                json.dumps(portfolio_after) if portfolio_after is not None else None
            ),
            "citations": json.dumps(citations) if citations is not None else None,
            "api_cost": api_cost,
            "latency_ms": latency_ms,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "error": error,
        }

        if self._sqlite_ok and self._conn:
            try:
                cur = self._conn.execute(
                    """INSERT INTO cycles (
                        timestamp, cycle_type, model, trace_id, prompt_hash,
                        signal, reasoning, response_text,
                        portfolio_before, portfolio_after,
                        citations, api_cost, latency_ms,
                        input_tokens, output_tokens, error
                    ) VALUES (
                        :timestamp, :cycle_type, :model, :trace_id, :prompt_hash,
                        :signal, :reasoning, :response_text,
                        :portfolio_before, :portfolio_after,
                        :citations, :api_cost, :latency_ms,
                        :input_tokens, :output_tokens, :error
                    )""",
                    row,
                )
                self._conn.commit()
                return cur.lastrowid
            except Exception as exc:
                _log.error("Logger: SQLite write failed: %s", exc)
                self._sqlite_ok = False

        # JSONL fallback
        return self._write_jsonl(row)

    def log_tool_call(
        self,
        *,
        cycle_id: int,
        tool_name: str,
        tool_type: str = "function",
        call_id: str | None = None,
        arguments: dict | None = None,
        result: Any = None,
        latency_ms: int | None = None,
        error: str | None = None,
    ) -> None:
        row = {
            "cycle_id": cycle_id,
            "tool_name": tool_name,
            "tool_type": tool_type,
            "call_id": call_id,
            "arguments": json.dumps(arguments) if arguments else None,
            "result": json.dumps(result) if result is not None else None,
            "latency_ms": latency_ms,
            "error": error,
        }
        if self._sqlite_ok and self._conn:
            try:
                self._conn.execute(
                    """INSERT INTO tool_calls (
                        cycle_id, tool_name, tool_type, call_id,
                        arguments, result, latency_ms, error
                    ) VALUES (
                        :cycle_id, :tool_name, :tool_type, :call_id,
                        :arguments, :result, :latency_ms, :error
                    )""",
                    row,
                )
                self._conn.commit()
                return
            except Exception as exc:
                _log.error("Logger: SQLite tool_calls write failed: %s", exc)
                self._sqlite_ok = False

        self._write_jsonl({"_table": "tool_calls", **row})

    def _write_jsonl(self, row: dict) -> int | None:
        today = datetime.now(tz=UTC).strftime("%Y-%m-%d")
        path = self._data_dir / f"fallback_{today}.jsonl"
        try:
            with open(path, "a") as f:
                f.write(json.dumps(row) + "\n")
            return None
        except Exception as exc:
            _log.critical(
                "Logger: JSONL fallback write failed: %s — suspending trading", exc
            )
            self._suspended = True
            return None

    def get_cycle(self, cycle_id: int) -> dict | None:
        if not self._sqlite_ok or not self._conn:
            return None
        row = self._conn.execute(
            "SELECT * FROM cycles WHERE id = ?", (cycle_id,)
        ).fetchone()
        if not row:
            return None
        cols = [d[0] for d in self._conn.execute(
            "SELECT * FROM cycles LIMIT 0"
        ).description or []]
        return dict(zip(cols, row)) if cols else None

    def get_recent_cycles(self, limit: int = 20) -> list[dict]:
        if not self._sqlite_ok or not self._conn:
            return []
        rows = self._conn.execute(
            "SELECT * FROM cycles ORDER BY timestamp DESC LIMIT ?", (limit,)
        ).fetchall()
        if not rows:
            return []
        cur = self._conn.execute("SELECT * FROM cycles LIMIT 0")
        cols = [d[0] for d in cur.description or []]
        return [dict(zip(cols, r)) for r in rows]

    def close(self) -> None:
        if self._conn:
            try:
                self._conn.close()
            except Exception:
                pass
