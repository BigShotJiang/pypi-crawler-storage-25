"""EventBus — two-tier delivery for plugin fan-out."""

from __future__ import annotations

import asyncio
import logging
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime

logger = logging.getLogger(__name__)

# Event types
CRITICAL_EVENTS = frozenset({"order_placed", "engine_error", "risk_blocked"})
NON_CRITICAL_EVENTS = frozenset({"signal_detected", "eod_summary", "order_filled"})

EventHandler = Callable[["PGTEvent"], Awaitable[None]]


@dataclass
class PGTEvent:
    event_type: str  # "order_placed" | "signal_detected" | "risk_blocked"
                     #  | "eod_summary" | "engine_error" | "order_filled"
    payload: dict
    trace_id: str | None = None
    timestamp: str = field(
        default_factory=lambda: datetime.now(tz=UTC).isoformat()
    )


class EventBus:
    """
    Two-tier event delivery:
    - Critical events (order_placed, engine_error, risk_blocked):
      direct handler call with per-plugin try/except — never dropped.
    - Non-critical events (signal_detected, eod_summary, order_filled):
      per-subscriber async queue (maxsize=1000), drop on full + warn.
    """

    def __init__(self) -> None:
        self._handlers: dict[str, list[EventHandler]] = {}
        self._queues: dict[str, list[asyncio.Queue[PGTEvent]]] = {}

    def subscribe(self, event_type: str, handler: EventHandler) -> None:
        if event_type in CRITICAL_EVENTS:
            self._handlers.setdefault(event_type, []).append(handler)
        else:
            q: asyncio.Queue[PGTEvent] = asyncio.Queue(maxsize=1000)
            self._queues.setdefault(event_type, []).append(q)
            asyncio.create_task(self._drain_queue(q, handler, event_type))

    async def publish(self, event: PGTEvent) -> None:
        if event.event_type in CRITICAL_EVENTS:
            for handler in self._handlers.get(event.event_type, []):
                try:
                    await handler(event)
                except Exception as exc:
                    logger.error(
                        "EventBus: handler failed for %s: %s", event.event_type, exc
                    )
        else:
            for q in self._queues.get(event.event_type, []):
                try:
                    q.put_nowait(event)
                except asyncio.QueueFull:
                    logger.warning(
                        "EventBus: queue full for %s — event dropped", event.event_type
                    )

    async def _drain_queue(
        self,
        q: asyncio.Queue[PGTEvent],
        handler: EventHandler,
        event_type: str,
    ) -> None:
        while True:
            event = await q.get()
            try:
                await handler(event)
            except Exception as exc:
                logger.error(
                    "EventBus: handler failed for %s: %s", event_type, exc
                )
            finally:
                q.task_done()
