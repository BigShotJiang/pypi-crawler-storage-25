"""BaseEngine, TradingEngine, BacktestEngine, MultiModelBacktestEngine."""

from __future__ import annotations

import asyncio
import logging
import signal
import uuid
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from typing import TYPE_CHECKING

from pgt.ai.pipeline import AIPipeline
from pgt.core.clock import SimClock, WallClock
from pgt.core.context import RunContext
from pgt.core.scheduler import Scheduler
from pgt.data.catalog import DuckDBCatalog
from pgt.logger import Logger
from pgt.memory.reflection import ReflectionMemory
from pgt.memory.session import SessionMemory
from pgt.models import BacktestReport, BacktestResult
from pgt.risk.engine import RiskEngine

if TYPE_CHECKING:
    from pgt.adapters.base import BrokerAdapter
    from pgt.ai.client import PGTLLMClient
    from pgt.core.config import PGTConfig
    from pgt.plugins.base import PGTPlugin

_log = logging.getLogger(__name__)


def plot_equity_curve(report: BacktestReport) -> None:
    """Render ASCII equity curve using plotext, then print a Rich stats table."""
    import plotext as plt
    from rich.console import Console
    from rich.table import Table

    console = Console()

    curve = report.equity_curve
    if not curve:
        console.print("[yellow]No equity curve data to plot.[/yellow]")
    else:
        values = [v for _, v in curve]

        plt.clear_figure()
        plt.plot(values, label="Portfolio Value")
        plt.title("Equity Curve")
        plt.xlabel("Bar Index")
        plt.ylabel("Portfolio Value")
        # Use date labels at evenly spaced tick positions if plotext supports it
        plt.show()

    # Rich stats table
    table = Table(title="Backtest Stats", show_header=True, header_style="bold cyan")
    table.add_column("Metric", style="bold")
    table.add_column("Value", justify="right")

    sign = "+" if report.total_return_pct >= 0 else ""
    dd_sign = "-" if report.max_drawdown_pct > 0 else ""

    table.add_row("Total Return", f"{sign}{report.total_return_pct:.2f}%")
    table.add_row("Sharpe Ratio", f"{report.sharpe:.3f}")
    table.add_row("Max Drawdown", f"{dd_sign}{abs(report.max_drawdown_pct):.2f}%")
    table.add_row("Win Rate", f"{report.win_rate * 100:.1f}%")
    table.add_row("Total Trades", str(report.total_trades))
    table.add_row("LLM Cost", f"${report.total_llm_cost:.4f}")

    console.print(table)


class BaseEngine:
    """
    Shared foundation for TradingEngine and BacktestEngine.
    Sets ThreadPoolExecutor(max_workers=16) as default event loop executor.
    """

    def __init__(
        self,
        adapter: BrokerAdapter,
        config: PGTConfig,
        llm: PGTLLMClient | None = None,
        plugins: list[PGTPlugin] | None = None,
        data_dir: str = "data",
    ) -> None:
        self._adapter = adapter
        self._config = config
        self._plugins = plugins or []
        self._data_dir = data_dir

        # Set explicit thread pool — default pool exhausts under concurrent to_thread() calls
        self._executor = ThreadPoolExecutor(max_workers=16)

        # Build components
        from pgt.ai.client import PGTLLMClient

        self._llm = llm or PGTLLMClient(config)
        self._risk = RiskEngine()
        self._memory = ReflectionMemory(storage_path=f"{data_dir}/memory.json")
        self._session = SessionMemory(
            storage_path=f"{data_dir}/session.json",
            cooldown_seconds=config.signal_cooldown,
        )
        self._logger = Logger(data_dir=data_dir)
        self._pipeline = AIPipeline()

    def _build_context(self, is_backtest: bool = False) -> RunContext:
        from pgt.core.clock import SimClock

        clock = SimClock() if is_backtest else WallClock()
        return RunContext(
            adapter=self._adapter,
            llm=self._llm,
            risk=self._risk,
            memory=self._memory,
            session=self._session,
            logger=self._logger,
            plugins=self._plugins,
            config=self._config,
            clock=clock,
            is_backtest=is_backtest,
        )

    async def _startup(self, ctx: RunContext) -> None:
        """Validate keys and call plugin on_startup."""
        self._llm.validate_keys()
        for plugin in self._plugins:
            try:
                await plugin.on_startup(ctx)
            except Exception as exc:
                _log.error("Plugin.on_startup failed: %s", exc)

    async def _shutdown(self, ctx: RunContext) -> None:
        """Call plugin on_shutdown and close resources."""
        for plugin in self._plugins:
            try:
                await plugin.on_shutdown()
            except Exception as exc:
                _log.error("Plugin.on_shutdown failed: %s", exc)
        self._logger.close()
        self._executor.shutdown(wait=False)


class TradingEngine(BaseEngine):
    """
    Live / paper trading engine. Uses WallClock + market-hours Scheduler.
    Handles SIGTERM for graceful shutdown.
    """

    def __init__(
        self,
        adapter: BrokerAdapter,
        config: PGTConfig,
        llm: PGTLLMClient | None = None,
        plugins: list[PGTPlugin] | None = None,
        data_dir: str = "data",
    ) -> None:
        super().__init__(adapter, config, llm, plugins, data_dir)
        self._running = False

    async def run(self) -> None:
        """Start the trading engine. Runs until SIGTERM or stop() is called."""
        loop = asyncio.get_event_loop()
        loop.set_default_executor(self._executor)

        ctx = self._build_context(is_backtest=False)
        await self._startup(ctx)

        self._running = True

        # SIGTERM graceful shutdown
        for sig in (signal.SIGTERM, signal.SIGINT):
            try:
                loop.add_signal_handler(sig, lambda: asyncio.create_task(self._stop(ctx)))
            except NotImplementedError:
                pass  # Windows doesn't support add_signal_handler

        scheduler = Scheduler(
            clock=ctx.clock,
            interval=self._config.monitor_interval,
            premarket_start=self._config.premarket_start,
            market_close=self._config.market_close,
            eod_time=self._config.eod_time,
            weekend_interval=self._config.weekend_interval,
        )

        # Set initial equity for daily drawdown check
        try:
            portfolio = await ctx.adapter.get_portfolio()
            ctx.risk.set_initial_equity(portfolio.equity)
        except Exception as exc:
            _log.warning("Could not fetch initial portfolio: %s", exc)

        _log.info(
            "TradingEngine started [paper=%s, exchange=%s]",
            self._config.paper,
            ctx.adapter.exchange_name,
        )

        await scheduler.run(
            cycle_fn=lambda: self._pipeline.run(ctx),
            eod_fn=lambda: self._run_eod(ctx),
        )

        await self._shutdown(ctx)

    async def _stop(self, ctx: RunContext) -> None:
        self._running = False
        _log.info("TradingEngine: shutdown signal received")

    async def _run_eod(self, ctx: RunContext) -> None:
        _log.info("TradingEngine: running EOD summary")
        # TODO: call LLM for EOD summary, store in reflection memory
        for plugin in ctx.plugins:
            try:
                pass  # on_eod_summary called after LLM summary (Phase 2)
            except Exception as exc:
                _log.error("Plugin.on_eod_summary failed: %s", exc)


class BacktestEngine(BaseEngine):
    """
    Replays historical data from DuckDB catalog through the full AIPipeline.
    Uses SimClock — all components are identical to TradingEngine.
    """

    def __init__(
        self,
        adapter: BrokerAdapter,
        config: PGTConfig,
        start: str | datetime,
        end: str | datetime,
        catalog: DuckDBCatalog | None = None,
        tickers: list[str] | None = None,
        run_id: str | None = None,
        llm: PGTLLMClient | None = None,
        plugins: list[PGTPlugin] | None = None,
        data_dir: str = "data",
    ) -> None:
        super().__init__(adapter, config, llm, plugins, data_dir)
        self._start = start
        self._end = end
        self._catalog = catalog or DuckDBCatalog(f"{data_dir}/catalog.db")
        self._tickers = tickers
        self._run_id = run_id or str(uuid.uuid4())

    async def run(self) -> BacktestResult:
        """
        Replay historical data. Returns BacktestResult with metrics.
        load_range() does ONE DuckDB range scan — zero per-bar I/O.
        """
        loop = asyncio.get_event_loop()
        loop.set_default_executor(self._executor)

        ctx = self._build_context(is_backtest=True)

        await self._startup(ctx)

        _log.info(
            "BacktestEngine started [run_id=%s, %s → %s]",
            self._run_id, self._start, self._end
        )

        # Single range scan — raises PGTCatalogError on failure (fail fast)
        bars = self._catalog.load_range(self._start, self._end, self._tickers)

        if not bars:
            _log.warning("BacktestEngine: no bars loaded for range %s → %s", self._start, self._end)
            await self._shutdown(ctx)
            return self._empty_result()

        initial_portfolio = await ctx.adapter.get_portfolio()
        initial_equity = initial_portfolio.equity
        ctx.risk.set_initial_equity(initial_equity)

        equity_curve: list[dict] = []

        for bar_index, (ts, prices) in enumerate(sorted(bars.items())):
            assert isinstance(ctx.clock, SimClock)
            ctx.clock.advance_to(ts)

            # Run full pipeline directly (no Scheduler — market hours gating is meaningless in replay)  # noqa: E501
            await self._pipeline.run(ctx)

            # Track equity
            portfolio = await ctx.adapter.get_portfolio()
            equity_curve.append({
                "timestamp": ts.isoformat(),
                "equity": portfolio.equity,
                "cash": portfolio.cash,
            })

            # Checkpoint
            if (bar_index + 1) % self._config.backtest_checkpoint_interval == 0:
                self._catalog.save_checkpoint(
                    run_id=self._run_id,
                    bar_index=bar_index,
                    timestamp=ts.isoformat(),
                    equity=portfolio.equity,
                    cash=portfolio.cash,
                )

        await self._shutdown(ctx)

        return self._build_report(equity_curve, initial_equity)

    def _build_report(
        self, equity_curve: list[dict], initial_equity: float
    ) -> BacktestResult:
        if not equity_curve:
            return self._empty_result()

        equities = [e["equity"] for e in equity_curve]
        final_equity = equities[-1]
        total_pnl = final_equity - initial_equity

        # Sharpe ratio (simplified: annualized)
        import statistics
        returns = [
            (equities[i] - equities[i - 1]) / equities[i - 1]
            for i in range(1, len(equities))
            if equities[i - 1] > 0
        ]
        mean_r = statistics.mean(returns) if returns else 0
        std_r = statistics.stdev(returns) if len(returns) > 1 else 1
        sharpe = (mean_r / std_r * (252 ** 0.5)) if std_r > 0 else 0

        # Max drawdown
        peak = equities[0]
        max_dd = 0.0
        for eq in equities:
            if eq > peak:
                peak = eq
            dd = (peak - eq) / peak if peak > 0 else 0
            max_dd = max(max_dd, dd)

        return BacktestResult(
            run_id=self._run_id,
            start=str(self._start),
            end=str(self._end),
            exchange=self._adapter.exchange_name,
            initial_capital=initial_equity,
            final_equity=final_equity,
            total_trades=0,  # TODO: count from logger
            win_rate=0.0,
            sharpe_ratio=round(sharpe, 3),
            max_drawdown=round(max_dd, 4),
            total_pnl=round(total_pnl, 2),
            equity_curve=equity_curve,
            model_used=self._config.trader_model,
        )

    def _empty_result(self) -> BacktestResult:
        return BacktestResult(
            run_id=self._run_id,
            start=str(self._start),
            end=str(self._end),
            exchange=self._adapter.exchange_name,
            initial_capital=0.0,
            final_equity=0.0,
            total_trades=0,
            win_rate=0.0,
            sharpe_ratio=0.0,
            max_drawdown=0.0,
            total_pnl=0.0,
        )


def compare_models_table(results: list[tuple[str, BacktestReport]]) -> None:
    """Print a Rich side-by-side comparison table of backtest results across models.

    Highlights the best value in each numeric column with green.
    """
    from rich.console import Console
    from rich.table import Table

    console = Console()

    table = Table(
        title="Multi-Model Backtest Comparison",
        show_header=True,
        header_style="bold cyan",
    )
    table.add_column("Model", style="bold")
    table.add_column("Total Return %", justify="right")
    table.add_column("Sharpe", justify="right")
    table.add_column("Max Drawdown %", justify="right")
    table.add_column("Win Rate %", justify="right")
    table.add_column("Total Trades", justify="right")
    table.add_column("LLM Cost $", justify="right")

    if not results:
        console.print(table)
        return

    # Find best values for each numeric column
    best_return = max(r.total_return_pct for _, r in results)
    best_sharpe = max(r.sharpe for _, r in results)
    best_drawdown = min(r.max_drawdown_pct for _, r in results)  # lower is better
    best_win_rate = max(r.win_rate for _, r in results)
    best_trades = max(r.total_trades for _, r in results)
    best_cost = min(r.total_llm_cost for _, r in results)  # lower is better

    def _fmt(value: float, best: float, fmt: str, lower_better: bool = False) -> str:
        is_best = (value <= best) if lower_better else (value >= best)
        formatted = fmt.format(value)
        return f"[green bold]{formatted}[/green bold]" if is_best else formatted

    for model_name, report in results:
        table.add_row(
            model_name,
            _fmt(report.total_return_pct, best_return, "{:.2f}%"),
            _fmt(report.sharpe, best_sharpe, "{:.3f}"),
            _fmt(report.max_drawdown_pct, best_drawdown, "{:.2f}%", lower_better=True),
            _fmt(report.win_rate * 100, best_win_rate * 100, "{:.1f}%"),
            _fmt(float(report.total_trades), float(best_trades), "{:.0f}"),
            _fmt(report.total_llm_cost, best_cost, "${:.4f}", lower_better=True),
        )

    console.print(table)


class MultiModelBacktestEngine:
    """
    Run same strategy across N LLM providers in parallel.
    Uses asyncio.gather() for concurrent execution.
    """

    def __init__(
        self,
        adapter: BrokerAdapter,
        config: PGTConfig,
        models: list[str],
        plugins: list[PGTPlugin] | None = None,
        data_dir: str = "data",
    ) -> None:
        self._adapter = adapter
        self._config = config
        self._models = models
        self._plugins = plugins or []
        self._data_dir = data_dir

    async def run(
        self,
        start: str,
        end: str,
        initial_capital: float = 100_000.0,
    ) -> list[tuple[str, BacktestReport]]:
        """Run backtests for all models concurrently.

        Returns list of (model_name, BacktestReport) tuples.
        If a model's engine raises, it is included with a zeroed BacktestReport.
        """

        async def _run_single(model: str) -> tuple[str, BacktestReport]:
            model_config = self._config.model_copy(
                update={
                    "research_model": model,
                    "decision_model": model,
                    "monitor_model": model,
                    "trader_model": model,
                }
            )
            engine = BacktestEngine(
                adapter=self._adapter,
                config=model_config,
                start=start,
                end=end,
                data_dir=self._data_dir,
                plugins=self._plugins,
            )
            try:
                result = await engine.run()
                report = BacktestReport.from_backtest_result(result)
            except Exception as exc:
                _log.error("MultiModelBacktestEngine: model %s failed: %s", model, exc)
                report = BacktestReport(
                    total_return_pct=0.0,
                    sharpe=0.0,
                    max_drawdown_pct=0.0,
                    win_rate=0.0,
                    total_trades=0,
                    total_llm_cost=0.0,
                )
            return (model, report)

        tasks = [_run_single(model) for model in self._models]
        results: list[tuple[str, BacktestReport]] = await asyncio.gather(*tasks)
        return list(results)
