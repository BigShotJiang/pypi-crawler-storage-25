"""PGTConfig — fully typed, validated at startup via pydantic-settings."""

from __future__ import annotations

from pydantic import Field, SecretStr, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class PGTConfig(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        # No prefix — keeps .env compatible with grok-trader / grok-crypto
    )

    # ─── LLM ───────────────────────────────────────────────────────────────
    monitor_model: str = "xai/grok-4-1-fast"
    research_model: str = "xai/grok-4-1-fast"
    trader_model: str = "xai/grok-4.20-reasoning"
    xai_api_key: SecretStr | None = None
    anthropic_api_key: SecretStr | None = None
    openai_api_key: SecretStr | None = None

    # ─── Tool call limits ──────────────────────────────────────────────────
    max_monitor_tool_calls: int = 5
    max_research_tool_calls: int = 5
    max_decision_tool_calls: int = 3

    # ─── Feature flags ─────────────────────────────────────────────────────
    fundamentals_enabled: bool = True
    indicators_enabled: bool = True
    reflection_enabled: bool = True
    debate_enabled: bool = False
    risk_debate_enabled: bool = False
    paper: bool = True  # default safe: paper mode

    # ─── Scheduling ────────────────────────────────────────────────────────
    monitor_interval: int = 180          # seconds
    premarket_start: str = "08:30"       # ET
    market_close: str = "16:00"          # ET
    eod_time: str = "16:05"              # ET
    min_urgency: str = "medium"
    signal_cooldown: int = 900           # seconds per ticker
    weekend_interval: int = 1800         # seconds (30 min)

    # ─── Risk ──────────────────────────────────────────────────────────────
    max_position_pct: float = 0.05
    max_daily_loss_pct: float = 0.05
    max_open_positions: int = 20
    min_cash_reserve_pct: float = 0.10
    paper_initial_capital: float = 10_000.0
    paper_taker_fee: float = 0.001       # 0.10%
    emergency_liquidate_token: SecretStr | None = None

    # ─── Backtest ──────────────────────────────────────────────────────────
    backtest_llm_temperature: float = 0.0
    backtest_checkpoint_interval: int = 100

    # ─── Search ────────────────────────────────────────────────────────────
    max_search_results: int = 5
    max_snippet_len: int = 200
    max_content_len: int = 2000
    firecrawl_timeout: int = 30
    search_per_domain_rate_limit_rps: float = 0.5
    search_cache_ttl: int = 300
    searxng_url: str = "http://searxng:8080"
    firecrawl_url: str = "http://firecrawl-api:3002"

    # ─── Telegram ──────────────────────────────────────────────────────────
    telegram_bot_token: SecretStr | None = None
    telegram_allowed_chat_id: int | None = None
    telegram_use_webhook: bool = False

    # ─── Broker credentials ────────────────────────────────────────────────
    alpaca_api_key: SecretStr | None = None
    alpaca_secret_key: SecretStr | None = None
    kraken_api_key: SecretStr | None = None
    kraken_secret: SecretStr | None = None
    ccxt_exchange: str = "binance"
    ccxt_api_key: SecretStr | None = None
    ccxt_secret: SecretStr | None = None

    # ─── Ticker allowlist (optional) ───────────────────────────────────────
    ticker_allowlist: list[str] = Field(default_factory=list)

    # ─── xAI Responses API (optional, Phase 1) ─────────────────────────────
    use_xai_responses_api: bool = False

    @model_validator(mode="after")
    def _validate_live_safety(self) -> PGTConfig:
        if not self.paper and self.emergency_liquidate_token is None:
            raise ValueError(
                "EMERGENCY_LIQUIDATE_TOKEN is required when PAPER=false. "
                "Set it in .env before enabling live trading."
            )
        return self
