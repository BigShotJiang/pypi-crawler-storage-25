"""Market-hours-aware async scheduler — TradingEngine only (not BacktestEngine)."""

from __future__ import annotations

import logging
from collections.abc import Awaitable, Callable
from datetime import datetime, time
from zoneinfo import ZoneInfo

from pgt.core.clock import PGTClock

logger = logging.getLogger(__name__)

ET = ZoneInfo("America/New_York")


class Scheduler:
    """
    Fires a coroutine on a configurable interval.
    Respects premarket_start and market_close for US equity exchanges.
    For 24/7 exchanges (Kraken, crypto), pass market_hours=False.
    """

    def __init__(
        self,
        clock: PGTClock,
        interval: int,
        premarket_start: str = "08:30",
        market_close: str = "16:00",
        eod_time: str = "16:05",
        weekend_interval: int = 1800,
        market_hours: bool = True,
    ) -> None:
        self._clock = clock
        self._interval = interval
        self._premarket_start = time.fromisoformat(premarket_start)
        self._market_close = time.fromisoformat(market_close)
        self._eod_time = time.fromisoformat(eod_time)
        self._weekend_interval = weekend_interval
        self._market_hours = market_hours
        self._running = False

    def _is_trading_hours(self, now: datetime) -> bool:
        if not self._market_hours:
            return True
        et_now = now.astimezone(ET)
        if et_now.weekday() >= 5:  # Saturday=5, Sunday=6
            return False
        t = et_now.time().replace(second=0, microsecond=0)
        return self._premarket_start <= t < self._market_close

    def _is_weekend(self, now: datetime) -> bool:
        return now.astimezone(ET).weekday() >= 5

    async def run(
        self,
        cycle_fn: Callable[[], Awaitable[None]],
        eod_fn: Callable[[], Awaitable[None]] | None = None,
    ) -> None:
        self._running = True
        _eod_fired_today: str | None = None

        while self._running:
            now = self._clock.now()

            if self._market_hours:
                et_now = now.astimezone(ET)
                today_str = et_now.strftime("%Y-%m-%d")
                eod_t = et_now.time().replace(second=0, microsecond=0)

                if (
                    eod_fn
                    and eod_t >= self._eod_time
                    and _eod_fired_today != today_str
                ):
                    _eod_fired_today = today_str
                    try:
                        await eod_fn()
                    except Exception as exc:
                        logger.error("Scheduler: eod_fn failed: %s", exc)

                if not self._is_trading_hours(now):
                    sleep_s = self._weekend_interval if self._is_weekend(now) else 60
                    logger.debug("Scheduler: outside trading hours, sleeping %ds", sleep_s)
                    await self._clock.sleep(sleep_s)
                    continue

            try:
                await cycle_fn()
            except Exception as exc:
                logger.error("Scheduler: cycle_fn failed: %s", exc)

            await self._clock.sleep(self._interval)

    def stop(self) -> None:
        self._running = False
