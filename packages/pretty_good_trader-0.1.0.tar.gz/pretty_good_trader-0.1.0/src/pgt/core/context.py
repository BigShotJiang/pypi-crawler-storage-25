"""RunContext — passed to every component; no global state, fully injectable."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pgt.adapters.base import BrokerAdapter
    from pgt.ai.client import PGTLLMClient
    from pgt.core.clock import PGTClock
    from pgt.core.config import PGTConfig
    from pgt.logger import Logger
    from pgt.memory.annotations import AnnotationMemory
    from pgt.memory.reflection import ReflectionMemory
    from pgt.memory.session import SessionMemory
    from pgt.plugins.base import PGTPlugin
    from pgt.risk.engine import RiskEngine


@dataclass
class RunContext:
    adapter: BrokerAdapter
    llm: PGTLLMClient
    risk: RiskEngine
    memory: ReflectionMemory
    session: SessionMemory
    logger: Logger
    plugins: list[PGTPlugin]
    config: PGTConfig
    clock: PGTClock
    is_backtest: bool = False
    cycle_id: int = 0
    trace_id: str | None = None
    annotations: AnnotationMemory | None = None
