"""PGTClock abstraction — same code runs in live and backtest mode."""

from __future__ import annotations

import asyncio
from abc import ABC, abstractmethod
from datetime import UTC, datetime


class PGTClock(ABC):
    """Abstract clock. WallClock for live trading, SimClock for backtests."""

    @abstractmethod
    def now(self) -> datetime: ...

    @abstractmethod
    async def sleep(self, seconds: float) -> None: ...


class WallClock(PGTClock):
    """Used by TradingEngine — reads actual wall time."""

    def now(self) -> datetime:
        return datetime.now(tz=UTC)

    async def sleep(self, seconds: float) -> None:
        await asyncio.sleep(seconds)


class SimClock(PGTClock):
    """Used by BacktestEngine — advanced by data replay. sleep() is a no-op."""

    def __init__(self, start: datetime | None = None) -> None:
        self._current: datetime = start or datetime.now(tz=UTC)

    def now(self) -> datetime:
        return self._current

    async def sleep(self, seconds: float) -> None:
        pass  # no-op in simulation

    def advance_to(self, ts: datetime) -> None:
        """Called by BacktestEngine for each bar timestamp."""
        self._current = ts
