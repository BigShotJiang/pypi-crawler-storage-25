"""TTL-aware disk cache for adapter discovery results and fundamentals."""

from __future__ import annotations

import json
import logging
import time
from pathlib import Path
from typing import Any

_log = logging.getLogger(__name__)


class DiskCache:
    """Simple file-based TTL cache. One JSON file per key."""

    def __init__(self, cache_dir: Path | str = "data/cache") -> None:
        self._dir = Path(cache_dir)
        self._dir.mkdir(parents=True, exist_ok=True)

    def _path(self, key: str) -> Path:
        safe = key.replace("/", "_").replace(":", "_")
        return self._dir / f"{safe}.json"

    def get(self, key: str) -> Any | None:
        p = self._path(key)
        if not p.exists():
            return None
        try:
            with open(p) as f:
                entry = json.load(f)
            if time.time() > entry["expires_at"]:
                p.unlink(missing_ok=True)
                return None
            return entry["value"]
        except Exception as exc:
            _log.debug("DiskCache.get failed for %s: %s", key, exc)
            return None

    def set(self, key: str, value: Any, ttl: int = 300) -> None:
        p = self._path(key)
        try:
            with open(p, "w") as f:
                json.dump({"value": value, "expires_at": time.time() + ttl}, f)
        except Exception as exc:
            _log.debug("DiskCache.set failed for %s: %s", key, exc)

    def delete(self, key: str) -> None:
        self._path(key).unlink(missing_ok=True)

    def clear(self) -> None:
        for f in self._dir.glob("*.json"):
            f.unlink(missing_ok=True)
