"""Persistent user annotations on cycles, stored in JSONL."""

from __future__ import annotations

import json
import threading
from datetime import UTC, datetime
from pathlib import Path


class AnnotationMemory:
    """Thread-safe JSONL-backed store for user annotations on trading cycles."""

    def __init__(self, storage_path: str | Path = "data/annotations.jsonl") -> None:
        self._path = Path(storage_path)
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()

    def add(self, cycle_id: int, text: str) -> None:
        """Append an annotation for the given cycle_id."""
        entry = {
            "cycle_id": cycle_id,
            "text": text,
            "timestamp": datetime.now(tz=UTC).isoformat(),
        }
        with self._lock:
            with open(self._path, "a") as f:
                f.write(json.dumps(entry) + "\n")

    def get(self, cycle_id: int) -> list[str]:
        """Return all annotation texts for a given cycle_id."""
        return [
            entry["text"]
            for entry in self._read_all()
            if entry.get("cycle_id") == cycle_id
        ]

    def all(self) -> list[dict]:
        """Return all annotations as a list of dicts."""
        return self._read_all()

    def inject_context(self, cycle_id: int) -> str:
        """Return a formatted string of annotations for prompt injection."""
        annotations = self.get(cycle_id)
        if not annotations:
            return ""
        lines = "\n".join(f"- {a}" for a in annotations)
        return f"User annotations for cycle {cycle_id}:\n{lines}\n"

    def _read_all(self) -> list[dict]:
        if not self._path.exists():
            return []
        entries: list[dict] = []
        with self._lock:
            with open(self._path) as f:
                for line in f:
                    line = line.strip()
                    if line:
                        try:
                            entries.append(json.loads(line))
                        except json.JSONDecodeError:
                            pass
        return entries
