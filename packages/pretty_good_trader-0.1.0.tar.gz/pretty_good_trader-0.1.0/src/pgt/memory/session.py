"""In-process session memory — cooldown timestamps and recent orders."""

from __future__ import annotations

import json
import logging
import time
from pathlib import Path

from pgt.models import OrderRecord, OrderSide

_log = logging.getLogger(__name__)


class SessionMemory:
    """
    Holds cooldown_timestamps and recent_orders (TTL-filtered on load).
    Persisted to disk so state survives engine restarts.
    """

    def __init__(
        self,
        storage_path: Path | str = "data/session.json",
        cooldown_seconds: int = 900,
    ) -> None:
        self._path = Path(storage_path)
        self._cooldown = cooldown_seconds
        self.cooldown_timestamps: dict[str, float] = {}
        self.recent_orders: list[OrderRecord] = []
        self._load()

    # ─── Cooldown ──────────────────────────────────────────────────────

    def is_on_cooldown(self, ticker: str) -> bool:
        ts = self.cooldown_timestamps.get(ticker)
        if ts is None:
            return False
        return time.time() - ts < self._cooldown

    def set_cooldown(self, ticker: str) -> None:
        self.cooldown_timestamps[ticker] = time.time()
        self._save()

    # ─── Recent orders ─────────────────────────────────────────────────

    def record_order(self, ticker: str, side: OrderSide) -> None:
        self.recent_orders.append(
            OrderRecord(ticker=ticker, side=side, timestamp=time.time())
        )
        self._save()

    def get_recent_orders(self, window_seconds: int = 60) -> list[OrderRecord]:
        cutoff = time.time() - window_seconds
        return [o for o in self.recent_orders if o.timestamp >= cutoff]

    # ─── Persistence ───────────────────────────────────────────────────

    def _load(self) -> None:
        if not self._path.exists():
            return
        try:
            with open(self._path) as f:
                data = json.load(f)

            now = time.time()

            # TTL-filter cooldown timestamps on load
            self.cooldown_timestamps = {
                ticker: ts
                for ticker, ts in data.get("cooldown_timestamps", {}).items()
                if now - ts < self._cooldown
            }

            # TTL-filter recent_orders on load (keep within cooldown window)
            cutoff = now - self._cooldown
            self.recent_orders = [
                OrderRecord(**r)
                for r in data.get("recent_orders", [])
                if r.get("timestamp", 0) >= cutoff
            ]
        except Exception as exc:
            _log.error("SessionMemory: load failed: %s", exc)

    def _save(self) -> None:
        try:
            self._path.parent.mkdir(parents=True, exist_ok=True)
            with open(self._path, "w") as f:
                json.dump(
                    {
                        "cooldown_timestamps": self.cooldown_timestamps,
                        "recent_orders": [o.model_dump() for o in self.recent_orders],
                    },
                    f,
                    indent=2,
                )
        except Exception as exc:
            _log.error("SessionMemory: save failed: %s", exc)
