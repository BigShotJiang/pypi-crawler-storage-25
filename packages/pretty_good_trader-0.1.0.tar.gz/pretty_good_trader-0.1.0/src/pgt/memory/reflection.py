"""BM25Plus-indexed persistent trade reflection memory."""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

from pgt.models import TradeReflection

_log = logging.getLogger(__name__)


class ReflectionMemory:
    """
    BM25Plus-indexed persistent memory of past trade lessons.

    Index strategy: self._index is rebuilt once after each add_reflection() call.
    search() uses the cached index — never rebuilds. This ensures search() is
    always O(1) cache hit while the index stays fresh.
    At 250 entries × ~200 tokens, one rebuild takes < 2ms — acceptable at EOD cadence.
    """

    def __init__(
        self,
        storage_path: Path | str = "data/memory.json",
        max_entries: int = 250,
    ) -> None:
        self._path = Path(storage_path)
        self._max_entries = max_entries
        self._corpus: list[TradeReflection] = []
        self._index: Any | None = None  # BM25Plus instance or None
        self._load()

    def add_reflection(self, reflection: TradeReflection) -> None:
        """Called at EOD cycle. Auto-rotates at max_entries (FIFO), then rebuilds index."""
        self._corpus.append(reflection)
        self._rotate()
        self._rebuild_index()
        self._save()

    def search(self, query: str, top_k: int = 3) -> list[TradeReflection]:
        """BM25Plus retrieval — uses cached index (never rebuilds on search)."""
        if self._index is None or not self._corpus:
            return []
        tokens = query.lower().split()
        scores = self._index.get_scores(tokens)
        top_indices = sorted(
            range(len(scores)), key=lambda i: scores[i], reverse=True
        )[:top_k]
        return [self._corpus[i] for i in top_indices if scores[i] > 0]

    def _rotate(self) -> None:
        """FIFO eviction if > max_entries. Private — called only inside add_reflection."""
        if len(self._corpus) > self._max_entries:
            self._corpus = self._corpus[-self._max_entries:]

    def _rebuild_index(self) -> None:
        try:
            from rank_bm25 import BM25Plus
        except ImportError:
            _log.warning("rank-bm25 not installed — reflection search disabled")
            return

        corpus_tokens = [r.tokens for r in self._corpus]
        self._index = BM25Plus(corpus_tokens) if corpus_tokens else None

    def _load(self) -> None:
        if not self._path.exists():
            return
        try:
            with open(self._path) as f:
                data = json.load(f)
            self._corpus = [TradeReflection(**r) for r in data.get("reflections", [])]
            if self._corpus:
                self._rebuild_index()
        except Exception as exc:
            _log.error("ReflectionMemory: load failed: %s", exc)

    def _save(self) -> None:
        try:
            self._path.parent.mkdir(parents=True, exist_ok=True)
            with open(self._path, "w") as f:
                json.dump(
                    {"reflections": [r.model_dump() for r in self._corpus]},
                    f,
                    indent=2,
                )
        except Exception as exc:
            _log.error("ReflectionMemory: save failed: %s", exc)

    def __len__(self) -> int:
        return len(self._corpus)
