"""TelegramPlugin — real-time alerts with chat_id whitelist."""

from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING

from pgt.plugins.base import PGTPlugin

if TYPE_CHECKING:
    from pgt.core.context import RunContext
    from pgt.models import (
        EODSummary,
        MonitorSignal,
        OrderIntent,
        OrderResult,
        PortfolioSnapshot,
    )

_log = logging.getLogger(__name__)


class TelegramPlugin(PGTPlugin):
    """
    Sends trade alerts and signals to a Telegram chat.
    TELEGRAM_ALLOWED_CHAT_ID whitelist enforced — rejects all unknown senders.
    Requires: pip install pretty-good-trader[telegram]
    """

    def __init__(self, token: str, allowed_chat_id: int) -> None:
        try:
            from telegram import Bot  # noqa: F401
            from telegram.ext import Application  # noqa: F401
        except ImportError:
            raise ImportError(
                "python-telegram-bot is required: pip install pretty-good-trader[telegram]"
            )

        self._token = token
        self._allowed_chat_id = allowed_chat_id
        self._bot = None

    async def on_startup(self, ctx: RunContext) -> None:
        from telegram import Bot

        self._bot = Bot(token=self._token)
        try:
            await self._bot.send_message(
                chat_id=self._allowed_chat_id,
                text=(
                    f"🟢 PGT started [paper={ctx.config.paper},"
                    f" exchange={ctx.adapter.exchange_name}]"
                ),
            )
        except Exception as exc:
            _log.error("TelegramPlugin.on_startup: %s", exc)

    async def on_order_placed(
        self, order: OrderResult, portfolio: PortfolioSnapshot
    ) -> None:
        if not self._bot:
            return
        emoji = "📈" if str(order.side) == "buy" else "📉"
        msg = (
            f"{emoji} {order.side.value.upper()} {order.qty} {order.ticker} "
            f"@ ${order.fill_price:.2f}\n"
            f"Portfolio equity: ${portfolio.equity:.2f}"
        )
        asyncio.create_task(self._send(msg))

    async def on_order_blocked(self, reason: str, intent: OrderIntent) -> None:
        asyncio.create_task(self._send(f"⛔ Order blocked: {reason}"))

    async def on_error(self, error: Exception, context: str) -> None:
        asyncio.create_task(self._send(f"⚠️ Error in {context}: {error}"))

    async def on_signal_detected(self, signal: MonitorSignal) -> None:
        tickers = ", ".join(signal.tickers)
        asyncio.create_task(
            self._send(f"🔍 Signal: {tickers} [{signal.urgency.value}] — {signal.reason}")
        )

    async def on_eod_summary(self, summary: EODSummary) -> None:
        pnl_emoji = "📈" if summary.pnl_today >= 0 else "📉"
        msg = (
            f"{pnl_emoji} EOD Summary\n"
            f"P&L today: ${summary.pnl_today:+.2f}\n"
            f"Trades: {summary.trades_today}\n"
            f"Equity: ${summary.portfolio.equity:.2f}"
        )
        asyncio.create_task(self._send(msg))

    async def on_shutdown(self) -> None:
        asyncio.create_task(self._send("🔴 PGT stopped"))

    async def _send(self, text: str) -> None:
        if not self._bot:
            return
        try:
            await self._bot.send_message(chat_id=self._allowed_chat_id, text=text)
        except Exception as exc:
            _log.error("TelegramPlugin._send failed: %s", exc)
