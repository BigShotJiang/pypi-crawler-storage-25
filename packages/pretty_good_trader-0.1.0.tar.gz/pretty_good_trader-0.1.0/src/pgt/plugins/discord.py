"""DiscordPlugin — trade alerts to Discord webhook."""

from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING

import httpx

from pgt.plugins.base import PGTPlugin

if TYPE_CHECKING:
    from pgt.models import OrderIntent, OrderResult, PortfolioSnapshot

_log = logging.getLogger(__name__)


class DiscordPlugin(PGTPlugin):
    """Sends trade alerts to a Discord webhook URL."""

    def __init__(self, webhook_url: str) -> None:
        self._webhook_url = webhook_url

    async def on_order_placed(
        self, order: OrderResult, portfolio: PortfolioSnapshot
    ) -> None:
        emoji = "📈" if str(order.side) == "buy" else "📉"
        asyncio.create_task(
            self._send(
                f"{emoji} **{order.side.value.upper()} {order.qty} {order.ticker}** "
                f"@ ${order.fill_price:.2f} | Equity: ${portfolio.equity:.2f}"
            )
        )

    async def on_order_blocked(self, reason: str, intent: OrderIntent) -> None:
        asyncio.create_task(self._send(f"⛔ Order blocked: {reason}"))

    async def on_error(self, error: Exception, context: str) -> None:
        asyncio.create_task(self._send(f"⚠️ Error in `{context}`: {error}"))

    async def _send(self, content: str) -> None:
        try:
            async with httpx.AsyncClient(timeout=10) as client:
                await client.post(self._webhook_url, json={"content": content})
        except Exception as exc:
            _log.error("DiscordPlugin._send failed: %s", exc)
