"""PGTPlugin ABC — no-op defaults for all hooks."""

from __future__ import annotations

from abc import ABC
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pgt.core.context import RunContext
    from pgt.models import (
        EODSummary,
        MonitorSignal,
        OrderFill,
        OrderIntent,
        OrderResult,
        PortfolioSnapshot,
    )


class PGTPlugin(ABC):
    """
    All methods have default no-op implementations.
    Only override the hooks your plugin needs.
    Exceptions in any hook are caught, logged, and do NOT crash the engine.
    """

    async def on_startup(self, ctx: RunContext) -> None:
        pass

    async def on_signal_detected(self, signal: MonitorSignal) -> None:
        pass

    async def on_order_placed(
        self, order: OrderResult, portfolio: PortfolioSnapshot
    ) -> None:
        pass

    async def on_order_filled(self, fill: OrderFill) -> None:
        pass

    async def on_order_blocked(self, reason: str, intent: OrderIntent) -> None:
        pass

    async def on_eod_summary(self, summary: EODSummary) -> None:
        pass

    async def on_error(self, error: Exception, context: str) -> None:
        pass

    async def on_shutdown(self) -> None:
        pass
