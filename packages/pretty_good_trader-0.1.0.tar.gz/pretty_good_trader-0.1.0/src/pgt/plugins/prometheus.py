"""PrometheusPlugin — 8 core metrics, HTTP /metrics endpoint on port 9090."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from pgt.plugins.base import PGTPlugin

if TYPE_CHECKING:
    from pgt.core.context import RunContext
    from pgt.models import EODSummary, MonitorSignal, OrderIntent, OrderResult, PortfolioSnapshot

_log = logging.getLogger(__name__)


class PrometheusPlugin(PGTPlugin):
    """
    Exposes Prometheus metrics at HTTP /metrics.
    Requires: pip install pretty-good-trader[prometheus]

    Metrics:
      pgt_monitor_signal_rate          — Counter — incremented on each monitor cycle signal
      pgt_cycle_duration_seconds       — Histogram{cycle_type} — duration of each pipeline cycle
      pgt_api_cost_total               — Counter{provider} — total API cost in dollars
      pgt_trade_count_total            — Counter{action, ticker} — total trades placed
      pgt_portfolio_value              — Gauge — current portfolio equity
      pgt_risk_blocked_total           — Counter — orders blocked by risk engine
      pgt_llm_tokens_total             — Counter{type} — LLM tokens used (type: prompt|completion)
      pgt_errors_total                 — Counter{error_type} — total errors by type
    """

    def __init__(self, port: int = 9090) -> None:
        try:
            import prometheus_client as prom  # noqa: F401
        except ImportError:
            raise ImportError(
                "prometheus-client is required: pip install pretty-good-trader[prometheus]"
            )

        self._port = port
        self._setup_metrics()

    def _setup_metrics(self) -> None:
        import prometheus_client as prom

        self._monitor_signal_rate = prom.Counter(
            "pgt_monitor_signal_rate",
            "Incremented on each monitor cycle signal",
        )
        self._cycle_duration_seconds = prom.Histogram(
            "pgt_cycle_duration_seconds",
            "Duration of each pipeline cycle",
            ["cycle_type"],
        )
        self._api_cost_total = prom.Counter(
            "pgt_api_cost_total",
            "Total API cost in dollars",
            ["provider"],
        )
        self._trade_count_total = prom.Counter(
            "pgt_trade_count_total",
            "Total trades placed",
            ["action", "ticker"],
        )
        self._portfolio_value = prom.Gauge(
            "pgt_portfolio_value",
            "Current portfolio equity",
        )
        self._risk_blocked_total = prom.Counter(
            "pgt_risk_blocked_total",
            "Orders blocked by risk engine",
        )
        self._llm_tokens_total = prom.Counter(
            "pgt_llm_tokens_total",
            "LLM tokens used (type: prompt|completion)",
            ["type"],
        )
        self._errors_total = prom.Counter(
            "pgt_errors_total",
            "Total errors by type",
            ["error_type"],
        )

    async def on_startup(self, ctx: RunContext) -> None:
        import prometheus_client as prom

        prom.start_http_server(self._port)
        _log.info("PrometheusPlugin: /metrics available at :%d", self._port)

    async def on_signal_detected(self, signal: MonitorSignal) -> None:
        self._monitor_signal_rate.inc()

    async def on_order_placed(
        self, order: OrderResult, portfolio: PortfolioSnapshot
    ) -> None:
        self._trade_count_total.labels(action=order.side.value, ticker=order.ticker).inc()
        self._portfolio_value.set(portfolio.equity)

    async def on_order_blocked(self, reason: str, intent: OrderIntent) -> None:
        self._risk_blocked_total.inc()

    async def on_error(self, error: Exception, context: str) -> None:
        self._errors_total.labels(error_type=type(error).__name__).inc()

    async def on_eod_summary(self, summary: EODSummary) -> None:
        self._portfolio_value.set(summary.portfolio.equity)
