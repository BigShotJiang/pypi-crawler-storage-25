"""pgt CLI — Typer + Rich. Entry point: pgt"""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pgt.core.config import PGTConfig
import json
import os
import re
import time
from datetime import UTC
from pathlib import Path

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

console = Console()
app = typer.Typer(
    name="pgt",
    help="PrettyGoodTrader — LLM-native algorithmic trading framework",
    no_args_is_help=True,
)
backtest_app = typer.Typer(help="Backtesting commands", no_args_is_help=True)
docker_app = typer.Typer(help="Docker infrastructure commands", no_args_is_help=True)
app.add_typer(backtest_app, name="backtest")
app.add_typer(docker_app, name="docker")

_PID_FILE = Path("data/pgt.pid")


# ─── PID lock ───────────────────────────────────────────────────────────────

def _acquire_pid_lock() -> None:
    """Write PID file; abort if another live pgt process is running."""
    try:
        import psutil
    except ImportError:
        # psutil not installed — skip lock rather than blocking
        return

    _PID_FILE.parent.mkdir(parents=True, exist_ok=True)

    if _PID_FILE.exists():
        try:
            existing_pid = int(_PID_FILE.read_text().strip())
        except (ValueError, OSError):
            existing_pid = None

        if existing_pid and psutil.pid_exists(existing_pid):
            try:
                proc = psutil.Process(existing_pid)
                cmdline = " ".join(proc.cmdline())
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                cmdline = ""

            if "pgt" in cmdline:
                console.print(
                    f"[red bold]pgt is already running (PID {existing_pid})[/red bold]\n"
                    "Use [cyan]pgt status[/cyan] to inspect or kill the process first."
                )
                raise typer.Exit(1)

    _PID_FILE.write_text(str(os.getpid()))


def _release_pid_lock() -> None:
    try:
        if _PID_FILE.exists():
            _PID_FILE.unlink()
    except OSError:
        pass


# ─── Setup ──────────────────────────────────────────────────────────────────

@app.command()
def init(
    exchange: str = typer.Option("alpaca", help="Exchange: alpaca, kraken, binance"),
    paper: bool = typer.Option(True, help="Start in paper trading mode"),
) -> None:
    """Interactive setup wizard — writes .env with inline comments."""
    import shutil

    env_example = Path(".env.example")
    env_file = Path(".env")

    if env_file.exists():
        overwrite = typer.confirm(".env already exists. Overwrite?", default=False)
        if not overwrite:
            console.print("[yellow]Skipped.[/yellow]")
            return

    if not env_example.exists():
        pkg_root = Path(__file__).parent.parent.parent
        env_example = pkg_root / ".env.example"

    if env_example.exists():
        shutil.copy(env_example, env_file)
        console.print("[green]✓[/green] Created .env from .env.example")
    else:
        env_file.write_text(f"PAPER={str(paper).lower()}\n")
        console.print("[green]✓[/green] Created minimal .env")

    console.print(
        Panel(
            "[bold]Next steps:[/bold]\n"
            "1. Edit [cyan].env[/cyan] and add your API keys\n"
            "2. Run [cyan]pgt doctor[/cyan] to verify setup\n"
            "3. Run [cyan]pgt run --dry-run[/cyan] to test",
            title="pgt init complete",
        )
    )


@app.command()
def doctor(
    fix: bool = typer.Option(False, "--fix", help="Auto-repair stopped services"),
) -> None:
    """Health check: API keys, Docker services, connectivity."""

    from pgt.core.config import PGTConfig

    table = Table(title="PGT Health Check")
    table.add_column("Check", style="cyan")
    table.add_column("Status")
    table.add_column("Notes")

    # Config check
    config = None
    try:
        config = PGTConfig()
        table.add_row("Config", "[green]✓[/green]", "PGTConfig loaded")
    except Exception as exc:
        table.add_row("Config", "[red]✗[/red]", str(exc))

    # API key check
    try:
        from pgt.ai.client import PGTLLMClient
        client = PGTLLMClient(config)
        client.validate_keys()
        table.add_row("API Keys", "[green]✓[/green]", "Keys validated")
    except Exception as exc:
        if fix:
            console.print(
                "[yellow]API keys missing. Set them in .env:[/yellow]\n"
                "  XAI_API_KEY=your_key_here\n"
                "  ANTHROPIC_API_KEY=your_key_here  # optional"
            )
        table.add_row("API Keys", "[red]✗[/red]", str(exc))

    # Data directory
    data_dir = Path("data")
    if data_dir.exists():
        table.add_row("Data dir", "[green]✓[/green]", str(data_dir.absolute()))
    else:
        if fix:
            data_dir.mkdir(parents=True, exist_ok=True)
            table.add_row("Data dir", "[green]✓ fixed[/green]", "Created data/")
        else:
            table.add_row("Data dir", "[yellow]![/yellow]", "Will be created on first run")

    # Docker services check
    _check_docker_services(table, fix=fix)

    console.print(table)


def _check_docker_services(table: Table, fix: bool = False) -> None:
    import subprocess

    services = ["pgt", "searxng", "searxng-redis"]
    compose_file = (
        "docker-compose.dev.yml"
        if not Path("docker-compose.yml").exists()
        else "docker-compose.yml"
    )

    if not Path(compose_file).exists():
        table.add_row("Docker", "[dim]–[/dim]", "No compose file found")
        return

    for service in services:
        try:
            result = subprocess.run(
                ["docker", "compose", "-f", compose_file, "ps", "--status", "running", service],
                capture_output=True, text=True, timeout=5,
            )
            running = service in result.stdout
            if running:
                table.add_row(f"Docker/{service}", "[green]✓[/green]", "running")
            else:
                if fix:
                    subprocess.run(
                        ["docker", "compose", "-f", compose_file, "up", "-d", service],
                        capture_output=True, timeout=30,
                    )
                    table.add_row(f"Docker/{service}", "[green]✓ fixed[/green]", "restarted")
                else:
                    table.add_row(
                        f"Docker/{service}", "[yellow]![/yellow]", "stopped — run pgt doctor --fix"
                    )
        except (subprocess.TimeoutExpired, FileNotFoundError):
            table.add_row(f"Docker/{service}", "[dim]–[/dim]", "docker not available")
            break


# ─── Trading ────────────────────────────────────────────────────────────────

@app.command()
def run(
    paper: bool = typer.Option(True, "--paper/--no-paper", help="Paper trading mode"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Run one cycle and exit"),
    confirm_live: bool = typer.Option(False, "--confirm-live", help="Required for live trading"),
) -> None:
    """Start the trading engine."""
    from pgt.core.config import PGTConfig

    config = PGTConfig()

    if not config.paper and not confirm_live:
        console.print(
            "[red bold]⚠️  LIVE TRADING MODE[/red bold]\n"
            "Real money is at risk. Add [cyan]--confirm-live[/cyan] to proceed."
        )
        raise typer.Exit(1)

    if not config.paper:
        console.print(
            Panel(
                "[red bold]🔴 LIVE TRADING MODE[/red bold]\n"
                "[bold]Real money is at risk.[/bold]\n"
                "Press Ctrl+C within 10 seconds to abort.",
                border_style="red",
            )
        )
        for i in range(10, 0, -1):
            console.print(f"  Starting in {i}s... (Ctrl+C to abort)", end="\r")
            time.sleep(1)
        console.print()
    else:
        console.print(
            Panel(
                "[green bold]🟢 PAPER MODE ACTIVE[/green bold]\n"
                "No real money at risk. Safe to run.",
                border_style="green",
            )
        )

    if dry_run:
        console.print("[cyan]Dry run: one cycle walkthrough[/cyan]")
        asyncio.run(_dry_run(config))
        return

    _acquire_pid_lock()
    try:
        asyncio.run(_run_live(config))
    finally:
        _release_pid_lock()


async def _dry_run(config: PGTConfig) -> None:
    """Rich 3-panel dry-run: Config + mock Monitor response + Ready summary."""

    # Panel 1 — Config
    config_lines = (
        f"[bold]Monitor model:[/bold]  {config.monitor_model}\n"
        f"[bold]Research model:[/bold] {config.research_model}\n"
        f"[bold]Trader model:[/bold]   {config.trader_model}\n"
        f"[bold]Paper mode:[/bold]     {config.paper}\n"
        f"[bold]Monitor interval:[/bold] {config.monitor_interval}s\n"
        f"[bold]Max position:[/bold]   {config.max_position_pct*100:.0f}%\n"
        f"[bold]Max daily loss:[/bold] {config.max_daily_loss_pct*100:.0f}%"
    )
    p1 = Panel(config_lines, title="[bold cyan]Config[/bold cyan]", border_style="cyan")

    # Panel 2 — Mock Monitor response (SimClock + mock LLM)
    mock_monitor = (
        "[bold]Simulated Monitor cycle[/bold]\n\n"
        "Clock:    SimClock (2026-04-11T09:30:00Z)\n"
        "Adapter:  PaperEngine(mock)\n"
        "Model:    [dim]mock-llm[/dim]\n\n"
        "Signal:   [yellow]HOLD[/yellow]\n"
        "Urgency:  low\n"
        "Tickers:  SPY, QQQ, AAPL\n"
        "Reasoning: Market conditions nominal.\n"
        "           No high-urgency signal detected."
    )
    p2 = Panel(
        mock_monitor,
        title="[bold yellow]Mock Monitor Response[/bold yellow]",
        border_style="yellow",
    )

    # Panel 3 — Ready summary
    ready_lines = (
        "[green bold]✓ Configuration valid[/green bold]\n"
        "[green bold]✓ PaperEngine initialized[/green bold]\n"
        "[green bold]✓ SimClock ready[/green bold]\n"
        "[green bold]✓ Logger initialized[/green bold]\n\n"
        "[bold]Ready to trade.[/bold]\n"
        "Run [cyan]pgt run --paper[/cyan] to start.\n"
        "Run [cyan]pgt run --no-paper --confirm-live[/cyan] for live."
    )
    p3 = Panel(ready_lines, title="[bold green]Ready to Trade[/bold green]", border_style="green")

    console.print(p1)
    console.print(p2)
    console.print(p3)


async def _run_live(config: PGTConfig) -> None:

    console.print(
        "[yellow]Use the Python API for live trading:[/yellow]\n"
        "  from pgt import TradingEngine, PGTConfig\n"
        "  from pgt.adapters import AlpacaAdapter, PaperEngine\n"
        "  engine = TradingEngine(adapter=PaperEngine(AlpacaAdapter(...)), config=PGTConfig())\n"
        "  asyncio.run(engine.run())"
    )


# ─── Status ─────────────────────────────────────────────────────────────────

@app.command()
def status(
    watch: bool = typer.Option(False, "--watch", help="Auto-refreshing dashboard (5s)"),
) -> None:
    """Portfolio status and P&L."""
    from pgt.logger import Logger

    if watch:
        _status_watch()
        return

    logger = Logger()
    cycles = logger.get_recent_cycles(limit=1)

    if not cycles:
        console.print("[dim]No trading cycles yet. Run [cyan]pgt run[/cyan] first.[/dim]")
        return

    latest = cycles[0]
    console.print(Panel(
        f"Last cycle: {latest.get('timestamp', 'N/A')}\n"
        f"Model: {latest.get('model', 'N/A')}\n"
        f"Cost: ${latest.get('api_cost', 0):.4f}",
        title="PGT Status",
    ))


def _status_watch() -> None:
    """Rich Live auto-refreshing status dashboard, 5s interval."""
    from datetime import datetime

    from rich.live import Live

    from pgt.logger import Logger

    logger = Logger()

    def _build_table() -> Table:
        now = datetime.now(tz=UTC)
        rows = logger.get_recent_cycles(limit=50)

        # Portfolio summary
        portfolio_table = Table(title="Portfolio", show_header=True, header_style="bold cyan")
        portfolio_table.add_column("Metric")
        portfolio_table.add_column("Value")

        if rows:
            latest = rows[0]
            portfolio_table.add_row("Last cycle", str(latest.get("timestamp", ""))[:19])
            portfolio_table.add_row("Signal", str(latest.get("signal", "N/A") or "N/A"))
            portfolio_table.add_row("Model", str(latest.get("model", "N/A"))[:30])

            today = now.strftime("%Y-%m-%d")
            today_cost = sum(
                r.get("api_cost") or 0
                for r in rows
                if str(r.get("timestamp", "")).startswith(today)
            )
            portfolio_table.add_row("Cost today", f"${today_cost:.4f}")
            portfolio_table.add_row("Cycles today", str(sum(
                1 for r in rows if str(r.get("timestamp", "")).startswith(today)
            )))
        else:
            portfolio_table.add_row("Status", "[dim]No cycles yet[/dim]")

        portfolio_table.add_row("Refreshed", now.strftime("%H:%M:%S UTC"))
        return portfolio_table

    console.print("[dim]Watching... Ctrl+C to exit[/dim]")
    try:
        with Live(console=console, refresh_per_second=0.2) as live:
            while True:
                live.update(_build_table())
                time.sleep(5)
    except KeyboardInterrupt:
        pass


@app.command()
def cycles(
    limit: int = typer.Option(20, help="Number of cycles to show"),
    trace: str | None = typer.Option(None, "--trace", help="Show full trace by UUID"),
    cycle_id: int | None = typer.Option(None, "--cycle-id", help="Show specific cycle"),
    json_output: bool = typer.Option(False, "--json", help="Output raw JSON"),
) -> None:
    """Recent LLM cycles (cost, latency, signal, model)."""
    from pgt.logger import Logger

    logger = Logger()

    if cycle_id is not None:
        row = logger.get_cycle(cycle_id)
        if not row:
            console.print(f"[red]Cycle {cycle_id} not found[/red]")
            return
        if json_output:
            console.print(json.dumps(row, indent=2))
        else:
            console.print(Panel(json.dumps(row, indent=2), title=f"Cycle #{cycle_id}"))
        return

    rows = logger.get_recent_cycles(limit=limit)
    if not rows:
        console.print("[dim]No cycles found.[/dim]")
        return

    if json_output:
        console.print(json.dumps(rows, indent=2))
        return

    table = Table(title=f"Recent {len(rows)} cycles")
    table.add_column("ID")
    table.add_column("Timestamp")
    table.add_column("Type")
    table.add_column("Model")
    table.add_column("Cost $")
    table.add_column("Latency ms")
    table.add_column("Error")

    for row in rows:
        table.add_row(
            str(row.get("id", "")),
            str(row.get("timestamp", ""))[:19],
            str(row.get("cycle_type", "")),
            str(row.get("model", ""))[:30],
            f"{row.get('api_cost', 0):.4f}",
            str(row.get("latency_ms", "")),
            "✗" if row.get("error") else "",
        )

    console.print(table)


@app.command()
def cost(
    forecast: bool = typer.Option(False, "--forecast", help="30-day cost projection"),
) -> None:
    """Projected monthly API cost from recent cycles."""
    from datetime import datetime, timedelta

    from pgt.logger import Logger

    logger = Logger()
    rows = logger.get_recent_cycles(limit=1000)

    if not rows:
        console.print("[dim]No cost data yet.[/dim]")
        return

    total_cost = sum(r.get("api_cost") or 0 for r in rows)
    console.print(f"[cyan]Total cost ({len(rows)} cycles): ${total_cost:.4f}[/cyan]")

    if forecast:
        now = datetime.now(tz=UTC)
        week_ago = (now - timedelta(days=7)).isoformat()
        week_rows = [r for r in rows if r.get("timestamp", "") >= week_ago]
        week_cost = sum(r.get("api_cost") or 0 for r in week_rows)
        monthly = week_cost / 7 * 30
        console.print(
            f"[bold]30-day forecast: ${monthly:.2f}[/bold]"
            f" (based on last {len(week_rows)} cycles over 7 days)"
        )

        # Top 3 most expensive cycles
        top3 = sorted(rows, key=lambda r: r.get("api_cost") or 0, reverse=True)[:3]
        if top3:
            table = Table(title="Top 3 most expensive cycles")
            table.add_column("ID")
            table.add_column("Timestamp")
            table.add_column("Type")
            table.add_column("Model")
            table.add_column("Cost $")
            for r in top3:
                table.add_row(
                    str(r.get("id", "")),
                    str(r.get("timestamp", ""))[:19],
                    str(r.get("cycle_type", "")),
                    str(r.get("model", ""))[:30],
                    f"${r.get('api_cost', 0):.4f}",
                )
            console.print(table)


def _highlight_term(text: str, term: str) -> str:
    """Wrap every case-insensitive occurrence of *term* in Rich yellow-bold markup."""
    if not term:
        return text
    pattern = re.compile(re.escape(term), re.IGNORECASE)
    return pattern.sub(lambda m: f"[yellow bold]{m.group(0)}[/yellow bold]", text)


@app.command()
def reflections(
    limit: int = typer.Option(20, help="Number of reflections to show"),
    search: str | None = typer.Option(None, "--search", help="BM25 search query"),
) -> None:
    """BM25 trade reflection memory."""
    from pgt.memory.reflection import ReflectionMemory

    memory = ReflectionMemory()

    if search:
        results = memory.search(search, top_k=limit)
        console.print(f"[cyan]Search results for '{search}':[/cyan]")
        for rank, r in enumerate(results, start=1):
            outcome_hl = _highlight_term(r.outcome, search)
            lesson_hl = _highlight_term(r.lesson, search)
            reasoning_hl = _highlight_term(
                getattr(r, "reasoning", ""), search
            ) if getattr(r, "reasoning", None) else None

            body = (
                f"Ticker: {r.ticker}\n"
                f"Action: {r.action}\n"
                f"Outcome: {outcome_hl}\n"
                f"Lesson: {lesson_hl}\n"
                f"Timestamp: {r.timestamp}"
            )
            if reasoning_hl:
                body += f"\nReasoning: {reasoning_hl}"

            console.print(
                Panel(
                    body,
                    title=f"{r.ticker} reflection #{rank}",
                )
            )
        return

    console.print(f"[cyan]Reflection memory ({len(memory)} entries)[/cyan]")
    for r in memory._corpus[-limit:]:
        console.print(f"  [{r.timestamp[:10]}] {r.ticker}: {r.lesson[:80]}")


# ─── Replay ─────────────────────────────────────────────────────────────────

@app.command()
def replay(
    cycle_id: int = typer.Argument(..., help="Cycle ID to replay"),
    annotate: bool = typer.Option(False, "--annotate", help="Add annotation to this cycle"),
    data_dir: str = typer.Option("data", "--data-dir"),
) -> None:
    """Re-run past cycle and display full reasoning."""
    from pgt.logger import Logger
    from pgt.memory.annotations import AnnotationMemory

    logger = Logger(data_dir=data_dir)
    annotation_memory = AnnotationMemory(
        storage_path=f"{data_dir}/annotations.jsonl"
    )

    cycle = logger.get_cycle(cycle_id)
    if not cycle:
        console.print(f"[red]Cycle {cycle_id} not found[/red]")
        raise typer.Exit(1)

    if annotate:
        text = typer.prompt("Annotation text")
        annotation_memory.add(cycle_id, text)
        console.print(f"[green]Annotation added to cycle {cycle_id}.[/green]")
        return

    existing_annotations = annotation_memory.get(cycle_id)
    annotations_text = (
        "\n".join(f"  • {a}" for a in existing_annotations)
        if existing_annotations
        else "  (none)"
    )

    content = (
        f"[bold]Type:[/bold]       {cycle.get('cycle_type', 'N/A')}\n"
        f"[bold]Model:[/bold]      {cycle.get('model', 'N/A')}\n"
        f"[bold]Timestamp:[/bold]  {cycle.get('timestamp', 'N/A')}\n"
        f"[bold]Signal:[/bold]     {cycle.get('signal', 'N/A')}\n"
        f"[bold]API Cost:[/bold]   ${cycle.get('api_cost') or 0:.4f}\n"
        f"[bold]Latency:[/bold]    {cycle.get('latency_ms', 'N/A')} ms\n"
        f"\n[bold]Reasoning:[/bold]\n{cycle.get('reasoning', '(none)')}\n"
        f"\n[bold]Response:[/bold]\n{cycle.get('response_text', '(none)')}\n"
        f"\n[bold]Annotations:[/bold]\n{annotations_text}"
    )

    console.print(Panel(content, title=f"[bold cyan]Cycle #{cycle_id} Replay[/bold cyan]"))


# ─── Docker ─────────────────────────────────────────────────────────────────

@docker_app.command("up")
def docker_up(
    minimal: bool = typer.Option(False, "--minimal", help="Minimal dev stack (no Firecrawl)"),
) -> None:
    """Start Docker services."""
    import subprocess

    compose_file = "docker-compose.dev.yml" if minimal else "docker-compose.yml"
    if not Path(compose_file).exists():
        console.print(f"[red]{compose_file} not found[/red]")
        raise typer.Exit(1)
    subprocess.run(["docker", "compose", "-f", compose_file, "up", "-d"], check=True)
    console.print(f"[green]✓[/green] Services started from {compose_file}")


@docker_app.command("down")
def docker_down() -> None:
    """Stop Docker services."""
    import subprocess

    subprocess.run(["docker", "compose", "down"], check=True)
    console.print("[green]✓[/green] Services stopped")


# ─── Backtest ────────────────────────────────────────────────────────────────

@backtest_app.command("run")
def backtest_run(
    start: str = typer.Option(..., "--start", help="Start date: 2024-01-01"),
    end: str = typer.Option(..., "--end", help="End date: 2025-12-31"),
    exchange: str = typer.Option("alpaca", "--exchange", help="Exchange: alpaca, kraken"),
    plot: bool = typer.Option(False, "--plot", help="ASCII equity curve (demo mode)"),
    demo: bool = typer.Option(False, "--demo", help="Show synthetic equity curve demo"),
    resume: str | None = typer.Option(None, "--run-id", help="Resume from checkpoint"),
    compare: bool = typer.Option(False, "--compare", help="Compare multiple LLM models"),
    models: str | None = typer.Option(
        None, "--models",
        help="Comma-separated models: xai/grok-beta,anthropic/claude-haiku-4-5-20251001",
    ),
) -> None:
    """Run a backtest."""
    console.print(f"[cyan]Backtest: {start} → {end} on {exchange}[/cyan]")
    console.print("[yellow]Configure BacktestEngine in Python for full control:[/yellow]")
    console.print(
        "  from pgt import BacktestEngine, PGTConfig\n"
        "  from pgt.adapters import PaperEngine\n"
        "  from pgt.data import DuckDBCatalog\n"
        "  results = asyncio.run(BacktestEngine(\n"
        f"      adapter=PaperEngine(...), config=PGTConfig(),\n"
        f"      start='{start}', end='{end}',\n"
        "  ).run())\n"
        "  from pgt.core.engines import plot_equity_curve\n"
        "  from pgt.models import BacktestReport\n"
        "  report = BacktestReport.from_backtest_result(results)\n"
        "  plot_equity_curve(report)"
    )

    if plot or demo:
        import random
        from datetime import datetime, timedelta

        from pgt.core.engines import plot_equity_curve
        from pgt.models import BacktestReport

        console.print(
            "\n[bold green]Demo equity curve (synthetic random walk — 100 bars)[/bold green]"
        )

        # Generate synthetic equity curve: random walk starting at 10_000
        random.seed(42)
        base = datetime(2024, 1, 2, 10, 0, tzinfo=None)
        equity = 10_000.0
        curve: list[tuple[datetime, float]] = []
        for i in range(100):
            ts = base + timedelta(days=i)
            delta = random.gauss(0, 150)
            equity = max(1_000.0, equity + delta)
            curve.append((ts, equity))

        final = curve[-1][1]
        initial = curve[0][1]
        returns = [
            (curve[i][1] - curve[i - 1][1]) / curve[i - 1][1]
            for i in range(1, len(curve))
            if curve[i - 1][1] > 0
        ]
        import statistics
        mean_r = statistics.mean(returns) if returns else 0
        std_r = statistics.stdev(returns) if len(returns) > 1 else 1
        sharpe = (mean_r / std_r * (252 ** 0.5)) if std_r > 0 else 0

        peak = initial
        max_dd = 0.0
        for _, eq in curve:
            if eq > peak:
                peak = eq
            dd = (peak - eq) / peak if peak > 0 else 0
            max_dd = max(max_dd, dd)

        report = BacktestReport(
            total_return_pct=round((final - initial) / initial * 100, 2),
            sharpe=round(sharpe, 3),
            max_drawdown_pct=round(max_dd * 100, 2),
            win_rate=round(sum(1 for r in returns if r > 0) / len(returns), 3) if returns else 0.0,
            total_trades=23,
            total_llm_cost=0.0142,
            equity_curve=curve,
        )

        plot_equity_curve(report)
        console.print(
            "[dim]Note: This is a synthetic demo. "
            "To use with real data, use BacktestEngine in Python"
            " and call plot_equity_curve(report).[/dim]"
        )

    if compare:
        import random
        import statistics
        from datetime import timedelta

        from pgt.core.engines import compare_models_table
        from pgt.models import BacktestReport

        _DEFAULT_MODELS = ["xai/grok-beta", "anthropic/claude-haiku-4-5-20251001"]
        model_list = [m.strip() for m in models.split(",")] if models else _DEFAULT_MODELS

        console.print(
            f"\n[bold cyan]Multi-Model Comparison (Demo Mode)[/bold cyan]\n"
            f"Models: {', '.join(model_list)}\n"
            f"Range:  {start} → {end}"
        )

        # Generate synthetic BacktestReport for each model (slightly different values)
        compare_results: list[tuple[str, BacktestReport]] = []
        random.seed(7)
        for i, model_name in enumerate(model_list):
            seed_offset = i * 13
            total_return = round(random.gauss(5.0 + seed_offset * 0.5, 3.0), 2)
            sharpe = round(random.gauss(0.8 + i * 0.15, 0.2), 3)
            max_dd = round(abs(random.gauss(8.0 - i * 0.5, 2.0)), 2)
            win_rate = round(min(0.99, max(0.01, random.gauss(0.52 + i * 0.02, 0.05))), 3)
            total_trades = random.randint(15, 40)
            llm_cost = round(abs(random.gauss(0.02 + i * 0.005, 0.005)), 4)

            report = BacktestReport(
                total_return_pct=total_return,
                sharpe=sharpe,
                max_drawdown_pct=max_dd,
                win_rate=win_rate,
                total_trades=total_trades,
                total_llm_cost=llm_cost,
            )
            compare_results.append((model_name, report))

        compare_models_table(compare_results)
        console.print(
            "[dim]Demo mode: use MultiModelBacktestEngine in Python for real comparison[/dim]"
        )


if __name__ == "__main__":
    app()
