"""RiskEngine — runs synchronous check pipeline before each order."""

from __future__ import annotations

from typing import TYPE_CHECKING

from pgt.models import OrderIntent, PortfolioSnapshot, RiskResult
from pgt.risk.checks import (
    MaxDailyDrawdownCheck,
    MaxOpenPositionsCheck,
    MaxPositionSizeCheck,
    MinCashReserveCheck,
    NegativeQtyCheck,
    TickerAllowlistCheck,
)

if TYPE_CHECKING:
    from pgt.risk.checks import RiskCheck


class RiskEngine:
    """
    Synchronous risk check pipeline. All checks run in < 1ms.
    First failing check stops the chain and returns BLOCKED result.
    """

    def __init__(
        self,
        checks: list[RiskCheck] | None = None,
        initial_equity: float | None = None,
    ) -> None:
        if checks is not None:
            self._checks = checks
        else:
            # Default check stack from §5.1
            self._checks = [
                NegativeQtyCheck(),
                MaxPositionSizeCheck(pct_of_portfolio=0.05),
                MaxDailyDrawdownCheck(pct=0.05, initial_equity=initial_equity),
                MaxOpenPositionsCheck(n=20),
                MinCashReserveCheck(pct=0.10),
                TickerAllowlistCheck(),
            ]

    def check(
        self,
        intent: OrderIntent,
        portfolio: PortfolioSnapshot,
    ) -> RiskResult:
        """
        Run all checks in order. Returns first blocked result.
        Returns allowed=True if all checks pass.
        """
        for check in self._checks:
            result = check.check(intent, portfolio)
            if not result.allowed:
                return result
        return RiskResult(allowed=True)

    def set_initial_equity(self, equity: float) -> None:
        for check in self._checks:
            if isinstance(check, MaxDailyDrawdownCheck):
                check.set_initial_equity(equity)
