"""All 7 risk checks — synchronous, fast arithmetic (< 1ms each)."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

from pgt.models import OrderIntent, OrderSide, PortfolioSnapshot, RiskResult

if TYPE_CHECKING:
    from pgt.memory.session import SessionMemory


class RiskCheck(ABC):
    @abstractmethod
    def check(
        self,
        intent: OrderIntent,
        portfolio: PortfolioSnapshot,
    ) -> RiskResult: ...

    @property
    def name(self) -> str:
        return self.__class__.__name__


class MaxPositionSizeCheck(RiskCheck):
    """Block orders that would make any single position > pct_of_portfolio of equity."""

    def __init__(self, pct_of_portfolio: float = 0.05) -> None:
        self._pct = pct_of_portfolio

    def check(self, intent: OrderIntent, portfolio: PortfolioSnapshot) -> RiskResult:
        if intent.side != OrderSide.BUY:
            return RiskResult(allowed=True)

        # Estimate current position value
        equity = portfolio.equity
        if equity <= 0:
            return RiskResult(allowed=True)

        pos = portfolio.positions.get(intent.ticker)
        current_value = pos.market_value if pos else 0.0

        # We don't know fill price here; use a conservative heuristic
        # Caller (ToolDispatcher) has current prices and can pass them via portfolio
        if equity > 0 and current_value / equity >= self._pct:
            return RiskResult(
                allowed=False,
                reason=(
                    f"{intent.ticker} already at {current_value/equity:.1%} of portfolio "
                    f"(max {self._pct:.0%})"
                ),
                check_name=self.name,
            )
        return RiskResult(allowed=True)


class MaxDailyDrawdownCheck(RiskCheck):
    """Kill switch: block all buys when daily drawdown >= pct."""

    def __init__(self, pct: float = 0.05, initial_equity: float | None = None) -> None:
        self._pct = pct
        self._initial_equity = initial_equity

    def set_initial_equity(self, equity: float) -> None:
        self._initial_equity = equity

    def check(self, intent: OrderIntent, portfolio: PortfolioSnapshot) -> RiskResult:
        if intent.side != OrderSide.BUY:
            return RiskResult(allowed=True)
        if self._initial_equity is None or self._initial_equity <= 0:
            return RiskResult(allowed=True)
        drawdown = (self._initial_equity - portfolio.equity) / self._initial_equity
        if drawdown >= self._pct:
            return RiskResult(
                allowed=False,
                reason=(
                    f"Daily drawdown {drawdown:.1%} >= limit {self._pct:.0%} — "
                    "trading suspended for today"
                ),
                check_name=self.name,
            )
        return RiskResult(allowed=True)


class MaxOpenPositionsCheck(RiskCheck):
    """Block new buys when open positions >= n."""

    def __init__(self, n: int = 20) -> None:
        self._n = n

    def check(self, intent: OrderIntent, portfolio: PortfolioSnapshot) -> RiskResult:
        if intent.side != OrderSide.BUY:
            return RiskResult(allowed=True)
        if portfolio.position_count >= self._n:
            return RiskResult(
                allowed=False,
                reason=f"Max open positions reached ({self._n})",
                check_name=self.name,
            )
        return RiskResult(allowed=True)


class MinCashReserveCheck(RiskCheck):
    """Keep at least pct of equity in cash."""

    def __init__(self, pct: float = 0.10) -> None:
        self._pct = pct

    def check(self, intent: OrderIntent, portfolio: PortfolioSnapshot) -> RiskResult:
        if intent.side != OrderSide.BUY:
            return RiskResult(allowed=True)
        equity = portfolio.equity
        if equity <= 0:
            return RiskResult(allowed=True)
        cash_ratio = portfolio.cash / equity
        if cash_ratio < self._pct:
            return RiskResult(
                allowed=False,
                reason=(
                    f"Cash {cash_ratio:.1%} below minimum {self._pct:.0%} reserve"
                ),
                check_name=self.name,
            )
        return RiskResult(allowed=True)


class DuplicateOrderCheck(RiskCheck):
    """
    Block duplicate orders within window_seconds.
    Key: (ticker, side) — not ticker alone (allows "buy more NVDA" after partial fill).
    State lives in SessionMemory.recent_orders (survives restarts via TTL-filtered load).
    """

    def __init__(self, session: SessionMemory, window_seconds: int = 60) -> None:
        self._session = session
        self._window = window_seconds

    def check(self, intent: OrderIntent, portfolio: PortfolioSnapshot) -> RiskResult:
        recent = self._session.get_recent_orders(window_seconds=self._window)
        for order in recent:
            if order.ticker == intent.ticker and order.side == intent.side:
                return RiskResult(
                    allowed=False,
                    reason=(
                        f"Duplicate {intent.side.value} order for {intent.ticker} "
                        f"within {self._window}s window"
                    ),
                    check_name=self.name,
                )
        return RiskResult(allowed=True)


class NegativeQtyCheck(RiskCheck):
    """Block zero or negative quantities (no shorts unless configured)."""

    def check(self, intent: OrderIntent, portfolio: PortfolioSnapshot) -> RiskResult:
        if intent.qty <= 0:
            return RiskResult(
                allowed=False,
                reason=f"qty must be positive, got {intent.qty}",
                check_name=self.name,
            )
        return RiskResult(allowed=True)


class TickerAllowlistCheck(RiskCheck):
    """Optional: restrict tradeable universe to a configured allowlist."""

    def __init__(self, allowlist: list[str] | None = None) -> None:
        self._allowlist = set(allowlist) if allowlist else None

    def check(self, intent: OrderIntent, portfolio: PortfolioSnapshot) -> RiskResult:
        if not self._allowlist:
            return RiskResult(allowed=True)
        if intent.ticker not in self._allowlist:
            return RiskResult(
                allowed=False,
                reason=f"{intent.ticker} not in ticker allowlist",
                check_name=self.name,
            )
        return RiskResult(allowed=True)
