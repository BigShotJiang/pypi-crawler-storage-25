"""Pydantic models shared across the framework."""

from __future__ import annotations

from datetime import UTC, datetime
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, Field, field_validator


class OrderSide(StrEnum):
    BUY = "buy"
    SELL = "sell"


class OrderType(StrEnum):
    MARKET = "market"
    LIMIT = "limit"
    STOP = "stop"
    STOP_LIMIT = "stop_limit"
    TRAILING_STOP = "trailing_stop"


class OrderStatus(StrEnum):
    PENDING = "pending"
    FILLED = "filled"
    PARTIALLY_FILLED = "partially_filled"
    CANCELLED = "cancelled"
    REJECTED = "rejected"


class UrgencyLevel(StrEnum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class MonitorSignal(BaseModel):
    """Structured output from Tier 1 Monitor LLM call."""

    signal: bool
    tickers: list[str]
    urgency: UrgencyLevel = UrgencyLevel.LOW
    reason: str = ""

    @field_validator("tickers")
    @classmethod
    def tickers_nonempty_when_signal(cls, v: list[str], info: Any) -> list[str]:
        # Validated downstream; model just parses
        return v


class Position(BaseModel):
    ticker: str
    qty: float
    avg_cost: float
    current_price: float = 0.0

    @property
    def market_value(self) -> float:
        return self.qty * self.current_price

    @property
    def unrealized_pnl(self) -> float:
        return (self.current_price - self.avg_cost) * self.qty


class PortfolioSnapshot(BaseModel):
    cash: float
    positions: dict[str, Position] = Field(default_factory=dict)
    timestamp: str = Field(
        default_factory=lambda: datetime.now(tz=UTC).isoformat()
    )

    @property
    def equity(self) -> float:
        return self.cash + sum(p.market_value for p in self.positions.values())

    @property
    def position_count(self) -> int:
        return len(self.positions)


class OrderIntent(BaseModel):
    """Validated order before risk check."""

    ticker: str
    side: OrderSide
    qty: float
    order_type: OrderType = OrderType.MARKET
    limit_price: float | None = None
    stop_price: float | None = None
    trace_id: str | None = None
    cycle_id: int = 0


class OrderResult(BaseModel):
    order_id: str
    ticker: str
    side: OrderSide
    qty: float
    fill_price: float | None = None
    status: OrderStatus = OrderStatus.PENDING
    fee: float = 0.0
    timestamp: str = Field(
        default_factory=lambda: datetime.now(tz=UTC).isoformat()
    )
    exchange: str = ""
    error: str | None = None

    @property
    def is_filled(self) -> bool:
        return self.status == OrderStatus.FILLED


class OrderFill(BaseModel):
    order_id: str
    ticker: str
    side: OrderSide
    qty: float
    fill_price: float
    fee: float
    timestamp: str = Field(
        default_factory=lambda: datetime.now(tz=UTC).isoformat()
    )


class OrderRecord(BaseModel):
    """Minimal record for DuplicateOrderCheck."""

    ticker: str
    side: OrderSide
    timestamp: float  # Unix epoch


class RiskResult(BaseModel):
    allowed: bool
    reason: str = ""
    check_name: str = ""


class ToolResult(BaseModel):
    content: str = ""
    error: str | None = None

    @property
    def is_error(self) -> bool:
        return self.error is not None


class LLMToolCall(BaseModel):
    id: str
    name: str
    args: dict[str, Any]


class LLMResponse(BaseModel):
    content: str = ""
    tool_calls: list[LLMToolCall] = Field(default_factory=list)
    model: str = ""
    input_tokens: int = 0
    output_tokens: int = 0
    cost: float = 0.0
    latency_ms: int = 0

    def as_assistant_message(self) -> dict:
        msg: dict = {"role": "assistant", "content": self.content}
        if self.tool_calls:
            msg["tool_calls"] = [
                {
                    "id": tc.id,
                    "type": "function",
                    "function": {"name": tc.name, "arguments": str(tc.args)},
                }
                for tc in self.tool_calls
            ]
        return msg


class TradeReflection(BaseModel):
    """A single lesson stored in ReflectionMemory."""

    ticker: str
    action: str
    outcome: str
    lesson: str
    timestamp: str = Field(
        default_factory=lambda: datetime.now(tz=UTC).isoformat()
    )
    tokens: list[str] = Field(default_factory=list)

    def model_post_init(self, _context: Any) -> None:
        if not self.tokens:
            text = f"{self.ticker} {self.action} {self.outcome} {self.lesson}"
            self.tokens = text.lower().split()


class EODSummary(BaseModel):
    date: str
    portfolio: PortfolioSnapshot
    trades_today: int
    pnl_today: float
    lessons: list[str] = Field(default_factory=list)
    summary_text: str = ""


class BacktestResult(BaseModel):
    run_id: str
    start: str
    end: str
    exchange: str
    initial_capital: float
    final_equity: float
    total_trades: int
    win_rate: float
    sharpe_ratio: float
    max_drawdown: float
    total_pnl: float
    equity_curve: list[dict] = Field(default_factory=list)
    model_used: str = ""
    total_llm_cost: float = 0.0


class BacktestReport(BaseModel):
    """Derived report from a BacktestResult, ready for display."""

    total_return_pct: float
    sharpe: float
    max_drawdown_pct: float
    win_rate: float
    total_trades: int
    total_llm_cost: float
    equity_curve: list[tuple[datetime, float]] = Field(default_factory=list)

    @classmethod
    def from_backtest_result(cls, result: BacktestResult) -> BacktestReport:
        """Build a BacktestReport from a BacktestResult."""
        total_return_pct = (
            (result.final_equity - result.initial_capital) / result.initial_capital * 100
            if result.initial_capital > 0
            else 0.0
        )

        # Build equity curve from equity_curve dicts (each has 'timestamp' and 'equity' keys)
        curve: list[tuple[datetime, float]] = []
        for entry in result.equity_curve:
            ts_raw = entry.get("timestamp")
            equity_val = entry.get("equity", 0.0)
            if ts_raw:
                if isinstance(ts_raw, datetime):
                    ts = ts_raw
                else:
                    try:
                        ts = datetime.fromisoformat(str(ts_raw))
                    except ValueError:
                        continue
                curve.append((ts, float(equity_val)))

        return cls(
            total_return_pct=round(total_return_pct, 2),
            sharpe=result.sharpe_ratio,
            max_drawdown_pct=round(result.max_drawdown * 100, 2),
            win_rate=result.win_rate,
            total_trades=result.total_trades,
            total_llm_cost=result.total_llm_cost,
            equity_curve=curve,
        )
