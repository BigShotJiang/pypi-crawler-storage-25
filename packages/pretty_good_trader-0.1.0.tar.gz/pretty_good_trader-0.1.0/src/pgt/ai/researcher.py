"""Tier 2 Research — deep research phase."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from pgt.ai.prompts import RESEARCH_SYSTEM_PROMPT
from pgt.ai.tools import RESEARCH_TOOLS
from pgt.models import MonitorSignal

if TYPE_CHECKING:
    from pgt.core.context import RunContext

_log = logging.getLogger(__name__)


class ResearchTier:
    """Tier 2: deep research using cheap fast model. Produces markdown brief."""

    async def run(self, ctx: RunContext, signal: MonitorSignal) -> str:
        """
        Conduct research for the given signal.
        Returns markdown research brief for Tier 3 Decision.
        """
        from pgt.ai.pipeline import AIPipeline

        # Build context from reflection memory
        reflection_context = ""
        if ctx.config.reflection_enabled and ctx.memory:
            query = " ".join(signal.tickers) + " " + signal.reason
            reflections = ctx.memory.search(query, top_k=3)
            if reflections:
                reflection_context = "\n\n## Past Lessons (BM25 Memory)\n"
                for r in reflections:
                    reflection_context += f"- {r.ticker} {r.action}: {r.lesson}\n"

        user_msg = (
            f"Research trading signal:\n"
            f"Tickers: {', '.join(signal.tickers)}\n"
            f"Urgency: {signal.urgency.value}\n"
            f"Reason: {signal.reason}"
            f"{reflection_context}"
        )

        try:
            response = await AIPipeline._run_tier(
                ctx=ctx,
                model=ctx.config.research_model,
                system_prompt=RESEARCH_SYSTEM_PROMPT,
                messages=[{"role": "user", "content": user_msg}],
                tools=RESEARCH_TOOLS,
                max_calls=ctx.config.max_research_tool_calls,
            )
            return response.content
        except Exception as exc:
            _log.error("ResearchTier failed: %s", exc)
            return f"Research failed: {exc}"
