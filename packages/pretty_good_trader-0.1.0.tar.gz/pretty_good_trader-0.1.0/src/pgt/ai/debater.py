"""Adversarial bull/bear debate — optional, gated by debate_enabled + urgency==high."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING

from pgt.ai.prompts import (
    BEAR_DEBATE_PROMPT,
    BULL_DEBATE_PROMPT,
    BULL_REBUTTAL_PROMPT,
)
from pgt.models import MonitorSignal, UrgencyLevel

if TYPE_CHECKING:
    from pgt.core.context import RunContext

_log = logging.getLogger(__name__)


@dataclass
class DebateResult:
    bull_argument: str
    bear_argument: str
    rebuttal: str
    final_stance: str  # "PROCEED" or "PASS"


class DebateTier:
    """
    3-round adversarial debate: bull → bear → bull rebuttal.
    Fires only when debate_enabled=True AND urgency=="high".
    Cost: 3× research model calls when triggered (~$0.006 additional).
    """

    async def run(
        self, ctx: RunContext, signal: MonitorSignal, research_brief: str
    ) -> DebateResult | None:
        """
        Returns DebateResult or None if gating conditions not met.
        Graceful failure: returns None on any LLM error (engine continues).
        """
        if not ctx.config.debate_enabled:
            return None

        if signal.urgency != UrgencyLevel.HIGH:
            _log.debug("DebateTier: skipped (urgency=%s, not high)", signal.urgency)
            return None

        _log.info("DebateTier: starting bull/bear debate for %s", signal.tickers)

        tickers_str = ", ".join(signal.tickers)

        # Round 1: Bull argument
        try:
            bull_response = await ctx.llm.call(
                model=ctx.config.research_model,
                system_prompt=BULL_DEBATE_PROMPT,
                messages=[{
                    "role": "user",
                    "content": f"Tickers: {tickers_str}\n\n{research_brief}"
                }],
                temperature=0.3,
            )
            bull_argument = bull_response.content
        except Exception as exc:
            _log.error("DebateTier: Bull LLM call failed: %s — debate aborted", exc)
            return None

        # Round 2: Bear argument (sees bull argument)
        try:
            bear_response = await ctx.llm.call(
                model=ctx.config.research_model,
                system_prompt=BEAR_DEBATE_PROMPT,
                messages=[{
                    "role": "user",
                    "content": (
                        f"Tickers: {tickers_str}\n\nResearch Brief:\n{research_brief}"
                        f"\n\nBull Argument:\n{bull_argument}"
                    )
                }],
                temperature=0.3,
            )
            bear_argument = bear_response.content
        except Exception as exc:
            _log.error("DebateTier: Bear LLM call failed: %s — debate aborted", exc)
            return None

        # Round 3: Bull rebuttal (concludes with PROCEED or PASS)
        try:
            rebuttal_response = await ctx.llm.call(
                model=ctx.config.research_model,
                system_prompt=BULL_REBUTTAL_PROMPT,
                messages=[{
                    "role": "user",
                    "content": (
                        f"Bull Argument:\n{bull_argument}"
                        f"\n\nBear Argument:\n{bear_argument}"
                    )
                }],
                temperature=0.3,
            )
            rebuttal = rebuttal_response.content
        except Exception as exc:
            _log.error("DebateTier: Rebuttal LLM call failed: %s — debate aborted", exc)
            return None

        # Extract final stance
        final_stance = "PROCEED" if "PROCEED" in rebuttal.upper() else "PASS"

        return DebateResult(
            bull_argument=bull_argument,
            bear_argument=bear_argument,
            rebuttal=rebuttal,
            final_stance=final_stance,
        )
