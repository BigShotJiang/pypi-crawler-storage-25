"""ToolDispatcher — per-call lifecycle, risk injection, MAX_TOOL_CALLS enforcement."""

from __future__ import annotations

import json
import logging
import re
from typing import TYPE_CHECKING

from pgt.models import OrderIntent, OrderSide, OrderType, ToolResult

if TYPE_CHECKING:
    from pgt.core.context import RunContext

_log = logging.getLogger(__name__)

_TICKER_RE = re.compile(r"^[A-Z.]{1,6}$")


class ToolLimitExceededError(Exception):
    """Raised when MAX_TOOL_CALLS is reached."""


class ToolDispatcher:
    """
    Receives LLM tool call requests, enforces limits, injects risk checks,
    routes to the correct handler (DataLayer or BrokerAdapter).

    LIFECYCLE: Create one instance per AIPipeline tier call — do NOT reuse across
    calls. The _remaining counter is intentionally not resettable; reuse depletes
    it permanently. AIPipeline._run_tier() creates a fresh ToolDispatcher each call.
    """

    def __init__(self, ctx: RunContext, max_tool_calls: int) -> None:
        self._ctx = ctx
        self._max = max_tool_calls
        self._remaining = max_tool_calls
        self._cycle_id: int | None = None  # set when first order is logged

    async def dispatch(self, tool_name: str, args: dict) -> ToolResult:
        if self._remaining <= 0:
            raise ToolLimitExceededError(f"MAX_TOOL_CALLS={self._max} reached")
        self._remaining -= 1

        # Logger suspension guard — audit trail unavailable → no trading
        if tool_name == "place_order" and self._ctx.logger.is_suspended:
            return ToolResult(
                content="BLOCKED: Trading suspended — logger failure (audit trail unavailable)"
            )

        # Backtest guard — disable live data sources (prevents future-data leakage)
        if self._ctx.is_backtest and tool_name in ("search_web", "get_fundamentals"):
            return ToolResult(content="[disabled in backtest mode — is_backtest=True]")

        match tool_name:
            case "place_order":
                return await self._place_order(args)
            case "cancel_order":
                return await self._cancel_order(args)
            case "get_portfolio":
                return await self._get_portfolio()
            case "get_prices":
                return await self._get_prices(args)
            case "get_fundamentals":
                return await self._get_fundamentals(args)
            case "get_indicators":
                return await self._get_indicators(args)
            case "search_web":
                return await self._search_web(args)
            case "get_orders":
                return await self._get_orders(args)
            case _:
                return ToolResult(error=f"Unknown tool: {tool_name}")

    # ─── Tool handlers ──────────────────────────────────────────────────

    async def _search_web(self, args: dict) -> ToolResult:
        from pgt.data.search import SearchClient

        query = args.get("query", "")
        if not query:
            return ToolResult(error="search_web requires 'query' argument")

        client = SearchClient(
            searxng_url=self._ctx.config.searxng_url,
            firecrawl_url=self._ctx.config.firecrawl_url,
            max_results=self._ctx.config.max_search_results,
            max_snippet_len=self._ctx.config.max_snippet_len,
            max_content_len=self._ctx.config.max_content_len,
            firecrawl_timeout=self._ctx.config.firecrawl_timeout,
            rate_limit_rps=self._ctx.config.search_per_domain_rate_limit_rps,
            cache_ttl=self._ctx.config.search_cache_ttl,
        )
        # SearchClient.search() already wraps in <search_result> tags (injection defense)
        result = await client.search(query)
        return ToolResult(content=result)

    async def _place_order(self, args: dict) -> ToolResult:
        from pydantic import ValidationError

        # 1. Validate ticker format
        ticker = args.get("ticker", "")
        if not _TICKER_RE.match(ticker):
            return ToolResult(
                error=f"Invalid ticker format: {ticker!r}. Expected 1-6 uppercase letters."
            )

        # 2. Validate qty
        qty = float(args.get("qty", 0))
        if qty <= 0:
            return ToolResult(error="qty must be positive")

        # 3. Parse side
        side_str = str(args.get("side", "")).lower()
        try:
            side = OrderSide(side_str)
        except ValueError:
            return ToolResult(error=f"Invalid side: {side_str!r}. Expected 'buy' or 'sell'.")

        # 4. Build OrderIntent
        try:
            intent = OrderIntent(
                ticker=ticker,
                side=side,
                qty=qty,
                order_type=OrderType(args.get("order_type", "market")),
                limit_price=args.get("limit_price"),
                trace_id=self._ctx.trace_id,
                cycle_id=self._ctx.cycle_id,
            )
        except (ValidationError, ValueError) as exc:
            return ToolResult(error=f"Invalid order parameters: {exc}")

        # 5. Tradeable check
        try:
            tradeable = await self._ctx.adapter.get_tradeable_tickers()
        except Exception as exc:
            return ToolResult(error=f"Tradeable check failed: {exc}")

        if tradeable is not None and ticker not in tradeable:
            return ToolResult(error=f"{ticker} not tradeable on this exchange")

        # 6. Risk check
        try:
            portfolio = await self._ctx.adapter.get_portfolio()
        except Exception as exc:
            return ToolResult(error=f"Portfolio fetch failed: {exc}")

        risk_result = self._ctx.risk.check(intent, portfolio)
        if not risk_result.allowed:
            # Publish risk_blocked event (critical — direct delivery)
            await self._publish_risk_blocked(risk_result.reason, intent)
            return ToolResult(content=f"BLOCKED: {risk_result.reason}")

        # 7. Place order
        try:
            order_result = await self._ctx.adapter.place_order(intent)
        except Exception as exc:
            return ToolResult(error=f"Order placement failed: {exc}")

        if order_result.error:
            return ToolResult(error=order_result.error)

        # 8. Record order in session memory (for DuplicateOrderCheck)
        self._ctx.session.record_order(ticker, side)

        # 9. Log to SQLite
        self._ctx.logger.log_cycle(
            cycle_type="decision",
            model="tool",
            trace_id=self._ctx.trace_id,
        )

        # 10. Publish OrderPlaced event (critical — direct call)
        await self._publish_order_placed(order_result, portfolio)

        return ToolResult(content=order_result.model_dump_json())

    async def _cancel_order(self, args: dict) -> ToolResult:
        order_id = args.get("order_id", "")
        if not order_id:
            return ToolResult(error="cancel_order requires 'order_id'")
        success = await self._ctx.adapter.cancel_order(order_id)
        return ToolResult(content=f"Cancelled: {success}")

    async def _get_portfolio(self) -> ToolResult:
        try:
            portfolio = await self._ctx.adapter.get_portfolio()
            return ToolResult(content=portfolio.model_dump_json(indent=2))
        except Exception as exc:
            return ToolResult(error=f"get_portfolio failed: {exc}")

    async def _get_prices(self, args: dict) -> ToolResult:
        tickers = args.get("tickers", [])
        if not tickers:
            return ToolResult(error="get_prices requires 'tickers' list")
        try:
            prices = await self._ctx.adapter.get_prices(tickers)
            return ToolResult(content=json.dumps(prices))
        except Exception as exc:
            return ToolResult(error=f"get_prices failed: {exc}")

    async def _get_fundamentals(self, args: dict) -> ToolResult:
        from pgt.data.fundamentals import get_fundamentals

        ticker = args.get("ticker", "")
        if not ticker:
            return ToolResult(error="get_fundamentals requires 'ticker'")
        data = await get_fundamentals(ticker)
        return ToolResult(content=json.dumps(data, indent=2))

    async def _get_indicators(self, args: dict) -> ToolResult:
        import asyncio

        import yfinance as yf

        from pgt.data.indicators import get_indicators

        ticker = args.get("ticker", "")
        if not ticker:
            return ToolResult(error="get_indicators requires 'ticker'")
        period = args.get("period", "5d")

        try:
            ohlcv = await asyncio.to_thread(
                lambda: yf.download(ticker, period=period, progress=False)
            )
            if ohlcv.empty:
                return ToolResult(error=f"No OHLCV data for {ticker}")
            data = await get_indicators(ohlcv, ticker)
            return ToolResult(content=json.dumps(data, indent=2))
        except Exception as exc:
            return ToolResult(error=f"get_indicators failed: {exc}")

    async def _get_orders(self, args: dict) -> ToolResult:
        status = args.get("status", "open")
        try:
            orders = await self._ctx.adapter.get_orders(status=status)
            return ToolResult(
                content=json.dumps([o.model_dump() for o in orders], indent=2)
            )
        except Exception as exc:
            return ToolResult(error=f"get_orders failed: {exc}")

    # ─── Event publishing ──────────────────────────────────────────────

    async def _publish_order_placed(self, order: object, portfolio: object) -> None:
        for plugin in self._ctx.plugins:
            try:
                from pgt.models import OrderResult, PortfolioSnapshot
                if isinstance(order, OrderResult) and isinstance(portfolio, PortfolioSnapshot):
                    await plugin.on_order_placed(order, portfolio)
            except Exception as exc:
                _log.error("Plugin.on_order_placed failed: %s", exc)

    async def _publish_risk_blocked(self, reason: str, intent: OrderIntent) -> None:
        for plugin in self._ctx.plugins:
            try:
                await plugin.on_order_blocked(reason, intent)
            except Exception as exc:
                _log.error("Plugin.on_order_blocked failed: %s", exc)
