"""LLM tool definitions (JSON schema) by pipeline tier."""

from __future__ import annotations

# ─── Tier 1: Monitor tools ───────────────────────────────────────────────────

MONITOR_TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "search_web",
            "description": "Search the web for news, market data, and context.",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Search query (max 200 chars)",
                    }
                },
                "required": ["query"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_indicators",
            "description": "Get technical indicators (RSI, MACD, Bollinger Bands, ATR) for a ticker.",  # noqa: E501
            "parameters": {
                "type": "object",
                "properties": {
                    "ticker": {
                        "type": "string",
                        "description": "Ticker symbol (e.g. NVDA)",
                    },
                    "period": {
                        "type": "string",
                        "description": "Data period: 1d, 5d, 1mo (default: 5d)",
                        "default": "5d",
                    },
                },
                "required": ["ticker"],
            },
        },
    },
]

# ─── Tier 2: Research tools ─────────────────────────────────────────────────

RESEARCH_TOOLS = [
    *MONITOR_TOOLS,
    {
        "type": "function",
        "function": {
            "name": "get_portfolio",
            "description": "Get current portfolio: cash balance, positions, unrealized P&L.",
            "parameters": {"type": "object", "properties": {}, "required": []},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_fundamentals",
            "description": "Get fundamental data (P/E, EV/EBITDA, ROE, growth) for a ticker.",
            "parameters": {
                "type": "object",
                "properties": {
                    "ticker": {
                        "type": "string",
                        "description": "Ticker symbol (e.g. NVDA)",
                    }
                },
                "required": ["ticker"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_prices",
            "description": "Get current prices for one or more tickers.",
            "parameters": {
                "type": "object",
                "properties": {
                    "tickers": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "List of ticker symbols",
                    }
                },
                "required": ["tickers"],
            },
        },
    },
]

# ─── Tier 3: Decision tools ─────────────────────────────────────────────────

DECISION_TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "get_portfolio",
            "description": "Get current portfolio: cash balance, positions, unrealized P&L.",
            "parameters": {"type": "object", "properties": {}, "required": []},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_orders",
            "description": "Get open orders.",
            "parameters": {
                "type": "object",
                "properties": {
                    "status": {
                        "type": "string",
                        "description": "Order status filter: open, all (default: open)",
                        "default": "open",
                    }
                },
                "required": [],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "place_order",
            "description": "Place a buy or sell order.",
            "parameters": {
                "type": "object",
                "properties": {
                    "ticker": {"type": "string", "description": "Ticker symbol (e.g. NVDA)"},
                    "side": {"type": "string", "enum": ["buy", "sell"]},
                    "qty": {"type": "number", "description": "Number of shares/units"},
                    "order_type": {
                        "type": "string",
                        "enum": ["market", "limit"],
                        "default": "market",
                    },
                    "limit_price": {
                        "type": "number",
                        "description": "Required for limit orders",
                    },
                },
                "required": ["ticker", "side", "qty"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "cancel_order",
            "description": "Cancel an open order by ID.",
            "parameters": {
                "type": "object",
                "properties": {
                    "order_id": {"type": "string", "description": "Order ID to cancel"}
                },
                "required": ["order_id"],
            },
        },
    },
]
