"""PGTLLMClient — pure one-shot LiteLLM transport. No dispatcher coupling."""

from __future__ import annotations

import json
import logging
import time
from typing import TYPE_CHECKING, Any

from pgt.models import LLMResponse, LLMToolCall

if TYPE_CHECKING:
    from pgt.core.config import PGTConfig

_log = logging.getLogger(__name__)

_MAX_RETRIES = 3
_BACKOFF_BASE = 2.0  # seconds


class PGTLLMError(Exception):
    """Raised by PGTLLMClient on exhausted retries."""


class PGTLLMClient:
    """
    Thin facade over LiteLLM. Provides type-safe call interface
    and normalizes responses. All 100+ LiteLLM providers supported.

    Switch provider via MODEL env vars:
      MONITOR_MODEL=xai/grok-4-1-fast         (default)
      MONITOR_MODEL=anthropic/claude-haiku-4-5 (alternative)
      MONITOR_MODEL=openai/gpt-4o-mini         (alternative)

    Agentic loop is NOT here — it lives in AIPipeline._run_tier().
    This is a pure one-shot transport.
    """

    def __init__(self, config: PGTConfig) -> None:
        self._config = config

    def validate_keys(self) -> None:
        """Check that required API keys are present. Called at engine startup."""

        needed: set[str] = set()
        for model_field in ("monitor_model", "research_model", "trader_model"):
            model = getattr(self._config, model_field, "")
            if model.startswith("xai/"):
                needed.add("xai")
            elif model.startswith("anthropic/"):
                needed.add("anthropic")
            elif model.startswith("openai/"):
                needed.add("openai")

        missing = []
        if "xai" in needed and not self._config.xai_api_key:
            missing.append("XAI_API_KEY")
        if "anthropic" in needed and not self._config.anthropic_api_key:
            missing.append("ANTHROPIC_API_KEY")
        if "openai" in needed and not self._config.openai_api_key:
            missing.append("OPENAI_API_KEY")

        if missing:
            raise PGTLLMError(
                f"Missing API keys for configured models: {', '.join(missing)}. "
                "Set them in .env or environment variables."
            )

    async def call(
        self,
        model: str,
        system_prompt: str,
        messages: list[dict],
        tools: list[dict] | None = None,
        max_tokens: int = 4096,
        temperature: float = 0.7,
    ) -> LLMResponse:
        """
        Wraps litellm.acompletion(). Normalizes to LLMResponse.
        Retries 3× with exponential backoff on timeout/429/529.
        Raises PGTLLMError on exhaustion.
        """
        import asyncio

        import litellm

        full_messages = [{"role": "system", "content": system_prompt}, *messages]

        # Set API keys in env for LiteLLM
        self._inject_keys()

        last_exc: Exception | None = None
        for attempt in range(_MAX_RETRIES):
            t0 = time.monotonic()
            try:
                kwargs: dict[str, Any] = {
                    "model": model,
                    "messages": full_messages,
                    "max_tokens": max_tokens,
                    "temperature": temperature,
                }
                if tools:
                    kwargs["tools"] = tools
                    kwargs["tool_choice"] = "auto"

                response = await litellm.acompletion(**kwargs)
                latency_ms = int((time.monotonic() - t0) * 1000)

                return self._normalize(response, latency_ms)

            except litellm.exceptions.RateLimitError as exc:
                last_exc = exc
                wait = _BACKOFF_BASE ** attempt
                _log.warning(
                    "LiteLLM rate limit (attempt %d/%d), retrying in %.1fs: %s",
                    attempt + 1, _MAX_RETRIES, wait, exc,
                )
                await asyncio.sleep(wait)

            except (litellm.exceptions.Timeout, litellm.exceptions.APIConnectionError) as exc:
                last_exc = exc
                wait = _BACKOFF_BASE ** attempt
                _log.warning(
                    "LiteLLM timeout/connection (attempt %d/%d), retrying in %.1fs: %s",
                    attempt + 1, _MAX_RETRIES, wait, exc,
                )
                await asyncio.sleep(wait)

            except Exception as exc:
                raise PGTLLMError(f"LiteLLM call failed: {exc}") from exc

        raise PGTLLMError(
            f"LiteLLM exhausted {_MAX_RETRIES} retries: {last_exc}"
        ) from last_exc

    def _inject_keys(self) -> None:
        """Inject API keys into environment for LiteLLM."""
        import os
        if self._config.xai_api_key:
            os.environ.setdefault("XAI_API_KEY", self._config.xai_api_key.get_secret_value())
        if self._config.anthropic_api_key:
            os.environ.setdefault(
                "ANTHROPIC_API_KEY", self._config.anthropic_api_key.get_secret_value()
            )
        if self._config.openai_api_key:
            os.environ.setdefault("OPENAI_API_KEY", self._config.openai_api_key.get_secret_value())

    def _normalize(self, response: Any, latency_ms: int) -> LLMResponse:
        choice = response.choices[0]
        message = choice.message

        content = message.content or ""
        tool_calls: list[LLMToolCall] = []

        if hasattr(message, "tool_calls") and message.tool_calls:
            for tc in message.tool_calls:
                try:
                    args = json.loads(tc.function.arguments)
                except (json.JSONDecodeError, TypeError):
                    args = {}
                tool_calls.append(
                    LLMToolCall(id=tc.id, name=tc.function.name, args=args)
                )

        usage = response.usage or {}
        cost = 0.0
        try:
            import litellm
            cost = litellm.completion_cost(completion_response=response) or 0.0
        except Exception:
            pass

        return LLMResponse(
            content=content,
            tool_calls=tool_calls,
            model=response.model or "",
            input_tokens=getattr(usage, "prompt_tokens", 0) or 0,
            output_tokens=getattr(usage, "completion_tokens", 0) or 0,
            cost=cost,
            latency_ms=latency_ms,
        )
