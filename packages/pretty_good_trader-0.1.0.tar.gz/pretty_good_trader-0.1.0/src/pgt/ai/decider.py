"""Tier 3 Decision — expensive reasoning model makes final trade decision."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from pgt.ai.prompts import TRADER_SYSTEM_PROMPT
from pgt.ai.tools import DECISION_TOOLS
from pgt.models import LLMResponse, MonitorSignal

if TYPE_CHECKING:
    from pgt.ai.debater import DebateResult
    from pgt.core.context import RunContext

_log = logging.getLogger(__name__)


class DeciderTier:
    """Tier 3: expensive reasoning model. Receives compact brief, makes final decision."""

    async def run(
        self,
        ctx: RunContext,
        signal: MonitorSignal,
        research_brief: str,
        debate_result: DebateResult | None = None,
    ) -> LLMResponse:
        """
        Run decision cycle. Receives research brief (and optional debate context).
        Returns full LLMResponse (content = reasoning summary).
        """
        from pgt.ai.pipeline import AIPipeline

        # Build context for decision
        context_parts = [
            (
                f"## Signal\nTickers: {', '.join(signal.tickers)}"
                f"\nUrgency: {signal.urgency.value}\nReason: {signal.reason}"
            ),
            f"## Research Brief\n{research_brief}",
        ]

        if debate_result:
            context_parts.append(
                f"## Adversarial Analysis\n"
                f"**Bull Case:**\n{debate_result.bull_argument}\n\n"
                f"**Bear Case:**\n{debate_result.bear_argument}\n\n"
                f"**Rebuttal & Stance:** {debate_result.final_stance}\n{debate_result.rebuttal}"
            )

        user_msg = "\n\n".join(context_parts)

        temperature = (
            ctx.config.backtest_llm_temperature
            if ctx.is_backtest
            else 0.7
        )

        try:
            response = await AIPipeline._run_tier(
                ctx=ctx,
                model=ctx.config.trader_model,
                system_prompt=TRADER_SYSTEM_PROMPT,
                messages=[{"role": "user", "content": user_msg}],
                tools=DECISION_TOOLS,
                max_calls=ctx.config.max_decision_tool_calls,
                temperature=temperature,
            )
            return response
        except Exception as exc:
            _log.error("DeciderTier failed: %s", exc)
            raise
