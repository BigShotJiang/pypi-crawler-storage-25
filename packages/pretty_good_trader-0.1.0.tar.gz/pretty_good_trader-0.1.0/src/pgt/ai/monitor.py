"""Tier 1 Monitor — cheap signal detection."""

from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING

from pgt.ai.prompts import MONITOR_SYSTEM_PROMPT
from pgt.ai.tools import MONITOR_TOOLS
from pgt.models import MonitorSignal, UrgencyLevel

if TYPE_CHECKING:
    from pgt.core.context import RunContext

_log = logging.getLogger(__name__)

_URGENCY_RANK = {"low": 0, "medium": 1, "high": 2}


class MonitorTier:
    """Tier 1: cheap, fast model. Fires every MONITOR_INTERVAL seconds."""

    async def run(self, ctx: RunContext) -> MonitorSignal | None:
        """
        Run monitor cycle. Returns MonitorSignal or None (no signal / urgency below min).
        Never raises — returns None on failure (engine continues).
        """
        from pgt.ai.client import PGTLLMError
        from pgt.ai.pipeline import AIPipeline

        try:
            response = await AIPipeline._run_tier(
                ctx=ctx,
                model=ctx.config.monitor_model,
                system_prompt=MONITOR_SYSTEM_PROMPT,
                messages=[{
                    "role": "user",
                    "content": "Analyze current market conditions. Report any trading signals.",
                }],
                tools=MONITOR_TOOLS,
                max_calls=ctx.config.max_monitor_tool_calls,
            )
        except PGTLLMError:
            raise  # propagate to AIPipeline.run() which fires on_error
        except Exception as exc:
            _log.error("MonitorTier failed: %s", exc)
            return None

        return self._parse_signal(response.content, ctx)

    def _parse_signal(self, content: str, ctx: RunContext) -> MonitorSignal | None:
        """Parse LLM output → MonitorSignal. Returns None on parse failure."""
        # Strip markdown code blocks if present
        stripped = content.strip()
        if stripped.startswith("```"):
            lines = stripped.split("\n")
            stripped = "\n".join(lines[1:-1] if lines[-1] == "```" else lines[1:])

        try:
            data = json.loads(stripped)
        except json.JSONDecodeError:
            # Try to extract JSON from content
            import re
            match = re.search(r"\{.*\}", stripped, re.DOTALL)
            if match:
                try:
                    data = json.loads(match.group())
                except json.JSONDecodeError:
                    _log.debug("MonitorTier: could not parse JSON from response")
                    return MonitorSignal(signal=False, tickers=[], urgency=UrgencyLevel.LOW)
            else:
                return MonitorSignal(signal=False, tickers=[], urgency=UrgencyLevel.LOW)

        try:
            signal = MonitorSignal(**data)
        except Exception as exc:
            _log.debug("MonitorTier: MonitorSignal validation failed: %s", exc)
            return MonitorSignal(signal=False, tickers=[], urgency=UrgencyLevel.LOW)

        # Empty tickers → treat as no signal
        if signal.signal and not signal.tickers:
            return MonitorSignal(
                signal=False, tickers=[], urgency=UrgencyLevel.LOW, reason=signal.reason
            )

        # Urgency below min threshold → no-op
        min_rank = _URGENCY_RANK.get(ctx.config.min_urgency, 1)
        if signal.signal and _URGENCY_RANK.get(signal.urgency.value, 0) < min_rank:
            _log.debug(
                "MonitorTier: urgency %s below MIN_URGENCY %s — skipping",
                signal.urgency, ctx.config.min_urgency
            )
            return MonitorSignal(signal=False, tickers=signal.tickers, urgency=signal.urgency)

        # Cooldown check per ticker
        if signal.signal:
            active_tickers = [
                t for t in signal.tickers
                if not ctx.session.is_on_cooldown(t)
            ]
            if not active_tickers:
                _log.debug("MonitorTier: all tickers on cooldown")
                return MonitorSignal(signal=False, tickers=signal.tickers, urgency=signal.urgency)
            signal = MonitorSignal(
                signal=True,
                tickers=active_tickers,
                urgency=signal.urgency,
                reason=signal.reason,
            )

        return signal
