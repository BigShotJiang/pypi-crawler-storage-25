"""AIPipeline — owns the agentic loop. Monitor → Research → Debate → Decision."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING
from uuid import uuid4

from pgt.ai.client import PGTLLMError
from pgt.ai.debater import DebateTier
from pgt.ai.decider import DeciderTier
from pgt.ai.dispatcher import ToolDispatcher, ToolLimitExceededError
from pgt.ai.monitor import MonitorTier
from pgt.ai.researcher import ResearchTier
from pgt.models import LLMResponse

if TYPE_CHECKING:
    from pgt.core.context import RunContext

_log = logging.getLogger(__name__)


class AIPipeline:
    """
    Orchestrates Monitor → Research → Debate (optional) → Decision.
    Owns the agentic loop: call → dispatch tool calls → feed results → repeat.
    """

    def __init__(self) -> None:
        self._monitor = MonitorTier()
        self._researcher = ResearchTier()
        self._debater = DebateTier()
        self._decider = DeciderTier()

    async def run(self, ctx: RunContext) -> None:
        """
        Run one full pipeline cycle.
        Catches PGTLLMError specifically → fires on_error() + skips cycle.
        No broad except Exception — see CONTRIBUTING.md.
        """
        ctx.cycle_id += 1

        try:
            # Tier 1: Monitor
            signal = await self._monitor.run(ctx)

            if signal is None or not signal.signal:
                return  # no signal — nothing to do

            # Signal detected — assign trace_id
            ctx.trace_id = str(uuid4())
            _log.info(
                "Signal detected [trace=%s]: %s (%s) — %s",
                ctx.trace_id, signal.tickers, signal.urgency.value, signal.reason
            )

            # Set cooldowns for signaled tickers
            for ticker in signal.tickers:
                ctx.session.set_cooldown(ticker)

            # Fan-out signal event to plugins
            for plugin in ctx.plugins:
                try:
                    await plugin.on_signal_detected(signal)
                except Exception as exc:
                    _log.error("Plugin.on_signal_detected failed: %s", exc)

            # Tier 2: Research
            research_brief = await self._researcher.run(ctx, signal)

            # Tier 2.5: Optional debate (high urgency only)
            debate_result = await self._debater.run(ctx, signal, research_brief)

            # Tier 3: Decision
            await self._decider.run(ctx, signal, research_brief, debate_result)

        except PGTLLMError as exc:
            _log.error("AIPipeline: LLM error on cycle %d: %s", ctx.cycle_id, exc)
            for plugin in ctx.plugins:
                try:
                    await plugin.on_error(exc, f"cycle_{ctx.cycle_id}")
                except Exception as plugin_exc:
                    _log.error("Plugin.on_error failed: %s", plugin_exc)
            # Engine continues — cycle skipped, not crashed

    @staticmethod
    async def _run_tier(
        ctx: RunContext,
        model: str,
        system_prompt: str,
        messages: list[dict],
        tools: list[dict] | None,
        max_calls: int,
        temperature: float = 0.7,
    ) -> LLMResponse:
        """
        Agentic loop: call → dispatch tool calls → feed results → repeat.
        Creates a fresh ToolDispatcher per call (never reuse — counter is not resettable).
        Raises PGTLLMError on LLM failure (caught by AIPipeline.run).
        """
        dispatcher = ToolDispatcher(ctx, max_tool_calls=max_calls)
        working_messages = list(messages)

        while True:
            response = await ctx.llm.call(
                model=model,
                system_prompt=system_prompt,
                messages=working_messages,
                tools=tools,
                temperature=temperature,
            )

            if not response.tool_calls:
                return response

            # Process tool calls
            tool_results_messages = []
            for tc in response.tool_calls:
                try:
                    result = await dispatcher.dispatch(tc.name, tc.args)
                except ToolLimitExceededError as exc:
                    _log.warning("Tool limit reached: %s", exc)
                    # Return what we have so far
                    return response

                tool_results_messages.append({
                    "role": "tool",
                    "content": result.error or result.content,
                    "tool_call_id": tc.id,
                })

            # Feed tool results back
            working_messages.append(response.as_assistant_message())
            working_messages.extend(tool_results_messages)
