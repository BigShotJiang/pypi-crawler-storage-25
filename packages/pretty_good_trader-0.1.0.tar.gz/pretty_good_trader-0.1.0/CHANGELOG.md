# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] — 2026-04-11

### Added

- LLM-native trading engine with 3-tier AI pipeline (Monitor → Research → Decision)
- BacktestEngine with DuckDB catalog, checkpoint/resume, equity curve plotting
- MultiModelBacktestEngine — compare models (grok-4, claude-opus-4, etc.) in parallel
- PaperEngine decorator for paper trading on any live adapter
- CCXTAdapter — 100+ exchanges via ccxt with exponential backoff reconnect
- AlpacaAdapter (US equities) and KrakenAdapter (crypto spot)
- TelegramPlugin with fire-and-forget notifications
- DiscordPlugin with webhook-based trade alerts
- PrometheusPlugin — 8 required metrics, `/metrics` endpoint on port 9090
- RiskEngine with 7 checks (position limits, daily drawdown, duplicate orders, etc.)
- ReflectionMemory with BM25Plus retrieval — offline, zero API cost
- SessionMemory with cooldown persistence (survives restarts via SQLite)
- Full CLI: `pgt run`, `pgt backtest`, `pgt init`, `pgt doctor`, `pgt cost`, `pgt reflections`, `pgt replay`
- Docker + docker-compose for self-hosted deployment
- MkDocs Material documentation scaffold
- 253 tests, 83%+ coverage

[0.1.0]: https://github.com/prettygoodtrader/pgt/releases/tag/v0.1.0
