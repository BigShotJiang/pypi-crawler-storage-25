"""End-to-end integration test: mock LLM → risk → paper fills → log."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from pgt.adapters.paper import PaperEngine
from pgt.ai.client import PGTLLMClient
from pgt.core.clock import SimClock
from pgt.core.config import PGTConfig
from pgt.core.context import RunContext
from pgt.logger import Logger
from pgt.memory.reflection import ReflectionMemory
from pgt.memory.session import SessionMemory
from pgt.models import LLMResponse
from pgt.risk.engine import RiskEngine
from tests.conftest import MockBrokerAdapter


@pytest.mark.asyncio
async def test_full_pipeline_buy_order(tmp_path):
    """Full cycle: monitor signal → research → decision → buy order filled."""
    from pgt.ai.pipeline import AIPipeline

    config = PGTConfig(paper=True, min_urgency="low")
    mock_adapter = MockBrokerAdapter()
    paper = PaperEngine(mock_adapter, initial_capital=10_000.0, is_backtest=True)

    # LLM call sequence:
    # 1. Monitor → signal detected (NVDA, high urgency)
    # 2. Research → brief
    # 3. Decision → place_order tool call
    # 4. Decision → final content after tool result

    call_count = 0
    order_placed = False

    from pgt.models import LLMToolCall

    async def mock_llm_call(*args, **kwargs):
        nonlocal call_count, order_placed
        call_count += 1

        if call_count == 1:
            # Monitor: signal detected
            return LLMResponse(
                content=(
                    '{"signal":true,"tickers":["NVDA"],"urgency":"high",'
                    '"reason":"momentum breakout"}'
                )
            )
        elif call_count == 2:
            # Research: return brief
            return LLMResponse(content="## Research Brief\nNVDA shows strong momentum.")
        elif call_count == 3:
            # Decision: place order tool call
            order_placed = True
            return LLMResponse(
                content="",
                tool_calls=[
                    LLMToolCall(
                        id="tc1",
                        name="place_order",
                        args={"ticker": "NVDA", "side": "buy", "qty": 1.0},
                    )
                ],
            )
        else:
            # Decision: final response after tool result
            return LLMResponse(content="Bought 1 NVDA. Strong momentum signal confirmed.")

    mock_llm = MagicMock(spec=PGTLLMClient)
    mock_llm.validate_keys = MagicMock()
    mock_llm.call = AsyncMock(side_effect=mock_llm_call)

    session = SessionMemory(tmp_path / "session.json", cooldown_seconds=900)
    reflection = ReflectionMemory(tmp_path / "memory.json")
    logger = Logger(data_dir=tmp_path)

    ctx = RunContext(
        adapter=paper,
        llm=mock_llm,
        risk=RiskEngine(),
        memory=reflection,
        session=session,
        logger=logger,
        plugins=[],
        config=config,
        clock=SimClock(),
        is_backtest=True,
    )

    pipeline = AIPipeline()
    await pipeline.run(ctx)

    # Verify order was placed
    assert order_placed

    # Verify portfolio changed
    portfolio = await paper.get_portfolio()
    assert portfolio.cash < 10_000.0  # cash spent on NVDA
    assert "NVDA" in portfolio.positions
