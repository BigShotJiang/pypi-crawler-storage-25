"""Integration tests: BacktestEngine checkpoint write and resumability."""

from __future__ import annotations

from datetime import datetime, timedelta
from unittest.mock import AsyncMock, MagicMock

import pytest

from pgt.adapters.paper import PaperEngine
from pgt.ai.client import PGTLLMClient
from pgt.core.config import PGTConfig
from pgt.core.engines import BacktestEngine
from pgt.data.catalog import DuckDBCatalog
from pgt.models import LLMResponse
from tests.conftest import MockBrokerAdapter

# ─── Fixtures ────────────────────────────────────────────────────────────────


@pytest.fixture
def catalog(tmp_path):
    """DuckDB catalog seeded with 3 NVDA bars."""
    cat = DuckDBCatalog(tmp_path / "catalog.db")
    now = datetime(2024, 1, 2, 9, 30)
    for i in range(3):
        ts = now + timedelta(hours=i)
        cat._conn.execute(
            "INSERT OR REPLACE INTO ohlcv VALUES (?, ?, ?, ?, ?, ?, ?)",
            [ts, "NVDA", 500.0 + i, 510.0 + i, 490.0 + i, 505.0 + i, 1000.0],
        )
    cat._conn.commit()
    return cat


def _make_mock_llm() -> MagicMock:
    """Return a mock LLM that always returns a no-signal monitor response."""
    mock_llm = MagicMock(spec=PGTLLMClient)
    mock_llm.validate_keys = MagicMock()
    mock_llm.call = AsyncMock(
        return_value=LLMResponse(
            content='{"signal":false,"tickers":[],"urgency":"low","reason":"quiet"}'
        )
    )
    return mock_llm


def _make_engine(
    catalog: DuckDBCatalog,
    tmp_path,
    run_id: str,
    *,
    checkpoint_interval: int = 1,
) -> BacktestEngine:
    config = PGTConfig(
        paper=True,
        backtest_checkpoint_interval=checkpoint_interval,
        min_urgency="low",
    )
    mock_adapter = MockBrokerAdapter()
    paper = PaperEngine(mock_adapter, initial_capital=10_000.0, is_backtest=True)
    return BacktestEngine(
        adapter=paper,
        config=config,
        start="2024-01-02T09:30:00",
        end="2024-01-02T12:00:00",
        catalog=catalog,
        tickers=["NVDA"],
        run_id=run_id,
        llm=_make_mock_llm(),
        data_dir=str(tmp_path),
    )


# ─── Tests ────────────────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_checkpoint_written_after_run(catalog, tmp_path):
    """BacktestEngine saves a checkpoint after processing bars."""
    run_id = "test-run-001"
    engine = _make_engine(catalog, tmp_path, run_id, checkpoint_interval=1)

    result = await engine.run()

    # Result is valid
    assert result is not None
    assert result.run_id == run_id

    # Checkpoint was written to the catalog
    checkpoint = catalog.load_checkpoint(run_id)
    assert checkpoint is not None
    assert checkpoint["bar_index"] >= 0


@pytest.mark.asyncio
async def test_checkpoint_contains_expected_fields(catalog, tmp_path):
    """Checkpoint dict has bar_index, timestamp, equity, cash fields."""
    run_id = "test-run-002"
    engine = _make_engine(catalog, tmp_path, run_id, checkpoint_interval=1)

    await engine.run()

    checkpoint = catalog.load_checkpoint(run_id)
    assert checkpoint is not None
    assert "bar_index" in checkpoint
    assert "timestamp" in checkpoint
    assert "equity" in checkpoint
    assert "cash" in checkpoint

    # Equity and cash are numeric and positive
    assert isinstance(checkpoint["equity"], float)
    assert isinstance(checkpoint["cash"], float)
    assert checkpoint["equity"] > 0
    assert checkpoint["cash"] >= 0


@pytest.mark.asyncio
async def test_checkpoint_bar_index_matches_bar_count(catalog, tmp_path):
    """With interval=1 the last checkpoint bar_index equals last bar (0-based → 2 for 3 bars)."""
    run_id = "test-run-003"
    engine = _make_engine(catalog, tmp_path, run_id, checkpoint_interval=1)

    await engine.run()

    checkpoint = catalog.load_checkpoint(run_id)
    assert checkpoint is not None
    # 3 bars inserted, 0-indexed last bar is 2
    assert checkpoint["bar_index"] == 2


@pytest.mark.asyncio
async def test_checkpoint_not_duplicated_on_second_run(catalog, tmp_path):
    """Running a second BacktestEngine with same run_id overwrites, not duplicates, checkpoint."""
    run_id = "test-run-004"

    # First run
    engine1 = _make_engine(catalog, tmp_path, run_id, checkpoint_interval=1)
    await engine1.run()

    checkpoint_after_first = catalog.load_checkpoint(run_id)
    assert checkpoint_after_first is not None

    # Second run with same run_id
    engine2 = _make_engine(catalog, tmp_path, run_id, checkpoint_interval=1)
    await engine2.run()

    checkpoint_after_second = catalog.load_checkpoint(run_id)
    assert checkpoint_after_second is not None

    # Only one latest checkpoint exists (load_checkpoint returns max bar_index)
    # bar_index should still be 2 (same 3-bar dataset), not doubled
    assert checkpoint_after_second["bar_index"] == 2


@pytest.mark.asyncio
async def test_checkpoint_interval_greater_than_bars(catalog, tmp_path):
    """If checkpoint_interval > number of bars, no checkpoint is written."""
    run_id = "test-run-005"
    # 3 bars, interval=10 → checkpoint fires only at bar 9, 19, … → never
    engine = _make_engine(catalog, tmp_path, run_id, checkpoint_interval=10)

    await engine.run()

    checkpoint = catalog.load_checkpoint(run_id)
    assert checkpoint is None


@pytest.mark.asyncio
async def test_checkpoint_at_every_second_bar(catalog, tmp_path):
    """With interval=2, checkpoint is written at bar 1 (index 1) but not at bar 0."""
    run_id = "test-run-006"
    # interval=2 fires at bar_index 1 (second bar, (1+1)%2==0) and skips bar_index 0 and 2
    engine = _make_engine(catalog, tmp_path, run_id, checkpoint_interval=2)

    await engine.run()

    checkpoint = catalog.load_checkpoint(run_id)
    assert checkpoint is not None
    # Bar index 1 is the only checkpoint written for a 3-bar run with interval=2
    assert checkpoint["bar_index"] == 1


@pytest.mark.asyncio
async def test_run_returns_backtest_result_with_equity_curve(catalog, tmp_path):
    """BacktestEngine.run() returns a BacktestResult with a populated equity_curve."""
    run_id = "test-run-007"
    engine = _make_engine(catalog, tmp_path, run_id, checkpoint_interval=1)

    result = await engine.run()

    assert result is not None
    assert result.equity_curve is not None
    assert len(result.equity_curve) == 3  # one entry per bar
    # Each entry has the expected keys
    for entry in result.equity_curve:
        assert "timestamp" in entry
        assert "equity" in entry
        assert "cash" in entry
