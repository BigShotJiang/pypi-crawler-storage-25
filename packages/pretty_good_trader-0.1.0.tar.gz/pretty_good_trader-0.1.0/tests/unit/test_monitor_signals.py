"""Structured output contract tests for MonitorTier signal parsing."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from pgt.ai.monitor import MonitorTier
from pgt.core.config import PGTConfig


def make_ctx(min_urgency="medium"):
    from pgt.core.clock import SimClock
    from pgt.core.context import RunContext
    from pgt.logger import Logger
    from pgt.memory.reflection import ReflectionMemory
    from pgt.memory.session import SessionMemory
    from pgt.risk.engine import RiskEngine
    from tests.conftest import MockBrokerAdapter

    config = PGTConfig(min_urgency=min_urgency, paper=True)
    session = MagicMock(spec=SessionMemory)
    session.is_on_cooldown = MagicMock(return_value=False)
    session.set_cooldown = MagicMock()

    mock_llm = MagicMock()
    mock_llm.call = AsyncMock()

    return RunContext(
        adapter=MockBrokerAdapter(),
        llm=mock_llm,
        risk=RiskEngine(),
        memory=MagicMock(spec=ReflectionMemory),
        session=session,
        logger=MagicMock(spec=Logger),
        plugins=[],
        config=config,
        clock=SimClock(),
        is_backtest=False,
    )


@pytest.mark.parametrize("raw,expected_signal", [
    ('{"signal":true,"tickers":["NVDA"],"urgency":"high","reason":"earnings"}', True),
    ('{"signal":false,"tickers":[],"urgency":"low","reason":"quiet"}', False),
    ('not json at all', False),           # ValidationError → signal=false
    ('{"signal":true,"tickers":[]}', False),  # empty tickers → treat as false
    ('{}', False),                        # missing required fields
    ('{"signal":true}', False),           # missing tickers → invalid → false
    # urgency below MIN_URGENCY → filtered
    ('{"signal":true,"tickers":["NVDA"],"urgency":"low","reason":"test"}', False),
])
def test_monitor_signal_parsing(raw, expected_signal):
    monitor = MonitorTier()
    ctx = make_ctx(min_urgency="medium")
    result = monitor._parse_signal(raw, ctx)
    assert result is not None
    assert result.signal == expected_signal


def test_signal_true_high_urgency():
    monitor = MonitorTier()
    ctx = make_ctx(min_urgency="low")
    raw = '{"signal":true,"tickers":["NVDA","AAPL"],"urgency":"high","reason":"breakout"}'
    result = monitor._parse_signal(raw, ctx)
    assert result is not None
    assert result.signal is True
    assert "NVDA" in result.tickers


def test_cooldown_filters_tickers():
    """Tickers on cooldown should be filtered out."""
    monitor = MonitorTier()
    ctx = make_ctx(min_urgency="low")
    # All tickers on cooldown
    ctx.session.is_on_cooldown = MagicMock(return_value=True)

    raw = '{"signal":true,"tickers":["NVDA"],"urgency":"high","reason":"test"}'
    result = monitor._parse_signal(raw, ctx)
    assert result is not None
    assert result.signal is False  # all filtered by cooldown
