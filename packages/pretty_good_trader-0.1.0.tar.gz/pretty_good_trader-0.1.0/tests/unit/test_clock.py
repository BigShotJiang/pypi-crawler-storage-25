"""Tests for PGTClock implementations."""

from __future__ import annotations

from datetime import UTC, datetime

import pytest

from pgt.core.clock import SimClock, WallClock


def test_wallclock_returns_utc():
    clock = WallClock()
    now = clock.now()
    assert now.tzinfo is not None


@pytest.mark.asyncio
async def test_wallclock_sleep_real():
    """WallClock.sleep() actually sleeps (briefly)."""
    import time

    clock = WallClock()
    t0 = time.monotonic()
    await clock.sleep(0.01)
    assert time.monotonic() - t0 >= 0.009


def test_simclock_advance():
    clock = SimClock()
    ts = datetime(2024, 6, 1, 12, 0, tzinfo=UTC)
    clock.advance_to(ts)
    assert clock.now() == ts


@pytest.mark.asyncio
async def test_simclock_sleep_noop():
    """SimClock.sleep() returns immediately."""
    import time

    clock = SimClock()
    t0 = time.monotonic()
    await clock.sleep(1000)  # 1000 seconds — should return instantly
    assert time.monotonic() - t0 < 0.1
