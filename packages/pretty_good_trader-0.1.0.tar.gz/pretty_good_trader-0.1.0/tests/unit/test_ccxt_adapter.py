"""Tests for CCXTAdapter — reconnect logic and broker methods."""

from __future__ import annotations

import asyncio
import sys
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def mock_ccxt():
    """Inject fake ccxt / ccxt.pro modules before each test."""
    mock_ccxt_module = MagicMock()
    mock_ccxt_pro = MagicMock()
    sys.modules["ccxt"] = mock_ccxt_module
    sys.modules["ccxt.pro"] = mock_ccxt_pro
    yield mock_ccxt_pro
    # Cleanup — remove so tests don't bleed into each other
    sys.modules.pop("ccxt", None)
    sys.modules.pop("ccxt.pro", None)


@pytest.fixture
def mock_exchange():
    """A fully-stubbed async exchange object."""
    ex = MagicMock()
    ex.load_markets = AsyncMock()
    ex.ping = AsyncMock()
    ex.close = AsyncMock()
    ex.fetch_balance = AsyncMock(
        return_value={
            "USDT": {"free": 1000.0, "total": 1000.0},
            "total": {"BTC": 0.5, "ETH": 2.0, "USDT": 1000.0},
        }
    )
    ex.fetch_ticker = AsyncMock(return_value={"last": 42000.0})
    ex.create_order = AsyncMock(
        return_value={
            "id": "order-123",
            "amount": 0.1,
            "price": 42000.0,
        }
    )
    ex.cancel_order = AsyncMock()
    ex.fetch_open_orders = AsyncMock(
        return_value=[
            {
                "id": "open-1",
                "symbol": "BTC/USDT",
                "side": "buy",
                "amount": 0.05,
            }
        ]
    )
    return ex


@pytest.fixture
def adapter(mock_ccxt, mock_exchange):
    """CCXTAdapter with the exchange replaced by our mock."""
    # Import inside fixture so sys.modules patches are in effect
    from pgt.adapters.ccxt import CCXTAdapter  # noqa: PLC0415

    mock_ccxt.binance = MagicMock(return_value=mock_exchange)
    instance = CCXTAdapter("binance", "test-key", "test-secret")
    # Direct injection so we don't rely on getattr(ccxtpro, ...)
    instance._exchange = mock_exchange
    return instance


# ---------------------------------------------------------------------------
# __init__ / context manager
# ---------------------------------------------------------------------------


class TestCCXTAdapterInit:
    def test_import_error_when_ccxt_missing(self):
        """ImportError is raised if ccxt is not installed."""
        # Remove both ccxt entries so the import inside __init__ fails
        sys.modules.pop("ccxt", None)
        sys.modules.pop("ccxt.pro", None)

        from pgt.adapters.ccxt import CCXTAdapter  # noqa: PLC0415

        with pytest.raises(ImportError, match="ccxt is required"):
            CCXTAdapter("binance", "k", "s")

    def test_exchange_created_with_credentials(self, mock_ccxt, mock_exchange):
        from pgt.adapters.ccxt import CCXTAdapter  # noqa: PLC0415

        adapter = CCXTAdapter("binance", "my-key", "my-secret")
        # exchange_id stored correctly; exchange object created (not None)
        assert adapter._exchange_id == "binance"
        assert adapter._exchange is not None


class TestCCXTAdapterContextManager:
    @pytest.mark.asyncio
    async def test_aenter_loads_markets_and_starts_heartbeat(
        self, adapter, mock_exchange
    ):
        async with adapter:
            mock_exchange.load_markets.assert_awaited_once()
            assert adapter._heartbeat_task is not None
            assert not adapter._heartbeat_task.done()

    @pytest.mark.asyncio
    async def test_aexit_cancels_heartbeat_and_closes_exchange(
        self, adapter, mock_exchange
    ):
        async with adapter:
            task = adapter._heartbeat_task

        assert task.cancelled()
        mock_exchange.close.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_aexit_without_heartbeat_task_does_not_raise(
        self, adapter, mock_exchange
    ):
        """If _heartbeat_task is None (never entered), __aexit__ is safe."""
        adapter._heartbeat_task = None
        await adapter.__aexit__(None, None, None)
        mock_exchange.close.assert_awaited_once()


# ---------------------------------------------------------------------------
# _heartbeat_loop
# ---------------------------------------------------------------------------


class TestHeartbeatLoop:
    @pytest.mark.asyncio
    async def test_heartbeat_calls_ping(self, adapter, mock_exchange):
        """After the 30s sleep (patched to 0), ping is called."""
        sleep_calls = []

        async def fake_sleep(n):
            sleep_calls.append(n)
            if len(sleep_calls) >= 2:
                raise asyncio.CancelledError

        with patch("pgt.adapters.ccxt.asyncio.sleep", side_effect=fake_sleep):
            with pytest.raises(asyncio.CancelledError):
                await adapter._heartbeat_loop()

        mock_exchange.ping.assert_awaited()

    @pytest.mark.asyncio
    async def test_heartbeat_calls_reconnect_on_ping_failure(
        self, adapter, mock_exchange
    ):
        """When ping raises, _reconnect() is invoked."""
        mock_exchange.ping.side_effect = Exception("connection lost")

        reconnect_called = []

        async def fake_reconnect():
            reconnect_called.append(True)
            raise asyncio.CancelledError  # stop the loop after first reconnect

        adapter._reconnect = fake_reconnect

        sleep_calls = []

        async def fake_sleep(n):
            sleep_calls.append(n)

        with patch("pgt.adapters.ccxt.asyncio.sleep", side_effect=fake_sleep):
            with pytest.raises(asyncio.CancelledError):
                await adapter._heartbeat_loop()

        assert reconnect_called, "_reconnect should have been called"


# ---------------------------------------------------------------------------
# _reconnect — exponential backoff
# ---------------------------------------------------------------------------


class TestReconnect:
    @pytest.mark.asyncio
    async def test_reconnect_succeeds_on_first_attempt(
        self, adapter, mock_exchange
    ):
        """load_markets succeeds immediately — no sleep, logs reconnect."""
        sleep_calls = []

        async def _fake_sleep(n: float) -> None:
            sleep_calls.append(n)

        with patch("pgt.adapters.ccxt.asyncio.sleep", side_effect=_fake_sleep):
            await adapter._reconnect()

        mock_exchange.close.assert_awaited_once()
        mock_exchange.load_markets.assert_awaited_once()
        assert sleep_calls == [], "No sleep on first-attempt success"

    @pytest.mark.asyncio
    async def test_reconnect_retries_with_exponential_backoff(
        self, adapter, mock_exchange
    ):
        """load_markets fails twice then succeeds; delays double each time."""
        call_count = 0

        async def failing_then_ok():
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                raise Exception(f"fail {call_count}")

        mock_exchange.load_markets.side_effect = failing_then_ok

        sleep_delays = []

        async def record_sleep(n):
            sleep_delays.append(n)

        with patch("pgt.adapters.ccxt.asyncio.sleep", side_effect=record_sleep):
            await adapter._reconnect()

        assert call_count == 3
        assert sleep_delays == [1.0, 2.0], f"Expected [1.0, 2.0], got {sleep_delays}"

    @pytest.mark.asyncio
    async def test_reconnect_caps_delay_at_30s(self, adapter, mock_exchange):
        """Sleep delay is capped at 30 seconds regardless of exponent."""
        # Fail 5 times to drive delay past 30s
        mock_exchange.load_markets.side_effect = Exception("always fails")

        sleep_delays = []

        async def record_sleep(n):
            sleep_delays.append(n)

        with patch("pgt.adapters.ccxt.asyncio.sleep", side_effect=record_sleep):
            await adapter._reconnect()

        assert all(d <= 30.0 for d in sleep_delays), (
            f"All delays must be <= 30s, got {sleep_delays}"
        )

    @pytest.mark.asyncio
    async def test_reconnect_gives_up_after_5_attempts(
        self, adapter, mock_exchange
    ):
        """After 5 failed attempts, _reconnect returns without raising."""
        mock_exchange.load_markets.side_effect = Exception("always fails")

        with patch("pgt.adapters.ccxt.asyncio.sleep", new_callable=AsyncMock):
            await adapter._reconnect()  # must not raise

        assert mock_exchange.load_markets.await_count == 5

    @pytest.mark.asyncio
    async def test_reconnect_delay_sequence_is_correct(
        self, adapter, mock_exchange
    ):
        """Full 5-fail run: delays should be [1, 2, 4, 8, 16] capped at 30."""
        mock_exchange.load_markets.side_effect = Exception("always fails")

        sleep_delays = []

        async def record_sleep(n):
            sleep_delays.append(n)

        with patch("pgt.adapters.ccxt.asyncio.sleep", side_effect=record_sleep):
            await adapter._reconnect()

        expected = [min(1.0 * 2**i, 30.0) for i in range(5)]
        assert sleep_delays == expected, f"Expected {expected}, got {sleep_delays}"


# ---------------------------------------------------------------------------
# get_portfolio
# ---------------------------------------------------------------------------


class TestGetPortfolio:
    @pytest.mark.asyncio
    async def test_returns_portfolio_snapshot(self, adapter, mock_exchange):
        from pgt.models import PortfolioSnapshot  # noqa: PLC0415

        result = await adapter.get_portfolio()

        assert isinstance(result, PortfolioSnapshot)
        assert result.cash == 1000.0

    @pytest.mark.asyncio
    async def test_positions_exclude_usdt(self, adapter, mock_exchange):
        result = await adapter.get_portfolio()

        assert "USDT" not in result.positions
        assert "BTC" in result.positions
        assert result.positions["BTC"].qty == 0.5

    @pytest.mark.asyncio
    async def test_raises_broker_error_on_exchange_failure(
        self, adapter, mock_exchange
    ):
        from pgt.adapters.base import BrokerError  # noqa: PLC0415

        mock_exchange.fetch_balance.side_effect = Exception("network error")

        with pytest.raises(BrokerError, match="get_portfolio failed"):
            await adapter.get_portfolio()


# ---------------------------------------------------------------------------
# get_prices
# ---------------------------------------------------------------------------


class TestGetPrices:
    @pytest.mark.asyncio
    async def test_returns_prices_dict(self, adapter, mock_exchange):
        result = await adapter.get_prices(["BTC", "ETH"])

        assert result == {"BTC": 42000.0, "ETH": 42000.0}
        assert mock_exchange.fetch_ticker.await_count == 2

    @pytest.mark.asyncio
    async def test_skips_failed_ticker_gracefully(self, adapter, mock_exchange):
        """A failing ticker is logged but does not raise."""
        mock_exchange.fetch_ticker.side_effect = [
            {"last": 42000.0},
            Exception("ticker error"),
        ]

        result = await adapter.get_prices(["BTC", "ETH"])

        assert "BTC" in result
        assert "ETH" not in result

    @pytest.mark.asyncio
    async def test_empty_tickers_returns_empty_dict(self, adapter):
        result = await adapter.get_prices([])
        assert result == {}


# ---------------------------------------------------------------------------
# place_order
# ---------------------------------------------------------------------------


class TestPlaceOrder:
    @pytest.mark.asyncio
    async def test_place_buy_order_returns_order_result(
        self, adapter, mock_exchange
    ):
        from pgt.models import OrderIntent, OrderResult, OrderSide  # noqa: PLC0415

        intent = OrderIntent(ticker="BTC", side=OrderSide.BUY, qty=0.1)
        result = await adapter.place_order(intent)

        assert isinstance(result, OrderResult)
        assert result.order_id == "order-123"
        assert result.ticker == "BTC"
        assert result.side == OrderSide.BUY
        assert result.qty == 0.1
        assert result.fill_price == 42000.0
        assert result.exchange == "binance"

    @pytest.mark.asyncio
    async def test_place_sell_order(self, adapter, mock_exchange):
        from pgt.models import OrderIntent, OrderSide  # noqa: PLC0415

        mock_exchange.create_order.return_value = {
            "id": "sell-456",
            "amount": 0.2,
            "price": None,
        }
        intent = OrderIntent(ticker="ETH", side=OrderSide.SELL, qty=0.2)
        result = await adapter.place_order(intent)

        call_args = mock_exchange.create_order.call_args
        assert call_args.kwargs["side"] == "sell"
        assert result.fill_price is None

    @pytest.mark.asyncio
    async def test_place_order_raises_broker_error_on_failure(
        self, adapter, mock_exchange
    ):
        from pgt.adapters.base import BrokerError  # noqa: PLC0415
        from pgt.models import OrderIntent, OrderSide  # noqa: PLC0415

        mock_exchange.create_order.side_effect = Exception("order rejected")
        intent = OrderIntent(ticker="BTC", side=OrderSide.BUY, qty=0.1)

        with pytest.raises(BrokerError, match="place_order failed"):
            await adapter.place_order(intent)


# ---------------------------------------------------------------------------
# cancel_order
# ---------------------------------------------------------------------------


class TestCancelOrder:
    @pytest.mark.asyncio
    async def test_cancel_order_returns_true_on_success(
        self, adapter, mock_exchange
    ):
        result = await adapter.cancel_order("order-123")
        assert result is True
        mock_exchange.cancel_order.assert_awaited_once_with("order-123")

    @pytest.mark.asyncio
    async def test_cancel_order_returns_false_on_failure(
        self, adapter, mock_exchange
    ):
        mock_exchange.cancel_order.side_effect = Exception("not found")
        result = await adapter.cancel_order("bad-id")
        assert result is False


# ---------------------------------------------------------------------------
# get_orders
# ---------------------------------------------------------------------------


class TestGetOrders:
    @pytest.mark.asyncio
    async def test_get_orders_returns_list_of_order_results(
        self, adapter, mock_exchange
    ):
        from pgt.models import OrderResult, OrderSide  # noqa: PLC0415

        results = await adapter.get_orders()

        assert len(results) == 1
        assert isinstance(results[0], OrderResult)
        assert results[0].order_id == "open-1"
        assert results[0].ticker == "BTC"
        assert results[0].side == OrderSide.BUY
        assert results[0].qty == 0.05

    @pytest.mark.asyncio
    async def test_get_orders_raises_broker_error_on_failure(
        self, adapter, mock_exchange
    ):
        from pgt.adapters.base import BrokerError  # noqa: PLC0415

        mock_exchange.fetch_open_orders.side_effect = Exception("connection lost")

        with pytest.raises(BrokerError, match="get_orders failed"):
            await adapter.get_orders()

    @pytest.mark.asyncio
    async def test_get_orders_sell_side_mapping(self, adapter, mock_exchange):
        from pgt.models import OrderSide  # noqa: PLC0415

        mock_exchange.fetch_open_orders.return_value = [
            {
                "id": "sell-99",
                "symbol": "ETH/USDT",
                "side": "sell",
                "amount": 1.0,
            }
        ]
        results = await adapter.get_orders()
        assert results[0].side == OrderSide.SELL


# ---------------------------------------------------------------------------
# exchange_name property
# ---------------------------------------------------------------------------


class TestExchangeName:
    def test_exchange_name_returns_exchange_id(self, adapter):
        assert adapter.exchange_name == "binance"
