"""Tests for EventBus two-tier delivery."""

from __future__ import annotations

import asyncio

import pytest

from pgt.core.bus import EventBus, PGTEvent


@pytest.mark.asyncio
async def test_critical_event_delivered_directly():
    """Critical events (order_placed) delivered directly even when queue is full."""
    bus = EventBus()
    received = []

    async def handler(event: PGTEvent) -> None:
        received.append(event)

    bus.subscribe("order_placed", handler)  # critical event

    event = PGTEvent(event_type="order_placed", payload={"ticker": "NVDA"})
    await bus.publish(event)

    assert len(received) == 1
    assert received[0].payload["ticker"] == "NVDA"


@pytest.mark.asyncio
async def test_non_critical_event_queued():
    """Non-critical events (signal_detected) go through per-subscriber queue."""
    bus = EventBus()
    received = []

    async def handler(event: PGTEvent) -> None:
        received.append(event)

    bus.subscribe("signal_detected", handler)

    event = PGTEvent(event_type="signal_detected", payload={"tickers": ["NVDA"]})
    await bus.publish(event)

    # Allow queue drain task to run
    await asyncio.sleep(0.05)
    assert len(received) == 1


@pytest.mark.asyncio
async def test_critical_event_delivered_when_queue_would_be_full():
    """Critical events bypass queue entirely — they call handler directly."""
    bus = EventBus()
    calls = []

    async def handler(event: PGTEvent) -> None:
        calls.append(event)

    bus.subscribe("engine_error", handler)  # critical

    # Publish 5 events — all delivered directly (no queue limit for critical)
    for i in range(5):
        await bus.publish(PGTEvent(event_type="engine_error", payload={"i": i}))

    assert len(calls) == 5


@pytest.mark.asyncio
async def test_non_critical_dropped_when_queue_full():
    """Non-critical events are dropped when per-subscriber queue is full (maxsize=1000)."""
    bus = EventBus()

    # Override queue maxsize to 2 for test speed
    import asyncio

    q: asyncio.Queue[PGTEvent] = asyncio.Queue(maxsize=2)

    async def slow_handler(event: PGTEvent) -> None:
        await asyncio.sleep(100)  # block intentionally

    # Manually inject small queue
    bus._queues["order_filled"] = [q]
    asyncio.create_task(bus._drain_queue(q, slow_handler, "order_filled"))

    # Fill queue
    await bus.publish(PGTEvent(event_type="order_filled", payload={"a": 1}))
    await bus.publish(PGTEvent(event_type="order_filled", payload={"b": 2}))

    # This one should be dropped (queue full)
    await bus.publish(PGTEvent(event_type="order_filled", payload={"c": 3}))

    # Queue size = 2 (not 3)
    assert q.qsize() == 2


@pytest.mark.asyncio
async def test_handler_exception_doesnt_affect_other_handlers():
    """One handler failure must not stop other handlers."""
    bus = EventBus()
    received = []

    async def bad_handler(event: PGTEvent) -> None:
        raise RuntimeError("plugin failure")

    async def good_handler(event: PGTEvent) -> None:
        received.append(event)

    bus.subscribe("order_placed", bad_handler)
    bus.subscribe("order_placed", good_handler)

    await bus.publish(PGTEvent(event_type="order_placed", payload={}))

    assert len(received) == 1
