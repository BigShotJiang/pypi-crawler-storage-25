"""Tests for PaperEngine."""

from __future__ import annotations

import asyncio

import pytest

from pgt.adapters.paper import PaperEngine, PGTStateError
from pgt.models import OrderIntent, OrderSide, OrderStatus


@pytest.mark.asyncio
async def test_buy_reduces_cash(paper_engine):
    intent = OrderIntent(ticker="NVDA", side=OrderSide.BUY, qty=1.0)
    result = await paper_engine.place_order(intent)
    assert result.status == OrderStatus.FILLED
    portfolio = await paper_engine.get_portfolio()
    assert portfolio.cash < 10_000.0


@pytest.mark.asyncio
async def test_sell_increases_cash(paper_engine):
    # Buy first
    buy = OrderIntent(ticker="NVDA", side=OrderSide.BUY, qty=1.0)
    await paper_engine.place_order(buy)
    cash_after_buy = (await paper_engine.get_portfolio()).cash

    # Sell
    sell = OrderIntent(ticker="NVDA", side=OrderSide.SELL, qty=1.0)
    result = await paper_engine.place_order(sell)
    assert result.status == OrderStatus.FILLED
    portfolio = await paper_engine.get_portfolio()
    assert portfolio.cash > cash_after_buy


@pytest.mark.asyncio
async def test_insufficient_funds_rejected(paper_engine):
    intent = OrderIntent(ticker="NVDA", side=OrderSide.BUY, qty=1_000_000.0)
    result = await paper_engine.place_order(intent)
    assert result.status == OrderStatus.REJECTED
    assert "Insufficient" in (result.error or "")


@pytest.mark.asyncio
async def test_insufficient_position_rejected(paper_engine):
    intent = OrderIntent(ticker="NVDA", side=OrderSide.SELL, qty=999.0)
    result = await paper_engine.place_order(intent)
    assert result.status == OrderStatus.REJECTED


@pytest.mark.asyncio
async def test_is_paper_true(paper_engine):
    assert paper_engine.is_paper is True


@pytest.mark.asyncio
async def test_backtest_no_file_written(mock_adapter, tmp_path):
    """is_backtest=True → no state file written."""
    engine = PaperEngine(
        live_adapter=mock_adapter,
        initial_capital=10_000.0,
        is_backtest=True,
        state_file=tmp_path / "should_not_exist.json",
    )
    intent = OrderIntent(ticker="NVDA", side=OrderSide.BUY, qty=1.0)
    await engine.place_order(intent)
    assert not (tmp_path / "should_not_exist.json").exists()


@pytest.mark.asyncio
async def test_concurrent_no_double_spend(mock_adapter, tmp_path):
    """10 parallel place_order calls must not double-spend."""
    engine = PaperEngine(
        live_adapter=mock_adapter,
        initial_capital=10_000.0,
        is_backtest=True,
    )

    # NVDA @ 500, buying 1 share × 10 concurrent = 5000 total (+ fees)
    intents = [
        OrderIntent(ticker="NVDA", side=OrderSide.BUY, qty=1.0) for _ in range(10)
    ]
    results = await asyncio.gather(*[engine.place_order(i) for i in intents])

    filled = [r for r in results if r.status == OrderStatus.FILLED]

    portfolio = await engine.get_portfolio()

    # Cash should not go negative — some fills, some rejections
    assert portfolio.cash >= 0
    # All filled orders should account for cash
    total_spent = sum(
        r.fill_price * r.qty for r in filled if r.fill_price
    )
    assert 10_000.0 - total_spent >= -0.01  # allow for fees


@pytest.mark.asyncio
async def test_corrupted_state_raises(mock_adapter, tmp_path):
    """Corrupted state file must raise PGTStateError — never silently reset."""
    state_file = tmp_path / "corrupt.json"
    state_file.write_text("{invalid json}")

    with pytest.raises(PGTStateError):
        PaperEngine(
            live_adapter=mock_adapter,
            initial_capital=10_000.0,
            state_file=state_file,
        )
