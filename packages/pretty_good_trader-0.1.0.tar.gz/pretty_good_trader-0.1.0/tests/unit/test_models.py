"""Tests for Pydantic models."""

from pgt.models import (
    MonitorSignal,
    OrderIntent,
    OrderSide,
    PortfolioSnapshot,
    Position,
    TradeReflection,
    UrgencyLevel,
)


def test_portfolio_equity():
    portfolio = PortfolioSnapshot(
        cash=5000.0,
        positions={
            "NVDA": Position(ticker="NVDA", qty=10.0, avg_cost=400.0, current_price=500.0)
        },
    )
    assert portfolio.equity == 5000.0 + 10.0 * 500.0


def test_portfolio_position_count():
    portfolio = PortfolioSnapshot(cash=10_000.0)
    assert portfolio.position_count == 0


def test_unrealized_pnl():
    pos = Position(ticker="NVDA", qty=10.0, avg_cost=400.0, current_price=500.0)
    assert pos.unrealized_pnl == 1000.0


def test_monitor_signal_defaults():
    sig = MonitorSignal(signal=True, tickers=["NVDA"], urgency=UrgencyLevel.HIGH, reason="test")
    assert sig.signal is True
    assert "NVDA" in sig.tickers


def test_trade_reflection_auto_tokens():
    r = TradeReflection(
        ticker="NVDA",
        action="buy",
        outcome="win",
        lesson="momentum works",
    )
    assert len(r.tokens) > 0
    assert "nvda" in r.tokens


def test_order_intent_validation():
    intent = OrderIntent(ticker="NVDA", side=OrderSide.BUY, qty=10.0)
    assert intent.ticker == "NVDA"
    assert intent.side == OrderSide.BUY
