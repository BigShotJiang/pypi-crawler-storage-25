"""Phase 2 CLI tests: PID lock, dry-run banner, status --watch output."""

from __future__ import annotations

import os
from unittest.mock import MagicMock, patch

import pytest
from typer.testing import CliRunner

from pgt.cli import _acquire_pid_lock, _release_pid_lock, app

runner = CliRunner(mix_stderr=False)


# ─── PID lock ────────────────────────────────────────────────────────────────

class TestPidLock:
    def test_acquire_creates_pid_file(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        pid_path = tmp_path / "data" / "pgt.pid"
        monkeypatch.setattr("pgt.cli._PID_FILE", pid_path)

        _acquire_pid_lock()
        assert pid_path.exists()
        assert int(pid_path.read_text()) == os.getpid()
        _release_pid_lock()

    def test_release_removes_pid_file(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        pid_path = tmp_path / "data" / "pgt.pid"
        monkeypatch.setattr("pgt.cli._PID_FILE", pid_path)

        _acquire_pid_lock()
        assert pid_path.exists()
        _release_pid_lock()
        assert not pid_path.exists()

    def test_stale_pid_file_does_not_block(self, tmp_path, monkeypatch):
        """A PID file pointing to a dead process must not block startup."""
        monkeypatch.chdir(tmp_path)
        pid_path = tmp_path / "data" / "pgt.pid"
        monkeypatch.setattr("pgt.cli._PID_FILE", pid_path)

        pid_path.parent.mkdir(parents=True, exist_ok=True)
        # Write a PID that does not exist
        pid_path.write_text("99999999")

        with patch("psutil.pid_exists", return_value=False):
            _acquire_pid_lock()  # should not raise

        assert int(pid_path.read_text()) == os.getpid()
        _release_pid_lock()

    def test_live_process_blocks(self, tmp_path, monkeypatch):
        """A PID file pointing to a live pgt process must raise SystemExit."""
        monkeypatch.chdir(tmp_path)
        pid_path = tmp_path / "data" / "pgt.pid"
        monkeypatch.setattr("pgt.cli._PID_FILE", pid_path)

        pid_path.parent.mkdir(parents=True, exist_ok=True)
        pid_path.write_text("12345")

        mock_proc = MagicMock()
        mock_proc.cmdline.return_value = ["python", "-m", "pgt", "run"]

        with patch("psutil.pid_exists", return_value=True), \
             patch("psutil.Process", return_value=mock_proc):
            with pytest.raises(Exception):  # typer.Exit / click.exceptions.Exit
                _acquire_pid_lock()


# ─── pgt run --dry-run ───────────────────────────────────────────────────────

class TestDryRun:
    def test_dry_run_shows_config_panel(self, monkeypatch, tmp_path):
        monkeypatch.chdir(tmp_path)
        result = runner.invoke(app, ["run", "--dry-run"], catch_exceptions=False)
        assert result.exit_code == 0
        assert "Config" in result.output

    def test_dry_run_shows_mock_monitor(self, monkeypatch, tmp_path):
        monkeypatch.chdir(tmp_path)
        result = runner.invoke(app, ["run", "--dry-run"], catch_exceptions=False)
        assert "Mock Monitor" in result.output

    def test_dry_run_shows_ready_panel(self, monkeypatch, tmp_path):
        monkeypatch.chdir(tmp_path)
        result = runner.invoke(app, ["run", "--dry-run"], catch_exceptions=False)
        assert "Ready" in result.output

    def test_paper_mode_banner(self, monkeypatch, tmp_path):
        monkeypatch.chdir(tmp_path)
        result = runner.invoke(app, ["run", "--dry-run"], catch_exceptions=False)
        assert "PAPER MODE" in result.output

    def test_live_mode_requires_confirm(self, monkeypatch, tmp_path):
        monkeypatch.chdir(tmp_path)
        # Set PAPER=false and required EMERGENCY_LIQUIDATE_TOKEN
        monkeypatch.setenv("PAPER", "false")
        monkeypatch.setenv("EMERGENCY_LIQUIDATE_TOKEN", "test-token-abc")
        result = runner.invoke(app, ["run", "--no-paper"])
        assert result.exit_code == 1
        assert "--confirm-live" in result.output


# ─── pgt status ──────────────────────────────────────────────────────────────

class TestStatus:
    def test_status_no_cycles(self, monkeypatch, tmp_path):
        monkeypatch.chdir(tmp_path)
        result = runner.invoke(app, ["status"], catch_exceptions=False)
        assert result.exit_code == 0
        # Should print "no cycles" message
        assert (
            "No trading cycles" in result.output
            or "No cycles" in result.output
            or result.output.strip()
        )

    def test_status_with_cycles(self, monkeypatch, tmp_path):
        # Logger defaults to "data" dir relative to cwd
        monkeypatch.chdir(tmp_path)
        from pgt.logger import Logger

        logger = Logger(data_dir=tmp_path / "data")
        logger.log_cycle(
            cycle_type="monitor",
            model="xai/grok-4-1-fast",
            signal={"signal": False},
            api_cost=0.0012,
        )

        result = runner.invoke(app, ["status"], catch_exceptions=False)
        assert result.exit_code == 0


# ─── pgt cost --forecast ─────────────────────────────────────────────────────

class TestCostForecast:
    def test_cost_no_data(self, monkeypatch, tmp_path):
        monkeypatch.chdir(tmp_path)
        result = runner.invoke(app, ["cost"], catch_exceptions=False)
        assert result.exit_code == 0
        assert "No cost data" in result.output

    def test_cost_forecast_top3(self, monkeypatch, tmp_path):
        # Logger defaults to "data" dir relative to cwd
        monkeypatch.chdir(tmp_path)
        from pgt.logger import Logger

        logger = Logger(data_dir=tmp_path / "data")
        costs = [0.01, 0.05, 0.02, 0.10, 0.003]
        for cost in costs:
            logger.log_cycle(
                cycle_type="monitor",
                model="xai/grok-4-1-fast",
                api_cost=cost,
            )

        result = runner.invoke(app, ["cost", "--forecast"], catch_exceptions=False)
        assert result.exit_code == 0
        assert "30-day forecast" in result.output
        assert "Top 3" in result.output
