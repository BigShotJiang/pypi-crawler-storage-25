"""Tests for PGTPlugin base class no-op defaults."""

from __future__ import annotations

import pytest

from pgt.models import (
    MonitorSignal,
    OrderIntent,
    OrderResult,
    OrderSide,
    OrderStatus,
    PortfolioSnapshot,
    UrgencyLevel,
)
from pgt.plugins.base import PGTPlugin


class ConcretePlugin(PGTPlugin):
    """Minimal concrete plugin (no overrides) — tests no-op defaults."""
    pass


@pytest.mark.asyncio
async def test_on_startup_noop(run_context):
    plugin = ConcretePlugin()
    await plugin.on_startup(run_context)  # should not raise


@pytest.mark.asyncio
async def test_on_signal_detected_noop():
    plugin = ConcretePlugin()
    signal = MonitorSignal(signal=True, tickers=["NVDA"], urgency=UrgencyLevel.HIGH)
    await plugin.on_signal_detected(signal)


@pytest.mark.asyncio
async def test_on_order_placed_noop():
    plugin = ConcretePlugin()
    order = OrderResult(
        order_id="test", ticker="NVDA", side=OrderSide.BUY, qty=1.0,
        fill_price=500.0, status=OrderStatus.FILLED, exchange="paper"
    )
    portfolio = PortfolioSnapshot(cash=9000.0)
    await plugin.on_order_placed(order, portfolio)


@pytest.mark.asyncio
async def test_on_order_blocked_noop():
    plugin = ConcretePlugin()
    intent = OrderIntent(ticker="NVDA", side=OrderSide.BUY, qty=1.0)
    await plugin.on_order_blocked("max position", intent)


@pytest.mark.asyncio
async def test_on_error_noop():
    plugin = ConcretePlugin()
    await plugin.on_error(ValueError("test"), "test_context")


@pytest.mark.asyncio
async def test_on_shutdown_noop():
    plugin = ConcretePlugin()
    await plugin.on_shutdown()
