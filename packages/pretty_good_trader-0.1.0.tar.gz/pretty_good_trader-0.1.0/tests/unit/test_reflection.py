"""Tests for BM25 ReflectionMemory."""

from __future__ import annotations

from pgt.memory.reflection import ReflectionMemory
from pgt.models import TradeReflection


def make_reflection(ticker="NVDA", lesson="momentum works") -> TradeReflection:
    return TradeReflection(
        ticker=ticker,
        action="buy",
        outcome="win",
        lesson=lesson,
    )


def test_add_and_search(tmp_path):
    memory = ReflectionMemory(storage_path=tmp_path / "m.json")
    memory.add_reflection(make_reflection("NVDA", "AI chips rally on earnings"))
    memory.add_reflection(make_reflection("AAPL", "product launch drove premium"))

    results = memory.search("NVDA AI chips")
    assert len(results) > 0
    # NVDA reflection should rank first
    assert results[0].ticker == "NVDA"


def test_search_empty_memory(tmp_path):
    memory = ReflectionMemory(storage_path=tmp_path / "m.json")
    results = memory.search("anything")
    assert results == []


def test_fifo_rotation(tmp_path):
    memory = ReflectionMemory(storage_path=tmp_path / "m.json", max_entries=5)
    for i in range(7):
        memory.add_reflection(make_reflection(f"T{i}", f"lesson {i}"))

    assert len(memory) == 5
    # Oldest (T0, T1) should be evicted; newest remain
    tickers = [r.ticker for r in memory._corpus]
    assert "T0" not in tickers
    assert "T6" in tickers


def test_index_not_rebuilt_on_search(tmp_path, monkeypatch):
    """search() must use cached index — never rebuild."""
    memory = ReflectionMemory(storage_path=tmp_path / "m.json")
    memory.add_reflection(make_reflection())

    rebuild_count = 0
    original_rebuild = memory._rebuild_index

    def counting_rebuild():
        nonlocal rebuild_count
        rebuild_count += 1
        original_rebuild()

    monkeypatch.setattr(memory, "_rebuild_index", counting_rebuild)

    # Multiple searches should not trigger rebuild
    memory.search("NVDA momentum")
    memory.search("something else")
    assert rebuild_count == 0


def test_persistence(tmp_path):
    """ReflectionMemory survives round-trip."""
    path = tmp_path / "m.json"
    m1 = ReflectionMemory(storage_path=path)
    m1.add_reflection(make_reflection("NVDA", "momentum strategy"))

    m2 = ReflectionMemory(storage_path=path)
    assert len(m2) == 1
    assert m2._corpus[0].ticker == "NVDA"
