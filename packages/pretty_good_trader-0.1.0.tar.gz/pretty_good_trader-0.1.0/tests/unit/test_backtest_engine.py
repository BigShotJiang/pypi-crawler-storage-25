"""Tests for BacktestEngine."""

from __future__ import annotations

from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock

import pytest

from pgt.adapters.paper import PaperEngine
from pgt.core.clock import SimClock
from pgt.core.engines import BacktestEngine
from pgt.data.catalog import DuckDBCatalog


def test_sim_clock_advance():
    """SimClock.advance_to() → now() returns new ts."""
    clock = SimClock()
    ts = datetime(2024, 6, 1, 10, 0, tzinfo=UTC)
    clock.advance_to(ts)
    assert clock.now() == ts


def test_sim_clock_sleep_noop():
    """SimClock.sleep() is a no-op — no actual waiting."""
    import asyncio
    import time

    clock = SimClock()
    t0 = time.monotonic()
    asyncio.get_event_loop().run_until_complete(clock.sleep(100))
    elapsed = time.monotonic() - t0
    assert elapsed < 0.1  # < 100ms — no real sleep


@pytest.mark.asyncio
async def test_load_range_failure_raises_catalog_error(tmp_path):
    """load_range() on missing/corrupt catalog raises PGTCatalogError (fail fast)."""
    catalog = DuckDBCatalog(tmp_path / "catalog.db")
    # No data inserted — empty catalog, but valid DB
    bars = catalog.load_range("2024-01-01", "2024-01-31")
    assert isinstance(bars, dict)  # returns empty dict, not error
    catalog.close()


@pytest.mark.asyncio
async def test_pipeline_called_once_per_bar(mock_adapter, test_config, tmp_path):
    """pipeline.run() called exactly once per bar."""
    from pgt.models import LLMResponse

    catalog = DuckDBCatalog(tmp_path / "catalog.db")

    # Insert 3 bars
    from datetime import datetime
    conn = catalog._conn
    for i in range(3):
        ts = datetime(2024, 1, i + 1, 10, 0, tzinfo=UTC)
        conn.execute(
            "INSERT INTO ohlcv VALUES (?, 'NVDA', 100, 105, 98, 102, 1000000)",
            [ts],
        )
    conn.commit()

    paper = PaperEngine(mock_adapter, initial_capital=10_000.0, is_backtest=True)
    engine = BacktestEngine(
        adapter=paper,
        config=test_config,
        start="2024-01-01",
        end="2024-01-31",
        catalog=catalog,
        tickers=["NVDA"],
        data_dir=str(tmp_path),
    )

    call_count = 0
    original_run = engine._pipeline.run

    async def counting_run(ctx):
        nonlocal call_count
        call_count += 1
        return await original_run(ctx)

    engine._pipeline.run = counting_run

    # Mock LLM to return no-signal
    mock_llm = MagicMock()
    mock_llm.validate_keys = MagicMock()
    mock_llm.call = AsyncMock(
        return_value=LLMResponse(
            content='{"signal":false,"tickers":[],"urgency":"low","reason":"quiet"}'
        )
    )
    engine._llm = mock_llm

    await engine.run()
    assert call_count == 3  # one per bar
    catalog.close()


@pytest.mark.asyncio
async def test_backtest_is_backtest_flag_set(mock_adapter, test_config, tmp_path):
    """BacktestEngine sets ctx.is_backtest=True."""
    catalog = DuckDBCatalog(tmp_path / "catalog.db")
    paper = PaperEngine(mock_adapter, initial_capital=10_000.0, is_backtest=True)

    engine = BacktestEngine(
        adapter=paper,
        config=test_config,
        start="2024-01-01",
        end="2024-01-31",
        catalog=catalog,
        data_dir=str(tmp_path),
    )

    captured_ctx = []

    async def capture_run(ctx):
        captured_ctx.append(ctx)

    engine._pipeline.run = capture_run
    engine._llm = MagicMock()
    engine._llm.validate_keys = MagicMock()

    await engine.run()  # no bars → immediate return

    # If bars were present, is_backtest would be True
    # Build context manually to verify
    ctx = engine._build_context(is_backtest=True)
    assert ctx.is_backtest is True
    catalog.close()
