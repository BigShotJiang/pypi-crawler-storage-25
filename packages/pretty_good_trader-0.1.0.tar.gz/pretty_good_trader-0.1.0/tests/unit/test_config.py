"""Tests for PGTConfig validation."""

import pytest
from pydantic import ValidationError

from pgt.core.config import PGTConfig


def test_paper_mode_no_token_ok():
    """paper=True should work without EMERGENCY_LIQUIDATE_TOKEN."""
    config = PGTConfig(paper=True)
    assert config.paper is True


def test_live_mode_requires_token():
    """paper=False without EMERGENCY_LIQUIDATE_TOKEN must raise ValueError."""
    with pytest.raises((ValueError, ValidationError)):
        PGTConfig(paper=False, emergency_liquidate_token=None)


def test_live_mode_with_token_ok():
    """paper=False with EMERGENCY_LIQUIDATE_TOKEN should succeed."""
    config = PGTConfig(paper=False, emergency_liquidate_token="my-secret-token")
    assert config.paper is False
    assert config.emergency_liquidate_token is not None


def test_defaults():
    """Check default values match spec."""
    config = PGTConfig()
    assert config.monitor_model == "xai/grok-4-1-fast"
    assert config.paper is True
    assert config.max_position_pct == 0.05
    assert config.signal_cooldown == 900
    assert config.paper_taker_fee == 0.001
