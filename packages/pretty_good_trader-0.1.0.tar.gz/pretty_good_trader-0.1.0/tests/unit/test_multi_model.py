"""Tests for MultiModelBacktestEngine and compare_models_table."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from pgt.core.config import PGTConfig
from pgt.core.engines import MultiModelBacktestEngine, compare_models_table
from pgt.models import BacktestReport, BacktestResult

# ─── Fixtures ────────────────────────────────────────────────────────────────

def _make_config() -> PGTConfig:
    return PGTConfig(paper=True)


def _make_report(seed: float = 1.0) -> BacktestReport:
    return BacktestReport(
        total_return_pct=seed * 5.0,
        sharpe=seed * 0.8,
        max_drawdown_pct=seed * 3.0,
        win_rate=0.55,
        total_trades=20,
        total_llm_cost=0.015 * seed,
    )


def _make_backtest_result() -> BacktestResult:
    return BacktestResult(
        run_id="test-run",
        start="2024-01-01",
        end="2024-12-31",
        exchange="mock",
        initial_capital=100_000.0,
        final_equity=110_000.0,
        total_trades=15,
        win_rate=0.6,
        sharpe_ratio=1.2,
        max_drawdown=0.05,
        total_pnl=10_000.0,
        total_llm_cost=0.02,
    )


# ─── MultiModelBacktestEngine.__init__ ───────────────────────────────────────

def test_init_stores_models():
    """MultiModelBacktestEngine stores the model list on init."""
    mock_adapter = MagicMock()
    config = _make_config()
    models = ["xai/grok-beta", "anthropic/claude-haiku-4-5-20251001"]

    engine = MultiModelBacktestEngine(
        adapter=mock_adapter,
        config=config,
        models=models,
    )

    assert engine._models == models
    assert engine._adapter is mock_adapter
    assert engine._config is config
    assert engine._plugins == []
    assert engine._data_dir == "data"


def test_init_custom_data_dir():
    """MultiModelBacktestEngine respects custom data_dir and plugins."""
    mock_adapter = MagicMock()
    config = _make_config()
    mock_plugin = MagicMock()

    engine = MultiModelBacktestEngine(
        adapter=mock_adapter,
        config=config,
        models=["xai/grok-beta"],
        plugins=[mock_plugin],
        data_dir="/tmp/custom",
    )

    assert engine._data_dir == "/tmp/custom"
    assert engine._plugins == [mock_plugin]


def test_init_creates_correct_number_of_models():
    """MultiModelBacktestEngine holds exactly N models."""
    mock_adapter = MagicMock()
    config = _make_config()
    models = ["model-a", "model-b", "model-c"]

    engine = MultiModelBacktestEngine(
        adapter=mock_adapter,
        config=config,
        models=models,
    )

    assert len(engine._models) == 3


# ─── compare_models_table ─────────────────────────────────────────────────────

def test_compare_models_table_runs_without_error():
    """compare_models_table prints without raising given valid mock data."""
    results = [
        ("xai/grok-beta", _make_report(1.0)),
        ("anthropic/claude-haiku-4-5-20251001", _make_report(1.5)),
        ("openai/gpt-4o-mini", _make_report(0.8)),
    ]

    with patch("rich.console.Console") as mock_console_cls:
        mock_console = MagicMock()
        mock_console_cls.return_value = mock_console
        compare_models_table(results)
        mock_console.print.assert_called_once()


def test_compare_models_table_empty_results():
    """compare_models_table handles empty results without error."""
    with patch("rich.console.Console") as mock_console_cls:
        mock_console = MagicMock()
        mock_console_cls.return_value = mock_console
        compare_models_table([])
        mock_console.print.assert_called_once()


def test_compare_models_table_single_model():
    """compare_models_table works with a single model."""
    results = [("xai/grok-beta", _make_report(1.0))]

    with patch("rich.console.Console") as mock_console_cls:
        mock_console = MagicMock()
        mock_console_cls.return_value = mock_console
        compare_models_table(results)
        mock_console.print.assert_called_once()


# ─── MultiModelBacktestEngine.run() ──────────────────────────────────────────

@pytest.mark.asyncio
async def test_run_calls_gather_with_n_tasks():
    """run() concurrently executes one BacktestEngine per model."""
    mock_adapter = MagicMock()
    config = _make_config()
    models = ["xai/grok-beta", "anthropic/claude-haiku-4-5-20251001"]

    engine = MultiModelBacktestEngine(
        adapter=mock_adapter,
        config=config,
        models=models,
    )

    mock_result = _make_backtest_result()

    with patch("pgt.core.engines.BacktestEngine") as mock_engine_cls:
        mock_instance = MagicMock()
        mock_instance.run = AsyncMock(return_value=mock_result)
        mock_engine_cls.return_value = mock_instance

        results = await engine.run(start="2024-01-01", end="2024-12-31")

    # One BacktestEngine created per model
    assert mock_engine_cls.call_count == len(models)
    # Returns one tuple per model
    assert len(results) == len(models)
    # All model names present
    returned_model_names = [name for name, _ in results]
    for m in models:
        assert m in returned_model_names


@pytest.mark.asyncio
async def test_run_returns_backtest_report_tuples():
    """run() returns list of (model_name, BacktestReport) tuples."""
    mock_adapter = MagicMock()
    config = _make_config()
    models = ["xai/grok-beta"]

    engine = MultiModelBacktestEngine(
        adapter=mock_adapter,
        config=config,
        models=models,
    )

    mock_result = _make_backtest_result()

    with patch("pgt.core.engines.BacktestEngine") as mock_engine_cls:
        mock_instance = MagicMock()
        mock_instance.run = AsyncMock(return_value=mock_result)
        mock_engine_cls.return_value = mock_instance

        results = await engine.run(start="2024-01-01", end="2024-12-31")

    assert len(results) == 1
    model_name, report = results[0]
    assert model_name == "xai/grok-beta"
    assert isinstance(report, BacktestReport)
    # Verify report is derived from BacktestResult
    assert report.total_trades == mock_result.total_trades
    assert report.total_llm_cost == mock_result.total_llm_cost


@pytest.mark.asyncio
async def test_run_handles_per_model_exception():
    """run() returns zeroed BacktestReport for a failing model, not a total failure."""
    mock_adapter = MagicMock()
    config = _make_config()
    models = ["xai/grok-beta", "bad/model"]

    engine = MultiModelBacktestEngine(
        adapter=mock_adapter,
        config=config,
        models=models,
    )

    mock_result = _make_backtest_result()

    def _make_engine(*args, **kwargs):
        instance = MagicMock()
        # First model succeeds, second raises
        if kwargs.get("config") and kwargs["config"].monitor_model == "bad/model":
            instance.run = AsyncMock(side_effect=RuntimeError("LLM API failure"))
        else:
            instance.run = AsyncMock(return_value=mock_result)
        return instance

    with patch("pgt.core.engines.BacktestEngine", side_effect=_make_engine):
        results = await engine.run(start="2024-01-01", end="2024-12-31")

    assert len(results) == 2
    result_dict = dict(results)

    # Good model has real data
    good_report = result_dict["xai/grok-beta"]
    assert good_report.total_trades == mock_result.total_trades

    # Bad model has zeroed report
    bad_report = result_dict["bad/model"]
    assert bad_report.total_return_pct == 0.0
    assert bad_report.sharpe == 0.0
    assert bad_report.total_trades == 0


@pytest.mark.asyncio
async def test_run_uses_model_config_override():
    """run() creates each engine with its own config where model fields are overridden."""
    mock_adapter = MagicMock()
    config = _make_config()
    models = ["xai/grok-beta", "anthropic/claude-haiku-4-5-20251001"]

    engine = MultiModelBacktestEngine(
        adapter=mock_adapter,
        config=config,
        models=models,
    )

    captured_configs: list[PGTConfig] = []

    def _capture_engine(*args, **kwargs):
        captured_configs.append(kwargs["config"])
        instance = MagicMock()
        instance.run = AsyncMock(return_value=_make_backtest_result())
        return instance

    with patch("pgt.core.engines.BacktestEngine", side_effect=_capture_engine):
        await engine.run(start="2024-01-01", end="2024-12-31")

    assert len(captured_configs) == 2
    for i, model_name in enumerate(models):
        assert captured_configs[i].monitor_model == model_name
        assert captured_configs[i].trader_model == model_name
