"""Tests for TelegramPlugin and DiscordPlugin fire-and-forget behaviour."""

from __future__ import annotations

import asyncio
import sys
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from pgt.models import (
    EODSummary,
    MonitorSignal,
    OrderIntent,
    OrderResult,
    OrderSide,
    OrderStatus,
    PortfolioSnapshot,
    UrgencyLevel,
)

# ---------------------------------------------------------------------------
# Shared fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def portfolio() -> PortfolioSnapshot:
    return PortfolioSnapshot(cash=10_000.0)


@pytest.fixture()
def order() -> OrderResult:
    return OrderResult(
        order_id="ord-1",
        ticker="AAPL",
        side=OrderSide.BUY,
        qty=5,
        fill_price=150.0,
        status=OrderStatus.FILLED,
    )


@pytest.fixture()
def intent() -> OrderIntent:
    return OrderIntent(ticker="AAPL", side=OrderSide.BUY, qty=5)


@pytest.fixture()
def signal() -> MonitorSignal:
    return MonitorSignal(
        signal=True,
        tickers=["AAPL", "TSLA"],
        urgency=UrgencyLevel.HIGH,
        reason="breakout detected",
    )


@pytest.fixture()
def eod_summary(portfolio: PortfolioSnapshot) -> EODSummary:
    return EODSummary(
        date="2026-04-11",
        portfolio=portfolio,
        trades_today=3,
        pnl_today=250.0,
    )


# ---------------------------------------------------------------------------
# TelegramPlugin fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=False)
def mock_telegram_bot():
    """Inject a fake python-telegram-bot module into sys.modules."""
    mock_bot = MagicMock()
    mock_bot.send_message = AsyncMock()

    mock_module = MagicMock()
    mock_module.Bot = MagicMock(return_value=mock_bot)

    mock_ext = MagicMock()

    sys.modules["telegram"] = mock_module
    sys.modules["telegram.ext"] = mock_ext

    yield mock_bot

    del sys.modules["telegram"]
    del sys.modules["telegram.ext"]


@pytest.fixture()
def telegram_plugin(mock_telegram_bot):
    # Import after sys.modules is patched
    from pgt.plugins.telegram import TelegramPlugin

    plugin = TelegramPlugin(token="fake-token", allowed_chat_id=123456)
    # Simulate post-startup state: _bot is set
    plugin._bot = mock_telegram_bot
    return plugin


# ---------------------------------------------------------------------------
# TelegramPlugin tests
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_telegram_on_order_placed_creates_task(
    telegram_plugin, order, portfolio, mock_telegram_bot
):
    """on_order_placed must fire-and-forget via create_task."""
    await telegram_plugin.on_order_placed(order, portfolio)
    await asyncio.sleep(0)  # yield to event loop so task can run
    mock_telegram_bot.send_message.assert_called_once()
    call_kwargs = mock_telegram_bot.send_message.call_args
    assert call_kwargs.kwargs["chat_id"] == 123456
    assert "AAPL" in call_kwargs.kwargs["text"]


@pytest.mark.asyncio
async def test_telegram_on_order_placed_does_not_block(
    telegram_plugin, order, portfolio, mock_telegram_bot
):
    """Calling on_order_placed must return before _send completes."""
    # Simulate a slow send
    async def slow_send(*args, **kwargs):
        await asyncio.sleep(10)  # never actually reached in test

    mock_telegram_bot.send_message = slow_send
    # Should return immediately — no TimeoutError
    await asyncio.wait_for(telegram_plugin.on_order_placed(order, portfolio), timeout=1.0)


@pytest.mark.asyncio
async def test_telegram_on_signal_detected_creates_task(
    telegram_plugin, signal, mock_telegram_bot
):
    """on_signal_detected must dispatch via create_task."""
    await telegram_plugin.on_signal_detected(signal)
    await asyncio.sleep(0)
    mock_telegram_bot.send_message.assert_called_once()
    text = mock_telegram_bot.send_message.call_args.kwargs["text"]
    assert "AAPL" in text
    assert "high" in text
    assert "breakout detected" in text


@pytest.mark.asyncio
async def test_telegram_on_error_creates_task(telegram_plugin, mock_telegram_bot):
    """on_error must fire-and-forget."""
    await telegram_plugin.on_error(ValueError("boom"), "test_context")
    await asyncio.sleep(0)
    mock_telegram_bot.send_message.assert_called_once()
    text = mock_telegram_bot.send_message.call_args.kwargs["text"]
    assert "test_context" in text
    assert "boom" in text


@pytest.mark.asyncio
async def test_telegram_on_shutdown_creates_task(telegram_plugin, mock_telegram_bot):
    """on_shutdown must fire-and-forget."""
    await telegram_plugin.on_shutdown()
    await asyncio.sleep(0)
    mock_telegram_bot.send_message.assert_called_once()
    text = mock_telegram_bot.send_message.call_args.kwargs["text"]
    assert "stopped" in text.lower() or "🔴" in text


@pytest.mark.asyncio
async def test_telegram_on_eod_summary_creates_task(
    telegram_plugin, eod_summary, mock_telegram_bot
):
    """on_eod_summary must fire-and-forget."""
    await telegram_plugin.on_eod_summary(eod_summary)
    await asyncio.sleep(0)
    mock_telegram_bot.send_message.assert_called_once()
    text = mock_telegram_bot.send_message.call_args.kwargs["text"]
    assert "250" in text  # pnl_today
    assert "3" in text    # trades_today


@pytest.mark.asyncio
async def test_telegram_send_logs_on_error(telegram_plugin, mock_telegram_bot):
    """_send must catch exceptions and log them instead of propagating."""
    mock_telegram_bot.send_message.side_effect = RuntimeError("network error")
    # Should not raise
    await telegram_plugin._send("hello")


@pytest.mark.asyncio
async def test_telegram_on_order_placed_no_bot(order, portfolio, mock_telegram_bot):
    """on_order_placed with no bot initialised must be a silent no-op."""
    from pgt.plugins.telegram import TelegramPlugin

    plugin = TelegramPlugin(token="fake-token", allowed_chat_id=123456)
    plugin._bot = None  # not started
    # Should not raise, nothing sent
    await plugin.on_order_placed(order, portfolio)
    await asyncio.sleep(0)
    mock_telegram_bot.send_message.assert_not_called()


# ---------------------------------------------------------------------------
# DiscordPlugin fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def mock_httpx():
    """Patch httpx.AsyncClient used by DiscordPlugin."""
    with patch("pgt.plugins.discord.httpx") as mock:
        mock_client = AsyncMock()
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=None)
        mock_client.post = AsyncMock()
        mock.AsyncClient = MagicMock(return_value=mock_client)
        yield mock_client


@pytest.fixture()
def discord_plugin():
    from pgt.plugins.discord import DiscordPlugin

    return DiscordPlugin(webhook_url="https://discord.example.com/webhook/1234")


# ---------------------------------------------------------------------------
# DiscordPlugin tests
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_discord_on_order_placed_creates_task(
    discord_plugin, order, portfolio, mock_httpx
):
    """on_order_placed must fire-and-forget via create_task."""
    await discord_plugin.on_order_placed(order, portfolio)
    await asyncio.sleep(0)
    mock_httpx.post.assert_called_once()
    call_kwargs = mock_httpx.post.call_args
    assert call_kwargs.kwargs["json"]["content"]
    assert "AAPL" in call_kwargs.kwargs["json"]["content"]


@pytest.mark.asyncio
async def test_discord_on_order_blocked_creates_task(
    discord_plugin, intent, mock_httpx
):
    """on_order_blocked must fire-and-forget."""
    await discord_plugin.on_order_blocked("max position exceeded", intent)
    await asyncio.sleep(0)
    mock_httpx.post.assert_called_once()
    content = mock_httpx.post.call_args.kwargs["json"]["content"]
    assert "max position exceeded" in content


@pytest.mark.asyncio
async def test_discord_on_error_creates_task(discord_plugin, mock_httpx):
    """on_error must fire-and-forget."""
    await discord_plugin.on_error(ValueError("divide by zero"), "engine")
    await asyncio.sleep(0)
    mock_httpx.post.assert_called_once()
    content = mock_httpx.post.call_args.kwargs["json"]["content"]
    assert "engine" in content
    assert "divide by zero" in content


@pytest.mark.asyncio
async def test_discord_send_posts_to_webhook_url(discord_plugin, mock_httpx):
    """_send must POST to the configured webhook URL."""
    await discord_plugin._send("hello discord")
    mock_httpx.post.assert_called_once_with(
        "https://discord.example.com/webhook/1234",
        json={"content": "hello discord"},
    )


@pytest.mark.asyncio
async def test_discord_send_logs_on_http_error(discord_plugin, mock_httpx):
    """_send must swallow HTTP errors and log them."""
    mock_httpx.post.side_effect = Exception("connection refused")
    # Should not raise
    await discord_plugin._send("test message")


@pytest.mark.asyncio
async def test_discord_on_order_placed_does_not_block(
    discord_plugin, order, portfolio, mock_httpx
):
    """on_order_placed must return immediately (fire-and-forget)."""
    async def slow_post(*args, **kwargs):
        await asyncio.sleep(10)

    mock_httpx.post = slow_post
    await asyncio.wait_for(
        discord_plugin.on_order_placed(order, portfolio), timeout=1.0
    )
