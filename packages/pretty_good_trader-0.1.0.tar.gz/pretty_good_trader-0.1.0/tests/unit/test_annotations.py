"""Tests for AnnotationMemory."""

from __future__ import annotations

import json

from pgt.memory.annotations import AnnotationMemory


def test_add_stores_annotation(tmp_path):
    """add() writes an annotation entry to the JSONL file."""
    storage = tmp_path / "annotations.jsonl"
    mem = AnnotationMemory(storage_path=storage)

    mem.add(cycle_id=1, text="Great signal!")

    assert storage.exists()
    lines = storage.read_text().splitlines()
    assert len(lines) == 1
    entry = json.loads(lines[0])
    assert entry["cycle_id"] == 1
    assert entry["text"] == "Great signal!"
    assert "timestamp" in entry


def test_add_multiple_annotations(tmp_path):
    """add() appends multiple annotations without overwriting."""
    storage = tmp_path / "annotations.jsonl"
    mem = AnnotationMemory(storage_path=storage)

    mem.add(cycle_id=5, text="First note")
    mem.add(cycle_id=5, text="Second note")
    mem.add(cycle_id=7, text="Other cycle")

    lines = storage.read_text().splitlines()
    assert len(lines) == 3


def test_get_returns_annotations_for_cycle(tmp_path):
    """get() returns only annotations matching the given cycle_id."""
    storage = tmp_path / "annotations.jsonl"
    mem = AnnotationMemory(storage_path=storage)

    mem.add(cycle_id=10, text="Note A")
    mem.add(cycle_id=11, text="Different cycle")
    mem.add(cycle_id=10, text="Note B")

    result = mem.get(cycle_id=10)
    assert result == ["Note A", "Note B"]


def test_get_returns_empty_list_for_unknown_cycle(tmp_path):
    """get() returns an empty list when no annotations exist for a cycle."""
    storage = tmp_path / "annotations.jsonl"
    mem = AnnotationMemory(storage_path=storage)

    mem.add(cycle_id=1, text="Some note")

    assert mem.get(cycle_id=999) == []


def test_get_returns_empty_list_when_file_missing(tmp_path):
    """get() returns an empty list when the JSONL file does not exist yet."""
    storage = tmp_path / "missing.jsonl"
    mem = AnnotationMemory(storage_path=storage)

    assert mem.get(cycle_id=1) == []


def test_inject_context_returns_formatted_string(tmp_path):
    """inject_context() returns a properly formatted multi-line string."""
    storage = tmp_path / "annotations.jsonl"
    mem = AnnotationMemory(storage_path=storage)

    mem.add(cycle_id=42, text="Strong buy signal")
    mem.add(cycle_id=42, text="RSI oversold")

    result = mem.inject_context(cycle_id=42)
    assert result.startswith("User annotations for cycle 42:")
    assert "- Strong buy signal" in result
    assert "- RSI oversold" in result
    assert result.endswith("\n")


def test_inject_context_returns_empty_string_for_no_annotations(tmp_path):
    """inject_context() returns an empty string when there are no annotations."""
    storage = tmp_path / "annotations.jsonl"
    mem = AnnotationMemory(storage_path=storage)

    assert mem.inject_context(cycle_id=99) == ""


def test_all_returns_all_annotations(tmp_path):
    """all() returns all annotation dicts regardless of cycle_id."""
    storage = tmp_path / "annotations.jsonl"
    mem = AnnotationMemory(storage_path=storage)

    mem.add(cycle_id=1, text="Alpha")
    mem.add(cycle_id=2, text="Beta")
    mem.add(cycle_id=3, text="Gamma")

    results = mem.all()
    assert len(results) == 3
    texts = [r["text"] for r in results]
    assert texts == ["Alpha", "Beta", "Gamma"]


def test_all_returns_empty_list_when_no_file(tmp_path):
    """all() returns an empty list when no JSONL file exists."""
    storage = tmp_path / "no_file.jsonl"
    mem = AnnotationMemory(storage_path=storage)

    assert mem.all() == []


def test_all_entries_have_required_keys(tmp_path):
    """Each entry from all() has cycle_id, text, and timestamp keys."""
    storage = tmp_path / "annotations.jsonl"
    mem = AnnotationMemory(storage_path=storage)

    mem.add(cycle_id=7, text="Check this")

    entries = mem.all()
    assert len(entries) == 1
    entry = entries[0]
    assert "cycle_id" in entry
    assert "text" in entry
    assert "timestamp" in entry


def test_storage_path_parent_created_automatically(tmp_path):
    """AnnotationMemory creates parent directories as needed."""
    storage = tmp_path / "nested" / "deep" / "annotations.jsonl"
    mem = AnnotationMemory(storage_path=storage)
    mem.add(cycle_id=1, text="Deep path")

    assert storage.exists()
