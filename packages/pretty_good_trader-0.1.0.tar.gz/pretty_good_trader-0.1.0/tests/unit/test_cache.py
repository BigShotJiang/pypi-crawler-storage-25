"""Tests for DiskCache."""

import time

from pgt.memory.cache import DiskCache


def test_set_and_get(tmp_path):
    cache = DiskCache(tmp_path / "cache")
    cache.set("key1", {"data": 42}, ttl=300)
    result = cache.get("key1")
    assert result == {"data": 42}


def test_get_missing_returns_none(tmp_path):
    cache = DiskCache(tmp_path / "cache")
    assert cache.get("nonexistent") is None


def test_ttl_expiry(tmp_path):
    cache = DiskCache(tmp_path / "cache")
    cache.set("expiring", "value", ttl=0)
    # TTL=0 should expire immediately
    time.sleep(0.01)
    assert cache.get("expiring") is None


def test_delete(tmp_path):
    cache = DiskCache(tmp_path / "cache")
    cache.set("key", "value", ttl=300)
    cache.delete("key")
    assert cache.get("key") is None


def test_clear(tmp_path):
    cache = DiskCache(tmp_path / "cache")
    cache.set("k1", "v1", ttl=300)
    cache.set("k2", "v2", ttl=300)
    cache.clear()
    assert cache.get("k1") is None
    assert cache.get("k2") is None


def test_key_with_special_chars(tmp_path):
    cache = DiskCache(tmp_path / "cache")
    cache.set("key/with:special", [1, 2, 3], ttl=300)
    result = cache.get("key/with:special")
    assert result == [1, 2, 3]
