"""Tests for Scheduler."""

from __future__ import annotations

import asyncio
from datetime import UTC, datetime

import pytest

from pgt.core.clock import SimClock
from pgt.core.scheduler import Scheduler


@pytest.mark.asyncio
async def test_scheduler_fires_cycle(tmp_path):
    """Scheduler calls cycle_fn on each interval."""
    clock = SimClock(start=datetime(2024, 6, 3, 10, 0, tzinfo=UTC))  # Monday 10am ET

    calls = []

    async def cycle_fn():
        calls.append(1)
        if len(calls) >= 3:
            scheduler.stop()

    scheduler = Scheduler(
        clock=clock,
        interval=1,  # 1 second interval
        market_hours=False,  # disable market hours gating for test
    )

    await asyncio.wait_for(
        scheduler.run(cycle_fn),
        timeout=2.0,
    )
    assert len(calls) == 3


@pytest.mark.asyncio
async def test_scheduler_stop():
    """scheduler.stop() causes run() to exit."""
    clock = SimClock()
    scheduler = Scheduler(clock=clock, interval=1, market_hours=False)

    async def immediate_stop():
        scheduler.stop()

    await asyncio.wait_for(
        scheduler.run(immediate_stop),
        timeout=1.0,
    )


def test_is_trading_hours_weekday():
    clock = SimClock()
    scheduler = Scheduler(clock=clock, interval=180)
    # Monday 10am ET
    dt = datetime(2024, 6, 3, 14, 0, tzinfo=UTC)  # 10am ET = 14:00 UTC
    assert scheduler._is_trading_hours(dt) is True


def test_is_trading_hours_weekend():
    clock = SimClock()
    scheduler = Scheduler(clock=clock, interval=180)
    # Saturday
    dt = datetime(2024, 6, 8, 14, 0, tzinfo=UTC)
    assert scheduler._is_trading_hours(dt) is False


def test_is_trading_hours_after_close():
    clock = SimClock()
    scheduler = Scheduler(clock=clock, interval=180, market_close="16:00")
    # Monday 4:30pm ET = 20:30 UTC
    dt = datetime(2024, 6, 3, 20, 30, tzinfo=UTC)
    assert scheduler._is_trading_hours(dt) is False


def test_no_market_hours_always_trading():
    clock = SimClock()
    scheduler = Scheduler(clock=clock, interval=180, market_hours=False)
    # Saturday midnight — but market_hours=False (24/7 exchange)
    dt = datetime(2024, 6, 8, 0, 0, tzinfo=UTC)
    assert scheduler._is_trading_hours(dt) is True
