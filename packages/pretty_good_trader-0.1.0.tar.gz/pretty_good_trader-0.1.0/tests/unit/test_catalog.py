"""Tests for DuckDBCatalog."""

from __future__ import annotations

from datetime import UTC, datetime

import pytest

from pgt.data.catalog import DuckDBCatalog


@pytest.fixture
def catalog(tmp_path):
    cat = DuckDBCatalog(tmp_path / "catalog.db")
    yield cat
    cat.close()


def _insert_bars(catalog: DuckDBCatalog, n: int = 3) -> list[datetime]:
    timestamps = []
    for i in range(n):
        ts = datetime(2024, 1, i + 1, 10, 0, tzinfo=UTC)
        catalog._conn.execute(
            "INSERT INTO ohlcv VALUES (?, 'NVDA', 100, 105, 98, 102+?, 1000000)",
            [ts, i],
        )
        timestamps.append(ts)
    catalog._conn.commit()
    return timestamps


def test_load_range_returns_dict(catalog):
    _insert_bars(catalog, 3)
    bars = catalog.load_range("2024-01-01", "2024-01-31")
    assert isinstance(bars, dict)
    assert len(bars) == 3


def test_load_range_filters_by_ticker(catalog):
    _insert_bars(catalog, 3)
    # Also insert AAPL
    catalog._conn.execute(
        "INSERT INTO ohlcv VALUES ('2024-01-01 10:00:00', 'AAPL', 100, 105, 98, 200, 500000)"
    )
    catalog._conn.commit()
    bars = catalog.load_range("2024-01-01", "2024-01-31", tickers=["NVDA"])
    for prices in bars.values():
        assert "AAPL" not in prices


def test_load_range_empty_range(catalog):
    _insert_bars(catalog, 3)
    bars = catalog.load_range("2023-01-01", "2023-12-31")
    assert bars == {}


def test_checkpoint_save_and_load(catalog):
    catalog.save_checkpoint("run-1", 0, "2024-01-01T10:00:00", 10500.0, 9500.0)
    checkpoint = catalog.load_checkpoint("run-1")
    assert checkpoint is not None
    assert checkpoint["equity"] == 10500.0
    assert checkpoint["bar_index"] == 0


def test_checkpoint_returns_latest(catalog):
    catalog.save_checkpoint("run-1", 0, "2024-01-01", 10000.0, 9000.0)
    catalog.save_checkpoint("run-1", 5, "2024-01-05", 10500.0, 9500.0)
    checkpoint = catalog.load_checkpoint("run-1")
    assert checkpoint["bar_index"] == 5


def test_load_checkpoint_missing_run(catalog):
    result = catalog.load_checkpoint("nonexistent-run")
    assert result is None
