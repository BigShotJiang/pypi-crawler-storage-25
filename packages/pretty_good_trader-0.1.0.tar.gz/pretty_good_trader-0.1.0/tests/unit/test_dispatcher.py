"""Tests for ToolDispatcher."""

from __future__ import annotations

from unittest.mock import AsyncMock, patch

import pytest

from pgt.ai.dispatcher import ToolDispatcher, ToolLimitExceededError


@pytest.mark.asyncio
async def test_max_tool_calls_exceeded(run_context):
    """ToolLimitExceededError raised after MAX_TOOL_CALLS."""
    dispatcher = ToolDispatcher(run_context, max_tool_calls=1)
    # First call consumes the limit
    await dispatcher.dispatch("get_portfolio", {})
    # Second call should raise
    with pytest.raises(ToolLimitExceededError):
        await dispatcher.dispatch("get_portfolio", {})


@pytest.mark.asyncio
async def test_logger_suspended_blocks_place_order(run_context):
    """place_order must be blocked when logger.is_suspended=True."""
    run_context.logger._suspended = True

    dispatcher = ToolDispatcher(run_context, max_tool_calls=10)
    result = await dispatcher.dispatch("place_order", {
        "ticker": "NVDA", "side": "buy", "qty": 1.0
    })
    assert "BLOCKED" in result.content
    assert "logger failure" in result.content


@pytest.mark.asyncio
async def test_backtest_disables_search_web(run_context):
    """search_web disabled in backtest mode."""
    run_context.is_backtest = True
    dispatcher = ToolDispatcher(run_context, max_tool_calls=10)
    result = await dispatcher.dispatch("search_web", {"query": "NVDA earnings"})
    assert "disabled in backtest mode" in result.content


@pytest.mark.asyncio
async def test_backtest_disables_get_fundamentals(run_context):
    """get_fundamentals disabled in backtest mode."""
    run_context.is_backtest = True
    dispatcher = ToolDispatcher(run_context, max_tool_calls=10)
    result = await dispatcher.dispatch("get_fundamentals", {"ticker": "NVDA"})
    assert "disabled in backtest mode" in result.content


@pytest.mark.asyncio
async def test_invalid_ticker_format(run_context):
    """Invalid ticker format returns error."""
    dispatcher = ToolDispatcher(run_context, max_tool_calls=10)
    result = await dispatcher.dispatch("place_order", {
        "ticker": "nvda-123!", "side": "buy", "qty": 1.0
    })
    assert result.error is not None
    assert "Invalid ticker" in result.error


@pytest.mark.asyncio
async def test_get_tradeable_none_skips_check(run_context):
    """get_tradeable_tickers() returning None → skip tradeable check."""
    run_context.adapter._mock_tradeable = None  # MockBrokerAdapter returns None by default
    dispatcher = ToolDispatcher(run_context, max_tool_calls=10)
    result = await dispatcher.dispatch("place_order", {
        "ticker": "NVDA", "side": "buy", "qty": 1.0
    })
    # Should not fail with "not tradeable" error
    assert "not tradeable" not in (result.error or "")


@pytest.mark.asyncio
async def test_get_tradeable_raises_blocks_order(run_context):
    """get_tradeable_tickers() raising BrokerError → block order."""
    from pgt.adapters.base import BrokerError

    run_context.adapter.get_tradeable_tickers = AsyncMock(
        side_effect=BrokerError("probe failed")
    )
    dispatcher = ToolDispatcher(run_context, max_tool_calls=10)
    result = await dispatcher.dispatch("place_order", {
        "ticker": "NVDA", "side": "buy", "qty": 1.0
    })
    assert result.error is not None
    assert "Tradeable check failed" in result.error


@pytest.mark.asyncio
async def test_search_web_wraps_in_search_result_tags(run_context):
    """search_web output must be wrapped in <search_result> tags (injection defense)."""
    from pgt.data.search import SearchClient

    with patch.object(SearchClient, "search", AsyncMock(
        return_value="<search_result>NVDA news here</search_result>"
    )):
        dispatcher = ToolDispatcher(run_context, max_tool_calls=10)
        result = await dispatcher.dispatch("search_web", {"query": "NVDA earnings"})
        assert "<search_result>" in result.content


@pytest.mark.asyncio
async def test_unknown_tool_returns_error(run_context):
    dispatcher = ToolDispatcher(run_context, max_tool_calls=10)
    result = await dispatcher.dispatch("nonexistent_tool", {})
    assert result.error is not None
    assert "Unknown tool" in result.error
