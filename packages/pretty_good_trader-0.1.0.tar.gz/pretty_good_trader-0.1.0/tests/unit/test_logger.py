"""Tests for SQLite logger with JSONL fallback."""

from __future__ import annotations

from pgt.logger import Logger


def test_log_cycle_success(tmp_path):
    logger = Logger(data_dir=tmp_path)
    cycle_id = logger.log_cycle(
        cycle_type="monitor",
        model="xai/grok-4-1-fast",
        trace_id="test-trace",
        api_cost=0.002,
        latency_ms=350,
    )
    assert cycle_id is not None
    assert cycle_id > 0


def test_get_cycle_by_id(tmp_path):
    logger = Logger(data_dir=tmp_path)
    cycle_id = logger.log_cycle(cycle_type="monitor", model="test")
    row = logger.get_cycle(cycle_id)
    assert row is not None
    assert row["cycle_type"] == "monitor"


def test_get_recent_cycles(tmp_path):
    logger = Logger(data_dir=tmp_path)
    for i in range(5):
        logger.log_cycle(cycle_type="monitor", model=f"model-{i}")
    rows = logger.get_recent_cycles(limit=3)
    assert len(rows) == 3


def test_sqlite_fail_falls_back_to_jsonl(tmp_path, monkeypatch):
    """SQLite failure → JSONL fallback, not suspended."""
    logger = Logger(data_dir=tmp_path)
    logger._sqlite_ok = False  # Force SQLite to appear broken

    logger.log_cycle(cycle_type="monitor", model="test")

    today = __import__("datetime").datetime.now().strftime("%Y-%m-%d")
    jsonl_path = tmp_path / f"fallback_{today}.jsonl"
    assert jsonl_path.exists()
    assert not logger.is_suspended


def test_dual_failure_suspends(tmp_path, monkeypatch):
    """JSONL failure after SQLite failure → is_suspended=True."""
    logger = Logger(data_dir=tmp_path)
    logger._sqlite_ok = False

    # Make JSONL write fail by monkeypatching open
    import builtins
    original_open = builtins.open

    def failing_open(path, *args, **kwargs):
        if "fallback" in str(path):
            raise OSError("disk full")
        return original_open(path, *args, **kwargs)

    monkeypatch.setattr(builtins, "open", failing_open)
    logger.log_cycle(cycle_type="monitor", model="test")
    assert logger.is_suspended


def test_log_tool_call(tmp_path):
    logger = Logger(data_dir=tmp_path)
    cycle_id = logger.log_cycle(cycle_type="monitor", model="test")
    logger.log_tool_call(
        cycle_id=cycle_id,
        tool_name="search_web",
        arguments={"query": "NVDA earnings"},
        result={"content": "results..."},
        latency_ms=120,
    )
    # No exception = pass
