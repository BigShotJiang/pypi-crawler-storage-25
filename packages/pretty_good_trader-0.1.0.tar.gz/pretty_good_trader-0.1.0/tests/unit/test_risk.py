"""Tests for all 7 risk checks."""

from __future__ import annotations

from pgt.memory.session import SessionMemory
from pgt.models import OrderIntent, OrderSide, PortfolioSnapshot, Position
from pgt.risk.checks import (
    DuplicateOrderCheck,
    MaxDailyDrawdownCheck,
    MaxOpenPositionsCheck,
    MaxPositionSizeCheck,
    MinCashReserveCheck,
    NegativeQtyCheck,
    TickerAllowlistCheck,
)
from pgt.risk.engine import RiskEngine


def make_portfolio(cash: float = 9000.0, positions: dict | None = None) -> PortfolioSnapshot:
    pos = {}
    if positions:
        for ticker, (qty, price) in positions.items():
            pos[ticker] = Position(ticker=ticker, qty=qty, avg_cost=price, current_price=price)
    return PortfolioSnapshot(cash=cash, positions=pos)


def buy(ticker: str = "NVDA", qty: float = 1.0) -> OrderIntent:
    return OrderIntent(ticker=ticker, side=OrderSide.BUY, qty=qty)


def sell(ticker: str = "NVDA", qty: float = 1.0) -> OrderIntent:
    return OrderIntent(ticker=ticker, side=OrderSide.SELL, qty=qty)


# ─── NegativeQtyCheck ────────────────────────────────────────────────────────

def test_negative_qty_blocked():
    check = NegativeQtyCheck()
    assert not check.check(buy("NVDA", qty=0.0), make_portfolio()).allowed
    assert not check.check(buy("NVDA", qty=-1.0), make_portfolio()).allowed


def test_positive_qty_ok():
    check = NegativeQtyCheck()
    assert check.check(buy("NVDA", qty=1.0), make_portfolio()).allowed


# ─── MaxPositionSizeCheck ────────────────────────────────────────────────────

def test_max_position_blocked():
    # Already at 6% of portfolio → exceed 5% limit
    check = MaxPositionSizeCheck(pct_of_portfolio=0.05)
    portfolio = make_portfolio(cash=9400.0, positions={"NVDA": (1.2, 500.0)})
    # NVDA: 1.2 × 500 = 600; equity = 9400 + 600 = 10000; 600/10000 = 6%
    result = check.check(buy("NVDA"), portfolio)
    assert not result.allowed


def test_max_position_ok():
    check = MaxPositionSizeCheck(pct_of_portfolio=0.05)
    portfolio = make_portfolio(cash=9800.0)  # no positions → 0% → ok
    assert check.check(buy("NVDA"), portfolio).allowed


# ─── MaxDailyDrawdownCheck ───────────────────────────────────────────────────

def test_drawdown_blocked():
    check = MaxDailyDrawdownCheck(pct=0.05, initial_equity=10_000.0)
    # Current equity = 9400 → drawdown = 6%
    portfolio = make_portfolio(cash=9400.0)
    result = check.check(buy("NVDA"), portfolio)
    assert not result.allowed


def test_drawdown_ok():
    check = MaxDailyDrawdownCheck(pct=0.05, initial_equity=10_000.0)
    portfolio = make_portfolio(cash=9600.0)  # drawdown = 4% → ok
    assert check.check(buy("NVDA"), portfolio).allowed


def test_drawdown_sell_always_ok():
    check = MaxDailyDrawdownCheck(pct=0.05, initial_equity=10_000.0)
    portfolio = make_portfolio(cash=9000.0)
    assert check.check(sell("NVDA"), portfolio).allowed  # sells not blocked


# ─── MaxOpenPositionsCheck ───────────────────────────────────────────────────

def test_max_positions_blocked():
    check = MaxOpenPositionsCheck(n=2)
    portfolio = make_portfolio(
        cash=8000.0,
        positions={"NVDA": (1.0, 500.0), "AAPL": (2.0, 200.0)},
    )
    assert not check.check(buy("TSLA"), portfolio).allowed


def test_max_positions_ok():
    check = MaxOpenPositionsCheck(n=3)
    portfolio = make_portfolio(cash=9000.0, positions={"NVDA": (1.0, 500.0)})
    assert check.check(buy("AAPL"), portfolio).allowed


# ─── MinCashReserveCheck ─────────────────────────────────────────────────────

def test_min_cash_blocked():
    check = MinCashReserveCheck(pct=0.10)
    # cash = 900, equity = 10000 → 9% < 10%
    portfolio = make_portfolio(cash=900.0, positions={"NVDA": (18.2, 500.0)})
    assert not check.check(buy("AAPL"), portfolio).allowed


def test_min_cash_ok():
    check = MinCashReserveCheck(pct=0.10)
    portfolio = make_portfolio(cash=1100.0, positions={"NVDA": (17.8, 500.0)})
    # equity ≈ 10000, cash/equity = 11% > 10%
    assert check.check(buy("AAPL"), portfolio).allowed


# ─── DuplicateOrderCheck ────────────────────────────────────────────────────

def test_duplicate_blocked(tmp_path):
    session = SessionMemory(storage_path=tmp_path / "s.json", cooldown_seconds=900)
    check = DuplicateOrderCheck(session=session, window_seconds=60)
    portfolio = make_portfolio()

    session.record_order("NVDA", OrderSide.BUY)
    result = check.check(buy("NVDA"), portfolio)
    assert not result.allowed


def test_duplicate_different_side_ok(tmp_path):
    session = SessionMemory(storage_path=tmp_path / "s.json", cooldown_seconds=900)
    check = DuplicateOrderCheck(session=session, window_seconds=60)
    portfolio = make_portfolio()

    session.record_order("NVDA", OrderSide.BUY)
    result = check.check(sell("NVDA"), portfolio)
    assert result.allowed  # buy ≠ sell → not duplicate


def test_duplicate_survives_restart(tmp_path):
    """DuplicateOrderCheck blocks on restart if recent_orders still within TTL."""
    storage = tmp_path / "session.json"
    session1 = SessionMemory(storage_path=storage, cooldown_seconds=900)
    session1.record_order("NVDA", OrderSide.BUY)

    # Simulate restart — load same file
    session2 = SessionMemory(storage_path=storage, cooldown_seconds=900)
    check = DuplicateOrderCheck(session=session2, window_seconds=60)
    result = check.check(buy("NVDA"), make_portfolio())
    assert not result.allowed


# ─── TickerAllowlistCheck ────────────────────────────────────────────────────

def test_allowlist_blocked():
    check = TickerAllowlistCheck(allowlist=["AAPL", "MSFT"])
    assert not check.check(buy("NVDA"), make_portfolio()).allowed


def test_allowlist_ok():
    check = TickerAllowlistCheck(allowlist=["AAPL", "NVDA"])
    assert check.check(buy("NVDA"), make_portfolio()).allowed


def test_allowlist_empty_allows_all():
    check = TickerAllowlistCheck(allowlist=None)
    assert check.check(buy("ANYTHING"), make_portfolio()).allowed


# ─── RiskEngine integration ─────────────────────────────────────────────────

def test_risk_engine_passes_clean(tmp_path):
    engine = RiskEngine(
        checks=[NegativeQtyCheck(), MinCashReserveCheck(0.10)],
        initial_equity=10_000.0,
    )
    portfolio = make_portfolio(cash=9000.0)
    result = engine.check(buy("NVDA", qty=1.0), portfolio)
    assert result.allowed


def test_risk_engine_blocks_on_first_fail(tmp_path):
    engine = RiskEngine(
        checks=[NegativeQtyCheck(), MaxOpenPositionsCheck(n=0)],
    )
    portfolio = make_portfolio()
    result = engine.check(buy("NVDA", qty=1.0), portfolio)
    assert not result.allowed
    assert "MaxOpenPositionsCheck" in result.check_name
