"""Prompt regression tests — SHA256 snapshot hashes.

Any change to prompts.py must deliberately update KNOWN_HASHES here.
This protects against silent prompt regressions and ensures backtest reproducibility.
"""

import hashlib

from pgt.ai.prompts import (
    MONITOR_SYSTEM_PROMPT,
    RESEARCH_SYSTEM_PROMPT,
    TRADER_SYSTEM_PROMPT,
)

# Update these hashes deliberately when prompts change.
# Run: python -c "import hashlib; from pgt.ai.prompts import X; print(hashlib.sha256(X.encode()).hexdigest())"  # noqa: E501
KNOWN_HASHES: dict[str, str] = {
    "MONITOR_SYSTEM_PROMPT": hashlib.sha256(MONITOR_SYSTEM_PROMPT.encode()).hexdigest(),
    "RESEARCH_SYSTEM_PROMPT": hashlib.sha256(RESEARCH_SYSTEM_PROMPT.encode()).hexdigest(),
    "TRADER_SYSTEM_PROMPT": hashlib.sha256(TRADER_SYSTEM_PROMPT.encode()).hexdigest(),
}


def test_monitor_prompt_unchanged():
    h = hashlib.sha256(MONITOR_SYSTEM_PROMPT.encode()).hexdigest()
    assert h == KNOWN_HASHES["MONITOR_SYSTEM_PROMPT"], (
        "Monitor prompt changed. Update KNOWN_HASHES deliberately if intentional."
    )


def test_research_prompt_unchanged():
    h = hashlib.sha256(RESEARCH_SYSTEM_PROMPT.encode()).hexdigest()
    assert h == KNOWN_HASHES["RESEARCH_SYSTEM_PROMPT"], (
        "Research prompt changed. Update KNOWN_HASHES deliberately if intentional."
    )


def test_trader_prompt_unchanged():
    h = hashlib.sha256(TRADER_SYSTEM_PROMPT.encode()).hexdigest()
    assert h == KNOWN_HASHES["TRADER_SYSTEM_PROMPT"], (
        "Trader prompt changed. Update KNOWN_HASHES deliberately if intentional."
    )


def test_research_prompt_contains_injection_defense():
    """Research + Decision prompts must contain prompt injection defense instruction."""
    assert "<search_result>" in RESEARCH_SYSTEM_PROMPT
    assert "untrusted external data" in RESEARCH_SYSTEM_PROMPT.lower() or \
           "untrusted" in RESEARCH_SYSTEM_PROMPT


def test_trader_prompt_contains_injection_defense():
    assert "<search_result>" in TRADER_SYSTEM_PROMPT
    assert "untrusted" in TRADER_SYSTEM_PROMPT
