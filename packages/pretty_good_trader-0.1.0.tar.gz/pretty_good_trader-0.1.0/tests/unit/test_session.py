"""Tests for SessionMemory."""

from __future__ import annotations

import time

from pgt.memory.session import SessionMemory
from pgt.models import OrderSide


def test_set_and_check_cooldown(tmp_path):
    session = SessionMemory(tmp_path / "s.json", cooldown_seconds=10)
    session.set_cooldown("NVDA")
    assert session.is_on_cooldown("NVDA") is True


def test_cooldown_expires(tmp_path):
    session = SessionMemory(tmp_path / "s.json", cooldown_seconds=0)
    session.set_cooldown("NVDA")
    time.sleep(0.01)
    # TTL=0 → immediately expired
    assert session.is_on_cooldown("NVDA") is False


def test_no_cooldown_by_default(tmp_path):
    session = SessionMemory(tmp_path / "s.json", cooldown_seconds=900)
    assert session.is_on_cooldown("NVDA") is False


def test_record_and_get_recent_orders(tmp_path):
    session = SessionMemory(tmp_path / "s.json", cooldown_seconds=900)
    session.record_order("NVDA", OrderSide.BUY)
    recent = session.get_recent_orders(window_seconds=60)
    assert len(recent) == 1
    assert recent[0].ticker == "NVDA"


def test_recent_orders_window_filter(tmp_path):
    session = SessionMemory(tmp_path / "s.json", cooldown_seconds=900)
    session.record_order("NVDA", OrderSide.BUY)
    # Window of 0 seconds → nothing
    recent = session.get_recent_orders(window_seconds=0)
    assert len(recent) == 0


def test_persistence_round_trip(tmp_path):
    path = tmp_path / "session.json"
    s1 = SessionMemory(path, cooldown_seconds=900)
    s1.set_cooldown("AAPL")
    s1.record_order("NVDA", OrderSide.BUY)

    s2 = SessionMemory(path, cooldown_seconds=900)
    assert s2.is_on_cooldown("AAPL")
    assert len(s2.recent_orders) == 1
