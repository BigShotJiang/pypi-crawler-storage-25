"""Tests for _highlight_term helper in pgt.cli."""

from pgt.cli import _highlight_term


def test_highlight_single_occurrence():
    result = _highlight_term("buy AAPL today", "aapl")
    assert "[yellow bold]AAPL[/yellow bold]" in result


def test_highlight_no_match():
    result = _highlight_term("no match here", "xyz")
    assert result == "no match here"


def test_highlight_multiple_occurrences():
    result = _highlight_term("AAPL is up, buy AAPL now", "aapl")
    assert result.count("[yellow bold]AAPL[/yellow bold]") == 2


def test_highlight_case_insensitive_preserves_original_case():
    result = _highlight_term("AaPl is volatile", "aapl")
    assert "[yellow bold]AaPl[/yellow bold]" in result


def test_highlight_empty_term_returns_unchanged():
    text = "some text"
    assert _highlight_term(text, "") == text
