"""Tests for PGTLLMClient."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from pgt.ai.client import PGTLLMClient, PGTLLMError
from pgt.core.config import PGTConfig
from pgt.models import LLMResponse


def make_config(**kwargs) -> PGTConfig:
    return PGTConfig(paper=True, **kwargs)


def test_validate_keys_xai_missing():
    config = make_config(monitor_model="xai/grok-4-1-fast", xai_api_key=None)
    client = PGTLLMClient(config)
    with pytest.raises(PGTLLMError, match="XAI_API_KEY"):
        client.validate_keys()


def test_validate_keys_anthropic_missing():
    config = make_config(monitor_model="anthropic/claude-haiku-4-5", anthropic_api_key=None)
    client = PGTLLMClient(config)
    with pytest.raises(PGTLLMError, match="ANTHROPIC_API_KEY"):
        client.validate_keys()


def test_validate_keys_all_ok():
    config = make_config(
        monitor_model="xai/grok-4-1-fast",
        xai_api_key="sk-test",
    )
    client = PGTLLMClient(config)
    client.validate_keys()  # should not raise


@pytest.mark.asyncio
async def test_call_returns_llm_response():
    """Mock litellm.acompletion → LLMResponse."""
    config = make_config(xai_api_key="sk-test")
    client = PGTLLMClient(config)

    mock_choice = MagicMock()
    mock_choice.message.content = "Hello from LLM"
    mock_choice.message.tool_calls = None

    mock_response = MagicMock()
    mock_response.choices = [mock_choice]
    mock_response.model = "xai/grok-4-1-fast"
    mock_response.usage.prompt_tokens = 100
    mock_response.usage.completion_tokens = 50

    with patch("litellm.acompletion", AsyncMock(return_value=mock_response)):
        with patch("litellm.completion_cost", return_value=0.002):
            result = await client.call(
                model="xai/grok-4-1-fast",
                system_prompt="You are helpful",
                messages=[{"role": "user", "content": "hello"}],
            )

    assert isinstance(result, LLMResponse)
    assert result.content == "Hello from LLM"
    assert result.input_tokens == 100
    assert result.output_tokens == 50


@pytest.mark.asyncio
async def test_call_retries_on_rate_limit():
    """429 rate limit → 3 retries → PGTLLMError."""
    import litellm

    config = make_config(xai_api_key="sk-test")
    client = PGTLLMClient(config)

    rate_err = litellm.exceptions.RateLimitError("rate limited", llm_provider="xai", model="grok")
    with patch("litellm.acompletion", AsyncMock(side_effect=rate_err)):
        with patch("asyncio.sleep", AsyncMock()):
            with pytest.raises(PGTLLMError, match="exhausted"):
                await client.call(
                    model="xai/grok-4-1-fast",
                    system_prompt="test",
                    messages=[],
                )


@pytest.mark.asyncio
async def test_call_raises_on_unknown_error():
    """Non-retriable errors are wrapped in PGTLLMError immediately."""
    config = make_config(xai_api_key="sk-test")
    client = PGTLLMClient(config)

    with patch("litellm.acompletion", AsyncMock(side_effect=ValueError("bad param"))):
        with pytest.raises(PGTLLMError):
            await client.call(
                model="xai/grok-4-1-fast",
                system_prompt="test",
                messages=[],
            )
