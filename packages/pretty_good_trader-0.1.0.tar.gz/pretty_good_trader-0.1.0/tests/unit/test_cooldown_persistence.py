"""Unit tests: SessionMemory cooldown persistence to disk."""

from __future__ import annotations

import json
import time

from pgt.memory.session import SessionMemory


def test_cooldown_persists_to_disk(tmp_path):
    """set_cooldown writes to JSON; reload from disk shows cooldown active."""
    path = tmp_path / "session.json"
    mem = SessionMemory(path, cooldown_seconds=900)
    mem.set_cooldown("NVDA")

    # Reload from disk
    mem2 = SessionMemory(path, cooldown_seconds=900)
    assert mem2.is_on_cooldown("NVDA")


def test_cooldown_expires_after_ttl(tmp_path):
    """Expired cooldowns are filtered out on load."""
    path = tmp_path / "session.json"
    # Write a cooldown that is already expired (1000 seconds ago)
    expired_ts = time.time() - 1000
    path.write_text(
        json.dumps(
            {
                "cooldown_timestamps": {"BTC": expired_ts},
                "recent_orders": [],
            }
        )
    )

    mem = SessionMemory(path, cooldown_seconds=900)
    assert not mem.is_on_cooldown("BTC")


def test_cooldown_not_active_before_set(tmp_path):
    """is_on_cooldown returns False for unknown tickers."""
    path = tmp_path / "session.json"
    mem = SessionMemory(path, cooldown_seconds=900)
    assert not mem.is_on_cooldown("TSLA")


def test_multiple_tickers_cooldown(tmp_path):
    """Multiple tickers can be on cooldown independently."""
    path = tmp_path / "session.json"
    mem = SessionMemory(path, cooldown_seconds=900)
    mem.set_cooldown("NVDA")
    mem.set_cooldown("AAPL")

    mem2 = SessionMemory(path, cooldown_seconds=900)
    assert mem2.is_on_cooldown("NVDA")
    assert mem2.is_on_cooldown("AAPL")
    assert not mem2.is_on_cooldown("TSLA")


def test_cooldown_round_trip_json(tmp_path):
    """The JSON file contains the expected structure after set_cooldown."""
    path = tmp_path / "session.json"
    mem = SessionMemory(path, cooldown_seconds=900)
    mem.set_cooldown("ETH")

    data = json.loads(path.read_text())
    assert "cooldown_timestamps" in data
    assert "ETH" in data["cooldown_timestamps"]
    assert isinstance(data["cooldown_timestamps"]["ETH"], float)


def test_cooldown_timestamp_is_recent(tmp_path):
    """The stored timestamp is approximately now (within 2 seconds)."""
    path = tmp_path / "session.json"
    mem = SessionMemory(path, cooldown_seconds=900)

    before = time.time()
    mem.set_cooldown("AAPL")
    after = time.time()

    data = json.loads(path.read_text())
    stored_ts = data["cooldown_timestamps"]["AAPL"]
    assert before <= stored_ts <= after


def test_active_cooldown_not_filtered_on_reload(tmp_path):
    """A freshly set cooldown survives a reload (TTL not yet elapsed)."""
    path = tmp_path / "session.json"
    mem = SessionMemory(path, cooldown_seconds=900)
    mem.set_cooldown("SOL")

    # Simulate reload immediately
    mem_reloaded = SessionMemory(path, cooldown_seconds=900)
    assert mem_reloaded.is_on_cooldown("SOL")
    # Should also be in the internal dict
    assert "SOL" in mem_reloaded.cooldown_timestamps


def test_cooldown_cleared_when_expired_at_boundary(tmp_path):
    """A cooldown set exactly at TTL boundary is treated as expired on reload."""
    path = tmp_path / "session.json"
    # Write a cooldown exactly cooldown_seconds seconds old — should be filtered
    cooldown_seconds = 60
    boundary_ts = time.time() - cooldown_seconds  # exactly expired
    path.write_text(
        json.dumps(
            {
                "cooldown_timestamps": {"DOGE": boundary_ts},
                "recent_orders": [],
            }
        )
    )

    mem = SessionMemory(path, cooldown_seconds=cooldown_seconds)
    # time.time() - boundary_ts == cooldown_seconds → NOT < cooldown → False
    assert not mem.is_on_cooldown("DOGE")


def test_json_file_created_on_first_set_cooldown(tmp_path):
    """The JSON session file is created when set_cooldown is called for the first time."""
    path = tmp_path / "session.json"
    assert not path.exists()

    mem = SessionMemory(path, cooldown_seconds=900)
    mem.set_cooldown("XRP")

    assert path.exists()
    data = json.loads(path.read_text())
    assert "XRP" in data["cooldown_timestamps"]


def test_second_set_cooldown_overwrites_first(tmp_path):
    """Calling set_cooldown twice on the same ticker overwrites the timestamp."""
    path = tmp_path / "session.json"

    # Write an old (but still within TTL) timestamp manually
    old_ts = time.time() - 400  # 400 s ago, still within 900 s cooldown
    path.write_text(
        json.dumps(
            {
                "cooldown_timestamps": {"NVDA": old_ts},
                "recent_orders": [],
            }
        )
    )

    mem = SessionMemory(path, cooldown_seconds=900)
    # First assert it is on cooldown from the old timestamp
    assert mem.is_on_cooldown("NVDA")

    # Now reset the cooldown (simulates a new signal)
    mem.set_cooldown("NVDA")

    data = json.loads(path.read_text())
    new_ts = data["cooldown_timestamps"]["NVDA"]
    # New timestamp must be fresher than old_ts
    assert new_ts > old_ts
