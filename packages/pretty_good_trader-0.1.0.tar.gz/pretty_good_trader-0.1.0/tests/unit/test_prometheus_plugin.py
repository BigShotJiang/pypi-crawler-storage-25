"""Tests for PrometheusPlugin — 8 required metrics + /metrics endpoint."""

from __future__ import annotations

import sys
from unittest.mock import MagicMock

import pytest


@pytest.fixture(autouse=True)
def mock_prometheus():
    """Inject a fake prometheus_client before each test and clean up after."""
    mock_prom = MagicMock()

    # Each metric factory returns a mock that supports .labels() chaining
    mock_metric = MagicMock()
    mock_metric.labels = MagicMock(return_value=mock_metric)

    mock_prom.Counter = MagicMock(return_value=mock_metric)
    mock_prom.Gauge = MagicMock(return_value=mock_metric)
    mock_prom.Histogram = MagicMock(return_value=mock_metric)
    mock_prom.start_http_server = MagicMock()

    sys.modules["prometheus_client"] = mock_prom
    # Also remove the real plugin module so it re-imports with the mock
    sys.modules.pop("pgt.plugins.prometheus", None)

    yield mock_prom

    sys.modules.pop("prometheus_client", None)
    sys.modules.pop("pgt.plugins.prometheus", None)


@pytest.fixture()
def plugin(mock_prometheus):
    from pgt.plugins.prometheus import PrometheusPlugin

    return PrometheusPlugin()


@pytest.fixture()
def run_ctx():
    ctx = MagicMock()
    ctx.config.paper = True
    ctx.adapter.exchange_name = "mock"
    return ctx


# ---------------------------------------------------------------------------
# 1. All 8 metrics created
# ---------------------------------------------------------------------------


def test_all_8_metrics_created(mock_prometheus, plugin):
    registered_names = {
        call_args[0][0]
        for factory in (mock_prometheus.Counter, mock_prometheus.Gauge, mock_prometheus.Histogram)
        for call_args in factory.call_args_list
    }
    expected = {
        "pgt_monitor_signal_rate",
        "pgt_cycle_duration_seconds",
        "pgt_api_cost_total",
        "pgt_trade_count_total",
        "pgt_portfolio_value",
        "pgt_risk_blocked_total",
        "pgt_llm_tokens_total",
        "pgt_errors_total",
    }
    assert expected == registered_names


# ---------------------------------------------------------------------------
# 2. on_startup calls start_http_server with port 9090
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_on_startup_calls_start_http_server(mock_prometheus, plugin, run_ctx):
    await plugin.on_startup(run_ctx)
    mock_prometheus.start_http_server.assert_called_once_with(9090)


# ---------------------------------------------------------------------------
# 3. on_signal_detected increments signal rate counter
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_on_signal_detected_increments_signal_rate(mock_prometheus, plugin):
    signal = MagicMock()
    await plugin.on_signal_detected(signal)
    plugin._monitor_signal_rate.inc.assert_called_once()


# ---------------------------------------------------------------------------
# 4. on_order_placed increments trade count with correct labels
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_on_order_placed_increments_trade_count_with_labels(mock_prometheus, plugin):
    order = MagicMock()
    order.side.value = "buy"
    order.ticker = "AAPL"
    portfolio = MagicMock()
    portfolio.equity = 10_000.0

    await plugin.on_order_placed(order, portfolio)

    plugin._trade_count_total.labels.assert_called_once_with(action="buy", ticker="AAPL")
    plugin._trade_count_total.labels.return_value.inc.assert_called_once()


# ---------------------------------------------------------------------------
# 5. on_order_placed sets portfolio value gauge
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_on_order_placed_sets_portfolio_value(mock_prometheus, plugin):
    order = MagicMock()
    order.side.value = "sell"
    order.ticker = "MSFT"
    portfolio = MagicMock()
    portfolio.equity = 25_000.50

    await plugin.on_order_placed(order, portfolio)

    plugin._portfolio_value.set.assert_called_once_with(25_000.50)


# ---------------------------------------------------------------------------
# 6. on_order_blocked increments risk_blocked_total counter
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_on_order_blocked_increments_risk_blocked(mock_prometheus, plugin):
    intent = MagicMock()
    await plugin.on_order_blocked("max position exceeded", intent)
    plugin._risk_blocked_total.inc.assert_called_once()


# ---------------------------------------------------------------------------
# 7. on_error increments errors counter with error_type label
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_on_error_increments_errors_with_error_type_label(mock_prometheus, plugin):
    error = ValueError("bad value")
    await plugin.on_error(error, "monitor_cycle")

    plugin._errors_total.labels.assert_called_once_with(error_type="ValueError")
    plugin._errors_total.labels.return_value.inc.assert_called_once()


# ---------------------------------------------------------------------------
# 8. on_eod_summary updates portfolio value
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_on_eod_summary_updates_portfolio_value(mock_prometheus, plugin):
    summary = MagicMock()
    summary.portfolio.equity = 50_000.0

    await plugin.on_eod_summary(summary)

    plugin._portfolio_value.set.assert_called_once_with(50_000.0)


# ---------------------------------------------------------------------------
# 9. ImportError when prometheus_client is not installed
# ---------------------------------------------------------------------------


def test_import_error_without_prometheus_client():
    # Remove the mock so the real import attempt fails
    sys.modules.pop("prometheus_client", None)
    sys.modules.pop("pgt.plugins.prometheus", None)

    with pytest.raises(ImportError, match="prometheus-client is required"):
        from pgt.plugins.prometheus import PrometheusPlugin  # noqa: F401

        PrometheusPlugin()
