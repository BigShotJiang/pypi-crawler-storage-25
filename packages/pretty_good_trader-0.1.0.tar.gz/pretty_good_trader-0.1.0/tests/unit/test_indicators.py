"""Tests for technical indicators."""

from __future__ import annotations

import pandas as pd
import pytest

from pgt.data.indicators import get_indicators


@pytest.mark.asyncio
async def test_indicators_basic():
    """Basic indicator computation on mock OHLCV data."""
    # Create minimal OHLCV DataFrame
    data = {
        "open": [100.0 + i for i in range(30)],
        "high": [105.0 + i for i in range(30)],
        "low": [95.0 + i for i in range(30)],
        "close": [102.0 + i for i in range(30)],
        "volume": [1_000_000.0] * 30,
    }
    df = pd.DataFrame(data)
    df.index = pd.date_range("2024-01-01", periods=30)

    result = await get_indicators(df, "NVDA")
    assert result["ticker"] == "NVDA"
    # close should be present
    assert result.get("close") is not None


@pytest.mark.asyncio
async def test_indicators_handles_empty():
    """Empty DataFrame returns dict with ticker key (error or None values)."""
    df = pd.DataFrame()
    result = await get_indicators(df, "NVDA")
    assert result["ticker"] == "NVDA"
    # Either returns error key or all-None values — both are acceptable
    assert "error" in result or result.get("close") is None
