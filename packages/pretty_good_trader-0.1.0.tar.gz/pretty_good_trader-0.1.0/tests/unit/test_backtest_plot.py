"""Tests for BacktestReport model and plot_equity_curve function."""

from __future__ import annotations

from datetime import UTC, datetime
from unittest.mock import MagicMock, patch

import pytest

from pgt.models import BacktestReport, BacktestResult

# ─── BacktestReport model validation ────────────────────────────────────────


def test_backtest_report_validates_correctly():
    """BacktestReport accepts valid data and stores it correctly."""
    ts = datetime(2024, 1, 2, 10, 0, tzinfo=UTC)
    report = BacktestReport(
        total_return_pct=12.5,
        sharpe=1.23,
        max_drawdown_pct=5.0,
        win_rate=0.6,
        total_trades=42,
        total_llm_cost=0.0085,
        equity_curve=[(ts, 11250.0)],
    )
    assert report.total_return_pct == 12.5
    assert report.sharpe == 1.23
    assert report.max_drawdown_pct == 5.0
    assert report.win_rate == 0.6
    assert report.total_trades == 42
    assert report.total_llm_cost == 0.0085
    assert len(report.equity_curve) == 1
    assert report.equity_curve[0] == (ts, 11250.0)


def test_backtest_report_default_equity_curve():
    """BacktestReport defaults equity_curve to empty list."""
    report = BacktestReport(
        total_return_pct=0.0,
        sharpe=0.0,
        max_drawdown_pct=0.0,
        win_rate=0.0,
        total_trades=0,
        total_llm_cost=0.0,
    )
    assert report.equity_curve == []


# ─── BacktestReport.from_backtest_result ────────────────────────────────────


def _make_backtest_result(equity_curve: list[dict] | None = None) -> BacktestResult:
    """Build a minimal BacktestResult for testing."""
    return BacktestResult(
        run_id="test-run-1",
        start="2024-01-01",
        end="2024-03-31",
        exchange="alpaca",
        initial_capital=10_000.0,
        final_equity=11_500.0,
        total_trades=15,
        win_rate=0.6,
        sharpe_ratio=1.45,
        max_drawdown=0.08,
        total_pnl=1_500.0,
        equity_curve=equity_curve or [],
        model_used="grok-2",
        total_llm_cost=0.012,
    )


def test_from_backtest_result_basic():
    """from_backtest_result() computes total_return_pct correctly."""
    result = _make_backtest_result()
    report = BacktestReport.from_backtest_result(result)

    assert report.total_return_pct == pytest.approx(15.0, rel=1e-3)
    assert report.sharpe == 1.45
    assert report.max_drawdown_pct == pytest.approx(8.0, rel=1e-3)
    assert report.win_rate == 0.6
    assert report.total_trades == 15
    assert report.total_llm_cost == 0.012


def test_from_backtest_result_equity_curve_parsed():
    """from_backtest_result() parses equity_curve dicts into (datetime, float) tuples."""
    equity_curve = [
        {"timestamp": "2024-01-02T10:00:00", "equity": 10_100.0, "cash": 5_000.0},
        {"timestamp": "2024-01-03T10:00:00", "equity": 10_250.0, "cash": 5_000.0},
        {"timestamp": "2024-01-04T10:00:00", "equity": 10_400.0, "cash": 5_000.0},
    ]
    result = _make_backtest_result(equity_curve=equity_curve)
    report = BacktestReport.from_backtest_result(result)

    assert len(report.equity_curve) == 3
    ts0, val0 = report.equity_curve[0]
    assert isinstance(ts0, datetime)
    assert val0 == pytest.approx(10_100.0)
    assert report.equity_curve[2][1] == pytest.approx(10_400.0)


def test_from_backtest_result_empty_equity_curve():
    """from_backtest_result() returns empty equity_curve when result has none."""
    result = _make_backtest_result(equity_curve=[])
    report = BacktestReport.from_backtest_result(result)
    assert report.equity_curve == []


def test_from_backtest_result_zero_initial_capital():
    """from_backtest_result() handles zero initial_capital without ZeroDivisionError."""
    result = BacktestResult(
        run_id="zero-cap",
        start="2024-01-01",
        end="2024-01-31",
        exchange="alpaca",
        initial_capital=0.0,
        final_equity=0.0,
        total_trades=0,
        win_rate=0.0,
        sharpe_ratio=0.0,
        max_drawdown=0.0,
        total_pnl=0.0,
    )
    report = BacktestReport.from_backtest_result(result)
    assert report.total_return_pct == 0.0


def test_from_backtest_result_skips_bad_timestamps():
    """from_backtest_result() silently skips entries with unparseable timestamps."""
    equity_curve = [
        {"timestamp": "not-a-date", "equity": 10_000.0},
        {"timestamp": "2024-01-02T10:00:00", "equity": 10_100.0},
    ]
    result = _make_backtest_result(equity_curve=equity_curve)
    report = BacktestReport.from_backtest_result(result)
    # Only the valid entry should appear
    assert len(report.equity_curve) == 1


# ─── plot_equity_curve ────────────────────────────────────────────────────────


def test_plot_equity_curve_runs_without_error():
    """plot_equity_curve() runs without raising, with plotext mocked."""
    from datetime import timedelta

    from pgt.core.engines import plot_equity_curve

    base = datetime(2024, 1, 2, 10, 0)
    curve = [(base + timedelta(days=i), 10_000.0 + i * 50) for i in range(10)]

    report = BacktestReport(
        total_return_pct=5.0,
        sharpe=1.1,
        max_drawdown_pct=2.5,
        win_rate=0.65,
        total_trades=10,
        total_llm_cost=0.005,
        equity_curve=curve,
    )

    mock_plt = MagicMock()
    with patch.dict("sys.modules", {"plotext": mock_plt}):
        # Re-import to pick up the mocked module inside the function
        # Call directly — the function does `import plotext as plt` inside
        # so we patch the module in sys.modules before calling
        plot_equity_curve(report)

    # plotext was called (clear_figure, plot, title, etc.)
    mock_plt.clear_figure.assert_called_once()
    mock_plt.plot.assert_called_once()
    mock_plt.show.assert_called_once()


def test_plot_equity_curve_empty_curve(capsys):
    """plot_equity_curve() prints a warning when equity_curve is empty."""
    from pgt.core.engines import plot_equity_curve

    report = BacktestReport(
        total_return_pct=0.0,
        sharpe=0.0,
        max_drawdown_pct=0.0,
        win_rate=0.0,
        total_trades=0,
        total_llm_cost=0.0,
        equity_curve=[],
    )

    mock_plt = MagicMock()
    with patch.dict("sys.modules", {"plotext": mock_plt}):
        plot_equity_curve(report)

    # plotext should NOT have been asked to plot anything
    mock_plt.plot.assert_not_called()
    mock_plt.show.assert_not_called()
