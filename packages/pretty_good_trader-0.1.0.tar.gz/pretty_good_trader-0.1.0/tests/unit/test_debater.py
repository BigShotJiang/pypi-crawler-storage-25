"""Tests for DebateTier — 4 required cases."""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest

from pgt.ai.client import PGTLLMError
from pgt.ai.debater import DebateTier
from pgt.models import LLMResponse, MonitorSignal, UrgencyLevel


def make_signal(urgency: str = "high") -> MonitorSignal:
    return MonitorSignal(
        signal=True,
        tickers=["NVDA"],
        urgency=UrgencyLevel(urgency),
        reason="test signal",
    )


@pytest.mark.asyncio
async def test_debate_fires_on_enabled_high_urgency(run_context):
    """debate_enabled=True + urgency=high → debate runs."""
    run_context.config.debate_enabled = True
    run_context.llm.call = AsyncMock(
        return_value=LLMResponse(content="PROCEED — strong bull case")
    )

    debater = DebateTier()
    result = await debater.run(run_context, make_signal("high"), "research brief")

    assert result is not None
    assert run_context.llm.call.call_count == 3  # 3 rounds


@pytest.mark.asyncio
async def test_debate_skipped_when_disabled(run_context):
    """debate_enabled=False → returns None."""
    run_context.config.debate_enabled = False

    debater = DebateTier()
    result = await debater.run(run_context, make_signal("high"), "research brief")

    assert result is None
    run_context.llm.call.assert_not_called()


@pytest.mark.asyncio
async def test_debate_skipped_on_wrong_urgency(run_context):
    """debate_enabled=True but urgency!=high → returns None."""
    run_context.config.debate_enabled = True

    debater = DebateTier()
    result = await debater.run(run_context, make_signal("medium"), "research brief")

    assert result is None
    run_context.llm.call.assert_not_called()


@pytest.mark.asyncio
async def test_debate_graceful_bull_llm_failure(run_context):
    """Bull LLM call fails → debate returns None (engine continues)."""
    run_context.config.debate_enabled = True
    run_context.llm.call = AsyncMock(side_effect=PGTLLMError("Bull LLM down"))

    debater = DebateTier()
    result = await debater.run(run_context, make_signal("high"), "research brief")

    assert result is None  # graceful failure, no exception propagated
