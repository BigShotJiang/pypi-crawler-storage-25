"""Tests for AIPipeline."""

from __future__ import annotations

from unittest.mock import AsyncMock, patch

import pytest

from pgt.ai.client import PGTLLMError
from pgt.ai.pipeline import AIPipeline
from pgt.models import LLMResponse


@pytest.mark.asyncio
async def test_no_signal_exits_early(run_context):
    """No signal from monitor → pipeline exits before research."""
    pipeline = AIPipeline()
    run_context.llm.call = AsyncMock(
        return_value=LLMResponse(
            content='{"signal":false,"tickers":[],"urgency":"low","reason":"quiet"}'
        )
    )

    with patch.object(pipeline._researcher, "run", AsyncMock()) as mock_research:
        await pipeline.run(run_context)
        mock_research.assert_not_called()


@pytest.mark.asyncio
async def test_signal_triggers_research_and_decision(run_context):
    """Signal detected → researcher and decider are called."""
    pipeline = AIPipeline()

    monitor_response = LLMResponse(
        content='{"signal":true,"tickers":["NVDA"],"urgency":"high","reason":"breakout"}'
    )
    research_response = LLMResponse(content="Research brief here")
    decision_response = LLMResponse(content="Decided to buy 1 share")

    call_count = 0

    async def mock_call(*args, **kwargs):
        nonlocal call_count
        call_count += 1
        if call_count == 1:
            return monitor_response
        elif call_count == 2:
            return research_response
        else:
            return decision_response

    run_context.llm.call = AsyncMock(side_effect=mock_call)

    await pipeline.run(run_context)
    assert call_count >= 2  # at least monitor + research calls made


@pytest.mark.asyncio
async def test_llm_error_fires_on_error_plugin(run_context):
    """PGTLLMError → on_error() fired, engine continues."""
    from pgt.plugins.base import PGTPlugin

    class TrackingPlugin(PGTPlugin):
        def __init__(self):
            self.errors = []

        async def on_error(self, error: Exception, context: str) -> None:
            self.errors.append((error, context))

    plugin = TrackingPlugin()
    run_context.plugins = [plugin]

    pipeline = AIPipeline()
    run_context.llm.call = AsyncMock(side_effect=PGTLLMError("LLM unavailable"))

    # Should not raise — engine continues
    await pipeline.run(run_context)

    assert len(plugin.errors) > 0
    assert isinstance(plugin.errors[0][0], PGTLLMError)


@pytest.mark.asyncio
async def test_cooldown_set_on_signal(run_context):
    """Signal detection must set cooldown for signaled tickers."""
    pipeline = AIPipeline()

    run_context.llm.call = AsyncMock(return_value=LLMResponse(
        content='{"signal":true,"tickers":["NVDA"],"urgency":"high","reason":"test"}'
    ))

    with patch.object(pipeline._researcher, "run", AsyncMock(return_value="brief")):
        with patch.object(pipeline._decider, "run", AsyncMock(return_value=LLMResponse())):
            await pipeline.run(run_context)

    assert run_context.session.is_on_cooldown("NVDA")


@pytest.mark.asyncio
async def test_trace_id_assigned_on_signal(run_context):
    """trace_id must be set when a signal is detected."""
    pipeline = AIPipeline()

    run_context.llm.call = AsyncMock(return_value=LLMResponse(
        content='{"signal":true,"tickers":["NVDA"],"urgency":"high","reason":"test"}'
    ))

    with patch.object(pipeline._researcher, "run", AsyncMock(return_value="brief")):
        with patch.object(pipeline._decider, "run", AsyncMock(return_value=LLMResponse())):
            await pipeline.run(run_context)

    assert run_context.trace_id is not None
