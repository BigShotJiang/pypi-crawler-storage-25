"""Tests for SearchClient."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from pgt.data.search import SearchClient, _sanitize_query


def test_sanitize_query_strips_dangerous_chars():
    result = _sanitize_query("NVDA; rm -rf /")
    assert ";" not in result
    assert "|" not in _sanitize_query("a|b")
    assert "`" not in _sanitize_query("a`b`c")


def test_sanitize_query_truncates():
    long_query = "a" * 300
    result = _sanitize_query(long_query, max_len=200)
    # URL-encoded, but original chars <= 200
    assert len(result) <= 600  # URL-encoding can expand, but max chars is bounded


def test_sanitize_query_url_encodes():
    result = _sanitize_query("NVDA&earnings Q4")
    # Dangerous chars stripped, but the result should be URL-safe
    assert "&" not in result


@pytest.mark.asyncio
async def test_search_wraps_in_tags(tmp_path):
    """Search results must be wrapped in <search_result> tags."""
    client = SearchClient(
        searxng_url="http://searxng:8080",
        cache_dir=str(tmp_path / "cache"),
    )

    mock_resp = MagicMock()
    mock_resp.json.return_value = {
        "results": [
            {"title": "NVDA News", "url": "https://example.com", "content": "NVDA up 5%"},
        ]
    }
    mock_resp.raise_for_status = MagicMock()

    with patch("httpx.AsyncClient") as mock_client_cls:
        mock_http = AsyncMock()
        mock_http.__aenter__ = AsyncMock(return_value=mock_http)
        mock_http.__aexit__ = AsyncMock(return_value=False)
        mock_http.get = AsyncMock(return_value=mock_resp)
        mock_client_cls.return_value = mock_http

        result = await client.search("NVDA news")

    assert "<search_result>" in result
    assert "</search_result>" in result


@pytest.mark.asyncio
async def test_search_caches_result(tmp_path):
    """Repeat search returns cached result without HTTP call."""
    client = SearchClient(
        searxng_url="http://searxng:8080",
        cache_dir=str(tmp_path / "cache"),
    )

    mock_resp = MagicMock()
    mock_resp.json.return_value = {"results": []}
    mock_resp.raise_for_status = MagicMock()

    call_count = 0

    with patch("httpx.AsyncClient") as mock_client_cls:
        mock_http = AsyncMock()
        mock_http.__aenter__ = AsyncMock(return_value=mock_http)
        mock_http.__aexit__ = AsyncMock(return_value=False)

        async def counting_get(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            return mock_resp

        mock_http.get = counting_get
        mock_client_cls.return_value = mock_http

        await client.search("NVDA news")
        await client.search("NVDA news")  # second call — should use cache

    assert call_count == 1  # only one HTTP call
