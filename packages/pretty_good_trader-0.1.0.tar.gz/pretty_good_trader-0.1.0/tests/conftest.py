"""Shared test fixtures."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

from pgt.adapters.base import BrokerAdapter
from pgt.adapters.paper import PaperEngine
from pgt.ai.client import PGTLLMClient
from pgt.core.clock import SimClock
from pgt.core.config import PGTConfig
from pgt.core.context import RunContext
from pgt.logger import Logger
from pgt.memory.reflection import ReflectionMemory
from pgt.memory.session import SessionMemory
from pgt.models import OrderResult, OrderStatus, PortfolioSnapshot, Position
from pgt.risk.engine import RiskEngine

# ─── Mock adapter ────────────────────────────────────────────────────────────

class MockBrokerAdapter(BrokerAdapter):
    """Deterministic portfolio + prices, never calls exchange."""

    def __init__(self) -> None:
        self._prices = {"NVDA": 500.0, "AAPL": 200.0, "TSLA": 250.0}
        self._portfolio = PortfolioSnapshot(
            cash=9000.0,
            positions={
                "NVDA": Position(ticker="NVDA", qty=2.0, avg_cost=480.0, current_price=500.0)
            },
        )
        self._tradeable: set[str] | None = None

    async def get_portfolio(self) -> PortfolioSnapshot:
        return self._portfolio

    async def get_prices(self, tickers: list[str]) -> dict[str, float]:
        return {t: self._prices.get(t, 100.0) for t in tickers}

    async def place_order(self, intent) -> OrderResult:
        return OrderResult(
            order_id="mock-001",
            ticker=intent.ticker,
            side=intent.side,
            qty=intent.qty,
            fill_price=self._prices.get(intent.ticker, 100.0),
            status=OrderStatus.FILLED,
            exchange="mock",
        )

    async def cancel_order(self, order_id: str) -> bool:
        return True

    async def get_orders(self, status: str = "open") -> list[OrderResult]:
        return []

    async def get_tradeable_tickers(self) -> set[str] | None:
        return self._tradeable

    @property
    def exchange_name(self) -> str:
        return "mock"


@pytest.fixture
def mock_adapter() -> MockBrokerAdapter:
    return MockBrokerAdapter()


@pytest.fixture
def paper_engine(mock_adapter: MockBrokerAdapter, tmp_path: Path) -> PaperEngine:
    return PaperEngine(
        live_adapter=mock_adapter,
        initial_capital=10_000.0,
        is_backtest=False,
        state_file=tmp_path / "paper_state.json",
    )


@pytest.fixture
def paper_engine_backtest(mock_adapter: MockBrokerAdapter) -> PaperEngine:
    return PaperEngine(
        live_adapter=mock_adapter,
        initial_capital=10_000.0,
        is_backtest=True,
    )


@pytest.fixture
def reflection_memory(tmp_path: Path) -> ReflectionMemory:
    return ReflectionMemory(storage_path=tmp_path / "memory.json")


@pytest.fixture
def session_memory(tmp_path: Path) -> SessionMemory:
    return SessionMemory(storage_path=tmp_path / "session.json", cooldown_seconds=900)


@pytest.fixture
def test_logger(tmp_path: Path) -> Logger:
    return Logger(data_dir=tmp_path)


@pytest.fixture
def test_config() -> PGTConfig:
    return PGTConfig(
        monitor_model="xai/grok-4-1-fast",
        research_model="xai/grok-4-1-fast",
        trader_model="xai/grok-4.20-reasoning",
        paper=True,
        monitor_interval=180,
        signal_cooldown=900,
        min_urgency="medium",
        debate_enabled=False,
    )


@pytest.fixture
def mock_llm(test_config: PGTConfig) -> PGTLLMClient:
    """Mock LLM client that returns configurable responses."""
    client = MagicMock(spec=PGTLLMClient)
    client.validate_keys = MagicMock()
    from pgt.models import LLMResponse
    client.call = AsyncMock(return_value=LLMResponse(
        content='{"signal":false,"tickers":[],"urgency":"low","reason":"quiet"}'
    ))
    return client


@pytest.fixture
def run_context(
    mock_adapter: MockBrokerAdapter,
    paper_engine: PaperEngine,
    test_config: PGTConfig,
    session_memory: SessionMemory,
    reflection_memory: ReflectionMemory,
    test_logger: Logger,
    tmp_path: Path,
) -> RunContext:
    """Full RunContext with SimClock, mock LLM, risk engine."""
    from unittest.mock import AsyncMock, MagicMock

    from pgt.ai.client import PGTLLMClient
    from pgt.models import LLMResponse

    mock_llm = MagicMock(spec=PGTLLMClient)
    mock_llm.validate_keys = MagicMock()
    mock_llm.call = AsyncMock(
        return_value=LLMResponse(
            content='{"signal":false,"tickers":[],"urgency":"low","reason":"quiet"}'
        )
    )

    return RunContext(
        adapter=paper_engine,
        llm=mock_llm,
        risk=RiskEngine(),
        memory=reflection_memory,
        session=session_memory,
        logger=test_logger,
        plugins=[],
        config=test_config,
        clock=SimClock(),
        is_backtest=False,
    )
