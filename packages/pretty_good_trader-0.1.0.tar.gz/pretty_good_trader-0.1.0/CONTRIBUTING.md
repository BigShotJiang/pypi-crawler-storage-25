# Contributing to PrettyGoodTrader

Thank you for your interest in contributing to PGT. This guide covers everything you need to make a clean contribution.

---

## Development Setup

```bash
git clone https://github.com/prettygoodtrader/pgt
cd pgt
python -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
```

---

## Prompt Change Rules

Any change to prompts in `src/pgt/ai/prompts.py` **requires a new regression test** in `tests/unit/test_prompts.py`.

Prompts are the "strategy logic" of PGT — treat them like database migrations: never modify without a test. A prompt edit that silently changes trading behavior is as dangerous as a schema migration with no rollback.

---

## Adapter Contribution Guide

To add a new exchange adapter:

1. Subclass `BrokerAdapter` from `src/pgt/adapters/base.py`
2. Implement all 5 abstract methods:
   - `async get_portfolio() -> PortfolioSnapshot`
   - `async get_prices(tickers: list[str]) -> dict[str, float]`
   - `async place_order(intent: OrderIntent) -> OrderResult`
   - `async cancel_order(order_id: str) -> bool`
   - `async get_orders(status: str = "open") -> list[OrderResult]`
3. Add `tests/unit/test_<name>_adapter.py` with at minimum:
   - Happy path
   - Error path (raises `BrokerError`)
   - Paper mode
4. Register it in `src/pgt/adapters/__init__.py`

---

## Exception Handling Contract

`AIPipeline` catches `PGTLLMError` and `BrokerError` specifically. **Broad `except Exception` is forbidden** — it silently swallows order failures. Always raise the appropriate typed exception.

---

## PR Checklist

- [ ] `ruff check src/ tests/` passes
- [ ] `pytest tests/ -q --cov=pgt --cov-fail-under=80` passes
- [ ] New features have unit tests
- [ ] Prompt changes have regression tests in `tests/unit/test_prompts.py`
- [ ] Adapter changes implement all 5 abstract methods
