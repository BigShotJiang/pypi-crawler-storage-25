"""
Backtest demo — replay 2024 historical data through the LLM pipeline.

Requires:
    - Historical OHLCV data loaded into DuckDB catalog
    - XAI_API_KEY (or another LLM provider key)

Usage:
    python examples/backtest_demo.py --start 2024-01-01 --end 2024-03-31
"""
from __future__ import annotations

import asyncio
import argparse

from pgt import BacktestEngine
from pgt.adapters import PaperEngine
from pgt.adapters.alpaca import AlpacaAdapter
from pgt.core.config import PGTConfig
from pgt.data.catalog import DuckDBCatalog


def main() -> None:
    parser = argparse.ArgumentParser(description="PGT backtest demo")
    parser.add_argument("--start", default="2024-01-01", help="Start date (YYYY-MM-DD)")
    parser.add_argument("--end", default="2024-03-31", help="End date (YYYY-MM-DD)")
    parser.add_argument("--db", default="data/catalog.duckdb", help="DuckDB path")
    args = parser.parse_args()

    config = PGTConfig(paper=True, backtest_llm_temperature=0.0)
    catalog = DuckDBCatalog(db_path=args.db)

    # CatalogAdapter reads prices from DuckDB instead of live broker
    from pgt.data.catalog import CatalogAdapter
    adapter = PaperEngine(
        CatalogAdapter(catalog),
        initial_capital=10_000.0,
        is_backtest=True,
    )

    engine = BacktestEngine(
        adapter=adapter,
        config=config,
        catalog=catalog,
        start=args.start,
        end=args.end,
    )

    print(f"Running backtest: {args.start} → {args.end}")
    results = asyncio.run(engine.run())

    print(f"\n=== Backtest Results ===")
    print(f"Total return: {results.total_return_pct:.2f}%")
    print(f"Sharpe ratio: {results.sharpe:.3f}")
    print(f"Max drawdown: {results.max_drawdown_pct:.2f}%")
    print(f"Win rate:     {results.win_rate:.1%}")
    print(f"Total trades: {results.total_trades}")
    print(f"LLM cost:     ${results.total_llm_cost:.4f}")


if __name__ == "__main__":
    main()
