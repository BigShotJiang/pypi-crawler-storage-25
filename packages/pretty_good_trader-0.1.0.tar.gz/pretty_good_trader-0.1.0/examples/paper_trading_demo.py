"""
Paper trading demo — no API keys required.

Runs one complete monitor cycle using a mock adapter and SimClock.
Prints the decision walkthrough to stdout.

Usage:
    python examples/paper_trading_demo.py
"""
from __future__ import annotations

import asyncio
from unittest.mock import AsyncMock, MagicMock

from pgt.adapters.paper import PaperEngine
from pgt.adapters.base import BrokerAdapter
from pgt.core.config import PGTConfig
from pgt.core.clock import SimClock


class MockAdapter(BrokerAdapter):
    """Minimal adapter for demo — returns fake prices, no API calls."""

    async def get_prices(self, tickers: list[str]) -> dict[str, float]:
        return {t: 100.0 + hash(t) % 50 for t in tickers}

    async def place_order(self, ticker, side, qty, order_type="market", **kwargs):
        from pgt.adapters.base import OrderResult
        return OrderResult(order_id="mock-001", status="filled", filled_qty=qty, filled_price=100.0)

    async def get_portfolio(self):
        from pgt.adapters.base import Portfolio
        return Portfolio(cash=10_000.0, positions={}, equity=10_000.0)

    async def cancel_order(self, order_id: str):
        pass


def main() -> None:
    config = PGTConfig(
        paper=True,
        monitor_model="xai/grok-4-1-fast",
    )

    mock = MockAdapter()
    adapter = PaperEngine(mock, initial_capital=10_000.0)

    print("=== Paper Trading Demo ===")
    print(f"Config: paper={config.paper}, model={config.monitor_model}")
    print(f"Initial capital: $10,000")
    print()
    print("Mock adapter initialized — no real API calls.")
    print("In a real run, TradingEngine would call the LLM each cycle.")
    print()
    print("To run a full cycle, wire up TradingEngine:")
    print("  engine = TradingEngine(adapter=adapter, config=config)")
    print("  asyncio.run(engine.run())")


if __name__ == "__main__":
    main()
