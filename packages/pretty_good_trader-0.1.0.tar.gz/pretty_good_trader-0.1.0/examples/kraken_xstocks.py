"""
Kraken xStocks — tokenized equities on Kraken.

Usage:
    python examples/kraken_xstocks.py
"""
from __future__ import annotations

import asyncio
import os

from pgt import TradingEngine
from pgt.adapters import PaperEngine
from pgt.adapters.kraken import KrakenAdapter
from pgt.core.config import PGTConfig


def main() -> None:
    config = PGTConfig()

    kraken = KrakenAdapter(
        api_key=os.environ["KRAKEN_API_KEY"],
        secret_key=os.environ["KRAKEN_SECRET_KEY"],
    )

    adapter = PaperEngine(kraken, initial_capital=10_000.0)

    engine = TradingEngine(adapter=adapter, config=config)

    print(f"Starting PGT (Kraken xStocks) — paper={config.paper}")
    asyncio.run(engine.run())


if __name__ == "__main__":
    main()
