"""
Alpaca US Equities — Live + Paper trading example.

Usage:
    # Paper mode (default, safe)
    python examples/alpaca_us_equities.py

    # Live mode (real money)
    PAPER=false python examples/alpaca_us_equities.py --confirm-live
"""
from __future__ import annotations

import asyncio
import os

from pgt import TradingEngine
from pgt.adapters import PaperEngine
from pgt.adapters.alpaca import AlpacaAdapter
from pgt.core.config import PGTConfig


def main() -> None:
    config = PGTConfig()

    alpaca = AlpacaAdapter(
        api_key=config.alpaca_api_key.get_secret_value() if config.alpaca_api_key else os.environ["ALPACA_API_KEY"],
        secret_key=config.alpaca_secret_key.get_secret_value() if config.alpaca_secret_key else os.environ["ALPACA_SECRET_KEY"],
        paper=config.paper,
    )

    # PaperEngine wraps the live adapter — uses real prices for fills,
    # but routes orders to a virtual portfolio.
    adapter = PaperEngine(alpaca, initial_capital=10_000.0)

    engine = TradingEngine(adapter=adapter, config=config)

    print(f"Starting PGT — paper={config.paper}, model={config.monitor_model}")
    asyncio.run(engine.run())


if __name__ == "__main__":
    main()
