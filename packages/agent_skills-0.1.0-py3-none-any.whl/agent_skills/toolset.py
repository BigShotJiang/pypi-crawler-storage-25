# Copyright (c) 2025-2026 Datalayer, Inc.
#
# BSD 3-Clause License

"""Agent Skills Toolset - Integration with pydantic-ai SkillsToolset.

This module provides extensions to pydantic-ai's SkillsToolset with:
- SandboxExecutor: Execute skill scripts in isolated code-sandboxes
- AgentSkillsToolset: Extended toolset with Datalayer-specific features

There are two ways to load skills into a toolset:

## Path-based loading

Skills live in a local directory tree.  Point the toolset at one or more
directories; every sub-directory containing a ``SKILL.md`` file is
automatically discovered::

    from agent_skills import AgentSkillsToolset, SandboxExecutor
    from code_sandboxes import LocalEvalSandbox

    toolset = AgentSkillsToolset(
        directories=["./skills"],           # scanned recursively for SKILL.md
        executor=SandboxExecutor(LocalEvalSandbox()),
    )

This is the right pattern when skills are checked into the same repository
or mounted at a well-known path at runtime.

## Module-based loading

Skills live inside an installed Python package.  Use
``AgentSkill.from_module()`` to import the package and locate the
``SKILL.md`` file next to it (works for both regular and namespace
packages), then pass the results to the toolset via ``skills=``:

    from agent_skills import AgentSkill, AgentSkillsToolset, SandboxExecutor
    from code_sandboxes import LocalEvalSandbox

    toolset = AgentSkillsToolset(
        skills=[
            AgentSkill.from_module("agent_skills.skills.crawl"),
            AgentSkill.from_module("agent_skills.skills.github"),
        ],
        executor=SandboxExecutor(LocalEvalSandbox()),
    )

This is the right pattern when skills are distributed as part of an
installed package (e.g. ``agent-skills``) and consumers should not need
an on-disk copy of the skill directory.

## Both patterns together

The two approaches can be combined freely:

    toolset = AgentSkillsToolset(
        directories=["./skills"],            # local overrides / custom skills
        skills=[
            AgentSkill.from_module("agent_skills.skills.crawl"),
        ],
        executor=SandboxExecutor(LocalEvalSandbox()),
    )
"""

from __future__ import annotations

import asyncio
import json
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable, Protocol, runtime_checkable

from code_sandboxes import ExecutionResult
from typing import TypedDict

if TYPE_CHECKING:
    from code_sandboxes import LocalEvalSandbox
    from pydantic_ai._run_context import RunContext

logger = logging.getLogger(__name__)


class ScriptExecutionResult(TypedDict, total=False):
    """Structured result from skill script execution.
    
    This provides rich error information including exit codes,
    allowing the UI to properly display different failure modes.
    """
    # Success indicator
    success: bool
    
    # Output from the script
    output: str
    stdout: str
    stderr: str
    
    # Execution status
    execution_ok: bool
    execution_error: str | None
    
    # Code error (Python exception)
    code_error: dict[str, str] | None  # {name, value, traceback}
    
    # Exit code from sys.exit()
    exit_code: int | None
    
    # Legacy error field for backwards compatibility
    error: str | None


# =============================================================================
# Executor Protocols (aligned with pydantic-ai PR #3780)
# =============================================================================


@runtime_checkable
class SkillScriptExecutorProtocol(Protocol):
    """Protocol for skill script execution.
    
    This aligns with pydantic-ai's SkillScriptExecutor pattern from PR #3780,
    allowing pluggable execution environments.
    
    BREAKING CHANGE: Now returns ScriptExecutionResult dict instead of str.
    This enables proper error handling with exit_code, code_error, etc.
    """
    
    async def execute(
        self,
        skill_name: str,
        script_name: str,
        script_path: Path,
        args: list[str],
        timeout: int | None = None,
    ) -> ScriptExecutionResult:
        """Execute a skill script.
        
        Args:
            skill_name: Name of the skill.
            script_name: Name of the script within the skill.
            script_path: Path to the script file.
            args: Command-line arguments.
            timeout: Execution timeout in seconds.
            
        Returns:
            ScriptExecutionResult with output, exit_code, and error details.
        """
        ...


# =============================================================================
# Sandbox Executor
# =============================================================================


@dataclass
class SandboxExecutor:
    """Execute skill scripts in an isolated code sandbox.
    
    Uses code-sandboxes (LocalEvalSandbox or remote) to execute
    skill scripts safely with proper isolation.
    
    Example:
        from code_sandboxes import LocalEvalSandbox
        from agent_skills import SandboxExecutor
        
        sandbox = LocalEvalSandbox()
        executor = SandboxExecutor(sandbox)
        
        result = await executor.execute(
            skill_name="pdf-extractor",
            script_name="extract",
            script_path=Path("./skills/pdf-extractor/scripts/extract.py"),
            args=["--input", "document.pdf"],
        )
    """
    
    sandbox: LocalEvalSandbox
    default_timeout: int = 30

    def _get_effective_sandbox(self) -> Any:
        """Return the sandbox to use for skill script execution.

        Always returns the configured sandbox directly.  When skills are
        invoked via the MCP proxy (codemode), the HTTP request arrives on
        a separate thread so there is no kernel deadlock — the same
        sandbox (including its environment variables) is safe to use.
        """
        return self.sandbox
    
    async def execute(
        self,
        skill_name: str,
        script_name: str,
        script_path: Path,
        args: list[str],
        timeout: int | None = None,
    ) -> ScriptExecutionResult:
        """Execute a skill script in the sandbox.
        
        Args:
            skill_name: Name of the skill.
            script_name: Name of the script.
            script_path: Path to the script file.
            args: Command-line arguments.
            timeout: Execution timeout (uses default if None).
            
        Returns:
            ScriptExecutionResult with output, exit_code, and error details.
        """
        timeout = timeout or self.default_timeout
        
        logger.debug(
            f"Executing skill script: {skill_name}/{script_name} "
            f"with args={args}, timeout={timeout}s"
        )
        
        # Read the script content
        script_content = script_path.read_text()
        
        # Build execution code that mimics CLI invocation
        execution_code = self._build_execution_code(
            script_content=script_content,
            script_name=script_name,
            args=args,
        )
        
        # Get identity environment variables from request context
        identity_env: dict[str, str] | None = None
        try:
            from agent_runtimes.context.identities import get_identity_env
            identity_env = get_identity_env()
            if identity_env:
                logger.debug(f"SandboxExecutor: Using identity env vars: {list(identity_env.keys())}")
        except ImportError:
            # agent_runtimes not installed, skip identity context
            pass
        
        try:
            # Select the effective sandbox (local fallback for Jupyter)
            effective_sandbox = self._get_effective_sandbox()

            # Execute in sandbox - prefer run_code if available (supports envs)
            if hasattr(effective_sandbox, 'run_code'):
                # Use run_code which supports envs parameter.
                # Wrap in asyncio.to_thread to avoid blocking the event loop
                # (important when called from a FastAPI async handler).
                result: ExecutionResult = await asyncio.to_thread(
                    effective_sandbox.run_code, execution_code, envs=identity_env
                )
                
                # Build structured result from ExecutionResult
                # Use the stdout/stderr properties which handle text extraction from logs
                stdout = result.stdout or ""
                stderr = result.stderr or ""
                
                # Check for execution failure (infrastructure error)
                if not result.execution_ok:
                    return ScriptExecutionResult(
                        success=False,
                        output=stderr or stdout,
                        stdout=stdout,
                        stderr=stderr,
                        execution_ok=False,
                        execution_error=result.execution_error or "Sandbox execution failed",
                        code_error=None,
                        exit_code=None,
                        error=result.execution_error or "Sandbox execution failed",
                    )
                
                # Check for code error (user code exception)
                if result.code_error:
                    return ScriptExecutionResult(
                        success=False,
                        output=stderr or stdout,
                        stdout=stdout,
                        stderr=stderr,
                        execution_ok=True,
                        execution_error=None,
                        code_error={
                            "name": result.code_error.name,
                            "value": result.code_error.value,
                            "traceback": result.code_error.traceback or "",
                        },
                        exit_code=None,
                        error=f"{result.code_error.name}: {result.code_error.value}",
                    )
                
                # Check for non-zero exit code (intentional sys.exit())
                if result.exit_code is not None and result.exit_code != 0:
                    return ScriptExecutionResult(
                        success=False,
                        output=stderr or stdout,
                        stdout=stdout,
                        stderr=stderr,
                        execution_ok=True,
                        execution_error=None,
                        code_error=None,
                        exit_code=result.exit_code,
                        error=f"Script exited with code {result.exit_code}",
                    )

                # Success case
                output = stdout
                if not output and result.results:
                    output = '\n'.join(str(r.data) for r in result.results)
                
                return ScriptExecutionResult(
                    success=True,
                    output=output,
                    stdout=stdout,
                    stderr=stderr,
                    execution_ok=True,
                    execution_error=None,
                    code_error=None,
                    exit_code=result.exit_code,  # Could be 0 or None
                    error=None,
                )
            elif asyncio.iscoroutinefunction(getattr(effective_sandbox, 'execute', None)):
                result = await asyncio.wait_for(
                    effective_sandbox.execute(execution_code),
                    timeout=timeout,
                )
            else:
                # Sync sandbox - run in executor
                loop = asyncio.get_event_loop()
                result = await asyncio.wait_for(
                    loop.run_in_executor(None, effective_sandbox.execute, execution_code),
                    timeout=timeout,
                )
            
            # Extract output for legacy sandbox APIs
            if hasattr(result, 'stdout'):
                output = result.stdout or ""
            elif hasattr(result, 'result'):
                output = str(result.result)
            else:
                output = str(result)
            
            return ScriptExecutionResult(
                success=True,
                output=output,
                stdout=output,
                stderr="",
                execution_ok=True,
                execution_error=None,
                code_error=None,
                exit_code=None,
                error=None,
            )
                
        except asyncio.TimeoutError:
            return ScriptExecutionResult(
                success=False,
                output="",
                stdout="",
                stderr="",
                execution_ok=False,
                execution_error=f"Skill script {skill_name}/{script_name} timed out after {timeout}s",
                code_error=None,
                exit_code=None,
                error=f"Timeout after {timeout}s",
            )
        except Exception as e:
            return ScriptExecutionResult(
                success=False,
                output="",
                stdout="",
                stderr=str(e),
                execution_ok=False,
                execution_error=str(e),
                code_error=None,
                exit_code=None,
                error=str(e),
            )
    
    def _build_execution_code(
        self,
        script_content: str,
        script_name: str,
        args: list[str],
    ) -> str:
        """Build executable code that runs the script with arguments.
        
        This wraps the script to:
        1. Set sys.argv with the provided arguments
        2. Execute the script
        3. Capture and return output
        """
        # Escape the script content for embedding
        escaped_script = script_content.replace("\\", "\\\\").replace('"""', '\\"\\"\\"')
        args_json = json.dumps(args)
        
        return f'''
import sys
import json
import io
from contextlib import redirect_stdout, redirect_stderr

# Set up sys.argv as if running from CLI
sys.argv = ["{script_name}.py"] + {args_json}

# Capture output
_stdout = io.StringIO()
_stderr = io.StringIO()

_script = """
{escaped_script}
"""

try:
    with redirect_stdout(_stdout), redirect_stderr(_stderr):
        # Create globals with __name__ = "__main__" so scripts with
        # if __name__ == "__main__": blocks execute properly
        _globals = {{"__name__": "__main__", "__file__": "{script_name}.py"}}
        exec(compile(_script, "{script_name}.py", "exec"), _globals)
    
    # Return captured output
    output = _stdout.getvalue()
    if not output:
        output = _stderr.getvalue()
    print(output)
except Exception as e:
    print(f"Error: {{e}}", file=sys.stderr)
    raise
'''


# =============================================================================
# Callable Executor (for programmatic skills)
# =============================================================================


@dataclass
class CallableExecutor:
    """Execute skill scripts that are Python callables.
    
    For programmatic skills created with decorators:
    
        skill = Skill(name="my-skill", ...)
        
        @skill.script
        async def process(ctx: RunContext, data: str) -> str:
            return f"Processed: {data}"
    """
    
    default_timeout: int = 30
    
    @staticmethod
    def _coerce_kwargs(func: Callable, kwargs: dict[str, Any]) -> dict[str, Any]:
        """Coerce kwargs values to match the function's type annotations."""
        import inspect
        sig = inspect.signature(func)
        coerced = {}
        for key, value in kwargs.items():
            if key in sig.parameters:
                param = sig.parameters[key]
                annotation = param.annotation
                if annotation is not inspect.Parameter.empty and isinstance(value, str):
                    # Handle both real types and string annotations (from __future__)
                    ann = annotation if isinstance(annotation, type) else None
                    ann_str = annotation if isinstance(annotation, str) else (
                        annotation.__name__ if hasattr(annotation, '__name__') else str(annotation)
                    )
                    try:
                        if ann is int or ann_str == 'int':
                            value = int(value)
                        elif ann is float or ann_str == 'float':
                            value = float(value)
                        elif ann is bool or ann_str == 'bool':
                            value = value.lower() in ('true', '1', 'yes')
                    except (ValueError, TypeError):
                        pass  # Keep as string if coercion fails
            coerced[key] = value
        return coerced
    
    async def execute_callable(
        self,
        func: Callable,
        ctx: Any,
        args: list[str],
        kwargs: dict[str, Any] | None = None,
        timeout: int | None = None,
    ) -> str:
        """Execute a callable skill script.
        
        Args:
            func: The async callable to execute.
            ctx: RunContext for dependency injection.
            args: Positional arguments to pass (fallback).
            kwargs: Named keyword arguments (preferred).
            timeout: Execution timeout.
            
        Returns:
            Result as string.
        """
        timeout = timeout or self.default_timeout
        kwargs = kwargs or {}
        
        # Determine if function takes context
        import inspect
        sig = inspect.signature(func)
        params = list(sig.parameters.keys())
        has_ctx = params and params[0] in ('ctx', 'context', 'run_context')
        
        # Coerce kwargs types based on function signature
        if kwargs:
            kwargs = self._coerce_kwargs(func, kwargs)
        
        try:
            if kwargs:
                # Preferred path: use keyword arguments
                if asyncio.iscoroutinefunction(func):
                    if has_ctx:
                        result = await asyncio.wait_for(
                            func(ctx, **kwargs),
                            timeout=timeout,
                        )
                    else:
                        result = await asyncio.wait_for(
                            func(**kwargs),
                            timeout=timeout,
                        )
                else:
                    import functools
                    loop = asyncio.get_event_loop()
                    if has_ctx:
                        result = await asyncio.wait_for(
                            loop.run_in_executor(
                                None, functools.partial(func, ctx, **kwargs)
                            ),
                            timeout=timeout,
                        )
                    else:
                        result = await asyncio.wait_for(
                            loop.run_in_executor(
                                None, functools.partial(func, **kwargs)
                            ),
                            timeout=timeout,
                        )
            else:
                # Fallback: positional args
                if asyncio.iscoroutinefunction(func):
                    if has_ctx:
                        result = await asyncio.wait_for(
                            func(ctx, *args),
                            timeout=timeout,
                        )
                    else:
                        result = await asyncio.wait_for(
                            func(*args),
                            timeout=timeout,
                        )
                else:
                    loop = asyncio.get_event_loop()
                    if has_ctx:
                        result = await asyncio.wait_for(
                            loop.run_in_executor(None, func, ctx, *args),
                            timeout=timeout,
                        )
                    else:
                        result = await asyncio.wait_for(
                            loop.run_in_executor(None, func, *args),
                            timeout=timeout,
                        )
            
            if isinstance(result, str):
                return result
            return json.dumps(result)
            
        except asyncio.TimeoutError:
            raise TimeoutError(f"Callable script timed out after {timeout}s")


# =============================================================================
# Agent Skills Toolset
# =============================================================================


@dataclass
class AgentSkillResource:
    """A resource file associated with a skill.
    
    Aligned with pydantic-ai's SkillResource from PR #3780.
    """
    name: str
    content: str | None = None
    path: Path | None = None
    
    async def read(self) -> str:
        """Read the resource content."""
        if self.content is not None:
            return self.content
        if self.path is not None:
            return self.path.read_text()
        return ""


@dataclass
class AgentSkillScript:
    """A script that can be executed as part of a skill.
    
    Aligned with pydantic-ai's SkillScript from PR #3780.
    """
    name: str
    path: Path | None = None
    callable: Callable | None = None
    description: str = ""
    
    def is_callable(self) -> bool:
        """Check if this is a callable (programmatic) script."""
        return self.callable is not None


@dataclass
class AgentSkill:
    """A skill definition compatible with pydantic-ai's Skill.
    
    This extends the pydantic-ai Skill model with Datalayer-specific features
    while maintaining full compatibility.
    
    Example:
        # From filesystem (SKILL.md)
        skill = AgentSkill.from_skill_md(path)
        
        # Programmatic
        skill = AgentSkill(
            name="my-skill",
            description="Does something useful",
            content="Instructions for the skill...",
        )
        
        @skill.script
        async def run(ctx, input: str) -> str:
            return f"Result: {input}"
    """
    name: str
    description: str
    content: str = ""
    path: Path | None = None
    resources: list[AgentSkillResource] = field(default_factory=list)
    scripts: list[AgentSkillScript] = field(default_factory=list)
    
    # Datalayer-specific fields
    tags: list[str] = field(default_factory=list)
    version: str = "1.0.0"
    author: str | None = None
    allowed_tools: list[str] = field(default_factory=list)
    denied_tools: list[str] = field(default_factory=list)
    license: str | None = None
    compatibility: str | None = None
    metadata: dict[str, str] = field(default_factory=dict)
    
    def resource(self, func: Callable) -> Callable:
        """Decorator to add a callable resource to the skill.
        
        Example:
            @skill.resource
            def get_context() -> str:
                return "Dynamic context..."
        """
        name = func.__name__
        # For callable resources, we store them differently
        # This creates a resource that will be evaluated on read
        self.resources.append(AgentSkillResource(
            name=name,
            content=None,  # Will be populated dynamically
            path=None,
        ))
        return func
    
    def script(self, func: Callable) -> Callable:
        """Decorator to add a callable script to the skill.
        
        Example:
            @skill.script
            async def process(ctx: RunContext, data: str) -> str:
                result = await ctx.deps.db.query(data)
                return str(result)
        """
        name = func.__name__
        self.scripts.append(AgentSkillScript(
            name=name,
            path=None,
            callable=func,
            description=func.__doc__ or "",
        ))
        return func
    
    @staticmethod
    def _extract_script_schema(script_path: Path) -> dict[str, Any]:
        """Extract input/output schema from a Python script file.

        Uses AST to parse the file and extract:
        - Module docstring (usage instructions)
        - Main function signature (parameters with types)
        - Return type annotation
        - Argparse argument definitions

        Args:
            script_path: Path to a .py script file.

        Returns:
            Dict with keys: ``description``, ``parameters``, ``returns``,
            ``usage``, ``env_vars``.
        """
        import ast
        import re

        schema: dict[str, Any] = {
            "description": "",
            "parameters": [],
            "returns": "",
            "usage": "",
            "env_vars": [],
        }

        try:
            source = script_path.read_text()
        except Exception:
            return schema

        # --- Parse the AST ---
        try:
            tree = ast.parse(source)
        except SyntaxError:
            return schema

        # Module docstring
        module_doc = ast.get_docstring(tree) or ""
        if module_doc:
            # First non-blank line is the summary
            lines = [l.strip() for l in module_doc.splitlines() if l.strip()]
            if lines:
                schema["description"] = lines[0]

            # Extract Usage: line
            usage_match = re.search(r"Usage:\s*(.+)", module_doc)
            if usage_match:
                schema["usage"] = usage_match.group(1).strip()

            # Extract environment variable names
            env_section = re.search(
                r"Environment:\s*\n((?:\s+\S+.*\n?)+)", module_doc
            )
            if env_section:
                for env_match in re.finditer(
                    r"^\s+(\w+)", env_section.group(1), re.MULTILINE
                ):
                    schema["env_vars"].append(env_match.group(1))

        # --- Find the main public function ---
        # Heuristic: first top-level function that doesn't start with '_'
        # and isn't 'main' or a helper like 'get_*_headers'.
        main_func: ast.FunctionDef | ast.AsyncFunctionDef | None = None
        for node in ast.iter_child_nodes(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                name = node.name
                if (
                    not name.startswith("_")
                    and name != "main"
                    and not name.startswith("get_")
                    and not name.startswith("format_")
                ):
                    main_func = node
                    break

        if main_func is not None:
            # Function docstring – often has a richer description
            func_doc = ast.get_docstring(main_func) or ""
            if func_doc:
                first_line = func_doc.splitlines()[0].strip()
                if first_line and not schema["description"]:
                    schema["description"] = first_line

                # Parse Google-style "Args:" section from docstring.
                # Use DOTALL so .*? can span blank lines, stop at next section.
                args_section = re.search(
                    r"Args:\s*\n(.*?)(?=\n\s*(?:Returns|Raises|Note|Example|Yields|Attributes):|\Z)",
                    func_doc,
                    re.DOTALL,
                )
                if args_section:
                    for param_match in re.finditer(
                        r"^\s+(\w+)(?:\s*\(([^)]+)\))?:\s*(.+)",
                        args_section.group(1),
                        re.MULTILINE,
                    ):
                        schema["parameters"].append({
                            "name": param_match.group(1),
                            "type": param_match.group(2) or "",
                            "description": param_match.group(3).strip(),
                        })

                # Parse "Returns:" section
                returns_match = re.search(
                    r"Returns:\s*\n\s+(.+)", func_doc
                )
                if returns_match:
                    schema["returns"] = returns_match.group(1).strip()

            # If no params from docstring, extract from function signature
            if not schema["parameters"]:
                for arg in main_func.args.args:
                    if arg.arg in ("self", "cls"):
                        continue
                    param: dict[str, str] = {"name": arg.arg}
                    if arg.annotation:
                        param["type"] = ast.unparse(arg.annotation)
                    schema["parameters"].append(param)

            # Return type annotation
            if main_func.returns and not schema["returns"]:
                schema["returns"] = ast.unparse(main_func.returns)

        # --- Extract argparse arguments (covers scripts without a main func) ---
        argparse_params = AgentSkill._extract_argparse_args(tree)
        if argparse_params and not schema["parameters"]:
            schema["parameters"] = argparse_params

        return schema

    @staticmethod
    def _extract_argparse_args(tree: Any) -> list[dict[str, str]]:
        """Extract argument definitions from argparse calls in the AST.

        Looks for ``parser.add_argument(...)`` calls and extracts the
        argument name, type, and help text.
        """
        import ast

        params: list[dict[str, str]] = []
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            func = node.func
            if not (
                isinstance(func, ast.Attribute)
                and func.attr == "add_argument"
            ):
                continue

            # Positional name from first string arg
            name = ""
            for a in node.args:
                if isinstance(a, ast.Constant) and isinstance(a.value, str):
                    raw = a.value.lstrip("-")
                    if raw:
                        name = raw.replace("-", "_")
                        break

            if not name:
                continue

            param: dict[str, str] = {"name": name}
            for kw in node.keywords:
                if kw.arg == "help" and isinstance(kw.value, ast.Constant):
                    param["description"] = str(kw.value.value)
                elif kw.arg == "type" and isinstance(kw.value, ast.Name):
                    param["type"] = kw.value.id
                elif kw.arg == "choices":
                    if isinstance(kw.value, ast.List):
                        choices = [
                            str(e.value)
                            for e in kw.value.elts
                            if isinstance(e, ast.Constant)
                        ]
                        param["choices"] = ", ".join(choices)
            params.append(param)

        return params

    @classmethod
    def from_skill_md(cls, skill_path: Path) -> "AgentSkill":
        """Load a skill from a SKILL.md file.
        
        Parses YAML frontmatter and discovers resources/scripts.
        Script descriptions are enriched by reading each script file
        to extract input/output schemas via AST analysis.
        
        Args:
            skill_path: Path to SKILL.md file or skill directory.
            
        Returns:
            Loaded skill.
        """
        import yaml
        
        if skill_path.is_dir():
            skill_md = skill_path / "SKILL.md"
        else:
            skill_md = skill_path
            skill_path = skill_md.parent
        
        if not skill_md.exists():
            raise FileNotFoundError(f"SKILL.md not found: {skill_md}")
        
        content = skill_md.read_text()
        
        # Parse YAML frontmatter
        if content.startswith("---"):
            parts = content.split("---", 2)
            if len(parts) >= 3:
                yaml_content = parts[1]
                markdown_content = parts[2].strip()
                try:
                    metadata = yaml.safe_load(yaml_content) or {}
                except yaml.YAMLError:
                    metadata = {}
            else:
                metadata = {}
                markdown_content = content
        else:
            metadata = {}
            markdown_content = content
        
        # Extract metadata
        name = metadata.get("name")
        description = metadata.get("description")

        if not name or not description:
            raise ValueError("Invalid SKILL.md format: name and description are required")
        version = metadata.get("version", "1.0.0")
        tags = metadata.get("tags", [])
        author = metadata.get("author")
        license_name = metadata.get("license")
        compatibility = metadata.get("compatibility")
        metadata_map = metadata.get("metadata", {})

        allowed_tools = metadata.get("allowed-tools", [])
        if isinstance(allowed_tools, str):
            allowed_tools = [t for t in allowed_tools.split(" ") if t]

        denied_tools = metadata.get("denied-tools", [])
        if isinstance(denied_tools, str):
            denied_tools = [t for t in denied_tools.split(" ") if t]
        
        # Discover resources
        resources = []
        for resource_dir_name in ["resources", "references", "assets"]:
            resources_dir = skill_path / resource_dir_name
            if resources_dir.exists():
                for res_file in resources_dir.iterdir():
                    if res_file.is_file():
                        resources.append(AgentSkillResource(
                            name=f"{resource_dir_name}/{res_file.name}",
                            path=res_file,
                        ))
        
        # Also check for common resource files in skill root
        for res_name in ["REFERENCE.md", "FORMS.md", "TEMPLATES.md"]:
            res_path = skill_path / res_name
            if res_path.exists():
                resources.append(AgentSkillResource(
                    name=res_name,
                    path=res_path,
                ))
        
        # Discover scripts and extract schemas from their content
        scripts = []
        scripts_dir = skill_path / "scripts"
        if scripts_dir.exists():
            for script_file in sorted(scripts_dir.glob("*.py")):
                schema = cls._extract_script_schema(script_file)
                # Build a rich description from the extracted schema
                desc_parts = []
                if schema["description"]:
                    desc_parts.append(schema["description"])
                else:
                    desc_parts.append(f"Script: {script_file.name}")
                if schema["parameters"]:
                    param_strs = []
                    for p in schema["parameters"]:
                        s = p["name"]
                        if p.get("type"):
                            s += f": {p['type']}"
                        if p.get("description"):
                            s += f" — {p['description']}"
                        param_strs.append(s)
                    desc_parts.append("Parameters: " + "; ".join(param_strs))
                if schema["returns"]:
                    desc_parts.append(f"Returns: {schema['returns']}")
                if schema["env_vars"]:
                    desc_parts.append(
                        f"Env: {', '.join(schema['env_vars'])}"
                    )
                script_description = ". ".join(desc_parts)
                scripts.append(AgentSkillScript(
                    name=script_file.stem,
                    path=script_file,
                    description=script_description,
                ))
        
        return cls(
            name=name,
            description=description,
            content=markdown_content,
            path=skill_path,
            resources=resources,
            scripts=scripts,
            tags=tags,
            version=version,
            author=author,
            allowed_tools=allowed_tools,
            denied_tools=denied_tools,
            license=license_name,
            compatibility=compatibility,
            metadata=metadata_map or {},
        )
    
    @classmethod
    def from_package(
        cls,
        package: str,
        method: str,
        *,
        name: str | None = None,
        description: str | None = None,
        version: str = "1.0.0",
        tags: list[str] | None = None,
        author: str | None = None,
    ) -> "AgentSkill":
        """Load a skill from a Python package and method name.
        
        This is the variant 2 loading mechanism: the skill is resolved by
        importing a Python package and locating a callable within it.
        Attributes such as license, compatibility, allowed-tools, and
        metadata are discovered from a ``SKILL.md`` file packaged alongside
        the module (inside the same directory as ``__init__.py``).
        
        Args:
            package: Dotted Python package path (e.g. ``agent_skills.skills.text_summarizer``).
            method: Name of the callable in the package.
            name: Skill name override (defaults to SKILL.md frontmatter, then method name).
            description: Skill description override (defaults to SKILL.md frontmatter, then docstring).
            version: Skill version fallback.
            tags: Tags fallback.
            author: Skill author fallback.
            
        Returns:
            Loaded AgentSkill with the callable attached as a script.
            
        Raises:
            ImportError: If the package cannot be imported.
            AttributeError: If the method is not found in the package.
        """
        import importlib
        
        mod = importlib.import_module(package)
        func = getattr(mod, method)
        
        # Discover SKILL.md from the package directory
        skill_dir = cls._module_dir(mod)
        skill_md_path = skill_dir / "SKILL.md" if skill_dir else None
        
        if skill_md_path and skill_md_path.exists():
            # Parse the SKILL.md to get all attributes
            skill = cls.from_skill_md(skill_md_path)
            # Override with explicit arguments if provided
            if name:
                skill.name = name
            if description:
                skill.description = description
                skill.content = description
            if tags is not None:
                skill.tags = tags
            if author is not None:
                skill.author = author
            # Attach the callable as a script (in addition to any discovered scripts)
            skill.scripts.append(AgentSkillScript(
                name=method,
                callable=func,
                description=func.__doc__ or "",
            ))
            logger.info(
                f"Loaded skill from package with SKILL.md: {skill.name} "
                f"({package}.{method})"
            )
            return skill
        
        # Fallback: no SKILL.md found, use basic metadata
        skill_name = name or method
        skill_description = description or (func.__doc__ or "").strip().split("\n")[0] or f"Skill: {skill_name}"
        
        skill = cls(
            name=skill_name,
            description=skill_description,
            content=skill_description,
            tags=tags or [],
            version=version,
            author=author,
            metadata={},
        )
        
        # Attach the callable as a script
        skill.scripts.append(AgentSkillScript(
            name=method,
            callable=func,
            description=func.__doc__ or "",
        ))
        
        logger.info(
            f"Loaded skill from package (no SKILL.md): {skill_name} "
            f"({package}.{method})"
        )
        
        return skill

    @staticmethod
    def _module_dir(module: Any) -> Path | None:
        """Return the directory that contains a module's files.

        Handles both regular packages (``module.__file__`` is set) and
        **namespace packages** (no ``__init__.py``, so ``__file__`` is
        ``None`` but ``__spec__.submodule_search_locations`` is populated).

        Args:
            module: An imported Python module object.

        Returns:
            Resolved directory ``Path`` or ``None`` if not determinable.
        """
        mod_file = getattr(module, "__file__", None)
        if mod_file:
            return Path(mod_file).resolve().parent
        # Namespace package: __file__ is None; use the first search location.
        locs = getattr(
            getattr(module, "__spec__", None),
            "submodule_search_locations",
            None,
        )
        if locs:
            return Path(locs[0])
        return None

    @classmethod
    def from_module(cls, module_name: str) -> "AgentSkill":
        """Load a skill from a Python module path.

        Imports *module_name*, locates the ``SKILL.md`` file next to the
        module (works for both regular and namespace packages), and returns
        the parsed skill.

        This is the canonical loading path for *module-based* skills, i.e.
        skills stored inside an installed Python package as a directory
        containing a ``SKILL.md`` file and a ``scripts/`` sub-directory.

        Example::

            skill = AgentSkill.from_module("agent_skills.skills.crawl")

        Args:
            module_name: Dotted Python module path.

        Returns:
            Loaded :class:`AgentSkill`.

        Raises:
            ImportError: If *module_name* cannot be imported.
            FileNotFoundError: If no ``SKILL.md`` exists next to the module.
        """
        import importlib

        module = importlib.import_module(module_name)
        skill_dir = cls._module_dir(module)
        if not skill_dir:
            raise FileNotFoundError(
                f"Cannot determine directory for module '{module_name}': "
                "neither __file__ nor __spec__.submodule_search_locations is set"
            )
        skill_md = skill_dir / "SKILL.md"
        if not skill_md.exists():
            raise FileNotFoundError(
                f"No SKILL.md found for module '{module_name}' in {skill_dir}"
            )
        return cls.from_skill_md(skill_md)

    def get_skills_header(self) -> str:
        """Get a brief header for system prompt injection.
        
        Used for progressive disclosure - only the header is shown initially.
        """
        location = str(self.path) if self.path else "programmatic"
        safe_name = self.name.replace('"', "'")
        safe_description = self.description.replace('"', "'")
        safe_location = location.replace('"', "'")
        return (
            f"<skill name=\"{safe_name}\" "
            f"description=\"{safe_description}\" "
            f"location=\"{safe_location}\" />"
        )
    
    def get_full_content(self) -> str:
        """Get full skill content for load_skill().
        
        Returns the complete SKILL.md content plus resource/script listings.
        """
        lines = [
            f"# Skill: {self.name}",
            f"**Description:** {self.description}",
            f"**Path:** {self.path or 'programmatic'}",
        ]

        if self.allowed_tools:
            lines.append(f"**Allowed Tools:** {', '.join(self.allowed_tools)}")
        if self.denied_tools:
            lines.append(f"**Denied Tools:** {', '.join(self.denied_tools)}")
        if self.license:
            lines.append(f"**License:** {self.license}")
        if self.compatibility:
            lines.append(f"**Compatibility:** {self.compatibility}")
        if self.metadata:
            lines.append(f"**Metadata:** {self.metadata}")
        
        if self.resources:
            lines.append("**Available Resources:**")
            for res in self.resources:
                lines.append(f"- {res.name}")
        else:
            lines.append("**Available Resources:** None")
        
        if self.scripts:
            lines.append("**Available Scripts:**")
            for script in self.scripts:
                if script.description and script.description != f"Script: {script.name}.py":
                    lines.append(f"- **{script.name}**: {script.description}")
                else:
                    lines.append(f"- {script.name}")
                # Show parameter signature for callable scripts
                if script.callable is not None:
                    import inspect
                    try:
                        sig = inspect.signature(script.callable)
                        param_parts = []
                        for pname, param in sig.parameters.items():
                            if pname in ('ctx', 'context', 'run_context'):
                                continue
                            annotation = param.annotation
                            if annotation is inspect.Parameter.empty:
                                type_str = "any"
                            elif isinstance(annotation, str):
                                type_str = annotation
                            elif hasattr(annotation, '__name__'):
                                type_str = annotation.__name__
                            else:
                                type_str = str(annotation)
                            if param.default is not inspect.Parameter.empty:
                                param_parts.append(f"{pname}: {type_str} = {param.default!r}")
                            else:
                                param_parts.append(f"{pname}: {type_str}")
                        if param_parts:
                            lines.append(f"  Parameters (use kwargs): {', '.join(param_parts)}")
                    except (ValueError, TypeError):
                        pass
        else:
            lines.append("**Available Scripts:** None")
        
        lines.append("")
        lines.append("---")
        lines.append("")
        lines.append(self.content)
        
        return "\n".join(lines)


# =============================================================================
# Skills Toolset for Pydantic-AI
# =============================================================================


try:
    from pydantic_ai.toolsets import AbstractToolset
    from pydantic_ai.toolsets.abstract import ToolsetTool
    from pydantic_ai.tools import ToolDefinition
    from pydantic_ai._run_context import RunContext
    from pydantic_core import SchemaValidator, core_schema
    
    PYDANTIC_AI_AVAILABLE = True
except ImportError:
    PYDANTIC_AI_AVAILABLE = False
    AbstractToolset = object  # Fallback for type hints


if PYDANTIC_AI_AVAILABLE:
    
    # Schema validator for any args
    SKILL_ARGS_VALIDATOR = SchemaValidator(schema=core_schema.any_schema())
    
    @dataclass
    class AgentSkillsToolset(AbstractToolset):
        """Skills toolset for pydantic-ai with Datalayer extensions.

        Provides the standard skills tools:

        - ``list_skills()`` — list available skills
        - ``load_skill(skill_name)`` — load full skill content
        - ``read_skill_resource(skill_name, resource_name)`` — read a resource
        - ``run_skill_script(skill_name, script_name, args)`` — execute a script

        Skills can be supplied via **two complementary mechanisms** that can be
        combined freely:

        **Path-based** — point ``directories`` at one or more filesystem paths;
        every sub-directory containing a ``SKILL.md`` file is auto-discovered
        when the toolset is first used::

            from agent_skills import AgentSkillsToolset, SandboxExecutor
            from code_sandboxes import LocalEvalSandbox
            from pydantic_ai import Agent

            toolset = AgentSkillsToolset(
                directories=["./skills"],
                executor=SandboxExecutor(LocalEvalSandbox()),
            )
            agent = Agent(model='openai:gpt-4o', toolsets=[toolset])

        **Module-based** — use ``AgentSkill.from_module()`` to load skills
        that are packaged inside an installed Python library, then pass them
        via ``skills=``::

            from agent_skills import AgentSkill, AgentSkillsToolset, SandboxExecutor
            from code_sandboxes import LocalEvalSandbox
            from pydantic_ai import Agent

            toolset = AgentSkillsToolset(
                skills=[
                    AgentSkill.from_module("my_library.skills.parser"),
                    AgentSkill.from_module("my_library.skills.formatter"),
                ],
                executor=SandboxExecutor(LocalEvalSandbox()),
            )
            agent = Agent(model='openai:gpt-4o', toolsets=[toolset])
        """
        
        directories: list[str | Path] = field(default_factory=list)
        skills: list[AgentSkill] = field(default_factory=list)
        executor: SandboxExecutor | None = None
        script_timeout: int = 30
        _id: str | None = None
        
        # Internal state
        _discovered_skills: dict[str, AgentSkill] = field(
            default_factory=dict, repr=False
        )
        _initialized: bool = field(default=False, repr=False)
        _skills_call_count: int = field(default=0, repr=False)
        
        def __post_init__(self):
            # Add programmatic skills
            for skill in self.skills:
                self._discovered_skills[skill.name] = skill
        
        @property
        def id(self) -> str | None:
            return self._id
        
        @property
        def label(self) -> str:
            return "Agent Skills Toolset"
        
        async def _ensure_initialized(self) -> None:
            """Discover skills from directories if not already done."""
            if self._initialized:
                return
            
            for directory in self.directories:
                dir_path = Path(directory)
                if not dir_path.exists():
                    logger.warning(f"Skills directory not found: {dir_path}")
                    continue
                
                # Look for SKILL.md files
                for skill_md in dir_path.rglob("SKILL.md"):
                    try:
                        skill = AgentSkill.from_skill_md(skill_md)
                        if skill.name not in self._discovered_skills:
                            self._discovered_skills[skill.name] = skill
                            logger.debug(f"Discovered skill: {skill.name}")
                    except Exception as e:
                        logger.warning(f"Failed to load skill from {skill_md}: {e}")
            
            self._initialized = True
            logger.info(f"Discovered {len(self._discovered_skills)} skills")
        
        async def get_tools(self, ctx: RunContext) -> dict[str, ToolsetTool]:
            """Get the tools provided by this toolset."""
            await self._ensure_initialized()
            
            tools = {}
            
            # list_skills tool
            tools["list_skills"] = ToolsetTool(
                toolset=self,
                tool_def=ToolDefinition(
                    name="list_skills",
                    description="List all available skills with their names and descriptions.",
                    parameters_json_schema={
                        "type": "object",
                        "properties": {},
                        "required": [],
                    },
                ),
                max_retries=0,
                args_validator=SKILL_ARGS_VALIDATOR,
            )
            
            # load_skill tool
            tools["load_skill"] = ToolsetTool(
                toolset=self,
                tool_def=ToolDefinition(
                    name="load_skill",
                    description="Load the full content and instructions for a skill.",
                    parameters_json_schema={
                        "type": "object",
                        "properties": {
                            "skill_name": {
                                "type": "string",
                                "description": "Name of the skill to load",
                            },
                        },
                        "required": ["skill_name"],
                    },
                ),
                max_retries=1,
                args_validator=SKILL_ARGS_VALIDATOR,
            )
            
            # read_skill_resource tool
            tools["read_skill_resource"] = ToolsetTool(
                toolset=self,
                tool_def=ToolDefinition(
                    name="read_skill_resource",
                    description="Read a resource file from a skill.",
                    parameters_json_schema={
                        "type": "object",
                        "properties": {
                            "skill_name": {
                                "type": "string",
                                "description": "Name of the skill",
                            },
                            "resource_name": {
                                "type": "string",
                                "description": "Name of the resource to read",
                            },
                        },
                        "required": ["skill_name", "resource_name"],
                    },
                ),
                max_retries=1,
                args_validator=SKILL_ARGS_VALIDATOR,
            )
            
            # run_skill_script tool
            tools["run_skill_script"] = ToolsetTool(
                toolset=self,
                tool_def=ToolDefinition(
                    name="run_skill_script",
                    description="Execute a script from a skill. Use 'kwargs' (preferred) to pass named parameters, or 'args' for positional arguments. Call load_skill first to see available scripts and their parameters.",
                    parameters_json_schema={
                        "type": "object",
                        "properties": {
                            "skill_name": {
                                "type": "string",
                                "description": "Name of the skill",
                            },
                            "script_name": {
                                "type": "string",
                                "description": "Name of the script to run",
                            },
                            "args": {
                                "type": "array",
                                "items": {"type": "string"},
                                "description": "Positional arguments to pass to the script (deprecated, prefer kwargs)",
                                "default": [],
                            },
                            "kwargs": {
                                "type": "object",
                                "description": "Named keyword arguments to pass to the script. Keys are parameter names, values are parameter values. Preferred over positional args.",
                                "default": {},
                            },
                        },
                        "required": ["skill_name", "script_name"],
                    },
                ),
                max_retries=1,
                args_validator=SKILL_ARGS_VALIDATOR,
            )
            
            return tools
        
        async def call_tool(
            self,
            name: str,
            tool_args: dict[str, Any],
            ctx: RunContext,
            tool: ToolsetTool,
        ) -> Any:
            """Call a tool by name."""
            await self._ensure_initialized()
            self._skills_call_count += 1
            
            if name == "list_skills":
                return self._list_skills()
            elif name == "load_skill":
                return self._load_skill(tool_args.get("skill_name", ""))
            elif name == "read_skill_resource":
                return await self._read_skill_resource(
                    tool_args.get("skill_name", ""),
                    tool_args.get("resource_name", ""),
                )
            elif name == "run_skill_script":
                return await self._run_skill_script(
                    tool_args.get("skill_name", ""),
                    tool_args.get("script_name", ""),
                    tool_args.get("args", []),
                    tool_args.get("kwargs", {}),
                    ctx,
                )
            else:
                raise ValueError(f"Unknown tool: {name}")
        
        def get_call_counts(self) -> dict[str, int]:
            """Return counts for skills tool calls."""
            return {
                "skills_tool_calls": self._skills_call_count,
            }
        
        def _list_skills(self) -> str:
            """List all available skills."""
            if not self._discovered_skills:
                return "No skills available."
            
            lines = ["Available skills:"]
            for skill in self._discovered_skills.values():
                lines.append(skill.get_skills_header())
            
            return "\n".join(lines)
        
        def _load_skill(self, skill_name: str) -> str:
            """Load full skill content."""
            skill = self._discovered_skills.get(skill_name)
            if not skill:
                return f"Skill not found: {skill_name}"
            
            return skill.get_full_content()
        
        async def _read_skill_resource(
            self,
            skill_name: str,
            resource_name: str,
        ) -> str:
            """Read a skill resource."""
            skill = self._discovered_skills.get(skill_name)
            if not skill:
                return f"Skill not found: {skill_name}"
            
            for resource in skill.resources:
                if resource.name == resource_name:
                    return await resource.read()
            
            return f"Resource not found: {resource_name}"
        
        async def _run_skill_script(
            self,
            skill_name: str,
            script_name: str,
            args: list[str],
            kwargs: dict[str, Any],
            ctx: RunContext,
        ) -> ScriptExecutionResult:
            """Run a skill script.
            
            Returns:
                ScriptExecutionResult with output, exit_code, and error details.
            """
            skill = self._discovered_skills.get(skill_name)
            if not skill:
                return ScriptExecutionResult(
                    success=False,
                    output="",
                    stdout="",
                    stderr="",
                    execution_ok=False,
                    execution_error=f"Skill not found: {skill_name}",
                    code_error=None,
                    exit_code=None,
                    error=f"Skill not found: {skill_name}",
                )
            
            # Find the script
            script = None
            for s in skill.scripts:
                if s.name == script_name:
                    script = s
                    break
            
            if not script:
                return ScriptExecutionResult(
                    success=False,
                    output="",
                    stdout="",
                    stderr="",
                    execution_ok=False,
                    execution_error=f"Script not found: {script_name}",
                    code_error=None,
                    exit_code=None,
                    error=f"Script not found: {script_name}",
                )
            
            # Execute
            try:
                if script.is_callable():
                    # Programmatic script - returns string, wrap it
                    callable_executor = CallableExecutor(
                        default_timeout=self.script_timeout
                    )
                    output = await callable_executor.execute_callable(
                        script.callable,
                        ctx,
                        args,
                        kwargs,
                        self.script_timeout,
                    )
                    return ScriptExecutionResult(
                        success=True,
                        output=output,
                        stdout=output,
                        stderr="",
                        execution_ok=True,
                        execution_error=None,
                        code_error=None,
                        exit_code=0,
                        error=None,
                    )
                elif self.executor and script.path:
                    # File-based script: convert kwargs to CLI flags
                    effective_args = list(args)
                    if kwargs:
                        for key, value in kwargs.items():
                            flag = f"--{key.replace('_', '-')}"
                            effective_args.append(flag)
                            effective_args.append(str(value))
                    return await self.executor.execute(
                        skill_name=skill_name,
                        script_name=script_name,
                        script_path=script.path,
                        args=effective_args,
                        timeout=self.script_timeout,
                    )
                else:
                    return ScriptExecutionResult(
                        success=False,
                        output="",
                        stdout="",
                        stderr="",
                        execution_ok=False,
                        execution_error=f"No executor configured for script: {script_name}",
                        code_error=None,
                        exit_code=None,
                        error=f"No executor configured for script: {script_name}",
                    )
            except TimeoutError as e:
                return ScriptExecutionResult(
                    success=False,
                    output="",
                    stdout="",
                    stderr="",
                    execution_ok=False,
                    execution_error=f"Script timed out: {e}",
                    code_error=None,
                    exit_code=None,
                    error=f"Script timed out: {e}",
                )
            except Exception as e:
                return ScriptExecutionResult(
                    success=False,
                    output="",
                    stdout="",
                    stderr=str(e),
                    execution_ok=False,
                    execution_error=str(e),
                    code_error=None,
                    exit_code=None,
                    error=f"Script failed: {e}",
                )
        
        async def get_instructions(self, ctx: RunContext | None = None) -> str:
            """Get instructions for system prompt injection.
            
            This implements the get_instructions() method proposed in PR #3780
            for automatic system prompt integration.
            """
            if not self._discovered_skills:
                return ""
            
            lines = [
                "<skills>",
                "You have access to skills that extend your capabilities.",
                "Skills are modular packages with instructions, resources, and scripts.",
                "",
                "<available_skills>",
            ]
            
            for skill in self._discovered_skills.values():
                lines.append(skill.get_skills_header())
            
            lines.extend([
                "</available_skills>",
                "",
                "<usage>",
                "1. Use load_skill(skill_name) to read full instructions",
                "2. Use read_skill_resource(skill_name, resource) for docs",
                "3. Use run_skill_script(skill_name, script, args) to execute",
                "</usage>",
                "</skills>",
            ])
            
            return "\n".join(lines)


else:
    # Fallback when pydantic-ai is not available
    class AgentSkillsToolset:  # type: ignore
        """Placeholder when pydantic-ai is not installed."""
        
        def __init__(self, *args, **kwargs):
            raise ImportError(
                "pydantic-ai with skills support is required. "
                "Install with: pip install pydantic-ai @ git+https://github.com/DougTrajano/pydantic-ai.git@DEV-1099"
            )
