# deepKernel

`deepKernel` 是一个deepline的二次开发的 Python 接口包。

## 依赖清单 (Dependencies)

本包目前无任何第三方依赖，您可以直接安装使用。

## 接口文档与更新日志 (Documentation & Changelog)

为了提供更清晰、结构化的阅读体验，本项目的详细 **API 接口说明** 以及历史 **版本变更记录** 均已迁移至独立的 Gitee 仓库进行开源托管。

请点击下方链接查阅最新文档：

- **[API 接口参考文档 (API Document)](https://gitee.com/the-sky_fly/deep-kernel_api_docs-and-changelog/blob/master/API_Document.md)**
  *(包含所有可用模块的方法说明、参数定义及代码调用示例)*

- **[版本更新日志 (Changelog)](https://gitee.com/the-sky_fly/deep-kernel_api_docs-and-changelog/blob/master/ChangeLog.md)**
  *(包含从 0.0.5 初始版本至今的所有功能迭代、修复与废弃记录)*

---

### 常用链接
* [文档仓库主页 (Gitee Repository)](https://gitee.com/the-sky_fly/deep-kernel_api_docs-and-changelog)
* [官方主页 (Homepage)](https://www.pzeda.com/CN)