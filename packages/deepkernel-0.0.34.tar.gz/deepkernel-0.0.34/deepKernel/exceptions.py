import json


class DeepKernelBaseError(Exception):
    """
    deepKernel 架构富上下文异常基类
    """

    def __init__(self, message: str, api_name: str = "Unknown", payload: dict = None,
                 inner_exception: Exception = None):
        self.message = message
        self.api_name = api_name
        self.payload = payload or {}
        self.inner_exception = inner_exception
        super().__init__(self.__str__())

    def __str__(self):
        # 自动格式化出一份完美的“验尸报告”
        error_report = [
            f"\n{'=' * 50}",
            f"[DeepKernel 运行异常] API: {self.api_name}",
            f"错误原因: {self.message}",
        ]
        if self.payload:
            # 格式化打印参数，方便开发者直接复制去排查
            try:
                formatted_payload = json.dumps(self.payload, indent=2, ensure_ascii=False)
                error_report.append(f"请求参数 (Payload):\n{formatted_payload}")
            except Exception:
                error_report.append(f"请求参数: {self.payload}")

        if self.inner_exception:
            error_report.append(f"底层原生报错 (Inner): {repr(self.inner_exception)}")

        error_report.append(f"{'=' * 50}\n")
        return "\n".join(error_report)


class DeepKernelProtocolError(DeepKernelBaseError):
    """协议层异常（参数错误、JSON 序列化/反序列化失败等）"""

    def __init__(self, message: str, api_name: str, payload: dict = None, raw_response: str = None,
                 inner_exception=None):
        super().__init__(message, api_name, payload, inner_exception)
        self.raw_response = raw_response

    def __str__(self):
        report = super().__str__()
        if self.raw_response:
            report += f"\n[C++ 原始返回内容]:\n{self.raw_response}\n"
        return report


class DeepKernelCtypeError(DeepKernelBaseError):
    """底层通信异常（DLL调用崩溃、返回空指针等严重系统错误）"""
    pass


class DeepKernelBusinessError(DeepKernelBaseError):
    """业务执行失败（C++ 正常解析但业务逻辑拒绝执行，如项目已存在等）"""

    def __init__(self, message: str, api_name: str, payload: dict = None, status_code: str = "false"):
        super().__init__(message, api_name, payload)
        self.status_code = status_code
