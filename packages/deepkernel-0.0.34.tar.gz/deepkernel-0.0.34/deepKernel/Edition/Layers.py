import json
import math

from deepKernel import base
from deepKernel.Action import Selection, Information
from deepKernel.Edition import Matrix, Layers


def copy2otherLayer(src_job: str, src_step: str, src_layer: str, dst_layer: str, invert: bool, offset_x: int,
                    offset_y: int, mirror: int, resize: float, rotation: float, x_anchor: float,
                    y_anchor: float) -> bool:
    try:
        ret = base.selCopyOther(src_job, src_step, [src_layer], [dst_layer], invert, offset_x,
                                offset_y, mirror, resize, rotation, x_anchor, y_anchor)
        return base.checkProcessStatus(ret)
    except Exception as e:
        print('copy2otherLayer: ', e)
    return False


def deleteFeature(job: str, step: str, layers: list) -> bool:
    try:
        ret = base.selDelete(job, step, layers)
        return base.checkProcessStatus(ret)
    except Exception as e:
        print('deleteFeature error: ', e)
    return False


def changeText(job: str, step: str, layers: list, text: str, font: str, x_size: int, y_size: int, width: int,
               polarity: bool, mirror: int, angle: int = 0) -> None:
    try:
        if polarity is True:
            polarity = 1
        else:
            polarity = -1
        base.changeText(job, step, layers, text, font, x_size, y_size, width, polarity, mirror, angle)
    except Exception as e:
        print('changeText error: ', e)
    return None


def breakFeatures(job: str, step: str, layers: list, type: int):
    try:
        base.selBreak(job, step, layers, type)
    except Exception as e:
        print('breakFeatures error: ', e)
    return None


def addLine(job: str, step: str, layers: list, symbol: str, start_x: int, start_y: int, end_x: int, end_y: int,
            polarity: bool, attributes: list) -> bool:
    try:
        layer = ''
        if len(layers) > 0:
            layer = layers[0]
        if polarity is True:
            polarity = 1
        else:
            polarity = -1
        ret = base.addLine(job, step, layers, layer, symbol, start_x, start_y, end_x, end_y, polarity, 0, attributes)
        return base.checkProcessStatus(ret)
    except Exception as e:
        print('addLine error: ', e)
    return False


def setFeatureToTopOrBottom(job: str, step: str, layers: list, mode: int) -> bool:
    try:
        ret = base.selIndex(job, step, layers, mode)
        return base.checkProcessStatus(ret)
    except Exception as e:
        print('setFeatureToTopOrBottom error: ', e)
    return False


def addSurface(job: str, step: str, layers: list, polarity: bool, attributes: list, points_location: list) -> bool:
    try:
        layer = ''
        if len(layers) > 0:
            layer = layers[0]
        if polarity is True:
            polarity = 1
        else:
            polarity = -1
        ret = base.addSurface(job, step, layers, layer, polarity, 0, False, attributes, points_location)
        return base.checkProcessStatus(ret)
    except Exception as e:
        print('addSurface error: ', e)
    return False


def addRoundSurface(job: str, step: str, layers: list, polarity: bool, attributes: list, center_x: int, center_y: int,
                    radius: int) -> bool:
    try:
        layer = ''
        if len(layers) > 0:
            layer = layers[0]
        if polarity is True:
            polarity = 1
        else:
            polarity = -1
        point2_x = center_x + radius
        point2_y = center_y
        points_location = [[point2_x, point2_y], [center_x, center_y]]
        ret = base.addSurface(job, step, layers, layer, polarity, 0, True, attributes, points_location)
        return base.checkProcessStatus(ret)
    except Exception as e:
        print('addRoundSurface error: ', e)
    return False


def contour2pad(job: str, step: str, layers: list, tol: float, minsize: float, maxsize: float, suffix: str):
    try:
        base.contour2pad(job, step, layers, tol, minsize, maxsize, suffix)
    except Exception as e:
        print(e)
    return None


def resizePolyline(job: str, step: str, layers: list, size: float, sel_type: bool) -> bool:
    try:
        ret = base.resizePolyline(job, step, layers, size, sel_type)
        return base.checkProcessStatus(ret)
    except Exception as e:
        print('resizePolyline error: ', e)
    return False


def contourize(job: str, step: str, layers: list, accuracy: int, separate_to_islands: bool, size: int,
               mode: int) -> bool:
    try:
        mode = mode + 1
        ret = base.contourize(job, step, layers, accuracy, separate_to_islands, size, mode)
        return base.checkProcessStatus(ret)
    except Exception as e:
        print('contourize error: ', e)
    return False


def addPad(job: str, step: str, layers: list, symbol: str, location_x: int, location_y: int, polarity: bool,
           orient: int, attributes: list, special_angle: float = 0) -> bool:
    try:
        layer = ''
        if len(layers) > 0:
            layer = layers[0]
        if polarity is True:
            polarity = 1
        else:
            polarity = -1
        ret = base.addPad(job, step, layers, layer, symbol, location_x, location_y, polarity, 0, orient,
                          attributes, special_angle)
        return base.checkProcessStatus(ret)
    except Exception as e:
        print('addPad error: ', e)
    return False


def changeFeatureSymbols(job: str, step: str, layers: list, symbol: str, pad_angle: bool = False) -> bool:
    try:
        ret = base.changeFeatureSymbols(job, step, layers, symbol, pad_angle)
        return base.checkProcessStatus(ret)
    except Exception as e:
        print('changeFeatureSymbols error: ', e)
    return False


def createProfile(job: str, step: str, layer: str) -> bool:
    try:
        ret = base.createProfile(job, step, layer)
        return base.checkProcessStatus(ret)
    except Exception as e:
        print('createProfile: ', e)
    return False


def doStepRepeat(job: str, step: str, stepRepeats: list) -> bool:
    """
    #拼板
    :param     job
    :param     step
    :param     stepRepeats
    :returns    :
    :raise error:
    """
    try:
        ret = base.stepRepeat(job, step, stepRepeats)
        return base.checkProcessStatus(ret)
    except Exception as e:
        print("doStepRepeat error: ", e)
    return False


def surfaceRepair(job: str, step: str, layers: list, scope: int, radius: int, remove_type: int, is_round: bool) -> bool:
    try:
        ret = base.removeSharpAngle(job, step, layers, scope, radius, remove_type, is_round)
        return base.checkProcessStatus(ret)
    except Exception as e:
        print('surfaceRepair error: ', e)
    return False


def surface2outline(job: str, step: str, layers: list, width: float) -> bool:
    try:
        ret = base.surface2outline(job, step, layers, width)
        return base.checkProcessStatus(ret)
    except Exception as e:
        print('surface2outline error: ', e)
    return False


def line2pad(job: str, step: str, layers: list) -> bool:
    try:
        ret = base.line2padNew(job, step, layers)
        return base.checkProcessStatus(ret)
    except Exception as e:
        print('line2pad error: ', e)
    return False


def modifyAttributes(job: str, step: str, layers: list, mode: int, attributes: list) -> bool:
    try:
        res = True
        for layer in layers:
            ret = base.editSelectedFeaturesAttributes(job, step, layer, mode, attributes)
            res = base.checkProcessStatus(ret) and res
        return res
    except Exception as e:
        print('modifyAttributes error: ', e)
    return False


def usePatternFillContours(job: str, step: str, layer: str, symbolname: str, dx: int, dy: int, break_partial: bool,
                           cut_primitive: bool, origin_point: bool, outline: bool, outlinewidth: float = 0,
                           outline_invert: bool = False, odd_offset: int = 0, even_offset: int = 0) -> bool:
    try:
        ret = base.usePatternFillContours(job, step, layer, symbolname, dx, dy, break_partial, cut_primitive,
                                          origin_point,
                                          outline, outlinewidth, outline_invert, odd_offset, even_offset)
        return base.checkProcessStatus(ret)
    except Exception as e:
        print('usePatternFillContours error: ', e)
    return False


def addArc(job: str, step: str, layers: list, symbol: str, start_x: float, start_y: float, end_x: float, end_y: float,
           center_x: float, center_y: float, cw: bool, polarity: int, attributes: list) -> bool:
    try:
        layer = ''
        if len(layers) > 0:
            layer = layers[0]
        if polarity is True:
            polarity = 1
        else:
            polarity = -1
        dcode = 0
        ret = base.addArc(job, step, layers, layer, symbol, start_x, start_y, end_x, end_y, center_x, center_y, cw,
                          polarity, dcode, attributes)
        return base.checkProcessStatus(ret)
    except Exception as e:
        print('addArc error: ', e)
    return False


def layerCompare(job1: str, step1: str, layer1: str, job2: str, step2: str, layer2: str, tol: int, isGlobal: bool,
                 consider_SR: bool, comparison_map_layername: str, map_layer_resolution: int) -> bool:
    try:
        ret = base.layerCompare(job1, step1, layer1, job2, step2, layer2, tol, isGlobal, consider_SR,
                                comparison_map_layername, map_layer_resolution)
        return base.checkProcessStatus(ret)
    except Exception as e:
        print('layerCompare error: ', e)
    return False


def addText(job: str, step: str, layers: list, fontname: str, text: str, xsize: int, ysize: int, linewidth: int,
            location_x: int, location_y: int, polarity: bool, orient: int, attributes: list,
            special_angle: float = 0) -> None:
    try:
        layer = ''
        if len(layers) > 0:
            layer = layers[0]
        if polarity is True:
            polarity = 1
        else:
            polarity = -1
        base.addText(job, step, layer, '', fontname, text, xsize, ysize, linewidth, location_x, location_y, polarity,
                     orient, 0, layers, attributes, special_angle)
    except Exception as e:
        print(e)
    return None


def changePolarity(job: str, step: str, layers: list, polarity: int, type: int) -> bool:
    try:
        sel_type = type
        _ret = base.selPolarity(job, step, layers, polarity, sel_type)
        return base.checkProcessStatus(_ret)
    except Exception as e:
        print('changePolarity error: ', e)
    return False


def fillProfile(job: str, step: str, layers: list, fill_type: int = 0, step_repeat_nesting: bool = True,
                nesting_child_steps: list = [], step_margin_x: int = 0, step_margin_y: int = 0, max_distance_x: int = 0,
                max_distance_y: int = 0, SR_step_margin_x: int = 0, SR_step_margin_y: int = 0,
                SR_max_distance_x: int = 0, SR_max_distance_y: int = 0, avoid_drill: int = 0, avoid_rout: int = 0,
                avoid_feature: int = 0, polarity: bool = True) -> bool:
    try:
        info = Information.getFillParam()
        patternParams = info['patternParams']
        solidParams = info['solidParams']
        gridParams = info['gridParams']
        base.setFillParam(fill_type, gridParams, patternParams, solidParams)
        if solidParams['minBrush'] == 0:
            if fill_type == 1 or solidParams['solidType'] is False:
                return False
        else:
            _ret = base.fillProfile(job, step, layers, step_repeat_nesting, nesting_child_steps, step_margin_x,
                                    step_margin_y, max_distance_x, max_distance_y, SR_step_margin_x, SR_step_margin_y,
                                    SR_max_distance_x, SR_max_distance_y, avoid_drill, avoid_rout, avoid_feature,
                                    polarity)
            return base.checkProcessStatus(_ret)
    except Exception as e:
        print('fillProfile error: ', e)
    return False


def resizeGlobal(job: str, step: str, layers: list, type: int, size: int) -> bool:
    try:
        sel_type = type
        ret = base.resizeGlobal(job, step, layers, sel_type, size)
        return base.checkProcessStatus(ret)
    except Exception as e:
        print('resizeGlobal error:', e)
    return False


def useLineFillContours(job: str, step: str, layer: str, dx: int, dy: int, linewidth: int, x_offset: int, y_offset: int,
                        angle: int) -> bool:
    try:
        ret = base.fillSelectFeatureByGrid(job, step, layer, dx, dy, linewidth, x_offset, y_offset, angle)
        return base.checkProcessStatus(ret)
    except Exception as e:
        print('useLineFillContours error: ', e)
    return False


def move2sameLayer(job: str, step: str, layers: list, offset_x: int, offset_y: int) -> bool:
    try:
        jobname = job
        stepname = step
        layernames = layers
        ret = base.moveSameLayer(jobname, stepname, layernames, offset_x, offset_y)
        return base.checkProcessStatus(ret)
    except Exception as e:
        print('move2sameLayer error', e)
    return False


def clipAreaUseReference(job: str, step: str, layers: list, reference_layer: str, margin: float, clipcontour: bool,
                         text: bool, surface: bool, arc: bool, line: bool, pad: bool, smooth_tolerance: float) -> bool:
    try:
        jobname = job
        stepname = step
        work_layers = layers
        positive = True
        negative = True
        featuretype_sum = 0
        featuretype_list = [positive, negative, text, surface, arc, line, pad]
        for index in range(len(featuretype_list)):
            if featuretype_list[index] is True:
                featuretype_list[index] = len(featuretype_list) - index - 1
            else:
                featuretype_list[index] = None
        for type_ in featuretype_list:
            if type_ is not None:
                featuretype_sum += math.pow(2, type_)
        ret = base.clipAreaUseReference(jobname, stepname, work_layers, reference_layer, margin, clipcontour,
                                        featuretype_sum, smooth_tolerance)
        return base.checkProcessStatus(ret)
    except Exception as e:
        print('clipAreaUseReference error: ', e)
    return False


def clipAreaUseManual(job: str, step: str, layers: list, points: list, margin: float, clipcontour: bool,
                      clipinside: bool, text: bool, surface: bool, arc: bool, line: bool, pad: bool,
                      smooth_tolerance: float):
    try:
        jobname = job
        stepname = step
        positive = True
        negative = True
        featuretype_sum = 0
        featuretype_list = [positive, negative, text, surface, arc, line, pad]
        for index in range(len(featuretype_list)):
            if featuretype_list[index] is True:
                featuretype_list[index] = len(featuretype_list) - index - 1
            else:
                featuretype_list[index] = None
        for type_ in featuretype_list:
            if type_ is not None:
                featuretype_sum += math.pow(2, type_)
        for i in layers:
            layer = i
            base.loadLayer(job, step, layer)
        base.clipAreaUseManual(jobname, stepname, layers, points, margin, clipcontour, clipinside, featuretype_sum,
                               smooth_tolerance)
    except Exception as e:
        print(e)
    return None


def clipAreaUseProfile(job: str, step: str, layers: list, clipinside: bool, clipcontour: bool, margin: float,
                       text: bool, surface: bool, arc: bool, line: bool, pad: bool, smooth_tolerance: float) -> bool:
    try:
        positive = True
        negative = True
        featuretype_sum = 0
        featuretype_list = [positive, negative, text, surface, arc, line, pad]
        for index in range(len(featuretype_list)):
            if featuretype_list[index] is True:
                featuretype_list[index] = len(featuretype_list) - index - 1
            else:
                featuretype_list[index] = None
        for type_ in featuretype_list:
            if type_ is not None:
                featuretype_sum += math.pow(2, type_)
        for i in layers:
            layer = i
            base.loadLayer(job, step, layer)
        ret = base.clipAreaUseProfile(job, step, layers, clipinside, clipcontour, margin, featuretype_sum,
                                      smooth_tolerance)
        return base.checkProcessStatus(ret)
    except Exception as e:
        print('clipAreaUseProfile error: ', e)
    return False


def transformFeatures(job: str, step: str, layer: str, mode: int, rotate: bool, scale: bool, mirror_X: bool,
                      mirror_Y: bool, duplicate: bool, point: dict, angle: float, xscale: float, yscale: float,
                      xoffset: int, yoffset: int) -> bool:
    try:
        jobname = job
        stepname = step
        layername = layer
        ret = base.transform(jobname, stepname, layername, mode, rotate, scale, mirror_X, mirror_Y, duplicate, point,
                             angle, xscale, yscale, xoffset, yoffset)
        return base.checkProcessStatus(ret)
    except Exception as e:
        print('transformFeatures error: ', e)
    return False


def roundingLineCorner(job: str, step: str, layers: list, radius: int) -> bool:
    try:
        ret = base.roundingLineCorner(job, step, layers, radius)
        return base.checkProcessStatus(ret)
    except Exception as e:
        print('roundingLineCorner error: ', e)
    return False


def flattenStep(job: str, step: str, flatten_layer: str, dst_layer: str) -> bool:
    try:
        layers = Information.getLayers(job)
        ret = base.getAllStepRepeatSteps(job, step)
        steps = json.loads(ret)['steps']
        if steps is not None:
            for i in range(0, len(layers)):
                for j in range(0, len(layers)):
                    if layers[i] == dst_layer and layers[j] == flatten_layer:
                        _ret = base.flattenStep(job, step, flatten_layer, dst_layer)
                        ret = json.loads(_ret)['status']
                        if ret == 'true':
                            ret = True
                        else:
                            ret = False
                        return ret
        else:
            pass
    except Exception as e:
        print(e)
    return False


def layerComparePoint(job1: str, step1: str, layer1: str, job2: str, step2: str, layer2: str, tol: int = 22860,
                      isGlobal: bool = True, consider_SR: bool = True, map_layer_resolution: int = 5080000) -> list:
    try:
        tolerance = tol
        mode = isGlobal
        point = base.layerComparePoint(job1, step1, layer1, job2, step2, layer2, tolerance, mode, consider_SR,
                                       map_layer_resolution)
        points = json.loads(point)['result']
        return points
    except Exception as e:
        print(e)
    return []


def profileToOutline(job: str, step: str, layers: list, linewidth: int):
    try:
        base.profileToOuterline(job, step, layers, linewidth)
    except Exception as e:
        print(e)
    return None


def arc2lines(job: str, step: str, layers: list, radius: float, sel_type: bool):
    try:
        if sel_type is True:
            sel_type = 0
        else:
            sel_type = 1
        base.arc2lines(job, step, layers, radius, sel_type)
    except Exception as e:
        print(e)
    return None


def extendSlots(job: str, step: str, layers: list, mode: int, datum: int, size: int):
    try:
        if mode == 1 and size < 0:
            return False
        Matrix.createLayer(job, 'line_back')
        Matrix.createLayer(job, 'slotpad_back')
        all_layers = layers
        select = False
        select_layer = []
        for item in all_layers:
            ret = Information.hasSelectedFeatures(job, step, item)
            if ret:
                select = True
                select_layer.append(item)
        if select is True:
            all_layers = select_layer
        for item in all_layers:
            if select is False:
                Selection.reverseSelect(job, step, item)
            Layers.move2otherLayer(job, step, [item], job, step, 'line_back', False, 0, 0, 0, 0, 0, 0, 0)
            Selection.setFeaturetypeFilter(True, True, True, True, True, False, False)
            Selection.selectFeaturesByFilter(job, step, ['line_back'])
            deleteselect = Information.hasSelectedFeatures(job, step, 'line_back')
            if deleteselect:
                Layers.move2otherLayer(job, step, ['line_back'], job, step, item, False, 0, 0, 0, 0, 0, 0, 0)
            Selection.resetSelectFilter()
            Selection.setFeaturetypeFilter(True, True, False, False, False, False, True)
            Selection.selectFeaturesByFilter(job, step, ['line_back'])
            padselect = Information.hasSelectedFeatures(job, step, 'line_back')
            if padselect:
                Layers.move2otherLayer(job, step, ['line_back'], job, step, 'slotpad_back', False, 0, 0, 0, 0, 0, 0, 0)
                padinfo = Information.getAllSymbolInfo(job, step, 'slotpad_back')['pad_list']
                ovallist = []
                for pad in padinfo:
                    if pad['symbolname'][0:4] == 'oval':
                        ovallist.append(pad['symbolname'])
                Selection.resetSelectFilter()
                Selection.setIncludeSymbolFilter(ovallist)
                Selection.selectFeaturesByFilter(job, step, ['slotpad_back'])
                Selection.reverseSelect(job, step, 'slotpad_back')
                info = Information.hasSelectedFeatures(job, step, 'slotpad_back')
                if info:
                    Layers.move2otherLayer(job, step, ['slotpad_back'], job, step, item, False, 0, 0, 0, 0, 0, 0, 0)
            linesum = Information.getLayerFeatureCount(job, step, 'line_back')
            ovalsum = Information.getLayerFeatureCount(job, step, 'slotpad_back')
            if linesum == 0 and ovalsum == 0:
                return False
            Selection.resetSelectFilter()
            for x in range(0, linesum):
                Selection.clearSelect(job, step, 'line_back')
                Selection.selectFeatureById(job, step, 'line_back', [0])
                info = Information.getSelectedFeaturesInfos(job, step, 'line_back')
                xs = info[0]['XS']
                xe = info[0]['XE']
                ys = info[0]['YS']
                ye = info[0]['YE']
                angle = abs(info[0]['angle'])
                sin = math.sin(math.radians(angle))
                cos = math.cos(math.radians(angle))
                check = True
                if angle == 0:
                    orglen = abs(xe - xs) * 25400000
                elif angle == 90:
                    orglen = abs(ye - ys) * 25400000
                else:
                    orglen = abs(xe - xs) * 25400000 / cos
                if size < 0 and abs(size) >= orglen:
                    Layers.setFeatureToTopOrBottom(job, step, ['line_back'], 1)
                    check = False
                if check is True:
                    if mode == 0 and datum == 0:
                        xlen = base.changesize00(angle, size, sin, cos)['xlen']
                        ylen = base.changesize00(angle, size, sin, cos)['ylen']
                        location = base.lineMode00(xlen, ylen, info)
                    if mode == 0 and datum == 1:
                        xlen = base.changesize01(angle, size, sin, cos)['xlen']
                        ylen = base.changesize01(angle, size, sin, cos)['ylen']
                        location = base.lineMode01(xlen, ylen, info)
                    if mode == 0 and datum == 2:
                        xlen = base.changesize01(angle, size, sin, cos)['xlen']
                        ylen = base.changesize01(angle, size, sin, cos)['ylen']
                        location = base.lineMode02(xlen, ylen, info)
                    if mode == 0 and datum == 3:
                        xlen = base.changesize01(angle, size, sin, cos)['xlen']
                        ylen = base.changesize01(angle, size, sin, cos)['ylen']
                        location = base.lineMode03(xlen, ylen, info)
                    if mode == 0 and datum == 4:
                        xlen = base.changesize01(angle, size, sin, cos)['xlen']
                        ylen = base.changesize01(angle, size, sin, cos)['ylen']
                        location = base.lineMode04(xlen, ylen, info)
                    if mode == 1 and datum == 0:
                        xlen = base.changesize10(xs, xe, ys, ye, angle, size, sin, cos)['xlen']
                        ylen = base.changesize10(xs, xe, ys, ye, angle, size, sin, cos)['ylen']
                        location = base.lineMode10(xlen, ylen, info)
                    if mode == 1 and datum == 1:
                        xlen = base.changesize11(xs, xe, ys, ye, angle, size, sin, cos)['xlen']
                        ylen = base.changesize11(xs, xe, ys, ye, angle, size, sin, cos)['ylen']
                        location = base.lineMode11(xlen, ylen, info)
                    if mode == 1 and datum == 2:
                        xlen = base.changesize11(xs, xe, ys, ye, angle, size, sin, cos)['xlen']
                        ylen = base.changesize11(xs, xe, ys, ye, angle, size, sin, cos)['ylen']
                        location = base.lineMode12(xlen, ylen, info)
                    if mode == 1 and datum == 3:
                        xlen = base.changesize11(xs, xe, ys, ye, angle, size, sin, cos)['xlen']
                        ylen = base.changesize11(xs, xe, ys, ye, angle, size, sin, cos)['ylen']
                        location = base.lineMode13(xlen, ylen, info)
                    if mode == 1 and datum == 4:
                        xlen = base.changesize11(xs, xe, ys, ye, angle, size, sin, cos)['xlen']
                        ylen = base.changesize11(xs, xe, ys, ye, angle, size, sin, cos)['ylen']
                        location = base.lineMode14(xlen, ylen, info)
                    xsnew = location['xsnew']
                    ysnew = location['ysnew']
                    xenew = location['xenew']
                    yenew = location['yenew']
                    symbol = info[0]['symbolname']
                    pol = location['pol']
                    att = info[0]['attributes']
                    Layers.deleteFeature(job, step, ['line_back'])
                    Layers.addLine(job, step, ['line_back'], symbol, xsnew, ysnew, xenew, yenew, pol, att)
            Selection.clearSelect(job, step, 'line_back')
            Layers.move2otherLayer(job, step, ['line_back'], job, step, item, False, 0, 0, 0, 0, 0, 0, 0)
            Selection.resetSelectFilter()
            for y in range(0, ovalsum):
                Selection.clearSelect(job, step, 'slotpad_back')
                Selection.selectFeatureById(job, step, 'slotpad_back', [0])
                info = Information.getSelectedFeaturesInfos(job, step, 'slotpad_back')
                locationx = info[0]['X'] * 25400000
                locationy = info[0]['Y'] * 25400000
                mirror = info[0]['mirror']
                if mirror is True:
                    orient = 9
                else:
                    orient = 8
                sym = info[0]['symbolname'].strip('oval').split('x', 1)
                xsize = float(sym[0])
                ysize = float(sym[1])
                polarity = info[0]['polarity']
                att = info[0]['attributes']
                angle = info[0]['angle']
                if polarity == 'POS':
                    pol = True
                else:
                    pol = False
                sepcial_angle = False
                vertical_angle = False
                if angle == 0 or angle == 180 or angle == 360 or (angle == 90) or (angle == 270):
                    anglenew = 0
                    sepcial_angle = True
                elif 0 < angle < 90 or 180 < angle < 270:
                    anglenew = 90 - angle % 90
                    sepcial_angle = False
                elif 90 < angle < 180 or 270 < angle < 360:
                    anglenew = angle % 90
                    sepcial_angle = False
                aa = False
                if angle == 0 or angle == 180 or angle == 360:
                    aa = True
                if xsize < ysize and aa is True:
                    vertical_angle = True
                elif xsize > ysize and aa is False:
                    vertical_angle = True
                if xsize < ysize:
                    orglen = ysize * 25400
                else:
                    orglen = xsize * 25400
                check = True
                if size < 0 and abs(size) >= orglen:
                    Layers.setFeatureToTopOrBottom(job, step, ['line_back'], 1)
                    check = False
                xlen = size / 1000000 / 25.4 * 1000
                ylen = size / 1000000 / 25.4 * 1000
                sin = math.sin(math.radians(anglenew))
                cos = math.cos(math.radians(anglenew))
                if check is True:
                    if mode == 0 and datum == 0:
                        location = base.changeDatum00(locationx, locationy)
                        info = base.ovalMode00(xlen, ylen, sepcial_angle, xsize, ysize)
                    if mode == 0 and datum == 1:
                        location = base.changeDatum01(xsize, ysize, size, sin, cos, locationx, locationy, sepcial_angle,
                                                      vertical_angle, angle, mirror)
                        info = base.ovalMode00(xlen, ylen, sepcial_angle, xsize, ysize)
                    if mode == 0 and datum == 2:
                        location = base.changeDatum02(xsize, ysize, size, sin, cos, locationx, locationy, sepcial_angle,
                                                      vertical_angle, angle, mirror)
                        info = base.ovalMode00(xlen, ylen, sepcial_angle, xsize, ysize)
                    if mode == 0 and datum == 3:
                        location = base.changeDatum03(xsize, ysize, size, sin, cos, locationx, locationy, angle, mirror,
                                                      datum)
                        info = base.ovalMode00(xlen, ylen, sepcial_angle, xsize, ysize)
                    if mode == 0 and datum == 4:
                        location = base.changeDatum03(xsize, ysize, size, sin, cos, locationx, locationy, angle, mirror,
                                                      datum)
                        info = base.ovalMode00(xlen, ylen, sepcial_angle, xsize, ysize)
                    if mode == 1 and datum == 0:
                        location = base.changeDatum00(locationx, locationy)
                        info = base.ovalMode10(xsize, ysize, size)
                    if mode == 1 and datum == 1:
                        location = base.changeDatum11(xsize, ysize, size, sin, cos, locationx, locationy, sepcial_angle,
                                                      vertical_angle, angle, mirror, datum)
                        info = base.ovalMode10(xsize, ysize, size)
                    if mode == 1 and datum == 2:
                        location = base.changeDatum11(xsize, ysize, size, sin, cos, locationx, locationy, sepcial_angle,
                                                      vertical_angle, angle, mirror, datum)
                        info = base.ovalMode10(xsize, ysize, size)
                    if mode == 1 and datum == 3:
                        location = base.changeDatum13(xsize, ysize, size, sin, cos, locationx, locationy, angle, mirror,
                                                      datum)
                        info = base.ovalMode10(xsize, ysize, size)
                    if mode == 1 and datum == 4:
                        location = base.changeDatum13(xsize, ysize, size, sin, cos, locationx, locationy, angle, mirror,
                                                      datum)
                        info = base.ovalMode10(xsize, ysize, size)
                    locationxnew = location['x']
                    locationynew = location['y']
                    xnew = info['xnew']
                    ynew = info['ynew']
                    Layers.deleteFeature(job, step, ['slotpad_back'])
                    symbolname = 'oval' + str(xnew) + 'x' + str(ynew)
                    Layers.addPad(job, step, ['slotpad_back'], symbolname, locationxnew, locationynew, pol, orient, att,
                                  angle)
            Selection.clearSelect(job, step, 'slotpad_back')
            Layers.move2otherLayer(job, step, ['slotpad_back'], job, step, item, False, 0, 0, 0, 0, 0, 0, 0)
        Matrix.deleteLayer(job, 'line_back')
        Matrix.deleteLayer(job, 'slotpad_back')
    except Exception as e:
        print(e)
    return None


def nearHoleSplitter(holeSize: int, holeSpacing: int, inPoints: list) -> list:
    try:
        for i in inPoints:
            i['ix'] = i['X']
            i['iy'] = i['Y']
            del i['X']
            del i['Y']
        ret = base.nearHoleSplitter(holeSize, holeSpacing, inPoints)
        ret = json.loads(ret)['paras']
        for j in ret:
            j['X'] = j['ix']
            j['Y'] = j['iy']
            del j['ix']
            del j['iy']
        return ret
    except Exception as e:
        print(e)
    return []


def outline2surface(job: str, step: str, layers: list, can_to_pad: str, size: str, unit: str):
    try:
        base.outline2surface(job, step, layers, can_to_pad, size, unit)
    except Exception as e:
        print(e)
    return None


def move2otherLayer(src_job: str, src_step: str, src_layers: list, dst_job: str, dst_step: str, dst_layer: str,
                    invert: bool, offset_x: float, offset_y: float, mirror: int, resize: float, rotation: float,
                    x_anchor: float, y_anchor: float) -> bool:
    try:
        ret = base.selMoveOther(src_job, src_step, src_layers, dst_job, dst_step, dst_layer, invert, offset_x, offset_y,
                                mirror, resize, rotation, x_anchor, y_anchor)
        return base.checkProcessStatus(ret)
    except Exception as e:
        print('move2otherLayer error: ', e)
    return False


def copyUsersymbolToOtherJob(job1: str, job2: str, symbol1: str, symbol2: str):
    try:
        base.copyUsersymbolToOtherJob(job1, job2, symbol1, symbol2)
    except Exception as e:
        print(e)


def setFillGridParam(angle: int, dx: int, dy: int, linewidth: int, xoffset: int, yoffset: int):
    try:
        ret = Information.getFillParam()
        fillType = 2
        patternParams = ret['patternParams']
        solidParams = ret['solidParams']
        gridParams = ret['gridParams']
        gridParams['angle'] = angle
        gridParams['dx'] = dx
        gridParams['dy'] = dy
        gridParams['lineWidth'] = linewidth
        gridParams['xOffset'] = xoffset
        gridParams['yOffset'] = yoffset
        base.setFillParam(fillType, gridParams, patternParams, solidParams)
    except Exception as e:
        print(e)


def setFillPatternParam(symbolname: str, break_partial: bool, cut_primitive: bool, dx: int, dy: int, origin_point: bool,
                        outline: bool, outline_invert: bool = False, outline_width: int = 0, even_offset: int = 0,
                        odd_offset: int = 0):
    try:
        ret = Information.getFillParam()
        fillType = 3
        patternParams = ret['patternParams']
        solidParams = ret['solidParams']
        gridParams = ret['gridParams']
        patternParams['breakPartial'] = break_partial
        patternParams['cutPrimitive'] = cut_primitive
        patternParams['dx'] = dx
        patternParams['dy'] = dy
        patternParams['evenOffset'] = even_offset
        patternParams['oddOffset'] = odd_offset
        patternParams['originPoint'] = origin_point
        patternParams['outline'] = outline
        patternParams['outlineInvert'] = outline_invert
        patternParams['outlineWidth'] = outline_width
        patternParams['symbolName'] = symbolname
        base.setFillParam(fillType, gridParams, patternParams, solidParams)
    except Exception as e:
        print(e)


def setFillSolidParam(solid_type: bool = True, min_brush: int = 25400, use_arcs: bool = False):
    try:
        ret = Information.getFillParam()
        fillType = 0
        patternParams = ret['patternParams']
        solidParams = ret['solidParams']
        gridParams = ret['gridParams']
        solidParams['minBrush'] = min_brush
        solidParams['solidType'] = solid_type
        solidParams['useArcs'] = use_arcs
        base.setFillParam(fillType, gridParams, patternParams, solidParams)
    except Exception as e:
        print(e)


def fillContours(job: str, step: str, layer: str, type: int):
    try:
        ret = base.getFillParam()
        param = json.loads(ret)['paras']
        if type == 0:
            minBrush = param['solidParams']['minBrush']
            useArcs = param['solidParams']['useArcs']
            base.useSolidFillContours(job, step, [layer], True, minBrush, useArcs)
        elif type == 1:
            angle = param['gridParams']['angle']
            dx = param['gridParams']['dx']
            dy = param['gridParams']['dy']
            lineWidth = param['gridParams']['lineWidth']
            xOffset = param['gridParams']['xOffset']
            yOffset = param['gridParams']['yOffset']
            base.fillSelectFeatureByGrid(job, step, layer, dx, dy, lineWidth, xOffset, yOffset, angle)
        elif type == 2:
            breakPartial = param['patternParams']['breakPartial']
            cutPrimitive = param['patternParams']['cutPrimitive']
            dx = param['patternParams']['dx']
            dy = param['patternParams']['dy']
            evenOffset = param['patternParams']['evenOffset']
            oddOffset = param['patternParams']['oddOffset']
            originPoint = param['patternParams']['originPoint']
            outline = param['patternParams']['outline']
            outlineInvert = param['patternParams']['outlineInvert']
            outlineWidth = param['patternParams']['outlineWidth']
            symbolName = param['patternParams']['symbolName']
            base.usePatternFillContours(job, step, layer, symbolName, dx, dy, breakPartial, cutPrimitive, originPoint,
                                        outline, outlineWidth, outlineInvert, oddOffset, evenOffset)
    except Exception as e:
        print(e)


def useSolidFillContours(job: str, step: str, layers: list, min_brush: int, use_arcs: bool = False) -> bool:
    try:
        ret = base.useSolidFillContours(job, step, layers, True, min_brush, use_arcs)
        return base.checkProcessStatus(ret)
    except Exception as e:
        print('useSolidFillContours error: ', e)
    return False


def addChain(job: str, step: str, layer: str, chain_number: int, first_index: int, comp: int, keep_direction: bool,
             add_plunge: bool, toolsize: float, rout_flag: float = 0, feed: float = 0, speed: float = 0):
    try:
        if comp == 0:
            comp = 'None'
        elif comp == 1:
            comp = 'Left'
        elif comp == 2:
            comp = 'Right'
        base.addChain(job, step, layer, chain_number, first_index, comp, keep_direction, add_plunge, toolsize,
                      rout_flag, feed, speed)
    except Exception as e:
        print(e)
