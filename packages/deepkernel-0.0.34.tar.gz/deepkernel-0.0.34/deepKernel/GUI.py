import json
from functools import wraps
from deepKernel import ui_base
from deepKernel.exceptions import DeepKernelProtocolError, DeepKernelBusinessError


def parse_response(expected_type):
    """
    结果解析装饰器
    """

    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            # 获取底层吐出的原生 JSON 字符串
            res = func(*args, **kwargs)

            try:
                if expected_type is bool:
                    data = json.loads(res)
                    is_success = str(data.get('status', 'false')).lower() == 'true'

                    if not is_success:
                        err_msg = data.get('msg', 'C++ API 返回执行失败 (status: false)')
                        # 抛出具体的业务异常，可被更上层的 UI 或脚本 catch 之后提示给用户
                        raise DeepKernelBusinessError(f"[{func.__name__}] 业务失败: {err_msg}", func.__name__)
                    return True

                elif expected_type is list:
                    data = json.loads(res)
                    if not isinstance(data, list):
                        raise DeepKernelProtocolError("期望返回 JSON 数组，实际并非数组", func.__name__,
                                                      raw_response=res)
                    return data

                elif expected_type is str:
                    return res if res else ""

            except json.JSONDecodeError as e:
                raise DeepKernelProtocolError("底层返回的 JSON 格式解析失败", func.__name__, raw_response=res,
                                              inner_exception=e)

        return wrapper

    return decorator


# GUI 接口 (包含类型注解)
@parse_response(bool)
def updateView() -> bool: return ui_base.updateView()


@parse_response(bool)
def updateMatrix() -> bool: return ui_base.updateMatrix()


@parse_response(bool)
def updateLayerList() -> bool: return ui_base.updateLayerList()


@parse_response(bool)
def updateCamGui() -> bool: return ui_base.updateCamGui()


@parse_response(bool)
def inputGerber(project_name: str, path: str) -> bool:
    return ui_base.inputGerber(project_name, path)


@parse_response(bool)
def createProject(project_name: str, customer: str, design_center: str, version: str) -> bool:
    return ui_base.createProject(project_name, customer, design_center, version)


@parse_response(bool)
def openProject(project_id: str) -> bool:
    return ui_base.openProject(project_id)


@parse_response(bool)
def closeProject(project_name: str) -> bool:
    return ui_base.closeProject(project_name)


@parse_response(bool)
def changeCurrentStep(job: str, step: str) -> bool:
    return ui_base.changeCurrentStep(job, step)


@parse_response(list)
def getOpenedProjectInfo() -> list:
    return ui_base.getOpenedProjectInfo()


@parse_response(list)
def getAllProject() -> list:
    return ui_base.getAllProject()


@parse_response(str)
def getCurrentJob() -> str:
    return ui_base.getCurrentJob()


@parse_response(str)
def getCurrentStep() -> str:
    return ui_base.getCurrentStep()


@parse_response(str)
def getDeepKernelConfigurationInitPath() -> str:
    return ui_base.getDeepKernelConfigurationInitPath()
