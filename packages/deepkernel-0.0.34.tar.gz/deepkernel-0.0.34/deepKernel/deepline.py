import ctypes
import os
import json

# 核心库变量
dll = None
bin_path = None
isInit = False

# UI库变量
uidll = None
isUIInit = False


def init(path):
    global dll, uidll
    global bin_path
    global isInit, isUIInit

    bin_path = path
    os.environ['path'] += (r";" + bin_path)

    # 核心库 (LibDL.dll) 初始化
    try:
        dll = ctypes.CDLL(bin_path + r"\LibDL.dll")
        dll.process.restype = ctypes.c_char_p
        dll.init_func_map.restype = ctypes.c_char_p
        dll.init_orig_func_map.restype = ctypes.c_char_p
        dll.getVersion.restype = ctypes.c_char_p
        dll.process.argtypes = [ctypes.c_char_p]

        # 初始化 Func Map
        ret_func = dll.init_func_map()
        ret_func_str = ret_func.decode(
            'utf-8') if ret_func else '{"status":"false", "msg":"init_func_map returned null"}'

        # 解析 JSON 判断是否失败
        try:
            func_data = json.loads(ret_func_str)
            if str(func_data.get('status', '')).lower() == 'false':
                print("LibDL.dll init_func_map 初始化失败")
                return ret_func_str
        except json.JSONDecodeError:
            pass

        # 初始化 Orig Func Map
        ret_orig = dll.init_orig_func_map()
        ret_orig_str = ret_orig.decode(
            'utf-8') if ret_orig else '{"status":"false", "msg":"init_orig_func_map returned null"}'

        try:
            orig_data = json.loads(ret_orig_str)
            if str(orig_data.get('status', '')).lower() == 'false':
                print("LibDL.dll init_orig_func_map 初始化失败")
                return ret_orig_str
        except json.JSONDecodeError:
            pass

        isInit = True

    except Exception as e:
        print(f"核心库 LibDL.dll 加载异常: {e}")
        return json.dumps({"status": "false", "msg": f"Dll Load Error: {e}"})

    # UI库 (LibDLUI.dll) 初始化
    try:
        uidll = ctypes.CDLL(bin_path + r"\LibDLUI.dll")
        uidll.Process.restype = ctypes.c_char_p
        uidll.Process.argtypes = [ctypes.c_char_p]

        uidll.InitFunctionMap.restype = ctypes.c_char_p
        uidll.InitFunctionMap.argtypes = [ctypes.c_char_p]

        uidll.InitFunctionMap(b"{}")
        isUIInit = True
    except Exception as e:
        print(f"LibDLUI.dll 加载或初始化失败: {e}")

    return ret_orig_str


def setUseTimes(times):
    times.encode('utf-8')
    times_str = bytes(times, encoding='utf-8')
    # noinspection PyUnresolvedReferences
    dll.setUseTimes(times_str)


def process(json_str):
    if isInit is False:
        print('Please init first')
        return

    string_buff = bytes(json_str, encoding='utf-8')
    # noinspection PyUnresolvedReferences
    ret = dll.process(string_buff)
    return ret.decode('utf-8') if ret else ""


# def viewCmd(vjson):
#     string_vjson = bytes(vjson, encoding='utf-8')
#     vdll.viewCmd(string_vjson)

def getVersion():
    # noinspection PyUnresolvedReferences
    ret = dll.getVersion()
    ret = ret.decode('utf-8')
    return json.loads(ret)


def uiprocess(json_str):
    if isUIInit is False:
        print('UI DLL is not initialized')
        return '{"status":"false"}'

    string_buff = bytes(json_str, encoding='utf-8')
    # noinspection PyUnresolvedReferences
    ret = uidll.Process(string_buff)
    if ret is None:
        return '{"status":"false"}'

    return ret.decode('utf-8')


# def readPathFactoryJson(vjson):
#     string_vjson = bytes(vjson, encoding='utf-8')
#     ret = matrixdll.readPathFactoryJson(string_vjson)
#     return ret.decode('gbk')

# def readPathTemplateConfigJson(vjson):
#     string_vjson = bytes(vjson, encoding='utf-8')
#     ret = matrixdll.readPathTemplateConfigJson(string_vjson)
#     return ret.decode('gbk')

# def getMatchedLayers(vjson):
#     string_vjson = bytes(vjson, encoding='utf-8')
#     ret = matrixdll.getMatchedLayers(string_vjson)
#     return ret.decode('gbk')

# def saveNewMatchRule(vjson):
#     string_vjson = bytes(vjson, encoding='utf-8')
#     ret = matrixdll.saveNewMatchRule(string_vjson)
#     return ret.decode('gbk')

def getConfigPath():
    return bin_path
