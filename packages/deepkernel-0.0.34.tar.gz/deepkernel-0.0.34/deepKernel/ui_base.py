import json
import inspect
from deepKernel import deepline
from deepKernel.exceptions import DeepKernelProtocolError, DeepKernelCtypeError


def ui_command(cmd_name: str):
    """
    UI 通信层闭包装饰器
    负责拦截函数调用，抓取参数并按 C++ 规范拼装为 JSON payload，透传给底层。
    """

    def decorator(func):
        def wrapper(*args, **kwargs):
            # 利用 inspect 模块，自动将传入的 args 和 kwargs 绑定到函数签名上
            try:
                sig = inspect.signature(func)
                bound_args = sig.bind(*args, **kwargs)
                bound_args.apply_defaults()
            except TypeError as e:
                # 捕获 Python 端传参错误
                raise DeepKernelProtocolError(
                    message="Python 接口参数传递错误 (可能少传或错传参数)",
                    api_name=cmd_name,
                    payload={"args": args, "kwargs": kwargs},
                    inner_exception=e
                )
            # 组装 Payload
            payload = {'func': cmd_name}

            # 将捕获到的参数字典转换为 C++ 端要求的 [{'k':'v'}] 格式
            if bound_args.arguments:
                payload['paras'] = [{k: v} for k, v in bound_args.arguments.items()]

            try:
                json_payload = json.dumps(payload)
            except Exception as e:
                raise DeepKernelProtocolError("JSON payload 组装序列化失败", cmd_name, payload, inner_exception=e)

            try:
                res = deepline.uiprocess(json_payload)
            except Exception as e:
                raise DeepKernelCtypeError("调用 C++ LibDLUI 发生严重崩溃", cmd_name, payload, inner_exception=e)

            if not res:
                raise DeepKernelCtypeError("底层 DLL 未返回任何数据 (空指针)", cmd_name, payload)

            return res
        return wrapper
    return decorator


# 无参数接口
@ui_command("UPDATE_VIEW")
def updateView(): pass


@ui_command("UPDATE_MATRIX")
def updateMatrix(): pass


@ui_command("UPDATE_LAYER_LIST")
def updateLayerList(): pass


@ui_command("UPDATE_CAM_GUI")
def updateCamGui(): pass


@ui_command("GET_OPENED_PROJECT_INFO")
def getOpenedProjectInfo(): pass


@ui_command("GET_ALL_PROJECT")
def getAllProject(): pass


@ui_command("GET_CURRENT_JOB")
def getCurrentJob(): pass


@ui_command("GET_CURRENT_STEP")
def getCurrentStep(): pass


@ui_command("GET_APPLICATION_PATH")
def getDeepKernelConfigurationInitPath(): pass


@ui_command("INPUT_GERBER")
def inputGerber(project_name: str, path: str): pass


# 带参数接口
@ui_command("CREATE_PROJECT")
def createProject(project_name, customer, design_center, version):
    pass


@ui_command("OPEN_PROJECT")
def openProject(project_id): pass


@ui_command("CLOSE_PROJECT")
def closeProject(project_name): pass


@ui_command("CHANGE_CURRENT_STEP")
def changeCurrentStep(job, step): pass
