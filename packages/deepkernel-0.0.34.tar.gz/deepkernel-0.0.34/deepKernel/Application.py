import json
import os
import shutil
import tarfile

from deepKernel import Output, base
from deepKernel.Action import Information, Selection
from deepKernel.Edition import Layers, Matrix, Job


# 指定step创建矩形profile
def createRectProfile(job: str, step: str, xmin: int, ymin: int, xmax: int, ymax: int):
    try:
        Matrix.createLayer(job, 'profile__fz')
        Layers.addLine(job, step, ['profile__fz'], 'r1', xmin, ymin, xmin, ymax, True, [])
        Layers.addLine(job, step, ['profile__fz'], 'r1', xmax, ymin, xmax, ymax, True, [])
        Layers.addLine(job, step, ['profile__fz'], 'r1', xmax, ymax, xmin, ymax, True, [])
        Layers.addLine(job, step, ['profile__fz'], 'r1', xmax, ymin, xmin, ymin, True, [])
        Selection.reverseSelect(job, step, 'profile__fz')
        Layers.createProfile(job, step, 'profile__fz')
        Matrix.deleteLayer(job, 'profile__fz')
    except Exception as e:
        print(e)
    return 0


# 直接根据属性去筛选
def setFeaturetypeFilter(types: list = None, polarity: list = None) -> bool:
    """
    设置特征类型过滤
    :param types: 包含 'line', 'pad', 'surface', 'arc', 'text' 的列表
    :param polarity: 包含 'pos', 'neg' 的列表
    :return: 成功返回 True，失败返回 False
    """
    # 规避可变默认参数陷阱
    if types is None:
        types = ['line', 'pad', 'surface', 'arc', 'text']
    if polarity is None:
        polarity = ['pos', 'neg']

    # 直接将判断结果转化为布尔值，按底层定义的严格顺序进行位置传参
    # 并直接返回底层的处理结果（True / False）
    return Selection.setFeaturetypeFilter(
        'line' in types,      # line
        'pad' in types,       # pad
        'surface' in types,   # surface
        'arc' in types,       # arc
        'text' in types,      # text
        'pos' in polarity,    # positive
        'neg' in polarity     # negative
    )


# 输出料号的格式
def exportJob(job: str, path: str, type: list = None):
    if type is None:
        type = ['tgz']

    try:
        ifn = os.path.join(path, job)

        if 'tar' in type:
            ofn = ifn + '.tar'
            Output.saveJob(job, path)
            with tarfile.open(ofn, 'w') as tar:
                tar.add(ifn, arcname=os.path.basename(ifn))
            shutil.rmtree(ifn)

        if 'tgz' in type:
            Output.saveJob(job, path)
            ofn = ifn + '.tgz'
            with tarfile.open(ofn, 'w:gz') as tar:
                tar.add(ifn, arcname=os.path.basename(ifn))
            shutil.rmtree(ifn)

        if 'odb' in type:
            Output.saveJob(job, path)

    except Exception as e:
        print(e)

    return 0


def addSurface(job: str, step: str, layers: list, polarity: bool, attributes: dict, points_location: list):
    try:
        new = list()
        for i in attributes:
            new.append({i: attributes[i]})
        Layers.addSurface(job, step, layers, polarity, new, points_location)
    except Exception as e:
        print(e)
    return 0


def addRoundSurface(job: str, step: str, layers: list, polarity: bool, attributes: dict, center_x: int,
                    center_y: int, radius: int):
    try:
        new = list()
        for i in attributes:
            new.append({i: attributes[i]})
        Layers.addRoundSurface(job, step, layers, polarity, new, center_x, center_y, radius)
    except Exception as e:
        print(e)
    return 0


def addText(job: str, step: str, layers: list, fontname: str, text: str, xsize: int, ysize: int, linewidth: int,
            location_x: int, location_y: int, polarity: bool, orient: int, attributes: dict,
            special_angle: float = 0):
    try:
        new = list()
        for i in attributes:
            new.append({i: attributes[i]})
        Layers.addText(job, step, layers, fontname, text, xsize, ysize, linewidth, location_x, location_y, polarity,
                       orient, new, special_angle)
    except Exception as e:
        print(e)
    return 0


def addLine(job: str, step: str, layers: list, symbol: str, start_x: int, start_y: int, end_x: int, end_y: int,
            polarity: bool, attributes: dict):
    try:
        new = list()
        for i in attributes:
            new.append({i: attributes[i]})
        Layers.addLine(job, step, layers, symbol, start_x, start_y, end_x, end_y, polarity, new)
    except Exception as e:
        print(e)
    return 0


def addArc(job: str, step: str, layers: list, symbol: str, start_x: int, start_y: int, end_x: int, end_y: int,
           center_x: int, center_y: int, cw: bool, polarity: bool, attributes: dict):
    try:
        new = list()
        for i in attributes:
            new.append({i: attributes[i]})
        Layers.addArc(job, step, layers, symbol, start_x, start_y, end_x, end_y, center_x, center_y, cw, polarity, new)
    except Exception as e:
        print(e)
    return 0


def getMatrix(job: str) -> dict:
    try:
        step = Information.getSteps(job)
        layer = Information.getLayerInformation(job)
        matrix_dict = {}
        matrix_dict['steps'] = step
        matrix_dict['info'] = layer
        return matrix_dict
    except Exception as e:
        print(e)
    return {}


def getSelectedFeatureInfos(job: str, step: str, layer: str) -> list:
    try:
        select = Information.hasSelectedFeatures(job, step, layer)
        if select is True:
            ret = Information.getSelectedFeaturesInfos(job, step, layer)
        else:
            ret = Information.getAllFeaturesInfo(job, step, layer)
        return ret
    except Exception as e:
        print(e)
    return []


def getSelectedSymbolInfo(job: str, step: str, layer: str) -> dict:
    try:
        select = Information.hasSelectedFeatures(job, step, layer)
        if select is True:
            ret = Information.getSelectedSymbolInfo(job, step, layer)
        else:
            ret = Information.getAllSymbolInfo(job, step, layer)
        return ret
    except Exception as e:
        print(e)
    return {}


# 增加了自动更新symbol的功能
def addPad(job: str, step: str, layers: list, symbol: str, location_x: int, location_y: int, polarity: bool,
           orient: int, attributes: dict, nx: int = 1, ny: int = 1, dx: int = 0, dy: int = 0,
           special_angle: float = 0):
    try:
        new = list()
        for i in attributes:
            new.append({i: attributes[i]})
        for m in range(0, nx):
            for n in range(0, ny):
                location_x1 = location_x + dx * m
                location_y1 = location_y + dy * n
                Layers.addPad(job, step, layers, symbol, location_x1, location_y1, polarity, orient, new, special_angle)
    except Exception as e:
        print(e)
    return 0


# 操作拼版
def srTabAdd(job: str, step: str, child_steps: list):
    try:
        info = Information.getSrStepInfo(job, step)
        info.append(child_steps)
        Layers.doStepRepeat(job, step, info)
    except Exception as e:
        print(e)
    return 0


def renameLayer(job: str, old_name: str, new_name: str):
    try:
        info = Information.getLayerInformation(job)
        for i in info:
            if i['name'] == old_name:
                context = i['context']
                type = i['type']
                polarity = i['polarity']
                if polarity == 'positive':
                    polarity = True
                else:
                    polarity = False
                Matrix.changeMatrixRow(job, old_name, context, type, new_name, polarity)
    except Exception as e:
        print(e)


def hasUsersymbol(job: str, symbolname: str) -> bool:
    try:
        usersymbol_list = Information.getUsersymbolList(job)
        for usersymbol in usersymbol_list:
            if usersymbol == symbolname:
                return True
    except Exception as e:
        print(e)
    return False


def getSelectedFeaturesBox(job: str, step: str, layers: list) -> dict:
    try:
        has_selected = False
        for layer in layers:
            selected = Information.hasSelectedFeatures(job, step, layer)
            if selected is True:
                has_selected = True
        if has_selected is True:
            box = Information.getSelectedFeaturesBox(job, step, layers)
        else:
            box = base.layerBox(job, step, layers)
            box = json.loads(box)['paras']
        return box
    except Exception as e:
        print(e)
        return {}


def savePartialSteps(job: str, steps: list, path: str) -> bool:
    try:
        jobname = job + 'backup'
        Job.createJob(jobname)
        Job.copyJob(job, jobname)
        Job.renameJob(job, 'jobtest')
        stepnames = Information.getSteps(jobname)
        for stepname in stepnames:
            if stepname not in steps:
                Matrix.deleteStep(jobname, stepname)
        Job.renameJob(jobname, job)
        save = Output.saveJob(job, path)
        Job.closeJob(job)
        Job.renameJob('jobtest', job)
        return save
    except Exception as e:
        print(e)
        return False


def srTabDelete(job: str, step: str, indexes: list):
    try:
        target_indexes = [i - 1 for i in indexes]
        info = Information.getSrStepInfo(job, step)
        infos = [val for i, val in enumerate(info) if i not in target_indexes]
        Layers.doStepRepeat(job, step, infos)

    except Exception as e:
        print(f"Error in srTabDelete: {e}")
