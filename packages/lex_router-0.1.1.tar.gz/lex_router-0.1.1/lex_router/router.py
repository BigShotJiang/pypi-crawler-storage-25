import re
import json
import logging
from dataclasses import asdict
from typing import Optional, Callable
from collections import defaultdict

from .signals import (PilotSignals, RouteDecision, RouterConfig, ScoreType,
                      compute_signals)
from .adapters import RetrievalAdapter

_logger = logging.getLogger(__name__)


class AdaptiveRouter:
    """Multi-signal adaptive query router for RAG systems.

    Routes queries to different retrieval strategies by analyzing
    the statistical distribution of pilot retrieval scores. Works
    with any retrieval backend through the RetrievalAdapter interface.

    The router does NOT use domain-specific vocabularies. It reads
    the retrieval landscape itself — score distributions, entropy,
    dense-sparse agreement, and IDF-based query rarity — to make
    routing decisions that generalize across any domain.

    Usage:
        # Option A: pass raw scores directly
        router = AdaptiveRouter()
        decision = router.route_from_scores(
            dense_scores=[0.92, 0.87, 0.61],
            sparse_scores=[12.4, 8.1],
        )

        # Option B: connect your pipeline via adapter
        router = AdaptiveRouter(adapter=MyAdapter())
        decision = router.route("complex query here")
    """

    def __init__(self, adapter: RetrievalAdapter = None,
                 config: RouterConfig = None,
                 pilot_k: int = 10,
                 dense_score_type: ScoreType = ScoreType.COSINE,
                 sparse_score_type: ScoreType = ScoreType.RAW,
                 custom_dense_normalizer: Callable = None,
                 custom_sparse_normalizer: Callable = None,
                 log_file: str = None):
        self.adapter = adapter
        self.config = config or RouterConfig()
        self.pilot_k = pilot_k
        self.dense_score_type = dense_score_type
        self.sparse_score_type = sparse_score_type
        self.custom_dense_normalizer = custom_dense_normalizer
        self.custom_sparse_normalizer = custom_sparse_normalizer
        self._log_fh = open(log_file, 'a', encoding='utf-8') if log_file else None
        self._route_counts = defaultdict(int)
        self._query_count = 0

    # Fix #5: Context manager support to prevent log file resource leaks
    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False

    def __del__(self):
        self.close()

    @classmethod
    def auto_calibrate(cls,
                       baseline_dense_scores: list,
                       baseline_sparse_scores: list = None,
                       adapter: RetrievalAdapter = None,
                       dense_score_type: ScoreType = ScoreType.COSINE,
                       sparse_score_type: ScoreType = ScoreType.RAW,
                       **kwargs) -> 'AdaptiveRouter':
        """Auto-tune routing thresholds to your specific embedder model.

        Prevents "threshold drift" (Fix #6) and breaks caused by swapping
        embedders (Fix #8). Pass a sample of scores from a baseline test
        (e.g., 50 queries) and the router will configure itself to your
        exact score distribution.
        """
        from .signals import normalize_scores

        def get_percentile(data, p):
            """Pure-Python percentile to avoid numpy dependency."""
            if not data: return 0.0
            s = sorted(data)
            k = (len(s) - 1) * (p / 100.0)
            f = int(k)
            c = int(k) + 1 if int(k) + 1 < len(s) else int(k)
            return s[f] + (k - f) * (s[c] - s[f])

        config = RouterConfig()

        if baseline_dense_scores:
            flat_dense = []
            vars_dense = []
            margins = []
            for batch in baseline_dense_scores:
                normed = normalize_scores(batch, dense_score_type)
                if not normed: continue
                flat_dense.extend(normed)
                
                if len(normed) > 1:
                    mean = sum(normed) / len(normed)
                    var = sum((x - mean)**2 for x in normed) / len(normed)
                    vars_dense.append(var**0.5)
                    margins.append(normed[0] - normed[min(4, len(normed)-1)])

            # Fix #6: guard against degenerate calibration from tiny samples
            if len(flat_dense) < 5:
                _logger.warning(
                    "Lex-Router: auto_calibrate received only %d scores. "
                    "Need at least 5 for reliable thresholds. Using defaults.",
                    len(flat_dense)
                )
            else:
                config.t_high = round(get_percentile(flat_dense, 90), 3)
                config.t_low = round(get_percentile(flat_dense, 25), 3)
                # Sanity: t_high must be > t_low
                if config.t_high <= config.t_low:
                    config.t_high = config.t_low + 0.1
            if vars_dense and len(vars_dense) >= 3:
                config.std_high = round(get_percentile(vars_dense, 75), 3)
            if margins and len(margins) >= 3:
                config.margin_high = round(get_percentile(margins, 70), 3)

        return cls(adapter=adapter, config=config,
                   dense_score_type=dense_score_type,
                   sparse_score_type=sparse_score_type, **kwargs)

    def route(self, query: str) -> RouteDecision:
        """Route a query using the connected retrieval adapter."""
        # Fix #2: guard against empty/None queries
        if not query or not isinstance(query, str) or not query.strip():
            return RouteDecision(
                route='normal', pool=self.config.normal_pool, top_k=self.config.normal_k,
                use_hyde=False, use_bm25=True, use_xref=False,
                use_span_refine=False, fallback_enabled=True,
                metadata={'reason': 'empty_or_invalid_query'}
            )

        if not self.adapter:
            raise RuntimeError(
                "No retrieval adapter connected. Either pass an adapter "
                "to __init__, or use route_from_scores() directly."
            )
        
        # Fast-Path Bypass for Ultra-Low Latency
        if self.config.fast_path_max_tokens > 0:
            if len(query.split()) <= self.config.fast_path_max_tokens:
                decision = RouteDecision(
                    route='fast_bypass', pool=self.config.narrow_pool, top_k=self.config.narrow_k,
                    use_hyde=False, use_bm25=True, use_xref=False,
                    use_span_refine=False, fallback_enabled=False,
                    metadata={'reason': 'fast_path_length_bypass'}
                )
                self._query_count += 1
                self._route_counts[decision.route] += 1
                self._log(query, PilotSignals(), decision)
                return decision

        # Fix #1: wrap adapter calls so a DB timeout doesn't crash the router
        try:
            dense_scores, dense_docs = self.adapter.dense_search(query, self.pilot_k)
            sparse_scores, sparse_docs = self.adapter.sparse_search(query, self.pilot_k)
            idf_lookup, corpus_size = self.adapter.get_idf_stats()
        except Exception as e:
            _logger.error(
                "Lex-Router: Retrieval adapter failed: %s. "
                "Falling back to 'normal' route.", e
            )
            return RouteDecision(
                route='normal', pool=self.config.normal_pool, top_k=self.config.normal_k,
                use_hyde=True, use_bm25=True, use_xref=True,
                use_span_refine=False, fallback_enabled=True,
                metadata={'reason': 'adapter_exception', 'error': str(e)}
            )

        return self.route_from_scores(
            query=query,
            dense_scores=dense_scores,
            sparse_scores=sparse_scores,
            dense_docs=dense_docs,
            sparse_docs=sparse_docs,
            idf_lookup=idf_lookup,
            corpus_size=corpus_size,
        )

    def route_from_scores(self, dense_scores: list = None,
                          sparse_scores: list = None,
                          dense_docs: list = None,
                          sparse_docs: list = None,
                          query: str = None,
                          idf_lookup: dict = None,
                          corpus_size: int = 0,
                          dense_score_type: ScoreType = None,
                          sparse_score_type: ScoreType = None) -> RouteDecision:
        """Route using raw retrieval scores. No adapter needed.

        Score types default to what was set in __init__.
        Override per-call if you have mixed sources.
        """
        signals = compute_signals(
            dense_scores=dense_scores,
            sparse_scores=sparse_scores,
            dense_docs=dense_docs,
            sparse_docs=sparse_docs,
            query=query,
            idf_lookup=idf_lookup,
            corpus_size=corpus_size,
            dense_score_type=dense_score_type or self.dense_score_type,
            sparse_score_type=sparse_score_type or self.sparse_score_type,
            custom_dense_normalizer=self.custom_dense_normalizer,
            custom_sparse_normalizer=self.custom_sparse_normalizer,
            min_pilot_results=self.config.min_pilot_results,
            analyze_top_k=self.pilot_k,  # Bug fix #1: pass pilot_k as analyze_top_k
        )

        decision = self._classify(signals)
        decision.metadata['signals'] = asdict(signals)

        # Bug fix #5: increment before log so query_id is correct
        self._query_count += 1
        self._route_counts[decision.route] += 1
        self._log(query or '', signals, decision)
        return decision

    def _classify(self, sig: PilotSignals) -> RouteDecision:
        """Map pilot signals to one of 4 retrieval strategies.

        Guards against three failure modes:
        1. Scores are normalized to [0,1] before reaching here (Fix #1)
        2. Rarity conditions are skipped when IDF unavailable (Fix #2)
        3. Low pilot count forces safe 'normal' route (Fix #3)
        """
        cfg = self.config

        # Bug fix #3: logging imported at module level, not inside hot path
        if sig.low_confidence_pilot:
            _logger.warning(
                "Lex-Router: Pilot search returned fewer than %d results. "
                "Statistical routing degraded. Falling back to 'normal' route.",
                self.config.min_pilot_results
            )
            return RouteDecision(
                route='normal', pool=cfg.normal_pool, top_k=cfg.normal_k,
                use_hyde=True, use_bm25=True, use_xref=True,
                use_span_refine=False, fallback_enabled=True,
                metadata={'reason': 'insufficient_pilot_data',
                          'warning': 'fewer than min_pilot_results returned'}
            )

        # REJECT: both retrievers weak (or the only available retriever is weak)
        # FIX #2: only check rarity if IDF data exists
        reject_rarity_ok = (not sig.has_idf_data) or sig.max_term_rarity < cfg.rarity_reject
        
        if sig.is_sparse_only:
            # RAW BM25 scores are unbounded, use zero as reject threshold
            is_weak = sig.bm25_max <= 0.0
        elif sig.is_dense_only:
            is_weak = sig.max_dense < cfg.t_low
        else:
            # Fix #1: dual-retriever — for RAW sparse, check if BM25 found
            # anything at all. For normalized sparse, use t_low threshold.
            dense_weak = sig.max_dense < cfg.t_low
            if sig.sparse_is_raw:
                sparse_weak = sig.bm25_max <= 0.0
            else:
                sparse_weak = sig.bm25_max < cfg.t_low
            is_weak = dense_weak and sparse_weak

        if is_weak and reject_rarity_ok:
            return RouteDecision(
                route='reject_or_fallback', pool=0, top_k=0,
                use_hyde=False, use_bm25=False, use_xref=False,
                use_span_refine=False, fallback_enabled=True,
                metadata={'reason': 'retriever_weak'}
            )

        # NARROW PRECISE: rare anchor OR confident top-1
        # FIX #2: only use rarity anchor when IDF data exists
        has_rare_anchor = sig.has_idf_data and sig.max_term_rarity > cfg.rarity_anchor
        has_confident_dense = (sig.max_dense > cfg.t_high
                               and sig.top1_top5_margin > cfg.margin_high
                               and sig.unique_doc_count <= 2)
        # Bug fix #4: bm25_max > 0.0 is too permissive for sparse-only systems.
        # We require the top result to be meaningfully above the mean
        # (i.e., the search clearly converged to 1-2 specific documents).
        has_confident_sparse = (sig.is_sparse_only
                                and sig.unique_doc_count <= 2
                                and sig.bm25_max > 0.0
                                and sig.bm25_mean > 0.0
                                and (sig.bm25_max / (sig.bm25_mean + 1e-9)) > 1.5)

        if has_rare_anchor or has_confident_dense or has_confident_sparse:
            return RouteDecision(
                route='narrow_precise', pool=cfg.narrow_pool, top_k=cfg.narrow_k,
                use_hyde=False, use_bm25=True, use_xref=False,
                use_span_refine=False, fallback_enabled=False,
                metadata={'reason': 'rare_anchor' if has_rare_anchor else 'confident_top1'}
            )

        # BROAD EXPAND: generic terms, high variance, many docs
        # FIX #2: skip rarity check when IDF is missing
        is_generic_by_rarity = sig.has_idf_data and sig.query_rarity < cfg.rarity_generic
        is_high_variance = sig.std_dense > cfg.std_high
        is_diverse = sig.unique_doc_count >= cfg.diversity_high
        if is_generic_by_rarity or is_high_variance or is_diverse:
            return RouteDecision(
                route='broad_expand', pool=cfg.broad_pool, top_k=cfg.broad_k,
                use_hyde=True, use_bm25=True, use_xref=True,
                use_span_refine=False, fallback_enabled=True,
                metadata={'reason': 'generic_terms' if is_generic_by_rarity
                          else 'high_variance' if is_high_variance
                          else 'high_doc_diversity'}
            )

        # NORMAL: balanced default
        return RouteDecision(
            route='normal', pool=cfg.normal_pool, top_k=cfg.normal_k,
            use_hyde=True, use_bm25=True, use_xref=True,
            use_span_refine=False, fallback_enabled=True,
            metadata={'reason': 'balanced_default'}
        )

    def should_fallback(self, top_reranker_score: float,
                        signals: PilotSignals) -> bool:
        """Post-reranking safety net."""
        cfg = self.config
        if top_reranker_score < cfg.reranker_threshold:
            return True
        if (signals.dense_bm25_overlap < cfg.overlap_threshold
                and signals.entropy > cfg.entropy_threshold):
            return True
        return False

    def get_fallback_config(self, current_pool: int) -> RouteDecision:
        """Fallback config: double pool, all features on."""
        cfg = self.config
        return RouteDecision(
            route='fallback',
            pool=min(max(current_pool * 2, cfg.broad_pool), cfg.fallback_max_pool),
            top_k=cfg.fallback_k,
            use_hyde=True, use_bm25=True, use_xref=True,
            use_span_refine=False, fallback_enabled=False,
            xref_hops=2,
            metadata={'reason': 'confidence_too_low'}
        )

    @staticmethod
    def simplify_query(query: str) -> str:
        """Strip filler tokens, keep proper nouns and content words."""
        filler = {
            'the', 'a', 'an', 'is', 'are', 'was', 'were', 'do', 'does',
            'did', 'will', 'would', 'could', 'should', 'can', 'may',
            'might', 'must', 'has', 'have', 'had', 'be', 'been', 'being',
            'it', 'its', 'this', 'that', 'these', 'those', 'what',
            'which', 'who', 'whom', 'how', 'when', 'where', 'why',
            'if', 'or', 'and', 'but', 'so', 'for', 'to', 'of', 'in',
            'on', 'at', 'by', 'with', 'from', 'about', 'into',
            'through', 'during', 'before', 'after', 'above', 'below',
        }
        tokens = query.split()
        kept = [t for t in tokens if t.lower() not in filler or t[0].isupper()]
        return ' '.join(kept) if kept else query

    def get_signals(self, query: str) -> PilotSignals:
        """Expose raw pilot signals without routing."""
        if not self.adapter:
            raise RuntimeError("No adapter connected.")
        if not query or not isinstance(query, str) or not query.strip():
            return PilotSignals()

        try:
            dense_scores, dense_docs = self.adapter.dense_search(query, self.pilot_k)
            sparse_scores, sparse_docs = self.adapter.sparse_search(query, self.pilot_k)
            idf_lookup, corpus_size = self.adapter.get_idf_stats()
        except Exception as e:
            _logger.error("Lex-Router: Adapter failed in get_signals: %s", e)
            return PilotSignals()

        # Bug fix #2: use keyword args to avoid positional arg mismatch
        return compute_signals(
            dense_scores=dense_scores,
            sparse_scores=sparse_scores,
            dense_docs=dense_docs,
            sparse_docs=sparse_docs,
            query=query,
            idf_lookup=idf_lookup,
            corpus_size=corpus_size,
            dense_score_type=self.dense_score_type,
            sparse_score_type=self.sparse_score_type,
            custom_dense_normalizer=self.custom_dense_normalizer,
            custom_sparse_normalizer=self.custom_sparse_normalizer,
            min_pilot_results=self.config.min_pilot_results,
            analyze_top_k=self.pilot_k,
        )

    def route_summary(self) -> dict:
        total = sum(self._route_counts.values())
        if total == 0:
            return {'total': 0, 'routes': {}}
        return {
            'total': total,
            'routes': {r: {'count': c, 'pct': round(100 * c / total, 1)}
                       for r, c in sorted(self._route_counts.items())}
        }

    def print_summary(self):
        s = self.route_summary()
        if s['total'] == 0:
            print('  No queries routed yet.'); return
        print(f"\nRoute Distribution ({s['total']} queries):")
        for r, info in s['routes'].items():
            print(f"  {r:<20} {info['count']:>4}  ({info['pct']:.1f}%)")

    def _log(self, query, signals, decision):
        if not self._log_fh: return
        entry = {
            'query_id': self._query_count, 'query': query,
            'signals': asdict(signals), 'route': decision.route,
            'config': {'pool': decision.pool, 'top_k': decision.top_k,
                       'use_hyde': decision.use_hyde, 'use_bm25': decision.use_bm25,
                       'use_xref': decision.use_xref},
        }
        self._log_fh.write(json.dumps(entry, ensure_ascii=False) + '\n')
        self._log_fh.flush()

    def close(self):
        if self._log_fh: self._log_fh.close(); self._log_fh = None
