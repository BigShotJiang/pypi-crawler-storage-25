import math
import re
from enum import Enum
from dataclasses import dataclass, field, asdict
from typing import List, Dict, Any, Optional, Callable

class ScoreType(Enum):
    """Declares the scale of your retrieval scores so the router
    can normalize them to [0, 1] before computing signals."""
    COSINE = "cosine"         # [0, 1] higher = better
    COSINE_DISTANCE = "cosine_distance" # [0, 2] lower = better -> converted to similarity
    L2 = "l2"                 # [0, inf] lower = better -> inverted
    DOT_PRODUCT = "dot"       # [-inf, inf] -> min-max normalized on pilot batch
    LOGITS = "logits"         # [-inf, inf] -> sigmoid probability [0, 1] (Cross-Encoders)
    RAW = "raw"               # no normalization (best for BM25)
    CUSTOM = "custom"         # user provides their own normalizer function


def normalize_scores(scores: List[float], score_type: ScoreType,
                     custom_fn: Callable = None) -> List[float]:
    """Normalize raw retrieval scores to [0, 1] range (higher = better).

    This prevents threshold mismatch when users plug in different
    retrieval backends that return scores on different scales.
    Also strips NaN/Inf to prevent math crashes.
    """
    if not scores:
        return []

    # FIX #5: Sanitize inputs safely (catch None, strings, and NaNs)
    clean_scores = []
    for s in scores:
        if s is None:
            clean_scores.append(0.0)
            continue
        try:
            val = float(s)
            if math.isnan(val) or math.isinf(val):
                clean_scores.append(0.0)
            else:
                clean_scores.append(val)
        except (ValueError, TypeError):
            clean_scores.append(0.0)
    
    if not clean_scores:
        return []

    if score_type == ScoreType.RAW:
        return clean_scores

    elif score_type == ScoreType.COSINE:
        return [max(0.0, min(1.0, s)) for s in clean_scores]

    elif score_type == ScoreType.COSINE_DISTANCE:
        # Distance = 1 - similarity. So similarity = 1 - distance.
        # We clamp to [0, 1] (ignoring negative similarity for opposite vectors)
        return [max(0.0, min(1.0, 1.0 - s)) for s in clean_scores]

    elif score_type == ScoreType.L2:
        # L2 distances are always >= 0. Clamp negatives to 0 in case of garbage input.
        return [1.0 / (1.0 + max(0.0, s)) for s in clean_scores]

    elif score_type == ScoreType.DOT_PRODUCT:
        mn, mx = min(clean_scores), max(clean_scores)
        rng = mx - mn
        if rng < 1e-9:
            return [0.5] * len(clean_scores)
        return [(s - mn) / rng for s in clean_scores]

    elif score_type == ScoreType.LOGITS:
        # Cross-encoder logits: convert to probability via sigmoid.
        # Clamped to [-100, 100] to prevent math.exp OverflowError.
        return [1.0 / (1.0 + math.exp(-max(min(s, 100.0), -100.0))) for s in clean_scores]

    elif score_type == ScoreType.CUSTOM:
        if custom_fn is None:
            raise ValueError("ScoreType.CUSTOM requires a custom_fn argument")
        return [custom_fn(s) for s in clean_scores]

    return clean_scores


@dataclass
class PilotSignals:
    """11-signal feature vector extracted from pilot retrieval scores."""
    max_dense: float = 0.0
    mean_dense: float = 0.0
    std_dense: float = 0.0
    top1_top5_margin: float = 0.0
    bm25_max: float = 0.0
    bm25_mean: float = 0.0
    dense_bm25_overlap: float = 0.0
    unique_doc_count: int = 0
    entropy: float = 0.0
    query_rarity: float = 0.0
    max_term_rarity: float = 0.0
    # metadata flags
    has_idf_data: bool = False
    low_confidence_pilot: bool = False
    is_sparse_only: bool = False
    is_dense_only: bool = False
    sparse_is_raw: bool = False


@dataclass
class RouteDecision:
    """Retrieval strategy chosen by the router."""
    route: str = 'normal'
    pool: int = 150
    top_k: int = 3
    use_hyde: bool = True
    use_bm25: bool = True
    use_xref: bool = True
    use_span_refine: bool = True
    fallback_enabled: bool = True
    xref_hops: int = 1
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class RouterConfig:
    """Tunable thresholds for routing decisions."""
    t_high: float = 0.75
    t_low: float = 0.35
    margin_high: float = 0.15
    std_high: float = 0.20
    diversity_high: int = 5
    rarity_anchor: float = 11.0
    rarity_generic: float = 15.0
    rarity_reject: float = 10.0
    reranker_threshold: float = 0.3
    entropy_threshold: float = 2.0
    overlap_threshold: float = 0.1
    # pool sizes
    narrow_pool: int = 50
    narrow_k: int = 3
    normal_pool: int = 100
    normal_k: int = 4
    broad_pool: int = 200
    broad_k: int = 5
    fallback_max_pool: int = 300
    fallback_k: int = 5
    # pilot guards
    min_pilot_results: int = 3
    fast_path_max_tokens: int = 0  # 0 = disabled. If >0, bypasses pilot for short queries


def compute_signals(dense_scores: List[float] = None,
                    sparse_scores: List[float] = None,
                    dense_docs: List[str] = None,
                    sparse_docs: List[str] = None,
                    query: str = None,
                    idf_lookup: dict = None,
                    corpus_size: int = 0,
                    dense_score_type: ScoreType = ScoreType.COSINE,
                    sparse_score_type: ScoreType = ScoreType.RAW,
                    custom_dense_normalizer: Callable = None,
                    custom_sparse_normalizer: Callable = None,
                    min_pilot_results: int = 3,
                    analyze_top_k: int = 10) -> PilotSignals:
    """Compute the 11-signal feature vector from pilot retrieval scores.

    Handles four critical edge cases:
    1. Score scale mismatch: normalizes via ScoreType before analysis
    2. Missing IDF data: sets has_idf_data=False so router skips rarity logic
    3. Too few results: sets low_confidence_pilot=True for safe routing
    4. High pilot_k warping: truncates inputs to `analyze_top_k` (10)

    Args:
        dense_scores: Raw scores from your dense retriever.
        sparse_scores: Raw scores from your sparse retriever.
        dense_docs: Document IDs from dense results.
        sparse_docs: Document IDs from sparse results.
        query: Raw query string (for IDF rarity).
        idf_lookup: Token -> IDF value mapping from your index.
        corpus_size: Total docs in corpus.
        dense_score_type: Scale of dense scores (COSINE, L2, DOT_PRODUCT, CUSTOM).
        sparse_score_type: Scale of sparse scores.
        custom_dense_normalizer: Function for CUSTOM dense normalization.
        custom_sparse_normalizer: Function for CUSTOM sparse normalization.
        min_pilot_results: Minimum results needed for reliable signal extraction.
        analyze_top_k: Number of top results to analyze to prevent statistical warping.
    """
    sig = PilotSignals()

    # FIX #7: Prevent statistical warping by truncating large pilots
    dense_scores = (dense_scores or [])[:analyze_top_k]
    sparse_scores = (sparse_scores or [])[:analyze_top_k]
    dense_docs = (dense_docs or [])[:analyze_top_k]
    sparse_docs = (sparse_docs or [])[:analyze_top_k]

    # FIX #1: normalize scores to [0, 1] before any computation
    dense_scores = normalize_scores(dense_scores, dense_score_type, custom_dense_normalizer)
    sparse_scores = normalize_scores(sparse_scores, sparse_score_type, custom_sparse_normalizer)

    # Set architecture flags for legacy systems
    sig.is_sparse_only = not dense_scores and bool(sparse_scores)
    sig.is_dense_only = not sparse_scores and bool(dense_scores)
    sig.sparse_is_raw = (sparse_score_type == ScoreType.RAW)

    # FIX #3: flag when pilot returned too few results
    total_results = len(dense_scores) + len(sparse_scores)
    if total_results < min_pilot_results:
        sig.low_confidence_pilot = True

    # dense score distribution
    if dense_scores:
        # Fix #2: sort descending so top1_top5_margin is always correct
        # even if the user passed unsorted results from their DB
        dense_sorted = sorted(dense_scores, reverse=True)
        sig.max_dense = dense_sorted[0]
        _mean = sum(dense_sorted) / len(dense_sorted)
        sig.mean_dense = _mean
        _var = sum((x - _mean) ** 2 for x in dense_sorted) / len(dense_sorted)
        sig.std_dense = _var ** 0.5
        sig.top1_top5_margin = (
            dense_sorted[0] - dense_sorted[min(4, len(dense_sorted) - 1)]
            if len(dense_sorted) > 1 else 0.0
        )

    # sparse score distribution (RAW by default to preserve variance)
    if sparse_scores:
        sig.bm25_max = max(sparse_scores)
        sig.bm25_mean = sum(sparse_scores) / len(sparse_scores)

    # dense-sparse agreement
    if dense_docs and sparse_docs:
        k = min(len(dense_docs), len(sparse_docs), 10)
        sig.dense_bm25_overlap = len(
            set(dense_docs[:k]) & set(sparse_docs[:k])
        ) / max(k, 1)

    # score distribution entropy
    if dense_scores and len(dense_scores) > 1:
        arr_max = max(dense_scores)
        shifted = [x - arr_max for x in dense_scores]
        exp_arr = [math.exp(x) for x in shifted]
        exp_sum = sum(exp_arr) + 1e-9
        probs = [e / exp_sum for e in exp_arr]
        sig.entropy = -sum(p * math.log(p + 1e-9) for p in probs)

    # document diversity
    sig.unique_doc_count = len(set(dense_docs + sparse_docs))

    # FIX #2: only compute rarity when IDF data is actually provided
    if query and idf_lookup and corpus_size > 0:
        tokens = re.findall(r'\b[a-zA-Z]{2,}\b', query.lower())
        if tokens:
            max_unseen_idf = math.log((corpus_size + 1) / 1) + 1
            rarity_scores = []
            for t in tokens:
                if t in idf_lookup:
                    try:
                        exp_val = math.exp(idf_lookup[t])
                        freq = corpus_size / exp_val
                        r = math.log((corpus_size + 1) / (freq + 1)) + 1
                        rarity_scores.append(r)
                    except (OverflowError, ValueError):
                        # IDF value too large for math.exp — treat as max rarity
                        rarity_scores.append(max_unseen_idf)
                else:
                    rarity_scores.append(max_unseen_idf)
            if rarity_scores:
                sig.query_rarity = sum(rarity_scores)
                sig.max_term_rarity = max(rarity_scores)
                sig.has_idf_data = True

    return sig
