from abc import ABC
from typing import List, Tuple


class RetrievalAdapter(ABC):
    """Interface for connecting any retrieval backend to the router.

    Implement this adapter to connect your specific pipeline.
    The router calls dense_search/sparse_search to get a small batch
    of pilot scores, then uses those to decide the retrieval strategy.

    You only need to implement the search method(s) you have:
    - Dense-only system (Pinecone, Qdrant): override dense_search only
    - Sparse-only system (Elasticsearch): override sparse_search only
    - Hybrid system (FAISS + BM25): override both

    Example implementations:
    - FAISSAdapter: wraps a FAISS index + BM25Okapi
    - PineconeAdapter: wraps a Pinecone client
    - WeaviateAdapter: wraps a Weaviate collection
    - ChromaAdapter: wraps a ChromaDB collection
    """

    def dense_search(self, query: str, k: int = 10) -> Tuple[List[float], List[str]]:
        """Run a fast dense (vector) pilot search.

        Args:
            query: The raw query string.
            k: Number of results to return.

        Returns:
            Tuple of (scores, doc_ids) where:
            - scores: similarity scores (higher = more similar)
            - doc_ids: document identifiers for overlap computation

        Override this if your system has a vector retriever.
        Default returns empty lists (no dense retrieval).
        """
        return [], []

    def sparse_search(self, query: str, k: int = 10) -> Tuple[List[float], List[str]]:
        """Run a fast sparse (keyword) pilot search.

        Args:
            query: The raw query string.
            k: Number of results to return.

        Returns:
            Tuple of (scores, doc_ids)

        Override this if your system has a keyword retriever (BM25, TF-IDF).
        Default returns empty lists (no sparse retrieval).
        """
        return [], []

    def get_idf_stats(self) -> Tuple[dict, int]:
        """Return (idf_lookup_dict, corpus_size) for rarity computation.

        Optional. If not implemented, query rarity signals will be zero.
        """
        return {}, 0
