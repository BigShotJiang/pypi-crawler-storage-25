from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="lex-router",
    version="0.1.1",
    author="Vedant Ghadi",
    description="A domain-agnostic adaptive query router for RAG systems. "
                "Routes queries using multi-signal retrieval score analysis, not vocabularies.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Vedant-ghadi/LexLegal",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Text Processing :: Linguistic",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
    ],
    python_requires=">=3.7",
    install_requires=[],
)
