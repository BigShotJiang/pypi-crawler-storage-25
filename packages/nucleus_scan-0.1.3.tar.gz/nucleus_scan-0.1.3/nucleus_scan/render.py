"""Renderer — TTY box-drawn report; pipe = plain; --json passes through.

Rules:
    - tty (sys.stdout.isatty()): box-drawn, ANSI color, emoji status.
    - pipe (no tty): plain text, no ANSI, no box, no emoji.
    - --json: caller skips this module entirely; dumps report dict.

Status icons:
    ok      🟢   (or [OK] in plain mode)
    drift   🟡
    n_a     ⚪   (or [N/A])
    timeout ⏱
    crashed 🔴
    error   🔴
"""
from __future__ import annotations

import sys
from typing import Dict

_ICONS_TTY = {"ok": "🟢", "drift": "🟡", "n_a": "⚪", "timeout": "⏱", "crashed": "🔴", "error": "🔴"}
_ICONS_PLAIN = {"ok": "[OK]", "drift": "[!]", "n_a": "[N/A]", "timeout": "[T/O]", "crashed": "[ERR]", "error": "[ERR]"}


def _icon(status: str, tty: bool) -> str:
    return (_ICONS_TTY if tty else _ICONS_PLAIN).get(status, "?")


def _engine_line(name: str, result: Dict, tty: bool) -> str:
    status = result["status"]
    icon = _icon(status, tty)
    if status == "ok":
        score = result.get("score", 0)
        if name == "plan_rot":
            c = result.get("counts", {})
            return f"{icon} plans: {c.get('ok', 0)}/{c.get('total', 0)} verified ({score}/100)"
        if name == "cve":
            n = len(result.get("findings", []))
            return f"{icon} deps: {n} CVEs ({score}/100)"
        if name == "intel":
            c = result.get("counts", {})
            return f"{icon} sessions: {c.get('total_corrections', 0)} ungrounded corrections in last {c.get('sessions_scanned', 0)} ({score}/100)"
    return f"{icon} {name}: {status} — {result.get('reason', '')}"


def render(report: Dict, tty: bool = None) -> str:
    if tty is None:
        tty = sys.stdout.isatty()

    lines = []
    score = report["score"]
    if score is None:
        lines.append("Insufficient signal — no engines applied to this project.")
        lines.append("")
        lines.append("Why each engine did not score:")
        for name, r in report["engines"].items():
            icon = _icon(r["status"], tty)
            lines.append(f"  {icon} {name}: {r['status']} — {r.get('reason', '')}")
        next_steps = [
            (name, r.get("next_step"))
            for name, r in report["engines"].items()
            if r.get("next_step")
        ]
        if next_steps:
            lines.append("")
            lines.append("Next steps to unlock a score:")
            for i, (name, step) in enumerate(next_steps, 1):
                lines.append(f"  {i}. [{name}] {step}")
        return "\n".join(lines)

    header = f"AI Hygiene Report — {score}/100"
    if tty:
        bar = "─" * (len(header) + 2)
        lines.append(f"┌{bar}┐")
        lines.append(f"│ {header} │")
        lines.append(f"└{bar}┘")
    else:
        lines.append(header)
        lines.append("=" * len(header))

    for name, r in report["engines"].items():
        lines.append("  " + _engine_line(name, r, tty))

    # Top-3 findings (highest leverage)
    fixes = []
    plan = report["engines"].get("plan_rot", {})
    if plan.get("status") == "ok":
        for f in plan.get("findings", [])[:2]:
            if f["bucket"] == "unverifiable":
                fixes.append(f"add `## Verification` with bash block to {f['plan']}")
            elif f["bucket"] == "drift":
                fixes.append(f"re-audit {f['plan']} ({len(f['drifted_files'])} files drifted)")
    cve_r = report["engines"].get("cve", {})
    if cve_r.get("status") == "ok" and cve_r.get("findings"):
        f = cve_r["findings"][0]
        fix_to = f.get("fix_versions", ["?"])
        fixes.append(f"upgrade {f['package']} to {fix_to[0] if fix_to else '?'} ({f['id']})")

    if fixes:
        lines.append("")
        lines.append("Top fixes:")
        for i, fx in enumerate(fixes[:3], 1):
            lines.append(f"  {i}. {fx}")

    # Surface next_step hints for engines that didn't score (n_a / error / etc.)
    # so partial-coverage repos can unlock the missing engine(s).
    unlock_steps = [
        (name, r["next_step"])
        for name, r in report["engines"].items()
        if r.get("status") != "ok" and r.get("next_step")
    ]
    if unlock_steps:
        lines.append("")
        lines.append("To unlock more coverage:")
        for i, (name, step) in enumerate(unlock_steps, 1):
            lines.append(f"  {i}. [{name}] {step}")

    lines.append("")
    lines.append(f"({report['elapsed_s']}s)")
    return "\n".join(lines)
