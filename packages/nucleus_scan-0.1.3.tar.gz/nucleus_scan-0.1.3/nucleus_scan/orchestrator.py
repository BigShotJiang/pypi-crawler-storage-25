"""Orchestrator — run 3 engines in parallel, aggregate, score.

State machine per engine:

    pending ──▶ running ──▶ done    (engine.run() returned)
                  │
                  ├──▶ timeout      (Future.result(timeout=) raised)
                  │
                  └──▶ crashed      (engine.run() raised)

Aggregation:
    - Each engine returns {score, status, findings, ...}.
    - status ∈ {ok, n_a, timeout, error, crashed}.
    - Engines with status=ok contribute their score; others contribute None
      to score.compute() and are excluded from the weighted average.

The per-engine timeout (default 30s) is enforced at the future layer so
a hung subprocess can't wedge the whole report.
"""
from __future__ import annotations

import time
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FuturesTimeout
from pathlib import Path
from typing import Dict, Optional

from . import score as score_mod
from .engines import cve, plan_lint, session_intel

_ENGINES = {
    "plan_rot": plan_lint.run,
    "cve": cve.run,
    "intel": session_intel.run,
}


def _safe_run(name: str, fn, project_root: Path, timeout_s: int) -> Dict:
    """Wrap an engine call with crash isolation. Timeout enforced upstream."""
    try:
        return fn(project_root)
    except Exception as e:  # noqa: BLE001 — engine crash isolation by design
        return {
            "score": None,
            "status": "crashed",
            "reason": f"{type(e).__name__}: {e}",
            "findings": [],
        }


def scan(project_root: Path, timeout_s: int = 30) -> Dict:
    """Run all engines, return aggregated report dict."""
    started = time.time()
    results: Dict[str, Dict] = {}

    with ThreadPoolExecutor(max_workers=len(_ENGINES)) as pool:
        futures = {
            name: pool.submit(_safe_run, name, fn, project_root, timeout_s)
            for name, fn in _ENGINES.items()
        }
        for name, fut in futures.items():
            try:
                results[name] = fut.result(timeout=timeout_s)
            except FuturesTimeout:
                results[name] = {
                    "score": None,
                    "status": "timeout",
                    "reason": f"engine exceeded {timeout_s}s",
                    "findings": [],
                }
                fut.cancel()

    engine_scores: Dict[str, Optional[float]] = {
        name: (r["score"] if r["status"] == "ok" else None)
        for name, r in results.items()
    }
    overall = score_mod.compute(engine_scores)

    return {
        "project_root": str(project_root),
        "score": overall,
        "engines": results,
        "elapsed_s": round(time.time() - started, 2),
    }
