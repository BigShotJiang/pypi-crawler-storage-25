"""Plan-rot engine — walk a project's plans dir, classify each markdown.

Buckets (per plan):
    unverifiable  — has neither `## Files Modified` nor a `## Verification`
                    section with a runnable bash fence.
    drift         — referenced files have mtime > plan mtime (code changed
                    after the plan was written).
    ok            — has both sections + no drift.

Score: 100 * ok / total. Returns (None, "no_plans_dir") if no plans found
anywhere we look.
"""
from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Optional, Tuple

from ._plan_parser import (
    extract_modified_files,
    has_files_modified_section,
    has_runnable_verification_section,
)

_PLAN_DIRS = ("plans", ".plans", "docs/plans", ".claude/plans", ".brain/plans")


def find_plans(project_root: Path) -> List[Path]:
    plans: List[Path] = []
    for sub in _PLAN_DIRS:
        d = project_root / sub
        if d.is_dir():
            plans.extend(sorted(d.rglob("*.md")))
    return plans


def classify(plan_path: Path) -> Tuple[str, List[str]]:
    """Return (bucket, drifted_files). bucket ∈ {ok, unverifiable, drift}."""
    try:
        text = plan_path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return "unverifiable", []

    if not (has_files_modified_section(text) and has_runnable_verification_section(text)):
        return "unverifiable", []

    plan_mtime = plan_path.stat().st_mtime
    drifted: List[str] = []
    for rel in extract_modified_files(text):
        f = (plan_path.parent / rel).resolve()
        if not f.exists():
            # Try project-root-relative
            f = (plan_path.parents[1] / rel).resolve() if len(plan_path.parents) > 1 else f
        if f.exists() and f.stat().st_mtime > plan_mtime:
            drifted.append(rel)
    if drifted:
        return "drift", drifted
    return "ok", []


def run(project_root: Path) -> Dict:
    """Returns {score, status, findings, counts}."""
    plans = find_plans(project_root)
    if not plans:
        return {
            "score": None,
            "status": "n_a",
            "reason": "no plans dir found (looked in plans/, .plans/, docs/plans/, .claude/plans/, .brain/plans/)",
            "next_step": (
                "create .brain/plans/ (or plans/) and drop in a markdown file "
                "with `## Files Modified` and `## Verification` (bash block) "
                "sections to enable plan_rot"
            ),
            "findings": [],
            "counts": {"total": 0},
        }

    counts = {"ok": 0, "unverifiable": 0, "drift": 0, "total": len(plans)}
    findings: List[Dict] = []
    for p in plans:
        bucket, drifted = classify(p)
        counts[bucket] += 1
        if bucket != "ok":
            findings.append({
                "plan": str(p.relative_to(project_root)),
                "bucket": bucket,
                "drifted_files": drifted,
            })

    score = 100.0 * counts["ok"] / counts["total"]
    return {
        "score": round(score, 1),
        "status": "ok",
        "findings": findings,
        "counts": counts,
    }
