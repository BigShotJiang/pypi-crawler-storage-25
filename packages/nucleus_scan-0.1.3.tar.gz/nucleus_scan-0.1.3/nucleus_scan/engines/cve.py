"""CVE engine — pip-audit -r requirements.txt, project-scoped.

Mirrors scripts/levers/dep_vulnerability_check.py's scoping rule:
without -r, pip-audit walks the active interpreter's site-packages and
reports CVEs from the user's global python install. We require
requirements.txt at the project root.

Score: 100 if 0 vulns, else max(0, 100 - 10*vuln_count) capped.
N/A if no requirements.txt or pip-audit not installed.
"""
from __future__ import annotations

import json
import re
import shutil
import subprocess
from pathlib import Path
from typing import Any, Dict, List, Optional


_NO_MATCHING_DIST_RE = re.compile(
    r"No matching distribution found for (\S+)"
)
_REQUIRES_PYTHON_RE = re.compile(
    r"Requires-Python\s*([^\s;,)]+)"
)


def _diagnose_subprocess_failure(stderr: str) -> Optional[str]:
    """Translate known pip-audit subprocess failure patterns to a user-legible
    reason. Returns None if no pattern matches (caller falls back to raw tail).

    Covers the common case seen on Nucleus's own repo: requirements.txt pins a
    package requiring Python >= X, pip-audit's subprocess venv uses an older
    interpreter, user sees a raw shell-invocation fragment and assumes crash.
    """
    if not stderr:
        return None
    miss = _NO_MATCHING_DIST_RE.search(stderr)
    if miss:
        pkg = miss.group(1)
        pyver = _REQUIRES_PYTHON_RE.search(stderr)
        if pyver:
            return (
                f"dependency resolution failed: {pkg} not installable in audit "
                f"environment (requires Python {pyver.group(1)}; pip-audit "
                f"subprocess may be using an older interpreter)"
            )
        return (
            f"dependency resolution failed: {pkg} not installable in audit "
            f"environment (likely Python-version or platform mismatch)"
        )
    if "Failed to install packages" in stderr or "internal pip failure" in stderr:
        return (
            "pip-audit could not resolve requirements.txt "
            "(likely Python-version or platform mismatch)"
        )
    return None


def _filter_stderr(stderr: str) -> str:
    """Drop warning-emitter noise, return last 300 chars of what remains.

    pip-audit leaks urllib3/DeprecationWarning lines to stderr even on a
    clean run. A head-biased truncate eats those and hides the real error;
    this filters by line-prefix/substring instead of maintaining a brittle
    warning-class allow-list.
    """
    kept = []
    for line in (stderr or "").splitlines():
        if line.startswith("WARNING:"):
            continue
        if "warnings.warn(" in line:
            continue
        if "Warning:" in line:
            continue
        kept.append(line)
    return "\n".join(kept).strip()[-300:]


def _extract_dependencies(payload: Any) -> List[Dict]:
    if isinstance(payload, list):
        return [d for d in payload if isinstance(d, dict)]
    if isinstance(payload, dict):
        deps = payload.get("dependencies")
        if isinstance(deps, list):
            return [d for d in deps if isinstance(d, dict)]
    return []


def run(project_root: Path, timeout_s: int = 30) -> Dict:
    req = project_root / "requirements.txt"
    if not req.is_file():
        return {
            "score": None,
            "status": "n_a",
            "reason": "no requirements.txt at project root",
            "next_step": (
                "add requirements.txt at the project root (e.g. "
                "`pip freeze > requirements.txt`) to enable the cve engine"
            ),
            "findings": [],
        }

    if not shutil.which("pip-audit"):
        return {
            "score": None,
            "status": "n_a",
            "reason": "pip-audit not installed (pip install pip-audit)",
            "next_step": (
                "install pip-audit (`pipx inject nucleus-scan pip-audit` or "
                "`pip install pip-audit`) to enable the cve engine"
            ),
            "findings": [],
        }

    try:
        result = subprocess.run(
            ["pip-audit", "-r", str(req), "--format", "json"],
            capture_output=True,
            text=True,
            timeout=timeout_s,
            cwd=project_root,
        )
    except subprocess.TimeoutExpired:
        return {
            "score": None,
            "status": "timeout",
            "reason": f"pip-audit exceeded {timeout_s}s (network slow?)",
            "findings": [],
        }

    stdout = result.stdout.strip()
    if not stdout:
        if result.returncode == 0:
            return {"score": 100.0, "status": "ok", "findings": []}
        diag = _diagnose_subprocess_failure(result.stderr)
        return {
            "score": None,
            "status": "error",
            "reason": diag or _filter_stderr(result.stderr) or f"exit {result.returncode}",
            "next_step": (
                "run pip-audit with an interpreter that matches requirements.txt's "
                "Python version (e.g. `pipx reinstall nucleus-scan --python python3.12`)"
                if diag else
                "re-run pip-audit directly against requirements.txt to see the full error"
            ),
            "findings": [],
        }

    try:
        payload = json.loads(stdout)
    except json.JSONDecodeError as e:
        return {"score": None, "status": "error", "reason": f"bad json: {e}", "findings": []}

    deps = _extract_dependencies(payload)
    findings: List[Dict] = []
    for dep in deps:
        name = dep.get("name") or dep.get("package") or "?"
        version = dep.get("version") or "?"
        for vuln in dep.get("vulns") or []:
            vid = vuln.get("id") or "?"
            fixes = vuln.get("fix_versions") or []
            findings.append({
                "package": name,
                "version": version,
                "id": vid,
                "fix_versions": fixes,
            })

    score = max(0.0, 100.0 - 10.0 * len(findings))
    return {
        "score": round(score, 1),
        "status": "ok",
        "findings": findings,
        "counts": {"vulns": len(findings), "deps_audited": len(deps)},
    }
