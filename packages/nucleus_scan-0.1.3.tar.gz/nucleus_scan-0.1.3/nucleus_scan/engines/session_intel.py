"""Session intel engine — count un-mined corrections + ungrounded reasoning.

Looks at ~/.claude/projects/<this-project>/*.jsonl (Claude Code captures).
For v0.1.0 we just COUNT signals — actual extraction lives in the
substrate's flywheel_capture_extractor (and is ledger-tracked separately).

Score: 100 if 0 ungrounded corrections, else degrades 5 points per signal.
N/A if no ~/.claude/projects/ dir or no sessions for this project.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, List

# Same correction markers as flywheel_capture_extractor._CORRECTION_MARKERS
_CORRECTION_MARKERS = (
    "no, ", "no don't", "don't ", "stop ", "wrong",
    "that's wrong", "that's not", "instead", "actually", "no — ",
)


def _project_capture_dir(project_root: Path) -> Path:
    """Claude Code stores captures at ~/.claude/projects/-Users-foo-bar/."""
    encoded = str(project_root.resolve()).replace("/", "-")
    return Path.home() / ".claude" / "projects" / encoded


def _looks_like_correction(text: str) -> bool:
    if not text:
        return False
    low = text.strip().lower()
    return any(low.startswith(m) or m in low[:80] for m in _CORRECTION_MARKERS)


def _extract_text(message) -> str:
    if isinstance(message, str):
        return message
    if isinstance(message, dict):
        c = message.get("content")
        if isinstance(c, str):
            return c
        if isinstance(c, list):
            return "\n".join(
                i.get("text", "") for i in c
                if isinstance(i, dict) and i.get("type") == "text"
            )
    return ""


def _scan_session(path: Path) -> int:
    """Return count of user corrections in this session."""
    count = 0
    prev_role = ""
    try:
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    turn = json.loads(line)
                except json.JSONDecodeError:
                    continue
                msg = turn.get("message", turn)
                role = msg.get("role", turn.get("type", "")) if isinstance(msg, dict) else ""
                text = _extract_text(msg)
                if role == "user" and prev_role == "assistant" and _looks_like_correction(text):
                    count += 1
                prev_role = role
    except (OSError, UnicodeDecodeError):
        return 0
    return count


def run(project_root: Path, max_sessions: int = 10) -> Dict:
    cap_dir = _project_capture_dir(project_root)
    if not cap_dir.is_dir():
        return {
            "score": None,
            "status": "n_a",
            "reason": f"no Claude Code sessions for this project ({cap_dir})",
            "next_step": (
                "use Claude Code in this project at least once so captures "
                "appear under ~/.claude/projects/; intel will score on next run"
            ),
            "findings": [],
        }

    sessions = sorted(cap_dir.glob("*.jsonl"), key=lambda p: p.stat().st_mtime, reverse=True)
    if not sessions:
        return {
            "score": None,
            "status": "n_a",
            "reason": "no session jsonls found",
            "next_step": (
                "use Claude Code in this project to generate at least one "
                "session jsonl under ~/.claude/projects/"
            ),
            "findings": [],
        }

    sessions = sessions[:max_sessions]
    total_corrections = 0
    findings: List[Dict] = []
    for s in sessions:
        n = _scan_session(s)
        total_corrections += n
        if n > 0:
            findings.append({"session": s.stem, "corrections": n})

    score = max(0.0, 100.0 - 5.0 * total_corrections)
    return {
        "score": round(score, 1),
        "status": "ok",
        "findings": findings,
        "counts": {
            "sessions_scanned": len(sessions),
            "total_corrections": total_corrections,
        },
    }
