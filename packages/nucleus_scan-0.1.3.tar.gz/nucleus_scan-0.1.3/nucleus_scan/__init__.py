"""nucleus-scan — AI Hygiene Report for any project."""
__version__ = "0.1.2"
