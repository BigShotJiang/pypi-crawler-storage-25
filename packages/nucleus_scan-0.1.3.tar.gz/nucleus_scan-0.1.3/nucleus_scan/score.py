"""Score formula — single source of truth.

DO NOT TWEAK weights or N/A semantics without bumping the minor version.
The score is the load-bearing number users compare across runs and
projects; drift here invalidates every prior score on disk.

Weights:
    plan_rot   40%   — unverifiable + drifted plans (highest signal of AI rot)
    cve        40%   — known dep vulnerabilities (table stakes, but heavy)
    intel      20%   — un-mined corrections + ungrounded audit reasoning

N/A semantics:
    An engine that doesn't apply (no requirements.txt → CVE N/A; no plans
    dir → plan rot N/A; no ~/.claude/projects/ → intel N/A) is excluded
    from the weighted average and its weight is redistributed pro-rata
    across the remaining engines. If ALL engines are N/A we return None
    and the renderer prints "Insufficient signal" (avoids the misleading
    100/100 on an empty repo).
"""
from __future__ import annotations
from typing import Dict, Optional

WEIGHTS: Dict[str, float] = {
    "plan_rot": 0.40,
    "cve": 0.40,
    "intel": 0.20,
}


def compute(engine_scores: Dict[str, Optional[float]]) -> Optional[float]:
    """Return weighted score 0-100, or None if all engines are N/A.

    engine_scores values: 0.0-100.0 for applicable engines, None for N/A.
    """
    applicable = {k: v for k, v in engine_scores.items() if v is not None}
    if not applicable:
        return None
    total_weight = sum(WEIGHTS[k] for k in applicable)
    weighted = sum(applicable[k] * WEIGHTS[k] for k in applicable)
    return round(weighted / total_weight, 1)
