"""nucleus-scan CLI entry point.

Refuses to scan $HOME (slow + scary). Exits 2 on guard violations,
0 normally, exit code = (--fail-under N if score < N) otherwise 0.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

from . import __version__
from .orchestrator import scan
from .render import render


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        prog="nucleus-scan",
        description="AI Hygiene Report — scan a project for plan rot, dep CVEs, and ungrounded reasoning.",
    )
    parser.add_argument("path", nargs="?", default=".", help="project dir (default: cwd)")
    parser.add_argument("--json", action="store_true", help="emit JSON instead of human report")
    parser.add_argument("--timeout", type=int, default=30, help="per-engine timeout (seconds)")
    parser.add_argument(
        "--fail-under", type=float, default=None,
        help="exit non-zero if overall score < N (CI gate)",
    )
    parser.add_argument("--version", action="version", version=f"nucleus-scan {__version__}")
    args = parser.parse_args(argv)

    project_root = Path(args.path).resolve()

    if not project_root.is_dir():
        print(f"error: {project_root} is not a directory", file=sys.stderr)
        return 2
    if project_root == Path.home():
        print("error: refuse to scan $HOME — cd into a project directory first", file=sys.stderr)
        return 2
    if project_root == Path("/"):
        print("error: refuse to scan / — cd into a project directory first", file=sys.stderr)
        return 2

    report = scan(project_root, timeout_s=args.timeout)

    if args.json:
        print(json.dumps(report, indent=2, default=str))
    else:
        print(render(report))

    if args.fail_under is not None and report["score"] is not None:
        if report["score"] < args.fail_under:
            return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
