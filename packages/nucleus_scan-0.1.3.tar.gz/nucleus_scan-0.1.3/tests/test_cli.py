import json
from pathlib import Path
from unittest import mock

from nucleus_scan import cli


def test_refuses_home(capsys):
    rc = cli.main([str(Path.home())])
    out = capsys.readouterr().err
    assert rc == 2
    assert "$HOME" in out


def test_refuses_root(capsys):
    rc = cli.main(["/"])
    assert rc == 2


def test_fail_under_triggers_exit_1(tmp_path):
    fake_report = {
        "project_root": str(tmp_path),
        "score": 50.0,
        "engines": {},
        "elapsed_s": 0.01,
    }
    with mock.patch.object(cli, "scan", return_value=fake_report):
        assert cli.main([str(tmp_path), "--fail-under", "80"]) == 1
        assert cli.main([str(tmp_path), "--fail-under", "40"]) == 0


def test_json_output_is_valid(tmp_path, capsys):
    fake_report = {
        "project_root": str(tmp_path),
        "score": 75.0,
        "engines": {},
        "elapsed_s": 0.01,
    }
    with mock.patch.object(cli, "scan", return_value=fake_report):
        cli.main([str(tmp_path), "--json"])
    parsed = json.loads(capsys.readouterr().out)
    assert parsed["score"] == 75.0
