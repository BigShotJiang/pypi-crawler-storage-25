import time
from pathlib import Path
from unittest import mock

from nucleus_scan import orchestrator


def _ok(score):
    return {"score": score, "status": "ok", "findings": []}


def test_aggregates_three_ok_engines(tmp_path):
    fake = {
        "plan_rot": lambda p: _ok(100),
        "cve": lambda p: _ok(100),
        "intel": lambda p: _ok(100),
    }
    with mock.patch.object(orchestrator, "_ENGINES", fake):
        report = orchestrator.scan(tmp_path)
    assert report["score"] == 100.0
    assert set(report["engines"].keys()) == {"plan_rot", "cve", "intel"}


def test_engine_crash_isolated(tmp_path):
    def boom(p):
        raise RuntimeError("kaboom")
    fake = {
        "plan_rot": lambda p: _ok(80),
        "cve": boom,
        "intel": lambda p: _ok(100),
    }
    with mock.patch.object(orchestrator, "_ENGINES", fake):
        report = orchestrator.scan(tmp_path)
    assert report["engines"]["cve"]["status"] == "crashed"
    assert "kaboom" in report["engines"]["cve"]["reason"]
    # score computed from surviving engines only
    assert report["score"] is not None


def test_engine_timeout_surfaced(tmp_path):
    def slow(p):
        time.sleep(5)
        return _ok(100)
    fake = {
        "plan_rot": lambda p: _ok(100),
        "cve": slow,
        "intel": lambda p: _ok(100),
    }
    with mock.patch.object(orchestrator, "_ENGINES", fake):
        report = orchestrator.scan(tmp_path, timeout_s=1)
    assert report["engines"]["cve"]["status"] == "timeout"
    assert report["score"] is not None  # other engines still counted


def test_all_na_returns_none_score(tmp_path):
    na = {"score": None, "status": "n_a", "reason": "nope", "findings": []}
    fake = {
        "plan_rot": lambda p: na,
        "cve": lambda p: na,
        "intel": lambda p: na,
    }
    with mock.patch.object(orchestrator, "_ENGINES", fake):
        report = orchestrator.scan(tmp_path)
    assert report["score"] is None
