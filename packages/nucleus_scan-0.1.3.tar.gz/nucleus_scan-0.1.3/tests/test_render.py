from nucleus_scan.render import render


def _report(score, engines):
    return {"project_root": "/x", "score": score, "engines": engines, "elapsed_s": 0.1}


def test_insufficient_signal_when_score_none():
    r = _report(None, {"plan_rot": {"status": "n_a", "reason": "no plans dir"}})
    out = render(r, tty=False)
    assert "Insufficient signal" in out


def test_all_na_surfaces_next_steps():
    engines = {
        "plan_rot": {
            "status": "n_a",
            "reason": "no plans dir found",
            "next_step": "create .brain/plans/ with `## Verification` section",
        },
        "cve": {
            "status": "n_a",
            "reason": "no requirements.txt",
            "next_step": "add requirements.txt at project root",
        },
        "intel": {
            "status": "n_a",
            "reason": "no Claude Code sessions",
            "next_step": "use Claude Code in this project",
        },
    }
    out = render(_report(None, engines), tty=False)
    assert "Why each engine did not score" in out
    assert "Next steps to unlock a score" in out
    assert "[plan_rot]" in out
    assert "[cve]" in out
    assert "[intel]" in out
    assert "create .brain/plans/" in out
    assert "requirements.txt" in out


def test_all_na_without_next_step_hides_unlock_section():
    # Older engines without next_step should not synthesize a bogus block.
    r = _report(None, {"plan_rot": {"status": "n_a", "reason": "no plans dir"}})
    out = render(r, tty=False)
    assert "Next steps to unlock a score" not in out


def test_partial_coverage_shows_unlock_hints():
    engines = {
        "plan_rot": {
            "status": "ok", "score": 100,
            "counts": {"ok": 1, "total": 1}, "findings": [],
        },
        "cve": {
            "status": "n_a", "reason": "no reqs",
            "next_step": "add requirements.txt at project root",
        },
        "intel": {
            "status": "n_a", "reason": "no sessions",
            "next_step": "use Claude Code in this project",
        },
    }
    out = render(_report(100.0, engines), tty=False)
    assert "To unlock more coverage" in out
    assert "[cve]" in out
    assert "[intel]" in out


def test_plain_mode_no_emoji():
    engines = {
        "plan_rot": {"status": "ok", "score": 100, "counts": {"ok": 3, "total": 3}, "findings": []},
        "cve": {"status": "ok", "score": 100, "findings": []},
        "intel": {"status": "ok", "score": 100, "counts": {"total_corrections": 0, "sessions_scanned": 10}, "findings": []},
    }
    out = render(_report(100.0, engines), tty=False)
    assert "[OK]" in out
    assert "🟢" not in out
    assert "100/100" in out


def test_top_fixes_surfaces_unverifiable_plan():
    engines = {
        "plan_rot": {
            "status": "ok", "score": 50,
            "counts": {"ok": 1, "total": 2},
            "findings": [{"bucket": "unverifiable", "plan": "foo.md"}],
        },
        "cve": {"status": "n_a", "reason": "no reqs"},
        "intel": {"status": "n_a", "reason": "no sessions"},
    }
    out = render(_report(50.0, engines), tty=False)
    assert "foo.md" in out
    assert "Verification" in out
