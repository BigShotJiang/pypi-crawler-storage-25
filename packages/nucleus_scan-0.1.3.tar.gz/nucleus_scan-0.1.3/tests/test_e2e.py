"""End-to-end orchestrator tests against real fixture repos.

Covers the _plan_parser and session parser paths that unit tests mock around.
"""
import os
import time
from unittest import mock

from nucleus_scan import orchestrator
from nucleus_scan.engines import session_intel


_GOOD_PLAN = """# Good Plan

## Files Modified
- foo.py

## Verification
```bash
pytest tests/
```
"""

_UNVERIFIABLE_PLAN = """# Unverifiable Plan

This plan is only prose. No sections the parser can hook.
"""

_DRIFT_PLAN = """# Drift Plan

## Files Modified
- drifted.py

## Verification
```bash
echo ok
```
"""


def test_scan_fixture_repo_three_plans(tmp_path):
    plans = tmp_path / "plans"
    plans.mkdir()
    (plans / "good.md").write_text(_GOOD_PLAN)
    (plans / "unverifiable.md").write_text(_UNVERIFIABLE_PLAN)

    drift_plan = plans / "drift.md"
    drift_plan.write_text(_DRIFT_PLAN)
    ref = tmp_path / "drifted.py"
    ref.write_text("x = 1\n")

    # Explicit mtime: plan in the past, ref in the future. No ordering reliance.
    t = time.time()
    os.utime(drift_plan, (t - 10, t - 10))
    os.utime(ref, (t + 10, t + 10))

    report = orchestrator.scan(tmp_path, timeout_s=10)

    plan_rot = report["engines"]["plan_rot"]
    assert plan_rot["status"] == "ok"
    counts = plan_rot["counts"]
    assert counts["total"] == 3
    assert counts["ok"] == 1
    assert counts["unverifiable"] == 1
    assert counts["drift"] == 1

    # No requirements.txt, no ~/.claude/projects entry for tmp_path
    assert report["engines"]["cve"]["status"] == "n_a"
    assert report["engines"]["intel"]["status"] == "n_a"
    # Score computed from plan_rot alone (weight redistributes)
    assert report["score"] is not None


def test_scan_detects_brain_plans_convention(tmp_path):
    brain_plans = tmp_path / ".brain" / "plans"
    brain_plans.mkdir(parents=True)
    (brain_plans / "migration.md").write_text(_GOOD_PLAN)

    report = orchestrator.scan(tmp_path, timeout_s=10)
    plan_rot = report["engines"]["plan_rot"]
    assert plan_rot["status"] == "ok"
    assert plan_rot["counts"]["total"] == 1
    assert plan_rot["counts"]["ok"] == 1


def test_malformed_session_skipped(tmp_path):
    cap_dir = tmp_path / "captures"
    cap_dir.mkdir()

    valid = cap_dir / "valid.jsonl"
    valid.write_text(
        '{"type":"assistant","message":{"role":"assistant","content":"hello"}}\n'
        '{"type":"user","message":{"role":"user","content":"no, that is wrong"}}\n'
    )

    bad = cap_dir / "bad.jsonl"
    bad.write_text('{"type":"assistant","message":{"role":"assis')  # truncated

    with mock.patch.object(session_intel, "_project_capture_dir", return_value=cap_dir):
        result = session_intel.run(tmp_path)

    assert result["status"] == "ok"
    assert result["counts"]["sessions_scanned"] == 2
    # The valid session has 1 correction; bad one silently skips
    assert result["counts"]["total_corrections"] >= 1
