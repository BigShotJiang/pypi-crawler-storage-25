"""CI template existence + parse checks.

These templates ship inside the package so downstream repos can reference
them. The tests guard against silent deletion or YAML-level breakage.
"""
from pathlib import Path

import yaml

_ROOT = Path(__file__).resolve().parent.parent


def test_precommit_hook_template_parses():
    path = _ROOT / ".pre-commit-hooks.yaml"
    assert path.exists(), f"missing {path}"
    hooks = yaml.safe_load(path.read_text())
    assert isinstance(hooks, list) and hooks, "must be a non-empty list"
    hook = hooks[0]
    assert hook["id"] == "nucleus-scan"
    assert "nucleus-scan" in hook["entry"]
    assert "--fail-under" in hook["entry"]


def test_github_workflow_template_parses():
    path = _ROOT / ".github" / "workflows" / "nucleus-scan.yml"
    assert path.exists(), f"missing {path}"
    wf = yaml.safe_load(path.read_text())
    # PyYAML parses the `on:` key as Python bool True — accept either form.
    trigger = wf.get("on", wf.get(True))
    assert trigger is not None, "workflow missing trigger block"
    assert "pull_request" in trigger
    jobs = wf["jobs"]
    assert "hygiene" in jobs
    steps = jobs["hygiene"]["steps"]
    assert any("nucleus-scan" in (s.get("run") or "") for s in steps)
