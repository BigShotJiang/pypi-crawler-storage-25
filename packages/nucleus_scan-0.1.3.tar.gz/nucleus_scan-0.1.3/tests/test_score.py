from nucleus_scan.score import compute, WEIGHTS


def test_all_perfect():
    assert compute({"plan_rot": 100, "cve": 100, "intel": 100}) == 100.0


def test_weighted_mix():
    # 50 * 0.4 + 100 * 0.4 + 0 * 0.2 = 60
    assert compute({"plan_rot": 50, "cve": 100, "intel": 0}) == 60.0


def test_na_engine_redistributes():
    # only plan_rot + cve apply; weights normalize 0.4/0.4 -> 0.5/0.5
    # 50 * 0.5 + 100 * 0.5 = 75
    assert compute({"plan_rot": 50, "cve": 100, "intel": None}) == 75.0


def test_all_na_returns_none():
    assert compute({"plan_rot": None, "cve": None, "intel": None}) is None


def test_weights_sum_to_one():
    assert abs(sum(WEIGHTS.values()) - 1.0) < 1e-9
