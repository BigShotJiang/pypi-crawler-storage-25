from nucleus_scan.engines.cve import _diagnose_subprocess_failure, _filter_stderr


def test_filter_drops_warnings_keeps_real_error():
    stderr = (
        "/path/urllib3/__init__.py:35: NotOpenSSLWarning: urllib3 v2 only supports OpenSSL 1.1.1+\n"
        "  warnings.warn(\n"
        "ERROR: Could not find version Flask-Limiter==4.1.1\n"
        "ERROR: No matching distribution found\n"
    )
    out = _filter_stderr(stderr)
    assert "urllib3" not in out
    assert "warnings.warn" not in out
    assert "Flask-Limiter" in out
    assert "No matching distribution" in out


def test_filter_empty_string():
    assert _filter_stderr("") == ""
    assert _filter_stderr(None) == ""


def test_filter_all_noise_returns_empty():
    stderr = (
        "WARNING: something something\n"
        "  warnings.warn(\n"
        "DeprecationWarning: foo\n"
    )
    assert _filter_stderr(stderr) == ""


def test_filter_truncates_tail_at_300():
    real_error = "X" * 500
    out = _filter_stderr(real_error)
    assert len(out) == 300
    assert out == "X" * 300


def test_diagnose_no_matching_distribution_with_python_requirement():
    stderr = (
        "ERROR: Ignored the following versions that require a different python "
        "version: 3.12 Requires-Python >=3.10; 4.1.1 Requires-Python >=3.10\n"
        "ERROR: Could not find a version that satisfies the requirement "
        "Flask-Limiter==4.1.1\n"
        "ERROR: No matching distribution found for Flask-Limiter==4.1.1\n"
    )
    diag = _diagnose_subprocess_failure(stderr)
    assert diag is not None
    assert "Flask-Limiter" in diag
    assert "Python" in diag
    assert ">=3.10" in diag


def test_diagnose_no_matching_distribution_without_python_hint():
    stderr = "ERROR: No matching distribution found for some-fake-pkg==1.0\n"
    diag = _diagnose_subprocess_failure(stderr)
    assert diag is not None
    assert "some-fake-pkg" in diag
    assert "platform" in diag or "Python" in diag


def test_diagnose_failed_to_install_packages():
    stderr = "ERROR:pip_audit._cli:Failed to install packages: ['python3', ...]\n"
    diag = _diagnose_subprocess_failure(stderr)
    assert diag is not None
    assert "requirements.txt" in diag


def test_diagnose_returns_none_on_unknown_pattern():
    assert _diagnose_subprocess_failure("") is None
    assert _diagnose_subprocess_failure("completely unrelated message") is None
