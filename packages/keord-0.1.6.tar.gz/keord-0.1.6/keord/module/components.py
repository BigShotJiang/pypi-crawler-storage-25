from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


def action_row(*components: dict[str, Any]) -> dict[str, Any]:
    return {"type": 1, "components": list(components)}


@dataclass(slots=True)
class Button:
    label: str
    custom_id: str
    style: int = 1  # primary
    disabled: bool = False
    emoji: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "type": 2,
            "style": self.style,
            "label": self.label,
            "custom_id": self.custom_id,
            "disabled": self.disabled,
        }
        if self.emoji is not None:
            payload["emoji"] = dict(self.emoji)
        return payload


@dataclass(slots=True)
class SelectOption:
    label: str
    value: str
    description: str | None = None
    emoji: dict[str, Any] | None = None
    default: bool = False

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {"label": self.label, "value": self.value, "default": self.default}
        if self.description is not None:
            d["description"] = self.description
        if self.emoji is not None:
            d["emoji"] = dict(self.emoji)
        return d


@dataclass(slots=True)
class SelectMenu:
    custom_id: str
    options: list[SelectOption] = field(default_factory=list)
    placeholder: str | None = None
    min_values: int | None = None
    max_values: int | None = None
    disabled: bool = False

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "type": 3,
            "custom_id": self.custom_id,
            "options": [o.to_dict() for o in self.options],
            "disabled": self.disabled,
        }
        if self.placeholder is not None:
            d["placeholder"] = self.placeholder
        if self.min_values is not None:
            d["min_values"] = self.min_values
        if self.max_values is not None:
            d["max_values"] = self.max_values
        return d

