from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any


@dataclass(slots=True)
class Embed:
    """Embed model for Discord messages (subset of Discord embed spec).

    This is intentionally lightweight but supports the most common parts:
    title/description/url/timestamp/color, fields, footer, author, images.
    """

    title: str | None = None
    description: str | None = None
    url: str | None = None
    timestamp: datetime | str | None = None
    color: int | None = None

    fields: list[dict[str, Any]] = field(default_factory=list)
    footer: dict[str, Any] | None = None
    author: dict[str, Any] | None = None
    thumbnail: dict[str, Any] | None = None
    image: dict[str, Any] | None = None

    def add_field(self, *, name: str, value: str, inline: bool = False) -> "Embed":
        self.fields.append({"name": name, "value": value, "inline": inline})
        return self

    def set_footer(self, *, text: str, icon_url: str | None = None) -> "Embed":
        data: dict[str, Any] = {"text": text}
        if icon_url is not None:
            data["icon_url"] = icon_url
        self.footer = data
        return self

    def set_author(self, *, name: str, url: str | None = None, icon_url: str | None = None) -> "Embed":
        data: dict[str, Any] = {"name": name}
        if url is not None:
            data["url"] = url
        if icon_url is not None:
            data["icon_url"] = icon_url
        self.author = data
        return self

    def set_thumbnail(self, url: str) -> "Embed":
        self.thumbnail = {"url": url}
        return self

    def set_image(self, url: str) -> "Embed":
        self.image = {"url": url}
        return self

    def set_timestamp_now(self) -> "Embed":
        self.timestamp = datetime.now(timezone.utc)
        return self

    def to_dict(self) -> dict[str, Any]:
        data: dict[str, Any] = {}
        if self.title is not None:
            data["title"] = self.title
        if self.description is not None:
            data["description"] = self.description
        if self.url is not None:
            data["url"] = self.url
        if self.timestamp is not None:
            if isinstance(self.timestamp, datetime):
                ts = self.timestamp
                if ts.tzinfo is None:
                    ts = ts.replace(tzinfo=timezone.utc)
                data["timestamp"] = ts.isoformat()
            else:
                data["timestamp"] = self.timestamp
        if self.color is not None:
            data["color"] = self.color
        if self.footer is not None:
            data["footer"] = dict(self.footer)
        if self.author is not None:
            data["author"] = dict(self.author)
        if self.thumbnail is not None:
            data["thumbnail"] = dict(self.thumbnail)
        if self.image is not None:
            data["image"] = dict(self.image)
        if self.fields:
            data["fields"] = list(self.fields)
        return data
