from __future__ import annotations

from typing import Iterable


def coerce_str_list(value: str | Iterable[str]) -> list[str]:
    if isinstance(value, str):
        return [value]
    return [str(v) for v in value]


def is_mention(token: str) -> bool:
    return token.startswith("<@") and token.endswith(">")


def strip_mention(token: str) -> str:
    # <@123>, <@!123>
    s = token.strip("<>@")
    if s.startswith("!"):
        s = s[1:]
    return s

