from __future__ import annotations

from dataclasses import dataclass
from typing import Awaitable, Callable


Callback = Callable[..., Awaitable[None]]


@dataclass(slots=True)
class Command:
    """Simple command object: name + async callback."""

    name: str
    callback: Callback
