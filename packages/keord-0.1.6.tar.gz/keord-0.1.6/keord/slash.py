from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable


Callback = Callable[..., Awaitable[None]]


@dataclass(slots=True)
class SlashCommand:
    name: str
    description: str
    callback: Callback
    options: list[dict[str, Any]] = field(default_factory=list)

    def to_application_command(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "name": self.name,
            "description": self.description,
            "type": 1,  # CHAT_INPUT
        }
        if self.options:
            payload["options"] = list(self.options)
        return payload

