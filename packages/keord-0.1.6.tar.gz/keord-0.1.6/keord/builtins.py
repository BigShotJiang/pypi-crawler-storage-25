from __future__ import annotations

from typing import Any

def setup_default_commands(bot: Any, *, prefix_commands: bool = True, slash_commands: bool = True) -> None:
    """Backward-compatible helper (no built-in commands).

    Раньше `keord` регистрировал встроенные команды (ping/avatar/help).
    По вашему запросу они удалены из поставки.

    Параметры сохранены, чтобы не ломать существующий код.
    """

    _ = (bot, prefix_commands, slash_commands)
    return None

