"""keord - minimalist educational framework for Discord bots."""

from .bot import Bot
from .builtins import setup_default_commands
from .command import Command
from .ctx import BaseContext, InteractionContext, MessageContext
from .module import Button, Colors, Embed, SelectMenu, SelectOption, action_row

__all__ = [
    "Bot",
    "setup_default_commands",
    "Command",
    "BaseContext",
    "MessageContext",
    "InteractionContext",
    "Embed",
    "Colors",
    "Button",
    "SelectMenu",
    "SelectOption",
    "action_row",
]
__version__ = "0.1.6"
