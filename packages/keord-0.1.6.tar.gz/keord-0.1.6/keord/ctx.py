from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping

from .module import Embed
from .utils import is_mention, strip_mention


DISCORD_API = "https://discord.com/api/v10"


@dataclass(slots=True)
class BaseContext:
    bot: Any
    args: list[str]
    raw: dict[str, Any]

    @property
    def channel_id(self) -> str | None:
        return self.raw.get("channel_id") or (self.raw.get("channel") or {}).get("id")

    @property
    def guild_id(self) -> str | None:
        return self.raw.get("guild_id")

    @property
    def author(self) -> Mapping[str, Any] | None:
        return self.raw.get("author") or self.raw.get("member", {}).get("user")

    @property
    def author_id(self) -> str | None:
        a = self.author
        if not a:
            return None
        return a.get("id")

    def parse_user_id(self, token: str | None) -> str | None:
        """Parse a user mention/id from command args.

        Supports: <@123>, <@!123>, "123".
        """
        if not token:
            return None
        t = token.strip()
        if is_mention(t):
            uid = strip_mention(t)
            return uid if uid.isdigit() else None
        return t if t.isdigit() else None

    async def fetch_user(self, user_id: str) -> dict[str, Any]:
        if self.bot.session is None or self.bot.token is None:
            raise RuntimeError("Bot session is not initialized")
        url = f"{DISCORD_API}/users/{user_id}"
        headers = {"Authorization": f"Bot {self.bot.token}"}
        async with self.bot.session.get(url, headers=headers) as response:
            if response.status >= 400:
                text = await response.text()
                raise RuntimeError(f"Failed to fetch user ({response.status}): {text}")
            return await response.json()

    async def send(
        self,
        content: str | None = None,
        *,
        embed: Embed | None = None,
        embeds: list[Embed] | None = None,
        components: list[dict[str, Any]] | None = None,
        tts: bool | None = None,
        allowed_mentions: dict[str, Any] | None = None,
    ) -> None:
        raise NotImplementedError


@dataclass(slots=True)
class MessageContext(BaseContext):
    message: dict[str, Any]

    async def send(
        self,
        content: str | None = None,
        *,
        embed: Embed | None = None,
        embeds: list[Embed] | None = None,
        components: list[dict[str, Any]] | None = None,
        tts: bool | None = None,
        allowed_mentions: dict[str, Any] | None = None,
    ) -> None:
        if self.bot.session is None or self.bot.token is None:
            raise RuntimeError("Bot session is not initialized")

        channel_id = self.message.get("channel_id")
        if not channel_id:
            raise RuntimeError("Message has no channel_id")

        url = f"{DISCORD_API}/channels/{channel_id}/messages"
        headers = {"Authorization": f"Bot {self.bot.token}"}

        payload: dict[str, Any] = {}
        if content is not None:
            payload["content"] = content
        if embed is not None:
            payload["embeds"] = [embed.to_dict()]
        if embeds is not None:
            payload["embeds"] = [e.to_dict() for e in embeds]
        if components is not None:
            payload["components"] = components
        if tts is not None:
            payload["tts"] = tts
        if allowed_mentions is not None:
            payload["allowed_mentions"] = allowed_mentions
        if not payload:
            raise RuntimeError("send() requires at least one field (content/embed/embeds/components)")

        async with self.bot.session.post(url, headers=headers, json=payload) as response:
            if response.status >= 400:
                text = await response.text()
                raise RuntimeError(f"Failed to send message ({response.status}): {text}")


@dataclass(slots=True)
class InteractionContext(BaseContext):
    interaction_id: str
    interaction_token: str
    data: dict[str, Any]
    _responded: bool = False
    _deferred: bool = False

    @property
    def command_name(self) -> str:
        return (self.data.get("name") or "").lower()

    @property
    def options(self) -> dict[str, Any]:
        """Slash-command options as a simple name->value mapping."""
        out: dict[str, Any] = {}
        for opt in self.data.get("options") or []:
            name = opt.get("name")
            if not name:
                continue
            if "value" in opt:
                out[str(name)] = opt["value"]
        return out

    async def defer(self, *, ephemeral: bool = False) -> None:
        await self._callback(5, {"flags": 64} if ephemeral else None)
        self._deferred = True

    async def respond(
        self,
        content: str | None = None,
        *,
        embed: Embed | None = None,
        embeds: list[Embed] | None = None,
        ephemeral: bool = False,
        components: list[dict[str, Any]] | None = None,
        allowed_mentions: dict[str, Any] | None = None,
    ) -> None:
        data: dict[str, Any] = {}
        if content is not None:
            data["content"] = content
        if embed is not None:
            data["embeds"] = [embed.to_dict()]
        if embeds is not None:
            data["embeds"] = [e.to_dict() for e in embeds]
        if components is not None:
            data["components"] = components
        if allowed_mentions is not None:
            data["allowed_mentions"] = allowed_mentions
        if ephemeral:
            data["flags"] = 64
        await self._callback(4, data if data else {})
        self._responded = True

    async def send(
        self,
        content: str | None = None,
        *,
        embed: Embed | None = None,
        embeds: list[Embed] | None = None,
        components: list[dict[str, Any]] | None = None,
        tts: bool | None = None,
        allowed_mentions: dict[str, Any] | None = None,
    ) -> None:
        # For slash commands, try to behave like "send" in other frameworks:
        # - first call: respond()
        # - subsequent calls (or after defer): followup()
        if not self._responded and not self._deferred:
            await self.respond(
                content,
                embed=embed,
                embeds=embeds,
                components=components,
                allowed_mentions=allowed_mentions,
            )
            return
        await self.followup(
            content,
            embed=embed,
            embeds=embeds,
            components=components,
            tts=tts,
            allowed_mentions=allowed_mentions,
        )

    async def edit_original(
        self,
        content: str | None = None,
        *,
        embed: Embed | None = None,
        embeds: list[Embed] | None = None,
        components: list[dict[str, Any]] | None = None,
        allowed_mentions: dict[str, Any] | None = None,
    ) -> None:
        if self.bot.session is None or self.bot.application_id is None:
            raise RuntimeError("Bot application_id/session is not initialized")
        url = f"{DISCORD_API}/webhooks/{self.bot.application_id}/{self.interaction_token}/messages/@original"
        payload: dict[str, Any] = {}
        if content is not None:
            payload["content"] = content
        if embed is not None:
            payload["embeds"] = [embed.to_dict()]
        if embeds is not None:
            payload["embeds"] = [e.to_dict() for e in embeds]
        if components is not None:
            payload["components"] = components
        if allowed_mentions is not None:
            payload["allowed_mentions"] = allowed_mentions
        async with self.bot.session.patch(url, json=payload) as response:
            if response.status >= 400:
                text = await response.text()
                raise RuntimeError(f"Failed to edit original response ({response.status}): {text}")

    async def followup(
        self,
        content: str | None = None,
        *,
        embed: Embed | None = None,
        embeds: list[Embed] | None = None,
        ephemeral: bool = False,
        components: list[dict[str, Any]] | None = None,
        tts: bool | None = None,
        allowed_mentions: dict[str, Any] | None = None,
    ) -> None:
        if self.bot.session is None or self.bot.application_id is None:
            raise RuntimeError("Bot application_id/session is not initialized")
        url = f"{DISCORD_API}/webhooks/{self.bot.application_id}/{self.interaction_token}"
        payload: dict[str, Any] = {}
        if content is not None:
            payload["content"] = content
        if embed is not None:
            payload["embeds"] = [embed.to_dict()]
        if embeds is not None:
            payload["embeds"] = [e.to_dict() for e in embeds]
        if components is not None:
            payload["components"] = components
        if tts is not None:
            payload["tts"] = tts
        if allowed_mentions is not None:
            payload["allowed_mentions"] = allowed_mentions
        if ephemeral:
            payload["flags"] = 64
        async with self.bot.session.post(url, json=payload) as response:
            if response.status >= 400:
                text = await response.text()
                raise RuntimeError(f"Failed to send followup ({response.status}): {text}")
        self._responded = True

    async def _callback(self, callback_type: int, data: dict[str, Any] | None) -> None:
        if self.bot.session is None:
            raise RuntimeError("Bot session is not initialized")
        url = f"{DISCORD_API}/interactions/{self.interaction_id}/{self.interaction_token}/callback"
        payload: dict[str, Any] = {"type": callback_type}
        if data is not None:
            payload["data"] = data
        async with self.bot.session.post(url, json=payload) as response:
            if response.status >= 400:
                text = await response.text()
                raise RuntimeError(f"Interaction callback failed ({response.status}): {text}")

