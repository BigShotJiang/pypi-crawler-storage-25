# Changelog

## [0.1.0] — 2026-04-22

First public release. Agentic MCP server for NetBox with ten read-only tools:
`netbox_search`, `netbox_get`, `netbox_get_all`, `netbox_aggregate_by_device`,
`netbox_device_profile`, `netbox_find_ip_references`, `netbox_trace_path`,
`netbox_get_available`, `netbox_inspect_type`, `netbox_query` (raw GraphQL).

### Docs

- Repo-level AI-assistant guide (git-ignored, personal-to-maintainer).
- `docs/DEVELOPMENT.md` consolidates design, implementation, testing, and extending in one developer guide.

### Repository hygiene

- Scrubbed realistic-looking hostnames and IPs from tests + one docstring (RFC 5737 addresses + generic `router-a` / `router-b` placeholders).
- `.pre-commit-config.yaml` (gitleaks + ruff + standard hooks) and `.gitleaks.toml` with an allowlist for synthetic `nbt_*` test tokens.
- `SECURITY.md` with a private vulnerability-reporting policy.
- `CONTRIBUTING.md` and `CODE_OF_CONDUCT.md` (Contributor Covenant v2.1 by reference).
- `.github/workflows/ci.yml` — ruff + pytest (3.11 / 3.12 / 3.13) + gitleaks on push + PR.
- `.github/workflows/publish.yml` — tag-triggered PyPI publish via trusted publishing (OIDC, no tokens).
- `.github/dependabot.yml` + `dependabot-auto-merge.yml` — weekly `uv` + `github-actions` updates, patch/minor auto-merged on green CI, majors flagged for manual review.
- Issue templates (bug / feature) and PR template.
- `pyproject.toml` `authors`, `urls`, `keywords`, and PyPI classifiers.
- README badges: CI, Python versions, license, pre-commit, Ruff.
- README install path leads with `uvx` and `uv tool install`; `git clone` moved to a **Development install** section.

### Code quality

- `__in` suffix-stripping filter translation centralized in `schema/filter_builder.filters_to_rest_params`; `QueryService` and `DeviceAggregationService` share it.
- Removed unreachable `last_exc` / `assert` dead code from `RestClient._request` and `GraphQLClient.query`.
- `server.main` closes the shared `httpx.Client` on shutdown; `build_services` returns `(registry, http)`.
- Deleted unreferenced GraphQL-first helpers: `schema/select_compiler.py` and the GraphQL portion of `schema/filter_builder.py` (`SUFFIX_MAP`, `build_filter_args`, support fns).
