---
name: Bug report
about: Something is broken or behaving incorrectly
title: ""
labels: ["bug"]
---

## What happened

<!-- Short description of the actual behavior. -->

## What you expected

<!-- Short description of the expected behavior. -->

## Reproduction

1.
2.
3.

### Minimal tool call / query (if applicable)

```python
# e.g. netbox_get("dcim.device", filters={...})
```

## Environment

- Server version (commit or tag):
- Python version:
- NetBox version:
- Transport (`stdio` / `http`):
- MCP client (Claude Code / LM Studio / other):

## Logs

<details>
<summary>Relevant output (set <code>LOG_LEVEL=DEBUG</code> if possible)</summary>

```
paste here
```

</details>

## Additional context
