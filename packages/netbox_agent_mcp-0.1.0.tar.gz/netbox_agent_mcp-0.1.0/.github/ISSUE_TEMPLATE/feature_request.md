---
name: Feature request
about: Suggest a new tool, filter, or response signal
title: ""
labels: ["enhancement"]
---

## Use case

<!-- What are you trying to accomplish from an agent's perspective?
     Concrete user question / scenario is most useful. -->

## Current workaround

<!-- How do you handle this today with the existing tools, if at all? -->

## Proposal

<!-- Short description of the tool / filter / signal you'd like added.
     If this is a new tool, sketch its signature and response shape. -->

## Alternatives considered

## Scope note

This server is **read-only by design** — proposals that require creating,
updating, or deleting NetBox objects are out of scope. For writes, use
NetBox's REST API or web UI directly.
