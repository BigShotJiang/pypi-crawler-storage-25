## Summary

<!-- What does this change and why? One or two sentences. -->

## Scope

- [ ] Code change (bug fix, feature, refactor)
- [ ] Docs only
- [ ] Tooling / CI
- [ ] Dependency bump

## Checklist

- [ ] `uv run pytest` passes locally
- [ ] `uv run ruff check .` and `uv run ruff format --check .` pass
- [ ] If I changed a response shape or added a signal, I updated the tool docstring AND `docs/SYSTEM_PROMPT.md`
- [ ] If I added or changed an object type, I updated `schema/object_types.py`, `schema/suggested_filters.py` (if applicable), and the contract `CRITICAL_TYPES` (if applicable)
- [ ] `CHANGELOG.md` under `Unreleased` describes the change (user-visible changes only)

## Testing notes

<!-- How did you verify this works? Unit tests, integration tests against a local
     NetBox, manual MCP client session? -->
