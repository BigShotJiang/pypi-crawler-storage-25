# Security Policy

## Supported versions

Only the latest `main` branch and the most recent tagged release are supported.

## Reporting a vulnerability

Please **do not** open a public GitHub issue for security problems.

Instead, report privately via GitHub's [Security Advisories](https://github.com/magicboxlab-ai/netbox-agent-mcp/security/advisories/new) — or email the maintainer listed in `pyproject.toml`.

When reporting, include:

- The version / commit hash.
- A minimal reproduction.
- Affected deployment surface (stdio client vs. HTTP transport).
- Anything sensitive the exploit could reveal or exfiltrate from a NetBox instance.

We aim to acknowledge within 3 business days and ship a fix within 30 days for confirmed issues.

## Scope

This project is a read-only MCP server for NetBox. Relevant security concerns include:

- **Credential handling** — NetBox tokens are accepted via env var or CLI. They are stored as `pydantic.SecretStr` and masked in log summaries. Report any path that leaks them.
- **Input validation** — user-supplied filters are translated into NetBox REST/GraphQL queries. Report any injection that would let an agent perform writes, access unauthorized endpoints, or cause unsafe server-side behavior.
- **Resource exhaustion** — `netbox_get_all` is hard-capped at 100,000 records; aggregation scans are capped at 10,000 rows by default. Report any path that bypasses these caps.
- **Dependency chain** — httpx, FastMCP, pydantic. Report vulnerabilities transiting these.

## Out of scope

- Vulnerabilities in NetBox itself — report those to the NetBox project.
- Denial of service caused by a malicious NetBox admin (we trust the NetBox instance we're configured against).
- Anything involving write operations: this server exposes no write tools.
