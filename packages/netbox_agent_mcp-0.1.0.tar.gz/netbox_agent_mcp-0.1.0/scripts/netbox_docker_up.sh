#!/usr/bin/env bash
set -euo pipefail

# Brings up netbox-docker for integration tests.
# Usage: scripts/netbox_docker_up.sh [path-to-netbox-docker-clone]

NETBOX_DOCKER_DIR="${1:-../netbox-docker}"

if [ ! -d "$NETBOX_DOCKER_DIR" ]; then
  echo "netbox-docker not found at $NETBOX_DOCKER_DIR" >&2
  echo "Clone https://github.com/netbox-community/netbox-docker.git first." >&2
  exit 1
fi

cd "$NETBOX_DOCKER_DIR"
docker compose up -d
echo "Waiting for NetBox to become healthy..."
for i in {1..60}; do
  if curl -sf http://localhost:8000/api/status/ > /dev/null 2>&1; then
    echo "NetBox ready at http://localhost:8000/"
    exit 0
  fi
  sleep 5
done
echo "NetBox did not become ready in time." >&2
exit 1
