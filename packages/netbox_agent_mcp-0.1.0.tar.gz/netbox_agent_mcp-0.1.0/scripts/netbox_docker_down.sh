#!/usr/bin/env bash
set -euo pipefail

NETBOX_DOCKER_DIR="${1:-../netbox-docker}"
cd "$NETBOX_DOCKER_DIR"
docker compose down -v
