"""Detect NetBox schema drift that would break this server's assumptions.

These tests assert that:
1. Every object type in our registry is queryable via GraphQL.
2. Common filter fields exist per type.
3. Critical REST endpoints are reachable.

Run when upgrading NetBox to catch breaks before users do.

Integration conftest lives at tests/integration/conftest.py; the
contract tests share its live_registry fixture. This module needs a local
conftest that re-exports the fixture, or tests import it via request.
"""

import pytest

from netbox_agent_mcp.schema.object_types import OBJECT_TYPES

pytestmark = pytest.mark.contract


CRITICAL_TYPES = [
    "dcim.device",
    "dcim.site",
    "dcim.interface",
    "dcim.rack",
    "ipam.prefix",
    "ipam.ipaddress",
    "ipam.vlan",
    "circuits.circuit",
    "virtualization.virtualmachine",
]


def test_every_registered_type_has_graphql_type(live_registry):
    failures = []
    for obj_type in OBJECT_TYPES:
        try:
            live_registry.introspection.inspect_type(obj_type)
        except Exception as exc:
            failures.append(f"{obj_type}: {exc}")
    assert not failures, "GraphQL introspection failed for: " + "; ".join(failures)


@pytest.mark.parametrize("object_type", CRITICAL_TYPES)
def test_critical_type_has_id_and_name(live_registry, object_type):
    result = live_registry.introspection.inspect_type(object_type)
    field_names = {f["name"] for f in result["fields"]}
    assert "id" in field_names
    if object_type != "ipam.ipaddress":
        assert "name" in field_names


def test_status_endpoint_reachable(live_registry):
    status = live_registry.introspection._rest.get("status")
    assert "netbox-version" in status
