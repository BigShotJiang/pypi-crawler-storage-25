import pytest

pytestmark = pytest.mark.integration


def test_netbox_get_sites_returns_results(live_registry):
    result = live_registry.query.get(
        object_type="dcim.site",
        filters={},
        select=["name", "slug"],
        limit=5,
    )
    assert "results" in result
    assert result["total_count"] >= 0


def test_netbox_get_device_with_nested_site(live_registry):
    result = live_registry.query.get(
        object_type="dcim.device",
        filters={},
        select=["name", "site.name"],
        limit=1,
    )
    if result["results"]:
        device = result["results"][0]
        assert "name" in device
        assert isinstance(device.get("site"), dict)


def test_netbox_get_unknown_type_raises(live_registry):
    from netbox_agent_mcp.exceptions import UnknownObjectTypeError

    with pytest.raises(UnknownObjectTypeError):
        live_registry.query.get(object_type="dcim.wizard", filters={})


def test_netbox_get_all_small_set(live_registry):
    result = live_registry.query.get_all(
        object_type="dcim.region",
        filters={},
        max_records=100,
    )
    assert result["has_more"] is False
    assert len(result["results"]) == result["total_count"]
