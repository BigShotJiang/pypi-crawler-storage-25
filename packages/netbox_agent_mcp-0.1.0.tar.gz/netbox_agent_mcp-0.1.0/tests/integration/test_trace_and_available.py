import pytest

pytestmark = pytest.mark.integration


def test_available_ips_on_first_prefix(live_registry):
    prefixes = live_registry.query.get(
        object_type="ipam.prefix",
        filters={},
        select=["prefix"],
        limit=1,
    )
    if not prefixes["results"]:
        pytest.skip("no prefixes in NetBox instance")
    pid = prefixes["results"][0]["id"]
    result = live_registry.availability.get_available(
        "prefix.available-ips", parent_id=pid, count=1
    )
    assert isinstance(result, list)


def test_trace_on_first_interface(live_registry):
    ifaces = live_registry.query.get(
        object_type="dcim.interface",
        filters={"cabled": True},
        select=["name"],
        limit=1,
    )
    if not ifaces["results"]:
        pytest.skip("no cabled interfaces in NetBox instance")
    iid = ifaces["results"][0]["id"]
    result = live_registry.trace.trace("interfaces", iid)
    assert isinstance(result, list)
