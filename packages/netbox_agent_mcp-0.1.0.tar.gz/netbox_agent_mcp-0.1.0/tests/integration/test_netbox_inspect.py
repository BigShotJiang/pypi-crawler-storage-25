import pytest

pytestmark = pytest.mark.integration


def test_inspect_device_type(live_registry):
    result = live_registry.introspection.inspect_type("dcim.device")
    assert result["name"] == "DeviceType"
    field_names = [f["name"] for f in result["fields"]]
    for expected in ["id", "name", "site"]:
        assert expected in field_names, f"Expected field '{expected}' missing"


def test_inspect_site_type(live_registry):
    result = live_registry.introspection.inspect_type("dcim.site")
    assert result["name"] == "SiteType"


def test_inspect_caches_across_calls(live_registry):
    first = live_registry.introspection.inspect_type("dcim.device")
    second = live_registry.introspection.inspect_type("dcim.device")
    assert first is second
