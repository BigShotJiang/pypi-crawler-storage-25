import pytest

pytestmark = pytest.mark.integration


def test_search_returns_matches_and_suggested_filters(live_registry):
    result = live_registry.search.search(
        query="a",
        object_types=["dcim.site"],
        limit=3,
    )
    assert "matches" in result
    assert "suggested_filters" in result
    if result["matches"]["dcim.site"]:
        assert "devices_at_these_sites" in result["suggested_filters"]


def test_search_default_types(live_registry):
    result = live_registry.search.search(query="x", limit=1)
    for t in ["dcim.device", "dcim.site", "ipam.ipaddress"]:
        assert t in result["matches"]
