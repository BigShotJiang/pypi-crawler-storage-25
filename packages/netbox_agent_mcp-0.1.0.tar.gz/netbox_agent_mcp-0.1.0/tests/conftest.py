"""Shared fixtures."""

import os

import pytest

from netbox_agent_mcp.clients.base import build_http_client
from netbox_agent_mcp.clients.graphql import GraphQLClient
from netbox_agent_mcp.clients.rest import RestClient
from netbox_agent_mcp.services.availability_service import AvailabilityService
from netbox_agent_mcp.services.device_aggregation_service import DeviceAggregationService
from netbox_agent_mcp.services.device_profile_service import DeviceProfileService
from netbox_agent_mcp.services.introspection_service import IntrospectionService
from netbox_agent_mcp.services.ip_reference_service import IPReferenceService
from netbox_agent_mcp.services.query_service import QueryService
from netbox_agent_mcp.services.registry import ServiceRegistry, set_services
from netbox_agent_mcp.services.search_service import SearchService
from netbox_agent_mcp.services.trace_service import TraceService


@pytest.fixture
def netbox_url() -> str:
    return "https://netbox.test.local/"


@pytest.fixture
def netbox_token() -> str:
    return "nbt_testtoken1234567890"


@pytest.fixture(scope="session")
def live_settings():
    url = os.environ.get("NETBOX_URL")
    token = os.environ.get("NETBOX_TOKEN")
    if not url or not token:
        pytest.skip("NETBOX_URL and NETBOX_TOKEN required for integration tests")
    return {
        "url": url,
        "token": token,
        "verify_ssl": os.environ.get("NETBOX_VERIFY_SSL", "true") == "true",
    }


@pytest.fixture(scope="session")
def http_client(live_settings):
    client = build_http_client(**live_settings)
    yield client
    client.close()


@pytest.fixture(scope="session")
def live_registry(http_client):
    gql = GraphQLClient(http_client)
    rest = RestClient(http_client)
    reg = ServiceRegistry(
        query=QueryService(rest),
        search=SearchService(rest),
        introspection=IntrospectionService(gql, rest),
        trace=TraceService(rest),
        availability=AvailabilityService(rest),
        ip_reference=IPReferenceService(rest),
        device_profile=DeviceProfileService(rest),
        device_aggregation=DeviceAggregationService(rest),
        graphql=gql,
    )
    set_services(reg)
    yield reg
    set_services(None)
