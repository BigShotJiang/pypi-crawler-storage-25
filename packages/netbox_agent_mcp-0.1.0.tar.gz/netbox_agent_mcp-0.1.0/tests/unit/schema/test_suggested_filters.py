from netbox_agent_mcp.schema.suggested_filters import compute_suggested_filters


def test_empty_matches_returns_empty_dict():
    assert compute_suggested_filters({}) == {}


def test_matches_with_no_items_returns_empty():
    assert compute_suggested_filters({"dcim.site": []}) == {}


def test_site_matches_produce_device_suggestion():
    matches = {"dcim.site": [{"id": 8}, {"id": 12}]}
    result = compute_suggested_filters(matches)
    assert "devices_at_these_sites" in result
    assert result["devices_at_these_sites"] == {
        "object_type": "dcim.device",
        "filters": {"site_id__in": [8, 12]},
    }


def test_site_matches_produce_multiple_suggestions():
    matches = {"dcim.site": [{"id": 8}]}
    result = compute_suggested_filters(matches)
    assert "devices_at_these_sites" in result
    assert "prefixes_at_these_sites" in result
    assert "racks_at_these_sites" in result


def test_device_matches_produce_interface_suggestion():
    matches = {"dcim.device": [{"id": 100}, {"id": 101}]}
    result = compute_suggested_filters(matches)
    assert "interfaces_on_these_devices" in result
    assert result["interfaces_on_these_devices"] == {
        "object_type": "dcim.interface",
        "filters": {"device_id__in": [100, 101]},
    }


def test_unknown_source_type_produces_no_suggestion():
    matches = {"dcim.wizard": [{"id": 1}]}
    assert compute_suggested_filters(matches) == {}


def test_mixed_match_types_produce_combined_suggestions():
    matches = {
        "dcim.site": [{"id": 8}],
        "dcim.device": [{"id": 100}],
    }
    result = compute_suggested_filters(matches)
    assert "devices_at_these_sites" in result
    assert "interfaces_on_these_devices" in result


def test_match_items_missing_id_are_skipped():
    matches = {"dcim.site": [{"name": "no-id"}, {"id": 8}]}
    result = compute_suggested_filters(matches)
    assert result["devices_at_these_sites"]["filters"]["site_id__in"] == [8]
