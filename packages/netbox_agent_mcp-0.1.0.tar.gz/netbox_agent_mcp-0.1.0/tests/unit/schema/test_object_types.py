import pytest

from netbox_agent_mcp.exceptions import UnknownObjectTypeError
from netbox_agent_mcp.schema.object_types import (
    OBJECT_TYPES,
    resolve_graphql_query_field,
    resolve_rest_endpoint,
    validate_object_type,
)


def test_core_types_present():
    for t in [
        "dcim.device",
        "dcim.site",
        "ipam.prefix",
        "ipam.ipaddress",
        "circuits.circuit",
        "virtualization.virtualmachine",
    ]:
        assert t in OBJECT_TYPES


def test_validate_object_type_accepts_known():
    validate_object_type("dcim.device")


def test_validate_object_type_rejects_unknown():
    with pytest.raises(UnknownObjectTypeError) as exc_info:
        validate_object_type("dcim.wizard")
    assert "dcim.wizard" in str(exc_info.value)


def test_resolve_rest_endpoint():
    assert resolve_rest_endpoint("dcim.device") == "dcim/devices"
    assert resolve_rest_endpoint("ipam.ipaddress") == "ipam/ip-addresses"


def test_resolve_graphql_query_field():
    assert resolve_graphql_query_field("dcim.device") == "device_list"
    assert resolve_graphql_query_field("ipam.ipaddress") == "ip_address_list"
