from netbox_agent_mcp.schema.filter_builder import filters_to_rest_params


def test_strips_in_suffix_for_list_values():
    out = filters_to_rest_params({"site_id__in": [8, 12]})
    assert out == {"site_id": [8, 12]}


def test_preserves_other_suffixes():
    out = filters_to_rest_params(
        {"name__ic": "switch", "vid__gte": 100, "status__n": "decommissioning"}
    )
    assert out == {
        "name__ic": "switch",
        "vid__gte": 100,
        "status__n": "decommissioning",
    }


def test_preserves_exact_match_keys():
    out = filters_to_rest_params({"site_id": 8, "status": "active"})
    assert out == {"site_id": 8, "status": "active"}


def test_does_not_strip_in_when_value_is_not_a_list():
    # Scalar value with __in is a caller mistake; passed through unchanged
    # so NetBox's filterset rejects it loudly instead of being silently lost.
    out = filters_to_rest_params({"site_id__in": 8})
    assert out == {"site_id__in": 8}


def test_empty_filters():
    assert filters_to_rest_params({}) == {}
