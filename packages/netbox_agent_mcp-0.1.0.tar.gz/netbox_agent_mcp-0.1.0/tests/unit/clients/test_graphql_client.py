import httpx
import pytest

from netbox_agent_mcp.clients.graphql import GraphQLClient
from netbox_agent_mcp.exceptions import NetBoxAPIError, SchemaIntrospectionError


def _mock_client(handler) -> httpx.Client:
    return httpx.Client(
        base_url="https://netbox.test",
        transport=httpx.MockTransport(handler),
    )


def test_query_posts_to_graphql_endpoint():
    captured = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["path"] = request.url.path
        captured["method"] = request.method
        captured["body"] = request.read().decode()
        return httpx.Response(200, json={"data": {"ok": True}})

    gql = GraphQLClient(_mock_client(handler))
    result = gql.query("query { device_list { id } }")
    assert captured["path"] == "/graphql/"
    assert captured["method"] == "POST"
    assert "device_list" in captured["body"]
    assert result == {"ok": True}


def test_query_passes_variables():
    captured = {}

    def handler(request: httpx.Request) -> httpx.Response:
        import json as _json

        captured["body"] = _json.loads(request.read())
        return httpx.Response(200, json={"data": {"x": 1}})

    gql = GraphQLClient(_mock_client(handler))
    gql.query("query($id: Int!) { device(id: $id) { name } }", variables={"id": 42})
    assert captured["body"]["variables"] == {"id": 42}


def test_graphql_errors_raise_schema_error():
    def handler(_request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            json={
                "data": None,
                "errors": [{"message": "Cannot query field 'wiggle'"}],
            },
        )

    gql = GraphQLClient(_mock_client(handler))
    with pytest.raises(SchemaIntrospectionError, match="wiggle"):
        gql.query("query { device_list { wiggle } }")


def test_http_5xx_raises_netboxapierror():
    def handler(_request: httpx.Request) -> httpx.Response:
        return httpx.Response(500, text="server broken")

    gql = GraphQLClient(_mock_client(handler), max_retries=0)
    with pytest.raises(NetBoxAPIError):
        gql.query("query { __typename }")


def test_partial_data_with_errors_still_raises():
    """NetBox can return partial data with errors; we treat any error as fatal."""

    def handler(_request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            json={
                "data": {"device_list": [{"id": 1}]},
                "errors": [{"message": "field access denied"}],
            },
        )

    gql = GraphQLClient(_mock_client(handler))
    with pytest.raises(SchemaIntrospectionError):
        gql.query("query { device_list { id } }")
