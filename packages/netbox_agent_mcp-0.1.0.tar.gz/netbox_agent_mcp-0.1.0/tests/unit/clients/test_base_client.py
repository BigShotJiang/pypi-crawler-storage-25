import httpx

from netbox_agent_mcp.clients.base import build_http_client


def test_bearer_scheme_for_nbt_token():
    client = build_http_client(
        url="https://netbox.test/",
        token="nbt_abc",
        verify_ssl=True,
    )
    assert client.headers["Authorization"] == "Bearer nbt_abc"


def test_token_scheme_for_non_prefixed_token():
    client = build_http_client(
        url="https://netbox.test/",
        token="abcdef1234",
        verify_ssl=True,
    )
    assert client.headers["Authorization"] == "Token abcdef1234"


def test_content_and_accept_headers():
    client = build_http_client(url="https://x/", token="t", verify_ssl=True)
    assert client.headers["Content-Type"] == "application/json"
    assert client.headers["Accept"] == "application/json"


def test_returns_httpx_client():
    client = build_http_client(url="https://x/", token="t", verify_ssl=True)
    assert isinstance(client, httpx.Client)
