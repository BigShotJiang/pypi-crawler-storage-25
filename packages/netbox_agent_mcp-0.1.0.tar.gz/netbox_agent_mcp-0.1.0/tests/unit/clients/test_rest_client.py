import httpx
import pytest

from netbox_agent_mcp.clients.rest import RestClient
from netbox_agent_mcp.exceptions import NetBoxAPIError


def _mock_client(handler) -> httpx.Client:
    transport = httpx.MockTransport(handler)
    return httpx.Client(
        base_url="https://netbox.test",
        transport=transport,
        headers={"Authorization": "Bearer nbt_x"},
    )


def test_get_returns_parsed_json():
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/api/dcim/sites/"
        return httpx.Response(200, json={"count": 1, "results": [{"id": 1}]})

    rest = RestClient(_mock_client(handler))
    result = rest.get("dcim/sites")
    assert result == {"count": 1, "results": [{"id": 1}]}


def test_get_with_id():
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/api/dcim/sites/42/"
        return httpx.Response(200, json={"id": 42})

    rest = RestClient(_mock_client(handler))
    assert rest.get("dcim/sites", id=42) == {"id": 42}


def test_get_with_params_passes_query_string():
    captured = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["q"] = request.url.params
        return httpx.Response(200, json={"results": []})

    rest = RestClient(_mock_client(handler))
    rest.get("dcim/sites", params={"q": "London", "limit": 5})
    assert captured["q"]["q"] == "London"
    assert captured["q"]["limit"] == "5"


def test_4xx_raises_netboxapierror():
    def handler(_request: httpx.Request) -> httpx.Response:
        return httpx.Response(404, text="Not found")

    rest = RestClient(_mock_client(handler))
    with pytest.raises(NetBoxAPIError) as exc_info:
        rest.get("dcim/sites", id=9999)
    assert exc_info.value.status == 404


def test_5xx_retries_then_raises():
    call_count = {"n": 0}

    def handler(_request: httpx.Request) -> httpx.Response:
        call_count["n"] += 1
        return httpx.Response(500, text="boom")

    rest = RestClient(_mock_client(handler), max_retries=2, backoff_base=0.0)
    with pytest.raises(NetBoxAPIError):
        rest.get("dcim/sites")
    assert call_count["n"] == 3  # initial + 2 retries


def test_5xx_then_success_returns_value():
    calls = {"n": 0}

    def handler(_request: httpx.Request) -> httpx.Response:
        calls["n"] += 1
        if calls["n"] == 1:
            return httpx.Response(502)
        return httpx.Response(200, json={"ok": True})

    rest = RestClient(_mock_client(handler), max_retries=3, backoff_base=0.0)
    assert rest.get("dcim/sites") == {"ok": True}
