import logging

import pytest
from pydantic import ValidationError

from netbox_agent_mcp.config import Settings, configure_logging


def test_settings_reads_from_env(monkeypatch):
    monkeypatch.setenv("NETBOX_URL", "https://netbox.example.com/")
    monkeypatch.setenv("NETBOX_TOKEN", "nbt_abc123")
    s = Settings()
    assert str(s.netbox_url) == "https://netbox.example.com/"
    assert s.netbox_token.get_secret_value() == "nbt_abc123"
    assert s.verify_ssl is True
    assert s.log_level == "INFO"
    assert s.transport == "stdio"


def test_settings_requires_url_and_token():
    with pytest.raises(ValidationError):
        Settings(netbox_url=None, netbox_token=None, _env_file=None)


def test_settings_cli_overlay():
    s = Settings(
        netbox_url="https://override.example.com/",
        netbox_token="nbt_override",
        log_level="DEBUG",
        _env_file=None,
    )
    assert str(s.netbox_url) == "https://override.example.com/"
    assert s.log_level == "DEBUG"


def test_settings_rejects_invalid_log_level():
    with pytest.raises(ValidationError):
        Settings(
            netbox_url="https://x/",
            netbox_token="t",
            log_level="TRACE",
            _env_file=None,
        )


def test_effective_config_summary_scrubs_token():
    s = Settings(
        netbox_url="https://x/",
        netbox_token="nbt_secret",
        _env_file=None,
    )
    summary = s.get_effective_config_summary()
    assert "nbt_secret" not in summary
    assert "***" in summary or "redacted" in summary.lower()


def test_configure_logging_sets_level():
    configure_logging("DEBUG")
    assert logging.getLogger("netbox_agent_mcp").level == logging.DEBUG
