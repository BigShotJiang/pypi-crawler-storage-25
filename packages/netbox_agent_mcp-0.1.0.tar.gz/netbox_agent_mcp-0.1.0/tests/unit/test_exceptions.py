from netbox_agent_mcp.exceptions import (
    AgentMCPError,
    CapExceededError,
    NetBoxAPIError,
    SchemaIntrospectionError,
    UnknownFieldError,
    UnknownObjectTypeError,
)


def test_all_exceptions_inherit_from_agent_mcp_error():
    for cls in (
        CapExceededError,
        NetBoxAPIError,
        SchemaIntrospectionError,
        UnknownFieldError,
        UnknownObjectTypeError,
    ):
        assert issubclass(cls, AgentMCPError)


def test_agent_mcp_error_is_valueerror_for_fastmcp_compat():
    assert issubclass(AgentMCPError, ValueError)


def test_cap_exceeded_carries_context():
    err = CapExceededError(total_count=45230, current_max=10000)
    assert err.total_count == 45230
    assert err.current_max == 10000
    assert "45230" in str(err)
    assert "10000" in str(err)


def test_unknown_field_carries_path_and_type():
    err = UnknownFieldError(object_type="dcim.device", path="site.continent")
    assert err.object_type == "dcim.device"
    assert err.path == "site.continent"
    assert "site.continent" in str(err)


def test_unknown_object_type_lists_valid_types():
    err = UnknownObjectTypeError(given="dcim.wizards", valid=["dcim.device", "dcim.site"])
    assert "dcim.wizards" in str(err)
    assert "dcim.device" in str(err)


def test_netbox_api_error_carries_status_and_url():
    err = NetBoxAPIError(status=500, url="https://netbox.test/api/foo/", body="boom")
    assert err.status == 500
    assert "https://netbox.test/api/foo/" in str(err)
    assert "500" in str(err)
