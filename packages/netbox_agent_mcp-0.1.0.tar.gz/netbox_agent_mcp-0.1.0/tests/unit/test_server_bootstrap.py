from unittest.mock import MagicMock

from netbox_agent_mcp.server import build_services


def test_build_services_wires_all_components():
    settings = MagicMock()
    settings.netbox_url.unicode_string.return_value = "https://netbox.test/"
    settings.netbox_token.get_secret_value.return_value = "nbt_x"
    settings.verify_ssl = True

    reg, http = build_services(settings)
    try:
        assert reg.query is not None
        assert reg.search is not None
        assert reg.introspection is not None
        assert reg.trace is not None
        assert reg.availability is not None
        assert reg.graphql is not None
    finally:
        http.close()
