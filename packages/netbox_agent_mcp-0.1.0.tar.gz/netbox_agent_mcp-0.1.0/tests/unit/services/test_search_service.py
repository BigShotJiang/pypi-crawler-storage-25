from unittest.mock import MagicMock

from netbox_agent_mcp.services.search_service import DEFAULT_LIMIT, SearchService


def test_search_default_limit_is_25():
    """Default limit=5 was too low (truncated common real-world queries)."""
    assert DEFAULT_LIMIT == 25


def test_search_uses_default_limit_when_unspecified():
    rest = MagicMock()
    rest.get.return_value = {"count": 0, "results": []}
    SearchService(rest).search(query="x", object_types=["dcim.site"])
    assert rest.get.call_args.kwargs["params"]["limit"] == DEFAULT_LIMIT


def test_search_calls_rest_per_object_type():
    rest = MagicMock()
    rest.get.return_value = {"count": 1, "results": [{"id": 1, "name": "london-dc1"}]}

    svc = SearchService(rest)
    svc.search(query="London", object_types=["dcim.site"], limit=5)

    assert rest.get.call_count == 1
    call = rest.get.call_args
    assert call.args[0] == "dcim/sites"
    assert call.kwargs["params"]["q"] == "London"
    assert call.kwargs["params"]["limit"] == 5


def test_search_aggregates_matches_by_type():
    rest = MagicMock()
    rest.get.side_effect = [
        {"count": 1, "results": [{"id": 8, "name": "london-dc1"}]},
        {"count": 0, "results": []},
    ]

    svc = SearchService(rest)
    result = svc.search(query="London", object_types=["dcim.site", "dcim.device"])

    assert result["matches"]["dcim.site"] == [{"id": 8, "name": "london-dc1"}]
    assert result["matches"]["dcim.device"] == []


def test_search_populates_suggested_filters():
    rest = MagicMock()
    rest.get.return_value = {"count": 1, "results": [{"id": 8}]}

    svc = SearchService(rest)
    result = svc.search(query="x", object_types=["dcim.site"])

    assert "devices_at_these_sites" in result["suggested_filters"]
    assert result["suggested_filters"]["devices_at_these_sites"]["filters"] == {"site_id__in": [8]}


def test_search_default_object_types():
    rest = MagicMock()
    rest.get.return_value = {"count": 0, "results": []}

    svc = SearchService(rest)
    result = svc.search(query="x")
    assert "dcim.device" in result["matches"]
    assert "dcim.site" in result["matches"]
    assert "ipam.ipaddress" in result["matches"]


def test_search_match_counts_detect_truncation():
    """When NetBox reports more matches than returned, flag `truncated: True`."""
    rest = MagicMock()
    rest.get.return_value = {
        "count": 6,
        "results": [{"id": i} for i in range(5)],  # limit=5, only 5 of 6 returned
    }
    svc = SearchService(rest)
    result = svc.search(query="London", object_types=["dcim.site"], limit=5)

    counts = result["match_counts"]["dcim.site"]
    assert counts["total"] == 6
    assert counts["returned"] == 5
    assert counts["truncated"] is True


def test_search_match_counts_no_truncation_when_exhausted():
    rest = MagicMock()
    rest.get.return_value = {"count": 3, "results": [{"id": 1}, {"id": 2}, {"id": 3}]}
    svc = SearchService(rest)
    result = svc.search(query="x", object_types=["dcim.site"], limit=25)

    counts = result["match_counts"]["dcim.site"]
    assert counts["total"] == 3
    assert counts["returned"] == 3
    assert counts["truncated"] is False


def test_search_resilient_to_per_type_failures():
    rest = MagicMock()

    def get(endpoint, **kwargs):
        if endpoint == "dcim/devices":
            raise RuntimeError("simulated outage")
        return {"count": 1, "results": [{"id": 1}]}

    rest.get.side_effect = get

    svc = SearchService(rest)
    result = svc.search(query="x", object_types=["dcim.site", "dcim.device"])

    assert result["matches"]["dcim.site"] == [{"id": 1}]
    assert result["matches"]["dcim.device"] == []
    # Failed type is surfaced in match_counts so the agent can see it
    assert result["match_counts"]["dcim.device"]["error"] == "simulated outage"
    assert result["match_counts"]["dcim.site"]["total"] == 1
