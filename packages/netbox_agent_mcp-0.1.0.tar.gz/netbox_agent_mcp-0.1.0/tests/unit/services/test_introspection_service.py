from unittest.mock import MagicMock

from netbox_agent_mcp.services.introspection_service import IntrospectionService


def test_inspect_type_calls_graphql_introspection():
    gql = MagicMock()
    gql.query.return_value = {
        "__type": {"name": "DeviceType", "fields": [{"name": "id", "type": {"name": "ID"}}]}
    }
    rest = MagicMock()
    rest.get.return_value = {"netbox-version": "4.5.8"}

    svc = IntrospectionService(gql, rest)
    result = svc.inspect_type("dcim.device")

    assert result["name"] == "DeviceType"
    assert gql.query.called
    query_arg = gql.query.call_args[0][0]
    assert "__type" in query_arg


def test_inspect_type_caches_by_version_and_type():
    gql = MagicMock()
    gql.query.return_value = {"__type": {"name": "DeviceType", "fields": []}}
    rest = MagicMock()
    rest.get.return_value = {"netbox-version": "4.5.8"}

    svc = IntrospectionService(gql, rest)
    svc.inspect_type("dcim.device")
    svc.inspect_type("dcim.device")

    assert gql.query.call_count == 1  # cached


def test_inspect_type_separate_cache_per_type():
    gql = MagicMock()
    gql.query.side_effect = [
        {"__type": {"name": "DeviceType", "fields": []}},
        {"__type": {"name": "SiteType", "fields": []}},
    ]
    rest = MagicMock()
    rest.get.return_value = {"netbox-version": "4.5.8"}

    svc = IntrospectionService(gql, rest)
    svc.inspect_type("dcim.device")
    svc.inspect_type("dcim.site")

    assert gql.query.call_count == 2


def test_netbox_version_fetched_once():
    gql = MagicMock()
    gql.query.return_value = {"__type": {"name": "X", "fields": []}}
    rest = MagicMock()
    rest.get.return_value = {"netbox-version": "4.5.8"}

    svc = IntrospectionService(gql, rest)
    svc.inspect_type("dcim.device")
    svc.inspect_type("dcim.site")

    assert rest.get.call_count == 1
