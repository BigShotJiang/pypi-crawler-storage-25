from unittest.mock import MagicMock

import pytest

from netbox_agent_mcp.services.trace_service import VALID_ENDPOINT_TYPES, TraceService


def test_trace_calls_correct_endpoint():
    rest = MagicMock()
    rest.get.return_value = [{"cable": 1}]

    svc = TraceService(rest)
    svc.trace("interfaces", 42)

    rest.get.assert_called_once()
    call = rest.get.call_args
    assert call.args[0] == "dcim/interfaces/42/trace"


def test_trace_returns_segments_in_wrapper_when_non_empty():
    rest = MagicMock()
    rest.get.return_value = [{"device": "r1"}, {"device": "r2"}]

    svc = TraceService(rest)
    result = svc.trace("interfaces", 42)

    assert result["segments"] == [{"device": "r1"}, {"device": "r2"}]
    assert result["segment_count"] == 2
    assert result["next_steps"] == []  # no guidance needed when cabled


def test_trace_empty_injects_next_step_about_cabled():
    """Empty trace = interface uncabled; direct the agent to check
    `cable` / `netbox_device_profile` instead of reporting no data."""
    rest = MagicMock()
    rest.get.return_value = []
    svc = TraceService(rest)
    result = svc.trace("interfaces", 34)
    assert result["segments"] == []
    assert result["segment_count"] == 0
    assert len(result["next_steps"]) == 1
    step = result["next_steps"][0]
    assert "uncabled" in step.lower() or "cabled" in step.lower()
    assert "netbox_device_profile" in step


def test_trace_rejects_unknown_endpoint_type():
    rest = MagicMock()
    svc = TraceService(rest)

    with pytest.raises(ValueError, match="endpoint_type"):
        svc.trace("wiggle-port", 1)


def test_valid_endpoint_types_covered():
    for et in [
        "interfaces",
        "console-ports",
        "console-server-ports",
        "power-ports",
        "power-outlets",
        "power-feeds",
    ]:
        assert et in VALID_ENDPOINT_TYPES
