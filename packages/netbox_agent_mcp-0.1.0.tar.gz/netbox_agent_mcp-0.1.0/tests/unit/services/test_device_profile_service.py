from unittest.mock import MagicMock

import pytest

from netbox_agent_mcp.services.device_profile_service import (
    DEFAULT_INCLUDE,
    DeviceProfileService,
)


def _rest(responses_by_endpoint):
    rest = MagicMock()

    def get(endpoint, params=None):
        return responses_by_endpoint.get(endpoint, {"count": 0, "results": []})

    rest.get.side_effect = get
    return rest


def test_profile_returns_device_and_default_sections():
    rest = _rest(
        {
            "dcim/devices/42": {"id": 42, "name": "r1", "site": {"name": "NYC"}},
            "dcim/interfaces": {
                "count": 2,
                "results": [{"id": 1, "name": "eth0"}, {"id": 2, "name": "eth1"}],
            },
            "ipam/ip-addresses": {"count": 1, "results": [{"id": 9, "address": "10.0.0.1/24"}]},
            "vpn/tunnel-terminations": {"count": 0, "results": []},
            "dcim/inventory-items": {"count": 0, "results": []},
        }
    )
    svc = DeviceProfileService(rest)
    result = svc.profile(device_id=42)

    assert result["device"]["name"] == "r1"
    assert set(result["sections"].keys()) == set(DEFAULT_INCLUDE)
    assert result["counts"]["interfaces"] == 2
    assert result["counts"]["ip_addresses"] == 1


def test_profile_respects_include_subset():
    rest = _rest(
        {
            "dcim/devices/1": {"id": 1, "name": "x"},
            "dcim/inventory-items": {"count": 5, "results": []},
        }
    )
    svc = DeviceProfileService(rest)
    result = svc.profile(device_id=1, include=["inventory_items"])
    assert set(result["sections"].keys()) == {"inventory_items"}
    assert result["counts"]["inventory_items"] == 5


def test_profile_rejects_invalid_include():
    rest = MagicMock()
    svc = DeviceProfileService(rest)
    with pytest.raises(ValueError, match="Unknown include"):
        svc.profile(device_id=1, include=["interfaces", "something_wrong"])


def test_profile_section_detects_truncation():
    rest = _rest(
        {
            "dcim/devices/1": {"id": 1},
            "dcim/interfaces": {
                "count": 173,
                "results": [{"id": i, "name": f"eth{i}"} for i in range(100)],
            },
            "ipam/ip-addresses": {"count": 0, "results": []},
            "vpn/tunnel-terminations": {"count": 0, "results": []},
            "dcim/inventory-items": {"count": 0, "results": []},
        }
    )
    svc = DeviceProfileService(rest)
    result = svc.profile(device_id=1, max_per_category=100)
    iface = result["sections"]["interfaces"]
    assert iface["total"] == 173
    assert iface["returned"] == 100
    assert iface["truncated"] is True


def test_profile_tunnel_mismatch_hint():
    """The real-world case: 172 tunnel.* interfaces, 42 structured tunnel terminations."""
    rest = _rest(
        {
            "dcim/devices/5": {"id": 5, "name": "router-b"},
            "dcim/interfaces": {
                # Brief section returns 100 sample interfaces, 100 named tunnel.*
                "count": 173,
                "results": [
                    {"id": i, "name": f"tunnel.foo{i}", "type": {"value": "virtual"}}
                    for i in range(100)
                ],
            },
            "ipam/ip-addresses": {"count": 0, "results": []},
            "vpn/tunnel-terminations": {
                "count": 42,
                "results": [{"id": i} for i in range(42)],
            },
            "dcim/inventory-items": {"count": 0, "results": []},
        }
    )
    svc = DeviceProfileService(rest)
    result = svc.profile(device_id=5)

    # There should be a hint flagging the orphaned-tunnel-interface gap
    joined = " ".join(result["hints"])
    assert "orphaned" in joined.lower() or "tunnel" in joined.lower()
    # And the gap should be roughly 131 (173 - 42)
    assert "42" in joined


def test_profile_management_field_populated_in_summary_mode():
    """REGRESSION: agent called profile with include=['ip_addresses'] and
    max_per_category=0 and saw no mgmt info. The always-on management probe
    now populates regardless of include/max_per_category."""
    captured = []

    def get(endpoint, params=None):
        captured.append((endpoint, dict(params or {})))
        if endpoint == "dcim/devices/99":
            return {"id": 99, "name": "router-d"}
        if endpoint == "dcim/interfaces":
            # The mgmt-probe fetch uses fields=id,name,type; return mgmt iface
            if params and params.get("fields") == "id,name,type":
                return {
                    "count": 1,
                    "results": [{"id": 34, "name": "management", "type": {"value": "virtual"}}],
                }
            return {"count": 0, "results": []}
        if endpoint == "ipam/ip-addresses":
            # The mgmt-probe IP lookup filters by interface_id
            if params and "interface_id" in params:
                return {
                    "count": 1,
                    "results": [
                        {
                            "id": 501,
                            "address": "10.1.2.11/32",
                            "description": "Management IP for router-d",
                            "assigned_object": {"id": 34, "name": "management"},
                        }
                    ],
                }
            return {"count": 0, "results": []}
        return {"count": 0, "results": []}

    rest = MagicMock()
    rest.get.side_effect = get

    # Agent's actual failing call: include=["ip_addresses"], max_per_category=0
    result = DeviceProfileService(rest).profile(
        device_id=99,
        include=["ip_addresses"],
        max_per_category=0,
    )

    # management top-level field populated
    assert len(result["management"]) == 1
    mgmt = result["management"][0]
    assert mgmt["interface"]["name"] == "management"
    assert mgmt["interface"]["id"] == 34
    assert len(mgmt["ips"]) == 1
    assert mgmt["ips"][0]["address"] == "10.1.2.11/32"

    # And the hint is emitted too
    mgmt_hints = [h for h in result["hints"] if "Management interface" in h]
    assert len(mgmt_hints) == 1
    assert "10.1.2.11/32" in mgmt_hints[0]


def test_profile_mgmt_probe_empty_when_no_mgmt_interfaces():
    rest = _rest(
        {
            "dcim/devices/1": {"id": 1},
            "dcim/interfaces": {
                "count": 2,
                "results": [{"id": 1, "name": "Ethernet1/1"}, {"id": 2, "name": "Ethernet1/2"}],
            },
            "ipam/ip-addresses": {"count": 0, "results": []},
            "vpn/tunnel-terminations": {"count": 0, "results": []},
            "dcim/inventory-items": {"count": 0, "results": []},
        }
    )
    result = DeviceProfileService(rest).profile(device_id=1)
    assert result["management"] == []


def test_profile_mgmt_interface_hint_with_structural_ip():
    """When device has an interface named 'management' and an IP structurally
    assigned to it, the profile surfaces a direct management-IP hint."""
    rest = _rest(
        {
            "dcim/devices/99": {"id": 99, "name": "router-d"},
            "dcim/interfaces": {
                "count": 1,
                "results": [{"id": 34, "name": "management", "type": {"value": "virtual"}}],
            },
            "ipam/ip-addresses": {
                "count": 1,
                "results": [
                    {
                        "id": 501,
                        "address": "10.1.2.11/32",
                        "description": "Management IP for router-d",
                        "assigned_object": {"id": 34, "name": "management"},
                    }
                ],
            },
            "vpn/tunnel-terminations": {"count": 0, "results": []},
            "dcim/inventory-items": {"count": 0, "results": []},
        }
    )
    result = DeviceProfileService(rest).profile(device_id=99)

    mgmt_hints = [h for h in result["hints"] if "Management interface" in h]
    assert len(mgmt_hints) == 1
    hint = mgmt_hints[0]
    assert "management" in hint
    assert "id=34" in hint
    assert "10.1.2.11/32" in hint
    assert "Management IP for router-d" in hint


def test_profile_mgmt_interface_hint_without_ip():
    """Management-named interface exists but no IP is assigned — say so."""
    rest = _rest(
        {
            "dcim/devices/1": {"id": 1},
            "dcim/interfaces": {
                "count": 1,
                "results": [{"id": 10, "name": "mgmt0"}],
            },
            "ipam/ip-addresses": {"count": 0, "results": []},
            "vpn/tunnel-terminations": {"count": 0, "results": []},
            "dcim/inventory-items": {"count": 0, "results": []},
        }
    )
    result = DeviceProfileService(rest).profile(device_id=1)
    mgmt_hints = [h for h in result["hints"] if "Management interface" in h]
    assert len(mgmt_hints) == 1
    assert "no IP assigned" in mgmt_hints[0]


def test_profile_mgmt_pattern_catches_common_variants():
    """mgmt, management, oob, out-of-band, fxp0 all match."""
    rest = _rest(
        {
            "dcim/devices/1": {"id": 1},
            "dcim/interfaces": {
                "count": 5,
                "results": [
                    {"id": 1, "name": "mgmt"},
                    {"id": 2, "name": "management"},
                    {"id": 3, "name": "oob"},
                    {"id": 4, "name": "out-of-band"},
                    {"id": 5, "name": "fxp0"},
                ],
            },
            "ipam/ip-addresses": {"count": 0, "results": []},
            "vpn/tunnel-terminations": {"count": 0, "results": []},
            "dcim/inventory-items": {"count": 0, "results": []},
        }
    )
    result = DeviceProfileService(rest).profile(device_id=1)
    mgmt_hints = [h for h in result["hints"] if "Management interface" in h]
    assert len(mgmt_hints) == 5


def test_profile_no_mgmt_hint_when_none_match():
    """Devices with only data interfaces: no mgmt hint at all."""
    rest = _rest(
        {
            "dcim/devices/1": {"id": 1},
            "dcim/interfaces": {
                "count": 2,
                "results": [
                    {"id": 1, "name": "Ethernet1/1"},
                    {"id": 2, "name": "Ethernet1/2"},
                ],
            },
            "ipam/ip-addresses": {"count": 0, "results": []},
            "vpn/tunnel-terminations": {"count": 0, "results": []},
            "dcim/inventory-items": {"count": 0, "results": []},
        }
    )
    result = DeviceProfileService(rest).profile(device_id=1)
    mgmt_hints = [h for h in result["hints"] if "Management interface" in h]
    assert mgmt_hints == []


def test_profile_ip_addresses_fetch_uses_assigned_object_fields():
    """The ip_addresses section is now fetched with assigned_object projected
    so the mgmt-interface hint can cross-reference."""
    captured = []

    def get(endpoint, params=None):
        captured.append((endpoint, params))
        if endpoint == "dcim/devices/1":
            return {"id": 1}
        if endpoint == "dcim/interfaces":
            return {"count": 0, "results": []}
        return {"count": 0, "results": []}

    rest = MagicMock()
    rest.get.side_effect = get
    DeviceProfileService(rest).profile(device_id=1)

    ip_call = next(c for c in captured if c[0] == "ipam/ip-addresses")
    assert ip_call[1]["device_id"] == 1
    assert "assigned_object" in ip_call[1]["fields"]


def test_profile_resilient_to_per_section_failures():
    rest = MagicMock()

    def get(endpoint, params=None):
        if endpoint == "dcim/interfaces":
            raise RuntimeError("simulated outage")
        if endpoint == "dcim/devices/9":
            return {"id": 9, "name": "partial"}
        return {"count": 0, "results": []}

    rest.get.side_effect = get
    svc = DeviceProfileService(rest)
    result = svc.profile(device_id=9)

    # Device record still present; interfaces section reports the error
    assert result["device"]["name"] == "partial"
    assert result["sections"]["interfaces"]["error"] == "simulated outage"


def test_profile_tunnel_filter_passes_interface_ids():
    """The two-step: first fetch interfaces, then tunnel-terminations filtered
    by termination_type + termination_id__in=<interface_ids>."""
    captured = []

    def get(endpoint, params=None):
        captured.append((endpoint, params))
        if endpoint == "dcim/devices/7":
            return {"id": 7}
        if endpoint == "dcim/interfaces":
            # params["fields"]="id,name,type,cable" → the full-mode call
            if params and params.get("fields") == "id,name,type,cable":
                return {"count": 3, "results": [{"id": 11}, {"id": 12}, {"id": 13}]}
            return {"count": 3, "results": [{"id": 11, "name": "a"}]}
        if endpoint == "vpn/tunnel-terminations":
            return {"count": 2, "results": []}
        return {"count": 0, "results": []}

    rest = MagicMock()
    rest.get.side_effect = get

    DeviceProfileService(rest).profile(device_id=7)

    tunnel_call = next(c for c in captured if c[0] == "vpn/tunnel-terminations")
    assert tunnel_call[1]["termination_type"] == "dcim.interface"
    assert tunnel_call[1]["termination_id"] == [11, 12, 13]
