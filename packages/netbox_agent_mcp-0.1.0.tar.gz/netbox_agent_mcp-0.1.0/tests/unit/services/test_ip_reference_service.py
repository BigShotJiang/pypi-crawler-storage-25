from unittest.mock import MagicMock

from netbox_agent_mcp.services.ip_reference_service import IPReferenceService


def _make_rest(responses_by_endpoint: dict[str, dict]) -> MagicMock:
    rest = MagicMock()

    def get(endpoint: str, params=None):
        return responses_by_endpoint.get(endpoint, {"count": 0, "results": []})

    rest.get.side_effect = get
    return rest


def test_finds_structured_ipam_assignment():
    rest = _make_rest(
        {
            "ipam/ip-addresses": {
                "count": 1,
                "results": [
                    {
                        "id": 42,
                        "address": "10.0.0.1/24",
                        "display": "10.0.0.1/24",
                        "assigned_object_type": "dcim.interface",
                        "assigned_object": {"id": 9, "name": "eth0", "device": {"name": "r1"}},
                    }
                ],
            },
        }
    )
    svc = IPReferenceService(rest)
    result = svc.find_references("10.0.0.1/24")

    assert result["query"] == "10.0.0.1"
    assert result["ipam_record"]["id"] == 42
    assert result["ipam_record"]["assigned_object_type"] == "dcim.interface"
    assert result["summary"]["ipam_assigned_to_object"] is True
    assert "follow" in result["summary"]["hint"]


def test_surfaces_text_references_when_no_structured_assignment():
    """The 'Palo Alto tunnel import' case: IP exists in IPAM with no assignment,
    but tunnel descriptions reference it."""
    rest = _make_rest(
        {
            "ipam/ip-addresses": {
                "count": 1,
                "results": [
                    {
                        "id": 543,
                        "address": "198.51.100.1/32",
                        "display": "198.51.100.1/32",
                        "assigned_object_type": None,
                        "assigned_object": None,
                    }
                ],
            },
            "vpn/tunnels": {
                "count": 1,
                "results": [
                    {
                        "id": 77,
                        "display": "tunnel-demo :: router-a :: 198.51.100.1",
                        "name": "tunnel-demo :: router-a :: 198.51.100.1",
                        "description": "Imported from Palo Alto firewall router-a | Peer IP: 198.51.100.1",
                    }
                ],
            },
        }
    )
    svc = IPReferenceService(rest)
    result = svc.find_references("198.51.100.1")

    assert result["ipam_record"] is not None
    assert result["ipam_record"]["assigned_object_type"] is None
    assert result["summary"]["ipam_assigned_to_object"] is False
    assert result["summary"]["text_reference_count"] == 1
    assert len(result["text_references"]["vpn.tunnel"]) == 1
    tunnel = result["text_references"]["vpn.tunnel"][0]
    assert "router-a" in tunnel["name"]


def test_no_references_anywhere():
    rest = _make_rest({})  # all endpoints return empty
    svc = IPReferenceService(rest)
    result = svc.find_references("203.0.113.99")

    assert result["ipam_record"] is None
    assert result["summary"]["ipam_record_exists"] is False
    assert result["summary"]["text_reference_count"] == 0
    assert "No references" in result["summary"]["hint"]


def test_falls_back_to_bare_host_when_masked_lookup_misses():
    """If user passes '10.0.0.1/32' but NetBox stores it as '10.0.0.1/24',
    retry with the bare host."""
    calls = {"n": 0}

    def get(endpoint, params=None):
        if endpoint == "ipam/ip-addresses":
            calls["n"] += 1
            if calls["n"] == 1:
                # First call with /32 returns nothing
                return {"count": 0, "results": []}
            # Second call with bare host finds it
            return {
                "count": 1,
                "results": [
                    {
                        "id": 99,
                        "address": "10.0.0.1/24",
                        "assigned_object_type": None,
                        "assigned_object": None,
                    }
                ],
            }
        return {"count": 0, "results": []}

    rest = MagicMock()
    rest.get.side_effect = get

    svc = IPReferenceService(rest)
    result = svc.find_references("10.0.0.1/32")
    assert result["ipam_record"] is not None
    assert result["ipam_record"]["id"] == 99
    assert calls["n"] == 2


def test_text_searches_use_description_ic():
    captured = []

    def get(endpoint, params=None):
        captured.append((endpoint, params))
        return {"count": 0, "results": []}

    rest = MagicMock()
    rest.get.side_effect = get

    IPReferenceService(rest).find_references("198.51.100.1")
    # One IPAM lookup + three text searches
    text_searches = [c for c in captured if c[0] != "ipam/ip-addresses"]
    assert len(text_searches) == 3
    for endpoint, params in text_searches:
        assert params["description__ic"] == "198.51.100.1"
        assert endpoint in {"vpn/tunnels", "dcim/interfaces", "ipam/prefixes"}


def test_resilient_to_per_endpoint_failures():
    """If one endpoint errors, the rest should still return."""

    def get(endpoint, params=None):
        if endpoint == "vpn/tunnels":
            raise RuntimeError("simulated outage")
        if endpoint == "ipam/ip-addresses":
            return {
                "count": 1,
                "results": [{"id": 1, "address": "203.0.113.99/32", "assigned_object": None}],
            }
        return {"count": 0, "results": []}

    rest = MagicMock()
    rest.get.side_effect = get

    result = IPReferenceService(rest).find_references("203.0.113.99")
    assert result["ipam_record"]["id"] == 1
    assert result["text_references"]["vpn.tunnel"] == []  # failed gracefully
