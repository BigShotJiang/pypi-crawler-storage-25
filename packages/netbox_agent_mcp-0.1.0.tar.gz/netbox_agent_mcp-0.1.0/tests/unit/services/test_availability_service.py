from unittest.mock import MagicMock

import pytest

from netbox_agent_mcp.services.availability_service import AvailabilityService


def test_available_ips_in_prefix():
    rest = MagicMock()
    rest.get.return_value = [{"address": "10.0.0.1/24"}]

    svc = AvailabilityService(rest)
    result = svc.get_available("prefix.available-ips", parent_id=42, count=1)

    rest.get.assert_called_once()
    assert rest.get.call_args.args[0] == "ipam/prefixes/42/available-ips"
    assert rest.get.call_args.kwargs["params"] == {"limit": 1}
    assert result == [{"address": "10.0.0.1/24"}]


def test_available_prefixes():
    rest = MagicMock()
    rest.get.return_value = [{"prefix": "10.0.0.0/26"}]

    svc = AvailabilityService(rest)
    svc.get_available("prefix.available-prefixes", parent_id=5, count=2)
    assert rest.get.call_args.args[0] == "ipam/prefixes/5/available-prefixes"


def test_available_ip_range_ips():
    rest = MagicMock()
    rest.get.return_value = []
    svc = AvailabilityService(rest)
    svc.get_available("ip-range.available-ips", parent_id=9, count=3)
    assert rest.get.call_args.args[0] == "ipam/ip-ranges/9/available-ips"


def test_available_vlans():
    rest = MagicMock()
    rest.get.return_value = []
    svc = AvailabilityService(rest)
    svc.get_available("vlan-group.available-vlans", parent_id=1)
    assert rest.get.call_args.args[0] == "ipam/vlan-groups/1/available-vlans"


def test_available_asns():
    rest = MagicMock()
    rest.get.return_value = []
    svc = AvailabilityService(rest)
    svc.get_available("asn-range.available-asns", parent_id=11)
    assert rest.get.call_args.args[0] == "ipam/asn-ranges/11/available-asns"


def test_unknown_resource_type_rejected():
    rest = MagicMock()
    svc = AvailabilityService(rest)
    with pytest.raises(ValueError, match="resource_type"):
        svc.get_available("nonsense.available-wiggles", parent_id=1)
