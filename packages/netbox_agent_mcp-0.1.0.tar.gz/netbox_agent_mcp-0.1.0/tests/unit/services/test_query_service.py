from unittest.mock import MagicMock

import pytest

from netbox_agent_mcp.exceptions import CapExceededError, UnknownObjectTypeError
from netbox_agent_mcp.services.query_service import QueryService


def _svc(rest_response):
    rest = MagicMock()
    rest.get.return_value = rest_response
    return QueryService(rest), rest


def test_get_calls_correct_rest_endpoint():
    svc, rest = _svc(
        {"count": 1, "next": None, "previous": None, "results": [{"id": 1, "name": "r1"}]}
    )

    result = svc.get(
        object_type="dcim.device",
        filters={"site_id": 8},
        select=["name"],
        limit=5,
        offset=0,
    )

    rest.get.assert_called_once()
    endpoint = rest.get.call_args.args[0]
    params = rest.get.call_args.kwargs["params"]
    assert endpoint == "dcim/devices"
    assert params["site_id"] == 8
    assert params["limit"] == 5
    assert params["offset"] == 0
    assert params["fields"] == "id,name"  # id auto-added, sorted
    assert result["results"] == [{"id": 1, "name": "r1"}]
    assert result["total_count"] == 1


def test_get_translates_in_suffix_to_repeated_params():
    """REGRESSION: NetBox silently ignores ?site_id__in=8&site_id__in=12.

    For scalar ID filters it requires repeated bare params: ?site_id=8&site_id=12.
    We translate the __in suffix at the wire boundary and leave the external
    contract (agents use `site_id__in` in filters) unchanged.
    """
    svc, rest = _svc({"count": 0, "next": None, "previous": None, "results": []})
    svc.get(
        object_type="dcim.device",
        filters={"site_id__in": [8, 12, 15]},
        select=None,
    )
    params = rest.get.call_args.kwargs["params"]
    # Suffix stripped; httpx will serialize the list as repeated bare params.
    assert "site_id__in" not in params
    assert params["site_id"] == [8, 12, 15]


def test_get_preserves_other_suffixes():
    """__ic, __gte, __empty etc. are real URL-level NetBox filter suffixes."""
    svc, rest = _svc({"count": 0, "next": None, "previous": None, "results": []})
    svc.get(
        object_type="dcim.device",
        filters={"name__ic": "switch", "status__n": "decommissioning"},
        select=None,
    )
    params = rest.get.call_args.kwargs["params"]
    assert params["name__ic"] == "switch"
    assert params["status__n"] == "decommissioning"


def test_get_passes_ordering_string():
    """'Top N sites by device count' pattern — use ordering='-device_count'."""
    svc, rest = _svc({"count": 0, "next": None, "previous": None, "results": []})
    svc.get(
        object_type="dcim.site",
        filters={},
        select=["name", "device_count"],
        limit=10,
        ordering="-device_count",
    )
    params = rest.get.call_args.kwargs["params"]
    assert params["ordering"] == "-device_count"


def test_get_passes_ordering_list():
    """Multiple ordering fields are comma-joined for NetBox's ?ordering=."""
    svc, rest = _svc({"count": 0, "next": None, "previous": None, "results": []})
    svc.get(
        object_type="dcim.site",
        filters={},
        ordering=["-device_count", "name"],
    )
    params = rest.get.call_args.kwargs["params"]
    assert params["ordering"] == "-device_count,name"


def test_get_no_ordering_param_when_unset():
    svc, rest = _svc({"count": 0, "next": None, "previous": None, "results": []})
    svc.get(object_type="dcim.site", filters={})
    params = rest.get.call_args.kwargs["params"]
    assert "ordering" not in params


def test_get_all_preserves_ordering_across_pages():
    """get_all paginates; each page must carry the same ordering so the
    assembled list is fully sorted."""
    rest = MagicMock()
    page_size = 500
    rest.get.side_effect = [
        {
            "count": 800,
            "next": "url",
            "previous": None,
            "results": [{"id": i} for i in range(page_size)],
        },
        {
            "count": 800,
            "next": None,
            "previous": None,
            "results": [{"id": i} for i in range(page_size, 800)],
        },
    ]
    svc = QueryService(rest)
    svc.get_all(
        object_type="dcim.site",
        filters={},
        ordering="-device_count",
    )
    for call in rest.get.call_args_list:
        assert call.kwargs["params"]["ordering"] == "-device_count"


def test_get_translates_role_and_site_filters_together():
    """The London-firewalls regression: role_id scalar + site_id__in list."""
    svc, rest = _svc({"count": 0, "next": None, "previous": None, "results": []})
    svc.get(
        object_type="dcim.device",
        filters={"role_id": 3, "site_id__in": [8, 124, 115, 17, 129, 61]},
        select=None,
    )
    params = rest.get.call_args.kwargs["params"]
    assert params["role_id"] == 3
    assert params["site_id"] == [8, 124, 115, 17, 129, 61]
    assert "site_id__in" not in params


def test_get_no_fields_param_when_select_is_none():
    svc, rest = _svc({"count": 0, "next": None, "previous": None, "results": []})
    svc.get(object_type="dcim.device", filters={})
    params = rest.get.call_args.kwargs["params"]
    assert "fields" not in params  # omit = NetBox returns full shape


def test_get_surfaces_silently_dropped_fields():
    """REGRESSION: ipam.ipaddress has no `device` field (use `assigned_object`).
    NetBox REST silently drops unknown ?fields= keys; we must surface that so
    agents see 'your request was rejected' instead of 'no data exists'.
    """
    svc, _ = _svc(
        {
            "count": 1,
            "next": None,
            "previous": None,
            # NetBox returns only valid fields; `device` was dropped server-side
            "results": [{"id": 543, "address": "198.51.100.1/32"}],
        }
    )
    result = svc.get(
        object_type="ipam.ipaddress",
        filters={"address": "198.51.100.1/32"},
        select=["address", "device.name", "device.site.name"],
    )
    assert result["fields_dropped"] == ["device"]
    assert "ipam.ipaddress" in result["fields_dropped_hint"]
    assert "netbox_inspect_type" in result["fields_dropped_hint"]


def test_get_no_fields_dropped_when_all_returned():
    svc, _ = _svc(
        {
            "count": 1,
            "next": None,
            "previous": None,
            "results": [{"id": 1, "name": "site-a", "slug": "site-a"}],
        }
    )
    result = svc.get(
        object_type="dcim.site",
        filters={},
        select=["name", "slug"],
    )
    assert "fields_dropped" not in result


def test_get_devices_emits_enrichment_next_step():
    """Listing devices? Server enumerates ALL device IDs in the next_step so
    the agent has a checklist, not a pattern it can half-apply."""
    svc, _ = _svc(
        {
            "count": 2,
            "next": None,
            "previous": None,
            "results": [{"id": 5, "name": "a"}, {"id": 8, "name": "b"}],
        }
    )
    result = svc.get(object_type="dcim.device", filters={})
    assert "next_steps" in result
    step = result["next_steps"][0]
    # Every device id must be named — explicit checklist
    assert "device_id=5" in step
    assert "device_id=8" in step
    # Anti-hedging instruction
    assert "unverified" in step.lower() or "truncate" in step.lower()


def test_get_devices_next_step_truncates_long_lists_but_is_explicit():
    """When there are >10 devices, show first 10 explicitly + count of the rest."""
    results = [{"id": i, "name": f"d{i}"} for i in range(1, 16)]  # 15 devices
    svc, _ = _svc({"count": 15, "next": None, "previous": None, "results": results})
    result = svc.get(object_type="dcim.device", filters={})
    step = result["next_steps"][0]
    # First 10 ids enumerated
    for i in range(1, 11):
        assert f"device_id={i}" in step
    # Remaining are acknowledged as still-required
    assert "5 more" in step
    assert "one call per device" in step


def test_get_ipam_ipaddress_with_null_assigned_object_emits_next_step():
    svc, _ = _svc(
        {
            "count": 2,
            "next": None,
            "previous": None,
            "results": [
                {"id": 543, "address": "198.51.100.1/32", "assigned_object": None},
                {"id": 544, "address": "198.51.100.2/32", "assigned_object": {"id": 99}},
            ],
        }
    )
    result = svc.get(object_type="ipam.ipaddress", filters={})
    assert "next_steps" in result
    step = result["next_steps"][0]
    assert "1 of 2" in step
    assert "netbox_find_ip_references" in step
    assert "198.51.100.1/32" in step


def test_get_site_list_emits_enrichment_next_step():
    svc, _ = _svc(
        {
            "count": 1,
            "next": None,
            "previous": None,
            "results": [{"id": 8, "name": "ELH"}],
        }
    )
    result = svc.get(object_type="dcim.site", filters={})
    assert any("region" in s and "device_count" in s for s in result.get("next_steps", []))


def test_get_interfaces_with_uncabled_flags_trace_gotcha():
    svc, _ = _svc(
        {
            "count": 2,
            "next": None,
            "previous": None,
            "results": [
                {"id": 1, "name": "mgmt", "cable": None},
                {"id": 2, "name": "eth1", "cable": {"id": 44}},
            ],
        }
    )
    result = svc.get(object_type="dcim.interface", filters={})
    step = result.get("next_steps", [])
    assert any("uncabled" in s and "trace_path" in s for s in step)


def test_get_emits_select_collapse_note_for_dotted_paths():
    """REGRESSION: the 'top 10 devices by tunnel count' bug — agent asked for
    select=['termination.device.id', 'termination.device.name'] and got back
    full `termination` objects because REST doesn't support dotted field
    selection. The server now warns the agent about this so they know the
    select didn't narrow fields the way they expected."""
    svc, _ = _svc(
        {
            "count": 1,
            "next": None,
            "previous": None,
            "results": [{"id": 1, "termination": {"device": {"id": 5}}}],
        }
    )
    result = svc.get(
        object_type="vpn.tunneltermination",
        filters={},
        select=["termination.device.id", "termination.device.name"],
    )
    assert "select_collapse_note" in result
    note = result["select_collapse_note"]
    assert "termination.device.id" in note
    assert "termination" in note
    assert "netbox_aggregate_by_device" in note


def test_get_no_collapse_note_for_flat_paths():
    svc, _ = _svc(
        {
            "count": 0,
            "next": None,
            "previous": None,
            "results": [],
        }
    )
    result = svc.get(
        object_type="dcim.site",
        filters={},
        select=["name", "slug"],
    )
    assert "select_collapse_note" not in result


def test_get_injects_type_guidance_when_type_has_one():
    """REGRESSION: vpn.tunnel should steer agents to vpn.tunneltermination."""
    svc, _ = _svc({"count": 0, "next": None, "previous": None, "results": []})
    result = svc.get(object_type="vpn.tunnel", filters={})
    assert "type_guidance" in result
    assert "vpn.tunneltermination" in result["type_guidance"]


def test_get_no_guidance_for_simple_types():
    """Most types don't need hand-curated guidance; response stays clean."""
    svc, _ = _svc({"count": 0, "next": None, "previous": None, "results": []})
    result = svc.get(object_type="dcim.region", filters={})
    assert "type_guidance" not in result


def test_new_junction_types_are_registered():
    """Agents need these to resolve device ↔ tunnel/cable/circuit/fhrp structurally."""
    from netbox_agent_mcp.schema.object_types import (
        OBJECT_TYPES,
        resolve_rest_endpoint,
    )

    for t in [
        "vpn.tunneltermination",
        "vpn.l2vpntermination",
        "dcim.cabletermination",
        "circuits.circuittermination",
        "ipam.fhrpgroup",
        "ipam.fhrpgroupassignment",
        "dcim.inventoryitem",
        "dcim.modulebay",
        "dcim.devicebay",
    ]:
        assert t in OBJECT_TYPES
    assert resolve_rest_endpoint("vpn.tunneltermination") == "vpn/tunnel-terminations"


def test_tunnel_search_suggests_terminations():
    """After searching vpn.tunnel, agent should be offered the termination path."""
    svc, _ = _svc(
        {
            "count": 2,
            "next": None,
            "previous": None,
            "results": [{"id": 77}, {"id": 78}],
        }
    )
    result = svc.get(object_type="vpn.tunnel", filters={})
    assert "terminations_for_these_tunnels" in result["suggested_next"]
    assert result["suggested_next"]["terminations_for_these_tunnels"] == {
        "object_type": "vpn.tunneltermination",
        "filters": {"tunnel_id__in": [77, 78]},
    }


def test_get_no_fields_dropped_when_empty_results():
    """Can't detect drops without a sample row; stay silent."""
    svc, _ = _svc({"count": 0, "next": None, "previous": None, "results": []})
    result = svc.get(
        object_type="dcim.site",
        filters={"id": 99999},
        select=["name", "totally_made_up"],
    )
    assert "fields_dropped" not in result


def test_get_flattens_dotted_paths_to_top_level_fields():
    svc, rest = _svc({"count": 0, "next": None, "previous": None, "results": []})
    svc.get(
        object_type="dcim.device",
        filters={},
        select=["name", "site.name", "site.region.name", "role.name"],
    )
    params = rest.get.call_args.kwargs["params"]
    # Dotted paths collapse to top-level names; id auto-added; sorted
    assert params["fields"] == "id,name,role,site"


def test_get_unknown_object_type_raises():
    rest = MagicMock()
    svc = QueryService(rest)
    with pytest.raises(UnknownObjectTypeError):
        svc.get(object_type="dcim.wizard", filters={})


def test_get_includes_suggested_next_for_devices():
    svc, _ = _svc(
        {
            "count": 2,
            "next": None,
            "previous": None,
            "results": [{"id": 1}, {"id": 2}],
        }
    )
    result = svc.get(object_type="dcim.device", filters={})
    assert "interfaces_on_these_devices" in result["suggested_next"]
    assert result["suggested_next"]["interfaces_on_these_devices"]["filters"] == {
        "device_id__in": [1, 2]
    }


def test_get_has_more_from_rest_next_field():
    svc, _ = _svc(
        {
            "count": 50,
            "next": "https://netbox.example/api/dcim/devices/?limit=10&offset=10",
            "previous": None,
            "results": [{"id": i} for i in range(10)],
        }
    )
    result = svc.get(object_type="dcim.device", filters={}, limit=10, offset=0)
    assert result["has_more"] is True


def test_get_no_more_when_next_is_null():
    svc, _ = _svc(
        {
            "count": 1,
            "next": None,
            "previous": None,
            "results": [{"id": 1}],
        }
    )
    result = svc.get(object_type="dcim.device", filters={}, limit=10, offset=0)
    assert result["has_more"] is False


def test_get_all_fails_loud_when_total_exceeds_cap():
    rest = MagicMock()
    rest.get.return_value = {"count": 45230, "next": None, "previous": None, "results": []}
    svc = QueryService(rest)
    with pytest.raises(CapExceededError) as exc_info:
        svc.get_all(object_type="dcim.device", filters={}, max_records=10000)
    assert exc_info.value.total_count == 45230
    assert exc_info.value.current_max == 10000


def test_get_all_max_records_hard_ceiling():
    """max_records cannot exceed the absolute ceiling."""
    rest = MagicMock()
    rest.get.return_value = {"count": 0, "next": None, "previous": None, "results": []}
    svc = QueryService(rest)
    with pytest.raises(ValueError, match="100000"):
        svc.get_all(object_type="dcim.device", filters={}, max_records=200000)


def test_get_all_loops_until_exhausted():
    rest = MagicMock()
    page_size = 500
    rest.get.side_effect = [
        {
            "count": 1200,
            "next": "url",
            "previous": None,
            "results": [{"id": i} for i in range(page_size)],
        },
        {
            "count": 1200,
            "next": "url",
            "previous": None,
            "results": [{"id": i} for i in range(page_size, 2 * page_size)],
        },
        {
            "count": 1200,
            "next": None,
            "previous": None,
            "results": [{"id": i} for i in range(2 * page_size, 1200)],
        },
    ]
    svc = QueryService(rest)
    result = svc.get_all(object_type="dcim.device", filters={})
    assert len(result["results"]) == 1200
    assert result["total_count"] == 1200
    assert rest.get.call_count == 3


def test_get_all_empty_result():
    rest = MagicMock()
    rest.get.return_value = {"count": 0, "next": None, "previous": None, "results": []}
    svc = QueryService(rest)
    result = svc.get_all(object_type="dcim.device", filters={})
    assert result["results"] == []
    assert result["total_count"] == 0
