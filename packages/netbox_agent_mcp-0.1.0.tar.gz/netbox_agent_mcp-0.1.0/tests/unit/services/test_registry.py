from unittest.mock import MagicMock

import pytest

from netbox_agent_mcp.services.registry import (
    ServiceRegistry,
    get_services,
    set_services,
)


def test_registry_holds_all_services():
    reg = ServiceRegistry(
        query=MagicMock(),
        search=MagicMock(),
        introspection=MagicMock(),
        trace=MagicMock(),
        availability=MagicMock(),
        ip_reference=MagicMock(),
        device_profile=MagicMock(),
        device_aggregation=MagicMock(),
        graphql=MagicMock(),
    )
    assert reg.query is not None
    assert reg.search is not None
    assert reg.introspection is not None
    assert reg.trace is not None
    assert reg.availability is not None
    assert reg.graphql is not None


def test_get_services_raises_if_unset():
    set_services(None)
    with pytest.raises(RuntimeError, match="not initialized"):
        get_services()


def test_get_services_returns_set_registry():
    reg = ServiceRegistry(
        query=MagicMock(),
        search=MagicMock(),
        introspection=MagicMock(),
        trace=MagicMock(),
        availability=MagicMock(),
        ip_reference=MagicMock(),
        device_profile=MagicMock(),
        device_aggregation=MagicMock(),
        graphql=MagicMock(),
    )
    set_services(reg)
    try:
        assert get_services() is reg
    finally:
        set_services(None)
