from unittest.mock import MagicMock

import pytest

from netbox_agent_mcp.services.device_aggregation_service import (
    DeviceAggregationService,
)


def _mk_rest(pages_by_endpoint):
    """pages_by_endpoint: {endpoint: [page1, page2, ...]}
    where each page is a full dict {count, next, results}.
    """
    rest = MagicMock()
    offsets = dict.fromkeys(pages_by_endpoint, 0)

    def get(endpoint, params=None):
        if endpoint not in pages_by_endpoint:
            return {"count": 0, "next": None, "results": []}
        pages = pages_by_endpoint[endpoint]
        idx = offsets[endpoint]
        if idx >= len(pages):
            return {"count": 0, "next": None, "results": []}
        offsets[endpoint] += 1
        return pages[idx]

    rest.get.side_effect = get
    return rest


def test_aggregate_emits_enrich_next_step_with_concrete_device_id():
    """After the aggregation returns, agent should enrich each top device.
    Server enumerates EVERY expected device_id — not just one example —
    so the agent has a concrete checklist, not a pattern it can apply to
    'the first few' and then footnote-hedge the rest."""
    rest = _mk_rest(
        {
            "dcim/interfaces": [
                {
                    "count": 2,
                    "next": None,
                    "results": [
                        {"id": 1, "device": {"id": 5, "name": "a"}},
                        {"id": 2, "device": {"id": 8, "name": "b"}},
                    ],
                }
            ],
        }
    )
    result = DeviceAggregationService(rest).aggregate_by_device("interfaces", top_n=2)
    assert "next_steps" in result
    step = result["next_steps"][0]
    # BOTH device_ids must appear — checklist, not pattern
    assert "device_id=5" in step
    assert "device_id=8" in step
    # Explicit anti-hedging instruction
    assert "footnote" in step.lower() or "disclaimer" in step.lower()


def test_aggregate_no_next_step_when_no_results():
    rest = _mk_rest({})
    result = DeviceAggregationService(rest).aggregate_by_device("interfaces")
    assert result["next_steps"] == []


def test_aggregate_tunnel_terminations_by_device():
    rest = _mk_rest(
        {
            "vpn/tunnel-terminations": [
                {
                    "count": 5,
                    "next": None,
                    "results": [
                        # Device 5 (router-b): 3 terminations
                        {"id": 1, "termination": {"device": {"id": 5, "name": "router-b"}}},
                        {"id": 2, "termination": {"device": {"id": 5, "name": "router-b"}}},
                        {"id": 3, "termination": {"device": {"id": 5, "name": "router-b"}}},
                        # Device 8 (router-c): 2 terminations
                        {"id": 4, "termination": {"device": {"id": 8, "name": "router-c"}}},
                        {"id": 5, "termination": {"device": {"id": 8, "name": "router-c"}}},
                    ],
                }
            ],
        }
    )
    svc = DeviceAggregationService(rest)
    result = svc.aggregate_by_device("tunnel_terminations", top_n=10)

    assert result["relation"] == "tunnel_terminations"
    assert result["total_items_scanned"] == 5
    assert result["unique_devices"] == 2
    assert result["top_devices"] == [
        {"device": {"id": 5, "name": "router-b"}, "count": 3},
        {"device": {"id": 8, "name": "router-c"}, "count": 2},
    ]


def test_aggregate_enforces_termination_type_filter():
    captured = []

    def get(endpoint, params=None):
        captured.append((endpoint, dict(params or {})))
        return {"count": 0, "next": None, "results": []}

    rest = MagicMock()
    rest.get.side_effect = get

    DeviceAggregationService(rest).aggregate_by_device("tunnel_terminations")
    # Intrinsic filter termination_type=dcim.interface should always be applied
    assert captured[0][1]["termination_type"] == "dcim.interface"
    assert captured[0][1]["fields"] == "termination"


def test_aggregate_interfaces_uses_device_projection():
    rest = _mk_rest(
        {
            "dcim/interfaces": [
                {
                    "count": 3,
                    "next": None,
                    "results": [
                        {"id": 1, "device": {"id": 5, "name": "r1"}},
                        {"id": 2, "device": {"id": 5, "name": "r1"}},
                        {"id": 3, "device": {"id": 7, "name": "r2"}},
                    ],
                }
            ],
        }
    )
    result = DeviceAggregationService(rest).aggregate_by_device("interfaces", top_n=1)
    assert result["top_devices"] == [
        {"device": {"id": 5, "name": "r1"}, "count": 2},
    ]


def test_aggregate_paginates_across_multiple_pages():
    # Simulate 2-page response. Devices 5 and 8 each get 500 rows distributed.
    page1_results = [
        {"id": i, "termination": {"device": {"id": 5, "name": "a"}}} for i in range(300)
    ] + [{"id": 300 + i, "termination": {"device": {"id": 8, "name": "b"}}} for i in range(200)]
    page2_results = [
        {"id": 500 + i, "termination": {"device": {"id": 5, "name": "a"}}} for i in range(100)
    ]

    rest = _mk_rest(
        {
            "vpn/tunnel-terminations": [
                {"count": 600, "next": "url", "results": page1_results},
                {"count": 600, "next": None, "results": page2_results},
            ],
        }
    )
    result = DeviceAggregationService(rest).aggregate_by_device("tunnel_terminations")
    assert result["total_items_scanned"] == 600
    assert result["top_devices"][0] == {"device": {"id": 5, "name": "a"}, "count": 400}
    assert result["top_devices"][1] == {"device": {"id": 8, "name": "b"}, "count": 200}


def test_aggregate_respects_max_scan():
    """Max-scan caps how many rows are scanned; partial ranking is flagged."""
    # Pretend NetBox has way more rows than max_scan; second page never reached.
    page1_results = [
        {"id": i, "termination": {"device": {"id": 1, "name": "a"}}} for i in range(500)
    ]
    rest = _mk_rest(
        {
            "vpn/tunnel-terminations": [
                {"count": 3000, "next": "url", "results": page1_results},
            ],
        }
    )
    result = DeviceAggregationService(rest).aggregate_by_device(
        "tunnel_terminations",
        max_scan=500,
    )
    assert result["total_items_scanned"] == 500
    assert result["truncated"] is True


def test_aggregate_unknown_relation_raises():
    rest = MagicMock()
    with pytest.raises(ValueError, match="Unknown relation"):
        DeviceAggregationService(rest).aggregate_by_device("wiggles")


def test_aggregate_top_n_zero_returns_all():
    rest = _mk_rest(
        {
            "dcim/interfaces": [
                {
                    "count": 3,
                    "next": None,
                    "results": [
                        {"id": 1, "device": {"id": 1, "name": "a"}},
                        {"id": 2, "device": {"id": 2, "name": "b"}},
                        {"id": 3, "device": {"id": 3, "name": "c"}},
                    ],
                }
            ],
        }
    )
    result = DeviceAggregationService(rest).aggregate_by_device("interfaces", top_n=0)
    assert len(result["top_devices"]) == 3


def test_aggregate_merges_caller_filters_with_intrinsic():
    """Caller can pass e.g. role_id=3 (firewalls only) and it's merged with
    termination_type=dcim.interface."""
    captured = []

    def get(endpoint, params=None):
        captured.append(dict(params or {}))
        return {"count": 0, "next": None, "results": []}

    rest = MagicMock()
    rest.get.side_effect = get

    DeviceAggregationService(rest).aggregate_by_device(
        "tunnel_terminations", filters={"role_id": 3}
    )
    assert captured[0]["termination_type"] == "dcim.interface"
    assert captured[0]["role_id"] == 3


def test_aggregate_filters_translate_in_suffix():
    """caller-supplied __in filters should be stripped to repeated params."""
    captured = []

    def get(endpoint, params=None):
        captured.append(dict(params or {}))
        return {"count": 0, "next": None, "results": []}

    rest = MagicMock()
    rest.get.side_effect = get

    DeviceAggregationService(rest).aggregate_by_device(
        "interfaces", filters={"site_id__in": [1, 2, 3]}
    )
    # __in suffix is stripped; the wire param is site_id with a list value
    assert "site_id__in" not in captured[0]
    assert captured[0]["site_id"] == [1, 2, 3]


def test_aggregate_resilient_to_endpoint_error():
    rest = MagicMock()
    rest.get.side_effect = RuntimeError("network down")
    result = DeviceAggregationService(rest).aggregate_by_device("tunnel_terminations")
    assert result["top_devices"] == []
    assert result["unique_devices"] == 0
    assert "network down" in result["error"]
