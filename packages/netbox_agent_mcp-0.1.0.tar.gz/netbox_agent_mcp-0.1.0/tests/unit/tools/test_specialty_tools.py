from unittest.mock import MagicMock

import pytest

from netbox_agent_mcp.services.registry import ServiceRegistry, set_services
from netbox_agent_mcp.tools.specialty import (
    netbox_aggregate_by_device,
    netbox_device_profile,
    netbox_find_ip_references,
    netbox_get_available,
    netbox_trace_path,
)


@pytest.fixture
def registry():
    reg = ServiceRegistry(
        query=MagicMock(),
        search=MagicMock(),
        introspection=MagicMock(),
        trace=MagicMock(),
        availability=MagicMock(),
        ip_reference=MagicMock(),
        device_profile=MagicMock(),
        device_aggregation=MagicMock(),
        graphql=MagicMock(),
    )
    set_services(reg)
    yield reg
    set_services(None)


def test_netbox_trace_path_delegates(registry):
    registry.trace.trace.return_value = []
    netbox_trace_path(endpoint_type="interfaces", endpoint_id=42)
    registry.trace.trace.assert_called_once_with("interfaces", 42)


def test_netbox_get_available_delegates(registry):
    registry.availability.get_available.return_value = []
    netbox_get_available(resource_type="prefix.available-ips", parent_id=42, count=5)
    registry.availability.get_available.assert_called_once_with(
        "prefix.available-ips", parent_id=42, count=5
    )


def test_netbox_find_ip_references_delegates(registry):
    registry.ip_reference.find_references.return_value = {
        "query": "198.51.100.1",
        "ipam_record": None,
        "text_references": {},
        "summary": {},
    }
    result = netbox_find_ip_references(ip="198.51.100.1")
    registry.ip_reference.find_references.assert_called_once_with("198.51.100.1")
    assert result["query"] == "198.51.100.1"


def test_netbox_device_profile_delegates_default(registry):
    registry.device_profile.profile.return_value = {
        "device": {"id": 42},
        "counts": {},
        "sections": {},
        "hints": [],
    }
    netbox_device_profile(device_id=42)
    registry.device_profile.profile.assert_called_once_with(
        device_id=42,
        include=None,
        max_per_category=100,
    )


def test_netbox_device_profile_summary_mode(registry):
    registry.device_profile.profile.return_value = {
        "device": {"id": 5},
        "counts": {"interfaces": 173},
        "sections": {},
        "hints": [],
    }
    netbox_device_profile(device_id=5, max_per_category=0)
    registry.device_profile.profile.assert_called_once_with(
        device_id=5,
        include=None,
        max_per_category=0,
    )


def test_netbox_aggregate_by_device_delegates(registry):
    registry.device_aggregation.aggregate_by_device.return_value = {
        "relation": "tunnel_terminations",
        "total_items_scanned": 0,
        "truncated": False,
        "unique_devices": 0,
        "top_devices": [],
    }
    netbox_aggregate_by_device(relation="tunnel_terminations")
    registry.device_aggregation.aggregate_by_device.assert_called_once_with(
        relation="tunnel_terminations",
        top_n=10,
        filters=None,
        max_scan=10_000,
    )


def test_netbox_aggregate_by_device_passes_filters(registry):
    registry.device_aggregation.aggregate_by_device.return_value = {
        "top_devices": [],
        "unique_devices": 0,
        "total_items_scanned": 0,
        "truncated": False,
        "relation": "interfaces",
    }
    netbox_aggregate_by_device(
        relation="interfaces",
        top_n=5,
        filters={"role_id": 3},
        max_scan=5000,
    )
    registry.device_aggregation.aggregate_by_device.assert_called_once_with(
        relation="interfaces",
        top_n=5,
        filters={"role_id": 3},
        max_scan=5000,
    )


def test_netbox_device_profile_include_subset(registry):
    registry.device_profile.profile.return_value = {
        "device": {},
        "counts": {},
        "sections": {},
        "hints": [],
    }
    netbox_device_profile(device_id=1, include=["interfaces", "inventory_items"])
    registry.device_profile.profile.assert_called_once_with(
        device_id=1,
        include=["interfaces", "inventory_items"],
        max_per_category=100,
    )
