from unittest.mock import MagicMock

import pytest

from netbox_agent_mcp.services.registry import ServiceRegistry, set_services
from netbox_agent_mcp.tools.query import netbox_get, netbox_get_all, netbox_query


@pytest.fixture
def registry():
    reg = ServiceRegistry(
        query=MagicMock(),
        search=MagicMock(),
        introspection=MagicMock(),
        trace=MagicMock(),
        availability=MagicMock(),
        ip_reference=MagicMock(),
        device_profile=MagicMock(),
        device_aggregation=MagicMock(),
        graphql=MagicMock(),
    )
    set_services(reg)
    yield reg
    set_services(None)


def test_netbox_query_passes_to_graphql_client(registry):
    registry.graphql.query.return_value = {"device_list": [{"id": 1}]}
    result = netbox_query(graphql="query { device_list { id } }")
    registry.graphql.query.assert_called_once_with("query { device_list { id } }", variables=None)
    assert result["data"] == {"device_list": [{"id": 1}]}


def test_netbox_query_passes_variables(registry):
    registry.graphql.query.return_value = {}
    netbox_query(graphql="q", variables={"x": 1})
    registry.graphql.query.assert_called_once_with("q", variables={"x": 1})


def test_netbox_get_delegates_to_query_service(registry):
    registry.query.get.return_value = {
        "results": [],
        "total_count": 0,
        "has_more": False,
        "suggested_next": {},
    }
    netbox_get(object_type="dcim.device", filters={"site_id": 1})
    registry.query.get.assert_called_once_with(
        object_type="dcim.device",
        filters={"site_id": 1},
        select=None,
        limit=10,
        offset=0,
        ordering=None,
    )


def test_netbox_get_passes_ordering(registry):
    registry.query.get.return_value = {
        "results": [],
        "total_count": 0,
        "has_more": False,
        "suggested_next": {},
    }
    netbox_get(
        object_type="dcim.site",
        filters={},
        select=["name", "device_count"],
        limit=10,
        ordering="-device_count",
    )
    registry.query.get.assert_called_once_with(
        object_type="dcim.site",
        filters={},
        select=["name", "device_count"],
        limit=10,
        offset=0,
        ordering="-device_count",
    )


def test_netbox_get_all_delegates(registry):
    registry.query.get_all.return_value = {
        "results": [],
        "total_count": 0,
        "has_more": False,
        "suggested_next": {},
    }
    netbox_get_all(object_type="dcim.device", filters={})
    registry.query.get_all.assert_called_once_with(
        object_type="dcim.device",
        filters={},
        select=None,
        max_records=10000,
        ordering=None,
    )
