from unittest.mock import MagicMock

import pytest

from netbox_agent_mcp.services.registry import ServiceRegistry, set_services
from netbox_agent_mcp.tools.introspection import netbox_inspect_type


@pytest.fixture
def registry():
    reg = ServiceRegistry(
        query=MagicMock(),
        search=MagicMock(),
        introspection=MagicMock(),
        trace=MagicMock(),
        availability=MagicMock(),
        ip_reference=MagicMock(),
        device_profile=MagicMock(),
        device_aggregation=MagicMock(),
        graphql=MagicMock(),
    )
    set_services(reg)
    yield reg
    set_services(None)


def test_netbox_inspect_type_delegates(registry):
    registry.introspection.inspect_type.return_value = {"name": "DeviceType", "fields": []}
    result = netbox_inspect_type(object_type="dcim.device")
    registry.introspection.inspect_type.assert_called_once_with("dcim.device")
    assert result["name"] == "DeviceType"
