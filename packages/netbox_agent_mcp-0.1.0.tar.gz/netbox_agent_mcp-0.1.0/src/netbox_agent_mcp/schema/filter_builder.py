"""REST filter-grammar translation."""

from typing import Any


def filters_to_rest_params(filters: dict[str, Any]) -> dict[str, Any]:
    """Translate the REST-ish filter grammar agents use into params NetBox
    actually accepts.

    Agents write ``{"site_id__in": [8, 12]}``. NetBox's REST API does NOT
    accept ``?site_id__in=8&site_id__in=12`` — it silently drops unknown filter
    keys and returns an unfiltered set. The correct wire form is repeated scalar
    params: ``?site_id=8&site_id=12``.

    So: strip the ``__in`` suffix when the value is a list; httpx will then
    serialize the list as repeated bare params. Leave all other suffixes
    (``__ic``, ``__gte``, ``__empty``, ``__n``, etc.) untouched — those ARE
    valid URL-level suffixes on NetBox's DRF filterset.
    """
    out: dict[str, Any] = {}
    for key, value in filters.items():
        if key.endswith("__in") and isinstance(value, list):
            out[key.removesuffix("__in")] = value
        else:
            out[key] = value
    return out
