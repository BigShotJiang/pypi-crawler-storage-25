"""Compute ``suggested_filters`` blocks from search matches.

Agents use these blocks as pre-built filter payloads for follow-up
``netbox_get`` calls, eliminating the need to parse search output and
re-construct filters by hand (the "pre-computed execution plan").
"""

from typing import Any

# Each rule: source object type → list of (suggestion_key, target_object_type, fk_field)
SUGGESTION_RULES: dict[str, list[tuple[str, str, str]]] = {
    "dcim.site": [
        ("devices_at_these_sites", "dcim.device", "site_id"),
        ("prefixes_at_these_sites", "ipam.prefix", "site_id"),
        ("racks_at_these_sites", "dcim.rack", "site_id"),
        ("circuits_at_these_sites", "circuits.circuit", "site_id"),
        ("vlans_at_these_sites", "ipam.vlan", "site_id"),
    ],
    "dcim.device": [
        ("interfaces_on_these_devices", "dcim.interface", "device_id"),
        ("ip_addresses_on_these_devices", "ipam.ipaddress", "device_id"),
        ("cables_on_these_devices", "dcim.cable", "device_id"),
    ],
    "dcim.rack": [
        ("devices_in_these_racks", "dcim.device", "rack_id"),
    ],
    "dcim.region": [
        ("sites_in_these_regions", "dcim.site", "region_id"),
    ],
    "dcim.location": [
        ("devices_at_these_locations", "dcim.device", "location_id"),
        ("racks_at_these_locations", "dcim.rack", "location_id"),
    ],
    "ipam.prefix": [
        ("ip_addresses_in_these_prefixes", "ipam.ipaddress", "parent_prefix_id"),
    ],
    "ipam.vlan": [
        ("prefixes_for_these_vlans", "ipam.prefix", "vlan_id"),
    ],
    "ipam.vrf": [
        ("prefixes_in_these_vrfs", "ipam.prefix", "vrf_id"),
        ("ip_addresses_in_these_vrfs", "ipam.ipaddress", "vrf_id"),
    ],
    "circuits.provider": [
        ("circuits_from_these_providers", "circuits.circuit", "provider_id"),
    ],
    "tenancy.tenant": [
        ("sites_for_these_tenants", "dcim.site", "tenant_id"),
        ("devices_for_these_tenants", "dcim.device", "tenant_id"),
        ("prefixes_for_these_tenants", "ipam.prefix", "tenant_id"),
    ],
    "virtualization.cluster": [
        ("vms_in_these_clusters", "virtualization.virtualmachine", "cluster_id"),
    ],
    # Junction / relationship types: steer agents from a list object to its
    # termination junction so device association can be resolved structurally.
    "vpn.tunnel": [
        ("terminations_for_these_tunnels", "vpn.tunneltermination", "tunnel_id"),
    ],
    "dcim.cable": [
        ("terminations_for_these_cables", "dcim.cabletermination", "cable_id"),
    ],
    "circuits.circuit": [
        ("terminations_for_these_circuits", "circuits.circuittermination", "circuit_id"),
    ],
    "ipam.fhrpgroup": [
        ("assignments_for_these_groups", "ipam.fhrpgroupassignment", "group_id"),
    ],
}


def compute_suggested_filters(
    matches: dict[str, list[dict[str, Any]]],
) -> dict[str, dict[str, Any]]:
    suggestions: dict[str, dict[str, Any]] = {}

    for source_type, items in matches.items():
        if not items:
            continue
        ids = [item["id"] for item in items if "id" in item]
        if not ids:
            continue

        rules = SUGGESTION_RULES.get(source_type, [])
        for key, target_type, fk_field in rules:
            suggestions[key] = {
                "object_type": target_type,
                "filters": {f"{fk_field}__in": ids},
            }

    return suggestions
