"""Canonical object type registry.

Maps object type identifiers (e.g. "dcim.device") to:
- ``rest``: REST endpoint path (e.g. "dcim/devices")
- ``gql``:  GraphQL query field name (e.g. "device_list")
- ``guidance`` (optional): a short agent-facing hint about how to use this type
  correctly. Surfaced in ``netbox_get`` and ``netbox_inspect_type`` responses
  to steer agents away from common dead-end patterns (e.g. text-searching
  tunnel descriptions to find owning devices, when vpn.tunneltermination is
  the structural answer).

Curated list: core NetBox object types. Plugin types are out of scope.
"""

from typing import NotRequired, TypedDict

from netbox_agent_mcp.exceptions import UnknownObjectTypeError


class _TypeEntry(TypedDict):
    rest: str
    gql: str
    guidance: NotRequired[str]


OBJECT_TYPES: dict[str, _TypeEntry] = {
    # DCIM
    "dcim.device": {
        "rest": "dcim/devices",
        "gql": "device_list",
        "guidance": (
            "Class-of-infrastructure questions (firewalls, switches, routers): "
            "resolve the dcim.devicerole first and filter with role_id + site_id/"
            "site_id__in. Don't match on device.name substrings."
        ),
    },
    "dcim.devicerole": {"rest": "dcim/device-roles", "gql": "device_role_list"},
    "dcim.devicetype": {"rest": "dcim/device-types", "gql": "device_type_list"},
    "dcim.site": {"rest": "dcim/sites", "gql": "site_list"},
    "dcim.sitegroup": {"rest": "dcim/site-groups", "gql": "site_group_list"},
    "dcim.region": {"rest": "dcim/regions", "gql": "region_list"},
    "dcim.location": {"rest": "dcim/locations", "gql": "location_list"},
    "dcim.rack": {"rest": "dcim/racks", "gql": "rack_list"},
    "dcim.interface": {
        "rest": "dcim/interfaces",
        "gql": "interface_list",
        "guidance": (
            "Interfaces belong to a device via `device_id`. For 'how many "
            "interfaces of type X does device D have?' use "
            "filters={device_id: D, type: 'virtual'} (or the specific type value). "
            "Don't rely on name patterns like 'tunnel.*'."
        ),
    },
    "dcim.cable": {"rest": "dcim/cables", "gql": "cable_list"},
    "dcim.cabletermination": {
        "rest": "dcim/cable-terminations",
        "gql": "cable_termination_list",
        "guidance": (
            "Junction table: each cable has two rows here (one per end). Each "
            "row has termination_type + termination_id → the cabled endpoint "
            "(usually dcim.interface, then follow interface.device)."
        ),
    },
    "dcim.manufacturer": {"rest": "dcim/manufacturers", "gql": "manufacturer_list"},
    "dcim.platform": {"rest": "dcim/platforms", "gql": "platform_list"},
    "dcim.consoleport": {"rest": "dcim/console-ports", "gql": "console_port_list"},
    "dcim.consoleserverport": {
        "rest": "dcim/console-server-ports",
        "gql": "console_server_port_list",
    },
    "dcim.powerport": {"rest": "dcim/power-ports", "gql": "power_port_list"},
    "dcim.poweroutlet": {"rest": "dcim/power-outlets", "gql": "power_outlet_list"},
    "dcim.powerfeed": {"rest": "dcim/power-feeds", "gql": "power_feed_list"},
    "dcim.frontport": {"rest": "dcim/front-ports", "gql": "front_port_list"},
    "dcim.rearport": {"rest": "dcim/rear-ports", "gql": "rear_port_list"},
    "dcim.inventoryitem": {
        "rest": "dcim/inventory-items",
        "gql": "inventory_item_list",
    },
    "dcim.modulebay": {"rest": "dcim/module-bays", "gql": "module_bay_list"},
    "dcim.devicebay": {"rest": "dcim/device-bays", "gql": "device_bay_list"},
    "dcim.virtualchassis": {"rest": "dcim/virtual-chassis", "gql": "virtual_chassis_list"},
    # IPAM
    "ipam.prefix": {"rest": "ipam/prefixes", "gql": "prefix_list"},
    "ipam.ipaddress": {
        "rest": "ipam/ip-addresses",
        "gql": "ip_address_list",
        "guidance": (
            "Device ownership is on `assigned_object` (polymorphic FK to "
            "dcim.interface, virtualization.vminterface, or ipam.fhrpgroup). "
            "If assigned_object is null the IP has no structural owner — "
            "use netbox_find_ip_references to scan tunnel/interface/prefix "
            "descriptions for mentions."
        ),
    },
    "ipam.iprange": {"rest": "ipam/ip-ranges", "gql": "ip_range_list"},
    "ipam.vlan": {"rest": "ipam/vlans", "gql": "vlan_list"},
    "ipam.vlangroup": {"rest": "ipam/vlan-groups", "gql": "vlan_group_list"},
    "ipam.vrf": {"rest": "ipam/vrfs", "gql": "vrf_list"},
    "ipam.aggregate": {"rest": "ipam/aggregates", "gql": "aggregate_list"},
    "ipam.asn": {"rest": "ipam/asns", "gql": "asn_list"},
    "ipam.asnrange": {"rest": "ipam/asn-ranges", "gql": "asn_range_list"},
    "ipam.service": {"rest": "ipam/services", "gql": "service_list"},
    "ipam.fhrpgroup": {"rest": "ipam/fhrp-groups", "gql": "fhrp_group_list"},
    "ipam.fhrpgroupassignment": {
        "rest": "ipam/fhrp-group-assignments",
        "gql": "fhrp_group_assignment_list",
        "guidance": (
            "Junction table linking fhrpgroup to an interface. "
            "interface_type + interface_id → dcim.interface (and then device)."
        ),
    },
    # Circuits
    "circuits.circuit": {"rest": "circuits/circuits", "gql": "circuit_list"},
    "circuits.circuittermination": {
        "rest": "circuits/circuit-terminations",
        "gql": "circuit_termination_list",
        "guidance": (
            "Junction table: each circuit has terminations at A-side and Z-side. "
            "Each row has site_id and optionally an interface termination. For "
            "'which devices terminate circuit X?' query here and follow the "
            "interface reference."
        ),
    },
    "circuits.provider": {"rest": "circuits/providers", "gql": "provider_list"},
    "circuits.circuittype": {"rest": "circuits/circuit-types", "gql": "circuit_type_list"},
    # Virtualization
    "virtualization.virtualmachine": {
        "rest": "virtualization/virtual-machines",
        "gql": "virtual_machine_list",
    },
    "virtualization.cluster": {"rest": "virtualization/clusters", "gql": "cluster_list"},
    "virtualization.clustertype": {
        "rest": "virtualization/cluster-types",
        "gql": "cluster_type_list",
    },
    "virtualization.vminterface": {"rest": "virtualization/interfaces", "gql": "vm_interface_list"},
    # Tenancy
    "tenancy.tenant": {"rest": "tenancy/tenants", "gql": "tenant_list"},
    "tenancy.tenantgroup": {"rest": "tenancy/tenant-groups", "gql": "tenant_group_list"},
    "tenancy.contact": {"rest": "tenancy/contacts", "gql": "contact_list"},
    # VPN
    "vpn.tunnel": {
        "rest": "vpn/tunnels",
        "gql": "tunnel_list",
        "guidance": (
            "A tunnel is a CONFIGURATION OBJECT. It does NOT directly reference a "
            "device. For 'which devices have tunnels?' or 'top N devices by "
            "tunnel count' you MUST query vpn.tunneltermination (the junction "
            "table) and follow termination → dcim.interface → device. Do not "
            "parse tunnel names or descriptions."
        ),
    },
    "vpn.tunneltermination": {
        "rest": "vpn/tunnel-terminations",
        "gql": "tunnel_termination_list",
        "guidance": (
            "Junction table: each row links one tunnel to one terminating "
            "endpoint via termination_type + termination_id (usually "
            "'dcim.interface', also 'virtualization.vminterface'). For "
            "'top N devices with tunnels', get_all these and aggregate "
            "client-side by termination.device.id."
        ),
    },
    "vpn.l2vpn": {"rest": "vpn/l2vpns", "gql": "l2vpn_list"},
    "vpn.l2vpntermination": {
        "rest": "vpn/l2vpn-terminations",
        "gql": "l2vpn_termination_list",
        "guidance": (
            "Junction table for L2VPN → interface/VLAN. Follow assigned_object "
            "to the terminating endpoint."
        ),
    },
    # Wireless
    "wireless.wirelesslan": {"rest": "wireless/wireless-lans", "gql": "wireless_lan_list"},
    "wireless.wirelesslink": {"rest": "wireless/wireless-links", "gql": "wireless_link_list"},
    # Extras / core
    "extras.tag": {"rest": "extras/tags", "gql": "tag_list"},
    "extras.journalentry": {"rest": "extras/journal-entries", "gql": "journal_entry_list"},
    "extras.configcontext": {"rest": "extras/config-contexts", "gql": "config_context_list"},
    "core.objectchange": {
        "rest": "core/object-changes",
        "gql": "object_change_list",
        "guidance": (
            "Audit trail. Filter by changed_object_type_id (a numeric "
            "ContentType ID, not a string), changed_object_id, user, action "
            "(created/updated/deleted), and time_before/time_after (ISO 8601)."
        ),
    },
}


def validate_object_type(object_type: str) -> None:
    if object_type not in OBJECT_TYPES:
        raise UnknownObjectTypeError(given=object_type, valid=list(OBJECT_TYPES.keys()))


def resolve_rest_endpoint(object_type: str) -> str:
    validate_object_type(object_type)
    return OBJECT_TYPES[object_type]["rest"]


def resolve_graphql_query_field(object_type: str) -> str:
    validate_object_type(object_type)
    return OBJECT_TYPES[object_type]["gql"]


def get_type_guidance(object_type: str) -> str | None:
    """Return the curated agent-facing hint for this type, or None."""
    if object_type not in OBJECT_TYPES:
        return None
    return OBJECT_TYPES[object_type].get("guidance")
