"""Service registry — single access point for tool-layer functions."""

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from netbox_agent_mcp.clients.graphql import GraphQLClient
    from netbox_agent_mcp.services.availability_service import AvailabilityService
    from netbox_agent_mcp.services.device_aggregation_service import DeviceAggregationService
    from netbox_agent_mcp.services.device_profile_service import DeviceProfileService
    from netbox_agent_mcp.services.introspection_service import IntrospectionService
    from netbox_agent_mcp.services.ip_reference_service import IPReferenceService
    from netbox_agent_mcp.services.query_service import QueryService
    from netbox_agent_mcp.services.search_service import SearchService
    from netbox_agent_mcp.services.trace_service import TraceService


@dataclass
class ServiceRegistry:
    query: "QueryService"
    search: "SearchService"
    introspection: "IntrospectionService"
    trace: "TraceService"
    availability: "AvailabilityService"
    ip_reference: "IPReferenceService"
    device_profile: "DeviceProfileService"
    device_aggregation: "DeviceAggregationService"
    graphql: "GraphQLClient"


_services: ServiceRegistry | None = None


def set_services(reg: ServiceRegistry | None) -> None:
    global _services
    _services = reg


def get_services() -> ServiceRegistry:
    if _services is None:
        raise RuntimeError("Service registry not initialized. Did main() run?")
    return _services
