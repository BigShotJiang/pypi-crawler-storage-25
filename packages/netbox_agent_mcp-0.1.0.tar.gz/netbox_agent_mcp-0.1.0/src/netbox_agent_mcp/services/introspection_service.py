"""GraphQL schema introspection with in-process cache."""

from typing import Any

from netbox_agent_mcp.clients.graphql import GraphQLClient
from netbox_agent_mcp.clients.rest import RestClient
from netbox_agent_mcp.schema.object_types import (
    get_type_guidance,
    resolve_graphql_query_field,
)


# Maps a list field (e.g. "device_list") to the introspectable type name
# (e.g. "DeviceType"). NetBox convention: strip _list suffix, append "Type",
# camel-case.
def _list_field_to_type_name(list_field: str) -> str:
    stem = list_field.removesuffix("_list")
    camel = "".join(part.capitalize() for part in stem.split("_"))
    return f"{camel}Type"


class IntrospectionService:
    def __init__(self, gql: GraphQLClient, rest: RestClient) -> None:
        self._gql = gql
        self._rest = rest
        self._version: str | None = None
        self._cache: dict[tuple[str, str], dict[str, Any]] = {}

    def inspect_type(self, object_type: str) -> dict[str, Any]:
        version = self._get_netbox_version()
        cache_key = (version, object_type)
        if cache_key in self._cache:
            return self._cache[cache_key]

        list_field = resolve_graphql_query_field(object_type)
        type_name = _list_field_to_type_name(list_field)

        query = (
            "query($name: String!) { "
            "__type(name: $name) { "
            "name description "
            "fields { name description type { name kind ofType { name kind } } } "
            "} }"
        )
        result = self._gql.query(query, variables={"name": type_name})
        type_data = dict(result.get("__type") or {})
        guidance = get_type_guidance(object_type)
        if guidance:
            type_data["type_guidance"] = guidance
        self._cache[cache_key] = type_data
        return type_data

    def _get_netbox_version(self) -> str:
        if self._version is None:
            status = self._rest.get("status")
            self._version = str(status.get("netbox-version", "unknown"))
        return self._version
