"""Queries NetBox's REST 'available-*' endpoints for capacity planning."""

from typing import Any

from netbox_agent_mcp.clients.rest import RestClient

ENDPOINT_MAP: dict[str, str] = {
    "prefix.available-ips": "ipam/prefixes/{id}/available-ips",
    "prefix.available-prefixes": "ipam/prefixes/{id}/available-prefixes",
    "ip-range.available-ips": "ipam/ip-ranges/{id}/available-ips",
    "vlan-group.available-vlans": "ipam/vlan-groups/{id}/available-vlans",
    "asn-range.available-asns": "ipam/asn-ranges/{id}/available-asns",
}


class AvailabilityService:
    def __init__(self, rest: RestClient) -> None:
        self._rest = rest

    def get_available(
        self,
        resource_type: str,
        *,
        parent_id: int,
        count: int = 1,
    ) -> Any:
        if resource_type not in ENDPOINT_MAP:
            valid = ", ".join(sorted(ENDPOINT_MAP.keys()))
            raise ValueError(f"Invalid resource_type '{resource_type}'. Valid: {valid}")
        path = ENDPOINT_MAP[resource_type].format(id=parent_id)
        return self._rest.get(path, params={"limit": count})
