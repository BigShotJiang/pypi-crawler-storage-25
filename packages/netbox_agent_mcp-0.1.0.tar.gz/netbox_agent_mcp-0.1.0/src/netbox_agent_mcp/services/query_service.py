"""Top-level query orchestration.

``netbox_get`` and ``netbox_get_all`` are backed by NetBox's REST API.
NetBox's Strawberry GraphQL schema exposes list fields as plain ``list[T]``
without sibling ``_count`` fields, does not support ``__in`` lookups on
scalar ID filters, and nests ``limit``/``offset`` inside a ``pagination``
input — all of which make a GraphQL-compiled list interface brittle. REST
supports the shape we need natively: ``?site_id=1&site_id=2`` for multi-ID,
``count``/``next``/``previous`` metadata for pagination, and ``?fields=``
for projection.

``netbox_query`` is a raw GraphQL escape hatch for power users;
``netbox_inspect_type`` uses GraphQL introspection. Dual-primary
GraphQL + REST, with list/filter on REST.
"""

from typing import Any

from netbox_agent_mcp.clients.rest import RestClient
from netbox_agent_mcp.exceptions import CapExceededError
from netbox_agent_mcp.schema.filter_builder import filters_to_rest_params
from netbox_agent_mcp.schema.object_types import (
    get_type_guidance,
    resolve_rest_endpoint,
    validate_object_type,
)
from netbox_agent_mcp.schema.suggested_filters import compute_suggested_filters

PAGE_SIZE = 500
ABSOLUTE_CEILING = 100_000


def _select_to_rest_fields(select: list[str] | None) -> str | None:
    """Flatten dotted paths to the top-level field names NetBox REST accepts.

    NetBox REST supports ``?fields=foo,bar``. Dotted paths like
    ``"site.region.name"`` collapse to the top-level field (``site``). NetBox
    returns nested objects one level deep by default, so 1-hop paths
    (``"site.name"``) resolve natively. Truly deep paths (``"site.region.name"``)
    aren't fully resolvable via REST; ``netbox_query`` is the escape hatch.

    ``id`` is always included so the agent can construct follow-up calls.
    """
    if not select:
        return None
    tops = {"id"} | {path.split(".", 1)[0] for path in select if path}
    return ",".join(sorted(tops))


def _detect_deep_select_collapse(select: list[str] | None) -> list[str]:
    """Return the subset of `select` paths that have dots — i.e., agents who
    thought they were asking for a deep projection but will only get the
    top-level object.
    """
    if not select:
        return []
    return [p for p in select if "." in p]


def _detect_dropped_fields(
    select: list[str] | None,
    results: list[dict[str, Any]],
) -> list[str]:
    """Return top-level fields the agent requested but NetBox didn't return.

    NetBox REST's ``?fields=`` parameter silently drops unknown field names.
    If an agent asks for ``select=["device.name"]`` on ``ipam.ipaddress`` (which
    has no ``device`` field — assignments live on ``assigned_object``), NetBox
    returns only the valid fields and the agent has no signal that part of the
    request was rejected. We surface that signal so agents can pivot.
    """
    if not select or not results:
        return []
    first = results[0]
    if not isinstance(first, dict):
        return []
    requested_tops = {p.split(".", 1)[0] for p in select if p}
    returned_keys = set(first.keys())
    return sorted(requested_tops - returned_keys)


def _compute_next_steps(
    object_type: str,
    results: list[dict[str, Any]],
) -> list[str]:
    """Per-object-type recommendations the agent should act on BEFORE responding.

    Fires with concrete IDs from the actual results so the agent can lift
    the tool call verbatim. Only adds hints where a specific enrichment
    pattern is high-ROI and commonly skipped.
    """
    steps: list[str] = []
    if not results:
        return steps

    if object_type == "dcim.device":
        device_ids = [
            r.get("id") for r in results if isinstance(r, dict) and r.get("id") is not None
        ]
        if device_ids:
            # Emit the full list so the agent has a checklist, not just one
            # example it might interpret as "do it once".
            preview = device_ids[:10]
            call_list = "\n  ".join(f"- netbox_device_profile(device_id={i})" for i in preview)
            overflow = (
                f"\n  (...{len(device_ids) - 10} more — make one call per device)"
                if len(device_ids) > 10
                else ""
            )
            steps.append(
                f"Devices here carry site/role but no management IP in this "
                f"shape. Before presenting to the user, enrich EVERY one of "
                f"the {len(device_ids)} devices with "
                f"`netbox_device_profile(device_id=D)`:\n  "
                f"{call_list}{overflow}\n"
                f"Do not truncate to the first few and footnote the rest as "
                f"'unverified'. Either enrich all {len(device_ids)} or reduce "
                f"the table you show the user to only the rows you actually "
                f"fetched."
            )

    elif object_type == "ipam.ipaddress":
        unassigned = [r for r in results if isinstance(r, dict) and not r.get("assigned_object")]
        if unassigned:
            sample_addr = next((u.get("address") for u in unassigned if u.get("address")), None)
            suffix = (
                f" Example: `netbox_find_ip_references(ip='{sample_addr}')`." if sample_addr else ""
            )
            steps.append(
                f"{len(unassigned)} of {len(results)} returned IPs have no "
                f"`assigned_object` (no structural device binding). For those, "
                f"pivot to `netbox_find_ip_references(ip=X)` to scan tunnel/"
                f"interface/prefix descriptions.{suffix}"
            )

    elif object_type == "dcim.site":
        steps.append(
            "Presenting sites? Most users expect region + tenant + device_count "
            "+ rack_count alongside the name. If those aren't in the current "
            "select, re-query with `select=['name','region.name','tenant.name',"
            "'device_count','rack_count']` — one call, no enrichment loop."
        )

    elif object_type == "dcim.interface":
        uncabled = sum(1 for r in results if isinstance(r, dict) and r.get("cable") is None)
        if uncabled:
            steps.append(
                f"{uncabled} of {len(results)} interfaces are uncabled. "
                f"`netbox_trace_path` on these will return []; that's expected, "
                f"not an error. For management/OOB interfaces, "
                f"`netbox_device_profile(device_id=<device>)` has the structural "
                f"mgmt answer."
            )

    return steps


def _ordering_to_rest_param(
    ordering: str | list[str] | None,
) -> str | None:
    """Translate ordering into NetBox's comma-separated REST ordering param.

    NetBox REST supports ``?ordering=field`` (ascending) and
    ``?ordering=-field`` (descending); multiple fields are comma-separated
    (``?ordering=-count,name``). Many serializer-computed counts are orderable
    (e.g. ``dcim.site.device_count``, ``dcim.rack.u_consumed``,
    ``dcim.device.interface_count``) — see the 'Top N by pre-computed count'
    pattern in the system prompt.
    """
    if ordering is None:
        return None
    if isinstance(ordering, str):
        cleaned = ordering.strip()
        return cleaned or None
    # list[str]
    cleaned = [s.strip() for s in ordering if s and s.strip()]
    if not cleaned:
        return None
    return ",".join(cleaned)


class QueryService:
    def __init__(self, rest: RestClient) -> None:
        self._rest = rest

    def get(
        self,
        *,
        object_type: str,
        filters: dict[str, Any],
        select: list[str] | None = None,
        limit: int = 10,
        offset: int = 0,
        ordering: str | list[str] | None = None,
    ) -> dict[str, Any]:
        validate_object_type(object_type)
        endpoint = resolve_rest_endpoint(object_type)

        params: dict[str, Any] = filters_to_rest_params(filters)
        params["limit"] = limit
        params["offset"] = offset
        fields = _select_to_rest_fields(select)
        if fields is not None:
            params["fields"] = fields
        ordering_param = _ordering_to_rest_param(ordering)
        if ordering_param is not None:
            params["ordering"] = ordering_param

        response = self._rest.get(endpoint, params=params)
        results = response.get("results") or []
        total_count = int(response.get("count") or 0)
        has_more = response.get("next") is not None

        out: dict[str, Any] = {
            "results": results,
            "total_count": total_count,
            "has_more": has_more,
            "suggested_next": compute_suggested_filters({object_type: results}),
        }
        dropped = _detect_dropped_fields(select, results)
        if dropped:
            out["fields_dropped"] = dropped
            out["fields_dropped_hint"] = (
                f"NetBox silently ignored these requested fields on {object_type}: "
                f"{dropped}. Call netbox_inspect_type('{object_type}') to see valid "
                f"fields — or omit `select` to see the full object shape."
            )
        guidance = get_type_guidance(object_type)
        if guidance:
            out["type_guidance"] = guidance

        deep_paths = _detect_deep_select_collapse(select)
        if deep_paths:
            out["select_collapse_note"] = (
                f"Dotted select paths {deep_paths} collapse to top-level "
                f"REST fields — NetBox's ?fields= doesn't support dotted "
                f"selection, so the full top-level object(s) "
                f"({sorted({p.split('.', 1)[0] for p in deep_paths})}) are "
                f"returned, not just the requested subfields. For aggregate "
                f"questions ('top N devices by X') use netbox_aggregate_by_device. "
                f"For arbitrary-depth projection use netbox_query (raw GraphQL)."
            )

        next_steps = _compute_next_steps(object_type, results)
        if next_steps:
            out["next_steps"] = next_steps

        return out

    def get_all(
        self,
        *,
        object_type: str,
        filters: dict[str, Any],
        select: list[str] | None = None,
        max_records: int = 10_000,
        ordering: str | list[str] | None = None,
    ) -> dict[str, Any]:
        if max_records > ABSOLUTE_CEILING:
            raise ValueError(
                f"max_records={max_records} exceeds absolute ceiling {ABSOLUTE_CEILING}."
            )

        validate_object_type(object_type)
        endpoint = resolve_rest_endpoint(object_type)
        fields = _select_to_rest_fields(select)
        ordering_param = _ordering_to_rest_param(ordering)

        # First page also carries the authoritative count. If over cap,
        # we bail before fetching additional pages.
        first_params: dict[str, Any] = filters_to_rest_params(filters)
        first_params["limit"] = PAGE_SIZE
        first_params["offset"] = 0
        if fields is not None:
            first_params["fields"] = fields
        if ordering_param is not None:
            first_params["ordering"] = ordering_param

        first = self._rest.get(endpoint, params=first_params)
        total_count = int(first.get("count") or 0)
        if total_count > max_records:
            raise CapExceededError(total_count=total_count, current_max=max_records)

        accumulated: list[dict[str, Any]] = list(first.get("results") or [])

        offset = PAGE_SIZE
        while offset < total_count:
            page_params: dict[str, Any] = filters_to_rest_params(filters)
            page_params["limit"] = PAGE_SIZE
            page_params["offset"] = offset
            if fields is not None:
                page_params["fields"] = fields
            if ordering_param is not None:
                page_params["ordering"] = ordering_param
            page = self._rest.get(endpoint, params=page_params)
            page_results = page.get("results") or []
            accumulated.extend(page_results)
            if not page_results:
                break  # defensive: server reports more but returned none
            offset += PAGE_SIZE

        return {
            "results": accumulated,
            "total_count": total_count,
            "has_more": False,
            "suggested_next": compute_suggested_filters({object_type: accumulated}),
        }
