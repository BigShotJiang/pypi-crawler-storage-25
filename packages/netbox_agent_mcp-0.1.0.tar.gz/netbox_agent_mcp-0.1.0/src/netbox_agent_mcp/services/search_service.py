"""Text search fan-out via REST, plus suggested_filters computation."""

import logging
from typing import Any

from netbox_agent_mcp.clients.rest import RestClient
from netbox_agent_mcp.schema.object_types import (
    resolve_rest_endpoint,
    validate_object_type,
)
from netbox_agent_mcp.schema.suggested_filters import compute_suggested_filters

logger = logging.getLogger(__name__)


DEFAULT_SEARCH_TYPES: list[str] = [
    "dcim.device",
    "dcim.site",
    "dcim.rack",
    "dcim.interface",
    "ipam.ipaddress",
    "ipam.prefix",
    "ipam.vlan",
    "circuits.circuit",
    "virtualization.virtualmachine",
]

DEFAULT_LIMIT = 25


class SearchService:
    def __init__(self, rest: RestClient) -> None:
        self._rest = rest

    def search(
        self,
        *,
        query: str,
        object_types: list[str] | None = None,
        limit: int = DEFAULT_LIMIT,
    ) -> dict[str, Any]:
        types = object_types if object_types is not None else DEFAULT_SEARCH_TYPES
        for t in types:
            validate_object_type(t)

        matches: dict[str, list[dict[str, Any]]] = {t: [] for t in types}
        match_counts: dict[str, dict[str, Any]] = {}

        for object_type in types:
            endpoint = resolve_rest_endpoint(object_type)
            try:
                response = self._rest.get(endpoint, params={"q": query, "limit": limit})
            except Exception as exc:
                logger.warning("search failed for %s: %s", object_type, exc)
                match_counts[object_type] = {
                    "total": None,
                    "returned": 0,
                    "truncated": False,
                    "error": str(exc),
                }
                continue

            results = response.get("results", [])
            total = response.get("count")
            total_int = int(total) if total is not None else len(results)
            matches[object_type] = results
            match_counts[object_type] = {
                "total": total_int,
                "returned": len(results),
                "truncated": total_int > len(results),
            }

        return {
            "matches": matches,
            "match_counts": match_counts,
            "suggested_filters": compute_suggested_filters(matches),
        }
