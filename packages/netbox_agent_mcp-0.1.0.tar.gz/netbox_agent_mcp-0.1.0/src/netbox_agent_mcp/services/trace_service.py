"""Cable path tracing via NetBox REST /trace/ custom action."""

from typing import Any

from netbox_agent_mcp.clients.rest import RestClient

VALID_ENDPOINT_TYPES: set[str] = {
    "interfaces",
    "console-ports",
    "console-server-ports",
    "power-ports",
    "power-outlets",
    "power-feeds",
}


class TraceService:
    def __init__(self, rest: RestClient) -> None:
        self._rest = rest

    def trace(self, endpoint_type: str, endpoint_id: int) -> dict[str, Any]:
        if endpoint_type not in VALID_ENDPOINT_TYPES:
            valid = ", ".join(sorted(VALID_ENDPOINT_TYPES))
            raise ValueError(f"Invalid endpoint_type '{endpoint_type}'. Valid: {valid}")
        path = f"dcim/{endpoint_type}/{endpoint_id}/trace"
        segments = self._rest.get(path)
        if not isinstance(segments, list):
            segments = []

        next_steps: list[str] = []
        if not segments:
            next_steps.append(
                f"Empty trace does NOT mean 'no data' — it usually means the "
                f"interface isn't cabled in NetBox (management/OOB ports often "
                f"aren't). Verify with "
                f"`netbox_get('dcim.{endpoint_type.rstrip('s')}', "
                f"filters={{'id': {endpoint_id}}}, select=['name', 'cable'])`. "
                f"If this is a management interface, call "
                f"`netbox_device_profile(device_id=<device>)` — its `management` "
                f"field has the IP directly without a cable trace."
            )

        return {
            "segments": segments,
            "segment_count": len(segments),
            "next_steps": next_steps,
        }
