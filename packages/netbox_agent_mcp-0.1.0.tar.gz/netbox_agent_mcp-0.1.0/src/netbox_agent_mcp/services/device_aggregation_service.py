"""Server-side aggregation for 'top N devices by X' queries.

Rationale: for questions like "top 10 devices by VPN tunnel count" the
structural answer requires scanning 1000s of junction rows (vpn.tunneltermination,
dcim.cabletermination, etc.). Shipping all those rows to the agent so it can
aggregate client-side is:

  1. wasteful (agent only needs the final top N),
  2. unreliable (MCP transport and model context windows truncate large
     payloads, leaving the agent to aggregate from a partial sample and
     report wrong counts).

This service pages through the junction (or direct) endpoint server-side with
a cheap projection, counts in-process, and returns only the top N device
entries. Per-page requests use ``?fields=<single_top_level>`` so each row is
small (~200-300 bytes) and aggregation is fast even for 10k-row scans.
"""

from typing import Any

from netbox_agent_mcp.clients.rest import RestClient
from netbox_agent_mcp.schema.filter_builder import filters_to_rest_params

PAGE_SIZE = 500
DEFAULT_MAX_SCAN = 10_000


# Each relation maps to:
#  - REST endpoint
#  - intrinsic filters (e.g., termination_type=dcim.interface) always applied
#  - projection field (single top-level name passed to ?fields=)
#  - device_path: how to descend to the device dict within a row
_RELATIONS: dict[str, dict[str, Any]] = {
    "tunnel_terminations": {
        "endpoint": "vpn/tunnel-terminations",
        "intrinsic_filters": {"termination_type": "dcim.interface"},
        "projection": "termination",
        "device_path": ("termination", "device"),
    },
    "cable_terminations": {
        "endpoint": "dcim/cable-terminations",
        "intrinsic_filters": {"termination_type": "dcim.interface"},
        "projection": "termination",
        "device_path": ("termination", "device"),
    },
    "interfaces": {
        "endpoint": "dcim/interfaces",
        "intrinsic_filters": {},
        "projection": "device",
        "device_path": ("device",),
    },
    "inventory_items": {
        "endpoint": "dcim/inventory-items",
        "intrinsic_filters": {},
        "projection": "device",
        "device_path": ("device",),
    },
    "ip_addresses": {
        # NetBox's ip-addresses filter supports `assigned_to_interface=true`
        # to restrict to addresses bound to an interface; we then pull the
        # assigned_object (which has device nested at brief level).
        "endpoint": "ipam/ip-addresses",
        "intrinsic_filters": {"assigned_to_interface": "true"},
        "projection": "assigned_object",
        "device_path": ("assigned_object", "device"),
    },
}


def _descend(row: dict[str, Any], path: tuple[str, ...]) -> dict[str, Any] | None:
    cur: Any = row
    for key in path:
        if not isinstance(cur, dict):
            return None
        cur = cur.get(key)
    return cur if isinstance(cur, dict) else None


class DeviceAggregationService:
    def __init__(self, rest: RestClient) -> None:
        self._rest = rest

    def aggregate_by_device(
        self,
        relation: str,
        top_n: int = 10,
        filters: dict[str, Any] | None = None,
        max_scan: int = DEFAULT_MAX_SCAN,
    ) -> dict[str, Any]:
        if relation not in _RELATIONS:
            valid = ", ".join(sorted(_RELATIONS.keys()))
            raise ValueError(f"Unknown relation '{relation}'. Valid: {valid}")
        if top_n < 0:
            raise ValueError("top_n must be >= 0 (0 = return all devices)")
        if max_scan < 1:
            raise ValueError("max_scan must be >= 1")

        spec = _RELATIONS[relation]
        endpoint: str = spec["endpoint"]
        projection: str = spec["projection"]
        device_path: tuple[str, ...] = spec["device_path"]

        # Merge caller filters on top of intrinsic filters (caller wins).
        merged_filters: dict[str, Any] = {**spec["intrinsic_filters"]}
        if filters:
            merged_filters.update(filters_to_rest_params(filters))

        counts: dict[int, dict[str, Any]] = {}
        total_scanned = 0
        truncated = False
        offset = 0

        while True:
            if total_scanned >= max_scan:
                truncated = True
                break

            page_limit = min(PAGE_SIZE, max_scan - total_scanned)
            params: dict[str, Any] = dict(merged_filters)
            params["fields"] = projection
            params["limit"] = page_limit
            params["offset"] = offset
            try:
                response = self._rest.get(endpoint, params=params)
            except Exception as exc:
                return {
                    "relation": relation,
                    "total_items_scanned": total_scanned,
                    "truncated": False,
                    "error": str(exc),
                    "unique_devices": 0,
                    "top_devices": [],
                }

            rows = response.get("results") or []
            if not rows:
                break

            for row in rows:
                device = _descend(row, device_path)
                if not device or device.get("id") is None:
                    continue
                did = device["id"]
                entry = counts.get(did)
                if entry is None:
                    counts[did] = {
                        "device": {
                            "id": did,
                            "name": device.get("name") or device.get("display"),
                        },
                        "count": 1,
                    }
                else:
                    entry["count"] += 1

            total_scanned += len(rows)
            if response.get("next") is None:
                break
            offset += page_limit

        ranked = sorted(counts.values(), key=lambda r: -r["count"])
        top = ranked[:top_n] if top_n > 0 else ranked

        next_steps: list[str] = []
        if top:
            top_ids = [
                t["device"].get("id")
                for t in top
                if isinstance(t.get("device"), dict) and t["device"].get("id") is not None
            ]
            if top_ids:
                # Enumerate EVERY expected call, not just one example. This
                # turns the hint from a pattern the agent can gloss over into
                # a concrete checklist.
                call_list = "\n  ".join(f"- netbox_device_profile(device_id={i})" for i in top_ids)
                next_steps.append(
                    f"Top devices here have only {{id, name, count}}. Before "
                    f"presenting this to the user, make ALL of the following "
                    f"{len(top_ids)} enrichment calls (one per top device — "
                    f"the `management` field is populated unconditionally):\n  "
                    f"{call_list}\n"
                    f"Do not present a {len(top_ids)}-row table unless all "
                    f"{len(top_ids)} calls have been made. Footnote-style "
                    f"disclaimers ('top 3 verified, rest from aggregate') are "
                    f"NOT an acceptable substitute for completing the loop."
                )

        return {
            "relation": relation,
            "total_items_scanned": total_scanned,
            "truncated": truncated,
            "unique_devices": len(counts),
            "top_devices": top,
            "next_steps": next_steps,
        }
