"""Fan-out lookup for every place a given IP address is referenced in NetBox.

NetBox stores IP-to-device relationships in multiple places:

1. **Structured:** ``ipam.ipaddress.assigned_object`` (polymorphic FK to
   ``dcim.interface``, ``virtualization.vminterface``, or ``ipam.fhrpgroup``).
   This is the "correct" place and the first thing to check.
2. **Free-text:** ``vpn.tunnel.description``, ``dcim.interface.description``,
   ``ipam.prefix.description``. Common when importers (e.g., Palo Alto →
   NetBox tunnel imports) write peer IPs into descriptions rather than
   structured fields.

``IPReferenceService`` queries all of these in parallel and returns a single
consolidated view so agents don't have to orchestrate four searches.
"""

from typing import Any

from netbox_agent_mcp.clients.rest import RestClient


def _strip_cidr(ip: str) -> str:
    """Return the host part of an IP, without any /mask suffix."""
    return ip.split("/", 1)[0]


class IPReferenceService:
    def __init__(self, rest: RestClient) -> None:
        self._rest = rest

    def find_references(self, ip: str) -> dict[str, Any]:
        host = _strip_cidr(ip)

        ipam_record = self._ipam_lookup(ip)
        tunnel_refs = self._text_search("vpn/tunnels", host)
        interface_refs = self._text_search("dcim/interfaces", host)
        prefix_refs = self._text_search("ipam/prefixes", host)

        text_reference_count = len(tunnel_refs) + len(interface_refs) + len(prefix_refs)
        ipam_assigned = bool(ipam_record and ipam_record.get("assigned_object_type"))

        summary: dict[str, Any] = {
            "ipam_record_exists": ipam_record is not None,
            "ipam_assigned_to_object": ipam_assigned,
            "text_reference_count": text_reference_count,
        }
        summary["hint"] = self._hint(ipam_record, ipam_assigned, text_reference_count)

        return {
            "query": host,
            "ipam_record": ipam_record,
            "text_references": {
                "vpn.tunnel": tunnel_refs,
                "dcim.interface": interface_refs,
                "ipam.prefix": prefix_refs,
            },
            "summary": summary,
        }

    def _ipam_lookup(self, ip: str) -> dict[str, Any] | None:
        """Look up the IP in ipam/ip-addresses. Try the input form first,
        then fall back to the bare host if the user included a /mask that
        doesn't exist as a stored record."""
        try:
            response = self._rest.get("ipam/ip-addresses", params={"address": ip, "limit": 1})
        except Exception:
            return None
        results = response.get("results") or []
        if results:
            return self._distill_ipam(results[0])

        host = _strip_cidr(ip)
        if host != ip:
            try:
                response = self._rest.get("ipam/ip-addresses", params={"address": host, "limit": 1})
            except Exception:
                return None
            results = response.get("results") or []
            if results:
                return self._distill_ipam(results[0])

        return None

    def _distill_ipam(self, ip_record: dict[str, Any]) -> dict[str, Any]:
        return {
            "id": ip_record.get("id"),
            "address": ip_record.get("address"),
            "display": ip_record.get("display"),
            "status": (ip_record.get("status") or {}).get("value"),
            "dns_name": ip_record.get("dns_name"),
            "description": ip_record.get("description"),
            "vrf": ip_record.get("vrf"),
            "tenant": ip_record.get("tenant"),
            "assigned_object_type": ip_record.get("assigned_object_type"),
            "assigned_object": ip_record.get("assigned_object"),
            "nat_inside": ip_record.get("nat_inside"),
            "nat_outside": ip_record.get("nat_outside"),
        }

    def _text_search(self, endpoint: str, host: str) -> list[dict[str, Any]]:
        """Search `description` fields with case-insensitive contains."""
        try:
            response = self._rest.get(
                endpoint,
                params={"description__ic": host, "limit": 50},
            )
        except Exception:
            return []
        return [self._distill_ref(r) for r in (response.get("results") or [])]

    def _distill_ref(self, record: dict[str, Any]) -> dict[str, Any]:
        """Slim a NetBox record down to the fields an agent needs to identify
        the owning device without flooding tokens."""
        return {
            "id": record.get("id"),
            "display": record.get("display"),
            "name": record.get("name"),
            "description": record.get("description"),
            "device": (record.get("device") or {}).get("name")
            if isinstance(record.get("device"), dict)
            else None,
            "url": record.get("url"),
        }

    def _hint(
        self,
        ipam_record: dict[str, Any] | None,
        ipam_assigned: bool,
        text_reference_count: int,
    ) -> str:
        if ipam_assigned:
            return (
                "IPAM record is structurally assigned — follow "
                "ipam_record.assigned_object to the owning interface/VM/FHRP group."
            )
        if ipam_record and text_reference_count > 0:
            return (
                "IPAM record exists but has no assigned_object. Text references "
                "were found — inspect their descriptions/names to identify the "
                "owning device (e.g., tunnel names often encode the local device)."
            )
        if ipam_record:
            return (
                "IPAM record exists but has no assigned_object and no text "
                "references were found. The IP is registered in NetBox but not "
                "tied to any device."
            )
        if text_reference_count > 0:
            return (
                "No IPAM record for this address, but text references were found "
                "(likely in tunnel/interface descriptions). Inspect those to find "
                "the referencing device(s)."
            )
        return "No references to this IP found anywhere in NetBox."
