"""REST-backed specialty tools: cable tracing and capacity queries."""

from typing import Annotated, Any

from pydantic import Field

from netbox_agent_mcp.services.registry import get_services


def netbox_trace_path(endpoint_type: str, endpoint_id: int) -> Any:
    """Trace the full cable path from a device endpoint.

    Returns every segment from the given port/interface through every cable,
    through-port, and patch to the far endpoint.

    Args:
        endpoint_type: One of ``"interfaces"``, ``"console-ports"``,
            ``"console-server-ports"``, ``"power-ports"``, ``"power-outlets"``,
            ``"power-feeds"``.
        endpoint_id: The endpoint's numeric ID.

    Returns:
        List of path segments (NetBox's native trace format).
    """
    svc = get_services()
    return svc.trace.trace(endpoint_type, endpoint_id)


def netbox_get_available(
    resource_type: str,
    parent_id: int,
    count: Annotated[int, Field(ge=1, le=1000)] = 1,
) -> Any:
    """Fetch free capacity from NetBox (IPs, prefixes, VLANs, ASNs).

    Args:
        resource_type: One of:

            - ``"prefix.available-ips"`` — IPs free within a prefix
            - ``"prefix.available-prefixes"`` — sub-prefixes free within a prefix
            - ``"ip-range.available-ips"`` — IPs free within an IP range
            - ``"vlan-group.available-vlans"`` — VLAN IDs free within a group
            - ``"asn-range.available-asns"`` — ASNs free within a range
        parent_id: Numeric ID of the parent object.
        count: How many items to return (1-1000, default 1).

    Returns:
        List of free resources; shape depends on resource_type.
    """
    svc = get_services()
    return svc.availability.get_available(resource_type, parent_id=parent_id, count=count)


def netbox_find_ip_references(ip: str) -> dict[str, Any]:
    """Fan-out lookup for every place an IP address is referenced in NetBox.

    Use when you want to answer "what device owns this IP?" or "where is this
    IP referenced?" and a straight ``netbox_get("ipam.ipaddress", ...)`` lookup
    didn't find a structural assignment.

    Searches:
    1. **``ipam.ipaddress``** — the canonical record (checks for ``assigned_object``,
       i.e. the interface/VM interface/FHRP group the IP is structurally bound to).
    2. **Free-text in descriptions** — ``vpn.tunnel.description``,
       ``dcim.interface.description``, ``ipam.prefix.description``. Catches cases
       where importers (e.g., Palo Alto → NetBox) put peer IPs in description
       fields instead of structured references.

    Args:
        ip: IP address. With or without CIDR suffix (``"10.0.0.1"`` or
            ``"10.0.0.1/32"``). The IPAM lookup tries both; text searches use
            the bare host so descriptions containing just the dotted form match.

    Returns::

        {
          "query": "198.51.100.1",
          "ipam_record": {
            "id": 543, "address": "198.51.100.1/32",
            "assigned_object_type": null,  # "dcim.interface" if structurally bound
            "assigned_object": null,        # nested interface/vminterface/fhrpgroup
            ...
          },
          "text_references": {
            "vpn.tunnel":      [{"id": 77, "name": "tunnel-demo :: router-a :: 198.51.100.1",
                                 "description": "Peer IP: 198.51.100.1 ...", "url": ...}],
            "dcim.interface":  [...],
            "ipam.prefix":     [...]
          },
          "summary": {
            "ipam_record_exists": true,
            "ipam_assigned_to_object": false,
            "text_reference_count": 1,
            "hint": "IPAM record exists but has no assigned_object. Text
                     references were found — inspect their descriptions/names
                     to identify the owning device (e.g., tunnel names often
                     encode the local device)."
          }
        }

    If ``summary.ipam_assigned_to_object`` is True, follow
    ``ipam_record.assigned_object`` for the authoritative device. Otherwise
    inspect the ``text_references`` entries — tunnel names commonly encode the
    local device (e.g. ``"tunnel-demo :: router-a :: 198.51.100.1"``).
    """
    svc = get_services()
    return svc.ip_reference.find_references(ip)


def netbox_device_profile(
    device_id: int,
    include: list[str] | None = None,
    max_per_category: Annotated[int, Field(ge=0, le=1000)] = 100,
) -> dict[str, Any]:
    """Composite one-shot view of a device: record + related objects + hints.

    NetBox's device record doesn't include interfaces, IPs, tunnel terminations,
    cables, inventory items, etc. inline — those are many-to-one and require
    separate queries. This tool fans out to ~5 NetBox endpoints and returns
    one consolidated payload so agents don't orchestrate the dance manually.

    Args:
        device_id: Numeric NetBox device ID.
        include: Subset of categories to include. Default = ``["interfaces",
            "ip_addresses", "tunnel_terminations", "inventory_items"]``.
            Valid values:

            - ``"interfaces"``          (dcim.interface)
            - ``"ip_addresses"``        (ipam.ipaddress via the device)
            - ``"tunnel_terminations"`` (vpn.tunneltermination via the device's interfaces)
            - ``"cable_terminations"``  (dcim.cabletermination via the device's interfaces)
            - ``"inventory_items"``     (dcim.inventoryitem)
            - ``"console_ports"``       (dcim.consoleport)
            - ``"power_ports"``         (dcim.powerport)
            - ``"module_bays"``         (dcim.modulebay)

        max_per_category: Cap on items returned per category (default 100, max 1000).
            **Pass ``0`` for summary mode** — returns only counts + hints per
            category, no item bodies. Useful for getting an overview of a
            device with hundreds of interfaces without token-busting.

    Returns::

        {
          "device": {...full device record from NetBox...},
          "counts": {"interfaces": 173, "ip_addresses": 42,
                     "tunnel_terminations": 42, "inventory_items": 0},
          "sections": {
            "interfaces":          {"total": 173, "returned": 100, "truncated": true,
                                    "items": [{...brief interface...}, ...]},
            "ip_addresses":        {...},
            "tunnel_terminations": {...},
            "inventory_items":     {...}
          },
          "hints": [
            "Interface sample (first 100/173) dominant types: 100 virtual",
            "~172 interfaces are named 'tunnel.*' but only 42 have structural
             vpn.tunneltermination records — 130 'orphaned' tunnel interfaces
             (imported from firewall config but never linked to a vpn.tunnel
             object)."
          ]
        }

    Related items are returned in NetBox ``?brief=1`` shape (id, url, display,
    name + per-type essentials) to keep the payload manageable. Use
    ``netbox_get`` for full objects if you need more.
    """
    svc = get_services()
    return svc.device_profile.profile(
        device_id=device_id,
        include=include,
        max_per_category=max_per_category,
    )


def netbox_aggregate_by_device(
    relation: str,
    top_n: Annotated[int, Field(ge=0, le=1000)] = 10,
    filters: dict[str, Any] | None = None,
    max_scan: Annotated[int, Field(ge=100, le=100_000)] = 10_000,
) -> dict[str, Any]:
    """Server-side 'top N devices by X' aggregation.

    Use this for questions like "top 10 devices by VPN tunnel count", "top 5
    devices by interface count", "top 20 devices by IP address count". The
    tool scans the underlying junction (or direct) endpoint server-side,
    aggregates counts in process, and returns ONLY the top N — never ships
    1000s of raw rows across the MCP wire.

    Why not just use ``netbox_get_all`` and count client-side? Because for
    large NetBoxes the raw junction set can be 1000s of rows. Shipping that
    through the MCP transport risks truncation, blows your context window,
    and wastes tokens when you only need 10 aggregated counts.

    Args:
        relation: Which relationship to aggregate. One of:

            - ``"tunnel_terminations"``  — vpn.tunneltermination via dcim.interface.device
              (answers 'top N devices by VPN tunnel count')
            - ``"cable_terminations"``   — dcim.cabletermination via dcim.interface.device
              (answers 'top N devices by cable count')
            - ``"interfaces"``           — dcim.interface by device_id
              (answers 'top N devices by interface count')
            - ``"inventory_items"``      — dcim.inventoryitem by device_id
              (answers 'top N devices by inventory item count')
            - ``"ip_addresses"``         — ipam.ipaddress via interface.device
              (only addresses structurally assigned to an interface)

        top_n: How many device entries to return (default 10). Pass 0 to
            return all devices found.
        filters: Optional filters applied to the underlying endpoint BEFORE
            aggregation. Uses the same NetBox REST filter grammar as
            ``netbox_get`` (e.g. ``{"role_id": 3}`` to restrict to firewalls,
            or ``{"site_id__in": [8, 17]}`` to scope by site).
        max_scan: Safety cap on how many junction rows to scan (default 10000,
            max 100000). If exceeded, ``truncated: true`` in the response —
            narrow your filters.

    Returns::

        {
          "relation": "tunnel_terminations",
          "total_items_scanned": 3147,
          "truncated": false,
          "unique_devices": 87,
          "top_devices": [
            {"device": {"id": 5, "name": "router-b"}, "count": 42},
            {"device": {"id": 8, "name": "router-c"}, "count": 37},
            ...
          ]
        }
    """
    svc = get_services()
    return svc.device_aggregation.aggregate_by_device(
        relation=relation,
        top_n=top_n,
        filters=filters,
        max_scan=max_scan,
    )
