"""Query tool surface: netbox_query (raw), netbox_get, netbox_get_all."""

from typing import Annotated, Any

from pydantic import Field

from netbox_agent_mcp.services.registry import get_services


def netbox_query(
    graphql: str,
    variables: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Execute a raw GraphQL query against NetBox.

    The power-user escape hatch. Use when you need fragments, deep hydration,
    cross-entity joins, or filters not expressible via ``netbox_get``.

    Args:
        graphql: Full GraphQL query document. Example::

            query {
              device_list(filters: {site_id: {in_list: [8, 12]}}, limit: 5) {
                id name site { name region { name } }
              }
            }

        variables: Optional variables dict for parameterized queries.

    Returns:
        ``{"data": {...}}`` — the ``data`` field of the GraphQL response.
        GraphQL errors are raised as ``SchemaIntrospectionError``.

    Use ``netbox_inspect_type`` first if you are unsure about field names.
    """
    svc = get_services()
    data = svc.graphql.query(graphql, variables=variables)
    return {"data": data}


def netbox_get(
    object_type: str,
    filters: dict[str, Any],
    select: list[str] | None = None,
    limit: Annotated[int, Field(ge=1, le=100)] = 10,
    offset: Annotated[int, Field(ge=0)] = 0,
    ordering: str | list[str] | None = None,
) -> dict[str, Any]:
    """List NetBox objects by type with filters and field selection.

    Backed by GraphQL. Supports arbitrary-depth relation selection via dotted
    paths in ``select``. Returns a structured response with a ``suggested_next``
    block that agents can paste directly into follow-up calls.

    Args:
        object_type: Canonical type identifier (e.g. ``"dcim.device"``,
            ``"ipam.prefix"``). Call ``netbox_inspect_type`` for the full list.
        filters: REST-style filter dict using NetBox's familiar grammar:

            - Direct match: ``{"site_id": 8, "status": "active"}``
            - Lookups:      ``{"name__ic": "switch", "vid__gte": 100}``
            - IN list:      ``{"site_id__in": [1, 2, 3]}``

            Multi-hop filters like ``{"device__site_id": 1}`` are rejected —
            do a two-step query instead (first look up the parent IDs, then
            filter children by those IDs).
        select: Fields to return, as dotted paths. Example:

            ``["name", "site.name", "site.region.name", "primary_ip4.address"]``

            Omit for a minimal safe default (``id``, ``display``). ``id`` is
            always included — agents need it for ``suggested_next`` follow-ups.
            ``display`` is a universal human-readable field present on every
            NetBox type (``name`` is not — IP addresses use ``address``,
            prefixes use ``prefix``).
        limit: Max results this page (1-100, default 10).
        offset: Skip this many results (default 0).
        ordering: Sort order. NetBox REST ordering syntax:

            - Ascending: ``"name"``
            - Descending: ``"-name"``
            - Multiple fields (priority order): ``["-device_count", "name"]``
              or ``"-device_count,name"``

            **Powerful with pre-computed counts.** NetBox parent objects
            expose orderable count annotations: ``dcim.site.device_count``,
            ``dcim.site.rack_count``, ``dcim.site.prefix_count``,
            ``dcim.site.vlan_count``, ``dcim.site.circuit_count``,
            ``dcim.site.virtualmachine_count``, ``dcim.rack.u_consumed``,
            ``dcim.device.interface_count``, etc. For "top N sites by
            device count" use ``ordering="-device_count"`` + ``limit=10``
            — no separate aggregation tool needed.

    Returns:
        ``{"results": [...], "total_count": N, "has_more": bool,
           "suggested_next": {...}}``
    """
    svc = get_services()
    return svc.query.get(
        object_type=object_type,
        filters=filters,
        select=select,
        limit=limit,
        offset=offset,
        ordering=ordering,
    )


def netbox_get_all(
    object_type: str,
    filters: dict[str, Any],
    select: list[str] | None = None,
    max_records: Annotated[int, Field(ge=1, le=100_000)] = 10_000,
    ordering: str | list[str] | None = None,
) -> dict[str, Any]:
    """Fetch ALL matching records, auto-paginated. Hard-capped. Fails loud.

    Use for exhaustive queries where you need the complete dataset. The tool
    paginates internally so you don't track offsets. If the total exceeds
    ``max_records``, the call RAISES — no partial results, ever.

    Args:
        object_type: Canonical type identifier.
        filters: Same grammar as ``netbox_get``.
        select: Same as ``netbox_get``.
        max_records: Ceiling for this call (default 10000, max 100000).
        ordering: Same syntax as ``netbox_get``. Ordering is preserved across
            paginated sub-requests so the assembled list is fully sorted.

    Returns:
        ``{"results": [...full list...], "total_count": N, "has_more": False,
           "suggested_next": {...}}``
    """
    svc = get_services()
    return svc.query.get_all(
        object_type=object_type,
        filters=filters,
        select=select,
        max_records=max_records,
        ordering=ordering,
    )
