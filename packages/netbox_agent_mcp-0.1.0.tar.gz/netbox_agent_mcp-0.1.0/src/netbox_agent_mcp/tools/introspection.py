"""Live GraphQL schema introspection for NetBox object types."""

from typing import Any

from netbox_agent_mcp.services.registry import get_services


def netbox_inspect_type(object_type: str) -> dict[str, Any]:
    """Return the live schema for a NetBox object type.

    Queries NetBox's GraphQL introspection endpoint for the type's full field
    list with types, nested relations, filter fields, and enum values. Call
    this BEFORE constructing filters or ``select`` paths against unfamiliar
    types — eliminates guessing.

    Args:
        object_type: Canonical type identifier (e.g. ``"dcim.device"``).

    Returns:
        Introspection dict with ``name``, ``description``, and ``fields`` list.
        Results are cached in-process keyed by NetBox version.
    """
    svc = get_services()
    return svc.introspection.inspect_type(object_type)
