"""Global text search with suggested_filters."""

from typing import Annotated, Any

from pydantic import Field

from netbox_agent_mcp.services.registry import get_services


def netbox_search(
    query: str,
    object_types: list[str] | None = None,
    limit: Annotated[int, Field(ge=1, le=100)] = 25,
) -> dict[str, Any]:
    """Free-text search across NetBox object types, with pre-built follow-up filters.

    Searches names, descriptions, IPs, serials, asset tags, and other indexed
    fields via NetBox's REST ``?q=`` parameter. The response includes
    ``suggested_filters`` — ready-to-use filter dicts for common follow-up
    ``netbox_get`` calls — and ``match_counts`` — per-type total/returned/truncated
    counts so you can detect when the limit cut off results.

    Args:
        query: Search term (e.g. ``"London"``, ``"192.168.1.1"``, ``"SN123456"``).
            Note: ``?q=`` searches NetBox's indexed fields (name, description,
            serial, asset_tag, etc.). For strict name-only match use
            ``netbox_get(..., filters={"name__ic": ...})``.
        object_types: Limit search to these types. Default spans common
            operational types (device, site, rack, interface, ipaddress,
            prefix, vlan, circuit, virtualmachine).
        limit: Max matches per type (1-100, default 25). **If
            ``match_counts[type]["truncated"]`` is True, raise the limit and
            retry before drawing conclusions — the default truncates silently
            on the NetBox side otherwise.**

    Returns:
        ::

            {
              "matches":        {"type": [...objects...]},
              "match_counts":   {"type": {"total": N, "returned": M,
                                          "truncated": bool}},
              "suggested_filters": {...ready-to-paste blocks...}
            }

        ``suggested_filters`` is a **base** filter. If you have other
        constraints (e.g. ``role_id=3`` for firewalls), MERGE them in before
        calling ``netbox_get``. Example:

        Search returns ``{"devices_at_these_sites": {"object_type": "dcim.device",
        "filters": {"site_id__in": [8, 12]}}}``. If you also want firewalls only,
        the follow-up call is
        ``netbox_get("dcim.device", filters={"site_id__in": [8, 12], "role_id": 3})``.
    """
    svc = get_services()
    return svc.search.search(query=query, object_types=object_types, limit=limit)
