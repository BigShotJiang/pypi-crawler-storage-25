"""FastMCP server for NetBox Agent MCP."""

import argparse
import logging
import sys
from typing import Any

import httpx
from fastmcp import FastMCP

from netbox_agent_mcp.clients.base import build_http_client
from netbox_agent_mcp.clients.graphql import GraphQLClient
from netbox_agent_mcp.clients.rest import RestClient
from netbox_agent_mcp.config import Settings, configure_logging
from netbox_agent_mcp.services.availability_service import AvailabilityService
from netbox_agent_mcp.services.device_aggregation_service import DeviceAggregationService
from netbox_agent_mcp.services.device_profile_service import DeviceProfileService
from netbox_agent_mcp.services.introspection_service import IntrospectionService
from netbox_agent_mcp.services.ip_reference_service import IPReferenceService
from netbox_agent_mcp.services.query_service import QueryService
from netbox_agent_mcp.services.registry import ServiceRegistry, set_services
from netbox_agent_mcp.services.search_service import SearchService
from netbox_agent_mcp.services.trace_service import TraceService
from netbox_agent_mcp.tools.introspection import netbox_inspect_type
from netbox_agent_mcp.tools.query import netbox_get, netbox_get_all, netbox_query
from netbox_agent_mcp.tools.search import netbox_search
from netbox_agent_mcp.tools.specialty import (
    netbox_aggregate_by_device,
    netbox_device_profile,
    netbox_find_ip_references,
    netbox_get_available,
    netbox_trace_path,
)

mcp = FastMCP("NetBox Agent")

mcp.tool(netbox_query)
mcp.tool(netbox_get)
mcp.tool(netbox_get_all)
mcp.tool(netbox_search)
mcp.tool(netbox_inspect_type)
mcp.tool(netbox_trace_path)
mcp.tool(netbox_get_available)
mcp.tool(netbox_find_ip_references)
mcp.tool(netbox_device_profile)
mcp.tool(netbox_aggregate_by_device)


def build_services(settings: Settings) -> tuple[ServiceRegistry, httpx.Client]:
    """Construct the shared httpx client and wire all services.

    The caller owns the returned ``httpx.Client`` and is responsible for
    closing it on shutdown (e.g., via ``try/finally`` in ``main``).
    """
    http = build_http_client(
        url=str(settings.netbox_url),
        token=settings.netbox_token.get_secret_value(),
        verify_ssl=settings.verify_ssl,
    )
    gql = GraphQLClient(http)
    rest = RestClient(http)

    registry = ServiceRegistry(
        query=QueryService(rest),
        search=SearchService(rest),
        introspection=IntrospectionService(gql, rest),
        trace=TraceService(rest),
        availability=AvailabilityService(rest),
        ip_reference=IPReferenceService(rest),
        device_profile=DeviceProfileService(rest),
        device_aggregation=DeviceAggregationService(rest),
        graphql=gql,
    )
    return registry, http


def parse_cli_args() -> dict[str, Any]:
    parser = argparse.ArgumentParser(
        description="NetBox Agent MCP - agentic Model Context Protocol server for NetBox",
    )
    parser.add_argument("--netbox-url")
    parser.add_argument("--netbox-token")
    parser.add_argument("--transport", choices=["stdio", "http"])
    parser.add_argument("--host")
    parser.add_argument("--port", type=int)
    parser.add_argument(
        "--log-level",
        choices=["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"],
    )

    ssl_grp = parser.add_mutually_exclusive_group()
    ssl_grp.add_argument("--verify-ssl", dest="verify_ssl", action="store_true", default=None)
    ssl_grp.add_argument("--no-verify-ssl", dest="verify_ssl", action="store_false")

    args = parser.parse_args()
    overlay: dict[str, Any] = {}
    for name in (
        "netbox_url",
        "netbox_token",
        "transport",
        "host",
        "port",
        "log_level",
        "verify_ssl",
    ):
        value = getattr(args, name)
        if value is not None:
            overlay[name] = value
    return overlay


def main() -> None:
    overlay = parse_cli_args()
    try:
        settings = Settings(**overlay)
    except Exception as exc:
        print(f"Configuration error: {exc}", file=sys.stderr)  # noqa: T201
        sys.exit(1)

    configure_logging(settings.log_level)
    logger = logging.getLogger(__name__)
    logger.info("Starting NetBox Agent MCP")
    logger.info("Effective config: %s", settings.get_effective_config_summary())

    try:
        registry, http = build_services(settings)
        set_services(registry)
    except Exception as exc:
        logger.error("Failed to initialize services: %s", exc)
        sys.exit(1)

    try:
        if settings.transport == "stdio":
            mcp.run(transport="stdio")
        else:
            mcp.run(transport="http", host=settings.host, port=settings.port)
    except Exception as exc:
        logger.error("Server failed: %s", exc)
        sys.exit(1)
    finally:
        http.close()


if __name__ == "__main__":
    main()
