"""NetBox Agent MCP — agentic Model Context Protocol server for NetBox."""

__version__ = "0.1.0"
