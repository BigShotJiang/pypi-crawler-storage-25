"""GraphQL client for NetBox's Strawberry endpoint at /graphql/."""

import logging
import time
from typing import Any

import httpx

from netbox_agent_mcp.exceptions import NetBoxAPIError, SchemaIntrospectionError

logger = logging.getLogger(__name__)


class GraphQLClient:
    def __init__(
        self,
        http: httpx.Client,
        *,
        max_retries: int = 3,
        backoff_base: float = 0.5,
    ) -> None:
        self._http = http
        self._max_retries = max_retries
        self._backoff_base = backoff_base

    def query(
        self,
        document: str,
        *,
        variables: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {"query": document}
        if variables is not None:
            body["variables"] = variables

        for attempt in range(self._max_retries + 1):
            try:
                response = self._http.post("/graphql/", json=body)
            except httpx.RequestError as exc:
                if attempt < self._max_retries:
                    self._sleep_backoff(attempt)
                    continue
                raise NetBoxAPIError(status=0, url="/graphql/", body=str(exc)) from exc

            if response.status_code >= 500:
                if attempt < self._max_retries:
                    self._sleep_backoff(attempt)
                    continue
                raise NetBoxAPIError(
                    status=response.status_code, url="/graphql/", body=response.text
                )

            if response.status_code >= 400:
                raise NetBoxAPIError(
                    status=response.status_code, url="/graphql/", body=response.text
                )

            payload = response.json()
            errors = payload.get("errors")
            if errors:
                messages = "; ".join(e.get("message", "(no message)") for e in errors)
                logger.debug("GraphQL errors for query %r: %s", document[:200], messages)
                raise SchemaIntrospectionError(f"GraphQL error: {messages}")
            return payload.get("data") or {}

        raise RuntimeError("unreachable: retry loop exited without return or raise")

    def _sleep_backoff(self, attempt: int) -> None:
        delay = self._backoff_base * (2**attempt)
        logger.debug("Retry after %.2fs (attempt %d)", delay, attempt + 1)
        time.sleep(delay)
