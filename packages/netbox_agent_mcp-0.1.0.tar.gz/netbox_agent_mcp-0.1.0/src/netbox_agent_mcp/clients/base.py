"""Shared httpx.Client factory for REST and GraphQL clients."""

import httpx


def build_http_client(url: str, token: str, verify_ssl: bool) -> httpx.Client:
    """Build a pre-configured httpx.Client with auth and JSON headers.

    The same client instance is shared by both the REST and GraphQL transport
    clients (one TLS handshake, pooled connections). Caller is responsible for
    closing via ``client.close()`` at shutdown.
    """
    auth_scheme = "Bearer" if token.startswith("nbt_") else "Token"
    return httpx.Client(
        base_url=url.rstrip("/"),
        verify=verify_ssl,
        timeout=httpx.Timeout(30.0, connect=10.0),
        headers={
            "Authorization": f"{auth_scheme} {token}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        },
    )
