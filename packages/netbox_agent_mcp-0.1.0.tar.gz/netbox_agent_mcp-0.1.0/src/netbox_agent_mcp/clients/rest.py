"""REST client for NetBox API endpoints that GraphQL does not cover."""

import logging
import time
from typing import Any

import httpx

from netbox_agent_mcp.exceptions import NetBoxAPIError

logger = logging.getLogger(__name__)


class RestClient:
    def __init__(
        self,
        http: httpx.Client,
        *,
        max_retries: int = 3,
        backoff_base: float = 0.5,
    ) -> None:
        self._http = http
        self._max_retries = max_retries
        self._backoff_base = backoff_base

    def get(
        self,
        endpoint: str,
        *,
        id: int | None = None,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        path = self._build_path(endpoint, id)
        return self._request("GET", path, params=params)

    def _build_path(self, endpoint: str, id: int | None) -> str:
        endpoint = endpoint.strip("/")
        if id is not None:
            return f"/api/{endpoint}/{id}/"
        return f"/api/{endpoint}/"

    def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json_body: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        for attempt in range(self._max_retries + 1):
            try:
                response = self._http.request(method, path, params=params, json=json_body)
            except httpx.RequestError as exc:
                if attempt < self._max_retries:
                    self._sleep_backoff(attempt)
                    continue
                raise NetBoxAPIError(status=0, url=path, body=str(exc)) from exc

            if response.status_code >= 500:
                if attempt < self._max_retries:
                    self._sleep_backoff(attempt)
                    continue
                raise NetBoxAPIError(status=response.status_code, url=path, body=response.text)

            if response.status_code >= 400:
                raise NetBoxAPIError(status=response.status_code, url=path, body=response.text)
            return response.json()

        raise RuntimeError("unreachable: retry loop exited without return or raise")

    def _sleep_backoff(self, attempt: int) -> None:
        delay = self._backoff_base * (2**attempt)
        logger.debug("Retry after %.2fs (attempt %d)", delay, attempt + 1)
        time.sleep(delay)
