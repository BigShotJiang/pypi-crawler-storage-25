"""Runtime configuration and logging."""

import logging
from typing import Literal

from pydantic import AliasChoices, Field, HttpUrl, SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict

LogLevel = Literal["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]
Transport = Literal["stdio", "http"]


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="",
        env_file=None,
        extra="ignore",
    )

    netbox_url: HttpUrl = Field(..., validation_alias=AliasChoices("netbox_url", "NETBOX_URL"))
    netbox_token: SecretStr = Field(
        ..., validation_alias=AliasChoices("netbox_token", "NETBOX_TOKEN")
    )
    verify_ssl: bool = Field(True, validation_alias=AliasChoices("verify_ssl", "NETBOX_VERIFY_SSL"))
    log_level: LogLevel = Field("INFO", validation_alias=AliasChoices("log_level", "LOG_LEVEL"))
    transport: Transport = Field("stdio", validation_alias=AliasChoices("transport", "TRANSPORT"))
    host: str = Field("127.0.0.1", validation_alias=AliasChoices("host", "HOST"))
    port: int = Field(8000, validation_alias=AliasChoices("port", "PORT"))
    max_records_ceiling: int = Field(
        100_000,
        validation_alias=AliasChoices("max_records_ceiling", "MAX_RECORDS_CEILING"),
    )

    def get_effective_config_summary(self) -> str:
        return (
            f"url={self.netbox_url} token=*** "
            f"verify_ssl={self.verify_ssl} log_level={self.log_level} "
            f"transport={self.transport}"
        )


def configure_logging(level: LogLevel) -> None:
    logging.basicConfig(
        level=getattr(logging, level),
        format="%(asctime)s %(name)s %(levelname)s %(message)s",
    )
    logging.getLogger("netbox_agent_mcp").setLevel(getattr(logging, level))
