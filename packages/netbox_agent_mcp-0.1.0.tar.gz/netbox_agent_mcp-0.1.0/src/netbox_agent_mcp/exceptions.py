"""Exception hierarchy.

All exceptions subclass ValueError so FastMCP serializes them uniformly into
MCP error responses. Each exception carries structured context fields that
agents can pattern-match on.
"""


class AgentMCPError(ValueError):
    """Base class for all netbox-agent-mcp exceptions."""


class UnknownObjectTypeError(AgentMCPError):
    """Raised when an agent passes an object_type not in the registry.

    Attributes:
        given: The string the agent supplied.
        valid: The full list of registered object type identifiers.
    """

    def __init__(self, given: str, valid: list[str]) -> None:
        self.given = given
        self.valid = valid
        valid_list = "\n".join(f"- {t}" for t in sorted(valid))
        super().__init__(f"Unknown object_type '{given}'. Valid types:\n{valid_list}")


class UnknownFieldError(AgentMCPError):
    """Raised when a select path references a field not on the object type.

    Attributes:
        object_type: The object type identifier the field was looked up against.
        path: The offending dotted path (e.g. ``"site.continent"``).
    """

    def __init__(self, object_type: str, path: str) -> None:
        self.object_type = object_type
        self.path = path
        super().__init__(
            f"Field '{path}' does not exist on {object_type}. "
            f"Call netbox_inspect_type('{object_type}') to list available fields."
        )


class CapExceededError(AgentMCPError):
    """Raised when ``netbox_get_all`` would exceed its configured record cap.

    Attributes:
        total_count: Total matching records reported by NetBox.
        current_max: The max_records value supplied by the caller.
    """

    def __init__(self, total_count: int, current_max: int) -> None:
        self.total_count = total_count
        self.current_max = current_max
        super().__init__(
            f"Query would return {total_count} records, exceeds max_records={current_max}. "
            f"Narrow filters or pass max_records up to 100000."
        )


class SchemaIntrospectionError(AgentMCPError):
    """Raised when GraphQL introspection fails or returns unusable data."""


class NetBoxAPIError(AgentMCPError):
    """Raised when NetBox returns a non-2xx HTTP response.

    Attributes:
        status: HTTP status code.
        url: Request path or full URL that failed.
        body: Raw response body (truncated to 200 chars in the message).
    """

    def __init__(self, status: int, url: str, body: str) -> None:
        self.status = status
        self.url = url
        self.body = body
        body_excerpt = body[:200] + ("..." if len(body) > 200 else "")
        super().__init__(f"NetBox API error {status} at {url}: {body_excerpt}")
