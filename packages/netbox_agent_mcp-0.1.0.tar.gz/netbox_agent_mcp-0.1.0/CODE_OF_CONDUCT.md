# Code of Conduct

This project adopts the [Contributor Covenant, version 2.1](https://www.contributor-covenant.org/version/2/1/code_of_conduct/) as its code of conduct.

The full text of the Contributor Covenant v2.1 is available at the URL above and applies to all project spaces — GitHub issues, pull requests, discussions, and any private channels maintained by the project.

## Enforcement

Reports of unacceptable behavior can be made privately to the maintainers via:

- GitHub's [private vulnerability / conduct reporting](https://github.com/magicboxlab-ai/netbox-agent-mcp/security/advisories/new) channel, or
- The maintainer email listed in [`pyproject.toml`](pyproject.toml) (`authors` field).

All reports will be reviewed and investigated promptly and fairly. Maintainers are obligated to respect the privacy of anyone who reports an incident.

## Attribution

The Contributor Covenant is maintained at <https://www.contributor-covenant.org/> and is licensed under [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/).
