"""Utility primitives — shared helpers that don't fit the other modules.

New in v0.3. Today a single primitive, :func:`run_async`, bridges sync
callers (LangChain ``StructuredTool._run``, legacy code paths) to the
host's async infrastructure without spinning a fresh event loop each
call. Kept minimal on purpose; future helpers land here only when a
dogfood plugin hits a real gap (not speculative).
"""

from __future__ import annotations

from typing import Any, Awaitable


def run_async(coro: Awaitable[Any]) -> Any:
    """Run a coroutine from a sync context and return its result.

    Wired at boot to the host's main-loop primitive (``asyncio.run`` in
    a worker thread against the shared uvicorn loop). Plugins can call
    this from a sync LangChain tool to invoke SDK async primitives
    (``piilot.sdk.cache.get``, ``piilot.sdk.db.cursor`` awaits…)
    without constructing / tearing down an event loop per call.

    Typical use::

        from piilot.sdk.utils import run_async
        from piilot.sdk.cache import get as cache_get

        def _run(self, key: str) -> str:
            # LangChain ``StructuredTool._run`` is sync
            value = run_async(cache_get(key))
            return value or "(miss)"

    Blocks until the coroutine completes. Raises whatever the coroutine
    raises. Do NOT use from an already-running event loop — use
    ``await`` directly in that case.
    """
    raise NotImplementedError("run_async() — wired by loader at boot")
