"""Programmatic Knowledge Base API for plugins.

KBs created by a plugin carry ``owner_type='plugin'`` and
``owner_ref=<namespace>`` on ``public.knowledge_bases``. The SDK
resolves ``owner_ref`` automatically from the ``current_plugin``
contextvar — plugins never pass it.

Access control follows the same rules as user-created KBs
(``access_grants`` + org unit tagging). Plugins that want to keep the
schema and the metadata of their KBs pristine should pass
``schema_locked=True`` and rely on the API guards to reject
``rename/delete KB``, ``update description``, column CRUD, and bulk
import from the UI. Cell edits and single-row CRUD remain available to
end users by design.

Typical seeding flow (idempotent, called from an activation hook or the
first handler invocation):

.. code-block:: python

    from piilot.sdk.knowledge import (
        find_kb, create_kb, add_column, insert_batch, delete_rows_by,
    )

    parent = find_kb(company_id=cid, name="Journal de paie — Périodes")
    if parent is None:
        parent = create_kb(
            company_id=cid, name="Journal de paie — Périodes",
            description="Ligne par période couverte — une ligne = un import.",
            schema_locked=True,
        )
        add_column(parent["id"], name="period_start", column_type="date", position=0)
        add_column(parent["id"], name="period_end", column_type="date", position=1)
        # ...

All functions are stubs until the loader wires them at boot
(``backend/services/plugin_runtime/sdk_wiring.py::_wire_knowledge``).
"""

from __future__ import annotations

from typing import Any, Optional


def create_kb(
    *,
    company_id: str,
    name: str,
    description: str = "",
    schema_locked: bool = False,
    project_id: Optional[str] = None,
) -> dict[str, Any]:
    """Create a plugin-owned KB inside ``company_id``.

    ``owner_type`` is set to ``'plugin'`` and ``owner_ref`` is resolved
    from the calling plugin's namespace (``current_plugin`` contextvar).
    When ``schema_locked=True`` the KB's columns cannot be edited/removed
    via the public API; callers of this SDK bypass that guard.

    Parent ↔ child relationships are now expressed via ``kb_ref`` columns
    only — set up by calling :func:`add_column` with
    ``column_type='kb_ref'`` and ``config={'target_kb_id': '...'}``. The
    legacy ``parent_kb_id`` parameter (SDK ≤ 0.4) was removed in 0.5.

    Returns the freshly-created ``knowledge_bases`` row.
    """
    raise NotImplementedError(
        "create_kb() — wired by loader at boot (plugin_runtime.sdk_wiring)"
    )


def list_columns(kb_id: str) -> list[dict[str, Any]]:
    """Return every column of a KB.

    Each item carries ``{id, name, column_type, position, is_required,
    config, description, pg_column, pg_type, created_at, updated_at}``.

    Plugins use this to translate their human-readable column names
    to the internal column UUIDs (for ``insert_row``, ``update_row``)
    or to discover the schema dynamically (for migrations / sanity
    checks).

    Available since SDK 0.5.0.
    """
    raise NotImplementedError(
        "list_columns() — wired by loader at boot (plugin_runtime.sdk_wiring)"
    )


def find_rows(
    *,
    kb_id: str,
    filters: dict[str, Any],
    parent_row_id: Optional[str] = None,
    limit: int = 50,
) -> list[dict[str, Any]]:
    """Look up rows matching a name-keyed equality filter.

    ``filters`` maps column **names** (not UUIDs) to values; multiple
    keys are ANDed. Pass ``parent_row_id`` to additionally restrict
    the result set to children of one parent row (the row-level FK,
    not a user column). ``filters`` can be empty when only filtering
    on the parent — useful for plugins iterating over a parent's
    children to delete or replace them.

    For richer ops (``gt`` / ``contains`` / ``in``), drop down to
    ``list_columns`` + the agent tools.

    Returns up to ``limit`` rows in the standard envelope:
    ``{id, kb_id, parent_row_id, data, source_type, position, ...}``
    where ``data`` is keyed by column UUID.

    Available since SDK 0.5.0. The ``parent_row_id`` kwarg landed in
    the same release. Replaces direct SQL on ``public.kb_rows`` for
    plugins that previously dropped down to ``piilot.sdk.db.cursor``
    to do their own ``data->>`` filtering.
    """
    raise NotImplementedError(
        "find_rows() — wired by loader at boot (plugin_runtime.sdk_wiring)"
    )


def find_kb(
    *,
    company_id: str,
    name: str,
) -> Optional[dict[str, Any]]:
    """Look up a KB owned by the calling plugin inside ``company_id``.

    Resolution key: ``(organization_id, owner_type='plugin',
    owner_ref=current_plugin, name)``. Returns ``None`` if no matching
    row exists — use this to implement idempotent seeding
    (``find_kb`` → if ``None`` call ``create_kb``).
    """
    raise NotImplementedError(
        "find_kb() — wired by loader at boot (plugin_runtime.sdk_wiring)"
    )


def add_column(
    kb_id: str,
    *,
    name: str,
    column_type: str,
    description: str = "",
    position: int = 0,
    is_required: bool = False,
    config: Optional[dict[str, Any]] = None,
) -> dict[str, Any]:
    """Append a typed column to a KB.

    ``column_type`` is one of the values in the ``kb_columns.column_type``
    CHECK constraint: ``text``, ``numeric``, ``date``, ``file``,
    ``kb_ref``. For ``kb_ref`` columns, put the target KB id in
    ``config={"target_kb_id": "..."}``.

    Returns the inserted column. The parent KB's ``column_count`` is
    incremented atomically.
    """
    raise NotImplementedError(
        "add_column() — wired by loader at boot (plugin_runtime.sdk_wiring)"
    )


def insert_row(
    kb_id: str,
    data: dict[str, Any],
    *,
    parent_row_id: Optional[str] = None,
    position: Optional[int] = None,
) -> dict[str, Any]:
    """Insert a single row. ``data`` maps column names to cell values.

    ``source_type`` is forced to ``'import'`` (plugin-sourced data is
    treated like an import for audit purposes). The KB's ``row_count``
    is bumped atomically.

    Returns the inserted row with its id.
    """
    raise NotImplementedError(
        "insert_row() — wired by loader at boot (plugin_runtime.sdk_wiring)"
    )


def update_row(row_id: str, data: dict[str, Any]) -> dict[str, Any]:
    """Replace the full ``data`` JSONB of a row. Does not merge — pass
    the full dict you want the row to end up with."""
    raise NotImplementedError(
        "update_row() — wired by loader at boot (plugin_runtime.sdk_wiring)"
    )


def delete_row(row_id: str) -> None:
    """Delete a single row. The KB's ``row_count`` is decremented
    atomically."""
    raise NotImplementedError(
        "delete_row() — wired by loader at boot (plugin_runtime.sdk_wiring)"
    )


def insert_batch(kb_id: str, rows: list[dict[str, Any]]) -> int:
    """Bulk insert. Each element must carry a ``data`` dict; optional
    ``position`` and ``parent_row_id`` keys are forwarded to the row.

    Returns the count of inserted rows. The KB's ``row_count`` is
    bumped by that count atomically.
    """
    raise NotImplementedError(
        "insert_batch() — wired by loader at boot (plugin_runtime.sdk_wiring)"
    )


def delete_rows_by(
    kb_id: str,
    filters: dict[str, Any],
    *,
    parent_row_id: Optional[str] = None,
) -> int:
    """Delete rows matching every ``(column_name, value)`` pair in
    ``filters`` (AND-joined). Pass ``parent_row_id`` to additionally
    scope the delete to children of one parent row (row-level FK, not
    a user column).

    ``filters`` can be empty when scoping only by ``parent_row_id`` —
    useful for plugins replacing a whole parent's children on
    re-import. As a safety guard the call refuses to delete anything
    when both ``filters`` is empty AND ``parent_row_id`` is None
    (returns 0).

    Returns the number of rows deleted. The KB's ``row_count`` is
    decremented by that amount atomically.

    Available since SDK 0.5.0. The ``parent_row_id`` kwarg landed in
    the same release.
    """
    raise NotImplementedError(
        "delete_rows_by() — wired by loader at boot (plugin_runtime.sdk_wiring)"
    )


def attach_to_project(kb_id: str, project_id: str) -> None:
    """Link a plugin-owned KB to a project. Reserved — not wired in the
    first release. Raise an issue upstream if your plugin needs it."""
    raise NotImplementedError(
        "attach_to_project() — not wired yet. Open an upstream issue "
        "in AICockpit if your plugin needs project scoping."
    )
