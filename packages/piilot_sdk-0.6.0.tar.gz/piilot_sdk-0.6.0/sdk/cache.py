"""Redis-backed cache for plugins — progress tracking, short-lived state, counters.

All primitives are **async**. Keys are automatically prefixed with the
plugin's namespace (``plugin:{namespace}:{key}``) so plugins cannot
accidentally read or write each other's data.

Values are JSON-serializable (dict, list, str, int, float, bool, None) —
serialization is handled transparently by the core cache backend.

Under the hood: the wired implementations delegate to the core
``CacheBackend`` (MemoryBackend in dev, RedisBackend in prod; see
``backend/services/cache.py``). Plugins SHOULD treat the cache as
best-effort: a Redis outage logs and falls through rather than raising.

Plugin context requirement
--------------------------

Every primitive resolves the active plugin's namespace from
``piilot.sdk._runtime.current_plugin``. Calling these from outside a
plugin entry point (not inside ``plugin.register()``, not inside a
request handler, not inside a scheduled job) raises ``RuntimeError``.
"""

from __future__ import annotations

from typing import Any, Optional


async def get(key: str) -> Any | None:
    """Retrieve a value. Returns ``None`` if the key is absent or expired.

    The effective Redis key is ``plugin:{namespace}:{key}`` — namespace
    prefixing is applied transparently by the wiring.
    """
    raise NotImplementedError("cache.get() — wired by loader at boot")


async def set(key: str, value: Any, ttl: Optional[int] = None) -> None:
    """Store a value. Value must be JSON-serializable.

    ``ttl`` in seconds. ``None`` means no expiration (discouraged — prefer
    an explicit TTL so plugin data doesn't accumulate indefinitely).
    """
    raise NotImplementedError("cache.set() — wired by loader at boot")


async def delete(key: str) -> None:
    """Remove a key. No-op if the key doesn't exist (idempotent)."""
    raise NotImplementedError("cache.delete() — wired by loader at boot")


async def incr(
    key: str,
    amount: int = 1,
    ttl: Optional[int] = None,
) -> int:
    """Atomic increment. Initializes the counter to 0 on first access.

    Returns the new value. ``ttl`` (in seconds) is applied **only on the
    first creation** of the key — matching Redis ``INCR`` + ``EXPIRE``
    semantics. Subsequent calls don't reset the TTL.

    Useful for: request counters, rate-limiting windows, per-company
    usage quotas.
    """
    raise NotImplementedError("cache.incr() — wired by loader at boot")


# ---------------------------------------------------------------------------
# Reserved — v0.3+
# ---------------------------------------------------------------------------


def get_redis() -> Any:
    """Return the raw async Redis client.

    Reserved for v0.3+. In v0.2 this remains a stub — direct Redis access
    would bypass the namespace isolation, so we don't expose it yet.
    Use the high-level ``get`` / ``set`` / ``delete`` / ``incr`` instead.
    """
    raise NotImplementedError(
        "get_redis() — reserved for v0.3+. Use the high-level cache primitives."
    )
