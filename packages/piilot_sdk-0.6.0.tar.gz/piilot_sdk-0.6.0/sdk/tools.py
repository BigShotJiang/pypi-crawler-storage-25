"""Agent tools — LangChain ``StructuredTool`` exposed to the builder.

A plugin declares its tools once at ``plugin.register()`` time via
:func:`register_tool`. The spec is a dict; we keep it untyped at the SDK
level to avoid leaking LangChain internals in type signatures.

v0.2 (Lot 6) — spec dict gained an optional ``system_prompt_builder``
key. When present, the callable is invoked each time an agent is built
for a given company — its return value is appended to the agent's
system prompt if non-empty. Plugins use this to advertise what
integrations are active for the user ("You have 2 active Pennylane
integrations...") so the LLM picks the right tool.

Spec shape::

    {
        "id": "pennylane.query_invoices",          # MUST be namespaced
        "namespace": "pennylane",                  # (optional — inferred from id.prefix)
        "label_key": "pennylane.tools.query_invoices.label",
        "description_key": "pennylane.tools.query_invoices.description",
        "requires": "connectors.pennylane.api",    # optional runtime gate
        "tool": <StructuredTool instance>,
        "system_prompt_builder": <Callable[[str], str]>,  # optional, new in v0.2
    }
"""

from __future__ import annotations

import functools
import inspect
from typing import Any, Callable, Literal, Optional

from piilot.sdk._runtime import current_plugin


# Tools registered by plugins: list of spec dicts
_REGISTERED: list[dict[str, Any]] = []

# Prompt builders extracted at register time: (namespace, callable) tuples.
# Stored alongside tools so the core runtime can iterate them without
# re-parsing every spec dict.
_PROMPT_BUILDERS: list[tuple[str, Callable[[str], str]]] = []


OnDuplicate = Literal["replace", "skip", "raise"]


def register_tool(
    spec: dict[str, Any],
    *,
    on_duplicate: OnDuplicate = "replace",
) -> None:
    """Declare an agent tool. Called during ``plugin.register()``.

    The spec's ``namespace`` field is inferred from ``current_plugin``
    contextvar if absent. The ``id`` must be namespaced (contain a ``.``).

    ``system_prompt_builder`` is optional; when present it's extracted
    into a companion registry consumed by the agent runtime at prompt-
    build time.

    ``on_duplicate`` (new in v0.3) controls what happens when a tool
    with the same ``id`` is already registered:

    - ``"replace"`` (default, v0.2 silent-append behavior replaced) —
      drop the existing entry + its prompt builder, register the new
      one. Last-wins, matches the other SDK registries.
    - ``"skip"`` — keep the existing entry, silently ignore the new
      call. Useful for idempotent ``plugin.register()`` bodies.
    - ``"raise"`` — raise :class:`ValueError` on duplicate ``id``.
    """
    if "id" not in spec or "tool" not in spec:
        raise ValueError("tool spec must contain 'id' and 'tool' keys at minimum")

    # Auto-fill namespace from context if absent
    ns = current_plugin.get()
    if "namespace" not in spec:
        if ns is None:
            raise RuntimeError(
                "register_tool called outside plugin context and spec lacks 'namespace'"
            )
        spec = {**spec, "namespace": ns}

    tool_id = spec["id"]
    existing_idx = next(
        (i for i, s in enumerate(_REGISTERED) if s.get("id") == tool_id),
        None,
    )
    if existing_idx is not None:
        if on_duplicate == "skip":
            return
        if on_duplicate == "raise":
            raise ValueError(f"tool with id={tool_id!r} already registered")
        # "replace" — drop old entry + associated prompt builder(s)
        old_spec = _REGISTERED.pop(existing_idx)
        old_builder = old_spec.get("system_prompt_builder")
        if old_builder is not None:
            _PROMPT_BUILDERS[:] = [
                (ns_, cb) for ns_, cb in _PROMPT_BUILDERS if cb is not old_builder
            ]

    _REGISTERED.append(spec)

    builder = spec.get("system_prompt_builder")
    if builder is not None:
        _PROMPT_BUILDERS.append((spec["namespace"], builder))


def _register_in_tree_tool(
    spec: dict[str, Any],
    namespace: str,
    system_prompt_builder: Optional[Callable[[str], str]] = None,
) -> None:
    """Host-only escape hatch: register an in-tree tool without a plugin context.

    Used by ``backend/api/main.py`` during the Pennylane transition —
    the 14 Pennylane tools are pushed into the registry at lifespan
    startup under the fictional ``pennylane`` namespace. Plugins MUST
    NOT call this; use :func:`register_tool`.

    Unlike :func:`register_tool`, the namespace is passed explicitly,
    and the system_prompt_builder is a separate kwarg rather than a
    spec dict key (keeps the helper tight).
    """
    if "id" not in spec or "tool" not in spec:
        raise ValueError("tool spec must contain 'id' and 'tool' keys")
    full_spec = {**spec, "namespace": namespace}
    _REGISTERED.append(full_spec)
    if system_prompt_builder is not None:
        _PROMPT_BUILDERS.append((namespace, system_prompt_builder))


def _drain() -> list[dict[str, Any]]:
    """Internal — called by the agent runtime to collect registered tools.

    Unlike other SDK ``_drain`` helpers, this does NOT clear the registry
    — the runtime references the specs for the life of the process
    (agents are built on-demand per session, each needs the tool list).
    """
    return list(_REGISTERED)


def _drain_prompt_builders() -> list[tuple[str, Callable[[str], str]]]:
    """Internal — snapshot of (namespace, prompt_builder) pairs.

    Same persistence rule as ``_drain``: the runtime consults this on
    every agent build, don't clear at drain.
    """
    return list(_PROMPT_BUILDERS)


def _reset_for_tests() -> None:
    """Test helper — clear both registries between tests."""
    _REGISTERED.clear()
    _PROMPT_BUILDERS.clear()


# ---------------------------------------------------------------------------
# bind_session — LangGraph-aware ``session_id`` injection (v0.6)
# ---------------------------------------------------------------------------


def bind_session(fn: Callable[..., Any]) -> Callable[..., Any]:
    """Adapt a tool ``_fn`` so its ``session_id`` is injected from ``RunnableConfig``.

    Why this exists
    ---------------

    Up to and including SDK ``v0.5.0``, agent tools took ``session_id: str``
    as a regular parameter, and the agent runtime told the LLM what its
    session id was via a ``--- SESSION ---`` block at the bottom of the
    system prompt. The LLM forwarded the value on every tool call.

    PLT-35 (Piilot core, end of April 2026) **removed that block** to
    stabilise OpenAI's prompt-cache prefix. Tools are now expected to
    receive ``session_id`` via LangGraph's ``RunnableConfig``
    (auto-injected by ``ToolNode``) — not as an LLM-facing parameter.

    Plugin tools that still ship the old ``session_id: str = ""``
    parameter are silently broken on production: the LLM no longer
    knows the session id, calls every tool with the empty default,
    and falls through to an "unknown session" error.

    Usage
    -----

    Wrap ``_fn`` before exporting the ``StructuredTool``::

        from piilot.sdk.tools import bind_session
        from langchain_core.tools import StructuredTool

        async def _my_tool_fn(arg: str, session_id: str = "") -> str:
            ...

        my_tool = StructuredTool.from_function(
            coroutine=bind_session(_my_tool_fn),
            name="my_tool",
            description="...",
        )

    The wrapper:

    * Removes ``session_id`` from the LLM-facing JSON schema (LangChain
      treats ``RunnableConfig``-typed parameters as internal-only).
    * Adds an internal ``config: RunnableConfig | None`` parameter
      that LangGraph's ``ToolNode`` populates from the run's config.
    * Extracts ``config["configurable"]["session_id"]`` (or ``""``
      if absent) and forwards it to ``fn`` as a keyword arg.
    * Preserves ``__name__``, ``__doc__``, ``__signature__``,
      ``__annotations__`` so ``StructuredTool.from_function`` derives
      the correct schema and name.
    * Detects sync vs async ``fn`` and wraps accordingly.
    * Is a no-op if ``fn`` doesn't have a ``session_id`` parameter
      (returns ``fn`` unchanged) — safe to ``map(bind_session, …)``
      over a heterogenous list.

    Direct calls to ``fn`` (your existing unit tests) keep working
    unchanged: ``bind_session`` returns a wrapper, not a replacement.

    Args:
        fn: a coroutine or sync function whose signature contains a
            ``session_id: str`` parameter.

    Returns:
        A wrapper with ``session_id`` replaced by ``config: RunnableConfig``.
    """
    # Local import — keeps ``langchain_core`` an optional dep at SDK
    # import time. Plugins that don't expose tools never need it.
    from langchain_core.runnables import RunnableConfig

    orig_sig = inspect.signature(fn)
    if "session_id" not in orig_sig.parameters:
        return fn

    new_params = [
        p for p in orig_sig.parameters.values() if p.name != "session_id"
    ]
    new_params.append(
        inspect.Parameter(
            "config",
            inspect.Parameter.KEYWORD_ONLY,
            default=None,
            annotation=RunnableConfig,
        )
    )
    new_sig = orig_sig.replace(parameters=new_params)

    is_coro = inspect.iscoroutinefunction(fn)

    if is_coro:

        @functools.wraps(fn)
        async def wrapper(*args, config=None, **kwargs):
            session_id = ""
            if isinstance(config, dict):
                cfg = config.get("configurable") or {}
                session_id = cfg.get("session_id") or ""
            return await fn(*args, session_id=session_id, **kwargs)

    else:

        @functools.wraps(fn)
        def wrapper(*args, config=None, **kwargs):  # type: ignore[misc]
            session_id = ""
            if isinstance(config, dict):
                cfg = config.get("configurable") or {}
                session_id = cfg.get("session_id") or ""
            return fn(*args, session_id=session_id, **kwargs)

    new_annotations = {
        p.name: p.annotation
        for p in new_params
        if p.annotation is not inspect.Parameter.empty
    }
    if orig_sig.return_annotation is not inspect.Signature.empty:
        new_annotations["return"] = orig_sig.return_annotation
    wrapper.__annotations__ = new_annotations
    wrapper.__signature__ = new_sig  # type: ignore[attr-defined]
    return wrapper
