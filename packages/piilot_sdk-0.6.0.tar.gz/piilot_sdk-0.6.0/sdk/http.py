"""HTTP extension points — mount plugin FastAPI routers + re-use core auth primitives.

v0.2 (Lot 4) adds the primary registration API and exposes the core's
auth dependencies + ``get_real_ip`` helper to plugins without forcing
them to import ``backend.*``.

Primary API (v0.2)
------------------

``register_router(router, prefix="")`` / ``register_webhook_router(router)``
set the router's prefix to the correct ``/plugins/{namespace}/...`` path
and queue it for mounting by the loader. The plugin's namespace is
resolved at call time via the ``current_plugin`` contextvar (set by the
loader around ``plugin.register()``).

Legacy API (v0.1)
-----------------

``mount_router(router)`` — kept as an alias so the v0.1 template still
boots. Takes a router with an already-correct ``/plugins/{namespace}/...``
prefix; the loader enforces the rule via ``PluginRoutePrefixInvalid``.
Will be removed in v0.3.

Auth dependencies
-----------------

``require_admin`` / ``require_builder`` / ``require_user`` are
FastAPI-compatible dependencies returning ``(user_id, OrgRole, company_id)``.
Use them via ``Depends(...)`` in plugin route handlers:

    from fastapi import Depends
    from piilot.sdk.http import require_admin, register_router

    @router.get("/admin-only")
    def handler(auth=Depends(require_admin)):
        user_id, role, company_id = auth
        ...
"""

from __future__ import annotations

from typing import Any

from piilot.sdk._runtime import current_plugin

# Stored entries: (router, override_prefix_or_None).
#
# For the legacy ``mount_router``, the tuple is ``(router, None)`` — the
# loader uses ``router.prefix`` directly (v0.1 behavior).
#
# For the v0.2 ``register_router`` / ``register_webhook_router``, the tuple
# is ``(router, "/plugins/{ns}{...}")``. We pass this prefix to
# ``app.include_router(router, prefix=...)`` at mount time rather than
# mutating ``router.prefix`` after the fact — FastAPI's APIRouter bakes
# its current prefix into each route at ``add_api_route`` time, so
# post-hoc prefix mutation doesn't propagate to already-registered routes.
_REGISTERED: list[tuple[Any, str | None]] = []


def mount_router(router: Any) -> None:
    """Deprecated v0.1 API — prefer :func:`register_router`.

    The router's ``prefix`` MUST already start with
    ``/plugins/{namespace}/``; the loader refuses the plugin otherwise.

    Kept as an alias so plugins forked from the v0.1 template continue
    to boot. Will be removed in v0.3.
    """
    _REGISTERED.append((router, None))


def register_router(router: Any, prefix: str = "") -> None:
    """Register a plugin FastAPI router.

    The effective mount path is ``/plugins/{namespace}{prefix}``. The
    plugin's namespace is resolved from the ``current_plugin`` contextvar
    (set by the loader around ``plugin.register()``).

    **Router prefix contract**: create the ``APIRouter`` with a blank
    prefix (or a suffix that appends to ``{prefix}``). The SDK always
    mounts it under ``/plugins/{ns}{prefix}`` — if you hand in a router
    with ``prefix="/custom"``, that ``/custom`` is **ignored** at mount
    time. Use the ``prefix`` parameter of this function instead.

    Example::

        from fastapi import APIRouter
        from piilot.sdk.http import register_router

        router = APIRouter()

        @router.get("/dashboard")
        def dashboard(): ...

        # In Plugin.register():
        ctx.http.register_router(router, prefix="/treasury")
        # → mounted at /plugins/{ns}/treasury/dashboard

    Calling from outside a plugin entry point raises ``RuntimeError``.
    """
    ns = current_plugin.get()
    if ns is None:
        raise RuntimeError(
            "register_router called outside plugin context. "
            "Invoke from plugin.register(ctx) or a plugin entry point."
        )
    full_prefix = f"/plugins/{ns}{prefix}"
    _REGISTERED.append((router, full_prefix))


def register_webhook_router(router: Any) -> None:
    """Register a plugin webhook router.

    The effective mount path is ``/plugins/{namespace}/webhooks{existing_prefix}``
    where ``existing_prefix`` is the router's original ``prefix`` (if any).
    Routes under this path are bypassed by the ``plugin_gate`` middleware —
    external SaaS callbacks come in without an ``X-Company-Id`` header,
    so the plugin itself must resolve the company from the payload +
    signature check.

    Example::

        webhook_router = APIRouter(prefix="/pennylane")

        @webhook_router.post("")
        async def handle(request): ...

        ctx.http.register_webhook_router(webhook_router)
        # → mounted at /plugins/{ns}/webhooks/pennylane

    Calling from outside a plugin entry point raises ``RuntimeError``.
    """
    ns = current_plugin.get()
    if ns is None:
        raise RuntimeError(
            "register_webhook_router called outside plugin context."
        )
    existing = getattr(router, "prefix", "") or ""
    full_prefix = f"/plugins/{ns}/webhooks{existing}"
    # Webhook routers keep their routes' own relative paths; we pass the
    # prefix at include_router time and reset the router's own prefix so
    # it doesn't double up.
    router.prefix = ""
    _REGISTERED.append((router, full_prefix))


def _drain() -> list[tuple[Any, str | None]]:
    collected = list(_REGISTERED)
    _REGISTERED.clear()
    return collected


# ---------------------------------------------------------------------------
# Auth dependencies + utilities — wired at boot by sdk_wiring._wire_http()
# ---------------------------------------------------------------------------


def require_admin(request: Any) -> Any:
    """FastAPI dependency — require admin role.

    Returns ``(user_id, OrgRole, company_id)``. Raises HTTP 403 if the
    caller isn't admin, or 403 on cross-company mismatch.

    Use via ``Depends(require_admin)``.
    """
    raise NotImplementedError("require_admin — wired by loader at boot")


def require_builder(request: Any) -> Any:
    """FastAPI dependency — require builder or admin role.

    Returns ``(user_id, OrgRole, company_id)``. Raises HTTP 403 if the
    caller is a plain user.
    """
    raise NotImplementedError("require_builder — wired by loader at boot")


def require_user(request: Any) -> Any:
    """FastAPI dependency — any authenticated user with a membership.

    Returns ``(user_id, OrgRole, company_id_or_None)``. Does NOT raise
    on role (admin / builder / user all allowed). Raises HTTP 403 only
    if ``X-Company-Id`` is set to a company the user isn't a member of.
    """
    raise NotImplementedError("require_user — wired by loader at boot")


def get_real_ip(request: Any) -> str:
    """Return the real client IP behind Cloudflare / reverse proxies.

    Priority: ``CF-Connecting-IP`` (Cloudflare) → ``X-Real-IP`` →
    ``X-Forwarded-For`` (first hop) → direct peer.
    """
    raise NotImplementedError("get_real_ip — wired by loader at boot")
