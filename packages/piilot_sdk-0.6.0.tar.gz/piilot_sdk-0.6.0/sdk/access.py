"""Access-grant checks for plugin-owned resources.

A plugin that creates resources users can access (modules, agents,
knowledge bases) often needs to gate reads/writes based on who the
caller is. The core ``access_grants_repo.has_access`` function handles
the multi-level grant resolution (direct user / group / role / project);
this module is a thin passthrough.

v0.2 — only ``check_grant`` is exposed. A ``require_grant`` FastAPI
dependency decorator is planned for v0.3+ once a plugin builds enough
gated routes to justify the wrapper. In v0.2, plugins can assemble the
same pattern by combining ``check_grant`` with ``Depends(require_user)``
from ``piilot.sdk.http``.
"""

from __future__ import annotations

from typing import Any


def check_grant(
    company_id: str,
    resource_type: str,
    resource_id: str,
    user_id: str,
) -> bool:
    """Return True if ``user_id`` has access to the resource.

    ``resource_type`` is a free-form string; the core reserves
    ``"module"``, ``"agent"``, and ``"knowledge_base"`` — plugins are
    free to introduce their own (e.g. ``"myplug.dashboard"``) as long
    as they stay consistent across their ``access_grants.create`` /
    ``access_grants.delete`` / ``check_grant`` calls.

    Resolution order (first match wins):

    1. No grants exist for the resource → **True** (backward-compatible
       default: a resource without any grant is visible to everyone).
    2. Direct user grant.
    3. Group grant (user is member of a company group that has a grant).
    4. Role grant (user's role matches a role grant).
    5. Project grant (user is member of a project that has a grant).
    """
    raise NotImplementedError("check_grant — wired by loader at boot")
