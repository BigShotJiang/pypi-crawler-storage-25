"""Plugin i18n — locale files merged by namespace.

A plugin ships ``locales/fr.json``, ``locales/en.json`` etc. with keys
prefixed by its namespace (``hello.modules.greet.title``). The loader
reads these files and merges them into the global catalog served at
``GET /i18n/catalog`` (see T08).

Rules enforced at boot:

* All keys MUST be prefixed by the plugin's namespace — unprefixed keys
  refuse the plugin.
* Overriding a core key or another plugin's key logs a WARNING, the
  first-registered value wins.
"""

from __future__ import annotations

from typing import NamedTuple

_REGISTERED: list["LocalesSpec"] = []


class LocalesSpec(NamedTuple):
    namespace: str
    anchor_file: str
    rel_dir: str


def register_locales(namespace: str, anchor_file: str, rel_dir: str) -> None:
    """Register a plugin's locales directory."""
    _REGISTERED.append(LocalesSpec(namespace, anchor_file, rel_dir))


def _drain() -> list[LocalesSpec]:
    collected = list(_REGISTERED)
    _REGISTERED.clear()
    return collected
