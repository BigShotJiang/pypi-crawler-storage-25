"""Modules registry — seed dashboard / workflow modules owned by a plugin.

Modules are declarative UI surfaces (dashboards, ETL wizards, etc.)
exposed to builders via the Modules section. A plugin seeds its module
row(s) at register time with :func:`register_module`; the loader upserts
each row into ``modules.modules`` with ``ON CONFLICT (module_slug) DO
UPDATE`` so re-installs / upgrades refresh the descriptive fields
while preserving the row's UUID (important for stable URLs, grants,
analytics).

Plugin-friendly naming
----------------------

The DB column is named ``module_slug`` for historical reasons; plugin
authors pass ``slug`` in the dict (the SDK maps the names at upsert
time). Both ``slug`` and the raw ``module_slug`` are accepted — prefer
``slug``.
"""

from __future__ import annotations

from typing import Any, Literal


# Buffered modules between ``register_module`` and the boot-time upsert
# that the loader runs after ``plugin.register()`` returns.
_REGISTERED: list[dict[str, Any]] = []


OnDuplicate = Literal["replace", "skip", "raise"]


def _module_slug(module: dict[str, Any]) -> str:
    """Return the canonical slug (``module_slug`` wins over ``slug``)."""
    return module.get("module_slug") or module["slug"]


def register_module(
    module: dict[str, Any],
    *,
    on_duplicate: OnDuplicate = "replace",
) -> None:
    """Register (idempotent upsert) a module row.

    Required: ``slug`` (or ``module_slug``) — globally unique across all
    companies and plugins.

    Common optional keys: ``module_name``, ``description``, ``icon``,
    ``category``, ``status`` (``"draft"`` / ``"published"`` /
    ``"archived"``), ``company_id`` (scoped module; ``None`` for global
    templates visible to all companies), ``config`` (JSONB).

    ``on_duplicate`` (new in v0.3): ``"replace"`` (default) drops the
    existing entry and appends the new one, ``"skip"`` keeps the old,
    ``"raise"`` raises :class:`ValueError`. The DB-level upsert run by
    the loader is unchanged (ON CONFLICT (module_slug) DO UPDATE); this
    control targets the in-memory buffer between ``register_module``
    and the boot-time drain.

    Raises ``ValueError`` if the ``slug`` key is missing.
    """
    if "slug" not in module and "module_slug" not in module:
        raise ValueError(
            "module dict must have a 'slug' key (or 'module_slug')"
        )

    slug = _module_slug(module)
    existing_idx = next(
        (i for i, m in enumerate(_REGISTERED) if _module_slug(m) == slug),
        None,
    )
    if existing_idx is not None:
        if on_duplicate == "skip":
            return
        if on_duplicate == "raise":
            raise ValueError(f"module with slug={slug!r} already registered")
        _REGISTERED.pop(existing_idx)

    _REGISTERED.append(module)


def _drain() -> list[dict[str, Any]]:
    collected = list(_REGISTERED)
    _REGISTERED.clear()
    return collected


# Wired at boot by ``sdk_wiring._wire_modules``.
def _upsert_module(module: dict[str, Any]) -> None:
    """Internal — upsert into ``modules.modules`` keyed on ``module_slug``.

    The dict's ``slug`` key (if present) is translated to ``module_slug``
    before the SQL. Other keys are used as-is. Conflict on
    ``module_slug`` triggers a ``DO UPDATE`` on every non-slug column.
    """
    raise NotImplementedError("_upsert_module — wired by loader at boot")


def get_by_slug(slug: str) -> dict[str, Any] | None:
    """Fetch a module row by its ``module_slug``.

    Returns the full row as a dict (including the auto-generated ``id``
    UUID) or ``None`` if no module with that slug exists. New in v0.3 —
    saves a ``piilot.sdk.db.cursor()`` boilerplate roundtrip when a
    plugin needs the UUID to route to ``/modules/{id}`` or seed access
    grants against a module registered via :func:`register_module`.
    """
    raise NotImplementedError("get_by_slug() — wired by loader at boot")
