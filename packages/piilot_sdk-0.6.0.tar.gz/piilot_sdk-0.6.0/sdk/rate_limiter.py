"""Async rate limiter for external API calls — adaptive backoff + auto-recovery.

The only SDK module that ships real code in v0.1 (not a stub wired by
the loader). The implementation is lifted from
``backend.services.integrations.pennylane.rate_limiter`` — which was
already fully generic — and extended with a ``@rate_limited`` decorator
that wraps async functions.

Usage (class)::

    limiter = RateLimiter(max_per_second=3.0)
    async with limiter:
        resp = await client.get(url)
    if resp.status_code == 429:
        limiter.back_off()
    else:
        limiter.success()

Usage (decorator)::

    @rate_limited(max_per_second=3.0)
    async def fetch(url):
        ...
"""

from __future__ import annotations

import asyncio
import functools
from typing import Any, Awaitable, Callable, TypeVar

F = TypeVar("F", bound=Callable[..., Awaitable[Any]])


class RateLimiter:
    """Async rate limiter with adaptive backoff and auto-recovery.

    On 429 from the remote: call :meth:`back_off` to double the interval
    (up to ``_MAX_INTERVAL``). After :attr:`_RECOVER_AFTER` consecutive
    successes: :meth:`success` restores the base rate.
    """

    _MAX_INTERVAL: float = 5.0
    _RECOVER_AFTER: int = 10

    def __init__(self, max_per_second: float = 4.0) -> None:
        if max_per_second <= 0:
            raise ValueError("max_per_second must be > 0")
        self._base_interval = 1.0 / max_per_second
        self._min_interval = self._base_interval
        self._lock = asyncio.Lock()
        self._last_call: float = 0.0
        self._ok_streak: int = 0

    def back_off(self) -> None:
        """Double the minimum interval (call after a 429)."""
        self._min_interval = min(self._min_interval * 2, self._MAX_INTERVAL)
        self._ok_streak = 0

    def success(self) -> None:
        """Record a successful request; recover base rate after enough successes."""
        if self._min_interval > self._base_interval:
            self._ok_streak += 1
            if self._ok_streak >= self._RECOVER_AFTER:
                self._min_interval = self._base_interval
                self._ok_streak = 0

    async def acquire(self) -> None:
        """Wait until the next request slot is available."""
        async with self._lock:
            loop = asyncio.get_event_loop()
            now = loop.time()
            elapsed = now - self._last_call
            if elapsed < self._min_interval:
                await asyncio.sleep(self._min_interval - elapsed)
            self._last_call = asyncio.get_event_loop().time()

    async def __aenter__(self) -> "RateLimiter":
        await self.acquire()
        return self

    async def __aexit__(self, *exc: object) -> None:
        return None


def rate_limited(max_per_second: float = 4.0) -> Callable[[F], F]:
    """Decorator: wrap an async function with a dedicated :class:`RateLimiter`.

    Each decorated function gets its own limiter instance. Use the class
    directly if you need to share a limiter across call sites (typical
    for a single external API client)."""

    def decorator(fn: F) -> F:
        limiter = RateLimiter(max_per_second)

        @functools.wraps(fn)
        async def wrapper(*args: Any, **kwargs: Any) -> Any:
            async with limiter:
                return await fn(*args, **kwargs)

        return wrapper  # type: ignore[return-value]

    return decorator
