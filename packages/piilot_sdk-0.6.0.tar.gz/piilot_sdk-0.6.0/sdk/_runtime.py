"""SDK-internal runtime state shared between the public surface and the host wiring.

The underscore prefix marks this module as **internal**. Plugin authors should
not import from here — the module is not part of the stable public contract
and may be reshuffled between minor versions pre-v1.0.

Why the contextvar lives here rather than in ``backend.*``
----------------------------------------------------------

The SDK is a self-contained package destined for PyPI distribution
(``piilot-sdk``). Importing ``backend.*`` from within the SDK would:

1. Break ``pip install piilot-sdk`` standalone (the package would carry a
   phantom dependency).
2. Defeat the plugin loader's AST check that refuses ``from backend.*`` in
   plugin source — the check relies on the SDK itself being backend-free.

So the contextvar is defined here, and the host backend imports *from the
SDK*. This inverts the dependency in the right direction: the SDK owns its
contract, the host plugs in behind.
"""

from __future__ import annotations

from contextvars import ContextVar

# Holds the namespace of the plugin currently executing in this async task.
# ``None`` outside a plugin entry point.
#
# Who sets it:
# * The plugin loader (``backend.services.plugins``), around
#   ``plugin.register(ctx)`` at boot.
# * The ``plugin_gate`` middleware, at the start of every
#   ``/plugins/{namespace}/*`` HTTP request (Lot 4).
# * The scheduler dispatcher, around each sync/job handler call (Lot 5).
#
# Plugins MUST NOT set this themselves — it's managed by the host. Reading
# via ``.get()`` is allowed (e.g. for logging), but the typed accessor
# :func:`piilot.sdk.plugin.current_namespace` is the public way.
current_plugin: ContextVar[str | None] = ContextVar("current_plugin", default=None)
