"""Symmetric encryption for plugin credentials (auto-applied on ``type: secret`` fields).

The core handles encryption/decryption transparently: fields marked
``type: secret`` in a connector's ``credentials_schema`` are encrypted
before being persisted to ``integrations_master.connections`` and
decrypted when the plugin calls
:func:`piilot.sdk.connectors.get_connection`. Plugins rarely call
:func:`encrypt` / :func:`decrypt` directly — only when encrypting data
outside the standard credentials pattern.

Implementation: wired at boot by the loader to
``backend.services.crypto`` (Fernet, key derived from ``CRYPTO_KEY``
env var). Exposed as SDK primitives so the contract is stable across
refactors of the core's crypto internals.
"""

from __future__ import annotations


class CryptoError(Exception):
    """Raised when encryption/decryption fails (bad key, tampered payload, etc.)."""


def encrypt(plaintext: bytes | str) -> str:
    """Encrypt and return a base64-encoded ciphertext string."""
    raise NotImplementedError("encrypt() — wired by loader at boot (T04)")


def decrypt(ciphertext: str) -> str:
    """Decrypt and return the plaintext as a UTF-8 ``str``.

    Changed in v0.3: previously returned ``bytes``. Callers that used
    ``decrypt(...).decode("utf-8")`` (Pennylane dogfood workaround
    ``_decrypt_str``) can now just use the result directly.

    Raises :class:`CryptoError` if the ciphertext is invalid.
    """
    raise NotImplementedError("decrypt() — wired by loader at boot (T04)")


def mask_api_key(key: str) -> str:
    """Return a masked preview of an API key for safe display/logging.

    Format: first 6 + ``...`` + last 3 chars (e.g. ``sk-abc...xyz``).
    Strings of length ≤ 8 are fully masked as ``"***"`` — too short to
    reveal without leaking the full value.

    Used by Settings UIs to show which key is configured without
    exposing the full secret. Safe to log.
    """
    raise NotImplementedError("mask_api_key() — wired by loader at boot")
