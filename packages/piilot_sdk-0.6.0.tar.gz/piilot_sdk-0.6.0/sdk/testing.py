"""Test helpers for plugin authors — isolated pytest fixtures.

New in v0.3. The dogfood (Pennylane) surfaced two recurring test-time
pain points:

- ``piilot.sdk.http.get_real_ip`` is a stub outside the host boot
  sequence — slowapi's ``key_func`` trips on ``NotImplementedError``
  when a plugin tests its own routes in isolation.
- ``piilot.sdk.db.execute_values`` + ``MagicMock`` cursor don't play
  together (the helper calls ``cur.mogrify`` + bytes join), breaking
  any test that mocks ``_get_conn`` in a plugin repo.

The helpers here are the same patches we documented in SDK_CHANGELOG
v0.3 roadmap entries P5/P11 — now shipped with the SDK so plugins
don't have to copy them into their own ``conftest.py``.

None of these wire to anything at boot; they are pure test utilities
safe to import from ``plugin/conftest.py``.
"""

from __future__ import annotations

from contextlib import contextmanager
from typing import Any, Iterator


def stub_http_primitives() -> None:
    """Replace ``piilot.sdk.http.get_real_ip`` with a deterministic stub.

    Call once from an autouse session-scoped fixture in your plugin's
    ``conftest.py``::

        import pytest
        from piilot.sdk.testing import stub_http_primitives

        @pytest.fixture(autouse=True, scope="session")
        def _stub_sdk_http() -> None:
            stub_http_primitives()

    After the call, ``get_real_ip(request)`` returns ``"127.0.0.1"``
    regardless of the request object. Idempotent — calling twice is a
    no-op. The host's real implementation is never restored because a
    test run never reaches host boot; for mixed-mode test runs, wrap
    the call in a ``try``/``finally`` that restores the original
    attribute.
    """
    from piilot.sdk import http as sdk_http

    def _stub(_request: Any) -> str:  # pragma: no cover — trivial
        return "127.0.0.1"

    sdk_http.get_real_ip = _stub  # type: ignore[assignment]


@contextmanager
def mock_db_conn(cursor_mock: Any) -> Iterator[None]:
    """Context manager that neutralises ``execute_values`` for mocked cursors.

    ``piilot.sdk.db.execute_values`` calls ``cur.mogrify`` + ``b"".join``
    under the hood. A bare ``MagicMock`` cursor trips on the bytes join
    because ``mogrify`` returns a ``Mock`` (not ``bytes``). This helper
    monkey-patches ``execute_values`` in every module that rebinds it
    via ``from piilot.sdk.db import execute_values`` (or the legacy
    ``from ._base import execute_values`` pattern) so your tests don't
    have to enumerate every repo manually.

    Usage::

        from unittest.mock import MagicMock
        from piilot.sdk.testing import mock_db_conn

        def test_upsert_invoices():
            cur = MagicMock()
            with mock_db_conn(cur):
                # cur.execute(...) / cur.fetchall() work normally;
                # execute_values(cur, ...) becomes cur.execute(sql % tuple(values))
                my_repo.upsert(cur, rows=[{...}])

    The original ``execute_values`` is restored on context exit. Safe
    to nest.
    """
    import sys

    # Replace the symbol in every loaded module that rebound it — the
    # "from x import execute_values" pattern creates a module-local
    # reference that would otherwise ignore our patch.
    def _fake_execute_values(
        cur: Any, sql: str, argslist: list[tuple[Any, ...]], *args: Any, **kwargs: Any
    ) -> None:
        for row in argslist:
            cur.execute(sql, row)

    patched: list[tuple[Any, str, Any]] = []

    # Patch the canonical symbol.
    try:
        from piilot.sdk import db as sdk_db

        original = sdk_db.execute_values
        sdk_db.execute_values = _fake_execute_values  # type: ignore[assignment]
        patched.append((sdk_db, "execute_values", original))
    except (ImportError, AttributeError):
        pass

    # Patch every module that re-exports it.
    for module in list(sys.modules.values()):
        if module is None:
            continue
        if not hasattr(module, "execute_values"):
            continue
        attr = getattr(module, "execute_values", None)
        # Only patch the rebind of our symbol, not unrelated namesakes.
        if callable(attr) and attr is not _fake_execute_values:
            patched.append((module, "execute_values", attr))
            module.execute_values = _fake_execute_values  # type: ignore[attr-defined]

    try:
        yield
    finally:
        for module, name, original in patched:
            setattr(module, name, original)
