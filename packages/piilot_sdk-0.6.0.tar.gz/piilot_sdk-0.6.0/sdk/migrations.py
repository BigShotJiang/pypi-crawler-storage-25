"""Plugin SQL migrations — dedicated schema per plugin.

A plugin registers its migrations directory at ``plugin.register()`` time.
The loader picks up every ``*.sql`` file in alphabetical order, tracks the
applied set in ``public.plugins_registry.migrations_applied``, and runs
only the delta on subsequent boots (same pattern as the core
``schema_migrations`` runner).

**Idempotency is mandatory**: every migration SQL file MUST use
``CREATE TABLE IF NOT EXISTS``, ``ALTER TABLE ... ADD COLUMN IF NOT EXISTS``,
``CREATE SCHEMA IF NOT EXISTS``, etc. The loader refuses to run a plugin
whose migrations don't follow this pattern (best-effort static check).
"""

from __future__ import annotations

from typing import NamedTuple

_REGISTERED: list["MigrationSpec"] = []


class MigrationSpec(NamedTuple):
    namespace: str
    anchor_file: str  # typically ``__file__`` of the plugin package
    rel_dir: str      # relative to anchor_file's parent, e.g. "migrations/"


def register_schema(namespace: str, anchor_file: str, rel_dir: str) -> None:
    """Register a plugin's migrations directory.

    Args:
        namespace: the plugin's namespace — migrations are expected to
            create a PG schema of the same name (e.g. ``CREATE SCHEMA
            integrations_pennylane``).
        anchor_file: usually ``__file__`` — used to resolve ``rel_dir``.
        rel_dir: migrations directory relative to ``anchor_file``'s folder.
    """
    _REGISTERED.append(MigrationSpec(namespace, anchor_file, rel_dir))


def _drain() -> list[MigrationSpec]:
    collected = list(_REGISTERED)
    _REGISTERED.clear()
    return collected
