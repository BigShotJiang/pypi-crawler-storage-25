"""Runtime context injected into ``plugin.register(ctx)`` and into handlers/tools.

Carries the database handle, the current company and user, a logger, and
a bundle of registries the plugin uses to expose primitives (handlers,
tools, templates, migrations, i18n, connectors, scheduler, events).

The loader (T04) is responsible for wiring real implementations into the
registries. Stubs here raise :class:`NotImplementedError` with a clear
"wired by loader at boot" message — that way a unit test importing the
Context fails loudly if it forgets to inject a fake.
"""

from __future__ import annotations

from typing import Any, Optional

from pydantic import BaseModel, ConfigDict


class CompanyRef(BaseModel):
    """Minimal shape of the active company passed to plugin code."""

    id: str
    name: str
    slug: Optional[str] = None


class UserRef(BaseModel):
    """Minimal shape of the acting user. Absent at boot / scheduler runs."""

    id: str
    email: Optional[str] = None


# ---------------------------------------------------------------------------
# Registry stubs — the loader (T04) replaces these with real implementations
# ---------------------------------------------------------------------------


class _RegistryStub:
    """Base stub that raises a uniform error when used before wiring."""

    _NAME: str = "Registry"

    def _not_wired(self, method: str) -> "NotImplementedError":
        return NotImplementedError(
            f"{self._NAME}.{method}() is a stub — wired by loader at boot (T04)"
        )


class HandlerRegistry(_RegistryStub):
    _NAME = "HandlerRegistry"

    def register(self, handler_id: str, fn: Any) -> None:
        raise self._not_wired("register")


class ToolRegistry(_RegistryStub):
    _NAME = "ToolRegistry"

    def register(self, spec: dict[str, Any]) -> None:
        raise self._not_wired("register")


class TemplateRegistry(_RegistryStub):
    _NAME = "TemplateRegistry"

    def register(self, template: dict[str, Any]) -> None:
        raise self._not_wired("register")

    def load_dir(self, path: str) -> None:
        raise self._not_wired("load_dir")


class MigrationRegistry(_RegistryStub):
    _NAME = "MigrationRegistry"

    def register_schema(self, namespace: str, pyfile: str, rel_dir: str) -> None:
        raise self._not_wired("register_schema")


class I18nRegistry(_RegistryStub):
    _NAME = "I18nRegistry"

    def register_locales(self, namespace: str, pyfile: str, rel_dir: str) -> None:
        raise self._not_wired("register_locales")


class ConnectorRegistry(_RegistryStub):
    """Connectors declaration + runtime CRUD (SDK §3 line 7, spike 21/04)."""

    _NAME = "ConnectorRegistry"

    # Declaration (at register() time)
    def register_connector(self, spec: dict[str, Any]) -> None:
        raise self._not_wired("register_connector")

    # Runtime CRUD (called from handlers / tools / jobs)
    def list_connections(self, company_id: str) -> list[dict[str, Any]]:
        raise self._not_wired("list_connections")

    def get_connection(self, connection_id: str) -> Optional[dict[str, Any]]:
        raise self._not_wired("get_connection")

    def save_connection(
        self,
        company_id: str,
        label: str,
        credentials: dict[str, Any],
        config: Optional[dict[str, Any]] = None,
    ) -> dict[str, Any]:
        raise self._not_wired("save_connection")

    def update_sync_state(
        self,
        connection_id: str,
        *,
        last_sync_at: Any = None,
        next_sync_at: Any = None,
        status: Optional[str] = None,
    ) -> None:
        raise self._not_wired("update_sync_state")

    def log_sync(
        self,
        connection_id: str,
        status: str,
        items_count: int,
        duration_ms: int,
        error: Optional[str] = None,
    ) -> None:
        raise self._not_wired("log_sync")


class SchedulerRegistry(_RegistryStub):
    _NAME = "SchedulerRegistry"

    def register_job(self, job_id: str, handler: Any, schedule: str) -> None:
        raise self._not_wired("register_job")


class EventBus(_RegistryStub):
    _NAME = "EventBus"

    def on(self, event_name: str, callback: Any) -> None:
        raise self._not_wired("on")

    def emit(self, event_name: str, payload: dict[str, Any]) -> None:
        raise self._not_wired("emit")


# ---------------------------------------------------------------------------
# Context itself
# ---------------------------------------------------------------------------


class Context(BaseModel):
    """Runtime context passed to every plugin entry point.

    ⚠️ God-object surveillance (T02 / SDK_CHANGELOG): 10 sub-registries
    in v0.1. Split into sub-namespaces if we cross 12 in v0.2/v0.3.
    """

    model_config = ConfigDict(arbitrary_types_allowed=True)

    db: Any
    company: Optional[CompanyRef] = None  # None at register() time (boot), set at runtime
    user: Optional[UserRef] = None
    logger: Any

    # Registries: typed as Any in v0.1 so the loader can inject either the
    # stub classes declared below or the concrete implementations from
    # ``backend.services.plugin_runtime.registries``. Plugins should rely
    # on the duck-typed public methods documented in SDK_SPEC §3, not on
    # the Python class identity. If we ever want strict typing for IDE
    # autocomplete, we'll expose Protocols in v0.2.
    handlers: Any
    tools: Any
    templates: Any
    migrations: Any
    i18n: Any
    connectors: Any
    scheduler: Any
    events: Any

    # Session scope (PLT-8 generic plumbing — used by multi-connection plugins
    # like Pennylane Firm/Company). In v0.1 these are stubs; the loader wires
    # them to ``backend.agents.session.engine.session_manager``.
    def set_scope(
        self,
        plugin: str,
        *,
        connection_id: Optional[str] = None,
        connection_label: Optional[str] = None,
        scope_id: Optional[str] = None,
        scope_label: Optional[str] = None,
    ) -> None:
        raise NotImplementedError("Context.set_scope() — wired by loader at boot (T04)")

    def get_scope(self) -> Optional[dict[str, Any]]:
        raise NotImplementedError("Context.get_scope() — wired by loader at boot (T04)")

    def clear_scope(self) -> None:
        raise NotImplementedError("Context.clear_scope() — wired by loader at boot (T04)")


# ---------------------------------------------------------------------------
# Free helpers — thin re-exports kept here so plugins can do
#   ``from piilot.sdk.context import get_db, get_current_company``
# The loader replaces these at boot with context-var backed implementations.
# ---------------------------------------------------------------------------


def get_db() -> Any:
    raise NotImplementedError("piilot.sdk.context.get_db() — wired by loader at boot (T04)")


def get_current_company() -> CompanyRef:
    raise NotImplementedError(
        "piilot.sdk.context.get_current_company() — wired by loader at boot (T04)"
    )


def get_current_user() -> Optional[UserRef]:
    raise NotImplementedError(
        "piilot.sdk.context.get_current_user() — wired by loader at boot (T04)"
    )


def get_logger() -> Any:
    raise NotImplementedError(
        "piilot.sdk.context.get_logger() — wired by loader at boot (T04)"
    )
