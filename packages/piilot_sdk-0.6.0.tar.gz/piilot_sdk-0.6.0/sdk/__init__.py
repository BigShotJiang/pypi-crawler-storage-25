"""Piilot SDK — public contract for plugins.

A plugin MUST only import from ``piilot.sdk.*``. Any import from
``backend.*`` is refused at boot by the loader's AST check (best-effort
honor system — see T04).

Surface exposed here:

* :class:`Plugin`, :func:`load_manifest`, :class:`Context` — bootstrap primitives
* ``MANIFEST_SCHEMA``, ``MANIFEST_SCHEMA_VERSION``, ``RESERVED_NAMESPACES`` — contract metadata
* ``__version__`` — SDK version, semver

All other symbols live in the dedicated submodules (``piilot.sdk.handlers``,
``piilot.sdk.tools``, etc.).
"""

from __future__ import annotations

from piilot.sdk.context import Context
from piilot.sdk.plugin import (
    MANIFEST_SCHEMA,
    MANIFEST_SCHEMA_VERSION,
    RESERVED_NAMESPACES,
    Plugin,
    PluginManifestInvalid,
    load_manifest,
)

__version__ = "0.6.0"

__all__ = [
    "Context",
    "MANIFEST_SCHEMA",
    "MANIFEST_SCHEMA_VERSION",
    "Plugin",
    "PluginManifestInvalid",
    "RESERVED_NAMESPACES",
    "__version__",
    "load_manifest",
]
