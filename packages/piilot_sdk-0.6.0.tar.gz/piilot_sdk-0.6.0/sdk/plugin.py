"""Plugin base class, manifest loader and schema metadata.

The manifest lives in the ``[tool.piilot.plugin]`` section of the plugin's
``pyproject.toml`` (no separate ``plugin.yaml``). The loader fuses it with
the standard ``[project]`` metadata (name, version, license, authors,
homepage) into a single canonical dict before validation.

``load_manifest()`` is the entry point: a plugin author calls it from
their ``__init__.py`` to populate ``Plugin.manifest`` at class scope.
"""

from __future__ import annotations

import json
import logging
import tomllib
from pathlib import Path
from typing import Any, ClassVar

import jsonschema

logger = logging.getLogger(__name__)


MANIFEST_SCHEMA_VERSION: int = 1
"""Integer version of the manifest schema itself (not the plugin's version).

A bump of this constant happens only for non-backward-compatible changes
to the schema (required field addition, removal, rename). Optional
additions keep ``MANIFEST_SCHEMA_VERSION = 1`` and existing plugins
remain valid.
"""


RESERVED_NAMESPACES: frozenset[str] = frozenset({
    "piilot", "core", "sdk", "admin", "api", "public", "auth", "billing",
    "integrations", "agents", "modules", "knowledge", "users", "companies",
    "projects",
})
"""Namespaces reserved by the core. A plugin declaring one of these is refused at boot."""


# MANIFEST_SCHEMA is populated at module import by loading the JSON file
# next to this module (filled in by T03).
_SCHEMA_PATH = Path(__file__).parent / "schemas" / "plugin_manifest.schema.json"

if _SCHEMA_PATH.exists():
    MANIFEST_SCHEMA: dict[str, Any] = json.loads(_SCHEMA_PATH.read_text(encoding="utf-8"))
else:
    # During T02 scaffolding, the schema file is produced by T03.
    # Allow import to succeed so smoke tests pass; the loader (T04) will
    # fail loudly if someone tries to validate a manifest before the
    # schema file is in place.
    MANIFEST_SCHEMA = {}


class PluginManifestInvalid(Exception):
    """Raised when a plugin manifest fails JSON Schema validation."""

    def __init__(self, errors: list[str]) -> None:
        self.errors = errors
        super().__init__("; ".join(errors))


class Plugin:
    """Base class every Piilot plugin inherits from.

    A plugin's ``__init__.py`` typically looks like::

        from piilot.sdk import Plugin, load_manifest

        class MyPlugin(Plugin):
            manifest = load_manifest(__file__)

            def register(self, ctx):
                ctx.handlers.register("my_ns.do_thing", handler)
                ...

    The loader (T04) instantiates each plugin class once at boot, injects
    a :class:`Context`, and calls ``register()``. The base ``register()``
    raises ``NotImplementedError`` to catch oversight.
    """

    manifest: ClassVar[dict[str, Any]] = {}

    def register(self, ctx: "Context") -> None:  # noqa: F821 — forward ref
        raise NotImplementedError(
            f"{type(self).__name__}.register(ctx) must be implemented by the plugin"
        )


def load_manifest(pyproject_path_or_file: str | Path) -> dict[str, Any]:
    """Load and validate a plugin manifest from a ``pyproject.toml``.

    Accepts either the path to a ``pyproject.toml`` file, or ``__file__``
    of a module inside the plugin package (the function walks up parents
    until it finds a ``pyproject.toml``).

    The returned dict is the **fused** manifest: standard Python metadata
    from ``[project]`` (name, version, description, license, authors,
    homepage) merged with Piilot-specific keys from ``[tool.piilot.plugin]``
    (namespace, sdk_compat, provides, permissions, etc.).

    Raises:
        FileNotFoundError: ``pyproject.toml`` not found.
        PluginManifestInvalid: schema validation failed, ``.errors`` holds details.
        ValueError: ``[tool.piilot.plugin]`` section absent — caller should
            treat this as "not a Piilot plugin" and skip.
    """
    toml_path = _resolve_pyproject(Path(pyproject_path_or_file))

    raw = tomllib.loads(toml_path.read_text(encoding="utf-8"))

    project = raw.get("project", {})
    piilot_section = raw.get("tool", {}).get("piilot", {}).get("plugin")

    if piilot_section is None:
        raise ValueError(
            f"{toml_path} has no [tool.piilot.plugin] section — not a Piilot plugin"
        )

    manifest = _fuse_sections(project, piilot_section)

    if MANIFEST_SCHEMA:
        _validate(manifest)
    else:
        logger.warning(
            "plugin_manifest.schema.json not found — skipping validation (T03 not run yet)"
        )

    return manifest


# ---------------------------------------------------------------------------
# Internals
# ---------------------------------------------------------------------------


def _resolve_pyproject(hint: Path) -> Path:
    """Find the pyproject.toml starting from a hint (file or directory)."""
    hint = hint.resolve()
    if hint.is_file() and hint.name == "pyproject.toml":
        return hint
    # Walk up from the hint (works for __file__ of a module)
    start = hint if hint.is_dir() else hint.parent
    for candidate in [start, *start.parents]:
        pp = candidate / "pyproject.toml"
        if pp.exists():
            return pp
    raise FileNotFoundError(f"No pyproject.toml found starting from {hint}")


def _fuse_sections(project: dict[str, Any], piilot: dict[str, Any]) -> dict[str, Any]:
    """Merge [project] and [tool.piilot.plugin] into the canonical manifest dict."""
    authors = project.get("authors") or [{}]
    first_author = authors[0] if isinstance(authors, list) and authors else {}

    urls = project.get("urls", {})

    # Normalize SPDX license to lowercase (v0.3): PEP 639 recommends SPDX
    # title-case (``Apache-2.0``, ``MIT``, ``BSD-3-Clause``). The manifest
    # schema's enum historically only accepts lowercase; we lowercase the
    # incoming value so plugin authors can write either form in
    # ``[project].license``.
    raw_license = project.get("license")
    license_value = raw_license.lower() if isinstance(raw_license, str) else raw_license

    fused: dict[str, Any] = {
        # From [tool.piilot.plugin] — Piilot-specific, mandatory
        **piilot,
        # From [project] — standard Python metadata copied into canonical keys
        "name": project.get("name"),
        "version": project.get("version"),
        "description": project.get("description"),
        "license": license_value,
        "author": {
            "name": first_author.get("name"),
            "email": first_author.get("email"),
        },
        "homepage": urls.get("homepage") or urls.get("Homepage"),
    }

    return fused


def _validate(manifest: dict[str, Any]) -> None:
    """Validate a fused manifest against MANIFEST_SCHEMA. Raises on failure.

    ``format_checker`` is enabled so that ``format: email`` / ``format: uri``
    annotations in the schema are actually enforced (jsonschema skips them
    by default). See ``Draft202012Validator.FORMAT_CHECKER``.
    """
    validator = jsonschema.Draft202012Validator(
        MANIFEST_SCHEMA,
        format_checker=jsonschema.Draft202012Validator.FORMAT_CHECKER,
    )
    errors = sorted(validator.iter_errors(manifest), key=lambda e: list(e.path))
    if errors:
        raise PluginManifestInvalid([
            f"{'/'.join(str(p) for p in err.path) or '<root>'}: {err.message}"
            for err in errors
        ])
