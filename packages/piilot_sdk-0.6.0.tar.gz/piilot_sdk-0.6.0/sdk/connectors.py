"""Settings integrations — declaration + CRUD runtime (SDK §3 line 7).

Spike Pennylane + ESMS (21/04/2026) revealed that a plugin needs not
only to **declare** its connector in the manifest, but also to
**read/write** its live connections and sync logs at runtime. Both
concerns are exposed here in a single module (no separate
``piilot.sdk.connections`` — keeps the surface tight).

Declaration at ``plugin.register()``::

    from piilot.sdk.connectors import register_connector

    register_connector({
        "id": "pennylane.api",
        "auth_type": "api_key",
        "credentials_schema": [
            {"name": "api_key", "type": "secret", "required": True},
        ],
    })

Runtime CRUD (called from handlers / tools / jobs)::

    from piilot.sdk.connectors import (
        list_connections, get_connection, save_connection,
        update_sync_state, delete_connection,
        list_connections_due_for_sync, log_sync,
    )

Credentials auto-encryption
---------------------------

When a plugin calls :func:`save_connection`, each field of the
``credentials`` dict is compared against the plugin's declared
``credentials_schema`` (from its ``register_connector`` call). Fields
marked ``{"type": "secret"}`` are **transparently encrypted** before
being persisted. Non-secret fields (``token_expires_at``, ``scopes``,
``external_account_id``, …) are stored in clear in the connection row.

If a plugin's schema declares a field that doesn't map to a dedicated
connection column (``access_token_encrypted``, ``refresh_token_encrypted``,
``token_expires_at``, ``scopes``, ``external_account_id``), the extra
field ends up in the JSONB ``config`` column. Secrets in ``config`` are
also encrypted.
"""

from __future__ import annotations

import logging
from typing import Any, Optional

logger = logging.getLogger(__name__)

_REGISTERED: list[dict[str, Any]] = []

# Maps plugin namespace → aggregated credentials_schema (list of field dicts
# across all connectors registered by that plugin). Populated by
# :func:`register_connector` (which reads the ``current_plugin`` contextvar)
# and consumed at runtime by the wired :func:`save_connection` to decide
# which fields to auto-encrypt.
_SCHEMA_BY_NAMESPACE: dict[str, list[dict[str, Any]]] = {}


def register_connector(spec: dict[str, Any]) -> None:
    """Declare a connector. Called during ``plugin.register()``.

    Expected spec shape::

        {
            "id": "pennylane.api",             # MUST be namespaced
            "auth_type": "api_key" | "oauth2" | "basic" | "custom",
            "credentials_schema": [
                {"name": "api_key", "type": "secret", "required": True},
                {"name": "token_expires_at", "type": "datetime"},
                ...
            ],
        }

    The ``credentials_schema`` drives the auto-encryption of secrets in
    :func:`save_connection` — any field with ``type == "secret"`` is
    encrypted transparently before reaching the DB.
    """
    if "id" not in spec or "auth_type" not in spec:
        raise ValueError("connector spec must contain 'id' and 'auth_type'")
    _REGISTERED.append(spec)

    # Index the credentials_schema by plugin namespace so save_connection
    # can lookup which fields to auto-encrypt.
    # The host (loader / middleware / scheduler) sets ``current_plugin``
    # contextvar around any plugin entry point — see piilot.sdk._runtime.
    from piilot.sdk._runtime import current_plugin
    ns = current_plugin.get()

    if ns is not None:
        schema = spec.get("credentials_schema") or []
        bucket = _SCHEMA_BY_NAMESPACE.setdefault(ns, [])
        # Merge (last-wins on duplicate names)
        existing_names = {f.get("name") for f in bucket}
        for field in schema:
            name = field.get("name")
            if name in existing_names:
                # Replace existing field — last declaration wins
                bucket[:] = [f for f in bucket if f.get("name") != name]
            bucket.append(field)


def _drain() -> list[dict[str, Any]]:
    collected = list(_REGISTERED)
    _REGISTERED.clear()
    return collected


def _get_schema_for_namespace(namespace: str) -> list[dict[str, Any]]:
    """Internal — returns the aggregated credentials_schema for a plugin.

    Used by the wired :func:`save_connection` to decide which fields to
    auto-encrypt. Returns an empty list if the plugin hasn't called
    :func:`register_connector`.
    """
    return list(_SCHEMA_BY_NAMESPACE.get(namespace, []))


def _reset_schema_registry_for_tests() -> None:
    """Test helper — clear the schema registry between tests."""
    _SCHEMA_BY_NAMESPACE.clear()


# ---------------------------------------------------------------------------
# Runtime CRUD — wired by the loader via ``sdk_wiring._wire_connectors()``.
# Signatures below are the authoritative contract; implementations live in
# ``backend/services/plugin_runtime/sdk_wiring.py``.
# ---------------------------------------------------------------------------


def list_connections(
    company_id: str,
    *,
    provider: Optional[str] = None,
) -> list[dict[str, Any]]:
    """List active connections of the tenant.

    When ``provider`` is given, restricts to that provider.
    """
    raise NotImplementedError("list_connections() — wired by loader at boot")


def get_connection(connection_id: str) -> Optional[dict[str, Any]]:
    """Fetch a connection by id. Fields marked ``type: secret`` are returned encrypted —
    call ``piilot.sdk.crypto.decrypt`` explicitly to read the plaintext."""
    raise NotImplementedError("get_connection() — wired by loader at boot")


def save_connection(
    company_id: str,
    provider: str,
    auth_type: str,
    label: str,
    credentials: dict[str, Any],
    config: Optional[dict[str, Any]] = None,
    *,
    connection_id: Optional[str] = None,
) -> dict[str, Any]:
    """Create or update a connection.

    Auto-encryption contract: each field of ``credentials`` is compared
    against the plugin's declared ``credentials_schema`` (from its
    ``register_connector`` call). Fields with ``type == "secret"`` are
    transparently encrypted via :func:`piilot.sdk.crypto.encrypt` before
    being persisted. Plugins pass plaintext values.

    Known mapping for non-secret fields (go to dedicated columns):

    - ``access_token`` (secret) → ``access_token_encrypted`` column
    - ``refresh_token`` (secret) → ``refresh_token_encrypted`` column
    - ``api_key`` (secret) → ``access_token_encrypted`` column
    - ``token_expires_at`` → dedicated column (not encrypted)
    - ``scopes`` → dedicated column (not encrypted)
    - ``external_account_id`` → dedicated column (not encrypted)

    Any other field ends up in the JSONB ``config`` column. Secrets
    declared there are also encrypted. The ``config`` parameter merges
    with fields routed to config from ``credentials``.

    ``connection_id``: when ``None``, creates. When provided, updates
    that specific connection (within the tenant).

    Returns the persisted connection row.
    """
    raise NotImplementedError("save_connection() — wired by loader at boot")


def update_sync_state(
    connection_id: str,
    *,
    last_sync_at: Any = None,
    next_sync_at: Any = None,
    status: Optional[str] = None,
) -> None:
    """Idempotent update of the sync-tracking fields on a connection."""
    raise NotImplementedError("update_sync_state() — wired by loader at boot")


def delete_connection(connection_id: str) -> bool:
    """Delete a connection. Returns True if a row was removed.

    Hard delete — cascades to ``integrations_master.sync_logs`` via FK.
    """
    raise NotImplementedError("delete_connection() — wired by loader at boot")


def list_connections_due_for_sync(
    provider: Optional[str] = None,
) -> list[dict[str, Any]]:
    """List all active connections whose ``next_sync_at`` has passed.

    When ``provider`` is given, restricts to that provider. When ``None``,
    returns due connections across all providers (used by the generic
    scheduler dispatcher — see Lot 5). Includes encrypted credentials
    fields, ready for the sync handler to decrypt and use.
    """
    raise NotImplementedError(
        "list_connections_due_for_sync() — wired by loader at boot"
    )


def log_sync(
    connection_id: str,
    company_id: str,
    sync_type: str,
    status: str,
    started_at: Any,
    completed_at: Any,
    *,
    items_synced: int = 0,
    items_failed: int = 0,
    error_message: Optional[str] = None,
    s3_path: Optional[str] = None,
) -> dict[str, Any]:
    """Append a run entry to ``integrations_master.sync_logs``.

    ``sync_type`` values: ``"full"``, ``"firm_full"``, ``"incremental"``,
    ``"manual"``. ``status`` values: ``"success"``, ``"partial"``, ``"error"``.

    Returns the created sync_log row (with auto-generated ``id``).
    """
    raise NotImplementedError("log_sync() — wired by loader at boot")


def set_active(connection_id: str, is_active: bool) -> bool:
    """Flip ``integrations_master.connections.is_active``.

    New in v0.3 — addresses the dogfood pain point where a plugin had
    no way to disable a broken connection (e.g. refresh-token rotation
    failed, Pennylane returns 401) without dropping down to raw SQL.
    Typical flow: plugin catches the auth error, calls
    ``set_active(conn_id, False)`` + ``log_sync(..., status="error")``,
    user reconnects via the plugin UI.

    Returns ``True`` when a row was updated, ``False`` when the
    connection_id is unknown. Does not cascade to ``sync_logs`` — the
    history is preserved.
    """
    raise NotImplementedError("set_active() — wired by loader at boot")


def update_config(connection_id: str, patch: dict[str, Any]) -> dict[str, Any]:
    """Merge ``patch`` into ``integrations_master.connections.config`` (JSONB).

    New in v0.3 — saves plugins ~50 lines of boilerplate per PATCH
    route. ``patch`` keys override existing keys (shallow merge, not
    deep); ``None`` values delete the key. The rest of the ``config``
    dict is preserved. Merge semantics match the dogfood contract
    (Pennylane's ``entity_scopes`` stored in ``config`` — see Lot D).

    Returns the updated connection row. Raises ``ValueError`` if
    ``connection_id`` is unknown.
    """
    raise NotImplementedError("update_config() — wired by loader at boot")
