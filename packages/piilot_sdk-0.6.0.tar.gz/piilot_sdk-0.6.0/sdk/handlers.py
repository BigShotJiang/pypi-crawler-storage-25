"""Module handlers — deterministic pipelines exposed via ``modules``.

A handler is a sync or async callable ``(ctx, payload) -> dict`` referenced
by a ``manifest.provides.modules[].id``. The loader indexes handlers by id
and dispatches module runs to them.

Decorator usage (plugin side)::

    from piilot.sdk.handlers import register_handler

    @register_handler("my_ns.do_thing")
    def my_handler(ctx, payload):
        return {"status": "ok"}
"""

from __future__ import annotations

from typing import Any, Callable

# Module-level registry: populated by the decorator, drained by the loader.
_REGISTERED: dict[str, Callable[..., Any]] = {}


def register_handler(handler_id: str) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """Decorator: register a handler under ``handler_id``.

    The id MUST be namespaced (``<namespace>.<name>``). Collision detection
    is done by the loader at boot, not here — two plugins with the same
    namespace would crash anyway at namespace-uniqueness check time.
    """

    def decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
        if handler_id in _REGISTERED:
            raise ValueError(
                f"handler id '{handler_id}' already registered at import time"
            )
        _REGISTERED[handler_id] = fn
        return fn

    return decorator


def _drain() -> dict[str, Callable[..., Any]]:
    """Internal — called by the loader to collect & clear the registry."""
    collected = dict(_REGISTERED)
    _REGISTERED.clear()
    return collected
