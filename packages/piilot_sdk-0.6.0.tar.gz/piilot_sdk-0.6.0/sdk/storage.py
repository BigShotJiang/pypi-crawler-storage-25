"""S3-compatible object storage for plugins.

All primitives are **async**. Keys are automatically prefixed with the
plugin namespace (``plugins/{namespace}/{key}``) so plugins cannot
accidentally read or overwrite each other's objects.

The target bucket is fixed to the core's documents bucket (``DOCUMENTS_BUCKET``
— ``"piilot-documents"``). Plugins do not choose the bucket — that's a
core concern (multi-tenant S3 endpoint resolution, lifecycle rules, etc.).
Multi-bucket support planned for v0.3+ if a use case emerges.

Under the hood: the wired implementations delegate to
``backend.services.storage.storage_service.async_{upload,download,delete}_file``.

Plugin context requirement
--------------------------

Every primitive resolves the active plugin's namespace from
``piilot.sdk._runtime.current_plugin``. Calling these from outside a
plugin entry point raises ``RuntimeError``.
"""

from __future__ import annotations

from typing import Any


async def put_object(
    key: str,
    body: bytes,
    content_type: str = "application/octet-stream",
) -> str:
    """Upload an object. Returns the full effective key (with namespace prefix).

    The effective key is ``plugins/{namespace}/{key}`` — use the returned
    string if you need to persist the path (e.g. in a ``sync_logs.s3_path``
    column).

    ``body`` is the raw bytes to upload. For JSON, serialize and encode
    yourself: ``json.dumps(data).encode("utf-8")``.
    """
    raise NotImplementedError("storage.put_object() — wired by loader at boot")


async def get_object(key: str) -> bytes:
    """Download an object as raw bytes.

    Raises if the key doesn't exist. ``key`` is auto-prefixed with the
    plugin namespace.
    """
    raise NotImplementedError("storage.get_object() — wired by loader at boot")


async def delete_object(key: str) -> None:
    """Delete an object. ``key`` is auto-prefixed with the plugin namespace.

    Idempotent (no error if the key is already absent).
    """
    raise NotImplementedError("storage.delete_object() — wired by loader at boot")


# ---------------------------------------------------------------------------
# Reserved — v0.3+
# ---------------------------------------------------------------------------


def get_s3_client() -> Any:
    """Return the raw boto3-compatible S3 client.

    Reserved for v0.3+. In v0.2 this remains a stub — direct client access
    would bypass the namespace prefix and bucket selection, so we don't
    expose it yet. Use the high-level ``put_object`` / ``get_object`` /
    ``delete_object`` instead.
    """
    raise NotImplementedError(
        "get_s3_client() — reserved for v0.3+. Use the high-level storage primitives."
    )
