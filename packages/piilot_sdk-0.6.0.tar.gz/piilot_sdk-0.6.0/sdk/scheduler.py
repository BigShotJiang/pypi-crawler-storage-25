"""Periodic / connector-driven jobs — sync loops, background tasks.

v0.2 scope (Lot 5)
------------------

The primary API in v0.2 is :func:`register_sync_handler` — plugins declare
a handler to be invoked by the core scheduler when one of their
connector connections reaches ``next_sync_at``. Dispatch is keyed by
``connection.provider``; each provider can have a regular handler and
an optional "firm mode" handler (used by multi-client connectors like
accounting-firm Pennylane tokens).

::

    # In Plugin.register():
    from .sync import sync_myplug, sync_myplug_firm
    ctx.scheduler.register_sync_handler(
        "myplug",
        handler=sync_myplug,
        firm_handler=sync_myplug_firm,  # optional
    )

The core scheduler polls ``connections_repo.list_due_for_sync`` every
60 seconds and calls the registered handler with the connection dict.
``current_plugin`` is set around each handler call so SDK primitives
(cache / storage / save_connection / log_sync) resolve the plugin
namespace correctly.

v0.3+ — :func:`register_job`
----------------------------

The generic-job primitive (interval / daily / cron schedules) is in
this module's surface already (v0.1 stub retained) but the core does
**not execute** registered jobs in v0.2 — only connector-based sync
dispatches. Registered jobs accumulate but never fire. Use
:func:`register_sync_handler` for Pennylane-style dogfood; wait for
v0.3 if you need plain recurring tasks.
"""

from __future__ import annotations

from typing import Any, Awaitable, Callable, NamedTuple, Optional

from piilot.sdk._runtime import current_plugin


# ---------------------------------------------------------------------------
# register_sync_handler — primary v0.2 API
# ---------------------------------------------------------------------------


# provider → (namespace, handler, firm_handler_or_None)
_PENDING_SYNC_HANDLERS: dict[
    str,
    tuple[str, Callable[..., Awaitable[Any]], Optional[Callable[..., Awaitable[Any]]]],
] = {}


def register_sync_handler(
    provider: str,
    handler: Callable[[dict], Awaitable[Any]],
    firm_handler: Optional[Callable[[dict], Awaitable[Any]]] = None,
) -> None:
    """Register a sync handler for a given connector ``provider``.

    The core scheduler polls ``connections_repo.list_due_for_sync()``
    every 60 seconds and dispatches each due connection to its
    provider's registered handler:

    * If ``connection.config.mode == "firm"`` and ``firm_handler`` is
      set → ``firm_handler(connection)`` is awaited.
    * Otherwise ``handler(connection)`` is awaited.

    The handler must be an async function returning a dict (by
    convention, the created ``sync_logs`` row, so the scheduler can
    log a short summary).

    Duplicate provider registration raises ``ValueError`` — if you
    need to replace a handler (e.g. Pennylane migrating from in-tree
    to plugin), the old registration must be removed first by the host.

    Called from ``Plugin.register(ctx)`` as the module-level function::

        from piilot.sdk.scheduler import register_sync_handler
        register_sync_handler("myplug", handler=sync_fn)

    Note: there is no ``ctx.scheduler.register_sync_handler`` — the
    primitive lives at module level to mirror the other SDK
    registries (``tools``, ``templates``, ``modules``).
    """
    ns = current_plugin.get()
    if ns is None:
        raise RuntimeError(
            "register_sync_handler called outside plugin context."
        )
    if provider in _PENDING_SYNC_HANDLERS:
        existing_ns = _PENDING_SYNC_HANDLERS[provider][0]
        raise ValueError(
            f"sync handler for provider '{provider}' already registered "
            f"(by '{existing_ns}') — cannot register again from '{ns}'"
        )
    _PENDING_SYNC_HANDLERS[provider] = (ns, handler, firm_handler)


def _drain_sync_handlers() -> dict[
    str,
    tuple[str, Callable[..., Awaitable[Any]], Optional[Callable[..., Awaitable[Any]]]],
]:
    """Internal — snapshot of registered handlers for the core scheduler.

    Unlike ``_drain`` on other SDK modules this does NOT clear the
    registry. The scheduler loop keeps running for the lifetime of the
    process and references the dict throughout. Clearing would disable
    all plugins' sync at boot-end.
    """
    return dict(_PENDING_SYNC_HANDLERS)


def _register_in_tree_handler(
    provider: str,
    namespace: str,
    handler: Callable[[dict], Awaitable[Any]],
    firm_handler: Optional[Callable[[dict], Awaitable[Any]]] = None,
) -> None:
    """Host-only escape hatch: register a handler without a plugin context.

    Used by ``api/main.py`` during the Pennylane transition window — the
    in-tree ``sync_pennylane`` code lives under a fictional ``pennylane``
    namespace until extracted to an external plugin. Plugins MUST NOT
    call this; use :func:`register_sync_handler`.

    Same duplicate-detection as the public API.
    """
    if provider in _PENDING_SYNC_HANDLERS:
        existing_ns = _PENDING_SYNC_HANDLERS[provider][0]
        raise ValueError(
            f"sync handler for provider '{provider}' already registered "
            f"(by '{existing_ns}')"
        )
    _PENDING_SYNC_HANDLERS[provider] = (namespace, handler, firm_handler)


def _reset_sync_handlers_for_tests() -> None:
    """Test helper — clear the registry between tests."""
    _PENDING_SYNC_HANDLERS.clear()


# ---------------------------------------------------------------------------
# register_job — v0.1 stub, NOT executed in v0.2
# ---------------------------------------------------------------------------


_REGISTERED: list["JobSpec"] = []


class JobSpec(NamedTuple):
    job_id: str
    handler: Callable[..., Any]
    schedule: str  # e.g. "daily", "twice_daily", "3600s", cron-like


def register_job(job_id: str, handler: Callable[..., Any], schedule: str) -> None:
    """Register a recurring job.

    .. warning::
       In v0.2 the core scheduler does **not execute** registered jobs —
       only connector-based sync via :func:`register_sync_handler` is
       dispatched. Jobs registered here accumulate in the registry but
       never fire. Full execution (with ``schedule`` string parsing for
       ``"daily"`` / ``"twice_daily"`` / interval / cron) arrives in v0.3.

       Use :func:`register_sync_handler` for Pennylane-style dogfood.
    """
    _REGISTERED.append(JobSpec(job_id, handler, schedule))


def _drain() -> list[JobSpec]:
    collected = list(_REGISTERED)
    _REGISTERED.clear()
    return collected
