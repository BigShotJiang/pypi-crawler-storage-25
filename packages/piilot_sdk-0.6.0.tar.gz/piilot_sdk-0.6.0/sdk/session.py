"""Agent session state — multi-turn conversation context for plugin tools.

When an LLM agent invokes a plugin-provided tool, the tool often needs to
read or write conversation state that persists across the turn — the
active integration connection, the selected firm client, user info, etc.
That state lives in the core ``session_manager`` (``backend.agents.session.engine``);
this module exposes the pieces plugins are allowed to touch.

Context requirement
-------------------

``set_scope`` requires a ``plugin`` argument which must match
``current_plugin.get()`` — a plugin can't overwrite another plugin's
scope. ``get`` / ``get_scope`` / ``clear_scope`` don't enforce this
because reading/wiping one's own scope is always legitimate, and the
returned scope dict is read-only from the plugin's perspective anyway.

v0.2 scope (Lot 6)
------------------

All four primitives are passthroughs to the core ``session_manager``
singleton. ``SessionState`` is re-exported as-is so plugin code can use
it in type hints.
"""

from __future__ import annotations

from typing import Any, Optional


# Re-exported types (wired at boot to the real SessionState class)

SessionState: Any = None  # set by sdk_wiring._wire_session()


def get(session_id: str) -> Optional[Any]:
    """Return the current :class:`SessionState` for ``session_id``, or None.

    None on:

    * unknown session (never started)
    * session ended (explicit ``end_session`` or TTL expired)

    The returned state is read-only from the plugin's perspective — use
    dedicated primitives to mutate (``set_scope``, ``clear_scope``).
    """
    raise NotImplementedError("session.get() — wired by loader at boot")


def get_scope(session_id: str) -> Optional[dict[str, Any]]:
    """Return the active scope dict, or None if no scope is set.

    Shape: ``{"plugin": str, "connection_id": str?, "connection_label": str?,
    "scope_id": str?, "scope_label": str?}``.
    """
    raise NotImplementedError("session.get_scope() — wired by loader at boot")


def set_scope(
    session_id: str,
    plugin: str,
    *,
    connection_id: Optional[str] = None,
    connection_label: Optional[str] = None,
    scope_id: Optional[str] = None,
    scope_label: Optional[str] = None,
) -> None:
    """Set (merge-update) the active scope for a session.

    ``plugin`` must match the caller's ``current_plugin`` context — a
    plugin cannot set scope under another plugin's name. Raises
    ``PermissionError`` otherwise.

    Merge semantics (inherited from ``session_manager.set_scope``):

    * Passing ``connection_id`` rewrites the connection axis AND resets
      ``scope_id`` / ``scope_label`` (a sub-scope of one connection
      doesn't exist in another).
    * Passing only ``scope_id`` updates the sub-scope axis, keeping
      the current connection.
    * If the session switches plugin (``plugin`` arg differs from the
      existing scope's plugin), the scope is wiped and restarted.
    """
    raise NotImplementedError("session.set_scope() — wired by loader at boot")


def clear_scope(session_id: str) -> None:
    """Remove any active scope from the session. Idempotent."""
    raise NotImplementedError(
        "session.clear_scope() — wired by loader at boot"
    )
