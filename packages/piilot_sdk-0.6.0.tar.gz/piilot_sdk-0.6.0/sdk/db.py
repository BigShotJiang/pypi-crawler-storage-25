"""Direct database access for plugins.

The SDK high-level registries (``connectors``, ``modules``, ``templates``)
cover 80% of plugin needs, but some plugins require direct SQL — custom
aggregations, fuzzy searches, cross-table joins, batch upserts against
plugin-owned schemas. This module exposes the thin set of primitives
needed for that.

v0.2 scope — **passthrough, trust-based**
-----------------------------------------

* ``run_in_thread`` — critical wrapper that propagates the RLS user
  context from the event-loop thread into the worker thread. Plugins
  **MUST** use this rather than calling ``asyncio.to_thread`` directly.
* ``cursor()`` — context manager yielding a ``RealDictCursor``. Commits
  on success, rolls back on exception. RLS context is set transparently.
* ``execute_values`` / ``Json`` — re-exports of the psycopg2 helpers a
  plugin would otherwise need to import from ``psycopg2.extras``
  (potentially awkward in a plugin that wants to stay minimal on deps).

Not yet in v0.2 (reserved for v0.3+ once Pennylane dogfood confirms the
real needs):

* ``readonly=True`` transactions
* ``statement_timeout`` per-cursor
* ``search_path`` restriction from manifest ``permissions.reads/writes``
* SQL parser to block tables outside the plugin's declared scope

In v0.2, the RLS policies on sensitive tables (``public.users``,
``public.companies_plugins``, tenant-partitioned data, etc.) provide the
security floor. Plugin-owned schemas (``integrations_pennylane.*``,
``esms.*``, …) are the plugin's to manage.

Usage
-----

::

    from piilot.sdk.db import cursor, execute_values, Json, run_in_thread

    def list_invoices(connection_id: str) -> list[dict]:
        with cursor() as cur:
            cur.execute(
                "SELECT * FROM integrations_pennylane.invoices "
                "WHERE connection_id = %s ORDER BY issue_date DESC",
                (connection_id,),
            )
            return cur.fetchall()

    async def list_invoices_async(connection_id: str) -> list[dict]:
        # Run the sync function above in a thread pool, preserving RLS context
        return await run_in_thread(list_invoices, connection_id)

    def batch_upsert(connection_id: str, rows: list[dict]) -> int:
        with cursor() as cur:
            execute_values(
                cur,
                '''INSERT INTO integrations_pennylane.invoices
                   (id, connection_id, data)
                   VALUES %s
                   ON CONFLICT (id) DO UPDATE SET data = EXCLUDED.data''',
                [(r["id"], connection_id, Json(r)) for r in rows],
            )
            return cur.rowcount
"""

from __future__ import annotations

from contextlib import contextmanager
from typing import Any, Callable, Iterator


async def run_in_thread(fn: Callable[..., Any], *args: Any, **kwargs: Any) -> Any:
    """Execute a blocking sync function in a thread pool.

    **CRITICAL**: use this rather than ``asyncio.to_thread`` directly.
    The Piilot core uses a ``threading.local()`` to propagate the RLS
    user context across threads. Calling ``asyncio.to_thread`` bypasses
    that propagation, causing queries to run without an RLS user — which
    either blocks them entirely (policies that require ``current_user_id``)
    or, in the worst case, lets the query see cross-tenant data.

    Always wrap sync DB calls from async code with this helper.
    """
    raise NotImplementedError("run_in_thread() — wired by loader at boot")


@contextmanager
def cursor() -> Iterator[Any]:
    """Acquire a DB cursor within a managed transaction.

    Yields a ``psycopg2.extras.RealDictCursor`` — rows come back as dicts
    keyed by column name. The transaction commits when the context exits
    normally, rolls back on exception.

    Not async — call from a sync function, wrap the whole sync function
    in :func:`run_in_thread` if you need to await from a coroutine.

    The cursor inherits the RLS user context of the caller thread.
    """
    raise NotImplementedError("cursor() — wired by loader at boot")


# Re-exports wired at boot. Declared here so plugin code can
# ``from piilot.sdk.db import execute_values, Json`` directly.

def execute_values(
    cur: Any,
    sql: str,
    rows: Any,
    template: Any = None,
    page_size: int = 100,
) -> None:
    """Batch ``INSERT`` / ``UPDATE`` via psycopg2's ``execute_values``.

    Passthrough of ``psycopg2.extras.execute_values`` — signature
    identical. Use for bulk writes:

    ::

        execute_values(
            cur,
            "INSERT INTO myplug.t (id, name) VALUES %s",
            [(r["id"], r["name"]) for r in rows],
            page_size=500,
        )
    """
    raise NotImplementedError("execute_values() — wired by loader at boot")


class _JsonPlaceholder:
    """Placeholder for psycopg2.extras.Json. Replaced at wire-time.

    Using a placeholder class (rather than a ``NotImplementedError`` raiser)
    so that ``Json`` is usable in type hints / isinstance checks before
    the wiring runs — but actually *calling* it before wiring fails loudly.
    """
    def __init__(self, *args: Any, **kwargs: Any) -> None:
        raise NotImplementedError("Json — wired by loader at boot")


Json: Any = _JsonPlaceholder
