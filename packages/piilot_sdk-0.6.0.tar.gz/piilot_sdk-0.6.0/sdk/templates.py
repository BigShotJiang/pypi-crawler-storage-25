"""Agent templates — seed agents exposed to builders.

Two usage patterns:

1. **Declarative** (preferred): declare ``agent_templates_dir`` in the
   manifest and drop ``*.json`` files in that folder. The loader
   auto-discovers them at boot.
2. **Programmatic**: call :func:`register_template` at
   ``plugin.register()`` time. Useful for templates derived from config
   or for ensuring idempotent seeds across plugin versions.

v0.2 (Lot 6) — ``register_template`` now performs an **idempotent
upsert** against ``agents.agent_templates`` keyed on the template's
``id`` (UUID). Re-registering with the same ``id`` updates the row;
different ``id`` creates a new one. A plugin re-installing / upgrading
can re-call ``register_template`` without worrying about duplicate rows.
"""

from __future__ import annotations

from typing import Any, Literal


# Buffered templates between ``register_template`` and the boot-time
# upsert that the core runs after ``plugin.register()`` returns.
_REGISTERED: list[dict[str, Any]] = []


OnDuplicate = Literal["replace", "skip", "raise"]


def register_template(
    template: dict[str, Any],
    *,
    on_duplicate: OnDuplicate = "replace",
) -> None:
    """Register (idempotent upsert) an agent template.

    Required keys:

    * ``id`` — UUID string (stable across installs, drives the upsert
      conflict key).
    * ``slug`` — must be namespaced (e.g. ``"pennylane-firm-assistant"``).

    Common optional keys: ``name``, ``description``, ``system_prompt``,
    ``tools`` (list of tool ids), ``model``, ``temperature``, ``scope``
    (``"global"`` / ``"company"`` / ``"project"``), ``category``. See
    ``agents.agent_templates`` for the full schema.

    ``on_duplicate`` (new in v0.3): ``"replace"`` (default) drops the
    existing entry and appends the new one, ``"skip"`` keeps the old,
    ``"raise"`` raises :class:`ValueError`. The DB-level upsert run by
    the loader is unchanged (ON CONFLICT (id) DO UPDATE); this control
    targets the in-memory buffer between ``register_template`` and the
    boot-time drain.

    Raises ``ValueError`` on missing ``id`` / ``slug``.
    """
    if "id" not in template:
        raise ValueError("agent template dict must have an 'id' key (UUID)")
    if "slug" not in template:
        raise ValueError("agent template dict must have a 'slug' key")

    template_id = template["id"]
    existing_idx = next(
        (i for i, t in enumerate(_REGISTERED) if t.get("id") == template_id),
        None,
    )
    if existing_idx is not None:
        if on_duplicate == "skip":
            return
        if on_duplicate == "raise":
            raise ValueError(f"template with id={template_id!r} already registered")
        _REGISTERED.pop(existing_idx)

    _REGISTERED.append(template)


def load_templates_dir(path: str) -> None:
    """Programmatic dir load — stub. The loader does auto-discovery itself
    via ``manifest.provides.agent_templates_dir``; this helper is kept
    for edge cases (e.g. conditional template sets)."""
    raise NotImplementedError(
        "load_templates_dir() — wired by loader at boot (T04)"
    )


def _drain() -> list[dict[str, Any]]:
    collected = list(_REGISTERED)
    _REGISTERED.clear()
    return collected


# Wired at boot by ``sdk_wiring._wire_templates``.
def _upsert_template(template: dict[str, Any]) -> None:
    """Internal — upsert the template row in ``agents.agent_templates``.

    ``ON CONFLICT (id) DO UPDATE`` on every key of ``template`` except
    ``id`` itself. Wired to the core's psycopg connection at boot.
    """
    raise NotImplementedError("_upsert_template — wired by loader at boot")
