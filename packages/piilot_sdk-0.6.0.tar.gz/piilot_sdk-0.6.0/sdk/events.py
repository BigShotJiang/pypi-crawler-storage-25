"""Lifecycle hooks — synchronous in-process event bus.

Events are emitted by the core on lifecycle transitions
(``company.created``, ``user.onboarded``, etc.). Plugins subscribe via
the ``@on_event`` decorator; handlers are called synchronously, in
registration order, during the request that emitted the event.

Convention: event names are ``dot-separated`` past-tense
(``company.created``, not ``on_company_created``).

Known v0.1 events (the core publishes these; the list will grow):

* ``company.created``  — fired after a new company is persisted
* ``user.onboarded``   — first full membership established
* ``plugin.enabled``   — a plugin was enabled for a company
* ``plugin.disabled``  — a plugin was disabled for a company
"""

from __future__ import annotations

from typing import Any, Callable

# event_name -> list of callables
_REGISTERED: dict[str, list[Callable[..., Any]]] = {}


def on_event(event_name: str) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """Decorator: subscribe to a lifecycle event.

    Example::

        from piilot.sdk.events import on_event

        @on_event("company.created")
        def seed_defaults(payload):
            ...
    """

    def decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
        _REGISTERED.setdefault(event_name, []).append(fn)
        return fn

    return decorator


def _drain() -> dict[str, list[Callable[..., Any]]]:
    collected = {k: list(v) for k, v in _REGISTERED.items()}
    _REGISTERED.clear()
    return collected
