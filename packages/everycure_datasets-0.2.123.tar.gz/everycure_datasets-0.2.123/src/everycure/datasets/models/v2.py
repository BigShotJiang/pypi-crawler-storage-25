"""Dataset Metadata v2 - Refined version (placeholder for future improvements)."""

from everycure.datasets.models.v1 import DatasetMetadataV1
import pandera.pandas as pa

PANDERA_TYPE_MAP: dict[str, type] = {
    "string": str,
    "int": int,
    "integer": int,
    "float": float,
    "bool": bool,
    "boolean": bool,
}

class DatasetMetadataV2(DatasetMetadataV1):
    """
    Dataset Metadata v2.

    This is a placeholder for a future refined version of the dataset metadata model.
    When v2 is implemented, it will include improvements and refinements over v1.

    For now, this class inherits from v1 to maintain compatibility.
    """

    # TODO: Add v2-specific fields and improvements here
    # Examples of potential improvements:
    # - Better validation
    # - Additional metadata fields
    # - Improved lineage tracking
    # - Enhanced schema definitions

    model_config = {
        "extra": "forbid",
        "json_schema_extra": {
            "$schema": "http://json-schema.org/2020-12/schema#",
            "$id": "https://everycure.org/schemas/dataset.v2.schema.json",
            "title": "Dataset Metadata v2",
            "description": "Schema for dataset registry metadata files (v2)",
        },
    }

    def to_pandera_schema(self) -> pa.DataFrameSchema:
        """Convert this metadata object's column definitions to a Pandera schema."""
        ds = self.dataset_schema
        if not ds or not ds.columns:
            raise ValueError(f"No schema columns defined for dataset '{self.name}'")

        columns: dict[str, pa.Column] = {}
        for col in ds.columns:
            dtype = PANDERA_TYPE_MAP.get(col.type.lower(), str)
            columns[col.name] = pa.Column(
                dtype=dtype,
                # TODO: Add nullability to the dataset schema. For now, we assume all columns are nullable. 
                nullable=True,
                description=col.description,
            )

        return pa.DataFrameSchema(columns=columns, strict=True)
