import logging
import subprocess

from everycure.datasets.kedro.catalog_dataset import DataCatalogDataset


def next_version(dataset: str, bump_type: str = "minor") -> str:
    """Return the next version for the named dataset.

    Auto-registered as the OmegaConf resolver ${next_version:dataset,bump_type}.
    Caching is handled by OmegaConf (use_cache=True), ensuring the same version is
    returned for repeated calls with the same arguments within a pipeline run.

    Args:
        dataset: Name of the dataset to look up.
        bump_type: One of "major", "minor", or "patch". Defaults to "minor".
    """
    return DataCatalogDataset(dataset=dataset, engine="pandas").bump_version(bump_type.strip())


def name():
    try:
        name = subprocess.check_output(
            ["git", "config", "--get", "user.name"], text=True
        ).strip()
        return name
    except subprocess.CalledProcessError:
        return None


def email():
    try:
        return subprocess.check_output(
            ["git", "config", "--get", "user.email"], text=True
        ).strip()
    except subprocess.CalledProcessError:
        return None


def git_sha():
    # grabs current git commit
    sha = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    # also print a warning to the user that uncommitted work won't be properly tracked
    is_uncommitted = subprocess.check_output(
        ["git", "status", "--porcelain"], text=True
    ).strip()
    if is_uncommitted:
        logging.warning(
            "Uncommitted work will not be properly tracked. Please commit your changes before running the pipeline."
        )
    return sha