"""DCBP providers -- each maps a slice of per-turn context into the prompt.

v0.4 ships four providers that preserve byte-for-byte parity with the old
`engine.py::_build_engineered_context`:

- `SessionSummaryProvider`  wraps `--continue` session summary
- `MemoryRecallProvider`    wraps memory `pre_turn` output
- `TopicSummaryProvider`    wraps `topic_tracker.build_context()`
- `ReasoningModeProvider`   wraps `get_reasoning_instruction(query_type)`

v0.6 adds:

- `EnvironmentProvider`     project AGENTS.md + global personal context
- `WebRetrievalProvider`    pre-fetched web context (engine fetches async)
- `ConflictSurfaceProvider` flags stored contradictions

Still on deck: `AmbientInsightProvider` and `InsightsProvider` (v0.7),
`ProjectContextProvider` once it is extracted from the frozen system prompt.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

from phoenix.core.reasoning import get_reasoning_instruction

if TYPE_CHECKING:
    from phoenix.context.intent import TurnIntent


@dataclass
class TurnState:
    """Per-turn inputs shared across providers.

    Data is gathered once by the pipeline and read by each provider; no
    provider talks to the memory system, topic tracker, or web client
    directly. The engine (or a pre-fetcher) fills these fields before
    `DCBP.run()` is invoked.
    """

    user_input: str
    intent: TurnIntent
    memory_context: str = ""
    session_summary: str = ""
    topic_context: str = ""
    web_context: str = ""
    contradiction_score: float = 0.0
    contradiction_pairs: list = field(default_factory=list)
    ambient_summary: str = ""


@dataclass
class SessionSummaryProvider:
    priority: int = 1

    def should_inject(self, state: TurnState) -> bool:
        return bool(state.session_summary)

    def render(self, state: TurnState, budget: int) -> str:
        body = state.session_summary
        if len(body) > budget:
            body = body[:budget]
        return f"[Previous session]\n{body}"


@dataclass
class MemoryRecallProvider:
    priority: int = 2

    def should_inject(self, state: TurnState) -> bool:
        return bool(state.memory_context)

    def render(self, state: TurnState, budget: int) -> str:
        # Memory already enforces `max_inject_tokens` inside
        # `recall.format_for_prompt`; this truncation is a defensive floor.
        body = state.memory_context
        if len(body) > budget:
            body = body[:budget]
        return body


@dataclass
class TopicSummaryProvider:
    priority: int = 7

    def should_inject(self, state: TurnState) -> bool:
        return bool(state.topic_context)

    def render(self, state: TurnState, budget: int) -> str:
        body = state.topic_context
        if len(body) > budget:
            body = body[:budget]
        return f"[Session context]\n{body}"


@dataclass
class ReasoningModeProvider:
    priority: int = 8

    def should_inject(self, state: TurnState) -> bool:
        return get_reasoning_instruction(state.intent.query_type) is not None

    def render(self, state: TurnState, budget: int) -> str:
        body = get_reasoning_instruction(state.intent.query_type) or ""
        if len(body) > budget:
            body = body[:budget]
        return body


_DEFAULT_ENV_MAX_CHARS = 1600
"""Per-provider cap independent of arbiter budget.

Even on a generous arbiter allocation, AGENTS.md should not silently dominate
the per-turn prompt -- the arbiter handles cross-provider competition; this
is the within-provider sanity bound. ~400 tokens per doc, two docs = ~800
tokens worst case, which the protected floor can comfortably absorb.
"""


_DEFAULT_WEB_MAX_CHARS = 2400
"""Per-provider cap for ambient web context (~600 tokens).

The model can still call `web_search` directly for deeper investigation;
this is the silently-injected ambient slice for "knows the world" turns.
"""


_DEFAULT_INSIGHTS_MAX_CHARS = 1200
"""Per-provider cap for consolidated insights (~300 tokens)."""


@dataclass
class EnvironmentProvider:
    """Project AGENTS.md + global `~/.phoenix/memories/environment.md`.

    Both files are optional; both inject if present. Read once at provider
    construction (engine boot) -- session-lifetime cache. Hot-reload across
    sessions is the contract; mid-session edits do not re-read.

    Priority 3 = protected floor: runtime constraints are load-bearing for
    correctness on environment-dependent code. The kind of bug that looks
    fine on the laptop and silently breaks in production.
    """

    priority: int = 3
    max_chars: int = _DEFAULT_ENV_MAX_CHARS
    cwd: Path | None = None
    global_path: Path | None = None
    _project_doc: str = field(default="", init=False)
    _global_doc: str = field(default="", init=False)

    def __post_init__(self) -> None:
        cwd = self.cwd or Path.cwd()
        project_md = cwd / "AGENTS.md"
        if project_md.exists() and project_md.is_file():
            try:
                self._project_doc = project_md.read_text(errors="replace").strip()
            except OSError:
                self._project_doc = ""

        global_path = self.global_path
        if global_path is None:
            from phoenix.config.settings import PHOENIX_DIR

            global_path = PHOENIX_DIR / "memories" / "environment.md"
        if global_path.exists() and global_path.is_file():
            try:
                self._global_doc = global_path.read_text(errors="replace").strip()
            except OSError:
                self._global_doc = ""

    def should_inject(self, state: TurnState) -> bool:
        return bool(self._project_doc or self._global_doc)

    def render(self, state: TurnState, budget: int) -> str:
        parts: list[str] = []
        if self._project_doc:
            parts.append(f"[Runtime constraints (AGENTS.md)]\n{self._project_doc}")
        if self._global_doc:
            parts.append(f"[Personal context]\n{self._global_doc}")
        out = "\n\n".join(parts)
        cap = min(budget, self.max_chars)
        if len(out) > cap:
            out = out[:cap]
        return out


@dataclass
class WebRetrievalProvider:
    """Renders pre-fetched web context. Engine handles the async fetch.

    Triggered when `intent.temporal_ref` is set (the user's query references
    time -- 'yesterday', 'last week', 'recently' -- which usually means we
    need ground-truth from the live web, not just memory). The actual fetch
    happens in `engine.run_stream` via `web_search` so the result is also
    written to `ctx.turn_cache` for tool dedupe.
    """

    priority: int = 4
    max_chars: int = _DEFAULT_WEB_MAX_CHARS

    def should_inject(self, state: TurnState) -> bool:
        return bool(state.web_context)

    def render(self, state: TurnState, budget: int) -> str:
        out = f"[Web context (auto-fetched -- model can also call web_search)]\n{state.web_context.strip()}"
        cap = min(budget, self.max_chars)
        if len(out) > cap:
            out = out[:cap]
        return out


@dataclass
class ConflictSurfaceProvider:
    """Surfaces stored-memory contradictions detected during recall.

    Reads `state.contradiction_score` (0..1) -- fraction of recalled
    memories that `_detect_tensions` flagged as in tension with another
    recalled memory. Above 0.4, renders a one-line ambient signal so the
    model knows to hedge instead of confidently relying on the recall.

    Priority 3 = protected floor: contradictions must not be silently
    displaced by a web snippet or ambient hint -- they are load-bearing
    for the Correction behavior in vision.md.

    v0.6 caveat: this only catches tensions among RECALLED memories, not
    user-input-vs-memory contradictions. The latter requires post-turn
    extraction signals (v0.7).
    """

    priority: int = 3
    threshold: float = 0.4

    def should_inject(self, state: TurnState) -> bool:
        return state.contradiction_score > self.threshold

    def render(self, state: TurnState, budget: int) -> str:
        score = state.contradiction_score
        pair_count = len(state.contradiction_pairs)
        body = (
            f"[Tension signal] Recalled memories disagree (score {score:.2f}, "
            f"{pair_count} pair{'s' if pair_count != 1 else ''}). Acknowledge "
            f"the conflict instead of picking a side silently."
        )
        if len(body) > budget:
            body = body[:budget]
        return body


@dataclass
class AmbientInsightProvider:
    """Surfaces ambient-daemon signals into the per-turn context.

    Engine pre-builds `state.ambient_summary` from the daemon (status +
    awareness patterns) before `DCBP.run()`. This provider just renders
    it. Gates on low-stakes turns -- ambient is for "noticed something"
    moments, never for high-stakes decisions where the user's question
    deserves direct attention.

    Priority 6: above TopicSummary(7), below MemoryRecall(2) and
    InsightsProvider(5). Not protected -- a tight budget can drop ambient
    to make room for memory/conflict.
    """

    priority: int = 6
    max_chars: int = 600

    def should_inject(self, state: TurnState) -> bool:
        return (not state.intent.stakes) and bool(state.ambient_summary)

    def render(self, state: TurnState, budget: int) -> str:
        out = f"[Ambient signal] {state.ambient_summary.strip()}"
        cap = min(budget, self.max_chars)
        if len(out) > cap:
            out = out[:cap]
        return out


@dataclass
class InsightsProvider:
    """Reads `~/.phoenix/insights.md` (consolidation output) for stable injection.

    Surfaces the most recent N insights so Phoenix can reference patterns
    it has noticed about Boss without re-deriving them every turn.
    Cache zone "stable" -- read once at provider construction. Hot reload
    across sessions only.

    Priority 5: between MemoryRecall(2) and TopicSummary(7). Below memory
    because specific recalled facts beat general patterns; above topic so
    Phoenix's "I noticed X about you" surfaces even on tight budgets.
    """

    priority: int = 5
    max_chars: int = _DEFAULT_INSIGHTS_MAX_CHARS
    last_n: int = 5
    insights_path: Path | None = None
    _content: str = field(default="", init=False)

    def __post_init__(self) -> None:
        path = self.insights_path
        if path is None:
            from phoenix.config.settings import PHOENIX_DIR

            path = PHOENIX_DIR / "insights.md"
        if not path.exists() or not path.is_file():
            return
        try:
            raw = path.read_text(errors="replace").strip()
        except OSError:
            return
        if not raw:
            return
        # Take the last N bullet lines for stable injection. Bullets begin
        # with "- ". Date headers ("## YYYY-...") are dropped; the model
        # cares about content, not when consolidation ran.
        bullets = [line for line in raw.splitlines() if line.startswith("- ")]
        self._content = "\n".join(bullets[-self.last_n :])

    def should_inject(self, state: TurnState) -> bool:
        return bool(self._content)

    def render(self, state: TurnState, budget: int) -> str:
        out = f"[Patterns Phoenix has noticed]\n{self._content}"
        cap = min(budget, self.max_chars)
        if len(out) > cap:
            out = out[:cap]
        return out


def default_providers() -> list:
    """Minimal provider set (v0.4 baseline).

    Used by unit tests and by `DCBP()` when no provider list is passed.
    Production code (`engine.boot()`) constructs an explicit extended
    list via `production_providers()` so new providers (`EnvironmentProvider`,
    `WebRetrievalProvider`, `ConflictSurfaceProvider`) are opt-in for tests.
    """
    return [
        SessionSummaryProvider(),
        MemoryRecallProvider(),
        TopicSummaryProvider(),
        ReasoningModeProvider(),
    ]


def production_providers() -> list:
    """Extended provider set used by `engine.boot()` in production.

    Adds v0.6 (`EnvironmentProvider`, `ConflictSurfaceProvider`,
    `WebRetrievalProvider`), v0.7 (`InsightsProvider`,
    `AmbientInsightProvider`), and v0.8 (`RepoMapProvider`) on top of
    the v0.4 baseline.
    """
    # Lazy import to break the providers <-> repo_map circular hazard.
    from phoenix.context.repo_map import RepoMapProvider

    return [
        SessionSummaryProvider(),
        MemoryRecallProvider(),
        EnvironmentProvider(),
        ConflictSurfaceProvider(),
        RepoMapProvider(),
        WebRetrievalProvider(),
        InsightsProvider(),
        AmbientInsightProvider(),
        TopicSummaryProvider(),
        ReasoningModeProvider(),
    ]
