"""Novelty gate -- filters duplicates, detects contradictions, blocks output overlap."""

import logging

import numpy as np

from .config import CATEGORY_IMPORTANCE, MemoryParams
from .embeddings import EmbeddingService
from .extractor import sigmoid
from .store import MemoryStore

log = logging.getLogger(__name__)


class NoveltyGate:
    """Evaluate whether a fact is worth storing."""

    def __init__(self, config: MemoryParams, embedder: EmbeddingService, store: MemoryStore):
        self.config = config
        self.embedder = embedder
        self.store = store

    async def evaluate(
        self,
        content: str,
        embedding: np.ndarray,
        namespace: str = "global",
        ai_output_text: str = "",
    ) -> dict:
        """Evaluate novelty. Returns dict with action and details.

        Actions:
          ADD     -- novel fact, caller should persist it
          NOOP    -- near-duplicate; access count already incremented + strength boosted
          UPDATE  -- contradicts an existing fact; caller routes through
                     `handle_contradiction` to supersede with an evolution chain
          FILTER  -- output-aware or novelty gate rejects storage

        DELETE is NOT emitted here. Hard deletion is user-explicit only
        (`/memory forget <q>`), routed directly against `MemoryStore`.
        """
        ids, matrix, _ = await self.store.get_all_embeddings(namespace)
        if len(ids) == 0:
            return {"action": "ADD", "gate": 1.0}

        sims = EmbeddingService.cosine_similarity_matrix(embedding, matrix)
        best_idx = int(np.argmax(sims))
        best_sim = float(sims[best_idx])
        best_id = ids[best_idx]

        # 1. Contradiction detection
        if best_sim >= self.config.contradiction_key_threshold:
            old_mem = await self.store.get(best_id)
            if old_mem and old_mem.get("embedding") is not None:
                old_emb = old_mem["embedding"]
                value_sim = EmbeddingService.cosine_similarity(embedding, old_emb)
                if value_sim < self.config.contradiction_value_threshold:
                    return {
                        "action": "UPDATE",
                        "old_id": best_id,
                        "old_content": old_mem.get("content", ""),
                        "old_created": old_mem.get("created_at"),
                        "similarity": best_sim,
                    }

        # 2. Near-duplicate
        if best_sim >= 0.85:
            await self.store.increment_access(best_id)
            existing = await self.store.get(best_id)
            await self.store.update_strength(
                best_id,
                min(
                    (existing or {}).get("strength", 1.0) + self.config.reinforce_amount,
                    self.config.strength_cap,
                ),
            )
            return {"action": "NOOP", "existing_id": best_id, "similarity": best_sim}

        # 3. Output-aware gating
        output_penalty = 0.0
        if ai_output_text:
            ai_emb = self.embedder.embed_document(ai_output_text[:300])
            output_sims = EmbeddingService.cosine_similarity_matrix(ai_emb, matrix)
            max_output_sim = float(np.max(output_sims)) if len(output_sims) > 0 else 0.0
            if max_output_sim >= self.config.output_overlap_ceiling:
                return {
                    "action": "FILTER",
                    "reason": "output overlap",
                    "similarity": max_output_sim,
                }
            output_penalty = self.config.output_overlap_weight * max_output_sim

        # 4. Novelty gate (sigmoid)
        novelty = max(0.0, min(1.0, 1.0 - best_sim - output_penalty))
        gate = sigmoid(self.config.beta_gate * (novelty - self.config.theta_gate))
        if gate < 0.15:
            return {"action": "FILTER", "reason": "not novel", "gate": gate, "similarity": best_sim}

        return {"action": "ADD", "gate": gate, "similarity": best_sim}

    async def handle_contradiction(
        self,
        old_id: str,
        new_content: str,
        embedding: np.ndarray,
        category: str,
        namespace: str = "global",
        intent: str | None = None,
        dimension: str | None = None,
    ) -> dict:
        """Store new fact, supersede old, preserve evolution chain."""
        old_mem = await self.store.get(old_id)
        old_content = old_mem["content"] if old_mem else ""
        old_created = old_mem.get("created_at") if old_mem else None

        importance = CATEGORY_IMPORTANCE.get(category, 1.0)
        strength = self.config.initial_strength * importance

        new_id = await self.store.add(
            content=new_content,
            category=category,
            namespace=namespace,
            embedding=embedding,
            strength=strength,
            intent=intent,
            prior_value=old_content,
            prior_date=old_created,
            dimension=dimension,
        )

        await self.store.supersede(old_id, new_id, self.config.contradiction_weaken_factor)

        log.info("Contradiction: '%s' superseded by '%s'", old_content[:50], new_content[:50])
        return {"new_id": new_id, "old_id": old_id, "action": "UPDATE"}
