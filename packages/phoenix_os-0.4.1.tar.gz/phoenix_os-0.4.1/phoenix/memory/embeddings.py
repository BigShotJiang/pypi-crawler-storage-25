"""Embedding service -- task-typed local vectors via Gemma, FastEmbed, or TF-IDF.

Three backends, selected via `config.embedding_backend`:

- `gemma`     -- google/embeddinggemma-300m via sentence-transformers. Asymmetric
                 task prompts (query, document, clustering, similarity). Best quality,
                 multilingual. Requires Hugging Face license acceptance + auth.
- `fastembed` -- sentence-transformers/all-MiniLM-L6-v2 via FastEmbed. Symmetric
                 (task argument ignored). English-only, small, fast. Fallback.
- `tfidf`     -- hash-based TF-IDF. Last-resort when no ML libs available. Symmetric.

Cache is keyed on `(backend_id, task, text)` so a single text embedded under
different task prompts does not collide.
"""

import hashlib
import logging
import math
import os
import platform
import re
from collections import Counter

import numpy as np

from .config import MemoryParams

log = logging.getLogger(__name__)


# Task-prompt templates. Applied by the Gemma backend before encoding.
# FastEmbed and TF-IDF ignore task (symmetric models).
_GEMMA_PROMPTS = {
    "query": "task: search result | query: {text}",
    "document": "title: none | text: {text}",
    "clustering": "task: clustering | query: {text}",
    "similarity": "task: sentence similarity | query: {text}",
}

_DEFAULT_TASK = "document"
_VALID_TASKS = tuple(_GEMMA_PROMPTS.keys())


def _detect_precision() -> str:
    """Pick bf16 where it is safely supported, fp32 elsewhere. Cross-platform."""
    machine = platform.machine().lower()
    system = platform.system().lower()
    if system == "darwin" and machine in ("arm64", "aarch64"):
        return "bf16"
    try:
        import torch

        if torch.cuda.is_available():
            return "bf16"
    except Exception:
        pass
    return "fp32"


class EmbeddingService:
    """Compute task-typed text embeddings locally."""

    def __init__(self, config: MemoryParams | None = None):
        self.config = config or MemoryParams()
        self._backend = None
        self._cache: dict[str, np.ndarray] = {}

    # Public API

    def embed(self, text: str, task: str = _DEFAULT_TASK) -> np.ndarray:
        """Embed a single text under the given task prompt. Returns unit vector."""
        if task not in _VALID_TASKS:
            raise ValueError(f"task must be one of {_VALID_TASKS}, got {task!r}")
        key = self._cache_key(text, task)
        if key in self._cache:
            return self._cache[key]
        vec = self._compute_batch([text], task)[0]
        self._cache[key] = vec
        return vec

    def embed_query(self, text: str) -> np.ndarray:
        return self.embed(text, task="query")

    def embed_document(self, text: str) -> np.ndarray:
        return self.embed(text, task="document")

    def embed_clustering(self, text: str) -> np.ndarray:
        return self.embed(text, task="clustering")

    def embed_similarity(self, text: str) -> np.ndarray:
        return self.embed(text, task="similarity")

    def embed_batch(self, texts: list[str], task: str = _DEFAULT_TASK) -> list[np.ndarray]:
        """Embed many texts under the same task. Uses cache where possible."""
        if task not in _VALID_TASKS:
            raise ValueError(f"task must be one of {_VALID_TASKS}, got {task!r}")
        results: list[np.ndarray | None] = []
        uncached_texts: list[str] = []
        uncached_indices: list[int] = []

        for i, t in enumerate(texts):
            key = self._cache_key(t, task)
            if key in self._cache:
                results.append(self._cache[key])
            else:
                results.append(None)
                uncached_texts.append(t)
                uncached_indices.append(i)

        if uncached_texts:
            vecs = self._compute_batch(uncached_texts, task)
            for idx, vec in zip(uncached_indices, vecs, strict=False):
                key = self._cache_key(texts[idx], task)
                self._cache[key] = vec
                results[idx] = vec

        return results  # type: ignore

    @property
    def dim(self) -> int:
        return self.config.embedding_dim

    @staticmethod
    def cosine_similarity(a: np.ndarray, b: np.ndarray) -> float:
        dot = float(np.dot(a, b))
        na = float(np.linalg.norm(a))
        nb = float(np.linalg.norm(b))
        if na < 1e-9 or nb < 1e-9:
            return 0.0
        return dot / (na * nb)

    @staticmethod
    def cosine_similarity_matrix(query: np.ndarray, keys: np.ndarray) -> np.ndarray:
        """Cosine similarity of query against each row in keys. Returns (n,)."""
        if keys.shape[0] == 0:
            return np.array([])
        norms = np.linalg.norm(keys, axis=1)
        norms = np.maximum(norms, 1e-9)
        qnorm = max(float(np.linalg.norm(query)), 1e-9)
        return (keys @ query) / (norms * qnorm)

    # Internals

    def _cache_key(self, text: str, task: str) -> str:
        backend_id = self._get_backend().id
        raw = f"{backend_id}|{task}|{text}"
        return hashlib.md5(raw.encode()).hexdigest()

    def _compute_batch(self, texts: list[str], task: str) -> list[np.ndarray]:
        return self._get_backend().embed_batch(texts, task)

    def _get_backend(self):
        if self._backend is not None:
            return self._backend
        preferred = self.config.embedding_backend

        if preferred == "gemma":
            try:
                self._backend = _GemmaBackend(self.config)
                log.info(
                    "Embedding: Gemma (%s) precision=%s",
                    self.config.embedding_model,
                    self._backend.precision,
                )
                return self._backend
            except Exception as e:
                log.warning(
                    "Gemma backend unavailable: %s. "
                    "Run `phoenix --setup` to retry HF auth, or "
                    "`phoenix --embedder fastembed` to switch to MiniLM.",
                    e,
                )
                raise

        if preferred == "fastembed":
            self._backend = _FastEmbedBackend(self.config)
            log.info("Embedding: FastEmbed (%s)", self.config.embedding_model)
            return self._backend

        if preferred == "tfidf":
            self._backend = _TFIDFBackend(self.config)
            log.info("Embedding: TF-IDF (fallback)")
            return self._backend

        raise ValueError(
            f"Unknown embedding_backend: {preferred!r}. Valid: gemma, fastembed, tfidf."
        )


# Backends


class _GemmaBackend:
    """EmbeddingGemma via sentence-transformers. Task-typed prompts."""

    id = "gemma"

    def __init__(self, config: MemoryParams):
        self.config = config
        self.precision = (
            _detect_precision()
            if config.embedding_precision == "auto"
            else config.embedding_precision
        )
        model_name = config.embedding_model

        os.environ.setdefault("HF_HUB_DISABLE_TELEMETRY", "1")
        # Skip the per-file tqdm progress bar on weight load -- the outer
        # "Loading embedding model..." print already signals what's happening,
        # and the extra 314-step bar just adds visual noise + redraw cost.
        os.environ.setdefault("HF_HUB_DISABLE_PROGRESS_BARS", "1")
        for name in ("sentence_transformers", "transformers", "huggingface_hub"):
            logging.getLogger(name).setLevel(logging.WARNING)

        import torch
        from sentence_transformers import SentenceTransformer

        dtype_map = {"fp32": torch.float32, "bf16": torch.bfloat16}
        # low_cpu_mem_usage mmaps weights instead of loading the whole state
        # dict into RAM first -- typically halves cold-load time on disk-bound
        # systems. Safe: HF transformers supports this on all architectures.
        model_kwargs = {
            "torch_dtype": dtype_map[self.precision],
            "low_cpu_mem_usage": True,
        }

        # Try loading from the local HF cache first (no network roundtrip
        # to check for updates). Falls back to a full fetch on first run or
        # when the user manually clears the cache.
        try:
            self._model = SentenceTransformer(
                model_name, model_kwargs=model_kwargs, local_files_only=True
            )
        except Exception:
            try:
                self._model = SentenceTransformer(model_name, model_kwargs=model_kwargs)
            except OSError as e:
                msg = str(e).lower()
                if "gated repo" in msg or "401" in msg or "restricted" in msg:
                    raise RuntimeError(
                        f"Hugging Face rejected access to {model_name}.\n"
                        f"  Run:  phoenix --setup   "
                        f"(re-runs the Gemma license + token flow)\n"
                        f"  Or:   phoenix --embedder fastembed   "
                        f"(switch to English-only MiniLM, no HF auth)"
                    ) from e
                raise

    def embed_batch(self, texts: list[str], task: str) -> list[np.ndarray]:
        template = _GEMMA_PROMPTS[task]
        prompts = [template.format(text=t) for t in texts]
        vecs = self._model.encode(
            prompts,
            convert_to_numpy=True,
            normalize_embeddings=True,
            show_progress_bar=False,
        )
        vecs = np.atleast_2d(vecs)
        return [np.asarray(v, dtype=np.float32) for v in vecs]


class _FastEmbedBackend:
    """FastEmbed + MiniLM. Symmetric -- task argument ignored."""

    id = "fastembed"

    def __init__(self, config: MemoryParams):
        self.config = config
        self.model_name = config.embedding_model

        from pathlib import Path

        from fastembed import TextEmbedding

        cache_dir = str(Path.home() / ".cache" / "fastembed")
        os.environ.setdefault("HF_HUB_DISABLE_TELEMETRY", "1")
        os.environ.setdefault("HF_HUB_DISABLE_PROGRESS_BARS", "1")
        os.environ.setdefault("TQDM_DISABLE", "1")
        for name in ("fastembed", "huggingface_hub", "onnxruntime"):
            logging.getLogger(name).setLevel(logging.WARNING)

        self._model = TextEmbedding(model_name=self.model_name, cache_dir=cache_dir)

    def embed_batch(self, texts: list[str], task: str) -> list[np.ndarray]:
        embeddings = list(self._model.embed(texts))
        return [_normalize(np.asarray(e, dtype=np.float32)) for e in embeddings]


class _TFIDFBackend:
    """Hash-based TF-IDF. Last-resort fallback when no ML libs available."""

    id = "tfidf"

    def __init__(self, config: MemoryParams):
        self.config = config
        self._dim = config.embedding_dim

    def embed_batch(self, texts: list[str], task: str) -> list[np.ndarray]:
        return [self._embed_one(t) for t in texts]

    def _embed_one(self, text: str) -> np.ndarray:
        tokens = _tokenize(text)
        if not tokens:
            return np.zeros(self._dim, dtype=np.float32)
        tf = Counter(tokens)
        vec = np.zeros(self._dim, dtype=np.float32)
        for token, count in tf.items():
            h = int(hashlib.md5(token.encode()).hexdigest(), 16)
            idx = h % self._dim
            sign = 1.0 if (h // self._dim) % 2 == 0 else -1.0
            vec[idx] += sign * (1.0 + math.log(count))
        return _normalize(vec)


# Helpers (used by backends)


def _normalize(v: np.ndarray) -> np.ndarray:
    norm = float(np.linalg.norm(v))
    if norm < 1e-9:
        return v
    return v / norm


_STOPWORDS = frozenset(
    {
        "the",
        "a",
        "an",
        "is",
        "are",
        "was",
        "were",
        "be",
        "been",
        "to",
        "of",
        "in",
        "for",
        "on",
        "with",
        "at",
        "by",
        "it",
        "this",
        "that",
        "and",
        "or",
        "but",
        "not",
        "no",
        "do",
        "does",
        "did",
        "has",
        "have",
        "had",
        "will",
        "would",
        "can",
        "could",
        "should",
    }
)


def _tokenize(text: str) -> list[str]:
    text = text.lower().strip()
    tokens = re.findall(r"[a-z0-9]+(?:[-'][a-z0-9]+)*", text)
    return [t for t in tokens if len(t) > 1 and t not in _STOPWORDS]
