"""Translate pydantic-ai stream events into Phoenix's outbound tuple shape.

Pulled out of `engine.py` to keep that file under the 400-line cap. The
final-result event (`AgentRunResultEvent`) stays in the engine because it
sets outer state (`final_usage`, `final_messages`); per-event payload
mapping is pure and lives here.

Outbound tuple shapes (TUI dispatches on the first element):
  ("text", delta: str)
  ("tool_call", tool_call_id: str, name: str, args: Any)
  ("tool_result", tool_call_id: str, content: str, is_error: bool)
"""

from __future__ import annotations

import json


def translate_event(event) -> tuple | None:
    """Map a single pydantic-ai stream event to an outbound tuple, or
    `None` if the event is internal-only (e.g. final-result, intermediate
    parts the TUI doesn't render).
    """
    from pydantic_ai.messages import (
        FunctionToolCallEvent,
        FunctionToolResultEvent,
        PartDeltaEvent,
        RetryPromptPart,
        TextPartDelta,
    )

    if isinstance(event, PartDeltaEvent) and isinstance(event.delta, TextPartDelta):
        delta = event.delta.content_delta
        return ("text", delta) if delta else None

    if isinstance(event, FunctionToolCallEvent):
        return (
            "tool_call",
            event.part.tool_call_id,
            event.part.tool_name,
            event.part.args,
        )

    if isinstance(event, FunctionToolResultEvent):
        is_error = isinstance(event.result, RetryPromptPart)
        content = getattr(event.result, "content", "")
        if not isinstance(content, str):
            try:
                content = json.dumps(content, default=str)
            except Exception:
                content = str(content)
        return ("tool_result", event.result.tool_call_id, content, is_error)

    return None
