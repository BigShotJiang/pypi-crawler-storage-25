"""Pre-DCBP signal-gathering helpers.

Pulled out of `engine.py` to keep the engine under the 400-line cap. Both
helpers are pure with respect to engine state: they operate on the data
they are passed and return what the DCBP needs.

- `maybe_fetch_web`             ambient web grounding for temporal queries
- `extract_contradiction_signal` tension score from last recall
- `build_ambient_summary`        one-line ambient-daemon synopsis
"""

from __future__ import annotations

import logging
from typing import Any

from phoenix.abilities import PhoenixContext

log = logging.getLogger(__name__)


async def maybe_fetch_web(ctx: PhoenixContext | None, user_input: str) -> str:
    """Pre-fetch web context for temporally-sensitive queries.

    Gated on `intent.temporal_ref` -- queries like 'what changed in
    pydantic-ai recently' or 'latest supabase pricing' get grounded
    without the model having to decide to call `web_search`. The fetch
    also writes to `ctx.turn_cache`, so an explicit model-invoked
    `web_search` for the same query within the turn dedupes.

    Skips silently if the ability is missing (no `BRAVE_API_KEY`) or the
    intent doesn't warrant a fetch.
    """
    if ctx is None:
        return ""

    from phoenix.context import intent_from_input

    intent = intent_from_input(user_input)
    if intent.temporal_ref is None:
        return ""

    try:
        from phoenix.abilities.web_search import _get_api_key, web_search
    except ImportError:
        return ""

    if not _get_api_key():
        return ""

    try:
        result = await web_search(ctx, user_input, max_results=5, max_tokens=600)
        return result
    except Exception as e:
        log.warning("WebRetrievalProvider pre-fetch failed: %s", e)
        return ""


async def build_ambient_summary(daemon: Any) -> str:
    """One-line synopsis of the ambient daemon's current state.

    Combines pending-signal count + responsibility count + a short slice
    of `awareness.get_patterns()`. Empty string when nothing material is
    pending or the daemon is missing/disabled.

    Best-effort: any exception swallows to empty string so the turn
    proceeds without ambient context.
    """
    if daemon is None:
        return ""
    try:
        if not getattr(daemon, "is_enabled", True):
            return ""
        status = daemon.status() if hasattr(daemon, "status") else {}
    except Exception as e:
        log.warning("AmbientInsightProvider summary failed: %s", e)
        return ""

    pending = status.get("pending_signals", 0)
    responsibilities = status.get("responsibilities", 0)
    if pending == 0 and responsibilities == 0:
        return ""

    parts: list[str] = []
    if pending:
        parts.append(f"{pending} ambient signal(s) pending")
    if responsibilities:
        parts.append(f"{responsibilities} responsibility(ies) tracked")

    awareness = getattr(daemon, "awareness", None)
    if awareness is not None and hasattr(awareness, "get_patterns"):
        try:
            import inspect

            patterns = awareness.get_patterns()
            if inspect.iscoroutine(patterns):
                patterns = await patterns
            if patterns:
                if isinstance(patterns, str):
                    parts.append(patterns[:200])
                elif isinstance(patterns, list):
                    parts.append("; ".join(str(p) for p in patterns[:3])[:200])
        except Exception as e:
            log.debug("ambient patterns unavailable: %s", e)

    return " | ".join(parts)


def extract_contradiction_signal(memory: Any) -> tuple[float, list]:
    """Compute (score, pairs) from `_detect_tensions` output on last recall.

    Score = fraction of recalled memories that landed in a tension pair.
    Pairs = list of (id_a, id_b) tuples for the tensioned memories.

    v0.6 caveat: only catches tensions among recalled memories, not
    user-input-vs-memory contradictions (that requires post-turn
    signals; deferred to v0.7).
    """
    if memory is None:
        return 0.0, []
    recall = getattr(memory, "_recall", None)
    if recall is None:
        return 0.0, []
    recalled = list(getattr(recall, "_last_recalled", []) or [])
    n = len(recalled)
    if n == 0:
        return 0.0, []
    with_tension = [m for m in recalled if m.get("tension_with")]
    if not with_tension:
        return 0.0, []
    score = len(with_tension) / n
    seen: set[tuple[str, str]] = set()
    pairs: list[tuple[str, str]] = []
    for m in with_tension:
        mid = m.get("id", "")
        for other_id in m.get("tension_with") or []:
            a, b = sorted((str(mid), str(other_id)))
            key: tuple[str, str] = (a, b)
            if key not in seen:
                seen.add(key)
                pairs.append(key)
    return score, pairs
