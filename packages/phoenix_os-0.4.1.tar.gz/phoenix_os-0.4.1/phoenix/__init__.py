"""Phoenix -- modular AI agent operating system."""

__version__ = "0.4.1"
