"""Notes -- Phoenix's personal notebook for structured thinking.

Different from memory (auto-extracted facts):
  - Notes are INTENTIONAL -- Phoenix decides to write them
  - Notes have structure -- title, category, status
  - Notes are Phoenix's own thinking tool
  - Notes can be updated, resolved, archived

Use cases:
  - "Write down that DEN uses loop architecture"
  - "Note: Boss wants reliability over flexibility"
  - "Mark the deployment note as resolved"
  - "What notes do I have about this project?"
"""

import os
import sqlite3
import time
import uuid

from phoenix.abilities import ability
from phoenix.config.settings import PHOENIX_DIR

_DB_PATH = os.environ.get("PHOENIX_NOTES_DB", str(PHOENIX_DIR / "notes.db"))

_SCHEMA = """
CREATE TABLE IF NOT EXISTS notes (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    category TEXT DEFAULT 'observation',
    content TEXT NOT NULL,
    status TEXT DEFAULT 'active',
    related_topic TEXT,
    tags TEXT,
    created_at REAL,
    updated_at REAL
);

CREATE INDEX IF NOT EXISTS idx_notes_category ON notes(category);
CREATE INDEX IF NOT EXISTS idx_notes_status ON notes(status);
CREATE INDEX IF NOT EXISTS idx_notes_topic ON notes(related_topic);
"""

VALID_CATEGORIES = [
    "observation",  # something Phoenix noticed
    "decision",  # a decision Boss made
    "project",  # project-level context
    "reference",  # useful reference info
    "todo",  # something to follow up on
    "insight",  # a pattern or connection Phoenix spotted
]

VALID_STATUSES = ["active", "resolved", "archived"]


def _get_conn() -> sqlite3.Connection:
    os.makedirs(os.path.dirname(_DB_PATH), exist_ok=True)
    conn = sqlite3.connect(_DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.executescript(_SCHEMA)
    return conn


def _new_id() -> str:
    return uuid.uuid4().hex[:10]


@ability(
    name="notes",
    description="Phoenix's personal notebook -- write, list, update, resolve notes",
)
def notes(
    action: str,
    title: str = "",
    content: str = "",
    category: str = "observation",
    related_topic: str = "",
    note_id: str = "",
    status: str = "",
    query: str = "",
) -> str:
    """Phoenix's structured notebook for organizing thinking.

    Args:
        action: write, list, search, update, resolve, archive, delete
        title: Note title (for write)
        content: Note content (for write/update)
        category: observation, decision, project, reference, todo, insight
        related_topic: Link to a topic or project name
        note_id: Note ID (for update/resolve/archive/delete)
        status: Filter by status (for list): active, resolved, archived
        query: Search string (for search action). `content` and `title`
            also work as fallbacks for backward compatibility.
    """
    action = action.strip().lower()

    if action == "write":
        return _write(title, content, category, related_topic)
    elif action == "list":
        return _list_notes(category, status or "active", related_topic)
    elif action == "search":
        return _search(query or content or title)
    elif action == "update":
        return _update(note_id, title, content, category)
    elif action == "resolve":
        return _resolve(note_id)
    elif action == "archive":
        return _archive(note_id)
    elif action == "delete":
        return _delete(note_id)
    else:
        return (
            f"Unknown action: {action}. Use: write, list, search, update, resolve, archive, delete"
        )


def _write(title: str, content: str, category: str, related_topic: str) -> str:
    if not title:
        return "Provide a title for the note."
    if not content:
        content = title

    if category not in VALID_CATEGORIES:
        category = "observation"

    conn = _get_conn()
    now = time.time()

    # Check for existing note with similar title (prevent duplicates)
    existing = conn.execute(
        "SELECT id, title, content, status FROM notes "
        "WHERE title LIKE ? AND status = 'active' LIMIT 1",
        (f"%{title}%",),
    ).fetchone()

    if existing:
        # Update existing note instead of creating duplicate
        conn.execute(
            "UPDATE notes SET content = ?, category = ?, "
            "related_topic = ?, updated_at = ? WHERE id = ?",
            (content, category, related_topic, now, existing["id"]),
        )
        conn.commit()
        conn.close()
        return (
            f"Updated existing note [{existing['id']}]: {title}\n"
            f"  Was: {existing['content'][:80]}\n"
            f"  Now: {content[:80]}"
        )

    # No duplicate -- create new
    nid = _new_id()
    conn.execute(
        "INSERT INTO notes (id, title, category, content, status, "
        "related_topic, created_at, updated_at) "
        "VALUES (?, ?, ?, ?, 'active', ?, ?, ?)",
        (nid, title, category, content, related_topic, now, now),
    )
    conn.commit()
    conn.close()

    return f"Noted [{nid}] ({category}): {title}"


def _list_notes(category: str, status: str, related_topic: str) -> str:
    conn = _get_conn()

    query = "SELECT * FROM notes WHERE 1=1"
    params: list = []

    if status:
        query += " AND status = ?"
        params.append(status)

    if category and category != "all":
        query += " AND category = ?"
        params.append(category)

    if related_topic:
        query += " AND related_topic LIKE ?"
        params.append(f"%{related_topic}%")

    query += " ORDER BY updated_at DESC LIMIT 20"
    rows = conn.execute(query, params).fetchall()
    conn.close()

    if not rows:
        return "No notes found."

    lines = [f"Notes ({len(rows)}):"]
    for r in rows:
        status_icon = {"active": " ", "resolved": "x", "archived": "-"}.get(r["status"], "?")
        cat_short = r["category"][:4]
        topic = f" [{r['related_topic']}]" if r["related_topic"] else ""
        lines.append(f"  [{status_icon}] {r['id']}  ({cat_short}) {r['title']}{topic}")
    return "\n".join(lines)


def _search(query: str) -> str:
    if not query:
        return "Provide a search query."

    conn = _get_conn()
    rows = conn.execute(
        "SELECT * FROM notes WHERE "
        "(title LIKE ? OR content LIKE ?) "
        "ORDER BY updated_at DESC LIMIT 10",
        (f"%{query}%", f"%{query}%"),
    ).fetchall()
    conn.close()

    if not rows:
        return f"No notes matching '{query}'."

    lines = [f"Found {len(rows)} notes:"]
    for r in rows:
        content_preview = r["content"][:80]
        lines.append(
            f"  [{r['id']}] ({r['category']}, {r['status']}) {r['title']}: {content_preview}"
        )
    return "\n".join(lines)


def _update(note_id: str, title: str, content: str, category: str) -> str:
    if not note_id:
        return "Provide note_id to update."

    conn = _get_conn()
    existing = conn.execute("SELECT * FROM notes WHERE id = ?", (note_id,)).fetchone()

    if not existing:
        conn.close()
        return f"Note [{note_id}] not found."

    updates = []
    params: list = []
    if title:
        updates.append("title = ?")
        params.append(title)
    if content:
        updates.append("content = ?")
        params.append(content)
    if category and category in VALID_CATEGORIES:
        updates.append("category = ?")
        params.append(category)

    if not updates:
        conn.close()
        return "Nothing to update. Provide title, content, or category."

    updates.append("updated_at = ?")
    params.append(time.time())
    params.append(note_id)

    conn.execute(
        f"UPDATE notes SET {', '.join(updates)} WHERE id = ?",
        params,
    )
    conn.commit()
    conn.close()

    return f"Updated note [{note_id}]."


def _resolve(note_id: str) -> str:
    if not note_id:
        return "Provide note_id to resolve."

    conn = _get_conn()
    result = conn.execute(
        "UPDATE notes SET status = 'resolved', updated_at = ? WHERE id = ?",
        (time.time(), note_id),
    )
    conn.commit()

    if result.rowcount == 0:
        conn.close()
        return f"Note [{note_id}] not found."

    row = conn.execute("SELECT title FROM notes WHERE id = ?", (note_id,)).fetchone()
    conn.close()

    title = row["title"] if row else "?"
    return f"Resolved: [{note_id}] {title}"


def _archive(note_id: str) -> str:
    if not note_id:
        return "Provide note_id to archive."

    conn = _get_conn()
    result = conn.execute(
        "UPDATE notes SET status = 'archived', updated_at = ? WHERE id = ?",
        (time.time(), note_id),
    )
    conn.commit()
    conn.close()

    if result.rowcount == 0:
        return f"Note [{note_id}] not found."
    return f"Archived: [{note_id}]"


def _delete(note_id: str) -> str:
    if not note_id:
        return "Provide note_id to delete."

    conn = _get_conn()
    result = conn.execute("DELETE FROM notes WHERE id = ?", (note_id,))
    conn.commit()
    conn.close()

    if result.rowcount == 0:
        return f"Note [{note_id}] not found."
    return f"Deleted: [{note_id}]"
