"""Provider API key verification.

Called during `phoenix --setup` right after a key is pasted, BEFORE it gets
stored. Hits each provider's `/models` endpoint (or equivalent) with the
key and reports:
  - ok: True    -- provider accepted the key, safe to store
  - ok: False   -- provider rejected it; show the message and let the user retry

Modelled on the existing HF `whoami` verification flow in setup_embeddings.py
-- same pattern, same user-facing promise: if setup says "verified", runtime
will not fall over because of a malformed or wrong-product key.
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from dataclasses import dataclass

log = logging.getLogger(__name__)


@dataclass
class VerifyResult:
    ok: bool
    message: str  # human-readable, shown in the wizard on failure
    http_status: int = 0  # 0 when the request didn't complete (timeout, DNS, etc.)


# Each verifier returns VerifyResult. All take (api_key) -> VerifyResult.
# Kept as thin functions so a future caller (doctor command, MCP bridge
# health check) can reuse them one-off.


def _get(url: str, headers: dict[str, str] | None = None, timeout: float = 10.0) -> tuple[int, str]:
    """Thin httpx.get wrapper that returns (status, body[:400])."""
    import httpx

    try:
        resp = httpx.get(url, headers=headers or {}, timeout=timeout)
    except httpx.TimeoutException:
        return 0, "request timed out"
    except httpx.ConnectError as e:
        return 0, f"connect failed ({e})"
    except Exception as e:
        return 0, f"{type(e).__name__}: {e}"
    return resp.status_code, resp.text[:400]


def _interpret(
    provider: str, status: int, body: str, auth_hint: str = "rotate the key"
) -> VerifyResult:
    """Common translation from HTTP status + body blob to user-facing text."""
    if status == 0:
        return VerifyResult(False, f"could not reach {provider}: {body}", 0)
    if 200 <= status < 300:
        return VerifyResult(True, "ok", status)
    if status in (401, 403):
        return VerifyResult(
            False,
            f"{provider} rejected the key ({status}). "
            f"The key is invalid, revoked, or missing a scope -- {auth_hint}.",
            status,
        )
    if status == 429:
        return VerifyResult(
            False,
            f"{provider} rate-limited the verification check (429). "
            "Key may be valid; retry in a minute or skip verification.",
            status,
        )
    if 500 <= status < 600:
        return VerifyResult(
            False,
            f"{provider} returned {status} (upstream outage). "
            "Key may be valid; try again in a minute or skip verification.",
            status,
        )
    return VerifyResult(
        False,
        f"{provider} returned unexpected {status}: {body[:120]}",
        status,
    )


def _verify_anthropic(api_key: str) -> VerifyResult:
    status, body = _get(
        "https://api.anthropic.com/v1/models",
        headers={"x-api-key": api_key, "anthropic-version": "2023-06-01"},
    )
    return _interpret("Anthropic", status, body)


def _verify_openai(api_key: str) -> VerifyResult:
    status, body = _get(
        "https://api.openai.com/v1/models",
        headers={"Authorization": f"Bearer {api_key}"},
    )
    return _interpret("OpenAI", status, body)


def _verify_google(api_key: str) -> VerifyResult:
    # Gemini API keys auth via query param, not header. If the key is for the
    # wrong Google product (Maps, Places, YouTube share the `AIza` prefix),
    # this endpoint returns a specific 403 with a helpful body.
    status, body = _get(f"https://generativelanguage.googleapis.com/v1beta/models?key={api_key}")
    result = _interpret(
        "Google Gemini", status, body, auth_hint="create a new key at aistudio.google.com"
    )
    # Google edge returns HTML 400 for totally unrecognized keys -- surface that
    # specifically so users know to check API enablement.
    if not result.ok and "Error 400 (Bad Request)!!1" in body:
        return VerifyResult(
            False,
            "Google rejected the key at its edge. Either the key isn't a Gemini "
            "API key (could be a Maps/Places key -- same AIza prefix), OR the "
            "'Generative Language API' is not enabled for the project the key "
            "belongs to. Get a Gemini-specific key at https://aistudio.google.com/apikey.",
            status,
        )
    return result


def _verify_groq(api_key: str) -> VerifyResult:
    status, body = _get(
        "https://api.groq.com/openai/v1/models",
        headers={"Authorization": f"Bearer {api_key}"},
    )
    return _interpret("Groq", status, body)


def _verify_mistral(api_key: str) -> VerifyResult:
    status, body = _get(
        "https://api.mistral.ai/v1/models",
        headers={"Authorization": f"Bearer {api_key}"},
    )
    return _interpret("Mistral", status, body)


def _verify_deepseek(api_key: str) -> VerifyResult:
    status, body = _get(
        "https://api.deepseek.com/v1/models",
        headers={"Authorization": f"Bearer {api_key}"},
    )
    return _interpret("DeepSeek", status, body)


def _verify_openrouter(api_key: str) -> VerifyResult:
    status, body = _get(
        "https://openrouter.ai/api/v1/auth/key",
        headers={"Authorization": f"Bearer {api_key}"},
    )
    return _interpret("OpenRouter", status, body)


def _verify_ollama(api_key: str) -> VerifyResult:
    """Ping local Ollama's /api/tags to confirm the daemon is reachable.

    The `api_key` argument is unused (Ollama's OpenAI-compat endpoint
    accepts any string), kept only to match the _VERIFIERS signature.
    """
    import os as _os

    base = _os.environ.get("OLLAMA_BASE_URL", "http://localhost:11434/v1")
    # Strip the /v1 to hit /api/tags (Ollama's native health endpoint).
    tags_url = base.rstrip("/").removesuffix("/v1") + "/api/tags"
    status, body = _get(tags_url, timeout=3.0)

    if status == 0:
        return VerifyResult(
            False,
            "Ollama is not reachable at "
            f"{tags_url.removesuffix('/api/tags')}. "
            "Start it with `ollama serve` (or install from https://ollama.com "
            "if you don't have it yet). Then pull a model, e.g. "
            "`ollama pull llama3`.",
            0,
        )
    if 200 <= status < 300:
        return VerifyResult(True, "ok", status)
    return VerifyResult(False, f"Ollama returned {status}: {body[:120]}", status)


_VERIFIERS: dict[str, Callable[[str], VerifyResult]] = {
    "anthropic": _verify_anthropic,
    "openai": _verify_openai,
    "google": _verify_google,
    "groq": _verify_groq,
    "mistral": _verify_mistral,
    "deepseek": _verify_deepseek,
    "openrouter": _verify_openrouter,
    "ollama": _verify_ollama,
}


def verify_api_key(provider_key: str, api_key: str) -> VerifyResult:
    """Ping the provider's /models endpoint to confirm the key authenticates.

    Returns VerifyResult(ok=True) for providers we don't know how to verify
    (forward-compat; unknown providers let setup proceed).
    """
    verifier = _VERIFIERS.get(provider_key)
    if verifier is None:
        return VerifyResult(True, f"no verifier for '{provider_key}'; skipping")
    try:
        return verifier(api_key)
    except Exception as e:
        log.warning("verify_api_key(%s) raised: %s", provider_key, e)
        return VerifyResult(False, f"verification raised {type(e).__name__}: {e}", 0)
