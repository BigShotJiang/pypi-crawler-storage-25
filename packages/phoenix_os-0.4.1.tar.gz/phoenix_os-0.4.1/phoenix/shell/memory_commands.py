"""`/memory` slash commands -- stats, breakdown, trace, forget, pin, unpin.

Split out of `commands.py` to keep that file under the 400-line cap and to
co-locate the memory command dispatcher with its helpers. Registered by
`commands.py`'s `COMMANDS` dict, which imports `cmd_memory` from here.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from phoenix.shell.display import BOLD, CYAN, DIM, GREEN, RESET, YELLOW

if TYPE_CHECKING:
    from phoenix.shell.commands import CommandContext


_PIN_MIN_STRENGTH = 1.5
_PIN_MIN_ACCESS = 3
_PIN_BLOCKED_INTENTS = frozenset({"venting", "excited"})


async def cmd_memory(args: str, ctx: CommandContext) -> str:
    """`/memory` subcommands.

    - `/memory`                 stats
    - `/memory why`             last-recall breakdown
    - `/memory trace <query>`   recall for <query> without mutating hit counts
    - `/memory forget <query>`  hard-delete the best text match
    - `/memory pin <query>`     pin best match (guardrails apply)
    - `/memory unpin <query>`   unpin best match
    - `/memory patterns`        list consolidated insights (v0.7+)
    """
    if not ctx.engine or not ctx.engine._memory:
        return "Memory system not available."

    memory = ctx.engine._memory
    stripped = args.strip()
    lower = stripped.lower()

    if lower == "why":
        return _format_breakdown(memory)
    if lower == "patterns":
        return await _memory_patterns(memory)
    if lower.startswith("trace"):
        rest = stripped[len("trace") :].strip()
        if not rest:
            return (
                f"{YELLOW}Usage: {BOLD}/memory trace <query>{RESET}\n"
                f"{DIM}Runs the recall pipeline for <query> without touching access counts.{RESET}"
            )
        await memory.trace(rest)
        return _format_breakdown(memory, header_query=rest)
    if lower.startswith("forget"):
        rest = stripped[len("forget") :].strip()
        return await _memory_forget(memory, rest)
    if lower.startswith("unpin"):
        rest = stripped[len("unpin") :].strip()
        return await _memory_pin(memory, rest, pinned=False)
    if lower.startswith("pin"):
        rest = stripped[len("pin") :].strip()
        return await _memory_pin(memory, rest, pinned=True)

    stats = await memory.stats()
    lines = [f"{BOLD}Memory Stats{RESET}"]
    lines.append(f"  Total memories: {stats['total']}")
    lines.append(f"  Pinned: {stats['pinned']}")
    lines.append(f"  Clusters: {stats['clusters']}")
    lines.append(f"  Graph edges: {stats['edge_count']}")
    lines.append(f"  Episodes: {stats['episodes']}")
    lines.append(f"  Avg strength: {stats['avg_strength']}")
    if stats.get("by_category"):
        cats = ", ".join(f"{k}:{v}" for k, v in stats["by_category"].items())
        lines.append(f"  Categories: {cats}")
    if stats.get("by_namespace"):
        nss = ", ".join(f"{k}:{v}" for k, v in stats["by_namespace"].items())
        lines.append(f"  Namespaces: {nss}")
    lines.append("")
    lines.append(
        f"{DIM}Subcommands: {CYAN}/memory why{RESET}{DIM}, "
        f"{CYAN}/memory trace <q>{RESET}{DIM}, "
        f"{CYAN}/memory forget <q>{RESET}{DIM}, "
        f"{CYAN}/memory pin|unpin <q>{RESET}{DIM}, "
        f"{CYAN}/memory patterns{RESET}"
    )
    return "\n".join(lines)


async def _memory_patterns(memory) -> str:
    """List consolidated insights (`category="insight"`).

    Searches the store for `[consolidated]`-prefixed rows (the convention
    consolidation writes). Falls back to `~/.phoenix/insights.md` so the
    file mirror is browsable even when the store is missing rows.
    """
    await memory._ensure_initialized()
    rows = await memory.store.search_text("[consolidated]", limit=20)
    rows = [r for r in rows if r.get("category") == "insight"]
    if rows:
        lines = [f"{BOLD}Patterns Phoenix has noticed{RESET}"]
        for r in rows:
            content = r.get("content", "").removeprefix("[consolidated] ")[:200]
            lines.append(f"  {CYAN}-{RESET} {content}")
        return "\n".join(lines)

    # Fallback: read insights.md (set up by consolidation as a secondary
    # surface; useful when Boss browses outside Phoenix).
    try:
        from phoenix.config.settings import PHOENIX_DIR

        path = PHOENIX_DIR / "insights.md"
        if path.exists() and path.is_file():
            body = path.read_text(errors="replace").strip()
            if body:
                return f"{BOLD}Patterns (from insights.md){RESET}\n{body}"
    except OSError:
        pass

    return f"{DIM}No patterns yet -- consolidation runs every {memory.config.consolidate_every} turns.{RESET}"


async def _memory_forget(memory, query: str) -> str:
    if not query:
        return (
            f"{YELLOW}Usage: {BOLD}/memory forget <query>{RESET}\n"
            f"{DIM}Hard-deletes the best text match. Irreversible.{RESET}"
        )
    await memory._ensure_initialized()
    results = await memory.store.search_text(query, limit=5)
    if not results:
        return f"{DIM}No memories found matching {query!r}.{RESET}"
    best = results[0]
    mid = best["id"]
    content = best["content"][:100]
    await memory.store.delete(mid)
    return f"{GREEN}Forgotten{RESET}: [{mid}] {content}"


async def _memory_pin(memory, query: str, pinned: bool) -> str:
    """Pin or unpin a memory by best-text-match.

    Unpin is unrestricted. Pin requires an established, used, non-emotional
    fact (strength >= 1.5, access_count >= 3, intent not in {venting,
    excited}). Without these guards, an LLM can (and has) pinned emotional
    confessions as identity and surfaced them in every profile load.
    """
    if not query:
        verb = "pin" if pinned else "unpin"
        return (
            f"{YELLOW}Usage: {BOLD}/memory {verb} <query>{RESET}\n"
            f"{DIM}{'Pin' if pinned else 'Unpin'}s the best text match.{RESET}"
        )
    await memory._ensure_initialized()
    results = await memory.store.search_text(query, limit=5)
    if not results:
        return f"{DIM}No memories found matching {query!r}.{RESET}"

    best = results[0]
    mid = best["id"]
    content = best["content"][:100]

    if pinned:
        strength = float(best.get("strength", 0.0))
        access_count = int(best.get("access_count", 0))
        intent = best.get("intent")
        missing = []
        if strength < _PIN_MIN_STRENGTH:
            missing.append(f"strength {strength:.2f} < {_PIN_MIN_STRENGTH}")
        if access_count < _PIN_MIN_ACCESS:
            missing.append(f"access_count {access_count} < {_PIN_MIN_ACCESS}")
        if intent in _PIN_BLOCKED_INTENTS:
            missing.append(f"intent={intent!r} is emotional")
        if missing:
            return (
                f"{YELLOW}Refusing to pin [{mid}]{RESET}: {'; '.join(missing)}. "
                f"{DIM}Pin is reserved for established, used, non-emotional facts. "
                f"Let the memory strengthen through reinforcement first.{RESET}"
            )

    await memory.store.set_pinned(mid, pinned)
    verb = "Pinned" if pinned else "Unpinned"
    return f"{GREEN}{verb}{RESET}: [{mid}] {content}"


def _format_breakdown(memory, header_query: str = "", max_rows: int = 15) -> str:
    """Render `MemorySystem.last_breakdown` as a fixed-width table.

    Plain-text labels (no ANSI) because the Textual TUI strips color codes
    but leaves the f-string width accounting intact, which mis-aligns the
    columns. Plain text is stable under the strip and still readable outside
    the TUI.
    """
    breakdown = memory.last_breakdown
    query = header_query or memory.last_query
    if not breakdown:
        return (
            f"{DIM}No recall breakdown captured yet. Run a turn or use "
            f"{CYAN}/memory trace <query>{RESET}{DIM} first.{RESET}"
        )

    reason_short = {
        "passed": "passed",
        "below_min_relevance_pre_score": "sem<min",
        "below_min_relevance_post_spread": "score<min",
        "below_direct_relevance_gate": "direct<gate",
        "duplicate_skipped": "dup",
        "topk_cap_exceeded": "topk_cap",
        "store_lookup_failed": "store_miss",
        "reached_scoring": "unranked",
        "no_embedding_skipped": "no_emb",
        "suppressed_single_weak": "single_weak",
        "query_rejected_degenerate": "q_rejected",
    }

    lines = [f"Memory breakdown (query: {query[:60]!r})"]
    lines.append(
        f"  {'sem':>5}  {'compo':>6}  {'direct':>6}  {'str':>4}  {'pin':>3}  {'gate':<12}  content"
    )
    lines.append(f"  {'-' * 95}")

    shown = breakdown[:max_rows]
    for b in shown:
        sem = f"{b['sem_score']:.2f}"
        comp = f"{b['composite_score']:.2f}"
        direct = f"{b['direct_relevance']:.2f}" if b["direct_relevance"] is not None else "  -  "
        strength = f"{b['strength']:.2f}" if b["strength"] else "  - "
        pin = "Y" if b["pinned"] else " "
        gate = reason_short.get(b["gate_reason"], b["gate_reason"][:12])
        content = b["content"].replace("\n", " ").strip()[:50] or "(unloaded)"
        lines.append(
            f"  {sem:>5}  {comp:>6}  {direct:>6}  {strength:>4}   {pin}    {gate:<12}  {content}"
        )

    if len(breakdown) > max_rows:
        lines.append(f"  ... and {len(breakdown) - max_rows} more candidates below.")

    passed = sum(1 for b in breakdown if b["passed_gate"])
    lines.append("")
    lines.append(f"  {len(breakdown)} candidates scored, {passed} passed all gates.")
    return "\n".join(lines)
