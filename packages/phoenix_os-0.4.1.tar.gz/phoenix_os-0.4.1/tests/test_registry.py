"""Tests for core/registry.py."""

import os

from phoenix.core.registry import Registry


def test_discover_abilities():
    reg = Registry()
    reg.discover_abilities()
    abilities = reg.list_abilities()
    assert "ask_user" in abilities
    assert "bash" in abilities
    assert "grep" in abilities
    assert "read_file" in abilities
    assert "write_file" in abilities
    assert "search_replace" in abilities
    assert "git_info" in abilities
    assert "claude_code" in abilities
    assert "read_pdf" in abilities
    assert "notes" in abilities
    # memory_manage was removed in v0.5 -- memory is the nervous system, not a tool.
    # /memory forget and /memory pin are user slash commands, not model tools.
    assert "memory_manage" not in abilities
    # web_search is conditionally registered via @ability(requires_env=[...]) --
    # present when BRAVE_API_KEY is set (dev machines), absent in clean CI.
    if os.environ.get("BRAVE_API_KEY"):
        assert "web_search" in abilities
        assert len(abilities) == 11
    else:
        assert "web_search" not in abilities
        assert len(abilities) == 10


def test_discover_agents():
    reg = Registry()
    reg.discover_agents()
    agents = reg.list_agents()
    assert "brain" in agents
    assert "worker" in agents
    assert "explorer" in agents
    assert "planner" in agents
    assert len(agents) == 4


def test_get_ability():
    reg = Registry()
    reg.discover_abilities()
    info = reg.get_ability("bash")
    assert info is not None
    assert info.name == "bash"
    assert info.is_async is True
    assert info.description


def test_get_agent_config():
    reg = Registry()
    reg.discover_agents()
    config = reg.get_agent_config("worker")
    assert config is not None
    assert config.name == "worker"
    assert "bash" in config.abilities


def test_get_agent_abilities():
    reg = Registry()
    reg.discover_all()
    worker_abilities = reg.get_agent_abilities("worker")
    names = [a.name for a in worker_abilities]
    assert "bash" in names
    assert "claude_code" in names
    assert "grep" in names


def test_missing_ability():
    reg = Registry()
    reg.discover_abilities()
    assert reg.get_ability("nonexistent") is None


def test_missing_agent():
    reg = Registry()
    reg.discover_agents()
    assert reg.get_agent_config("nonexistent") is None
