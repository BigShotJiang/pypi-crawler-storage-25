"""
CLI entry point per bge-auto-tune.

Uso:
    bge-auto-tune generate [opzioni]
    bge-auto-tune generate --docling --docs-dir ./my_docs
    bge-auto-tune finetune [opzioni]
    bge-auto-tune test [opzioni]
    bge-auto-tune run [opzioni]        ← esegue tutto: generate → finetune → test
"""

import argparse
import os
import sys
import time


def main():
    parser = argparse.ArgumentParser(
        prog="bge-auto-tune",
        description="Fine-tune BAAI/bge-m3 per retrieval + reranking su dominio specifico",
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s 0.1.0")

    subparsers = parser.add_subparsers(dest="command", required=True)

    # ══════════════════════════════════════════════════════
    # generate
    # ══════════════════════════════════════════════════════
    gen = subparsers.add_parser("generate", help="Genera dataset di training dai chunk Qdrant o da documenti (Docling)")

    # — Modalità Docling —
    gen.add_argument("--docling", action="store_true",
                     help="Usa Docling per parsing documenti locali invece di Qdrant")
    gen.add_argument("--docs-dir",
                     default=os.getenv("DOCS_DIR"),
                     help="Directory con i documenti da parsare (richiesto con --docling)")
    gen.add_argument("--docling-url",
                     default=os.getenv("DOCLING_URL", "http://localhost:5001"),
                     help="URL del servizio Docling (default: http://localhost:5001)")
    gen.add_argument("--docling-timeout", type=int, default=3600,
                     help="Timeout in secondi per il parsing di un singolo documento (default: 3600)")
    gen.add_argument("--embed-batch", type=int, default=32,
                     help="Batch size per embedding dei chunk (default: 32)")

    # Docling chunking params
    gen.add_argument("--chunking-max-tokens", type=int, default=512,
                     help="Max tokens per chunk nel chunking semantico Docling (default: 512)")
    gen.add_argument("--chunking-tokenizer", default="BAAI/bge-m3",
                     help="Tokenizer per il chunking Docling (default: BAAI/bge-m3)")

    # Docling OCR/parsing params
    gen.add_argument("--docling-ocr", action="store_false", default=False,
                     help="Abilita OCR in Docling (default: true)")
    gen.add_argument("--no-docling-ocr", dest="docling_ocr", action="store_false")
    gen.add_argument("--docling-ocr-engine", default="easyocr",
                     help="OCR engine per Docling (default: easyocr)")
    gen.add_argument("--docling-ocr-lang", default='["it", "en"]',
                     help='Lingue OCR come JSON array (default: \'["it", "en"]\')')
    gen.add_argument("--docling-pdf-backend", default="dlparse_v4",
                     help="PDF backend Docling (default: dlparse_v4)")
    gen.add_argument("--docling-table-mode", default="fast",
                     help="Modalità tabelle Docling (default: fast)")
    gen.add_argument("--docling-table-cell-matching", action="store_false", default=False)

    # — Modalità Qdrant (default) —
    gen.add_argument("--qdrant-url", default=os.getenv("QDRANT_URL", "http://localhost:6333"))
    gen.add_argument("--collection", default=os.getenv("QDRANT_COLLECTION", "docs"))
    gen.add_argument("--text-field", default="text")
    gen.add_argument("--scroll-batch", type=int, default=100)

    # — LLM —
    gen.add_argument("--llm-url", default=os.getenv("LLM_URL", "http://localhost:8001/v1"))
    gen.add_argument("--llm-model", default=os.getenv("LLM_MODEL", "Qwen/Qwen3-4B-Instruct-2507"))
    gen.add_argument("--llm-api-key", default=os.getenv("LLM_API_KEY", "none"))

    # — Embedding —
    gen.add_argument("--embed-url", default=os.getenv("EMBED_URL", "http://localhost:8004"))

    # — Dataset —
    gen.add_argument("--output", default="bge_m3_training.jsonl")
    gen.add_argument("--queries-per-chunk", type=int, default=3)
    gen.add_argument("--hard-negatives", type=int, default=7)
    gen.add_argument("--min-pairs", type=int, default=2000)
    gen.add_argument("--max-chunks", type=int, default=None)

    # — Filtri —
    gen.add_argument("--min-chunk-length", type=int, default=100)
    gen.add_argument("--min-words", type=int, default=20)
    gen.add_argument("--min-alpha-ratio", type=float, default=0.4)
    gen.add_argument("--skip-llm-filter", action="store_true")

    # — Misc —
    gen.add_argument("--seed", type=int, default=42)
    gen.add_argument("--resume", action="store_true")

    gen.add_argument("--vector-name", default=None,
                     help="Named vector in Qdrant (e.g. 'dense'). Leave empty for unnamed vectors")

    # ══════════════════════════════════════════════════════
    # finetune
    # ══════════════════════════════════════════════════════
    ft = subparsers.add_parser("finetune", help="Fine-tune BGE-M3 (unified dense+sparse+colbert)")

    ft.add_argument("--dataset", default="bge_m3_training.jsonl")
    ft.add_argument("--model", default="BAAI/bge-m3")
    ft.add_argument("--output", default="./bge-m3-finetuned")

    ft.add_argument("--epochs", type=int, default=2)
    ft.add_argument("--lr", type=float, default=1e-5)
    ft.add_argument("--batch-size", type=int, default=4)
    ft.add_argument("--temperature", type=float, default=0.02)
    ft.add_argument("--warmup-ratio", type=float, default=0.05)

    ft.add_argument("--max-passage-len", type=int, default=1024)
    ft.add_argument("--max-query-len", type=int, default=256)
    ft.add_argument("--train-group-size", type=int, default=8)

    ft.add_argument("--save-steps", type=int, default=500)
    ft.add_argument("--logging-steps", type=int, default=10)
    ft.add_argument("--gradient-checkpointing", action="store_true", default=True)
    ft.add_argument("--no-gradient-checkpointing", dest="gradient_checkpointing", action="store_false")

    # ══════════════════════════════════════════════════════
    # test
    # ══════════════════════════════════════════════════════
    ts = subparsers.add_parser("test", help="Testa retrieval base vs fine-tunato")

    ts.add_argument("--base-model", default="BAAI/bge-m3")
    ts.add_argument("--model", default="./bge-m3-finetuned")
    ts.add_argument("--dataset", default="bge_m3_training.jsonl")

    ts.add_argument("--test-queries", type=int, default=200)
    ts.add_argument("--test-split", type=float, default=0.2,
                    help="Fraction of data to hold out for testing (default 0.2)")
    ts.add_argument("--top-k", type=int, default=10)
    ts.add_argument("--max-len", type=int, default=1024)
    ts.add_argument("--batch-size", type=int, default=16)

    ts.add_argument("--dense-weight", type=float, default=0.30,
                    help="Dense weight for reranking (default 0.30)")
    ts.add_argument("--sparse-weight", type=float, default=0.65,
                    help="Sparse weight for reranking (default 0.65)")
    ts.add_argument("--colbert-weight", type=float, default=0.05,
                    help="ColBERT weight for reranking (default 0.05)")

    ts.add_argument("--output", default="test_results.json")
    ts.add_argument("--verbose", action="store_true")
    ts.add_argument("--seed", type=int, default=42)
    ts.add_argument("--device", default="auto")

    # ══════════════════════════════════════════════════════
    # reindex
    # ══════════════════════════════════════════════════════
    ri = subparsers.add_parser("reindex", help="Re-indicizza collection Qdrant col modello fine-tunato")

    ri.add_argument("--collections", required=True,
                    help="Collection da re-indicizzare (virgola-separated, es: docs,faq)")
    ri.add_argument("--qdrant-url", default=os.getenv("QDRANT_URL", "http://localhost:6333"))
    ri.add_argument("--embed-url", default=os.getenv("EMBED_URL", "http://localhost:8004"))
    ri.add_argument("--text-field", default="text",
                    help="Campo payload con il testo (default: text)")

    ri.add_argument("--vectors", default="dense,sparse",
                    help="Tipi di vettore da generare, virgola-separated (default: dense,sparse)")
    ri.add_argument("--vector-names", default=None,
                    help="Mapping tipo:nome, es: 'dense:dense,sparse:sparse'. "
                         "Default: usa il tipo come nome")
    ri.add_argument("--unnamed-vectors", action="store_true",
                    help="Usa vettori unnamed (solo dense, nessun nome)")

    ri.add_argument("--test", action="store_true",
                    help="Crea collection di test separate invece di sovrascrivere")
    ri.add_argument("--embed-batch", type=int, default=32)
    ri.add_argument("--scroll-batch", type=int, default=100)
    ri.add_argument("--yes", "-y", action="store_true",
                    help="Salta conferma")

    # ══════════════════════════════════════════════════════
    # publish
    # ══════════════════════════════════════════════════════
    pub = subparsers.add_parser("publish", help="Pubblica il modello su HuggingFace Hub")

    pub.add_argument("--model", default="./bge-m3-finetuned")
    pub.add_argument("--repo", required=True, help="HuggingFace repo (user/model-name)")
    pub.add_argument("--private", action="store_true")
    pub.add_argument("--branch", default="main")
    pub.add_argument("--message", default=None)
    pub.add_argument("--yes", "-y", action="store_true")

    # ══════════════════════════════════════════════════════
    # run (pipeline completa)
    # ══════════════════════════════════════════════════════
    run = subparsers.add_parser("run", help="Esegui generate → finetune → test in sequenza")

    # — Docling mode —
    run.add_argument("--docling", action="store_true",
                     help="Usa Docling per parsing documenti locali invece di Qdrant")
    run.add_argument("--docs-dir", default=os.getenv("DOCS_DIR"),
                     help="Directory con i documenti da parsare (richiesto con --docling)")
    run.add_argument("--docling-url",
                     default=os.getenv("DOCLING_URL", "http://localhost:5001"))
    run.add_argument("--docling-timeout", type=int, default=3600)
    run.add_argument("--chunking-max-tokens", type=int, default=512)
    run.add_argument("--chunking-tokenizer", default="BAAI/bge-m3")
    run.add_argument("--docling-ocr", action="store_true", default=True)
    run.add_argument("--no-docling-ocr", dest="docling_ocr", action="store_false")
    run.add_argument("--docling-ocr-engine", default="easyocr")
    run.add_argument("--docling-ocr-lang", default='["it", "en"]')
    run.add_argument("--docling-pdf-backend", default="dlparse_v4")
    run.add_argument("--docling-table-mode", default="fast")
    run.add_argument("--docling-table-cell-matching", action="store_false", default=False)

    # — Generate (Qdrant) —
    run.add_argument("--qdrant-url", default=os.getenv("QDRANT_URL", "http://localhost:6333"))
    run.add_argument("--collection", default=os.getenv("QDRANT_COLLECTION", "docs"))
    run.add_argument("--text-field", default="text")
    run.add_argument("--scroll-batch", type=int, default=100)

    run.add_argument("--llm-url", default=os.getenv("LLM_URL", "http://localhost:8001/v1"))
    run.add_argument("--llm-model", default=os.getenv("LLM_MODEL", "Qwen/Qwen3-4B-Instruct-2507"))
    run.add_argument("--llm-api-key", default=os.getenv("LLM_API_KEY", "none"))

    run.add_argument("--embed-url", default=os.getenv("EMBED_URL", "http://localhost:8004"))
    run.add_argument("--embed-batch", type=int, default=32)

    run.add_argument("--queries-per-chunk", type=int, default=3)
    run.add_argument("--hard-negatives", type=int, default=7)
    run.add_argument("--min-pairs", type=int, default=2000)
    run.add_argument("--max-chunks", type=int, default=None)

    run.add_argument("--min-chunk-length", type=int, default=100)
    run.add_argument("--min-words", type=int, default=20)
    run.add_argument("--min-alpha-ratio", type=float, default=0.4)
    run.add_argument("--skip-llm-filter", action="store_true")

    run.add_argument("--vector-name", default=None)

    # — Finetune —
    run.add_argument("--model", default="BAAI/bge-m3")
    run.add_argument("--model-output", default="./bge-m3-finetuned")
    run.add_argument("--epochs", type=int, default=2)
    run.add_argument("--lr", type=float, default=1e-5)
    run.add_argument("--batch-size", type=int, default=4)
    run.add_argument("--temperature", type=float, default=0.02)
    run.add_argument("--warmup-ratio", type=float, default=0.05)
    run.add_argument("--max-passage-len", type=int, default=1024)
    run.add_argument("--max-query-len", type=int, default=256)
    run.add_argument("--train-group-size", type=int, default=8)
    run.add_argument("--save-steps", type=int, default=500)
    run.add_argument("--logging-steps", type=int, default=10)
    run.add_argument("--gradient-checkpointing", action="store_true", default=True)
    run.add_argument("--no-gradient-checkpointing", dest="gradient_checkpointing",
                     action="store_false")

    # — Test —
    run.add_argument("--test-queries", type=int, default=200)
    run.add_argument("--test-split", type=float, default=0.2)
    run.add_argument("--top-k", type=int, default=10)
    run.add_argument("--dense-weight", type=float, default=0.30)
    run.add_argument("--sparse-weight", type=float, default=0.65)
    run.add_argument("--colbert-weight", type=float, default=0.05)
    run.add_argument("--device", default="auto")

    # — Shared —
    run.add_argument("--dataset", default="bge_m3_training.jsonl",
                     help="Path del dataset JSONL (usato da tutti gli step)")
    run.add_argument("--seed", type=int, default=42)
    run.add_argument("--verbose", action="store_true")

    # ══════════════════════════════════════════════════════
    # Dispatch
    # ══════════════════════════════════════════════════════
    args = parser.parse_args()

    if args.command == "generate":
        if args.docling:
            if not args.docs_dir:
                parser.error("--docs-dir è richiesto quando si usa --docling")
            from .generate_dataset_docling import run_generate_docling
            run_generate_docling(args)
        else:
            from .generate_dataset import run_generate
            run_generate(args)

    elif args.command == "finetune":
        from .finetune_bge_m3 import run_finetune
        run_finetune(args)

    elif args.command == "test":
        from .test_retrieval import run_test
        run_test(args)

    elif args.command == "publish":
        from .publish import run_publish
        run_publish(args)

    elif args.command == "reindex":
        from .reindex import run_reindex
        run_reindex(args)

    elif args.command == "run":
        _run_pipeline(args)


# ══════════════════════════════════════════════════════════════
# 🚀 PIPELINE COMPLETA
# ══════════════════════════════════════════════════════════════

def _run_pipeline(args):
    """Esegue generate → finetune → test in sequenza."""
    from argparse import Namespace

    total_start = time.time()
    dataset_path = args.dataset
    model_output = args.model_output

    is_docling = args.docling

    print("""
╔══════════════════════════════════════════════════════════════╗
║        🚀  BGE Auto-Tune — Pipeline Completa                 ║
║        generate → finetune → test                            ║
╚══════════════════════════════════════════════════════════════╝
    """)

    if is_docling:
        print(f"  📄 Modalità: Docling (documenti locali)")
        if not args.docs_dir:
            print(f"  ✗ --docs-dir è richiesto con --docling")
            sys.exit(1)
    else:
        print(f"  🗃️  Modalità: Qdrant (chunk esistenti)")

    if args.verbose:
        print(f"  📋 Configurazione:")
        print(f"     Dataset:           {dataset_path}")
        print(f"     Modello base:      {args.model}")
        print(f"     Output modello:    {model_output}")
        if is_docling:
            print(f"     Docs dir:          {args.docs_dir}")
            print(f"     Docling:           {args.docling_url}")
        else:
            print(f"     Collection:        {args.collection}")
            print(f"     Qdrant:            {args.qdrant_url}")
        print(f"     LLM:              {args.llm_model}")
        print(f"     Epochs:            {args.epochs}")
        print(f"     LR:               {args.lr}")
        print(f"     Min pairs:         {args.min_pairs}")
        print()

    # ── STEP 1: Generate ──
    print(f"{'═' * 60}")
    print(f"  📊  STEP 1/3 — Generazione dataset")
    print(f"{'═' * 60}\n")

    step_start = time.time()

    if is_docling:
        gen_args = Namespace(
            docling=True,
            docs_dir=args.docs_dir,
            docling_url=args.docling_url,
            docling_timeout=args.docling_timeout,
            chunking_max_tokens=args.chunking_max_tokens,
            chunking_tokenizer=args.chunking_tokenizer,
            docling_ocr=args.docling_ocr,
            docling_ocr_engine=args.docling_ocr_engine,
            docling_ocr_lang=args.docling_ocr_lang,
            docling_pdf_backend=args.docling_pdf_backend,
            docling_table_mode=args.docling_table_mode,
            docling_table_cell_matching=args.docling_table_cell_matching,
            embed_batch=args.embed_batch,
            llm_url=args.llm_url,
            llm_model=args.llm_model,
            llm_api_key=args.llm_api_key,
            embed_url=args.embed_url,
            output=dataset_path,
            queries_per_chunk=args.queries_per_chunk,
            hard_negatives=args.hard_negatives,
            min_pairs=args.min_pairs,
            max_chunks=args.max_chunks,
            min_chunk_length=args.min_chunk_length,
            min_words=args.min_words,
            min_alpha_ratio=args.min_alpha_ratio,
            skip_llm_filter=args.skip_llm_filter,
            seed=args.seed,
            resume=False,
        )
        try:
            from .generate_dataset_docling import run_generate_docling
            run_generate_docling(gen_args)
        except Exception as e:
            print(f"\n  ✗ Step 1 fallito: {e}")
            sys.exit(1)
    else:
        gen_args = Namespace(
            qdrant_url=args.qdrant_url,
            collection=args.collection,
            text_field=args.text_field,
            scroll_batch=args.scroll_batch,
            llm_url=args.llm_url,
            llm_model=args.llm_model,
            llm_api_key=args.llm_api_key,
            embed_url=args.embed_url,
            output=dataset_path,
            queries_per_chunk=args.queries_per_chunk,
            hard_negatives=args.hard_negatives,
            min_pairs=args.min_pairs,
            max_chunks=args.max_chunks,
            min_chunk_length=args.min_chunk_length,
            min_words=args.min_words,
            min_alpha_ratio=args.min_alpha_ratio,
            skip_llm_filter=args.skip_llm_filter,
            seed=args.seed,
            resume=False,
            vector_name=args.vector_name,
        )
        try:
            from .generate_dataset import run_generate
            run_generate(gen_args)
        except Exception as e:
            print(f"\n  ✗ Step 1 fallito: {e}")
            sys.exit(1)

    print(f"\n  ⏱️  Step 1 completato in {(time.time() - step_start) / 60:.1f} minuti\n")

    # ── STEP 2: Finetune ──
    print(f"{'═' * 60}")
    print(f"  🔧  STEP 2/3 — Fine-tuning")
    print(f"{'═' * 60}\n")

    ft_args = Namespace(
        dataset=dataset_path,
        model=args.model,
        output=model_output,
        epochs=args.epochs,
        lr=args.lr,
        batch_size=args.batch_size,
        temperature=args.temperature,
        warmup_ratio=args.warmup_ratio,
        max_passage_len=args.max_passage_len,
        max_query_len=args.max_query_len,
        train_group_size=args.train_group_size,
        save_steps=args.save_steps,
        logging_steps=args.logging_steps,
        gradient_checkpointing=args.gradient_checkpointing,
    )

    step_start = time.time()
    try:
        from .finetune_bge_m3 import run_finetune
        run_finetune(ft_args)
    except Exception as e:
        print(f"\n  ✗ Step 2 fallito: {e}")
        sys.exit(1)
    print(f"\n  ⏱️  Step 2 completato in {(time.time() - step_start) / 60:.1f} minuti\n")

    # ── STEP 3: Test ──
    print(f"{'═' * 60}")
    print(f"  🔬  STEP 3/3 — Test retrieval")
    print(f"{'═' * 60}\n")

    test_args = Namespace(
        base_model="BAAI/bge-m3",
        model=model_output,
        dataset=dataset_path,
        test_queries=args.test_queries,
        test_split=args.test_split,
        top_k=args.top_k,
        max_len=args.max_passage_len,
        batch_size=16,
        dense_weight=args.dense_weight,
        sparse_weight=args.sparse_weight,
        colbert_weight=args.colbert_weight,
        output="test_results.json",
        verbose=args.verbose,
        seed=args.seed,
        device=args.device,
    )

    step_start = time.time()
    try:
        from .test_retrieval import run_test
        run_test(test_args)
    except Exception as e:
        print(f"\n  ✗ Step 3 fallito: {e}")
        sys.exit(1)
    print(f"\n  ⏱️  Step 3 completato in {(time.time() - step_start) / 60:.1f} minuti\n")

    # ── Riepilogo ──
    total_elapsed = time.time() - total_start
    print(f"{'═' * 60}")
    print(f"  ✅  Pipeline completata!")
    print(f"{'═' * 60}")
    print(f"  ⏱️  Tempo totale: {total_elapsed / 60:.1f} minuti")
    print(f"  💾 Dataset:       {dataset_path}")
    print(f"  🔧 Modello:       {model_output}")
    print(f"  📊 Test report:   test_results.json")
    print(f"\n  Prossimo passo: ri-indicizza Qdrant col nuovo modello!")
    print()


if __name__ == "__main__":
    main()