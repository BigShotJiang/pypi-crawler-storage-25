"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  generate_dataset.py                                                       ║
║  Genera dataset di training per BGE-M3 dai chunk in Qdrant                 ║
║                                                                            ║
║  Workflow:                                                                 ║
║    1. Scroll di tutti i point dalla collection Qdrant                      ║
║    2. Filtro deterministico (lunghezza, ratio testo, duplicati)            ║
║    3. Filtro qualità con LLM locale (via OpenAI SDK → vLLM)               ║
║    4. Generazione query sintetiche con LLM                                 ║
║    5. Ricerca hard negatives in Qdrant                                     ║
║    6. Salvataggio dataset JSONL per FlagEmbedding                          ║
║                                                                            ║
║  Uso:                                                                      ║
║    python generate_dataset.py                                              ║
║    python generate_dataset.py --collection my_docs --min-pairs 3000        ║
║    python generate_dataset.py --qdrant-url http://10.0.0.1:6333            ║
║                                                                            ║
║  Env vars (alternativa ai flag):                                           ║
║    QDRANT_URL, QDRANT_COLLECTION, LLM_URL, LLM_MODEL, EMBED_URL           ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import os
import re
import sys
import json
import time
import random
import argparse
import logging

import requests
from openai import OpenAI
from qdrant_client import QdrantClient

# ════════════════════════════════════════════════════════════════
# 📋 LOGGING
# ════════════════════════════════════════════════════════════════

logging.basicConfig(
    level=logging.INFO,
    format="%(message)s",
)
logger = logging.getLogger("dataset-gen")


# ════════════════════════════════════════════════════════════════
# ⚙️ CONFIG & ARGS
# ════════════════════════════════════════════════════════════════

def parse_args():
    p = argparse.ArgumentParser(description="Genera dataset BGE-M3 da Qdrant")

    # Qdrant
    p.add_argument("--qdrant-url", default=os.getenv("QDRANT_URL", "http://localhost:6333"))
    p.add_argument("--collection", default=os.getenv("QDRANT_COLLECTION", "docs"))
    p.add_argument("--text-field", default="text",
                   help="Nome del campo payload che contiene il testo del chunk")
    p.add_argument("--scroll-batch", type=int, default=100,
                   help="Batch size per lo scroll Qdrant")

    # LLM locale
    p.add_argument("--llm-url", default=os.getenv("LLM_URL", "http://localhost:8001/v1"))
    p.add_argument("--llm-model", default=os.getenv("LLM_MODEL", "Qwen/Qwen3-4B-Instruct-2507"))
    p.add_argument("--llm-api-key", default=os.getenv("LLM_API_KEY", "none"))

    # Embedding server (il TUO bge-m3 service)
    p.add_argument("--embed-url", default=os.getenv("EMBED_URL", "http://localhost:8004"))

    # Dataset
    p.add_argument("--output", default="bge_m3_training.jsonl")
    p.add_argument("--queries-per-chunk", type=int, default=3)
    p.add_argument("--hard-negatives", type=int, default=7,
                   help="Numero di hard negatives per query")
    p.add_argument("--min-pairs", type=int, default=2000,
                   help="Numero minimo di coppie da generare prima di fermarsi")
    p.add_argument("--max-chunks", type=int, default=None,
                   help="Limita il numero di chunk da processare (per test)")

    # Filtri
    p.add_argument("--min-chunk-length", type=int, default=100,
                   help="Lunghezza minima chunk in caratteri")
    p.add_argument("--min-words", type=int, default=20)
    p.add_argument("--min-alpha-ratio", type=float, default=0.4,
                   help="Rapporto minimo caratteri alfabetici / totali")
    p.add_argument("--skip-llm-filter", action="store_true",
                   help="Salta il filtro qualità LLM (più veloce)")

    # Misc
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--resume", action="store_true",
                   help="Riprendi da un output parziale esistente")

    return p.parse_args()


# ════════════════════════════════════════════════════════════════
# 🧹 FILTRI DETERMINISTICI
# ════════════════════════════════════════════════════════════════

JUNK_PATTERNS = [
    re.compile(r"^page\s+\d+\s+(of|di)\s+\d+$", re.I),
    re.compile(r"^pagina\s+\d+\s+di\s+\d+$", re.I),
    re.compile(r"^[-_=\s]{10,}$"),
    re.compile(r"^\.{5,}$"),
    re.compile(r"^tutti i diritti riservati", re.I),
    re.compile(r"^all rights reserved", re.I),
    re.compile(r"^copyright\s", re.I),
]


def is_chunk_usable(text, args):
    """
    Filtri deterministici rapidi.
    Ritorna (True/False, motivo)
    """
    text = text.strip()

    if len(text) < args.min_chunk_length:
        return False, "troppo_corto"

    words = text.split()
    if len(words) < args.min_words:
        return False, "poche_parole"

    # Rapporto testo vs numeri/simboli
    alpha_chars = sum(1 for c in text if c.isalpha())
    if len(text) > 0 and alpha_chars / len(text) < args.min_alpha_ratio:
        return False, "troppi_numeri_simboli"

    # Righe duplicate (header/footer ripetuti)
    lines = [l.strip() for l in text.split("\n") if l.strip()]
    if lines:
        unique = set(lines)
        if len(unique) / len(lines) < 0.5:
            return False, "righe_duplicate"

    # Pattern junk
    clean_lines = [
        l for l in lines
        if not any(p.match(l) for p in JUNK_PATTERNS)
    ]
    if lines and len(clean_lines) < len(lines) * 0.5:
        return False, "junk_pdf"

    # Sembra un indice (tutte righe corte)
    if lines and all(len(l.split()) < 6 for l in lines) and len(lines) > 5:
        return False, "indice"

    return True, "ok"


# ════════════════════════════════════════════════════════════════
# 🧠 FILTRO QUALITÀ CON LLM
# ════════════════════════════════════════════════════════════════

def score_chunk_quality(text, llm_client, model):
    """
    Chiede al LLM locale se il chunk è utile come fonte
    per rispondere a domande. Ritorna {score, usable, reason}.
    """
    try:
        response = llm_client.chat.completions.create(
            model=model,
            messages=[{
                "role": "user",
                "content": f"""
Valuta questo testo estratto da documentazione.
Deve servire come fonte per rispondere a domande di utenti.

Rispondi SOLO con un JSON, nessun altro testo:
{{"score": <1-5>, "usable": <true/false>, "reason": "<breve>"}}

Criteri:
- 1: spazzatura (tabelle rotte, header, testo illeggibile)
- 2: frammento senza contesto sufficiente
- 3: informazione parziale ma comprensibile
- 4: buon contenuto, risponde a domande specifiche
- 5: contenuto completo e autosufficiente

usable = true solo se score >= 3

Testo:
---
{text[:1500]}
---"""
            }],
            temperature=0.1,
            max_tokens=150,
        )
        content = response.choices[0].message.content.strip()

        # Rimuovi markdown backticks se presenti
        if content.startswith("```"):
            content = content.split("\n", 1)[1].rsplit("```", 1)[0].strip()

        return json.loads(content)

    except Exception as e:
        logger.warning(f"  ⚠️ Errore LLM quality score: {e}")
        # In caso di errore, tienilo (meglio falso positivo)
        return {"score": 3, "usable": True, "reason": "errore_valutazione"}


# ════════════════════════════════════════════════════════════════
# 🤖 GENERAZIONE QUERY
# ════════════════════════════════════════════════════════════════

def generate_queries(text, source_info, llm_client, model, n_queries=3):
    """
    Genera query sintetiche realistiche per un chunk.
    Ritorna lista di stringhe.
    """
    try:
        response = llm_client.chat.completions.create(
            model=model,
            messages=[{
                "role": "user",
                "content": f"""
Dato questo testo da documentazione ({source_info}),
genera {n_queries} domande DIVERSE e REALISTICHE che un utente
potrebbe fare, e a cui questo testo risponderebbe bene.

Regole:
- Domande in italiano naturale
- Varia: alcune formali, alcune colloquiali
- Includi sinonimi e riformulazioni dei concetti chiave
- NO domande a cui il testo NON risponde
- Rispondi SOLO con un JSON array di stringhe, nient'altro

Testo:
---
{text[:2000]}
---"""
            }],
            temperature=0.8,
            max_tokens=500,
        )
        content = response.choices[0].message.content.strip()

        if content.startswith("```"):
            content = content.split("\n", 1)[1].rsplit("```", 1)[0].strip()

        queries = json.loads(content)
        # Filtra query vuote o troppo corte
        return [q.strip() for q in queries if q and len(q.strip()) > 10]

    except Exception as e:
        logger.warning(f"  ⚠️ Errore generazione query: {e}")
        return []


# ════════════════════════════════════════════════════════════════
# 🎯 HARD NEGATIVES
# ════════════════════════════════════════════════════════════════

def get_dense_embedding(text, embed_url):
    """Chiama il server BGE-M3 per ottenere embedding dense."""
    try:
        resp = requests.post(
            f"{embed_url}/v1/embeddings",
            json={
                "input": [text] if isinstance(text, str) else text,
                "return_dense": True,
                "return_sparse": False,
                "return_colbert": False,
            },
            timeout=30,
        )
        resp.raise_for_status()
        results = resp.json()["results"]
        return [r["embeddings"]["dense"] for r in results]

    except Exception as e:
        logger.warning(f"  ⚠️ Errore embedding: {e}")
        return None


def find_hard_negatives(query, positive_id, qdrant_client, collection, embed_url, top_k=7, vector_name=None):
    """
    Trova hard negatives: chunk che il retriever attuale
    restituisce come rilevanti ma che NON sono il positive.
    """
    embeddings = get_dense_embedding(query, embed_url)
    if not embeddings:
        return []

    try:
        query_kwargs = dict(
            collection_name=collection,
            query=embeddings[0],
            limit=top_k + 5,
            with_payload=True,
        )
        if vector_name:
            query_kwargs["using"] = vector_name

        results = qdrant_client.query_points(**query_kwargs)

        negatives = []
        for point in results.points:
            if str(point.id) != str(positive_id):
                text = point.payload.get("text", "")
                if text.strip() and len(text.strip()) > 50:
                    negatives.append(text.strip())
            if len(negatives) >= top_k:
                break

        return negatives

    except Exception as e:
        logger.warning(f"  ⚠️ Errore ricerca negatives: {e}")
        return []


# ════════════════════════════════════════════════════════════════
# 📥 SCROLL QDRANT
# ════════════════════════════════════════════════════════════════

def scroll_all_points(qdrant_client, collection, text_field, batch_size=100):
    """Scarica tutti i point dalla collection."""
    all_points = []
    offset = None

    while True:
        results, next_offset = qdrant_client.scroll(
            collection_name=collection,
            limit=batch_size,
            offset=offset,
            with_payload=True,
            with_vectors=False,
        )
        all_points.extend(results)

        if next_offset is None:
            break
        offset = next_offset

    return all_points


# ════════════════════════════════════════════════════════════════
# 💾 RESUME SUPPORT
# ════════════════════════════════════════════════════════════════

def load_existing_dataset(path):
    """Carica dataset parziale se esiste (per resume)."""
    if not os.path.exists(path):
        return [], set()

    dataset = []
    seen_queries = set()

    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                item = json.loads(line)
                dataset.append(item)
                seen_queries.add(item.get("query", ""))
            except json.JSONDecodeError:
                continue

    return dataset, seen_queries


# ════════════════════════════════════════════════════════════════
# 🚀 MAIN
# ════════════════════════════════════════════════════════════════

def run_generate(args):
    """Entry point chiamato da cli.py"""
    random.seed(args.seed)

    print("""
╔══════════════════════════════════════════════════════════════╗
║        📊  BGE-M3 Training Dataset Generator                ║
╚══════════════════════════════════════════════════════════════╝
    """)

    # ── Connessioni ──
    print("🔌 Connessione servizi...")

    qdrant = QdrantClient(url=args.qdrant_url)
    try:
        info = qdrant.get_collection(args.collection)
        print(f"  ✓ Qdrant: {args.qdrant_url} → {args.collection} ({info.points_count} points)")
    except Exception as e:
        print(f"  ✗ Errore Qdrant: {e}")
        sys.exit(1)

    llm = OpenAI(base_url=args.llm_url, api_key=args.llm_api_key)
    try:
        # Test rapido LLM
        test = llm.chat.completions.create(
            model=args.llm_model,
            messages=[{"role": "user", "content": "Rispondi solo: ok"}],
            max_tokens=10,
        )
        print(f"  ✓ LLM: {args.llm_url} → {args.llm_model}")
    except Exception as e:
        print(f"  ✗ Errore LLM: {e}")
        sys.exit(1)

    try:
        health = requests.get(f"{args.embed_url}/health", timeout=5)
        print(f"  ✓ Embeddings: {args.embed_url}")
    except Exception as e:
        print(f"  ✗ Errore embedding server: {e}")
        sys.exit(1)

    # ── Resume ──
    dataset = []
    seen_queries = set()
    if args.resume:
        dataset, seen_queries = load_existing_dataset(args.output)
        if dataset:
            print(f"\n🔄 Resume: {len(dataset)} coppie esistenti caricate")

    # ══════════════════════════════════════════════════════════
    # STEP 1: Scroll tutti i point
    # ══════════════════════════════════════════════════════════

    print(f"\n{'═' * 60}")
    print(f"  📥  Step 1: Scroll Qdrant")
    print(f"{'═' * 60}")

    all_points = scroll_all_points(qdrant, args.collection, args.text_field, args.scroll_batch)
    print(f"  ✓ Point scaricati: {len(all_points)}")

    if args.max_chunks:
        random.shuffle(all_points)
        all_points = all_points[:args.max_chunks]
        print(f"  ✓ Limitati a: {args.max_chunks} (--max-chunks)")

    # ══════════════════════════════════════════════════════════
    # STEP 2: Filtro deterministico
    # ══════════════════════════════════════════════════════════

    print(f"\n{'═' * 60}")
    print(f"  🧹  Step 2: Filtro deterministico")
    print(f"{'═' * 60}")

    passed_deterministic = []
    reject_reasons = {}

    for point in all_points:
        text = point.payload.get(args.text_field, "")
        ok, reason = is_chunk_usable(text, args)
        if ok:
            passed_deterministic.append(point)
        else:
            reject_reasons[reason] = reject_reasons.get(reason, 0) + 1

    print(f"  ✓ Passati: {len(passed_deterministic)} / {len(all_points)}")
    if reject_reasons:
        for reason, count in sorted(reject_reasons.items(), key=lambda x: -x[1]):
            print(f"    ✗ {reason}: {count}")

    # ══════════════════════════════════════════════════════════
    # STEP 3: Filtro qualità LLM
    # ══════════════════════════════════════════════════════════

    if args.skip_llm_filter:
        passed_quality = passed_deterministic
        print(f"\n  ⏭️  Filtro LLM skippato (--skip-llm-filter)")
    else:
        print(f"\n{'═' * 60}")
        print(f"  🧠  Step 3: Filtro qualità LLM")
        print(f"{'═' * 60}")

        passed_quality = []
        scores_dist = {1: 0, 2: 0, 3: 0, 4: 0, 5: 0}

        for i, point in enumerate(passed_deterministic):
            text = point.payload.get(args.text_field, "")
            print(f"\r  [{i + 1}/{len(passed_deterministic)}] Valutazione qualità...", end="", flush=True)

            result = score_chunk_quality(text, llm, args.llm_model)
            score = result.get("score", 3)
            scores_dist[min(5, max(1, score))] += 1

            if result.get("usable", False):
                passed_quality.append(point)

        print(f"\n  ✓ Passati: {len(passed_quality)} / {len(passed_deterministic)}")
        print(f"  Distribuzione score:")
        for s in range(1, 6):
            bar = "█" * min(50, scores_dist.get(s, 0))
            print(f"    {s}: {scores_dist.get(s, 0):>5} {bar}")

    # Shuffle per varietà
    random.shuffle(passed_quality)

    # ══════════════════════════════════════════════════════════
    # STEP 4: Generazione query + hard negatives
    # ══════════════════════════════════════════════════════════

    print(f"\n{'═' * 60}")
    print(f"  🤖  Step 4: Generazione query + hard negatives")
    print(f"{'═' * 60}")
    print(f"  Target: {args.min_pairs} coppie minime")

    start_time = time.time()
    errors = 0
    skipped = 0

    for i, point in enumerate(passed_quality):
        # Controlla se abbiamo abbastanza
        if len(dataset) >= args.min_pairs:
            print(f"\n  ✓ Target raggiunto: {len(dataset)} coppie")
            break

        text = point.payload.get(args.text_field, "")
        point_id = str(point.id)

        # Info sorgente per il prompt (se disponibile nel payload)
        source_info = point.payload.get("source", point.payload.get("filename", "documento"))

        elapsed = time.time() - start_time
        rate = len(dataset) / max(elapsed, 1) * 60  # coppie/minuto
        remaining = (args.min_pairs - len(dataset)) / max(rate, 0.1)

        print(
            f"\r  [{i + 1}/{len(passed_quality)}] "
            f"Coppie: {len(dataset)}/{args.min_pairs} "
            f"| {rate:.0f}/min "
            f"| ETA: {remaining:.0f}min  ",
            end="", flush=True,
        )

        # Genera query
        queries = generate_queries(
            text, source_info, llm, args.llm_model, args.queries_per_chunk
        )

        if not queries:
            errors += 1
            continue

        for query in queries:
            # Skip se già vista (resume)
            if query in seen_queries:
                skipped += 1
                continue

            # Hard negatives da Qdrant
            hard_negs = find_hard_negatives(
                query, point_id, qdrant, args.collection,
                args.embed_url, top_k=args.hard_negatives,
                vector_name=args.vector_name
            )

            dataset.append({
                "query": query,
                "pos": [text],
                "neg": hard_negs,
            })
            seen_queries.add(query)

        # Salvataggio incrementale ogni 100 coppie
        if len(dataset) % 100 < args.queries_per_chunk:
            _save_dataset(dataset, args.output)

    # ══════════════════════════════════════════════════════════
    # STEP 5: Salvataggio finale
    # ══════════════════════════════════════════════════════════

    _save_dataset(dataset, args.output)

    elapsed = time.time() - start_time
    with_neg = sum(1 for d in dataset if d["neg"])
    avg_neg = sum(len(d["neg"]) for d in dataset) / max(len(dataset), 1)

    print(f"\n\n{'═' * 60}")
    print(f"  ✅  Dataset completato!")
    print(f"{'═' * 60}")
    print(f"  📊 Coppie totali:        {len(dataset)}")
    print(f"     Con hard negatives:   {with_neg} ({100 * with_neg / max(len(dataset), 1):.0f}%)")
    print(f"     Media negatives:      {avg_neg:.1f}")
    print(f"     Errori LLM:           {errors}")
    print(f"     Skip (resume):        {skipped}")
    print(f"  ⏱️  Tempo:               {elapsed / 60:.1f} minuti")
    print(f"  💾 Output:               {args.output}")
    print(f"     Dimensione:           {os.path.getsize(args.output) / 1e6:.1f} MB")

    if len(dataset) < 500:
        print(f"\n  ⚠️ Dataset piccolo ({len(dataset)}). Consiglio almeno 1000 coppie.")
        print(f"     Prova: --min-pairs 3000 --queries-per-chunk 5")


def _save_dataset(dataset, path):
    """Salva dataset come JSONL (sovrascrive)."""
    with open(path, "w", encoding="utf-8") as f:
        for item in dataset:
            f.write(json.dumps(item, ensure_ascii=False) + "\n")


def main():
    args = parse_args()
    run_generate(args)


if __name__ == "__main__":
    main()
