"""BGE Auto-Tune: Fine-tune BAAI/bge-m3 per retrieval + reranking."""

__version__ = "0.1.5.7"
