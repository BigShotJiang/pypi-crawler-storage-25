"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  generate_dataset_docling.py                                               ║
║  Genera dataset di training per BGE-M3 da documenti locali via Docling     ║
║                                                                            ║
║  Workflow:                                                                 ║
║    1. Scan directory per documenti supportati                              ║
║    2. Invio a Docling serve /v1/chunk/hybrid/file → chunking semantico        ║
║    3. Filtro deterministico (lunghezza, ratio testo, duplicati)            ║
║    4. Filtro qualità con LLM locale (via OpenAI SDK → vLLM)               ║
║    5. Generazione query sintetiche con LLM                                 ║
║    6. Ricerca hard negatives in-memory (cosine similarity)                 ║
║    7. Salvataggio dataset JSONL per FlagEmbedding                          ║
║                                                                            ║
║  Uso:                                                                      ║
║    bge-auto-tune generate --docling --docs-dir ./my_docs                   ║
║    bge-auto-tune generate --docling --docs-dir ./my_docs --min-pairs 3000  ║
║                                                                            ║
║  Env vars:                                                                 ║
║    DOCLING_URL, LLM_URL, LLM_MODEL, EMBED_URL                             ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import os
import re
import sys
import json
import time
import random
import hashlib
import logging
from pathlib import Path
from dataclasses import dataclass, field
from typing import Any, Optional

import numpy as np
import requests
from openai import OpenAI

# ════════════════════════════════════════════════════════════════
# 📋 LOGGING
# ════════════════════════════════════════════════════════════════

logging.basicConfig(level=logging.INFO, format="%(message)s")
logger = logging.getLogger("dataset-gen-docling")

# ════════════════════════════════════════════════════════════════
# 📄 SUPPORTED FORMATS
# ════════════════════════════════════════════════════════════════

SUPPORTED_EXTENSIONS = {
    ".pdf", ".docx", ".pptx", ".html", ".htm",
    ".png", ".jpg", ".jpeg", ".tiff", ".bmp",
    ".md", ".csv", ".xlsx",
}

# ════════════════════════════════════════════════════════════════
# ⚙️ DOCLING DEFAULTS
# ════════════════════════════════════════════════════════════════

MAX_RETRIES = 3
RETRY_DELAY_SECONDS = 5.0

# ════════════════════════════════════════════════════════════════
# 🧹 FILTRI DETERMINISTICI
# ════════════════════════════════════════════════════════════════

JUNK_PATTERNS = [
    re.compile(r"^page\s+\d+\s+(of|di)\s+\d+$", re.I),
    re.compile(r"^pagina\s+\d+\s+di\s+\d+$", re.I),
    re.compile(r"^[-_=\s]{10,}$"),
    re.compile(r"^\.{5,}$"),
    re.compile(r"^tutti i diritti riservati", re.I),
    re.compile(r"^all rights reserved", re.I),
    re.compile(r"^copyright\s", re.I),
]


def is_chunk_usable(text: str, min_chunk_length: int, min_words: int,
                    min_alpha_ratio: float) -> tuple[bool, str]:
    """
    Filtri deterministici rapidi.
    Ritorna (True/False, motivo).
    """
    text = text.strip()

    if len(text) < min_chunk_length:
        return False, "troppo_corto"

    words = text.split()
    if len(words) < min_words:
        return False, "poche_parole"

    alpha_chars = sum(1 for c in text if c.isalpha())
    if len(text) > 0 and alpha_chars / len(text) < min_alpha_ratio:
        return False, "troppi_numeri_simboli"

    lines = [ln.strip() for ln in text.split("\n") if ln.strip()]
    if lines:
        unique = set(lines)
        if len(unique) / len(lines) < 0.5:
            return False, "righe_duplicate"

    clean_lines = [
        ln for ln in lines
        if not any(p.match(ln) for p in JUNK_PATTERNS)
    ]
    if lines and len(clean_lines) < len(lines) * 0.5:
        return False, "junk_pdf"

    if lines and all(len(ln.split()) < 6 for ln in lines) and len(lines) > 5:
        return False, "indice"

    return True, "ok"


# ════════════════════════════════════════════════════════════════
# 📂 DOCUMENT DISCOVERY
# ════════════════════════════════════════════════════════════════

def discover_documents(docs_dir: str) -> list[Path]:
    """Scansiona ricorsivamente la directory per documenti supportati."""
    docs_path = Path(docs_dir)
    if not docs_path.exists():
        logger.error(f"  ✗ Directory non trovata: {docs_dir}")
        sys.exit(1)
    if not docs_path.is_dir():
        logger.error(f"  ✗ Non è una directory: {docs_dir}")
        sys.exit(1)

    documents = []
    for filepath in sorted(docs_path.rglob("*")):
        if filepath.is_file() and filepath.suffix.lower() in SUPPORTED_EXTENSIONS:
            documents.append(filepath)

    return documents


# ════════════════════════════════════════════════════════════════
# 🔌 DOCLING CLIENT — Hybrid Chunking
# ════════════════════════════════════════════════════════════════

@dataclass
class Chunk:
    """Un chunk di testo con metadati sorgente."""
    text: str
    source: str
    chunk_index: int
    chunk_id: str = field(default="")

    def __post_init__(self):
        if not self.chunk_id:
            h = hashlib.md5(
                f"{self.source}:{self.chunk_index}:{self.text[:100]}".encode()
            ).hexdigest()[:12]
            self.chunk_id = h


def check_docling_health(docling_url: str) -> bool:
    """Verifica che il servizio Docling sia raggiungibile."""
    for endpoint in ["/health", "/docs", "/"]:
        try:
            r = requests.get(f"{docling_url}{endpoint}", timeout=10)
            if r.status_code == 200:
                return True
        except requests.ConnectionError:
            continue
    return False


def _build_chunking_params(args) -> dict[str, Any]:
    """
    Costruisce i parametri per l'endpoint /v1/chunk/hybrid/file.

    Riferimento: API spec docling-serve con prefisso "convert_" e "chunking_"
    """
    params: dict[str, Any] = {
        # Output
        "include_converted_doc": False,
        "target_type": "inbody",

        # Convert
        "convert_from_formats": ["docx", "pptx", "html", "image", "pdf", "md", "csv", "xlsx"],
        "convert_image_export_mode": "placeholder",
        "convert_do_ocr": getattr(args, "docling_ocr", False),
        "convert_force_ocr": False,
        "convert_ocr_engine": getattr(args, "docling_ocr_engine", "easyocr"),
        "convert_ocr_lang": json.loads(getattr(args, "docling_ocr_lang", '["it", "en"]')),
        "convert_pdf_backend": getattr(args, "docling_pdf_backend", "dlparse_v4"),
        "convert_table_mode": getattr(args, "docling_table_mode", "fast"),
        "convert_table_cell_matching": getattr(args, "docling_table_cell_matching", False),
        "convert_pipeline": "standard",
        "convert_page_range": [1, 10000],
        "convert_document_timeout": getattr(args, "docling_timeout", 3600),
        "convert_abort_on_error": False,
        "convert_do_table_structure": True,
        "convert_include_images": False,
        "convert_images_scale": 0.1,
        "convert_md_page_break_placeholder": "<!-- page-break -->",
        "convert_do_code_enrichment": False,
        "convert_do_formula_enrichment": False,
        "convert_do_picture_classification": False,
        "convert_do_picture_description": False,
        "convert_picture_description_area_threshold": 0.05,

        # Chunking
        "chunking_use_markdown_tables": True,
        "chunking_include_raw_text": False,
        "chunking_max_tokens": getattr(args, "chunking_max_tokens", 512),
        "chunking_tokenizer": getattr(args, "chunking_tokenizer", "BAAI/bge-m3"),
        "chunking_merge_peers": True,
    }

    return params


def chunk_document_docling(filepath: Path, docling_url: str,
                           chunking_params: dict[str, Any],
                           timeout: int = 600) -> list[Chunk]:
    """
    Invia un documento a Docling serve /v1/chunk/hybrid/file e ritorna i chunk.

    Include retry su 404 (bug noto Docling) e 5xx.
    """
    url = f"{docling_url}/v1/chunk/hybrid/file"
    source_name = filepath.name
    last_error: Exception | None = None

    for attempt in range(1, MAX_RETRIES + 1):
        try:
            with open(filepath, "rb") as f:
                files = {"files": (filepath.name, f, "application/octet-stream")}
                resp = requests.post(
                    url, files=files, data=chunking_params, timeout=timeout,
                )
                resp.raise_for_status()
                return _parse_chunk_response(resp.json(), source_name)

        except requests.exceptions.HTTPError as e:
            last_error = e
            status = e.response.status_code if e.response else 0

            if status == 404 or status >= 500:
                delay = RETRY_DELAY_SECONDS * attempt
                logger.warning(
                    f"  ⚠️ Docling retry {attempt}/{MAX_RETRIES} "
                    f"(status {status}) per {source_name}, "
                    f"riprovo in {delay:.0f}s..."
                )
                time.sleep(delay)
                continue

            # 400, 422 ecc. → non ritentare
            logger.warning(f"  ✗ Docling {status} per {source_name}: {e}")
            return []

        except requests.exceptions.RequestException as e:
            last_error = e
            delay = RETRY_DELAY_SECONDS * attempt
            logger.warning(
                f"  ⚠️ Docling retry {attempt}/{MAX_RETRIES} "
                f"per {source_name}: {e}, riprovo in {delay:.0f}s..."
            )
            time.sleep(delay)
            continue

    logger.warning(
        f"  ✗ Tutti i {MAX_RETRIES} tentativi falliti per {source_name}: {last_error}"
    )
    return []


def _parse_chunk_response(data: Any, source_name: str) -> list[Chunk]:
    """
    Parsa la risposta dell'endpoint /v1/chunk/hybrid/file di docling-serve.

    Il formato atteso è una lista di chunk, ognuno con un campo "text"
    o "content" (o "chunks" come wrapper).
    """
    chunks: list[Chunk] = []

    # Caso 1: risposta è una lista diretta di chunk
    raw_chunks: list[Any] = []

    if isinstance(data, list):
        raw_chunks = data
    elif isinstance(data, dict):
        # Caso 2: {"chunks": [...]} o {"results": [...]} o {"output": [...]}
        raw_chunks = (
            data.get("chunks")
            or data.get("results")
            or data.get("output")
            or data.get("data")
            or []
        )
        if not raw_chunks and "text" in data:
            raw_chunks = [data]

    for i, item in enumerate(raw_chunks):
        text = ""
        if isinstance(item, dict):
            text = (
                item.get("text")
                or item.get("content")
                or item.get("markdown")
                or item.get("body")
                or ""
            )
        elif isinstance(item, str):
            text = item

        text = text.strip()
        if text:
            chunks.append(Chunk(text=text, source=source_name, chunk_index=i))

    return chunks


# ════════════════════════════════════════════════════════════════
# 🧠 FILTRO QUALITÀ CON LLM
# ════════════════════════════════════════════════════════════════

def score_chunk_quality(text: str, llm_client: OpenAI, model: str) -> dict:
    """
    Chiede al LLM locale se il chunk è utile come fonte
    per rispondere a domande. Ritorna {score, usable, reason}.
    """
    try:
        response = llm_client.chat.completions.create(
            model=model,
            messages=[{
                "role": "user",
                "content": f"""
Valuta questo testo estratto da documentazione.
Deve servire come fonte per rispondere a domande di utenti.

Rispondi SOLO con un JSON, nessun altro testo:
{{"score": <1-5>, "usable": <true/false>, "reason": "<breve>"}}

Criteri:
- 1: spazzatura (tabelle rotte, header, testo illeggibile)
- 2: frammento senza contesto sufficiente
- 3: informazione parziale ma comprensibile
- 4: buon contenuto, risponde a domande specifiche
- 5: contenuto completo e autosufficiente

usable = true solo se score >= 3

Testo:
---
{text[:1500]}
---"""
            }],
            temperature=0.1,
            max_tokens=150,
        )
        content = response.choices[0].message.content.strip()

        if content.startswith("```"):
            content = content.split("\n", 1)[1].rsplit("```", 1)[0].strip()

        return json.loads(content)

    except Exception as e:
        logger.warning(f"  ⚠️ Errore LLM quality score: {e}")
        return {"score": 3, "usable": True, "reason": "errore_valutazione"}


# ════════════════════════════════════════════════════════════════
# 🤖 GENERAZIONE QUERY
# ════════════════════════════════════════════════════════════════

def generate_queries(text: str, source_info: str, llm_client: OpenAI,
                     model: str, n_queries: int = 3) -> list[str]:
    """Genera query sintetiche realistiche per un chunk."""
    try:
        response = llm_client.chat.completions.create(
            model=model,
            messages=[{
                "role": "user",
                "content": f"""
Dato questo testo da documentazione ({source_info}),
genera {n_queries} domande DIVERSE e REALISTICHE che un utente
potrebbe fare, e a cui questo testo risponderebbe bene.

Regole:
- Domande in italiano naturale
- Varia: alcune formali, alcune colloquiali
- Includi sinonimi e riformulazioni dei concetti chiave
- NO domande a cui il testo NON risponde
- Rispondi SOLO con un JSON array di stringhe, nient'altro

Testo:
---
{text[:2000]}
---"""
            }],
            temperature=0.8,
            max_tokens=500,
        )
        content = response.choices[0].message.content.strip()

        if content.startswith("```"):
            content = content.split("\n", 1)[1].rsplit("```", 1)[0].strip()

        queries = json.loads(content)
        return [q.strip() for q in queries if q and len(q.strip()) > 10]

    except Exception as e:
        logger.warning(f"  ⚠️ Errore generazione query: {e}")
        return []


# ════════════════════════════════════════════════════════════════
# 🔢 EMBEDDING
# ════════════════════════════════════════════════════════════════

def get_dense_embeddings(texts: list[str], embed_url: str,
                         batch_size: int = 32) -> Optional[list[list[float]]]:
    """Ottieni embedding dense dal server BGE-M3 (in batch)."""
    all_embeddings: list[list[float]] = []

    for i in range(0, len(texts), batch_size):
        batch = texts[i:i + batch_size]
        try:
            resp = requests.post(
                f"{embed_url}/v1/embeddings",
                json={
                    "input": batch,
                    "return_dense": True,
                    "return_sparse": False,
                    "return_colbert": False,
                },
                timeout=60,
            )
            resp.raise_for_status()
            results = resp.json()["results"]
            results.sort(key=lambda x: x["index"])
            all_embeddings.extend([r["embeddings"]["dense"] for r in results])
        except Exception as e:
            logger.warning(f"  ⚠️ Errore embedding batch {i}: {e}")
            return None

    return all_embeddings


# ════════════════════════════════════════════════════════════════
# 🎯 HARD NEGATIVES IN-MEMORY
# ════════════════════════════════════════════════════════════════

class InMemoryIndex:
    """Indice in-memory per hard negatives basato su cosine similarity."""

    def __init__(self, embeddings: list[list[float]], texts: list[str]):
        self.matrix = np.array(embeddings, dtype=np.float32)
        self.texts = texts
        norms = np.linalg.norm(self.matrix, axis=1, keepdims=True)
        norms[norms == 0] = 1.0
        self.matrix_norm = self.matrix / norms

    def search(self, query_embedding: list[float], exclude_idx: int,
               top_k: int = 7) -> list[str]:
        """Trova i top-k chunk più simili, escludendo il positive."""
        q = np.array(query_embedding, dtype=np.float32)
        q_norm = q / max(np.linalg.norm(q), 1e-10)
        scores = self.matrix_norm @ q_norm
        scores[exclude_idx] = -1.0
        top_indices = np.argsort(scores)[::-1][:top_k]
        return [self.texts[i] for i in top_indices if scores[i] > 0]


def find_hard_negatives_memory(query: str, positive_idx: int,
                               index: InMemoryIndex, embed_url: str,
                               top_k: int = 7) -> list[str]:
    """Trova hard negatives usando l'indice in-memory."""
    embeddings = get_dense_embeddings([query], embed_url)
    if not embeddings:
        return []
    return index.search(embeddings[0], positive_idx, top_k)


# ════════════════════════════════════════════════════════════════
# 💾 RESUME / SAVE
# ════════════════════════════════════════════════════════════════

def load_existing_dataset(path: str) -> tuple[list[dict], set[str]]:
    """Carica dataset parziale se esiste (per resume)."""
    if not os.path.exists(path):
        return [], set()

    dataset: list[dict] = []
    seen_queries: set[str] = set()

    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                item = json.loads(line)
                dataset.append(item)
                seen_queries.add(item.get("query", ""))
            except json.JSONDecodeError:
                continue

    return dataset, seen_queries


def save_dataset(dataset: list[dict], path: str) -> None:
    """Salva dataset come JSONL (sovrascrive)."""
    with open(path, "w", encoding="utf-8") as f:
        for item in dataset:
            f.write(json.dumps(item, ensure_ascii=False) + "\n")


# ════════════════════════════════════════════════════════════════
# 🚀 MAIN
# ════════════════════════════════════════════════════════════════

def run_generate_docling(args) -> None:
    """Entry point per generazione dataset da documenti via Docling."""
    random.seed(args.seed)

    print("""
╔══════════════════════════════════════════════════════════════╗
║        📊  BGE-M3 Training Dataset Generator                ║
║        📄  Modalità Docling (chunking semantico)            ║
╚══════════════════════════════════════════════════════════════╝
    """)

    docling_url = args.docling_url
    docs_dir = args.docs_dir

    # ── Connessioni ──
    print("🔌 Connessione servizi...")

    if not check_docling_health(docling_url):
        print(f"  ✗ Docling non raggiungibile: {docling_url}")
        print(f"    Avvia docling-serve con:")
        print(f"      pip install docling-serve && docling-serve run")
        print(f"      oppure: docker run -p 5001:5001 quay.io/docling-project/docling-serve")
        sys.exit(1)
    print(f"  ✓ Docling: {docling_url}")

    llm = OpenAI(base_url=args.llm_url, api_key=args.llm_api_key)
    try:
        llm.chat.completions.create(
            model=args.llm_model,
            messages=[{"role": "user", "content": "Rispondi solo: ok"}],
            max_tokens=10,
        )
        print(f"  ✓ LLM: {args.llm_url} → {args.llm_model}")
    except Exception as e:
        print(f"  ✗ Errore LLM: {e}")
        sys.exit(1)

    try:
        requests.get(f"{args.embed_url}/health", timeout=5)
        print(f"  ✓ Embeddings: {args.embed_url}")
    except Exception as e:
        print(f"  ✗ Errore embedding server: {e}")
        sys.exit(1)

    # ── Resume ──
    dataset: list[dict] = []
    seen_queries: set[str] = set()
    if args.resume:
        dataset, seen_queries = load_existing_dataset(args.output)
        if dataset:
            print(f"\n🔄 Resume: {len(dataset)} coppie esistenti caricate")

    # ══════════════════════════════════════════════════════════
    # STEP 1: Scopri documenti
    # ══════════════════════════════════════════════════════════

    print(f"\n{'═' * 60}")
    print(f"  📂  Step 1: Scan documenti")
    print(f"{'═' * 60}")

    documents = discover_documents(docs_dir)
    print(f"  ✓ Trovati: {len(documents)} documenti in {docs_dir}")

    if not documents:
        print(f"  ✗ Nessun documento supportato trovato.")
        print(f"    Formati: {', '.join(sorted(SUPPORTED_EXTENSIONS))}")
        sys.exit(1)

    for doc in documents[:10]:
        print(f"    📄 {doc.relative_to(docs_dir)}")
    if len(documents) > 10:
        print(f"    ... e altri {len(documents) - 10}")

    # ══════════════════════════════════════════════════════════
    # STEP 2: Chunking semantico via Docling
    # ══════════════════════════════════════════════════════════

    print(f"\n{'═' * 60}")
    print(f"  🔄  Step 2: Chunking semantico via Docling")
    print(f"{'═' * 60}")

    chunking_params = _build_chunking_params(args)
    docling_timeout = getattr(args, "docling_timeout", 300)

    all_chunks: list[Chunk] = []
    parsed_ok = 0
    parsed_fail = 0

    for i, doc_path in enumerate(documents):
        rel_name = str(doc_path.relative_to(docs_dir))
        print(f"\r  [{i + 1}/{len(documents)}] {rel_name[:50]:<50}", end="", flush=True)

        doc_chunks = chunk_document_docling(
            doc_path, docling_url, chunking_params, timeout=docling_timeout,
        )

        if doc_chunks:
            parsed_ok += 1
            all_chunks.extend(doc_chunks)
        else:
            parsed_fail += 1

    print(f"\n  ✓ Documenti parsati: {parsed_ok} / {len(documents)}")
    if parsed_fail:
        print(f"    ✗ Falliti: {parsed_fail}")
    print(f"  ✓ Chunk totali: {len(all_chunks)}")

    if not all_chunks:
        print(f"  ✗ Nessun chunk generato. Controlla i documenti e Docling.")
        sys.exit(1)

    if args.max_chunks and len(all_chunks) > args.max_chunks:
        random.shuffle(all_chunks)
        all_chunks = all_chunks[:args.max_chunks]
        print(f"  ✓ Limitati a: {args.max_chunks} (--max-chunks)")

    # ══════════════════════════════════════════════════════════
    # STEP 3: Filtro deterministico
    # ══════════════════════════════════════════════════════════

    print(f"\n{'═' * 60}")
    print(f"  🧹  Step 3: Filtro deterministico")
    print(f"{'═' * 60}")

    passed_deterministic: list[Chunk] = []
    reject_reasons: dict[str, int] = {}

    for chunk in all_chunks:
        ok, reason = is_chunk_usable(
            chunk.text, args.min_chunk_length, args.min_words, args.min_alpha_ratio,
        )
        if ok:
            passed_deterministic.append(chunk)
        else:
            reject_reasons[reason] = reject_reasons.get(reason, 0) + 1

    print(f"  ✓ Passati: {len(passed_deterministic)} / {len(all_chunks)}")
    if reject_reasons:
        for reason, count in sorted(reject_reasons.items(), key=lambda x: -x[1]):
            print(f"    ✗ {reason}: {count}")

    # ══════════════════════════════════════════════════════════
    # STEP 4: Filtro qualità LLM
    # ══════════════════════════════════════════════════════════

    if args.skip_llm_filter:
        passed_quality = passed_deterministic
        print(f"\n  ⏭️  Filtro LLM skippato (--skip-llm-filter)")
    else:
        print(f"\n{'═' * 60}")
        print(f"  🧠  Step 4: Filtro qualità LLM")
        print(f"{'═' * 60}")

        passed_quality: list[Chunk] = []
        scores_dist = {1: 0, 2: 0, 3: 0, 4: 0, 5: 0}

        for i, chunk in enumerate(passed_deterministic):
            print(f"\r  [{i + 1}/{len(passed_deterministic)}] Valutazione qualità...",
                  end="", flush=True)

            result = score_chunk_quality(chunk.text, llm, args.llm_model)
            score = result.get("score", 3)
            scores_dist[min(5, max(1, score))] += 1

            if result.get("usable", False):
                passed_quality.append(chunk)

        print(f"\n  ✓ Passati: {len(passed_quality)} / {len(passed_deterministic)}")
        print(f"  Distribuzione score:")
        for s in range(1, 6):
            bar = "█" * min(50, scores_dist.get(s, 0))
            print(f"    {s}: {scores_dist.get(s, 0):>5} {bar}")

    random.shuffle(passed_quality)

    # ══════════════════════════════════════════════════════════
    # STEP 5: Embedding chunk + indice in-memory
    # ══════════════════════════════════════════════════════════

    print(f"\n{'═' * 60}")
    print(f"  🔢  Step 5: Embedding chunk per hard negatives")
    print(f"{'═' * 60}")

    chunk_texts = [c.text for c in passed_quality]
    print(f"  Embedding {len(chunk_texts)} chunk...")

    embed_batch_size = getattr(args, "embed_batch", 32)
    all_embeddings = get_dense_embeddings(chunk_texts, args.embed_url, embed_batch_size)

    if not all_embeddings or len(all_embeddings) != len(chunk_texts):
        print(f"  ✗ Errore embedding chunk. Impossibile costruire indice hard negatives.")
        print(f"    Ottenuti: {len(all_embeddings) if all_embeddings else 0} / {len(chunk_texts)}")
        sys.exit(1)

    index = InMemoryIndex(all_embeddings, chunk_texts)
    print(f"  ✓ Indice in-memory costruito: {len(chunk_texts)} vettori")

    # ══════════════════════════════════════════════════════════
    # STEP 6: Generazione query + hard negatives
    # ══════════════════════════════════════════════════════════

    print(f"\n{'═' * 60}")
    print(f"  🤖  Step 6: Generazione query + hard negatives")
    print(f"{'═' * 60}")
    print(f"  Target: {args.min_pairs} coppie minime")

    start_time = time.time()
    errors = 0
    skipped = 0

    for i, chunk in enumerate(passed_quality):
        if len(dataset) >= args.min_pairs:
            print(f"\n  ✓ Target raggiunto: {len(dataset)} coppie")
            break

        text = chunk.text
        source_info = chunk.source

        elapsed = time.time() - start_time
        rate = len(dataset) / max(elapsed, 1) * 60
        remaining = (args.min_pairs - len(dataset)) / max(rate, 0.1)

        print(
            f"\r  [{i + 1}/{len(passed_quality)}] "
            f"Coppie: {len(dataset)}/{args.min_pairs} "
            f"| {rate:.0f}/min "
            f"| ETA: {remaining:.0f}min  ",
            end="", flush=True,
        )

        queries = generate_queries(
            text, source_info, llm, args.llm_model, args.queries_per_chunk,
        )

        if not queries:
            errors += 1
            continue

        for query in queries:
            if query in seen_queries:
                skipped += 1
                continue

            hard_negs = find_hard_negatives_memory(
                query, i, index, args.embed_url, top_k=args.hard_negatives,
            )

            dataset.append({
                "query": query,
                "pos": [text],
                "neg": hard_negs,
            })
            seen_queries.add(query)

        # Salvataggio incrementale ogni 100 coppie
        if len(dataset) % 100 < args.queries_per_chunk:
            save_dataset(dataset, args.output)

    # ══════════════════════════════════════════════════════════
    # STEP 7: Salvataggio finale
    # ══════════════════════════════════════════════════════════

    save_dataset(dataset, args.output)

    elapsed = time.time() - start_time
    with_neg = sum(1 for d in dataset if d["neg"])
    avg_neg = sum(len(d["neg"]) for d in dataset) / max(len(dataset), 1)

    print(f"\n\n{'═' * 60}")
    print(f"  ✅  Dataset completato!")
    print(f"{'═' * 60}")
    print(f"  📊 Coppie totali:        {len(dataset)}")
    print(f"     Con hard negatives:   {with_neg} ({100 * with_neg / max(len(dataset), 1):.0f}%)")
    print(f"     Media negatives:      {avg_neg:.1f}")
    print(f"     Errori LLM:           {errors}")
    print(f"     Skip (resume):        {skipped}")
    print(f"  ⏱️  Tempo:               {elapsed / 60:.1f} minuti")
    print(f"  💾 Output:               {args.output}")
    print(f"     Dimensione:           {os.path.getsize(args.output) / 1e6:.1f} MB")

    if len(dataset) < 500:
        print(f"\n  ⚠️ Dataset piccolo ({len(dataset)}). Consiglio almeno 1000 coppie.")
        print(f"     Prova: --min-pairs 3000 --queries-per-chunk 5")
        print(f"     Oppure aggiungi più documenti in {docs_dir}")