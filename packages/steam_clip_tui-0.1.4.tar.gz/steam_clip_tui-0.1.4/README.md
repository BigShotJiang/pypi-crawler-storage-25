# Steam Clip TUI

A terminal application for browsing and exporting Steam game recording clips, built with [Textual](https://textual.textualize.io/).

## Features

- **Browse clips** — automatically scans your Steam userdata directory, organizes clips by game
- **Preview** — inline thumbnail preview in terminals that support image protocols (kitty, ghostty, foot, wezterm)
- **Export to MP4** — join DASH segments into a single MP4 via ffmpeg, with real-time progress tracking
- **Customizable output** — choose video codec (copy/H.264/H.265/VideoToolbox), resolution (source/1080p/720p/480p), bitrate, and filename template
- **Game name resolution** — resolves Steam app IDs to human-readable names via appmanifest files and the Steam Store API, with a local disk cache

## Requirements

- Python 3.11+
- ffmpeg (must be on `PATH`)
- Steam with game recording enabled (clips stored in `userdata/`)

## Installation

```bash
# Run directly without installing (recommended)
uvx steam-clip-tui

# Or install globally with uv
uv tool install steam-clip-tui

# Or install with pipx
pipx install steam-clip-tui

# Or install with pip
pip install steam-clip-tui
```

## Usage

```bash
steam-clip-tui
```

### Keyboard shortcuts

| Key | Action |
|-----|--------|
| `h` / `l` | Switch focus left / right |
| `j` / `k` | Move cursor down / up |
| `g` | Focus game list |
| `e` | Export selected clip |
| `/` | Search games / Filter clips by date |
| `?` | Show help |
| `q` | Quit |

## Configuration

On first run, a config file is created at your platform's config directory (e.g. `~/.config/steam-clip-tui/config.toml` on Linux, `~/Library/Application Support/steam-clip-tui/config.toml` on macOS). See `config.default.toml` for all available options.

Key settings:

```toml
[export]
output_dir = "~/Movies/SteamClips"
video_codec = "copy"        # copy | libx264 | libx265 | h264_videotoolbox | hevc_videotoolbox
resolution = "source"       # source | 1080p | 720p | 480p
filename_template = "{game}/{date}_{time}.{ext}"

[ui]
enable_images = true
```
