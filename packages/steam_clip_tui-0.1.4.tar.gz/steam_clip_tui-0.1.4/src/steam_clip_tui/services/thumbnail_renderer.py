"""Thumbnail renderer — capability detection and path resolution."""

from __future__ import annotations

import functools
import os
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pathlib import Path

    from steam_clip_tui.models.clip import Clip


@functools.lru_cache(maxsize=1)
def terminal_supports_images() -> bool:
    """Check if terminal supports kitty or sixel graphics protocol."""
    term = os.environ.get("TERM", "")
    if "kitty" in term:
        return True
    if os.environ.get("KITTY_WINDOW_ID"):
        return True
    # Check for sixel support
    term_program = os.environ.get("TERM_PROGRAM", "")
    if term_program in ("iTerm.app", "WezTerm"):
        return True
    # foot terminal support
    return "foot" in term


class ThumbnailRenderer:
    """Handles thumbnail rendering and terminal capability detection."""

    def __init__(self, enable_images: bool = True):
        """Initialize with image display preference."""
        self._enable = enable_images

    @property
    def can_display(self) -> bool:
        """Whether the current terminal can display images."""
        if not self._enable:
            return False
        return terminal_supports_images()

    def get_image_path(self, clip: Clip) -> Path | None:
        """Return the thumbnail image path for a clip, or None."""
        return clip.thumbnail_path
