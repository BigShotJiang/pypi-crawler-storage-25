"""Textual App entry point for Steam Clip TUI."""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import TYPE_CHECKING, ClassVar

# Force early import of textual_image.renderable BEFORE Textual takes over the
# terminal. The protocol detection (kitty/Sixel/TGP) queries the terminal at
# import time and requires a clean terminal state. textual_image.__init__ is
# empty — we must import the renderable module explicitly.
import textual_image.renderable  # noqa: F401
from textual import on
from textual.app import App
from textual.binding import Binding
from textual.containers import Container, Horizontal
from textual.widgets import Button, Footer, Header, Input, Label, Static

from steam_clip_tui.config import Config
from steam_clip_tui.services.exporter import ClipExporter
from steam_clip_tui.services.game_resolver import GameNameResolver
from steam_clip_tui.services.scanner import SteamClipScanner
from steam_clip_tui.services.thumbnail_renderer import terminal_supports_images
from steam_clip_tui.ui.screens.help_screen import HelpScreen
from steam_clip_tui.ui.screens.progress_screen import ProgressScreen
from steam_clip_tui.ui.widgets.clip_grid import ClipGrid, ClipSelected
from steam_clip_tui.ui.widgets.export_dialog import ExportDialog
from steam_clip_tui.ui.widgets.game_list import GameList, GameSelected
from steam_clip_tui.ui.widgets.preview_pane import PreviewPane

if TYPE_CHECKING:
    from textual import events
    from textual.app import ComposeResult

    from steam_clip_tui.models.clip import Clip
    from steam_clip_tui.models.export_settings import ExportSettings
    from steam_clip_tui.models.game import Game


# Per-pane search configuration: (search_input_id, list_widget_id, list_class, filter_method)
_SEARCH_GAME = ("#game-search", "#game-list", GameList, "filter_by_name")
_SEARCH_CLIP = ("#clip-search", "#clip-grid", ClipGrid, "filter_by_date")


class SteamClipApp(App[None]):
    """Main Textual application for browsing and exporting Steam game clips."""

    CSS_PATH: ClassVar[Path] = Path(__file__).parent / "ui/css/app.tcss"

    BINDINGS: ClassVar[list] = [
        Binding("q", "quit", "Quit"),
        Binding("e", "export_clip", "Export"),
        Binding("/", "search", "Search"),
        Binding("?", "help", "Help"),
        Binding("h", "focus_left", "Left", show=False),
        Binding("j", "cursor_down", "Down", show=False),
        Binding("k", "cursor_up", "Up", show=False),
        Binding("l", "focus_right", "Right", show=False),
        Binding("g", "focus_game_list", "Game List", show=False),
    ]

    def __init__(self):
        """Initialize the application with default configuration."""
        super().__init__()
        self.config = Config()
        self._games: list[Game] = []
        self._selected_clip: Clip | None = None
        self._current_game_name: str = ""
        self._last_header_text: str = ""

    def _icon_width(self) -> int:
        """Return the icon width for game list items, or 0 if disabled."""
        if self.config.show_game_icons and terminal_supports_images():
            return 2
        return 0

    def compose(self) -> ComposeResult:
        """Compose the UI layout with game list, clip grid, and preview pane."""
        yield Header()
        with Horizontal(id="main-layout"):
            with Container(id="game-list-container"):
                yield Input(placeholder="Search games…", id="game-search", classes="search-input")
                yield GameList(id="game-list", icon_width=self._icon_width())
            with Container(id="clip-area"):
                yield Static("Select a game", id="clip-grid-header")
                yield Input(
                    placeholder="Date range (e.g. 2024 or 2024-01..2024-06)",
                    id="clip-search",
                    classes="search-input",
                )
                yield ClipGrid(id="clip-grid")
                yield Label("No clips found.\n\nPress 'g' to focus game list.", id="no-clips-msg")
            yield PreviewPane(id="preview")
        yield Footer()

    async def on_mount(self) -> None:
        """Initialize the UI and start scanning the Steam library."""
        self.query_one("#no-clips-msg", Label).display = True
        self.query_one("#clip-grid", ClipGrid).display = False

        if not self._ffmpeg_available():
            self.notify(
                "ffmpeg not found. Export will not work.\nInstall with: brew install ffmpeg",
                title="Missing dependency",
                severity="warning",
                timeout=10,
            )

        self.run_worker(self._scan_library(), exclusive=True)

    @staticmethod
    def _ffmpeg_available() -> bool:
        import shutil

        return shutil.which("ffmpeg") is not None

    async def _scan_library(self) -> None:
        header = self.query_one("#clip-grid-header", Static)
        header.update("Scanning Steam clips...")

        scanner = SteamClipScanner(userdata_path=self.config.steam_userdata_path)
        self._games = await scanner.scan()

        resolver = GameNameResolver(
            libraryfolders_path=self.config.steam_libraryfolders_path,
            cache_path=self.config.appnames_cache_path(),
        )
        try:
            for game in self._games:
                game.name = await resolver.resolve(game.app_id)
            if self.config.show_game_icons and terminal_supports_images():
                icons = resolver.resolve_icons([g.app_id for g in self._games])
                for game, icon in zip(self._games, icons, strict=False):
                    game.icon_path = icon
        finally:
            await resolver.close()

        game_list = self.query_one("#game-list", GameList)
        await game_list.set_games(self._games)

        if self._games:
            header.update("Clips")
            game_list.focus()
            first_game = self._games[0]
            await self._show_clips_for_game(first_game)
        else:
            header.update("No Steam clips found")

    @on(GameSelected)
    async def on_game_selected(self, event: GameSelected) -> None:
        """Handle game selection from the game list."""
        await self._show_clips_for_game(event.game)

    @on(Button.Pressed, "#export-button")
    def on_export_button_pressed(self) -> None:
        """Handle export button click."""
        self.action_export_clip()

    async def _show_clips_for_game(self, game: Game) -> None:
        clip_search = self.query_one("#clip-search", Input)
        if clip_search.display:
            clip_search.display = False
            clip_search.value = ""

        self._current_game_name = game.name
        header = self.query_one("#clip-grid-header", Static)
        header.update(f"{game.name} — {game.clip_count} clips")
        self._last_header_text = ""

        grid = self.query_one("#clip-grid", ClipGrid)
        no_clips = self.query_one("#no-clips-msg", Label)

        if game.clips:
            grid.display = True
            no_clips.display = False
            await grid.set_clips(game.clips)
            grid.index = 0
        else:
            grid.display = False
            no_clips.display = True
            no_clips.update(f"No clips for {game.name}")

    @on(ClipSelected)
    def on_clip_selected(self, event: ClipSelected) -> None:
        """Handle clip selection and update the preview pane."""
        self._selected_clip = event.clip
        preview = self.query_one("#preview", PreviewPane)
        preview.show_clip(event.clip, self.config)

    def action_export_clip(self) -> None:
        """Export the currently selected clip."""
        if self._selected_clip is None or not self._selected_clip.has_video:
            return
        self.push_screen(ExportDialog(self.config, self._selected_clip), self._on_export)

    async def _on_export(self, settings: ExportSettings | None) -> None:
        if settings is None or self._selected_clip is None:
            return
        clip = self._selected_clip

        progress_screen = ProgressScreen()
        self.push_screen(progress_screen)

        exporter = ClipExporter()
        try:
            output_path = await exporter.export(
                clip,
                settings,
                progress_callback=progress_screen.update_progress,
            )
            self.notify(f"Exported to {output_path}", title="Export complete", timeout=5)
        except Exception as exc:
            self.notify(str(exc), title="Export failed", severity="error", timeout=5)
            progress_screen.signal_error()
        finally:
            await progress_screen.dismiss_on_complete()

    def action_cursor_down(self) -> None:
        """Move cursor down in the focused list."""
        focused = self.screen.focused
        if focused and hasattr(focused, "action_cursor_down"):
            focused.action_cursor_down()

    def action_cursor_up(self) -> None:
        """Move cursor up in the focused list."""
        focused = self.screen.focused
        if focused and hasattr(focused, "action_cursor_up"):
            focused.action_cursor_up()

    def action_focus_left(self) -> None:
        """Focus the pane to the left."""
        panes = [
            self.query_one("#game-list", GameList),
            self.query_one("#clip-grid", ClipGrid),
            self.query_one("#export-button", Button),
        ]
        focused = self.screen.focused
        for i, pane in enumerate(panes):
            if pane is focused or (focused is not None and focused in pane.query("*")):
                if i > 0:
                    panes[i - 1].focus()
                return

    def action_focus_right(self) -> None:
        """Focus the pane to the right."""
        panes = [
            self.query_one("#game-list", GameList),
            self.query_one("#clip-grid", ClipGrid),
            self.query_one("#export-button", Button),
        ]
        focused = self.screen.focused
        for i, pane in enumerate(panes):
            if pane is focused or (focused is not None and focused in pane.query("*")):
                if i < len(panes) - 1:
                    panes[i + 1].focus()
                return

    # ── search ──────────────────────────────────────────────────────────

    def action_search(self) -> None:
        """Toggle the search bar for the focused pane."""
        focused = self.screen.focused
        game_search = self.query_one("#game-search", Input)
        clip_search = self.query_one("#clip-search", Input)

        if focused is game_search:
            self._schedule_dismiss_search(*_SEARCH_GAME)
            return
        if focused is clip_search:
            self._schedule_dismiss_search(*_SEARCH_CLIP)
            return

        game_list = self.query_one("#game-list", GameList)
        clip_grid = self.query_one("#clip-grid", ClipGrid)

        if focused is game_list or (focused is not None and focused in game_list.query("*")):
            self._open_search(*_SEARCH_GAME)
        elif focused is clip_grid or (focused is not None and focused in clip_grid.query("*")):
            self._open_search(*_SEARCH_CLIP)

    def _open_search(self, search_id: str, _list_id: str, _list_class: type, _method: str) -> None:
        search = self.query_one(search_id, Input)
        search.display = True
        search.value = ""
        search.focus()

    async def _dismiss_search(
        self, search_id: str, list_id: str, list_class: type, filter_method: str
    ) -> None:
        search = self.query_one(search_id, Input)
        search.display = False
        search.value = ""
        list_widget = self.query_one(list_id, list_class)
        await getattr(list_widget, filter_method)("")
        list_widget.focus()

    def _schedule_dismiss_search(
        self, search_id: str, list_id: str, list_class: type, filter_method: str
    ) -> None:
        asyncio.get_running_loop().create_task(
            self._dismiss_search(search_id, list_id, list_class, filter_method)
        )

    async def _dismiss_clip_search_with_header(self) -> None:
        await self._dismiss_search(*_SEARCH_CLIP)
        self._update_clip_header()

    def _schedule_dismiss_clip_search_with_header(self) -> None:
        asyncio.get_running_loop().create_task(self._dismiss_clip_search_with_header())

    @on(Input.Changed, "#game-search")
    async def on_game_search_changed(self, event: Input.Changed) -> None:
        """Filter the game list as the user types in the search input."""
        game_list = self.query_one("#game-list", GameList)
        await game_list.filter_by_name(event.value)

    @on(Input.Changed, "#clip-search")
    async def on_clip_search_changed(self, event: Input.Changed) -> None:
        """Filter the clip grid as the user types in the date search input."""
        clip_grid = self.query_one("#clip-grid", ClipGrid)
        await clip_grid.filter_by_date(event.value)
        self._update_clip_header()

    @on(Input.Submitted, "#game-search")
    def on_game_search_submitted(self) -> None:
        """Dismiss the game search input on Enter, keeping the current filter."""
        self.query_one("#game-search", Input).display = False
        self.query_one("#game-list", GameList).focus()

    @on(Input.Submitted, "#clip-search")
    def on_clip_search_submitted(self) -> None:
        """Dismiss the clip search input on Enter, keeping the current filter."""
        self.query_one("#clip-search", Input).display = False
        self.query_one("#clip-grid", ClipGrid).focus()

    def _update_clip_header(self) -> None:
        """Update the clip grid header to reflect active filter count."""
        grid = self.query_one("#clip-grid", ClipGrid)
        if grid.is_filtered:
            new_text = f"{self._current_game_name} — {grid.filtered_count}/{grid.total_count} clips"
        else:
            new_text = f"{self._current_game_name} — {grid.total_count} clips"
        if new_text == self._last_header_text:
            return
        self._last_header_text = new_text
        self.query_one("#clip-grid-header", Static).update(new_text)

    def on_key(self, event: events.Key) -> None:
        """Handle global key events."""
        if event.key == "escape":
            focused = self.screen.focused
            if focused is self.query_one("#game-search", Input):
                event.stop()
                self._schedule_dismiss_search(*_SEARCH_GAME)
            elif focused is self.query_one("#clip-search", Input):
                event.stop()
                self._schedule_dismiss_clip_search_with_header()

    def action_focus_game_list(self) -> None:
        """Focus the game list sidebar."""
        self.query_one("#game-list", GameList).focus()

    def action_help(self) -> None:
        """Show the help screen with keyboard shortcuts."""
        self.push_screen(HelpScreen())


def main():
    """Entry point for the Steam Clip TUI application."""
    app = SteamClipApp()
    app.run()
