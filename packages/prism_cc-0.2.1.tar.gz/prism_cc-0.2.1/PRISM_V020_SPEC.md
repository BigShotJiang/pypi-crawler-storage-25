# PRISM v0.2.0 — Build Specification
> Hand this to Claude Code and say: "Build the v0.2.0 upgrades exactly as specified. 
> Do not break any existing functionality. Run pytest after every major step."

---

## Overview of What's Changing

Four additions. Nothing existing gets removed or broken.

1. **HTML Dashboard** — single self-contained file, auto-generated, opens in browser
2. **Claude Code /plugin install** — adds marketplace install alongside pip
3. **Attention Curve Scorer** — new advisor recommendation based on CLAUDE.md rule position
4. **README + GitHub improvements** — splash image, Trust & Safety FAQ, better badges

Current version: 0.1.2 → bump to 0.2.0

---

## 1. HTML Dashboard

### What it does
Generates a single self-contained HTML file at:
```
~/.claude/prism/dashboard.html
```

The file embeds all data inline — no live server required. User opens it as a 
`file://` URL or runs `prism dashboard --serve` for localhost.

Auto-regenerates every time `prism analyze` is run.

### New CLI command

```bash
prism dashboard              # Generate dashboard.html and open in browser
prism dashboard --serve      # Serve on localhost:19821, open in browser  
prism dashboard --no-open    # Generate only, don't open browser
```

Add to `prism/cli.py` as a new Typer command `dashboard_cmd`.

### HTML file generation

New file: `prism/dashboard.py`

```python
# prism/dashboard.py
# Generates self-contained HTML dashboard from analysis results
# Called by: cli.py dashboard_cmd, and at end of analyze_cmd

def generate_dashboard(reports: list[ProjectHealthReport], output_path: Path) -> Path:
    """Generate self-contained HTML dashboard. Returns path to file."""
    ...

def serve_dashboard(html_path: Path, port: int = 19821) -> None:
    """Serve dashboard on localhost using http.server."""
    ...
```

### Dashboard HTML structure

Single HTML file. Dark theme matching GitHub Dark palette already used in prism.tcss.
Self-contained — all CSS and JS inline, no external dependencies.

**Sections in order:**

**Header bar:**
- PRISM logo/wordmark (text, styled)
- "Last updated: {timestamp}"
- Overall fleet health: average grade across all projects

**Project Health Grid:**
- One card per project
- Card shows: project name, overall grade (large, color-coded), 5 dimension scores in a mini-grid
- Click card to expand to full detail view

**Full Detail View (expandable per project):**
- 5 health dimension cards with scores and descriptions
- Top issues list (same as CLI output)
- Advisor recommendations panel (all recommendations for this project)

**Fleet Summary (bottom):**
- Total sessions analyzed
- Total projects
- Projects by grade distribution (simple bar chart using CSS only, no Chart.js)
- Most common issues across all projects

**Design requirements:**
- Background: #0d1117
- Cards: #161b22 with border #30363d  
- Grade colors: A=green #3fb950, B=blue #58a6ff, C=yellow #d29922, D/F=red #f85149
- Font: system monospace stack for code, system sans for prose
- NO external fonts, NO CDN dependencies — must work offline
- Responsive — readable on any screen width
- All data embedded as a JSON blob in a `<script>` tag, rendered by inline JS

**Data shape embedded in HTML:**
```json
{
  "generated_at": "2026-04-13T19:00:00Z",
  "prism_version": "0.2.0",
  "projects": [
    {
      "name": "myapp",
      "display_name": "D//myapp",
      "overall_grade": "B+",
      "overall_score": 76,
      "dimensions": {
        "token_efficiency": {"grade": "C+", "score": 58, "issues": [...]},
        "tool_health": {"grade": "A-", "score": 88, "issues": [...]},
        "context_hygiene": {"grade": "B", "score": 72, "issues": [...]},
        "md_adherence": {"grade": "D+", "score": 42, "issues": [...]},
        "continuity": {"grade": "A+", "score": 96, "issues": [...]}
      },
      "top_issues": ["...", "..."],
      "advisor_recommendations": [
        {"action": "ADD", "impact": "High", "content": "...", "rationale": "..."}
      ],
      "session_count": 8,
      "last_active": "2026-04-13T18:00:00Z"
    }
  ]
}
```

### Integration with existing analyze command

In `cli.py`, after `analyze_cmd` prints the Rich table, add:
```python
# Auto-generate dashboard
dashboard_path = generate_dashboard(reports, get_dashboard_path())
console.print(f"\n[dim]Dashboard updated: {dashboard_path}[/dim]")
```

Only if `prism/dashboard.py` import succeeds — don't break analyze if dashboard 
generation fails (try/except, fail silently with a dim warning).

---

## 2. Claude Code /plugin Install

### What this adds

Users can install PRISM as a Claude Code plugin alongside the existing pip install.
Both install methods work independently.

### New files to create

**`plugin.json`** (repo root):
```json
{
  "name": "prism",
  "version": "0.2.0",
  "description": "Session intelligence for Claude Code — find why your sessions fail and fix them",
  "author": "jakeefr",
  "license": "MIT",
  "repository": "https://github.com/jakeefr/prism",
  "claudeCode": {
    "minVersion": "2.0.0"
  },
  "skills": [
    {
      "name": "prism-analyze",
      "path": "skills/prism-analyze/SKILL.md"
    }
  ],
  "hooks": []
}
```

**`skills/prism-analyze/SKILL.md`**:
```markdown
# prism-analyze

Analyze Claude Code session health using PRISM.

## When to use
When the user asks to analyze their Claude Code sessions, check token usage,
audit their CLAUDE.md, or understand why sessions are failing.

## Usage

Run the analysis:
```bash
prism analyze
```

If prism is not installed:
```bash
pip install prism-cc
prism analyze
```

For a specific project:
```bash
prism analyze --project <path>
```

For CLAUDE.md recommendations:
```bash
prism advise
```

## What PRISM shows
- Health scores (A-F) across 5 dimensions per project
- Token efficiency: CLAUDE.md re-read costs, compaction frequency
- Tool health: retry loops, edit-revert cycles, consecutive failures
- Context hygiene: compaction loss events, mid-task boundaries
- CLAUDE.md adherence: whether your rules are actually being followed
- Session continuity: resume success rate, truncated sessions

## Output
PRISM prints a health report table and top issues per project.
Run `prism` (no args) to open the interactive TUI dashboard.
Run `prism dashboard` to open the HTML dashboard in your browser.
```

**`README` install section update** — add plugin install option:
```markdown
## Install

\`\`\`bash
# pip (standalone CLI)
pip install prism-cc

# pipx (recommended)
pipx install prism-cc

# Claude Code plugin
/plugin marketplace add jakeefr/prism
/plugin install prism
\`\`\`
```

### Note on hooks
Do NOT add any hooks to plugin.json for now. Hooks that intercept tool calls 
require careful testing to ensure fail-open behavior. The plugin in v0.2.0 
is skill-only — it teaches Claude Code how to invoke PRISM, nothing more.
Hooks can be added in v0.3.0 after the plugin install path is validated.

---

## 3. Attention Curve Scorer

### What it does
Adds a new recommendation type to `advisor.py` based on the U-shaped attention 
curve finding: LLMs pay most attention to content at the beginning and end of 
a prompt, least to content in the middle.

For a CLAUDE.md with N lines, the "danger zone" is roughly lines 
`int(N * 0.2)` through `int(N * 0.75)` — the middle 55%.

### Implementation

Add to `prism/advisor.py`:

```python
def _recommend_attention_curve(
    report: ProjectHealthReport,
) -> list[Recommendation]:
    """
    Score CLAUDE.md rules by their position in the U-shaped attention curve.
    Rules in the middle 55% of the file get the least model attention.
    Flag critical rules (Never/NEVER/CRITICAL/DO NOT) that are in the danger zone.
    """
    if not report.claude_md_path or not report.claude_md_path.exists():
        return []
    
    lines = report.claude_md_path.read_text().splitlines()
    total = len(lines)
    if total < 20:  # Too short to matter
        return []
    
    danger_start = int(total * 0.20)
    danger_end = int(total * 0.75)
    
    critical_patterns = ["NEVER", "CRITICAL", "DO NOT", "ALWAYS", "MUST NOT"]
    buried_rules = []
    
    for i, line in enumerate(lines):
        if danger_start <= i <= danger_end:
            if any(p in line.upper() for p in critical_patterns):
                buried_rules.append((i + 1, line.strip()))
    
    if not buried_rules:
        return []
    
    rule_list = "\n".join(
        f"  Line {lineno}: {text[:80]}" 
        for lineno, text in buried_rules[:5]
    )
    
    return [Recommendation(
        action="RESTRUCTURE",
        impact="Medium",
        rationale=(
            f"Found {len(buried_rules)} critical rule(s) in the attention dead zone "
            f"(lines {danger_start}–{danger_end} of {total}). "
            "LLMs follow a U-shaped attention curve — middle content gets least focus. "
            "Move NEVER/CRITICAL rules to the first 20% or last 25% of your CLAUDE.md."
        ),
        content=f"Move these rules to the top or bottom of your CLAUDE.md:\n{rule_list}",
    )]
```

Add `_recommend_attention_curve` to the list of generators called in 
`generate_recommendations()`.

Add tests in `tests/test_advisor.py`:
- Test with short file (<20 lines) — no recommendation
- Test with critical rule in danger zone — recommendation generated
- Test with all critical rules at top — no recommendation

---

## 4. README and GitHub Improvements

### 4a. Splash image

Create `assets/splash.svg` — a clean SVG banner for the top of the README.

Design: dark background (#0d1117), "PRISM" in large monospace text, 
subtitle "session intelligence for claude code" smaller below.
Use the prism color palette. Simple, not flashy — looks like a serious dev tool.
Size: 1200×300px viewBox.

Reference in README at the very top, before the title:
```markdown
<p align="center">
  <img src="assets/splash.svg" alt="PRISM" width="800">
</p>
```

### 4b. Expanded badge row

Replace current 4 badges with this expanded set:
```markdown
[![PyPI version](https://img.shields.io/pypi/v/prism-cc?cache=1)](https://pypi.org/project/prism-cc/)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![Python 3.11+](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/)
[![Tests](https://img.shields.io/github/actions/workflow/status/jakeefr/prism/tests.yml?label=tests)](https://github.com/jakeefr/prism/actions)
[![PyPI downloads](https://img.shields.io/pypi/dm/prism-cc?label=installs)](https://pypi.org/project/prism-cc/)
[![Claude Code Plugin](https://img.shields.io/badge/Claude%20Code-Plugin-orange.svg)](https://github.com/jakeefr/prism)
[![Zero dependencies](https://img.shields.io/badge/external%20deps-4-brightgreen.svg)](pyproject.toml)
```

### 4c. Trust & Safety FAQ section

Add after the "How it works" section in README.md:

```markdown
## Trust & Safety

<details>
<summary><b>Does PRISM send any data anywhere?</b></summary>

No. PRISM never makes network calls. All analysis runs locally against files 
already on your machine. No telemetry, no analytics, no external servers.
</details>

<details>
<summary><b>Can PRISM hurt my Claude Code sessions?</b></summary>

No. PRISM is read-only — it never modifies session files. It reads 
~/.claude/projects/ but never writes to it. Your sessions are completely 
untouched.
</details>

<details>
<summary><b>Does PRISM modify my CLAUDE.md without asking?</b></summary>

Only if you explicitly run `prism advise --apply` and confirm the prompt. 
`prism advise` (without --apply) only prints recommendations — it never 
touches any file.
</details>

<details>
<summary><b>What data does PRISM read?</b></summary>

Only the JSONL session files Claude Code writes to `~/.claude/projects/` 
and your CLAUDE.md files. It reads nothing else. No API keys, no environment 
variables, no network traffic.
</details>

<details>
<summary><b>Does it work with Claude Code Max / Pro / Team?</b></summary>

Yes — PRISM reads local session files which are written by all Claude Code 
subscription tiers. The analysis works identically regardless of your plan.
</details>

<details>
<summary><b>What are PRISM's dependencies?</b></summary>

Four packages: textual, rich, typer, watchdog. All well-maintained, 
widely-used Python libraries. No C extensions, no compiled binaries.
</details>
```

### 4d. docs/ directory

Create these files:

**`docs/how-it-works.md`** — technical explanation of the JSONL format, 
how each metric is calculated, what the scores mean. 
Pull from the existing analyzer.py docstrings and expand them.

**`docs/claude-md-guide.md`** — guide to optimizing your CLAUDE.md based 
on what PRISM detects. Cover: line count, rule placement (attention curve), 
subdirectory files, what to trim. Use the research findings.

**`docs/commands.md`** — full command reference. Every command, every flag, 
example output for each.

**`docs/faq.md`** — expanded FAQ beyond the Trust & Safety section. 
Common questions: "Why is my Token Efficiency score low?", 
"What is a compaction boundary?", "How do I fix a D grade?", etc.

---

## Build Order

1. Bump version to 0.2.0 in pyproject.toml
2. Add `_recommend_attention_curve` to advisor.py + tests
3. Create `prism/dashboard.py` + tests
4. Integrate dashboard into cli.py analyze_cmd
5. Add `dashboard_cmd` to cli.py
6. Create `plugin.json` + `skills/prism-analyze/SKILL.md`
7. Create `assets/splash.svg`
8. Update README.md (badges + Trust & Safety FAQ + install section + splash)
9. Create `docs/` files
10. Run full pytest suite — all tests must pass
11. Commit and push
12. Build and publish to PyPI as 0.2.0

---

## What Must NOT Change

- All existing commands: `prism`, `prism analyze`, `prism advise`, 
  `prism replay`, `prism watch`, `prism projects` — behavior identical
- All existing flags and their behavior
- All existing TUI screens and navigation
- All existing test fixtures
- The --project path resolution logic added in 0.1.2
- pyproject.toml entry point: `prism = "prism.cli:app"`

---

## First Message to Send Claude Code

```
Read PRISM_V020_SPEC.md in full before writing any code.

Build the v0.2.0 upgrades exactly as specified. Current version is 0.1.2.

Critical rules:
- Do NOT break any existing commands or functionality
- Run pytest after each major step — all 77 existing tests must keep passing
- The HTML dashboard must be self-contained (no CDN, no external deps)
- The plugin install adds skills only — no hooks in v0.2.0
- Follow the build order at the bottom of the spec

Start with step 1: bump version to 0.2.0 in pyproject.toml.
```
