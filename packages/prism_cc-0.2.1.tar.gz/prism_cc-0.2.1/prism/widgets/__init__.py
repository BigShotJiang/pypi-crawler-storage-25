"""PRISM Textual widgets."""
