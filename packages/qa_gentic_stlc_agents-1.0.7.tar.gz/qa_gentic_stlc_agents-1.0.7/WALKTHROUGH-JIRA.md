# STLC Agents — End-to-End Walkthrough: Jira Cloud

> Jira Cloud pipeline: issue → test cases → Gherkin → Playwright TypeScript → Helix-QA.
> For Azure DevOps see [WALKTHROUGH-ADO.md](WALKTHROUGH-ADO.md).

---

## Overview

The Jira pipeline mirrors the ADO pipeline exactly. `qa-jira-manager` replaces `qa-test-case-manager` as the entry point; the three shared agents (`qa-gherkin-generator`, `qa-playwright-generator`, `qa-helix-writer`) run identically in both pipelines. A coding assistant reads the skill files once and drives the full flow — from Jira issue to running self-healing tests — in a single session.

The scenario used throughout this walkthrough: **User Profile Photo Management** — a Jira Story covering photo upload, crop, and update.

---

## Setup

```bash
npm install -g @qa-gentic/stlc-agents
qa-stlc init --vscode --integration jira
```

`qa-stlc init --integration jira` does three things:

1. Installs all five Python MCP servers via `pip install qa-gentic-stlc-agents`
2. Copies Jira + shared skill files to `.github/copilot-instructions/` (and `.claude/` for non-VS Code targets)
3. Writes `.vscode/mcp.json` with `qa-jira-manager` + the three shared agents + Playwright MCP

Then start the Playwright MCP browser server:

```bash
npx @playwright/mcp@latest --port 8931
```

Copy `.env.example` to `.env` and populate your Jira credentials:

```env
JIRA_CLIENT_ID=your-atlassian-oauth-client-id
JIRA_CLIENT_SECRET=your-atlassian-oauth-client-secret
JIRA_CLOUD_ID=your-atlassian-cloud-id
APP_BASE_URL=https://your-app.example.com
APP_EMAIL=your-test-email@example.com
APP_PASSWORD=your-test-password
```

First run opens a browser once for Jira sign-in. The token is cached at `~/.jira-cache/jira-token.json` and silently refreshed for ~60 days.

---

## Phase 1 — Fetch Issue and Generate Test Cases (`qa-jira-manager`)

### What you say to your AI assistant

> "Run the full STLC pipeline for Jira issue PROJ-123"

or step by step:

> "Fetch Jira issue PROJ-123 and generate test cases"

### What happens

**Step 1.1 — Fetch the Jira issue**

The agent calls `fetch_jira_issue(issue_key="PROJ-123")`. This calls the Jira REST API v3, extracts acceptance criteria from the issue description, and runs `_extract_coverage_hints()` to scan for 11 coverage categories:

```
toast_notifications  file_size_boundary  post_action_state  platform_specific
computed_values      data_persistence    accessibility       image_manipulation
file_formats         cancel_flows        validation_errors
```

The response includes: `summary`, `description`, `acceptance_criteria`, `status`, `priority`, `story_points`, `project_key`, `epic_key`, `existing_test_cases_count`, `coverage_hints`.

For our scenario the response flags: `file_size_boundary`, `image_manipulation`, `toast_notifications`, `cancel_flows`, `post_action_state`, `file_formats`.

**Step 1.2 — Deduplication gate**

Before generating anything, the agent calls `get_linked_test_cases(issue_key="PROJ-123")` to fetch any existing 'is tested by' linked test cases. If any already exist, it diffs by summary and only creates net-new cases.

**Step 1.3 — Generate and confirm test cases**

`story_points = 5` → Medium complexity → 6–12 test cases planned.

The agent proposes the test case list to the user. After explicit confirmation it calls `create_and_link_test_cases(issue_key="PROJ-123", test_cases=[...])`.

For each test case, steps are stored as an ADF table in the issue description — compatible with Jira Software and Xray-free environments. Each new test case is linked to PROJ-123 via an `is tested by` / `Test` link.

**What appears in Jira:**

- 8 test case issues created in the same project
- Each issue linked to PROJ-123 via `is tested by`
- Steps visible as a formatted table in the description
- Priority, labels, and epic link inherited from the source issue

---

## Phase 2 — Gherkin BDD Generation (`qa-gherkin-generator`)

### What you say

> "Generate a Gherkin regression suite for PROJ-123"

### What happens

**Step 2.1 — Source acceptance criteria**

The agent uses the `acceptance_criteria` and `description` fetched in Phase 1 (no second network call needed if run in the same session). For Epic-level generation, `fetch_jira_epic_hierarchy` returns all child issues and their AC.

**Step 2.2 — Generate the feature file**

The coding agent reads all acceptance criteria, identifies user journeys, and writes scenarios following the skill rules:

- 5–10 scenarios per feature file
- `@smoke` tag on the primary happy path
- `@regression` on all others
- `Scenario Outline` for boundary/data-driven tests
- `Background` only when two or more scenarios share identical preconditions
- Every scenario includes explicit navigation steps

Example generated scenario:

```gherkin
@user_profile @regression
Feature: User Profile Photo Management
  As an authenticated user
  I want to manage my profile photo

  Background:
    Given the user is logged in and navigates to the Profile Settings page

  @smoke
  Scenario: User uploads a valid photo and sees confirmation
    Given the user navigates to the Profile Photo section
    When the user selects a valid JPG file under 5 MB
    And the user adjusts the crop and clicks Save
    Then a success toast notification should be displayed
    And the profile photo is updated in the application header

  @regression
  Scenario Outline: File size boundary validation
    Given the user navigates to the Profile Photo section
    When the user attempts to upload a file of <size> bytes
    Then <outcome>
    Examples:
      | size      | outcome                             |
      | 5242880   | the file is accepted                |
      | 5242881   | an error toast should be displayed  |
```

**Step 2.3 — Validate**

`validate_gherkin_content(...)` checks structure, tags, scenario count, and navigation steps.

**Step 2.4 — Deliver**

The agent asks the user: save locally, or attach to the Jira issue? Each delivery is an independent decision — the agent never infers one from the other.

---

## Phase 3 — Playwright Code Generation (`qa-playwright-generator`)

### Step 3.0 — Live browser inspection

The Playwright MCP server drives the live app and collects an accessibility tree snapshot. The coding agent builds a `context_map` from the AX tree snapshots and passes it to `generate_playwright_code`.

```
playwright:browser_navigate → https://your-app.com/profile
playwright:browser_snapshot → AX tree of the profile page
```

Every selector found in the AX tree is validated against the live DOM before it enters `locators.ts`. This is the **zero-hallucinations guarantee** — only selectors matching exactly one element are used.

### Step 3.1 — Scaffold the healing infrastructure (once per project)

`scaffold_locator_repository(...)` generates six shared TypeScript infrastructure files:

| File | Purpose |
|---|---|
| `LocatorHealer.ts` | 8-strategy locator resolution chain |
| `LocatorRepository.ts` | Persistent state store for all healing layers |
| `TimingHealer.ts` | Network drift detection and auto-healing |
| `VisualIntentChecker.ts` | Element screenshot comparison |
| `DevToolsHealer.ts` | CDP AX tree and bounding-box healing |
| `HealingDashboard.ts` | HTTP review server at `http://localhost:7890` |

### Step 3.2 — Generate the page object and step definitions

`generate_playwright_code(gherkin_content=..., context_map=..., ...)` produces:

| File | Contents |
|---|---|
| `src/pages/{kebab}/locators.ts` | CDP-verified selectors with intent, stability score, healing metadata |
| `src/pages/{kebab}/{kebab}.page.ts` | Page object with all three healing layers active |
| `src/test/steps/{kebab}.steps.ts` | Cucumber step definitions via PageFixture DI |
| `config/cucumber.js` | Cucumber profile entry |

Each locator entry includes why it was chosen:

```typescript
// CDP: stability=100 strategy=data-testid
saveButton: {
  selector: "[data-testid='profile-save-btn']",
  intent: 'save changes button',
  visualIntent: true,
  cdpSignals: { stability: 100, strategy: 'data-testid' }
},
```

### Step 3.3 — Deliver

The agent asks: attach to the Jira issue, or save locally? This is a separate, explicit decision from the Gherkin delivery in Phase 2.

---

## Phase 4 — Write to Helix-QA (`qa-helix-writer`)

### What you say

> "Write the generated files to my Helix-QA project at /workspace/my-qa-project"

### What happens

`write_helix_files(...)` routes each generated file to its correct Helix-QA location:

| Generated file | Helix path |
|---|---|
| `locators.ts` | `src/locators/<kebab>.locators.ts` |
| `<Page>.page.ts` | `src/pages/<Page>.page.ts` |
| `<feature>.steps.ts` | `src/test/steps/<feature>.steps.ts` |
| `<feature>.feature` | `src/test/features/<feature>.feature` |
| Infrastructure files | `src/utils/locators/<file>` |

Before writing, `list_helix_tree` and `read_helix_file` are called for overlap detection — no file is blindly overwritten.

---

## Phase 5 — Running the Tests

```bash
ENABLE_SELF_HEALING=true \
HEALING_DASHBOARD_PORT=7890 \
cucumber-js --config=config/cucumber.js -p user_profile_photo_management
```

**First run:** `locator-repository.json` does not exist. Every locator works through the full resolution chain, bounding boxes are captured, and visual baselines are created.

**Subsequent runs:** Cached healed selectors are tried first (Strategy 1), skipping the rest of the chain.

---

## Self-Healing in Action

### When a selector breaks

Say the developer renames `data-testid='profile-save-btn'` to `data-testid='save-profile-button'`.

1. Strategy 1 (cached) fails
2. Strategy 2 (primary CSS) fails
3. Strategy 3 (`page.getByRole('button', { name: /save/i })`) succeeds
4. Suggestion queued to HealingDashboard at `http://localhost:7890`

The engineer sees the current selector, the suggested fix, and the strategy that found it. They Approve or Reject. Nothing commits without human review.

### When an API slows down

`TimingHealer` detects drift beyond the 20% threshold, auto-adjusts the timeout with 50% headroom, and queues a timing suggestion for engineer review.

### When a visual element changes

`VisualIntentChecker` detects a pixel diff above the 0.5% threshold and queues a visual suggestion. The engineer views the before/after diff and approves the new baseline.

---

## What the Engineer Reviews at the End

After one session:

- Jira test case issues linked to the source story with structured steps
- A validated `.feature` file (saved locally or attached to the Jira issue)
- Playwright TypeScript code in the Helix-QA project
- A running test suite with three-layer self-healing
- `http://localhost:7890` for reviewing any AI-suggested changes before they commit

**Nothing is committed to the repository without human review.** The system suggests; engineers decide.

---

## Related

- [QUICKSTART-JIRA.md](QUICKSTART-JIRA.md) — quick install reference
- [ARCHITECTURE-JIRA.md](ARCHITECTURE-JIRA.md) — technical architecture
- [WALKTHROUGH-ADO.md](WALKTHROUGH-ADO.md) — Azure DevOps walkthrough
