# STLC Agents — End-to-End Walkthrough: Azure DevOps

> Azure DevOps pipeline: PBI / Bug / Feature → test cases → Gherkin → Playwright TypeScript → Helix-QA.
> For Jira Cloud see [WALKTHROUGH-JIRA.md](WALKTHROUGH-JIRA.md).

---

## Overview

The QA STLC Agent system automates the full Software Test Life Cycle through five co-ordinated AI agents. The ADO pipeline uses four of them, each exposed as a Model Context Protocol (MCP) server. A coding assistant (Claude Code, GitHub Copilot in VS Code, Cursor, or Windsurf) reads the skill files once and can then drive the entire pipeline — from ADO work item to running self-healing tests — in a single session.

The scenario used throughout this walkthrough: **User Profile Photo Management** — a feature allowing users to upload, crop, and update their profile photo.

---

## Setup

```bash
npm install -g @qa-gentic/stlc-agents
qa-stlc init --vscode --integration ado
```

`qa-stlc init --integration ado` does three things in one command:

1. Installs all five Python MCP servers via `pip install qa-gentic-stlc-agents`
2. Copies skill files to `.github/copilot-instructions/` (and `.claude/` for non-VS Code targets)
3. Writes `.vscode/mcp.json` with all five servers configured

Then start the Playwright MCP browser server:

```bash
npx @playwright/mcp@latest --port 8931
```

Copy `.env.example` to `.env` and populate your ADO credentials:

```
ADO_ORGANIZATION_URL=https://dev.azure.com/your-org
ADO_PROJECT_NAME=YourProject
ADO_PAT=your-personal-access-token
APP_BASE_URL=https://your-app.example.com
APP_EMAIL=your-test-email@example.com
APP_PASSWORD=your-test-password
```

---

## Phase 1 — Manual Test Case Generation (Agent 1: `qa-test-case-manager`)

### What you say to your AI assistant

> "Generate test cases for work item #12345 in MyProject at https://dev.azure.com/myorg"

### What happens

**Step 1.1 — Fetch the work item**

The agent calls `fetch_work_item(work_item_id=12345, ...)`. Internally this calls the ADO REST API, strips HTML from rich-text fields, and runs `_extract_coverage_hints()` to scan acceptance criteria for 11 coverage categories:

```
toast_notifications  file_size_boundary  post_action_state  platform_specific
computed_values      data_persistence    accessibility       image_manipulation
file_formats         cancel_flows        validation_errors
```

The response includes the work item details, story points (used to classify complexity), existing test case count, parent feature, and coverage hints.

For our scenario, the response flags: `file_size_boundary`, `image_manipulation`, `toast_notifications`, `cancel_flows`, `post_action_state`, `file_formats`.

**Step 1.2 — Create and link test cases**

`story_points = 5` → Medium complexity → 6–12 test cases planned.

The agent calls `create_and_link_test_cases(...)` with a structured list of test cases. For each one, `_build_steps_xml()` generates the `Microsoft.VSTS.TCM.Steps` XML format required by ADO, then a `TestedBy-Forward` link connects each new TC back to PBI #12345.

**What appears in ADO:**

- 8 test cases created and visible under the Tests tab of PBI #12345
- Area path and iteration path automatically inherited from the parent work item
- Each test case titled with a `TC_{id}_{seq}` prefix for traceability

**Deduplication gate:** Before creating anything, the agent runs `get_linked_test_cases` to fetch existing TCs. If any already exist, it diffs by title and only creates net-new cases.

---

## Phase 2 — Gherkin BDD Generation (Agent 2: `qa-gherkin-generator`)

### What you say

> "Generate a Gherkin regression suite for Feature #11000 in MyProject at https://dev.azure.com/myorg"

### What happens

**Step 2.1 — Fetch the feature hierarchy**

`fetch_feature_hierarchy(feature_id=11000, ...)` walks the full Feature hierarchy — Feature → PBIs → Bugs — and for each child fetches linked test cases with their full XML steps. A best-practice Gherkin example is embedded directly in the API response so the coding agent always has a concrete style reference.

**Step 2.2 — Generate the feature file**

The coding agent reads all test cases, identifies feature-level journeys, and writes scenarios following the skill rules:

- 5–10 scenarios per feature file
- `@smoke` tag on the primary happy path
- `@regression` on all others
- `Scenario Outline` for boundary/data-driven tests
- `Background` only when two or more scenarios share identical preconditions

Example generated scenario:

```gherkin
@user_profile @regression
Feature: User Profile Photo Management
  As an authenticated user
  I want to manage my profile photo

  Background:
    Given user logs in with Microsoft SSO as "standard_user"

  @smoke
  Scenario: User uploads a valid photo and sees confirmation
    Given the user navigates to the Profile Photo section
    When the user selects a valid JPG file under 5 MB
    And the user adjusts the crop and clicks Save
    Then a success toast notification should be displayed
    And the profile photo is updated in the application header

  @regression
  Scenario Outline: File size boundary validation
    Given the user navigates to the Profile Photo section
    When the user attempts to upload a file of <size> bytes
    Then <outcome>
    Examples:
      | size      | outcome                             |
      | 5242880   | the file is accepted                |
      | 5242881   | an error toast should be displayed  |
```

**Step 2.3 — Validate and attach**

`validate_gherkin_content(...)` checks structure, tags, scenario count, and navigation steps before attachment is offered. Only after the user explicitly confirms does the agent call `attach_gherkin_to_feature(...)`.

**What appears in ADO:**

File `11000_user-profile-management_regression.feature` attached to Feature #11000, visible under Attachments.

---

## Phase 3 — Playwright Code Generation (Agent 3: `qa-playwright-generator`)

### Step 3.0 — Live browser inspection (strongly recommended)

The Playwright MCP server drives the live app and collects an accessibility tree snapshot. The coding agent builds a `context_map` from the AX tree snapshots and passes it to `generate_playwright_code`.

```
playwright:browser_navigate → https://your-app.com/profile
playwright:browser_snapshot → AX tree of the profile page
```

Every selector found in the AX tree is validated against the live DOM before it enters `locators.ts`. This is the **zero-hallucinations guarantee** — only selectors matching exactly one element are used.

### Step 3.1 — Scaffold the healing infrastructure (once per project)

`scaffold_locator_repository(...)` generates six shared TypeScript infrastructure files:

| File | Purpose |
|---|---|
| `LocatorHealer.ts` | 8-strategy locator resolution chain |
| `LocatorRepository.ts` | Persistent state store for all healing layers |
| `TimingHealer.ts` | Network drift detection and auto-healing |
| `VisualIntentChecker.ts` | Element screenshot comparison |
| `DevToolsHealer.ts` | CDP AX tree and bounding-box healing |
| `HealingDashboard.ts` | HTTP review server at `http://localhost:7890` |

### Step 3.2 — Generate the page object and step definitions

`generate_playwright_code(gherkin_content=..., context_map=..., ...)` produces:

| File | Contents |
|---|---|
| `src/pages/{kebab}/locators.ts` | CDP-verified selectors with intent, stability score, and healing metadata |
| `src/pages/{kebab}/{kebab}.page.ts` | Page object with all three healing layers active |
| `src/test/steps/{kebab}.steps.ts` | Cucumber step definitions via PageFixture DI |
| `config/cucumber.js` | Cucumber profile entry |

Each locator entry includes why it was chosen:

```typescript
// CDP: stability=100 strategy=data-testid
saveButton: {
  selector: "[data-testid='profile-save-btn']",
  intent: 'save changes button',
  visualIntent: true,
  cdpSignals: { stability: 100, strategy: 'data-testid' }
},
```

### Step 3.3 — Write files to Helix-QA (Agent 4: `qa-helix-writer`)

If the project uses the Helix-QA directory layout, `write_helix_files(...)` routes each generated file to its correct location automatically:

| Generated file | Helix path |
|---|---|
| `locators.ts` | `src/locators/<kebab>.locators.ts` |
| `<Page>.page.ts` | `src/pages/<Page>.page.ts` |
| `<feature>.steps.ts` | `src/test/steps/<feature>.steps.ts` |
| Infrastructure files | `src/utils/locators/<file>` |

### Step 3.4 — Attach to ADO

After the user explicitly confirms, `attach_code_to_work_item(...)` uploads delta files to PBI #12345. Only net-new files are uploaded — existing attachments are not duplicated.

---

## Phase 4 — Running the Tests

```bash
ENABLE_SELF_HEALING=true \
HEALING_DASHBOARD_PORT=7890 \
cucumber-js --config=config/cucumber.js -p user_profile_photo_management
```

**First run:** `locator-repository.json` does not exist. Every locator works through the full resolution chain, bounding boxes are captured after each successful click, and visual baselines are created.

**Subsequent runs:** Cached healed selectors are tried first (Strategy 1), skipping the rest of the chain. Timing baselines from prior runs are used for drift detection.

---

## Self-Healing in Action

### When a selector breaks

Say the developer renames `data-testid='profile-save-btn'` to `data-testid='save-profile-button'`.

1. Strategy 1 (cached) fails
2. Strategy 2 (primary CSS) fails
3. Strategy 3 (`page.getByRole('button', { name: /save/i })`) succeeds
4. Suggestion queued to HealingDashboard

At `http://localhost:7890` the engineer sees the current selector, the suggested fix, and the strategy that found it. They can Approve (write to `locator-repository.json`) or Reject and manually set the correct `data-testid`. Nothing commits without human review.

### When an API slows down

A backend change causes the upload endpoint to take 1200ms instead of the baseline 430ms.

`TimingHealer` detects 179% drift, auto-adjusts the timeout to 1800ms (1200ms × 1.5 headroom) so the test doesn't fail, and queues a timing suggestion. The engineer approves the new baseline.

### When a visual element changes

A design update changes the success toast from green to teal. `LocatorHealer` still finds the element, but `VisualIntentChecker` detects a 3.2% pixel diff (above the 0.5% threshold) and queues a visual suggestion. The engineer views the before/after diff and approves the new baseline.

---

## What the Engineer Reviews at the End

After one session:

- Structured test cases linked to the PBI in ADO
- A validated `.feature` file attached to the Feature in ADO
- Playwright TypeScript code attached to the PBI in ADO
- A running test suite with self-healing on all four layers
- `http://localhost:7890` for reviewing any AI-suggested changes before they commit

**Nothing is committed to the repository without human review.** The system suggests; engineers decide.

---

## Related

- [QUICKSTART-ADO.md](QUICKSTART-ADO.md) — quick install reference
- [ARCHITECTURE-ADO.md](ARCHITECTURE-ADO.md) — technical architecture
- [WALKTHROUGH-JIRA.md](WALKTHROUGH-JIRA.md) — Jira Cloud walkthrough
