# {{PROJECT_NAME}}

> Playwright + Cucumber + TypeScript QA automation framework with **three-layer AI self-healing** for locators.
> Scaffolded by [`@qa-gentic/stlc-agents`](https://www.npmjs.com/package/@qa-gentic/stlc-agents).

---

## Features

| Capability | Detail |
|---|---|
| **BDD / Gherkin** | Cucumber 12 with tagged scenario filtering |
| **Parallel execution** | 2 workers (local), 4 workers (CI) |
| **Three-layer self-healing** | LocatorHealer → TimingHealer → VisualIntentChecker |
| **5 AI providers** | OpenAI, Anthropic/Claude, Grok, Ollama, LM Studio |
| **Healing dashboard** | Live browser UI at port 7890 during test runs |
| **Review server** | Post-run review + PR creation at port 7891 |
| **CI/CD integration** | Azure Pipelines + GitHub Actions; `healix:apply-ci` script |
| **Docker** | `docker-compose.yml` for reproducible runs |
| **Auth caching** | Browser storage-state login once, reuse across all tests |
| **TypeScript** | Strict mode, ES2022, full path aliases |

---

## Quick Start

```bash
# 1. Install dependencies
npm install
npx playwright install chromium

# 2. Configure your environment
cp .env.example .env
# Edit .env — set BASE_URL and AI_API_KEY at minimum

# 3. Run the example test
npm test

# 4. View the HTML report
open test-results/reports/cucumber-report.html
```

---

## Directory Structure

```
src/
  config/          # Environment, global setup/teardown
  hooks/           # Cucumber BeforeAll/Before/After/AfterAll
  pages/           # BasePage (all healing APIs wired here)
  locators/        # base.locators.ts — common selectors
  test/
    features/      # Your .feature files (Gherkin scenarios)
    steps/         # Cucumber step definitions
  templates/       # Copy these to create new pages rapidly
  utils/
    helpers/       # Logger, RetryHandler, WaitHelper
    locators/      # Full self-healing infrastructure (see below)
    ai-assistant/  # AILocatorGenerator, AISelfHealing, AITestGenerator
    storage-state/ # AuthManager, AuthSetup
storage-state/     # Saved browser auth state + healed-locators.json (git-ignored)
test-results/      # Reports, screenshots, traces, videos, visual baselines
logs/              # Winston log files
```

---

## Creating a New Page

```bash
# 1. Copy templates
cp src/templates/_template.feature        src/test/features/my-page.feature
cp src/templates/_template.locators.ts    src/locators/my-page.locators.ts
cp src/templates/_template.steps.ts       src/test/steps/my-page.steps.ts
cp src/templates/_TemplatePage.ts         src/pages/MyPage.ts

# 2. Rename "Template" → your page name in each file
# 3. Update locators to match your page elements
# 4. Write your Gherkin scenarios
# 5. npm test -- --tags @my-tag
```

---

## Self-Healing Architecture

### Layer 1 — LocatorHealer (`src/utils/locators/LocatorHealer.ts`)

When a locator fails at runtime, the healer automatically walks this chain:

| Step | Strategy | Description |
|---|---|---|
| 1 | Primary selector | The selector from your locators file |
| 2 | `getByRole` | Inferred from the element's `intent` string |
| 3 | `getByLabel` / `getByPlaceholder` | For form inputs |
| 4 | `getByText` | Visible text content match |
| 5 | AI Vision | Page screenshot → chosen AI provider identifies the element |
| 6 | CDPSession AX tree | Crawls the accessibility tree as a last resort |

Every healed selector is **persisted** in `LocatorRepository` — zero healing overhead on repeat runs within the same pipeline.

### Layer 2 — TimingHealer (`src/utils/locators/TimingHealer.ts`)

Adaptive EMA-based network-idle timeouts per labelled action. Learns expected network patterns per step over time, automatically adjusting as your app's performance changes. Flags timing drift to the HealingDashboard when actual wait exceeds `baseline × 1.5`.

### Layer 3 — VisualIntentChecker (`src/utils/locators/VisualIntentChecker.ts`)

Screenshot-based element identity verification. For locators with `visualIntent: true`, captures element screenshots and pixel-diffs against stored baselines. Logs a dashboard warning when size diff exceeds 2%. Baselines are stored in `test-results/visual-baselines/`.

---

## AI Provider Configuration

Set `AI_PROVIDER` in `.env`:

| Provider | `AI_PROVIDER` value | Required env var | Notes |
|---|---|---|---|
| OpenAI (gpt-4o) | `openai` | `AI_API_KEY` | Default |
| Anthropic Claude | `claude` or `anthropic` | `AI_API_KEY` | Uses claude-opus-4-6 |
| Grok | `grok` | `AI_API_KEY` | xAI vision API |
| Ollama (local) | `ollama` | `OLLAMA_ENDPOINT` | No key needed |
| LM Studio | `local` | `LOCAL_LLM_ENDPOINT` | No key needed |

> Self-healing still works without an AI key — Layers 2 and 3 are purely algorithmic. Layer 1 falls back to AX tree if no AI key is set.

---

## Environment Variables

See `.env.example` for the full reference. Minimum required:

| Variable | Default | Description |
|---|---|---|
| `BASE_URL` | `https://example.com` | Application under test |
| `BROWSER` | `chromium` | `chromium` / `firefox` / `webkit` |
| `HEADLESS` | `true` | Headless browser mode |
| `AI_PROVIDER` | `openai` | AI provider for Layer 1 healing |
| `AI_API_KEY` | — | API key for chosen provider |
| `ENABLE_SELF_HEALING` | `true` | Master switch for all healing layers |
| `HEALING_DASHBOARD_PORT` | `7890` | Live healing dashboard port |
| `HEALIX_REVIEW_PORT` | `7891` | Post-run review server port |
| `HEAL_STORE_PATH` | `self-heal/healed-locators.json` | Persisted heal store location |
| `HEAL_SEARCH_ROOTS` | `src/` | Comma-separated dirs to search when applying heals |
| `HEAL_PR_BASE_BRANCH` | `main` | Target branch for heal PRs |

---

## Healing Dashboard

During a test run the live dashboard is available at **http://localhost:7890** (or `HEALING_DASHBOARD_PORT`).

- **Live view** — watch heals as they happen, grouped by strategy
- **Summary** — counts by strategy (ai-vision, ax-tree, role, label, text)
- **Registry** — all healed locators with approval status

---

## Viewing & Updating Healed Locators After a Pipeline Run

### Where healed locators are stored

All healed locators are written to a JSON file during the test run:

```
self-heal/healed-locators.json   ← controlled by HEAL_STORE_PATH
```

Each entry captures everything needed to review and apply the fix:

```json
{
  "loginPage_usernameInput": {
    "healedSelector": "#username",
    "originalSelector": "[data-testid='user-input']",
    "strategy": "ai-vision",
    "provider": "claude",
    "intent": "username input field",
    "healCount": 1,
    "lastHealedAt": "2025-01-15T10:30:00.000Z",
    "approved": false
  }
}
```

---

### Option A — Manual Review (recommended for production)

The pipeline publishes `healed-locators.json` as a build artifact. After the run:

```bash
# 1. Download the artifact and place it at:
#    self-heal/healed-locators.json

# 2. Start the review server
npm run healix:review
# Opens http://localhost:7891

# 3. In the browser UI:
#    • Inspect each original → healed selector pair
#    • ✓ Approve or ✗ Reject individually
#    • Click "Apply approved & create PR"
```

The review server rewrites your TypeScript locator source files directly and opens a PR on the branch `heal/locator-fixes-{timestamp}`.

---

### Option B — CI Auto-Apply (fast-track)

```bash
HEALIX_CI_AUTO_APPROVE=true npm run healix:apply-ci
```

This headless script:
1. Auto-approves every heal in the store
2. Finds each `originalSelector` string literal in `.ts` files under `HEAL_SEARCH_ROOTS`
3. Replaces it in-place with the `healedSelector`
4. Commits to a new branch and creates a PR (GitHub Actions via `gh`, or Azure Pipelines via `az repos pr create`)

The **next test run uses the fixed selector natively** — zero re-healing overhead because the source file itself has been updated.

---

### Pipeline Configuration

#### GitHub Actions

```yaml
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Install dependencies
        run: npm ci && npx playwright install chromium

      - name: Run tests
        run: npm run test:ci
        env:
          BASE_URL: ${{ secrets.BASE_URL }}
          AI_API_KEY: ${{ secrets.AI_API_KEY }}
          AI_PROVIDER: claude

      - name: Upload healed locators artifact
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: healed-locators
          path: self-heal/healed-locators.json

      - name: Apply heals and create PR
        if: always()
        run: npm run healix:apply-ci
        env:
          HEALIX_CI_AUTO_APPROVE: "true"
          GH_TOKEN: ${{ secrets.GITHUB_TOKEN }}
          HEAL_PR_BASE_BRANCH: main
```

#### Azure Pipelines

```yaml
trigger:
  - main

pool:
  vmImage: ubuntu-latest

steps:
  - task: NodeTool@0
    inputs:
      versionSpec: '20.x'

  - script: npm ci && npx playwright install chromium
    displayName: Install dependencies

  - script: npm run test:ci
    displayName: Run tests
    env:
      BASE_URL: $(BASE_URL)
      AI_API_KEY: $(AI_API_KEY)
      AI_PROVIDER: claude

  - task: PublishPipelineArtifact@1
    condition: always()
    inputs:
      targetPath: self-heal/healed-locators.json
      artifact: healed-locators
    displayName: Upload heal store

  - script: npm run healix:apply-ci
    condition: always()
    displayName: Apply heals and create PR
    env:
      HEALIX_CI_AUTO_APPROVE: "true"
      ADO_PAT: $(System.AccessToken)
      HEAL_PR_BASE_BRANCH: main
```

---

### CI Decision Flow

```
Tests run in CI pipeline
         │
         ▼
Locator fails → LocatorHealer auto-heals
         │
         ▼
Heal saved to self-heal/healed-locators.json
         │
         ├─── HEALIX_CI_AUTO_APPROVE=true ──────► healix:apply-ci
         │                                              │
         │                                    Rewrites .ts source files
         │                                    Pushes branch + opens PR
         │                                    Next run: healed natively ✓
         │
         └─── HEALIX_CI_AUTO_APPROVE=false ───► Artifact uploaded
                                                       │
                                              Download artifact locally
                                                       │
                                              npm run healix:review
                                              http://localhost:7891
                                                       │
                                              Approve / Reject in browser UI
                                                       │
                                              "Apply approved & create PR"
```

---

### What `HealApplicator` Does to Your Source Files

When heals are applied (either path above), `HealApplicator` (`src/utils/locators/HealApplicator.ts`):

1. Searches all `.ts` files under `HEAL_SEARCH_ROOTS` (default: `src/`)
2. Finds the exact string literal matching `originalSelector` using a regex pattern
3. Replaces the **first** occurrence in-place with `healedSelector`
4. Normalises attribute selector quoting (`['attr'='val']` → `["attr"="val"]`)
5. Creates a git branch `heal/locator-fixes-{timestamp}`
6. Commits changed files and pushes
7. Opens a PR via `gh pr create` (GitHub) or `az repos pr create` (ADO)

Files that are skipped (original selector not found in source) are listed in the review UI and in CI output, so nothing is lost silently.

---

## Scripts Reference

| Script | Purpose |
|---|---|
| `npm test` | Run all tests |
| `npm run test:smoke` | `@smoke` tagged scenarios only |
| `npm run test:regression` | `@regression` tagged scenarios only |
| `npm run test:headed` | Headed browser (visual debug) |
| `npm run test:parallel` | 4 parallel workers, `@regression` tag |
| `npm run test:ci` | CI profile (4 workers, retry off) |
| `npm run test:chrome` | Force Chromium |
| `npm run test:firefox` | Force Firefox |
| `npm run test:webkit` | Force WebKit |
| `npm run auth:setup` | Save browser auth state to `storage-state/` |
| `npm run healix:review` | Start post-run review server at port 7891 |
| `npm run healix:apply-ci` | Headless CI heal applicator |
| `npm run report:open` | Open the HTML Cucumber report |
| `npm run typecheck` | TypeScript type-check (no emit) |
| `npm run lint` | ESLint check |
| `npm run lint:fix` | ESLint auto-fix |
| `npm run docker:build` | Build Docker image |
| `npm run docker:run` | Run tests via docker-compose |

---

## Locator Stability Guide

Write the most stable selector your app supports. Self-healing kicks in automatically when a selector breaks — but a stable selector is always faster.

| Stability | Selector type | When to use |
|---|---|---|
| ★★★★★ | `[data-testid="x"]` | Ask devs to add test IDs — best investment |
| ★★★★☆ | `getByRole` with accessible name | Element has an ARIA role |
| ★★★★☆ | `#id` | Stable, unique ID |
| ★★★☆☆ | `aria-label` or `placeholder` | Form inputs without test IDs |
| ★★☆☆☆ | Visible text | Buttons, links — breaks on copy changes |
| ★☆☆☆☆ | CSS class / XPath | Last resort — breaks on any redesign |

---

## Authentication Setup

```bash
npm run auth:setup
```

Set `USE_STORAGE_STATE=true` in `.env`. All subsequent scenarios reuse the saved session — login runs once per suite rather than once per scenario.

---

## Docker

```bash
# Build image
npm run docker:build

# Run full suite
npm run docker:run

# Tear down
npm run docker:down
```

The `docker-compose.yml` mounts `test-results/` as a volume so reports and screenshots are available on the host after the container exits.

---

## Scaffolded by @qa-gentic/stlc-agents

This project was created with the `qa-stlc scaffold` command from [`@qa-gentic/stlc-agents`](https://www.npmjs.com/package/@qa-gentic/stlc-agents) — an AI-powered QA STLC automation toolkit that connects Azure DevOps and Jira work items to self-healing Playwright TypeScript.

```bash
# Scaffold a new project
npx @qa-gentic/stlc-agents scaffold --name my-qa-project

# Generate Playwright code from a work item (requires MCP agents)
# Azure DevOps:
Generate Playwright TypeScript for PBI #12345 in MyProject at https://dev.azure.com/myorg

# Jira:
Generate Playwright TypeScript for Jira issue PROJ-123
```

Five MCP agents cover the full STLC pipeline:

| Agent | Role |
|---|---|
| `qa-test-case-manager` | ADO work item → manual test cases |
| `qa-gherkin-generator` | Epic / Feature / PBI → `.feature` file |
| `qa-playwright-generator` | Gherkin + live browser → `locators.ts` + page objects + steps |
| `qa-helix-writer` | Generated files → Helix-QA directory layout on disk |
| `qa-jira-manager` | Jira issue → test cases → Gherkin → Playwright |

See the [full agent README](https://www.npmjs.com/package/@qa-gentic/stlc-agents) for installation and MCP configuration.

---

## License

MIT
