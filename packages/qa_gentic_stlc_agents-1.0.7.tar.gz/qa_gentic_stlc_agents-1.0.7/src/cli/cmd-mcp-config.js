/**
 * cmd-mcp-config.js — `qa-stlc mcp-config`
 *
 * Generates .mcp.json (Claude Code) or .vscode/mcp.json (GitHub Copilot / VS Code).
 */
"use strict";

const path     = require("path");
const fs       = require("fs");
const { spawnSync } = require("child_process");

const C = {
  reset: "\x1b[0m", bold: "\x1b[1m",
  green: "\x1b[32m", cyan: "\x1b[36m",
  yellow: "\x1b[33m", red: "\x1b[31m", dim: "\x1b[2m",
};
const ok   = (m) => console.log(`${C.green}✓${C.reset}  ${m}`);
const info = (m) => console.log(`${C.cyan}→${C.reset}  ${m}`);
const warn = (m) => console.log(`${C.yellow}⚠${C.reset}  ${m}`);

const os   = require("os");
const fs_  = fs;  // alias — fs already required above

const PREF_FILE_MCP = require("path").join(os.homedir(), ".qa-stlc", "integration");

function readIntegrationPref() {
  try {
    if (fs_.existsSync(PREF_FILE_MCP))
      return fs_.readFileSync(PREF_FILE_MCP, "utf8").trim();
  } catch (_) {}
  return "ado";
}

const CWD = process.cwd();
const IS_WIN = process.platform === "win32";
const EXT = IS_WIN ? ".exe" : "";

const AGENT_NAMES = [
  "qa-test-case-manager",
  "qa-gherkin-generator",
  "qa-playwright-generator",
  "qa-helix-writer",
];

// Jira agent — added separately because it needs env var injection
const JIRA_AGENT_NAME = "qa-jira-manager";
const JIRA_ENV_VARS = {
  JIRA_CLIENT_ID:     "${env:JIRA_CLIENT_ID}",
  JIRA_CLIENT_SECRET: "${env:JIRA_CLIENT_SECRET}",
  JIRA_CLOUD_ID:      "${env:JIRA_CLOUD_ID}",
};

/**
 * Locate the binary for an agent.
 * Priority: .venv → --python dir → system PATH → python sys.executable dir → macOS framework dirs
 */
function findBinary(name, pythonBin) {
  // 1. .venv in cwd
  const venvBin = IS_WIN
    ? path.join(CWD, ".venv", "Scripts", name + EXT)
    : path.join(CWD, ".venv", "bin", name);
  if (fs.existsSync(venvBin)) return venvBin;

  // 2. dir of --python flag binary
  if (pythonBin && pythonBin !== "python3" && pythonBin !== "python") {
    const candidate = path.join(path.dirname(pythonBin), name + EXT);
    if (fs.existsSync(candidate)) return candidate;
  }

  // 3. system PATH via which/where
  const which = spawnSync(IS_WIN ? "where" : "which", [name], { encoding: "utf8" });
  if (which.status === 0 && which.stdout.trim()) return which.stdout.trim().split("\n")[0].trim();

  // 4. ask Python where its own bin dir is (catches framework installs not on PATH)
  for (const py of ["python3", "python"]) {
    const r = spawnSync(py, ["-c", "import sys, os; print(os.path.dirname(sys.executable))"], { encoding: "utf8" });
    if (r.status === 0 && r.stdout.trim()) {
      const candidate = path.join(r.stdout.trim(), name + EXT);
      if (fs.existsSync(candidate)) return candidate;
    }
  }

  // 5. macOS Python.org framework fallback
  if (!IS_WIN) {
    const frameworkDirs = [
      "/Library/Frameworks/Python.framework/Versions/3.13/bin",
      "/Library/Frameworks/Python.framework/Versions/3.12/bin",
      "/Library/Frameworks/Python.framework/Versions/3.11/bin",
      "/Library/Frameworks/Python.framework/Versions/3.10/bin",
    ];
    for (const dir of frameworkDirs) {
      const candidate = path.join(dir, name);
      if (fs.existsSync(candidate)) return candidate;
    }
  }

  return null;
}

function buildClaudeConfig(pythonBin, playwrightPort, integration) {
  const servers = {};
  const missing = [];
  const needsAdo  = !integration || integration === "ado"  || integration === "both";
  const needsJira = integration === "jira" || integration === "both";

  // ADO agents — always included for ado/both; also included for jira because
  // qa-gherkin-generator, qa-playwright-generator, and qa-helix-writer are shared
  // by the Jira pipeline (Gherkin → Playwright → Helix steps run the same agents).
  const activeNames = (needsAdo || needsJira) ? AGENT_NAMES : [];

  for (const name of activeNames) {
    const bin = findBinary(name, pythonBin);
    if (bin) {
      servers[name] = { command: bin };
    } else {
      missing.push(name);
      servers[name] = { command: `/path/to/.venv/bin/${name}`, "_comment": "NOT FOUND — run: pip install qa-gentic-stlc-agents" };
    }
  }

  // Jira agent — only when integration includes jira
  if (needsJira) {
    const jiraBin = findBinary(JIRA_AGENT_NAME, pythonBin);
    if (jiraBin) {
      servers[JIRA_AGENT_NAME] = { command: jiraBin, env: JIRA_ENV_VARS };
    } else {
      missing.push(JIRA_AGENT_NAME);
      servers[JIRA_AGENT_NAME] = {
        command: `/path/to/.venv/bin/${JIRA_AGENT_NAME}`,
        env: JIRA_ENV_VARS,
        "_comment": "NOT FOUND — run: pip install qa-gentic-stlc-agents",
      };
    }
  }

  servers["playwright"] = {
    type: "url",
    url: `ws://localhost:${playwrightPort}`,
  };

  return { config: { mcpServers: servers }, missing };
}

function buildVscodeConfig(pythonBin, playwrightPort, integration) {
  const servers = {};
  const missing = [];
  const needsAdo  = !integration || integration === "ado"  || integration === "both";
  const needsJira = integration === "jira" || integration === "both";
  // Shared agents (Gherkin, Playwright, Helix) are needed by both ADO and Jira pipelines.
  const activeNames = (needsAdo || needsJira) ? AGENT_NAMES : [];

  for (const name of activeNames) {
    const bin = findBinary(name, pythonBin);
    if (bin) {
      servers[name] = { command: bin };
    } else {
      missing.push(name);
      servers[name] = { command: `/path/to/.venv/bin/${name}`, "_comment": "NOT FOUND — run: pip install qa-gentic-stlc-agents" };
    }
  }

  // Jira agent — only when integration includes jira
  if (needsJira) {
    const jiraBinV = findBinary(JIRA_AGENT_NAME, pythonBin);
    if (jiraBinV) {
      servers[JIRA_AGENT_NAME] = { command: jiraBinV, env: JIRA_ENV_VARS };
    } else {
      missing.push(JIRA_AGENT_NAME);
      servers[JIRA_AGENT_NAME] = {
        command: `/path/to/.venv/bin/${JIRA_AGENT_NAME}`,
        env: JIRA_ENV_VARS,
        "_comment": "NOT FOUND — run: pip install qa-gentic-stlc-agents",
      };
    }
  }

  servers["playwright"] = {
    type: "http",
    url: `http://localhost:${playwrightPort}/mcp`,
  };

  return { config: { servers }, missing };
}

function printNextSteps(mode, playwrightPort) {
  const isVscode = mode === "vscode";
  console.log(`
  ${C.dim}Start Playwright MCP before running generation workflows:${C.reset}
  npx @playwright/mcp@latest --port ${playwrightPort}
  ${C.dim}headless (CI): npx @playwright/mcp@latest --headless --port ${playwrightPort}${C.reset}

  ${isVscode
    ? `Reload VS Code window — all 5 MCP servers will appear in the MCP panel.`
    : `In Claude Code, run /mcp to verify all 5 servers are loaded.`
  }
`);
}

module.exports = async function mcpConfig(opts) {
  const useVscode      = opts.vscode || false;
  const printOnly      = opts.print  || false;
  const pythonBin      = opts.python || "python3";
  const playwrightPort = opts.playwrightPort || "8931";
  const integration    = (opts.integration || readIntegrationPref() || "ado").toLowerCase();

  if (printOnly) {
    const { config: claudeCfg } = buildClaudeConfig(pythonBin, playwrightPort, integration);
    const { config: vscodeCfg } = buildVscodeConfig(pythonBin, playwrightPort, integration);
    console.log("\n=== Claude Code (.mcp.json) ===");
    console.log(JSON.stringify(claudeCfg, null, 2));
    console.log("\n=== VS Code (.vscode/mcp.json) ===");
    console.log(JSON.stringify(vscodeCfg, null, 2));
    printNextSteps("both", playwrightPort);
    return;
  }

  if (useVscode) {
    const { config, missing } = buildVscodeConfig(pythonBin, playwrightPort, integration);
    const dir = path.join(CWD, ".vscode");
    fs.mkdirSync(dir, { recursive: true });
    const out = path.join(dir, "mcp.json");
    fs.writeFileSync(out, JSON.stringify(config, null, 2) + "\n", "utf8");
    ok(`Written → .vscode/mcp.json`);
    if (missing.length) {
      warn(`${missing.length} agent(s) not found — run: pip install qa-gentic-stlc-agents`);
      missing.forEach((m) => warn(`  missing: ${m}`));
    }
    printNextSteps("vscode", playwrightPort);
  } else {
    const { config, missing } = buildClaudeConfig(pythonBin, playwrightPort, integration);
    const out = path.join(CWD, ".mcp.json");
    fs.writeFileSync(out, JSON.stringify(config, null, 2) + "\n", "utf8");
    ok(`Written → .mcp.json`);
    if (missing.length) {
      warn(`${missing.length} agent(s) not found — run: pip install qa-gentic-stlc-agents`);
      missing.forEach((m) => warn(`  missing: ${m}`));
    }
    printNextSteps("claude", playwrightPort);
  }
};