/**
 * prompt-integration.js — Interactive integration picker
 *
 * Presents a numbered menu asking the user which integration(s) they want:
 *   1. Azure DevOps only  (Agents 1–4)
 *   2. Jira Cloud only    (Full pipeline: qa-jira-manager + shared Agents 2–4)
 *   3. Both
 *
 * Works in interactive terminals (TTY). Falls back to a default (ado) when
 * stdin is not a TTY (e.g. CI, piped installs) — callers can override the
 * default via the `fallback` argument.
 *
 * Returns a Promise that resolves to: "ado" | "jira" | "both"
 *
 * Usage:
 *   const pickIntegration = require("./prompt-integration");
 *   const integration = await pickIntegration();  // "ado" | "jira" | "both"
 */
"use strict";

const readline = require("readline");

const C = {
  reset: "\x1b[0m", bold: "\x1b[1m",
  green: "\x1b[32m", cyan: "\x1b[36m",
  yellow: "\x1b[33m", dim: "\x1b[2m", blue: "\x1b[34m",
};

const MENU = `
${C.bold}Which project management integration do you need?${C.reset}

  ${C.cyan}1${C.reset}  ${C.bold}Azure DevOps${C.reset}   ${C.dim}(Agents 1–4: test cases, Gherkin, Playwright, Helix-QA)${C.reset}
  ${C.cyan}2${C.reset}  ${C.bold}Jira Cloud${C.reset}     ${C.dim}(Full pipeline: fetch issues → test cases → Gherkin → Playwright → Helix-QA)${C.reset}
  ${C.cyan}3${C.reset}  ${C.bold}Both${C.reset}           ${C.dim}(All five agents — use ADO and Jira side by side)${C.reset}

  ${C.dim}Tip: you can change this later with  qa-stlc init --integration <ado|jira|both>${C.reset}

Enter 1, 2, or 3 [default: 1]: `;

const CHOICES = { "1": "ado", "2": "jira", "3": "both", "": "ado" };

/**
 * @param {string} [fallback="ado"] - Value to return when stdin is not a TTY.
 * @returns {Promise<"ado"|"jira"|"both">}
 */
module.exports = function pickIntegration(fallback = "ado") {
  // Non-interactive environment — skip the prompt entirely
  if (!process.stdin.isTTY) {
    console.log(
      `${C.dim}→  Non-interactive install — defaulting to integration: ${C.reset}${C.bold}${fallback}${C.reset}`
    );
    console.log(
      `${C.dim}   To change, run:  qa-stlc init --integration <ado|jira|both>${C.reset}\n`
    );
    return Promise.resolve(fallback);
  }

  return new Promise((resolve) => {
    const rl = readline.createInterface({
      input:  process.stdin,
      output: process.stdout,
    });

    function ask() {
      rl.question(MENU, (answer) => {
        const trimmed = answer.trim();
        const choice  = CHOICES[trimmed];

        if (choice) {
          rl.close();
          const label = choice === "ado"  ? "Azure DevOps"
                      : choice === "jira" ? "Jira Cloud"
                      :                     "Azure DevOps + Jira Cloud";
          console.log(`\n${C.green}✓${C.reset}  Integration selected: ${C.bold}${label}${C.reset}\n`);
          resolve(choice);
        } else {
          console.log(
            `${C.yellow}  Please enter 1, 2, or 3.${C.reset}`
          );
          ask();
        }
      });
    }

    ask();
  });
};