#!/usr/bin/env bash
# install-skills.sh — Install QA STLC Agent skills into a coding agent
#
# Usage:
#   ./scripts/install-skills.sh               # Claude Code (.claude/skills/)
#   ./scripts/install-skills.sh vscode        # VS Code (.github/copilot-instructions/)
#   ./scripts/install-skills.sh print         # Print skill paths only
#
# Equivalent to: npx skills add https://github.com/your-org/stlc-agents

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
SKILLS_DIR="$ROOT_DIR/skills"

TARGET="${1:-claude}"
INTEGRATION="${2:-ado}"

# Skill directory names (spec layout: skills/<name>/SKILL.md)
ADO_SKILLS="generate-test-cases generate-gherkin generate-playwright-code write-helix-files deduplication-protocol"
JIRA_SKILLS="qa-jira-manager generate-gherkin generate-playwright-code write-helix-files deduplication-protocol"
BOTH_SKILLS="generate-test-cases qa-jira-manager generate-gherkin generate-playwright-code write-helix-files deduplication-protocol"

case "$INTEGRATION" in
  jira) SKILL_LIST="$JIRA_SKILLS" ;;
  both) SKILL_LIST="$BOTH_SKILLS" ;;
  *)    SKILL_LIST="$ADO_SKILLS"  ;;
esac

case "$TARGET" in
  vscode)
    # Flat copy: SKILL.md → <name>.md
    DEST="$PWD/.github/copilot-instructions"
    mkdir -p "$DEST"
    cp "$SKILLS_DIR/AGENT-BEHAVIOR.md" "$DEST/"
    for d in $SKILL_LIST; do
      cp "$SKILLS_DIR/$d/SKILL.md" "$DEST/$d.md"
    done
    echo "✓ Skills installed to $DEST (integration=$INTEGRATION)"
    echo "  Add to .github/copilot-instructions.md: @.github/copilot-instructions/AGENT-BEHAVIOR.md"
    ;;
  print)
    echo "Available skills (integration=$INTEGRATION):"
    for d in $SKILL_LIST; do
      echo "  $d/SKILL.md"
    done
    echo "  AGENT-BEHAVIOR.md"
    ;;
  *)
    # Default: Claude Code — copy entire skill dir (preserves references/)
    DEST="$PWD/.claude/skills"
    mkdir -p "$DEST"
    cp "$SKILLS_DIR/AGENT-BEHAVIOR.md" "$PWD/.claude/"
    for d in $SKILL_LIST; do
      cp -r "$SKILLS_DIR/$d" "$DEST/"
    done
    echo "✓ Skills installed to $DEST (integration=$INTEGRATION)"
    echo ""
    echo "Skills available:"
    for d in $SKILL_LIST; do
      echo "  • $d/SKILL.md"
    done
    ;;
esac
