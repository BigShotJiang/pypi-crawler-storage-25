# wexample-app

Version: 0.0.72

Helpers for building Python app or cli.

## Table of Contents

- [Status Compatibility](#status-compatibility)
- [Installation](#installation)
- [Quickstart](#quickstart)
- [Basic Usage](#basic-usage)
- [Examples](#examples)
- [Tests](#tests)
- [Roadmap](#roadmap)
- [Useful Links](#useful-links)


## Status & Compatibility

**Maturity**: Production-ready

**Python Support**: >=3.10

**OS Support**: Linux, macOS, Windows

**Status**: Actively maintained

## Installation

```bash
pip install wexample-app
```

## Quickstart

Get started with **wexample-app** in seconds:

```python
# Your first example with wexample-app
from wexample-app import YourClass

# Initialize and use
instance = YourClass()
instance.run()
```

This package requires Python >=3.10.

## Basic Usage

```python
from wexample_helpers.decorator.base_class import base_class

from wexample_app.common.abstract_kernel import AbstractKernel
from wexample_app.common.mixins.command_line_kernel import CommandLineKernel
from wexample_app.common.mixins.command_runner_kernel import CommandRunnerKernel

@base_class
class MyApp(CommandRunnerKernel, CommandLineKernel, AbstractKernel):
    pass

my_app = MyApp()
```

## Additional Examples

### Advanced Usage

```python
from wexample-app import AdvancedFeature

# Advanced example
feature = AdvancedFeature(config={'option': 'value'})
result = feature.execute()
```

More examples can be found in the `examples/` directory of the repository.

## Tests

This project uses `pytest` for testing and `pytest-cov` for code coverage analysis.

### Installation

First, install the required testing dependencies:
```bash
.venv/bin/python -m pip install pytest pytest-cov
```

### Basic Usage

Run all tests with coverage:
```bash
.venv/bin/python -m pytest --cov --cov-report=html
```

### Common Commands
```bash
# Run tests with coverage for a specific module
.venv/bin/python -m pytest --cov=your_module

# Show which lines are not covered
.venv/bin/python -m pytest --cov=your_module --cov-report=term-missing

# Generate an HTML coverage report
.venv/bin/python -m pytest --cov=your_module --cov-report=html

# Combine terminal and HTML reports
.venv/bin/python -m pytest --cov=your_module --cov-report=term-missing --cov-report=html

# Run specific test file with coverage
.venv/bin/python -m pytest tests/test_file.py --cov=your_module --cov-report=term-missing
```

### Viewing HTML Reports

After generating an HTML report, open `htmlcov/index.html` in your browser to view detailed line-by-line coverage information.

### Coverage Threshold

To enforce a minimum coverage percentage:
```bash
.venv/bin/python -m pytest --cov=your_module --cov-fail-under=80
```

This will cause the test suite to fail if coverage drops below 80%.

## Known Limitations & Roadmap

Current limitations and planned features are tracked in the GitHub issues.

See the [project roadmap](https://github.com/wexample/python-app/issues) for upcoming features and improvements.

## Useful Links

- **Homepage**: https://github.com/wexample/python-app
- **Documentation**: [docs.wexample.com](https://docs.wexample.com)
- **Issue Tracker**: https://github.com/wexample/python-app/issues
- **Discussions**: https://github.com/wexample/python-app/discussions
- **PyPI**: [pypi.org/project/wexample-app](https://pypi.org/project/wexample-app/)

