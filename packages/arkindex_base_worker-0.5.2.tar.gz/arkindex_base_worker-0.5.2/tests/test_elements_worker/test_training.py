import logging
import sys

import pytest

from arkindex_worker.worker import BaseWorker
from arkindex_worker.worker.training import TrainingMixin, create_archive


@pytest.fixture
def mock_training_worker(monkeypatch, setup_mock_api_client):
    class TrainingWorker(BaseWorker, TrainingMixin):
        """
        This class is needed to run tests in the context of a training worker
        """

    monkeypatch.setattr(sys, "argv", ["worker"])
    training_worker = TrainingWorker()
    training_worker.args = training_worker.parser.parse_args()
    return training_worker


@pytest.fixture
def default_model_version():
    return {
        "id": "model_version_id",
        "model_id": "model_id",
        "parent": "42" * 16,
        "description": "A description",
        "tag": "A simple tag",
        "state": "created",
        "size": 42,
        "archive_hash": "123456789",
        "configuration": {"test": "value"},
        "s3_etag": None,
        "s3_put_url": "http://upload.archive",
        "s3_url": None,
        "created": "2000-01-01T00:00:00Z",
    }


def test_create_archive(model_file_dir):
    """Create an archive with all base attributes"""

    with create_archive(path=model_file_dir) as (
        zst_archive_path,
        size,
        hash,
    ):
        assert zst_archive_path.exists(), "The archive was not created"
        assert len(hash) == 32
        assert 300 < size < 700

    assert not zst_archive_path.exists(), "Auto removal failed"


def test_create_archive_with_subfolder(model_file_dir_with_subfolder):
    """Create an archive when the model's file is in a folder containing a subfolder"""

    with create_archive(path=model_file_dir_with_subfolder) as (
        zst_archive_path,
        size,
        hash,
    ):
        assert zst_archive_path.exists(), "The archive was not created"
        assert len(hash) == 32
        assert 300 < size < 1500

    assert not zst_archive_path.exists(), "Auto removal failed"


@pytest.mark.parametrize(
    "method",
    [
        "publish_model_version",
        "create_model_version",
        "update_model_version",
        "upload_to_s3",
    ],
)
def test_training_mixin_read_only(mock_training_worker, method, caplog):
    """All operations related to models versions returns early if the worker is configured as read only"""
    # Set worker in read_only mode
    mock_training_worker.worker_run_id = None
    assert mock_training_worker.is_read_only

    assert mock_training_worker.model_version is None
    getattr(mock_training_worker, method)()
    assert mock_training_worker.model_version is None
    assert [(level, message) for _, level, message in caplog.record_tuples] == [
        (
            logging.WARNING,
            "Cannot perform this operation as the worker is in read-only mode",
        ),
    ]


def test_create_model_version_already_created(mock_training_worker):
    mock_training_worker.model_version = {"id": "model_version_id"}
    with pytest.raises(
        AssertionError, match="A model version has already been created."
    ):
        mock_training_worker.create_model_version(
            model_id="model_id", size=42, archive_hash="123456789"
        )


@pytest.mark.parametrize("set_tag", [True, False])
def test_create_model_version(mock_training_worker, default_model_version, set_tag):
    args = {
        "size": 42,
        "archive_hash": "123456789",
        "parent": "42" * 16,
        "tag": "A simple tag",
        "description": "A description",
        "configuration": {"test": "value"},
    }
    if not set_tag:
        del args["tag"]
        default_model_version["tag"] = None
    mock_training_worker.api_client.add_response(
        "CreateModelVersion",
        id="model_id",
        response=default_model_version,
        body=args,
    )
    assert mock_training_worker.model_version is None
    mock_training_worker.create_model_version(model_id="model_id", **args)
    assert mock_training_worker.model_version == default_model_version


def test_update_model_version_not_created(mock_training_worker):
    with pytest.raises(AssertionError, match="No model version has been created yet."):
        mock_training_worker.update_model_version(size=42, archive_hash="123456789")


def test_update_model_version(mock_training_worker, default_model_version):
    mock_training_worker.model_version = default_model_version
    args = {"size": 42, "archive_hash": "123456789", "tag": "A new tag"}
    new_model_version = {**default_model_version, "tag": "A new tag"}
    mock_training_worker.api_client.add_response(
        "UpdateModelVersion",
        id="model_version_id",
        response=new_model_version,
        body=args,
    )
    mock_training_worker.update_model_version(**args)
    assert mock_training_worker.model_version == new_model_version
