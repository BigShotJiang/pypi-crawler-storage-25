"""
ElementsWorker methods for transcriptions.
"""

from collections.abc import Iterable
from enum import Enum
from warnings import warn

from arkindex_worker import logger
from arkindex_worker.models import Element
from arkindex_worker.utils import DEFAULT_BATCH_SIZE, batch_publication, make_batches


class TextOrientation(Enum):
    """
    Orientation of a transcription's text.
    """

    HorizontalLeftToRight = "horizontal-lr"
    """
    The text is read from top to bottom then left to right.
    This is the default when no orientation is specified.
    """

    HorizontalRightToLeft = "horizontal-rl"
    """
    The text is read from top to bottom then right to left.
    """

    VerticalRightToLeft = "vertical-rl"
    """
    The text is read from right to left then top to bottom.
    """

    VerticalLeftToRight = "vertical-lr"
    """
    The text is read from left to right then top to bottom.
    """


class TranscriptionMixin:
    def create_transcription(
        self,
        element: Element,
        text: str,
        confidence: float,
        orientation: TextOrientation = TextOrientation.HorizontalLeftToRight,
    ) -> dict[str, str | float] | None:
        """
        Create a transcription on the given element through the API.

        :param element: Element to create a transcription on.
        :param text: Text of the transcription.
        :param confidence: Confidence score, between 0 and 1.
        :param orientation: Orientation of the transcription's text.
        :returns: A dict as returned by the ``CreateTranscription`` API endpoint,
           or None if the worker is in read-only mode.
        """
        assert element and isinstance(element, Element), (
            "element shouldn't be null and should be an Element"
        )
        assert text and isinstance(text, str), (
            "text shouldn't be null and should be of type str"
        )
        assert orientation and isinstance(orientation, TextOrientation), (
            "orientation shouldn't be null and should be of type TextOrientation"
        )
        assert isinstance(confidence, float) and 0 <= confidence <= 1, (
            "confidence shouldn't be null and should be a float in [0..1] range"
        )

        if self.is_read_only:
            logger.warning(
                "Cannot create transcription as this worker is in read-only mode"
            )
            return

        return self.api_client.request(
            "CreateTranscription",
            id=element.id,
            body={
                "text": text,
                "worker_run_id": self.worker_run_id,
                "confidence": confidence,
                "orientation": orientation.value,
            },
        )

    @batch_publication
    def create_transcriptions(
        self,
        transcriptions: list[dict[str, str | float | TextOrientation | None]],
        batch_size: int = DEFAULT_BATCH_SIZE,
    ) -> list[dict[str, str | float]]:
        """
        Create multiple transcriptions at once on existing elements through the API.

        :param transcriptions: A list of dicts representing a transcription each, with the following keys:

            element_id (str)
                Required. UUID of the element to create this transcription on.
            text (str)
                Required. Text of the transcription.
            confidence (float)
                Required. Confidence score between 0 and 1.
            orientation (TextOrientation)
                Optional. Orientation of the transcription's text.

        :param batch_size: The size of each batch, which will be used to split the publication to avoid API errors.

        :returns: A list of dicts as returned in the ``transcriptions`` field by the ``CreateTranscriptions`` API endpoint.
        """

        assert transcriptions and isinstance(transcriptions, list), (
            "transcriptions shouldn't be null and should be of type list"
        )

        # Create shallow copies of every transcription to avoid mutating the original payload
        transcriptions_payload = list(map(dict, transcriptions))

        for index, transcription in enumerate(transcriptions_payload):
            element_id = transcription.get("element_id")
            assert element_id and isinstance(element_id, str), (
                f"Transcription at index {index} in transcriptions: element_id shouldn't be null and should be of type str"
            )

            text = transcription.get("text")
            assert text and isinstance(text, str), (
                f"Transcription at index {index} in transcriptions: text shouldn't be null and should be of type str"
            )

            confidence = transcription.get("confidence")
            assert (
                confidence is not None
                and isinstance(confidence, float)
                and 0 <= confidence <= 1
            ), (
                f"Transcription at index {index} in transcriptions: confidence shouldn't be null and should be a float in [0..1] range"
            )

            orientation = transcription.get(
                "orientation", TextOrientation.HorizontalLeftToRight
            )
            assert orientation and isinstance(orientation, TextOrientation), (
                f"Transcription at index {index} in transcriptions: orientation shouldn't be null and should be of type TextOrientation"
            )
            if orientation:
                transcription["orientation"] = orientation.value

        if self.is_read_only:
            logger.warning(
                "Cannot create transcription as this worker is in read-only mode"
            )
            return

        return [
            created_tr
            for batch in make_batches(
                transcriptions_payload, "transcription", batch_size
            )
            for created_tr in self.api_client.request(
                "CreateTranscriptions",
                body={
                    "worker_run_id": self.worker_run_id,
                    "transcriptions": batch,
                },
            )["transcriptions"]
        ]

    @batch_publication
    def create_element_transcriptions(
        self,
        element: Element,
        sub_element_type: str,
        transcriptions: list[dict[str, str | float]],
        batch_size: int = DEFAULT_BATCH_SIZE,
    ) -> dict[str, str | bool]:
        """
        Create multiple elements and transcriptions at once on a single parent element through the API.

        :param element: Element to create elements and transcriptions on.
        :param sub_element_type: Slug of the element type to use for the new elements.
        :param transcriptions: A list of dicts representing an element and transcription each, with the following keys:

            polygon (list(list(int or float)))
                Required. Polygon of the element.
            text (str)
                Required. Text of the transcription.
            confidence (float)
                Required. Confidence score between 0 and 1.
            orientation ([TextOrientation][arkindex_worker.worker.transcription.TextOrientation])
                Optional. Orientation of the transcription's text.
            element_confidence (float)
                Optional. Confidence score of the element between 0 and 1.

        :param batch_size: The size of each batch, which will be used to split the publication to avoid API errors.

        :returns: A list of dicts as returned by the ``CreateElementTranscriptions`` API endpoint.
        """
        assert element and isinstance(element, Element), (
            "element shouldn't be null and should be an Element"
        )
        assert sub_element_type and isinstance(sub_element_type, str), (
            "sub_element_type shouldn't be null and should be of type str"
        )
        assert transcriptions and isinstance(transcriptions, list), (
            "transcriptions shouldn't be null and should be of type list"
        )

        # Create shallow copies of every transcription to avoid mutating the original payload
        transcriptions_payload = list(map(dict, transcriptions))

        for index, transcription in enumerate(transcriptions_payload):
            text = transcription.get("text")
            assert text and isinstance(text, str), (
                f"Transcription at index {index} in transcriptions: text shouldn't be null and should be of type str"
            )

            confidence = transcription.get("confidence")
            assert (
                confidence is not None
                and isinstance(confidence, float)
                and 0 <= confidence <= 1
            ), (
                f"Transcription at index {index} in transcriptions: confidence shouldn't be null and should be a float in [0..1] range"
            )

            orientation = transcription.get(
                "orientation", TextOrientation.HorizontalLeftToRight
            )
            assert orientation and isinstance(orientation, TextOrientation), (
                f"Transcription at index {index} in transcriptions: orientation shouldn't be null and should be of type TextOrientation"
            )
            if orientation:
                transcription["orientation"] = orientation.value

            polygon = transcription.get("polygon")
            assert polygon and isinstance(polygon, list), (
                f"Transcription at index {index} in transcriptions: polygon shouldn't be null and should be of type list"
            )
            assert len(polygon) >= 3, (
                f"Transcription at index {index} in transcriptions: polygon should have at least three points"
            )
            assert all(
                isinstance(point, list) and len(point) == 2 for point in polygon
            ), (
                f"Transcription at index {index} in transcriptions: polygon points should be lists of two items"
            )
            assert all(
                isinstance(coord, int | float) for point in polygon for coord in point
            ), (
                f"Transcription at index {index} in transcriptions: polygon points should be lists of two numbers"
            )

            element_confidence = transcription.get("element_confidence")
            assert element_confidence is None or (
                isinstance(element_confidence, float) and 0 <= element_confidence <= 1
            ), (
                f"Transcription at index {index} in transcriptions: element_confidence should be either null or a float in [0..1] range"
            )

        if self.is_read_only:
            logger.warning(
                "Cannot create transcriptions as this worker is in read-only mode"
            )
            return

        annotations = [
            annotation
            for batch in make_batches(
                transcriptions_payload, "transcription", batch_size
            )
            for annotation in self.api_client.request(
                "CreateElementTranscriptions",
                id=element.id,
                body={
                    "element_type": sub_element_type,
                    "worker_run_id": self.worker_run_id,
                    "transcriptions": batch,
                    "return_elements": True,
                },
            )
        ]

        for annotation in annotations:
            if annotation["created"]:
                logger.debug(
                    f"A sub_element of {element.id} with type {sub_element_type} was created during transcriptions bulk creation"
                )

        return annotations

    def list_transcriptions(
        self,
        element: Element,
        element_type: str | None = None,
        recursive: bool | None = None,
        worker_version: str | bool | None = None,
        worker_run: str | bool | None = None,
    ) -> Iterable[dict]:
        """
        List transcriptions on an element.

        Warns:
        ----
        The following parameters are **deprecated**:

        - `worker_version` in favor of `worker_run`

        :param element: The element to list transcriptions on.
        :param element_type: Restrict to transcriptions whose elements have an element type with this slug.
        :param recursive: Include transcriptions of any descendant of this element, recursively.
        :param worker_version: **Deprecated** Restrict to transcriptions created by a worker version with this UUID. Set to False to look for manually created transcriptions.
        :param worker_run: Restrict to transcriptions created by a worker run with this UUID. Set to False to look for manually created transcriptions.
        :returns: An iterable of dicts representing each transcription.
        """
        assert element and isinstance(element, Element), (
            "element shouldn't be null and should be an Element"
        )
        query_params = {}
        if element_type:
            assert isinstance(element_type, str), "element_type should be of type str"
            query_params["element_type"] = element_type
        if recursive is not None:
            assert isinstance(recursive, bool), "recursive should be of type bool"
            query_params["recursive"] = recursive
        if worker_version is not None:
            warn(
                "`worker_version` usage is deprecated. Consider using `worker_run` instead.",
                DeprecationWarning,
                stacklevel=1,
            )
            assert isinstance(worker_version, str | bool), (
                "worker_version should be of type str or bool"
            )
            if isinstance(worker_version, bool):
                assert worker_version is False, (
                    "if of type bool, worker_version can only be set to False"
                )
            query_params["worker_version"] = worker_version
        if worker_run is not None:
            assert isinstance(worker_run, str | bool), (
                "worker_run should be of type str or bool"
            )
            if isinstance(worker_run, bool):
                assert worker_run is False, (
                    "if of type bool, worker_run can only be set to False"
                )
            query_params["worker_run"] = worker_run

        return self.api_client.paginate(
            "ListTranscriptions", id=element.id, **query_params
        )
