# Compressors

Compressors is a library of containing flexible implementations of state-of-the-art compression systems.

[Documentation](https://danjacobellis.net/compressors)

`pip install compressors`
