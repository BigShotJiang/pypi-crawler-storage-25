---
name: traia-iatp
description: >-
  Use the traia-iatp CLI to add d402 payments to MCP servers, create and deploy
  IATP wallets on Arbitrum One, generate paid MCP server repos, test paid tool
  calls, and register deployed servers on d402.net. Use when the user asks about
  d402 payments, IATP wallets, MCP server monetisation, create-mcp, create-iatp-wallet,
  register-mcp, test-mcp, or any traia-iatp command.
---

# traia-iatp CLI Skill

`traia-iatp` adds HTTP 402 / d402 payment gating to MCP servers.

## Key concepts

- **Server wallet** — the MCP server's on-chain IATP wallet. Receives payments.
  Produced by `create-mcp` (automatically) or reused with `--server-address`.
- **Client wallet** — the caller's on-chain IATP wallet. Pays for tool calls.
  Produced by `create-iatp-wallet --wallet-type CLIENT`.
- These are **separate wallets**. Never mix them up.
- Network: `arbitrum_one` only (production).
- Tokens: `USDC` (`payment_token_id=1`) or `USDT` (`payment_token_id=2`).

---

## Workflow A — local testing (fastest path)

### 1. Create the client wallet (once, reuse across tests)

```bash
# Option A — owner pays gas
traia-iatp create-iatp-wallet \
  --owner-key 0xFUNDED_PRIVATE_KEY \
  --wallet-name "My Client Wallet" \
  --wallet-type CLIENT

# Option B — maintainer pays gas (generates fresh owner wallet)
traia-iatp create-iatp-wallet \
  --maintainer-key 0xFUNDED_PRIVATE_KEY \
  --wallet-name "My Client Wallet" \
  --wallet-type CLIENT
```

Output keys you need:
- `operatorPrivateKey` → `CLIENT_OPERATOR_PRIVATE_KEY`
- `iatpWalletAddress`  → `CLIENT_WALLET_ADDRESS`

Fund `iatpWalletAddress` with USDC (or USDT) before testing.

### 2. Generate the MCP server repo

Requires a wallet config. Choose one of three options:

```bash
# Option A — owner pays gas (creates a new server wallet on-chain)
traia-iatp create-mcp \
  --name "My API" \
  --api-url "https://api.example.com" \
  --price-usd 0.01 \
  --endpoints-file ./endpoints.json \
  --server-wallet-owner-key 0xFUNDED_PRIVATE_KEY

# Option B — maintainer pays gas (generates fresh server owner)
traia-iatp create-mcp \
  --name "My API" \
  --api-url "https://api.example.com" \
  --price-usd 0.01 \
  --endpoints-file ./endpoints.json \
  --maintainer-key 0xFUNDED_PRIVATE_KEY

# Option C — reuse an existing wallet (no on-chain call)
traia-iatp create-mcp \
  --name "My API" \
  --api-url "https://api.example.com" \
  --price-usd 0.01 \
  --endpoints-file ./endpoints.json \
  --server-address 0xEXISTING_SERVER_WALLET \
  --operator-address 0xEXISTING_OPERATOR \
  --operator-private-key 0xEXISTING_OPERATOR_KEY
```

> **Note**: Even `--boilerplate-only` generation requires one of the three wallet
> options above. Use Option C with existing addresses to avoid an on-chain call.

`endpoints.json` format (same file reused for `register-mcp` later):

```json
[
  {
    "endpoint_name": "get_data",
    "endpoint_path": "/v1/data/{id}",
    "endpoint_method": "GET",
    "endpoint_description": "Fetch item by id",
    "payment_price_float": 0.01,
    "endpoint_input_schema": {
      "type": "object",
      "properties": {
        "id": { "type": "string", "description": "Item id" }
      },
      "required": ["id"]
    }
  }
]
```

Required fields: `endpoint_name`, `endpoint_path`, `endpoint_method`.
Optional: `endpoint_description`, `payment_price_float`, `endpoint_input_schema`, `endpoint_output_schema`.

### 3. Start the server

```bash
cd <generated-repo>
./run_local_docker.sh        # Docker
# or
uv run python server.py      # direct
```

### 4. Test a paid tool call

```bash
export CLIENT_OPERATOR_PRIVATE_KEY="0x..."   # operatorPrivateKey
export CLIENT_WALLET_ADDRESS="0x..."          # iatpWalletAddress

traia-iatp test-mcp \
  --base-url "http://localhost:8000" \
  --tool-name "get_data" \
  --arguments '{"id": "123"}'
```

For schema-based tools pass real arg names. For flag-based tools use `{"query_params": {...}}`.

---

## Workflow B — register a deployed server on d402.net

Only run this **after** deploying to a public URL and confirming every endpoint works.

### Prerequisites
- d402.net account — sign up at https://d402.net with your email.
- Same `endpoints.json` used with `create-mcp`.
- MCP server wallet addresses from the `create-mcp` output.

```bash
traia-iatp register-mcp \
  --email "you@example.com" \
  --name "My API MCP" \
  --description "What the server does" \
  --url "https://yourserver.com/mcp" \
  --server-address 0xMCP_SERVER_WALLET \
  --operator-address 0xMCP_SERVER_OPERATOR \
  --no-requires-auth \
  --token-symbol USDC \
  --endpoints-file ./endpoints.json
```

Use `--requires-auth` if the MCP server requires callers to provide an API key.
Use `--tag` (repeatable) for custom tags. Default tag: `d402`.
Use `--icon-url` to attach a server icon image URL (optional).

Token mapping: `USDC` → `payment_token_id=1`, `USDT` → `payment_token_id=2`.

---

## Other useful commands

### Generate a plain ETH keypair (no on-chain call)
```bash
traia-iatp create-eth-wallet
# Save to JSON file:
traia-iatp create-eth-wallet --output wallet.json
```
Fund the address with **0.001+ ETH** on arbitrum_one, then use it with `--owner-key`.

### Create a wallet (full control over type)
```bash
traia-iatp create-iatp-wallet \
  --owner-key 0x... \
  --wallet-name "My Server" \
  --wallet-type CLIENT    # CLIENT | HUMAN
```

### Reuse an existing server wallet with create-mcp
```bash
traia-iatp create-mcp \
  --name "..." --api-url "..." --price-usd 0.01 \
  --endpoints-file ./endpoints.json \
  --server-address 0x... \
  --operator-address 0x... \
  --operator-private-key 0x...
```

### Agency commands (discover and use paid utility agencies)
```bash
traia-iatp list-mcp-servers          # list all registered MCP servers
traia-iatp list-agencies             # list all registered utility agencies
traia-iatp search-agencies           # search for agencies by keyword
traia-iatp find-tools                # find tools for use in CrewAI
traia-iatp create-agency             # create an agency from an existing MCP server
traia-iatp deploy                    # deploy a utility agency from a generated dir
traia-iatp example-crew              # show an example CrewAI crew using agencies
```

### Print this skill
```bash
traia-iatp print-skill
```

---

## Environment variables (generated .env)

| Variable | Description |
|---|---|
| `PORT` | Server port (default `8000`) |
| `STAGE` | `MAINNET` or `TESTNET` |
| `LOG_LEVEL` | Logging level (default `INFO`) |
| `SERVER_ADDRESS` | MCP server IATP wallet address |
| `MCP_OPERATOR_PRIVATE_KEY` | MCP server operator private key |
| `MCP_OPERATOR_ADDRESS` | MCP server operator address |
| `D402_FACILITATOR_URL` | `https://facilitator.d402.net` |
| `D402_FACILITATOR_API_KEY` | Facilitator API key (optional) |
| `D402_TESTING_MODE` | `true` = verify without settlement, `false` = full settlement |
| `DEFAULT_SETTLEMENT_TOKEN` | On-chain token contract address (e.g. USDC on Arbitrum) |
| `DEFAULT_SETTLEMENT_NETWORK` | Settlement network (default `arbitrum_one`) |
| `NETWORK` | Active network (default `arbitrum_one`) |
| `ARBITRUM_ONE_RPC_URL` | Custom Arbitrum RPC URL (optional) |
| `CLIENT_OPERATOR_PRIVATE_KEY` | Client operator key (for test-mcp) |
| `CLIENT_WALLET_ADDRESS` | Client IATP wallet address (for test-mcp) |

---

## Common mistakes

| Mistake | Fix |
|---|---|
| Using client wallet address as `--server-address` in `register-mcp` | Use `iatpWalletAddress` from the `create-mcp` server wallet output, not the client |
| `D402_TESTING_MODE=true` in production | Set to `false` for production; client wallet must hold the settlement token either way |
| Wrong `--arguments` shape | Schema-based tools: `{"param": "value"}`. Flag-based tools: `{"query_params": {"param": "value"}}` |
| Registering before testing deployed URL | Always run `test-mcp --base-url https://yourserver.com` first |
| Calling `create-mcp --boilerplate-only` without a wallet config | Even boilerplate mode needs `--server-wallet-owner-key`, `--maintainer-key`, or all three of `--server-address`, `--operator-address`, `--operator-private-key` |
| Funding with too little ETH | Fund with at least **0.001 ETH** on arbitrum_one before running `create-iatp-wallet` |
