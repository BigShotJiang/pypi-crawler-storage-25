from __future__ import annotations

from pathlib import Path
from typing import Any

from ..config import (
    DEFAULT_BATCH_SIZE,
    DEFAULT_LOCK_STALE_SECONDS,
    PLUGIN_OWNER,
    PROJECTS_SUBDIR,
    build_paths,
    get_home_dir,
    is_archived_bucket,
)
from ..managed_skills.manifest import dump_manifest, load_manifest
from ..schemas import CompilerReceipt, SuggestionEnvelope
from ..storage import (
    CompileLockError,
    atomic_write_json,
    atomic_write_text,
    claim_suggestions,
    file_lock,
    finalize_suggestion,
    has_pending_work,
    list_suggestions,
    load_json,
    lock_status,
)
from .backends import build_compile_context, get_backend


def _tally_memory_actions(envelopes: list[SuggestionEnvelope]) -> dict[str, Any]:
    """Count reviewer-requested memory actions across a compile batch.

    Returns a dict with action totals and scope distribution. Populated into
    :class:`CompilerReceipt.memory_action_stats` so observability can tell
    whether the reviewer is actually using the ``replace`` / ``remove`` /
    scope-routing capabilities introduced in Phase 1 — without this, the
    receipts only report aggregate ``memory_records`` which conflates "new
    entries added" with "existing entries passed through untouched".

    Empty dict when the batch has no memory_updates; keeps legacy receipts
    that parse old schema happy.
    """
    actions: dict[str, int] = {"add": 0, "replace": 0, "remove": 0}
    by_scope: dict[str, int] = {"user": 0, "global": 0}
    total = 0
    for envelope in envelopes:
        for suggestion in envelope.suggestions:
            if suggestion.family != "memory_updates":
                continue
            total += 1
            action = str(suggestion.details.get("action") or "add").strip().lower()
            if action in actions:
                actions[action] += 1
            scope = str(suggestion.details.get("scope") or "global").strip().lower()
            if scope in by_scope:
                by_scope[scope] += 1
    if total == 0:
        return {}
    return {
        "total": total,
        "by_action": actions,
        "by_scope": by_scope,
    }


def _render_memory_markdown(title: str, records: list[dict]) -> str:
    lines = [f"# {title}", ""]
    if not records:
        lines.extend(["_No entries yet._", ""])
        return "\n".join(lines)
    for item in records:
        lines.extend([f"## {item['summary']}", "", item["content"], ""])
    return "\n".join(lines).rstrip() + "\n"


def _write_memory(memory_dir: Path, records_by_scope: dict[str, list[dict]]) -> tuple[Path, Path, Path]:
    user_path = memory_dir / "USER.md"
    global_path = memory_dir / "MEMORY.md"
    index_path = memory_dir / "memory.json"
    user_records = records_by_scope.get("user", [])
    global_records = records_by_scope.get("global", [])
    atomic_write_text(user_path, _render_memory_markdown("USER", user_records))
    atomic_write_text(global_path, _render_memory_markdown("MEMORY", global_records))
    atomic_write_json(index_path, {"user": user_records, "global": global_records})
    return user_path, global_path, index_path


def _write_recall(recall_dir: Path, records: list) -> tuple[Path, Path]:
    index_path = recall_dir / "index.json"
    markdown_path = recall_dir / "compiled.md"
    atomic_write_json(index_path, {"records": [item.to_dict() for item in records]})
    lines = ["# Compiled Recall", ""]
    for item in records:
        lines.extend([f"## {item.summary}", "", item.content, "", f"Provenance: {', '.join(item.source_paths)}", ""])
    atomic_write_text(markdown_path, "\n".join(lines).rstrip() + "\n")
    return index_path, markdown_path


def _write_skills(
    skills_dir: Path,
    compiled_skills: list[dict],
    entries: list,
    existing_entries: list | None = None,
) -> tuple[list[Path], Path]:
    managed_dir = skills_dir / "managed"
    existing_map = {entry.skill_id: entry for entry in (existing_entries or load_manifest(skills_dir / "manifest.json"))}
    written: list[Path] = []
    for item in compiled_skills:
        skill_id = item["skill_id"]
        existing = existing_map.get(skill_id)
        if item["action"] in {"patch", "edit", "retire"}:
            if existing is None or not existing.managed or existing.owner != PLUGIN_OWNER:
                raise ValueError(f"cannot modify unmanaged skill: {skill_id}")
        skill_path = managed_dir / f"{skill_id}.md"
        if item["action"] == "retire":
            content = f"# {item['title']}\n\nStatus: retired\n"
        else:
            content = f"# {item['title']}\n\n{item['content'].strip()}\n"
        atomic_write_text(skill_path, content)
        written.append(skill_path)
    manifest_path = skills_dir / "manifest.json"
    atomic_write_json(manifest_path, dump_manifest(entries))
    return written, manifest_path


def write_receipt(compiler_dir: Path, receipt: CompilerReceipt) -> Path:
    destination = compiler_dir / "last_receipt.json"
    atomic_write_json(destination, receipt.to_dict())
    return destination


def apply_compiler_outputs(
    memory_dir: Path,
    recall_dir: Path,
    skills_dir: Path,
    memory_records: dict[str, list[dict]],
    recall_records: list,
    compiled_skills: list[dict],
    manifest_entries: list,
    existing_entries: list | None = None,
) -> dict[str, tuple | list]:
    memory_paths = _write_memory(memory_dir, memory_records)
    recall_paths = _write_recall(recall_dir, recall_records)
    skill_paths = _write_skills(skills_dir, compiled_skills, manifest_entries, existing_entries=existing_entries)
    return {
        "memory": memory_paths,
        "recall": recall_paths,
        "skills": skill_paths,
    }


def preflight_compile(
    repo_root: str | Path | None = None,
    state_dir: str | Path | None = None,
    stale_after_seconds: int = DEFAULT_LOCK_STALE_SECONDS,
) -> dict:
    paths = build_paths(repo_root=repo_root, state_dir=state_dir)
    status = lock_status(paths, stale_after_seconds=stale_after_seconds)
    if status["locked"] and not status["stale"]:
        return {"status": "skip_locked", "lock": status}
    if not has_pending_work(paths):
        return {"status": "skip_empty", "pending": 0, "retryable_failed": 0}
    return {"status": "run", "lock": status, "pending": len(list_suggestions(paths, "pending"))}


def run_compile(
    repo_root: str | Path | None = None,
    state_dir: str | Path | None = None,
    batch_size: int = DEFAULT_BATCH_SIZE,
    backend: str = "script",
    allow_fallback: bool = True,
) -> dict:
    paths = build_paths(repo_root=repo_root, state_dir=state_dir)
    preflight = preflight_compile(repo_root=repo_root, state_dir=state_dir)
    if preflight["status"] != "run":
        receipt = CompilerReceipt(
            run_status=preflight["status"],
            backend=backend,
            processed_count=0,
            archived_count=0,
            memory_records=0,
            recall_records=0,
            managed_skills=0,
            skip_reason=preflight["status"],
        )
        receipt_path = write_receipt(paths.compiler_dir, receipt)
        return {"status": preflight["status"], "processed_count": 0, "receipt_path": str(receipt_path)}
    try:
        with file_lock(paths):
            claimed = claim_suggestions(paths, batch_size=batch_size)
            if not claimed:
                receipt = CompilerReceipt(
                    run_status="skip_empty",
                    backend=backend,
                    processed_count=0,
                    archived_count=0,
                    memory_records=0,
                    recall_records=0,
                    managed_skills=0,
                    skip_reason="skip_empty",
                )
                receipt_path = write_receipt(paths.compiler_dir, receipt)
                return {"status": "skip_empty", "processed_count": 0, "receipt_path": str(receipt_path)}
            envelopes = [SuggestionEnvelope.from_dict(load_json(path)) for path, _ in claimed]
            memory_action_stats = _tally_memory_actions(envelopes)
            backend_impl = get_backend(backend)
            context = build_compile_context(paths, envelopes)
            artifacts = backend_impl.compile(envelopes, context, {"allow_fallback": allow_fallback})
            apply_compiler_outputs(
                memory_dir=paths.memory_dir,
                recall_dir=paths.recall_dir,
                skills_dir=paths.skills_dir,
                memory_records=artifacts.memory_records,
                recall_records=artifacts.recall_records,
                compiled_skills=artifacts.compiled_skills,
                manifest_entries=artifacts.manifest_entries,
                existing_entries=context["existing_manifest"],
            )
            item_receipts = []
            for path, envelope in claimed:
                destination = finalize_suggestion(paths, path, envelope, "done")
                item_receipts.append({"suggestion_id": envelope.suggestion_id, "state": "done", "path": str(destination)})
            for discarded in artifacts.discarded_items:
                item_receipts.append({"state": "discarded", **discarded})
            receipt = CompilerReceipt(
                run_status="success",
                backend=artifacts.backend_name,
                processed_count=len(claimed),
                archived_count=len(claimed),
                memory_records=sum(len(items) for items in artifacts.memory_records.values()),
                recall_records=len(artifacts.recall_records),
                managed_skills=len(artifacts.compiled_skills),
                item_receipts=item_receipts,
                fallback_backend=artifacts.fallback_backend,
                memory_action_stats=memory_action_stats,
            )
            receipt_path = write_receipt(paths.compiler_dir, receipt)
            return {
                "status": "success",
                "processed_count": len(claimed),
                "receipt_path": str(receipt_path),
                "backend": artifacts.backend_name,
                "fallback_backend": artifacts.fallback_backend,
                "memory_action_stats": memory_action_stats,
                "discarded_count": len(artifacts.discarded_items),
            }
    except CompileLockError:
        receipt = CompilerReceipt(
            run_status="skip_locked",
            backend=backend,
            processed_count=0,
            archived_count=0,
            memory_records=0,
            recall_records=0,
            managed_skills=0,
            skip_reason="skip_locked",
        )
        receipt_path = write_receipt(paths.compiler_dir, receipt)
        return {"status": "skip_locked", "processed_count": 0, "receipt_path": str(receipt_path)}


def scan_all_projects(
    home: str | Path | None = None,
    backend: str = "agent:opencode",
    batch_size: int = DEFAULT_BATCH_SIZE,
    allow_fallback: bool = True,
    stale_after_seconds: int = DEFAULT_LOCK_STALE_SECONDS,
) -> dict:
    """Run preflight + compile on every per-project bucket under ``<home>/projects/``.

    Intended for the launchd scheduler: a single invocation drains every repo
    that has accumulated pending suggestions, without the user having to
    enumerate them or stand up one plist per repo (which would become
    unmaintainable as they add repos).

    Per-bucket exceptions are **isolated**: a corrupt / mid-migration / locked
    bucket surfaces as an ``error`` entry in the result list but does not stop
    the scan from processing the others. This matters because the scan runs
    unattended — a single bad bucket should not wedge the whole pipeline.

    The default ``backend="agent:opencode"`` matches where we want production
    scheduling to land (see docs/2026-04-21-ready-for-others-gap-analysis.md
    P0-5). Callers that want the deterministic script path (tests / CI) pass
    ``backend="script"`` explicitly.

    Returns a summary:

    .. code-block:: json

        {
          "home": "/home/alice/.codex-self-evolution",
          "total_projects": 3,
          "results": [
            {"project": "-home-alice-repo1",
             "state_dir": "...",
             "preflight_status": "run",
             "compile_status": "success",
             "processed_count": 5,
             "backend": "agent:opencode",
             "receipt_path": "...",
             "error": null},
            ...
          ],
          "counts": {"run": 1, "skipped": 1, "failed": 1}
        }

    Nothing is written outside the per-bucket state dirs — scan itself has no
    output store, just the aggregated return value (which the CLI prints to
    stdout for the scheduler to log).
    """
    home_dir = Path(home).expanduser().resolve() if home else get_home_dir()
    projects_dir = home_dir / PROJECTS_SUBDIR
    counts = {"run": 0, "skipped": 0, "failed": 0}
    results: list[dict] = []

    if not projects_dir.is_dir():
        # First ever launchd run on a fresh install: nothing to do, surface
        # that honestly instead of 500-ing.
        return {
            "home": str(home_dir),
            "total_projects": 0,
            "results": results,
            "counts": counts,
        }

    for bucket_path in sorted(projects_dir.iterdir()):
        if not bucket_path.is_dir():
            continue
        # Archived buckets are the tombstones left by `migrate-worktrees` after
        # a worktree consolidation. They carry historical receipts but no live
        # work — processing them would re-run compile against stale snapshots
        # and dirty the receipts, so we explicitly skip them.
        if is_archived_bucket(bucket_path.name):
            continue
        entry: dict = {
            "project": bucket_path.name,
            "state_dir": str(bucket_path),
            "preflight_status": None,
            "compile_status": "not_run",
            "processed_count": 0,
            "backend": None,
            "receipt_path": None,
            "error": None,
        }
        try:
            preflight = preflight_compile(
                state_dir=bucket_path,
                stale_after_seconds=stale_after_seconds,
            )
            entry["preflight_status"] = preflight["status"]
            if preflight["status"] != "run":
                entry["compile_status"] = preflight["status"]
                counts["skipped"] += 1
            else:
                compile_result = run_compile(
                    state_dir=bucket_path,
                    batch_size=batch_size,
                    backend=backend,
                    allow_fallback=allow_fallback,
                )
                entry["compile_status"] = compile_result["status"]
                entry["processed_count"] = compile_result.get("processed_count", 0)
                entry["backend"] = compile_result.get("backend", backend)
                entry["receipt_path"] = compile_result.get("receipt_path")
                entry["fallback_backend"] = compile_result.get("fallback_backend")
                entry["memory_action_stats"] = compile_result.get("memory_action_stats", {})
                entry["discarded_count"] = compile_result.get("discarded_count", 0)
                if compile_result["status"] == "success":
                    counts["run"] += 1
                else:
                    # Non-success but non-error (e.g. raced another runner and
                    # got skip_locked mid-run) still counts as skipped.
                    counts["skipped"] += 1
        except Exception as exc:  # noqa: BLE001 — per-bucket isolation is the point
            entry["error"] = f"{type(exc).__name__}: {exc}"
            if entry["preflight_status"] is None:
                entry["preflight_status"] = "error"
            entry["compile_status"] = "error"
            counts["failed"] += 1
        results.append(entry)

    return {
        "home": str(home_dir),
        "total_projects": len(results),
        "results": results,
        "counts": counts,
        "aggregate": _aggregate_scan_stats(results),
    }


def _aggregate_scan_stats(results: list[dict]) -> dict[str, Any]:
    """Roll up per-bucket metrics into a single dict for plugin.log readers.

    Without this every observability question ("did reviewer use replace
    anywhere today?") requires jq-iterating the full results array. With it
    one log line per scan tells the whole story.
    """
    actions = {"add": 0, "replace": 0, "remove": 0}
    scopes = {"user": 0, "global": 0}
    total_suggestions = 0
    buckets_with_fallback = 0
    buckets_processed = 0
    total_discarded = 0
    for entry in results:
        stats = entry.get("memory_action_stats") or {}
        if stats:
            total_suggestions += int(stats.get("total", 0) or 0)
            for key, value in (stats.get("by_action") or {}).items():
                if key in actions:
                    actions[key] += int(value or 0)
            for key, value in (stats.get("by_scope") or {}).items():
                if key in scopes:
                    scopes[key] += int(value or 0)
        if entry.get("compile_status") == "success":
            buckets_processed += 1
            if entry.get("fallback_backend"):
                buckets_with_fallback += 1
            total_discarded += int(entry.get("discarded_count", 0) or 0)
    return {
        "buckets_processed": buckets_processed,
        "buckets_with_fallback": buckets_with_fallback,
        "total_memory_suggestions": total_suggestions,
        "actions": actions,
        "scopes": scopes,
        "total_discarded": total_discarded,
    }
