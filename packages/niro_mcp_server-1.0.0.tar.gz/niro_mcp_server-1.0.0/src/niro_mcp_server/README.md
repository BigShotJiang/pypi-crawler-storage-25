# niro-mcp-server

An MCP (Model Context Protocol) server that exposes AU-SG Retail BI domain intelligence as tools for Kiro and other MCP-compatible AI clients.

## What It Does

NIRO MCP Server acts as a virtual BIE — it knows your metrics, dashboards, data lineage, and team conventions. Install it once and any MCP client (Kiro, Claude Desktop, etc.) can:

- **Look up metrics** — definitions, formulas, source tables, ETL jobs, aliases
- **Classify intent** — determine if a request is a CHANGE, STATUS, or DATA query
- **Triage requests** — find duplicates, suggest assignees, recommend actions
- **Generate proposals** — structured solution proposals with draft SQL and effort estimates
- **Trace lineage** — upstream/downstream data flow from any table, ETL, or dashboard
- **Assess impact** — what breaks if a source table or ETL changes
- **Check freshness** — expected refresh schedules and acceptable lag
- **Detect deprecation** — find deprecated sources and their replacements
- **Search domain knowledge** — full-text search across all BI knowledge
- **Create SIM tickets** — file new requests in the AU-Retail-BI resolver group
- **Synthesize status** — unified view of SIM tickets, ETL health, and sprint progress

## Installation

```bash
pip install niro-mcp-server
```

Or run without installing (requires [uv](https://docs.astral.sh/uv/)):

```bash
uvx niro-mcp-server
```

## Configuration for Kiro

Add to your `.kiro/settings/mcp.json`:

```json
{
  "mcpServers": {
    "niro": {
      "command": "niro-mcp-server",
      "env": {"FASTMCP_LOG_LEVEL": "ERROR"},
      "autoApprove": [
        "niro_lookup_metric",
        "niro_classify_intent",
        "niro_find_similar",
        "niro_trace_lineage",
        "niro_impact_analysis",
        "niro_check_freshness",
        "niro_check_deprecation",
        "niro_domain_search",
        "niro_synthesize_status"
      ]
    }
  }
}
```

Or use `uvx` for zero-install:

```json
{
  "mcpServers": {
    "niro": {
      "command": "uvx",
      "args": ["niro-mcp-server"],
      "env": {"FASTMCP_LOG_LEVEL": "ERROR"}
    }
  }
}
```

## Prerequisites

- **Python 3.10+**
- **Midway authentication** (optional) — needed for SIM/Taskei operations. Run `mwinit` to authenticate. All read-only tools work without it.
- **AWS credentials** (optional) — needed for LLM-powered proposals via Amazon Bedrock. Without credentials, proposals use template-based generation.

## Available Tools

| Tool | Description | Auth Required |
|------|-------------|:---:|
| `niro_lookup_metric` | Look up metric by name or alias | No |
| `niro_classify_intent` | Classify text as CHANGE/STATUS/DATA/AMBIGUOUS | No |
| `niro_find_similar` | Find similar SIM tickets | No |
| `niro_trace_lineage` | Trace data lineage upstream/downstream | No |
| `niro_impact_analysis` | Assess downstream impact of a change | No |
| `niro_check_freshness` | Check data source refresh schedule | No |
| `niro_check_deprecation` | Check if a source is deprecated | No |
| `niro_domain_search` | Search across all domain knowledge | No |
| `niro_synthesize_status` | Unified status report | Midway (optional) |
| `niro_triage_request` | Triage a BI request | Midway (optional) |
| `niro_generate_proposal` | Generate solution proposal | AWS (optional) |
| `niro_create_sim` | Create a SIM/Taskei ticket | Midway |

## License

MIT
