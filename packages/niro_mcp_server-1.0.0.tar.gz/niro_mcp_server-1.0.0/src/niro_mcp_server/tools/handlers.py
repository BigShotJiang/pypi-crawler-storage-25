"""
NIRO MCP Tool Handlers

Implements the business logic for each MCP tool by delegating to NIRO's
existing core modules.
"""

from __future__ import annotations

import json
import logging
from dataclasses import asdict
from datetime import datetime, timezone
from typing import Optional

from mcp.types import TextContent

from niro_mcp_server.core.domain_knowledge import DomainKnowledgeStore
from niro_mcp_server.core.lineage_graph import DataLineageGraph
from niro_mcp_server.core.bi_request_agent import BIRequestAgent
from niro_mcp_server.core.solution_proposal import SolutionProposalGenerator
from niro_mcp_server.core.operational_intel import OperationalIntelligence
from niro_mcp_server.core.similarity import rank_similar_issues
from niro_mcp_server.core.models import BIRequest, ImpactAnalysisResult
from niro_mcp_server.core.config import SIM_CTI, SIM_RESOLVER_GROUP

logger = logging.getLogger(__name__)


def _text_result(data: dict) -> list[TextContent]:
    """Wrap a dict as a JSON TextContent response."""
    return [TextContent(type="text", text=json.dumps(data, default=str))]


class ToolHandlers:
    """Stateful handler class holding references to all NIRO components."""

    def __init__(
        self,
        domain_knowledge: DomainKnowledgeStore,
        lineage_graph: DataLineageGraph,
        bi_agent: BIRequestAgent,
        proposal_generator: SolutionProposalGenerator,
        operational_intel: OperationalIntelligence,
        llm_connector=None,
        mcp_connector=None,
    ) -> None:
        self.domain_knowledge = domain_knowledge
        self.lineage_graph = lineage_graph
        self.bi_agent = bi_agent
        self.proposal_generator = proposal_generator
        self.operational_intel = operational_intel
        self.llm_connector = llm_connector
        self.mcp_connector = mcp_connector

    # =========================================================================
    # READ-ONLY HANDLERS
    # =========================================================================

    async def handle_lookup_metric(self, arguments: dict) -> list[TextContent]:
        """Look up a BI metric by name or alias."""
        metric_name = arguments["metric_name"]
        entry = self.domain_knowledge.lookup_metric(metric_name)

        if entry is None:
            return _text_result({
                "found": False,
                "message": f"No metric found matching '{metric_name}'. Try a different name or alias.",
            })

        # Get downstream lineage
        downstream = self.lineage_graph.trace_downstream(entry.name)

        return _text_result({
            "found": True,
            "name": entry.name,
            "definition": entry.definition,
            "formula": entry.formula,
            "source_table": entry.source_table,
            "etl_job": entry.etl_job,
            "dashboard": entry.dashboard,
            "aliases": entry.aliases,
            "downstream_lineage": downstream,
        })

    async def handle_classify_intent(self, arguments: dict) -> list[TextContent]:
        """Classify a free-text user query into an intent category."""
        text = arguments["text"]
        intent = self.bi_agent.classify_intent(text)
        return _text_result({"intent": intent})

    async def handle_trace_lineage(self, arguments: dict) -> list[TextContent]:
        """Trace data lineage upstream and/or downstream from a node."""
        node = arguments["node"]
        direction = arguments.get("direction", "both")

        upstream: list[str] = []
        downstream: list[str] = []

        if direction in ("upstream", "both"):
            upstream = self.lineage_graph.trace_upstream(node)
        if direction in ("downstream", "both"):
            downstream = self.lineage_graph.trace_downstream(node)

        return _text_result({
            "node": node,
            "direction": direction,
            "upstream": upstream,
            "downstream": downstream,
        })

    async def handle_impact_analysis(self, arguments: dict) -> list[TextContent]:
        """Assess downstream impact of changing a data source or ETL job."""
        node = arguments["node"]
        result: ImpactAnalysisResult = self.lineage_graph.impact_analysis(node)

        return _text_result({
            "node": node,
            "affected_dashboards": result.affected_dashboards,
            "affected_reports": result.affected_reports,
            "affected_etl_jobs": result.affected_etl_jobs,
            "affected_metrics": result.affected_metrics,
            "summary": result.summary,
        })

    async def handle_check_freshness(self, arguments: dict) -> list[TextContent]:
        """Check the expected refresh schedule for a data source."""
        source_name = arguments["source_name"]
        entry = self.domain_knowledge.check_freshness(source_name)

        if entry is None:
            return _text_result({
                "found": False,
                "message": f"No freshness entry found for '{source_name}'.",
            })

        return _text_result({
            "found": True,
            "source_name": entry.source_name,
            "refresh_frequency": entry.refresh_frequency,
            "expected_lag_days": entry.expected_lag_days,
            "expected_time_utc": entry.expected_time_utc,
        })

    async def handle_check_deprecation(self, arguments: dict) -> list[TextContent]:
        """Check if a data source or metric is deprecated."""
        source_name = arguments["source_name"]
        warning = self.domain_knowledge.get_deprecation_warning(source_name)

        if warning is None:
            return _text_result({
                "deprecated": False,
                "message": f"'{source_name}' is not deprecated.",
            })

        return _text_result({
            "deprecated": True,
            "warning": warning,
        })

    async def handle_domain_search(self, arguments: dict) -> list[TextContent]:
        """Search across all domain knowledge."""
        query = arguments["query"].lower()

        results: dict[str, list] = {
            "metrics": [],
            "dashboards": [],
            "patterns": [],
            "team": [],
            "providers": [],
        }

        # Search metrics
        for name, metric in self.domain_knowledge.metrics.items():
            if query in name.lower() or query in metric.definition.lower() or any(query in a.lower() for a in metric.aliases):
                results["metrics"].append({
                    "name": metric.name,
                    "definition": metric.definition,
                    "source_table": metric.source_table,
                    "dashboard": metric.dashboard,
                })

        # Search dashboards
        for db in self.domain_knowledge.dashboard_registry:
            db_name = db.get("name", "")
            db_desc = db.get("description", "")
            if query in db_name.lower() or query in db_desc.lower():
                results["dashboards"].append({
                    "name": db_name,
                    "url": db.get("url", ""),
                    "description": db_desc,
                })

        # Search reporting patterns
        for pat in self.domain_knowledge.reporting_patterns:
            pat_name = pat.get("pattern", "")
            pat_desc = pat.get("description", "")
            if query in pat_name.lower() or query in pat_desc.lower():
                results["patterns"].append({
                    "pattern": pat_name,
                    "description": pat_desc,
                    "typical_effort_hours": pat.get("typical_effort_hours", ""),
                })

        # Search team structure
        for member in self.domain_knowledge.team_structure:
            alias = member.get("alias", "")
            name = member.get("name", "")
            areas = member.get("areas", [])
            if query in alias.lower() or query in name.lower() or any(query in a.lower() for a in areas):
                results["team"].append({
                    "alias": alias,
                    "name": name,
                    "areas": areas,
                })

        # Search provider mappings
        for prov in self.domain_knowledge.provider_mappings:
            prov_name = prov.get("provider", "")
            prov_desc = prov.get("description", "")
            if query in prov_name.lower() or query in prov_desc.lower():
                results["providers"].append({
                    "provider": prov_name,
                    "type": prov.get("type", ""),
                    "description": prov_desc,
                })

        # Remove empty categories
        results = {k: v for k, v in results.items() if v}

        return _text_result({
            "query": arguments["query"],
            "results": results,
            "total_matches": sum(len(v) for v in results.values()),
        })

    async def handle_find_similar(self, arguments: dict) -> list[TextContent]:
        """Find SIM tickets similar to a given request text."""
        request_text = arguments["request_text"]
        threshold = arguments.get("threshold", 0.4)
        max_results = arguments.get("max_results", 5)

        # Get cached issues from the BI agent
        issues = self.bi_agent.cached_issues or []

        # If MCP connector is available, try to fetch live issues
        if self.mcp_connector is not None:
            try:
                result = self.mcp_connector.search_tickets(
                    resolver_group=SIM_RESOLVER_GROUP,
                    statuses=["Open", "Assigned", "Work In Progress"],
                    rows=50,
                )
                if result.success and result.data and isinstance(result.data, list):
                    issues = result.data
            except Exception as exc:
                logger.warning("Failed to fetch SIM tickets for similarity: %s", exc)

        similar = rank_similar_issues(
            request_text=request_text,
            issues=issues,
            threshold=threshold,
            max_results=max_results,
        )

        return _text_result({
            "request_text": request_text,
            "threshold": threshold,
            "max_results": max_results,
            "results": similar,
            "count": len(similar),
        })

    # =========================================================================
    # WRITE AND LLM-BACKED HANDLERS
    # =========================================================================

    async def handle_triage_request(self, arguments: dict) -> list[TextContent]:
        """Triage a BI request: classify, find similar SIMs, recommend action."""
        title = arguments["title"]
        description = arguments["description"]
        dashboard = arguments.get("dashboard", "")
        urgency = arguments.get("urgency", "Medium")

        request_text = f"{title} {description}"

        # Fetch existing issues if MCP is available (read-only)
        existing_issues: list[dict] = []
        if self.mcp_connector is not None:
            try:
                result = self.mcp_connector.search_tickets(
                    resolver_group=SIM_RESOLVER_GROUP,
                    statuses=["Open", "Assigned", "Work In Progress", "Researching", "Pending"],
                    rows=50,
                )
                if result.success and result.data and isinstance(result.data, list):
                    existing_issues = result.data
            except Exception as exc:
                logger.warning("SIM search failed during triage: %s", exc)

        # Run triage (read-only — no SIM creation)
        triage_result = self.bi_agent.analyze_similarity(request_text, existing_issues)

        # Get suggested assignee
        suggested_assignee = ""
        if self.domain_knowledge:
            suggested_assignee = self.domain_knowledge.get_area_assignee(request_text) or ""

        # Get feasibility
        feasibility = self.proposal_generator.generate_feasibility(
            BIRequest(title=title, description=description, dashboard=dashboard, urgency=urgency),
            existing_issues,
            self.domain_knowledge,
        )

        return _text_result({
            "recommendation": triage_result["recommendation"],
            "message": triage_result["message"],
            "category": triage_result["category"],
            "similar_issues": triage_result["similar_issues"],
            "suggested_assignee": suggested_assignee,
            "feasibility": {
                "complexity": feasibility.complexity,
                "reasoning": feasibility.reasoning,
                "estimated_hours_low": feasibility.estimated_hours_low,
                "estimated_hours_high": feasibility.estimated_hours_high,
            },
        })

    async def handle_generate_proposal(self, arguments: dict) -> list[TextContent]:
        """Generate a structured solution proposal for a BI request."""
        title = arguments["title"]
        description = arguments["description"]
        dashboard = arguments.get("dashboard", "")
        request_type = arguments.get("request_type", "")
        urgency = arguments.get("urgency", "Medium")

        request = BIRequest(
            title=title, description=description, dashboard=dashboard,
            request_type=request_type, urgency=urgency,
            timestamp=datetime.now(timezone.utc).isoformat(),
            intent_type="CHANGE",
        )

        proposal = self.proposal_generator.generate(
            request=request,
            similar_issues=[],
            domain_knowledge=self.domain_knowledge,
            lineage_graph=self.lineage_graph,
            llm_connector=self.llm_connector,
        )

        # Determine generation method
        generation_method = "llm" if (
            self.llm_connector is not None
            and getattr(self.llm_connector, "is_available", False)
        ) else "template"

        result = {
            "bi_context": proposal.bi_context,
            "problem_statement": proposal.problem_statement,
            "proposed_approach": proposal.proposed_approach,
            "draft_artifacts": [
                {"artifact_type": a.artifact_type, "title": a.title, "content": a.content, "description": a.description}
                for a in proposal.draft_artifacts
            ],
            "estimated_effort": proposal.estimated_effort,
            "implementation_guidance": {
                "where_to_fix": proposal.implementation_guidance.where_to_fix if proposal.implementation_guidance else "",
                "how_to_fix": proposal.implementation_guidance.how_to_fix if proposal.implementation_guidance else "",
                "what_was_done_before": proposal.implementation_guidance.what_was_done_before if proposal.implementation_guidance else "",
            },
            "feasibility": {
                "complexity": proposal.feasibility.complexity if proposal.feasibility else "",
                "reasoning": proposal.feasibility.reasoning if proposal.feasibility else "",
                "estimated_hours_low": proposal.feasibility.estimated_hours_low if proposal.feasibility else 0,
                "estimated_hours_high": proposal.feasibility.estimated_hours_high if proposal.feasibility else 0,
            },
            "generation_method": generation_method,
        }

        return _text_result(result)

    async def handle_create_sim(self, arguments: dict) -> list[TextContent]:
        """Create a SIM/Taskei ticket for a BI request."""
        title = arguments["title"]
        description = arguments["description"]
        priority = arguments.get("priority", "Medium")
        assignee = arguments.get("assignee", "")

        if self.mcp_connector is None:
            return _text_result({
                "success": False,
                "error": "mcp_unavailable",
                "message": "MCP connector is not available. Cannot create SIM tickets.",
            })

        # Check Midway auth
        auth_result = self.mcp_connector.check_midway_auth()
        if not auth_result.success:
            error_type = "midway_expired" if "expired" in (auth_result.error_message or "").lower() else "midway_expired"
            return _text_result({
                "success": False,
                "error": error_type,
                "message": auth_result.error_message or "Midway session expired. Run 'mwinit' to re-authenticate.",
            })

        # Map priority to severity
        severity_map = {"High": "SEV_3", "Medium": "SEV_4", "Low": "SEV_5"}
        severity = severity_map.get(priority, "SEV_4")

        categorization = [
            {"key": "category", "value": SIM_CTI["category"]},
            {"key": "type", "value": SIM_CTI["type"]},
            {"key": "item", "value": SIM_CTI["item"]},
        ]

        result = self.mcp_connector.create_ticket(
            title=f"[BI Request] {title}",
            description=description,
            severity=severity,
            assigned_group=SIM_RESOLVER_GROUP,
            categorization=categorization,
        )

        if result.success:
            ticket_data = result.data if isinstance(result.data, dict) else {}
            return _text_result({
                "success": True,
                "ticket_id": ticket_data.get("id", ticket_data.get("ticketId", "")),
                "url": ticket_data.get("url", ""),
            })
        else:
            return _text_result({
                "success": False,
                "error": result.error_type.value if result.error_type else "operation_failed",
                "message": result.error_message or "Failed to create SIM ticket.",
            })

    async def handle_synthesize_status(self, arguments: dict) -> list[TextContent]:
        """Get a unified status report for a BI topic."""
        query = arguments["query"]

        synthesis = self.operational_intel.synthesize_status(
            query=query,
            mcp_connector=self.mcp_connector,
            domain_knowledge=self.domain_knowledge,
        )

        return _text_result({
            "query": query,
            "sim_status": synthesis.sim_status,
            "job_health": [
                {"job_id": j.job_id, "job_name": j.job_name, "status": j.status}
                for j in synthesis.job_health
            ],
            "sprint_progress": synthesis.sprint_progress,
            "summary": synthesis.summary,
            "timestamp": synthesis.timestamp,
        })
