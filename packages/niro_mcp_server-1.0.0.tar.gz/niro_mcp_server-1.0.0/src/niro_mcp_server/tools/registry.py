"""
NIRO MCP Tool Registry

Defines all 12 MCP tool schemas (name, description, input JSON schema)
and maps them to handler functions.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, TYPE_CHECKING

if TYPE_CHECKING:
    from niro_mcp_server.tools.handlers import ToolHandlers


@dataclass
class ToolDefinition:
    """A single MCP tool definition."""

    name: str
    description: str
    input_schema: dict[str, Any]
    handler: Callable


def get_tool_definitions(handlers: "ToolHandlers") -> list[ToolDefinition]:
    """Return all 12 NIRO MCP tool definitions with JSON Schemas."""
    return [
        ToolDefinition(
            name="niro_lookup_metric",
            description=(
                "Look up a BI metric by name or alias. Returns the metric's "
                "definition, formula, source table, ETL job, dashboard, aliases, "
                "and downstream lineage."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "metric_name": {
                        "type": "string",
                        "description": "Metric name or alias (case-insensitive)",
                    },
                },
                "required": ["metric_name"],
            },
            handler=handlers.handle_lookup_metric,
        ),
        ToolDefinition(
            name="niro_classify_intent",
            description=(
                "Classify a free-text user query into one of: CHANGE, STATUS, "
                "DATA, or AMBIGUOUS. Uses LLM-first classification with keyword "
                "fallback."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "text": {
                        "type": "string",
                        "description": "Free-text user query to classify",
                    },
                },
                "required": ["text"],
            },
            handler=handlers.handle_classify_intent,
        ),
        ToolDefinition(
            name="niro_triage_request",
            description=(
                "Triage a BI request: classify intent, find similar SIM tickets, "
                "and recommend action (DUPLICATE, SIMILAR, or NEW). Read-only — "
                "does not create or modify any tickets."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "title": {
                        "type": "string",
                        "description": "Short title of the BI request",
                    },
                    "description": {
                        "type": "string",
                        "description": "Full description of the BI request",
                    },
                    "dashboard": {
                        "type": "string",
                        "description": "Target dashboard name (optional)",
                    },
                    "urgency": {
                        "type": "string",
                        "enum": ["High", "Medium", "Low"],
                        "description": "Request urgency level",
                    },
                },
                "required": ["title", "description"],
            },
            handler=handlers.handle_triage_request,
        ),
        ToolDefinition(
            name="niro_generate_proposal",
            description=(
                "Generate a structured solution proposal for a BI request. "
                "Includes BI context, problem statement, proposed approach, "
                "draft artifacts (SQL, QuickSight, ETL), effort estimate, and "
                "implementation guidance."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "title": {
                        "type": "string",
                        "description": "Short title of the BI request",
                    },
                    "description": {
                        "type": "string",
                        "description": "Full description of the BI request",
                    },
                    "dashboard": {
                        "type": "string",
                        "description": "Target dashboard name (optional)",
                    },
                    "request_type": {
                        "type": "string",
                        "description": "Request type: Bug, Feature, or Enhancement",
                    },
                    "urgency": {
                        "type": "string",
                        "enum": ["High", "Medium", "Low"],
                        "description": "Request urgency level",
                    },
                },
                "required": ["title", "description"],
            },
            handler=handlers.handle_generate_proposal,
        ),
        ToolDefinition(
            name="niro_find_similar",
            description=(
                "Find SIM tickets similar to a given request text. Returns "
                "scored matches sorted by similarity descending."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "request_text": {
                        "type": "string",
                        "description": "Request text to match against existing SIMs",
                    },
                    "threshold": {
                        "type": "number",
                        "description": "Minimum similarity score (0.0-1.0)",
                        "minimum": 0.0,
                        "maximum": 1.0,
                    },
                    "max_results": {
                        "type": "integer",
                        "description": "Maximum number of results (1-20)",
                        "minimum": 1,
                        "maximum": 20,
                    },
                },
                "required": ["request_text"],
            },
            handler=handlers.handle_find_similar,
        ),
        ToolDefinition(
            name="niro_trace_lineage",
            description=(
                "Trace data lineage upstream and/or downstream from a node "
                "(table, ETL job, query, or dashboard) in the lineage graph."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "node": {
                        "type": "string",
                        "description": "Node name (table, ETL job, or dashboard)",
                    },
                    "direction": {
                        "type": "string",
                        "enum": ["upstream", "downstream", "both"],
                        "description": "Traversal direction (default: both)",
                    },
                },
                "required": ["node"],
            },
            handler=handlers.handle_trace_lineage,
        ),
        ToolDefinition(
            name="niro_impact_analysis",
            description=(
                "Assess downstream impact of changing a data source or ETL job. "
                "Returns affected dashboards, reports, ETL jobs, and metrics."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "node": {
                        "type": "string",
                        "description": "Source node to analyze impact from",
                    },
                },
                "required": ["node"],
            },
            handler=handlers.handle_impact_analysis,
        ),
        ToolDefinition(
            name="niro_check_freshness",
            description=(
                "Check the expected refresh schedule and acceptable lag for a "
                "data source in the freshness registry."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "source_name": {
                        "type": "string",
                        "description": "Data source name to check",
                    },
                },
                "required": ["source_name"],
            },
            handler=handlers.handle_check_freshness,
        ),
        ToolDefinition(
            name="niro_check_deprecation",
            description=(
                "Check if a data source or metric is deprecated and get the "
                "recommended replacement."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "source_name": {
                        "type": "string",
                        "description": "Table or metric name to check",
                    },
                },
                "required": ["source_name"],
            },
            handler=handlers.handle_check_deprecation,
        ),
        ToolDefinition(
            name="niro_domain_search",
            description=(
                "Search across all domain knowledge: metrics, dashboards, "
                "reporting patterns, team structure, and provider mappings."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Free-text search query",
                    },
                },
                "required": ["query"],
            },
            handler=handlers.handle_domain_search,
        ),
        ToolDefinition(
            name="niro_create_sim",
            description=(
                "Create a SIM/Taskei ticket for a BI request in the AU-Retail-BI "
                "resolver group. Requires valid Midway authentication."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "title": {
                        "type": "string",
                        "description": "Ticket title",
                    },
                    "description": {
                        "type": "string",
                        "description": "Ticket description (markdown supported)",
                    },
                    "priority": {
                        "type": "string",
                        "enum": ["High", "Medium", "Low"],
                        "description": "Ticket priority (default: Medium)",
                    },
                    "assignee": {
                        "type": "string",
                        "description": "Assignee alias (optional)",
                    },
                },
                "required": ["title", "description"],
            },
            handler=handlers.handle_create_sim,
        ),
        ToolDefinition(
            name="niro_synthesize_status",
            description=(
                "Get a unified status report combining SIM ticket status, "
                "ETL job health, and sprint progress for a BI topic."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Status query (SIM ID, dashboard name, metric, etc.)",
                    },
                },
                "required": ["query"],
            },
            handler=handlers.handle_synthesize_status,
        ),
    ]
