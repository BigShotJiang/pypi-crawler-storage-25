"""Allow running as: python -m niro_mcp_server"""
from niro_mcp_server import main

main()
