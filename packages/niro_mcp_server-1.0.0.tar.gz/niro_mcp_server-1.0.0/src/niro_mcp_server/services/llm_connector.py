"""
LLMConnector — Wraps Amazon Bedrock invoke_model API for LLM-powered
Solution_Proposal generation.
"""

import json
import logging
import time

from niro_mcp_server.core.config import (
    LLM_MODEL_ID,
    LLM_REGION,
    LLM_TIMEOUT_SECONDS,
    LLM_FALLBACK_ENABLED,
    LLM_MAX_TOKENS,
)
from niro_mcp_server.core.models import LLMResult, LLMError, LLMErrorType

logger = logging.getLogger(__name__)

_MAX_CONSECUTIVE_FAILURES = 3


class LLMConnector:
    """Wraps Amazon Bedrock calls for LLM-powered Solution_Proposal generation."""

    def __init__(self):
        self.model_id = LLM_MODEL_ID
        self.region = LLM_REGION
        self.timeout = LLM_TIMEOUT_SECONDS
        self.fallback_enabled = LLM_FALLBACK_ENABLED
        self.max_tokens = LLM_MAX_TOKENS
        self.available = True
        self._client = None
        self._consecutive_failures = 0

    @property
    def is_available(self) -> bool:
        """Check if LLM service is available (not in cooldown)."""
        return self.available

    def generate_proposal(self, system_context: str, user_context: str) -> LLMResult:
        """Invoke Bedrock with BI domain knowledge and request details."""
        start = time.time()
        try:
            raw_response = self._invoke_model(system_context, user_context)
            parsed = self._parse_response(raw_response)
            latency_ms = (time.time() - start) * 1000
            self._consecutive_failures = 0
            logger.info("LLM call succeeded in %.0fms (model=%s)", latency_ms, self.model_id)
            return LLMResult(success=True, data=parsed)
        except LLMError:
            self._record_failure()
            raise
        except Exception as exc:
            self._record_failure()
            raise LLMError(LLMErrorType.SERVICE_UNAVAILABLE, f"Unexpected error: {exc}") from exc

    def _build_bedrock_client(self):
        """Lazy-initialize boto3 Bedrock runtime client."""
        if self._client is None:
            import boto3
            from botocore.config import Config
            self._client = boto3.client(
                "bedrock-runtime", region_name=self.region,
                config=Config(read_timeout=self.timeout, connect_timeout=self.timeout, retries={"max_attempts": 0}),
            )
        return self._client

    def _invoke_model(self, system_prompt: str, user_prompt: str) -> dict:
        """Call Bedrock invoke_model API."""
        client = self._build_bedrock_client()
        body = json.dumps({
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": self.max_tokens,
            "system": system_prompt,
            "messages": [{"role": "user", "content": user_prompt}],
        })
        try:
            response = client.invoke_model(
                modelId=self.model_id, contentType="application/json",
                accept="application/json", body=body,
            )
            return json.loads(response["body"].read())
        except Exception as exc:
            msg = str(exc).lower()
            if any(kw in msg for kw in ("timeout", "timed out", "readtimeout")):
                raise LLMError(LLMErrorType.TIMEOUT, f"Bedrock request timed out: {exc}") from exc
            if "429" in msg or "throttl" in msg:
                raise LLMError(LLMErrorType.RATE_LIMITED, f"Bedrock rate limited: {exc}") from exc
            raise LLMError(LLMErrorType.SERVICE_UNAVAILABLE, f"Bedrock invocation failed: {exc}") from exc

    def _parse_response(self, raw_response: dict) -> dict:
        """Parse Bedrock response body into structured JSON."""
        try:
            content_blocks = raw_response.get("content", [])
            if not content_blocks:
                raise LLMError(LLMErrorType.INVALID_RESPONSE, "Empty content in Bedrock response")
            text = content_blocks[0].get("text", "")
            if not text:
                raise LLMError(LLMErrorType.INVALID_RESPONSE, "Empty text in Bedrock response")
            json_str = text.strip()
            if json_str.startswith("```"):
                lines = json_str.split("\n")
                lines = [line for line in lines if not line.strip().startswith("```")]
                json_str = "\n".join(lines)
            return json.loads(json_str)
        except LLMError:
            raise
        except (json.JSONDecodeError, KeyError, IndexError, TypeError) as exc:
            raise LLMError(LLMErrorType.INVALID_RESPONSE, f"Failed to parse LLM response: {exc}") from exc

    def _record_failure(self):
        """Track consecutive failures and enter cooldown after threshold."""
        self._consecutive_failures += 1
        logger.warning("LLM failure %d/%d", self._consecutive_failures, _MAX_CONSECUTIVE_FAILURES)
        if self._consecutive_failures >= _MAX_CONSECUTIVE_FAILURES:
            self.available = False
            logger.warning("LLM connector entering cooldown after %d consecutive failures", self._consecutive_failures)
