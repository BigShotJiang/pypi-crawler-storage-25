"""
MCP Client — Communicates with MCP servers via JSON-RPC over stdio subprocess.
"""

from __future__ import annotations

import json
import logging
import subprocess
import threading
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class MCPClient:
    """Manages a connection to an MCP server subprocess."""

    def __init__(self, command: str, args: Optional[List[str]] = None):
        self.command = command
        self.args = args or []
        self._process = None
        self._request_id = 0
        self._lock = threading.Lock()
        self._initialized = False

    def start(self) -> bool:
        """Start the MCP server subprocess."""
        try:
            self._process = subprocess.Popen(
                [self.command] + self.args,
                stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                text=True, bufsize=1,
            )
            init_result = self._send_request("initialize", {
                "protocolVersion": "2024-11-05", "capabilities": {},
                "clientInfo": {"name": "niro", "version": "1.0.0"},
            })
            if init_result is not None:
                self._send_notification("notifications/initialized", {})
                self._initialized = True
                return True
            return False
        except FileNotFoundError:
            logger.warning("MCP server command not found: %s", self.command)
            return False
        except Exception as exc:
            logger.warning("Failed to start MCP server %s: %s", self.command, exc)
            return False

    def stop(self):
        """Stop the MCP server subprocess."""
        if self._process:
            try:
                self._process.stdin.close()
                self._process.terminate()
                self._process.wait(timeout=5)
            except Exception:
                try:
                    self._process.kill()
                except Exception:
                    pass
            self._process = None
            self._initialized = False

    def call_tool(self, tool_name: str, arguments: Dict[str, Any]) -> Optional[Dict]:
        """Call an MCP tool and return the result."""
        if not self._initialized or not self._process:
            return None
        return self._send_request("tools/call", {"name": tool_name, "arguments": arguments})

    def list_tools(self) -> Optional[List[Dict]]:
        """List available tools from the MCP server."""
        if not self._initialized:
            return None
        result = self._send_request("tools/list", {})
        if result and "tools" in result:
            return result["tools"]
        return result

    def _send_request(self, method: str, params: Dict) -> Optional[Dict]:
        with self._lock:
            self._request_id += 1
            request = {"jsonrpc": "2.0", "id": self._request_id, "method": method, "params": params}
            return self._send_and_receive(request)

    def _send_notification(self, method: str, params: Dict):
        notification = {"jsonrpc": "2.0", "method": method, "params": params}
        try:
            line = json.dumps(notification) + "\n"
            self._process.stdin.write(line)
            self._process.stdin.flush()
        except Exception as exc:
            logger.warning("Failed to send notification: %s", exc)

    def _send_and_receive(self, request: Dict) -> Optional[Dict]:
        try:
            line = json.dumps(request) + "\n"
            self._process.stdin.write(line)
            self._process.stdin.flush()
            while True:
                response_line = self._process.stdout.readline()
                if not response_line:
                    return None
                response_line = response_line.strip()
                if not response_line:
                    continue
                try:
                    response = json.loads(response_line)
                except json.JSONDecodeError:
                    continue
                if "id" not in response:
                    continue
                if response.get("id") == request["id"]:
                    if "error" in response:
                        logger.warning("MCP error for %s: %s", request["method"], response["error"])
                        return None
                    return response.get("result")
        except Exception as exc:
            logger.warning("MCP communication error: %s", exc)
            return None

    @property
    def is_running(self) -> bool:
        return self._process is not None and self._process.poll() is None and self._initialized
