"""
MCPConnector — Wraps all builder-mcp tool calls behind a Python interface.
"""

from __future__ import annotations

import json
import logging
import os
import time
from typing import Dict, List, Optional

from niro_mcp_server.core.config import MIDWAY_COOKIE_PATH, MIDWAY_EXPIRY_HOURS, SIM_RESOLVER_GROUP
from niro_mcp_server.core.models import MCPResult, MCPErrorType
from niro_mcp_server.services.mcp_client import MCPClient

logger = logging.getLogger(__name__)

_AUTH_KEYWORDS = ("401", "403", "midway", "authentication", "cookie", "unauthorized")
_CONNECTION_KEYWORDS = ("connection", "timeout", "unreachable", "refused", "dns")


class MCPConnector:
    """Wraps builder-mcp tool calls with Midway auth checks and error handling."""

    def __init__(self):
        self.midway_cookie_path = os.path.expanduser(MIDWAY_COOKIE_PATH)
        self.available = True
        self.midway_valid = False
        self._builder_mcp = None

    def _get_builder_mcp(self) -> Optional[MCPClient]:
        """Lazy-initialize the builder-mcp client."""
        if self._builder_mcp is not None and self._builder_mcp.is_running:
            return self._builder_mcp
        import shutil
        cmd = shutil.which("builder-mcp")
        if cmd is None:
            for path in [
                os.path.expanduser("~/.toolbox/bin/builder-mcp"),
                "/usr/local/bin/builder-mcp",
                os.path.expanduser("~/.local/bin/builder-mcp"),
            ]:
                if os.path.isfile(path):
                    cmd = path
                    break
        if cmd is None:
            logger.warning("builder-mcp not found on PATH or common locations")
            return None
        client = MCPClient(cmd)
        if client.start():
            self._builder_mcp = client
            logger.info("builder-mcp started successfully from %s", cmd)
            return client
        else:
            logger.warning("Failed to start builder-mcp from %s", cmd)
            return None

    def check_midway_auth(self) -> MCPResult:
        """Verify Midway cookie validity."""
        if not os.path.exists(self.midway_cookie_path):
            return MCPResult(success=False, error_type=MCPErrorType.MIDWAY_MISSING, error_message="Midway cookie file not found. Run `mwinit` first.")
        if os.path.getsize(self.midway_cookie_path) == 0:
            return MCPResult(success=False, error_type=MCPErrorType.MIDWAY_MISSING, error_message="Midway cookie file is empty. Run `mwinit` first.")
        mtime = os.path.getmtime(self.midway_cookie_path)
        age_hours = (time.time() - mtime) / 3600
        if age_hours > MIDWAY_EXPIRY_HOURS:
            return MCPResult(success=False, error_type=MCPErrorType.MIDWAY_EXPIRED, error_message=f"Midway cookie is {age_hours:.1f}h old (limit: {MIDWAY_EXPIRY_HOURS}h). Run `mwinit` to refresh.")
        self.midway_valid = True
        return MCPResult(success=True)

    def _check_auth_before_call(self) -> Optional[MCPResult]:
        if not self.midway_valid:
            result = self.check_midway_auth()
            if not result.success:
                return result
        return None

    def _call_builder_tool(self, action: str, input_args: Dict) -> MCPResult:
        """Call a builder-mcp tool with auth checks and error handling."""
        auth_err = self._check_auth_before_call()
        if auth_err is not None:
            return auth_err
        client = self._get_builder_mcp()
        if client is None:
            return MCPResult(success=False, error_type=MCPErrorType.MCP_UNAVAILABLE, error_message="builder-mcp is not available.")
        try:
            result = client.call_tool(action, input_args)
            if result is None:
                return MCPResult(success=False, error_type=MCPErrorType.OPERATION_FAILED, error_message=f"Tool {action} returned no result")
            content = result.get("content", [])
            if content and isinstance(content, list):
                text_parts = []
                for item in content:
                    if isinstance(item, dict) and item.get("type") == "text":
                        text_parts.append(item.get("text", ""))
                combined = "\n".join(text_parts)
                try:
                    data = json.loads(combined)
                    return MCPResult(success=True, data=data)
                except json.JSONDecodeError:
                    return MCPResult(success=True, data=combined)
            return MCPResult(success=True, data=result)
        except Exception as exc:
            msg = str(exc).lower()
            if any(kw in msg for kw in _AUTH_KEYWORDS):
                self.midway_valid = False
                return MCPResult(success=False, error_type=MCPErrorType.MIDWAY_EXPIRED, error_message=f"Authentication failure: {exc}")
            if any(kw in msg for kw in _CONNECTION_KEYWORDS):
                self.available = False
                return MCPResult(success=False, error_type=MCPErrorType.MCP_UNAVAILABLE, error_message=f"MCP connection failure: {exc}")
            return MCPResult(success=False, error_type=MCPErrorType.OPERATION_FAILED, error_message=f"Operation failed: {exc}")

    def search_tickets(self, resolver_group: str, statuses: Optional[List[str]] = None, rows: int = 50, sort: str = "lastUpdatedDate desc") -> MCPResult:
        """Search SIM tickets via TicketingReadActions search-tickets."""
        input_args = {"action": "search-tickets", "input": {"assignedGroup": [resolver_group], "status": statuses or ["Open", "Assigned", "Work In Progress"], "rows": rows, "sort": sort}}
        return self._call_builder_tool("TicketingReadActions", input_args)

    def get_ticket(self, ticket_id: str, max_correspondence: int = 20) -> MCPResult:
        """Get full ticket details."""
        input_args = {"action": "get-ticket", "input": {"ticketId": ticket_id, "maxCorrespondence": max_correspondence}}
        return self._call_builder_tool("TicketingReadActions", input_args)

    def create_ticket(self, title: str, description: str, severity: str, assigned_group: str, categorization: Optional[List[Dict]] = None, tags: Optional[List[str]] = None) -> MCPResult:
        """Create SIM ticket."""
        input_args = {"action": "create-ticket", "title": title, "description": description, "severity": severity, "assignedGroup": assigned_group, "categorization": categorization or []}
        if tags:
            input_args["tags"] = [{"tagId": t} for t in tags]
        return self._call_builder_tool("TicketingWriteActions", input_args)

    def add_comment(self, ticket_id: str, message: str) -> MCPResult:
        """Add comment to SIM ticket."""
        return self._call_builder_tool("TicketingWriteActions", {"action": "add-comment", "ticketId": ticket_id, "message": message})

    def fetch_datacentral_job_status(self, job_url: str) -> MCPResult:
        """Fetch DataCentral job page."""
        return self._call_builder_tool("ReadInternalWebsites", {"inputs": [job_url]})

    def read_internal_website(self, url: str) -> MCPResult:
        """Read any internal Amazon website."""
        return self._call_builder_tool("ReadInternalWebsites", {"inputs": [url]})

    def __del__(self):
        if self._builder_mcp:
            self._builder_mcp.stop()
