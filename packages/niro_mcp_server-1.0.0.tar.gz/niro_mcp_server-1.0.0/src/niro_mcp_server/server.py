"""
NIRO MCP Server

Bootstraps the MCP server, registers all 12 tools, initializes shared NIRO
components, and runs the stdio transport loop.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
from pathlib import Path
from typing import Any, Optional

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

from niro_mcp_server.core.domain_knowledge import DomainKnowledgeStore
from niro_mcp_server.core.lineage_graph import DataLineageGraph
from niro_mcp_server.core.bi_request_agent import BIRequestAgent
from niro_mcp_server.core.solution_proposal import SolutionProposalGenerator
from niro_mcp_server.core.operational_intel import OperationalIntelligence
from niro_mcp_server.tools.registry import get_tool_definitions

logger = logging.getLogger(__name__)


class NiroMCPServer:
    """MCP server that exposes NIRO BI intelligence as tools."""

    def __init__(self, yaml_path: str | None = None) -> None:
        self._yaml_path = yaml_path
        self._server = Server("niro-mcp-server")

        # Initialize all components
        self._init_components()

        # Register MCP tool handlers
        self._register_tools()

    # -----------------------------------------------------------------
    # Component initialization
    # -----------------------------------------------------------------

    def _init_components(self) -> None:
        """Initialize all NIRO components with graceful fallback."""
        # Step 1: Load domain knowledge (three-tier: local > S3 > bundled)
        yaml_data = self._load_domain_knowledge()
        self.domain_knowledge = DomainKnowledgeStore(yaml_data)
        self.lineage_graph = DataLineageGraph(self.domain_knowledge.lineage_edges)

        # Step 2: Initialize LLM connector (best-effort)
        self.llm_connector = self._try_init_llm()

        # Step 3: Initialize MCP connector (best-effort)
        self.mcp_connector = self._try_init_mcp()

        # Step 4: Wire up core components
        self.bi_agent = BIRequestAgent(
            domain_knowledge=self.domain_knowledge,
            lineage_graph=self.lineage_graph,
            llm_connector=self.llm_connector,
            mcp_connector=self.mcp_connector,
        )
        self.proposal_generator = SolutionProposalGenerator(
            domain_knowledge=self.domain_knowledge,
            lineage_graph=self.lineage_graph,
            llm_connector=self.llm_connector,
        )
        self.operational_intel = OperationalIntelligence(
            domain_knowledge=self.domain_knowledge,
            lineage_graph=self.lineage_graph,
        )

    def _load_domain_knowledge(self) -> dict:
        """Three-tier YAML loading: local > S3 > bundled."""
        import yaml

        # Tier 1: Explicit path or local override
        if self._yaml_path:
            return self._load_yaml_file(self._yaml_path)

        local_path = os.path.expanduser("~/.niro/bi_domain_knowledge.yaml")
        if os.path.isfile(local_path):
            logger.info("Loading domain knowledge from local override: %s", local_path)
            data = self._load_yaml_file(local_path)
            if data:
                return data

        # Tier 2: S3
        s3_data = self._try_load_from_s3()
        if s3_data:
            return s3_data

        # Tier 3: Bundled package data
        bundled_path = os.path.join(
            os.path.dirname(__file__), "data", "bi_domain_knowledge.yaml"
        )
        if os.path.isfile(bundled_path):
            logger.info("Loading domain knowledge from bundled data: %s", bundled_path)
            return self._load_yaml_file(bundled_path)

        logger.warning("No domain knowledge YAML found — starting with empty store.")
        return {}

    @staticmethod
    def _load_yaml_file(path: str) -> dict:
        """Load a YAML file and return its contents as a dict."""
        import yaml
        try:
            with open(path, "r", encoding="utf-8") as fh:
                data = yaml.safe_load(fh)
            if isinstance(data, dict):
                return data
            logger.warning("YAML file %s did not contain a mapping.", path)
            return {}
        except Exception as exc:
            logger.warning("Failed to load YAML from %s: %s", path, exc)
            return {}

    @staticmethod
    def _try_load_from_s3() -> Optional[dict]:
        """Attempt to load domain knowledge from S3."""
        import yaml
        try:
            import boto3
            s3 = boto3.client("s3")
            response = s3.get_object(
                Bucket="au-sg-retail-bi",
                Key="niro/bi_domain_knowledge.yaml",
            )
            content = response["Body"].read().decode("utf-8")
            data = yaml.safe_load(content)
            if isinstance(data, dict):
                logger.info("Loaded domain knowledge from S3.")
                return data
        except Exception as exc:
            logger.debug("S3 domain knowledge load failed (expected in dev): %s", exc)
        return None

    @staticmethod
    def _try_init_llm():
        """Initialize LLMConnector, returning None on failure."""
        try:
            from niro_mcp_server.services.llm_connector import LLMConnector
            connector = LLMConnector()
            logger.info("LLMConnector initialized (model=%s).", connector.model_id)
            return connector
        except Exception as exc:
            logger.warning("LLMConnector unavailable: %s — proposals will use template fallback.", exc)
            return None

    @staticmethod
    def _try_init_mcp():
        """Initialize MCPConnector, returning None on failure."""
        try:
            from niro_mcp_server.services.mcp_connector import MCPConnector
            connector = MCPConnector()
            auth = connector.check_midway_auth()
            if not auth.success:
                logger.warning("Midway auth check failed: %s — SIM operations will be unavailable.", auth.error_message)
            return connector
        except Exception as exc:
            logger.warning("MCPConnector unavailable: %s — SIM operations will be unavailable.", exc)
            return None

    # -----------------------------------------------------------------
    # Tool registration
    # -----------------------------------------------------------------

    def _register_tools(self) -> None:
        """Register all tools with the MCP Server using decorators."""
        from niro_mcp_server.tools.handlers import ToolHandlers

        handlers = ToolHandlers(
            domain_knowledge=self.domain_knowledge,
            lineage_graph=self.lineage_graph,
            bi_agent=self.bi_agent,
            proposal_generator=self.proposal_generator,
            operational_intel=self.operational_intel,
            llm_connector=self.llm_connector,
            mcp_connector=self.mcp_connector,
        )

        tool_defs = get_tool_definitions(handlers)
        self._tool_map: dict[str, Any] = {td.name: td for td in tool_defs}

        @self._server.list_tools()
        async def list_tools() -> list[Tool]:
            """Return all registered NIRO tools."""
            return [
                Tool(
                    name=td.name,
                    description=td.description,
                    inputSchema=td.input_schema,
                )
                for td in tool_defs
            ]

        @self._server.call_tool()
        async def call_tool(name: str, arguments: dict) -> list[TextContent]:
            """Dispatch a tool call with validation and error isolation."""
            if name not in self._tool_map:
                return [TextContent(
                    type="text",
                    text=json.dumps({"error": "unknown_tool", "message": f"Unknown tool: {name}"}),
                )]

            td = self._tool_map[name]

            # Input validation
            validation_error = self._validate_arguments(arguments, td.input_schema)
            if validation_error:
                return [TextContent(
                    type="text",
                    text=json.dumps({"error": "validation_error", "message": validation_error}),
                )]

            # Error isolation — catch all handler exceptions
            try:
                result = await td.handler(arguments)
                return result
            except Exception as exc:
                logger.exception("Tool handler error for %s", name)
                return [TextContent(
                    type="text",
                    text=json.dumps({"error": "handler_error", "message": str(exc)}),
                )]

    # -----------------------------------------------------------------
    # Input validation
    # -----------------------------------------------------------------

    @staticmethod
    def _validate_arguments(arguments: dict, schema: dict) -> Optional[str]:
        """Validate tool arguments against JSON Schema.

        Returns an error message string if validation fails, or None if valid.
        """
        properties = schema.get("properties", {})
        required = schema.get("required", [])

        # Check required fields
        for field_name in required:
            if field_name not in arguments or arguments[field_name] is None:
                return f"Missing required field: '{field_name}'"
            # Check non-empty strings for required string fields
            field_schema = properties.get(field_name, {})
            if field_schema.get("type") == "string" and not str(arguments[field_name]).strip():
                return f"Required field '{field_name}' must be a non-empty string"

        # Check types and constraints for provided fields
        for field_name, value in arguments.items():
            if field_name not in properties:
                continue  # Allow extra fields

            field_schema = properties[field_name]
            expected_type = field_schema.get("type")

            # Type checking
            if expected_type == "string" and not isinstance(value, str):
                return f"Field '{field_name}' must be a string, got {type(value).__name__}"
            elif expected_type == "number" and not isinstance(value, (int, float)):
                return f"Field '{field_name}' must be a number, got {type(value).__name__}"
            elif expected_type == "integer" and not isinstance(value, int):
                return f"Field '{field_name}' must be an integer, got {type(value).__name__}"

            # Enum validation
            if "enum" in field_schema and value not in field_schema["enum"]:
                return f"Field '{field_name}' must be one of {field_schema['enum']}, got '{value}'"

            # Range validation
            if "minimum" in field_schema and isinstance(value, (int, float)):
                if value < field_schema["minimum"]:
                    return f"Field '{field_name}' must be >= {field_schema['minimum']}, got {value}"
            if "maximum" in field_schema and isinstance(value, (int, float)):
                if value > field_schema["maximum"]:
                    return f"Field '{field_name}' must be <= {field_schema['maximum']}, got {value}"

        return None

    # -----------------------------------------------------------------
    # Run
    # -----------------------------------------------------------------

    def run(self) -> None:
        """Start the MCP server with stdio transport."""
        logging.basicConfig(level=logging.INFO, format="%(name)s - %(levelname)s - %(message)s")
        logger.info("Starting NIRO MCP Server...")
        logger.info("Domain knowledge: %d metrics, %d lineage nodes",
                     len(self.domain_knowledge.metrics),
                     len(self.lineage_graph.adjacency))
        logger.info("LLM: %s | MCP: %s",
                     "available" if self.llm_connector else "unavailable",
                     "available" if self.mcp_connector else "unavailable")

        asyncio.run(self._run_async())

    async def _run_async(self) -> None:
        """Async entry point for the stdio transport loop."""
        async with stdio_server() as (read_stream, write_stream):
            await self._server.run(
                read_stream,
                write_stream,
                self._server.create_initialization_options(),
            )
