"""NIRO MCP Server — BI domain intelligence as MCP tools."""


def main():
    """Entry point for the NIRO MCP server."""
    from niro_mcp_server.server import NiroMCPServer
    server = NiroMCPServer()
    server.run()
