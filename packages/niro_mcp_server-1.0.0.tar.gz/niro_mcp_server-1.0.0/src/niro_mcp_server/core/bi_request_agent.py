"""
BI Request Agent — Intelligent triage for BI change requests.

Repackaged for the MCP server with updated imports.
"""

import logging
from datetime import datetime
from typing import Optional

from niro_mcp_server.core.config import (
    AUTO_TAGS,
    DASHBOARD_REGISTRY,
    DEFAULT_PRIORITY,
    GROUPING_CATEGORIES,
    MAX_SIMILAR_RESULTS,
    SIM_CTI,
    SIM_FOLDER_ID,
    SIM_RESOLVER_GROUP,
    SIM_TEMPLATE,
    SIMILARITY_THRESHOLD,
)
from niro_mcp_server.core.models import (
    BIRequest,
    TriageResult,
    SimilarIssue,
    FeasibilityAssessment,
    SolutionProposal,
)
from niro_mcp_server.core.domain_knowledge import DomainKnowledgeStore
from niro_mcp_server.core.lineage_graph import DataLineageGraph
from niro_mcp_server.core.similarity import categorize_request, rank_similar_issues

logger = logging.getLogger(__name__)


class BIRequestAgent:
    """Intelligent BI request triage agent."""

    CHANGE_KEYWORDS = [
        "add", "new", "create", "build", "modify", "update",
        "fix", "change", "need", "broken", "bug",
    ]
    STATUS_KEYWORDS = [
        "status", "update", "progress", "where is",
        "what happened", "how is", "any update", "stale",
    ]
    DATA_KEYWORDS = [
        "show", "pull", "get", "what is", "what are",
        "current", "latest", "metrics for", "numbers for",
        "how much", "how many",
    ]

    def __init__(
        self,
        folder_id: str = "",
        resolver_group: str = "",
        domain_knowledge: Optional[DomainKnowledgeStore] = None,
        lineage_graph: Optional[DataLineageGraph] = None,
        llm_connector=None,
        mcp_connector=None,
    ):
        self.folder_id = folder_id or SIM_FOLDER_ID
        self.resolver_group = resolver_group or SIM_RESOLVER_GROUP
        self.cached_issues: list[dict] = []
        self.domain_knowledge = domain_knowledge
        self.lineage_graph = lineage_graph
        self.llm_connector = llm_connector
        self.mcp_connector = mcp_connector

    # =========================================================================
    # INTENT CLASSIFICATION
    # =========================================================================

    def classify_intent(self, text: str) -> str:
        """Classify user intent as CHANGE, STATUS, DATA, or AMBIGUOUS."""
        if not text or not text.strip():
            return "CHANGE"

        if self.llm_connector is not None:
            try:
                llm_result = self._classify_intent_via_llm(text)
                if llm_result is not None:
                    return llm_result
            except Exception:
                logger.debug("LLM intent classification failed, falling back to keywords")

        return self._classify_intent_via_keywords(text)

    def _classify_intent_via_llm(self, text: str) -> Optional[str]:
        """Attempt intent classification using the LLM connector."""
        if not hasattr(self.llm_connector, "generate_proposal"):
            return None
        available = getattr(self.llm_connector, "is_available", True)
        if callable(available):
            available = available()
        if not available:
            return None

        system_prompt = (
            "You are an intent classifier for a BI request system. "
            "Classify the user's message into exactly one of these intents:\n"
            "- CHANGE: The user wants something built, modified, or fixed.\n"
            "- STATUS: The user wants to know the progress of ongoing work.\n"
            "- DATA: The user wants to pull, view, or look up data or metrics.\n\n"
            "Respond with ONLY the intent type: CHANGE, STATUS, or DATA."
        )
        result = self.llm_connector.generate_proposal(system_prompt, text)
        if result is not None and hasattr(result, "success") and result.success:
            response_text = ""
            if isinstance(result.data, str):
                response_text = result.data.strip().upper()
            elif isinstance(result.data, dict):
                response_text = str(
                    result.data.get("intent", result.data.get("classification", ""))
                ).strip().upper()
            if response_text in ("CHANGE", "STATUS", "DATA"):
                return response_text
        return None

    def _classify_intent_via_keywords(self, text: str) -> str:
        """Classify intent using keyword matching."""
        lower_text = text.lower()

        status_phrases = ["what happened", "where is", "how is", "any update"]
        for phrase in status_phrases:
            if phrase in lower_text:
                return "STATUS"

        has_status_word = any(kw in lower_text for kw in ["status", "progress", "stale"])
        has_strong_data_signal = any(
            kw in lower_text for kw in ["show", "pull", "metrics for", "numbers for", "how much", "how many"]
        )
        if has_status_word and not has_strong_data_signal:
            return "STATUS"

        def _find_earliest_position(keywords):
            earliest = -1
            for kw in keywords:
                pos = lower_text.find(kw)
                if pos != -1 and (earliest == -1 or pos < earliest):
                    earliest = pos
            return earliest

        change_pos = _find_earliest_position(self.CHANGE_KEYWORDS)
        status_pos = _find_earliest_position(self.STATUS_KEYWORDS)
        data_pos = _find_earliest_position(self.DATA_KEYWORDS)

        matches: dict[str, int] = {}
        if change_pos != -1:
            matches["CHANGE"] = change_pos
        if status_pos != -1:
            matches["STATUS"] = status_pos
        if data_pos != -1:
            matches["DATA"] = data_pos

        if not matches:
            return "CHANGE"

        min_pos = min(matches.values())
        earliest_intents = [intent for intent, pos in matches.items() if pos == min_pos]

        if len(earliest_intents) > 1:
            return "AMBIGUOUS"
        return earliest_intents[0]

    # =========================================================================
    # CHANGE HANDLER
    # =========================================================================

    def handle_change(self, text: str, request_id: str = "") -> dict:
        """Handle a CHANGE intent."""
        first_sentence_end = None
        for sep in (".", "!", "?", "\n"):
            idx = text.find(sep)
            if idx != -1 and (first_sentence_end is None or idx < first_sentence_end):
                first_sentence_end = idx

        if first_sentence_end is not None and first_sentence_end > 0:
            title = text[:first_sentence_end].strip()[:100]
        else:
            title = text[:100].strip()

        dashboard = self._extract_dashboard(text)
        request_type = self._extract_request_type(text)
        urgency = self._extract_urgency(text)

        request = BIRequest(
            request_id=request_id, title=title, description=text,
            dashboard=dashboard, request_type=request_type, urgency=urgency,
            timestamp=datetime.now().isoformat(), intent_type="CHANGE",
        )

        triage_result = self.analyze_similarity(text, self.cached_issues)
        category = categorize_request(text, GROUPING_CATEGORIES)

        suggested_assignee = ""
        if self.domain_knowledge is not None:
            suggested_assignee = self.domain_knowledge.get_area_assignee(text) or ""

        deprecation_warnings: list[str] = []
        if self.domain_knowledge is not None:
            for word in text.split():
                warning = self.domain_knowledge.get_deprecation_warning(word)
                if warning and warning not in deprecation_warnings:
                    deprecation_warnings.append(warning)

        return {
            "request": request, "triage_result": triage_result,
            "category": category, "suggested_assignee": suggested_assignee,
            "deprecation_warnings": deprecation_warnings,
        }

    @staticmethod
    def _extract_dashboard(text: str) -> str:
        lower_text = text.lower()
        for dashboard in DASHBOARD_REGISTRY:
            if dashboard.lower() in lower_text:
                return dashboard
        return ""

    @staticmethod
    def _extract_request_type(text: str) -> str:
        lower_text = text.lower()
        for kw in ["bug", "issue", "broken", "error"]:
            if kw in lower_text:
                return "Bug"
        for kw in ["add", "new", "create", "need"]:
            if kw in lower_text:
                return "Feature"
        for kw in ["improve", "update", "change", "modify"]:
            if kw in lower_text:
                return "Enhancement"
        return "Feature"

    @staticmethod
    def _extract_urgency(text: str) -> str:
        lower_text = text.lower()
        for kw in ["urgent", "asap", "critical", "blocking"]:
            if kw in lower_text:
                return "High"
        for kw in ["low priority", "when you can", "nice to have"]:
            if kw in lower_text:
                return "Low"
        return "Medium"

    # =========================================================================
    # SIMILARITY ANALYSIS
    # =========================================================================

    def analyze_similarity(self, request_text: str, existing_issues: list[dict]) -> dict:
        """Analyze the incoming request against existing issues."""
        similar = rank_similar_issues(
            request_text=request_text, issues=existing_issues,
            threshold=SIMILARITY_THRESHOLD, max_results=MAX_SIMILAR_RESULTS,
        )
        category = categorize_request(request_text, GROUPING_CATEGORIES)

        if similar and similar[0]["similarity_score"] >= 0.7:
            recommendation = "DUPLICATE"
            message = f"High-confidence match found. This request appears to be a duplicate of '{similar[0]['issue_name']}' (score: {similar[0]['similarity_score']})."
        elif similar and similar[0]["similarity_score"] >= SIMILARITY_THRESHOLD:
            recommendation = "SIMILAR"
            message = f"Found {len(similar)} similar request(s). Review these before creating a new SIM to avoid duplication."
        else:
            recommendation = "NEW"
            message = "No similar requests found. This appears to be a new request. Proceed with SIM creation."

        return {
            "recommendation": recommendation, "message": message,
            "category": category, "similar_issues": similar,
            "timestamp": datetime.now().isoformat(),
        }

    # =========================================================================
    # SIM CREATION
    # =========================================================================

    def build_sim_creation_params(self, title: str, description: str, requester: str = "", category: str = "", priority: str = "") -> dict:
        """Build the parameters for creating a new SIM."""
        filled_description = SIM_TEMPLATE["description_template"].format(
            summary=title, justification="To be provided by requester",
            requester=requester or "Not specified", data_sources="To be determined",
            deliverable="To be determined", target_date="To be determined",
            acceptance_criteria="To be determined",
        )
        return {
            "name": f"[BI Request] {title}",
            "description": filled_description,
            "assignedGroup": self.resolver_group,
            "type": SIM_TEMPLATE["type"],
            "priority": priority or DEFAULT_PRIORITY,
            "tags": AUTO_TAGS + ([category.lower().replace(" ", "-")] if category else []),
            "cti": SIM_CTI,
        }

    def triage_request(self, request_text: str, existing_issues: Optional[list[dict]] = None) -> dict:
        """Run the full triage workflow for a BI request."""
        issues = existing_issues or self.cached_issues
        result = self.analyze_similarity(request_text, issues)
        if result["recommendation"] == "NEW":
            result["creation_params"] = self.build_sim_creation_params(
                title=request_text[:100], description=request_text, category=result["category"],
            )
        return result
