"""
Similarity engine for matching BI requests against existing SIM issues.

Uses keyword-based + fuzzy matching to find duplicate or related requests.
No external ML dependencies — lightweight and fast.
"""

import re
from collections import Counter
from typing import Optional


def tokenize(text: str) -> list[str]:
    """Extract meaningful tokens from text, lowercased and cleaned."""
    if not text:
        return []
    # Remove common stop words and noise
    stop_words = {
        "the", "a", "an", "is", "are", "was", "were", "be", "been", "being",
        "have", "has", "had", "do", "does", "did", "will", "would", "could",
        "should", "may", "might", "can", "shall", "to", "of", "in", "for",
        "on", "with", "at", "by", "from", "as", "into", "through", "during",
        "before", "after", "above", "below", "between", "and", "but", "or",
        "not", "no", "nor", "so", "yet", "both", "either", "neither", "each",
        "every", "all", "any", "few", "more", "most", "other", "some", "such",
        "than", "too", "very", "just", "also", "i", "we", "you", "they", "it",
        "this", "that", "these", "those", "my", "our", "your", "their", "its",
        "me", "us", "him", "her", "them", "need", "want", "please", "new",
    }
    tokens = re.findall(r'\b[a-z][a-z0-9]+\b', text.lower())
    return [t for t in tokens if t not in stop_words and len(t) > 2]


def compute_similarity(text_a: str, text_b: str) -> float:
    """
    Compute similarity between two texts using cosine similarity on token frequencies.

    Returns a score between 0.0 (no match) and 1.0 (identical).
    """
    tokens_a = tokenize(text_a)
    tokens_b = tokenize(text_b)

    if not tokens_a or not tokens_b:
        return 0.0

    counter_a = Counter(tokens_a)
    counter_b = Counter(tokens_b)

    # All unique tokens
    all_tokens = set(counter_a.keys()) | set(counter_b.keys())

    # Cosine similarity
    dot_product = sum(counter_a.get(t, 0) * counter_b.get(t, 0) for t in all_tokens)
    magnitude_a = sum(v ** 2 for v in counter_a.values()) ** 0.5
    magnitude_b = sum(v ** 2 for v in counter_b.values()) ** 0.5

    if magnitude_a == 0 or magnitude_b == 0:
        return 0.0

    return dot_product / (magnitude_a * magnitude_b)


def find_keyword_overlap(request_text: str, sim_text: str) -> list[str]:
    """Find overlapping meaningful keywords between request and SIM."""
    tokens_req = set(tokenize(request_text))
    tokens_sim = set(tokenize(sim_text))
    return sorted(tokens_req & tokens_sim)


def rank_similar_issues(
    request_text: str,
    issues: list[dict],
    threshold: float = 0.4,
    max_results: int = 5,
) -> list[dict]:
    """
    Rank existing SIM issues by similarity to the incoming request.

    Args:
        request_text: The user's BI request description
        issues: List of SIM issue dicts with 'name' and 'description' fields
        threshold: Minimum similarity score to include
        max_results: Maximum number of results to return

    Returns:
        List of dicts with issue info + similarity score, sorted by score desc
    """
    scored = []

    for issue in issues:
        # Combine title and description for matching
        issue_text = f"{issue.get('name', '')} {issue.get('description', '')}"
        tags_text = " ".join(issue.get("tags", []))
        full_issue_text = f"{issue_text} {tags_text}"

        score = compute_similarity(request_text, full_issue_text)
        overlapping_keywords = find_keyword_overlap(request_text, full_issue_text)

        if score >= threshold:
            scored.append({
                "issue_id": issue.get("id", ""),
                "issue_name": issue.get("name", ""),
                "status": issue.get("status", ""),
                "similarity_score": round(score, 3),
                "overlapping_keywords": overlapping_keywords,
                "assignee": issue.get("assignee", ""),
            })

    # Sort by similarity score descending
    scored.sort(key=lambda x: x["similarity_score"], reverse=True)
    return scored[:max_results]


def categorize_request(request_text: str, categories: list[str]) -> Optional[str]:
    """
    Auto-categorize a BI request into one of the predefined categories.

    Uses keyword matching against category names and common synonyms.
    """
    category_keywords = {
        "Dashboard": ["dashboard", "viz", "visualization", "visual", "chart", "graph", "tableau", "quicksight"],
        "Report": ["report", "reporting", "weekly", "monthly", "daily", "summary", "metrics"],
        "Data Extract": ["extract", "export", "download", "pull", "dump", "csv", "excel"],
        "Data Pipeline": ["pipeline", "etl", "ingestion", "flow", "automation", "scheduled", "job"],
        "Data Quality": ["quality", "validation", "accuracy", "reconciliation", "audit", "check", "discrepancy"],
        "Ad-hoc Analysis": ["analysis", "analyze", "investigate", "deep dive", "adhoc", "ad-hoc", "one-time"],
    }

    tokens = set(tokenize(request_text))
    best_category = "Other"
    best_score = 0

    for category, keywords in category_keywords.items():
        if category in categories:
            keyword_tokens = set(tokenize(" ".join(keywords)))
            overlap = len(tokens & keyword_tokens)
            if overlap > best_score:
                best_score = overlap
                best_category = category

    return best_category
