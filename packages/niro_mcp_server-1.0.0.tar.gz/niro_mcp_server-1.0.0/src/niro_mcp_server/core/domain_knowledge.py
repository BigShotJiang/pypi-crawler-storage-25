"""
NIRO Domain Knowledge Store

Loads bi_domain_knowledge.yaml and provides typed lookup methods for
metric definitions, lineage, deprecation warnings, freshness checks,
HVE proximity, area routing, WBR criticality, and self-service answers.
"""

import logging
from datetime import date, datetime, timedelta
from typing import Optional

import yaml

from niro_mcp_server.core.config import AREA_ROUTING
from niro_mcp_server.core.models import (
    FreshnessEntry,
    MetricEntry,
    MetricLineage,
    SeasonalEvent,
)

logger = logging.getLogger(__name__)


class DomainKnowledgeStore:
    """Queryable store for the AU-SG Retail BI domain knowledge base."""

    def __init__(self, data: dict):
        raw = data or {}

        # -- Metric Dictionary --
        self.metrics: dict[str, MetricEntry] = {}
        self._alias_index: dict[str, str] = {}  # lowercase alias -> metric name
        for entry in raw.get("metric_dictionary", []) or []:
            me = MetricEntry(
                name=entry.get("name", ""),
                definition=entry.get("definition", ""),
                formula=entry.get("formula") or "",
                source_table=entry.get("source_table", ""),
                etl_job=entry.get("etl_job", ""),
                dashboard=entry.get("dashboard", ""),
                aliases=entry.get("aliases") or [],
            )
            self.metrics[me.name] = me
            # Index by lowercase name and aliases for case-insensitive lookup
            self._alias_index[me.name.lower()] = me.name
            for alias in me.aliases:
                self._alias_index[alias.lower()] = me.name

        # -- Deprecation Mappings --
        self.deprecations: list[dict] = raw.get("deprecation_mappings", []) or []

        # -- Freshness Registry --
        self.freshness_registry: list[dict] = raw.get("freshness_registry", []) or []

        # -- Seasonal Events --
        self.seasonal_events: list[dict] = raw.get("seasonal_events", []) or []

        # -- WBR Schedule --
        self.wbr_schedule: dict = raw.get("wbr_schedule", {}) or {}

        # -- Team Structure --
        self.team_structure: list[dict] = raw.get("team_structure", []) or []

        # -- Dashboard Registry --
        self.dashboard_registry: list[dict] = raw.get("dashboard_registry", []) or []

        # -- Reporting Patterns --
        self.reporting_patterns: list[dict] = raw.get("reporting_patterns", []) or []

        # -- Provider Mappings --
        self.provider_mappings: list[dict] = raw.get("provider_mappings", []) or []

        # -- Raw lineage edges (DataLineageGraph will handle traversal) --
        lineage_data = raw.get("data_lineage_graph", {}) or {}
        self.lineage_edges: list[dict] = lineage_data.get("edges", []) or []

    # -----------------------------------------------------------------
    # Factory
    # -----------------------------------------------------------------

    @classmethod
    def load(cls, yaml_path: str) -> "DomainKnowledgeStore":
        """Load domain knowledge from a YAML file.

        Returns an empty store and logs a warning on missing or malformed file.
        """
        try:
            with open(yaml_path, "r", encoding="utf-8") as fh:
                data = yaml.safe_load(fh)
            if not isinstance(data, dict):
                logger.warning(
                    "YAML file %s did not contain a mapping; using empty store.",
                    yaml_path,
                )
                return cls({})
            return cls(data)
        except FileNotFoundError:
            logger.warning(
                "Domain knowledge file not found: %s — using empty store.",
                yaml_path,
            )
            return cls({})
        except Exception as exc:
            logger.warning(
                "Failed to load domain knowledge from %s: %s — using empty store.",
                yaml_path,
                exc,
            )
            return cls({})

    # -----------------------------------------------------------------
    # Metric Lookups
    # -----------------------------------------------------------------

    def lookup_metric(self, name: str) -> Optional[MetricEntry]:
        """Search by metric name or alias (case-insensitive)."""
        key = self._alias_index.get(name.lower())
        if key:
            return self.metrics.get(key)
        return None

    def resolve_metric_lineage(self, metric_name: str) -> Optional[MetricLineage]:
        """Build a MetricLineage from the metric entry fields."""
        metric = self.lookup_metric(metric_name)
        if metric is None:
            return None
        return MetricLineage(
            metric_name=metric.name,
            business_definition=metric.definition,
            source_table=metric.source_table,
            etl_job=metric.etl_job,
            sql_query="",  # populated by DataLineageGraph when available
            dashboard_visual=metric.dashboard,
        )

    # -----------------------------------------------------------------
    # Deprecation
    # -----------------------------------------------------------------

    def get_deprecation_warning(self, source_name: str) -> Optional[str]:
        """Return a warning message if *source_name* is deprecated, else None."""
        lower = source_name.lower()
        for dep in self.deprecations:
            if dep.get("old_source", "").lower() == lower:
                new = dep.get("new_source", "unknown")
                since = dep.get("deprecated_since", "unknown")
                note = dep.get("note", "")
                msg = (
                    f"'{source_name}' has been deprecated since {since}. "
                    f"Use '{new}' instead."
                )
                if note:
                    msg += f" ({note})"
                return msg
        return None

    # -----------------------------------------------------------------
    # Freshness
    # -----------------------------------------------------------------

    def check_freshness(self, source_name: str) -> Optional[FreshnessEntry]:
        """Look up *source_name* in the freshness registry."""
        lower = source_name.lower()
        for entry in self.freshness_registry:
            if entry.get("source", "").lower() == lower:
                return FreshnessEntry(
                    source_name=entry.get("source", ""),
                    refresh_frequency=entry.get("refresh_frequency", ""),
                    expected_lag_days=entry.get("acceptable_lag_days", 0),
                    expected_time_utc=entry.get("expected_refresh_time", ""),
                    last_known_refresh="",
                )
        return None

    # -----------------------------------------------------------------
    # HVE Proximity
    # -----------------------------------------------------------------

    def check_hve_proximity(
        self, date_str: str = None, window_days: int = 30
    ) -> list[SeasonalEvent]:
        """Return seasonal events within *window_days* of the given date.

        If *date_str* is ``None``, uses today's date.  *date_str* should be
        ISO-format (``YYYY-MM-DD``).
        """
        if date_str:
            try:
                target = datetime.strptime(date_str, "%Y-%m-%d").date()
            except ValueError:
                target = date.today()
        else:
            target = date.today()

        nearby: list[SeasonalEvent] = []
        for ev in self.seasonal_events:
            month_name = ev.get("typical_month")
            if not month_name:
                continue
            try:
                month_num = _month_name_to_number(month_name)
            except ValueError:
                continue
            # Approximate event date as the 15th of the typical month
            event_date = date(target.year, month_num, 15)
            delta = abs((target - event_date).days)
            if delta <= window_days:
                nearby.append(
                    SeasonalEvent(
                        name=ev.get("name", ""),
                        start_date="",
                        end_date="",
                        impact_description=ev.get("description", ""),
                    )
                )
        return nearby

    # -----------------------------------------------------------------
    # Area Routing
    # -----------------------------------------------------------------

    def get_area_assignee(self, text: str) -> Optional[str]:
        """Scan *text* for area keywords and return the matching alias."""
        lower = text.lower()
        for keyword, alias in AREA_ROUTING.items():
            if keyword.lower() in lower:
                return alias
        return None

    # -----------------------------------------------------------------
    # WBR Criticality
    # -----------------------------------------------------------------

    def is_wbr_critical(self, dashboard_name: str) -> bool:
        """Return True if *dashboard_name* is part of any WBR deliverable."""
        deliverables = self.wbr_schedule.get("deliverables", []) or []
        lower = dashboard_name.lower()
        for deliv in deliverables:
            for db in deliv.get("dashboards", []) or []:
                if db.lower() == lower:
                    return True
        return False

    # -----------------------------------------------------------------
    # Self-Service Answers
    # -----------------------------------------------------------------

    def get_self_service_answer(self, query: str) -> Optional[str]:
        """Return a direct answer for known self-service patterns, or None."""
        lower = query.lower()

        # 1. Metric definition lookups
        for name, metric in self.metrics.items():
            if name.lower() in lower or any(
                a.lower() in lower for a in metric.aliases
            ):
                answer = f"**{metric.name}**: {metric.definition}"
                if metric.formula:
                    answer += f"\n\nFormula: `{metric.formula}`"
                answer += (
                    f"\n\nSource table: {metric.source_table} | "
                    f"Dashboard: {metric.dashboard}"
                )
                return answer

        # 2. Dashboard navigation
        for db in self.dashboard_registry:
            db_name = db.get("name", "")
            if db_name.lower() in lower:
                url = db.get("url", "")
                desc = db.get("description", "")
                return (
                    f"**{db_name}**\n\n{desc}\n\n"
                    f"URL: {url}"
                )

        return None


# =====================================================================
# Helpers
# =====================================================================

_MONTH_MAP = {
    "january": 1,
    "february": 2,
    "march": 3,
    "april": 4,
    "may": 5,
    "june": 6,
    "july": 7,
    "august": 8,
    "september": 9,
    "october": 10,
    "november": 11,
    "december": 12,
}


def _month_name_to_number(name: str) -> int:
    """Convert a month name (e.g. 'July') to its number (7)."""
    num = _MONTH_MAP.get(name.lower())
    if num is None:
        raise ValueError(f"Unknown month name: {name}")
    return num
