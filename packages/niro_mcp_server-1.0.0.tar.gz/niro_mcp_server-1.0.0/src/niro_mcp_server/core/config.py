"""
BI Request Agent Configuration

Update these values with your team's SIM folder, CTI, and preferences.
"""

# =============================================================================
# SIM / TASKEI CONFIGURATION
# =============================================================================

# Target SIM folder UUID (AU-SG Retail BI Projects)
# Resolver group: AU-Retail-BI
SIM_FOLDER_ID = "8ecac38e-a131-432a-bb67-956998b2abc6"

# Resolver group name (used for ticket search queries)
SIM_RESOLVER_GROUP = "AU-Retail-BI"

# Room name filter (used to discover room if UUID not set)
SIM_ROOM_NAME_FILTER = "AU Programs & Features/AU-SG Retail BI Projects"

# CTI for new SIM issues (Category / Type / Item)
SIM_CTI = {
    "category": "Retail",
    "type": "AU-BI",
    "item": "Request for AU Retail BI",
}

# Default assignee for new issues (leave empty for unassigned)
DEFAULT_ASSIGNEE = ""

# Default priority for new BI requests
DEFAULT_PRIORITY = "Medium"  # High, Medium, Low

# =============================================================================
# SIMILARITY / DEDUPLICATION SETTINGS
# =============================================================================

# Minimum similarity score to suggest an existing SIM (0.0 to 1.0)
# Higher = stricter matching, fewer false positives
SIMILARITY_THRESHOLD = 0.4

# Maximum number of similar SIMs to show the user
MAX_SIMILAR_RESULTS = 5

# Fields to compare when checking similarity
SIMILARITY_FIELDS = ["name", "description", "tags"]

# =============================================================================
# SIM TEMPLATE FOR NEW ISSUES
# =============================================================================

SIM_TEMPLATE = {
    "type": "STORY",
    "priority": DEFAULT_PRIORITY,
    "description_template": """
## BI Change Request

### Request Summary
{summary}

### Business Justification
{justification}

### Requested By
{requester}

### Data Sources Involved
{data_sources}

### Expected Deliverable
{deliverable}

### Target Completion Date
{target_date}

### Acceptance Criteria
{acceptance_criteria}

---
*Created via BI Request Agent*
""",
}

# =============================================================================
# STORY BOARD / ROLLUP SETTINGS
# =============================================================================

# How to group requests for the story board
GROUPING_CATEGORIES = [
    "Dashboard",
    "Report",
    "Data Extract",
    "Data Pipeline",
    "Data Quality",
    "Ad-hoc Analysis",
    "Other",
]

# Labels to auto-apply to new BI requests
AUTO_LABELS = ["bi-request", "auto-triaged"]

# Tags for categorization
AUTO_TAGS = ["bi-request"]

# =============================================================================
# MIDWAY AUTHENTICATION SETTINGS
# =============================================================================

# Path to the Midway cookie file (~ resolves to current user's home directory)
MIDWAY_COOKIE_PATH = "~/.midway/cookie"

# Hours before a Midway cookie is considered expired
# Conservative: Midway sessions typically last 12-24h
MIDWAY_EXPIRY_HOURS = 20

# =============================================================================
# LLM CONFIGURATION (Amazon Bedrock)
# =============================================================================

# Bedrock model ID for Solution Proposal generation
LLM_MODEL_ID = "anthropic.claude-3-sonnet-20240229-v1:0"

# AWS region for Bedrock API calls
LLM_REGION = "us-west-2"

# Request timeout in seconds for LLM calls
LLM_TIMEOUT_SECONDS = 30

# Fall back to template-based generation when LLM is unavailable
LLM_FALLBACK_ENABLED = True

# Maximum response tokens for LLM generation
LLM_MAX_TOKENS = 4096

# =============================================================================
# SPRINT DATA SETTINGS
# =============================================================================

# SharePoint URL for live sprint Excel file (primary source)
SPRINT_DATA_SHAREPOINT_URL = (
    "https://amazonaus.sharepoint.com/:x:/r/sites/AU-SGRetailBI/"
    "_layouts/15/Doc.aspx?sourcedoc=%7BF77E0F8C-CCA1-4C14-83AC-"
    "72580C989C0E%7D&file=Selection%20SIMs.xlsx&action=default"
    "&mobileredirect=true"
)

# How long (minutes) to cache fetched sprint data in Session_State
SPRINT_DATA_CACHE_TTL_MINUTES = 15

# Local fallback path when SharePoint is unavailable
SPRINT_DATA_LOCAL_FALLBACK_PATH = "../BI Sprint/generate_sprint_gantt_dynamic.py"

# =============================================================================
# DASHBOARD REGISTRY
# =============================================================================

# Curated list of known AU-SG Retail BI QuickSight dashboards
DASHBOARD_REGISTRY = [
    "AU SG Instock Tracker Dashboard",
    "AU SG T1 STR Dashboard",
    "AU SG Removals Hub",
    "AU SoROOS Dashboard",
    "SG SoROOS Dashboard",
    "Project Hawker (Consolidated Pricing Dashboard)",
    "Perfect Launch / Ramp Dashboard",
]

# =============================================================================
# SLACK INTEGRATION
# =============================================================================

# Slack channel ID for the AU-SG Retail BI team
SLACK_CHANNEL_ID = "C02M65M5VMW"

# =============================================================================
# OPERATIONAL INTELLIGENCE SETTINGS
# =============================================================================

# Number of days without comment activity before a SIM is flagged as stale
STALE_SIM_THRESHOLD_DAYS = 7

# Percentage deviation from trailing average to flag an anomaly
ANOMALY_THRESHOLD_PERCENT = 20

# =============================================================================
# USAGE LOGGING
# =============================================================================

# Path to the JSON Lines usage log file
USAGE_LOG_PATH = "niro_usage_log.jsonl"

# =============================================================================
# AREA-OF-RESPONSIBILITY ROUTING
# =============================================================================

# Mapping of BI domain area keywords to team member aliases
# Used by the BI_Agent to suggest a default assignee based on request content
AREA_ROUTING = {
    "Selection": "rkothari",
    "MVR": "rkothari",
    "RVR": "rkothari",
    "Pricing": "adrianw",
    "InStock": "rkothari",
    "X-Border": "rkothari",
    "Category Marketing": "adrianw",
    "Customer Programs": "adrianw",
    "Programs": "andriyat",
    "Amazon Business": "andriyat",
    "AVS": "aravindg",
    "PF": "aravindg",
    "Deals and Events": "rkothari",
}
