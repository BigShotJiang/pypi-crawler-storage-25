"""
NIRO Solution Proposal Generator

Assembles structured Solution_Proposals using LLM-first generation with
template fallback.  The LLM receives BI_Domain_Knowledge as system context
and generates proposals that reason like a senior BIE.  When the LLM is
unavailable, falls back to template-based assembly from domain knowledge,
similarity results, and impact analysis.
"""

import json
import logging
import re
from typing import Optional

from niro_mcp_server.core.domain_knowledge import DomainKnowledgeStore
from niro_mcp_server.core.lineage_graph import DataLineageGraph
from niro_mcp_server.core.models import (
    BIRequest,
    DraftArtifact,
    FeasibilityAssessment,
    ImpactAnalysisResult,
    ImplementationGuidance,
    MetricLineage,
    ResolutionPattern,
    SolutionProposal,
    TechnicalResource,
)

logger = logging.getLogger(__name__)

_DATACENTRAL_RE = re.compile(
    r"https?://datacentral\.a2z\.com/[^\s)>\]\"']+", re.IGNORECASE
)
_HOOT_RE = re.compile(
    r"https?://hoot\.a2z\.com/[^\s)>\]\"']+", re.IGNORECASE
)
_QUICKSIGHT_RE = re.compile(
    r"https?://(?:quicksight\.aws\.amazon\.com|[a-z0-9-]+\.quicksight)[^\s)>\]\"']+",
    re.IGNORECASE,
)
_SQL_FRAGMENT_RE = re.compile(
    r"(?:SELECT|INSERT|UPDATE|DELETE|CREATE|ALTER|WITH)\s.{10,}",
    re.IGNORECASE | re.DOTALL,
)

_LOW_KEYWORDS = {"modify", "update", "change", "tweak", "adjust", "filter", "rename"}
_MEDIUM_KEYWORDS = {"add", "new visual", "new metric", "new column", "new field", "new chart"}
_HIGH_KEYWORDS = {
    "new dashboard", "new data source", "new pipeline", "new etl",
    "integration", "onboard", "migrate",
}


class SolutionProposalGenerator:
    """Generates Solution_Proposals with LLM-first strategy and template fallback."""

    def __init__(
        self,
        domain_knowledge: DomainKnowledgeStore,
        lineage_graph: DataLineageGraph,
        llm_connector=None,
    ):
        self.domain_knowledge = domain_knowledge
        self.lineage_graph = lineage_graph
        self.llm_connector = llm_connector

    def generate(
        self,
        request: BIRequest,
        similar_issues: list[dict],
        domain_knowledge: DomainKnowledgeStore,
        lineage_graph: DataLineageGraph,
        llm_connector=None,
    ) -> SolutionProposal:
        """Generate a full Solution_Proposal.

        Strategy:
        1. If *llm_connector* (or self.llm_connector) is available, try LLM.
        2. On LLM failure or unavailability, fall back to template assembly.
        """
        connector = llm_connector or self.llm_connector
        if connector is not None and getattr(connector, "is_available", False):
            available = (
                connector.is_available
                if isinstance(connector.is_available, bool)
                else connector.is_available
            )
            if available:
                try:
                    return self._generate_via_llm(
                        request, domain_knowledge, lineage_graph, connector
                    )
                except Exception:
                    logger.warning(
                        "LLM proposal generation failed; falling back to template.",
                        exc_info=True,
                    )
        return self._generate_via_template(
            request, similar_issues, domain_knowledge, lineage_graph
        )

    def _generate_via_llm(
        self,
        request: BIRequest,
        domain_knowledge: DomainKnowledgeStore,
        lineage_graph: DataLineageGraph,
        llm_connector,
    ) -> SolutionProposal:
        """Build system + user context, call LLM, parse JSON into SolutionProposal."""
        system_context = self._build_system_context(domain_knowledge, request)
        user_context = self._build_user_context(request)
        result = llm_connector.generate_proposal(system_context, user_context)
        if not result.success or result.data is None:
            raise RuntimeError("LLM returned unsuccessful result")
        return self._parse_llm_response(result.data)

    def _generate_via_template(
        self,
        request: BIRequest,
        similar_issues: list[dict],
        domain_knowledge: DomainKnowledgeStore,
        lineage_graph: DataLineageGraph,
    ) -> SolutionProposal:
        """Assemble a proposal from domain knowledge lookups, resolution
        patterns, and impact analysis."""
        bi_context = self._build_bi_context(request, domain_knowledge, lineage_graph)
        problem_statement = f"Request: {request.title}\n\n{request.description}"
        proposed_approach = self._build_proposed_approach(request, domain_knowledge)

        resolution_patterns = self.extract_resolution_patterns(
            [iss.get("comments", []) for iss in similar_issues if isinstance(iss, dict)]
        )
        impl_guidance = self._build_implementation_guidance(
            request, domain_knowledge, lineage_graph, resolution_patterns
        )
        impact = self._compute_impact(request, lineage_graph)

        all_comments: list[str] = []
        for iss in similar_issues:
            if isinstance(iss, dict):
                all_comments.extend(iss.get("comments", []))
        tech_resources = self.extract_technical_resources(all_comments)

        drafts: list[DraftArtifact] = []
        sql_draft = self.generate_draft_sql(request, domain_knowledge)
        if sql_draft:
            drafts.append(sql_draft)
        qs_draft = self.generate_draft_quicksight(request, domain_knowledge)
        if qs_draft:
            drafts.append(qs_draft)
        etl_draft = self.generate_draft_etl(request, domain_knowledge)
        if etl_draft:
            drafts.append(etl_draft)

        feasibility = self.generate_feasibility(request, similar_issues, domain_knowledge)

        return SolutionProposal(
            bi_context=bi_context,
            problem_statement=problem_statement,
            proposed_approach=proposed_approach,
            draft_artifacts=drafts,
            impact_analysis=impact,
            technical_resources=tech_resources,
            resolution_patterns=resolution_patterns,
            estimated_effort=(
                f"{feasibility.estimated_hours_low:.0f}-"
                f"{feasibility.estimated_hours_high:.0f} hours "
                f"({feasibility.complexity} complexity)"
            ),
            implementation_guidance=impl_guidance,
            feasibility=feasibility,
        )

    def generate_feasibility(
        self,
        request: BIRequest,
        similar_issues: list[dict],
        domain_knowledge: DomainKnowledgeStore,
    ) -> FeasibilityAssessment:
        """Classify complexity and estimate effort."""
        text = f"{request.title} {request.description}".lower()
        complexity = "Medium"
        reasoning_parts: list[str] = []

        if any(kw in text for kw in _HIGH_KEYWORDS):
            complexity = "High"
            reasoning_parts.append("Request involves new data source integration or new dashboard creation.")
        elif any(kw in text for kw in _MEDIUM_KEYWORDS):
            complexity = "Medium"
            reasoning_parts.append("Request involves adding new visuals or data points to an existing dashboard.")
        elif any(kw in text for kw in _LOW_KEYWORDS):
            complexity = "Low"
            reasoning_parts.append("Request involves modifications to existing visuals on a known dashboard.")

        if request.dashboard and domain_knowledge.is_wbr_critical(request.dashboard):
            reasoning_parts.append(f"Dashboard '{request.dashboard}' is WBR-critical.")

        completed_count = sum(
            1 for iss in similar_issues
            if isinstance(iss, dict) and iss.get("status", "").lower() in ("closed", "resolved", "completed")
        )

        if completed_count >= 2:
            hours_low = max(1.0, completed_count * 1.5)
            hours_high = max(hours_low + 2, completed_count * 3.0)
            reasoning_parts.append(f"Effort estimated from {completed_count} similar completed SIMs.")
        else:
            effort_map = {"Low": (2.0, 4.0), "Medium": (4.0, 12.0), "High": (12.0, 40.0)}
            hours_low, hours_high = effort_map[complexity]
            reasoning_parts.append("Effort estimated from complexity defaults (insufficient historical SIMs).")

        return FeasibilityAssessment(
            complexity=complexity,
            reasoning=" ".join(reasoning_parts),
            estimated_hours_low=hours_low,
            estimated_hours_high=hours_high,
            historical_sim_count=completed_count,
        )

    @staticmethod
    def extract_technical_resources(comments: list[str]) -> list[TechnicalResource]:
        """Scan SIM comments for DataCentral links, Hoot links, QuickSight URLs, and SQL fragments."""
        resources: list[TechnicalResource] = []
        seen_urls: set[str] = set()
        for comment in comments or []:
            if not isinstance(comment, str):
                continue
            for m in _DATACENTRAL_RE.finditer(comment):
                url = m.group(0)
                if url not in seen_urls:
                    seen_urls.add(url)
                    resources.append(TechnicalResource(resource_type="datacentral", name=_extract_resource_name(url, "DataCentral"), url=url, description="DataCentral ETL job link"))
            for m in _HOOT_RE.finditer(comment):
                url = m.group(0)
                if url not in seen_urls:
                    seen_urls.add(url)
                    resources.append(TechnicalResource(resource_type="hoot", name=_extract_resource_name(url, "Hoot"), url=url, description="Hoot table provider link"))
            for m in _QUICKSIGHT_RE.finditer(comment):
                url = m.group(0)
                if url not in seen_urls:
                    seen_urls.add(url)
                    resources.append(TechnicalResource(resource_type="quicksight", name=_extract_resource_name(url, "QuickSight"), url=url, description="QuickSight dashboard URL"))
            for m in _SQL_FRAGMENT_RE.finditer(comment):
                fragment = m.group(0).strip()[:500]
                frag_key = fragment[:80]
                if frag_key not in seen_urls:
                    seen_urls.add(frag_key)
                    resources.append(TechnicalResource(resource_type="sql", name="SQL fragment", url="", description=fragment))
        return resources

    @staticmethod
    def extract_resolution_patterns(comments: list[str]) -> list[ResolutionPattern]:
        """Extract step-by-step resolution patterns from completed SIM comments."""
        patterns: list[ResolutionPattern] = []
        for comment in comments or []:
            if not isinstance(comment, str):
                continue
            step_matches = re.findall(r"(?:^|\n)\s*\d+[.)]\s*(.+)", comment)
            if len(step_matches) >= 2:
                patterns.append(ResolutionPattern(pattern_name="Extracted resolution steps", description="Steps extracted from SIM comment", steps=[s.strip() for s in step_matches], source_sim_id=""))
                continue
            bullet_matches = re.findall(r"(?:^|\n)\s*[-*]\s+(.+)", comment)
            if len(bullet_matches) >= 2:
                patterns.append(ResolutionPattern(pattern_name="Extracted resolution steps", description="Steps extracted from SIM comment", steps=[s.strip() for s in bullet_matches], source_sim_id=""))
        return patterns

    def generate_draft_sql(self, request: BIRequest, domain_knowledge: DomainKnowledgeStore) -> Optional[DraftArtifact]:
        """Generate draft SQL based on metric lineage."""
        lineage = self._find_metric_lineage(request, domain_knowledge)
        if lineage is None:
            return None
        sql_lines = [
            f"-- Draft SQL for: {request.title}",
            f"-- Source table: {lineage.source_table}",
            f"-- Metric: {lineage.metric_name} — {lineage.business_definition}",
            "", "SELECT",
        ]
        if lineage.metric_name.upper() == "ASP":
            sql_lines.append("    SUM(ordered_revenue) / NULLIF(SUM(ordered_units), 0) AS asp,")
        elif "selection" in lineage.metric_name.lower():
            sql_lines.append("    SUM(ftac_asins) / NULLIF(SUM(total_buyable_asins), 0) AS selection_efficiency,")
        else:
            sql_lines.append(f"    /* Add calculated field for {lineage.metric_name} */")
        sql_lines.extend([
            "    marketplace_id,", "    report_date",
            f"FROM {lineage.source_table}",
            "WHERE report_date BETWEEN :start_date AND :end_date",
            "GROUP BY marketplace_id, report_date",
            "ORDER BY report_date DESC;",
        ])
        return DraftArtifact(
            artifact_type="sql", title=f"Draft SQL — {lineage.metric_name}",
            content="\n".join(sql_lines),
            description=f"Draft SQL query referencing {lineage.source_table} for metric {lineage.metric_name}. ETL job: {lineage.etl_job}. Dashboard: {lineage.dashboard_visual}.",
        )

    def generate_draft_quicksight(self, request: BIRequest, domain_knowledge: DomainKnowledgeStore) -> Optional[DraftArtifact]:
        """Generate QuickSight configuration suggestions."""
        if not request.dashboard:
            return None
        db_entry = None
        for db in domain_knowledge.dashboard_registry:
            if db.get("name", "").lower() == request.dashboard.lower():
                db_entry = db
                break
        if db_entry is None:
            return None
        config_lines = [
            f"# QuickSight Configuration Suggestion",
            f"# Dashboard: {db_entry.get('name', '')}",
            f"# URL: {db_entry.get('url', '')}",
            "", "## Suggested Changes",
            f"- Target dashboard: {db_entry.get('name', '')}",
            f"- Data sources: {', '.join(db_entry.get('data_sources', []))}",
            "", "## Recommended Visual Configuration",
            f"- Visual type: Table or Bar Chart (based on request context)",
            f"- Dataset: Linked to {', '.join(db_entry.get('data_sources', []))}",
            f"- Filters: marketplace_id, report_date range",
        ]
        return DraftArtifact(
            artifact_type="quicksight", title=f"QuickSight Config — {db_entry.get('name', '')}",
            content="\n".join(config_lines),
            description=f"QuickSight configuration suggestions for {db_entry.get('name', '')}.",
        )

    def generate_draft_etl(self, request: BIRequest, domain_knowledge: DomainKnowledgeStore) -> Optional[DraftArtifact]:
        """Generate ETL job modification proposals."""
        lineage = self._find_metric_lineage(request, domain_knowledge)
        if lineage is None or not lineage.etl_job:
            return None
        text_lower = f"{request.title} {request.description}".lower()
        etl_keywords = {"etl", "pipeline", "job", "ingestion", "data source", "schedule"}
        if not any(kw in text_lower for kw in etl_keywords):
            return None
        etl_lines = [
            f"# ETL Modification Proposal", f"# Job: {lineage.etl_job}",
            f"# Source table: {lineage.source_table}", "",
            "## Proposed Changes", f"- ETL job: {lineage.etl_job}",
            f"- Source: {lineage.source_table}",
            f"- Target: Verify target table schema accommodates new fields", "",
            "## Steps",
            f"1. Review current {lineage.etl_job} configuration in DataCentral",
            f"2. Modify transformation logic as needed",
            f"3. Update target table DDL if schema changes required",
            f"4. Test with sample data run",
            f"5. Schedule and monitor first production run",
        ]
        return DraftArtifact(
            artifact_type="etl", title=f"ETL Proposal — {lineage.etl_job}",
            content="\n".join(etl_lines),
            description=f"ETL job modification proposal for {lineage.etl_job} sourcing from {lineage.source_table}.",
        )

    @staticmethod
    def _build_system_context(domain_knowledge: DomainKnowledgeStore, request: BIRequest) -> str:
        """Build the LLM system prompt from domain knowledge."""
        parts: list[str] = [
            "You are a senior BIE for the AU-SG Retail BI team.",
            "Generate a structured Solution_Proposal as JSON with fields: "
            "bi_context, problem_statement, proposed_approach, "
            "implementation_guidance (where_to_fix, how_to_fix, what_was_done_before), "
            "draft_artifacts, estimated_effort.", "", "## Metric Dictionary",
        ]
        for name, metric in domain_knowledge.metrics.items():
            parts.append(f"- {metric.name}: {metric.definition} (source: {metric.source_table}, dashboard: {metric.dashboard})")
        parts.append("")
        parts.append("## Data Lineage Edges")
        for edge in domain_knowledge.lineage_edges[:20]:
            parts.append(f"- {edge.get('source', '')} -> {edge.get('target', '')} [{edge.get('type', '')}]")
        parts.append("")
        parts.append("## Reporting Patterns")
        for pat in domain_knowledge.reporting_patterns[:5]:
            parts.append(f"- {pat.get('pattern', '')}: {pat.get('description', '')}")
        return "\n".join(parts)

    @staticmethod
    def _build_user_context(request: BIRequest) -> str:
        """Build the LLM user prompt from request details."""
        return "\n".join([
            "## Request", f"Title: {request.title}",
            f"Description: {request.description}",
            f"Dashboard: {request.dashboard or 'Not specified'}",
            f"Type: {request.request_type or 'Not specified'}",
            f"Urgency: {request.urgency or 'Medium'}",
        ])

    @staticmethod
    def _parse_llm_response(data: dict) -> SolutionProposal:
        """Parse structured JSON from LLM into a SolutionProposal."""
        impl_data = data.get("implementation_guidance", {}) or {}
        impl_guidance = ImplementationGuidance(
            where_to_fix=impl_data.get("where_to_fix", ""),
            how_to_fix=impl_data.get("how_to_fix", ""),
            what_was_done_before=impl_data.get("what_was_done_before", ""),
        )
        draft_artifacts: list[DraftArtifact] = []
        for art in data.get("draft_artifacts", []) or []:
            if isinstance(art, dict):
                draft_artifacts.append(DraftArtifact(
                    artifact_type=art.get("artifact_type", ""),
                    title=art.get("title", ""),
                    content=art.get("content", ""),
                    description=art.get("description", ""),
                ))
        return SolutionProposal(
            bi_context=data.get("bi_context", ""),
            problem_statement=data.get("problem_statement", ""),
            proposed_approach=data.get("proposed_approach", ""),
            draft_artifacts=draft_artifacts,
            estimated_effort=data.get("estimated_effort", ""),
            implementation_guidance=impl_guidance,
        )

    @staticmethod
    def _build_bi_context(request: BIRequest, domain_knowledge: DomainKnowledgeStore, lineage_graph: DataLineageGraph) -> str:
        """Build BI context from metric lineage and team conventions."""
        parts: list[str] = []
        text = f"{request.title} {request.description}"
        for name, metric in domain_knowledge.metrics.items():
            name_lower = name.lower()
            aliases = [a.lower() for a in metric.aliases]
            if name_lower in text.lower() or any(a in text.lower() for a in aliases):
                lineage = domain_knowledge.resolve_metric_lineage(name)
                if lineage:
                    parts.append(f"Metric '{lineage.metric_name}': {lineage.business_definition}. Source: {lineage.source_table} -> ETL: {lineage.etl_job} -> Dashboard: {lineage.dashboard_visual}.")
        for word in text.split():
            warning = domain_knowledge.get_deprecation_warning(word)
            if warning and warning not in parts:
                parts.append(f"Warning: {warning}")
        if request.dashboard and domain_knowledge.is_wbr_critical(request.dashboard):
            parts.append(f"Dashboard '{request.dashboard}' is WBR-critical — changes require extra validation before the next WBR deadline.")
        if not parts:
            parts.append("This request relates to the AU-SG Retail BI ecosystem. Generated via template (LLM unavailable).")
        return "\n".join(parts)

    @staticmethod
    def _build_proposed_approach(request: BIRequest, domain_knowledge: DomainKnowledgeStore) -> str:
        """Build proposed approach from reporting patterns."""
        text_lower = f"{request.title} {request.description}".lower()
        matched_patterns: list[dict] = []
        for pat in domain_knowledge.reporting_patterns:
            pattern_name = pat.get("pattern", "").lower()
            description = pat.get("description", "").lower()
            if any(word in text_lower for word in pattern_name.split() if len(word) > 3) or any(word in text_lower for word in description.split() if len(word) > 3):
                matched_patterns.append(pat)
        if not matched_patterns:
            return "Approach: Review the request details, identify affected data sources and dashboards, implement changes following team conventions, and validate before publishing."
        parts: list[str] = []
        for pat in matched_patterns[:2]:
            steps = pat.get("typical_steps", [])
            parts.append(f"**{pat.get('pattern', '')}**: {pat.get('description', '')}")
            for i, step in enumerate(steps, 1):
                parts.append(f"  {i}. {step}")
            effort = pat.get("typical_effort_hours", "")
            if effort:
                parts.append(f"  Typical effort: ~{effort} hours")
        return "\n".join(parts)

    @staticmethod
    def _build_implementation_guidance(request: BIRequest, domain_knowledge: DomainKnowledgeStore, lineage_graph: DataLineageGraph, resolution_patterns: list[ResolutionPattern]) -> ImplementationGuidance:
        """Build implementation guidance from domain knowledge and patterns."""
        where_parts: list[str] = []
        text = f"{request.title} {request.description}"
        for name, metric in domain_knowledge.metrics.items():
            if name.lower() in text.lower():
                where_parts.append(f"{metric.dashboard} (source: {metric.source_table}, ETL: {metric.etl_job})")
        if request.dashboard and not where_parts:
            where_parts.append(request.dashboard)
        where_to_fix = "; ".join(where_parts) if where_parts else "To be determined based on further analysis."
        how_parts: list[str] = []
        if resolution_patterns:
            best = resolution_patterns[0]
            how_parts.append(f"Based on pattern: {best.pattern_name}")
            for step in best.steps[:5]:
                how_parts.append(f"  - {step}")
        else:
            how_parts.append("Follow standard team conventions for the identified dashboard/data source.")
        how_to_fix = "\n".join(how_parts)
        what_parts: list[str] = []
        if resolution_patterns:
            for rp in resolution_patterns[:2]:
                if rp.source_sim_id:
                    what_parts.append(f"SIM {rp.source_sim_id}: {rp.description}")
                else:
                    what_parts.append(rp.description)
        what_was_done_before = "; ".join(what_parts) if what_parts else "No directly matching historical SIMs found."
        return ImplementationGuidance(where_to_fix=where_to_fix, how_to_fix=how_to_fix, what_was_done_before=what_was_done_before)

    @staticmethod
    def _compute_impact(request: BIRequest, lineage_graph: DataLineageGraph) -> Optional[ImpactAnalysisResult]:
        """Run impact analysis on data sources mentioned in the request."""
        text = f"{request.title} {request.description}"
        for node in lineage_graph.adjacency:
            if node.lower() in text.lower():
                return lineage_graph.impact_analysis(node)
        return None

    @staticmethod
    def _find_metric_lineage(request: BIRequest, domain_knowledge: DomainKnowledgeStore) -> Optional[MetricLineage]:
        """Find the first matching metric lineage for the request."""
        text = f"{request.title} {request.description}".lower()
        for name in domain_knowledge.metrics:
            metric = domain_knowledge.metrics[name]
            if name.lower() in text or any(a.lower() in text for a in metric.aliases):
                return domain_knowledge.resolve_metric_lineage(name)
        return None


def _extract_resource_name(url: str, prefix: str) -> str:
    """Extract a human-readable name from a URL."""
    parts = url.rstrip("/").split("/")
    name = parts[-1] if parts else url
    if "?" in name:
        name = name.split("?")[0]
    return f"{prefix}: {name}" if name else prefix
