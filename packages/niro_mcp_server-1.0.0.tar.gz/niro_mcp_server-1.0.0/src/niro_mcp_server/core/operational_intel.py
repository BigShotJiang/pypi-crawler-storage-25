"""
NIRO Operational Intelligence

Proactive status synthesis from multiple sources: SIM tickets, DataCentral
job health, sprint progress, and Slack activity.
"""

import logging
from datetime import datetime, timedelta, timezone
from typing import Optional

from niro_mcp_server.core.domain_knowledge import DomainKnowledgeStore
from niro_mcp_server.core.lineage_graph import DataLineageGraph
from niro_mcp_server.core.models import (
    JobHealthStatus,
    MCPResult,
    StatusSynthesis,
    WBRReadinessReport,
)

logger = logging.getLogger(__name__)


class OperationalIntelligence:
    """Synthesises operational status from SIM, job health, sprint, and Slack."""

    def __init__(
        self,
        domain_knowledge: DomainKnowledgeStore,
        lineage_graph: DataLineageGraph,
    ):
        self.domain_knowledge = domain_knowledge
        self.lineage_graph = lineage_graph

    # -----------------------------------------------------------------
    # Status synthesis
    # -----------------------------------------------------------------

    def synthesize_status(
        self,
        query: str,
        mcp_connector,
        domain_knowledge: DomainKnowledgeStore,
        sprint_engine=None,
    ) -> StatusSynthesis:
        """Combine SIM status, job health, sprint progress into a unified report."""
        sim_status = ""
        job_health: list[JobHealthStatus] = []
        sprint_progress = ""
        slack_activity = ""

        # -- SIM status --
        if mcp_connector is not None:
            try:
                from niro_mcp_server.core.config import SIM_RESOLVER_GROUP
                result: MCPResult = mcp_connector.search_tickets(
                    resolver_group=SIM_RESOLVER_GROUP,
                    statuses=["Open", "Assigned", "In Progress"],
                    rows=20,
                )
                if result.success and result.data:
                    matching = []
                    query_lower = query.lower()
                    for ticket in result.data:
                        title = (ticket.get("name") or ticket.get("title") or "").lower()
                        desc = (ticket.get("description") or "").lower()
                        if any(w in title or w in desc for w in query_lower.split() if len(w) > 2):
                            matching.append(ticket)
                    if matching:
                        parts = [f"Found {len(matching)} matching SIM(s):"]
                        for t in matching[:5]:
                            tid = t.get("id", "?")
                            tname = t.get("name") or t.get("title") or "Untitled"
                            tstatus = t.get("status", "Unknown")
                            parts.append(f"  - {tid}: {tname} [{tstatus}]")
                        sim_status = "\n".join(parts)
                    else:
                        sim_status = "No matching SIM tickets found for this query."
                else:
                    sim_status = "SIM search returned no results."
            except Exception as exc:
                logger.warning("SIM search failed during status synthesis: %s", exc)
                sim_status = "SIM search unavailable."

        # -- Job health --
        query_lower = query.lower()
        for name, metric in domain_knowledge.metrics.items():
            if name.lower() in query_lower or any(
                a.lower() in query_lower for a in metric.aliases
            ):
                if metric.etl_job:
                    job_health.append(
                        JobHealthStatus(
                            job_id=metric.etl_job,
                            job_name=metric.etl_job,
                            status="Unknown",
                            last_execution="",
                            error_details="",
                        )
                    )

        # -- Sprint progress --
        if sprint_engine is not None:
            try:
                loaded = sprint_engine.load_sprint_data()
                if loaded and hasattr(sprint_engine, "sprint_df") and sprint_engine.sprint_df is not None:
                    sprint_progress = f"Sprint data loaded: {len(sprint_engine.sprint_df)} items."
                else:
                    sprint_progress = "Sprint data not available."
            except Exception:
                sprint_progress = "Sprint data loading failed."

        # -- Compose summary --
        summary_parts: list[str] = []
        if sim_status:
            summary_parts.append(f"SIM: {sim_status}")
        if job_health:
            summary_parts.append(f"Jobs: {len(job_health)} related ETL job(s) identified.")
        if sprint_progress:
            summary_parts.append(f"Sprint: {sprint_progress}")
        if not summary_parts:
            summary_parts.append("No operational data available for this query.")

        now_iso = datetime.now(timezone.utc).isoformat()

        return StatusSynthesis(
            sim_status=sim_status,
            job_health=job_health,
            sprint_progress=sprint_progress,
            slack_activity=slack_activity,
            summary="\n".join(summary_parts),
            timestamp=now_iso,
        )

    # -----------------------------------------------------------------
    # Stale SIM detection
    # -----------------------------------------------------------------

    def detect_stale_sims(
        self,
        issues: list[dict],
        threshold_days: int = 7,
    ) -> list[dict]:
        """Flag SIMs with no comment activity beyond *threshold_days*."""
        stale: list[dict] = []
        now = datetime.now(timezone.utc)
        cutoff = now - timedelta(days=threshold_days)

        for issue in issues or []:
            status = (issue.get("status") or "").lower()
            if status in ("closed", "resolved", "completed"):
                continue

            ts_str = (
                issue.get("last_comment_timestamp")
                or issue.get("lastUpdatedDate")
                or issue.get("last_updated")
                or ""
            )
            if not ts_str:
                continue

            try:
                last_activity = datetime.fromisoformat(
                    ts_str.replace("Z", "+00:00")
                )
                if last_activity.tzinfo is None:
                    last_activity = last_activity.replace(tzinfo=timezone.utc)
            except (ValueError, TypeError):
                continue

            if last_activity < cutoff:
                days_stale = (now - last_activity).days
                stale.append({
                    "id": issue.get("id") or issue.get("issue_id", ""),
                    "title": issue.get("name") or issue.get("title", ""),
                    "status": issue.get("status", ""),
                    "assignee": issue.get("assignee", ""),
                    "last_activity": ts_str,
                    "days_stale": days_stale,
                })

        return stale
