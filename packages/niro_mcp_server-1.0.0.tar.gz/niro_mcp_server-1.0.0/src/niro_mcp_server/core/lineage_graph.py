"""
NIRO Data Lineage Graph

Directed graph for tracing metric lineage and performing impact analysis.
Uses dict-based adjacency lists and BFS traversal with collections.deque.
"""

from collections import deque

from niro_mcp_server.core.models import ImpactAnalysisResult


class DataLineageGraph:
    """Directed graph built from YAML edge definitions.

    Each edge dict has: source, target, type.
    The ``type`` field describes the kind of the *source* node
    (e.g. "table", "etl", "query").
    """

    def __init__(self, edges: list[dict]):
        self.adjacency: dict[str, list[str]] = {}   # node -> downstream nodes
        self.reverse: dict[str, list[str]] = {}      # node -> upstream nodes
        self.node_types: dict[str, str] = {}         # node -> type label

        for edge in edges or []:
            src = edge.get("source", "")
            tgt = edge.get("target", "")
            edge_type = edge.get("type", "")

            if not src or not tgt:
                continue

            # Forward adjacency
            self.adjacency.setdefault(src, [])
            if tgt not in self.adjacency[src]:
                self.adjacency[src].append(tgt)

            # Reverse adjacency
            self.reverse.setdefault(tgt, [])
            if src not in self.reverse[tgt]:
                self.reverse[tgt].append(src)

            # Ensure every node appears as a key in both dicts
            self.adjacency.setdefault(tgt, [])
            self.reverse.setdefault(src, [])

            # Store node type from edge type field (source node's type)
            if edge_type and src not in self.node_types:
                self.node_types[src] = edge_type

    # ------------------------------------------------------------------
    # BFS helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _bfs(graph: dict[str, list[str]], start: str) -> list[str]:
        """BFS traversal from *start*, returning all reachable nodes
        (excluding *start* itself) in traversal order."""
        visited: set[str] = set()
        result: list[str] = []
        queue: deque[str] = deque()

        visited.add(start)
        queue.append(start)

        while queue:
            current = queue.popleft()
            for neighbour in graph.get(current, []):
                if neighbour not in visited:
                    visited.add(neighbour)
                    result.append(neighbour)
                    queue.append(neighbour)

        return result

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def trace_upstream(self, node: str) -> list[str]:
        """Return all upstream nodes reachable from *node* via BFS
        on the reverse graph, in traversal order."""
        return self._bfs(self.reverse, node)

    def trace_downstream(self, node: str) -> list[str]:
        """Return all downstream nodes reachable from *node* via BFS
        on the forward graph, in traversal order."""
        return self._bfs(self.adjacency, node)

    def impact_analysis(self, node: str) -> ImpactAnalysisResult:
        """Trace downstream from *node* and categorise affected artifacts
        into dashboards, reports, ETL jobs, and metrics."""
        downstream = self.trace_downstream(node)

        dashboards: list[str] = []
        reports: list[str] = []
        etl_jobs: list[str] = []
        metrics: list[str] = []

        for n in downstream:
            ntype = self.node_types.get(n, "")
            lower_name = n.lower()

            # Categorise using stored type first, then naming conventions
            if ntype == "query" or "dashboard" in lower_name:
                dashboards.append(n)
            elif "report" in lower_name:
                reports.append(n)
            elif ntype == "etl" or "etl" in lower_name or "job" in lower_name:
                etl_jobs.append(n)
            elif ntype == "table" or "metric" in lower_name:
                metrics.append(n)
            else:
                # Fall back: queries go to dashboards bucket
                if "query" in lower_name:
                    dashboards.append(n)
                else:
                    # Uncategorised — add to reports as a catch-all
                    reports.append(n)

        parts: list[str] = []
        if dashboards:
            parts.append(f"{len(dashboards)} dashboard(s)")
        if reports:
            parts.append(f"{len(reports)} report(s)")
        if etl_jobs:
            parts.append(f"{len(etl_jobs)} ETL job(s)")
        if metrics:
            parts.append(f"{len(metrics)} metric(s)")

        summary = (
            f"Change to '{node}' affects {', '.join(parts)}."
            if parts
            else f"No downstream artifacts affected by '{node}'."
        )

        return ImpactAnalysisResult(
            affected_dashboards=dashboards,
            affected_reports=reports,
            affected_etl_jobs=etl_jobs,
            affected_metrics=metrics,
            summary=summary,
        )

    def resolve_lineage(self, source: str, target: str) -> list[str]:
        """Find a path from *source* to *target* using BFS on the
        forward graph.  Returns the full path as a list of node names,
        or an empty list if no path exists."""
        if source == target:
            return [source]

        visited: set[str] = {source}
        queue: deque[list[str]] = deque([[source]])

        while queue:
            path = queue.popleft()
            current = path[-1]
            for neighbour in self.adjacency.get(current, []):
                if neighbour not in visited:
                    new_path = path + [neighbour]
                    if neighbour == target:
                        return new_path
                    visited.add(neighbour)
                    queue.append(new_path)

        return []
