"""
NIRO Data Quality Checker

Performs data quality checks, discrepancy tracing through the lineage graph,
freshness monitoring, and anomaly detection for the AU-SG Retail BI ecosystem.
"""

import logging
from typing import Optional

from niro_mcp_server.core.domain_knowledge import DomainKnowledgeStore
from niro_mcp_server.core.lineage_graph import DataLineageGraph
from niro_mcp_server.core.models import (
    AnomalyAlert,
    DataQualityCheckResult,
    DiscrepancyTrace,
    FreshnessAlert,
)

logger = logging.getLogger(__name__)


class DataQualityChecker:
    """Data quality monitoring: discrepancy tracing, freshness, anomaly detection."""

    def __init__(
        self,
        domain_knowledge: DomainKnowledgeStore,
        lineage_graph: DataLineageGraph,
    ):
        self.domain_knowledge = domain_knowledge
        self.lineage_graph = lineage_graph

    def trace_discrepancy(
        self, metric_name: str, source_a: str, source_b: str,
        value_a: float, value_b: float, lineage_graph: DataLineageGraph,
    ) -> DiscrepancyTrace:
        """Trace both sides of a reported discrepancy through the lineage graph."""
        path_a = lineage_graph.trace_upstream(source_a)
        path_b = lineage_graph.trace_upstream(source_b)
        set_a = set(path_a)
        set_b = set(path_b)
        common = set_a & set_b
        if common:
            divergence = "unknown"
            for node in path_a:
                if node not in set_b:
                    divergence = node
                    break
            if divergence == "unknown":
                for node in path_b:
                    if node not in set_a:
                        divergence = node
                        break
        else:
            divergence = "No common ancestor found — sources may be independent."
        return DiscrepancyTrace(
            metric_name=metric_name, source_a=source_a, source_b=source_b,
            value_a=value_a, value_b=value_b, divergence_point=divergence,
            lineage_path_a=[source_a] + path_a, lineage_path_b=[source_b] + path_b,
        )

    def check_freshness_all(self, domain_knowledge: DomainKnowledgeStore) -> list[FreshnessAlert]:
        """Check all known sources in the freshness registry."""
        alerts: list[FreshnessAlert] = []
        for entry in domain_knowledge.freshness_registry:
            source_name = entry.get("source", "")
            refresh_freq = entry.get("refresh_frequency", "")
            acceptable_lag = entry.get("acceptable_lag_days", 0)
            alerts.append(FreshnessAlert(
                source_name=source_name,
                expected_refresh=f"{refresh_freq} (lag: {acceptable_lag}d)",
                actual_refresh="", is_stale=False, staleness_hours=0.0,
            ))
        return alerts

    def detect_anomaly(
        self, metric_name: str, current_value: float,
        trailing_average: float, threshold_percent: float,
    ) -> Optional[AnomalyAlert]:
        """Flag a deviation when it exceeds threshold_percent of the trailing average."""
        if trailing_average == 0.0:
            return None
        deviation = abs(current_value - trailing_average)
        deviation_pct = (deviation / abs(trailing_average)) * 100.0
        if deviation_pct > threshold_percent:
            return AnomalyAlert(
                metric_name=metric_name, current_value=current_value,
                trailing_average=trailing_average, deviation_percent=deviation_pct,
            )
        return None
