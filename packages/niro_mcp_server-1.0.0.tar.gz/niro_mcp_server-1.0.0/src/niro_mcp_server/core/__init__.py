# NIRO MCP Server — Core subpackage
