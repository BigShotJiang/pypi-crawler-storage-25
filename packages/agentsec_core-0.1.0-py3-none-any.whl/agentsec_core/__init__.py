"""agentsec-core: Shared security primitives for AI agent protection."""

__version__ = "0.1.0"
