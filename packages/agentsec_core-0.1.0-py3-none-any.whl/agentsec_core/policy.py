"""YAML-based policy engine for AI agent security."""

from __future__ import annotations

import fnmatch
import logging
from pathlib import Path

import yaml

from .schemas import (
    Policy,
    PolicyAction,
    PolicyDecision,
    PolicyRule,
    Violation,
)

logger = logging.getLogger(__name__)


def load_policy(path: str | Path) -> Policy:
    """Load a Policy from a YAML file.

    Raises:
        FileNotFoundError: If the file does not exist.
        ValueError: If the YAML is invalid or cannot be parsed into a Policy.
    """
    file_path = Path(path)
    if not file_path.exists():
        raise FileNotFoundError(f"Policy file not found: {file_path}")

    raw = file_path.read_text(encoding="utf-8")
    return load_policy_from_string(raw)


def load_policy_from_string(yaml_str: str) -> Policy:
    """Parse a Policy from a YAML string.

    Raises:
        ValueError: If the YAML is invalid or cannot be parsed.
    """
    try:
        data = yaml.safe_load(yaml_str)
    except yaml.YAMLError as exc:
        raise ValueError(f"Invalid YAML: {exc}") from exc

    if not isinstance(data, dict):
        raise ValueError("Policy YAML must be a mapping at the top level")

    try:
        return Policy(**data)
    except Exception as exc:
        raise ValueError(f"Cannot parse policy: {exc}") from exc


def _tool_matches_rule(rule: PolicyRule, tool_name: str) -> bool:
    """Check if a tool name matches any of the rule's tool patterns."""
    return any(fnmatch.fnmatch(tool_name, pattern) for pattern in rule.tools)


def _scan_parameters(parameters: dict) -> list[Violation]:
    """Attempt to scan parameters for secrets via the scanner module.

    Returns an empty list if the scanner module is not available.
    """
    try:
        from .scanner import scan_parameters  # type: ignore[import-not-found]

        return scan_parameters(parameters)
    except ImportError:
        logger.debug("Scanner module not available; skipping parameter scan")
        return []


def evaluate(
    policy: Policy,
    tool_name: str,
    parameters: dict | None = None,
) -> PolicyDecision:
    """Evaluate a tool call against a policy.

    Matching logic:
    1. Check each rule's 'tools' patterns against tool_name using fnmatch.
    2. If a rule matches, capture that rule's action.
    3. If parameters are provided, scan for secrets.
    4. If violations are found, return DENY regardless of rule match.
    5. If no rule matches, use policy.default_action.
    """
    matched_rule: PolicyRule | None = None

    for rule in policy.rules:
        if _tool_matches_rule(rule, tool_name):
            matched_rule = rule
            break

    violations: list[Violation] = []
    if parameters:
        violations = _scan_parameters(parameters)

    if violations:
        return PolicyDecision(
            action=PolicyAction.DENY,
            matched_rule=matched_rule,
            violations=violations,
            reason="Secrets detected in parameters",
        )

    if matched_rule is not None:
        return PolicyDecision(
            action=matched_rule.action,
            matched_rule=matched_rule,
            reason=matched_rule.reason,
        )

    return PolicyDecision(
        action=policy.default_action,
        reason=f"No matching rule; using default action '{policy.default_action.value}'",
    )


def merge_policies(*policies: Policy) -> Policy:
    """Merge multiple policies. Later policies override earlier ones.

    Rules are concatenated in order. The default_action comes from the
    last policy in the sequence.
    """
    if not policies:
        return Policy()

    all_rules: list[PolicyRule] = []
    for p in policies:
        all_rules.extend(p.rules)

    last = policies[-1]
    return Policy(
        version=last.version,
        name=last.name,
        description=last.description,
        default_action=last.default_action,
        rules=all_rules,
    )
