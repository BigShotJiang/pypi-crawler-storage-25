"""Secret and pattern scanner for AI agent security."""

from __future__ import annotations

import math
import re
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class PatternRule:
    """A single pattern-based scanning rule."""

    rule_id: str
    pattern: re.Pattern[str]
    description: str
    severity: str  # "ERROR" or "WARN"


@dataclass(frozen=True)
class Violation:
    """A security violation found by the scanner."""

    source: str
    line_number: int
    severity: str  # "ERROR" or "WARN"
    rule_id: str
    message: str
    match_text: str


# ---------------------------------------------------------------------------
# Shannon entropy for high-entropy string detection
# ---------------------------------------------------------------------------

ENTROPY_THRESHOLD = 3.5
HIGH_ENTROPY_PATTERN = re.compile(r"[A-Za-z0-9+/=_-]{20,}")


def shannon_entropy(text: str) -> float:
    """Calculate Shannon entropy of a string."""
    if not text:
        return 0.0
    length = len(text)
    freq: dict[str, int] = {}
    for ch in text:
        freq[ch] = freq.get(ch, 0) + 1
    return -sum(
        (count / length) * math.log2(count / length)
        for count in freq.values()
    )


# ---------------------------------------------------------------------------
# Core pattern rules (SEC001 -- SEC020) ported from security_precommit.py
# ---------------------------------------------------------------------------

PATTERNS: list[PatternRule] = [
    PatternRule("SEC001", re.compile(r"AIzaSy[a-zA-Z0-9_-]{33}"),
                "Google API key (AIzaSy...)", "ERROR"),
    PatternRule("SEC002", re.compile(r"sk-[a-zA-Z0-9]{20,}"),
                "OpenAI/Stripe secret key (sk-...)", "ERROR"),
    PatternRule("SEC003", re.compile(r"ghp_[a-zA-Z0-9]{36}"),
                "GitHub personal access token (ghp_...)", "ERROR"),
    PatternRule("SEC004", re.compile(r"xoxb-[0-9]+-[a-zA-Z0-9]+"),
                "Slack bot token (xoxb-...)", "ERROR"),
    PatternRule("SEC005", re.compile(r"-----BEGIN (RSA |EC |DSA )?PRIVATE KEY-----"),
                "Private key literal", "ERROR"),
    PatternRule("SEC006", re.compile(r"Bearer\s+[A-Za-z0-9\-._~+/]+=*", re.IGNORECASE),
                "Hardcoded Bearer token", "ERROR"),
    PatternRule("SEC007", re.compile(r"AKIA[0-9A-Z]{16}"),
                "AWS Access Key ID (AKIA...)", "ERROR"),
    PatternRule("SEC008", re.compile(
                r"(?:aws_secret|aws_key|secret_access_key)\s*=\s*['\"][A-Za-z0-9/+=]{40}['\"]",
                re.IGNORECASE),
                "AWS Secret Access Key", "ERROR"),
    PatternRule("SEC009", re.compile(
                r"(?:mongodb|postgres|mysql|redis|amqp)://[^\s'\"]+:[^\s'\"]+@[^\s'\"]+",
                re.IGNORECASE),
                "Database connection string with credentials", "ERROR"),
    PatternRule("SEC010", re.compile(
                r"https://hooks\.slack\.com/services/T[A-Z0-9]+/B[A-Z0-9]+/[a-zA-Z0-9]+"),
                "Slack webhook URL", "ERROR"),
    PatternRule("SEC011", re.compile(
                r"https://discord(?:app)?\.com/api/webhooks/\d+/[a-zA-Z0-9_-]+"),
                "Discord webhook URL", "ERROR"),
    PatternRule("SEC012", re.compile(
                r"(?:password|passwd|pwd)\s*[:=]\s*['\"][^'\"]{4,}['\"]", re.IGNORECASE),
                "Hardcoded password assignment", "ERROR"),
    PatternRule("SEC013", re.compile(
                r"eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}"),
                "JWT token literal", "ERROR"),
    PatternRule("SEC014", re.compile(r"AC[a-f0-9]{32}"),
                "Twilio Account SID", "ERROR"),
    PatternRule("SEC015", re.compile(r"SK[a-f0-9]{32}"),
                "Twilio API Key SID", "ERROR"),
    PatternRule("SEC016", re.compile(r"(?:sk|pk|rk)_(?:test|live)_[a-zA-Z0-9]{20,}"),
                "Stripe API key", "ERROR"),
    PatternRule("SEC017", re.compile(r"whsec_[a-zA-Z0-9]+"),
                "Stripe webhook secret", "ERROR"),
    PatternRule("SEC018", re.compile(r"SG\.[a-zA-Z0-9_-]{22}\.[a-zA-Z0-9_-]{43}"),
                "SendGrid API key", "ERROR"),
    PatternRule("SEC019", re.compile(r"key-[a-f0-9]{32}"),
                "Mailgun API key", "ERROR"),
    PatternRule("SEC020", re.compile(r"-----BEGIN CERTIFICATE-----"),
                "Certificate literal in code", "WARN"),
    # PII patterns
    PatternRule("SEC021", re.compile(r"\b\d{3}-\d{2}-\d{4}\b"),
                "Possible SSN (XXX-XX-XXXX)", "ERROR"),
    PatternRule("SEC022", re.compile(r"\b\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{4}\b"),
                "Possible credit card number", "ERROR"),
    PatternRule("SEC023", re.compile(
                r"""(?:email|e_mail)\s*=\s*["'][a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}["']""",
                re.IGNORECASE),
                "Email address in assignment context", "WARN"),
]


# Allowlist for skipping false positives on comments and regex definitions
_COMMENT_PREFIX = re.compile(r"^\s*(?:#|//)")
_REGEX_DEFINITION = re.compile(r"re\.compile\(")


def _is_skippable_line(line: str) -> bool:
    """Check if a line should be skipped (comment, regex definition, docstring)."""
    stripped = line.strip()
    if _COMMENT_PREFIX.match(stripped):
        return True
    if stripped.startswith(("pattern=re.compile", "re.compile(")):
        return True
    if stripped.startswith(('"""', "'''", "- ")):
        return True
    return False


def scan_text(
    text: str,
    source: str = "<inline>",
    rules: list[PatternRule] | None = None,
) -> list[Violation]:
    """Scan a text string for security violations.

    Each line is checked against all patterns. Comments (#, //) are skipped.
    Also runs high-entropy detection.

    Args:
        text: The text content to scan.
        source: Identifier for the source of the text.
        rules: Optional list of PatternRule to use. Defaults to PATTERNS.

    Returns:
        List of Violation objects found.
    """
    active_rules = rules if rules is not None else PATTERNS
    violations: list[Violation] = []

    for lineno, line in enumerate(text.splitlines(), start=1):
        if _is_skippable_line(line):
            continue

        stripped = line.strip()

        for rule in active_rules:
            match = rule.pattern.search(line)
            if match:
                violations.append(Violation(
                    source=source,
                    line_number=lineno,
                    severity=rule.severity,
                    rule_id=rule.rule_id,
                    message=rule.description,
                    match_text=stripped,
                ))

        # High-entropy string detection
        for match in HIGH_ENTROPY_PATTERN.finditer(line):
            candidate = match.group(0)
            entropy = shannon_entropy(candidate)
            if entropy >= ENTROPY_THRESHOLD:
                violations.append(Violation(
                    source=source,
                    line_number=lineno,
                    severity="WARN",
                    rule_id="SEC_ENTROPY",
                    message=f"High-entropy string detected (entropy={entropy:.2f})",
                    match_text=stripped,
                ))

    return violations


def scan_parameters(
    params: dict,
    source: str = "<params>",
    rules: list[PatternRule] | None = None,
) -> list[Violation]:
    """Recursively scan dict values for security violations.

    Converts each value to string and runs scan_text on it.

    Args:
        params: Dictionary of parameters to scan.
        source: Identifier for the source.
        rules: Optional list of PatternRule to use.

    Returns:
        List of Violation objects found.
    """
    violations: list[Violation] = []

    for key, value in params.items():
        param_source = f"{source}.{key}"
        if isinstance(value, dict):
            violations.extend(scan_parameters(value, param_source, rules))
        elif isinstance(value, list):
            for i, item in enumerate(value):
                item_source = f"{param_source}[{i}]"
                if isinstance(item, dict):
                    violations.extend(scan_parameters(item, item_source, rules))
                else:
                    violations.extend(scan_text(str(item), item_source, rules))
        else:
            violations.extend(scan_text(str(value), param_source, rules))

    return violations


SCANNABLE_EXTENSIONS = {
    ".py", ".js", ".ts", ".jsx", ".tsx", ".sh", ".bash",
    ".env", ".yml", ".yaml", ".toml",
}


def scan_file(
    filepath: str,
    rules: list[PatternRule] | None = None,
) -> list[Violation]:
    """Scan a file for security violations.

    Args:
        filepath: Path to the file to scan.
        rules: Optional list of PatternRule to use.

    Returns:
        List of Violation objects found.
    """
    path = Path(filepath)

    if not path.exists():
        return []

    if path.suffix not in SCANNABLE_EXTENSIONS:
        return []

    try:
        content = path.read_text(encoding="utf-8", errors="replace")
    except (OSError, PermissionError):
        return []

    return scan_text(content, filepath, rules)
