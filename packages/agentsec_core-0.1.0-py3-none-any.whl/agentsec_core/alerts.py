"""Webhook alerting for security violations."""

from __future__ import annotations

import json
import logging
import subprocess
from abc import ABC, abstractmethod

from .schemas import AuditEvent, Severity

logger = logging.getLogger(__name__)

_DISCORD_SEVERITY_COLORS: dict[Severity, int] = {
    Severity.CRITICAL: 0xFF0000,
    Severity.ERROR: 0xFF4444,
    Severity.WARNING: 0xFFAA00,
    Severity.INFO: 0x00AA00,
}


class WebhookAlert(ABC):
    """Base class for webhook alerts."""

    def __init__(self, webhook_url: str) -> None:
        from .validators import validate_webhook_url

        self.webhook_url = validate_webhook_url(webhook_url)

    @abstractmethod
    def format_payload(self, event: AuditEvent) -> dict:
        """Format the event into a webhook-specific payload."""

    def send(self, event: AuditEvent) -> bool:
        """Send an alert via curl subprocess. Returns True on success.

        Uses curl instead of ``requests`` / ``urllib`` because Discord
        webhooks return 403 with Python default User-Agent headers.
        """
        payload = self.format_payload(event)
        payload_json = json.dumps(payload)

        try:
            result = subprocess.run(
                [
                    "curl",
                    "-s",
                    "-o", "/dev/null",
                    "-w", "%{http_code}",
                    "-X", "POST",
                    "-H", "Content-Type: application/json",
                    "-H", "User-Agent: AgentSec/1.0",
                    "-d", payload_json,
                    self.webhook_url,
                ],
                capture_output=True,
                text=True,
                timeout=30,
            )
            status_code = result.stdout.strip()
            success = status_code.startswith("2")
            if not success:
                logger.warning(
                    "Webhook returned HTTP %s for %s",
                    status_code,
                    self.webhook_url,
                )
            return success
        except (subprocess.TimeoutExpired, FileNotFoundError) as exc:
            logger.error("Failed to send webhook alert: %s", exc)
            return False


class DiscordAlert(WebhookAlert):
    """Discord webhook alerts with embeds."""

    def format_payload(self, event: AuditEvent) -> dict:
        """Format as Discord embed with colour-coded severity."""
        max_severity = self._max_severity(event)
        color = _DISCORD_SEVERITY_COLORS.get(max_severity, 0x808080)

        fields = [
            {"name": "Tool", "value": event.tool_name or "N/A", "inline": True},
            {"name": "Action", "value": event.action_taken.value, "inline": True},
            {"name": "Event Type", "value": event.event_type, "inline": True},
        ]

        if event.violations:
            violation_text = "\n".join(
                f"- [{v.severity.value.upper()}] {v.message}"
                for v in event.violations[:5]
            )
            fields.append({"name": "Violations", "value": violation_text})

        return {
            "embeds": [
                {
                    "title": f"AgentSec Alert: {event.event_type}",
                    "color": color,
                    "fields": fields,
                    "timestamp": (
                        event.timestamp.isoformat()
                        if event.timestamp
                        else None
                    ),
                }
            ]
        }

    @staticmethod
    def _max_severity(event: AuditEvent) -> Severity:
        """Return the highest severity among the event's violations."""
        if not event.violations:
            return Severity.INFO
        order = [Severity.CRITICAL, Severity.ERROR, Severity.WARNING, Severity.INFO]
        for sev in order:
            if any(v.severity == sev for v in event.violations):
                return sev
        return Severity.INFO


class SlackAlert(WebhookAlert):
    """Slack webhook alerts with Block Kit messages."""

    def format_payload(self, event: AuditEvent) -> dict:
        """Format as Slack Block Kit message."""
        blocks: list[dict] = [
            {
                "type": "header",
                "text": {
                    "type": "plain_text",
                    "text": f"AgentSec Alert: {event.event_type}",
                },
            },
            {
                "type": "section",
                "fields": [
                    {
                        "type": "mrkdwn",
                        "text": f"*Tool:* {event.tool_name or 'N/A'}",
                    },
                    {
                        "type": "mrkdwn",
                        "text": f"*Action:* {event.action_taken.value}",
                    },
                ],
            },
        ]

        if event.violations:
            violation_lines = [
                f"- *[{v.severity.value.upper()}]* {v.message}"
                for v in event.violations[:5]
            ]
            blocks.append(
                {
                    "type": "section",
                    "text": {
                        "type": "mrkdwn",
                        "text": "*Violations:*\n" + "\n".join(violation_lines),
                    },
                }
            )

        return {"blocks": blocks}


def create_alerter(webhook_url: str) -> WebhookAlert:
    """Factory: auto-detect provider from URL pattern.

    Raises:
        ValueError: If the webhook URL format is not recognised.
    """
    if "hooks.slack.com" in webhook_url:
        return SlackAlert(webhook_url)
    if "discord.com/api/webhooks" in webhook_url or "discordapp.com" in webhook_url:
        return DiscordAlert(webhook_url)
    raise ValueError(
        f"Unknown webhook URL format: {webhook_url}. "
        "Supported: Discord (discord.com/api/webhooks) and Slack (hooks.slack.com)."
    )
