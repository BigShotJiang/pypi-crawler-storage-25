"""Immutable append-only audit logger with SHA-256 hash chain."""

from __future__ import annotations

import hashlib
import json
import logging
from datetime import datetime
from pathlib import Path

from .schemas import AuditEvent, PolicyAction

logger = logging.getLogger(__name__)

_GENESIS_SEED = "genesis"


def _compute_hash(previous_hash: str, line: str) -> str:
    """Compute SHA-256 of previous_hash concatenated with line content."""
    payload = previous_hash + line
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _genesis_hash() -> str:
    """Return the SHA-256 hash of the genesis seed."""
    return hashlib.sha256(_GENESIS_SEED.encode("utf-8")).hexdigest()


class AuditLogger:
    """Append-only JSONL logger with tamper-detection hash chain.

    Each line is a JSON object with an added ``_hash`` field containing
    ``SHA-256(previous_hash + json_line)``.  The first line uses
    ``sha256("genesis")`` as the previous hash.
    """

    def __init__(self, log_path: str | Path) -> None:
        """Initialize logger. Creates the file if it doesn't exist."""
        self._path = Path(log_path)
        self._path.parent.mkdir(parents=True, exist_ok=True)
        if not self._path.exists():
            self._path.touch()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def log(self, event: AuditEvent) -> None:
        """Append an event to the audit log with hash chain."""
        previous_hash = self._last_hash()
        line = json.dumps(event.model_dump(mode="json"), separators=(",", ":"))
        entry_hash = _compute_hash(previous_hash, line)

        record = json.loads(line)
        record["_hash"] = entry_hash

        with self._path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(record, separators=(",", ":")) + "\n")

    def query(
        self,
        *,
        tool_name: str | None = None,
        action: PolicyAction | None = None,
        since: datetime | None = None,
        until: datetime | None = None,
    ) -> list[AuditEvent]:
        """Query events matching filters. All filters are AND-combined."""
        results: list[AuditEvent] = []
        for event in self._read_events():
            if tool_name is not None and event.tool_name != tool_name:
                continue
            if action is not None and event.action_taken != action:
                continue
            ts = event.timestamp
            if ts is not None:
                if since is not None and ts < since:
                    continue
                if until is not None and ts > until:
                    continue
            results.append(event)
        return results

    def tail(self, n: int = 10) -> list[AuditEvent]:
        """Return the last *n* events."""
        all_events = self._read_events()
        return all_events[-n:]

    def verify_integrity(self) -> tuple[bool, list[str]]:
        """Verify the hash chain integrity.

        Returns ``(is_valid, errors)`` where *errors* lists any
        mismatches found when recomputing hashes from genesis.
        """
        errors: list[str] = []
        previous_hash = _genesis_hash()
        lines = self._raw_lines()

        for idx, raw_line in enumerate(lines, start=1):
            try:
                record = json.loads(raw_line)
            except json.JSONDecodeError:
                errors.append(f"Line {idx}: invalid JSON")
                continue

            stored_hash = record.pop("_hash", None)
            if stored_hash is None:
                errors.append(f"Line {idx}: missing _hash field")
                continue

            line_without_hash = json.dumps(record, separators=(",", ":"))
            expected_hash = _compute_hash(previous_hash, line_without_hash)

            if stored_hash != expected_hash:
                errors.append(
                    f"Line {idx}: hash mismatch "
                    f"(stored={stored_hash[:12]}... expected={expected_hash[:12]}...)"
                )

            previous_hash = stored_hash

        return (len(errors) == 0, errors)

    def export_json(self, path: str | Path) -> int:
        """Export all events as a JSON array file. Returns event count."""
        events = self._read_events()
        out = [e.model_dump(mode="json") for e in events]
        Path(path).write_text(
            json.dumps(out, indent=2), encoding="utf-8"
        )
        return len(out)

    @property
    def event_count(self) -> int:
        """Return total number of events in the log."""
        return len(self._raw_lines())

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _raw_lines(self) -> list[str]:
        """Read all non-empty lines from the log file."""
        if not self._path.exists():
            return []
        text = self._path.read_text(encoding="utf-8")
        return [ln for ln in text.splitlines() if ln.strip()]

    def _read_events(self) -> list[AuditEvent]:
        """Parse all JSONL lines into AuditEvent objects."""
        events: list[AuditEvent] = []
        for raw_line in self._raw_lines():
            try:
                record = json.loads(raw_line)
                record.pop("_hash", None)
                events.append(AuditEvent(**record))
            except json.JSONDecodeError as exc:
                logger.warning("Skipping unparseable log line: %s", exc)
            except Exception:
                logger.warning("Skipping malformed audit record", exc_info=True)
        return events

    def _last_hash(self) -> str:
        """Return the ``_hash`` of the last entry, or the genesis hash."""
        lines = self._raw_lines()
        if not lines:
            return _genesis_hash()
        try:
            last_record = json.loads(lines[-1])
            return last_record.get("_hash", _genesis_hash())
        except json.JSONDecodeError:
            return _genesis_hash()
