"""Pydantic v2 schema models for agentsec-core."""

from __future__ import annotations

import re
from datetime import datetime, timezone
from enum import Enum

from pydantic import BaseModel, ConfigDict, Field

SAFE_NAME_PATTERN = re.compile(r"^[a-zA-Z0-9_-]+$")


class Severity(str, Enum):
    """Severity levels for security violations."""

    CRITICAL = "critical"
    ERROR = "error"
    WARNING = "warning"
    INFO = "info"


class PolicyAction(str, Enum):
    """Actions a policy rule can enforce."""

    ALLOW = "allow"
    DENY = "deny"
    LOG = "log"
    ALERT = "alert"


class Violation(BaseModel):
    """A single security violation detected during scanning."""

    model_config = ConfigDict(frozen=True)

    rule_id: str
    severity: Severity
    message: str
    source: str = ""
    line_number: int = 0
    match_text: str = ""
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class PolicyRule(BaseModel):
    """A single rule within a security policy."""

    model_config = ConfigDict(frozen=True)

    name: str = ""
    tools: list[str] = Field(default_factory=list)
    resources: list[str] = Field(default_factory=list)
    action: PolicyAction = PolicyAction.DENY
    reason: str = ""


class Policy(BaseModel):
    """A complete security policy containing rules."""

    model_config = ConfigDict(frozen=True)

    version: str = "1.0"
    name: str = "default"
    description: str = ""
    default_action: PolicyAction = PolicyAction.DENY
    rules: list[PolicyRule] = Field(default_factory=list)


class PolicyDecision(BaseModel):
    """Result of evaluating a request against a policy."""

    model_config = ConfigDict(frozen=True)

    action: PolicyAction
    matched_rule: PolicyRule | None = None
    violations: list[Violation] = Field(default_factory=list)
    reason: str = ""


class AuditEvent(BaseModel):
    """An auditable security event for logging and compliance."""

    model_config = ConfigDict(frozen=True)

    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    event_type: str  # "tool_call", "policy_check", "violation", "alert"
    tool_name: str = ""
    action_taken: PolicyAction = PolicyAction.LOG
    violations: list[Violation] = Field(default_factory=list)
    parameters: dict = Field(default_factory=dict)
    metadata: dict = Field(default_factory=dict)
