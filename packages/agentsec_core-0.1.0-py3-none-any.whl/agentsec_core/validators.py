"""Input validation and sanitization utilities for AI agent security."""

from __future__ import annotations

import os
import re
from urllib.parse import urlparse

# E.164: + followed by 1-15 digits
_E164_PATTERN = re.compile(r"^\+[1-9]\d{1,14}$")

# Control characters, newlines, tabs (but preserve spaces)
_CONTROL_CHARS = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f\r\n\t]")

# Characters that enable header injection
_HEADER_UNSAFE = re.compile(r"[\r\n\x00]")

# YAML special characters that could enable injection
_YAML_UNSAFE = re.compile(r"[|>{}[\]:,&*?#!%@`]")

# Known webhook URL patterns
_DISCORD_WEBHOOK = re.compile(
    r"^https://discord(?:app)?\.com/api/webhooks/\d+/[a-zA-Z0-9_-]+$"
)
_SLACK_WEBHOOK = re.compile(
    r"^https://hooks\.slack\.com/services/T[A-Z0-9]+/B[A-Z0-9]+/[a-zA-Z0-9]+$"
)


def require_env(key: str) -> str:
    """Get an environment variable or raise immediately.

    Fail-fast prevents hardcoded fallbacks from masking missing config.

    Args:
        key: Environment variable name.

    Returns:
        The environment variable value.

    Raises:
        RuntimeError: If the variable is not set or is empty.
    """
    value = os.environ.get(key)
    if not value:
        raise RuntimeError(
            f"Required environment variable '{key}' is not set. "
            f"Add it to your .env file or export it before running."
        )
    return value


def validate_phone_e164(phone: str) -> str | None:
    """Validate and return an E.164 phone number, or None if invalid.

    Args:
        phone: Raw phone string from user input.

    Returns:
        Cleaned E.164 string, or None if the input is not valid.
    """
    if not phone:
        return None

    cleaned = re.sub(r"[\s\-\(\).]", "", phone.strip())

    if not cleaned.startswith("+"):
        digits = re.sub(r"\D", "", cleaned)
        if len(digits) == 10:
            cleaned = f"+1{digits}"
        elif len(digits) == 11 and digits.startswith("1"):
            cleaned = f"+{digits}"
        else:
            return None

    if _E164_PATTERN.match(cleaned):
        return cleaned
    return None


def sanitize_name(name: str, max_length: int = 100) -> str:
    """Strip control characters and truncate user-provided names.

    Args:
        name: Raw name string from user input.
        max_length: Maximum allowed length (default 100).

    Returns:
        Sanitized name string, stripped and truncated.

    Raises:
        ValueError: If the result is empty after sanitization.
    """
    if not name or not name.strip():
        raise ValueError("Name cannot be empty.")

    sanitized = _CONTROL_CHARS.sub("", name)
    sanitized = sanitized.strip()

    if not sanitized:
        raise ValueError("Name cannot be empty after sanitization.")

    return sanitized[:max_length]


def sanitize_for_header(value: str) -> str:
    """Strip characters that could cause HTTP/email header injection.

    Args:
        value: Raw string intended for use in a header.

    Returns:
        Sanitized string with injection characters removed.
    """
    if not value:
        return ""

    return _HEADER_UNSAFE.sub("", value).strip()


def validate_url_https(url: str, allow_localhost: bool = False) -> str:
    """Validate that a URL uses HTTPS.

    Args:
        url: URL string to validate.
        allow_localhost: If True, permit http://localhost and http://127.0.0.1.

    Returns:
        The validated URL string.

    Raises:
        ValueError: If the URL is not valid HTTPS (or allowed localhost).
    """
    if not url:
        raise ValueError("URL cannot be empty.")

    parsed = urlparse(url)

    if not parsed.scheme or not parsed.netloc:
        raise ValueError(f"Invalid URL format: {url}")

    if parsed.scheme == "https":
        return url

    if allow_localhost and parsed.scheme == "http":
        host = parsed.hostname or ""
        if host in ("localhost", "127.0.0.1", "0.0.0.0"):
            return url

    raise ValueError(
        f"URL must use HTTPS: {url}. "
        f"Use allow_localhost=True for local development."
    )


def validate_webhook_url(url: str) -> str:
    """Validate Discord or Slack webhook URL format.

    Must be HTTPS and match known webhook URL patterns.

    Args:
        url: Webhook URL to validate.

    Returns:
        The validated webhook URL.

    Raises:
        ValueError: If the URL is not a valid webhook URL.
    """
    if not url:
        raise ValueError("Webhook URL cannot be empty.")

    parsed = urlparse(url)
    if parsed.scheme != "https":
        raise ValueError(f"Webhook URL must use HTTPS: {url}")

    if _DISCORD_WEBHOOK.match(url):
        return url

    if _SLACK_WEBHOOK.match(url):
        return url

    raise ValueError(
        f"Unrecognized webhook URL format: {url}. "
        f"Must match Discord (discord.com/api/webhooks/) "
        f"or Slack (hooks.slack.com/services/) patterns."
    )


def sanitize_yaml_value(value: str) -> str:
    """Prevent YAML injection by escaping special YAML characters.

    Removes characters that could alter YAML parsing: | > {{ }} [ ] : , & * ? # ! % @ `

    Args:
        value: Raw string to sanitize for YAML inclusion.

    Returns:
        Sanitized string safe for YAML values.

    Raises:
        ValueError: If the result is empty after sanitization.
    """
    if not value:
        raise ValueError("YAML value cannot be empty.")

    sanitized = _YAML_UNSAFE.sub("", value).strip()

    if not sanitized:
        raise ValueError("YAML value cannot be empty after sanitization.")

    return sanitized
