import os
from datetime import datetime, timedelta, timezone
from astral import Observer
from astral.sun import sunrise as get_sunrise, sunset as get_sunset
import pytz
from loguru import logger

from solaredge_influxdb.solaredge import Equipment
from solaredge_influxdb.influxdb import InfluxDBClient


def app(
    config_path: str = "./solaredge_influxdb/config.toml",
    latitude: float = os.getenv("LATITUDE", 52.3676),
    longitude: float = os.getenv("LONGITUDE", 4.9041),
    api_key: str = os.getenv("API_KEY"),
    additional_time_window: int = 60,
    timezone_str: str = "Europe/Amsterdam",
    timewindow: int = 15,  # Time window in minutes for collecting technical data, default is 15 minutes
    force: bool = False,
):
    observer = Observer(latitude=latitude, longitude=longitude)
    current_time = datetime.now(timezone.utc)
    logger.debug(f"Current time: {current_time}")
    _timezone = pytz.timezone(timezone_str)
    local_date = current_time.astimezone(_timezone).date()
    try:
        sunrise = get_sunrise(observer, date=local_date, tzinfo=_timezone)
        sunset = get_sunset(observer, date=local_date, tzinfo=_timezone)
        logger.debug(f"Sunrise: {sunrise}, Sunset: {sunset}")

    except ValueError as e:
        logger.error("Failed to retrieve sunrise/sunset times")
        raise RuntimeError("Application requires sunset and sunrise times to prevent unnecessary API calls") from e
    InfluxClient = InfluxDBClient(config_path)

    within_daylight_window = sunrise - timedelta(minutes=additional_time_window) < current_time < sunset + timedelta(
        minutes=additional_time_window
    )
    should_collect = force or within_daylight_window

    if should_collect:
        if force and not within_daylight_window:
            logger.info("Force mode enabled, bypassing daylight-window checks to collect data")
        if within_daylight_window:
            logger.debug("The Sun is shining bright, let's collect some data!")
        else:
            logger.debug("Collecting data because force mode is enabled")
        EquipmentClient = Equipment(api_key)
        current_time = current_time.astimezone(_timezone)
        for inverter in EquipmentClient.inverters:
            tech_data = EquipmentClient.get_technical_data(
                inverter.serialNumber,
                current_time - timedelta(minutes=timewindow),
                current_time,
            )
            if tech_data is None:
                logger.error("Failed to retrieve technical data")
                continue

            for telemetry in tech_data.telemetries:
                tags = [
                    ("serial_number", inverter.serialNumber),
                    ("model", inverter.model),
                    ("operation_mode", telemetry.operationMode),
                    ("inverter_mode", telemetry.inverterMode),
                ]
                telemetry_date = _timezone.localize(telemetry.date)
                energy_point = InfluxClient.convert_to_point(
                    telemetry_date,
                    "solar",
                    [
                        ("total_energy", telemetry.totalEnergy / 1000),
                    ],
                    tags,
                )
                if telemetry.totalActivePower is not None:
                    power_point = InfluxClient.convert_to_point(
                        telemetry_date,
                        "solar",
                        [
                            ("ac_power", telemetry.totalActivePower / 1000),
                        ],
                        tags,
                    )
                else:
                    logger.warning(
                        f"totalActivePower is missing for inverter {inverter.serialNumber} at {telemetry_date}, skipping power write"
                    )
                    power_point = None

                voltage_fields = [
                    ("voltage_l1_to_2", telemetry.vL1To2),
                    ("voltage_l2_to_3", telemetry.vL2To3),
                    ("voltage_l3_to_1", telemetry.vL3To1),
                ]
                if telemetry.dcVoltage is not None:
                    voltage_fields.insert(0, ("dc_voltage", telemetry.dcVoltage))
                else:
                    logger.warning(
                        f"dcVoltage is missing for inverter {inverter.serialNumber} at {telemetry_date}, excluding dc_voltage field"
                    )
                voltage_point = InfluxClient.convert_to_point(
                    telemetry_date,
                    "solar",
                    voltage_fields,
                    tags,
                )
                InfluxClient.write(energy_point, "energy")
                if power_point is not None:
                    InfluxClient.write(power_point, "energy_flow")
                InfluxClient.write(voltage_point, "voltage_current")
    else:
        logger.info("It's dark outside, no need to collect data")
