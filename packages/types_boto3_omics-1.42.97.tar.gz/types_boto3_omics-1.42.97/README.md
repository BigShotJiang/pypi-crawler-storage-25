<a id="types-boto3-omics"></a>

# types-boto3-omics

[![PyPI - types-boto3-omics](https://img.shields.io/pypi/v/types-boto3-omics.svg?color=blue)](https://pypi.org/project/types-boto3-omics/)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/types-boto3-omics.svg?color=blue)](https://pypi.org/project/types-boto3-omics/)
[![Docs](https://img.shields.io/readthedocs/boto3-stubs.svg?color=blue)](https://youtype.github.io/types_boto3_docs/)
[![PyPI - Downloads](https://static.pepy.tech/badge/types-boto3-omics)](https://pypistats.org/packages/types-boto3-omics)

![boto3.typed](https://github.com/youtype/mypy_boto3_builder/raw/main/logo.png)

Type annotations for [boto3 Omics 1.42.97](https://pypi.org/project/boto3/)
compatible with [VSCode](https://code.visualstudio.com/),
[PyCharm](https://www.jetbrains.com/pycharm/),
[Emacs](https://www.gnu.org/software/emacs/),
[Sublime Text](https://www.sublimetext.com/),
[mypy](https://github.com/python/mypy),
[pyright](https://github.com/microsoft/pyright) and other tools.

Generated with
[mypy-boto3-builder 8.12.0](https://github.com/youtype/mypy_boto3_builder).

More information can be found on
[types-boto3](https://pypi.org/project/types-boto3/) page and in
[types-boto3-omics docs](https://youtype.github.io/types_boto3_docs/types_boto3_omics/).

See how it helps you find and fix potential bugs:

![types-boto3 demo](https://github.com/youtype/mypy_boto3_builder/raw/main/demo.gif)

- [types-boto3-omics](#types-boto3-omics)
  - [How to install](#how-to-install)
    - [Generate locally (recommended)](<#generate-locally-(recommended)>)
    - [VSCode extension](#vscode-extension)
    - [From PyPI with pip](#from-pypi-with-pip)
  - [How to uninstall](#how-to-uninstall)
  - [Usage](#usage)
    - [VSCode](#vscode)
    - [PyCharm](#pycharm)
    - [Emacs](#emacs)
    - [Sublime Text](#sublime-text)
    - [Other IDEs](#other-ides)
    - [mypy](#mypy)
    - [pyright](#pyright)
    - [Pylint compatibility](#pylint-compatibility)
  - [Explicit type annotations](#explicit-type-annotations)
    - [Client annotations](#client-annotations)
    - [Paginators annotations](#paginators-annotations)
    - [Waiters annotations](#waiters-annotations)
    - [Literals](#literals)
    - [Type definitions](#type-definitions)
  - [How it works](#how-it-works)
  - [What's new](#what's-new)
    - [Implemented features](#implemented-features)
    - [Latest changes](#latest-changes)
  - [Versioning](#versioning)
  - [Thank you](#thank-you)
  - [Documentation](#documentation)
  - [Support and contributing](#support-and-contributing)

<a id="how-to-install"></a>

## How to install

<a id="generate-locally-(recommended)"></a>

### Generate locally (recommended)

You can generate type annotations for `boto3` package locally with
`mypy-boto3-builder`. Use
[uv](https://docs.astral.sh/uv/getting-started/installation/) for build
isolation.

1. Run mypy-boto3-builder in your package root directory:
   `uvx --with 'boto3==1.42.97' mypy-boto3-builder`
2. Select `boto3` AWS SDK.
3. Add `Omics` service.
4. Use provided commands to install generated packages.

<a id="vscode-extension"></a>

### VSCode extension

Add
[AWS Boto3](https://marketplace.visualstudio.com/items?itemName=Boto3typed.boto3-ide)
extension to your VSCode and run `AWS boto3: Quick Start` command.

Click `Modify` and select `boto3 common` and `Omics`.

<a id="from-pypi-with-pip"></a>

### From PyPI with pip

Install `types-boto3` for `Omics` service.

```bash
# install with boto3 type annotations
python -m pip install 'types-boto3[omics]'

# Lite version does not provide session.client/resource overloads
# it is more RAM-friendly, but requires explicit type annotations
python -m pip install 'types-boto3-lite[omics]'

# standalone installation
python -m pip install types-boto3-omics
```

<a id="how-to-uninstall"></a>

## How to uninstall

```bash
python -m pip uninstall -y types-boto3-omics
```

<a id="usage"></a>

## Usage

<a id="vscode"></a>

### VSCode

- Install
  [Python extension](https://marketplace.visualstudio.com/items?itemName=ms-python.python)
- Install
  [Pylance extension](https://marketplace.visualstudio.com/items?itemName=ms-python.vscode-pylance)
- Set `Pylance` as your Python Language Server
- Install `types-boto3[omics]` in your environment:

```bash
python -m pip install 'types-boto3[omics]'
```

Both type checking and code completion should now work. No explicit type
annotations required, write your `boto3` code as usual.

<a id="pycharm"></a>

### PyCharm

> ⚠️ Due to slow PyCharm performance on `Literal` overloads (issue
> [PY-40997](https://youtrack.jetbrains.com/issue/PY-40997)), it is recommended
> to use [types-boto3-lite](https://pypi.org/project/types-boto3-lite/) until
> the issue is resolved.

> ⚠️ If you experience slow performance and high CPU usage, try to disable
> `PyCharm` type checker and use [mypy](https://github.com/python/mypy) or
> [pyright](https://github.com/microsoft/pyright) instead.

> ⚠️ To continue using `PyCharm` type checker, you can try to replace
> `types-boto3` with
> [types-boto3-lite](https://pypi.org/project/types-boto3-lite/):

```bash
pip uninstall types-boto3
pip install types-boto3-lite
```

Install `types-boto3[omics]` in your environment:

```bash
python -m pip install 'types-boto3[omics]'
```

Both type checking and code completion should now work.

<a id="emacs"></a>

### Emacs

- Install `types-boto3` with services you use in your environment:

```bash
python -m pip install 'types-boto3[omics]'
```

- Install [use-package](https://github.com/jwiegley/use-package),
  [lsp](https://github.com/emacs-lsp/lsp-mode/),
  [company](https://github.com/company-mode/company-mode) and
  [flycheck](https://github.com/flycheck/flycheck) packages
- Install [lsp-pyright](https://github.com/emacs-lsp/lsp-pyright) package

```elisp
(use-package lsp-pyright
  :ensure t
  :hook (python-mode . (lambda ()
                          (require 'lsp-pyright)
                          (lsp)))  ; or lsp-deferred
  :init (when (executable-find "python3")
          (setq lsp-pyright-python-executable-cmd "python3"))
  )
```

- Make sure emacs uses the environment where you have installed `types-boto3`

Type checking should now work. No explicit type annotations required, write
your `boto3` code as usual.

<a id="sublime-text"></a>

### Sublime Text

- Install `types-boto3[omics]` with services you use in your environment:

```bash
python -m pip install 'types-boto3[omics]'
```

- Install [LSP-pyright](https://github.com/sublimelsp/LSP-pyright) package

Type checking should now work. No explicit type annotations required, write
your `boto3` code as usual.

<a id="other-ides"></a>

### Other IDEs

Not tested, but as long as your IDE supports `mypy` or `pyright`, everything
should work.

<a id="mypy"></a>

### mypy

- Install `mypy`: `python -m pip install mypy`
- Install `types-boto3[omics]` in your environment:

```bash
python -m pip install 'types-boto3[omics]'
```

Type checking should now work. No explicit type annotations required, write
your `boto3` code as usual.

<a id="pyright"></a>

### pyright

- Install `pyright`: `npm i -g pyright`
- Install `types-boto3[omics]` in your environment:

```bash
python -m pip install 'types-boto3[omics]'
```

Optionally, you can install `types-boto3` to `typings` directory.

Type checking should now work. No explicit type annotations required, write
your `boto3` code as usual.

<a id="pylint-compatibility"></a>

### Pylint compatibility

It is totally safe to use `TYPE_CHECKING` flag in order to avoid
`types-boto3-omics` dependency in production. However, there is an issue in
`pylint` that it complains about undefined variables. To fix it, set all types
to `object` in non-`TYPE_CHECKING` mode.

```python
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from types_boto3_ec2 import EC2Client, EC2ServiceResource
    from types_boto3_ec2.waiters import BundleTaskCompleteWaiter
    from types_boto3_ec2.paginators import DescribeVolumesPaginator
else:
    EC2Client = object
    EC2ServiceResource = object
    BundleTaskCompleteWaiter = object
    DescribeVolumesPaginator = object

...
```

<a id="explicit-type-annotations"></a>

## Explicit type annotations

<a id="client-annotations"></a>

### Client annotations

`OmicsClient` provides annotations for `boto3.client("omics")`.

```python
from boto3.session import Session

from types_boto3_omics import OmicsClient

client: OmicsClient = Session().client("omics")

# now client usage is checked by mypy and IDE should provide code completion
```

<a id="paginators-annotations"></a>

### Paginators annotations

`types_boto3_omics.paginator` module contains type annotations for all
paginators.

```python
from boto3.session import Session

from types_boto3_omics import OmicsClient
from types_boto3_omics.paginator import (
    ListAnnotationImportJobsPaginator,
    ListAnnotationStoreVersionsPaginator,
    ListAnnotationStoresPaginator,
    ListBatchPaginator,
    ListConfigurationsPaginator,
    ListMultipartReadSetUploadsPaginator,
    ListReadSetActivationJobsPaginator,
    ListReadSetExportJobsPaginator,
    ListReadSetImportJobsPaginator,
    ListReadSetUploadPartsPaginator,
    ListReadSetsPaginator,
    ListReferenceImportJobsPaginator,
    ListReferenceStoresPaginator,
    ListReferencesPaginator,
    ListRunCachesPaginator,
    ListRunGroupsPaginator,
    ListRunTasksPaginator,
    ListRunsInBatchPaginator,
    ListRunsPaginator,
    ListSequenceStoresPaginator,
    ListSharesPaginator,
    ListVariantImportJobsPaginator,
    ListVariantStoresPaginator,
    ListWorkflowVersionsPaginator,
    ListWorkflowsPaginator,
)

client: OmicsClient = Session().client("omics")

# Explicit type annotations are optional here
# Types should be correctly discovered by mypy and IDEs
list_annotation_import_jobs_paginator: ListAnnotationImportJobsPaginator = client.get_paginator(
    "list_annotation_import_jobs"
)
list_annotation_store_versions_paginator: ListAnnotationStoreVersionsPaginator = (
    client.get_paginator("list_annotation_store_versions")
)
list_annotation_stores_paginator: ListAnnotationStoresPaginator = client.get_paginator(
    "list_annotation_stores"
)
list_batch_paginator: ListBatchPaginator = client.get_paginator("list_batch")
list_configurations_paginator: ListConfigurationsPaginator = client.get_paginator(
    "list_configurations"
)
list_multipart_read_set_uploads_paginator: ListMultipartReadSetUploadsPaginator = (
    client.get_paginator("list_multipart_read_set_uploads")
)
list_read_set_activation_jobs_paginator: ListReadSetActivationJobsPaginator = client.get_paginator(
    "list_read_set_activation_jobs"
)
list_read_set_export_jobs_paginator: ListReadSetExportJobsPaginator = client.get_paginator(
    "list_read_set_export_jobs"
)
list_read_set_import_jobs_paginator: ListReadSetImportJobsPaginator = client.get_paginator(
    "list_read_set_import_jobs"
)
list_read_set_upload_parts_paginator: ListReadSetUploadPartsPaginator = client.get_paginator(
    "list_read_set_upload_parts"
)
list_read_sets_paginator: ListReadSetsPaginator = client.get_paginator("list_read_sets")
list_reference_import_jobs_paginator: ListReferenceImportJobsPaginator = client.get_paginator(
    "list_reference_import_jobs"
)
list_reference_stores_paginator: ListReferenceStoresPaginator = client.get_paginator(
    "list_reference_stores"
)
list_references_paginator: ListReferencesPaginator = client.get_paginator("list_references")
list_run_caches_paginator: ListRunCachesPaginator = client.get_paginator("list_run_caches")
list_run_groups_paginator: ListRunGroupsPaginator = client.get_paginator("list_run_groups")
list_run_tasks_paginator: ListRunTasksPaginator = client.get_paginator("list_run_tasks")
list_runs_in_batch_paginator: ListRunsInBatchPaginator = client.get_paginator("list_runs_in_batch")
list_runs_paginator: ListRunsPaginator = client.get_paginator("list_runs")
list_sequence_stores_paginator: ListSequenceStoresPaginator = client.get_paginator(
    "list_sequence_stores"
)
list_shares_paginator: ListSharesPaginator = client.get_paginator("list_shares")
list_variant_import_jobs_paginator: ListVariantImportJobsPaginator = client.get_paginator(
    "list_variant_import_jobs"
)
list_variant_stores_paginator: ListVariantStoresPaginator = client.get_paginator(
    "list_variant_stores"
)
list_workflow_versions_paginator: ListWorkflowVersionsPaginator = client.get_paginator(
    "list_workflow_versions"
)
list_workflows_paginator: ListWorkflowsPaginator = client.get_paginator("list_workflows")
```

<a id="waiters-annotations"></a>

### Waiters annotations

`types_boto3_omics.waiter` module contains type annotations for all waiters.

```python
from boto3.session import Session

from types_boto3_omics import OmicsClient
from types_boto3_omics.waiter import (
    AnnotationImportJobCreatedWaiter,
    AnnotationStoreCreatedWaiter,
    AnnotationStoreDeletedWaiter,
    AnnotationStoreVersionCreatedWaiter,
    AnnotationStoreVersionDeletedWaiter,
    ReadSetActivationJobCompletedWaiter,
    ReadSetExportJobCompletedWaiter,
    ReadSetImportJobCompletedWaiter,
    ReferenceImportJobCompletedWaiter,
    RunCompletedWaiter,
    RunRunningWaiter,
    TaskCompletedWaiter,
    TaskRunningWaiter,
    VariantImportJobCreatedWaiter,
    VariantStoreCreatedWaiter,
    VariantStoreDeletedWaiter,
    WorkflowActiveWaiter,
    WorkflowVersionActiveWaiter,
)

client: OmicsClient = Session().client("omics")

# Explicit type annotations are optional here
# Types should be correctly discovered by mypy and IDEs
annotation_import_job_created_waiter: AnnotationImportJobCreatedWaiter = client.get_waiter(
    "annotation_import_job_created"
)
annotation_store_created_waiter: AnnotationStoreCreatedWaiter = client.get_waiter(
    "annotation_store_created"
)
annotation_store_deleted_waiter: AnnotationStoreDeletedWaiter = client.get_waiter(
    "annotation_store_deleted"
)
annotation_store_version_created_waiter: AnnotationStoreVersionCreatedWaiter = client.get_waiter(
    "annotation_store_version_created"
)
annotation_store_version_deleted_waiter: AnnotationStoreVersionDeletedWaiter = client.get_waiter(
    "annotation_store_version_deleted"
)
read_set_activation_job_completed_waiter: ReadSetActivationJobCompletedWaiter = client.get_waiter(
    "read_set_activation_job_completed"
)
read_set_export_job_completed_waiter: ReadSetExportJobCompletedWaiter = client.get_waiter(
    "read_set_export_job_completed"
)
read_set_import_job_completed_waiter: ReadSetImportJobCompletedWaiter = client.get_waiter(
    "read_set_import_job_completed"
)
reference_import_job_completed_waiter: ReferenceImportJobCompletedWaiter = client.get_waiter(
    "reference_import_job_completed"
)
run_completed_waiter: RunCompletedWaiter = client.get_waiter("run_completed")
run_running_waiter: RunRunningWaiter = client.get_waiter("run_running")
task_completed_waiter: TaskCompletedWaiter = client.get_waiter("task_completed")
task_running_waiter: TaskRunningWaiter = client.get_waiter("task_running")
variant_import_job_created_waiter: VariantImportJobCreatedWaiter = client.get_waiter(
    "variant_import_job_created"
)
variant_store_created_waiter: VariantStoreCreatedWaiter = client.get_waiter("variant_store_created")
variant_store_deleted_waiter: VariantStoreDeletedWaiter = client.get_waiter("variant_store_deleted")
workflow_active_waiter: WorkflowActiveWaiter = client.get_waiter("workflow_active")
workflow_version_active_waiter: WorkflowVersionActiveWaiter = client.get_waiter(
    "workflow_version_active"
)
```

<a id="literals"></a>

### Literals

`types_boto3_omics.literals` module contains literals extracted from shapes
that can be used in user code for type checking.

Full list of `Omics` Literals can be found in
[docs](https://youtype.github.io/types_boto3_docs/types_boto3_omics/literals/).

```python
from types_boto3_omics.literals import AcceleratorsType


def check_value(value: AcceleratorsType) -> bool: ...
```

<a id="type-definitions"></a>

### Type definitions

`types_boto3_omics.type_defs` module contains structures and shapes assembled
to typed dictionaries and unions for additional type checking.

Full list of `Omics` TypeDefs can be found in
[docs](https://youtype.github.io/types_boto3_docs/types_boto3_omics/type_defs/).

```python
# TypedDict usage example
from types_boto3_omics.type_defs import AbortMultipartReadSetUploadRequestTypeDef


def get_value() -> AbortMultipartReadSetUploadRequestTypeDef:
    return {
        "sequenceStoreId": ...,
    }
```

<a id="how-it-works"></a>

## How it works

Fully automated
[mypy-boto3-builder](https://github.com/youtype/mypy_boto3_builder) carefully
generates type annotations for each service, patiently waiting for `boto3`
updates. It delivers drop-in type annotations for you and makes sure that:

- All available `boto3` services are covered.
- Each public class and method of every `boto3` service gets valid type
  annotations extracted from `botocore` schemas.
- Type annotations include up-to-date documentation.
- Link to documentation is provided for every method.
- Code is processed by [ruff](https://docs.astral.sh/ruff/) for readability.

<a id="what's-new"></a>

## What's new

<a id="implemented-features"></a>

### Implemented features

- Fully type annotated `boto3`, `botocore`, `aiobotocore` and `aioboto3`
  libraries
- `mypy`, `pyright`, `VSCode`, `PyCharm`, `Sublime Text` and `Emacs`
  compatibility
- `Client`, `ServiceResource`, `Resource`, `Waiter` `Paginator` type
  annotations for each service
- Generated `TypeDefs` for each service
- Generated `Literals` for each service
- Auto discovery of types for `boto3.client` and `boto3.resource` calls
- Auto discovery of types for `session.client` and `session.resource` calls
- Auto discovery of types for `client.get_waiter` and `client.get_paginator`
  calls
- Auto discovery of types for `ServiceResource` and `Resource` collections
- Auto discovery of types for `aiobotocore.Session.create_client` calls

<a id="latest-changes"></a>

### Latest changes

Builder changelog can be found in
[Releases](https://github.com/youtype/mypy_boto3_builder/releases).

<a id="versioning"></a>

## Versioning

`types-boto3-omics` version is the same as related `boto3` version and follows
[Python Packaging version specifiers](https://packaging.python.org/en/latest/specifications/version-specifiers/).

<a id="thank-you"></a>

## Thank you

- [Allie Fitter](https://github.com/alliefitter) for
  [boto3-type-annotations](https://pypi.org/project/boto3-type-annotations/),
  this package is based on top of his work
- [black](https://github.com/psf/black) developers for an awesome formatting
  tool
- [Timothy Edmund Crosley](https://github.com/timothycrosley) for
  [isort](https://github.com/PyCQA/isort) and how flexible it is
- [mypy](https://github.com/python/mypy) developers for doing all dirty work
  for us
- [pyright](https://github.com/microsoft/pyright) team for the new era of typed
  Python

<a id="documentation"></a>

## Documentation

All services type annotations can be found in
[boto3 docs](https://youtype.github.io/types_boto3_docs/types_boto3_omics/)

<a id="support-and-contributing"></a>

## Support and contributing

This package is auto-generated. Please reports any bugs or request new features
in [mypy-boto3-builder](https://github.com/youtype/mypy_boto3_builder/issues/)
repository.
