# flicker-detector

**Umbrella (metapackage) on PyPI.** This project ships almost no code: it declares optional extras so you can install **one** Windows x64 backend with a single command.

| Extra | Pulls in | Console commands (example) |
|--------|-----------|------------------------------|
| `[cpu]` | `flicker-detector-cpu` | `cpu-flicker-detector`, `cpu-flicker-detector-server`, `cpu-flicker-detector-client` |
| `[gpu]` | `flicker-detector-gpu` | GPU package should use a `gpu-` prefix when published (same pattern as CPU). |

- **Python** ≥ 3.10  
- **OS**: Windows **64-bit** (extras are marked for `AMD64`)

## Install

**CPU (recommended default):**

```powershell
py -m pip install -U "flicker-detector[cpu]"
```

**GPU:**

```powershell
py -m pip install -U "flicker-detector[gpu]"
```

Requires the **`flicker-detector-gpu`** package to exist on the index you use (e.g. PyPI). If resolution fails, install the GPU wheel directly from its project page.

**Important:** do not install two backends that register the **same** console script names. The CPU backend uses **`cpu-*`** scripts; a GPU backend should use **`gpu-*`** (or another distinct prefix) so both can coexist if needed.

## Commands (after installing `flicker-detector-cpu`)

| Command | Role |
|---------|------|
| `cpu-flicker-detector` | Local CLI: video / image folder / image sequence → JSON |
| `cpu-flicker-detector-server` | Web UI + HTTP API |
| `cpu-flicker-detector-client` | Submit jobs to a running server |

## Backend-only install (skip this umbrella)

If you only want the backend package:

```powershell
py -m pip install flicker-detector-cpu
# or, when available:
py -m pip install flicker-detector-gpu
```

Same executables as with `[cpu]` / `[gpu]`; you do not need `flicker-detector` on top unless you want the extra indirection.

## Source and issues

Algorithm details, building from source, and bug reports: see the **flicker-detector-cpu** (or GPU) repository and main project README, not this empty metapackage.
