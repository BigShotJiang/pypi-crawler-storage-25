"""
CLI integration tests that exercise the CLI pipeline directly.

These test the full CLI pipeline: flag parsing, node initialization,
execution, and JSON output — matching the pattern used by the Go
SQLite package's CLITests.cs.
"""
import json
import os
import subprocess
import sys

import pytest

# Path to the test fixture
FIXTURE_DIR = os.path.join(os.path.dirname(__file__), "cli_fixture")
MAIN_PY = os.path.join(FIXTURE_DIR, "main.py")

# Robomotion library root (parent of tests/)
LIB_ROOT = os.path.dirname(os.path.dirname(__file__))


def run_cli(*args, env_extra=None):
    """
    Run the CLI test fixture as a subprocess and capture output.

    Returns (exit_code, stdout, stderr).
    """
    env = os.environ.copy()
    env["PYTHONPATH"] = LIB_ROOT
    # Prevent Python from writing .pyc files in the fixture dir
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    if env_extra:
        env.update(env_extra)

    result = subprocess.run(
        [sys.executable, MAIN_PY, *args],
        cwd=FIXTURE_DIR,
        capture_output=True,
        text=True,
        timeout=30,
        env=env,
    )
    return result.returncode, result.stdout.strip(), result.stderr.strip()


# ---------------------------------------------------------------------------
# Help & discovery
# ---------------------------------------------------------------------------

class TestHelp:
    def test_help_shows_usage(self):
        exit_code, _, stderr = run_cli("--help")
        assert exit_code == 0
        assert "python main.py <command>" in stderr
        assert "--list-commands" in stderr
        assert "--skill-md" in stderr
        assert "--vault-id" in stderr

    def test_help_short_flag(self):
        exit_code, _, stderr = run_cli("-h")
        assert exit_code == 0
        assert "python main.py <command>" in stderr


class TestListCommands:
    def test_human_readable(self):
        exit_code, _, stderr = run_cli("--list-commands")
        assert exit_code == 0
        assert "count_words" in stderr
        assert "reverse_text" in stderr
        assert "upper_case" in stderr
        assert "greet" in stderr
        assert "fail_node" in stderr
        assert "no_output" in stderr
        # NoToolNode should NOT appear
        assert "no_tool" not in stderr.lower().replace("no_tool_node", "")

    def test_json_returns_array(self):
        exit_code, stdout, _ = run_cli("--list-commands", "--output", "json")
        assert exit_code == 0

        commands = json.loads(stdout)
        assert isinstance(commands, list)
        assert len(commands) > 0

        names = [c["name"] for c in commands]
        assert "count_words" in names
        assert "reverse_text" in names
        assert "upper_case" in names
        assert "greet" in names

    def test_json_has_no_tool_node_excluded(self):
        """Nodes without Tool should not appear in --list-commands."""
        exit_code, stdout, _ = run_cli("--list-commands", "--output", "json")
        commands = json.loads(stdout)
        names = [c["name"] for c in commands]
        # NoToolNode has no Tool, should be absent
        for name in names:
            assert "no_tool" not in name.lower()

    def test_json_count_words_has_parameters(self):
        exit_code, stdout, _ = run_cli("--list-commands", "--output", "json")
        commands = json.loads(stdout)

        cmd = next(c for c in commands if c["name"] == "count_words")
        param_names = [p["name"] for p in cmd["parameters"]]
        assert "text" in param_names
        assert "min-length" in param_names

    def test_json_count_words_has_outputs(self):
        exit_code, stdout, _ = run_cli("--list-commands", "--output", "json")
        commands = json.loads(stdout)

        cmd = next(c for c in commands if c["name"] == "count_words")
        output_names = [o["name"] for o in cmd["outputs"]]
        assert "wordCount" in output_names
        assert "words" in output_names

    def test_json_upper_case_has_choices(self):
        exit_code, stdout, _ = run_cli("--list-commands", "--output", "json")
        commands = json.loads(stdout)

        cmd = next(c for c in commands if c["name"] == "upper_case")
        mode_param = next(p for p in cmd["parameters"] if p["name"] == "mode")
        assert mode_param["required"] is False
        assert mode_param["choices"] == ["upper", "lower"]

    def test_json_greet_detail_shows_credentials(self):
        """Greet has Credentials — detail view should mention authentication."""
        exit_code, _, stderr = run_cli("--list-commands", "greet")
        assert exit_code == 0
        assert "Authentication" in stderr or "credential" in stderr.lower()


class TestListCommandDetail:
    def test_shows_command_info(self):
        exit_code, _, stderr = run_cli("--list-commands", "count_words")
        assert exit_code == 0
        assert "count_words" in stderr
        assert "Count words" in stderr
        assert "--text" in stderr
        assert "--min-length" in stderr
        assert "wordCount" in stderr

    def test_shows_parameter_types(self):
        exit_code, _, stderr = run_cli("--list-commands", "reverse_text")
        assert exit_code == 0
        assert "--text" in stderr
        assert "string" in stderr

    def test_unknown_command_errors(self):
        exit_code, _, stderr = run_cli("--list-commands", "nonexistent_cmd")
        assert exit_code == 1
        assert "error" in stderr
        assert "nonexistent_cmd" in stderr

    def test_shows_credentials_note(self):
        exit_code, _, stderr = run_cli("--list-commands", "greet")
        assert exit_code == 0
        assert "Authentication" in stderr or "credential" in stderr.lower()


# ---------------------------------------------------------------------------
# SKILL.md generation
# ---------------------------------------------------------------------------

class TestSkillMd:
    def test_generates_frontmatter(self):
        exit_code, stdout, _ = run_cli("--skill-md")
        assert exit_code == 0
        assert stdout.startswith("---")
        assert "name: test-cli" in stdout.lower() or "name: test.cli" in stdout.lower()
        assert "version: 1.0.0" in stdout

    def test_contains_all_commands(self):
        exit_code, stdout, _ = run_cli("--skill-md")
        assert "## count_words" in stdout
        assert "## reverse_text" in stdout
        assert "## upper_case" in stdout
        assert "## greet" in stdout

    def test_contains_parameter_table(self):
        exit_code, stdout, _ = run_cli("--skill-md")
        assert "| Flag | Type | Required | Description |" in stdout
        assert "`--text`" in stdout

    def test_contains_usage_line(self):
        exit_code, stdout, _ = run_cli("--skill-md")
        assert "python main.py count_words" in stdout

    def test_contains_authentication_section(self):
        """Should have authentication section since greet has Credentials."""
        exit_code, stdout, _ = run_cli("--skill-md")
        assert "## Authentication" in stdout
        assert "ROBOMOTION_CREDENTIALS" in stdout

    def test_contains_output_section(self):
        exit_code, stdout, _ = run_cli("--skill-md")
        assert "### Output" in stdout
        assert "```json" in stdout


# ---------------------------------------------------------------------------
# Command execution — reverse_text
# ---------------------------------------------------------------------------

class TestReverseText:
    def test_basic(self):
        exit_code, stdout, _ = run_cli("reverse_text", "--text=Hello World")
        assert exit_code == 0

        result = json.loads(stdout)
        assert result["result"] == "dlroW olleH"

    def test_empty_string(self):
        exit_code, stdout, _ = run_cli("reverse_text", "--text=")
        assert exit_code == 0

        result = json.loads(stdout)
        assert result["result"] == ""

    def test_key_value_space_format(self):
        """Test --key value (space-separated) flag format."""
        exit_code, stdout, _ = run_cli("reverse_text", "--text", "abc")
        assert exit_code == 0

        result = json.loads(stdout)
        assert result["result"] == "cba"

    def test_unicode(self):
        exit_code, stdout, _ = run_cli("reverse_text", "--text=hello")
        assert exit_code == 0

        result = json.loads(stdout)
        assert result["result"] == "olleh"


# ---------------------------------------------------------------------------
# Command execution — count_words
# ---------------------------------------------------------------------------

class TestCountWords:
    def test_basic_count(self):
        exit_code, stdout, _ = run_cli(
            "count_words",
            "--text=the quick brown fox jumps over the lazy dog",
            "--min-length=0",
        )
        assert exit_code == 0

        result = json.loads(stdout)
        assert result["wordCount"] == 9

    def test_with_min_length_filter(self):
        exit_code, stdout, _ = run_cli(
            "count_words",
            "--text=the quick brown fox jumps over the lazy dog",
            "--min-length=4",
        )
        assert exit_code == 0

        result = json.loads(stdout)
        assert result["wordCount"] == 5
        assert "quick" in result["words"]
        assert "brown" in result["words"]
        assert "jumps" in result["words"]
        assert "over" in result["words"]
        assert "lazy" in result["words"]
        # Words shorter than 4 should be excluded
        assert "the" not in result["words"]
        assert "fox" not in result["words"]

    def test_all_outputs_present(self):
        exit_code, stdout, _ = run_cli(
            "count_words",
            "--text=hello world",
            "--min-length=0",
        )
        assert exit_code == 0

        result = json.loads(stdout)
        assert "wordCount" in result
        assert "words" in result
        assert isinstance(result["words"], list)


# ---------------------------------------------------------------------------
# Command execution — upper_case (OptVariable with enum)
# ---------------------------------------------------------------------------

class TestUpperCase:
    def test_default_upper(self):
        exit_code, stdout, _ = run_cli("upper_case", "--text=hello")
        assert exit_code == 0

        result = json.loads(stdout)
        assert result["result"] == "HELLO"

    def test_explicit_upper(self):
        exit_code, stdout, _ = run_cli("upper_case", "--text=hello", "--mode=upper")
        assert exit_code == 0

        result = json.loads(stdout)
        assert result["result"] == "HELLO"

    def test_lower_mode(self):
        exit_code, stdout, _ = run_cli("upper_case", "--text=HELLO", "--mode=lower")
        assert exit_code == 0

        result = json.loads(stdout)
        assert result["result"] == "hello"


# ---------------------------------------------------------------------------
# Command execution — no_output (no OutVariables)
# ---------------------------------------------------------------------------

class TestNoOutput:
    def test_returns_status_completed(self):
        exit_code, stdout, _ = run_cli("no_output", "--text=anything")
        assert exit_code == 0

        result = json.loads(stdout)
        assert result == {"status": "completed"}


# ---------------------------------------------------------------------------
# Command execution — greet (with Credentials)
# ---------------------------------------------------------------------------

class TestGreet:
    def test_basic_greet(self):
        exit_code, stdout, _ = run_cli("greet", "--name=Alice")
        assert exit_code == 0

        result = json.loads(stdout)
        assert result["greeting"] == "Hello, Alice!"

    def test_with_credentials_env(self):
        exit_code, stdout, _ = run_cli(
            "greet", "--name=Bob",
            env_extra={"ROBOMOTION_CREDENTIALS": '{"value": "sk-test-123"}'},
        )
        assert exit_code == 0

        result = json.loads(stdout)
        assert "Hello, Bob!" in result["greeting"]
        assert "api_key=sk-test-123" in result["greeting"]

    def test_without_credentials_still_works(self):
        """Greet should work even without credentials (try/except in node)."""
        exit_code, stdout, _ = run_cli("greet", "--name=Charlie")
        assert exit_code == 0

        result = json.loads(stdout)
        assert "Hello, Charlie!" in result["greeting"]
        # No api_key should be present
        assert "api_key" not in result["greeting"]


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------

class TestErrors:
    def test_unknown_command(self):
        exit_code, _, stderr = run_cli("nonexistent_command")
        assert exit_code == 1

        error = json.loads(stderr)
        assert "error" in error
        assert "nonexistent_command" in error["error"]
        # Should list available commands
        assert "count_words" in error["error"]

    def test_bad_flag_format(self):
        exit_code, _, stderr = run_cli("reverse_text", "not_a_flag")
        assert exit_code == 1

        error = json.loads(stderr)
        assert "error" in error
        assert "not_a_flag" in error["error"]
        assert "expected --flag" in error["error"]

    def test_node_raises_error(self):
        exit_code, _, stderr = run_cli(
            "fail_node",
            "--error-message=something went wrong",
        )
        assert exit_code == 1

        error = json.loads(stderr)
        assert "error" in error
        assert "something went wrong" in error["error"]

    def test_node_raises_default_error(self):
        exit_code, _, stderr = run_cli("fail_node", "--error-message=")
        assert exit_code == 1

        error = json.loads(stderr)
        assert "error" in error
        assert "intentional failure" in error["error"]


# ---------------------------------------------------------------------------
# gRPC mode not affected
# ---------------------------------------------------------------------------

class TestGRPCMode:
    def test_no_args_starts_grpc(self):
        """With no arguments, should enter gRPC mode (prints handshake line)."""
        try:
            result = subprocess.run(
                [sys.executable, MAIN_PY],
                cwd=FIXTURE_DIR,
                capture_output=True,
                text=True,
                timeout=3,
                env={**os.environ, "PYTHONPATH": LIB_ROOT, "PYTHONDONTWRITEBYTECODE": "1"},
            )
            stdout = result.stdout.strip()
        except subprocess.TimeoutExpired as e:
            # Expected — gRPC server blocks forever, timeout kills it
            stdout = (e.stdout or b"").decode().strip()

        # gRPC handshake format: 1|1|tcp|127.0.0.1:<port>|grpc
        assert "1|1|tcp|127.0.0.1:" in stdout
        assert "grpc" in stdout

    def test_dash_s_generates_spec(self):
        """The -s flag should still generate the spec JSON."""
        exit_code, stdout, _ = run_cli("-s")
        assert exit_code == 0

        spec = json.loads(stdout)
        assert spec["name"] == "Test.CLI"
        assert spec["version"] == "1.0.0"
        assert "nodes" in spec
        assert len(spec["nodes"]) > 0


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------

class TestEdgeCases:
    def test_output_is_valid_json(self):
        """All successful commands should output valid JSON to stdout."""
        exit_code, stdout, _ = run_cli("reverse_text", "--text=test")
        assert exit_code == 0
        # Should not raise
        json.loads(stdout)

    def test_error_is_valid_json_on_stderr(self):
        """All error commands should output valid JSON to stderr."""
        exit_code, _, stderr = run_cli("nonexistent")
        assert exit_code == 1
        # Should not raise
        json.loads(stderr)

    def test_stdout_clean_on_error(self):
        """On error, stdout should be empty (all errors go to stderr)."""
        exit_code, stdout, _ = run_cli("nonexistent")
        assert exit_code == 1
        assert stdout == ""

    def test_stderr_clean_on_success(self):
        """On success, stderr should have no JSON errors."""
        exit_code, _, stderr = run_cli("reverse_text", "--text=ok")
        assert exit_code == 0
        # stderr may have debug info but should not have JSON error objects
        if stderr:
            try:
                parsed = json.loads(stderr)
                assert "error" not in parsed
            except json.JSONDecodeError:
                pass  # Non-JSON stderr is fine (debug output)
