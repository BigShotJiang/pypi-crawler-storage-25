"""Deterministic Windows-only repros for the share-mode race that
robomotion.lmo._retry_share_violation defends against.

On Windows, Python's built-in open() uses FILE_SHARE_READ | FILE_SHARE_WRITE
(no FILE_SHARE_DELETE), so a concurrent reader prevents the writer's
os.replace (PermissionError "Access is denied"), and a rename-in-flight
briefly blocks new opens (PermissionError "process cannot access ...").
POSIX rename(2) has neither race — these tests are gated to win32.

Strategy: open the destination via Win32 CreateFileW with dwShareMode=0
(no sharing), kick off put_blob / get_blob in a worker thread, sleep
through a few backoff cycles, then close the handle. The retry helper
must succeed once the holder releases mid-backoff.
"""
import ctypes
import os
import sys
import shutil
import tempfile
import threading
import time

import pytest

if sys.platform != "win32":
    pytest.skip("Windows-only race repro", allow_module_level=True)

from robomotion.lmo import Store


# ── Win32 CreateFileW helpers ──

_GENERIC_READ = 0x80000000
_OPEN_EXISTING = 3
_FILE_ATTRIBUTE_NORMAL = 0x80
_INVALID_HANDLE_VALUE = ctypes.c_void_p(-1).value

_kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
_kernel32.CreateFileW.restype = ctypes.c_void_p
_kernel32.CreateFileW.argtypes = [
    ctypes.c_wchar_p, ctypes.c_uint32, ctypes.c_uint32,
    ctypes.c_void_p, ctypes.c_uint32, ctypes.c_uint32, ctypes.c_void_p,
]
_kernel32.CloseHandle.restype = ctypes.c_int
_kernel32.CloseHandle.argtypes = [ctypes.c_void_p]


def _open_exclusive(path):
    """Open a file with dwShareMode=0 — blocks all other opens until close."""
    handle = _kernel32.CreateFileW(
        path, _GENERIC_READ, 0, None, _OPEN_EXISTING, _FILE_ATTRIBUTE_NORMAL, None,
    )
    if handle == _INVALID_HANDLE_VALUE:
        raise ctypes.WinError(ctypes.get_last_error())
    return handle


def _close(handle):
    _kernel32.CloseHandle(handle)


@pytest.fixture
def store():
    d = tempfile.mkdtemp()
    s = Store(d)
    s.set_rel_path("test/flow")
    yield s
    shutil.rmtree(d, ignore_errors=True)


def test_put_blob_retries_past_sharing_violation(store):
    """put_blob's os.replace must retry past an exclusive holder on dst."""
    data = b"payload for put_blob retry test"
    target = store._blob_path_local(__import__("robomotion.lmo", fromlist=["_hash_ref"])._hash_ref(data))
    os.makedirs(os.path.dirname(target), exist_ok=True)

    # Plant a zero-byte file at the destination so put_blob's dedup
    # short-circuit (size > 0) doesn't fire and we go through the rename.
    open(target, "wb").close()
    holder = _open_exclusive(target)

    # Sanity: plain os.replace fails immediately while holder is open.
    src = target + ".sanity-src"
    with open(src, "wb") as f:
        f.write(b"sanity")
    with pytest.raises(PermissionError):
        os.replace(src, target)
    os.remove(src)

    result = {}

    def worker():
        try:
            result["ref"] = store.put_blob(data)
        except Exception as exc:
            result["err"] = exc

    t = threading.Thread(target=worker)
    t.start()
    # Let put_blob's _retry_share_violation burn a few backoff cycles.
    time.sleep(0.002)
    _close(holder)
    t.join(timeout=5)

    assert not t.is_alive(), "put_blob hung past expected retry window"
    assert "err" not in result, f"put_blob failed: {result.get('err')!r}"
    # Verify content round-trips via the resulting ref.
    got = store.get_blob(result["ref"], "test/flow")
    assert got == data


def test_get_blob_retries_past_sharing_violation(store):
    """get_blob's open()+read() must retry past an exclusive holder."""
    data = b"payload for get_blob retry test"
    ref = store.put_blob(data)
    blob_path = store._blob_path_local(ref)

    holder = _open_exclusive(blob_path)

    # Sanity: plain open() fails immediately while holder is open.
    with pytest.raises(PermissionError):
        with open(blob_path, "rb") as f:
            f.read()

    result = {}

    def worker():
        try:
            result["data"] = store.get_blob(ref, "test/flow")
        except Exception as exc:
            result["err"] = exc

    t = threading.Thread(target=worker)
    t.start()
    time.sleep(0.002)
    _close(holder)
    t.join(timeout=5)

    assert not t.is_alive(), "get_blob hung past expected retry window"
    assert "err" not in result, f"get_blob failed: {result.get('err')!r}"
    assert result["data"] == data
