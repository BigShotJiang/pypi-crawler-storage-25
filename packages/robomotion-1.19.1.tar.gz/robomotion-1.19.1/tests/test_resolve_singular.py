"""Pin the recursive-resolve gap in Store.resolve (singular path-based).

The companion fix in this PR makes Store.resolve_all recursive (covered by
TestNestedBlobRefRecursive). The singular Store.resolve has the SAME gap on
two call sites:

  - Line 189: when walking a path and `current` is a BlobRef, _resolve_ref
    returns its content; if THAT content is itself a BlobRef envelope, the
    loop's `if part in current` checks for the user's key in the envelope
    (which only has __magic, __ref, ...) and returns None.
  - Line 207: the final-segment unwrap — single call, no loop.

These tests fail pre-fix and pass post-fix.
"""

import shutil
import tempfile

import pytest

from robomotion.lmo import Store, MAGIC, is_blob_ref


@pytest.fixture
def tmp_dir():
    d = tempfile.mkdtemp()
    yield d
    shutil.rmtree(d, ignore_errors=True)


@pytest.fixture
def store(tmp_dir):
    s = Store(tmp_dir)
    s.set_rel_path("test/path")
    return s


def _envelope(ref: str, size: int, type_str: str = "string", path: str = "test/path") -> str:
    return (
        '{"__ref":"' + ref + '","__magic":' + str(MAGIC) +
        ',"__size":' + str(size) + ',"__path":"' + path + '","__type":"' + type_str + '"}'
    )


class TestResolveSingularRecursive:
    def test_direct_access_double_nested(self, store):
        """resolve('key') where key's value is a BlobRef whose blob content
        is itself another BlobRef. Pre-fix: returns the inner envelope dict.
        Post-fix: returns the actual underlying value."""
        real_data = b'"hello from the deepest blob"'
        real_ref = store.put_blob(real_data)
        real_envelope = _envelope(real_ref, len(real_data))

        wrapper_ref = store.put_blob(real_envelope.encode("utf-8"))
        wrapper_envelope = _envelope(wrapper_ref, len(real_envelope))

        payload = ('{"key":' + wrapper_envelope + '}').encode("utf-8")

        result = store.resolve(payload, "key")

        # Pre-fix: result is a dict matching the BlobRef envelope shape.
        # Post-fix: result is the underlying string.
        assert not isinstance(result, dict) or not is_blob_ref(result), (
            "resolve returned a BlobRef envelope instead of unwrapping it.\n"
            "This is the singular-resolve recursion gap.\n"
            f"Got: {result!r}\n"
            "Expected: 'hello from the deepest blob'"
        )
        assert result == "hello from the deepest blob", f"unexpected: {result!r}"

    def test_path_walk_double_nested(self, store):
        """resolve('container.inner') where container is a BlobRef whose
        content has `inner` as a BlobRef whose content is YET another BlobRef.

        Walks the path: container resolves to outer_content. Then `inner` in
        outer_content is wrapper_envelope. Pre-fix: walks the part, current
        becomes wrapper_envelope (still a BlobRef), the FINAL is_blob_ref
        check at line 207 calls _resolve_ref ONCE → real_envelope (still a
        BlobRef!) is returned. Post-fix: fully unwrapped."""
        real_data = b'"deep value"'
        real_ref = store.put_blob(real_data)
        real_envelope = _envelope(real_ref, len(real_data))

        wrapper_ref = store.put_blob(real_envelope.encode("utf-8"))
        wrapper_envelope = _envelope(wrapper_ref, len(real_envelope))

        outer_content = '{"inner":' + wrapper_envelope + ',"sibling":"keep"}'
        outer_ref = store.put_blob(outer_content.encode("utf-8"))
        outer_envelope = _envelope(outer_ref, len(outer_content), type_str="object")

        payload = ('{"container":' + outer_envelope + '}').encode("utf-8")

        result = store.resolve(payload, "container.inner")

        assert not isinstance(result, dict) or not is_blob_ref(result), (
            "resolve returned a BlobRef envelope instead of fully unwrapping the path-walk + nested case.\n"
            f"Got: {result!r}\n"
            "Expected: 'deep value'"
        )
        assert result == "deep value", f"unexpected: {result!r}"

    def test_no_op_for_unnested(self, store):
        """Common case: plain field returns the field; single-level BlobRef
        returns its content. Recursion guard must not change this."""
        payload = b'{"name":"plain","count":42}'
        assert store.resolve(payload, "name") == "plain"

        real_data = b'"single-level"'
        real_ref = store.put_blob(real_data)
        real_envelope = _envelope(real_ref, len(real_data))
        payload2 = ('{"k":' + real_envelope + '}').encode("utf-8")
        assert store.resolve(payload2, "k") == "single-level"

    def test_depth_limit_pathological(self, store):
        """Defensive depth-limit guard against pathological chains.
        Naturally Pack can't produce these depths but a hostile input could.
        Must not infinite-loop or stack-overflow."""
        chain_depth = 64
        inner_ref = store.put_blob(b'"bottom"')
        current_envelope = _envelope(inner_ref, 8)
        for _ in range(chain_depth):
            ref = store.put_blob(current_envelope.encode("utf-8"))
            current_envelope = _envelope(ref, len(current_envelope))

        payload = ('{"k":' + current_envelope + '}').encode("utf-8")

        # Chain depth 64 exceeds max_resolve_depth (32), so the loop MUST
        # exhaust and surface a depth-limit error. Asserts the FIX is
        # present (full unwrap or loud error) and explicitly rejects the
        # silent-failure mode where a missing _fully_resolve_ref would
        # return the inner envelope unchanged.
        try:
            result = store.resolve(payload, "k")
        except Exception as e:
            assert "depth" in str(e).lower(), f"expected depth-limit error, got: {e!r}"
            return

        # If no error: full unwrap required, NOT envelope.
        assert not (isinstance(result, dict) and is_blob_ref(result)), (
            "resolve returned a BlobRef envelope without error — "
            f"_fully_resolve_ref appears to be missing.\nGot: {result!r}"
        )
        assert result == "bottom", f"expected full unwrap to 'bottom', got: {result!r}"
