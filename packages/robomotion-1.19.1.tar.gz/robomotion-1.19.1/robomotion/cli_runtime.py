"""
CLI Runtime Helper for Robomotion Python SDK.

Provides a lightweight runtime helper that allows node code (InVariable.Get,
OutVariable.Set, Credentials.get_vault_item) to work in CLI mode without
the gRPC robot runtime.
"""

import os
import json


class CLIRuntimeHelper:
    """
    Implements credential resolution for CLI mode.

    In CLI mode, credentials come from either:
    1. ROBOMOTION_CREDENTIALS environment variable (JSON)
    2. Vault API fetch via CLIVaultClient (--vault-id/--item-id flags)
    """

    def __init__(self):
        self._credentials = None
        env_creds = os.environ.get('ROBOMOTION_CREDENTIALS')
        if env_creds:
            self._credentials = json.loads(env_creds)

    def set_credentials(self, creds: dict):
        """Inject credentials fetched from vault API."""
        self._credentials = creds

    def get_vault_item(self, vault_id, item_id) -> dict:
        """Return pre-loaded credentials or raise if none available."""
        if self._credentials is not None:
            return self._credentials
        raise RuntimeError(
            "no credentials available: use --vault-id/--item-id flags "
            "or set ROBOMOTION_CREDENTIALS env var"
        )
