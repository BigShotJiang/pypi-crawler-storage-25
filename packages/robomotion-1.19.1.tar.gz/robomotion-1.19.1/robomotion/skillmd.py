"""
SKILL.md Generator for Robomotion Python SDK.

Generates SKILL.md documentation from tool-annotated nodes for AI agent
discovery. Matches the Go implementation in skillmd.go.
"""

import sys

from robomotion.cli import (
    _discover_node_classes,
    gather_commands,
    camel_to_kebab,
)


def infer_binary_name(package_name):
    """
    Derive binary name from package name.
    e.g. "Robomotion.GoogleDrive" -> "robomotion-googledrive"
    """
    return package_name.replace('.', '-').lower()


def generate_skill_md(name, version, config=None):
    """
    Generate and print SKILL.md to stdout.

    Introspects tool-annotated nodes and produces YAML frontmatter + markdown
    command documentation for AI agent discovery.
    """
    commands = gather_commands()
    if not commands:
        sys.stderr.write("No tool-annotated nodes found.\n")
        return

    binary_name = infer_binary_name(name)

    # Collect descriptions for frontmatter
    descriptions = [cmd["description"] for cmd in commands if cmd["description"]]
    frontmatter_desc = ", ".join(descriptions) if descriptions else name

    # Check if any command has credentials
    any_credentials = any(cmd.get("has_credentials", False) for cmd in commands)

    out = []

    # YAML frontmatter
    out.append("---")
    out.append("name: %s" % binary_name)
    out.append("description: %s" % frontmatter_desc)
    out.append("version: %s" % version)
    out.append("---")
    out.append("")

    # Commands
    for cmd in commands:
        out.append("## %s" % cmd["name"])
        out.append("")
        if cmd["description"]:
            out.append(cmd["description"])
            out.append("")

        # Usage line
        usage_parts = ["python main.py", cmd["name"]]
        for p in cmd["parameters"]:
            if p["required"]:
                usage_parts.append("--%s=<%s>" % (p["name"], p["type"]))
        for p in cmd["parameters"]:
            if not p["required"]:
                usage_parts.append("[--%s=<%s>]" % (p["name"], p["type"]))
        out.append("```")
        out.append(" ".join(usage_parts))
        out.append("```")
        out.append("")

        # Parameters table
        if cmd["parameters"]:
            out.append("### Parameters")
            out.append("")
            out.append("| Flag | Type | Required | Description |")
            out.append("|------|------|----------|-------------|")
            for p in cmd["parameters"]:
                req = "Yes" if p["required"] else "No"
                desc = p.get("description", "")
                choices = p.get("choices")
                if choices:
                    desc += " (choices: %s)" % ", ".join(str(c) for c in choices)
                out.append("| `--%s` | %s | %s | %s |" % (
                    p["name"], p["type"], req, desc
                ))
            out.append("")

        # Output section
        if cmd["outputs"]:
            out.append("### Output")
            out.append("")
            out.append("```json")
            output_example = {}
            for o in cmd["outputs"]:
                type_examples = {
                    "string": "...",
                    "number": 0,
                    "integer": 0,
                    "boolean": True,
                    "object": {},
                    "array": [],
                }
                output_example[o["name"]] = type_examples.get(o["type"], "...")
            import json
            out.append(json.dumps(output_example, indent=2))
            out.append("```")
            out.append("")

    # Authentication section
    if any_credentials:
        out.append("## Authentication")
        out.append("")
        out.append("Commands that require authentication accept credentials via:")
        out.append("")
        out.append("**Vault flags (production):**")
        out.append("")
        out.append("```")
        out.append("python main.py <command> --vault-id=<ID> --item-id=<ID> [other flags...]")
        out.append("```")
        out.append("")
        out.append("Or by name:")
        out.append("")
        out.append("```")
        out.append("python main.py <command> --vault=<NAME> --item=<NAME> [other flags...]")
        out.append("```")
        out.append("")
        out.append("**Environment variable (development):**")
        out.append("")
        out.append("```")
        out.append('export ROBOMOTION_CREDENTIALS=\'{"value": "your-api-key"}\'')
        out.append("python main.py <command> [flags...]")
        out.append("```")
        out.append("")

    print("\n".join(out))
