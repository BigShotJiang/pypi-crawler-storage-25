from robomotion.node import Node


def node_decorator(*args, **kwargs):
    def wrapper(cls):
        class NewCls(cls):
            def __init__(self):
                super().__init__()
                self.cls = cls
                self.name = ''
                self.title = ''
                self.color = ''
                self.continueOnError=False
                self.icon = ''
                self.editor = None
                self.inputs = 1
                self.outputs = 1
                # `assets` declares per-node markdown bootstrap files that
                # Designer surfaces in the Files tab (and seeds with the
                # given template at runtime when no on-disk copy exists).
                # Default empty so spec.py's `if inst.assets` skips it
                # for nodes that don't opt in.
                self.assets = []

            def __getattribute__(self, s):
                if s in kwargs:
                    return kwargs[s]

                return super().__getattribute__(s)

        return NewCls
    return wrapper
