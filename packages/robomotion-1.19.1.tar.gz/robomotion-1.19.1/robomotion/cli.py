"""
CLI Mode for Robomotion Python SDK.

Allows package scripts to be invoked directly from the command line as
standalone tools, without the gRPC robot runtime. Designed for AI agent
integration: agents read SKILL.md, build a command, execute the script,
and read JSON output from stdout.
"""

import sys
import re
import json
import inspect
import asyncio

from robomotion.node import Node
from robomotion.variable import InVariable, OutVariable, OptVariable, Credentials, Variable
from robomotion.tool import Tool
from robomotion.runtime import Runtime
from robomotion.cli_runtime import CLIRuntimeHelper
from robomotion.testing.context import MockContext


# ---------------------------------------------------------------------------
# Case conversion utilities
# ---------------------------------------------------------------------------

def camel_to_kebab(name: str) -> str:
    """Convert camelCase to kebab-case: filePath -> file-path"""
    s = re.sub(r'([A-Z])', r'-\1', name)
    return s.lower().lstrip('-')


def kebab_to_camel(name: str) -> str:
    """Convert kebab-case to camelCase: file-path -> filePath"""
    parts = name.split('-')
    return parts[0] + ''.join(p.capitalize() for p in parts[1:])


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------

def cli_error(msg: str):
    """Print JSON error to stderr and exit with code 1."""
    sys.stderr.write(json.dumps({"error": msg}) + "\n")
    sys.exit(1)


# ---------------------------------------------------------------------------
# Node discovery
# ---------------------------------------------------------------------------

def _discover_node_classes():
    """
    Discover Node subclasses from the calling module.
    Same pattern as plugin.py:init() — walk up the stack to find the
    module that called start(), then find all Node subclasses.
    """
    # Walk up the stack looking for the user's module that has Node subclasses
    # Skip robomotion.* internal modules
    for frame_info in inspect.stack():
        mod = inspect.getmodule(frame_info[0])
        if mod is None:
            continue
        mod_name = getattr(mod, '__name__', '')
        if mod_name.startswith('robomotion'):
            continue
        clsmembers = inspect.getmembers(sys.modules.get(mod_name, mod), inspect.isclass)
        node_classes = []
        for name, cls in clsmembers:
            if issubclass(cls, Node) and cls is not Node:
                node_classes.append(cls)
        if node_classes:
            return node_classes
    return []


def _get_tool(cls):
    """Get the Tool instance from a node class, or None.
    Checks both class-level attributes and inner class instance dict
    (for @node_decorator pattern where Tool is set in __init__)."""
    # Check class-level attributes first
    for attr in dir(cls):
        value = getattr(cls, attr, None)
        if isinstance(value, Tool) and value.name:
            return value
    # Check inner class instance dict (decorator pattern)
    fields = _get_inner_fields(cls)
    for key, val in fields.items():
        if isinstance(val, Tool) and val.name:
            return val
    return None


def _get_inner_fields(cls):
    """Get the inner class fields dict via cls().cls().__dict__ pattern."""
    try:
        return cls().cls().__dict__
    except Exception:
        return {}


# ---------------------------------------------------------------------------
# Command map
# ---------------------------------------------------------------------------

class CommandEntry:
    def __init__(self, cls, tool, node_id):
        self.cls = cls          # Node class
        self.tool = tool        # Tool instance
        self.node_id = node_id  # Node ID (e.g. "Robomotion.GoogleDrive.Upload")


def build_command_map(node_classes=None):
    """
    Build a mapping of tool_name -> CommandEntry for all nodes with Tool.
    """
    if node_classes is None:
        node_classes = _discover_node_classes()

    commands = {}
    for cls in node_classes:
        tool = _get_tool(cls)
        if tool is None:
            continue
        try:
            node_id = cls().name
        except Exception:
            node_id = cls.__name__
        commands[tool.name] = CommandEntry(cls, tool, node_id)
    return commands


# ---------------------------------------------------------------------------
# Flag parsing
# ---------------------------------------------------------------------------

def parse_flags(args):
    """
    Parse CLI flags from args list.
    Supports: --key=value, --key value, --flag (boolean true).
    Repeated flags produce a JSON array string.
    Returns (flags_dict, remaining_args).
    """
    flags = {}
    vault_id = ""
    item_id = ""
    i = 0

    while i < len(args):
        arg = args[i]
        if not arg.startswith('--'):
            cli_error('unexpected argument "%s" (expected --flag=value)' % arg)

        arg = arg[2:]  # strip --

        if '=' in arg:
            key, value = arg.split('=', 1)
        elif i + 1 < len(args) and not args[i + 1].startswith('--'):
            key = arg
            value = args[i + 1]
            i += 1
        else:
            key = arg
            value = "true"

        # Extract global flags
        if key == 'vault-id':
            vault_id = value
        elif key == 'item-id':
            item_id = value
        elif key == 'vault':
            vault_id = value  # name-based resolution
        elif key == 'item':
            item_id = value   # name-based resolution
        elif key == 'output':
            flags['__output_format__'] = value
        elif key in ('session', 'session-id', 'session-close', 'session-timeout'):
            flags['__' + key.replace('-', '_') + '__'] = value
        else:
            # Handle repeated flags -> JSON array
            if key in flags:
                existing = flags[key]
                try:
                    arr = json.loads(existing)
                    if not isinstance(arr, list):
                        arr = [existing]
                except (json.JSONDecodeError, TypeError):
                    arr = [existing]
                arr.append(value)
                flags[key] = json.dumps(arr)
            else:
                flags[key] = value

        i += 1

    return flags, vault_id, item_id


# ---------------------------------------------------------------------------
# Flag-to-variable mapping
# ---------------------------------------------------------------------------

class FlagMeta:
    """Metadata about a flag's corresponding variable."""
    def __init__(self, spec_name, scope, field_name, var):
        self.spec_name = spec_name    # Variable name (e.g. "filePath")
        self.scope = scope            # "Message", "Custom", etc.
        self.field_name = field_name  # Field name on inner class
        self.var = var                # Variable instance


def build_flag_map(cls):
    """
    Build a mapping from kebab-case flag names to FlagMeta.
    Introspects the node's inner class fields.
    """
    flag_map = {}
    fields = _get_inner_fields(cls)

    for field_name, val in fields.items():
        if isinstance(val, (InVariable, OptVariable)):
            spec_name = val.name
            scope = val.scope
            if spec_name:
                kebab = camel_to_kebab(spec_name)
                flag_map[kebab] = FlagMeta(spec_name, scope, field_name, val)
            # Also map by field name for convenience
            field_kebab = camel_to_kebab(field_name)
            if field_kebab not in flag_map:
                flag_map[field_kebab] = FlagMeta(
                    spec_name or field_name, scope, field_name, val
                )
        elif isinstance(val, Variable) and (val.input or val.option):
            spec_name = val.name or field_name
            scope = val.scope or "Custom"
            kebab = camel_to_kebab(spec_name)
            flag_map[kebab] = FlagMeta(spec_name, scope, field_name, val)

    return flag_map


# ---------------------------------------------------------------------------
# Context building
# ---------------------------------------------------------------------------

def _maybe_parse_json(value):
    """Try to parse a string as JSON (for object/array flag values). Return original if not JSON."""
    if isinstance(value, str) and value and value[0] in ('{', '['):
        try:
            return json.loads(value)
        except (json.JSONDecodeError, ValueError):
            pass
    return value


def build_cli_context(cls, flags):
    """
    Convert parsed CLI flags into message data and config patches.

    Message-scope variables -> set in message context
    Custom-scope variables -> set in node config
    Unknown flags -> camelCase fallback into message context

    Returns (msg_data, config_patches).
    """
    flag_map = build_flag_map(cls)
    msg_data = {}
    config_patches = {}

    for flag_key, flag_value in flags.items():
        if flag_key.startswith('__'):
            continue  # internal flags

        if flag_key in flag_map:
            meta = flag_map[flag_key]
            if meta.scope == "Message" or meta.scope == "":
                msg_data[meta.spec_name] = _maybe_parse_json(flag_value)
            else:
                # Custom/other scope: patch the node config
                config_patches[meta.field_name] = {
                    "scope": meta.scope,
                    "name": flag_value
                }
        else:
            # Fallback: convert kebab to camelCase and put in message
            camel_key = kebab_to_camel(flag_key)
            msg_data[camel_key] = _maybe_parse_json(flag_value)

    return msg_data, config_patches


# ---------------------------------------------------------------------------
# Credential injection
# ---------------------------------------------------------------------------

def inject_option_defaults(cls, node_config):
    """
    Inject default values for plain Variable option fields and bare typed
    fields (bool, int, str prefixed with 'opt') into the node config.

    In gRPC mode, Runtime.deserialize replaces these fields with values from
    the config JSON. In CLI mode, if no flag was provided, we need to seed
    the config with the default value so deserialize replaces the Variable
    object with the actual default.
    """
    fields = _get_inner_fields(cls)
    for field_name, val in fields.items():
        if field_name in node_config:
            continue  # already set by a CLI flag
        if isinstance(val, Variable) and not isinstance(val, (InVariable, OutVariable, OptVariable)):
            if val.option and val.default is not None:
                node_config[field_name] = val.default
        elif isinstance(val, (bool, int, float, str)) and field_name.lower().startswith('opt'):
            node_config[field_name] = val


def inject_credential_config(node, vault_id, item_id):
    """
    Set vaultId and itemId on all Credential fields in the node.
    Uses Python name mangling: Credentials.__vaultId -> _Credentials__vaultId
    """
    if not vault_id or not item_id:
        return

    fields = _get_inner_fields(node.__class__)
    for field_name, val in fields.items():
        if isinstance(val, Credentials):
            # Access the actual credential on the instantiated node's inner class
            inner = node.cls()
            cred = getattr(inner, field_name, None)
            if cred is not None and isinstance(cred, Credentials):
                cred._Credentials__vaultId = vault_id
                cred._Credentials__itemId = item_id


# ---------------------------------------------------------------------------
# Output collection
# ---------------------------------------------------------------------------

def collect_cli_output(cls, ctx):
    """
    Read OutVariable values from context after OnMessage completes.
    Falls back to {"status": "completed"} if no outputs found.
    """
    output = {}
    fields = _get_inner_fields(cls)

    for field_name, val in fields.items():
        if isinstance(val, OutVariable):
            spec_name = val.name or field_name
            value = ctx.get(spec_name)
            if value is not None:
                output[spec_name] = value
        elif isinstance(val, Variable) and val.output:
            spec_name = val.name or field_name
            value = ctx.get(spec_name)
            if value is not None:
                output[spec_name] = value

    if not output:
        return {"status": "completed"}
    return output


# ---------------------------------------------------------------------------
# Command metadata gathering
# ---------------------------------------------------------------------------

def gather_commands(node_classes=None):
    """
    Collect full CLI command metadata for --list-commands and SKILL.md.
    Returns a list of command info dicts.
    """
    if node_classes is None:
        node_classes = _discover_node_classes()

    commands = []

    for cls in node_classes:
        tool = _get_tool(cls)
        if tool is None:
            continue

        try:
            node_id = cls().name
        except Exception:
            node_id = cls.__name__

        fields = _get_inner_fields(cls)

        parameters = []
        outputs = []
        has_credentials = False

        for field_name, val in fields.items():
            if isinstance(val, InVariable):
                spec_name = val.name or field_name
                parameters.append({
                    "name": camel_to_kebab(spec_name),
                    "type": val.type or "string",
                    "required": True,
                    "description": val.title or val.description or "",
                })
            elif isinstance(val, OptVariable):
                spec_name = val.name or field_name
                param_info = {
                    "name": camel_to_kebab(spec_name),
                    "type": val.type or "string",
                    "required": False,
                    "description": val.title or val.description or "",
                }
                if val.enum is not None and val.enum.enums:
                    param_info["choices"] = val.enum.enums
                parameters.append(param_info)
            elif isinstance(val, Variable) and val.input:
                spec_name = val.name or field_name
                parameters.append({
                    "name": camel_to_kebab(spec_name),
                    "type": val.type or "string",
                    "required": True,
                    "description": val.title or val.description or "",
                })
            elif isinstance(val, Variable) and val.option:
                spec_name = val.name or field_name
                param_info = {
                    "name": camel_to_kebab(spec_name),
                    "type": val.type or "string",
                    "required": False,
                    "description": val.title or val.description or "",
                }
                if val.enum is not None and val.enum.enums:
                    param_info["choices"] = val.enum.enums
                parameters.append(param_info)
            elif isinstance(val, OutVariable):
                spec_name = val.name or field_name
                outputs.append({
                    "name": spec_name,
                    "type": val.type or "string",
                })
            elif isinstance(val, Variable) and val.output:
                spec_name = val.name or field_name
                outputs.append({
                    "name": spec_name,
                    "type": val.type or "string",
                })
            elif isinstance(val, Credentials):
                has_credentials = True

        commands.append({
            "name": tool.name,
            "description": tool.description or "",
            "node_id": node_id,
            "parameters": parameters,
            "outputs": outputs,
            "has_credentials": has_credentials,
        })

    return commands


# ---------------------------------------------------------------------------
# Command listing
# ---------------------------------------------------------------------------

def list_commands():
    """List available CLI commands. JSON to stdout if --output json, else human-readable to stderr."""
    commands = gather_commands()

    # Check for --output json
    output_json = False
    for arg in sys.argv:
        if arg == '--output' or arg.startswith('--output='):
            if '=' in arg:
                output_json = arg.split('=', 1)[1] == 'json'
            else:
                idx = sys.argv.index(arg)
                if idx + 1 < len(sys.argv):
                    output_json = sys.argv[idx + 1] == 'json'
            break

    if output_json:
        # Clean output for machine consumption
        clean = []
        for cmd in commands:
            c = dict(cmd)
            c.pop('has_credentials', None)
            clean.append(c)
        print(json.dumps(clean, indent=2))
    else:
        sys.stderr.write("Available commands:\n\n")
        for cmd in commands:
            sys.stderr.write("  %-30s %s\n" % (cmd["name"], cmd["description"]))
        sys.stderr.write("\nUse --list-commands <command> for detailed help.\n")
        sys.stderr.write("Use --list-commands --output json for machine-readable output.\n")


def list_command_detail(cmd_name):
    """Print detailed help for one command."""
    commands = gather_commands()
    cmd = None
    for c in commands:
        if c["name"] == cmd_name:
            cmd = c
            break

    if cmd is None:
        available = ", ".join(c["name"] for c in commands)
        cli_error('unknown command "%s"; available commands: %s' % (cmd_name, available))

    sys.stderr.write("Command: %s\n" % cmd["name"])
    sys.stderr.write("Description: %s\n" % cmd["description"])
    sys.stderr.write("Node ID: %s\n\n" % cmd["node_id"])

    if cmd["parameters"]:
        sys.stderr.write("Parameters:\n")
        for p in cmd["parameters"]:
            req = "required" if p["required"] else "optional"
            desc = p.get("description", "")
            choices = p.get("choices")
            line = "  --%-25s %-10s [%s]" % (p["name"], p["type"], req)
            if desc:
                line += "  %s" % desc
            if choices:
                line += "  (choices: %s)" % ", ".join(str(c) for c in choices)
            sys.stderr.write(line + "\n")

    if cmd["outputs"]:
        sys.stderr.write("\nOutputs:\n")
        for o in cmd["outputs"]:
            sys.stderr.write("  %-25s %s\n" % (o["name"], o["type"]))

    if cmd["has_credentials"]:
        sys.stderr.write("\nAuthentication required. Use --vault-id/--item-id or set ROBOMOTION_CREDENTIALS.\n")


# ---------------------------------------------------------------------------
# Help
# ---------------------------------------------------------------------------

def print_cli_usage():
    """Print overall CLI usage to stderr."""
    sys.stderr.write("Usage:\n")
    sys.stderr.write("  python main.py <command> [--flag=value ...]\n")
    sys.stderr.write("  python main.py --list-commands          List available commands\n")
    sys.stderr.write("  python main.py --list-commands <cmd>    Detailed help for a command\n")
    sys.stderr.write("  python main.py --skill-md               Generate SKILL.md\n")
    sys.stderr.write("  python main.py --help                   Show this help\n")
    sys.stderr.write("\nCredential flags:\n")
    sys.stderr.write("  --vault-id=ID    Robomotion vault ID\n")
    sys.stderr.write("  --item-id=ID     Robomotion vault item ID\n")
    sys.stderr.write("  --vault=NAME     Vault name (resolved via API)\n")
    sys.stderr.write("  --item=NAME      Item name (resolved via API)\n")
    sys.stderr.write("\nSession flags:\n")
    sys.stderr.write("  --session              Start a new session (keeps process alive)\n")
    sys.stderr.write("  --session-id=ID        Reuse an existing session\n")
    sys.stderr.write("  --session-close=ID     Close a session and stop the daemon\n")
    sys.stderr.write("  --session-timeout=DUR  Inactivity timeout (default: 30m)\n")
    sys.stderr.write("\nEnvironment variables:\n")
    sys.stderr.write("  ROBOMOTION_CREDENTIALS    JSON credentials (bypasses vault)\n")
    sys.stderr.write("  ROBOMOTION_API_TOKEN      API token for vault access\n")
    sys.stderr.write("  ROBOMOTION_ROBOT_ID       Robot ID for key lookup\n")
    sys.stderr.write("  ROBOMOTION_API_URL        API base URL (default: https://api.robomotion.io)\n")


# ---------------------------------------------------------------------------
# Main CLI entry point
# ---------------------------------------------------------------------------

def run_cli(args):
    """
    Main CLI entry point. Discovers nodes, resolves command, parses flags,
    sets up CLI runtime, instantiates node, runs lifecycle, collects output,
    and prints JSON to stdout.
    """
    if not args:
        print_cli_usage()
        return

    cmd_name = args[0]

    # Build command map
    node_classes = _discover_node_classes()
    commands = build_command_map(node_classes)

    if cmd_name not in commands:
        available = ", ".join(sorted(commands.keys()))
        cli_error('unknown command "%s"; available commands: %s' % (cmd_name, available))

    entry = commands[cmd_name]
    cls = entry.cls

    # Parse flags
    flags, vault_id, item_id = parse_flags(args[1:])

    # Extract session flags
    session_start = flags.pop('__session__', '') == 'true'
    session_id = flags.pop('__session_id__', '')
    session_close = flags.pop('__session_close__', '')
    session_timeout_str = flags.pop('__session_timeout__', '')

    # Session close
    if session_close:
        from robomotion.cli_session import close_session
        close_session(session_close)
        return

    # Session reuse: send command to existing daemon
    if session_id:
        from robomotion.cli_session import run_session_client
        cmd_flags = dict(flags)
        # Remove internal flags
        cmd_flags = {k: v for k, v in cmd_flags.items() if not k.startswith('__')}
        if vault_id:
            cmd_flags['vault-id'] = vault_id
        if item_id:
            cmd_flags['item-id'] = item_id
        run_session_client(session_id, cmd_name, cmd_flags)
        return

    # Session start: fork daemon, then send first command as client
    if session_start:
        from robomotion.cli_session import (
            start_daemon_process, run_session_client,
            generate_session_id, parse_session_timeout, DEFAULT_SESSION_TIMEOUT,
        )
        timeout = parse_session_timeout(session_timeout_str)
        sid = generate_session_id()
        start_daemon_process(sid, timeout, vault_id, item_id)
        cmd_flags = {k: v for k, v in flags.items() if not k.startswith('__')}
        if vault_id:
            cmd_flags['vault-id'] = vault_id
        if item_id:
            cmd_flags['item-id'] = item_id
        run_session_client(sid, cmd_name, cmd_flags)
        return

    # Set up CLI runtime helper
    cli_helper = CLIRuntimeHelper()
    Runtime._cli_helper = cli_helper

    # Handle vault credential resolution
    if vault_id and item_id:
        # Check if vault_id/item_id look like UUIDs or names
        uuid_pattern = re.compile(r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$', re.I)
        needs_name_resolution = not uuid_pattern.match(vault_id) or not uuid_pattern.match(item_id)

        try:
            from robomotion.cli_vault import CLIVaultClient
            vault_client = CLIVaultClient.from_env()

            if needs_name_resolution:
                if not uuid_pattern.match(vault_id):
                    vault_id = vault_client.resolve_vault_by_name(vault_id)
                if not uuid_pattern.match(item_id):
                    item_id = vault_client.resolve_item_by_name(vault_id, item_id)

            creds = vault_client.fetch_vault_item(vault_id, item_id)
            cli_helper.set_credentials(creds)
        except ImportError:
            cli_error("vault access requires the 'cryptography' package: pip install cryptography")
        except Exception as e:
            cli_error("vault error: %s" % str(e))

    # Build context from flags
    msg_data, config_patches = build_cli_context(cls, flags)

    # Build node config
    node_config = {
        "guid": "cli-node",
        "name": cmd_name,
    }

    # Apply config patches (Custom-scope variables)
    for field_name, patch in config_patches.items():
        node_config[field_name] = patch

    # Inject defaults for plain Variable option fields (e.g. optTableStyle)
    inject_option_defaults(cls, node_config)

    # Instantiate the node via Runtime.deserialize (same as factory)
    try:
        inner_cls = cls().cls
        config_bytes = json.dumps(node_config).encode('utf-8')
        node = Runtime.deserialize(config_bytes, inner_cls)
    except Exception as e:
        cli_error("failed to initialize node: %s" % str(e))

    # Inject credential config into node's Credential fields
    inject_credential_config(node, vault_id, item_id)

    # Build message context using MockContext
    msg_data["id"] = "cli-msg"
    ctx = MockContext(msg_data)

    # Run node lifecycle: on_create -> on_message -> on_close
    try:
        asyncio.run(node.on_create())
    except Exception as e:
        cli_error("OnCreate failed: %s" % str(e))

    try:
        asyncio.run(node.on_message(ctx))
    except Exception as e:
        cli_error("command failed: %s" % str(e))

    try:
        asyncio.run(node.on_close())
    except Exception as e:
        cli_error("OnClose failed: %s" % str(e))

    # Collect output
    output = collect_cli_output(cls, ctx)

    # Print JSON result to stdout
    print(json.dumps(output, indent=2))

    # Clean up
    Runtime._cli_helper = None
