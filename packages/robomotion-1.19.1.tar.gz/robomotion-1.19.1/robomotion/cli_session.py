"""
CLI Session Daemon for Robomotion Python SDK.

Allows stateful multi-step CLI workflows by keeping a daemon process alive
that maintains node state (in-memory documents, connections, etc.) across
multiple CLI invocations.

Architecture:
  - Client sends JSON request over Unix socket (or TCP on Windows)
  - Daemon dispatches to node lifecycle (OnCreate/OnMessage/OnClose)
  - Nodes stay alive in the daemon process between calls

Matches the Go implementation in cli_session.go.
"""

import json
import os
import sys
import time
import asyncio
import secrets
import signal
import socket
import struct
import threading
from datetime import datetime, timezone

from robomotion.runtime import Runtime
from robomotion.cli_runtime import CLIRuntimeHelper


# Constants
DEFAULT_SESSION_TIMEOUT = 30 * 60  # 30 minutes in seconds
DAEMON_POLL_INTERVAL = 0.1  # 100ms
DAEMON_POLL_MAX_WAIT = 3.0  # 3 seconds
MAX_MSG_SIZE = 64 * 1024 * 1024  # 64 MB


# ---------------------------------------------------------------------------
# Platform-specific session directory and socket handling
# ---------------------------------------------------------------------------

def session_dir():
    """Return platform-specific directory for session files."""
    if sys.platform == 'win32':
        app_data = os.environ.get('LOCALAPPDATA', '')
        if app_data:
            return os.path.join(app_data, 'Robomotion', 'sessions')
        return os.path.join(os.environ.get('TEMP', '/tmp'), 'robomotion-sessions')
    elif sys.platform == 'darwin':
        tmp = os.environ.get('TMPDIR', '/tmp')
        return os.path.join(tmp, 'robomotion-sessions')
    else:
        xdg = os.environ.get('XDG_RUNTIME_DIR', '')
        if xdg:
            return os.path.join(xdg, 'robomotion-sessions')
        return '/tmp/robomotion-sessions'


def _ensure_session_dir():
    d = session_dir()
    os.makedirs(d, mode=0o700, exist_ok=True)
    return d


def session_socket_path(session_id):
    """Return the Unix socket path for a session."""
    return os.path.join(session_dir(), session_id + '.sock')


def session_port_path(session_id):
    """Return the TCP port file path for a session (Windows)."""
    return os.path.join(session_dir(), session_id + '.port')


def session_meta_path(session_id):
    """Return the metadata JSON file path for a session."""
    return os.path.join(session_dir(), session_id + '.json')


def session_dial_addr(session_id):
    """Return (family, address) for connecting to a session, or None."""
    if sys.platform == 'win32':
        port_path = session_port_path(session_id)
        if not os.path.exists(port_path):
            return None
        with open(port_path) as f:
            port = f.read().strip()
        return (socket.AF_INET, ('127.0.0.1', int(port)))
    else:
        sock_path = session_socket_path(session_id)
        if not os.path.exists(sock_path):
            return None
        return (socket.AF_UNIX, sock_path)


def session_ready(session_id):
    """Check if the session socket/port file exists."""
    return session_dial_addr(session_id) is not None


def session_cleanup(session_id):
    """Remove socket/port and metadata files for a session."""
    d = session_dir()
    for ext in ('.sock', '.port', '.json'):
        path = os.path.join(d, session_id + ext)
        try:
            os.remove(path)
        except OSError:
            pass


# ---------------------------------------------------------------------------
# Framed message protocol (length-prefixed JSON over socket)
# ---------------------------------------------------------------------------

def _send_msg(sock, data: dict):
    """Send a length-prefixed JSON message."""
    payload = json.dumps(data).encode('utf-8')
    sock.sendall(struct.pack('>I', len(payload)) + payload)


def _recv_msg(sock) -> dict:
    """Receive a length-prefixed JSON message."""
    raw_len = _recv_exactly(sock, 4)
    if not raw_len:
        return None
    msg_len = struct.unpack('>I', raw_len)[0]
    if msg_len > MAX_MSG_SIZE:
        raise RuntimeError("message too large: %d bytes" % msg_len)
    payload = _recv_exactly(sock, msg_len)
    if not payload:
        return None
    return json.loads(payload.decode('utf-8'))


def _recv_exactly(sock, n):
    """Receive exactly n bytes from socket."""
    buf = bytearray()
    while len(buf) < n:
        chunk = sock.recv(n - len(buf))
        if not chunk:
            return None
        buf.extend(chunk)
    return bytes(buf)


# ---------------------------------------------------------------------------
# Session metadata
# ---------------------------------------------------------------------------

def write_session_metadata(session_id, nodes=None):
    _ensure_session_dir()
    meta = {
        'session_id': session_id,
        'pid': os.getpid(),
        'created_at': datetime.now(timezone.utc).isoformat(),
        'last_activity': datetime.now(timezone.utc).isoformat(),
        'nodes': nodes or [],
    }
    with open(session_meta_path(session_id), 'w') as f:
        json.dump(meta, f, indent=2)


def read_session_metadata(session_id):
    path = session_meta_path(session_id)
    if not os.path.exists(path):
        return None
    with open(path) as f:
        return json.load(f)


def save_session_metadata(session_id, meta):
    meta['last_activity'] = datetime.now(timezone.utc).isoformat()
    with open(session_meta_path(session_id), 'w') as f:
        json.dump(meta, f, indent=2)


# ---------------------------------------------------------------------------
# Session ID generation
# ---------------------------------------------------------------------------

def generate_session_id():
    """Return 8 random hex characters."""
    return secrets.token_hex(4)


def parse_session_timeout(s):
    """Parse timeout string (e.g. '30m', '1h', '60s', '60'). Returns seconds."""
    if not s:
        return DEFAULT_SESSION_TIMEOUT
    s = s.strip()
    try:
        if s.endswith('m'):
            return int(s[:-1]) * 60
        elif s.endswith('h'):
            return int(s[:-1]) * 3600
        elif s.endswith('s'):
            return int(s[:-1])
        else:
            return int(s)
    except (ValueError, IndexError):
        return DEFAULT_SESSION_TIMEOUT


# ---------------------------------------------------------------------------
# Session Daemon
# ---------------------------------------------------------------------------

def run_session_daemon(session_id, timeout, vault_id, item_id):
    """
    Start the session daemon. Listens on a Unix socket (or TCP on Windows),
    dispatches commands to node lifecycle methods, and stays alive until
    timeout or explicit close.
    """
    from robomotion.cli import (
        _discover_node_classes, build_command_map, build_cli_context,
        collect_cli_output, cli_error, inject_credential_config,
    )
    from robomotion.factory import NodeFactory
    from robomotion.node import Node
    from robomotion.testing.context import MockContext

    # Set up CLI runtime
    cli_helper = CLIRuntimeHelper()
    Runtime._cli_helper = cli_helper

    # Handle vault credentials
    if vault_id and item_id:
        try:
            from robomotion.cli_vault import CLIVaultClient
            vault_client = CLIVaultClient.from_env()
            creds = vault_client.fetch_vault_item(vault_id, item_id)
            cli_helper.set_credentials(creds)
        except Exception as e:
            sys.stderr.write(json.dumps({"error": "vault: %s" % str(e)}) + "\n")
            sys.exit(1)

    # Discover and register node factories
    node_classes = _discover_node_classes()
    for cls in node_classes:
        if issubclass(cls, Node) and cls is not Node:
            try:
                name = cls().name
                factory = NodeFactory(cls().cls)
                Runtime.create_node(name, factory)
            except Exception:
                pass

    commands = build_command_map(node_classes)

    # Create listener
    _ensure_session_dir()
    if sys.platform == 'win32':
        server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_sock.bind(('127.0.0.1', 0))
        port = server_sock.getsockname()[1]
        with open(session_port_path(session_id), 'w') as f:
            f.write(str(port))
    else:
        sock_path = session_socket_path(session_id)
        try:
            os.remove(sock_path)
        except OSError:
            pass
        server_sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        server_sock.bind(sock_path)

    server_sock.listen(5)
    server_sock.settimeout(1.0)  # Allow periodic timeout checks

    # Write metadata
    write_session_metadata(session_id)

    # Inactivity timer
    last_activity = time.time()
    shutdown = threading.Event()

    def check_timeout():
        nonlocal last_activity
        while not shutdown.is_set():
            if time.time() - last_activity > timeout:
                shutdown.set()
                break
            shutdown.wait(1.0)

    timeout_thread = threading.Thread(target=check_timeout, daemon=True)
    timeout_thread.start()

    # Handle SIGTERM gracefully
    def on_signal(signum, frame):
        shutdown.set()

    signal.signal(signal.SIGTERM, on_signal)

    # Main loop
    while not shutdown.is_set():
        try:
            conn, _ = server_sock.accept()
        except socket.timeout:
            continue
        except OSError:
            break

        last_activity = time.time()

        try:
            request = _recv_msg(conn)
            if request is None:
                conn.close()
                continue

            action = request.get('action', '')
            response = {}

            if action == 'command':
                cmd_name = request.get('command', '')
                flags = request.get('flags', {})
                v_id = request.get('vault_id', vault_id)
                i_id = request.get('item_id', item_id)

                if cmd_name not in commands:
                    response = {"error": "unknown command: %s" % cmd_name}
                else:
                    entry = commands[cmd_name]
                    cls = entry.cls
                    guid = cmd_name + '-' + generate_session_id()

                    # Build context
                    msg_data, config_patches = build_cli_context(cls, flags)

                    # Build node config
                    node_config = {"guid": guid, "name": cmd_name}
                    for k, v in config_patches.items():
                        node_config[k] = v

                    # Inject defaults for plain Variable option fields
                    from robomotion.cli import inject_option_defaults
                    inject_option_defaults(cls, node_config)

                    # Instantiate node
                    try:
                        inner_cls = cls().cls
                        config_bytes = json.dumps(node_config).encode('utf-8')
                        node = Runtime.deserialize(config_bytes, inner_cls)
                    except Exception as e:
                        response = {"error": "node init failed: %s" % str(e)}
                        _send_msg(conn, response)
                        conn.close()
                        continue

                    # Inject credentials
                    inject_credential_config(node, v_id, i_id)

                    # Register in runtime
                    Runtime.add_node(guid, node)

                    # Update metadata
                    meta = read_session_metadata(session_id) or {}
                    nodes_list = meta.get('nodes', [])
                    nodes_list.append(guid)
                    meta['nodes'] = nodes_list
                    save_session_metadata(session_id, meta)

                    # Build context
                    msg_data['id'] = 'cli-msg-' + guid
                    ctx = MockContext(msg_data)

                    # Run lifecycle
                    try:
                        asyncio.run(node.on_create())
                        asyncio.run(node.on_message(ctx))

                        # Collect output
                        output = collect_cli_output(cls, ctx)
                        output['session_id'] = session_id
                        response = output
                    except Exception as e:
                        response = {"error": str(e)}

            elif action == 'close':
                # Close all active nodes
                for guid in list(Runtime.nodes.keys()):
                    try:
                        node = Runtime.nodes[guid]
                        asyncio.run(node.on_close())
                    except Exception:
                        pass

                response = {"status": "closed"}
                _send_msg(conn, response)
                conn.close()
                shutdown.set()
                break

            else:
                response = {"error": "unknown action: %s" % action}

            _send_msg(conn, response)
            conn.close()

        except Exception as e:
            try:
                _send_msg(conn, {"error": "daemon error: %s" % str(e)})
                conn.close()
            except Exception:
                pass

    # Cleanup
    server_sock.close()
    session_cleanup(session_id)


# ---------------------------------------------------------------------------
# Session Client
# ---------------------------------------------------------------------------

def run_session_client(session_id, command_name, flags):
    """
    Connect to an existing session daemon and send a command.
    Prints JSON result to stdout.
    """
    addr_info = session_dial_addr(session_id)
    if addr_info is None:
        from robomotion.cli import cli_error
        cli_error("session %s not found (daemon not running?)" % session_id)

    family, addr = addr_info

    request = {
        'action': 'command',
        'command': command_name,
        'flags': flags,
    }

    # Extract and forward vault flags
    if 'vault-id' in flags:
        request['vault_id'] = flags.pop('vault-id')
    if 'item-id' in flags:
        request['item_id'] = flags.pop('item-id')

    try:
        sock = socket.socket(family, socket.SOCK_STREAM)
        sock.connect(addr)
        _send_msg(sock, request)
        response = _recv_msg(sock)
        sock.close()
    except Exception as e:
        from robomotion.cli import cli_error
        cli_error("session dial failed: %s" % str(e))

    if response is None:
        from robomotion.cli import cli_error
        cli_error("empty response from session daemon")

    if 'error' in response:
        from robomotion.cli import cli_error
        cli_error(response['error'])

    print(json.dumps(response, indent=2))


def close_session(session_id):
    """Send close command to session daemon."""
    addr_info = session_dial_addr(session_id)
    if addr_info is None:
        from robomotion.cli import cli_error
        cli_error("session %s not found" % session_id)

    family, addr = addr_info
    try:
        sock = socket.socket(family, socket.SOCK_STREAM)
        sock.connect(addr)
        _send_msg(sock, {'action': 'close'})
        response = _recv_msg(sock)
        sock.close()
    except Exception as e:
        from robomotion.cli import cli_error
        cli_error("session close failed: %s" % str(e))

    if response:
        print(json.dumps(response, indent=2))


def start_daemon_process(session_id, timeout, vault_id, item_id):
    """
    Fork the current Python script as a session daemon, then wait
    for the socket/port file to appear.
    """
    import subprocess

    # Build daemon command: python <script> --session-daemon <id> [flags]
    # We need the original script (main.py), not just robomotion
    script = sys.argv[0]
    args = [sys.executable, script, '--session-daemon', session_id]

    if timeout != DEFAULT_SESSION_TIMEOUT:
        args.append('--session-timeout=%d' % timeout)
    if vault_id:
        args.append('--vault-id=%s' % vault_id)
    if item_id:
        args.append('--item-id=%s' % item_id)

    # Start detached process with stdout/stderr going to devnull
    # (daemon logs are not needed; it communicates via socket)
    proc = subprocess.Popen(
        args,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        stdin=subprocess.DEVNULL,
        start_new_session=True,
        cwd=os.getcwd(),
    )

    # Poll for socket/port file
    deadline = time.time() + DAEMON_POLL_MAX_WAIT
    while time.time() < deadline:
        if session_ready(session_id):
            return
        time.sleep(DAEMON_POLL_INTERVAL)

    from robomotion.cli import cli_error
    cli_error("session daemon did not start within %.1fs" % DAEMON_POLL_MAX_WAIT)
