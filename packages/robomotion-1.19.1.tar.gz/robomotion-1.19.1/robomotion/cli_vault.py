"""
CLI Vault Client for Robomotion Python SDK.

Provides direct vault API access with AES-256-CBC decryption for CLI mode,
matching the Go implementation in cli_vault.go.
"""

import os
import json
import re
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

from robomotion.utils import get_config_dir

# Optional cryptography import — only needed when vault features are used
try:
    from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
    from cryptography.hazmat.primitives.asymmetric import padding as asym_padding
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.backends import default_backend
    HAS_CRYPTO = True
except ImportError:
    HAS_CRYPTO = False


DEFAULT_API_URL = "https://api.robomotion.io"


class CLIVaultClient:
    """
    Vault client for CLI mode. Fetches and decrypts vault items using
    the Robomotion API and local robot keys.
    """

    def __init__(self, api_token, robot_id, api_url, private_key=None, vault_secrets=None):
        self._api_token = api_token
        self._robot_id = robot_id
        self._api_url = api_url.rstrip('/')
        self._private_key = private_key
        self._vault_secrets = vault_secrets or {}
        self._vault_key_cache = {}

    @classmethod
    def from_env(cls):
        """
        Create a CLIVaultClient from environment variables.

        Required env vars:
        - ROBOMOTION_API_TOKEN: API auth token
        - ROBOMOTION_ROBOT_ID: Robot ID for key lookup

        Optional:
        - ROBOMOTION_API_URL: API base URL (default: https://api.robomotion.io)
        """
        api_token = os.environ.get('ROBOMOTION_API_TOKEN', '')
        robot_id = os.environ.get('ROBOMOTION_ROBOT_ID', '')
        api_url = os.environ.get('ROBOMOTION_API_URL', DEFAULT_API_URL)

        if not api_token:
            raise RuntimeError(
                "ROBOMOTION_API_TOKEN env var not set; required for vault access"
            )
        if not robot_id:
            raise RuntimeError(
                "ROBOMOTION_ROBOT_ID env var not set; required for vault key lookup"
            )

        private_key = load_robot_private_key(robot_id)
        vault_secrets = load_vault_secrets(robot_id)

        return cls(api_token, robot_id, api_url, private_key, vault_secrets)

    def fetch_vault_item(self, vault_id, item_id):
        """
        Fetch and decrypt a vault item.

        Returns the decrypted credential dict.
        """
        if not HAS_CRYPTO:
            raise RuntimeError(
                "vault decryption requires the 'cryptography' package: "
                "pip install cryptography"
            )

        # Fetch the encrypted item from API
        url = "%s/v1/vaults.items.get?vault_id=%s&item_id=%s" % (
            self._api_url, vault_id, item_id
        )
        resp = api_get(url, self._api_token)
        item_data = resp.get('item', {})

        encrypted_data = item_data.get('data', '')
        iv_hex = item_data.get('iv', '')

        if not encrypted_data or not iv_hex:
            raise RuntimeError("vault item has no encrypted data")

        # Get the AES key for this vault
        aes_key = self.get_vault_key(vault_id)

        # Decrypt the item
        import base64
        encrypted_bytes = base64.b64decode(encrypted_data)
        plaintext = decrypt_aes_cbc(aes_key, encrypted_bytes, iv_hex)

        return json.loads(plaintext)

    def get_vault_key(self, vault_id):
        """
        Derive the AES-256 key for a vault.

        The key is: XOR(RSA_decrypt(vault_key), RSA_decrypt(secret_key))
        """
        if vault_id in self._vault_key_cache:
            return self._vault_key_cache[vault_id]

        # Fetch vault metadata (includes encrypted vault key)
        url = "%s/v1/vaults.get?vault_id=%s" % (self._api_url, vault_id)
        resp = api_get(url, self._api_token)
        vault_data = resp.get('vault', {})

        encrypted_vault_key = vault_data.get('key', '')
        if not encrypted_vault_key:
            raise RuntimeError("vault has no encrypted key")

        # Decrypt vault key with robot's private key
        import base64
        vault_key_bytes = self._rsa_decrypt(base64.b64decode(encrypted_vault_key))

        # Get and decrypt secret key from .vaults files
        secret_key_encrypted = self._vault_secrets.get(vault_id)
        if not secret_key_encrypted:
            raise RuntimeError(
                "no secret key found for vault %s; check .vaults files in %s/keys/%s" % (
                    vault_id, get_config_dir(), self._robot_id
                )
            )

        secret_key_bytes = self._rsa_decrypt(base64.b64decode(secret_key_encrypted))

        # XOR vault key and secret key to get AES key
        aes_key = bytes(a ^ b for a, b in zip(vault_key_bytes, secret_key_bytes))

        self._vault_key_cache[vault_id] = aes_key
        return aes_key

    def _rsa_decrypt(self, ciphertext):
        """RSA-OAEP decrypt using the robot's private key."""
        if self._private_key is None:
            raise RuntimeError("no robot private key loaded")

        return self._private_key.decrypt(
            ciphertext,
            asym_padding.OAEP(
                mgf=asym_padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None
            )
        )

    def resolve_vault_by_name(self, name):
        """Resolve a vault name to its ID via API."""
        url = "%s/v1/vaults.list?robot_id=%s" % (self._api_url, self._robot_id)
        resp = api_get(url, self._api_token)
        vaults = resp.get('vaults', [])

        name_lower = name.lower()
        matches = [v for v in vaults if v.get('name', '').lower() == name_lower]

        if len(matches) == 0:
            available = ", ".join(v.get('name', '') for v in vaults)
            raise RuntimeError(
                'vault "%s" not found; available vaults: %s' % (name, available)
            )
        if len(matches) > 1:
            raise RuntimeError(
                'ambiguous vault name "%s": %d matches found' % (name, len(matches))
            )

        return matches[0]['id']

    def resolve_item_by_name(self, vault_id, name):
        """Resolve a vault item name to its ID via API."""
        url = "%s/v1/vaults.items.list?vault_id=%s" % (self._api_url, vault_id)
        resp = api_get(url, self._api_token)
        items = resp.get('items', [])

        name_lower = name.lower()
        matches = [i for i in items if i.get('name', '').lower() == name_lower]

        if len(matches) == 0:
            available = ", ".join(i.get('name', '') for i in items)
            raise RuntimeError(
                'vault item "%s" not found; available items: %s' % (name, available)
            )
        if len(matches) > 1:
            raise RuntimeError(
                'ambiguous item name "%s": %d matches found' % (name, len(matches))
            )

        return matches[0]['id']


# ---------------------------------------------------------------------------
# Standalone functions
# ---------------------------------------------------------------------------

def load_robot_private_key(robot_id):
    """Load the robot's RSA private key from the keys directory."""
    if not HAS_CRYPTO:
        return None

    keys_dir = os.path.join(get_config_dir(), "keys", robot_id)
    key_path = os.path.join(keys_dir, "private.pem")

    if not os.path.isfile(key_path):
        raise RuntimeError(
            "robot private key not found at %s" % key_path
        )

    with open(key_path, 'rb') as f:
        key_data = f.read()

    return serialization.load_pem_private_key(
        key_data, password=None, backend=default_backend()
    )


def load_vault_secrets(robot_id):
    """
    Load vault secrets from .vaults YAML files in the keys directory.

    Returns a dict of vault_id -> base64-encoded encrypted secret key.
    """
    keys_dir = os.path.join(get_config_dir(), "keys", robot_id)
    secrets = {}

    if not os.path.isdir(keys_dir):
        return secrets

    for fname in os.listdir(keys_dir):
        if fname.endswith('.vaults'):
            fpath = os.path.join(keys_dir, fname)
            try:
                file_secrets = parse_vaults_file(fpath)
                secrets.update(file_secrets)
            except Exception:
                pass

    return secrets


def parse_vaults_file(path):
    """
    Parse a .vaults YAML file.

    Expected format:
      vaults:
        <uuid>: <base64-encoded-key>
        <uuid>: <base64-encoded-key>

    Returns dict of vault_id -> base64 string.
    """
    secrets = {}
    with open(path, 'r') as f:
        in_vaults = False
        for line in f:
            stripped = line.strip()
            if stripped == 'vaults:':
                in_vaults = True
                continue
            if in_vaults:
                if not line.startswith(' ') and not line.startswith('\t'):
                    break
                # Parse "  uuid: base64value"
                match = re.match(r'\s+([0-9a-f-]+):\s*(.+)', stripped)
                if not match:
                    match = re.match(r'([0-9a-f-]+):\s*(.+)', stripped)
                if match:
                    vault_id = match.group(1)
                    secret = match.group(2).strip()
                    secrets[vault_id] = secret

    return secrets


def decrypt_aes_cbc(key, data, iv_hex):
    """
    AES-256-CBC decrypt with PKCS7 unpadding.

    Args:
        key: 32-byte AES key
        data: encrypted bytes
        iv_hex: hex-encoded IV string

    Returns:
        Decrypted plaintext bytes.
    """
    iv = bytes.fromhex(iv_hex)
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
    decryptor = cipher.decryptor()
    plaintext = decryptor.update(data) + decryptor.finalize()

    # PKCS7 unpad
    pad_len = plaintext[-1]
    if pad_len < 1 or pad_len > 16:
        raise RuntimeError("invalid PKCS7 padding")
    for b in plaintext[-pad_len:]:
        if b != pad_len:
            raise RuntimeError("invalid PKCS7 padding")
    return plaintext[:-pad_len]


def api_get(url, token):
    """
    Authenticated GET request via urllib.

    Returns parsed JSON response dict.
    """
    req = Request(url)
    req.add_header('Authorization', 'Bearer %s' % token)
    req.add_header('Accept', 'application/json')

    try:
        with urlopen(req) as resp:
            body = resp.read()
            return json.loads(body)
    except HTTPError as e:
        body = e.read().decode('utf-8', errors='replace')
        raise RuntimeError("API error %d: %s" % (e.code, body))
    except URLError as e:
        raise RuntimeError("API connection error: %s" % str(e.reason))
