"""Proxy Serial class – drop-in replacement for serial.Serial.

Each instance connects to a BrokerServer over IPC (Unix Domain Socket on
POSIX, TCP localhost on Windows). The broker holds the physical port lock,
fans read data out to all proxies, and serialises writes.
"""

import json
import logging
import os
import socket
import struct
import subprocess
import sys
import tempfile
import threading
import time
from collections import deque

from .protocol import (
    MSG_HEADER_SIZE,
    MsgType,
    OriginType,
    decode_header,
    encode_msg,
)

_IS_WINDOWS = sys.platform == "win32"

_CONNECT_RETRIES = 5
_CONNECT_SLEEP = 0.3

log = logging.getLogger(__name__)


def _normalize_port(port: str) -> str:
    for ch in r"/\:":
        port = port.replace(ch, "_")
    return port


def get_socket_path(port: str) -> str:
    """IPC address for *port* (mirrors broker's logic)."""
    safe_port = port
    for ch in r"/\:":
        safe_port = safe_port.replace(ch, "_")

    if _IS_WINDOWS:
        return os.path.join(tempfile.gettempdir(), f"pyserial_mux_{safe_port}.txt")
    return f"/tmp/pyserial_mux_{safe_port}.sock"


def _recv_exact(sock: socket.socket, n: int) -> bytes:
    buf = b""
    while len(buf) < n:
        chunk = sock.recv(n - len(buf))
        if not chunk:
            return b""
        buf += chunk
    return buf


def _connect_to_broker(port: str) -> socket.socket:
    """Return a connected socket to the broker for *port*."""
    sock_path = get_socket_path(port)
    if _IS_WINDOWS:
        with open(sock_path) as f:
            tcp_port = int(f.read().strip())
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.connect(("127.0.0.1", tcp_port))
    else:
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock.connect(sock_path)
    return sock


class Serial:
    """Drop-in replacement for ``serial.Serial`` backed by a broker process."""

    def __init__(
        self,
        port=None,
        baudrate: int = 9600,
        bytesize: int = 8,
        parity: str = "N",
        stopbits: int = 1,
        timeout=None,
        xonxoff: bool = False,
        rtscts: bool = False,
        dsrdtr: bool = False,
        **kwargs,
    ):
        self._port = port
        self._baudrate = baudrate
        self._bytesize = bytesize
        self._parity = parity
        self._stopbits = stopbits
        self.timeout = timeout
        self._xonxoff = xonxoff
        self._rtscts = rtscts
        self._dsrdtr = dsrdtr
        self._extra_kwargs = kwargs
        self._ignore_baudrate_diff = bool(kwargs.get("ignore_baudrate_diff", False))
        self._virtual_interface = kwargs.get("virtual_interface")
        self._client_id = kwargs.get("client_id")
        self._target_id = kwargs.get("target_id")
        self._host_virtual_interface = bool(kwargs.get("host_virtual_interface", False))
        self._logs = bool(kwargs.get("logs", False))
        self._debug = bool(kwargs.get("debug", False))

        if self._debug:
            logging.basicConfig(level=logging.DEBUG)
            log.setLevel(logging.DEBUG)

        self._sock: socket.socket | None = None
        self._closed = True
        self._buffer = bytearray()
        self._buffer_lock = threading.Lock()
        self._buffer_event = threading.Event()
        self._reader_thread: threading.Thread | None = None
        self.other_clients: list[str] = []
        self.shared: dict[str, bytes] = {}
        self.on_log: callable | None = None
        self._log_queue: deque = deque(maxlen=1000)

        if port is not None:
            self.open()

    # ------------------------------------------------------------------
    # open / close
    # ------------------------------------------------------------------

    def open(self):
        if not self._closed:
            return

        port = self._port
        sock_path = get_socket_path(port)
        lock_path = sock_path + ".lock"

        # Acquire a file-based lock so only one process starts the broker.
        lock_fd = self._acquire_start_lock(lock_path)
        try:
            sock = self._try_connect(port)
            if sock is None:
                self._spawn_broker(port)
                sock = self._retry_connect(port)
        finally:
            self._release_start_lock(lock_fd, lock_path)

        self._sock = sock
        self._closed = False

        # Send CONFIG and wait for ACK / ERROR
        cfg = {
            "baudrate": self._baudrate,
            "bytesize": self._bytesize,
            "parity": self._parity,
            "stopbits": self._stopbits,
            "ignore_baudrate_diff": self._ignore_baudrate_diff,
            "virtual_interface": self._virtual_interface,
            "client_id": self._client_id,
            "target_id": self._target_id,
            "host_virtual_interface": self._host_virtual_interface,
            "logs": self._logs,
        }
        if self._debug:
            log.debug("Sending broker config: %s", cfg)
        self._sock.sendall(encode_msg(MsgType.CONFIG, json.dumps(cfg).encode()))

        header = _recv_exact(self._sock, MSG_HEADER_SIZE)
        if not header:
            raise OSError("Broker closed connection during handshake")
        msg_type, length = decode_header(header)
        payload = _recv_exact(self._sock, length) if length else b""

        if msg_type == MsgType.ERROR:
            self._sock.close()
            self._closed = True
            raise ValueError(payload.decode())
        if msg_type != MsgType.ACK:
            self._sock.close()
            self._closed = True
            raise OSError(f"Unexpected handshake response: {msg_type}")

        # Request initial shared store sync
        self._sock.sendall(encode_msg(MsgType.KV_GET))

        # Start background reader
        self._reader_thread = threading.Thread(
            target=self._reader_loop, daemon=True, name="proxy-reader"
        )
        self._reader_thread.start()

    def set_shared(self, key: str, value: bytes):
        """Update a key in the shared data store."""
        if not isinstance(key, str):
            raise TypeError("key must be str")
        if not isinstance(value, (bytes, bytearray)):
            raise TypeError("value must be bytes-like")
        
        k_bytes = key.encode()
        if len(k_bytes) > 255:
            raise ValueError("key too long")
        
        payload = struct.pack("B", len(k_bytes)) + k_bytes + bytes(value)
        self._sock.sendall(encode_msg(MsgType.KV_SET, payload))

    def close(self):
        if self._closed:
            return
        self._closed = True
        try:
            self._sock.sendall(encode_msg(MsgType.CLOSE))
        except OSError:
            pass
        try:
            self._sock.close()
        except OSError:
            pass
        # Wake any blocking read
        self._buffer_event.set()

    # ------------------------------------------------------------------
    # Context manager
    # ------------------------------------------------------------------

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    def __del__(self):
        try:
            self.close()
        except:
            pass

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def is_open(self) -> bool:
        return not self._closed

    @property
    def in_waiting(self) -> int:
        with self._buffer_lock:
            return len(self._buffer)

    @property
    def out_waiting(self) -> int:
        """Return 0 as we don't track the broker's output queue depth."""
        return 0

    @property
    def name(self) -> str | None:
        return self._port

    @property
    def port(self) -> str | None:
        return self._port

    @port.setter
    def port(self, value: str | None):
        self._port = value

    @property
    def baudrate(self) -> int:
        return self._baudrate

    @baudrate.setter
    def baudrate(self, value: int):
        self._baudrate = value
        self._send_runtime_config()

    @property
    def bytesize(self) -> int:
        return self._bytesize

    @bytesize.setter
    def bytesize(self, value: int):
        self._bytesize = value
        self._send_runtime_config()

    @property
    def parity(self) -> str:
        return self._parity

    @parity.setter
    def parity(self, value: str):
        self._parity = value
        self._send_runtime_config()

    @property
    def stopbits(self) -> float:
        return self._stopbits

    @stopbits.setter
    def stopbits(self, value: float):
        self._stopbits = value
        self._send_runtime_config()

    @property
    def xonxoff(self) -> bool:
        return self._xonxoff

    @xonxoff.setter
    def xonxoff(self, value: bool):
        self._xonxoff = value
        self._send_runtime_config()

    @property
    def rtscts(self) -> bool:
        return self._rtscts

    @rtscts.setter
    def rtscts(self, value: bool):
        self._rtscts = value
        self._send_runtime_config()

    @property
    def dsrdtr(self) -> bool:
        return self._dsrdtr

    @dsrdtr.setter
    def dsrdtr(self, value: bool):
        self._dsrdtr = value
        self._send_runtime_config()

    @property
    def cts(self) -> bool:
        return False

    @property
    def dsr(self) -> bool:
        return False

    @property
    def ri(self) -> bool:
        return False

    @property
    def cd(self) -> bool:
        return False

    @property
    def client_id(self) -> str | None:
        return self._client_id

    @client_id.setter
    def client_id(self, value: str | None):
        self._client_id = value
        self._send_runtime_config()

    @property
    def target_id(self) -> str | None:
        return self._target_id

    @target_id.setter
    def target_id(self, value: str | None):
        self._target_id = value
        self._send_runtime_config()

    @property
    def logs(self) -> bool:
        return self._logs

    @logs.setter
    def logs(self, value: bool):
        self._logs = bool(value)
        self._send_runtime_config()

    def get_logs(self) -> list[dict]:
        """Return a list of all buffered log entries."""
        return list(self._log_queue)

    def clear_logs(self):
        """Clear the local log buffer."""
        self._log_queue.clear()

    def _send_runtime_config(self):
        if self._closed:
            return
        cfg = {
            "baudrate": self._baudrate,
            "bytesize": self._bytesize,
            "parity": self._parity,
            "stopbits": self._stopbits,
            "ignore_baudrate_diff": self._ignore_baudrate_diff,
            "virtual_interface": self._virtual_interface,
            "client_id": self._client_id,
            "target_id": self._target_id,
            "host_virtual_interface": self._host_virtual_interface,
            "logs": self._logs,
        }
        self._sock.sendall(encode_msg(MsgType.CONFIG, json.dumps(cfg).encode()))

    # ------------------------------------------------------------------
    # Read / write API
    # ------------------------------------------------------------------

    def read(self, size: int = 1) -> bytes:
        """Read up to *size* bytes, blocking until data arrives or timeout."""
        deadline = None if self.timeout is None else time.monotonic() + self.timeout
        result = bytearray()

        while len(result) < size:
            with self._buffer_lock:
                available = len(self._buffer)
                if available:
                    take = min(size - len(result), available)
                    result += self._buffer[:take]
                    del self._buffer[:take]

            if len(result) >= size:
                break

            if self._closed:
                break

            # Wait for more data
            remaining = None
            if deadline is not None:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    break

            self._buffer_event.clear()
            self._buffer_event.wait(timeout=remaining)

        return bytes(result)

    def read_until(self, expected: bytes = b"\n", size: int | None = None) -> bytes:
        """Read until an expected sequence is found (or *size* or timeout)."""
        deadline = None if self.timeout is None else time.monotonic() + self.timeout
        result = bytearray()

        while True:
            with self._buffer_lock:
                # Check if 'expected' is in our buffer
                idx = self._buffer.find(expected)
                if idx != -1:
                    take = idx + len(expected)
                    if size is not None and len(result) + take > size:
                        take = size - len(result)
                    
                    actual_take = min(take, len(self._buffer))
                    result += self._buffer[:actual_take]
                    del self._buffer[:actual_take]
                    return bytes(result)

                if self._buffer:
                    if size is not None:
                        can_take = size - len(result)
                        if can_take <= 0:
                            return bytes(result)
                        take = min(len(self._buffer), can_take)
                        result += self._buffer[:take]
                        del self._buffer[:take]
                    else:
                        # Take all but keep some for potential 'expected' overlap
                        # Simple implementation: take everything if expected is not found
                        result += self._buffer
                        self._buffer.clear()

            if self._closed:
                break

            if size is not None and len(result) >= size:
                break

            remaining = None
            if deadline is not None:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    break

            self._buffer_event.clear()
            self._buffer_event.wait(timeout=remaining)

        return bytes(result)

    def read_all(self) -> bytes:
        """Read all currently available data."""
        with self._buffer_lock:
            res = bytes(self._buffer)
            self._buffer.clear()
        return res

    def readinto(self, b) -> int:
        """Read into a pre-allocated buffer."""
        data = self.read(len(b))
        n = len(data)
        b[:n] = data
        return n

    def readline(self, size: int = -1) -> bytes:
        """Read until newline (or *size* bytes or timeout)."""
        return self.read_until(b"\n", size=size if size != -1 else None)

    def readlines(self, hint: int = -1) -> list[bytes]:
        """Read a list of lines."""
        lines = []
        while True:
            line = self.readline()
            if not line:
                break
            lines.append(line)
            if hint != -1 and sum(len(l) for l in lines) >= hint:
                break
        return lines

    def write(self, data: bytes, target_id: str | None = None) -> int:
        if isinstance(data, str):
            raise TypeError("data must be bytes-like, not str")
        if self._closed:
            raise OSError("Serial is closed")
        
        if target_id is not None:
            # Payload: [1 byte target_id len][target_id string][bytes data]
            tid_bytes = str(target_id).encode()
            if len(tid_bytes) > 255:
                raise ValueError("target_id too long (max 255 bytes)")
            payload = struct.pack("B", len(tid_bytes)) + tid_bytes + bytes(data)
            self._sock.sendall(encode_msg(MsgType.WRITE_TO, payload))
        else:
            self._sock.sendall(encode_msg(MsgType.WRITE, bytes(data)))
        return len(data)

    def reset_input_buffer(self):
        """Clear this client's local receive buffer."""
        with self._buffer_lock:
            self._buffer.clear()
        self._buffer_event.clear()

    def flushInput(self):
        """Legacy alias for reset_input_buffer()."""
        self.reset_input_buffer()

    def reset_output_buffer(self):
        """No-op: the broker's write queue cannot be cleared per-client."""

    def flushOutput(self):
        """Legacy alias for reset_output_buffer()."""
        self.reset_output_buffer()

    def flush(self):
        """No-op: writes are sent to broker immediately."""

    def readable(self) -> bool:
        return True

    def writable(self) -> bool:
        return True

    def seekable(self) -> bool:
        return False

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _reader_loop(self):
        """Background thread: receive DATA messages from broker and buffer them."""
        while not self._closed:
            try:
                header = _recv_exact(self._sock, MSG_HEADER_SIZE)
                if not header:
                    break
                msg_type, length = decode_header(header)
                payload = _recv_exact(self._sock, length) if length else b""
                if msg_type == MsgType.DATA:
                    with self._buffer_lock:
                        self._buffer += payload
                    self._buffer_event.set()
                elif msg_type == MsgType.LIST_CLIENTS:
                    all_ids = json.loads(payload.decode())
                    self.other_clients = [cid for cid in all_ids if cid != self._client_id]
                elif msg_type == MsgType.LOG_DATA:
                    # Payload: [8 bytes timestamp (double)][1 byte origin_type][1 byte origin_id_len][origin_id][binary_data]
                    if len(payload) >= 10:
                        ts, otype_val = struct.unpack(">dB", payload[:9])
                        otype = OriginType(otype_val)
                        oid_len = payload[9]
                        oid = payload[10 : 10 + oid_len].decode()
                        data = payload[10 + oid_len :]
                        log_entry = {
                            "timestamp": ts,
                            "origin_type": otype,
                            "origin_id": oid,
                            "data": data,
                        }
                        self._log_queue.append(log_entry)
                        if self.on_log:
                            try:
                                self.on_log(log_entry)
                            except Exception:
                                pass
                elif msg_type == MsgType.KV_UPDATE:
                    if len(payload) >= 1:
                        k_len = payload[0]
                        key = payload[1 : 1 + k_len].decode()
                        val = payload[1 + k_len :]
                        self.shared[key] = val
                elif msg_type == MsgType.ERROR:
                    break
            except OSError:
                break
        self._closed = True
        self._buffer_event.set()

    def _try_connect(self, port: str) -> socket.socket | None:
        try:
            return _connect_to_broker(port)
        except (OSError, FileNotFoundError, ValueError):
            return None

    def _retry_connect(self, port: str) -> socket.socket:
        for attempt in range(_CONNECT_RETRIES):
            time.sleep(_CONNECT_SLEEP)
            sock = self._try_connect(port)
            if sock is not None:
                return sock
        raise OSError(
            f"Could not connect to broker for port {port!r} "
            f"after {_CONNECT_RETRIES} retries"
        )

    def _spawn_broker(self, port: str):
        kwargs = {}
        for key in ("bytesize", "parity", "stopbits", "xonxoff", "rtscts", "dsrdtr"):
            kwargs[key] = getattr(self, f"_{key}")
        if self._virtual_interface:
            kwargs["virtual_interface"] = self._virtual_interface
        kwargs["debug"] = self._debug
        cmd = [
            sys.executable,
            "-m",
            "pySerialMux._broker_entry",
            port,
            str(self._baudrate),
            json.dumps(kwargs),
        ]
        subprocess.Popen(
            cmd,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            close_fds=True,
        )

    # ------------------------------------------------------------------
    # File-lock helpers (prevent thundering-herd broker spawning)
    # ------------------------------------------------------------------

    @staticmethod
    def _acquire_start_lock(lock_path: str):
        if _IS_WINDOWS:
            import msvcrt
            fd = os.open(lock_path, os.O_CREAT | os.O_RDWR)
            msvcrt.locking(fd, msvcrt.LK_LOCK, 1)
            return fd
        else:
            import fcntl
            fd = os.open(lock_path, os.O_CREAT | os.O_RDWR)
            fcntl.flock(fd, fcntl.LOCK_EX)
            return fd

    @staticmethod
    def _release_start_lock(fd, lock_path: str):
        if _IS_WINDOWS:
            import msvcrt
            try:
                msvcrt.locking(fd, msvcrt.LK_UNLCK, 1)
            except OSError:
                pass
        else:
            import fcntl
            try:
                fcntl.flock(fd, fcntl.LOCK_UN)
            except OSError:
                pass
        try:
            os.close(fd)
        except OSError:
            pass
