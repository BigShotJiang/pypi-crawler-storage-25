"""AmpUp CLI — auto-generated, do not edit."""

from __future__ import annotations

from typing import Optional

import typer

from ampup.cli._context import configure, get_client, output

app = typer.Typer(name="ampup", help="AmpUp CLI", no_args_is_help=True)


@app.callback()
def main(
    api_key: Optional[str] = typer.Option(None, "--api-key", envvar="AMPUP_API_KEY", help="API key"),
    base_url: str = typer.Option("https://app.ampup.ai", "--base-url", envvar="AMPUP_BASE_URL", help="API base URL"),
    output_fmt: str = typer.Option("json", "--output", "-o", help="Output format: json or table"),
) -> None:
    configure(api_key, base_url, output_fmt)


org_app = typer.Typer(no_args_is_help=True)
accounts_app = typer.Typer(no_args_is_help=True)
deals_app = typer.Typer(no_args_is_help=True)
meetings_app = typer.Typer(no_args_is_help=True)
metrics_app = typer.Typer(no_args_is_help=True)
scripts_app = typer.Typer(no_args_is_help=True)
config_app = typer.Typer(no_args_is_help=True)

app.add_typer(org_app, name="org", help="Organization management")
app.add_typer(accounts_app, name="accounts", help="Account management")
app.add_typer(deals_app, name="deals", help="Deal management")
app.add_typer(meetings_app, name="meetings", help="Meeting management")
app.add_typer(metrics_app, name="metrics", help="Metrics management")
app.add_typer(scripts_app, name="scripts", help="Practice scripts")
app.add_typer(config_app, name="config", help="Analysis configuration")


# ── Org ──

@org_app.command()
def get() -> None:
    """Get current organization."""
    output(get_client().org.get_org())

@org_app.command("list")
def list_orgs() -> None:
    """List all organizations."""
    output(get_client().org.list_orgs())


# ── Accounts ──

@accounts_app.command("list")
def list_accounts(
    search: Optional[str] = typer.Option(None, help="Search by name"),
    limit: int = typer.Option(5, help="Max results"),
) -> None:
    """List accounts."""
    from ampup.models.list_accounts_request import ListAccountsRequest
    output(get_client().accounts.list_accounts(ListAccountsRequest(search=search, limit=limit)))

@accounts_app.command("get")
def get_account(account_id: str = typer.Argument(..., help="Account ID")) -> None:
    """Get account details."""
    from ampup.models.get_account_request import GetAccountRequest
    output(get_client().accounts.get_account(GetAccountRequest(account_id=account_id)))

@accounts_app.command()
def create(
    name: str = typer.Option(..., help="Company name"),
    industry: Optional[str] = typer.Option(None, help="Industry"),
    sync_to_crm: bool = typer.Option(False, "--sync-to-crm"),
) -> None:
    """Create account."""
    from ampup.models.create_account_request import CreateAccountRequest
    output(get_client().accounts.create_account(CreateAccountRequest(name=name, industry=industry, sync_to_crm=sync_to_crm)))


# ── Deals ──

@deals_app.command("list")
def list_deals(
    search: Optional[str] = typer.Option(None, help="Search by name"),
    limit: int = typer.Option(5, help="Max results"),
) -> None:
    """List deals."""
    from ampup.models.list_opportunities_request import ListOpportunitiesRequest
    output(get_client().opportunities.list_opportunities(ListOpportunitiesRequest(search=search, limit=limit)))

@deals_app.command("get")
def get_deal(opportunity_id: str = typer.Argument(..., help="Deal ID")) -> None:
    """Get deal details."""
    from ampup.models.get_opportunity_request import GetOpportunityRequest
    output(get_client().opportunities.get_opportunity(GetOpportunityRequest(opportunity_id=opportunity_id)))

@deals_app.command()
def create_deal(
    name: str = typer.Option(..., help="Deal name"),
    amount: float = typer.Option(0.0, help="Amount"),
) -> None:
    """Create deal."""
    from ampup.models.create_opportunity_request import CreateOpportunityRequest
    output(get_client().opportunities.create_opportunity(CreateOpportunityRequest(name=name, amount=amount)))


# ── Meetings ──

@meetings_app.command("list")
def list_meetings(
    search: Optional[str] = typer.Option(None, help="Search"),
    status: Optional[str] = typer.Option(None, help="Status filter"),
    limit: int = typer.Option(5, help="Max results"),
) -> None:
    """List meetings."""
    from ampup.models.list_meetings_request import ListMeetingsRequest
    output(get_client().meetings.list_meetings(ListMeetingsRequest(search=search, status=status, limit=limit)))

@meetings_app.command("get")
def get_meeting(meeting_id: str = typer.Argument(..., help="Meeting ID")) -> None:
    """Get meeting overview."""
    from ampup.models.get_meeting_request import GetMeetingRequest
    output(get_client().meetings.get_meeting(GetMeetingRequest(meeting_id=meeting_id)))

@meetings_app.command()
def transcript(meeting_id: str = typer.Argument(..., help="Meeting ID")) -> None:
    """Get full transcript."""
    from ampup.models.get_meeting_transcript_request import GetMeetingTranscriptRequest
    output(get_client().meetings.get_meeting_transcript(GetMeetingTranscriptRequest(meeting_id=meeting_id)))

@meetings_app.command("pre-brief")
def pre_brief(meeting_id: str = typer.Argument(..., help="Meeting ID")) -> None:
    """Get pre-meeting brief."""
    from ampup.models.get_pre_meeting_brief_request import GetPreMeetingBriefRequest
    output(get_client().meetings.get_pre_meeting_brief(GetPreMeetingBriefRequest(meeting_id=meeting_id)))

@meetings_app.command("post-brief")
def post_brief(meeting_id: str = typer.Argument(..., help="Meeting ID")) -> None:
    """Get post-meeting brief."""
    from ampup.models.get_post_meeting_brief_request import GetPostMeetingBriefRequest
    output(get_client().meetings.get_post_meeting_brief(GetPostMeetingBriefRequest(meeting_id=meeting_id)))

@meetings_app.command()
def analyze(
    meeting_id: str = typer.Argument(..., help="Meeting ID"),
    force: bool = typer.Option(False, "--force"),
) -> None:
    """Trigger meeting analysis."""
    from ampup.models.run_analysis_request import RunAnalysisRequest
    output(get_client().meetings.run_analysis(RunAnalysisRequest(meeting_id=meeting_id, force=force)))


# ── Metrics ──

@metrics_app.command()
def groups() -> None:
    """List metric groups."""
    output(get_client().metrics.list_metric_groups())

@metrics_app.command("list")
def list_metrics() -> None:
    """List metrics."""
    output(get_client().metrics.list_metrics())


# ── Scripts ──

@scripts_app.command("list")
def list_scripts(search: Optional[str] = typer.Option(None, help="Search")) -> None:
    """List practice scripts."""
    from ampup.models.list_practice_scripts_request import ListPracticeScriptsRequest
    output(get_client().practice_scripts.list_practice_scripts(ListPracticeScriptsRequest(search=search)))

@scripts_app.command("get")
def get_script(script_id: str = typer.Argument(..., help="Script ID")) -> None:
    """Get practice script."""
    from ampup.models.get_practice_script_request import GetPracticeScriptRequest
    output(get_client().practice_scripts.get_practice_script(GetPracticeScriptRequest(script_id=script_id)))


# ── Config ──

@config_app.command("get")
def get_config() -> None:
    """Get analysis configuration."""
    output(get_client().config.get_analysis_config())


if __name__ == "__main__":
    app()
