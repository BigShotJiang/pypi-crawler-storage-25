"""Shared CLI context — auto-generated, do not edit."""

from __future__ import annotations

import json
import os
import sys
from typing import Any

from ampup.client import AmpUpClient

_api_key: str | None = None
_base_url: str = "https://app.ampup.ai"
_output_format: str = "json"


def configure(api_key: str | None, base_url: str, output: str) -> None:
    global _api_key, _base_url, _output_format
    _api_key = api_key
    _base_url = base_url
    _output_format = output


def get_client() -> AmpUpClient:
    key = _api_key or os.environ.get("AMPUP_API_KEY")
    if not key:
        print("Error: API key required. Use --api-key or set AMPUP_API_KEY.", file=sys.stderr)
        raise SystemExit(1)
    return AmpUpClient(api_key=key, base_url=_base_url)


def output(data: Any) -> None:
    if hasattr(data, "to_dict"):
        data = data.to_dict()
    if _output_format == "json":
        print(json.dumps(data, indent=2, default=str))
    else:
        _print_table(data)


def _print_table(data: Any, indent: int = 0) -> None:
    prefix = "  " * indent
    if hasattr(data, "to_dict"):
        data = data.to_dict()
    if isinstance(data, dict):
        for key, value in data.items():
            if isinstance(value, (dict, list)):
                print(f"{prefix}{key}:")
                _print_table(value, indent + 1)
            else:
                print(f"{prefix}{key}: {value}")
    elif isinstance(data, list):
        for i, item in enumerate(data):
            print(f"{prefix}[{i}]")
            _print_table(item, indent + 1)
    else:
        print(f"{prefix}{data}")
