"""Accessibility MCP Server -- WCAG 2.1/2.2 Checker fuer AI-Agents."""

from mcp.server.fastmcp import FastMCP
from src.tools.accessibility_tools import (
    check_color_contrast,
    check_url_accessibility,
    validate_aria,
    check_heading_structure,
    check_images_alt,
    check_form_labels,
    generate_a11y_report,
    list_wcag_rules,
)

mcp = FastMCP(
    "accessibility-mcp-server",
    instructions=(
        "MCP-Server fuer Web-Accessibility-Checks nach WCAG 2.1/2.2. "
        "Prueft Webseiten auf Barrierefreiheit: Bildtextalternativen, Kontrast, ARIA, "
        "Formular-Labels, Ueberschriften-Hierarchie und mehr. Kein API-Key noetig."
    ),
)

# Tools registrieren
mcp.tool()(check_url_accessibility)
mcp.tool()(check_color_contrast)
mcp.tool()(validate_aria)
mcp.tool()(check_heading_structure)
mcp.tool()(check_images_alt)
mcp.tool()(check_form_labels)
mcp.tool()(generate_a11y_report)
mcp.tool()(list_wcag_rules)


def main():
    """Startet den MCP-Server ueber stdio-Transport."""
    mcp.run()


if __name__ == "__main__":
    main()
