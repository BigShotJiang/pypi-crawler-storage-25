"""HTTP-Client zum Abrufen von HTML-Seiten fuer Accessibility-Checks."""

import httpx
from bs4 import BeautifulSoup


async def fetch_html(url: str) -> tuple[str, BeautifulSoup]:
    """Ruft HTML-Inhalt einer URL ab und gibt rohen HTML-Text + BeautifulSoup-Objekt zurueck."""
    headers = {
        "User-Agent": "AccessibilityMCPServer/0.1 (WCAG-Checker; +https://github.com/AiAgentKarl/accessibility-mcp-server)"
    }
    async with httpx.AsyncClient(timeout=30, follow_redirects=True) as client:
        response = await client.get(url, headers=headers)
        response.raise_for_status()
        html = response.text
        soup = BeautifulSoup(html, "lxml")
        return html, soup
