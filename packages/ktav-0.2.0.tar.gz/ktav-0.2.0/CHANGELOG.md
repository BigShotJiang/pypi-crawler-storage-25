# Changelog — `ktav` (Python bindings)

**Languages:** **English** · [Русский](CHANGELOG.ru.md) · [简体中文](CHANGELOG.zh.md)

All notable changes to the `ktav` Python package are documented here.
The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/);
this package adheres to [Semantic Versioning](https://semver.org/) with
the pre-1.0 convention that a MINOR bump is breaking.

For the format specification's own history, see
[`ktav-lang/spec`](https://github.com/ktav-lang/spec). For the
underlying Rust implementation, see
[`ktav-lang/rust`](https://github.com/ktav-lang/rust).

## [0.2.0] — 2026-05-07

### Changed (breaking)

- **Picked up `ktav 0.2.0`** — multi-line strings now serialize in the
  indented stripped `( ... )` form by default. `:f 42` accepts integer
  literals (parsed as `42.0`). See the
  [`ktav` crate CHANGELOG](https://github.com/ktav-lang/rust/blob/main/CHANGELOG.md#020--2026-05-07).

  Code comparing serialized output byte-for-byte to a baked-in
  `((...))` literal must be updated. Round-trip is unchanged.

### Spec

- spec submodule synced (typed_float_integer_body fixture; oracle 42.0).


## [0.1.2] — 2026-05-03

### Changed

- **Picked up `ktav 0.1.5`** — the upstream Rust crate's structured
  errors API (`Error::Structured(ErrorKind)` with byte-offset spans),
  retroactive `#[non_exhaustive]` on the error enums, and the public
  `ktav::thin` event-based parser. The PyO3 binding's user-visible
  behaviour is unchanged: `KtavDecodeError` / `KtavEncodeError` still
  carry the same human-readable messages (Display strings for the
  seven canonical categories are byte-identical to ktav 0.1.4).
  Mapping `ktav::ErrorKind` to a structured Python exception
  hierarchy (`MissingSeparatorSpace`, `DuplicateKey`, etc.) is
  separate follow-up work tracked in the workspace's
  [`STRUCTURED_ERRORS.md`](https://github.com/ktav-lang/.github/blob/main/STRUCTURED_ERRORS.md).

PyPI: `ktav==0.1.2`.

## [0.1.1] — 2026-04-26

### Changed

- **Picked up `ktav 0.1.4`** — the upstream Rust crate's untyped
  `parse() → Value` path (which the PyO3 binding uses) is now ~30%
  faster on small documents and ~13% faster on large ones, just from
  a one-line `Frame::Object` capacity tweak (4 → 8). Every
  `ktav.loads` call benefits transparently.

PyPI: `ktav==0.1.1`.

## [0.1.0] — 2026-04-22

Initial release. Implements [Ktav spec 0.1.0](https://github.com/ktav-lang/spec/blob/main/versions/0.1/spec.md)
via PyO3 bindings over the reference Rust implementation.

### Added

- `ktav.loads(s)` — parse a Ktav string (or UTF-8 `bytes`) into native
  Python values.
- `ktav.dumps(obj)` — serialise a native Python value into Ktav text.
- `ktav.load(fp)` / `ktav.dump(obj, fp)` — file-like wrappers that work
  for both text-mode and binary-mode files.
- Exception hierarchy: `KtavError` (base), `KtavDecodeError`,
  `KtavEncodeError`.
- Type mapping honouring Ktav's "no magic types" principle:
  - bare scalars → `str`;
  - `:i` marker → `int` (arbitrary precision round-trips);
  - `:f` marker → `float` (decimal point always present on output);
  - keywords `null` / `true` / `false` → `None` / `bool`;
  - `[ ... ]` → `list`;
  - `{ ... }` → `dict` (insertion order preserved).
- `NaN` / `±Infinity` rejected by the serialiser — Ktav 0.1.0 does not
  represent them.
- Bundled `.pyi` type stubs and `py.typed` marker (PEP 561).
- `ktav.__version__` — package version.
- `ktav.__spec_version__` — Ktav format version these bindings
  implement.

### Supported platforms

Prebuilt wheels:

- **Linux** (manylinux + musllinux) — `x86_64`, `aarch64`
- **macOS** — `x86_64`, `arm64`
- **Windows** — `x64`, `arm64`

Wheels use the stable ABI (`abi3-py39`); one wheel per platform serves
every supported CPython release.

### MSRV

Rust **1.70** or newer — matches the underlying `ktav` crate.
