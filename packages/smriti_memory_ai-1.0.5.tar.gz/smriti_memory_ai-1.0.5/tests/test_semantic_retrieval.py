import unittest

from tests.helpers import SynonymEmbeddingModel
from smriti.semantic_memory import SemanticMemory


class SemanticRetrievalAccuracyTests(unittest.TestCase):
    def test_paraphrased_query_returns_relevant_entry(self):
        memory = SemanticMemory(embedding_model=SynonymEmbeddingModel(), faiss_module=None)
        memory.add_entry("user-a", "health", "Maya is a doctor at a community clinic.")
        memory.add_entry("user-a", "transport", "Maya drives an electric car.")
        memory.add_entry("user-a", "profile", "Maya enjoys travel writing.")

        result = memory.retrieve("user-a", "health", "physician medical work", k=1)

        self.assertEqual(result[0].entry.text, "Maya is a doctor at a community clinic.")

    def test_session_and_topic_boundaries_are_respected(self):
        memory = SemanticMemory(embedding_model=SynonymEmbeddingModel(), faiss_module=None)
        memory.add_entry("user-a", "transport", "Alex owns a blue automobile.")
        memory.add_entry("user-a", "finance", "Alex tracks revenue in a dashboard.")
        memory.add_entry("user-b", "transport", "Sam owns a red vehicle.")

        user_a_transport = memory.retrieve("user-a", "transport", "car", k=3)
        user_a_finance = memory.retrieve("user-a", "finance", "car", k=3)
        user_b_transport = memory.retrieve("user-b", "transport", "car", k=3)

        self.assertEqual([r.entry.text for r in user_a_transport], ["Alex owns a blue automobile."])
        self.assertEqual([r.entry.text for r in user_a_finance], ["Alex tracks revenue in a dashboard."])
        self.assertEqual([r.entry.text for r in user_b_transport], ["Sam owns a red vehicle."])


if __name__ == "__main__":
    unittest.main()
