import unittest

from tests.helpers import MemoryEchoSmritiAI, StatelessBaseline


FACTS = [
    "My name is Jordan and I am a marine biologist.",
    "I work at the Pacific Ocean Research Institute in Hawaii.",
    "I am currently studying humpback whale migration patterns.",
]

DISTRACTORS = [
    "What is 15 multiplied by 7?",
    "Tell me something about ancient Rome.",
    "What is the speed of light?",
]

RECALLS = [
    ("What is my name and profession?", ("jordan", "marine biologist")),
    ("Where do I work?", ("pacific ocean research institute", "hawaii")),
    ("What am I currently researching?", ("humpback", "whale", "migration")),
]


class MemoryRetentionTests(unittest.TestCase):
    def test_semantic_memory_recalls_all_facts_after_distractors(self):
        upgraded = MemoryEchoSmritiAI(retrieval_mode="semantic", session_id="retention-user")
        baseline = StatelessBaseline()

        upgraded_score = _run_retention(upgraded)
        baseline_score = _run_retention(baseline)

        self.assertEqual(upgraded_score, 1.0)
        self.assertEqual(baseline_score, 0.0)


def _run_retention(agent) -> float:
    for fact in FACTS:
        agent.chat(fact)
    for distractor in DISTRACTORS:
        agent.chat(distractor)

    hits = 0
    for question, expected_terms in RECALLS:
        response = agent.chat(question).lower()
        hits += int(all(term in response for term in expected_terms))
    return hits / len(RECALLS)


if __name__ == "__main__":
    unittest.main()
