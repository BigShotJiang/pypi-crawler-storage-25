import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from fastapi.testclient import TestClient

from smriti.api import USER_MEMORIES, create_app, set_memory_backend
from smriti.backends import JsonBackend


class ApiIntegrationTests(unittest.TestCase):
    def setUp(self):
        USER_MEMORIES.clear()
        set_memory_backend(None)
        self.client = TestClient(create_app())

    def tearDown(self):
        USER_MEMORIES.clear()
        set_memory_backend(None)

    def test_chat_save_load_graph_query_and_user_isolation(self):
        inject = self.client.post(
            "/chat",
            json={
                "user_id": "alice",
                "topic_id": "profile",
                "retrieval_mode": "tfidf",
                "message": "My name is Alice and I work at Ocean Lab.",
            },
        )
        recall = self.client.post(
            "/chat",
            json={
                "user_id": "alice",
                "topic_id": "profile",
                "retrieval_mode": "tfidf",
                "message": "Where do I work?",
            },
        )
        other_user = self.client.post(
            "/chat",
            json={
                "user_id": "bob",
                "topic_id": "profile",
                "retrieval_mode": "tfidf",
                "message": "Where does Alice work?",
            },
        )
        graph = self.client.post(
            "/graph/query",
            json={
                "user_id": "alice",
                "topic_id": "profile",
                "query_entity": "user",
                "depth": 1,
            },
        )

        self.assertEqual(inject.status_code, 200)
        self.assertIn("Ocean Lab", recall.json()["retrieved_context"])
        self.assertNotIn("Ocean Lab", other_user.json()["retrieved_context"])
        self.assertIn("user works at ocean lab.", graph.json()["facts"])

        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "memory.json"
            saved = self.client.post(
                "/memory/save",
                json={"user_id": "alice", "path": str(path)},
            )
            loaded = self.client.post(
                "/memory/load",
                json={"user_id": "charlie", "path": str(path)},
            )

        self.assertEqual(saved.status_code, 200)
        self.assertEqual(loaded.status_code, 200)
        self.assertEqual(loaded.json()["session_id"], "charlie")

    def test_concurrent_agents_share_user_memory(self):
        messages = [
            "My name is Priya.",
            "I work at Robotics Lab.",
            "I am currently studying swarm planning.",
        ]

        def post(message):
            return self.client.post(
                "/chat",
                json={
                    "user_id": "shared-user",
                    "topic_id": "agent-team",
                    "agent_id": "planner",
                    "retrieval_mode": "tfidf",
                    "message": message,
                },
            )

        with ThreadPoolExecutor(max_workers=3) as pool:
            responses = list(pool.map(post, messages))

        recall = self.client.post(
            "/chat",
            json={
                "user_id": "shared-user",
                "topic_id": "agent-team",
                "agent_id": "summariser",
                "retrieval_mode": "tfidf",
                "message": "What do you remember about me?",
            },
        )

        self.assertTrue(all(response.status_code == 200 for response in responses))
        self.assertIn("Priya", recall.json()["retrieved_context"])
        self.assertIn("Robotics Lab", recall.json()["retrieved_context"])

    def test_memory_delete_removes_configured_backend_state(self):
        with tempfile.TemporaryDirectory() as tmp:
            set_memory_backend(JsonBackend(root=tmp))
            self.client = TestClient(create_app())
            self.client.post(
                "/chat",
                json={
                    "user_id": "delete-me",
                    "topic_id": "profile",
                    "retrieval_mode": "tfidf",
                    "message": "My name is Delete Me.",
                },
            )
            self.client.post("/memory/save", json={"user_id": "delete-me"})

            deleted = self.client.post("/memory/delete", json={"user_id": "delete-me"})
            loaded = self.client.post("/memory/load", json={"user_id": "delete-me"})

        self.assertEqual(deleted.status_code, 200)
        self.assertTrue(deleted.json()["deleted_backend"])
        self.assertEqual(loaded.status_code, 404)

    def test_harness_dashboard_endpoints_and_canary(self):
        current = self.client.get("/harness/current")
        history = self.client.get("/harness/history")
        metrics = self.client.get("/harness/metrics")

        self.assertEqual(current.status_code, 200)
        self.assertIn("params", current.json())
        self.assertEqual(history.status_code, 200)
        self.assertEqual(metrics.status_code, 200)

        started = self.client.post(
            "/harness/canary/start",
            json={
                "active_harness": "seed",
                "canary_harness": "evolved-v1",
                "canary_percentage": 10,
            },
        )
        self.assertEqual(started.status_code, 200)
        self.assertTrue(started.json()["enabled"])

        seen = {
            self.client.post(
                "/chat",
                json={"user_id": f"canary-user-{idx}", "message": "My name is Canary."},
            ).json()["memory"]["_harness_id"]
            for idx in range(40)
        }
        self.assertTrue(seen <= {"seed", "evolved-v1"})
        self.assertIn("seed", seen)

        stopped = self.client.post("/harness/canary/stop")
        self.assertEqual(stopped.status_code, 200)
        self.assertFalse(stopped.json()["enabled"])


if __name__ == "__main__":
    unittest.main()
