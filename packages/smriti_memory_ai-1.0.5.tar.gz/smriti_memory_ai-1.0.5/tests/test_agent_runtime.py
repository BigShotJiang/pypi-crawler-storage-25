import tempfile
import unittest
from contextlib import nullcontext
from pathlib import Path
from unittest.mock import patch

from smriti import BaselineGemma, IdentityFingerprint, MemPalaceLite, SmritiAILite
from smriti.semantic_memory import _HashingEmbeddingModel


class FakeTensor:
    def __init__(self, values=None, device="cpu"):
        self.values = values or [1, 2, 3]
        self.device = device

    @property
    def shape(self):
        return (1, len(self.values))

    def to(self, device):
        self.device = str(device)
        return self

    def detach(self):
        return self

    def cpu(self):
        self.device = "cpu"
        return self

    def __getitem__(self, _):
        return self


class FakeParameter:
    device = "cpu"


class FakeModel:
    def __init__(self):
        self.generated = False
        self.moved_to = None

    def parameters(self):
        yield FakeParameter()

    def to(self, device):
        self.moved_to = str(device)
        return self

    def eval(self):
        return self

    def generate(self, **_):
        self.generated = True
        return FakeTensor([1, 2, 3, 4, 5])


class FakeTokenizer:
    eos_token_id = 0

    def apply_chat_template(self, messages, tokenize=False, add_generation_prompt=True):
        return messages[0]["content"] + "\nassistant:"

    def __call__(self, text, **_):
        return {"input_ids": FakeTensor(text.split())}

    def decode(self, *_args, **_kwargs):
        return "Generated memory-aware answer."

    def encode(self, text):
        return text.split()


class FakeGenerationConfig:
    def __init__(self, **kwargs):
        self.kwargs = kwargs


class FakeCuda:
    @staticmethod
    def is_available():
        return False

    @staticmethod
    def is_bf16_supported():
        return False


class FakeTorch:
    cuda = FakeCuda()
    float32 = "float32"
    float16 = "float16"
    bfloat16 = "bfloat16"

    @staticmethod
    def device(name):
        return name

    @staticmethod
    def inference_mode():
        return nullcontext()

    @staticmethod
    def autocast(**_):
        return nullcontext()


class AgentRuntimeTests(unittest.TestCase):
    def test_baseline_and_smriti_generation_paths_with_fake_torch(self):
        with patch("smriti.agent.torch", FakeTorch), patch(
            "smriti.agent.GenerationConfig", FakeGenerationConfig
        ):
            baseline = BaselineGemma(FakeModel(), FakeTokenizer(), auto_device=False)
            baseline.max_new_tokens = 7
            self.assertEqual(baseline.chat("Hello"), "Generated memory-aware answer.")
            self.assertEqual(len(baseline._history), 2)
            baseline.reset()
            self.assertEqual(baseline._history, [])

            memory = MemPalaceLite(
                retrieval_mode="tfidf",
                session_id="runtime",
                topic_id="profile",
            )
            identity = IdentityFingerprint(
                threshold=2.0,
                embedding_model=_HashingEmbeddingModel(),
            )
            agent = SmritiAILite(
                model=FakeModel(),
                tokenizer=FakeTokenizer(),
                memory=memory,
                identity=identity,
                session_id="runtime",
                topic_id="profile",
                auto_device=False,
            )
            self.assertIn("Maintain consistency", agent.build_prompt("Who am I?"))
            self.assertEqual(agent._generate("prompt", max_tokens=3), "Generated memory-aware answer.")
            self.assertEqual(agent.chat("My name is Ada."), "Generated memory-aware answer.")
            self.assertIn("[REASONING CHAIN]", agent.get_reasoning_chain())

            with tempfile.TemporaryDirectory() as tmp:
                path = Path(tmp) / "memory.json"
                agent.save_memory(str(path))
                agent.load_memory(str(path))
                self.assertEqual(agent.get_memory_state()["retrieval_mode"], "tfidf")


if __name__ == "__main__":
    unittest.main()
