import tempfile
import unittest
from pathlib import Path

from fastapi.testclient import TestClient

from demo.app import app
from smriti.api import USER_MEMORIES, set_memory_backend
from smriti.backends import JsonBackend


class DemoAppTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        USER_MEMORIES.clear()
        set_memory_backend(JsonBackend(root=self.tmp.name))
        self.client = TestClient(app)

    def tearDown(self):
        USER_MEMORIES.clear()
        set_memory_backend(None)
        self.tmp.cleanup()

    def test_demo_page_and_frontend_contract(self):
        response = self.client.get("/")

        self.assertEqual(response.status_code, 200)
        html = response.text
        self.assertIn("Smriti AI live dashboard", html)
        self.assertIn("memory cockpit", html)
        self.assertIn("topbar", html)
        self.assertIn("hero-actions", html)
        self.assertIn("Semantic retrieval", html)
        self.assertIn("Knowledge graph", html)
        self.assertIn("Identity governance", html)
        self.assertIn("Agentic harness evolution", html)
        self.assertIn("Observable memory knobs", html)
        self.assertIn("Release and production readiness", html)
        self.assertIn("Production-break suite", html)
        self.assertIn("Production gates", html)
        self.assertIn("No fake/mock/tiny model", html)
        self.assertIn("smriti-memory-ai==", html)
        self.assertIn("Gemma 4 benchmark evidence", html)
        self.assertIn("https://huggingface.co/luciferai-devil/smriti-ai", html)
        self.assertIn("Training status", html)
        self.assertIn("Frozen", html)
        self.assertIn('id="userId"', html)
        self.assertIn('id="topicId"', html)
        self.assertIn('id="messages"', html)
        self.assertIn('id="context"', html)
        self.assertIn('id="graphFacts"', html)
        self.assertIn('id="identityStatus"', html)
        self.assertIn('id="generationStatus"', html)
        self.assertIn('id="benchmarkTable"', html)
        self.assertIn('id="facts"', html)

        script = Path("src/demo/static/app.js").read_text(encoding="utf-8")
        self.assertIn("deleteUserId.value = selectedUserId", script)
        self.assertIn("socket.close()", script)
        self.assertNotIn("setTimeout(() => socket.send(payload)", script)

    def test_status_endpoint_summarises_dashboard_capabilities(self):
        response = self.client.get("/status?user_id=demo-status-user&topic_id=profile")

        self.assertEqual(response.status_code, 200)
        payload = response.json()
        titles = {card["title"] for card in payload["feature_cards"]}
        self.assertIn("Semantic retrieval", titles)
        self.assertIn("Knowledge graph", titles)
        self.assertIn("Identity governance", titles)
        self.assertIn("Gemma 4 benchmarks", titles)
        self.assertIn("AHE harness loop", titles)
        self.assertIn("Production gates", titles)
        self.assertIn("Production-break tests", titles)
        self.assertIn("Release package", titles)
        self.assertIn("No fake claims", titles)
        self.assertIn("Base model", titles)
        self.assertIn("harness", payload)
        self.assertIn("params", payload["harness"])
        self.assertIn("release", payload)
        self.assertIn("readiness", payload)
        self.assertEqual(payload["release"]["package"], "smriti-memory-ai")
        self.assertTrue(payload["release"]["pypi_target"].startswith("smriti-memory-ai=="))
        readiness_titles = {card["title"] for card in payload["readiness"]["cards"]}
        self.assertIn("Production-break suite", readiness_titles)
        self.assertIn("Security acceptance", readiness_titles)
        self.assertEqual(payload["major_results"]["baseline_recall"], "0/3")
        self.assertEqual(payload["major_results"]["smriti_recall"], "3/3")
        self.assertEqual(payload["hf_model_repo"], "https://huggingface.co/luciferai-devil/smriti-ai")
        self.assertFalse(payload["live_model"]["enabled"])
        self.assertEqual(payload["training_status"]["status"], "not fine-tuned")

    def test_websocket_memory_flow_and_delete_endpoint(self):
        user_id = "demo-regression-user"
        with self.client.websocket_connect(f"/ws/{user_id}") as websocket:
            websocket.send_json(
                {
                    "message": "My name is Alex and I am a marine biologist.",
                    "topic_id": "profile",
                }
            )
            injected = websocket.receive_json()
            self.assertIn("Stored new facts", injected["response"])

            websocket.send_json(
                {
                    "message": "What do you remember about me?",
                    "topic_id": "profile",
                }
            )
            recalled = websocket.receive_json()

        combined = "\n".join(
            [
                recalled.get("response", ""),
                recalled.get("retrieved_context", ""),
                " ".join(recalled.get("graph_facts", [])),
                " ".join(fact["text"] for fact in recalled.get("facts", [])),
            ]
        )
        self.assertIn("Alex", combined)
        self.assertIn("marine biologist", combined)
        self.assertTrue(recalled["identity"]["enabled"])
        self.assertEqual(recalled["generation"]["mode"], "memory")
        self.assertIn("dashboard", recalled)

        delete_response = self.client.post("/delete", data={"user_id": user_id}, follow_redirects=False)
        self.assertEqual(delete_response.status_code, 303)
        self.assertNotIn(user_id, USER_MEMORIES)


if __name__ == "__main__":
    unittest.main()
