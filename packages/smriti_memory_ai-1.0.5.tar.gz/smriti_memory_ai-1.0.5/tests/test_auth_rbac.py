import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from fastapi.testclient import TestClient

from smriti.api import USER_MEMORIES, create_app, set_memory_backend
from smriti.backends import JsonBackend


class AuthRBACTests(unittest.TestCase):
    def tearDown(self):
        USER_MEMORIES.clear()
        set_memory_backend(None)

    def test_user_key_can_only_access_bound_user(self):
        with tempfile.TemporaryDirectory() as tmp:
            keys = Path(tmp) / "api_keys.json"
            keys.write_text(
                json.dumps({"alice-secret": {"role": "user", "user_id": "alice", "key_id": "alice"}}),
                encoding="utf-8",
            )
            with patch.dict(
                os.environ,
                {"AUTH_ENABLED": "true", "SMRITI_API_KEYS_PATH": str(keys)},
                clear=False,
            ):
                client = TestClient(create_app())
                own = client.post(
                    "/chat",
                    headers={"x-api-key": "alice-secret"},
                    json={"user_id": "alice", "message": "My name is Alice."},
                )
                other = client.post(
                    "/chat",
                    headers={"x-api-key": "alice-secret"},
                    json={"user_id": "bob", "message": "My name is Bob."},
                )

        self.assertEqual(own.status_code, 200)
        self.assertEqual(other.status_code, 403)

    def test_admin_key_can_delete_any_user(self):
        with tempfile.TemporaryDirectory() as tmp:
            keys = Path(tmp) / "api_keys.json"
            keys.write_text(json.dumps({"admin-secret": {"role": "admin"}}), encoding="utf-8")
            set_memory_backend(JsonBackend(root=tmp))
            with patch.dict(
                os.environ,
                {"AUTH_ENABLED": "true", "SMRITI_API_KEYS_PATH": str(keys)},
                clear=False,
            ):
                client = TestClient(create_app())
                created = client.post(
                    "/chat",
                    headers={"x-api-key": "admin-secret"},
                    json={"user_id": "bob", "message": "My name is Bob."},
                )
                deleted = client.post(
                    "/memory/delete",
                    headers={"x-api-key": "admin-secret"},
                    json={"user_id": "bob"},
                )

        self.assertEqual(created.status_code, 200)
        self.assertEqual(deleted.status_code, 200)


if __name__ == "__main__":
    unittest.main()
