import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from fastapi.testclient import TestClient

from smriti import api as smriti_api
from smriti.api import USER_MEMORIES, create_app, get_memory


class ApiObservabilitySecurityTests(unittest.TestCase):
    def setUp(self):
        USER_MEMORIES.clear()

    def test_metrics_request_id_and_memory_delete(self):
        client = TestClient(create_app())
        response = client.post(
            "/chat",
            headers={"x-request-id": "req-readiness-1"},
            json={
                "user_id": "delete-me",
                "message": "My name is Mira and I work at Ocean Lab.",
            },
        )
        metrics = client.get("/metrics")

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.headers["x-request-id"], "req-readiness-1")
        self.assertIn("smriti_http_requests_total", metrics.text)
        self.assertIn("smriti_retrieval_latency_seconds", metrics.text)

        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "memory.json"
            path.write_text("{}", encoding="utf-8")
            deleted = client.post(
                "/memory/delete",
                json={"user_id": "delete-me", "path": str(path)},
            )

        self.assertEqual(deleted.status_code, 200)
        self.assertTrue(deleted.json()["deleted_memory"])
        self.assertTrue(deleted.json()["deleted_file"])
        self.assertNotIn("delete-me", USER_MEMORIES)

    def test_optional_api_key_protects_mutating_routes(self):
        client = TestClient(create_app())
        with patch.dict(os.environ, {"SMRITI_API_KEY": "secret"}, clear=False):
            health = client.get("/health")
            rejected = client.post(
                "/chat",
                json={"user_id": "secure", "message": "My name is Secure."},
            )
            accepted = client.post(
                "/chat",
                headers={"x-api-key": "secret"},
                json={"user_id": "secure", "message": "My name is Secure."},
            )

        self.assertEqual(health.status_code, 200)
        self.assertEqual(rejected.status_code, 401)
        self.assertEqual(accepted.status_code, 200)

    def test_retrieval_and_graph_failures_degrade_gracefully(self):
        client = TestClient(create_app())
        memory = get_memory("fault-user")

        def boom(*_, **__):
            raise RuntimeError("offline")

        memory.get_context = boom  # type: ignore[method-assign]
        chat = client.post(
            "/chat",
            json={"user_id": "fault-user", "message": "My name is Faulty."},
        )
        self.assertEqual(chat.status_code, 200)
        self.assertTrue(chat.json()["memory"]["_degraded"])
        self.assertIn("primary_retrieval_failure", " ".join(chat.json()["memory"]["_warnings"]))

        memory.knowledge_graph.query_graph = boom  # type: ignore[method-assign]
        graph = client.post(
            "/graph/query",
            json={"user_id": "fault-user", "query_entity": "user"},
        )

        self.assertEqual(graph.status_code, 200)
        self.assertTrue(graph.json()["degraded"])
        self.assertEqual(graph.json()["facts"], [])

    def test_api_main_uses_loaded_app_without_reload_to_avoid_metric_double_registration(self):
        with patch("uvicorn.run") as run:
            smriti_api.main(["--host", "127.0.0.1", "--port", "8999"])

        args, kwargs = run.call_args
        self.assertIs(args[0], smriti_api.app)
        self.assertEqual(kwargs["host"], "127.0.0.1")
        self.assertEqual(kwargs["port"], 8999)

    def test_api_main_uses_import_string_when_reload_is_requested(self):
        with patch("uvicorn.run") as run:
            smriti_api.main(["--reload"])

        args, kwargs = run.call_args
        self.assertEqual(args[0], "smriti.api:app")
        self.assertTrue(kwargs["reload"])


if __name__ == "__main__":
    unittest.main()
