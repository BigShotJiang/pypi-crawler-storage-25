import os
import tempfile
import unittest
from pathlib import Path

from smriti.backend_conformance import run_backend_conformance
from smriti.backends import JsonBackend, MemoryCipher, SqliteBackend, build_backend


class MemoryBackendTests(unittest.TestCase):
    def test_json_backend_saves_retrieves_and_deletes_user_memory(self):
        with tempfile.TemporaryDirectory() as tmp:
            backend = JsonBackend(root=tmp)
            state = {"session_id": "alice", "key_facts": [{"content": "Alice works at Ocean Lab."}]}

            backend.save("alice", state)
            backend.add_entry("alice", "alice", "profile", "Alice works at Ocean Lab.")

            self.assertEqual(backend.load("alice")["session_id"], "alice")
            hits = backend.retrieve("alice", session_id="alice", topic_id="profile", query="Ocean")
            self.assertEqual(hits[0]["text"], "Alice works at Ocean Lab.")
            self.assertTrue(backend.delete_user("alice"))
            self.assertIsNone(backend.load("alice"))

    def test_sqlite_backend_preserves_user_isolation(self):
        with tempfile.TemporaryDirectory() as tmp:
            backend = SqliteBackend(path=Path(tmp) / "memory.sqlite3")
            self.assertIsNone(backend.load("missing"))
            backend.save("alice", {"profile": "Alice"})
            self.assertEqual(backend.load("alice")["profile"], "Alice")
            backend.add_entry("alice", "alice", "profile", "Alice studies whales.")
            backend.add_entry("bob", "bob", "profile", "Bob studies robotics.")

            alice_hits = backend.retrieve("alice", session_id="alice", query="studies", k=5)
            bob_hits = backend.retrieve("bob", session_id="bob", query="studies", k=5)

            self.assertEqual([hit["text"] for hit in alice_hits], ["Alice studies whales."])
            self.assertEqual([hit["text"] for hit in bob_hits], ["Bob studies robotics."])
            self.assertTrue(backend.delete_user("alice"))
            self.assertFalse(backend.delete_user("missing"))

    def test_encrypted_json_backend_does_not_write_plaintext(self):
        with tempfile.TemporaryDirectory() as tmp:
            cipher = MemoryCipher("unit-test-secret")
            self.assertTrue(cipher.enabled)
            backend = JsonBackend(root=tmp, cipher=cipher)

            backend.save("alice", {"secret": "Alice studies whales"})

            raw = (Path(tmp) / "alice.json").read_text(encoding="utf-8")
            self.assertIn('"encrypted": true', raw)
            self.assertNotIn("Alice studies whales", raw)
            self.assertEqual(backend.load("alice")["secret"], "Alice studies whales")

    def test_cipher_plaintext_and_encrypted_error_paths(self):
        plain = MemoryCipher()
        self.assertFalse(plain.enabled)
        self.assertEqual(plain.unwrap(plain.wrap({"ok": True})), {"ok": True})

        encrypted = MemoryCipher("another-secret").wrap({"secret": "value"})
        with self.assertRaises(RuntimeError):
            plain.unwrap(encrypted)

    def test_build_backend_selects_local_backends_and_rejects_unknown(self):
        with tempfile.TemporaryDirectory() as tmp:
            json_backend = build_backend("json", root=Path(tmp) / "json")
            sqlite_backend = build_backend("sqlite", path=Path(tmp) / "db.sqlite3")

            self.assertIsInstance(json_backend, JsonBackend)
            self.assertIsInstance(sqlite_backend, SqliteBackend)
            with self.assertRaises(ValueError):
                build_backend("unknown")

    def test_json_and_sqlite_backends_pass_conformance_contract(self):
        with tempfile.TemporaryDirectory() as tmp:
            backends = [
                JsonBackend(root=Path(tmp) / "json"),
                SqliteBackend(path=Path(tmp) / "memory.sqlite3"),
            ]

            for backend in backends:
                with self.subTest(backend=backend.__class__.__name__):
                    result = run_backend_conformance(backend)
                    self.assertTrue(result.passed)
                    self.assertIn("user_isolation", result.checked)
                    self.assertIn("delete_user", result.checked)

    def test_encrypted_json_backend_passes_conformance_contract(self):
        with tempfile.TemporaryDirectory() as tmp:
            backend = JsonBackend(root=tmp, cipher=MemoryCipher("contract-secret"))
            result = run_backend_conformance(backend)

            self.assertTrue(result.passed)
            self.assertIn("payload_roundtrip", result.checked)

    def tearDown(self):
        os.environ.pop("SMRITI_MEMORY_KEY", None)


if __name__ == "__main__":
    unittest.main()
