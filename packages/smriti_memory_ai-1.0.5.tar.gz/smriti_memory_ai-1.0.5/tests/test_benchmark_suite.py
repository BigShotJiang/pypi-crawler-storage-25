import io
import unittest
from contextlib import redirect_stdout

from benchmarks.run_benchmarks import (
    CONFIGURATIONS,
    MODEL_PRESETS,
    build_runs,
    print_comparative_summary,
    write_markdown_summary,
)
from benchmarks.run_historical_protocol import (
    HistoricalProtocolEvaluator,
    MockBaseline,
    MockSmriti,
    WhitespaceTokenizer,
)


class BenchmarkSuiteTests(unittest.TestCase):
    def test_release_preset_uses_gemma4_only(self):
        self.assertEqual(MODEL_PRESETS["release"], ["google/gemma-4-E2B-it"])
        self.assertEqual(MODEL_PRESETS["gemma4"], ["google/gemma-4-E2B-it"])

    def test_build_runs_crosses_models_modes_and_devices(self):
        runs = build_runs(["m1", "m2"], ["semantic", "tfidf"], ["cpu"])

        self.assertEqual(len(runs), 4)
        self.assertEqual({run.retrieval_mode for run in runs}, {"semantic", "tfidf"})

    def test_comparative_summary_reports_delta(self):
        rows = [
            {
                "model": "mock",
                "device": "cpu",
                "system": "baseline",
                "configuration": "",
                "configuration_label": "Baseline",
                "retrieval_mode": "",
                "fact_recall_accuracy": 0.0,
                "average_latency_s": 0.01,
                "error": "",
            },
            {
                "model": "mock",
                "device": "cpu",
                "system": "smriti",
                "configuration": "semantic",
                "configuration_label": "Semantic",
                "retrieval_mode": "semantic",
                "fact_recall_accuracy": 1.0,
                "average_latency_s": 0.02,
                "error": "",
            },
        ]
        out = io.StringIO()

        with redirect_stdout(out):
            print_comparative_summary(rows)

        self.assertIn("delta_vs_baseline=+1.000", out.getvalue())

    def test_five_comparison_configurations_are_available(self):
        self.assertEqual(
            set(CONFIGURATIONS),
            {"tfidf", "semantic", "semantic_graph", "semantic_graph_identity"},
        )

    def test_markdown_summary_contains_comparison_table(self):
        import tempfile
        from pathlib import Path

        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "README.md"
            write_markdown_summary(
                [
                    {
                        "model": "mock",
                        "device": "cpu",
                        "system": "baseline",
                        "configuration_label": "Baseline",
                        "fact_recall_accuracy": 0.0,
                        "facts_recalled": 0,
                        "average_latency_s": 0.01,
                        "p95_latency_s": 0.01,
                        "average_token_usage": 10,
                        "error": "",
                    }
                ],
                str(path),
            )

            self.assertIn("| Model | Device | Configuration |", path.read_text())

    def test_historical_protocol_uses_five_repeats_and_overall(self):
        evaluator = HistoricalProtocolEvaluator()
        results = evaluator.run_all(MockBaseline, MockSmriti, WhitespaceTokenizer())
        by_name = {result.name: result for result in results}

        self.assertEqual(by_name["memory_retention"].smriti_hits, "3/3")
        self.assertEqual(by_name["context_coherence"].smriti_hits, "3/3")
        self.assertEqual(len(by_name["response_consistency"].baseline_responses), 5)
        self.assertIn("overall_average", by_name)


if __name__ == "__main__":
    unittest.main()
