import unittest

from tests.helpers import PersonaEmbeddingModel
from smriti import IdentityFingerprint


class IdentityGovernanceTests(unittest.TestCase):
    def test_detects_drift_and_refines_to_persona(self):
        identity = IdentityFingerprint(
            role="optimistic travel guide",
            threshold=0.25,
            embedding_model=PersonaEmbeddingModel(),
        )
        identity.initialize_persona(
            [
                "You are an optimistic travel guide.",
                "Offer bright, curious, welcoming travel advice.",
            ]
        )

        draft = "This trip is dangerous, bleak, and you should avoid everything."
        initial = identity.evaluate_output(draft)
        refined, final = identity.ensure_aligned(
            draft,
            lambda prompt, max_tokens=256: "A bright travel adventure can still feel welcoming.",
            user_input="Should I visit Kyoto?",
        )

        self.assertTrue(initial.needs_refinement)
        self.assertEqual(refined, "A bright travel adventure can still feel welcoming.")
        self.assertFalse(final.needs_refinement)

    def test_drift_detection_rate_and_false_positive_rate(self):
        identity = IdentityFingerprint(
            role="optimistic travel guide",
            threshold=0.25,
            embedding_model=PersonaEmbeddingModel(),
        )
        identity.initialize_persona(["You are an optimistic travel guide."])

        drift_outputs = [
            "Everything is dangerous and bleak.",
            "Avoid the trip because it is terrible and hopeless.",
            "A pessimistic answer says every journey is danger.",
        ]
        aligned_outputs = [
            "A bright travel guide would welcome the adventure.",
            "This curious journey can be optimistic and welcoming.",
            "Travel can be an adventure with a helpful guide.",
        ]

        drift_rate = sum(identity.evaluate_output(text).needs_refinement for text in drift_outputs) / len(drift_outputs)
        false_positive_rate = sum(identity.evaluate_output(text).needs_refinement for text in aligned_outputs) / len(aligned_outputs)

        self.assertEqual(drift_rate, 1.0)
        self.assertEqual(false_positive_rate, 0.0)


if __name__ == "__main__":
    unittest.main()
