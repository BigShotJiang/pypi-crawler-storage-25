import io
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path

from smriti.cli import main as cli_main


class CliTests(unittest.TestCase):
    def test_chat_load_save_and_graph_query_commands(self):
        with tempfile.TemporaryDirectory() as tmp:
            memory_path = Path(tmp) / "memory.json"

            out = io.StringIO()
            with redirect_stdout(out):
                chat_code = cli_main(
                    [
                        "--memory-path",
                        str(memory_path),
                        "--session-id",
                        "alex",
                        "--topic-id",
                        "profile",
                        "--retrieval-mode",
                        "tfidf",
                        "chat",
                        "My name is Alex and I work at Ocean Lab.",
                    ]
                )
            self.assertEqual(chat_code, 0)
            self.assertTrue(memory_path.exists())
            self.assertIn("Stored facts", out.getvalue())

            with redirect_stdout(io.StringIO()) as save_out:
                save_code = cli_main(
                    [
                        "--memory-path",
                        str(memory_path),
                        "--session-id",
                        "alex",
                        "--retrieval-mode",
                        "tfidf",
                        "save",
                    ]
                )
            self.assertEqual(save_code, 0)
            self.assertIn('"facts"', save_out.getvalue())

            with redirect_stdout(io.StringIO()) as load_out:
                load_code = cli_main(
                    [
                        "--memory-path",
                        str(memory_path),
                        "--retrieval-mode",
                        "tfidf",
                        "load",
                    ]
                )
            self.assertEqual(load_code, 0)
            self.assertIn('"retrieval_mode": "tfidf"', load_out.getvalue())

            with redirect_stdout(io.StringIO()) as graph_out:
                graph_code = cli_main(
                    [
                        "--memory-path",
                        str(memory_path),
                        "--session-id",
                        "alex",
                        "--topic-id",
                        "profile",
                        "--retrieval-mode",
                        "tfidf",
                        "graph_query",
                        "user",
                    ]
                )
            self.assertEqual(graph_code, 0)
            self.assertIn("ocean lab", graph_out.getvalue().lower())

            with redirect_stdout(io.StringIO()) as delete_out:
                delete_code = cli_main(
                    [
                        "--memory-path",
                        str(memory_path),
                        "--session-id",
                        "alex",
                        "--backend",
                        "json",
                        "--backend-path",
                        str(Path(tmp) / "backend"),
                        "delete",
                    ]
                )
            self.assertEqual(delete_code, 0)
            self.assertIn('"deleted_file": true', delete_out.getvalue())
            self.assertFalse(memory_path.exists())

    def test_backend_conformance_command(self):
        with tempfile.TemporaryDirectory() as tmp:
            with redirect_stdout(io.StringIO()) as out:
                code = cli_main(
                    [
                        "--backend",
                        "json",
                        "--backend-path",
                        str(Path(tmp) / "backend"),
                        "backend",
                        "conformance",
                    ]
                )

            self.assertEqual(code, 0)
            payload = out.getvalue()
            self.assertIn('"passed": true', payload)
            self.assertIn('"user_isolation"', payload)

    def test_migrate_backend_command_copies_user_memory(self):
        with tempfile.TemporaryDirectory() as tmp:
            source = Path(tmp) / "source"
            destination = Path(tmp) / "destination"
            cli_main(
                [
                    "--session-id",
                    "alice",
                    "--backend",
                    "json",
                    "--backend-path",
                    str(source),
                    "--memory-path",
                    str(Path(tmp) / "memory.json"),
                    "chat",
                    "My name is Alice and I study coral reefs.",
                ]
            )
            with redirect_stdout(io.StringIO()) as out:
                code = cli_main(
                    [
                        "--session-id",
                        "alice",
                        "migrate-backend",
                        "--from-backend",
                        "json",
                        "--from-path",
                        str(source),
                        "--to-backend",
                        "json",
                        "--to-path",
                        str(destination),
                    ]
                )

            self.assertEqual(code, 0)
            self.assertIn('"status": "migrated"', out.getvalue())
            self.assertTrue((destination / "alice.json").exists())

    def test_harness_registry_commands(self):
        with redirect_stdout(io.StringIO()) as list_out:
            list_code = cli_main(["harness", "list"])
        self.assertEqual(list_code, 0)
        self.assertIn("seed", list_out.getvalue())

        with redirect_stdout(io.StringIO()) as show_out:
            show_code = cli_main(["harness", "show", "seed"])
        self.assertEqual(show_code, 0)
        self.assertIn('"harness_id": "seed"', show_out.getvalue())

        with redirect_stdout(io.StringIO()) as compare_out:
            compare_code = cli_main(["harness", "compare", "seed", "evolved-v1"])
        self.assertEqual(compare_code, 0)
        self.assertIn('"changes"', compare_out.getvalue())

        with redirect_stdout(io.StringIO()) as verify_out:
            verify_code = cli_main(["harness", "verify-manifest"])
        self.assertEqual(verify_code, 0)
        self.assertIn('"valid": true', verify_out.getvalue())

    def test_missing_harness_fails(self):
        with self.assertRaises(FileNotFoundError):
            cli_main(["harness", "show", "missing-harness"])


if __name__ == "__main__":
    unittest.main()
