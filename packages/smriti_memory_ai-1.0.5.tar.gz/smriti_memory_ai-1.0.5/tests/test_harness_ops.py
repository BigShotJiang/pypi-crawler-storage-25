from pathlib import Path

import pytest

from smriti import canary
from smriti.cross_model_validation import run_cross_model_eval
from smriti.harness import HarnessParams
from smriti.harness_registry import (
    HarnessRegistryError,
    activate_harness,
    compare_harnesses,
    copy_harness,
    create_harness,
    list_harnesses,
    load_harness,
    load_results,
    promote_harness,
    seed_registry_if_missing,
)
from smriti.manifest_schema import ManifestEntry, canonical_manifest_entry
from smriti.production_gates import run_production_gates


def test_harness_registry_lifecycle(tmp_path, monkeypatch):
    monkeypatch.setattr(
        "smriti.harness_registry.ACTIVE_HARNESS_STATE",
        tmp_path / "active_harness.json",
    )
    root = tmp_path / "harnesses"
    seed_registry_if_missing(root)
    rows = list_harnesses(root)
    assert {row["harness_id"] for row in rows} == {"seed", "evolved-v1"}

    seed = load_harness("seed", root)
    evolved = load_harness("evolved-v1", root)
    assert evolved.identity_threshold < seed.identity_threshold
    assert compare_harnesses("seed", "evolved-v1", root)["changes"]

    custom = HarnessParams.from_dict(seed.to_dict())
    custom.top_k = 7
    create_harness("custom", custom, parent_harness_id="seed", results={"metrics": {"recall": 1.0}}, root=root)
    assert load_results("custom", root)["metrics"]["recall"] == 1.0

    target_config = tmp_path / "active.yaml"
    state = activate_harness("custom", root=root, target_config=target_config)
    assert state["active_harness_id"] == "custom"
    assert target_config.exists()

    copied = copy_harness("custom", tmp_path / "copied", root)
    assert (copied / "metadata.json").exists()

    promote_harness("custom", "rejected", root)
    with pytest.raises(HarnessRegistryError):
        load_harness("custom", root)

    promote_harness("custom", "candidate", root)
    monkeypatch.setenv("SMRITI_ENV", "production")
    with pytest.raises(HarnessRegistryError):
        load_harness("custom", root)
    promote_harness("custom", "accepted", root)
    assert load_harness("custom", root).top_k == 7


def test_manifest_schema_canonicalizes_legacy_entry():
    entry = canonical_manifest_entry(
        {
            "component": "top_k",
            "previous_value": 3,
            "new_value": 5,
            "status": "accepted",
            "observed_effect": {"memory_recall_accuracy": 0.1},
            "config_before": {"top_k": 3},
            "config_after": {"top_k": 5},
        }
    )
    parsed = ManifestEntry.model_validate(entry)
    assert parsed.component_changed == "top_k"
    assert parsed.verdict == "accepted"
    assert parsed.observed_metric_delta["memory_recall_accuracy"] == 0.1


def test_cross_model_eval_writes_reports(tmp_path, monkeypatch):
    def fake_validate_harnesses(**kwargs):
        Path(kwargs["output_json"]).write_text("{}", encoding="utf-8")
        return {
            "rows": [
                {"system": "baseline_frozen_model", "memory_recall_accuracy": 0.0, "p95_latency_ms": 0.0, "token_overhead": 0},
                {"system": "smriti_seed_harness", "memory_recall_accuracy": 0.8, "p95_latency_ms": 100.0, "token_overhead": 20},
                {"system": "smriti_evolved_harness", "memory_recall_accuracy": 1.0, "p95_latency_ms": 110.0, "token_overhead": 22},
            ],
            "conclusion": {"production_ready": True},
        }

    monkeypatch.setattr("smriti.cross_model_validation.validate_harnesses", fake_validate_harnesses)
    result = run_cross_model_eval(
        output_csv=str(tmp_path / "cross.csv"),
        output_md=str(tmp_path / "cross.md"),
    )
    assert result["average_improvement"] == pytest.approx(0.2)
    assert result["scope"] == "general-purpose"
    assert (tmp_path / "cross.csv").exists()
    assert "google/gemma-4-E2B-it" in (tmp_path / "cross.md").read_text(encoding="utf-8")


def test_production_gates_success_path(tmp_path, monkeypatch):
    validation = {
        "rows": [
            {"system": "baseline_frozen_model", "privacy_delete_passed": True},
            {"system": "smriti_seed_harness", "privacy_delete_passed": True},
            {"system": "smriti_evolved_harness", "privacy_delete_passed": True},
        ],
        "conclusion": {"production_ready": True, "failures": []},
    }
    promoted = {}

    monkeypatch.setattr("smriti.production_gates._backend_gate", lambda: {"passed": True, "details": {}})
    monkeypatch.setattr("smriti.production_gates._holdout_gate", lambda harness_id: {"passed": True, "details": {"harness_id": harness_id}})
    monkeypatch.setattr("smriti.production_gates.validate_harnesses", lambda **kwargs: validation)
    monkeypatch.setattr("smriti.production_gates.verify_manifest", lambda: {"valid": True})
    monkeypatch.setattr("smriti.production_gates.run_cross_model_eval", lambda **kwargs: {"regressed_models": [], "rows": []})

    def fake_promote(harness_id, status):
        promoted["harness_id"] = harness_id
        promoted["status"] = status
        return {"harness_id": harness_id, "production_status": status}

    monkeypatch.setattr("smriti.production_gates.promote_harness", fake_promote)
    result = run_production_gates(
        "evolved-v1",
        target_status="production",
        run_tests=False,
        report_path=tmp_path / "gate.md",
    )
    assert result["passed"] is True
    assert promoted == {"harness_id": "evolved-v1", "status": "production"}
    assert "validation_benchmark" in (tmp_path / "gate.md").read_text(encoding="utf-8")


def test_canary_sticky_routing_and_auto_rollback(tmp_path):
    canary.STATE.active_harness = "seed"
    canary.STATE.canary_harness = ""
    canary.STATE.canary_percentage = 0
    canary.STATE.enabled = False
    canary.STATE.sticky_routes = {}
    canary.STATE.metrics = {}

    status = canary.start_canary("seed", "evolved-v1", 100)
    assert status["enabled"] is True
    assert canary.route_user("alice") == "evolved-v1"
    assert canary.route_user("alice") == "evolved-v1"

    for _ in range(5):
        canary.record_metric("evolved-v1", latency_ms=10.0, error=True)
    assert canary.STATE.enabled is False
    assert canary.STATE.metrics["rollback"]["last_reason"] == "canary_error_rate_gt_5_percent"

    canary.write_canary_report("unit-test", tmp_path / "canary.md")
    assert "Harness Canary Report" in (tmp_path / "canary.md").read_text(encoding="utf-8")
