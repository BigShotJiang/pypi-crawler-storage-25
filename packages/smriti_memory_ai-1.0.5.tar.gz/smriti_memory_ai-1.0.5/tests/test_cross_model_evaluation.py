import os
import unittest

try:
    import pytest
except Exception:  # pragma: no cover - unittest-only environments do not need pytest.
    pytest = None

from benchmarks.run_benchmarks import MODEL_PRESETS

if pytest is not None:
    pytestmark = pytest.mark.large_model


@unittest.skipUnless(
    os.getenv("RUN_LARGE_MODEL_TESTS") == "1",
    "Set RUN_LARGE_MODEL_TESTS=1 to run gated large-model evaluation checks.",
)
class CrossModelEvaluationTests(unittest.TestCase):
    def test_release_models_are_gemma4_only(self):
        self.assertEqual(MODEL_PRESETS["release"], ["google/gemma-4-E2B-it"])


if __name__ == "__main__":
    unittest.main()
