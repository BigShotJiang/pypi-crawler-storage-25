import io
import os
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path
from unittest.mock import patch

from smriti.cli import main as cli_main
from smriti.config import configure_environment_from_file, load_config, write_default_config
from smriti.integrations.langchain import SmritiMemory
from smriti.integrations.llama_index import SmritiStorageContext


class ConfigAndIntegrationTests(unittest.TestCase):
    def test_config_template_and_environment_defaults(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "config.yaml"
            write_default_config(path)
            config = load_config(path)

            self.assertEqual(config.backend, "json")
            self.assertEqual(config.port, 8000)

            with patch.dict(os.environ, {}, clear=True):
                configure_environment_from_file(path)
                self.assertEqual(os.environ["SMRITI_MEMORY_BACKEND"], "json")
                self.assertEqual(os.environ["SMRITI_AUTOSAVE"], "1")

    def test_config_expands_environment_placeholders_without_leaking_literals(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "config.yaml"
            path.write_text(
                """
memory:
  backend: redis
  redis_url: ${SMRITI_TEST_REDIS_URL}
security:
  encryption_key: ${SMRITI_MISSING_SECRET}
api:
  cors_origins:
    - ${SMRITI_TEST_ORIGIN}
""",
                encoding="utf-8",
            )

            with patch.dict(
                os.environ,
                {
                    "SMRITI_TEST_REDIS_URL": "redis://redis:6379/0",
                    "SMRITI_TEST_ORIGIN": "https://app.example.com",
                },
                clear=True,
            ):
                config = load_config(path)

        self.assertEqual(config.backend, "redis")
        self.assertEqual(config.redis_url, "redis://redis:6379/0")
        self.assertEqual(config.encryption_key, "")
        self.assertEqual(config.cors_origins, ["https://app.example.com"])

    def test_config_environment_variables_override_file_defaults(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "config.yaml"
            write_default_config(path)
            with patch.dict(
                os.environ,
                {
                    "SMRITI_MEMORY_BACKEND": "sqlite",
                    "SMRITI_SQLITE_PATH": "custom.sqlite3",
                    "SMRITI_CORS_ORIGINS": "https://one.example,https://two.example",
                    "SMRITI_AUTOSAVE": "0",
                },
                clear=True,
            ):
                config = load_config(path)

        self.assertEqual(config.backend, "sqlite")
        self.assertEqual(config.sqlite_path, "custom.sqlite3")
        self.assertEqual(config.cors_origins, ["https://one.example", "https://two.example"])
        self.assertFalse(config.autosave)

    def test_cli_init_config_wizard_and_benchmark_command(self):
        with tempfile.TemporaryDirectory() as tmp:
            config_path = Path(tmp) / "config.yaml"

            out = io.StringIO()
            with redirect_stdout(out):
                init_code = cli_main(["init", str(config_path)])
            self.assertEqual(init_code, 0)
            self.assertTrue(config_path.exists())

            wizard_path = Path(tmp) / "wizard.yaml"
            with redirect_stdout(io.StringIO()):
                wizard_code = cli_main(
                    [
                        "config",
                        "wizard",
                        "--path",
                        str(wizard_path),
                        "--backend",
                        "sqlite",
                        "--encrypt",
                    ]
                )
            self.assertEqual(wizard_code, 0)
            text = wizard_path.read_text()
            self.assertIn("backend: sqlite", text)
            self.assertNotIn('encryption_key: ""', text)

            with patch("smriti.cli.subprocess.call", return_value=0) as call:
                bench_code = cli_main(["benchmark", "--max-new-tokens", "8"])
            self.assertEqual(bench_code, 0)
            self.assertIn("--model-preset", call.call_args.args[0])
            self.assertIn("gemma4", call.call_args.args[0])

    def test_langchain_adapter_stores_and_loads_memory(self):
        memory = SmritiMemory(session_id="alex", topic_id="profile")
        memory.save_context(
            {"input": "My name is Alex and I work at Ocean Lab."},
            {"output": "Nice to meet you."},
        )

        variables = memory.load_memory_variables({"input": "Where do I work?"})
        self.assertIn("Ocean Lab", variables["smriti_context"])

        memory.clear()
        cleared = memory.load_memory_variables({"input": "Where do I work?"})
        self.assertEqual(cleared["smriti_context"], "")

    def test_llama_index_storage_context(self):
        storage = SmritiStorageContext(session_id="alex", topic_id="profile")
        storage.add_node("Alex is a marine biologist.")

        results = storage.query("What is Alex's profession?")
        self.assertTrue(any("marine biologist" in result.lower() for result in results))


if __name__ == "__main__":
    unittest.main()
