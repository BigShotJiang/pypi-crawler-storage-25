import tempfile
import unittest
from pathlib import Path

from smriti import IdentityFingerprint, MemPalaceLite
from smriti.semantic_memory import _HashingEmbeddingModel


class SmritiCoreTests(unittest.TestCase):
    def test_semantic_mode_adds_graph_context(self):
        memory = MemPalaceLite(
            retrieval_mode="semantic",
            session_id="alex",
            embedding_model=_HashingEmbeddingModel(),
            faiss_module=None,
        )
        memory.add_fact("I work at Pacific Ocean Research Institute.", session_id="alex")
        context = memory.get_context("Where do I work?", session_id="alex")

        self.assertIn("Pacific Ocean Research Institute", context)
        self.assertIn("[RELATED GRAPH FACTS]", context)

    def test_save_load_keeps_semantic_memory(self):
        model = _HashingEmbeddingModel()
        memory = MemPalaceLite(
            retrieval_mode="semantic",
            session_id="alex",
            embedding_model=model,
            faiss_module=None,
        )
        memory.add_fact("My name is Alex and I am a marine biologist.", session_id="alex")

        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "memory.json"
            memory.save(path)
            loaded = MemPalaceLite.load(
                path,
                retrieval_mode="semantic",
                embedding_model=model,
                faiss_module=None,
            )
            context = loaded.get_context("What is my name?", session_id="alex")
            self.assertIn("Alex", context)

    def test_legacy_json_migrates_into_semantic_memory(self):
        legacy = {
            "history": [],
            "key_facts": [
                {
                    "content": "My name is Alex and I am a marine biologist.",
                    "timestamp": 0,
                    "relevance_score": 1.0,
                    "category": "fact",
                }
            ],
            "patterns": [],
            "step_counter": 0,
        }
        loaded = MemPalaceLite.from_dict(
            legacy,
            retrieval_mode="semantic",
            session_id="alex",
            embedding_model=_HashingEmbeddingModel(),
            faiss_module=None,
        )

        context = loaded.get_context("What is my name?", session_id="alex")
        self.assertIn("Alex", context)


class IdentityFingerprintTests(unittest.TestCase):
    def test_refinement_pass_runs_when_distance_exceeds_threshold(self):
        identity = IdentityFingerprint(
            threshold=0.0,
            embedding_model=_HashingEmbeddingModel(),
        )
        identity.initialize_persona(["I am Jordan, a marine biologist."])
        output, check = identity.ensure_aligned(
            "A completely unrelated draft about tax law.",
            lambda prompt, max_tokens=256: "Jordan is a marine biologist.",
            user_input="Who am I?",
        )

        self.assertTrue(check.consistency_score >= 0.0)
        self.assertEqual(output, "Jordan is a marine biologist.")


if __name__ == "__main__":
    unittest.main()
