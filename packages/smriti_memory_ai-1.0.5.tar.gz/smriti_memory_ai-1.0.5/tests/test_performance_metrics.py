import tempfile
import unittest
from unittest.mock import patch
from pathlib import Path

from scripts.measure_latency import (
    LatencySample,
    main as measure_latency_main,
    summarize_samples,
)


class PerformanceMetricTests(unittest.TestCase):
    def test_latency_summary_computes_average_p95_tokens_and_memory(self):
        samples = [
            LatencySample("baseline", "q1", "a1", 0.01, 4, 0),
            LatencySample("baseline", "q2", "a2", 0.03, 6, 0),
            LatencySample("smriti", "q1", "a1", 0.02, 8, 128),
            LatencySample("smriti", "q2", "a2", 0.04, 10, 256),
        ]

        summary = summarize_samples(samples)

        self.assertAlmostEqual(summary["baseline"]["average_latency_s"], 0.02)
        self.assertEqual(summary["smriti"]["total_tokens"], 18.0)
        self.assertEqual(summary["smriti"]["max_memory_bytes"], 256.0)

    def test_measure_latency_mock_mode_writes_csv(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "latency.csv"
            with patch.dict("os.environ", {"SMRITI_ALLOW_TEST_DOUBLES": "1"}):
                code = measure_latency_main(
                    [
                        "--mock",
                        "--output",
                        str(path),
                        "--queries",
                        "My name is Jordan.",
                        "What is my name?",
                    ]
                )

            self.assertEqual(code, 0)
            text = path.read_text(encoding="utf-8")
            self.assertIn("baseline", text)
            self.assertIn("smriti", text)

    def test_measure_latency_can_run_multiple_retrieval_modes(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "latency_modes.csv"
            with patch.dict("os.environ", {"SMRITI_ALLOW_TEST_DOUBLES": "1"}):
                code = measure_latency_main(
                    [
                        "--mock",
                        "--retrieval-modes",
                        "tfidf",
                        "semantic",
                        "--output",
                        str(path),
                        "--queries",
                        "My name is Jordan.",
                        "What is my name?",
                    ]
                )

            self.assertEqual(code, 0)
            text = path.read_text(encoding="utf-8")
            self.assertIn("retrieval_mode", text)
            self.assertIn("tfidf", text)
            self.assertIn("semantic", text)


if __name__ == "__main__":
    unittest.main()
