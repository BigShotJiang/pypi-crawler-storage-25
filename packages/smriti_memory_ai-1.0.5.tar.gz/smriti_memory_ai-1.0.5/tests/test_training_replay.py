import tempfile
import unittest
from pathlib import Path

from training.ewc_replay import EWCReplayTrainer, TrainingConfig, ReplayBuffer, load_texts


class TrainingReplayTests(unittest.TestCase):
    def test_replay_buffer_keeps_fixed_capacity(self):
        buffer = ReplayBuffer(capacity=2, seed=7)
        buffer.add_many(["one", "two", "three", "four"])

        self.assertEqual(len(buffer.samples), 2)
        self.assertEqual(len(buffer.sample(3)), 3)

    def test_load_texts_supports_jsonl_and_dry_run_metrics(self):
        with tempfile.TemporaryDirectory() as tmp:
            dataset = Path(tmp) / "data.jsonl"
            metrics = Path(tmp) / "metrics.csv"
            dataset.write_text('{"text":"first sample"}\n{"prompt":"second sample"}\n', encoding="utf-8")

            self.assertEqual(load_texts(str(dataset)), ["first sample", "second sample"])

            config = TrainingConfig(
                model_name="dummy/model",
                dataset_path=str(dataset),
                metrics_csv=str(metrics),
                dry_run=True,
                continual=True,
            )
            result = EWCReplayTrainer(config).train()

            self.assertTrue(result["dry_run"])
            self.assertEqual(result["samples"], 2)
            self.assertTrue(metrics.exists())


if __name__ == "__main__":
    unittest.main()
