import importlib.util
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch


class HuggingFaceDeploymentTests(unittest.TestCase):
    def test_handler_memory_only_chat_recall_and_delete(self):
        handler_module = _load_handler_module()
        with tempfile.TemporaryDirectory() as tmp:
            env = {
                "BASE_MODEL_ID": "",
                "HF_ENDPOINT_URL": "",
                "SMRITI_MEMORY_BACKEND": "json",
                "SMRITI_MEMORY_PATH": str(Path(tmp) / "memory.json"),
                "SMRITI_RETRIEVAL_MODE": "tfidf",
                "REDIS_URL": "",
                "POSTGRES_DSN": "",
                "SMRITI_REDIS_URL": "",
                "SMRITI_POSTGRES_DSN": "",
            }
            with patch.dict(os.environ, env, clear=False):
                handler = handler_module.EndpointHandler(
                    path=str(Path("deploy/huggingface_model").resolve())
                )
                health = handler({"inputs": {"operation": "health"}})
                self.assertEqual(health["status"], "ok")

                inject = handler(
                    {
                        "inputs": {
                            "operation": "chat",
                            "user_id": "hf-test-user",
                            "message": "My name is Alex and I am a marine biologist based in Hawaii.",
                            "retrieval_mode": "tfidf",
                        },
                        "parameters": {"return_memories": True},
                    }
                )
                self.assertNotIn("error", inject)

                recall = handler(
                    {
                        "inputs": {
                            "operation": "chat",
                            "user_id": "hf-test-user",
                            "message": "What do you remember about me?",
                            "retrieval_mode": "tfidf",
                        },
                        "parameters": {"return_memories": True},
                    }
                )
                self.assertIn("Alex", recall["response"])
                self.assertTrue(recall["retrieved_memories"])

                deleted = handler(
                    {"inputs": {"operation": "delete_memory", "user_id": "hf-test-user"}}
                )
                self.assertTrue(deleted["deleted"])

                recall_after_delete = handler(
                    {
                        "inputs": {
                            "operation": "chat",
                            "user_id": "hf-test-user",
                            "message": "What do you remember about me?",
                            "retrieval_mode": "tfidf",
                        }
                    }
                )
                self.assertEqual(recall_after_delete["retrieved_memories"], [])


def _load_handler_module():
    path = Path("deploy/huggingface_model/handler.py").resolve()
    spec = importlib.util.spec_from_file_location("smriti_hf_handler_test", path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


if __name__ == "__main__":
    unittest.main()
