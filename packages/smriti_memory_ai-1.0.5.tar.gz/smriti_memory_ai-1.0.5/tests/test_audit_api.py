import tempfile
import unittest
from pathlib import Path

from fastapi.testclient import TestClient

from smriti.api import USER_MEMORIES, create_app, set_memory_backend
from smriti.backends import JsonBackend, SqliteBackend


class AuditApiTests(unittest.TestCase):
    def tearDown(self):
        USER_MEMORIES.clear()
        set_memory_backend(None)

    def test_json_audit_list_pin_archive_delete(self):
        with tempfile.TemporaryDirectory() as tmp:
            backend = JsonBackend(root=tmp)
            backend.add_entry(
                "alice",
                "alice",
                "profile",
                "Alice is a marine biologist based in Hawaii.",
                {"tags": ["profile"]},
            )
            set_memory_backend(backend)
            client = TestClient(create_app())

            listed = client.post("/memory/list", json={"user_id": "alice", "topic_id": "profile"})
            entry = listed.json()["entries"][0]
            pinned = client.post(
                "/memory/pin",
                json={"user_id": "alice", "entry_id": entry["entry_id"], "value": True},
            )
            archived = client.post(
                "/memory/archive",
                json={"user_id": "alice", "entry_id": entry["entry_id"], "value": True},
            )
            hidden = client.post("/memory/list", json={"user_id": "alice", "topic_id": "profile"})
            visible = client.post(
                "/memory/list",
                json={"user_id": "alice", "topic_id": "profile", "include_archived": True},
            )
            deleted = client.post(
                "/memory/entry/delete",
                json={"user_id": "alice", "entry_id": entry["entry_id"]},
            )

        self.assertEqual(listed.status_code, 200)
        self.assertIn("marine biologist", entry["text"])
        self.assertTrue(pinned.json()["entry"]["pinned"])
        self.assertTrue(archived.json()["entry"]["archived"])
        self.assertEqual(hidden.json()["entries"], [])
        self.assertEqual(len(visible.json()["entries"]), 1)
        self.assertTrue(deleted.json()["deleted"])

    def test_sqlite_audit_update(self):
        with tempfile.TemporaryDirectory() as tmp:
            backend = SqliteBackend(Path(tmp) / "memory.sqlite3")
            backend.add_entry("alice", "alice", "profile", "Alice likes coral reefs.", {})
            set_memory_backend(backend)
            client = TestClient(create_app())
            entry = client.post("/memory/list", json={"user_id": "alice"}).json()["entries"][0]
            updated = client.post(
                "/memory/update",
                json={
                    "user_id": "alice",
                    "entry_id": entry["entry_id"],
                    "text": "Alice studies coral restoration.",
                    "metadata": {"tags": ["research"]},
                },
            )

        self.assertEqual(updated.status_code, 200)
        self.assertEqual(updated.json()["entry"]["text"], "Alice studies coral restoration.")
        self.assertEqual(updated.json()["entry"]["metadata"]["tags"], ["research"])


if __name__ == "__main__":
    unittest.main()
