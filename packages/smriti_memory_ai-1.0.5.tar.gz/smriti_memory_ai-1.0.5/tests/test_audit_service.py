import tempfile
import unittest
from pathlib import Path

from smriti.audit import MemoryAuditService
from smriti.backends import JsonBackend, MemoryBackend


class FakeBackend(MemoryBackend):
    def load(self, user_id):
        return None

    def save(self, user_id, memory):
        self.saved = (user_id, memory)

    def add_entry(self, user_id, session_id, topic_id, text, metadata=None):
        pass

    def retrieve(self, user_id, session_id=None, topic_id=None, query="", k=5):
        return [
            {
                "session_id": session_id or user_id,
                "topic_id": topic_id or "general",
                "text": "Generic backend memory about Alex.",
                "metadata": {"pinned": True},
                "created_at": 10,
            }
        ]

    def delete_user(self, user_id):
        return True


class AuditServiceTests(unittest.TestCase):
    def test_json_update_unpin_unarchive_and_missing_entry(self):
        with tempfile.TemporaryDirectory() as tmp:
            backend = JsonBackend(root=Path(tmp))
            backend.add_entry("alice", "alice", "profile", "Alice works at Ocean Lab.", {})
            service = MemoryAuditService(backend)

            updated = service.update_entry(
                "alice",
                "json:0",
                text="Alice works at Reef Lab.",
                metadata={"tags": ["work"]},
            )
            pinned = service.pin_entry("alice", "json:0", True)
            unpinned = service.pin_entry("alice", "json:0", False)
            archived = service.archive_entry("alice", "json:0", True)
            unarchived = service.archive_entry("alice", "json:0", False)

            self.assertEqual(updated.text, "Alice works at Reef Lab.")
            self.assertEqual(updated.metadata["tags"], ["work"])
            self.assertTrue(pinned.pinned)
            self.assertFalse(unpinned.pinned)
            self.assertTrue(archived.archived)
            self.assertFalse(unarchived.archived)
            with self.assertRaises(KeyError):
                service.delete_entry("alice", "json:99")

    def test_runtime_semantic_entries_and_generic_backend_listing(self):
        runtime_state = {
            "session_id": "alice",
            "topic_id": "profile",
            "key_facts": [{"content": "Alice is a marine biologist.", "timestamp": 20}],
            "semantic_memory": {
                "sessions": {
                    "alice": {
                        "topics": {
                            "profile": {
                                "entries": [
                                    {
                                        "text": "Alice is based in Hawaii.",
                                        "timestamp": 30,
                                        "metadata": {"tags": ["location"]},
                                    }
                                ]
                            }
                        }
                    }
                }
            },
        }
        service = MemoryAuditService(FakeBackend())
        entries = service.list_entries(
            "alice",
            session_id="alice",
            topic_id="profile",
            query="Hawaii",
            runtime_state=runtime_state,
        )

        self.assertEqual(len(entries), 1)
        self.assertEqual(entries[0].text, "Alice is based in Hawaii.")
        generic = service.list_entries("bob", query="Alex")
        self.assertEqual(generic[0].source, "FakeBackend")

    def test_unsupported_mutations_raise_clear_errors(self):
        service = MemoryAuditService(FakeBackend())
        with self.assertRaises(NotImplementedError):
            service.update_entry("alice", "retrieval:0", text="new")
        with self.assertRaises(NotImplementedError):
            service.delete_entry("alice", "retrieval:0")


if __name__ == "__main__":
    unittest.main()
