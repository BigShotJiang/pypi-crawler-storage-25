import tempfile
import unittest
from pathlib import Path

from smriti.semantic_memory import SemanticMemory, _HashingEmbeddingModel


class SemanticMemoryTests(unittest.TestCase):
    def test_retrieve_and_persist_session_topic_memory(self):
        model = _HashingEmbeddingModel()
        memory = SemanticMemory(embedding_model=model, faiss_module=None)
        memory.add_entry("user-a", "profile", "Alex is a marine biologist in Hawaii.")
        memory.add_entry("user-a", "profile", "Alex studies whale migration.")
        memory.add_entry("user-b", "profile", "Sam works on finance dashboards.")

        results = memory.retrieve("user-a", "profile", "whale research", k=1)
        self.assertEqual(results[0].entry.text, "Alex studies whale migration.")

        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "memory.json"
            memory.save(path)
            loaded = SemanticMemory.load(path, embedding_model=model, faiss_module=None)
            loaded_results = loaded.retrieve("user-a", "profile", "marine Hawaii", k=1)
            self.assertIn("marine biologist", loaded_results[0].entry.text)
            self.assertEqual(loaded.retrieve("user-b", "profile", "marine Hawaii", k=1)[0].entry.text, "Sam works on finance dashboards.")

    def test_compress_topic_archives_older_entries(self):
        with tempfile.TemporaryDirectory() as tmp:
            archive = Path(tmp) / "archive.jsonl"
            memory = SemanticMemory(
                embedding_model=_HashingEmbeddingModel(),
                faiss_module=None,
                max_entries_per_topic=3,
                archive_path=archive,
            )
            for idx in range(6):
                memory.add_entry("user-a", "project", f"Project note {idx} about semantic memory.")

            entries = memory.recent_entries("user-a", "project", k=10)
            self.assertLessEqual(len(entries), 3)
            self.assertTrue(archive.exists())
            self.assertTrue(archive.read_text(encoding="utf-8").strip())


if __name__ == "__main__":
    unittest.main()
