import tempfile
import unittest
from pathlib import Path

from smriti import MACPLite
from smriti.semantic_memory import SemanticMemory, _HashingEmbeddingModel


class MemoryEdgeCaseTests(unittest.TestCase):
    def test_semantic_memory_empty_invalid_and_recent_paths(self):
        memory = SemanticMemory(embedding_model=_HashingEmbeddingModel(), faiss_module=False)

        self.assertEqual(memory.retrieve("missing", "general", "anything"), [])
        self.assertEqual(memory.recent_entries("missing", "general"), [])
        self.assertIsNone(memory.compress_topic("missing", "general"))
        with self.assertRaises(ValueError):
            memory.add_entry("user", "topic", "   ")

        entry = memory.add_entry("user", "topic", "Nora studies coral reefs.")
        self.assertEqual(entry.text, "Nora studies coral reefs.")
        self.assertEqual(memory.recent_entries("user", "topic", k=1)[0].text, entry.text)
        self.assertIsNone(memory.compress_topic("user", "topic"))

        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "semantic.json"
            memory.save(path)
            loaded = SemanticMemory.load(
                path,
                embedding_model=_HashingEmbeddingModel(),
                faiss_module=False,
            )
            self.assertIn("Nora", loaded.retrieve("user", "topic", "coral", k=1)[0].entry.text)

    def test_macp_records_summarizes_and_resets_reasoning(self):
        macp = MACPLite()
        self.assertEqual(macp.get_chain_summary(), "No reasoning chain yet.")
        macp.start_chain("initial context")
        macp.add_step("input", "output", 0.91, "continue")

        self.assertIn("Step 0", macp.get_chain_summary())
        self.assertEqual(macp.context_buffer, "output")

        macp.reset()
        self.assertEqual(macp.current_step, 0)
        self.assertEqual(macp.reasoning_chain, [])


if __name__ == "__main__":
    unittest.main()
