import tempfile
import unittest
from unittest.mock import patch
from pathlib import Path

from benchmarks.run_identity_bench import run_identity_benchmark
from benchmarks.run_longmem import main as run_longmem_main


class LongMemoryIdentityBenchTests(unittest.TestCase):
    def test_longmem_mock_writes_outputs(self):
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp) / "longmem.csv"
            summary = Path(tmp) / "longmem.md"
            with patch.dict("os.environ", {"SMRITI_ALLOW_TEST_DOUBLES": "1"}):
                code = run_longmem_main(
                    [
                        "--mock",
                        "--retrieval-mode",
                        "tfidf",
                        "--output",
                        str(output),
                        "--summary-output",
                        str(summary),
                    ]
                )
            output_text = output.read_text(encoding="utf-8")
            summary_text = summary.read_text(encoding="utf-8")

        self.assertEqual(code, 0)
        self.assertIn("mean_f1", output_text)
        self.assertIn("LoCoMo-style", summary_text)

    def test_identity_benchmark_labels_false_positives(self):
        rows = run_identity_benchmark(threshold=0.35)
        labels = {row["label"] for row in rows}
        self.assertEqual(labels, {"adversarial", "in_persona"})
        self.assertTrue(all("false_positive" in row for row in rows))


if __name__ == "__main__":
    unittest.main()
