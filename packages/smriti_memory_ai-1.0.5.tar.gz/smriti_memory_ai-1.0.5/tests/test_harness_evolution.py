import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from benchmarks.collect_evidence import collect_evidence
from evolve_harness import evolve_harness
from smriti.core import MemPalaceLite
from smriti.harness import HarnessParams, load_harness_params, write_harness_params
from smriti.semantic_memory import _HashingEmbeddingModel


class HarnessEvolutionTests(unittest.TestCase):
    def test_harness_config_loads_and_applies_to_memory(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "harness.yaml"
            write_harness_params(
                HarnessParams(
                    retrieval_mode="semantic_graph_identity",
                    top_k=7,
                    decay_lambda=0.12,
                    graph_depth=3,
                    identity_threshold=0.42,
                ),
                path,
            )

            with patch.dict("os.environ", {"SMRITI_HARNESS_CONFIG": str(path)}):
                params = load_harness_params()
                memory = MemPalaceLite(embedding_model=_HashingEmbeddingModel(), faiss_module=False)

            self.assertEqual(params.top_k, 7)
            self.assertEqual(memory.default_top_k, 7)
            self.assertEqual(memory.decay_rate, 0.12)
            self.assertEqual(memory.graph_depth, 3)
            self.assertEqual(memory.retrieval_mode, "semantic")

    def test_collect_evidence_writes_summary_and_query_logs(self):
        with tempfile.TemporaryDirectory() as tmp:
            config = Path(tmp) / "harness.yaml"
            summary = Path(tmp) / "evidence_summary.json"
            logs = Path(tmp) / "logs"
            write_harness_params(HarnessParams(top_k=5), config)

            payload = collect_evidence(config_path=config, summary_path=summary, logs_dir=logs)

            self.assertTrue(summary.exists())
            self.assertGreaterEqual(payload["metrics"]["recall_rate"], 1.0)
            self.assertTrue(Path(payload["per_query_log"]).exists())
            lines = Path(payload["per_query_log"]).read_text(encoding="utf-8").splitlines()
            self.assertTrue(any('"phase": "recall"' in line for line in lines))

    def test_evolve_harness_increases_top_k_when_recall_is_low(self):
        with tempfile.TemporaryDirectory() as tmp:
            config = Path(tmp) / "harness.yaml"
            manifest = Path(tmp) / "manifest.jsonl"
            evidence = Path(tmp) / "evidence_summary.json"
            write_harness_params(HarnessParams(top_k=2, recall_target=1.0), config)
            evidence.write_text(
                json.dumps(
                    {
                        "metrics": {
                            "recall_rate": 0.33,
                            "latency_p95_ms": 10.0,
                            "identity_drift_rate": 0.0,
                            "response_consistency": 1.0,
                        }
                    }
                ),
                encoding="utf-8",
            )

            proposal = evolve_harness(
                config_path=config,
                evidence_summary_path=evidence,
                manifest_path=manifest,
            )
            updated = load_harness_params(config)

            self.assertTrue(proposal["changed"])
            self.assertEqual(proposal["component"], "top_k")
            self.assertEqual(updated.top_k, 3)
            self.assertTrue(manifest.exists())
            self.assertIn('"component": "top_k"', manifest.read_text(encoding="utf-8"))


if __name__ == "__main__":
    unittest.main()
