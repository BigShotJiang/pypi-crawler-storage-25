import unittest

from fastapi.testclient import TestClient

from smriti.api import USER_MEMORIES, create_app, get_memory
from smriti.knowledge_graph import KnowledgeGraphMemory, extract_triples


class KnowledgeGraphTests(unittest.TestCase):
    def setUp(self):
        USER_MEMORIES.clear()

    def test_extracts_simple_personal_triples(self):
        triples = extract_triples(
            "My name is Alex and I work at Pacific Ocean Research Institute."
        )
        texts = [triple.to_text() for triple in triples]
        self.assertIn("user name is alex.", texts)
        self.assertIn("user works at pacific ocean research institute.", texts)

    def test_queries_session_isolated_graph(self):
        graph = KnowledgeGraphMemory()
        graph.add_statement("user-a", "profile", "I work at Pacific Ocean Research Institute.")
        graph.add_statement("user-b", "profile", "I work at Mars Robotics Lab.")

        facts_a = graph.triples_to_text(graph.query_graph("user-a", "user", topic_id="profile"))
        facts_b = graph.triples_to_text(graph.query_graph("user-b", "user", topic_id="profile"))

        self.assertEqual(facts_a, ["user works at pacific ocean research institute."])
        self.assertEqual(facts_b, ["user works at mars robotics lab."])

    def test_single_and_multi_hop_graph_queries(self):
        graph = KnowledgeGraphMemory()
        graph.add_triple("science", "Marie Curie", "discovered", "radium", topic_id="chemistry")
        graph.add_triple("science", "radium", "is a", "chemical element", topic_id="chemistry")

        one_hop = graph.triples_to_text(
            graph.query_graph("science", "Who discovered radium?", topic_id="chemistry")
        )
        two_hop = graph.triples_to_text(
            graph.query_graph("science", "radium", depth=2, topic_id="chemistry")
        )

        self.assertIn("Marie Curie discovered radium.", one_hop)
        self.assertIn("radium is a chemical element.", two_hop)

    def test_graph_api_answers_question_like_queries_and_prompt_context(self):
        memory = get_memory("science")
        memory.topic_id = "chemistry"
        memory.knowledge_graph.add_triple(
            "science", "Marie Curie", "discovered", "radium", topic_id="chemistry"
        )
        memory.knowledge_graph.add_triple(
            "science", "radium", "is a", "chemical element", topic_id="chemistry"
        )
        client = TestClient(create_app())

        response = client.post(
            "/graph/query",
            json={
                "user_id": "science",
                "query_entity": "What did Marie Curie discover?",
                "topic_id": "chemistry",
                "depth": 2,
            },
        )
        context = memory.get_context(
            "Who discovered radium?",
            session_id="science",
            topic_id="chemistry",
        )

        self.assertEqual(response.status_code, 200)
        self.assertIn("Marie Curie discovered radium.", response.json()["facts"])
        self.assertIn("Marie Curie discovered radium.", context)


if __name__ == "__main__":
    unittest.main()
