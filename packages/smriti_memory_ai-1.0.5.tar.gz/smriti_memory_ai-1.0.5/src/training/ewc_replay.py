"""Replay/EWC training experiments for small language models.

This module is a research scaffold for the training-time half of the broader
memory story. It is deliberately separate from the Smriti AI inference package:
Smriti AI recall works without fine-tuning, while this module lets researchers
run controlled fine-tuning and continual-learning experiments when desired.
"""

from __future__ import annotations

import argparse
import csv
import json
import random
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence


@dataclass
class TrainingConfig:
    """Configuration for standard fine-tuning or continual replay/EWC runs."""

    model_name: str
    dataset_path: str
    output_dir: str = "training/checkpoints"
    metrics_csv: str = "training/metrics.csv"
    max_length: int = 512
    epochs: float = 1.0
    batch_size: int = 1
    learning_rate: float = 5e-5
    continual: bool = False
    ewc_lambda: float = 0.4
    replay_size: int = 128
    replay_ratio: float = 0.2
    seed: int = 13
    dry_run: bool = False


class ReplayBuffer:
    """Fixed-size reservoir buffer for replay samples from earlier tasks."""

    def __init__(self, capacity: int, seed: int = 13):
        self.capacity = max(0, capacity)
        self.samples: List[str] = []
        self._seen = 0
        self._rng = random.Random(seed)

    def add_many(self, texts: Iterable[str]) -> None:
        for text in texts:
            self.add(text)

    def add(self, text: str) -> None:
        if self.capacity <= 0 or not text.strip():
            return
        self._seen += 1
        if len(self.samples) < self.capacity:
            self.samples.append(text)
            return
        idx = self._rng.randint(0, self._seen - 1)
        if idx < self.capacity:
            self.samples[idx] = text

    def sample(self, count: int) -> List[str]:
        if not self.samples or count <= 0:
            return []
        return [self._rng.choice(self.samples) for _ in range(count)]


@dataclass
class EWCState:
    """Diagonal Fisher-style parameter importance for EWC."""

    reference_params: Mapping[str, Any]
    importance: Mapping[str, Any]


class TextDataset:
    """Tiny causal-LM dataset backed by plain text or JSONL rows."""

    def __init__(self, texts: Sequence[str], tokenizer: Any, max_length: int):
        self.texts = [text for text in texts if text.strip()]
        self.tokenizer = tokenizer
        self.max_length = max_length

    def __len__(self) -> int:
        return len(self.texts)

    def __getitem__(self, idx: int) -> Dict[str, Any]:
        encoded = self.tokenizer(
            self.texts[idx],
            truncation=True,
            max_length=self.max_length,
            padding="max_length",
            return_tensors="pt",
        )
        item = {key: value.squeeze(0) for key, value in encoded.items()}
        item["labels"] = item["input_ids"].clone()
        return item


class EWCTrainerMixin:
    """Mixin that adds an EWC quadratic penalty to HuggingFace Trainer loss."""

    ewc_state: Optional[EWCState] = None
    ewc_lambda: float = 0.0

    def compute_loss(self, model: Any, inputs: Dict[str, Any], return_outputs: bool = False, **_: Any):
        outputs = model(**inputs)
        loss = outputs.loss
        if self.ewc_state is not None and self.ewc_lambda > 0:
            penalty = 0.0
            named_params = dict(model.named_parameters())
            for name, reference in self.ewc_state.reference_params.items():
                param = named_params.get(name)
                importance = self.ewc_state.importance.get(name)
                if param is None or importance is None:
                    continue
                penalty = penalty + (importance * (param - reference).pow(2)).sum()
            loss = loss + self.ewc_lambda * penalty
        return (loss, outputs) if return_outputs else loss


class EWCReplayTrainer:
    """Orchestrates standard fine-tuning and optional EWC/replay training."""

    def __init__(self, config: TrainingConfig):
        self.config = config
        self.replay = ReplayBuffer(config.replay_size, seed=config.seed)

    def train(self) -> Dict[str, Any]:
        """Run the configured training job and write a metrics row."""

        start = time.perf_counter()
        texts = load_texts(self.config.dataset_path)
        if self.config.dry_run:
            metrics = {
                "model_name": self.config.model_name,
                "dataset_path": self.config.dataset_path,
                "samples": len(texts),
                "continual": self.config.continual,
                "dry_run": True,
                "duration_s": time.perf_counter() - start,
            }
            self._write_metrics(metrics)
            return metrics

        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer, Trainer, TrainingArguments

        random.seed(self.config.seed)
        torch.manual_seed(self.config.seed)

        tokenizer = AutoTokenizer.from_pretrained(self.config.model_name)
        if tokenizer.pad_token_id is None:
            tokenizer.pad_token = tokenizer.eos_token
        model = AutoModelForCausalLM.from_pretrained(self.config.model_name)

        replay_samples: List[str] = []
        if self.config.continual:
            replay_count = max(1, int(len(texts) * self.config.replay_ratio))
            replay_samples = self.replay.sample(replay_count)
        train_dataset = TextDataset(texts + replay_samples, tokenizer, self.config.max_length)

        output_root = Path(self.config.output_dir)
        run_dir = output_root / _run_name(self.config.model_name)
        run_dir.mkdir(parents=True, exist_ok=True)
        args = TrainingArguments(
            output_dir=str(run_dir),
            num_train_epochs=self.config.epochs,
            per_device_train_batch_size=self.config.batch_size,
            learning_rate=self.config.learning_rate,
            logging_steps=10,
            save_strategy="epoch",
            report_to=[],
            remove_unused_columns=False,
        )

        trainer_cls = type("TrainerWithEWC", (EWCTrainerMixin, Trainer), {})
        trainer = trainer_cls(model=model, args=args, train_dataset=train_dataset)
        if self.config.continual:
            trainer.ewc_state = self.estimate_importance(model, train_dataset, limit=min(32, len(train_dataset)))
            trainer.ewc_lambda = self.config.ewc_lambda
        train_output = trainer.train()
        trainer.save_model(str(run_dir / "final"))
        tokenizer.save_pretrained(str(run_dir / "final"))
        self.replay.add_many(texts)

        metrics = {
            "model_name": self.config.model_name,
            "dataset_path": self.config.dataset_path,
            "samples": len(texts),
            "replay_samples": len(replay_samples),
            "continual": self.config.continual,
            "ewc_lambda": self.config.ewc_lambda if self.config.continual else 0.0,
            "train_loss": getattr(train_output, "training_loss", None),
            "checkpoint_dir": str(run_dir / "final"),
            "dry_run": False,
            "duration_s": time.perf_counter() - start,
        }
        self._write_metrics(metrics)
        return metrics

    def estimate_importance(self, model: Any, dataset: TextDataset, limit: int = 32) -> EWCState:
        """Estimate diagonal Fisher-style weight importance from squared gradients."""

        import torch
        from torch.utils.data import DataLoader

        device = next(model.parameters()).device
        model.eval()
        importance = {
            name: torch.zeros_like(param, device=device)
            for name, param in model.named_parameters()
            if param.requires_grad
        }
        dataloader = DataLoader(dataset, batch_size=1, shuffle=True)
        used = 0
        for batch in dataloader:
            if used >= limit:
                break
            batch = {key: value.to(device) for key, value in batch.items()}
            model.zero_grad(set_to_none=True)
            loss = model(**batch).loss
            loss.backward()
            for name, param in model.named_parameters():
                if param.grad is not None and name in importance:
                    importance[name] += param.grad.detach().pow(2)
            used += 1
        denom = max(1, used)
        importance = {name: value / denom for name, value in importance.items()}
        reference = {
            name: param.detach().clone()
            for name, param in model.named_parameters()
            if param.requires_grad
        }
        model.train()
        return EWCState(reference_params=reference, importance=importance)

    def _write_metrics(self, metrics: Dict[str, Any]) -> None:
        path = Path(self.config.metrics_csv)
        path.parent.mkdir(parents=True, exist_ok=True)
        exists = path.exists()
        with path.open("a", newline="", encoding="utf-8") as handle:
            fieldnames = sorted(metrics)
            writer = csv.DictWriter(handle, fieldnames=fieldnames)
            if not exists:
                writer.writeheader()
            writer.writerow(metrics)


def load_texts(path: str) -> List[str]:
    """Load training texts from .txt, .jsonl, or a directory of those files."""

    source = Path(path)
    if source.is_dir():
        texts: List[str] = []
        for child in sorted(source.iterdir()):
            if child.suffix.lower() in {".txt", ".jsonl"}:
                texts.extend(load_texts(str(child)))
        return texts
    if not source.exists():
        raise FileNotFoundError(path)
    if source.suffix.lower() == ".jsonl":
        rows = []
        for line in source.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            payload = json.loads(line)
            rows.append(payload.get("text") or payload.get("prompt") or json.dumps(payload))
        return rows
    return [line.strip() for line in source.read_text(encoding="utf-8").splitlines() if line.strip()]


def _run_name(model_name: str) -> str:
    cleaned = "".join(ch if ch.isalnum() or ch in "._-" else "-" for ch in model_name)
    return f"{cleaned}-{int(time.time())}"


def parse_args(argv: Sequence[str] | None = None) -> TrainingConfig:
    parser = argparse.ArgumentParser(description="Run Smriti AI replay/EWC training experiments.")
    parser.add_argument("--model", required=True, dest="model_name")
    parser.add_argument("--dataset", required=True, dest="dataset_path")
    parser.add_argument("--output-dir", default="training/checkpoints")
    parser.add_argument("--metrics-csv", default="training/metrics.csv")
    parser.add_argument("--max-length", type=int, default=512)
    parser.add_argument("--epochs", type=float, default=1.0)
    parser.add_argument("--batch-size", type=int, default=1)
    parser.add_argument("--learning-rate", type=float, default=5e-5)
    parser.add_argument("--continual", action="store_true")
    parser.add_argument("--ewc-lambda", type=float, default=0.4)
    parser.add_argument("--replay-size", type=int, default=128)
    parser.add_argument("--replay-ratio", type=float, default=0.2)
    parser.add_argument("--seed", type=int, default=13)
    parser.add_argument("--dry-run", action="store_true")
    return TrainingConfig(**vars(parser.parse_args(argv)))


def main(argv: Sequence[str] | None = None) -> int:
    config = parse_args(argv)
    metrics = EWCReplayTrainer(config).train()
    print(json.dumps({"config": asdict(config), "metrics": metrics}, indent=2, default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
