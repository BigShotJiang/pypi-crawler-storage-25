"""Training research utilities for Smriti AI.

This package is intentionally separate from the inference-time `smriti` package.
Importing `smriti` does not import this package, preserving Smriti AI's core
training-free memory augmentation path.

Import concrete training classes from `training.ewc_replay` so `python -m
training.ewc_replay` can execute without preloading the module.
"""

__all__: list[str] = []
