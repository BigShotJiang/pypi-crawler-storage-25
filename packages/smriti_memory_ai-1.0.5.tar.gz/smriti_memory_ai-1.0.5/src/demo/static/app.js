const messages = document.querySelector('#messages');
const context = document.querySelector('#context');
const facts = document.querySelector('#facts');
const graphFacts = document.querySelector('#graphFacts');
const identityStatus = document.querySelector('#identityStatus');
const backendStatus = document.querySelector('#backendStatus');
const generationStatus = document.querySelector('#generationStatus');
const messageInput = document.querySelector('#message');
const send = document.querySelector('#send');
const userId = document.querySelector('#userId');
const topicId = document.querySelector('#topicId');
const deleteUserId = document.querySelector('form[action="/delete"] input[name="user_id"]');
let socket;
let socketUserId;

function connect() {
  const selectedUserId = userId.value || 'demo-user';
  if (deleteUserId) deleteUserId.value = selectedUserId;
  if (socket && socket.readyState !== WebSocket.CLOSED && socket.readyState !== WebSocket.CLOSING) {
    socket.close();
  }
  const proto = location.protocol === 'https:' ? 'wss' : 'ws';
  socketUserId = selectedUserId;
  socket = new WebSocket(`${proto}://${location.host}/ws/${encodeURIComponent(selectedUserId)}`);
  socket.onmessage = event => {
    const data = JSON.parse(event.data);
    addMessage(data.response, 'bot');
    renderGeneration(data.generation);
    context.textContent = data.retrieved_context || 'No relevant memory retrieved.';
    renderFacts(data.facts || []);
    renderGraphFacts(data.graph_facts || []);
    renderIdentity(data.identity);
    renderBackend(data.dashboard);
  };
}

function addMessage(text, role) {
  const div = document.createElement('div');
  div.className = `message ${role}`;
  div.textContent = text;
  messages.appendChild(div);
  messages.scrollTop = messages.scrollHeight;
}

function submit(text) {
  const selectedUserId = userId.value || 'demo-user';
  if (!socket || socket.readyState === WebSocket.CLOSED || socket.readyState === WebSocket.CLOSING || socketUserId !== selectedUserId) {
    connect();
  }
  const payload = JSON.stringify({ message: text, topic_id: topicId.value || 'profile' });
  addMessage(text, 'user');
  setGenerationStatus('Generating...');
  if (socket.readyState === WebSocket.OPEN) {
    socket.send(payload);
    return;
  }
  socket.addEventListener('open', () => socket.send(payload), { once: true });
}

function setGenerationStatus(text) {
  if (!generationStatus) return;
  generationStatus.textContent = text;
  generationStatus.classList.toggle('busy', text.toLowerCase().includes('generating'));
}

function renderGeneration(generation) {
  if (!generation) {
    setGenerationStatus('Ready');
    return;
  }
  const mode = generation.mode || 'memory';
  const latency = generation.latency_ms ? ` · ${generation.latency_ms} ms` : '';
  const error = generation.error ? ' · fallback' : '';
  setGenerationStatus(`${mode}${latency}${error}`);
}

function renderFacts(items) {
  facts.innerHTML = '';
  if (!items.length) {
    facts.innerHTML = '<tr><td>No stored facts yet.</td><td>empty</td></tr>';
    return;
  }
  for (const fact of items) {
    const row = document.createElement('tr');
    row.innerHTML = `<td>${escapeHtml(fact.text)}</td><td>${escapeHtml(fact.source)}</td>`;
    facts.appendChild(row);
  }
}

function renderGraphFacts(items) {
  graphFacts.innerHTML = '';
  if (!items.length) {
    graphFacts.innerHTML = '<li>No graph facts yet.</li>';
    return;
  }
  for (const item of items) {
    const li = document.createElement('li');
    li.textContent = item;
    graphFacts.appendChild(li);
  }
}

function renderIdentity(identity) {
  if (!identity) {
    identityStatus.textContent = 'No GIFP check yet.';
    return;
  }
  identityStatus.innerHTML = `
    <strong>${identity.enabled ? 'GIFP active' : 'GIFP off'}</strong>
    <span>drift ${escapeHtml(identity.drift_score)} / threshold ${escapeHtml(identity.threshold)}</span>
    <span>${identity.refinement_triggered ? 'Refinement would trigger' : 'No refinement needed'}</span>
    <small>${escapeHtml(identity.note || '')}</small>
  `;
}

function renderBackend(dashboard) {
  if (!dashboard || !backendStatus) return;
  const backend = dashboard.backend || {};
  const liveModel = dashboard.live_model || {};
  const training = dashboard.training_status || {};
  const release = dashboard.release || {};
  const readiness = dashboard.readiness || {};
  const claims = readiness.result_claims || {};
  backendStatus.innerHTML = `
    <dt>Model mode</dt><dd>${escapeHtml(liveModel.status || 'unknown')} / ${escapeHtml(liveModel.model || 'unknown')}</dd>
    <dt>Device</dt><dd>${escapeHtml(liveModel.device || 'unknown')}</dd>
    <dt>Training</dt><dd>${escapeHtml(training.status || 'not fine-tuned')}</dd>
    <dt>Release</dt><dd>${escapeHtml(release.pypi_target || 'unknown')}</dd>
    <dt>PyPI</dt><dd>${escapeHtml(release.pypi_status || 'check package index')}</dd>
    <dt>Guards</dt><dd>${claims.valid === false ? 'claim provenance review' : 'claim provenance valid'}</dd>
    <dt>Backend</dt><dd>${escapeHtml(backend.name || 'unknown')}</dd>
    <dt>Storage</dt><dd>${escapeHtml(backend.storage || 'unknown')}</dd>
    <dt>Encrypted</dt><dd>${backend.encrypted ? 'yes' : 'ready; set SMRITI_MEMORY_KEY'}</dd>
    <dt>Facts</dt><dd>${escapeHtml(dashboard.memory_count ?? 0)}</dd>
    <dt>Graph facts</dt><dd>${escapeHtml(dashboard.graph_count ?? 0)}</dd>
  `;
}

function escapeHtml(value) {
  return String(value).replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
}

send.addEventListener('click', () => {
  const text = messageInput.value.trim();
  if (!text) return;
  messageInput.value = '';
  submit(text);
});
messageInput.addEventListener('keydown', event => {
  if (event.key === 'Enter') send.click();
});
document.querySelectorAll('[data-message]').forEach(button => {
  button.addEventListener('click', () => submit(button.dataset.message));
});
userId.addEventListener('change', connect);
connect();
