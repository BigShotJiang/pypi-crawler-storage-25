"""Browser dashboard for presenting Smriti AI memory capabilities."""

from __future__ import annotations

import csv
import json
import os
import subprocess
import time
from pathlib import Path
from threading import RLock
from typing import Any, Dict, List

from fastapi import FastAPI, Form, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, PlainTextResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.requests import Request

from smriti import __version__
from smriti.api import USER_MEMORIES, get_memory, get_memory_backend
from smriti.harness import (
    HarnessParams,
    append_manifest_entry,
    apply_harness_to_memory,
    build_manifest_entry,
    format_manifest_rows,
    load_harness_params,
    load_manifest,
    manifest_path,
    resolve_harness_config_path,
    update_params,
    write_harness_params,
)
from smriti.harness_registry import list_harnesses
from smriti.harness_validation import validate_harnesses
from smriti.identity_fingerprint import IdentityFingerprint
from smriti.semantic_memory import _HashingEmbeddingModel

BASE_DIR = Path(__file__).resolve().parent
ROOT_DIR = BASE_DIR.parents[1]
HF_MODEL_REPO = "https://huggingface.co/luciferai-devil/smriti-ai"
GITHUB_REPO = "https://github.com/Luciferai04/smriti-ai"
USER_IDENTITIES: Dict[str, IdentityFingerprint] = {}
DEMO_LAST_SEEN: Dict[str, float] = {}
DEMO_STATE_LOCK = RLock()
MODEL_LOCK = RLock()
MODEL_STATE: Dict[str, Any] = {
    "model": None,
    "tokenizer": None,
    "loaded": False,
    "loading": False,
    "error": None,
    "device": "not loaded",
}

app = FastAPI(title="Smriti AI Demo", version=__version__)
app.mount("/static", StaticFiles(directory=BASE_DIR / "static"), name="static")
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))


@app.get("/", response_class=HTMLResponse)
def index(request: Request, user_id: str = "demo-user", topic_id: str = "profile"):
    """Render the stakeholder dashboard and fast memory demo."""

    _demo_touch(user_id)
    memory = get_memory(user_id)
    facts = _facts(memory, user_id, topic_id)
    dashboard = _dashboard_payload(memory, user_id, topic_id)
    return templates.TemplateResponse(
        request,
        "index.html",
        {
            "user_id": user_id,
            "topic_id": topic_id,
            "facts": facts,
            "dashboard": dashboard,
        },
    )


@app.get("/status")
def status(user_id: str = "demo-user", topic_id: str = "profile") -> Dict[str, Any]:
    """Return dashboard status as JSON for scripted demos."""

    _demo_touch(user_id)
    memory = get_memory(user_id)
    return _dashboard_payload(memory, user_id, topic_id)


@app.post("/delete")
def delete_memory(user_id: str = Form(...)):
    _delete_user_memory(user_id)
    return RedirectResponse(url=f"/?user_id={user_id}&deleted=1", status_code=303)


@app.post("/harness/update")
def update_harness(
    user_id: str = Form("demo-user"),
    topic_id: str = Form("profile"),
    retrieval_mode: str = Form(...),
    top_k: int = Form(...),
    decay_lambda: float = Form(...),
    use_graph: str | None = Form(None),
    graph_depth: int = Form(...),
    identity_threshold: float = Form(...),
    summarisation_threshold: int = Form(...),
):
    before = load_harness_params()
    after = update_params(
        before,
        {
            "retrieval_mode": retrieval_mode,
            "top_k": top_k,
            "decay_lambda": decay_lambda,
            "use_graph": use_graph is not None,
            "graph_depth": graph_depth,
            "identity_threshold": identity_threshold,
            "summarisation_threshold": summarisation_threshold,
        },
    )
    write_harness_params(after)
    for memory in USER_MEMORIES.values():
        apply_harness_to_memory(memory, after)
    changes = _harness_change_summary(before, after)
    append_manifest_entry(
        build_manifest_entry(
            component=changes["component"],
            previous_value=changes["previous_value"],
            new_value=changes["new_value"],
            reason="Manual dashboard override.",
            predicted_impact="Operator override; evaluate with collect_evidence.py.",
            config_before=before,
            config_after=after,
            actor="dashboard",
            status="manual_override",
        )
    )
    return RedirectResponse(url=f"/?user_id={user_id}&topic_id={topic_id}#harness", status_code=303)


@app.post("/harness/rollback")
def rollback_harness(
    user_id: str = Form("demo-user"),
    topic_id: str = Form("profile"),
    manifest_index: int = Form(...),
):
    rows = load_manifest()
    if manifest_index < 0 or manifest_index >= len(rows):
        return RedirectResponse(url=f"/?user_id={user_id}&topic_id={topic_id}#harness", status_code=303)
    row = rows[manifest_index]
    before = load_harness_params()
    rollback_data = row.get("config_before") or row.get("config_after")
    if not rollback_data:
        return RedirectResponse(url=f"/?user_id={user_id}&topic_id={topic_id}#harness", status_code=303)
    after = HarnessParams.from_dict(rollback_data)
    write_harness_params(after)
    for memory in USER_MEMORIES.values():
        apply_harness_to_memory(memory, after)
    append_manifest_entry(
        build_manifest_entry(
            component="rollback",
            previous_value=f"manifest_index:{manifest_index}",
            new_value="config_before",
            reason="Manual dashboard rollback to an earlier harness snapshot.",
            predicted_impact="Restores the selected previous configuration exactly.",
            config_before=before,
            config_after=after,
            actor="dashboard",
            status="rollback",
        )
    )
    return RedirectResponse(url=f"/?user_id={user_id}&topic_id={topic_id}#harness", status_code=303)


@app.post("/harness/quick-eval")
def quick_eval_harness(user_id: str = Form("demo-user"), topic_id: str = Form("profile")):
    validate_harnesses()
    return RedirectResponse(url=f"/?user_id={user_id}&topic_id={topic_id}#harness", status_code=303)


@app.get("/harness/export", response_class=PlainTextResponse)
def export_harness_report() -> str:
    for candidate in [
        ROOT_DIR / "reports" / "evolution_report.md",
        ROOT_DIR / "results" / "harness_evolution_summary.md",
        ROOT_DIR / "results" / "harness_evolution_validation.md",
    ]:
        if candidate.exists():
            return candidate.read_text(encoding="utf-8")
    return "No harness report has been generated yet."


@app.websocket("/ws/{user_id}")
async def chat_socket(websocket: WebSocket, user_id: str):
    await websocket.accept()
    try:
        while True:
            payload = await websocket.receive_text()
            request = json.loads(payload)
            message = str(request.get("message", ""))
            topic_id = str(request.get("topic_id", "profile"))
            _demo_touch(user_id)
            memory = get_memory(user_id)
            memory.topic_id = topic_id
            identity = _identity_for(user_id)
            identity.observe_user_input(message)

            context = memory.get_context(message, session_id=user_id, topic_id=topic_id)
            facts = memory.extract_facts("", user_input=message)
            for fact in facts:
                memory.add_fact(fact, session_id=user_id, topic_id=topic_id)
            memory.add_to_history("User: " + message, "user_input")

            visible_context = context
            if not visible_context and facts:
                visible_context = memory.get_context(
                    "What do you remember about me?",
                    session_id=user_id,
                    topic_id=topic_id,
                )
            graph_facts = _graph_facts(memory, user_id, topic_id, message)
            response, generation = _generate_demo_response(
                memory,
                user_id,
                topic_id,
                message,
                context,
                facts,
                graph_facts,
            )
            identity_result = _identity_status(identity, response)
            identity.record_behavior(response)
            memory.add_to_history("Assistant: " + response[:200], "assistant_output")
            await websocket.send_json(
                {
                    "response": response,
                    "retrieved_context": visible_context,
                    "graph_facts": graph_facts,
                    "identity": identity_result,
                    "generation": generation,
                    "stored_facts": facts,
                    "facts": _facts(memory, user_id, topic_id),
                    "dashboard": _dashboard_payload(memory, user_id, topic_id),
                }
            )
    except WebSocketDisconnect:
        return


def _memory_response(context: str, facts: List[str], graph_facts: List[str]) -> str:
    if context:
        bullets = [line.strip(" *") for line in context.splitlines() if line.strip().startswith("*")]
        if bullets:
            return "I found relevant memory:\n" + "\n".join(f"- {item}" for item in bullets[:6])
        return "I found relevant memory for the configured model."
    if facts:
        return "Stored new facts. Ask a recall question or a distractor next."
    if graph_facts:
        return "I found related graph memory:\n" + "\n".join(f"- {item}" for item in graph_facts[:6])
    return "No prior relevant memory found yet. Try injecting a personal fact first."


def _generate_demo_response(
    memory: Any,
    user_id: str,
    topic_id: str,
    message: str,
    context: str,
    facts: List[str],
    graph_facts: List[str],
) -> tuple[str, Dict[str, Any]]:
    if not _live_gemma_enabled():
        return _memory_response(context, facts, graph_facts), {
            "mode": "memory",
            "model": None,
            "latency_ms": 0,
        }

    start = time.perf_counter()
    try:
        model, tokenizer, torch, GenerationConfig = _load_live_gemma()
        response = _generate_with_model(
            model,
            tokenizer,
            torch,
            GenerationConfig,
            _build_live_prompt(memory, user_id, topic_id, message),
            max_new_tokens=_demo_max_new_tokens(),
        )
        return response or _memory_response(context, facts, graph_facts), {
            "mode": "gemma4",
            "model": _demo_model_id(),
            "latency_ms": round((time.perf_counter() - start) * 1000, 1),
        }
    except Exception as exc:
        MODEL_STATE["error"] = f"{exc.__class__.__name__}: {exc}"
        return _memory_response(context, facts, graph_facts), {
            "mode": "gemma4-fallback",
            "model": _demo_model_id(),
            "latency_ms": round((time.perf_counter() - start) * 1000, 1),
            "error": MODEL_STATE["error"],
        }


def _build_live_prompt(memory: Any, user_id: str, topic_id: str, message: str) -> str:
    context = memory.get_context(message, session_id=user_id, topic_id=topic_id)
    instructions = (
        "You are Smriti AI running on a frozen Gemma 4 base model. "
        "Use retrieved memory when relevant, be concise, and do not invent private facts."
    )
    if context:
        return f"{instructions}\n\n{context}\n\nUser: {message}\nAssistant:"
    return f"{instructions}\n\nUser: {message}\nAssistant:"


def _load_live_gemma() -> tuple[Any, Any, Any, Any]:
    with MODEL_LOCK:
        if MODEL_STATE["loaded"]:
            return (
                MODEL_STATE["model"],
                MODEL_STATE["tokenizer"],
                MODEL_STATE["torch"],
                MODEL_STATE["GenerationConfig"],
            )
        MODEL_STATE["loading"] = True
        MODEL_STATE["error"] = None
        try:
            import torch
            from transformers import AutoModelForCausalLM, AutoTokenizer, GenerationConfig

            model_id = _demo_model_id()
            local_files_only = _bool_env("SMRITI_DEMO_LOCAL_FILES_ONLY", True)
            token = os.getenv("HF_TOKEN")
            kwargs: Dict[str, Any] = {"local_files_only": local_files_only}
            if token:
                kwargs["token"] = token
            device = "cuda" if torch.cuda.is_available() else "cpu"
            dtype = torch.float32
            if device == "cuda":
                dtype = torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16
            tokenizer = AutoTokenizer.from_pretrained(model_id, **kwargs)
            if tokenizer.pad_token_id is None:
                tokenizer.pad_token = tokenizer.eos_token
            try:
                model = AutoModelForCausalLM.from_pretrained(model_id, dtype=dtype, **kwargs)
            except TypeError:
                model = AutoModelForCausalLM.from_pretrained(model_id, torch_dtype=dtype, **kwargs)
            model.to(device)
            model.eval()
            MODEL_STATE.update(
                {
                    "model": model,
                    "tokenizer": tokenizer,
                    "torch": torch,
                    "GenerationConfig": GenerationConfig,
                    "loaded": True,
                    "loading": False,
                    "error": None,
                    "device": device,
                }
            )
            return model, tokenizer, torch, GenerationConfig
        except Exception as exc:
            MODEL_STATE["loading"] = False
            MODEL_STATE["error"] = f"{exc.__class__.__name__}: {exc}"
            raise


def _generate_with_model(
    model: Any,
    tokenizer: Any,
    torch: Any,
    GenerationConfig: Any,
    prompt: str,
    max_new_tokens: int,
) -> str:
    messages = [{"role": "user", "content": prompt}]
    try:
        formatted = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
    except Exception:
        formatted = prompt
    inputs = tokenizer(formatted, return_tensors="pt", truncation=True, max_length=2048)
    device = MODEL_STATE.get("device", "cpu")
    inputs = {key: value.to(device) for key, value in inputs.items()}
    cfg = GenerationConfig(
        max_new_tokens=max_new_tokens,
        temperature=float(os.getenv("SMRITI_DEMO_TEMPERATURE", "0.2")),
        top_p=float(os.getenv("SMRITI_DEMO_TOP_P", "0.9")),
        do_sample=_bool_env("SMRITI_DEMO_DO_SAMPLE", False),
        pad_token_id=getattr(tokenizer, "eos_token_id", None),
    )
    with torch.inference_mode():
        out = model.generate(**inputs, generation_config=cfg)
    return tokenizer.decode(
        out[0, inputs["input_ids"].shape[1] :].detach().cpu(),
        skip_special_tokens=True,
    ).strip()


def _facts(memory: Any, user_id: str, topic_id: str) -> List[Dict[str, Any]]:
    return [
        {"text": fact, "source": "semantic" if memory.retrieval_mode == "semantic" else "tf-idf"}
        for fact in memory.retrieve_facts("", k=20, session_id=user_id, topic_id=topic_id)
    ]


def _graph_facts(memory: Any, user_id: str, topic_id: str, query: str = "") -> List[str]:
    candidates = [query, "user", "me", "Alex", "Hawaii"]
    seen: set[str] = set()
    facts: List[str] = []
    for candidate in candidates:
        triples = memory.knowledge_graph.query_graph(
            user_id,
            candidate,
            depth=2,
            topic_id=topic_id,
        )
        for text in memory.knowledge_graph.triples_to_text(triples):
            if text not in seen:
                seen.add(text)
                facts.append(text)
    return facts[:8]


def _identity_for(user_id: str) -> IdentityFingerprint:
    if user_id not in USER_IDENTITIES:
        identity = IdentityFingerprint(
            role="optimistic memory assistant for product demos",
            threshold=0.35,
            embedding_model=_HashingEmbeddingModel(),
        )
        identity.set_constraints(
            [
                "Use remembered user facts only when relevant.",
                "Stay transparent about retrieved memory.",
                "Keep demo responses concise and encouraging.",
            ]
        )
        identity.initialize_persona(
            [
                "You are an optimistic memory assistant.",
                "You explain memory retrieval, graph facts, and privacy controls clearly.",
            ]
        )
        USER_IDENTITIES[user_id] = identity
    return USER_IDENTITIES[user_id]


def _identity_status(identity: IdentityFingerprint, response: str) -> Dict[str, Any]:
    check = identity.evaluate_output(response)
    return {
        "enabled": True,
        "drift_score": round(check.distance, 3),
        "threshold": round(check.threshold, 3),
        "refinement_triggered": bool(check.needs_refinement),
        "persona_evidence": identity.persona_evidence[-3:],
        "note": "Demo computes the GIFP check without running a slow second model pass.",
    }


def _dashboard_payload(memory: Any, user_id: str, topic_id: str) -> Dict[str, Any]:
    backend = _backend_status()
    live_model = _live_model_status()
    release = _release_status()
    readiness = _readiness_dashboard()
    comparison_rows = _benchmark_rows(ROOT_DIR / "benchmarks" / "results_comparison.csv")
    gemma_rows = _benchmark_rows(ROOT_DIR / "benchmarks" / "results_gemma_eval.csv")
    historical_rows = _benchmark_rows(ROOT_DIR / "benchmarks" / "results_historical_protocol.csv")
    major = _major_results(gemma_rows, historical_rows)
    return {
        "user_id": user_id,
        "topic_id": topic_id,
        "retrieval_mode": memory.retrieval_mode,
        "harness": _harness_dashboard(),
        "backend": backend,
        "release": release,
        "readiness": readiness,
        "live_model": live_model,
        "training_status": _training_status(),
        "feature_cards": _feature_cards(backend, live_model, release, readiness),
        "major_results": major,
        "benchmark_rows": comparison_rows,
        "hf_model_repo": HF_MODEL_REPO,
        "github_repo": GITHUB_REPO,
        "memory_count": len(_facts(memory, user_id, topic_id)),
        "graph_count": len(_graph_facts(memory, user_id, topic_id, "user")),
        "api_routes": ["/chat", "/memory/delete", "/graph/query", "/metrics", "/docs"],
        "demo_mode_note": _demo_mode_note(live_model),
        "public_demo": _public_demo_enabled(),
        "memory_ttl_seconds": _demo_ttl_seconds(),
    }


def _backend_status() -> Dict[str, Any]:
    backend = get_memory_backend()
    cipher = getattr(backend, "cipher", None)
    storage = getattr(backend, "root", None) or getattr(backend, "path", None) or getattr(backend, "url", None) or "external"
    return {
        "name": type(backend).__name__.replace("Backend", ""),
        "storage": str(storage),
        "encrypted": bool(getattr(cipher, "enabled", False)),
        "configured_by": os.getenv("SMRITI_MEMORY_BACKEND", "json"),
    }


def _release_status() -> Dict[str, Any]:
    return {
        "version": __version__,
        "git_commit": _git_commit(),
        "package": "smriti-memory-ai",
        "pypi_target": f"smriti-memory-ai=={__version__}",
        "github_release": f"{GITHUB_REPO}/releases/tag/v{__version__}",
        "wheel_asset": f"smriti_memory_ai-{__version__}-py3-none-any.whl",
        "sdist_asset": f"smriti_memory_ai-{__version__}.tar.gz",
        "pypi_status": os.getenv(
            "SMRITI_DEMO_PYPI_STATUS",
            "release-gated; publish through GitHub secret or trusted publishing",
        ),
        "note": "GitHub release artifacts are versioned; PyPI publish must use a non-exposed token or trusted publishing.",
    }


def _read_json_report(relative_path: str) -> Dict[str, Any]:
    path = ROOT_DIR / relative_path
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _git_commit() -> str:
    try:
        return subprocess.check_output(
            ["git", "-C", str(ROOT_DIR), "rev-parse", "--short", "HEAD"],
            text=True,
            stderr=subprocess.DEVNULL,
        ).strip()
    except Exception:
        return os.getenv("GIT_COMMIT", "unknown")


def _readiness_dashboard() -> Dict[str, Any]:
    production_break = _read_json_report("reports/production_break_test_report.json")
    gates = _read_json_report("results/production_gate_report.json")
    security = _read_json_report("reports/security_acceptance_report.json")
    operations = _read_json_report("reports/operations_readiness_report.json")
    file_audit = _read_json_report("reports/production_file_audit.json")
    result_claims = _read_json_report("reports/security_report_result_claims.json")

    gate_rows = gates.get("gates") or {}
    gate_total = len(gate_rows)
    gate_passed = sum(1 for row in gate_rows.values() if row.get("passed"))
    break_summary = production_break.get("summary") or {}
    audit_counts = file_audit.get("counts") or {}
    audit_sensitive = audit_counts.get("delete_candidate_sensitive", 0)
    audit_review = (
        audit_counts.get("archive_candidate", 0)
        + audit_counts.get("delete_candidate_requires_review", 0)
        + audit_counts.get("unknown_requires_review", 0)
    )
    result_claim_valid = result_claims.get("valid", True)
    cards = [
        {
            "title": "Production-break suite",
            "status": production_break.get("verdict", "missing"),
            "detail": (
                f"{break_summary.get('tests', 'unknown')} tests, "
                f"{break_summary.get('failures', 0)} failures, "
                f"{break_summary.get('errors', 0)} errors."
            ),
        },
        {
            "title": "Production gates",
            "status": "pass" if gates.get("passed") else "missing",
            "detail": f"{gate_passed}/{gate_total} gates passed for {gates.get('harness_id', 'unknown harness')}.",
        },
        {
            "title": "Security acceptance",
            "status": security.get("verdict", "missing"),
            "detail": "OWASP LLM/API risk mapping, auth/RBAC, redaction, delete, and harness security reports.",
        },
        {
            "title": "Operations readiness",
            "status": operations.get("verdict", "missing"),
            "detail": f"{operations.get('dashboard_count', 0)} Grafana dashboards plus runbooks, health checks, and support flow.",
        },
        {
            "title": "Production file audit",
            "status": file_audit.get("verdict", "missing"),
            "detail": f"{audit_sensitive} sensitive findings; {audit_review} review/archive candidates remain non-deleted.",
        },
        {
            "title": "Result provenance",
            "status": "valid" if result_claim_valid else "review",
            "detail": "Public claims reject fake, synthetic, or unverifiable benchmark rows.",
        },
    ]
    fail_closed = [
        "No fake/mock/tiny model fallback in production.",
        "No official benchmark claim from synthetic or deterministic smoke data.",
        "Production harness promotion requires manifest, privacy, security, latency, token, and holdout gates.",
        "Deletion, auth/RBAC, cross-user isolation, and secret redaction are hard-fail conditions.",
    ]
    return {
        "cards": cards,
        "production_break": production_break,
        "production_gates": gates,
        "security": security,
        "operations": operations,
        "file_audit": file_audit,
        "result_claims": result_claims,
        "fail_closed": fail_closed,
    }


def _feature_cards(
    backend: Dict[str, Any],
    live_model: Dict[str, Any],
    release: Dict[str, Any],
    readiness: Dict[str, Any],
) -> List[Dict[str, str]]:
    encryption_state = "On" if backend["encrypted"] else "Ready"
    break_verdict = readiness["production_break"].get("verdict", "missing")
    gate_status = "Pass" if readiness["production_gates"].get("passed") else "Review"
    return [
        {
            "title": "Base model",
            "status": live_model["status"],
            "detail": f"{live_model['model']} ({live_model['mode']}).",
        },
        {"title": "Semantic retrieval", "status": "Live", "detail": "Session -> topic -> fact memory with embedding retrieval."},
        {"title": "Knowledge graph", "status": "Live", "detail": "Extracts user triples and shows related graph facts."},
        {"title": "Identity governance", "status": "Live", "detail": "GIFP drift scoring is computed for each demo response."},
        {"title": "Durable backends", "status": backend["name"], "detail": "JSON, SQLite, Redis, and Postgres are supported."},
        {"title": "Encrypted memory", "status": encryption_state, "detail": "Set SMRITI_MEMORY_KEY to encrypt backend blobs."},
        {"title": "Privacy deletion", "status": "Live", "detail": "Delete clears RAM, durable memory, and identity state for a user."},
        {"title": "Gemma 4 benchmarks", "status": "Loaded", "detail": "Dashboard reads current CSV artifacts, not CI smoke results."},
        {"title": "HF deployment", "status": "Uploaded", "detail": "Model-style handler is live on Hugging Face."},
        {"title": "API + monitoring", "status": "Ready", "detail": "FastAPI docs, metrics, Docker, and Grafana assets exist."},
        {"title": "AHE harness loop", "status": "Observable", "detail": "YAML params, evidence logs, and manifest-backed evolution are auditable."},
        {"title": "Production gates", "status": gate_status, "detail": "Manifest, privacy/delete, security, holdout, latency, and token gates are visible."},
        {"title": "Production-break tests", "status": break_verdict, "detail": "Malformed input, cross-user isolation, provider outage, prompt injection, and deployment breakers."},
        {"title": "Release package", "status": f"v{release['version']}", "detail": f"{release['pypi_target']} plus GitHub wheel/sdist artifacts."},
        {"title": "No fake claims", "status": "Guarded", "detail": "Test doubles stay CI-only and never count as production benchmark evidence."},
    ]


def _live_gemma_enabled() -> bool:
    mode = os.getenv("SMRITI_DEMO_MODEL_MODE", os.getenv("SMRITI_DEMO_MODE", "memory")).lower()
    return mode in {"gemma", "gemma4", "live", "model"}


def _demo_model_id() -> str:
    return (
        os.getenv("SMRITI_DEMO_BASE_MODEL_ID")
        or os.getenv("BASE_MODEL_ID")
        or "google/gemma-4-E2B-it"
    )


def _demo_max_new_tokens() -> int:
    try:
        return int(os.getenv("SMRITI_DEMO_MAX_NEW_TOKENS", "64"))
    except ValueError:
        return 64


def _live_model_status() -> Dict[str, Any]:
    enabled = _live_gemma_enabled()
    if not enabled:
        status = "Memory-only"
    elif MODEL_STATE["loaded"]:
        status = "Gemma 4 live"
    elif MODEL_STATE["loading"]:
        status = "Loading"
    elif MODEL_STATE["error"]:
        status = "Gemma 4 error"
    else:
        status = "Gemma 4 configured"
    return {
        "enabled": enabled,
        "loaded": bool(MODEL_STATE["loaded"]),
        "loading": bool(MODEL_STATE["loading"]),
        "status": status,
        "mode": "live Gemma 4" if enabled else "fast memory-only dashboard",
        "model": _demo_model_id() if enabled else "none loaded",
        "device": MODEL_STATE.get("device", "not loaded"),
        "max_new_tokens": _demo_max_new_tokens(),
        "error": MODEL_STATE.get("error"),
    }


def _training_status() -> Dict[str, str]:
    return {
        "status": "not fine-tuned",
        "detail": (
            "Smriti AI is an inference-time wrapper. Gemma 4 stays frozen; "
            "memory improves recall through retrieval and prompt augmentation."
        ),
    }


def _demo_mode_note(live_model: Dict[str, Any]) -> str:
    privacy_note = ""
    if _public_demo_enabled():
        privacy_note = (
            f" Public demo mode is on: do not enter PII; demo memory auto-deletes "
            f"after {_demo_ttl_seconds()} seconds of inactivity."
        )
    if live_model["enabled"]:
        return (
            "Live Gemma 4 mode is enabled. First response may be slow while the cached model loads; "
            "no fine-tuning is performed."
            + privacy_note
        )
    return (
        "Live dashboard is memory-only for speed; Gemma 4 quality claims come from saved benchmark CSVs."
        + privacy_note
    )


def _public_demo_enabled() -> bool:
    return _bool_env("SMRITI_PUBLIC_DEMO", False)


def _demo_ttl_seconds() -> int:
    try:
        return max(30, int(os.getenv("SMRITI_DEMO_MEMORY_TTL_SECONDS", "900")))
    except ValueError:
        return 900


def _demo_touch(user_id: str) -> None:
    """Track demo activity and age out public-demo memory between requests."""

    if not _public_demo_enabled():
        return
    now = time.time()
    with DEMO_STATE_LOCK:
        _demo_cleanup_expired(now)
        DEMO_LAST_SEEN[user_id] = now


def _demo_cleanup_expired(now: float | None = None) -> None:
    if not _public_demo_enabled():
        return
    timestamp = now if now is not None else time.time()
    ttl = _demo_ttl_seconds()
    expired = [
        user_id
        for user_id, last_seen in DEMO_LAST_SEEN.items()
        if timestamp - last_seen > ttl
    ]
    for user_id in expired:
        _delete_user_memory(user_id)


def _delete_user_memory(user_id: str) -> None:
    with DEMO_STATE_LOCK:
        USER_MEMORIES.pop(user_id, None)
        USER_IDENTITIES.pop(user_id, None)
        DEMO_LAST_SEEN.pop(user_id, None)
        get_memory_backend().delete_user(user_id)


def _harness_dashboard() -> Dict[str, Any]:
    params = load_harness_params()
    rows = load_manifest()
    formatted = format_manifest_rows(rows)
    validation_rows = _benchmark_rows(ROOT_DIR / "results" / "harness_evolution_validation.csv")
    cross_rows = _benchmark_rows(ROOT_DIR / "results" / "cross_model_harness_eval.csv")
    return {
        "active_harness": os.getenv("SMRITI_HARNESS_ID", "config"),
        "params": params.to_dict(),
        "config_path": str(resolve_harness_config_path()),
        "manifest_path": str(manifest_path()),
        "manifest": formatted[-10:],
        "manifest_count": len(rows),
        "registry": list_harnesses(),
        "validation_rows": validation_rows,
        "cross_rows": cross_rows,
    }


def _harness_change_summary(before: HarnessParams, after: HarnessParams) -> Dict[str, Any]:
    before_data = before.to_dict()
    after_data = after.to_dict()
    for key in before_data:
        if key == "evolution":
            continue
        if before_data[key] != after_data[key]:
            return {
                "component": key,
                "previous_value": before_data[key],
                "new_value": after_data[key],
            }
    return {"component": "none", "previous_value": "", "new_value": ""}


def _bool_env(name: str, default: bool = False) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.lower() in {"1", "true", "yes", "on"}


def _benchmark_rows(path: Path) -> List[Dict[str, str]]:
    if not path.exists():
        return []
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def _major_results(gemma_rows: List[Dict[str, str]], historical_rows: List[Dict[str, str]]) -> Dict[str, str]:
    baseline = next((row for row in gemma_rows if row.get("system") == "baseline"), {})
    smriti = next((row for row in gemma_rows if row.get("system") == "smriti"), {})
    historical = next((row for row in historical_rows if row.get("metric") == "overall_average"), {})
    return {
        "baseline_recall": _facts_label(baseline),
        "smriti_recall": _facts_label(smriti),
        "recall_lift": "+3 facts" if smriti.get("facts_recalled") == "3" else "See CSV",
        "broader_delta": _percent_label(historical.get("delta_percent", "")),
        "model": smriti.get("model") or baseline.get("model") or "google/gemma-4-E2B-it",
        "latency": _latency_label(smriti),
        "historical_note": "Old +31.2% is lineage only; current broader-protocol rerun is separate.",
    }


def _facts_label(row: Dict[str, str]) -> str:
    if not row:
        return "See CSV"
    return f"{row.get('facts_recalled', '?')}/3"


def _latency_label(row: Dict[str, str]) -> str:
    try:
        return f"{float(row.get('average_latency_s', 0.0)) * 1000:.0f} ms"
    except (TypeError, ValueError):
        return "See CSV"


def _percent_label(value: str) -> str:
    if not value:
        return "See CSV"
    return value if value.endswith("%") else f"{value}%"


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "demo.app:app",
        host=os.getenv("SMRITI_DEMO_HOST", "127.0.0.1"),
        port=int(os.getenv("SMRITI_DEMO_PORT", "8080")),
    )
