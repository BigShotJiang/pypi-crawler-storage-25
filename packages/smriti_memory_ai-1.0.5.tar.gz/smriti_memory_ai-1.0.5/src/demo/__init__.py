"""Small web demo for Smriti AI memory interactions."""
