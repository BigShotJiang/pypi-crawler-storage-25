"""Authenticated memory audit dashboard for Smriti AI demos."""

from __future__ import annotations

import os
import secrets
from pathlib import Path

from fastapi import Depends, FastAPI, Form, HTTPException, Request, status
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from fastapi.templating import Jinja2Templates

from smriti import __version__
from smriti.audit import MemoryAuditService
from smriti.backends import build_backend

ROOT = Path(__file__).resolve().parent
templates = Jinja2Templates(directory=str(ROOT / "templates"))
security = HTTPBasic()
app = FastAPI(title="Smriti AI Memory Audit", version=__version__)


def require_basic_auth(credentials: HTTPBasicCredentials = Depends(security)) -> str:
    """Protect the audit dashboard with HTTP Basic credentials."""

    expected_user = os.getenv("SMRITI_AUDIT_USER", "admin")
    expected_password = os.getenv("SMRITI_AUDIT_PASSWORD", "smriti-local")
    username_ok = secrets.compare_digest(credentials.username, expected_user)
    password_ok = secrets.compare_digest(credentials.password, expected_password)
    if not (username_ok and password_ok):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid audit credentials.",
            headers={"WWW-Authenticate": "Basic"},
        )
    return credentials.username


def audit_service() -> MemoryAuditService:
    return MemoryAuditService(build_backend())


@app.get("/", response_class=HTMLResponse)
def index(
    request: Request,
    user_id: str = "demo-user",
    topic_id: str = "general",
    query: str = "",
    include_archived: bool = False,
    _: str = Depends(require_basic_auth),
) -> HTMLResponse:
    entries = audit_service().list_entries(
        user_id=user_id,
        topic_id=topic_id or None,
        query=query,
        include_archived=include_archived,
        limit=250,
    )
    return templates.TemplateResponse(
        "audit.html",
        {
            "request": request,
            "user_id": user_id,
            "topic_id": topic_id,
            "query": query,
            "include_archived": include_archived,
            "entries": [entry.to_dict() for entry in entries],
            "backend": type(build_backend()).__name__,
        },
    )


@app.post("/action")
def action(
    user_id: str = Form(...),
    topic_id: str = Form("general"),
    entry_id: str = Form(...),
    action_name: str = Form(...),
    _: str = Depends(require_basic_auth),
) -> RedirectResponse:
    service = audit_service()
    if action_name == "pin":
        service.pin_entry(user_id, entry_id, True)
    elif action_name == "unpin":
        service.pin_entry(user_id, entry_id, False)
    elif action_name == "archive":
        service.archive_entry(user_id, entry_id, True)
    elif action_name == "unarchive":
        service.archive_entry(user_id, entry_id, False)
    elif action_name == "delete":
        service.delete_entry(user_id, entry_id)
    else:
        raise HTTPException(status_code=400, detail="Unknown audit action.")
    return RedirectResponse(url=f"/?user_id={user_id}&topic_id={topic_id}", status_code=303)


@app.post("/update")
def update(
    user_id: str = Form(...),
    topic_id: str = Form("general"),
    entry_id: str = Form(...),
    text: str = Form(...),
    _: str = Depends(require_basic_auth),
) -> RedirectResponse:
    audit_service().update_entry(user_id, entry_id, text=text)
    return RedirectResponse(url=f"/?user_id={user_id}&topic_id={topic_id}", status_code=303)
