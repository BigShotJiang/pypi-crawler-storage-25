"""Compatibility wrapper for :mod:`smriti.cli`."""

from smriti.cli import *  # noqa: F401,F403
