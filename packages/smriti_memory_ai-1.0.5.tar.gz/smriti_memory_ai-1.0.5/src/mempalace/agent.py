"""Compatibility wrapper for :mod:`smriti.agent`."""

from smriti.agent import *  # noqa: F401,F403
