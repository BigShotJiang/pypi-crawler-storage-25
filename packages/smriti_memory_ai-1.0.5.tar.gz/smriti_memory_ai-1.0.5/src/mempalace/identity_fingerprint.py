"""Compatibility wrapper for :mod:`smriti.identity_fingerprint`."""

from smriti.identity_fingerprint import *  # noqa: F401,F403
