"""Backward-compatible imports for the renamed :mod:`smriti` package."""

from smriti import *  # noqa: F401,F403
