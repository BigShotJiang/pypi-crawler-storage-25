"""Compatibility wrapper for :mod:`smriti.gifp`."""

from smriti.gifp import *  # noqa: F401,F403
