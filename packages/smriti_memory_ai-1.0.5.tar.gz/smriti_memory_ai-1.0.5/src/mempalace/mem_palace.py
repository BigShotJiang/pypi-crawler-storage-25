"""Compatibility wrapper for :mod:`smriti.mem_palace`."""

from smriti.mem_palace import *  # noqa: F401,F403
