"""Compatibility wrapper for :mod:`smriti.core`."""

from smriti.core import *  # noqa: F401,F403
