"""Compatibility wrapper for :mod:`smriti.api`."""

from smriti.api import *  # noqa: F401,F403
