"""Compatibility wrapper for :mod:`smriti.knowledge_graph`."""

from smriti.knowledge_graph import *  # noqa: F401,F403
