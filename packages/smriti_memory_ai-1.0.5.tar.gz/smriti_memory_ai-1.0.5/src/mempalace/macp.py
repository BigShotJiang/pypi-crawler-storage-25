"""Compatibility wrapper for :mod:`smriti.macp`."""

from smriti.macp import *  # noqa: F401,F403
