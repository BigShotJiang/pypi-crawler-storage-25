"""Compatibility wrapper for :mod:`smriti.semantic_memory`."""

from smriti.semantic_memory import *  # noqa: F401,F403
