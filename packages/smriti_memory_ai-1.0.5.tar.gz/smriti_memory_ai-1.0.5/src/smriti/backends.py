"""Durable memory backends for Smriti AI.

Backends persist complete user memory blobs and also expose a minimal entry API
for tools that want to store/retrieve lightweight facts without instantiating the
full runtime. Optional encryption is applied at the blob boundary so JSON, SQL,
Redis, and Postgres stores share the same privacy behavior.
"""

from __future__ import annotations

import base64
import hashlib
import json
import os
import re
import sqlite3
import time
from abc import ABC, abstractmethod
from pathlib import Path
from threading import RLock
from typing import Any, Dict, List, Optional

from .migrations import load_schema_sql, migrate_sqlite_database
from .security.backend_security import chmod_private, ensure_not_symlink, safe_backend_root, safe_user_id
from .security.encryption import validate_encryption_policy
from .security.memory_sanitizer import tag_memory_metadata


class MemoryBackend(ABC):
    """Abstract persistence contract for user-isolated Smriti AI memory."""

    @abstractmethod
    def load(self, user_id: str) -> Optional[Dict[str, Any]]:
        """Load a complete memory state for one user, or None if absent."""

    @abstractmethod
    def save(self, user_id: str, memory: Dict[str, Any]) -> None:
        """Persist a complete memory state for one user."""

    @abstractmethod
    def add_entry(
        self,
        user_id: str,
        session_id: str,
        topic_id: str,
        text: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Persist one lightweight fact/entry for a user/session/topic."""

    @abstractmethod
    def retrieve(
        self,
        user_id: str,
        session_id: Optional[str] = None,
        topic_id: Optional[str] = None,
        query: str = "",
        k: int = 5,
    ) -> List[Dict[str, Any]]:
        """Retrieve lightweight entries scoped to a user/session/topic."""

    @abstractmethod
    def delete_user(self, user_id: str) -> bool:
        """Delete all memory owned by one user. Return whether anything existed."""


class MemoryCipher:
    """Optional symmetric encryption wrapper using Fernet when configured."""

    def __init__(self, secret: Optional[str] = None):
        self.secret = secret or os.getenv("SMRITI_MEMORY_KEY") or os.getenv("SMRITI_ENCRYPTION_KEY")
        self._fernet = None
        if self.secret:
            try:
                from cryptography.fernet import Fernet
            except Exception as exc:  # pragma: no cover - depends on optional install.
                raise RuntimeError(
                    "SMRITI_MEMORY_KEY is set, but cryptography is not installed. "
                    "Install smriti-memory-ai[security] or smriti-memory-ai[full]."
                ) from exc
            self._fernet = Fernet(_fernet_key(self.secret))

    @property
    def enabled(self) -> bool:
        return self._fernet is not None

    def wrap(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        if not self._fernet:
            return {"encrypted": False, "payload": payload}
        raw = json.dumps(payload, sort_keys=True).encode("utf-8")
        return {
            "encrypted": True,
            "algorithm": "fernet-sha256-derived-key",
            "payload": self._fernet.encrypt(raw).decode("utf-8"),
        }

    def unwrap(self, wrapper: Dict[str, Any]) -> Dict[str, Any]:
        if not wrapper.get("encrypted"):
            return dict(wrapper.get("payload", {}))
        if not self._fernet:
            raise RuntimeError("Memory blob is encrypted but SMRITI_MEMORY_KEY is not configured.")
        decrypted = self._fernet.decrypt(wrapper["payload"].encode("utf-8"))
        return json.loads(decrypted.decode("utf-8"))


def build_backend(kind: Optional[str] = None, **kwargs: Any) -> MemoryBackend:
    """Construct a backend from an explicit kind or SMRITI_MEMORY_BACKEND."""

    validate_encryption_policy()
    selected = (kind or os.getenv("SMRITI_MEMORY_BACKEND") or "json").lower()
    if selected == "json":
        return JsonBackend(root=kwargs.get("root") or os.getenv("SMRITI_MEMORY_DIR", "data/memory"))
    if selected == "sqlite":
        return SqliteBackend(path=kwargs.get("path") or os.getenv("SMRITI_SQLITE_PATH", "data/smriti_memory.sqlite3"))
    if selected == "redis":
        return RedisBackend(url=kwargs.get("url") or os.getenv("SMRITI_REDIS_URL") or os.getenv("REDIS_URL", "redis://localhost:6379/0"))
    if selected in {"postgres", "postgresql"}:
        return PostgresBackend(dsn=kwargs.get("dsn") or os.getenv("SMRITI_POSTGRES_DSN") or os.getenv("POSTGRES_DSN", ""))
    raise ValueError("SMRITI_MEMORY_BACKEND must be one of: json, sqlite, redis, postgres.")


class JsonBackend(MemoryBackend):
    """File-per-user JSON backend. This preserves the original local behavior."""

    def __init__(self, root: str | Path = "data/memory", cipher: Optional[MemoryCipher] = None):
        self.root = safe_backend_root(root)
        self.cipher = cipher or MemoryCipher()
        self._lock = RLock()

    def load(self, user_id: str) -> Optional[Dict[str, Any]]:
        with self._lock:
            path = self._path(user_id)
            if not path.exists():
                return None
            return self.cipher.unwrap(json.loads(path.read_text(encoding="utf-8")))

    def save(self, user_id: str, memory: Dict[str, Any]) -> None:
        with self._lock:
            self.root.mkdir(parents=True, exist_ok=True)
            path = self._path(user_id)
            ensure_not_symlink(path)
            tmp_path = path.with_suffix(path.suffix + ".tmp")
            tmp_path.write_text(
                json.dumps(self.cipher.wrap(memory), indent=2),
                encoding="utf-8",
            )
            chmod_private(tmp_path)
            tmp_path.replace(path)
            chmod_private(path)

    def add_entry(
        self,
        user_id: str,
        session_id: str,
        topic_id: str,
        text: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        with self._lock:
            state = self.load(user_id) or {"backend_entries": []}
            state.setdefault("backend_entries", []).append(_entry(session_id, topic_id, text, metadata))
            self.save(user_id, state)

    def retrieve(
        self,
        user_id: str,
        session_id: Optional[str] = None,
        topic_id: Optional[str] = None,
        query: str = "",
        k: int = 5,
    ) -> List[Dict[str, Any]]:
        with self._lock:
            state = self.load(user_id) or {}
            return _rank_entries(state.get("backend_entries", []), session_id, topic_id, query, k)

    def delete_user(self, user_id: str) -> bool:
        with self._lock:
            path = self._path(user_id)
            existed = path.exists()
            if existed:
                path.unlink()
            return existed

    def _path(self, user_id: str) -> Path:
        return self.root / f"{_safe_id(user_id)}.json"


class SqliteBackend(MemoryBackend):
    """SQLite backend for local durable multi-user memory."""

    def __init__(self, path: str | Path = "data/smriti_memory.sqlite3", cipher: Optional[MemoryCipher] = None):
        self.path = safe_backend_root(path)
        self.cipher = cipher or MemoryCipher()
        self._init_schema()

    def load(self, user_id: str) -> Optional[Dict[str, Any]]:
        with self._connect() as conn:
            row = conn.execute("SELECT payload FROM user_memory WHERE user_id = ?", (user_id,)).fetchone()
        if not row:
            return None
        return self.cipher.unwrap(json.loads(row[0]))

    def save(self, user_id: str, memory: Dict[str, Any]) -> None:
        payload = json.dumps(self.cipher.wrap(memory))
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO user_memory(user_id, payload, updated_at)
                VALUES(?, ?, ?)
                ON CONFLICT(user_id) DO UPDATE SET payload=excluded.payload, updated_at=excluded.updated_at
                """,
                (user_id, payload, time.time()),
            )

    def add_entry(
        self,
        user_id: str,
        session_id: str,
        topic_id: str,
        text: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO memory_entries(user_id, session_id, topic_id, text, metadata, created_at)
                VALUES(?, ?, ?, ?, ?, ?)
                """,
                (user_id, session_id, topic_id, text, json.dumps(metadata or {}), time.time()),
            )

    def retrieve(
        self,
        user_id: str,
        session_id: Optional[str] = None,
        topic_id: Optional[str] = None,
        query: str = "",
        k: int = 5,
    ) -> List[Dict[str, Any]]:
        clauses = ["user_id = ?"]
        params: List[Any] = [user_id]
        if session_id:
            clauses.append("session_id = ?")
            params.append(session_id)
        if topic_id:
            clauses.append("topic_id = ?")
            params.append(topic_id)
        params.append(max(1, k * 5))
        sql = f"""
            SELECT session_id, topic_id, text, metadata, created_at
            FROM memory_entries
            WHERE {' AND '.join(clauses)}
            ORDER BY created_at DESC
            LIMIT ?
        """
        with self._connect() as conn:
            rows = conn.execute(sql, params).fetchall()
        entries = [
            {
                "session_id": row[0],
                "topic_id": row[1],
                "text": row[2],
                "metadata": json.loads(row[3] or "{}"),
                "created_at": row[4],
            }
            for row in rows
        ]
        return _rank_entries(entries, session_id, topic_id, query, k)

    def delete_user(self, user_id: str) -> bool:
        with self._connect() as conn:
            before = conn.total_changes
            conn.execute("DELETE FROM user_memory WHERE user_id = ?", (user_id,))
            conn.execute("DELETE FROM memory_entries WHERE user_id = ?", (user_id,))
            return conn.total_changes > before

    def _connect(self) -> sqlite3.Connection:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        return sqlite3.connect(self.path)

    def _init_schema(self) -> None:
        migrate_sqlite_database(self.path)


class RedisBackend(MemoryBackend):  # pragma: no cover - requires external Redis service.
    """Redis backend using string payloads and per-user entry lists."""

    def __init__(self, url: str = "redis://localhost:6379/0", cipher: Optional[MemoryCipher] = None):
        try:
            import redis
        except Exception as exc:  # pragma: no cover - optional dependency.
            raise RuntimeError("Install redis to use RedisBackend: pip install smriti-memory-ai[backends]") from exc
        self.client = redis.Redis.from_url(url, decode_responses=True)
        self.cipher = cipher or MemoryCipher()

    def load(self, user_id: str) -> Optional[Dict[str, Any]]:
        raw = self.client.get(self._payload_key(user_id))
        if not raw:
            return None
        return self.cipher.unwrap(json.loads(raw))

    def save(self, user_id: str, memory: Dict[str, Any]) -> None:
        self.client.set(self._payload_key(user_id), json.dumps(self.cipher.wrap(memory)))

    def add_entry(self, user_id: str, session_id: str, topic_id: str, text: str, metadata: Optional[Dict[str, Any]] = None) -> None:
        self.client.lpush(self._entries_key(user_id), json.dumps(_entry(session_id, topic_id, text, metadata)))

    def retrieve(self, user_id: str, session_id: Optional[str] = None, topic_id: Optional[str] = None, query: str = "", k: int = 5) -> List[Dict[str, Any]]:
        raw_entries = self.client.lrange(self._entries_key(user_id), 0, max(0, k * 5 - 1))
        entries = [json.loads(item) for item in raw_entries]
        return _rank_entries(entries, session_id, topic_id, query, k)

    def delete_user(self, user_id: str) -> bool:
        return bool(self.client.delete(self._payload_key(user_id), self._entries_key(user_id)))

    def _payload_key(self, user_id: str) -> str:
        return f"smriti:user:{_safe_id(user_id)}:payload"

    def _entries_key(self, user_id: str) -> str:
        return f"smriti:user:{_safe_id(user_id)}:entries"


class PostgresBackend(MemoryBackend):  # pragma: no cover - requires external Postgres service.
    """Postgres backend using psycopg2 and indexed user/session/topic tables."""

    def __init__(self, dsn: str, cipher: Optional[MemoryCipher] = None):
        if not dsn:
            raise ValueError("SMRITI_POSTGRES_DSN is required for PostgresBackend.")
        try:
            import psycopg2
        except Exception as exc:  # pragma: no cover - optional dependency.
            raise RuntimeError("Install psycopg2-binary to use PostgresBackend: pip install smriti-memory-ai[backends]") from exc
        self._psycopg2 = psycopg2
        self.dsn = dsn
        self.cipher = cipher or MemoryCipher()
        self._init_schema()

    def load(self, user_id: str) -> Optional[Dict[str, Any]]:
        with self._connect() as conn, conn.cursor() as cur:
            cur.execute("SELECT payload FROM user_memory WHERE user_id = %s", (user_id,))
            row = cur.fetchone()
        if not row:
            return None
        return self.cipher.unwrap(row[0] if isinstance(row[0], dict) else json.loads(row[0]))

    def save(self, user_id: str, memory: Dict[str, Any]) -> None:
        payload = json.dumps(self.cipher.wrap(memory))
        with self._connect() as conn, conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO user_memory(user_id, payload, updated_at)
                VALUES(%s, %s::jsonb, NOW())
                ON CONFLICT(user_id) DO UPDATE SET payload=excluded.payload, updated_at=excluded.updated_at
                """,
                (user_id, payload),
            )

    def add_entry(self, user_id: str, session_id: str, topic_id: str, text: str, metadata: Optional[Dict[str, Any]] = None) -> None:
        with self._connect() as conn, conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO memory_entries(user_id, session_id, topic_id, text, metadata)
                VALUES(%s, %s, %s, %s, %s::jsonb)
                """,
                (user_id, session_id, topic_id, text, json.dumps(metadata or {})),
            )

    def retrieve(self, user_id: str, session_id: Optional[str] = None, topic_id: Optional[str] = None, query: str = "", k: int = 5) -> List[Dict[str, Any]]:
        clauses = ["user_id = %s"]
        params: List[Any] = [user_id]
        if session_id:
            clauses.append("session_id = %s")
            params.append(session_id)
        if topic_id:
            clauses.append("topic_id = %s")
            params.append(topic_id)
        params.append(max(1, k * 5))
        sql = f"""
            SELECT session_id, topic_id, text, metadata, EXTRACT(EPOCH FROM created_at)
            FROM memory_entries
            WHERE {' AND '.join(clauses)}
            ORDER BY created_at DESC
            LIMIT %s
        """
        with self._connect() as conn, conn.cursor() as cur:
            cur.execute(sql, params)
            rows = cur.fetchall()
        entries = [
            {
                "session_id": row[0],
                "topic_id": row[1],
                "text": row[2],
                "metadata": row[3] or {},
                "created_at": float(row[4]),
            }
            for row in rows
        ]
        return _rank_entries(entries, session_id, topic_id, query, k)

    def delete_user(self, user_id: str) -> bool:
        with self._connect() as conn, conn.cursor() as cur:
            cur.execute("DELETE FROM user_memory WHERE user_id = %s", (user_id,))
            memory_deleted = cur.rowcount
            cur.execute("DELETE FROM memory_entries WHERE user_id = %s", (user_id,))
            entries_deleted = cur.rowcount
        return bool(memory_deleted or entries_deleted)

    def _connect(self):
        return self._psycopg2.connect(self.dsn)

    def _init_schema(self) -> None:
        with self._connect() as conn, conn.cursor() as cur:
            cur.execute(load_schema_sql("postgres_schema_v1.sql"))
            cur.execute(load_schema_sql("postgres_schema_v2.sql"))


def _fernet_key(secret: str) -> bytes:
    raw = secret.encode("utf-8")
    try:
        base64.urlsafe_b64decode(raw)
        if len(raw) == 44:
            return raw
    except Exception:
        pass
    return base64.urlsafe_b64encode(hashlib.sha256(raw).digest())


def _safe_id(value: str) -> str:
    return re.sub(r"[^a-zA-Z0-9_.@:-]+", "_", safe_user_id(value).strip()) or "default"


def _entry(session_id: str, topic_id: str, text: str, metadata: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    return {
        "session_id": session_id,
        "topic_id": topic_id,
        "text": text,
        "metadata": tag_memory_metadata(text, metadata),
        "created_at": time.time(),
    }


def _rank_entries(
    entries: List[Dict[str, Any]],
    session_id: Optional[str],
    topic_id: Optional[str],
    query: str,
    k: int,
) -> List[Dict[str, Any]]:
    scoped = [
        entry
        for entry in entries
        if (not session_id or entry.get("session_id") == session_id)
        and (not topic_id or entry.get("topic_id") == topic_id)
        and not (entry.get("metadata") or {}).get("deleted")
        and not (entry.get("metadata") or {}).get("archived")
        and not (entry.get("metadata") or {}).get("quarantined")
    ]
    if not query.strip():
        return sorted(scoped, key=lambda item: item.get("created_at", 0), reverse=True)[:k]
    q_terms = set(re.findall(r"[a-z0-9']+", query.lower()))
    scored = []
    for entry in scoped:
        terms = set(re.findall(r"[a-z0-9']+", entry.get("text", "").lower()))
        overlap = len(q_terms & terms) / max(1, len(q_terms | terms))
        recency = entry.get("created_at", 0)
        scored.append((overlap, recency, entry))
    scored.sort(key=lambda item: (item[0], item[1]), reverse=True)
    return [entry for _, _, entry in scored[:k]]
