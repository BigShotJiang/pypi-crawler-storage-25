"""Backend conformance checks for Smriti AI memory stores.

The checks in this module are intentionally small and deterministic. They give
backend authors a reusable contract for the behaviors Smriti AI depends on:
user isolation, session/topic scoping, payload save/load, entry retrieval,
metadata preservation, and deletion.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List
from uuid import uuid4

from .backends import MemoryBackend


class BackendConformanceError(AssertionError):
    """Raised when a memory backend violates the Smriti backend contract."""


@dataclass
class BackendConformanceResult:
    """Result returned by :func:`run_backend_conformance`."""

    backend_name: str
    user_prefix: str
    checked: List[str] = field(default_factory=list)
    deleted_users: List[str] = field(default_factory=list)

    @property
    def passed(self) -> bool:
        """Whether the conformance suite completed successfully."""

        return True

    def to_dict(self) -> dict:
        """Return a JSON-serialisable result for CLIs and reports."""

        return {
            "backend_name": self.backend_name,
            "user_prefix": self.user_prefix,
            "passed": self.passed,
            "checked": list(self.checked),
            "deleted_users": list(self.deleted_users),
        }


def run_backend_conformance(
    backend: MemoryBackend,
    user_prefix: str = "smriti-conformance",
    cleanup: bool = True,
) -> BackendConformanceResult:
    """Validate the common Smriti AI backend contract.

    Parameters
    ----------
    backend:
        Backend instance to check.
    user_prefix:
        Prefix for temporary user IDs. A unique suffix is always added.
    cleanup:
        Delete temporary users at the end of the check.

    Raises
    ------
    BackendConformanceError
        If the backend fails a required behavior.
    """

    suffix = uuid4().hex[:10]
    alice = f"{user_prefix}-alice-{suffix}"
    bob = f"{user_prefix}-bob-{suffix}"
    result = BackendConformanceResult(
        backend_name=backend.__class__.__name__,
        user_prefix=user_prefix,
    )

    try:
        _expect(backend.load(alice) is None, "missing user should load as None")
        result.checked.append("missing_load")

        backend.save(
            alice,
            {
                "version": 2,
                "session_id": alice,
                "topic_id": "profile",
                "key_facts": [{"content": "Alice works at Ocean Lab."}],
            },
        )
        loaded = backend.load(alice)
        _expect(isinstance(loaded, dict), "saved payload should load as a dict")
        _expect(loaded.get("session_id") == alice, "payload should preserve session_id")
        result.checked.append("payload_roundtrip")

        backend.save(alice, {"version": 2, "session_id": alice, "updated": True})
        loaded = backend.load(alice)
        _expect(loaded.get("updated") is True, "save should overwrite payload for same user")
        result.checked.append("payload_overwrite")

        backend.add_entry(
            alice,
            alice,
            "profile",
            "Alice works at Ocean Lab.",
            metadata={"source": "conformance", "kind": "profile"},
        )
        backend.add_entry(
            alice,
            alice,
            "hobbies",
            "Alice prefers green tea.",
            metadata={"source": "conformance", "kind": "hobby"},
        )
        backend.add_entry(
            bob,
            bob,
            "profile",
            "Bob builds robotics systems.",
            metadata={"source": "conformance", "kind": "profile"},
        )
        result.checked.append("entry_write")

        alice_hits = backend.retrieve(
            alice,
            session_id=alice,
            topic_id="profile",
            query="Ocean Lab",
            k=5,
        )
        _expect(alice_hits, "profile retrieval should return at least one hit")
        _expect(
            alice_hits[0]["text"] == "Alice works at Ocean Lab.",
            "profile retrieval should return the scoped Alice fact first",
        )
        _expect(
            alice_hits[0].get("metadata", {}).get("source") == "conformance",
            "retrieval should preserve entry metadata",
        )
        result.checked.append("retrieval_scoped_to_topic")

        hobby_hits = backend.retrieve(
            alice,
            session_id=alice,
            topic_id="hobbies",
            query="Ocean Lab",
            k=5,
        )
        _expect(
            all("Ocean Lab" not in hit["text"] for hit in hobby_hits),
            "topic filter should exclude profile facts",
        )
        result.checked.append("topic_isolation")

        bob_hits = backend.retrieve(bob, session_id=bob, query="Ocean Lab", k=5)
        _expect(
            all("Alice" not in hit["text"] for hit in bob_hits),
            "user filter should exclude another user's facts",
        )
        result.checked.append("user_isolation")

        _expect(backend.delete_user(alice), "delete_user should return true for Alice")
        result.deleted_users.append(alice)
        _expect(backend.load(alice) is None, "deleted payload should not load")
        _expect(
            backend.retrieve(alice, session_id=alice, query="Alice", k=5) == [],
            "deleted entries should not retrieve",
        )
        result.checked.append("delete_user")

        _expect(backend.delete_user(bob), "delete_user should return true for Bob")
        result.deleted_users.append(bob)
        result.checked.append("delete_second_user")
    except Exception:
        if cleanup:
            _cleanup(backend, alice, bob, result)
        raise

    if cleanup:
        _cleanup(backend, alice, bob, result)
    return result


def _cleanup(
    backend: MemoryBackend,
    alice: str,
    bob: str,
    result: BackendConformanceResult,
) -> None:
    for user_id in (alice, bob):
        try:
            if backend.delete_user(user_id) and user_id not in result.deleted_users:
                result.deleted_users.append(user_id)
        except Exception:
            # Cleanup should not mask the original conformance failure.
            pass


def _expect(condition: bool, message: str) -> None:
    if not condition:
        raise BackendConformanceError(message)
