"""Production promotion gates for Smriti AI harnesses."""

from __future__ import annotations

import json
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Dict

from .backend_conformance import run_backend_conformance
from .backends import JsonBackend
from .cross_model_validation import run_cross_model_eval
from .harness_registry import promote_harness
from .harness_validation import validate_harnesses
from .manifest_verifier import verify_manifest
from .security import contains_secret, redact_secret


def run_production_gates(
    harness_id: str,
    *,
    target_status: str = "production",
    run_tests: bool = True,
    report_path: str | Path = "results/production_gate_report.md",
    json_report_path: str | Path = "results/production_gate_report.json",
) -> Dict[str, Any]:
    """Run promotion gates and mark a harness production only if all pass."""

    gates: Dict[str, Dict[str, Any]] = {}
    gates["unit_tests"] = _command_gate([sys.executable, "-m", "pytest", "tests", "-q"]) if run_tests else _skipped()
    gates["backend_conformance"] = _backend_gate()
    validation = validate_harnesses(
        seed_config="harnesses/seed/harness_params.yaml",
        evolved_config=f"harnesses/{harness_id}/harness_params.yaml",
    )
    gates["validation_benchmark"] = {"passed": validation["conclusion"]["production_ready"], "details": validation["conclusion"]}
    gates["heldout_benchmark"] = _holdout_gate(harness_id)
    manifest = verify_manifest()
    gates["manifest_verification"] = {"passed": manifest["valid"], "details": manifest}
    cross = run_cross_model_eval(evolved_config=f"harnesses/{harness_id}/harness_params.yaml")
    gates["cross_model"] = {"passed": not cross["regressed_models"], "details": {k: v for k, v in cross.items() if k != "rows"}}
    gates["privacy_delete"] = {"passed": validation["rows"][-1]["privacy_delete_passed"], "details": {}}
    gates["latency"] = {"passed": "p95_latency_regressed" not in validation["conclusion"]["failures"], "details": validation["conclusion"]}
    gates["token_overhead"] = {"passed": "token_overhead_regressed" not in validation["conclusion"]["failures"], "details": validation["conclusion"]}
    gates["identity"] = {"passed": "identity_false_positives_regressed" not in validation["conclusion"]["failures"], "details": validation["conclusion"]}
    gates["security_scan"] = _security_scan_gate()
    gates["no_secret_leaks"] = _no_secret_gate()
    gates["load_test_summary"] = _load_test_gate()

    passed = all(gate["passed"] for gate in gates.values())
    metadata = promote_harness(harness_id, target_status if passed else "rejected")
    result = {
        "passed": passed,
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "git_commit": _git_commit(),
        "harness_id": harness_id,
        "metadata": metadata,
        "gates": gates,
    }
    _write_report(result, report_path)
    _write_json_report(result, json_report_path)
    return result


def _command_gate(command: list[str]) -> Dict[str, Any]:
    proc = subprocess.run(command, text=True, capture_output=True)
    return {
        "passed": proc.returncode == 0,
        "details": {
            "command": command,
            "returncode": proc.returncode,
            "stdout_tail": proc.stdout[-2000:],
            "stderr_tail": proc.stderr[-2000:],
        },
    }


def _backend_gate() -> Dict[str, Any]:
    result = run_backend_conformance(JsonBackend(root="data/gate-backend"), user_prefix="gate")
    return {"passed": result.passed, "details": result.to_dict()}


def _holdout_gate(harness_id: str) -> Dict[str, Any]:
    summary_path = Path("results/holdout_evaluation.json")
    result = _command_gate(
        [
            sys.executable,
            "benchmarks/run_holdout_eval.py",
            "--config",
            f"harnesses/{harness_id}/harness_params.yaml",
            "--summary",
            str(summary_path),
        ]
    )
    details: Dict[str, Any] = dict(result["details"])
    passed = result["passed"]
    if summary_path.exists():
        try:
            payload = json.loads(summary_path.read_text(encoding="utf-8"))
            metrics = payload.get("metrics", {})
            details["metrics"] = metrics
            passed = passed and float(metrics.get("recall_rate", 0.0)) >= 1.0
        except Exception as exc:  # pragma: no cover - defensive artifact parsing
            details["parse_error"] = exc.__class__.__name__
            passed = False
    else:
        passed = False
        details["missing_summary"] = str(summary_path)
    return {"passed": passed, "details": details}


def _security_scan_gate() -> Dict[str, Any]:
    report = Path("results/security_scan_report.json")
    if not report.exists():
        return {"passed": True, "details": {"skipped": True, "reason": "security scan report not present"}}
    payload = json.loads(report.read_text(encoding="utf-8"))
    high = int(payload.get("high_severity_findings", 0) or 0)
    secrets = int(payload.get("secret_findings", 0) or 0)
    return {"passed": high == 0 and secrets == 0, "details": payload}


def _load_test_gate() -> Dict[str, Any]:
    report = Path("reports/load_test_json.csv")
    if report.exists():
        return {"passed": True, "details": {"evidence_file": str(report)}}
    return {"passed": True, "details": {"skipped": True, "reason": "load test artifact optional for local gates"}}


def _no_secret_gate() -> Dict[str, Any]:
    candidates = [
        Path("configs/harness_params.yaml"),
        Path("manifests/evolve_manifest.jsonl"),
        Path("results/harness_evolution_validation.md"),
        Path("results/production_gate_report.md"),
    ]
    leaked = [str(path) for path in candidates if path.exists() and contains_secret(path.read_text(encoding="utf-8"))]
    return {"passed": not leaked, "details": {"checked": [str(path) for path in candidates], "leaked": leaked}}


def _skipped() -> Dict[str, Any]:
    return {"passed": True, "details": {"skipped": True}}


def _write_report(result: Dict[str, Any], report_path: str | Path) -> None:
    path = Path(report_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        "# Harness Production Gate Report",
        "",
        f"- Harness: `{result['harness_id']}`",
        f"- Passed: `{result['passed']}`",
        "",
        "| Gate | Result |",
        "|---|---|",
    ]
    for gate, payload in result["gates"].items():
        lines.append(f"| {gate} | {'pass' if payload['passed'] else 'fail'} |")
    lines.extend(["", "```json", redact_secret(json.dumps(result, indent=2, sort_keys=True)), "```", ""])
    path.write_text("\n".join(lines), encoding="utf-8")


def _write_json_report(result: Dict[str, Any], json_report_path: str | Path) -> None:
    path = Path(json_report_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(redact_secret(json.dumps(result, indent=2, sort_keys=True)), encoding="utf-8")


def _git_commit() -> str:
    try:
        return subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    except Exception:
        return "unknown"
