import os
from contextlib import nullcontext
from typing import Any, Dict, List, Optional, Tuple

from .core import MemPalaceLite
from .harness import HarnessParams, load_harness_params
from .identity_fingerprint import IdentityFingerprint
from .macp import MACPLite

try:
    import torch
except Exception:
    torch = None

try:
    from transformers import GenerationConfig
except Exception:
    GenerationConfig = None


class SmritiAILite:
    """
    Model-agnostic SLM wrapper with semantic memory, graph memory, reasoning
    continuity, and GIFP v1.0 identity governance.

    Pass any pre-loaded HuggingFace causal LM and tokenizer.
    """

    def __init__(
        self,
        model: Any,
        tokenizer: Any,
        memory_path: Optional[str] = None,
        retrieval_mode: Optional[str] = None,
        session_id: str = "default",
        topic_id: str = "general",
        memory: Optional[MemPalaceLite] = None,
        identity: Optional[IdentityFingerprint] = None,
        auto_device: bool = True,
        harness_params: Optional[HarnessParams] = None,
        harness_config_path: Optional[str] = None,
    ):
        self.model = model
        self.tokenizer = tokenizer
        self.session_id = session_id
        self.topic_id = topic_id
        self.harness_params = harness_params or load_harness_params(harness_config_path)
        memory_retrieval_mode = retrieval_mode or self.harness_params.memory_retrieval_mode

        if memory is not None:
            self.memory = memory
        elif memory_path and os.path.exists(memory_path):
            self.memory = MemPalaceLite.load(
                memory_path,
                retrieval_mode=memory_retrieval_mode,
                harness_params=self.harness_params,
            )
        else:
            self.memory = MemPalaceLite(
                retrieval_mode=memory_retrieval_mode,
                session_id=session_id,
                topic_id=topic_id,
                harness_params=self.harness_params,
            )

        self.continuity = MACPLite()
        self.identity = identity or IdentityFingerprint(
            role="helpful AI assistant with persistent memory",
            threshold=self.harness_params.identity_threshold,
        )
        self.identity.set_constraints(
            [
                "Always be helpful and accurate",
                "Reference previous context when relevant",
                "Maintain logical consistency across turns",
                "Acknowledge uncertainty when present",
            ]
        )
        self.device, self.autocast_dtype = configure_inference_device()
        if auto_device:
            self._move_model_to_best_device()

    def build_prompt(self, user_input: str) -> str:
        identity = self.identity.get_identity_prompt()
        ctx = self.memory.get_context(
            query=user_input,
            session_id=self.session_id,
            topic_id=self.topic_id,
        )
        if ctx:
            return identity + "\n" + ctx + "\n\n" + user_input
        return identity + "\n" + user_input

    def _generate(self, prompt: str, max_tokens: int = 256) -> str:
        if torch is None or GenerationConfig is None:
            raise RuntimeError("torch and transformers are required for model generation.")

        messages = [{"role": "user", "content": prompt}]
        try:
            formatted = self.tokenizer.apply_chat_template(
                messages, tokenize=False, add_generation_prompt=True
            )
        except Exception:
            formatted = prompt

        inputs = self.tokenizer(
            formatted,
            return_tensors="pt",
            truncation=True,
            max_length=2048,
        )
        model_device = _model_device(self.model) or self.device
        inputs = {key: value.to(model_device) for key, value in inputs.items()}
        cfg = GenerationConfig(
            max_new_tokens=max_tokens,
            temperature=0.7,
            top_p=0.9,
            do_sample=True,
            pad_token_id=getattr(self.tokenizer, "eos_token_id", None),
        )
        with torch.inference_mode(), _autocast_context(model_device, self.autocast_dtype):
            out = self.model.generate(**inputs, generation_config=cfg)
        return self.tokenizer.decode(
            out[0, inputs["input_ids"].shape[1] :].detach().cpu(),
            skip_special_tokens=True,
        ).strip()

    def chat(self, user_input: str, refine: bool = False) -> str:
        self.continuity.start_chain(user_input)
        self.identity.observe_user_input(user_input)
        prompt = self.build_prompt(user_input)
        response = self._generate(prompt)

        context = self.memory.get_context(
            query=user_input,
            session_id=self.session_id,
            topic_id=self.topic_id,
        )
        response, identity_check = self.identity.ensure_aligned(
            response,
            self._generate,
            user_input=user_input,
            context=context,
        )
        if refine and identity_check.consistency_score < 0.5:
            response = self.identity.refinement_pass(
                self._generate,
                response,
                user_input=user_input,
                context=context,
            )
            identity_check = self.identity.evaluate_output(response)

        self.continuity.add_step(
            user_input,
            response,
            identity_check.consistency_score,
            "continue" if identity_check.consistency_score > 0.7 else "refine",
        )
        for fact in self.memory.extract_facts(response, user_input=user_input):
            self.memory.add_fact(fact, session_id=self.session_id, topic_id=self.topic_id)
        self.memory.add_to_history("User: " + user_input, "user_input")
        self.memory.add_to_history(
            "Assistant: " + response[:200], "assistant_output"
        )
        self.identity.record_behavior(response)
        return response

    def save_memory(self, path: str):
        self.memory.save(path)

    def load_memory(self, path: str):
        self.memory = MemPalaceLite.load(
            path,
            retrieval_mode=self.memory.retrieval_mode,
            harness_params=self.harness_params,
        )

    def get_memory_state(self) -> Dict:
        return self.memory.to_dict()

    def get_reasoning_chain(self) -> str:
        return self.continuity.get_chain_summary()

    def _move_model_to_best_device(self) -> None:
        if torch is None or self.device is None or str(self.device) == "cpu":
            return
        try:
            current = _model_device(self.model)
            if current is not None and str(current).startswith("cuda"):
                return
            self.model.to(self.device)
        except Exception:
            pass


class BaselineGemma:
    """Plain causal LM with no memory, no identity layer, no continuity."""

    def __init__(self, model: Any, tokenizer: Any, auto_device: bool = True):
        self.model = model
        self.tokenizer = tokenizer
        self._history: List[str] = []
        self.device, self.autocast_dtype = configure_inference_device()
        if auto_device and torch is not None and str(self.device) != "cpu":
            try:
                self.model.to(self.device)
            except Exception:
                pass

    def chat(self, user_input: str) -> str:
        if torch is None or GenerationConfig is None:
            raise RuntimeError("torch and transformers are required for model generation.")

        messages = [{"role": "user", "content": user_input}]
        try:
            prompt = self.tokenizer.apply_chat_template(
                messages, tokenize=False, add_generation_prompt=True
            )
        except Exception:
            prompt = user_input
        inputs = self.tokenizer(
            prompt,
            return_tensors="pt",
            truncation=True,
            max_length=2048,
        )
        model_device = _model_device(self.model) or self.device
        inputs = {key: value.to(model_device) for key, value in inputs.items()}
        cfg = GenerationConfig(
            max_new_tokens=getattr(self, "max_new_tokens", 256),
            temperature=0.7,
            top_p=0.9,
            do_sample=True,
            pad_token_id=getattr(self.tokenizer, "eos_token_id", None),
        )
        with torch.inference_mode(), _autocast_context(model_device, self.autocast_dtype):
            out = self.model.generate(**inputs, generation_config=cfg)
        response = self.tokenizer.decode(
            out[0, inputs["input_ids"].shape[1] :].detach().cpu(),
            skip_special_tokens=True,
        ).strip()
        self._history.extend(["User: " + user_input, "Assistant: " + response])
        return response

    def reset(self):
        self._history = []


def configure_inference_device() -> Tuple[Any, Any]:
    """Return the preferred torch device and mixed-precision dtype."""

    if torch is None:
        return "cpu", None
    if torch.cuda.is_available():
        dtype = torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16
        return torch.device("cuda"), dtype
    return torch.device("cpu"), torch.float32


def _model_device(model: Any) -> Any:
    try:
        return next(model.parameters()).device
    except Exception:
        return None


def _autocast_context(device: Any, dtype: Any):
    if torch is None or dtype is None:
        return nullcontext()
    if str(device).startswith("cuda"):
        return torch.autocast(device_type="cuda", dtype=dtype)
    return nullcontext()


# Backwards compatibility for existing user code.
GodelAILite = SmritiAILite
