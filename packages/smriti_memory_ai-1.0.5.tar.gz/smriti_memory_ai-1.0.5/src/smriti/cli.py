"""Command-line tools for local Smriti AI experimentation."""

from __future__ import annotations

import argparse
import csv
import json
import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

from cryptography.fernet import Fernet

from .backend_conformance import run_backend_conformance
from .backends import build_backend
from .config import configure_environment_from_file, write_default_config
from .core import MemPalaceLite
from .harness_registry import (
    activate_harness,
    compare_harnesses,
    list_harnesses,
    load_harness,
    load_metadata,
    record_rollback_event,
)
from .manifest_verifier import verify_manifest
from .production_safety import require_test_doubles_allowed
from .security.api_keys import create_record, load_records, write_records
from .security.encryption import encryption_key_configured, validate_encryption_policy
from .support.bundle import create_diagnostics_bundle
from .support.error_report import ErrorReportRequest, store_error_report
from .support.fixes import run_safe_fix
from .support.repro import create_repro_case, run_repro_case
from .support.triage import triage_asdict


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="smriti-cli",
        description="Smriti AI local CLI for configuration, memory, API, and benchmarks.",
    )
    parser.add_argument("--config", help="Path to config.yaml. Defaults to SMRITI_CONFIG_PATH or ./config.yaml.")
    parser.add_argument("--memory-path", default="smriti_memory.json")
    parser.add_argument("--session-id", default="default", help="User/session id for isolated memory.")
    parser.add_argument("--topic-id", default="general")
    parser.add_argument(
        "--backend",
        choices=["json", "sqlite", "redis", "postgres"],
        help="Durable backend. Defaults to config.yaml or SMRITI_MEMORY_BACKEND.",
    )
    parser.add_argument("--backend-path", help="JSON root or SQLite path for local durable backends.")
    parser.add_argument("--retrieval-mode", choices=["semantic", "tfidf"], default="semantic")

    subparsers = parser.add_subparsers(dest="command", required=True)

    subparsers.add_parser("status", help="Generate and print the product status dashboard.")

    init_parser = subparsers.add_parser("init", help="Create a config.yaml template.")
    init_parser.add_argument("path", nargs="?", default="config.yaml")
    init_parser.add_argument("--overwrite", action="store_true")

    config_parser = subparsers.add_parser("config", help="Configuration helpers.")
    config_sub = config_parser.add_subparsers(dest="config_command", required=True)
    wizard_parser = config_sub.add_parser("wizard", help="Create config.yaml with backend defaults.")
    wizard_parser.add_argument("--path", default="config.yaml")
    wizard_parser.add_argument("--backend", choices=["json", "sqlite", "redis", "postgres"])
    wizard_parser.add_argument("--encrypt", action="store_true", help="Generate a local Fernet encryption key.")
    wizard_parser.add_argument("--overwrite", action="store_true")

    server_parser = subparsers.add_parser("start-server", help="Start the FastAPI server.")
    server_parser.add_argument("--host", default=None)
    server_parser.add_argument("--port", type=int, default=None)
    server_parser.add_argument("--reload", action="store_true")
    server_parser.add_argument("--harness", help="Harness ID from harnesses/ to activate for this process.")

    chat_parser = subparsers.add_parser("chat", help="Store a message and show retrieved memory.")
    chat_parser.add_argument("message")

    load_parser = subparsers.add_parser("load", help="Load memory JSON and print a summary.")
    load_parser.add_argument("path", nargs="?")

    save_parser = subparsers.add_parser("save", help="Save memory to a path.")
    save_parser.add_argument("path", nargs="?")

    delete_parser = subparsers.add_parser("delete", help="Delete all memory for a user.")
    delete_parser.add_argument("--path", help="Optional memory JSON path to remove as well.")

    memory_parser = subparsers.add_parser("memory", help="Namespaced memory operations.")
    memory_sub = memory_parser.add_subparsers(dest="memory_command", required=True)
    memory_save = memory_sub.add_parser("save", help="Save memory for the configured user.")
    memory_save.add_argument("path", nargs="?")
    memory_load = memory_sub.add_parser("load", help="Load memory for the configured user.")
    memory_load.add_argument("path", nargs="?")
    memory_delete = memory_sub.add_parser("delete", help="Delete memory for the configured user.")
    memory_delete.add_argument("--path", help="Optional memory JSON path to remove as well.")

    graph_parser = subparsers.add_parser("graph_query", help="Query the knowledge graph.")
    graph_parser.add_argument("entity")
    graph_parser.add_argument("--depth", type=int, default=1)

    benchmark_parser = subparsers.add_parser("benchmark", help="Run the Gemma 4 benchmark suite.")
    benchmark_parser.add_argument("--max-new-tokens", type=int, default=80)
    benchmark_parser.add_argument(
        "--quick",
        action="store_true",
        help=(
            "Run an internal deterministic test-double benchmark smoke. "
            "Requires SMRITI_ALLOW_TEST_DOUBLES=1 and writes internal-only artifacts."
        ),
    )
    benchmark_parser.add_argument("--full", action="store_true", help="Run the full configured benchmark suite.")

    backend_parser = subparsers.add_parser("backend", help="Backend diagnostics.")
    backend_sub = backend_parser.add_subparsers(dest="backend_command", required=True)
    backend_conformance = backend_sub.add_parser(
        "conformance",
        help="Run the Smriti backend compatibility contract against the selected backend.",
    )
    backend_conformance.add_argument(
        "--user-prefix",
        default="smriti-cli-conformance",
        help="Temporary user ID prefix used during the conformance run.",
    )
    backend_conformance.add_argument(
        "--keep-data",
        action="store_true",
        help="Leave temporary conformance users in the backend for inspection.",
    )

    migrate_parser = subparsers.add_parser(
        "migrate-backend",
        help="Copy one user's memory from one durable backend to another.",
    )
    migrate_parser.add_argument("--from-backend", required=True, choices=["json", "sqlite", "redis", "postgres"])
    migrate_parser.add_argument("--to-backend", required=True, choices=["json", "sqlite", "redis", "postgres"])
    migrate_parser.add_argument("--from-path", help="JSON root or SQLite file for the source backend.")
    migrate_parser.add_argument("--to-path", help="JSON root or SQLite file for the destination backend.")
    migrate_parser.add_argument("--from-url", help="Redis URL or Postgres DSN for the source backend.")
    migrate_parser.add_argument("--to-url", help="Redis URL or Postgres DSN for the destination backend.")
    migrate_parser.add_argument("--user-id", default=None, help="User ID to migrate. Defaults to --session-id.")
    migrate_parser.add_argument("--delete-source", action="store_true", help="Delete source memory after a successful copy.")

    harness_parser = subparsers.add_parser("harness", help="Harness registry and promotion commands.")
    harness_sub = harness_parser.add_subparsers(dest="harness_command", required=True)
    harness_list = harness_sub.add_parser("list", help="List registered harnesses.")
    harness_list.add_argument("--all", action="store_true", help="Include rejected harnesses.")
    harness_show = harness_sub.add_parser("show", help="Show one harness metadata/config.")
    harness_show.add_argument("harness_id")
    harness_activate = harness_sub.add_parser("activate", help="Activate a harness by copying it into configs/harness_params.yaml.")
    harness_activate.add_argument("harness_id")
    harness_compare = harness_sub.add_parser("compare", help="Compare two harness configs.")
    harness_compare.add_argument("left")
    harness_compare.add_argument("right")
    harness_rollback = harness_sub.add_parser("rollback", help="Rollback to a previous harness.")
    harness_rollback.add_argument("harness_id")
    harness_sub.add_parser("verify-manifest", help="Verify evolve_manifest.jsonl.")
    harness_promote = harness_sub.add_parser("promote", help="Run production gates and promote a harness only if they pass.")
    harness_promote.add_argument("harness_id")
    harness_promote.add_argument("--to", default="production")
    harness_promote.add_argument("--skip-tests", action="store_true", help="Skip pytest gate for local dry runs.")
    harness_sub.add_parser("regression-test", help="Run harness regression tests.")

    security_parser = subparsers.add_parser("security", help="Security administration and reports.")
    security_sub = security_parser.add_subparsers(dest="security_command", required=True)
    create_key = security_sub.add_parser("create-api-key", help="Create a hashed API key record.")
    create_key.add_argument("--role", required=True, choices=["user", "developer", "admin", "auditor", "service"])
    create_key.add_argument("--user-id", action="append", default=[], help="Allowed user ID. Repeatable.")
    create_key.add_argument("--tenant-id", action="append", default=[], help="Allowed tenant ID. Repeatable.")
    create_key.add_argument("--key-id", help="Stable key identifier.")
    create_key.add_argument("--path", default=None, help="API key store path.")
    revoke_key = security_sub.add_parser("revoke-api-key", help="Revoke an API key by key_id.")
    revoke_key.add_argument("--key-id", required=True)
    revoke_key.add_argument("--path", default=None)
    security_sub.add_parser("list-api-keys", help="List API key metadata without secrets.").add_argument("--path", default=None)
    rotate_key = security_sub.add_parser("rotate-api-key", help="Revoke an API key and create a replacement.")
    rotate_key.add_argument("--key-id", required=True)
    rotate_key.add_argument("--path", default=None)
    security_sub.add_parser("rotate-key", help="Validate encryption-key rotation readiness without printing keys.")
    security_sub.add_parser("validate-config", help="Validate production security configuration.")
    security_sub.add_parser("report", help="Generate the security acceptance report.")

    support_parser = subparsers.add_parser("support", help="Support diagnostics and user-error intake.")
    support_sub = support_parser.add_subparsers(dest="support_command", required=True)
    support_collect = support_sub.add_parser("collect-diagnostics", help="Create a redacted diagnostics bundle.")
    support_collect.add_argument("--request-id")
    support_report = support_sub.add_parser("report-error", help="Store a privacy-safe local error report.")
    support_report.add_argument("--category", required=True)
    support_report.add_argument("--summary", required=True)
    support_report.add_argument("--steps-to-reproduce", default="")
    support_report.add_argument("--user-id")
    support_report.add_argument("--request-id")
    support_sub.add_parser("redact-bundle", help="Validate a bundle is redacted.").add_argument("path")
    support_repro = support_sub.add_parser("create-repro", help="Create a synthetic repro from a diagnostics bundle.")
    support_repro.add_argument("--bundle", required=True)
    support_run = support_sub.add_parser("run-repro", help="Run a synthetic repro case.")
    support_run.add_argument("case")
    support_triage = support_sub.add_parser("triage", help="Classify a support issue.")
    support_triage.add_argument("--category", default="other")
    support_triage.add_argument("--summary", required=True)

    fix_parser = subparsers.add_parser("fix", help="Safe remediation helpers.")
    fix_sub = fix_parser.add_subparsers(dest="fix_command", required=True)
    for name in ["diagnose", "backend-health", "verify-delete", "rebuild-index", "clear-cache", "validate-config", "collect-bundle"]:
        item = fix_sub.add_parser(name)
        item.add_argument("--user-id")
    rollback_fix = fix_sub.add_parser("rollback-harness")
    rollback_fix.add_argument("--confirm", action="store_true")
    rotate_fix = fix_sub.add_parser("rotate-key")
    rotate_fix.add_argument("--dry-run", action="store_true")

    ops_parser = subparsers.add_parser("ops", help="Operations utilities.")
    ops_sub = ops_parser.add_subparsers(dest="ops_command", required=True)
    estimate = ops_sub.add_parser("estimate-cost", help="Estimate monthly deployment cost.")
    estimate.add_argument("--requests-per-day", type=int, default=10000)
    estimate.add_argument("--backend", choices=["json", "sqlite", "redis", "postgres"], default="redis")
    estimate.add_argument("--model-provider", choices=["local-cpu", "local-gpu", "hf-endpoint", "external"], default="hf-endpoint")
    estimate.add_argument("--average-prompt-tokens", type=int, default=800)
    estimate.add_argument("--average-output-tokens", type=int, default=180)
    estimate.add_argument("--user-count", type=int, default=1000)
    estimate.add_argument("--memory-entries-per-user", type=int, default=100)
    postmortem = ops_sub.add_parser("generate-postmortem", help="Generate a postmortem draft.")
    postmortem.add_argument("--incident-id", required=True)
    fix_plan = ops_sub.add_parser("fix-plan", help="Generate a safe remediation plan from a production-break report.")
    fix_plan.add_argument("--from", dest="source", default="reports/production_break_test_report.json")

    args = parser.parse_args(argv)
    if args.config:
        os.environ["SMRITI_CONFIG_PATH"] = args.config
    configure_environment_from_file(args.config)

    if args.command == "init":
        path = write_default_config(args.path, overwrite=args.overwrite)
        print(f"Wrote config template: {path}")
        return 0

    if args.command == "config" and args.config_command == "wizard":
        path = _write_wizard_config(
            args.path,
            backend=args.backend or _prompt_backend(),
            encrypt=args.encrypt,
            overwrite=args.overwrite,
        )
        print(f"Wrote Smriti AI config: {path}")
        print(_config_next_steps(path))
        return 0

    if args.command == "start-server":
        return _start_server(host=args.host, port=args.port, reload=args.reload, harness=args.harness)

    if args.command == "benchmark":
        return _run_benchmark(args.max_new_tokens, quick=args.quick, full=args.full)

    if args.command == "backend" and args.backend_command == "conformance":
        result = run_backend_conformance(
            _backend(args),
            user_prefix=args.user_prefix,
            cleanup=not args.keep_data,
        )
        print(json.dumps(result.to_dict(), indent=2))
        return 0

    if args.command == "migrate-backend":
        print(_migrate_backend(args))
        return 0

    if args.command == "harness":
        return _harness_command(args)

    if args.command == "security":
        return _security_command(args)

    if args.command == "support":
        return _support_command(args)

    if args.command == "fix":
        return _fix_command(args)

    if args.command == "ops":
        return _ops_command(args)

    if args.command == "status":
        return subprocess.call([sys.executable, "status/generate_status.py"])

    memory = _load_or_new(args.memory_path, args.retrieval_mode, args.session_id, args.topic_id)

    if args.command == "chat":
        context = memory.get_context(query=args.message, session_id=args.session_id, topic_id=args.topic_id)
        facts = memory.extract_facts("", user_input=args.message)
        for fact in facts:
            memory.add_fact(fact, session_id=args.session_id, topic_id=args.topic_id)
        memory.add_to_history("User: " + args.message, "user_input")
        memory.save(args.memory_path)
        _save_to_backend_if_requested(args, memory)
        print(context or "No relevant prior memory.")
        if facts:
            print("\nStored facts:")
            for fact in facts:
                print(f"- {fact}")
        return 0

    if args.command == "load" or (args.command == "memory" and args.memory_command == "load"):
        load_path = getattr(args, "path", None) or args.memory_path
        if Path(load_path).exists():
            loaded = MemPalaceLite.load(load_path, retrieval_mode=args.retrieval_mode)
        else:
            state = _backend(args).load(args.session_id)
            if state is None:
                raise SystemExit(f"No memory found for user {args.session_id!r}.")
            loaded = MemPalaceLite.from_dict(state, retrieval_mode=args.retrieval_mode)
        print(_summary(loaded))
        return 0

    if args.command == "save" or (args.command == "memory" and args.memory_command == "save"):
        memory.save(getattr(args, "path", None) or args.memory_path)
        _save_to_backend_if_requested(args, memory)
        print(_summary(memory))
        return 0

    if args.command == "delete" or (args.command == "memory" and args.memory_command == "delete"):
        print(_delete_memory(args))
        return 0

    if args.command == "graph_query":
        triples = memory.knowledge_graph.query_graph(
            args.session_id,
            args.entity,
            depth=args.depth,
            topic_id=args.topic_id,
        )
        print(json.dumps([triple.__dict__ for triple in triples], indent=2))
        return 0

    return 1


def _load_or_new(path: str, retrieval_mode: str, session_id: str, topic_id: str) -> MemPalaceLite:
    if Path(path).exists():
        memory = MemPalaceLite.load(path, retrieval_mode=retrieval_mode)
        memory.session_id = session_id
        memory.topic_id = topic_id
        return memory
    return MemPalaceLite(retrieval_mode=retrieval_mode, session_id=session_id, topic_id=topic_id)


def _summary(memory: MemPalaceLite) -> str:
    state: dict[str, Any] = memory.to_dict()
    semantic_sessions = state.get("semantic_memory", {}).get("sessions", {}) if state.get("semantic_memory") else {}
    return json.dumps(
        {
            "retrieval_mode": state["retrieval_mode"],
            "facts": len(state["key_facts"]),
            "history": len(state["history"]),
            "semantic_sessions": list(semantic_sessions.keys()),
        },
        indent=2,
    )


def _backend(args: argparse.Namespace):
    kwargs = {}
    if args.backend_path:
        if args.backend == "sqlite":
            kwargs["path"] = args.backend_path
        else:
            kwargs["root"] = args.backend_path
    return build_backend(args.backend, **kwargs)


def _backend_from_options(kind: str, path: str | None = None, url: str | None = None):
    kwargs: dict[str, Any] = {}
    if path:
        if kind == "sqlite":
            kwargs["path"] = path
        else:
            kwargs["root"] = path
    if url:
        if kind == "redis":
            kwargs["url"] = url
        elif kind == "postgres":
            kwargs["dsn"] = url
    return build_backend(kind, **kwargs)


def _migrate_backend(args: argparse.Namespace) -> str:
    user_id = args.user_id or args.session_id
    source = _backend_from_options(args.from_backend, args.from_path, args.from_url)
    destination = _backend_from_options(args.to_backend, args.to_path, args.to_url)
    state = source.load(user_id)
    if state is None:
        raise SystemExit(f"No source memory found for user {user_id!r}.")
    destination.save(user_id, state)
    deleted_source = source.delete_user(user_id) if args.delete_source else False
    return json.dumps(
        {
            "user_id": user_id,
            "from_backend": args.from_backend,
            "to_backend": args.to_backend,
            "deleted_source": deleted_source,
            "status": "migrated",
        },
        indent=2,
    )


def _save_to_backend_if_requested(args: argparse.Namespace, memory: MemPalaceLite) -> None:
    if args.backend or args.backend_path or os.getenv("SMRITI_AUTOSAVE", "0").lower() in {"1", "true", "yes"}:
        _backend(args).save(args.session_id, memory.to_dict())


def _delete_memory(args: argparse.Namespace) -> str:
    deleted_file = False
    target = Path(getattr(args, "path", None) or args.memory_path)
    if target.exists():
        target.unlink()
        deleted_file = True
    deleted_backend = _backend(args).delete_user(args.session_id)
    return json.dumps(
        {"user_id": args.session_id, "deleted_file": deleted_file, "deleted_backend": deleted_backend},
        indent=2,
    )


def _write_wizard_config(path: str, backend: str, encrypt: bool, overwrite: bool) -> Path:
    config_path = write_default_config(path, overwrite=overwrite)
    text = config_path.read_text(encoding="utf-8")
    text = text.replace("backend: json", f"backend: {backend}")
    if encrypt:
        key = Fernet.generate_key().decode("utf-8")
        text = text.replace('encryption_key: ""', f'encryption_key: "{key}"')
    config_path.write_text(text, encoding="utf-8")
    return config_path


def _prompt_backend() -> str:
    if not sys.stdin.isatty():
        return "json"
    options = ["json", "sqlite", "redis", "postgres"]
    print("Choose a memory backend:")
    for idx, option in enumerate(options, start=1):
        print(f"  {idx}. {option}")
    answer = input("Backend [1=json]: ").strip()
    if not answer:
        return "json"
    if answer.isdigit() and 1 <= int(answer) <= len(options):
        return options[int(answer) - 1]
    if answer.lower() in options:
        return answer.lower()
    print("Unknown backend; using json.")
    return "json"


def _config_next_steps(path: Path) -> str:
    return "\n".join(
        [
            "Next steps:",
            f"  export SMRITI_CONFIG_PATH={path}",
            "  smriti-cli start-server --host 0.0.0.0 --port 8000",
            "  smriti-cli --session-id alex chat \"My name is Alex and I work at Ocean Lab.\"",
        ]
    )


def _start_server(host: str | None, port: int | None, reload: bool, harness: str | None = None) -> int:
    import uvicorn

    if harness:
        os.environ["SMRITI_HARNESS_ID"] = harness
    uvicorn.run(
        "smriti.api:app",
        host=host or os.getenv("SMRITI_HOST", "0.0.0.0"),
        port=port or int(os.getenv("SMRITI_PORT", "8000")),
        reload=reload,
    )
    return 0


def _run_benchmark(max_new_tokens: int, *, quick: bool = False, full: bool = False) -> int:
    script = _find_benchmark_script()
    if script is None:
        if quick:
            return _run_packaged_quick_benchmark(max_new_tokens)
        print(
            "Full benchmark scripts are repository tools and were not found in this installed "
            "environment. Clone https://github.com/Luciferai04/smriti-ai and run "
            "`python benchmarks/run_benchmarks.py ...`, or use `smriti-cli benchmark --quick` "
            "for an internal install smoke check.",
            file=sys.stderr,
        )
        return 2

    cmd = [
        sys.executable,
        str(script),
        "--model-preset",
        "gemma4",
        "--max-new-tokens",
        str(max_new_tokens),
    ]
    if quick:
        cmd.append("--quick")
        cmd.extend(
            [
                "--output",
                "results/internal_ci/benchmark_quick.csv",
                "--markdown-output",
                "results/internal_ci/benchmark_quick.md",
                "--summary-output",
                "results/internal_ci/benchmark_quick_summary.md",
            ]
        )
    if full:
        cmd.append("--full")
    return subprocess.call(cmd)


def _find_benchmark_script() -> Path | None:
    """Find the repository benchmark script when the CLI is run from source.

    Wheels intentionally do not install the full research benchmark tree. In
    that case, quick mode uses a small packaged smoke check and full benchmark
    mode gives a clear clone-the-repo message instead of a raw file-not-found.
    """

    candidates = [
        Path.cwd() / "benchmarks" / "run_benchmarks.py",
        Path(__file__).resolve().parents[2] / "benchmarks" / "run_benchmarks.py",
    ]
    for candidate in candidates:
        if candidate.exists():
            return candidate
    return None


def _run_packaged_quick_benchmark(max_new_tokens: int) -> int:
    """Run a deterministic install smoke benchmark from an installed wheel.

    This is not public model-quality evidence. It exists so customer success,
    CI, and enterprise evaluators can quickly verify that the installed package,
    memory layer, CLI, and artifact writing path work before running the real
    Gemma 4 benchmark from the source repository.
    """

    require_test_doubles_allowed("smriti-cli benchmark --quick")
    output_dir = Path("results/internal_ci")
    output_dir.mkdir(parents=True, exist_ok=True)
    csv_path = output_dir / "benchmark_quick.csv"
    md_path = output_dir / "benchmark_quick.md"
    summary_path = output_dir / "benchmark_quick_summary.md"

    facts = [
        "My name is Alex.",
        "I am a marine biologist.",
        "I am based in Hawaii.",
    ]
    questions = [
        "What is my name?",
        "What is my profession?",
        "Where am I based?",
    ]
    start = time.perf_counter()
    memory = MemPalaceLite(retrieval_mode="semantic", session_id="quick-smoke", topic_id="profile")
    for fact in facts:
        memory.add_fact(fact, session_id="quick-smoke", topic_id="profile")
    retrieved = [
        memory.retrieve_facts(question, k=3, session_id="quick-smoke", topic_id="profile")
        for question in questions
    ]
    elapsed_ms = (time.perf_counter() - start) * 1000
    hits = sum(
        any(expected.lower().rstrip(".") in item.lower() for item in items)
        for expected, items in zip(facts, retrieved)
    )
    recall = hits / len(facts)
    token_overhead = sum(len(item.split()) for items in retrieved for item in items)

    row = {
        "harness_id": os.getenv("SMRITI_HARNESS_ID", "install-smoke"),
        "model_name": "deterministic-install-smoke",
        "retrieval_mode": "semantic",
        "recall_accuracy": f"{recall:.3f}",
        "retrieval_precision_at_k": f"{recall:.3f}",
        "retrieval_recall_at_k": f"{recall:.3f}",
        "identity_drift": "0.000",
        "p50_latency_ms": f"{elapsed_ms:.3f}",
        "p95_latency_ms": f"{elapsed_ms:.3f}",
        "token_overhead": str(token_overhead),
        "backend": "in_memory",
        "timestamp": str(int(time.time())),
        "benchmark_mode": "internal_install_smoke",
        "is_test_double": "true",
        "claim_status": "internal_only_not_public_evidence",
        "max_new_tokens": str(max_new_tokens),
    }
    with csv_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(row))
        writer.writeheader()
        writer.writerow(row)
    md = "\n".join(
        [
            "# Smriti AI Internal Install Smoke Benchmark",
            "",
            "This quick check uses a deterministic install-smoke path and is not public "
            "model-quality evidence. Public benchmark claims must come from real Gemma 4 runs.",
            "",
            "| Metric | Value |",
            "|---|---:|",
            f"| Recall | {recall:.3f} |",
            f"| Hits | {hits}/3 |",
            f"| Latency ms | {elapsed_ms:.3f} |",
            f"| Token overhead | {token_overhead} |",
        ]
    )
    md_path.write_text(md + "\n", encoding="utf-8")
    summary_path.write_text(md + "\n", encoding="utf-8")
    print(f"Wrote internal quick benchmark artifacts under {output_dir}")
    return 0


def _harness_command(args: argparse.Namespace) -> int:
    if args.harness_command == "list":
        print(json.dumps(list_harnesses(include_rejected=args.all), indent=2, sort_keys=True))
        return 0
    if args.harness_command == "show":
        load_harness(args.harness_id)
        payload = {
            "metadata": load_metadata(args.harness_id),
            "config": load_harness(args.harness_id).to_dict(),
        }
        print(json.dumps(payload, indent=2, sort_keys=True))
        return 0
    if args.harness_command == "activate":
        print(json.dumps(activate_harness(args.harness_id), indent=2, sort_keys=True))
        return 0
    if args.harness_command == "rollback":
        state = activate_harness(args.harness_id)
        record_rollback_event(args.harness_id)
        print(json.dumps(state, indent=2, sort_keys=True))
        return 0
    if args.harness_command == "compare":
        print(json.dumps(compare_harnesses(args.left, args.right), indent=2, sort_keys=True))
        return 0
    if args.harness_command == "verify-manifest":
        result = verify_manifest()
        print(json.dumps(result, indent=2, sort_keys=True))
        return 0 if result["valid"] else 1
    if args.harness_command == "promote":
        from .production_gates import run_production_gates

        result = run_production_gates(
            args.harness_id,
            target_status=args.to,
            run_tests=not args.skip_tests,
        )
        print(json.dumps({"passed": result["passed"], "harness_id": args.harness_id}, indent=2))
        return 0 if result["passed"] else 1
    if args.harness_command == "regression-test":
        return subprocess.call([sys.executable, "-m", "pytest", "tests/regression", "-q"])
    return 1


def _security_command(args: argparse.Namespace) -> int:
    if args.security_command == "create-api-key":
        api_key, record = create_record(
            role=args.role,
            key_id=args.key_id,
            allowed_user_ids=args.user_id,
            allowed_tenants=args.tenant_id,
        )
        records = load_records(args.path, allow_legacy_plaintext=False)
        records.append(record)
        path = write_records(records, args.path)
        print(json.dumps({"key_id": record.key_id, "path": str(path), "api_key": api_key}, indent=2))
        print("Store this API key securely. It will not be recoverable from the hashed key store.", file=sys.stderr)
        return 0
    if args.security_command == "revoke-api-key":
        records = load_records(args.path, allow_legacy_plaintext=False)
        changed = False
        for record in records:
            if record.key_id == args.key_id:
                record.revoked = True
                changed = True
        write_records(records, args.path)
        print(json.dumps({"key_id": args.key_id, "revoked": changed}, indent=2))
        return 0 if changed else 1
    if args.security_command == "list-api-keys":
        records = load_records(args.path, allow_legacy_plaintext=False)
        print(
            json.dumps(
                [
                    {
                        "key_id": record.key_id,
                        "role": record.role,
                        "allowed_user_ids": record.allowed_user_ids,
                        "allowed_tenants": record.allowed_tenants,
                        "created_at": record.created_at,
                        "expires_at": record.expires_at,
                        "revoked": record.revoked,
                        "rate_limit_tier": record.rate_limit_tier,
                    }
                    for record in records
                ],
                indent=2,
            )
        )
        return 0
    if args.security_command == "rotate-api-key":
        records = load_records(args.path, allow_legacy_plaintext=False)
        replacement = None
        for record in records:
            if record.key_id == args.key_id:
                record.revoked = True
                api_key, replacement = create_record(
                    role=record.role,
                    key_id=f"{record.key_id}-rotated",
                    allowed_user_ids=record.allowed_user_ids,
                    allowed_tenants=record.allowed_tenants,
                    rate_limit_tier=record.rate_limit_tier,
                )
                records.append(replacement)
                write_records(records, args.path)
                print(json.dumps({"revoked_key_id": args.key_id, "new_key_id": replacement.key_id, "api_key": api_key}, indent=2))
                return 0
        print(json.dumps({"key_id": args.key_id, "rotated": False}, indent=2))
        return 1
    if args.security_command == "rotate-key":
        configured = encryption_key_configured()
        print(json.dumps({"encryption_key_configured": configured, "status": "ready" if configured else "missing_key"}, indent=2))
        return 0 if configured else 1
    if args.security_command == "validate-config":
        try:
            validate_encryption_policy()
        except Exception as exc:
            print(json.dumps({"valid": False, "error": exc.__class__.__name__}, indent=2))
            return 1
        print(json.dumps({"valid": True}, indent=2))
        return 0
    if args.security_command == "report":
        return subprocess.call([sys.executable, "scripts/generate_security_acceptance_report.py"])
    return 1


def _support_command(args: argparse.Namespace) -> int:
    if args.support_command == "collect-diagnostics":
        path = create_diagnostics_bundle(request_id=args.request_id)
        print(json.dumps({"bundle": str(path)}, indent=2))
        return 0
    if args.support_command == "report-error":
        report = ErrorReportRequest(
            category=args.category,
            summary=args.summary,
            steps_to_reproduce=args.steps_to_reproduce,
            user_id=args.user_id,
            request_id=args.request_id,
        )
        print(json.dumps(store_error_report(report), indent=2))
        return 0
    if args.support_command == "redact-bundle":
        print(json.dumps({"bundle": args.path, "status": "redaction_check_available"}, indent=2))
        return 0
    if args.support_command == "create-repro":
        print(create_repro_case(args.bundle))
        return 0
    if args.support_command == "run-repro":
        print(json.dumps(run_repro_case(args.case), indent=2))
        return 0
    if args.support_command == "triage":
        print(json.dumps(triage_asdict({"category": args.category, "summary": args.summary}), indent=2))
        return 0
    return 1


def _fix_command(args: argparse.Namespace) -> int:
    if args.fix_command == "rollback-harness":
        print(json.dumps(run_safe_fix("rollback_production_harness", confirm=args.confirm), indent=2))
        return 0
    if args.fix_command == "rotate-key":
        print(json.dumps(run_safe_fix("rotate_encryption_key", confirm=not args.dry_run), indent=2))
        return 0 if args.dry_run else 1
    print(json.dumps(run_safe_fix(args.fix_command, user_id=getattr(args, "user_id", None)), indent=2))
    return 0


def _ops_command(args: argparse.Namespace) -> int:
    if args.ops_command == "estimate-cost":
        return subprocess.call(
            [
                sys.executable,
                "scripts/estimate_cost.py",
                "--requests-per-day",
                str(args.requests_per_day),
                "--backend",
                args.backend,
                "--model-provider",
                args.model_provider,
                "--average-prompt-tokens",
                str(args.average_prompt_tokens),
                "--average-output-tokens",
                str(args.average_output_tokens),
                "--user-count",
                str(args.user_count),
                "--memory-entries-per-user",
                str(args.memory_entries_per_user),
            ]
        )
    if args.ops_command == "generate-postmortem":
        return subprocess.call([sys.executable, "scripts/generate_postmortem.py", "--incident-id", args.incident_id])
    if args.ops_command == "fix-plan":
        return subprocess.call([sys.executable, "scripts/fix_from_production_break_report.py", "--from", args.source])
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
