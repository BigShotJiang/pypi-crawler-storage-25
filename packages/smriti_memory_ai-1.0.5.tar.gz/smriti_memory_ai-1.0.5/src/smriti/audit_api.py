"""FastAPI router for Smriti AI memory audit operations."""

from __future__ import annotations

import logging
from typing import Any, Callable, Dict, Optional

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, Field

from .audit import MemoryAuditService
from .auth import AuthContext, require_user_access
from .backends import MemoryBackend
from .security import sanitize_payload

LOGGER = logging.getLogger("smriti.audit")


class AuditListRequest(BaseModel):
    user_id: str
    session_id: Optional[str] = None
    topic_id: Optional[str] = None
    query: str = ""
    include_archived: bool = False
    limit: int = Field(default=100, ge=1, le=1000)


class AuditUpdateRequest(BaseModel):
    user_id: str
    entry_id: str
    text: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None


class AuditFlagRequest(BaseModel):
    user_id: str
    entry_id: str
    value: bool = True


class AuditDeleteRequest(BaseModel):
    user_id: str
    entry_id: str


BackendGetter = Callable[[], MemoryBackend]
AuthGetter = Callable[[Request], AuthContext]
RuntimeStateGetter = Callable[[str], Optional[Dict[str, Any]]]


def create_audit_router(
    get_backend: BackendGetter,
    get_auth_context: AuthGetter,
    get_runtime_state: Optional[RuntimeStateGetter] = None,
) -> APIRouter:
    """Create audit routes bound to the API's backend and auth context."""

    router = APIRouter(tags=["memory-audit"])

    @router.post("/memory/list")
    def list_memory(payload: AuditListRequest, request: Request) -> Dict[str, Any]:
        require_user_access(get_auth_context(request), payload.user_id)
        runtime_state = get_runtime_state(payload.user_id) if get_runtime_state else None
        entries = MemoryAuditService(get_backend()).list_entries(
            user_id=payload.user_id,
            session_id=payload.session_id,
            topic_id=payload.topic_id,
            query=payload.query,
            include_archived=payload.include_archived,
            limit=payload.limit,
            runtime_state=runtime_state,
        )
        return sanitize_payload({"user_id": payload.user_id, "entries": [entry.to_dict() for entry in entries]})

    @router.post("/memory/update")
    def update_memory(payload: AuditUpdateRequest, request: Request) -> Dict[str, Any]:
        require_user_access(get_auth_context(request), payload.user_id)
        try:
            entry = MemoryAuditService(get_backend()).update_entry(
                payload.user_id,
                payload.entry_id,
                text=payload.text,
                metadata=payload.metadata,
            )
        except NotImplementedError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        return {"updated": True, "entry": entry.to_dict()}

    @router.post("/memory/pin")
    def pin_memory(payload: AuditFlagRequest, request: Request) -> Dict[str, Any]:
        require_user_access(get_auth_context(request), payload.user_id)
        try:
            entry = MemoryAuditService(get_backend()).pin_entry(
                payload.user_id,
                payload.entry_id,
                pinned=payload.value,
            )
        except NotImplementedError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        return {"pinned": payload.value, "entry": entry.to_dict()}

    @router.post("/memory/archive")
    def archive_memory(payload: AuditFlagRequest, request: Request) -> Dict[str, Any]:
        require_user_access(get_auth_context(request), payload.user_id)
        try:
            entry = MemoryAuditService(get_backend()).archive_entry(
                payload.user_id,
                payload.entry_id,
                archived=payload.value,
            )
        except NotImplementedError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        return {"archived": payload.value, "entry": entry.to_dict()}

    @router.post("/memory/entry/delete")
    def delete_memory_entry(payload: AuditDeleteRequest, request: Request) -> Dict[str, Any]:
        require_user_access(get_auth_context(request), payload.user_id)
        try:
            deleted = MemoryAuditService(get_backend()).delete_entry(payload.user_id, payload.entry_id)
        except NotImplementedError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        return {"deleted": deleted, "user_id": payload.user_id, "entry_id": payload.entry_id}

    return router
