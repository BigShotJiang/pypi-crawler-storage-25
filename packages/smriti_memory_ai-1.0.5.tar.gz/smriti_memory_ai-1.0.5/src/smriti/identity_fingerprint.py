"""Embedding-based identity governance for Smriti AI."""

from __future__ import annotations

import math
import re
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Sequence

import numpy as np

from .semantic_memory import DEFAULT_EMBEDDING_MODEL, _HashingEmbeddingModel, _normalize


@dataclass
class IdentityCheck:
    """Result of comparing an output to the current persona fingerprint."""

    distance: float
    threshold: float
    needs_refinement: bool
    consistency_score: float


class IdentityFingerprint:
    """
    GIFP v1.0 identity governance based on sentence embeddings.

    A persona vector is built from user self-descriptions and early responses.
    Each model output is compared against that vector; outputs that drift too
    far can be regenerated with the persona fingerprint prepended.
    """

    def __init__(
        self,
        role: str = "helpful assistant with persistent memory",
        embedding_model_name: str = DEFAULT_EMBEDDING_MODEL,
        threshold: float = 0.35,
        device: str = "auto",
        embedding_model: Any = None,
    ):
        self.role_definition = role
        self.embedding_model_name = embedding_model_name
        self.threshold = threshold
        self.device = _resolve_device(device)
        self.embedding_model = embedding_model or self._load_embedding_model()
        self.constraints: List[str] = []
        self.persona_vector: Optional[np.ndarray] = None
        self.persona_evidence: List[str] = []
        self.behavior_history: List[str] = []

    # ------------------------------------------------------------------
    # Compatibility prompt methods
    # ------------------------------------------------------------------

    def set_constraints(self, constraints: List[str]) -> None:
        self.constraints = constraints

    def get_identity_prompt(self) -> str:
        prompt = f"You are a {self.role_definition}.\n"
        if self.constraints:
            prompt += "\nBehavioural guidelines:\n"
            for constraint in self.constraints:
                prompt += f"- {constraint}\n"
        if self.persona_evidence:
            prompt += "\nPersona fingerprint evidence:\n"
            for evidence in self.persona_evidence[-5:]:
                prompt += f"- {evidence}\n"
        prompt += "\nMaintain consistency across all interactions.\n"
        return prompt

    # ------------------------------------------------------------------
    # Persona vector lifecycle
    # ------------------------------------------------------------------

    def initialize_persona(self, texts: Sequence[str]) -> None:
        evidence = [text.strip() for text in texts if text and text.strip()]
        if not evidence:
            return
        vectors = np.asarray([self._embed(text) for text in evidence], dtype=np.float32)
        self.persona_vector = _normalize(vectors.mean(axis=0).reshape(1, -1))[0]
        self.persona_evidence = evidence[-12:]

    def observe_user_input(self, user_input: str) -> None:
        """Update the persona from self-descriptive user turns."""

        if _looks_personal(user_input) or len(self.persona_evidence) < 3:
            self.update_persona(user_input, weight=0.25)

    def update_persona(self, text: str, weight: float = 0.15) -> None:
        cleaned = text.strip()
        if not cleaned or len(cleaned) < 8:
            return
        vector = self._embed(cleaned)
        if self.persona_vector is None:
            self.persona_vector = vector
        else:
            blended = (1.0 - weight) * self.persona_vector + weight * vector
            self.persona_vector = _normalize(blended.reshape(1, -1))[0]
        self.persona_evidence.append(cleaned[:300])
        self.persona_evidence = self.persona_evidence[-12:]

    # ------------------------------------------------------------------
    # Drift detection and refinement
    # ------------------------------------------------------------------

    def evaluate_output(self, output: str) -> IdentityCheck:
        if self.persona_vector is None or not output.strip():
            return IdentityCheck(0.0, self.effective_threshold, False, 1.0)
        output_vector = self._embed(output)
        distance = cosine_distance(self.persona_vector, output_vector)
        threshold = self.effective_threshold
        return IdentityCheck(
            distance=distance,
            threshold=threshold,
            needs_refinement=distance > threshold,
            consistency_score=max(0.0, 1.0 - distance),
        )

    def check_consistency(self, output: str) -> float:
        """Compatibility method returning a score instead of a structured check."""

        return self.evaluate_output(output).consistency_score

    def refinement_pass(
        self,
        generate_fn: Any,
        output: str,
        user_input: str = "",
        context: str = "",
        max_tokens: int = 256,
    ) -> str:
        """Regenerate an output with persona evidence prepended."""

        prompt = self._refinement_prompt(output, user_input=user_input, context=context)
        try:
            return generate_fn(prompt, max_tokens=max_tokens)
        except TypeError:
            return generate_fn(prompt)

    def ensure_aligned(
        self,
        output: str,
        generate_fn: Any,
        user_input: str = "",
        context: str = "",
        max_tokens: int = 256,
    ) -> tuple[str, IdentityCheck]:
        check = self.evaluate_output(output)
        if not check.needs_refinement:
            return output, check
        refined = self.refinement_pass(
            generate_fn,
            output,
            user_input=user_input,
            context=context,
            max_tokens=max_tokens,
        )
        refined_check = self.evaluate_output(refined)
        return refined, refined_check

    def record_behavior(self, output: str) -> None:
        if output and len(output) > 10:
            self.behavior_history.append(output[:300])
            self.behavior_history = self.behavior_history[-20:]
            if len(self.persona_evidence) < 3:
                self.update_persona(output, weight=0.1)

    @property
    def effective_threshold(self) -> float:
        adjustment = min(0.15, math.log1p(len(self.persona_evidence)) * 0.025)
        return self.threshold + adjustment

    def to_dict(self) -> Dict[str, Any]:
        return {
            "role_definition": self.role_definition,
            "embedding_model_name": self.embedding_model_name,
            "threshold": self.threshold,
            "constraints": self.constraints,
            "persona_vector": self.persona_vector.tolist()
            if self.persona_vector is not None
            else None,
            "persona_evidence": self.persona_evidence,
            "behavior_history": self.behavior_history,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any], **kwargs: Any) -> "IdentityFingerprint":
        init_kwargs = {
            "role": data.get("role_definition", "helpful assistant with persistent memory"),
            "embedding_model_name": data.get("embedding_model_name", DEFAULT_EMBEDDING_MODEL),
            "threshold": data.get("threshold", 0.35),
        }
        init_kwargs.update(kwargs)
        inst = cls(**init_kwargs)
        vector = data.get("persona_vector")
        inst.persona_vector = np.asarray(vector, dtype=np.float32) if vector else None
        inst.constraints = list(data.get("constraints", []))
        inst.persona_evidence = list(data.get("persona_evidence", []))
        inst.behavior_history = list(data.get("behavior_history", []))
        return inst

    def _load_embedding_model(self) -> Any:
        try:
            from sentence_transformers import SentenceTransformer

            return SentenceTransformer(self.embedding_model_name, device=self.device)
        except Exception:
            return _HashingEmbeddingModel()

    def _embed(self, text: str) -> np.ndarray:
        vector = self.embedding_model.encode(
            text,
            convert_to_numpy=True,
            normalize_embeddings=True,
        )
        vector = np.asarray(vector, dtype=np.float32)
        if vector.ndim > 1:
            vector = vector[0]
        return _normalize(vector.reshape(1, -1))[0]

    def _refinement_prompt(self, output: str, user_input: str, context: str) -> str:
        evidence = "\n".join(f"- {item}" for item in self.persona_evidence[-6:])
        constraints = "\n".join(f"- {item}" for item in self.constraints)
        return (
            "[PERSONA FINGERPRINT]\n"
            f"Role: {self.role_definition}\n"
            f"{evidence}\n\n"
            "[BEHAVIOURAL GUIDELINES]\n"
            f"{constraints}\n\n"
            "[RETRIEVED CONTEXT]\n"
            f"{context}\n\n"
            "[USER MESSAGE]\n"
            f"{user_input}\n\n"
            "[DRAFT OUTPUT]\n"
            f"{output}\n\n"
            "Regenerate the answer so it remains accurate, helpful and aligned "
            "with the persona fingerprint."
        )


def cosine_distance(left: np.ndarray, right: np.ndarray) -> float:
    left = _normalize(np.asarray(left, dtype=np.float32).reshape(1, -1))[0]
    right = _normalize(np.asarray(right, dtype=np.float32).reshape(1, -1))[0]
    similarity = float(np.dot(left, right))
    return max(0.0, min(2.0, 1.0 - similarity))


def _looks_personal(text: str) -> bool:
    lowered = text.lower()
    return bool(
        re.search(
            r"\b(my name is|i am|i'm|i work|i live|i study|i research|i build|i prefer|my favorite|my favourite)\b",
            lowered,
        )
    )


def _resolve_device(device: str) -> str:
    if device != "auto":
        return device
    try:
        import torch

        return "cuda" if torch.cuda.is_available() else "cpu"
    except Exception:
        return "cpu"
