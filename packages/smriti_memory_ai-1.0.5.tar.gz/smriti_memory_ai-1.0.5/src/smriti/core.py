import json
import math
import re
from dataclasses import asdict, dataclass
from typing import Any, Dict, List, Optional

from .harness import HarnessParams, load_harness_params
from .knowledge_graph import KnowledgeGraphMemory
from .semantic_memory import DEFAULT_EMBEDDING_MODEL, SemanticMemory


@dataclass
class MemoryEntry:
    content: str
    timestamp: int
    relevance_score: float = 1.0
    category: str = "general"


class MemPalaceLite:
    """
    Structured external memory for SLMs.

    The legacy TF-IDF-style fact store is preserved for compatibility, while
    the default retrieval path now uses hierarchical semantic memory:
    sessions -> topics -> embedded facts.

    Decay formula: relevance * exp(-decay_rate * age_in_steps)
    """

    def __init__(
        self,
        max_history: int = 10,
        max_facts: int = 20,
        decay_rate: Optional[float] = None,
        retrieval_mode: Optional[str] = None,
        session_id: str = "default",
        topic_id: str = "general",
        embedding_model_name: str = DEFAULT_EMBEDDING_MODEL,
        semantic_memory: Optional[SemanticMemory] = None,
        knowledge_graph: Optional[KnowledgeGraphMemory] = None,
        max_entries_per_topic: Optional[int] = None,
        harness_params: Optional[HarnessParams] = None,
        harness_config_path: Optional[str] = None,
        **semantic_kwargs: Any,
    ):
        self.harness_params = harness_params or load_harness_params(harness_config_path)
        retrieval_mode = retrieval_mode or self.harness_params.memory_retrieval_mode
        decay_rate = self.harness_params.decay_lambda if decay_rate is None else decay_rate
        max_entries_per_topic = (
            max_entries_per_topic
            or self.harness_params.max_entries_per_topic
            or max_facts
        )
        if retrieval_mode not in {"tfidf", "semantic"}:
            raise ValueError("retrieval_mode must be 'tfidf' or 'semantic'.")

        self.history: List[MemoryEntry] = []
        self.key_facts: List[MemoryEntry] = []
        self.patterns: List[str] = []
        self.max_history = max_history
        self.max_facts = max_facts
        self.decay_rate = decay_rate
        self.step_counter = 0
        self.retrieval_mode = retrieval_mode
        self.session_id = session_id
        self.topic_id = topic_id
        self.embedding_model_name = embedding_model_name
        self.default_top_k = self.harness_params.top_k
        self.include_graph_default = self.harness_params.graph_enabled
        self.graph_depth = self.harness_params.graph_depth
        self.graph_weight = self.harness_params.graph_weight
        self.summarisation_threshold = self.harness_params.summarisation_threshold
        self.max_entries_per_topic = max_entries_per_topic

        self.semantic_memory = semantic_memory
        if self.retrieval_mode == "semantic" and self.semantic_memory is None:
            self.semantic_memory = SemanticMemory(
                embedding_model_name=embedding_model_name,
                decay_rate=decay_rate,
                max_entries_per_topic=max_entries_per_topic,
                **semantic_kwargs,
            )
        self.knowledge_graph = knowledge_graph or KnowledgeGraphMemory()

    # ------------------------------------------------------------------
    # Core memory operations
    # ------------------------------------------------------------------

    def _decayed_relevance(self, entry: MemoryEntry) -> float:
        age = self.step_counter - entry.timestamp
        return entry.relevance_score * math.exp(-self.decay_rate * age)

    def add_to_history(self, interaction: str, category: str = "interaction"):
        self.step_counter += 1
        self.history.append(
            MemoryEntry(interaction, self.step_counter, category=category)
        )
        if self.semantic_memory is not None:
            self.semantic_memory.step_counter = max(
                self.semantic_memory.step_counter,
                self.step_counter,
            )
        if len(self.history) > self.max_history:
            self.history = self.history[-self.max_history :]

    def add_fact(
        self,
        fact: str,
        relevance: float = 1.0,
        session_id: Optional[str] = None,
        topic_id: Optional[str] = None,
    ):
        fact = fact.strip()
        if not fact or len(fact) < 8:
            return
        for entry in self.key_facts:
            if (
                fact.lower()[:40] in entry.content.lower()
                or entry.content.lower()[:40] in fact.lower()
            ):
                return

        session_id = session_id or self.session_id
        topic_id = topic_id or self.topic_id
        self.key_facts.append(
            MemoryEntry(
                fact,
                self.step_counter,
                relevance_score=relevance,
                category="fact",
            )
        )

        if self.semantic_memory is not None:
            self.semantic_memory.add_entry(
                session_id,
                topic_id,
                fact,
                metadata={"category": "fact", "relevance": relevance},
            )
        self.knowledge_graph.add_statement(session_id, topic_id, fact)

        if len(self.key_facts) > self.max_facts:
            self.key_facts.sort(key=self._decayed_relevance, reverse=True)
            self.key_facts = self.key_facts[: self.max_facts]

    def add_pattern(self, pattern: str):
        if pattern and pattern not in self.patterns:
            self.patterns.append(pattern)

    # ------------------------------------------------------------------
    # Retrieval and context assembly
    # ------------------------------------------------------------------

    def retrieve_facts(
        self,
        query: str = "",
        k: Optional[int] = None,
        session_id: Optional[str] = None,
        topic_id: Optional[str] = None,
    ) -> List[str]:
        session_id = session_id or self.session_id
        topic_id = topic_id or self.topic_id
        k = int(k or self.default_top_k)

        if self.retrieval_mode == "semantic" and self.semantic_memory is not None:
            if query.strip():
                return [
                    result.entry.text
                    for result in self.semantic_memory.retrieve(
                        session_id, topic_id, query, k=k
                    )
                ]
            return [
                entry.text
                for entry in self.semantic_memory.recent_entries(session_id, topic_id, k=k)
            ]

        return self._retrieve_tfidf(query=query, k=k)

    def get_context(
        self,
        query: str = "",
        top_facts: Optional[int] = None,
        top_history: int = 3,
        session_id: Optional[str] = None,
        topic_id: Optional[str] = None,
        include_graph: Optional[bool] = None,
    ) -> str:
        session_id = session_id or self.session_id
        topic_id = topic_id or self.topic_id
        top_facts = int(top_facts or self.default_top_k)
        include_graph = self.include_graph_default if include_graph is None else include_graph
        parts = []

        facts = self.retrieve_facts(query, k=top_facts, session_id=session_id, topic_id=topic_id)
        if facts:
            facts_text = "\n".join(f"  * {fact}" for fact in facts[:top_facts])
            parts.append(f"[REMEMBERED FACTS]\n{facts_text}")

        if include_graph:
            graph_facts = self._graph_context(query, session_id=session_id, topic_id=topic_id)
            if graph_facts:
                graph_text = "\n".join(f"  * {fact}" for fact in graph_facts[:top_facts])
                parts.append(f"[RELATED GRAPH FACTS]\n{graph_text}")

        # Recent conversation is intentionally omitted for non-default topics.
        # History entries are legacy/global and do not carry a topic tag, so
        # injecting them into scoped topic retrieval can leak unrelated context.
        if self.history and top_history > 0 and topic_id == "general":
            hist_text = "\n".join(
                f"  {entry.content}" for entry in self.history[-top_history:]
            )
            parts.append(f"[RECENT CONVERSATION]\n{hist_text}")
        if self.patterns:
            pat_text = "\n".join(f"  -> {pattern}" for pattern in self.patterns[-2:])
            parts.append(f"[REASONING PATTERNS]\n{pat_text}")
        return "\n\n".join(parts)

    def _retrieve_tfidf(self, query: str, k: int) -> List[str]:
        if not self.key_facts:
            return []
        if not query.strip():
            sorted_facts = sorted(
                self.key_facts, key=self._decayed_relevance, reverse=True
            )
            return [entry.content for entry in sorted_facts[:k]]

        try:
            from sklearn.feature_extraction.text import TfidfVectorizer
            from sklearn.metrics.pairwise import cosine_similarity

            corpus = [query] + [entry.content for entry in self.key_facts]
            tfidf = TfidfVectorizer(stop_words="english").fit_transform(corpus)
            sims = cosine_similarity(tfidf[0:1], tfidf[1:])[0]
            scored = [
                (float(sim) * self._decayed_relevance(entry), entry)
                for sim, entry in zip(sims, self.key_facts)
            ]
        except Exception:
            query_terms = set(re.findall(r"[a-z0-9']+", query.lower()))
            scored = []
            for entry in self.key_facts:
                terms = set(re.findall(r"[a-z0-9']+", entry.content.lower()))
                overlap = len(query_terms & terms) / max(1, len(query_terms | terms))
                scored.append((overlap * self._decayed_relevance(entry), entry))

        scored.sort(key=lambda item: item[0], reverse=True)
        return [entry.content for _, entry in scored[:k]]

    def _graph_context(self, query: str, session_id: str, topic_id: str) -> List[str]:
        terms = _graph_query_terms(query)
        if not terms and any(word in query.lower() for word in ["me", "my", "mine"]):
            terms = ["user"]
        graph_texts: List[str] = []
        seen = set()
        for term in terms:
            triples = self.knowledge_graph.query_graph(
                session_id, term, depth=self.graph_depth, topic_id=topic_id
            )
            for text in self.knowledge_graph.triples_to_text(triples):
                if text not in seen:
                    seen.add(text)
                    graph_texts.append(text)
        return graph_texts

    # ------------------------------------------------------------------
    # Fact extraction
    # ------------------------------------------------------------------

    def extract_facts(self, text: str, user_input: str = "") -> List[str]:
        """
        Extract factual sentences from user_input + model text.

        user_input is combined with text so injected personal facts
        ("My name is Jordan") are captured. Question sentences are
        filtered by first-word check to avoid storing distractors.

        Secondary extraction is restricted to user_input only to prevent
        noisy model narration from polluting the fact store.
        """
        question_starters = (
            "what",
            "where",
            "when",
            "who",
            "how",
            "why",
            "is",
            "are",
            "do",
            "does",
            "did",
            "can",
            "will",
            "could",
            "would",
            "should",
        )
        patterns = [
            r"my name is ([\w ]+)",
            r"i am (?:a |an )?([\w ]+)",
            r"i work (?:as|at|for) ([\w ]+)",
            r"i(?:'m| am) (?:currently )?(?:studying|working on|researching|building) ([\w ]+)",
            r"i (?:live|am based) (?:in|at) ([\w ,]+)",
        ]

        def _non_question_sentences(src: str) -> List[str]:
            out = []
            for sentence in re.split(r"[.!?]", src):
                sentence = sentence.strip()
                if not sentence:
                    continue
                first = sentence.lower().split()[0] if sentence.split() else ""
                if first not in question_starters:
                    out.append(sentence)
            return out

        combined = (user_input + " " + text).strip()
        combined_sentences = _non_question_sentences(combined)
        user_sentences = _non_question_sentences(user_input)

        facts = []

        # Primary: regex patterns on combined sentences
        for sent in combined_sentences:
            for pattern in patterns:
                if re.search(pattern, sent.lower()) and 8 < len(sent) < 200:
                    facts.append(sent[:200])
                    break

        # Secondary: general facts -- user_input sentences only
        if len(facts) < 3:
            for sent in user_sentences:
                if 20 < len(sent) < 150:
                    if any(
                        kw in sent.lower()
                        for kw in [
                            " is ",
                            " are ",
                            " was ",
                            "capital",
                            "located",
                            "known for",
                        ]
                    ):
                        if sent not in facts:
                            facts.append(sent[:150])

        seen, unique = set(), []
        for fact in facts:
            key = fact.lower()[:30]
            if key not in seen:
                seen.add(key)
                unique.append(fact)
        return unique[:4]

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def save(self, path: str):
        with open(path, "w", encoding="utf-8") as handle:
            json.dump(self.to_dict(), handle, indent=2)
        print(
            f"Memory saved -> {path}  "
            f"({len(self.key_facts)} facts, {len(self.history)} history)"
        )

    @classmethod
    def load(cls, path: str, **kwargs: Any) -> "MemPalaceLite":
        with open(path, encoding="utf-8") as handle:
            data = json.load(handle)
        inst = cls.from_dict(data, **kwargs)
        print(
            f"Memory loaded <- {path}  "
            f"({len(inst.key_facts)} facts, {len(inst.history)} history)"
        )
        return inst

    @classmethod
    def from_dict(cls, data: Dict[str, Any], **kwargs: Any) -> "MemPalaceLite":
        semantic_data = data.get("semantic_memory")
        graph_data = data.get("knowledge_graph")

        semantic_kwargs = dict(kwargs)
        max_history = semantic_kwargs.pop("max_history", data.get("max_history", 10))
        max_facts = semantic_kwargs.pop("max_facts", data.get("max_facts", 20))
        decay_rate = semantic_kwargs.pop("decay_rate", data.get("decay_rate", 0.05))
        retrieval_mode = semantic_kwargs.pop(
            "retrieval_mode",
            data.get("retrieval_mode", "semantic" if semantic_data else "tfidf"),
        )
        session_id = semantic_kwargs.pop("session_id", data.get("session_id", "default"))
        topic_id = semantic_kwargs.pop("topic_id", data.get("topic_id", "general"))
        embedding_model_name = semantic_kwargs.pop(
            "embedding_model_name",
            data.get("embedding_model_name", DEFAULT_EMBEDDING_MODEL),
        )
        semantic_memory = semantic_kwargs.pop("semantic_memory", None)
        knowledge_graph = semantic_kwargs.pop("knowledge_graph", None)
        harness_params = semantic_kwargs.pop("harness_params", None)
        harness_config_path = semantic_kwargs.pop("harness_config_path", None)
        if harness_params is None and data.get("harness_params"):
            harness_params = HarnessParams.from_dict(data.get("harness_params"))
        if semantic_data and semantic_memory is None:
            semantic_memory = SemanticMemory.from_dict(semantic_data, **semantic_kwargs)

        inst = cls(
            max_history=max_history,
            max_facts=max_facts,
            decay_rate=decay_rate,
            retrieval_mode=retrieval_mode,
            session_id=session_id,
            topic_id=topic_id,
            embedding_model_name=embedding_model_name,
            semantic_memory=semantic_memory,
            knowledge_graph=knowledge_graph
            or (KnowledgeGraphMemory.from_dict(graph_data) if graph_data else None),
            harness_params=harness_params,
            harness_config_path=harness_config_path,
            **semantic_kwargs,
        )
        inst.history = [MemoryEntry(**entry) for entry in data.get("history", [])]
        inst.key_facts = [MemoryEntry(**entry) for entry in data.get("key_facts", [])]
        inst.patterns = list(data.get("patterns", []))
        inst.step_counter = data.get("step_counter", 0)
        if (
            inst.retrieval_mode == "semantic"
            and inst.semantic_memory is not None
            and not semantic_data
        ):
            for entry in inst.key_facts:
                inst.semantic_memory.add_entry(
                    inst.session_id,
                    inst.topic_id,
                    entry.content,
                    metadata={
                        "category": entry.category,
                        "relevance": entry.relevance_score,
                        "migrated_from_legacy": True,
                    },
                )
        if not graph_data:
            for entry in inst.key_facts:
                inst.knowledge_graph.add_statement(
                    inst.session_id,
                    inst.topic_id,
                    entry.content,
                )
        return inst

    def to_dict(self) -> Dict[str, Any]:
        return {
            "version": 2,
            "retrieval_mode": self.retrieval_mode,
            "session_id": self.session_id,
            "topic_id": self.topic_id,
            "max_history": self.max_history,
            "max_facts": self.max_facts,
            "decay_rate": self.decay_rate,
            "harness_params": self.harness_params.to_dict(),
            "embedding_model_name": self.embedding_model_name,
            "history": [asdict(entry) for entry in self.history],
            "key_facts": [asdict(entry) for entry in self.key_facts],
            "patterns": self.patterns,
            "step_counter": self.step_counter,
            "semantic_memory": self.semantic_memory.to_dict()
            if self.semantic_memory is not None
            else None,
            "knowledge_graph": self.knowledge_graph.to_dict(),
        }


def _graph_query_terms(query: str) -> List[str]:
    terms = []
    lowered = query.lower()
    if any(word in lowered for word in ["me", "my", "mine", "myself"]):
        terms.append("user")
    for match in re.finditer(r"\b[A-Z][a-zA-Z0-9_ -]{2,}\b", query):
        terms.append(match.group(0))
    for pattern in [
        r"about ([\w .,'-]+)",
        r"remember ([\w .,'-]+)",
        r"where do i work",
        r"what is my name",
        r"who\s+\w+\s+([\w .,'-]+)",
        r"what did ([\w .,'-]+?)\s+\w+",
    ]:
        found = re.search(pattern, lowered)
        if found:
            if found.groups():
                terms.append(found.group(1))
            else:
                terms.append("user")
    stop = {
        "who", "what", "when", "where", "why", "how", "did", "does", "do",
        "is", "are", "the", "a", "an", "discover", "discovered", "work",
    }
    for token in re.findall(r"[a-zA-Z0-9][a-zA-Z0-9'-]{2,}", lowered):
        if token not in stop:
            terms.append(token)
    deduped = []
    seen = set()
    for term in terms:
        cleaned = term.strip(" ?.,")
        if cleaned and cleaned not in seen:
            seen.add(cleaned)
            deduped.append(cleaned)
    return deduped
