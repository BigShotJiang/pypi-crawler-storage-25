"""Versioned harness registry for Smriti AI."""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import time
from pathlib import Path
from typing import Any, Dict, List

from .harness import HarnessParams, append_manifest_entry, load_harness_params, write_harness_params


DEFAULT_REGISTRY_ROOT = Path("harnesses")
ACTIVE_HARNESS_STATE = Path("configs/active_harness.json")


class HarnessRegistryError(RuntimeError):
    """Raised when a harness registry operation is invalid."""


def registry_root(path: str | Path | None = None) -> Path:
    return Path(path or os.getenv("SMRITI_HARNESS_REGISTRY", DEFAULT_REGISTRY_ROOT))


def harness_dir(harness_id: str, root: str | Path | None = None) -> Path:
    return registry_root(root) / harness_id


def list_harnesses(root: str | Path | None = None, *, include_rejected: bool = False) -> List[Dict[str, Any]]:
    """Return registry metadata for known harnesses."""

    root_path = registry_root(root)
    if not root_path.exists():
        return []
    rows = []
    for child in sorted(path for path in root_path.iterdir() if path.is_dir()):
        metadata = load_metadata(child.name, root_path)
        if metadata:
            if not include_rejected and metadata.get("production_status") == "rejected":
                continue
            rows.append(metadata)
    return rows


def load_metadata(harness_id: str, root: str | Path | None = None) -> Dict[str, Any]:
    path = harness_dir(harness_id, root) / "metadata.json"
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def load_results(harness_id: str, root: str | Path | None = None) -> Dict[str, Any]:
    path = harness_dir(harness_id, root) / "results.json"
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def load_harness(harness_id: str, root: str | Path | None = None) -> HarnessParams:
    path = harness_dir(harness_id, root) / "harness_params.yaml"
    if not path.exists():
        raise FileNotFoundError(f"Harness {harness_id!r} does not exist at {path}.")
    metadata = load_metadata(harness_id, root)
    _ensure_allowed(metadata)
    return load_harness_params(path)


def activate_harness(
    harness_id: str,
    *,
    root: str | Path | None = None,
    target_config: str | Path = "configs/harness_params.yaml",
) -> Dict[str, Any]:
    """Copy a registry harness into the active config and write active state."""

    params = load_harness(harness_id, root)
    written = write_harness_params(params, target_config)
    ACTIVE_HARNESS_STATE.parent.mkdir(parents=True, exist_ok=True)
    state = {
        "active_harness_id": harness_id,
        "activated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "config_path": str(written),
    }
    ACTIVE_HARNESS_STATE.write_text(json.dumps(state, indent=2), encoding="utf-8")
    return state


def compare_harnesses(left: str, right: str, root: str | Path | None = None) -> Dict[str, Any]:
    left_params = load_harness(left, root).to_dict()
    right_params = load_harness(right, root).to_dict()
    left_results = load_results(left, root)
    right_results = load_results(right, root)
    changes = []
    for key, value in left_params.items():
        if key == "evolution":
            continue
        if value != right_params.get(key):
            changes.append(
                {
                    "component": key,
                    "left": value,
                    "right": right_params.get(key),
                }
            )
    return {
        "left": left,
        "right": right,
        "changes": changes,
        "left_results": left_results,
        "right_results": right_results,
        "metric_deltas": _metric_deltas(left_results, right_results),
    }


def create_harness(
    harness_id: str,
    params: HarnessParams,
    *,
    parent_harness_id: str | None = None,
    results: Dict[str, Any] | None = None,
    production_status: str = "candidate",
    root: str | Path | None = None,
) -> Path:
    """Create or update a registry harness directory."""

    target = harness_dir(harness_id, root)
    target.mkdir(parents=True, exist_ok=True)
    write_harness_params(params, target / "harness_params.yaml")
    summary_metrics = (results or {}).get("metrics", results or {})
    metadata = {
        "harness_id": harness_id,
        "parent_harness_id": parent_harness_id,
        "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "git_commit": _git_commit(),
        "base_model": os.getenv("BASE_MODEL_ID", "google/gemma-4-E2B-it"),
        "benchmark_suite": "memory_retention_v1",
        "retrieval_mode": params.retrieval_mode,
        "accepted_changes": [],
        "reverted_changes": [],
        "summary_metrics": summary_metrics,
        "production_status": production_status,
    }
    (target / "metadata.json").write_text(json.dumps(metadata, indent=2, sort_keys=True), encoding="utf-8")
    (target / "results.json").write_text(json.dumps(results or {}, indent=2, sort_keys=True), encoding="utf-8")
    return target


def promote_harness(
    harness_id: str,
    status: str = "accepted",
    root: str | Path | None = None,
) -> Dict[str, Any]:
    metadata = load_metadata(harness_id, root)
    if not metadata:
        raise FileNotFoundError(harness_id)
    metadata["production_status"] = status
    metadata["promoted_at"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    path = harness_dir(harness_id, root) / "metadata.json"
    path.write_text(json.dumps(metadata, indent=2, sort_keys=True), encoding="utf-8")
    return metadata


def record_rollback_event(harness_id: str, *, reason: str = "manual_cli") -> None:
    """Record a rollback decision in the evolution manifest."""

    append_manifest_entry(
        {
            "iteration_id": f"rollback-{harness_id}-{int(time.time())}",
            "harness_id": harness_id,
            "component_changed": "active_harness",
            "old_value": "",
            "new_value": harness_id,
            "evidence_source": "manual",
            "root_cause": reason,
            "predicted_fix": "restore known-good harness",
            "predicted_metric_delta": {},
            "at_risk_regressions": [],
            "observed_metric_delta": {"rollback_recorded": 1.0},
            "verdict": "reverted",
            "config_before": {},
            "config_after": {},
        }
    )


def _ensure_allowed(metadata: Dict[str, Any]) -> None:
    status = metadata.get("production_status", "candidate")
    if status == "rejected":
        raise HarnessRegistryError("Rejected harnesses cannot be activated.")
    production = os.getenv("SMRITI_ENV", "").lower() == "production" or os.getenv("SMRITI_PRODUCTION") == "1"
    if production and status not in {"accepted", "production"}:
        raise HarnessRegistryError("Production mode only allows accepted harnesses.")


def _git_commit() -> str:
    try:
        return subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    except Exception:
        return "unknown"


def _metric_deltas(left_results: Dict[str, Any], right_results: Dict[str, Any]) -> Dict[str, float]:
    left_metrics = left_results.get("summary_metrics") or left_results.get("metrics") or left_results
    right_metrics = right_results.get("summary_metrics") or right_results.get("metrics") or right_results
    deltas: Dict[str, float] = {}
    for key in {"recall", "recall_rate", "memory_recall", "latency_ms", "p95_latency_ms", "token_overhead", "identity_drift"}:
        if key in left_metrics and key in right_metrics:
            try:
                deltas[key] = float(right_metrics[key]) - float(left_metrics[key])
            except (TypeError, ValueError):
                continue
    return deltas


def seed_registry_if_missing(root: str | Path | None = None) -> None:
    """Create a seed registry from the active config if no harnesses exist."""

    root_path = registry_root(root)
    if list_harnesses(root_path):
        return
    params = load_harness_params()
    create_harness("seed", params, production_status="accepted", root=root_path)
    evolved = HarnessParams.from_dict(params.to_dict())
    evolved.identity_threshold = max(0.15, round(evolved.identity_threshold - 0.05, 3))
    create_harness("evolved-v1", evolved, parent_harness_id="seed", production_status="candidate", root=root_path)


def copy_harness(harness_id: str, destination: str | Path, root: str | Path | None = None) -> Path:
    source = harness_dir(harness_id, root)
    if not source.exists():
        raise FileNotFoundError(harness_id)
    target = Path(destination)
    if target.exists():
        shutil.rmtree(target)
    shutil.copytree(source, target)
    return target
