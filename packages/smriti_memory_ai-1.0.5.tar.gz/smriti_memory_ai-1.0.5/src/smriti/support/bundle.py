"""Customer-safe diagnostics bundles."""

from __future__ import annotations

import json
import time
import zipfile
from pathlib import Path

from .diagnostics import collect_diagnostics, redacted_logs
from smriti.security.redaction import redact_secret


def create_diagnostics_bundle(*, request_id: str | None = None, output_dir: str | Path = "support_bundles") -> Path:
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    timestamp = time.strftime("%Y%m%d-%H%M%S", time.gmtime())
    bundle_path = out / f"smriti_diagnostics_{timestamp}.zip"
    diagnostics = collect_diagnostics(request_id=request_id)
    with zipfile.ZipFile(bundle_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("diagnostics.json", redact_secret(json.dumps(diagnostics, indent=2, sort_keys=True)))
        zf.writestr("redacted_logs.txt", redacted_logs(request_id=request_id))
        zf.writestr("health.json", redact_secret(json.dumps(diagnostics.get("health", {}), indent=2, sort_keys=True)))
        zf.writestr("config_redacted.yaml", redact_secret(json.dumps(diagnostics.get("config_summary", {}), indent=2, sort_keys=True)))
    return bundle_path


def bundle_contains_unsafe_text(bundle: str | Path, forbidden: list[str]) -> bool:
    with zipfile.ZipFile(bundle) as zf:
        for name in zf.namelist():
            text = zf.read(name).decode("utf-8", errors="ignore")
            if any(item and item in text for item in forbidden):
                return True
    return False
