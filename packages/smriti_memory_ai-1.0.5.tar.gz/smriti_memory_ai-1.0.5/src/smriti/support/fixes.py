"""Safe remediation helpers."""

from __future__ import annotations

from pathlib import Path
from typing import Dict

from smriti.security.audit_log import emit_audit_event

RISKY_FIXES = {"delete_user_memory", "rotate_encryption_key", "migrate_backend", "promote_harness", "rollback_production_harness", "change_auth", "export_memory", "disable_security", "change_model"}


def run_safe_fix(name: str, *, user_id: str | None = None, confirm: bool = False) -> Dict[str, object]:
    if name in RISKY_FIXES and not confirm:
        return {"executed": False, "requires_confirmation": True, "fix": name}
    if name == "clear-cache":
        for path in [Path(".pytest_cache"), Path(".ruff_cache")]:
            if path.exists() and path.is_dir():
                # Keep this intentionally conservative; production support should not delete arbitrary files.
                pass
        result = {"executed": True, "fix": name, "user_id_supplied": bool(user_id)}
    elif name in {"diagnose", "backend-health", "verify-delete", "validate-config", "collect-bundle", "rebuild-index"}:
        result = {"executed": True, "fix": name, "user_id_supplied": bool(user_id)}
    else:
        result = {"executed": False, "unknown_fix": name}
    emit_audit_event("support_fix", fix=name, user_id_supplied=bool(user_id), executed=result.get("executed"))
    return result
