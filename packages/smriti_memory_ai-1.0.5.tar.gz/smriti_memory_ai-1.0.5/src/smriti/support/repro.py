"""Redacted reproduction harness."""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Dict

import yaml

from smriti.security.redaction import redact_secret


def create_repro_case(bundle_path: str | Path, *, output_dir: str | Path = "repro_cases") -> Path:
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    case_id = f"case-{time.strftime('%Y%m%d-%H%M%S', time.gmtime())}"
    spec = {
        "case_id": case_id,
        "category": "unknown",
        "environment": "redacted",
        "version": "from_bundle",
        "backend_type": "redacted",
        "harness_id": "redacted",
        "retrieval_mode": "redacted",
        "model_provider": "redacted",
        "sanitized_steps": ["Reproduce with synthetic equivalent facts only."],
        "synthetic_equivalent_memory": ["Synthetic user likes coral reef research."],
        "expected_behavior": "Memory retrieval uses only the synthetic user facts.",
        "observed_behavior": "See diagnostics bundle reference.",
        "diagnostic_bundle_reference": redact_secret(str(bundle_path)),
    }
    path = out / f"{case_id}.yaml"
    path.write_text(yaml.safe_dump(spec, sort_keys=False), encoding="utf-8")
    return path


def run_repro_case(path: str | Path) -> Dict[str, object]:
    spec = yaml.safe_load(Path(path).read_text(encoding="utf-8")) or {}
    text = redact_secret(json.dumps(spec))
    return {"case_id": spec.get("case_id", "unknown"), "safe": "secret" not in text.lower(), "status": "completed"}
