"""Automatic privacy-safe error triage."""

from __future__ import annotations

from dataclasses import asdict, dataclass


@dataclass(frozen=True)
class TriageResult:
    category: str
    severity: str
    confidence: float
    suggested_runbook: str
    suggested_commands: list[str]
    safe_auto_fix_available: bool
    requires_human_review: bool


def triage_error(report: dict) -> TriageResult:
    text = " ".join(str(report.get(key, "")) for key in ("category", "summary", "steps_to_reproduce")).lower()
    if "cross-user" in text or "other user's memory" in text or "secret leak" in text:
        return _result("security_error", "P0", "runbooks/user_errors/memory_delete_failed.md", ["make security-report"], False, True)
    if "delete" in text and "fail" in text:
        return _result("memory_delete_error", "P0", "runbooks/user_errors/memory_delete_failed.md", ["smriti-cli fix verify-delete --user-id <id>"], True, True)
    if "unauthorized" in text or "invalid api key" in text or "401" in text or "403" in text:
        return _result("auth_error", "P2", "runbooks/user_errors/authentication_failed.md", ["smriti-cli security list-api-keys"], False, False)
    if "hugging face" in text or "timeout" in text or "model provider" in text:
        return _result("model_provider_error", "P1", "runbooks/user_errors/model_provider_timeout.md", ["make post-deploy-verify"], False, True)
    if "backend" in text or "redis" in text or "postgres" in text:
        return _result("backend_error", "P1", "runbooks/user_errors/backend_connection_failed.md", ["smriti-cli fix backend-health"], True, True)
    if "dashboard" in text:
        return _result("dashboard_error", "P2", "runbooks/user_errors/dashboard_not_loading.md", ["smriti-cli fix diagnose"], True, False)
    if "benchmark" in text:
        return _result("benchmark_error", "P2", "runbooks/user_errors/benchmark_result_missing.md", ["smriti-cli benchmark --quick"], True, False)
    return _result("unknown", "P3", "runbooks/user_errors/README.md", ["smriti-cli support collect-diagnostics"], False, True, confidence=0.35)


def _result(category: str, severity: str, runbook: str, commands: list[str], safe: bool, human: bool, confidence: float = 0.8) -> TriageResult:
    return TriageResult(category, severity, confidence, runbook, commands, safe, human)


def triage_asdict(report: dict) -> dict:
    return asdict(triage_error(report))
