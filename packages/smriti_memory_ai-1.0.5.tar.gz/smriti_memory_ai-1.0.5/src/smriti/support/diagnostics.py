"""Privacy-safe diagnostics collection."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict

from smriti import __version__
from smriti.config import load_config
from smriti.health import health_summary
from smriti.observability.context import git_commit
from smriti.security.redaction import redact_secret

SAFE_ENV_KEYS = ["SMRITI_ENV", "SMRITI_MEMORY_BACKEND", "SMRITI_MODEL_ADAPTER", "BASE_MODEL_ID", "SMRITI_HARNESS_ID"]


def collect_diagnostics(*, request_id: str | None = None, include_health: bool = True) -> Dict[str, Any]:
    config = load_config()
    payload: Dict[str, Any] = {
        "version": __version__,
        "git_commit": git_commit(),
        "environment": os.getenv("SMRITI_ENV", "development"),
        "active_harness_id": os.getenv("SMRITI_HARNESS_ID", "config"),
        "backend_type": config.backend,
        "retrieval_mode": os.getenv("SMRITI_RETRIEVAL_MODE", "configured"),
        "model_provider": config.model_adapter,
        "request_id": request_id or "",
        "config_summary": {
            "backend": config.backend,
            "model_adapter": config.model_adapter,
            "base_model_id": redact_secret(config.base_model_id),
            "autosave": config.autosave,
        },
        "env_summary": {key: redact_secret(os.getenv(key, "")) for key in SAFE_ENV_KEYS if os.getenv(key)},
    }
    if include_health:
        payload["health"] = health_summary()
    return payload


def redacted_logs(path: str | Path = "logs/security_audit.jsonl", *, request_id: str | None = None, limit: int = 80) -> str:
    target = Path(path)
    if not target.exists():
        return ""
    lines = target.read_text(encoding="utf-8", errors="ignore").splitlines()
    if request_id:
        lines = [line for line in lines if request_id in line]
    return "\n".join(redact_secret(line) for line in lines[-limit:])


def write_diagnostics(path: str | Path, payload: Dict[str, Any]) -> Path:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(redact_secret(json.dumps(payload, indent=2, sort_keys=True)), encoding="utf-8")
    return target
