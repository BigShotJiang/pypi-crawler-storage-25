"""User error report schema and storage."""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

from smriti.security.redaction import redact_secret
from .diagnostics import collect_diagnostics

Category = Literal["chat_error", "memory_error", "delete_error", "deployment_error", "benchmark_error", "security_error", "other"]


class ErrorReportRequest(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)
    category: Category
    summary: str = Field(min_length=1, max_length=2000)
    steps_to_reproduce: str = Field(default="", max_length=4000)
    user_id: str | None = Field(default=None, max_length=128)
    request_id: str | None = Field(default=None, max_length=128)
    include_diagnostics: bool = True


def store_error_report(report: ErrorReportRequest, *, path: str | Path = "reports/support/error_reports.jsonl") -> dict:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "category": report.category,
        "summary": redact_secret(report.summary),
        "steps_to_reproduce": redact_secret(report.steps_to_reproduce),
        "user_id_hash_only": bool(report.user_id),
        "request_id": report.request_id or "",
    }
    if report.include_diagnostics:
        payload["diagnostics"] = collect_diagnostics(request_id=report.request_id, include_health=True)
    target.open("a", encoding="utf-8").write(redact_secret(json.dumps(payload, sort_keys=True)) + "\n")
    return {"stored": True, "path": str(target), "category": report.category, "request_id": report.request_id or ""}
