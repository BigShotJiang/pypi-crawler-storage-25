"""Pydantic schema for Smriti AI harness evolution manifests."""

from __future__ import annotations

from typing import Any, Dict, List, Literal

from pydantic import BaseModel, ConfigDict, Field


Verdict = Literal["accepted", "rejected", "reverted", "pending"]


class ManifestEntry(BaseModel):
    """Strict manifest row for one falsifiable harness-evolution decision."""

    model_config = ConfigDict(extra="forbid")

    iteration_id: str
    timestamp: str
    harness_id: str
    component_changed: str
    old_value: Any
    new_value: Any
    evidence_source: str
    root_cause: str
    predicted_fix: str
    predicted_metric_delta: Dict[str, float] = Field(default_factory=dict)
    at_risk_regressions: List[str] = Field(default_factory=list)
    observed_metric_delta: Dict[str, Any] = Field(default_factory=dict)
    verdict: Verdict
    config_before: Dict[str, Any]
    config_after: Dict[str, Any]


def canonical_manifest_entry(raw: Dict[str, Any]) -> Dict[str, Any]:
    """Map legacy manifest keys into the strict canonical schema."""

    return {
        "iteration_id": str(raw.get("iteration_id") or raw.get("id") or "unknown"),
        "timestamp": str(raw.get("timestamp") or ""),
        "harness_id": str(raw.get("harness_id") or raw.get("target_harness_id") or "unknown"),
        "component_changed": str(raw.get("component_changed") or raw.get("component") or ""),
        "old_value": raw.get("old_value", raw.get("previous_value")),
        "new_value": raw.get("new_value"),
        "evidence_source": str(raw.get("evidence_source") or raw.get("evidence_summary_path") or ""),
        "root_cause": str(raw.get("root_cause") or raw.get("reason") or ""),
        "predicted_fix": str(raw.get("predicted_fix") or raw.get("predicted_impact") or ""),
        "predicted_metric_delta": raw.get("predicted_metric_delta") or {},
        "at_risk_regressions": raw.get("at_risk_regressions") or [],
        "observed_metric_delta": raw.get("observed_metric_delta") or raw.get("observed_effect") or {},
        "verdict": raw.get("verdict") or _status_to_verdict(str(raw.get("status", "pending"))),
        "config_before": raw.get("config_before") or {},
        "config_after": raw.get("config_after") or {},
    }


def _status_to_verdict(status: str) -> Verdict:
    if status in {"accepted", "manual_override"}:
        return "accepted"
    if status == "rejected":
        return "rejected"
    if status in {"reverted", "rollback"}:
        return "reverted"
    return "pending"
