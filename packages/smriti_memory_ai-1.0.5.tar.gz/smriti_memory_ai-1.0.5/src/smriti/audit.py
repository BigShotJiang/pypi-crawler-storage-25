"""Memory audit helpers for listing and managing user memories.

The audit layer intentionally works through existing Smriti backends. It is a
control plane for inspection, pinning, archiving, and deletion; it does not own
retrieval semantics or model prompting.
"""

from __future__ import annotations

import json
import re
import time
from dataclasses import asdict, dataclass
from typing import Any, Dict, Iterable, List, Mapping, MutableMapping, Optional

from .backends import JsonBackend, MemoryBackend, SqliteBackend


@dataclass
class AuditEntry:
    """A normalized memory row shown in audit APIs and dashboards."""

    entry_id: str
    user_id: str
    session_id: str
    topic_id: str
    text: str
    timestamp: float
    metadata: Dict[str, Any]
    pinned: bool = False
    archived: bool = False
    source: str = "backend"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class MemoryAuditService:
    """Inspect and mutate user-owned memory entries across supported backends."""

    def __init__(self, backend: MemoryBackend):
        self.backend = backend

    def list_entries(
        self,
        user_id: str,
        session_id: Optional[str] = None,
        topic_id: Optional[str] = None,
        query: str = "",
        include_archived: bool = False,
        limit: int = 100,
        runtime_state: Optional[Mapping[str, Any]] = None,
    ) -> List[AuditEntry]:
        """Return normalized entries scoped to one user."""

        entries: List[AuditEntry] = []
        entries.extend(self._list_backend_entries(user_id, session_id, topic_id, include_archived))
        if runtime_state:
            entries.extend(
                _entries_from_runtime_state(user_id, runtime_state, session_id, topic_id, include_archived)
            )
        entries = _dedupe_entries(entries)
        if query.strip():
            entries = _filter_query(entries, query)
        entries.sort(key=lambda entry: (entry.pinned, entry.timestamp), reverse=True)
        return entries[: max(1, limit)]

    def update_entry(
        self,
        user_id: str,
        entry_id: str,
        text: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> AuditEntry:
        """Update an entry's text or metadata in a mutable backend."""

        if isinstance(self.backend, JsonBackend) and entry_id.startswith("json:"):
            return self._update_json_entry(user_id, entry_id, text=text, metadata=metadata)
        if isinstance(self.backend, SqliteBackend) and entry_id.startswith("sqlite:"):
            return self._update_sqlite_entry(user_id, entry_id, text=text, metadata=metadata)
        raise NotImplementedError(f"Entry {entry_id!r} is not mutable for {type(self.backend).__name__}.")

    def pin_entry(self, user_id: str, entry_id: str, pinned: bool = True) -> AuditEntry:
        """Mark an entry as pinned so retrieval/ranking layers can boost it."""

        return self._set_flag(user_id, entry_id, "pinned", pinned)

    def archive_entry(self, user_id: str, entry_id: str, archived: bool = True) -> AuditEntry:
        """Move an entry to audit-visible cold storage."""

        return self._set_flag(user_id, entry_id, "archived", archived)

    def delete_entry(self, user_id: str, entry_id: str) -> bool:
        """Delete a single memory entry from a mutable backend."""

        if isinstance(self.backend, JsonBackend) and entry_id.startswith("json:"):
            state, entries, index = self._json_entry(user_id, entry_id)
            entries.pop(index)
            self.backend.save(user_id, state)
            return True
        if isinstance(self.backend, SqliteBackend) and entry_id.startswith("sqlite:"):
            row_id = _parse_numeric_id(entry_id)
            with self.backend._connect() as conn:  # noqa: SLF001 - audit is backend-adjacent.
                before = conn.total_changes
                conn.execute("DELETE FROM memory_entries WHERE id = ? AND user_id = ?", (row_id, user_id))
                return conn.total_changes > before
        raise NotImplementedError(f"Entry {entry_id!r} is not deletable for {type(self.backend).__name__}.")

    def _list_backend_entries(
        self,
        user_id: str,
        session_id: Optional[str],
        topic_id: Optional[str],
        include_archived: bool,
    ) -> List[AuditEntry]:
        if isinstance(self.backend, JsonBackend):
            state = self.backend.load(user_id) or {}
            return list(_entries_from_backend_blob(user_id, state, session_id, topic_id, include_archived))
        if isinstance(self.backend, SqliteBackend):
            clauses = ["user_id = ?"]
            params: List[Any] = [user_id]
            if session_id:
                clauses.append("session_id = ?")
                params.append(session_id)
            if topic_id:
                clauses.append("topic_id = ?")
                params.append(topic_id)
            if not include_archived:
                clauses.append("COALESCE(archived, 0) = 0")
            sql = f"""
                SELECT id, session_id, topic_id, text, metadata, created_at, pinned, archived
                FROM memory_entries
                WHERE {' AND '.join(clauses)}
                ORDER BY pinned DESC, created_at DESC
            """
            with self.backend._connect() as conn:  # noqa: SLF001 - audit is backend-adjacent.
                rows = conn.execute(sql, params).fetchall()
            return [
                AuditEntry(
                    entry_id=f"sqlite:{row[0]}",
                    user_id=user_id,
                    session_id=row[1],
                    topic_id=row[2],
                    text=row[3],
                    metadata=json.loads(row[4] or "{}"),
                    timestamp=float(row[5] or 0),
                    pinned=bool(row[6]),
                    archived=bool(row[7]),
                    source="sqlite",
                )
                for row in rows
            ]
        return [
            AuditEntry(
                entry_id=f"retrieval:{idx}",
                user_id=user_id,
                session_id=item.get("session_id", session_id or user_id),
                topic_id=item.get("topic_id", topic_id or "general"),
                text=item.get("text", ""),
                metadata=item.get("metadata", {}),
                timestamp=float(item.get("created_at", item.get("timestamp", 0)) or 0),
                pinned=bool(item.get("metadata", {}).get("pinned", False)),
                archived=bool(item.get("metadata", {}).get("archived", False)),
                source=type(self.backend).__name__,
            )
            for idx, item in enumerate(self.backend.retrieve(user_id, session_id, topic_id, k=100))
            if include_archived or not item.get("metadata", {}).get("archived", False)
        ]

    def _set_flag(self, user_id: str, entry_id: str, flag: str, value: bool) -> AuditEntry:
        if isinstance(self.backend, JsonBackend) and entry_id.startswith("json:"):
            state, entries, index = self._json_entry(user_id, entry_id)
            metadata = dict(entries[index].get("metadata", {}))
            metadata[flag] = value
            entries[index]["metadata"] = metadata
            self.backend.save(user_id, state)
            return next(_entries_from_backend_blob(user_id, state, None, None, True, only_index=index))
        if isinstance(self.backend, SqliteBackend) and entry_id.startswith("sqlite:"):
            row_id = _parse_numeric_id(entry_id)
            column = "pinned" if flag == "pinned" else "archived"
            with self.backend._connect() as conn:  # noqa: SLF001
                conn.execute(
                    f"UPDATE memory_entries SET {column} = ? WHERE id = ? AND user_id = ?",
                    (1 if value else 0, row_id, user_id),
                )
            return self._get_sqlite_entry(user_id, row_id)
        return self.update_entry(user_id, entry_id, metadata={flag: value})

    def _json_entry(
        self,
        user_id: str,
        entry_id: str,
    ) -> tuple[MutableMapping[str, Any], List[Dict[str, Any]], int]:
        state = self.backend.load(user_id) or {"backend_entries": []}
        entries = state.setdefault("backend_entries", [])
        index = _parse_numeric_id(entry_id)
        if index < 0 or index >= len(entries):
            raise KeyError(f"No JSON memory entry {entry_id!r} for {user_id!r}.")
        return state, entries, index

    def _update_json_entry(
        self,
        user_id: str,
        entry_id: str,
        text: Optional[str],
        metadata: Optional[Dict[str, Any]],
    ) -> AuditEntry:
        state, entries, index = self._json_entry(user_id, entry_id)
        if text is not None:
            entries[index]["text"] = text
        if metadata:
            merged = dict(entries[index].get("metadata", {}))
            merged.update(metadata)
            entries[index]["metadata"] = merged
        self.backend.save(user_id, state)
        return next(_entries_from_backend_blob(user_id, state, None, None, True, only_index=index))

    def _update_sqlite_entry(
        self,
        user_id: str,
        entry_id: str,
        text: Optional[str],
        metadata: Optional[Dict[str, Any]],
    ) -> AuditEntry:
        row_id = _parse_numeric_id(entry_id)
        current = self._get_sqlite_entry(user_id, row_id)
        next_text = text if text is not None else current.text
        next_metadata = dict(current.metadata)
        if metadata:
            next_metadata.update(metadata)
        with self.backend._connect() as conn:  # noqa: SLF001
            conn.execute(
                "UPDATE memory_entries SET text = ?, metadata = ? WHERE id = ? AND user_id = ?",
                (next_text, json.dumps(next_metadata), row_id, user_id),
            )
        return self._get_sqlite_entry(user_id, row_id)

    def _get_sqlite_entry(self, user_id: str, row_id: int) -> AuditEntry:
        with self.backend._connect() as conn:  # noqa: SLF001
            row = conn.execute(
                """
                SELECT id, session_id, topic_id, text, metadata, created_at, pinned, archived
                FROM memory_entries
                WHERE id = ? AND user_id = ?
                """,
                (row_id, user_id),
            ).fetchone()
        if not row:
            raise KeyError(f"No SQLite memory entry sqlite:{row_id} for {user_id!r}.")
        return AuditEntry(
            entry_id=f"sqlite:{row[0]}",
            user_id=user_id,
            session_id=row[1],
            topic_id=row[2],
            text=row[3],
            metadata=json.loads(row[4] or "{}"),
            timestamp=float(row[5] or 0),
            pinned=bool(row[6]),
            archived=bool(row[7]),
            source="sqlite",
        )


def _entries_from_backend_blob(
    user_id: str,
    state: Mapping[str, Any],
    session_id: Optional[str],
    topic_id: Optional[str],
    include_archived: bool,
    only_index: Optional[int] = None,
) -> Iterable[AuditEntry]:
    for index, item in enumerate(state.get("backend_entries", [])):
        if only_index is not None and index != only_index:
            continue
        item_session = item.get("session_id", user_id)
        item_topic = item.get("topic_id", "general")
        metadata = dict(item.get("metadata", {}))
        archived = bool(metadata.get("archived", False))
        if session_id and item_session != session_id:
            continue
        if topic_id and item_topic != topic_id:
            continue
        if archived and not include_archived:
            continue
        yield AuditEntry(
            entry_id=f"json:{index}",
            user_id=user_id,
            session_id=item_session,
            topic_id=item_topic,
            text=item.get("text", ""),
            metadata=metadata,
            timestamp=float(item.get("created_at", item.get("timestamp", 0)) or 0),
            pinned=bool(metadata.get("pinned", False)),
            archived=archived,
            source="json",
        )


def _entries_from_runtime_state(
    user_id: str,
    state: Mapping[str, Any],
    session_id: Optional[str],
    topic_id: Optional[str],
    include_archived: bool,
) -> Iterable[AuditEntry]:
    now = time.time()
    for index, fact in enumerate(state.get("key_facts", [])):
        metadata = {"category": fact.get("category", "fact")}
        archived = bool(metadata.get("archived", False))
        if archived and not include_archived:
            continue
        yield AuditEntry(
            entry_id=f"runtime:key_fact:{index}",
            user_id=user_id,
            session_id=state.get("session_id", user_id),
            topic_id=state.get("topic_id", "general"),
            text=fact.get("content", ""),
            timestamp=float(fact.get("timestamp", now) or now),
            metadata=metadata,
            pinned=False,
            archived=archived,
            source="runtime",
        )
    semantic = state.get("semantic_memory") or {}
    sessions = semantic.get("sessions", {}) if isinstance(semantic, Mapping) else {}
    for sess_id, session_data in sessions.items():
        if session_id and sess_id != session_id:
            continue
        topics = session_data.get("topics", session_data) if isinstance(session_data, Mapping) else {}
        for top_id, topic_data in topics.items():
            if topic_id and top_id != topic_id:
                continue
            raw_entries = topic_data.get("entries", topic_data) if isinstance(topic_data, Mapping) else []
            if isinstance(raw_entries, Mapping):
                raw_entries = raw_entries.get("entries", [])
            for index, item in enumerate(raw_entries or []):
                metadata = dict(item.get("metadata", {})) if isinstance(item, Mapping) else {}
                archived = bool(metadata.get("archived", False))
                if archived and not include_archived:
                    continue
                yield AuditEntry(
                    entry_id=f"runtime:semantic:{sess_id}:{top_id}:{index}",
                    user_id=user_id,
                    session_id=sess_id,
                    topic_id=top_id,
                    text=item.get("text", item.get("content", "")),
                    timestamp=float(item.get("timestamp", now) or now),
                    metadata=metadata,
                    pinned=bool(metadata.get("pinned", False)),
                    archived=archived,
                    source="runtime",
                )


def _dedupe_entries(entries: Iterable[AuditEntry]) -> List[AuditEntry]:
    seen: set[tuple[str, str, str]] = set()
    deduped: List[AuditEntry] = []
    for entry in entries:
        key = (entry.session_id, entry.topic_id, entry.text.strip().lower())
        if key in seen or not entry.text.strip():
            continue
        seen.add(key)
        deduped.append(entry)
    return deduped


def _filter_query(entries: Iterable[AuditEntry], query: str) -> List[AuditEntry]:
    terms = set(re.findall(r"[a-z0-9']+", query.lower()))
    if not terms:
        return list(entries)
    matched = []
    for entry in entries:
        haystack = f"{entry.text} {json.dumps(entry.metadata, sort_keys=True)}".lower()
        if any(term in haystack for term in terms):
            matched.append(entry)
    return matched


def _parse_numeric_id(entry_id: str) -> int:
    try:
        return int(entry_id.rsplit(":", 1)[-1])
    except ValueError as exc:
        raise KeyError(f"Invalid memory entry id {entry_id!r}.") from exc
