"""Sticky canary routing for Smriti AI harnesses."""

from __future__ import annotations

import hashlib
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict


@dataclass
class CanaryState:
    active_harness: str = "seed"
    canary_harness: str = ""
    canary_percentage: int = 0
    enabled: bool = False
    started_at: str = ""
    sticky_routes: Dict[str, str] = field(default_factory=dict)
    metrics: Dict[str, Dict[str, Any]] = field(default_factory=dict)


STATE = CanaryState()


def route_user(user_id: str) -> str:
    """Return the sticky harness route for a user."""

    if not STATE.enabled or not STATE.canary_harness or STATE.canary_percentage <= 0:
        return STATE.active_harness
    if user_id in STATE.sticky_routes:
        return STATE.sticky_routes[user_id]
    digest = hashlib.sha256(user_id.encode("utf-8")).hexdigest()
    bucket = int(digest[:8], 16) % 100
    harness_id = STATE.canary_harness if bucket < STATE.canary_percentage else STATE.active_harness
    STATE.sticky_routes[user_id] = harness_id
    return harness_id


def start_canary(active_harness: str, canary_harness: str, percentage: int) -> Dict[str, Any]:
    STATE.active_harness = active_harness
    STATE.canary_harness = canary_harness
    STATE.canary_percentage = max(0, min(100, int(percentage)))
    STATE.enabled = STATE.canary_percentage > 0 and bool(canary_harness)
    STATE.started_at = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    STATE.sticky_routes = {}
    payload = status()
    write_canary_report("started")
    return payload


def stop_canary(event: str = "stopped") -> Dict[str, Any]:
    STATE.enabled = False
    STATE.canary_percentage = 0
    STATE.canary_harness = ""
    STATE.sticky_routes = {}
    payload = status()
    write_canary_report(event)
    return payload


def promote_canary() -> Dict[str, Any]:
    if STATE.canary_harness:
        STATE.active_harness = STATE.canary_harness
    return stop_canary()


def rollback_canary(reason: str = "manual") -> Dict[str, Any]:
    rollback = STATE.metrics.setdefault("rollback", {})
    rollback["count"] = rollback.get("count", 0) + 1
    rollback["last_reason"] = reason
    return stop_canary(f"rollback:{reason}")


def record_metric(harness_id: str, latency_ms: float = 0.0, error: bool = False) -> None:
    row = STATE.metrics.setdefault(harness_id, {"requests": 0, "errors": 0, "latency_ms_total": 0.0})
    row["requests"] += 1
    row["latency_ms_total"] += latency_ms
    if error:
        row["errors"] += 1
    maybe_auto_rollback()


def status() -> Dict[str, Any]:
    payload = asdict(STATE)
    payload["routes"] = dict(STATE.sticky_routes)
    return payload


def maybe_auto_rollback() -> bool:
    """Rollback canary traffic if simple safety thresholds are violated."""

    if not STATE.enabled or not STATE.canary_harness:
        return False
    canary = STATE.metrics.get(STATE.canary_harness, {})
    active = STATE.metrics.get(STATE.active_harness, {})
    canary_requests = float(canary.get("requests", 0) or 0)
    if canary_requests < 5:
        return False
    canary_error_rate = float(canary.get("errors", 0) or 0) / canary_requests
    if canary_error_rate > 0.05:
        rollback_canary("canary_error_rate_gt_5_percent")
        return True
    active_requests = float(active.get("requests", 0) or 0)
    if active_requests >= 5:
        canary_latency = float(canary.get("latency_ms_total", 0) or 0) / canary_requests
        active_latency = float(active.get("latency_ms_total", 0) or 0) / active_requests
        if active_latency > 0 and canary_latency > active_latency * 1.25:
            rollback_canary("canary_latency_gt_25_percent")
            return True
    return False


def write_canary_report(event: str = "status", path: str | Path = "results/canary_report.md") -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    payload = status()
    lines = [
        "# Harness Canary Report",
        "",
        f"- Event: `{event}`",
        f"- Active harness: `{payload['active_harness']}`",
        f"- Canary harness: `{payload['canary_harness'] or 'none'}`",
        f"- Canary percentage: `{payload['canary_percentage']}`",
        f"- Enabled: `{payload['enabled']}`",
        "",
        "## Metrics",
        "",
        "| Harness | Requests | Errors | Avg latency ms |",
        "|---|---:|---:|---:|",
    ]
    for harness_id, row in STATE.metrics.items():
        requests = float(row.get("requests", 0) or 0)
        avg_latency = float(row.get("latency_ms_total", 0) or 0) / requests if requests else 0.0
        lines.append(f"| {harness_id} | {int(requests)} | {int(row.get('errors', 0) or 0)} | {avg_latency:.3f} |")
    lines.append("")
    target.write_text("\n".join(lines), encoding="utf-8")
