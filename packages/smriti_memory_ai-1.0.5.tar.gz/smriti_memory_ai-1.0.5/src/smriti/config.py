"""Configuration helpers for Smriti AI deployments."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml


DEFAULT_CONFIG_PATH = Path("config.yaml")


@dataclass
class SmritiConfig:
    """Runtime configuration loaded from YAML and environment variables."""

    backend: str = "json"
    memory_dir: str = "data/memory"
    sqlite_path: str = "data/smriti_memory.sqlite3"
    redis_url: str = "redis://localhost:6379/0"
    postgres_dsn: str = ""
    encryption_key: str = ""
    autosave: bool = False
    host: str = "0.0.0.0"
    port: int = 8000
    cors_origins: list[str] = field(default_factory=lambda: ["*"])
    model_adapter: str = "local_hf"
    base_model_id: str = "google/gemma-4-E2B-it"
    hf_endpoint_url: str = ""
    ollama_url: str = "http://localhost:11434"
    vllm_url: str = "http://localhost:8000"
    openai_compatible_url: str = "https://api.openai.com/v1"
    harness_config_path: str = "configs/harness_params.yaml"


def load_config(path: str | Path | None = None) -> SmritiConfig:
    """Load a Smriti AI YAML config, returning sensible defaults when absent."""

    config_path = Path(path or os.getenv("SMRITI_CONFIG_PATH") or DEFAULT_CONFIG_PATH)
    if not config_path.exists():
        return SmritiConfig()
    data = _expand_env(yaml.safe_load(config_path.read_text(encoding="utf-8")) or {})
    memory = data.get("memory", data)
    api = data.get("api", {})
    security = data.get("security", {})
    model = data.get("model", {})
    harness = data.get("harness", {})
    cors_origins = list(api.get("cors_origins", ["*"]))
    if os.getenv("SMRITI_CORS_ORIGINS"):
        cors_origins = [
            origin.strip()
            for origin in os.environ["SMRITI_CORS_ORIGINS"].split(",")
            if origin.strip()
        ] or ["*"]
    return SmritiConfig(
        backend=str(os.getenv("SMRITI_MEMORY_BACKEND", memory.get("backend", "json"))),
        memory_dir=str(os.getenv("SMRITI_MEMORY_DIR", memory.get("memory_dir", "data/memory"))),
        sqlite_path=str(
            os.getenv("SMRITI_SQLITE_PATH", memory.get("sqlite_path", "data/smriti_memory.sqlite3"))
        ),
        redis_url=str(
            os.getenv("SMRITI_REDIS_URL", memory.get("redis_url", "redis://localhost:6379/0"))
        ),
        postgres_dsn=str(os.getenv("SMRITI_POSTGRES_DSN", memory.get("postgres_dsn", ""))),
        encryption_key=str(
            os.getenv("SMRITI_MEMORY_KEY", security.get("encryption_key", memory.get("encryption_key", "")))
        ),
        autosave=_bool_env("SMRITI_AUTOSAVE", memory.get("autosave", False)),
        host=str(os.getenv("SMRITI_HOST", api.get("host", "0.0.0.0"))),
        port=int(os.getenv("SMRITI_PORT", api.get("port", 8000))),
        cors_origins=cors_origins,
        model_adapter=str(os.getenv("SMRITI_MODEL_ADAPTER", model.get("adapter", "local_hf"))),
        base_model_id=str(os.getenv("BASE_MODEL_ID", model.get("base_model_id", "google/gemma-4-E2B-it"))),
        hf_endpoint_url=str(os.getenv("HF_ENDPOINT_URL", model.get("hf_endpoint_url", ""))),
        ollama_url=str(os.getenv("OLLAMA_URL", model.get("ollama_url", "http://localhost:11434"))),
        vllm_url=str(os.getenv("VLLM_URL", model.get("vllm_url", "http://localhost:8000"))),
        openai_compatible_url=str(
            os.getenv("OPENAI_COMPATIBLE_URL", model.get("openai_compatible_url", "https://api.openai.com/v1"))
        ),
        harness_config_path=str(
            os.getenv("SMRITI_HARNESS_CONFIG", harness.get("config_path", "configs/harness_params.yaml"))
        ),
    )


def _expand_env(value: Any) -> Any:
    """Recursively expand `${VAR}` placeholders in YAML values.

    Empty unresolved placeholders intentionally become empty strings instead of
    literal secrets such as `${SMRITI_MEMORY_KEY}`. This keeps sample configs
    safe to commit while still allowing production deployments to inject secrets
    through the environment.
    """

    if isinstance(value, str):
        expanded = os.path.expandvars(value)
        if expanded == value and value.startswith("${") and value.endswith("}"):
            return ""
        return expanded
    if isinstance(value, list):
        return [_expand_env(item) for item in value]
    if isinstance(value, dict):
        return {key: _expand_env(item) for key, item in value.items()}
    return value


def _bool_env(name: str, default: Any) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return bool(default)
    return raw.lower() in {"1", "true", "yes", "on"}


def configure_environment_from_file(path: str | Path | None = None) -> SmritiConfig:
    """Apply config defaults to environment variables without overwriting users."""

    config = load_config(path)
    defaults: dict[str, Any] = {
        "SMRITI_MEMORY_BACKEND": config.backend,
        "SMRITI_MEMORY_DIR": config.memory_dir,
        "SMRITI_SQLITE_PATH": config.sqlite_path,
        "SMRITI_REDIS_URL": config.redis_url,
        "SMRITI_POSTGRES_DSN": config.postgres_dsn,
        "SMRITI_AUTOSAVE": "1" if config.autosave else "0",
        "SMRITI_HOST": config.host,
        "SMRITI_PORT": str(config.port),
        "SMRITI_CORS_ORIGINS": ",".join(config.cors_origins),
        "SMRITI_MODEL_ADAPTER": config.model_adapter,
        "BASE_MODEL_ID": config.base_model_id,
        "HF_ENDPOINT_URL": config.hf_endpoint_url,
        "OLLAMA_URL": config.ollama_url,
        "VLLM_URL": config.vllm_url,
        "OPENAI_COMPATIBLE_URL": config.openai_compatible_url,
        "SMRITI_HARNESS_CONFIG": config.harness_config_path,
    }
    if config.encryption_key:
        defaults["SMRITI_MEMORY_KEY"] = config.encryption_key
    for key, value in defaults.items():
        if value not in {"", None}:
            os.environ.setdefault(key, str(value))
    return config


def write_default_config(path: str | Path = DEFAULT_CONFIG_PATH, overwrite: bool = False) -> Path:
    """Write a customer-friendly config template."""

    config_path = Path(path)
    if config_path.exists() and not overwrite:
        return config_path
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(DEFAULT_CONFIG_YAML, encoding="utf-8")
    return config_path


DEFAULT_CONFIG_YAML = """# Smriti AI local configuration.
memory:
  # Options: json, sqlite, redis, postgres
  backend: json
  memory_dir: data/memory
  sqlite_path: data/smriti_memory.sqlite3
  redis_url: redis://localhost:6379/0
  postgres_dsn: ""
  autosave: true

security:
  # Optional Fernet-compatible secret or passphrase-derived key.
  # Prefer setting SMRITI_MEMORY_KEY in production instead of committing a key.
  encryption_key: ""

api:
  host: 0.0.0.0
  port: 8000
  cors_origins:
    - "*"

model:
  # Options: local_hf, hf_endpoint, ollama, vllm, openai
  adapter: local_hf
  base_model_id: google/gemma-4-E2B-it
  hf_endpoint_url: ""
  ollama_url: http://localhost:11434
  vllm_url: http://localhost:8000
  openai_compatible_url: https://api.openai.com/v1

harness:
  # Decoupled AHE-style memory harness parameters.
  config_path: configs/harness_params.yaml
"""
