"""Optional framework adapters for Smriti AI."""

try:
    from .langchain import SmritiMemory
except Exception:  # pragma: no cover - optional dependency surface.
    SmritiMemory = None

try:
    from .llama_index import SmritiStorageContext
except Exception:  # pragma: no cover - optional dependency surface.
    SmritiStorageContext = None

__all__ = ["SmritiMemory", "SmritiStorageContext"]
