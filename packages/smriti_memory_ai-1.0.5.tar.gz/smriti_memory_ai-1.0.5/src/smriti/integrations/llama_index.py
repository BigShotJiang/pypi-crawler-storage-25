"""LlamaIndex-style storage adapter for Smriti AI."""

from __future__ import annotations

from typing import Any

from smriti import MemPalaceLite


class SmritiStorageContext:
    """Minimal node storage/retrieval context backed by Smriti AI memory."""

    def __init__(self, memory: MemPalaceLite | None = None, session_id: str = "default", topic_id: str = "general"):
        self.session_id = session_id
        self.topic_id = topic_id
        self.memory = memory or MemPalaceLite(retrieval_mode="semantic", session_id=session_id, topic_id=topic_id)

    def add_node(self, node: Any) -> None:
        text = getattr(node, "text", None) or getattr(node, "get_content", lambda: str(node))()
        self.memory.add_fact(str(text), session_id=self.session_id, topic_id=self.topic_id)

    def query(self, query: str, k: int = 5) -> list[str]:
        context = self.memory.get_context(
            query=query,
            top_facts=k,
            session_id=self.session_id,
            topic_id=self.topic_id,
        )
        results = []
        for line in context.splitlines():
            cleaned = line.strip()
            if cleaned.startswith("* "):
                results.append(cleaned[2:].strip())
        return results

    def persist(self, path: str) -> None:
        self.memory.save(path)
