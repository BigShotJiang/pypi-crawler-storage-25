"""LangChain adapter for Smriti AI memory."""

from __future__ import annotations

from typing import Any

from smriti import MemPalaceLite


class SmritiMemory:
    """Small LangChain-compatible memory adapter.

    The class intentionally avoids a hard LangChain dependency. It implements
    the common `memory_variables`, `load_memory_variables`, `save_context`, and
    `clear` methods expected by chain-style integrations.
    """

    memory_key = "smriti_context"

    def __init__(self, memory: MemPalaceLite | None = None, session_id: str = "default", topic_id: str = "general"):
        self.session_id = session_id
        self.topic_id = topic_id
        self.memory = memory or MemPalaceLite(retrieval_mode="semantic", session_id=session_id, topic_id=topic_id)

    @property
    def memory_variables(self) -> list[str]:
        return [self.memory_key]

    def load_memory_variables(self, inputs: dict[str, Any]) -> dict[str, str]:
        query = str(inputs.get("input") or inputs.get("query") or "")
        return {
            self.memory_key: self.memory.get_context(
                query=query,
                session_id=self.session_id,
                topic_id=self.topic_id,
            )
        }

    def save_context(self, inputs: dict[str, Any], outputs: dict[str, Any]) -> None:
        text = str(inputs.get("input") or inputs.get("query") or "")
        response = str(outputs.get("output") or outputs.get("response") or "")
        for fact in self.memory.extract_facts(response, user_input=text):
            self.memory.add_fact(fact, session_id=self.session_id, topic_id=self.topic_id)
        self.memory.add_to_history("User: " + text, "user_input")
        if response:
            self.memory.add_to_history("Assistant: " + response[:200], "assistant_output")

    def clear(self) -> None:
        self.memory = MemPalaceLite(retrieval_mode=self.memory.retrieval_mode, session_id=self.session_id, topic_id=self.topic_id)
