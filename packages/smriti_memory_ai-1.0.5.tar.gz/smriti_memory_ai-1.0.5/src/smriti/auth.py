"""Compatibility shim for Smriti AI security auth helpers.

New code should import from ``smriti.security.auth`` or ``smriti.security.rbac``.
This module preserves the historical ``smriti.auth`` API.
"""

from __future__ import annotations

from .security.auth import AuthContext, auth_enabled, authenticate_request, public_paths, require_admin, require_role, require_user_access
from .security.api_keys import load_records as _load_records

PUBLIC_PATHS = public_paths()


def load_api_keys(path: str | None = None):
    """Compatibility loader returning non-secret API-key metadata by key_id."""

    return {
        record.key_id: {
            "key_id": record.key_id,
            "role": record.role,
            "user_id": record.allowed_user_ids[0] if record.allowed_user_ids else None,
            "allowed_user_ids": record.allowed_user_ids,
            "allowed_tenants": record.allowed_tenants,
            "revoked": record.revoked,
            "expires_at": record.expires_at,
        }
        for record in _load_records(path, allow_legacy_plaintext=True)
    }


__all__ = [
    "AuthContext",
    "PUBLIC_PATHS",
    "auth_enabled",
    "authenticate_request",
    "load_api_keys",
    "require_admin",
    "require_role",
    "require_user_access",
]
