"""Production health/readiness checks for Smriti AI."""

from __future__ import annotations

import os
from typing import Any, Callable, Dict

from . import __version__
from .config import load_config
from .harness import load_harness_params
from .observability.context import git_commit, safe_model_id
from .production_safety import ProductionSafetyError, validate_model_id_for_environment
from .security.auth import auth_enabled, is_production
from .security.encryption import encryption_key_configured, production_encryption_required
from .security.redaction import redact_secret


def live_status() -> Dict[str, Any]:
    return {"status": "ok", "version": __version__, "git_commit": git_commit()}


def health_summary(*, memory_users: int = 0, backend_check: Callable[[], Any] | None = None) -> Dict[str, Any]:
    config = load_config()
    backend_state = _backend_state(backend_check)
    production_validation = _production_validation(config.base_model_id)
    status = "ok"
    if backend_state == "failed" or production_validation == "fail":
        status = "failed"
    elif backend_state == "degraded":
        status = "degraded"
    try:
        harness = load_harness_params()
        active_harness_id = os.getenv("SMRITI_HARNESS_ID", "config")
        retrieval_mode = harness.memory_retrieval_mode
    except Exception:
        active_harness_id = "unavailable"
        retrieval_mode = "unavailable"
        status = "degraded" if status == "ok" else status
    payload = {
        "status": status,
        "version": __version__,
        "git_commit": git_commit(),
        "environment": os.getenv("SMRITI_ENV", "development"),
        "active_harness_id": active_harness_id,
        "retrieval_mode": retrieval_mode,
        "backend_type": config.backend,
        "model_provider": config.model_adapter,
        "model_id": safe_model_id(config.base_model_id),
        "production_validation": production_validation,
        "memory_backend": backend_state,
        "model_backend": "configured" if config.base_model_id or config.hf_endpoint_url else "degraded",
        "encryption": "enabled" if encryption_key_configured() else "disabled",
        "auth": "enabled" if auth_enabled() else "disabled",
        "delete_endpoint": "enabled",
        "memory_users": memory_users,
    }
    return _redact_payload(payload)


def ready_status(*, backend_check: Callable[[], Any] | None = None) -> Dict[str, Any]:
    payload = health_summary(backend_check=backend_check)
    ready = payload["status"] == "ok"
    if is_production():
        ready = ready and payload["auth"] == "enabled" and payload["production_validation"] == "pass"
        if production_encryption_required():
            ready = ready and payload["encryption"] == "enabled"
    payload["ready"] = ready
    payload["status"] = "ok" if ready else "failed"
    return payload


def _backend_state(backend_check: Callable[[], Any] | None) -> str:
    if backend_check is None:
        return "unknown"
    try:
        backend_check()
        return "healthy"
    except Exception:
        return "failed"


def _production_validation(base_model_id: str) -> str:
    try:
        validate_model_id_for_environment(base_model_id, context="health", allow_empty=False)
    except ProductionSafetyError:
        return "fail"
    if is_production() and not auth_enabled():
        return "fail"
    if production_encryption_required() and not encryption_key_configured():
        return "fail"
    return "pass"


def _redact_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
    return {key: redact_secret(value) for key, value in payload.items()}
