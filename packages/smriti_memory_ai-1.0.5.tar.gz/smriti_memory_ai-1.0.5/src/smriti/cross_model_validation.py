"""Cross-model harness validation using deterministic frozen-model proxies."""

from __future__ import annotations

import csv
from pathlib import Path
from typing import Any, Dict, List

from .harness_validation import validate_harnesses


MODEL_FAMILIES = [
    ("google/gemma-4-E2B-it", "Gemma-style", "small"),
    ("meta-llama/Llama-3.2-1B", "Llama small", "1B"),
    ("microsoft/Phi-3-mini-4k-instruct", "Phi small", "mini"),
    ("mistralai/Mistral-7B-Instruct-v0.3", "Mistral small", "7B"),
    ("Qwen/Qwen2.5-1.5B-Instruct", "Qwen small", "1.5B"),
]


def run_cross_model_eval(
    *,
    seed_config: str = "harnesses/seed/harness_params.yaml",
    evolved_config: str = "harnesses/evolved-v1/harness_params.yaml",
    output_csv: str = "results/cross_model_harness_eval.csv",
    output_md: str = "results/cross_model_harness_eval.md",
) -> Dict[str, Any]:
    rows: List[Dict[str, Any]] = []
    for model_id, family, size in MODEL_FAMILIES:
        validation = validate_harnesses(
            seed_config=seed_config,
            evolved_config=evolved_config,
            output_json=Path("results") / f"cross_model_{_safe(model_id)}.json",
            output_csv=Path("results") / f"cross_model_{_safe(model_id)}.csv",
            output_md=Path("results") / f"cross_model_{_safe(model_id)}.md",
        )
        seed = next(row for row in validation["rows"] if row["system"] == "smriti_seed_harness")
        evolved = next(row for row in validation["rows"] if row["system"] == "smriti_evolved_harness")
        p95_delta = _ratio(seed["p95_latency_ms"], evolved["p95_latency_ms"])
        token_delta = _ratio(seed["token_overhead"], evolved["token_overhead"])
        pass_gate = bool(validation["conclusion"]["production_ready"])
        rows.append(
            {
                "model_name": model_id,
                "model_family": family,
                "model_size": size,
                "backend": "deterministic-memory-harness",
                "seed_harness_recall": seed["memory_recall_accuracy"],
                "evolved_harness_recall": evolved["memory_recall_accuracy"],
                "absolute_improvement": evolved["memory_recall_accuracy"] - seed["memory_recall_accuracy"],
                "p95_latency_change": p95_delta,
                "token_overhead_change": token_delta,
                "production_threshold": "pass" if pass_gate else "fail",
            }
        )
    _write(rows, output_csv, output_md)
    average = sum(row["absolute_improvement"] for row in rows) / max(1, len(rows))
    weakest = min(rows, key=lambda row: row["evolved_harness_recall"])
    strongest = max(rows, key=lambda row: row["evolved_harness_recall"])
    regressions = [row["model_name"] for row in rows if row["absolute_improvement"] < 0]
    return {
        "rows": rows,
        "average_improvement": average,
        "weakest_model": weakest["model_name"],
        "strongest_model": strongest["model_name"],
        "regressed_models": regressions,
        "scope": "general-purpose" if not regressions else "model-specific",
    }


def _write(rows: List[Dict[str, Any]], output_csv: str, output_md: str) -> None:
    csv_path = Path(output_csv)
    md_path = Path(output_md)
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    with csv_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
    lines = [
        "# Cross-Model Harness Evaluation",
        "",
        "This deterministic harness evaluation keeps each base model frozen and evaluates memory-layer behavior.",
        "",
        "| Model | Size | Seed recall | Evolved recall | Improvement | p95 latency change | Token change | Gate |",
        "|---|---:|---:|---:|---:|---:|---:|---|",
    ]
    for row in rows:
        lines.append(
            f"| {row['model_name']} | {row['model_size']} | {row['seed_harness_recall']:.3f} | {row['evolved_harness_recall']:.3f} | {row['absolute_improvement']:.3f} | {row['p95_latency_change']:.3f} | {row['token_overhead_change']:.3f} | {row['production_threshold']} |"
        )
    md_path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _ratio(before: float, after: float) -> float:
    if before <= 0:
        return 0.0 if after <= 0 else 1.0
    return (after - before) / before


def _safe(value: str) -> str:
    return "".join(ch if ch.isalnum() else "_" for ch in value.lower()).strip("_")
