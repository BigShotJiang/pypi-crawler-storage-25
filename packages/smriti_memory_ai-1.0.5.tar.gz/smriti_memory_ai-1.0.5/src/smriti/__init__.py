"""
Smriti AI — Inference-time memory framework for small language models.

Smriti AI adds semantic memory, reasoning continuity, and identity
governance to any HuggingFace causal LM with zero fine-tuning. The name
comes from smriti, a Sanskrit term associated with memory and remembrance.

Features:
- Semantic memory with FAISS-based retrieval
- Knowledge graph integration
- Embedding-based identity governance (GIFP v1.0)
- Multi-user support via API and CLI

Quick start:
    from smriti import MemPalaceLite, SmritiAILite

    memory = MemPalaceLite(retrieval_mode="semantic")
    agent  = SmritiAILite(model=model, tokenizer=tokenizer)
    reply  = agent.chat("My name is Jordan and I am a marine biologist.")
"""

from .agent import BaselineGemma, GodelAILite, SmritiAILite
from .adapters import ModelAdapter, build_adapter
from .audit import AuditEntry, MemoryAuditService
from .backend_conformance import (
    BackendConformanceError,
    BackendConformanceResult,
    run_backend_conformance,
)
from .backends import (
    JsonBackend,
    MemoryBackend,
    MemoryCipher,
    PostgresBackend,
    RedisBackend,
    SqliteBackend,
    build_backend,
)
from .config import SmritiConfig, configure_environment_from_file, load_config, write_default_config
from .core import MemoryEntry, MemPalaceLite
from .gifp import GIFPLite
from .harness import (
    HarnessParams,
    append_manifest_entry,
    apply_harness_to_memory,
    load_harness_params,
    load_manifest,
    write_harness_params,
)
from .macp import MACPLite, ReasoningStep

# New modules for enhanced functionality
try:
    from .semantic_memory import (
        RetrievalResult,
        SemanticMemory,
        MemoryEntry as SemanticMemoryEntry,
    )
except ImportError:
    RetrievalResult = None
    SemanticMemory = None
    SemanticMemoryEntry = None

try:
    from .knowledge_graph import GraphTriple, KnowledgeGraphMemory
except ImportError:
    GraphTriple = None
    KnowledgeGraphMemory = None

try:
    from .identity_fingerprint import IdentityCheck, IdentityFingerprint
except ImportError:
    IdentityCheck = None
    IdentityFingerprint = None

__version__ = "1.0.5"
__author__ = "Alton Lee Wei Bin (creator35lwb)"

__all__ = [
    "MemoryEntry",
    "MemPalaceLite",
    "ReasoningStep",
    "MACPLite",
    "GIFPLite",
    "SmritiAILite",
    "GodelAILite",
    "BaselineGemma",
    "ModelAdapter",
    "build_adapter",
    "AuditEntry",
    "MemoryAuditService",
    "MemoryBackend",
    "MemoryCipher",
    "BackendConformanceError",
    "BackendConformanceResult",
    "run_backend_conformance",
    "JsonBackend",
    "SqliteBackend",
    "RedisBackend",
    "PostgresBackend",
    "build_backend",
    "SmritiConfig",
    "load_config",
    "configure_environment_from_file",
    "write_default_config",
    "HarnessParams",
    "load_harness_params",
    "write_harness_params",
    "apply_harness_to_memory",
    "append_manifest_entry",
    "load_manifest",
]

# Add new classes if available
if SemanticMemory is not None:
    __all__.extend(["SemanticMemory", "SemanticMemoryEntry", "RetrievalResult"])
if KnowledgeGraphMemory is not None:
    __all__.extend(["KnowledgeGraphMemory", "GraphTriple"])
if IdentityFingerprint is not None:
    __all__.extend(["IdentityFingerprint", "IdentityCheck"])
__all__.extend(["api_app", "create_app", "get_memory", "set_agent_factory", "set_memory_backend", "cli_main"])


def __getattr__(name: str):
    """Lazy optional API/CLI exports without double-registering Prometheus metrics."""

    if name in {"api_app", "create_app", "get_memory", "set_agent_factory", "set_memory_backend"}:
        from .api import app as api_app
        from .api import create_app, get_memory, set_agent_factory, set_memory_backend

        values = {
            "api_app": api_app,
            "create_app": create_app,
            "get_memory": get_memory,
            "set_agent_factory": set_agent_factory,
            "set_memory_backend": set_memory_backend,
        }
        return values[name]
    if name == "cli_main":
        from .cli import main as cli_main

        return cli_main
    raise AttributeError(name)
