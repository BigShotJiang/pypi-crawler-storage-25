"""Privacy-safe product telemetry for Smriti AI."""

from .collector import TelemetryCollector
from .events import TelemetryEvent, make_event
from .privacy import deployment_id, sanitize_properties, stable_hash, telemetry_enabled

__all__ = [
    "TelemetryCollector",
    "TelemetryEvent",
    "deployment_id",
    "make_event",
    "sanitize_properties",
    "stable_hash",
    "telemetry_enabled",
]
