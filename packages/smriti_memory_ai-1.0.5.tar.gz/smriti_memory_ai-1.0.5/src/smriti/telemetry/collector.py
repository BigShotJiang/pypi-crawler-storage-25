"""Privacy-safe telemetry collector for Smriti AI."""

from __future__ import annotations

import json
import os
import urllib.request
from pathlib import Path
from typing import Any

from smriti.security.redaction import redact_secret

from .events import TelemetryEvent, make_event
from .privacy import telemetry_enabled


class TelemetryCollector:
    """Collects metadata-only telemetry and never blocks the app on failures."""

    def __init__(self, endpoint: str | None = None, enabled: bool | None = None) -> None:
        self.endpoint = endpoint if endpoint is not None else os.getenv("SMRITI_TELEMETRY_ENDPOINT", "")
        self.enabled = telemetry_enabled() if enabled is None else enabled
        self.local_events: list[dict[str, Any]] = []

    def emit(self, event: TelemetryEvent) -> bool:
        payload = event.to_dict()
        self.local_events.append(payload)
        if not self.enabled:
            return False
        if not self.endpoint:
            return False
        try:
            body = json.dumps(payload).encode("utf-8")
            request = urllib.request.Request(
                self.endpoint,
                data=body,
                headers={"content-type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(request, timeout=2.0):
                return True
        except Exception:
            return False

    def emit_event(self, event_type: str, **kwargs: Any) -> bool:
        return self.emit(make_event(event_type, **kwargs))

    def write_local_debug(self, path: str | Path) -> Path:
        target = Path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(redact_secret(json.dumps(self.local_events, indent=2)), encoding="utf-8")
        return target
