"""Privacy controls for Smriti AI telemetry.

Telemetry is intentionally metadata-only. User prompts, memory text, graph fact
text, embeddings, secrets, and raw user identifiers are dropped or hashed before
an event can leave the process.
"""

from __future__ import annotations

import hashlib
import os
from typing import Any

from smriti.security.redaction import contains_secret, redact_secret

DENIED_KEYS = {
    "prompt",
    "message",
    "user_message",
    "memory",
    "memory_text",
    "raw_memory",
    "graph_fact",
    "graph_fact_text",
    "embedding",
    "embeddings",
    "api_key",
    "token",
    "secret",
    "password",
    "dsn",
    "connection_string",
    "hf_token",
    "redis_url",
    "postgres_dsn",
}
HASHED_KEYS = {"user_id", "tenant_id", "session_id", "deployment_id"}
ALLOWED_EVENT_TYPES = {
    "server_started",
    "chat_request_completed",
    "memory_written",
    "memory_retrieved",
    "memory_deleted",
    "harness_promoted",
    "harness_rolled_back",
    "production_gate_passed",
    "production_gate_failed",
    "benchmark_completed",
    "security_event_detected",
}


def stable_hash(value: str | None) -> str | None:
    """Return a stable non-reversible identifier for privacy-safe telemetry."""

    if not value:
        return None
    salt = os.getenv("SMRITI_TELEMETRY_SALT", "smriti-ai-telemetry")
    return hashlib.sha256(f"{salt}:{value}".encode("utf-8")).hexdigest()[:16]


def deployment_id() -> str:
    """Return an anonymized deployment identifier."""

    configured = os.getenv("SMRITI_DEPLOYMENT_ID") or os.getenv("HOSTNAME") or "local"
    return stable_hash(configured) or "unknown"


def sanitize_properties(properties: dict[str, Any] | None) -> dict[str, Any]:
    """Drop unsafe telemetry fields and redact suspicious values."""

    clean: dict[str, Any] = {}
    for key, value in (properties or {}).items():
        normalized = key.lower()
        if normalized in DENIED_KEYS:
            continue
        if normalized in HASHED_KEYS:
            hashed = stable_hash(str(value))
            if hashed:
                clean[f"{normalized}_hash"] = hashed
            continue
        if isinstance(value, (dict, list, tuple, set)):
            text = redact_secret(value)
            if contains_secret(text):
                continue
            clean[normalized] = text[:500]
            continue
        text = redact_secret(value)
        if contains_secret(text):
            continue
        clean[normalized] = text
    return clean


def telemetry_enabled() -> bool:
    return os.getenv("SMRITI_TELEMETRY_ENABLED", "false").strip().lower() in {"1", "true", "yes"}
