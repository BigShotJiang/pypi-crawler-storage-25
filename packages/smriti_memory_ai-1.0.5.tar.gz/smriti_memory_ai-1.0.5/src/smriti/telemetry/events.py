"""Telemetry event model for Smriti AI."""

from __future__ import annotations

import time
from dataclasses import asdict, dataclass, field
from typing import Any

from .privacy import ALLOWED_EVENT_TYPES, deployment_id, sanitize_properties


@dataclass(slots=True)
class TelemetryEvent:
    """A privacy-safe product telemetry event."""

    event_type: str
    timestamp: str
    deployment_id: str
    version: str
    harness_id: str | None = None
    backend_type: str | None = None
    retrieval_mode: str | None = None
    latency_ms: float | None = None
    token_count_input: int | None = None
    token_count_output: int | None = None
    memory_count: int | None = None
    error_class: str | None = None
    deletion_success: bool | None = None
    production_validation_status: str | None = None
    properties: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["properties"] = sanitize_properties(payload.get("properties"))
        return {key: value for key, value in payload.items() if value is not None}


def make_event(event_type: str, **kwargs: Any) -> TelemetryEvent:
    """Create a telemetry event, rejecting unknown event names."""

    if event_type not in ALLOWED_EVENT_TYPES:
        raise ValueError(f"Unsupported telemetry event type: {event_type}")
    from smriti import __version__

    return TelemetryEvent(
        event_type=event_type,
        timestamp=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        deployment_id=deployment_id(),
        version=__version__,
        **kwargs,
    )
