"""Small stdlib HTTP helpers for provider adapters."""

from __future__ import annotations

import json
import urllib.error
import urllib.request
from typing import Any, Dict, Mapping, Optional


class AdapterHTTPError(RuntimeError):
    """Raised when a provider endpoint returns an invalid response."""


def post_json(url: str, payload: Mapping[str, Any], headers: Optional[Dict[str, str]] = None, timeout: float = 60.0) -> Any:
    body = json.dumps(payload).encode("utf-8")
    request = urllib.request.Request(
        url,
        data=body,
        headers={"content-type": "application/json", **(headers or {})},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:  # noqa: S310 - user-configured endpoint.
            raw = response.read().decode("utf-8")
    except urllib.error.HTTPError as exc:
        raise AdapterHTTPError(f"Provider returned HTTP {exc.code}: {exc.reason}") from exc
    except urllib.error.URLError as exc:
        raise AdapterHTTPError(f"Provider request failed: {exc.reason}") from exc
    try:
        return json.loads(raw)
    except json.JSONDecodeError as exc:
        raise AdapterHTTPError("Provider response was not valid JSON.") from exc


def first_text(payload: Any) -> str:
    """Extract text from common inference response shapes."""

    if isinstance(payload, str):
        return payload
    if isinstance(payload, list) and payload:
        return first_text(payload[0])
    if isinstance(payload, dict):
        for key in ("generated_text", "text", "response", "output"):
            if key in payload:
                return str(payload[key])
        choices = payload.get("choices")
        if isinstance(choices, list) and choices:
            choice = choices[0]
            if isinstance(choice, dict):
                if "text" in choice:
                    return str(choice["text"])
                message = choice.get("message")
                if isinstance(message, dict) and "content" in message:
                    return str(message["content"])
        outputs = payload.get("outputs")
        if isinstance(outputs, list) and outputs:
            return first_text(outputs[0])
    return str(payload)
