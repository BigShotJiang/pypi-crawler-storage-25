"""Local Hugging Face Transformers adapter."""

from __future__ import annotations

import os
from typing import Any, Optional

from .base import ModelAdapter


class HuggingFaceLocalAdapter(ModelAdapter):
    """Generate with a local `transformers` causal LM."""

    name = "local_hf"

    def __init__(
        self,
        model: Any | None = None,
        tokenizer: Any | None = None,
        model_id: str | None = None,
        device: str | None = None,
        **_: Any,
    ):
        self.model = model
        self.tokenizer = tokenizer
        self.model_id = model_id or os.getenv("BASE_MODEL_ID", "google/gemma-4-E2B-it")
        self.device = device or os.getenv("SMRITI_DEVICE", "auto")
        if self.model is None or self.tokenizer is None:
            self._load()

    def _load(self) -> None:
        try:
            import torch
            from transformers import AutoModelForCausalLM, AutoTokenizer
        except Exception as exc:  # pragma: no cover - optional ML stack.
            raise RuntimeError("Install smriti-memory-ai[ml] to use HuggingFaceLocalAdapter.") from exc
        selected_device = self.device
        if selected_device == "auto":
            selected_device = "cuda" if torch.cuda.is_available() else "cpu"
        dtype = torch.float32
        if selected_device == "cuda":
            dtype = torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16
        self.tokenizer = AutoTokenizer.from_pretrained(self.model_id)
        if self.tokenizer.pad_token_id is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
        try:
            self.model = AutoModelForCausalLM.from_pretrained(self.model_id, dtype=dtype)
        except TypeError:
            self.model = AutoModelForCausalLM.from_pretrained(self.model_id, torch_dtype=dtype)
        self.model.to(selected_device)
        self.model.eval()
        self.device = selected_device

    def generate(self, prompt: str, **kwargs: Any) -> str:
        import torch

        max_new_tokens = int(kwargs.get("max_new_tokens", 256))
        inputs = self.tokenizer(prompt, return_tensors="pt", truncation=True, max_length=4096)
        inputs = {key: value.to(self.model.device) for key, value in inputs.items()}
        with torch.inference_mode():
            output = self.model.generate(
                **inputs,
                max_new_tokens=max_new_tokens,
                temperature=float(kwargs.get("temperature", 0.7)),
                top_p=float(kwargs.get("top_p", 0.9)),
                do_sample=bool(kwargs.get("do_sample", False)),
                pad_token_id=self.tokenizer.eos_token_id,
            )
        generated = output[0][inputs["input_ids"].shape[-1] :]
        return self.tokenizer.decode(generated, skip_special_tokens=True).strip()

    def get_tokenizer(self) -> Optional[Any]:
        return self.tokenizer
