"""Ollama REST adapter."""

from __future__ import annotations

import os
from typing import Any

from .base import ModelAdapter
from .http import first_text, post_json


class OllamaAdapter(ModelAdapter):
    name = "ollama"

    def __init__(self, url: str | None = None, model: str | None = None, timeout: float = 120.0, **_: Any):
        self.url = (url or os.getenv("OLLAMA_URL", "http://localhost:11434")).rstrip("/")
        self.model = model or os.getenv("OLLAMA_MODEL", "gemma3:4b")
        self.timeout = timeout

    def generate(self, prompt: str, **kwargs: Any) -> str:
        payload = {
            "model": self.model,
            "prompt": prompt,
            "stream": False,
            "options": {
                "temperature": float(kwargs.get("temperature", 0.7)),
                "top_p": float(kwargs.get("top_p", 0.9)),
                "num_predict": int(kwargs.get("max_new_tokens", 256)),
            },
        }
        return first_text(post_json(f"{self.url}/api/generate", payload, timeout=self.timeout))
