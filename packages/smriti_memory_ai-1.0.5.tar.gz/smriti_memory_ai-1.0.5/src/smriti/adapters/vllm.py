"""vLLM server adapter."""

from __future__ import annotations

import os
from typing import Any

from .base import ModelAdapter
from .http import first_text, post_json


class VLLMAdapter(ModelAdapter):
    name = "vllm"

    def __init__(self, url: str | None = None, model: str | None = None, timeout: float = 120.0, **_: Any):
        self.url = (url or os.getenv("VLLM_URL", "http://localhost:8000")).rstrip("/")
        self.model = model or os.getenv("VLLM_MODEL", os.getenv("BASE_MODEL_ID", "google/gemma-4-E2B-it"))
        self.timeout = timeout

    def generate(self, prompt: str, **kwargs: Any) -> str:
        payload = {
            "model": self.model,
            "prompt": prompt,
            "max_tokens": int(kwargs.get("max_new_tokens", 256)),
            "temperature": float(kwargs.get("temperature", 0.7)),
            "top_p": float(kwargs.get("top_p", 0.9)),
        }
        return first_text(post_json(f"{self.url}/generate", payload, timeout=self.timeout))
