"""OpenAI-compatible chat completions adapter."""

from __future__ import annotations

import os
from typing import Any

from .base import ModelAdapter
from .http import first_text, post_json


class OpenAICompatibleAdapter(ModelAdapter):
    name = "openai_compatible"

    def __init__(
        self,
        base_url: str | None = None,
        api_key: str | None = None,
        model: str | None = None,
        timeout: float = 120.0,
        **_: Any,
    ):
        self.base_url = (base_url or os.getenv("OPENAI_COMPATIBLE_URL", "https://api.openai.com/v1")).rstrip("/")
        self.api_key = api_key or os.getenv("OPENAI_API_KEY", "")
        self.model = model or os.getenv("OPENAI_MODEL", os.getenv("BASE_MODEL_ID", "gpt-4.1-mini"))
        self.timeout = timeout

    def generate(self, prompt: str, **kwargs: Any) -> str:
        headers = {"authorization": f"Bearer {self.api_key}"} if self.api_key else {}
        payload = {
            "model": self.model,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": int(kwargs.get("max_new_tokens", 256)),
            "temperature": float(kwargs.get("temperature", 0.7)),
            "top_p": float(kwargs.get("top_p", 0.9)),
        }
        return first_text(post_json(f"{self.base_url}/chat/completions", payload, headers=headers, timeout=self.timeout))
