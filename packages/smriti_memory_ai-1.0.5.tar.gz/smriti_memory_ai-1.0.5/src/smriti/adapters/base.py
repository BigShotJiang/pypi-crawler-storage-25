"""Model/provider adapter interface for Smriti AI."""

from __future__ import annotations

import os
from abc import ABC, abstractmethod
from typing import Any, Optional


class ModelAdapter(ABC):
    """Minimal generation contract used by Smriti's inference wrapper."""

    name: str = "base"

    @abstractmethod
    def generate(self, prompt: str, **kwargs: Any) -> str:
        """Generate text for an already-augmented prompt."""

    def get_tokenizer(self) -> Optional[Any]:
        """Return a tokenizer-like object when available."""

        return None


def build_adapter(kind: str | None = None, **kwargs: Any) -> ModelAdapter:
    """Build a provider adapter from config/environment variables."""

    selected = (kind or os.getenv("SMRITI_MODEL_ADAPTER") or "local_hf").lower()
    if selected in {"local_hf", "huggingface", "hf-local"}:
        from .huggingface_local import HuggingFaceLocalAdapter

        return HuggingFaceLocalAdapter(**kwargs)
    if selected in {"hf_endpoint", "huggingface_endpoint", "hf-endpoint"}:
        from .hf_endpoint import HuggingFaceEndpointAdapter

        return HuggingFaceEndpointAdapter(**kwargs)
    if selected == "ollama":
        from .ollama import OllamaAdapter

        return OllamaAdapter(**kwargs)
    if selected == "vllm":
        from .vllm import VLLMAdapter

        return VLLMAdapter(**kwargs)
    if selected in {"openai", "openai_compatible", "openai-compatible"}:
        from .openai_compatible import OpenAICompatibleAdapter

        return OpenAICompatibleAdapter(**kwargs)
    raise ValueError(
        "SMRITI_MODEL_ADAPTER must be one of: local_hf, hf_endpoint, ollama, vllm, openai."
    )
