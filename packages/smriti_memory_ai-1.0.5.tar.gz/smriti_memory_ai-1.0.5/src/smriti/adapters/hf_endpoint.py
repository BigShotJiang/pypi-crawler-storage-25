"""Hugging Face Inference Endpoint adapter."""

from __future__ import annotations

import os
from typing import Any

from .base import ModelAdapter
from .http import first_text, post_json


class HuggingFaceEndpointAdapter(ModelAdapter):
    name = "hf_endpoint"

    def __init__(self, endpoint_url: str | None = None, token: str | None = None, timeout: float = 120.0, **_: Any):
        self.endpoint_url = endpoint_url or os.getenv("HF_ENDPOINT_URL", "")
        self.token = token or os.getenv("HF_TOKEN", "")
        self.timeout = timeout
        if not self.endpoint_url:
            raise ValueError("HF_ENDPOINT_URL is required for HuggingFaceEndpointAdapter.")

    def generate(self, prompt: str, **kwargs: Any) -> str:
        headers = {"authorization": f"Bearer {self.token}"} if self.token else {}
        payload = {
            "inputs": prompt,
            "parameters": {
                "max_new_tokens": int(kwargs.get("max_new_tokens", 256)),
                "temperature": float(kwargs.get("temperature", 0.7)),
                "top_p": float(kwargs.get("top_p", 0.9)),
            },
        }
        return first_text(post_json(self.endpoint_url, payload, headers=headers, timeout=self.timeout))
