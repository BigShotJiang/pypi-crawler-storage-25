"""Observable harness configuration for Smriti AI memory behaviour.

The base model remains frozen. This module makes the surrounding inference
harness editable, measurable, and reversible: retrieval parameters, graph
depth, memory compression thresholds, and identity drift thresholds are stored
as plain YAML and every automated/manual change can be logged to a JSONL
manifest.
"""

from __future__ import annotations

import json
import os
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

import yaml


VALID_RETRIEVAL_MODES = {
    "tfidf",
    "semantic",
    "semantic_graph",
    "semantic_graph_identity",
}
DEFAULT_HARNESS_CONFIG_PATH = Path("configs/harness_params.yaml")
DEFAULT_EVOLUTION_MANIFEST_PATH = Path("manifests/evolve_manifest.jsonl")


class HarnessConfigError(ValueError):
    """Raised when strict harness validation rejects a configuration."""


@dataclass
class HarnessParams:
    """Configurable Smriti AI harness knobs used outside model weights."""

    retrieval_mode: str = "semantic_graph_identity"
    top_k: int = 5
    decay_lambda: float = 0.05
    use_graph: bool = True
    graph_depth: int = 2
    graph_weight: float = 1.0
    enable_identity: bool = True
    identity_threshold: float = 0.35
    summarisation_threshold: int = 200
    max_entries_per_topic: int = 200
    latency_budget_ms: float = 750.0
    recall_target: float = 1.0
    consistency_target: float = 0.85
    drift_target: float = 0.10
    evolution: Dict[str, Any] = field(
        default_factory=lambda: {
            "top_k_min": 1,
            "top_k_max": 12,
            "graph_depth_min": 1,
            "graph_depth_max": 4,
            "identity_threshold_min": 0.15,
            "identity_threshold_max": 0.65,
            "decay_lambda_min": 0.0,
            "decay_lambda_max": 0.25,
            "summarisation_threshold_min": 20,
            "summarisation_threshold_max": 1000,
        }
    )

    @property
    def memory_retrieval_mode(self) -> str:
        """Return the low-level memory store mode understood by MemPalaceLite."""

        return "tfidf" if self.retrieval_mode == "tfidf" else "semantic"

    @property
    def graph_enabled(self) -> bool:
        return bool(self.use_graph or "graph" in self.retrieval_mode)

    @property
    def identity_enabled(self) -> bool:
        return bool(self.enable_identity and "identity" in self.retrieval_mode)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any] | None) -> "HarnessParams":
        raw = dict(data or {})
        params = cls()
        allowed = set(params.to_dict())
        values = {key: value for key, value in raw.items() if key in allowed}
        if "evolution" in values:
            merged = dict(params.evolution)
            merged.update(values["evolution"] or {})
            values["evolution"] = merged
        inst = cls(**values)
        inst.retrieval_mode = _normalise_retrieval_mode(inst.retrieval_mode)
        inst.top_k = max(1, int(inst.top_k))
        inst.decay_lambda = max(0.0, float(inst.decay_lambda))
        inst.graph_depth = max(1, int(inst.graph_depth))
        inst.graph_weight = max(0.0, float(inst.graph_weight))
        inst.identity_threshold = max(0.0, float(inst.identity_threshold))
        inst.summarisation_threshold = max(1, int(inst.summarisation_threshold))
        inst.max_entries_per_topic = max(1, int(inst.max_entries_per_topic))
        inst.latency_budget_ms = max(1.0, float(inst.latency_budget_ms))
        inst.recall_target = _clamp(float(inst.recall_target), 0.0, 1.0)
        inst.consistency_target = _clamp(float(inst.consistency_target), 0.0, 1.0)
        inst.drift_target = _clamp(float(inst.drift_target), 0.0, 1.0)
        return inst


def resolve_harness_config_path(path: str | Path | None = None) -> Path:
    """Resolve the harness YAML path from argument, env, cwd, or repo root."""

    if path:
        return Path(path)
    if os.getenv("SMRITI_HARNESS_ID"):
        registry_root = Path(os.getenv("SMRITI_HARNESS_REGISTRY", "harnesses"))
        candidate = registry_root / os.environ["SMRITI_HARNESS_ID"] / "harness_params.yaml"
        if candidate.exists():
            return candidate
    if os.getenv("SMRITI_HARNESS_CONFIG"):
        return Path(os.environ["SMRITI_HARNESS_CONFIG"])
    cwd_candidate = Path.cwd() / DEFAULT_HARNESS_CONFIG_PATH
    if cwd_candidate.exists():
        return cwd_candidate
    repo_candidate = Path(__file__).resolve().parents[2] / DEFAULT_HARNESS_CONFIG_PATH
    if repo_candidate.exists():
        return repo_candidate
    package_candidate = Path(__file__).resolve().parent / "configs" / "harness_params.yaml"
    if package_candidate.exists():
        return package_candidate
    return DEFAULT_HARNESS_CONFIG_PATH


def load_harness_params(
    path: str | Path | None = None,
    *,
    strict: bool = False,
    production: bool = False,
) -> HarnessParams:
    """Load harness parameters, returning defaults when the YAML is absent.

    Normal local usage remains forgiving. CI, production gates, and security
    tests can pass ``strict=True`` to reject invalid values before they are
    normalised.
    """

    config_path = resolve_harness_config_path(path)
    if not config_path.exists():
        params = HarnessParams()
    else:
        data = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
        if strict:
            _validate_raw_harness_dict(data)
        params = HarnessParams.from_dict(data)
    params = _apply_env_overrides(params, strict=strict)
    if strict:
        validate_harness_params(params, production=production)
    return params


def write_harness_params(
    params: HarnessParams | Dict[str, Any],
    path: str | Path | None = None,
) -> Path:
    """Persist harness parameters as stable, reviewable YAML."""

    if path is None and not os.getenv("SMRITI_HARNESS_CONFIG"):
        config_path = Path.cwd() / DEFAULT_HARNESS_CONFIG_PATH
    else:
        config_path = resolve_harness_config_path(path)
    config_path.parent.mkdir(parents=True, exist_ok=True)
    normalised = params if isinstance(params, HarnessParams) else HarnessParams.from_dict(params)
    config_path.write_text(
        yaml.safe_dump(normalised.to_dict(), sort_keys=False),
        encoding="utf-8",
    )
    return config_path


def apply_harness_to_memory(memory: Any, params: HarnessParams | None = None) -> None:
    """Apply harness settings to an existing MemPalaceLite-compatible object."""

    harness = params or load_harness_params()
    memory.retrieval_mode = harness.memory_retrieval_mode
    memory.decay_rate = harness.decay_lambda
    memory.default_top_k = harness.top_k
    memory.include_graph_default = harness.graph_enabled
    memory.graph_depth = harness.graph_depth
    memory.graph_weight = harness.graph_weight
    memory.summarisation_threshold = harness.summarisation_threshold
    memory.max_entries_per_topic = harness.max_entries_per_topic
    if getattr(memory, "semantic_memory", None) is not None:
        memory.semantic_memory.decay_rate = harness.decay_lambda
        memory.semantic_memory.max_entries_per_topic = harness.max_entries_per_topic


def manifest_path(path: str | Path | None = None) -> Path:
    if path:
        return Path(path)
    if os.getenv("SMRITI_EVOLVE_MANIFEST"):
        return Path(os.environ["SMRITI_EVOLVE_MANIFEST"])
    return Path.cwd() / DEFAULT_EVOLUTION_MANIFEST_PATH


def append_manifest_entry(
    entry: Dict[str, Any],
    path: str | Path | None = None,
) -> Path:
    """Append one auditable harness evolution event to a JSONL manifest."""

    target = manifest_path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        **entry,
    }
    with target.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(payload, sort_keys=True) + "\n")
    return target


def load_manifest(path: str | Path | None = None, limit: Optional[int] = None) -> List[Dict[str, Any]]:
    """Read the evolution manifest, ignoring malformed historical lines."""

    target = manifest_path(path)
    if not target.exists():
        return []
    rows: List[Dict[str, Any]] = []
    for line in target.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            rows.append(json.loads(line))
        except json.JSONDecodeError:
            rows.append({"malformed": True, "raw": line[:500]})
    if limit is not None:
        return rows[-limit:]
    return rows


def build_manifest_entry(
    *,
    component: str,
    previous_value: Any,
    new_value: Any,
    reason: str,
    predicted_impact: str,
    config_before: HarnessParams,
    config_after: HarnessParams,
    evidence_summary_path: str | Path | None = None,
    actor: str = "evolve_harness",
    status: str = "proposed",
    observed_effect: Optional[Dict[str, Any]] = None,
    iteration_id: str = "",
    predicted_metric_delta: Optional[Dict[str, float]] = None,
    at_risk_regressions: Optional[List[str]] = None,
    harness_id: str | None = None,
) -> Dict[str, Any]:
    """Create a consistent manifest row for automated or manual edits."""

    observed = observed_effect or {}
    verdict = _status_to_verdict(status)
    return {
        "iteration_id": iteration_id or f"{actor}-{int(time.time())}",
        "harness_id": harness_id or os.getenv("SMRITI_HARNESS_ID", "unknown"),
        "actor": actor,
        "component": component,
        "component_changed": component,
        "previous_value": previous_value,
        "old_value": previous_value,
        "new_value": new_value,
        "reason": reason,
        "root_cause": reason,
        "predicted_impact": predicted_impact,
        "predicted_fix": predicted_impact,
        "predicted_metric_delta": predicted_metric_delta or {},
        "at_risk_regressions": at_risk_regressions or ["latency", "token_overhead", "identity_false_positives"],
        "status": status,
        "verdict": verdict,
        "evidence_summary_path": str(evidence_summary_path) if evidence_summary_path else "",
        "evidence_source": str(evidence_summary_path) if evidence_summary_path else "",
        "observed_effect": observed_effect or {},
        "observed_metric_delta": observed,
        "config_before": config_before.to_dict(),
        "config_after": config_after.to_dict(),
    }


def diff_params(before: HarnessParams, after: HarnessParams) -> List[Dict[str, Any]]:
    """Return changed scalar parameter fields for dashboard/audit display."""

    before_data = before.to_dict()
    after_data = after.to_dict()
    changes = []
    for key in before_data:
        if key == "evolution":
            continue
        if before_data[key] != after_data[key]:
            changes.append(
                {
                    "component": key,
                    "previous_value": before_data[key],
                    "new_value": after_data[key],
                }
            )
    return changes


def update_params(params: HarnessParams, updates: Dict[str, Any]) -> HarnessParams:
    """Return a new HarnessParams instance with typed user/script updates."""

    data = params.to_dict()
    for key, value in updates.items():
        if key not in data:
            continue
        data[key] = _coerce_value(data[key], value)
    return HarnessParams.from_dict(data)


def format_manifest_rows(rows: Iterable[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Prepare manifest rows for lightweight UIs."""

    formatted = []
    for index, row in enumerate(rows):
        formatted.append(
            {
                "index": index,
                "timestamp": row.get("timestamp", ""),
                "component": row.get("component") or row.get("component_changed", ""),
                "previous_value": row.get("previous_value", row.get("old_value", "")),
                "new_value": row.get("new_value", ""),
                "reason": row.get("reason", ""),
                "predicted_impact": row.get("predicted_impact") or row.get("predicted_fix", ""),
                "status": row.get("status") or row.get("verdict", ""),
                "observed_effect": row.get("observed_effect") or row.get("observed_metric_delta", {}),
            }
        )
    return formatted


def _normalise_retrieval_mode(mode: str) -> str:
    cleaned = str(mode or "semantic_graph_identity").strip().lower()
    if cleaned not in VALID_RETRIEVAL_MODES:
        raise ValueError(
            "retrieval_mode must be one of: " + ", ".join(sorted(VALID_RETRIEVAL_MODES))
        )
    return cleaned


def validate_harness_params(params: HarnessParams, *, production: bool = False) -> None:
    """Strictly validate harness parameters for CI and production gates."""

    errors: list[str] = []
    bounds = params.evolution
    if params.retrieval_mode not in VALID_RETRIEVAL_MODES:
        errors.append(f"invalid retrieval_mode: {params.retrieval_mode}")
    if not int(bounds.get("top_k_min", 1)) <= params.top_k <= int(bounds.get("top_k_max", 12)):
        errors.append("top_k outside configured safe bounds")
    if not float(bounds.get("decay_lambda_min", 0.0)) <= params.decay_lambda <= float(
        bounds.get("decay_lambda_max", 0.25)
    ):
        errors.append("decay_lambda outside configured safe bounds")
    if not int(bounds.get("graph_depth_min", 1)) <= params.graph_depth <= int(bounds.get("graph_depth_max", 4)):
        errors.append("graph_depth outside configured safe bounds")
    if not float(bounds.get("identity_threshold_min", 0.15)) <= params.identity_threshold <= float(
        bounds.get("identity_threshold_max", 0.65)
    ):
        errors.append("identity_threshold outside configured safe bounds")
    if not int(bounds.get("summarisation_threshold_min", 20)) <= params.summarisation_threshold <= int(
        bounds.get("summarisation_threshold_max", 1000)
    ):
        errors.append("summarisation_threshold outside configured safe bounds")
    if production:
        backend = os.getenv("SMRITI_MEMORY_BACKEND", "json").lower()
        public_demo = os.getenv("SMRITI_PUBLIC_DEMO", "false").lower() in {"1", "true", "yes", "on"}
        encrypted = bool(os.getenv("SMRITI_ENCRYPTION_KEY") or os.getenv("SMRITI_MEMORY_KEY"))
        if os.getenv("SMRITI_REQUIRE_ENCRYPTION", "true").lower() in {"1", "true", "yes", "on"} and not encrypted:
            errors.append("production mode requires SMRITI_ENCRYPTION_KEY or SMRITI_MEMORY_KEY")
        if public_demo and backend in {"redis", "postgres"}:
            errors.append("public_demo cannot use a shared durable production backend")
    if errors:
        raise HarnessConfigError("; ".join(errors))


def _validate_raw_harness_dict(data: Dict[str, Any]) -> None:
    errors: list[str] = []
    if "retrieval_mode" in data and data["retrieval_mode"] not in VALID_RETRIEVAL_MODES:
        errors.append(f"invalid retrieval_mode: {data['retrieval_mode']}")
    numeric_bounds: dict[str, tuple[float, float, type]] = {
        "top_k": (1, 12, int),
        "decay_lambda": (0.0, 0.25, float),
        "graph_depth": (1, 4, int),
        "identity_threshold": (0.15, 0.65, float),
        "summarisation_threshold": (20, 1000, int),
    }
    for key, (lower, upper, caster) in numeric_bounds.items():
        if key not in data:
            continue
        try:
            value = caster(data[key])
        except (TypeError, ValueError):
            errors.append(f"invalid {key}: must be numeric")
            continue
        if value < lower or value > upper:
            errors.append(f"invalid {key}: {value} outside [{lower}, {upper}]")
    if errors:
        raise HarnessConfigError("; ".join(errors))


def _apply_env_overrides(params: HarnessParams, *, strict: bool = False) -> HarnessParams:
    data = params.to_dict()
    env_map: dict[str, tuple[str, Any]] = {
        "SMRITI_RETRIEVAL_MODE": ("retrieval_mode", str),
        "SMRITI_TOP_K": ("top_k", int),
        "SMRITI_DECAY_LAMBDA": ("decay_lambda", float),
        "SMRITI_GRAPH_DEPTH": ("graph_depth", int),
        "SMRITI_IDENTITY_THRESHOLD": ("identity_threshold", float),
    }
    errors: list[str] = []
    for env_name, (field_name, caster) in env_map.items():
        raw = os.getenv(env_name)
        if raw is None:
            continue
        try:
            data[field_name] = caster(raw)
        except (TypeError, ValueError):
            errors.append(f"{env_name} could not be parsed")
    if errors and strict:
        raise HarnessConfigError("; ".join(errors))
    return HarnessParams.from_dict(data)


def _coerce_value(existing: Any, value: Any) -> Any:
    if isinstance(existing, bool):
        if isinstance(value, str):
            return value.lower() in {"1", "true", "yes", "on"}
        return bool(value)
    if isinstance(existing, int) and not isinstance(existing, bool):
        return int(value)
    if isinstance(existing, float):
        return float(value)
    return value


def _clamp(value: float, lower: float, upper: float) -> float:
    return max(lower, min(upper, value))


def _status_to_verdict(status: str) -> str:
    if status in {"accepted", "manual_override"}:
        return "accepted"
    if status in {"rejected"}:
        return "rejected"
    if status in {"reverted", "rollback"}:
        return "reverted"
    return "pending"
