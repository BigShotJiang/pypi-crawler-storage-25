"""Deterministic validation suite for seed vs evolved Smriti AI harnesses."""

from __future__ import annotations

import csv
import json
import statistics
import time
from pathlib import Path
from typing import Any, Dict, List

from .backends import JsonBackend
from .core import MemPalaceLite
from .harness import HarnessParams, load_harness_params
from .identity_fingerprint import IdentityFingerprint
from .semantic_memory import _HashingEmbeddingModel


DEFAULT_OUTPUT_JSON = Path("results/harness_evolution_validation.json")
DEFAULT_OUTPUT_CSV = Path("results/harness_evolution_validation.csv")
DEFAULT_OUTPUT_MD = Path("results/harness_evolution_validation.md")

FACTS = [
    ("My name is Alex.", ["alex"], "What is my name?"),
    ("I am a marine biologist.", ["marine", "biologist"], "What is my profession?"),
    ("I am based in Hawaii.", ["hawaii"], "Where am I based?"),
]
DISTRACTORS = [
    "What is the capital of France?",
    "Explain cosine similarity in one sentence.",
    "Give one safe productivity tip.",
]
PARAPHRASES = [
    ("Which island state do I live around?", ["hawaii"]),
    ("What field do I work in?", ["marine", "biologist"]),
]


def validate_harnesses(
    *,
    seed_config: str | Path = "configs/harness_params.yaml",
    evolved_config: str | Path = "harnesses/evolved-v1/harness_params.yaml",
    output_json: str | Path = DEFAULT_OUTPUT_JSON,
    output_csv: str | Path = DEFAULT_OUTPUT_CSV,
    output_md: str | Path = DEFAULT_OUTPUT_MD,
) -> Dict[str, Any]:
    """Compare baseline, seed harness, and evolved harness."""

    seed = load_harness_params(seed_config)
    evolved_path = Path(evolved_config)
    evolved = load_harness_params(evolved_path if evolved_path.exists() else seed_config)
    rows = [
        _baseline_row(),
        _evaluate_harness("smriti_seed_harness", seed),
        _evaluate_harness("smriti_evolved_harness", evolved),
    ]
    verdict = _production_verdict(rows[1], rows[2])
    payload = {"rows": rows, "thresholds": _thresholds(), "conclusion": verdict}
    _write_outputs(payload, output_json, output_csv, output_md)
    return payload


def _baseline_row() -> Dict[str, Any]:
    return {
        "system": "baseline_frozen_model",
        "memory_recall_accuracy": 0.0,
        "retrieval_precision_at_k": 0.0,
        "retrieval_recall_at_k": 0.0,
        "answer_correctness": 0.0,
        "identity_drift_score": 0.0,
        "identity_false_positive_rate": 0.0,
        "p50_latency_ms": 0.0,
        "p95_latency_ms": 0.0,
        "token_overhead": 0,
        "memory_write_count": 0,
        "memory_read_count": 0,
        "graph_retrieval_hit_rate": 0.0,
        "privacy_delete_passed": True,
    }


def _evaluate_harness(name: str, params: HarnessParams) -> Dict[str, Any]:
    memory = _memory(params)
    identity = IdentityFingerprint(
        role="optimistic memory assistant",
        threshold=params.identity_threshold,
        embedding_model=_HashingEmbeddingModel(),
    )
    identity.initialize_persona(["You are an optimistic memory assistant."])
    latencies: List[float] = []
    token_overhead = 0
    writes = 0
    reads = 0
    recall_hits = 0
    precision_scores = []
    recall_scores = []
    graph_hits = 0
    identity_false_positives = 0
    identity_distances = []

    for fact, _, _ in FACTS:
        start = time.perf_counter()
        memory.add_fact(fact, session_id="validation-user", topic_id="profile")
        writes += 1
        latencies.append((time.perf_counter() - start) * 1000)
        token_overhead += len(fact.split())

    for distractor in DISTRACTORS:
        start = time.perf_counter()
        context = memory.get_context(distractor, session_id="validation-user", topic_id="profile")
        reads += 1
        latencies.append((time.perf_counter() - start) * 1000)
        token_overhead += len(context.split())
        if any(term in context.lower() for term in ["alex", "marine", "hawaii"]):
            identity_false_positives += 1

    recall_cases = [(query, expected) for _, expected, query in FACTS] + PARAPHRASES
    for query, expected in recall_cases:
        start = time.perf_counter()
        retrieved = memory.retrieve_facts(query, session_id="validation-user", topic_id="profile")
        context = memory.get_context(query, session_id="validation-user", topic_id="profile")
        graph_facts = memory.knowledge_graph.triples_to_text(
            memory.knowledge_graph.query_graph("validation-user", "user", depth=params.graph_depth, topic_id="profile")
        )
        reads += 1
        latencies.append((time.perf_counter() - start) * 1000)
        combined = "\n".join([context, *retrieved, *graph_facts]).lower()
        hit = all(term in combined for term in expected)
        recall_hits += int(hit)
        graph_hits += int(bool(graph_facts) and hit)
        relevant = [fact for fact in retrieved if any(term in fact.lower() for term in expected)]
        precision_scores.append(len(relevant) / max(1, len(retrieved)))
        recall_scores.append(float(hit))
        response = "As an optimistic memory assistant, I remember: " + " ".join(retrieved[:3])
        identity_check = identity.evaluate_output(response)
        identity_distances.append(identity_check.distance)
        token_overhead += len(context.split()) + len(response.split())

    delete_passed = _privacy_delete_check(memory)
    total_recall = len(recall_cases)
    return {
        "system": name,
        "memory_recall_accuracy": recall_hits / total_recall,
        "retrieval_precision_at_k": statistics.mean(precision_scores) if precision_scores else 0.0,
        "retrieval_recall_at_k": statistics.mean(recall_scores) if recall_scores else 0.0,
        "answer_correctness": recall_hits / total_recall,
        "identity_drift_score": statistics.mean(identity_distances) if identity_distances else 0.0,
        "identity_false_positive_rate": identity_false_positives / max(1, len(DISTRACTORS)),
        "p50_latency_ms": _percentile(latencies, 50),
        "p95_latency_ms": _percentile(latencies, 95),
        "token_overhead": token_overhead,
        "memory_write_count": writes,
        "memory_read_count": reads,
        "graph_retrieval_hit_rate": graph_hits / total_recall,
        "privacy_delete_passed": delete_passed,
    }


def _memory(params: HarnessParams) -> MemPalaceLite:
    return MemPalaceLite(
        retrieval_mode=params.memory_retrieval_mode,
        session_id="validation-user",
        topic_id="profile",
        harness_params=params,
        embedding_model=_HashingEmbeddingModel(),
        faiss_module=False,
    )


def _privacy_delete_check(memory: MemPalaceLite) -> bool:
    backend = JsonBackend(root="data/validation-delete-smoke")
    user_id = "validation-delete-user"
    backend.save(user_id, memory.to_dict())
    deleted = backend.delete_user(user_id)
    return bool(deleted and backend.load(user_id) is None)


def _production_verdict(seed: Dict[str, Any], evolved: Dict[str, Any]) -> Dict[str, Any]:
    thresholds = _thresholds()
    failures = []
    if evolved["memory_recall_accuracy"] < seed["memory_recall_accuracy"]:
        failures.append("recall_regressed")
    if _ratio_increase(seed["p95_latency_ms"], evolved["p95_latency_ms"]) > thresholds["p95_latency_max_increase"]:
        failures.append("p95_latency_regressed")
    if _ratio_increase(seed["token_overhead"], evolved["token_overhead"]) > thresholds["token_overhead_max_increase"]:
        failures.append("token_overhead_regressed")
    if (
        evolved["identity_false_positive_rate"] - seed["identity_false_positive_rate"]
        > thresholds["identity_false_positive_max_increase"]
    ):
        failures.append("identity_false_positives_regressed")
    if not evolved["privacy_delete_passed"]:
        failures.append("privacy_delete_failed")
    return {
        "production_ready": not failures,
        "failures": failures,
        "summary": "Production-ready" if not failures else "NOT production-ready",
    }


def _write_outputs(
    payload: Dict[str, Any],
    output_json: str | Path,
    output_csv: str | Path,
    output_md: str | Path,
) -> None:
    json_path = Path(output_json)
    csv_path = Path(output_csv)
    md_path = Path(output_md)
    json_path.parent.mkdir(parents=True, exist_ok=True)
    json_path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    with csv_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(payload["rows"][0].keys()))
        writer.writeheader()
        writer.writerows(payload["rows"])
    md_path.write_text(_markdown(payload), encoding="utf-8")


def _markdown(payload: Dict[str, Any]) -> str:
    lines = [
        "# Harness Evolution Validation",
        "",
        "The base model remains frozen. This report evaluates only the Smriti AI memory harness.",
        "",
        "| System | Recall | Precision@K | Recall@K | Correctness | Drift | p95 ms | Tokens | Privacy delete |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---|",
    ]
    for row in payload["rows"]:
        lines.append(
            "| {system} | {recall:.3f} | {precision:.3f} | {retrieval_recall:.3f} | {correct:.3f} | {drift:.3f} | {p95:.3f} | {tokens} | {delete} |".format(
                system=row["system"],
                recall=row["memory_recall_accuracy"],
                precision=row["retrieval_precision_at_k"],
                retrieval_recall=row["retrieval_recall_at_k"],
                correct=row["answer_correctness"],
                drift=row["identity_drift_score"],
                p95=row["p95_latency_ms"],
                tokens=row["token_overhead"],
                delete="pass" if row["privacy_delete_passed"] else "fail",
            )
        )
    conclusion = payload["conclusion"]
    lines.extend(
        [
            "",
            "## Conclusion",
            "",
            f"- Verdict: **{conclusion['summary']}**",
            f"- Failures: {', '.join(conclusion['failures']) if conclusion['failures'] else 'none'}",
            "- Historical GodelAI-Lite percentages are lineage only; these metrics are current Smriti AI harness metrics.",
            "",
        ]
    )
    return "\n".join(lines)


def _thresholds() -> Dict[str, float]:
    return {
        "p95_latency_max_increase": 0.20,
        "token_overhead_max_increase": 0.25,
        "identity_false_positive_max_increase": 0.10,
    }


def _ratio_increase(before: float, after: float) -> float:
    if before <= 0:
        return 0.0 if after <= 0 else 1.0
    return (after - before) / before


def _percentile(values: List[float], percentile: int) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    index = min(len(ordered) - 1, max(0, round((percentile / 100) * (len(ordered) - 1))))
    return ordered[index]
