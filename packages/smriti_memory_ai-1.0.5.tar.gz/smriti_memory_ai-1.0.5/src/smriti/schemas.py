"""Pydantic API request/response schemas with security validation."""

from __future__ import annotations

from typing import Any, Dict, Optional

from pydantic import Field, field_validator, model_validator

from .security.validation import (
    StrictBaseModel,
    max_graph_depth,
    validate_harness_id,
    validate_identifier,
    validate_path,
    validate_retrieval_mode,
    validate_text,
)


class ChatRequest(StrictBaseModel):
    user_id: str
    message: str
    topic_id: str = "general"
    agent_id: str = "executor"
    retrieval_mode: Optional[str] = None
    tenant_id: Optional[str] = None

    @field_validator("user_id", "topic_id", "agent_id", "tenant_id")
    @classmethod
    def _ids(cls, value: Optional[str], info):
        if value is None:
            return value
        return validate_identifier(value, info.field_name)

    @field_validator("message")
    @classmethod
    def _message(cls, value: str) -> str:
        return validate_text(value, "message")

    @field_validator("retrieval_mode")
    @classmethod
    def _retrieval(cls, value: Optional[str]) -> Optional[str]:
        return validate_retrieval_mode(value)


class ChatResponse(StrictBaseModel):
    user_id: str
    agent_id: str
    topic_id: str
    response: str
    retrieved_context: str
    memory: Dict[str, Any]


class MemoryLoadRequest(StrictBaseModel):
    user_id: str
    memory: Optional[Dict[str, Any]] = None
    path: Optional[str] = None
    retrieval_mode: Optional[str] = None

    @field_validator("user_id")
    @classmethod
    def _user(cls, value: str) -> str:
        return validate_identifier(value, "user_id")

    @field_validator("path")
    @classmethod
    def _path(cls, value: Optional[str]) -> Optional[str]:
        return validate_path(value)

    @field_validator("retrieval_mode")
    @classmethod
    def _retrieval(cls, value: Optional[str]) -> Optional[str]:
        return validate_retrieval_mode(value)


class MemorySaveRequest(StrictBaseModel):
    user_id: str
    path: Optional[str] = None

    @field_validator("user_id")
    @classmethod
    def _user(cls, value: str) -> str:
        return validate_identifier(value, "user_id")

    @field_validator("path")
    @classmethod
    def _path(cls, value: Optional[str]) -> Optional[str]:
        return validate_path(value)


class MemoryDeleteRequest(MemorySaveRequest):
    pass


class GraphQueryRequest(StrictBaseModel):
    user_id: str
    query_entity: str
    topic_id: Optional[str] = None
    depth: int = Field(default=1, ge=1)

    @field_validator("user_id", "topic_id")
    @classmethod
    def _ids(cls, value: Optional[str], info):
        if value is None:
            return value
        return validate_identifier(value, info.field_name)

    @field_validator("query_entity")
    @classmethod
    def _query(cls, value: str) -> str:
        return validate_text(value, "query_entity", max_chars=512)

    @field_validator("depth")
    @classmethod
    def _depth(cls, value: int) -> int:
        if value > max_graph_depth():
            raise ValueError("graph depth exceeds configured maximum")
        return value


class HarnessRollbackRequest(StrictBaseModel):
    harness_id: str = "seed"

    @field_validator("harness_id")
    @classmethod
    def _harness(cls, value: str) -> str:
        return validate_harness_id(value)


class HarnessEvaluateRequest(StrictBaseModel):
    seed_harness_id: str = "seed"
    evolved_harness_id: str = "evolved-v1"

    @field_validator("seed_harness_id", "evolved_harness_id")
    @classmethod
    def _harness(cls, value: str) -> str:
        return validate_harness_id(value)


class CanaryStartRequest(StrictBaseModel):
    active_harness: str = "seed"
    canary_harness: str = "evolved-v1"
    canary_percentage: int = Field(default=10, ge=0, le=100)

    @field_validator("active_harness", "canary_harness")
    @classmethod
    def _harness(cls, value: str) -> str:
        return validate_harness_id(value)


class MemoryImportExportRequest(StrictBaseModel):
    user_id: str
    path: str

    @field_validator("user_id")
    @classmethod
    def _user(cls, value: str) -> str:
        return validate_identifier(value, "user_id")

    @field_validator("path")
    @classmethod
    def _path(cls, value: str) -> str:
        return validate_path(value, allow_none=False) or value


class BenchmarkRequest(StrictBaseModel):
    mode: str = "quick"
    max_cases: int = Field(default=5, ge=1, le=100)

    @model_validator(mode="after")
    def _official_requires_small_api_mode(self):
        if self.mode not in {"quick", "official", "local"}:
            raise ValueError("Invalid benchmark mode.")
        return self
