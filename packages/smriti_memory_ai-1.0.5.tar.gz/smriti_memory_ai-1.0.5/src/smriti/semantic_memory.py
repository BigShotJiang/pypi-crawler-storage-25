"""Semantic, hierarchical memory backed by sentence embeddings and FAISS."""
from __future__ import annotations

import json
import math
import re
import time
from hashlib import blake2b
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np


DEFAULT_EMBEDDING_MODEL = "all-MiniLM-L6-v2"
DEFAULT_ARCHIVE_PATH = "smriti_memory_archive.jsonl"


@dataclass
class MemoryEntry:
    """One fact or turn stored in a topic-level semantic index."""

    text: str
    timestamp: int
    embedding: List[float]
    created_at: float = field(default_factory=time.time)
    last_accessed: int = 0
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class RetrievalResult:
    """Ranked semantic retrieval result with both similarity and decay scores."""

    entry: MemoryEntry
    cosine_similarity: float
    decay: float
    score: float


@dataclass
class _TopicStore:
    entries: List[MemoryEntry] = field(default_factory=list)
    index: Any = None
    use_faiss: bool = False


class _HashingEmbeddingModel:
    """Small deterministic fallback used when sentence-transformers is absent."""

    def __init__(self, dimension: int = 384):
        self.dimension = dimension

    def encode(
        self,
        texts: Sequence[str] | str,
        convert_to_numpy: bool = True,
        normalize_embeddings: bool = True,
        **_: Any,
    ) -> np.ndarray:
        single = isinstance(texts, str)
        values = [texts] if single else list(texts)
        vectors = np.zeros((len(values), self.dimension), dtype=np.float32)
        for row, text in enumerate(values):
            for token in re.findall(r"[a-z0-9']+", text.lower()):
                digest = blake2b(token.encode("utf-8"), digest_size=8).digest()
                idx = int.from_bytes(digest, byteorder="big") % self.dimension
                vectors[row, idx] += 1.0
        if normalize_embeddings:
            vectors = _normalize(vectors)
        if single:
            return vectors[0]
        return vectors


class _NumpyIndex:
    """In-memory cosine index with a FAISS-like search interface."""

    def __init__(self, dimension: int):
        self.dimension = dimension
        self.vectors = np.empty((0, dimension), dtype=np.float32)

    def add(self, vectors: np.ndarray) -> None:
        vectors = np.asarray(vectors, dtype=np.float32)
        if vectors.ndim == 1:
            vectors = vectors.reshape(1, -1)
        self.vectors = np.vstack([self.vectors, vectors])

    def search(self, query: np.ndarray, k: int) -> Tuple[np.ndarray, np.ndarray]:
        if self.vectors.size == 0:
            return (
                np.empty((1, 0), dtype=np.float32),
                np.empty((1, 0), dtype=np.int64),
            )
        query = np.asarray(query, dtype=np.float32).reshape(1, -1)
        sims = self.vectors @ query[0]
        order = np.argsort(-sims)[:k]
        return sims[order].reshape(1, -1), order.astype(np.int64).reshape(1, -1)


class SemanticMemory:
    """
    Hierarchical semantic memory with per-topic vector indices.

    Sessions isolate users or conversations. Each session owns topics, and
    each topic owns `MemoryEntry` objects indexed by cosine similarity.
    """

    def __init__(
        self,
        embedding_model_name: str = DEFAULT_EMBEDDING_MODEL,
        decay_rate: float = 0.05,
        max_entries_per_topic: int = 200,
        archive_path: str | Path = DEFAULT_ARCHIVE_PATH,
        device: str = "auto",
        use_gpu_index: Optional[bool] = None,
        embedding_model: Any = None,
        faiss_module: Any = None,
    ):
        self.embedding_model_name = embedding_model_name
        self.decay_rate = decay_rate
        self.max_entries_per_topic = max_entries_per_topic
        self.archive_path = Path(archive_path)
        self.step_counter = 0
        self.sessions: Dict[str, Dict[str, _TopicStore]] = {}

        self.device = _resolve_device(device)
        self.embedding_model = embedding_model or self._load_embedding_model()
        if faiss_module is False:
            self.faiss = None
        else:
            self.faiss = faiss_module if faiss_module is not None else _try_import_faiss()
        self.use_gpu_index = _cuda_available() if use_gpu_index is None else use_gpu_index

    def _load_embedding_model(self) -> Any:
        try:
            from sentence_transformers import SentenceTransformer

            return SentenceTransformer(self.embedding_model_name, device=self.device)
        except Exception:
            return _HashingEmbeddingModel()

    def _embed(self, text: str) -> np.ndarray:
        vector = self.embedding_model.encode(
            text,
            convert_to_numpy=True,
            normalize_embeddings=True,
        )
        vector = np.asarray(vector, dtype=np.float32)
        if vector.ndim > 1:
            vector = vector[0]
        return _normalize(vector.reshape(1, -1))[0]

    def _get_topic(self, session_id: str, topic_id: str) -> _TopicStore:
        session = self.sessions.setdefault(session_id, {})
        return session.setdefault(topic_id, _TopicStore())

    def _new_index(self, dimension: int) -> Tuple[Any, bool]:
        if self.faiss is None:
            return _NumpyIndex(dimension), False

        index = None
        try:
            index = self.faiss.IndexHNSWFlat(
                dimension, 32, self.faiss.METRIC_INNER_PRODUCT
            )
            index.hnsw.efSearch = 64
            index.hnsw.efConstruction = 80
        except Exception:
            index = self.faiss.IndexFlatIP(dimension)

        if self.use_gpu_index and hasattr(self.faiss, "StandardGpuResources"):
            try:
                resources = self.faiss.StandardGpuResources()
                index = self.faiss.index_cpu_to_gpu(resources, 0, index)
            except Exception:
                pass
        return index, True

    def _rebuild_topic_index(self, topic: _TopicStore) -> None:
        if not topic.entries:
            topic.index = None
            topic.use_faiss = False
            return
        vectors = np.asarray([e.embedding for e in topic.entries], dtype=np.float32)
        vectors = _normalize(vectors)
        topic.index, topic.use_faiss = self._new_index(vectors.shape[1])
        topic.index.add(vectors)

    def add_entry(
        self,
        session_id: str,
        topic_id: str,
        text: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> MemoryEntry:
        """Embed text and add it to the session/topic memory."""

        cleaned = text.strip()
        if not cleaned:
            raise ValueError("Cannot add an empty memory entry.")

        self.step_counter += 1
        vector = self._embed(cleaned)
        entry = MemoryEntry(
            text=cleaned,
            timestamp=self.step_counter,
            embedding=vector.tolist(),
            last_accessed=self.step_counter,
            metadata=metadata or {},
        )
        topic = self._get_topic(session_id, topic_id)
        topic.entries.append(entry)

        if topic.index is None:
            self._rebuild_topic_index(topic)
        else:
            topic.index.add(vector.reshape(1, -1).astype(np.float32))

        self._enforce_topic_limit(session_id, topic_id)
        return entry

    def retrieve(
        self,
        session_id: str,
        topic_id: str,
        query: str,
        k: int = 5,
    ) -> List[RetrievalResult]:
        """Return top-k entries ranked by cosine similarity and age decay."""

        topic = self.sessions.get(session_id, {}).get(topic_id)
        if not topic or not topic.entries or not query.strip():
            return []
        if topic.index is None:
            self._rebuild_topic_index(topic)

        candidate_k = min(len(topic.entries), max(k * 5, k))
        query_vector = self._embed(query).reshape(1, -1).astype(np.float32)
        distances, indices = topic.index.search(query_vector, candidate_k)

        ranked: List[RetrievalResult] = []
        for cosine, idx in zip(distances[0], indices[0]):
            if idx < 0 or idx >= len(topic.entries):
                continue
            entry = topic.entries[int(idx)]
            age = max(0, self.step_counter - entry.timestamp)
            decay = math.exp(-self.decay_rate * age)
            score = max(0.0, float(cosine)) * decay
            entry.last_accessed = self.step_counter
            ranked.append(RetrievalResult(entry, float(cosine), decay, score))

        ranked.sort(key=lambda item: item.score, reverse=True)
        return ranked[:k]

    def recent_entries(
        self,
        session_id: str,
        topic_id: str,
        k: int = 5,
    ) -> List[MemoryEntry]:
        """Return the most recent entries for a session/topic."""

        topic = self.sessions.get(session_id, {}).get(topic_id)
        if not topic:
            return []
        return sorted(topic.entries, key=lambda entry: entry.timestamp, reverse=True)[:k]

    def compress_topic(self, session_id: str, topic_id: str) -> Optional[MemoryEntry]:
        """
        Summarise older entries, archive originals, and rebuild the topic index.

        The summariser is extractive and intentionally dependency-light. If NLTK
        sentence tokenisation is available it is used; otherwise a regex splitter
        keeps the method fully local.
        """

        topic = self.sessions.get(session_id, {}).get(topic_id)
        if not topic or len(topic.entries) < 4:
            return None

        keep_count = max(2, min(5, len(topic.entries) // 3))
        ordered = sorted(topic.entries, key=lambda entry: entry.timestamp)
        older = ordered[:-keep_count]
        recent = ordered[-keep_count:]
        if not older:
            return None

        summary_text = _extractive_summary([entry.text for entry in older])
        self._archive_entries(session_id, topic_id, older)

        self.step_counter += 1
        vector = self._embed(summary_text)
        summary = MemoryEntry(
            text=summary_text,
            timestamp=self.step_counter,
            embedding=vector.tolist(),
            last_accessed=self.step_counter,
            metadata={
                "compressed": True,
                "source_count": len(older),
                "source_timestamp_min": min(entry.timestamp for entry in older),
                "source_timestamp_max": max(entry.timestamp for entry in older),
            },
        )
        topic.entries = [summary] + recent
        self._rebuild_topic_index(topic)
        return summary

    def to_dict(self) -> Dict[str, Any]:
        return {
            "version": 1,
            "embedding_model_name": self.embedding_model_name,
            "decay_rate": self.decay_rate,
            "max_entries_per_topic": self.max_entries_per_topic,
            "archive_path": str(self.archive_path),
            "step_counter": self.step_counter,
            "sessions": {
                session_id: {
                    topic_id: [asdict(entry) for entry in topic.entries]
                    for topic_id, topic in topics.items()
                }
                for session_id, topics in self.sessions.items()
            },
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any], **kwargs: Any) -> "SemanticMemory":
        init_kwargs = {
            "embedding_model_name": data.get(
                "embedding_model_name", DEFAULT_EMBEDDING_MODEL
            ),
            "decay_rate": data.get("decay_rate", 0.05),
            "max_entries_per_topic": data.get("max_entries_per_topic", 200),
            "archive_path": data.get("archive_path", DEFAULT_ARCHIVE_PATH),
        }
        init_kwargs.update(kwargs)
        inst = cls(**init_kwargs)
        inst.step_counter = data.get("step_counter", 0)
        for session_id, topics in data.get("sessions", {}).items():
            for topic_id, entries in topics.items():
                topic = inst._get_topic(session_id, topic_id)
                topic.entries = [MemoryEntry(**entry) for entry in entries]
                inst._rebuild_topic_index(topic)
        return inst

    def save(self, path: str | Path = "smriti_memory.json") -> None:
        with open(path, "w", encoding="utf-8") as handle:
            json.dump(self.to_dict(), handle, indent=2)

    @classmethod
    def load(cls, path: str | Path = "smriti_memory.json", **kwargs: Any) -> "SemanticMemory":
        with open(path, encoding="utf-8") as handle:
            data = json.load(handle)
        return cls.from_dict(data, **kwargs)

    def _enforce_topic_limit(self, session_id: str, topic_id: str) -> None:
        topic = self.sessions.get(session_id, {}).get(topic_id)
        if not topic or len(topic.entries) <= self.max_entries_per_topic:
            return

        self.compress_topic(session_id, topic_id)
        topic = self.sessions[session_id][topic_id]
        if len(topic.entries) <= self.max_entries_per_topic:
            return

        topic.entries.sort(key=lambda entry: (entry.last_accessed, entry.timestamp))
        evicted = topic.entries[: len(topic.entries) - self.max_entries_per_topic]
        topic.entries = topic.entries[len(topic.entries) - self.max_entries_per_topic:]
        self._archive_entries(session_id, topic_id, evicted, reason="evicted_lru")
        self._rebuild_topic_index(topic)

    def _archive_entries(
        self,
        session_id: str,
        topic_id: str,
        entries: Iterable[MemoryEntry],
        reason: str = "compressed",
    ) -> None:
        entries = list(entries)
        if not entries:
            return
        self.archive_path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.archive_path, "a", encoding="utf-8") as handle:
            for entry in entries:
                payload = {
                    "session_id": session_id,
                    "topic_id": topic_id,
                    "reason": reason,
                    "archived_at": time.time(),
                    "entry": asdict(entry),
                }
                handle.write(json.dumps(payload) + "\n")


def _normalize(vectors: np.ndarray) -> np.ndarray:
    vectors = np.asarray(vectors, dtype=np.float32)
    norms = np.linalg.norm(vectors, axis=-1, keepdims=True)
    norms = np.where(norms == 0.0, 1.0, norms)
    return vectors / norms


def _try_import_faiss() -> Any:
    try:
        import faiss

        return faiss
    except Exception:
        return None


def _cuda_available() -> bool:
    try:
        import torch

        return bool(torch.cuda.is_available())
    except Exception:
        return False


def _resolve_device(device: str) -> str:
    if device != "auto":
        return device
    return "cuda" if _cuda_available() else "cpu"


def _split_sentences(text: str) -> List[str]:
    try:
        import nltk

        return [s.strip() for s in nltk.sent_tokenize(text) if s.strip()]
    except Exception:
        return [s.strip() for s in re.split(r"(?<=[.!?])\s+", text) if s.strip()]


def _extractive_summary(texts: Sequence[str], max_sentences: int = 3) -> str:
    text = " ".join(t.strip() for t in texts if t.strip())
    sentences = _split_sentences(text)
    if not sentences:
        return text[:500]
    if len(sentences) <= max_sentences:
        return " ".join(sentences)

    tokens = re.findall(r"[a-z0-9']+", text.lower())
    stopwords = {
        "the", "and", "a", "an", "to", "of", "in", "is", "it", "for",
        "on", "with", "that", "this", "i", "you", "we", "they", "am",
    }
    freqs: Dict[str, int] = {}
    for token in tokens:
        if token not in stopwords:
            freqs[token] = freqs.get(token, 0) + 1

    scored = []
    for idx, sentence in enumerate(sentences):
        words = re.findall(r"[a-z0-9']+", sentence.lower())
        score = sum(freqs.get(word, 0) for word in words) / max(1, len(words))
        scored.append((score, idx, sentence))
    selected = sorted(scored, key=lambda item: (-item[0], item[1]))[:max_sentences]
    selected.sort(key=lambda item: item[1])
    return " ".join(sentence for _, _, sentence in selected)[:750]
