"""Server-side guardrails for actions that an LLM must never authorize."""

from __future__ import annotations

RESTRICTED_ACTIONS = {
    "delete_memory",
    "export_memory",
    "view_other_user_memory",
    "change_harness",
    "promote_canary",
    "rollback_harness",
    "create_api_key",
    "revoke_api_key",
    "change_backend",
    "change_encryption",
    "run_benchmark",
}


def is_restricted_action(action: str) -> bool:
    return action in RESTRICTED_ACTIONS
