"""FastAPI authentication dependencies for Smriti AI."""

from __future__ import annotations

import os
from pathlib import Path

from fastapi import HTTPException, Request

from .api_keys import authenticate_key, load_records
from .rbac import AuthContext, require_admin, require_role, require_user_access

PUBLIC_ALWAYS = {"/health", "/live", "/ready"}
DOC_PATHS = {"/docs", "/openapi.json", "/redoc"}
METRIC_PATHS = {"/metrics"}


def is_production() -> bool:
    return os.getenv("SMRITI_ENV", "").lower() == "production"


def auth_enabled() -> bool:
    value = os.getenv("AUTH_ENABLED", os.getenv("SMRITI_AUTH_ENABLED", "false"))
    return value.lower() in {"1", "true", "yes", "on"} or bool(os.getenv("SMRITI_API_KEY")) or is_production()


def public_paths() -> set[str]:
    paths = set(PUBLIC_ALWAYS)
    if not is_production() or os.getenv("SMRITI_PUBLIC_DOCS", "false").lower() in {"1", "true", "yes", "on"}:
        paths.update(DOC_PATHS)
    if not is_production() or os.getenv("SMRITI_INTERNAL_METRICS_PUBLIC", "false").lower() in {"1", "true", "yes", "on"}:
        paths.update(METRIC_PATHS)
    return paths


def authenticate_request(request: Request) -> AuthContext:
    """Authenticate a FastAPI request and return caller context."""

    if request.url.path in public_paths():
        return AuthContext(key_id="public", role="public")
    if not auth_enabled():
        return AuthContext(key_id="disabled", role="admin")

    supplied = request.headers.get("x-api-key") or request.headers.get("X-API-Key")
    if not supplied:
        raise HTTPException(status_code=401, detail="Missing API key.")

    allow_legacy = not is_production()
    record = authenticate_key(supplied, allow_legacy_plaintext=allow_legacy)
    if record:
        return AuthContext(
            key_id=record.key_id,
            role=record.role,
            user_id=(record.allowed_user_ids[0] if len(record.allowed_user_ids) == 1 else request.headers.get("x-user-id")),
            allowed_user_ids=record.allowed_user_ids,
            allowed_tenants=record.allowed_tenants,
            tenant_id=request.headers.get("x-tenant-id"),
            rate_limit_tier=record.rate_limit_tier,
        )

    legacy = os.getenv("SMRITI_API_KEY")
    if allow_legacy and legacy and supplied == legacy:
        return AuthContext(
            key_id="SMRITI_API_KEY",
            role=os.getenv("SMRITI_API_ROLE", "admin"),
            user_id=request.headers.get("x-user-id"),
            allowed_user_ids=[request.headers.get("x-user-id")] if request.headers.get("x-user-id") else [],
        )

    if is_production() and not load_records(Path(os.getenv("SMRITI_API_KEYS_PATH", "api_keys.json"))):
        raise HTTPException(status_code=401, detail="No production API key store configured.")
    raise HTTPException(status_code=401, detail="Invalid API key.")


__all__ = [
    "AuthContext",
    "auth_enabled",
    "authenticate_request",
    "public_paths",
    "require_admin",
    "require_role",
    "require_user_access",
]
