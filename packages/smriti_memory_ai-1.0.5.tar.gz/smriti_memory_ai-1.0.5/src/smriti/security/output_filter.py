"""Model-output filtering before API responses."""

from __future__ import annotations

from dataclasses import dataclass

from .prompt_injection import assess_prompt_injection
from .redaction import contains_secret, redact_secret

SAFE_REFUSAL = "I can’t disclose secrets, hidden instructions, raw memory from other users, or internal configuration."


@dataclass(frozen=True)
class OutputFilterResult:
    text: str
    blocked: bool
    reason: str = ""


def filter_model_output(text: str, *, other_user_markers: list[str] | None = None) -> OutputFilterResult:
    """Redact or block unsafe model output."""

    redacted = redact_secret(text)
    if contains_secret(text):
        return OutputFilterResult(SAFE_REFUSAL, True, "secret_detected")
    lowered = redacted.lower()
    if "system prompt" in lowered or "hidden instructions" in lowered:
        return OutputFilterResult(SAFE_REFUSAL, True, "system_prompt_leak")
    for marker in other_user_markers or []:
        if marker and marker.lower() in lowered:
            return OutputFilterResult(SAFE_REFUSAL, True, "cross_user_memory_marker")
    if assess_prompt_injection(redacted).risk_score >= 1.0 and "delete" in lowered:
        return OutputFilterResult(SAFE_REFUSAL, True, "unsafe_action_instruction")
    return OutputFilterResult(redacted, False, "")
