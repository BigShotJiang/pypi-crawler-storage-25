"""FastAPI dependency helpers for Smriti AI security."""

from __future__ import annotations

from fastapi import Request

from .auth import authenticate_request
from .rbac import AuthContext


def get_auth_context(request: Request) -> AuthContext:
    return getattr(request.state, "auth", authenticate_request(request))
