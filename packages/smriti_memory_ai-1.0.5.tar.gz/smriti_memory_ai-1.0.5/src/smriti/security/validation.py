"""Input and configuration validation for Smriti AI."""

from __future__ import annotations

import os
import re
import unicodedata
from pathlib import Path
from urllib.parse import urlparse

from fastapi import HTTPException, Request
from pydantic import BaseModel, ConfigDict

VALID_RETRIEVAL_MODES = {"tfidf", "semantic", "semantic_graph", "semantic_graph_identity"}
VALID_BACKENDS = {"json", "sqlite", "redis", "postgres", "postgresql"}
VALID_ADAPTERS = {"huggingface_local", "hf_endpoint", "ollama", "vllm", "openai", "openai_compatible"}
ID_RE = re.compile(r"^[A-Za-z0-9_.@:-]{1,128}$")
HARNESS_RE = re.compile(r"^[A-Za-z0-9_.-]{1,128}$")


def is_production() -> bool:
    return os.getenv("SMRITI_ENV", "").lower() == "production"


class StrictBaseModel(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


def max_message_chars() -> int:
    return int(os.getenv("SMRITI_MAX_MESSAGE_CHARS", "12000"))


def max_request_body_bytes() -> int:
    return int(os.getenv("SMRITI_MAX_REQUEST_BODY_BYTES", "1048576"))


def max_top_k() -> int:
    return int(os.getenv("SMRITI_MAX_TOP_K", "20"))


def max_graph_depth() -> int:
    return int(os.getenv("SMRITI_MAX_GRAPH_DEPTH", "4"))


def normalize_text(value: str) -> str:
    if "\x00" in value:
        raise ValueError("Null bytes are not allowed.")
    return unicodedata.normalize("NFC", value)


def validate_identifier(value: str, field: str = "identifier") -> str:
    value = normalize_text(str(value or "").strip())
    if not ID_RE.match(value):
        raise ValueError(f"Invalid {field}.")
    if ".." in value or "/" in value or "\\" in value:
        raise ValueError(f"Invalid {field}: path-like values are not allowed.")
    return value


def validate_harness_id(value: str) -> str:
    value = normalize_text(str(value or "").strip())
    if not HARNESS_RE.match(value) or ".." in value or "/" in value or "\\" in value:
        raise ValueError("Invalid harness_id.")
    return value


def validate_text(value: str, field: str = "text", *, max_chars: int | None = None) -> str:
    if not isinstance(value, str):
        raise ValueError(f"{field} must be text.")
    value = normalize_text(value)
    if len(value) > (max_chars or max_message_chars()):
        raise ValueError(f"{field} is too large.")
    return value


def validate_path(value: str | None, *, allow_none: bool = True) -> str | None:
    if value is None:
        if allow_none:
            return None
        raise ValueError("path is required.")
    path_text = normalize_text(str(value).strip())
    if "\x00" in path_text or ".." in Path(path_text).parts:
        raise ValueError("Path traversal is not allowed.")
    return path_text


def validate_retrieval_mode(value: str | None) -> str | None:
    if value is None:
        return None
    if value not in VALID_RETRIEVAL_MODES:
        raise ValueError("Invalid retrieval_mode.")
    return value


def validate_url_allowlist(url: str, env_name: str = "SMRITI_ALLOWED_PROVIDER_HOSTS") -> str:
    parsed = urlparse(url)
    if parsed.scheme not in {"https", "http"}:
        raise ValueError("Only HTTP(S) provider URLs are allowed.")
    if parsed.hostname in {"127.0.0.1", "localhost", "0.0.0.0"} and is_production():
        raise ValueError("Loopback provider URLs are not allowed in production.")
    allow = {item.strip().lower() for item in os.getenv(env_name, "").split(",") if item.strip()}
    if is_production() and allow and parsed.hostname and parsed.hostname.lower() not in allow:
        raise ValueError("Provider host is not allowlisted.")
    return url


async def enforce_body_size(request: Request) -> None:
    length = request.headers.get("content-length")
    if length and int(length) > max_request_body_bytes():
        raise HTTPException(status_code=413, detail="Request body too large.")
