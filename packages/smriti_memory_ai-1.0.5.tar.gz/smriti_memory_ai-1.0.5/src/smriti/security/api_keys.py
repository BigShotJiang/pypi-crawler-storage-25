"""Hashed API-key storage and verification."""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import secrets
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, Optional

DEFAULT_ITERATIONS = 260_000


@dataclass
class ApiKeyRecord:
    key_id: str
    hashed_key: str
    role: str = "user"
    allowed_user_ids: list[str] = field(default_factory=list)
    allowed_tenants: list[str] = field(default_factory=list)
    created_at: str = ""
    expires_at: Optional[str] = None
    revoked: bool = False
    rate_limit_tier: str = "standard"
    last_used_at: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ApiKeyRecord":
        values = dict(data)
        if "allowed_user_ids" not in values and values.get("user_id"):
            values["allowed_user_ids"] = [values["user_id"]]
        allowed = {key for key in cls.__dataclass_fields__}
        kwargs = {key: values[key] for key in allowed if key in values}
        kwargs.setdefault("allowed_user_ids", [])
        kwargs.setdefault("allowed_tenants", [])
        kwargs.setdefault("created_at", _now())
        if "key_id" not in kwargs or "hashed_key" not in kwargs:
            raise ValueError("API key record requires key_id and hashed_key.")
        return cls(**kwargs)


def generate_api_key(prefix: str = "smriti") -> str:
    """Generate a display-once API key."""

    return f"{prefix}_{secrets.token_urlsafe(32)}"


def hash_api_key(api_key: str, *, iterations: int = DEFAULT_ITERATIONS, salt: str | None = None) -> str:
    """Hash an API key using PBKDF2-SHA256."""

    salt_bytes = base64.urlsafe_b64decode(salt.encode("utf-8")) if salt else secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", api_key.encode("utf-8"), salt_bytes, iterations)
    return "pbkdf2_sha256${}${}${}".format(
        iterations,
        base64.urlsafe_b64encode(salt_bytes).decode("utf-8"),
        base64.urlsafe_b64encode(digest).decode("utf-8"),
    )


def verify_api_key(api_key: str, hashed_key: str) -> bool:
    """Constant-time API-key hash verification."""

    try:
        algorithm, iterations_raw, salt, expected = hashed_key.split("$", 3)
        if algorithm != "pbkdf2_sha256":
            return False
        candidate = hash_api_key(api_key, iterations=int(iterations_raw), salt=salt).split("$", 3)[3]
        return hmac.compare_digest(candidate, expected)
    except Exception:
        return False


def create_record(
    *,
    role: str,
    key_id: str | None = None,
    allowed_user_ids: Iterable[str] | None = None,
    allowed_tenants: Iterable[str] | None = None,
    expires_at: str | None = None,
    rate_limit_tier: str = "standard",
) -> tuple[str, ApiKeyRecord]:
    """Create a new display-once API key plus hashed metadata record."""

    api_key = generate_api_key()
    record = ApiKeyRecord(
        key_id=key_id or secrets.token_hex(6),
        hashed_key=hash_api_key(api_key),
        role=role,
        allowed_user_ids=list(allowed_user_ids or []),
        allowed_tenants=list(allowed_tenants or []),
        created_at=_now(),
        expires_at=expires_at,
        revoked=False,
        rate_limit_tier=rate_limit_tier,
    )
    return api_key, record


def load_records(path: str | Path | None = None, *, allow_legacy_plaintext: bool = False) -> list[ApiKeyRecord]:
    """Load API-key records from the configured JSON file."""

    keys_path = Path(path or os.getenv("SMRITI_API_KEYS_PATH", "api_keys.json"))
    if not keys_path.exists():
        return []
    payload = json.loads(keys_path.read_text(encoding="utf-8"))
    records: list[ApiKeyRecord] = []
    if isinstance(payload, dict) and isinstance(payload.get("keys"), list):
        return [ApiKeyRecord.from_dict(item) for item in payload["keys"]]
    if not allow_legacy_plaintext:
        return []
    if isinstance(payload, list):
        for item in payload:
            key = item.get("key")
            if key:
                records.append(_legacy_record(key, item))
    elif isinstance(payload, dict):
        for key, value in payload.items():
            if isinstance(value, dict):
                records.append(_legacy_record(key, value))
    return records


def write_records(records: list[ApiKeyRecord], path: str | Path | None = None) -> Path:
    """Write hashed API-key records."""

    keys_path = Path(path or os.getenv("SMRITI_API_KEYS_PATH", "api_keys.json"))
    keys_path.parent.mkdir(parents=True, exist_ok=True)
    payload = {"version": 1, "keys": [asdict(record) for record in records]}
    keys_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    try:
        keys_path.chmod(0o600)
    except OSError:
        pass
    return keys_path


def authenticate_key(api_key: str, *, path: str | Path | None = None, allow_legacy_plaintext: bool = False) -> ApiKeyRecord | None:
    """Return the matching non-revoked, non-expired API-key record."""

    now = _now()
    for record in load_records(path, allow_legacy_plaintext=allow_legacy_plaintext):
        if record.revoked:
            continue
        if record.expires_at and record.expires_at <= now:
            continue
        if verify_api_key(api_key, record.hashed_key):
            return record
    return None


def _legacy_record(api_key: str, data: Dict[str, Any]) -> ApiKeyRecord:
    allowed = []
    if data.get("user_id"):
        allowed.append(data["user_id"])
    return ApiKeyRecord(
        key_id=data.get("key_id", data.get("name", api_key[:8])),
        hashed_key=hash_api_key(api_key),
        role=data.get("role", "user"),
        allowed_user_ids=data.get("allowed_user_ids") or allowed,
        allowed_tenants=data.get("allowed_tenants") or [],
        created_at=data.get("created_at", _now()),
        expires_at=data.get("expires_at"),
        revoked=bool(data.get("revoked", False)),
        rate_limit_tier=data.get("rate_limit_tier", "standard"),
        last_used_at=data.get("last_used_at"),
    )


def _now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
