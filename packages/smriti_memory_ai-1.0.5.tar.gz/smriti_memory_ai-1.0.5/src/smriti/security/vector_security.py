"""Vector retrieval policy and poisoning controls."""

from __future__ import annotations

from typing import Any, Dict

from .prompt_injection import assess_prompt_injection


def min_similarity_threshold() -> float:
    import os

    return float(os.getenv("SMRITI_MIN_SIMILARITY", "0.0"))


def memory_allowed_for_injection(entry: Dict[str, Any], *, expected_user_id: str | None = None) -> bool:
    """Return whether a retrieved memory entry is safe to inject as context."""

    metadata = entry.get("metadata") or {}
    if expected_user_id and entry.get("user_id") and entry.get("user_id") != expected_user_id:
        return False
    if metadata.get("deleted") or metadata.get("archived") or metadata.get("quarantined"):
        return False
    if float(entry.get("similarity", entry.get("score", 1.0)) or 0.0) < min_similarity_threshold():
        return False
    if assess_prompt_injection(str(entry.get("text", ""))).quarantine:
        return False
    return True


def strip_embedding_fields(payload: Any) -> Any:
    """Remove raw embeddings/vector IDs from API payloads."""

    if isinstance(payload, dict):
        return {
            key: strip_embedding_fields(value)
            for key, value in payload.items()
            if key not in {"embedding", "embedding_vector", "vector", "vector_id", "faiss_id"}
        }
    if isinstance(payload, list):
        return [strip_embedding_fields(item) for item in payload]
    return payload
