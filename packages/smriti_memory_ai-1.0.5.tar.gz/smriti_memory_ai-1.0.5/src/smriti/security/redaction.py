"""Redaction and sensitive-value detection for Smriti AI."""

from __future__ import annotations

import json
import os
import re
from typing import Any, Iterable

SENSITIVE_ENV_NAMES = {
    "HF_TOKEN",
    "OPENAI_API_KEY",
    "ANTHROPIC_API_KEY",
    "SMRITI_API_KEY",
    "SMRITI_ENCRYPTION_KEY",
    "SMRITI_MEMORY_KEY",
    "REDIS_URL",
    "SMRITI_REDIS_URL",
    "POSTGRES_DSN",
    "SMRITI_POSTGRES_DSN",
    "JWT_SECRET",
    "SECRET_KEY",
    "AWS_SECRET_ACCESS_KEY",
    "AZURE_CLIENT_SECRET",
    "GOOGLE_APPLICATION_CREDENTIALS",
}

SECRET_PATTERNS: tuple[re.Pattern[str], ...] = (
    re.compile(r"\bhf_[A-Za-z0-9]{12,}\b"),
    re.compile(r"\bpypi-[A-Za-z0-9_-]{20,}\b"),
    re.compile(r"\bsk-[A-Za-z0-9_-]{12,}\b"),
    re.compile(r"\b(?:postgres(?:ql)?|rediss?)://[^:/\s\"'<>]+:[^@\s\"'<>]+@[^\s\"'<>]+", re.IGNORECASE),
    re.compile(r"\brediss?://:[^@\s\"'<>]+@[^\s\"'<>]+", re.IGNORECASE),
    re.compile(r"\bBearer\s+[A-Za-z0-9._-]{12,}\b", re.IGNORECASE),
    re.compile(r"\b[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b"),
    re.compile(r"\bgAAAAA[A-Za-z0-9_-]{20,}\b"),
    re.compile(r"\b[A-Za-z0-9_-]{43}=\b"),
    re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |)PRIVATE KEY-----[\s\S]+?-----END (?:RSA |EC |OPENSSH |)PRIVATE KEY-----"),
)

PII_PATTERNS: tuple[re.Pattern[str], ...] = (
    re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b"),
    re.compile(r"\b(?:\+?\d[\d\s().-]{7,}\d)\b"),
    re.compile(r"\b(?:\d[ -]*?){13,19}\b"),
)


def _as_text(value: Any) -> str:
    if isinstance(value, (dict, list, tuple, set)):
        return json.dumps(value, default=str, sort_keys=True)
    return str(value)


def sensitive_env_values() -> list[str]:
    """Return configured secret values that are long enough to redact."""

    values: list[str] = []
    for name in SENSITIVE_ENV_NAMES:
        value = os.getenv(name)
        if value and len(value) >= 6:
            values.append(value)
    return values


def redact_secret(value: Any, replacement: str = "[REDACTED]") -> str:
    """Return ``value`` as text with known secret patterns removed."""

    text = _as_text(value)
    for secret in sorted(sensitive_env_values(), key=len, reverse=True):
        text = text.replace(secret, replacement)
    for pattern in SECRET_PATTERNS:
        text = pattern.sub(replacement, text)
    return text


def contains_secret(value: Any, extra_values: Iterable[str] | None = None) -> bool:
    """Return True when ``value`` appears to contain a secret."""

    text = _as_text(value)
    candidates = list(sensitive_env_values())
    if extra_values:
        candidates.extend(candidate for candidate in extra_values if candidate)
    for candidate in candidates:
        if len(candidate) >= 6 and candidate in text:
            return True
    return redact_secret(text) != text


def assert_no_secret_leak(value: Any) -> None:
    """Raise AssertionError when ``value`` contains a secret-like token."""

    if contains_secret(value):
        raise AssertionError("Sensitive value leaked in output.")


def detect_pii(value: Any) -> list[str]:
    """Return lightweight PII detector labels for public-demo policy checks."""

    text = _as_text(value)
    labels: list[str] = []
    for label, pattern in zip(("email", "phone", "financial"), PII_PATTERNS):
        if pattern.search(text):
            labels.append(label)
    return labels
