"""Memory encryption policy helpers."""

from __future__ import annotations

import os

from .validation import is_production


def encryption_key_configured() -> bool:
    return bool(os.getenv("SMRITI_MEMORY_KEY") or os.getenv("SMRITI_ENCRYPTION_KEY"))


def production_encryption_required() -> bool:
    if not is_production():
        return False
    override = os.getenv("SMRITI_ALLOW_UNENCRYPTED_MEMORY", "").lower() in {"1", "true", "yes", "on"}
    acknowledged = bool(os.getenv("SMRITI_ENTERPRISE_OVERRIDE_ACK"))
    return not (override and acknowledged)


def validate_encryption_policy() -> None:
    if production_encryption_required() and not encryption_key_configured():
        raise RuntimeError("Production requires SMRITI_MEMORY_KEY or SMRITI_ENCRYPTION_KEY.")
