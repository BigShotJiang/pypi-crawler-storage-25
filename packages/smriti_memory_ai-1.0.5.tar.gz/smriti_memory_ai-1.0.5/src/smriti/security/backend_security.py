"""Backend path, SQL, Redis/Postgres, and file safety helpers."""

from __future__ import annotations

import os
from pathlib import Path
from urllib.parse import urlsplit, urlunsplit

from .validation import is_production


def approved_data_dir() -> Path:
    return Path(os.getenv("SMRITI_DATA_DIR", "data")).resolve()


def safe_backend_root(path: str | Path) -> Path:
    """Resolve a backend root and enforce approved data-dir policy in production."""

    candidate = Path(path).expanduser().resolve()
    if is_production():
        root = approved_data_dir()
        try:
            candidate.relative_to(root)
        except ValueError as exc:
            raise ValueError(f"Backend path must be under approved data directory: {root}") from exc
    return candidate


def safe_user_id(value: str) -> str:
    from .validation import validate_identifier

    return validate_identifier(value, "user_id")


def ensure_not_symlink(path: Path) -> None:
    if path.exists() and path.is_symlink():
        raise ValueError("Refusing to overwrite symlinked memory file.")


def chmod_private(path: Path) -> None:
    try:
        path.chmod(0o600)
    except OSError:
        pass


def redact_url(url: str) -> str:
    parts = urlsplit(url)
    if parts.password:
        netloc = parts.hostname or ""
        if parts.port:
            netloc = f"{netloc}:{parts.port}"
        if parts.username:
            netloc = f"{parts.username}:***@{netloc}"
        return urlunsplit((parts.scheme, netloc, parts.path, parts.query, parts.fragment))
    return url
