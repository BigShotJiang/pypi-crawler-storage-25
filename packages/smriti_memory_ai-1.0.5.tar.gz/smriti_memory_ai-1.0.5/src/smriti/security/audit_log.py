"""Structured security audit logging."""

from __future__ import annotations

import json
import os
import time
from pathlib import Path
from typing import Any, Dict

from .redaction import redact_secret


def audit_log_path() -> Path:
    return Path(os.getenv("SMRITI_AUDIT_LOG_PATH", "logs/security_audit.jsonl"))


def emit_audit_event(event_type: str, **fields: Any) -> None:
    path = audit_log_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    payload: Dict[str, Any] = {
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "event_type": event_type,
        **fields,
    }
    path.open("a", encoding="utf-8").write(redact_secret(json.dumps(payload, sort_keys=True)) + "\n")
