"""Prompt and memory injection detection utilities."""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Iterable

INJECTION_PATTERNS: tuple[re.Pattern[str], ...] = (
    re.compile(r"ignore\s+(?:all\s+)?previous\s+instructions", re.IGNORECASE),
    re.compile(r"\b(?:system|developer|assistant)\s*:", re.IGNORECASE),
    re.compile(r"reveal\s+(?:the\s+)?(?:user'?s\s+)?secret", re.IGNORECASE),
    re.compile(r"print\s+(?:the\s+)?(?:encryption\s+key|api\s+key|token|system\s+prompt)", re.IGNORECASE),
    re.compile(r"delete\s+all\s+memory", re.IGNORECASE),
    re.compile(r"call\s+(?:a\s+)?tool|/memory/delete|/harness/", re.IGNORECASE),
    re.compile(r"override\s+(?:policy|instructions|auth)", re.IGNORECASE),
    re.compile(r"jailbreak|developer\s+mode|hidden\s+prompt", re.IGNORECASE),
    re.compile(r"export\s+all\s+users|leak\s+other\s+users?", re.IGNORECASE),
    re.compile(r"disable\s+(?:auth|encryption|security)", re.IGNORECASE),
)

HIGH_RISK_THRESHOLD = 0.65


@dataclass(frozen=True)
class InjectionAssessment:
    """Prompt-injection assessment result."""

    risk_score: float
    matched_patterns: list[str]
    quarantine: bool = False



def assess_prompt_injection(text: str, extra_patterns: Iterable[re.Pattern[str]] | None = None) -> InjectionAssessment:
    """Score suspicious instruction-like text in user prompts, memory, or graph facts."""

    patterns = list(INJECTION_PATTERNS)
    if extra_patterns:
        patterns.extend(extra_patterns)
    matched = [pattern.pattern for pattern in patterns if pattern.search(text or "")]
    score = min(1.0, len(matched) / 3.0)
    return InjectionAssessment(score, matched, score >= HIGH_RISK_THRESHOLD)
