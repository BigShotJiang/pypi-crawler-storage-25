"""Comprehensive user-memory deletion helpers."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict


def purge_memory_object(memory: Any) -> Dict[str, bool]:
    """Best-effort purge of all per-user in-memory layers."""

    purged = {
        "semantic_memory": False,
        "knowledge_graph": False,
        "identity": False,
        "history": False,
        "facts": False,
    }
    if memory is None:
        return purged
    if getattr(memory, "semantic_memory", None) is not None:
        try:
            memory.semantic_memory.sessions.pop(getattr(memory, "session_id", ""), None)
            purged["semantic_memory"] = True
        except Exception:
            pass
    if getattr(memory, "knowledge_graph", None) is not None:
        try:
            graph = memory.knowledge_graph
            if hasattr(graph, "graphs"):
                graph.graphs.pop(getattr(memory, "session_id", ""), None)
            purged["knowledge_graph"] = True
        except Exception:
            pass
    for attr, label in (("identity", "identity"), ("history", "history"), ("key_facts", "facts")):
        if hasattr(memory, attr):
            try:
                value = getattr(memory, attr)
                if hasattr(value, "clear"):
                    value.clear()
                else:
                    setattr(memory, attr, None)
                purged[label] = True
            except Exception:
                pass
    return purged


def delete_managed_file(path: str | None) -> bool:
    if not path:
        return False
    target = Path(path)
    if not target.exists():
        return False
    target.unlink()
    return True
