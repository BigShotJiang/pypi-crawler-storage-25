"""Role-based access control policy for Smriti AI."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from fastapi import HTTPException

ROLE_PERMISSIONS = {
    "public": {"health:read"},
    "user": {"chat:own", "memory:read:own", "memory:delete:own", "memory:write:own"},
    "developer": {"chat:own", "memory:read:own", "memory:write:own", "benchmark:local", "diagnostics:read"},
    "admin": {"*"},
    "auditor": {"audit:read", "security:read", "diagnostics:read"},
    "service": {"chat:own", "memory:read:own", "memory:write:own", "memory:delete:own", "service:internal"},
}


@dataclass(frozen=True)
class AuthContext:
    """Authenticated caller context."""

    key_id: str
    role: str = "user"
    user_id: Optional[str] = None
    allowed_user_ids: list[str] = field(default_factory=list)
    allowed_tenants: list[str] = field(default_factory=list)
    tenant_id: Optional[str] = None
    rate_limit_tier: str = "standard"

    @property
    def is_admin(self) -> bool:
        return self.role == "admin"

    def can(self, permission: str) -> bool:
        permissions = ROLE_PERMISSIONS.get(self.role, set())
        return "*" in permissions or permission in permissions


def require_user_access(auth: AuthContext, target_user_id: str, *, tenant_id: str | None = None) -> None:
    """Require caller to own a user ID or hold admin role."""

    if auth.role == "public":
        raise HTTPException(status_code=401, detail="Authentication required.")
    if auth.is_admin:
        return
    allowed = set(auth.allowed_user_ids or [])
    if auth.user_id:
        allowed.add(auth.user_id)
    if target_user_id in allowed:
        if tenant_id and auth.allowed_tenants and tenant_id not in auth.allowed_tenants:
            raise HTTPException(status_code=403, detail="Not authorized for this tenant_id.")
        return
    raise HTTPException(status_code=403, detail="Not authorized for this user_id.")


def require_role(auth: AuthContext, roles: set[str]) -> None:
    if auth.role in roles or auth.is_admin:
        return
    raise HTTPException(status_code=403, detail="Insufficient role.")


def require_admin(auth: AuthContext) -> None:
    if auth.is_admin:
        return
    raise HTTPException(status_code=403, detail="Admin role required.")
