"""Rate-limit tier defaults."""

from __future__ import annotations

TIER_LIMITS_PER_MINUTE = {
    "standard": 60,
    "developer": 120,
    "admin": 240,
    "service": 600,
}


def limit_for_tier(tier: str, default: int = 60) -> int:
    return TIER_LIMITS_PER_MINUTE.get(tier, default)
