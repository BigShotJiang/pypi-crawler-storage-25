"""HTTP security header helpers."""

from __future__ import annotations

from fastapi import Response

SECURITY_HEADERS = {
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Referrer-Policy": "no-referrer",
    "Content-Security-Policy": "default-src 'self'; frame-ancestors 'none'; object-src 'none'",
}

SENSITIVE_CACHE_CONTROL = "no-store"


def apply_security_headers(response: Response, *, sensitive: bool = False) -> None:
    for key, value in SECURITY_HEADERS.items():
        response.headers.setdefault(key, value)
    if sensitive:
        response.headers["Cache-Control"] = SENSITIVE_CACHE_CONTROL
