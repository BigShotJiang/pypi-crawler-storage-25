"""Benchmark and model-card result integrity checks."""

from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any, Dict, Iterable

REQUIRED_PROVENANCE = {
    "run_id",
    "timestamp",
    "git_commit",
    "model_id",
    "model_is_fake",
    "data_is_synthetic",
    "benchmark_mode",
    "harness_id",
    "hardware",
    "dataset_name",
    "retrieval_mode",
}


def validate_official_result(row: Dict[str, Any]) -> list[str]:
    errors = [f"missing provenance: {key}" for key in sorted(REQUIRED_PROVENANCE) if key not in row]
    if str(row.get("model_is_fake", "")).lower() != "false":
        errors.append("official result uses fake model")
    if str(row.get("data_is_synthetic", "")).lower() != "false":
        errors.append("official result uses synthetic data")
    if row.get("benchmark_mode") != "official":
        errors.append("official result must set benchmark_mode=official")
    return errors


def scan_result_files(paths: Iterable[str | Path]) -> Dict[str, Any]:
    findings: list[Dict[str, Any]] = []
    for path_raw in paths:
        path = Path(path_raw)
        if not path.exists() or not path.is_file():
            continue
        if path.suffix == ".csv":
            with path.open(newline="", encoding="utf-8") as handle:
                for index, row in enumerate(csv.DictReader(handle), start=1):
                    officialish = row.get("benchmark_mode") == "official" or "results/current" in str(path)
                    if officialish:
                        errors = validate_official_result(row)
                        if errors:
                            findings.append({"path": str(path), "row": index, "errors": errors})
        elif path.suffix == ".json":
            payload = json.loads(path.read_text(encoding="utf-8"))
            rows = payload if isinstance(payload, list) else payload.get("rows", []) if isinstance(payload, dict) else []
            for index, row in enumerate(rows, start=1):
                if isinstance(row, dict) and row.get("benchmark_mode") == "official":
                    errors = validate_official_result(row)
                    if errors:
                        findings.append({"path": str(path), "row": index, "errors": errors})
    return {"valid": not findings, "findings": findings}
