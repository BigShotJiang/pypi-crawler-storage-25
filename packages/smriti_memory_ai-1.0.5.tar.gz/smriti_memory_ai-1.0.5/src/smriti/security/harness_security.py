"""Security policy for harness evolution and promotion."""

from __future__ import annotations

from typing import Any, Dict

ALLOWED_HARNESS_KEYS = {
    "retrieval_mode",
    "top_k",
    "decay_lambda",
    "use_graph",
    "graph_depth",
    "graph_weight",
    "enable_identity",
    "identity_threshold",
    "summarisation_threshold",
    "max_entries_per_topic",
    "latency_budget_ms",
    "recall_target",
    "consistency_target",
    "drift_target",
    "evolution",
}
FORBIDDEN_SECURITY_KEYS = {
    "auth_enabled",
    "encryption_required",
    "memory_delete_enabled",
    "production_validation",
    "benchmark_guard",
    "backend_security",
    "model_provider_secrets",
    "allowed_origins",
    "api_key_settings",
    "retention_deletion_policy",
}


def validate_harness_security_policy(config: Dict[str, Any]) -> list[str]:
    errors: list[str] = []
    for key in config:
        if key in FORBIDDEN_SECURITY_KEYS or key not in ALLOWED_HARNESS_KEYS:
            errors.append(f"Harness may not edit security-sensitive key: {key}")
    top_k = int(config.get("top_k", 5) or 5)
    graph_depth = int(config.get("graph_depth", 1) or 1)
    if top_k > 20:
        errors.append("top_k exceeds security budget")
    if graph_depth > 4:
        errors.append("graph_depth exceeds security budget")
    return errors
