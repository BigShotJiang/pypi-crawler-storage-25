"""CORS policy validation."""

from __future__ import annotations

from .validation import is_production


def validate_cors_policy(origins: list[str], *, allow_credentials: bool = True) -> None:
    if is_production() and allow_credentials and "*" in origins:
        raise RuntimeError("Production CORS cannot use wildcard origins with credentials.")
