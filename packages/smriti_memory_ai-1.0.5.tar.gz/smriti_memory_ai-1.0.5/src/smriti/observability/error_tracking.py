"""Optional Sentry-compatible error tracking."""

from __future__ import annotations

import os
from typing import Any, Dict

from smriti.security.redaction import redact_secret


def before_send(event: Dict[str, Any], hint: Dict[str, Any] | None = None) -> Dict[str, Any] | None:
    del hint
    return _redact_event(event)


def _redact_event(value: Any) -> Any:
    if isinstance(value, dict):
        return {key: _redact_event(item) for key, item in value.items() if key.lower() not in {"prompt", "memory", "api_key", "token", "dsn"}}
    if isinstance(value, list):
        return [_redact_event(item) for item in value]
    if isinstance(value, str):
        return redact_secret(value)
    return value


def init_error_tracking() -> Dict[str, Any]:
    dsn = os.getenv("SENTRY_DSN", "")
    if not dsn:
        return {"enabled": False, "reason": "missing_dsn"}
    try:
        import sentry_sdk  # type: ignore

        sentry_sdk.init(
            dsn=dsn,
            environment=os.getenv("SENTRY_ENVIRONMENT", os.getenv("SMRITI_ENV", "development")),
            release=os.getenv("SENTRY_RELEASE"),
            traces_sample_rate=float(os.getenv("SENTRY_TRACES_SAMPLE_RATE", "0.0")),
            profiles_sample_rate=float(os.getenv("SENTRY_PROFILES_SAMPLE_RATE", "0.0")),
            before_send=before_send,
        )
        return {"enabled": True}
    except Exception as exc:
        return {"enabled": False, "reason": exc.__class__.__name__}
