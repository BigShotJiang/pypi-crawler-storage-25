"""Privacy-safe observability context helpers."""

from __future__ import annotations

import hashlib
import os
import subprocess
import uuid
from contextvars import ContextVar
from dataclasses import dataclass
from typing import Any, Dict

from smriti import __version__
from smriti.security.redaction import redact_secret

_REQUEST_ID: ContextVar[str] = ContextVar("smriti_request_id", default="")
_TRACE_ID: ContextVar[str] = ContextVar("smriti_trace_id", default="")


def request_id() -> str:
    value = _REQUEST_ID.get()
    if not value:
        value = str(uuid.uuid4())
        _REQUEST_ID.set(value)
    return value


def set_request_id(value: str | None = None) -> str:
    rid = value or str(uuid.uuid4())
    _REQUEST_ID.set(rid)
    if not _TRACE_ID.get():
        _TRACE_ID.set(str(uuid.uuid4()))
    return rid


def trace_id() -> str:
    value = _TRACE_ID.get()
    if not value:
        value = str(uuid.uuid4())
        _TRACE_ID.set(value)
    return value


def hash_identifier(value: str | None, *, prefix: str = "id") -> str:
    if not value:
        return f"{prefix}:anonymous"
    digest = hashlib.sha256(value.encode("utf-8")).hexdigest()[:16]
    return f"{prefix}:{digest}"


def safe_model_id(model_id: str | None) -> str:
    value = (model_id or "").strip()
    if not value:
        return "unset"
    # Public model IDs are acceptable; secrets/URLs are not.
    if "://" in value or "token" in value.lower():
        return hash_identifier(value, prefix="model")
    return redact_secret(value)


def git_commit() -> str:
    try:
        return subprocess.check_output(["git", "rev-parse", "--short", "HEAD"], text=True).strip()
    except Exception:
        return os.getenv("GIT_COMMIT", "unknown")


@dataclass(frozen=True)
class RuntimeContext:
    request_id: str
    trace_id: str
    environment: str
    release_version: str
    git_commit: str

    def to_attributes(self) -> Dict[str, Any]:
        return {
            "request_id": self.request_id,
            "trace_id": self.trace_id,
            "environment": self.environment,
            "release_version": self.release_version,
            "git_commit": self.git_commit,
        }


def runtime_context() -> RuntimeContext:
    return RuntimeContext(
        request_id=request_id(),
        trace_id=trace_id(),
        environment=os.getenv("OTEL_ENVIRONMENT", os.getenv("SMRITI_ENV", "development")),
        release_version=os.getenv("SENTRY_RELEASE", __version__),
        git_commit=git_commit(),
    )
