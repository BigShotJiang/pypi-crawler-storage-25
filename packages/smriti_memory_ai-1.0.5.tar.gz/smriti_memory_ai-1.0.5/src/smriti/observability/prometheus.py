"""Prometheus metric definitions for Smriti AI."""

from __future__ import annotations

from prometheus_client import Counter, Gauge, Histogram

from . import metric_names as names

ALLOWED_LABELS = ("route", "method", "status_code", "backend_type", "retrieval_mode", "harness_id", "environment", "model_provider", "error_class")

ACTIVE_REQUESTS = Gauge(names.ACTIVE_REQUESTS, "Active in-flight HTTP requests.", ("route", "method"))
RATE_LIMITED_REQUESTS = Counter(names.RATE_LIMITED, "Rate limited requests.", ("route", "method"))
CHAT_REQUESTS = Counter(names.CHAT_REQUESTS, "Chat requests handled.", ("retrieval_mode", "harness_id", "backend_type", "model_provider"))
MODEL_GENERATION_DURATION = Histogram(names.MODEL_GENERATION_DURATION, "Model generation duration.", ("model_provider",))
MODEL_GENERATION_ERRORS = Counter(names.MODEL_GENERATION_ERRORS, "Model generation errors.", ("model_provider", "error_class"))
MODEL_INPUT_TOKENS = Counter(names.MODEL_INPUT_TOKENS, "Input token count estimate.", ("model_provider",))
MODEL_OUTPUT_TOKENS = Counter(names.MODEL_OUTPUT_TOKENS, "Output token count estimate.", ("model_provider",))
MEMORY_RETRIEVAL_TOTAL = Counter(names.MEMORY_RETRIEVAL, "Memory retrieval attempts.", ("retrieval_mode", "backend_type"))
MEMORY_RETRIEVAL_DURATION = Histogram(names.MEMORY_RETRIEVAL_DURATION, "Memory retrieval duration.", ("retrieval_mode", "backend_type"))
MEMORY_HITS = Counter(names.MEMORY_HITS, "Memory retrieval hits.", ("retrieval_mode", "backend_type"))
MEMORY_MISSES = Counter(names.MEMORY_MISSES, "Memory retrieval misses.", ("retrieval_mode", "backend_type"))
MEMORY_WRITE_TOTAL = Counter(names.MEMORY_WRITE, "Memory writes.", ("backend_type",))
MEMORY_DELETE_TOTAL = Counter(names.MEMORY_DELETE, "Memory deletes.", ("backend_type", "status_code"))
AUTH_FAILURES = Counter(names.AUTH_FAILURES, "Auth failures.", ("error_class",))
UNAUTHORIZED_ACCESS = Counter(names.UNAUTHORIZED, "Unauthorized access attempts.", ("route",))
PROMPT_INJECTION_DETECTED = Counter(names.PROMPT_INJECTION, "Prompt injection detections.", ("route",))
SECRET_REDACTION_TOTAL = Counter(names.SECRET_REDACTION, "Secret redaction events.", ("surface",))
OUTPUT_BLOCKED_TOTAL = Counter(names.OUTPUT_BLOCKED, "Blocked unsafe outputs.", ("reason",))
PRODUCTION_VALIDATION_FAILURES = Counter(names.PRODUCTION_VALIDATION_FAILURES, "Production validation failures.", ("component",))
