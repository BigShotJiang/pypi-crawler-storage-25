"""Convenience metric helpers."""

from __future__ import annotations

from .context import hash_identifier


def user_hash(user_id: str | None) -> str:
    return hash_identifier(user_id, prefix="user")


def tenant_hash(tenant_id: str | None) -> str:
    return hash_identifier(tenant_id, prefix="tenant")
