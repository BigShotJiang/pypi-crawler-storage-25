"""Privacy-safe logging helpers."""

from __future__ import annotations

import logging
import os

from smriti.security.redaction import redact_secret
from .context import request_id


class RedactionFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        record.msg = redact_secret(record.getMessage())
        record.args = ()
        record.request_id = getattr(record, "request_id", request_id())
        return True


def configure_logging(logger_name: str = "smriti") -> logging.Logger:
    logger = logging.getLogger(logger_name)
    level = os.getenv("SMRITI_LOG_LEVEL", "info").upper()
    logger.setLevel(getattr(logging, level, logging.INFO))
    if not any(isinstance(flt, RedactionFilter) for flt in logger.filters):
        logger.addFilter(RedactionFilter())
    return logger
