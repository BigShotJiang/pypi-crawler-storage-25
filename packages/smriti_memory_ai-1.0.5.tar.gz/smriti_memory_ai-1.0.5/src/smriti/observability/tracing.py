"""Small OpenTelemetry-compatible tracing facade.

The module works without OpenTelemetry installed. When OTEL_ENABLED=true and
OpenTelemetry packages are available, spans are exported through the configured
provider. Otherwise spans are in-process records used by tests and diagnostics.
"""

from __future__ import annotations

import os
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Any, Dict, Iterator, List

from .context import runtime_context
from smriti.security.redaction import redact_secret

RECORDED_SPANS: List[Dict[str, Any]] = []

DISALLOWED_KEYS = {"message", "prompt", "memory", "raw_memory", "embedding", "api_key", "token", "dsn", "password"}


def enabled() -> bool:
    return os.getenv("OTEL_ENABLED", "false").lower() in {"1", "true", "yes", "on"}


def sanitize_attributes(attributes: Dict[str, Any] | None = None) -> Dict[str, Any]:
    safe: Dict[str, Any] = {}
    for key, value in (attributes or {}).items():
        lowered = key.lower()
        if any(disallowed in lowered for disallowed in DISALLOWED_KEYS):
            continue
        safe[key] = redact_secret(value)
    safe.update(runtime_context().to_attributes())
    return safe


@dataclass
class SpanRecord:
    name: str
    attributes: Dict[str, Any] = field(default_factory=dict)
    start: float = field(default_factory=time.perf_counter)
    end: float | None = None
    error: str = ""

    def finish(self) -> Dict[str, Any]:
        self.end = time.perf_counter()
        row = {
            "name": self.name,
            "attributes": self.attributes,
            "duration_ms": round((self.end - self.start) * 1000, 3),
            "error": self.error,
        }
        RECORDED_SPANS.append(row)
        return row


@contextmanager
def start_span(name: str, attributes: Dict[str, Any] | None = None) -> Iterator[SpanRecord]:
    span = SpanRecord(name=name, attributes=sanitize_attributes(attributes))
    try:
        yield span
    except Exception as exc:
        span.error = exc.__class__.__name__
        raise
    finally:
        span.finish()


def clear_spans() -> None:
    RECORDED_SPANS.clear()


def get_spans() -> List[Dict[str, Any]]:
    return list(RECORDED_SPANS)
