"""Compatibility wrapper for Sentry setup."""

from .error_tracking import before_send, init_error_tracking

__all__ = ["before_send", "init_error_tracking"]
