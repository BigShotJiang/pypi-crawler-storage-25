"""OpenTelemetry setup facade."""

from __future__ import annotations

import os
from typing import Any, Dict


def configure_otel(app: Any | None = None) -> Dict[str, Any]:
    del app
    if os.getenv("OTEL_ENABLED", "false").lower() not in {"1", "true", "yes", "on"}:
        return {"enabled": False, "reason": "disabled"}
    try:
        import opentelemetry  # type: ignore  # noqa: F401
    except Exception:
        return {"enabled": False, "reason": "opentelemetry_not_installed"}
    return {
        "enabled": True,
        "service_name": os.getenv("OTEL_SERVICE_NAME", "smriti-ai"),
        "endpoint": os.getenv("OTEL_EXPORTER_OTLP_ENDPOINT", ""),
    }
