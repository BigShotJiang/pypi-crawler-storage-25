"""Production safety checks for model IDs, test doubles, and public artifacts.

The project keeps deterministic test doubles for CI stability, but production
deployments and public benchmark claims must use real configured models.
"""

from __future__ import annotations

import os
from pathlib import Path


GEMMA4_MODEL_ID = "google/gemma-4-E2B-it"

TRUE_VALUES = {"1", "true", "yes", "on"}
PRODUCTION_ENV_VALUES = {"prod", "production"}

FORBIDDEN_MODEL_TOKENS = (
    "mock",
    "fake",
    "tiny",
    "sshleifer/tiny-gpt2",
    "replace_with",
    "your_org",
)

PLACEHOLDER_VALUES = {
    "",
    "REPLACE_WITH_BASE_MODEL_ID",
    "YOUR_ORG/smriti-ai",
    "your_org/smriti-ai",
}

CANONICAL_PUBLIC_OUTPUTS = {
    "benchmarks/results_comparison.csv",
    "benchmarks/README.md",
    "benchmarks/summary.md",
    "benchmarks/longmem_results.csv",
    "benchmarks/longmem_summary.md",
    "benchmarks/latency_results.csv",
    "benchmarks/results_historical_protocol.csv",
    "benchmarks/results_historical_protocol_responses.json",
    "benchmarks/results_gemma_eval.csv",
    "results/summary.md",
    "model_card_smriti.md",
    "deploy/huggingface_model/README.md",
}


class ProductionSafetyError(RuntimeError):
    """Raised when a test-only setting is used in a production/public path."""


def is_truthy_env(name: str) -> bool:
    """Return True when an environment variable is set to a truthy value."""

    return os.getenv(name, "").strip().lower() in TRUE_VALUES


def is_production_mode() -> bool:
    """Return True when the process is explicitly running as production."""

    return os.getenv("SMRITI_ENV", "").strip().lower() in PRODUCTION_ENV_VALUES


def test_doubles_allowed() -> bool:
    """Return True when deterministic test doubles have been explicitly allowed."""

    return is_truthy_env("SMRITI_ALLOW_TEST_DOUBLES")


def is_placeholder_model_id(model_id: str | None) -> bool:
    """Return True when a model ID is empty or a deployment placeholder."""

    value = (model_id or "").strip()
    return value in PLACEHOLDER_VALUES


def is_test_double_model_id(model_id: str | None) -> bool:
    """Return True when a model ID clearly names a test double or tiny CI model."""

    value = (model_id or "").strip().lower()
    if not value:
        return False
    return any(token in value for token in FORBIDDEN_MODEL_TOKENS)


def require_test_doubles_allowed(feature: str) -> None:
    """Require explicit opt-in before running deterministic test-double paths."""

    if not test_doubles_allowed():
        raise ProductionSafetyError(
            f"{feature} uses deterministic test doubles. Set "
            "SMRITI_ALLOW_TEST_DOUBLES=1 only for CI/internal smoke tests; "
            f"use {GEMMA4_MODEL_ID} for production or reported benchmarks."
        )


def validate_model_id_for_environment(
    model_id: str | None,
    *,
    context: str,
    allow_empty: bool = False,
) -> str:
    """Validate a model ID against production safety policy."""

    value = (model_id or "").strip()
    if not value:
        if allow_empty:
            return ""
        raise ProductionSafetyError(f"{context} requires a real base model ID.")
    if is_placeholder_model_id(value):
        raise ProductionSafetyError(
            f"{context} still uses placeholder model ID {value!r}. "
            f"Set BASE_MODEL_ID={GEMMA4_MODEL_ID} or another real approved model."
        )
    if is_production_mode() and is_test_double_model_id(value):
        raise ProductionSafetyError(
            f"{context} cannot use test-double/tiny model ID {value!r} in production."
        )
    return value


def assert_public_output_allows_test_double(path: str | Path, *, feature: str) -> None:
    """Block deterministic test-double runs from overwriting public artifacts."""

    output = Path(path)
    try:
        rel = output.resolve().relative_to(Path.cwd().resolve()).as_posix()
    except Exception:
        rel = output.as_posix()
    if rel in CANONICAL_PUBLIC_OUTPUTS:
        raise ProductionSafetyError(
            f"{feature} cannot write deterministic test-double results to public artifact "
            f"{rel!r}. Use a temporary/internal output path under results/internal_ci/ "
            "or run the real Gemma 4 benchmark."
        )
