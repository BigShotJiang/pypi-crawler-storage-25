"""FastAPI layer for multi-user, multi-agent Smriti AI memory access."""

from __future__ import annotations

import json
import logging
import os
import time
import uuid
from contextlib import contextmanager
from threading import RLock
from typing import Any, Callable, Dict, Iterator, List, Optional

from fastapi import FastAPI, HTTPException, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from prometheus_client import CONTENT_TYPE_LATEST, Counter, Gauge, Histogram, generate_latest

from .audit_api import create_audit_router
from .auth import AuthContext, authenticate_request, require_admin, require_user_access
from .backends import MemoryBackend, build_backend
from .canary import promote_canary, record_metric, rollback_canary, route_user, start_canary, status as canary_status, stop_canary
from .config import configure_environment_from_file, load_config
from .core import MemPalaceLite
from .harness import apply_harness_to_memory, load_harness_params, load_manifest
from .harness_registry import activate_harness, list_harnesses, load_harness, load_metadata
from .harness_validation import validate_harnesses
from .health import health_summary, live_status, ready_status
from .observability.context import hash_identifier, set_request_id
from .observability.error_tracking import init_error_tracking
from .observability import prometheus as obs_metrics
from .observability.tracing import start_span
from .schemas import (
    CanaryStartRequest,
    ChatRequest,
    ChatResponse,
    GraphQueryRequest,
    HarnessEvaluateRequest,
    HarnessRollbackRequest,
    MemoryDeleteRequest,
    MemoryLoadRequest,
    MemorySaveRequest,
)
from .security import filter_model_output, redact_secret, sanitize_context_block, sanitize_payload
from .security.cors import validate_cors_policy
from .security.deletion import delete_managed_file, purge_memory_object
from .security.headers import apply_security_headers
from .security.validation import enforce_body_size
from .security.vector_security import strip_embedding_fields
from .support.error_report import ErrorReportRequest, store_error_report


AgentFactory = Callable[..., Any]

USER_MEMORIES: Dict[str, MemPalaceLite] = {}
MEMORY_LOCK = RLock()
MEMORY_BACKEND: Optional[MemoryBackend] = None
AGENT_FACTORY: Optional[AgentFactory] = None
RATE_LIMIT_BUCKETS: Dict[str, List[float]] = {}
LOGGER = logging.getLogger("smriti.api")
LOGGER.setLevel(logging.INFO)
if not LOGGER.handlers:
    _handler = logging.StreamHandler()
    _handler.setFormatter(logging.Formatter("%(levelname)s:%(name)s:%(message)s"))
    LOGGER.addHandler(_handler)
LOGGER.propagate = False

HTTP_REQUESTS = Counter(
    "smriti_http_requests_total",
    "Total HTTP requests handled by the Smriti AI API.",
    ("method", "path", "status"),
)
HTTP_ERRORS = Counter(
    "smriti_http_errors_total",
    "Total HTTP requests that completed with status >= 500.",
    ("method", "path"),
)
HTTP_LATENCY = Histogram(
    "smriti_http_request_latency_seconds",
    "End-to-end HTTP request latency.",
    ("method", "path"),
)
RETRIEVAL_LATENCY = Histogram(
    "smriti_retrieval_latency_seconds",
    "Memory retrieval latency for chat requests.",
    ("retrieval_mode",),
)
TOKEN_USAGE = Counter(
    "smriti_tokens_total",
    "Approximate whitespace-token count observed by the API.",
    ("user_hash", "agent_id"),
)
USER_MEMORY_COUNT = Gauge(
    "smriti_user_memories",
    "Number of in-memory user memory stores.",
)
USER_MEMORY_BYTES = Gauge(
    "smriti_user_memory_bytes",
    "Approximate serialized memory size by hashed user.",
    ("user_hash",),
)


def set_agent_factory(factory: Optional[AgentFactory]) -> None:
    """
    Register a callable that returns a configured model agent.

    The callable receives `user_id`, `memory`, `topic_id`, and `agent_id`.
    When no factory is configured, `/chat` runs in memory-only mode.
    """

    global AGENT_FACTORY
    AGENT_FACTORY = factory


def set_memory_backend(backend: Optional[MemoryBackend]) -> None:
    """Override the configured persistence backend for tests or deployments."""

    global MEMORY_BACKEND
    MEMORY_BACKEND = backend


def get_memory_backend() -> MemoryBackend:
    """Return the configured durable backend, constructing it lazily from env."""

    global MEMORY_BACKEND
    if MEMORY_BACKEND is None:
        configure_environment_from_file()
        MEMORY_BACKEND = build_backend()
    return MEMORY_BACKEND


def get_memory(user_id: str, retrieval_mode: Optional[str] = None) -> MemPalaceLite:
    with MEMORY_LOCK:
        if user_id not in USER_MEMORIES:
            harness_params = load_harness_params()
            memory_mode = retrieval_mode or harness_params.memory_retrieval_mode
            state = None
            try:
                state = get_memory_backend().load(user_id)
            except Exception:
                LOGGER.exception("Durable memory load failed; starting empty memory")
            if state:
                memory = MemPalaceLite.from_dict(
                    state,
                    retrieval_mode=memory_mode,
                    harness_params=harness_params,
                )
                memory.session_id = user_id
            else:
                memory = MemPalaceLite(
                    retrieval_mode=memory_mode,
                    session_id=user_id,
                    harness_params=harness_params,
                )
            USER_MEMORIES[user_id] = memory
            USER_MEMORY_COUNT.set(len(USER_MEMORIES))
        return USER_MEMORIES[user_id]


def create_app() -> FastAPI:
    config = configure_environment_from_file()
    validate_cors_policy(config.cors_origins, allow_credentials=True)
    init_error_tracking()
    app = FastAPI(
        title="Smriti AI API",
        version="1.0.0",
        description="Semantic memory, knowledge graph and identity governance API.",
    )
    app.add_middleware(
        CORSMiddleware,
        allow_origins=config.cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    @app.middleware("http")
    async def request_observability(request: Request, call_next: Callable[..., Any]) -> Response:
        request_id = set_request_id(request.headers.get("x-request-id", str(uuid.uuid4())))
        path = request.url.path
        start = time.perf_counter()
        status_code = 500
        obs_metrics.ACTIVE_REQUESTS.labels(path, request.method).inc()
        try:
            with start_span("request.http", {"route": path, "method": request.method}):
                await enforce_body_size(request)
                request.state.auth = authenticate_request(request)
                _enforce_rate_limit(request)
                response = await call_next(request)
                status_code = response.status_code
        except HTTPException as exc:
            status_code = exc.status_code
            if status_code == 401:
                obs_metrics.AUTH_FAILURES.labels(exc.__class__.__name__).inc()
            if status_code == 403:
                obs_metrics.UNAUTHORIZED_ACCESS.labels(path).inc()
            if status_code == 429:
                obs_metrics.RATE_LIMITED_REQUESTS.labels(path, request.method).inc()
            detail = redact_secret(exc.detail)
            response = Response(
                content=json.dumps({"detail": detail}),
                status_code=exc.status_code,
                media_type="application/json",
            )
        except Exception:
            LOGGER.exception(
                "Unhandled API request failure",
                extra={"request_id": request_id, "path": path},
            )
            response = Response(
                content='{"detail":"Internal server error"}',
                status_code=500,
                media_type="application/json",
            )
        duration = time.perf_counter() - start
        obs_metrics.ACTIVE_REQUESTS.labels(path, request.method).dec()
        HTTP_LATENCY.labels(request.method, path).observe(duration)
        HTTP_REQUESTS.labels(request.method, path, str(status_code)).inc()
        if status_code >= 500:
            HTTP_ERRORS.labels(request.method, path).inc()
        USER_MEMORY_COUNT.set(len(USER_MEMORIES))
        response.headers["x-request-id"] = request_id
        apply_security_headers(
            response,
            sensitive=path.startswith(("/chat", "/memory", "/graph", "/harness", "/audit", "/metrics")),
        )
        LOGGER.info(
            "request completed request_id=%s method=%s path=%s status=%s duration_s=%.6f",
            request_id,
            request.method,
            path,
            status_code,
            duration,
        )
        return response

    @app.get("/live")
    def live() -> Dict[str, Any]:
        return live_status()

    @app.get("/ready")
    def ready() -> Dict[str, Any]:
        return ready_status(backend_check=lambda: get_memory_backend().load("__smriti_readiness_probe__"))

    @app.get("/health")
    def health() -> Dict[str, Any]:
        return health_summary(memory_users=len(USER_MEMORIES), backend_check=lambda: get_memory_backend().load("__smriti_health_probe__"))

    @app.get("/metrics")
    def metrics() -> Response:
        return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)

    @app.post("/chat", response_model=ChatResponse)
    def chat(request: ChatRequest, http_request: Request) -> ChatResponse:
        require_user_access(_auth_context(http_request), request.user_id, tenant_id=request.tenant_id)
        backend_type = load_config().backend
        model_provider = load_config().model_adapter
        with start_span(
            "harness.select",
            {
                "user_hash": hash_identifier(request.user_id, prefix="user"),
                "tenant_hash": hash_identifier(request.tenant_id, prefix="tenant"),
            },
        ):
            harness_id = route_user(request.user_id)
            try:
                harness_params = load_harness(harness_id)
            except Exception:
                harness_params = load_harness_params()
        retrieval_mode = request.retrieval_mode or harness_params.memory_retrieval_mode
        obs_metrics.CHAT_REQUESTS.labels(retrieval_mode, harness_id, backend_type, model_provider).inc()
        memory = get_memory(request.user_id, retrieval_mode=retrieval_mode)
        apply_harness_to_memory(memory, harness_params)
        memory.retrieval_mode = retrieval_mode
        memory.topic_id = request.topic_id
        started = time.perf_counter()
        with start_span("memory.retrieve", {"retrieval_mode": retrieval_mode, "backend_type": backend_type, "harness_id": harness_id}):
            retrieval_started = time.perf_counter()
            context, degraded, warnings = _safe_get_context(
                memory,
                query=request.message,
                session_id=request.user_id,
                topic_id=request.topic_id,
                retrieval_mode=retrieval_mode,
            )
            obs_metrics.MEMORY_RETRIEVAL_TOTAL.labels(retrieval_mode, backend_type).inc()
            obs_metrics.MEMORY_RETRIEVAL_DURATION.labels(retrieval_mode, backend_type).observe(time.perf_counter() - retrieval_started)
            if context:
                obs_metrics.MEMORY_HITS.labels(retrieval_mode, backend_type).inc()
            else:
                obs_metrics.MEMORY_MISSES.labels(retrieval_mode, backend_type).inc()

        if AGENT_FACTORY is not None:
            agent = _build_agent(
                AGENT_FACTORY,
                user_id=request.user_id,
                memory=memory,
                topic_id=request.topic_id,
                agent_id=request.agent_id,
            )
            with MEMORY_LOCK:
                try:
                    with start_span("model.generate", {"model_provider": model_provider}):
                        model_started = time.perf_counter()
                        response = agent.chat(request.message)
                        obs_metrics.MODEL_GENERATION_DURATION.labels(model_provider).observe(time.perf_counter() - model_started)
                except Exception as exc:
                    LOGGER.exception("Agent factory chat failed")
                    obs_metrics.MODEL_GENERATION_ERRORS.labels(model_provider, exc.__class__.__name__).inc()
                    degraded = True
                    warnings.append(f"agent_failure:{exc.__class__.__name__}")
                    response = _memory_only_response(context)
                state = memory.to_dict()
        else:
            response = _memory_only_response(context)
            with MEMORY_LOCK:
                _safe_update_memory(
                    memory,
                    request.message,
                    response,
                    request.user_id,
                    request.topic_id,
                    warnings,
                )
                state = memory.to_dict()
                _persist_if_configured(request.user_id, state, warnings)

        filtered = filter_model_output(response)
        if filtered.blocked:
            warnings.append(f"output_filter:{filtered.reason}")
            obs_metrics.OUTPUT_BLOCKED_TOTAL.labels(filtered.reason).inc()
        response = filtered.text

        input_tokens = _count_tokens(request.message)
        output_tokens = _count_tokens(response)
        obs_metrics.MODEL_INPUT_TOKENS.labels(model_provider).inc(input_tokens)
        obs_metrics.MODEL_OUTPUT_TOKENS.labels(model_provider).inc(output_tokens)
        TOKEN_USAGE.labels(hash_identifier(request.user_id, prefix="user"), request.agent_id).inc(
            input_tokens + output_tokens
        )
        state["_degraded"] = degraded
        state["_warnings"] = warnings
        state["_harness_id"] = harness_id
        state = strip_embedding_fields(state)
        record_metric(harness_id, latency_ms=(time.perf_counter() - started) * 1000, error=degraded)
        return ChatResponse(
            user_id=request.user_id,
            agent_id=request.agent_id,
            topic_id=request.topic_id,
            response=response,
            retrieved_context=context,
            memory=sanitize_payload(state),
        )

    @app.post("/memory/load")
    def load_memory(request: MemoryLoadRequest, http_request: Request) -> Dict[str, Any]:
        require_user_access(_auth_context(http_request), request.user_id)
        harness_params = load_harness_params()
        retrieval_mode = request.retrieval_mode or harness_params.memory_retrieval_mode
        with MEMORY_LOCK:
            if request.path:
                memory = MemPalaceLite.load(
                    request.path,
                    retrieval_mode=retrieval_mode,
                    harness_params=harness_params,
                )
            elif request.memory:
                memory = MemPalaceLite.from_dict(
                    request.memory or {},
                    retrieval_mode=retrieval_mode,
                    harness_params=harness_params,
                )
            else:
                state = get_memory_backend().load(request.user_id)
                if state is None:
                    raise HTTPException(status_code=404, detail="No memory found for user.")
                memory = MemPalaceLite.from_dict(
                    state,
                    retrieval_mode=retrieval_mode,
                    harness_params=harness_params,
                )
            memory.session_id = request.user_id
            USER_MEMORIES[request.user_id] = memory
            return memory.to_dict()

    @app.post("/memory/save")
    def save_memory(request: MemorySaveRequest, http_request: Request) -> Dict[str, Any]:
        require_user_access(_auth_context(http_request), request.user_id)
        memory = get_memory(request.user_id)
        with MEMORY_LOCK:
            if request.path:
                memory.save(request.path)
            state = memory.to_dict()
            if not request.path:
                get_memory_backend().save(request.user_id, state)
                obs_metrics.MEMORY_WRITE_TOTAL.labels(load_config().backend).inc()
                _observe_memory_size(request.user_id, state)
            return state

    @app.post("/memory/delete")
    def delete_memory(request: MemoryDeleteRequest, http_request: Request) -> Dict[str, Any]:
        require_user_access(_auth_context(http_request), request.user_id)
        backend_type = load_config().backend
        with start_span("memory.delete", {"backend_type": backend_type}), MEMORY_LOCK:
            memory_obj = USER_MEMORIES.pop(request.user_id, None)
            existed = memory_obj is not None
            purged = purge_memory_object(memory_obj)
            USER_MEMORY_COUNT.set(len(USER_MEMORIES))
            deleted_file = delete_managed_file(request.path)
            deleted_backend = False
            try:
                deleted_backend = get_memory_backend().delete_user(request.user_id)
            except Exception:
                LOGGER.exception("Durable memory deletion failed")
                obs_metrics.MEMORY_DELETE_TOTAL.labels(backend_type, "500").inc()
            try:
                USER_MEMORY_BYTES.remove(hash_identifier(request.user_id, prefix="user"))
            except Exception:
                pass
            obs_metrics.MEMORY_DELETE_TOTAL.labels(backend_type, "200").inc()
            return {
                "user_id": request.user_id,
                "deleted_memory": existed,
                "purged_layers": purged,
                "deleted_file": deleted_file,
                "deleted_backend": deleted_backend,
                "remaining_users": len(USER_MEMORIES),
            }

    @app.post("/graph/query")
    def graph_query(request: GraphQueryRequest, http_request: Request) -> Dict[str, Any]:
        require_user_access(_auth_context(http_request), request.user_id)
        memory = get_memory(request.user_id)
        try:
            triples = memory.knowledge_graph.query_graph(
                request.user_id,
                request.query_entity,
                depth=request.depth,
                topic_id=request.topic_id,
            )
            degraded = False
            warnings: List[str] = []
        except Exception as exc:
            LOGGER.exception("Knowledge graph query failed")
            triples = []
            degraded = True
            warnings = [f"knowledge_graph_failure:{exc.__class__.__name__}"]
        return {
            "user_id": request.user_id,
            "query_entity": request.query_entity,
            "triples": [triple.__dict__ for triple in triples],
            "facts": memory.knowledge_graph.triples_to_text(triples),
            "degraded": degraded,
            "warnings": warnings,
        }

    @app.get("/harness/current")
    def harness_current() -> Dict[str, Any]:
        params = load_harness_params()
        return {
            "active_harness": os.getenv("SMRITI_HARNESS_ID", "config"),
            "params": params.to_dict(),
            "registry": list_harnesses(),
        }

    @app.get("/harness/history")
    def harness_history() -> Dict[str, Any]:
        return {"manifest": load_manifest()}

    @app.get("/harness/metrics")
    def harness_metrics() -> Dict[str, Any]:
        validation = "results/harness_evolution_validation.json"
        payload = {}
        if os.path.exists(validation):
            with open(validation, encoding="utf-8") as handle:
                payload = json.load(handle)
        return {"validation": payload, "canary": canary_status()}

    @app.post("/harness/rollback")
    def harness_rollback(request: HarnessRollbackRequest, http_request: Request) -> Dict[str, Any]:
        require_admin(_auth_context(http_request))
        state = activate_harness(request.harness_id)
        return {"rolled_back_to": request.harness_id, "state": state}

    @app.post("/harness/evaluate")
    def harness_evaluate(request: HarnessEvaluateRequest, http_request: Request) -> Dict[str, Any]:
        require_admin(_auth_context(http_request))
        result = validate_harnesses(
            seed_config=f"harnesses/{request.seed_harness_id}/harness_params.yaml",
            evolved_config=f"harnesses/{request.evolved_harness_id}/harness_params.yaml",
        )
        return result

    @app.get("/harness/canary/status")
    def harness_canary_status() -> Dict[str, Any]:
        return canary_status()

    @app.post("/harness/canary/start")
    def harness_canary_start(request: CanaryStartRequest, http_request: Request) -> Dict[str, Any]:
        require_admin(_auth_context(http_request))
        load_metadata(request.active_harness)
        load_metadata(request.canary_harness)
        return start_canary(
            request.active_harness,
            request.canary_harness,
            request.canary_percentage,
        )

    @app.post("/harness/canary/stop")
    def harness_canary_stop(http_request: Request) -> Dict[str, Any]:
        require_admin(_auth_context(http_request))
        return stop_canary()

    @app.post("/harness/canary/promote")
    def harness_canary_promote(http_request: Request) -> Dict[str, Any]:
        require_admin(_auth_context(http_request))
        return promote_canary()

    @app.post("/harness/canary/rollback")
    def harness_canary_rollback(http_request: Request) -> Dict[str, Any]:
        require_admin(_auth_context(http_request))
        return rollback_canary("api_request")

    @app.get("/status")
    def service_status() -> Dict[str, Any]:
        return {
            "service": "Smriti AI",
            "health": health_summary(memory_users=len(USER_MEMORIES)),
            "known_incidents": [],
            "planned_maintenance": [],
        }

    @app.post("/support/report-error")
    def support_report_error(request: ErrorReportRequest, http_request: Request) -> Dict[str, Any]:
        if request.user_id:
            require_user_access(_auth_context(http_request), request.user_id)
        return store_error_report(request)

    app.include_router(
        create_audit_router(
            get_memory_backend,
            _auth_context,
            lambda user_id: USER_MEMORIES[user_id].to_dict() if user_id in USER_MEMORIES else None,
        )
    )
    return app


def reset_rate_limits() -> None:
    """Clear in-memory rate-limit buckets for deterministic tests."""

    RATE_LIMIT_BUCKETS.clear()


def _auth_context(request: Request) -> AuthContext:
    return getattr(request.state, "auth", AuthContext(key_id="disabled", role="admin"))


def _enforce_rate_limit(request: Request) -> None:
    if os.getenv("SMRITI_RATE_LIMIT_ENABLED", "false").lower() not in {"1", "true", "yes", "on"}:
        return
    limit = int(os.getenv("SMRITI_RATE_LIMIT_PER_MINUTE", "60"))
    if limit <= 0:
        return
    identity = request.headers.get("x-api-key") or request.client.host if request.client else "anonymous"
    now = time.time()
    window_start = now - 60.0
    with MEMORY_LOCK:
        bucket = [stamp for stamp in RATE_LIMIT_BUCKETS.get(identity, []) if stamp >= window_start]
        if len(bucket) >= limit:
            RATE_LIMIT_BUCKETS[identity] = bucket
            raise HTTPException(status_code=429, detail="Rate limit exceeded.")
        bucket.append(now)
        RATE_LIMIT_BUCKETS[identity] = bucket


def _build_agent(factory: AgentFactory, **kwargs: Any) -> Any:
    try:
        return factory(**kwargs)
    except TypeError:
        return factory(kwargs["memory"])


def _memory_only_response(context: str) -> str:
    if context:
        bullets = []
        for line in context.splitlines():
            cleaned = line.strip()
            if cleaned.startswith("* "):
                bullets.append(cleaned[2:].strip())
        if bullets:
            rendered = "\n".join(f"- {fact}" for fact in bullets[:5])
            return f"Memory updated. I found relevant context:\n{rendered}"
        return "Memory updated. Relevant context is available for the configured model."
    return "Memory updated. No prior relevant context was found."


def _safe_get_context(
    memory: MemPalaceLite,
    query: str,
    session_id: str,
    topic_id: str,
    retrieval_mode: str,
) -> tuple[str, bool, List[str]]:
    warnings: List[str] = []
    with _observe_retrieval(retrieval_mode):
        try:
            return (
                sanitize_context_block(
                    memory.get_context(
                        query=query,
                        session_id=session_id,
                        topic_id=topic_id,
                    )
                ),
                False,
                warnings,
            )
        except Exception as exc:
            LOGGER.exception("Primary retrieval failed; degrading to TF-IDF/no-graph context")
            warnings.append(f"primary_retrieval_failure:{exc.__class__.__name__}")

    original_mode = memory.retrieval_mode
    try:
        memory.retrieval_mode = "tfidf"
        with _observe_retrieval("tfidf"):
            context = sanitize_context_block(
                memory.get_context(
                    query=query,
                    session_id=session_id,
                    topic_id=topic_id,
                    include_graph=False,
                )
            )
        warnings.append("degraded_to_tfidf")
        return context, True, warnings
    except Exception as exc:
        LOGGER.exception("Fallback TF-IDF retrieval failed")
        warnings.append(f"fallback_retrieval_failure:{exc.__class__.__name__}")
        return "", True, warnings
    finally:
        memory.retrieval_mode = original_mode


def _safe_update_memory(
    memory: MemPalaceLite,
    user_message: str,
    response: str,
    session_id: str,
    topic_id: str,
    warnings: List[str],
) -> None:
    try:
        for fact in memory.extract_facts("", user_input=user_message):
            try:
                memory.add_fact(fact, session_id=session_id, topic_id=topic_id)
            except Exception as exc:
                LOGGER.exception("Fact storage failed")
                warnings.append(f"fact_storage_failure:{exc.__class__.__name__}")
        memory.add_to_history("User: " + user_message, "user_input")
        memory.add_to_history("Assistant: " + response[:200], "assistant_output")
    except Exception as exc:
        LOGGER.exception("Memory update failed")
        warnings.append(f"memory_update_failure:{exc.__class__.__name__}")


def _persist_if_configured(user_id: str, state: Dict[str, Any], warnings: List[str]) -> None:
    if os.getenv("SMRITI_AUTOSAVE", "0").lower() not in {"1", "true", "yes"}:
        _observe_memory_size(user_id, state)
        return
    try:
        get_memory_backend().save(user_id, state)
        _observe_memory_size(user_id, state)
    except Exception as exc:
        LOGGER.exception("Durable memory autosave failed")
        warnings.append(f"autosave_failure:{exc.__class__.__name__}")


def _observe_memory_size(user_id: str, state: Dict[str, Any]) -> None:
    try:
        USER_MEMORY_BYTES.labels(hash_identifier(user_id, prefix="user")).set(len(json.dumps(state)))
    except Exception:
        pass


@contextmanager
def _observe_retrieval(retrieval_mode: str) -> Iterator[None]:
    start = time.perf_counter()
    try:
        yield
    finally:
        RETRIEVAL_LATENCY.labels(retrieval_mode).observe(time.perf_counter() - start)


def _count_tokens(text: str) -> int:
    return max(1, len(text.split())) if text else 0


app = create_app()


def main(argv: Optional[List[str]] = None) -> None:
    """Run the API with `python -m smriti.api` or the `smriti-api` entry point."""

    import argparse
    import uvicorn

    parser = argparse.ArgumentParser(description="Run the Smriti AI FastAPI service.")
    parser.add_argument("--config", help="Path to config.yaml.")
    parser.add_argument("--host", help="Bind host. Defaults to config or SMRITI_HOST.")
    parser.add_argument("--port", type=int, help="Bind port. Defaults to config or SMRITI_PORT.")
    parser.add_argument("--reload", action="store_true", help="Enable Uvicorn reload mode.")
    args = parser.parse_args(argv)
    if args.config:
        os.environ["SMRITI_CONFIG_PATH"] = args.config
    config = load_config()
    uvicorn.run(
        "smriti.api:app" if args.reload else app,
        host=args.host or os.getenv("SMRITI_HOST", config.host),
        port=args.port or int(os.getenv("SMRITI_PORT", config.port)),
        reload=args.reload,
    )


if __name__ == "__main__":
    main()
