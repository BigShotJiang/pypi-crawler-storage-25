"""Run the Smriti AI CLI with `python -m smriti`."""

from .cli import main


if __name__ == "__main__":
    raise SystemExit(main())
