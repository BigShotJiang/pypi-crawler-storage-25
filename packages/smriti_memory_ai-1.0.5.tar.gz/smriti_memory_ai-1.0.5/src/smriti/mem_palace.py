"""Compatibility module for older `mempalace.mem_palace` imports."""

from .core import MemoryEntry, MemPalaceLite

__all__ = ["MemoryEntry", "MemPalaceLite"]
