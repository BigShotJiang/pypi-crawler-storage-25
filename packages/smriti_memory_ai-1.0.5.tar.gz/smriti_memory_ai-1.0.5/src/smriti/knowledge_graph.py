"""Session-scoped knowledge graph memory for lightweight fact traversal."""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Optional, Tuple


@dataclass(frozen=True)
class GraphTriple:
    """A subject-relation-object fact stored in graph memory."""

    subject: str
    relation: str
    object: str
    topic_id: str = "general"

    def to_text(self) -> str:
        return f"{self.subject} {self.relation} {self.object}."


class KnowledgeGraphMemory:
    """
    Directed graph memory keyed by session and topic.

    NetworkX is used when installed. A tiny fallback graph keeps local tests and
    imports working in environments where dependencies have not been installed
    yet, but packaged installs will use `networkx.DiGraph`.
    """

    def __init__(self):
        self.nx = _try_import_networkx()
        self.graphs: Dict[str, Dict[str, Any]] = {}

    def add_statement(
        self,
        session_id: str,
        topic_id: str,
        statement: str,
    ) -> List[GraphTriple]:
        """Extract simple triples from a statement and add them to graph memory."""

        triples = extract_triples(statement)
        for triple in triples:
            self.add_triple(
                session_id,
                triple.subject,
                triple.relation,
                triple.object,
                topic_id=topic_id,
            )
        return triples

    def add_triple(
        self,
        session_id: str,
        subject: str,
        relation: str,
        object_: str,
        topic_id: str = "general",
    ) -> GraphTriple:
        """Add a subject-relation-object edge to a session/topic graph."""

        triple = GraphTriple(
            subject=_clean_entity(subject),
            relation=_clean_relation(relation),
            object=_clean_entity(object_),
            topic_id=topic_id,
        )
        if not triple.subject or not triple.relation or not triple.object:
            raise ValueError("subject, relation and object_ must be non-empty.")

        graph = self._get_graph(session_id, topic_id)
        subj_key = _node_key(triple.subject)
        obj_key = _node_key(triple.object)
        _add_node(graph, subj_key, label=triple.subject)
        _add_node(graph, obj_key, label=triple.object)

        edge_data = _get_edge_data(graph, subj_key, obj_key) or {}
        relations = set(edge_data.get("relations", []))
        relations.add(triple.relation)
        _add_edge(graph, subj_key, obj_key, relations=sorted(relations))
        return triple

    def query_graph(
        self,
        session_id: str,
        query_entity: str,
        depth: int = 1,
        topic_id: Optional[str] = None,
    ) -> List[GraphTriple]:
        """Traverse outward and inward from matching entities and return facts."""

        if not query_entity.strip():
            return []
        query_candidates = _query_candidates(query_entity)
        topics = self.graphs.get(session_id, {})
        selected = (
            {topic_id: topics.get(topic_id)}
            if topic_id
            else topics
        )

        results: List[GraphTriple] = []
        seen: set[Tuple[str, str, str, str]] = set()
        for current_topic, graph in selected.items():
            if graph is None:
                continue
            starts = []
            for candidate in query_candidates:
                starts.extend(self._matching_nodes(graph, candidate))
            starts = list(dict.fromkeys(starts))
            for start in starts:
                for subj, obj, data in _traverse_edges(graph, start, depth):
                    subject = _node_label(graph, subj)
                    object_ = _node_label(graph, obj)
                    for relation in data.get("relations", []):
                        key = (current_topic, subject, relation, object_)
                        if key in seen:
                            continue
                        seen.add(key)
                        results.append(GraphTriple(subject, relation, object_, current_topic))
        return results

    def triples_to_text(self, triples: Iterable[GraphTriple]) -> List[str]:
        return [triple.to_text() for triple in triples]

    def to_dict(self) -> Dict[str, Any]:
        sessions: Dict[str, Dict[str, List[Dict[str, str]]]] = {}
        for session_id, topics in self.graphs.items():
            sessions[session_id] = {}
            for topic_id, graph in topics.items():
                triples = []
                for subj, obj, data in _all_edges(graph):
                    for relation in data.get("relations", []):
                        triples.append(
                            {
                                "subject": _node_label(graph, subj),
                                "relation": relation,
                                "object": _node_label(graph, obj),
                            }
                        )
                sessions[session_id][topic_id] = triples
        return {"version": 1, "sessions": sessions}

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "KnowledgeGraphMemory":
        inst = cls()
        for session_id, topics in data.get("sessions", {}).items():
            for topic_id, triples in topics.items():
                for triple in triples:
                    inst.add_triple(
                        session_id,
                        triple["subject"],
                        triple["relation"],
                        triple["object"],
                        topic_id=topic_id,
                    )
        return inst

    def _get_graph(self, session_id: str, topic_id: str) -> Any:
        session = self.graphs.setdefault(session_id, {})
        if topic_id not in session:
            session[topic_id] = self.nx.DiGraph() if self.nx else _SimpleDiGraph()
        return session[topic_id]

    def _matching_nodes(self, graph: Any, query: str) -> List[str]:
        query_key = _node_key(query)
        matches = []
        for node in _nodes(graph):
            label = _node_label(graph, node)
            node_key = _node_key(label)
            if query_key in node_key or node_key in query_key:
                matches.append(node)
        return matches


def extract_triples(text: str) -> List[GraphTriple]:
    """Extract simple triples with conservative regex patterns."""

    triples: List[GraphTriple] = []
    sentence_parts: List[str] = []
    for sentence in [s.strip() for s in re.split(r"[.!?\n]+", text) if s.strip()]:
        sentence_parts.extend(_split_clauses(sentence))
    patterns = [
        (r"^(my name) is ([\w .,'-]+)$", "user", "name is", 2),
        (r"^i (?:am|'m) (?:a |an )?([\w .,'-]+)$", "user", "is", 1),
        (r"^i work (?:at|for) ([\w .,'-]+)$", "user", "works at", 1),
        (r"^i work as (?:a |an )?([\w .,'-]+)$", "user", "works as", 1),
        (r"^i (?:live|am based) (?:in|at) ([\w .,'-]+)$", "user", "lives in", 1),
        (r"^i (?:study|studying|research|researching|build|building) ([\w .,'-]+)$", "user", "works on", 1),
        (r"^([\w .,'-]+?) is (?:a |an |the )?([\w .,'-]+)$", 1, "is", 2),
        (r"^([\w .,'-]+?) works (?:at|for) ([\w .,'-]+)$", 1, "works at", 2),
        (r"^([\w .,'-]+?) lives in ([\w .,'-]+)$", 1, "lives in", 2),
        (r"^([\w .,'-]+?) (?:studies|researches|builds|uses|likes) ([\w .,'-]+)$", 1, "relates to", 2),
    ]
    for sentence in sentence_parts:
        lowered = sentence.lower().strip()
        for pattern, subject_group, relation, object_group in patterns:
            match = re.match(pattern, lowered, flags=re.IGNORECASE)
            if not match:
                continue
            subject = subject_group if isinstance(subject_group, str) else match.group(subject_group)
            object_ = match.group(object_group)
            triples.append(
                GraphTriple(
                    subject=_clean_entity(subject),
                    relation=_clean_relation(relation),
                    object=_clean_entity(object_),
                )
            )
            break
    return triples


class _SimpleDiGraph:
    def __init__(self):
        self.node_attrs: Dict[str, Dict[str, Any]] = {}
        self.edges: Dict[Tuple[str, str], Dict[str, Any]] = {}

    def add_node(self, node: str, **attrs: Any) -> None:
        self.node_attrs.setdefault(node, {}).update(attrs)

    def add_edge(self, source: str, target: str, **attrs: Any) -> None:
        self.edges[(source, target)] = attrs

    def has_edge(self, source: str, target: str) -> bool:
        return (source, target) in self.edges

    def get_edge_data(self, source: str, target: str, default: Any = None) -> Any:
        return self.edges.get((source, target), default)

    def successors(self, node: str) -> List[str]:
        return [target for source, target in self.edges if source == node]

    def predecessors(self, node: str) -> List[str]:
        return [source for source, target in self.edges if target == node]

    @property
    def nodes(self) -> Dict[str, Dict[str, Any]]:
        return self.node_attrs


def _try_import_networkx() -> Any:
    try:
        import networkx as nx

        return nx
    except Exception:
        return None


def _clean_entity(value: str) -> str:
    return re.sub(r"\s+", " ", value.strip(" .,'\"")).strip()


def _clean_relation(value: str) -> str:
    return re.sub(r"\s+", " ", value.strip().lower())


def _node_key(value: str) -> str:
    return _clean_entity(value).lower()


def _split_clauses(sentence: str) -> List[str]:
    clauses = []
    remaining = sentence.strip()
    while True:
        match = re.search(r"\s+and\s+(?=i\s)", remaining, flags=re.IGNORECASE)
        if not match:
            clauses.append(remaining)
            break
        clauses.append(remaining[: match.start()])
        remaining = remaining[match.end() :]
    return [clause.strip() for clause in clauses if clause.strip()]


def _query_candidates(query: str) -> List[str]:
    cleaned = _clean_entity(query.rstrip("?"))
    lowered = cleaned.lower()
    candidates = [cleaned]
    question_patterns = [
        r"^who\s+\w+\s+(.+)$",
        r"^what\s+did\s+(.+?)\s+\w+",
        r"^what\s+is\s+(.+)$",
        r"^tell\s+me\s+about\s+(.+)$",
    ]
    for pattern in question_patterns:
        match = re.search(pattern, lowered)
        if match:
            candidates.append(match.group(1))
    for match in re.finditer(r"\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\b", query):
        candidates.append(match.group(0))
    stop = {
        "who", "what", "when", "where", "why", "how", "did", "does", "do",
        "is", "are", "was", "were", "the", "a", "an", "discover", "discovered",
    }
    for token in re.findall(r"[a-zA-Z0-9][a-zA-Z0-9'-]{2,}", lowered):
        if token not in stop:
            candidates.append(token)
    deduped = []
    seen = set()
    for candidate in candidates:
        candidate = _clean_entity(candidate)
        key = candidate.lower()
        if candidate and key not in seen:
            seen.add(key)
            deduped.append(candidate)
    return deduped


def _add_node(graph: Any, node: str, **attrs: Any) -> None:
    graph.add_node(node, **attrs)


def _add_edge(graph: Any, source: str, target: str, **attrs: Any) -> None:
    graph.add_edge(source, target, **attrs)


def _get_edge_data(graph: Any, source: str, target: str) -> Optional[Dict[str, Any]]:
    return graph.get_edge_data(source, target, default=None)


def _node_label(graph: Any, node: str) -> str:
    try:
        return graph.nodes[node].get("label", node)
    except Exception:
        return graph.nodes.get(node, {}).get("label", node)


def _nodes(graph: Any) -> List[str]:
    try:
        return list(graph.nodes)
    except Exception:
        return list(graph.nodes.keys())


def _all_edges(graph: Any) -> Iterable[Tuple[str, str, Dict[str, Any]]]:
    if hasattr(graph, "edges") and callable(getattr(graph, "edges")):
        return graph.edges(data=True)
    return [(source, target, data) for (source, target), data in graph.edges.items()]


def _edge_between(graph: Any, source: str, target: str) -> Dict[str, Any]:
    return graph.get_edge_data(source, target, default={}) or {}


def _traverse_edges(graph: Any, start: str, depth: int) -> Iterable[Tuple[str, str, Dict[str, Any]]]:
    max_depth = max(1, depth)
    queue: List[Tuple[str, int]] = [(start, 0)]
    visited = {start}
    emitted: set[Tuple[str, str]] = set()

    while queue:
        node, current_depth = queue.pop(0)
        if current_depth >= max_depth:
            continue
        neighbours = list(graph.successors(node)) + list(graph.predecessors(node))
        for neighbour in neighbours:
            for source, target in ((node, neighbour), (neighbour, node)):
                if graph.has_edge(source, target) and (source, target) not in emitted:
                    emitted.add((source, target))
                    yield source, target, _edge_between(graph, source, target)
            if neighbour not in visited:
                visited.add(neighbour)
                queue.append((neighbour, current_depth + 1))
