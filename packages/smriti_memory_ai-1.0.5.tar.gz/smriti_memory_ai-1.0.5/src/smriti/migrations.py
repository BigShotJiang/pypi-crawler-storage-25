"""Schema migration helpers for Smriti AI durable backends."""

from __future__ import annotations

import sqlite3
from importlib import resources
from pathlib import Path


SCHEMA_VERSION = 2


def load_schema_sql(name: str) -> str:
    """Load a packaged SQL migration file."""

    return resources.files("smriti.sql").joinpath(name).read_text(encoding="utf-8")


def migrate_sqlite_database(path: str | Path, target_version: int = SCHEMA_VERSION) -> int:
    """Upgrade a SQLite memory database to the requested schema version."""

    db_path = Path(path)
    db_path.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(db_path) as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS schema_migrations(
                version INTEGER PRIMARY KEY,
                applied_at REAL NOT NULL DEFAULT (strftime('%s', 'now'))
            )
            """
        )
        current = _current_sqlite_version(conn)
        for version in range(current + 1, target_version + 1):
            if version == 2:
                _ensure_sqlite_column(conn, "memory_entries", "pinned", "INTEGER NOT NULL DEFAULT 0")
                _ensure_sqlite_column(conn, "memory_entries", "archived", "INTEGER NOT NULL DEFAULT 0")
            sql = load_schema_sql(f"sqlite_schema_v{version}.sql")
            conn.executescript(sql)
            conn.execute(
                "INSERT OR IGNORE INTO schema_migrations(version) VALUES(?)",
                (version,),
            )
        return _current_sqlite_version(conn)


def _current_sqlite_version(conn: sqlite3.Connection) -> int:
    row = conn.execute("SELECT MAX(version) FROM schema_migrations").fetchone()
    return int(row[0] or 0)


def _ensure_sqlite_column(
    conn: sqlite3.Connection,
    table_name: str,
    column_name: str,
    definition: str,
) -> None:
    columns = {row[1] for row in conn.execute(f"PRAGMA table_info({table_name})").fetchall()}
    if column_name not in columns:
        conn.execute(f"ALTER TABLE {table_name} ADD COLUMN {column_name} {definition}")
