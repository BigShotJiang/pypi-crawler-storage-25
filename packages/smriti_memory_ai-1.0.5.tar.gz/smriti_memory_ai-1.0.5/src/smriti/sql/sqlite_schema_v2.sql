CREATE INDEX IF NOT EXISTS idx_entries_user_session_topic
ON memory_entries(user_id, session_id, topic_id, created_at);

CREATE INDEX IF NOT EXISTS idx_entries_user_archived
ON memory_entries(user_id, archived, created_at);
