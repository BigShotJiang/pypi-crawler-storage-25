ALTER TABLE memory_entries ADD COLUMN IF NOT EXISTS pinned BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE memory_entries ADD COLUMN IF NOT EXISTS archived BOOLEAN NOT NULL DEFAULT FALSE;

CREATE INDEX IF NOT EXISTS idx_smriti_entries_user_session_topic
ON memory_entries(user_id, session_id, topic_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_smriti_entries_user_archived
ON memory_entries(user_id, archived, created_at DESC);

INSERT INTO schema_migrations(version) VALUES(2)
ON CONFLICT(version) DO NOTHING;
