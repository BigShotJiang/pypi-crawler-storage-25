"""Packaged SQL migrations for Smriti AI backends."""

