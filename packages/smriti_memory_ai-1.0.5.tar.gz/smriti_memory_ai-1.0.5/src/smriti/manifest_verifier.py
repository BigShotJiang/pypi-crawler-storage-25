"""Verify Smriti AI harness evolution manifests and production harness state."""

from __future__ import annotations

import json
from collections import Counter
from pathlib import Path
from typing import Any, Dict, List

from pydantic import ValidationError

from .harness import load_manifest
from .harness_registry import list_harnesses
from .manifest_schema import ManifestEntry, canonical_manifest_entry
from .security import contains_secret, redact_secret


def verify_manifest(
    *,
    manifest_path: str | Path | None = None,
    registry_root: str | Path | None = None,
    report_path: str | Path = "results/manifest_verification.md",
    json_report_path: str | Path = "results/manifest_verification.json",
) -> Dict[str, Any]:
    raw_rows = load_manifest(manifest_path)
    errors: List[str] = []
    entries: List[ManifestEntry] = []
    harness_ids = {row.get("harness_id") for row in list_harnesses(registry_root, include_rejected=True)}
    seen_iterations: set[str] = set()
    last_accepted_component: dict[str, str] = {}
    for index, raw in enumerate(raw_rows):
        try:
            if contains_secret(raw):
                errors.append(f"line {index + 1}: manifest contains secret-like value")
            entry = ManifestEntry.model_validate(canonical_manifest_entry(raw))
            entries.append(entry)
        except ValidationError as exc:
            errors.append(f"line {index + 1}: {exc}")
            continue
        if entry.iteration_id in seen_iterations:
            errors.append(f"{entry.iteration_id}: duplicate iteration_id")
        seen_iterations.add(entry.iteration_id)
        if entry.harness_id == "unknown":
            errors.append(f"{entry.iteration_id}: missing harness_id")
        elif harness_ids and entry.harness_id not in harness_ids:
            errors.append(f"{entry.iteration_id}: unknown harness_id {entry.harness_id!r}")
        if entry.evidence_source and not Path(entry.evidence_source).exists():
            errors.append(f"{entry.iteration_id}: evidence_source does not exist: {entry.evidence_source}")
        if entry.verdict == "accepted":
            previous = last_accepted_component.get(entry.component_changed)
            if previous and not entry.observed_metric_delta:
                errors.append(
                    f"{entry.iteration_id}: duplicate accepted change to {entry.component_changed} "
                    f"after {previous} without observed evidence"
                )
            last_accepted_component[entry.component_changed] = entry.iteration_id

    for entry in entries:
        if entry.verdict == "accepted" and not entry.observed_metric_delta:
            errors.append(f"{entry.iteration_id}: accepted change lacks observed_metric_delta")
        if entry.verdict in {"rejected", "reverted"} and not entry.observed_metric_delta:
            errors.append(f"{entry.iteration_id}: rejected/reverted change lacks rollback evidence")
        if entry.component_changed and (not entry.config_before or not entry.config_after):
            errors.append(f"{entry.iteration_id}: changed component lacks before/after config")

    production_harnesses = [
        row
        for row in list_harnesses(registry_root, include_rejected=True)
        if row.get("production_status") in {"accepted", "production"}
    ]
    pending = [entry for entry in entries if entry.verdict == "pending"]
    if production_harnesses and pending:
        errors.append("production harness exists while manifest contains pending changes")

    counts = Counter(entry.verdict for entry in entries)
    impact = _highest_impact(entries)
    result = {
        "valid": not errors,
        "errors": errors,
        "counts": {
            "proposed": len(entries),
            "accepted": counts.get("accepted", 0),
            "rejected": counts.get("rejected", 0),
            "reverted": counts.get("reverted", 0),
            "pending": counts.get("pending", 0),
        },
        "highest_impact_accepted_edit": impact,
        "most_common_failure_mode": _failure_mode(errors),
        "current_production_harness": production_harnesses[0]["harness_id"] if production_harnesses else "",
    }
    _write_report(result, report_path)
    _write_json_report(result, json_report_path)
    return result


def _highest_impact(entries: List[ManifestEntry]) -> Dict[str, Any]:
    accepted = [entry for entry in entries if entry.verdict == "accepted"]
    if not accepted:
        return {}
    return max(
        (
            {
                "iteration_id": entry.iteration_id,
                "component": entry.component_changed,
                "observed_metric_delta": entry.observed_metric_delta,
                "score": sum(
                    abs(float(value))
                    for value in entry.observed_metric_delta.values()
                    if isinstance(value, (int, float))
                ),
            }
            for entry in accepted
        ),
        key=lambda row: row["score"],
    )


def _failure_mode(errors: List[str]) -> str:
    if not errors:
        return "none"
    if any("pending" in error for error in errors):
        return "pending_changes"
    if any("observed_metric_delta" in error for error in errors):
        return "missing_observed_evidence"
    return "schema_validation"


def _write_report(result: Dict[str, Any], report_path: str | Path) -> None:
    path = Path(report_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    counts = result["counts"]
    lines = [
        "# Manifest Verification",
        "",
        f"- Valid: `{result['valid']}`",
        f"- Proposed edits: `{counts['proposed']}`",
        f"- Accepted edits: `{counts['accepted']}`",
        f"- Rejected edits: `{counts['rejected']}`",
        f"- Reverted edits: `{counts['reverted']}`",
        f"- Pending edits: `{counts['pending']}`",
        f"- Current production harness: `{result['current_production_harness'] or 'none'}`",
        f"- Most common failure mode: `{result['most_common_failure_mode']}`",
        "",
        "## Errors",
        "",
    ]
    if result["errors"]:
        lines.extend(f"- {redact_secret(error)}" for error in result["errors"])
    else:
        lines.append("- none")
    lines.extend(["", "```json", json.dumps(result["highest_impact_accepted_edit"], indent=2), "```", ""])
    path.write_text("\n".join(lines), encoding="utf-8")


def _write_json_report(result: Dict[str, Any], json_report_path: str | Path) -> None:
    path = Path(json_report_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    redacted = json.loads(redact_secret(result))
    path.write_text(json.dumps(redacted, indent=2, sort_keys=True), encoding="utf-8")
