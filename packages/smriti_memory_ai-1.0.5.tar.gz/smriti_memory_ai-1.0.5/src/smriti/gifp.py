"""Backward-compatible GIFP import path."""

from .identity_fingerprint import IdentityFingerprint


class GIFPLite(IdentityFingerprint):
    """Compatibility alias for the embedding-based GIFP v1.0 implementation."""

