from __future__ import annotations
import asyncio
from argparse import ArgumentParser, Namespace
from collections.abc import Iterable, Mapping, Sequence
from dataclasses import asdict, dataclass
from datetime import UTC, datetime
import getpass
import apps.cli.wizard as cli_wizard
import importlib.util
import json
import os
from pathlib import Path
import re
import shlex
import signal
import subprocess
import sys
import time
from wsgiref.simple_server import make_server

from apps.cli.shell import (
    Align,
    BRAND_ACCENT,
    BRAND_ACCENT_STRONG,
    BRAND_LIGHT,
    BRAND_MUTED,
    Console,
    Group,
    Panel,
    RICH_AVAILABLE,
    Table,
    Text,
    _resolve_aegis_version,
    render_guardian_mark,
)
from apps.provider_runtime import load_runtime_local_secret_env
from apps.runtime_layout import default_cli_state_dir, default_gateway_state_dir, default_profile_dir
from packages.gateway_core import DEFAULT_GATEWAY_ACCOUNT_ID
from packages.profile import write_profile_manifest

from . import (
    DEFAULT_DISCORD_BOT_TOKEN_ENV,
    DEFAULT_FEISHU_APP_ID_ENV,
    DEFAULT_FEISHU_APP_SECRET_ENV,
    DEFAULT_FEISHU_EVENT_PATH,
    FEISHU_ADAPTER_ID,
    GatewayHttpService,
    GatewayManagedRuntime,
    GatewayManagedService,
    SUPPORTED_DISCORD_TRANSPORTS,
    SUPPORTED_FEISHU_TRANSPORTS,
    build_gateway_app,
    build_gateway_plugin_registry,
    create_gateway_web_app,
)
from .discord import DISCORD_PY_PIP_SPEC, DiscordGatewayService
from .feishu import FEISHU_SDK_PIP_SPEC, FeishuGatewayService

try:
    from prompt_toolkit.application import Application
    from prompt_toolkit.key_binding import KeyBindings as PromptKeyBindings
    from prompt_toolkit.layout.containers import HSplit, Window
    from prompt_toolkit.layout.controls import FormattedTextControl
    from prompt_toolkit.layout.layout import Layout
    from prompt_toolkit.shortcuts import input_dialog
    from prompt_toolkit.styles import Style as PromptStyle

    PROMPT_TOOLKIT_DIALOGS_AVAILABLE = True
except ModuleNotFoundError:  # pragma: no cover - optional wizard polish
    Application = None
    PromptKeyBindings = None
    HSplit = None
    Window = None
    FormattedTextControl = None
    Layout = None
    input_dialog = None
    PromptStyle = None
    PROMPT_TOOLKIT_DIALOGS_AVAILABLE = False

@dataclass(frozen=True)
class GatewayRuntimeRecord:
    runtime_id: str
    service_key: str
    target: str
    status: str
    pid: int | None
    pid_path: str
    log_path: str
    record_path: str
    command: tuple[str, ...]
    profile_dir: str
    state_dir: str
    cli_profile_dir: str | None
    cli_state_dir: str | None
    workspace_id: str
    account_id: str | None = None
    host: str | None = None
    port: int | None = None
    started_at: str | None = None
    stopped_at: str | None = None
    last_exit_code: int | None = None
    last_error: str | None = None
    transport: str | None = None


@dataclass(slots=True)
class FeishuGatewayWizardState:
    account_id: str
    transport: str
    event_path: str
    app_id_env_var: str
    app_secret_env_var: str
    app_id_value: str
    app_secret_value: str
    enabled: bool
    default_clone_id: str
    auto_create_clone: bool
    allow_group_chats: bool


@dataclass(slots=True)
class DiscordGatewayWizardState:
    account_id: str
    transport: str
    bot_token_value: str
    enabled: bool
    account_enabled: bool
    allow_guild_ids: tuple[str, ...]
    allow_channel_ids: tuple[str, ...]


GATEWAY_WIZARD_MAX_VISIBLE_CHOICES = cli_wizard.WIZARD_MAX_VISIBLE_CHOICES
GatewayWizardChoice = cli_wizard.WizardChoice
_GatewayWizardBackSignal = cli_wizard._WizardBackSignal
GATEWAY_WIZARD_BACK = cli_wizard.WIZARD_BACK
_interactive_shell_supported = cli_wizard._interactive_shell_supported
_gateway_wizard_dialogs_supported = cli_wizard._wizard_dialogs_supported
_shared_wizard_choice_prompt = cli_wizard._wizard_choice_prompt
_shared_wizard_text_prompt = cli_wizard._wizard_text_prompt


def _gateway_wizard_choice_label(choice: GatewayWizardChoice) -> str:
    if not choice.emoji:
        return choice.label
    return f"{choice.emoji} {choice.label}"


def _gateway_wizard_choice_window(
    total: int,
    selected: int,
    *,
    max_visible: int = GATEWAY_WIZARD_MAX_VISIBLE_CHOICES,
) -> tuple[int, int]:
    if total <= max_visible:
        return 0, total
    if selected < 0:
        selected = 0
    if selected >= total:
        selected = total - 1
    half = max_visible // 2
    start = max(0, selected - half)
    end = start + max_visible
    if end > total:
        end = total
        start = end - max_visible
    return start, end


def _gateway_wizard_choice_fragments(
    title: str,
    prompt: str,
    choices: tuple[GatewayWizardChoice, ...],
    *,
    selected: int,
    max_visible: int = GATEWAY_WIZARD_MAX_VISIBLE_CHOICES,
    allow_back: bool = False,
) -> list[tuple[str, str]]:
    fragments: list[tuple[str, str]] = [
        ("class:title", f"{title}\n"),
        ("class:prompt", f"{prompt}\n\n"),
    ]
    start, end = _gateway_wizard_choice_window(
        len(choices),
        selected,
        max_visible=max_visible,
    )
    if start > 0:
        fragments.append(("class:hint", f"↑ {start} more above\n"))
    for index in range(start, end):
        choice = choices[index]
        active = index == selected
        marker = "›" if active else " "
        label_style = "class:selected" if active else "class:item"
        detail_style = "class:selected-detail" if active else "class:detail"
        fragments.append((label_style, f"{marker} {_gateway_wizard_choice_label(choice)}\n"))
        fragments.append((detail_style, f"  {choice.detail}\n"))
    if end < len(choices):
        fragments.append(("class:hint", f"↓ {len(choices) - end} more below\n"))
    if allow_back:
        fragments.append(("class:hint", "\nEnter confirms · Esc goes back · ↑/↓ or j/k moves"))
    else:
        fragments.append(("class:hint", "\nEnter confirms · ↑/↓ or j/k moves"))
    return fragments


def _gateway_wizard_choice_menu(
    title: str,
    prompt: str,
    choices: tuple[GatewayWizardChoice, ...],
    *,
    default: str,
    allow_back: bool = False,
) -> str | _GatewayWizardBackSignal:
    if not (
        PROMPT_TOOLKIT_DIALOGS_AVAILABLE
        and Application is not None
        and PromptKeyBindings is not None
        and HSplit is not None
        and Window is not None
        and FormattedTextControl is not None
        and Layout is not None
    ):
        return default
    selected = next(
        (index for index, choice in enumerate(choices) if choice.value == default),
        0,
    )
    result: dict[str, str] = {"value": default}

    def render():
        return _gateway_wizard_choice_fragments(
            title,
            prompt,
            choices,
            selected=selected,
            allow_back=allow_back,
        )

    control = FormattedTextControl(render)
    bindings = PromptKeyBindings()

    @bindings.add("down")
    @bindings.add("j")
    def _move_down(event) -> None:
        nonlocal selected
        selected = (selected + 1) % len(choices)
        event.app.invalidate()

    @bindings.add("up")
    @bindings.add("k")
    def _move_up(event) -> None:
        nonlocal selected
        selected = (selected - 1) % len(choices)
        event.app.invalidate()

    @bindings.add("tab")
    def _move_tab(event) -> None:
        nonlocal selected
        selected = (selected + 1) % len(choices)
        event.app.invalidate()

    @bindings.add("enter")
    def _accept(event) -> None:
        result["value"] = choices[selected].value
        event.app.exit(result=result["value"])

    @bindings.add("escape")
    def _cancel(event) -> None:
        event.app.exit(result=GATEWAY_WIZARD_BACK if allow_back else default)

    application = Application(
        layout=Layout(HSplit([Window(content=control)])),
        key_bindings=bindings,
        style=_gateway_wizard_style(),
        full_screen=True,
        erase_when_done=True,
    )
    answer = application.run()
    if answer is GATEWAY_WIZARD_BACK:
        return GATEWAY_WIZARD_BACK
    return str(answer or default)


def _gateway_prompt_value(
    label: str,
    *,
    default: str | None = None,
    preserve_default_on_empty: bool = True,
) -> str:
    suffix = f" [{default}]" if default else ""
    answer = input(f"{label}{suffix}: ").strip()
    if answer:
        return answer
    if preserve_default_on_empty:
        return default or ""
    return ""


def _gateway_wizard_text_prompt(
    title: str,
    prompt: str,
    *,
    default: str | None = None,
    allow_back: bool = False,
    preserve_default_on_empty: bool = True,
) -> str | _GatewayWizardBackSignal:
    if _gateway_wizard_dialogs_supported():
        answer = _shared_wizard_text_prompt(
            title,
            prompt,
            default=default,
            allow_back=allow_back,
            preserve_default_on_empty=preserve_default_on_empty,
        )
        if answer is GATEWAY_WIZARD_BACK:
            return GATEWAY_WIZARD_BACK
        return str(answer)
    return _gateway_prompt_value(
        prompt,
        default=default,
        preserve_default_on_empty=preserve_default_on_empty,
    )


def _gateway_wizard_choice_prompt(
    title: str,
    prompt: str,
    choices: tuple[GatewayWizardChoice, ...],
    *,
    default: str | None = None,
    allow_back: bool = False,
) -> str | _GatewayWizardBackSignal:
    if not choices:
        return default or ""
    default_value = default or choices[0].value
    if _gateway_wizard_dialogs_supported():
        answer = _shared_wizard_choice_prompt(
            title,
            prompt,
            choices,
            default=default_value,
            allow_back=allow_back,
        )
        if answer is GATEWAY_WIZARD_BACK:
            return GATEWAY_WIZARD_BACK
        return str(answer)
    print(prompt)
    for index, choice in enumerate(choices, start=1):
        marker = "*" if choice.value == default_value else " "
        print(f"  {marker} {index}. {_gateway_wizard_choice_label(choice)} :: {choice.detail}")
    while True:
        answer = input(f"choice [{default_value}]: ").strip()
        if not answer:
            return default_value
        if allow_back and answer.casefold() in {"back", "b"}:
            return GATEWAY_WIZARD_BACK
        if answer.isdigit():
            index = int(answer)
            if 1 <= index <= len(choices):
                return choices[index - 1].value
        normalized = answer.casefold()
        for choice in choices:
            if normalized in {choice.value.casefold(), choice.label.casefold()}:
                return choice.value
        print("  choose a listed number, transport id, or label.")


def _gateway_bool_choices(
    *,
    enabled_label: str,
    enabled_detail: str,
    disabled_label: str,
    disabled_detail: str,
) -> tuple[GatewayWizardChoice, GatewayWizardChoice]:
    return (
        GatewayWizardChoice(
            value="yes",
            label=enabled_label,
            detail=enabled_detail,
            emoji="✅",
        ),
        GatewayWizardChoice(
            value="no",
            label=disabled_label,
            detail=disabled_detail,
            emoji="➖",
        ),
    )


def _gateway_bool_prompt(
    title: str,
    prompt: str,
    *,
    default: bool,
    enabled_label: str,
    enabled_detail: str,
    disabled_label: str,
    disabled_detail: str,
    allow_back: bool = False,
) -> bool | _GatewayWizardBackSignal:
    answer = _gateway_wizard_choice_prompt(
        title,
        prompt,
        _gateway_bool_choices(
            enabled_label=enabled_label,
            enabled_detail=enabled_detail,
            disabled_label=disabled_label,
            disabled_detail=disabled_detail,
        ),
        default="yes" if default else "no",
        allow_back=allow_back,
    )
    if answer is GATEWAY_WIZARD_BACK:
        return GATEWAY_WIZARD_BACK
    return str(answer) == "yes"


def _feishu_transport_choices() -> tuple[GatewayWizardChoice, ...]:
    details = {
        "long-connection": "Use Feishu long connection for a local bridge without webhook setup.",
    }
    return tuple(
        GatewayWizardChoice(
            value=transport,
            label=transport.replace("-", " ").title(),
            detail=details.get(transport, "Use this Feishu ingress transport."),
            emoji="🛰️",
        )
        for transport in SUPPORTED_FEISHU_TRANSPORTS
    )


def _discord_transport_choices() -> tuple[GatewayWizardChoice, ...]:
    details = {
        "gateway": "Use the managed Discord gateway runtime for local IM bring-up.",
    }
    return tuple(
        GatewayWizardChoice(
            value=transport,
            label=transport.replace("-", " ").title(),
            detail=details.get(transport, "Use this Discord ingress transport."),
            emoji="💬",
        )
        for transport in SUPPORTED_DISCORD_TRANSPORTS
    )


def _im_setup_choices(*, allow_skip: bool) -> tuple[GatewayWizardChoice, ...]:
    choices: list[GatewayWizardChoice] = [
        GatewayWizardChoice(
            value="feishu",
            label="Feishu",
            detail="Wire a Feishu bot into Aegis IM and route plain text into your local clone runtime.",
            emoji="🪽",
        ),
        GatewayWizardChoice(
            value="discord",
            label="Discord",
            detail="Wire a Discord bot into Aegis IM and route messages from DMs, channels, and threads.",
            emoji="💬",
        ),
    ]
    if allow_skip:
        choices.append(
            GatewayWizardChoice(
                value="skip",
                label="Skip for now",
                detail="Stay local for now. You can always run `aegis im` later.",
                emoji="➖",
            )
        )
    return tuple(choices)


def _center_brand_block(renderable):
    if Align is None:
        return renderable
    return Align.center(renderable)


def _confirm_gateway_wizard_intro() -> bool:
    if not _interactive_shell_supported():
        return True
    try:
        answer = _gateway_prompt_value(
            "Press Enter to start setup, or type q to cancel",
            preserve_default_on_empty=False,
        )
    except (EOFError, KeyboardInterrupt):
        return False
    return answer.strip().casefold() not in {"q", "quit", "esc", "escape", "back", "\x1b"}


def _print_gateway_feishu_wizard_intro() -> bool:
    if not RICH_AVAILABLE or Table is None or Panel is None or Group is None:
        print("𓅃 Aegis IM // Feishu setup")
        print("  - choose the Feishu account you want to wire")
        print("  - bind App ID and App Secret cleanly")
        print("  - keep profile wiring and local credentials separate")
        print("  - check Bot, Events, Long Connection, and Permissions in Feishu")
        return _confirm_gateway_wizard_intro()
    console = Console(highlight=False, soft_wrap=True)
    brand = Table.grid(expand=True)
    brand.add_column(no_wrap=True)
    hero = Text(justify="center")
    hero.append("𓅃 Bring Feishu into Aegis IM.\n", style=f"bold {BRAND_LIGHT}")
    hero.append(
        "A short setup flow for wiring credentials, clone routing, and the Feishu console path with less friction.",
        style=BRAND_MUTED,
    )
    flow = Text()
    flow.append("𓂀 IM setup flow\n", style=f"bold {BRAND_ACCENT}")
    flow.append("1 · Choose the Feishu account and long-connection surface\n", style=BRAND_LIGHT)
    flow.append("2 · Paste App ID and App Secret directly into the local IM secret store\n", style=BRAND_LIGHT)
    flow.append("3 · Decide how the control bridge routes clones\n", style=BRAND_LIGHT)
    flow.append("4 · Start the bridge with credentials kept out of profile.json", style=BRAND_LIGHT)
    portal = Text()
    portal.append("Feishu console checklist\n", style=f"bold {BRAND_ACCENT}")
    portal.append("Capability · Add App Capability → Bot\n", style=BRAND_LIGHT)
    portal.append("Events · Event Subscriptions → add `im.message.receive_v1`\n", style=BRAND_LIGHT)
    portal.append("Transport · Use Long Connection for local IM bring-up\n", style=BRAND_LIGHT)
    portal.append(
        "Permissions · Enable `im:message`, `im:message.p2p_msg:readonly`, and `im:message:send_as_bot`",
        style=BRAND_LIGHT,
    )
    brand.add_row(_center_brand_block(hero))
    brand.add_row(Text(" "))
    brand.add_row(_center_brand_block(render_guardian_mark()))
    brand.add_row(Text(" "))
    content = Table.grid(expand=True)
    console_width = getattr(console.size, "width", 0)
    if console_width and console_width < 148:
        content.add_column(ratio=1, min_width=52)
        content.add_row(brand)
        content.add_row(Text(" "))
        content.add_row(flow)
        content.add_row(Text(" "))
        content.add_row(portal)
    else:
        content.add_column(ratio=11, min_width=42)
        content.add_column(ratio=12, min_width=44)
        content.add_column(ratio=12, min_width=44)
        content.add_row(brand, flow, portal)
    console.print(
        Panel(
            content,
            title=f"[bold {BRAND_ACCENT}] IM Feishu Setup v{_resolve_aegis_version()} [/bold {BRAND_ACCENT}]",
            subtitle="[bold {brand}]Polished local bridge setup for Feishu.[/bold {brand}]".replace(
                "{brand}",
                BRAND_LIGHT,
            ),
            border_style=BRAND_ACCENT,
            padding=(1, 2),
        )
    )
    return _confirm_gateway_wizard_intro()


def _print_gateway_discord_wizard_intro() -> bool:
    if not RICH_AVAILABLE or Table is None or Panel is None or Group is None:
        print("Aegis IM // Discord setup")
        print("Bring Discord into Aegis IM.")
        print("  - choose the Discord account you want to wire")
        print("  - paste the bot token directly into the local IM secret store")
        print("  - keep profile wiring and local credentials separate")
        print("Discord portal checklist")
        print("  - check OAuth2 invite scope, MESSAGE_CONTENT, and bot permissions in Discord")
        return _confirm_gateway_wizard_intro()
    console = Console(highlight=False, soft_wrap=True)
    brand = Table.grid(expand=True)
    brand.add_column(no_wrap=True)
    hero = Text(justify="center")
    hero.append("Bring Discord into Aegis IM.\n", style=f"bold {BRAND_LIGHT}")
    hero.append(
        "A short setup flow for wiring the bot token, profile switches, and Discord portal steps with less friction.",
        style=BRAND_MUTED,
    )
    flow = Text()
    flow.append("IM setup flow\n", style=f"bold {BRAND_ACCENT}")
    flow.append("1 · Choose the Discord account and managed gateway surface\n", style=BRAND_LIGHT)
    flow.append("2 · Paste the bot token directly into the local IM secret file\n", style=BRAND_LIGHT)
    flow.append("3 · Decide whether Discord is active in profile views and default runtime starts\n", style=BRAND_LIGHT)
    flow.append("4 · Start the bridge with credentials kept out of profile.json", style=BRAND_LIGHT)
    portal = Text()
    portal.append("Discord portal checklist\n", style=f"bold {BRAND_ACCENT}")
    portal.append("OAuth2 · URL Generator → include the `bot` scope when inviting the app\n", style=BRAND_LIGHT)
    portal.append("Bot · Privileged Gateway Intents → enable `MESSAGE_CONTENT`\n", style=BRAND_LIGHT)
    portal.append(
        "Permissions · Grant `View Channels`, `Send Messages`, `Send Messages in Threads`, and `Read Message History`\n",
        style=BRAND_LIGHT,
    )
    portal.append("Runtime · Start with `aegis im discord start --transport gateway`", style=BRAND_LIGHT)
    brand.add_row(_center_brand_block(hero))
    brand.add_row(Text(" "))
    brand.add_row(_center_brand_block(render_guardian_mark()))
    brand.add_row(Text(" "))
    content = Table.grid(expand=True)
    console_width = getattr(console.size, "width", 0)
    if console_width and console_width < 148:
        content.add_column(ratio=1, min_width=52)
        content.add_row(brand)
        content.add_row(Text(" "))
        content.add_row(flow)
        content.add_row(Text(" "))
        content.add_row(portal)
    else:
        content.add_column(ratio=11, min_width=42)
        content.add_column(ratio=12, min_width=44)
        content.add_column(ratio=12, min_width=44)
        content.add_row(brand, flow, portal)
    console.print(
        Panel(
            content,
            title=f"[bold {BRAND_ACCENT}] IM Discord Setup v{_resolve_aegis_version()} [/bold {BRAND_ACCENT}]",
            subtitle="[bold {brand}]Polished local bridge setup for Discord.[/bold {brand}]".replace(
                "{brand}",
                BRAND_LIGHT,
            ),
            border_style=BRAND_ACCENT,
            padding=(1, 2),
        )
    )
    return _confirm_gateway_wizard_intro()


def _gateway_wizard_secret_prompt(
    title: str,
    prompt: str,
    *,
    allow_back: bool = False,
) -> str | _GatewayWizardBackSignal:
    if _gateway_wizard_dialogs_supported():
        answer = _shared_wizard_text_prompt(
            title,
            prompt,
            allow_back=allow_back,
            password=True,
        )
        if answer is GATEWAY_WIZARD_BACK:
            return GATEWAY_WIZARD_BACK
        return str(answer).strip()
    hint = " (leave blank to keep the current local value" + (", type back to return" if allow_back else "") + ")"
    answer = getpass.getpass(f"{prompt}{hint}: ").strip()
    if allow_back and answer.casefold() == "back":
        return GATEWAY_WIZARD_BACK
    return answer



def _print_gateway_setup_paused(service_name: str) -> None:
    print(f"{service_name} IM setup paused")
    print("  No IM changes were written.")
    print("  next_commands:")
    print("  - aegis im")
    print("  - aegis im doctor")


def _ensure_feishu_sdk_available(*, reason: str) -> bool:
    if importlib.util.find_spec("lark_oapi") is not None:
        return False
    command = [
        sys.executable,
        "-m",
        "pip",
        "install",
        "--disable-pip-version-check",
        FEISHU_SDK_PIP_SPEC,
    ]
    print(f"Preparing Feishu support for {reason}...")
    try:
        subprocess.run(command, check=True)
    except (OSError, subprocess.CalledProcessError) as exc:
        rendered = " ".join(shlex.quote(part) for part in command)
        raise SystemExit(
            "Aegis could not automatically install the Feishu SDK. "
            f"Run `{rendered}` and retry."
        ) from exc
    if importlib.util.find_spec("lark_oapi") is None:
        rendered = " ".join(shlex.quote(part) for part in command)
        raise SystemExit(
            "Aegis finished the Feishu SDK install command, but `lark_oapi` is still unavailable. "
            f"Run `{rendered}` manually and retry."
        )
    print("Feishu support is ready.")
    return True


def _ensure_discord_sdk_available(*, reason: str) -> bool:
    if importlib.util.find_spec("discord") is not None:
        return False
    command = [
        sys.executable,
        "-m",
        "pip",
        "install",
        "--disable-pip-version-check",
        DISCORD_PY_PIP_SPEC,
    ]
    print(f"Preparing Discord support for {reason}...")
    try:
        subprocess.run(command, check=True)
    except (OSError, subprocess.CalledProcessError) as exc:
        rendered = " ".join(shlex.quote(part) for part in command)
        raise SystemExit(
            "Aegis could not automatically install Discord support. "
            f"Run `{rendered}` and retry."
        ) from exc
    if importlib.util.find_spec("discord") is None:
        rendered = " ".join(shlex.quote(part) for part in command)
        raise SystemExit(
            "Aegis finished the Discord install command, but `discord.py` is still unavailable. "
            f"Run `{rendered}` manually and retry."
        )
    print("Discord support is ready.")
    return True


def _parse_gateway_id_csv(value: str) -> tuple[str, ...]:
    return tuple(dict.fromkeys(part.strip() for part in value.split(",") if part.strip()))


def _run_interactive_feishu_wizard(
    *,
    account_id: str,
    transport: str,
    event_path: str,
    app_id_env_var: str,
    app_secret_env_var: str,
    app_id_value: str,
    app_secret_value: str,
    enabled: bool,
    default_clone_id: str,
    auto_create_clone: bool,
    allow_group_chats: bool,
) -> FeishuGatewayWizardState | None:
    state = FeishuGatewayWizardState(
        account_id=account_id,
        transport=transport,
        event_path=event_path,
        app_id_env_var=app_id_env_var,
        app_secret_env_var=app_secret_env_var,
        app_id_value=app_id_value,
        app_secret_value=app_secret_value,
        enabled=enabled,
        default_clone_id=default_clone_id,
        auto_create_clone=auto_create_clone,
        allow_group_chats=allow_group_chats,
    )
    steps = (
        "account_id",
        "transport",
        "event_path",
        "app_id_value",
        "app_secret_value",
        "enabled",
        "default_clone_id",
        "auto_create_clone",
        "allow_group_chats",
    )
    step_index = 0
    while step_index < len(steps):
        step = steps[step_index]
        if step == "account_id":
            answer = _gateway_wizard_text_prompt(
                "Feishu Account",
                "Which Feishu gateway account id should this bridge use?",
                default=state.account_id,
                allow_back=True,
            )
            if answer is GATEWAY_WIZARD_BACK:
                return None
            state.account_id = str(answer).strip() or DEFAULT_GATEWAY_ACCOUNT_ID
            step_index += 1
            continue
        if step == "transport":
            answer = _gateway_wizard_choice_prompt(
                "Ingress Transport",
                "How should this Feishu bridge receive events?",
                _feishu_transport_choices(),
                default=state.transport,
                allow_back=True,
            )
            if answer is GATEWAY_WIZARD_BACK:
                step_index -= 1
                continue
            state.transport = str(answer)
            step_index += 1
            continue
        if step == "event_path":
            answer = _gateway_wizard_text_prompt(
                "Compatibility Event Path",
                "Which webhook-style event path should stay in the manifest for compatibility?",
                default=state.event_path,
                allow_back=True,
            )
            if answer is GATEWAY_WIZARD_BACK:
                step_index -= 1
                continue
            state.event_path = str(answer).strip() or DEFAULT_FEISHU_EVENT_PATH
            step_index += 1
            continue
        if step == "app_id_value":
            answer = _gateway_wizard_text_prompt(
                "Paste App ID",
                "Paste the Feishu App ID to store it in the local IM secret file. Leave blank to keep the current local value if one already exists.",
                default=None,
                allow_back=True,
                preserve_default_on_empty=False,
            )
            if answer is GATEWAY_WIZARD_BACK:
                step_index -= 1
                continue
            state.app_id_value = str(answer).strip()
            step_index += 1
            continue
        if step == "app_secret_value":
            answer = _gateway_wizard_secret_prompt(
                "Paste App Secret",
                "Paste the Feishu App Secret / API key to store it in the local IM secret file.",
                allow_back=True,
            )
            if answer is GATEWAY_WIZARD_BACK:
                step_index -= 1
                continue
            state.app_secret_value = str(answer).strip()
            step_index += 1
            continue
        if step == "enabled":
            answer = _gateway_bool_prompt(
                "Serve With Gateway",
                "Should Feishu also be enabled for `aegis im serve`?",
                default=state.enabled,
                enabled_label="Enable for serve",
                enabled_detail="Mount Feishu whenever you run `aegis im serve`.",
                disabled_label="Keep config only",
                disabled_detail="Write the config now, but start Feishu explicitly later.",
                allow_back=True,
            )
            if answer is GATEWAY_WIZARD_BACK:
                step_index -= 1
                continue
            state.enabled = bool(answer)
            step_index += 1
            continue
        if step == "default_clone_id":
            answer = _gateway_wizard_text_prompt(
                "Default Clone",
                "Optional: which clone should plain text fall back to before a thread is pinned? Leave blank to follow the most recent clone.",
                default=state.default_clone_id,
                allow_back=True,
                preserve_default_on_empty=False,
            )
            if answer is GATEWAY_WIZARD_BACK:
                step_index -= 1
                continue
            state.default_clone_id = str(answer).strip()
            step_index += 1
            continue
        if step == "auto_create_clone":
            answer = _gateway_bool_prompt(
                "Auto-create Missing Clone",
                "If the default clone does not exist yet, should the control bridge create it automatically?",
                default=state.auto_create_clone,
                enabled_label="Auto-create clone",
                enabled_detail="Create the configured default clone the first time Feishu needs it.",
                disabled_label="Require existing clone",
                disabled_detail="Make Feishu wait until the clone already exists locally.",
                allow_back=True,
            )
            if answer is GATEWAY_WIZARD_BACK:
                step_index -= 1
                continue
            state.auto_create_clone = bool(answer)
            step_index += 1
            continue
        if step == "allow_group_chats":
            answer = _gateway_bool_prompt(
                "Group Chats",
                "Should the Feishu control bridge accept group chats too?",
                default=state.allow_group_chats,
                enabled_label="Allow group chats",
                enabled_detail="Let the bridge respond in group chats as well as direct messages.",
                disabled_label="Direct messages only",
                disabled_detail="Keep the bridge limited to private chats.",
                allow_back=True,
            )
            if answer is GATEWAY_WIZARD_BACK:
                step_index -= 1
                continue
            state.allow_group_chats = bool(answer)
            step_index += 1
            continue
    return state


def _run_interactive_discord_wizard(
    *,
    account_id: str,
    transport: str,
    bot_token_value: str,
    enabled: bool,
    account_enabled: bool,
    allow_guild_ids: Sequence[str],
    allow_channel_ids: Sequence[str],
) -> DiscordGatewayWizardState | None:
    state = DiscordGatewayWizardState(
        account_id=account_id,
        transport=transport,
        bot_token_value=bot_token_value,
        enabled=enabled,
        account_enabled=account_enabled,
        allow_guild_ids=tuple(str(value).strip() for value in allow_guild_ids if str(value).strip()),
        allow_channel_ids=tuple(str(value).strip() for value in allow_channel_ids if str(value).strip()),
    )
    steps = (
        "account_id",
        "transport",
        "bot_token_value",
        "enabled",
        "account_enabled",
        "allow_guild_ids",
        "allow_channel_ids",
    )
    step_index = 0
    while step_index < len(steps):
        step = steps[step_index]
        if step == "account_id":
            answer = _gateway_wizard_text_prompt(
                "Discord Account",
                "Which Discord gateway account id should this bridge use?",
                default=state.account_id,
                allow_back=True,
            )
            if answer is GATEWAY_WIZARD_BACK:
                return None
            state.account_id = str(answer).strip() or DEFAULT_GATEWAY_ACCOUNT_ID
            step_index += 1
            continue
        if step == "transport":
            answer = _gateway_wizard_choice_prompt(
                "Ingress Transport",
                "How should this Discord bridge receive events?",
                _discord_transport_choices(),
                default=state.transport,
                allow_back=True,
            )
            if answer is GATEWAY_WIZARD_BACK:
                step_index -= 1
                continue
            state.transport = str(answer)
            step_index += 1
            continue
        if step == "bot_token_value":
            answer = _gateway_wizard_secret_prompt(
                "Paste Bot Token",
                "Paste the Discord bot token to store it in the local IM secret file.",
                allow_back=True,
            )
            if answer is GATEWAY_WIZARD_BACK:
                step_index -= 1
                continue
            state.bot_token_value = str(answer).strip()
            step_index += 1
            continue
        if step == "enabled":
            answer = _gateway_bool_prompt(
                "Profile Visibility",
                "Should Discord be included in `aegis im describe` and `aegis im doctor` for this profile?",
                default=state.enabled,
                enabled_label="Include in profile",
                enabled_detail="Show Discord in profile-wide IM describe and doctor output.",
                disabled_label="Keep config only",
                disabled_detail="Write the config now, but keep Discord out of profile-wide IM views.",
                allow_back=True,
            )
            if answer is GATEWAY_WIZARD_BACK:
                step_index -= 1
                continue
            state.enabled = bool(answer)
            step_index += 1
            continue
        if step == "account_enabled":
            answer = _gateway_bool_prompt(
                "Default Runtime Starts",
                "Should this Discord account join default multi-account runtime starts?",
                default=state.account_enabled,
                enabled_label="Include in default starts",
                enabled_detail="Start this Discord account when you launch the managed runtime normally.",
                disabled_label="Skip by default",
                disabled_detail="Keep the account configured, but require explicit selection later.",
                allow_back=True,
            )
            if answer is GATEWAY_WIZARD_BACK:
                step_index -= 1
                continue
            state.account_enabled = bool(answer)
            step_index += 1
            continue
        if step == "allow_guild_ids":
            answer = _gateway_wizard_text_prompt(
                "Guild Allowlist",
                "Optional: comma-separated guild ids to allow. Leave blank to accept any guild where the bot is installed.",
                default=", ".join(state.allow_guild_ids) or None,
                allow_back=True,
                preserve_default_on_empty=False,
            )
            if answer is GATEWAY_WIZARD_BACK:
                step_index -= 1
                continue
            state.allow_guild_ids = _parse_gateway_id_csv(str(answer))
            step_index += 1
            continue
        if step == "allow_channel_ids":
            answer = _gateway_wizard_text_prompt(
                "Channel Allowlist",
                "Optional: comma-separated channel or parent-channel ids to allow. Leave blank for no channel-specific allowlist.",
                default=", ".join(state.allow_channel_ids) or None,
                allow_back=True,
                preserve_default_on_empty=False,
            )
            if answer is GATEWAY_WIZARD_BACK:
                step_index -= 1
                continue
            state.allow_channel_ids = _parse_gateway_id_csv(str(answer))
            step_index += 1
            continue
    return state


def _mapping(value: object) -> Mapping[str, object] | None:
    return value if isinstance(value, Mapping) else None


def _mapping_payload(value: object, *, path: str) -> dict[str, object]:
    if value is None:
        return {}
    if not isinstance(value, Mapping):
        raise ValueError(f"{path} must be a JSON object")
    return {str(key): item for key, item in value.items()}


def _load_profile_manifest(profile_dir: Path) -> dict[str, object]:
    manifest_path = profile_dir / "profile.json"
    if not manifest_path.exists():
        return {}
    payload = json.loads(manifest_path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("profile.json must contain a JSON object")
    return payload


GATEWAY_LOCAL_SECRET_ENV_FILE = "gateway-local-secrets.json"



def _gateway_local_secret_env_path(state_dir: Path) -> Path:
    return state_dir / GATEWAY_LOCAL_SECRET_ENV_FILE



def _load_gateway_local_secret_env(state_dir: Path) -> dict[str, str]:
    path = _gateway_local_secret_env_path(state_dir)
    if not path.exists():
        return {}
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, Mapping):
        raise ValueError(f"{path} must contain a JSON object")
    resolved: dict[str, str] = {}
    for key, value in payload.items():
        text = str(value).strip()
        if text:
            resolved[str(key)] = text
    return resolved



def _persist_gateway_local_secret_env(
    state_dir: Path,
    updates: Mapping[str, str],
) -> Path | None:
    filtered = {str(key): str(value).strip() for key, value in updates.items() if str(value).strip()}
    if not filtered:
        return None
    state_dir.mkdir(parents=True, exist_ok=True)
    path = _gateway_local_secret_env_path(state_dir)
    payload = _load_gateway_local_secret_env(state_dir)
    payload.update(filtered)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass
    return path



def _gateway_runtime_environ(
    state_dir: Path,
    *,
    cli_state_dir: Path | None = None,
) -> dict[str, str]:
    env = load_runtime_local_secret_env(cli_state_dir or state_dir)
    env.update(_load_gateway_local_secret_env(state_dir))
    env.update(os.environ)
    return env



def _read_pid(path: Path) -> int | None:
    if not path.exists():
        return None
    try:
        return int(path.read_text(encoding="utf-8").strip())
    except (OSError, ValueError):
        return None


def _pid_is_running(pid: int | None) -> bool:
    if pid is None or pid <= 0:
        return False
    try:
        os.kill(pid, 0)
    except OSError:
        return False
    return True


def _optional_text(value: object) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def _coerce_int(value: object) -> int | None:
    if value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _utc_now_iso() -> str:
    return datetime.now(UTC).isoformat()

def _load_runtime_record(path: Path) -> dict[str, object] | None:
    if not path.exists():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    if not isinstance(payload, dict):
        return None
    return {str(key): value for key, value in payload.items()}


def _write_runtime_record(path: Path, record: GatewayRuntimeRecord) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(asdict(record), ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def _build_runtime_record(
    args: Namespace,
    *,
    runtime: GatewayManagedRuntime,
    status: str,
    pid: int | None,
    existing: Mapping[str, object] | None = None,
    command: Sequence[str] | None = None,
    started_at: str | None = None,
    stopped_at: str | None = None,
    last_exit_code: int | None = None,
    last_error: str | None = None,
) -> GatewayRuntimeRecord:
    existing_payload = dict(existing or {})
    command_payload = tuple(
        str(value)
        for value in (command or existing_payload.get("command") or ())
    )
    profile_dir = _optional_text(getattr(args, "profile_dir", None)) or _optional_text(
        existing_payload.get("profile_dir")
    )
    cli_profile_dir = _optional_text(getattr(args, "cli_profile_dir", None)) or _optional_text(
        existing_payload.get("cli_profile_dir")
    )
    cli_state_dir = _optional_text(getattr(args, "cli_state_dir", None)) or _optional_text(
        existing_payload.get("cli_state_dir")
    )
    workspace_id = _optional_text(getattr(args, "workspace_id", None)) or _optional_text(
        existing_payload.get("workspace_id")
    )
    host = _optional_text(getattr(args, "host", None)) or _optional_text(existing_payload.get("host"))
    port = _coerce_int(getattr(args, "port", None))
    if port is None:
        port = _coerce_int(existing_payload.get("port"))
    if status == "running":
        stopped_at = None
        last_exit_code = None
        last_error = None
    elif last_exit_code is None:
        last_exit_code = _coerce_int(existing_payload.get("last_exit_code"))
    if last_error is None:
        last_error = _optional_text(existing_payload.get("last_error"))
    if stopped_at is None and status != "running":
        stopped_at = _optional_text(existing_payload.get("stopped_at"))
    if started_at is None:
        started_at = _optional_text(existing_payload.get("started_at"))
    if started_at is None and status in {"starting", "running"}:
        started_at = _utc_now_iso()
    return GatewayRuntimeRecord(
        runtime_id=runtime.runtime_id,
        service_key=runtime.service_key,
        target=runtime.target,
        status=status,
        pid=pid,
        pid_path=str(runtime.pid_path),
        log_path=str(runtime.log_path),
        record_path=str(runtime.record_path),
        command=command_payload,
        profile_dir=profile_dir or "",
        state_dir=str(getattr(args, "state_dir", runtime.pid_path.parent)),
        cli_profile_dir=cli_profile_dir,
        cli_state_dir=cli_state_dir,
        workspace_id=workspace_id or "",
        account_id=_optional_text(getattr(args, "account_id", None))
        or _optional_text(existing_payload.get("account_id")),
        host=host,
        port=port,
        started_at=started_at,
        stopped_at=stopped_at,
        last_exit_code=last_exit_code,
        last_error=last_error,
        transport=runtime.target,
    )


def _runtime_state(runtime: GatewayManagedRuntime) -> dict[str, object]:
    record = _load_runtime_record(runtime.record_path) or {}
    pid_from_file = _read_pid(runtime.pid_path)
    pid_from_record = _coerce_int(record.get("pid"))
    pid = pid_from_file if pid_from_file is not None else pid_from_record
    pid_active = _pid_is_running(pid)
    record_status = _optional_text(record.get("status")) or "stopped"
    if pid_active:
        status = "running"
    elif record_status == "failed":
        status = "failed"
    else:
        status = "stopped"
    return {
        "record": record,
        "pid": pid,
        "pid_from_file": pid_from_file,
        "pid_from_record": pid_from_record,
        "pid_active": pid_active,
        "stale_pid": pid_from_file is not None and not pid_active,
        "status": status,
    }


def _remove_file_if_exists(path: Path) -> None:
    try:
        path.unlink()
    except FileNotFoundError:
        return


def _wait_for_pid_exit(pid: int, *, timeout_seconds: float) -> bool:
    deadline = time.monotonic() + max(timeout_seconds, 0.0)
    while time.monotonic() < deadline:
        if not _pid_is_running(pid):
            return True
        time.sleep(0.2)
    return not _pid_is_running(pid)


def _terminate_pid(pid: int, *, timeout_seconds: float, force: bool) -> str | None:
    if timeout_seconds < 0:
        raise SystemExit("--timeout must be zero or a positive number.")
    if not _pid_is_running(pid):
        return None
    try:
        os.kill(pid, signal.SIGTERM)
    except ProcessLookupError:
        return None
    except PermissionError as exc:
        raise SystemExit(f"Unable to stop process {pid}: {exc}") from exc
    if _wait_for_pid_exit(pid, timeout_seconds=timeout_seconds):
        return signal.Signals(signal.SIGTERM).name
    if not force:
        raise SystemExit(
            f"Process {pid} did not exit within {timeout_seconds:g}s. Retry with `--force` to send SIGKILL."
        )
    try:
        os.kill(pid, signal.SIGKILL)
    except ProcessLookupError:
        return signal.Signals(signal.SIGTERM).name
    except PermissionError as exc:
        raise SystemExit(f"Unable to force-stop process {pid}: {exc}") from exc
    if _wait_for_pid_exit(pid, timeout_seconds=max(timeout_seconds, 2.0)):
        return signal.Signals(signal.SIGKILL).name
    raise SystemExit(f"Process {pid} is still running after SIGKILL.")


def _resolve_runtime_target_argument(
    args: Namespace,
    *,
    service: GatewayManagedService | None = None,
) -> str:
    requested_target = str(getattr(args, "runtime_target", "configured") or "configured")
    if requested_target != "configured":
        return requested_target
    if service is None:
        raise SystemExit(
            "Resolving the configured runtime target requires an active gateway service profile."
        )
    return service.configured_runtime_target()


def _run_start_detached(
    args: Namespace,
    *,
    service: GatewayManagedService,
    target: str,
    action: str = "startup",
) -> int:
    service.prepare_managed_runtime(action=action, target=target)
    runtime = service.managed_runtime(args=args, target=target)
    state = _runtime_state(runtime)
    existing_pid = state["pid"]
    if state["pid_active"]:
        raise SystemExit(
            f"{runtime.label} is already running in the background with pid {existing_pid}."
        )
    args.state_dir.mkdir(parents=True, exist_ok=True)
    command = service.build_detached_runtime_command(args=args, target=target)
    started_at = _utc_now_iso()
    with runtime.log_path.open("ab") as log_stream:
        process = subprocess.Popen(
            list(command),
            stdin=subprocess.DEVNULL,
            stdout=log_stream,
            stderr=subprocess.STDOUT,
            start_new_session=True,
            env=_gateway_runtime_environ(
                args.state_dir,
                cli_state_dir=args.cli_state_dir,
            ),
        )
    runtime.pid_path.write_text(f"{process.pid}\n", encoding="utf-8")
    _write_runtime_record(
        runtime.record_path,
        _build_runtime_record(
            args,
            runtime=runtime,
            status="starting",
            pid=process.pid,
            existing=state["record"],
            command=command,
            started_at=started_at,
        ),
    )
    time.sleep(0.4)
    return_code = process.poll()
    if return_code is not None:
        _remove_file_if_exists(runtime.pid_path)
        log_excerpt = ""
        try:
            excerpt_lines = runtime.log_path.read_text(encoding="utf-8").splitlines()[-20:]
        except OSError:
            excerpt_lines = []
        if excerpt_lines:
            log_excerpt = "\nRecent log output:\n" + "\n".join(excerpt_lines)
        _write_runtime_record(
            runtime.record_path,
            _build_runtime_record(
                args,
                runtime=runtime,
                status="failed",
                pid=None,
                existing=state["record"],
                command=command,
                started_at=started_at,
                stopped_at=_utc_now_iso(),
                last_exit_code=return_code,
                last_error=f"process exited with code {return_code}",
            ),
        )
        raise SystemExit(
            f"{runtime.label} failed to stay up in the background (exit {return_code})."
            f" Check {runtime.log_path}.{log_excerpt}"
        )
    _write_runtime_record(
        runtime.record_path,
        _build_runtime_record(
            args,
            runtime=runtime,
            status="running",
            pid=process.pid,
            existing=state["record"],
            command=command,
            started_at=started_at,
            stopped_at=None,
            last_exit_code=None,
            last_error=None,
        ),
    )
    print(f"Started Aegis IM {runtime.label} in background.")
    print(f"PID: {process.pid}")
    print(f"PID file: {runtime.pid_path}")
    print(f"Log file: {runtime.log_path}")
    print(f"Runtime record: {runtime.record_path}")
    print(f"View logs: {service.managed_runtime_log_hint(target=target)}")
    return 0


def _read_log_excerpt(path: Path, *, tail: int) -> tuple[str, ...]:
    if tail < 0:
        raise SystemExit("--tail must be zero or a positive integer.")
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except OSError as exc:
        raise SystemExit(f"Unable to read log file {path}: {exc}") from exc
    if tail == 0:
        return ()
    return tuple(lines[-tail:])


def _follow_log_file(path: Path) -> None:
    with path.open("r", encoding="utf-8") as stream:
        stream.seek(0, os.SEEK_END)
        while True:
            chunk = stream.read()
            if chunk:
                print(chunk, end="")
                sys.stdout.flush()
                continue
            time.sleep(0.4)
            try:
                current_size = path.stat().st_size
            except OSError:
                current_size = stream.tell()
            if current_size < stream.tell():
                stream.seek(0)


def _format_runtime_command(record: Mapping[str, object]) -> str:
    command = record.get("command")
    if not isinstance(command, (list, tuple)):
        return "<none>"
    parts = [str(part) for part in command if str(part)]
    if not parts:
        return "<none>"
    return shlex.join(parts)


def _run_status(args: Namespace, *, service: GatewayManagedService | None = None) -> int:
    if service is None:
        raise TypeError("_run_status requires a managed gateway service")
    target = _resolve_runtime_target_argument(args, service=service)
    runtime = service.managed_runtime(args=args, target=target)
    state = _runtime_state(runtime)
    record = state["record"]
    print("Aegis IM runtime status")
    print(f"runtime_id: {runtime.runtime_id}")
    print(f"service_key: {runtime.service_key}")
    print(f"target: {runtime.target}")
    print(f"status: {state['status']}")
    print(f"recorded_status: {record.get('status') or '<none>'}")
    print(f"pid: {state['pid'] if state['pid'] is not None else '<none>'}")
    print(f"pid_active: {'yes' if state['pid_active'] else 'no'}")
    print(f"stale_pid_file: {'yes' if state['stale_pid'] else 'no'}")
    print(f"pid_file: {runtime.pid_path}")
    print(f"log_file: {runtime.log_path}")
    print(f"record_file: {runtime.record_path}")
    print(f"started_at: {record.get('started_at') or '<none>'}")
    print(f"stopped_at: {record.get('stopped_at') or '<none>'}")
    print(f"last_exit_code: {record.get('last_exit_code') if record.get('last_exit_code') is not None else '<none>'}")
    print(f"last_error: {record.get('last_error') or '<none>'}")
    print(f"account_id: {record.get('account_id') or '<none>'}")
    print(f"command: {_format_runtime_command(record)}")
    if getattr(service, "service_key", None) == "discord" and hasattr(service, "describe"):
        description = service.describe()
        for line in _discord_account_status_lines(description):
            print(line)
        for account in tuple(description.get("accounts") or ()):
            if not isinstance(account, Mapping):
                continue
            print(_render_discord_account_line(account, prefix="account"))
    if getattr(service, "service_key", None) == "feishu" and hasattr(service, "describe"):
        description = service.describe()
        for line in _feishu_async_status_lines(description):
            print(line)
    return 0


def _stop_managed_runtime(
    args: Namespace,
    *,
    service: GatewayManagedService,
    target: str,
) -> tuple[str, str | None, GatewayManagedRuntime]:
    runtime = service.managed_runtime(args=args, target=target)
    state = _runtime_state(runtime)
    record = state["record"]
    pid = _coerce_int(state["pid"])
    if pid is None or not state["pid_active"]:
        if state["stale_pid"]:
            _remove_file_if_exists(runtime.pid_path)
        _write_runtime_record(
            runtime.record_path,
            _build_runtime_record(
                args,
                runtime=runtime,
                status="stopped",
                pid=None,
                existing=record,
                stopped_at=_utc_now_iso(),
            ),
        )
        return "already-stopped", None, runtime
    signal_name = _terminate_pid(pid, timeout_seconds=args.timeout, force=args.force)
    _remove_file_if_exists(runtime.pid_path)
    _write_runtime_record(
        runtime.record_path,
        _build_runtime_record(
            args,
            runtime=runtime,
            status="stopped",
            pid=None,
            existing=record,
            stopped_at=_utc_now_iso(),
            last_exit_code=0,
            last_error=None,
        ),
    )
    return "stopped", signal_name, runtime


def _run_stop(args: Namespace, *, service: GatewayManagedService | None = None) -> int:
    if service is None:
        raise TypeError("_run_stop requires a managed gateway service")
    target = _resolve_runtime_target_argument(args, service=service)
    outcome, signal_name, runtime = _stop_managed_runtime(
        args,
        service=service,
        target=target,
    )
    if outcome == "already-stopped":
        print(f"{runtime.label} is not running.")
    else:
        print(f"Stopped Aegis IM {runtime.label}.")
        print(f"Signal: {signal_name or '<none>'}")
    print(f"Log file: {runtime.log_path}")
    print(f"Runtime record: {runtime.record_path}")
    return 0


def _run_restart(args: Namespace, *, service: GatewayManagedService | None = None) -> int:
    if service is None:
        raise TypeError("_run_restart requires a managed gateway service")
    target = _resolve_runtime_target_argument(args, service=service)
    runtime = service.managed_runtime(args=args, target=target)
    print(f"Restarting Aegis IM {runtime.label}.")
    outcome, _, _ = _stop_managed_runtime(args, service=service, target=target)
    if outcome == "already-stopped":
        print("No running detached runtime was found; starting a fresh background process.")
    return _run_start_detached(args, service=service, target=target, action="restart")


def _run_logs(args: Namespace, *, service: GatewayManagedService | None = None) -> int:
    if service is None:
        raise TypeError("_run_logs requires a managed gateway service")
    target = _resolve_runtime_target_argument(args, service=service)
    runtime = service.managed_runtime(args=args, target=target)
    state = _runtime_state(runtime)
    if args.path:
        print(runtime.log_path)
        return 0
    if not runtime.log_path.exists():
        running_hint = (
            f" Background pid {state['pid']} is still recorded." if state["pid_active"] else ""
        )
        raise SystemExit(
            f"No log file found for {runtime.label} at {runtime.log_path}."
            f" Start it with `{service.managed_runtime_log_hint(target=target).replace(' logs ', ' start ').replace('--follow', '--detach')}` first.{running_hint}"
        )
    excerpt = _read_log_excerpt(runtime.log_path, tail=args.tail)
    if excerpt:
        print("\n".join(excerpt))
    if args.follow:
        if not excerpt:
            print(f"Following {runtime.log_path} (Ctrl-C to stop)")
        try:
            _follow_log_file(runtime.log_path)
        except KeyboardInterrupt:
            return 0
    return 0


def _secret_reference_id(*, account_id: str, secret_key: str) -> str:
    normalized_account = re.sub(r"[^a-z0-9]+", "-", account_id.strip().lower()).strip("-") or "default"
    normalized_key = secret_key.replace("_", "-")
    return f"secret-feishu-{normalized_account}-{normalized_key}"


def _default_feishu_secret_env_var(*, account_id: str, secret_key: str) -> str:
    if account_id == DEFAULT_GATEWAY_ACCOUNT_ID:
        if secret_key == "app_id":
            return DEFAULT_FEISHU_APP_ID_ENV
        if secret_key == "app_secret":
            return DEFAULT_FEISHU_APP_SECRET_ENV
    normalized_account = re.sub(r"[^A-Za-z0-9]+", "_", account_id.strip()).strip("_").upper() or "DEFAULT"
    suffix = "APP_ID" if secret_key == "app_id" else "APP_SECRET"
    return f"AEGIS_FEISHU_{normalized_account}_{suffix}"


def _build_feishu_secret_reference(
    *,
    account_id: str,
    secret_key: str,
    env_var: str,
) -> dict[str, object]:
    return {
        "reference_id": _secret_reference_id(account_id=account_id, secret_key=secret_key),
        "provider_id": FEISHU_ADAPTER_ID,
        "secret_name": secret_key,
        "secret_key": secret_key,
        "metadata": {"env_var": env_var},
    }


def _find_feishu_account(
    accounts: Sequence[Mapping[str, object]],
    *,
    account_id: str,
) -> Mapping[str, object] | None:
    for account in accounts:
        current_account_id = str(account.get("account_id") or DEFAULT_GATEWAY_ACCOUNT_ID)
        if current_account_id == account_id:
            return account
    return None


def _account_secret_env_var(
    account_payload: Mapping[str, object] | None,
    *,
    secret_key: str,
) -> str | None:
    if account_payload is None:
        return None
    env_payload = _mapping(account_payload.get("env")) or {}
    direct = env_payload.get(secret_key)
    if direct is not None:
        text = str(direct).strip()
        if text:
            return text
    secret_refs = account_payload.get("secret_references")
    if not isinstance(secret_refs, list):
        return None
    for item in secret_refs:
        if not isinstance(item, Mapping):
            continue
        if str(item.get("secret_key") or "") != secret_key:
            continue
        metadata = _mapping(item.get("metadata")) or {}
        for key in ("env_var", "env", "environment_variable"):
            candidate = metadata.get(key)
            if candidate is None:
                continue
            text = str(candidate).strip()
            if text:
                return text
    return None


def _payload_string_list(value: object) -> list[str]:
    if value is None:
        return []
    if not isinstance(value, (list, tuple)):
        raise SystemExit("allowlist fields must be JSON arrays when already present in profile.json")
    resolved: list[str] = []
    for item in value:
        text = str(item).strip()
        if text:
            resolved.append(text)
    return list(dict.fromkeys(resolved))


def _default_discord_bot_token_env_var(*, account_id: str) -> str:
    if account_id == DEFAULT_GATEWAY_ACCOUNT_ID:
        return DEFAULT_DISCORD_BOT_TOKEN_ENV
    normalized_account = re.sub(r"[^A-Za-z0-9]+", "_", account_id.strip()).strip("_").upper() or "DEFAULT"
    return f"AEGIS_DISCORD_{normalized_account}_BOT_TOKEN"


def _find_discord_account(
    accounts: Sequence[Mapping[str, object]],
    *,
    account_id: str,
) -> Mapping[str, object] | None:
    for account in accounts:
        current_account_id = str(account.get("account_id") or DEFAULT_GATEWAY_ACCOUNT_ID)
        if current_account_id == account_id:
            return account
    return None


def _resolved_discord_bot_token_env_var(
    *,
    explicit_env_var: object,
    existing_account: Mapping[str, object] | None,
    account_id: str,
) -> str:
    if explicit_env_var is not None:
        text = str(explicit_env_var).strip()
        if text:
            return text
    env_payload = _mapping(existing_account.get("env")) if existing_account is not None else None
    if env_payload is not None:
        candidate = env_payload.get("bot_token")
        if candidate is not None:
            text = str(candidate).strip()
            if text:
                return text
    return _default_discord_bot_token_env_var(account_id=account_id)


def _is_unconfigured_default_discord_account(
    account_payload: Mapping[str, object],
    *,
    state_dir: Path,
    cli_state_dir: Path | None = None,
) -> bool:
    account_id = str(account_payload.get("account_id") or DEFAULT_GATEWAY_ACCOUNT_ID)
    if account_id != DEFAULT_GATEWAY_ACCOUNT_ID:
        return False
    env_var = _account_secret_env_var(account_payload, secret_key="bot_token")
    if env_var is None or env_var != DEFAULT_DISCORD_BOT_TOKEN_ENV:
        return False
    if _payload_string_list(account_payload.get("allow_guild_ids")):
        return False
    if _payload_string_list(account_payload.get("allow_channel_ids")):
        return False
    runtime_payload = _mapping(account_payload.get("runtime")) or {}
    if runtime_payload:
        return False
    runtime_environ = _gateway_runtime_environ(state_dir, cli_state_dir=cli_state_dir)
    if str(runtime_environ.get(DEFAULT_DISCORD_BOT_TOKEN_ENV) or "").strip():
        return False
    if str(runtime_environ.get(LEGACY_DISCORD_BOT_TOKEN_ENV) or "").strip():
        return False
    return True


def _upsert_discord_account(
    accounts: Sequence[Mapping[str, object]],
    account_payload: Mapping[str, object],
    *,
    state_dir: Path | None = None,
    cli_state_dir: Path | None = None,
) -> list[dict[str, object]]:
    target_account_id = str(account_payload.get("account_id") or DEFAULT_GATEWAY_ACCOUNT_ID)
    if (
        target_account_id != DEFAULT_GATEWAY_ACCOUNT_ID
        and state_dir is not None
        and len(accounts) == 1
        and _is_unconfigured_default_discord_account(
            accounts[0],
            state_dir=state_dir,
            cli_state_dir=cli_state_dir,
        )
    ):
        return [{str(key): value for key, value in account_payload.items()}]
    updated: list[dict[str, object]] = []
    replaced = False
    for account in accounts:
        current_account_id = str(account.get("account_id") or DEFAULT_GATEWAY_ACCOUNT_ID)
        if current_account_id == target_account_id:
            updated.append({str(key): value for key, value in account_payload.items()})
            replaced = True
        else:
            updated.append({str(key): value for key, value in account.items()})
    if not replaced:
        updated.append({str(key): value for key, value in account_payload.items()})
    return updated


def _resolved_feishu_secret_env_var(
    *,
    explicit_env_var: object,
    existing_account: Mapping[str, object] | None,
    account_id: str,
    secret_key: str,
) -> str:
    if explicit_env_var is not None:
        text = str(explicit_env_var).strip()
        if text:
            return text
    return _account_secret_env_var(existing_account, secret_key=secret_key) or _default_feishu_secret_env_var(
        account_id=account_id,
        secret_key=secret_key,
    )


def _upsert_feishu_account(
    accounts: Sequence[Mapping[str, object]],
    account_payload: Mapping[str, object],
) -> list[dict[str, object]]:
    target_account_id = str(account_payload.get("account_id") or DEFAULT_GATEWAY_ACCOUNT_ID)
    resolved = [dict(account) for account in accounts]
    for index, account in enumerate(resolved):
        account_id = str(account.get("account_id") or DEFAULT_GATEWAY_ACCOUNT_ID)
        if account_id == target_account_id:
            resolved[index] = dict(account_payload)
            return resolved
    resolved.append(dict(account_payload))
    return resolved


def _resolved_defaults(
    *,
    default_profile_dir_override: Path | None = None,
    default_state_dir_override: Path | None = None,
    default_control_profile_dir_override: Path | None = None,
    default_control_state_dir_override: Path | None = None,
) -> dict[str, Path]:
    return {
        "profile_dir": default_profile_dir_override or default_profile_dir(),
        "state_dir": default_state_dir_override or default_gateway_state_dir(),
        "cli_profile_dir": default_control_profile_dir_override or default_profile_dir(),
        "cli_state_dir": default_control_state_dir_override or default_cli_state_dir(),
    }


def _add_common_gateway_options(parser: ArgumentParser, *, defaults: dict[str, Path]) -> None:
    parser.add_argument("--profile-dir", type=Path, default=defaults["profile_dir"])
    parser.add_argument("--state-dir", type=Path, default=defaults["state_dir"])
    parser.add_argument("--cli-profile-dir", type=Path, default=defaults["cli_profile_dir"])
    parser.add_argument("--cli-state-dir", type=Path, default=defaults["cli_state_dir"])
    parser.add_argument("--workspace-id", default="workspace:gateway")


def _add_http_server_options(parser: ArgumentParser) -> None:
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8788)


def _add_discord_runtime_target_options(
    parser: ArgumentParser,
    *,
    transport_help: str,
    include_account_id: bool = False,
) -> None:
    parser.add_argument(
        "--transport",
        dest="runtime_target",
        choices=("configured", "gateway"),
        default="configured",
        help=transport_help,
    )
    if include_account_id:
        parser.add_argument(
            "--account-id",
            help="Optional Discord gateway account to run. Omit to use the configured account or all configured accounts.",
        )


def _add_discord_start_options(parser: ArgumentParser) -> None:
    _add_discord_runtime_target_options(
        parser,
        transport_help="Which Discord gateway transport to run. 'configured' uses gateway.adapters.discord.accounts[].surface.",
        include_account_id=True,
    )
    parser.add_argument(
        "--detach",
        action="store_true",
        help="Start the Discord gateway transport in a background process and return immediately.",
    )


def _add_discord_status_options(parser: ArgumentParser) -> None:
    _add_discord_runtime_target_options(
        parser,
        transport_help="Which Discord detached transport runtime to inspect. 'configured' uses gateway.adapters.discord.accounts[].surface.",
    )


def _add_discord_stop_options(parser: ArgumentParser) -> None:
    _add_discord_runtime_target_options(
        parser,
        transport_help="Which Discord detached transport runtime to stop. 'configured' uses gateway.adapters.discord.accounts[].surface.",
    )
    parser.add_argument(
        "--timeout",
        type=float,
        default=10.0,
        help="Seconds to wait for a graceful shutdown before failing or forcing.",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Send SIGKILL when the process does not exit within --timeout.",
    )


def _add_discord_restart_options(parser: ArgumentParser) -> None:
    _add_discord_runtime_target_options(
        parser,
        transport_help="Which Discord detached transport runtime to restart. 'configured' uses gateway.adapters.discord.accounts[].surface.",
        include_account_id=True,
    )
    parser.add_argument(
        "--timeout",
        type=float,
        default=10.0,
        help="Seconds to wait for the previous process to exit before failing or forcing.",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Send SIGKILL when the previous process does not exit within --timeout.",
    )


def _add_discord_logs_options(parser: ArgumentParser) -> None:
    _add_discord_runtime_target_options(
        parser,
        transport_help="Which Discord detached transport log to inspect. 'configured' uses gateway.adapters.discord.accounts[].surface.",
    )
    parser.add_argument(
        "--tail",
        type=int,
        default=80,
        help="Show the last N log lines before exiting or following. Use 0 to suppress the initial excerpt.",
    )
    parser.add_argument(
        "--follow",
        action="store_true",
        help="Keep streaming appended log output until interrupted.",
    )
    parser.add_argument(
        "--path",
        action="store_true",
        help="Print the resolved log file path and exit.",
    )


def _add_discord_add_options(parser: ArgumentParser) -> None:
    parser.add_argument(
        "--account-id",
        default=DEFAULT_GATEWAY_ACCOUNT_ID,
        help="Discord gateway account id to create or update.",
    )
    parser.add_argument(
        "--transport",
        choices=SUPPORTED_DISCORD_TRANSPORTS,
        default=None,
        help="Configured transport to persist for this Discord account (defaults to existing or gateway).",
    )
    parser.add_argument(
        "--bot-token-env-var",
        default=None,
        help="Environment variable alias used to resolve the Discord bot token.",
    )
    parser.add_argument(
        "--bot-token",
        default=None,
        help="Optional raw Discord bot token to store in the local gateway secret file instead of profile.json.",
    )
    wizard_group = parser.add_mutually_exclusive_group()
    wizard_group.add_argument(
        "--wizard",
        dest="wizard",
        action="store_true",
        default=None,
        help="Force the interactive Discord setup wizard even when command-line flags are present.",
    )
    wizard_group.add_argument(
        "--no-wizard",
        dest="wizard",
        action="store_false",
        help="Skip the interactive wizard and write configuration directly from CLI arguments.",
    )
    parser.add_argument(
        "--allow-guild-id",
        action="append",
        default=None,
        help="Optional guild allowlist entry. Repeat to allow multiple guilds.",
    )
    parser.add_argument(
        "--allow-channel-id",
        action="append",
        default=None,
        help="Optional channel or parent-channel allowlist entry. Repeat to allow multiple channels.",
    )
    enabled_group = parser.add_mutually_exclusive_group()
    enabled_group.add_argument(
        "--enabled",
        dest="enabled",
        action="store_true",
        default=None,
        help="Include Discord in the active profile for `aegis im describe` and `aegis im doctor`.",
    )
    enabled_group.add_argument(
        "--disabled",
        dest="enabled",
        action="store_false",
        help="Keep Discord configured but excluded from profile-wide IM describe/doctor output.",
    )
    account_enabled_group = parser.add_mutually_exclusive_group()
    account_enabled_group.add_argument(
        "--account-enabled",
        dest="account_enabled",
        action="store_true",
        default=None,
        help="Include this Discord account in default multi-account runtime starts.",
    )
    account_enabled_group.add_argument(
        "--account-disabled",
        dest="account_enabled",
        action="store_false",
        help="Keep this Discord account configured but skip it during default multi-account runtime starts.",
    )


def _add_feishu_runtime_target_options(
    parser: ArgumentParser,
    *,
    transport_help: str,
    include_account_id: bool = False,
) -> None:
    parser.add_argument(
        "--transport",
        dest="runtime_target",
        choices=("configured", "long-connection"),
        default="configured",
        help=transport_help,
    )
    if include_account_id:
        parser.add_argument(
            "--account-id",
            help="Explicit Feishu gateway account to use for long-connection mode.",
        )


def _add_feishu_start_options(parser: ArgumentParser) -> None:
    _add_feishu_runtime_target_options(
        parser,
        transport_help="Which Feishu ingress transport to run. 'configured' uses gateway.adapters.feishu.accounts[].surface.",
        include_account_id=True,
    )
    parser.add_argument(
        "--detach",
        action="store_true",
        help="Start the Feishu transport in a background process and return immediately.",
    )
    _add_http_server_options(parser)



def _add_feishu_status_options(parser: ArgumentParser) -> None:
    _add_feishu_runtime_target_options(
        parser,
        transport_help="Which Feishu detached transport runtime to inspect. 'configured' uses gateway.adapters.feishu.accounts[].surface.",
    )



def _add_feishu_stop_options(parser: ArgumentParser) -> None:
    _add_feishu_runtime_target_options(
        parser,
        transport_help="Which Feishu detached transport runtime to stop. 'configured' uses gateway.adapters.feishu.accounts[].surface.",
    )
    parser.add_argument(
        "--timeout",
        type=float,
        default=10.0,
        help="Seconds to wait for a graceful shutdown before failing or forcing.",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Send SIGKILL when the process does not exit within --timeout.",
    )



def _add_feishu_restart_options(parser: ArgumentParser) -> None:
    _add_feishu_runtime_target_options(
        parser,
        transport_help="Which Feishu detached transport runtime to restart. 'configured' uses gateway.adapters.feishu.accounts[].surface.",
        include_account_id=True,
    )
    _add_http_server_options(parser)
    parser.add_argument(
        "--timeout",
        type=float,
        default=10.0,
        help="Seconds to wait for the previous process to exit before failing or forcing.",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Send SIGKILL when the previous process does not exit within --timeout.",
    )



def _add_feishu_logs_options(parser: ArgumentParser) -> None:
    _add_feishu_runtime_target_options(
        parser,
        transport_help="Which Feishu detached transport log to inspect. 'configured' uses gateway.adapters.feishu.accounts[].surface.",
    )
    parser.add_argument(
        "--tail",
        type=int,
        default=80,
        help="Show the last N log lines before exiting or following. Use 0 to suppress the initial excerpt.",
    )
    parser.add_argument(
        "--follow",
        action="store_true",
        help="Keep streaming appended log output until interrupted.",
    )
    parser.add_argument(
        "--path",
        action="store_true",
        help="Print the resolved log file path and exit.",
    )


def _add_feishu_add_options(parser: ArgumentParser) -> None:
    parser.add_argument(
        "--account-id",
        default=DEFAULT_GATEWAY_ACCOUNT_ID,
        help="Feishu gateway account id to create or update.",
    )
    parser.add_argument(
        "--transport",
        choices=SUPPORTED_FEISHU_TRANSPORTS,
        default=None,
        help="Configured transport to persist for this Feishu account (defaults to existing or long-connection).",
    )
    parser.add_argument(
        "--event-path",
        default=None,
        help="Legacy webhook event path to persist for compatibility (defaults to existing or /feishu/events); long-connection does not use it directly.",
    )
    parser.add_argument(
        "--app-id-env-var",
        default=None,
        help="Environment variable alias used to resolve the Feishu App ID.",
    )
    parser.add_argument(
        "--app-secret-env-var",
        default=None,
        help="Environment variable alias used to resolve the Feishu App Secret / API key.",
    )
    parser.add_argument(
        "--app-id",
        "--api-id",
        dest="app_id",
        default=None,
        help="Optional raw Feishu App ID to store in the local gateway secret file instead of profile.json.",
    )
    parser.add_argument(
        "--app-secret",
        "--api-key",
        dest="app_secret",
        default=None,
        help="Optional raw Feishu App Secret / API key to store in the local gateway secret file instead of profile.json.",
    )
    wizard_group = parser.add_mutually_exclusive_group()
    wizard_group.add_argument(
        "--wizard",
        dest="wizard",
        action="store_true",
        default=None,
        help="Force the interactive Feishu setup wizard even when command-line flags are present.",
    )
    wizard_group.add_argument(
        "--no-wizard",
        dest="wizard",
        action="store_false",
        help="Skip the interactive wizard and write configuration directly from CLI arguments.",
    )
    enabled_group = parser.add_mutually_exclusive_group()
    enabled_group.add_argument(
        "--enabled",
        dest="enabled",
        action="store_true",
        default=None,
        help="Also enable Feishu for `aegis im serve`.",
    )
    enabled_group.add_argument(
        "--disabled",
        dest="enabled",
        action="store_false",
        help="Keep Feishu configured but excluded from `aegis im serve`.",
    )
    parser.add_argument(
        "--default-clone-id",
        help="Default local clone id for the Feishu control bridge.",
    )
    parser.add_argument(
        "--auto-create-clone",
        action="store_true",
        help="Allow the Feishu control bridge to auto-create the default clone when it is missing.",
    )
    parser.add_argument(
        "--allow-group-chats",
        action="store_true",
        help="Allow the Feishu control bridge to accept group chats.",
    )


def _build_registry():
    return build_gateway_plugin_registry()


def _build_app(args: Namespace, *, registry=None):
    args.state_dir.mkdir(parents=True, exist_ok=True)
    app, _, _ = build_gateway_app(
        profile_dir=str(args.profile_dir),
        state_dir=str(args.state_dir),
        workspace_id=args.workspace_id,
        runtime_environ=_gateway_runtime_environ(
            args.state_dir,
            cli_state_dir=args.cli_state_dir,
        ),
        plugin_registry=registry,
    )
    return app


def _service_kwargs_for(service_key: str, args: Namespace) -> dict[str, object]:
    if service_key == "discord":
        return {
            "default_cli_profile_dir": (
                None if args.cli_profile_dir is None else str(args.cli_profile_dir)
            ),
            "default_cli_state_dir": (
                None if args.cli_state_dir is None else str(args.cli_state_dir)
            ),
            "environ": _gateway_runtime_environ(
                args.state_dir,
                cli_state_dir=args.cli_state_dir,
            ),
            "runtime_dependency_ensurer": _ensure_discord_sdk_available,
            "runtime_state_dir": Path(args.state_dir),
        }
    if service_key == "feishu":
        return {
            "default_cli_profile_dir": (
                None if args.cli_profile_dir is None else str(args.cli_profile_dir)
            ),
            "default_cli_state_dir": (
                None if args.cli_state_dir is None else str(args.cli_state_dir)
            ),
            "environ": _gateway_runtime_environ(
                args.state_dir,
                cli_state_dir=args.cli_state_dir,
            ),
            "runtime_dependency_ensurer": _ensure_feishu_sdk_available,
        }
    return {}


def _build_services(
    args: Namespace,
    *,
    service_keys: Iterable[str] | None = None,
):
    registry = _build_registry()
    app = _build_app(args, registry=registry)
    manifest = app.loaded_profile.manifest if app.loaded_profile is not None else None
    resolved_keys = (
        tuple(service_keys)
        if service_keys is not None
        else registry.configured_service_keys(manifest)
    )
    services = {
        key: registry.create_service(
            key,
            app=app,
            **_service_kwargs_for(key, args),
        )
        for key in resolved_keys
    }
    return app, services


def _build_service(
    args: Namespace,
    *,
    service_key: str,
    respect_enabled: bool = False,
):
    registry = _build_registry()
    app = _build_app(args, registry=registry)
    service = registry.create_service(
        service_key,
        app=app,
        respect_enabled=respect_enabled,
        **_service_kwargs_for(service_key, args),
    )
    return service


def _build_feishu_service(args: Namespace) -> FeishuGatewayService:
    service = _build_service(args, service_key="feishu", respect_enabled=False)
    if not isinstance(service, FeishuGatewayService):
        raise TypeError("gateway service plugin 'feishu' must build FeishuGatewayService")
    return service


def _build_discord_service(args: Namespace) -> DiscordGatewayService:
    service = _build_service(args, service_key="discord", respect_enabled=False)
    if not isinstance(service, DiscordGatewayService):
        raise TypeError("gateway service plugin 'discord' must build DiscordGatewayService")
    return service


def _build_managed_service(args: Namespace, *, service_key: str) -> GatewayManagedService:
    service = _build_service(args, service_key=service_key, respect_enabled=False)
    if not isinstance(service, GatewayManagedService):
        raise TypeError(
            f"gateway service plugin '{service_key}' must build a managed gateway service"
        )
    return service


def _describe_payload(service_key: str, service) -> dict[str, object]:
    return {
        "gateway": dict(service.app.setup_summary()),
        service_key: dict(service.describe()),
    }


def _describe_services_payload(
    app,
    services: Mapping[str, object],
) -> dict[str, object]:
    payload: dict[str, object] = {
        "gateway": dict(app.setup_summary()),
        "services": {
            key: dict(service.describe())
            for key, service in services.items()
            if hasattr(service, "describe")
        },
    }
    for key, service in services.items():
        if hasattr(service, "describe"):
            payload[key] = dict(service.describe())
    return payload


def _print_json(payload: dict[str, object]) -> None:
    print(json.dumps(payload, ensure_ascii=False, indent=2, default=str))


def _next_steps(service) -> tuple[str, ...]:
    description = service.describe()
    accounts = tuple(description.get("accounts") or ())
    control = dict(description.get("control") or {})
    steps: list[str] = []
    if description.get("sdk_dependency_status") == "missing_optional_dependency":
        steps.append("Aegis will auto-install the Feishu SDK when you run `aegis im` or `aegis im start`.")
    if any(account.get("credentials_status") != "configured" for account in accounts if isinstance(account, dict)):
        env_vars: list[str] = []
        secret_reference_ids: list[str] = []
        for account in accounts:
            if not isinstance(account, dict):
                continue
            credential_env_vars = account.get("credential_env_vars")
            if isinstance(credential_env_vars, (list, tuple)):
                env_vars.extend(
                    value for value in credential_env_vars if isinstance(value, str) and value
                )
            else:
                env_vars.extend(
                    value
                    for value in (
                        account.get("app_id_env_var"),
                        account.get("app_secret_env_var"),
                    )
                    if isinstance(value, str) and value
                )
            secret_refs = account.get("secret_reference_ids")
            if isinstance(secret_refs, (list, tuple)):
                secret_reference_ids.extend(
                    value for value in secret_refs if isinstance(value, str) and value
                )
        if env_vars:
            steps.append(
                "Complete Feishu IM setup again with `aegis im` to store the App ID and App Secret locally, or export these advanced credential aliases manually: "
                + ", ".join(dict.fromkeys(env_vars))
            )
        elif secret_reference_ids:
            steps.append(
                "Complete Feishu IM setup again with `aegis im` or configure the active Feishu runtime secrets referenced by: "
                + ", ".join(dict.fromkeys(secret_reference_ids))
            )
    if control.get("runtime_status") != "ready":
        steps.append(
            "Make sure the IM bridge can open the local CLI runtime, or pass `--cli-profile-dir` / `--cli-state-dir` explicitly when the launcher defaults are not correct."
        )
    known_clones = tuple(control.get("known_clones") or ()) if isinstance(control, dict) else ()
    if not known_clones:
        steps.append(
            "Create a local clone first with `aegis clone demo`. Once a clone exists, plain text will route to the most recently active clone by default, and `/use demo` can pin the thread explicitly."
        )
    if not steps:
        steps.append("IM wiring looks healthy. Start it with `aegis im start --transport long-connection`. ")
    return tuple(steps)


def _render_discord_account_line(account: Mapping[str, object], *, prefix: str = "discord_account") -> str:
    allow_guild_ids = tuple(account.get("allow_guild_ids") or ())
    allow_channel_ids = tuple(account.get("allow_channel_ids") or ())
    parts = [
        str(account.get("account_id") or DEFAULT_GATEWAY_ACCOUNT_ID),
        f"enabled={'yes' if account.get('enabled') is not False else 'no'}",
        f"startup={account.get('startup_status') or '<unknown>'}",
        f"credentials={account.get('credentials_status') or '<unknown>'}",
        f"surface={account.get('surface') or '<unset>'}",
        f"bot_token_env_var={account.get('bot_token_env_var') or '<unset>'}",
        f"allow_guilds={len(allow_guild_ids)}",
        f"allow_channels={len(allow_channel_ids)}",
    ]
    credentials_error = str(account.get("credentials_error") or "").strip()
    if credentials_error:
        parts.append(f"error={credentials_error}")
    return f"{prefix}: " + " · ".join(parts)


def _feishu_async_status_lines(
    description: Mapping[str, object],
    *,
    prefix: str = "",
) -> tuple[str, ...]:
    recent_failures = tuple(description.get("recent_failures") or ())
    lines = [
        f"{prefix}async_delivery_enabled: {'yes' if description.get('async_delivery_enabled') else 'no'}",
        f"{prefix}queue_depth: {description.get('queue_depth') or 0}",
        f"{prefix}running_jobs: {description.get('running_jobs') or 0}",
        f"{prefix}worker_count: {description.get('worker_count') or 0}",
        f"{prefix}recent_failures: {len(recent_failures)}",
    ]
    for index, failure in enumerate(recent_failures[:3], start=1):
        if not isinstance(failure, Mapping):
            continue
        lines.append(
            f"{prefix}failure[{index}]: "
            f"{failure.get('account_id') or DEFAULT_GATEWAY_ACCOUNT_ID} · "
            f"conversation={failure.get('conversation_id') or '<unknown>'} · "
            f"message={failure.get('message_id') or '<unknown>'} · "
            f"summary={failure.get('failure_summary') or '<unknown>'}"
        )
    return tuple(lines)


def _discord_account_status_lines(
    description: Mapping[str, object],
    *,
    prefix: str = "",
) -> tuple[str, ...]:
    account_status = dict(description.get("account_status") or {})
    if not account_status:
        return ()
    blocked_account_ids = tuple(account_status.get("blocked_account_ids") or ())
    disabled_account_ids = tuple(account_status.get("disabled_account_ids") or ())
    return (
        f"{prefix}account_service_status: {account_status.get('service_status') or '<unknown>'}",
        f"{prefix}configured_accounts: {account_status.get('configured_accounts') or 0}",
        f"{prefix}enabled_accounts: {account_status.get('enabled_accounts') or 0}",
        f"{prefix}runnable_accounts: {account_status.get('runnable_accounts') or 0}",
        f"{prefix}blocked_accounts: {account_status.get('blocked_accounts') or 0}",
        f"{prefix}disabled_accounts: {account_status.get('disabled_accounts') or 0}",
        f"{prefix}blocked_account_ids: "
        + (", ".join(str(account_id) for account_id in blocked_account_ids if account_id) or "<none>"),
        f"{prefix}disabled_account_ids: "
        + (", ".join(str(account_id) for account_id in disabled_account_ids if account_id) or "<none>"),
    )


def _discord_portal_checklist() -> tuple[str, ...]:
    return (
        "Open Discord Developer Portal → OAuth2 → URL Generator and include the `bot` scope before inviting the app.",
        "Enable the Discord `MESSAGE_CONTENT` privileged intent for this bot before starting the gateway runtime.",
        "Grant these bot permissions in Discord: `View Channels` (`查看频道`), `Send Messages` (`发送消息`), `Send Messages in Threads` (`在子区内发送消息`), and `Read Message History` (`阅读消息历史记录`).",
    )


def _discord_next_steps(service) -> tuple[str, ...]:
    description = service.describe()
    accounts = tuple(description.get("accounts") or ())
    account_status = dict(description.get("account_status") or {})
    runtime = dict(description.get("runtime") or {})
    runtime_status = str(runtime.get("runtime_status") or "").strip().lower()
    runtime_target = str(runtime.get("target") or description.get("configured_transport") or "gateway")
    enabled_accounts = int(account_status.get("enabled_accounts") or 0)
    runnable_accounts = int(account_status.get("runnable_accounts") or 0)
    blocked_account_ids = tuple(account_status.get("blocked_account_ids") or ())
    service_status = str(account_status.get("service_status") or "").strip().lower()
    steps: list[str] = []
    if description.get("sdk_dependency_status") == "missing_optional_dependency":
        steps.append("Aegis will auto-install Discord support when you run `aegis im discord start`.")
    missing_credentials = [
        account
        for account in accounts
        if isinstance(account, dict)
        and account.get("enabled") is not False
        and account.get("credentials_status") != "configured"
    ]
    if missing_credentials:
        env_vars = [
            str(account.get("bot_token_env_var"))
            for account in missing_credentials
            if str(account.get("bot_token_env_var") or "").strip()
        ]
        if env_vars:
            steps.append(
                "Configure the Discord bot token with `aegis im add discord --bot-token ...` or export these env vars manually: "
                + ", ".join(dict.fromkeys(env_vars))
            )
    if enabled_accounts == 0:
        steps.append(
            "Enable at least one Discord account for runtime starts with `aegis im add discord --account-enabled --account-id ...` before starting the gateway runtime."
        )
    steps.append(
        "Review the Discord developer portal checklist below before starting the gateway runtime."
    )
    if runtime_status == "running":
        if service_status == "degraded" and blocked_account_ids:
            steps.append(
                f"Discord gateway runtime is already running on `{runtime_target}` in degraded mode; blocked enabled accounts were skipped: {', '.join(str(account_id) for account_id in blocked_account_ids if account_id)}."
            )
        else:
            steps.append(f"Discord gateway runtime is already running on `{runtime_target}`.")
    elif service_status == "degraded" and runnable_accounts > 0:
        steps.append(
            f"Discord wiring is partially ready. Start it with `aegis im discord start --transport {runtime_target}`; runnable enabled accounts will connect while blocked accounts are skipped."
        )
    elif service_status == "ready" and runnable_accounts > 0:
        steps.append(
            f"Discord wiring looks healthy. Start it with `aegis im discord start --transport {runtime_target}`."
        )
    return tuple(steps)


def _doctor_lines(service, args: Namespace) -> tuple[str, ...]:
    description = service.describe()
    accounts = tuple(description.get("accounts") or ())
    control = dict(description.get("control") or {})
    lines = [
        "Aegis IM doctor",
        f"im_profile_dir: {args.profile_dir}",
        f"im_state_dir: {args.state_dir}",
        f"cli_profile_dir: {args.cli_profile_dir}",
        f"cli_state_dir: {args.cli_state_dir}",
        f"configured_transport: {description.get('configured_transport') or '<unset>'}",
        f"sdk_dependency_status: {description.get('sdk_dependency_status')}",
    ]
    lines.extend(_feishu_async_status_lines(description))
    if description.get("configured_transport_error"):
        lines.append(f"configured_transport_error: {description['configured_transport_error']}")
    for account in accounts:
        if not isinstance(account, dict):
            continue
        lines.append(
            "feishu_account: "
            f"{account.get('account_id')} · credentials={account.get('credentials_status')} · "
            f"surface={account.get('surface')} · event_path={account.get('event_path')}"
        )
    lines.append(f"control_runtime_status: {control.get('runtime_status') or '<unknown>'}")
    if control.get("runtime_error"):
        lines.append(f"control_runtime_error: {control['runtime_error']}")
    known_clones = tuple(control.get("known_clones") or ())
    lines.append(
        "control_known_clones: "
        + (", ".join(str(clone) for clone in known_clones if clone) or "<none>")
    )
    lines.append("next_steps:")
    lines.extend(f"- {step}" for step in _next_steps(service))
    return tuple(lines)


def _discord_doctor_lines(service, args: Namespace) -> tuple[str, ...]:
    description = service.describe()
    accounts = tuple(description.get("accounts") or ())
    runtime = dict(description.get("runtime") or {})
    control = dict(description.get("control") or {})
    lines = [
        "Aegis IM doctor",
        f"im_profile_dir: {args.profile_dir}",
        f"im_state_dir: {args.state_dir}",
        f"cli_profile_dir: {args.cli_profile_dir}",
        f"cli_state_dir: {args.cli_state_dir}",
        f"configured_transport: {description.get('configured_transport') or '<unset>'}",
        f"sdk_dependency_status: {description.get('sdk_dependency_status') or '<n/a>'}",
        f"runtime_status: {runtime.get('runtime_status') or '<unknown>'}",
        f"control_runtime_status: {control.get('runtime_status') or '<unknown>'}",
        "required_intents: "
        + ", ".join(str(intent) for intent in tuple(description.get("required_intents") or ()) if intent),
    ]
    lines.extend(_discord_account_status_lines(description))
    if description.get("configured_transport_error"):
        lines.append(f"configured_transport_error: {description['configured_transport_error']}")
    if runtime.get("target"):
        lines.append(f"runtime_target: {runtime['target']}")
    if runtime.get("pid") is not None:
        lines.append(f"runtime_pid: {runtime['pid']}")
    if runtime.get("stale_pid_file"):
        lines.append("runtime_stale_pid_file: yes")
    if control.get("runtime_error"):
        lines.append(f"control_runtime_error: {control['runtime_error']}")
    known_clones = tuple(control.get("known_clones") or ())
    lines.append(
        "control_known_clones: "
        + (", ".join(str(clone) for clone in known_clones if clone) or "<none>")
    )
    for account in accounts:
        if not isinstance(account, dict):
            continue
        lines.append(_render_discord_account_line(account))
    lines.append("discord_portal_checklist:")
    lines.extend(f"- {step}" for step in _discord_portal_checklist())
    lines.append("next_steps:")
    lines.extend(f"- {step}" for step in _discord_next_steps(service))
    return tuple(lines)


def _doctor_service_lines(
    service_key: str,
    service,
) -> tuple[str, ...]:
    def render_account_line(account: Mapping[str, object]) -> str:
        parts = [
            str(account.get("account_id") or "<default>"),
            f"credentials={account.get('credentials_status')}",
            f"surface={account.get('surface')}",
        ]
        if account.get("enabled") is not None:
            parts.append(f"enabled={'yes' if account.get('enabled') is not False else 'no'}")
        if account.get("startup_status") is not None:
            parts.append(f"startup={account.get('startup_status')}")
        if account.get("event_path") is not None:
            parts.append(f"event_path={account.get('event_path')}")
        if account.get("bot_token_env_var") is not None:
            parts.append(f"bot_token_env_var={account.get('bot_token_env_var')}")
        allow_guild_ids = tuple(account.get("allow_guild_ids") or ())
        allow_channel_ids = tuple(account.get("allow_channel_ids") or ())
        if allow_guild_ids:
            parts.append(f"allow_guilds={len(allow_guild_ids)}")
        if allow_channel_ids:
            parts.append(f"allow_channels={len(allow_channel_ids)}")
        return f"service[{service_key}].account: " + " · ".join(parts)

    if service_key == "feishu":
        description = service.describe()
        lines = [
            f"service[{service_key}].configured_transport: {description.get('configured_transport') or '<unset>'}",
            f"service[{service_key}].sdk_dependency_status: {description.get('sdk_dependency_status') or '<n/a>'}",
        ]
        lines.extend(_feishu_async_status_lines(description, prefix=f"service[{service_key}]."))
        for account in tuple(description.get("accounts") or ()):
            if not isinstance(account, dict):
                continue
            lines.append(render_account_line(account))
        return tuple(lines)
    description = service.describe() if hasattr(service, "describe") else {}
    lines = [
        f"service[{service_key}].configured_transport: {description.get('configured_transport') or '<unset>'}",
    ]
    if description.get("configured_transport_error"):
        lines.append(
            f"service[{service_key}].configured_transport_error: {description.get('configured_transport_error')}"
        )
    if description.get("sdk_dependency_status") is not None:
        lines.append(
            f"service[{service_key}].sdk_dependency_status: {description.get('sdk_dependency_status')}"
        )
    runtime = dict(description.get("runtime") or {})
    if runtime:
        lines.append(
            f"service[{service_key}].runtime_status: {runtime.get('runtime_status') or '<unknown>'}"
        )
        if runtime.get("target") is not None:
            lines.append(f"service[{service_key}].runtime_target: {runtime.get('target')}")
    for account in tuple(description.get("accounts") or ()):
        if not isinstance(account, dict):
            continue
        lines.append(render_account_line(account))
    return tuple(lines)


def _doctor_services_lines(app, services: Mapping[str, object], args: Namespace) -> tuple[str, ...]:
    lines = [
        "Aegis IM doctor",
        f"im_profile_dir: {args.profile_dir}",
        f"im_state_dir: {args.state_dir}",
        f"cli_profile_dir: {args.cli_profile_dir}",
        f"cli_state_dir: {args.cli_state_dir}",
        "registered_services: " + (", ".join(services.keys()) or "<none>"),
    ]
    lines.extend(
        line
        for service_key, service in services.items()
        for line in _doctor_service_lines(service_key, service)
    )
    if "feishu" in services:
        lines.append("next_steps:")
        lines.extend(f"- {step}" for step in _next_steps(services["feishu"]))
    elif "discord" in services:
        lines.append("next_steps:")
        lines.extend(f"- {step}" for step in _discord_next_steps(services["discord"]))
    return tuple(lines)


def _run_add_discord(args: Namespace) -> int:
    _ensure_discord_sdk_available(reason="Discord setup")
    args.profile_dir.mkdir(parents=True, exist_ok=True)
    manifest = _load_profile_manifest(args.profile_dir)
    gateway_payload = _mapping_payload(manifest.get("gateway"), path="gateway")
    adapters_payload = _mapping_payload(gateway_payload.get("adapters"), path="gateway.adapters")
    discord_payload = _mapping_payload(adapters_payload.get("discord"), path="gateway.adapters.discord")

    account_id = str(args.account_id or DEFAULT_GATEWAY_ACCOUNT_ID).strip() or DEFAULT_GATEWAY_ACCOUNT_ID
    accounts_value = discord_payload.get("accounts")
    if accounts_value is None:
        existing_accounts: list[dict[str, object]] = []
    elif isinstance(accounts_value, list):
        existing_accounts = []
        for index, account in enumerate(accounts_value):
            if not isinstance(account, Mapping):
                raise SystemExit(
                    f"gateway.adapters.discord.accounts[{index}] must be a JSON object"
                )
            existing_accounts.append({str(key): value for key, value in account.items()})
    else:
        raise SystemExit("gateway.adapters.discord.accounts must be a JSON array")
    existing_account = _find_discord_account(existing_accounts, account_id=account_id)

    transport = (
        str(args.transport or "").strip()
        or str((existing_account or {}).get("surface") or "").strip()
        or str(discord_payload.get("surface") or "").strip()
        or "gateway"
    )
    bot_token_env_var = _resolved_discord_bot_token_env_var(
        explicit_env_var=args.bot_token_env_var,
        existing_account=existing_account,
        account_id=account_id,
    )
    allow_guild_ids = (
        list(dict.fromkeys(str(value).strip() for value in args.allow_guild_id if str(value).strip()))
        if args.allow_guild_id is not None
        else _payload_string_list((existing_account or {}).get("allow_guild_ids"))
    )
    allow_channel_ids = (
        list(dict.fromkeys(str(value).strip() for value in args.allow_channel_id if str(value).strip()))
        if args.allow_channel_id is not None
        else _payload_string_list((existing_account or {}).get("allow_channel_ids"))
    )
    enabled = bool(args.enabled) if args.enabled is not None else bool(discord_payload.get("enabled") is True)
    account_enabled = (
        bool(args.account_enabled)
        if args.account_enabled is not None
        else bool((existing_account or {}).get("enabled") is not False)
    )
    bot_token_value = str(args.bot_token or "").strip()
    use_wizard = bool(args.wizard) if args.wizard is not None else _interactive_shell_supported()
    if use_wizard:
        if not _print_gateway_discord_wizard_intro():
            _print_gateway_setup_paused("Discord")
            return 0
        wizard_state = _run_interactive_discord_wizard(
            account_id=account_id,
            transport=transport,
            bot_token_value=bot_token_value,
            enabled=enabled,
            account_enabled=account_enabled,
            allow_guild_ids=allow_guild_ids,
            allow_channel_ids=allow_channel_ids,
        )
        if wizard_state is None:
            _print_gateway_setup_paused("Discord")
            return 0
        account_id = wizard_state.account_id
        transport = wizard_state.transport
        bot_token_value = wizard_state.bot_token_value
        enabled = wizard_state.enabled
        account_enabled = wizard_state.account_enabled
        allow_guild_ids = list(wizard_state.allow_guild_ids)
        allow_channel_ids = list(wizard_state.allow_channel_ids)

    existing_account = _find_discord_account(existing_accounts, account_id=account_id)
    bot_token_env_var = _resolved_discord_bot_token_env_var(
        explicit_env_var=args.bot_token_env_var,
        existing_account=existing_account,
        account_id=account_id,
    )

    account_payload: dict[str, object] = {
        "account_id": account_id,
        "surface": transport,
        "enabled": account_enabled,
        "env": {"bot_token": bot_token_env_var},
    }
    existing_runtime = _mapping((existing_account or {}).get("runtime"))
    if existing_runtime:
        account_payload["runtime"] = dict(existing_runtime)
    if allow_guild_ids:
        account_payload["allow_guild_ids"] = allow_guild_ids
    if allow_channel_ids:
        account_payload["allow_channel_ids"] = allow_channel_ids

    local_secret_path = _persist_gateway_local_secret_env(
        args.state_dir,
        {bot_token_env_var: bot_token_value},
    )

    discord_payload["accounts"] = _upsert_discord_account(existing_accounts, account_payload)
    discord_payload["surface"] = transport
    discord_payload["enabled"] = enabled
    adapters_payload["discord"] = discord_payload
    gateway_payload["adapters"] = adapters_payload
    manifest["gateway"] = gateway_payload

    manifest_path = write_profile_manifest(args.profile_dir, manifest)

    service = _build_discord_service(args)
    print(f"Configured Discord IM in {manifest_path}")
    print(f"Discord account: {account_id}")
    print(f"Discord transport: {transport}")
    print("Discord account enabled for default runtime starts: " + ("yes" if account_enabled else "no"))
    print("Discord included in profile-wide IM describe/doctor: " + ("yes" if enabled else "no"))
    if local_secret_path is not None:
        print(f"Local IM secret file: {local_secret_path}")
        print("Raw Discord bot token was stored locally outside profile.json.")
    print("next_steps:")
    for step in _discord_next_steps(service):
        print(f"- {step}")
    print("Discord developer portal checklist:")
    for step in _discord_portal_checklist():
        print(f"- {step}")
    print(f"- Start the configured bridge with `aegis im discord start --transport {transport}`.")
    return 0


def _run_add_feishu(args: Namespace) -> int:
    _ensure_feishu_sdk_available(reason="Feishu setup")
    args.profile_dir.mkdir(parents=True, exist_ok=True)
    manifest = _load_profile_manifest(args.profile_dir)
    gateway_payload = _mapping_payload(manifest.get("gateway"), path="gateway")
    adapters_payload = _mapping_payload(gateway_payload.get("adapters"), path="gateway.adapters")
    feishu_payload = _mapping_payload(adapters_payload.get("feishu"), path="gateway.adapters.feishu")
    control_payload = _mapping_payload(feishu_payload.get("control"), path="gateway.adapters.feishu.control")

    account_id = str(args.account_id or DEFAULT_GATEWAY_ACCOUNT_ID).strip() or DEFAULT_GATEWAY_ACCOUNT_ID
    accounts_value = feishu_payload.get("accounts")
    if accounts_value is None:
        existing_accounts: list[dict[str, object]] = []
    elif isinstance(accounts_value, list):
        existing_accounts = []
        for index, account in enumerate(accounts_value):
            if not isinstance(account, Mapping):
                raise SystemExit(
                    f"gateway.adapters.feishu.accounts[{index}] must be a JSON object"
                )
            existing_accounts.append({str(key): value for key, value in account.items()})
    else:
        raise SystemExit("gateway.adapters.feishu.accounts must be a JSON array")

    existing_account = _find_feishu_account(existing_accounts, account_id=account_id)
    transport = (
        str(args.transport)
        if args.transport is not None
        else str(
            (existing_account or {}).get("surface")
            or feishu_payload.get("surface")
            or "long-connection"
        )
    )
    event_path = (
        str(args.event_path)
        if args.event_path is not None
        else str(
            (existing_account or {}).get("event_path")
            or feishu_payload.get("event_path")
            or DEFAULT_FEISHU_EVENT_PATH
        )
    )
    app_id_env_var = _resolved_feishu_secret_env_var(
        explicit_env_var=args.app_id_env_var,
        existing_account=existing_account,
        account_id=account_id,
        secret_key="app_id",
    )
    app_secret_env_var = _resolved_feishu_secret_env_var(
        explicit_env_var=args.app_secret_env_var,
        existing_account=existing_account,
        account_id=account_id,
        secret_key="app_secret",
    )
    app_id_value = str(args.app_id or "").strip()
    app_secret_value = str(args.app_secret or "").strip()
    enabled = bool(args.enabled) if args.enabled is not None else bool(feishu_payload.get("enabled") is True)
    default_clone_id = (
        str(args.default_clone_id).strip()
        if args.default_clone_id is not None
        else str(control_payload.get("default_clone_id") or "").strip()
    )
    auto_create_clone = bool(args.auto_create_clone) or bool(control_payload.get("auto_create_clone") is True)
    allow_group_chats = bool(args.allow_group_chats) or bool(control_payload.get("allow_group_chats") is True)

    use_wizard = bool(args.wizard) if args.wizard is not None else _interactive_shell_supported()
    if use_wizard:
        if not _print_gateway_feishu_wizard_intro():
            _print_gateway_setup_paused("Feishu")
            return 0
        wizard_state = _run_interactive_feishu_wizard(
            account_id=account_id,
            transport=transport,
            event_path=event_path,
            app_id_env_var=app_id_env_var,
            app_secret_env_var=app_secret_env_var,
            app_id_value=app_id_value,
            app_secret_value=app_secret_value,
            enabled=enabled,
            default_clone_id=default_clone_id,
            auto_create_clone=auto_create_clone,
            allow_group_chats=allow_group_chats,
        )
        if wizard_state is None:
            _print_gateway_setup_paused("Feishu")
            return 0
        account_id = wizard_state.account_id
        transport = wizard_state.transport
        event_path = wizard_state.event_path
        app_id_value = wizard_state.app_id_value
        app_secret_value = wizard_state.app_secret_value
        enabled = wizard_state.enabled
        default_clone_id = wizard_state.default_clone_id
        auto_create_clone = wizard_state.auto_create_clone
        allow_group_chats = wizard_state.allow_group_chats

    existing_account = _find_feishu_account(existing_accounts, account_id=account_id)
    app_id_env_var = _resolved_feishu_secret_env_var(
        explicit_env_var=args.app_id_env_var,
        existing_account=existing_account,
        account_id=account_id,
        secret_key="app_id",
    )
    app_secret_env_var = _resolved_feishu_secret_env_var(
        explicit_env_var=args.app_secret_env_var,
        existing_account=existing_account,
        account_id=account_id,
        secret_key="app_secret",
    )

    account_payload = {
        "account_id": account_id,
        "surface": transport,
        "event_path": event_path,
        "secret_references": [
            _build_feishu_secret_reference(
                account_id=account_id,
                secret_key="app_id",
                env_var=app_id_env_var,
            ),
            _build_feishu_secret_reference(
                account_id=account_id,
                secret_key="app_secret",
                env_var=app_secret_env_var,
            ),
        ],
    }
    feishu_payload["accounts"] = _upsert_feishu_account(existing_accounts, account_payload)
    feishu_payload["surface"] = transport
    feishu_payload["event_path"] = event_path
    feishu_payload["enabled"] = enabled

    if default_clone_id:
        control_payload["default_clone_id"] = default_clone_id
    elif use_wizard:
        control_payload.pop("default_clone_id", None)
    if auto_create_clone:
        control_payload["auto_create_clone"] = True
    elif use_wizard:
        control_payload.pop("auto_create_clone", None)
    if allow_group_chats:
        control_payload["allow_group_chats"] = True
    elif use_wizard:
        control_payload.pop("allow_group_chats", None)
    if control_payload:
        feishu_payload["control"] = control_payload
    else:
        feishu_payload.pop("control", None)

    adapters_payload["feishu"] = feishu_payload
    gateway_payload["adapters"] = adapters_payload
    manifest["gateway"] = gateway_payload
    manifest_path = write_profile_manifest(args.profile_dir, manifest)

    local_secret_path = _persist_gateway_local_secret_env(
        args.state_dir,
        {
            app_id_env_var: app_id_value,
            app_secret_env_var: app_secret_value,
        },
    )

    service = _build_feishu_service(args)
    print(f"Configured Feishu IM in {manifest_path}")
    print(f"Feishu account: {account_id}")
    print("Feishu enabled for `aegis im serve`: " + ("yes" if enabled else "no"))
    if local_secret_path is not None:
        print(f"Local IM secret file: {local_secret_path}")
        print("Raw Feishu credentials were stored locally outside profile.json.")
    print("next_steps:")
    for step in _next_steps(service):
        print(f"- {step}")
    print(f"- Start the configured bridge with `aegis im start --transport {transport}`.")
    if enabled:
        print("- Or mount every enabled HTTP gateway service with `aegis im serve`.")
    return 0


def _run_start(service: FeishuGatewayService, args: Namespace) -> int:
    transport = _resolve_runtime_target_argument(args, service=service)

    if transport == "long-connection":
        service.prepare_managed_runtime(action="startup", target=transport)
    if args.detach:
        return _run_start_detached(args, service=service, target=transport)

    if transport == "long-connection":
        account_label = args.account_id or "<default>"
        print("Starting Aegis IM Feishu long-connection transport")
        print(f"Feishu account: {account_label}")
        service.start_long_connection(account_id=args.account_id)
        return 0

    app = create_gateway_web_app({"feishu": service}, app=service.app)
    with make_server(args.host, args.port, app) as server:
        event_paths = ", ".join(service.event_paths) or "<none>"
        print(f"Serving Aegis IM on http://{args.host}:{args.port}")
        print(f"Feishu event paths: {event_paths}")
        server.serve_forever()
    return 0


def _run_discord_start(service: DiscordGatewayService, args: Namespace) -> int:
    transport = _resolve_runtime_target_argument(args, service=service)
    service.prepare_managed_runtime(action="startup", target=transport)
    if args.detach:
        return _run_start_detached(args, service=service, target=transport)

    account_label = args.account_id or "<all enabled>"
    print("Starting Aegis IM Discord gateway transport")
    print(f"Discord account: {account_label}")
    asyncio.run(service.start_gateway(account_id=args.account_id))
    return 0


def _http_services(
    services: Mapping[str, object],
) -> dict[str, GatewayHttpService]:
    return {
        key: service
        for key, service in services.items()
        if isinstance(service, GatewayHttpService)
    }


def _run_serve(args: Namespace) -> int:
    app, services = _build_services(args)
    if not services:
        raise SystemExit("No gateway services are enabled in the active profile manifest.")
    http_services = _http_services(services)
    if not http_services:
        raise SystemExit("No enabled gateway HTTP services are available in the active profile manifest.")
    web_app = create_gateway_web_app(http_services, app=app)
    with make_server(args.host, args.port, web_app) as server:
        print(f"Serving Aegis IM on http://{args.host}:{args.port}")
        for key, service in http_services.items():
            event_paths = ", ".join(getattr(service, "http_paths", ())) or "<none>"
            print(f"{key} event paths: {event_paths}")
        server.serve_forever()
    return 0


def _build_legacy_parser(*, defaults: dict[str, Path]) -> ArgumentParser:
    parser = ArgumentParser(description="Run the Aegis IM surface locally.")
    _add_feishu_start_options(parser)
    _add_common_gateway_options(parser, defaults=defaults)
    parser.add_argument(
        "--describe",
        action="store_true",
        help="Print the active Feishu IM configuration and exit.",
    )
    parser.add_argument(
        "--doctor",
        action="store_true",
        help="Inspect Feishu IM readiness and next steps.",
    )
    return parser


def legacy_main(
    argv: Sequence[str] | None = None,
    *,
    default_profile_dir: Path | None = None,
    default_state_dir: Path | None = None,
    default_control_profile_dir: Path | None = None,
    default_control_state_dir: Path | None = None,
) -> int:
    defaults = _resolved_defaults(
        default_profile_dir_override=default_profile_dir,
        default_state_dir_override=default_state_dir,
        default_control_profile_dir_override=default_control_profile_dir,
        default_control_state_dir_override=default_control_state_dir,
    )
    parser = _build_legacy_parser(defaults=defaults)
    args = parser.parse_args(list(argv) if argv is not None else None)
    service = _build_feishu_service(args)
    if args.describe:
        _print_json(_describe_payload("feishu", service))
        return 0
    if args.doctor:
        print("\n".join(_doctor_lines(service, args)))
        return 0
    return _run_start(service, args)


def command_main(
    argv: Sequence[str] | None = None,
    *,
    default_profile_dir: Path | None = None,
    default_state_dir: Path | None = None,
    default_control_profile_dir: Path | None = None,
    default_control_state_dir: Path | None = None,
) -> int:
    defaults = _resolved_defaults(
        default_profile_dir_override=default_profile_dir,
        default_state_dir_override=default_state_dir,
        default_control_profile_dir_override=default_control_profile_dir,
        default_control_state_dir_override=default_control_state_dir,
    )
    resolved_argv = list(argv) if argv is not None else list(sys.argv[1:])
    if not resolved_argv:
        resolved_argv = ["setup"]
    elif resolved_argv[0].startswith("-"):
        resolved_argv = ["add", "feishu", *resolved_argv]
    elif resolved_argv[0] in {"start", "status", "stop", "restart", "logs"}:
        resolved_argv = ["feishu", *resolved_argv]
    common = ArgumentParser(add_help=False)
    _add_common_gateway_options(common, defaults=defaults)

    parser = ArgumentParser(prog="aegis im", description="Operate the Aegis IM surfaces.")
    subparsers = parser.add_subparsers(dest="command")

    setup = subparsers.add_parser(
        "setup",
        parents=[common],
        help="Choose an IM surface and configure it interactively.",
    )
    setup.add_argument(
        "--default-clone-id",
        default="",
        help="Prefill which clone plain text should route to by default after setup.",
    )
    setup.set_defaults(command_action="setup")

    doctor = subparsers.add_parser(
        "doctor",
        parents=[common],
        help="Inspect all active IM services and next steps.",
    )
    doctor.set_defaults(command_action="doctor_all")

    describe = subparsers.add_parser(
        "describe",
        parents=[common],
        help="Print the active multi-service IM configuration as JSON.",
    )
    describe.set_defaults(command_action="describe_all")

    serve = subparsers.add_parser(
        "serve",
        parents=[common],
        help="Serve all enabled IM HTTP services in one process.",
    )
    _add_http_server_options(serve)
    serve.set_defaults(command_action="serve_all")

    add = subparsers.add_parser(
        "add",
        help="Write IM configuration into the active profile manifest.",
    )
    add_subparsers = add.add_subparsers(dest="add_command")
    add_feishu = add_subparsers.add_parser(
        "feishu",
        parents=[common],
        help="Add or update Feishu IM wiring in the active profile.",
    )
    _add_feishu_add_options(add_feishu)
    add_feishu.set_defaults(command_action="add_feishu")

    add_discord = add_subparsers.add_parser(
        "discord",
        parents=[common],
        help="Add or update Discord IM wiring in the active profile.",
    )
    _add_discord_add_options(add_discord)
    add_discord.set_defaults(command_action="add_discord")

    feishu = subparsers.add_parser("feishu", help="Operate the Feishu IM surface.")
    feishu_subparsers = feishu.add_subparsers(dest="feishu_command")

    feishu_start = feishu_subparsers.add_parser(
        "start",
        parents=[common],
        help="Start the Feishu IM server or long-connection transport.",
    )
    _add_feishu_start_options(feishu_start)
    feishu_start.set_defaults(command_action="start")

    feishu_status = feishu_subparsers.add_parser(
        "status",
        parents=[common],
        help="Inspect the detached Feishu runtime status.",
    )
    _add_feishu_status_options(feishu_status)
    feishu_status.set_defaults(command_action="status")

    feishu_stop = feishu_subparsers.add_parser(
        "stop",
        parents=[common],
        help="Stop the detached Feishu runtime for one transport.",
    )
    _add_feishu_stop_options(feishu_stop)
    feishu_stop.set_defaults(command_action="stop")

    feishu_restart = feishu_subparsers.add_parser(
        "restart",
        parents=[common],
        help="Restart the detached Feishu runtime for one transport.",
    )
    _add_feishu_restart_options(feishu_restart)
    feishu_restart.set_defaults(command_action="restart")

    feishu_logs = feishu_subparsers.add_parser(
        "logs",
        parents=[common],
        help="Inspect the detached Feishu IM process log.",
    )
    _add_feishu_logs_options(feishu_logs)
    feishu_logs.set_defaults(command_action="logs")

    feishu_describe = feishu_subparsers.add_parser(
        "describe",
        parents=[common],
        help="Print the active Feishu IM configuration as JSON.",
    )
    feishu_describe.set_defaults(command_action="describe")

    feishu_doctor = feishu_subparsers.add_parser(
        "doctor",
        parents=[common],
        help="Inspect Feishu IM readiness and next steps.",
    )
    feishu_doctor.set_defaults(command_action="doctor", service_key="feishu")

    discord = subparsers.add_parser("discord", help="Operate the Discord IM surface.")
    discord_subparsers = discord.add_subparsers(dest="discord_command")

    discord_start = discord_subparsers.add_parser(
        "start",
        parents=[common],
        help="Start the Discord gateway transport.",
    )
    _add_discord_start_options(discord_start)
    discord_start.set_defaults(command_action="start", service_key="discord")

    discord_status = discord_subparsers.add_parser(
        "status",
        parents=[common],
        help="Inspect the detached Discord runtime status.",
    )
    _add_discord_status_options(discord_status)
    discord_status.set_defaults(command_action="status", service_key="discord")

    discord_stop = discord_subparsers.add_parser(
        "stop",
        parents=[common],
        help="Stop the detached Discord runtime.",
    )
    _add_discord_stop_options(discord_stop)
    discord_stop.set_defaults(command_action="stop", service_key="discord")

    discord_restart = discord_subparsers.add_parser(
        "restart",
        parents=[common],
        help="Restart the detached Discord runtime.",
    )
    _add_discord_restart_options(discord_restart)
    discord_restart.set_defaults(command_action="restart", service_key="discord")

    discord_logs = discord_subparsers.add_parser(
        "logs",
        parents=[common],
        help="Inspect the detached Discord IM process log.",
    )
    _add_discord_logs_options(discord_logs)
    discord_logs.set_defaults(command_action="logs", service_key="discord")

    discord_describe = discord_subparsers.add_parser(
        "describe",
        parents=[common],
        help="Print the active Discord IM configuration as JSON.",
    )
    discord_describe.set_defaults(command_action="describe", service_key="discord")

    discord_doctor = discord_subparsers.add_parser(
        "doctor",
        parents=[common],
        help="Inspect Discord IM readiness and next steps.",
    )
    discord_doctor.set_defaults(command_action="doctor", service_key="discord")

    args = parser.parse_args(resolved_argv)
    action = getattr(args, "command_action", None)
    if action is None:
        parser.print_help()
        return 2
    if action == "setup":
        return run_im_setup(
            default_clone_id=str(args.default_clone_id or "").strip(),
            default_profile_dir=args.profile_dir,
            default_state_dir=args.state_dir,
            default_control_profile_dir=args.cli_profile_dir,
            default_control_state_dir=args.cli_state_dir,
        )
    if action == "describe_all":
        app, services = _build_services(args)
        _print_json(_describe_services_payload(app, services))
        return 0
    if action == "doctor_all":
        app, services = _build_services(args)
        print("\n".join(_doctor_services_lines(app, services, args)))
        return 0
    if action == "serve_all":
        return _run_serve(args)
    if action == "add_discord":
        return _run_add_discord(args)
    if action == "add_feishu":
        return _run_add_feishu(args)

    service_key = str(getattr(args, "service_key", "feishu") or "feishu")
    service: object | None = None
    managed_service: GatewayManagedService | None = None

    def ensure_service() -> object:
        nonlocal service
        if service is None:
            if service_key == "discord":
                service = _build_discord_service(args)
            elif service_key == "feishu":
                service = _build_feishu_service(args)
            else:
                raise SystemExit(f"Unsupported IM service: {service_key}")
        return service

    def ensure_managed_service() -> GatewayManagedService:
        nonlocal managed_service
        if managed_service is None:
            managed_service = _build_managed_service(args, service_key=service_key)
        return managed_service

    if action == "describe":
        _print_json(_describe_payload(service_key, ensure_service()))
        return 0
    if action == "doctor":
        if service_key == "discord":
            print("\n".join(_discord_doctor_lines(ensure_service(), args)))
        else:
            print("\n".join(_doctor_lines(ensure_service(), args)))
        return 0
    if action == "status":
        return _run_status(args, service=ensure_managed_service())
    if action == "stop":
        return _run_stop(args, service=ensure_managed_service())
    if action == "restart":
        return _run_restart(args, service=ensure_managed_service())
    if action == "logs":
        return _run_logs(args, service=ensure_managed_service())
    if service_key == "discord":
        discord_service = ensure_service()
        if not isinstance(discord_service, DiscordGatewayService):
            raise TypeError("gateway service plugin 'discord' must build DiscordGatewayService")
        return _run_discord_start(discord_service, args)
    feishu_service = ensure_service()
    if not isinstance(feishu_service, FeishuGatewayService):
        raise TypeError("gateway service plugin 'feishu' must build FeishuGatewayService")
    return _run_start(feishu_service, args)


def run_im_setup(
    *,
    default_clone_id: str = "",
    default_profile_dir: Path | None = None,
    default_state_dir: Path | None = None,
    default_control_profile_dir: Path | None = None,
    default_control_state_dir: Path | None = None,
    prompt_title: str = "𓅃 IM Setup",
    prompt_text: str = "𓅃 Which IM should Aegis configure right now?",
    allow_skip: bool = False,
) -> int:
    answer = _gateway_wizard_choice_prompt(
        prompt_title,
        prompt_text,
        _im_setup_choices(allow_skip=allow_skip),
        default="skip" if allow_skip else "feishu",
        allow_back=not allow_skip,
    )
    if answer is GATEWAY_WIZARD_BACK or answer == "skip":
        return 0
    if answer not in {"feishu", "discord"}:
        raise SystemExit(f"Unsupported IM setup target: {answer}")
    argv = ["add", str(answer), "--wizard"]
    if answer == "feishu" and default_clone_id:
        argv.extend(["--default-clone-id", default_clone_id])
    return command_main(
        argv,
        default_profile_dir=default_profile_dir,
        default_state_dir=default_state_dir,
        default_control_profile_dir=default_control_profile_dir,
        default_control_state_dir=default_control_state_dir,
    )


def main(
    argv: Sequence[str] | None = None,
    *,
    default_profile_dir: Path | None = None,
    default_state_dir: Path | None = None,
    default_control_profile_dir: Path | None = None,
    default_control_state_dir: Path | None = None,
) -> int:
    resolved_argv = list(argv) if argv is not None else list(sys.argv[1:])
    if not resolved_argv or resolved_argv[0] in {
        "setup",
        "doctor",
        "describe",
        "serve",
        "add",
        "discord",
        "feishu",
        "start",
        "status",
        "stop",
        "restart",
        "logs",
    }:
        return command_main(
            resolved_argv,
            default_profile_dir=default_profile_dir,
            default_state_dir=default_state_dir,
            default_control_profile_dir=default_control_profile_dir,
            default_control_state_dir=default_control_state_dir,
        )
    return legacy_main(
        resolved_argv,
        default_profile_dir=default_profile_dir,
        default_state_dir=default_state_dir,
        default_control_profile_dir=default_control_profile_dir,
        default_control_state_dir=default_control_state_dir,
    )


if __name__ == "__main__":
    raise SystemExit(main())
