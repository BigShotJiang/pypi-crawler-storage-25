"""Discord gateway bootstrap, service description, and delivery wiring."""

from __future__ import annotations

import asyncio
from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
import importlib.util
import inspect
import io
import json
import os
from pathlib import Path
from typing import Any, Protocol, runtime_checkable
from uuid import uuid4

from apps.runtime_layout import default_cli_state_dir, default_profile_dir
from packages.gateway_core import GatewayExchange, GatewayInboundMessage, GatewayOutboundMessage

from .cli_control import (
    CliRuntimeFactory,
    GatewayCliBindingStore,
    GatewayCliControlService,
    load_gateway_cli_control_config,
)
from .plugins import GatewayManagedRuntime, GatewayPluginRegistry, default_gateway_runtime_path
from .runtime import (
    DEFAULT_GATEWAY_ACCOUNT_ID,
    DISCORD_ADAPTER_ID,
    DiscordMessagingAdapter,
    GatewayApp,
    build_gateway_app,
)

DEFAULT_DISCORD_BOT_TOKEN_ENV = "AEGIS_DISCORD_BOT_TOKEN"
LEGACY_DISCORD_BOT_TOKEN_ENV = "DISCORD_BOT_TOKEN"
SUPPORTED_DISCORD_TRANSPORTS = ("gateway",)
REQUIRED_DISCORD_INTENTS = ("guilds", "messages", "message_content")
PRIVILEGED_DISCORD_INTENTS = ("message_content",)
DISCORD_PY_PIP_SPEC = "discord.py>=2.6,<3"
DISCORD_MESSAGE_CONTENT_LIMIT = 2000
DISCORD_FENCE_SPLIT_RESERVE = 32
DISCORD_ATTACHMENT_FALLBACK_THRESHOLD = 8000
DISCORD_ATTACHMENT_FALLBACK_FILENAME = "reply.md"

DiscordClientFactory = Callable[[Any, object], object]
DiscordDeliveryTransportFactory = Callable[[object, Any], "DiscordDeliveryTransport"]


def _mapping(value: object) -> Mapping[str, object] | None:
    return value if isinstance(value, Mapping) else None


def _normalize_transport(value: str | None) -> str:
    normalized = str(value or "gateway").strip().lower().replace("_", "-")
    if normalized in {"gateway", "discord-gateway"}:
        return "gateway"
    raise ValueError(
        "discord transport must be one of "
        f"{', '.join(SUPPORTED_DISCORD_TRANSPORTS)}"
    )


def _string_list(value: object, *, field_name: str) -> tuple[str, ...]:
    if value is None:
        return ()
    if not isinstance(value, list):
        raise ValueError(f"{field_name} must be a JSON array")
    resolved: list[str] = []
    for item in value:
        text = str(item).strip()
        if text:
            resolved.append(text)
    return tuple(dict.fromkeys(resolved))


def _discord_py_dependency_status() -> str:
    return "installed" if importlib.util.find_spec("discord") is not None else "missing_optional_dependency"


def _load_discord_sdk(discord_module: Any | None = None) -> Any:
    if discord_module is not None:
        return discord_module
    try:
        import discord  # type: ignore[import-not-found]
    except ImportError as exc:  # pragma: no cover - exercised by runtime preflight
        raise RuntimeError(
            "Discord gateway transport requires the bundled dependency "
            "'discord.py'. Reinstall Aegis or add the package to your environment if it is missing."
        ) from exc
    return discord


def _default_discord_client_factory(discord_module: Any, intents: object) -> object:
    client_type = getattr(discord_module, "Client", None)
    if client_type is None:
        raise RuntimeError("discord.py Client is unavailable")
    return client_type(intents=intents)


def _default_discord_delivery_transport_factory(
    client: object,
    discord_module: Any,
) -> "DiscordPyDeliveryTransport":
    return DiscordPyDeliveryTransport(client=client, discord_module=discord_module)


def _snowflake(value: object) -> int | str:
    text = str(value).strip()
    if text.isdigit():
        return int(text)
    return text


def _discord_intents(discord_module: Any) -> object:
    intents_type = getattr(discord_module, "Intents", None)
    if intents_type is None or not hasattr(intents_type, "none"):
        raise RuntimeError("discord.py Intents.none() is unavailable")
    intents = intents_type.none()
    for field_name in REQUIRED_DISCORD_INTENTS:
        if not hasattr(intents, field_name):
            raise RuntimeError(f"discord.py intents object is missing '{field_name}'")
        setattr(intents, field_name, True)
    return intents


async def _maybe_await(result: object) -> object:
    if inspect.isawaitable(result):
        return await result
    return result


def _optional_text(value: object) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def _coerce_int(value: object) -> int | None:
    if value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _coerce_bool(value: object, *, default: bool) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized in {"1", "true", "yes", "on"}:
            return True
        if normalized in {"0", "false", "no", "off"}:
            return False
    return bool(value)


def _split_discord_message_content(
    content: str,
    *,
    limit: int = DISCORD_MESSAGE_CONTENT_LIMIT,
) -> tuple[str, ...]:
    if limit <= 0:
        raise ValueError("discord message content limit must be positive")
    if len(content) <= limit:
        return (content,)
    chunks: list[str] = []
    remaining = content
    preferred_split_floor = max(1, limit // 2)
    while len(remaining) > limit:
        boundary = remaining.rfind("\n", 0, limit)
        if boundary < preferred_split_floor:
            boundary = remaining.rfind(" ", 0, limit)
        cut = limit if boundary < preferred_split_floor else boundary + 1
        chunks.append(remaining[:cut])
        remaining = remaining[cut:]
    if remaining or not chunks:
        chunks.append(remaining)
    return tuple(chunks)



def _discord_fence_state(content: str) -> str | None:
    open_fence: str | None = None
    for raw_line in content.split("\n"):
        stripped = raw_line.strip()
        if not stripped.startswith("```"):
            continue
        if open_fence is None:
            open_fence = stripped
        else:
            open_fence = None
    return open_fence



def _rebalance_discord_fenced_chunks(
    chunks: tuple[str, ...],
    *,
    limit: int = DISCORD_MESSAGE_CONTENT_LIMIT,
) -> tuple[str, ...]:
    if len(chunks) <= 1 or not any("```" in chunk for chunk in chunks):
        return chunks
    balanced: list[str] = []
    reopened_fence: str | None = None
    for index, original_chunk in enumerate(chunks):
        chunk = original_chunk if reopened_fence is None else f"{reopened_fence}\n{original_chunk}"
        reopened_fence = _discord_fence_state(chunk)
        if reopened_fence is not None and index < len(chunks) - 1:
            chunk = f"{chunk}\n```"
        if len(chunk) > limit:
            raise RuntimeError("discord fenced content chunk exceeds message content limit")
        balanced.append(chunk)
    if reopened_fence is not None and balanced:
        final_chunk = f"{balanced[-1]}\n```"
        if len(final_chunk) > limit:
            raise RuntimeError("discord fenced content chunk exceeds message content limit")
        balanced[-1] = final_chunk
    return tuple(balanced)


def _read_runtime_record(path: Path) -> Mapping[str, object] | None:
    if not path.exists():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    if not isinstance(payload, Mapping):
        return None
    return payload


def _read_pid(path: Path) -> int | None:
    if not path.exists():
        return None
    try:
        return int(path.read_text(encoding="utf-8").strip())
    except (OSError, ValueError):
        return None


def _pid_is_running(pid: int | None) -> bool:
    if pid is None or pid <= 0:
        return False
    try:
        os.kill(pid, 0)
    except OSError:
        return False
    return True


def _managed_runtime_state(*, pid_path: Path, record_path: Path) -> Mapping[str, object]:
    record = dict(_read_runtime_record(record_path) or {})
    pid_from_file = _read_pid(pid_path)
    pid_from_record = _coerce_int(record.get("pid"))
    pid = pid_from_file if pid_from_file is not None else pid_from_record
    pid_active = _pid_is_running(pid)
    record_status = _optional_text(record.get("status")) or "stopped"
    if pid_active:
        runtime_status = "running"
    elif record_status == "failed":
        runtime_status = "failed"
    else:
        runtime_status = "stopped"
    return {
        "record": record,
        "pid": pid,
        "pid_active": pid_active,
        "stale_pid": pid_from_file is not None and not pid_active,
        "runtime_status": runtime_status,
        "recorded_status": record_status,
    }


@dataclass(frozen=True, slots=True)
class DiscordGatewayAccountConfig:
    account_id: str = DEFAULT_GATEWAY_ACCOUNT_ID
    bot_token_env_var: str = DEFAULT_DISCORD_BOT_TOKEN_ENV
    surface: str = "gateway"
    enabled: bool = True
    allow_guild_ids: tuple[str, ...] = ()
    allow_channel_ids: tuple[str, ...] = ()
    runtime_metadata: Mapping[str, object] = field(default_factory=dict)
    metadata: Mapping[str, object] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class DiscordResolvedAccount:
    account_id: str
    bot_token: str
    config: DiscordGatewayAccountConfig


@dataclass(frozen=True, slots=True)
class DiscordGatewayEventResult:
    exchange: GatewayExchange | None
    response_body: Mapping[str, object]
    delivery_request: Mapping[str, object] | None = None
    delivery_response: Mapping[str, object] | None = None


@runtime_checkable
class DiscordDeliveryTransport(Protocol):
    async def send_request(
        self,
        request: Mapping[str, object],
        *,
        account: DiscordResolvedAccount,
    ) -> Mapping[str, object]:
        """Send one normalized Discord outbound request."""


@dataclass(frozen=True, slots=True)
class DiscordPyDeliveryTransport:
    client: object
    discord_module: Any

    async def send_request(
        self,
        request: Mapping[str, object],
        *,
        account: DiscordResolvedAccount,
    ) -> Mapping[str, object]:
        del account
        body = _mapping(request.get("body"))
        if body is None:
            raise RuntimeError("discord delivery request is missing the body payload")
        channel = await self._resolve_channel(request)
        content = str(body.get("content") or "")
        allowed_mentions = self._allowed_mentions()
        reply_message_id: str | None = None
        reply_payload = _mapping(body.get("message_reference"))
        if reply_payload is not None:
            resolved_reply_message_id = str(reply_payload.get("message_id") or "").strip()
            if resolved_reply_message_id:
                reply_message_id = resolved_reply_message_id
        if len(content) > DISCORD_ATTACHMENT_FALLBACK_THRESHOLD:
            attachment = self._build_text_attachment(content)
            if attachment is not None:
                message = await self._send_attachment_fallback(
                    channel=channel,
                    content=content,
                    attachment=attachment,
                    allowed_mentions=allowed_mentions,
                    reply_message_id=reply_message_id,
                )
                return {
                    "id": str(getattr(message, "id", "")),
                    "channel_id": str(getattr(channel, "id", request.get("channel_id") or "")),
                    "chunk_count": 1,
                    "delivery_mode": "attachment",
                    "attachment_filename": DISCORD_ATTACHMENT_FALLBACK_FILENAME,
                }
        chunk_limit = (
            DISCORD_MESSAGE_CONTENT_LIMIT - DISCORD_FENCE_SPLIT_RESERVE
            if "```" in content
            else DISCORD_MESSAGE_CONTENT_LIMIT
        )
        content_chunks = _rebalance_discord_fenced_chunks(
            _split_discord_message_content(content, limit=chunk_limit)
        )
        message = await self._send_content_chunks(
            channel=channel,
            content_chunks=content_chunks,
            allowed_mentions=allowed_mentions,
            reply_message_id=reply_message_id,
        )
        return {
            "id": str(getattr(message, "id", "")),
            "channel_id": str(getattr(channel, "id", request.get("channel_id") or "")),
            "chunk_count": len(content_chunks),
            "delivery_mode": "chunked" if len(content_chunks) > 1 else "inline",
        }

    def _build_text_attachment(self, content: str) -> object | None:
        file_type = getattr(self.discord_module, "File", None)
        if file_type is None:
            return None
        return file_type(
            fp=io.BytesIO(content.encode("utf-8")),
            filename=DISCORD_ATTACHMENT_FALLBACK_FILENAME,
            description="Full Discord reply body",
        )

    async def _send_attachment_fallback(
        self,
        *,
        channel: object,
        content: str,
        attachment: object,
        allowed_mentions: object | None,
        reply_message_id: str | None,
    ) -> object:
        notice = self._attachment_notice(content)
        return await self._send_reply_or_channel_message(
            channel=channel,
            content=notice,
            allowed_mentions=allowed_mentions,
            reply_message_id=reply_message_id,
            file=attachment,
        )

    def _attachment_notice(self, content: str) -> str:
        return (
            "Reply too long for Discord inline delivery "
            f"({len(content)} chars); full content is attached as "
            f"{DISCORD_ATTACHMENT_FALLBACK_FILENAME}."
        )

    async def _send_content_chunks(
        self,
        *,
        channel: object,
        content_chunks: tuple[str, ...],
        allowed_mentions: object | None,
        reply_message_id: str | None,
    ) -> object:
        first_chunk, *remaining_chunks = content_chunks
        message = await self._send_reply_or_channel_message(
            channel=channel,
            content=first_chunk,
            allowed_mentions=allowed_mentions,
            reply_message_id=reply_message_id,
        )
        for chunk in remaining_chunks:
            await self._send_channel_message(
                channel=channel,
                content=chunk,
                allowed_mentions=allowed_mentions,
            )
        return message

    async def _send_reply_or_channel_message(
        self,
        *,
        channel: object,
        content: str,
        allowed_mentions: object | None,
        reply_message_id: str | None,
        file: object | None = None,
    ) -> object:
        if reply_message_id and hasattr(channel, "get_partial_message"):
            partial_message = channel.get_partial_message(_snowflake(reply_message_id))
            reply = getattr(partial_message, "reply", None)
            if callable(reply):
                return await _maybe_await(
                    reply(
                        content=content,
                        allowed_mentions=allowed_mentions,
                        mention_author=False,
                        file=file,
                    )
                )
        return await self._send_channel_message(
            channel=channel,
            content=content,
            allowed_mentions=allowed_mentions,
            file=file,
        )

    async def _send_channel_message(
        self,
        *,
        channel: object,
        content: str,
        allowed_mentions: object | None,
        file: object | None = None,
    ) -> object:
        send = getattr(channel, "send", None)
        if not callable(send):
            raise RuntimeError("discord channel does not expose send()")
        return await _maybe_await(
            send(
                content=content,
                allowed_mentions=allowed_mentions,
                file=file,
            )
        )

    async def _resolve_channel(self, request: Mapping[str, object]) -> object:
        channel_id = request.get("channel_id")
        if channel_id is None:
            raise RuntimeError("discord delivery request is missing channel_id")
        resolved_channel_id = _snowflake(channel_id)
        get_channel = getattr(self.client, "get_channel", None)
        if callable(get_channel):
            channel = get_channel(resolved_channel_id)
            if channel is not None:
                return channel
        fetch_channel = getattr(self.client, "fetch_channel", None)
        if callable(fetch_channel):
            channel = await _maybe_await(fetch_channel(resolved_channel_id))
            if channel is not None:
                return channel
        raise RuntimeError(f"discord channel '{channel_id}' is unavailable to the active client")

    def _allowed_mentions(self) -> object | None:
        allowed_mentions_type = getattr(self.discord_module, "AllowedMentions", None)
        if allowed_mentions_type is None:
            return None
        return allowed_mentions_type(
            everyone=False,
            users=False,
            roles=False,
            replied_user=False,
        )


def load_discord_gateway_accounts(
    app: GatewayApp,
    *,
    respect_enabled: bool = True,
    include_disabled: bool = False,
) -> tuple[DiscordGatewayAccountConfig, ...]:
    manifest = app.loaded_profile.manifest if app.loaded_profile is not None else {}
    gateway_payload = _mapping(manifest.get("gateway")) or {}
    adapters_payload = _mapping(gateway_payload.get("adapters")) or {}
    discord_payload = _mapping(adapters_payload.get("discord"))
    if respect_enabled and discord_payload is not None and discord_payload.get("enabled") is False:
        return ()

    default_surface = _normalize_transport((discord_payload or {}).get("surface"))
    accounts_payload = (discord_payload or {}).get("accounts")
    if isinstance(accounts_payload, list) and accounts_payload:
        resolved: list[DiscordGatewayAccountConfig] = []
        for index, account_payload in enumerate(accounts_payload):
            account_mapping = _mapping(account_payload)
            if account_mapping is None:
                raise ValueError("gateway.adapters.discord.accounts entries must be JSON objects")
            account_enabled = _coerce_bool(account_mapping.get("enabled"), default=True)
            if not include_disabled and not account_enabled:
                continue
            env_payload = _mapping(account_mapping.get("env")) or {}
            runtime_payload = _mapping(account_mapping.get("runtime")) or {}
            resolved.append(
                DiscordGatewayAccountConfig(
                    account_id=str(account_mapping.get("account_id") or DEFAULT_GATEWAY_ACCOUNT_ID),
                    bot_token_env_var=str(
                        env_payload.get("bot_token") or DEFAULT_DISCORD_BOT_TOKEN_ENV
                    ),
                    surface=str(account_mapping.get("surface") or default_surface),
                    enabled=account_enabled,
                    allow_guild_ids=_string_list(
                        account_mapping.get("allow_guild_ids"),
                        field_name="gateway.adapters.discord.accounts[].allow_guild_ids",
                    ),
                    allow_channel_ids=_string_list(
                        account_mapping.get("allow_channel_ids"),
                        field_name="gateway.adapters.discord.accounts[].allow_channel_ids",
                    ),
                    runtime_metadata=dict(runtime_payload),
                    metadata={"manifest_index": index},
                )
            )
        return tuple(resolved)

    return (DiscordGatewayAccountConfig(surface=default_surface),)


def resolve_discord_account(
    config: DiscordGatewayAccountConfig,
    *,
    environ: Mapping[str, str] | None = None,
) -> DiscordResolvedAccount:
    env = environ or os.environ
    bot_token = str(env.get(config.bot_token_env_var) or "").strip()
    if not bot_token and config.bot_token_env_var == DEFAULT_DISCORD_BOT_TOKEN_ENV:
        bot_token = str(env.get(LEGACY_DISCORD_BOT_TOKEN_ENV) or "").strip()
    if not bot_token:
        raise LookupError(
            f"discord account '{config.account_id}' requires {config.bot_token_env_var}"
        )
    return DiscordResolvedAccount(
        account_id=config.account_id,
        bot_token=bot_token,
        config=config,
    )


@dataclass(slots=True)
class DiscordGatewayService:
    app: GatewayApp
    account_configs: tuple[DiscordGatewayAccountConfig, ...] = ()
    environ: Mapping[str, str] = field(default_factory=lambda: dict(os.environ))
    adapter: DiscordMessagingAdapter | None = None
    cli_runtime_factory: CliRuntimeFactory | None = None
    cli_binding_store: GatewayCliBindingStore | None = None
    cli_control: GatewayCliControlService | None = None
    default_cli_profile_dir: str | None = None
    default_cli_state_dir: str | None = None
    runtime_dependency_ensurer: Callable[..., object] | None = None
    respect_enabled: bool = True
    service_key: str = "discord"
    runtime_state_dir: Path | None = None

    def __post_init__(self) -> None:
        if not self.account_configs:
            self.account_configs = load_discord_gateway_accounts(
                self.app,
                respect_enabled=self.respect_enabled,
                include_disabled=True,
            )
        if self.adapter is None:
            self.adapter = DiscordMessagingAdapter(app=self.app)
        if self.cli_control is None and self.app.loaded_profile is not None:
            config = load_gateway_cli_control_config(
                self.app.loaded_profile.manifest,
                adapter_key="discord",
            )
            if config is not None:
                binding_store = self.cli_binding_store
                if binding_store is None:
                    state_root = self.app.state_dir
                    binding_path = (
                        None
                        if state_root is None
                        else os.path.join(state_root, "discord-cli-bindings.json")
                    )
                    binding_store = GatewayCliBindingStore(
                        path=None if binding_path is None else Path(binding_path)
                    )
                self.cli_control = GatewayCliControlService(
                    config=self._resolved_cli_control_config(config),
                    runtime_factory=self.cli_runtime_factory,
                    binding_store=binding_store,
                    surface_label="Discord",
                    binding_subject="channel",
                    control_config_path="gateway.adapters.discord.control",
                )

    def _resolved_cli_control_config(self, config) -> object:
        profile_dir = config.profile_dir or self.default_cli_profile_dir or self.app.profile_dir
        if profile_dir is None:
            profile_dir = str(default_profile_dir(environ=self.environ))
        state_dir = config.state_dir or self.default_cli_state_dir or self._inferred_cli_state_dir()
        if state_dir is None:
            state_dir = str(default_cli_state_dir(environ=self.environ))
        return type(config)(
            profile_dir=profile_dir,
            state_dir=state_dir,
            default_clone_id=config.default_clone_id,
            auto_create_clone=config.auto_create_clone,
            allow_group_chats=config.allow_group_chats,
        )

    def _inferred_cli_state_dir(self) -> str | None:
        if self.app.state_dir is None:
            return None
        state_dir = Path(self.app.state_dir)
        if state_dir.name == "gateway" and state_dir.parent != state_dir:
            return str(state_dir.parent)
        return str(state_dir)

    def _enabled_account_configs(self) -> tuple[DiscordGatewayAccountConfig, ...]:
        return tuple(config for config in self.account_configs if config.enabled)

    def _transport_account_configs(self) -> tuple[DiscordGatewayAccountConfig, ...]:
        enabled_configs = self._enabled_account_configs()
        return enabled_configs if enabled_configs else self.account_configs

    def _describe_accounts(self) -> tuple[tuple[dict[str, object], ...], dict[str, object]]:
        accounts: list[dict[str, object]] = []
        configured_account_ids: list[str] = []
        enabled_account_ids: list[str] = []
        disabled_account_ids: list[str] = []
        runnable_account_ids: list[str] = []
        blocked_account_ids: list[str] = []
        for config in self.account_configs:
            configured_account_ids.append(config.account_id)
            credentials_status = "configured"
            credentials_error: str | None = None
            try:
                resolve_discord_account(config, environ=self.environ)
            except LookupError as exc:
                credentials_status = "missing_credentials"
                credentials_error = str(exc)
            if config.enabled:
                enabled_account_ids.append(config.account_id)
                if credentials_status == "configured":
                    runnable_account_ids.append(config.account_id)
                    startup_status = "ready"
                else:
                    blocked_account_ids.append(config.account_id)
                    startup_status = "blocked"
            else:
                disabled_account_ids.append(config.account_id)
                startup_status = "disabled"
            payload = {
                "account_id": config.account_id,
                "surface": config.surface,
                "enabled": config.enabled,
                "bot_token_env_var": config.bot_token_env_var,
                "credentials_status": credentials_status,
                "startup_status": startup_status,
                "allow_guild_ids": config.allow_guild_ids,
                "allow_channel_ids": config.allow_channel_ids,
                "runtime_metadata": dict(config.runtime_metadata),
            }
            if credentials_error is not None:
                payload["credentials_error"] = credentials_error
            accounts.append(payload)
        service_status = "unconfigured"
        if accounts:
            if not enabled_account_ids:
                service_status = "disabled"
            elif blocked_account_ids and runnable_account_ids:
                service_status = "degraded"
            elif blocked_account_ids:
                service_status = "blocked"
            else:
                service_status = "ready"
        return tuple(accounts), {
            "service_status": service_status,
            "configured_accounts": len(configured_account_ids),
            "enabled_accounts": len(enabled_account_ids),
            "disabled_accounts": len(disabled_account_ids),
            "runnable_accounts": len(runnable_account_ids),
            "blocked_accounts": len(blocked_account_ids),
            "configured_account_ids": tuple(configured_account_ids),
            "enabled_account_ids": tuple(enabled_account_ids),
            "disabled_account_ids": tuple(disabled_account_ids),
            "runnable_account_ids": tuple(runnable_account_ids),
            "blocked_account_ids": tuple(blocked_account_ids),
        }

    def describe(self) -> Mapping[str, object]:
        accounts, account_status = self._describe_accounts()
        configured_transport: str | None = None
        configured_transport_error: str | None = None
        try:
            configured_transport = self.configured_transport()
        except (LookupError, ValueError) as exc:
            configured_transport_error = str(exc)
        return {
            "adapter_id": self.adapter.adapter_id if self.adapter is not None else DISCORD_ADAPTER_ID,
            "profile_id": self.app.profile_id,
            "workspace_id": self.app.workspace_id,
            "preferred_transport": "gateway",
            "implemented_transports": ("discord.py-gateway",),
            "configured_transport": configured_transport,
            "configured_transport_error": configured_transport_error,
            "sdk_dependency_status": _discord_py_dependency_status(),
            "required_intents": REQUIRED_DISCORD_INTENTS,
            "privileged_intents": PRIVILEGED_DISCORD_INTENTS,
            "mention_policy": "suppress-all",
            "accounts": accounts,
            "account_status": account_status,
            "control": self._describe_control(),
            "runtime": self._describe_runtime(
                configured_transport=configured_transport,
                configured_transport_error=configured_transport_error,
            ),
        }

    def _describe_runtime(
        self,
        *,
        configured_transport: str | None,
        configured_transport_error: str | None,
    ) -> Mapping[str, object]:
        payload: dict[str, object] = {
            "enabled": True,
            "runtime": "managed-service",
        }
        if configured_transport_error is not None:
            payload["runtime_status"] = "unavailable"
            payload["runtime_error"] = configured_transport_error
            return payload
        if configured_transport is None or self.runtime_state_dir is None:
            payload["runtime_status"] = "configured"
            if configured_transport is not None:
                payload["target"] = configured_transport
            return payload
        pid_path = default_gateway_runtime_path(
            self.runtime_state_dir,
            service_key=self.service_key,
            target=configured_transport,
            suffix="pid",
        )
        log_path = default_gateway_runtime_path(
            self.runtime_state_dir,
            service_key=self.service_key,
            target=configured_transport,
            suffix="log",
        )
        record_path = default_gateway_runtime_path(
            self.runtime_state_dir,
            service_key=self.service_key,
            target=configured_transport,
            suffix="runtime.json",
        )
        state = _managed_runtime_state(pid_path=pid_path, record_path=record_path)
        record = dict(state.get("record") or {})
        payload.update(
            {
                "target": configured_transport,
                "runtime_status": state["runtime_status"],
                "recorded_status": state["recorded_status"],
                "pid": state["pid"],
                "pid_active": bool(state["pid_active"]),
                "stale_pid_file": bool(state["stale_pid"]),
                "pid_file": str(pid_path),
                "log_file": str(log_path),
                "record_file": str(record_path),
                "started_at": _optional_text(record.get("started_at")),
                "stopped_at": _optional_text(record.get("stopped_at")),
                "last_exit_code": _coerce_int(record.get("last_exit_code")),
                "last_error": _optional_text(record.get("last_error")),
            }
        )
        return payload

    def _describe_control(self) -> Mapping[str, object]:
        if self.cli_control is None:
            return {
                "enabled": False,
                "runtime": "cli-runtime",
                "runtime_status": "disabled",
                "known_clones": (),
            }
        return self.cli_control.describe()

    async def dispatch_event(
        self,
        payload: Mapping[str, object],
        *,
        account_id: str | None = None,
        transport: str = "gateway",
        delivery_transport: DiscordDeliveryTransport | None = None,
    ) -> DiscordGatewayEventResult:
        if self.adapter is None:
            raise RuntimeError("discord adapter is unavailable")
        account = self._match_account(account_id=account_id)
        if not self._payload_allowed(payload, account=account):
            return DiscordGatewayEventResult(
                exchange=None,
                response_body={
                    "ok": True,
                    "adapter_id": self.adapter.adapter_id,
                    "transport": transport,
                    "account_id": account.account_id,
                    "conversation_id": str(payload.get("channel_id") or ""),
                    "delivery_outcome": "ignored",
                    "summary": "ignored_by_allowlist",
                },
            )
        inbound = self.adapter.normalize_event(
            payload,
            account_id=account.account_id,
            transport=transport,
        )
        if self.cli_control is not None:
            return await self._dispatch_cli_control(
                inbound,
                account=account,
                transport=transport,
                delivery_transport=delivery_transport,
            )
        exchange = self.app.handle_message(
            inbound,
            reply_to_message_id=inbound.reply_to_message_id or inbound.event_id,
            attachment_refs=inbound.attachment_refs,
            metadata={
                **dict(inbound.metadata),
                "delivery_surface": inbound.account.surface or f"discord-{transport}",
            },
        )
        response_body: dict[str, object] = {
            "ok": True,
            "adapter_id": self.adapter.adapter_id,
            "transport": transport,
            "account_id": exchange.route.inbound.account_id,
            "conversation_id": exchange.route.inbound.conversation_id,
            "session_id": exchange.route.session.session_id,
            "policy_decision": str(exchange.delivery.policy_result.decision),
            "delivery_outcome": exchange.delivery.outcome,
        }
        if exchange.delivery.outbound is None:
            response_body["summary"] = exchange.delivery.summary
            return DiscordGatewayEventResult(
                exchange=exchange,
                response_body=response_body,
            )
        if delivery_transport is None:
            raise RuntimeError("discord delivery transport is unavailable")
        delivery_request = self.adapter.build_reply_request(exchange.delivery.outbound)
        delivery_response = await delivery_transport.send_request(
            delivery_request,
            account=account,
        )
        response_body["external_message_id"] = self._external_message_id(delivery_response)
        return DiscordGatewayEventResult(
            exchange=exchange,
            response_body=response_body,
            delivery_request=delivery_request,
            delivery_response=delivery_response,
        )

    async def _dispatch_cli_control(
        self,
        inbound: GatewayInboundMessage,
        *,
        account: DiscordResolvedAccount,
        transport: str,
        delivery_transport: DiscordDeliveryTransport | None,
    ) -> DiscordGatewayEventResult:
        assert self.cli_control is not None
        result = self.cli_control.handle_message(inbound)
        response_body: dict[str, object] = {
            "ok": True,
            "adapter_id": self.adapter.adapter_id if self.adapter is not None else DISCORD_ADAPTER_ID,
            "transport": transport,
            "account_id": inbound.account_id,
            "conversation_id": inbound.conversation_id,
            "control_mode": "cli-runtime",
            "delivery_outcome": "ignored" if result.body is None else "delivered",
            "summary": result.summary or "",
        }
        if result.clone_id is not None:
            response_body["clone_id"] = result.clone_id
        if result.session_id is not None:
            response_body["session_id"] = result.session_id
        if result.body is None:
            return DiscordGatewayEventResult(exchange=None, response_body=response_body)
        if delivery_transport is None:
            raise RuntimeError("discord delivery transport is unavailable")
        assert self.adapter is not None
        outbound = self._build_control_outbound(inbound, body=result.body, session_id=result.session_id)
        delivery_request = self.adapter.build_reply_request(outbound)
        delivery_response = await delivery_transport.send_request(
            delivery_request,
            account=account,
        )
        response_body["external_message_id"] = self._external_message_id(delivery_response)
        return DiscordGatewayEventResult(
            exchange=None,
            response_body=response_body,
            delivery_request=delivery_request,
            delivery_response=delivery_response,
        )

    def _build_control_outbound(
        self,
        inbound: GatewayInboundMessage,
        *,
        body: str,
        session_id: str | None,
    ) -> GatewayOutboundMessage:
        return GatewayOutboundMessage(
            message_id=f"discord-control:{session_id or inbound.conversation_id}:{uuid4().hex[:12]}",
            account=inbound.account,
            conversation=inbound.conversation,
            session_id=session_id or f"control:{inbound.conversation_id}",
            body=body,
            reply_to_message_id=inbound.reply_to_message_id or inbound.event_id,
            attachment_refs=(),
            metadata={
                **dict(inbound.metadata),
                "delivery_surface": inbound.account.surface or "discord-control",
                "runtime_surface": "cli-runtime",
            },
        )

    def configured_transport(self) -> str:
        transport_configs = self._transport_account_configs()
        if not transport_configs:
            return "gateway"
        transports = tuple(
            dict.fromkeys(_normalize_transport(config.surface) for config in transport_configs)
        )
        if len(transports) == 1:
            return transports[0]
        raise LookupError(
            "configured Discord accounts use multiple transport surfaces; choose one explicitly"
        )

    def configured_runtime_target(self) -> str:
        return self.configured_transport()

    def managed_runtime(
        self,
        *,
        args: Any,
        target: str,
    ) -> GatewayManagedRuntime:
        normalized_target = _normalize_transport(target)
        state_dir = Path(args.state_dir)
        return GatewayManagedRuntime(
            service_key=self.service_key,
            runtime_id=f"{self.service_key}:{normalized_target}",
            target=normalized_target,
            label=f"Discord {normalized_target} transport",
            pid_path=default_gateway_runtime_path(
                state_dir,
                service_key=self.service_key,
                target=normalized_target,
                suffix="pid",
            ),
            log_path=default_gateway_runtime_path(
                state_dir,
                service_key=self.service_key,
                target=normalized_target,
                suffix="log",
            ),
            record_path=default_gateway_runtime_path(
                state_dir,
                service_key=self.service_key,
                target=normalized_target,
                suffix="runtime.json",
            ),
        )

    def build_detached_runtime_command(
        self,
        *,
        args: Any,
        target: str,
    ) -> tuple[str, ...]:
        command = [
            os.sys.executable,
            "-m",
            "apps.launcher",
            "im",
            "discord",
            "start",
            "--transport",
            _normalize_transport(target),
            "--profile-dir",
            str(args.profile_dir),
            "--state-dir",
            str(args.state_dir),
            "--cli-profile-dir",
            str(args.cli_profile_dir),
            "--cli-state-dir",
            str(args.cli_state_dir),
            "--workspace-id",
            str(args.workspace_id),
        ]
        if getattr(args, "account_id", None):
            command.extend(["--account-id", str(args.account_id)])
        return tuple(command)

    def prepare_managed_runtime(self, *, action: str, target: str) -> None:
        _normalize_transport(target)
        if self.runtime_dependency_ensurer is None:
            return
        self.runtime_dependency_ensurer(reason=f"Discord gateway {action}")

    def managed_runtime_log_hint(self, *, target: str) -> str:
        return f"aegis im discord logs --transport {_normalize_transport(target)} --follow"

    async def start_gateway(
        self,
        *,
        account_id: str | None = None,
        discord_module: Any | None = None,
        client_factory: DiscordClientFactory = _default_discord_client_factory,
        delivery_transport_factory: DiscordDeliveryTransportFactory = _default_discord_delivery_transport_factory,
    ) -> tuple[object, ...]:
        discord = _load_discord_sdk(discord_module)
        accounts, blocked_accounts = self._resolved_accounts_for_start(account_id=account_id)
        if not accounts:
            if account_id is not None:
                raise LookupError(f"unknown or unrunnable Discord gateway account: {account_id}")
            if blocked_accounts:
                blocked_summary = "; ".join(
                    f"{account_label}: {error}" for account_label, error in blocked_accounts
                )
                raise LookupError(
                    "no enabled Discord gateway accounts are runnable; " + blocked_summary
                )
            raise LookupError("no enabled Discord gateway accounts are configured")
        for account_label, error in blocked_accounts:
            print(
                f"Skipping Discord account '{account_label}': {error}",
                file=os.sys.stderr,
            )
        results = await asyncio.gather(
            *(
                self._start_gateway_account_supervised(
                    account,
                    discord_module=discord,
                    client_factory=client_factory,
                    delivery_transport_factory=delivery_transport_factory,
                )
                for account in accounts
            )
        )
        clients = tuple(result for result in results if not isinstance(result, Exception))
        if clients:
            return clients
        first_error = next((result for result in results if isinstance(result, Exception)), None)
        if first_error is not None:
            raise RuntimeError(f"failed to start any Discord gateway accounts: {first_error}")
        return ()

    async def _start_gateway_account_supervised(
        self,
        account: DiscordResolvedAccount,
        *,
        discord_module: Any,
        client_factory: DiscordClientFactory,
        delivery_transport_factory: DiscordDeliveryTransportFactory,
    ) -> object | Exception:
        try:
            return await self._start_gateway_account(
                account,
                discord_module=discord_module,
                client_factory=client_factory,
                delivery_transport_factory=delivery_transport_factory,
            )
        except Exception as exc:
            print(
                f"Discord gateway account '{account.account_id}' stopped with error: {exc}",
                file=os.sys.stderr,
            )
            return exc

    async def _start_gateway_account(
        self,
        account: DiscordResolvedAccount,
        *,
        discord_module: Any,
        client_factory: DiscordClientFactory,
        delivery_transport_factory: DiscordDeliveryTransportFactory,
    ) -> object:
        client = client_factory(discord_module, _discord_intents(discord_module))
        delivery_transport = delivery_transport_factory(client, discord_module)
        queue: asyncio.Queue[Mapping[str, object] | None] = asyncio.Queue()
        worker = asyncio.create_task(
            self._drain_gateway_queue(
                queue,
                account=account,
                delivery_transport=delivery_transport,
            )
        )

        async def on_message(message: object) -> None:
            if self.should_ignore_sdk_message(
                message,
                self_user_id=self._client_self_user_id(client),
            ):
                return
            payload = self.sdk_message_payload(message)
            if not self._payload_allowed(payload, account=account):
                return
            await queue.put(payload)

        event = getattr(client, "event", None)
        if callable(event):
            event(on_message)
        else:
            setattr(client, "on_message", on_message)

        start = getattr(client, "start", None)
        if not callable(start):
            raise RuntimeError("discord gateway client does not expose start()")
        try:
            await _maybe_await(start(account.bot_token))
        finally:
            await queue.join()
            await queue.put(None)
            await worker
            close = getattr(client, "close", None)
            if callable(close):
                await _maybe_await(close())
        return client

    async def _drain_gateway_queue(
        self,
        queue: "asyncio.Queue[Mapping[str, object] | None]",
        *,
        account: DiscordResolvedAccount,
        delivery_transport: DiscordDeliveryTransport,
    ) -> None:
        while True:
            payload = await queue.get()
            try:
                if payload is None:
                    return
                await self.dispatch_event(
                    payload,
                    account_id=account.account_id,
                    transport="gateway",
                    delivery_transport=delivery_transport,
                )
            except Exception as exc:
                print(
                    f"Discord gateway dispatch failed for account '{account.account_id}': {exc}",
                    file=os.sys.stderr,
                )
            finally:
                queue.task_done()

    def sdk_message_payload(self, message: object) -> Mapping[str, object]:
        author = getattr(message, "author", None)
        if author is None or getattr(author, "id", None) is None:
            raise ValueError("discord SDK message requires an author with id")
        channel = getattr(message, "channel", None)
        if channel is None or getattr(channel, "id", None) is None:
            raise ValueError("discord SDK message requires a channel with id")
        guild = getattr(message, "guild", None)
        parent = getattr(channel, "parent", None)
        attachments = []
        for attachment in tuple(getattr(message, "attachments", ()) or ()):
            attachments.append(
                {
                    "id": str(getattr(attachment, "id", "")),
                    "filename": str(getattr(attachment, "filename", "")),
                    "content_type": str(getattr(attachment, "content_type", "")),
                    "url": str(getattr(attachment, "url", "")),
                }
            )
        payload: dict[str, object] = {
            "id": str(getattr(message, "id", "")),
            "channel_id": str(getattr(channel, "id", "")),
            "guild_id": (
                str(getattr(guild, "id", ""))
                if guild is not None and getattr(guild, "id", None) is not None
                else None
            ),
            "content": str(getattr(message, "content", "") or ""),
            "author": {
                "id": str(getattr(author, "id", "")),
                "username": str(getattr(author, "name", "") or getattr(author, "username", "")),
                "global_name": str(getattr(author, "global_name", "")),
                "bot": bool(getattr(author, "bot", False)),
            },
            "attachments": attachments,
        }
        nickname = getattr(author, "nick", None)
        if nickname is not None:
            payload["member"] = {"nick": str(nickname)}
        reference = getattr(message, "reference", None)
        if reference is not None and getattr(reference, "message_id", None) is not None:
            payload["message_reference"] = {
                "message_id": str(getattr(reference, "message_id")),
                "channel_id": str(getattr(reference, "channel_id", getattr(channel, "id", ""))),
                "guild_id": (
                    str(getattr(reference, "guild_id"))
                    if getattr(reference, "guild_id", None) is not None
                    else None
                ),
            }
        if parent is not None and getattr(parent, "id", None) is not None:
            payload["parent_id"] = str(getattr(parent, "id"))
            payload["thread_id"] = str(getattr(channel, "id"))
            payload["chat_type"] = "topic"
        elif guild is not None:
            payload["chat_type"] = "channel"
        else:
            payload["chat_type"] = "direct"
        return payload

    def should_ignore_sdk_message(self, message: object, *, self_user_id: str | None = None) -> bool:
        author = getattr(message, "author", None)
        if author is None:
            return True
        author_id = getattr(author, "id", None)
        if self_user_id is not None and author_id is not None and str(author_id) == str(self_user_id):
            return True
        if bool(getattr(author, "bot", False)):
            return True
        message_type = getattr(message, "type", None)
        if message_type is None:
            return False
        message_type_name = str(getattr(message_type, "name", message_type)).lower()
        return message_type_name not in {"default", "reply"}

    def _match_account(
        self,
        *,
        account_id: str | None = None,
    ) -> DiscordResolvedAccount:
        if not self.account_configs:
            raise LookupError("no Discord gateway accounts are configured")
        if account_id is not None:
            for config in self.account_configs:
                if config.account_id == account_id:
                    return resolve_discord_account(config, environ=self.environ)
            raise LookupError(f"unknown Discord gateway account: {account_id}")
        enabled_configs = self._enabled_account_configs()
        if not enabled_configs:
            raise LookupError("no enabled Discord gateway accounts are configured")
        if len(enabled_configs) == 1:
            return resolve_discord_account(enabled_configs[0], environ=self.environ)
        raise LookupError(
            "multiple enabled Discord gateway accounts are configured; pass account_id explicitly"
        )

    def _resolved_accounts_for_start(
        self,
        *,
        account_id: str | None = None,
    ) -> tuple[tuple[DiscordResolvedAccount, ...], tuple[tuple[str, str], ...]]:
        if account_id is not None:
            return ((self._match_account(account_id=account_id),), ())
        enabled_configs = self._enabled_account_configs()
        if not enabled_configs:
            return (), ()
        resolved: list[DiscordResolvedAccount] = []
        blocked: list[tuple[str, str]] = []
        for config in enabled_configs:
            try:
                resolved.append(resolve_discord_account(config, environ=self.environ))
            except LookupError as exc:
                blocked.append((config.account_id, str(exc)))
        return tuple(resolved), tuple(blocked)

    def _resolved_accounts(
        self,
        *,
        account_id: str | None = None,
    ) -> tuple[DiscordResolvedAccount, ...]:
        accounts, _ = self._resolved_accounts_for_start(account_id=account_id)
        return accounts

    def _payload_allowed(
        self,
        payload: Mapping[str, object],
        *,
        account: DiscordResolvedAccount,
    ) -> bool:
        guild_id = str(payload.get("guild_id") or "").strip()
        channel_id = str(payload.get("channel_id") or "").strip()
        parent_id = str(payload.get("parent_id") or "").strip()
        allowed_guild_ids = account.config.allow_guild_ids
        if guild_id and allowed_guild_ids and guild_id not in allowed_guild_ids:
            return False
        allowed_channel_ids = account.config.allow_channel_ids
        if allowed_channel_ids and channel_id not in allowed_channel_ids:
            if not parent_id or parent_id not in allowed_channel_ids:
                return False
        return True

    def _client_self_user_id(self, client: object) -> str | None:
        user = getattr(client, "user", None)
        if user is None or getattr(user, "id", None) is None:
            return None
        return str(getattr(user, "id"))

    def _external_message_id(self, response: Mapping[str, object]) -> str:
        return str(response.get("id") or "")


def register_discord_gateway_service(registry: GatewayPluginRegistry) -> GatewayPluginRegistry:
    registry.register_service(
        "discord",
        factory=lambda app, **kwargs: DiscordGatewayService(app=app, **kwargs),
        enabled_by_default=True,
    )
    return registry


def build_discord_gateway_service(
    *,
    profile_id: str = "profile:default",
    workspace_id: str | None = None,
    provider_profile: Mapping[str, Any] | None = None,
    profile_dir: str | None = None,
    state_dir: str | None = None,
    environ: Mapping[str, str] | None = None,
    plugin_registry: GatewayPluginRegistry | None = None,
) -> DiscordGatewayService:
    app, _, _ = build_gateway_app(
        profile_id=profile_id,
        workspace_id=workspace_id,
        provider_profile=provider_profile,
        profile_dir=profile_dir,
        state_dir=state_dir,
        plugin_registry=plugin_registry,
    )
    return DiscordGatewayService(
        app=app,
        environ=dict(environ or os.environ),
        runtime_state_dir=Path(state_dir) if state_dir is not None else None,
    )
