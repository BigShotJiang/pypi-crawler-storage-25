"""SQLite-backed repository for durable runtime state.

The repository owns the first persistence baseline for the runtime. It stays
small on purpose so the kernel and module packages can layer behavior on top
without needing to know about SQL dialect details.
"""

from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass, field, replace
from datetime import datetime, timezone
import json
from pathlib import Path
import sqlite3
from typing import Iterator, Mapping

from packages.auth.runtime import AuthProfile, EncryptedSecretValue, ProviderAuthState, SecretReference
from packages.contracts.runtime import (
    AgentRunState,
    AgentRunStep,
    CloneIdentityRecord,
    ExperienceRecord,
    ProfileGrowthState,
    ProfileState,
    RelationshipMemoryRecord,
    SessionState,
    UserCardRecord,
)
from packages.planning import GoalGraph, GoalGraphNode

MIGRATION_VERSION = 11
MIGRATIONS = {
    1: Path(__file__).with_name("migrations") / "0001_initial.sql",
    2: Path(__file__).with_name("migrations") / "0002_auth_profiles.sql",
    3: Path(__file__).with_name("migrations") / "0003_goal_graph.sql",
    4: Path(__file__).with_name("migrations") / "0004_memory_substrate.sql",
    5: Path(__file__).with_name("migrations") / "0005_agent_runs.sql",
    6: Path(__file__).with_name("migrations") / "0006_experiences.sql",
    7: Path(__file__).with_name("migrations") / "0007_profile_growth.sql",
    8: Path(__file__).with_name("migrations") / "0008_profiles_clone_path.sql",
    9: Path(__file__).with_name("migrations") / "0009_auth_secret_values.sql",
    10: Path(__file__).with_name("migrations") / "0010_provider_auth_states.sql",
    11: Path(__file__).with_name("migrations") / "0011_canonical_personal_ai_state.sql",
}


@dataclass(frozen=True, slots=True)
class StorageBootstrapState:
    database_path: str
    schema_version: int


@dataclass(frozen=True, slots=True)
class StoredMemoryLedgerEntry:
    entry_id: str
    session_id: str
    event_id: str
    event_type: str
    content: str
    kind: str
    source_event_id: str | None = None
    goal_refs: tuple[str, ...] = ()
    tags: tuple[str, ...] = ()
    created_at: datetime | None = None
    metadata: Mapping[str, str] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class StoredMemoryRecord:
    memory_id: str
    session_id: str
    kind: str
    content: str
    source_event_id: str | None = None
    goal_refs: tuple[str, ...] = ()
    tags: tuple[str, ...] = ()
    created_at: datetime | None = None


@dataclass(frozen=True, slots=True)
class StoredIdentityLedgerEntry:
    entry_id: str
    clone_id: str
    profile_id: str
    action: str
    summary: str
    metadata: Mapping[str, str] = field(default_factory=dict)
    created_at: datetime | None = None


@dataclass(frozen=True, slots=True)
class StoredUserCardLedgerEntry:
    entry_id: str
    user_card_id: str
    profile_id: str
    action: str
    summary: str
    metadata: Mapping[str, str] = field(default_factory=dict)
    created_at: datetime | None = None


@dataclass(frozen=True, slots=True)
class StoredRelationshipLedgerEntry:
    entry_id: str
    relationship_id: str
    profile_id: str
    action: str
    summary: str
    metadata: Mapping[str, str] = field(default_factory=dict)
    created_at: datetime | None = None


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _iso(value: datetime | None) -> str:
    return (value or _utc_now()).isoformat()


def _parse_datetime(value: str) -> datetime:
    parsed = datetime.fromisoformat(value)
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=timezone.utc)
    return parsed


def _json_text(values: tuple[str, ...]) -> str:
    return json.dumps(list(values), separators=(",", ":"))


def _tuple_text(payload: str) -> tuple[str, ...]:
    data = json.loads(payload)
    return tuple(str(item) for item in data)


def _json_mapping(values: dict[str, str]) -> str:
    return json.dumps(values, separators=(",", ":"), sort_keys=True)


def _mapping_text(payload: str) -> dict[str, str]:
    data = json.loads(payload)
    if not isinstance(data, dict):
        raise ValueError("expected a JSON object")
    return {str(key): str(value) for key, value in data.items()}


def _json_dict_text(values: dict[str, object]) -> str:
    return json.dumps(values, separators=(",", ":"), sort_keys=True, default=str)


def _mapping_object(payload: str) -> dict[str, object]:
    data = json.loads(payload)
    if not isinstance(data, dict):
        raise ValueError("expected a JSON object")
    return {str(key): value for key, value in data.items()}


def _record_from_row(row: sqlite3.Row) -> StoredMemoryRecord:
    return StoredMemoryRecord(
        memory_id=str(row["memory_id"]),
        session_id=str(row["session_id"]),
        kind=str(row["kind"]),
        content=str(row["content"]),
        source_event_id=str(row["source_event_id"]) if row["source_event_id"] is not None else None,
        goal_refs=_tuple_text(str(row["goal_refs_json"])),
        tags=_tuple_text(str(row["tags_json"])),
        created_at=_parse_datetime(str(row["created_at"])) if row["created_at"] is not None else None,
    )


def _ledger_entry_from_row(row: sqlite3.Row) -> StoredMemoryLedgerEntry:
    return StoredMemoryLedgerEntry(
        entry_id=str(row["entry_id"]),
        session_id=str(row["session_id"]),
        event_id=str(row["event_id"]),
        event_type=str(row["event_type"]),
        content=str(row["content"]),
        kind=str(row["kind"]),
        source_event_id=str(row["source_event_id"]) if row["source_event_id"] is not None else None,
        goal_refs=_tuple_text(str(row["goal_refs_json"])),
        tags=_tuple_text(str(row["tags_json"])),
        created_at=_parse_datetime(str(row["created_at"])) if row["created_at"] is not None else _utc_now(),
        metadata=_mapping_text(str(row["metadata_json"])),
    )


def _agent_run_from_row(row: sqlite3.Row) -> AgentRunState:
    return AgentRunState(
        run_id=str(row["run_id"]),
        session_id=str(row["session_id"]),
        source_event_id=str(row["source_event_id"]),
        prompt=str(row["prompt"]),
        status=str(row["status"]),
        phase=str(row["phase"]),
        step_count=int(row["step_count"]),
        model_turn_count=int(row["model_turn_count"]),
        tool_call_count=int(row["tool_call_count"]),
        max_model_turns=int(row["max_model_turns"]),
        max_wall_time_seconds=int(row["max_wall_time_seconds"]),
        created_at=_parse_datetime(str(row["created_at"])),
        updated_at=_parse_datetime(str(row["updated_at"])),
        waiting_reason=str(row["waiting_reason"]) if row["waiting_reason"] is not None else None,
        continuation_prompt=(
            str(row["continuation_prompt"]) if row["continuation_prompt"] is not None else None
        ),
        last_summary=str(row["last_summary"]) if row["last_summary"] is not None else None,
    )


def _agent_run_step_from_row(row: sqlite3.Row) -> AgentRunStep:
    return AgentRunStep(
        step_id=str(row["step_id"]),
        run_id=str(row["run_id"]),
        session_id=str(row["session_id"]),
        step_index=int(row["step_index"]),
        kind=str(row["kind"]),
        title=str(row["title"]),
        content=str(row["content"]),
        created_at=_parse_datetime(str(row["created_at"])),
        outcome=str(row["outcome"]) if row["outcome"] is not None else None,
        tool_name=str(row["tool_name"]) if row["tool_name"] is not None else None,
    )


def _experience_from_row(row: sqlite3.Row) -> ExperienceRecord:
    return ExperienceRecord(
        experience_id=str(row["experience_id"]),
        session_id=str(row["session_id"]),
        profile_id=str(row["profile_id"]),
        workspace_id=str(row["workspace_id"]) if row["workspace_id"] is not None else None,
        kind=str(row["kind"]),
        title=str(row["title"]),
        summary=str(row["summary"]),
        status=str(row["status"]),
        run_id=str(row["run_id"]) if row["run_id"] is not None else None,
        source_event_id=str(row["source_event_id"]) if row["source_event_id"] is not None else None,
        goal_id=str(row["goal_id"]) if row["goal_id"] is not None else None,
        tool_call_count=int(row["tool_call_count"]),
        model_turn_count=int(row["model_turn_count"]),
        related_skill_ids=_tuple_text(str(row["related_skill_ids_json"])),
        produced_artifact_ids=_tuple_text(str(row["produced_artifact_ids_json"])),
        tags=_tuple_text(str(row["tags_json"])),
        created_at=_parse_datetime(str(row["created_at"])) if row["created_at"] is not None else None,
        updated_at=_parse_datetime(str(row["updated_at"])) if row["updated_at"] is not None else None,
    )


def _growth_from_row(row: sqlite3.Row) -> ProfileGrowthState:
    return ProfileGrowthState(
        profile_id=str(row["profile_id"]),
        growth_score=int(row["growth_score"]),
        total_dialogues=int(row["total_dialogues"]),
        total_tokens=int(row["total_tokens"]),
        total_experiences=int(row["total_experiences"]),
        promoted_experiences=int(row["promoted_experiences"]),
        active_days=int(row["active_days"]),
        streak_days=int(row["streak_days"]),
        first_dialogue_at=(
            _parse_datetime(str(row["first_dialogue_at"])) if row["first_dialogue_at"] is not None else None
        ),
        last_dialogue_at=(
            _parse_datetime(str(row["last_dialogue_at"])) if row["last_dialogue_at"] is not None else None
        ),
        last_active_day=str(row["last_active_day"]) if row["last_active_day"] is not None else None,
        created_at=_parse_datetime(str(row["created_at"])) if row["created_at"] is not None else None,
        updated_at=_parse_datetime(str(row["updated_at"])) if row["updated_at"] is not None else None,
    )


def _clone_identity_from_row(row: sqlite3.Row) -> CloneIdentityRecord:
    return CloneIdentityRecord(
        clone_id=str(row["clone_id"]),
        profile_id=str(row["profile_id"]),
        display_name=str(row["display_name"]),
        identity_mode=str(row["identity_mode"]),
        personality_preset=str(row["personality_preset"]),
        initiative=str(row["initiative"]),
        relational_stance=str(row["relational_stance"]),
        voice_contract=str(row["voice_contract"]),
        working_style_contract=str(row["working_style_contract"]),
        charter_extension=str(row["charter_extension"]) if row["charter_extension"] is not None else None,
        governance_flags=_tuple_text(str(row["governance_flags_json"])),
        source_manifest_path=(
            str(row["source_manifest_path"]) if row["source_manifest_path"] is not None else None
        ),
        source_clone_path=str(row["source_clone_path"]) if row["source_clone_path"] is not None else None,
        created_at=_parse_datetime(str(row["created_at"])) if row["created_at"] is not None else None,
        updated_at=_parse_datetime(str(row["updated_at"])) if row["updated_at"] is not None else None,
    )


def _user_card_from_row(row: sqlite3.Row) -> UserCardRecord:
    return UserCardRecord(
        user_card_id=str(row["user_card_id"]),
        profile_id=str(row["profile_id"]),
        preferred_name=str(row["preferred_name"]) if row["preferred_name"] is not None else None,
        locale=str(row["locale"]) if row["locale"] is not None else None,
        timezone=str(row["timezone"]) if row["timezone"] is not None else None,
        communication_preferences=_tuple_text(str(row["communication_preferences_json"])),
        boundaries=_tuple_text(str(row["boundaries_json"])),
        biography_fragments=_tuple_text(str(row["biography_fragments_json"])),
        shared_preferences=_tuple_text(str(row["shared_preferences_json"])),
        source_friend_path=str(row["source_friend_path"]) if row["source_friend_path"] is not None else None,
        created_at=_parse_datetime(str(row["created_at"])) if row["created_at"] is not None else None,
        updated_at=_parse_datetime(str(row["updated_at"])) if row["updated_at"] is not None else None,
    )


def _relationship_memory_from_row(row: sqlite3.Row) -> RelationshipMemoryRecord:
    return RelationshipMemoryRecord(
        relationship_id=str(row["relationship_id"]),
        profile_id=str(row["profile_id"]),
        clone_id=str(row["clone_id"]),
        user_card_id=str(row["user_card_id"]) if row["user_card_id"] is not None else None,
        interaction_preferences=_tuple_text(str(row["interaction_preferences_json"])),
        repair_history=_tuple_text(str(row["repair_history_json"])),
        trust_markers=_tuple_text(str(row["trust_markers_json"])),
        expectations=_tuple_text(str(row["expectations_json"])),
        local_corrections=_tuple_text(str(row["local_corrections_json"])),
        continuity_notes=_tuple_text(str(row["continuity_notes_json"])),
        created_at=_parse_datetime(str(row["created_at"])) if row["created_at"] is not None else None,
        updated_at=_parse_datetime(str(row["updated_at"])) if row["updated_at"] is not None else None,
    )


def _identity_ledger_from_row(row: sqlite3.Row) -> StoredIdentityLedgerEntry:
    return StoredIdentityLedgerEntry(
        entry_id=str(row["entry_id"]),
        clone_id=str(row["clone_id"]),
        profile_id=str(row["profile_id"]),
        action=str(row["action"]),
        summary=str(row["summary"]),
        metadata=_mapping_text(str(row["metadata_json"])),
        created_at=_parse_datetime(str(row["created_at"])) if row["created_at"] is not None else None,
    )


def _user_card_ledger_from_row(row: sqlite3.Row) -> StoredUserCardLedgerEntry:
    return StoredUserCardLedgerEntry(
        entry_id=str(row["entry_id"]),
        user_card_id=str(row["user_card_id"]),
        profile_id=str(row["profile_id"]),
        action=str(row["action"]),
        summary=str(row["summary"]),
        metadata=_mapping_text(str(row["metadata_json"])),
        created_at=_parse_datetime(str(row["created_at"])) if row["created_at"] is not None else None,
    )


def _relationship_ledger_from_row(row: sqlite3.Row) -> StoredRelationshipLedgerEntry:
    return StoredRelationshipLedgerEntry(
        entry_id=str(row["entry_id"]),
        relationship_id=str(row["relationship_id"]),
        profile_id=str(row["profile_id"]),
        action=str(row["action"]),
        summary=str(row["summary"]),
        metadata=_mapping_text(str(row["metadata_json"])),
        created_at=_parse_datetime(str(row["created_at"])) if row["created_at"] is not None else None,
    )


class RuntimeStorageRepository:
    """Own the durable SQLite baseline for runtime state."""

    def __init__(self, database_path: str | Path) -> None:
        self.database_path = Path(database_path)

    def bootstrap(self) -> StorageBootstrapState:
        self.database_path.parent.mkdir(parents=True, exist_ok=True)
        with self.connection() as connection:
            version = self.schema_version(connection)
            if version > MIGRATION_VERSION:
                raise RuntimeError(
                    f"database schema version {version} is newer than supported "
                    f"migration version {MIGRATION_VERSION}"
                )
            for target_version in range(version + 1, MIGRATION_VERSION + 1):
                migration_file = MIGRATIONS[target_version]
                migration_sql = migration_file.read_text(encoding="utf-8")
                connection.executescript(migration_sql)
                connection.execute(
                    "INSERT OR REPLACE INTO schema_migrations(version, applied_at) VALUES(?, ?)",
                    (target_version, _iso(None)),
                )
                connection.commit()
        return StorageBootstrapState(
            database_path=str(self.database_path),
            schema_version=MIGRATION_VERSION,
        )

    @contextmanager
    def connection(self) -> Iterator[sqlite3.Connection]:
        connection = sqlite3.connect(self.database_path)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        try:
            yield connection
        finally:
            connection.close()

    def schema_version(self, connection: sqlite3.Connection | None = None) -> int:
        owns_connection = connection is None
        if owns_connection:
            with self.connection() as owned_connection:
                return self.schema_version(owned_connection)

        assert connection is not None
        try:
            row = connection.execute(
                "SELECT MAX(version) AS version FROM schema_migrations"
            ).fetchone()
        except sqlite3.OperationalError:
            return 0
        if row is None or row["version"] is None:
            return 0
        return int(row["version"])

    def upsert_profile(self, profile: ProfileState, *, updated_at: datetime | None = None) -> None:
        timestamp = _iso(updated_at)
        created_at = timestamp
        with self.connection() as connection:
            existing = connection.execute(
                "SELECT created_at FROM profiles WHERE profile_id = ?",
                (profile.profile_id,),
            ).fetchone()
            if existing is not None:
                created_at = str(existing["created_at"])
            connection.execute(
                """
                INSERT INTO profiles (
                    profile_id,
                    display_name,
                    mode,
                    clone_path,
                    preferences_json,
                    enabled_capabilities_json,
                    created_at,
                    updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(profile_id) DO UPDATE SET
                    display_name = excluded.display_name,
                    mode = excluded.mode,
                    clone_path = excluded.clone_path,
                    preferences_json = excluded.preferences_json,
                    enabled_capabilities_json = excluded.enabled_capabilities_json,
                    updated_at = excluded.updated_at
                """,
                (
                    profile.profile_id,
                    profile.display_name,
                    profile.mode,
                    profile.clone_path,
                    _json_text(profile.preferences),
                    _json_text(profile.enabled_capabilities),
                    created_at,
                    timestamp,
                ),
            )
            connection.commit()

    def load_profile(self, profile_id: str) -> ProfileState | None:
        with self.connection() as connection:
            row = connection.execute(
                """
                SELECT profile_id, display_name, mode, clone_path,
                       preferences_json, enabled_capabilities_json
                FROM profiles
                WHERE profile_id = ?
                """,
                (profile_id,),
            ).fetchone()
        if row is None:
            return None
        return ProfileState(
            profile_id=str(row["profile_id"]),
            display_name=str(row["display_name"]),
            mode=str(row["mode"]),
            clone_path=str(row["clone_path"]) if row["clone_path"] is not None else None,
            preferences=_tuple_text(str(row["preferences_json"])),
            enabled_capabilities=_tuple_text(str(row["enabled_capabilities_json"])),
        )

    def upsert_clone_identity(
        self,
        record: CloneIdentityRecord,
        *,
        updated_at: datetime | None = None,
    ) -> None:
        timestamp = _iso(updated_at or record.updated_at or record.created_at)
        created_at = timestamp
        with self.connection() as connection:
            existing = connection.execute(
                "SELECT created_at FROM clone_identities WHERE clone_id = ?",
                (record.clone_id,),
            ).fetchone()
            if existing is not None:
                created_at = str(existing["created_at"])
            connection.execute(
                """
                INSERT INTO clone_identities (
                    clone_id,
                    profile_id,
                    display_name,
                    identity_mode,
                    personality_preset,
                    initiative,
                    relational_stance,
                    voice_contract,
                    working_style_contract,
                    charter_extension,
                    governance_flags_json,
                    source_manifest_path,
                    source_clone_path,
                    created_at,
                    updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(clone_id) DO UPDATE SET
                    profile_id = excluded.profile_id,
                    display_name = excluded.display_name,
                    identity_mode = excluded.identity_mode,
                    personality_preset = excluded.personality_preset,
                    initiative = excluded.initiative,
                    relational_stance = excluded.relational_stance,
                    voice_contract = excluded.voice_contract,
                    working_style_contract = excluded.working_style_contract,
                    charter_extension = excluded.charter_extension,
                    governance_flags_json = excluded.governance_flags_json,
                    source_manifest_path = excluded.source_manifest_path,
                    source_clone_path = excluded.source_clone_path,
                    updated_at = excluded.updated_at
                """,
                (
                    record.clone_id,
                    record.profile_id,
                    record.display_name,
                    record.identity_mode,
                    record.personality_preset,
                    record.initiative,
                    record.relational_stance,
                    record.voice_contract,
                    record.working_style_contract,
                    record.charter_extension,
                    _json_text(record.governance_flags),
                    record.source_manifest_path,
                    record.source_clone_path,
                    created_at,
                    timestamp,
                ),
            )
            connection.commit()

    def load_clone_identity(self, clone_id: str) -> CloneIdentityRecord | None:
        with self.connection() as connection:
            row = connection.execute(
                """
                SELECT clone_id, profile_id, display_name, identity_mode,
                       personality_preset, initiative, relational_stance,
                       voice_contract, working_style_contract, charter_extension,
                       governance_flags_json, source_manifest_path,
                       source_clone_path, created_at, updated_at
                FROM clone_identities
                WHERE clone_id = ?
                """,
                (clone_id,),
            ).fetchone()
        return _clone_identity_from_row(row) if row is not None else None

    def load_clone_identity_for_profile(self, profile_id: str) -> CloneIdentityRecord | None:
        with self.connection() as connection:
            row = connection.execute(
                """
                SELECT clone_id, profile_id, display_name, identity_mode,
                       personality_preset, initiative, relational_stance,
                       voice_contract, working_style_contract, charter_extension,
                       governance_flags_json, source_manifest_path,
                       source_clone_path, created_at, updated_at
                FROM clone_identities
                WHERE profile_id = ?
                ORDER BY updated_at DESC, created_at DESC
                LIMIT 1
                """,
                (profile_id,),
            ).fetchone()
        return _clone_identity_from_row(row) if row is not None else None

    def upsert_user_card(
        self,
        record: UserCardRecord,
        *,
        updated_at: datetime | None = None,
    ) -> None:
        timestamp = _iso(updated_at or record.updated_at or record.created_at)
        created_at = timestamp
        with self.connection() as connection:
            existing = connection.execute(
                "SELECT created_at FROM user_cards WHERE user_card_id = ?",
                (record.user_card_id,),
            ).fetchone()
            if existing is not None:
                created_at = str(existing["created_at"])
            connection.execute(
                """
                INSERT INTO user_cards (
                    user_card_id,
                    profile_id,
                    preferred_name,
                    locale,
                    timezone,
                    communication_preferences_json,
                    boundaries_json,
                    biography_fragments_json,
                    shared_preferences_json,
                    source_friend_path,
                    created_at,
                    updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(user_card_id) DO UPDATE SET
                    profile_id = excluded.profile_id,
                    preferred_name = excluded.preferred_name,
                    locale = excluded.locale,
                    timezone = excluded.timezone,
                    communication_preferences_json = excluded.communication_preferences_json,
                    boundaries_json = excluded.boundaries_json,
                    biography_fragments_json = excluded.biography_fragments_json,
                    shared_preferences_json = excluded.shared_preferences_json,
                    source_friend_path = excluded.source_friend_path,
                    updated_at = excluded.updated_at
                """,
                (
                    record.user_card_id,
                    record.profile_id,
                    record.preferred_name,
                    record.locale,
                    record.timezone,
                    _json_text(record.communication_preferences),
                    _json_text(record.boundaries),
                    _json_text(record.biography_fragments),
                    _json_text(record.shared_preferences),
                    record.source_friend_path,
                    created_at,
                    timestamp,
                ),
            )
            connection.commit()

    def load_user_card(self, user_card_id: str) -> UserCardRecord | None:
        with self.connection() as connection:
            row = connection.execute(
                """
                SELECT user_card_id, profile_id, preferred_name, locale, timezone,
                       communication_preferences_json, boundaries_json,
                       biography_fragments_json, shared_preferences_json,
                       source_friend_path, created_at, updated_at
                FROM user_cards
                WHERE user_card_id = ?
                """,
                (user_card_id,),
            ).fetchone()
        return _user_card_from_row(row) if row is not None else None

    def load_user_card_for_profile(self, profile_id: str) -> UserCardRecord | None:
        with self.connection() as connection:
            row = connection.execute(
                """
                SELECT user_card_id, profile_id, preferred_name, locale, timezone,
                       communication_preferences_json, boundaries_json,
                       biography_fragments_json, shared_preferences_json,
                       source_friend_path, created_at, updated_at
                FROM user_cards
                WHERE profile_id = ?
                ORDER BY updated_at DESC, created_at DESC
                LIMIT 1
                """,
                (profile_id,),
            ).fetchone()
        return _user_card_from_row(row) if row is not None else None

    def upsert_relationship_memory(
        self,
        record: RelationshipMemoryRecord,
        *,
        updated_at: datetime | None = None,
    ) -> None:
        timestamp = _iso(updated_at or record.updated_at or record.created_at)
        created_at = timestamp
        with self.connection() as connection:
            existing = connection.execute(
                "SELECT created_at FROM relationship_memories WHERE relationship_id = ?",
                (record.relationship_id,),
            ).fetchone()
            if existing is not None:
                created_at = str(existing["created_at"])
            connection.execute(
                """
                INSERT INTO relationship_memories (
                    relationship_id,
                    profile_id,
                    clone_id,
                    user_card_id,
                    interaction_preferences_json,
                    repair_history_json,
                    trust_markers_json,
                    expectations_json,
                    local_corrections_json,
                    continuity_notes_json,
                    created_at,
                    updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(relationship_id) DO UPDATE SET
                    profile_id = excluded.profile_id,
                    clone_id = excluded.clone_id,
                    user_card_id = excluded.user_card_id,
                    interaction_preferences_json = excluded.interaction_preferences_json,
                    repair_history_json = excluded.repair_history_json,
                    trust_markers_json = excluded.trust_markers_json,
                    expectations_json = excluded.expectations_json,
                    local_corrections_json = excluded.local_corrections_json,
                    continuity_notes_json = excluded.continuity_notes_json,
                    updated_at = excluded.updated_at
                """,
                (
                    record.relationship_id,
                    record.profile_id,
                    record.clone_id,
                    record.user_card_id,
                    _json_text(record.interaction_preferences),
                    _json_text(record.repair_history),
                    _json_text(record.trust_markers),
                    _json_text(record.expectations),
                    _json_text(record.local_corrections),
                    _json_text(record.continuity_notes),
                    created_at,
                    timestamp,
                ),
            )
            connection.commit()

    def load_relationship_memory(self, relationship_id: str) -> RelationshipMemoryRecord | None:
        with self.connection() as connection:
            row = connection.execute(
                """
                SELECT relationship_id, profile_id, clone_id, user_card_id,
                       interaction_preferences_json, repair_history_json,
                       trust_markers_json, expectations_json,
                       local_corrections_json, continuity_notes_json,
                       created_at, updated_at
                FROM relationship_memories
                WHERE relationship_id = ?
                """,
                (relationship_id,),
            ).fetchone()
        return _relationship_memory_from_row(row) if row is not None else None

    def load_relationship_memory_for_profile(self, profile_id: str) -> RelationshipMemoryRecord | None:
        with self.connection() as connection:
            row = connection.execute(
                """
                SELECT relationship_id, profile_id, clone_id, user_card_id,
                       interaction_preferences_json, repair_history_json,
                       trust_markers_json, expectations_json,
                       local_corrections_json, continuity_notes_json,
                       created_at, updated_at
                FROM relationship_memories
                WHERE profile_id = ?
                ORDER BY updated_at DESC, created_at DESC
                LIMIT 1
                """,
                (profile_id,),
            ).fetchone()
        return _relationship_memory_from_row(row) if row is not None else None

    def append_identity_ledger(
        self,
        entry: StoredIdentityLedgerEntry,
        *,
        created_at: datetime | None = None,
    ) -> None:
        timestamp = _iso(created_at or entry.created_at)
        created_value = timestamp
        with self.connection() as connection:
            existing = connection.execute(
                "SELECT created_at FROM identity_ledger_entries WHERE entry_id = ?",
                (entry.entry_id,),
            ).fetchone()
            if existing is not None:
                created_value = str(existing["created_at"])
            connection.execute(
                """
                INSERT INTO identity_ledger_entries (
                    entry_id,
                    clone_id,
                    profile_id,
                    action,
                    summary,
                    metadata_json,
                    created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(entry_id) DO UPDATE SET
                    clone_id = excluded.clone_id,
                    profile_id = excluded.profile_id,
                    action = excluded.action,
                    summary = excluded.summary,
                    metadata_json = excluded.metadata_json
                """,
                (
                    entry.entry_id,
                    entry.clone_id,
                    entry.profile_id,
                    entry.action,
                    entry.summary,
                    _json_mapping(dict(entry.metadata)),
                    created_value,
                ),
            )
            connection.commit()

    def list_identity_ledger(self, clone_id: str | None = None) -> tuple[StoredIdentityLedgerEntry, ...]:
        with self.connection() as connection:
            if clone_id is None:
                rows = connection.execute(
                    """
                    SELECT entry_id, clone_id, profile_id, action, summary,
                           metadata_json, created_at
                    FROM identity_ledger_entries
                    ORDER BY created_at ASC, entry_id ASC
                    """
                ).fetchall()
            else:
                rows = connection.execute(
                    """
                    SELECT entry_id, clone_id, profile_id, action, summary,
                           metadata_json, created_at
                    FROM identity_ledger_entries
                    WHERE clone_id = ?
                    ORDER BY created_at ASC, entry_id ASC
                    """,
                    (clone_id,),
                ).fetchall()
        return tuple(_identity_ledger_from_row(row) for row in rows)

    def append_user_card_ledger(
        self,
        entry: StoredUserCardLedgerEntry,
        *,
        created_at: datetime | None = None,
    ) -> None:
        timestamp = _iso(created_at or entry.created_at)
        created_value = timestamp
        with self.connection() as connection:
            existing = connection.execute(
                "SELECT created_at FROM user_card_ledger_entries WHERE entry_id = ?",
                (entry.entry_id,),
            ).fetchone()
            if existing is not None:
                created_value = str(existing["created_at"])
            connection.execute(
                """
                INSERT INTO user_card_ledger_entries (
                    entry_id,
                    user_card_id,
                    profile_id,
                    action,
                    summary,
                    metadata_json,
                    created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(entry_id) DO UPDATE SET
                    user_card_id = excluded.user_card_id,
                    profile_id = excluded.profile_id,
                    action = excluded.action,
                    summary = excluded.summary,
                    metadata_json = excluded.metadata_json
                """,
                (
                    entry.entry_id,
                    entry.user_card_id,
                    entry.profile_id,
                    entry.action,
                    entry.summary,
                    _json_mapping(dict(entry.metadata)),
                    created_value,
                ),
            )
            connection.commit()

    def list_user_card_ledger(self, user_card_id: str | None = None) -> tuple[StoredUserCardLedgerEntry, ...]:
        with self.connection() as connection:
            if user_card_id is None:
                rows = connection.execute(
                    """
                    SELECT entry_id, user_card_id, profile_id, action, summary,
                           metadata_json, created_at
                    FROM user_card_ledger_entries
                    ORDER BY created_at ASC, entry_id ASC
                    """
                ).fetchall()
            else:
                rows = connection.execute(
                    """
                    SELECT entry_id, user_card_id, profile_id, action, summary,
                           metadata_json, created_at
                    FROM user_card_ledger_entries
                    WHERE user_card_id = ?
                    ORDER BY created_at ASC, entry_id ASC
                    """,
                    (user_card_id,),
                ).fetchall()
        return tuple(_user_card_ledger_from_row(row) for row in rows)

    def append_relationship_ledger(
        self,
        entry: StoredRelationshipLedgerEntry,
        *,
        created_at: datetime | None = None,
    ) -> None:
        timestamp = _iso(created_at or entry.created_at)
        created_value = timestamp
        with self.connection() as connection:
            existing = connection.execute(
                "SELECT created_at FROM relationship_ledger_entries WHERE entry_id = ?",
                (entry.entry_id,),
            ).fetchone()
            if existing is not None:
                created_value = str(existing["created_at"])
            connection.execute(
                """
                INSERT INTO relationship_ledger_entries (
                    entry_id,
                    relationship_id,
                    profile_id,
                    action,
                    summary,
                    metadata_json,
                    created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(entry_id) DO UPDATE SET
                    relationship_id = excluded.relationship_id,
                    profile_id = excluded.profile_id,
                    action = excluded.action,
                    summary = excluded.summary,
                    metadata_json = excluded.metadata_json
                """,
                (
                    entry.entry_id,
                    entry.relationship_id,
                    entry.profile_id,
                    entry.action,
                    entry.summary,
                    _json_mapping(dict(entry.metadata)),
                    created_value,
                ),
            )
            connection.commit()

    def list_relationship_ledger(
        self,
        relationship_id: str | None = None,
    ) -> tuple[StoredRelationshipLedgerEntry, ...]:
        with self.connection() as connection:
            if relationship_id is None:
                rows = connection.execute(
                    """
                    SELECT entry_id, relationship_id, profile_id, action, summary,
                           metadata_json, created_at
                    FROM relationship_ledger_entries
                    ORDER BY created_at ASC, entry_id ASC
                    """
                ).fetchall()
            else:
                rows = connection.execute(
                    """
                    SELECT entry_id, relationship_id, profile_id, action, summary,
                           metadata_json, created_at
                    FROM relationship_ledger_entries
                    WHERE relationship_id = ?
                    ORDER BY created_at ASC, entry_id ASC
                    """,
                    (relationship_id,),
                ).fetchall()
        return tuple(_relationship_ledger_from_row(row) for row in rows)

    def upsert_session(self, session: SessionState, *, resume_count_delta: int = 0) -> None:
        with self.connection() as connection:
            connection.execute(
                """
                INSERT INTO sessions (
                    session_id,
                    profile_id,
                    workspace_id,
                    status,
                    started_at,
                    updated_at,
                    parent_session_id,
                    interruption_state,
                    resume_count
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(session_id) DO UPDATE SET
                    profile_id = excluded.profile_id,
                    workspace_id = excluded.workspace_id,
                    status = excluded.status,
                    started_at = excluded.started_at,
                    updated_at = excluded.updated_at,
                    parent_session_id = excluded.parent_session_id,
                    interruption_state = excluded.interruption_state,
                    resume_count = sessions.resume_count + ?
                """,
                (
                    session.session_id,
                    session.profile_id,
                    session.workspace_id,
                    session.status,
                    _iso(session.started_at),
                    _iso(session.updated_at),
                    session.parent_session_id,
                    session.interruption_state,
                    resume_count_delta,
                    resume_count_delta,
                ),
            )
            connection.commit()

    def load_session(self, session_id: str) -> SessionState | None:
        with self.connection() as connection:
            row = connection.execute(
                """
                SELECT session_id, profile_id, workspace_id, status, started_at,
                       updated_at, parent_session_id, interruption_state
                FROM sessions
                WHERE session_id = ?
                """,
                (session_id,),
            ).fetchone()
        if row is None:
            return None
        return SessionState(
            session_id=str(row["session_id"]),
            profile_id=str(row["profile_id"]),
            workspace_id=str(row["workspace_id"]) if row["workspace_id"] is not None else None,
            status=str(row["status"]),
            started_at=_parse_datetime(str(row["started_at"])),
            updated_at=_parse_datetime(str(row["updated_at"])),
            parent_session_id=str(row["parent_session_id"]) if row["parent_session_id"] is not None else None,
            interruption_state=str(row["interruption_state"]) if row["interruption_state"] is not None else None,
        )

    def upsert_goal_graph(self, graph: GoalGraph) -> None:
        timestamp = _iso(graph.updated_at)
        with self.connection() as connection:
            existing_graph = connection.execute(
                """
                SELECT created_at
                FROM goal_graphs
                WHERE session_id = ?
                """,
                (graph.session_id,),
            ).fetchone()
            created_at = str(existing_graph["created_at"]) if existing_graph is not None else timestamp

            connection.execute(
                """
                INSERT INTO goal_graphs (
                    session_id,
                    root_goal_id,
                    active_goal_id,
                    revision_id,
                    created_at,
                    updated_at
                ) VALUES (?, ?, ?, ?, ?, ?)
                ON CONFLICT(session_id) DO UPDATE SET
                    root_goal_id = excluded.root_goal_id,
                    active_goal_id = excluded.active_goal_id,
                    revision_id = excluded.revision_id,
                    updated_at = excluded.updated_at
                """,
                (
                    graph.session_id,
                    graph.root_goal_id,
                    graph.active_goal_id,
                    graph.revision_id,
                    created_at,
                    timestamp,
                ),
            )

            existing_goal_rows = connection.execute(
                """
                SELECT goal_id, status, revision_id, created_at
                FROM goal_nodes
                WHERE session_id = ?
                """,
                (graph.session_id,),
            ).fetchall()
            existing_by_goal_id = {str(row["goal_id"]): row for row in existing_goal_rows}

            for goal_order, goal in enumerate(graph.nodes):
                goal_record = goal.to_record()
                previous = existing_by_goal_id.get(goal.goal_id)
                goal_created_at = str(previous["created_at"]) if previous is not None else timestamp
                connection.execute(
                    """
                    INSERT INTO goal_nodes (
                        goal_id,
                        session_id,
                        goal_order,
                        title,
                        status,
                        priority,
                        owner,
                        parent_goal_id,
                        dependency_refs_json,
                        evidence_refs_json,
                        related_memory_ids_json,
                        deadline,
                        time_sensitivity,
                        review_checkpoint,
                        revision_id,
                        created_at,
                        updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ON CONFLICT(goal_id) DO UPDATE SET
                        session_id = excluded.session_id,
                        goal_order = excluded.goal_order,
                        title = excluded.title,
                        status = excluded.status,
                        priority = excluded.priority,
                        owner = excluded.owner,
                        parent_goal_id = excluded.parent_goal_id,
                        dependency_refs_json = excluded.dependency_refs_json,
                        evidence_refs_json = excluded.evidence_refs_json,
                        related_memory_ids_json = excluded.related_memory_ids_json,
                        deadline = excluded.deadline,
                        time_sensitivity = excluded.time_sensitivity,
                        review_checkpoint = excluded.review_checkpoint,
                        revision_id = excluded.revision_id,
                        updated_at = excluded.updated_at
                    """,
                    (
                        goal.goal_id,
                        graph.session_id,
                        goal_order,
                        goal.title,
                        goal.status,
                        goal.priority,
                        goal.owner,
                        goal.parent_goal_id,
                        _json_text(goal.dependency_refs),
                        _json_text(goal.evidence_refs),
                        _json_text(goal.related_memory_ids),
                        goal.deadline.isoformat() if goal.deadline is not None else None,
                        goal.time_sensitivity,
                        goal.review_checkpoint,
                        goal.revision_id,
                        goal_created_at,
                        goal_record["updated_at"],
                    ),
                )
                if previous is not None and str(previous["status"]) != goal.status:
                    connection.execute(
                        """
                        INSERT INTO goal_lifecycle_events (
                            event_id,
                            session_id,
                            goal_id,
                            from_status,
                            to_status,
                            reason,
                            revision_id,
                            metadata_json,
                            created_at
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                        ON CONFLICT(event_id) DO UPDATE SET
                            from_status = excluded.from_status,
                            to_status = excluded.to_status,
                            reason = excluded.reason,
                            revision_id = excluded.revision_id,
                            metadata_json = excluded.metadata_json
                        """,
                        (
                            f"{graph.session_id}:{goal.goal_id}:{goal_record['updated_at']}:{goal.status}",
                            graph.session_id,
                            goal.goal_id,
                            str(previous["status"]),
                            goal.status,
                            None,
                            goal.revision_id,
                            _json_dict_text(
                                {
                                    "goal_order": goal_order,
                                    "title": goal.title,
                                    "priority": goal.priority,
                                    "owner": goal.owner,
                                }
                            ),
                            goal_record["updated_at"],
                        ),
                    )
            connection.commit()

    def load_goal_graph(self, session_id: str) -> GoalGraph | None:
        with self.connection() as connection:
            graph_row = connection.execute(
                """
                SELECT session_id, root_goal_id, active_goal_id, revision_id, updated_at
                FROM goal_graphs
                WHERE session_id = ?
                """,
                (session_id,),
            ).fetchone()
            goal_rows = connection.execute(
                """
                SELECT goal_id, session_id, goal_order, title, status, priority, owner,
                       parent_goal_id, dependency_refs_json, evidence_refs_json,
                       related_memory_ids_json, deadline, time_sensitivity,
                       review_checkpoint, revision_id, updated_at
                FROM goal_nodes
                WHERE session_id = ?
                ORDER BY goal_order ASC, goal_id ASC
                """,
                (session_id,),
            ).fetchall()

        if graph_row is None and not goal_rows:
            return None

        graph_record = {
            "session_id": session_id,
            "root_goal_id": graph_row["root_goal_id"] if graph_row is not None else None,
            "active_goal_id": graph_row["active_goal_id"] if graph_row is not None else None,
            "revision_id": graph_row["revision_id"] if graph_row is not None else None,
            "updated_at": graph_row["updated_at"] if graph_row is not None else None,
            "nodes": tuple(
                GoalGraphNode.from_record(
                    {
                        "goal_id": row["goal_id"],
                        "session_id": row["session_id"],
                        "title": row["title"],
                        "status": row["status"],
                        "priority": row["priority"],
                        "owner": row["owner"],
                        "parent_goal_id": row["parent_goal_id"],
                        "dependency_refs": _tuple_text(str(row["dependency_refs_json"])),
                        "evidence_refs": _tuple_text(str(row["evidence_refs_json"])),
                        "related_memory_ids": _tuple_text(str(row["related_memory_ids_json"])),
                        "deadline": row["deadline"],
                        "time_sensitivity": row["time_sensitivity"],
                        "review_checkpoint": row["review_checkpoint"],
                        "revision_id": row["revision_id"],
                        "updated_at": row["updated_at"],
                    }
                )
                for row in goal_rows
            ),
        }
        return GoalGraph.from_record(graph_record)

    def record_resume(self, parent_session_id: str, child_session_id: str, resumed_at: datetime) -> None:
        with self.connection() as connection:
            connection.execute(
                """
                INSERT INTO session_lineage(parent_session_id, child_session_id, resumed_at)
                VALUES (?, ?, ?)
                ON CONFLICT(child_session_id) DO UPDATE SET
                    parent_session_id = excluded.parent_session_id,
                    resumed_at = excluded.resumed_at
                """,
                (parent_session_id, child_session_id, _iso(resumed_at)),
            )
            parent = connection.execute(
                "SELECT resume_count FROM sessions WHERE session_id = ?",
                (parent_session_id,),
            ).fetchone()
            if parent is not None:
                connection.execute(
                    """
                    UPDATE sessions
                    SET status = ?, updated_at = ?, resume_count = resume_count + 1
                    WHERE session_id = ?
                    """,
                    ("resumed", _iso(resumed_at), parent_session_id),
                )
            connection.commit()

    def lineage(self, session_id: str) -> tuple[SessionState, ...]:
        session = self.load_session(session_id)
        if session is None:
            return ()
        chain = [session]
        current = session
        while current.parent_session_id is not None:
            parent = self.load_session(current.parent_session_id)
            if parent is None:
                break
            chain.append(parent)
            current = parent
        return tuple(reversed(chain))

    def upsert_agent_run(self, run: AgentRunState) -> None:
        with self.connection() as connection:
            connection.execute(
                """
                INSERT INTO agent_runs (
                    run_id,
                    session_id,
                    source_event_id,
                    prompt,
                    status,
                    phase,
                    step_count,
                    model_turn_count,
                    tool_call_count,
                    max_model_turns,
                    max_wall_time_seconds,
                    waiting_reason,
                    continuation_prompt,
                    last_summary,
                    created_at,
                    updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(run_id) DO UPDATE SET
                    session_id = excluded.session_id,
                    source_event_id = excluded.source_event_id,
                    prompt = excluded.prompt,
                    status = excluded.status,
                    phase = excluded.phase,
                    step_count = excluded.step_count,
                    model_turn_count = excluded.model_turn_count,
                    tool_call_count = excluded.tool_call_count,
                    max_model_turns = excluded.max_model_turns,
                    max_wall_time_seconds = excluded.max_wall_time_seconds,
                    waiting_reason = excluded.waiting_reason,
                    continuation_prompt = excluded.continuation_prompt,
                    last_summary = excluded.last_summary,
                    created_at = excluded.created_at,
                    updated_at = excluded.updated_at
                """,
                (
                    run.run_id,
                    run.session_id,
                    run.source_event_id,
                    run.prompt,
                    run.status,
                    run.phase,
                    run.step_count,
                    run.model_turn_count,
                    run.tool_call_count,
                    run.max_model_turns,
                    run.max_wall_time_seconds,
                    run.waiting_reason,
                    run.continuation_prompt,
                    run.last_summary,
                    _iso(run.created_at),
                    _iso(run.updated_at),
                ),
            )
            connection.commit()

    def load_agent_run(self, run_id: str) -> AgentRunState | None:
        with self.connection() as connection:
            row = connection.execute(
                """
                SELECT run_id, session_id, source_event_id, prompt, status, phase,
                       step_count, model_turn_count, tool_call_count, max_model_turns,
                       max_wall_time_seconds, waiting_reason, continuation_prompt,
                       last_summary, created_at, updated_at
                FROM agent_runs
                WHERE run_id = ?
                """,
                (run_id,),
            ).fetchone()
        return _agent_run_from_row(row) if row is not None else None

    def load_latest_open_agent_run(self, session_id: str) -> AgentRunState | None:
        with self.connection() as connection:
            row = connection.execute(
                """
                SELECT run_id, session_id, source_event_id, prompt, status, phase,
                       step_count, model_turn_count, tool_call_count, max_model_turns,
                       max_wall_time_seconds, waiting_reason, continuation_prompt,
                       last_summary, created_at, updated_at
                FROM agent_runs
                WHERE session_id = ? AND status IN ('active', 'pending')
                ORDER BY updated_at DESC, created_at DESC
                LIMIT 1
                """,
                (session_id,),
            ).fetchone()
        return _agent_run_from_row(row) if row is not None else None

    def list_agent_runs(
        self,
        session_id: str | None = None,
        *,
        statuses: tuple[str, ...] = (),
    ) -> tuple[AgentRunState, ...]:
        filters: list[str] = []
        parameters: list[object] = []
        if session_id is not None:
            filters.append("session_id = ?")
            parameters.append(session_id)
        if statuses:
            placeholders = ", ".join("?" for _ in statuses)
            filters.append(f"status IN ({placeholders})")
            parameters.extend(statuses)
        where_clause = f"WHERE {' AND '.join(filters)}" if filters else ""
        with self.connection() as connection:
            rows = connection.execute(
                f"""
                SELECT run_id, session_id, source_event_id, prompt, status, phase,
                       step_count, model_turn_count, tool_call_count, max_model_turns,
                       max_wall_time_seconds, waiting_reason, continuation_prompt,
                       last_summary, created_at, updated_at
                FROM agent_runs
                {where_clause}
                ORDER BY updated_at DESC, created_at DESC
                """,
                tuple(parameters),
            ).fetchall()
        return tuple(_agent_run_from_row(row) for row in rows)

    def append_agent_run_step(self, step: AgentRunStep) -> None:
        with self.connection() as connection:
            connection.execute(
                """
                INSERT OR REPLACE INTO agent_run_steps (
                    step_id,
                    run_id,
                    session_id,
                    step_index,
                    kind,
                    title,
                    content,
                    outcome,
                    tool_name,
                    created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    step.step_id,
                    step.run_id,
                    step.session_id,
                    step.step_index,
                    step.kind,
                    step.title,
                    step.content,
                    step.outcome,
                    step.tool_name,
                    _iso(step.created_at),
                ),
            )
            connection.commit()

    def list_agent_run_steps(self, run_id: str, *, limit: int | None = None) -> tuple[AgentRunStep, ...]:
        limit_clause = "LIMIT ?" if limit is not None else ""
        parameters: tuple[object, ...]
        if limit is None:
            parameters = (run_id,)
        else:
            parameters = (run_id, limit)
        with self.connection() as connection:
            rows = connection.execute(
                f"""
                SELECT step_id, run_id, session_id, step_index, kind, title, content,
                       outcome, tool_name, created_at
                FROM agent_run_steps
                WHERE run_id = ?
                ORDER BY step_index DESC
                {limit_clause}
                """,
                parameters,
            ).fetchall()
        steps = tuple(_agent_run_step_from_row(row) for row in rows)
        return tuple(reversed(steps))

    def upsert_experience(self, experience: ExperienceRecord) -> None:
        with self.connection() as connection:
            connection.execute(
                """
                INSERT INTO experiences (
                    experience_id,
                    session_id,
                    profile_id,
                    workspace_id,
                    run_id,
                    source_event_id,
                    kind,
                    title,
                    summary,
                    status,
                    goal_id,
                    tool_call_count,
                    model_turn_count,
                    related_skill_ids_json,
                    produced_artifact_ids_json,
                    tags_json,
                    created_at,
                    updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(experience_id) DO UPDATE SET
                    session_id = excluded.session_id,
                    profile_id = excluded.profile_id,
                    workspace_id = excluded.workspace_id,
                    run_id = excluded.run_id,
                    source_event_id = excluded.source_event_id,
                    kind = excluded.kind,
                    title = excluded.title,
                    summary = excluded.summary,
                    status = excluded.status,
                    goal_id = excluded.goal_id,
                    tool_call_count = excluded.tool_call_count,
                    model_turn_count = excluded.model_turn_count,
                    related_skill_ids_json = excluded.related_skill_ids_json,
                    produced_artifact_ids_json = excluded.produced_artifact_ids_json,
                    tags_json = excluded.tags_json,
                    created_at = excluded.created_at,
                    updated_at = excluded.updated_at
                """,
                (
                    experience.experience_id,
                    experience.session_id,
                    experience.profile_id,
                    experience.workspace_id,
                    experience.run_id,
                    experience.source_event_id,
                    experience.kind,
                    experience.title,
                    experience.summary,
                    experience.status,
                    experience.goal_id,
                    experience.tool_call_count,
                    experience.model_turn_count,
                    _json_text(experience.related_skill_ids),
                    _json_text(experience.produced_artifact_ids),
                    _json_text(experience.tags),
                    _iso(experience.created_at),
                    _iso(experience.updated_at),
                ),
            )
            connection.commit()

    def load_experience(self, experience_id: str) -> ExperienceRecord | None:
        with self.connection() as connection:
            row = connection.execute(
                """
                SELECT experience_id, session_id, profile_id, workspace_id, run_id,
                       source_event_id, kind, title, summary, status, goal_id,
                       tool_call_count, model_turn_count, related_skill_ids_json,
                       produced_artifact_ids_json, tags_json, created_at, updated_at
                FROM experiences
                WHERE experience_id = ?
                """,
                (experience_id,),
            ).fetchone()
        return _experience_from_row(row) if row is not None else None

    def load_profile_growth(self, profile_id: str) -> ProfileGrowthState | None:
        with self.connection() as connection:
            row = connection.execute(
                """
                SELECT profile_id, growth_score, total_dialogues, total_tokens,
                       total_experiences, promoted_experiences, active_days,
                       streak_days, first_dialogue_at, last_dialogue_at,
                       last_active_day, created_at, updated_at
                FROM profile_growth
                WHERE profile_id = ?
                """,
                (profile_id,),
            ).fetchone()
        return _growth_from_row(row) if row is not None else None

    def upsert_profile_growth(self, growth: ProfileGrowthState) -> None:
        with self.connection() as connection:
            connection.execute(
                """
                INSERT INTO profile_growth (
                    profile_id,
                    growth_score,
                    total_dialogues,
                    total_tokens,
                    total_experiences,
                    promoted_experiences,
                    active_days,
                    streak_days,
                    first_dialogue_at,
                    last_dialogue_at,
                    last_active_day,
                    created_at,
                    updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(profile_id) DO UPDATE SET
                    growth_score = excluded.growth_score,
                    total_dialogues = excluded.total_dialogues,
                    total_tokens = excluded.total_tokens,
                    total_experiences = excluded.total_experiences,
                    promoted_experiences = excluded.promoted_experiences,
                    active_days = excluded.active_days,
                    streak_days = excluded.streak_days,
                    first_dialogue_at = excluded.first_dialogue_at,
                    last_dialogue_at = excluded.last_dialogue_at,
                    last_active_day = excluded.last_active_day,
                    created_at = excluded.created_at,
                    updated_at = excluded.updated_at
                """,
                (
                    growth.profile_id,
                    growth.growth_score,
                    growth.total_dialogues,
                    growth.total_tokens,
                    growth.total_experiences,
                    growth.promoted_experiences,
                    growth.active_days,
                    growth.streak_days,
                    _iso(growth.first_dialogue_at) if growth.first_dialogue_at is not None else None,
                    _iso(growth.last_dialogue_at) if growth.last_dialogue_at is not None else None,
                    growth.last_active_day,
                    _iso(growth.created_at),
                    _iso(growth.updated_at),
                ),
            )
            connection.commit()

    def list_experiences(
        self,
        session_id: str | None = None,
        *,
        profile_id: str | None = None,
        statuses: tuple[str, ...] = (),
        limit: int | None = None,
    ) -> tuple[ExperienceRecord, ...]:
        if limit is not None and limit <= 0:
            return ()
        filters: list[str] = []
        parameters: list[object] = []
        if session_id is not None:
            filters.append("session_id = ?")
            parameters.append(session_id)
        if profile_id is not None:
            filters.append("profile_id = ?")
            parameters.append(profile_id)
        if statuses:
            placeholders = ", ".join("?" for _ in statuses)
            filters.append(f"status IN ({placeholders})")
            parameters.extend(statuses)
        where_clause = f"WHERE {' AND '.join(filters)}" if filters else ""
        limit_clause = ""
        if limit is not None:
            limit_clause = "LIMIT ?"
            parameters.append(limit)
        with self.connection() as connection:
            rows = connection.execute(
                f"""
                SELECT experience_id, session_id, profile_id, workspace_id, run_id,
                       source_event_id, kind, title, summary, status, goal_id,
                       tool_call_count, model_turn_count, related_skill_ids_json,
                       produced_artifact_ids_json, tags_json, created_at, updated_at
                FROM experiences
                {where_clause}
                ORDER BY updated_at DESC, created_at DESC
                {limit_clause}
                """,
                tuple(parameters),
            ).fetchall()
        return tuple(_experience_from_row(row) for row in rows)

    def refresh_session(
        self,
        session_id: str,
        *,
        status: str | None = None,
        interruption_state: str | None = None,
        updated_at: datetime | None = None,
    ) -> SessionState:
        current = self.load_session(session_id)
        if current is None:
            raise KeyError(session_id)
        updated = replace(
            current,
            status=status if status is not None else current.status,
            interruption_state=(
                interruption_state if interruption_state is not None else current.interruption_state
            ),
            updated_at=updated_at or _utc_now(),
        )
        self.upsert_session(updated)
        return updated

    def delete_sessions(self, session_ids: tuple[str, ...]) -> int:
        if not session_ids:
            return 0
        placeholders = ", ".join("?" for _ in session_ids)
        with self.connection() as connection:
            connection.execute(
                f"""
                DELETE FROM session_lineage
                WHERE parent_session_id IN ({placeholders})
                   OR child_session_id IN ({placeholders})
                """,
                session_ids + session_ids,
            )
            connection.execute(
                f"DELETE FROM memory_ledger_entries WHERE session_id IN ({placeholders})",
                session_ids,
            )
            connection.execute(
                f"DELETE FROM memories WHERE session_id IN ({placeholders})",
                session_ids,
            )
            connection.execute(
                f"DELETE FROM goal_graphs WHERE session_id IN ({placeholders})",
                session_ids,
            )
            deleted = connection.execute(
                f"DELETE FROM sessions WHERE session_id IN ({placeholders})",
                session_ids,
            ).rowcount
            connection.commit()
        return deleted

    def append_memory_ledger(self, entry: StoredMemoryLedgerEntry, *, created_at: datetime | None = None) -> None:
        timestamp = _iso(created_at or entry.created_at)
        created_value = timestamp
        with self.connection() as connection:
            existing = connection.execute(
                "SELECT created_at FROM memory_ledger_entries WHERE entry_id = ?",
                (entry.entry_id,),
            ).fetchone()
            if existing is not None:
                created_value = str(existing["created_at"])
            connection.execute(
                """
                INSERT INTO memory_ledger_entries (
                    entry_id,
                    session_id,
                    event_id,
                    event_type,
                    content,
                    kind,
                    source_event_id,
                    goal_refs_json,
                    tags_json,
                    metadata_json,
                    created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(entry_id) DO UPDATE SET
                    session_id = excluded.session_id,
                    event_id = excluded.event_id,
                    event_type = excluded.event_type,
                    content = excluded.content,
                    kind = excluded.kind,
                    source_event_id = excluded.source_event_id,
                    goal_refs_json = excluded.goal_refs_json,
                    tags_json = excluded.tags_json,
                    metadata_json = excluded.metadata_json
                """,
                (
                    entry.entry_id,
                    entry.session_id,
                    entry.event_id,
                    entry.event_type,
                    entry.content,
                    entry.kind,
                    entry.source_event_id,
                    _json_text(entry.goal_refs),
                    _json_text(entry.tags),
                    _json_mapping(dict(entry.metadata)),
                    created_value,
                ),
            )
            connection.commit()

    def list_memory_ledger(self, session_id: str | None = None) -> tuple[StoredMemoryLedgerEntry, ...]:
        with self.connection() as connection:
            if session_id is None:
                rows = connection.execute(
                    """
                    SELECT entry_id, session_id, event_id, event_type, content, kind,
                           source_event_id, goal_refs_json, tags_json, metadata_json, created_at
                    FROM memory_ledger_entries
                    ORDER BY created_at ASC, entry_id ASC
                    """
                ).fetchall()
            else:
                rows = connection.execute(
                    """
                    SELECT entry_id, session_id, event_id, event_type, content, kind,
                           source_event_id, goal_refs_json, tags_json, metadata_json, created_at
                    FROM memory_ledger_entries
                    WHERE session_id = ?
                    ORDER BY created_at ASC, entry_id ASC
                    """,
                    (session_id,),
                ).fetchall()
        return tuple(_ledger_entry_from_row(row) for row in rows)

    def upsert_memory_record(
        self,
        record: StoredMemoryRecord,
        *,
        state: str = "active",
        updated_at: datetime | None = None,
    ) -> None:
        timestamp = _iso(updated_at or record.created_at)
        created_value = timestamp
        state_value = state
        replacement_memory_id: str | None = None
        with self.connection() as connection:
            existing = connection.execute(
                """
                SELECT created_at, lifecycle_state, replacement_memory_id
                FROM memories
                WHERE memory_id = ?
                """,
                (record.memory_id,),
            ).fetchone()
            if existing is not None:
                created_value = str(existing["created_at"])
                state_value = str(existing["lifecycle_state"])
                replacement_memory_id = (
                    str(existing["replacement_memory_id"]) if existing["replacement_memory_id"] is not None else None
                )
            connection.execute(
                """
                INSERT INTO memories (
                    memory_id,
                    session_id,
                    kind,
                    content,
                    source_event_id,
                    goal_refs_json,
                    tags_json,
                    created_at,
                    lifecycle_state,
                    replacement_memory_id,
                    updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(memory_id) DO UPDATE SET
                    session_id = excluded.session_id,
                    kind = excluded.kind,
                    content = excluded.content,
                    source_event_id = excluded.source_event_id,
                    goal_refs_json = excluded.goal_refs_json,
                    tags_json = excluded.tags_json,
                    lifecycle_state = excluded.lifecycle_state,
                    replacement_memory_id = excluded.replacement_memory_id,
                    updated_at = excluded.updated_at
                """,
                (
                    record.memory_id,
                    record.session_id,
                    record.kind,
                    record.content,
                    record.source_event_id,
                    _json_text(record.goal_refs),
                    _json_text(record.tags),
                    created_value,
                    state_value,
                    replacement_memory_id,
                    timestamp,
                ),
            )
            connection.commit()

    def load_memory_record(self, memory_id: str) -> StoredMemoryRecord | None:
        with self.connection() as connection:
            row = connection.execute(
                """
                SELECT memory_id, session_id, kind, content, source_event_id,
                       goal_refs_json, tags_json, created_at
                FROM memories
                WHERE memory_id = ?
                """,
                (memory_id,),
            ).fetchone()
        if row is None:
            return None
        return _record_from_row(row)

    def list_memory_records(
        self,
        session_id: str | None = None,
        *,
        include_inactive: bool = False,
    ) -> tuple[StoredMemoryRecord, ...]:
        clauses = []
        params: list[str] = []
        if session_id is not None:
            clauses.append("session_id = ?")
            params.append(session_id)
        if not include_inactive:
            clauses.append("lifecycle_state = 'active'")
        where_sql = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        with self.connection() as connection:
            rows = connection.execute(
                f"""
                SELECT memory_id, session_id, kind, content, source_event_id,
                       goal_refs_json, tags_json, created_at
                FROM memories
                {where_sql}
                ORDER BY created_at ASC, memory_id ASC
                """,
                tuple(params),
            ).fetchall()
        return tuple(_record_from_row(row) for row in rows)

    def mark_memory_consolidated(self, source_ids: tuple[str, ...], summary_id: str) -> None:
        if not source_ids:
            return
        with self.connection() as connection:
            for source_id in source_ids:
                connection.execute(
                    """
                    UPDATE memories
                    SET lifecycle_state = ?, replacement_memory_id = ?, updated_at = ?
                    WHERE memory_id = ?
                    """,
                    ("consolidated", summary_id, _iso(None), source_id),
                )
            connection.commit()

    def mark_memory_superseded(self, source_id: str, replacement_id: str) -> None:
        with self.connection() as connection:
            connection.execute(
                """
                UPDATE memories
                SET lifecycle_state = ?, replacement_memory_id = ?, updated_at = ?
                WHERE memory_id = ?
                """,
                ("superseded", replacement_id, _iso(None), source_id),
            )
            connection.commit()

    def mark_memory_deleted(self, memory_id: str) -> None:
        with self.connection() as connection:
            connection.execute(
                """
                UPDATE memories
                SET lifecycle_state = ?, updated_at = ?
                WHERE memory_id = ?
                """,
                ("deleted", _iso(None), memory_id),
            )
            connection.commit()

    def memory_state(self, memory_id: str) -> str | None:
        with self.connection() as connection:
            row = connection.execute(
                "SELECT lifecycle_state FROM memories WHERE memory_id = ?",
                (memory_id,),
            ).fetchone()
        if row is None:
            return None
        return str(row["lifecycle_state"])

    def memory_lineage(self, memory_id: str) -> str | None:
        with self.connection() as connection:
            row = connection.execute(
                "SELECT replacement_memory_id FROM memories WHERE memory_id = ?",
                (memory_id,),
            ).fetchone()
        if row is None or row["replacement_memory_id"] is None:
            return None
        return str(row["replacement_memory_id"])

    def upsert_auth_profile(self, profile: AuthProfile, *, updated_at: datetime | None = None) -> None:
        timestamp = _iso(updated_at)
        created_at = timestamp
        with self.connection() as connection:
            existing = connection.execute(
                "SELECT created_at FROM auth_profiles WHERE profile_id = ?",
                (profile.profile_id,),
            ).fetchone()
            if existing is not None:
                created_at = str(existing["created_at"])
            connection.execute(
                """
                INSERT INTO auth_profiles (
                    profile_id,
                    provider_id,
                    transport_id,
                    base_url,
                    default_model,
                    auth_method,
                    provider_kind,
                    extra_headers_json,
                    priority,
                    session_pin,
                    cooldown_until,
                    metadata_json,
                    created_at,
                    updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(profile_id) DO UPDATE SET
                    provider_id = excluded.provider_id,
                    transport_id = excluded.transport_id,
                    base_url = excluded.base_url,
                    default_model = excluded.default_model,
                    auth_method = excluded.auth_method,
                    provider_kind = excluded.provider_kind,
                    extra_headers_json = excluded.extra_headers_json,
                    priority = excluded.priority,
                    session_pin = excluded.session_pin,
                    cooldown_until = excluded.cooldown_until,
                    metadata_json = excluded.metadata_json,
                    updated_at = excluded.updated_at
                """,
                (
                    profile.profile_id,
                    profile.provider_id,
                    profile.transport_id,
                    profile.base_url,
                    profile.default_model,
                    profile.auth_method,
                    profile.provider_kind,
                    _json_mapping(dict(profile.extra_headers)),
                    profile.priority,
                    profile.session_pin,
                    _iso(profile.cooldown_until) if profile.cooldown_until is not None else None,
                    _json_mapping(dict(profile.metadata)),
                    created_at,
                    timestamp,
                ),
            )
            existing_reference_rows = connection.execute(
                "SELECT reference_id FROM auth_secret_references WHERE profile_id = ?",
                (profile.profile_id,),
            ).fetchall()
            existing_reference_ids = {
                str(row["reference_id"])
                for row in existing_reference_rows
            }
            desired_reference_ids = {reference.reference_id for reference in profile.secret_references}
            for order_index, reference in enumerate(profile.secret_references):
                connection.execute(
                    """
                    INSERT INTO auth_secret_references (
                        reference_id,
                        profile_id,
                        provider_id,
                        secret_name,
                        secret_key,
                        source,
                        reference_order,
                        metadata_json,
                        created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ON CONFLICT(reference_id) DO UPDATE SET
                        profile_id = excluded.profile_id,
                        provider_id = excluded.provider_id,
                        secret_name = excluded.secret_name,
                        secret_key = excluded.secret_key,
                        source = excluded.source,
                        reference_order = excluded.reference_order,
                        metadata_json = excluded.metadata_json
                    """,
                    (
                        reference.reference_id,
                        profile.profile_id,
                        reference.provider_id,
                        reference.secret_name,
                        reference.secret_key,
                        reference.source,
                        order_index,
                        _json_mapping(dict(reference.metadata)),
                        created_at,
                    ),
                )
            stale_reference_ids = tuple(sorted(existing_reference_ids - desired_reference_ids))
            if stale_reference_ids:
                placeholders = ", ".join("?" for _ in stale_reference_ids)
                connection.execute(
                    f"DELETE FROM auth_secret_references WHERE reference_id IN ({placeholders})",
                    stale_reference_ids,
                )
            connection.commit()

    def upsert_auth_secret_value(
        self,
        value: EncryptedSecretValue,
        *,
        updated_at: datetime | None = None,
    ) -> None:
        timestamp = _iso(updated_at)
        created_at = timestamp
        with self.connection() as connection:
            existing = connection.execute(
                "SELECT created_at FROM auth_secret_values WHERE reference_id = ?",
                (value.reference_id,),
            ).fetchone()
            if existing is not None:
                created_at = str(existing["created_at"])
            connection.execute(
                """
                INSERT INTO auth_secret_values (
                    reference_id,
                    key_id,
                    nonce_b64,
                    ciphertext_b64,
                    mac_hex,
                    created_at,
                    updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(reference_id) DO UPDATE SET
                    key_id = excluded.key_id,
                    nonce_b64 = excluded.nonce_b64,
                    ciphertext_b64 = excluded.ciphertext_b64,
                    mac_hex = excluded.mac_hex,
                    updated_at = excluded.updated_at
                """,
                (
                    value.reference_id,
                    value.key_id,
                    value.nonce_b64,
                    value.ciphertext_b64,
                    value.mac_hex,
                    created_at,
                    timestamp,
                ),
            )
            connection.commit()

    def load_auth_secret_value(self, reference_id: str) -> EncryptedSecretValue | None:
        with self.connection() as connection:
            row = connection.execute(
                """
                SELECT reference_id, key_id, nonce_b64, ciphertext_b64, mac_hex
                FROM auth_secret_values
                WHERE reference_id = ?
                """,
                (reference_id,),
            ).fetchone()
        if row is None:
            return None
        return EncryptedSecretValue(
            reference_id=str(row["reference_id"]),
            key_id=str(row["key_id"]),
            nonce_b64=str(row["nonce_b64"]),
            ciphertext_b64=str(row["ciphertext_b64"]),
            mac_hex=str(row["mac_hex"]),
        )

    def has_auth_secret_value(self, reference_id: str) -> bool:
        with self.connection() as connection:
            row = connection.execute(
                "SELECT 1 FROM auth_secret_values WHERE reference_id = ?",
                (reference_id,),
            ).fetchone()
        return row is not None

    def delete_auth_secret_value(self, reference_id: str) -> None:
        with self.connection() as connection:
            connection.execute(
                "DELETE FROM auth_secret_values WHERE reference_id = ?",
                (reference_id,),
            )
            connection.commit()

    def load_auth_profile(self, profile_id: str) -> AuthProfile | None:
        with self.connection() as connection:
            row = connection.execute(
                """
                SELECT profile_id, provider_id, transport_id, base_url, default_model,
                       auth_method, provider_kind, extra_headers_json, priority,
                       session_pin, cooldown_until, metadata_json
                FROM auth_profiles
                WHERE profile_id = ?
                """,
                (profile_id,),
            ).fetchone()
            if row is None:
                return None
            references = connection.execute(
                """
                SELECT reference_id, provider_id, secret_name, secret_key, source, metadata_json
                FROM auth_secret_references
                WHERE profile_id = ?
                ORDER BY reference_order ASC, reference_id ASC
                """,
                (profile_id,),
            ).fetchall()
        return AuthProfile(
            profile_id=str(row["profile_id"]),
            provider_id=str(row["provider_id"]),
            transport_id=str(row["transport_id"]),
            base_url=str(row["base_url"]) if row["base_url"] is not None else None,
            default_model=str(row["default_model"]) if row["default_model"] is not None else None,
            auth_method=str(row["auth_method"]),
            provider_kind=str(row["provider_kind"]),
            extra_headers=_mapping_text(str(row["extra_headers_json"])),
            secret_references=tuple(
                SecretReference(
                    reference_id=str(reference["reference_id"]),
                    provider_id=str(reference["provider_id"]),
                    secret_name=str(reference["secret_name"]),
                    secret_key=str(reference["secret_key"]),
                    source=str(reference["source"]),
                    metadata=_mapping_text(str(reference["metadata_json"])),
                )
                for reference in references
            ),
            priority=int(row["priority"]),
            session_pin=str(row["session_pin"]) if row["session_pin"] is not None else None,
            cooldown_until=_parse_datetime(str(row["cooldown_until"])) if row["cooldown_until"] is not None else None,
            metadata=_mapping_text(str(row["metadata_json"])),
        )

    def list_auth_profiles(self, provider_id: str | None = None) -> tuple[AuthProfile, ...]:
        with self.connection() as connection:
            if provider_id is None:
                rows = connection.execute(
                    """
                    SELECT profile_id
                    FROM auth_profiles
                    ORDER BY provider_id ASC, priority DESC, profile_id ASC
                    """
                ).fetchall()
            else:
                rows = connection.execute(
                    """
                    SELECT profile_id
                    FROM auth_profiles
                    WHERE provider_id = ?
                    ORDER BY priority DESC, profile_id ASC
                    """,
                    (provider_id,),
                ).fetchall()
        profiles = []
        for row in rows:
            profile = self.load_auth_profile(str(row["profile_id"]))
            if profile is not None:
                profiles.append(profile)
        return tuple(profiles)

    def select_auth_profile(self, provider_id: str) -> AuthProfile:
        profiles = sorted(
            self.list_auth_profiles(provider_id),
            key=lambda profile: (-profile.priority, profile.profile_id),
        )
        if not profiles:
            raise LookupError(f"no auth profile registered for provider: {provider_id}")
        return profiles[0]

    def upsert_provider_auth_state(
        self,
        state: ProviderAuthState,
        *,
        updated_at: datetime | None = None,
    ) -> None:
        timestamp = _iso(updated_at)
        discovered_at = _iso(state.discovered_at) if state.discovered_at is not None else timestamp
        with self.connection() as connection:
            existing = connection.execute(
                "SELECT discovered_at FROM provider_auth_states WHERE provider_id = ?",
                (state.provider_id,),
            ).fetchone()
            if existing is not None and existing["discovered_at"] is not None:
                discovered_at = str(existing["discovered_at"])
            connection.execute(
                """
                INSERT INTO provider_auth_states (
                    provider_id,
                    auth_type,
                    status,
                    source,
                    profile_id,
                    transport_id,
                    provider_kind,
                    base_url,
                    default_model,
                    runtime_enabled,
                    summary,
                    metadata_json,
                    discovered_at,
                    updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(provider_id) DO UPDATE SET
                    auth_type = excluded.auth_type,
                    status = excluded.status,
                    source = excluded.source,
                    profile_id = excluded.profile_id,
                    transport_id = excluded.transport_id,
                    provider_kind = excluded.provider_kind,
                    base_url = excluded.base_url,
                    default_model = excluded.default_model,
                    runtime_enabled = excluded.runtime_enabled,
                    summary = excluded.summary,
                    metadata_json = excluded.metadata_json,
                    updated_at = excluded.updated_at
                """,
                (
                    state.provider_id,
                    state.auth_type,
                    state.status,
                    state.source,
                    state.profile_id,
                    state.transport_id,
                    state.provider_kind,
                    state.base_url,
                    state.default_model,
                    1 if state.runtime_enabled else 0,
                    state.summary,
                    _json_mapping(dict(state.metadata)),
                    discovered_at,
                    timestamp,
                ),
            )
            connection.commit()

    def load_provider_auth_state(self, provider_id: str) -> ProviderAuthState | None:
        with self.connection() as connection:
            row = connection.execute(
                """
                SELECT provider_id, auth_type, status, source, profile_id, transport_id,
                       provider_kind, base_url, default_model, runtime_enabled, summary,
                       metadata_json, discovered_at, updated_at
                FROM provider_auth_states
                WHERE provider_id = ?
                """,
                (provider_id,),
            ).fetchone()
        if row is None:
            return None
        return ProviderAuthState(
            provider_id=str(row["provider_id"]),
            auth_type=str(row["auth_type"]),
            status=str(row["status"]),
            source=str(row["source"]),
            profile_id=str(row["profile_id"]) if row["profile_id"] is not None else None,
            transport_id=str(row["transport_id"]) if row["transport_id"] is not None else None,
            provider_kind=str(row["provider_kind"]),
            base_url=str(row["base_url"]) if row["base_url"] is not None else None,
            default_model=str(row["default_model"]) if row["default_model"] is not None else None,
            runtime_enabled=bool(int(row["runtime_enabled"])),
            summary=str(row["summary"] or ""),
            metadata=_mapping_text(str(row["metadata_json"])),
            discovered_at=_parse_datetime(str(row["discovered_at"])) if row["discovered_at"] is not None else None,
            updated_at=_parse_datetime(str(row["updated_at"])) if row["updated_at"] is not None else None,
        )

    def list_provider_auth_states(self) -> tuple[ProviderAuthState, ...]:
        with self.connection() as connection:
            rows = connection.execute(
                """
                SELECT provider_id
                FROM provider_auth_states
                ORDER BY provider_id ASC
                """
            ).fetchall()
        states: list[ProviderAuthState] = []
        for row in rows:
            state = self.load_provider_auth_state(str(row["provider_id"]))
            if state is not None:
                states.append(state)
        return tuple(states)
