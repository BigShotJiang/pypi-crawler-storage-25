"""Core shared contract shapes.

The goal here is to define durable, serializable records for the runtime.
These shapes are intentionally plain so the rest of the system can depend on
them without creating import cycles or backend-specific coupling.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime


@dataclass(frozen=True, slots=True)
class ProfileState:
    profile_id: str
    display_name: str
    mode: str
    clone_path: str | None = None
    preferences: tuple[str, ...] = ()
    enabled_capabilities: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class CloneIdentityRecord:
    clone_id: str
    profile_id: str
    display_name: str
    identity_mode: str
    personality_preset: str
    initiative: str
    relational_stance: str
    voice_contract: str
    working_style_contract: str
    charter_extension: str | None = None
    governance_flags: tuple[str, ...] = ()
    source_manifest_path: str | None = None
    source_clone_path: str | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None


@dataclass(frozen=True, slots=True)
class UserCardRecord:
    user_card_id: str
    profile_id: str
    preferred_name: str | None = None
    locale: str | None = None
    timezone: str | None = None
    communication_preferences: tuple[str, ...] = ()
    boundaries: tuple[str, ...] = ()
    biography_fragments: tuple[str, ...] = ()
    shared_preferences: tuple[str, ...] = ()
    source_friend_path: str | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None


@dataclass(frozen=True, slots=True)
class RelationshipMemoryRecord:
    relationship_id: str
    profile_id: str
    clone_id: str
    user_card_id: str | None = None
    interaction_preferences: tuple[str, ...] = ()
    repair_history: tuple[str, ...] = ()
    trust_markers: tuple[str, ...] = ()
    expectations: tuple[str, ...] = ()
    local_corrections: tuple[str, ...] = ()
    continuity_notes: tuple[str, ...] = ()
    created_at: datetime | None = None
    updated_at: datetime | None = None


@dataclass(frozen=True, slots=True)
class SessionState:
    session_id: str
    profile_id: str
    workspace_id: str | None
    status: str
    started_at: datetime
    updated_at: datetime
    parent_session_id: str | None = None
    interruption_state: str | None = None


@dataclass(frozen=True, slots=True)
class SessionContinuityState:
    session_id: str
    mode: str
    origin_session_id: str
    lineage_session_ids: tuple[str, ...] = ()
    inherited_interruption_state: str | None = None
    active_goal_id: str | None = None
    summary: str = ""

    @property
    def requires_recovery(self) -> bool:
        return self.mode != "foreground"


@dataclass(frozen=True, slots=True)
class ProfileGrowthState:
    profile_id: str
    growth_score: int = 0
    total_dialogues: int = 0
    total_tokens: int = 0
    total_experiences: int = 0
    promoted_experiences: int = 0
    active_days: int = 0
    streak_days: int = 0
    first_dialogue_at: datetime | None = None
    last_dialogue_at: datetime | None = None
    last_active_day: str | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None


@dataclass(frozen=True, slots=True)
class GoalNode:
    goal_id: str
    session_id: str
    title: str
    status: str
    priority: str
    dependencies: tuple[str, ...] = ()
    evidence_refs: tuple[str, ...] = ()
    owner: str | None = None
    parent_goal_id: str | None = None
    related_memory_ids: tuple[str, ...] = ()
    deadline: datetime | None = None
    time_sensitivity: str | None = None
    review_checkpoint: str | None = None
    revision_id: str | None = None
    updated_at: datetime | None = None


@dataclass(frozen=True, slots=True)
class MemoryRecord:
    memory_id: str
    session_id: str
    kind: str
    content: str
    source_event_id: str | None = None
    goal_refs: tuple[str, ...] = ()
    tags: tuple[str, ...] = ()
    created_at: datetime | None = None


@dataclass(frozen=True, slots=True)
class ExperienceRecord:
    experience_id: str
    session_id: str
    profile_id: str
    workspace_id: str | None
    kind: str
    title: str
    summary: str
    status: str
    run_id: str | None = None
    source_event_id: str | None = None
    goal_id: str | None = None
    tool_call_count: int = 0
    model_turn_count: int = 0
    related_skill_ids: tuple[str, ...] = ()
    produced_artifact_ids: tuple[str, ...] = ()
    tags: tuple[str, ...] = ()
    created_at: datetime | None = None
    updated_at: datetime | None = None


@dataclass(frozen=True, slots=True)
class ArtifactRecord:
    artifact_id: str
    session_id: str
    kind: str
    name: str
    uri: str
    checksum: str | None = None
    created_at: datetime | None = None


@dataclass(frozen=True, slots=True)
class ContextBundle:
    bundle_id: str
    session_id: str
    instruction_refs: tuple[str, ...] = ()
    goal_ids: tuple[str, ...] = ()
    memory_ids: tuple[str, ...] = ()
    artifact_ids: tuple[str, ...] = ()
    token_budget: int = 0
    rendered_prompt: str | None = None


@dataclass(frozen=True, slots=True)
class PlanStep:
    step_id: str
    title: str
    rationale: str
    dependency_refs: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class PlanDraft:
    plan_id: str
    goal_id: str
    session_id: str
    steps: tuple[PlanStep, ...] = ()
    rationale: str = ""


@dataclass(frozen=True, slots=True)
class ExecutionResult:
    execution_id: str
    session_id: str
    outcome: str
    summary: str
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0
    produced_artifact_ids: tuple[str, ...] = ()
    telemetry_event_ids: tuple[str, ...] = ()
    side_effects: tuple[str, ...] = ()
    tool_calls: tuple["ExecutionToolCall", ...] = ()


@dataclass(frozen=True, slots=True)
class ExecutionToolCall:
    tool_name: str
    arguments: dict[str, object] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class AgentRunState:
    run_id: str
    session_id: str
    source_event_id: str
    prompt: str
    status: str
    phase: str
    step_count: int
    model_turn_count: int
    tool_call_count: int
    max_model_turns: int
    max_wall_time_seconds: int
    created_at: datetime
    updated_at: datetime
    waiting_reason: str | None = None
    continuation_prompt: str | None = None
    last_summary: str | None = None


@dataclass(frozen=True, slots=True)
class AgentRunStep:
    step_id: str
    run_id: str
    session_id: str
    step_index: int
    kind: str
    title: str
    content: str
    created_at: datetime
    outcome: str | None = None
    tool_name: str | None = None


@dataclass(frozen=True, slots=True)
class EventEnvelope:
    event_id: str
    event_type: str
    session_id: str
    source: str
    payload: dict[str, str] = field(default_factory=dict)
