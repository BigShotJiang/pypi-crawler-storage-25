---
name: friend-clone-governance
skill_id: friend-clone-governance
description: Governs when and how Aegis should inspect or update FRIEND.md, CLONE.md, and companion identity without polluting durable profile state.
version: 1.0.0
source_kind: aegis-builtin
aliases: ["friend governance", "clone governance", "FRIEND.md", "CLONE.md", "identity governance"]
trigger_phrases: ["update friend.md", "update clone.md", "remember my preference", "change your tone", "persist my profile"]
keywords: ["friend", "clone", "identity", "continuity", "governance"]
category: continuity
---

# friend-clone-governance

Use this skill when the user is shaping the durable companion relationship rather than asking for a one-off task.

## Core rules

- Treat `AEGIS.md` as the immutable global charter shared by every clone.
- Use `tool.identity.manage`, `tool.user.manage`, and `tool.relationship.manage` as the canonical write surfaces.
- Use `tool.user.manage` only for stable user facts, preferences, boundaries, or recurring context that should survive future sessions.
- Use `tool.identity.manage` only when the user explicitly changes this clone's voice, posture, stance, or long-lived way of working, or asks for a durable preset/initiative change.
- Use `tool.relationship.manage` for clone-local collaboration rhythm, continuity notes, and expectations that should not be promoted to shared user truth.
- Never store transient todos, scratch notes, debugging output, or ordinary chat turns in durable self, user, or relationship state.

## FRIEND.md guidance

Prefer concise labeled lines or a `fields` object keyed by canonical field names when you know concrete stable information, such as:

- Preferred name
- Current work
- School
- Current city
- MBTI
- Dream
- Creative hobby
- Media hobby
- Movement hobby
- Boundaries

When the user corrects or adds durable identity information, update `FRIEND.md` proactively instead of waiting for a separate memory request.

## CLONE.md guidance

Only update `CLONE.md` when the user is changing how this clone should behave over time, for example:

- “be more concise with me from now on”
- “keep your tone warm but direct”
- “act more like an operator clone for release work”

Avoid rewriting `CLONE.md` for temporary task instructions that belong in the current turn or in durable goals.

## Working pattern

1. Inspect the current companion state first when uncertain.
2. Decide whether the new information belongs in `FRIEND.md`, `CLONE.md`, `identity`, or nowhere durable.
3. Persist the smallest durable delta through `tool.companion.manage`.
4. Continue the conversation naturally without turning the update into a heavy ceremony.
