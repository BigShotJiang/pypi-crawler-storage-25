<p align="center">
  <img src="apps/site/static/assets/brand/evolution-stage-0.svg" alt="Aegis growth stage 0" width="36" />
  <img src="apps/site/static/assets/brand/evolution-stage-1.svg" alt="Aegis growth stage 1" width="54" />
  <img src="apps/site/static/assets/brand/evolution-stage-2.svg" alt="Aegis growth stage 2" width="72" />
  <img src="apps/site/static/assets/brand/evolution-stage-3.svg" alt="Aegis growth stage 3" width="90" />
  <img src="apps/site/static/assets/brand/aegis-logo.png" alt="Aegis growth stage 4" width="108" />
</p>

<h1 align="center">Aegis</h1>

<p align="center">
  <strong>Your own persistent AI.</strong><br />
  An agent that remembers, reasons, and endures across time.
</p>

Aegis is building toward a personal AI agent that does not lose the thread when
a single chat ends. The goal is not just tool calling or session orchestration,
but continuity: an agent that becomes more useful as it accumulates the right
history, goals, and context.

## Positioning

Aegis is for long-running work that should survive interruption.

- It should remember what matters.
- It should reason across longer horizons than the current turn.
- It should recover the right context instead of collapsing when the window fills.

In product terms, Aegis is aiming at a persistent personal AI, not a disposable
chat session.

## Why Aegis Exists

Most current agents fail in three predictable ways:

- **Amnesia:** decisions, preferences, and project state disappear when the session ends.
- **Myopia:** current-turn optimization wins over next-week usefulness.
- **Overflow:** context windows fill up, and naive truncation replaces structured memory and retrieval.

The product thesis behind Aegis is that a useful agent should behave more like a
persistent collaborator: it should remember, plan, and recover the right
context when work resumes.

## Thesis

- **Long-term memory:** durable episodic, semantic, and procedural memory instead of session-only state.
- **Long-horizon decision making:** persistent goals, task decomposition, and deadline-aware planning.
- **Long-context understanding:** layered context management, compression, and retrieval instead of naive truncation.

## Quickstart

Aegis is used from the terminal. The path is simple: install it, run `aegis`,
let it hatch your first named clone, and continue directly into grow. Use
`aegis clone <name>` only when you want another Aegis individual, and give that
new thread its first durable goal right away.

### Install from remote

```bash
curl -fsSL https://aegis.agentic-in.ai/install.sh | bash
```

This installs the public `aegis` launcher into `~/.local/bin` and prepares the
default durable runtime under `~/.aegis`. The public installer now tracks the
latest published development package by default. If you want the latest stable
package instead:

```bash
curl -fsSL https://aegis.agentic-in.ai/install.sh | bash -s -- --channel stable
```

### Install from source

```bash
git clone https://github.com/agentic-in/aegis.git
cd aegis
bash scripts/install.sh
```

This creates a local launcher and the default durable layout:

- `AEGIS_HOME`
- `AEGIS_STATE_DIR`
- `AEGIS_GATEWAY_STATE_DIR`
- `AEGIS_PROFILE_DIR`

If `~/.local/bin` is not already on `PATH`, use the launcher path printed by the
install script directly.

### CLI overview

```bash
aegis
aegis born
aegis grow
aegis clone nova --initial-goal "Own the release readiness thread"
aegis clones
aegis health
aegis im --default-clone-id demo
aegis im doctor
aegis im start --transport long-connection --detach
aegis im status --transport long-connection
aegis im logs --transport long-connection --follow
aegis im restart --transport long-connection
aegis im add discord --account-id ops-discord --bot-token ...
aegis im discord start --transport gateway
aegis im discord doctor
aegis grow --message "Who are you?"
```

The CLI surface stays intentionally small:

- `aegis` is the default entry: on the first run it starts birth, and later it re-enters grow directly or asks which clone to open.
- `aegis born` brings the first Aegis to life, persists identity and `CLONE.md`, binds the provider path, asks for the first durable goal, hatches the first clone, and now surfaces the IM chooser before grow resumes.
- `aegis grow` is the normal way back in and enters the current live clone directly when one exists.
- `aegis grow --message "..."` runs a single turn without staying in the TUI.
- `aegis im ...` is the IM setup/runtime surface: with no extra args it opens the IM chooser, then the adapter-specific wizard, and `doctor`, `describe`, `serve`, `start`, `status`, `logs`, `stop`, and `restart` stay on the same IM command.
- `aegis health` checks whether the current companion is ready to grow.
- `aegis clone <name>` creates another named Aegis individual only when you want a second continuity line, and requires a first durable goal either from `--initial-goal` or the interactive prompt.
- `aegis clones` lists known clones.
- `aegis clones bye <name>` retires one clone.
- `aegis clones bye --all` clears every clone.
- `aegis grow --clone-id <name>` opens one clone directly.

Inside `grow`, the conversation stays primary. Slash commands such as `/status`,
`/memory`, `/goals`, `/identity`, and `/help` are there when you need to inspect
or steer continuity without leaving the session.

## Shipped Capability Overview

Aegis already ships these core runtime surfaces on `main`:

- Durable memory, planning, and context recovery backing the normal `grow` path.
- Persistent clones with isolated continuity, personality, and `CLONE.md`.
- A dedicated `aegis brain` and `/brain` surface for configuring provider, model, reasoning effort, and context window together.
- Provider onboarding and a pluggable catalog covering `openai-compatible`, `openai`, `openai-codex`, `openrouter`, `copilot`, `anthropic`, `google`, `groq`, `deepseek`, `xai`, `mistral`, `together`, `fireworks`, `moonshot`, `qwen-oauth`, `minimax`, `minimax-cn`, `zai`, `alibaba`, `huggingface`, `ai-gateway`, `opencode-zen`, `opencode-go`, `kilocode`, `ollama`, and `vllm`.
- Provider discovery now reuses configured profiles, encrypted local secrets, environment variables, local endpoint probes, and imported external auth sources such as Codex, GitHub Copilot, Qwen, and Hermes auth state.
- Provider setup and model selection now surface reasoning-effort choices for supported models instead of treating every runtime as flat chat completion.
- Built-in tools now ship as a curated runtime catalog:
<!-- BEGIN:GENERATED_BUILTIN_TOOL_SUMMARY -->
- `terminal`: `tool.terminal.exec`
- `process`: `tool.process.manage`
- `file`: `tool.file.read`, `tool.file.write`, `tool.file.patch`, `tool.file.search`
- `web`: `tool.web.search`, `tool.web.read`, `tool.web.extract`
- `browser`: `tool.browser.navigate`, `tool.browser.snapshot`, `tool.browser.click`, `tool.browser.type`, `tool.browser.scroll`, `tool.browser.back`, `tool.browser.press`, `tool.browser.images`, `tool.browser.vision`, `tool.browser.console`
- `clarify`: `tool.clarify`
- `cron`: `tool.cron.manage`
- `code_execution`: `tool.code.execute`
- `memory`: `tool.memory.manage`
- `messaging`: `tool.message.send`
- `todo`: `tool.todo.manage`
- `continuity-native`: `tool.companion.manage`, `tool.goal.manage`, `tool.skill.manage`
<!-- END:GENERATED_BUILTIN_TOOL_SUMMARY -->
- Built-in skills for shell, workspace search, web search/read, continuity, cron scheduling, and voice reply guidance.
- Local skill-hub search/install plus Aegis-authored skill creation inside the shared shelf.
- Durable agent-run checkpoints for resumable multi-step tool loops and long-horizon follow-up.

The public docs now cover the supported operator path plus the currently shipped
provider, capability, automation, and extension surfaces. Internal design docs
under `docs/system-design/` still describe the broader target architecture.
