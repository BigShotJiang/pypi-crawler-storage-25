
import json
import xml.etree.ElementTree as ET
import re
import os
from tqdm import tqdm

NEGACIONES = {'no', 'nada', 'nunca', 'jamás', 'ni', 'tampoco', 'sin'}
PUNTUACION_CORTE = {'.', ',', ';', '!', '?'}
INTENSIFICADORES = {'muy', 'demasiado', 'super', 'súper', 'extremadamente', 'bastante', 'altamente', 'totalmente', 'realmente'}
ATENUADORES = {'poco', 'algo', 'ligeramente', 'apenas', 'medio'}
CONTRASTES = {'pero', 'aunque'}
def cargar_lexico_json(path):
    print(f"[Lexicon JSON] Cargando léxico JSON: {path}...")
    try:
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        lexicon = {str(k).lower(): float(v) for k, v in data.items()}
        
        # Omitimos las negaciones
        for neg in NEGACIONES:
            if neg in lexicon:
                del lexicon[neg]
                
        print(f"[Lexicon JSON] Léxico cargado: {len(lexicon)} términos listos.")
        return lexicon
    except Exception as e:
        print(f"[Lexicon JSON] Error al leer el archivo JSON: {e}")
        return None

def LexiconJSONClasificator(texts: list) -> list:
    path_json = os.path.join(os.path.dirname(__file__), 'lexicon.json')
    
    diccionario_json = cargar_lexico_json(path_json)
    if not diccionario_json:
        print("[Lexicon JSON] Usando diccionario vacío como fallback.")
        diccionario_json = {}
        
    resultados = []
    scores = []
    
    print(f"[Lexicon JSON] Analizando {len(texts)} textos con Léxico JSON...")
    
    for texto in tqdm(texts, desc="Progreso del análisis", unit="txt"):
        s = analizar_sentimiento_avanzado(str(texto), diccionario_json)
        scores.append(s)
        
        if s > 0.5:
            resultados.append('POS')
        elif s < -0.5:
            resultados.append('NEG')
        else:
            resultados.append('NEU')

    print("[Lexicon JSON] ¡Finalizado!")
    return resultados, scores

def SentimentAnalysisSpanish(texts: list) -> list:
    print("[Sentiment Analysis Spanish] Iniciando carga de modelo...")
    from sentiment_analysis_spanish import sentiment_analysis
    
    sentiment = sentiment_analysis.SentimentAnalysisSpanish()
    
    resultados = []
    scores = []
    
    print(f"[Sentiment Analysis Spanish] Analizando {len(texts)} textos...")
    
    for texto in tqdm(texts, desc="Progreso del análisis", unit="txt"):
        try:
            raw_val = sentiment.sentiment(str(texto))
            
            # Mapear de Probabilidad (0 a 1) a Escala de Sentimiento (-1 a 1)
            # Para que -1 sea Negativo, 0 sea Neutro y 1 sea Positivo
            val_mapped = (float(raw_val) * 2.0) - 1.0
            val = round(val_mapped, 3)
            
            scores.append(val)
            
            # Clasificación usando la nueva escala (-1 a 1)
            if val > 0.1:
                resultados.append('POS')
            elif val < -0.999:
                resultados.append('NEG')
            else:
                resultados.append('NEU')
        except Exception:
            scores.append(0.0)
            resultados.append('NEU')
                
    print("[Sentiment Analysis Spanish] ¡Finalizado!")
    return resultados, scores


def cargar_bayes_json(path):
    print(f"[Naive Bayes] Cargando pesos probabilísticos: {path}...")
    try:
        with open(path, 'r', encoding='utf-8') as f:
            diccionario = json.load(f)
            print(f"[Naive Bayes] Pesos cargados: {len(diccionario)} palabras.")
            return diccionario
    except Exception as e:
        print(f"[Naive Bayes] Error al cargar pesos: {e}")
        return {}

import math

def NaiveBayesClasificator(texts: list) -> tuple:
    path_json = os.path.join(os.path.dirname(__file__), 'bayes_weights.json')
    bayes_dict = cargar_bayes_json(path_json)
    
    resultados = []
    scores = []
    
    # Probabilidades a priori (asumiendo clases balanceadas o ligeramnete sesgadas a POS)
    prior_neg = math.log(0.3)
    prior_neu = math.log(0.3)
    prior_pos = math.log(0.4)
    
    print(f"[Naive Bayes] Analizando {len(texts)} textos...")
    
    for texto in tqdm(texts, desc="Progreso del análisis", unit="txt"):
        if not isinstance(texto, str) or texto.strip() == "":
            resultados.append('NEU')
            scores.append(0.0)
            continue
            
        tokens = re.findall(r'\w+', texto.lower())
        
        log_prob_neg = prior_neg
        log_prob_neu = prior_neu
        log_prob_pos = prior_pos
        
        for t in tokens:
            if t in bayes_dict:
                probs = bayes_dict[t]
                # Sumamos el logaritmo de las probabilidades
                log_prob_neg += math.log(probs.get('neg', 0.01))
                log_prob_neu += math.log(probs.get('neu', 0.01))
                log_prob_pos += math.log(probs.get('pos', 0.01))
                
        # Calcular un score continuo acotado de -1 a 1 para la lógica difusa
        # Si la probabilidad NEU es la mayor, el score tenderá a 0
        max_log_prob = max(log_prob_neg, log_prob_neu, log_prob_pos)
        
        if log_prob_neu == max_log_prob:
            # Es puramente neutral
            score = 0.0
            resultados.append('NEU')
        elif log_prob_pos == max_log_prob:
            # Es positivo. Ponderamos qué tan positivo es respecto al neutral
            # Dif de logaritmos es el log del ratio
            ratio = min(1.0, (log_prob_pos - log_prob_neu) / 5.0) # Escalado heurístico
            score = ratio
            resultados.append('POS')
        else:
            # Es negativo.
            ratio = min(1.0, (log_prob_neg - log_prob_neu) / 5.0)
            score = -ratio
            resultados.append('NEG')
            
        scores.append(score)

    print("[Naive Bayes] ¡Finalizado!")
    return resultados, scores

def cargar_senticon_xml(path):
    print(f"[Senticon] Cargando léxico: {path}...")
    try:
        tree = ET.parse(path)
        root = tree.getroot()
    except Exception as e:
        print(f"[Senticon] Error al abrir el XML: {e}")
        return None

    lexicon = {}
    for lemma in root.iter('lemma'):
        palabra = lemma.text
        score_str = lemma.get('pol')
        
        if palabra and score_str:
            p_limpia = palabra.strip().lower()
            if p_limpia == 'no':
                continue
            lexicon[p_limpia] = float(score_str)

    print(f"[Senticon] Léxico cargado: {len(lexicon)} palabras (excluyendo 'no').")
    return lexicon

def analizar_sentimiento_avanzado(texto, diccionario):
    if not isinstance(texto, str) or texto.strip() == "":
        return 0.0
    
    tokens = re.findall(r'\w+|[.,!?;]', texto.lower())
    
    score_total = 0.0
    negacion_activa = False
    ventana_negacion = 0 
    
    multiplicador_intensidad = 1.0
    ventana_intensidad = 0
    
    multiplicador_contraste = 1.0

    for t in tokens:
        if t in CONTRASTES:
            # Lógica del "PERO": Reducir a la mitad el sentimiento anterior
            score_total *= 0.5
            # Y darle un 50% más de peso a todo lo que viene después (hasta el punto)
            multiplicador_contraste = 1.5
            continue

        if t in PUNTUACION_CORTE:
            negacion_activa = False
            ventana_negacion = 0
            multiplicador_contraste = 1.0 # El contraste se reinicia con la puntuación
            continue

        if t in NEGACIONES:
            negacion_activa = True
            ventana_negacion = 3 
            continue
            
        if t in INTENSIFICADORES:
            multiplicador_intensidad = 1.5
            ventana_intensidad = 2
            continue
            
        if t in ATENUADORES:
            multiplicador_intensidad = 0.5
            ventana_intensidad = 2
            continue

        if t in diccionario:
            valor = diccionario[t]
            
            # Aplicar negación
            if negacion_activa and ventana_negacion > 0:
                valor *= -1.0
                ventana_negacion -= 1
                
            # Aplicar intensificadores/atenuadores
            if ventana_intensidad > 0:
                valor *= multiplicador_intensidad
                ventana_intensidad -= 1
                
            # Aplicar contraste
            valor *= multiplicador_contraste
            
            score_total += valor
        
        # Limpiar ventanas si se acaban
        if ventana_negacion == 0:
            negacion_activa = False
        if ventana_intensidad == 0:
            multiplicador_intensidad = 1.0
            
    return score_total

def SenticonClasificator(texts: list, C=True) -> list:
    # Buscar el XML siempre dentro de la misma carpeta donde está instalado este script
    path_xml = os.path.join(os.path.dirname(__file__), 'senticon.es.xml')
            
    senticon_dict = cargar_senticon_xml(path_xml)
    if not senticon_dict:
        print("[Senticon] Usando diccionario vacío como fallback.")
        senticon_dict = {}
        
    resultados = []
    scores = []
    
    print(f"[Senticon] Analizando {len(texts)} textos con lógica de negación...")
    
    for texto in tqdm(texts, desc="Progreso del análisis", unit="txt"):
        s = analizar_sentimiento_avanzado(str(texto), senticon_dict)
        scores.append(s)
        
        if s > 0.1:
            resultados.append('POS')
        elif s < -0.1:
            resultados.append('NEG')
        else:
            resultados.append('NEU')

    print("[Senticon] ¡Finalizado!")
    return resultados, scores
