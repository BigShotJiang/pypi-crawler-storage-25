from .Twotuples import LexiconJSONClasificator, SentimentAnalysisSpanish, SenticonClasificator, NaiveBayesClasificator, difuso_clasificator, Metric

