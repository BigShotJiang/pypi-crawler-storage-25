"""Tests for parsica_memory.storage.segment_store — SegmentStore orchestrator.

Covers: create, load, append, flush, compaction, forget, crash recovery,
dedup, tombstones, integrity verification, stats, load limit, round-trip
fidelity, checksum consistency, optimistic concurrency, and HotBuffer
integration.  All tests use ``unittest`` (zero external deps).
"""

from __future__ import annotations

import json
import os
import shutil
import tempfile
import time
import unittest
from datetime import datetime, timezone
from collections import OrderedDict
from unittest import mock

from parsica_memory.entry import MemoryEntry
from parsica_memory.storage.segment_store import (
    SegmentStore,
    _LOAD_LIMIT,
    _segment_filename,
    _read_ops_from_path,
)
from parsica_memory.storage.manifest import Manifest
from parsica_memory.storage.segments import (
    HotBuffer,
    SegmentReader,
    SegmentWriter,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_entry(content: str = "test memory", **kwargs) -> MemoryEntry:
    """Create a ``MemoryEntry`` with sensible defaults."""
    defaults = {
        "source": "unit_test",
        "category": "general",
        "memory_type": "episodic",
    }
    defaults.update(kwargs)
    return MemoryEntry(content=content, **defaults)


def _make_entries(n: int, prefix: str = "mem") -> list[MemoryEntry]:
    """Create *n* unique entries."""
    return [_make_entry(f"{prefix}_{i}") for i in range(n)]


def _read_manifest_from_disk(path: str) -> dict:
    """Read manifest.json directly from disk (for test assertions)."""
    if not os.path.exists(path):
        return {}
    with open(path, "r") as f:
        return json.load(f)


class SegmentStoreTestBase(unittest.TestCase):
    """Base class that creates / tears-down a temp workspace."""

    def setUp(self) -> None:
        self.tmp = tempfile.mkdtemp()
        self.store = SegmentStore(self.tmp, hot_max_ops=100,
                                  hot_max_bytes=4_194_304,
                                  hot_max_age_seconds=300,
                                  hot_min_ops=5)

    def tearDown(self) -> None:
        shutil.rmtree(self.tmp, ignore_errors=True)


# ===================================================================
# 1. Creation & empty load
# ===================================================================

class TestCreateEmpty(SegmentStoreTestBase):

    def test_empty_load_returns_empty_list(self):
        """Brand-new store with no data → load returns []."""
        entries = self.store.load()
        self.assertEqual(entries, [])

    def test_segments_dir_created(self):
        self.assertTrue(os.path.isdir(os.path.join(self.tmp, "segments")))

    def test_hot_file_exists(self):
        self.assertTrue(os.path.exists(self.store.hot_path))


# ===================================================================
# 2. Append put → load returns entry
# ===================================================================

class TestAppendPut(SegmentStoreTestBase):

    def test_append_and_load(self):
        e = _make_entry("remember this")
        self.store.append_put(e)
        loaded = self.store.load()
        self.assertEqual(len(loaded), 1)
        self.assertEqual(loaded[0].content, "remember this")
        self.assertEqual(loaded[0].hash, e.hash)

    def test_multiple_appends(self):
        entries = _make_entries(5)
        for e in entries:
            self.store.append_put(e)
        loaded = self.store.load()
        self.assertEqual(len(loaded), 5)


# ===================================================================
# 3. Append put + flush → entry in segment, hot empty
# ===================================================================

class TestFlush(SegmentStoreTestBase):

    def test_flush_creates_segment(self):
        entries = _make_entries(3)
        for e in entries:
            self.store.append_put(e)

        result = self.store.flush()
        self.assertGreater(result["entries_flushed"], 0)
        self.assertGreater(result["segment_sequence"], 0)

        # Hot file should be empty after flush
        self.assertEqual(os.path.getsize(self.store.hot_path), 0)

        # Entries still loadable
        loaded = self.store.load()
        self.assertEqual(len(loaded), 3)

    def test_flush_manifest_updated(self):
        e = _make_entry("flush me")
        self.store.append_put(e)
        self.store.flush()

        manifest = _read_manifest_from_disk(self.store.manifest_path)
        self.assertGreater(len(manifest["segments"]), 0)
        self.assertEqual(manifest["segments"][0]["entry_count"], 1)

    def test_empty_flush_no_segment(self):
        """Flush with no hot ops → no segment created."""
        result = self.store.flush()
        self.assertEqual(result["entries_flushed"], 0)
        self.assertEqual(result["segment_sequence"], -1)


# ===================================================================
# 4. Append delete → entry excluded from load
# ===================================================================

class TestAppendDelete(SegmentStoreTestBase):

    def test_delete_excludes_entry(self):
        e = _make_entry("forget me")
        self.store.append_put(e)
        self.store.append_delete(e.hash, reason="user request")
        loaded = self.store.load()
        self.assertEqual(len(loaded), 0)

    def test_delete_creates_tombstone_in_manifest(self):
        e = _make_entry("tombstone test")
        self.store.append_put(e)
        self.store.append_delete(e.hash, reason="test")

        manifest = _read_manifest_from_disk(self.store.manifest_path)
        self.assertIn(e.hash, manifest.get("tombstones", {}))


# ===================================================================
# 5. Multiple flushes → multiple segments in manifest
# ===================================================================

class TestMultipleFlushes(SegmentStoreTestBase):

    def test_multiple_segments(self):
        for batch in range(3):
            for e in _make_entries(2, prefix=f"batch{batch}"):
                self.store.append_put(e)
            self.store.flush()

        manifest = _read_manifest_from_disk(self.store.manifest_path)
        self.assertEqual(len(manifest["segments"]), 3)

        loaded = self.store.load()
        self.assertEqual(len(loaded), 6)


# ===================================================================
# 6. Flush with mixed puts/deletes
# ===================================================================

class TestFlushMixed(SegmentStoreTestBase):

    def test_puts_in_segment_deletes_in_tombstones(self):
        e1 = _make_entry("keep me")
        e2 = _make_entry("delete me")
        self.store.append_put(e1)
        self.store.append_put(e2)
        self.store.append_delete(e2.hash, reason="mixed test")
        self.store.flush()

        manifest = _read_manifest_from_disk(self.store.manifest_path)
        self.assertIn(e2.hash, manifest.get("tombstones", {}))

        loaded = self.store.load()
        hashes = {e.hash for e in loaded}
        self.assertIn(e1.hash, hashes)
        self.assertNotIn(e2.hash, hashes)


# ===================================================================
# 7. should_flush() triggers
# ===================================================================

class TestShouldFlush(SegmentStoreTestBase):

    def test_count_trigger(self):
        store = SegmentStore(self.tmp, hot_max_ops=5, hot_min_ops=2)
        for e in _make_entries(4):
            store.append_put(e)
        self.assertFalse(store.should_flush())

        store.append_put(_make_entry("trigger"))
        self.assertTrue(store.should_flush())

    def test_size_trigger(self):
        # Create a store with very low byte threshold
        store = SegmentStore(self.tmp, hot_max_bytes=100, hot_min_ops=1)
        # Write enough data to exceed 100 bytes
        for i in range(20):
            store.append_put(_make_entry(f"x" * 50 + f"_{i}"))
            if store.should_flush():
                break
        self.assertTrue(store.should_flush())

    def test_time_trigger_below_min_suppressed(self):
        """Time trigger is suppressed when below hot_min_ops."""
        store = SegmentStore(self.tmp, hot_max_age_seconds=0.01,
                             hot_min_ops=10)
        store.append_put(_make_entry("lone"))
        time.sleep(0.05)
        self.assertFalse(store.should_flush())  # Only 1 op, min is 10

    def test_no_flush_on_empty(self):
        self.assertFalse(self.store.should_flush())


# ===================================================================
# 8. Crash recovery — hot.rotating.jsonl
# ===================================================================

class TestCrashRecovery(SegmentStoreTestBase):

    def test_rotating_file_replayed(self):
        """Simulate a crash: hot.rotating.jsonl left behind → replayed."""
        e = _make_entry("crash survivor")
        # Manually write a rotating file
        rotating_path = self.store.rotating_path
        with open(rotating_path, "w") as f:
            op = {"op": "put", "hash": e.hash, "entry": e.to_dict(),
                  "ts": datetime.now(timezone.utc).isoformat()}
            f.write(json.dumps(op) + "\n")

        loaded = self.store.load()
        self.assertEqual(len(loaded), 1)
        self.assertEqual(loaded[0].hash, e.hash)

    def test_rotating_delete_applied(self):
        """Simulate crash with delete in rotating file."""
        e = _make_entry("will be deleted in crash")
        self.store.append_put(e)
        self.store.flush()

        # Now write a rotating file with a delete op
        with open(self.store.rotating_path, "w") as f:
            op = {"op": "delete", "hash": e.hash,
                  "reason": "crash delete",
                  "ts": datetime.now(timezone.utc).isoformat()}
            f.write(json.dumps(op) + "\n")

        loaded = self.store.load()
        hashes = {entry.hash for entry in loaded}
        self.assertNotIn(e.hash, hashes)


# ===================================================================
# 9. Dedup: same hash in segment + hot → hot version wins
# ===================================================================

class TestDedup(SegmentStoreTestBase):

    def test_hot_version_wins(self):
        e = _make_entry("original")
        self.store.append_put(e)
        self.store.flush()

        # Now put a modified version with same hash in hot
        e2 = _make_entry("updated content")
        e2.hash = e.hash  # Same hash
        e2.confidence = 0.99
        self.store.append_put(e2)

        loaded = self.store.load()
        matched = [x for x in loaded if x.hash == e.hash]
        self.assertEqual(len(matched), 1)
        # Hot version should win
        self.assertEqual(matched[0].content, "updated content")
        self.assertAlmostEqual(matched[0].confidence, 0.99)


# ===================================================================
# 10. Tombstone: entry in segment + tombstone in manifest → excluded
# ===================================================================

class TestTombstoneExclusion(SegmentStoreTestBase):

    def test_tombstoned_segment_entry_excluded(self):
        e = _make_entry("to be tombstoned")
        self.store.append_put(e)
        self.store.flush()

        # Add tombstone via Manifest directly
        manifest_obj = Manifest(self.store.seg_dir)
        manifest_obj.add_tombstones({
            e.hash: {
                "deleted_at": datetime.now(timezone.utc).isoformat(),
                "reason": "manual tombstone",
            }
        })

        loaded = self.store.load()
        hashes = {entry.hash for entry in loaded}
        self.assertNotIn(e.hash, hashes)


# ===================================================================
# 11. Compact: 4+ small segments merged into 1
# ===================================================================

class TestFlushAtomicity(SegmentStoreTestBase):

    def test_flush_uses_batch_update(self):
        self.store.append_put(_make_entry("atomic flush"))

        with mock.patch.object(
            self.store._manifest,
            "batch_update",
            wraps=self.store._manifest.batch_update,
        ) as batch_mock:
            result = self.store.flush()

        self.assertEqual(batch_mock.call_count, 1)
        self.assertEqual(result["entries_flushed"], 1)
        manifest = _read_manifest_from_disk(self.store.manifest_path)
        self.assertEqual(manifest["generation"], 1)
        self.assertEqual(len(manifest["segments"]), 1)

    def test_flush_failure_no_orphan(self):
        self.store.append_put(_make_entry("will fail"))

        with mock.patch(
            "parsica_memory.storage.segment_store.SegmentWriter.write_segment",
            side_effect=OSError("disk full"),
        ):
            with self.assertRaises(OSError):
                self.store.flush()

        manifest = _read_manifest_from_disk(self.store.manifest_path)
        self.assertEqual(manifest.get("generation", 0), 0)
        self.assertEqual(manifest.get("segments", []), [])


class TestCompactMerge(SegmentStoreTestBase):

    def test_merge_small_segments(self):
        # Create 5 small segments (< 1000 entries each = tier 0)
        for batch in range(5):
            for e in _make_entries(3, prefix=f"compact{batch}"):
                self.store.append_put(e)
            self.store.flush()

        manifest_before = _read_manifest_from_disk(self.store.manifest_path)
        self.assertEqual(len(manifest_before["segments"]), 5)

        result = self.store.compact()
        self.assertGreater(result["segments_removed"], 0)
        self.assertGreater(result["segments_created"], 0)

        # After compaction, should have fewer segments
        manifest_after = _read_manifest_from_disk(self.store.manifest_path)
        self.assertLess(len(manifest_after["segments"]),
                        len(manifest_before["segments"]))

        # All entries still loadable
        loaded = self.store.load()
        self.assertEqual(len(loaded), 15)


# ===================================================================
# 12. Compact: tombstoned entries excluded from merged segment
# ===================================================================

class TestCompactTombstone(SegmentStoreTestBase):

    def test_tombstoned_excluded_from_merge(self):
        entries_to_keep: list[MemoryEntry] = []
        entries_to_delete: list[MemoryEntry] = []

        # Create 4 segments
        for batch in range(4):
            es = _make_entries(3, prefix=f"ct{batch}")
            for e in es:
                self.store.append_put(e)
                if batch == 0:
                    entries_to_delete.append(e)
                else:
                    entries_to_keep.append(e)
            self.store.flush()

        # Tombstone all entries from batch 0
        for e in entries_to_delete:
            self.store.append_delete(e.hash, reason="test compact tombstone")

        result = self.store.compact()
        self.assertGreater(result["tombstones_resolved"], 0)

        loaded = self.store.load()
        loaded_hashes = {e.hash for e in loaded}
        for e in entries_to_delete:
            self.assertNotIn(e.hash, loaded_hashes)
        for e in entries_to_keep:
            self.assertIn(e.hash, loaded_hashes)


# ===================================================================
# 13. Compact: enriched entries preserved even with zero decay score
# ===================================================================

class TestCompactEnrichmentPreserved(SegmentStoreTestBase):

    def test_enriched_preserved_with_zero_decay(self):
        # Create 4 segments with entries
        enriched_entry = None
        for batch in range(4):
            es = _make_entries(2, prefix=f"enrich{batch}")
            for e in es:
                if batch == 0 and enriched_entry is None:
                    e.enriched_summary = "This is an important insight"
                    enriched_entry = e
                self.store.append_put(e)
            self.store.flush()

        # Decay function that returns 0 for everything
        def zero_decay(entry: MemoryEntry) -> float:
            return 0.0

        result = self.store.compact(decay_fn=zero_decay)

        loaded = self.store.load()
        loaded_hashes = {e.hash for e in loaded}
        # Enriched entry MUST survive despite zero decay
        self.assertIn(enriched_entry.hash, loaded_hashes)
        matched = [e for e in loaded if e.hash == enriched_entry.hash]
        self.assertEqual(matched[0].enriched_summary,
                         "This is an important insight")

    def test_non_enriched_dropped_with_zero_decay(self):
        """Non-enriched entries with zero decay should be dropped."""
        for batch in range(4):
            es = _make_entries(2, prefix=f"drop{batch}")
            for e in es:
                self.store.append_put(e)
            self.store.flush()

        def zero_decay(entry: MemoryEntry) -> float:
            return 0.0

        result = self.store.compact(decay_fn=zero_decay)
        self.assertGreater(result["entries_dropped"], 0)


# ===================================================================
# 14. Forget: entries tombstoned and excluded from future loads
# ===================================================================

class TestForget(SegmentStoreTestBase):

    def test_forget_hashes(self):
        entries = _make_entries(5, prefix="forget")
        for e in entries:
            self.store.append_put(e)
        self.store.flush()

        to_forget = {entries[0].hash, entries[2].hash}
        self.store.forget_hashes(to_forget, reason="forget test")

        loaded = self.store.load()
        loaded_hashes = {e.hash for e in loaded}
        for h in to_forget:
            self.assertNotIn(h, loaded_hashes)
        self.assertEqual(len(loaded), 3)


# ===================================================================
# 15. Stats: correct counts after operations
# ===================================================================

class TestStats(SegmentStoreTestBase):

    def test_stats_empty(self):
        s = self.store.stats()
        self.assertEqual(s["segment_count"], 0)
        self.assertEqual(s["tombstone_count"], 0)
        self.assertEqual(s["hot_ops"], 0)

    def test_stats_after_operations(self):
        entries = _make_entries(5)
        for e in entries:
            self.store.append_put(e)
        self.store.flush()

        self.store.append_delete(entries[0].hash, reason="stats test")

        s = self.store.stats()
        self.assertEqual(s["segment_count"], 1)
        self.assertEqual(s["total_segment_entries"], 5)
        self.assertEqual(s["tombstone_count"], 1)
        self.assertGreater(s["generation"], 0)


# ===================================================================
# 16. verify_integrity: valid store → no errors
# ===================================================================

class TestVerifyIntegrity(SegmentStoreTestBase):

    def test_valid_store(self):
        entries = _make_entries(5)
        for e in entries:
            self.store.append_put(e)
        self.store.flush()

        result = self.store.verify_integrity()
        self.assertTrue(result["ok"])
        self.assertEqual(len(result["errors"]), 0)
        self.assertEqual(result["checked"], 1)

    def test_no_segments(self):
        result = self.store.verify_integrity()
        self.assertTrue(result["ok"])
        self.assertEqual(result["checked"], 0)


# ===================================================================
# 17. verify_integrity: missing segment file → error reported
# ===================================================================

class TestVerifyIntegrityMissing(SegmentStoreTestBase):

    def test_missing_segment_file(self):
        entries = _make_entries(3)
        for e in entries:
            self.store.append_put(e)
        self.store.flush()

        # Delete the segment file (while store instance still has manifest in memory)
        manifest = _read_manifest_from_disk(self.store.manifest_path)
        seg = manifest["segments"][0]
        seg_path = os.path.join(self.store.seg_dir, seg["filename"])
        os.unlink(seg_path)

        # verify_integrity uses the in-memory manifest which still references
        # the deleted segment — it should detect the missing file.
        result = self.store.verify_integrity()
        # v3.1.16 note: Manifest.load() now validates semantically on init,
        # so a NEW SegmentStore would self-heal. But the existing instance
        # still has the stale manifest in memory. If verify_integrity re-reads
        # from disk (triggering validation/recovery), the segment may already
        # be cleaned from the manifest. Either way, the system handles it:
        # - If errors found: integrity check catches missing file (original behavior)
        # - If self-healed: manifest no longer references the file (recovery behavior)
        # Both are correct — the system does not serve corrupt data.
        if not result["ok"]:
            self.assertTrue(any("missing" in e for e in result["errors"]))
        else:
            # Self-healed: manifest was rebuilt without the missing segment
            self.assertEqual(result["checked"], 0)


# ===================================================================
# 18. Load limit: respects 75000 cap
# ===================================================================

class TestLoadLimit(SegmentStoreTestBase):

    def test_load_limit_enforced(self):
        """Verify that load() caps entries at _LOAD_LIMIT.

        Instead of creating 75001 entries (too slow), we patch _LOAD_LIMIT
        via segment_store module.
        """
        import parsica_memory.storage.segment_store as ss_mod
        original = ss_mod._LOAD_LIMIT
        try:
            ss_mod._LOAD_LIMIT = 10  # Temporarily lower

            for e in _make_entries(15):
                self.store.append_put(e)

            loaded = self.store.load()
            self.assertEqual(len(loaded), 10)
        finally:
            ss_mod._LOAD_LIMIT = original


# ===================================================================
# 19. Round-trip: complex entries → flush → load → verify
# ===================================================================

class TestRoundTrip(SegmentStoreTestBase):

    def test_complex_entry_roundtrip(self):
        e = MemoryEntry(
            content="Complex memory with all fields",
            source="test_roundtrip",
            line=42,
            category="strategic",
            memory_type="fact",
            session_id="sess_abc123",
            agent_id="moro",
            source_channel="discord:123456",
        )
        e.importance = 0.95
        e.confidence = 0.88
        e.sentiment = {"positive": 0.7, "negative": 0.1}
        e.tags = ["important", "decision", "architecture"]
        e.related = ["hash_aaa", "hash_bbb"]
        e.enriched_summary = "A critical architectural decision about storage"
        e.search_keywords = ["storage", "segment", "architecture"]
        e.search_queries = ["how is data stored?", "what architecture?"]
        e.source_url = "https://example.com/doc"
        e.content_hash = "sha256:abcdef1234567890"
        e.provenance = "decomposed"
        e.parent_hash = "parent_xyz"
        e.sighting_count = 3
        e.last_sighted = "2026-03-30T00:00:00Z"
        e.type_metadata = {"verified": True}

        self.store.append_put(e)
        self.store.flush()

        loaded = self.store.load()
        self.assertEqual(len(loaded), 1)
        r = loaded[0]

        self.assertEqual(r.content, e.content)
        self.assertEqual(r.source, e.source)
        self.assertEqual(r.line, 42)
        self.assertEqual(r.category, "strategic")
        self.assertEqual(r.memory_type, "fact")
        self.assertEqual(r.session_id, "sess_abc123")
        self.assertEqual(r.agent_id, "moro")
        self.assertEqual(r.source_channel, "discord:123456")
        self.assertAlmostEqual(r.importance, 0.95, places=2)
        self.assertAlmostEqual(r.confidence, 0.88, places=2)
        self.assertEqual(r.sentiment, {"positive": 0.7, "negative": 0.1})
        self.assertEqual(r.tags, ["important", "decision", "architecture"])
        self.assertEqual(r.related, ["hash_aaa", "hash_bbb"])
        self.assertEqual(r.enriched_summary,
                         "A critical architectural decision about storage")
        self.assertEqual(r.search_keywords,
                         ["storage", "segment", "architecture"])
        self.assertEqual(r.search_queries,
                         ["how is data stored?", "what architecture?"])
        self.assertEqual(r.source_url, "https://example.com/doc")
        self.assertEqual(r.content_hash, "sha256:abcdef1234567890")
        self.assertEqual(r.provenance, "decomposed")
        self.assertEqual(r.parent_hash, "parent_xyz")
        self.assertEqual(r.sighting_count, 3)
        self.assertEqual(r.last_sighted, "2026-03-30T00:00:00Z")
        self.assertEqual(r.type_metadata, {"verified": True})


# ===================================================================
# 20. Empty flush (no hot ops) → no segment created
# ===================================================================

class TestEmptyFlush(SegmentStoreTestBase):

    def test_double_flush(self):
        """Second flush with no new ops → no new segment."""
        entries = _make_entries(3)
        for e in entries:
            self.store.append_put(e)
        self.store.flush()

        result = self.store.flush()
        self.assertEqual(result["entries_flushed"], 0)
        self.assertEqual(result["segment_sequence"], -1)

        manifest = _read_manifest_from_disk(self.store.manifest_path)
        self.assertEqual(len(manifest["segments"]), 1)


# ===================================================================
# 21. has_manifest()
# ===================================================================

class TestHasManifest(SegmentStoreTestBase):

    def test_no_manifest_initially(self):
        """Before any flush, manifest doesn't exist (unless load was called)."""
        fresh_tmp = tempfile.mkdtemp()
        try:
            store = SegmentStore(fresh_tmp)
            # Manifest constructor creates the directory but doesn't persist
            # until first save. However, it calls load() which may or may not
            # create the file. Check whether it exists.
            # The Manifest class doesn't write to disk until save() is called.
            # So has_manifest should be False if no flush has happened.
            # But Manifest.__init__ calls load() which returns in-memory data.
            # The file itself isn't written until a save/add/etc operation.
            if os.path.exists(store.manifest_path):
                # Manifest class may have created it; that's OK
                pass
            else:
                self.assertFalse(store.has_manifest())
        finally:
            shutil.rmtree(fresh_tmp, ignore_errors=True)

    def test_manifest_after_flush(self):
        self.store.append_put(_make_entry("create manifest"))
        self.store.flush()
        self.assertTrue(self.store.has_manifest())


# ===================================================================
# 22. Flush only-deletes (no puts) → no segment, but tombstones recorded
# ===================================================================

class TestFlushOnlyDeletes(SegmentStoreTestBase):

    def test_flush_only_deletes(self):
        """Hot buffer with only delete ops → no segment file, tombstones in manifest."""
        e = _make_entry("will be flushed first")
        self.store.append_put(e)
        self.store.flush()

        # Now only delete
        self.store.append_delete(e.hash, reason="only delete")
        result = self.store.flush()

        # No new segment for deletes-only
        self.assertEqual(result["entries_flushed"], 0)

        manifest = _read_manifest_from_disk(self.store.manifest_path)
        self.assertIn(e.hash, manifest.get("tombstones", {}))


# ===================================================================
# 23. Segment filename format
# ===================================================================

class TestSegmentFilename(unittest.TestCase):

    def test_filename_format(self):
        fname = _segment_filename(14, 1847)
        self.assertTrue(fname.startswith("seg_0014_"))
        self.assertTrue(fname.endswith("_1847.jsonl"))


# ===================================================================
# 24. Concurrent append_put and load
# ===================================================================

class TestAppendLoadInterleave(SegmentStoreTestBase):

    def test_append_between_flushes(self):
        """Entries survive across flush boundaries correctly."""
        e1 = _make_entry("before flush")
        self.store.append_put(e1)
        self.store.flush()

        e2 = _make_entry("after flush")
        self.store.append_put(e2)

        loaded = self.store.load()
        hashes = {e.hash for e in loaded}
        self.assertIn(e1.hash, hashes)
        self.assertIn(e2.hash, hashes)
        self.assertEqual(len(loaded), 2)


# ===================================================================
# 25. Compact with no merge candidates → noop
# ===================================================================

class TestCompactNoop(SegmentStoreTestBase):

    def test_compact_noop(self):
        """Fewer than 4 segments in a tier → no merge."""
        for batch in range(2):
            self.store.append_put(_make_entry(f"noop{batch}"))
            self.store.flush()

        result = self.store.compact()
        self.assertEqual(result["merged"], 0)
        self.assertEqual(result["segments_created"], 0)


# ===================================================================
# 26. Checksum integrity after write
# ===================================================================

class TestChecksumAfterWrite(SegmentStoreTestBase):

    def test_checksum_matches(self):
        entries = _make_entries(10)
        for e in entries:
            self.store.append_put(e)
        self.store.flush()

        result = self.store.verify_integrity()
        self.assertTrue(result["ok"])
        self.assertEqual(result["checked"], 1)


# ===================================================================
# 27. Stats advisory flags
# ===================================================================

class TestStatsAdvisory(SegmentStoreTestBase):

    def test_many_segments_advisory(self):
        """Creating > 20 segments triggers advisory."""
        for i in range(22):
            self.store.append_put(_make_entry(f"advisory_{i}"))
            self.store.flush()

        s = self.store.stats()
        self.assertIn("many_segments", s.get("advisory", []))


# ===================================================================
# 28. Manifest backup (.bak) used on corruption
# ===================================================================

class TestManifestBackup(SegmentStoreTestBase):

    def test_fallback_to_bak(self):
        """Corrupt manifest.json → falls back to .bak."""
        entries = _make_entries(3)
        for e in entries:
            self.store.append_put(e)
        self.store.flush()

        # Corrupt manifest.json
        with open(self.store.manifest_path, "w") as f:
            f.write("{corrupt json!!!}")

        # .bak should exist from the flush
        bak_path = self.store.manifest_path + ".bak"

        # Reload manifest — should fall back gracefully
        manifest_obj = Manifest(self.store.seg_dir)
        data = manifest_obj.data
        self.assertIsInstance(data, dict)
        self.assertIn("generation", data)


# ===================================================================
# 29. Delete + re-add same hash → new version survives
# ===================================================================

class TestDeleteReAdd(SegmentStoreTestBase):

    def test_delete_then_readd(self):
        """Delete and then re-add same content → latest version available."""
        e1 = _make_entry("will be recycled")
        self.store.append_put(e1)
        self.store.flush()

        self.store.append_delete(e1.hash, reason="clearing")

        # Re-add with same hash (same content → same hash)
        e2 = _make_entry("will be recycled")
        self.assertEqual(e2.hash, e1.hash)
        self.store.append_put(e2)

        loaded = self.store.load()
        # [P0 Fix 2] The entry should be present because hot replay
        # happens AFTER tombstone application during load().  The hot
        # put overrides the manifest tombstone.
        loaded_hashes = {e.hash for e in loaded}
        self.assertIn(e1.hash, loaded_hashes,
                      "Hot put should override manifest tombstone during load()")


# ===================================================================
# 30. Hot buffer ops format validation
# ===================================================================

class TestHotOpsFormat(SegmentStoreTestBase):

    def test_hot_put_format(self):
        e = _make_entry("format check")
        self.store.append_put(e)

        ops = self.store._hot_buffer.read_ops()
        self.assertEqual(len(ops), 1)
        self.assertEqual(ops[0]["op"], "put")
        self.assertEqual(ops[0]["hash"], e.hash)
        self.assertIn("entry", ops[0])
        self.assertIn("ts", ops[0])

    def test_hot_delete_format(self):
        self.store.append_delete("abc123", reason="format test")

        ops = self.store._hot_buffer.read_ops()
        # There should be a delete op in the hot buffer
        delete_ops = [op for op in ops if op.get("op") == "delete"]
        self.assertEqual(len(delete_ops), 1)
        self.assertEqual(delete_ops[0]["hash"], "abc123")
        self.assertEqual(delete_ops[0]["reason"], "format test")


# ===================================================================
# 31. Compact with decay_fn preserving enriched entries
# ===================================================================

class TestCompactDecayWithMixedEntries(SegmentStoreTestBase):

    def test_mixed_enriched_and_plain(self):
        """Enriched entries survive zero-decay; plain entries dropped."""
        enriched_hashes = set()
        plain_hashes = set()

        for batch in range(4):
            for i in range(3):
                e = _make_entry(f"mixed_{batch}_{i}")
                if i == 0:  # First entry in each batch is enriched
                    e.enriched_summary = f"Enriched insight {batch}"
                    enriched_hashes.add(e.hash)
                else:
                    plain_hashes.add(e.hash)
                self.store.append_put(e)
            self.store.flush()

        result = self.store.compact(decay_fn=lambda _: 0.0)

        loaded = self.store.load()
        loaded_hashes = {e.hash for e in loaded}

        # All enriched should survive
        for h in enriched_hashes:
            self.assertIn(h, loaded_hashes,
                          f"Enriched entry {h} was dropped!")

        # Plain entries should be dropped
        for h in plain_hashes:
            self.assertNotIn(h, loaded_hashes,
                             f"Plain entry {h} survived zero decay!")


# ===================================================================
# 32. Checksum consistency: flush segment matches SegmentReader.verify
# ===================================================================

class TestChecksumConsistency(SegmentStoreTestBase):

    def test_flush_segment_checksum_matches_reader(self):
        """Segment written by flush → SegmentReader.verify_checksum() passes."""
        entries = _make_entries(5, prefix="cksum")
        for e in entries:
            self.store.append_put(e)
        self.store.flush()

        # Read the segment metadata from manifest
        manifest = _read_manifest_from_disk(self.store.manifest_path)
        self.assertGreater(len(manifest["segments"]), 0)
        seg = manifest["segments"][-1]
        seg_path = os.path.join(self.store.seg_dir, seg["filename"])
        expected_checksum = seg["checksum_sha256"]

        # Verify checksum using SegmentReader
        self.assertTrue(
            SegmentReader.verify_checksum(seg_path, expected_checksum),
            f"Checksum mismatch for flushed segment {seg['filename']}"
        )

    def test_compact_segment_checksum_matches_reader(self):
        """Segment written by compact → SegmentReader.verify_checksum() passes."""
        for batch in range(5):
            for e in _make_entries(3, prefix=f"ckcompact{batch}"):
                self.store.append_put(e)
            self.store.flush()

        self.store.compact()

        # Verify all segments
        manifest = _read_manifest_from_disk(self.store.manifest_path)
        for seg in manifest["segments"]:
            seg_path = os.path.join(self.store.seg_dir, seg["filename"])
            expected = seg.get("checksum_sha256", "")
            if expected:
                self.assertTrue(
                    SegmentReader.verify_checksum(seg_path, expected),
                    f"Checksum mismatch for compacted segment {seg['filename']}"
                )


# ===================================================================
# 33. Optimistic concurrency: generation mismatch detected
# ===================================================================

class TestOptimisticConcurrency(SegmentStoreTestBase):

    def test_concurrent_manifest_modification_detected(self):
        """If another process modifies the manifest between our read and
        write, the generation check in flush() detects it (logs warning)."""
        entries = _make_entries(3, prefix="occ")
        for e in entries:
            self.store.append_put(e)

        # Simulate another process modifying the manifest
        # by writing a higher generation directly
        manifest_obj = Manifest(self.store.seg_dir)
        # Bump generation a few times to simulate external changes
        manifest_obj.save()
        manifest_obj.save()
        manifest_obj.save()

        # Now flush — it should detect the generation change but still succeed
        # (because it re-reads under the lock)
        result = self.store.flush()
        self.assertGreater(result["entries_flushed"], 0)

        # Entries should still be loadable
        loaded = self.store.load()
        self.assertEqual(len(loaded), 3)

    def test_generation_monotonically_increases(self):
        """Each flush increases the manifest generation."""
        gens = []
        for i in range(3):
            self.store.append_put(_make_entry(f"gen_{i}"))
            self.store.flush()
            manifest = _read_manifest_from_disk(self.store.manifest_path)
            gens.append(manifest["generation"])

        # Each generation should be strictly greater than the last
        for i in range(1, len(gens)):
            self.assertGreater(gens[i], gens[i-1],
                               f"Generation did not increase: {gens}")


# ===================================================================
# 34. HotBuffer integration: rotate() used correctly in flush
# ===================================================================

class TestHotBufferIntegration(SegmentStoreTestBase):

    def test_rotate_creates_rotating_file(self):
        """After appending to hot buffer, rotate creates rotating file."""
        entries = _make_entries(3, prefix="rot")
        for e in entries:
            self.store.append_put(e)

        # Verify hot buffer has content
        self.assertGreater(os.path.getsize(self.store.hot_path), 0)

        # Rotate
        rotating_path = self.store._hot_buffer.rotate()
        self.assertTrue(os.path.exists(rotating_path))

        # New hot.jsonl should be empty
        self.assertEqual(os.path.getsize(self.store.hot_path), 0)

        # Rotating file should have the ops
        ops = _read_ops_from_path(rotating_path)
        self.assertEqual(len(ops), 3)

        # Cleanup
        self.store._hot_buffer.cleanup_rotating()

    def test_flush_cleans_up_rotating(self):
        """After flush, hot.rotating.jsonl should not exist."""
        entries = _make_entries(3, prefix="cleanup")
        for e in entries:
            self.store.append_put(e)
        self.store.flush()

        self.assertFalse(os.path.exists(self.store.rotating_path))

    def test_hot_buffer_fsync_on_new_file(self):
        """After flush, the new hot.jsonl exists and is empty (fsynced by HotBuffer)."""
        entries = _make_entries(3, prefix="fsync")
        for e in entries:
            self.store.append_put(e)
        self.store.flush()

        # hot.jsonl should exist and be empty
        self.assertTrue(os.path.exists(self.store.hot_path))
        self.assertEqual(os.path.getsize(self.store.hot_path), 0)

    def test_hot_buffer_stats(self):
        """HotBuffer.get_stats() reflects appended operations."""
        entries = _make_entries(5, prefix="stats")
        for e in entries:
            self.store.append_put(e)

        stats = self.store._hot_buffer.get_stats()
        self.assertEqual(stats["put_count"], 5)
        self.assertEqual(stats["delete_count"], 0)
        self.assertGreater(stats["size_bytes"], 0)


# ===================================================================
# 35. Delegation: no inline manifest/segment I/O
# ===================================================================

class TestDelegation(SegmentStoreTestBase):

    def test_store_uses_manifest_class(self):
        """SegmentStore should have a _manifest attribute that is a Manifest."""
        self.assertIsInstance(self.store._manifest, Manifest)

    def test_store_uses_hot_buffer_class(self):
        """SegmentStore should have a _hot_buffer attribute that is a HotBuffer."""
        self.assertIsInstance(self.store._hot_buffer, HotBuffer)

    def test_no_inline_manifest_functions(self):
        """Verify the old inline functions are NOT in the module."""
        import parsica_memory.storage.segment_store as ss_mod
        self.assertFalse(hasattr(ss_mod, '_read_manifest'),
                         "_read_manifest should not exist in segment_store")
        self.assertFalse(hasattr(ss_mod, '_save_manifest'),
                         "_save_manifest should not exist in segment_store")
        self.assertFalse(hasattr(ss_mod, '_empty_manifest'),
                         "_empty_manifest should not exist in segment_store")
        self.assertFalse(hasattr(ss_mod, '_write_segment'),
                         "_write_segment should not exist in segment_store")
        self.assertFalse(hasattr(ss_mod, '_read_segment'),
                         "_read_segment should not exist in segment_store")
        self.assertFalse(hasattr(ss_mod, '_hot_append'),
                         "_hot_append should not exist in segment_store")
        self.assertFalse(hasattr(ss_mod, '_read_hot_ops'),
                         "_read_hot_ops should not exist in segment_store")


# ===================================================================
# 36. Tombstone-survives-flush-after-re-add (P0 bug fix)
# ===================================================================

class TestDeleteReAddSurvivesFlushAndReload(SegmentStoreTestBase):

    def test_delete_then_readd_same_hash_survives_flush_and_reload(self):
        """P0 bug: delete(hash) → re-add(hash) → flush() → restart → load()
        must return the re-added entry.

        [P0 Fix 2] append_put() no longer eagerly clears tombstones.
        Instead, tombstone clearing happens during flush() when the
        net-final-state computation determines the last op is a put.
        During load(), hot replay happens AFTER tombstone application,
        so a hot put overrides a manifest tombstone correctly.
        """
        e = _make_entry("will be deleted then re-added")
        original_hash = e.hash

        # Step 1: add and flush to a segment
        self.store.append_put(e)
        self.store.flush()

        # Step 2: delete (writes tombstone to manifest)
        self.store.append_delete(original_hash, reason="temporary removal")

        # Verify tombstone exists
        manifest = _read_manifest_from_disk(self.store.manifest_path)
        self.assertIn(original_hash, manifest.get("tombstones", {}))

        # Step 3: re-add same content (same hash)
        e2 = _make_entry("will be deleted then re-added")
        self.assertEqual(e2.hash, original_hash)
        self.store.append_put(e2)

        # [P0 Fix 2] Tombstone is NOT eagerly cleared by append_put
        # anymore.  It persists until flush() clears it.
        manifest = _read_manifest_from_disk(self.store.manifest_path)
        self.assertIn(original_hash, manifest.get("tombstones", {}),
                      "Tombstone should still exist — append_put no longer "
                      "eagerly clears tombstones (P0 Fix 2)")

        # But load() should still show the entry because hot replay
        # happens after tombstone application.
        loaded = self.store.load()
        loaded_hashes = {entry.hash for entry in loaded}
        self.assertIn(original_hash, loaded_hashes,
                      "Hot put should override manifest tombstone during load()")

        # Step 4: flush the delete + re-add
        self.store.flush()

        # Tombstone should NOT be in manifest after flush (flush sees
        # the net final state is a put → clears the tombstone).
        manifest = _read_manifest_from_disk(self.store.manifest_path)
        self.assertNotIn(original_hash, manifest.get("tombstones", {}),
                         "Tombstone survived flush despite re-add being the last op!")

        # Step 5: simulate restart — create a fresh SegmentStore on same workspace
        new_store = SegmentStore(self.tmp)
        loaded = new_store.load()
        loaded_hashes = {entry.hash for entry in loaded}

        self.assertIn(original_hash, loaded_hashes,
                       "Re-added entry was lost after flush + reload! "
                       "The tombstone-survives-flush bug is still present.")
        matched = [entry for entry in loaded if entry.hash == original_hash]
        self.assertEqual(len(matched), 1)
        self.assertEqual(matched[0].content, "will be deleted then re-added")


class TestDeleteReAddDeleteFinalStateDeleted(SegmentStoreTestBase):

    def test_delete_readd_delete_final_state_is_deleted(self):
        """delete → re-add → delete → flush: the entry should be GONE
        because the last op is a delete."""
        e = _make_entry("delete-readd-delete cycle")
        h = e.hash

        self.store.append_put(e)
        self.store.flush()

        # delete → re-add → delete (all in same hot window)
        self.store.append_delete(h, reason="first delete")
        e2 = _make_entry("delete-readd-delete cycle")
        self.assertEqual(e2.hash, h)
        self.store.append_put(e2)
        self.store.append_delete(h, reason="final delete")

        self.store.flush()

        # Tombstone should exist (last op was delete)
        manifest = _read_manifest_from_disk(self.store.manifest_path)
        self.assertIn(h, manifest.get("tombstones", {}))

        # Simulate restart
        new_store = SegmentStore(self.tmp)
        loaded = new_store.load()
        loaded_hashes = {entry.hash for entry in loaded}

        self.assertNotIn(h, loaded_hashes,
                         "Entry survived despite final op being delete!")


class TestMultiplePutDeleteCyclesNetState(SegmentStoreTestBase):

    def test_multiple_put_delete_cycles_net_state_correct(self):
        """Complex interleaving: multiple put/delete cycles for the same hash
        and different hashes in one hot window — net state must be correct."""
        # Entry A: put → delete → put (net: alive)
        eA = _make_entry("entry A content")
        hA = eA.hash

        # Entry B: put → delete (net: dead)
        eB = _make_entry("entry B content")
        hB = eB.hash

        # Entry C: put only (net: alive)
        eC = _make_entry("entry C content")
        hC = eC.hash

        # Entry D: put → delete → put → delete → put (net: alive)
        eD = _make_entry("entry D content")
        hD = eD.hash

        # All ops in a single hot window:
        # A: put → delete → put
        self.store.append_put(eA)
        self.store.append_delete(hA, reason="cycle A delete")
        eA2 = _make_entry("entry A content")
        self.store.append_put(eA2)

        # B: put → delete
        self.store.append_put(eB)
        self.store.append_delete(hB, reason="cycle B delete")

        # C: put
        self.store.append_put(eC)

        # D: put → delete → put → delete → put
        self.store.append_put(eD)
        self.store.append_delete(hD, reason="cycle D delete 1")
        eD2 = _make_entry("entry D content")
        self.store.append_put(eD2)
        self.store.append_delete(hD, reason="cycle D delete 2")
        eD3 = _make_entry("entry D content")
        self.store.append_put(eD3)

        self.store.flush()

        # Simulate restart
        new_store = SegmentStore(self.tmp)
        loaded = new_store.load()
        loaded_hashes = {entry.hash for entry in loaded}

        # A: last op was put → alive
        self.assertIn(hA, loaded_hashes,
                      "Entry A should be alive (last op: put)")
        # B: last op was delete → dead
        self.assertNotIn(hB, loaded_hashes,
                         "Entry B should be dead (last op: delete)")
        # C: only put → alive
        self.assertIn(hC, loaded_hashes,
                      "Entry C should be alive (only put)")
        # D: last op was put → alive
        self.assertIn(hD, loaded_hashes,
                      "Entry D should be alive (last op: put after 2 cycles)")

        # Verify no tombstones for alive entries
        manifest = _read_manifest_from_disk(new_store.manifest_path)
        tombstones = manifest.get("tombstones", {})
        self.assertNotIn(hA, tombstones)
        self.assertIn(hB, tombstones)
        self.assertNotIn(hC, tombstones)
        self.assertNotIn(hD, tombstones)


# ===================================================================
# 37. Hot overflow warning and stats (P2 Fix 1)
# ===================================================================

class TestHotOverflowWarningAndStats(SegmentStoreTestBase):

    def test_hot_overflow_detected_and_in_stats(self):
        """When hot.jsonl exceeds the emergency threshold, stats shows
        hot_overflow=True and should_flush() returns True regardless of
        minimum ops threshold."""
        # Create a store with a tiny emergency threshold (256 bytes)
        store = SegmentStore(
            self.tmp,
            hot_max_ops=100_000,
            hot_max_bytes=100_000,
            hot_min_ops=100_000,
            hot_max_emergency_bytes=256,
        )

        # Write enough data to exceed 256 bytes
        for i in range(20):
            store.append_put(_make_entry(f"overflow_test_{i}_" + "x" * 50))

        # Hot file should be well over 256 bytes
        hot_size = os.path.getsize(store.hot_path)
        self.assertGreater(hot_size, 256)

        # Overflow should be detected
        self.assertTrue(store._hot_overflow)

        # should_flush() must return True even though we're way below
        # hot_max_ops and hot_max_bytes
        self.assertTrue(store.should_flush())

        # Stats should expose the overflow flag
        s = store.stats()
        self.assertTrue(s["hot_overflow"])

    def test_hot_overflow_clears_after_flush(self):
        """After a successful flush, the overflow flag should clear."""
        store = SegmentStore(
            self.tmp,
            hot_max_ops=100_000,
            hot_max_bytes=100_000,
            hot_min_ops=100_000,
            hot_max_emergency_bytes=256,
        )

        for i in range(20):
            store.append_put(_make_entry(f"overflow_clear_{i}_" + "x" * 50))

        self.assertTrue(store._hot_overflow)

        # Flush should succeed
        result = store.flush()
        self.assertGreater(result["entries_flushed"], 0)

        # After flush, hot is empty → overflow should be false
        # (need a write to recheck, but _hot_bytes is reset in flush)
        self.assertFalse(store._hot_overflow)
        s = store.stats()
        self.assertFalse(s["hot_overflow"])

    def test_no_overflow_when_below_threshold(self):
        """No overflow flag when hot buffer is below emergency threshold."""
        store = SegmentStore(
            self.tmp,
            hot_max_emergency_bytes=50 * 1024 * 1024,  # 50 MB default
        )
        store.append_put(_make_entry("small write"))
        self.assertFalse(store._hot_overflow)
        s = store.stats()
        self.assertFalse(s["hot_overflow"])


# ===================================================================
# 38. Load truncation warning (P2 Fix 2)
# ===================================================================

class TestLoadTruncationWarning(SegmentStoreTestBase):

    def test_load_truncation_warns_and_reports(self):
        """When load() truncates at _LOAD_LIMIT, it emits a warning and
        stats reflects the truncation count."""
        import parsica_memory.storage.segment_store as ss_mod
        original = ss_mod._LOAD_LIMIT
        try:
            ss_mod._LOAD_LIMIT = 10  # Temporarily lower

            for e in _make_entries(15):
                self.store.append_put(e)

            with self.assertWarns(UserWarning) as cm:
                loaded = self.store.load()

            self.assertEqual(len(loaded), 10)

            # Warning message should mention the truncation
            warning_msg = str(cm.warning)
            self.assertIn("15", warning_msg)
            self.assertIn("10", warning_msg)
            self.assertIn("5", warning_msg)  # truncated count

            # Stats should expose the truncation
            s = self.store.stats()
            self.assertTrue(s["load_truncated"])
            self.assertEqual(s["load_truncated_count"], 5)
        finally:
            ss_mod._LOAD_LIMIT = original

    def test_no_truncation_below_limit(self):
        """When under the limit, no truncation is reported."""
        for e in _make_entries(5):
            self.store.append_put(e)

        loaded = self.store.load()
        self.assertEqual(len(loaded), 5)

        s = self.store.stats()
        self.assertFalse(s["load_truncated"])
        self.assertEqual(s["load_truncated_count"], 0)


# ===================================================================
# 39. Manifest recovery from segment scan (P2 Fix 4)
# ===================================================================

class TestManifestRecoveryFromSegmentScan(SegmentStoreTestBase):

    def test_both_manifests_corrupt_recovers_from_segments(self):
        """When both manifest.json and .bak are corrupt, the manifest is
        reconstructed from segment files on disk."""
        # Create some data and flush to create segment files
        entries = _make_entries(10, prefix="recover")
        for e in entries:
            self.store.append_put(e)
        self.store.flush()

        # Verify segment files exist
        seg_dir = self.store.seg_dir
        seg_files = [f for f in os.listdir(seg_dir)
                     if f.startswith("seg_") and f.endswith(".jsonl")]
        self.assertGreater(len(seg_files), 0)

        # Corrupt BOTH manifest files
        manifest_path = os.path.join(seg_dir, "manifest.json")
        bak_path = os.path.join(seg_dir, "manifest.json.bak")

        with open(manifest_path, "w") as f:
            f.write("{corrupt!!! not valid json")
        if os.path.exists(bak_path):
            with open(bak_path, "w") as f:
                f.write("{also corrupt!!!")

        # Create a fresh SegmentStore — this triggers manifest load
        new_store = SegmentStore(self.tmp)

        # Manifest should be reconstructed from the segment files
        manifest = _read_manifest_from_disk(new_store.manifest_path)
        self.assertGreater(len(manifest.get("segments", [])), 0)

        # The recovered segments should have _recovered=True marker
        for seg in manifest["segments"]:
            self.assertTrue(seg.get("_recovered", False))

        # The recovery metadata should be present
        self.assertIn("_recovery", manifest)
        self.assertEqual(manifest["_recovery"]["reason"],
                         "both_manifests_corrupt")

        # Data should be loadable
        loaded = new_store.load()
        self.assertGreater(len(loaded), 0)

        # Verify the recovered entries match the original entries
        original_hashes = {e.hash for e in entries}
        loaded_hashes = {e.hash for e in loaded}
        self.assertEqual(original_hashes, loaded_hashes)

    def test_no_segments_creates_empty_manifest(self):
        """When both manifests are corrupt and no segment files exist,
        an empty manifest is created (existing behavior)."""
        seg_dir = self.store.seg_dir

        # Remove all segment files
        for f in os.listdir(seg_dir):
            if f.startswith("seg_"):
                os.unlink(os.path.join(seg_dir, f))

        # Corrupt both manifest files
        manifest_path = os.path.join(seg_dir, "manifest.json")
        bak_path = os.path.join(seg_dir, "manifest.json.bak")

        with open(manifest_path, "w") as f:
            f.write("{corrupt!!!")
        if os.path.exists(bak_path):
            with open(bak_path, "w") as f:
                f.write("{corrupt!!!")

        # Create a fresh store
        new_store = SegmentStore(self.tmp)
        loaded = new_store.load()
        self.assertEqual(len(loaded), 0)


# ===================================================================
# 40. P0 Fix 1: Crash during recovery does not lose rotating ops
# ===================================================================

class TestCrashDuringRecoveryDoesNotLoseRotatingOps(SegmentStoreTestBase):

    def test_crash_during_recovery_does_not_lose_rotating_ops(self):
        """P0 Fix 1: load() with a rotating file present must re-append
        the recovered ops into hot.jsonl BEFORE deleting the rotating file.

        Scenario: process crashes during flush, leaving hot.rotating.jsonl.
        On restart, load() recovers the ops.  If the process crashes AGAIN
        before the next flush, the ops must still survive in hot.jsonl.

        Old bug: load() read rotating ops into memory, deleted the rotating
        file, and only held the ops in-memory.  A second crash before the
        next flush lost the data permanently.
        """
        e1 = _make_entry("crash recovery entry 1")
        e2 = _make_entry("crash recovery entry 2")

        # Simulate a crash that left hot.rotating.jsonl behind
        rotating_path = self.store.rotating_path
        with open(rotating_path, "w") as f:
            for e in [e1, e2]:
                op = {"op": "put", "hash": e.hash, "entry": e.to_dict(),
                      "ts": datetime.now(timezone.utc).isoformat()}
                f.write(json.dumps(op) + "\n")

        # First load — should recover the ops and re-append to hot.jsonl
        loaded = self.store.load()
        self.assertEqual(len(loaded), 2)

        # Verify rotating file is deleted
        self.assertFalse(os.path.exists(rotating_path),
                         "Rotating file should be deleted after recovery")

        # Verify the ops are now in hot.jsonl (durable!)
        hot_ops = self.store._hot_buffer.read_ops()
        hot_put_hashes = {op["hash"] for op in hot_ops if op.get("op") == "put"}
        self.assertIn(e1.hash, hot_put_hashes,
                      "Recovered op should be in hot.jsonl")
        self.assertIn(e2.hash, hot_put_hashes,
                      "Recovered op should be in hot.jsonl")

        # Simulate a SECOND crash — create a fresh store (simulating restart)
        # without any rotating file.  The ops should survive in hot.jsonl.
        new_store = SegmentStore(self.tmp)
        loaded2 = new_store.load()
        loaded2_hashes = {e.hash for e in loaded2}

        self.assertIn(e1.hash, loaded2_hashes,
                      "Entry lost after second crash! Recovery ops were not "
                      "durably committed to hot.jsonl.")
        self.assertIn(e2.hash, loaded2_hashes,
                      "Entry lost after second crash! Recovery ops were not "
                      "durably committed to hot.jsonl.")

    def test_crash_recovery_with_delete_ops(self):
        """Rotating file with delete ops: the deletes should also be
        re-appended to hot.jsonl so they survive a second crash."""
        e = _make_entry("will be deleted in rotating")
        self.store.append_put(e)
        self.store.flush()

        # Simulate rotating file with a delete op
        with open(self.store.rotating_path, "w") as f:
            op = {"op": "delete", "hash": e.hash,
                  "reason": "crash delete",
                  "ts": datetime.now(timezone.utc).isoformat()}
            f.write(json.dumps(op) + "\n")

        # First load — recover and re-append
        loaded = self.store.load()
        self.assertEqual(len(loaded), 0, "Deleted entry should not appear")

        # Verify the delete op is in hot.jsonl
        hot_ops = self.store._hot_buffer.read_ops()
        hot_delete_hashes = {op["hash"] for op in hot_ops
                             if op.get("op") == "delete"}
        self.assertIn(e.hash, hot_delete_hashes,
                      "Delete op should be in hot.jsonl after recovery")

        # Simulate second crash
        new_store = SegmentStore(self.tmp)
        loaded2 = new_store.load()
        loaded2_hashes = {entry.hash for entry in loaded2}
        self.assertNotIn(e.hash, loaded2_hashes,
                         "Deleted entry reappeared after second crash!")


# ===================================================================
# 41. P0 Fix 2: append_put does not clear tombstone eagerly
# ===================================================================

class TestAppendPutDoesNotClearTombstoneEagerly(SegmentStoreTestBase):

    def test_append_put_does_not_clear_tombstone_eagerly(self):
        """P0 Fix 2: append_put() must NOT clear tombstones eagerly.

        Scenario: entry is deleted (tombstone written to manifest), then
        re-added via append_put.  If the hot append FAILS after the
        tombstone is already cleared, the old deleted segment entry
        resurrects on the next load.

        The fix: tombstones are cleared during flush() (not append_put()).
        """
        e = _make_entry("tombstone test entry")

        # Add and flush to a segment
        self.store.append_put(e)
        self.store.flush()

        # Delete (creates tombstone in manifest)
        self.store.append_delete(e.hash, reason="testing tombstone safety")

        manifest = _read_manifest_from_disk(self.store.manifest_path)
        self.assertIn(e.hash, manifest.get("tombstones", {}))

        # Now simulate: append_put is called but imagine the hot append
        # could fail.  Even if it succeeds, the tombstone should NOT be
        # cleared yet.
        e2 = _make_entry("tombstone test entry")  # same hash
        self.assertEqual(e2.hash, e.hash)
        self.store.append_put(e2)

        # Tombstone should STILL exist in manifest (not eagerly cleared)
        manifest = _read_manifest_from_disk(self.store.manifest_path)
        self.assertIn(e.hash, manifest.get("tombstones", {}),
                      "append_put() must NOT eagerly clear tombstones! "
                      "This is the P0 Fix 2 regression.")

    def test_tombstone_cleared_during_flush_not_append(self):
        """Tombstone is cleared by flush() when net final state is a put."""
        e = _make_entry("flush clears tombstone")

        self.store.append_put(e)
        self.store.flush()

        # Delete + re-add
        self.store.append_delete(e.hash, reason="will re-add")
        e2 = _make_entry("flush clears tombstone")
        self.store.append_put(e2)

        # Before flush: tombstone still exists
        manifest = _read_manifest_from_disk(self.store.manifest_path)
        self.assertIn(e.hash, manifest.get("tombstones", {}))

        # After flush: tombstone cleared because net state is a put
        self.store.flush()

        manifest = _read_manifest_from_disk(self.store.manifest_path)
        self.assertNotIn(e.hash, manifest.get("tombstones", {}),
                         "flush() should clear tombstone when net state is put")

    def test_simulated_append_failure_does_not_resurrect_deleted_entry(self):
        """If append_put fails (after tombstone would have been cleared in
        the old code), the entry should stay deleted, not resurrect."""
        e = _make_entry("should stay deleted if append fails")

        # Add and flush to segment
        self.store.append_put(e)
        self.store.flush()

        # Delete
        self.store.append_delete(e.hash, reason="permanent delete")

        # Simulate append_put that fails (mock the hot buffer to raise)
        with mock.patch.object(
            self.store._hot_buffer, 'append_put',
            side_effect=OSError("disk full"),
        ):
            with self.assertRaises(OSError):
                e2 = _make_entry("should stay deleted if append fails")
                self.store.append_put(e2)

        # The tombstone should still exist (was never cleared)
        manifest = _read_manifest_from_disk(self.store.manifest_path)
        self.assertIn(e.hash, manifest.get("tombstones", {}),
                      "Tombstone was cleared despite append failure!")

        # The entry should NOT appear on load
        loaded = self.store.load()
        loaded_hashes = {entry.hash for entry in loaded}
        self.assertNotIn(e.hash, loaded_hashes,
                         "Deleted entry resurrected after failed append!")


# ===================================================================
# 42. P0 Fix 3: Compaction multi-group unique sequences
# ===================================================================

class TestCompactionMultiGroupUniqueSequences(SegmentStoreTestBase):

    def test_compaction_multi_group_unique_sequences(self):
        """P0 Fix 3: When compact() creates multiple merged segments in one
        run (multiple tier groups), each must get a unique sequence number.

        Old bug: all output segments used self._manifest.generation + 1
        without advancing between groups, creating duplicate sequences.
        """
        # Create segments that span two tiers:
        # Tier 0 (< 1000 entries): 5 segments with 3 entries each
        # We need at least 4 in a tier for compaction to trigger.
        # Create 4 very small segments (tier 0) and 4 medium segments (tier 1)
        # But tier 1 needs >= 1000 entries each — too slow.
        # Instead: create 8 tier-0 segments to get two groups of 4 after split.
        # Actually, with the current code, all <1000 go into tier 0, so
        # 8 tier-0 segments = 1 merge group with all 8.
        # To get MULTIPLE merge groups, we need segments in different tiers.
        # Let's mock _tier_for_count to put some segments in different tiers.

        # Simpler approach: create 8 small segments. The compaction merges
        # them as one group, producing one output segment.  But we need
        # multiple output segments from one compact() call.
        #
        # Actually, re-reading the code: the tier-based grouping means we
        # need 4+ segments in at least 2 different tiers.
        #
        # Let's just create 8 segments and monkey-patch _tier_for_count to
        # create 2 tiers with 4 segments each.

        import parsica_memory.storage.segment_store as ss_mod
        original_tier_fn = ss_mod._tier_for_count

        # Make entries 0-3 go to tier 0, entries 4-7 go to tier 1
        call_count = [0]
        def mock_tier_for_count(count):
            # Use entry_count to determine tier:
            # segments with 2 entries → tier 0
            # segments with 3 entries → tier 1
            if count <= 2:
                return 0
            else:
                return 1

        ss_mod._tier_for_count = mock_tier_for_count
        try:
            # Create 4 segments with 2 entries (tier 0)
            for batch in range(4):
                for e in _make_entries(2, prefix=f"t0_{batch}"):
                    self.store.append_put(e)
                self.store.flush()

            # Create 4 segments with 3 entries (tier 1)
            for batch in range(4):
                for e in _make_entries(3, prefix=f"t1_{batch}"):
                    self.store.append_put(e)
                self.store.flush()

            manifest_before = _read_manifest_from_disk(self.store.manifest_path)
            self.assertEqual(len(manifest_before["segments"]), 8)

            result = self.store.compact()
            self.assertEqual(result["segments_created"], 2,
                             "Should create 2 merged segments (one per tier)")

            # Verify all output segments have UNIQUE sequences
            manifest_after = _read_manifest_from_disk(self.store.manifest_path)
            sequences = [s["sequence"] for s in manifest_after["segments"]]
            self.assertEqual(len(sequences), len(set(sequences)),
                             f"Duplicate sequence numbers found: {sequences}")
        finally:
            ss_mod._tier_for_count = original_tier_fn

    def test_compaction_sequences_monotonically_increase(self):
        """After compaction, the generation counter should reflect the
        highest sequence used, so subsequent flushes get unique sequences."""
        # Create 5 small segments
        for batch in range(5):
            for e in _make_entries(3, prefix=f"mono_{batch}"):
                self.store.append_put(e)
            self.store.flush()

        gen_before = _read_manifest_from_disk(
            self.store.manifest_path)["generation"]

        self.store.compact()

        gen_after = _read_manifest_from_disk(
            self.store.manifest_path)["generation"]

        # Generation should have advanced
        self.assertGreater(gen_after, gen_before)

        # A subsequent flush should get a unique sequence
        self.store.append_put(_make_entry("after compact"))
        self.store.flush()

        manifest = _read_manifest_from_disk(self.store.manifest_path)
        sequences = [s["sequence"] for s in manifest["segments"]]
        self.assertEqual(len(sequences), len(set(sequences)),
                         f"Duplicate sequences after compact+flush: {sequences}")


# ===================================================================
# 43. P0 Fix 4: Partial compaction does not resolve tombstones
# ===================================================================

class TestCompactionPartialDoesNotResolveTombstones(SegmentStoreTestBase):

    def test_compaction_partial_does_not_resolve_tombstones(self):
        """P0 Fix 4: When compacting a SUBSET of segments, tombstones
        must NOT be resolved — the tombstoned hash might still exist in
        uncompacted segments, and removing the tombstone would let those
        copies resurrect.

        Scenario: hash H exists in segments A (compacted) and B (not compacted).
        A tombstone for H exists in the manifest.  If compaction removes the
        tombstone, B's copy of H comes back alive — data resurrection bug.
        """
        # Create an entry that will exist in multiple segments
        shared_entry = _make_entry("shared across segments")
        shared_hash = shared_entry.hash

        # Segment 1: contains shared_entry (will be compacted)
        self.store.append_put(shared_entry)
        self.store.flush()

        # Create 3 more small segments (tier 0) to trigger compaction
        for batch in range(3):
            for e in _make_entries(2, prefix=f"filler_{batch}"):
                self.store.append_put(e)
            self.store.flush()

        # Create a large segment (tier 2, >5000 entries) that also contains
        # a copy of the shared entry.  This segment will NOT be compacted
        # (it's in a different tier and there's only 1 of it).
        big_entries = _make_entries(100, prefix="big")  # Keep manageable for test
        # Manually create a big segment with the shared entry included
        big_entries_with_shared = big_entries + [shared_entry]

        # Write this as a separate segment directly
        import parsica_memory.storage.segment_store as ss_mod
        original_tier = ss_mod._tier_for_count

        # Override tier function so the big segment is in tier 2
        def mock_tier(count):
            if count > 50:
                return 2
            return original_tier(count)

        ss_mod._tier_for_count = mock_tier
        try:
            # Flush the big entries normally — append all to hot, then flush
            for e in big_entries_with_shared:
                self.store.append_put(e)
            self.store.flush()

            # Now delete the shared entry (creates tombstone)
            self.store.append_delete(shared_hash, reason="test partial compact")

            # Verify tombstone exists
            manifest = _read_manifest_from_disk(self.store.manifest_path)
            self.assertIn(shared_hash, manifest.get("tombstones", {}))

            # Compact — should only compact the 4 small tier-0 segments,
            # NOT the big tier-2 segment.
            result = self.store.compact()
            self.assertGreater(result["segments_removed"], 0)

            # The tombstone for shared_hash must STILL exist because
            # the big segment (not compacted) also contains it.
            manifest = _read_manifest_from_disk(self.store.manifest_path)
            self.assertIn(shared_hash, manifest.get("tombstones", {}),
                          "Tombstone was resolved during partial compaction! "
                          "The uncompacted segment's copy of this entry would "
                          "resurrect — P0 Fix 4 regression.")

            # The shared entry should NOT appear on load (tombstone blocks it)
            loaded = self.store.load()
            loaded_hashes = {e.hash for e in loaded}
            self.assertNotIn(shared_hash, loaded_hashes,
                             "Tombstoned entry resurrected after partial compact!")
        finally:
            ss_mod._tier_for_count = original_tier

    def test_full_compaction_resolves_tombstones(self):
        """When ALL active segments are compacted (full compaction),
        tombstones ARE resolved — no uncompacted copies can resurrect."""
        entries = []
        entry_to_delete = _make_entry("will be deleted and resolved")

        # Create 4 small segments (all tier 0)
        for batch in range(4):
            batch_entries = _make_entries(3, prefix=f"full_{batch}")
            if batch == 0:
                batch_entries.append(entry_to_delete)
            entries.extend(batch_entries)
            for e in batch_entries:
                self.store.append_put(e)
            self.store.flush()

        # Delete the entry
        self.store.append_delete(entry_to_delete.hash, reason="full compact test")
        # Flush the delete so it's not in hot buffer during compact
        self.store.flush()

        # Verify tombstone exists
        manifest = _read_manifest_from_disk(self.store.manifest_path)
        self.assertIn(entry_to_delete.hash, manifest.get("tombstones", {}))

        # Compact — all segments are tier 0, so this is a full compaction
        # (the delete-only flush creates no segment, so only the 4 original
        # segments are active and all are in tier 0 → all compacted).
        result = self.store.compact()
        self.assertGreater(result["tombstones_resolved"], 0)

        # Tombstone should be resolved
        manifest = _read_manifest_from_disk(self.store.manifest_path)
        self.assertNotIn(entry_to_delete.hash, manifest.get("tombstones", {}),
                         "Tombstone should be resolved after full compaction")


# ===================================================================
# 44. P0 Fix 5: Crash recovery rotating + active hot correct op order
# ===================================================================

class TestCrashRecoveryRotatingPlusActiveHotCorrectOrder(SegmentStoreTestBase):

    def test_crash_recovery_rotating_plus_active_hot_correct_order(self):
        """P0 Fix 5: Pro's exact reproduction scenario.

        When both hot.rotating.jsonl AND hot.jsonl exist (crash between
        rotation and manifest publish, with newer writes in fresh hot.jsonl),
        load() must replay rotating ops BEFORE current hot ops.

        Scenario:
        1. Immutable segment contains entry A.
        2. Old hot batch contains delete(A).
        3. Flush rotates that batch → hot.rotating.jsonl.
        4. Newer write appends put(A) into new hot.jsonl.
        5. Process crashes before manifest publish.
        6. Restart → load().
        7. Expected: A is alive (delete happened before re-add).
        8. Old bug: A disappears (rotating ops re-appended AFTER newer
           ops, so delete is last).
        """
        # Step 1: Create immutable segment with entry A
        entry_a = _make_entry("entry A — the survivor")
        self.store.append_put(entry_a)
        self.store.flush()

        # Step 2-3: Simulate old hot batch with delete(A) that got rotated.
        # Write hot.rotating.jsonl directly with the delete op.
        rotating_path = self.store.rotating_path
        with open(rotating_path, "w") as f:
            op = {"op": "delete", "hash": entry_a.hash,
                  "reason": "old batch delete",
                  "ts": datetime.now(timezone.utc).isoformat()}
            f.write(json.dumps(op) + "\n")

        # Step 4: Newer write appends put(A) into the new hot.jsonl
        # (simulating writes that happened after rotation but before crash).
        hot_path = self.store.hot_path
        with open(hot_path, "w") as f:
            re_add = _make_entry("entry A — the survivor")
            self.assertEqual(re_add.hash, entry_a.hash)
            op = {"op": "put", "hash": re_add.hash,
                  "entry": re_add.to_dict(),
                  "ts": datetime.now(timezone.utc).isoformat()}
            f.write(json.dumps(op) + "\n")

        # Step 5: Process crash is implicit — both files exist.

        # Step 6: Restart → create fresh store and load()
        new_store = SegmentStore(self.tmp)
        loaded = new_store.load()

        # Step 7: Expected: A is alive
        loaded_hashes = {e.hash for e in loaded}
        self.assertIn(entry_a.hash, loaded_hashes,
                      "Entry A should be ALIVE! The delete in rotating "
                      "happened BEFORE the put in hot.jsonl. Replay order "
                      "must be: rotating ops first, then current hot ops.")

    def test_crash_recovery_rotating_plus_active_hot_same_hash_put_wins(self):
        """P0 Fix 5: delete in rotating, put in active hot → entry alive.

        This is the exact same scenario as the GPT Pro reproduction but
        without a pre-existing immutable segment — purely hot-buffer ops.
        """
        entry = _make_entry("delete-then-put across crash boundary")

        # hot.rotating.jsonl has delete(entry)
        with open(self.store.rotating_path, "w") as f:
            op = {"op": "delete", "hash": entry.hash,
                  "reason": "rotating delete",
                  "ts": datetime.now(timezone.utc).isoformat()}
            f.write(json.dumps(op) + "\n")

        # hot.jsonl has put(entry) — NEWER, should win
        with open(self.store.hot_path, "w") as f:
            op = {"op": "put", "hash": entry.hash,
                  "entry": entry.to_dict(),
                  "ts": datetime.now(timezone.utc).isoformat()}
            f.write(json.dumps(op) + "\n")

        new_store = SegmentStore(self.tmp)
        loaded = new_store.load()
        loaded_hashes = {e.hash for e in loaded}
        self.assertIn(entry.hash, loaded_hashes,
                      "Entry should be alive: put in hot.jsonl is newer "
                      "than delete in hot.rotating.jsonl")

    def test_crash_recovery_rotating_plus_active_hot_delete_wins(self):
        """P0 Fix 5: put in rotating, delete in active hot → entry deleted.

        Reverse scenario: rotating has put, current hot has delete.
        The delete is newer, so the entry should be dead.
        """
        entry = _make_entry("put-then-delete across crash boundary")

        # hot.rotating.jsonl has put(entry) — OLDER
        with open(self.store.rotating_path, "w") as f:
            op = {"op": "put", "hash": entry.hash,
                  "entry": entry.to_dict(),
                  "ts": datetime.now(timezone.utc).isoformat()}
            f.write(json.dumps(op) + "\n")

        # hot.jsonl has delete(entry) — NEWER, should win
        with open(self.store.hot_path, "w") as f:
            op = {"op": "delete", "hash": entry.hash,
                  "reason": "hot delete wins",
                  "ts": datetime.now(timezone.utc).isoformat()}
            f.write(json.dumps(op) + "\n")

        new_store = SegmentStore(self.tmp)
        loaded = new_store.load()
        loaded_hashes = {e.hash for e in loaded}
        self.assertNotIn(entry.hash, loaded_hashes,
                         "Entry should be DEAD: delete in hot.jsonl is "
                         "newer than put in hot.rotating.jsonl")

    def test_crash_recovery_preserves_durability_after_repair(self):
        """After order-preserving repair, hot.jsonl contains ALL ops in
        correct order.  A second crash should not lose data."""
        entry_a = _make_entry("durable entry A")
        entry_b = _make_entry("durable entry B")

        # Rotating has put(A) and delete(B)
        with open(self.store.rotating_path, "w") as f:
            op_a = {"op": "put", "hash": entry_a.hash,
                    "entry": entry_a.to_dict(),
                    "ts": datetime.now(timezone.utc).isoformat()}
            op_b = {"op": "delete", "hash": entry_b.hash,
                    "reason": "rotating delete",
                    "ts": datetime.now(timezone.utc).isoformat()}
            f.write(json.dumps(op_a) + "\n")
            f.write(json.dumps(op_b) + "\n")

        # Hot has put(B) — re-adds B after rotating's delete
        with open(self.store.hot_path, "w") as f:
            op = {"op": "put", "hash": entry_b.hash,
                  "entry": entry_b.to_dict(),
                  "ts": datetime.now(timezone.utc).isoformat()}
            f.write(json.dumps(op) + "\n")

        # First load — triggers repair
        store1 = SegmentStore(self.tmp)
        loaded1 = store1.load()
        loaded1_hashes = {e.hash for e in loaded1}
        self.assertIn(entry_a.hash, loaded1_hashes)
        self.assertIn(entry_b.hash, loaded1_hashes,
                      "B should be alive: put in hot is newer than "
                      "delete in rotating")

        # Rotating file should be gone
        self.assertFalse(os.path.exists(self.store.rotating_path))

        # hot.jsonl should contain all ops in correct order
        hot_ops = _read_ops_from_path(store1.hot_path)
        self.assertEqual(len(hot_ops), 3,
                         "hot.jsonl should have 3 ops: put(A), delete(B), put(B)")

        # Simulate second crash — create fresh store
        store2 = SegmentStore(self.tmp)
        loaded2 = store2.load()
        loaded2_hashes = {e.hash for e in loaded2}
        self.assertIn(entry_a.hash, loaded2_hashes,
                      "Entry A lost after second crash!")
        self.assertIn(entry_b.hash, loaded2_hashes,
                      "Entry B lost after second crash!")

    def test_crash_recovery_rotating_only_no_hot_ops(self):
        """Rotating file exists but hot.jsonl is empty — all rotating ops
        should be preserved in correct order."""
        entry = _make_entry("rotating only entry")

        with open(self.store.rotating_path, "w") as f:
            op = {"op": "put", "hash": entry.hash,
                  "entry": entry.to_dict(),
                  "ts": datetime.now(timezone.utc).isoformat()}
            f.write(json.dumps(op) + "\n")

        # hot.jsonl is empty (default state after setUp)

        new_store = SegmentStore(self.tmp)
        loaded = new_store.load()
        self.assertEqual(len(loaded), 1)
        self.assertEqual(loaded[0].hash, entry.hash)

        # Rotating should be cleaned up
        self.assertFalse(os.path.exists(self.store.rotating_path))

        # Ops should be in hot.jsonl for durability
        hot_ops = _read_ops_from_path(new_store.hot_path)
        self.assertEqual(len(hot_ops), 1)


# ===================================================================
# Entry point
# ===================================================================

if __name__ == "__main__":
    unittest.main()
