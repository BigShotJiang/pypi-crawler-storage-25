from __future__ import annotations

import hashlib
import json
import os
import tempfile
import unittest
from unittest import mock

from parsica_memory.entry import MemoryEntry
from parsica_memory.storage.migration import (
    _load_entries_from_enterprise_shards,
    _load_hashes_from_shards,
    _load_pending_wal,
    _segment_checksum,
    detect_storage_format,
    migrate_to_segments,
    rollback_migration,
    verify_migration,
)


class StorageMigrationTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.workspace = self.tmp.name

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def _make_entry(self, idx: int, created: str | None = None, hash_value: str | None = None) -> MemoryEntry:
        entry = MemoryEntry(
            content=f"memory {idx}",
            source="test",
            line=idx,
            category="conversation" if idx % 2 == 0 else "fact",
            created=created or f"2026-03-{(idx % 28) + 1:02d}T12:00:00+00:00",
            memory_type="episodic" if idx % 2 == 0 else "fact",
            session_id=f"sess-{idx}",
            agent_id="moro",
            source_channel="discord:test",
        )
        entry.enriched_summary = f"summary {idx}"
        entry.search_keywords = [f"kw{idx}", "shared"]
        entry.search_queries = [f"query {idx}"]
        if hash_value:
            entry.hash = hash_value
        return entry

    def _write_shards(self, shard_count: int = 2, entries_per_shard: int = 5, start: int = 0) -> list[MemoryEntry]:
        shards_dir = os.path.join(self.workspace, "shards")
        os.makedirs(shards_dir, exist_ok=True)
        written = []
        current = start
        for shard_index in range(shard_count):
            items = []
            for _ in range(entries_per_shard):
                entry = self._make_entry(current)
                current += 1
                written.append(entry)
                items.append(entry.to_dict())
            payload = {
                "shard_key": f"2026-03:topic{shard_index}",
                "date_key": "2026-03",
                "topic_key": f"topic{shard_index}",
                "version": "0.4.0",
                "count": len(items),
                "memories": items,
            }
            with open(os.path.join(shards_dir, f"shard_2026-03_topic{shard_index}.json"), "w", encoding="utf-8") as fh:
                json.dump(payload, fh)
        return written

    def _write_wal(self, entries: list[MemoryEntry]) -> None:
        wal_dir = os.path.join(self.workspace, ".wal")
        os.makedirs(wal_dir, exist_ok=True)
        with open(os.path.join(wal_dir, "pending.jsonl"), "w", encoding="utf-8") as fh:
            for entry in entries:
                fh.write(json.dumps(entry.to_dict()) + "\n")

    def _read_manifest(self) -> dict:
        with open(os.path.join(self.workspace, "segments", "manifest.json"), "r", encoding="utf-8") as fh:
            return json.load(fh)

    def _read_segment_entries(self) -> list[dict]:
        manifest = self._read_manifest()
        entries = []
        for segment in manifest["segments"]:
            path = os.path.join(self.workspace, "segments", segment["filename"])
            with open(path, "r", encoding="utf-8") as fh:
                for line in fh:
                    if line.strip():
                        entries.append(json.loads(line))
        return entries

    def test_detect_storage_format_empty(self):
        self.assertEqual(detect_storage_format(self.workspace), "empty")

    def test_detect_storage_format_enterprise_shards(self):
        self._write_shards()
        self.assertEqual(detect_storage_format(self.workspace), "enterprise_shards")

    def test_detect_storage_format_segments(self):
        os.makedirs(os.path.join(self.workspace, "segments"), exist_ok=True)
        with open(os.path.join(self.workspace, "segments", "manifest.json"), "w", encoding="utf-8") as fh:
            json.dump({"segments": []}, fh)
        self.assertEqual(detect_storage_format(self.workspace), "segments")

    def test_detect_storage_format_time_shards(self):
        with open(os.path.join(self.workspace, "memories_2026-03.jsonl"), "w", encoding="utf-8") as fh:
            fh.write("{}\n")
        self.assertEqual(detect_storage_format(self.workspace), "time_shards")

    def test_detect_storage_format_legacy(self):
        with open(os.path.join(self.workspace, "memory_metadata.json"), "w", encoding="utf-8") as fh:
            json.dump({}, fh)
        self.assertEqual(detect_storage_format(self.workspace), "legacy")

    def test_load_entries_from_enterprise_shards_reads_disk_entries(self):
        written = self._write_shards(shard_count=2, entries_per_shard=2)
        loaded = _load_entries_from_enterprise_shards(self.workspace)
        self.assertEqual(len(loaded), len(written))
        self.assertEqual(loaded[0].enriched_summary, written[0].enriched_summary)
        self.assertEqual(loaded[0].search_keywords, written[0].search_keywords)

    def test_load_entries_from_enterprise_shards_skips_corrupt_shard_files(self):
        written = self._write_shards(shard_count=1, entries_per_shard=2)
        shards_dir = os.path.join(self.workspace, "shards")
        with open(os.path.join(shards_dir, "shard_2026-03_bad.json"), "w", encoding="utf-8") as fh:
            fh.write('{"memories": [')
        loaded = _load_entries_from_enterprise_shards(self.workspace)
        self.assertEqual({e.hash for e in loaded}, {e.hash for e in written})

    def test_load_pending_wal_reads_entries(self):
        wal_entries = [self._make_entry(90), self._make_entry(91)]
        self._write_wal(wal_entries)
        loaded = _load_pending_wal(self.workspace)
        self.assertEqual([e.hash for e in loaded], [e.hash for e in wal_entries])

    def test_load_hashes_from_shards(self):
        written = self._write_shards(shard_count=2, entries_per_shard=3)
        hashes = _load_hashes_from_shards(os.path.join(self.workspace, "shards"))
        self.assertEqual(hashes, {entry.hash for entry in written})

    def test_migrate_to_segments_creates_segments_from_enterprise_shards(self):
        self._write_shards(shard_count=2, entries_per_shard=5)
        result = migrate_to_segments(self.workspace, chunk_size=4)
        self.assertEqual(result["status"], "migrated")
        self.assertTrue(os.path.exists(os.path.join(self.workspace, "segments", "manifest.json")))
        self.assertTrue(result["segments"] >= 1)

    def test_migrate_to_segments_preserves_all_entry_hashes(self):
        written = self._write_shards(shard_count=3, entries_per_shard=4)
        migrate_to_segments(self.workspace, chunk_size=3)
        new_hashes = {item["hash"] for item in self._read_segment_entries()}
        self.assertEqual(new_hashes, {entry.hash for entry in written})

    def test_migrate_to_segments_preserves_enrichment_fields(self):
        written = self._write_shards(shard_count=1, entries_per_shard=3)
        migrate_to_segments(self.workspace, chunk_size=10)
        migrated = {item["hash"]: item for item in self._read_segment_entries()}
        for entry in written:
            self.assertEqual(migrated[entry.hash]["enriched_summary"], entry.enriched_summary)
            self.assertEqual(migrated[entry.hash]["search_keywords"], entry.search_keywords)

    def test_migrate_to_segments_replays_wal_entries(self):
        shard_entries = self._write_shards(shard_count=1, entries_per_shard=2)
        wal_entry = self._make_entry(999, created="2026-03-29T12:00:00+00:00")
        self._write_wal([wal_entry])
        migrate_to_segments(self.workspace, chunk_size=10)
        hashes = {item["hash"] for item in self._read_segment_entries()}
        self.assertIn(wal_entry.hash, hashes)
        self.assertTrue({entry.hash for entry in shard_entries}.issubset(hashes))

    def test_migrate_to_segments_deduplicates_by_hash(self):
        written = self._write_shards(shard_count=1, entries_per_shard=2)
        duplicate = self._make_entry(1000, hash_value=written[0].hash)
        duplicate.enriched_summary = "replacement"
        self._write_wal([duplicate])
        result = migrate_to_segments(self.workspace, chunk_size=10)
        self.assertEqual(result["duplicate_hashes"], 1)
        hashes = [item["hash"] for item in self._read_segment_entries()]
        self.assertEqual(len(hashes), len(set(hashes)))

    def test_migrate_to_segments_deduplicates_wal_entries_that_duplicate_shards(self):
        written = self._write_shards(shard_count=1, entries_per_shard=2)
        duplicate_one = self._make_entry(2000, hash_value=written[0].hash)
        duplicate_two = self._make_entry(2001, hash_value=written[1].hash)
        self._write_wal([duplicate_one, duplicate_two])
        result = migrate_to_segments(self.workspace, chunk_size=10)
        self.assertEqual(result["duplicate_hashes"], 2)
        self.assertEqual(result["deduped_entries"], len(written))

    def test_migrate_to_segments_creates_backup_of_old_shards(self):
        self._write_shards()
        migrate_to_segments(self.workspace)
        self.assertFalse(os.path.exists(os.path.join(self.workspace, "shards")))
        self.assertTrue(os.path.isdir(os.path.join(self.workspace, "shards.pre_segments_backup")))

    def test_migrate_to_segments_creates_manifest_backup_immediately(self):
        self._write_shards()
        migrate_to_segments(self.workspace)
        manifest_path = os.path.join(self.workspace, "segments", "manifest.json")
        backup_path = manifest_path + ".bak"
        self.assertTrue(os.path.exists(backup_path))
        with open(manifest_path, "rb") as fh:
            manifest_bytes = fh.read()
        with open(backup_path, "rb") as fh:
            backup_bytes = fh.read()
        self.assertEqual(manifest_bytes, backup_bytes)

    def test_migrate_to_segments_uses_segment_writer_json_serialization(self):
        entries = self._write_shards(shard_count=1, entries_per_shard=1)
        migrate_to_segments(self.workspace, chunk_size=10)
        manifest = self._read_manifest()
        segment = manifest["segments"][0]
        segment_path = os.path.join(self.workspace, "segments", segment["filename"])
        expected_line = json.dumps(entries[0].to_dict(), ensure_ascii=False) + "\n"
        with open(segment_path, "r", encoding="utf-8") as fh:
            actual = fh.read()
        self.assertEqual(actual, expected_line)
        expected_checksum = hashlib.sha256(expected_line.encode("utf-8")).hexdigest()
        self.assertEqual(segment["checksum_sha256"], expected_checksum)
        self.assertEqual(_segment_checksum(segment_path), expected_checksum)

    def test_migrate_to_segments_idempotent(self):
        self._write_shards()
        first = migrate_to_segments(self.workspace, chunk_size=2)
        second = migrate_to_segments(self.workspace, chunk_size=2)
        self.assertEqual(first["status"], "migrated")
        self.assertEqual(second["status"], "already_migrated")
        manifest = self._read_manifest()
        self.assertEqual(sum(seg["entry_count"] for seg in manifest["segments"]), first["deduped_entries"])

    def test_migrate_to_segments_handles_empty_shards_directory(self):
        os.makedirs(os.path.join(self.workspace, "shards"), exist_ok=True)
        result = migrate_to_segments(self.workspace, chunk_size=2)
        self.assertEqual(result["status"], "migrated")
        manifest = self._read_manifest()
        self.assertEqual(manifest["segments"], [])
        self.assertTrue(os.path.exists(os.path.join(self.workspace, "segments", "hot.jsonl")))

    def test_verify_migration_reports_zero_missing_hashes_on_good_migration(self):
        self._write_shards(shard_count=2, entries_per_shard=4)
        migrate_to_segments(self.workspace, chunk_size=3)
        result = verify_migration(self.workspace)
        self.assertEqual(result["missing"], [])
        self.assertTrue(result["enrichment_preserved"])

    def test_verify_migration_detects_missing_hashes_on_bad_migration(self):
        self._write_shards(shard_count=1, entries_per_shard=3)
        migrate_to_segments(self.workspace, chunk_size=10)
        manifest = self._read_manifest()
        segment_path = os.path.join(self.workspace, "segments", manifest["segments"][0]["filename"])
        with open(segment_path, "r", encoding="utf-8") as fh:
            lines = fh.readlines()
        with open(segment_path, "w", encoding="utf-8") as fh:
            fh.writelines(lines[:-1])
        result = verify_migration(self.workspace)
        self.assertTrue(len(result["missing"]) >= 1)

    def test_verify_migration_detects_enrichment_check_failure(self):
        self._write_shards(shard_count=1, entries_per_shard=2)
        migrate_to_segments(self.workspace, chunk_size=10)
        manifest = self._read_manifest()
        segment_path = os.path.join(self.workspace, "segments", manifest["segments"][0]["filename"])
        with open(segment_path, "r", encoding="utf-8") as fh:
            rows = [json.loads(line) for line in fh if line.strip()]
        rows[0]["enriched_summary"] = "tampered summary"
        with open(segment_path, "w", encoding="utf-8") as fh:
            for row in rows:
                fh.write(json.dumps(row) + "\n")
        result = verify_migration(self.workspace)
        self.assertFalse(result["enrichment_preserved"])

    def test_rollback_migration_restores_old_shards_from_backup(self):
        self._write_shards(shard_count=1, entries_per_shard=2)
        migrate_to_segments(self.workspace)
        result = rollback_migration(self.workspace)
        self.assertEqual(result["status"], "rolled_back")
        self.assertTrue(os.path.isdir(os.path.join(self.workspace, "shards")))
        self.assertFalse(os.path.exists(os.path.join(self.workspace, "shards.pre_segments_backup")))
        self.assertTrue(os.path.isdir(os.path.join(self.workspace, "segments.rollback_disabled")))

    def test_rollback_migration_handles_case_where_no_backup_exists(self):
        os.makedirs(os.path.join(self.workspace, "segments"), exist_ok=True)
        with open(os.path.join(self.workspace, "segments", "manifest.json"), "w", encoding="utf-8") as fh:
            json.dump({"segments": []}, fh)
        result = rollback_migration(self.workspace)
        self.assertEqual(result["status"], "no_backup")
        self.assertTrue(result["segments_removed"])
        self.assertTrue(os.path.isdir(os.path.join(self.workspace, "segments.rollback_disabled")))

    def test_rollback_migration_preserves_modified_segments_in_rollback_disabled(self):
        self._write_shards(shard_count=1, entries_per_shard=2)
        migrate_to_segments(self.workspace)
        modified_path = os.path.join(self.workspace, "segments", "post_migration_note.txt")
        with open(modified_path, "w", encoding="utf-8") as fh:
            fh.write("modified after migration")
        result = rollback_migration(self.workspace)
        self.assertEqual(result["status"], "rolled_back")
        preserved_path = os.path.join(self.workspace, "segments.rollback_disabled", "post_migration_note.txt")
        self.assertTrue(os.path.exists(preserved_path))

    def test_rollback_migration_restores_segments_if_backup_rename_fails(self):
        self._write_shards(shard_count=1, entries_per_shard=2)
        migrate_to_segments(self.workspace)

        original_replace = os.replace
        call_count = {"count": 0}

        def flaky_replace(src, dst):
            call_count["count"] += 1
            if call_count["count"] == 2:
                raise OSError("rename failed")
            return original_replace(src, dst)

        with mock.patch("parsica_memory.storage.migration.os.replace", side_effect=flaky_replace):
            with self.assertRaises(OSError):
                rollback_migration(self.workspace)

        self.assertTrue(os.path.isdir(os.path.join(self.workspace, "segments")))
        self.assertTrue(os.path.isdir(os.path.join(self.workspace, "shards.pre_segments_backup")))
        self.assertFalse(os.path.exists(os.path.join(self.workspace, "segments.rollback_disabled")))

    def test_chunk_size_respected_creates_expected_segment_count(self):
        self._write_shards(shard_count=3, entries_per_shard=5)
        result = migrate_to_segments(self.workspace, chunk_size=4)
        self.assertEqual(result["segments"], 4)
        manifest = self._read_manifest()
        self.assertEqual(len(manifest["segments"]), 4)

    def test_migration_generation_equals_segment_count(self):
        self._write_shards(shard_count=3, entries_per_shard=1)
        result = migrate_to_segments(self.workspace, chunk_size=1)
        manifest = self._read_manifest()
        self.assertEqual(result["segments"], 3)
        self.assertEqual(len(manifest["segments"]), 3)
        self.assertEqual(manifest["generation"], 3)

    def test_post_migration_flush_no_sequence_collision(self):
        self._write_shards(shard_count=3, entries_per_shard=1)
        migrate_to_segments(self.workspace, chunk_size=1)

        from parsica_memory.storage.segment_store import SegmentStore

        store = SegmentStore(self.workspace)
        store.load()
        store.append_put(self._make_entry(999, created="2026-03-30T12:00:00+00:00"))
        flush_result = store.flush()
        self.assertEqual(flush_result["entries_flushed"], 1)

        manifest = self._read_manifest()
        sequences = [seg["sequence"] for seg in manifest["segments"]]
        self.assertEqual(len(sequences), len(set(sequences)))
        self.assertEqual(max(sequences), 4)

    def test_migration_sorts_entries_by_created_timestamp(self):
        shards_dir = os.path.join(self.workspace, "shards")
        os.makedirs(shards_dir, exist_ok=True)
        entries = [
            self._make_entry(1, created="2026-03-03T12:00:00+00:00"),
            self._make_entry(2, created="2026-03-01T12:00:00+00:00"),
            self._make_entry(3, created="2026-03-02T12:00:00+00:00"),
        ]
        with open(os.path.join(shards_dir, "shard_2026-03_topic.json"), "w", encoding="utf-8") as fh:
            json.dump({"memories": [entry.to_dict() for entry in entries]}, fh)
        migrate_to_segments(self.workspace, chunk_size=10)
        created_values = [item["created"] for item in self._read_segment_entries()]
        self.assertEqual(created_values, sorted(created_values))

    def test_migration_handles_entries_missing_created_field(self):
        shards_dir = os.path.join(self.workspace, "shards")
        os.makedirs(shards_dir, exist_ok=True)
        normal = self._make_entry(1, created="2026-03-01T12:00:00+00:00").to_dict()
        missing_created = self._make_entry(2).to_dict()
        missing_created.pop("created", None)
        with open(os.path.join(shards_dir, "shard_2026-03_topic.json"), "w", encoding="utf-8") as fh:
            json.dump({"memories": [missing_created, normal]}, fh)
        result = migrate_to_segments(self.workspace, chunk_size=10)
        self.assertEqual(result["deduped_entries"], 2)
        entries = self._read_segment_entries()
        self.assertEqual(len(entries), 2)


if __name__ == "__main__":
    unittest.main()
