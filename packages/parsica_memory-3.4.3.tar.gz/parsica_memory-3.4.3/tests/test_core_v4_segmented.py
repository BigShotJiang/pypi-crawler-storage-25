"""Tests for MemorySystemV4 segmented storage integration (v3.2.0).

Validates that MemorySystemV4 correctly delegates to SegmentStore when
storage_backend="segments" or "auto", while preserving all existing
backend paths (enterprise shards, legacy).
"""

from __future__ import annotations

import json
import os
import shutil
import tempfile
import unittest
import warnings
from pathlib import Path

from parsica_memory.core_v4 import MemorySystemV4
from parsica_memory.entry import MemoryEntry
from parsica_memory.storage.segment_store import SegmentStore
from parsica_memory.storage.migration import detect_storage_format


def _make_mem(workspace: str, **kwargs) -> MemorySystemV4:
    """Create a MemorySystemV4 suppressing the agent_name warning."""
    defaults = {
        "agent_name": "test-agent",
        "graph_intelligence": False,
        "quality_routing": False,
        "semantic_expansion": False,
    }
    defaults.update(kwargs)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", UserWarning)
        return MemorySystemV4(workspace, **defaults)


class TestAutoDetectSegmentStore(unittest.TestCase):
    """Test auto-detection and migration in storage_backend='auto' mode."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_auto_detect_creates_segment_store_on_empty(self):
        """Auto mode with no existing data should NOT create a segment store
        (empty workspace = no data to migrate, no segments dir)."""
        mem = _make_mem(self.tmp, storage_backend="auto")
        # On an empty workspace, auto mode should not create segment store
        # because there's nothing to load from and no segments/ dir exists.
        # The system falls back to enterprise/legacy path (default behavior).
        self.assertEqual(len(mem.memories), 0)
        mem.close()

    def test_auto_detect_with_existing_segments(self):
        """Auto mode with existing segments/ should use SegmentStore."""
        # First: create a segmented workspace
        mem1 = _make_mem(self.tmp, storage_backend="segments")
        mem1.ingest("Auto-detect test: existing segments should be detected")
        mem1.save()
        mem1.close()
        # Verify segments exist
        self.assertTrue(os.path.exists(os.path.join(self.tmp, "segments", "manifest.json")))
        # Now: re-open with auto mode
        mem2 = _make_mem(self.tmp, storage_backend="auto")
        self.assertIsNotNone(mem2._segment_store)
        self.assertGreater(len(mem2.memories), 0)
        mem2.close()

    def test_auto_detect_enterprise_shards_migrates(self):
        """Auto mode with enterprise shards → should auto-migrate to segments."""
        # Create fake enterprise shard data
        shards_dir = os.path.join(self.tmp, "shards")
        os.makedirs(shards_dir)
        shard_data = {
            "memories": [
                {
                    "content": "Enterprise shard entry that should be migrated to segments automatically",
                    "source": "test",
                    "line": 1,
                    "category": "general",
                    "hash": "abc123def456789012345678901234567890abcdef0123456789abcdef01234567",
                    "created": "2026-03-01T00:00:00+00:00",
                    "last_accessed": "2026-03-01T00:00:00+00:00",
                    "access_count": 1,
                    "importance": 1.0,
                    "confidence": 0.8,
                    "tags": ["test"],
                    "sentiment": {},
                    "memory_type": "episodic",
                    "type_metadata": {},
                    "enriched_summary": "A test entry with enrichment",
                    "search_keywords": ["test", "shard", "entry"],
                }
            ]
        }
        with open(os.path.join(shards_dir, "shard_0.json"), "w") as f:
            json.dump(shard_data, f)

        # Open with auto mode — should migrate (defaults: use_sharding=True, sharding=True)
        mem = _make_mem(self.tmp, storage_backend="auto")
        self.assertIsNotNone(mem._segment_store)
        # Check that segments dir was created
        self.assertTrue(os.path.exists(os.path.join(self.tmp, "segments", "manifest.json")))
        # Check that data was migrated
        self.assertGreater(len(mem.memories), 0)
        # Verify enrichment was preserved
        migrated = [m for m in mem.memories if "Enterprise shard" in m.content]
        self.assertEqual(len(migrated), 1)
        self.assertEqual(migrated[0].enriched_summary, "A test entry with enrichment")
        mem.close()


class TestAutoMigrationSkipsUnsupportedFormats(unittest.TestCase):
    """Test that auto-migration skips formats migrate_to_segments() does not support."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_auto_migration_skips_time_shards(self):
        with open(os.path.join(self.tmp, "memories_2026-03.jsonl"), "w", encoding="utf-8") as fh:
            fh.write(json.dumps({
                "content": "time shard entry that should stay on existing backend",
                "source": "test",
                "line": 1,
                "category": "general",
                "hash": "time-shard-hash",
                "created": "2026-03-01T00:00:00+00:00",
                "last_accessed": "2026-03-01T00:00:00+00:00",
                "access_count": 1,
                "importance": 1.0,
                "confidence": 0.8,
                "tags": [],
                "sentiment": {},
                "memory_type": "episodic",
                "type_metadata": {},
            }) + "\n")

        with self.assertLogs("parsica_memory", level="INFO") as logs:
            mem = _make_mem(self.tmp, storage_backend="auto", use_sharding=False, sharding=True)

        self.assertIsNone(mem._segment_store)
        self.assertEqual(detect_storage_format(self.tmp), "time_shards")
        self.assertFalse(os.path.exists(os.path.join(self.tmp, "segments", "manifest.json")))
        self.assertTrue(any(
            "Auto-migration from time_shards not yet supported. Using existing backend." in message
            for message in logs.output
        ))
        mem.close()

    def test_auto_migration_skips_legacy(self):
        with open(os.path.join(self.tmp, "memory_metadata.json"), "w", encoding="utf-8") as fh:
            json.dump({
                "version": "0.4.0",
                "memories": [
                    {
                        "content": "legacy entry that should stay on existing backend",
                        "source": "test",
                        "line": 1,
                        "category": "general",
                        "hash": "legacy-hash",
                        "created": "2026-03-01T00:00:00+00:00",
                        "last_accessed": "2026-03-01T00:00:00+00:00",
                        "access_count": 1,
                        "importance": 1.0,
                        "confidence": 0.8,
                        "tags": [],
                        "sentiment": {},
                        "memory_type": "episodic",
                        "type_metadata": {},
                    }
                ],
            }, fh)

        with self.assertLogs("parsica_memory", level="INFO") as logs:
            mem = _make_mem(self.tmp, storage_backend="auto", use_sharding=False, sharding=False)

        self.assertIsNone(mem._segment_store)
        self.assertEqual(detect_storage_format(self.tmp), "legacy")
        self.assertFalse(os.path.exists(os.path.join(self.tmp, "segments", "manifest.json")))
        self.assertTrue(any(
            "Auto-migration from legacy not yet supported. Using existing backend." in message
            for message in logs.output
        ))
        self.assertEqual(len(mem.memories), 1)
        self.assertIn("legacy entry", mem.memories[0].content)
        mem.close()


class TestForceSegmentsMode(unittest.TestCase):
    """Test storage_backend='segments' forces segmented storage."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_force_segments_mode(self):
        """storage_backend='segments' should always create a SegmentStore."""
        mem = _make_mem(self.tmp, storage_backend="segments")
        self.assertIsNotNone(mem._segment_store)
        self.assertIsInstance(mem._segment_store, SegmentStore)
        mem.close()

    def test_force_segments_creates_dir(self):
        """Forcing segments mode should create the segments/ directory."""
        mem = _make_mem(self.tmp, storage_backend="segments")
        self.assertTrue(os.path.isdir(os.path.join(self.tmp, "segments")))
        mem.close()


class TestForceEnterpriseMode(unittest.TestCase):
    """Test that storage_backend='enterprise' uses the old shard path."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_force_enterprise_mode(self):
        """storage_backend='enterprise' should NOT create a SegmentStore."""
        mem = _make_mem(self.tmp, storage_backend="enterprise")
        self.assertIsNone(mem._segment_store)
        # Enterprise mode should use shard_manager
        self.assertIsNotNone(mem.shard_manager)
        mem.close()

    def test_force_legacy_mode(self):
        """storage_backend='legacy' should NOT create a SegmentStore."""
        mem = _make_mem(self.tmp, storage_backend="legacy")
        self.assertIsNone(mem._segment_store)
        mem.close()


class TestSegmentedLoadPopulatesMemories(unittest.TestCase):
    """Test that load() fills self.memories when using segmented storage."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_segmented_load_populates_memories(self):
        """After ingest + save + reload, memories should be populated."""
        mem1 = _make_mem(self.tmp, storage_backend="segments")
        mem1.ingest(
            "Load test: segmented storage should persist and reload memories correctly"
        )
        mem1.save()
        count1 = len(mem1.memories)
        self.assertGreater(count1, 0)
        mem1.close()

        # Reload
        mem2 = _make_mem(self.tmp, storage_backend="segments")
        self.assertEqual(len(mem2.memories), count1)
        self.assertTrue(any("Load test" in m.content for m in mem2.memories))
        mem2.close()

    def test_segmented_load_rebuilds_indexes(self):
        """After load, hash and content-norm indexes should be populated."""
        mem1 = _make_mem(self.tmp, storage_backend="segments")
        mem1.ingest(
            "Index rebuild test: hash and content norm indexes must be populated after load"
        )
        mem1.save()
        mem1.close()

        mem2 = _make_mem(self.tmp, storage_backend="segments")
        self.assertEqual(len(mem2._hashes), len(mem2.memories))
        self.assertGreater(len(mem2._content_norms), 0)
        mem2.close()


class TestSegmentedIngestSearchRoundtrip(unittest.TestCase):
    """Test ingest → search roundtrip with segmented storage."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_segmented_ingest_search_roundtrip(self):
        """Ingest content, search for it — should return results."""
        mem = _make_mem(self.tmp, storage_backend="segments")
        mem.ingest(
            "The weather in Portland Oregon is usually rainy during winter months"
        )
        results = mem.search("Portland weather", limit=5)
        self.assertGreater(len(results), 0)
        # Check that the content matches
        found = any("Portland" in str(getattr(r, 'content', r)) for r in results)
        self.assertTrue(found)
        mem.close()

    def test_segmented_search_after_save_reload(self):
        """Search should work after save/reload cycle."""
        mem1 = _make_mem(self.tmp, storage_backend="segments")
        mem1.ingest(
            "Machine learning models require careful hyperparameter tuning for best performance"
        )
        mem1.save()
        mem1.close()

        mem2 = _make_mem(self.tmp, storage_backend="segments")
        results = mem2.search("hyperparameter tuning", limit=5)
        self.assertGreater(len(results), 0)
        mem2.close()


class TestSegmentedSaveCreatesSegment(unittest.TestCase):
    """Test that save() creates segment files."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_segmented_save_creates_segment(self):
        """save() should create segment files in segments/ directory."""
        mem = _make_mem(self.tmp, storage_backend="segments")
        mem.ingest(
            "Save test: this entry should be persisted to a segment file on disk"
        )
        save_path = mem.save()
        self.assertEqual(save_path, os.path.join(self.tmp, "segments"))
        # Check manifest exists
        manifest_path = os.path.join(self.tmp, "segments", "manifest.json")
        self.assertTrue(os.path.exists(manifest_path))
        # Check at least one segment file exists
        seg_files = [f for f in os.listdir(os.path.join(self.tmp, "segments"))
                     if f.startswith("seg_") and f.endswith(".jsonl")]
        self.assertGreater(len(seg_files), 0)
        mem.close()


class TestSegmentedFlush(unittest.TestCase):
    """Test flush() with segmented storage."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_segmented_flush_creates_segment(self):
        """flush() should delegate to SegmentStore and create segment files."""
        mem = _make_mem(self.tmp, storage_backend="segments")
        mem.ingest(
            "Flush test: this entry should be flushed to an immutable segment file"
        )
        result = mem.flush()
        self.assertIn("flushed_entries", result)
        self.assertTrue(result.get("wal_cleared", False))
        mem.close()

    def test_segmented_flush_returns_correct_count(self):
        """flush() should report the correct number of flushed entries."""
        mem = _make_mem(self.tmp, storage_backend="segments")
        # Ingest multiple entries
        mem.ingest("Flush count test entry number one for accurate counting")
        mem.ingest("Flush count test entry number two for accurate counting")
        mem.ingest("Flush count test entry number three for accurate counting")
        result = mem.flush()
        # Should have flushed the entries (exact count depends on dedup)
        self.assertIsInstance(result["flushed_entries"], int)
        mem.close()


class TestSegmentedCompact(unittest.TestCase):
    """Test compact() with segmented storage."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_segmented_compact_delegates_to_store(self):
        """compact() should delegate to SegmentStore.compact()."""
        mem = _make_mem(self.tmp, storage_backend="segments")
        # Create some segments by ingesting and flushing multiple times
        for i in range(5):
            for j in range(10):
                mem.ingest(
                    f"Compact test batch {i} item {j}: unique content here for dedup avoidance"
                )
            mem.save()  # flush to create a segment each time

        result = mem.compact()
        self.assertIsInstance(result, dict)
        # After compaction, memories should still be accessible
        self.assertGreater(len(mem.memories), 0)
        mem.close()

    def test_segmented_compact_preserves_data(self):
        """Compaction should not lose any live entries."""
        mem = _make_mem(self.tmp, storage_backend="segments")
        mem.ingest(
            "Compact preserve test: this entry must survive compaction intact"
        )
        mem.save()
        before_count = len(mem.memories)

        mem.compact()
        after_count = len(mem.memories)
        # No data should be lost from compaction of a single segment
        self.assertEqual(before_count, after_count)
        mem.close()


class TestSegmentedForget(unittest.TestCase):
    """Test forget() with segmented storage."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_segmented_forget_excludes_from_search(self):
        """After forget(), forgotten entries should not appear in search."""
        mem = _make_mem(self.tmp, storage_backend="segments")
        mem.ingest(
            "The elephant painting was beautiful and magnificent in the gallery"
        )
        mem.ingest(
            "Quantum computing will revolutionize cryptography and security algorithms"
        )
        mem.save()

        # Verify both are searchable
        results = mem.search("elephant", limit=5)
        self.assertGreater(len(results), 0)

        # Forget elephant-related memories
        forget_result = mem.forget(topic="elephant")
        self.assertGreater(len(forget_result["removed"]), 0)

        # Reload to verify persistence
        mem2 = _make_mem(self.tmp, storage_backend="segments")
        results = mem2.search("elephant", limit=5)
        # Should not find elephant anymore
        found = any("elephant" in str(getattr(r, 'content', r)).lower() for r in results)
        self.assertFalse(found)
        # But quantum should still be there
        results2 = mem2.search("quantum computing", limit=5)
        self.assertGreater(len(results2), 0)
        mem2.close()


class TestSegmentedClose(unittest.TestCase):
    """Test close() with segmented storage."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_segmented_close_flushes(self):
        """close() should flush pending data to segments."""
        mem = _make_mem(self.tmp, storage_backend="segments")
        mem.ingest(
            "Close test: this entry should be flushed when close is called on system"
        )
        # Don't call save() — close should handle it
        mem.close()

        # Reload and verify data was persisted
        mem2 = _make_mem(self.tmp, storage_backend="segments")
        self.assertGreater(len(mem2.memories), 0)
        self.assertTrue(any("Close test" in m.content for m in mem2.memories))
        mem2.close()


class TestSegmentedStats(unittest.TestCase):
    """Test stats() includes segment storage info."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_segmented_stats_includes_storage_info(self):
        """stats() should include segment store information."""
        mem = _make_mem(self.tmp, storage_backend="segments")
        mem.ingest(
            "Stats test: verify that statistics include segment storage information"
        )
        mem.save()
        stats = mem.stats()
        # get_stats should have segment info
        full_stats = mem.get_stats()
        self.assertEqual(full_stats.get("storage_backend"), "segments")
        self.assertIn("segment_store", full_stats)
        seg_stats = full_stats["segment_store"]
        self.assertIn("segment_count", seg_stats)
        self.assertIn("generation", seg_stats)
        mem.close()


class TestExistingTestsInEnterpriseMode(unittest.TestCase):
    """Verify no regression in enterprise (shard) mode."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_existing_tests_pass_in_enterprise_mode(self):
        """Enterprise mode (storage_backend='enterprise') should work as before."""
        mem = _make_mem(self.tmp, storage_backend="enterprise")
        self.assertIsNone(mem._segment_store)

        # Ingest
        count = mem.ingest(
            "Enterprise mode regression test: ensure the original shard path still works correctly"
        )
        self.assertGreater(count, 0)

        # Search
        results = mem.search("enterprise regression", limit=5)
        self.assertGreater(len(results), 0)

        # Save
        save_path = mem.save()
        self.assertNotEqual(save_path, os.path.join(self.tmp, "segments"))

        # Flush
        flush_result = mem.flush()
        self.assertIn("flushed_entries", flush_result)

        # Compact
        compact_result = mem.compact()
        self.assertIn("original_count", compact_result)

        mem.close()

    def test_legacy_mode_works(self):
        """Legacy flat file mode should work as before."""
        mem = _make_mem(
            self.tmp,
            storage_backend="legacy",
            use_sharding=False,
            sharding=False,
        )
        self.assertIsNone(mem._segment_store)

        count = mem.ingest(
            "Legacy mode test: flat file storage path should be preserved and functional"
        )
        self.assertGreater(count, 0)

        mem.save()

        # Verify it saved to legacy format (memory_metadata.json)
        self.assertTrue(os.path.exists(
            os.path.join(self.tmp, "memory_metadata.json")
        ))
        mem.close()


class TestSearchQualityPreservedAfterMigration(unittest.TestCase):
    """Verify search quality is preserved after migration from enterprise shards."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_search_results_same_before_and_after_migration(self):
        """Search results should be equivalent before/after migration."""
        # Step 1: Create data in enterprise shard format
        shards_dir = os.path.join(self.tmp, "shards")
        os.makedirs(shards_dir)

        entries = []
        for i in range(5):
            entry = MemoryEntry(
                content=f"Search quality test entry {i}: the capital of France is Paris which is a major European city",
                source="test",
                line=i,
                category="general",
                memory_type="episodic",
                agent_id="test-agent",
            )
            entry.tags = ["geography", "europe"]
            entry.enriched_summary = f"Test entry {i} about Paris"
            entry.search_keywords = ["paris", "france", "capital", "europe"]
            entries.append(entry)

        shard_data = {"memories": [e.to_dict() for e in entries]}
        with open(os.path.join(shards_dir, "shard_0.json"), "w") as f:
            json.dump(shard_data, f)

        # Step 2: Open with auto mode → triggers migration (defaults: use_sharding=True, sharding=True)
        mem = _make_mem(self.tmp, storage_backend="auto")
        self.assertIsNotNone(mem._segment_store)

        # Step 3: Verify all entries are present
        self.assertEqual(len(mem.memories), len(entries))

        # Step 4: Search should find relevant results
        results = mem.search("Paris capital France", limit=5)
        self.assertGreater(len(results), 0)

        # Step 5: Verify enrichment was preserved
        for m in mem.memories:
            if "Search quality test" in m.content:
                self.assertIn("paris", m.search_keywords)
                self.assertTrue(m.enriched_summary.startswith("Test entry"))

        mem.close()


class TestSegmentedIngestMistake(unittest.TestCase):
    """Test ingest_mistake() with segmented storage."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_ingest_mistake_uses_segment_store(self):
        """ingest_mistake should write through segment store when active."""
        mem = _make_mem(self.tmp, storage_backend="segments")
        entry = mem.ingest_mistake(
            what_happened="Used wrong API endpoint during integration testing",
            correction="Always verify the endpoint URL in config before calling",
            root_cause="Hardcoded development URL was left in production config",
            severity="high",
        )
        self.assertIsNotNone(entry)
        self.assertEqual(entry.memory_type, "mistake")

        # Save and reload to verify persistence via segments
        mem.save()
        mem.close()

        mem2 = _make_mem(self.tmp, storage_backend="segments")
        mistakes = [m for m in mem2.memories if m.memory_type == "mistake"]
        self.assertEqual(len(mistakes), 1)
        self.assertIn("wrong API endpoint", mistakes[0].content)
        mem2.close()


class TestSegmentedDeleteSource(unittest.TestCase):
    """Test delete_source() with segmented storage."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_delete_source_uses_segment_tombstones(self):
        """delete_source() should use segment store tombstones."""
        mem = _make_mem(self.tmp, storage_backend="segments")
        mem.ingest(
            "Delete source test: this content was ingested from a specific source URL",
            source_url="http://example.com/article1",
        )
        mem.ingest(
            "This entry has a different source URL and should survive the delete",
            source_url="http://example.com/article2",
        )
        mem.save()

        result = mem.delete_source("http://example.com/article1")
        self.assertEqual(result["deleted"], 1)

        # Reload and verify
        mem2 = _make_mem(self.tmp, storage_backend="segments")
        # Article1 should be gone, article2 should remain
        contents = [m.content for m in mem2.memories]
        self.assertFalse(any("article1" in c.lower() for c in contents))
        # article2 survives (it was ingested, so check it's there if it passed filters)
        mem2.close()


class TestSegmentedMultipleFlushCycles(unittest.TestCase):
    """Test multiple flush cycles with segmented storage."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_multiple_flush_cycles_accumulate(self):
        """Multiple ingest→flush cycles should accumulate segments correctly."""
        mem = _make_mem(self.tmp, storage_backend="segments")

        # Cycle 1
        mem.ingest(
            "Flush cycle one: artificial intelligence is transforming healthcare delivery"
        )
        mem.save()

        # Cycle 2
        mem.ingest(
            "Flush cycle two: deep learning requires large datasets for effective training"
        )
        mem.save()

        # Cycle 3
        mem.ingest(
            "Flush cycle three: neural networks can model complex nonlinear relationships"
        )
        mem.save()

        # All three should be in memory
        self.assertEqual(len(mem.memories), 3)

        # All three should be searchable
        results = mem.search("artificial intelligence deep learning", limit=10)
        self.assertGreater(len(results), 0)

        # Reload and verify persistence
        mem.close()
        mem2 = _make_mem(self.tmp, storage_backend="segments")
        self.assertEqual(len(mem2.memories), 3)
        mem2.close()


class TestSegmentedStorageBackendProperty(unittest.TestCase):
    """Test the _using_segments property."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_using_segments_property_true(self):
        """_using_segments should be True when segment store is active."""
        mem = _make_mem(self.tmp, storage_backend="segments")
        self.assertTrue(mem._using_segments)
        mem.close()

    def test_using_segments_property_false(self):
        """_using_segments should be False when segment store is not active."""
        mem = _make_mem(self.tmp, storage_backend="enterprise")
        self.assertFalse(mem._using_segments)
        mem.close()


class TestImportFromPersistsInSegmentedMode(unittest.TestCase):
    """Test that import_from() persists entries through segments (Fix 1)."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_import_from_persists_in_segmented_mode(self):
        """import_from(merge=True): imported entries survive close + reopen."""
        # Step 1: Create an export file
        export_path = os.path.join(self.tmp, "export.json")
        export_data = {
            "version": "4.2",
            "entries": [
                {
                    "content": "Import persist test: the Eiffel Tower is located in Paris France",
                    "source": "import",
                    "category": "geography",
                    "memory_type": "episodic",
                    "timestamp": "2026-03-01T00:00:00+00:00",
                },
                {
                    "content": "Import persist test: the Great Wall stretches across northern China",
                    "source": "import",
                    "category": "geography",
                    "memory_type": "episodic",
                    "timestamp": "2026-03-01T01:00:00+00:00",
                },
            ],
        }
        with open(export_path, "w") as f:
            json.dump(export_data, f)

        # Step 2: Import into segmented store
        mem = _make_mem(self.tmp, storage_backend="segments")
        count = mem.import_from(export_path, merge=True)
        self.assertEqual(count, 2)
        self.assertEqual(len(mem.memories), 2)
        mem.close()

        # Step 3: Reopen and verify entries survived
        mem2 = _make_mem(self.tmp, storage_backend="segments")
        self.assertEqual(len(mem2.memories), 2)
        contents = [m.content for m in mem2.memories]
        self.assertTrue(any("Eiffel Tower" in c for c in contents))
        self.assertTrue(any("Great Wall" in c for c in contents))
        mem2.close()

    def test_import_from_merge_false_clears_and_persists(self):
        """import_from(merge=False): replaces store, new entries persist."""
        # Step 1: Pre-populate the store
        mem = _make_mem(self.tmp, storage_backend="segments")
        mem.ingest("Pre-existing entry that should be replaced by the import")
        mem.save()
        self.assertEqual(len(mem.memories), 1)
        mem.close()

        # Step 2: Create export file
        export_path = os.path.join(self.tmp, "export.json")
        export_data = {
            "version": "4.2",
            "entries": [
                {
                    "content": "Replacement entry: merge false should wipe old entries completely",
                    "source": "import",
                    "category": "general",
                    "memory_type": "episodic",
                    "timestamp": "2026-03-02T00:00:00+00:00",
                },
            ],
        }
        with open(export_path, "w") as f:
            json.dump(export_data, f)

        # Step 3: Import with merge=False
        mem2 = _make_mem(self.tmp, storage_backend="segments")
        count = mem2.import_from(export_path, merge=False)
        self.assertEqual(count, 1)
        self.assertEqual(len(mem2.memories), 1)
        self.assertIn("Replacement entry", mem2.memories[0].content)
        mem2.close()

        # Step 4: Reopen and verify
        mem3 = _make_mem(self.tmp, storage_backend="segments")
        # The replacement entry should persist
        self.assertGreaterEqual(len(mem3.memories), 1)
        found_replacement = any("Replacement entry" in m.content for m in mem3.memories)
        self.assertTrue(found_replacement)
        mem3.close()


class TestReEnrichWritesBackInSegmentedMode(unittest.TestCase):
    """Test that re_enrich() writes enriched entries back through segments (Fix 2)."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_re_enrich_writes_back_in_segmented_mode(self):
        """re_enrich(): enriched fields survive close + reopen in segmented mode."""
        # Step 1: Create a store with entries (no enricher)
        mem = _make_mem(self.tmp, storage_backend="segments")
        mem.ingest(
            "Re-enrich test: machine learning models benefit from feature engineering"
        )
        mem.save()
        # Verify no enrichment yet
        self.assertFalse(bool(getattr(mem.memories[0], "enriched_summary", "")))
        mem.close()

        # Step 2: Reopen with an enricher and re-enrich
        def mock_enricher(text):
            return {
                "summary": "A statement about ML feature engineering",
                "tags": ["machine-learning", "feature-engineering"],
                "keywords": ["ml", "features", "engineering"],
                "search_queries": ["how does feature engineering improve ML"],
            }

        mem2 = _make_mem(self.tmp, storage_backend="segments", enricher=mock_enricher)
        enriched_count = mem2.re_enrich()
        self.assertEqual(enriched_count, 1)
        # Verify in-memory enrichment
        self.assertEqual(
            mem2.memories[0].enriched_summary,
            "A statement about ML feature engineering",
        )
        mem2.close()

        # Step 3: Reopen WITHOUT enricher and verify enrichment persisted
        mem3 = _make_mem(self.tmp, storage_backend="segments")
        self.assertGreater(len(mem3.memories), 0)
        enriched = [m for m in mem3.memories if getattr(m, "enriched_summary", "")]
        self.assertGreater(len(enriched), 0)
        self.assertEqual(
            enriched[0].enriched_summary,
            "A statement about ML feature engineering",
        )
        self.assertIn("machine-learning", enriched[0].tags)
        mem3.close()


class TestCloseNoDoubleFlush(unittest.TestCase):
    """Test that close() does not double-flush the segment store (Fix 3)."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_close_no_double_flush(self):
        """close() should call SegmentStore.flush() exactly once."""
        mem = _make_mem(self.tmp, storage_backend="segments")
        mem.ingest(
            "Close double-flush test: verify flush is invoked exactly one time"
        )

        # Monkey-patch SegmentStore.flush to count calls
        original_flush = mem._segment_store.flush
        flush_call_count = [0]

        def counting_flush():
            flush_call_count[0] += 1
            return original_flush()

        mem._segment_store.flush = counting_flush
        mem.close()

        # flush() should be called exactly once (from self.flush() inside close())
        self.assertEqual(flush_call_count[0], 1,
                         f"Expected 1 flush call, got {flush_call_count[0]}")


class TestMigrationFailureFallsBack(unittest.TestCase):
    """Test that migration failure in _initialize() falls back gracefully (Fix 4)."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_migration_failure_falls_back(self):
        """If migrate_to_segments() fails, constructor should still succeed
        and fall back to enterprise shards."""
        # Create fake enterprise shard data so auto-detect triggers migration
        shards_dir = os.path.join(self.tmp, "shards")
        os.makedirs(shards_dir)
        shard_data = {
            "memories": [
                {
                    "content": "Migration failure test: this entry should still be accessible",
                    "source": "test",
                    "line": 1,
                    "category": "general",
                    "hash": "abc123def456789012345678901234567890abcdef0123456789abcdef01234567",
                    "created": "2026-03-01T00:00:00+00:00",
                    "last_accessed": "2026-03-01T00:00:00+00:00",
                    "access_count": 1,
                    "importance": 1.0,
                    "confidence": 0.8,
                    "tags": [],
                    "sentiment": {},
                    "memory_type": "episodic",
                    "type_metadata": {},
                }
            ]
        }
        with open(os.path.join(shards_dir, "shard_0.json"), "w") as f:
            json.dump(shard_data, f)

        # Patch migrate_to_segments to raise
        import parsica_memory.core_v4 as core_module
        original_migrate = core_module.migrate_to_segments

        def failing_migrate(workspace):
            raise OSError("Simulated disk full error during migration")

        core_module.migrate_to_segments = failing_migrate
        try:
            # Constructor should NOT raise — it should fall back gracefully
            mem = _make_mem(self.tmp, storage_backend="auto")
            # Should have fallen back to enterprise shards (no segment store)
            self.assertIsNone(mem._segment_store)
            self.assertFalse(mem._using_segments)
            # The system should be functional even after failed migration:
            # ingest and search should work via the enterprise/legacy path
            mem.ingest(
                "Post-migration-failure ingest: system should be functional after fallback"
            )
            results = mem.search("migration failure ingest", limit=5)
            self.assertGreater(len(results), 0)
            mem.close()
        finally:
            core_module.migrate_to_segments = original_migrate


class TestSegmentedSyncWarnings(unittest.TestCase):
    """Test segmented-mode PeerSync warnings for unsupported v3.2 behavior."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_sync_raises_in_segmented_mode(self):
        """sync() should raise NotImplementedError in segmented mode."""
        mem = _make_mem(self.tmp, storage_backend="segments")
        try:
            with self.assertRaises(NotImplementedError) as ctx:
                mem.sync(peers=[])
            self.assertIn("not compatible with segmented storage", str(ctx.exception))
            self.assertIn("v3.3", str(ctx.exception))
        finally:
            mem.close()

    def test_sync_daily_logs_raises_in_segmented_mode(self):
        """sync_daily_logs() should raise NotImplementedError in segmented mode."""
        mem = _make_mem(self.tmp, storage_backend="segments")
        try:
            with self.assertRaises(NotImplementedError) as ctx:
                mem.sync_daily_logs(peers=[])
            self.assertIn("not compatible with segmented storage", str(ctx.exception))
            self.assertIn("v3.3", str(ctx.exception))
        finally:
            mem.close()


class TestSegmentedNeverTouchesLegacyWal(unittest.TestCase):
    """Test that segmented mode never writes to legacy .wal/ directory."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_segmented_never_touches_legacy_wal(self):
        """In segmented mode, no .wal/ directory should be created or written to."""
        mem = _make_mem(self.tmp, storage_backend="segments")

        # Ingest, flush, ingest more, flush again
        mem.ingest(
            "Legacy WAL test: this content should only go through segment storage"
        )
        mem.flush()
        mem.ingest(
            "Legacy WAL test: second entry also routed through segment storage only"
        )
        mem.flush()

        # Check that no legacy WAL files were created
        wal_dir = os.path.join(self.tmp, ".wal")
        parsica_wal = os.path.join(self.tmp, ".parsica_wal.jsonl")
        antaris_wal = os.path.join(self.tmp, ".antaris_wal.jsonl")

        # .wal directory should not exist
        if os.path.exists(wal_dir):
            wal_files = os.listdir(wal_dir)
            # If it exists, it should be empty (no entries written)
            self.assertEqual(len(wal_files), 0,
                             f".wal/ dir has files: {wal_files}")

        # parsica_wal.jsonl should either not exist or be empty
        if os.path.exists(parsica_wal):
            with open(parsica_wal) as f:
                content = f.read().strip()
            self.assertEqual(content, "",
                             f".parsica_wal.jsonl has content: {content[:200]}")

        # antaris_wal.jsonl should either not exist or be empty
        if os.path.exists(antaris_wal):
            with open(antaris_wal) as f:
                content = f.read().strip()
            self.assertEqual(content, "",
                             f".antaris_wal.jsonl has content: {content[:200]}")

        # Verify data IS in segments
        seg_dir = os.path.join(self.tmp, "segments")
        self.assertTrue(os.path.isdir(seg_dir))
        seg_files = [f for f in os.listdir(seg_dir) if f.startswith("seg_")]
        self.assertGreater(len(seg_files), 0,
                           "Expected segment files but found none")

        mem.close()


if __name__ == "__main__":
    unittest.main()
