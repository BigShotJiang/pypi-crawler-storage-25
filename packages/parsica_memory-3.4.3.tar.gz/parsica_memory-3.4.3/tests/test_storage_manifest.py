"""Tests for parsica_memory.storage.manifest — Manifest class."""

from __future__ import annotations

import json
import os
import shutil
import tempfile
import threading
import time
import unittest
from unittest import mock


class TestManifestCreate(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.seg_dir = os.path.join(self.tmpdir, "segments")

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_create_fresh(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        self.assertEqual(m.generation, 0)
        self.assertEqual(m.segments, [])
        self.assertEqual(m.tombstones, {})
        self.assertEqual(m.version, "3.2.0")
        self.assertIn("hot", m.data)
        self.assertIsNone(m.migration)

    def test_segments_dir_created(self):
        from parsica_memory.storage.manifest import Manifest
        Manifest(self.seg_dir)
        self.assertTrue(os.path.isdir(self.seg_dir))


class TestManifestLoad(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.seg_dir = os.path.join(self.tmpdir, "segments")
        os.makedirs(self.seg_dir, exist_ok=True)

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_load_existing(self):
        from parsica_memory.storage.manifest import Manifest
        data = {
            "version": "3.2.0",
            "generation": 5,
            "created_at": "2026-01-01T00:00:00+00:00",
            "updated_at": "2026-01-01T00:00:00+00:00",
            "segments": [],
            "hot": {"filename": "hot.jsonl", "put_count": 0,
                    "delete_count": 0, "last_write_at": None},
            "tombstones": {},
            "search": {"index_generation": 5},
            "migration": None,
        }
        mpath = os.path.join(self.seg_dir, "manifest.json")
        with open(mpath, "w") as f:
            json.dump(data, f)

        m = Manifest(self.seg_dir)
        self.assertEqual(m.generation, 5)


class TestGenerationCounter(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.seg_dir = os.path.join(self.tmpdir, "segments")

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_save_does_not_increment(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        self.assertEqual(m.generation, 0)
        m.save()
        self.assertEqual(m.generation, 0)
        m.save()
        self.assertEqual(m.generation, 0)

    def test_mutation_then_save_no_double_increment(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        m.add_tombstones({"h1": {"deleted_at": "now", "reason": "test"}})
        self.assertEqual(m.generation, 1)
        m.save()
        self.assertEqual(m.generation, 1)

    def test_each_mutation_increments(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        seg_file = os.path.join(self.seg_dir, "seg_0001.jsonl")
        os.makedirs(self.seg_dir, exist_ok=True)
        open(seg_file, "w").close()

        m.add_segment({"sequence": 1, "filename": "seg_0001.jsonl",
                        "state": "active", "entry_count": 10})
        g1 = m.generation
        m.add_tombstones({"h1": {"deleted_at": "now", "reason": "test"}})
        g2 = m.generation
        self.assertGreater(g2, g1)
        m.reset_hot()
        g3 = m.generation
        self.assertGreater(g3, g2)


class TestAddRemoveSegments(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.seg_dir = os.path.join(self.tmpdir, "segments")

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_add_segment(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        meta = {"sequence": 1, "filename": "seg_0001.jsonl",
                "state": "active", "entry_count": 100}
        m.add_segment(meta)
        self.assertEqual(len(m.segments), 1)
        self.assertEqual(m.segments[0]["sequence"], 1)

    def test_remove_segments(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        for i in range(1, 4):
            m.add_segment({"sequence": i, "filename": f"seg_{i:04d}.jsonl",
                           "state": "active", "entry_count": 50})
        self.assertEqual(len(m.segments), 3)
        m.remove_segments([1, 3])
        self.assertEqual(len(m.segments), 1)
        self.assertEqual(m.segments[0]["sequence"], 2)


class TestAddRemoveTombstones(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.seg_dir = os.path.join(self.tmpdir, "segments")

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_add_tombstones(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        ts = {"hash_a": {"deleted_at": "2026-01-01", "reason": "test"}}
        m.add_tombstones(ts)
        self.assertIn("hash_a", m.tombstones)

    def test_remove_tombstones(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        m.add_tombstones({
            "h1": {"deleted_at": "now", "reason": "a"},
            "h2": {"deleted_at": "now", "reason": "b"},
        })
        m.remove_tombstones({"h1"})
        self.assertNotIn("h1", m.tombstones)
        self.assertIn("h2", m.tombstones)


class TestTombstoneHashSet(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.seg_dir = os.path.join(self.tmpdir, "segments")

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_get_tombstone_hashes(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        m.add_tombstones({
            "h1": {"deleted_at": "now", "reason": "a"},
            "h2": {"deleted_at": "now", "reason": "b"},
            "h3": {"deleted_at": "now", "reason": "c"},
        })
        hashes = m.get_tombstone_hashes()
        self.assertIsInstance(hashes, set)
        self.assertEqual(hashes, {"h1", "h2", "h3"})

    def test_empty_tombstone_hashes(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        self.assertEqual(m.get_tombstone_hashes(), set())


class TestHotState(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.seg_dir = os.path.join(self.tmpdir, "segments")

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_update_hot(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        m.update_hot(put_count=10, delete_count=2,
                     last_write_at="2026-03-30T00:00:00Z")
        hot = m.hot
        self.assertEqual(hot["put_count"], 10)
        self.assertEqual(hot["delete_count"], 2)
        self.assertEqual(hot["last_write_at"], "2026-03-30T00:00:00Z")

    def test_reset_hot(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        m.update_hot(99, 5, "2026-03-30T00:00:00Z")
        m.reset_hot()
        hot = m.hot
        self.assertEqual(hot["put_count"], 0)
        self.assertEqual(hot["delete_count"], 0)
        self.assertIsNone(hot["last_write_at"])


class TestBackupCreation(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.seg_dir = os.path.join(self.tmpdir, "segments")

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_backup_created_on_second_write(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        m.add_tombstones({"h1": {"deleted_at": "now", "reason": "a"}})
        m.add_tombstones({"h2": {"deleted_at": "later", "reason": "b"}})
        bak = os.path.join(self.seg_dir, "manifest.json.bak")
        self.assertTrue(os.path.exists(bak))
        with open(bak) as f:
            bak_data = json.load(f)
        self.assertEqual(bak_data["generation"], 1)

    def test_backup_reflects_previous_generation(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        m.add_tombstones({"h1": {"deleted_at": "now", "reason": "a"}})
        m.add_tombstones({"h2": {"deleted_at": "now", "reason": "b"}})
        m.add_tombstones({"h3": {"deleted_at": "now", "reason": "c"}})
        with open(os.path.join(self.seg_dir, "manifest.json.bak")) as f:
            bak = json.load(f)
        self.assertEqual(bak["generation"], 2)

    def test_atomic_backup_survives_simulated_crash(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        m.add_tombstones({"h1": {"deleted_at": "now", "reason": "a"}})
        m.add_tombstones({"h2": {"deleted_at": "later", "reason": "b"}})

        original_backup = os.path.join(self.seg_dir, "manifest.json.bak")
        with open(original_backup) as f:
            before = json.load(f)

        original_replace = os.replace

        def crash_replace(src, dst):
            if dst == original_backup:
                raise OSError("simulated crash during backup rename")
            return original_replace(src, dst)

        with mock.patch("parsica_memory.storage.manifest.os.replace", side_effect=crash_replace):
            m.add_tombstones({"h3": {"deleted_at": "later", "reason": "c"}})

        with open(original_backup) as f:
            after = json.load(f)
        self.assertEqual(after, before)


class TestRecoveryFromBackup(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.seg_dir = os.path.join(self.tmpdir, "segments")
        os.makedirs(self.seg_dir, exist_ok=True)

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_corrupt_primary_falls_back_to_backup(self):
        from parsica_memory.storage.manifest import Manifest

        bak_data = {
            "version": "3.2.0", "generation": 7,
            "created_at": "t", "updated_at": "t",
            "segments": [], "hot": {"filename": "hot.jsonl",
            "put_count": 0, "delete_count": 0, "last_write_at": None},
            "tombstones": {}, "search": {"index_generation": 7},
            "migration": None,
        }
        bak_path = os.path.join(self.seg_dir, "manifest.json.bak")
        with open(bak_path, "w") as f:
            json.dump(bak_data, f)

        mpath = os.path.join(self.seg_dir, "manifest.json")
        with open(mpath, "w") as f:
            f.write("{broken json!!!!")

        m = Manifest(self.seg_dir)
        self.assertEqual(m.generation, 7)

    def test_both_missing_creates_fresh(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        self.assertEqual(m.generation, 0)

    def test_both_corrupt_creates_fresh(self):
        from parsica_memory.storage.manifest import Manifest
        for name in ("manifest.json", "manifest.json.bak"):
            with open(os.path.join(self.seg_dir, name), "w") as f:
                f.write("NOT JSON")
        m = Manifest(self.seg_dir)
        self.assertEqual(m.generation, 0)


class TestOptimisticConcurrency(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.seg_dir = os.path.join(self.tmpdir, "segments")

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_disk_change_between_load_and_save_raises_conflict(self):
        from parsica_memory.storage.manifest import Manifest, ManifestConflictError

        m1 = Manifest(self.seg_dir)
        m1.add_tombstones({"a": {"deleted_at": "now", "reason": "first"}})

        stale = Manifest(self.seg_dir)
        m1.add_tombstones({"b": {"deleted_at": "later", "reason": "second"}})

        with self.assertRaises(ManifestConflictError):
            stale.save()

        with self.assertRaises(ManifestConflictError):
            stale.add_tombstones({"c": {"deleted_at": "later", "reason": "stale"}})


class TestValidationMissingFiles(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.seg_dir = os.path.join(self.tmpdir, "segments")

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_missing_segment_file(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        m.add_segment({"sequence": 1, "filename": "seg_0001_missing.jsonl",
                        "state": "active", "entry_count": 50})
        errors = m.validate()
        self.assertTrue(any("seg_0001_missing.jsonl" in e for e in errors))

    def test_existing_segment_file_passes(self):
        from parsica_memory.storage.manifest import Manifest
        import hashlib
        m = Manifest(self.seg_dir)
        fname = "seg_0001.jsonl"
        os.makedirs(self.seg_dir, exist_ok=True)
        # Write non-empty content so entry_count=10 doesn't trigger the count
        # check; also compute a real checksum to satisfy the new validator.
        content = b'{"hash": "x"}\n' * 10
        fpath = os.path.join(self.seg_dir, fname)
        with open(fpath, "wb") as f:
            f.write(content)
        checksum = hashlib.sha256(content).hexdigest()
        m.add_segment({"sequence": 1, "filename": fname,
                        "state": "active", "entry_count": 10,
                        "checksum_sha256": checksum})
        errors = m.validate()
        file_errors = [e for e in errors if "missing" in e.lower()]
        self.assertEqual(file_errors, [])


class TestValidationDuplicateSequences(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.seg_dir = os.path.join(self.tmpdir, "segments")

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_duplicate_sequences(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        fname = "seg_dup.jsonl"
        os.makedirs(self.seg_dir, exist_ok=True)
        open(os.path.join(self.seg_dir, fname), "w").close()
        m.add_segment({"sequence": 1, "filename": fname,
                        "state": "active", "entry_count": 10})
        m.add_segment({"sequence": 1, "filename": fname,
                        "state": "active", "entry_count": 20})
        errors = m.validate()
        self.assertTrue(any("Duplicate" in e for e in errors))


class TestEmptyStore(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.seg_dir = os.path.join(self.tmpdir, "segments")

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_empty_store_valid(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        self.assertEqual(m.segments, [])
        self.assertEqual(m.tombstones, {})
        errors = m.validate()
        self.assertEqual(errors, [])


class TestConcurrentSafety(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.seg_dir = os.path.join(self.tmpdir, "segments")

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_concurrent_saves_serialized(self):
        from parsica_memory.storage.manifest import Manifest

        m = Manifest(self.seg_dir)
        m.save()

        errors = []
        save_count = 10

        def do_saves():
            try:
                inst = Manifest(self.seg_dir)
                for _ in range(save_count):
                    inst.save()
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=do_saves) for _ in range(3)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=30)

        self.assertEqual(errors, [])

        with open(os.path.join(self.seg_dir, "manifest.json")) as f:
            data = json.load(f)
        self.assertIsInstance(data["generation"], int)
        self.assertEqual(data["generation"], 0)

    def test_locked_init_prevents_race(self):
        from parsica_memory.storage.manifest import Manifest

        os.makedirs(self.seg_dir, exist_ok=True)
        gate = threading.Event()
        release = threading.Event()
        started = []

        original_try_read = Manifest._try_read

        def slow_try_read(self, path):
            if path.endswith("manifest.json") and not started:
                started.append(True)
                gate.set()
                release.wait(timeout=5)
            return original_try_read(self, path)

        def build_manifest():
            Manifest(self.seg_dir)

        with mock.patch.object(Manifest, "_try_read", slow_try_read):
            t1 = threading.Thread(target=build_manifest)
            t2 = threading.Thread(target=build_manifest)
            t1.start()
            gate.wait(timeout=5)
            t2.start()
            time.sleep(0.1)
            self.assertTrue(t1.is_alive())
            self.assertTrue(t2.is_alive())
            release.set()
            t1.join(timeout=5)
            t2.join(timeout=5)

        self.assertFalse(t1.is_alive())
        self.assertFalse(t2.is_alive())


class TestRoundTrip(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.seg_dir = os.path.join(self.tmpdir, "segments")

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_roundtrip(self):
        from parsica_memory.storage.manifest import Manifest

        m1 = Manifest(self.seg_dir)
        os.makedirs(self.seg_dir, exist_ok=True)
        seg_file = "seg_0001.jsonl"
        open(os.path.join(self.seg_dir, seg_file), "w").close()
        m1.add_segment({"sequence": 1, "filename": seg_file,
                         "state": "active", "entry_count": 42,
                         "originals_count": 40, "derived_count": 2,
                         "agent_ids": ["moro"],
                         "categories": {"conversation": 42}})
        m1.add_tombstones({"deadbeef": {"deleted_at": "2026-01-01",
                                         "reason": "test"}})
        m1.update_hot(put_count=5, delete_count=1,
                      last_write_at="2026-03-30T12:00:00Z")
        m1.save()

        m2 = Manifest(self.seg_dir)
        self.assertEqual(m2.generation, m1.generation)
        self.assertEqual(len(m2.segments), 1)
        self.assertEqual(m2.segments[0]["entry_count"], 42)
        self.assertIn("deadbeef", m2.tombstones)
        self.assertEqual(m2.hot["put_count"], 5)


class TestFutureProofFields(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.seg_dir = os.path.join(self.tmpdir, "segments")

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_segment_preserves_all_fields(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        meta = {
            "sequence": 1,
            "filename": "seg_0001.jsonl",
            "state": "active",
            "entry_count": 100,
            "min_created": "2026-01-01",
            "max_created": "2026-03-01",
            "size_bytes": 123456,
            "checksum_sha256": "abcdef0123456789",
            "categories": {"conversation": 80, "strategic": 20},
            "memory_types": {"episodic": 90, "fact": 10},
            "originals_count": 95,
            "derived_count": 5,
            "agent_ids": ["moro"],
            "session_ids_sample": ["sess_1", "sess_2"],
            "source_channels": ["discord:123"],
            "has_lineage_fields": False,
            "flushed_at": "2026-03-30T00:00:00Z",
        }
        m.add_segment(meta)
        stored = m.segments[0]
        for key in meta:
            self.assertEqual(stored[key], meta[key],
                             f"Field {key!r} not preserved")


class TestNextSequence(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.seg_dir = os.path.join(self.tmpdir, "segments")

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_monotonic(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        seq1 = m.next_sequence()
        seq2 = m.next_sequence()
        seq3 = m.next_sequence()
        self.assertEqual(seq1, 1)
        self.assertEqual(seq2, 2)
        self.assertEqual(seq3, 3)

    def test_persisted_across_reload(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        m.next_sequence()
        m.next_sequence()

        m2 = Manifest(self.seg_dir)
        seq = m2.next_sequence()
        self.assertEqual(seq, 3)


class TestBatchUpdate(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.seg_dir = os.path.join(self.tmpdir, "segments")

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_batch_update_single_lock_acquisition(self):
        from parsica_memory.storage.manifest import Manifest

        m = Manifest(self.seg_dir)
        with mock.patch.object(m, "_verify_generation", wraps=m._verify_generation) as verify_mock, \
             mock.patch.object(m, "_backup", wraps=m._backup) as backup_mock, \
             mock.patch.object(m, "_write_to_disk_unlocked", wraps=m._write_to_disk_unlocked) as write_mock:
            with m.batch_update() as manifest:
                manifest._data.setdefault("tombstones", {})["h1"] = {
                    "deleted_at": "now",
                    "reason": "test",
                }
                manifest._data["hot"] = {
                    "filename": "hot.jsonl",
                    "put_count": 0,
                    "delete_count": 0,
                    "last_write_at": None,
                }

        self.assertEqual(verify_mock.call_count, 1)
        self.assertEqual(backup_mock.call_count, 1)
        self.assertEqual(write_mock.call_count, 1)
        self.assertEqual(m.generation, 1)
        self.assertIn("h1", m.tombstones)

    def test_batch_update_rollback_on_error(self):
        from parsica_memory.storage.manifest import Manifest

        m = Manifest(self.seg_dir)
        m.add_tombstones({"existing": {"deleted_at": "now", "reason": "seed"}})
        before = m.data

        with self.assertRaises(RuntimeError):
            with m.batch_update() as manifest:
                manifest._data.setdefault("tombstones", {})["new"] = {
                    "deleted_at": "later",
                    "reason": "boom",
                }
                raise RuntimeError("boom")

        reloaded = Manifest(self.seg_dir)
        self.assertEqual(reloaded.data, before)
        self.assertNotIn("new", reloaded.tombstones)


class TestMigrationMetadata(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.seg_dir = os.path.join(self.tmpdir, "segments")

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_set_migration(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        self.assertIsNone(m.migration)
        meta = {
            "migrated_from": "enterprise_shards",
            "migrated_at": "2026-03-30T00:00:00Z",
            "source_entry_count": 24715,
            "legacy_backup": "shards.pre_segments_backup",
        }
        m.set_migration(meta)
        self.assertEqual(m.migration["source_entry_count"], 24715)

        m2 = Manifest(self.seg_dir)
        self.assertEqual(m2.migration["migrated_from"], "enterprise_shards")


class TestReprAndAccessors(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.seg_dir = os.path.join(self.tmpdir, "segments")

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_repr(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        r = repr(m)
        self.assertIn("Manifest", r)
        self.assertIn("gen=0", r)
        self.assertIn("segments=0", r)

    def test_data_is_deep_copy(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        d = m.data
        d["generation"] = 9999
        self.assertEqual(m.generation, 0)

    def test_segments_is_copy(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        segs = m.segments
        segs.append({"fake": True})
        self.assertEqual(m.segments, [])

    def test_tombstones_is_copy(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        m.add_tombstones({"h1": {"deleted_at": "now", "reason": "x"}})
        ts = m.tombstones
        ts["h1"]["reason"] = "MUTATED"
        self.assertEqual(m.tombstones["h1"]["reason"], "x")


if __name__ == "__main__":
    unittest.main()
