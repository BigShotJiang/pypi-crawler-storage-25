"""
Integration tests for Parsica Memory v3.4.0+ — Ambient Awareness (trigger-based).

v3.4.1 update: Session lifecycle is now trigger-based (begin_turn/end_turn)
instead of TTL-based (session_start/session_end).  The session_awareness
parameter replaces the old ambient_awareness bool with a 3-value string:
  - "off"    : no gate, full backward compat (default)
  - "open"   : warn on idle writes but allow
  - "closed" : block idle writes (strict)

Tests:
  1.  Backward compatibility — no tracker, no gate (session_awareness="off")
  2.  Write gate _check_write_gate logic (unit)
  3.  Write gate integration — ingest()
  4.  Write gate integration — ingest_mistake()
  5.  Write gate integration — _ingest_typed()
  6.  Write gate integration — forget()
  7.  Search read_only mode
  8.  DedupEngine integration
  9.  Full lifecycle (begin_turn/end_turn through MemorySystem public API)
  10. 3-mode configuration tests
  11. synthesize() and shared_write() write gate

All tests use unittest and zero external dependencies.
"""
from __future__ import annotations

import os
import sys
import tempfile
import unittest
import warnings
from unittest.mock import MagicMock, patch

# Ensure the package root is on the path when running from tests/ directly
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from parsica_memory.core_v4 import MemorySystemV4


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _make_tracker(active_sessions=None, idle_sessions=None):
    """Build a mock SessionTracker compatible with the trigger-based API."""
    active_sessions = set(active_sessions or [])
    idle_sessions = set(idle_sessions or [])

    tracker = MagicMock()

    def _is_write_allowed(session_id):
        # registered-and-idle → deny; everything else → allow (fail-open)
        if session_id in idle_sessions:
            return False
        return True  # unregistered or active → allow

    tracker.is_write_allowed.side_effect = _is_write_allowed
    tracker.begin_turn.return_value = None
    tracker.end_turn.return_value = None
    tracker.add_task.return_value = True   # accepted
    tracker.complete_task.return_value = None
    tracker.get_ambient_context.return_value = []
    tracker.update_memory_summary.return_value = None
    return tracker


def _make_dedup(duplicate_hash=None):
    """Build a mock DedupEngine.

    duplicate_hash: If set, is_duplicate always returns this hash string
                    (simulating a detected duplicate). If None, always returns None
                    (unique content).
    """
    dedup = MagicMock()
    dedup.is_duplicate.return_value = duplicate_hash
    return dedup


def _mem(workspace, session_awareness="off", ambient_awareness=False):
    """Create a MemorySystemV4 with minimal config."""
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        return MemorySystemV4(
            workspace=workspace,
            use_sharding=False,
            sharding=False,
            graph_intelligence=False,
            quality_routing=False,
            semantic_expansion=False,
            agent_name="test-agent",
            session_awareness=session_awareness,
            ambient_awareness=ambient_awareness,
        )


# ─────────────────────────────────────────────────────────────────────────────
# 1. Backward Compatibility — no tracker, no gate
# ─────────────────────────────────────────────────────────────────────────────

class TestBackwardCompatNoTracker(unittest.TestCase):
    """session_awareness="off" (default) → zero gate, zero dedup overhead."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.mem = _mem(self.tmp, session_awareness="off")

    def test_session_tracker_is_none_by_default(self):
        self.assertIsNone(self.mem._session_tracker)

    def test_dedup_engine_is_none_by_default(self):
        self.assertIsNone(self.mem._dedup_engine)

    def test_session_awareness_off(self):
        self.assertEqual(self.mem._session_awareness, "off")

    def test_check_write_gate_always_true_without_tracker(self):
        """_check_write_gate returns True when no tracker — full backward compat."""
        self.assertTrue(self.mem._check_write_gate("any-session", "ingest"))
        self.assertTrue(self.mem._check_write_gate(None, "ingest"))
        self.assertTrue(self.mem._check_write_gate("idle-session", "forget"))

    def test_ingest_works_without_session_id(self):
        count = self.mem.ingest("This is a valid memory entry for testing purposes.")
        self.assertGreater(count, 0)

    def test_ingest_works_with_session_id_no_tracker(self):
        count = self.mem.ingest(
            "Another valid memory entry for backward compatibility test.",
            session_id="some-session",
        )
        self.assertGreater(count, 0)

    def test_begin_turn_noop_when_off(self):
        """begin_turn is a no-op when session_awareness="off"."""
        # Should not raise
        self.mem.begin_turn("any-session")

    def test_end_turn_noop_when_off(self):
        """end_turn is a no-op when session_awareness="off"."""
        self.mem.end_turn("any-session")

    def test_add_task_returns_empty_when_off(self):
        """add_task returns "" when session_awareness="off"."""
        result = self.mem.add_task("any-session", "my-task")
        self.assertEqual(result, "")

    def test_complete_task_noop_when_off(self):
        """complete_task is a no-op when session_awareness="off"."""
        self.mem.complete_task("any-session", "my-task")


# ─────────────────────────────────────────────────────────────────────────────
# 2. Write Gate — _check_write_gate logic
# ─────────────────────────────────────────────────────────────────────────────

class TestCheckWriteGate(unittest.TestCase):
    """Unit tests for the _check_write_gate helper."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.mem = _mem(self.tmp)

    def test_no_tracker_always_allows(self):
        self.mem._session_tracker = None
        self.mem._session_awareness = "off"
        self.assertTrue(self.mem._check_write_gate("any-session"))
        self.assertTrue(self.mem._check_write_gate(None))

    def test_open_mode_none_session_allows(self):
        """OPEN mode: None session_id always allowed (legacy callers)."""
        self.mem._session_tracker = _make_tracker(idle_sessions=["session-a"])
        self.mem._session_awareness = "open"
        self.assertTrue(self.mem._check_write_gate(None, "ingest"))

    def test_open_mode_active_session_allowed(self):
        self.mem._session_tracker = _make_tracker(active_sessions=["session-a"])
        self.mem._session_awareness = "open"
        self.assertTrue(self.mem._check_write_gate("session-a", "ingest"))

    def test_open_mode_idle_session_allowed_but_warns(self):
        """OPEN mode: idle session write is allowed but logs a warning."""
        self.mem._session_tracker = _make_tracker(idle_sessions=["session-idle"])
        self.mem._session_awareness = "open"
        with self.assertLogs("parsica_memory", level="WARNING"):
            result = self.mem._check_write_gate("session-idle", "ingest")
        self.assertTrue(result)  # OPEN: always allows

    def test_closed_mode_active_session_allowed(self):
        self.mem._session_tracker = _make_tracker(active_sessions=["session-a"])
        self.mem._session_awareness = "closed"
        self.assertTrue(self.mem._check_write_gate("session-a", "ingest"))

    def test_closed_mode_idle_session_blocked(self):
        self.mem._session_tracker = _make_tracker(idle_sessions=["session-idle"])
        self.mem._session_awareness = "closed"
        self.assertFalse(self.mem._check_write_gate("session-idle", "ingest"))

    def test_closed_mode_unregistered_session_blocked(self):
        """CLOSED mode: unregistered sessions are blocked (strict enforcement)."""
        from parsica_memory.session_tracker import SessionTracker
        real_tracker = SessionTracker(mode="closed")
        real_tracker.begin_turn("other-session")  # register one session
        real_tracker.end_turn("other-session")     # idle it
        self.mem._session_tracker = real_tracker
        self.mem._session_awareness = "closed"
        # "unknown-session" has no entry → blocked in closed mode
        self.assertFalse(self.mem._check_write_gate("unknown-session", "ingest"))

    def test_off_mode_always_allows_even_with_tracker(self):
        """OFF mode: ignores tracker entirely."""
        self.mem._session_tracker = _make_tracker(idle_sessions=["session-idle"])
        self.mem._session_awareness = "off"
        self.assertTrue(self.mem._check_write_gate("session-idle", "ingest"))


# ─────────────────────────────────────────────────────────────────────────────
# 3. Write Gate Integration — ingest()
# ─────────────────────────────────────────────────────────────────────────────

class TestWriteGateIngest(unittest.TestCase):

    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.mem = _mem(self.tmp)

    def _install_closed_tracker(self, idle=None, active=None):
        self.mem._session_tracker = _make_tracker(idle_sessions=idle, active_sessions=active)
        self.mem._session_awareness = "closed"

    def test_idle_session_ingest_returns_zero(self):
        self._install_closed_tracker(idle=["idle-session"])
        count = self.mem.ingest(
            "This is a substantial memory that should be blocked by write gate.",
            session_id="idle-session",
        )
        self.assertEqual(count, 0)

    def test_idle_session_ingest_stores_nothing(self):
        self._install_closed_tracker(idle=["idle-session"])
        before = len(self.mem.memories)
        self.mem.ingest(
            "Content that should be blocked by the write gate for idle sessions.",
            session_id="idle-session",
        )
        self.assertEqual(len(self.mem.memories), before)

    def test_active_session_ingest_succeeds(self):
        self._install_closed_tracker(active=["active-session"])
        count = self.mem.ingest(
            "This is a valid memory entry that should be ingested by active session.",
            session_id="active-session",
        )
        self.assertGreater(count, 0)

    def test_no_session_id_ingest_always_succeeds(self):
        self._install_closed_tracker(idle=["other-session"])
        count = self.mem.ingest(
            "Memory with no session id should always be allowed through the write gate."
        )
        self.assertGreater(count, 0)

    def test_write_gate_checked_before_processing(self):
        """Gate fires before ANY processing — should not call enricher for idle."""
        enricher = MagicMock(return_value={"tags": ["test"], "summary": "test"})
        self.mem._enricher = enricher
        self._install_closed_tracker(idle=["idle-session"])
        self.mem.ingest(
            "This content should be blocked and the enricher should not be called.",
            session_id="idle-session",
        )
        enricher.assert_not_called()


# ─────────────────────────────────────────────────────────────────────────────
# 4. Write Gate Integration — ingest_mistake()
# ─────────────────────────────────────────────────────────────────────────────

class TestWriteGateIngestMistake(unittest.TestCase):

    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.mem = _mem(self.tmp)

    def test_idle_session_ingest_mistake_blocked(self):
        self.mem._session_tracker = _make_tracker(idle_sessions=["idle-session"])
        self.mem._session_awareness = "closed"
        result = self.mem.ingest_mistake(
            what_happened="Something went wrong in the system",
            correction="Use the correct approach next time",
            session_id="idle-session",
        )
        self.assertIsNone(result)

    def test_active_session_ingest_mistake_allowed(self):
        self.mem._session_tracker = _make_tracker(active_sessions=["active-session"])
        self.mem._session_awareness = "closed"
        result = self.mem.ingest_mistake(
            what_happened="Something went wrong in the system",
            correction="Use the correct approach next time",
            session_id="active-session",
        )
        # Returns MemoryEntry or None (None = duplicate), but NOT because of gate
        self.assertTrue(
            result is not None or len(self.mem.memories) > 0
        )

    def test_no_session_id_mistake_always_allowed(self):
        self.mem._session_tracker = _make_tracker(idle_sessions=["idle"])
        self.mem._session_awareness = "closed"
        # session_id=None → gate short-circuits (returns True without calling tracker)
        result = self.mem.ingest_mistake(
            what_happened="Mistake without session binding",
            correction="Use correct session bindings going forward",
        )
        # Verify ingest_mistake ran (no exception raised)
        self.assertTrue(True)  # reached here without exception


# ─────────────────────────────────────────────────────────────────────────────
# 5. Write Gate Integration — _ingest_typed()
# ─────────────────────────────────────────────────────────────────────────────

class TestWriteGateIngestTyped(unittest.TestCase):

    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.mem = _mem(self.tmp)

    def test_idle_session_ingest_fact_blocked(self):
        self.mem._session_tracker = _make_tracker(idle_sessions=["idle-session"])
        self.mem._session_awareness = "closed"
        count = self.mem.ingest_fact(
            "The sky is blue and it has been established by science over many years.",
            session_id="idle-session",
        )
        self.assertEqual(count, 0)

    def test_idle_session_ingest_preference_blocked(self):
        self.mem._session_tracker = _make_tracker(idle_sessions=["idle-session"])
        self.mem._session_awareness = "closed"
        count = self.mem.ingest_preference(
            "User strongly prefers dark mode interfaces for all applications they use.",
            session_id="idle-session",
        )
        self.assertEqual(count, 0)

    def test_active_session_ingest_fact_allowed(self):
        self.mem._session_tracker = _make_tracker(active_sessions=["active-session"])
        self.mem._session_awareness = "closed"
        count = self.mem.ingest_fact(
            "Python was created by Guido van Rossum and first released in 1991.",
            session_id="active-session",
        )
        self.assertGreater(count, 0)


# ─────────────────────────────────────────────────────────────────────────────
# 6. Write Gate Integration — forget()
# ─────────────────────────────────────────────────────────────────────────────

class TestWriteGateForget(unittest.TestCase):

    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.mem = _mem(self.tmp)

    def test_idle_session_forget_blocked(self):
        # Ingest a memory without session gating first
        self.mem.ingest(
            "Important memory about the deployment pipeline that must be preserved.",
            session_id=None,
        )
        before = len(self.mem.memories)

        self.mem._session_tracker = _make_tracker(idle_sessions=["idle-session"])
        self.mem._session_awareness = "closed"
        result = self.mem.forget(topic="deployment", session_id="idle-session")

        # Forget should return empty removed list
        self.assertEqual(len(result["removed"]), 0)
        # Memories should be unchanged
        self.assertEqual(len(self.mem.memories), before)

    def test_no_session_id_forget_allowed(self):
        self.mem.ingest(
            "Temporary memory about a test topic that should be forgettable.",
            session_id=None,
        )
        self.mem._session_tracker = _make_tracker(idle_sessions=["idle"])
        self.mem._session_awareness = "closed"
        # No session_id = gate passes
        result = self.mem.forget(topic="test topic")
        # Should not raise and should return a valid dict
        self.assertIn("removed", result)


# ─────────────────────────────────────────────────────────────────────────────
# 7. Search read_only mode
# ─────────────────────────────────────────────────────────────────────────────

class TestSearchReadOnly(unittest.TestCase):

    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.mem = _mem(self.tmp)
        # Ingest some searchable content
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            self.mem.ingest(
                "The deployment pipeline runs automated tests before shipping to production.",
                session_id=None,
            )
            self.mem.ingest(
                "The memory system uses BM25 ranking for efficient search and retrieval.",
                session_id=None,
            )

    def test_read_only_search_returns_results(self):
        """read_only=True must still return search results."""
        results = self.mem.search("deployment", read_only=True)
        self.assertIsInstance(results, list)
        self.assertGreater(len(results), 0)

    def test_read_only_search_does_not_increment_access_count(self):
        """read_only=True must not increment access counts."""
        results = self.mem.search("deployment", read_only=True)
        if not results:
            self.skipTest("No results to test access count on")

        entry = results[0]
        count_before = entry.access_count

        self.mem.search("deployment", read_only=True)

        mem_entry = next(
            (m for m in self.mem.memories if m.hash == entry.hash), None
        )
        if mem_entry is None:
            self.skipTest("Entry not found in memories after search")

        self.assertEqual(mem_entry.access_count, count_before)

    def test_normal_search_does_reinforce_decay(self):
        """Normal search (read_only=False) SHOULD call decay.reinforce."""
        with patch.object(self.mem.decay, 'reinforce') as mock_reinforce:
            results = self.mem.search("deployment", read_only=False)
            if results:
                mock_reinforce.assert_called()

    def test_read_only_search_does_not_reinforce_decay(self):
        """read_only=True search should NOT call decay.reinforce."""
        with patch.object(self.mem.decay, 'reinforce') as mock_reinforce:
            self.mem.search("deployment", read_only=True)
            mock_reinforce.assert_not_called()

    def test_read_only_does_not_call_record_access(self):
        """read_only=True should not call _record_access."""
        with patch.object(self.mem, '_record_access') as mock_record:
            self.mem.search("memory", read_only=True)
            mock_record.assert_not_called()

    def test_normal_search_calls_record_access(self):
        """Normal search should call _record_access for returned entries."""
        with patch.object(self.mem, '_record_access') as mock_record:
            results = self.mem.search("memory", read_only=False)
            if results:
                mock_record.assert_called()

    def test_read_only_search_same_results_as_normal(self):
        """read_only search returns same entries as normal search (just no mutation)."""
        normal_results = self.mem.search("deployment pipeline", read_only=False)
        readonly_results = self.mem.search("deployment pipeline", read_only=True)

        self.assertEqual(len(normal_results), len(readonly_results))

        normal_hashes = {getattr(r, 'hash', str(r)) for r in normal_results}
        readonly_hashes = {getattr(r, 'hash', str(r)) for r in readonly_results}
        self.assertEqual(normal_hashes, readonly_hashes)


# ─────────────────────────────────────────────────────────────────────────────
# 8. DedupEngine integration
# ─────────────────────────────────────────────────────────────────────────────

class TestDedupEngineIntegration(unittest.TestCase):

    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.mem = _mem(self.tmp)

    def test_dedup_blocks_duplicate_content(self):
        """When DedupEngine returns a hash, ingest should return 0."""
        self.mem._dedup_engine = _make_dedup(duplicate_hash="abc123")
        count = self.mem.ingest(
            "This is content that the dedup engine thinks is a duplicate entry."
        )
        self.assertEqual(count, 0)

    def test_dedup_stores_nothing_for_duplicate(self):
        self.mem._dedup_engine = _make_dedup(duplicate_hash="abc123")
        before = len(self.mem.memories)
        self.mem.ingest(
            "Duplicate content that should not be stored in the memory system."
        )
        self.assertEqual(len(self.mem.memories), before)

    def test_dedup_allows_unique_content(self):
        """When DedupEngine returns None (unique), ingest proceeds normally."""
        self.mem._dedup_engine = _make_dedup(duplicate_hash=None)
        count = self.mem.ingest(
            "This is unique content that the dedup engine allows through normally."
        )
        self.assertGreater(count, 0)

    def test_dedup_engine_receives_content_and_memories(self):
        """DedupEngine.is_duplicate is called with the content and memories list."""
        self.mem._dedup_engine = _make_dedup(duplicate_hash=None)
        content = "Content passed to dedup engine for duplicate checking purposes."
        self.mem.ingest(content)
        self.mem._dedup_engine.is_duplicate.assert_called_once_with(
            content, self.mem.memories
        )

    def test_dedup_not_called_when_engine_is_none(self):
        """When _dedup_engine is None, no dedup check runs (backward compat)."""
        self.assertIsNone(self.mem._dedup_engine)
        count = self.mem.ingest(
            "Content ingested when dedup engine is disabled for backward compat."
        )
        self.assertGreater(count, 0)

    def test_dedup_checked_before_hash_dedup(self):
        """DedupEngine is checked at entry of ingest, before line-level processing."""
        self.mem._dedup_engine = _make_dedup(duplicate_hash="xyz789")
        self.mem.ingest(
            "Line one of a multi-line content block that is a duplicate entry.\n"
            "Line two of the duplicate content block for testing purposes."
        )
        # Called once per ingest() call, not per line
        self.assertEqual(self.mem._dedup_engine.is_duplicate.call_count, 1)


# ─────────────────────────────────────────────────────────────────────────────
# 9. Full Lifecycle — begin_turn/end_turn through MemorySystem public API
# ─────────────────────────────────────────────────────────────────────────────

class TestFullLifecycleBeginEndTurn(unittest.TestCase):
    """End-to-end lifecycle using the trigger-based begin_turn/end_turn API."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.mem = _mem(self.tmp)

    def _install_real_tracker(self):
        """Install a mutable tracker that simulates trigger-based SessionTracker state."""
        class _TriggerTracker:
            def __init__(self):
                self._active = set()
                self._idle = set()
                self._pending_tasks = {}  # session_id → {task_name: time}
                self._turn_depth = {}    # session_id → int

            def begin_turn(self, sid):
                self._idle.discard(sid)
                self._active.add(sid)
                self._turn_depth[sid] = self._turn_depth.get(sid, 0) + 1

            def end_turn(self, sid):
                depth = self._turn_depth.get(sid, 1)
                depth = max(0, depth - 1)
                self._turn_depth[sid] = depth
                if depth == 0 and not self._pending_tasks.get(sid):
                    self._active.discard(sid)
                    self._idle.add(sid)

            def add_task(self, sid, task_name):
                if sid not in self._active:
                    return False
                if sid not in self._pending_tasks:
                    self._pending_tasks[sid] = {}
                self._pending_tasks[sid][task_name] = True
                return True

            def complete_task(self, sid, task_name):
                if sid in self._pending_tasks:
                    self._pending_tasks[sid].pop(task_name, None)
                    if not self._pending_tasks[sid] and self._turn_depth.get(sid, 0) == 0:
                        self._active.discard(sid)
                        self._idle.add(sid)

            def is_write_allowed(self, sid):
                if sid in self._idle:
                    return False
                return True

            def is_active(self, sid):
                return sid in self._active

            def get_ambient_context(self, sid, limit=5):
                return []

            def update_memory_summary(self, sid, summary):
                pass

        return _TriggerTracker()

    def test_begin_turn_allows_ingest(self):
        tracker = self._install_real_tracker()
        self.mem._session_tracker = tracker
        self.mem._session_awareness = "closed"

        self.mem.begin_turn("session-alpha")
        count = self.mem.ingest(
            "Active session memory: the deployment was successful yesterday.",
            session_id="session-alpha",
        )
        self.assertGreater(count, 0)

    def test_end_turn_blocks_ingest(self):
        tracker = self._install_real_tracker()
        self.mem._session_tracker = tracker
        self.mem._session_awareness = "closed"

        # Start, ingest, then end
        self.mem.begin_turn("session-alpha")
        self.mem.ingest(
            "Active session memory: the deployment was successful yesterday.",
            session_id="session-alpha",
        )
        self.mem.end_turn("session-alpha")

        # After end_turn, ingest should be blocked
        count = self.mem.ingest(
            "Post-session memory: this should be blocked after session ended.",
            session_id="session-alpha",
        )
        self.assertEqual(count, 0)

    def test_search_always_allowed_after_end_turn(self):
        tracker = self._install_real_tracker()
        self.mem._session_tracker = tracker
        self.mem._session_awareness = "closed"

        self.mem.begin_turn("session-alpha")
        self.mem.ingest(
            "Active session memory: the deployment was successful yesterday.",
            session_id="session-alpha",
        )
        self.mem.end_turn("session-alpha")

        # Search is never gated — should still work
        results = self.mem.search("deployment")
        self.assertIsInstance(results, list)

    def test_second_begin_turn_reactivates_session(self):
        """begin_turn on an ended session re-enables writes."""
        tracker = self._install_real_tracker()
        self.mem._session_tracker = tracker
        self.mem._session_awareness = "closed"

        # First cycle
        self.mem.begin_turn("session-beta")
        self.mem.ingest(
            "First cycle memory ingested during active session beta phase.",
            session_id="session-beta",
        )
        self.mem.end_turn("session-beta")

        # Verify blocked
        count = self.mem.ingest(
            "Blocked memory that should not be ingested during idle phase.",
            session_id="session-beta",
        )
        self.assertEqual(count, 0)

        # Re-activate
        self.mem.begin_turn("session-beta")
        count = self.mem.ingest(
            "Second cycle memory ingested after session was restarted again.",
            session_id="session-beta",
        )
        self.assertGreater(count, 0)

    def test_multiple_sessions_independent_gates(self):
        """Two sessions can be active/idle independently."""
        tracker = self._install_real_tracker()
        self.mem._session_tracker = tracker
        self.mem._session_awareness = "closed"

        self.mem.begin_turn("session-a")
        self.mem.begin_turn("session-b")
        self.mem.end_turn("session-a")  # only A is ended

        # B should still be able to write
        count_b = self.mem.ingest(
            "Session B is still active and should be able to write memories.",
            session_id="session-b",
        )
        self.assertGreater(count_b, 0)

        # A should be blocked
        count_a = self.mem.ingest(
            "Session A is idle and should be blocked from writing any memories.",
            session_id="session-a",
        )
        self.assertEqual(count_a, 0)

    def test_add_task_keep_session_active_after_end_turn(self):
        """Session stays ACTIVE after end_turn if pending tasks exist."""
        tracker = self._install_real_tracker()
        self.mem._session_tracker = tracker
        self.mem._session_awareness = "closed"

        self.mem.begin_turn("session-parent")
        task_name = self.mem.add_task("session-parent", "sub-agent-1")
        self.assertNotEqual(task_name, "")

        # end_turn before task completes — session should STAY active
        # (because pending_tasks > 0)
        self.mem.end_turn("session-parent")
        self.assertTrue(tracker.is_active("session-parent"))

        # Complete the task — now session should go idle
        self.mem.complete_task("session-parent", task_name)
        self.assertFalse(tracker.is_active("session-parent"))

    def test_is_session_active_reflects_state(self):
        tracker = self._install_real_tracker()
        self.mem._session_tracker = tracker
        self.mem._session_awareness = "closed"

        self.assertFalse(self.mem.is_session_active("session-x"))

        self.mem.begin_turn("session-x")
        self.assertTrue(self.mem.is_session_active("session-x"))

        self.mem.end_turn("session-x")
        self.assertFalse(self.mem.is_session_active("session-x"))

    def test_ambient_awareness_flag_initializes_none_without_modules(self):
        """session_awareness="closed" with missing modules → graceful None fallback."""
        import parsica_memory.core_v4 as _core
        orig_tracker = _core._SessionTracker
        orig_dedup = _core._DedupEngine

        try:
            _core._SessionTracker = None
            _core._DedupEngine = None

            mem = _mem(self.tmp, session_awareness="closed")
            self.assertIsNone(mem._session_tracker)
            self.assertIsNone(mem._dedup_engine)
        finally:
            _core._SessionTracker = orig_tracker
            _core._DedupEngine = orig_dedup


# ─────────────────────────────────────────────────────────────────────────────
# 10. 3-Mode Configuration Tests
# ─────────────────────────────────────────────────────────────────────────────

class TestThreeModeConfiguration(unittest.TestCase):
    """Tests for the 3 session_awareness modes: off, open, closed."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def test_off_mode_sets_session_awareness(self):
        mem = _mem(self.tmp, session_awareness="off")
        self.assertEqual(mem._session_awareness, "off")
        self.assertIsNone(mem._session_tracker)

    def test_open_mode_sets_session_awareness(self):
        mem = _mem(self.tmp, session_awareness="open")
        self.assertEqual(mem._session_awareness, "open")
        # Tracker is set (if available)

    def test_closed_mode_sets_session_awareness(self):
        mem = _mem(self.tmp, session_awareness="closed")
        self.assertEqual(mem._session_awareness, "closed")

    def test_legacy_ambient_awareness_bool_maps_to_closed(self):
        """ambient_awareness=True (legacy) maps to session_awareness='closed'."""
        mem = _mem(self.tmp, ambient_awareness=True)
        self.assertEqual(mem._session_awareness, "closed")

    def test_off_mode_ingest_always_works(self):
        """OFF mode: no gate, everything goes through."""
        mem = _mem(self.tmp, session_awareness="off")
        count = mem.ingest(
            "Memory ingested with no session gate active in off mode."
        )
        self.assertGreater(count, 0)

    def test_open_mode_idle_write_warns_but_allows(self):
        """OPEN mode: idle session write is allowed but logged as warning."""
        mem = _mem(self.tmp, session_awareness="open")
        mem._session_tracker = _make_tracker(idle_sessions=["idle-session"])

        with self.assertLogs("parsica_memory", level="WARNING"):
            result = mem._check_write_gate("idle-session", "ingest")

        self.assertTrue(result)  # OPEN: allows despite idle

    def test_open_mode_idle_write_actually_ingests(self):
        """OPEN mode: even idle sessions can successfully ingest content."""
        mem = _mem(self.tmp, session_awareness="open")
        mem._session_tracker = _make_tracker(idle_sessions=["idle-session"])

        # Suppress the warning log for this test
        import logging
        logging.getLogger("parsica_memory").setLevel(logging.ERROR)
        count = mem.ingest(
            "Memory ingested by idle session in open mode — should succeed.",
            session_id="idle-session",
        )
        logging.getLogger("parsica_memory").setLevel(logging.WARNING)
        self.assertGreater(count, 0)

    def test_closed_mode_idle_write_is_blocked(self):
        """CLOSED mode: idle session write is blocked (returns 0)."""
        mem = _mem(self.tmp, session_awareness="closed")
        mem._session_tracker = _make_tracker(idle_sessions=["idle-session"])

        count = mem.ingest(
            "Memory that should be blocked in closed mode for idle session.",
            session_id="idle-session",
        )
        self.assertEqual(count, 0)

    def test_closed_mode_active_session_ingests(self):
        """CLOSED mode: active session can write normally."""
        mem = _mem(self.tmp, session_awareness="closed")
        mem._session_tracker = _make_tracker(active_sessions=["active-session"])

        count = mem.ingest(
            "Memory written by active session in closed mode — should succeed.",
            session_id="active-session",
        )
        self.assertGreater(count, 0)

    def test_open_mode_no_session_id_always_allowed(self):
        """OPEN mode: anonymous writes (no session_id) always succeed."""
        mem = _mem(self.tmp, session_awareness="open")
        mem._session_tracker = _make_tracker(idle_sessions=["some-session"])
        count = mem.ingest(
            "Anonymous memory in open mode — no session id provided here."
        )
        self.assertGreater(count, 0)

    def test_closed_mode_no_session_id_uses_none_path(self):
        """CLOSED mode: no session_id falls through to tracker (backward compat path)."""
        mem = _mem(self.tmp, session_awareness="closed")
        mem._session_tracker = _make_tracker()  # no sessions tracked
        # With no sessions tracked, tracker returns True for None
        result = mem._check_write_gate(None, "ingest")
        # Should be allowed (no sessions tracked → backward compat)
        self.assertTrue(result)


# ─────────────────────────────────────────────────────────────────────────────
# 11. synthesize() and shared_write() write gate
# ─────────────────────────────────────────────────────────────────────────────

class TestWriteGateSynthesizeAndShared(unittest.TestCase):

    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.mem = _mem(self.tmp)

    def test_idle_session_synthesize_returns_empty(self):
        self.mem._session_tracker = _make_tracker(idle_sessions=["idle"])
        self.mem._session_awareness = "closed"
        result = self.mem.synthesize(session_id="idle")
        self.assertEqual(result.get("synthesized_entries", 0), 0)

    def test_idle_session_shared_write_returns_none(self):
        self.mem._session_tracker = _make_tracker(idle_sessions=["idle"])
        self.mem._session_awareness = "closed"
        result = self.mem.shared_write(
            "Content for shared pool",
            session_id="idle",
        )
        self.assertIsNone(result)

    def test_shared_write_no_pool_raises_only_when_active(self):
        """RuntimeError from shared_write should only fire for active sessions."""
        self.mem._session_tracker = _make_tracker(active_sessions=["active"])
        self.mem._session_awareness = "closed"
        with self.assertRaises(RuntimeError):
            self.mem.shared_write("Content", session_id="active")

    def test_synthesize_no_session_id_runs_normally(self):
        """synthesize() without session_id is not blocked (maintenance op)."""
        result = self.mem.synthesize()
        self.assertIsInstance(result, dict)


# ─────────────────────────────────────────────────────────────────────────────
# 12. Legacy session_start/session_end backward compat (removed → check no attr)
# ─────────────────────────────────────────────────────────────────────────────

class TestLegacyAPIRemoved(unittest.TestCase):
    """Verify the old session_start/session_end methods no longer exist."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.mem = _mem(self.tmp)

    def test_session_start_not_present(self):
        """session_start() was replaced by begin_turn() — should not exist."""
        self.assertFalse(
            hasattr(self.mem, 'session_start'),
            "session_start() should have been removed and replaced by begin_turn()",
        )

    def test_session_end_not_present(self):
        """session_end() was replaced by end_turn() — should not exist."""
        self.assertFalse(
            hasattr(self.mem, 'session_end'),
            "session_end() should have been removed and replaced by end_turn()",
        )

    def test_begin_turn_exists(self):
        self.assertTrue(hasattr(self.mem, 'begin_turn'))
        self.assertTrue(callable(self.mem.begin_turn))

    def test_end_turn_exists(self):
        self.assertTrue(hasattr(self.mem, 'end_turn'))
        self.assertTrue(callable(self.mem.end_turn))

    def test_add_task_exists(self):
        self.assertTrue(hasattr(self.mem, 'add_task'))
        self.assertTrue(callable(self.mem.add_task))

    def test_complete_task_exists(self):
        self.assertTrue(hasattr(self.mem, 'complete_task'))
        self.assertTrue(callable(self.mem.complete_task))

    def test_get_ambient_context_exists(self):
        self.assertTrue(hasattr(self.mem, 'get_ambient_context'))

    def test_is_session_active_exists(self):
        self.assertTrue(hasattr(self.mem, 'is_session_active'))


if __name__ == "__main__":
    unittest.main(verbosity=2)
