"""Tests for GPT Pro review fixes: sync bridge, parallel enricher segments,
and manifest semantic validation.

These test the three external persistence bypass bugs identified in the
Parsica 3.2.0 production readiness review (specs/parsica_3.2.0_PRO_REVIEW.md).
"""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import tempfile
import unittest
import warnings
from datetime import datetime, timedelta, timezone
from unittest import mock

from parsica_memory.core_v4 import MemorySystemV4
from parsica_memory.entry import MemoryEntry
from parsica_memory.storage.manifest import Manifest


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_mem(workspace: str, **kwargs) -> MemorySystemV4:
    """Create a MemorySystemV4 in segmented mode, suppressing warnings."""
    defaults = {
        "agent_name": "test-agent",
        "storage_backend": "segments",
        "graph_intelligence": False,
        "quality_routing": False,
        "semantic_expansion": False,
    }
    defaults.update(kwargs)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", UserWarning)
        return MemorySystemV4(workspace, **defaults)


def _make_entry_dict(content: str, hours_ago: float = 0) -> dict:
    """Build a minimal entry dict matching Parsica conventions."""
    created = (datetime.now(timezone.utc) - timedelta(hours=hours_ago)).isoformat()
    h = hashlib.md5(f"test:0:{content}".encode()).hexdigest()[:12]
    return {
        "hash": h,
        "content": content,
        "source": "test",
        "line": 0,
        "category": "general",
        "created": created,
        "last_accessed": created,
        "access_count": 0,
        "importance": 1.0,
        "confidence": 0.5,
        "sentiment": {},
        "tags": [],
        "related": [],
        "memory_type": "episodic",
        "session_id": "",
        "agent_id": "test-agent",
    }


def _write_peer_store(peer_dir: str, entries: list[dict]):
    """Set up a minimal peer store with shards and WAL for sync to read."""
    shards_dir = os.path.join(peer_dir, "shards")
    os.makedirs(shards_dir, exist_ok=True)
    shard_path = os.path.join(shards_dir, "shard_2026-03_general.json")
    with open(shard_path, "w") as f:
        json.dump({"memories": entries, "count": len(entries)}, f)


# ===========================================================================
# Test 1: sync() entries reach segment store
# ===========================================================================


class TestSyncEntriesReachSegmentStore(unittest.TestCase):
    """Verify that PeerSync.sync() entries are bridged to the segment store
    in segmented mode, not silently dropped in the legacy WAL."""

    def setUp(self):
        self.local_dir = tempfile.mkdtemp()
        self.peer_dir = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.local_dir, ignore_errors=True)
        shutil.rmtree(self.peer_dir, ignore_errors=True)

    def test_sync_raises_in_segmented_mode(self):
        """sync() should raise NotImplementedError in segmented mode (v3.2)."""
        mem = _make_mem(self.local_dir)
        self.assertTrue(mem._using_segments)

        peer_entries = [
            _make_entry_dict("Peer memory about dolphins", hours_ago=1),
        ]
        _write_peer_store(self.peer_dir, peer_entries)

        with self.assertRaises(NotImplementedError) as ctx:
            mem.sync(hours=24, peers=[self.peer_dir])
        self.assertIn("not compatible with segmented storage", str(ctx.exception))
        mem.close()

    def test_sync_no_legacy_wal_written_in_segmented_mode(self):
        """In segmented mode, sync should not write to legacy WAL at all."""
        mem = _make_mem(self.local_dir)
        self.assertTrue(mem._using_segments)

        peer_entries = [_make_entry_dict("Unique peer memory", hours_ago=1)]
        _write_peer_store(self.peer_dir, peer_entries)

        # Sync raises — no WAL should be written
        with self.assertRaises(NotImplementedError):
            mem.sync(hours=24, peers=[self.peer_dir])

        wal_path = os.path.join(self.local_dir, ".parsica_wal.jsonl")
        if os.path.exists(wal_path):
            with open(wal_path, "r") as f:
                content = f.read().strip()
            self.assertEqual(content, "", "Legacy WAL should not be written in segmented mode")
        mem.close()

    def test_peer_sync_direct_blocked_on_segmented_workspace(self):
        """PeerSync() constructor should raise on segmented workspace."""
        mem = _make_mem(self.local_dir)
        mem.ingest("Some entry to make workspace real")
        mem.save()
        mem.close()

        from parsica_memory.sync import PeerSync
        with self.assertRaises(NotImplementedError) as ctx:
            PeerSync(self.local_dir)
        self.assertIn("not compatible with segmented storage", str(ctx.exception))


# ===========================================================================
# Test 2: parallel enricher uses segment store
# ===========================================================================


class TestParallelEnricherUsesSegments(unittest.TestCase):
    """Verify that parallel enrichment writes fact entries to the segment
    store instead of the legacy WAL when in segmented mode."""

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_parallel_enricher_uses_segments(self):
        """Facts created by parallel enrichment should persist in segment
        store, not be lost in the legacy WAL."""
        mem = _make_mem(self.tmpdir)
        self.assertTrue(mem._using_segments)

        # Add some un-enriched entries
        for i in range(3):
            mem.ingest(f"Test memory number {i} about important research findings that need enrichment processing")
        mem.save()

        initial_count = len(mem.memories)

        # Create a fact entry as the enricher would
        fact_entry = MemoryEntry(
            "Research findings show interesting patterns",
            source="test",
            line=0,
            category="general",
            memory_type="fact",
        )
        fact_entry.provenance = "decomposed"
        fact_entry.parent_hash = mem.memories[0].hash
        fact_entry.confidence = 0.8

        # Simulate what parallel_enricher does — the fixed path
        mem.memories.append(fact_entry)
        mem._hashes.add(fact_entry.hash)

        # The fix: check for segment store and use it
        if hasattr(mem, '_segment_store') and mem._segment_store is not None:
            mem._segment_store.append_put(fact_entry)
        else:
            mem._wal.append(fact_entry.to_dict())

        mem.save()

        # Close and reopen — verify persistence
        mem.close()
        mem2 = _make_mem(self.tmpdir)
        contents = [m.content for m in mem2.memories]
        self.assertIn(
            "Research findings show interesting patterns",
            contents,
            "Fact entry should persist through segment store after save/reload",
        )
        mem2.close()

    def test_enricher_fact_not_in_legacy_wal_in_segmented_mode(self):
        """In segmented mode, enricher-created facts should NOT go to legacy WAL."""
        mem = _make_mem(self.tmpdir)
        self.assertTrue(mem._using_segments)

        fact_entry = MemoryEntry(
            "A fact that should go to segments not WAL",
            source="test",
            memory_type="fact",
        )

        # Simulate the fixed enricher write path
        if hasattr(mem, '_segment_store') and mem._segment_store is not None:
            mem._segment_store.append_put(fact_entry)
        else:
            mem._wal.append(fact_entry.to_dict())

        # The legacy WAL should NOT have this entry
        wal_pending = mem._wal.load_pending()
        wal_hashes = {e.get("hash", "") if isinstance(e, dict) else getattr(e, "hash", "") for e in wal_pending}
        self.assertNotIn(
            fact_entry.hash,
            wal_hashes,
            "In segmented mode, fact should go to segment store, not legacy WAL",
        )
        mem.close()


# ===========================================================================
# Test 3: manifest.load() validates before trusting
# ===========================================================================


class TestManifestLoadValidatesBeforeTrusting(unittest.TestCase):
    """Verify that Manifest.load() performs semantic validation on the primary
    manifest and falls back to the backup when the primary is broken."""

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.seg_dir = os.path.join(self.tmpdir, "segments")
        os.makedirs(self.seg_dir, exist_ok=True)

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def _write_manifest(self, data: dict, path: str = None):
        """Write a manifest dict to a specific path."""
        if path is None:
            path = os.path.join(self.seg_dir, "manifest.json")
        with open(path, "w") as f:
            json.dump(data, f)

    def _good_manifest(self, generation: int = 5) -> dict:
        """Return a valid manifest dict."""
        return {
            "version": "3.2.0",
            "generation": generation,
            "created_at": "2026-01-01T00:00:00+00:00",
            "updated_at": "2026-01-01T00:00:00+00:00",
            "segments": [],
            "hot": {
                "filename": "hot.jsonl",
                "put_count": 0,
                "delete_count": 0,
                "last_write_at": None,
            },
            "tombstones": {},
            "search": {"index_generation": 0},
            "migration": None,
        }

    def test_valid_primary_used_directly(self):
        """A semantically valid primary manifest should be used as-is."""
        good = self._good_manifest(generation=10)
        self._write_manifest(good)
        m = Manifest(self.seg_dir)
        self.assertEqual(m.generation, 10)

    def test_missing_keys_triggers_backup_fallback(self):
        """Primary missing required keys → backup should be used."""
        # Primary: syntactically valid JSON but missing required keys
        bad_primary = {"version": "3.2.0", "generation": 3}
        # Missing: segments, hot, tombstones
        self._write_manifest(bad_primary)

        # Backup: fully valid
        good_backup = self._good_manifest(generation=2)
        self._write_manifest(good_backup, os.path.join(self.seg_dir, "manifest.json.bak"))

        m = Manifest(self.seg_dir)
        self.assertEqual(m.generation, 2, "Should fall back to valid backup")

    def test_missing_segment_files_triggers_backup(self):
        """Primary references non-existent segment files → backup used."""
        bad_primary = self._good_manifest(generation=5)
        bad_primary["segments"] = [
            {
                "sequence": 1,
                "filename": "seg_0001_nonexistent.jsonl",
                "state": "active",
                "entry_count": 100,
            },
            {
                "sequence": 2,
                "filename": "seg_0002_also_missing.jsonl",
                "state": "active",
                "entry_count": 50,
            },
        ]
        self._write_manifest(bad_primary)

        good_backup = self._good_manifest(generation=4)
        self._write_manifest(good_backup, os.path.join(self.seg_dir, "manifest.json.bak"))

        m = Manifest(self.seg_dir)
        self.assertEqual(m.generation, 4, "Should fall back to backup when segment files missing")
        self.assertEqual(len(m.segments), 0, "Backup has no segments")

    def test_duplicate_sequences_triggers_backup(self):
        """Primary with duplicate segment sequences → backup used."""
        # Create real segment files so file-existence check passes
        for fname in ("seg_dup_a.jsonl", "seg_dup_b.jsonl"):
            with open(os.path.join(self.seg_dir, fname), "w") as f:
                f.write("{}\n")

        bad_primary = self._good_manifest(generation=7)
        bad_primary["segments"] = [
            {"sequence": 1, "filename": "seg_dup_a.jsonl", "state": "active", "entry_count": 10},
            {"sequence": 1, "filename": "seg_dup_b.jsonl", "state": "active", "entry_count": 20},
        ]
        self._write_manifest(bad_primary)

        good_backup = self._good_manifest(generation=6)
        self._write_manifest(good_backup, os.path.join(self.seg_dir, "manifest.json.bak"))

        m = Manifest(self.seg_dir)
        self.assertEqual(m.generation, 6, "Should fall back to backup on duplicate sequences")

    def test_both_bad_uses_fewer_errors(self):
        """Both primary and backup have errors → prefer higher generation (B6 fix).

        When both manifests have errors, the one with the higher generation
        (more recent committed state) is preferred.  Fewer errors is only
        a tiebreaker when generations are equal.
        """
        # Primary: 3 errors (missing segments, hot, tombstones keys), gen=5
        bad_primary = {"version": "3.2.0", "generation": 5}
        self._write_manifest(bad_primary)

        # Backup: 1 error (missing tombstones key only), gen=4
        less_bad_backup = {
            "version": "3.2.0",
            "generation": 4,
            "segments": [],
            "hot": {
                "filename": "hot.jsonl",
                "put_count": 0,
                "delete_count": 0,
                "last_write_at": None,
            },
        }
        self._write_manifest(less_bad_backup, os.path.join(self.seg_dir, "manifest.json.bak"))

        m = Manifest(self.seg_dir)
        # B6 fix: Primary (gen=5) preferred — higher generation has more recent data
        self.assertEqual(m.generation, 5, "Should use primary with higher generation")

    def test_no_backup_uses_primary_despite_errors(self):
        """No backup exists → primary used even with validation errors."""
        bad_primary = self._good_manifest(generation=3)
        bad_primary["segments"] = [
            {
                "sequence": 1,
                "filename": "seg_missing.jsonl",
                "state": "active",
                "entry_count": 50,
            },
        ]
        self._write_manifest(bad_primary)
        # No backup file

        m = Manifest(self.seg_dir)
        self.assertEqual(m.generation, 3, "No backup → use primary despite errors")
        self.assertEqual(len(m.segments), 1, "Primary segments preserved")

    def test_valid_primary_no_fallback(self):
        """Valid primary should NOT trigger backup check."""
        good = self._good_manifest(generation=10)
        self._write_manifest(good)

        # Write a backup with different generation — should not be used
        backup = self._good_manifest(generation=99)
        self._write_manifest(backup, os.path.join(self.seg_dir, "manifest.json.bak"))

        m = Manifest(self.seg_dir)
        self.assertEqual(m.generation, 10, "Valid primary should be used, not backup")


if __name__ == "__main__":
    unittest.main()
