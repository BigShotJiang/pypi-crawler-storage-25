"""Tests for ambient awareness bridge wiring.

Verifies that session_awareness reaches MemorySystem at creation time
through the bridge pre-turn path, and that the pipeline pool respects it.

These tests validate the fix for the bridgePreTurn() wiring gap where
session_awareness was not passed to the Python bridge, causing the
MemorySystem to be created with default "off" and no session tracker.

Pro-recommended test cases (2026-04-01).
"""

import os
import sys
import tempfile
import pytest

# Ensure parsica_memory is importable
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from parsica_memory import MemorySystem


class TestSessionAwarenessCreation:
    """Verify that session_awareness at construction time controls tracker creation."""

    def test_closed_mode_creates_tracker(self, tmp_path):
        """Pre-turn with session_awareness='closed' should create a live tracker."""
        mem = MemorySystem(workspace=str(tmp_path), agent_name="test", session_awareness="closed")
        mem.load()
        assert mem._session_tracker is not None, (
            "session_awareness='closed' must create a _session_tracker"
        )

    def test_open_mode_creates_tracker(self, tmp_path):
        """Pre-turn with session_awareness='open' should create a live tracker."""
        mem = MemorySystem(workspace=str(tmp_path), agent_name="test", session_awareness="open")
        mem.load()
        assert mem._session_tracker is not None, (
            "session_awareness='open' must create a _session_tracker"
        )

    def test_off_mode_no_tracker(self, tmp_path):
        """Pre-turn with session_awareness='off' should keep tracker absent."""
        mem = MemorySystem(workspace=str(tmp_path), agent_name="test", session_awareness="off")
        mem.load()
        assert mem._session_tracker is None, (
            "session_awareness='off' must NOT create a _session_tracker"
        )

    def test_default_is_off(self, tmp_path):
        """Default construction (no session_awareness param) should be 'off'."""
        mem = MemorySystem(workspace=str(tmp_path), agent_name="test")
        mem.load()
        assert mem._session_tracker is None, (
            "Default session_awareness must be 'off' (no tracker)"
        )


class TestTrackerMethodsWithoutTracker:
    """Verify that begin_turn/end_turn/get_ambient_context are safe no-ops when off."""

    def test_begin_turn_noop_when_off(self, tmp_path):
        """begin_turn should be a silent no-op when session_awareness='off'."""
        mem = MemorySystem(workspace=str(tmp_path), agent_name="test", session_awareness="off")
        mem.load()
        # Should not raise
        mem.begin_turn("test-session")

    def test_end_turn_noop_when_off(self, tmp_path):
        """end_turn should be a silent no-op when session_awareness='off'."""
        mem = MemorySystem(workspace=str(tmp_path), agent_name="test", session_awareness="off")
        mem.load()
        mem.end_turn("test-session")

    def test_get_ambient_context_empty_when_off(self, tmp_path):
        """get_ambient_context should return empty when session_awareness='off'."""
        mem = MemorySystem(workspace=str(tmp_path), agent_name="test", session_awareness="off")
        mem.load()
        result = mem.get_ambient_context("test-session")
        assert result == [] or result == "" or result is None or (hasattr(result, '__len__') and len(result) == 0), (
            "get_ambient_context must return empty when tracker is None"
        )


class TestTrackerMethodsWithTracker:
    """Verify that begin_turn/end_turn/get_ambient_context work when tracker exists."""

    def test_begin_turn_registers_session(self, tmp_path):
        """begin_turn with 'open' mode should register the session."""
        mem = MemorySystem(workspace=str(tmp_path), agent_name="test", session_awareness="open")
        mem.load()
        mem.begin_turn("session-alpha")
        # The session should now be tracked
        tracker = mem._session_tracker
        assert tracker is not None
        # Session should be active after begin_turn
        assert tracker.is_write_allowed("session-alpha"), (
            "After begin_turn, session should be active and allowed to write"
        )

    def test_end_turn_idles_session(self, tmp_path):
        """end_turn should idle the session."""
        mem = MemorySystem(workspace=str(tmp_path), agent_name="test", session_awareness="open")
        mem.load()
        mem.begin_turn("session-beta")
        mem.end_turn("session-beta")
        # In open mode, writes are still allowed (just warned)
        # In closed mode, writes would be blocked after end_turn

    def test_ambient_context_across_sessions(self, tmp_path):
        """Two sessions should be able to see each other's summaries."""
        mem = MemorySystem(workspace=str(tmp_path), agent_name="test", session_awareness="open")
        mem.load()

        # Session 1 begins and does work
        mem.begin_turn("session-1")
        # Ingest something so there's context
        mem.ingest("Session 1 is working on the roadmap update", source="test")
        mem.end_turn("session-1")

        # Session 2 begins and asks for ambient context
        mem.begin_turn("session-2")
        context = mem.get_ambient_context("session-2")
        # Context should exist (may be empty if summaries haven't been generated,
        # but the method should not error)
        assert context is not None, "get_ambient_context should not return None with tracker active"


class TestLegacyAmbientAwareness:
    """Verify legacy ambient_awareness=True behavior."""

    def test_legacy_bool_without_explicit_session_awareness(self, tmp_path):
        """ambient_awareness=True without session_awareness should activate tracker."""
        mem = MemorySystem(
            workspace=str(tmp_path), agent_name="test",
            ambient_awareness=True,
            # No explicit session_awareness — legacy path
        )
        mem.load()
        # Legacy ambient_awareness=True should create a tracker
        # (resolves to "closed" mode per core_v4.py logic)
        assert mem._session_tracker is not None, (
            "Legacy ambient_awareness=True should create a tracker"
        )

    def test_legacy_bool_overrides_explicit_off(self, tmp_path):
        """ambient_awareness=True currently overrides session_awareness='off'.

        This documents CURRENT behavior (legacy bool takes precedence).
        Pro flagged this as a reason NOT to blindly pass ambient_awareness
        through the bridge — it would silently enable tracking for everyone.
        """
        mem = MemorySystem(
            workspace=str(tmp_path), agent_name="test",
            session_awareness="off",
            ambient_awareness=True,
        )
        mem.load()
        # Legacy bool currently wins — tracker is created even with explicit "off"
        # This is the exact behavior Pro warned about: passing ambient_awareness=True
        # through the bridge would silently enable tracking for all users
        assert mem._session_tracker is not None, (
            "Legacy ambient_awareness=True currently overrides session_awareness='off'"
        )


class TestPoolCacheRisk:
    """Verify that MemorySystem created with wrong config stays wrong (documents the pool risk)."""

    def test_tracker_is_immutable_after_creation(self, tmp_path):
        """Once created with 'off', the tracker cannot be retroactively enabled."""
        mem = MemorySystem(workspace=str(tmp_path), agent_name="test", session_awareness="off")
        mem.load()
        assert mem._session_tracker is None

        # Calling begin_turn doesn't magically create a tracker
        mem.begin_turn("test-session")
        assert mem._session_tracker is None, (
            "begin_turn must not create a tracker if it wasn't there at construction"
        )

    def test_separate_instances_get_separate_trackers(self, tmp_path):
        """Two MemorySystems at the same path but different configs get different trackers."""
        path1 = str(tmp_path / "store1")
        path2 = str(tmp_path / "store2")
        os.makedirs(path1, exist_ok=True)
        os.makedirs(path2, exist_ok=True)

        mem_off = MemorySystem(workspace=path1, agent_name="test", session_awareness="off")
        mem_off.load()
        mem_open = MemorySystem(workspace=path2, agent_name="test", session_awareness="open")
        mem_open.load()

        assert mem_off._session_tracker is None
        assert mem_open._session_tracker is not None
