"""Tests for parsica_memory.storage.snapshot.

Covers create_snapshot, verify_snapshot, restore_snapshot, and snapshot_info.
15+ test cases.
"""

from __future__ import annotations

import json
import os
import shutil
import tempfile
import uuid
from pathlib import Path

import pytest

from parsica_memory.storage.snapshot import (
    RestoreResult,
    SnapshotFile,
    SnapshotManifest,
    StoreValidationError,
    VerifyResult,
    create_snapshot,
    restore_snapshot,
    snapshot_info,
    verify_snapshot,
)


# ---------------------------------------------------------------------------
# Fixtures & helpers
# ---------------------------------------------------------------------------

def _make_store(base: Path, *, num_segments: int = 2, include_bak: bool = True) -> Path:
    """Build a minimal valid segmented store under *base* and return its path."""
    workspace = base / f"workspace_{uuid.uuid4().hex[:8]}"
    segments_dir = workspace / "segments"
    segments_dir.mkdir(parents=True)

    segment_metas: list[dict] = []
    for i in range(1, num_segments + 1):
        fname = f"seg_{i:04d}_20260101T000000Z_{i * 10}.jsonl"
        seg_path = segments_dir / fname
        content = "\n".join(
            json.dumps({"hash": f"abc{i}{j:03d}", "content": f"entry {j}"})
            for j in range(i * 10)
        ) + "\n"
        seg_path.write_text(content, encoding="utf-8")

        import hashlib
        sha = hashlib.sha256(seg_path.read_bytes()).hexdigest()
        segment_metas.append({
            "sequence": i,
            "filename": fname,
            "state": "active",
            "entry_count": i * 10,
            "size_bytes": seg_path.stat().st_size,
            "checksum_sha256": sha,
            "flushed_at": "2026-01-01T00:00:00+00:00",
        })

    manifest = {
        "version": "3.3.0",
        "generation": num_segments,
        "created_at": "2026-01-01T00:00:00+00:00",
        "updated_at": "2026-01-01T00:00:00+00:00",
        "segments": segment_metas,
        "hot": {
            "filename": "hot.jsonl",
            "put_count": 0,
            "delete_count": 0,
            "last_write_at": None,
        },
        "tombstones": {},
        "search": {"index_generation": 0},
        "migration": None,
    }
    manifest_path = segments_dir / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    if include_bak:
        bak_path = segments_dir / "manifest.json.bak"
        bak_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    hot_path = segments_dir / "hot.jsonl"
    hot_path.write_text("", encoding="utf-8")

    return workspace


@pytest.fixture()
def tmp(tmp_path: Path) -> Path:
    return tmp_path


@pytest.fixture()
def store(tmp_path: Path) -> Path:
    return _make_store(tmp_path)


@pytest.fixture()
def snap_dir(tmp_path: Path) -> Path:
    return tmp_path / "snapshots"


# ---------------------------------------------------------------------------
# 1. create_snapshot — happy path
# ---------------------------------------------------------------------------

def test_create_snapshot_returns_path(store: Path, snap_dir: Path) -> None:
    result = create_snapshot(store, snap_dir)
    assert isinstance(result, Path)
    assert result.exists()


def test_create_snapshot_directory_structure(store: Path, snap_dir: Path) -> None:
    result = create_snapshot(store, snap_dir)
    assert (result / "snapshot_manifest.json").exists()
    assert (result / "segments" / "manifest.json").exists()
    assert (result / "segments" / "hot.jsonl").exists()


def test_create_snapshot_includes_all_segments(store: Path, snap_dir: Path) -> None:
    result = create_snapshot(store, snap_dir)
    for seg_file in (store / "segments").glob("seg_*.jsonl"):
        assert (result / "segments" / seg_file.name).exists(), (
            f"Segment {seg_file.name} not found in snapshot"
        )


def test_create_snapshot_includes_bak_manifest(store: Path, snap_dir: Path) -> None:
    result = create_snapshot(store, snap_dir)
    assert (result / "segments" / "manifest.json.bak").exists()


def test_create_snapshot_manifest_content(store: Path, snap_dir: Path) -> None:
    result = create_snapshot(store, snap_dir)
    data = json.loads((result / "snapshot_manifest.json").read_text())
    assert "snapshot_id" in data
    assert data["snapshot_id"].startswith("snap-")
    assert data["store_generation"] == 2
    assert data["store_version"] == "3.3.0"
    assert data["file_count"] > 0
    assert len(data["files"]) == data["file_count"]


def test_create_snapshot_checksums_valid(store: Path, snap_dir: Path) -> None:
    """Every file in the snapshot manifest must have a non-empty SHA-256."""
    result = create_snapshot(store, snap_dir)
    data = json.loads((result / "snapshot_manifest.json").read_text())
    for f in data["files"]:
        assert len(f["sha256"]) == 64, f"Bad SHA-256 for {f['path']}: {f['sha256']!r}"
        assert f["size_bytes"] >= 0


def test_create_snapshot_custom_id(store: Path, snap_dir: Path) -> None:
    result = create_snapshot(store, snap_dir, snapshot_id="my-snap-v1")
    assert result.name == "my-snap-v1"
    assert result.exists()


def test_create_snapshot_duplicate_id_raises(store: Path, snap_dir: Path) -> None:
    create_snapshot(store, snap_dir, snapshot_id="dup-snap")
    with pytest.raises(FileExistsError):
        create_snapshot(store, snap_dir, snapshot_id="dup-snap")


# ---------------------------------------------------------------------------
# 2. create_snapshot — validation
# ---------------------------------------------------------------------------

def test_create_snapshot_invalid_store_raises(tmp_path: Path, snap_dir: Path) -> None:
    """Snaphotting a workspace with no segments/ should raise StoreValidationError."""
    empty_workspace = tmp_path / "empty_ws"
    empty_workspace.mkdir()
    with pytest.raises(StoreValidationError):
        create_snapshot(empty_workspace, snap_dir)


def test_create_snapshot_missing_manifest_raises(tmp_path: Path, snap_dir: Path) -> None:
    workspace = tmp_path / "ws_no_manifest"
    (workspace / "segments").mkdir(parents=True)
    with pytest.raises(StoreValidationError, match="manifest.json is missing"):
        create_snapshot(workspace, snap_dir)


def test_create_snapshot_missing_segment_raises(tmp_path: Path, snap_dir: Path) -> None:
    workspace = _make_store(tmp_path)
    # Delete one segment file without updating manifest
    seg = next((workspace / "segments").glob("seg_*.jsonl"))
    seg.unlink()
    with pytest.raises(StoreValidationError, match="missing on disk"):
        create_snapshot(workspace, snap_dir)


def test_create_snapshot_skip_validation(tmp_path: Path, snap_dir: Path) -> None:
    """skip_validation=True should allow snapshotting even invalid stores."""
    workspace = tmp_path / "invalid_ws"
    (workspace / "segments").mkdir(parents=True)
    # Minimal: write a broken manifest but don't add segments or hot
    manifest_path = workspace / "segments" / "manifest.json"
    manifest_path.write_text(json.dumps({
        "version": "3.3.0", "generation": 0, "segments": [],
        "hot": {"filename": "hot.jsonl"}, "tombstones": {}
    }), encoding="utf-8")
    (workspace / "segments" / "hot.jsonl").write_text("", encoding="utf-8")
    # Should not raise
    result = create_snapshot(workspace, snap_dir, skip_validation=True)
    assert result.exists()


# ---------------------------------------------------------------------------
# 3. verify_snapshot — happy path
# ---------------------------------------------------------------------------

def test_verify_snapshot_ok(store: Path, snap_dir: Path) -> None:
    snap = create_snapshot(store, snap_dir)
    result = verify_snapshot(snap)
    assert isinstance(result, VerifyResult)
    assert result.ok is True
    assert result.errors == []


def test_verify_snapshot_counts(store: Path, snap_dir: Path) -> None:
    snap = create_snapshot(store, snap_dir)
    result = verify_snapshot(snap)
    assert result.file_count > 0
    assert result.verified_count == result.file_count


# ---------------------------------------------------------------------------
# 4. verify_snapshot — failures
# ---------------------------------------------------------------------------

def test_verify_snapshot_missing_manifest(tmp_path: Path) -> None:
    empty = tmp_path / "not_a_snap"
    empty.mkdir()
    result = verify_snapshot(empty)
    assert result.ok is False
    assert any("snapshot_manifest.json" in e for e in result.errors)


def test_verify_snapshot_tampered_file(store: Path, snap_dir: Path) -> None:
    snap = create_snapshot(store, snap_dir)
    # Tamper with a segment file inside the snapshot
    seg = next((snap / "segments").glob("seg_*.jsonl"))
    seg.write_text("TAMPERED\n", encoding="utf-8")
    result = verify_snapshot(snap)
    assert result.ok is False
    assert any("Checksum mismatch" in e for e in result.errors)


def test_verify_snapshot_missing_file(store: Path, snap_dir: Path) -> None:
    snap = create_snapshot(store, snap_dir)
    seg = next((snap / "segments").glob("seg_*.jsonl"))
    seg.unlink()
    result = verify_snapshot(snap)
    assert result.ok is False
    assert any("Missing file" in e for e in result.errors)


# ---------------------------------------------------------------------------
# 5. restore_snapshot — happy path
# ---------------------------------------------------------------------------

def test_restore_snapshot_into_empty_workspace(store: Path, snap_dir: Path, tmp_path: Path) -> None:
    snap = create_snapshot(store, snap_dir)
    target = tmp_path / "restored_ws"
    result = restore_snapshot(snap, target)
    assert result.ok is True
    assert (target / "segments" / "manifest.json").exists()
    assert (target / "segments" / "hot.jsonl").exists()


def test_restore_snapshot_result_type(store: Path, snap_dir: Path, tmp_path: Path) -> None:
    snap = create_snapshot(store, snap_dir)
    result = restore_snapshot(snap, tmp_path / "rws")
    assert isinstance(result, RestoreResult)
    assert result.errors == []


def test_restore_snapshot_all_segments_present(store: Path, snap_dir: Path, tmp_path: Path) -> None:
    snap = create_snapshot(store, snap_dir)
    target = tmp_path / "rws"
    restore_snapshot(snap, target)
    original_segs = {f.name for f in (store / "segments").glob("seg_*.jsonl")}
    restored_segs = {f.name for f in (target / "segments").glob("seg_*.jsonl")}
    assert original_segs == restored_segs


def test_restore_snapshot_creates_backup_for_non_empty(
    store: Path, snap_dir: Path, tmp_path: Path
) -> None:
    snap = create_snapshot(store, snap_dir)
    target = tmp_path / "rws"
    # Pre-populate target so it's non-empty
    (target / "segments").mkdir(parents=True)
    (target / "segments" / "old_file.txt").write_text("old data")

    result = restore_snapshot(snap, target, allow_non_empty=True)
    assert result.ok is True
    assert result.backup_path is not None
    backup = Path(result.backup_path)
    assert backup.exists()
    assert (backup / "segments" / "old_file.txt").exists()


def test_restore_snapshot_non_empty_without_flag_fails(
    store: Path, snap_dir: Path, tmp_path: Path
) -> None:
    snap = create_snapshot(store, snap_dir)
    target = tmp_path / "rws"
    (target / "segments").mkdir(parents=True)
    (target / "segments" / "old_file.txt").write_text("old data")

    result = restore_snapshot(snap, target)  # allow_non_empty=False by default
    assert result.ok is False
    assert any("not empty" in e.lower() or "non-empty" in e.lower() for e in result.errors)


# ---------------------------------------------------------------------------
# 6. restore_snapshot — invalid snapshot
# ---------------------------------------------------------------------------

def test_restore_invalid_snapshot_aborts(tmp_path: Path) -> None:
    snap_dir = tmp_path / "bad_snap"
    snap_dir.mkdir()
    target = tmp_path / "target"
    result = restore_snapshot(snap_dir, target)
    assert result.ok is False
    assert len(result.errors) > 0


def test_restore_tampered_snapshot_aborts(store: Path, snap_dir: Path, tmp_path: Path) -> None:
    snap = create_snapshot(store, snap_dir)
    seg = next((snap / "segments").glob("seg_*.jsonl"))
    seg.write_text("TAMPERED\n", encoding="utf-8")
    target = tmp_path / "target"
    result = restore_snapshot(snap, target)
    assert result.ok is False


# ---------------------------------------------------------------------------
# 7. snapshot_info
# ---------------------------------------------------------------------------

def test_snapshot_info_returns_dict(store: Path, snap_dir: Path) -> None:
    snap = create_snapshot(store, snap_dir)
    info = snapshot_info(snap)
    assert isinstance(info, dict)
    assert "snapshot_id" in info
    assert "files" in info


def test_snapshot_info_missing_returns_error(tmp_path: Path) -> None:
    info = snapshot_info(tmp_path / "nonexistent")
    assert "error" in info


# ---------------------------------------------------------------------------
# 8. SnapshotManifest round-trip
# ---------------------------------------------------------------------------

def test_snapshot_manifest_round_trip() -> None:
    files = [SnapshotFile(path="segments/manifest.json", sha256="a" * 64, size_bytes=512)]
    m = SnapshotManifest(
        snapshot_id="snap-test",
        created_at="2026-01-01T00:00:00+00:00",
        store_workspace="/tmp/ws",
        store_generation=5,
        store_version="3.3.0",
        manifest_checksum="a" * 64,
        file_count=1,
        total_size_bytes=512,
        files=files,
    )
    d = m.to_dict()
    m2 = SnapshotManifest.from_dict(d)
    assert m2.snapshot_id == m.snapshot_id
    assert m2.store_generation == 5
    assert len(m2.files) == 1
    assert m2.files[0].sha256 == "a" * 64


# ---------------------------------------------------------------------------
# 9. Snapshot without .bak (optional file)
# ---------------------------------------------------------------------------

def test_create_snapshot_no_bak(tmp_path: Path, snap_dir: Path) -> None:
    workspace = _make_store(tmp_path, include_bak=False)
    snap = create_snapshot(workspace, snap_dir)
    assert snap.exists()
    data = json.loads((snap / "snapshot_manifest.json").read_text())
    paths = [f["path"] for f in data["files"]]
    assert "segments/manifest.json.bak" not in paths


# ---------------------------------------------------------------------------
# 10. Snapshot with hot.rotating.jsonl present
# ---------------------------------------------------------------------------

def test_create_snapshot_includes_rotating_hot(tmp_path: Path, snap_dir: Path) -> None:
    workspace = _make_store(tmp_path)
    rotating = workspace / "segments" / "hot.rotating.jsonl"
    rotating.write_text(
        json.dumps({"op": "put", "hash": "deadbeef", "entry": {}, "ts": "2026-01-01T00:00:00+00:00"}) + "\n",
        encoding="utf-8",
    )
    snap = create_snapshot(workspace, snap_dir)
    assert (snap / "segments" / "hot.rotating.jsonl").exists()
    data = json.loads((snap / "snapshot_manifest.json").read_text())
    paths = [f["path"] for f in data["files"]]
    assert "segments/hot.rotating.jsonl" in paths


# ---------------------------------------------------------------------------
# 11. Multiple snapshots of the same store
# ---------------------------------------------------------------------------

def test_multiple_snapshots_unique_ids(store: Path, snap_dir: Path) -> None:
    import time
    snap1 = create_snapshot(store, snap_dir)
    time.sleep(0.01)  # ensure timestamps differ
    snap2 = create_snapshot(store, snap_dir)
    assert snap1 != snap2
    assert snap1.name != snap2.name


# ---------------------------------------------------------------------------
# 12. verify_snapshot returns VerifyResult.to_dict() correctly
# ---------------------------------------------------------------------------

def test_verify_result_to_dict(store: Path, snap_dir: Path) -> None:
    snap = create_snapshot(store, snap_dir)
    result = verify_snapshot(snap)
    d = result.to_dict()
    assert d["ok"] is True
    assert isinstance(d["errors"], list)
    assert isinstance(d["file_count"], int)


# ---------------------------------------------------------------------------
# 13. restore_snapshot skip_post_validation
# ---------------------------------------------------------------------------

def test_restore_skip_post_validation(store: Path, snap_dir: Path, tmp_path: Path) -> None:
    snap = create_snapshot(store, snap_dir)
    target = tmp_path / "rws"
    result = restore_snapshot(snap, target, skip_post_validation=True)
    assert result.ok is True


# ---------------------------------------------------------------------------
# 14. RestoreResult.to_dict() serialises correctly
# ---------------------------------------------------------------------------

def test_restore_result_to_dict(store: Path, snap_dir: Path, tmp_path: Path) -> None:
    snap = create_snapshot(store, snap_dir)
    result = restore_snapshot(snap, tmp_path / "rws")
    d = result.to_dict()
    assert "ok" in d
    assert "snapshot_dir" in d
    assert "target_workspace" in d
    assert d["backup_path"] is None


# ---------------------------------------------------------------------------
# 15. Store with zero segments (hot-only store)
# ---------------------------------------------------------------------------

def test_snapshot_hot_only_store(tmp_path: Path, snap_dir: Path) -> None:
    workspace = tmp_path / "hot_only_ws"
    (workspace / "segments").mkdir(parents=True)
    manifest = {
        "version": "3.3.0",
        "generation": 0,
        "created_at": "2026-01-01T00:00:00+00:00",
        "updated_at": "2026-01-01T00:00:00+00:00",
        "segments": [],
        "hot": {"filename": "hot.jsonl", "put_count": 3, "delete_count": 0, "last_write_at": None},
        "tombstones": {},
        "search": {"index_generation": 0},
        "migration": None,
    }
    (workspace / "segments" / "manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
    (workspace / "segments" / "hot.jsonl").write_text(
        json.dumps({"op": "put", "hash": "xyz", "entry": {}, "ts": "2026-01-01T00:00:00+00:00"}) + "\n",
        encoding="utf-8",
    )

    snap = create_snapshot(workspace, snap_dir)
    assert snap.exists()
    result = verify_snapshot(snap)
    assert result.ok is True

    target = tmp_path / "restored_hot_only"
    restore_result = restore_snapshot(snap, target)
    assert restore_result.ok is True
    assert (target / "segments" / "manifest.json").exists()
    assert (target / "segments" / "hot.jsonl").exists()
