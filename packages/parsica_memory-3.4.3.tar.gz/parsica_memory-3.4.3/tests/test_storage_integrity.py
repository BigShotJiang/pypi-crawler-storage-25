"""Tests for parsica_memory.storage.integrity — v3.3 dedicated integrity validation.

Covers:
- validate_store() on healthy, broken, and edge-case stores
- validate_segment() standalone
- validate_hot() standalone
- scan_orphans()
- Tombstone consistency checks
- Search index staleness detection
- Physical vs logical entry counts
- Machine-readable JSON output
- Missing/corrupt manifest handling
- Duplicate sequence detection
- Checksum mismatch detection
- Empty segment handling
- Oversized hot buffer warning

15+ tests, zero external dependencies.
"""

from __future__ import annotations

import hashlib
import json
import os
import tempfile
from pathlib import Path

import pytest

from parsica_memory.storage.integrity import (
    HotValidation,
    SegmentValidation,
    ValidationIssue,
    ValidationReport,
    _count_jsonl_entries,
    scan_orphans,
    sha256_file,
    validate_hot,
    validate_segment,
    validate_store,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _make_entry(content: str = "hello", hash_val: str | None = None) -> dict:
    """Return a minimal MemoryEntry-like dict."""
    h = hash_val or hashlib.md5(content.encode()).hexdigest()[:12]
    return {
        "content": content,
        "source": "test",
        "line": 0,
        "category": "general",
        "created": "2026-03-30T00:00:00+00:00",
        "last_accessed": "2026-03-30T00:00:00+00:00",
        "access_count": 0,
        "importance": 1.0,
        "confidence": 0.5,
        "sentiment": {},
        "tags": [],
        "related": [],
        "hash": h,
        "memory_type": "episodic",
        "type_metadata": {},
        "session_id": "",
        "agent_id": "",
    }


def _write_segment(seg_dir: Path, filename: str, entries: list[dict]) -> str:
    """Write a JSONL segment file and return its SHA-256 checksum."""
    seg_path = seg_dir / filename
    payload = ""
    for e in entries:
        payload += json.dumps(e, ensure_ascii=False) + "\n"
    seg_path.write_text(payload, encoding="utf-8")
    return _sha256_bytes(payload.encode("utf-8"))


def _write_manifest(seg_dir: Path, manifest: dict) -> None:
    """Write manifest.json."""
    path = seg_dir / "manifest.json"
    path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")


def _build_healthy_store(workspace: Path) -> dict:
    """Create a fully healthy store and return the manifest dict."""
    seg_dir = workspace / "segments"
    seg_dir.mkdir(parents=True, exist_ok=True)

    # Write two segments
    entries1 = [_make_entry("memory one", "aaa111"), _make_entry("memory two", "bbb222")]
    entries2 = [_make_entry("memory three", "ccc333")]
    cs1 = _write_segment(seg_dir, "seg_0001_20260330T000000Z_2.jsonl", entries1)
    cs2 = _write_segment(seg_dir, "seg_0002_20260330T000100Z_1.jsonl", entries2)

    # Write hot.jsonl (empty)
    (seg_dir / "hot.jsonl").write_text("", encoding="utf-8")

    manifest = {
        "version": "3.2.0",
        "generation": 5,
        "created_at": "2026-03-30T00:00:00+00:00",
        "updated_at": "2026-03-30T00:00:00+00:00",
        "segments": [
            {
                "sequence": 1,
                "filename": "seg_0001_20260330T000000Z_2.jsonl",
                "state": "active",
                "entry_count": 2,
                "size_bytes": 100,
                "checksum_sha256": cs1,
                "flushed_at": "2026-03-30T00:00:00+00:00",
            },
            {
                "sequence": 2,
                "filename": "seg_0002_20260330T000100Z_1.jsonl",
                "state": "active",
                "entry_count": 1,
                "size_bytes": 50,
                "checksum_sha256": cs2,
                "flushed_at": "2026-03-30T00:01:00+00:00",
            },
        ],
        "hot": {
            "filename": "hot.jsonl",
            "put_count": 0,
            "delete_count": 0,
            "last_write_at": None,
        },
        "tombstones": {},
        "search": {"index_generation": 5},
        "migration": None,
    }
    _write_manifest(seg_dir, manifest)
    return manifest


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestSha256File:
    def test_correct_hash(self, tmp_path: Path):
        p = tmp_path / "test.bin"
        data = b"hello world"
        p.write_bytes(data)
        assert sha256_file(p) == _sha256_bytes(data)


class TestCountJsonlEntries:
    def test_valid_lines(self, tmp_path: Path):
        p = tmp_path / "test.jsonl"
        p.write_text('{"a":1}\n{"b":2}\n\n', encoding="utf-8")
        total, valid, malformed = _count_jsonl_entries(p)
        assert total == 2
        assert valid == 2
        assert malformed == 0

    def test_malformed_lines(self, tmp_path: Path):
        p = tmp_path / "test.jsonl"
        p.write_text('{"a":1}\nNOT JSON\n[1,2]\n', encoding="utf-8")
        total, valid, malformed = _count_jsonl_entries(p)
        assert total == 3
        assert valid == 1
        assert malformed == 2


class TestValidateSegment:
    def test_missing_file(self, tmp_path: Path):
        sv = validate_segment(tmp_path / "nonexistent.jsonl")
        assert not sv.ok
        assert not sv.exists
        assert any(i.code == "missing_segment_file" for i in sv.issues)

    def test_valid_segment(self, tmp_path: Path):
        entries = [_make_entry("test")]
        payload = json.dumps(entries[0]) + "\n"
        seg_path = tmp_path / "seg.jsonl"
        seg_path.write_text(payload, encoding="utf-8")
        expected_cs = _sha256_bytes(payload.encode("utf-8"))

        sv = validate_segment(seg_path, checksum_expected=expected_cs)
        assert sv.ok
        assert sv.exists
        assert sv.checksum_actual == expected_cs
        assert sv.entry_count == 1

    def test_checksum_mismatch(self, tmp_path: Path):
        seg_path = tmp_path / "seg.jsonl"
        seg_path.write_text('{"a":1}\n', encoding="utf-8")

        sv = validate_segment(seg_path, checksum_expected="deadbeef" * 8)
        assert not sv.ok
        assert any(i.code == "checksum_mismatch" for i in sv.issues)

    def test_empty_segment_warning(self, tmp_path: Path):
        seg_path = tmp_path / "seg.jsonl"
        seg_path.write_text("", encoding="utf-8")

        sv = validate_segment(seg_path)
        assert sv.ok  # empty is a warning, not an error
        assert sv.entry_count == 0
        assert any(i.code == "segment_empty" for i in sv.issues)

    def test_no_checksum_check_when_none(self, tmp_path: Path):
        seg_path = tmp_path / "seg.jsonl"
        seg_path.write_text('{"a":1}\n', encoding="utf-8")

        sv = validate_segment(seg_path, checksum_expected=None)
        assert sv.ok
        assert sv.checksum_actual is not None


class TestValidateHot:
    def test_missing_hot(self, tmp_path: Path):
        hv = validate_hot(tmp_path / "hot.jsonl")
        assert not hv.ok
        assert not hv.exists
        assert any(i.code == "missing_hot_file" for i in hv.issues)

    def test_empty_hot(self, tmp_path: Path):
        hot_path = tmp_path / "hot.jsonl"
        hot_path.write_text("", encoding="utf-8")

        hv = validate_hot(hot_path)
        assert hv.ok
        assert hv.total_lines == 0
        assert hv.put_count == 0
        assert hv.delete_count == 0

    def test_valid_hot_ops(self, tmp_path: Path):
        hot_path = tmp_path / "hot.jsonl"
        ops = [
            json.dumps({"op": "put", "hash": "aaa", "entry": {}, "ts": "2026-01-01"}),
            json.dumps({"op": "put", "hash": "bbb", "entry": {}, "ts": "2026-01-01"}),
            json.dumps({"op": "delete", "hash": "ccc", "reason": "test", "ts": "2026-01-01"}),
        ]
        hot_path.write_text("\n".join(ops) + "\n", encoding="utf-8")

        hv = validate_hot(hot_path)
        assert hv.ok
        assert hv.put_count == 2
        assert hv.delete_count == 1
        assert hv.valid_lines == 3
        assert hv.malformed_lines == 0

    def test_malformed_hot_lines(self, tmp_path: Path):
        hot_path = tmp_path / "hot.jsonl"
        hot_path.write_text('{"op":"put","hash":"a","entry":{},"ts":"x"}\nBAD LINE\n', encoding="utf-8")

        hv = validate_hot(hot_path)
        assert not hv.ok
        assert hv.malformed_lines == 1
        assert any(i.code == "hot_malformed_line" for i in hv.issues)

    def test_oversized_hot_warning(self, tmp_path: Path):
        hot_path = tmp_path / "hot.jsonl"
        # Write just enough to trigger the warning at a low threshold
        hot_path.write_text('{"op":"put"}\n' * 100, encoding="utf-8")

        hv = validate_hot(hot_path, size_warning_bytes=100)
        # Should have the oversized warning
        assert any(i.code == "hot_oversized" for i in hv.issues)


class TestScanOrphans:
    def test_no_orphans(self, tmp_path: Path):
        seg_dir = tmp_path / "segments"
        seg_dir.mkdir()
        seg_file = seg_dir / "seg_0001.jsonl"
        seg_file.write_text("{}\n", encoding="utf-8")

        orphans = scan_orphans(tmp_path, {seg_file})
        assert orphans == []

    def test_finds_orphans(self, tmp_path: Path):
        seg_dir = tmp_path / "segments"
        seg_dir.mkdir()
        referenced = seg_dir / "seg_0001.jsonl"
        referenced.write_text("{}\n", encoding="utf-8")
        orphan = seg_dir / "seg_9999.jsonl"
        orphan.write_text("{}\n", encoding="utf-8")

        orphans = scan_orphans(tmp_path, {referenced})
        assert len(orphans) == 1
        assert orphans[0].name == "seg_9999.jsonl"

    def test_ignores_tmp_files(self, tmp_path: Path):
        seg_dir = tmp_path / "segments"
        seg_dir.mkdir()
        (seg_dir / "something.tmp").write_text("", encoding="utf-8")

        orphans = scan_orphans(tmp_path, set())
        assert orphans == []

    def test_ignores_manifest_files(self, tmp_path: Path):
        seg_dir = tmp_path / "segments"
        seg_dir.mkdir()
        (seg_dir / "manifest.json").write_text("{}", encoding="utf-8")
        (seg_dir / "manifest.json.bak").write_text("{}", encoding="utf-8")

        orphans = scan_orphans(tmp_path, set())
        assert orphans == []

    def test_no_segments_dir(self, tmp_path: Path):
        orphans = scan_orphans(tmp_path, set())
        assert orphans == []


class TestValidateStoreHealthy:
    def test_healthy_store_ok(self, tmp_path: Path):
        _build_healthy_store(tmp_path)
        report = validate_store(tmp_path)
        assert report.ok
        assert report.error_count() == 0
        assert len(report.segments) == 2
        assert report.total_physical_entries == 3
        assert report.generation == 5

    def test_healthy_store_json_output(self, tmp_path: Path):
        _build_healthy_store(tmp_path)
        report = validate_store(tmp_path)
        j = report.to_json()
        parsed = json.loads(j)
        assert parsed["ok"] is True
        assert parsed["error_count"] == 0
        assert "segments" in parsed
        assert "hot" in parsed


class TestValidateStoreMissingManifest:
    def test_missing_manifest(self, tmp_path: Path):
        seg_dir = tmp_path / "segments"
        seg_dir.mkdir(parents=True)
        # No manifest.json

        report = validate_store(tmp_path)
        assert not report.ok
        assert any(i.code == "missing_manifest" for i in report.issues)


class TestValidateStoreCorruptManifest:
    def test_unparseable_manifest(self, tmp_path: Path):
        seg_dir = tmp_path / "segments"
        seg_dir.mkdir(parents=True)
        (seg_dir / "manifest.json").write_text("NOT JSON {{{", encoding="utf-8")

        report = validate_store(tmp_path)
        assert not report.ok
        assert any(i.code == "invalid_manifest" for i in report.issues)

    def test_manifest_not_dict(self, tmp_path: Path):
        seg_dir = tmp_path / "segments"
        seg_dir.mkdir(parents=True)
        (seg_dir / "manifest.json").write_text("[1, 2, 3]", encoding="utf-8")

        report = validate_store(tmp_path)
        assert not report.ok
        assert any(i.code == "invalid_manifest" for i in report.issues)


class TestValidateStoreMissingSegment:
    def test_missing_segment_file(self, tmp_path: Path):
        seg_dir = tmp_path / "segments"
        seg_dir.mkdir(parents=True)
        (seg_dir / "hot.jsonl").write_text("", encoding="utf-8")

        manifest = {
            "version": "3.2.0",
            "generation": 1,
            "segments": [
                {
                    "sequence": 1,
                    "filename": "seg_0001_missing.jsonl",
                    "state": "active",
                    "entry_count": 5,
                    "size_bytes": 100,
                    "checksum_sha256": "abc123",
                    "flushed_at": "2026-03-30T00:00:00+00:00",
                }
            ],
            "hot": {"filename": "hot.jsonl"},
            "tombstones": {},
            "search": {"index_generation": 1},
        }
        _write_manifest(seg_dir, manifest)

        report = validate_store(tmp_path)
        assert not report.ok
        assert any(i.code == "missing_segment_file" for i in report.issues)


class TestValidateStoreDuplicateSequence:
    def test_duplicate_sequence(self, tmp_path: Path):
        seg_dir = tmp_path / "segments"
        seg_dir.mkdir(parents=True)
        (seg_dir / "hot.jsonl").write_text("", encoding="utf-8")

        # Write two segment files
        cs1 = _write_segment(seg_dir, "seg_0001a.jsonl", [_make_entry("a", "aaa")])
        cs2 = _write_segment(seg_dir, "seg_0001b.jsonl", [_make_entry("b", "bbb")])

        manifest = {
            "version": "3.2.0",
            "generation": 2,
            "segments": [
                {
                    "sequence": 1,
                    "filename": "seg_0001a.jsonl",
                    "state": "active",
                    "entry_count": 1,
                    "size_bytes": 50,
                    "checksum_sha256": cs1,
                    "flushed_at": "2026-03-30T00:00:00+00:00",
                },
                {
                    "sequence": 1,  # DUPLICATE
                    "filename": "seg_0001b.jsonl",
                    "state": "active",
                    "entry_count": 1,
                    "size_bytes": 50,
                    "checksum_sha256": cs2,
                    "flushed_at": "2026-03-30T00:00:00+00:00",
                },
            ],
            "hot": {"filename": "hot.jsonl"},
            "tombstones": {},
            "search": {"index_generation": 2},
        }
        _write_manifest(seg_dir, manifest)

        report = validate_store(tmp_path)
        assert any(i.code == "duplicate_sequence" for i in report.issues)


class TestValidateStoreChecksumMismatch:
    def test_segment_checksum_mismatch(self, tmp_path: Path):
        seg_dir = tmp_path / "segments"
        seg_dir.mkdir(parents=True)
        (seg_dir / "hot.jsonl").write_text("", encoding="utf-8")

        _write_segment(seg_dir, "seg_0001.jsonl", [_make_entry("test")])

        manifest = {
            "version": "3.2.0",
            "generation": 1,
            "segments": [
                {
                    "sequence": 1,
                    "filename": "seg_0001.jsonl",
                    "state": "active",
                    "entry_count": 1,
                    "size_bytes": 50,
                    "checksum_sha256": "0000000000000000000000000000000000000000000000000000000000000000",
                    "flushed_at": "2026-03-30T00:00:00+00:00",
                }
            ],
            "hot": {"filename": "hot.jsonl"},
            "tombstones": {},
            "search": {"index_generation": 1},
        }
        _write_manifest(seg_dir, manifest)

        report = validate_store(tmp_path)
        assert not report.ok
        assert any(i.code == "checksum_mismatch" for i in report.issues)


class TestValidateStoreTombstoneOrphans:
    def test_tombstone_orphan_detection(self, tmp_path: Path):
        """Tombstones referencing hashes not in any segment should be flagged."""
        seg_dir = tmp_path / "segments"
        seg_dir.mkdir(parents=True)
        (seg_dir / "hot.jsonl").write_text("", encoding="utf-8")

        cs = _write_segment(seg_dir, "seg_0001.jsonl", [_make_entry("test", "aaa111")])

        manifest = {
            "version": "3.2.0",
            "generation": 3,
            "segments": [
                {
                    "sequence": 1,
                    "filename": "seg_0001.jsonl",
                    "state": "active",
                    "entry_count": 1,
                    "size_bytes": 50,
                    "checksum_sha256": cs,
                    "flushed_at": "2026-03-30T00:00:00+00:00",
                }
            ],
            "hot": {"filename": "hot.jsonl"},
            "tombstones": {
                "aaa111": {"deleted_at": "2026-03-30T00:00:00+00:00", "reason": "test"},
                "zzz999": {"deleted_at": "2026-03-30T00:00:00+00:00", "reason": "orphan"},
            },
            "search": {"index_generation": 3},
        }
        _write_manifest(seg_dir, manifest)

        report = validate_store(tmp_path)
        assert report.tombstone_count == 2
        assert report.tombstone_orphan_count == 1
        assert any(i.code == "tombstone_orphan" for i in report.issues)


class TestValidateStoreSearchIndexStale:
    def test_stale_search_index(self, tmp_path: Path):
        seg_dir = tmp_path / "segments"
        seg_dir.mkdir(parents=True)
        (seg_dir / "hot.jsonl").write_text("", encoding="utf-8")

        cs = _write_segment(seg_dir, "seg_0001.jsonl", [_make_entry("test")])

        manifest = {
            "version": "3.2.0",
            "generation": 10,
            "segments": [
                {
                    "sequence": 1,
                    "filename": "seg_0001.jsonl",
                    "state": "active",
                    "entry_count": 1,
                    "size_bytes": 50,
                    "checksum_sha256": cs,
                    "flushed_at": "2026-03-30T00:00:00+00:00",
                }
            ],
            "hot": {"filename": "hot.jsonl"},
            "tombstones": {},
            "search": {"index_generation": 3},  # Behind store gen
        }
        _write_manifest(seg_dir, manifest)

        report = validate_store(tmp_path)
        assert any(i.code == "search_index_stale" for i in report.issues)


class TestValidateStoreOrphanFiles:
    def test_orphan_file_detected(self, tmp_path: Path):
        _build_healthy_store(tmp_path)
        # Add an orphan file
        orphan = tmp_path / "segments" / "stale_segment.jsonl"
        orphan.write_text('{"content":"orphan"}\n', encoding="utf-8")

        report = validate_store(tmp_path)
        assert any(i.code == "orphan_file" for i in report.issues)
        assert str(orphan) in report.orphan_paths


class TestValidateStoreEntryCounts:
    def test_physical_vs_logical_counts(self, tmp_path: Path):
        seg_dir = tmp_path / "segments"
        seg_dir.mkdir(parents=True)

        entries = [_make_entry(f"mem{i}", f"hash{i:03d}") for i in range(5)]
        cs = _write_segment(seg_dir, "seg_0001.jsonl", entries)

        # Hot buffer with 2 puts
        hot_ops = [
            json.dumps({"op": "put", "hash": "hot1", "entry": _make_entry("hot1", "hot1"), "ts": "2026-01-01"}),
            json.dumps({"op": "put", "hash": "hot2", "entry": _make_entry("hot2", "hot2"), "ts": "2026-01-01"}),
        ]
        (seg_dir / "hot.jsonl").write_text("\n".join(hot_ops) + "\n", encoding="utf-8")

        manifest = {
            "version": "3.2.0",
            "generation": 5,
            "segments": [
                {
                    "sequence": 1,
                    "filename": "seg_0001.jsonl",
                    "state": "active",
                    "entry_count": 5,
                    "size_bytes": 100,
                    "checksum_sha256": cs,
                    "flushed_at": "2026-03-30T00:00:00+00:00",
                }
            ],
            "hot": {"filename": "hot.jsonl"},
            "tombstones": {
                "hash001": {"deleted_at": "2026-03-30T00:00:00+00:00", "reason": "test"},
            },
            "search": {"index_generation": 5},
        }
        _write_manifest(seg_dir, manifest)

        report = validate_store(tmp_path)
        # Physical = 5 (segment) + 2 (hot puts) = 7
        assert report.total_physical_entries == 7
        # Logical = 5 (segment) - 1 (tombstone) = 4 (hot not subtracted)
        assert report.total_logical_entries == 4
        assert report.tombstone_count == 1


class TestValidateStoreMissingHot:
    def test_missing_hot_file(self, tmp_path: Path):
        seg_dir = tmp_path / "segments"
        seg_dir.mkdir(parents=True)

        manifest = {
            "version": "3.2.0",
            "generation": 0,
            "segments": [],
            "hot": {"filename": "hot.jsonl"},
            "tombstones": {},
            "search": {"index_generation": 0},
        }
        _write_manifest(seg_dir, manifest)
        # Do NOT create hot.jsonl

        report = validate_store(tmp_path)
        assert not report.ok
        assert any(i.code == "missing_hot_file" for i in report.issues)


class TestValidateStoreManifestSchemaError:
    def test_missing_required_keys(self, tmp_path: Path):
        seg_dir = tmp_path / "segments"
        seg_dir.mkdir(parents=True)
        (seg_dir / "hot.jsonl").write_text("", encoding="utf-8")

        # Manifest missing 'segments' and 'tombstones'
        manifest = {
            "version": "3.2.0",
            "generation": 0,
            "hot": {"filename": "hot.jsonl"},
        }
        _write_manifest(seg_dir, manifest)

        report = validate_store(tmp_path)
        schema_issues = [i for i in report.issues if i.code == "manifest_schema_error"]
        assert len(schema_issues) >= 2  # missing segments and tombstones


class TestValidationReportSerialization:
    def test_to_dict_roundtrip(self, tmp_path: Path):
        _build_healthy_store(tmp_path)
        report = validate_store(tmp_path)
        d = report.to_dict()

        assert isinstance(d, dict)
        assert d["ok"] is True
        assert isinstance(d["segments"], list)
        assert isinstance(d["issues"], list)
        assert "hot" in d

    def test_to_json_valid(self, tmp_path: Path):
        _build_healthy_store(tmp_path)
        report = validate_store(tmp_path)
        j = report.to_json()
        parsed = json.loads(j)
        assert parsed["workspace"] == str(tmp_path)

    def test_error_report_json(self, tmp_path: Path):
        seg_dir = tmp_path / "segments"
        seg_dir.mkdir(parents=True)
        # Corrupt manifest
        (seg_dir / "manifest.json").write_text("BROKEN", encoding="utf-8")

        report = validate_store(tmp_path)
        j = report.to_json()
        parsed = json.loads(j)
        assert parsed["ok"] is False
        assert parsed["error_count"] > 0


class TestValidationIssueToDict:
    def test_minimal_issue(self):
        issue = ValidationIssue(
            severity="error",
            code="missing_manifest",
            message="Manifest is missing.",
        )
        d = issue.to_dict()
        assert d["severity"] == "error"
        assert d["code"] == "missing_manifest"
        assert "path" not in d  # None path omitted
        assert "details" not in d  # Empty details omitted

    def test_full_issue(self):
        issue = ValidationIssue(
            severity="warning",
            code="orphan_file",
            message="Orphan found.",
            path="/tmp/orphan.jsonl",
            details={"size": 1024},
        )
        d = issue.to_dict()
        assert d["path"] == "/tmp/orphan.jsonl"
        assert d["details"]["size"] == 1024


class TestValidateStoreHotWithMalformedLines:
    def test_hot_malformed_lines_cause_error(self, tmp_path: Path):
        seg_dir = tmp_path / "segments"
        seg_dir.mkdir(parents=True)

        manifest = {
            "version": "3.2.0",
            "generation": 0,
            "segments": [],
            "hot": {"filename": "hot.jsonl"},
            "tombstones": {},
            "search": {"index_generation": 0},
        }
        _write_manifest(seg_dir, manifest)

        # Hot with malformed lines
        (seg_dir / "hot.jsonl").write_text(
            '{"op":"put","hash":"a","entry":{},"ts":"x"}\n'
            'THIS IS NOT JSON\n'
            '{"op":"delete","hash":"b","reason":"test","ts":"x"}\n',
            encoding="utf-8",
        )

        report = validate_store(tmp_path)
        assert not report.ok
        assert any(i.code == "hot_malformed_line" for i in report.issues)


class TestValidateStoreEntryCountMismatch:
    def test_entry_count_mismatch_warning(self, tmp_path: Path):
        """When manifest says N entries but file has M, emit a warning."""
        seg_dir = tmp_path / "segments"
        seg_dir.mkdir(parents=True)
        (seg_dir / "hot.jsonl").write_text("", encoding="utf-8")

        # Write 3 entries but manifest says 5
        entries = [_make_entry(f"e{i}", f"h{i}") for i in range(3)]
        cs = _write_segment(seg_dir, "seg_0001.jsonl", entries)

        manifest = {
            "version": "3.2.0",
            "generation": 1,
            "segments": [
                {
                    "sequence": 1,
                    "filename": "seg_0001.jsonl",
                    "state": "active",
                    "entry_count": 5,  # WRONG — file has 3
                    "size_bytes": 100,
                    "checksum_sha256": cs,
                    "flushed_at": "2026-03-30T00:00:00+00:00",
                }
            ],
            "hot": {"filename": "hot.jsonl"},
            "tombstones": {},
            "search": {"index_generation": 1},
        }
        _write_manifest(seg_dir, manifest)

        report = validate_store(tmp_path)
        # Should have a warning about count mismatch
        mismatch_issues = [
            i for i in report.issues
            if "manifest says" in i.message and "entries" in i.message
        ]
        assert len(mismatch_issues) == 1


class TestImportFromPackage:
    """Verify that validate_store and ValidationReport are importable from the package."""

    def test_import_from_storage(self):
        from parsica_memory.storage import ValidationReport, validate_store
        assert callable(validate_store)
        assert ValidationReport is not None
