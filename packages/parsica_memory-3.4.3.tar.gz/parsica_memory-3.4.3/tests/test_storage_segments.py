from __future__ import annotations

import json
import os
import tempfile
import threading
import unittest

from parsica_memory.entry import MemoryEntry
from parsica_memory.storage.segments import HotBuffer, SegmentReader, SegmentWriter


class StorageSegmentsTestCase(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp_dir.cleanup)
        self.root = self.temp_dir.name
        self.segment_path = os.path.join(self.root, "seg_0001_test_2.jsonl")
        self.segments_dir = os.path.join(self.root, "segments")
        os.makedirs(self.segments_dir, exist_ok=True)

    def make_entry(
        self,
        content: str = "hello",
        source: str = "discord",
        line: int = 1,
        category: str = "conversation",
        created: str = "2026-03-30T05:00:00+00:00",
        memory_type: str = "episodic",
        session_id: str = "sess-1",
        agent_id: str = "moro",
        source_channel: str = "discord:123",
    ) -> MemoryEntry:
        entry = MemoryEntry(
            content=content,
            source=source,
            line=line,
            category=category,
            created=created,
            memory_type=memory_type,
            session_id=session_id,
            agent_id=agent_id,
            source_channel=source_channel,
        )
        entry.last_accessed = created
        entry.access_count = 3
        entry.importance = 1.2345
        entry.confidence = 0.8765
        entry.sentiment = {"joy": 0.8}
        entry.tags = ["alpha", "beta"]
        entry.related = ["rel-1", "rel-2"]
        entry.type_metadata = {"foo": "bar"}
        entry.enriched_summary = "rich summary"
        entry.search_keywords = ["keyword1", "keyword2"]
        entry.search_queries = ["how to hello", "hello summary"]
        entry.source_url = "https://example.com/item"
        entry.content_hash = "content-hash-123"
        entry.provenance = "derived"
        entry.parent_hash = "parent-123"
        entry.sighting_count = 7
        entry.last_sighted = "2026-03-30T05:10:00+00:00"
        return entry

    def test_write_read_segment_preserves_all_fields(self):
        entry = self.make_entry()
        SegmentWriter.write_segment(self.segment_path, [entry])
        loaded = SegmentReader.read_segment(self.segment_path)
        self.assertEqual(len(loaded), 1)
        loaded_entry = loaded[0]
        self.assertEqual(loaded_entry.to_dict(), entry.to_dict())
        self.assertEqual(loaded_entry.enriched_summary, "rich summary")
        self.assertEqual(loaded_entry.search_keywords, ["keyword1", "keyword2"])
        self.assertEqual(loaded_entry.search_queries, ["how to hello", "hello summary"])
        self.assertEqual(loaded_entry.provenance, "derived")
        self.assertEqual(loaded_entry.parent_hash, "parent-123")
        self.assertEqual(loaded_entry.sighting_count, 7)
        self.assertEqual(loaded_entry.source_channel, "discord:123")

    def test_write_empty_segment(self):
        meta = SegmentWriter.write_segment(self.segment_path, [])
        self.assertTrue(os.path.exists(self.segment_path))
        self.assertEqual(SegmentReader.read_segment(self.segment_path), [])
        self.assertEqual(meta["entry_count"], 0)
        self.assertEqual(meta["size_bytes"], 0)
        self.assertEqual(meta["checksum_sha256"], "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
        self.assertEqual(meta["categories"], {})
        self.assertEqual(meta["memory_types"], {})
        self.assertEqual(meta["originals_count"], 0)
        self.assertEqual(meta["derived_count"], 0)
        self.assertFalse(meta["has_lineage_fields"])

    def test_large_segment_round_trip(self):
        entries = [
            self.make_entry(
                content=f"entry {i}",
                line=i,
                created=f"2026-03-30T05:{i % 60:02d}:00+00:00",
                session_id=f"sess-{i}",
            )
            for i in range(1200)
        ]
        meta = SegmentWriter.write_segment(self.segment_path, entries)
        loaded = SegmentReader.read_segment(self.segment_path)
        self.assertEqual(len(loaded), 1200)
        self.assertEqual(meta["entry_count"], 1200)
        self.assertEqual(loaded[1199].content, "entry 1199")

    def test_malformed_line_in_segment_is_skipped(self):
        first = self.make_entry(content="first")
        second = self.make_entry(content="second", line=2)
        with open(self.segment_path, "w", encoding="utf-8") as handle:
            handle.write(json.dumps(first.to_dict(), ensure_ascii=False) + "\n")
            handle.write("{bad json\n")
            handle.write(json.dumps(second.to_dict(), ensure_ascii=False) + "\n")
        loaded = SegmentReader.read_segment(self.segment_path)
        self.assertEqual([entry.content for entry in loaded], ["first", "second"])

    def test_verify_checksum_valid(self):
        entry = self.make_entry()
        meta = SegmentWriter.write_segment(self.segment_path, [entry])
        self.assertTrue(SegmentReader.verify_checksum(self.segment_path, meta["checksum_sha256"]))

    def test_verify_checksum_corrupted(self):
        entry = self.make_entry()
        meta = SegmentWriter.write_segment(self.segment_path, [entry])
        with open(self.segment_path, "a", encoding="utf-8") as handle:
            handle.write("corruption\n")
        self.assertFalse(SegmentReader.verify_checksum(self.segment_path, meta["checksum_sha256"]))

    def test_segment_metadata_aggregation(self):
        original = self.make_entry(content="orig", category="conversation", memory_type="episodic")
        original.provenance = "self"
        original.parent_hash = ""
        derived = self.make_entry(
            content="derived",
            category="strategic",
            memory_type="fact",
            session_id="sess-2",
            agent_id="san",
            source_channel="discord:999",
        )
        derived.provenance = "decomposed"
        derived.parent_hash = "orig-hash"
        meta = SegmentWriter.write_segment(self.segment_path, [original, derived])
        self.assertEqual(meta["categories"], {"conversation": 1, "strategic": 1})
        self.assertEqual(meta["memory_types"], {"episodic": 1, "fact": 1})
        self.assertEqual(meta["originals_count"], 1)
        self.assertEqual(meta["derived_count"], 1)
        self.assertEqual(meta["agent_ids"], ["moro", "san"])
        self.assertEqual(meta["session_ids_sample"], ["sess-1", "sess-2"])
        self.assertEqual(meta["source_channels"], ["discord:123", "discord:999"])
        self.assertTrue(meta["has_lineage_fields"])

    def test_segment_metadata_created_range(self):
        early = self.make_entry(created="2026-03-30T01:00:00+00:00")
        late = self.make_entry(created="2026-03-30T09:00:00+00:00", line=2)
        meta = SegmentWriter.write_segment(self.segment_path, [late, early])
        self.assertEqual(meta["min_created"], "2026-03-30T01:00:00+00:00")
        self.assertEqual(meta["max_created"], "2026-03-30T09:00:00+00:00")

    def test_read_segment_hashes(self):
        first = self.make_entry(content="first")
        second = self.make_entry(content="second", line=2)
        SegmentWriter.write_segment(self.segment_path, [first, second])
        hashes = SegmentReader.read_segment_hashes(self.segment_path)
        self.assertEqual(hashes, {first.hash, second.hash})

    def test_read_segment_hashes_skips_malformed_lines(self):
        entry = self.make_entry()
        with open(self.segment_path, "w", encoding="utf-8") as handle:
            handle.write(json.dumps(entry.to_dict(), ensure_ascii=False) + "\n")
            handle.write("not-json\n")
        hashes = SegmentReader.read_segment_hashes(self.segment_path)
        self.assertEqual(hashes, {entry.hash})

    def test_verify_checksum_missing_file_false(self):
        self.assertFalse(SegmentReader.verify_checksum(self.segment_path, "abc"))

    def test_hot_buffer_append_put_read_ops(self):
        hot = HotBuffer(self.segments_dir)
        entry = self.make_entry()
        hot.append_put(entry)
        ops = hot.read_ops()
        self.assertEqual(len(ops), 1)
        self.assertEqual(ops[0]["op"], "put")
        self.assertEqual(ops[0]["hash"], entry.hash)
        self.assertEqual(ops[0]["entry"], entry.to_dict())
        self.assertIn("ts", ops[0])

    def test_hot_buffer_append_delete_read_ops(self):
        hot = HotBuffer(self.segments_dir)
        hot.append_delete("hash-1", "forget(topic=test)")
        ops = hot.read_ops()
        self.assertEqual(len(ops), 1)
        self.assertEqual(ops[0]["op"], "delete")
        self.assertEqual(ops[0]["hash"], "hash-1")
        self.assertEqual(ops[0]["reason"], "forget(topic=test)")

    def test_hot_buffer_rotate_creates_rotating_and_new_empty_hot(self):
        hot = HotBuffer(self.segments_dir)
        entry = self.make_entry()
        hot.append_put(entry)
        rotating = hot.rotate()
        self.assertTrue(os.path.exists(rotating))
        self.assertTrue(os.path.exists(hot.hot_path))
        self.assertEqual(os.path.getsize(hot.hot_path), 0)
        with open(rotating, "r", encoding="utf-8") as handle:
            content = handle.read()
        self.assertIn(entry.hash, content)

    def test_hot_buffer_replay_separates_puts_and_deletes(self):
        hot = HotBuffer(self.segments_dir)
        entry = self.make_entry()
        ops = [
            {"op": "put", "hash": entry.hash, "entry": entry.to_dict(), "ts": "x"},
            {"op": "delete", "hash": "deadbeef", "reason": "x", "ts": "y"},
        ]
        puts, deletes = hot.replay(ops)
        self.assertEqual(len(puts), 1)
        self.assertEqual(puts[0].to_dict(), entry.to_dict())
        self.assertEqual(deletes, {"deadbeef"})

    def test_hot_buffer_mixed_put_delete_operations(self):
        hot = HotBuffer(self.segments_dir)
        first = self.make_entry(content="first")
        second = self.make_entry(content="second", line=2)
        hot.append_put(first)
        hot.append_delete(first.hash, "forget")
        hot.append_put(second)
        ops = hot.read_ops()
        self.assertEqual([op["op"] for op in ops], ["put", "delete", "put"])

    def test_hot_buffer_crash_recovery_detects_rotating(self):
        hot = HotBuffer(self.segments_dir)
        entry = self.make_entry()
        hot.append_put(entry)
        rotating = hot.rotate()
        self.assertTrue(hot.has_rotating())
        self.assertEqual(rotating, hot.rotating_path)

    def test_hot_buffer_stats_tracking(self):
        hot = HotBuffer(self.segments_dir)
        hot.append_put(self.make_entry(content="a"))
        hot.append_put(self.make_entry(content="b", line=2))
        hot.append_delete("hash-x", "cleanup")
        stats = hot.get_stats()
        self.assertEqual(stats["put_count"], 2)
        self.assertEqual(stats["delete_count"], 1)
        self.assertGreater(stats["size_bytes"], 0)

    def test_hot_buffer_cleanup_rotating(self):
        hot = HotBuffer(self.segments_dir)
        hot.append_put(self.make_entry())
        hot.rotate()
        self.assertTrue(hot.has_rotating())
        hot.cleanup_rotating()
        self.assertFalse(hot.has_rotating())

    def test_hot_buffer_concurrent_appends_two_threads(self):
        hot = HotBuffer(self.segments_dir)

        def writer(prefix: str, base_line: int):
            for i in range(50):
                hot.append_put(self.make_entry(content=f"{prefix}-{i}", line=base_line + i))

        t1 = threading.Thread(target=writer, args=("a", 1))
        t2 = threading.Thread(target=writer, args=("b", 1000))
        t1.start()
        t2.start()
        t1.join()
        t2.join()

        ops = hot.read_ops()
        self.assertEqual(len(ops), 100)
        self.assertTrue(all(op["op"] == "put" for op in ops))

    def test_hot_round_trip_memory_entry_from_dict_preserves_all_fields(self):
        hot = HotBuffer(self.segments_dir)
        entry = self.make_entry()
        hot.append_put(entry)
        ops = hot.read_ops()
        round_trip = MemoryEntry.from_dict(ops[0]["entry"])
        self.assertEqual(round_trip.to_dict(), entry.to_dict())

    def test_hot_buffer_read_ops_skips_malformed_lines(self):
        hot = HotBuffer(self.segments_dir)
        with open(hot.hot_path, "w", encoding="utf-8") as handle:
            handle.write('{"op":"delete","hash":"a","reason":"x","ts":"1"}\n')
            handle.write("broken\n")
            handle.write('{"op":"delete","hash":"b","reason":"y","ts":"2"}\n')
        ops = hot.read_ops()
        self.assertEqual(len(ops), 2)
        self.assertEqual([op["hash"] for op in ops], ["a", "b"])

    def test_hot_buffer_rotate_when_rotating_already_exists_is_idempotent(self):
        hot = HotBuffer(self.segments_dir)
        hot.append_put(self.make_entry())
        first_rotating = hot.rotate()
        second_rotating = hot.rotate()
        self.assertEqual(first_rotating, second_rotating)
        self.assertTrue(os.path.exists(first_rotating))

    def test_hot_buffer_initializes_empty_hot_file(self):
        hot = HotBuffer(self.segments_dir)
        self.assertTrue(os.path.exists(hot.hot_path))
        self.assertEqual(os.path.getsize(hot.hot_path), 0)

    def test_replay_ignores_invalid_put_entry_payload(self):
        hot = HotBuffer(self.segments_dir)
        puts, deletes = hot.replay([
            {"op": "put", "hash": "bad", "entry": "not-a-dict", "ts": "x"},
            {"op": "delete", "hash": "gone", "reason": "x", "ts": "y"},
        ])
        self.assertEqual(puts, [])
        self.assertEqual(deletes, {"gone"})

    def test_segment_reader_skips_non_object_json_lines(self):
        entry = self.make_entry(content="ok")
        with open(self.segment_path, "w", encoding="utf-8") as handle:
            handle.write(json.dumps(entry.to_dict(), ensure_ascii=False) + "\n")
            handle.write(json.dumps([1, 2, 3]) + "\n")
        loaded = SegmentReader.read_segment(self.segment_path)
        self.assertEqual(len(loaded), 1)
        self.assertEqual(loaded[0].content, "ok")

    def test_cleanup_rotating_is_safe_when_missing(self):
        hot = HotBuffer(self.segments_dir)
        hot.cleanup_rotating()
        self.assertFalse(hot.has_rotating())

    # -------------------------------------------------------------------------
    # NEW TESTS — Fix 1: rotate() crash recovery (hot.jsonl missing)
    # -------------------------------------------------------------------------

    def test_hot_buffer_rotate_heals_missing_hot_jsonl_after_crash(self):
        """Crash between rename and create-new: hot.jsonl missing, rotating exists.

        Simulates: previous rotation crashed after os.replace(hot→rotating) but
        before _create_empty_file(hot).  On the next rotate() call the method
        must detect that hot.jsonl is absent and create it, so writers can
        resume immediately.
        """
        hot = HotBuffer(self.segments_dir)
        entry = self.make_entry()
        hot.append_put(entry)

        # Simulate crash mid-rotate: manually rename without creating new hot.
        os.replace(hot.hot_path, hot.rotating_path)
        self.assertFalse(os.path.exists(hot.hot_path), "test pre-condition: hot.jsonl should not exist")
        self.assertTrue(os.path.exists(hot.rotating_path))

        # rotate() should detect existing rotating, notice hot.jsonl is missing,
        # create it, and return the rotating path.
        rotating = hot.rotate()
        self.assertEqual(rotating, hot.rotating_path)
        self.assertTrue(os.path.exists(hot.hot_path), "rotate() must recreate missing hot.jsonl")
        self.assertEqual(os.path.getsize(hot.hot_path), 0, "recreated hot.jsonl must be empty")

        # Writers must now be able to append without error.
        hot.append_put(self.make_entry(content="after-heal", line=2))
        ops = hot.read_ops()
        self.assertEqual(len(ops), 1)
        self.assertEqual(ops[0]["entry"]["content"], "after-heal")

    # -------------------------------------------------------------------------
    # NEW TESTS — Fix 2: write_segment() no longer takes sequence parameter
    # -------------------------------------------------------------------------

    def test_write_segment_no_sequence_parameter(self):
        """write_segment() must NOT accept a sequence keyword argument."""
        import inspect
        sig = inspect.signature(SegmentWriter.write_segment)
        self.assertNotIn(
            "sequence",
            sig.parameters,
            "sequence parameter must be removed from write_segment() — it was dead code",
        )

    # -------------------------------------------------------------------------
    # NEW TESTS — Fix 3: replay_ordered() preserves interleaved op ordering
    # -------------------------------------------------------------------------

    def test_replay_ordered_preserves_interleaved_put_delete_sequence(self):
        """replay_ordered() must return ops in exact log order."""
        hot = HotBuffer(self.segments_dir)
        entry_a = self.make_entry(content="A", line=1)
        entry_b = self.make_entry(content="B", line=2)

        ops = [
            {"op": "put",    "hash": entry_a.hash, "entry": entry_a.to_dict(), "ts": "1"},
            {"op": "delete", "hash": entry_a.hash, "reason": "pruned",         "ts": "2"},
            {"op": "put",    "hash": entry_b.hash, "entry": entry_b.to_dict(), "ts": "3"},
            {"op": "put",    "hash": entry_a.hash, "entry": entry_a.to_dict(), "ts": "4"},  # re-add
        ]
        ordered = hot.replay_ordered(ops)
        self.assertEqual(len(ordered), 4)
        self.assertEqual([o["op"] for o in ordered], ["put", "delete", "put", "put"])
        self.assertEqual(ordered[1]["hash"], entry_a.hash)

        # Net state: apply in order → entry_a present (re-added after delete)
        entry_map: dict = {}
        for op in ordered:
            if op["op"] == "put":
                try:
                    e = MemoryEntry.from_dict(op["entry"])
                    entry_map[e.hash] = e
                except Exception:
                    pass
            elif op["op"] == "delete":
                entry_map.pop(op["hash"], None)
        self.assertIn(entry_a.hash, entry_map, "entry_a should be present after re-add")
        self.assertIn(entry_b.hash, entry_map)

    def test_replay_ordered_delete_wins_if_last_op(self):
        """replay_ordered(): delete that comes after a put results in absence."""
        hot = HotBuffer(self.segments_dir)
        entry = self.make_entry()
        ops = [
            {"op": "put",    "hash": entry.hash, "entry": entry.to_dict(), "ts": "1"},
            {"op": "delete", "hash": entry.hash, "reason": "gone",         "ts": "2"},
        ]
        ordered = hot.replay_ordered(ops)
        entry_map: dict = {}
        for op in ordered:
            if op["op"] == "put":
                try:
                    e = MemoryEntry.from_dict(op["entry"])
                    entry_map[e.hash] = e
                except Exception:
                    pass
            elif op["op"] == "delete":
                entry_map.pop(op["hash"], None)
        self.assertNotIn(entry.hash, entry_map, "delete-last must remove the entry")

    # -------------------------------------------------------------------------
    # NEW TESTS — Fix 4a: Unicode / emoji content in write_segment
    # -------------------------------------------------------------------------

    def test_write_segment_unicode_and_emoji_content(self):
        """write_segment() must correctly round-trip Unicode and emoji content."""
        emoji_content = "🔥 Memory: こんにちは world ← → café résumé 中文 😊🚀"
        entry = self.make_entry(content=emoji_content)
        meta = SegmentWriter.write_segment(self.segment_path, [entry])

        # Checksum must be self-consistent.
        self.assertTrue(SegmentReader.verify_checksum(self.segment_path, meta["checksum_sha256"]))

        loaded = SegmentReader.read_segment(self.segment_path)
        self.assertEqual(len(loaded), 1)
        self.assertEqual(loaded[0].content, emoji_content)

    def test_write_segment_ensure_ascii_false(self):
        """Non-ASCII bytes must be written raw (not \\uXXXX escaped)."""
        entry = self.make_entry(content="こんにちは")
        SegmentWriter.write_segment(self.segment_path, [entry])
        raw = open(self.segment_path, "rb").read()
        # If ensure_ascii=False the UTF-8 bytes for こんにちは appear literally.
        self.assertIn("こんにちは".encode("utf-8"), raw)

    # -------------------------------------------------------------------------
    # NEW TESTS — Fix 4b: segment files > 4 MB
    # -------------------------------------------------------------------------

    def test_write_segment_larger_than_4mb(self):
        """write_segment() must handle files that exceed the 4 MB hot-buffer threshold."""
        # Each entry has ~1 KB of content → 5000 entries ≈ 5 MB
        entries = [
            self.make_entry(
                content="x" * 1024,
                line=i,
                session_id=f"sess-{i}",
            )
            for i in range(5000)
        ]
        meta = SegmentWriter.write_segment(self.segment_path, entries)

        size = os.path.getsize(self.segment_path)
        self.assertGreater(size, 4 * 1024 * 1024, "segment file must be > 4 MB")
        self.assertEqual(meta["entry_count"], 5000)
        self.assertEqual(meta["size_bytes"], size)

        # Checksum must still verify.
        self.assertTrue(SegmentReader.verify_checksum(self.segment_path, meta["checksum_sha256"]))

        # Round-trip all entries.
        loaded = SegmentReader.read_segment(self.segment_path)
        self.assertEqual(len(loaded), 5000)

    # -------------------------------------------------------------------------
    # NEW TESTS — Fix 4c: concurrent rotate + append interleaving
    # -------------------------------------------------------------------------

    def test_hot_buffer_concurrent_rotate_and_append(self):
        """Concurrent rotate() and append_put() must not corrupt either log file.

        One thread rotates once while another appends entries concurrently.
        We do NOT call cleanup_rotating() between iterations — that would
        intentionally discard entries that were rotated before the appender
        finished, which is expected behaviour (cleanup = "I've consumed this").

        The correctness invariants we verify:
        1. No exceptions raised by either thread.
        2. Every file that exists contains only valid JSON lines (no torn writes).
        3. The union of hot.jsonl + hot.rotating.jsonl contains all entries that
           were appended *before* the rotate completed (i.e. none are corrupted).
           Entries appended concurrently with the rotate may land in either file,
           but they must not be silently dropped or garbled.
        """
        hot = HotBuffer(self.segments_dir)
        n_entries = 60
        appended_hashes: list[str] = []
        errors: list[Exception] = []

        def appender():
            for i in range(n_entries):
                try:
                    e = self.make_entry(content=f"concurrent-{i}", line=i + 1)
                    appended_hashes.append(e.hash)
                    hot.append_put(e)
                except Exception as exc:
                    errors.append(exc)

        def rotator():
            # Rotate once in the middle of the appends.
            import time
            time.sleep(0.002)   # let a few appends land first
            try:
                hot.rotate()
            except Exception as exc:
                errors.append(exc)

        t_append = threading.Thread(target=appender)
        t_rotate = threading.Thread(target=rotator)
        t_append.start()
        t_rotate.start()
        t_append.join()
        t_rotate.join()

        self.assertEqual(errors, [], f"Unexpected errors during concurrent test: {errors}")

        # Collect all ops from wherever they landed (hot + rotating).
        all_ops: list[dict] = []
        for path in (hot.hot_path, hot.rotating_path):
            if os.path.exists(path):
                with open(path, "r", encoding="utf-8") as fh:
                    for ln, raw in enumerate(fh, 1):
                        raw = raw.strip()
                        if not raw:
                            continue
                        try:
                            all_ops.append(json.loads(raw))
                        except json.JSONDecodeError as exc:
                            self.fail(f"Corrupt JSON line in {path}:{ln} — {exc}")

        # All entries must be present across both files with no corruption.
        found_hashes = {op["hash"] for op in all_ops if op.get("op") == "put"}
        for h in appended_hashes:
            self.assertIn(h, found_hashes, f"Entry {h} lost during concurrent rotate+append")


if __name__ == "__main__":
    unittest.main()
