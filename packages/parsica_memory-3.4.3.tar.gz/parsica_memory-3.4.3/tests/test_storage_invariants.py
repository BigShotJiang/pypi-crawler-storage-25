"""Tests for PR 1 — Storage Invariants Enforcement.

Validates:
- Manifest semantic validation rejects impossible states
- SegmentStore invariant assertions catch divergence
- Core save/flush/forget route through SegmentStore when active
- Legacy write paths are disabled in segmented mode
- No WAL writes occur in segmented mode

All tests use ``unittest`` (zero external deps).
"""

from __future__ import annotations

import json
import os
import shutil
import tempfile
import time
import unittest
from datetime import datetime, timezone, timedelta
from unittest import mock

from parsica_memory.entry import MemoryEntry
from parsica_memory.storage.segment_store import SegmentStore
from parsica_memory.storage.manifest import Manifest
from parsica_memory.storage.segments import SegmentWriter


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_entry(content: str = "test memory", **kwargs) -> MemoryEntry:
    """Create a ``MemoryEntry`` with sensible defaults."""
    defaults = {
        "source": "unit_test",
        "category": "general",
        "memory_type": "episodic",
    }
    defaults.update(kwargs)
    return MemoryEntry(content=content, **defaults)


def _make_entries(n: int, prefix: str = "mem") -> list[MemoryEntry]:
    """Create *n* unique entries."""
    return [_make_entry(f"{prefix}_{i}_padding_to_reach_min_length") for i in range(n)]


def _read_manifest_raw(path: str) -> dict:
    """Read manifest.json directly from disk."""
    if not os.path.exists(path):
        return {}
    with open(path, "r") as f:
        return json.load(f)


class InvariantTestBase(unittest.TestCase):
    """Base class that creates / tears-down a temp workspace."""

    def setUp(self) -> None:
        self.tmp = tempfile.mkdtemp()
        self.store = SegmentStore(
            self.tmp,
            hot_max_ops=100,
            hot_max_bytes=4_194_304,
            hot_max_age_seconds=300,
            hot_min_ops=5,
        )

    def tearDown(self) -> None:
        shutil.rmtree(self.tmp, ignore_errors=True)


# ===================================================================
# Manifest semantic validation
# ===================================================================

class TestManifestSemanticValidation(unittest.TestCase):
    """Test that Manifest.validate() rejects impossible states."""

    def setUp(self) -> None:
        self.tmp = tempfile.mkdtemp()
        self.seg_dir = os.path.join(self.tmp, "segments")
        os.makedirs(self.seg_dir, exist_ok=True)

    def tearDown(self) -> None:
        shutil.rmtree(self.tmp, ignore_errors=True)

    def _write_manifest(self, data: dict) -> str:
        """Write a manifest.json to the segments dir and return its path."""
        path = os.path.join(self.seg_dir, "manifest.json")
        with open(path, "w") as f:
            json.dump(data, f)
        return path

    def _make_manifest_with_segments(self, segments: list[dict]) -> Manifest:
        """Create a Manifest instance with the given segment list."""
        now = datetime.now(timezone.utc).isoformat()
        data = {
            "version": "3.2.0",
            "generation": 10,
            "created_at": now,
            "updated_at": now,
            "segments": segments,
            "hot": {
                "filename": "hot.jsonl",
                "put_count": 0,
                "delete_count": 0,
                "last_write_at": None,
            },
            "tombstones": {},
            "search": {"index_generation": 0},
            "migration": None,
        }
        self._write_manifest(data)
        m = Manifest(self.seg_dir)
        return m

    def test_manifest_semantic_validation_rejects_duplicate_sequences(self):
        """Manifest with two segments sharing the same sequence number must fail validation."""
        # Create two real segment files
        entries = [_make_entry(f"entry_{i}_padding_content_here") for i in range(3)]
        fname1 = "seg_0001_20260330T120000Z_3.jsonl"
        fname2 = "seg_0001_20260330T120100Z_3.jsonl"  # same sequence!
        SegmentWriter.write_segment(os.path.join(self.seg_dir, fname1), entries)
        SegmentWriter.write_segment(os.path.join(self.seg_dir, fname2), entries)

        meta1 = SegmentWriter.write_segment(os.path.join(self.seg_dir, fname1), entries)
        meta2 = SegmentWriter.write_segment(os.path.join(self.seg_dir, fname2), entries)

        m = self._make_manifest_with_segments([
            {
                "sequence": 1,
                "filename": fname1,
                "state": "active",
                "entry_count": 3,
                "size_bytes": meta1["size_bytes"],
                "checksum_sha256": meta1["checksum_sha256"],
                "flushed_at": datetime.now(timezone.utc).isoformat(),
            },
            {
                "sequence": 1,  # DUPLICATE
                "filename": fname2,
                "state": "active",
                "entry_count": 3,
                "size_bytes": meta2["size_bytes"],
                "checksum_sha256": meta2["checksum_sha256"],
                "flushed_at": datetime.now(timezone.utc).isoformat(),
            },
        ])

        errors = m.validate()
        dup_errors = [e for e in errors if "Duplicate segment sequence" in e]
        self.assertTrue(len(dup_errors) >= 1, f"Expected duplicate sequence error, got: {errors}")

    def test_manifest_semantic_validation_rejects_missing_segment_file(self):
        """Manifest referencing a non-existent segment file must fail validation."""
        m = self._make_manifest_with_segments([
            {
                "sequence": 1,
                "filename": "seg_0001_20260330T120000Z_100.jsonl",  # does NOT exist
                "state": "active",
                "entry_count": 100,
                "size_bytes": 5000,
                "checksum_sha256": "abc123",
                "flushed_at": datetime.now(timezone.utc).isoformat(),
            },
        ])

        errors = m.validate()
        missing_errors = [e for e in errors if "missing" in e.lower()]
        self.assertTrue(len(missing_errors) >= 1, f"Expected missing file error, got: {errors}")

    def test_manifest_rejects_negative_generation(self):
        """Manifest with a negative generation counter must fail validation."""
        now = datetime.now(timezone.utc).isoformat()
        data = {
            "version": "3.2.0",
            "generation": -5,
            "created_at": now,
            "updated_at": now,
            "segments": [],
            "hot": {
                "filename": "hot.jsonl",
                "put_count": 0,
                "delete_count": 0,
                "last_write_at": None,
            },
            "tombstones": {},
        }
        self._write_manifest(data)
        m = Manifest(self.seg_dir)

        errors = m.validate()
        gen_errors = [e for e in errors if "generation" in e.lower()]
        self.assertTrue(len(gen_errors) >= 1, f"Expected negative generation error, got: {errors}")

    def test_manifest_rejects_duplicate_segment_ids(self):
        """Manifest with two segments sharing the same filename must fail validation."""
        entries = [_make_entry(f"entry_{i}_padding_content_here") for i in range(3)]
        fname = "seg_0001_20260330T120000Z_3.jsonl"
        meta = SegmentWriter.write_segment(os.path.join(self.seg_dir, fname), entries)

        m = self._make_manifest_with_segments([
            {
                "sequence": 1,
                "filename": fname,
                "state": "active",
                "entry_count": 3,
                "size_bytes": meta["size_bytes"],
                "checksum_sha256": meta["checksum_sha256"],
                "flushed_at": datetime.now(timezone.utc).isoformat(),
            },
            {
                "sequence": 2,
                "filename": fname,  # DUPLICATE filename
                "state": "active",
                "entry_count": 3,
                "size_bytes": meta["size_bytes"],
                "checksum_sha256": meta["checksum_sha256"],
                "flushed_at": datetime.now(timezone.utc).isoformat(),
            },
        ])

        errors = m.validate()
        dup_errors = [e for e in errors if "Duplicate segment filename" in e]
        self.assertTrue(len(dup_errors) >= 1, f"Expected duplicate filename error, got: {errors}")

    def test_manifest_rejects_negative_sequence(self):
        """Manifest with a negative segment sequence must fail validation."""
        entries = [_make_entry(f"entry_{i}_padding_content_here") for i in range(3)]
        fname = "seg_neg_20260330T120000Z_3.jsonl"
        meta = SegmentWriter.write_segment(os.path.join(self.seg_dir, fname), entries)

        m = self._make_manifest_with_segments([
            {
                "sequence": -1,  # NEGATIVE
                "filename": fname,
                "state": "active",
                "entry_count": 3,
                "size_bytes": meta["size_bytes"],
                "checksum_sha256": meta["checksum_sha256"],
                "flushed_at": datetime.now(timezone.utc).isoformat(),
            },
        ])

        errors = m.validate()
        neg_errors = [e for e in errors if "non-negative" in e.lower() or "Invalid segment sequence" in e]
        self.assertTrue(len(neg_errors) >= 1, f"Expected negative sequence error, got: {errors}")

    def test_manifest_rejects_future_timestamp(self):
        """Manifest with a flushed_at far in the future must fail validation."""
        entries = [_make_entry(f"entry_{i}_padding_content_here") for i in range(3)]
        fname = "seg_0001_20260330T120000Z_3.jsonl"
        meta = SegmentWriter.write_segment(os.path.join(self.seg_dir, fname), entries)

        future_ts = (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat()

        m = self._make_manifest_with_segments([
            {
                "sequence": 1,
                "filename": fname,
                "state": "active",
                "entry_count": 3,
                "size_bytes": meta["size_bytes"],
                "checksum_sha256": meta["checksum_sha256"],
                "flushed_at": future_ts,  # 1 hour in the future
            },
        ])

        errors = m.validate()
        future_errors = [e for e in errors if "future" in e.lower()]
        self.assertTrue(len(future_errors) >= 1, f"Expected future timestamp error, got: {errors}")


# ===================================================================
# SegmentStore invariant assertions
# ===================================================================

class TestSegmentStoreInvariants(InvariantTestBase):
    """Test _assert_manifest_is_truth and _assert_no_legacy_writes."""

    def test_assert_manifest_is_truth_passes_on_clean_store(self):
        """A clean store with matching manifest and disk should pass."""
        entries = _make_entries(10)
        for e in entries:
            self.store.append_put(e)
        self.store.flush()

        # Should not raise
        self.store._assert_manifest_is_truth()

    def test_assert_manifest_is_truth_fails_on_missing_segment(self):
        """If a segment file is deleted but manifest still references it, assertion fails."""
        entries = _make_entries(10)
        for e in entries:
            self.store.append_put(e)
        self.store.flush()

        # Delete the segment file
        seg_dir = self.store.seg_dir
        seg_files = [f for f in os.listdir(seg_dir) if f.startswith("seg_")]
        self.assertTrue(len(seg_files) > 0)

        # Also delete the backup manifest so load() can't fall back to it
        bak_path = os.path.join(seg_dir, "manifest.json.bak")
        if os.path.exists(bak_path):
            os.unlink(bak_path)

        os.unlink(os.path.join(seg_dir, seg_files[0]))

        with self.assertRaises(AssertionError) as ctx:
            self.store._assert_manifest_is_truth()
        self.assertIn("missing", str(ctx.exception).lower())

    def test_assert_manifest_is_truth_fails_on_orphan_segment(self):
        """If a segment file exists on disk but is not in the manifest, assertion fails."""
        entries = _make_entries(10)
        for e in entries:
            self.store.append_put(e)
        self.store.flush()

        # Create an orphan segment file
        orphan_path = os.path.join(self.store.seg_dir, "seg_9999_20260330T120000Z_1.jsonl")
        with open(orphan_path, "w") as f:
            f.write('{"test": true}\n')

        with self.assertRaises(AssertionError) as ctx:
            self.store._assert_manifest_is_truth()
        self.assertIn("orphan", str(ctx.exception).lower())

    def test_assert_no_legacy_writes_passes_on_clean_workspace(self):
        """A clean segmented workspace should pass the legacy writes check."""
        # Should not raise
        self.store._assert_no_legacy_writes()

    def test_assert_no_legacy_writes_fails_on_wal_with_content(self):
        """If pending.jsonl has content, the assertion should fail."""
        pending_path = os.path.join(self.tmp, "pending.jsonl")
        with open(pending_path, "w") as f:
            f.write('{"op": "put", "hash": "abc123", "entry": {}}\n')

        with self.assertRaises(AssertionError) as ctx:
            self.store._assert_no_legacy_writes()
        self.assertIn("pending.jsonl", str(ctx.exception))

    def test_assert_no_legacy_writes_passes_on_empty_pending_jsonl(self):
        """An empty pending.jsonl (from WALManager init) should pass."""
        pending_path = os.path.join(self.tmp, "pending.jsonl")
        with open(pending_path, "w") as f:
            f.write("")  # empty file

        # Should not raise
        self.store._assert_no_legacy_writes()

    def test_assert_no_legacy_writes_fails_on_weekly_shards(self):
        """If weekly shard files exist, the assertion should fail."""
        shard_path = os.path.join(self.tmp, "memories_2026-W13.jsonl")
        with open(shard_path, "w") as f:
            f.write("{}\n")

        with self.assertRaises(AssertionError) as ctx:
            self.store._assert_no_legacy_writes()
        self.assertIn("shard", str(ctx.exception).lower())


# ===================================================================
# Core save/flush/forget route through SegmentStore
# ===================================================================

class TestCoreSaveFlushForgetRouteToSegmentStore(unittest.TestCase):
    """Verify that save(), flush(), and forget() delegate to SegmentStore
    when segmented storage is active."""

    def setUp(self) -> None:
        self.tmp = tempfile.mkdtemp()

    def tearDown(self) -> None:
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_core_save_flush_forget_route_to_segment_store(self):
        """When _segment_store is set, save/flush/forget must call SegmentStore methods."""
        from parsica_memory.core_v4 import MemorySystemV4

        mem = MemorySystemV4(
            workspace=self.tmp,
            storage_backend="segments",
            use_sharding=False,
            sharding=False,
            graph_intelligence=False,
            quality_routing=False,
            semantic_expansion=False,
        )

        # Verify segment store is active
        self.assertTrue(mem._using_segments)
        self.assertIsNotNone(mem._segment_store)

        # Ingest some content
        count = mem.ingest(
            "This is a test memory for routing verification through segment store",
            source="test",
        )
        self.assertGreater(count, 0)

        # save() should call segment_store.flush()
        with mock.patch.object(mem._segment_store, "flush", wraps=mem._segment_store.flush) as mock_flush:
            mem.save()
            mock_flush.assert_called()

        # flush() should delegate to segment_store.flush()
        # Ingest more to have something to flush
        mem.ingest(
            "Another test memory for flush routing verification through segments",
            source="test",
        )
        with mock.patch.object(mem._segment_store, "flush", wraps=mem._segment_store.flush) as mock_flush:
            mem.flush()
            mock_flush.assert_called()

        # forget() should call segment_store.forget_hashes()
        mem.ingest(
            "Memory about elephants that we will forget to test routing path",
            source="test",
        )
        with mock.patch.object(
            mem._segment_store, "forget_hashes", wraps=mem._segment_store.forget_hashes
        ) as mock_forget:
            result = mem.forget(topic="elephants")
            if result["removed"]:
                mock_forget.assert_called()

        mem.close()


# ===================================================================
# Legacy paths disabled in segmented mode
# ===================================================================

class TestCoreLegacyPathsDisabledInSegmentedMode(unittest.TestCase):
    """Verify that legacy WAL/shard writes do NOT happen in segmented mode."""

    def setUp(self) -> None:
        self.tmp = tempfile.mkdtemp()

    def tearDown(self) -> None:
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_core_legacy_paths_disabled_in_segmented_mode(self):
        """In segmented mode, ingest should NOT write to the legacy WAL."""
        from parsica_memory.core_v4 import MemorySystemV4

        mem = MemorySystemV4(
            workspace=self.tmp,
            storage_backend="segments",
            use_sharding=False,
            sharding=False,
            graph_intelligence=False,
            quality_routing=False,
            semantic_expansion=False,
        )

        self.assertTrue(mem._using_segments)

        # Track WAL append calls — should NOT be called
        original_wal_append = mem._wal.append
        wal_calls = []

        def tracking_append(entry_dict):
            wal_calls.append(entry_dict)
            return original_wal_append(entry_dict)

        mem._wal.append = tracking_append

        # Ingest content
        mem.ingest(
            "This memory should go to segment store not to the legacy WAL path",
            source="test",
        )

        # WAL should NOT have been called
        self.assertEqual(
            len(wal_calls), 0,
            f"Legacy WAL received {len(wal_calls)} write(s) in segmented mode"
        )

        mem.close()


# ===================================================================
# No WAL writes in segmented mode (full lifecycle)
# ===================================================================

class TestNoWalWritesInSegmentedMode(unittest.TestCase):
    """Full lifecycle test: ingest + flush + forget, verify .wal/ untouched."""

    def setUp(self) -> None:
        self.tmp = tempfile.mkdtemp()

    def tearDown(self) -> None:
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_no_wal_writes_in_segmented_mode(self):
        """Ingest + flush + forget lifecycle should not create any .wal/ artefacts."""
        from parsica_memory.core_v4 import MemorySystemV4

        mem = MemorySystemV4(
            workspace=self.tmp,
            storage_backend="segments",
            use_sharding=False,
            sharding=False,
            graph_intelligence=False,
            quality_routing=False,
            semantic_expansion=False,
        )

        self.assertTrue(mem._using_segments)

        # Ingest
        mem.ingest(
            "Important fact about quantum computing that should be stored in segments",
            source="test",
        )
        mem.ingest(
            "Another important fact about machine learning stored in segment store",
            source="test",
        )

        # Flush
        mem.flush()

        # Forget
        mem.forget(topic="quantum")

        # Close
        mem.close()

        # The WALManager may create a .wal/ directory during init (it's
        # part of the MemorySystemV4 constructor regardless of backend).
        # What matters is that no WAL *entries* were written.
        # Check that no pending entries exist in the WAL.
        wal_pending = mem._wal.load_pending()
        self.assertEqual(
            len(wal_pending), 0,
            f"WAL has {len(wal_pending)} pending entries in segmented mode"
        )

        # Verify segments/ directory exists and has content
        seg_dir = os.path.join(self.tmp, "segments")
        self.assertTrue(os.path.isdir(seg_dir))
        manifest_path = os.path.join(seg_dir, "manifest.json")
        self.assertTrue(os.path.exists(manifest_path))

        # Verify the SegmentStore invariant
        mem._segment_store._assert_no_legacy_writes()


# ===================================================================
# B3 fix: compact() generation — no drift after repeated compactions
# ===================================================================

class TestCompactGenerationNoDriftAfterRepeatedCompactions(InvariantTestBase):
    """B3: After compaction, generation should equal max segment sequence, not max+1."""

    def test_compact_generation_no_drift_after_repeated_compactions(self):
        """Compact should set generation = max_new_seq, not max_new_seq + 1."""
        # Create enough entries to flush multiple small segments
        for i in range(5):
            entries = _make_entries(10, prefix=f"batch{i}")
            for e in entries:
                self.store.append_put(e)
            self.store.flush()

        # Verify we have multiple segments
        self.store._manifest.load()
        segments_before = self.store._manifest.segments
        self.assertGreaterEqual(len(segments_before), 4,
                                "Need at least 4 segments for compaction to trigger")

        # Run compaction
        result = self.store.compact()

        # After compaction, generation should equal the max segment sequence
        self.store._manifest.load()
        segments_after = self.store._manifest.segments
        if segments_after:
            max_seq = max(s["sequence"] for s in segments_after)
            gen = self.store._manifest.generation
            self.assertEqual(gen, max_seq,
                             f"Generation {gen} should equal max segment sequence {max_seq}, "
                             f"not {max_seq + 1} (off-by-one)")

    def test_generation_stable_across_multiple_compactions(self):
        """Multiple compaction cycles should not cause generation to inflate."""
        generations = []

        for cycle in range(3):
            # Add entries and flush to create segments
            for i in range(5):
                entries = _make_entries(10, prefix=f"cycle{cycle}_batch{i}")
                for e in entries:
                    self.store.append_put(e)
                self.store.flush()

            # Compact
            self.store.compact()
            self.store._manifest.load()
            gen = self.store._manifest.generation
            segments = self.store._manifest.segments
            if segments:
                max_seq = max(s["sequence"] for s in segments)
                # Generation should be exactly max_seq after compaction
                self.assertEqual(gen, max_seq,
                                 f"Cycle {cycle}: gen={gen} != max_seq={max_seq}")
            generations.append(gen)


# ===================================================================
# B4 fix: Debug dual-write sets cleared on flush
# ===================================================================

class TestDebugSetsClearedOnFlush(unittest.TestCase):
    """B4: _debug_segment_hashes and _debug_wal_hashes must be cleared on flush/load."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_debug_sets_cleared_on_flush(self):
        """After flush(), debug tracking sets should be empty."""
        from parsica_memory.core_v4 import MemorySystemV4

        mem = MemorySystemV4(
            self.tmp,
            storage_backend="segments",
            use_sharding=False,
            sharding=False,
            graph_intelligence=False,
            quality_routing=False,
            semantic_expansion=False,
        )

        # Ingest some entries — this populates _debug_segment_hashes
        mem.ingest(
            "This is a test memory entry that is long enough to pass the minimum length filter",
            source="test",
        )
        # Debug sets should have entries before flush
        has_entries = bool(mem._debug_segment_hashes) or bool(mem._debug_wal_hashes)
        self.assertTrue(has_entries, "Debug sets should have entries after ingest")

        # Flush
        mem.flush()

        # After flush, debug sets should be cleared
        self.assertEqual(len(mem._debug_segment_hashes), 0,
                         "segment hashes should be cleared after flush")
        self.assertEqual(len(mem._debug_wal_hashes), 0,
                         "wal hashes should be cleared after flush")

    def test_debug_sets_cleared_on_load(self):
        """After load(), debug tracking sets should be empty."""
        from parsica_memory.core_v4 import MemorySystemV4

        mem = MemorySystemV4(
            self.tmp,
            storage_backend="segments",
            use_sharding=False,
            sharding=False,
            graph_intelligence=False,
            quality_routing=False,
            semantic_expansion=False,
        )

        # Manually populate the debug sets
        mem._debug_segment_hashes.add("fake_hash_1")
        mem._debug_wal_hashes.add("fake_hash_2")

        # Load should clear them
        mem.load()

        self.assertEqual(len(mem._debug_segment_hashes), 0)
        self.assertEqual(len(mem._debug_wal_hashes), 0)


# ===================================================================
# Coverage tests: no WAL writes for segmented ingest paths
# ===================================================================

class TestNoWalWritesForSegmentedPaths(unittest.TestCase):
    """Verify that ingest_bulk, typed ingest, import_from, and re_enrich
    do NOT write to the WAL when in segmented mode."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        from parsica_memory.core_v4 import MemorySystemV4
        self.mem = MemorySystemV4(
            self.tmp,
            storage_backend="segments",
            use_sharding=False,
            sharding=False,
            graph_intelligence=False,
            quality_routing=False,
            semantic_expansion=False,
        )

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def _wal_has_entries(self) -> bool:
        """Check if the WAL pending file has any content."""
        pending = self.mem._wal.load_pending()
        return len(pending) > 0

    def test_no_wal_writes_for_ingest_bulk(self):
        """ingest_bulk() in segmented mode should not write to WAL."""
        items = [
            f"Bulk memory item number {i} with enough content to pass the minimum length filter"
            for i in range(5)
        ]
        count = self.mem.ingest_bulk(items, source="bulk_test")
        self.assertGreater(count, 0)
        self.assertFalse(self._wal_has_entries(),
                         "WAL should have no entries in segmented mode after ingest_bulk")

    def test_no_wal_writes_for_typed_ingest(self):
        """ingest_fact/ingest_preference/ingest_procedure should not write to WAL."""
        self.mem.ingest_fact(
            "The capital of France is Paris and this is a well-known geographical fact",
            source="fact_test",
        )
        self.mem.ingest_preference(
            "I prefer dark mode in all my applications and editors for reduced eye strain",
            source="pref_test",
        )
        self.mem.ingest_procedure(
            "To deploy the application first run the test suite then build the Docker image",
            source="proc_test",
        )
        self.assertFalse(self._wal_has_entries(),
                         "WAL should have no entries in segmented mode after typed ingest")

    def test_no_wal_writes_for_import_from(self):
        """import_from() in segmented mode should not write to WAL."""
        import json as _json
        # Create an export file
        export_path = os.path.join(self.tmp, "export.json")
        export_data = {
            "version": "4.2",
            "entries": [
                {
                    "content": "Imported memory entry with enough content to pass the minimum length filter",
                    "source": "import_test",
                    "category": "general",
                    "memory_type": "episodic",
                    "timestamp": "2026-03-30T00:00:00+00:00",
                    "score": 1.0,
                    "_hash": "import_hash_001",
                },
            ],
        }
        with open(export_path, "w") as fh:
            _json.dump(export_data, fh)

        count = self.mem.import_from(export_path, merge=True)
        self.assertGreater(count, 0)
        self.assertFalse(self._wal_has_entries(),
                         "WAL should have no entries in segmented mode after import_from")

    def test_no_wal_writes_for_re_enrich(self):
        """re_enrich() in segmented mode should not write to WAL."""
        # Ingest a memory first
        self.mem.ingest(
            "This is a memory that will be re-enriched with additional metadata and tags",
            source="enrich_test",
        )
        # Set up a mock enricher
        def mock_enricher(text):
            return {
                "tags": ["test_tag"],
                "summary": "A test summary",
                "keywords": ["test", "keyword"],
            }
        self.mem._enricher = mock_enricher

        count = self.mem.re_enrich(overwrite=True)
        self.assertGreater(count, 0)
        self.assertFalse(self._wal_has_entries(),
                         "WAL should have no entries in segmented mode after re_enrich")


# ===================================================================
# Run
# ===================================================================

if __name__ == "__main__":
    unittest.main()


# ===================================================================
# Opus gap tests
# ===================================================================

class TestManifestConflictErrorInvariant(unittest.TestCase):
    """Opus gap 1: ManifestConflictError triggers on stale generation."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_manifest_conflict_detected_on_stale_write(self):
        from parsica_memory.storage.manifest import Manifest, ManifestConflictError
        m1 = Manifest(os.path.join(self.tmp, "segments"))
        m2 = Manifest(os.path.join(self.tmp, "segments"))
        # m1 writes, bumping generation
        m1.add_segment({"sequence": 1, "filename": "seg_0001_test.jsonl",
                        "state": "active", "entry_count": 10, "size_bytes": 100,
                        "checksum_sha256": "abc123", "min_created": "", "max_created": "",
                        "flushed_at": ""})
        # m2 still has old generation — should conflict
        with self.assertRaises(ManifestConflictError):
            m2.add_segment({"sequence": 2, "filename": "seg_0002_test.jsonl",
                            "state": "active", "entry_count": 5, "size_bytes": 50,
                            "checksum_sha256": "def456", "min_created": "", "max_created": "",
                            "flushed_at": ""})


class TestHotOverflowCircuitBreaker(unittest.TestCase):
    """Opus gap 2: Hot overflow detection and stats reporting."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_hot_overflow_detected_in_stats(self):
        from parsica_memory.storage.segment_store import SegmentStore
        from parsica_memory.entry import MemoryEntry
        # Use a tiny emergency threshold
        store = SegmentStore(self.tmp, hot_max_emergency_bytes=500)
        # Ingest enough to exceed 500 bytes
        for i in range(20):
            e = MemoryEntry(f"Hot overflow test entry with enough content to be meaningful number {i}",
                            "test", i, "general")
            store.append_put(e)
        stats = store.stats()
        self.assertTrue(stats.get("hot_overflow", False),
                        "Hot overflow should be detected when emergency threshold exceeded")


class TestSegmentRecoveryIntegration(unittest.TestCase):
    """Opus gap 3: Both manifests corrupt, segments on disk → recovery."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_corrupt_both_manifests_recovers_from_segments(self):
        from parsica_memory.storage.segment_store import SegmentStore
        from parsica_memory.entry import MemoryEntry
        # Create store with data and flush
        store = SegmentStore(self.tmp)
        entries = []
        for i in range(5):
            e = MemoryEntry(f"Recovery integration test entry number {i} with sufficient content length",
                            "test", i, "general")
            store.append_put(e)
            entries.append(e)
        store.flush()
        store_hashes = {e.hash for e in entries}

        # Corrupt both manifests
        seg_dir = os.path.join(self.tmp, "segments")
        for name in ("manifest.json", "manifest.json.bak"):
            path = os.path.join(seg_dir, name)
            if os.path.exists(path):
                with open(path, "w") as f:
                    f.write("{corrupt!")

        # Create new store — should recover from segment scan
        store2 = SegmentStore(self.tmp)
        loaded = store2.load()
        loaded_hashes = {e.hash for e in loaded}
        self.assertEqual(store_hashes, loaded_hashes,
                         "All entries should be recovered from segment scan")
