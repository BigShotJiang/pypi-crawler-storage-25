from __future__ import annotations

import json
import os
import shutil
import tempfile
import unittest

from parsica_memory.entry import MemoryEntry
from parsica_memory.storage.manifest import Manifest
from parsica_memory.storage.repair import (
    RepairPlan,
    RepairResult,
    doctor,
    quarantine_orphans,
    reconcile_hot_state,
    repair_manifest,
    validate_store,
)
from parsica_memory.storage.segment_store import SegmentStore


def _make_entry(content: str, **kwargs) -> MemoryEntry:
    defaults = {
        "source": "unit_test",
        "category": "general",
        "memory_type": "episodic",
    }
    defaults.update(kwargs)
    return MemoryEntry(content=content, **defaults)


class RepairTestBase(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.mkdtemp()
        self.store = SegmentStore(self.tmp, hot_max_ops=100, hot_min_ops=1)
        self.seg_dir = os.path.join(self.tmp, "segments")
        self.manifest_path = os.path.join(self.seg_dir, "manifest.json")
        self.hot_path = os.path.join(self.seg_dir, "hot.jsonl")

    def tearDown(self) -> None:
        shutil.rmtree(self.tmp, ignore_errors=True)


class TestValidateStore(RepairTestBase):
    def test_validate_clean_store_ok(self):
        report = validate_store(self.tmp)
        self.assertTrue(report.ok)
        self.assertEqual(report.error_count(), 0)

    def test_validate_missing_manifest(self):
        os.unlink(self.manifest_path)
        report = validate_store(self.tmp)
        self.assertFalse(report.ok)
        self.assertTrue(any(issue.code == "missing_manifest" for issue in report.issues))

    def test_validate_checksum_mismatch(self):
        entry = _make_entry("hello")
        self.store.append_put(entry)
        self.store.flush()
        with open(self.manifest_path, "r", encoding="utf-8") as handle:
            manifest = json.load(handle)
        manifest["segments"][0]["checksum_sha256"] = "deadbeef"
        with open(self.manifest_path, "w", encoding="utf-8") as handle:
            json.dump(manifest, handle)
        report = validate_store(self.tmp)
        self.assertTrue(any(issue.code == "checksum_mismatch" for issue in report.issues))

    def test_validate_rotating_hot_present_warning(self):
        with open(os.path.join(self.seg_dir, "hot.rotating.jsonl"), "w", encoding="utf-8") as handle:
            handle.write('{"op":"delete","hash":"abc","ts":"2026-01-01T00:00:00+00:00"}\n')
        report = validate_store(self.tmp)
        self.assertTrue(any(issue.code == "rotating_hot_present" for issue in report.issues))

    def test_validate_hot_manifest_mismatch_warning(self):
        entry = _make_entry("one")
        self.store.append_put(entry)
        report = validate_store(self.tmp)
        self.assertTrue(any(issue.code == "hot_manifest_mismatch" for issue in report.issues))


class TestDoctor(RepairTestBase):
    def test_doctor_clean_store_has_no_actions(self):
        plan = doctor(self.tmp)
        self.assertIsInstance(plan, RepairPlan)
        self.assertTrue(plan.ok)
        self.assertEqual(plan.actions, [])

    def test_doctor_missing_manifest_recommends_rebuild(self):
        os.unlink(self.manifest_path)
        plan = doctor(self.tmp)
        kinds = [action.action_type for action in plan.actions]
        self.assertIn("rebuild_manifest", kinds)

    def test_doctor_orphan_recommends_quarantine(self):
        orphan = os.path.join(self.seg_dir, "seg_9999_fake_1.jsonl")
        with open(orphan, "w", encoding="utf-8") as handle:
            handle.write('{"x":1}\n')
        plan = doctor(self.tmp)
        kinds = [action.action_type for action in plan.actions]
        self.assertIn("quarantine_orphans", kinds)

    def test_doctor_rotating_hot_recommends_reconcile(self):
        with open(os.path.join(self.seg_dir, "hot.rotating.jsonl"), "w", encoding="utf-8") as handle:
            handle.write('{"op":"delete","hash":"abc","ts":"2026-01-01T00:00:00+00:00"}\n')
        plan = doctor(self.tmp)
        kinds = [action.action_type for action in plan.actions]
        self.assertIn("reconcile_hot_state", kinds)


class TestRepairManifest(RepairTestBase):
    def test_repair_manifest_dry_run_no_changes(self):
        entry = _make_entry("persist only in segment")
        self.store.append_put(entry)
        self.store.flush()
        os.unlink(self.manifest_path)
        result = repair_manifest(self.tmp, dry_run=True)
        self.assertIsInstance(result, RepairResult)
        self.assertFalse(result.changed)
        self.assertFalse(os.path.exists(self.manifest_path))
        self.assertIn("rebuilt_manifest", result.details)

    def test_repair_manifest_rebuilds_missing_manifest(self):
        entry = _make_entry("persist me")
        self.store.append_put(entry)
        self.store.flush()
        os.unlink(self.manifest_path)
        result = repair_manifest(self.tmp, dry_run=False)
        self.assertTrue(result.changed)
        self.assertTrue(os.path.exists(self.manifest_path))
        repaired_store = SegmentStore(self.tmp)
        loaded = repaired_store.load()
        self.assertEqual([e.content for e in loaded], ["persist me"])

    def test_repair_manifest_creates_backup_when_manifest_exists(self):
        entry = _make_entry("persist me too")
        self.store.append_put(entry)
        self.store.flush()
        with open(self.manifest_path, "w", encoding="utf-8") as handle:
            handle.write("{}")
        result = repair_manifest(self.tmp, dry_run=False)
        self.assertTrue(result.backups_created)
        self.assertTrue(any("manifest.json.bak." in path for path in result.backups_created))

    def test_repair_manifest_json_output(self):
        os.unlink(self.manifest_path)
        result = repair_manifest(self.tmp, dry_run=True)
        payload = json.loads(result.to_json())
        self.assertEqual(payload["workspace"], self.tmp)
        self.assertIn("details", payload)


class TestQuarantineOrphans(RepairTestBase):
    def test_quarantine_orphans_dry_run(self):
        orphan = os.path.join(self.seg_dir, "seg_9999_orphan_1.jsonl")
        with open(orphan, "w", encoding="utf-8") as handle:
            handle.write('{"x":1}\n')
        result = quarantine_orphans(self.tmp, dry_run=True)
        self.assertFalse(result.changed)
        self.assertTrue(os.path.exists(orphan))
        self.assertTrue(result.applied)

    def test_quarantine_orphans_moves_files(self):
        orphan = os.path.join(self.seg_dir, "seg_9999_orphan_1.jsonl")
        with open(orphan, "w", encoding="utf-8") as handle:
            handle.write('{"x":1}\n')
        result = quarantine_orphans(self.tmp, dry_run=False)
        self.assertTrue(result.changed)
        self.assertFalse(os.path.exists(orphan))
        quarantine_dir = result.details["quarantine_dir"]
        self.assertTrue(os.path.isdir(quarantine_dir))
        moved_targets = [a.details["to"] for a in result.applied]
        self.assertTrue(any(target.endswith("seg_9999_orphan_1.jsonl") for target in moved_targets))

    def test_quarantine_orphans_creates_backup_before_move(self):
        orphan = os.path.join(self.seg_dir, "seg_9999_orphan_1.jsonl")
        with open(orphan, "w", encoding="utf-8") as handle:
            handle.write('{"x":1}\n')
        result = quarantine_orphans(self.tmp, dry_run=False)
        self.assertTrue(result.backups_created)


class TestReconcileHotState(RepairTestBase):
    def test_reconcile_hot_state_dry_run(self):
        entry = _make_entry("hot entry")
        self.store.append_put(entry)
        rotating_path = os.path.join(self.seg_dir, "hot.rotating.jsonl")
        with open(rotating_path, "w", encoding="utf-8") as handle:
            handle.write('{"op":"delete","hash":"abc","ts":"2026-01-01T00:00:00+00:00"}\n')
        with open(rotating_path, "r", encoding="utf-8") as handle:
            before = handle.read()
        result = reconcile_hot_state(self.tmp, dry_run=True)
        self.assertFalse(result.changed)
        with open(rotating_path, "r", encoding="utf-8") as handle:
            after = handle.read()
        self.assertEqual(before, after)

    def test_reconcile_hot_state_merges_rotating_into_hot(self):
        entry = _make_entry("hot entry")
        self.store.append_put(entry)
        rotating = os.path.join(self.seg_dir, "hot.rotating.jsonl")
        with open(rotating, "w", encoding="utf-8") as handle:
            handle.write(json.dumps({"op": "delete", "hash": "deadbeef", "reason": "x", "ts": "2026-01-01T00:00:00+00:00"}) + "\n")
        result = reconcile_hot_state(self.tmp, dry_run=False)
        self.assertTrue(result.changed)
        self.assertFalse(os.path.exists(rotating))
        with open(self.hot_path, "r", encoding="utf-8") as handle:
            lines = [json.loads(line) for line in handle if line.strip()]
        self.assertEqual(len(lines), 2)
        self.assertEqual(lines[0]["op"], "delete")
        self.assertEqual(lines[1]["op"], "put")

    def test_reconcile_hot_state_updates_manifest_counters(self):
        entry = _make_entry("count me")
        self.store.append_put(entry)
        with open(os.path.join(self.seg_dir, "hot.rotating.jsonl"), "w", encoding="utf-8") as handle:
            handle.write(json.dumps({"op": "delete", "hash": "abc", "reason": "x", "ts": "2026-01-01T00:00:00+00:00"}) + "\n")
        reconcile_hot_state(self.tmp, dry_run=False)
        with open(self.manifest_path, "r", encoding="utf-8") as handle:
            manifest = json.load(handle)
        self.assertEqual(manifest["hot"]["put_count"], 1)
        self.assertEqual(manifest["hot"]["delete_count"], 1)

    def test_reconcile_hot_state_creates_backups(self):
        entry = _make_entry("backup me")
        self.store.append_put(entry)
        with open(os.path.join(self.seg_dir, "hot.rotating.jsonl"), "w", encoding="utf-8") as handle:
            handle.write(json.dumps({"op": "delete", "hash": "abc", "reason": "x", "ts": "2026-01-01T00:00:00+00:00"}) + "\n")
        result = reconcile_hot_state(self.tmp, dry_run=False)
        self.assertTrue(result.backups_created)


class TestDataclassJsonHelpers(RepairTestBase):
    def test_plan_to_json(self):
        plan = doctor(self.tmp)
        payload = json.loads(plan.to_json())
        self.assertIn("workspace", payload)
        self.assertIn("validation", payload)

    def test_validation_report_to_json(self):
        report = validate_store(self.tmp)
        payload = json.loads(report.to_json())
        self.assertIn("ok", payload)
        self.assertIn("issues", payload)


if __name__ == "__main__":
    unittest.main()
