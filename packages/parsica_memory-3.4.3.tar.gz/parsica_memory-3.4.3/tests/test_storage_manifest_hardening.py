"""Tests for PR 3 — Manifest Semantic Validator Hardening (Parsica Memory v3.2).

Covers:
  - validate() semantic checks (all new checks added in PR 3)
  - rebuild_from_disk() correctness and robustness
  - detect_storage_format() edge cases
  - load() backup-preference when primary fails validation
"""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import tempfile
import unittest


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_valid_manifest(segments_dir: str, *, generation: int = 5) -> dict:
    """Return a minimal, valid manifest dict referencing no segment files."""
    return {
        "version": "3.2.0",
        "generation": generation,
        "created_at": "2026-03-30T00:00:00+00:00",
        "updated_at": "2026-03-30T00:00:00+00:00",
        "segments": [],
        "hot": {
            "filename": "hot.jsonl",
            "put_count": 0,
            "delete_count": 0,
            "last_write_at": None,
        },
        "tombstones": {},
        "search": {"index_generation": 0},
        "migration": None,
    }


def _write_json(path: str, data: dict) -> None:
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(data, fh)


def _make_segment_file(seg_dir: str, filename: str, entry_count: int = 3) -> str:
    """Create a minimal valid seg_*.jsonl file; return its SHA-256 checksum."""
    path = os.path.join(seg_dir, filename)
    lines = []
    for i in range(entry_count):
        lines.append(json.dumps({
            "hash": f"hash{i:04d}",
            "content": f"entry {i}",
            "created": "2026-03-30T00:00:00+00:00",
        }))
    payload = "\n".join(lines) + "\n"
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(payload)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


# ---------------------------------------------------------------------------
# validate() — required keys
# ---------------------------------------------------------------------------

class TestValidateCatchesMissingRequiredKeys(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.seg_dir = os.path.join(self.tmpdir, "segments")
        os.makedirs(self.seg_dir, exist_ok=True)

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def _load_with_data(self, data: dict):
        from parsica_memory.storage.manifest import Manifest
        mpath = os.path.join(self.seg_dir, "manifest.json")
        _write_json(mpath, data)
        m = Manifest(self.seg_dir)
        return m

    def test_missing_version(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        del m._data["version"]
        errors = m.validate()
        self.assertTrue(any("version" in e for e in errors), errors)

    def test_missing_generation(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        del m._data["generation"]
        errors = m.validate()
        self.assertTrue(any("generation" in e for e in errors), errors)

    def test_missing_segments(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        del m._data["segments"]
        errors = m.validate()
        self.assertTrue(any("segments" in e for e in errors), errors)

    def test_missing_hot(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        del m._data["hot"]
        errors = m.validate()
        self.assertTrue(any("hot" in e for e in errors), errors)

    def test_missing_tombstones(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        del m._data["tombstones"]
        errors = m.validate()
        self.assertTrue(any("tombstones" in e for e in errors), errors)

    def test_all_keys_present_no_errors(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        errors = m.validate()
        self.assertEqual(errors, [], errors)


# ---------------------------------------------------------------------------
# validate() — negative generation
# ---------------------------------------------------------------------------

class TestValidateCatchesNegativeGeneration(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.seg_dir = os.path.join(self.tmpdir, "segments")
        os.makedirs(self.seg_dir, exist_ok=True)

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_negative_generation(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        m._data["generation"] = -1
        errors = m.validate()
        self.assertTrue(any("generation" in e.lower() for e in errors), errors)

    def test_float_generation(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        m._data["generation"] = 1.5
        errors = m.validate()
        self.assertTrue(any("generation" in e.lower() for e in errors), errors)

    def test_string_generation(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        m._data["generation"] = "five"
        errors = m.validate()
        self.assertTrue(any("generation" in e.lower() for e in errors), errors)

    def test_zero_generation_valid(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        m._data["generation"] = 0
        errors = m.validate()
        # No generation error expected for zero
        gen_errors = [e for e in errors if "invalid generation" in e.lower()]
        self.assertEqual(gen_errors, [], errors)


# ---------------------------------------------------------------------------
# validate() — duplicate sequences
# ---------------------------------------------------------------------------

class TestValidateCatchesDuplicateSequences(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.seg_dir = os.path.join(self.tmpdir, "segments")
        os.makedirs(self.seg_dir, exist_ok=True)

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_duplicate_sequences_caught(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        checksum = _make_segment_file(self.seg_dir, "seg_0001_ts_3.jsonl", 3)
        m._data["segments"] = [
            {"sequence": 1, "filename": "seg_0001_ts_3.jsonl",
             "state": "active", "entry_count": 3, "checksum_sha256": checksum},
            {"sequence": 1, "filename": "seg_0001_ts_3.jsonl",
             "state": "active", "entry_count": 3, "checksum_sha256": checksum},
        ]
        m._data["generation"] = 5
        errors = m.validate()
        dup_errors = [e for e in errors if "duplicate" in e.lower() and "sequence" in e.lower()]
        self.assertTrue(len(dup_errors) >= 1, errors)

    def test_unique_sequences_no_error(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        cs1 = _make_segment_file(self.seg_dir, "seg_0001_ts_2.jsonl", 2)
        cs2 = _make_segment_file(self.seg_dir, "seg_0002_ts_2.jsonl", 2)
        m._data["segments"] = [
            {"sequence": 1, "filename": "seg_0001_ts_2.jsonl",
             "state": "active", "entry_count": 2, "checksum_sha256": cs1},
            {"sequence": 2, "filename": "seg_0002_ts_2.jsonl",
             "state": "active", "entry_count": 2, "checksum_sha256": cs2},
        ]
        m._data["generation"] = 5
        errors = m.validate()
        dup_errors = [e for e in errors if "duplicate" in e.lower()]
        self.assertEqual(dup_errors, [], errors)


# ---------------------------------------------------------------------------
# validate() — duplicate filenames
# ---------------------------------------------------------------------------

class TestValidateCatchesDuplicateFilenames(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.seg_dir = os.path.join(self.tmpdir, "segments")
        os.makedirs(self.seg_dir, exist_ok=True)

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_duplicate_filenames_caught(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        checksum = _make_segment_file(self.seg_dir, "seg_shared.jsonl", 2)
        m._data["segments"] = [
            {"sequence": 1, "filename": "seg_shared.jsonl",
             "state": "active", "entry_count": 2, "checksum_sha256": checksum},
            {"sequence": 2, "filename": "seg_shared.jsonl",  # same filename!
             "state": "active", "entry_count": 2, "checksum_sha256": checksum},
        ]
        m._data["generation"] = 5
        errors = m.validate()
        dup_fname_errors = [e for e in errors if "duplicate" in e.lower() and "filename" in e.lower()]
        self.assertTrue(len(dup_fname_errors) >= 1, errors)

    def test_unique_filenames_no_error(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        cs1 = _make_segment_file(self.seg_dir, "seg_a.jsonl", 2)
        cs2 = _make_segment_file(self.seg_dir, "seg_b.jsonl", 2)
        m._data["segments"] = [
            {"sequence": 1, "filename": "seg_a.jsonl",
             "state": "active", "entry_count": 2, "checksum_sha256": cs1},
            {"sequence": 2, "filename": "seg_b.jsonl",
             "state": "active", "entry_count": 2, "checksum_sha256": cs2},
        ]
        m._data["generation"] = 5
        errors = m.validate()
        fname_errors = [e for e in errors if "duplicate" in e.lower() and "filename" in e.lower()]
        self.assertEqual(fname_errors, [], errors)


# ---------------------------------------------------------------------------
# validate() — missing segment files
# ---------------------------------------------------------------------------

class TestValidateCatchesMissingSegmentFiles(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.seg_dir = os.path.join(self.tmpdir, "segments")
        os.makedirs(self.seg_dir, exist_ok=True)

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_missing_segment_file_caught(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        m._data["segments"] = [
            {"sequence": 1, "filename": "seg_ghost.jsonl",
             "state": "active", "entry_count": 5, "checksum_sha256": "abc123"}
        ]
        m._data["generation"] = 5
        errors = m.validate()
        missing_errors = [e for e in errors if "missing" in e.lower() and "ghost" in e]
        self.assertTrue(len(missing_errors) >= 1, errors)

    def test_present_segment_file_no_error(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        checksum = _make_segment_file(self.seg_dir, "seg_present.jsonl", 3)
        m._data["segments"] = [
            {"sequence": 1, "filename": "seg_present.jsonl",
             "state": "active", "entry_count": 3, "checksum_sha256": checksum}
        ]
        m._data["generation"] = 5
        errors = m.validate()
        missing_errors = [e for e in errors if "missing" in e.lower()]
        self.assertEqual(missing_errors, [], errors)


# ---------------------------------------------------------------------------
# validate() — empty tombstone hash
# ---------------------------------------------------------------------------

class TestValidateCatchesEmptyTombstoneHash(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.seg_dir = os.path.join(self.tmpdir, "segments")
        os.makedirs(self.seg_dir, exist_ok=True)

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_empty_string_tombstone_key_caught(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        m._data["tombstones"] = {
            "": {"deleted_at": "2026-01-01", "reason": "bad key"}
        }
        errors = m.validate()
        ts_errors = [e for e in errors if "tombstone" in e.lower()]
        self.assertTrue(len(ts_errors) >= 1, errors)

    def test_valid_tombstone_key_no_error(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        m._data["tombstones"] = {
            "abc123": {"deleted_at": "2026-01-01", "reason": "test"}
        }
        errors = m.validate()
        ts_errors = [e for e in errors if "tombstone" in e.lower()]
        self.assertEqual(ts_errors, [], errors)


# ---------------------------------------------------------------------------
# validate() — generation < max segment sequence
# ---------------------------------------------------------------------------

class TestValidateCatchesGenerationLessThanMaxSequence(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.seg_dir = os.path.join(self.tmpdir, "segments")
        os.makedirs(self.seg_dir, exist_ok=True)

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_generation_less_than_max_sequence_caught(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        cs = _make_segment_file(self.seg_dir, "seg_high.jsonl", 2)
        m._data["segments"] = [
            {"sequence": 99, "filename": "seg_high.jsonl",
             "state": "active", "entry_count": 2, "checksum_sha256": cs}
        ]
        m._data["generation"] = 5  # less than sequence 99
        errors = m.validate()
        monotonic_errors = [e for e in errors if "monoton" in e.lower() or "less than" in e.lower()]
        self.assertTrue(len(monotonic_errors) >= 1, errors)

    def test_generation_equal_to_max_sequence_valid(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        cs = _make_segment_file(self.seg_dir, "seg_eq.jsonl", 2)
        m._data["segments"] = [
            {"sequence": 5, "filename": "seg_eq.jsonl",
             "state": "active", "entry_count": 2, "checksum_sha256": cs}
        ]
        m._data["generation"] = 5  # equal is fine
        errors = m.validate()
        monotonic_errors = [e for e in errors if "monoton" in e.lower() or "less than" in e.lower()]
        self.assertEqual(monotonic_errors, [], errors)

    def test_generation_greater_than_max_sequence_valid(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        cs = _make_segment_file(self.seg_dir, "seg_lower.jsonl", 2)
        m._data["segments"] = [
            {"sequence": 3, "filename": "seg_lower.jsonl",
             "state": "active", "entry_count": 2, "checksum_sha256": cs}
        ]
        m._data["generation"] = 10  # higher due to tombstone mutations etc.
        errors = m.validate()
        monotonic_errors = [e for e in errors if "monoton" in e.lower() or "less than" in e.lower()]
        self.assertEqual(monotonic_errors, [], errors)


# ---------------------------------------------------------------------------
# rebuild_from_disk() — discovers all segments
# ---------------------------------------------------------------------------

class TestRebuildFromDiskDiscoversAllSegments(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.seg_dir = os.path.join(self.tmpdir, "segments")
        os.makedirs(self.seg_dir, exist_ok=True)

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_discovers_three_segments(self):
        from parsica_memory.storage.manifest import Manifest
        _make_segment_file(self.seg_dir, "seg_0001_20260330T120000Z_5.jsonl", 5)
        _make_segment_file(self.seg_dir, "seg_0002_20260330T130000Z_3.jsonl", 3)
        _make_segment_file(self.seg_dir, "seg_0003_20260330T140000Z_7.jsonl", 7)

        m = Manifest(self.seg_dir)
        rebuilt = m.rebuild_from_disk()

        self.assertEqual(len(rebuilt["segments"]), 3)
        seqs = sorted(s["sequence"] for s in rebuilt["segments"])
        self.assertEqual(seqs, [1, 2, 3])

    def test_empty_directory_returns_empty_segments(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        rebuilt = m.rebuild_from_disk()
        self.assertEqual(rebuilt["segments"], [])
        self.assertEqual(rebuilt["generation"], 0)

    def test_generation_gte_max_sequence(self):
        from parsica_memory.storage.manifest import Manifest
        _make_segment_file(self.seg_dir, "seg_0001_20260330T120000Z_5.jsonl", 5)
        _make_segment_file(self.seg_dir, "seg_0007_20260330T130000Z_3.jsonl", 3)

        m = Manifest(self.seg_dir)
        rebuilt = m.rebuild_from_disk()
        self.assertGreaterEqual(rebuilt["generation"], 7)

    def test_validate_passes_on_rebuilt_manifest(self):
        from parsica_memory.storage.manifest import Manifest
        _make_segment_file(self.seg_dir, "seg_0001_20260330T120000Z_4.jsonl", 4)
        _make_segment_file(self.seg_dir, "seg_0002_20260330T130000Z_2.jsonl", 2)

        m = Manifest(self.seg_dir)
        rebuilt = m.rebuild_from_disk()
        m._data = rebuilt
        errors = m.validate()
        self.assertEqual(errors, [], errors)


# ---------------------------------------------------------------------------
# rebuild_from_disk() — handles corrupt segment files gracefully
# ---------------------------------------------------------------------------

class TestRebuildFromDiskHandlesCorruptSegment(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.seg_dir = os.path.join(self.tmpdir, "segments")
        os.makedirs(self.seg_dir, exist_ok=True)

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_corrupt_lines_skipped_file_still_included(self):
        from parsica_memory.storage.manifest import Manifest
        # Write a file that is half valid JSON and half garbage
        seg_path = os.path.join(self.seg_dir, "seg_0001_20260330T120000Z_5.jsonl")
        with open(seg_path, "w") as fh:
            fh.write(json.dumps({"hash": "aaaa", "content": "ok"}) + "\n")
            fh.write("NOT JSON AT ALL\n")
            fh.write(json.dumps({"hash": "bbbb", "content": "ok2"}) + "\n")
            fh.write("{broken{\n")

        m = Manifest(self.seg_dir)
        rebuilt = m.rebuild_from_disk()
        # File should still be in the manifest (not silently dropped)
        self.assertEqual(len(rebuilt["segments"]), 1)
        seg = rebuilt["segments"][0]
        self.assertEqual(seg["filename"], "seg_0001_20260330T120000Z_5.jsonl")
        # 2 valid lines, 2 corrupt — raw count recorded
        self.assertEqual(seg["_recovered_raw_entry_count"], 2)

    def test_fully_corrupt_file_still_included(self):
        from parsica_memory.storage.manifest import Manifest
        seg_path = os.path.join(self.seg_dir, "seg_0001_20260330T120000Z_1.jsonl")
        with open(seg_path, "w") as fh:
            fh.write("all garbage no json\n")
            fh.write("more garbage\n")

        m = Manifest(self.seg_dir)
        rebuilt = m.rebuild_from_disk()
        # File included in manifest even if all lines are corrupt
        self.assertEqual(len(rebuilt["segments"]), 1)
        seg = rebuilt["segments"][0]
        self.assertEqual(seg["_recovered_raw_entry_count"], 0)

    def test_mixed_good_and_corrupt_files(self):
        from parsica_memory.storage.manifest import Manifest
        # Good file
        _make_segment_file(self.seg_dir, "seg_0001_20260330T120000Z_3.jsonl", 3)
        # Corrupt file
        with open(os.path.join(self.seg_dir, "seg_0002_20260330T130000Z_99.jsonl"), "w") as fh:
            fh.write("{bad json\n")

        m = Manifest(self.seg_dir)
        rebuilt = m.rebuild_from_disk()
        self.assertEqual(len(rebuilt["segments"]), 2)
        # Both present; good one has proper count
        good = next(s for s in rebuilt["segments"] if s["sequence"] == 1)
        self.assertEqual(good["_recovered_raw_entry_count"], 3)


# ---------------------------------------------------------------------------
# rebuild_from_disk() — computes correct checksums
# ---------------------------------------------------------------------------

class TestRebuildFromDiskComputesCorrectChecksums(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.seg_dir = os.path.join(self.tmpdir, "segments")
        os.makedirs(self.seg_dir, exist_ok=True)

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_checksum_matches_file_content(self):
        from parsica_memory.storage.manifest import Manifest
        # _make_segment_file returns the SHA-256 of the content it wrote
        expected_checksum = _make_segment_file(
            self.seg_dir, "seg_0001_20260330T120000Z_5.jsonl", 5
        )

        m = Manifest(self.seg_dir)
        rebuilt = m.rebuild_from_disk()
        self.assertEqual(len(rebuilt["segments"]), 1)
        self.assertEqual(rebuilt["segments"][0]["checksum_sha256"], expected_checksum)

    def test_checksum_non_empty_for_each_segment(self):
        from parsica_memory.storage.manifest import Manifest
        _make_segment_file(self.seg_dir, "seg_0001_20260330T120000Z_2.jsonl", 2)
        _make_segment_file(self.seg_dir, "seg_0002_20260330T130000Z_4.jsonl", 4)

        m = Manifest(self.seg_dir)
        rebuilt = m.rebuild_from_disk()
        for seg in rebuilt["segments"]:
            self.assertTrue(seg["checksum_sha256"], f"Empty checksum for {seg['filename']}")

    def test_different_files_have_different_checksums(self):
        from parsica_memory.storage.manifest import Manifest
        # Both files have different content
        cs1 = _make_segment_file(self.seg_dir, "seg_0001_20260330T120000Z_2.jsonl", 2)
        cs2 = _make_segment_file(self.seg_dir, "seg_0002_20260330T130000Z_5.jsonl", 5)

        m = Manifest(self.seg_dir)
        rebuilt = m.rebuild_from_disk()
        checksums = [s["checksum_sha256"] for s in rebuilt["segments"]]
        # Different content → different checksums
        self.assertNotEqual(cs1, cs2)
        self.assertNotEqual(checksums[0], checksums[1])


# ---------------------------------------------------------------------------
# detect_storage_format() — empty segments/ directory
# ---------------------------------------------------------------------------

class TestDetectFormatEmptySegmentsDir(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_empty_segments_dir_is_segments_format(self):
        from parsica_memory.storage.migration import detect_storage_format
        segments_dir = os.path.join(self.tmpdir, "segments")
        os.makedirs(segments_dir, exist_ok=True)
        # No manifest.json, no hot.jsonl, no seg files — just the directory
        fmt = detect_storage_format(self.tmpdir)
        self.assertEqual(fmt, "segments")

    def test_no_segments_dir_at_all_is_empty(self):
        from parsica_memory.storage.migration import detect_storage_format
        # Completely empty workspace
        fmt = detect_storage_format(self.tmpdir)
        self.assertEqual(fmt, "empty")

    def test_segments_dir_with_only_seg_files_is_segments(self):
        """segments/ dir exists with seg files but no manifest.json or hot.jsonl."""
        from parsica_memory.storage.migration import detect_storage_format
        segments_dir = os.path.join(self.tmpdir, "segments")
        os.makedirs(segments_dir, exist_ok=True)
        # Write a seg file but no manifest
        with open(os.path.join(segments_dir, "seg_0001_20260330T120000Z_5.jsonl"), "w") as fh:
            fh.write("{}\n")
        fmt = detect_storage_format(self.tmpdir)
        self.assertEqual(fmt, "segments")


# ---------------------------------------------------------------------------
# detect_storage_format() — manifest exists but empty JSON
# ---------------------------------------------------------------------------

class TestDetectFormatManifestOnlyNoSegments(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_manifest_only_empty_json_is_segments(self):
        """manifest.json exists but contains empty JSON {} → still 'segments'."""
        from parsica_memory.storage.migration import detect_storage_format
        segments_dir = os.path.join(self.tmpdir, "segments")
        os.makedirs(segments_dir, exist_ok=True)
        with open(os.path.join(segments_dir, "manifest.json"), "w") as fh:
            fh.write("{}")
        fmt = detect_storage_format(self.tmpdir)
        self.assertEqual(fmt, "segments")

    def test_manifest_only_no_seg_files_is_segments(self):
        """manifest.json present but no seg_*.jsonl → still 'segments'."""
        from parsica_memory.storage.migration import detect_storage_format
        segments_dir = os.path.join(self.tmpdir, "segments")
        os.makedirs(segments_dir, exist_ok=True)
        data = {
            "version": "3.2.0", "generation": 0,
            "segments": [], "hot": {}, "tombstones": {},
        }
        with open(os.path.join(segments_dir, "manifest.json"), "w") as fh:
            json.dump(data, fh)
        fmt = detect_storage_format(self.tmpdir)
        self.assertEqual(fmt, "segments")

    def test_hot_only_no_manifest_is_segments(self):
        """hot.jsonl exists but no manifest → 'segments'."""
        from parsica_memory.storage.migration import detect_storage_format
        segments_dir = os.path.join(self.tmpdir, "segments")
        os.makedirs(segments_dir, exist_ok=True)
        open(os.path.join(segments_dir, "hot.jsonl"), "w").close()
        fmt = detect_storage_format(self.tmpdir)
        self.assertEqual(fmt, "segments")

    def test_segments_takes_priority_over_enterprise_shards(self):
        """segments/ present alongside shards/ → 'segments' wins."""
        from parsica_memory.storage.migration import detect_storage_format
        segments_dir = os.path.join(self.tmpdir, "segments")
        shards_dir = os.path.join(self.tmpdir, "shards")
        os.makedirs(segments_dir, exist_ok=True)
        os.makedirs(shards_dir, exist_ok=True)
        # Write a shard file to make it look like enterprise_shards
        with open(os.path.join(shards_dir, "shard_001.json"), "w") as fh:
            json.dump({"memories": []}, fh)
        # Write a manifest to segments/
        with open(os.path.join(segments_dir, "manifest.json"), "w") as fh:
            fh.write("{}")
        fmt = detect_storage_format(self.tmpdir)
        self.assertEqual(fmt, "segments")


# ---------------------------------------------------------------------------
# load() — prefers backup when primary fails validation
# ---------------------------------------------------------------------------

class TestLoadPrefersBackupWhenPrimaryFailsValidation(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.seg_dir = os.path.join(self.tmpdir, "segments")
        os.makedirs(self.seg_dir, exist_ok=True)

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_backup_used_when_primary_references_missing_file(self):
        """Primary references a non-existent segment → load() should use backup."""
        from parsica_memory.storage.manifest import Manifest

        # Write a clean backup (generation=7, no broken references)
        backup_data = {
            "version": "3.2.0", "generation": 7,
            "created_at": "2026-03-30T00:00:00+00:00",
            "updated_at": "2026-03-30T00:00:00+00:00",
            "segments": [],
            "hot": {"filename": "hot.jsonl", "put_count": 0,
                    "delete_count": 0, "last_write_at": None},
            "tombstones": {},
            "search": {"index_generation": 7},
            "migration": None,
        }
        bak_path = os.path.join(self.seg_dir, "manifest.json.bak")
        _write_json(bak_path, backup_data)

        # Write a primary that references a seg file that does NOT exist
        primary_data = {
            "version": "3.2.0", "generation": 8,
            "created_at": "2026-03-30T00:00:00+00:00",
            "updated_at": "2026-03-30T00:00:00+00:00",
            "segments": [
                {
                    "sequence": 1,
                    "filename": "seg_ghost_does_not_exist.jsonl",
                    "state": "active",
                    "entry_count": 5,
                    "checksum_sha256": "deadbeef" * 8,
                }
            ],
            "hot": {"filename": "hot.jsonl", "put_count": 0,
                    "delete_count": 0, "last_write_at": None},
            "tombstones": {},
            "search": {"index_generation": 8},
            "migration": None,
        }
        mpath = os.path.join(self.seg_dir, "manifest.json")
        _write_json(mpath, primary_data)

        m = Manifest(self.seg_dir)
        # Backup (generation=7, no broken refs) should be preferred
        self.assertEqual(m.generation, 7)
        self.assertEqual(m.segments, [])

    def test_primary_valid_backup_not_used(self):
        """When primary is valid, backup is ignored."""
        from parsica_memory.storage.manifest import Manifest

        # Write a valid primary
        cs = _make_segment_file(self.seg_dir, "seg_0001_20260330T120000Z_2.jsonl", 2)
        primary_data = {
            "version": "3.2.0", "generation": 10,
            "created_at": "2026-03-30T00:00:00+00:00",
            "updated_at": "2026-03-30T00:00:00+00:00",
            "segments": [
                {"sequence": 1, "filename": "seg_0001_20260330T120000Z_2.jsonl",
                 "state": "active", "entry_count": 2, "checksum_sha256": cs}
            ],
            "hot": {"filename": "hot.jsonl", "put_count": 0,
                    "delete_count": 0, "last_write_at": None},
            "tombstones": {},
            "search": {"index_generation": 10},
            "migration": None,
        }
        mpath = os.path.join(self.seg_dir, "manifest.json")
        _write_json(mpath, primary_data)

        # Write a stale backup with lower generation
        backup_data = {
            "version": "3.2.0", "generation": 3,
            "created_at": "2026-03-30T00:00:00+00:00",
            "updated_at": "2026-03-30T00:00:00+00:00",
            "segments": [],
            "hot": {"filename": "hot.jsonl", "put_count": 0,
                    "delete_count": 0, "last_write_at": None},
            "tombstones": {},
            "search": {"index_generation": 3},
            "migration": None,
        }
        bak_path = os.path.join(self.seg_dir, "manifest.json.bak")
        _write_json(bak_path, backup_data)

        m = Manifest(self.seg_dir)
        # Primary (generation=10) should be used, not backup (generation=3)
        self.assertEqual(m.generation, 10)
        self.assertEqual(len(m.segments), 1)

    def test_both_invalid_uses_higher_generation(self):
        """Both primary and backup have errors → higher generation wins (B6 fix)."""
        from parsica_memory.storage.manifest import Manifest

        # Primary: gen=10, references 2 ghost files → 2 missing-file errors
        primary_data = {
            "version": "3.2.0", "generation": 10,
            "created_at": "2026-03-30T00:00:00+00:00",
            "updated_at": "2026-03-30T00:00:00+00:00",
            "segments": [
                {"sequence": 1, "filename": "ghost1.jsonl",
                 "state": "active", "entry_count": 5, "checksum_sha256": "aa" * 32},
                {"sequence": 2, "filename": "ghost2.jsonl",
                 "state": "active", "entry_count": 3, "checksum_sha256": "bb" * 32},
            ],
            "hot": {"filename": "hot.jsonl", "put_count": 0,
                    "delete_count": 0, "last_write_at": None},
            "tombstones": {},
            "search": {"index_generation": 10},
            "migration": None,
        }
        mpath = os.path.join(self.seg_dir, "manifest.json")
        _write_json(mpath, primary_data)

        # Backup: gen=8, references only 1 ghost file → 1 error (fewer errors)
        backup_data = {
            "version": "3.2.0", "generation": 8,
            "created_at": "2026-03-30T00:00:00+00:00",
            "updated_at": "2026-03-30T00:00:00+00:00",
            "segments": [
                {"sequence": 1, "filename": "ghost1.jsonl",
                 "state": "active", "entry_count": 5, "checksum_sha256": "aa" * 32},
            ],
            "hot": {"filename": "hot.jsonl", "put_count": 0,
                    "delete_count": 0, "last_write_at": None},
            "tombstones": {},
            "search": {"index_generation": 8},
            "migration": None,
        }
        bak_path = os.path.join(self.seg_dir, "manifest.json.bak")
        _write_json(bak_path, backup_data)

        m = Manifest(self.seg_dir)
        # B6 fix: Primary (gen=10) should be preferred — higher generation
        # has more recent committed state, even though backup has fewer errors
        self.assertEqual(m.generation, 10)


# ---------------------------------------------------------------------------
# Additional validate() coverage — entry_count and checksum
# ---------------------------------------------------------------------------

class TestValidateSegmentFieldChecks(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.seg_dir = os.path.join(self.tmpdir, "segments")
        os.makedirs(self.seg_dir, exist_ok=True)

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_zero_entry_count_caught(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        cs = _make_segment_file(self.seg_dir, "seg_zero.jsonl", 0)
        m._data["segments"] = [
            {"sequence": 1, "filename": "seg_zero.jsonl",
             "state": "active", "entry_count": 0, "checksum_sha256": cs}
        ]
        m._data["generation"] = 5
        errors = m.validate()
        count_errors = [e for e in errors if "entry_count" in e.lower()]
        self.assertTrue(len(count_errors) >= 1, errors)

    def test_negative_entry_count_caught(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        cs = _make_segment_file(self.seg_dir, "seg_neg.jsonl", 1)
        m._data["segments"] = [
            {"sequence": 1, "filename": "seg_neg.jsonl",
             "state": "active", "entry_count": -1, "checksum_sha256": cs}
        ]
        m._data["generation"] = 5
        errors = m.validate()
        count_errors = [e for e in errors if "entry_count" in e.lower()]
        self.assertTrue(len(count_errors) >= 1, errors)

    def test_empty_checksum_caught(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        _make_segment_file(self.seg_dir, "seg_nocs.jsonl", 3)
        m._data["segments"] = [
            {"sequence": 1, "filename": "seg_nocs.jsonl",
             "state": "active", "entry_count": 3, "checksum_sha256": ""}
        ]
        m._data["generation"] = 5
        errors = m.validate()
        cs_errors = [e for e in errors if "checksum" in e.lower()]
        self.assertTrue(len(cs_errors) >= 1, errors)

    def test_missing_checksum_caught(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        _make_segment_file(self.seg_dir, "seg_nocs2.jsonl", 3)
        m._data["segments"] = [
            {"sequence": 1, "filename": "seg_nocs2.jsonl",
             "state": "active", "entry_count": 3}
            # no checksum_sha256 key at all
        ]
        m._data["generation"] = 5
        errors = m.validate()
        cs_errors = [e for e in errors if "checksum" in e.lower()]
        self.assertTrue(len(cs_errors) >= 1, errors)

    def test_invalid_state_caught(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        cs = _make_segment_file(self.seg_dir, "seg_badstate.jsonl", 2)
        m._data["segments"] = [
            {"sequence": 1, "filename": "seg_badstate.jsonl",
             "state": "compacted", "entry_count": 2, "checksum_sha256": cs}
        ]
        m._data["generation"] = 5
        errors = m.validate()
        state_errors = [e for e in errors if "state" in e.lower()]
        self.assertTrue(len(state_errors) >= 1, errors)

    def test_valid_segment_no_errors(self):
        from parsica_memory.storage.manifest import Manifest
        m = Manifest(self.seg_dir)
        cs = _make_segment_file(self.seg_dir, "seg_ok.jsonl", 3)
        m._data["segments"] = [
            {"sequence": 1, "filename": "seg_ok.jsonl",
             "state": "active", "entry_count": 3, "checksum_sha256": cs}
        ]
        m._data["generation"] = 5
        errors = m.validate()
        self.assertEqual(errors, [], errors)


# ---------------------------------------------------------------------------
# B1 fix: rebuild_from_disk() — no duplicate sequences with mixed filenames
# ---------------------------------------------------------------------------

class TestRebuildFromDiskNoDuplicateSequencesWithMixedFilenames(unittest.TestCase):
    """B1: Fallback sequences must not collide with parsed sequences."""

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.seg_dir = os.path.join(self.tmpdir, "segments")
        os.makedirs(self.seg_dir, exist_ok=True)

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_rebuild_from_disk_no_duplicate_sequences_with_mixed_filenames(self):
        """Standard filename with seq=1 + non-standard filename must not both get seq=1."""
        from parsica_memory.storage.manifest import Manifest

        # Standard filename → seq=1
        _make_segment_file(self.seg_dir, "seg_0001_20260330T120000Z_3.jsonl", 3)
        # Non-standard filename (matches seg_*.jsonl glob but not the regex)
        _make_segment_file(self.seg_dir, "seg_recovered_shard.jsonl", 2)

        m = Manifest(self.seg_dir)
        rebuilt = m.rebuild_from_disk()

        seqs = [s["sequence"] for s in rebuilt["segments"]]
        # No duplicate sequences
        self.assertEqual(len(seqs), len(set(seqs)),
                         f"Duplicate sequences found: {seqs}")
        # The non-standard file should get a sequence > 1 (above the parsed max)
        non_standard = [s for s in rebuilt["segments"]
                        if s["filename"] == "seg_recovered_shard.jsonl"]
        self.assertEqual(len(non_standard), 1)
        self.assertGreater(non_standard[0]["sequence"], 1)

    def test_multiple_non_standard_files_get_unique_sequences(self):
        """Multiple non-standard filenames all get unique sequences above parsed max."""
        from parsica_memory.storage.manifest import Manifest

        _make_segment_file(self.seg_dir, "seg_0003_20260330T120000Z_2.jsonl", 2)
        _make_segment_file(self.seg_dir, "seg_backup_a.jsonl", 1)
        _make_segment_file(self.seg_dir, "seg_backup_b.jsonl", 1)

        m = Manifest(self.seg_dir)
        rebuilt = m.rebuild_from_disk()

        seqs = [s["sequence"] for s in rebuilt["segments"]]
        self.assertEqual(len(seqs), len(set(seqs)),
                         f"Duplicate sequences found: {seqs}")
        # All fallback sequences should be > 3 (the parsed max)
        for s in rebuilt["segments"]:
            if s["filename"] != "seg_0003_20260330T120000Z_2.jsonl":
                self.assertGreater(s["sequence"], 3)

    def test_rebuilt_manifest_passes_validate(self):
        """Rebuilt manifest with mixed filenames must pass validate()."""
        from parsica_memory.storage.manifest import Manifest

        _make_segment_file(self.seg_dir, "seg_0001_20260330T120000Z_3.jsonl", 3)
        _make_segment_file(self.seg_dir, "seg_recovered.jsonl", 2)

        m = Manifest(self.seg_dir)
        rebuilt = m.rebuild_from_disk()
        m._data = rebuilt
        errors = m.validate()
        self.assertEqual(errors, [], f"validate() errors: {errors}")


# ---------------------------------------------------------------------------
# B2 fix: rebuild_from_disk() — corrupt segment entry_count is 0
# ---------------------------------------------------------------------------

class TestRebuildFromDiskCorruptSegmentEntryCountZero(unittest.TestCase):
    """B2: Fully-corrupt segments should have entry_count=0, not max(1, 0)=1."""

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.seg_dir = os.path.join(self.tmpdir, "segments")
        os.makedirs(self.seg_dir, exist_ok=True)

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_rebuild_from_disk_corrupt_segment_entry_count_zero(self):
        """Fully corrupt file should have entry_count=0 and _recovered_corrupt=True."""
        from parsica_memory.storage.manifest import Manifest

        seg_path = os.path.join(self.seg_dir, "seg_0001_20260330T120000Z_1.jsonl")
        with open(seg_path, "w") as fh:
            fh.write("all garbage no json\n")
            fh.write("more garbage\n")

        m = Manifest(self.seg_dir)
        rebuilt = m.rebuild_from_disk()
        self.assertEqual(len(rebuilt["segments"]), 1)
        seg = rebuilt["segments"][0]
        # B2 fix: entry_count should be 0, not 1
        self.assertEqual(seg["entry_count"], 0)
        self.assertEqual(seg["_recovered_raw_entry_count"], 0)
        self.assertTrue(seg["_recovered_corrupt"])

    def test_corrupt_segment_passes_validate(self):
        """Rebuilt manifest with corrupt segment (entry_count=0) must pass validate()."""
        from parsica_memory.storage.manifest import Manifest

        seg_path = os.path.join(self.seg_dir, "seg_0001_20260330T120000Z_1.jsonl")
        with open(seg_path, "w") as fh:
            fh.write("not json\n")

        m = Manifest(self.seg_dir)
        rebuilt = m.rebuild_from_disk()
        m._data = rebuilt
        errors = m.validate()
        # Should NOT have entry_count errors for recovered-corrupt segments
        entry_count_errors = [e for e in errors if "entry_count" in e.lower()]
        self.assertEqual(entry_count_errors, [],
                         f"Unexpected entry_count errors: {entry_count_errors}")

    def test_good_segment_still_has_positive_entry_count(self):
        """Non-corrupt segments should still have accurate positive entry_count."""
        from parsica_memory.storage.manifest import Manifest

        _make_segment_file(self.seg_dir, "seg_0001_20260330T120000Z_5.jsonl", 5)

        m = Manifest(self.seg_dir)
        rebuilt = m.rebuild_from_disk()
        seg = rebuilt["segments"][0]
        self.assertEqual(seg["entry_count"], 5)
        self.assertFalse(seg.get("_recovered_corrupt", False))


# ---------------------------------------------------------------------------
# B5 fix: detect_storage_format() — segments/ dir with unrelated files
# ---------------------------------------------------------------------------

class TestDetectFormatSegmentsDirWithUnrelatedFiles(unittest.TestCase):
    """B5: segments/ with only unrelated files should NOT be classified as 'segments'."""

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_detect_format_segments_dir_with_unrelated_files(self):
        """segments/ containing only non-Parsica files should not be 'segments'."""
        from parsica_memory.storage.migration import detect_storage_format

        segments_dir = os.path.join(self.tmpdir, "segments")
        os.makedirs(segments_dir, exist_ok=True)
        # Create unrelated files (e.g. audio segments)
        with open(os.path.join(segments_dir, "audio_001.wav"), "w") as fh:
            fh.write("fake audio data")
        with open(os.path.join(segments_dir, "notes.txt"), "w") as fh:
            fh.write("some notes")

        fmt = detect_storage_format(self.tmpdir)
        self.assertEqual(fmt, "empty",
                         f"Expected 'empty' for unrelated files, got '{fmt}'")

    def test_segments_dir_with_parsica_files_still_detected(self):
        """segments/ with Parsica files (seg_*.jsonl) should still be 'segments'."""
        from parsica_memory.storage.migration import detect_storage_format

        segments_dir = os.path.join(self.tmpdir, "segments")
        os.makedirs(segments_dir, exist_ok=True)
        with open(os.path.join(segments_dir, "seg_0001_test.jsonl"), "w") as fh:
            fh.write("{}\n")
        with open(os.path.join(segments_dir, "unrelated.txt"), "w") as fh:
            fh.write("other stuff")

        fmt = detect_storage_format(self.tmpdir)
        self.assertEqual(fmt, "segments")

    def test_segments_dir_with_manifest_bak_still_detected(self):
        """segments/ with manifest.json.bak should still be 'segments'."""
        from parsica_memory.storage.migration import detect_storage_format

        segments_dir = os.path.join(self.tmpdir, "segments")
        os.makedirs(segments_dir, exist_ok=True)
        with open(os.path.join(segments_dir, "manifest.json.bak"), "w") as fh:
            fh.write("{}")

        fmt = detect_storage_format(self.tmpdir)
        self.assertEqual(fmt, "segments")

    def test_empty_segments_dir_still_detected(self):
        """Empty segments/ directory should still be classified as 'segments'."""
        from parsica_memory.storage.migration import detect_storage_format

        segments_dir = os.path.join(self.tmpdir, "segments")
        os.makedirs(segments_dir, exist_ok=True)

        fmt = detect_storage_format(self.tmpdir)
        self.assertEqual(fmt, "segments")


# ---------------------------------------------------------------------------
# B6 fix: Manifest load prefers higher generation when both corrupt
# ---------------------------------------------------------------------------

class TestManifestLoadPrefersHigherGenerationWhenBothCorrupt(unittest.TestCase):
    """B6: When both manifests have errors, prefer higher generation, not fewer errors."""

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.seg_dir = os.path.join(self.tmpdir, "segments")
        os.makedirs(self.seg_dir, exist_ok=True)

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_manifest_load_prefers_higher_generation_when_both_corrupt(self):
        """Primary gen=100 with 2 errors should be preferred over backup gen=8 with 1 error."""
        from parsica_memory.storage.manifest import Manifest

        # Primary: gen=100, references 2 ghost files → 2 errors
        primary_data = {
            "version": "3.2.0", "generation": 100,
            "created_at": "2026-03-30T00:00:00+00:00",
            "updated_at": "2026-03-30T00:00:00+00:00",
            "segments": [
                {"sequence": 1, "filename": "ghost1.jsonl",
                 "state": "active", "entry_count": 5, "checksum_sha256": "aa" * 32},
                {"sequence": 2, "filename": "ghost2.jsonl",
                 "state": "active", "entry_count": 3, "checksum_sha256": "bb" * 32},
            ],
            "hot": {"filename": "hot.jsonl", "put_count": 0,
                    "delete_count": 0, "last_write_at": None},
            "tombstones": {},
            "search": {"index_generation": 100},
            "migration": None,
        }
        mpath = os.path.join(self.seg_dir, "manifest.json")
        _write_json(mpath, primary_data)

        # Backup: gen=8, references 1 ghost file → 1 error (fewer errors)
        backup_data = {
            "version": "3.2.0", "generation": 8,
            "created_at": "2026-03-30T00:00:00+00:00",
            "updated_at": "2026-03-30T00:00:00+00:00",
            "segments": [
                {"sequence": 1, "filename": "ghost1.jsonl",
                 "state": "active", "entry_count": 5, "checksum_sha256": "aa" * 32},
            ],
            "hot": {"filename": "hot.jsonl", "put_count": 0,
                    "delete_count": 0, "last_write_at": None},
            "tombstones": {},
            "search": {"index_generation": 8},
            "migration": None,
        }
        bak_path = os.path.join(self.seg_dir, "manifest.json.bak")
        _write_json(bak_path, backup_data)

        m = Manifest(self.seg_dir)
        # B6 fix: Primary (gen=100) should be preferred despite having more errors
        self.assertEqual(m.generation, 100)

    def test_same_generation_uses_fewer_errors_as_tiebreaker(self):
        """When both have same generation, fewer errors should win (tiebreaker)."""
        from parsica_memory.storage.manifest import Manifest

        # Primary: gen=10, 2 ghost files → 2 errors
        primary_data = {
            "version": "3.2.0", "generation": 10,
            "created_at": "2026-03-30T00:00:00+00:00",
            "updated_at": "2026-03-30T00:00:00+00:00",
            "segments": [
                {"sequence": 1, "filename": "ghost1.jsonl",
                 "state": "active", "entry_count": 5, "checksum_sha256": "aa" * 32},
                {"sequence": 2, "filename": "ghost2.jsonl",
                 "state": "active", "entry_count": 3, "checksum_sha256": "bb" * 32},
            ],
            "hot": {"filename": "hot.jsonl", "put_count": 0,
                    "delete_count": 0, "last_write_at": None},
            "tombstones": {},
            "search": {"index_generation": 10},
            "migration": None,
        }
        mpath = os.path.join(self.seg_dir, "manifest.json")
        _write_json(mpath, primary_data)

        # Backup: gen=10 (same), 1 ghost file → 1 error (fewer)
        backup_data = {
            "version": "3.2.0", "generation": 10,
            "created_at": "2026-03-30T00:00:00+00:00",
            "updated_at": "2026-03-30T00:00:00+00:00",
            "segments": [
                {"sequence": 1, "filename": "ghost1.jsonl",
                 "state": "active", "entry_count": 5, "checksum_sha256": "aa" * 32},
            ],
            "hot": {"filename": "hot.jsonl", "put_count": 0,
                    "delete_count": 0, "last_write_at": None},
            "tombstones": {},
            "search": {"index_generation": 10},
            "migration": None,
        }
        bak_path = os.path.join(self.seg_dir, "manifest.json.bak")
        _write_json(bak_path, backup_data)

        m = Manifest(self.seg_dir)
        # Same generation → fewer errors wins → backup (gen=10, 1 error)
        # The backup gets written to primary, so generation stays 10
        # but the segment list should have only 1 segment (backup's)
        self.assertEqual(len(m.segments), 1)


if __name__ == "__main__":
    unittest.main()
