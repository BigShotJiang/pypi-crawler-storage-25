"""
Regression tests for the search scoping leak found by Pro Review v3.4.0.

Bug: combine_semantic_and_recency() in search.py pulled recent entries from
the FULL corpus, bypassing agent_id and session_id filtering that was already
applied. This re-added out-of-scope memories with confidence=0.0.

These tests reproduce the EXACT bugs Pro found:
  1. Agent leak: agent_id="alice" search returns Bob's memory with confidence=0.0
  2. Session leak: session_id="s1" search returns s2 memory with confidence=0.0

Also tests:
  3. Belt-and-suspenders re-filter in core_v4.py search()
  4. begin_turn(None) validation
  5. Invalid session_awareness values warn instead of silently falling back
"""

import os
import tempfile
import unittest
import warnings
from datetime import datetime, timezone

from parsica_memory import MemorySystem
from parsica_memory.entry import MemoryEntry
from parsica_memory.search import SearchEngine


class TestAgentScopingLeak(unittest.TestCase):
    """Agent leak: agent_id='alice' search must never return bob's memory."""

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_agent_leak_via_recency_injection(self):
        """Reproduce Pro review bug #1: recency injection leaks agent-scoped entries.

        Before fix: combine_semantic_and_recency() used the FULL corpus,
        so recent Bob entries would appear in Alice's search with confidence=0.0.
        """
        mem = MemorySystem(self.tmpdir, half_life=7.0, agent_name="alice")

        # Ingest as alice
        mem.ingest(
            "alice remembers the quantum computing project details uniquealice",
            source="alice_test",
            agent_id="alice",
        )

        # Ingest as bob (into same store)
        now_iso = datetime.now(timezone.utc).isoformat()
        bob_entry = MemoryEntry(
            "bob remembers the mountain climbing trip details uniquebob",
            source="bob_test",
            line=0,
            category="general",
            agent_id="bob",
        )
        bob_entry.created = now_iso  # Make it very recent for recency injection
        mem.memories.append(bob_entry)
        mem._hashes.add(bob_entry.hash)
        mem.search_engine.mark_dirty()

        # Search as alice — bob's memory must NOT appear
        results = mem.search(
            "project details trip",
            agent_id="alice",
            session_id="*",
            explain=True,
        )

        for r in results:
            entry_agent = getattr(r.entry, "agent_id", None)
            self.assertNotEqual(
                entry_agent, "bob",
                f"AGENT LEAK: Bob's memory appeared in Alice's search! "
                f"Content: {r.entry.content[:80]}, confidence={r.relevance}",
            )

    def test_agent_leak_backward_compat_no_explain(self):
        """Same test but with explain=False (returns MemoryEntry directly)."""
        mem = MemorySystem(self.tmpdir, half_life=7.0, agent_name="alice")

        mem.ingest(
            "alice unique content for backward compat check agentleaktest",
            source="alice_test",
            agent_id="alice",
        )

        now_iso = datetime.now(timezone.utc).isoformat()
        bob_entry = MemoryEntry(
            "bob unique content for backward compat check agentleaktest",
            source="bob_test",
            line=0,
            category="general",
            agent_id="bob",
        )
        bob_entry.created = now_iso
        mem.memories.append(bob_entry)
        mem._hashes.add(bob_entry.hash)
        mem.search_engine.mark_dirty()

        results = mem.search(
            "agentleaktest backward compat",
            agent_id="alice",
            session_id="*",
        )

        for entry in results:
            entry_agent = getattr(entry, "agent_id", None)
            self.assertNotEqual(
                entry_agent, "bob",
                f"AGENT LEAK (no explain): Bob's memory appeared in Alice's search! "
                f"Content: {entry.content[:80]}",
            )


class TestSessionScopingLeak(unittest.TestCase):
    """Session leak: session_id='s1' search must never return s2's memory."""

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_session_leak_via_recency_injection(self):
        """Reproduce Pro review bug #2: recency injection leaks session-scoped entries.

        Before fix: combine_semantic_and_recency() used the FULL corpus,
        so recent s2 entries would appear in s1's search with confidence=0.0.
        """
        mem = MemorySystem(self.tmpdir, half_life=7.0, agent_name="test-agent")

        # Ingest into session s1
        mem.ingest(
            "session one discusses the deployment pipeline unique s1content",
            source="s1_test",
            session_id="s1",
        )

        # Ingest into session s2 (very recent)
        now_iso = datetime.now(timezone.utc).isoformat()
        s2_entry = MemoryEntry(
            "session two discusses the database migration unique s2content",
            source="s2_test",
            line=0,
            category="general",
            agent_id="test-agent",
            session_id="s2",
        )
        s2_entry.created = now_iso  # Make it very recent for recency injection
        mem.memories.append(s2_entry)
        mem._hashes.add(s2_entry.hash)
        mem.search_engine.mark_dirty()

        # Search within session s1 — s2's memory must NOT appear
        results = mem.search(
            "deployment database pipeline migration",
            session_id="s1",
            explain=True,
        )

        for r in results:
            entry_session = getattr(r.entry, "session_id", "") or ""
            if entry_session and entry_session != "s1":
                self.fail(
                    f"SESSION LEAK: s2 memory appeared in s1 search! "
                    f"Content: {r.entry.content[:80]}, confidence={r.relevance}"
                )

    def test_session_leak_backward_compat_no_explain(self):
        """Same test but with explain=False (returns MemoryEntry directly)."""
        mem = MemorySystem(self.tmpdir, half_life=7.0, agent_name="test-agent")

        mem.ingest(
            "session alpha discusses unique session alpha content sessionleaktest",
            source="s_alpha",
            session_id="s_alpha",
        )

        now_iso = datetime.now(timezone.utc).isoformat()
        s_beta_entry = MemoryEntry(
            "session beta discusses unique session beta content sessionleaktest",
            source="s_beta",
            line=0,
            category="general",
            agent_id="test-agent",
            session_id="s_beta",
        )
        s_beta_entry.created = now_iso
        mem.memories.append(s_beta_entry)
        mem._hashes.add(s_beta_entry.hash)
        mem.search_engine.mark_dirty()

        results = mem.search(
            "sessionleaktest content discusses",
            session_id="s_alpha",
        )

        for entry in results:
            entry_session = getattr(entry, "session_id", "") or ""
            if entry_session and entry_session != "s_alpha":
                self.fail(
                    f"SESSION LEAK (no explain): s_beta memory appeared in s_alpha search! "
                    f"Content: {entry.content[:80]}"
                )


class TestSearchEngineRecencyScoping(unittest.TestCase):
    """Direct SearchEngine-level test for combine_semantic_and_recency scoping."""

    def test_recency_injection_respects_agent_scope(self):
        """SearchEngine.search() must not inject recent entries from other agents."""
        engine = SearchEngine(recency_window_hours=24.0, recency_limit=10)

        now_iso = datetime.now(timezone.utc).isoformat()

        alice_entry = MemoryEntry(
            "alice important data for recency scoping test alicescope",
            source="test",
            line=0,
            category="general",
            agent_id="alice",
        )
        alice_entry.created = now_iso

        bob_entry = MemoryEntry(
            "bob important data for recency scoping test bobscope",
            source="test",
            line=0,
            category="general",
            agent_id="bob",
        )
        bob_entry.created = now_iso

        memories = [alice_entry, bob_entry]
        engine.build_index(memories)

        results = engine.search(
            "scoping test data",
            memories=memories,
            agent_id="alice",
        )

        for r in results:
            entry_agent = getattr(r.entry, "agent_id", None)
            self.assertNotEqual(
                entry_agent, "bob",
                f"SearchEngine agent leak: bob's entry in alice's results! "
                f"score={r.score}, relevance={r.relevance}",
            )

    def test_recency_injection_respects_session_scope(self):
        """SearchEngine.search() must not inject recent entries from other sessions."""
        engine = SearchEngine(recency_window_hours=24.0, recency_limit=10)

        now_iso = datetime.now(timezone.utc).isoformat()

        s1_entry = MemoryEntry(
            "session one critical data for recency session scoping",
            source="test",
            line=0,
            category="general",
            session_id="s1",
        )
        s1_entry.created = now_iso

        s2_entry = MemoryEntry(
            "session two critical data for recency session scoping",
            source="test",
            line=0,
            category="general",
            session_id="s2",
        )
        s2_entry.created = now_iso

        memories = [s1_entry, s2_entry]
        engine.build_index(memories)

        results = engine.search(
            "critical data session scoping",
            memories=memories,
            session_id="s1",
        )

        for r in results:
            entry_session = getattr(r.entry, "session_id", "") or ""
            if entry_session and entry_session != "s1":
                self.fail(
                    f"SearchEngine session leak: s2 entry in s1 results! "
                    f"score={r.score}, relevance={r.relevance}",
                )


class TestBeginTurnNoneRejection(unittest.TestCase):
    """begin_turn(None) must raise, not create a None key in _sessions."""

    def test_begin_turn_none_raises(self):
        from parsica_memory.session_tracker import SessionTracker

        tracker = SessionTracker(mode="closed")
        with self.assertRaises((TypeError, ValueError)):
            tracker.begin_turn(None)

    def test_begin_turn_empty_string_raises(self):
        from parsica_memory.session_tracker import SessionTracker

        tracker = SessionTracker(mode="closed")
        with self.assertRaises(ValueError):
            tracker.begin_turn("")

    def test_begin_turn_whitespace_raises(self):
        from parsica_memory.session_tracker import SessionTracker

        tracker = SessionTracker(mode="closed")
        with self.assertRaises(ValueError):
            tracker.begin_turn("   ")

    def test_begin_turn_valid_string_works(self):
        from parsica_memory.session_tracker import SessionTracker

        tracker = SessionTracker(mode="closed")
        tracker.begin_turn("valid-session-id")
        self.assertTrue(tracker.is_active("valid-session-id"))

    def test_no_none_key_in_sessions(self):
        """After rejected begin_turn(None), _sessions must not contain None key."""
        from parsica_memory.session_tracker import SessionTracker

        tracker = SessionTracker(mode="closed")
        try:
            tracker.begin_turn(None)
        except (TypeError, ValueError):
            pass
        self.assertNotIn(None, tracker._sessions)


class TestInvalidSessionAwarenessWarning(unittest.TestCase):
    """Invalid session_awareness values must WARN, not silently fall back to 'off'."""

    def test_invalid_value_warns(self):
        """Passing session_awareness='closd' (typo) must emit a UserWarning."""
        with tempfile.TemporaryDirectory() as d:
            with warnings.catch_warnings(record=True) as w:
                warnings.simplefilter("always")
                mem = MemorySystem(
                    d,
                    half_life=7.0,
                    agent_name="test",
                    session_awareness="closd",  # typo!
                )
                # Check that a warning about invalid session_awareness was emitted
                sa_warnings = [
                    x for x in w
                    if "Invalid session_awareness" in str(x.message)
                ]
                self.assertTrue(
                    len(sa_warnings) > 0,
                    f"Expected warning about invalid session_awareness='closd', "
                    f"got warnings: {[str(x.message) for x in w]}",
                )

    def test_invalid_value_falls_back_to_off(self):
        """After warning, the effective mode should be 'off'."""
        with tempfile.TemporaryDirectory() as d:
            with warnings.catch_warnings(record=True):
                warnings.simplefilter("always")
                mem = MemorySystem(
                    d,
                    half_life=7.0,
                    agent_name="test",
                    session_awareness="enabled",  # invalid
                )
            self.assertEqual(mem._session_awareness, "off")
            self.assertIsNone(mem._session_tracker)

    def test_valid_values_no_warning(self):
        """Valid session_awareness values should not emit the warning."""
        for value in ("off", "open", "closed"):
            with tempfile.TemporaryDirectory() as d:
                with warnings.catch_warnings(record=True) as w:
                    warnings.simplefilter("always")
                    mem = MemorySystem(
                        d,
                        half_life=7.0,
                        agent_name="test",
                        session_awareness=value,
                    )
                    sa_warnings = [
                        x for x in w
                        if "Invalid session_awareness" in str(x.message)
                    ]
                    self.assertEqual(
                        len(sa_warnings), 0,
                        f"session_awareness={value!r} should not warn, "
                        f"but got: {[str(x.message) for x in sa_warnings]}",
                    )


class TestBeltAndSuspendersReFilter(unittest.TestCase):
    """The final scope re-filter in core_v4.py search() catches any remaining leaks."""

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_refilter_catches_agent_leak(self):
        """Even if an internal layer leaks, the re-filter must catch it."""
        mem = MemorySystem(self.tmpdir, half_life=7.0, agent_name="alice")

        # Add memories for both agents
        mem.ingest("alice data for refilter check unique alicerefilter", source="test", agent_id="alice")
        
        bob_entry = MemoryEntry(
            "bob data for refilter check unique bobrefilter",
            source="test",
            line=0,
            category="general",
            agent_id="bob",
        )
        bob_entry.created = datetime.now(timezone.utc).isoformat()
        mem.memories.append(bob_entry)
        mem._hashes.add(bob_entry.hash)
        mem.search_engine.mark_dirty()

        # Both paths
        for explain in (True, False):
            results = mem.search(
                "refilter check data",
                agent_id="alice",
                session_id="*",
                explain=explain,
            )

            for r in results:
                entry = r.entry if explain else r
                entry_agent = getattr(entry, "agent_id", None)
                self.assertNotEqual(
                    entry_agent, "bob",
                    f"Re-filter failed (explain={explain}): bob's entry leaked! "
                    f"Content: {entry.content[:80]}",
                )


if __name__ == "__main__":
    unittest.main()
