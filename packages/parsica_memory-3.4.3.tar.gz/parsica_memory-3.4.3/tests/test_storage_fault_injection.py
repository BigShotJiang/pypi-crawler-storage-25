from __future__ import annotations

import os
import shutil
import tempfile
import unittest

from parsica_memory.entry import MemoryEntry
from parsica_memory.storage.segment_store import SegmentStore


def _make_entry(content: str = "test memory entry with sufficient length for validation", **kwargs) -> MemoryEntry:
    """Create a MemoryEntry with sensible defaults.

    N7 fix: Default content and all callers use >= 20 chars to avoid
    being silently dropped by minimum content length filters.
    """
    defaults = {
        "source": "fault_test",
        "category": "general",
        "memory_type": "episodic",
    }
    defaults.update(kwargs)
    return MemoryEntry(content=content, **defaults)


def _raise_crash() -> None:
    raise RuntimeError("simulated crash")


class FaultInjectionTestBase(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.mkdtemp()
        self.store = SegmentStore(
            self.tmp,
            hot_max_ops=100,
            hot_max_bytes=4_194_304,
            hot_max_age_seconds=300,
            hot_min_ops=5,
        )

    def tearDown(self) -> None:
        shutil.rmtree(self.tmp, ignore_errors=True)

    def _new_store(self) -> SegmentStore:
        return SegmentStore(
            self.tmp,
            hot_max_ops=100,
            hot_max_bytes=4_194_304,
            hot_max_age_seconds=300,
            hot_min_ops=5,
        )

    def _load_hashes(self) -> set[str]:
        return {entry.hash for entry in self._new_store().load()}


class TestStorageFaultInjection(FaultInjectionTestBase):
    def test_crash_after_hot_fsync_data_survives(self):
        entries = [_make_entry(f"Test memory entry for hot fsync crash scenario number {i}") for i in range(3)]
        for entry in entries:
            self.store.append_put(entry)

        self.store._fault_after_hot_fsync = _raise_crash
        with self.assertRaises(RuntimeError):
            self.store.flush()

        self.assertEqual(self._load_hashes(), {entry.hash for entry in entries})

    def test_crash_after_segment_write_before_manifest_data_survives(self):
        entries = [_make_entry(f"Test memory entry for segment write crash scenario number {i}") for i in range(4)]
        for entry in entries:
            self.store.append_put(entry)

        self.store._fault_after_segment_write = _raise_crash
        with self.assertRaises(RuntimeError):
            self.store.flush()

        self.assertEqual(self._load_hashes(), {entry.hash for entry in entries})

    def test_crash_after_manifest_replace_before_hot_clear_dedup_handles_overlap(self):
        baseline = [_make_entry(f"Test memory entry for overlap dedup scenario number {i}") for i in range(3)]
        for entry in baseline:
            self.store.append_put(entry)
        self.store.flush()

        duplicate = _make_entry("Test memory entry for overlap dedup scenario number 1")
        extra = _make_entry("Test memory entry for overlap extra scenario with sufficient length")
        self.store.append_put(duplicate)
        self.store.append_put(extra)

        self.store._fault_after_manifest_replace = _raise_crash
        with self.assertRaises(RuntimeError):
            self.store.flush()

        loaded = self._new_store().load()
        loaded_hashes = {entry.hash for entry in loaded}
        expected_hashes = {entry.hash for entry in baseline}
        expected_hashes.add(extra.hash)
        self.assertEqual(loaded_hashes, expected_hashes)
        self.assertEqual(sum(1 for entry in loaded if entry.hash == duplicate.hash), 1)

    def test_crash_during_compaction_before_manifest_old_segments_intact(self):
        expected = []
        for batch in range(4):
            batch_entries = [_make_entry(f"Test memory entry for compaction old segments batch {batch} item {i}") for i in range(2)]
            expected.extend(batch_entries)
            for entry in batch_entries:
                self.store.append_put(entry)
            self.store.flush()

        self.store._fault_before_manifest_replace = _raise_crash
        with self.assertRaises(RuntimeError):
            self.store.compact()

        self.assertEqual(self._load_hashes(), {entry.hash for entry in expected})

    def test_crash_during_compaction_after_output_before_manifest_orphan_harmless(self):
        expected = []
        for batch in range(4):
            batch_entries = [_make_entry(f"compact-orphan-{batch}-{i}") for i in range(2)]
            expected.extend(batch_entries)
            for entry in batch_entries:
                self.store.append_put(entry)
            self.store.flush()

        self.store._fault_after_segment_write = _raise_crash
        with self.assertRaises(RuntimeError):
            self.store.compact()

        self.assertEqual(self._load_hashes(), {entry.hash for entry in expected})

    def test_double_crash_recovery_no_data_loss(self):
        baseline = _make_entry("double-baseline")
        self.store.append_put(baseline)
        self.store.flush()

        second = _make_entry("double-second")
        self.store.append_put(second)
        self.store._fault_after_hot_fsync = _raise_crash
        with self.assertRaises(RuntimeError):
            self.store.flush()

        store2 = self._new_store()
        self.assertEqual({entry.hash for entry in store2.load()}, {baseline.hash, second.hash})

        store2._fault_after_hot_fsync = _raise_crash
        with self.assertRaises(RuntimeError):
            store2.flush()

        self.assertEqual(self._load_hashes(), {baseline.hash, second.hash})

    def test_rotating_plus_active_hot_ordering_survives_crash(self):
        target = _make_entry("ordering-target")
        self.store.append_put(target)
        self.store.flush()

        self.store.append_delete(target.hash, reason="delete before crash")
        self.store._fault_after_hot_fsync = _raise_crash
        with self.assertRaises(RuntimeError):
            self.store.flush()

        self.store.append_put(_make_entry("ordering-target"))

        loaded = self._new_store().load()
        matches = [entry for entry in loaded if entry.hash == target.hash]
        self.assertEqual(len(matches), 1)
        self.assertEqual(matches[0].content, "ordering-target")


if __name__ == "__main__":
    unittest.main()
