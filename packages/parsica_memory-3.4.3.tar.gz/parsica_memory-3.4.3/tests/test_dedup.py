from __future__ import annotations

import hashlib
import unittest
from datetime import datetime, timedelta, timezone

from parsica_memory.dedup import DedupEngine
from parsica_memory.entry import MemoryEntry


def _md5_12(text: str) -> str:
    return hashlib.md5(text.encode("utf-8")).hexdigest()[:12]


def _memory(content: str, *, hours_ago: int = 0, hash_value: str | None = None) -> MemoryEntry:
    created = (datetime.now(timezone.utc) - timedelta(hours=hours_ago)).isoformat()
    entry = MemoryEntry(content, created=created)
    if hash_value is not None:
        entry.hash = hash_value
    return entry


class TestDedupEngine(unittest.TestCase):
    def setUp(self) -> None:
        self.engine = DedupEngine()

    def test_exact_duplicate_hash_match_returns_existing_hash(self) -> None:
        content = "System ready"
        existing = [_memory(content, hash_value=_md5_12(content))]
        self.assertEqual(self.engine.is_duplicate(content, existing), _md5_12(content))
        self.assertEqual(self.engine.last_result["status"], "duplicate_exact")

    def test_exact_duplicate_uses_provided_hash(self) -> None:
        content = "Use the provided hash"
        existing = [_memory(content, hash_value="abc123provided")]
        self.assertEqual(self.engine.is_duplicate(content, existing), "abc123provided")

    def test_normalized_duplicate_case_and_whitespace(self) -> None:
        existing = [_memory("  DEPLOY   COMPLETE  ")]
        result = self.engine.is_duplicate("deploy complete", existing)
        self.assertEqual(result, existing[0].hash)
        self.assertEqual(self.engine.last_result["status"], "duplicate_normalized")

    def test_normalized_duplicate_ignores_iso_timestamp(self) -> None:
        existing = [_memory("Build finished at 2026-03-31 18:00:00 UTC")]
        result = self.engine.is_duplicate("build finished at 2026-03-31 19:15:00 UTC", existing)
        self.assertEqual(result, existing[0].hash)

    def test_normalized_duplicate_ignores_date_only(self) -> None:
        existing = [_memory("Meeting moved to 2026-03-31")]
        result = self.engine.is_duplicate("meeting moved to 2026-04-01", existing)
        self.assertEqual(result, existing[0].hash)

    def test_unique_content_returns_none(self) -> None:
        existing = [_memory("cat on mat")]
        self.assertIsNone(self.engine.is_duplicate("server deploy complete", existing))
        self.assertEqual(self.engine.last_result["status"], "unique")

    def test_jaccard_above_threshold_dedups(self) -> None:
        existing = [_memory("alpha beta gamma delta epsilon zeta")]
        result = self.engine.is_duplicate("alpha beta gamma delta epsilon zeta extra", existing)
        self.assertEqual(result, existing[0].hash)
        self.assertEqual(self.engine.last_result["status"], "duplicate_fuzzy")
        self.assertGreater(self.engine.last_result["similarity"], 0.85)

    def test_jaccard_review_band_sets_possibly_duplicate(self) -> None:
        existing = [_memory("alpha beta gamma delta")]
        result = self.engine.is_duplicate("alpha beta gamma delta theta", existing)
        self.assertIsNone(result)
        self.assertEqual(self.engine.last_result["status"], "possibly_duplicate")
        self.assertEqual(self.engine.last_result["match_hash"], existing[0].hash)

    def test_jaccard_below_review_band_stores_normally(self) -> None:
        existing = [_memory("alpha beta gamma delta")]
        result = self.engine.is_duplicate("alpha beta theta lambda", existing)
        self.assertIsNone(result)
        self.assertEqual(self.engine.last_result["status"], "unique")

    def test_number_difference_blocks_fuzzy_dedup(self) -> None:
        existing = [_memory("release version 3.3.2 shipped successfully today")]
        result = self.engine.is_duplicate("release version 3.3.3 shipped successfully today", existing)
        self.assertIsNone(result)
        self.assertEqual(self.engine.last_result["status"], "unique")

    def test_plain_number_difference_blocks_fuzzy_dedup(self) -> None:
        existing = [_memory("processed 14 files successfully in batch")]
        result = self.engine.is_duplicate("processed 15 files successfully in batch", existing)
        self.assertIsNone(result)

    def test_negation_difference_blocks_fuzzy_dedup(self) -> None:
        existing = [_memory("The service is working now")]
        result = self.engine.is_duplicate("The service is not working now", existing)
        self.assertIsNone(result)

    def test_contraction_negation_difference_blocks_fuzzy_dedup(self) -> None:
        existing = [_memory("Pipeline is running cleanly")]
        result = self.engine.is_duplicate("Pipeline isn't running cleanly", existing)
        self.assertIsNone(result)

    def test_proper_noun_difference_blocks_fuzzy_dedup(self) -> None:
        existing = [_memory("Discussed migration plan with Alice yesterday")]
        result = self.engine.is_duplicate("Discussed migration plan with Bob yesterday", existing)
        self.assertIsNone(result)

    def test_same_proper_nouns_do_not_block(self) -> None:
        existing = [_memory("Alice reviewed the final ambient awareness plan")]
        result = self.engine.is_duplicate("Alice reviewed final ambient awareness plan", existing)
        self.assertEqual(result, existing[0].hash)

    def test_window_filters_out_old_memories(self) -> None:
        existing = [_memory("deploy complete", hours_ago=48)]
        self.assertIsNone(self.engine.is_duplicate("deploy complete", existing, window_hours=24))

    def test_window_includes_recent_memories(self) -> None:
        existing = [_memory("deploy complete", hours_ago=2)]
        self.assertEqual(self.engine.is_duplicate("deploy complete", existing, window_hours=24), existing[0].hash)

    def test_missing_created_is_included(self) -> None:
        memory = {"content": "deploy complete", "hash": "dict-hash"}
        self.assertEqual(self.engine.is_duplicate("deploy complete", [memory]), "dict-hash")

    def test_empty_content_returns_none(self) -> None:
        existing = [_memory("something here")]
        self.assertIsNone(self.engine.is_duplicate("   ", existing))

    def test_empty_existing_content_is_skipped(self) -> None:
        existing = [_memory("")]
        self.assertIsNone(self.engine.is_duplicate("useful content", existing))

    def test_very_short_content_exact_match_dedups(self) -> None:
        existing = [_memory("ok")]
        self.assertEqual(self.engine.is_duplicate("ok", existing), existing[0].hash)

    def test_very_short_content_different_text_does_not_fuzzy_dedup(self) -> None:
        existing = [_memory("ok")]
        self.assertIsNone(self.engine.is_duplicate("go", existing))

    def test_tokenize_removes_stopwords_and_punctuation(self) -> None:
        tokens = self.engine._tokenize("This, and that, are in the system!")
        self.assertEqual(tokens, {"system"})

    def test_normalize_applies_unicode_normalization(self) -> None:
        normalized = self.engine._normalize("cafe\u0301")
        self.assertEqual(normalized, "café")

    def test_jaccard_similarity_handles_empty_sets(self) -> None:
        self.assertEqual(self.engine._jaccard_similarity(set(), {"x"}), 0.0)
        self.assertEqual(self.engine._jaccard_similarity(set(), set()), 0.0)

    def test_jaccard_similarity_computes_expected_ratio(self) -> None:
        score = self.engine._jaccard_similarity({"a", "b", "c"}, {"b", "c", "d"})
        self.assertAlmostEqual(score, 0.5)

    def test_identical_content_with_different_timestamps_dedups(self) -> None:
        existing = [_memory("Alert fired at 18:00 PST for ambient system")]
        result = self.engine.is_duplicate("Alert fired at 19:30 PST for ambient system", existing)
        self.assertEqual(result, existing[0].hash)

    def test_dict_memory_objects_supported(self) -> None:
        memory = {
            "content": "alpha beta gamma delta epsilon zeta",
            "hash": "dict123hash",
            "created": datetime.now(timezone.utc).isoformat(),
        }
        result = self.engine.is_duplicate("alpha beta gamma delta epsilon zeta extra", [memory])
        self.assertEqual(result, "dict123hash")

    def test_invalid_created_value_is_treated_as_recent(self) -> None:
        memory = {"content": "deploy complete", "hash": "badcreated", "created": "not-a-date"}
        result = self.engine.is_duplicate("deploy complete", [memory])
        self.assertEqual(result, "badcreated")

    def test_has_critical_difference_detects_versions(self) -> None:
        self.assertTrue(
            self.engine._has_critical_difference(
                "ambient awareness shipped in v3.4.0",
                "ambient awareness shipped in v3.4.1",
            )
        )

    def test_has_critical_difference_detects_negation(self) -> None:
        self.assertTrue(
            self.engine._has_critical_difference(
                "feature is enabled",
                "feature is not enabled",
            )
        )

    def test_has_critical_difference_detects_proper_nouns(self) -> None:
        self.assertTrue(
            self.engine._has_critical_difference(
                "Alice approved the release",
                "Bob approved the release",
            )
        )

    def test_has_critical_difference_false_for_equivalent_text(self) -> None:
        self.assertFalse(
            self.engine._has_critical_difference(
                "Alice approved the release",
                "Alice approved release",
            )
        )


if __name__ == "__main__":
    unittest.main()
