"""
Tests for SessionTracker — Parsica Memory v3.4.0 Ambient Awareness.

Trigger-based design: sessions transition via explicit begin_turn/end_turn
signals from the runtime, NOT via time-based TTL.

Covers:
- begin_turn/end_turn state transitions
- Turn depth reference counting (nested/concurrent turns)
- Named task tracking (add_task/complete_task)
- Write gate (active=allow, idle=deny, unregistered=fail-open, backward compat)
- Force idle escape hatch
- Ambient context retrieval
- Crash safety net (cleanup_stale, safety sweep)
- Backward compat (no sessions = everything allowed)
- Open vs closed mode
- Edge cases (end_turn without begin_turn, complete_task that doesn't exist,
  rapid cycling, session limit eviction)
"""

from __future__ import annotations

import logging
import time
import unittest
from unittest.mock import patch

from parsica_memory.session_tracker import (
    MAX_PENDING_TASKS,
    MAX_TRACKED_SESSIONS,
    SAFETY_TTL_SECONDS,
    SessionState,
    SessionTracker,
)


class TestSessionState(unittest.TestCase):
    """Tests for the SessionState dataclass."""

    def test_defaults(self):
        state = SessionState(session_id="test-1")
        self.assertEqual(state.session_id, "test-1")
        self.assertEqual(state.status, "idle")
        self.assertEqual(state.turn_depth, 0)
        self.assertEqual(state.pending_tasks, {})
        self.assertEqual(state.last_active, 0.0)
        self.assertEqual(state.last_memory_summary, "")

    def test_custom_values(self):
        state = SessionState(
            session_id="s2",
            status="active",
            turn_depth=2,
            pending_tasks={"task-a": 1000.0},
            last_active=1000.0,
            last_memory_summary="Working on parsica",
        )
        self.assertEqual(state.status, "active")
        self.assertEqual(state.turn_depth, 2)
        self.assertEqual(len(state.pending_tasks), 1)
        self.assertIn("task-a", state.pending_tasks)
        self.assertEqual(state.last_memory_summary, "Working on parsica")


class TestBeginEndTurn(unittest.TestCase):
    """Tests for begin_turn/end_turn state transitions."""

    def setUp(self):
        self.tracker = SessionTracker()

    def test_begin_turn_creates_active_session(self):
        self.tracker.begin_turn("s1")
        self.assertTrue(self.tracker.is_active("s1"))
        state = self.tracker.get_session_state("s1")
        self.assertIsNotNone(state)
        self.assertEqual(state.status, "active")
        self.assertEqual(state.turn_depth, 1)
        self.assertGreater(state.last_active, 0)

    def test_end_turn_makes_idle(self):
        self.tracker.begin_turn("s1")
        self.tracker.end_turn("s1")
        self.assertFalse(self.tracker.is_active("s1"))
        state = self.tracker.get_session_state("s1")
        self.assertEqual(state.status, "idle")
        self.assertEqual(state.turn_depth, 0)

    def test_begin_end_begin_reactivates(self):
        """Session can be reactivated after going idle."""
        self.tracker.begin_turn("s1")
        self.tracker.end_turn("s1")
        self.assertFalse(self.tracker.is_active("s1"))
        self.tracker.begin_turn("s1")
        self.assertTrue(self.tracker.is_active("s1"))
        self.assertEqual(self.tracker.get_session_state("s1").turn_depth, 1)

    def test_begin_turn_auto_registers_new_session(self):
        """begin_turn on an unknown session auto-registers it."""
        self.assertIsNone(self.tracker.get_session_state("new"))
        self.tracker.begin_turn("new")
        self.assertIsNotNone(self.tracker.get_session_state("new"))
        self.assertTrue(self.tracker.is_active("new"))

    def test_begin_turn_refreshes_timestamp(self):
        self.tracker.begin_turn("s1")
        ts1 = self.tracker.get_session_state("s1").last_active
        time.sleep(0.01)
        self.tracker.begin_turn("s1")
        ts2 = self.tracker.get_session_state("s1").last_active
        self.assertGreater(ts2, ts1)

    def test_end_turn_nonexistent_is_noop(self):
        """Ending a turn on a session that was never started does nothing."""
        self.tracker.end_turn("ghost")  # should not raise
        self.assertIsNone(self.tracker.get_session_state("ghost"))

    def test_end_turn_updates_last_active(self):
        self.tracker.begin_turn("s1")
        ts1 = self.tracker.get_session_state("s1").last_active
        time.sleep(0.01)
        self.tracker.end_turn("s1")
        ts2 = self.tracker.get_session_state("s1").last_active
        self.assertGreater(ts2, ts1)

    def test_multiple_sessions_independent(self):
        """Multiple sessions can be tracked independently."""
        self.tracker.begin_turn("s1")
        self.tracker.begin_turn("s2")
        self.assertTrue(self.tracker.is_active("s1"))
        self.assertTrue(self.tracker.is_active("s2"))

        self.tracker.end_turn("s1")
        self.assertFalse(self.tracker.is_active("s1"))
        self.assertTrue(self.tracker.is_active("s2"))


class TestTurnDepthRefCounting(unittest.TestCase):
    """Tests for turn_depth reference counting (concurrent/nested turns)."""

    def setUp(self):
        self.tracker = SessionTracker()

    def test_nested_turns_increment_depth(self):
        """Multiple begin_turn calls increment turn_depth."""
        self.tracker.begin_turn("s1")
        self.assertEqual(self.tracker.get_session_state("s1").turn_depth, 1)
        self.tracker.begin_turn("s1")
        self.assertEqual(self.tracker.get_session_state("s1").turn_depth, 2)
        self.tracker.begin_turn("s1")
        self.assertEqual(self.tracker.get_session_state("s1").turn_depth, 3)

    def test_nested_turns_stay_active_until_all_end(self):
        """Session stays ACTIVE until all nested turns complete."""
        self.tracker.begin_turn("s1")
        self.tracker.begin_turn("s1")

        self.tracker.end_turn("s1")
        self.assertTrue(self.tracker.is_active("s1"))
        self.assertEqual(self.tracker.get_session_state("s1").turn_depth, 1)

        self.tracker.end_turn("s1")
        self.assertFalse(self.tracker.is_active("s1"))
        self.assertEqual(self.tracker.get_session_state("s1").turn_depth, 0)

    def test_concurrent_messages_reference_counting(self):
        """Simulates two messages arriving before the first completes."""
        # Message 1 arrives
        self.tracker.begin_turn("s1")  # depth=1
        # Message 2 arrives before message 1 finishes
        self.tracker.begin_turn("s1")  # depth=2

        # Message 1 finishes
        self.tracker.end_turn("s1")  # depth=1, still ACTIVE
        self.assertTrue(self.tracker.is_active("s1"))

        # Message 2 finishes
        self.tracker.end_turn("s1")  # depth=0, → IDLE
        self.assertFalse(self.tracker.is_active("s1"))

    def test_end_turn_without_begin_warns(self):
        """end_turn when turn_depth is 0 logs a warning."""
        self.tracker.begin_turn("s1")
        self.tracker.end_turn("s1")  # depth → 0, IDLE

        with self.assertLogs("parsica_memory", level="WARNING") as cm:
            self.tracker.end_turn("s1")  # depth already 0

        self.assertTrue(any("turn_depth already 0" in msg for msg in cm.output))
        # turn_depth should NOT go negative
        self.assertEqual(self.tracker.get_session_state("s1").turn_depth, 0)

    def test_turn_depth_never_negative(self):
        """turn_depth is clamped at 0 — never goes negative."""
        self.tracker.begin_turn("s1")
        self.tracker.end_turn("s1")

        # Extra end_turn calls should not make depth negative
        with self.assertLogs("parsica_memory", level="WARNING"):
            self.tracker.end_turn("s1")

        self.assertEqual(self.tracker.get_session_state("s1").turn_depth, 0)

    def test_deeply_nested_turns(self):
        """Handles many levels of nesting correctly."""
        depth = 10
        for _ in range(depth):
            self.tracker.begin_turn("s1")
        self.assertEqual(self.tracker.get_session_state("s1").turn_depth, depth)

        for i in range(depth):
            self.tracker.end_turn("s1")
            if i < depth - 1:
                self.assertTrue(self.tracker.is_active("s1"))
            else:
                self.assertFalse(self.tracker.is_active("s1"))


class TestNamedTaskTracking(unittest.TestCase):
    """Tests for add_task/complete_task with named tasks."""

    def setUp(self):
        self.tracker = SessionTracker()

    def test_add_task_registers_named_task(self):
        self.tracker.begin_turn("s1")
        result = self.tracker.add_task("s1", "subagent-1")
        self.assertTrue(result)
        state = self.tracker.get_session_state("s1")
        self.assertIn("subagent-1", state.pending_tasks)

    def test_add_multiple_tasks(self):
        self.tracker.begin_turn("s1")
        self.tracker.add_task("s1", "task-a")
        self.tracker.add_task("s1", "task-b")
        self.tracker.add_task("s1", "task-c")
        state = self.tracker.get_session_state("s1")
        self.assertEqual(len(state.pending_tasks), 3)
        self.assertIn("task-a", state.pending_tasks)
        self.assertIn("task-b", state.pending_tasks)
        self.assertIn("task-c", state.pending_tasks)

    def test_complete_task_removes_named_task(self):
        self.tracker.begin_turn("s1")
        self.tracker.add_task("s1", "task-a")
        self.tracker.add_task("s1", "task-b")
        self.tracker.complete_task("s1", "task-a")
        state = self.tracker.get_session_state("s1")
        self.assertNotIn("task-a", state.pending_tasks)
        self.assertIn("task-b", state.pending_tasks)

    def test_tasks_keep_session_active_after_end_turn(self):
        """Session stays ACTIVE after end_turn if tasks are pending."""
        self.tracker.begin_turn("s1")
        self.tracker.add_task("s1", "long-running-job")
        self.tracker.end_turn("s1")  # turn_depth → 0, but task pending

        self.assertTrue(self.tracker.is_active("s1"))

    def test_completing_last_task_idles_session(self):
        """Completing the last task when turn_depth==0 transitions to IDLE."""
        self.tracker.begin_turn("s1")
        self.tracker.add_task("s1", "job-1")
        self.tracker.end_turn("s1")  # depth=0, task pending → stays ACTIVE

        self.tracker.complete_task("s1", "job-1")  # last task → IDLE
        self.assertFalse(self.tracker.is_active("s1"))

    def test_completing_task_with_remaining_turns_stays_active(self):
        """Completing a task while turn_depth > 0 stays ACTIVE."""
        self.tracker.begin_turn("s1")
        self.tracker.add_task("s1", "job-1")
        self.tracker.complete_task("s1", "job-1")  # no tasks, but depth=1

        self.assertTrue(self.tracker.is_active("s1"))

    def test_add_task_on_unregistered_session_warns(self):
        """add_task on an unregistered session logs warning and returns False."""
        with self.assertLogs("parsica_memory", level="WARNING") as cm:
            result = self.tracker.add_task("ghost", "task-1")
        self.assertFalse(result)
        self.assertTrue(any("not registered" in msg for msg in cm.output))

    def test_complete_task_nonexistent_task_warns(self):
        """Completing a task that doesn't exist logs a warning."""
        self.tracker.begin_turn("s1")
        with self.assertLogs("parsica_memory", level="WARNING") as cm:
            self.tracker.complete_task("s1", "no-such-task")
        self.assertTrue(any("task not found" in msg for msg in cm.output))

    def test_complete_task_on_unregistered_session_warns(self):
        """Completing a task on an unregistered session logs a warning."""
        with self.assertLogs("parsica_memory", level="WARNING") as cm:
            self.tracker.complete_task("ghost", "task-1")
        self.assertTrue(any("not registered" in msg for msg in cm.output))

    def test_add_task_at_limit_rejected(self):
        """Tasks beyond max_pending_tasks are rejected."""
        tracker = SessionTracker(max_pending_tasks=3)
        tracker.begin_turn("s1")
        self.assertTrue(tracker.add_task("s1", "t1"))
        self.assertTrue(tracker.add_task("s1", "t2"))
        self.assertTrue(tracker.add_task("s1", "t3"))

        with self.assertLogs("parsica_memory", level="WARNING"):
            result = tracker.add_task("s1", "t4")
        self.assertFalse(result)
        self.assertEqual(len(tracker.get_session_state("s1").pending_tasks), 3)

    def test_add_task_updates_last_active(self):
        self.tracker.begin_turn("s1")
        ts1 = self.tracker.get_session_state("s1").last_active
        time.sleep(0.01)
        self.tracker.add_task("s1", "task-1")
        ts2 = self.tracker.get_session_state("s1").last_active
        self.assertGreater(ts2, ts1)

    def test_complete_task_updates_last_active(self):
        self.tracker.begin_turn("s1")
        self.tracker.add_task("s1", "task-1")
        ts1 = self.tracker.get_session_state("s1").last_active
        time.sleep(0.01)
        self.tracker.complete_task("s1", "task-1")
        ts2 = self.tracker.get_session_state("s1").last_active
        self.assertGreater(ts2, ts1)

    def test_task_timestamps_recorded(self):
        """Task timestamps are recorded for safety net TTL."""
        self.tracker.begin_turn("s1")
        before = time.time()
        self.tracker.add_task("s1", "task-1")
        after = time.time()
        state = self.tracker.get_session_state("s1")
        ts = state.pending_tasks["task-1"]
        self.assertGreaterEqual(ts, before)
        self.assertLessEqual(ts, after)


class TestWriteGateClosed(unittest.TestCase):
    """Tests for is_write_allowed in CLOSED mode (default)."""

    def setUp(self):
        self.tracker = SessionTracker(mode="closed")

    def test_no_sessions_tracked_denies_in_closed(self):
        """CLOSED mode: strict from cold start — no sessions tracked = writes denied."""
        self.assertFalse(self.tracker.is_write_allowed("any-session"))
        # None is always denied in closed mode
        self.assertFalse(self.tracker.is_write_allowed(None))

    def test_none_session_id_denied_when_sessions_tracked(self):
        """CLOSED mode: None session_id denied when sessions exist."""
        self.tracker.begin_turn("s1")
        with self.assertLogs("parsica_memory", level="WARNING"):
            result = self.tracker.is_write_allowed(None)
        self.assertFalse(result)

    def test_active_session_allowed(self):
        """Active sessions can write."""
        self.tracker.begin_turn("s1")
        self.assertTrue(self.tracker.is_write_allowed("s1"))

    def test_idle_session_denied(self):
        """Idle sessions are denied in CLOSED mode."""
        self.tracker.begin_turn("s1")
        self.tracker.end_turn("s1")
        self.assertFalse(self.tracker.is_write_allowed("s1"))

    def test_unregistered_session_blocked_in_closed(self):
        """CLOSED mode: unregistered sessions are BLOCKED (not fail-open)."""
        self.tracker.begin_turn("s1")  # register at least one session
        with self.assertLogs("parsica_memory", level="WARNING") as cm:
            result = self.tracker.is_write_allowed("unknown-session")
        self.assertFalse(result)
        self.assertTrue(any("CLOSED" in msg or "denied" in msg for msg in cm.output))

    def test_reactivated_session_allowed(self):
        """A session that was idle then reactivated can write again."""
        self.tracker.begin_turn("s1")
        self.tracker.end_turn("s1")
        self.assertFalse(self.tracker.is_write_allowed("s1"))
        self.tracker.begin_turn("s1")
        self.assertTrue(self.tracker.is_write_allowed("s1"))

    def test_session_with_pending_tasks_allowed(self):
        """Session with pending tasks (even after end_turn) can write."""
        self.tracker.begin_turn("s1")
        self.tracker.add_task("s1", "bg-job")
        self.tracker.end_turn("s1")
        # Still ACTIVE because of pending task
        self.assertTrue(self.tracker.is_write_allowed("s1"))


class TestWriteGateOpen(unittest.TestCase):
    """Tests for is_write_allowed in OPEN mode."""

    def setUp(self):
        self.tracker = SessionTracker(mode="open")

    def test_no_sessions_allows_all(self):
        self.assertTrue(self.tracker.is_write_allowed("any"))
        self.assertTrue(self.tracker.is_write_allowed(None))

    def test_active_session_allowed(self):
        self.tracker.begin_turn("s1")
        self.assertTrue(self.tracker.is_write_allowed("s1"))

    def test_idle_session_allowed_with_warning(self):
        """OPEN mode: idle sessions can write (with warning)."""
        self.tracker.begin_turn("s1")
        self.tracker.end_turn("s1")
        with self.assertLogs("parsica_memory", level="WARNING"):
            result = self.tracker.is_write_allowed("s1")
        self.assertTrue(result)

    def test_unregistered_session_allowed_with_warning(self):
        """OPEN mode: unregistered sessions can write (with warning)."""
        self.tracker.begin_turn("s1")
        with self.assertLogs("parsica_memory", level="WARNING"):
            result = self.tracker.is_write_allowed("unknown")
        self.assertTrue(result)

    def test_none_session_id_allowed(self):
        """OPEN mode: None session_id always allowed."""
        self.tracker.begin_turn("s1")
        self.assertTrue(self.tracker.is_write_allowed(None))


class TestForceIdle(unittest.TestCase):
    """Tests for the force_idle escape hatch."""

    def setUp(self):
        self.tracker = SessionTracker()

    def test_force_idle_clears_everything(self):
        self.tracker.begin_turn("s1")
        self.tracker.begin_turn("s1")  # depth=2
        self.tracker.add_task("s1", "task-a")
        self.tracker.add_task("s1", "task-b")

        self.tracker.force_idle("s1")

        state = self.tracker.get_session_state("s1")
        self.assertEqual(state.status, "idle")
        self.assertEqual(state.turn_depth, 0)
        self.assertEqual(state.pending_tasks, {})

    def test_force_idle_on_already_idle(self):
        """force_idle on an already idle session is a no-op."""
        self.tracker.begin_turn("s1")
        self.tracker.end_turn("s1")
        self.tracker.force_idle("s1")  # should not raise
        self.assertFalse(self.tracker.is_active("s1"))

    def test_force_idle_on_nonexistent_session(self):
        """force_idle on a nonexistent session is a no-op."""
        self.tracker.force_idle("ghost")  # should not raise

    def test_force_idle_denies_writes_in_closed_mode(self):
        """After force_idle, writes are denied in CLOSED mode."""
        self.tracker.begin_turn("s1")
        self.assertTrue(self.tracker.is_write_allowed("s1"))
        self.tracker.force_idle("s1")
        self.assertFalse(self.tracker.is_write_allowed("s1"))

    def test_force_idle_updates_last_active(self):
        self.tracker.begin_turn("s1")
        ts1 = self.tracker.get_session_state("s1").last_active
        time.sleep(0.01)
        self.tracker.force_idle("s1")
        ts2 = self.tracker.get_session_state("s1").last_active
        self.assertGreater(ts2, ts1)


class TestAmbientContext(unittest.TestCase):
    """Tests for get_ambient_context and update_memory_summary."""

    def setUp(self):
        self.tracker = SessionTracker()

    def test_ambient_context_excludes_current_session(self):
        self.tracker.begin_turn("s1")
        self.tracker.begin_turn("s2")
        self.tracker.update_memory_summary("s1", "Working on parsica")
        self.tracker.update_memory_summary("s2", "Debugging forge")

        context = self.tracker.get_ambient_context("s1")
        self.assertEqual(len(context), 1)
        self.assertIn("[s2]", context[0])
        self.assertIn("Debugging forge", context[0])

    def test_ambient_context_empty_when_no_other_sessions(self):
        self.tracker.begin_turn("s1")
        self.tracker.update_memory_summary("s1", "Solo work")
        context = self.tracker.get_ambient_context("s1")
        self.assertEqual(context, [])

    def test_ambient_context_skips_sessions_without_summary(self):
        self.tracker.begin_turn("s1")
        self.tracker.begin_turn("s2")
        self.tracker.update_memory_summary("s1", "Has summary")
        # s2 has no summary

        context = self.tracker.get_ambient_context("s1")
        self.assertEqual(context, [])

    def test_ambient_context_respects_limit(self):
        for i in range(10):
            sid = f"s{i}"
            self.tracker.begin_turn(sid)
            self.tracker.update_memory_summary(sid, f"Task {i}")

        context = self.tracker.get_ambient_context("s0", limit=3)
        self.assertEqual(len(context), 3)

    def test_ambient_context_sorted_by_recency(self):
        """Most recently active sessions appear first."""
        self.tracker.begin_turn("old")
        self.tracker.update_memory_summary("old", "Old work")
        state_old = self.tracker.get_session_state("old")
        state_old.last_active = time.time() - 1000

        self.tracker.begin_turn("new")
        self.tracker.update_memory_summary("new", "New work")

        context = self.tracker.get_ambient_context("requester")
        self.assertEqual(len(context), 2)
        self.assertIn("[new]", context[0])
        self.assertIn("[old]", context[1])

    def test_update_memory_summary_truncates(self):
        """Summaries are capped at 200 characters."""
        self.tracker.begin_turn("s1")
        long_summary = "x" * 500
        self.tracker.update_memory_summary("s1", long_summary)
        state = self.tracker.get_session_state("s1")
        self.assertEqual(len(state.last_memory_summary), 200)

    def test_update_memory_summary_on_nonexistent_session(self):
        """Updating summary on a nonexistent session is a no-op."""
        self.tracker.update_memory_summary("ghost", "Should not crash")
        self.assertIsNone(self.tracker.get_session_state("ghost"))

    def test_ambient_context_includes_idle_sessions_with_summary(self):
        """Idle sessions with summaries are included in ambient context."""
        self.tracker.begin_turn("s1")
        self.tracker.update_memory_summary("s1", "Was working on X")
        self.tracker.end_turn("s1")

        self.tracker.begin_turn("s2")
        context = self.tracker.get_ambient_context("s2")
        self.assertEqual(len(context), 1)
        self.assertIn("Was working on X", context[0])

    def test_summary_persists_across_begin_end_cycles(self):
        """Memory summary persists across begin_turn/end_turn cycles."""
        self.tracker.begin_turn("s1")
        self.tracker.update_memory_summary("s1", "Important context")
        self.tracker.end_turn("s1")
        self.tracker.begin_turn("s1")

        state = self.tracker.get_session_state("s1")
        self.assertEqual(state.last_memory_summary, "Important context")


class TestCrashSafetyNet(unittest.TestCase):
    """Tests for cleanup_stale and the safety sweep."""

    def setUp(self):
        self.tracker = SessionTracker(safety_ttl_seconds=1800)

    def test_cleanup_removes_old_idle_sessions(self):
        self.tracker.begin_turn("s1")
        self.tracker.end_turn("s1")

        # Backdate the last_active timestamp
        state = self.tracker.get_session_state("s1")
        state.last_active = time.time() - 7200  # 2 hours ago

        removed = self.tracker.cleanup_stale(max_idle_seconds=3600)
        self.assertEqual(removed, 1)
        self.assertIsNone(self.tracker.get_session_state("s1"))

    def test_cleanup_keeps_recent_idle_sessions(self):
        self.tracker.begin_turn("s1")
        self.tracker.end_turn("s1")

        removed = self.tracker.cleanup_stale(max_idle_seconds=3600)
        self.assertEqual(removed, 0)
        self.assertIsNotNone(self.tracker.get_session_state("s1"))

    def test_cleanup_keeps_active_sessions(self):
        """Active sessions are never cleaned up by idle cleanup."""
        self.tracker.begin_turn("s1")
        state = self.tracker.get_session_state("s1")
        state.last_active = time.time() - 7200  # old but active

        removed = self.tracker.cleanup_stale(max_idle_seconds=3600)
        self.assertEqual(removed, 0)

    def test_safety_sweep_forces_stuck_active_to_idle(self):
        """Safety sweep catches sessions stuck ACTIVE beyond safety TTL."""
        self.tracker.begin_turn("s1")
        state = self.tracker.get_session_state("s1")
        state.last_active = time.time() - 2000  # beyond 1800s safety TTL

        with self.assertLogs("parsica_memory", level="ERROR") as cm:
            self.tracker._safety_sweep_now()

        self.assertFalse(self.tracker.is_active("s1"))
        self.assertEqual(state.turn_depth, 0)
        self.assertEqual(state.pending_tasks, {})
        self.assertTrue(any("SAFETY NET" in msg for msg in cm.output))

    def test_safety_sweep_ignores_recent_active(self):
        """Safety sweep does not touch recently active sessions."""
        self.tracker.begin_turn("s1")
        self.tracker._safety_sweep_now()
        self.assertTrue(self.tracker.is_active("s1"))

    def test_safety_sweep_ignores_idle_sessions(self):
        """Safety sweep only targets ACTIVE sessions."""
        self.tracker.begin_turn("s1")
        self.tracker.end_turn("s1")
        state = self.tracker.get_session_state("s1")
        state.last_active = time.time() - 5000

        self.tracker._safety_sweep_now()
        # Should still be idle (not removed — that's cleanup_stale's job)
        self.assertIsNotNone(self.tracker.get_session_state("s1"))

    def test_cleanup_stale_runs_safety_sweep_first(self):
        """cleanup_stale runs safety sweep before pruning idle sessions."""
        self.tracker.begin_turn("s1")
        state = self.tracker.get_session_state("s1")
        state.last_active = time.time() - 5000  # beyond safety TTL

        with self.assertLogs("parsica_memory", level="ERROR"):
            self.tracker.cleanup_stale(max_idle_seconds=3600)

        # Safety sweep forced it to idle (and refreshed last_active to now),
        # so it's now a recently-idle session — not stale enough to remove.
        # Verify it was forced idle by the sweep.
        state = self.tracker.get_session_state("s1")
        self.assertIsNotNone(state)
        self.assertEqual(state.status, "idle")
        self.assertEqual(state.turn_depth, 0)
        self.assertEqual(state.pending_tasks, {})

    def test_cleanup_with_no_sessions(self):
        """cleanup_stale on empty tracker returns 0."""
        removed = self.tracker.cleanup_stale()
        self.assertEqual(removed, 0)

    def test_cleanup_mixed_stale_and_fresh(self):
        """Only stale idle sessions are removed."""
        self.tracker.begin_turn("stale")
        self.tracker.end_turn("stale")
        self.tracker.get_session_state("stale").last_active = time.time() - 7200

        self.tracker.begin_turn("fresh")
        self.tracker.end_turn("fresh")

        self.tracker.begin_turn("active")

        removed = self.tracker.cleanup_stale(max_idle_seconds=3600)
        self.assertEqual(removed, 1)
        self.assertIsNone(self.tracker.get_session_state("stale"))
        self.assertIsNotNone(self.tracker.get_session_state("fresh"))
        self.assertIsNotNone(self.tracker.get_session_state("active"))

    def test_cleanup_custom_timeout(self):
        """cleanup_stale respects custom max_idle_seconds."""
        self.tracker.begin_turn("s1")
        self.tracker.end_turn("s1")
        state = self.tracker.get_session_state("s1")
        state.last_active = time.time() - 120  # 2 minutes ago

        # 5-minute timeout: should NOT remove
        removed = self.tracker.cleanup_stale(max_idle_seconds=300)
        self.assertEqual(removed, 0)

        # 1-minute timeout: should remove
        removed = self.tracker.cleanup_stale(max_idle_seconds=60)
        self.assertEqual(removed, 1)


class TestGetActiveSessions(unittest.TestCase):
    """Tests for get_active_sessions and get_states."""

    def setUp(self):
        self.tracker = SessionTracker()

    def test_get_active_sessions_empty(self):
        self.assertEqual(self.tracker.get_active_sessions(), [])

    def test_get_active_sessions_filters_idle(self):
        self.tracker.begin_turn("active")
        self.tracker.begin_turn("idle")
        self.tracker.end_turn("idle")

        active = self.tracker.get_active_sessions()
        self.assertEqual(active, ["active"])

    def test_get_states_returns_all(self):
        self.tracker.begin_turn("s1")
        self.tracker.begin_turn("s2")
        self.tracker.end_turn("s2")

        states = self.tracker.get_states()
        self.assertEqual(len(states), 2)
        self.assertIn("s1", states)
        self.assertIn("s2", states)

    def test_has_any_sessions(self):
        self.assertFalse(self.tracker.has_any_sessions())
        self.tracker.begin_turn("s1")
        self.assertTrue(self.tracker.has_any_sessions())


class TestBackwardCompat(unittest.TestCase):
    """Tests ensuring backward compatibility when no sessions are tracked."""

    def test_no_sessions_open_mode_allows_everything(self):
        """OPEN mode: with zero sessions registered, all writes are allowed."""
        tracker = SessionTracker(mode="open")
        self.assertTrue(tracker.is_write_allowed("any"))
        self.assertTrue(tracker.is_write_allowed(None))
        self.assertTrue(tracker.is_write_allowed(""))

    def test_no_sessions_closed_mode_denies(self):
        """CLOSED mode: strict from cold start — denies even with zero sessions."""
        tracker = SessionTracker(mode="closed")
        self.assertFalse(tracker.is_write_allowed("any"))

    def test_is_active_returns_false_for_unknown(self):
        tracker = SessionTracker()
        self.assertFalse(tracker.is_active("unknown"))

    def test_get_active_sessions_empty_by_default(self):
        tracker = SessionTracker()
        self.assertEqual(tracker.get_active_sessions(), [])

    def test_ambient_context_empty_by_default(self):
        tracker = SessionTracker()
        self.assertEqual(tracker.get_ambient_context("any"), [])


class TestEdgeCases(unittest.TestCase):
    """Edge case and regression tests."""

    def setUp(self):
        self.tracker = SessionTracker()

    def test_rapid_begin_end_cycles(self):
        """Rapid begin_turn/end_turn cycles don't corrupt state."""
        for _ in range(100):
            self.tracker.begin_turn("s1")
            self.tracker.end_turn("s1")
        state = self.tracker.get_session_state("s1")
        self.assertEqual(state.status, "idle")
        self.assertEqual(state.turn_depth, 0)
        self.assertEqual(state.pending_tasks, {})

    def test_many_concurrent_sessions(self):
        """Tracker handles many concurrent sessions."""
        for i in range(50):
            self.tracker.begin_turn(f"session-{i}")

        active = self.tracker.get_active_sessions()
        self.assertEqual(len(active), 50)

        for i in range(25):
            self.tracker.end_turn(f"session-{i}")

        active = self.tracker.get_active_sessions()
        self.assertEqual(len(active), 25)

    def test_complete_task_that_doesnt_exist(self):
        """Completing a nonexistent task warns but doesn't crash."""
        self.tracker.begin_turn("s1")
        self.tracker.add_task("s1", "real-task")
        with self.assertLogs("parsica_memory", level="WARNING"):
            self.tracker.complete_task("s1", "fake-task")
        # Real task should still be there
        self.assertIn("real-task", self.tracker.get_session_state("s1").pending_tasks)

    def test_end_turn_with_tasks_stays_active(self):
        """end_turn doesn't idle a session with pending tasks."""
        self.tracker.begin_turn("s1")
        self.tracker.add_task("s1", "bg-job")
        self.tracker.end_turn("s1")
        self.assertTrue(self.tracker.is_active("s1"))
        self.assertEqual(self.tracker.get_session_state("s1").turn_depth, 0)

    def test_interleaved_tasks_and_turns(self):
        """Complex interleaving of tasks and turns."""
        self.tracker.begin_turn("s1")
        self.tracker.add_task("s1", "task-1")
        self.tracker.begin_turn("s1")  # nested turn
        self.tracker.add_task("s1", "task-2")
        self.tracker.end_turn("s1")  # depth=1, 2 tasks → ACTIVE
        self.assertTrue(self.tracker.is_active("s1"))

        self.tracker.complete_task("s1", "task-1")  # depth=1, 1 task → ACTIVE
        self.assertTrue(self.tracker.is_active("s1"))

        self.tracker.end_turn("s1")  # depth=0, 1 task → ACTIVE
        self.assertTrue(self.tracker.is_active("s1"))

        self.tracker.complete_task("s1", "task-2")  # depth=0, 0 tasks → IDLE
        self.assertFalse(self.tracker.is_active("s1"))

    def test_session_limit_eviction(self):
        """Sessions beyond max_sessions trigger LRU eviction of idle sessions."""
        tracker = SessionTracker(max_sessions=5)

        # Create 5 sessions, idle the first 3
        for i in range(5):
            tracker.begin_turn(f"s{i}")
        for i in range(3):
            tracker.end_turn(f"s{i}")
            # Backdate to make them old
            tracker.get_session_state(f"s{i}").last_active = time.time() - (300 - i)

        # Adding a 6th session should evict the oldest idle one
        tracker.begin_turn("s5")
        self.assertIsNone(tracker.get_session_state("s0"))  # oldest idle evicted
        self.assertIsNotNone(tracker.get_session_state("s1"))  # still there

    def test_constants_values(self):
        """Module constants have expected values."""
        self.assertEqual(SAFETY_TTL_SECONDS, 1800)
        self.assertEqual(MAX_PENDING_TASKS, 50)
        self.assertEqual(MAX_TRACKED_SESSIONS, 500)

    def test_mode_defaults_to_closed(self):
        """Default mode is closed."""
        tracker = SessionTracker()
        self.assertEqual(tracker._mode, "closed")

    def test_sanitize_summary_strips_control_chars(self):
        """Summary sanitization strips control characters."""
        self.tracker.begin_turn("s1")
        self.tracker.update_memory_summary("s1", "Hello\x00World\x01!")
        state = self.tracker.get_session_state("s1")
        self.assertNotIn("\x00", state.last_memory_summary)
        self.assertNotIn("\x01", state.last_memory_summary)
        self.assertIn("Hello", state.last_memory_summary)
        self.assertIn("World", state.last_memory_summary)

    def test_empty_string_session_id_no_sessions_closed(self):
        """CLOSED mode: empty string session_id with no sessions = denied (strict cold start)."""
        self.assertFalse(self.tracker.is_write_allowed(""))

    def test_empty_string_session_id_with_sessions(self):
        """Empty string session_id when sessions exist = blocked in CLOSED mode."""
        self.tracker.begin_turn("s1")
        with self.assertLogs("parsica_memory", level="WARNING"):
            result = self.tracker.is_write_allowed("")
        self.assertFalse(result)

    def test_force_idle_then_begin_turn_reactivates(self):
        """After force_idle, begin_turn properly reactivates."""
        self.tracker.begin_turn("s1")
        self.tracker.add_task("s1", "task-1")
        self.tracker.force_idle("s1")
        self.assertFalse(self.tracker.is_active("s1"))

        self.tracker.begin_turn("s1")
        self.assertTrue(self.tracker.is_active("s1"))
        self.assertEqual(self.tracker.get_session_state("s1").turn_depth, 1)
        self.assertEqual(self.tracker.get_session_state("s1").pending_tasks, {})

    def test_safety_sweep_lazy_throttling(self):
        """Safety sweep is throttled to run at most once per interval."""
        self.tracker._last_sweep = time.time()  # just swept
        self.tracker.begin_turn("s1")
        state = self.tracker.get_session_state("s1")
        state.last_active = time.time() - 5000  # beyond safety TTL

        # _maybe_safety_sweep should be throttled (no sweep)
        self.tracker._maybe_safety_sweep()
        # Session should still be active (sweep was throttled)
        self.assertTrue(self.tracker.is_active("s1"))

    def test_double_add_same_task_name_overwrites_timestamp(self):
        """Adding a task with the same name overwrites the timestamp."""
        self.tracker.begin_turn("s1")
        self.tracker.add_task("s1", "task-1")
        ts1 = self.tracker.get_session_state("s1").pending_tasks["task-1"]
        time.sleep(0.01)
        self.tracker.add_task("s1", "task-1")
        ts2 = self.tracker.get_session_state("s1").pending_tasks["task-1"]
        self.assertGreater(ts2, ts1)
        # Still only one task
        self.assertEqual(len(self.tracker.get_session_state("s1").pending_tasks), 1)


if __name__ == "__main__":
    unittest.main()
