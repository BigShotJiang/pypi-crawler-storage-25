"""Crash-boundary and recovery tests for parsica_memory.storage.segment_store.

These tests simulate crash windows by manipulating files between operations
instead of actually killing the process.
"""

from __future__ import annotations

import json
import os
import shutil
import tempfile
import unittest
from datetime import datetime, timezone

from parsica_memory.entry import MemoryEntry
from parsica_memory.storage.manifest import _empty_manifest
from parsica_memory.storage.segment_store import SegmentStore, _read_ops_from_path, _segment_filename
from parsica_memory.storage.segments import SegmentReader, SegmentWriter


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_entry(content: str = "test memory", **kwargs) -> MemoryEntry:
    defaults = {
        "source": "crash_test",
        "category": "general",
        "memory_type": "episodic",
    }
    defaults.update(kwargs)
    return MemoryEntry(content=content, **defaults)


def _make_entries(n: int, prefix: str = "mem") -> list[MemoryEntry]:
    return [_make_entry(f"{prefix}_{i}") for i in range(n)]


def _write_json(path: str, data: dict) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


class CrashBoundaryTestBase(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.mkdtemp()
        self.store = SegmentStore(
            self.tmp,
            hot_max_ops=100,
            hot_max_bytes=4_194_304,
            hot_max_age_seconds=300,
            hot_min_ops=5,
        )
        self.seg_dir = self.store.seg_dir

    def tearDown(self) -> None:
        shutil.rmtree(self.tmp, ignore_errors=True)

    def _new_store(self) -> SegmentStore:
        return SegmentStore(
            self.tmp,
            hot_max_ops=100,
            hot_max_bytes=4_194_304,
            hot_max_age_seconds=300,
            hot_min_ops=5,
        )

    def _manifest(self) -> dict:
        if not os.path.exists(self.store.manifest_path):
            return _empty_manifest()
        with open(self.store.manifest_path, "r", encoding="utf-8") as f:
            return json.load(f)


# ===================================================================
# Flush crash boundaries
# ===================================================================

class TestFlushCrashAfterHotRename(CrashBoundaryTestBase):
    def test_recovery_replays_rotating_file(self):
        entries = _make_entries(3, prefix="rename")
        for e in entries:
            self.store.append_put(e)

        os.replace(self.store.hot_path, self.store.rotating_path)
        self.store._hot_buffer._create_empty_file(self.store.hot_path)

        loaded = self._new_store().load()
        self.assertEqual(len(loaded), 3)
        self.assertEqual({e.hash for e in loaded}, {e.hash for e in entries})


class TestFlushCrashAfterSegmentWrite(CrashBoundaryTestBase):
    def test_orphan_segment_rotating_replayed(self):
        entries = _make_entries(4, prefix="orphan")
        for e in entries:
            self.store.append_put(e)

        os.replace(self.store.hot_path, self.store.rotating_path)
        self.store._hot_buffer._create_empty_file(self.store.hot_path)

        ops = _read_ops_from_path(self.store.rotating_path)
        put_entries = [MemoryEntry.from_dict(op["entry"]) for op in ops if op.get("op") == "put"]
        orphan_name = _segment_filename(1, len(put_entries))
        SegmentWriter.write_segment(os.path.join(self.seg_dir, orphan_name), put_entries)

        loaded = self._new_store().load()
        self.assertEqual(len(loaded), 4)
        self.assertEqual({e.hash for e in loaded}, {e.hash for e in entries})


class TestFlushCrashAfterManifestUpdate(CrashBoundaryTestBase):
    def test_dedup_handles_overlap(self):
        entries = _make_entries(3, prefix="overlap")
        for e in entries:
            self.store.append_put(e)
        self.store.flush()

        with open(self.store.rotating_path, "w", encoding="utf-8") as f:
            now = datetime.now(timezone.utc).isoformat()
            for e in entries:
                f.write(json.dumps({
                    "op": "put",
                    "hash": e.hash,
                    "entry": e.to_dict(),
                    "ts": now,
                }) + "\n")

        loaded = self._new_store().load()
        self.assertEqual(len(loaded), 3)
        self.assertEqual({e.hash for e in loaded}, {e.hash for e in entries})


# ===================================================================
# Compact crash boundaries
# ===================================================================

class TestCompactCrashAfterMergedSegmentWrite(CrashBoundaryTestBase):
    def test_old_segments_intact(self):
        all_entries = []
        for batch in range(5):
            es = _make_entries(3, prefix=f"compact_{batch}")
            all_entries.extend(es)
            for e in es:
                self.store.append_put(e)
            self.store.flush()

        manifest_before = self._manifest()
        self.assertEqual(len(manifest_before["segments"]), 5)

        loaded = self._new_store().load()
        self.assertEqual(len(loaded), len(all_entries))
        self.assertEqual({e.hash for e in loaded}, {e.hash for e in all_entries})


class TestCompactCrashDuringManifestSave(CrashBoundaryTestBase):
    def test_atomic_write_prevents_partial_state(self):
        for batch in range(4):
            for e in _make_entries(2, prefix=f"atomic_{batch}"):
                self.store.append_put(e)
            self.store.flush()

        self.store.compact()

        # Simulate a bad primary manifest after compaction; backup should recover.
        with open(self.store.manifest_path, "w", encoding="utf-8") as f:
            f.write("{corrupt")

        loaded = self._new_store().load()
        # Atomic manifest recovery should not crash or return partial JSON state.
        # Depending on whether .bak captured the pre- or post-compact manifest,
        # data may or may not be visible here, but load() must succeed cleanly.
        self.assertIsInstance(loaded, list)


# ===================================================================
# Migration-style crash boundaries (simulated at file level)
# ===================================================================

class TestMigrationCrashAfterSegmentsWritten(CrashBoundaryTestBase):
    def test_restart_cleanly_with_orphan_segments(self):
        """Orphan segment files on disk with corrupt manifest → P2 Fix 4
        recovers them via segment scanning. Data is now visible."""
        entries = _make_entries(5, prefix="mig_orphan")
        fname = _segment_filename(1, len(entries))
        SegmentWriter.write_segment(os.path.join(self.seg_dir, fname), entries)

        # Corrupt both manifest and backup so segment scan recovery triggers.
        # (v3.1.16+: Manifest.__init__ eagerly writes an empty manifest, so
        # we need to corrupt it to trigger the recovery-from-segments path.)
        manifest_path = os.path.join(self.seg_dir, "manifest.json")
        bak_path = os.path.join(self.seg_dir, "manifest.json.bak")
        for p in (manifest_path, bak_path):
            if os.path.exists(p):
                with open(p, "w") as f:
                    f.write("{corrupt!")

        loaded = self._new_store().load()
        # P2 Fix 4: segment scanning recovers orphan segments
        self.assertEqual(len(loaded), 5)
        self.assertEqual({e.hash for e in loaded}, {e.hash for e in entries})


class TestMigrationCrashAfterManifest(CrashBoundaryTestBase):
    def test_shards_still_exist_segments_load_fine(self):
        entries = _make_entries(5, prefix="mig_manifest")
        for e in entries:
            self.store.append_put(e)
        self.store.flush()

        shards_dir = os.path.join(self.tmp, "shards")
        os.makedirs(shards_dir, exist_ok=True)
        with open(os.path.join(shards_dir, "shard_0.json"), "w", encoding="utf-8") as f:
            json.dump([], f)

        loaded = self._new_store().load()
        self.assertEqual(len(loaded), 5)
        self.assertEqual({e.hash for e in loaded}, {e.hash for e in entries})


# ===================================================================
# Tombstone lifecycle
# ===================================================================

class TestTombstoneLifecycle(CrashBoundaryTestBase):
    def test_forget_hot_delete_tombstone_excluded_from_load(self):
        entries = _make_entries(5, prefix="forget")
        for e in entries:
            self.store.append_put(e)
        self.store.flush()

        target = entries[0]
        self.store.forget_hashes({target.hash}, reason="user request")

        loaded = self.store.load()
        self.assertNotIn(target.hash, {e.hash for e in loaded})

        manifest = self._manifest()
        self.assertIn(target.hash, manifest.get("tombstones", {}))

    def test_forget_flush_compact_permanently_gone(self):
        target = None
        for batch in range(4):
            es = _make_entries(3, prefix=f"compact_del_{batch}")
            if batch == 0:
                target = es[0]
            for e in es:
                self.store.append_put(e)
            self.store.flush()

        self.store.forget_hashes({target.hash}, reason="permanent delete")
        self.store.flush()
        result = self.store.compact()

        self.assertGreaterEqual(result["tombstones_resolved"], 1)
        loaded = self.store.load()
        self.assertNotIn(target.hash, {e.hash for e in loaded})

    def test_forget_readd_same_hash_visible_after_fix(self):
        e = _make_entry("will be recycled")
        self.store.append_put(e)
        self.store.flush()

        self.store.forget_hashes({e.hash}, reason="temporary removal")
        e2 = _make_entry("will be recycled")
        self.assertEqual(e2.hash, e.hash)
        self.store.append_put(e2)

        loaded = self.store.load()
        self.assertIn(e.hash, {entry.hash for entry in loaded})


# ===================================================================
# Hot buffer overflow
# ===================================================================

class TestHotBufferOverflow(CrashBoundaryTestBase):
    def test_large_hot_buffer_still_functions(self):
        entries = _make_entries(500, prefix="overflow")
        for e in entries:
            self.store.append_put(e)

        self.assertTrue(self.store.should_flush())
        loaded = self.store.load()
        self.assertEqual(len(loaded), 500)


# ===================================================================
# Recovery
# ===================================================================

class TestRecoveryEdgeCases(CrashBoundaryTestBase):
    def test_both_manifest_and_backup_corrupt_recovers_from_segments(self):
        """P2 Fix 4: When both manifest files are corrupt, segment files on
        disk are scanned and a manifest is reconstructed.  Data is now
        recovered instead of silently lost."""
        entries = _make_entries(5, prefix="corrupt")
        for e in entries:
            self.store.append_put(e)
        self.store.flush()

        with open(self.store.manifest_path, "w", encoding="utf-8") as f:
            f.write("NOT JSON")
        with open(self.store.manifest_path + ".bak", "w", encoding="utf-8") as f:
            f.write("ALSO NOT JSON")

        loaded = self._new_store().load()
        # P2 Fix 4: data is now recovered via segment scanning
        self.assertEqual(len(loaded), 5)
        self.assertEqual({e.hash for e in loaded}, {e.hash for e in entries})

    def test_hot_rotating_exists_on_startup_replayed_and_cleaned_up(self):
        e = _make_entry("rotating cleanup")
        with open(self.store.rotating_path, "w", encoding="utf-8") as f:
            f.write(json.dumps({
                "op": "put",
                "hash": e.hash,
                "entry": e.to_dict(),
                "ts": datetime.now(timezone.utc).isoformat(),
            }) + "\n")

        store2 = self._new_store()
        loaded = store2.load()
        self.assertEqual(len(loaded), 1)
        self.assertEqual(loaded[0].hash, e.hash)
        self.assertFalse(os.path.exists(store2.rotating_path))


# ===================================================================
# Extra regression coverage for the two fixes
# ===================================================================

class TestReAddRegression(CrashBoundaryTestBase):
    def test_delete_then_readd_visible_after_restart(self):
        e = _make_entry("restart recycle")
        self.store.append_put(e)
        self.store.flush()
        self.store.append_delete(e.hash, reason="temp")
        self.store.append_put(_make_entry("restart recycle"))

        loaded = self._new_store().load()
        self.assertIn(e.hash, {x.hash for x in loaded})

    def test_manifest_tombstone_does_not_override_later_hot_put(self):
        e = _make_entry("manual tombstone")
        self.store.append_put(e)
        self.store.flush()

        manifest = self._manifest()
        manifest.setdefault("tombstones", {})[e.hash] = {
            "deleted_at": datetime.now(timezone.utc).isoformat(),
            "reason": "manual",
        }
        manifest["generation"] = manifest.get("generation", 0) + 1
        _write_json(self.store.manifest_path, manifest)

        self.store.append_put(e)
        loaded = self.store.load()
        self.assertIn(e.hash, {x.hash for x in loaded})


if __name__ == "__main__":
    unittest.main()
