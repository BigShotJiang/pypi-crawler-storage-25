from __future__ import annotations

import io
import json
import os
import shutil
import tempfile
import unittest
from contextlib import redirect_stderr, redirect_stdout
from types import SimpleNamespace

from parsica_memory.cli import (
    cmd_doctor,
    cmd_repair_manifest,
    cmd_snapshot_create,
    cmd_snapshot_restore,
    cmd_snapshot_verify,
    cmd_validate,
)
from parsica_memory.entry import MemoryEntry
from parsica_memory.storage.segment_store import SegmentStore


class CLIStorageTestCase(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.mkdtemp()
        self.workspace = os.path.join(self.tmp, "workspace")
        self.snapshots = os.path.join(self.tmp, "snapshots")
        os.makedirs(self.workspace, exist_ok=True)
        os.makedirs(self.snapshots, exist_ok=True)
        self.store = SegmentStore(self.workspace, hot_max_ops=100, hot_min_ops=1)
        self.segment_dir = os.path.join(self.workspace, "segments")
        self.manifest_path = os.path.join(self.segment_dir, "manifest.json")

    def tearDown(self) -> None:
        shutil.rmtree(self.tmp, ignore_errors=True)

    def _entry(self, content: str) -> MemoryEntry:
        return MemoryEntry(
            content=content,
            source="unit_test",
            category="general",
            memory_type="episodic",
        )

    def _capture(self, func, args):
        stdout = io.StringIO()
        stderr = io.StringIO()
        with redirect_stdout(stdout), redirect_stderr(stderr):
            code = func(args)
        return code, stdout.getvalue(), stderr.getvalue()

    def test_cli_validate_clean_store(self):
        args = SimpleNamespace(workspace=self.workspace, json=False)
        code, stdout, stderr = self._capture(cmd_validate, args)
        self.assertEqual(code, 0)
        self.assertEqual(stdout, "")
        self.assertIn("Validation report", stderr)
        self.assertIn("Status                 : clean", stderr)

        json_args = SimpleNamespace(workspace=self.workspace, json=True)
        code, stdout, stderr = self._capture(cmd_validate, json_args)
        self.assertEqual(code, 0)
        self.assertEqual(stderr, "")
        payload = json.loads(stdout)
        self.assertTrue(payload["ok"])
        self.assertEqual(payload["workspace"], os.path.abspath(self.workspace))

    def test_cli_validate_broken_store_exit_code(self):
        os.unlink(self.manifest_path)
        args = SimpleNamespace(workspace=self.workspace, json=False)
        code, stdout, stderr = self._capture(cmd_validate, args)
        self.assertEqual(code, 1)
        self.assertEqual(stdout, "")
        self.assertIn("issues found", stderr)
        self.assertIn("missing_manifest", stderr)

    def test_cli_doctor_clean_store_exit_zero(self):
        """A completely clean store with no issues must return exit code 0."""
        args = SimpleNamespace(workspace=self.workspace, dry_run=True, json=False)
        code, stdout, stderr = self._capture(cmd_doctor, args)
        self.assertEqual(code, 0, f"Expected exit 0 for clean store, got {code}. stderr={stderr!r}")
        self.assertEqual(stdout, "")
        self.assertIn("Doctor report", stderr)
        self.assertIn("Status                 : clean", stderr)

        # JSON output should also reflect ok=True
        json_args = SimpleNamespace(workspace=self.workspace, dry_run=True, json=True)
        code, stdout, stderr = self._capture(cmd_doctor, json_args)
        self.assertEqual(code, 0)
        self.assertEqual(stderr, "")
        payload = json.loads(stdout)
        self.assertTrue(payload["ok"])

    def test_cli_doctor_dry_run(self):
        orphan = os.path.join(self.segment_dir, "seg_9999_fake_1.jsonl")
        with open(orphan, "w", encoding="utf-8") as handle:
            handle.write('{"x":1}\n')

        # An orphan file is a warning-level issue (not an error).
        # doctor exits 0 unless there are actual errors — warnings do not
        # cause a non-zero exit.  The repair plan should still list the action.
        args = SimpleNamespace(workspace=self.workspace, dry_run=True, json=False)
        code, stdout, stderr = self._capture(cmd_doctor, args)
        self.assertEqual(code, 0)
        self.assertEqual(stdout, "")
        self.assertIn("Doctor report", stderr)
        self.assertIn("quarantine_orphans", stderr)
        self.assertTrue(os.path.exists(orphan))

        json_args = SimpleNamespace(workspace=self.workspace, dry_run=True, json=True)
        code, stdout, stderr = self._capture(cmd_doctor, json_args)
        self.assertEqual(code, 0)
        self.assertEqual(stderr, "")
        payload = json.loads(stdout)
        self.assertTrue(payload["ok"])
        self.assertTrue(any(action["action_type"] == "quarantine_orphans" for action in payload["actions"]))

    def test_cli_doctor_errors_cause_exit_one(self):
        """Error-level issues (e.g. missing manifest) must cause doctor to exit 1."""
        os.unlink(self.manifest_path)
        args = SimpleNamespace(workspace=self.workspace, dry_run=True, json=False)
        code, stdout, stderr = self._capture(cmd_doctor, args)
        self.assertEqual(code, 1)

        json_args = SimpleNamespace(workspace=self.workspace, dry_run=True, json=True)
        code, stdout, stderr = self._capture(cmd_doctor, json_args)
        self.assertEqual(code, 1)
        payload = json.loads(stdout)
        self.assertFalse(payload["ok"])

    def test_cli_snapshot_create_verify_restore_roundtrip(self):
        self.store.append_put(self._entry("persist me"))
        self.store.flush()

        create_args = SimpleNamespace(workspace=self.workspace, output=self.snapshots, json=False)
        code, stdout, stderr = self._capture(cmd_snapshot_create, create_args)
        self.assertEqual(code, 0)
        self.assertEqual(stdout, "")
        self.assertIn("Snapshot created", stderr)

        snapshot_dirs = [
            os.path.join(self.snapshots, name)
            for name in os.listdir(self.snapshots)
            if os.path.isdir(os.path.join(self.snapshots, name))
        ]
        self.assertEqual(len(snapshot_dirs), 1)
        snapshot_path = snapshot_dirs[0]

        verify_args = SimpleNamespace(path=snapshot_path, json=True)
        code, stdout, stderr = self._capture(cmd_snapshot_verify, verify_args)
        self.assertEqual(code, 0)
        self.assertEqual(stderr, "")
        verify_payload = json.loads(stdout)
        self.assertTrue(verify_payload["ok"])

        restored_workspace = os.path.join(self.tmp, "restored")
        restore_args = SimpleNamespace(
            path=snapshot_path,
            workspace=restored_workspace,
            allow_non_empty=False,
            json=True,
        )
        code, stdout, stderr = self._capture(cmd_snapshot_restore, restore_args)
        self.assertEqual(code, 0)
        self.assertEqual(stderr, "")
        restore_payload = json.loads(stdout)
        self.assertTrue(restore_payload["ok"])
        self.assertTrue(os.path.exists(os.path.join(restored_workspace, "segments", "manifest.json")))

        restored_store = SegmentStore(restored_workspace)
        loaded = restored_store.load()
        self.assertEqual([entry.content for entry in loaded], ["persist me"])

    def test_cli_repair_manifest(self):
        self.store.append_put(self._entry("repair me"))
        self.store.flush()
        os.unlink(self.manifest_path)

        args = SimpleNamespace(workspace=self.workspace, dry_run=True, json=True)
        code, stdout, stderr = self._capture(cmd_repair_manifest, args)
        self.assertEqual(code, 0)
        self.assertEqual(stderr, "")
        payload = json.loads(stdout)
        self.assertFalse(payload["changed"])
        self.assertIn("rebuilt_manifest", payload["details"])
        self.assertFalse(os.path.exists(self.manifest_path))

        apply_args = SimpleNamespace(workspace=self.workspace, dry_run=False, json=False)
        code, stdout, stderr = self._capture(cmd_repair_manifest, apply_args)
        self.assertEqual(code, 0)
        self.assertEqual(stdout, "")
        self.assertIn("Repair manifest", stderr)
        self.assertTrue(os.path.exists(self.manifest_path))

        repaired_store = SegmentStore(self.workspace)
        loaded = repaired_store.load()
        self.assertEqual([entry.content for entry in loaded], ["repair me"])


if __name__ == "__main__":
    unittest.main()
