from __future__ import annotations

import hashlib
import logging
import re
import unicodedata
from datetime import datetime, timedelta, timezone
from typing import Iterable, Optional

logger = logging.getLogger(__name__)


class DedupEngine:
    """Conservative duplicate detector for recent memories.

    Strategy:
    1. Exact content hash match => duplicate
    2. Normalized content hash match => duplicate
    3. Jaccard similarity > threshold => duplicate, unless guardrails block it
    4. Jaccard in review band => not duplicate (caller may tag as possibly_duplicate)
    5. Below review band => not duplicate

    Notes:
    - This engine only *returns* the canonical duplicate hash or ``None``.
    - Review-band matches are exposed through ``last_result`` for callers that
      want to tag new memories as ``possibly_duplicate`` without suppressing
      storage.

    Dedup scope:
        This engine operates at the **content-block level**, not the individual
        line level. When ``MemorySystemV4.ingest()`` receives multi-line content,
        ``is_duplicate()`` is called once on the full content string *before*
        line splitting. This means:

        - A single duplicate line inside a multi-line block is NOT caught by
          this engine (per-line hash dedup in ``ingest()`` handles exact line
          duplicates separately).
        - The same content ingested as a single line vs. inside a multi-line
          batch may produce different dedup behavior.
        - This is a deliberate design choice for v1: content-block dedup catches
          bulk re-ingestion (e.g. re-processing the same conversation), while
          per-line hash dedup in ``ingest()`` catches individual line duplicates.
    """

    STOPWORDS = {
        "the", "a", "an", "is", "was", "are", "were", "in", "on", "at",
        "to", "for", "of", "and", "or", "but", "with", "this", "that",
        # NOTE: "not" intentionally excluded — it carries semantic weight
        # critical for negation detection (e.g. "service is working" vs
        # "service is not working"). Negation is also guarded by
        # _has_critical_difference(), but keeping "not" in tokens provides
        # defense-in-depth for Jaccard similarity scoring.
    }

    NEGATION_PATTERNS = (
        r"\bnot\b",
        r"\bno\b",
        r"\bnever\b",
        r"\bnone\b",
        r"\bwithout\b",
        r"\bcan't\b",
        r"\bcannot\b",
        r"\bwon't\b",
        r"\bdoesn't\b",
        r"\bdon't\b",
        r"\bdidn't\b",
        r"\bisn't\b",
        r"\baren't\b",
        r"\bwasn't\b",
        r"\bweren't\b",
        r"\bhasn't\b",
        r"\bhaven't\b",
        r"\bhadn't\b",
        r"\bshouldn't\b",
        r"\bwouldn't\b",
        r"\bcouldn't\b",
    )

    # P0 fix: Match capitalized words but filter out common sentence-start
    # words in _extract_proper_nouns(). The regex itself matches any Title-case
    # word; the filter list removes false positives like "The", "This", "After".
    PROPER_NOUN_RE = re.compile(r"\b[A-Z][a-z]+(?:\s[A-Z][a-z]+)*\b")
    # Common words that appear capitalized at sentence start but are NOT proper nouns.
    _COMMON_CAPITALIZED: frozenset = frozenset({
        "The", "This", "That", "These", "Those", "There", "Their", "Then",
        "They", "After", "Before", "During", "While", "When", "Where",
        "What", "Which", "Who", "How", "But", "And", "For", "Not", "All",
        "Any", "Each", "Every", "Some", "Most", "Many", "Much", "Such",
        "Very", "Also", "Just", "Only", "Even", "Still", "Already",
        "Here", "Now", "Our", "His", "Her", "Its", "Your", "One", "Two",
        "First", "Last", "New", "Old", "Other", "More", "Less", "Well",
        "However", "Although", "Because", "Since", "Until", "Unless",
        "Once", "Both", "Either", "Neither", "Several", "Few",
    })
    TOKEN_RE = re.compile(r"[a-z0-9]+(?:\.[a-z0-9]+)*", re.IGNORECASE)
    # Match version strings like v1.0.0, 3.3.3, 2026-03-31, etc.
    # The v? prefix is optional to catch both "v1.0.0" and "1.0.0"
    NUMBER_RE = re.compile(r"(?:^|(?<=\s)|(?<=v))(\d+(?:[.:/-]\d+)*(?:[a-z]+)?)\b", re.IGNORECASE)
    TIMESTAMP_PATTERNS = (
        re.compile(r"\b\d{4}-\d{2}-\d{2}[ t]\d{2}:\d{2}(?::\d{2})?(?:z|[+-]\d{2}:?\d{2})?\b", re.IGNORECASE),
        re.compile(r"\b\d{4}-\d{2}-\d{2}\b"),
        re.compile(r"\b\d{1,2}/\d{1,2}/\d{2,4}\b"),
        re.compile(r"\b\d{1,2}:\d{2}(?::\d{2})?\s*(?:am|pm|utc|pst|pdt|est|edt|cst|cdt|mst|mdt)?\b", re.IGNORECASE),
    )

    def __init__(
        self,
        window_hours: int = 24,
        jaccard_threshold: float = 0.85,
        review_threshold: float = 0.70,
    ) -> None:
        self.window_hours = window_hours
        self.jaccard_threshold = jaccard_threshold
        self.review_threshold = review_threshold
        #: Detailed result of the last ``is_duplicate()`` call.
        #:
        #: .. warning:: Thread safety
        #:    ``last_result`` is mutable instance state overwritten on every
        #:    ``is_duplicate()`` call. It is only valid **synchronously
        #:    immediately after** the call returns. In concurrent or async
        #:    contexts, a second call may overwrite it before the first
        #:    caller reads it. For thread-safe access, capture the return
        #:    value of ``is_duplicate()`` and inspect ``last_result``
        #:    immediately, or use external synchronization.
        self.last_result: dict[str, object] = {
            "status": "unique",
            "match_hash": None,
            "similarity": 0.0,
        }

    def is_duplicate(
        self,
        content: str,
        existing_memories: Iterable[object],
        window_hours: Optional[int] = None,
    ) -> Optional[str]:
        """Return duplicate hash if found, otherwise ``None``.

        The comparison window is limited to recent memories only. Exact and
        normalized hash matches always deduplicate. Fuzzy dedup is guarded by
        numeric/version, negation, and proper-noun checks.

        Args:
            content: The content string to check for duplicates.
            existing_memories: Iterable of memory objects to compare against.
            window_hours: Time window in hours. ``None`` (default) uses the
                instance-level ``self.window_hours`` set at construction time.
                Pass an explicit int to override for a single call.

        Note:
            The ``possibly_duplicate`` status (Jaccard in the review band
            0.70–0.85) is informational only — it is exposed via
            ``self.last_result`` for callers that want to tag or log
            near-duplicates, but this method still returns ``None`` for
            review-band matches (i.e. they are NOT suppressed).
        """
        self.last_result = {
            "status": "unique",
            "match_hash": None,
            "similarity": 0.0,
        }

        if not isinstance(content, str) or not content.strip():
            return None

        effective_window = self.window_hours if window_hours is None else window_hours
        recent_memories = list(self._filter_recent(existing_memories, effective_window))
        if not recent_memories:
            return None

        content_hash = self._hash(content)
        normalized = self._normalize(content)
        normalized_hash = self._hash(normalized) if normalized else None
        content_tokens = self._tokenize(content)

        best_review_hash: Optional[str] = None
        best_review_score = 0.0

        for memory in recent_memories:
            memory_content = self._get_content(memory)
            if not memory_content.strip():
                continue

            # P0 fix: Compare content hashes directly instead of using
            # memory.hash (which is md5(source:line:content), NOT content-only).
            # This ensures exact-content duplicates are caught regardless of
            # differing source/line metadata.
            memory_content_hash = self._hash(memory_content)
            # Canonical hash for return value — use the memory's own hash
            # (source:line:content) as the dedup identifier so callers can
            # look up the original entry.
            memory_id_hash = self._get_hash(memory, memory_content)
            if memory_content_hash == content_hash:
                self.last_result = {
                    "status": "duplicate_exact",
                    "match_hash": memory_id_hash,
                    "similarity": 1.0,
                }
                return memory_id_hash

            memory_normalized = self._normalize(memory_content)
            memory_normalized_hash = self._hash(memory_normalized) if memory_normalized else None
            if normalized_hash and memory_normalized_hash == normalized_hash:
                self.last_result = {
                    "status": "duplicate_normalized",
                    "match_hash": memory_id_hash,
                    "similarity": 1.0,
                }
                return memory_id_hash

            if self._has_critical_difference(content, memory_content):
                continue

            memory_tokens = self._tokenize(memory_content)
            similarity = self._jaccard_similarity(content_tokens, memory_tokens)
            if similarity > self.jaccard_threshold:
                logger.info(
                    "DedupEngine fuzzy duplicate detected: similarity=%.3f existing=%s",
                    similarity,
                    memory_id_hash,
                )
                self.last_result = {
                    "status": "duplicate_fuzzy",
                    "match_hash": memory_id_hash,
                    "similarity": similarity,
                }
                return memory_id_hash

            if self.review_threshold <= similarity <= self.jaccard_threshold and similarity > best_review_score:
                best_review_hash = memory_id_hash
                best_review_score = similarity

        if best_review_hash is not None:
            self.last_result = {
                "status": "possibly_duplicate",
                "match_hash": best_review_hash,
                "similarity": best_review_score,
            }
        return None

    def _normalize(self, text: str) -> str:
        """Normalize text for conservative duplicate matching."""
        if not isinstance(text, str):
            return ""
        normalized = unicodedata.normalize("NFKC", text)
        for pattern in self.TIMESTAMP_PATTERNS:
            normalized = pattern.sub(" ", normalized)
        normalized = normalized.lower()
        normalized = re.sub(r"\s+", " ", normalized).strip()
        return normalized

    def _tokenize(self, text: str) -> set[str]:
        """Tokenize to lowercase terms with a small hardcoded stopword list."""
        if not isinstance(text, str):
            return set()
        tokens = {
            match.group(0).lower()
            for match in self.TOKEN_RE.finditer(self._normalize(text))
        }
        return {token for token in tokens if token and token not in self.STOPWORDS}

    def _jaccard_similarity(self, tokens_a: set[str], tokens_b: set[str]) -> float:
        """Return token-set Jaccard coefficient."""
        if not tokens_a or not tokens_b:
            return 0.0
        union = tokens_a | tokens_b
        if not union:
            return 0.0
        return len(tokens_a & tokens_b) / len(union)

    def _has_critical_difference(self, a: str, b: str) -> bool:
        """Return True when content differs in ways that should block dedup."""
        if self._extract_numbers(a) != self._extract_numbers(b):
            return True
        if self._extract_negations(a) != self._extract_negations(b):
            return True
        if self._extract_proper_nouns(a) != self._extract_proper_nouns(b):
            return True
        return False

    def _filter_recent(self, existing_memories: Iterable[object], window_hours: int) -> Iterable[object]:
        cutoff = datetime.now(timezone.utc) - timedelta(hours=window_hours)
        for memory in existing_memories:
            created = self._get_created(memory)
            if created is None or created >= cutoff:
                yield memory

    def _get_content(self, memory: object) -> str:
        if isinstance(memory, dict):
            return str(memory.get("content", ""))
        return str(getattr(memory, "content", ""))

    def _get_hash(self, memory: object, fallback_content: str) -> str:
        if isinstance(memory, dict):
            value = memory.get("hash")
        else:
            value = getattr(memory, "hash", None)
        if value:
            return str(value)
        return self._hash(fallback_content)

    def _get_created(self, memory: object) -> Optional[datetime]:
        raw = memory.get("created") if isinstance(memory, dict) else getattr(memory, "created", None)
        if not raw:
            return None
        if isinstance(raw, datetime):
            dt = raw
        else:
            try:
                dt = datetime.fromisoformat(str(raw).replace("Z", "+00:00"))
            except ValueError:
                return None
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)

    def _hash(self, text: str) -> str:
        return hashlib.md5(text.encode("utf-8")).hexdigest()[:12]

    def _extract_numbers(self, text: str) -> tuple[str, ...]:
        return tuple(self.NUMBER_RE.findall(unicodedata.normalize("NFKC", text or "")))

    def _extract_negations(self, text: str) -> tuple[str, ...]:
        lowered = unicodedata.normalize("NFKC", text or "").lower()
        found: list[str] = []
        for pattern in self.NEGATION_PATTERNS:
            if re.search(pattern, lowered):
                found.append(pattern)
        return tuple(found)

    def _extract_proper_nouns(self, text: str) -> tuple[str, ...]:
        # P0 fix: Filter out common English words that appear capitalized at
        # sentence start (e.g. "The", "This", "After") to avoid false positives
        # in _has_critical_difference(). Real proper nouns like "Alice", "Bob",
        # "Kubernetes" pass through.
        found = [
            match.group(0)
            for match in self.PROPER_NOUN_RE.finditer(text or "")
            if match.group(0) not in self._COMMON_CAPITALIZED
        ]
        return tuple(found)
