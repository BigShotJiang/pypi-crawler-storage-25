"""Schemas for the embeddings endpoint."""

from pydantic import BaseModel, Field


class EmbeddingRequest(BaseModel):
    """OpenAI-compatible embedding request."""

    input: str | list[str] = Field(..., description="Text or list of texts to embed")
    model: str = Field(default="text2vec-transformers", description="Embedding model name")


class EmbeddingData(BaseModel):
    """A single embedding result."""

    object: str = "embedding"
    embedding: list[float]
    index: int


class EmbeddingUsage(BaseModel):
    """Token usage for the embedding request."""

    prompt_tokens: int = 0
    total_tokens: int = 0


class EmbeddingResponse(BaseModel):
    """OpenAI-compatible embedding response."""

    object: str = "list"
    data: list[EmbeddingData]
    model: str
    usage: EmbeddingUsage = Field(default_factory=EmbeddingUsage)
