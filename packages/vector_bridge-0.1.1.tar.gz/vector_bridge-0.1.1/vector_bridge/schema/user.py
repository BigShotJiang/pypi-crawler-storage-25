from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field
from vector_bridge.schema.security_group import SecurityGroup


class User(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    created_at: datetime
    organization_id: str | None = None

    @property
    def has_organization(self) -> bool:
        return self.organization_id is not None


class UserWithSecurityGroup(User):
    model_config = ConfigDict(from_attributes=True)

    security_group: SecurityGroup | None = Field(default=None)


class UsersList(BaseModel):
    users: list[User]
    limit: int
    last_evaluated_key: str | None
    has_more: bool = Field(default=False)
