class BaseError(Exception):
    """Base class for general errors."""


def raise_for_base_error_detail(detail: str) -> None:
    """
    Raises a BaseError with the given detail string.
    """
    raise BaseError(detail)
