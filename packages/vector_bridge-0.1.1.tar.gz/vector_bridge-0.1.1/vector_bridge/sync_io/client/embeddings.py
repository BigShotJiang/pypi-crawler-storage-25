"""Synchronous embeddings client."""

from vector_bridge import VectorBridgeClient
from vector_bridge.schema.embeddings import EmbeddingResponse
from vector_bridge.schema.errors.base import raise_for_base_error_detail


class EmbeddingsClient:
    """Synchronous client for the embeddings endpoint."""

    def __init__(self, client: VectorBridgeClient):
        self.client = client

    def create(
        self,
        input: str | list[str],
        model: str = "text2vec-transformers",
    ) -> EmbeddingResponse:
        """
        Generate embeddings for the given input text(s).

        Args:
            input: A single text string or list of texts to embed.
            model: Embedding model name (default: text2vec-transformers).

        Returns:
            EmbeddingResponse with embedding vectors in OpenAI-compatible format.
        """
        url = f"{self.client.base_url}/v1/embeddings"
        headers = self.client._get_auth_headers()
        payload = {"input": input, "model": model}

        response = self.client.session.post(url, headers=headers, json=payload)
        result = self.client._handle_response(response=response, error_callable=raise_for_base_error_detail)
        return EmbeddingResponse(**result)
