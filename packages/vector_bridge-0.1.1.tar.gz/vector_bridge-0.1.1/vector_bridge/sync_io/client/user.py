from typing import Any

from vector_bridge import VectorBridgeClient
from vector_bridge.schema.errors.user import raise_for_user_detail
from vector_bridge.schema.user import User, UsersList
from vector_bridge.schema.user_integrations import UserWithIntegrationsAndPermissions


class UserClient:
    """Client for user management endpoints."""

    def __init__(self, client: VectorBridgeClient):
        self.client = client

    def get_me(self) -> UserWithIntegrationsAndPermissions:
        """
        Retrieve information about the currently authenticated user.

        Returns:
            User information including integrations
        """
        url = f"{self.client.base_url}/v1/user/me"
        headers = self.client._get_auth_headers()
        response = self.client.session.get(url, headers=headers)
        data = self.client._handle_response(response=response, error_callable=raise_for_user_detail)
        return UserWithIntegrationsAndPermissions.model_validate(data)

    def get_users_in_my_organization(self, limit: int = 25, last_evaluated_key: str | None = None) -> UsersList:
        """
        Retrieve information about the users of the authenticated user's organization.

        Args:
            limit: Number of users to return
            last_evaluated_key: Last evaluated key for pagination

        Returns:
            UsersList with users and pagination information
        """
        url = f"{self.client.base_url}/v1/users/my-organization"
        params: dict[str, Any] = {"limit": limit}
        if last_evaluated_key:
            params["last_evaluated_key"] = last_evaluated_key

        headers = self.client._get_auth_headers()
        response = self.client.session.get(url, headers=headers, params=params)
        result = self.client._handle_response(response=response, error_callable=raise_for_user_detail)
        return UsersList.model_validate(result)

    def remove_user(self, user_id: str) -> None:
        """
        Remove a user from the organization.

        Args:
            user_id: The user to be removed
        """
        url = f"{self.client.base_url}/v1/user/remove/{user_id}"
        headers = self.client._get_auth_headers()
        response = self.client.session.post(url, headers=headers)
        self.client._handle_response(response=response, error_callable=raise_for_user_detail)

    def get_user_by_id(self, user_id: str) -> User | None:
        """
        Retrieve user information based on their unique user ID.

        Args:
            user_id: The unique identifier of the user

        Returns:
            User information or None if not found
        """
        url = f"{self.client.base_url}/v1/user/id/{user_id}"
        headers = self.client._get_auth_headers()
        response = self.client.session.get(url, headers=headers)
        data = self.client._handle_response(response=response, error_callable=raise_for_user_detail)
        return User.model_validate(data) if data else None

    def get_users_by_ids(self, user_ids: list[str]) -> list[User]:
        """
        Retrieve user information for multiple users based on their IDs.

        Args:
            user_ids: List of unique identifiers of the users

        Returns:
            List of user information
        """
        url = f"{self.client.base_url}/v1/users/ids"
        headers = self.client._get_auth_headers()
        params = {"user_ids": user_ids}
        response = self.client.session.get(url, headers=headers, params=params)
        data = self.client._handle_response(response=response, error_callable=raise_for_user_detail)
        return [User.model_validate(user) for user in data]
