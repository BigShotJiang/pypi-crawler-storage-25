"""Asynchronous embeddings client."""

from vector_bridge import AsyncVectorBridgeClient
from vector_bridge.schema.embeddings import EmbeddingResponse
from vector_bridge.schema.errors.base import raise_for_base_error_detail


class AsyncEmbeddingsClient:
    """Async client for the embeddings endpoint."""

    def __init__(self, client: AsyncVectorBridgeClient):
        self.client = client

    async def create(
        self,
        input: str | list[str],
        model: str = "text2vec-transformers",
    ) -> EmbeddingResponse:
        """
        Generate embeddings for the given input text(s).

        Args:
            input: A single text string or list of texts to embed.
            model: Embedding model name (default: text2vec-transformers).

        Returns:
            EmbeddingResponse with embedding vectors in OpenAI-compatible format.
        """
        await self.client._ensure_session()

        url = f"{self.client.base_url}/v1/embeddings"
        headers = self.client._get_auth_headers()
        payload = {"input": input, "model": model}

        async with self.client.session.post(url, headers=headers, json=payload) as response:
            result = await self.client._handle_response(response=response, error_callable=raise_for_base_error_detail)
            return EmbeddingResponse(**result)
