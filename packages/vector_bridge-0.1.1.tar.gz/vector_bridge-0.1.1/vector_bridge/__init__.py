from collections.abc import Callable
from typing import Any
from urllib.parse import urlparse

import aiohttp
import requests
from vector_bridge.schema.errors.base import raise_for_base_error_detail


class BaseVectorBridgeClient:
    """Base class for VectorBridge clients with common functionality."""

    def __init__(
        self,
        base_url: str = "http://vector_bridge:8000/",
        api_key: str | None = None,
        access_token: str | None = None,
        integration_name: str = "default",
    ):
        self.base_url = base_url.rstrip("/")
        self.access_token = access_token
        self.api_key = api_key
        self.integration_name = integration_name

        self._parsed_url = urlparse(self.base_url)

    @property
    def host(self) -> str:
        return self._parsed_url.hostname or "localhost"

    @property
    def redis_url(self) -> str:
        return f"redis://{self.host}:6379"

    def set_access_token(self, token: str) -> None:
        """Set the JWT access token for authentication."""
        self.access_token = token

    def _get_auth_headers(self) -> dict[str, str]:
        """Get headers with API key authentication and bearer token authentication."""
        api_key_headers = {}
        if self.api_key:
            api_key_headers["Api-Key"] = self.api_key
        if self.access_token:
            api_key_headers["Authorization"] = f"Bearer {self.access_token}"

        if not api_key_headers:
            raise ValueError("Authentication required. Call set_access_token() first or provide api_key.")
        return api_key_headers

    def _create_http_exception(self, status_code: int, error_data: Any, error_callable: Callable) -> Exception:
        """Create HTTPException from error response."""
        if isinstance(error_data, dict):
            detail = error_data.get("detail")
        else:
            detail = str(error_data)

        return error_callable(detail)


class VectorBridgeClient(BaseVectorBridgeClient):
    """
    Synchronous Python client for the VectorBridge.ai API.

    Provides access to all functionality of the VectorBridge platform including
    user management, AI processing, vector operations, and more.
    """

    def __init__(
        self,
        base_url: str = "http://vector_bridge:8000/",
        api_key: str | None = None,
        access_token: str | None = None,
        integration_name: str = "default",
    ):
        """
        Initialize the VectorBridge client.

        Args:
            base_url: The base URL of the VectorBridge API.
            api_key: API key for authentication.
            access_token: JWT access token for authentication.
            integration_name: Name of the integration.
        """
        super().__init__(base_url, api_key, access_token, integration_name)

        from vector_bridge.sync_io.admin import AdminClient
        from vector_bridge.sync_io.client.ai_knowledge import AIKnowledge
        from vector_bridge.sync_io.client.api_keys import APIKeysClient
        from vector_bridge.sync_io.client.embeddings import EmbeddingsClient
        from vector_bridge.sync_io.client.history import HistoryClient
        from vector_bridge.sync_io.client.logs import LogsClient
        from vector_bridge.sync_io.client.query import QueryClient
        from vector_bridge.sync_io.client.usage import UsageClient
        from vector_bridge.sync_io.client.user import UserClient

        self.session = requests.Session()

        # Initialize client modules
        self.admin = AdminClient(self)
        self.api_keys = APIKeysClient(self)
        self.ai_knowledge = AIKnowledge(self)
        self.embeddings = EmbeddingsClient(self)
        self.history = HistoryClient(self)
        self.logs = LogsClient(self)
        self.queries = QueryClient(self)
        self.users = UserClient(self)
        self.usage = UsageClient(self)

    def _handle_response(self, response: requests.Response, error_callable: Callable) -> Any:
        """Handle API response and errors."""
        if 200 <= response.status_code < 300:
            if response.status_code == 204:
                return None
            try:
                return response.json()
            except ValueError:
                return response.text
        else:
            try:
                error_data = response.json()
            except ValueError:
                error_data = response.text

            exc = self._create_http_exception(response.status_code, error_data, error_callable)
            raise exc

    def ping(self) -> str:
        """
        Ping the API to check if it's available.

        Returns:
            Response string
        """
        url = f"{self.base_url}/v1/ping"
        response = self.session.get(url)
        return self._handle_response(response=response, error_callable=raise_for_base_error_detail)

    def stream_ping(self):
        """
        Stream ping the API to check if streaming is available.

        Returns:
            Streaming response
        """
        url = f"{self.base_url}/v1/stream/ping"
        response = self.session.get(url, stream=True)
        return response

    def generate_crypto_key(self) -> str:
        """
        Generate a crypto key.

        Returns:
            Generated crypto key
        """
        url = f"{self.base_url}/v1/secrets/generate-crypto-key"
        response = self.session.get(url)
        return self._handle_response(response=response, error_callable=raise_for_base_error_detail)

    def check_db_connection(self) -> dict:
        """
        Check database connection using the server's global Weaviate settings.

        Returns:
            Connection check response
        """
        url = f"{self.base_url}/v1/internal/check-db-connection"
        response = self.session.post(url)
        return self._handle_response(response=response, error_callable=raise_for_base_error_detail)

    def close(self):
        """Close the session."""
        self.session.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()


class AsyncVectorBridgeClient(BaseVectorBridgeClient):
    """
    Asynchronous Python client for the VectorBridge.ai API.

    Provides async access to all functionality of the VectorBridge platform including
    user management, AI processing, vector operations, and more.
    """

    def __init__(
        self,
        base_url: str = "http://vector_bridge:8000/",
        api_key: str | None = None,
        access_token: str | None = None,
        integration_name: str = "default",
        connector: aiohttp.BaseConnector | None = None,
        timeout: aiohttp.ClientTimeout | None = None,
    ):
        """
        Initialize the async VectorBridge client.

        Args:
            base_url: The base URL of the VectorBridge API.
            api_key: API key for authentication.
            access_token: JWT access token for authentication.
            integration_name: Name of the integration.
            connector: aiohttp connector for custom connection handling.
            timeout: Timeout configuration for requests.
        """
        super().__init__(base_url, api_key, access_token, integration_name)

        from vector_bridge.async_io.admin import AsyncAdminClient
        from vector_bridge.async_io.admin.api_keys import AsyncAPIKeys
        from vector_bridge.async_io.client.ai_knowledge import AsyncAIKnowledge
        from vector_bridge.async_io.client.embeddings import AsyncEmbeddingsClient
        from vector_bridge.async_io.client.history import AsyncHistoryClient
        from vector_bridge.async_io.client.logs import AsyncLogsClient
        from vector_bridge.async_io.client.query import AsyncQueryClient
        from vector_bridge.async_io.client.usage import AsyncUsageClient
        from vector_bridge.async_io.client.user import AsyncUserClient

        self.session = None
        self._connector = connector
        self._timeout = timeout or aiohttp.ClientTimeout(total=30)

        # Initialize async client modules
        self.admin = AsyncAdminClient(self)
        self.api_keys = AsyncAPIKeys(self)
        self.ai_knowledge = AsyncAIKnowledge(self)
        self.embeddings = AsyncEmbeddingsClient(self)
        self.history = AsyncHistoryClient(self)
        self.logs = AsyncLogsClient(self)
        self.queries = AsyncQueryClient(self)
        self.users = AsyncUserClient(self)
        self.usage = AsyncUsageClient(self)

    async def __aenter__(self):
        """Async context manager entry."""
        await self._ensure_session()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.close()

    async def _ensure_session(self):
        """Ensure aiohttp session is created."""
        if self.session is None:
            self.session = aiohttp.ClientSession(connector=self._connector, timeout=self._timeout)

    async def _handle_response(self, response: aiohttp.ClientResponse, error_callable: Callable) -> Any:
        """Handle async API response and errors."""
        if 200 <= response.status < 300:
            if response.status == 204:
                return None
            try:
                return await response.json()
            except (ValueError, aiohttp.ContentTypeError):
                return await response.text()
        else:
            try:
                error_data = await response.json()
            except (ValueError, aiohttp.ContentTypeError):
                error_data = await response.text()

            exc = self._create_http_exception(response.status, error_data, error_callable)
            raise exc

    async def ping(self) -> str:
        """
        Ping the API to check if it's available.

        Returns:
            Response string
        """
        await self._ensure_session()

        url = f"{self.base_url}/v1/ping"
        async with self.session.get(url) as response:
            return await self._handle_response(response=response, error_callable=raise_for_base_error_detail)

    async def stream_ping(self):
        """
        Stream ping the API to check if streaming is available.

        Returns:
            Streaming response
        """
        await self._ensure_session()

        url = f"{self.base_url}/v1/stream/ping"
        return await self.session.get(url)

    async def generate_crypto_key(self) -> str:
        """
        Generate a crypto key.

        Returns:
            Generated crypto key
        """
        await self._ensure_session()

        url = f"{self.base_url}/v1/secrets/generate-crypto-key"
        async with self.session.get(url) as response:
            return await self._handle_response(response=response, error_callable=raise_for_base_error_detail)

    async def check_db_connection(self) -> dict:
        """
        Check database connection using the server's global Weaviate settings.

        Returns:
            Connection check response
        """
        await self._ensure_session()

        url = f"{self.base_url}/v1/internal/check-db-connection"
        async with self.session.post(url) as response:
            return await self._handle_response(response=response, error_callable=raise_for_base_error_detail)

    async def close(self):
        """Close the async session."""
        if self.session and not self.session.closed:
            await self.session.close()
            self.session = None


# Factory function for easier client creation
def create_client(
    base_url: str = "http://vector_bridge:8000/",
    api_key: str | None = None,
    access_token: str | None = None,
    integration_name: str = "default",
    async_client: bool = False,
    **kwargs,
) -> VectorBridgeClient | AsyncVectorBridgeClient:
    """
    Factory function to create either sync or async VectorBridge client.

    Args:
        base_url: The base URL of the VectorBridge API.
        api_key: API key for authentication.
        access_token: JWT access token for authentication.
        integration_name: Name of the integration.
        async_client: If True, returns AsyncVectorBridgeClient, otherwise VectorBridgeClient.
        **kwargs: Additional arguments passed to the client constructor.

    Returns:
        VectorBridgeClient or AsyncVectorBridgeClient instance.
    """
    if async_client:
        return AsyncVectorBridgeClient(
            base_url=base_url,
            api_key=api_key,
            access_token=access_token,
            integration_name=integration_name,
            **kwargs,
        )
    else:
        return VectorBridgeClient(
            base_url=base_url,
            api_key=api_key,
            access_token=access_token,
            integration_name=integration_name,
        )
