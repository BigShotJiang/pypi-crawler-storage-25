#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #

import numpy as np
import matplotlib.pyplot as plt

from scipy.optimize import curve_fit, differential_evolution
from scipy.special import erfc
from scipy.stats import median_abs_deviation


# ============================================================
# 1) Core single-function model: Exponentially Modified Gaussian (EMG)
# ============================================================

def emg_peak(x, A, mu, sigma, tau, y0):
    """
    Exponentially Modified Gaussian + constant baseline.

    Parameters
    ----------
    x : array
    A : amplitude scale (>0)
    mu : center-like location
    sigma : Gaussian width (>0)
    tau : exponential tail scale
          tau > 0 -> right tail
          tau < 0 -> left tail
    y0 : constant baseline

    Returns
    -------
    y : array
    """
    x = np.asarray(x, dtype=float)

    # numerical safety
    sigma = np.clip(float(sigma), 1e-14, None)
    if np.abs(tau) < 1e-14:
        tau = np.sign(tau) * 1e-14 if tau != 0 else 1e-14

    # EMG formula
    z = (mu + (sigma**2)/tau - x) / (np.sqrt(2.0) * sigma)
    y = (A / (2.0 * np.abs(tau))) * np.exp((sigma**2)/(2.0*tau**2) - (x - mu)/tau) * erfc(z) + y0
    return y


# ============================================================
# 2) Optional variant: EMG + linear baseline
# ============================================================

def emg_peak_linear_bg(x, A, mu, sigma, tau, y0, m):
    """
    EMG + linear background: y0 + m*(x - mean(x))
    """
    xc = np.mean(x)
    return emg_peak(x, A, mu, sigma, tau, 0.0) + y0 + m * (x - xc)


# ============================================================
# 3) Optional two-sided asymmetric-tail "single function"
#    (weighted sum of right-tail and left-tail EMGs sharing one center/width)
# ============================================================

def emg_two_sided(x, A, mu, sigma, tau_r, tau_l, w, y0):
    """
    Two-sided asymmetric tail model (still one callable function):
      y = w * EMG(right tail, tau_r>0) + (1-w)*EMG(left tail, tau_l<0) + y0

    Params
    ------
    A      : total amplitude scale
    mu     : center
    sigma  : Gaussian width
    tau_r  : right-tail scale (>0 suggested)
    tau_l  : left-tail scale (<0 suggested)
    w      : weight in [0,1]
    y0     : baseline
    """
    w = np.clip(w, 0.0, 1.0)
    y_r = emg_peak(x, A*w, mu, sigma, np.abs(tau_r), 0.0)
    y_l = emg_peak(x, A*(1.0-w), mu, sigma, -np.abs(tau_l), 0.0)
    return y_r + y_l + y0


# ============================================================
# 4) Utilities: guesses, bounds, metrics
# ============================================================

def robust_sigma_from_peak(x, y, frac=0.5):
    """
    Estimate width from FWHM-like crossing if possible.
    """
    x = np.asarray(x); y = np.asarray(y)
    i0 = np.argmax(y)
    y0 = np.percentile(y, 5)
    yp = y - y0
    peak = yp[i0]
    if peak <= 0:
        return 0.05*(x.max()-x.min())

    half = frac * peak
    # left crossing
    left = np.where(yp[:i0] <= half)[0]
    right = np.where(yp[i0:] <= half)[0]

    if left.size > 0 and right.size > 0:
        xl = x[left[-1]]
        xr = x[i0 + right[0]]
        fwhm = max(xr - xl, 1e-12)
        sigma = fwhm / 2.355
    else:
        sigma = 0.05*(x.max()-x.min())

    return max(sigma, 1e-12)


def initial_guess_emg(x, y):
    x = np.asarray(x); y = np.asarray(y)
    y0 = np.percentile(y, 5)
    i0 = np.argmax(y)
    mu0 = x[i0]

    sigma0 = robust_sigma_from_peak(x, y)
    A0 = max((y.max() - y0) * max(np.abs(sigma0), 1e-6) * np.sqrt(2*np.pi), 1e-9)

    # crude skew estimate to choose tail sign
    # compare weighted spread on right vs left
    yp = np.clip(y - y0, 0, None)
    if yp.sum() > 0:
        mean = np.sum(x*yp)/np.sum(yp)
        m3 = np.sum(((x-mean)**3)*yp)/np.sum(yp)
        tail_sign = 1.0 if m3 >= 0 else -1.0
    else:
        tail_sign = 1.0

    tau0 = tail_sign * max(0.1*(x.max()-x.min()), sigma0)
    return np.array([A0, mu0, sigma0, tau0, y0], dtype=float)


def bounds_emg(x, y):
    xr = x.max() - x.min()
    yr = y.max() - y.min()
    # A, mu, sigma, tau, y0
    lb = np.array([0.0, x.min(), 1e-12, -20*xr, y.min()-2*max(1.0, abs(y.min()))], dtype=float)
    ub = np.array([100*max(yr, 1e-9)*max(xr,1e-9), x.max(), xr, 20*xr, y.max()+2*max(1.0, abs(y.max()))], dtype=float)
    return lb, ub


def fit_metrics(y, yhat, k):
    """
    Return common fit metrics.
    k: number of fitted parameters.
    """
    y = np.asarray(y); yhat = np.asarray(yhat)
    n = y.size
    r = y - yhat
    sse = np.sum(r**2)
    mse = sse / n
    rmse = np.sqrt(mse)

    tss = np.sum((y - np.mean(y))**2)
    r2 = 1.0 - sse/tss if tss > 0 else np.nan

    # AIC, BIC (Gaussian errors)
    # ignoring constants: n*ln(SSE/n)+2k ; n*ln(SSE/n)+k ln n
    sse_n = max(sse/n, 1e-300)
    aic = n*np.log(sse_n) + 2*k
    bic = n*np.log(sse_n) + k*np.log(n)

    return {
        "SSE": sse,
        "RMSE": rmse,
        "R2": r2,
        "AIC": aic,
        "BIC": bic
    }


# ============================================================
# 5) Fitters
# ============================================================

def fit_emg_curve_fit(x, y, p0=None, sigma_y=None, absolute_sigma=False, maxfev=50000):
    x = np.asarray(x); y = np.asarray(y)
    if p0 is None:
        p0 = initial_guess_emg(x, y)

    lb, ub = bounds_emg(x, y)

    popt, pcov = curve_fit(
        emg_peak, x, y,
        p0=p0, bounds=(lb, ub),
        sigma=sigma_y, absolute_sigma=absolute_sigma,
        maxfev=maxfev
    )
    yhat = emg_peak(x, *popt)
    met = fit_metrics(y, yhat, k=len(popt))
    perr = np.sqrt(np.diag(pcov))
    return popt, pcov, perr, yhat, met


def fit_emg_de(x, y, workers=1, seed=0, polish=True):
    x = np.asarray(x); y = np.asarray(y)
    lb, ub = bounds_emg(x, y)
    bounds = list(zip(lb, ub))

    # robust scale for optional weighted loss (Huber-like)
    mad = median_abs_deviation(y, scale='normal')
    scale = max(float(mad), 1e-12)

    def objective(p):
        r = y - emg_peak(x, *p)
        # pseudo-Huber loss for robustness to outliers
        delta = 2.0 * scale
        return np.sum(delta**2 * (np.sqrt(1.0 + (r/delta)**2) - 1.0))

    result = differential_evolution(
        objective, bounds=bounds, seed=seed, workers=workers, polish=polish
    )
    pbest = result.x
    yhat = emg_peak(x, *pbest)
    met = fit_metrics(y, yhat, k=len(pbest))
    return pbest, yhat, met, result


def fit_emg_hybrid(x, y, seed=0):
    """
    Best practice:
      1) global search with DE
      2) local refinement with curve_fit (covariance + uncertainties)
    """
    p_de, yhat_de, met_de, res_de = fit_emg_de(x, y, seed=seed, polish=True)
    popt, pcov, perr, yhat_cf, met_cf = fit_emg_curve_fit(x, y, p0=p_de)
    return {
        "p_de": p_de, "yhat_de": yhat_de, "met_de": met_de, "res_de": res_de,
        "p_opt": popt, "pcov": pcov, "perr": perr, "yhat": yhat_cf, "metrics": met_cf
    }


# ============================================================
# 6) Synthetic data generator
# ============================================================

def generate_synthetic_emg_data(
    n=500, x_min=-5, x_max=10,
    A=80, mu=1.2, sigma=0.8, tau=2.0, y0=3.0,
    noise_std=0.7, outlier_frac=0.00, outlier_scale=8.0, seed=1
):
    """
    Generate synthetic one-sided coma-like peak data.
    """
    rng = np.random.default_rng(seed)
    x = np.linspace(x_min, x_max, n)
    y_clean = emg_peak(x, A, mu, sigma, tau, y0)
    y = y_clean + rng.normal(0.0, noise_std, size=n)

    if outlier_frac > 0:
        m = int(np.floor(outlier_frac*n))
        idx = rng.choice(n, size=m, replace=False)
        y[idx] += rng.normal(0.0, outlier_scale*noise_std, size=m)

    return x, y, y_clean


# ============================================================
# 7) Plotting helpers
# ============================================================

def plot_fit(x, y, yhat, params, title="EMG fit", show_components=True):
    A, mu, sigma, tau, y0 = params

    fig1 = plt.figure(figsize=(9, 5))
    ax = fig1.add_subplot(111)
    ax.plot(x, y, '-', ms=4, label='Data')
    ax.plot(x, yhat, '-', lw=2, label='Fit')

    if show_components:
        # approximate "Gaussian core" visualization (not convolution-separated exactly)
        g = (A / (sigma*np.sqrt(2*np.pi))) * np.exp(-0.5*((x-mu)/sigma)**2) + y0
        ax.plot(x, g, '--', lw=1.5, label='Gaussian core (visual guide)')

    ax.set_title(title)
    ax.set_xlabel("x")
    ax.set_ylabel("y")
    ax.legend()
    ax.grid(alpha=0.25)

    # residuals
    fig2 = plt.figure(figsize=(9, 3.5))
    axr = fig2.add_subplot(111)
    r = y - yhat
    axr.axhline(0, lw=1)
    axr.plot(x, r, '.', ms=4)
    axr.set_title("Residuals")
    axr.set_xlabel("x")
    axr.set_ylabel("y - fit")
    axr.grid(alpha=0.25)

    plt.tight_layout()
    plt.show()


def print_report(name, params, metrics, perr=None):
    pnames = ["A", "mu", "sigma", "tau", "y0"]
    print(f"\n=== {name} ===")
    if perr is None:
        for n, v in zip(pnames, params):
            print(f"{n:>6s} = {v: .8g}")
    else:
        for n, v, e in zip(pnames, params, perr):
            print(f"{n:>6s} = {v: .8g} ± {e:.3g}")

    print("Metrics:")
    for k, v in metrics.items():
        print(f"  {k:>4s} = {v: .8g}")


# ============================================================
# 8) Example usage
# ============================================================

if __name__ == "__main__":
    # ---- Create synthetic right-tail data
    x, y, y_clean = generate_synthetic_emg_data(
        n=600,
        A=90, mu=0.8, sigma=0.55, tau=1.6, y0=105.0,
        noise_std=5.0,
        outlier_frac=0.01,
        outlier_scale=12.0,
        seed=42
    )

    # ---- Fit with curve_fit only
    p0 = initial_guess_emg(x, y)
    popt_cf, pcov_cf, perr_cf, yhat_cf, met_cf = fit_emg_curve_fit(x, y, p0=p0)
    print_report("curve_fit", popt_cf, met_cf, perr=perr_cf)

    # ---- Fit with differential evolution only
    p_de, yhat_de, met_de, res_de = fit_emg_de(x, y, seed=42, polish=True)
    print_report("differential_evolution", p_de, met_de, perr=None)

    # ---- Hybrid fit (recommended)
    out = fit_emg_hybrid(x, y, seed=42)
    print_report("hybrid (DE -> curve_fit)", out["p_opt"], out["metrics"], perr=out["perr"])

    # ---- Plot hybrid
    plot_fit(x, y, out["yhat"], out["p_opt"], title="Hybrid EMG fit")

    # ---- Compare true vs estimated for synthetic test
    p_true = np.array([90, 0.8, 0.55, 1.6, 2.5], dtype=float)
    print("\nTrue params (synthetic):", p_true)
    print("Estimated params       :", out["p_opt"])
