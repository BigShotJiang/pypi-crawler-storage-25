"""Core dataclasses + exceptions.

Mirrors the TypeScript ``types.ts`` shapes so the same JSON payload
flows over the wire without extra adaptation.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal

Action = Literal["read", "write", "update", "delete"]
ResourceScope = Literal["system", "company"]


@dataclass(frozen=True)
class DependencyEdge:
    """One edge in a resource's ``depends_on`` cascade.

    Mirrors the TypeScript ``DependencyEdge``. ``actions`` defaults to
    read-only — the shorthand ``depends_on=["tenants"]`` is equivalent
    to ``depends_on=[DependencyEdge(resource="tenants", actions=("read",))]``.

    Available since 0.4.0.
    """

    resource: str
    actions: tuple[Action, ...] = ("read",)


@dataclass(frozen=True)
class ResourceDescriptor:
    resource: str
    scope: ResourceScope
    label: str
    description: str | None = None
    group: str | None = None
    # 0.4.0+. Per-edge action cascade. Granting <this>:<action> in the
    # admin matrix UI automatically grants <edge.resource>:<action> for
    # every edge whose ``actions`` includes <action>. Plain-string
    # entries default to ``(``read``,)`` so the common case stays
    # terse.
    depends_on: tuple[str | DependencyEdge, ...] = ()


@dataclass(frozen=True)
class RoleSummary:
    id: str
    name: str
    is_system: bool = False
    is_super: bool = False
    frontend_config: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class PermissionGrid:
    read: bool = False
    write: bool = False
    update: bool = False
    delete: bool = False

    def get(self, action: Action) -> bool:
        return getattr(self, action)


PermissionMap = dict[str, PermissionGrid]

# 0.4.0+. Map of resource → True for actions granted **directly**.
# Drives ``can_access_section`` on the client + ``require_section_access``
# FastAPI dep.
DirectGrantMap = dict[str, bool]


@dataclass(frozen=True)
class CompanyMembership:
    company_id: str
    company_name: str
    company_slug: str | None
    roles: list[RoleSummary]
    permissions: PermissionMap
    frontend_config: dict[str, Any] = field(default_factory=dict)
    # 0.4.0+. Per-action direct-grant maps for this company.
    direct_reads: DirectGrantMap = field(default_factory=dict)
    direct_writes: DirectGrantMap = field(default_factory=dict)
    direct_updates: DirectGrantMap = field(default_factory=dict)
    direct_deletes: DirectGrantMap = field(default_factory=dict)


@dataclass(frozen=True)
class UserProfile:
    user_id: str
    is_super_admin: bool
    system_roles: list[RoleSummary]
    system_permissions: PermissionMap
    system_frontend_config: dict[str, Any]
    memberships: list[CompanyMembership]
    # 0.4.0+. Per-action direct-grant maps at system scope.
    system_direct_reads: DirectGrantMap = field(default_factory=dict)
    system_direct_writes: DirectGrantMap = field(default_factory=dict)
    system_direct_updates: DirectGrantMap = field(default_factory=dict)
    system_direct_deletes: DirectGrantMap = field(default_factory=dict)


class AuthRbacError(Exception):
    """Base class for everything raised by the package."""


class RbacRegistryError(AuthRbacError):
    """Raised when the resource registry is malformed.

    Currently fires on cyclic ``depends_on`` graphs and on dangling
    edges (an edge points at a resource that isn't registered). Both
    are programmer errors; the package re-raises at
    ``PermissionsService`` construction so misconfigured registries
    fail loud at app boot.
    """


class PermissionDenied(AuthRbacError):  # noqa: N818 — intentional public name, "Error" suffix would be redundant
    """Raised when a permission check fails. FastAPI deps catch this
    and convert it to a 403; non-FastAPI hosts can catch it directly.
    """

    def __init__(
        self,
        resource: str,
        action: str,
        *,
        scope: ResourceScope | None = None,
        company_id: str | None = None,
    ) -> None:
        self.resource = resource
        self.action = action
        self.scope = scope
        self.company_id = company_id
        super().__init__(
            f"permission denied: {action!r} on {resource!r}"
            + (f" (company={company_id})" if company_id else "")
        )
