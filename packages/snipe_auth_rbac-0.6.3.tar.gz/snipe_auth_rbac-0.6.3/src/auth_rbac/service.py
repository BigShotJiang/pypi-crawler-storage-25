"""Permissions service — wraps the SQL helper RPCs.

Two read paths:
  * ``user_can(user_id, resource, action, company_id=None)``
    — single boolean check. Calls ``rbac.user_can``.
  * ``hydrate_profile(user_id)`` — full profile in one call. Calls
    ``rbac.user_profile``. Used by the ``/me/profile`` endpoint.

The functions live in the dedicated ``rbac`` Postgres schema, so
adopters must add ``rbac`` to their PostgREST exposed-schemas list
(Supabase Studio → Settings → API → Exposed schemas) for the
``schema("rbac")`` calls below to reach them.

A small in-process LRU caches the hydrated profile per user with a
TTL of 30 seconds. Adopters that need cross-process invalidation
(multi-worker FastAPI) should swap ``_ProfileCache`` for a Redis
implementation — the public API is unchanged.
"""

from __future__ import annotations

import time
import warnings
from threading import RLock
from typing import Any, Protocol

from .types import (
    Action,
    AuthRbacError,
    CompanyMembership,
    DependencyEdge,
    DirectGrantMap,
    PermissionGrid,
    PermissionMap,
    RbacRegistryError,
    ResourceDescriptor,
    ResourceScope,
    RoleSummary,
    UserProfile,
)


def _edge_target(edge: str | DependencyEdge) -> str:
    return edge if isinstance(edge, str) else edge.resource


def _edge_actions(edge: str | DependencyEdge) -> tuple[Action, ...]:
    return ("read",) if isinstance(edge, str) else edge.actions


# DFS colours for the dependency-graph cycle detector. Named so ruff
# doesn't flag the comparisons as magic numbers.
_COLOUR_WHITE = 0
_COLOUR_GREY = 1
_COLOUR_BLACK = 2


def _detect_cycles(resources: list[ResourceDescriptor]) -> None:
    """DFS over the registry's ``depends_on`` graph.

    Raises :class:`RbacRegistryError` on **dangling** edges (an edge
    points at a resource that isn't in the registry — almost always
    a typo).

    Cycles are *not* fatal: the matrix UI's cascade is cycle-safe by
    construction (it only flips cells on and skips already-on cells),
    and real-world dependency graphs in property-management /
    multi-entity SaaS are naturally cyclic. Cycles are reported via
    :mod:`warnings` so unintended ones stay visible during
    development without breaking adopters whose graphs are cyclic by
    design.

    Pre-0.4.1: cycles raised RbacRegistryError. The raise was wrong —
    the cascade has always been safe under cycles. 0.4.1 keeps the
    diagnostic but downgrades it to a warning.
    """
    by_name = {r.resource: r for r in resources}
    colour: dict[str, int] = {r.resource: _COLOUR_WHITE for r in resources}
    stack: list[str] = []
    cycles_found: set[str] = set()

    def visit(name: str) -> None:
        state = colour.get(name)
        if state == _COLOUR_BLACK:
            return
        if state == _COLOUR_GREY:
            cycle_start = stack.index(name)
            path = " → ".join([*stack[cycle_start:], name])
            cycles_found.add(path)
            return
        if state is None:
            referrer = stack[-1] if stack else "<root>"
            raise RbacRegistryError(
                f"depends_on target {name!r} is not a registered resource "
                f"(referenced by {referrer!r})"
            )
        colour[name] = _COLOUR_GREY
        stack.append(name)
        descriptor = by_name.get(name)
        for edge in descriptor.depends_on if descriptor else ():
            visit(_edge_target(edge))
        stack.pop()
        colour[name] = _COLOUR_BLACK

    for r in resources:
        visit(r.resource)

    if cycles_found:
        warnings.warn(
            "[auth-rbac] dependency cycle(s) detected in resource "
            "registry. Cycles are runtime-safe — the matrix UI's "
            "cascade only flips cells on and skips already-on cells — "
            "but they may indicate unintended edges. Found: "
            + "; ".join(sorted(cycles_found)),
            stacklevel=2,
        )


def _extract_resource_dependencies(
    resources: list[ResourceDescriptor],
) -> list[dict[str, str]]:
    """Flatten ``depends_on`` into one row per (parent, child, action).

    Mirrors the TS ``extractResourceDependencies`` so the same wire
    shape feeds ``rbac.replace_resource_dependencies``.
    """
    out: list[dict[str, str]] = []
    for r in resources:
        for edge in r.depends_on:
            child = _edge_target(edge)
            for action in _edge_actions(edge):
                out.append(
                    {
                        "parent_resource": r.resource,
                        "child_resource": child,
                        "action": action,
                    }
                )
    return out


class SupabaseLike(Protocol):
    """Just enough of the supabase-py surface for the service to
    work. Adopters can pass any object that implements these two
    methods (``rpc`` for the resolver / hydrator, ``from_`` for the
    one-shot resource sync)."""

    def rpc(self, fn: str, args: dict[str, Any]) -> Any: ...

    def from_(self, table: str) -> Any: ...


class _ProfileCache:
    def __init__(self, ttl_seconds: float = 30.0) -> None:
        self._ttl = ttl_seconds
        self._lock = RLock()
        self._data: dict[str, tuple[float, UserProfile]] = {}

    def get(self, user_id: str) -> UserProfile | None:
        with self._lock:
            entry = self._data.get(user_id)
            if entry is None:
                return None
            stored_at, profile = entry
            if time.monotonic() - stored_at > self._ttl:
                del self._data[user_id]
                return None
            return profile

    def put(self, user_id: str, profile: UserProfile) -> None:
        with self._lock:
            self._data[user_id] = (time.monotonic(), profile)

    def invalidate(self, user_id: str | None = None) -> None:
        with self._lock:
            if user_id is None:
                self._data.clear()
            else:
                self._data.pop(user_id, None)


class PermissionsService:
    """Single entry point used by the FastAPI deps and by manual
    callers (admin scripts, tests).

    The service is stateless except for the profile cache; instances
    are safe to share across requests."""

    def __init__(
        self,
        supabase: SupabaseLike,
        *,
        resources: list[ResourceDescriptor],
        cache_ttl_seconds: float = 30.0,
    ) -> None:
        # 0.4.0+. Reject cyclic / dangling depends_on graphs at boot
        # so adopters get an immediate, named error rather than a
        # surprise stack overflow inside the matrix UI later.
        _detect_cycles(list(resources))
        self._sb = supabase
        self._resources = {r.resource: r for r in resources}
        self._cache = _ProfileCache(cache_ttl_seconds)

    # ── Resource registry helpers ──────────────────────────────────

    def resource_scope(self, resource: str) -> ResourceScope | None:
        descriptor = self._resources.get(resource)
        return descriptor.scope if descriptor else None

    # ── Read APIs ─────────────────────────────────────────────────

    def can_access_section(
        self,
        user_id: str,
        resource: str,
        action: Action = "read",
        company_id: str | None = None,
    ) -> bool:
        """Direct-grant check for top-level navigation / list pages.

        0.4.0+. Returns True only when the user holds the action on
        the resource as a direct admin grant — implied rows from a
        ``depends_on`` cascade answer False here, even though
        :py:meth:`user_can` would return True for the same role.

        Use case: backend endpoints serving list views can gate on
        this; detail endpoints stay on :py:meth:`user_can`.

        Falls through the cached profile so the call is cheap.
        """
        try:
            profile = self.hydrate_profile(user_id)
        except AuthRbacError:
            return False
        if profile.is_super_admin:
            return True
        scope = self.resource_scope(resource)
        if scope is None:
            return False
        if scope == "system":
            return _direct_lookup_system(profile, action, resource)
        if not company_id:
            return False
        membership = next(
            (m for m in profile.memberships if m.company_id == company_id),
            None,
        )
        return (
            _direct_lookup_membership(membership, action, resource)
            if membership is not None
            else False
        )

    def user_can(
        self,
        user_id: str,
        resource: str,
        action: Action,
        company_id: str | None = None,
    ) -> bool:
        """Single boolean check. Calls the SQL function directly so
        super-admin bypass + scope rules stay in one place."""
        try:
            result = self._sb.schema("rbac").rpc(
                "user_can",
                {
                    "p_user_id": user_id,
                    "p_resource": resource,
                    "p_action": action,
                    "p_company_id": company_id,
                },
            ).execute()
        except Exception as exc:  # pragma: no cover — bubbled
            raise AuthRbacError(
                f"rbac.user_can RPC failed: {exc}"
            ) from exc

        # supabase-py returns an APIResponse; raw clients return a dict-ish.
        data = getattr(result, "data", result)
        if isinstance(data, list) and data:
            data = data[0]
        if isinstance(data, dict):
            data = data.get("user_can", next(iter(data.values()), False))
        return bool(data)

    def hydrate_profile(
        self,
        user_id: str,
        *,
        force_refresh: bool = False,
    ) -> UserProfile:
        if not force_refresh:
            cached = self._cache.get(user_id)
            if cached is not None:
                return cached
        try:
            result = self._sb.schema("rbac").rpc(
                "user_profile",
                {"p_user_id": user_id},
            ).execute()
        except Exception as exc:
            raise AuthRbacError(
                f"rbac.user_profile RPC failed: {exc}"
            ) from exc
        data = getattr(result, "data", result)
        if isinstance(data, list) and data:
            data = data[0]
        if isinstance(data, dict):
            # The function returns jsonb wrapping the whole object,
            # so the dict's only value IS the profile.
            if "user_profile" in data:
                data = data["user_profile"]
        if not isinstance(data, dict):
            raise AuthRbacError("unexpected rbac.user_profile payload")
        profile = _profile_from_jsonb(data)
        self._cache.put(user_id, profile)
        return profile

    # ── Template defaults ─────────────────────────────────────────

    def apply_template_defaults(
        self,
        role_id: str,
        *,
        only_missing: bool = True,
    ) -> int:
        """Materialise ``rbac.role_permissions`` rows from a template
        role's ``default_permissions`` JSONB pattern.

        Run this **after** ``sync_resources()`` so the function can
        match the template's group/resource patterns against the
        current resource registry.

        Returns the number of rows inserted/updated."""
        try:
            result = self._sb.schema("rbac").rpc(
                "apply_template_defaults",
                {"p_role_id": role_id, "p_only_missing": only_missing},
            ).execute()
        except Exception as exc:
            raise AuthRbacError(
                f"rbac.apply_template_defaults RPC failed: {exc}"
            ) from exc
        data = getattr(result, "data", result)
        if isinstance(data, list) and data:
            data = data[0]
        if isinstance(data, dict):
            data = data.get(
                "apply_template_defaults",
                next(iter(data.values()), 0),
            )
        return int(data or 0)

    # ── Resource sync (run once at app boot) ──────────────────────

    def sync_resources(
        self,
        resources: list[ResourceDescriptor] | None = None,
    ) -> int:
        """Upsert resource descriptors into ``rbac.resources``.

        Call this once during app start-up so adding a new resource
        is purely a code change — no manual migration required. The
        registry passed at construction is used by default; pass a
        list explicitly to sync a different set.

        Returns the number of rows upserted.

        Idempotent: running it again with the same list is a no-op
        on the matrix UI but does refresh `label` / `description` /
        `group_label` if you tweaked them.
        """
        rows = resources if resources is not None else list(self._resources.values())
        if not rows:
            return 0
        try:
            payload = [
                {
                    "resource": r.resource,
                    "scope": r.scope,
                    "label": r.label,
                    "description": r.description,
                    "group_label": r.group,
                }
                for r in rows
            ]
            self._sb.schema("rbac").from_("resources").upsert(  # type: ignore[attr-defined]
                payload, on_conflict="resource"
            ).execute()
        except Exception as exc:
            raise AuthRbacError(
                f"sync_resources failed: {exc}"
            ) from exc
        # 0.4.0+. Also push the depends_on graph into
        # rbac.resource_dependencies so the admin matrix UI can
        # cascade implied grants. Atomic replace-all via the
        # ``rbac.replace_resource_dependencies(jsonb)`` RPC. Tolerates
        # pre-0.4.0 SQL by silently skipping when the RPC is absent.
        edges = _extract_resource_dependencies(rows)
        try:
            self._sb.schema("rbac").rpc(
                "replace_resource_dependencies",
                {"p_edges": edges},
            ).execute()
        except Exception as exc:  # noqa: BLE001
            msg = str(exc).lower()
            if "replace_resource_dependencies" in msg and "does not exist" in msg:
                # Older SQL — skip silently. Adopter can upgrade and
                # re-run sync_resources to backfill.
                pass
            else:
                raise AuthRbacError(
                    f"sync_resources dependencies failed: {exc}"
                ) from exc
        return len(rows)

    # ── Bootstrap detection ───────────────────────────────────────

    def detect_schema(self) -> bool:
        """Returns True if the ``rbac`` schema looks installed.

        Cheap probe — calls ``rbac.user_can`` with a non-existent
        user; a missing schema or unexposed PostgREST surface
        bubbles up as an exception. A False return means the
        bootstrap migration hasn't been applied OR the ``rbac``
        schema isn't in the project's exposed-schemas list.

        Run this at app boot from your start-up hook; on False,
        log a clear error and skip the rest of the auth-rbac wiring
        so the app comes up degraded rather than crashing on every
        request."""
        try:
            self._sb.schema("rbac").rpc(
                "user_can",
                {
                    "p_user_id": "00000000-0000-0000-0000-000000000000",
                    "p_resource": "__rbac_self_check__",
                    "p_action": "read",
                    "p_company_id": None,
                },
            ).execute()
        except Exception:
            return False
        return True

    def require_schema(self) -> None:
        """Raise ``AuthRbacError`` if ``detect_schema`` returns False.

        Convenience wrapper for app start-up that wants to abort
        boot rather than silently degrade."""
        if not self.detect_schema():
            raise AuthRbacError(
                "rbac schema is not reachable. Apply 0001_initial.sql "
                "(and optionally 0002_seed_defaults.sql) and add 'rbac' "
                "to your PostgREST exposed-schemas list."
            )

    # ── Cache control ─────────────────────────────────────────────

    def invalidate(self, user_id: str | None = None) -> None:
        """Drop one user's cached profile (or all if user_id is None).

        Adopters wire this to a Postgres LISTEN/NOTIFY or a Supabase
        realtime channel on the assignments tables so demotions
        propagate within seconds rather than 30s TTL."""
        self._cache.invalidate(user_id)


# ── jsonb → dataclass helpers ────────────────────────────────────


def _grid_from_dict(payload: dict[str, Any]) -> PermissionGrid:
    return PermissionGrid(
        read=bool(payload.get("read")),
        write=bool(payload.get("write")),
        update=bool(payload.get("update")),
        delete=bool(payload.get("delete")),
    )


def _perm_map_from_dict(payload: dict[str, Any] | None) -> PermissionMap:
    if not payload:
        return {}
    return {k: _grid_from_dict(v or {}) for k, v in payload.items()}


def _role_from_dict(payload: dict[str, Any]) -> RoleSummary:
    return RoleSummary(
        id=str(payload.get("id")),
        name=str(payload.get("name", "")),
        is_system=bool(payload.get("is_system", False)),
        is_super=bool(payload.get("is_super", False)),
        frontend_config=payload.get("frontend_config") or {},
    )


def _direct_map_from_dict(payload: Any) -> DirectGrantMap:
    if not isinstance(payload, dict):
        return {}
    return {str(k): bool(v) for k, v in payload.items()}


def _membership_from_dict(payload: dict[str, Any]) -> CompanyMembership:
    return CompanyMembership(
        company_id=str(payload["company_id"]),
        company_name=str(payload.get("company_name", "")),
        company_slug=payload.get("company_slug"),
        roles=[_role_from_dict(r) for r in (payload.get("roles") or [])],
        permissions=_perm_map_from_dict(payload.get("permissions")),
        frontend_config=payload.get("frontend_config") or {},
        direct_reads=_direct_map_from_dict(payload.get("direct_reads")),
        direct_writes=_direct_map_from_dict(payload.get("direct_writes")),
        direct_updates=_direct_map_from_dict(payload.get("direct_updates")),
        direct_deletes=_direct_map_from_dict(payload.get("direct_deletes")),
    )


def _profile_from_jsonb(payload: dict[str, Any]) -> UserProfile:
    return UserProfile(
        user_id=str(payload["user_id"]),
        is_super_admin=bool(payload.get("is_super_admin")),
        system_roles=[
            _role_from_dict(r) for r in (payload.get("system_roles") or [])
        ],
        system_permissions=_perm_map_from_dict(payload.get("system_permissions")),
        system_frontend_config=payload.get("system_frontend_config") or {},
        memberships=[
            _membership_from_dict(m) for m in (payload.get("memberships") or [])
        ],
        system_direct_reads=_direct_map_from_dict(payload.get("system_direct_reads")),
        system_direct_writes=_direct_map_from_dict(payload.get("system_direct_writes")),
        system_direct_updates=_direct_map_from_dict(payload.get("system_direct_updates")),
        system_direct_deletes=_direct_map_from_dict(payload.get("system_direct_deletes")),
    )


# 0.4.0+. Direct-grant lookups feeding ``can_access_section``.

def _direct_lookup_system(
    profile: UserProfile, action: Action, resource: str
) -> bool:
    if action == "read":
        m = profile.system_direct_reads
    elif action == "write":
        m = profile.system_direct_writes
    elif action == "update":
        m = profile.system_direct_updates
    else:
        m = profile.system_direct_deletes
    return bool(m.get(resource))


def _direct_lookup_membership(
    membership: CompanyMembership, action: Action, resource: str
) -> bool:
    if action == "read":
        m = membership.direct_reads
    elif action == "write":
        m = membership.direct_writes
    elif action == "update":
        m = membership.direct_updates
    else:
        m = membership.direct_deletes
    return bool(m.get(resource))
