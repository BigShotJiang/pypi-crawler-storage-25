"""Unit tests for DVGatewayClient.warm_transfer.

A stub HTTP client stands in for the gateway so REST calls are captured
but never touch a network. Mirrors the approach used in
``test_play_audio.py``.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import pytest

from dvgateway.client import DVGatewayClient
from dvgateway.types import WarmTransferResult


@dataclass
class _StubResponse:
    status: int = 200
    data: Any = None


class _StubHttp:
    """Records HTTP calls and returns canned responses."""

    def __init__(self, post_response: Any = None) -> None:
        self.posts: list[tuple[str, Any]] = []
        self._post_response = post_response or {}

    async def post(self, path: str, body: Any = None) -> Any:
        self.posts.append((path, body))
        return _StubResponse(status=200, data=self._post_response)


class _NoopLogger:
    def debug(self, *a, **k): pass
    def info(self, *a, **k): pass
    def warn(self, *a, **k): pass
    def error(self, *a, **k): pass


def _make_client(post_response: Any = None) -> tuple[DVGatewayClient, _StubHttp]:
    gw = DVGatewayClient.__new__(DVGatewayClient)  # bypass __init__
    http = _StubHttp(post_response=post_response)
    gw._http = http  # type: ignore[assignment]
    gw._logger = _NoopLogger()  # type: ignore[assignment]
    return gw, http


@pytest.mark.asyncio
async def test_warm_transfer_connects() -> None:
    gw, http = _make_client(
        post_response={
            "connected": True,
            "timedOut": False,
            "error": "",
            "agentChannel": "PJSIP/1001-00000042",
            "bridgeId": "bridge-xyz",
            "whisperPlayed": False,
        }
    )

    result = await gw.warm_transfer(
        "call-a",
        destination="1001",
        whisper_text="VIP 고객입니다",
        hold_audio_url="https://cdn.example.com/hold.mp3",
        timeout_ms=30_000,
    )

    assert isinstance(result, WarmTransferResult)
    assert result.connected is True
    assert result.timed_out is False
    assert result.error is None  # empty string → None
    assert result.agent_channel == "PJSIP/1001-00000042"
    assert result.bridge_id == "bridge-xyz"
    assert result.whisper_played is False

    assert len(http.posts) == 1
    path, body = http.posts[0]
    assert path == "/api/v1/transfer/warm/call-a"
    assert body == {
        "destination": "1001",
        "timeoutMs": 30_000,
        "context": "from-internal",
        "whisperText": "VIP 고객입니다",
        "holdAudioUrl": "https://cdn.example.com/hold.mp3",
    }


@pytest.mark.asyncio
async def test_warm_transfer_timeout() -> None:
    gw, _http = _make_client(
        post_response={
            "connected": False,
            "timedOut": True,
            "error": "no_answer",
            "agentChannel": "",
            "bridgeId": "",
            "whisperPlayed": False,
        }
    )

    result = await gw.warm_transfer(
        "call-b",
        destination="1002",
        timeout_ms=5_000,
    )
    assert result.connected is False
    assert result.timed_out is True
    assert result.error == "no_answer"
    assert result.agent_channel is None
    assert result.bridge_id is None
    assert result.whisper_played is False


@pytest.mark.asyncio
async def test_warm_transfer_error_response() -> None:
    gw, _http = _make_client(
        post_response={
            "connected": False,
            "timedOut": False,
            "error": "originate_failed",
            "agentChannel": "",
            "bridgeId": "",
            "whisperPlayed": False,
        }
    )

    result = await gw.warm_transfer(
        "call-c",
        destination="1003",
    )
    assert result.connected is False
    assert result.timed_out is False
    assert result.error == "originate_failed"
    assert result.agent_channel is None
    assert result.bridge_id is None


@pytest.mark.asyncio
async def test_warm_transfer_empty_destination_raises() -> None:
    gw, _http = _make_client()
    with pytest.raises(ValueError):
        await gw.warm_transfer("call-d", destination="")


@pytest.mark.asyncio
async def test_warm_transfer_invalid_timeout_raises() -> None:
    gw, _http = _make_client()
    with pytest.raises(ValueError):
        await gw.warm_transfer("call-e", destination="1004", timeout_ms=0)
