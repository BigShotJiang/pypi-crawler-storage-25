"""Unit tests for DVGatewayClient.collect_dtmf().

These tests exercise the DTMF state machine by injecting synthetic
``call:dtmf`` events through the public ``on("call:dtmf", ...)``
subscription mechanism. A stub HTTP client stands in for the gateway so
the mute/unmute REST calls are captured but never touch a network.
"""

from __future__ import annotations

import asyncio
from typing import Any

import pytest

from dvgateway.client import DVGatewayClient
from dvgateway.types import CallDtmfEvent


class _StubHttp:
    """Records HTTP calls issued by the client without actually making them."""

    def __init__(self) -> None:
        self.posts: list[tuple[str, Any]] = []
        self.deletes: list[str] = []

    async def post(self, path: str, body: Any = None) -> Any:
        self.posts.append((path, body))
        return {"data": {"muted": True}}

    async def delete(self, path: str) -> Any:
        self.deletes.append(path)
        return {"data": {"muted": False}}


class _FanOutCallEvents:
    """Minimal stand-in for CallEventStream: keeps handlers in a list and
    exposes ``dispatch`` so tests can push synthetic events."""

    def __init__(self) -> None:
        self._type_handlers: dict[str, list] = {}

    def on_type(self, event_type: str, handler):
        self._type_handlers.setdefault(event_type, []).append(handler)

        def unsub() -> None:
            try:
                self._type_handlers[event_type].remove(handler)
            except ValueError:
                pass

        return unsub

    def on(self, handler):  # unused by collect_dtmf but keeps interface honest
        return lambda: None

    def dispatch(self, event_type: str, event) -> None:
        for h in list(self._type_handlers.get(event_type, [])):
            result = h(event)
            if asyncio.iscoroutine(result):
                asyncio.ensure_future(result)


def _make_client() -> tuple[DVGatewayClient, _StubHttp, _FanOutCallEvents]:
    """Create a minimally-wired client with stub http + call_events."""
    gw = DVGatewayClient.__new__(DVGatewayClient)  # bypass __init__

    stub_http = _StubHttp()
    call_events = _FanOutCallEvents()

    # minimal attributes collect_dtmf touches
    gw._http = stub_http  # type: ignore[assignment]
    gw._call_events = call_events  # type: ignore[assignment]
    gw._logger = _NoopLogger()  # type: ignore[assignment]
    gw._stt_mute_refs = {}
    gw._stt_mute_lock = asyncio.Lock()
    return gw, stub_http, call_events


class _NoopLogger:
    def debug(self, *a, **k): pass
    def info(self, *a, **k): pass
    def warn(self, *a, **k): pass
    def error(self, *a, **k): pass


def _dtmf(linked_id: str, digit: str, phase: str = "end") -> CallDtmfEvent:
    return CallDtmfEvent(linked_id=linked_id, digit=digit, phase=phase)  # type: ignore[arg-type]


@pytest.mark.asyncio
async def test_collect_dtmf_max_digits_reached() -> None:
    gw, http, events = _make_client()

    async def driver() -> None:
        # yield control so collect_dtmf subscribes first
        await asyncio.sleep(0)
        for d in ("1", "2", "3"):
            events.dispatch("call:dtmf", _dtmf("call-a", d))
            await asyncio.sleep(0)

    result, _ = await asyncio.gather(
        gw.collect_dtmf("call-a", max_digits=3, timeout_ms=5_000, inter_digit_timeout_ms=2_000),
        driver(),
    )
    assert result.digits == "123"
    assert result.timed_out is False
    assert result.terminated_by_key is False
    # mute then unmute was sent
    assert any("/api/v1/stt/call-a/mute" in p for p, _ in http.posts)
    assert http.deletes and "/api/v1/stt/call-a/mute" in http.deletes[0]


@pytest.mark.asyncio
async def test_collect_dtmf_terminator_ends_collection() -> None:
    gw, _http, events = _make_client()

    async def driver() -> None:
        await asyncio.sleep(0)
        for d in ("1", "2", "3", "4", "#"):
            events.dispatch("call:dtmf", _dtmf("call-b", d))
            await asyncio.sleep(0)

    result, _ = await asyncio.gather(
        gw.collect_dtmf(
            "call-b",
            max_digits=10,
            timeout_ms=5_000,
            inter_digit_timeout_ms=2_000,
            terminator="#",
        ),
        driver(),
    )
    assert result.digits == "1234"
    assert result.terminated_by_key is True
    assert result.timed_out is False


@pytest.mark.asyncio
async def test_collect_dtmf_first_key_timeout() -> None:
    gw, _http, _events = _make_client()

    result = await gw.collect_dtmf(
        "call-c",
        max_digits=4,
        timeout_ms=50,  # very short
        inter_digit_timeout_ms=2_000,
    )
    assert result.digits == ""
    assert result.timed_out is True
    assert result.terminated_by_key is False


@pytest.mark.asyncio
async def test_collect_dtmf_inter_digit_timeout() -> None:
    gw, _http, events = _make_client()

    async def driver() -> None:
        await asyncio.sleep(0)
        events.dispatch("call:dtmf", _dtmf("call-d", "5"))
        # no further digits — inter-digit timeout should trip

    result, _ = await asyncio.gather(
        gw.collect_dtmf(
            "call-d",
            max_digits=4,
            timeout_ms=5_000,
            inter_digit_timeout_ms=50,  # very short
        ),
        driver(),
    )
    assert result.digits == "5"
    assert result.timed_out is True
    assert result.terminated_by_key is False


@pytest.mark.asyncio
async def test_collect_dtmf_ignores_begin_phase_and_other_linked_ids() -> None:
    gw, _http, events = _make_client()

    async def driver() -> None:
        await asyncio.sleep(0)
        # begin-phase should be ignored
        events.dispatch("call:dtmf", _dtmf("call-e", "1", phase="begin"))
        # wrong linked_id should be ignored
        events.dispatch("call:dtmf", _dtmf("other-call", "9"))
        await asyncio.sleep(0)
        events.dispatch("call:dtmf", _dtmf("call-e", "7"))
        events.dispatch("call:dtmf", _dtmf("call-e", "#"))

    result, _ = await asyncio.gather(
        gw.collect_dtmf(
            "call-e",
            max_digits=5,
            timeout_ms=2_000,
            inter_digit_timeout_ms=1_000,
            terminator="#",
        ),
        driver(),
    )
    assert result.digits == "7"
    assert result.terminated_by_key is True
