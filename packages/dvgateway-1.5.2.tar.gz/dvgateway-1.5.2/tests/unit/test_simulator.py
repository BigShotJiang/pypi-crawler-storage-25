"""Unit tests for the SDK simulator.

Exercises :meth:`DVGatewayClient.simulate` end-to-end:
    - synthetic ``call:new`` delivery,
    - slin16 frame playback,
    - captured-TTS buffer round-trip,
    - graceful hangup and early ``stop()``.
"""
from __future__ import annotations

import asyncio
import os
import tempfile
from pathlib import Path

import pytest

from dvgateway import DVGatewayClient
from dvgateway.simulator import write_slin16_wav


# 800 ms of silence at 16 kHz → 40 frames of 640 bytes each.
SILENCE_PCM = b"\x00" * (16_000 * 2 * 8 // 10)


def _tmp_wav() -> str:
    fd, path = tempfile.mkstemp(suffix=".wav", prefix="dvgw-sim-")
    os.close(fd)
    write_slin16_wav(path, SILENCE_PCM)
    return path


def _make_client() -> DVGatewayClient:
    return DVGatewayClient(
        base_url="http://localhost:8080",
        auth={"type": "apiKey", "api_key": "simulation"},
    )


@pytest.mark.asyncio
async def test_simulate_delivers_call_new_and_resolves_wait_for_end() -> None:
    gw = _make_client()
    wav = _tmp_wav()
    try:
        events: list[str] = []

        def _handler(ev: object) -> None:
            events.append(getattr(ev, "type", ""))

        gw.on_call_event(_handler)

        call = await gw.simulate(
            audio_file=wav,
            caller="+82-10-0000-1111",
            realtime=False,          # flush ASAP in tests
            hangup_delay_ms=50,      # short grace period
        )

        assert call.linked_id.startswith("sim-")
        assert call.session.caller == "+82-10-0000-1111"

        await call.wait_for_end()

        assert "call:new" in events
        assert "call:ended" in events
    finally:
        gw.close()
        Path(wav).unlink(missing_ok=True)


@pytest.mark.asyncio
async def test_simulate_captures_injected_tts() -> None:
    gw = _make_client()
    wav = _tmp_wav()
    try:
        call = await gw.simulate(
            audio_file=wav,
            realtime=False,
            hangup_delay_ms=100,
        )

        async def _fake_tts():
            for i in range(5):
                yield bytes([i + 1]) * 640

        await gw.inject_tts(call.linked_id, _fake_tts())

        captured = call.captured_tts_bytes()
        assert len(captured) == 5 * 640

        out_path = tempfile.mktemp(suffix=".wav", prefix="sim-tts-")
        await call.save_tts(out_path)
        on_disk = Path(out_path).read_bytes()
        assert len(on_disk) == 44 + len(captured)  # 44-byte WAV header + PCM
        Path(out_path).unlink(missing_ok=True)

        await call.wait_for_end()
    finally:
        gw.close()
        Path(wav).unlink(missing_ok=True)


@pytest.mark.asyncio
async def test_simulate_stop_short_circuits() -> None:
    gw = _make_client()
    wav = _tmp_wav()
    try:
        call = await gw.simulate(
            audio_file=wav,
            realtime=True,               # would otherwise run for 800ms
            hangup_delay_ms=60_000,      # ridiculous grace we want to skip
        )

        await call.stop()
        # Must return immediately — if stop() left the hangup timer
        # alive this would wait for 60s and fail the test timeout.
        await asyncio.wait_for(call.wait_for_end(), timeout=1.0)
    finally:
        gw.close()
        Path(wav).unlink(missing_ok=True)
