"""Unit tests for GeminiLiveAdapter's ``tool_choice`` → ``tool_config``
mapping.

These run without a live WebSocket — they exercise the pure mapping
function and constructor defaults only.
"""
from __future__ import annotations

import pytest

from dvgateway.adapters.realtime import (
    GeminiLiveAdapter,
    build_gemini_tool_config,
)


class TestBuildGeminiToolConfig:
    def test_auto_maps_to_mode_auto(self) -> None:
        assert build_gemini_tool_config("auto") == {
            "function_calling_config": {"mode": "AUTO"},
        }

    def test_none_maps_to_mode_none(self) -> None:
        assert build_gemini_tool_config("none") == {
            "function_calling_config": {"mode": "NONE"},
        }

    def test_required_maps_to_mode_any(self) -> None:
        # OpenAI calls this "required"; Gemini's equivalent is mode=ANY.
        assert build_gemini_tool_config("required") == {
            "function_calling_config": {"mode": "ANY"},
        }

    def test_pinned_function_adds_allowed_names(self) -> None:
        assert build_gemini_tool_config(
            {"type": "function", "name": "lookup_order"},
        ) == {
            "function_calling_config": {
                "mode": "ANY",
                "allowed_function_names": ["lookup_order"],
            },
        }

    def test_pinned_function_requires_name(self) -> None:
        with pytest.raises(ValueError, match="requires a 'name'"):
            build_gemini_tool_config({"type": "function"})

    def test_unknown_value_raises(self) -> None:
        with pytest.raises(ValueError, match="Unsupported tool_choice"):
            build_gemini_tool_config("bogus")  # type: ignore[arg-type]


class TestGeminiLiveAdapterToolChoiceDefaults:
    def test_auto_default_when_tools_declared(self) -> None:
        adapter = GeminiLiveAdapter(
            api_key="test-key",
            tools=[{"name": "lookup_order", "description": "Get order status"}],
        )
        assert adapter._tool_choice == "auto"

    def test_none_default_when_no_tools(self) -> None:
        adapter = GeminiLiveAdapter(api_key="test-key")
        assert adapter._tool_choice is None

    def test_explicit_override_preserved(self) -> None:
        adapter = GeminiLiveAdapter(
            api_key="test-key",
            tools=[{"name": "fn1"}, {"name": "fn2"}],
            tool_choice={"type": "function", "name": "fn1"},
        )
        assert adapter._tool_choice == {"type": "function", "name": "fn1"}

    def test_explicit_none_disables_tool_calls(self) -> None:
        adapter = GeminiLiveAdapter(
            api_key="test-key",
            tools=[{"name": "fn1"}],
            tool_choice="none",
        )
        assert adapter._tool_choice == "none"

    def test_explicit_required_forces_tool_call(self) -> None:
        adapter = GeminiLiveAdapter(
            api_key="test-key",
            tools=[{"name": "fn1"}],
            tool_choice="required",
        )
        assert adapter._tool_choice == "required"
