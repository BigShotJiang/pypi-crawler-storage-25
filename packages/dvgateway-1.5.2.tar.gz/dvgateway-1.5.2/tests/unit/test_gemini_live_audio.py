"""Tests for GeminiLiveAdapter audio output parsing.

Verifies that the parser handles:
  - both camelCase (per published spec) AND snake_case (observed in
    Live preview deployments) field naming,
  - sample rate extraction from MIME type,
  - silent / text-only response detection (diagnostic surfacing).
"""
from __future__ import annotations

import base64

import pytest

from dvgateway.adapters.realtime import (
    GeminiLiveAdapter,
    parse_rate_from_mime,
    peak_amplitude,
)


class TestParseRateFromMime:
    def test_extracts_rate_from_pcm_24khz(self) -> None:
        assert parse_rate_from_mime("audio/pcm;rate=24000") == 24000

    def test_extracts_rate_with_leading_whitespace(self) -> None:
        assert parse_rate_from_mime("audio/pcm; rate=16000") == 16000

    def test_returns_none_when_no_rate(self) -> None:
        assert parse_rate_from_mime("audio/pcm") is None

    def test_returns_none_for_empty_string(self) -> None:
        assert parse_rate_from_mime("") is None

    def test_rejects_zero_rate(self) -> None:
        assert parse_rate_from_mime("audio/pcm;rate=0") is None


class TestPeakAmplitude:
    def test_empty_returns_zero(self) -> None:
        assert peak_amplitude([]) == 0.0

    def test_silence_returns_zero(self) -> None:
        assert peak_amplitude([0.0, 0.0, 0.0]) == 0.0

    def test_returns_absolute_peak(self) -> None:
        assert peak_amplitude([0.1, -0.7, 0.3, -0.2]) == pytest.approx(0.7)


class TestGeminiLiveAdapterDualCasing:
    """Verify ``_handle_server_message`` accepts both naming conventions.

    These reach into the private handler because the WebSocket session
    isn't worth standing up just to verify field-name parsing — and the
    handler is the entire bug surface.
    """

    @staticmethod
    def _make_adapter() -> GeminiLiveAdapter:
        return GeminiLiveAdapter(api_key="test-key")

    def test_decodes_audio_from_camel_case(self) -> None:
        adapter = self._make_adapter()
        captured: list[bytes] = []
        adapter.on_audio_output(lambda chunk, lid: captured.append(chunk))

        # 16-bit LE PCM at 16kHz: max positive, max negative
        pcm = bytes([0xFF, 0x7F, 0x00, 0x80])

        adapter._handle_server_message(  # type: ignore[attr-defined]
            {
                "serverContent": {
                    "modelTurn": {
                        "parts": [{
                            "inlineData": {
                                "mimeType": "audio/pcm;rate=16000",
                                "data": base64.b64encode(pcm).decode("ascii"),
                            },
                        }],
                    },
                },
            },
            "sim-call-camel",
        )

        assert len(captured) == 1
        assert len(captured[0]) == 4

    def test_decodes_audio_from_snake_case(self) -> None:
        adapter = self._make_adapter()
        captured: list[bytes] = []
        adapter.on_audio_output(lambda chunk, lid: captured.append(chunk))

        pcm = bytes([0xFF, 0x7F, 0x00, 0x80])

        adapter._handle_server_message(  # type: ignore[attr-defined]
            {
                "server_content": {
                    "model_turn": {
                        "parts": [{
                            "inline_data": {
                                "mime_type": "audio/pcm;rate=16000",
                                "data": base64.b64encode(pcm).decode("ascii"),
                            },
                        }],
                    },
                },
            },
            "sim-call-snake",
        )

        assert len(captured) == 1
        assert len(captured[0]) == 4

    def test_routes_turn_complete_from_snake_case(self) -> None:
        adapter = self._make_adapter()
        transcripts: list[str] = []
        adapter.on_transcript(lambda r: transcripts.append(r.text))

        # Stream a partial output transcript via snake_case
        adapter._handle_server_message(  # type: ignore[attr-defined]
            {"server_content": {"output_transcription": {"text": "Hello!"}}},
            "sim-call-tc",
        )
        # Then complete the turn — also snake_case
        adapter._handle_server_message(  # type: ignore[attr-defined]
            {"server_content": {"turn_complete": True}},
            "sim-call-tc",
        )

        assert "Hello!" in transcripts


class TestGeminiLiveAdapterOutputGain:
    """Verify the output_gain_db option applies the right linear multiplier
    and clips cleanly instead of wrapping around.
    """

    @staticmethod
    def _pcm_with_peak(int16_value: int) -> bytes:
        """Build a 4-sample PCM buffer with a known int16 peak value."""
        import struct

        return struct.pack("<hhhh", int16_value, -int16_value, int16_value, -int16_value)

    @staticmethod
    def _peak_int16(buf: bytes) -> int:
        """Return the peak absolute int16 value in a slin16 buffer."""
        import struct

        peak = 0
        for i in range(0, len(buf), 2):
            (s,) = struct.unpack_from("<h", buf, i)
            v = -s if s < 0 else s
            if v > peak:
                peak = v
        return peak

    @staticmethod
    def _invoke_with_pcm(adapter: GeminiLiveAdapter, pcm: bytes, linked_id: str) -> None:
        import base64
        adapter._handle_server_message(  # type: ignore[attr-defined]
            {
                "serverContent": {
                    "modelTurn": {
                        "parts": [{
                            "inlineData": {
                                "mimeType": "audio/pcm;rate=16000",
                                "data": base64.b64encode(pcm).decode("ascii"),
                            },
                        }],
                    },
                },
            },
            linked_id,
        )

    def test_default_zero_db_leaves_samples_unchanged(self) -> None:
        adapter = GeminiLiveAdapter(api_key="test-key")
        captured: list[bytes] = []
        adapter.on_audio_output(lambda chunk, lid: captured.append(chunk))

        pcm = self._pcm_with_peak(1000)
        self._invoke_with_pcm(adapter, pcm, "sim-gain-0")

        assert len(captured) == 1
        peak = self._peak_int16(captured[0])
        assert 999 <= peak <= 1001  # ±1 LSB for Float round-trip

    def test_plus_six_db_roughly_doubles_peak(self) -> None:
        adapter = GeminiLiveAdapter(api_key="test-key", output_gain_db=6)
        captured: list[bytes] = []
        adapter.on_audio_output(lambda chunk, lid: captured.append(chunk))

        pcm = self._pcm_with_peak(1000)
        self._invoke_with_pcm(adapter, pcm, "sim-gain-6")

        peak = self._peak_int16(captured[0])
        # 10**(6/20) ≈ 1.9953, so 1000 × 1.9953 ≈ 1995
        assert 1990 <= peak <= 2000

    def test_plus_24_db_amplifies_1000_to_about_15800(self) -> None:
        adapter = GeminiLiveAdapter(api_key="test-key", output_gain_db=24)
        captured: list[bytes] = []
        adapter.on_audio_output(lambda chunk, lid: captured.append(chunk))

        pcm = self._pcm_with_peak(1000)
        self._invoke_with_pcm(adapter, pcm, "sim-gain-24")

        peak = self._peak_int16(captured[0])
        # 10**(24/20) ≈ 15.849, so 1000 × 15.849 ≈ 15849
        assert 15840 <= peak <= 15860

    def test_clips_cleanly_when_gain_exceeds_int16_range(self) -> None:
        # Source at 6800 × 16x → ≈108800, must clamp to int16 max (32767).
        adapter = GeminiLiveAdapter(api_key="test-key", output_gain_db=24)
        captured: list[bytes] = []
        adapter.on_audio_output(lambda chunk, lid: captured.append(chunk))

        pcm = self._pcm_with_peak(6800)
        self._invoke_with_pcm(adapter, pcm, "sim-gain-clip")

        peak = self._peak_int16(captured[0])
        assert 32766 <= peak <= 32767  # no wrap-around to negatives

    def test_stores_configured_output_gain_db(self) -> None:
        adapter = GeminiLiveAdapter(api_key="test-key", output_gain_db=24)
        assert adapter._output_gain_db == 24.0
        # Linear multiplier pre-computed — no round-trip through log math
        # per chunk.
        assert abs(adapter._output_gain_linear - 15.848931924611136) < 1e-9

    def test_defaults_to_zero_db_when_unset(self) -> None:
        adapter = GeminiLiveAdapter(api_key="test-key")
        assert adapter._output_gain_db == 0.0
        assert adapter._output_gain_linear == 1.0


class TestClassifyServerMessage:
    """The heartbeat tag generator — resilient to camelCase and snake_case."""

    def test_setup_complete_camel(self) -> None:
        from dvgateway.adapters.realtime import classify_server_message
        assert classify_server_message({"setupComplete": {}}) == "setupComplete"

    def test_setup_complete_snake(self) -> None:
        from dvgateway.adapters.realtime import classify_server_message
        assert classify_server_message({"setup_complete": {}}) == "setupComplete"

    def test_model_turn_audio_vs_text(self) -> None:
        from dvgateway.adapters.realtime import classify_server_message
        assert classify_server_message({
            "serverContent": {"modelTurn": {"parts": [{"inlineData": {"data": "aGVsbG8="}}]}},
        }) == "modelTurn(audio)"
        assert classify_server_message({
            "serverContent": {"modelTurn": {"parts": [{"text": "hello"}]}},
        }) == "modelTurn(text)"

    def test_turn_complete_wins_over_other_variants(self) -> None:
        from dvgateway.adapters.realtime import classify_server_message
        assert classify_server_message({
            "serverContent": {"turn_complete": True},
        }) == "turnComplete"

    def test_interrupted_no_model_turn(self) -> None:
        from dvgateway.adapters.realtime import classify_server_message
        assert classify_server_message({
            "serverContent": {"interrupted": True},
        }) == "interrupted"

    def test_input_and_output_transcription(self) -> None:
        from dvgateway.adapters.realtime import classify_server_message
        assert classify_server_message({
            "serverContent": {"inputTranscription": {"text": "hi"}},
        }) == "inputTranscription"
        assert classify_server_message({
            "server_content": {"output_transcription": {"text": "hello"}},
        }) == "outputTranscription"

    def test_tool_call_and_go_away(self) -> None:
        from dvgateway.adapters.realtime import classify_server_message
        assert classify_server_message({
            "toolCall": {"functionCalls": [{"name": "lookup"}]},
        }) == "toolCall"
        assert classify_server_message({"goAway": {"timeLeft": "5s"}}) == "goAway"

    def test_unknown_key_surfaces_for_forward_compat(self) -> None:
        from dvgateway.adapters.realtime import classify_server_message
        result = classify_server_message({"futureFeature": {"x": 1}})
        assert result == "unknown:futureFeature"


class TestGeminiLiveAdapterPerSessionDiagnostics:
    """Verify handleServerMessage updates per-session diagnostic state."""

    def test_handle_server_message_updates_last_message_type(self) -> None:
        adapter = GeminiLiveAdapter(api_key="test-key")
        # Simulate start_session's diagnostic init.
        import time as _t

        from dvgateway.adapters.realtime.gemini_live import _SessionDiagnostics
        now = _t.monotonic()
        adapter._session_diag["sim-call"] = _SessionDiagnostics(
            start_time=now, last_server_message_at=now, turn_started_at=now,
        )

        adapter._handle_server_message(
            {"serverContent": {"turnComplete": True}},
            "sim-call",
        )
        diag = adapter._session_diag["sim-call"]
        assert diag.last_server_message_type == "turnComplete"
        assert diag.turn_number == 1
        assert diag.saw_input_this_turn is False
        assert diag.saw_output_this_turn is False

    def test_turn_complete_advances_counter_and_resets_flags(self) -> None:
        adapter = GeminiLiveAdapter(api_key="test-key")
        import time as _t

        from dvgateway.adapters.realtime.gemini_live import _SessionDiagnostics
        now = _t.monotonic()
        adapter._session_diag["sim-call"] = _SessionDiagnostics(
            start_time=now, last_server_message_at=now, turn_started_at=now,
            turn_number=5, saw_input_this_turn=True, saw_output_this_turn=True,
        )

        adapter._handle_server_message(
            {"serverContent": {"turnComplete": True}},
            "sim-call",
        )
        diag = adapter._session_diag["sim-call"]
        assert diag.turn_number == 6
        assert diag.saw_input_this_turn is False
        assert diag.saw_output_this_turn is False


class TestListGeminiLiveModels:
    """Live registry discovery — mocked aiohttp.ClientSession."""

    @staticmethod
    def _mock_response(status: int, json_payload: object | None = None,
                       text_payload: str = "") -> object:
        """Build a mock aiohttp response object that mimics the async
        context-manager interface used by `aiohttp.ClientSession.get`.
        """
        from unittest.mock import AsyncMock, MagicMock

        resp = MagicMock()
        resp.status = status
        resp.json = AsyncMock(return_value=json_payload or {})
        resp.text = AsyncMock(return_value=text_payload)
        # Async context manager protocol
        resp.__aenter__ = AsyncMock(return_value=resp)
        resp.__aexit__ = AsyncMock(return_value=False)
        return resp

    @staticmethod
    def _mock_session(response: object) -> object:
        """Mock aiohttp.ClientSession used as `async with` context."""
        from unittest.mock import AsyncMock, MagicMock

        session = MagicMock()
        session.get = MagicMock(return_value=response)
        session.__aenter__ = AsyncMock(return_value=session)
        session.__aexit__ = AsyncMock(return_value=False)
        return session

    @pytest.mark.asyncio
    async def test_filters_models_with_bidi_generate_content(
        self, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        from dvgateway.adapters.realtime import (
            list_gemini_live_models,
        )
        from dvgateway.adapters.realtime.gemini_live import (
            _reset_live_model_cache,
        )

        _reset_live_model_cache()
        resp = self._mock_response(200, {
            "models": [
                {
                    "name": "models/gemini-2.5-flash-native-audio-preview-09-2025",
                    "displayName": "Gemini 2.5 Flash Native Audio",
                    "description": "native audio Live model",
                    "version": "001",
                    "supportedGenerationMethods": ["bidiGenerateContent", "generateContent"],
                },
                {
                    "name": "models/gemini-1.5-pro",
                    "displayName": "Gemini 1.5 Pro",
                    "description": "text-only",
                    "version": "001",
                    "supportedGenerationMethods": ["generateContent"],
                },
                {
                    "name": "models/gemini-live-half-cascade",
                    "displayName": "Gemini Live Half-Cascade",
                    "description": "live",
                    "version": "002",
                    "supportedGenerationMethods": ["bidiGenerateContent"],
                },
            ],
        })
        session = self._mock_session(resp)
        import aiohttp
        monkeypatch.setattr(aiohttp, "ClientSession", lambda: session)

        models = await list_gemini_live_models("test-key")
        assert len(models) == 2
        assert [m["name"] for m in models] == [
            "models/gemini-2.5-flash-native-audio-preview-09-2025",
            "models/gemini-live-half-cascade",
        ]

    @pytest.mark.asyncio
    async def test_caches_per_api_key(
        self, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        from dvgateway.adapters.realtime import list_gemini_live_models
        from dvgateway.adapters.realtime.gemini_live import (
            _reset_live_model_cache,
        )

        _reset_live_model_cache()
        call_count = 0

        def make_session():
            nonlocal call_count
            call_count += 1
            return self._mock_session(self._mock_response(200, {
                "models": [{
                    "name": "models/m1",
                    "displayName": "M1",
                    "description": "",
                    "version": "1",
                    "supportedGenerationMethods": ["bidiGenerateContent"],
                }],
            }))

        import aiohttp
        monkeypatch.setattr(aiohttp, "ClientSession", make_session)

        await list_gemini_live_models("key-A")
        await list_gemini_live_models("key-A")
        assert call_count == 1
        await list_gemini_live_models("key-B")
        assert call_count == 2

    @pytest.mark.asyncio
    async def test_bypasses_cache_when_ttl_zero(
        self, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        from dvgateway.adapters.realtime import list_gemini_live_models
        from dvgateway.adapters.realtime.gemini_live import (
            _reset_live_model_cache,
        )

        _reset_live_model_cache()
        call_count = 0

        def make_session():
            nonlocal call_count
            call_count += 1
            return self._mock_session(self._mock_response(200, {"models": []}))

        import aiohttp
        monkeypatch.setattr(aiohttp, "ClientSession", make_session)

        await list_gemini_live_models("key-X", cache_ttl_s=0)
        await list_gemini_live_models("key-X", cache_ttl_s=0)
        assert call_count == 2

    @pytest.mark.asyncio
    async def test_raises_on_empty_api_key(self) -> None:
        from dvgateway.adapters.realtime import list_gemini_live_models
        with pytest.raises(ValueError, match="api_key is required"):
            await list_gemini_live_models("")

    @pytest.mark.asyncio
    async def test_raises_with_body_on_non_200(
        self, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        from dvgateway.adapters.realtime import list_gemini_live_models
        from dvgateway.adapters.realtime.gemini_live import (
            _reset_live_model_cache,
        )

        _reset_live_model_cache()
        resp = self._mock_response(403, text_payload="API key not valid.")
        session = self._mock_session(resp)
        import aiohttp
        monkeypatch.setattr(aiohttp, "ClientSession", lambda: session)

        with pytest.raises(RuntimeError, match=r"HTTP 403.*API key not valid"):
            await list_gemini_live_models("bad-key")


class TestOpenAICompatAliases:
    """Verify OpenAI-compat aliases: ``max_response_tokens`` folds into
    ``max_output_tokens``, and ``threshold`` folds into the LOW/MEDIUM/
    HIGH sensitivity fields.
    """

    def test_map_threshold_low_to_high_sensitivity(self) -> None:
        from dvgateway.adapters.realtime import map_threshold_to_sensitivity

        assert map_threshold_to_sensitivity(0.0) == "HIGH"
        assert map_threshold_to_sensitivity(0.1) == "HIGH"
        assert map_threshold_to_sensitivity(0.29) == "HIGH"

    def test_map_threshold_default_to_medium(self) -> None:
        from dvgateway.adapters.realtime import map_threshold_to_sensitivity

        assert map_threshold_to_sensitivity(0.3) == "MEDIUM"
        assert map_threshold_to_sensitivity(0.5) == "MEDIUM"
        assert map_threshold_to_sensitivity(0.7) == "MEDIUM"

    def test_map_threshold_high_to_low_sensitivity(self) -> None:
        from dvgateway.adapters.realtime import map_threshold_to_sensitivity

        assert map_threshold_to_sensitivity(0.71) == "LOW"
        assert map_threshold_to_sensitivity(0.9) == "LOW"
        assert map_threshold_to_sensitivity(1.0) == "LOW"

    def test_map_threshold_rejects_invalid(self) -> None:
        from dvgateway.adapters.realtime import map_threshold_to_sensitivity

        assert map_threshold_to_sensitivity(None) is None
        assert map_threshold_to_sensitivity(-0.1) is None
        assert map_threshold_to_sensitivity(1.1) is None
        assert map_threshold_to_sensitivity(float("nan")) is None

    def test_max_response_tokens_maps_to_max_output_tokens(self) -> None:
        from dvgateway.adapters.realtime import GeminiLiveAdapter

        adapter = GeminiLiveAdapter(api_key="test-key", max_response_tokens=1024)
        assert adapter._max_output_tokens == 1024

    def test_explicit_max_output_tokens_wins_over_alias(self) -> None:
        from dvgateway.adapters.realtime import GeminiLiveAdapter

        adapter = GeminiLiveAdapter(
            api_key="test-key",
            max_output_tokens=256,
            max_response_tokens=1024,
        )
        assert adapter._max_output_tokens == 256

    def test_max_response_tokens_inf_means_no_cap(self) -> None:
        from dvgateway.adapters.realtime import GeminiLiveAdapter

        adapter = GeminiLiveAdapter(api_key="test-key", max_response_tokens="inf")
        assert adapter._max_output_tokens is None

    def test_turn_detection_threshold_sets_both_sensitivities(self) -> None:
        from dvgateway.adapters.realtime import (
            GeminiLiveAdapter,
            GeminiLiveTurnDetectionOptions,
        )

        adapter = GeminiLiveAdapter(
            api_key="test-key",
            turn_detection=GeminiLiveTurnDetectionOptions(threshold=0.9),
        )
        cfg = adapter._build_realtime_input_config()
        aad = cfg["automatic_activity_detection"]
        assert isinstance(aad, dict)
        assert aad["start_of_speech_sensitivity"] == "START_SENSITIVITY_LOW"
        assert aad["end_of_speech_sensitivity"] == "END_SENSITIVITY_LOW"

    def test_explicit_start_sensitivity_wins_threshold_still_applies_to_end(
        self,
    ) -> None:
        from dvgateway.adapters.realtime import (
            GeminiLiveAdapter,
            GeminiLiveTurnDetectionOptions,
        )

        adapter = GeminiLiveAdapter(
            api_key="test-key",
            turn_detection=GeminiLiveTurnDetectionOptions(
                threshold=0.1, start_sensitivity="LOW",
            ),
        )
        cfg = adapter._build_realtime_input_config()
        aad = cfg["automatic_activity_detection"]
        assert isinstance(aad, dict)
        # Explicit start → LOW
        assert aad["start_of_speech_sensitivity"] == "START_SENSITIVITY_LOW"
        # End falls through to threshold mapping → HIGH (from 0.1)
        assert aad["end_of_speech_sensitivity"] == "END_SENSITIVITY_HIGH"

    def test_turn_detection_dict_accepts_threshold(self) -> None:
        """The adapter also accepts turn_detection as a plain dict;
        verify the threshold alias works through that pathway too."""
        from dvgateway.adapters.realtime import GeminiLiveAdapter

        adapter = GeminiLiveAdapter(
            api_key="test-key",
            turn_detection={"threshold": 0.0},
        )
        cfg = adapter._build_realtime_input_config()
        aad = cfg["automatic_activity_detection"]
        assert isinstance(aad, dict)
        assert aad["start_of_speech_sensitivity"] == "START_SENSITIVITY_HIGH"
