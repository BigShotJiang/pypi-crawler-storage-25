"""Unit tests for DVGatewayClient.play_audio / stop_audio.

A stub HTTP client stands in for the gateway so REST calls are captured
but never touch a network. Mirrors the approach used in
``test_collect_dtmf.py``.
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import Any

import pytest

from dvgateway.client import DVGatewayClient
from dvgateway.types import PlayAudioResult


@dataclass
class _StubResponse:
    status: int = 200
    data: Any = None


class _StubHttp:
    """Records HTTP calls and returns canned responses."""

    def __init__(self, post_response: Any = None) -> None:
        self.posts: list[tuple[str, Any]] = []
        self.deletes: list[str] = []
        self._post_response = post_response or {"completed": True, "durationMs": 0}

    async def post(self, path: str, body: Any = None) -> Any:
        self.posts.append((path, body))
        return _StubResponse(status=200, data=self._post_response)

    async def delete(self, path: str) -> Any:
        self.deletes.append(path)
        return _StubResponse(status=200, data={"stopped": True, "linkedId": "x"})


class _NoopLogger:
    def debug(self, *a, **k): pass
    def info(self, *a, **k): pass
    def warn(self, *a, **k): pass
    def error(self, *a, **k): pass


def _make_client(post_response: Any = None) -> tuple[DVGatewayClient, _StubHttp]:
    gw = DVGatewayClient.__new__(DVGatewayClient)  # bypass __init__
    http = _StubHttp(post_response=post_response)
    gw._http = http  # type: ignore[assignment]
    gw._logger = _NoopLogger()  # type: ignore[assignment]
    return gw, http


@pytest.mark.asyncio
async def test_play_audio_completes_normally() -> None:
    gw, http = _make_client(
        post_response={
            "completed": True,
            "interruptedByDtmf": "",
            "durationMs": 1234,
            "linkedId": "call-a",
        }
    )

    result = await gw.play_audio(
        "call-a",
        url="https://cdn.example.com/a.mp3",
    )

    assert isinstance(result, PlayAudioResult)
    assert result.completed is True
    assert result.interrupted_by_dtmf is None  # empty string → None
    assert result.duration_ms == 1234

    assert len(http.posts) == 1
    path, body = http.posts[0]
    assert path == "/api/v1/play/call-a"
    assert body == {
        "url": "https://cdn.example.com/a.mp3",
        "loop": False,
        "interruptOnDtmf": False,
        "waitForCompletion": True,
    }


@pytest.mark.asyncio
async def test_play_audio_interrupted_by_dtmf() -> None:
    gw, _http = _make_client(
        post_response={
            "completed": False,
            "interruptedByDtmf": "1",
            "durationMs": 500,
            "linkedId": "call-b",
        }
    )
    result = await gw.play_audio(
        "call-b",
        url="https://cdn.example.com/b.mp3",
        interrupt_on_dtmf=True,
    )
    assert result.completed is False
    assert result.interrupted_by_dtmf == "1"
    assert result.duration_ms == 500


@pytest.mark.asyncio
async def test_play_audio_no_wait_returns_immediately() -> None:
    gw, http = _make_client(
        post_response={"started": True, "linkedId": "call-c"}
    )
    result = await gw.play_audio(
        "call-c",
        url="https://cdn.example.com/c.mp3",
        wait_for_completion=False,
    )
    assert result.completed is False
    assert result.interrupted_by_dtmf is None
    assert result.duration_ms == 0

    _path, body = http.posts[0]
    assert body["waitForCompletion"] is False


@pytest.mark.asyncio
async def test_stop_audio_sends_delete() -> None:
    gw, http = _make_client()
    await gw.stop_audio("call-d")
    assert http.deletes == ["/api/v1/play/call-d"]


@pytest.mark.asyncio
async def test_play_audio_empty_url_raises() -> None:
    gw, _http = _make_client()
    with pytest.raises(ValueError):
        await gw.play_audio("call-e", url="")
