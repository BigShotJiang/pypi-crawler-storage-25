"""
DVGateway SDK

Real-time voice AI integration for DVGateway media gateway.

Quick start:

    from dvgateway import DVGatewayClient
    from dvgateway.adapters.stt import DeepgramAdapter
    from dvgateway.adapters.llm import AnthropicAdapter
    from dvgateway.adapters.tts import ElevenLabsAdapter

    gw = DVGatewayClient(
        base_url="https://gateway.example.com",
        auth={"type": "apiKey", "api_key": os.environ["DV_API_KEY"]},
    )

    await (
        gw.pipeline()
        .stt(DeepgramAdapter(api_key=os.environ["DEEPGRAM_KEY"], language="ko"))
        .llm(AnthropicAdapter(api_key=os.environ["ANTHROPIC_KEY"], model="claude-opus-4-6"))
        .tts(ElevenLabsAdapter(api_key=os.environ["ELEVENLABS_KEY"]))
        .start()
    )

DVGateway port reference:
  :8080 — API server  (AI clients connect here)
  :8081 — Dashboard   (monitoring UI)
  :8092 — Media server (Asterisk ExternalMedia WebSocket, default GW_MEDIA_ADDR)
  :8088 — Asterisk ARI HTTP API (Asterisk's own port, not DVGateway's)
"""

# Main client
from dvgateway.client import DVGatewayClient

# Simulator (for offline testing and docs Try-it widgets)
from dvgateway.simulator import SimulateOptions, SimulatedCall

# Types
from dvgateway.types import (
    ApiKeyAuth,
    AudioChunk,
    Auth,
    CallEndedEvent,
    CallDtmfEvent,
    CallEvent,
    CallNewEvent,
    CallSession,
    ConfEndedEvent,
    ConfJoinEvent,
    ConfLeaveEvent,
    ConferenceParticipant,
    TTSCompleteEvent,
    ConferenceSession,
    DVGatewayOptions,
    HUMAN_VOICE_DEFAULTS_EN,
    HUMAN_VOICE_DEFAULTS_KO,
    HumanVoiceOptions,
    JwtAuth,
    LlmAdapter,
    LlmOptions,
    Message,
    MtlsOptions,
    PipelineOptions,
    RawAudioChunk,
    ReconnectOptions,
    SecurityOptions,
    StreamDir,
    SentimentResult,
    SttAdapter,
    TranscriptResult,
    TranscriptWord,
    TtsAdapter,
    TtsOptions,
    Unsubscribe,
    VoiceInfo,
    WarmTransferResult,
)

# Audio codec utilities
from dvgateway.audio.codec import (
    calculate_rms,
    detect_voice_activity,
    float32_to_slin16,
    resample,
    slin16_to_float32,
    slin16_to_ulaw,
    ulaw_to_slin16,
)

# Logger factory
from dvgateway.observability.logger import create_logger, default_logger

# Metrics
from dvgateway.observability.metrics import Counter, Histogram, PipelineMetrics

__all__ = [
    # Client
    "DVGatewayClient",
    # Simulator
    "SimulateOptions",
    "SimulatedCall",
    # Auth
    "ApiKeyAuth",
    "JwtAuth",
    "Auth",
    # Options
    "DVGatewayOptions",
    "ReconnectOptions",
    "SecurityOptions",
    "MtlsOptions",
    # Sessions
    "CallSession",
    "ConferenceSession",
    "ConferenceParticipant",
    "StreamDir",
    # Events
    "CallEvent",
    "CallNewEvent",
    "CallEndedEvent",
    "ConfJoinEvent",
    "ConfLeaveEvent",
    "ConfEndedEvent",
    "TTSCompleteEvent",
    "CallDtmfEvent",
    # Audio
    "AudioChunk",
    "RawAudioChunk",
    # AI adapters
    "SttAdapter",
    "TtsAdapter",
    "LlmAdapter",
    "TranscriptResult",
    "TranscriptWord",
    "SentimentResult",
    "TtsOptions",
    "HumanVoiceOptions",
    "HUMAN_VOICE_DEFAULTS_KO",
    "HUMAN_VOICE_DEFAULTS_EN",
    "VoiceInfo",
    "WarmTransferResult",
    "Message",
    "LlmOptions",
    # Pipeline
    "PipelineOptions",
    # Logging
    "create_logger",
    "default_logger",
    # Metrics
    "PipelineMetrics",
    "Histogram",
    "Counter",
    # Audio utilities
    "slin16_to_float32",
    "float32_to_slin16",
    "ulaw_to_slin16",
    "slin16_to_ulaw",
    "resample",
    "calculate_rms",
    "detect_voice_activity",
    # Utility
    "Unsubscribe",
]
