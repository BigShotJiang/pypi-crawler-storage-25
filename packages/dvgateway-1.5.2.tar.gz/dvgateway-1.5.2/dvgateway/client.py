"""
DVGatewayClient — Main SDK Entry Point

Wires together all internal components and exposes a clean,
type-safe public API for integrating with the DVGateway.

Example:
    gw = DVGatewayClient(
        base_url="https://gateway.example.com",
        auth=ApiKeyAuth(api_key=os.environ["DV_API_KEY"]),
    )

    # High-level: 5-line AI voice bot
    await (
        gw.pipeline()
        .stt(DeepgramAdapter(api_key="..."))
        .llm(AnthropicAdapter(api_key="..."))
        .tts(ElevenLabsAdapter(api_key="..."))
        .start()
    )
"""

from __future__ import annotations

from typing import AsyncIterable, Awaitable, Callable, Literal
from urllib.parse import quote as _url_quote

from dvgateway.auth.manager import AuthManager
from dvgateway.minutes.manager import MinutesManager
from dvgateway.observability.logger import create_logger
from dvgateway.observability.metrics import PipelineMetrics
from dvgateway.pipeline.builder import PipelineBuilder
from dvgateway.session.manager import SessionManager
from dvgateway.streams.audio_stream import AudioStream, create_audio_stream
from dvgateway.streams.call_events import CallEventStream
from dvgateway.streams.tts_stream import TtsInjector
from dvgateway.transport.http_client import HttpClient
from dvgateway.transport.ws_pool import WsPool
from dvgateway.types import (
    AudioChunk,
    CallDtmfEvent,
    CallEvent,
    CallSession,
    DTMFResult,
    DVGatewayOptions,
    PlayAudioResult,
    Logger,
    StreamDir,
    TranscriptResult,
    TtsAdapter,
    Unsubscribe,
    WarmTransferResult,
)


class DVGatewayClient:
    """Main SDK entry point for the DVGateway real-time voice media gateway."""

    def __init__(
        self,
        base_url: str = "http://localhost:8080",
        auth: dict[str, str] | None = None,
        tenant_id: str | None = None,
        timeout: int = 30_000,
        reconnect: dict[str, object] | None = None,
        security: dict[str, object] | None = None,
        logger: Logger | None = None,
        *,
        options: DVGatewayOptions | None = None,
    ) -> None:
        # Support both dict-style and DVGatewayOptions
        if options:
            opts = options
        else:
            from dvgateway.types import ApiKeyAuth, JwtAuth, ReconnectOptions, SecurityOptions

            # Parse auth
            auth_dict = auth or {"type": "apiKey", "api_key": "dev-no-auth"}
            if auth_dict.get("type") == "jwt":
                parsed_auth = JwtAuth(token=auth_dict.get("token", ""))
            else:
                parsed_auth = ApiKeyAuth(api_key=auth_dict.get("api_key", "dev-no-auth"))

            # Parse reconnect
            recon_dict = reconnect or {}
            parsed_reconnect = ReconnectOptions(
                max_attempts=int(recon_dict.get("max_attempts", recon_dict.get("maxAttempts", 10))),  # type: ignore[arg-type]
                initial_delay_ms=int(recon_dict.get("initial_delay_ms", recon_dict.get("initialDelayMs", 2000))),  # type: ignore[arg-type]
                on_reconnect=recon_dict.get("on_reconnect", recon_dict.get("onReconnect")),  # type: ignore[arg-type]
            )

            # Parse security
            sec_dict = security or {}
            parsed_security = SecurityOptions(
                mask_pii=bool(sec_dict.get("mask_pii", sec_dict.get("maskPii", True))),
                force_tls=bool(sec_dict.get("force_tls", sec_dict.get("forceTls", True))),
            )

            opts = DVGatewayOptions(
                base_url=base_url,
                auth=parsed_auth,
                tenant_id=tenant_id,
                timeout=timeout,
                reconnect=parsed_reconnect,
                security=parsed_security,
                logger=logger,
            )

        # Enforce TLS in production
        normalized_url = self._normalize_base_url(opts)

        self._logger: Logger = opts.logger or create_logger(
            level="info",
            redact_pii=opts.security.mask_pii,
        )

        self._auth = AuthManager(opts.auth, normalized_url, self._logger)
        self._ws_pool = WsPool(self._auth, opts.reconnect, self._logger)
        self._http = HttpClient(self._auth, opts.timeout, self._logger, opts.tenant_id)
        self._call_events = CallEventStream(self._ws_pool, self._logger)
        self._tts_injector = TtsInjector(self._ws_pool, self._http, self._logger)
        self._sessions = SessionManager(self._http, self._logger)
        self._minutes = MinutesManager(self._http, self._logger)
        self.metrics = PipelineMetrics(self._logger)
        # Per-linkedID STT mute reference counter used by collect_dtmf
        # to coordinate concurrent collectors within this process.
        # Only the final release actually sends DELETE to the gateway.
        self._stt_mute_refs: dict[str, int] = {}
        import asyncio as _asyncio
        self._stt_mute_lock = _asyncio.Lock()

    # ─── High-Level: Pipeline Builder ──────────────────────────────────────

    def pipeline(self) -> PipelineBuilder:
        """
        Create a fluent AI voice pipeline.

        Example:
            await (
                gw.pipeline()
                .stt(DeepgramAdapter(api_key="..."))
                .llm(AnthropicAdapter(api_key="..."))
                .tts(ElevenLabsAdapter(api_key="..."))
                .on_new_call(lambda s: print(f"Call: {s.linked_id}"))
                .start()
            )
        """
        return PipelineBuilder(self._ws_pool, self._call_events, self._tts_injector, self._logger)

    # ─── Simulation (no gateway / no phone required) ────────────────────────

    async def simulate(
        self,
        audio_file: str,
        *,
        linked_id: str | None = None,
        caller: str | None = None,
        caller_name: str | None = None,
        callee: str | None = None,
        did: str | None = None,
        tenant_id: str | None = None,
        realtime: bool = True,
        hangup_delay_ms: int = 5_000,
        on_tts: Callable[[bytes], None] | None = None,
    ) -> "SimulatedCall":
        """Simulate an inbound call from a local audio file.

        No gateway, no PBX, no phone number required. The existing
        pipeline runs unchanged (same ``pipeline().stt().llm().tts()
        .start()``) and the simulator acts as a loopback gateway: it
        fires a synthetic ``call:new`` event, streams the audio file
        into the pipeline frame-by-frame, captures the bot's injected
        TTS reply into an in-memory buffer, then fires ``call:ended``
        after a grace period.

        This is the recommended way to:

        * run SDK examples in the docs "Try it" widgets,
        * write unit tests for voice-bot logic,
        * onboard developers before their gateway and DID are
          provisioned.

        The audio file must be 16 kHz mono 16-bit PCM — either a WAV
        or a raw slin16 capture. Convert arbitrary assets with::

            ffmpeg -i input.mp3 -ar 16000 -ac 1 -sample_fmt s16 caller.wav

        Args:
            audio_file: Path to the caller's audio.
            linked_id: Auto-generated if omitted.
            caller: Synthetic CallerID number.
            caller_name: Synthetic CallerID name.
            callee: Dialled extension.
            did: DID main number.
            tenant_id: Tenant identifier propagated into ``call:new``.
            realtime: Pace at 20 ms/frame (True, default) or flush ASAP.
            hangup_delay_ms: Grace period before ``call:ended`` fires
                after the caller audio drains. Default: 5000.
            on_tts: Optional callback invoked for each captured TTS
                frame.

        Returns:
            A :class:`SimulatedCall` exposing ``wait_for_end()``,
            ``save_tts(path)``, ``captured_tts_bytes()``, and
            ``stop()``.

        Example::

            gw = DVGatewayClient(
                base_url="http://localhost:8080",
                auth={"type": "apiKey", "api_key": "simulation"},
            )

            # Start the pipeline (non-awaited — runs until gw.close()).
            asyncio.ensure_future(
                gw.pipeline().stt(stt).llm(llm).tts(tts).start()
            )

            # Drive a fake call.
            call = await gw.simulate(
                audio_file="./samples/customer-inquiry.wav",
                caller="+82-10-1234-5678",
            )
            await call.wait_for_end()
            await call.save_tts("./samples/bot-reply.wav")

            gw.close()
        """
        from dvgateway.simulator.simulator import (
            SimulateOptions,
            SimulatedCall,
            create_simulated_call,
        )

        opts = SimulateOptions(
            audio_file=audio_file,
            linked_id=linked_id,
            caller=caller,
            caller_name=caller_name,
            callee=callee,
            did=did,
            tenant_id=tenant_id,
            realtime=realtime,
            hangup_delay_ms=hangup_delay_ms,
            on_tts=on_tts,
        )
        return await create_simulated_call(self._ws_pool, self._logger, opts)

    # ─── Mid-Level: Audio Streaming ─────────────────────────────────────────

    def stream_audio(
        self,
        linked_id: str,
        dir: StreamDir = "both",
        pipeline_type: str = "",
    ) -> AudioStream:
        """
        Subscribe to real-time audio from a call.
        Returns an AsyncIterable that yields AudioChunk (Float32, 16kHz).

        Args:
            linked_id: Call session identifier.
            dir: Stream direction ("in" / "out" / "both").
            pipeline_type: AI pipeline kind declaration for the gateway
                dashboard. Pass ``"s2s"`` when driving this stream with
                OpenAIRealtimeAdapter so the callee VU is labeled "AI",
                ducking is applied on tts:start, and the S2S pipeline badge
                appears on the session card. Empty string = legacy behavior.

        Example::

            # S2S (OpenAI Realtime) — dashboard shows AI session
            stream = gw.stream_audio(linked_id, dir="both", pipeline_type="s2s")
            await realtime.start_session(linked_id, stream)
        """
        return create_audio_stream(
            self._ws_pool, linked_id, self._logger, dir, pipeline_type
        )

    # ─── Mid-Level: TTS Injection ───────────────────────────────────────────

    async def inject_tts(self, linked_id: str, audio_chunks: AsyncIterable[bytes]) -> None:
        """Inject synthesized speech into an active call."""
        await self._tts_injector.inject_streaming(linked_id, audio_chunks)

    async def broadcast_tts(self, conf_id: str, audio_chunks: AsyncIterable[bytes]) -> None:
        """Broadcast synthesized speech to all conference participants."""
        await self._tts_injector.broadcast_to_conference(conf_id, audio_chunks)

    async def say(self, linked_id: str, text: str, tts: TtsAdapter) -> None:
        """
        Convenience: synthesize text and inject it directly.

        Tip: Pass a CachedTtsAdapter to avoid redundant API calls
        for repeated announcements (e.g. IVR greetings).

        Example::

            from dvgateway.adapters.tts import ElevenLabsAdapter, CachedTtsAdapter

            tts = CachedTtsAdapter(
                ElevenLabsAdapter(api_key="..."),
                provider="elevenlabs", cache_dir="./tts-cache",
            )
            await tts.warmup([{"text": "안녕하세요"}])
            await gw.say(linked_id, "안녕하세요", tts)  # cache hit
        """
        await self._tts_injector.inject_streaming(linked_id, tts.synthesize(text))

    async def broadcast_say(self, conf_id: str, text: str, tts: TtsAdapter) -> None:
        """Broadcast synthesized speech to a conference.

        Pass a CachedTtsAdapter for zero-cost repeated broadcasts.
        """
        await self._tts_injector.broadcast_to_conference(conf_id, tts.synthesize(text))

    # ─── Comfort Noise / Thinking Signals ─────────────────────────────────

    async def start_thinking(self, linked_id: str) -> None:
        """
        Notify the gateway that AI processing has started (STT → LLM → TTS).
        If comfort noise is enabled (GW_COMFORT_NOISE_ENABLED=true),
        low-level background audio will be injected into the call to prevent dead air.

        Can also be sent via the audio stream WebSocket:
            await audio_stream.send_thinking_start()

        Or via REST API:
            POST /api/v1/comfort/{linkedId}/start
        """
        await self._http.post(f"/api/v1/comfort/{_url_quote(linked_id, safe='')}/start", {})
        self._logger.debug({"linked_id": linked_id}, "Thinking signal: start")

    async def stop_thinking(self, linked_id: str) -> None:
        """
        Notify the gateway that AI processing has completed.
        Comfort noise injection will fade out and stop.
        """
        await self._http.post(f"/api/v1/comfort/{_url_quote(linked_id, safe='')}/stop", {})
        self._logger.debug({"linked_id": linked_id}, "Thinking signal: stop")

    # ─── VAD (Voice Activity Detection) Forwarding ────────────────────────

    async def post_vad(
        self,
        linked_id: str,
        side: Literal["caller", "callee"],
        speaking: bool,
    ) -> None:
        """Forward an authoritative VAD event to the gateway dashboard.

        The dashboard uses this to paint a reliable "speaking" indicator
        next to the caller / callee VU bar, replacing the RMS-threshold
        heuristic which is unreliable for half-duplex S2S sessions with
        AI ducking.

        Typical use: in an S2S pipeline, wire OpenAIRealtimeAdapter's
        ``on_speech_activity`` callback into this method so
        ``input_audio_buffer.speech_started`` / ``speech_stopped`` events
        reach the dashboard.

        Args:
            linked_id: Call session identifier.
            side: ``"caller"`` (customer) or ``"callee"`` (agent / AI).
            speaking: ``True`` on speech_started, ``False`` on speech_stopped.

        Example::

            def on_vad(ev):
                asyncio.ensure_future(
                    gw.post_vad(ev.linked_id, ev.side, ev.speaking)
                )
            realtime.on_speech_activity(on_vad)

        Fire-and-forget by convention — VAD is a UI hint, not critical state.
        """
        await self._http.post(
            f"/api/v1/vad/{_url_quote(linked_id, safe='')}",
            {"side": side, "speaking": speaking},
        )

    # ─── DTMF Collection ──────────────────────────────────────────────────

    async def mute_stt(self, linked_id: str, duration_ms: int | None = None) -> None:
        """Mute the gateway's STT audio pipeline for a call.

        While muted, inbound audio frames for ``linked_id`` are dropped
        before reaching the STT provider. Used by :meth:`collect_dtmf` so
        DTMF button tones are not transcribed as spurious text, but also
        callable directly for custom flows.

        Args:
            linked_id: Call session identifier.
            duration_ms: Auto-expiry in milliseconds. ``None`` (or 0)
                keeps the mute open until an explicit
                :meth:`unmute_stt`.
        """
        query = ""
        if duration_ms is not None and duration_ms > 0:
            query = f"?duration_ms={int(duration_ms)}"
        await self._http.post(
            f"/api/v1/stt/{_url_quote(linked_id, safe='')}/mute{query}",
            {},
        )
        self._logger.debug(
            {"linked_id": linked_id, "duration_ms": duration_ms},
            "STT muted",
        )

    async def unmute_stt(self, linked_id: str) -> None:
        """Explicitly unmute the STT pipeline for a call.

        Forces the mute reference counter to zero — even if other callers
        still hold mutes. Use :meth:`collect_dtmf` for reference-counted
        semantics; this is the escape hatch.
        """
        await self._http.delete(
            f"/api/v1/stt/{_url_quote(linked_id, safe='')}/mute"
        )
        self._logger.debug({"linked_id": linked_id}, "STT unmuted")

    async def collect_dtmf(
        self,
        linked_id: str,
        max_digits: int = 1,
        timeout_ms: int = 5_000,
        inter_digit_timeout_ms: int = 2_000,
        terminator: str = "#",
        mute_stt: bool = True,
    ) -> DTMFResult:
        """Collect DTMF digits from the caller over the callinfo stream.

        Completes when any of the following fires first:
          - ``max_digits`` digits have been accumulated
          - the ``terminator`` key is pressed
          - the first-key ``timeout_ms`` elapses before any digit
          - ``inter_digit_timeout_ms`` elapses after at least one digit

        Gateway prerequisites:
          - ``GW_DTMF_ENABLED=true`` (default) — AMI DTMF forwarding on.
          - ``GW_DTMF_PHASE_FILTER`` should include ``"end"`` (default).
            Only ``phase=="end"`` events are counted, mirroring IVR
            semantics where a digit is "entered" when released.

        Only events matching ``linked_id`` are accumulated. Concurrent
        calls to ``collect_dtmf`` on the same ``linked_id`` are
        independent collections; STT mute is reference-counted so the
        STT only resumes when the final concurrent collector releases.

        Args:
            linked_id: Call session identifier to collect from.
            max_digits: Max digits to collect (>=1). Completion fires
                when this count is reached (terminator not counted).
            timeout_ms: First-key timeout — how long to wait for the
                first digit before giving up (``timed_out=True,
                digits=""``).
            inter_digit_timeout_ms: After the first digit, how long to
                wait for the next digit before completing as
                ``timed_out=True`` with the partial digits.
            terminator: Key that ends the collection immediately.
                ``""`` disables the terminator feature. Default ``"#"``.
            mute_stt: When ``True`` (default), mute the STT pipeline for
                the duration of the collection so DTMF button tones are
                not transcribed. Set ``False`` to keep STT running
                (e.g. when using an out-of-band DTMF adapter that can't
                confuse the STT).

        Returns:
            :class:`DTMFResult` with ``digits``, ``timed_out``, and
            ``terminated_by_key`` populated.

        Example::

            result = await gw.collect_dtmf(
                linked_id,
                max_digits=4,
                timeout_ms=8_000,
                inter_digit_timeout_ms=3_000,
                terminator="#",
            )
            if result.timed_out:
                await gw.say(linked_id, "입력 시간이 초과되었습니다.", tts)
            else:
                await process_pin(result.digits)
        """
        import asyncio

        if max_digits < 1:
            raise ValueError("max_digits must be >= 1")

        loop = asyncio.get_event_loop()
        digits_buf: list[str] = []
        terminated = False
        next_digit_event = asyncio.Event()

        def on_dtmf(event: CallDtmfEvent) -> None:
            # Only count end-phase events and events for this linked_id.
            if event.linked_id != linked_id:
                return
            if event.phase != "end":
                return
            digit = event.digit
            if not digit:
                return
            nonlocal terminated
            if terminator and digit == terminator:
                terminated = True
                next_digit_event.set()
                return
            digits_buf.append(digit)
            next_digit_event.set()

        unsub = self.on("call:dtmf", on_dtmf)

        # Reference-counted STT mute. Only the first concurrent collector
        # actually sends the mute_stt REST call; only the last sends
        # unmute_stt. This lets multiple collect_dtmf() tasks on the same
        # linked_id coexist without one prematurely unmuting the other.
        mute_engaged = False
        if mute_stt:
            async with self._stt_mute_lock:
                prev = self._stt_mute_refs.get(linked_id, 0)
                self._stt_mute_refs[linked_id] = prev + 1
                if prev == 0:
                    try:
                        await self.mute_stt(linked_id, None)
                        mute_engaged = True
                    except Exception as exc:  # pragma: no cover - best-effort
                        self._logger.warn(
                            {"linked_id": linked_id, "err": str(exc)},
                            "collect_dtmf: mute_stt failed, continuing without mute",
                        )
                        # rollback ref so we don't leak
                        self._stt_mute_refs[linked_id] = prev
                        if self._stt_mute_refs[linked_id] == 0:
                            del self._stt_mute_refs[linked_id]
                        mute_stt = False
                else:
                    # Another collector already engaged the gateway mute;
                    # we only need to participate in ref counting.
                    mute_engaged = True

        first_timeout = max(0, timeout_ms) / 1000.0
        inter_timeout = max(0, inter_digit_timeout_ms) / 1000.0

        try:
            # Wait for the first digit (or terminator).
            try:
                await asyncio.wait_for(next_digit_event.wait(), timeout=first_timeout)
            except asyncio.TimeoutError:
                return DTMFResult(digits="", timed_out=True, terminated_by_key=False)

            if terminated:
                return DTMFResult(
                    digits="".join(digits_buf),
                    timed_out=False,
                    terminated_by_key=True,
                )
            if len(digits_buf) >= max_digits:
                return DTMFResult(
                    digits="".join(digits_buf[:max_digits]),
                    timed_out=False,
                    terminated_by_key=False,
                )

            # Subsequent digits: inter-digit timeout governs.
            while True:
                next_digit_event.clear()
                try:
                    await asyncio.wait_for(
                        next_digit_event.wait(), timeout=inter_timeout
                    )
                except asyncio.TimeoutError:
                    return DTMFResult(
                        digits="".join(digits_buf),
                        timed_out=True,
                        terminated_by_key=False,
                    )
                if terminated:
                    return DTMFResult(
                        digits="".join(digits_buf),
                        timed_out=False,
                        terminated_by_key=True,
                    )
                if len(digits_buf) >= max_digits:
                    return DTMFResult(
                        digits="".join(digits_buf[:max_digits]),
                        timed_out=False,
                        terminated_by_key=False,
                    )
        finally:
            try:
                unsub()
            except Exception:  # pragma: no cover - defensive
                pass
            if mute_stt and mute_engaged:
                async with self._stt_mute_lock:
                    remaining = self._stt_mute_refs.get(linked_id, 0) - 1
                    if remaining <= 0:
                        self._stt_mute_refs.pop(linked_id, None)
                        try:
                            await self.unmute_stt(linked_id)
                        except Exception as exc:  # pragma: no cover - best-effort
                            self._logger.warn(
                                {"linked_id": linked_id, "err": str(exc)},
                                "collect_dtmf: unmute_stt failed",
                            )
                    else:
                        self._stt_mute_refs[linked_id] = remaining
            # Suppress unused-loop warning for Python 3.10 linters.
            _ = loop

    # ─── Audio Playback ────────────────────────────────────────────────────

    async def play_audio(
        self,
        linked_id: str,
        url: str,
        loop: bool = False,
        interrupt_on_dtmf: bool = False,
        wait_for_completion: bool = True,
    ) -> PlayAudioResult:
        """Play an audio file from a URL into an active call.

        The gateway downloads the audio asset (auto-converting to 16kHz
        mono PCM via FFmpeg when needed) and injects it into the call's
        channel. Typical uses: IVR prompts, legal disclosures, on-hold
        music, pre-recorded announcements.

        Args:
            linked_id: Call session identifier.
            url: HTTP(S) URL to the audio asset (mp3/wav/ogg auto-converted).
            loop: Loop playback continuously until stopped. Default ``False``.
            interrupt_on_dtmf: End playback immediately when the caller
                presses any DTMF digit; the pressed digit is returned in
                :attr:`PlayAudioResult.interrupted_by_dtmf`. Default ``False``.
            wait_for_completion: When ``True`` (default), this call
                suspends until playback finishes (or is interrupted /
                stopped). When ``False``, the gateway returns 202 as soon
                as playback starts and this method returns immediately
                with ``completed=False``.

        Returns:
            :class:`PlayAudioResult`. When ``wait_for_completion=False``,
            only ``completed=False`` / ``duration_ms=0`` /
            ``interrupted_by_dtmf=None`` is returned — the "started"
            acknowledgement.

        Raises:
            ValueError: when ``url`` is empty.

        Example — legal notice with DTMF consent::

            res = await gw.play_audio(
                linked_id,
                url="https://cdn.example.com/legal-notice.mp3",
                interrupt_on_dtmf=True,
            )
            if res.interrupted_by_dtmf == "1":
                await process_consent(linked_id)
        """
        if not url:
            raise ValueError("url is required")
        body = {
            "url": url,
            "loop": bool(loop),
            "interruptOnDtmf": bool(interrupt_on_dtmf),
            "waitForCompletion": bool(wait_for_completion),
        }
        res = await self._http.post(
            f"/api/v1/play/{_url_quote(linked_id, safe='')}", body
        )
        data = res.data if isinstance(res.data, dict) else {}
        if not wait_for_completion:
            # 202 — gateway accepted the request, playback will proceed async.
            return PlayAudioResult(
                completed=False, interrupted_by_dtmf=None, duration_ms=0
            )
        raw_dtmf = data.get("interruptedByDtmf", "")
        dtmf = raw_dtmf if isinstance(raw_dtmf, str) and raw_dtmf != "" else None
        return PlayAudioResult(
            completed=bool(data.get("completed", False)),
            interrupted_by_dtmf=dtmf,
            duration_ms=int(data.get("durationMs", 0) or 0),
        )

    async def stop_audio(self, linked_id: str) -> None:
        """Stop any active audio playback on a call.

        No-op when nothing is playing. Safe to call concurrently with
        :meth:`play_audio` — the outstanding ``play_audio`` will return
        with ``completed=False``.
        """
        await self._http.delete(f"/api/v1/play/{_url_quote(linked_id, safe='')}")
        self._logger.debug({"linked_id": linked_id}, "Audio playback stopped")

    # ─── Call Control ──────────────────────────────────────────────────────

    async def hangup(self, linked_id: str) -> None:
        """Terminate an active call by linkedId.

        Sends AMI Hangup action to Asterisk via the gateway.
        """
        await self._http.post(f"/api/v1/calls/{_url_quote(linked_id, safe='')}/hangup", {})
        self._logger.debug({"linked_id": linked_id}, "Call hangup requested")

    async def redirect(
        self,
        linked_id: str,
        destination: str,
        context: str = "from-internal",
    ) -> None:
        """Transfer (redirect) an active call to a different extension.

        Sends AMI Redirect action to Asterisk via the gateway.
        """
        await self._http.post(f"/api/v1/calls/{_url_quote(linked_id, safe='')}/redirect", {
            "context": context,
            "exten": destination,
            "priority": 1,
        })
        self._logger.debug(
            {"linked_id": linked_id, "destination": destination, "context": context},
            "Call redirect requested",
        )

    async def warm_transfer(
        self,
        linked_id: str,
        destination: str,
        whisper_text: str = "",
        hold_audio_url: str = "",
        context: str = "from-internal",
        timeout_ms: int = 30_000,
    ) -> WarmTransferResult:
        """Warm-transfer an active call to an agent extension.

        The gateway originates a new leg to ``destination`` (in
        ``context``), optionally plays a whisper prompt to the agent,
        optionally plays hold audio to the caller, and bridges the two
        legs once the agent answers. If the agent does not answer before
        ``timeout_ms`` elapses the transfer is reported as timed out and
        the original call is left untouched.

        .. note::
           The gateway does not yet synthesize the ``whisper_text``
           prompt; the response's ``whisper_played`` flag will therefore
           typically be ``False`` in this SDK release. When gateway-side
           whisper synthesis lands, no SDK changes are required.

        Args:
            linked_id: Call session to transfer.
            destination: Agent extension / number to dial.
            whisper_text: Text to speak to the agent before bridging.
                Passed to the gateway, but currently ignored server-side
                (see note above).
            hold_audio_url: HTTP(S) URL of hold-music audio played to
                the caller while the agent is ringing.
            context: Dialplan context for the agent leg (default
                ``"from-internal"``).
            timeout_ms: How long to wait for the agent to answer, in
                milliseconds (must be > 0).

        Returns:
            :class:`WarmTransferResult` with ``connected`` / ``timed_out`` /
            ``error`` / ``agent_channel`` / ``bridge_id`` /
            ``whisper_played`` populated.

        Raises:
            ValueError: when ``destination`` is empty or ``timeout_ms``
                is not a positive integer.

        Example::

            res = await gw.warm_transfer(
                linked_id,
                destination="1001",
                whisper_text="VIP 고객입니다",
                hold_audio_url="https://cdn.example.com/hold.mp3",
                timeout_ms=30_000,
            )
            if res.connected:
                print("agent", res.agent_channel, "bridged", res.bridge_id)
            elif res.timed_out:
                await gw.say(linked_id, "담당자 연결에 실패했습니다.", tts)
        """
        if not destination:
            raise ValueError("destination is required")
        if timeout_ms <= 0:
            raise ValueError("timeout_ms must be > 0")

        body: dict[str, object] = {
            "destination": destination,
            "timeoutMs": int(timeout_ms),
        }
        if context:
            body["context"] = context
        if whisper_text:
            body["whisperText"] = whisper_text
        if hold_audio_url:
            body["holdAudioUrl"] = hold_audio_url

        res = await self._http.post(
            f"/api/v1/transfer/warm/{_url_quote(linked_id, safe='')}", body
        )
        data = res.data if isinstance(res.data, dict) else {}

        def _to_optional_str(v: object) -> str | None:
            return v if isinstance(v, str) and v != "" else None

        return WarmTransferResult(
            connected=bool(data.get("connected", False)),
            timed_out=bool(data.get("timedOut", False)),
            error=_to_optional_str(data.get("error", "")),
            agent_channel=_to_optional_str(data.get("agentChannel", "")),
            bridge_id=_to_optional_str(data.get("bridgeId", "")),
            whisper_played=bool(data.get("whisperPlayed", False)),
        )

    # ─── PBX Management ─────────────────────────────────────────────────

    async def apply_changes(self) -> dict:
        """Apply PBX configuration changes (required after callerID/extension changes)."""
        res = await self._http.post("/api/v1/pbx/apply-changes", {})
        return res.data

    async def click_to_call(
        self,
        caller: str,
        callee: str,
        cid_name: str = "",
        cid_number: str = "",
        account_code: str = "",
        custom_value_1: str = "",
        custom_value_2: str = "",
        custom_value_3: str = "",
    ) -> dict:
        """Initiate an outbound call via PBX click-to-call API."""
        body = {"caller": caller, "callee": callee}
        if cid_name:
            body["cidName"] = cid_name
        if cid_number:
            body["cidNumber"] = cid_number
        if account_code:
            body["accountCode"] = account_code
        if custom_value_1:
            body["customValue1"] = custom_value_1
        if custom_value_2:
            body["customValue2"] = custom_value_2
        if custom_value_3:
            body["customValue3"] = custom_value_3
        res = await self._http.post("/api/v1/pbx/click-to-call", body)
        self._logger.debug({"caller": caller, "callee": callee}, "Click-to-call requested")
        return res.data

    # ─── Call Forwarding (Diversions) ───────────────────────────────────

    async def get_diversions(self, extension: str, tenant_id: str = "") -> dict:
        """Get all forwarding rules for an extension."""
        query = f"?tenantId={_url_quote(tenant_id, safe='')}" if tenant_id else ""
        res = await self._http.get(f"/api/v1/diversions/{_url_quote(extension, safe='')}{query}")
        return res.data

    async def set_diversion(
        self,
        extension: str,
        cf_type: str,
        enable: str = "",
        destination: str = "",
        time_group: str = "",
        tenant_id: str = "",
    ) -> dict:
        """Set a forwarding rule (CFI/CFB/CFN/CFU)."""
        body = {}
        if enable:
            body["enable"] = enable
        if destination:
            body["destination"] = destination
        if time_group:
            body["timeGroup"] = time_group
        query = f"?tenantId={_url_quote(tenant_id, safe='')}" if tenant_id else ""
        res = await self._http.put(
            f"/api/v1/diversions/{_url_quote(extension, safe='')}/{cf_type}{query}", body
        )
        return res.data

    async def delete_diversion(self, extension: str, cf_type: str, tenant_id: str = "") -> dict:
        """Delete (disable + clear) a forwarding rule."""
        query = f"?tenantId={_url_quote(tenant_id, safe='')}" if tenant_id else ""
        res = await self._http.delete(
            f"/api/v1/diversions/{_url_quote(extension, safe='')}/{cf_type}{query}"
        )
        return res.data

    # ─── Caller ID ──────────────────────────────────────────────────────

    async def get_caller_id(self, extension: str) -> dict:
        """Get caller ID display for an extension."""
        res = await self._http.get(f"/api/v1/callerid/{_url_quote(extension, safe='')}")
        return res.data

    async def set_caller_id(
        self,
        extension: str,
        name: str = "",
        number: str = "",
        apply_changes: bool = False,
    ) -> dict:
        """Update external caller ID display (optionally auto-apply changes)."""
        body = {}
        if name:
            body["name"] = name
        if number:
            body["number"] = number
        if apply_changes:
            body["applyChanges"] = True
        res = await self._http.put(f"/api/v1/callerid/{_url_quote(extension, safe='')}", body)
        return res.data

    # ─── Early Media ────────────────────────────────────────────────────

    #: Reserved "extension" value addressing the tenant-wide **default**
    #: Early Media profile. Use with :meth:`get_early_media` /
    #: :meth:`set_early_media` (or the convenience wrappers
    #: :meth:`get_early_media_default` / :meth:`set_early_media_default`)
    #: to read or write the fallback profile played when a DID has no
    #: explicit per-DID configuration.
    #:
    #: The dialplan fallback chain is:
    #:
    #:   1. Per-DID profile (``earlymedia/{DID}/enabled == "yes"``)
    #:   2. This default profile (``earlymedia/_default/enabled == "yes"``)
    #:   3. Skip Early Media entirely
    #:
    #: The leading underscore guarantees no collision with real phone
    #: numbers (digits only by convention). Backend stores to::
    #:
    #:   AstDB:  /{tenant_id}/earlymedia/_default/{enabled,source,tts_*,audio_url}
    #:   File:   /var/spool/asterisk/{tenant_id}/pa/_default/pamsg.wav
    EARLY_MEDIA_DEFAULT_EXT: str = "_default"

    async def get_early_media(self, extension: str, tenant_id: str = "") -> dict:
        """Get Early Media config for an extension.

        Pass the phone number (digits only) for per-DID config, or the
        special string ``"_default"`` — exposed as
        :attr:`EARLY_MEDIA_DEFAULT_EXT` — to read the tenant-wide fallback
        profile. The returned dict has the same shape either way::

            {
              "enabled":     "yes" | "no",
              "source":      "tts" | "url" | "",
              "audioUrl":    str,
              "ttsText":     str,
              "ttsProvider": str,
              "ttsVoice":    str,
              "localPath":   str,   # where the converted WAV lives on disk
              "fileExists":  bool,
            }

        Fields that are not configured come back as empty strings;
        ``fileExists`` reflects whether the converted WAV is on disk.

        Example::

            # Per-DID
            cfg = await gw.get_early_media("07045144801")
            print(cfg["enabled"], cfg["source"], cfg["ttsText"])

            # Tenant-wide default
            default = await gw.get_early_media_default()
        """
        query = f"?tenantId={_url_quote(tenant_id, safe='')}" if tenant_id else ""
        res = await self._http.get(f"/api/v1/earlymedia/{_url_quote(extension, safe='')}{query}")
        return res.data

    async def set_early_media(
        self,
        extension: str,
        enabled: str = "",
        audio_url: str = "",
        tts: dict | None = None,
        tenant_id: str = "",
    ) -> dict:
        """Set Early Media config for an extension.

        Two source modes (mutually exclusive within one call):

        - ``audio_url``: gateway downloads the remote file and converts it
          once to an 8 kHz mono WAV via FFmpeg. The file is NOT re-downloaded
          per call — changing the upstream URL requires re-invoking this
          method so the cached WAV is regenerated.
        - ``tts``: gateway invokes the tenant's Cloud TTS provider (resolved
          from the dashboard API-keys config) and saves the synthesized PCM
          as an 8 kHz WAV. ``provider`` / ``voice`` overrides are optional.

        Both modes target the same on-disk path::

            /var/spool/asterisk/{tenant_id}/pa/{extension}/pamsg.wav

        Passing ``extension=EARLY_MEDIA_DEFAULT_EXT`` (``"_default"``)
        writes the tenant-wide default profile. The dialplan
        ``[dvgateway-pa-noa]`` context falls back to this profile whenever
        an incoming DID has no explicit per-DID configuration — so one
        default greeting automatically applies to every unconfigured line.

        To disable a profile without deleting its data, pass
        ``enabled="no"``. To regenerate a TTS asset after changing voice
        or text, pass the full ``tts`` dict again.

        Args:
            extension: Phone number in digits (e.g. ``"07045144801"``) or
                the special value :attr:`EARLY_MEDIA_DEFAULT_EXT` for the
                tenant default.
            enabled: ``"yes"`` or ``"no"``.
            audio_url: Remote audio URL (mp3/wav/ogg — auto-converted).
            tts: dict with keys:

                - ``text`` (required): text to synthesize
                - ``provider`` (optional): ``google`` / ``openai`` /
                  ``elevenlabs`` / ``azure`` / ``aws`` / ``gemini`` /
                  ``cosyvoice`` / ``qwen``
                - ``voice`` (optional): voice ID override
            tenant_id: Tenant ID (auto from JWT if omitted).

        Example — TTS default that every inbound call hears::

            await gw.set_early_media(
                gw.EARLY_MEDIA_DEFAULT_EXT,
                enabled="yes",
                tts={
                    "text": "안녕하세요, 잠시만 기다려 주세요.",
                    "provider": "openai",
                    "voice": "nova",
                },
            )

        Example — per-DID override that wins over the default::

            await gw.set_early_media(
                "07045144801",
                enabled="yes",
                audio_url="https://cdn.example.com/vip-greeting.mp3",
            )
        """
        body: dict = {}
        if enabled:
            body["enabled"] = enabled
        if audio_url:
            body["audioUrl"] = audio_url
        if tts:
            body["tts"] = tts
        query = f"?tenantId={_url_quote(tenant_id, safe='')}" if tenant_id else ""
        res = await self._http.put(f"/api/v1/earlymedia/{_url_quote(extension, safe='')}{query}", body)
        return res.data

    async def get_early_media_default(self, tenant_id: str = "") -> dict:
        """Convenience: read the tenant-wide default Early Media profile.

        Equivalent to ``get_early_media(EARLY_MEDIA_DEFAULT_EXT, tenant_id)``.
        See :meth:`get_early_media` for the returned payload shape.
        """
        return await self.get_early_media(self.EARLY_MEDIA_DEFAULT_EXT, tenant_id)

    async def set_early_media_default(
        self,
        enabled: str = "",
        audio_url: str = "",
        tts: dict | None = None,
        tenant_id: str = "",
    ) -> dict:
        """Convenience: write the tenant-wide default Early Media profile.

        Equivalent to
        ``set_early_media(EARLY_MEDIA_DEFAULT_EXT, enabled=..., audio_url=..., tts=..., tenant_id=...)``.

        Example::

            # One default greeting for every unconfigured DID
            await gw.set_early_media_default(
                enabled="yes",
                tts={"text": "고객센터 상담원 연결 중입니다."},
            )

            # Disable the default (per-DID entries are unaffected)
            await gw.set_early_media_default(enabled="no")
        """
        return await self.set_early_media(
            self.EARLY_MEDIA_DEFAULT_EXT,
            enabled=enabled,
            audio_url=audio_url,
            tts=tts,
            tenant_id=tenant_id,
        )

    # ─── Outbound Campaigns ─────────────────────────────────────────────

    async def list_campaigns(self) -> dict:
        """List all outbound call campaigns."""
        res = await self._http.get("/api/v1/pbx/campaigns")
        return res.data

    async def create_campaign(self, campaign: dict) -> dict:
        """Create a new campaign (scheduled, bulk, or recurring)."""
        res = await self._http.post("/api/v1/pbx/campaigns", campaign)
        return res.data

    async def get_campaign(self, campaign_id: str) -> dict:
        """Get campaign details."""
        res = await self._http.get(f"/api/v1/pbx/campaigns/{_url_quote(campaign_id, safe='')}")
        return res.data

    async def update_campaign(self, campaign_id: str, updates: dict) -> dict:
        """Update a campaign."""
        res = await self._http.put(
            f"/api/v1/pbx/campaigns/{_url_quote(campaign_id, safe='')}", updates
        )
        return res.data

    async def delete_campaign(self, campaign_id: str) -> dict:
        """Delete a campaign."""
        res = await self._http.delete(f"/api/v1/pbx/campaigns/{_url_quote(campaign_id, safe='')}")
        return res.data

    async def start_campaign(self, campaign_id: str) -> dict:
        """Start campaign execution."""
        res = await self._http.post(
            f"/api/v1/pbx/campaigns/{_url_quote(campaign_id, safe='')}/start", {}
        )
        return res.data

    async def pause_campaign(self, campaign_id: str) -> dict:
        """Pause a running campaign."""
        res = await self._http.post(
            f"/api/v1/pbx/campaigns/{_url_quote(campaign_id, safe='')}/pause", {}
        )
        return res.data

    async def resume_campaign(self, campaign_id: str) -> dict:
        """Resume a paused campaign."""
        res = await self._http.post(
            f"/api/v1/pbx/campaigns/{_url_quote(campaign_id, safe='')}/resume", {}
        )
        return res.data

    async def cancel_campaign(self, campaign_id: str) -> dict:
        """Cancel a running campaign."""
        res = await self._http.post(
            f"/api/v1/pbx/campaigns/{_url_quote(campaign_id, safe='')}/cancel", {}
        )
        return res.data

    async def get_campaign_results(self, campaign_id: str) -> dict:
        """Get campaign call results."""
        res = await self._http.get(
            f"/api/v1/pbx/campaigns/{_url_quote(campaign_id, safe='')}/results"
        )
        return res.data

    # ─── Mid-Level: Call Events ─────────────────────────────────────────────

    def on_call_event(
        self,
        handler: Callable[[CallEvent], None | Awaitable[None]],
    ) -> Unsubscribe:
        """Subscribe to all call lifecycle events. Returns an unsubscribe function."""
        return self._call_events.on(handler)

    def on(
        self,
        event_type: str,
        handler: Callable[..., None | Awaitable[None]],
    ) -> Unsubscribe:
        """Subscribe to a specific call event type."""
        return self._call_events.on_type(event_type, handler)

    def on_tts_complete(
        self,
        handler: Callable[..., None | Awaitable[None]],
    ) -> Unsubscribe:
        """Subscribe to the ``tts:complete`` event.

        Fired when an injected TTS playback finishes streaming into the call.
        Convenience sugar over ``on("tts:complete", handler)`` for the common
        "wait for AI reply to finish, then do X" pattern in voice bots.

        Example::

            def after_greeting(ev):
                # ev is a TTSCompleteEvent
                if ev.linked_id != current_call:
                    return
                asyncio.ensure_future(gw.inject_tts(current_call, menu_audio()))

            gw.on_tts_complete(after_greeting)

        See :class:`dvgateway.types.TTSCompleteEvent` for payload details
        and timing semantics.
        """
        return self._call_events.on_type("tts:complete", handler)

    # ─── Session Management ─────────────────────────────────────────────────

    async def list_sessions(self) -> list[CallSession]:
        """List all currently active call sessions."""
        return await self._sessions.list_sessions()

    async def list_sessions_by_tenant(self, tenant_id: str) -> list[CallSession]:
        """List active call sessions filtered by tenant ID."""
        return await self._sessions.list_sessions_by_tenant(tenant_id)

    async def update_session_meta(self, linked_id: str, meta: dict[str, str]) -> None:
        """Update metadata on a session."""
        await self._sessions.update_metadata(linked_id, meta)

    # ─── Minutes / Transcripts ──────────────────────────────────────────────

    async def submit_transcript(self, conf_id: str, result: TranscriptResult) -> None:
        """Submit an STT transcript result to the gateway's minutes store."""
        await self._minutes.submit_transcript(conf_id, result)

    async def download_minutes(
        self,
        conf_id: str,
        format: Literal["json", "txt"] = "txt",
    ) -> str:
        """Download conference minutes in JSON or plain-text format."""
        return await self._minutes.download_minutes(conf_id, format)

    def auto_submit_transcripts(
        self,
        conf_id: str,
    ) -> Callable[[TranscriptResult], Awaitable[None]]:
        """Returns a function that auto-submits final transcripts to minutes."""
        return self._minutes.create_auto_submitter(conf_id)

    # ─── Lifecycle ──────────────────────────────────────────────────────────

    def close(self) -> None:
        """Gracefully close all WebSocket connections and release resources."""
        self._ws_pool.close_all()
        self._logger.info({}, "DVGatewayClient closed")

    # ─── Private helpers ────────────────────────────────────────────────────

    def _normalize_base_url(self, opts: DVGatewayOptions) -> str:
        url = opts.base_url.rstrip("/")
        if opts.security.force_tls:
            if url.startswith("http://") and not self._should_skip_tls(url):
                self._logger: Logger = opts.logger or create_logger(level="info")  # type: ignore[assignment]
                url = url.replace("http://", "https://", 1)
        return url

    @staticmethod
    def _should_skip_tls(url: str) -> bool:
        """Return True if force_tls should NOT upgrade this URL to https://.

        TLS upgrade is skipped for:
          - IP addresses (any): TLS certificates are domain-based. Connecting
            to an IP address (public or private) via HTTPS almost never works
            because there's no valid certificate for raw IP addresses.
            Users who connect by IP always mean plain HTTP.
          - Loopback hostnames: localhost, *.local
        """
        from ipaddress import ip_address
        from urllib.parse import urlparse

        host = urlparse(url).hostname or ""

        # Loopback hostnames
        if host in ("localhost", "::1") or host.endswith(".local"):
            return True

        # Any IP address (public or private) — TLS certs don't cover raw IPs
        try:
            ip_address(host)
            return True  # valid IP → skip TLS
        except ValueError:
            return False  # not an IP → domain name → force_tls applies
