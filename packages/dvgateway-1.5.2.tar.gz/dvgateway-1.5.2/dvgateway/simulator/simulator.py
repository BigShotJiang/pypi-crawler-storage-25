"""DVGateway SDK Simulator (Python).

Drives an existing ``DVGatewayClient`` pipeline from a local audio file
without opening a real connection to a gateway or placing a real phone
call. Designed for unit tests, CI, docs "Try it" widgets, and developer
onboarding — ``python bot.py`` should let someone hear their voice bot
answer a recorded customer inquiry within seconds of ``pip install``.

Implementation strategy: :meth:`DVGatewayClient.simulate` installs three
simulated routes on the internal ``WsPool``:

  1. ``/api/v1/ws/callinfo`` — emits one synthetic ``call:new`` event
     for the simulated call, then a ``call:ended`` event after the
     audio finishes plus a grace period.
  2. ``/api/v1/ws/stream?linkedid={id}`` — streams slin16 frames from
     the caller's audio file, paced at 20 ms/frame by default. Any
     inbound ``thinking:start/stop`` signals from the pipeline are
     silently acknowledged.
  3. ``/api/v1/ws/tts/{linked_id}`` — captures injected TTS bytes into
     an in-memory buffer. Retrievable via :meth:`captured_tts_bytes` or
     written out via :meth:`save_tts`.

The pipeline code under test doesn't change — the same five-line
``gw.pipeline().stt().llm().tts().start()`` runs. The simulator drives
call progression on its own clock so a call still completes cleanly
even when nothing subscribes to the audio stream (useful for unit tests
of event handling).
"""
from __future__ import annotations

import asyncio
import secrets
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Callable

from dvgateway.simulator.wav import (
    SIMULATOR_SAMPLE_RATE,  # re-export convenience
    read_slin16_file,
    write_slin16_wav,
)
from dvgateway.transport.ws_pool import (
    SimulatedRoute,
    SimulatedSocket,
    WsPool,
    WsSubscription,
)
from dvgateway.types import CallSession, Logger

#: 20 ms slin16 frame — matches the gateway's native frame size.
_FRAME_BYTES = 640
_FRAME_DURATION_S = 0.020

__all__ = ["SimulateOptions", "SimulatedCall", "create_simulated_call", "SIMULATOR_SAMPLE_RATE"]


@dataclass
class SimulateOptions:
    """Options passed to :meth:`DVGatewayClient.simulate`.

    Attributes:
        audio_file: Path to the caller's audio. Accepts 16 kHz mono
            16-bit PCM WAV or raw slin16 PCM (no header). Convert
            arbitrary sources with::

                ffmpeg -i input.mp3 -ar 16000 -ac 1 -sample_fmt s16 caller.wav

        linked_id: Unique call identifier. Auto-generated if omitted.
        caller: Synthetic CallerID number shown to the pipeline.
        caller_name: Synthetic CallerID name.
        callee: Dialled extension shown to the pipeline.
        did: DID main number.
        tenant_id: Tenant identifier propagated into ``call:new``.
        realtime: Pace playback at 20 ms/frame (default, mimics a real
            call). Set to ``False`` to flush all frames as fast as
            possible — useful in CI.
        hangup_delay_ms: Delay between end-of-caller-audio and the
            synthetic ``call:ended`` event. Default: 5000.
        on_tts: Optional hook invoked for each captured TTS frame.
    """

    audio_file: str | Path
    linked_id: str | None = None
    caller: str | None = None
    caller_name: str | None = None
    callee: str | None = None
    did: str | None = None
    tenant_id: str | None = None
    realtime: bool = True
    hangup_delay_ms: int = 5_000
    on_tts: Callable[[bytes], None] | None = None


@dataclass
class SimulatedCall:
    """Handle returned from :meth:`DVGatewayClient.simulate`.

    The handle is backed by a live ``_SimulatorState`` — methods
    delegate to it. Kept as a dataclass for a clean public surface.
    """

    linked_id: str
    session: CallSession
    _state: "_SimulatorState" = field(repr=False)

    async def wait_for_end(self) -> None:
        """Wait for the caller audio to drain and the hangup to fire."""
        await self._state.wait_for_end()

    async def stop(self) -> None:
        """Terminate the simulation early; emits ``call:ended``."""
        await self._state.stop()

    def captured_tts_bytes(self) -> bytes:
        """Return the concatenated captured-TTS PCM (slin16)."""
        return self._state.captured_bytes()

    async def save_tts(self, output_path: str | Path) -> None:
        """Write captured TTS as a 16 kHz mono WAV file."""
        write_slin16_wav(output_path, self.captured_tts_bytes())


def _generate_linked_id() -> str:
    """Pick a linkedId that won't collide with real gateway IDs."""
    return f"sim-{int(time.time() * 1000):x}-{secrets.token_hex(4)}"


def _build_session(opts: SimulateOptions, linked_id: str) -> CallSession:
    """Synthetic CallSession from user overrides + sensible defaults."""
    return CallSession(
        linked_id=linked_id,
        dir="both",
        caller=opts.caller or "+1-555-0100",
        caller_name=opts.caller_name or "Simulated Caller",
        callee=opts.callee or "100",
        did=opts.did or opts.callee or "100",
        started_at=datetime.now(),
        stream_url=f"sim://audio/{linked_id}",
        tenant_id=opts.tenant_id,
    )


async def create_simulated_call(
    ws_pool: WsPool,
    logger: Logger,
    opts: SimulateOptions,
) -> SimulatedCall:
    """Build a :class:`SimulatedCall`, install simulated routes, and
    start the call clock. Used internally by
    :meth:`DVGatewayClient.simulate`.
    """
    linked_id = opts.linked_id or _generate_linked_id()
    session = _build_session(opts, linked_id)

    pcm = read_slin16_file(opts.audio_file)
    if not pcm:
        raise ValueError(f"simulator: audio file is empty: {opts.audio_file}")

    state = _SimulatorState(
        logger=logger,
        linked_id=linked_id,
        session=session,
        pcm=pcm,
        realtime=opts.realtime,
        hangup_delay_ms=opts.hangup_delay_ms,
    )

    call_info_route = _CallInfoRoute(state)
    audio_route = _AudioRoute(state, linked_id)
    tts_route = _TtsCaptureRoute(state, linked_id, opts.on_tts)

    disposers = [
        ws_pool.add_simulated_route(call_info_route),
        ws_pool.add_simulated_route(audio_route),
        ws_pool.add_simulated_route(tts_route),
    ]

    def _on_stop() -> None:
        for d in disposers:
            try:
                d()
            except Exception:  # noqa: BLE001 — disposer best-effort
                pass

    state.on_stop = _on_stop
    state.start()

    return SimulatedCall(linked_id=linked_id, session=session, _state=state)


# ─── Private implementation ──────────────────────────────────────────


class _SimulatorState:
    """Shared clock + buffer across the three simulated routes.

    Each route holds a reference and pushes into the same state so
    multiple subscribers (e.g. dashboard + pipeline) see consistent
    frame positions.
    """

    def __init__(
        self,
        logger: Logger,
        linked_id: str,
        session: CallSession,
        pcm: bytes,
        realtime: bool,
        hangup_delay_ms: int,
    ) -> None:
        self._logger = logger
        self._linked_id = linked_id
        self._session = session
        self._pcm = pcm
        self._realtime = realtime
        self._hangup_delay_s = hangup_delay_ms / 1000.0
        self._total_frames = (len(pcm) + _FRAME_BYTES - 1) // _FRAME_BYTES
        self._frame_index = 0

        # WsSubscription isn't hashable (mutable dataclass) so we key by
        # id(sub) in dicts. Fine for O(1) lookup and we never leak keys
        # outside the route lifetime.
        self._callinfo_subs: dict[int, WsSubscription] = {}
        self._callinfo_delivered: set[int] = set()
        self._audio_subs: dict[int, WsSubscription] = {}
        self._captured: list[bytes] = []

        self._call_ended = False
        self._stopped = False
        self._started_at = 0.0
        self._end_event = asyncio.Event()
        self._playback_task: asyncio.Task[None] | None = None
        self._hangup_task: asyncio.Task[None] | None = None

        import json as _json

        self._call_new_payload = _json.dumps({
            "event": "call:new",
            "linkedId": linked_id,
            "dir": session.dir,
            "caller": session.caller,
            "callerName": session.caller_name,
            "callee": session.callee,
            "did": session.did,
            "streamUrl": session.stream_url,
            "tenantId": session.tenant_id,
        }).encode("utf-8")

        self.on_stop: Callable[[], None] = lambda: None

    # ── Lifecycle ─────────────────────────────────────────────────

    def start(self) -> None:
        self._started_at = time.monotonic()
        self._playback_task = asyncio.ensure_future(self._playback_loop())

    async def _playback_loop(self) -> None:
        try:
            while not self._stopped and self._frame_index < self._total_frames:
                self._push_frame()
                if self._realtime:
                    await asyncio.sleep(_FRAME_DURATION_S)
                else:
                    # Yield to the event loop so subscribers get a
                    # chance to process each frame without starving
                    # other tasks.
                    await asyncio.sleep(0)
            if not self._stopped:
                await self._on_playback_complete()
        except asyncio.CancelledError:
            # Expected when stop() is called — swallow.
            pass

    def _push_frame(self) -> None:
        start = self._frame_index * _FRAME_BYTES
        end = min(start + _FRAME_BYTES, len(self._pcm))
        frame = self._pcm[start:end]
        # Copy per subscriber for safety — consumers may buffer slices.
        for sub in list(self._audio_subs.values()):
            sub.on_message(bytes(frame))
        self._frame_index += 1

    async def _on_playback_complete(self) -> None:
        # Close audio streams so STT adapters see EOF.
        for sub in list(self._audio_subs.values()):
            if sub.on_close:
                sub.on_close()
        if self._hangup_delay_s <= 0:
            self._emit_call_ended(time.monotonic() - self._started_at)
            self._end_event.set()
            return
        self._hangup_task = asyncio.ensure_future(self._delayed_hangup())

    async def _delayed_hangup(self) -> None:
        try:
            await asyncio.sleep(self._hangup_delay_s)
            if not self._stopped:
                self._emit_call_ended(time.monotonic() - self._started_at)
                self._end_event.set()
        except asyncio.CancelledError:
            pass

    async def stop(self) -> None:
        if self._stopped:
            return
        self._stopped = True
        for task in (self._playback_task, self._hangup_task):
            if task and not task.done():
                task.cancel()
        self._emit_call_ended(0.0)
        self._end_event.set()
        self.on_stop()

    async def wait_for_end(self) -> None:
        await self._end_event.wait()

    # ── Route attachment ─────────────────────────────────────────

    def attach_callinfo(self, sub: WsSubscription) -> None:
        self._callinfo_subs[id(sub)] = sub
        asyncio.get_event_loop().call_soon(self._deliver_call_new, sub)

    def detach_callinfo(self, sub: WsSubscription) -> None:
        self._callinfo_subs.pop(id(sub), None)

    def _deliver_call_new(self, sub: WsSubscription) -> None:
        if self._stopped:
            return
        sub_key = id(sub)
        if sub_key in self._callinfo_delivered:
            return
        self._callinfo_delivered.add(sub_key)
        sub.on_message(self._call_new_payload)
        self._logger.info({"linked_id": self._linked_id}, "simulator: call:new delivered")

    def attach_audio(self, sub: WsSubscription) -> None:
        self._audio_subs[id(sub)] = sub

    def detach_audio(self, sub: WsSubscription) -> None:
        self._audio_subs.pop(id(sub), None)

    def capture_tts(self, chunk: bytes) -> None:
        self._captured.append(bytes(chunk))

    def captured_bytes(self) -> bytes:
        return b"".join(self._captured)

    # ── Events ────────────────────────────────────────────────────

    def _emit_call_ended(self, duration_sec: float) -> None:
        if self._call_ended:
            return
        self._call_ended = True
        import json as _json

        payload = _json.dumps({
            "event": "call:ended",
            "linkedId": self._linked_id,
            "duration": duration_sec,
        }).encode("utf-8")
        for sub in list(self._callinfo_subs.values()):
            sub.on_message(payload)
        self._logger.info(
            {"linked_id": self._linked_id, "duration_sec": duration_sec},
            "simulator: call:ended delivered",
        )


class _CallInfoRoute:
    """Simulated route for ``/api/v1/ws/callinfo``."""

    def __init__(self, state: _SimulatorState) -> None:
        self._state = state

    def matches(self, path: str, params: dict[str, str]) -> bool:
        return path == "/api/v1/ws/callinfo"

    def on_subscribe(self, sub: WsSubscription) -> SimulatedSocket:
        self._state.attach_callinfo(sub)
        return _CallInfoSocket(self._state, sub)


class _CallInfoSocket:
    def __init__(self, state: _SimulatorState, sub: WsSubscription) -> None:
        self._state = state
        self._sub = sub

    def send(self, data: bytes) -> None:
        # callinfo is server → client only
        pass

    def send_text(self, text: str) -> None:
        pass

    def close(self) -> None:
        self._state.detach_callinfo(self._sub)


class _AudioRoute:
    """Simulated route for ``/api/v1/ws/stream?linkedid={linked_id}``."""

    def __init__(self, state: _SimulatorState, linked_id: str) -> None:
        self._state = state
        self._linked_id = linked_id

    def matches(self, path: str, params: dict[str, str]) -> bool:
        return path == "/api/v1/ws/stream" and params.get("linkedid") == self._linked_id

    def on_subscribe(self, sub: WsSubscription) -> SimulatedSocket:
        self._state.attach_audio(sub)
        return _AudioSocket(self._state, sub, self._linked_id)


class _AudioSocket:
    def __init__(self, state: _SimulatorState, sub: WsSubscription, linked_id: str) -> None:
        self._state = state
        self._sub = sub
        self._linked_id = linked_id

    def send(self, data: bytes) -> None:
        # Pipeline does not send binary on the inbound stream WS.
        pass

    def send_text(self, text: str) -> None:
        # thinking:start / thinking:stop — log only, no side effects
        pass

    def close(self) -> None:
        self._state.detach_audio(self._sub)


class _TtsCaptureRoute:
    """Simulated route for ``/api/v1/ws/tts/{linked_id}`` — captures sends."""

    def __init__(
        self,
        state: _SimulatorState,
        linked_id: str,
        on_tts: Callable[[bytes], None] | None,
    ) -> None:
        self._state = state
        self._path = f"/api/v1/ws/tts/{linked_id}"
        self._on_tts = on_tts

    def matches(self, path: str, params: dict[str, str]) -> bool:
        return path == self._path

    def on_subscribe(self, sub: WsSubscription) -> SimulatedSocket:
        return _TtsSocket(self._state, self._on_tts)


class _TtsSocket:
    def __init__(
        self,
        state: _SimulatorState,
        on_tts: Callable[[bytes], None] | None,
    ) -> None:
        self._state = state
        self._on_tts = on_tts

    def send(self, data: bytes) -> None:
        self._state.capture_tts(data)
        if self._on_tts:
            try:
                self._on_tts(data)
            except Exception:  # noqa: BLE001 — user callback, don't crash playback
                pass

    def send_text(self, text: str) -> None:
        # TTS WS is binary-only.
        pass

    def close(self) -> None:
        pass
