"""DVGateway SDK simulator — run voice-bot code without a gateway or phone.

Exports:
    SimulateOptions — parameters for :meth:`DVGatewayClient.simulate`.
    SimulatedCall   — handle returned from simulate().
"""
from dvgateway.simulator.simulator import (
    SimulateOptions,
    SimulatedCall,
    create_simulated_call,
)
from dvgateway.simulator.wav import (
    SIMULATOR_SAMPLE_RATE,
    read_slin16_file,
    write_slin16_wav,
)

__all__ = [
    "SimulateOptions",
    "SimulatedCall",
    "create_simulated_call",
    "SIMULATOR_SAMPLE_RATE",
    "read_slin16_file",
    "write_slin16_wav",
]
