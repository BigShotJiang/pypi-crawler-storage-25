"""Minimal WAV file reader/writer for the SDK simulator.

Supports the narrow format needed by DVGateway simulation:

    PCM (format code 1), 16-bit little-endian, mono, 16 kHz.

Also accepts raw slin16 files (no RIFF header) — any file whose first
four bytes are not ``RIFF`` is treated as a raw slin16 stream. This lets
callers point ``audio_file`` at either a standard WAV asset or a raw PCM
capture without juggling conversions themselves.
"""
from __future__ import annotations

import struct
from pathlib import Path

#: Target sample rate for all gateway audio (slin16).
SIMULATOR_SAMPLE_RATE: int = 16_000


def read_slin16_file(path: str | Path) -> bytes:
    """Read a WAV or raw slin16 file into 16-bit LE PCM bytes.

    The returned bytes can be sliced into 640-byte frames directly.

    Raises:
        ValueError: If the file is a WAV with an unsupported format
            (non-PCM, non-mono, or sample rate != 16 kHz).
    """
    data = Path(path).read_bytes()
    return parse_slin16(data)


def parse_slin16(data: bytes) -> bytes:
    """Parse in-memory bytes; same rules as :func:`read_slin16_file`."""
    if len(data) < 4 or data[:4] != b"RIFF":
        # Not a RIFF container — treat as raw slin16 PCM.
        return data

    if data[8:12] != b"WAVE":
        raise ValueError("simulator: file starts with RIFF but is not a WAVE")

    offset = 12
    audio_format = 0
    num_channels = 0
    sample_rate = 0
    bits_per_sample = 0
    pcm: bytes | None = None

    while offset + 8 <= len(data):
        chunk_id = data[offset : offset + 4]
        (size,) = struct.unpack_from("<I", data, offset + 4)
        body = data[offset + 8 : offset + 8 + size]

        if chunk_id == b"fmt ":
            audio_format, num_channels, sample_rate = struct.unpack_from("<HHI", body, 0)
            (bits_per_sample,) = struct.unpack_from("<H", body, 14)
        elif chunk_id == b"data":
            pcm = body
            break

        # Chunks are word-aligned — odd sizes carry a trailing pad byte.
        offset += 8 + size + (size % 2)

    if pcm is None:
        raise ValueError("simulator: WAV file has no data chunk")
    if audio_format != 1:
        raise ValueError(f"simulator: unsupported WAV format code {audio_format} (need PCM=1)")
    if num_channels != 1:
        raise ValueError(f"simulator: unsupported channel count {num_channels} (need mono)")
    if sample_rate != SIMULATOR_SAMPLE_RATE:
        raise ValueError(
            f"simulator: unsupported sample rate {sample_rate} Hz (need {SIMULATOR_SAMPLE_RATE} Hz); "
            f"convert with: ffmpeg -i input.wav -ar 16000 -ac 1 -sample_fmt s16 output.wav"
        )
    if bits_per_sample != 16:
        raise ValueError(f"simulator: unsupported bit depth {bits_per_sample} (need 16)")

    return pcm


def write_slin16_wav(path: str | Path, pcm: bytes) -> None:
    """Wrap raw 16 kHz mono slin16 PCM into a minimal WAV container and
    write it to ``path``. Used by :meth:`SimulatedCall.save_tts` so
    captured TTS can be played back in any audio tool.
    """
    byte_rate = SIMULATOR_SAMPLE_RATE * 2  # 16-bit mono
    header = bytearray(44)

    header[0:4] = b"RIFF"
    struct.pack_into("<I", header, 4, 36 + len(pcm))
    header[8:12] = b"WAVE"

    header[12:16] = b"fmt "
    struct.pack_into("<I", header, 16, 16)                 # fmt chunk size
    struct.pack_into("<H", header, 20, 1)                  # PCM
    struct.pack_into("<H", header, 22, 1)                  # mono
    struct.pack_into("<I", header, 24, SIMULATOR_SAMPLE_RATE)
    struct.pack_into("<I", header, 28, byte_rate)
    struct.pack_into("<H", header, 32, 2)                  # block align
    struct.pack_into("<H", header, 34, 16)                 # bits per sample

    header[36:40] = b"data"
    struct.pack_into("<I", header, 40, len(pcm))

    Path(path).write_bytes(bytes(header) + pcm)
