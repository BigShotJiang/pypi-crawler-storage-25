"""Evaluation entry point for COMBO.

Single unified path: always full-text, always combo-seg segmenter. Results are
written to ``<language_output_dir>/results/`` — the same directory the training
pipeline writes, so ``tools/hf-update-card.py`` picks them up automatically.

An ``eval_fulltext_<timestamp>.json`` is always written as history. When the
new run beats the existing ``results_best.json`` on ``config.training.metric_for_best``
(in the ``<best_model_split>_fulltext_metrics.f1`` table), ``results_best.json``
is overwritten — matching trainer semantics.
"""

import argparse
import json
from datetime import datetime
from pathlib import Path
from typing import Any

import torch
from transformers import AutoTokenizer

from combo.config import load_config
from combo.data import (
    CoNLLUReader,
    LabelEncoder,
    CharVocab,
    UDDataset,
    create_dataloaders,
)
from combo.data.label_encoder import MorphoEncoder
from combo.evaluation import Evaluator
from combo.evaluation import conll18_ud_eval
from combo.model import UDParser
from combo.segmenters import make_segmenter
from combo.utils import get_device


def find_gold_test_file(config) -> Path:
    """Find the gold test CoNLL-U file for the configured language/treebank."""
    ud_path = Path(config.data.ud_path)
    for treebank in config.data.treebanks:
        treebank_dir = ud_path / f"UD_{config.data.language}-{treebank}"
        test_files = list(treebank_dir.glob("*-test.conllu"))
        if test_files:
            return test_files[0]
    raise FileNotFoundError(
        f"No test file found for {config.data.language} in {config.data.treebanks}"
    )


def derive_task_config_path(model_id_or_path: str) -> Path | None:
    """Derive a task config path from a model ID/path using the naming convention.

    ``clarin-pl/combo-nlp-xlm-roberta-base-polish-pdb-ud2.17``
        → ``config/tasks/combo-nlp-xlm-roberta-base-polish-pdb-ud2.17.yaml``
    """
    model_name = Path(model_id_or_path).name  # handles both "org/model" and "/local/path/model"
    candidate = Path("config/tasks") / f"{model_name}.yaml"
    return candidate if candidate.exists() else None


def combo_seg_model_id(repo_id: str) -> str:
    """Derive combo-seg model ID from combo-nlp repo ID."""
    return repo_id.replace("combo-nlp", "combo-seg")


def main():
    parser = argparse.ArgumentParser(
        description="Evaluate COMBO: full-text (segmentation + parsing) with combo-seg.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Re-evaluate a trained model (checkpoint, encoders resolved from pipeline output)
  combo-nlp-evaluate --task-config config/tasks/combo-nlp-xlm-roberta-base-polish-pdb-ud2.17.yaml

  # Re-evaluate a published model (task config derived from HF model ID)
  combo-nlp-evaluate --model clarin-pl/combo-nlp-xlm-roberta-base-polish-pdb-ud2.17

  # Compare two CoNLL-U files directly (no model needed)
  combo-nlp-evaluate --gold-file gold.conllu --predictions-file predicted.conllu
""",
    )

    # File comparison mode (no model needed)
    parser.add_argument(
        "--gold-file", type=Path, default=None,
        help="Gold CoNLL-U file for direct file comparison (no model needed)",
    )
    parser.add_argument(
        "--predictions-file", type=Path, default=None,
        help="Predicted CoNLL-U file for direct file comparison",
    )

    # Model source — either --model (HF ID or local path) or --task-config (or both)
    parser.add_argument(
        "--model", type=str, default=None,
        help="Model: HuggingFace ID (e.g. clarin-pl/combo-nlp-polish-pdb-ud2.17) "
             "or local exported model directory. When given, task config is derived "
             "from the model name if --task-config is not set.",
    )
    parser.add_argument(
        "--task-config", type=Path, default=None,
        help="Path to task-specific configuration. Required unless it can be derived from --model.",
    )
    parser.add_argument(
        "--config", type=Path, default=Path("config/base.yaml"),
        help="Path to base configuration file (default: config/base.yaml).",
    )
    parser.add_argument(
        "--checkpoint", type=Path, default=None,
        help="Path to checkpoint. Default: HF download (if --model is HF ID) "
             "or <language_output_dir>/checkpoints/checkpoint_best.pt.",
    )
    parser.add_argument(
        "--test-file", type=Path, default=None,
        help="Path to gold CoNLL-U test file. Default: auto-detected from UD treebank in config.",
    )
    parser.add_argument(
        "--output-dir", type=Path, default=None,
        help="Override results directory. Default: <language_output_dir>/results.",
    )
    parser.add_argument(
        "--segmenter-model", type=str, default=None,
        help="Override combo-seg model ID. Default: derived from config.repo_id "
             "by swapping 'combo-nlp' → 'combo-seg'.",
    )
    parser.add_argument(
        "--split-level",
        type=str,
        default=None,
        choices=["SENTENCE", "TURN"],
        help="Segmentation level: SENTENCE (default) or TURN.",
    )
    parser.add_argument(
        "--split-multiwords",
        action=argparse.BooleanOptionalAction,
        default=None,
        help="Split multi-word tokens into subwords (default: True).",
    )
    args = parser.parse_args()

    # === Mode 1: Direct file comparison ===
    if args.gold_file or args.predictions_file:
        if not (args.gold_file and args.predictions_file):
            parser.error("--gold-file and --predictions-file must be used together")
        print(f"Comparing files:")
        print(f"  Gold:   {args.gold_file}")
        print(f"  Predictions: {args.predictions_file}")
        evaluation = conll18_ud_eval.evaluate(
            conll18_ud_eval.load_conllu_file(str(args.gold_file)),
            conll18_ud_eval.load_conllu_file(str(args.predictions_file)),
        )
        print_results(evaluation)
        return

    # === Mode 2: Model evaluation (always full-text with combo-seg) ===
    # Resolve task config — required either explicitly or derivable from --model name.
    task_config_path = args.task_config
    if task_config_path is None and args.model:
        task_config_path = derive_task_config_path(args.model)
        if task_config_path is None:
            parser.error(
                f"Could not derive task config for --model {args.model!r}. "
                f"Pass --task-config explicitly."
            )
        print(f"Derived task config: {task_config_path}")
    if task_config_path is None:
        parser.error("--task-config is required (or --model with a matching config/tasks/ entry)")

    config = load_config(args.config, task_config_path)
    device = get_device(config.device)

    # Resolve model source: HF download, local dir, or pipeline output.
    hf_model_dir: Path | None = None
    if args.model:
        local_path = Path(args.model)
        if local_path.exists():
            hf_model_dir = local_path
        else:
            from combo.hub import download_model
            print(f"Downloading model from HuggingFace Hub: {args.model}")
            hf_model_dir = download_model(args.model)

    # When loading an exported model, its config.json carries the exact model
    # hyperparams used when the weights were saved. Override config.model so
    # architecture matches the checkpoint.
    if hf_model_dir is not None:
        exported_config = load_config(hf_model_dir / "config.json")
        config.model = exported_config.model
        config.max_length = exported_config.max_length
    max_length = config.max_length if hasattr(config, "max_length") else config.data.max_length

    # Resolve encoders and checkpoint paths.
    if hf_model_dir is not None:
        encoders_dir = hf_model_dir / "encoders"
        checkpoint_path = args.checkpoint or (hf_model_dir / "pytorch_model.bin")
    else:
        encoders_dir = config.language_output_dir / "encoders"
        checkpoint_path = args.checkpoint or (
            config.language_output_dir / "checkpoints" / "checkpoint_best.pt"
        )

    print(f"Loading encoders from {encoders_dir}")
    morpho_encoder = MorphoEncoder.load(encoders_dir / "morpho_encoder.json")
    deprel_encoder = LabelEncoder.load(encoders_dir / "deprel_encoder.json")
    char_vocab = CharVocab.load(encoders_dir / "char_vocab.json")

    config.model.num_upos = morpho_encoder.num_upos
    config.model.num_xpos = morpho_encoder.num_xpos
    config.model.feat_vocab_sizes = morpho_encoder.feat_vocab_sizes
    config.model.feat_categories = morpho_encoder.feat_categories
    config.model.num_deprels = len(deprel_encoder)
    config.model.char_vocab_size = len(char_vocab)

    print(f"Loading model from {checkpoint_path}")
    model = UDParser(config.model)
    checkpoint = torch.load(checkpoint_path, map_location=device, weights_only=False)
    model.load_state_dict(checkpoint["model_state_dict"], strict=False)
    model = model.to(device)
    model.eval()

    epoch = checkpoint.get("epoch")
    best_metric = checkpoint.get("best_metric")
    if epoch is not None:
        print(f"  Checkpoint epoch: {epoch + 1 if isinstance(epoch, int) else epoch}")
    if best_metric is not None:
        print(f"  Training best metric: {best_metric}")

    tokenizer = AutoTokenizer.from_pretrained(config.model.base_model)

    # Test file, results dir, segmenter model.
    gold_conllu = args.test_file or find_gold_test_file(config)
    results_dir = Path(args.output_dir) if args.output_dir else (
        config.language_output_dir / "results"
    )
    results_dir.mkdir(parents=True, exist_ok=True)

    seg_model_id = args.segmenter_model or combo_seg_model_id(config.repo_id)
    segmenter_instance = make_segmenter("combo-seg", config.data.language, model_name=seg_model_id)

    print(f"\nFull-text evaluation (combo-seg)")
    print(f"  Language:       {config.data.language}")
    print(f"  Gold file:      {gold_conllu}")
    print(f"  Segmenter:      {seg_model_id}")
    print(f"  Results dir:    {results_dir}")

    evaluator = Evaluator(
        morpho_encoder, deprel_encoder, char_vocab,
        treebank=",".join(config.data.treebanks),
        model_name=config.model_name,
        base_model=config.model.base_model,
        use_lemma_beam_search=config.model.use_lemma_beam_search,
        lemma_beam_width=config.model.lemma_beam_width,
        use_morpho_constraints=config.model.use_morpho_constraints,
    )

    result = evaluator.evaluate_full_text(
        model=model,
        text_path=None,
        gold_conllu_path=gold_conllu,
        tokenizer=tokenizer,
        max_length=max_length,
        batch_size=config.data.eval_batch_size,
        device=device,
        language=config.data.language,
        segmenter=segmenter_instance,
        combo_model_id=config.repo_id,
        show_progress=True,
        split_level=args.split_level,
        split_multiwords=args.split_multiwords,
    )

    # Print results
    print("\n" + "=" * 60)
    print("Full-text Evaluation Results (official CoNLL 2018 metrics)")
    print("=" * 60)
    fulltext_metrics = [
        "Tokens", "Sentences", "Words",
        "UPOS", "XPOS", "UFeats", "AllTags", "Lemmas",
        "UAS", "LAS", "CLAS", "MLAS", "BLEX",
    ]
    print("\n{:11}| {:>10} | {:>10}".format("Metric", "F1 Score", "Aligned"))
    print("-" * 42)
    for metric_name in fulltext_metrics:
        f1 = result.f1.get(metric_name)
        aligned = result.aligned_accuracy.get(metric_name)
        if f1 is not None:
            aligned_str = f"{aligned:10.2f}" if aligned is not None else "       n/a"
            print("{:11}| {:10.2f} | {}".format(metric_name, f1, aligned_str))

    # Write history file (always) and results_best.json (when improved).
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    fulltext_block = {
        "f1": dict(result.f1),
        "aligned_accuracy": {k: v for k, v in result.aligned_accuracy.items() if v is not None},
    }
    metric_for_best = config.training.metric_for_best
    metric_value = fulltext_block["f1"].get(metric_for_best)
    best_split = config.training.best_model_split
    fulltext_key = f"{best_split}_fulltext_metrics"

    eval_record: dict[str, Any] = {
        "source": "re-evaluation",
        "timestamp": timestamp,
        "language": config.data.language,
        "treebanks": list(config.data.treebanks),
        "model": config.repo_id,
        "base_model": config.model.base_model,
        "checkpoint": str(checkpoint_path),
        "gold_file": str(gold_conllu),
        "segmenter": f"combo-seg ({seg_model_id})",
        "text_source": result.text_source,
        "best_model_split": best_split,
        "metric_for_best": metric_for_best,
        "metric_value": metric_value,
        # Match trainer's structure so hf-update-card.py reads it unchanged.
        "epoch": None,
        "train_loss": None,
        "dev_metrics": None,
        "train_metrics": None,
        "test_metrics": None,
        "dev_fulltext_metrics": None,
        "test_fulltext_metrics": None,
        fulltext_key: fulltext_block,
    }

    history_file = results_dir / f"eval_fulltext_{timestamp}.json"
    with open(history_file, "w") as f:
        json.dump(eval_record, f, indent=2)
    print(f"\nHistory: {history_file}")

    best_file = results_dir / "results_best.json"
    existing_best = _load_existing_best(best_file)
    if _is_improvement(eval_record, existing_best):
        with open(best_file, "w") as f:
            json.dump(eval_record, f, indent=2)
        prior = existing_best.get("metric_value") if existing_best else None
        prior_str = f"{prior:.2f}" if isinstance(prior, (int, float)) else "none"
        new_str = f"{metric_value:.2f}" if isinstance(metric_value, (int, float)) else "n/a"
        print(f"results_best.json updated: {metric_for_best} {prior_str} → {new_str}")
        print(f"  {best_file}")
    else:
        prior = existing_best.get("metric_value") if existing_best else None
        prior_str = f"{prior:.2f}" if isinstance(prior, (int, float)) else str(prior)
        new_str = f"{metric_value:.2f}" if isinstance(metric_value, (int, float)) else "n/a"
        print(f"results_best.json kept — existing {metric_for_best}={prior_str} beats new {new_str}")


def _load_existing_best(path: Path) -> dict | None:
    if not path.exists():
        return None
    try:
        with open(path) as f:
            return json.load(f)
    except Exception as e:
        print(f"  Warning: could not read existing {path.name}: {e}")
        return None


def _is_improvement(new: dict, existing: dict | None) -> bool:
    if existing is None:
        return True
    new_value = new.get("metric_value")
    if not isinstance(new_value, (int, float)):
        return False
    old_value = existing.get("metric_value")
    if not isinstance(old_value, (int, float)):
        return True
    return new_value > old_value


def print_results(evaluation: dict) -> None:
    """Print evaluation results in a readable format."""
    print("\n" + "=" * 72)
    print("Evaluation Results (official CoNLL 2018 metrics)")
    print("=" * 72)

    print("\n{:11}| {:>10} | {:>10} | {:>10} | {:>10}".format(
        "Metric", "Precision", "Recall", "F1 Score", "Aligned"))
    print("-" * 72)

    for metric in ["UPOS", "XPOS", "UFeats", "AllTags", "Lemmas",
                    "UAS", "LAS", "CLAS", "MLAS", "BLEX"]:
        s = evaluation[metric]
        aligned = s.aligned_accuracy
        aligned_str = f"{aligned * 100:10.2f}" if aligned is not None else "       n/a"
        print("{:11}| {:10.2f} | {:10.2f} | {:10.2f} | {}".format(
            metric, s.precision * 100, s.recall * 100, s.f1 * 100, aligned_str))


if __name__ == "__main__":
    main()
