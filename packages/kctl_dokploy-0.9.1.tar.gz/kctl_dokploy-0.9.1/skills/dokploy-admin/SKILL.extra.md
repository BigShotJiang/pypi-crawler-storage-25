# dokploy-admin — extra runbooks

> This file is merged into SKILL.md by `kctl-dokploy skill generate`.
> Put anything here that should survive regeneration: narrative workflows,
> gotchas, one-command recipes, troubleshooting.

## Database Backup & Restore — MANDATORY Decision Guide

**ALWAYS use this table to pick the right command. No exceptions.**

| Scenario | Command | Why |
|---|---|---|
| **Production → Local dev** (laptop postgres) | `backups pull <id> -t local -f` | Config-driven preset. Downloads via boto3, restores locally. |
| **Production → Staging** (remote server) | `backups pull <id> -t staging -f` | Server-side restore via SSH (rclone+pg_restore on remote). ~65s. |
| **Production → All targets** | `backups pull <id> -t all -f` | Runs all configured targets sequentially. |
| **Production → Staging** (Dokploy API path) | `backups restore --compose <infra-postgres> --database-name <stg_db>` | Server-side restore via Dokploy API. No local download. |
| **Production → Another Dokploy server** | `backups restore` on target profile | Dokploy handles the S3→pg_restore pipeline server-side. |
| **Manual args** (no preset) | `backups pull --target-host localhost ...` | Legacy explicit flags still work when no preset configured. |

**NEVER use `backups pull --target-compose` for remote servers** — it requires local Docker socket access which doesn't exist for remote hosts.

**NEVER use `backups restore` for local dev** — it targets Dokploy-managed postgres, not your laptop.

## Compose Postgres Backup → S3 → Local Restore (prod → local)

For developers pulling prod dumps down to a local postgres running on
`localhost:5434`, use `backups pull`. The recommended approach is config-driven presets.

### `--target` preset (config-driven restore targets)

Define reusable restore targets in config, then restore with a single flag:

```bash
# Restore to local dev
kctl-dokploy -p idtpp backups pull 5Ku-fyw3O7Z1OIEztfcH5 -t local -f

# Restore to staging (server-side via SSH — ~65s, no data crosses internet)
kctl-dokploy -p idtpp backups pull 5Ku-fyw3O7Z1OIEztfcH5 -t staging -f

# Restore to ALL configured targets sequentially
kctl-dokploy -p idtpp backups pull 5Ku-fyw3O7Z1OIEztfcH5 -t all -f
```

**Config example:**

```yaml
# ~/.config/kodemeio/config.yaml
profiles:
  idtpp:
    dokploy:
      restore_targets:
        local:
          host: localhost
          port: 5434
          user: odoo
          password: local-dev-app-pw
          owner: odoo
          backup_databases:
            "5Ku-fyw3O7Z1OIEztfcH5": { database: mac_odoo_erp }
            "h8WoZGaZfJ1TAFLZdNZvP": { database: tpp_odoo_erp }
        staging:
          host: 10.0.0.2
          port: 5432
          user: postgres
          password: "..."
          owner: odoo
          ssh: root@178.104.127.104
          backup_databases:
            "5Ku-fyw3O7Z1OIEztfcH5":
              database: mac_odoo_erp_stg
              docker_project: compose-input-multi-byte-port-qsokry
              stop_compose: 4SSfiBOGTynvBFWrpch0q
              restart_compose: 4SSfiBOGTynvBFWrpch0q
```

**Server-side restore (SSH targets):** When a target has `ssh` configured, the restore runs entirely on the remote server: SSH in -> rclone cat S3 -> gunzip -> docker exec pg_restore. No data crosses the internet. Performance: ~65s for staging (same as local), vs >12 min with the old SSH tunnel approach.

**Per-backup database mappings:** Each `backup_databases.<backup_id>` entry maps the backup to its target DB name. Staging targets can additionally specify `docker_project`, `stop_compose`, and `restart_compose` for automatic Odoo stop/restart around the restore.

**`--target all`:** Runs all configured targets sequentially — useful for syncing both local and staging in one command.

### Legacy explicit flags (one-command recipe)

```bash
kctl-dokploy -p idtpp backups pull <backup_id> \
    --target-host localhost --target-port 5434 \
    --target-user odoo --target-password <pwd> \
    --target-db tpp_odoo_erp \
    --trigger --force
```

What this does:

1. Looks up the backup config via `/backup.one` — extracts destinationId,
   S3 bucket, prefix, source DB name.
2. With `--trigger`: fires the appropriate `/backup.manualBackup*` endpoint
   (postgres / compose / mysql / ...) and polls S3 every 10 s (configurable
   via `--poll-interval`) for a NEW object with `LastModified` after
   trigger time, up to `--wait-timeout` seconds (default 300).
3. Without `--trigger`: picks the newest existing object under the backup's
   prefix — no fresh dump, no production load.
4. Downloads the object via boto3 using the destination's stored credentials.
5. Gunzips if `.gz`; magic-byte-detects `PGDMP` for pg_restore custom format
   vs. plain SQL.
6. Drops the target DB (terminating active connections via `pg_terminate_backend`)
   and recreates it with `OWNER=<--owner | --target-user>`. Prompts
   unless `--force`.
7. `pg_restore --no-owner --no-privileges --clean --if-exists` (custom) or
   `psql -f` (plain) against `--target-host:--target-port`.
8. Smoke test: `SELECT count(*) FROM res_users` (best-effort, non-fatal).
9. Cleans up the downloaded file unless `--keep-download`.

### Finding the backup_id

**IMPORTANT:** Backup configs live on the **infra-postgres** compose, NOT on the
Odoo compose. Each tenant group has its own infra-postgres:

| Tenant | Infra Postgres Compose | Profile |
|---|---|---|
| MAC | `UL9UNK_WvbjNKR-KB6aCr` (mac-infra-postgres) | `idtpp-mac` |
| TPP | `2iEl8DzSWOMFOClweOhiZ` (tpp-infra-postgres) | `idtpp` |

```bash
# 1. List backups on the INFRA-POSTGRES compose (not the Odoo compose!)
kctl-dokploy -p idtpp-mac backups list --compose UL9UNK_WvbjNKR-KB6aCr   # MAC
kctl-dokploy -p idtpp backups list --compose 2iEl8DzSWOMFOClweOhiZ        # TPP

# 2. Identify which backup_id is for your target database.
kctl-dokploy -p idtpp-mac backups get <backup_id>

# 3. Pick the row whose "Database" matches the DB you want — that's <backup_id>.
```

### Known backup IDs (quick reference)

| Database | Backup ID | Infra Compose | Profile |
|---|---|---|---|
| `mac_odoo_erp` | `5Ku-fyw3O7Z1OIEztfcH5` | mac-infra-postgres | `idtpp-mac` |
| `mac_odoo_hrms` | `gnM3xWzr-dvG3UmZrS8Br` | mac-infra-postgres | `idtpp-mac` |
| `tpp_odoo_erp` | `h8WoZGaZfJ1TAFLZdNZvP` | tpp-infra-postgres | `idtpp` |
| `tpp_odoo_hrms` | `85cwZU8trJN8OEJUYgELD` | tpp-infra-postgres | `idtpp` |

### Copy-paste recipes per tenant

**Preferred: using `--target` presets (requires config setup above):**

```bash
# MAC Odoo ERP → local + staging
kctl-dokploy -p idtpp-mac backups pull 5Ku-fyw3O7Z1OIEztfcH5 -t local -f
kctl-dokploy -p idtpp-mac backups pull 5Ku-fyw3O7Z1OIEztfcH5 -t staging -f
kctl-dokploy -p idtpp-mac backups pull 5Ku-fyw3O7Z1OIEztfcH5 -t all -f

# TPP Odoo ERP → local + staging
kctl-dokploy -p idtpp backups pull h8WoZGaZfJ1TAFLZdNZvP -t local -f
kctl-dokploy -p idtpp backups pull h8WoZGaZfJ1TAFLZdNZvP -t staging -f
```

**Legacy explicit flags (still work without config presets):**

**MAC Odoo ERP → local:**
```bash
kctl-dokploy -p idtpp-mac backups pull 5Ku-fyw3O7Z1OIEztfcH5 \
    --target-db mac_odoo_erp \
    --target-host localhost --target-port 5434 \
    --target-user odoo --target-password local-dev-app-pw \
    --trigger --force
```

**MAC Odoo HRMS → local:**
```bash
kctl-dokploy -p idtpp-mac backups pull gnM3xWzr-dvG3UmZrS8Br \
    --target-db mac_odoo_hrms \
    --target-host localhost --target-port 5434 \
    --target-user odoo --target-password local-dev-app-pw \
    --trigger --force
```

**TPP Odoo ERP → local:**
```bash
kctl-dokploy -p idtpp backups pull h8WoZGaZfJ1TAFLZdNZvP \
    --target-db tpp_odoo_erp \
    --target-host localhost --target-port 5434 \
    --target-user odoo --target-password local-dev-app-pw \
    --trigger --force
```

**TPP Odoo HRMS → local:**
```bash
kctl-dokploy -p idtpp backups pull 85cwZU8trJN8OEJUYgELD \
    --target-db tpp_odoo_hrms \
    --target-host localhost --target-port 5434 \
    --target-user odoo --target-password local-dev-app-pw \
    --trigger --force
```

After restore, restart local Odoo: `kctl-odoo -p local-mac-odoo-erp local restart`

### `--trigger` vs. latest existing

- **Default (no `--trigger`)**: reuses the newest scheduled backup already in
  S3. Zero production load, dump freshness = `<= schedule interval`.
- **`--trigger`**: fires a manual dump first. Dump freshness = "right now".
  Costs prod CPU/IO for the dump duration; use when yesterday's nightly
  isn't fresh enough (e.g. debugging a bug introduced today).

Prefer `--trigger` when debugging _today's_ state; prefer default when
catching up development data.

### Target types

**`--target-host` (raw postgres — local dev)**

```bash
kctl-dokploy -p idtpp backups pull <backup_id> \
    --target-host localhost --target-port 5434 \
    --target-user odoo --target-password <pwd> \
    --target-db tpp_odoo_erp --force
```

`PGPASSWORD` env var is used as the fallback if `--target-password` is omitted.

**`--target-compose` (Dokploy-managed on the current profile's host)**

```bash
kctl-dokploy -p local backups pull <backup_id> \
    --target-compose <target_compose_id> \
    --target-user odoo --target-db tpp_odoo_erp \
    --target-service postgres --force
```

Resolves the running postgres container via `docker ps` labels
(`com.docker.compose.project=<appName>`, `com.docker.compose.service=<svc>`)
and runs `docker exec -i <container> pg_restore`. The command that calls
this needs docker socket access on the local host — for cross-host restores
use `backups restore` (native Dokploy SSE) instead.

### Log output

Every `backups pull` / `run-wait` / `download` line carries a wall-clock
`[HH:MM:SS]` prefix (since 0.4.3). Operators can see elapsed time between
phases at a glance:

```
INFO [19:43:23] Triggering manual backup via /backup.manualBackupCompose ...
OK   [19:43:38] New backup file detected: .../2026-04-19T12-43-24Z.sql.gz
OK   [19:43:42] Downloaded 9.8 MB in 3.2s (3.1 MB/s)
OK   [19:43:43] Target database 'mac_odoo_erp' recreated.
INFO [19:43:43] Running pg_restore (custom format) ...
OK   [19:45:36] Restore completed.
OK   [19:45:36] Pull complete: 5Ku-fyw3O7Z1OIEztfcH5 -> mac_odoo_erp
```

### Real-world timing benchmarks

Measured against production (Hetzner) → local workstation on the same
LAN, small Odoo 18 databases:

| Database | Compressed size | Users | Total time | pg_restore | S3+download |
|---|---:|---:|---:|---:|---:|
| `tpp_odoo_erp` | 8.0 MB | 14 | **89s** | 73s (82%) | 15s |
| `mac_odoo_erp` | 9.8 MB | 31 | **136s** | 113s (83%) | 18s |

**pg_restore dominates.** Network/S3 scales with DB size, restore
scales with table count + index count. A 100 MB DB is typically
3–5 min; a 1 GB DB is 20–40 min — the bottleneck is local
`pg_restore`, not Dokploy or S3.

### Multi-prefix discovery (0.4.2+)

`backups pull` and `run-wait` transparently handle two Dokploy S3
layout generations:

- **NEW** (current Dokploy): `<compose.appName>_<serviceName>/<backup.prefix>/<timestamp>.<ext>`
- **OLD** (legacy, pre-upgrade): `<backup.prefix>-<timestamp>.<ext>`

The tool scans both candidate prefixes + filters by DB-name
substring, and picks the globally-newest match. If your bucket still
has legacy objects, they're found too; only the newest wins.

### Other pull-flow commands

**`backups run-wait`** — trigger + poll without downloading/restoring.
Useful in CI to wait for a nightly without restoring locally:

```bash
kctl-dokploy -p idtpp backups run-wait <backup_id> --timeout 600
# prints: s3://<bucket>/<key>
```

**`backups download`** — standalone S3 download using a destination's creds:

```bash
kctl-dokploy -p idtpp backups download <s3_key> \
    --destination <destination_id> --output /tmp/dump.sql.gz
```

**`backups list-files`** — list objects in a destination (now boto3-backed;
no more "Input validation failed"):

```bash
# List everything (up to --limit, default 200)
kctl-dokploy -p idtpp backups list-files --destination <destination_id>

# Filter client-side by substring
kctl-dokploy -p idtpp backups list-files --destination <destination_id> --search tpp_odoo_erp

# Filter S3-side by prefix (faster for huge buckets)
kctl-dokploy -p idtpp backups list-files --destination <destination_id> \
    --prefix 'compose-xyz/postgres/'
```

### Dokploy-managed restore (`backups restore`)

When the target lives inside Dokploy (on the same host as the CLI's
profile), use the native SSE path — Dokploy runs pg_restore itself via
`docker exec`, no local download:

```bash
kctl-dokploy -p <target-profile> backups restore \
    --compose <target-compose-id> \
    --destination <target-destination-id> \
    --database-name <db-name> \
    --service-name postgres \
    --database-user odoo \
    --latest <db-name>
```

Exit 0 on success, 1 on Dokploy error, 2 on transport failure. Dokploy's
log lines stream to stdout prefixed `[Dokploy]`.

### Metadata flags — why they matter (applies to `backups restore`)

`--service-name` and `--database-user` map to `metadata.serviceName` and
`metadata.postgres.databaseUser` in the tRPC payload. Without them
Dokploy runs `docker exec -i sh` (wrong container) and `pg_restore -U ''`
(empty user). The CLI exits 1 immediately if either is omitted.

| DB type | Required flags |
|---|---|
| `postgres` (default) | `--service-name`, `--database-user` |
| `mariadb` / `mongo` | `--service-name`, `--database-user`, `--database-password` |
| `mysql` | `--service-name`, `--database-password` |

### Troubleshooting

| Symptom | Cause + fix |
|---|---|
| `Compose '<id>' not found` | Wrong compose ID for that profile. Re-run `kctl-dokploy --profile <name> compose list` and copy the ID column exactly (case-sensitive). |
| Empty backup list for Odoo compose | Backups are on the **infra-postgres** compose, not the Odoo compose. Use `compose list \| grep infra-postgres` to find the right compose ID, then `backups list --compose <infra-postgres-id>`. |
| `backups create` fails with SQL error on Odoo compose | You're creating the backup on the wrong compose. Create it on the infra-postgres compose instead: `--compose <infra-postgres-compose-id>`. |
| `Backup '<id>' not found` (during `backups pull`) | `backup_id` belongs to a different profile. `pull` uses the profile passed to `-p`; run `kctl-dokploy -p <src> backups list --compose <id>` on the correct profile. |
| `Timed out after Ns waiting for a new backup` (with `--trigger`) | Source dump is slow or cron is disabled. Bump `--wait-timeout 900`; check `backups get <id>` to confirm `enabled=True`. |
| `No S3 objects found under prefix '...'` (without `--trigger`) | No scheduled dump exists yet. Run once with `--trigger` or verify the nightly schedule via `backups list --compose <id>`. |
| `Error: ... no such container` in Dokploy log (during `backups restore`) | `--service-name` doesn't match the postgres service label in the compose YAML. Check with `kctl-dokploy --profile <name> compose loadServices --compose <id>`. |
| `pg_restore: error: role "<user>" does not exist` | `--target-user` / `--database-user` is wrong or role hasn't been created on the target. Verify with `psql -U postgres -c '\du'`. |
| `docker exec` errors with `No running postgres container found` (during `backups pull --target-compose`) | `--target-service` doesn't match the service in the target compose (default is `postgres`). Inspect with `docker ps --filter label=com.docker.compose.project=<appName>`. |
| `UndefinedColumn` errors after restore | Source DB schema is ahead of target (module upgraded on source). Run `kctl-odoo -p <target-profile> modules upgrade <module>`. |
| Transport / auth failure (exit 2 from `backups restore`) | API key or Dokploy URL wrong for the target profile. Run `kctl-dokploy -p <profile> config test`. |

## Fast Log Debugging

See `packages/kctl-odoo/README.md` and CLAUDE.md for `kctl-odoo logs
tail`, which layers Odoo-aware filters (`--level`, `--module`,
`--request`, `--worker`, `--grep`) on top of `kctl-dokploy compose
service-logs -f`. Tracebacks are captured as whole blocks so
`--level ERROR` keeps the full `Traceback (most recent call last): ...`
body.
