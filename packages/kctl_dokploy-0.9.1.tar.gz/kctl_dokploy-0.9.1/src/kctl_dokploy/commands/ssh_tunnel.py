"""SSH tunnel context manager for restore-through-SSH workflows."""

from __future__ import annotations

import socket
import subprocess
import time
from contextlib import contextmanager
from typing import Generator


def _find_free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


@contextmanager
def ssh_tunnel(
    ssh_host: str,
    remote_port: int = 5432,
    ssh_port: int = 22,
    local_port: int | None = None,
) -> Generator[int, None, None]:
    """Open an SSH tunnel and yield the ephemeral local port.

    Usage::

        with ssh_tunnel("root@hetzner-host", remote_port=5432) as port:
            # port is a local port forwarding to remote_port on ssh_host
            psql -h localhost -p {port} ...
    """
    lport = local_port or _find_free_port()

    cmd = [
        "ssh",
        "-o",
        "StrictHostKeyChecking=accept-new",
        "-o",
        "BatchMode=yes",
        "-o",
        "ConnectTimeout=10",
        "-N",
        "-L",
        f"127.0.0.1:{lport}:127.0.0.1:{remote_port}",
        "-p",
        str(ssh_port),
        ssh_host,
    ]
    proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)  # noqa: S603

    # Wait for the tunnel to become connectable
    deadline = time.monotonic() + 15
    connected = False
    while time.monotonic() < deadline:
        if proc.poll() is not None:
            stderr = proc.stderr.read().decode() if proc.stderr else ""
            raise RuntimeError(f"SSH tunnel exited immediately: {stderr.strip()}")
        try:
            with socket.create_connection(("127.0.0.1", lport), timeout=1):
                connected = True
                break
        except OSError:
            time.sleep(0.3)

    if not connected:
        proc.terminate()
        raise RuntimeError(f"SSH tunnel to {ssh_host}:{remote_port} did not become connectable within 15s")

    try:
        yield lport
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
