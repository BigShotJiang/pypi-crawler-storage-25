"""CodeStats - Python Code Analysis Tool"""

from .analyzer import analyze, CodeReport

__version__ = "1.0.1"
__all__ = ["analyze", "CodeReport"]
