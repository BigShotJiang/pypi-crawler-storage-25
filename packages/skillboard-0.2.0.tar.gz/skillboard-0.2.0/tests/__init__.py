"""Tests for skillboard package."""
