# Copyright (C) 2023 - 2026 ANSYS, Inc. and/or its affiliates.
# SPDX-FileCopyrightText: 2023 ANSYS, Inc. All rights reserved
# SPDX-License-Identifier: MIT
#
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import re
import socket
import sys
import threading

from .server_log_level import ServerLogLevel


class CUEEngineReadMessageService(threading.Thread):
    cue_engine = 0

    def __init__(self, parent_object):
        # calling parent class constructor
        super().__init__()
        self.cue_engine = parent_object

    def __del__(self):
        pass
        # print(f"__del__ CUEEngineReadMessageService ")

    def log_read(self, message, log_level):
        self.cue_engine().log_core(message, log_level)

    def run(self):
        self.log_read(
            "read_message_process: read_message_process running...",
            ServerLogLevel.NETWORK_DEBUG,
        )
        # This service is (nicely) shut down by setting run_read_message_process to False and then processing a message.
        # The thread can be join()ed as well if need be.
        while self.cue_engine().run_read_message_process:
            # read command code and number of bytes.
            # The command code won't be used, but we could check it for validity.
            # self.log_read(
            #     f"read_message_process: Waiting on {self.cue_engine().app_name} for a message",
            #     ServerLogLevel.INFO,
            # )
            try:
                message_command_code: str = self.cue_engine().client_socket.recv(
                    10, socket.MSG_WAITALL
                )
                # This should never happen unless we have a blocking issue.
                # this is seen on github runners when the engine does not start up (for example, a license problem) or when TGEngine crashes in some scenarios.
                # If a socket returns 0 bytes in this way, the other point will never send more information back.
                if not message_command_code:
                    # Fatal Error, but if TG shut down purposefully, we can ignore it
                    if self.cue_engine().run_read_message_process == True:
                        self.log_read(
                            f"read_message_process: FATAL: message_command_code should have read 10 bytes but instead read {len(message_command_code)}",
                            ServerLogLevel.NETWORK_DEBUG,
                        )
                    # kill this thread process. Depending on the order of operations,
                    # the read messenger may quit this way. If the process leash is off,
                    # it is a normal exit.
                    if self.cue_engine().run_read_message_process == False:
                        self.log_read("Read Message Process Completed", ServerLogLevel.DEBUG)
                    else:
                        self.log_read(
                            "Read Message Process Completed Abornmally!",
                            ServerLogLevel.DEBUG,
                        )
                    return

                # Process the message
                self.read_message_process(message_command_code)

            except socket.timeout as e:
                # self.log_read(
                #     f"read_message_process: socket timeout (socket.timeout), sleeping",
                #     ServerLogLevel.DEBUG,
                # )
                pass
            except Exception as e:
                print(f"run_read_message_process general catch {e}")
                self.log_read(
                    f"read_message_process: Exception: {e}, return",
                    ServerLogLevel.DEBUG,
                )
                return
        # End of while loop, read_message_process thread is done.
        self.log_read("Read Message Process Completed", ServerLogLevel.DEBUG)

    def read_message_process(self, message_command_code):
        # we can check for t_message_pr
        #  code 'cueDataKey'
        message_header = self.cue_engine().client_socket.recv(4).decode("utf-8")
        self.log_read(
            f"read_message_process: Message Header: {message_header}",
            ServerLogLevel.DEBUG,
        )
        message_number_of_bytes = int.from_bytes(
            self.cue_engine().client_socket.recv(4, socket.MSG_WAITALL), byteorder="big"
        )
        self.log_read(
            f"read_message_process: Message NBytes: {message_number_of_bytes}",
            ServerLogLevel.DEBUG,
        )
        if message_header == "DONE":
            self.log_read(
                f"read_message_process: {self.cue_engine().app_name} Ready for the next command",
                ServerLogLevel.DEBUG,
            )
            if getattr(sys, "ps1", sys.flags.interactive):  # Interactive only
                self.log_read(
                    f"{self.cue_engine().app_name} is waiting for the next command",
                    ServerLogLevel.INFO,
                )
            self.cue_engine().engine_ready = True
        elif message_header == "ERRR":
            incoming_message = (
                self.cue_engine()
                .client_socket.recv(message_number_of_bytes, socket.MSG_WAITALL)
                .decode("utf-8")
            )
            self.cue_engine().engine_incoming_error_queue.put(self.extract_error(incoming_message))
            self.log_read(
                f"read_message_process: {self.cue_engine().app_name} ERROR Response: {incoming_message}",
                ServerLogLevel.DEBUG,
            )
            self.log_read(
                f"{self.cue_engine().app_name} Error: {self.extract_error(incoming_message)}",
                ServerLogLevel.WARNING,
            )
            # for now, allow continuation of processing, because we don't have a way to pause other operations to handle errors.
            # self.cue_engine.engine_ready = True
        elif message_header == "DBCH":
            # ObjectDB change notification from the engine
            incoming_message = (
                self.cue_engine()
                .client_socket.recv(message_number_of_bytes, socket.MSG_WAITALL)
                .decode("utf-8")
            )
            self.cue_engine().notify_ccl_changes(incoming_message)
            self.log_read(
                f"read_message_process: Engine CCL Change Notification: {incoming_message}",
                ServerLogLevel.DEBUG,
            )
            # self.cue_engine().engine_ready = True
        elif message_header == "RPLY":
            # Either wait for an empty buffer, or implement a thread-safe queue.
            incoming_message = (
                self.cue_engine()
                .client_socket.recv(message_number_of_bytes, socket.MSG_WAITALL)
                .decode("utf-8")
            )
            self.cue_engine().engine_incoming_message_queue.put(incoming_message)
            self.log_read(
                f"read_message_process: {self.cue_engine().app_name} Query Response: {incoming_message}",
                ServerLogLevel.DEBUG,
            )
        else:
            message_body = (
                self.cue_engine()
                .client_socket.recv(message_number_of_bytes, socket.MSG_WAITALL)
                .decode("utf-8")
            )

            self.log_read(
                f"read_message_process: {self.cue_engine().app_name} Not Ready. Reports: {message_body}",
                ServerLogLevel.DEBUG,
            )
        return

    def extract_error(self, message):
        # Engine sends errors in the form:
        # {  ClassMethod = <class>:<method>,  Message = <msg>,}
        # The <msg> string could contain newlines.
        pattern = r".*Message =\s+(?P<msg>.*),}"
        match = re.search(pattern, message, re.DOTALL)
        if match:
            return match.group("msg")
        return message
