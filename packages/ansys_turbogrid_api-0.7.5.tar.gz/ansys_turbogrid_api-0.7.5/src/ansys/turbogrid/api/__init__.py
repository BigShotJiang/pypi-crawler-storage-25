# Copyright (C) 2023 - 2026 ANSYS, Inc. and/or its affiliates.
# SPDX-FileCopyrightText: 2023 ANSYS, Inc. All rights reserved
# SPDX-License-Identifier: MIT
#
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""``ansys-api-turbogrid`` is a python wrapper for Ansys TurboGrid Service."""
import os
import pathlib

import toml

try:
    import importlib.metadata as importlib_metadata
except ModuleNotFoundError:  # pragma: no cover
    import importlib_metadata

# Read from the pyproject.toml
# major, minor, patch
__version__ = "0.0.0"
try:
    __version__ = importlib_metadata.version("ansys-turbogrid-api")
except importlib_metadata.PackageNotFoundError:
    # Get version from pyproject.toml
    install_path = pathlib.PurePath(__file__).parent.parent.parent.parent.parent.as_posix()
    print(f"Reading Local install version from: {install_path + '/pyproject.toml'}")
    pyptoml = toml.load(install_path + "/pyproject.toml")
    __version__ = pyptoml["tool"]["poetry"]["version"]
    print(f"Local install version: {__version__}")
    pass


try:
    if os.getenv("PYTURBOGRID_DOC_ENGINE_CONNECTION"):
        from ansys.turbogrid.api.help_utils import add_engine_functions_for_doc

        add_engine_functions_for_doc()
except Exception:
    pass
