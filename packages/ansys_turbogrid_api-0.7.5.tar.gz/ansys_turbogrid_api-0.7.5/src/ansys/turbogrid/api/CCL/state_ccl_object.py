# Copyright (C) 2023 - 2026 ANSYS, Inc. and/or its affiliates.
# SPDX-FileCopyrightText: 2023 ANSYS, Inc. All rights reserved
# SPDX-License-Identifier: MIT
#
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from . import ccl_utils


class StateCCLObject:
    """Class represents a CUE state CCL object."""

    def __init__(self, type: str, name: str, parent):
        self.parent: StateCCLObject = parent
        self.type: str = type
        self.name: str = name
        self.children: list[StateCCLObject] = []
        self.param_map: dict[str, str] = {}

    def exists(self) -> bool:
        return True

    def get_full_path(self) -> str:
        all_nodes = [self]
        parent = self.parent
        while parent and parent.exists():
            all_nodes.append(parent)
            parent = parent.parent

        all_nodes.reverse()

        type_name_list = []
        for node in all_nodes:
            type_name_list.append(ccl_utils.get_type_and_name_str(node.type, node.name))
        full_path = "/" + "/".join(type_name_list)

        return full_path

    def __str__(self) -> str:  # pragma: no cover
        indent_level = -1
        parent: StateCCLObject = self.parent
        while parent:
            indent_level += 1
            parent = parent.parent

        indent = "  " * indent_level
        type_name = ccl_utils.get_type_and_name_str(self.type, self.name)
        desc = indent + type_name + "\n"

        for p, v in self.param_map.items():
            desc += indent + "  " + p + " = " + v + "\n"

        for c in self.children:
            desc += str(c)

        desc += indent + "END\n"

        return desc
