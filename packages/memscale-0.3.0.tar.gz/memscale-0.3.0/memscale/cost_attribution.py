"""Cost attribution — calculate $$ saved by MemScale.

This is a high-value feature for ML teams who care about cloud costs.
"""
from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Dict, Optional

logger = logging.getLogger(__name__)


# Common GPU pricing (USD/hour, on-demand cloud rates as of 2025)
# Sources: AWS, GCP, Azure, RunPod, Lambda Labs averages
GPU_HOURLY_COSTS = {
    # Consumer GPUs (RunPod/Vast)
    "RTX 3090": 0.34,
    "RTX 4090": 0.69,
    "RTX A4000": 0.39,
    "RTX A5000": 0.79,
    "RTX A6000": 1.20,
    # Data center GPUs
    "V100": 1.60,
    "T4": 0.50,
    "A10": 0.95,
    "A40": 1.50,
    "A100 40GB": 1.99,
    "A100 80GB": 2.49,
    "H100 80GB": 4.50,
    "H100 SXM": 5.50,
    # AMD
    "MI210": 1.50,
    "MI250": 2.00,
    "MI300X": 4.00,
}


@dataclass
class CostReport:
    """Cost attribution report."""

    # Training duration
    training_hours: float
    num_gpus: int
    gpu_type: str
    gpu_hourly_rate: float

    # Without MemScale
    baseline_total_cost_usd: float
    baseline_vram_gb: float
    baseline_oom_risk: bool

    # With MemScale
    memscale_total_cost_usd: float
    memscale_vram_gb: float
    memscale_overhead_pct: float

    # Savings
    cost_savings_usd: float
    cost_savings_pct: float
    vram_savings_gb: float

    def __str__(self) -> str:
        lines = [
            "=" * 60,
            "  MemScale Cost Attribution Report",
            "=" * 60,
            f"  GPU: {self.num_gpus}× {self.gpu_type} (${self.gpu_hourly_rate:.2f}/hr each)",
            f"  Training duration: {self.training_hours:.2f} hours",
            "",
            "  Without MemScale:",
            f"    VRAM: {self.baseline_vram_gb:.2f} GB",
            f"    Cost: ${self.baseline_total_cost_usd:.2f}",
        ]

        if self.baseline_oom_risk:
            lines.append(
                f"    Status: ⚠ OOM RISK — would need bigger GPU or smaller batch"
            )

        lines.extend(
            [
                "",
                "  With MemScale:",
                f"    VRAM: {self.memscale_vram_gb:.2f} GB ({self.vram_savings_gb:.1f} GB saved)",
                f"    Cost: ${self.memscale_total_cost_usd:.2f}",
                f"    Throughput overhead: {self.memscale_overhead_pct:+.1f}%",
                "",
                f"  💰 Total savings: ${self.cost_savings_usd:.2f} ({self.cost_savings_pct:.1f}%)",
                "=" * 60,
            ]
        )

        return "\n".join(lines)


class CostTracker:
    """Track training costs and savings from MemScale.

    Usage:
        from memscale import CostTracker

        tracker = CostTracker(
            gpu_type="A100 40GB",
            num_gpus=4,
        )

        tracker.start()
        # ... training happens ...
        tracker.update_baseline_vram(38.0)  # Without MemScale would need this much
        tracker.update_memscale_vram(19.0)  # With MemScale
        tracker.update_throughput_overhead(2.5)  # 2.5% slower
        tracker.stop()

        report = tracker.report()
        print(report)
    """

    def __init__(
        self,
        gpu_type: str = "A100 40GB",
        num_gpus: int = 1,
        custom_hourly_rate: Optional[float] = None,
    ):
        self.gpu_type = gpu_type
        self.num_gpus = num_gpus

        if custom_hourly_rate is not None:
            self.gpu_hourly_rate = custom_hourly_rate
        elif gpu_type in GPU_HOURLY_COSTS:
            self.gpu_hourly_rate = GPU_HOURLY_COSTS[gpu_type]
        else:
            logger.warning(
                f"Unknown GPU type '{gpu_type}'. "
                f"Using default $2.00/hr. "
                f"Set custom_hourly_rate for accurate costs."
            )
            self.gpu_hourly_rate = 2.00

        # Tracking
        self._start_time: Optional[float] = None
        self._end_time: Optional[float] = None
        self._baseline_vram_gb: float = 0.0
        self._memscale_vram_gb: float = 0.0
        self._throughput_overhead_pct: float = 0.0
        self._oom_risk: bool = False

    def start(self) -> None:
        """Start timing the training run."""
        self._start_time = time.time()

    def stop(self) -> None:
        """Stop timing the training run."""
        self._end_time = time.time()

    def update_baseline_vram(self, gb: float, oom_risk: bool = False) -> None:
        """Update baseline VRAM measurement (what training would use without MemScale)."""
        self._baseline_vram_gb = gb
        self._oom_risk = oom_risk

    def update_memscale_vram(self, gb: float) -> None:
        """Update MemScale-optimized VRAM measurement."""
        self._memscale_vram_gb = gb

    def update_throughput_overhead(self, percent: float) -> None:
        """Update throughput overhead from MemScale (positive = slower)."""
        self._throughput_overhead_pct = percent

    @property
    def training_hours(self) -> float:
        """Get training duration in hours."""
        if self._start_time is None:
            return 0.0
        end = self._end_time or time.time()
        return (end - self._start_time) / 3600.0

    def report(self) -> CostReport:
        """Generate cost attribution report."""
        hours = self.training_hours

        # Cost without MemScale
        # If baseline OOMs, you'd need a bigger GPU or smaller batch
        # Either way, training takes longer or costs more
        if self._oom_risk:
            # Assume need 1.5× more compute time with smaller batches
            baseline_hours_effective = hours * 1.5
        else:
            baseline_hours_effective = hours

        baseline_cost = baseline_hours_effective * self.gpu_hourly_rate * self.num_gpus

        # Cost with MemScale
        # Slight overhead from optimization
        memscale_hours = hours * (1 + self._throughput_overhead_pct / 100)
        memscale_cost = memscale_hours * self.gpu_hourly_rate * self.num_gpus

        # Savings
        savings_usd = baseline_cost - memscale_cost
        savings_pct = (savings_usd / baseline_cost * 100) if baseline_cost > 0 else 0
        vram_savings = self._baseline_vram_gb - self._memscale_vram_gb

        return CostReport(
            training_hours=hours,
            num_gpus=self.num_gpus,
            gpu_type=self.gpu_type,
            gpu_hourly_rate=self.gpu_hourly_rate,
            baseline_total_cost_usd=baseline_cost,
            baseline_vram_gb=self._baseline_vram_gb,
            baseline_oom_risk=self._oom_risk,
            memscale_total_cost_usd=memscale_cost,
            memscale_vram_gb=self._memscale_vram_gb,
            memscale_overhead_pct=self._throughput_overhead_pct,
            cost_savings_usd=savings_usd,
            cost_savings_pct=savings_pct,
            vram_savings_gb=vram_savings,
        )


def estimate_savings(
    baseline_vram_gb: float,
    memscale_vram_gb: float,
    training_hours: float,
    gpu_type: str = "A100 40GB",
    num_gpus: int = 1,
    overhead_pct: float = 2.0,
) -> CostReport:
    """Quick estimate of savings without manual tracking.

    Args:
        baseline_vram_gb: VRAM without MemScale
        memscale_vram_gb: VRAM with MemScale
        training_hours: Total training time
        gpu_type: GPU model
        num_gpus: Number of GPUs
        overhead_pct: Throughput overhead from MemScale

    Returns:
        CostReport with estimated savings
    """
    # Determine if baseline would OOM
    oom_risk = False
    if gpu_type in GPU_HOURLY_COSTS:
        # Rough VRAM capacity lookup
        vram_capacity = {
            "RTX 3090": 24,
            "RTX 4090": 24,
            "RTX A4000": 16,
            "RTX A5000": 24,
            "RTX A6000": 48,
            "V100": 32,
            "T4": 16,
            "A10": 24,
            "A40": 48,
            "A100 40GB": 40,
            "A100 80GB": 80,
            "H100 80GB": 80,
            "H100 SXM": 80,
        }.get(gpu_type, 40)

        oom_risk = baseline_vram_gb > vram_capacity

    tracker = CostTracker(gpu_type=gpu_type, num_gpus=num_gpus)
    tracker._start_time = 0.0
    tracker._end_time = training_hours * 3600.0
    tracker.update_baseline_vram(baseline_vram_gb, oom_risk=oom_risk)
    tracker.update_memscale_vram(memscale_vram_gb)
    tracker.update_throughput_overhead(overhead_pct)

    return tracker.report()