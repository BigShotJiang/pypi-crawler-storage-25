"""Distributed training support for MemScale.

Handles multi-GPU (DDP) and multi-node (FSDP) scenarios.
"""
from __future__ import annotations

import logging
import os
from typing import Optional

import torch
import torch.distributed as dist

logger = logging.getLogger(__name__)


class DistributedContext:
    """Context for distributed training detection and management."""

    def __init__(self):
        self.is_distributed = False
        self.world_size = 1
        self.rank = 0
        self.local_rank = 0
        self.backend = None

        self._detect()

    def _detect(self) -> None:
        """Auto-detect distributed training setup."""
        # Check if PyTorch DDP is initialized
        if dist.is_available() and dist.is_initialized():
            self.is_distributed = True
            self.world_size = dist.get_world_size()
            self.rank = dist.get_rank()
            self.backend = dist.get_backend()
            logger.info(
                f"Detected DDP: rank={self.rank}/{self.world_size}, backend={self.backend}"
            )

        # Try to detect via environment variables (before init_process_group)
        elif "RANK" in os.environ or "LOCAL_RANK" in os.environ:
            self.is_distributed = True
            self.rank = int(os.environ.get("RANK", 0))
            self.world_size = int(os.environ.get("WORLD_SIZE", 1))
            self.local_rank = int(os.environ.get("LOCAL_RANK", 0))
            logger.info(
                f"Detected distributed env vars: rank={self.rank}/{self.world_size}"
            )

        if self.is_distributed:
            # Set device to local rank for DDP
            if torch.cuda.is_available():
                torch.cuda.set_device(self.local_rank)

    @property
    def is_main_process(self) -> bool:
        """Whether this is the main process (rank 0)."""
        return self.rank == 0

    @property
    def device(self) -> torch.device:
        """Current device for this process."""
        if torch.cuda.is_available():
            return torch.device(f"cuda:{self.local_rank}")
        return torch.device("cpu")

    def barrier(self) -> None:
        """Synchronize all processes."""
        if self.is_distributed and dist.is_initialized():
            dist.barrier()

    def all_reduce_mean(self, tensor: torch.Tensor) -> torch.Tensor:
        """Average a tensor across all processes."""
        if not self.is_distributed or not dist.is_initialized():
            return tensor

        dist.all_reduce(tensor, op=dist.ReduceOp.SUM)
        return tensor / self.world_size


def get_distributed_context() -> DistributedContext:
    """Get the current distributed training context (singleton)."""
    if not hasattr(get_distributed_context, "_instance"):
        get_distributed_context._instance = DistributedContext()
    return get_distributed_context._instance


def wrap_ddp_model(model: torch.nn.Module) -> torch.nn.Module:
    """Wrap a model with DistributedDataParallel if in distributed mode.

    This is a helper for users who haven't wrapped their model yet.
    MemScale works on both DDP-wrapped and unwrapped models.

    Args:
        model: PyTorch model to wrap

    Returns:
        DDP-wrapped model if distributed, else original model
    """
    ctx = get_distributed_context()

    if not ctx.is_distributed:
        return model

    # Check if already wrapped
    if isinstance(model, torch.nn.parallel.DistributedDataParallel):
        logger.debug("Model already wrapped with DDP")
        return model

    try:
        from torch.nn.parallel import DistributedDataParallel as DDP

        model = model.to(ctx.device)
        ddp_model = DDP(
            model,
            device_ids=[ctx.local_rank] if torch.cuda.is_available() else None,
            output_device=ctx.local_rank if torch.cuda.is_available() else None,
        )
        logger.info(f"Wrapped model with DDP on rank {ctx.rank}")
        return ddp_model
    except Exception as e:
        logger.warning(f"Failed to wrap model with DDP: {e}")
        return model


def should_log() -> bool:
    """Whether the current process should log to console/files.

    Use this to avoid duplicate logs from all ranks.
    """
    return get_distributed_context().is_main_process