"""Compatibility layer for FSDP and DeepSpeed.

These frameworks already do memory optimization. MemScale needs to detect
them and either:
1. Cooperate (apply complementary techniques)
2. Step aside (don't conflict)
3. Warn the user about potential conflicts
"""
from __future__ import annotations

import logging
from enum import Enum
from typing import Any, Optional

import torch
import torch.nn as nn

logger = logging.getLogger(__name__)


class TrainingFramework(Enum):
    """Detected training framework / strategy."""

    PURE_PYTORCH = "pure_pytorch"
    DDP = "ddp"
    FSDP = "fsdp"
    DEEPSPEED = "deepspeed"
    UNKNOWN = "unknown"


def detect_framework(model: nn.Module) -> TrainingFramework:
    """Detect what training framework is wrapping the model.

    Args:
        model: PyTorch model (possibly wrapped)

    Returns:
        TrainingFramework enum
    """
    # Check DDP
    if isinstance(model, torch.nn.parallel.DistributedDataParallel):
        return TrainingFramework.DDP

    # Check FSDP
    try:
        from torch.distributed.fsdp import FullyShardedDataParallel as FSDP

        if isinstance(model, FSDP):
            return TrainingFramework.FSDP
    except ImportError:
        pass

    # Check for DeepSpeed (DeepSpeedEngine wraps the model)
    try:
        import deepspeed

        if isinstance(model, deepspeed.DeepSpeedEngine):
            return TrainingFramework.DEEPSPEED
    except ImportError:
        pass

    # Check class name for hints
    class_name = type(model).__name__
    if "DeepSpeed" in class_name:
        return TrainingFramework.DEEPSPEED
    if "FSDP" in class_name or "FullyShardedDataParallel" in class_name:
        return TrainingFramework.FSDP

    return TrainingFramework.PURE_PYTORCH


class CompatibilityChecker:
    """Check if MemScale can be applied alongside other frameworks.

    Some combinations work great (MemScale + DDP).
    Some need care (MemScale + FSDP — overlap in checkpointing).
    Some are not yet supported (MemScale + DeepSpeed ZeRO-3).
    """

    @staticmethod
    def check_compatibility(model: nn.Module) -> dict:
        """Check if MemScale can be applied to this model.

        Args:
            model: PyTorch model

        Returns:
            Dict with:
                - compatible: bool
                - framework: TrainingFramework
                - warnings: list[str]
                - recommendations: list[str]
        """
        framework = detect_framework(model)
        warnings_list = []
        recommendations = []
        compatible = True

        if framework == TrainingFramework.PURE_PYTORCH:
            recommendations.append(
                "Pure PyTorch model detected. MemScale can apply all optimizations."
            )

        elif framework == TrainingFramework.DDP:
            recommendations.append(
                "DDP detected. MemScale will profile underlying model and apply per-GPU optimizations."
            )

        elif framework == TrainingFramework.FSDP:
            warnings_list.append(
                "FSDP already shards model parameters across GPUs. "
                "MemScale's CPU offloading may conflict with FSDP's CPU offload."
            )
            recommendations.extend(
                [
                    "Disable MemScale CPU offloading (use Config(enable_offloading=False))",
                    "MemScale activation checkpointing still works alongside FSDP",
                    "MemScale tiling still provides benefit for very wide layers",
                ]
            )

        elif framework == TrainingFramework.DEEPSPEED:
            warnings_list.append(
                "DeepSpeed detected. DeepSpeed ZeRO already does aggressive memory optimization."
            )
            recommendations.extend(
                [
                    "MemScale + DeepSpeed ZeRO-1/2: Generally compatible, MemScale adds layer-level optimization",
                    "MemScale + DeepSpeed ZeRO-3: Not recommended — both shard parameters, conflicts likely",
                    "Consider using MemScale OR DeepSpeed, not both, for ZeRO-3 setups",
                ]
            )

        elif framework == TrainingFramework.UNKNOWN:
            warnings_list.append(
                "Unknown framework wrapping. Behavior undefined."
            )
            recommendations.append(
                "Try unwrapping model before passing to MemScale, or use Config(force_apply=True)"
            )

        return {
            "compatible": compatible,
            "framework": framework,
            "warnings": warnings_list,
            "recommendations": recommendations,
        }

    @staticmethod
    def adapt_config(config, framework: TrainingFramework):
        """Adapt MemScale config based on detected framework.

        Args:
            config: MemScale Config
            framework: Detected framework

        Returns:
            Adapted Config (may be same instance if no changes needed)
        """
        from memscale.core.config import Config

        if framework == TrainingFramework.FSDP:
            # FSDP already does CPU offloading — disable in MemScale to avoid conflict
            adapted = Config(
                mode=config.mode,
                enable_checkpointing=config.enable_checkpointing,
                enable_offloading=False,  # FSDP handles this
                enable_tiling=config.enable_tiling,
                target_gpu_utilization=config.target_gpu_utilization,
            )
            logger.info("Adapted config for FSDP: disabled CPU offloading")
            return adapted

        if framework == TrainingFramework.DEEPSPEED:
            # Conservative: only checkpointing, let DeepSpeed handle the rest
            adapted = Config(
                mode=config.mode,
                enable_checkpointing=config.enable_checkpointing,
                enable_offloading=False,
                enable_tiling=False,
                target_gpu_utilization=config.target_gpu_utilization,
            )
            logger.info(
                "Adapted config for DeepSpeed: only activation checkpointing enabled"
            )
            return adapted

        return config


def safe_wrap_with_compatibility(
    model: nn.Module, config=None, sample_input: Optional[torch.Tensor] = None
):
    """Wrap a model with MemScale, with automatic compatibility handling.

    Args:
        model: PyTorch model (possibly wrapped with DDP/FSDP/DeepSpeed)
        config: MemScale Config (optional)
        sample_input: Sample input for profiling

    Returns:
        Wrapped model
    """
    from memscale.api import wrap as _wrap
    from memscale.core.config import Config

    if config is None:
        config = Config()

    # Check compatibility
    check = CompatibilityChecker.check_compatibility(model)

    # Print warnings
    for warning in check["warnings"]:
        logger.warning(f"⚠ {warning}")
    for rec in check["recommendations"]:
        logger.info(f"→ {rec}")

    # Adapt config if needed
    config = CompatibilityChecker.adapt_config(config, check["framework"])

    # Wrap with MemScale
    return _wrap(model, config=config, sample_input=sample_input)