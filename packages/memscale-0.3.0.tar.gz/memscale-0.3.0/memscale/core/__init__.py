"""
MemScale — Drop-in memory optimizer for PyTorch training.

Usage:
    import memscale

    trainer = memscale.wrap(your_trainer)
    # That's it. VRAM optimization is now active.
"""

from memscale.core.profiler import MemoryProfiler
from memscale.core.decision_engine import DecisionEngine
from memscale.core.executor import Executor
from memscale.core.config import Config, OptimizationMode
from memscale.api import wrap, optimize

__version__ = "0.1.0"

__all__ = [
    "wrap",
    "optimize",
    "Config",
    "OptimizationMode",
    "MemoryProfiler",
    "DecisionEngine",
    "Executor",
    "__version__",
]