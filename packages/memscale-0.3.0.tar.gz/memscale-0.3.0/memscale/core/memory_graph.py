"""Memory graph data structures.

Represents the per-layer memory profile of a model, used as input
to the decision engine.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional


@dataclass
class LayerMemoryInfo:
    """Memory profile of a single layer in the model.

    Attributes:
        name: Fully qualified layer name (e.g., "model.layers.0.attention")
        param_bytes: Bytes used by parameters (weights + biases)
        activation_bytes: Estimated activation memory during forward pass
        gradient_bytes: Bytes for gradients (typically same as param_bytes)
        flops: Estimated FLOPs for forward pass (used for compute/memory ratio)
        layer_type: PyTorch module type name (e.g., "Linear", "MultiheadAttention")
        is_trainable: Whether layer has trainable parameters
    """

    name: str
    param_bytes: int = 0
    activation_bytes: int = 0
    gradient_bytes: int = 0
    flops: int = 0
    layer_type: str = "Unknown"
    is_trainable: bool = True

    @property
    def total_memory_bytes(self) -> int:
        """Total memory footprint during training (params + grads + activations)."""
        return self.param_bytes + self.gradient_bytes + self.activation_bytes

    @property
    def compute_to_memory_ratio(self) -> float:
        """FLOPs per byte. Higher = more compute-bound, recompute is cheaper."""
        if self.activation_bytes == 0:
            return float("inf")
        return self.flops / self.activation_bytes

    def __str__(self) -> str:
        mb = 1024 * 1024
        return (
            f"LayerMemoryInfo({self.name}: type={self.layer_type}, "
            f"params={self.param_bytes / mb:.1f}MB, "
            f"acts={self.activation_bytes / mb:.1f}MB, "
            f"flops={self.flops / 1e9:.2f}G)"
        )


@dataclass
class MemoryGraph:
    """Graph of all layers in the model and their memory profiles.

    The decision engine uses this to plan which optimization technique
    to apply to each layer.
    """

    layers: Dict[str, LayerMemoryInfo] = field(default_factory=dict)
    model_name: Optional[str] = None
    total_params: int = 0
    profiling_method: str = "unknown"  # "static" | "empirical" | "unknown"

    def add_layer(self, info: LayerMemoryInfo) -> None:
        self.layers[info.name] = info
        self.total_params += info.param_bytes // 4  # Assume FP32 for param count

    def total_memory_bytes(self) -> int:
        return sum(layer.total_memory_bytes for layer in self.layers.values())

    def total_activation_bytes(self) -> int:
        return sum(layer.activation_bytes for layer in self.layers.values())

    def total_param_bytes(self) -> int:
        return sum(layer.param_bytes for layer in self.layers.values())

    def layers_sorted_by_memory(self) -> List[LayerMemoryInfo]:
        """Return layers sorted by total memory footprint, descending."""
        return sorted(self.layers.values(), key=lambda x: x.total_memory_bytes, reverse=True)

    def __str__(self) -> str:
        gb = 1024**3
        return (
            f"MemoryGraph(model={self.model_name}, layers={len(self.layers)}, "
            f"params={self.total_params / 1e6:.1f}M, "
            f"total_mem={self.total_memory_bytes() / gb:.2f}GB, "
            f"method={self.profiling_method})"
        )

    def summary(self) -> str:
        """Human-readable summary of the memory graph."""
        lines = [str(self), "Top 5 layers by memory:"]
        for layer in self.layers_sorted_by_memory()[:5]:
            lines.append(f"  - {layer}")
        return "\n".join(lines)