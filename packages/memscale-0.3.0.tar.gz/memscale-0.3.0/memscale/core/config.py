"""Configuration classes for MemScale.

This module defines the user-facing configuration API and internal
hardware budget representation.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class OptimizationMode(str, Enum):
    """Optimization aggressiveness mode.

    - CONSERVATIVE: Only optimize when VRAM > 90% capacity. Safest, least overhead.
    - BALANCED: Default. Optimize when VRAM > 75% capacity. Good speed-memory trade-off.
    - AGGRESSIVE: Always optimize. Lowest VRAM usage, may have small overhead.
    """

    CONSERVATIVE = "conservative"
    BALANCED = "balanced"
    AGGRESSIVE = "aggressive"


@dataclass
class Config:
    """User-facing configuration for MemScale.

    Most users won't need to set anything — defaults work for 90% of cases.

    Example:
        config = Config(
            mode=OptimizationMode.BALANCED,
            enable_offloading=True,
            max_cpu_offload_gb=64,
        )
    """

    # Optimization aggressiveness
    mode: OptimizationMode = OptimizationMode.BALANCED

    # Which techniques to enable
    enable_checkpointing: bool = True
    enable_offloading: bool = True
    enable_tiling: bool = False  # Disabled by default (more experimental)

    # Resource limits
    max_cpu_offload_gb: Optional[float] = None  # None = use available CPU RAM
    target_gpu_utilization: float = 0.85  # Try to use this fraction of GPU memory

    # Profiling
    use_static_profiling: bool = True  # Try torch.fx first
    use_empirical_fallback: bool = True  # Fallback to runtime profiling
    warmup_steps: int = 2  # For empirical profiling

    # Observability
    enable_logging: bool = True
    log_file: Optional[str] = None  # None = stdout only
    observability_port: Optional[int] = None  # If set, expose Prometheus metrics

    # Cost tracking
    gpu_cost_per_hour: float = 2.50  # Default H100 spot rate (USD)

    # Safety
    verify_correctness: bool = False  # If True, runs baseline comparison (slow!)

    def __post_init__(self) -> None:
        if self.target_gpu_utilization <= 0 or self.target_gpu_utilization > 1.0:
            raise ValueError(
                f"target_gpu_utilization must be in (0, 1], got {self.target_gpu_utilization}"
            )
        if self.warmup_steps < 1:
            raise ValueError(f"warmup_steps must be >= 1, got {self.warmup_steps}")


@dataclass
class HardwareBudget:
    """Available hardware resources detected at runtime.

    Populated by Profiler.detect_hardware() — users shouldn't construct this directly.
    """

    gpu_total_bytes: int
    gpu_available_bytes: int
    cpu_total_bytes: int
    cpu_available_bytes: int
    num_gpus: int
    pcie_bandwidth_gbps: float = 16.0  # Reasonable default for PCIe 4.0 x16

    @property
    def gpu_total_gb(self) -> float:
        return self.gpu_total_bytes / (1024**3)

    @property
    def gpu_available_gb(self) -> float:
        return self.gpu_available_bytes / (1024**3)

    @property
    def cpu_total_gb(self) -> float:
        return self.cpu_total_bytes / (1024**3)

    @property
    def cpu_available_gb(self) -> float:
        return self.cpu_available_bytes / (1024**3)

    def __str__(self) -> str:
        return (
            f"HardwareBudget(GPU: {self.gpu_available_gb:.1f}/{self.gpu_total_gb:.1f} GB, "
            f"CPU: {self.cpu_available_gb:.1f}/{self.cpu_total_gb:.1f} GB, "
            f"GPUs: {self.num_gpus})"
        )