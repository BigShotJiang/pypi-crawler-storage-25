"""Memory profiler for PyTorch models.

Two modes:
1. Static profiling via torch.fx (fast, ~1-2 sec)
2. Empirical profiling via runtime hooks (slower, more accurate)

Static is tried first; falls back to empirical if tracing fails.
"""
from __future__ import annotations

import logging
import time
from typing import Optional

import torch
import torch.nn as nn

from memscale.core.config import HardwareBudget
from memscale.core.memory_graph import LayerMemoryInfo, MemoryGraph

logger = logging.getLogger(__name__)


class MemoryProfiler:
    """Profile memory usage per layer in a PyTorch model.

    Example:
        profiler = MemoryProfiler()
        graph = profiler.profile(model, sample_input)
        print(graph.summary())
    """

    def __init__(self, prefer_static: bool = True, fallback_empirical: bool = True):
        self.prefer_static = prefer_static
        self.fallback_empirical = fallback_empirical

    def detect_hardware(self) -> HardwareBudget:
        """Detect available GPU and CPU memory."""
        import psutil

        # GPU memory
        if torch.cuda.is_available():
            gpu_total = torch.cuda.get_device_properties(0).total_memory
            gpu_free, _ = torch.cuda.mem_get_info(0)
            num_gpus = torch.cuda.device_count()
        else:
            gpu_total = 0
            gpu_free = 0
            num_gpus = 0

        # CPU memory
        vm = psutil.virtual_memory()
        cpu_total = vm.total
        cpu_available = vm.available

        return HardwareBudget(
            gpu_total_bytes=gpu_total,
            gpu_available_bytes=gpu_free,
            cpu_total_bytes=cpu_total,
            cpu_available_bytes=cpu_available,
            num_gpus=num_gpus,
        )

    def profile(
        self,
        model: nn.Module,
        sample_input: Optional[torch.Tensor] = None,
        model_name: Optional[str] = None,
    ) -> MemoryGraph:
        """Profile a model and return a memory graph.

        Args:
            model: PyTorch model to profile (DDP-wrapped or unwrapped)
            sample_input: Sample input tensor (required for empirical profiling)
            model_name: Optional name for the model

        Returns:
            MemoryGraph with per-layer memory info
        """
        # Unwrap DDP if present — we profile the underlying model
        unwrapped_model = self._unwrap_ddp(model)
        graph = MemoryGraph(model_name=model_name or unwrapped_model.__class__.__name__)

        # Try static profiling first
        if self.prefer_static:
            try:
                logger.info("Attempting static profiling via torch.fx...")
                start = time.time()
                self._profile_static(unwrapped_model, graph, sample_input)
                graph.profiling_method = "static"
                logger.info(f"Static profiling completed in {time.time() - start:.2f}s")
                return graph
            except Exception as e:
                logger.warning(f"Static profiling failed: {e}")
                if not self.fallback_empirical:
                    raise

        # Fall back to empirical
        if sample_input is None:
            raise ValueError(
                "Empirical profiling requires sample_input. "
                "Provide a sample tensor matching your training data shape."
            )

        logger.info("Running empirical profiling...")
        start = time.time()
        self._profile_empirical(unwrapped_model, graph, sample_input)
        graph.profiling_method = "empirical"
        logger.info(f"Empirical profiling completed in {time.time() - start:.2f}s")
        return graph

    @staticmethod
    def _unwrap_ddp(model: nn.Module) -> nn.Module:
        """Unwrap DDP/FSDP wrapper to get the underlying model."""
        # Check for DDP
        if isinstance(model, torch.nn.parallel.DistributedDataParallel):
            return model.module
        # Check for DataParallel (legacy)
        if isinstance(model, torch.nn.DataParallel):
            return model.module
        # Check for FSDP (future support)
        if hasattr(torch.distributed, "fsdp") and isinstance(
            model, torch.distributed.fsdp.FullyShardedDataParallel
        ):
            return model.module
        return model

    def _profile_static(
        self,
        model: nn.Module,
        graph: MemoryGraph,
        sample_input: Optional[torch.Tensor],
    ) -> None:
        """Static profiling: walk module tree and estimate memory.

        This doesn't run the model — it just inspects parameters and estimates
        activation sizes based on layer types and shapes.
        """
        for name, module in model.named_modules():
            if not name:  # Skip root module
                continue

            # Skip container modules (Sequential, ModuleList) — count their children only
            if self._is_container(module):
                continue

            param_bytes = sum(p.numel() * p.element_size() for p in module.parameters(recurse=False))

            # Estimate activation size based on layer type
            # This is heuristic — empirical mode gives accurate numbers
            activation_bytes = self._estimate_activation_size(module, sample_input)

            # Gradient size = param size (one gradient per param)
            gradient_bytes = param_bytes

            # FLOPs estimate (rough)
            flops = self._estimate_flops(module, sample_input)

            info = LayerMemoryInfo(
                name=name,
                param_bytes=param_bytes,
                activation_bytes=activation_bytes,
                gradient_bytes=gradient_bytes,
                flops=flops,
                layer_type=type(module).__name__,
                is_trainable=any(p.requires_grad for p in module.parameters()),
            )
            graph.add_layer(info)

    def _profile_empirical(
        self,
        model: nn.Module,
        graph: MemoryGraph,
        sample_input: torch.Tensor,
    ) -> None:
        """Empirical profiling: register hooks and measure actual memory.

        Runs forward + backward passes with memory tracking hooks attached.
        """
        if not torch.cuda.is_available():
            logger.warning("CUDA not available, empirical profiling will be limited")

        layer_stats: dict = {}
        hooks = []

        # Count layers for progress tracking
        num_layers = sum(
            1
            for name, module in model.named_modules()
            if name and not self._is_container(module)
        )

        from memscale.utils import ProgressLogger

        progress = ProgressLogger(num_layers, desc="Profiling layers")

        def make_hook(name: str, module: nn.Module):
            def hook(mod, inp, out):
                # Estimate activation bytes from output shape
                if isinstance(out, torch.Tensor):
                    activation_bytes = out.numel() * out.element_size()
                elif isinstance(out, (tuple, list)) and len(out) > 0:
                    activation_bytes = sum(
                        o.numel() * o.element_size()
                        for o in out
                        if isinstance(o, torch.Tensor)
                    )
                else:
                    activation_bytes = 0

                param_bytes = sum(
                    p.numel() * p.element_size() for p in mod.parameters(recurse=False)
                )

                layer_stats[name] = {
                    "param_bytes": param_bytes,
                    "activation_bytes": activation_bytes,
                    "layer_type": type(mod).__name__,
                    "is_trainable": any(p.requires_grad for p in mod.parameters()),
                }
                progress.update(1)

            return hook

        # Register hooks on leaf modules
        for name, module in model.named_modules():
            if not name or self._is_container(module):
                continue
            handle = module.register_forward_hook(make_hook(name, module))
            hooks.append(handle)

        # Run forward pass
        try:
            model.eval()
            with torch.no_grad():
                _ = model(sample_input)
        finally:
            # Clean up hooks
            for h in hooks:
                h.remove()
            progress.close()

        # Build graph from collected stats
        for name, stats in layer_stats.items():
            info = LayerMemoryInfo(
                name=name,
                param_bytes=stats["param_bytes"],
                activation_bytes=stats["activation_bytes"],
                gradient_bytes=stats["param_bytes"],  # Approx
                flops=0,  # Skip FLOPs in empirical mode for speed
                layer_type=stats["layer_type"],
                is_trainable=stats["is_trainable"],
            )
            graph.add_layer(info)

    @staticmethod
    def _is_container(module: nn.Module) -> bool:
        """Check if module is a container (Sequential, ModuleList, ModuleDict)."""
        return isinstance(module, (nn.Sequential, nn.ModuleList, nn.ModuleDict)) or (
            type(module) is nn.Module
        )

    @staticmethod
    def _estimate_activation_size(
        module: nn.Module, sample_input: Optional[torch.Tensor]
    ) -> int:
        """Heuristic estimate of activation memory for a layer."""
        if sample_input is None:
            # No sample input — use parameter size as rough proxy
            return sum(p.numel() * p.element_size() for p in module.parameters(recurse=False))

        batch_size = sample_input.shape[0] if sample_input.dim() > 0 else 1

        if isinstance(module, nn.Linear):
            # Output: [batch, seq, out_features] for typical transformer use
            return batch_size * module.out_features * 4  # FP32
        elif isinstance(module, nn.LayerNorm):
            normalized_shape_size = (
                module.normalized_shape[0]
                if isinstance(module.normalized_shape, (list, tuple))
                else module.normalized_shape
            )
            return batch_size * normalized_shape_size * 4
        elif isinstance(module, nn.Embedding):
            return batch_size * module.embedding_dim * 4
        elif isinstance(module, nn.MultiheadAttention):
            # Attention is O(seq^2) — rough estimate
            return batch_size * module.embed_dim * 4 * 4  # 4× factor for Q,K,V,attn
        else:
            # Generic fallback: use param size as proxy
            return sum(p.numel() * p.element_size() for p in module.parameters(recurse=False))

    @staticmethod
    def _estimate_flops(module: nn.Module, sample_input: Optional[torch.Tensor]) -> int:
        """Rough FLOPs estimate for a layer."""
        if isinstance(module, nn.Linear):
            return 2 * module.in_features * module.out_features
        elif isinstance(module, nn.MultiheadAttention):
            return 4 * module.embed_dim * module.embed_dim
        else:
            # Fallback: param count × 2
            return sum(p.numel() for p in module.parameters(recurse=False)) * 2