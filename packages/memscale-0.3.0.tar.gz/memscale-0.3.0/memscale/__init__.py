"""
MemScale - Drop-in memory optimizer for PyTorch training.

Usage:
    import memscale

    trainer = memscale.wrap(your_trainer)
    # That's it. VRAM optimization is now active.
"""

# Core
from memscale.core.profiler import MemoryProfiler
from memscale.core.decision_engine import DecisionEngine
from memscale.core.executor import Executor
from memscale.core.config import Config, OptimizationMode

# Public API
from memscale.api import wrap, optimize, detach

# Distributed
from memscale.distributed import get_distributed_context, wrap_ddp_model

# v0.2 features
from memscale.autotuning import AutoTuner

# Phase 3 features (NEW in v0.3)
from memscale.oom_predictor import OOMPredictor, OOMRisk, OOMPrediction
from memscale.cost_attribution import CostTracker, CostReport, estimate_savings
from memscale.compatibility import (
    detect_framework,
    TrainingFramework,
    CompatibilityChecker,
    safe_wrap_with_compatibility,
)

__version__ = "0.3.0"

__all__ = [
    # Public API
    "wrap",
    "optimize",
    "detach",
    "safe_wrap_with_compatibility",
    # Configuration
    "Config",
    "OptimizationMode",
    # Core components
    "MemoryProfiler",
    "DecisionEngine",
    "Executor",
    # Distributed
    "get_distributed_context",
    "wrap_ddp_model",
    # Auto-tuning
    "AutoTuner",
    # OOM prediction
    "OOMPredictor",
    "OOMRisk",
    "OOMPrediction",
    # Cost attribution
    "CostTracker",
    "CostReport",
    "estimate_savings",
    # Compatibility
    "detect_framework",
    "TrainingFramework",
    "CompatibilityChecker",
    # Version
    "__version__",
]