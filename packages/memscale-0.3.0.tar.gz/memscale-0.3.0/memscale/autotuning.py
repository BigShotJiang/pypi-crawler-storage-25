"""Auto-tuning mode — learns optimal configurations from past runs.

This is a v0.2 feature that improves decision quality over time.
"""
from __future__ import annotations

import json
import logging
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, List, Optional

from memscale.core.config import OptimizationMode
from memscale.core.decision_engine import Technique

logger = logging.getLogger(__name__)


@dataclass
class RunMetrics:
    """Metrics from a single training run."""

    model_name: str
    model_params: int
    batch_size: int
    seq_length: int

    # Configuration used
    optimization_mode: str
    techniques_applied: Dict[str, str]  # layer_name -> technique

    # Results
    vram_peak_gb: float
    vram_reduction_pct: float
    throughput_overhead_pct: float
    numerical_error: float  # Max abs diff from baseline

    # Context
    gpu_name: str
    timestamp: float


class AutoTuner:
    """Learn from past runs to improve future decisions.

    Stores run history in ~/.memscale/history.jsonl and uses it to:
    - Recommend better optimization modes
    - Suggest which techniques work best for similar models
    - Predict VRAM savings before running

    Usage:
        tuner = AutoTuner()
        tuner.record_run(metrics)
        recommendation = tuner.recommend_config(model_name, model_params)
    """

    def __init__(self, history_path: Optional[Path] = None):
        if history_path is None:
            history_path = Path.home() / ".memscale" / "history.jsonl"

        self.history_path = history_path
        self.history_path.parent.mkdir(parents=True, exist_ok=True)

        self.runs: List[RunMetrics] = []
        self._load_history()

    def _load_history(self) -> None:
        """Load past runs from disk."""
        if not self.history_path.exists():
            return

        try:
            with open(self.history_path, "r") as f:
                for line in f:
                    if line.strip():
                        data = json.loads(line)
                        self.runs.append(RunMetrics(**data))
            logger.info(f"Loaded {len(self.runs)} past runs from {self.history_path}")
        except Exception as e:
            logger.warning(f"Failed to load run history: {e}")

    def record_run(self, metrics: RunMetrics) -> None:
        """Record a new training run."""
        self.runs.append(metrics)

        # Append to history file
        try:
            with open(self.history_path, "a") as f:
                f.write(json.dumps(asdict(metrics)) + "\n")
        except Exception as e:
            logger.warning(f"Failed to save run to history: {e}")

    def recommend_config(
        self, model_name: str, model_params: int, gpu_name: Optional[str] = None
    ) -> Dict[str, any]:
        """Recommend configuration based on past runs.

        Args:
            model_name: Name of the model (e.g., "Llama-3-8B")
            model_params: Number of parameters
            gpu_name: GPU model name (optional, for matching similar hardware)

        Returns:
            Dict with:
                - recommended_mode: OptimizationMode
                - confidence: 0-1 score
                - predicted_vram_reduction_pct: float
                - rationale: str
        """
        if not self.runs:
            return {
                "recommended_mode": OptimizationMode.BALANCED,
                "confidence": 0.0,
                "predicted_vram_reduction_pct": 50.0,
                "rationale": "No past runs available — using default BALANCED mode.",
            }

        # Find similar runs (same model or similar param count)
        similar_runs = [
            run
            for run in self.runs
            if run.model_name == model_name
            or abs(run.model_params - model_params) / model_params < 0.2
        ]

        if not similar_runs:
            return {
                "recommended_mode": OptimizationMode.BALANCED,
                "confidence": 0.0,
                "predicted_vram_reduction_pct": 50.0,
                "rationale": "No similar past runs found — using default BALANCED mode.",
            }

        # Find the run with best vram_reduction / overhead trade-off
        best_run = max(
            similar_runs,
            key=lambda r: r.vram_reduction_pct - r.throughput_overhead_pct * 2,
        )

        confidence = len(similar_runs) / max(10, len(self.runs))  # 0-1 score

        return {
            "recommended_mode": best_run.optimization_mode,
            "confidence": confidence,
            "predicted_vram_reduction_pct": best_run.vram_reduction_pct,
            "predicted_overhead_pct": best_run.throughput_overhead_pct,
            "rationale": (
                f"Based on {len(similar_runs)} similar past run(s), "
                f"{best_run.optimization_mode} achieved {best_run.vram_reduction_pct:.1f}% "
                f"VRAM reduction with {best_run.throughput_overhead_pct:.1f}% overhead."
            ),
        }

    def get_best_technique_for_layer_type(self, layer_type: str) -> Optional[Technique]:
        """Get the technique that worked best historically for a layer type.

        Args:
            layer_type: PyTorch module type name (e.g., "Linear", "MultiheadAttention")

        Returns:
            Best technique, or None if insufficient data
        """
        technique_counts: Dict[Technique, List[float]] = {}

        for run in self.runs:
            for layer_name, technique_str in run.techniques_applied.items():
                if layer_type in layer_name:  # Heuristic match
                    technique = Technique(technique_str)
                    if technique not in technique_counts:
                        technique_counts[technique] = []
                    # Weight by VRAM reduction
                    technique_counts[technique].append(run.vram_reduction_pct)

        if not technique_counts:
            return None

        # Pick technique with highest average VRAM reduction
        best_technique = max(
            technique_counts.items(), key=lambda kv: sum(kv[1]) / len(kv[1])
        )[0]

        return best_technique

    def summary(self) -> str:
        """Human-readable summary of tuning data."""
        if not self.runs:
            return "No runs recorded yet."

        avg_vram_reduction = sum(r.vram_reduction_pct for r in self.runs) / len(self.runs)
        avg_overhead = sum(r.throughput_overhead_pct for r in self.runs) / len(self.runs)

        models = set(r.model_name for r in self.runs)

        return (
            f"AutoTuner: {len(self.runs)} runs recorded.\n"
            f"  Models tested: {', '.join(sorted(models))}\n"
            f"  Avg VRAM reduction: {avg_vram_reduction:.1f}%\n"
            f"  Avg throughput overhead: {avg_overhead:.1f}%"
        )