"""Prometheus metrics endpoint for MemScale.

Exposes training metrics via HTTP for monitoring with Prometheus/Grafana.
"""
from __future__ import annotations

import logging
import threading
import time
from typing import Dict, Optional

logger = logging.getLogger(__name__)

# Optional dependency
try:
    from prometheus_client import (
        CollectorRegistry,
        Counter,
        Gauge,
        Histogram,
        start_http_server,
    )

    PROMETHEUS_AVAILABLE = True
except ImportError:
    PROMETHEUS_AVAILABLE = False


class MetricsServer:
    """HTTP server exposing MemScale metrics in Prometheus format.

    Usage:
        from memscale.observability.metrics import MetricsServer

        # Start metrics server on port 9090
        server = MetricsServer(port=9090)
        server.start()

        # Record metrics during training
        server.record_vram_allocated(12.5)  # GB
        server.record_step_time(0.087)  # seconds
        server.record_optimization_applied("checkpoint", "layer.5")

        # Access at http://localhost:9090/metrics
    """

    def __init__(self, port: int = 9090, registry: Optional[object] = None):
        if not PROMETHEUS_AVAILABLE:
            logger.warning(
                "prometheus_client not installed. "
                "Install with: pip install memscale[observability]"
            )

        self.port = port
        self.registry = registry or (CollectorRegistry() if PROMETHEUS_AVAILABLE else None)
        self._server = None
        self._started = False

        if PROMETHEUS_AVAILABLE:
            self._init_metrics()

    def _init_metrics(self) -> None:
        """Initialize Prometheus metric objects."""
        # VRAM metrics
        self.vram_allocated_gb = Gauge(
            "memscale_vram_allocated_gb",
            "Currently allocated VRAM in GB",
            registry=self.registry,
        )
        self.vram_peak_gb = Gauge(
            "memscale_vram_peak_gb",
            "Peak VRAM usage in GB",
            registry=self.registry,
        )
        self.vram_reduction_pct = Gauge(
            "memscale_vram_reduction_percent",
            "VRAM reduction percentage vs baseline",
            registry=self.registry,
        )

        # Performance metrics
        self.step_time_seconds = Histogram(
            "memscale_step_time_seconds",
            "Time per training step in seconds",
            buckets=(0.01, 0.05, 0.1, 0.5, 1.0, 5.0, 10.0),
            registry=self.registry,
        )
        self.throughput_samples_per_sec = Gauge(
            "memscale_throughput_samples_per_second",
            "Training throughput in samples/second",
            registry=self.registry,
        )

        # Optimization counters
        self.optimizations_applied = Counter(
            "memscale_optimizations_applied_total",
            "Number of optimization techniques applied",
            ["technique", "layer_type"],
            registry=self.registry,
        )

        # OOM events
        self.oom_predictions = Counter(
            "memscale_oom_predictions_total",
            "Number of OOM predictions issued",
            ["severity"],
            registry=self.registry,
        )

        # Training progress
        self.training_steps = Counter(
            "memscale_training_steps_total",
            "Total training steps completed",
            registry=self.registry,
        )

    def start(self) -> bool:
        """Start the HTTP server.

        Returns:
            True if server started successfully, False otherwise
        """
        if not PROMETHEUS_AVAILABLE:
            logger.error("Cannot start metrics server — prometheus_client not installed")
            return False

        if self._started:
            logger.warning("Metrics server already started")
            return True

        try:
            start_http_server(self.port, registry=self.registry)
            self._started = True
            logger.info(
                f"MemScale metrics available at http://localhost:{self.port}/metrics"
            )
            return True
        except Exception as e:
            logger.error(f"Failed to start metrics server: {e}")
            return False

    def record_vram_allocated(self, gb: float) -> None:
        """Record current VRAM allocation."""
        if PROMETHEUS_AVAILABLE and self._started:
            self.vram_allocated_gb.set(gb)

    def record_vram_peak(self, gb: float) -> None:
        """Record peak VRAM."""
        if PROMETHEUS_AVAILABLE and self._started:
            self.vram_peak_gb.set(gb)

    def record_vram_reduction(self, percent: float) -> None:
        """Record VRAM reduction vs baseline."""
        if PROMETHEUS_AVAILABLE and self._started:
            self.vram_reduction_pct.set(percent)

    def record_step_time(self, seconds: float) -> None:
        """Record time for one training step."""
        if PROMETHEUS_AVAILABLE and self._started:
            self.step_time_seconds.observe(seconds)
            self.training_steps.inc()

    def record_throughput(self, samples_per_sec: float) -> None:
        """Record training throughput."""
        if PROMETHEUS_AVAILABLE and self._started:
            self.throughput_samples_per_sec.set(samples_per_sec)

    def record_optimization_applied(self, technique: str, layer_type: str) -> None:
        """Record that an optimization was applied to a layer."""
        if PROMETHEUS_AVAILABLE and self._started:
            self.optimizations_applied.labels(
                technique=technique, layer_type=layer_type
            ).inc()

    def record_oom_prediction(self, severity: str = "warning") -> None:
        """Record an OOM prediction event."""
        if PROMETHEUS_AVAILABLE and self._started:
            self.oom_predictions.labels(severity=severity).inc()


# Global singleton for easy access
_global_server: Optional[MetricsServer] = None


def get_metrics_server() -> Optional[MetricsServer]:
    """Get the global metrics server instance."""
    return _global_server


def start_metrics_server(port: int = 9090) -> Optional[MetricsServer]:
    """Start the global metrics server.

    Args:
        port: HTTP port to listen on (default 9090)

    Returns:
        MetricsServer instance, or None if Prometheus not available
    """
    global _global_server

    if _global_server is not None:
        logger.warning("Metrics server already running")
        return _global_server

    server = MetricsServer(port=port)
    if server.start():
        _global_server = server
        return server
    return None