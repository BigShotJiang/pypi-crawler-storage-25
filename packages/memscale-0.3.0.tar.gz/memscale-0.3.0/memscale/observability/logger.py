"""Structured JSON logger.

Emits training metrics in JSON format for consumption by W&B, MLflow,
or custom dashboards.
"""
from __future__ import annotations

import json
import logging
import sys
import time
from typing import Any, Optional, TextIO

from memscale.core.config import Config


class StructuredLogger:
    """Logger that emits structured JSON events.

    Each log entry is a JSON object on a single line, suitable for
    consumption by log aggregation tools.
    """

    _instance: Optional["StructuredLogger"] = None

    def __init__(self, output: TextIO = sys.stdout, log_file: Optional[str] = None):
        self.output = output
        self.log_file = log_file
        self._file_handle = None
        if log_file:
            self._file_handle = open(log_file, "a")

    def emit(self, event: str, **fields: Any) -> None:
        """Emit a structured log event.

        Args:
            event: Event name (e.g., "step", "init", "oom_warning")
            **fields: Additional fields to include in the log entry
        """
        entry = {
            "timestamp": time.time(),
            "event": event,
            **fields,
        }
        line = json.dumps(entry, default=str)

        try:
            self.output.write(line + "\n")
            self.output.flush()
        except Exception:
            pass

        if self._file_handle is not None:
            try:
                self._file_handle.write(line + "\n")
                self._file_handle.flush()
            except Exception:
                pass

    def info(self, event: str, **fields: Any) -> None:
        self.emit(event, level="info", **fields)

    def warning(self, event: str, **fields: Any) -> None:
        self.emit(event, level="warning", **fields)

    def error(self, event: str, **fields: Any) -> None:
        self.emit(event, level="error", **fields)

    def step(self, step_num: int, vram_peak_bytes: int, throughput: float, **extra: Any) -> None:
        """Convenience: log a training step's metrics."""
        self.emit(
            "step",
            step=step_num,
            vram_peak_gb=vram_peak_bytes / (1024**3),
            throughput_tokens_per_sec=throughput,
            **extra,
        )

    def close(self) -> None:
        if self._file_handle is not None:
            self._file_handle.close()


def get_logger(config: Optional[Config] = None) -> StructuredLogger:
    """Get the global structured logger (singleton)."""
    if StructuredLogger._instance is None:
        log_file = config.log_file if config else None
        StructuredLogger._instance = StructuredLogger(log_file=log_file)
    return StructuredLogger._instance