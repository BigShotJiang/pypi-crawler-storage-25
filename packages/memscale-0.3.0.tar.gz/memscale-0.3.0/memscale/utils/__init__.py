"""Utility functions for MemScale."""
from __future__ import annotations

import functools
import logging
import time
from typing import Any, Callable, Optional

import torch

logger = logging.getLogger(__name__)


def format_bytes(num_bytes: int) -> str:
    """Format bytes as human-readable string.

    Args:
        num_bytes: Number of bytes

    Returns:
        Formatted string (e.g., "1.5 GB", "256 MB")
    """
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if abs(num_bytes) < 1024.0:
            return f"{num_bytes:.1f} {unit}"
        num_bytes /= 1024.0
    return f"{num_bytes:.1f} PB"


def get_model_size(model: torch.nn.Module) -> tuple[int, int]:
    """Get model size in parameters and bytes.

    Args:
        model: PyTorch model

    Returns:
        Tuple of (num_parameters, num_bytes)
    """
    num_params = sum(p.numel() for p in model.parameters())
    num_bytes = sum(p.numel() * p.element_size() for p in model.parameters())
    return num_params, num_bytes


def get_gpu_memory_info() -> dict[str, int]:
    """Get current GPU memory usage.

    Returns:
        Dict with keys: allocated, reserved, free, total (all in bytes)
    """
    if not torch.cuda.is_available():
        return {"allocated": 0, "reserved": 0, "free": 0, "total": 0}

    allocated = torch.cuda.memory_allocated()
    reserved = torch.cuda.memory_reserved()
    total = torch.cuda.get_device_properties(0).total_memory
    free = total - allocated

    return {
        "allocated": allocated,
        "reserved": reserved,
        "free": free,
        "total": total,
    }


def profile_function(func: Callable) -> Callable:
    """Decorator to profile execution time of a function.

    Usage:
        @profile_function
        def my_slow_function():
            ...
    """

    @functools.wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        start = time.time()
        result = func(*args, **kwargs)
        elapsed = time.time() - start
        logger.debug(f"{func.__name__} took {elapsed:.3f}s")
        return result

    return wrapper


class ProgressLogger:
    """Simple progress logger for profiling/optimization steps.

    Falls back to simple logging if tqdm is not available.
    """

    def __init__(self, total: int, desc: str = "Progress"):
        self.total = total
        self.desc = desc
        self.current = 0

        try:
            from tqdm.auto import tqdm

            self.pbar = tqdm(total=total, desc=desc, leave=False)
            self.has_tqdm = True
        except ImportError:
            self.pbar = None
            self.has_tqdm = False
            logger.info(f"{desc}: 0/{total}")

    def update(self, n: int = 1) -> None:
        """Update progress by n steps."""
        self.current += n
        if self.has_tqdm and self.pbar:
            self.pbar.update(n)
        else:
            if self.current % max(1, self.total // 10) == 0:
                logger.info(f"{self.desc}: {self.current}/{self.total}")

    def close(self) -> None:
        """Close the progress bar."""
        if self.has_tqdm and self.pbar:
            self.pbar.close()
        else:
            logger.info(f"{self.desc}: {self.total}/{self.total} complete")


def check_pytorch_version(min_version: str = "2.1.0") -> bool:
    """Check if PyTorch version meets minimum requirement.

    Args:
        min_version: Minimum required version

    Returns:
        True if version is sufficient
    """
    try:
        from packaging import version

        current = version.parse(torch.__version__.split("+")[0])  # Strip +cu118 suffix
        required = version.parse(min_version)
        return current >= required
    except Exception:
        # If packaging is not available, assume it's fine
        return True


def estimate_training_memory(
    model_params_bytes: int,
    batch_size: int,
    sequence_length: int,
    optimizer: str = "adamw",
) -> int:
    """Rough estimate of total training memory needed.

    This is a heuristic based on common patterns:
    - Model parameters + gradients = 2× params
    - Optimizer states (AdamW) = 2× params (momentum + variance)
    - Activations ≈ batch_size × seq_length × hidden_dim × num_layers × 4 (rough)

    Args:
        model_params_bytes: Model parameter size in bytes
        batch_size: Training batch size
        sequence_length: Sequence length
        optimizer: Optimizer name (adamw, sgd, adam)

    Returns:
        Estimated total memory in bytes
    """
    # Parameters + gradients
    params_and_grads = model_params_bytes * 2

    # Optimizer states
    if optimizer.lower() in ["adamw", "adam"]:
        optimizer_states = model_params_bytes * 2  # Momentum + variance
    else:
        optimizer_states = model_params_bytes  # SGD momentum

    # Activations (very rough estimate — depends heavily on architecture)
    # Assume activations are ~4× params for typical transformer
    activations = model_params_bytes * 4 * (batch_size / 8)  # Normalize to batch=8

    total = params_and_grads + optimizer_states + activations
    return int(total)