"""HuggingFace Trainer integration.

Wraps a Trainer instance so its train() method runs with MemScale optimizations.
"""
from __future__ import annotations

import logging
from typing import Any, Optional

import torch

from memscale.core.config import Config

logger = logging.getLogger(__name__)


def wrap_hf_trainer(trainer: Any, config: Config, sample_input: Optional[torch.Tensor] = None):
    """Wrap a HuggingFace Trainer with MemScale optimizations.

    The wrapping happens by injecting a MemScale executor onto the model
    before training starts.

    Args:
        trainer: HuggingFace Trainer instance
        config: MemScale configuration
        sample_input: Optional sample input for profiling

    Returns:
        The same trainer instance with optimization hooks attached.
    """
    from memscale.api import _wrap_module

    # Wrap the underlying model
    if hasattr(trainer, "model") and trainer.model is not None:
        trainer.model = _wrap_module(trainer.model, config, sample_input)
        logger.info("MemScale attached to HuggingFace Trainer")
    else:
        logger.warning("Trainer has no model attribute — cannot wrap")

    # Hook into trainer's training loop for metrics
    _attach_metrics_callback(trainer, config)

    return trainer


def _attach_metrics_callback(trainer: Any, config: Config) -> None:
    """Attach a callback to log VRAM usage during training."""
    try:
        from transformers import TrainerCallback

        class MemScaleCallback(TrainerCallback):
            def on_step_end(self, args, state, control, **kwargs):
                if torch.cuda.is_available() and state.global_step % 10 == 0:
                    peak = torch.cuda.max_memory_allocated()
                    from memscale.observability.logger import get_logger

                    get_logger().step(
                        step_num=state.global_step,
                        vram_peak_bytes=peak,
                        throughput=0.0,  # TODO: calculate from step time
                    )
                    torch.cuda.reset_peak_memory_stats()

        trainer.add_callback(MemScaleCallback())
    except ImportError:
        logger.debug("transformers not installed — skipping callback registration")