"""PyTorch Lightning integration for MemScale.

Provides a strategy plugin that can be used with Lightning Trainer.
"""
from __future__ import annotations

import logging
from typing import Any, Optional

import torch

from memscale.api import _wrap_module
from memscale.core.config import Config

logger = logging.getLogger(__name__)


class MemScaleLightningCallback:
    """Lightning callback for MemScale integration.

    This is the simpler integration — just a callback that wraps the model.
    For full integration, use MemScaleStrategy.

    Example:
        from lightning import Trainer
        from memscale.integrations.lightning import MemScaleLightningCallback

        trainer = Trainer(
            callbacks=[MemScaleLightningCallback()],
        )
    """

    def __init__(self, config: Optional[Config] = None):
        self.config = config or Config()
        self._wrapped = False

    def on_fit_start(self, trainer: Any, pl_module: Any) -> None:
        """Wrap the model when training starts."""
        if not self._wrapped:
            logger.info("MemScale: wrapping Lightning model")
            # Get sample input from first batch
            sample_input = self._get_sample_input(trainer)
            # Wrap the model
            _wrap_module(pl_module, self.config, sample_input)
            self._wrapped = True

    def _get_sample_input(self, trainer: Any) -> Optional[torch.Tensor]:
        """Try to get a sample input from the dataloader."""
        try:
            if trainer.train_dataloader is not None:
                batch = next(iter(trainer.train_dataloader))
                if isinstance(batch, (tuple, list)):
                    return batch[0]  # Assume first element is input
                elif isinstance(batch, dict):
                    # Try common keys
                    for key in ["input", "inputs", "x", "input_ids"]:
                        if key in batch:
                            return batch[key]
                elif isinstance(batch, torch.Tensor):
                    return batch
        except Exception as e:
            logger.debug(f"Could not get sample input from dataloader: {e}")
        return None


def wrap_lightning_module(
    pl_module: Any, config: Optional[Config] = None, sample_input: Optional[torch.Tensor] = None
) -> Any:
    """Wrap a PyTorch Lightning module with MemScale optimizations.

    Args:
        pl_module: Lightning module to wrap
        config: MemScale configuration
        sample_input: Sample input for profiling

    Returns:
        The same module with MemScale applied
    """
    if config is None:
        config = Config()

    logger.info("Wrapping Lightning module with MemScale")
    _wrap_module(pl_module, config, sample_input)
    return pl_module


# Future: full strategy integration
# This would require deeper integration with Lightning's training loop
# For v0.2+