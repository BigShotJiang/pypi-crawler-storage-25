"""Integrations with popular training frameworks."""

from memscale.integrations.huggingface import wrap_hf_trainer

__all__ = ["wrap_hf_trainer"]