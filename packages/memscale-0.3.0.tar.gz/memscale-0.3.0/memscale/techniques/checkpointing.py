"""Activation checkpointing.

Saves memory by recomputing activations during backward pass instead
of storing them. Trades compute for memory.

Built on torch.utils.checkpoint, which is the well-tested PyTorch primitive.
"""
from __future__ import annotations

import logging
from functools import wraps

import torch
import torch.nn as nn
from torch.utils.checkpoint import checkpoint

logger = logging.getLogger(__name__)


def apply_checkpointing(module: nn.Module) -> None:
    """Wrap a module's forward method with activation checkpointing.

    After this call, the module's forward will use torch.utils.checkpoint,
    which discards activations after forward and recomputes them on backward.

    Args:
        module: PyTorch module to wrap (will be modified in place)
    """
    original_forward = module.forward

    @wraps(original_forward)
    def checkpointed_forward(*args, **kwargs):
        # Only checkpoint during training (not inference)
        if not module.training:
            return original_forward(*args, **kwargs)

        # torch.utils.checkpoint requires inputs to be on autograd-tracked tensors
        # We use use_reentrant=False (newer, more reliable variant)
        def run_forward(*inputs):
            return original_forward(*inputs, **kwargs)

        # Filter args that are tensors (checkpoint needs tensor inputs)
        return checkpoint(run_forward, *args, use_reentrant=False)

    module.forward = checkpointed_forward
    module._memscale_checkpointed = True
    logger.debug(f"Applied checkpointing to {type(module).__name__}")