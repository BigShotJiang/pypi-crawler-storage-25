"""Tests for Invariant GFX."""
