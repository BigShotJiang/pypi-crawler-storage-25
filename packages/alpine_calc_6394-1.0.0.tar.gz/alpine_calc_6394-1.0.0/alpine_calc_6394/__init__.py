"""Opal Cog Pier"""
__version__ = "1.0.0"
