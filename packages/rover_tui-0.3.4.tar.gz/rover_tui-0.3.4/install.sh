#!/usr/bin/env bash
set -euo pipefail

# ──────────────────────────────────────────────
# rover installer
# ──────────────────────────────────────────────

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'
info()  { echo -e "${GREEN}✓${NC} $*"; }
warn()  { echo -e "${YELLOW}!${NC} $*"; }
error() { echo -e "${RED}✗${NC} $*" >&2; }
step()  { echo -e "\n${CYAN}→${NC} $*"; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ── --update mode: reinstall package only, skip all setup ────────────────────
if [[ "${1:-}" == "--update" ]]; then
    VENV_DIR="$HOME/.rover"
    if [[ ! -x "$VENV_DIR/bin/pip" ]]; then
        error "rover venv not found at $VENV_DIR — run install.sh without --update first."
        exit 1
    fi
    step "Updating rover..."
    "$VENV_DIR/bin/pip" install --quiet --upgrade pip
    if [[ "${ROVER_LOCAL:-0}" == "1" ]]; then
        # Local/bundled mode: upgrade from local source tree (used by Dispatch
        # bundled installs where the package is not yet on PyPI or the user
        # wants to pin to the in-repo copy).
        "$VENV_DIR/bin/pip" install --quiet --force-reinstall --no-deps "${SCRIPT_DIR}"
    else
        # Default: pull the latest published release from PyPI.
        "$VENV_DIR/bin/pip" install --quiet --upgrade rover-tui
    fi
    VERSION=$("$VENV_DIR/bin/rover" --version 2>/dev/null || echo "unknown")
    info "rover updated ($VERSION)"
    exit 0
fi

# ── 1. Find python >= 3.11 ────────────────────

step "Checking Python..."

PYTHON_BIN=""
for candidate in python3.13 python3.12 python3.11 python3; do
    if ! command -v "$candidate" &>/dev/null; then
        continue
    fi
    _ver=$("$candidate" -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")' 2>/dev/null) || continue
    _major=$(echo "$_ver" | cut -d. -f1)
    _minor=$(echo "$_ver" | cut -d. -f2)
    if [[ "$_major" -lt 3 ]] || [[ "$_major" -eq 3 && "$_minor" -lt 11 ]]; then
        continue
    fi
    # Sanity-check: verify core stdlib modules load (pyexpat is broken on some
    # Homebrew Python 3.13 builds due to a libexpat symbol mismatch on macOS).
    if ! "$candidate" -c "import xml.parsers.expat, venv, ensurepip" 2>/dev/null; then
        warn "python$_ver found but has broken stdlib (pyexpat/ensurepip). Skipping."
        continue
    fi
    PYTHON_BIN="$candidate"
    PY_VERSION="$_ver"
    break
done

if [[ -z "$PYTHON_BIN" ]]; then
    error "No working Python 3.11+ found. Checked: python3.13, python3.12, python3.11, python3."
    echo ""
    echo "  Your Python 3.13 has a known Homebrew/libexpat issue. Fix with:"
    echo "    brew reinstall python@3.13"
    echo "  Or install a known-good version:"
    echo "    brew install python@3.12"
    exit 1
fi

info "Python $PY_VERSION ($PYTHON_BIN)"

# ── 2. Check / install tmux ───────────────────

step "Checking tmux..."
if ! command -v tmux &>/dev/null; then
    warn "tmux not found. Installing via Homebrew..."
    if ! command -v brew &>/dev/null; then
        error "Homebrew not found. Install Homebrew first: https://brew.sh"
        exit 1
    fi
    brew install tmux
    info "tmux installed."
else
    TMUX_VER=$(tmux -V | awk '{print $2}')
    info "tmux $TMUX_VER"
fi

# ── 3. Write ~/.tmux.conf ─────────────────────

step "Configuring tmux..."
TMUX_CONF="$HOME/.tmux.conf"
if grep -q "Rover detach shortcut" "$TMUX_CONF" 2>/dev/null; then
    info "tmux.conf already configured"
else
    cat >> "$TMUX_CONF" << 'TMUXCONF'

# ── Rover detach shortcut ─────────────────────
# Ctrl+Q — detach from session, return to rover menu (no prefix needed)
bind-key -n C-q detach-client

# Prefix: Ctrl+A (easier than Ctrl+B on mobile keyboards)
set -g prefix C-a
unbind C-b
bind C-a send-prefix

set -g history-limit 100000
set -g base-index 1
set -g escape-time 10

# Scroll-wheel / swipe always hits tmux scrollback, even when the inner TUI
# (Claude Code, vim, …) has mouse reporting enabled. First wheel-up enters
# copy-mode; further wheels scroll within it; wheel-down past the bottom exits.
set -g mouse on
bind -T root WheelUpPane   if-shell -Ft= '#{pane_in_mode}' 'send-keys -M' 'copy-mode -e ; send-keys -M'
bind -T root WheelDownPane if-shell -Ft= '#{pane_in_mode}' 'send-keys -M' ''

# Keyboard fallback: Ctrl+S enters copy-mode from anywhere (q / Enter to exit).
bind-key -n C-s copy-mode
TMUXCONF
    info "tmux.conf updated (Ctrl+Q to detach, swipe to scroll history)"
fi

# ── 4. Install rover into a dedicated venv ───────────────────────────────────
#
# We skip pipx intentionally: Homebrew Python 3.13+ ships without ensurepip
# enabled, which causes pipx's shared-environment setup to fail. A plain venv
# has no shared-environment step and works reliably on all Homebrew Pythons.
#
# Source selection:
#   Default      — installs the latest published release from PyPI (rover-tui).
#   ROVER_LOCAL=1 — installs from the local source tree; used by the Dispatch
#                   bundled installer so it can ship a pre-release build or a
#                   pinned in-repo copy without going through PyPI first.

step "Installing rover..."

VENV_DIR="$HOME/.rover"

# Create (or recreate) the venv, with get-pip fallback if ensurepip is absent.
if ! "$PYTHON_BIN" -m venv "$VENV_DIR" 2>/dev/null; then
    warn "venv with ensurepip failed — trying --without-pip fallback..."
    "$PYTHON_BIN" -m venv --without-pip "$VENV_DIR"
    curl -fsSL https://bootstrap.pypa.io/get-pip.py | "$VENV_DIR/bin/python"
fi

"$VENV_DIR/bin/pip" install --quiet --upgrade pip

if [[ "${ROVER_LOCAL:-0}" == "1" ]]; then
    # Bundled / development install: pull from local source tree.
    "$VENV_DIR/bin/pip" install --quiet "${SCRIPT_DIR}"
else
    # Default: pull the latest published release from PyPI.
    # We intentionally do NOT pin a version here so that re-running install.sh
    # always brings in the latest stable release. Users who want a specific
    # version can run: pip install "rover-tui==x.y.z" inside ~/.rover manually.
    "$VENV_DIR/bin/pip" install --quiet rover-tui
fi

info "rover installed into $VENV_DIR"

# Create launcher shim so 'rover' works from anywhere.
SHIM_DIR="$HOME/.local/bin"
mkdir -p "$SHIM_DIR"
cat > "$SHIM_DIR/rover" << SHIM
#!/usr/bin/env bash
exec "$VENV_DIR/bin/rover" "\$@"
SHIM
chmod +x "$SHIM_DIR/rover"
info "launcher written to $SHIM_DIR/rover"

# Ensure ~/.local/bin is in PATH.
export PATH="$SHIM_DIR:$PATH"
if ! grep -q 'local/bin' "$HOME/.zshrc" 2>/dev/null; then
    echo 'export PATH="$HOME/.local/bin:$PATH"' >> "$HOME/.zshrc"
    info "Added ~/.local/bin to PATH in ~/.zshrc"
fi

# ── 5. .zshrc auto-launch snippet ─────────────

ZSHRC="$HOME/.zshrc"
MARKER="# rover auto-launch"

step "Checking .zshrc auto-launch..."
if grep -q "$MARKER" "$ZSHRC" 2>/dev/null; then
    info "Auto-launch already configured in ~/.zshrc"
else
    read -rp "$(echo -e "${YELLOW}?${NC}  Add auto-launch to ~/.zshrc? (rover starts on SSH login) [Y/n]: ")" ADD_ZSHRC
    if [[ "$(echo "$ADD_ZSHRC" | tr '[:upper:]' '[:lower:]')" != "n" ]]; then
        cat >> "$ZSHRC" << 'SNIPPET'

# rover auto-launch
# Automatically start rover when connecting via SSH.
# cd into the git workspace first so rover launches there and the shell
# stays there when the user exits rover.
if [[ -n "$SSH_CONNECTION" && -z "$ROVER_ACTIVE" ]]; then
    export ROVER_ACTIVE=1
    cd "$HOME/Documents/git" 2>/dev/null || true
    rover
fi
SNIPPET
        info "Auto-launch added to ~/.zshrc"
    else
        warn "Skipped. To enable later, add to ~/.zshrc:"
        echo '    if [[ -n "$SSH_CONNECTION" && -z "$ROVER_ACTIVE" ]]; then'
        echo '        export ROVER_ACTIVE=1'
        echo '        cd "$HOME/Documents/git" 2>/dev/null || true'
        echo '        rover'
        echo '    fi'
    fi
fi

# ── 6. Success message ────────────────────────

echo ""
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${GREEN}  rover installed${NC}"
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""
echo "  Run:  rover"
echo ""
echo "  Inside a session:"
echo "  · Ctrl+Q  → back to rover menu"
echo "  · Ctrl+A D → also detaches (prefix + d)"
echo ""
echo "  Terminus setup:"
echo "  · SSH to your Mac normally"
echo "  · rover launches automatically on connection"
echo "  · Pick a session → Enter → you're in it"
echo "  · Ctrl+Q → back to menu"
echo ""
