#!/usr/bin/env bash
# Tests for install.sh — isolated HOME, mocked python3 and tmux.
#
# Assertions:
#   1. --update with no venv exits non-zero with an error message.
#   2. Fresh install (mocked python3 + tmux present) exits 0.
#   3. ~/.local/bin/rover shim is written and is executable after fresh install.
#   4. .zshrc auto-launch snippet is idempotent (run install twice → grep-c returns 1).
#   5. --update succeeds when rover venv is present.

set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
INSTALL_SH="$SCRIPT_DIR/install.sh"

pass=0
fail=0

ok()   { echo "  PASS: $*"; pass=$((pass+1)); }
fail_test() { echo "  FAIL: $*"; fail=$((fail+1)); }

# ---------------------------------------------------------------------------
# Set up an isolated home directory with fake python3 and tmux.
# ---------------------------------------------------------------------------

FAKE_HOME="$(mktemp -d)"
# Trap cleanup — do not exit on cleanup errors.
cleanup() { rm -rf "$FAKE_HOME" "${FAKE_HOME2:-}" 2>/dev/null || true; }
trap cleanup EXIT

FAKE_BIN="$FAKE_HOME/fake_bin"
mkdir -p "$FAKE_BIN"

# ---------------------------------------------------------------------------
# Stub: python3
# Reports version 3.12. Handles the stdlib import check. Creates a minimal
# fake venv with stub pip, rover, and python binaries.
# ---------------------------------------------------------------------------
cat > "$FAKE_BIN/python3" << 'PYSTUB'
#!/usr/bin/env bash
JOINED="$*"
# Version probe
if echo "$JOINED" | grep -q "sys.version_info.major"; then
    echo "3.12"
    exit 0
fi
# stdlib import check (xml.parsers.expat etc.)
if echo "$JOINED" | grep -q "import xml"; then
    exit 0
fi
# venv creation
if echo "$JOINED" | grep -q "\-m venv"; then
    # Extract last argument = venv directory
    for last; do true; done
    VENV_TARGET="$last"
    mkdir -p "$VENV_TARGET/bin"
    # stub pip
    printf '#!/usr/bin/env bash\nexit 0\n' > "$VENV_TARGET/bin/pip"
    chmod +x "$VENV_TARGET/bin/pip"
    # stub rover
    printf '#!/usr/bin/env bash\necho "rover 0.2.0"\nexit 0\n' > "$VENV_TARGET/bin/rover"
    chmod +x "$VENV_TARGET/bin/rover"
    # stub python (used as fallback in altergo exec)
    cp "$VENV_TARGET/bin/pip" "$VENV_TARGET/bin/python"
    exit 0
fi
# Generic fallback
echo "3.12"
exit 0
PYSTUB
chmod +x "$FAKE_BIN/python3"

# Versioned symlinks that install.sh probes
for name in python3.13 python3.12 python3.11; do
    ln -sf "$FAKE_BIN/python3" "$FAKE_BIN/$name"
done

# ---------------------------------------------------------------------------
# Stub: tmux
# ---------------------------------------------------------------------------
printf '#!/usr/bin/env bash\necho "tmux 3.3a"\nexit 0\n' > "$FAKE_BIN/tmux"
chmod +x "$FAKE_BIN/tmux"

# Minimal .zshrc so install.sh can grep/append
touch "$FAKE_HOME/.zshrc"

# ---------------------------------------------------------------------------
# run_install: run install.sh with isolated HOME, fake PATH, and no tty prompts.
# We echo "n" into stdin to answer the interactive read -rp auto-launch prompt.
# ---------------------------------------------------------------------------
run_install() {
    echo "n" | HOME="$FAKE_HOME" PATH="$FAKE_BIN:$PATH" bash "$INSTALL_SH" "$@" 2>&1
    return ${PIPESTATUS[1]}
}

# ============================================================================
# Test 1: --update with no venv exits non-zero.
# ============================================================================
echo ""
echo "Test 1: --update with no venv exits non-zero..."
HOME="$FAKE_HOME" bash "$INSTALL_SH" --update > /dev/null 2>&1
T1_EXIT=$?
if [[ "$T1_EXIT" -ne 0 ]]; then
    ok "--update with no venv exits non-zero (exit $T1_EXIT)"
else
    fail_test "--update with no venv should exit non-zero, got 0"
fi

# ============================================================================
# Test 2: Fresh install exits 0.
# ============================================================================
echo ""
echo "Test 2: Fresh install exits 0..."
run_install > /dev/null 2>&1
T2_EXIT=$?
if [[ "$T2_EXIT" -eq 0 ]]; then
    ok "Fresh install exits 0"
else
    fail_test "Fresh install should exit 0, got $T2_EXIT"
fi

# ============================================================================
# Test 3: ~/.local/bin/rover shim is written and executable.
# ============================================================================
echo ""
echo "Test 3: Shim written and executable..."
SHIM="$FAKE_HOME/.local/bin/rover"
if [[ -f "$SHIM" && -x "$SHIM" ]]; then
    ok "~/.local/bin/rover shim exists and is executable"
else
    fail_test "~/.local/bin/rover shim missing or not executable"
fi

# ============================================================================
# Test 4: .zshrc auto-launch snippet is idempotent.
#   Run install twice with auto-launch answer "y"; marker appears exactly once.
# ============================================================================
echo ""
echo "Test 4: .zshrc auto-launch snippet is idempotent..."

FAKE_HOME2="$(mktemp -d)"
FAKE_BIN2="$FAKE_HOME2/fake_bin"
mkdir -p "$FAKE_BIN2"
cp "$FAKE_BIN/python3" "$FAKE_BIN2/"
cp "$FAKE_BIN/tmux"    "$FAKE_BIN2/"
for name in python3.13 python3.12 python3.11; do
    ln -sf "$FAKE_BIN2/python3" "$FAKE_BIN2/$name"
done
touch "$FAKE_HOME2/.zshrc"

# Run twice answering "y" to the auto-launch prompt.
echo "y" | HOME="$FAKE_HOME2" PATH="$FAKE_BIN2:$PATH" bash "$INSTALL_SH" > /dev/null 2>&1 || true
echo "y" | HOME="$FAKE_HOME2" PATH="$FAKE_BIN2:$PATH" bash "$INSTALL_SH" > /dev/null 2>&1 || true

MARKER_COUNT=$(grep -c "rover auto-launch" "$FAKE_HOME2/.zshrc" 2>/dev/null || echo "0")
if [[ "$MARKER_COUNT" -eq 1 ]]; then
    ok "Auto-launch snippet is idempotent (marker count = $MARKER_COUNT)"
else
    fail_test "Auto-launch snippet not idempotent (marker count = $MARKER_COUNT)"
fi

# ============================================================================
# Test 5: --update succeeds when rover venv is present (created by Test 2).
# ============================================================================
echo ""
echo "Test 5: --update with existing venv exits 0..."
HOME="$FAKE_HOME" PATH="$FAKE_BIN:$PATH" bash "$INSTALL_SH" --update > /dev/null 2>&1
T5_EXIT=$?
if [[ "$T5_EXIT" -eq 0 ]]; then
    ok "--update with existing venv exits 0"
else
    fail_test "--update with existing venv should exit 0, got $T5_EXIT"
fi

# ============================================================================
# Summary
# ============================================================================
echo ""
echo "Results: $pass passed, $fail failed"
if [[ "$fail" -gt 0 ]]; then
    exit 1
fi
exit 0
