# Rover Upgrade — Information Architecture & Flow Design
_product-service-architect · 2026-04-17_

---

## 1. Menu Information Architecture

**Decision: add one new top-level binding (`Y`) that branches into two sub-choices.**

The current main menu has six bindings consuming four display rows (D / A / S / Q) plus implicit r/R and n/N. There is exactly one natural slot before the menu becomes a list that needs a scroll hint on a phone screen. Spend that slot on `Y`.

Rationale for top-level (not embedded in the altergo-launcher flow): yolo-new and yolo-resume are interruption-aware actions — the user already knows which account they want (the last one, or a pinned one). Embedding a `y/n` yolo prompt after account selection adds a mandatory question to the normal (non-yolo) path. That is a cost paid by 100% of launcher users to serve ~30% of them. Wrong trade.

`Y` at the main menu keeps the normal `A` path pristine. It also signals clearly that yolo is a distinct mode, not a modifier on a regular launch.

The `Y` submenu is a two-item inline prompt rendered inside the same 67-column box — not a full new screen. This keeps rover feeling like a launcher, not a modal app.

---

## 2. Yolo-Resume Flow

**Decision: embed a session picker inside rover using `altergo --recall` output, not a raw hand-off.**

`altergo --recall` opens altergo's own interactive picker. Handing off to it directly would work, but it exits back to the shell on cancel — not back to the rover menu. That breaks rover's ownership of the navigation stack on a phone where re-invoking rover is friction.

Rover should call `altergo --recall --json` (or parse `~/.altergo/sessions/`) to fetch the session list and render it in rover's own `_pick_from_list` picker, then exec `altergo <account> --yolo-resume=<ID>`. This gives:
- Consistent box-drawing UI (user never leaves rover's visual frame).
- Back-navigation on cancel (returns to main menu, not to a raw shell).
- Ability to show account column alongside session ID in the 67-col box.

If `--recall --json` is not yet implemented in altergo, fall back to parsing the `~/.altergo/sessions/` directory directly — same approach the session scanner already uses for provider home dirs.

Cross-account session list columns at 67 characters: `  {letter}  {account:14}  {date:10}  {id-short:8}` — 14+10+8+overhead = 42 visible chars, comfortably fits. Truncate account names at 14.

---

## 3. Keybind Vocabulary (full map after upgrade)

```
Main menu — after upgrade
  Enter / 1-9   attach highlighted/numbered tmux session     [unchanged]
  j / k         cursor down / up                             [unchanged]
  arrows        cursor down / up                             [unchanged]
  n / N         new tmux session prompt                      [unchanged]
  d / D         Dispatch Dashboard                           [unchanged]
  a / A         New altergo session (standard)               [unchanged]
  s / S         Settings                                     [unchanged]
  r / R         Force refresh                                [unchanged]
  q / Q         Quit                                         [unchanged]
  y / Y         [NEW] Yolo submenu (see below)

Yolo submenu (single keypress, rendered inline)
  y / Enter     yolo-new    — pick project+account, launch with --yolo
  r             yolo-resume — resume last session per account
  p             yolo-pick   — session picker, resume by ID
  Esc / q       cancel, return to main menu
```

No existing bindings move. `y/Y` is unoccupied. The yolo submenu uses `y`, `r`, `p` — none conflict with the main menu's `r/R` because the submenu is a distinct render state that only accepts its own keys.

Status bar hint line when in yolo submenu:
`  y new  ·  r resume-last  ·  p pick session  ·  Esc cancel`

This fits in 67 columns: 56 visible chars.

---

## 4. Flow Diagrams

**yolo-new (5 steps)**
```
[Y pressed] → yolo submenu renders inline
    → [y pressed] → project picker  (existing _pick_from_list)
    → account picker                 (existing _pick_from_list)
    → os.execvp: altergo <account> --yolo  (in project dir)
```

**yolo-resume-last (3 steps)**
```
[Y pressed] → yolo submenu renders inline
    → [r pressed] → account picker
    → os.execvp: altergo <account> --yolo-resume  (no ID = last session)
```

**yolo-resume-pick-id (5 steps)**
```
[Y pressed] → yolo submenu renders inline
    → [p pressed] → session picker (rover-embedded, cross-account)
    → [letter selects session] → session object holds (account, id)
    → os.execvp: altergo <account> --yolo-resume=<id>  (in recorded project dir)
```

---

## 5. Feature Tiers

**Core — ship in this wave**
- `Y` → yolo-new (project + account picker + `--yolo` flag)
- `Y → r` → yolo-resume-last (account picker + `--yolo-resume`)

Frequency: daily. Value-on-phone: high. These are two-step flows building directly on existing picker primitives. Implementation risk is low.

**Power-user — ship after core is stable**
- `Y → p` → session picker (cross-account, rover-embedded)

Frequency: weekly. Value-on-phone: medium-high. Requires the session-list data source decision (parse sessions dir or add `--recall --json` to altergo). Do not block core on this.

**Cut**
- A "pin last account for yolo" config shortcut. Attractive, but adds state that breaks on account rename. Not worth the support surface until there is evidence users want it.
- A dedicated yolo tmux window name / color indicator. Product-engineer territory; irrelevant to flow IA.
- Auto-populating the yolo submenu with the last-used account as a default. Premature optimization — adds code path for a flow that is already two keystrokes.

---

## 6. Naming: "yolo" vs. something else

**Decision: keep "yolo" in the UI, but display it as "yolo (skip confirm)" on first reference.**

"Auto-approve" and "headless" are technically accurate but dead on a phone screen. "Yolo" is the term the user already uses, it matches the altergo flag name, and it is short enough to fit in a 67-column status bar. The parenthetical gloss appears only in the submenu header — one time, zero cognitive overhead for returning users. Do not invent a new vocabulary layer.

Display in main menu action row:
```
   Y  Yolo session  (skip confirm)
```
After the user has used it once, "skip confirm" is noise. A future minor iteration can drop the parenthetical based on a config flag (`yolo_gloss_seen: true`). Do not add that flag now.

---

## 7. Backwards Compatibility

No existing binding moves. The only change to muscle memory is the addition of `Y`. Users who type `Y` today get a re-render (the "unknown key" path in menu.py). After this upgrade, `Y` opens the yolo submenu. Users who have never pressed `Y` are unaffected. Users who accidentally pressed `Y` on the current code noticed nothing — they will now see the submenu, which is escapable with `Esc` or `q` in one keypress.

The `n/N` binding for new tmux session is unchanged and unrelated to yolo-new. The altergo `A` path is untouched. No binding is moved, shadowed, or repurposed.

One watch item: if product-engineer proposes adding a `Y` binding inside the Textual dispatch dashboard (app.py BINDINGS), it must be coordinated. Currently `app.py` uses `q`, `m`, `s`, `?`, `r` — `Y` is free there too, but that decision belongs to the dashboard IA pass, not this one.
