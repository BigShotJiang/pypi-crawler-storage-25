# Rover 0.2.0 — QA Strategy

## 1. Layers and Boundaries

**Unit (pure Python, no I/O, no subprocesses)**

Everything that can be exercised by calling a function with controlled inputs and asserting the return value. The code has several pure sub-functions that do real work and carry real bug risk: path decoding, session parsing, telemetry rotation logic, and argv construction. These are cheap to test and catch the classes of bugs most likely to break the yolo flows silently.

**Integration (filesystem I/O, patched os.execvp / subprocess)**

`list_altergo_sessions()` is worth integration-testing because its correctness depends on directory layout assumptions and deduplication logic across multiple account directories. Use a real `tmp_path` tree — no mocking filesystem calls. Patch `os.execvp` at the `altergo_launcher` module level (not globally) to assert correct argv construction without actually exec-ing.

**Manual only**

Raw-mode stdin handling (`_read_key`, the full `run_menu` loop, `_run_yolo_submenu`) requires a real PTY to drive. The `select.select` + `termios` loop cannot be exercised in a headless pytest run without spawning a pty subprocess, which is disproportionate effort for a single-operator local tool. Textual widget rendering (DashboardScreen pixel layout) is also manual-only — Textual's snapshot test helper requires a display. The j/k fix (`table.focus()`) is a one-liner verified by reading the code; manual smoke-test on the device confirms it.

**Left for altergo's own tests**

Anything that verifies altergo binary behavior. Rover's test boundary ends at the argv handed to `os.execvp`.

---

## 2. Test Map

| Surface | Layer | Rationale |
|---|---|---|
| `sessions_index._decode_project_path()` | Unit | Pure string transform; critical to session display correctness |
| `sessions_index._clean()` / `_extract_text()` / `_is_real_user_message()` | Unit | Pure; edge cases (malformed content, tool_result echoes) are hard to hit manually |
| `sessions_index._scan_session_preview()` | Unit | Feed a tmp `.jsonl` file; verifies 40-line cap and preview truncation |
| `sessions_index.list_altergo_sessions()` | Integration | Real tmp dir tree; dedup by session_id, sort order, missing-dir resilience |
| `telemetry._maybe_rotate()` | Unit | Feed a tmp file; verify line-count threshold, wipe-when-tiny path, kept-lines count |
| `telemetry._emit()` | Unit | Verify record written, `ts` field present, never raises on bad input |
| `altergo_launcher._exec_altergo()` — argv construction | Unit | Patch `os.execvp`; parametrize over yolo=F/T, yolo_resume=F/T/"UUID", native vs. account |
| `altergo_launcher.run_yolo_resume_pick()` — empty-sessions path | Unit | Patch `list_altergo_sessions` to return []; verify function returns without calling execvp |
| `menu._confirm_kill()` key routing | Manual | Requires raw-mode TTY |
| `menu.run_menu()` full key loop | Manual | Requires PTY |
| `screens/dashboard.py` j/k focus fix | Manual | Requires Textual display |
| `session_manager.TmuxSession.age_str()` | Unit | Pure arithmetic; boundary values (0s, 59s, 60m, 24h, 48h) |
| `menu._fmt_tokens()` | Unit | Pure; boundary values (0, 999, 1000, 1_000_000) |
| `__main__.py --version` flag | Unit/subprocess | Spawn `python -m dispatch_tui --version`; assert exit 0 and version string |
| `install.sh` (fresh install path) | Bash | See section 5 |
| `install.sh --update` path | Bash | See section 5 |

---

## 3. Fixtures

**`fake_altergo_tree` (session fixture)**

A `pytest` fixture using `tmp_path` that creates:

```
<tmp>/
  .altergo/accounts/
    acct-alpha/
      account.json          {"provider": "claude"}
      .claude/projects/
        -Users-user-proj-a/
          <uuid-1>.jsonl    (one real user message line + one tool_result line)
    acct-beta/
      .claude/projects/
        -Users-user-proj-b/
          <uuid-2>.jsonl    (empty file — should yield empty preview)
  .claude/projects/
    -Users-user-proj-a/
      <uuid-1>.jsonl        (symlink duplicate — dedup test)
```

Fixture patches `pathlib.Path.home` (see section 4) to point at `<tmp>`.

**`tmp_events_file`**

A fixture that creates `<tmp>/.rover/events.jsonl` with controllable initial content for rotation tests. Patches `telemetry._ROVER_DIR` and `telemetry._EVENTS_FILE` directly (module-level constants, monkeypatched via `monkeypatch.setattr`).

**`fake_execvp`**

A fixture that patches `altergo_launcher.os.execvp` with a function that records `(file, argv)` into a list and raises `SystemExit(0)` so the test can assert on it without running altergo.

---

## 4. Isolation Technique

Patch at the narrowest scope — the module that owns the reference, not the stdlib original.

```python
# Correct: patches the name as used in sessions_index
monkeypatch.setattr("dispatch_tui.sessions_index.pathlib.Path.home",
                    lambda: tmp_path)

# Correct: patches os.execvp only within altergo_launcher
monkeypatch.setattr("dispatch_tui.altergo_launcher.os.execvp", fake_execvp)

# Correct: patches os.chdir only within altergo_launcher
monkeypatch.setattr("dispatch_tui.altergo_launcher.os.chdir", lambda p: None)
```

All `monkeypatch` calls are function-scoped (pytest default), so no state leaks between tests.

For `telemetry`, patch the module-level constants directly:

```python
monkeypatch.setattr("dispatch_tui.telemetry._ROVER_DIR", tmp_path / ".rover")
monkeypatch.setattr("dispatch_tui.telemetry._EVENTS_FILE",
                    tmp_path / ".rover" / "events.jsonl")
```

Never patch `time.time` globally — if a test needs a fixed timestamp, pass it as a parameter to a helper or compare field presence (`assert "ts" in record`) rather than the value.

---

## 5. Install / Update Testing

**`tests/test_install.sh`**

Set up a fake environment: `HOME=$(mktemp -d)`, a fake `python3` script on a controlled `PATH` that prints a valid version and exits 0, and a fake `tmux` that does the same. Source `install.sh` with these overrides.

What to check:

- `--update` with no venv exits non-zero with a readable error message.
- Fresh install (mocked python + tmux present) exits 0.
- `~/.local/bin/rover` shim is written and is executable.
- `.zshrc` auto-launch snippet is idempotent (run install twice, `grep -c "rover auto-launch"` returns 1).
- `--update` path calls `rover --version` and exits 0 when rover is present in the fake venv.

What NOT to check here:

- Actual Python package installation (that is pip's job, not ours).
- Homebrew tmux installation (requires real brew — integration environment concern).
- SSH PTY behavior (runtime environment, not installer).
- `.tmux.conf` content correctness (user preference, not a correctness invariant).

---

## 6. Line Budget

Target: 45–55 tests total.

| Module | Tests |
|---|---|
| `test_sessions_index.py` | 14 |
| `test_telemetry.py` | 8 |
| `test_altergo_launcher_argv.py` | 10 |
| `test_session_manager.py` | 6 |
| `test_menu_helpers.py` | 5 |
| `test_main_version.py` | 2 |
| `test_install.sh` | 5 |
| **Total** | **~50** |

---

## 7. What Is Explicitly Not Tested

- Raw-mode stdin (`termios`, `tty.setraw`, `select.select` inside `run_menu`, `_run_yolo_submenu`, `_pick_from_list`) — requires a real PTY. Any test that wraps this in a pty subprocess is more fragile than the code it tests.
- Textual widget rendering, CSS layout, or cursor pixel position — Textual snapshot tests require a display and the j/k fix is a trivial one-liner best verified by code review and manual smoke test.
- altergo binary behavior — rover's boundary is argv to `os.execvp`. What altergo does with `--yolo-resume=<UUID>` is altergo's test responsibility.
- Network calls (`fetch_menu_stats`, `fetch_state`) — mock at the call site in any test that needs them; do not write tests whose purpose is to verify httpx works.
- Rich rendering output — do not snapshot-test box-drawing characters. Rendering is presentation; behavior is what we test.

---

## 8. Directory Layout

```
dispatch-tui/
  tests/
    conftest.py                        shared fixtures (fake_altergo_tree, fake_execvp, tmp_events_file)
    test_sessions_index.py             unit + integration for sessions_index
    test_telemetry.py                  unit for telemetry._emit and _maybe_rotate
    test_altergo_launcher_argv.py      unit for _exec_altergo argv construction
    test_session_manager.py            unit for TmuxSession.age_str + list_sessions parsing
    test_menu_helpers.py               unit for _fmt_tokens and other pure helpers
    test_main_version.py               subprocess smoke test for --version flag
    test_install.sh                    bash-level install / --update path tests
```

Mirror the module tree one-to-one. Do not create `tests/unit/` or `tests/integration/` subdirectories — at 50 tests the layer distinction is captured in the file names, not a directory hierarchy.

**`pyproject.toml` addition for qa-engineer to apply:**

```toml
[project.optional-dependencies]
dev = [
    "pytest>=8.0",
    "pytest-timeout>=2.3",
]
```

No coverage plugin in the initial setup. Coverage as a gate comes after the suite proves it catches real bugs.
