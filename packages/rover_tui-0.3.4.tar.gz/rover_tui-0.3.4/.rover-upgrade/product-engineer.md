# rover upgrade — product-engineer brief

## 1. Context summary

- rover is a Rich TUI (box-drawing, raw-mode stdin) SSH-first remote multitool installed at `~/.rover`, entry via `dispatch_tui/__main__.py` → `menu.py`.
- Primary UI is a Rich menu (`menu.py`); Textual is used only for the Dispatch dashboard, detail, and settings deep-panels.
- It manages tmux sessions (list/attach/new/kill via `session_manager.py`), launches altergo accounts via a paginated project→account picker (`altergo_launcher.py`), and shows dispatch agent stats from the local HTTP API (`api.py`).
- Designed for Terminus on Android over SSH — every interaction must be a single keypress, renders must be lean, no animations.
- altergo v0.38–v0.39 added `--yolo` (skip-perms), `--yolo-resume [<UUID>]` (skip-perms + resume specific session), and `--recall` (cross-account session picker); rover does not yet surface any of these.

---

## 2. Scope

### In scope
- `--yolo` launch (new session, all permissions skipped)
- `--yolo-resume <ID>` (pick from rover-rendered session list, exec with ID)
- Kill a tmux session from the menu
- One-keystroke "quick attach" to newest running/attached session
- Connection health indicator already exists (dispatch offline label); needs a tmux-server liveness hint too

### Out of scope (rejected)

| Feature | Reason |
|---|---|
| Clipboard copy (OSC 52) | Terminus support is inconsistent; zero-value if it silently fails over SSH |
| Tmux pane splits from rover | Already doable in tmux; adding a split UI is a desktop-feel feature that earns nothing over SSH |
| SSH host switching | rover runs on the host, not the client; host switching belongs to the SSH client (Terminus bookmarks) |
| Waking a stalled session | "Wake" semantics are provider-specific with no API surface; out of scope until dispatch exposes it |
| Provider quick-switch from menu | Account switch is already the A-flow; a second shortcut duplicates it with no reduction in keystrokes |
| Tailing dispatch events for a specific agent | Dispatch dashboard (D) already does this; a raw-log tail adds complexity for zero gain over the existing Textual view |
| Textual animations or themes | SSH latency kills animated elements; keep Textual panels static |

---

## 3. Ordered feature list

### F1 — Yolo session launch (MUST)

**Summary:** pressing `Y` in the main menu launches altergo with `--yolo` (no permission prompts).

**Pays rent:** the most common flow on a phone over SSH is "spin up an agent and don't babysit it." One keystroke vs. the current A-flow (3 pickers + no yolo).

**UX:**
- Key: `y` / `Y` in `menu.py` (next to `a`).
- Flow: same project→account pickers as A-flow (`run_altergo_launcher`), but appends `--yolo` to the argv before `os.execvp`.
- Menu footer hint: `Y yolo`.
- Implementation: add `yolo: bool = False` param to `run_altergo_launcher`; when True append `--yolo` after the account positional.

**Acceptance criteria:**
- `Y` triggers project→account pickers identically to `A`.
- altergo is exec'd with `--yolo` appended.
- If altergo binary not found, same error path as `A`.
- Menu label visible in footer.

---

### F2 — Yolo-resume with in-rover session picker (MUST)

**Summary:** pressing `R` (or a new key) in the altergo launcher shows altergo's cross-account sessions inside rover's box-drawing picker, then resumes the chosen session with `--yolo-resume <ID>`.

**Pays rent:** lets you jump back into an abandoned agent session from your phone in 2 keypresses without knowing the UUID.

**UX:**
- Key: `v` / `V` from the main menu ("resume with yolo").
- rover scans `~/.altergo/accounts/*/` for `.jsonl` session files (same scan logic altergo uses internally — read `stem` for ID, scan first 40 lines for topic via `_scan_session_head` equivalent).
- Renders sessions in `_pick_from_list` format: `<letter>  <topic_preview>  [<provider>]  <age>`.
- On selection: exec `altergo --yolo-resume <UUID>`.
- Fallback: if no sessions found, show "no sessions — press A to start one."

**Acceptance criteria:**
- `V` opens a paginated session list built from local `.jsonl` files.
- Selecting a session execs `altergo --yolo-resume <UUID>`.
- Age and provider columns render correctly.
- Cancel returns to main menu.

---

### F3 — Kill tmux session from menu (MUST)

**Summary:** when cursor is on a session, `X` kills it with a one-line confirmation prompt.

**Pays rent:** runaway or stale sessions can only be cleaned up by attaching and exiting, or by leaving rover entirely. On a phone this is expensive.

**UX:**
- Key: `x` / `X` in `menu.py`, only active when `sessions` is non-empty and cursor is valid.
- Render a single confirmation line below the box: `Kill <name>? [y/N]`.
- `y` calls `session_manager.kill_session(name)` then refreshes; any other key cancels.
- Existing `kill_session()` in `session_manager.py` is already implemented — just needs wiring.

**Acceptance criteria:**
- `X` on a session shows confirmation prompt.
- `y` kills it and refreshes session list.
- Non-y key cancels and re-renders without killing.
- Confirmation uses same raw-mode read loop as the rest of the menu.

---

### F4 — Quick attach to newest session (SHOULD)

**Summary:** pressing `Enter` with no cursor movement attaches the top (most recent/attached) session instantly.

**Pays rent:** the existing Enter already does this when cursor is on row 0, but only after a timeout. This makes it the default on first render with zero navigation.

**UX:**
- Current behavior: Enter attaches cursor session. Cursor starts at 0.
- Required change: none to the attach logic; the issue is the 5-second auto-refresh resets the cursor position to `max(0, min(cursor, len(sessions)-1))` only — cursor 0 is already the most recent session due to sort order.
- Actually: this already works. **No code change needed.** Document it in the footer hint more clearly: `Enter attach newest`.

**Acceptance criteria:**
- Footer hint updated to `Enter attach  (↑↓/jk move)`.

---

### F5 — j/k bug fix (MUST — see section 4 for root cause)

**Summary:** j/k navigation works in `menu.py` but is broken in the Textual `DashboardScreen` because `action_cursor_down/up` delegate to `DataTable.action_cursor_down/up` but the `DataTable` widget needs focus.

**UX:** no UX change — j/k should move the DataTable cursor in the Dispatch dashboard.

**Acceptance criteria:** pressing `j`/`k` in the Dispatch dashboard moves the selected row.

---

### F6 — `N` new-session now opens an altergo session in a new tmux window (SHOULD)

**Summary:** pressing `N` currently only creates a blank tmux session. Extend with a sub-prompt: `[t]mux only  [a]lterego`. `a` runs the altergo launcher and wraps it in `tmux new-session`.

**Pays rent:** the most common "new" action on a phone is "new agent in isolation" — two steps today (N then A) becomes one path.

**UX:**
- After `N`, render a 2-option inline prompt using the existing confirmation-line pattern.
- `t` → existing new-session flow.
- `a` → altergo launcher (same as A) but pre-wrapped: the exec becomes `tmux new-session -d -s <name> altergo ...` so it runs detached, then attaches.

**Acceptance criteria:**
- `N` shows inline `[t]mux / [a]lterego` prompt.
- `t` behaves identically to current `N`.
- `a` launches a new tmux session with altergo inside and attaches to it.

---

## 4. j/k bug — root cause

The user-reported j/k failure is in the **Textual Dispatch dashboard**, not `menu.py`.

`menu.py` lines 388–399: j/k are handled correctly in the Rich raw-mode loop — they mutate `cursor` and call `_render_menu`. No bug here.

`screens/dashboard.py` lines 82–94: `DashboardScreen.BINDINGS` defines `j` → `action_cursor_down` and `k` → `action_cursor_up`. Lines 182–186: these actions call `self.query_one("#sessions-table", DataTable).action_cursor_down/up()`.

**Root cause:** Textual routes key bindings to the focused widget first. When the `DataTable` has focus, it already consumes `j`/`k` natively — so the `DashboardScreen` bindings fire only when the `DataTable` does NOT have focus (e.g., the `Static` status bar is focused on mount). The fix is to call `table.focus()` in `DashboardScreen.on_mount()` after `self.refresh_data()` so the DataTable owns focus on entry.

**Exact location:** `dispatch_tui/screens/dashboard.py`, `on_mount()` method, line 117. Add `table.focus()` after `self.refresh_data()`.

---

## 5. Instrumentation notes

rover has no analytics today. The lightest-weight approach: append one JSON line to `~/.rover/events.jsonl` per key action. No network calls, no SDK, just `json.dumps({...}) + "\n"` appended atomically. Staff engineers can grep this locally or ship it via dispatch's existing telemetry route later.

| Feature | Event to emit |
|---|---|
| F1 yolo launch | `{"event": "launch", "mode": "yolo", "provider": "<provider>"}` |
| F2 yolo-resume | `{"event": "launch", "mode": "yolo_resume", "provider": "<provider>"}` |
| F3 kill session | `{"event": "kill_session", "confirmed": true/false}` |
| F5 j/k fix | no event — it's a bug fix, not a feature |

Write these in a single `_emit(event: dict)` helper in a new `dispatch_tui/telemetry.py` module. Wrap every write in `try/except` — telemetry must never crash rover. Keep file under 100 KB; rotate by dropping oldest 200 lines when it exceeds the limit.
