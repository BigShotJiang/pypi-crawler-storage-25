# Rover upgrade — Phase 2 implementation manifest

Two staff engineers work in parallel. Strict file ownership to prevent peer overwrite.

## Decisions (from product-engineer + product-service-architect)

- **Y** top-level binding on the main menu opens a **yolo submenu** (inline inside the same 67-col Rich box — not a new screen).
- Yolo submenu keys:
  - `y` / Enter → yolo-new: project + account pickers, exec `altergo <account> --yolo` in project dir.
  - `r` → yolo-resume-last: account picker, exec `altergo <account> --yolo-resume`.
  - `p` → yolo-pick: cross-account session picker, exec `altergo <account> --yolo-resume=<UUID>` in that session's project dir.
  - `Esc` / `q` → cancel back to main menu.
- **X** on main menu kills the cursor tmux session with inline `Kill <name>? [y/N]` confirmation. `session_manager.kill_session` already exists; just wire it.
- **j/k fix** in Textual dashboard: `DashboardScreen.on_mount()` must call `table.focus()` after `self.refresh_data()` so the DataTable owns focus. See `screens/dashboard.py` line 117.
- **Session picker data source**: parse `~/.altergo/accounts/<account>/.claude/projects/**/`, `.../.gemini/...`, `.../.codex/sessions/`, `.../.copilot/...` — whatever altergo's native discovery does. Confirm by grepping `altergo.py` for `_find_sessions` / `recall`. If altergo exposes `--recall --json`, prefer that. Fallback: direct filesystem scan. Truncate account at 14, date at 10, short-id at 8 — fits 67-col box.
- Footer hint after upgrade:
  `  ↑↓/jk navigate · Enter/num attach · Y yolo · A altergo · D agents · X kill · S sets · Q quit`
- Naming: stays "yolo" in UI. Optional gloss `(skip confirm)` in submenu header only.
- No binding moves. No existing flow changes.
- Instrumentation: `~/.rover/events.jsonl` append-only, wrapped in try/except, rotate when >100 KB. One event per launch/kill.

## Lane A — owned by staff engineer #1 (`senior-feature`)

**Write access to these files ONLY:**
- `dispatch_tui/menu.py`
- `dispatch_tui/altergo_launcher.py`
- `dispatch_tui/session_manager.py`
- `dispatch_tui/sessions_index.py` (NEW — session scanner for yolo-pick)
- `dispatch_tui/telemetry.py` (NEW — minimal append-only events)

**Read access to everything.**

Responsibilities:
1. Add `Y` key in `menu.py` → yolo submenu. Implement submenu as a sibling function `_run_yolo_submenu(console, fd, ...)` in `menu.py` that renders inline below or replacing the action-item rows, reads keys in raw mode, and either dispatches or returns to caller.
2. Extend `run_altergo_launcher(config, save_config_fn, *, yolo: bool = False, yolo_resume: bool | str = False)` in `altergo_launcher.py`:
   - `yolo=True` → append `--yolo` to argv.
   - `yolo_resume=True` → append `--yolo-resume` (no ID = last).
   - `yolo_resume="<UUID>"` → append `--yolo-resume=<UUID>`.
   - When `yolo_resume` is a UUID, **skip the project picker** — use the project dir recorded in the session (the picker passes project path alongside the ID).
3. Implement cross-account session scanner in `sessions_index.py`:
   - `list_altergo_sessions() -> list[SessionRecord]` where SessionRecord = (account, provider, project_path, session_id, modified_at, first_user_prompt_preview).
   - First, try `altergo --recall --json` (check if supported, fallback gracefully).
   - Fallback: scan `~/.altergo/accounts/<acct>/.claude/projects/**/*.jsonl`, etc. — mirror altergo's logic. Grep `altergo.py` for `recall` / `sessions` to find the canonical path logic.
   - Sort most-recent-first.
4. Wire the session picker using existing `_pick_from_list` primitive. Columns: `{letter} {account:14} {date:10} {preview:30}`.
5. Add `X` kill in `menu.py` with inline confirmation.
6. Add `telemetry.py` — `_emit(event: dict)` helper, atomic append, 100 KB rotation, try/except around everything.
7. Update footer hint text.

Constraint: touch only the files listed. If you need to change dashboard or settings screens, STOP and escalate — that's Lane B.

## Lane B — owned by staff engineer #2 (`senior-infra`)

**Write access to these files ONLY:**
- `dispatch_tui/screens/dashboard.py`
- `dispatch_tui/screens/detail.py`
- `dispatch_tui/screens/settings.py`
- `dispatch_tui/app.py`
- `dispatch_tui/__main__.py`
- `dispatch_tui/config.py`
- `pyproject.toml`
- `install.sh`

**Read access to everything.**

Responsibilities:
1. **Fix j/k bug** in `screens/dashboard.py`: the `DataTable` doesn't get focus on mount, so screen-level `j`/`k` bindings don't fire. Add `table.focus()` after `self.refresh_data()` in `on_mount()`. Verify the same issue doesn't exist in `detail.py` and `settings.py` — fix there too if it does.
2. Verify `install.sh --update` path still works end-to-end after the upgrade (dependency changes, entry-point stability). If `sessions_index` or `telemetry` need extra deps (they shouldn't — pure stdlib + existing httpx), update `pyproject.toml`.
3. Bump version in `pyproject.toml` and `dispatch_tui/__init__.py` from `0.1.0` to `0.2.0`.
4. Ensure `dispatch_tui/__main__.py` still flows correctly after the main-menu changes (check the MenuAction enum contract — Lane A must not add new enum values without telling you; if it does, you plumb them).
5. Add a `--version` flag in `__main__.py` that prints the package version (install.sh's update path already calls `rover --version`). Check if already present; implement if missing.
6. Light touch in `config.py` if needed for the session-picker cache invalidation — but only if Lane A requests it.

Constraint: do NOT touch `menu.py`, `altergo_launcher.py`, `session_manager.py`, or new Lane A files. If you need a coordination point with Lane A, drop a one-line note in this manifest under "## Coordination" — do NOT edit their files.

## Hard rules for BOTH lanes

- Use Read / Edit / Write / Grep / Glob. Never shell out with cat/head/sed.
- Read full files once (token-limit error is the only reason to offset/limit).
- No feature flags. This is a single-operator local tool — ship default-on.
- No new top-level dependencies unless absolutely required.
- No placeholder `TODO` code. Ship working features only.
- When your lane is done, STOP. Do not explore further. Do not run tests (QA is Phase 3). Do not touch git.
- Report a 1-paragraph summary of what changed, file list, and any blockers found.

## Coordination
- Lane B (senior-infra): `sessions_index.py` and `telemetry.py` did not exist when Lane B ran. Both files are pure stdlib (json, pathlib, uuid) — no new deps needed in `pyproject.toml`. Once Lane A writes them, `pip install --upgrade "${SCRIPT_DIR}"` in install.sh will pick them up automatically since hatchling discovers all packages under `dispatch_tui/`. No pyproject.toml changes needed for Lane A's new modules.
