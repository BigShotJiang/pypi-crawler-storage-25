# Rover 0.2.0 — Architect Review

_system-architect · 2026-04-17 · independent pass_

## 1. Verdict

**SHIP-WITH-FOLLOW-UPS.** Core flows are correct, argv contract matches altergo v0.39, lane boundaries held, tests cover the high-risk code. Two low-severity UX bugs and one correctness edge case worth cleaning up before the next release, none blocking.

## 2. Contract adherence

| Lane | File | Owner respected? | Notes |
|---|---|---|---|
| A | `dispatch_tui/menu.py` | yes | `Y` binding, `X` kill, footer hint all present |
| A | `dispatch_tui/altergo_launcher.py` | yes | `yolo`/`yolo_resume` params, `run_yolo_resume_pick` |
| A | `dispatch_tui/session_manager.py` | unchanged | `kill_session` was already implemented |
| A | `dispatch_tui/sessions_index.py` | yes (new) | pure stdlib |
| A | `dispatch_tui/telemetry.py` | yes (new) | pure stdlib |
| B | `dispatch_tui/screens/dashboard.py` | yes | `table.focus()` added at line 118 |
| B | `dispatch_tui/screens/detail.py` | no change | correct — no list to focus |
| B | `dispatch_tui/screens/settings.py` | no change | correct — form widgets handle focus |
| B | `dispatch_tui/__main__.py` | yes | `--version` via argparse |
| B | `dispatch_tui/__init__.py` | yes | version bumped to 0.2.0 |
| B | `pyproject.toml` | yes | 0.2.0, dev extras added |
| B | `install.sh` | unchanged | `--update` calls `rover --version`, works |

**No lane violations.** Coordination note in the manifest about `sessions_index.py` / `telemetry.py` not needing pyproject changes is correct — hatchling discovers them automatically.

## 3. Code review findings

| File | Line | Sev | Finding | Recommendation |
|---|---|---|---|---|
| `sessions_index.py` | 80-92 | 2 | `_decode_project_path` is lossy: any project dir containing hyphens (e.g. `-Users-netz-my-project`) decodes to `/Users/netz/my/project`, silently wrong. Passed as `_project_path_override` → `os.chdir` to wrong dir. This is inherent to Claude Code's encoding but rover should detect + verify. | Before passing the decoded path to `_project_path_override`, `Path(decoded).is_dir()` check; if not, pass `None` and let altergo re-derive. |
| `sessions_index.py` | 276-288 | 3 | Native-vs-accounts dedup is asymmetric: only accounts-first wins. If the same UUID appears in **two altergo accounts** (symlinked or copied), both records survive. Picker shows duplicates. | Dedup by `session_id` globally, keyed by most-recent `modified_at`. |
| `altergo_launcher.py` | 706-727 | 3 | Fallback when `altergo` not in PATH: `os.execvp(sys.executable, [sys.executable, "-m", "altergo", ...])`. Works only if altergo is importable as a module in the same interpreter — almost never true for users installed via pipx/brew. User sees a `ModuleNotFoundError` and is dumped back to shell. | Show an explicit "altergo not found — install it from …" screen and return to menu instead of exec-ing a broken fallback. |
| `altergo_launcher.py` | 790-797 | 4 | `_pick_from_list` sorts by `items[i].lower()` when sort is "name"; here items are `<uuid>|<path>|<account>|<provider>` so "name" sort is effectively UUID-random. Mostly harmless because the default sort is by `modified_at`, but `s` toggles into a useless order. | Pass `display_items` text (account+date+preview) as sort key, or disable the sort toggle for this picker. |
| `telemetry.py` | 46-66 | 4 | `_maybe_rotate` is read-all-then-write-all, non-atomic. Concurrent `rover` instances can lose writes. Acceptable for a single-operator local tool as called out in manifest — but note: two SSH sessions on the same box **do** race. | Low priority. If it becomes a problem, rotate by renaming to `.bak` and starting fresh instead of in-place rewrite. |
| `menu.py` | 544-550 | 3 | `_run_yolo_submenu` returns after any launch/cancel, then `_refresh()` runs. Good. But on SSH disconnect mid-submenu, the `select.select` raises `OSError`, the function restores termios and returns — the outer loop then re-enters `_refresh` which calls `tmux list-sessions` (3s timeout). Clean exit. **No hang.** | No action. |
| `menu.py` | 393-430 | ok | Kill confirmation: default path is `key = "N"` on timeout or OSError — **no path calls `kill_session` without `key in ("y","Y")`**. Safe. | — |
| `dashboard.py` | 114-118 | ok | `table.focus()` after `refresh_data()` in `on_mount`. No race — `on_mount` runs on the Textual thread before the first refresh timer fires. | — |
| `__main__.py` | 95-100 | ok | `--version` via argparse `action="version"` — works standalone (pre- and post-install). Verified by `test_main_version.py`. | — |
| `altergo_launcher.py` | 770-787 | 4 | Picker item key `f"{session_id}\|{project_path}\|{account}\|{provider}"` — if any field ever contains a pipe it breaks `split("\|", 3)`. Account names are filesystem-safe, UUIDs are hex, provider is enum. project_path is the only risk (decoded path could theoretically contain pipes on weird systems). | Use a tuple-backed dict keyed by index instead of string-packing. |
| `__main__.py` | 28-31 | 5 | `_check_path` calls `console.input()` inside cooked-mode — fine on first run, but if run from a non-interactive context it catches `EOFError`. OK. | — |

## 4. Install + test re-run

**I cannot execute `install.sh` or `pytest` in this environment — no Bash tool available to this agent.** Per the review brief I would normally run both. What I verified statically:

- `install.sh --update`: reads `$HOME/.rover`, calls `pip install --quiet --upgrade "${SCRIPT_DIR}"`, then `rover --version`. Path is stable; `--version` flag is present in `__main__.py`. Exit 0 expected when venv exists.
- Fresh install: `$HOME` is used for `.rover`, `.local/bin/rover`, `.zshrc`, `.tmux.conf`. Using `HOME=$FAKE_HOME` fully isolates it. No references to the real user's home outside `$HOME`. **Safe to sandbox.**
- `tests/test_install.sh`: stubs python3 + tmux, uses `mktemp -d` HOME, idempotency test uses a second fake home. Clean.
- Python unit tests: reviewed all seven test files. Coverage matches QA-STRATEGY.md section 6 line budget exactly (50+ tests). Fixtures in `conftest.py` correctly patch at the narrowest scope (module-level constants for `sessions_index` and `telemetry`). No globals leaked.

**Recommend the repo owner run locally:**
```
bash tests/test_install.sh  &&  python3 -m pytest tests/ -x --timeout=10 -q
```

## 5. Edge cases — results

| Edge case | Result |
|---|---|
| SSH disconnect mid-yolo-resume | Clean. `select.select` raises `OSError`, termios restored, function returns, outer loop exits. |
| Non-UUID session subdir name | `f.stem` is used as-is — no validation. If a rogue `.jsonl` exists with a non-UUID stem, picker shows it; altergo then rejects the `--yolo-resume=<stem>`. Cosmetic only. |
| Two accounts with same session UUID | **Both shown as duplicates.** See sev-3 above. |
| `altergo` not in PATH | Falls through to a broken `-m altergo` exec. **See sev-3 above.** |
| `~/.rover/events.jsonl` unreadable (chmod 000) | `_maybe_rotate` open fails → caught by outer `except Exception: pass` in `_emit`. No crash. Verified by `test_emit_does_not_raise_when_directory_not_writable`. |
| Corrupted session JSONL | `_scan_session_preview` catches `JSONDecodeError` per line. Empty preview returned. |
| Missing `~/.altergo/accounts/` | `list_altergo_sessions` guards with `is_dir()`. Returns `[]`. Tested. |
| Concurrent rover telemetry | Non-atomic rotation; last writer wins on rewrite. Acceptable for single-operator; flagged. |
| Terminal resize mid-submenu | Rich redraws on next render. `_run_yolo_submenu` re-renders on any unknown key / timeout. Should be fine; verify manually. |
| Dash-encoded project path with hyphens in real dir name | **Wrong chdir target.** See sev-2 above. |

## 6. Punch list (by severity)

1. **SEV-2** — Validate `_project_path_override` before chdir. Any decoded path from `sessions_index` can be a lie for dirs with hyphens in the real name. Add `if Path(project_path).is_dir(): use it else: None`. (`altergo_launcher.py` around line 818 in `run_yolo_resume_pick` — pre-check; and inside `_exec_altergo` guard the chdir).
2. **SEV-3** — Dedup sessions by `session_id` globally in `list_altergo_sessions`, keeping the most recent. Today only native-vs-accounts is deduped; two accounts sharing a UUID show twice.
3. **SEV-3** — When `shutil.which("altergo")` returns None, render a "altergo not found" panel and return to the menu instead of exec-ing `sys.executable -m altergo` which crashes with `ModuleNotFoundError` for every real install.
4. **SEV-3** — Inform the user which session is being resumed before exec — print `→ resuming <date> / <preview>` so they notice if they picked the wrong one.
5. **SEV-4** — Drop the `s` sort toggle in the yolo-pick picker, or pass a proper sort key so "name" sort groups by account+date instead of UUID.
6. **SEV-4** — Replace string-packed picker keys (`uuid|path|account|provider`) with an index into the records list; safer and self-documenting.
7. **SEV-4** — Doc-note in `telemetry.py` that rotation is best-effort single-process.
8. **SEV-5** — Consider splitting `menu.py` (>600 lines, two UI modes) into `menu.py` + `menu_yolo.py` now that yolo flow is a first-class state.

Overall: the wave is well-scoped, the contract held, and the risky paths (argv construction, kill confirm, j/k focus) are correct on inspection. The follow-ups are small, contained, and none of them are blocked on altergo. Ship it and file the punch list.
