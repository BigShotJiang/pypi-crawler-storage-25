# EvaSuite
#
# ---------------------------------------------------------------
# Copyright (C) 2004-2025, Hereon
# Contact information: beate.geyer@hereon.de, imktro-climate-modelling@lists.kit.edu
# See AUTHORS.TXT for a list of authors
# See LICENSES/ for license information
# SPDX-License-Identifier: Apache-2.0
# ---------------------------------------------------------------

from setuptools import setup
import os

setup(
    name='hereon_evasuite',
    version='v1.0.0',
    author='Evgenii Churiulin',
    author_email='evgenii.churiulin@kit.edu',
    url='',
    license='LICENSE',
    description='An automatic evaluation between different datasets',
    long_description=open('README.md').read(),
    install_requires=[
        "numba>=0.51.0",
        "numpy>=1.19.2",
        "scipy>=1.5.3",
        "xarray>=0.16.1",
        "netCDF4",
        "h5py",
        "pandas>=1.1.4",
        "geopandas",
        "shapely",
        "regionmask",
        "dask>=2.30.0",
        "distributed>=2.30.0",
        "xskillscore>=0.0.23",
        "matplotlib>=3.1",
        "statsmodels",
        "pytest",
        "pyproj",
        "cartopy",
        "cdo",
    ],
    python_requires=">=3.10",
    packages=['hereon_evasuite'],
    package_data={
        'hereon_evasuite': [os.path.join('system', 'evasuite.sysconf.yaml')]
    },
    include_package_data = True,
    entry_points={
        'console_scripts': ['evasuite = hereon_evasuite.EvaSuite:main'],
    },
    zip_safe=False
)
