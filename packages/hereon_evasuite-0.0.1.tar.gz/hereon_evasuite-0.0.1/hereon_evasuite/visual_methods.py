# EvaSuite
#
# ---------------------------------------------------------------
# Copyright (C) 2004-2025, Hereon
# Contact information: beate.geyer@hereon.de, imktro-climate-modelling@lists.kit.edu
# See AUTHORS.TXT for a list of authors
# See LICENSES/ for license information
# SPDX-License-Identifier: Apache-2.0
# ---------------------------------------------------------------

# ---------------------------------------------------------------
# Program description:
# This program provides a flexible and user-friendly framework for the visualization
# of both 1D and 2D scientific data. It supports a variety of plot types, including:
#
# - 1D Line, Scatter, and Bar plots (single or collage view)
# - 2D Maps (single map, time-based collage maps, and general collage maps)
# - Difference plots for comparing datasets (e.g., in 2D maps)
#
# The visualization configuration is fully customizable via YAML files, allowing
# users to modify colors, labels, subplots, grid settings, and more without altering
# the code.

# Key Features:
# -------------
# - Automatic handling of defaults with the option for user overrides via YAML
# - Smart rounding of colorbars, axis limits, and tick labels
# - Support for different map projections (e.g., PlateCarree, LambertConformal)
# - Chunking for large datasets and collage-type layouts
# - Integrated validation and control of data types and user settings
# - Modular design, with classes separated for data preprocessing, 1D plots, and 2D plots
#
# Usage Example:
# --------------
# 1. Configure your plots/maps via the provided GUI tools → generate YAML settings.
# 2. Call the plotting scripts with the YAML configuration files:
#
#    History:
#    Version    Date       Name
#    ---------- ---------- ----
#    1.1        04.2025   Evgenii Churiulin, IMKTRO
#                         Initial realise
# ---------------------------------------------------------------
# -- Import python packages:
import math
import os
import csv
import inspect
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize, TwoSlopeNorm

# -- Import special methods for ticks:
from datetime import datetime
from typing import List, Dict, Union, Optional, Tuple
# -- Import user methods:
from hereon_evasuite.visual_support import Control_data_types
from hereon_evasuite.visual_config import Builder_plots_config, Builder_maps_config, Config_class
from hereon_evasuite.visual_plt_settings import Plot_settings, TaylorDiagram
from hereon_evasuite.visual_map_settings import Map_settings
from hereon_evasuite.log_EvaSuite import get_logger, log_function_name
logger = get_logger()


class Fig_preprocessor:
    """
    Data preprocessing class for 1D and 2D visualizations.

    Handles input data formatting, time parsing, and type control
    for various supported plot types, including line plots, bar charts,
    scatter plots, and different 2D map visualizations.

    Parameters
    ----------
    data4visualization : Dict[str, np.ndarray]
        Dictionary containing the input data arrays for plotting.
        Expected keys: 'var4vis', 'time', 'ds_name', and optionally 'var_lon', 'var_lat'.
    settings4visualization : Dict[str, Union[str, float, int]]
        Dictionary with visualization settings, including plot type and output options.
    collage_type : str, optional
        Specify collage type if required for specific multi-region plots.

    Raises
    ------
    TypeError
        If the provided plot type is not supported or data types are incorrect.

    Attributes
    ----------
    data : np.ndarray or list
        Main data for visualization.
    time : list[str]
        Formatted time steps.
    ds_names : list[str]
        Dataset names used in the plot.
    plot_type : str
        Selected plot type (e.g., 'line', 'scatter', 'bar', 'collage', 'time_collage').
    """
    @log_function_name
    def __init__(
        self,
        evaluation_mode: str,
        data4visualization: Union[Dict[str, np.ndarray], List[Dict[str, np.ndarray]]],
        settings4visualization: Union[Dict, List],
        collage_type: Optional[str] = None,
    ) -> None:
        """
        Initialize the figure preprocessor for both 1D and 2D plots.

        Depending on the selected plot type, this class prepares the input data
        and verifies its structure and types.

        Parameters:
        -----------
        data4visualization : dict
            Dictionary containing input data arrays and metadata for visualization.
            Required keys depend on plot type and include:
            'var4vis', 'time', 'ds_name', (optionally 'var_lon', 'var_lat' for 2D plots).

        settings4visualization : dict
            Dictionary with configuration parameters for visualization
            (e.g., 'plt_title', 'plt_label', 'type4plot', 'plt_domain_type', 'plotabsmin', 'plotabsmax').

        collage_type : str or None, optional
            Used to override the plot type to 'collage_1d_plot' (for special handling of subregions).
            If None, 'type4plot' from settings4visualization is used.

        Raises:
        -------
        TypeError:
            If an unsupported plot type is provided or if input data types are incorrect.

        Notes:
        ------
        Supported plot types:
            - 1D: 'line', 'scatter', 'bar', 'collage_1d_plot'
            - 2D: 'time_collage', 'collage', 'single_map'
        """
        # -- Local variables:
        func_name = inspect.currentframe().f_code.co_name  # Function name

        self.eval_mode = evaluation_mode
        # Maximal numbers of subplot in of figure:
        self.subplot_chunk_size = 12
        old_time_format = "%Y-%m-%d %H:%M:%S"
        new_time_format = "%Y-%m-%d %H:%M:%S"
        # If you want to add new types, with absolutely different logic
        # then, you have initialize a new case. Otherwise error case is active
        self.types_1d_plots = ['line', 'scatter', 'bar']
        self.types_2d_plots = ['time_collage', 'collage', 'single_map']

        # -- Initialization of control methods:
        ctr = Control_data_types()

        # -- Type of plot (has to be in lower register):
        if collage_type is not None:
            self.plot_type = 'collage_1d_plot'
        else:
            self.plot_type = settings4visualization.get('type4plot').lower()
        logger.info(f"Current plot type set to '{self.plot_type}'")

        # -- Depending on plot type, we have to use different logic:
        if self.plot_type in self.types_1d_plots + self.types_2d_plots:
            # -- Common data (has to be in all cases):
            self.data = data4visualization.get('var4vis')
            self.time = data4visualization.get('time')
            # -- Parse the string and format it to keep only the date:
            self.time = [
                datetime.strptime(ts, old_time_format).strftime(new_time_format)
                for ts in self.time
            ]
            self.ds_names = data4visualization.get('ds_name')

            # -- Handle specific logic for 'time_collage', 'collage', 'single_map':
            if self.plot_type in self.types_2d_plots:
                self.lon = data4visualization.get('var_lon')
                self.lat = data4visualization.get('var_lat')

        # -- Handle collage_1d_plot type separately:
        elif self.plot_type == 'collage_1d_plot':
            tmp_data, tmp_time, tmp_ds_names = [], [], []
            for sub_redions_data in data4visualization:
                tmp_data.append(sub_redions_data.get('var4vis'))
                tmp_time.append(sub_redions_data.get('time'))
                tmp_ds_names.append(sub_redions_data.get('ds_name'))
            # -- Compare list with simular values:
            tmp_time = ctr.compare_values_in_list(tmp_time)
            tmp_ds_names = ctr.compare_values_in_list(tmp_ds_names)
            #
            self.data = tmp_data
            self.time = tmp_time
            self.time = [
                datetime.strptime(ts, old_time_format).strftime(new_time_format)
                for ts in self.time
            ]
            self.ds_names = tmp_ds_names
        else:
            raise TypeError(
                f"Unsupported plot type '{self.plot_type}'. "
                "Please check 'type4plot' or provide 'collage_type'."
            )

        # -- Control datatype of input variables:
        #    1. Options 'line', 'scatter', 'bar'
        if self.plot_type in self.types_1d_plots:
            ctr.control_types4dict(
                {
                    'data': (self.data, list, np.ndarray),
                    'time': (self.time, list, str),
                    'ds_names': (self.ds_names, list, str),
                },
                func_name = func_name
            )
        #    2. Options collage_1d_plot ('line', 'scatter', 'bar')
        elif self.plot_type == 'collage_1d_plot':
            ctr.control_types4dict(
                {
                    'data': (self.data, list, list, np.ndarray),
                    'time': (self.time, list, str),
                    'ds_names': (self.ds_names, list, str),
                },
                func_name = func_name
            )
        #    3. Options for 'time_collage' - 2d plots
        elif self.plot_type == 'time_collage':
            ctr.control_types4dict(
                {
                    'data': (self.data, list, list, np.ndarray),
                    'lon': (self.lon, np.ndarray),
                    'lat': (self.lat, np.ndarray),
                    'time': (self.time, list, str),
                    'ds_names': (self.ds_names, list, str),
                },
                func_name = func_name
            )
        #    4. Options for 'collage' and 'single_map' - 2d plots
        elif self.plot_type in ('collage', 'single_map'):
            ctr.control_types4dict(
                {
                    'data': (self.data, np.ndarray),
                    'lon': (self.lon, np.ndarray),
                    'lat': (self.lat, np.ndarray),
                    'time': (self.time, list, str),
                    'ds_names': (self.ds_names, str),
                },
                func_name = func_name
            )
        #     5. Add other options as a new option, otherwise ERROR has to be raised:
        else:
            raise TypeError(
                f"Unsupported plot_type '{self.plot_type}' detected during type validation."
            )

        logger.info("All input variables from 'data4visualization' have correct data types.")

        # -- Depending on plot type, we have to use different logic:
        if self.plot_type in self.types_1d_plots + self.types_2d_plots:
            # -- Get variables for visualization (set by user - have to be in all cases):
            self.title = settings4visualization.get('plt_title')
            self.label = settings4visualization.get('plt_label')
            self.domain_type = settings4visualization.get('plt_domain_type')
            self.pout = settings4visualization.get('plt_out')
            # -- Special path for CSV reports:
            self.pout_csv_report = os.path.dirname(self.pout)
            logger.info(f"You output csv data will be saved in: {self.pout_csv_report}")

            # -- Control datatype of user settings for visualization (cannot be None):
            ctr.control_types4dict(
                {"settings4visualization.get('plt_domain_type')": (self.domain_type, str)},
                func_name = func_name,
            )
        elif self.plot_type == 'collage_1d_plot':
            self.title, self.label, self.domain_type = [], [], []
            for sub_redions_data in settings4visualization:
                self.title.append(sub_redions_data.get('plt_title'))
                self.label.append(sub_redions_data.get('plt_label'))
                self.domain_type.append(sub_redions_data.get('plt_domain_type'))
            # -- Remove dublicates:
            self.title = ctr.compare_values_in_list(self.title)
            self.label = ctr.compare_values_in_list(self.label)
            name = self.__extract_variable_name(self.title)
            # -- Get common output path:
            common_path = os.path.commonpath(
                [
                    entry['plt_out']
                    for entry in settings4visualization
                    if isinstance(entry.get('plt_out'), str)
                ]
            )
            self.pout_csv_report = f"{common_path}"
            self.pout = f"{common_path}/{name}_subregions"
            # -- Control datatype of user settings for visualization (cannot be None):
            ctr.control_types4dict(
                {"settings4visualization.get('plt_domain_type')": (self.domain_type, list, str)},
                func_name = func_name,
            )
        # -- Control other variables:
        ctr.control_types4dict(
            {
                "settings4visualization.get('plt_title')": (self.title, str),
                "settings4visualization.get('plt_label')": (self.label, str),
                "settings4visualization.get('plt_out')": (self.pout, str),
            },
            func_name = func_name
        )
        logger.info('All input variables from "settings4visualization", have correct data types.')

    @log_function_name
    def __extract_variable_name(self, full_name: str) -> str:
        """
        Extracts the main variable name from a comma-separated string.

        This function is useful when the input string contains multiple variable names
        separated by commas, but only the first one is needed.

        Parameters:
        -----------
        full_name : str
            A string that may contain one or more variable names separated by commas.

        Returns:
        --------
        str
            The first variable name (trimmed of whitespace).

        Example:
        --------
        full_name = "Temperature, Precipitation, Wind"
        result = "Temperature"
        """
        if not isinstance(full_name, str):
            raise TypeError(f"Expected 'full_name' as str, got {type(full_name)}")
        result = full_name.split(',')[0].strip()
        logger.debug(f"Extracted variable name: {result}")
        return result

    @log_function_name
    def _save_csv_report(
        self,
        output_path: str,
        min_values: float,
        max_values: float,
    ) -> None:
        """Update or append vmin/vmax for a given title in the CSV file."""
        # -- Ensure output directory exists
        output_dir = os.path.dirname(output_path)
        if not os.path.exists(output_dir):
            logger.info(f"Creating directory for CSV output: {output_dir}")
            os.makedirs(output_dir)
        # -- Initialize data list:
        records = []
        # -- If file exists, read it first:
        if os.path.isfile(output_path):
            with open(output_path, mode='r', newline='') as csvfile:
                reader = csv.reader(csvfile)
                records = list(reader)
        # -- Extract header and data rows:
        if records and records[0] == ["Title", "vmin", "vmax"]:
            header = records[0]
            data = records[1:]
        else:
            header = ["Title", "vmin", "vmax"]
            data = []
        # -- Check if title already exists:
        updated = False
        for i, row in enumerate(data):
            if row[0] == self.title:
                data[i] = [self.title, min_values, max_values]
                updated = True
                break
        # -- If not found, append new:
        if not updated:
            data.append([self.title, min_values, max_values])
        # -- Write back everything:
        with open(output_path, mode='w', newline='') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow(header)
            writer.writerows(data)

    @log_function_name
    def _get_subplots(
        self,
        l4names: Union[str, list[str]],
        domain_type: Optional[Union[str, list[str]]] = None,
        ds4vis: Optional[List[np.ndarray]] = None,
    ) -> str:
        """
        Determines the subplot layout configuration based on dataset count and domain type.

        Parameters:
        -----------
        l4names : str or list of str
            Dataset names.

        domain_type : str or list of str, optional
            Domain type ('global_PlateCarree', 'copat2_LambertConformal', 'RotatedPole').

        ds4vis : list of np.ndarray, optional
            Required for 2D single plots to check dataset count.

        Returns:
        --------
        str
            Subplot configuration name ('single', 'r1c4', 'r3c4', etc.).

        Raises:
        -------
        ValueError
            If the number of rows/columns is unknown or invalid.
        """
        # -- Local variables:
        subplot_size = "default"
        # -- Constant parameter due to the plots with more numbers of columns
        #    look overfull:
        num_cols_plt = 4

        # -- Depending on class, use different logic
        if self.__class__.__name__ == "Plot1D":
            if isinstance(domain_type, str):
                subplot_size = 'single'
            else:
                # -- Calculate the number of rows:
                num_items = len(domain_type)
                num_rows = math.ceil(num_items / num_cols_plt)
                logger.info(f"Current items = {num_items}, rows = {num_rows}")
                # -- Get different names depending on rows and cols:
                match (num_rows, num_cols_plt):
                    case (1, 4):
                        subplot_size = 'r1c4'
                    case (2, 4):
                        subplot_size = 'r2c4'
                    case (3, 4):
                        subplot_size = 'r3c4'
                    case (_, 4) if num_items > 12:
                        pass
                    case _:
                        raise ValueError("Unknown grid configuration for rows/cols.")
            logger.info(f"Selected subplot configuration for 1D → {subplot_size}")

        elif self.__class__.__name__ == "Plot2D":
            logger.debug("Determining subplot configuration for 2D plots.")
            # -- Define max allowed subplots (for r4c3 or r3c4)
            max_items = 12
            # -- Get maximal possible number of columns (not actual for single plot):
            if domain_type not in ('global_PlateCarree', 'copat2_LambertConformal', 'RotatedPole'):
                raise TypeError(f"Unknown domain_type '{domain_type}'")
            # -- More domains can be add here:
            if domain_type == 'global_PlateCarree':
                num_cols = 3
            elif domain_type in ['copat2_LambertConformal', 'RotatedPole']:
                num_cols = 4

            # -- Compute automatically numbers of rows and return name:
            if isinstance(l4names, str):
                if ds4vis is None:
                    raise ValueError("ds4vis must be provided for single l4names in 2D plots.")
                if len(ds4vis) == 1:
                    subplot_size = 'single'
                else:
                    plot_type = 'seasonal' if len(ds4vis) == 4 else 'annual'
                    logger.info(f"{plot_type.capitalize()} plots")
                    layout_map = {
                        'global_PlateCarree': {
                            'seasonal': 'r2c3', 'annual': 'r4c3',
                        },
                        'copat2_LambertConformal': {
                            'seasonal': 'r1c4', 'annual': 'r3c4',
                        },
                        'RotatedPole': {
                            'seasonal': 'r1c4', 'annual': 'r3c4',
                        },
                    }
                    # Set layout using map, fallback to default if not found
                    subplot_size = layout_map.get(domain_type, {}).get(plot_type)
                    if subplot_size is None:
                        raise ValueError(f"Unknown layout for domain_type {domain_type}")
            else:
                num_items = len(l4names)
                if num_items == 1:
                    # -- Single plot option
                    subplot_size = 'single'
                elif num_items > max_items:
                    pass
                else:
                    # -- Calculate the number of rows:
                    num_rows = math.ceil(num_items / num_cols)
                    # -- Get different names depending on rows and cols:
                    match (num_rows, num_cols):
                        case (1, 3) if domain_type == 'global_PlateCarree':
                            subplot_size = 'r1c3'
                        case (2, 3) if domain_type == 'global_PlateCarree':
                            subplot_size = 'r2c3'
                        case (3, 3) if domain_type == 'global_PlateCarree':
                            subplot_size = 'r3c3'
                        case (4, 3) if domain_type == 'global_PlateCarree':
                            subplot_size = 'r4c3'
                        case (1, 4) if domain_type in ['copat2_LambertConformal', 'RotatedPole']:
                            subplot_size = 'r1c4'
                        case (2, 4) if domain_type in ['copat2_LambertConformal', 'RotatedPole']:
                            subplot_size = 'r2c4'
                        case (3, 4) if domain_type in ['copat2_LambertConformal', 'RotatedPole']:
                            subplot_size = 'r3c4'
                        case _:
                            raise ValueError('Unknown number of cols. Check self._num_cols')
            logger.info(f"Selected subplot configuration for 2D → {subplot_size}")
        else:
            raise TypeError(f"Unsupported class '{self.__class__.__name__}' for subplot selection.")
        return subplot_size


class Plot1D(Fig_preprocessor):
    """
    Class for creating 1D visualizations: line, scatter, and bar plots.

    Inherits from Fig_preprocessor and handles additional configuration loading,
    settings merging, and 1D-specific plotting logic.

    Parameters
    ----------
    data4visualization : Dict[str, np.ndarray]
        Input data dictionary for 1D plots.
    settings4visualization : Dict[str, Union[str, float, int]]
        Visualization settings dictionary for 1D plots.
    collage_type : str, optional
        Specify collage type if applicable.

    Methods
    -------
    create_single_plot_1d():
        Creates a single 1D plot (non-collage).
    create_collage_plot_1d_auto():
        Automatically creates a collage of 1D plots with chunking.
    """
    @log_function_name
    def __init__(
        self,
        evaluation_mode: str,
        data4visualization: Union[Dict[str, np.ndarray], List[Dict[str, np.ndarray]]],
        settings4visualization: Union[Dict[str, Union[str, float, int]], List[Dict[str, Union[str, float, int]]]],
        config_paths: Dict[str, Union[None, str]],
        collage_type: Optional[str] = None,
    ) -> None:
        """Initialization 1D methods:"""
        # -- Local variables:
        self.class_name = self.__class__.__name__

        # -- Initialzation of parent class:
        super().__init__(
            evaluation_mode,
            data4visualization,
            settings4visualization,
            collage_type,
        )
        logger.info(f"Initialized {self.class_name} with plot type: {self.plot_type}")

        # -- General plot configuration:
        # -- Initialization of the user class with 1D plot (PLOT) settings:
        self.cfg_plots = Builder_plots_config()
        # -- Load default settings (do not modify these manually):
        plt_settings_default = self.cfg_plots._build_plot1d_settings().values
        # -- Load user MAP settings from the YAML file (if provided):
        plt_path = (
            os.path.abspath(os.path.expanduser(config_paths["PLOTCONFIG"]))
            if config_paths["PLOTCONFIG"] is not None else None
        )
        # -- Load test configuration settings based on GUI Form:
        if plt_path:
            logger.info(
                f"User-defined PLOT configuration detected.\n"
                f"Configuration file path: {plt_path}"
            )
            plt_settings_user = self.cfg_plots._read_yaml_config(plt_path)
            # -- Merge user-modified settings with defaults
            #    (non-modified fields keep defaults):
            self._plt_settings_all = self.cfg_plots._merge_user_settings(
                # -- Default settings:
                plt_settings_default,
                # -- User settings
                plt_settings_user,
            )
        else:
            logger.info(
                "No user PLOT configuration provided.\n"
                " Using the internal default PLOT settings."
            )
            self._plt_settings_all = plt_settings_default
        # -- Run control of input variables:
        self.cfg_plots._control_user_settings(self._plt_settings_all)
        # -- Get vmin and vmax values:
        # -- We have two options (default -> program compute values
        #                         user -> we are using user values)
        temp_min = self._plt_settings_all['plts_min_values']
        temp_max = self._plt_settings_all['plts_max_values']

        if temp_min is None and temp_max is None:
            if isinstance(settings4visualization, list):
                # -- Initialize lists for all plotabsmin and plotabsmax values:
                all_min_values = [item['plotabsmin'] for item in settings4visualization]
                all_max_values = [item['plotabsmax'] for item in settings4visualization]
                # -- Compute the absolute minimum and maximum values across the list:
                self.absolute_min = min(all_min_values)
                self.absolute_max = max(all_max_values)
            elif isinstance(settings4visualization, dict):
                # Extract all min and max values:
                self.absolute_min = settings4visualization['plotabsmin']
                self.absolute_max = settings4visualization['plotabsmax']
            else:
                raise TypeError(
                    f"Incorrect input type for 'settings4visualization'."
                    f"Expected list or dict, got {type(settings4visualization)}"
                )
        elif temp_min is not None and temp_max is not None:
            self.absolute_min = temp_min[self.title]
            self.absolute_max = temp_max[self.title]
        else:
            raise ValueError("Please provide both 'plts_max_values' and 'plts_min_values', or neither.")

        # -- Get actual subtitles, in case of 1d plots -> it has to be a legend labels:
        if self._plt_settings_all['plts_subtitle'] is None:
            logger.info("We are using subtitles based on NetCDF attributes")
        else:
            if len(self.ds_names) == len(self._plt_settings_all['plts_subtitle']):
                logger.info("We are using subtitles based on user names")
                self.ds_names = self._plt_settings_all['plts_subtitle']
            else:
                logger.info(
                    "User and NetCDF names have different len"
                    "We are using subtitles based on NetCDF attributes"
                )
                logger.info(f"name lenght in NetCDF = {len(self.ds_names)}")
                logger.info(
                    f"name lenght in maps_subtitle = {len(self._plt_settings_all['plts_subtitle'])}")

    @log_function_name
    def __nice_round(self, value: float) -> float:
        """
        Nicely rounds a positive value UP to the next 'friendly' number (1, 2.5, 5, 10, ...).

        This rounding approach is commonly used for colorbars, axis limits, or any kind
        of labeling where human-friendly, easy-to-read numbers are preferred.

        Parameters:
        -----------
        val : float
            The input value (usually positive). If the value is zero, returns zero.

        Returns:
        --------
        rounded : float
            Rounded-up value to the nearest "nice" number:
            - 1 * magnitude of 10^n
            - 2.5 * magnitude of 10^n
            - 5 * magnitude of 10^n
            - 10 * magnitude of 10^n


        Notes:
        ------
        - Designed for POSITIVE input values.
        - Use `nice_round_down()` for rounding negative values downward symmetrically.
        """
        # -- Round step to a "nice" value (e.g., 1, 2, 5, 10, 20, etc.)
        magnitude = 10 ** math.floor(math.log10(value))
        normalized = value / magnitude
        # Round to nearest "nice" value
        if normalized < 1.5:
            rounded = 1 * magnitude
        elif normalized < 3:
            rounded = 2.5 * magnitude
        elif normalized < 7:
            rounded = 5 * magnitude
        else:
            rounded = 10 * magnitude
        logger.info(f"Rounded {value} → {rounded}")
        return rounded

    @log_function_name
    def _adjust_and_round_vmin_vmax(
        self,
        abs_min: float,
        abs_max: float,
    ) -> tuple[float, float, float]:
        """
        Adjusts and rounds the vmin and vmax values for Y-axis or colorbar scaling
        to ensure human-friendly labeling using "nice" intervals.

        The function:
        1. Calculates the total data range (`absolute_max - absolute_min`).
        2. Divides this range into approximately 10 intervals.
        3. Uses `__nice_round` to round the interval step to a "nice" number.
        4. Rounds vmin and vmax to the nearest multiple of the computed step.

        Returns
        -------
        tuple of float
            Rounded (vmin, vmax, step) values, ready to be used for axis or colorbar limits.

        Example
        -------
        >>> vmin, vmax, step = self._adjust_and_round_vmin_vmax()
        >>> logger.info(vmin, vmax, step)
        -5.0 25.0 5.0

        Notes
        -----
        - Requires that `self.absolute_min` and `self.absolute_max` are already defined.
        - Use this function for consistent, readable scaling across different plots.
        """
        # -- Local variables:
        max_intervals = 10
        # -- Define global Y-axis limits (Minimum and Maximum across all values):
        value_range = abs(abs_max - abs_min)
        if value_range == 0:
            logger.warning("Value range is zero. Using default step=1.0")
            step = 1.0
        else:
            # -- Compute step size to ensure 10 intervals:
            step = value_range / max_intervals
            # -- Get nice values:
            step = self.__nice_round(step)
        # -- Round vmin and vmax to the nearest step:
        vmin = step * math.floor(abs_min / step)
        vmax = step * math.ceil(abs_max / step) + step

        # -- Save output numbers to CSV:
        output_path = f'{self.pout_csv_report}/vmin_vmax_log.csv'
        self._save_csv_report(output_path, vmin, vmax)

        logger.info(
            f"Computed vmin = {vmin}, vmax = {vmax}, step = {step} "
            f"(based on absolute_min = {abs_min}, absolute_max = {abs_max})"
        )
        return vmin, vmax, step

    @log_function_name
    def create_single_plot_1d(self) -> None:
        """User function for single 1d plot visualization:"""
        # -- Get correct grid type (depending on plot type, we are using different settings):
        if isinstance(self.domain_type, str):
            subplot_size = self._get_subplots(self.ds_names, self.domain_type)
            logger.info(f"Dataset ({len([self.domain_type])} plots) → {subplot_size}: {self.ds_names}")
        else:
            raise TypeError(
                f'self.domain_type has invalid format: {self.domain_type}'
                f'It must be a string for a single plot — if it is a list, it will be treated as a collage plot.')

        # -- Initialization of user class with 1d methods for set up 1d plots:
        self._user_plots_functions = Plot_settings(
            self.cfg_plots._get_plot_setting,
            subplot_size,
            self._plt_settings_all,
        )
        # -- Correct time steps (convert to hourly, daily, monthly formats):
        self.time = self._user_plots_functions.correct_time(self.time)
        logger.info(f'Actual timesteps: {self.time}')

        # -- Create figure:
        fig, axs = plt.subplots(
            nrows = self._user_plots_functions.splt_nrows,
            ncols = self._user_plots_functions.splt_ncols,
            figsize = (
                self._user_plots_functions.plt_width,
                self._user_plots_functions.plt_heigth,
            ),
            gridspec_kw = {
                'wspace': self._user_plots_functions.splt_wspace,
                'hspace': self._user_plots_functions.splt_hspace,
            },
        )
        # -- Add objects to the plot:
        for i in range(len(self.data)):
            if len(self.time) == 1:
                logger.info('Activated scatter plot')
                plt_line_type = 'scatter'
            else:
                plt_line_type = 'line'

            self._user_plots_functions.create_plot_data(
                axs, self.data, self.ds_names, plt_line_type, self.time, i
            )

        # -- Get min and max values:
        vmin, vmax, step = self._adjust_and_round_vmin_vmax(
            self.absolute_min, self.absolute_max)

        # -- Add zero line:
        self._user_plots_functions.add_zero_line(
            axs, self.eval_mode, vmin, vmax)

        # -- Apply user settings for visualization:
        # -- Add Plot title and x and y axes labels:
        self._user_plots_functions.add_title_xy_label(
            axs, title = self.domain_type, xlabel = None, ylabel = self.label)
        # -- Add legend:
        self._user_plots_functions.add_legend_simple(axs)

        # -- Setup for values on Y and X axis:
        self._user_plots_functions.add_limits4_Y_axis(
            axs, ylim_num = [vmin, vmax, step])
        if len(self.time) == 1:
            logger.debug("Setting X-axis limits with ±1 day buffer for single timestamp")
            timepoint = pd.to_datetime(self.time[0])
            margin = pd.Timedelta(days=1)
            self._user_plots_functions.add_limits4_X_axis(
                axs, xlim_time = [timepoint - margin, timepoint + margin])
        else:
            self._user_plots_functions.add_limits4_X_axis(
                axs, xlim_time = [self.time[0], self.time[-1]])
        # -- Add grid:
        self._user_plots_functions.add_grid(axs)
        # -- Add second Y axis:
        self._user_plots_functions.add_extra_y_axis(axs)
        # -- Extra settings for X and Y ticks: (ax, rotation, size)
        self._user_plots_functions.add_xticks_settings(axs)
        self._user_plots_functions.add_yticks_settings(axs)
        # -- Save or show figure:
        self._user_plots_functions.save_plot(fig, plt_pout = self.pout)
        # -- Adjust layout to prevent overlap:
        plt.tight_layout()
        # -- Clean memory:
        plt.close(fig)
        plt.gcf().clear()

    @log_function_name
    def create_collage_plot_1d_auto(self) -> None:
        """User function for 1d collage plot visualization:"""
        # -- Min and Max (define above for all regions):
        vmin, vmax, step = self._adjust_and_round_vmin_vmax(
            self.absolute_min, self.absolute_max)


        # -- Start multi figures visualization (12 subplots for 1 figure):
        for i, start_idx in enumerate(range(0, len(self.domain_type), self.subplot_chunk_size)):
            logger.debug(f"Current plot index is {i}, Subplot chunk is: {start_idx}")
            end_idx = min(start_idx + self.subplot_chunk_size, len(self.domain_type))
            chunk_domains = self.domain_type[start_idx:end_idx]
            chunk_data = self.data[start_idx:end_idx]
            chunk_names = self.ds_names
            # -- Get correct grid type (depending on plot type, we are using different settings):
            subplot_size = self._get_subplots(chunk_names, chunk_domains)
            logger.info(f"Chunk {i+1} ({len(chunk_domains)} plots) → {subplot_size}: {chunk_names}")
            # -- Initialization of user class with 1d methods for set up 1d plots:
            self._user_plots_functions = Plot_settings(
                self.cfg_plots._get_plot_setting,
                subplot_size,
                self._plt_settings_all,
            )
            # -- Correct time steps (convert to hourly, daily, monthly formats):
            self.time = self._user_plots_functions.correct_time(self.time)
            logger.info(self.time)
            # -- Create figure:
            fig, axs = plt.subplots(
                nrows = self._user_plots_functions.splt_nrows,
                ncols = self._user_plots_functions.splt_ncols,
                figsize = (
                    self._user_plots_functions.plt_width,
                    self._user_plots_functions.plt_heigth,
                ),
                gridspec_kw = {
                    'wspace': self._user_plots_functions.splt_wspace,
                    'hspace': self._user_plots_functions.splt_hspace,
                },
            )
            # -- Convert axs object to list:
            axs = axs.flatten()

            logger.info('Create collage plot with 1d subplots:')
            # -- Add plot title (common):
            fig.suptitle(self.title, fontsize = 14.0)
            # -- Count the actual number of datasets (non-None values):
            num_valid_datasets = sum(1 for ds in chunk_data if ds is not None)
            # -- Index for not full fill subplots (don't modify without testing):
            remaining = num_valid_datasets % self._user_plots_functions.splt_ncols
            if num_valid_datasets == 11:
                last_full_row_start = 7
            elif num_valid_datasets == 10:
                last_full_row_start = 6
            elif num_valid_datasets == 9:
                last_full_row_start = 5
            elif num_valid_datasets == 7:
                last_full_row_start = 3
            elif num_valid_datasets == 6:
                last_full_row_start = 2
            elif num_valid_datasets == 5:
                last_full_row_start = 1
            elif num_valid_datasets in [1, 2, 3]:
                last_full_row_start = 0
            # -- Start visualization:
            for j, (domain, data_item) in enumerate(zip(chunk_domains, chunk_data)):
                for k in range(len(data_item)):
                    if len(self.time) == 1:
                        logger.info('Activated scatter plot')
                        plt_line_type = 'scatter'
                    else:
                        plt_line_type = 'line'

                    self._user_plots_functions.create_plot_data(
                        axs[j], chunk_data, self.ds_names, plt_line_type, self.time, j, k
                    )
                # -- Add zero line:
                self._user_plots_functions.add_zero_line(
                    axs[j], self.eval_mode, vmin, vmax)

                # -- Set special properties for Y label (show only left)
                if subplot_size == 'r1c4':
                    ylabel = self.label if j == 0 else None
                elif subplot_size == 'r2c4':
                    ylabel = self.label if j in [0, 4] else None
                elif subplot_size == 'r3c4':
                    ylabel = self.label if j in [0, 4, 8] else None
                # -- Add Plot title and x and y axes labels:
                self._user_plots_functions.add_title_xy_label(
                    axs[j], title = chunk_domains[j], xlabel = None, ylabel = ylabel)
                # -- Setup for values on Y axis:
                self._user_plots_functions.add_limits4_Y_axis(
                    axs[j], ylim_num = [vmin, vmax, step])
                # -- Setup for values on X axis (not set):
                if len(self.time) == 1:
                    logger.debug("Setting X-axis limits with ±1 day buffer for single timestamp")
                    timepoint = pd.to_datetime(self.time[0])
                    margin = pd.Timedelta(days=1)
                    self._user_plots_functions.add_limits4_X_axis(
                        axs[j], xlim_time = [timepoint - margin, timepoint + margin])
                else:
                    self._user_plots_functions.add_limits4_X_axis(
                        axs[j], xlim_time = [self.time[0], self.time[-1]])

                # --- Handle X-tick labels within the loop ---:
                if remaining == 0:
                    # If last row is full, only the last row should have labels:
                    if j < num_valid_datasets - self._user_plots_functions.splt_ncols:
                        axs[j].set_xticklabels([])
                else:
                    if j < last_full_row_start:
                        axs[j].set_xticklabels([])
                # -- Add grid:
                self._user_plots_functions.add_grid(axs[j])
                # -- Extra settings for X and Y ticks: (ax, rotation, size):
                self._user_plots_functions.add_xticks_settings(axs[j])
                self._user_plots_functions.add_yticks_settings(axs[j])
            # -- Remove unused axes:
            for k in range(num_valid_datasets, len(axs)):
                axs[k].set_visible(False)
            # -- Add legend:
            self._user_plots_functions.add_single_legend(
                fig = fig, axs = axs, legend_title = "Models",
            )
            # -- Adjust bottom line:
            plt.subplots_adjust(
                bottom = self._user_plots_functions.splt_bottom,
                top = self._user_plots_functions.splt_top,
            )
            # -- Save or show figure:
            self._user_plots_functions.save_plot(
                fig, plt_pout = f'{self.pout}_part_{i+1}')
            logger.info(f"Saved figure: {self.pout}_part_{i+1}")
            # -- Clean memory:
            plt.close(fig)
            plt.gcf().clear()


class Plot2D(Fig_preprocessor):
    """
    Class for creating 2D map visualizations: single map, collage maps, and time-based collages.

    Inherits from Fig_preprocessor and handles map-specific configuration loading,
    projection selection, normalization calculation, and visualization.

    Parameters
    ----------
    data4visualization : Dict[str, np.ndarray]
        Input data dictionary for 2D maps.
    settings4visualization : Dict[str, Union[str, float, int]]
        Visualization settings dictionary for 2D maps.
    collage_type : str, optional
        Specify collage type if applicable.

    Methods
    -------
    create_collage_plot_2d_auto():
        Automatically creates a collage of 2D maps, including support for difference plots.
    _compute_norm_for_plot(data4plot):
        Computes the normalization object for colorbar scaling based on percentiles.
    """
    @log_function_name
    def __init__(
        self,
        evaluation_mode: str,
        ls_mask: bool,
        data4visualization: Union[Dict[str, np.ndarray], List[Dict[str, np.ndarray]]],
        settings4visualization: Dict[str, Union[str, float, int]],
        config_paths: Dict[str, Union[None, str]],
        collage_type: Optional[str] = None,
        eval_variable: Optional[str] = None,
    ) -> None:
        """Initialization of Plot2D"""
        # -- Local variables:
        self.class_name = self.__class__.__name__  # Class name
        # -- Initialzation of parent class:
        super().__init__(
            evaluation_mode,
            data4visualization,
            settings4visualization,
            collage_type,
        )
        logger.info(f"Initialized {self.class_name} with plot type: {self.plot_type}")
        # -- Define the mask values for NaN values:
        self._nanvals = -999999
        # -- Lower percentile (default 1):
        self.lower_pct = 1
        # -- Upper percentile (default 99):
        self.upper_pct = 99

        # -- General map configuration:
        # -- Initialization of the user class with 2D plot (map) settings:
        self.cfg_maps = Builder_maps_config()
        # -- Load default settings (do not modify these manually):
        map_settings_default = self.cfg_maps._build_maps_settings().values
        # -- Load user MAP settings from the YAML file (if provided):
        map_path = (
            os.path.abspath(os.path.expanduser(config_paths["MAPCONFIG"]))
            if config_paths["MAPCONFIG"] is not None else None
        )
        # -- Load test configuration settings based on GUI Form:
        if map_path:
            logger.info(
                f"User-defined MAP configuration detected.\n"
                f"Configuration file path: {map_path}"
            )
            map_settings_user = self.cfg_maps._read_yaml_config(map_path)
            # -- Merge user-modified settings with defaults
            #    (non-modified fields keep defaults):
            self._map_settings_all = self.cfg_maps._merge_user_map_settings(
                # -- Default settings:
                map_settings_default,
                # -- User settings
                map_settings_user,
            )
        else:
            logger.info(
                "No user MAP configuration provided.\n Using the internal default MAP settings."
            )
            self._map_settings_all = map_settings_default
        # -- Final control/validation of the combined settings:
        self.cfg_maps._control_maps_settings(self._map_settings_all)
        # -- Show values above limits:
        self.clip_norm_values = False

        # -- Create a specil subplot titles
        if self._map_settings_all['maps_subtitle'] is None:
            logger.info("We are using subtitles based on NetCDF attributes")
        else:
            if len(self.ds_names) == len(self._map_settings_all['maps_subtitle']):
                logger.info("We are using subtitles based on user names")
                self.ds_names = self._map_settings_all['maps_subtitle']
            else:
                logger.info(
                    "User and NetCDF names have different len"
                    "We are using subtitles based on NetCDF attributes"
                )
                logger.info(f"name lenght in NetCDF = {len(self.ds_names)}")
                logger.info(f"name lenght in maps_subtitle = {len(self._map_settings_all['maps_subtitle'])}")

        # -- Define colorbar key:
        self.key4colormap = None
        if isinstance(eval_variable, str):
            self.key4colormap = eval_variable
        else:
            logger.warning(
                f"Unrecognized evaluation mode '{evaluation_mode}' or missing evaluation variable. "
                "Using default key for colorbar."
            )
        # -- Show land/sea mask:
        self.land_sea_mask = ls_mask

    @log_function_name
    def __smart_round(
        self,
        vmin: float,
        vmax: float,
        threshold: float,
        min_negative_extend: float = 2.5
    ) -> tuple[float, float]:
        """
        Apply smart rounding logic for colorbar limits in visualization.

        Parameters:
        -----------
        vmin : float
            The raw minimum value of the data (e.g., from percentiles).
            Can be negative, positive, or zero.

        vmax : float
            The raw maximum value of the data (e.g., from percentiles).
            Always expected to be positive for regular colorbars.

        threshold : float
            Range limit below which rounding is completely skipped.
            If both |vmin| and |vmax| are less than this threshold,
            the function returns the original vmin and vmax without rounding.
            This protects small data ranges from being distorted by rounding.

        min_negative_extend : float, optional (default=2.5)
            The minimum absolute value to enforce on the negative side if vmin < 0.
            Even if the actual vmin is close to zero (like -0.99), this parameter
            ensures the colorbar starts at at least -2.5 (or your specified value).
            This prevents the negative part of the data from being visually compressed
            or hidden on the colorbar.

        Returns:
        --------
        vmin_final : float
            Rounded (or original) minimum value, possibly extended to cover negative values
            with a margin if needed.

        vmax_final : float
            Rounded (or original) maximum value, rounded up nicely if outside the threshold.

        Example:
        --------
        raw_vmin = -0.99
        raw_vmax = 20.4
        vmin_final, vmax_final = smart_round(raw_vmin, raw_vmax, threshold=5)
        # Result: vmin_final = -2.5, vmax_final = 25
        """
        if not np.isfinite(vmin) or not np.isfinite(vmax):
            raise ValueError("Non-finite vmin or vmax passed to smart_round")
        # -- Skip rounding for small ranges:
        if abs(vmax - vmin) < threshold:
            return vmin, vmax

        # Ensure ordering
        vmin, vmax = min(vmin, vmax), max(vmin, vmax)
        data_range = vmax - vmin

        # Compute dynamic step size
        rough_step = data_range / 5.0  # aim for ~5 intervals
        base = 10 ** np.floor(np.log10(rough_step))

        # Scale to a nice number: 1, 2, or 5 * 10^x
        if rough_step / base >= 5:
            step = 5 * base
        elif rough_step / base >= 2:
            step = 2 * base
        else:
            step = 1 * base

        # Final vmin/vmax rounded outward
        vmin_final = step * np.floor(vmin / step)
        vmax_final = step * np.ceil(vmax / step)

        # Optional: ensure at least min_negative_extend is shown if vmin is small negative
        if vmin_final < 0 and abs(vmin_final) < min_negative_extend:
            vmin_final = -min_negative_extend

        # Final safety: if equal, expand range
        if np.isclose(vmin_final, vmax_final):
            vmax_final += step

        logger.debug(
            f"Smart rounding:\n"
            f"  Raw vmin/vmax = {vmin:.4f}, {vmax:.4f}\n"
            f"  Range = {vmax - vmin:.4f}, Threshold = {threshold}\n"
            f"  Rounded vmin/vmax = {vmin_final:.4f}, {vmax_final:.4f} \n"
        )

        return vmin_final, vmax_final

    @log_function_name
    def _compute_norm_from_percentile(
        self,
        data_values: np.ndarray,
        diverging: bool = False,
        rounding_threshold: float = 2.5,
    ) -> Tuple[Union[Normalize, TwoSlopeNorm], str]:
        """
        Compute TwoSlopeNorm (for difference plots) or Normalize (for regular plots) using percentile-based limits,
        with integrated nice rounding.

        Parameters:
        ----------------------------
            data_values (np.ndarray): Flattened array of data values.
            diverging (bool): True for difference plots (TwoSlopeNorm), False for normal plots (Normalize).

        Returns:
        ----------------------------
            TwoSlopeNorm: Normalization object for diverging colormap centered at 0.
        """
        # -- Decide which keys to use based on diverging flag
        min_key = 'maps_min_values_diff' if diverging else 'maps_min_values'
        max_key = 'maps_max_values_diff' if diverging else 'maps_max_values'
        # -- Load None or dictionaries:
        vmin_temp = self._map_settings_all.get(min_key)
        vmax_temp = self._map_settings_all.get(max_key)

        # -- Select algorithm for data:
        if vmin_temp is None and vmax_temp is None:
            vmin_override, vmax_override = vmin_temp, vmax_temp
        else:
            clean_title = self.title.replace(', ', ',')
            vmin_override = vmin_temp.get(clean_title)
            vmax_override = vmax_temp.get(clean_title)
        # -- Safety check:
        zero = 0
        if data_values.size == zero or np.all(np.isnan(data_values)):
            raise ValueError("Empty or NaN-only array provided to compute normalization.")
        # -- Decide how to compute vmin/vmax:
        if vmin_override is None and vmax_override is None:
            logger.info(
                f"Using nanpercentile method to compute "
                f"{'diff ' if diverging else ''}min and max values")
            vmin_raw = np.nanpercentile(data_values, self.lower_pct)
            vmax_raw = np.nanpercentile(data_values, self.upper_pct)
            # -- Get nice values
            vmin_rounded, vmax_rounded = self.__smart_round(
                vmin_raw, vmax_raw, rounding_threshold)
            # --- Safety if rounding collapses vmin/vmax:
            if np.isclose(vmin_rounded, vmax_rounded):
                vmin_rounded = vmin_raw
                vmax_rounded = vmax_raw
        elif vmin_override is not None and vmax_override is not None:
            logger.info(
                f"Using user values for "
                f"{'diff ' if diverging else ''}min and max values")

            # -- Special algorithm for control user values:
            data_min = np.nanmin(data_values)
            data_max = np.nanmax(data_values)
            if data_max < vmin_override or data_min > vmax_override:
                logger.warning(
                    f"User-defined limits vmin={vmin_override}, vmax={vmax_override} "
                    f"do NOT overlap with data range: [{data_min}, {data_max}]. "
                    f"This may lead to empty or invalid colorbars/plots."
                )
            cover_range = vmax_override - vmin_override
            data_range = data_max - data_min
            coverage_ratio = data_range / cover_range if cover_range else 0
            if coverage_ratio < 0.3:
                logger.warning(
                    f"User-defined range [{vmin_override}, {vmax_override}] "
                    f"is much wider than the actual data range [{data_min}, {data_max}]. "
                    f"This may cause the colorbar to appear blank or mis-scaled."
                )
            # -- Set actual values:
            vmin_rounded = vmin_override
            vmax_rounded = vmax_override
        else:
            raise ValueError(f"Please provide both {min_key} and {max_key}, or neither.")

        # -- Save min and max values:
        if diverging:
            csv_file = f"{self.pout_csv_report}/percentile_norms_diff_log.csv"
        else:
            csv_file = f"{self.pout_csv_report}/percentile_norms_log.csv"
        self._save_csv_report(csv_file, vmin_rounded, vmax_rounded)

        # -- Define a special key for colormap:
        if vmin_raw < 0 and vmax_raw > 0:
            cmap_type = 'def_full'
        elif vmin_raw >= 0:
            cmap_type = 'def_positive'
        elif vmax_raw <= 0:
            cmap_type = 'def_negative'

        # --- Create normalization:
        logger.info(
            f'{"Diff" if diverging else "Main"} mode: vmin_rounded={vmin_rounded}, vmax_rounded={vmax_rounded}')

        if vmin_rounded < zero and vmax_rounded > zero:
            abs_max = max(abs(vmin_rounded), abs(vmax_rounded))
            if abs_max == zero:
                abs_max = 1
            logger.info(f"{'Diff' if diverging else 'Main'} mode: using TwoSlopeNorm (data spans zero)")
            return TwoSlopeNorm(vmin=-abs_max, vcenter=zero, vmax=abs_max), cmap_type
        elif vmax_rounded <= zero and diverging:
            logger.warning("Diff plot is entirely non-positive — using Normalize instead")
            return Normalize(vmin=vmin_rounded, vmax=vmax_rounded + 1), cmap_type
        elif vmin_rounded >= zero and diverging:
            logger.warning("Diff plot is entirely non-negative — using Normalize instead")
            return Normalize(vmin=vmin_rounded - 1, vmax=vmax_rounded), cmap_type
        else:
            return Normalize(vmin=vmin_rounded, vmax=vmax_rounded), cmap_type

    @log_function_name
    def _compute_norm_for_plot(
        self,
        data4plot: list,
    ) -> Tuple[Union[Normalize, TwoSlopeNorm], str]:
        """
        Compute vmin/vmax normalization for the 2D collage plot
        depending on the current plot_type ('time_collage', 'collage', or 'single').

        Parameters:
        -----------
        data4plot : array-like
            The input data array (could be list of arrays for time_collage, or array for single/collage).

        Returns:
        --------
        norm : Normalize or TwoSlopeNorm
            Normalization object based on computed percentiles.
        cmap_type_key : str
            Key indicating the colorbar category ('def_diverging', 'def_positive', etc.).
        """
        logger.info(f"Get norm for {self.plot_type}")

        all_data_values = []

        if self.plot_type == 'time_collage':
            # -- Flatten across time steps and datasets:
            for timestep in data4plot:
                for d in timestep:
                    masked = np.ma.masked_invalid(d)
                    valid = np.ravel(masked.filled(np.nan))
                    if np.any(~np.isnan(valid)):
                        all_data_values.append(valid)

        elif self.plot_type == 'collage':
            # Flatten across timesteps (collage uses one dataset with multiple timesteps):
            for timestep in data4plot:
                masked = np.ma.masked_invalid(timestep)
                valid = np.ravel(masked.filled(np.nan))
                if np.any(~np.isnan(valid)):
                    all_data_values.append(valid)

        elif self.plot_type == 'single_map':
            # Single dataset, single timestep:
            masked = np.ma.masked_invalid(data4plot)
            valid = np.ravel(masked.filled(np.nan))
            if np.any(~np.isnan(valid)):
                all_data_values.append(valid)
        else:
            raise TypeError(f"Unknown plot_type = {self.plot_type}")

        # -- Safety check:
        if len(all_data_values) == 0:
            raise ValueError(f"No valid data found for {self.title} to compute vmin/vmax!")
        else:
            all_data_values = np.concatenate(all_data_values)

        # -- Compute normalization and return cmap type:
        norm, cmap_type_key = self._compute_norm_from_percentile(
            all_data_values, diverging=False)
        return norm, cmap_type_key

    @log_function_name
    def get_mask(
        self,
        lon_2d: np.ndarray,
        lat_2d: np.ndarray,
        data4masking: np.ndarray,
        mask_type: str = "land",
        mask_active: bool = True,
    ) -> np.ndarray:
        """
        Applies a land/ocean mask to the input data using Cartopy's Natural Earth shapefiles.

        Parameters:
        -----------
        lon_2d : np.ndarray
            2D array of longitudes corresponding to the data grid.
        lat_2d : np.ndarray
            2D array of latitudes corresponding to the data grid.
        data : np.ndarray
            2D (or broadcastable) array of the same shape as lon_2d/lat_2d containing the data to mask.
        mask_type : str, optional
            Whether to mask "land" or "ocean". Default is "land".
            - "land" keeps land points and masks ocean.
            - "ocean" keeps ocean points and masks land.
        mask_active : bool, optional
            Whether to apply the mask. If False, returns `data` unchanged.

        Returns:
        --------
        np.ndarray
            The masked data array (same shape as input `data`).
            Points outside the specified `mask_type` will be set to NaN.

        Notes:
        ------
        - Uses shapely and geopandas with Cartopy's 'natural_earth' dataset.
        - Designed for 2D geospatial data.
        """
        from shapely.geometry import Point
        from shapely.prepared import prep
        import geopandas as gpd
        from cartopy.io.shapereader import natural_earth

        if mask_active:
            logger.info('Land/Ocean mask was turned on')
            # -- Get Cartopy's land/ocean features
            land_gdf = gpd.read_file(
                natural_earth(category='physical', name='land', resolution='50m')
            )
            # -- Prepare land geometry for fast containment checks
            prepared_land = prep(land_gdf.unary_union)

            # -- Create land/ocean boolean mask
            flat_coords = np.column_stack([lon_2d.ravel(), lat_2d.ravel()])
            land_mask = np.array([
                prepared_land.contains(Point(lon, lat)) for lon, lat in flat_coords
            ], dtype=bool).reshape(lon_2d.shape)

            # -- Apply mask to the data
            # mask_type = "land"  # set to "ocean" if you want to keep only ocean
            if mask_type == "land":
                masked_data = np.where(land_mask, data4masking, np.nan)
            else:  # mask_type == "ocean"
                masked_data = np.where(~land_mask, data4masking, np.nan)
            return masked_data
        else:
            logger.info('Land/Ocean mask was turned off')
            return data4masking

    @log_function_name
    def create_collage_plot_2d_auto(self) -> None:
        """User function for 2D collage plot visualization with automatic chunking."""
        # -- Activate difference plot visualization if number of datasets equal 2
        diff_datasets_lim = 2
        # -- Create difference plot only if there is 1 chunk of data:
        diff_chunk_lim = 0
        # -- Original time format in dataset:
        orig_time_form = "%Y-%m-%d %H:%M:%S"
        # -- New time format in dataset:
        new_time_form = "%Y-%m-%d"

        # -- Create a mesh grid based on lon * lat:
        if self.lon.ndim == 1 and self.lat.ndim == 1:
            lon_2d, lat_2d = np.meshgrid(self.lon, self.lat)
            logger.info(f"Generated meshgrid from 1D lon/lat → shape {lon_2d.shape}")
        elif self.lon.ndim == 2 and self.lat.ndim == 2:
            lon_2d, lat_2d = self.lon, self.lat
            logger.info(f"Using existing 2D lon/lat → shape {lon_2d.shape}")
        else:
            logger.warning(
                f"Unexpected lon/lat dimensions: lon.ndim={self.lon.ndim}, lat.ndim={self.lat.ndim}. "
                "Expected both 1D or both 2D."
            )

        # 1. Check if longitudes are in 0 to 360 range
        if np.nanmax(lon_2d) > 180 and np.nanmin(lon_2d) >= 0:
            logger.info("Longitude range is [0, 360]: converting to [-180, 180]")
            lon_2d = np.where(lon_2d > 180, lon_2d - 360, lon_2d)

            # 2. Sort longitudes and rearrange data
            sort_idx = np.argsort(lon_2d[0, :])
            lon_2d = lon_2d[:, sort_idx]
            lat_2d = lat_2d[:, sort_idx]
            data4plot = self.data[:, sort_idx]
            mod_coordinates = True
        else:
            logger.info("Default mode:")
            data4plot = self.data
            mod_coordinates = False

        # -- Replace NaN values:
        # data4plot = np.nan_to_num(data, nan = self._nanvals)

        # -- Apply land/ocean mask:
        data4plot = self.get_mask(
            lon_2d, lat_2d, data4plot, mask_active=self.land_sea_mask)

        # -- Depending on plot type, use different settings:
        if self.plot_type in self.types_2d_plots:
            if self.plot_type == 'time_collage':
                # -- Compute normalization for main data and colormap key:
                norm, cmap_key_numeric = self._compute_norm_for_plot(data4plot)

                # -- Preprocess all difference data to compute global diff_norm:
                diff_norm = None
                all_diff_values = []
                for t in range(len(self.time)):
                    if len(data4plot[t]) == diff_datasets_lim:
                        masked1 = np.ma.masked_invalid(data4plot[t][0])
                        masked2 = np.ma.masked_invalid(data4plot[t][1])
                        diff_data = masked1 - masked2
                        diff_data = diff_data.filled(np.nan)
                        all_diff_values.append(diff_data.flatten())
                if all_diff_values:
                    all_diff_values = np.concatenate(all_diff_values)
                    diff_norm, cmap_key_numeric_diff = self._compute_norm_from_percentile(
                        all_diff_values, diverging=True)

                # -- Collage plot based on time steps (convert time to correct format):
                self.time = [
                    datetime.strptime(ts, orig_time_form).strftime(new_time_form)
                    for ts in self.time
                ]

                logger.info(f"Actual time steps: {self.time}")
                for t in range(len(self.time)):
                    numb_datasets = len(data4plot[t])
                    logger.info(f'Time step {t}, total datasets: {numb_datasets}')
                    # -- Define automatically data chunks (12 datasets per chunk)
                    for chunk_idx, start_idx in enumerate(range(0, numb_datasets, self.subplot_chunk_size)):
                        end_idx = min(start_idx + self.subplot_chunk_size, numb_datasets)
                        chunk_data = data4plot[t][start_idx:end_idx]
                        chunk_names = self.ds_names[start_idx:end_idx]
                        # -- Add difference plot if only two dataset were used:
                        if numb_datasets == diff_datasets_lim and chunk_idx == diff_chunk_lim:
                            masked1 = np.ma.masked_invalid(chunk_data[0])
                            masked2 = np.ma.masked_invalid(chunk_data[1])
                            diff_data = masked1 - masked2
                            diff_data = diff_data.filled(np.nan)
                            chunk_data = list(chunk_data)
                            chunk_data.append(diff_data)
                            chunk_names = list(chunk_names)
                            chunk_names.append('Difference (ds1 - ds2)')

                        # -- Determine subplot layout per chunk:
                        type_of_subplots = self._get_subplots(chunk_names, self.domain_type)
                        # -- Initialize Map Settings and Projection per chunk:
                        self._user_maps_functions = Map_settings(
                            self.cfg_maps._get_map_setting,
                            type_of_subplots,
                            self._map_settings_all,
                            self.domain_type,
                        )
                        cart_projection_act = self._user_maps_functions._get_current_projection(self.domain_type)
                        logger.info(
                            f'Time {t}, Chunk {chunk_idx+1} ({len(chunk_data)} maps) → {type_of_subplots}')

                        # -- Create visualization:
                        self._user_maps_functions._time_collage_2d_map(
                            lon_2d = lon_2d, lat_2d = lat_2d,                  # longitute (2d) and latitude (2d)
                            data4plot = chunk_data,                            # chunk icon data (2d) - with corrections
                            ds_names = chunk_names,                            # chunk dataset names
                            time = self.time[t],                               # time steps
                            title = self.title,                                # dataset titles
                            label = self.label,                                # dataset labels
                            norm = norm,                                       # normalized values for colorbar
                            cart_projection_act = cart_projection_act,         # projection
                            pout = self.pout,                                  # output name
                            chunk_size = f'chunk_{chunk_idx+1}',               # actual chunk pull (index)
                            diff_norm=diff_norm,                               # normalized values for diff colorbar
                            modif_coord=mod_coordinates,
                            colormap_key_main=self.key4colormap,               # Colormap key based on input variable
                            colormap_key_reserve= cmap_key_numeric,            # Colormap key based on values
                        )
            else:
                # -- Case of collage and single options (simplified versions):
                # -- Compute collorbar limits:
                norm, cmap_key_numeric = self._compute_norm_for_plot(data4plot)

                # -- Get correct type_of_subplots:
                data_for_subplots = self.data if self.plot_type == 'collage' else [self.data]
                type_of_subplots = self._get_subplots(
                    self.ds_names, self.domain_type, data_for_subplots)

                # -- Initialization:
                self._user_maps_functions = Map_settings(
                    self.cfg_maps._get_map_setting,
                    type_of_subplots,
                    self._map_settings_all,
                    self.domain_type,
                )
                cart_projection_act = self._user_maps_functions._get_current_projection(self.domain_type)
                logger.info(f"Subplots = {type_of_subplots}")

                # -- Shared arguments for both plot types:
                shared_args = {
                    # -- Longitute (2d), Latitude (2d), ICON data (2d) - with corrections:
                    "lon_2d": lon_2d, "lat_2d": lat_2d, "data4plot": data4plot,
                    # -- Dataset title, labels, normolized values for colorbar (norm):
                    "title": self.title, "label": self.label, "norm": norm,
                    # -- Projection, output path + filename:
                    "cart_projection_act": cart_projection_act, "pout": self.pout,
                    # -- Modify coordinates, Main colormap key (based on names)
                    "modif_coord": mod_coordinates, "colormap_key_main": self.key4colormap,
                    # -- Colormap key based on values (reserve):
                    "colormap_key_reserve": cmap_key_numeric,
                }
                # -- Create visualization
                if self.plot_type == 'collage':
                    self._user_maps_functions._collage_2d_map(
                        # -- Collection, Raw ICON data (2d) and Time (1d, max 12 steps):
                        **shared_args, data = self.data, time = self.time)
                elif self.plot_type == 'single_map':
                    self._user_maps_functions._single_2d_map(**shared_args)

        else:
            raise TypeError(
                f"Invalid 'plot_type' = '{self.plot_type}'. Supported types: {self.types_2d_plots}")


class Taylor_plot:
    @log_function_name
    def __init__(self, config_paths: Dict[str, Union[None, str]],) -> None:
        """
        Initializes the Taylor_plot class by loading configuration, extracting
        plot parameters, and computing global settings for normalization across
        subplots.
        """
        # -- Local variables:
        self.class_name = self.__class__.__name__  # Class name

        self.taylor_vis = TaylorDiagram
        # -- Initialization of user configuration methods
        configurator = Config_class()
        # -- Load path to YAML configuration file:
        taylor_path = (
            os.path.abspath(os.path.expanduser(config_paths["TAYLORCONFIG"]))
            if config_paths["TAYLORCONFIG"] is not None else None
        )
        if taylor_path:
            logger.info(
                "User-defined TAYLOR configuration detected.\n"
                f"Configuration file path: {taylor_path}"
            )
            self.taylor_configuration = configurator.load_yaml_configs(taylor_path)
        else:
            raise ValueError("User-defined TAYLOR configuration is not detected")

        # -- Load common settings based on user configuration:
        # -- Configuration settins (Reference std, samples):
        self.stdrefs = self.taylor_configuration.get('stdrefs')
        self.samples = self.taylor_configuration.get('samples')
        # -- Figure settings:
        self.plt_figzise = self.taylor_configuration.get('figsize')
        # -- Plot settings (Common):
        figure_params = self.taylor_configuration.get('figure_params')
        if figure_params is None:
            raise KeyError("'figure_params' is missing in the configuration of GUI Taylor form")
        self.plt_save_format = figure_params.get('save_format')
        self.plt_save_dpi = figure_params.get('save_dpi')
        self.plt_save_filename = figure_params.get('save_filename')
        # -- Plot settings (legend):
        self.plt_legend_loc = figure_params.get('legend_loc')
        self.plt_legend_numpoints = figure_params.get('legend_numpoints')
        self.plt_legend_fontsize = figure_params.get('legend_fontsize')
        # -- Plot settings (contour):
        self.plt_contour_levels = figure_params.get('contour_levels')
        self.plt_contour_linecolor = figure_params.get('contour_linecolor')
        self.plt_contour_inline = figure_params.get('contour_inline')
        self.plt_contour_fontsize = figure_params.get('contour_fontsize')
        self.plt_contour_fmt = figure_params.get('contour_fmt')
        # -- Plot settings (title):
        self.plt_title = self.taylor_configuration.get('subtitle')
        self.plt_tsize = self.taylor_configuration.get('title_fsize')
        # -- Plot settings (markers and colors):
        self.plt_marker_mode = self.taylor_configuration.get('marker_mode')
        self.plt_marker_size = self.taylor_configuration.get('marker_size')
        self.plt_marker_colors = self.taylor_configuration.get('marker_colors')
        if self.plt_marker_mode == 'text':
            self.plt_marker_fmt = self.taylor_configuration.get('marker_fmt')
            self.plt_marker_shape = None
        else:
            self.plt_marker_fmt = None
            self.plt_marker_shape = self.taylor_configuration.get('marker_shapes')
        # -- Compute global max std for normalization:
        all_stddevs = [self.stdrefs[season] for season in self.stdrefs]
        for season_samples in self.samples.values():
            all_stddevs.extend([s[0] for s in season_samples])
        self.global_max_std = max(all_stddevs)

    @log_function_name
    def taylor_clim(self) -> None:
        """
        Draw separate climatology-oriented Taylor diagrams per season using
        independent figures
        """
        for season in self.stdrefs:
            stdref = self.stdrefs[season]
            samples = self.samples.get(season)
            if samples is None:
                raise ValueError(f"Missing samples for season '{season}'")

            fig = plt.figure(figsize=self.plt_figzise)
            # Figure title:
            fig.suptitle(self.plt_title, size = self.plt_tsize)
            # -- Create diagram:
            dia = self.taylor_vis(stdref, fig=fig, label='Reference', extend=True)
            # -- Mark reference point as a red star:
            dia.samplePoints[0].set_color('r')
            # Add models to Taylor diagram
            for i, (stddev, corrcoef, name) in enumerate(samples):
                # -- Select markers form:
                if self.plt_marker_mode == "text":
                    marker = self.plt_marker_fmt % (i + 1)
                elif self.plt_marker_mode == "shape":
                    marker = self.plt_marker_shape[i % len(self.plt_marker_shape)]
                else:
                    raise ValueError('Check plt_marker_mode value')
                # -- Add data to the figure:
                dia.add_sample(
                    stddev,
                    corrcoef,
                    marker = marker,
                    ms = self.plt_marker_size,
                    ls='',
                    mfc = self.plt_marker_colors[i],
                    mec = self.plt_marker_colors[i],
                    label = name,
                )
            # -- Add RMS contours, and label them:
            contours = dia.add_contours(
                levels = self.plt_contour_levels,
                colors = str(self.plt_contour_linecolor),
            )
            dia.ax.clabel(
                contours,
                inline = self.plt_contour_inline,
                fontsize = self.plt_contour_fontsize,
                fmt = self.plt_contour_fmt,
            )
            # -- Add grid:
            dia.add_grid()
            # -- Put ticks outward:
            dia._ax.axis[:].major_ticks.set_tick_out(True)
            # -- Special location for legend:
            if self.plt_legend_loc == 'center':
                legend_loc = 'upper right'
            else:
                legend_loc = self.plt_legend_loc
            # -- Add a figure legend and title. For loc option, place x,y tuple inside [ ]
            dia.ax.legend(
                dia.samplePoints,
                [p.get_label() for p in dia.samplePoints],
                numpoints = self.plt_legend_numpoints,
                prop = dict(size = self.plt_legend_fontsize),
                loc = legend_loc,
            )
            # -- Save figure:
            plt.savefig(
                f"{self.plt_save_filename}_{season}.{self.plt_save_format}",
                format = self.plt_save_format,
                dpi = self.plt_save_dpi,
            )

    @log_function_name
    def taylor_clim_season(self) -> None:
        """
        Draw a single multi-panel Taylor diagram for all seasons with unified axes.
        """
        # -- Local variables:
        # -- Significance levels (standard deviation x and y axis):
        signific_level_95 = self.taylor_configuration.get('significance_lines').get('95')
        signific_level_99 = self.taylor_configuration.get('significance_lines').get('99')
        x95, x99 = signific_level_95.get('x'), signific_level_99.get('x')
        y95, y99 = signific_level_95.get('y'), signific_level_99.get('y')

        # -- Original Y max from significance lines
        original_ymax = max(max(y95), max(y99))
        scale_factor = self.global_max_std / original_ymax if original_ymax else 1
        y95_scaled = [y * scale_factor for y in y95]
        y99_scaled = [y * scale_factor for y in y99]
        # -- Subplots locations:
        rects = self.taylor_configuration.get('rects')
        # -- Create plot:
        fig = plt.figure(figsize=self.plt_figzise)
        fig.suptitle(self.plt_title, size = self.plt_tsize)
        # -- Cycle over keys in samples
        for season in sorted(self.samples.keys()):
            # -- Run Taylor diagram:
            dia = self.taylor_vis(
                self.stdrefs[season],
                fig=fig,
                rect=rects[season],
                label='Reference',
                srange=(0, self.global_max_std / self.stdrefs[season]),
            )
            # -- Add lines indicating the 95% and 99% significance thresholds:
            dia.ax.plot(x95, y95_scaled, color='k', linestyle=':')
            dia.ax.plot(x99, y99_scaled, color='k', linestyle=':')
            # -- Add samples to Taylor diagram
            for i, (stddev, corrcoef, name) in enumerate(self.samples[season]):
                # -- Select markers form:
                if self.plt_marker_mode == "text":
                    marker = self.plt_marker_fmt % (i + 1)
                elif self.plt_marker_mode == "shape":
                    marker = self.plt_marker_shape[i % len(self.plt_marker_shape)]
                else:
                    raise ValueError('Check plt_marker_mode value')
                # -- Add data to the figure:
                dia.add_sample(
                    stddev,
                    corrcoef,
                    marker = marker,
                    ms = self.plt_marker_size,
                    ls = '',
                    mfc = self.plt_marker_colors[i],
                    mec = self.plt_marker_colors[i],
                    label = name,
                )
            # -- Add RMS contours, and label them:
            contours = dia.add_contours(
                levels = self.plt_contour_levels,
                colors = str(self.plt_contour_linecolor),
            )
            dia.ax.clabel(
                contours,
                inline = self.plt_contour_inline,
                fontsize = self.plt_contour_fontsize,
                fmt = self.plt_contour_fmt,
            )
            # Tricky: ax is the polar ax (used for plots), _ax is the
            # container (used for layout)
            dia._ax.set_title(season.capitalize())
        # -- Add a figure legend and title. For loc option, place x,y tuple inside [ ]
        fig.legend(
            dia.samplePoints,
            [p.get_label() for p in dia.samplePoints],
            numpoints = self.plt_legend_numpoints,
            prop = dict(size = self.plt_legend_fontsize),
            loc = self.plt_legend_loc,
        )
        # -- Save figure:
        plt.savefig(
            f"{self.plt_save_filename}.{self.plt_save_format}",
            format = self.plt_save_format,
            dpi = self.plt_save_dpi,
        )
