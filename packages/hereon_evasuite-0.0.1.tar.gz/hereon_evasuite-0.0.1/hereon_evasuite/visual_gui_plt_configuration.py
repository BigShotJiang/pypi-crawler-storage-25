# EvaSuite
#
# ---------------------------------------------------------------
# Copyright (C) 2004-2025, Hereon
# Contact information: beate.geyer@hereon.de, imktro-climate-modelling@lists.kit.edu
# See AUTHORS.TXT for a list of authors
# See LICENSES/ for license information
# SPDX-License-Identifier: Apache-2.0
# ---------------------------------------------------------------

# ---------------------------------------------------------------
#    Program description:
#    User GUI form for creating a YAML configuration file for 1D plot settings.
#
#    Main functionality:
#       - Allows the user to configure general plot options, grid, axes, line/marker/bar styles, and subplot layouts.
#       - Detects which fields have been modified by the user and highlights them.
#       - Supports saving either only modified settings or the full default configuration.
#       - Includes context-sensitive help ("?") buttons explaining each parameter group.
#
#    Available Methods:
#    ------------------
#    1. __init__(self, root)
#          Initializes the GUI layout, loads default settings, and builds all frames with scrollbars and controls.
#
#    2. create_entry(self, parent, label, default, row)
#          Creates a labeled input field (Entry) for a parameter with default value handling and change detection.
#
#    3. toggle_grid_fields(self)
#          Enables or disables the grid-related input fields based on the 'Grid Add' checkbox state.
#
#    4. toggle_subplot_params(self, option)
#          Enables or disables the input fields for a selected subplot configuration based on the associated checkbox.
#
#    5. on_user_edit_general(self, entry, key)
#          Detects changes in general parameter fields and updates their color to indicate modification.
#
#    6. on_user_edit_subplot(self, entry, param, option)
#          Detects changes in subplot parameter fields and updates their color to indicate modification.
#
#    7. save_settings(self)
#          Saves only the modified (user-edited) settings into a YAML file. Cleans and parses inputs before saving.
#
#    8. save_defaults_to_yaml(self)
#          Saves the full current configuration (including defaults) into a YAML file for later reuse or comparison.
#
#    9. debug_compare_with_defaults(self)
#          Compares the current GUI state with the default configuration and prints mismatches for debugging purposes.
#
#    10. show_info(self, section=None)
#          Displays help information for the selected parameter group (general, grid, axes, subplots, etc.).
#
#    11. pad_to_limit(self, value, default=None)
#          Pads list-type parameter values to the configured maximum length using the default repeat value if available.
#
#    12. is_list_parameter(self, key)
#          Determines whether a given parameter should be treated as a list and padded.
#
#    13. parse_value(self, key, value)
#          Parses input values safely: handles numbers, strings, lists, and automatic type detection.
#
#    14. _convert_to_number_or_lower(self, value)
#          Converts a value to int or float if possible, otherwise returns the lowercase string.
#
#    15. restore_default_values(self)
#          Restore default values in GUI form
#
#    16. load_special_1d_limits_csv(self)
#          Load CSV file with use min and max values for different parameters
#
#    History:
#    Version    Date       Name
#    ---------- ---------- ----
#    1.1        04.2025   Evgenii Churiulin, IMKTRO
#                         Initial realise
# ---------------------------------------------------------------
# -- Import Python modules:
import tkinter as tk
import pandas as pd
import io
import yaml
from tkinter import ttk, filedialog, messagebox
from typing import Any, Optional

# -- Import user map_settings:
from hereon_evasuite.visual_config import Builder_plots_config


class Plot1DSettingsGUI:
    """
    GUI tool for configuring and exporting 1D plot visualization settings.

    Features:
    ---------
    - Interactive form for setting general plot options, grid, line/marker/bar styles, axes, and subplots.
    - Supports list-based parameters with automatic padding to the configured limit.
    - Detects user modifications and highlights changed fields.
    - Allows saving only modified settings or exporting the full default configuration.
    - Includes contextual help ("?") buttons explaining each parameter group.

    Purpose:
    --------
    Designed to simplify the process of generating YAML configuration files
    for 1D plots, ensuring consistency and user-friendly editing of visualization parameters.
    """

    def __init__(self, root: tk.Tk) -> None:
        """
        Initialize the 1D Plot Settings GUI.

        This function builds the full GUI layout including:
        ----------------------------
        - Scrollable main frame.
        - Parameter input sections for general, main line/marker/bar, grid, X axis, Y axis.
        - Subplot configuration section with checkboxes and entry fields.
        - Buttons for saving, debugging, and exporting settings.

        Parameters:
        -----------
        root : tk.Tk
            The root Tkinter window object.
        """
        # -- Configuration setup:
        self.__lim_len_var = 21  # Max number of lines/markers/bars
        # -- Load default EvaSuite setups:
        plot_conf = Builder_plots_config()
        plot_settings = plot_conf._build_plot1d_settings().values
        plot_conf._control_user_settings(plot_settings)
        # -- Store defaults for later comparison:
        self.general_defaults = plot_settings
        # -- Default background color (unchanged fields)
        self.form_color_default = 'lightgray'
        # -- # Modified field background color
        self.form_color_modif = 'white'

        self.root = root
        self.root.title("1D Plot Settings Generator")

        # -- Scrollable frame setup:
        self.canvas = tk.Canvas(self.root, borderwidth=0, width=1200, height=800)
        self.frame = ttk.Frame(self.canvas)
        self.vsb = tk.Scrollbar(self.root, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=self.vsb.set)
        self.hsb = tk.Scrollbar(self.root, orient="horizontal", command=self.canvas.xview)
        self.canvas.configure(xscrollcommand=self.hsb.set)
        self.vsb.pack(side="right", fill="y")
        self.hsb.pack(side="bottom", fill="x")
        self.canvas.pack(side="left", fill="both", expand=True)
        self.canvas_window = self.canvas.create_window((0, 0), window=self.frame, anchor="nw")
        self.frame.bind("<Configure>", lambda event: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        # -- Initialize storage for entry widgets:
        self.entries = {}

        # -- Parameter groups definition:
        general_parameters = [
            'plt_title_color', 'plt_labels_color', 'plt_llegend', 'plt_minor_locator',
            'plt_lsave', 'plt_format', 'plt_dpi'
        ]
        self.main_parameters = [
            'vplt_colors', 'vplt_ln_styles', 'vplt_ln_widths', 'vplt_alphas',
            'vplt_mkr_color', 'vplt_mkr_size', 'vplt_mkr_style',
            'vplt_bar_hatch', 'vplt_bar_widths'
        ]

        grid_parameters = [
            'plt_gtype', 'plt_gclr', 'plt_gstyle', 'plt_galpha'
        ]
        x_axis_parameters = [
            'plt_num_x_axis', 'plt_time_x_axis', 'plt_ftime',
            'plt_day_locator', 'plt_l_xrotation', 'plt_x_unit_color'
        ]
        y_axis_parameters = [
            'plt_l_yrotation', 'plt_y_rotation', 'plt_y_unit_size',
            'plt_y_unit_color', 'plt_lextra_axis'
        ]
        special_parameters = [
            'plts_title', 'plts_subtitle', 'plts_min_values', 'plts_max_values']

        # -- Build parameter group frames:
        self.build_group_frame(
            "General Plot Settings",
            general_parameters,
            plot_settings,
            0,
            info_button=True
        )
        # -- Warning label under Special Parameters
        warning_label = tk.Label(
            self.frame,
            text="Don't change 'Special Parameters' group without understanding what they are doing. See more information in help.",
            fg="red",
            wraplength=1000,
            justify="left"
        )
        warning_label.grid(row=1, column=0, sticky="w", padx=10, pady=(0, 10))
        self.build_group_frame(
            "Special Parameters",
            special_parameters,
            plot_settings,
            2,
            info_button=True
        )
        # -- Add CSV import button for plts_min/max_values
        self.load_csv_1d_button = tk.Button(
            self.frame,
            text="Load CSV for plts_min/max_values",
            command=self.load_special_1d_limits_csv,
            bg="#e1f5fe"
        )
        self.load_csv_1d_button.grid(row=2, column=1, sticky="e", padx=10, pady=(0, 5))

        self.build_group_frame(
            "Main Line/Marker/Bar Settings",
            self.main_parameters,
            plot_settings,
            3,
            info_button=True
        )
        self.build_grid_frame(
            "Grid Settings",
            grid_parameters,
            plot_settings,
            4,
            info_button=True,
        )
        self.build_group_frame(
            "X Axis Settings",
            x_axis_parameters,
            plot_settings,
            5,
            info_button=True,
        )
        self.build_group_frame(
            "Y Axis Settings",
            y_axis_parameters,
            plot_settings,
            6,
            info_button=True,
        )
        # -- Subplot options frame:
        self.default_subplot_values = plot_settings.get('subplots')
        self.subplot_frame = ttk.LabelFrame(self.frame, text="Subplot Options")
        self.subplot_frame.grid(row=7, column=0, sticky="nsew", padx=10, pady=5)
        # -- Add info button for subplot section:
        btn = tk.Button(
            self.subplot_frame,
            text="?",
            command=lambda: self.show_info(section="subplots"),
        )
        btn.grid(row=0, column=len(self.default_subplot_values) + 1, padx=5, pady=2)

        self.subplot_vars = {}
        self.subplot_param_entries = {}

        subplot_options = list(self.default_subplot_values.keys())
        subplot_params = list(self.default_subplot_values[subplot_options[0]].keys())

        # --- Subplot checkboxes and parameter entries ---
        # This block creates:
        # 1. A checkbox for each subplot layout option ('single', 'r1c4', 'r2c4', etc.).
        # 2. Corresponding parameter input fields (entries) for each option.
        # 3. Each parameter entry is disabled by default and activated only if the checkbox is selected.
        for idx, option in enumerate(subplot_options):
            # -- Create a BooleanVar for the checkbox state of this subplot option:
            # -- All checkboxes are OFF by default:
            var = tk.BooleanVar(value=False)
            # -- Create the checkbox for activating/deactivating this subplot option:
            chk = ttk.Checkbutton(
                self.subplot_frame,
                # -- Label text (e.g., 'single', 'r1c4', etc.):
                text=option,
                # -- Connect to the BooleanVar:
                variable=var,
                # -- Enable/disable fields on toggle:
                command=lambda opt=option: self.toggle_subplot_params(opt)
            )
            # -- Position checkbox in the first row:
            chk.grid(row=0, column=idx)
            # -- Store the checkbox variable for later access:
            self.subplot_vars[option] = var
            self.subplot_param_entries[option] = {}
            # -- Create entry fields for each parameter of this subplot option:
            for p_idx, param in enumerate(subplot_params):
                # -- Only add labels for parameter names once (in the first column):
                if idx == 0:
                    label = tk.Label(self.subplot_frame, text=f"{param}:")
                    label.grid(row=p_idx + 1, column=0, sticky="e")
                # --- Create entry widget for this parameter
                entry = tk.Entry(self.subplot_frame, bg=self.form_color_default, fg='black')
                # --- Insert default value into the entry field
                default_value = self.default_subplot_values[option].get(param)
                if isinstance(default_value, list) and len(set(default_value)) == 1:
                    entry.insert(0, str(default_value[0]))
                else:
                    entry.insert(0, str(default_value))
                # --- Place the entry field in the grid
                entry.grid(row=p_idx + 1, column=idx + 1, padx=(5, 15))
                # --- Disable entry by default (will be enabled only if checkbox is selected)
                entry.configure(state='disabled')
                # --- Add event binding to detect user modifications in this entry
                entry.bind(
                    "<KeyRelease>",
                    lambda event,
                    e=entry,
                    param=param,
                    opt=option: self.on_user_edit_subplot(e, param, opt)
                )
                self.subplot_param_entries[option][param] = entry
        # -- Button (SAVE):
        self.save_button = tk.Button(
            self.frame,
            text="Save Settings as YAML",
            command=self.save_settings,
        )
        self.save_button.grid(row=8, column=0, pady=10)
        # -- Button (DEBUG):
        self.debug_button = tk.Button(
            self.frame,
            text="DEBUG: Compare with Defaults",
            command=self.debug_compare_with_defaults,
        )
        self.debug_button.grid(row=9, column=0, pady=10)
        # -- Button (EXPORT):
        self.export_defaults_button = tk.Button(
            self.frame,
            text="Export Default Configuration",
            command=self.save_defaults_to_yaml,
        )
        self.export_defaults_button.grid(row=10, column=0, pady=10)
        # -- Button (RESTORE):
        self.restore_defaults_button = tk.Button(
            self.frame,
            text="Restore Default Configuration",
            command=self.restore_default_values,
            bg="#ffe0e0",  # optional: light red to show it's a reset action
        )
        self.restore_defaults_button.grid(row=11, column=0, pady=10)
        # -- Initial grid toggle:
        self.toggle_grid_fields()

    def build_group_frame(
        self,
        title: str,
        parameters: list[str],
        settings: dict[str, Any],
        row_idx: int,
        info_button: bool = False,
    ) -> None:
        """
        Build a labeled frame for a specific group of plot parameters.

        Parameters:
        -----------
        title : str
            The title of the section (e.g., "General Plot Settings", "X Axis Settings").
        parameters : list of str
            A list of parameter names to create entry fields for.
        settings : dict
            The configuration dictionary containing default values for each parameter.
        row_idx : int
            The grid row index at which to place this group in the main GUI layout.
        info_button : bool, optional
            Whether to include an info ("?") button that shows help for this section (default: False).
        """
        # -- Create the labeled frame for the group:
        frame = ttk.LabelFrame(self.frame, text=title)
        frame.grid(row=row_idx, column=0, sticky="nsew", padx=10, pady=5)
        # -- Create entry fields for each parameter in the group:
        for idx, param in enumerate(parameters):
            self.create_entry(frame, param, settings.get(param), idx)
        # -- Add section-specific info ("?") button if requested:
        if info_button:
            if title == "General Plot Settings":
                btn = tk.Button(
                    frame, text="?", command=lambda: self.show_info(section="general"))
            elif title == "Special Parameters":
                btn = tk.Button(
                    frame, text="?", command=lambda: self.show_info(section="special"))
            elif title == "Main Line/Marker/Bar Settings":
                btn = tk.Button(
                    frame, text="?", command=lambda: self.show_info(section="main_parameters"))
            elif title == "Grid Settings":
                btn = tk.Button(
                    frame, text="?", command=lambda: self.show_info(section="grid"))
            elif title == "X Axis Settings":
                btn = tk.Button(
                    frame, text="?", command=lambda: self.show_info(section="x_axis"))
            elif title == "Y Axis Settings":
                btn = tk.Button(
                    frame, text="?", command=lambda: self.show_info(section="y_axis"))
            else:
                btn = tk.Button(
                    frame, text="?", command=self.show_info)
            btn.grid(row=0, column=2, padx=5, pady=2)

    def build_grid_frame(
        self,
        title: str,
        parameters: list[str],
        settings: dict[str, Any],
        row_idx: int,
        info_button: bool = False,
    ) -> None:
        """
        Build the 'Grid Settings' section of the GUI.

        Parameters:
        -----------
        title : str
            The title of the section (usually "Grid Settings").
        parameters : list of str
            The list of grid-related parameter names to create entry fields for.
        settings : dict
            The current configuration dictionary containing default values.
        row_idx : int
            The row index at which to place this section in the main grid layout.
        info_button : bool, optional
            Whether to include an info ("?") button explaining grid parameters (default: False).
        """
        # -- Create the grid settings frame:
        frame = ttk.LabelFrame(self.frame, text=title)
        frame.grid(row=row_idx, column=0, sticky="nsew", padx=10, pady=5)
        # -- Add 'Grid Add' checkbox (controls whether grid settings are active):
        self.lgrid_var = tk.BooleanVar(value=settings.get('plt_lgrid', True))
        grid_check = ttk.Checkbutton(
            frame,
            text="Grid Add",
            variable=self.lgrid_var,
            # -- Enable/disable fields when checkbox is toggled
            command=self.toggle_grid_fields,
        )
        grid_check.grid(row=0, column=0, columnspan=2)
        # -- Create entry fields for each grid parameter:
        self.grid_entries = []
        for idx, param in enumerate(parameters, start=1):
            value = settings.get(param)
            self.grid_entries.append(self.create_entry(frame, param, value, idx))
        # -- Add info ("?") button if requested:
        if info_button:
            if title == "Grid Settings":
                btn = tk.Button(
                    frame,
                    text="?",
                    command=lambda: self.show_info(section="grid"))
            else:
                btn = tk.Button(frame, text="?", command=self.show_info)
            btn.grid(row=0, column=2, padx=5, pady=2)

    def load_special_1d_limits_csv(self) -> None:
        """
        Load a CSV with 'title', 'vmin', 'vmax' columns and populate:
            - plts_min_values
            - plts_max_values

        Updates the corresponding GUI fields with clean YAML-style output.
        """
        file_path = filedialog.askopenfilename(filetypes=[("CSV files", "*.csv")])
        if not file_path:
            return

        try:
            df = pd.read_csv(file_path)
            df.columns = [col.strip().lower() for col in df.columns]
            required_cols = {'title', 'vmin', 'vmax'}
            if not required_cols.issubset(df.columns):
                messagebox.showerror("Invalid CSV", "CSV must contain 'title', 'vmin', and 'vmax' columns.")
                return

            # Store limits as dictionaries
            self.special_limits_data = {
                'plts_min_values': {},
                'plts_max_values': {},
            }

            for _, row in df.iterrows():
                title = str(row['title']).strip()
                try:
                    vmin = float(row['vmin']) if str(row['vmin']).strip().lower() != 'none' else None
                    vmax = float(row['vmax']) if str(row['vmax']).strip().lower() != 'none' else None
                except ValueError:
                    messagebox.showerror("Invalid Value", f"Non-numeric vmin/vmax for title: {title}")
                    return

                self.special_limits_data['plts_min_values'][title] = vmin
                self.special_limits_data['plts_max_values'][title] = vmax

            # Insert YAML-formatted content into GUI entries
            for key in ['plts_min_values', 'plts_max_values']:
                if key in self.entries:
                    stream = io.StringIO()
                    yaml.dump(self.special_limits_data[key], stream, default_flow_style=False, sort_keys=False)
                    yaml_string = stream.getvalue().strip()
                    self.entries[key].delete(0, tk.END)
                    self.entries[key].insert(0, yaml_string)
                    self.entries[key].configure(bg=self.form_color_modif, fg='black')

            messagebox.showinfo("Success", "Limits from CSV successfully loaded and formatted.")

        except Exception as e:
            messagebox.showerror("Error", f"Failed to load CSV: {str(e)}")

    def create_entry(
        self,
        parent: tk.Widget,
        label: str,
        default: Any,
        row: int,
    ) -> tk.Entry:
        """
        Create a labeled entry field for a given parameter.

        Parameters:
        -----------
        parent : tk.Widget
            The parent widget (usually a frame) where the entry will be placed.
        label : str
            The name of the parameter (used both as label text and as a key for storing the entry).
        default : Any
            The default value to display in the entry field (can be a scalar or a list).
        row : int
            The row index for placing this entry in the grid layout of the parent widget.

        Returns:
        --------
        entry : tk.Entry
            The created entry widget (reference stored for later use).
        """
        # --- Create the label widget for the entry field
        label_widget = tk.Label(parent, text=label + ":")
        label_widget.grid(row=row, column=0, sticky="w", padx=(5, 2), pady=2)
        # --- Create the entry widget
        entry = tk.Entry(parent, bg=self.form_color_default, fg='gray')
        # --- Insert the default value into the entry field
        if isinstance(default, list) and len(set(default)) == 1:
            entry.insert(0, str(default[0]))
        else:
            entry.insert(0, str(default))
        # --- Place the entry field in the grid layout
        entry.grid(row=row, column=1, sticky="ew", padx=(2, 5), pady=2)
        # --- Allow column 1 (entry field column) to expand horizontally
        parent.grid_columnconfigure(1, weight=1)
        # --- Store the entry reference in the entries dictionary for later access
        self.entries[label] = entry
        # --- Bind the entry field to detect user edits (for background color change logic)
        entry.bind(
            "<KeyRelease>",
            lambda event, e=entry, key=label: self.on_user_edit_general(e, key)
        )
        return entry

    def on_user_edit_general(self, entry: tk.Entry, key: str) -> None:
        """
        Detects changes made by the user in general input fields and updates their appearance.

        This function compares the current value of an entry field against its default value.
        - If the user has modified the value → the field background is set to white and text color to black.
        - If the value matches the default → the background is reset to gray and text color to gray.

        Parameters:
        -----------
        entry : tk.Entry
            The entry widget being edited.
        key : str
            The parameter name (used to fetch the default value from general_defaults).
        """
        # --- Retrieve the default value for this parameter
        default_value = self.general_defaults.get(key)
        # --- Read the current user input from the entry field
        current_value = entry.get().strip()
        # --- Compare the current input with the default value
        if str(current_value) != str(default_value):
            # User has modified the value → highlight field as "edited"
            entry.configure(bg=self.form_color_modif, fg='black')
        else:
            # Value matches default → reset field appearance to "default"
            entry.configure(bg=self.form_color_default, fg='gray')

    def on_user_edit_subplot(self, entry: tk.Entry, param: str, option: str) -> None:
        """
        Detects changes made by the user in subplot parameter fields and updates their appearance.

        This function compares the current value of a subplot entry field against its default value.
        - If the user modifies the field → the background is set to white and text color to black.
        - If the value matches the default → the background is reset to gray and text color to gray.

        Handles both scalar defaults and lists where all elements are identical.

        Parameters:
        -----------
        entry : tk.Entry
            The entry widget being edited.
        param : str
            The subplot parameter name (e.g., 'plt_size', 'plt_nrows').
        option : str
            The subplot configuration option (e.g., 'single', 'r1c4', 'r2c4').
        """
        # --- Retrieve the default value for this subplot parameter
        default_value = self.default_subplot_values.get(option, {}).get(param)
        # -- If the default is a list with all the same values, simplify it:
        if isinstance(default_value, list) and len(set(default_value)) == 1:
            default_value = default_value[0]
        # --- Read the current user input from the entry field
        current_value = entry.get().strip()
        if str(current_value) != str(default_value):
            entry.configure(bg=self.form_color_modif, fg='black')
        else:
            entry.configure(bg=self.form_color_default, fg='gray')

    def toggle_grid_fields(self) -> None:
        """
        Enable or disable the grid-related entry fields based on the 'Grid Add' checkbox state.

        - If the 'Grid Add' checkbox (lgrid_var) is checked → fields are enabled (normal).
        - If unchecked → fields are disabled (grayed out).
        """
        # -- Determine field state from checkbox (True = normal, False = disabled)
        state = 'normal' if self.lgrid_var.get() else 'disabled'
        # --- Apply the state to all grid parameter entry fields
        for entry in self.grid_entries:
            entry.configure(state=state)

    def toggle_subplot_params(self, option: str) -> None:
        """
        Enable or disable the parameter fields for a specific subplot configuration option.

        Parameters:
        -----------
        option : str
            The subplot option name (e.g., 'single', 'r1c4', 'r2c4').

        Behavior:
        ---------
        - If the checkbox for this subplot option is active (checked) → enable related entry fields.
        - If unchecked → disable related fields.
        - Always reset background color to default (form_color_default) when toggling.
        """
        # --- Check if this subplot option is activated (checkbox selected)
        active = self.subplot_vars[option].get()
        # --- Enable or disable all parameter entry fields for this subplot option
        for param, entry in self.subplot_param_entries[option].items():
            if active:
                entry.configure(state='normal', bg=self.form_color_default)
            else:
                entry.configure(state='disabled', bg=self.form_color_default)

    def pad_to_limit(self, value: Any, default=None) -> list:
        """
        Pads a list-type parameter to the configured maximum length (self.__lim_len_var).

        If the provided value is not already a list, it is converted into a list.
        Padding is applied using the provided 'default' value (if given), otherwise None.

        Parameters:
        -----------
        value : Any
            The input value (scalar or list) to be padded.
        default : Any, optional
            The value used for padding if the list is shorter than the limit (default: None).

        Returns:
        --------
        list
            A list padded to self.__lim_len_var length.
        """
        # --- Ensure the value is a list
        if not isinstance(value, list):
            value = [value]
        # --- Use the provided default for padding, or None if not given
        padding_value = default if default is not None else None
        return value + [padding_value] * (self.__lim_len_var - len(value))

    def is_list_parameter(self, key: str) -> bool:
        """
        Determines whether a given parameter should be treated as a list-type parameter.

        Used to identify which parameters require list padding (like 'colors', 'line_styles', etc.).

        Parameters:
        -----------
        key : str
            The parameter name to check.

        Returns:
        --------
        bool
            True if the parameter should be treated as a list, False otherwise.
        """
        return key in self.main_parameters

    def restore_default_values(self) -> None:
        """
        Resets all GUI fields to their original default values.

        Behavior:
        ---------
        - Overwrites all entries with the defaults from self.general_defaults.
        - Disables all subplot checkboxes and fields.
        - Resets background and text color to default indicators.
        - Resets 'Grid Add' checkbox to its default value.
        """
        special_none_keys = {
            'plts_title', 'plts_subtitle', 'plts_min_values', 'plts_max_values'
        }

        for key, entry in self.entries.items():
            default = self.general_defaults.get(key)
            entry.configure(state='normal')  # In case some entries were disabled

            if key in special_none_keys and default is None:
                entry.delete(0, tk.END)
                entry.insert(0, "None")
                entry._default_none = True
            else:
                entry.delete(0, tk.END)
                entry.insert(0, str(default) if default is not None else "")
            entry.configure(bg=self.form_color_default, fg='gray')

        # Reset 'Grid Add'
        self.lgrid_var.set(self.general_defaults.get('plt_lgrid', True))
        self.toggle_grid_fields()

        # Reset subplot entries
        for option, var in self.subplot_vars.items():
            var.set(False)  # uncheck all
            self.toggle_subplot_params(option)
            for param, entry in self.subplot_param_entries[option].items():
                default_val = self.default_subplot_values.get(option, {}).get(param)
                entry.configure(state='disabled')
                entry.delete(0, tk.END)
                entry.insert(0, str(default_val) if default_val is not None else "")
                entry.configure(bg=self.form_color_default, fg='gray')

        messagebox.showinfo("Defaults Restored", "All settings have been reset to their default values.")

    def parse_value(self, key: str, value: str) -> Any:
        """
        Safely parses the user input from an entry field.

        Behavior:
        ---------
        - For list parameters:
            - Splits values by commas if not using brackets.
            - Supports automatic conversion to numbers or lowercase strings.
            - Handles padding logic outside of this function.
        - For scalar parameters:
            - Converts to int, float, or lowercase string.

        Parameters:
        -----------
        key : str
            The parameter name (used to determine if it should be treated as a list).
        value : str
            The raw string input from the user.
        Returns:
        --------
        Any
            Parsed value as int, float, lowercase string, or list of these.
        """
        # -- Protect against accidental reuse of the parameter name as input value
        if value.lower() == key.lower():
            return None
        # -- Special handling for plts_subtitle to always be list of strings
        if key in ["plts_title","plts_subtitle"]:
            if value.startswith("[") and value.endswith("]"):
                try:
                    parsed = eval(value)
                    return [str(item).strip() for item in parsed]
                except:
                    return [value.strip()]
            else:
                return [v.strip() for v in value.split(",") if v.strip()]
        # -- Handle list-type parameters
        if self.is_list_parameter(key):
            # Split by comma if not using brackets
            if ',' in value and not (value.startswith('[') and value.endswith(']')):
                items = [v.strip() for v in value.split(',')]
            else:
                try:
                    items = eval(value)
                    if not isinstance(items, list):
                        items = [items]
                except:
                    items = [value]
            return [self._convert_to_number_or_lower(item) for item in items]
        else:
            return self._convert_to_number_or_lower(value)

    def _convert_to_number_or_lower(self, value: str) -> Any:
        """
        Attempts to convert a string value into an integer or float.
        If conversion fails, returns the value as a lowercase string.

        Parameters:
        -----------
        value : str
            The input string to convert.

        Returns:
        --------
        int, float, or str
            Parsed number (int or float), or lowercase string if not a number.
        """
        try:
            return int(value)
        except ValueError:
            try:
                return float(value)
            except ValueError:
                return value.lower()

    def save_settings(self) -> None:
        """
        Saves the user-modified plot settings into a YAML configuration file.

        Behavior:
        ---------
        - Only parameters that were changed by the user (white background fields) are saved.
        - Automatically parses values:
            • Converts numerical strings to int or float.
            • Handles list parameters with correct parsing and padding.
            • Pads list-type parameters up to the maximum length (self.__lim_len_var).
              Uses the default repeating value for padding (if available), not None.

        - Subplot options:
            • Saves only active subplot configurations (checkbox enabled).
            • Saves only subplot parameters that were modified by the user.

        Notes:
        ------
        - The background color 'white' (self.form_color_modif) indicates user modification.
        - Unchanged fields (gray background) are skipped to keep the YAML clean.
        - 'lgrid' (Grid Add) is handled separately: saved only if the user changed it from the default.

        Output:
        -------
        Creates a YAML file with only the modified settings.
        Prompts the user to select the output file path via a file dialog.
        """
        settings_to_save = {}
        # -- General settings (only user-edited fields!)
        for key, entry in self.entries.items():
            if entry.cget('bg') == self.form_color_modif:
                value = entry.get().strip()
                # -- Block-style YAML for plts_min_values and plts_max_values
                if key in ['plts_min_values', 'plts_max_values']:
                    try:
                        parsed = yaml.safe_load(value)
                        settings_to_save[key] = parsed
                    except Exception:
                        messagebox.showerror("YAML Error", f"Failed to parse {key} as dictionary.")
                        return
                    continue

                parsed = self.parse_value(key, value)
                # --- Ensure plts_subtitle is always a list
                if key in ["plts_title", "plts_subtitle"]:
                    if not isinstance(parsed, list):
                        parsed = [parsed]
                    elif parsed == []:
                        parsed = [None]
                if key in self.main_parameters and self.is_list_parameter(key):
                    default_value = self.general_defaults.get(key)
                    # -- Detect repeating default value
                    if isinstance(default_value, list) and len(set(default_value)) == 1:
                        default_repeat_value = default_value[0]
                    else:
                        default_repeat_value = None
                    # -- Pad using the default repeat value
                    settings_to_save[key] = self.pad_to_limit(parsed, default=default_repeat_value)
                else:
                    settings_to_save[key] = parsed
            # -- Handle 'lgrid' (Grid Add checkbox) only if user changed it:
            default_lgrid = self.general_defaults.get('plt_lgrid', True)
            current_lgrid = self.lgrid_var.get()
            if current_lgrid != default_lgrid:
                settings_to_save['plt_lgrid'] = current_lgrid

        # -- Subplot section: unchanged logic (no parsing needed here!)
        subplot_data = {}
        for option, var in self.subplot_vars.items():
            if var.get():
                subplot_params = {}
                for param, entry in self.subplot_param_entries[option].items():
                    if entry.cget('bg') == self.form_color_modif:
                        val = entry.get().strip()
                        try:
                            parsed = eval(val)
                        except:
                            parsed = val
                        subplot_params[param] = parsed
                if subplot_params:
                    subplot_data[option] = subplot_params
        if subplot_data:
            settings_to_save['subplots'] = subplot_data
        # -- Save only if anything was modified!
        if not settings_to_save:
            messagebox.showinfo("No Changes", "No modified settings to save!")
            return
        # -- Write YAML file:
        file_path = filedialog.asksaveasfilename(defaultextension=".yaml", filetypes=[("YAML files", "*.yaml")])
        if file_path:
            with open(file_path, 'w') as f:
                yaml.dump(settings_to_save, f, sort_keys=False)
            messagebox.showinfo("Success", f"Settings saved to {file_path}")

    def save_defaults_to_yaml(self) -> None:
        """
        Exports the current default configuration into a YAML file.

        Behavior:
        ---------
        - Saves all parameter values, regardless of whether the user has modified them.
        - Correctly parses input values:
            • Converts numerical strings to int or float.
            • Handles list parameters with padding up to the maximum length (self.__lim_len_var).
            • For list parameters:
                - If the default is a repeating value (e.g., [0.8, 0.8, ..., 0.8]):
                  keeps the repeating structure instead of inserting None.
                - If the user input matches the default repeat value → saves it as a repeated list.
                - Otherwise, pads the list to the required length.

        - Subplot options:
            • Exports all subplot configurations (not only active ones).
            • Includes all subplot parameters, even if unchanged.

        - Grid settings:
            • Always includes the 'plt_lgrid' (Grid Add) checkbox state.

        Output:
        -------
        - Opens a file dialog to select where to save the YAML configuration.
        - Saves the entire current configuration (full defaults) into the chosen YAML file.

        Notes:
        ------
        - Intended for generating the baseline/default configuration file.
        - Unlike 'save_settings', this function does not check for field modification.
        - Useful for exporting initial setups or for documentation purposes.
        """
        # --- Check for modified fields ---
        for entry in self.entries.values():
            if entry.cget('bg') == self.form_color_modif:
                messagebox.showerror("Aborted", "Some fields have been modified.\nUse 'Save Settings' to export custom changes.")
                return

        defaults_to_save = {}
        for key, entry in self.entries.items():
            value = entry.get()
            try:
                parsed = eval(value)
            except:
                parsed = value
            # --- Ensure plts_subtitle is always a list ---
            if key in ["plts_title", "plts_subtitle"]:
                if not isinstance(parsed, list):
                    parsed = [parsed]
                    if parsed == [None]:
                        parsed = None
                elif parsed == []:
                    parsed = [None]

            if key in self.main_parameters and self.is_list_parameter(key):
                default_value = self.general_defaults.get(key)
                # Check if default is repeating:
                if isinstance(default_value, list) and len(set(default_value)) == 1:
                    unique_default = default_value[0]
                    # If the user entered the same value, repeat it:
                    if parsed == unique_default or (isinstance(parsed, list) and all((v == unique_default or v is None) for v in parsed)):
                        defaults_to_save[key] = [unique_default] * self.__lim_len_var
                    else:
                        defaults_to_save[key] = self.pad_to_limit(parsed)
                else:
                    defaults_to_save[key] = self.pad_to_limit(parsed)
            else:
                defaults_to_save[key] = parsed
        # Always include 'lgrid' in debug comparison:
        current_lgrid = self.lgrid_var.get()
        defaults_to_save['plt_lgrid'] = current_lgrid

        subplot_defaults = {}
        for option, param_dict in self.subplot_param_entries.items():
            subplot_defaults[option] = {}
            for param, entry in param_dict.items():
                val = entry.get()
                try:
                    parsed = eval(val)
                except:
                    parsed = val
                if self.is_list_parameter(param):
                    subplot_defaults[option][param] = self.pad_to_limit(parsed)
                else:
                    subplot_defaults[option][param] = parsed
        defaults_to_save['subplots'] = subplot_defaults

        file_path = filedialog.asksaveasfilename(defaultextension=".yaml", filetypes=[("YAML files", "*.yaml")])
        if file_path:
            with open(file_path, 'w') as f:
                yaml.dump(defaults_to_save, f, sort_keys=False)
            messagebox.showinfo("Success", f"Default configuration saved to {file_path}")

    def debug_compare_with_defaults(self) -> None:
        """
        Debugging tool for comparing the current GUI state with the default configuration.

        Behavior:
        ---------
        - Checks both general/grid parameters and subplot parameters.
        - Activates all subplot fields temporarily to ensure a full comparison.
        - Compares each current field value against its corresponding default:
            • For list-type parameters:
                - Correctly handles repeating default values (e.g., [0.8, 0.8, ..., 0.8]).
                - Pads user input lists to the required length for a fair comparison.
            • For scalar (single) values:
                - Direct string-based comparison after parsing numerical inputs.

        - If mismatches are detected:
            • Prints a detailed message showing the current value and expected default.
            • Labels mismatches as either [Main], [General], or [subplot option].

        Subplot Handling:
        -----------------
        - Forces all subplot options to be "active" during the debug check.
        - Compares subplot parameter fields even if their checkboxes are not selected.

        Output:
        -------
        - Prints comparison results directly to the console (standard output).
        - Clearly marks mismatches for easy identification.

        Notes:
        ------
        - This function does not modify the GUI state permanently.
        - Intended for manual inspection and debugging purposes only.
        - Helpful for verifying whether the current GUI setup matches the configuration defaults.
        """
        # -- Check General and Grid Settings:
        for key, entry in self.entries.items():
            current_value = entry.get()
            default_value = self.general_defaults.get(key)
            if key in self.main_parameters:
                # -- For main parameters, check with padding logic:
                try:
                    parsed_current = eval(current_value)
                except:
                    parsed_current = current_value
                parsed_current = [parsed_current] if not isinstance(parsed_current, list) else parsed_current
                # -- Detect if the default list is repeating the same value:
                if isinstance(default_value, list) and len(set(default_value)) == 1:
                    default_unique = default_value[0]
                    # -- Check if user input matches this unique value:
                    if all((v == default_unique or v is None) for v in parsed_current):
                        continue  # They match → no mismatch
                    else:
                        print(f"[Main] Mismatch in '{key}': Current='{parsed_current}' | Expected all '{default_unique}'")
                else:
                    # -- Regular padded list comparison:
                    padded_current = self.pad_to_limit(parsed_current)
                    padded_default = self.pad_to_limit(default_value)
                    if padded_current != padded_default:
                        print(f"[Main] Mismatch in '{key}': Current='{padded_current}' | Default='{padded_default}'")
            else:
                # -- For single values
                try:
                    parsed_current = eval(current_value)
                except:
                    parsed_current = current_value
                if str(parsed_current) != str(default_value):
                    print(f"[General] Mismatch in '{key}': Current='{parsed_current}' | Default='{default_value}'")
        # -- Check Subplot Settings (activate all for comparison)
        for option, params in self.subplot_param_entries.items():
            for param, entry in params.items():
                current_value = entry.get()
                default_value = self.default_subplot_values.get(option, {}).get(param)
                try:
                    parsed_current = eval(current_value)
                except:
                    parsed_current = current_value
                if isinstance(default_value, list) and len(set(default_value)) == 1:
                    default_value = default_value[0]  # Simplify list if all the same
                if str(parsed_current) != str(default_value):
                    print(f"[{option}] Mismatch in '{param}': Current='{parsed_current}' | Default='{default_value}'")

    def show_info(self, section: Optional[str] = None) -> None:
        """
        Displays context-specific help information for the selected GUI parameter section.

        Behavior:
        ---------
        - Opens a message box with an explanation for the selected group of parameters.
        - Each section describes the meaning and purpose of its settings, including examples where helpful.
        - Supports the following sections:
            • "general"          → General Plot Settings.
            • "main_parameters"  → Line / Marker / Bar Settings.
            • "grid"             → Grid Settings.
            • "x_axis"           → X Axis Settings.
            • "y_axis"           → Y Axis Settings.
            • "subplots"         → Subplot Options and layout configuration.

        Parameters:
        -----------
        section : str, optional
            The section name that determines which help message to display.
            If None or unrecognized, a general help message is shown.

        Notes:
        ------
        - This function is triggered by clicking the "?" info buttons in different sections of the GUI.
        - Uses Tkinter's `messagebox.showinfo()` for the popup display.
        - Helps guide the user on how to correctly input values for each parameter group.
        """
        if section == "x_axis":
            messagebox.showinfo(
                "Info for X Axis Settings",
                "Explanation of X Axis Parameters:\n\n"
                "• plt_num_x_axis:\n"
                "  Set to True if you want a numerical X-axis (integer labels).\n\n"
                "• plt_time_x_axis:\n"
                "  Set to True if you want the X-axis to represent time values.\n"
                "  If both 'plt_num_x_axis' and 'plt_time_x_axis' are False, the axis uses string labels.\n\n"
                "• plt_ftime:\n"
                "  Date/time format string (used when 'time_x_axis' is True).\n"
                "  Example formats: '%Y-%m-%d', '%H', '%M', etc.\n"
                "  Controls how the date/time labels appear on the X-axis.\n\n"
                "• plt_day_locator:\n"
                "  Adds extra ticks on the X-axis.\n"
                "  Example: 15 → one tick every 15 days (when using time axis).\n\n"
                "• plt_l_xrotation:\n"
                "  Set to True to rotate X-axis labels (useful if labels overlap).\n\n"
                "• plt_x_unit_color:\n"
                "  Color of the X-axis label units (can be text like 'black', 'blue')."
            )
        elif section == "main_parameters":
            messagebox.showinfo(
                "Info for Line / Marker / Bar Settings",
                "How to input values:\n\n"
                "• For a single value (applied to all lines/markers/bars):\n"
                "  Example:  blue    or    0.8    or    --\n"
                "  (Quotes are not required for strings like colors or styles.)\n\n"
                "• For multiple values (comma-separated list):\n"
                "  Example:  blue, green, red\n"
                "  (You do not need brackets like [ ] — just use commas.)\n\n"
                "Notes:\n"
                "- If you enter fewer than 21 values, the list will be automatically padded.\n"
                "- Padding uses the default value (if available); otherwise, None is used.\n"
                "- Example padded result:\n"
                "    ['blue', 'green', 'red', None, None, ..., None]\n\n"
                "Tip:\n"
                "- Enter numbers (like 0.5, 1.0) without quotes.\n"
                "- Strings like color names ('blue') or line styles ('--') can be written directly without quotes."
            )
        elif section == "general":
            messagebox.showinfo(
                "Info for General Plot Settings",
                "Explanation of General Plot Parameters:\n\n"
                "• plt_title_color:\n"
                "  Color of the plot title text (e.g., black, blue, red).\n\n"
                "• plt_labels_color:\n"
                "  Color of the axis labels (X and Y labels).\n\n"
                "• plt_llegend:\n"
                "  Set to True to display the legend on the plot.\n"
                "  False if you want to hide the legend.\n\n"
                "• plt_minor_locator:\n"
                "  Controls how many divisions between major grid ticks.\n"
                "  Example: 5 → five subdivisions between each major tick.\n\n"
                "• plt_lsave:\n"
                "  Set to True if you want to save the generated plot automatically.\n\n"
                "• plt_format:\n"
                "  Format for saving the plot (e.g., png, jpg, pdf).\n\n"
                "• plt_dpi:\n"
                "  Resolution of the saved plot (Dots Per Inch).\n"
                "  Higher DPI means better quality but larger file size."
            )
        elif section == "grid":
            messagebox.showinfo(
                "Info for Grid Settings",
                "Explanation of Grid Parameters:\n\n"
                "• plt_gtype:\n"
                "  Defines which ticks to apply the grid to:\n"
                "   - 'major' for main grid lines.\n"
                "   - 'minor' for additional subdivision lines.\n\n"
                "• plt_gclr:\n"
                "   Color of the grid lines (e.g., grey, black).\n\n"
                "• plt_gstyle:\n"
                "  Line style for the grid:\n"
                "  - solid, dashed, dotted, etc.\n\n"
                "• plt_galpha:\n"
                "  Transparency of the grid lines (from 0.0 = fully transparent to 1.0 = fully opaque).\n\n"
                "Note:\n"
                "- The 'Grid Add' checkbox enables or disables these grid options."
            )
        elif section == "y_axis":
            messagebox.showinfo(
                "Info for Y Axis Settings",
                "Explanation of Y Axis Parameters:\n\n"
                "• plt_l_yrotation:\n"
                "  Set to True to rotate Y-axis labels (useful for vertical text).\n\n"
                "• plt_y_rotation:\n"
                "  Angle (in degrees) for rotating Y-axis labels.\n"
                "  Example: 0 for horizontal, 90 for vertical.\n\n"
                "• plt_y_unit_size:\n"
                "  Font size of the Y-axis label units.\n\n"
                "• plt_y_unit_color:\n"
                "  Color of the Y-axis label units (e.g., black, blue).\n\n"
                "• plt_lextra_axis:\n"
                "  Set to True if you want to add an additional Y-axis (for dual-axis plots)."
            )
        elif section == "subplots":
            messagebox.showinfo(
                "Info for Subplot Options",
                "Explanation of Subplot Parameters:\n\n"
                "Subplot Layout:\n"
                "• single  →  One plot (1 row × 1 column).\n"
                "• r1c4    →  1 row × 4 columns.\n"
                "• r2c4    →  2 rows × 4 columns.\n"
                "• r3c4    →  3 rows × 4 columns.\n\n"
                "Parameters for each subplot configuration:\n"
                "• splt_size:\n"
                "  Figure size as [width, height] in inches.\n\n"
                "• splt_nrows / splt_ncols:\n"
                "  Number of rows and columns in the subplot grid.\n\n"
                "• splt_wspace / splt_hspace:\n"
                "  Spacing between subplots (width and height space).\n\n"
                "• splt_bottom / splt_top:\n"
                "  Adjust the vertical positioning of the entire subplot layout.\n\n"
                "• splt_title_fsize / splt_title_pad:\n"
                "  Font size and padding for subplot titles.\n\n"
                "• splt_label_fsize:\n"
                "  Font size for axis labels.\n\n"
                "• splt_xlabel_pad / splt_ylabel_pad:\n"
                "  Padding between labels and the plot edges.\n\n"
                "• splt_x_rotation:\n"
                "  Rotation angle for X-axis labels.\n\n"
                "• splt_x_unit_size:\n"
                "  Font size of X-axis label units.\n\n"
                "• splt_l_pos:\n"
                "  Position of the legend (e.g., 'upper left', 'upper right').\n\n"
                "• splt_bbox_x_loc / splt_bbox_y_loc:\n"
                "  Legend box location coordinates."
            )
        elif section == "special":
            messagebox.showinfo(
                "Info for Special Parameters",
                "• plts_title:\n"
                "  List of titles corresponding to each parameter. Must be a list of strings (e.g., BIASmean, BIASnorm) .\n"
                "  If provided, overrides the default titles extracted from the NetCDF parameter names.\n\n"
                "• plts_subtitle:\n"
                "  List of subtitles corresponding to each region or models (e.g., COSMO, ICON, CLM). Must be a list of strings.\n"
                "  If the number of subtitles doesn't match the number of regions, defaults from the file will be used.\n\n"
                "• plts_min_values / plts_max_values:\n"
                "  Optional manual override for colorbar limits. These dictionaries use the format:\n"
                "    { 'parameter_name, season': vmin or vmax }\n"
                "  Use only if consistent scaling across plots is required (e.g., for publications)."
            )
        else:
            messagebox.showinfo(
                "Info",
                "This is the general help section.\n"
                "(You can add more info here if needed.)"
            )


if __name__ == "__main__":
    root = tk.Tk()
    app = Plot1DSettingsGUI(root)
    root.mainloop()
