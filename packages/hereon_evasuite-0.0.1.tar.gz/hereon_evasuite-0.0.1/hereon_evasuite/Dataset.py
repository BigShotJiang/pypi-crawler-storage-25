# EvaSuite
#
# ---------------------------------------------------------------
# Copyright (C) 2004-2025, Hereon
# Contact information: beate.geyer@hereon.de, imktro-climate-modelling@lists.kit.edu
# See AUTHORS.TXT for a list of authors
# See LICENSES/ for license information
# SPDX-License-Identifier: Apache-2.0
# ---------------------------------------------------------------

# -- Import Python modules:
import os
import glob
import shutil
from typing import Any, Optional, Dict, List, Union, Tuple

# -- Import EvaSuite modules:
from hereon_evasuite.log_EvaSuite import get_logger, log_function_name
from hereon_evasuite.GeneralUtils import SuiteUtilities
from hereon_evasuite.Prog_CDONCO import CDO, NCO, NCSYS
from hereon_evasuite.Prog_PyXarray_PyVis import PyXarray
from hereon_evasuite.DataMiningGD import DataMiningGridded, DataMiningStation
from hereon_evasuite.control_input_settings import Control_dataset_namelists

# -- Activation common methods and loggers:
GeneralUtils = SuiteUtilities()
logger = get_logger()

# -- Class to handle datasets and attributes (methods + variables):


class Dataset(object):
    @log_function_name
    def __init__(
        self: 'Dataset',
        datasetname: str,
        typeofdata: str,
        settingsDataset: Dict[str, Any],
        evalparas: List[str],
        eval_refgridhor: Optional[bool] = None,
        eval_origrefgrid: Optional[bool] = None,
        eval_refvertb: Optional[bool] = None,
        eval_timerefgrid: Optional[Any] = None,
        DSevalbase: Optional[Any] = None,
        DStoproof: Optional[Any] = None,
        DSskillref: Optional[Any] = None,
        checkAR: Optional[bool] = False,
    ) -> None:
        """ Initialization of Dataset class: """
        # -- Local variables associated with the data set:
        self.name = datasetname
        # possible values for typeEP:
        #  'Evaldata', 'Data2Proof', 'CombEvalData_{minmax/mean}', 'FinalEvalMode'
        self.typeEP = typeofdata
        # -- evaluation dataset for Dataset:
        self.DSevalbase = DSevalbase
        # -- dataproof:
        self.DStoproof = DStoproof
        # -- skill reference for Dataset:
        self.DSskillref = DSskillref
        self.cfgdataset = settingsDataset
        self.typeGRID = self.cfgdataset["gridtype"]
        self.typeVERT = GeneralUtils.safe_access_bib(
            " ",
            KeyError,
            dicttest = self.cfgdataset,
            dictkey = "levtype",
            errhandle = False,
        )
        # -- Horizontal reference grid:
        self.eval_refgridhor = eval_refgridhor
        # -- Vertical reference grid:
        self.eval_refvertb = eval_refvertb
        # -- Original reference grid:
        self.eval_origrefgrid = eval_origrefgrid
        # -- The reference for temporal reselect:
        self.eval_timerefgrid = eval_timerefgrid
        # -- Create a new dictionary and list which will be used furher:
        self.Protect_VarNames: dict[Any, Any] = {}
        self.Protect_Attributes: list[Any] = []

        logger.info(f'Dataset instance for {self.name} ", Type: " {self.typeEP}')
        # -- Check Access to data
        if checkAR:
            research_var = self.getOrigDataFil(evalparas)[0]
            logger.debug(
                f'Checking readability of dataset directory {self.cfgdataset["storagedir"]} '
                f'and files {research_var}'
            )
            # -- Control of some variables:
            checker = Control_dataset_namelists(
                self.name,
                self.cfgdataset,
                research_var
            )
            checker.run_all_checks()

    @log_function_name
    def createDirs(
        self: 'Dataset',
        rootdatadir: str,
        subdirectorylist: List[str],
    ) -> None:
        """
        Create subdirectories for the dataset inside each given working directory.

        For each entry in subdirectorylist, this will:
        ----------------------------
            - Create the working directory under rootdatadir (if it doesn't exist)
            - Create a subdirectory named after the dataset (self.name)
            - Store the full dataset subdirectory path in self.subdirs_datset

        Parameters:
        ----------------------------
            - rootdatadir (str): Base path where all working directories will be created
            - subdirectorylist (List[str]): List of subdirectory names to create under rootdatadir

        Returns:
        ----------------------------
            - None (modifies self.subdirs_datset in-place)
        """
        self.subdirs_datset = []
        for wpdirname in subdirectorylist:
            # Create working path if it doesn't exist
            dirdatawp = os.path.join(rootdatadir, wpdirname)
            os.makedirs(dirdatawp, exist_ok=True)
            # Create dataset-specific subdirectory
            dataset_subdir = os.path.join(dirdatawp, self.name)
            os.makedirs(dataset_subdir, exist_ok=True)
            # Store the created path
            self.subdirs_datset.append(dataset_subdir)

    @log_function_name
    def __generate_output_path(
        self,
        input_filepath: str,
        output_directory: str,
        label_suffix: str
    ) -> str:
        """
        Construct a standardized output path by removing the file extension
        from the input filename and appending a suffix before adding .nc.

        Parameters:
        ----------------------------
            input_filepath (str): Full path to the input data file.
            output_directory (str): Directory to save the output.
            label_suffix (str): Suffix to append to the filename.

        Returns:
        ----------------------------
            str: Full output file path with .nc extension.
        """
        filename_without_ext = os.path.splitext(os.path.basename(input_filepath))[0]
        return os.path.join(output_directory, f"{filename_without_ext}_{label_suffix}.nc")

    @log_function_name
    def DetectRepairEffort(
        self: 'Dataset',
        evalparas: list[str],
        Repair_variables: List[str],
        Repair_attributes: List[str],
        DataProgsToUse: Dict[str, Union[CDO, NCO, NCSYS, PyXarray]],
        filelist: List[str],
        Repair_TargGrid: List[str],
    ) -> None:
        """
            Detect the attributes and variables in the netcdf variables which
            should survive cdo operations:
        """
        # -- Local variables (load class objects):
        if isinstance(DataProgsToUse["nco"], NCO):
            nco_object = DataProgsToUse["nco"]
        if isinstance(DataProgsToUse["pyxarray"], PyXarray):
            pyxarray_object = DataProgsToUse["pyxarray"]

        Repair_wholevars = (
            Repair_variables + Repair_TargGrid if self.eval_origrefgrid else Repair_variables
        )
        for datafile in filelist:
            Protect_VarNames, h = pyxarray_object.FindVarName(
                datafile, Repair_wholevars,
            )
            for varname in Protect_VarNames:
                self.Protect_VarNames.update({varname: datafile})

            for eintrag in nco_object.FindAttributes(datafile, attributes = Repair_attributes):
                if ((eintrag[0] in self.getVarNamelist(evalparas) + Repair_variables) and
                        (eintrag not in self.Protect_Attributes)):
                    self.Protect_Attributes.append(eintrag)

        # -- Check for Repair from external files:
        RepairExternalVarnames = GeneralUtils.safe_access_bib(
            f'The attribute "External_RepairNcdf_variables" is not given as a settings for {self.name}',
            KeyError,
            dicttest = self.cfgdataset,
            dictkey = "External_RepairNcdf_variables",
            errhandle = False,
        )
        if RepairExternalVarnames is not None:
            if list(RepairExternalVarnames.keys()):
                self.Protect_VarNames.update(RepairExternalVarnames)
                logger.info(
                    f'An external file is given containing the variables names "'
                    f'{list(RepairExternalVarnames.keys())}" to be repaired'
                )
        else:
            logger.info('No external files with variables to protect was given.')

    @log_function_name
    def DetectDomCut(
        self: 'Dataset',
        cfgdomhori: Optional[bool] = None,
        cfgdomvert: Optional[bool] = None,
    ) -> tuple[bool, Union[bool, None], Union[bool, None]]:
        """ Detects the need for cutting the domain on reference grid """
        # -- Set local variables:
        needcutdom, cutxydict, cutzdict = False, None, None
        # -- Get actual values for variables:
        if self.getRefgrid() and cfgdomhori is not None:
            cutxydict = cfgdomhori
        if self.getRefVert() and cfgdomvert is not None:
            cutzdict = cfgdomvert
        # -- There are cases where no vertical reference grid is given but
        #    still a level has to be cut
        if (cutxydict is not None) or (cutzdict is not None):
            needcutdom = True
        return needcutdom, cutxydict, cutzdict

    @log_function_name
    def IdentifyAndCutRelevantFiles(
        self: 'Dataset',
        evalparas: List[str],
        cfgdatamining: Dict[str, Any],
        DataProgsToUse: Dict[str, Union[CDO, NCO, NCSYS, PyXarray]],
        resultdir: str,
        posdimnames: Dict[str, List[str]],
    ) -> None:
        """
        Identify and extract input files containing the parameters and time slices required for evaluation.

        This method scans available datasets and filters files based on:
        - Desired evaluation parameters (`evalparas`)
        - Time periods of interest (`cfgdatamining['targettime_fullspan']`)
        - Optional constraints (e.g., subregions, masks, interpolation methods)

        Parameters
        ----------
        evalparas : List[str]
            List of variable names to evaluate (e.g., ['hfls']).

        cfgdatamining : Dict[str, Any]
            Dictionary of user configuration for data mining, including:
            - Time span and season: `targettime_fullspan`, `targettime_season`
            - Target grid settings: `targetgrid_horizontal`, `targetgrid_vertical`
            - Evaluation frequency: `target_EvalFrequency`
            - Interpolation method: `interpol_method`
            - Domain settings and masking options

        DataProgsToUse : Dict[str, Union[CDO, NCO, NCSYS, PyXarray]]
            Dictionary of initialized processing tool wrappers used for file handling.

        resultdir : str
            Path to the directory where the identified and cut files should be stored.

        posdimnames : Dict[str, List[str]]
            Mapping of recognized dimension names, e.g.:
            - 'spatial': ['lon', 'lat', 'X', 'Y']
            - 'time': ['time']
            - 'vertical': ['level', 'height']

        Examples
        --------
        evalparas = ['hfls']
        cfgdatamining = {
            'targettime_fullspan': ['1981-01-01T00:00', '1982-12-31T23:59'],
            'target_EvalFrequency': {'method': 'resample', 'freq': 'monthly', 'how': 'mean'},
            ...
        }
        resultdir = '/scratch/.../DataMining/WP01_Preperation/MIROC6-monthly'
        posdimnames = {
            'spatial': ['lon', 'lat'],
            'time': ['time'],
            'vertical': ['level']
        }

        Notes
        -----
        This method is **deprecated** and will be removed in future versions.
        Please use `IdentifyRelevantMergeTime()` instead for robust and future-proof handling.
        """
        # -- Local variables (load class objects):
        if isinstance(DataProgsToUse["cdo"], CDO):
            cdo_object = DataProgsToUse["cdo"]
        if isinstance(DataProgsToUse["pyxarray"], PyXarray):
            pyxarray_object = DataProgsToUse["pyxarray"]
        if isinstance(DataProgsToUse["nco"], NCO):
            nco_object = DataProgsToUse["nco"]
        #
        self.RelevantFiles: list[Any] = []
        self.RelevantFiles_ForRepair: list[Any] = []

        refgrid_domcut, cutxydict, cutzdict = self.DetectDomCut(
            cfgdatamining["targetdom_horizontal"],
            cfgdatamining["targetdom_vertical"],
        )
        # -- List matches:
        filesMatchingUserSpecs = self.getOrigDataFil(evalparas)
        if len(filesMatchingUserSpecs) > 1:
            filesMatchingUserSpecs = [
                f"{self.cfgdataset['storagedir']}/{entry}"
                for entry in filesMatchingUserSpecs
            ]
        else:
            filesMatchingUserSpecs = (
                glob.glob(f"{self.cfgdataset['storagedir']}/{filesMatchingUserSpecs[0]}")
            )

        # -- Proof for external zipped files and extract them --> update filelist
        filestocheck = self.checkExternalZip(filesMatchingUserSpecs, resultdir = resultdir)
        #
        for datafile, countf in zip(filestocheck, range(len(filestocheck))):
            logger.debug(f'Investigating file {datafile}')
            # -- Check for varnames and times relevant for evaluation:
            VarNamesIntersect, h = cdo_object.FindVarName(
                datafile, self.getVarNamelist(evalparas),
            )

            NoUnitTSAtAll, CorVarList = self.getListOfVarsToCorrect(
                varnames = VarNamesIntersect,
                listofVardicts = True,
            )

            AllVarnsRelevant = cdo_object.AllVarNamesRelevant(
                datafile = datafile,
                varnamelist = VarNamesIntersect,
            )
            DateTimeIntSec, AllTimeStepsRelevant = pyxarray_object.DatesInterSect(
                filein = datafile,
                timper = cfgdatamining["targettime_fullspan"],
                varcorlistdict = CorVarList,
                varsrel = VarNamesIntersect,
                posdimnames = posdimnames,
            )
            # -- If the list empty, do nothing:
            if VarNamesIntersect and DateTimeIntSec:
                suffilnr = f"_filenr_{countf}"
                # if not refgrid_domcut:
                self.RelevantFiles_ForRepair.append(datafile)
                datafileUZ, CheckZ = self.CheckInternalZip(
                    fnamein = datafile,
                    resultdir = resultdir,
                    progobj = DataProgsToUse,
                    variable = VarNamesIntersect[0],
                    suffix = suffilnr,
                )
                if not(AllTimeStepsRelevant and AllVarnsRelevant and NoUnitTSAtAll):
                    logger.debug(f'Something relevant found , vars={VarNamesIntersect}')
                    logger.debug(
                        '... timesteps=' + ','.join(map(str, [DateTimeIntSec[0], DateTimeIntSec[1]])))
                    suffilnr2 = '' if CheckZ else suffilnr
                    # -- Create output path:
                    outputname = os.path.join(
                        resultdir,
                        os.path.basename(datafileUZ) + f"_CutParamTimeUnitCor{suffilnr2}"
                    )
                    # -- Time cutting for dataset:
                    file_cutparamtime = pyxarray_object.CutTimeStepsAndParamAndVarCor(
                        filein = datafileUZ,
                        fileout = outputname,
                        varnames = VarNamesIntersect,
                        timper = cfgdatamining["targettime_fullspan"],
                        varcorlistdict = CorVarList,
                        posdimnames = posdimnames,
                        timRangeIdx = DateTimeIntSec,
                    )

                    logger.info('Relevant parameters and times cutted + units converted')
                    RelevantF = file_cutparamtime

                else:
                    logger.info(
                        f'All timesteps and variables are relevant to the evaluation, '
                        f'i.e. vars = {VarNamesIntersect} ... timesteps = '
                        f'[{DateTimeIntSec[0]}, {DateTimeIntSec[0]}]. No unit '
                        'conversions are required. The file is taken as it is.'
                    )
                    RelevantF = datafileUZ
                #
                if refgrid_domcut:
                    outfname = os.path.join(
                        resultdir, os.path.basename(datafileUZ) + "_domcut_refgrid")

                    logger.debug(
                        f'Cut out spatially/vertically from reference domain in '
                        f'file {datafileUZ}'
                    )

                    nco_object.CutDomainXYZ(
                        filein = RelevantF, fileout = outfname,
                        RangeSpat = cutxydict, RangeLev = cutzdict,
                    )
                    self.RelevantFiles.append(outfname)
                    '''
                    Now the issue is to take also the result of cutting as reference
                    for netcdf-repair, otherwise it gets problematic to copy lon's
                    and lat's from an uncutted original file to a cutted file.
                    Thus, we have two files for repairing the files of the reference
                    grid dataset: one time the files found relevant for variables
                    and times and another time the files cutted horizontally
                    (the latter induce an overwriting of variables to repair ->
                    they are not taken from relevant files but from cutted files;
                    other variables like rotated_pole maybe were destroyed during
                    timestep-selection but they are still there in the relevant files)
                    '''
                    self.RelevantFiles_ForRepair.append(outfname)
                else:
                    self.RelevantFiles.append(RelevantF)

    @log_function_name
    def MergeRelevantFiles(
        self: 'Dataset',
        DataProgsToUse: Dict[str, Union[CDO, NCO, NCSYS, PyXarray]],
        resultdir: str,
    ) -> None:
        """
        Merge all intermediate or filtered files into a single dataset for further evaluation steps.

        This method consolidates files located in `resultdir` that were previously identified
        and cut during the data preparation phase. It is useful for simplifying downstream
        processing and ensuring compatibility with evaluation tools that expect a single input file.

        Parameters
        ----------
        DataProgsToUse : Dict[str, Union[CDO, NCO, NCSYS, PyXarray]]
            A dictionary of initialized processing tool wrappers used for file operations,
            such as merging NetCDF datasets (e.g., with CDO or NCO).

        resultdir : str
            Path to the directory containing the relevant files to be merged. The final merged
            file will typically overwrite or complement the intermediate results.

        Notes
        -----
        **Deprecation Warning**: This method is planned for removal in future versions.
        Although currently functional, it is recommended to migrate to a more modern merging strategy
        integrated into `IdentifyRelevantMergeTime()` or your custom data pipeline.
        """
        # -- Local variables (load class objects):
        if isinstance(DataProgsToUse["cdo"], CDO):
            cdo_object = DataProgsToUse["cdo"]

        self.PreparedFiles: List[Any] = []
        if len(self.RelevantFiles) == 0:
            raise FileNotFoundError(
                "No files were found in the user-specified storage directory, "
                "which contain any information relevant to the evaluation settings."
            )
        elif len(self.RelevantFiles) == 1:
            logger.debug(
                ' 1 file was found containing relevant information. Merging is superfluous.'
            )
            self.PreparedFiles = self.RelevantFiles
        else:
            outputname = os.path.join(
                resultdir, f"{self.name}_Merged_RelevantTimeAndParam.nc")

            file_mergedataset = cdo_object.MergeFiles(
                filesin = self.RelevantFiles,
                fileout = outputname,
                tmpfile = False,
            )
            self.PreparedFiles.append(file_mergedataset)

    @log_function_name
    def IdentifyRelevantMergeTime(
        self: 'Dataset',
        evalparas: List[str],
        cfgdatamining: Dict[str, Any],
        DataProgsToUse: Dict[str, Union[CDO, NCO, NCSYS, PyXarray]],
        resultdir: str,
        posdimnames = None,
    ) -> None:
        """
        Identify and merge all files that contain data for the evaluation parameters and time range of interest.

        This method replaces the older `IdentifyAndCutRelevantFiles` and `MergeRelevantFiles` by
        combining both identification and merging logic into a unified and robust step. It scans
        the result directory for files containing the specified evaluation parameters and ensures
        that only the relevant ones within the desired temporal and spatial bounds are merged.

        Parameters
        ----------
        evalparas : List[str]
            List of evaluation parameters (e.g., `['tas', 'pr']`) to be matched against the dataset files.

        cfgdatamining : Dict[str, Any]
            Configuration dictionary specifying temporal bounds, spatial domains, masks, and other user-defined settings.
            Example keys include:
            - `targettime_fullspan`: full time range to consider.
            - `targetgrid_horizontal`, `targetgrid_vertical`: target grids for interpolation.
            - `operator_time`, `aggregate_temporal`, etc.

        DataProgsToUse : Dict[str, Union[CDO, NCO, NCSYS, PyXarray]]
            Dictionary of external tool interfaces (e.g., CDO, NCO) used for data manipulation and merging.

        resultdir : str
            Directory containing intermediate result files to scan, select, and merge.

        posdimnames : Optional[Dict[str, List[str]]]
            Dictionary of recognized dimension names, e.g.,:
            ```python
            {
                "spatial": ["lon", "lat", "x", "y"],
                "time": ["time"],
                "vertical": ["level", "height"]
            }
            ```
            If not provided, default dimensions may be inferred or assumed by downstream tools.
        """
        logger.warning(
            "EvaSuite Warning: You are using an untested function.\n"
            "If possible, please send your configuration files to: "
            "evgenii.churiulin@kit.edu for testing and validation support."
        )

        # -- Local variables (load class objects):
        if isinstance(DataProgsToUse["cdo"], CDO):
            cdo_object = DataProgsToUse["cdo"]
        if isinstance(DataProgsToUse["pyxarray"], PyXarray):
            pyxarray_object = DataProgsToUse["pyxarray"]

        self.RelevantFiles = []
        refgrid_domcut, cutxydict, cutzdict = self.DetectDomCut(
            cfgdatamining["targetdom_horizontal"], cfgdatamining["targetdom_vertical"],
        )
        # -- Step 1, check the files for data structure --> self.RelevantFiles
        filesMatchingUserSpecs = self.getOrigDataFil(evalparas)
        if len(filesMatchingUserSpecs) > 1:
            filesMatchingUserSpecs = [
                os.path.join(self.cfgdataset["storagedir"], entry)
                for entry in filesMatchingUserSpecs
            ]
        else:
            filesMatchingUserSpecs = glob.glob(
                f'{self.cfgdataset["storagedir"]}/{filesMatchingUserSpecs[0]}')

        # -- Proof for external zipped files and extract them --> update filelist
        filestocheck = self.checkExternalZip(
            filesMatchingUserSpecs, resultdir = resultdir)
        #
        refvars: List[Any] = []
        for datafile in filestocheck:
            logger.debug(f'Investigating file {datafile}')
            # -- Check for varnames relevant for evaluation:
            varsintersec, datavars = cdo_object.FindVarName(
                datafile, self.getVarNamelist(evalparas),
            )
            logger.debug(f'{varsintersec}**********{datavars}')

            if varsintersec:
                if (refvars and not(set(datavars).difference(refvars))) or (not(refvars)):
                    logger.debug(
                        '... which has variables of interest and same'
                        ' data structure as the others')
                    datafileUZ = self.CheckInternalZip(
                        fnamein = datafile,
                        resultdir = resultdir,
                        progobj = DataProgsToUse,
                        variable = VarNamesIntersect[0],
                    )
                    self.RelevantFiles.append(datafileUZ)
                    refvars = datavars
                    refintersec = varsintersec
                else:
                    raise Exception(
                        "The specified datafiles for the dataset has different data structure --> Stop")
            else:
                logger.debug('... which has no variables of interest.')

        # -- Step 2, Put all files together --> self.PreparedFiles:
        self.PreparedFiles = []
        help1, corvarlist = self.getListOfVarsToCorrect(
            varnames = refintersec, listofVardicts = True)

        outputname = os.path.join(
            resultdir,
            f"{self.name}_{self.getVarNamelist(evalparas)[0]}_CutParamTimeUnitCor.nc"
        )

        file_cutparamtime = pyxarray_object.CutTimeStepsAndParamAndVarCor(
            filein = self.RelevantFiles,
            fileout = outputname,
            varnames = refintersec,
            timper = cfgdatamining["targettime_fullspan"],
            varcorlistdict = corvarlist,
            posdimnames = posdimnames,
            cutrgspat = cutxydict,
            cutrglev = cutzdict,
        )
        logger.info('Relevant parameters and times cutted + units converted')
        self.PreparedFiles.append(file_cutparamtime)

    @log_function_name
    def ChangeVertHoriGrid(
        self: 'Dataset',
        cfgdatamining: Dict[str, Any],
        GridOperaToUse: Dict[str, Union[DataMiningGridded, DataMiningStation]],
        DataProgsToUse: Dict[str, Union[CDO, NCO, NCSYS, PyXarray]],
        interpol_refgridf: str,
        interpol_refgridtype: str,
        interpol_refvertf: Any,
        interpol_reflevtype: Any,
        evalparas: List[str],
        interpol_refevalpars: Any,
        resultdir: str,
    ) -> None:
        """
        Apply horizontal and/or vertical interpolation to dataset files before evaluation.

        Based on the configuration and grid types, this function determines the appropriate
        interpolation strategy (horizontal, vertical, or both) and delegates the operation
        to either `DataMiningGridded` or `DataMiningStation` tools via `GridOperaToUse`.

        This step is essential to ensure that all datasets are aligned on a common reference
        grid before metric computation.

        Parameters
        ----------
        cfgdatamining : Dict[str, Any]
            Dictionary of user-defined settings controlling the interpolation process.
            Expected keys include:
            - `interpol_method`: method name (e.g., 'bilinear', 'conservative1st')
            - `targetgrid_horizontal`, `targetgrid_vertical`
            - `targettime_fullspan`, `target_EvalFrequency`, etc.

        GridOperaToUse : Dict[str, Union[DataMiningGridded, DataMiningStation]]
            Dictionary containing interpolation operator instances, typically selected
            based on the dataset type (gridded vs. station).

        DataProgsToUse : Dict[str, Union[CDO, NCO, NCSYS, PyXarray]]
            Dictionary of tool interfaces for performing regridding and data manipulation.

        interpol_refgridf : str
            Path to the NetCDF file that defines the target horizontal reference grid.

        interpol_refgridtype : str
            Type of horizontal grid to be used for interpolation (e.g., 'regular', 'gaussian').

        interpol_refvertf : Any
            Vertical reference file (NetCDF or auxiliary format) used if vertical interpolation is required.

        interpol_reflevtype : Any
            Vertical level type used in interpolation (e.g., 'pressure', 'model').

        evalparas : List[str]
            List of evaluation variable names (e.g., ['tas', 'pr']) to be interpolated.

        interpol_refevalpars : Any
            Parameter mapping or configuration related to interpolation of specific variables.

        resultdir : str
            Path to the directory where the interpolated outputs will be saved.
        """
        self.RecentResFiles: List[Any] = []
        self.RelevantFiles_ForRepair: List[Any] = []

        if (interpol_refgridtype is None and interpol_reflevtype is None):
            logger.info(
                'There is no wish for a h/v interpolation by the user at all or '
                'the leveltypes were not defined.'
            )
            for datafile in self.PreparedFiles:
                # -- Create output_name (WP02 final):
                outputname = self.__generate_output_path(datafile, resultdir, 'FinalEvalGrid')

                self.CheckMoveOrCopyInitialFiles(
                    filesource = datafile,
                    filetarget = outputname,
                    linkToOld = True,
                )
                self.RecentResFiles.append(outputname)

        elif ((interpol_reflevtype is None and self.eval_refgridhor) or
              (interpol_refgridtype is None and self.eval_refvertb) or
              (self.eval_refgridhor and self.eval_refvertb)):
            logger.info(
                f'The dataset {self.getName()} holds the target grid in '
                f'horizontal direction and a vertical interpolation was not asked'
                f'- or the other way around or the dataset holds both target grids.'
            )

            for datafile in self.PreparedFiles:
                # -- Create output_name (WP02 final):
                outputname = self.__generate_output_path(datafile, resultdir, 'FinalEvalGrid')

                self.CheckMoveOrCopyInitialFiles(
                    filesource = datafile,
                    filetarget = outputname,
                    linkToOld = True,
                )
                self.RecentResFiles.append(outputname)
            # -- Reset here because otherwise protectvarnames contain information
            #    from old files and dirs
            self.UpdateAttributes(Protect_varnames = {}, Protect_attrib = [])

        elif (not self.eval_refgridhor or not self.eval_refvertb):
            for datafile in self.PreparedFiles:
                logger.debug(
                    f'Interpolation for {datafile}, method = {cfgdatamining["interpol_method"]}'
                )
                # -- Create output_name (WP02 final):
                outputname = self.__generate_output_path(datafile, resultdir, 'FinalEvalGrid')

                fileug_hor, fileug_ver = GridOperaToUse[self.typeGRID].GridInterpolation(
                    cfgdatamining,
                    DataProgsToUse,
                    self.cfgdataset,
                    datafile,
                    interpol_refgridf,
                    interpol_refgridtype,
                    interpol_refvertf,
                    interpol_reflevtype,
                    self.getVarNamelist(evalparas),
                    interpol_refevalpars,
                    outputname,
                    tmpfile = False,
                )
                if fileug_hor is None and fileug_ver is None:
                    self.CheckMoveOrCopyInitialFiles(
                        filesource = datafile,
                        filetarget = outputname,
                        linkToOld = False,
                    )
                else:
                    logger.info('Interpolation finished.')
                self.RecentResFiles.append(outputname)

            # -- The attributes+varnames to repair are reinitialized because
            #    interpolated dataset may have different attributes
            self.UpdateAttributes(
                Typegrid = interpol_refgridtype,
                TypeLevel = interpol_reflevtype,
                Protect_varnames = {},
                Protect_attrib = [],
                refgrid_b = True if (interpol_refgridtype is not None) else None,
                refvert_b = True if (interpol_reflevtype is not None) else None,
            )
            logger.info("Dataset attributes were adapted to reference grid")

        self.RelevantFiles_ForRepair = self.RecentResFiles

    @log_function_name
    def RepairNcdfVarsAndAttributes(
        self: 'Dataset',
        DataProgsToUse: Dict[str, Union[CDO, NCO, NCSYS, PyXarray]],
        replevel: int,
        filelist: List[str],
    ) -> None:
        """
        Restore original variable names and NetCDF attributes for a list of files.

        This function reverts modifications that may have been applied to variable names,
        units, metadata, or coordinate conventions during preprocessing steps such as
        merging, regridding, or slicing. It is typically used as a post-processing fix
        to ensure standard compliance (e.g., CMOR, CF conventions) or to align with
        external expectations.

        Parameters
        ----------
        DataProgsToUse : Dict[str, Union[CDO, NCO, NCSYS, PyXarray]]
            Dictionary of tool interfaces (e.g., CDO, NCO) for editing NetCDF content.

        replevel : int
            Verbosity or repair level that defines how strict or deep the correction should go.
            For example:
            - `0` may apply only essential renaming.
            - `1+` may include full CF compliance repair.

        filelist : List[str]
            List of NetCDF file paths to be repaired in place or saved with corrected metadata.

        Notes
        -----
        Typical repairs include:
        - Renaming internal variable IDs to match expected long names or CF-compliant names.
        - Reinstating missing attributes (units, standard_name, long_name).
        - Fixing dimension order or coordinate naming inconsistencies.

        Use this step after any transformation that could affect the metadata integrity.
        """
        # -- Local variables (load class objects):
        if isinstance(DataProgsToUse["nco"], NCO):
            nco_object = DataProgsToUse["nco"]
        if isinstance(DataProgsToUse["pyxarray"], PyXarray):
            pyxarray_object = DataProgsToUse["pyxarray"]

        for datafile in filelist:
            logger.debug(
                f'Repair the file {datafile} using the repair level {replevel}')
            # -- Missing variables are always added:
            if replevel in (1, 2):
                for varname in self.Protect_VarNames.keys():
                    contpro, h = pyxarray_object.FindVarName(datafile, varname)
                    # -- Protected variable is not in file:
                    if not contpro:
                        logger.debug(
                            f'Copy the protected variable {varname} '
                            f'from the file {self.Protect_VarNames[varname]}'
                        )
                        try:
                            nco_object.CopyVariableFile2File(
                                source = self.Protect_VarNames[varname],
                                targetf = datafile,
                                param = varname,
                            )
                        except:
                            pass
                    else:
                        logger.debug(f"The protected variable '{varname}' already inside")

            # -- Attributes are added in case of high repair level:
            if replevel == 2:
                if self.Protect_Attributes:
                    vargroup, attribgroup, valuegroup = [], [], []
                    for attrgroup in self.Protect_Attributes:
                        # -- Remove attributes which are already there or variable to attribute is missing
                        contpro, h = pyxarray_object.FindVarName(
                            datafile, attrgroup[0],
                        )
                        if (contpro and not nco_object.FindAttributes(
                                datafile, attributes = [attrgroup[1]], varname = attrgroup[0])):
                            vargroup.append(attrgroup[0])
                            attribgroup.append(attrgroup[1])
                            valuegroup.append(attrgroup[2])
                            logger.debug(
                                f'Have to create attribute "{str(attrgroup[1])}" '
                                f'having value {str(attrgroup[2])} " to variable "{str(attrgroup[0])}'
                            )

                    if vargroup and attribgroup and valuegroup:
                        try:
                            nco_object.PutAttribute(
                                datafile,
                                vargroup,
                                attribgroup,
                                valuegroup,
                                AttrType = 'c',
                                mode = 'c',
                            )
                        except:
                            pass
                else:
                    logger.debug('No attributes to protect in this dataset.')

    @log_function_name
    def ChangeFrequency(
        self: 'Dataset',
        DataProgsToUse: Dict[str, Union[CDO, NCO, NCSYS, PyXarray]],
        evalparas: List[str],
        filelist: List[str],
        resultdir: str,
        cfgRestime: Dict[str, str],
        posdimnames: Dict[str, List[str]],
        cfgrollingm: Optional[str] = None,
        refgrid_time: Optional[str] = None,
        refgrid_timevars: Optional[List[str]] = None,
    ) -> None:
        """
        Adjust the temporal resolution of the dataset to match a target frequency.

        This method harmonizes time coordinates across variables using user-defined
        settings, including resampling strategy, rolling means, and optional alignment
        to a reference temporal grid. It ensures all data conforms to the frequency
        expected by downstream evaluation workflows.

        Parameters
        ----------
        DataProgsToUse : Dict[str, Union[CDO, NCO, NCSYS, PyXarray]]
            Dictionary of available backend tools for NetCDF processing.

        evalparas : List[str]
            List of variable names (e.g., ['tas', 'pr']) to be resampled.

        filelist : List[str]
            List of NetCDF file paths to be harmonized.

        resultdir : str
            Directory where processed output files will be written.

        cfgRestime : Dict[str, str]
            Dictionary specifying the resampling method and frequency.
            Example:
            ```python
            {
                "method": "resample",  # or "interp", "agg"
                "freq": "monthly",
                "how": "mean"
            }
            ```

        posdimnames : Dict[str, List[str]]
            Dictionary specifying which names correspond to time, spatial, or vertical dimensions.

        cfgrollingm : Optional[str], default=None
            Variable name from NetCDF file to apply a rolling mean (if desired).

        refgrid_time : Optional[str], default=None
            Path to a NetCDF file that defines a reference time grid to align all variables to.

        refgrid_timevars : Optional[List[str]], default=None
            List of time-related variable names (e.g., ['time', 'leadtime']) from the reference grid.

        Notes
        -----
        This method ensures all temporal dimensions follow the same structure and frequency.

        Supports:
        ----------------------------
        - Resampling to daily/monthly/seasonal using "mean", "sum", etc.
        - Rolling window smoothing if `cfgrollingm` is specified.
        - Temporal alignment to external reference grids (e.g., reanalysis calendar).
        """
        # -- Local variables (load class objects):
        if isinstance(DataProgsToUse["pyxarray"], PyXarray):
            pyxarray_object = DataProgsToUse["pyxarray"]

        NewResFiles = []
        for datafile in filelist:
            # -- Create an output file name:
            outputname = self.__generate_output_path(datafile, resultdir, "EvalFrequency")

            if (cfgRestime["method"] == "-" or
                    (cfgRestime["method"] == "reselect" and self.eval_timerefgrid is True)):
                logger.debug(f'{datafile} does not require aggregation')
                self.CheckMoveOrCopyInitialFiles(
                    filesource = datafile,
                    filetarget = outputname,
                    linkToNew = True,
                )
            else:
                '''
                Only a temporal operation has to be done -> no grid dependent operator
                (DataMiningGD) has to be called as in CondenseDimensions:
                GridOperaToUse[self.typeGRID].SpatialTemporalOpera
                '''
                outputname = pyxarray_object.OperaSpatialTemporal(
                    filein = datafile,
                    fileout = outputname,
                    evalvars = self.getVarNamelist(evalparas),
                    cfgRestime = cfgRestime,
                    cfgrollingm = cfgrollingm,
                    spatialopx = None,
                    spatialopy = None,
                    spatialopz = None,
                    refgrid_time = refgrid_time,
                    refgrid_timevars = refgrid_timevars,
                    posdimnames = posdimnames,
                    varsprot = self.Protect_VarNames.keys(),
                )
            NewResFiles.append(outputname)
        self.RecentResFiles = NewResFiles

    @log_function_name
    def CondenseDimensions(
        self: 'Dataset',
        DataProgsToUse: Dict[str, Union[CDO, NCO, NCSYS, PyXarray]],
        GridOperaToUse: Dict[str, Union[DataMiningGridded, DataMiningStation]],
        evalparas: List[str],
        filelist: List[str],
        resultdir: str,
        cfgRestime: Dict[str, str],
        posdimnames: Dict[str, List[str]],
        cfgrollingm: Optional[Any] = None,
        opera_x: Optional[Any] = None,
        opera_y: Optional[Any] = None,
        opera_z: Optional[Any] = None,
    ) -> None:
        """
        Condense spatial and/or temporal dimensions of NetCDF datasets using specified operations.

        This method performs reductions (e.g., mean, sum) over dimensions like time, latitude,
        longitude, and level. It is designed to prepare datasets for comparison, visualization,
        or further statistical analysis by aggregating them into simplified forms.

        Parameters
        ----------
        DataProgsToUse : Dict[str, Union[CDO, NCO, NCSYS, PyXarray]]
            Dictionary mapping tool names to available processing backends.

        GridOperaToUse : Dict[str, Union[DataMiningGridded, DataMiningStation]]
            Mapping to specialized preprocessing classes for interpolation or masking.

        evalparas : List[str]
            List of variable names (e.g., ['tas', 'pr', 'hfls']) to be processed.

        filelist : List[str]
            List of paths to NetCDF files whose dimensions will be condensed.

        resultdir : str
            Output directory where condensed NetCDF files will be written.

        cfgRestime : Dict[str, str]
            Configuration for temporal aggregation. Example:
            ```python
            {
                "method": "resample",
                "freq": "monthly",
                "how": "mean"
            }
            ```

        posdimnames : Dict[str, List[str]]
            Dictionary mapping logical dimension types (e.g., 'time', 'spatial') to actual names used in files.
            Example:
            ```python
            {
                "time": ["time"],
                "spatial": ["lon", "lat"],
                "vertical": ["level", "height"]
            }
            ```

        cfgrollingm : Optional[Any], default=None
            Optional configuration for applying rolling means prior to reduction.

        opera_x : Optional[Any], default=None
            Operation to apply over the X (longitude) dimension. Example: 'mean', 'sum'.

        opera_y : Optional[Any], default=None
            Operation to apply over the Y (latitude) dimension. Example: 'mean', 'max'.

        opera_z : Optional[Any], default=None
            Operation to apply over the Z (vertical) dimension. Example: 'max', 'integrate'.

        Notes
        -----
        This method supports flexible aggregation across user-specified axes.

        - Use this to reduce datasets for metrics like "spatial average", "zonal profile", or "temporal trends".
        - Dimension reduction is often the final preprocessing step before evaluation.

        All files in `filelist` should be structured consistently and have the same dimension naming conventions.
        """
        NewResFiles = []

        for datafile in filelist:
            logger.debug(
                f"Condensation starts for file {datafile} using settings "
                f"(temporal/spatialx/spatialy/spatialz): {cfgRestime}/{opera_x}/{opera_y}/{opera_z}"
            )
            # -- Create an output file name (final name for 2D maps on WP03 stage):
            outputname = self.__generate_output_path(datafile, resultdir, "CondenseDimensions")
            # -- Run SpatialTemporalOpera (can be improved):
            file_CondenseDims = GridOperaToUse[self.typeGRID].SpatialTemporalOpera(
                DataProgsToUse,
                filein = datafile,
                fileout = outputname,
                evalvars = self.getVarNamelist(evalparas),
                cfgRestime = cfgRestime,
                posdimnames = posdimnames,
                cfgrollingm = cfgrollingm,
                oper_x = opera_x,
                oper_y = opera_y,
                oper_z = opera_z,
                varsprot = self.Protect_VarNames.keys(),
            )
            NewResFiles.append(file_CondenseDims)
        self.RecentResFiles = NewResFiles

    @log_function_name
    def RecomputeQuant(
        self: 'Dataset',
        compute_type = None,
        DataProgsToUse = None,
        evalparas = None,
        dictPossDimNames = None,
        filelist = None,
        resultdir = None,
        evalparadd = None,
    ) -> None:
        """
        Recompute derived quantities from existing NetCDF datasets using PyXarray-based methods.

        This function is used to apply custom post-processing computations (e.g., derived variables,
        unit conversions, or diagnostics) based on existing parameters. The result is a set of
        new NetCDF files containing the recomputed variables.

        Parameters
        ----------
        compute_type : Optional[Any], default=None
            A flag or string that identifies the type of recomputation to perform.
            This is passed to the `PyXarray.RecomputeQuant` method.

        DataProgsToUse : Optional[Dict[str, Union[CDO, NCO, NCSYS, PyXarray]]], default=None
            Dictionary of data processing tool instances used throughout EvaSuite.
            Must contain the key `"pyxarray"` mapped to a valid `PyXarray` instance.

        evalparas : Optional[List[str]], default=None
            List of primary evaluation variable names (e.g., `['tas', 'hurs']`) to be recomputed.

        dictPossDimNames : Optional[Dict[str, List[str]]], default=None
            Dictionary of possible dimension names for each logical axis (e.g. time, space, vertical).
            Used to interpret and remap dimensions inside PyXarray.

        filelist : Optional[List[str]], default=None
            List of input NetCDF file paths to be processed.

        resultdir : Optional[str], default=None
            Output directory where recomputed files will be saved.

        evalparadd : Optional[Any], default=None
            Additional evaluation parameters required by the PyXarray recomputation logic.

        Notes
        -----
        This method is currently **not fully tested** in EvaSuite.
        If you use it, please report your configurations to the developers for validation.

        - Files are passed to the `PyXarray.RecomputeQuant()` function for transformation.
        - Resulting files are stored in the specified `resultdir` with `_recomp` appended.
        - Newly created variable metadata is added to the internal bibliographic tracking system
          via `self.UpdateAttributes(BibParamdict=...)`.

        Example
        -------
        >>> dataset.RecomputeQuant(
        ...     compute_type="dew_point",
        ...     DataProgsToUse={"pyxarray": PyXarray()},
        ...     evalparas=["tas", "hurs"],
        ...     filelist=["tas_file.nc", "hurs_file.nc"],
        ...     resultdir="/output/recomputed"
        ... )
        """
        logger.warning(
            "EvaSuite Warning: You are using an untested function.\n"
            "If possible, please send your configuration files to: "
            "evgenii.churiulin@kit.edu for testing and validation support."
        )
        # -- Local variables (load class objects):
        if isinstance(DataProgsToUse["pyxarray"], PyXarray):
            pyxarray_object = DataProgsToUse["pyxarray"]

        NewResFiles = []
        newvardict = {}

        for datafile in filelist:
            logger.info(f'Recomputation of quantities starts for file {datafile}')
            #
            outputname = os.path.join(
                resultdir, f"{os.path.basename(datafile)}_recomp"
            )
            file_Recomp, newvarsfile = pyxarray_object.RecomputeQuant(
                compute_type,
                filein = datafile,
                fileout = outputname,
                evalvars = self.getVarNamelist(evalparas),
                levtype = self.typeVERT,
                dictDims = dictPossDimNames,
                datset = self,
                evalparadd = evalparadd,
            )
            newvardict.update(newvarsfile)
            NewResFiles.append(file_Recomp)
        # -- Update attributes:
        self.UpdateAttributes(BibParamdict = newvardict)
        self.RecentResFiles = NewResFiles

    @log_function_name
    def UpdateAttributes(
        self: 'Dataset',
        RecResFiles: Optional[Any] = None,
        BibParamdict: Optional[Any] = None,
        Typegrid: Optional[str] = None,
        TypeLevel: Optional[Any] = None,
        Protect_varnames: Optional[Dict[Any, Any]] = None,
        Protect_attrib: Optional[List[str]] = None,
        refgrid_b: Optional[bool] = None,
        refvert_b: Optional[bool] = None,
        eval_timerefgrid: Optional[Any] = None,
        ReinitCfgSettings: Optional[bool] = False,
    ) -> None:
        """
        Update internal metadata and attributes of the dataset based on processed results.

        This method is responsible for adjusting the dataset's configuration, metadata,
        and bibliographic information after operations like interpolation, recomputation,
        or other transformations. It can also protect certain variable names or attributes
        from being overwritten and reset selected configuration values if required.

        Parameters
        ----------
        RecResFiles : Optional[Any], default=None
            A list or object representing recently generated result files that should be
            recorded as part of the dataset’s output state.

        BibParamdict : Optional[Any], default=None
            Dictionary containing variable names and associated bibliographic metadata
            (e.g., units, standard names, processing info). Used to update internal citation tracking.

        Typegrid : Optional[str], default=None
            Describes the horizontal grid type of the dataset (e.g., `"regular"`, `"unstructured"`).
            If provided, updates the dataset's grid type metadata.

        TypeLevel : Optional[Any], default=None
            Describes the vertical coordinate system or level type (e.g., pressure levels, height levels).

        Protect_varnames : Optional[Dict[Any, Any]], default=None
            Dictionary of variable names that should be preserved during attribute updates.
            Used to avoid overwriting specific variables.

        Protect_attrib : Optional[List[str]], default=None
            List of attribute names (e.g., `"units"`, `"standard_name"`) that should not be changed
            even if new metadata is available.

        refgrid_b : Optional[bool], default=None
            If `True`, the current dataset is considered the horizontal reference grid.

        refvert_b : Optional[bool], default=None
            If `True`, the current dataset is considered the vertical reference grid.

        eval_timerefgrid : Optional[Any], default=None
            Optional time reference metadata (e.g., reference time grid file or values).

        ReinitCfgSettings : Optional[bool], default=False
            If `True`, resets or reinitializes part of the configuration settings in the dataset
            to reflect the updated structure or metadata.

        Notes
        -----
        - This function acts as a central place to refresh or finalize internal metadata after
          major transformation steps.
        - Can be called multiple times throughout the workflow, e.g., after interpolation,
          temporal harmonization, or recomputation.
        - Metadata protection flags (`Protect_varnames`, `Protect_attrib`) allow safe updates.

        Example
        -------
        >>> dataset.UpdateAttributes(
        ...     RecResFiles=["regridded_output.nc"],
        ...     BibParamdict={"tas": {"units": "K", "standard_name": "air_temperature"}},
        ...     Typegrid="regular",
        ...     Protect_attrib=["units"]
        ... )
        """
        if ReinitCfgSettings is True:
            self.cfgdataset = {}
        # -- Special handling:
        if RecResFiles is not None:
            self.RecentResFiles = GeneralUtils.check_for_list(RecResFiles)
        if BibParamdict is not None:
            self.cfgdataset["paramdict"] = BibParamdict

        # -- Simple assignments (only if provided):
        updates = {
            "typeGRID": Typegrid,
            "typeVERT": TypeLevel,
            "eval_refgridhor": refgrid_b,
            "eval_refvertb": refvert_b,
            "Protect_VarNames": Protect_varnames,
            "Protect_Attributes": Protect_attrib,
            "eval_timerefgrid": eval_timerefgrid,
        }
        for attr, value in updates.items():
            if value is not None:
                setattr(self, attr, value)

    @log_function_name
    def StoreDSMetaDataInFile(self: 'Dataset') -> Dict[str, Any]:
        """
        Collect and return the dataset metadata needed to reproduce an EvaSuite run.

        This method assembles a dictionary of the essential dataset/evaluation configuration
        so the pipeline can be re-run, audited, or restored later. The returned mapping is
        suitable for serialization (e.g., JSON/YAML) by the caller.

        Returns
        -------
        Dict[str, Any]
            Dictionary with the same keys/values as the legacy implementation:
            - typeEP
            - typeGRID
            - eval_refgridhor
            - eval_origrefgrid
            - Protect_VarNames
            - Protect_Attributes
            - RecentResFiles
        """
        return {
            "typeEP": self.typeEP,
            "typeGRID": self.typeGRID,
            "eval_refgridhor": self.eval_refgridhor,
            "eval_origrefgrid": self.eval_origrefgrid,
            "Protect_VarNames": self.Protect_VarNames,
            "Protect_Attributes": self.Protect_Attributes,
            "RecentResFiles": self.RecentResFiles,
        }

    @log_function_name
    def LoadDSMetaDataFromFile(self: 'Dataset', loadedDSbib: Dict[str, Any]) -> None:
        """
        Reload metadata about preprocessed datasets from a previous EvaSuite run.

        This method restores dataset metadata stored during a prior evaluation or preprocessing phase.
        It allows the evaluation pipeline to resume or replicate a run based on previously saved
        file mappings, variable adjustments, or evaluation configurations.

        Parameters
        ----------
        loadedDSbib : Dict[str, Any]
            A dictionary containing stored metadata about previously processed datasets.
            This typically includes:
            - File paths
            - Variable transformations
            - Derived quantities
            - Bibliographic info for attributes

        Notes
        -----
        This function is intended to be used alongside `StoreDSMetaDataInFile` to support:
        - Restartable or reproducible evaluation workflows
        - Modular pipeline stages without full recomputation
        - Version tracking and consistency across SLURM batches
        """
        required_keys = (
            "typeEP",
            "typeGRID",
            "eval_refgridhor",
            "eval_origrefgrid",
            "Protect_VarNames",
            "Protect_Attributes",
            "RecentResFiles",
        )
        missing = [k for k in required_keys if k not in loadedDSbib]
        if missing:
            raise KeyError(f"Missing dataset metadata keys: {missing}")

        for key in required_keys:
            setattr(self, key, loadedDSbib[key])

    @log_function_name
    def CheckMoveOrCopyInitialFiles(
        self: 'Dataset',
        filesource: str,
        filetarget: str,
        linkToOld: Optional[bool] = False,
        linkToNew: Optional[bool] = False,
    ) -> None:
        """
        Move or copy NetCDF or related files to a target location, with optional symlink creation.

        This method ensures files are transferred safely depending on their source:
        - If the source file is located within the original storage directory (as defined in
          `self.cfgdataset["storagedir"]`), the file is **copied** to avoid permission or safety issues.
        - Otherwise, the file is **moved** to the target location.

        Additionally, symbolic links can be created to maintain references between original
        and new locations, depending on user flags.

        Parameters
        ----------
        filesource : str
            Absolute path to the source file that needs to be moved or copied.
        filetarget : str
            Absolute path to the destination where the file should be placed.
        linkToOld : bool, optional
            If True, create a symlink at the original location pointing to the new location after moving.
        linkToNew : bool, optional
            If True, create a symlink at the new location pointing to the original location.

        Notes
        -----
        - `linkToOld` and `linkToNew` are mutually exclusive.
        - The method uses `shutil.copy2` for copying (preserving metadata).
        - This is useful in shared HPC environments to avoid modifying read-only reference storage.

        Examples
        --------
        >>> dataset.CheckMoveOrCopyInitialFiles(
        ...     filesource='/scratch/tmp/data.nc',
        ...     filetarget='/results/final/data.nc',
        ...     linkToOld=True
        ... )
        """
        src_dir = os.path.dirname(os.path.abspath(filesource))
        init_dir = os.path.dirname(os.path.abspath(self.cfgdataset["storagedir"]))

        logger.debug("Checking file move/copy conditions:")
        logger.debug(f" - Source directory: {src_dir}")
        logger.debug(f" - Initial storage dir:{init_dir}")

        if src_dir == init_dir or init_dir in src_dir:
            logger.info(
                f"File {filesource} is located in an initial storage dir → "
                f"copying instead of moving (permissions safety)."
            )
            shutil.copy2(filesource, filetarget)
        else:
            logger.info(
                f"File {filesource} is not in the initial storage dir → moving is allowed."
            )
            if not linkToNew:
                shutil.move(filesource, filetarget)

            if linkToOld:
                if not os.path.exists(filesource):
                    os.symlink(filetarget, filesource)
                    logger.info(f"Symlink created: {filesource} → {filetarget}")
                else:
                    logger.warning(f"Skipped linkToOld: {filesource} already exists.")

            elif linkToNew:
                if not os.path.exists(filetarget):
                    os.symlink(filesource, filetarget)
                    logger.info(f"Symlink created: {filetarget} → {filesource}")
                else:
                    logger.warning(f"Skipped linkToNew: {filetarget} already exists.")

    @log_function_name
    def CheckInternalZip(
        self: 'Dataset',
        fnamein: str,
        resultdir: str,
        progobj: Dict[str, Union[CDO, NCO, NCSYS, PyXarray]],
        variable: str,
        suffix: Optional['str'] = '',
    ) -> Tuple[str, bool]:
        """
        Detect and decompress internally zipped NetCDF files for efficient evaluation.

        This method checks whether the NetCDF file is internally compressed (e.g., using zlib).
        If compression is detected, it decompresses the file and stores the unzipped version
        in the specified output directory. This ensures faster read performance and compatibility
        with tools that may not handle internal compression well.

        Parameters
        ----------
        fnamein : str
            Absolute path to the input NetCDF file.
        resultdir : str
            Directory to store the uncompressed version if decompression is needed.
        progobj : Dict[str, Union[CDO, NCO, NCSYS, PyXarray]]
            Dictionary of initialized utility classes used in EvaSuite. Expects `ncsys` key for compression checks.
        variable : str
            Name of the variable inside the NetCDF file to check for compression.
        suffix : Optional[str], default=""
            Optional suffix to append to the output file name.

        Returns
        -------
        Tuple[str, bool]
            - Path to the file that will be used (original or unzipped copy).
            - Boolean indicating whether decompression was applied (`True` if unzipped).
        """
        # -- Local variables (load class objects):
        if isinstance(progobj["ncsys"], NCSYS):
            ncsys_object = progobj["ncsys"]
        #
        lintzipped = ncsys_object.DeflateCheck(filein = fnamein, variable = variable)

        if lintzipped:
            logger.info(
                'The relevant file is internally zipped, for correct calculations '
                'and speedup its unzipped'
            )
            dataunzipped = os.path.join(
                resultdir, f"{os.path.basename(fnamein)}_Unzipped{suffix}")
            ncsys_object.DeflateNcdf(filein = fnamein, fileout = dataunzipped)
        else:
            dataunzipped = fnamein
        return dataunzipped, lintzipped

    @log_function_name
    def checkExternalZip(
        self: 'Dataset',
        filelist: List[str],
        resultdir: str
    ) -> List[str]:
        """
        Check and unzip externally compressed NetCDF files using gunzip or pgzip.

        This method scans a list of input files. If any are found to be externally zipped
        (e.g., `.gz`, `.pgz`), it decompresses them into the given result directory.
        Files that are not compressed are passed through unchanged.

        Parameters
        ----------
        filelist : List[str]
            List of file paths to check for external compression.
        resultdir : str
            Directory where uncompressed files will be written (if needed).

        Returns
        -------
        List[str]
            A list of paths to usable (uncompressed) NetCDF files.
            Original uncompressed files are reused; compressed ones are replaced with the unzipped versions.
        """
        finallist = []
        for file, countf in zip(filelist, range(len(filelist))):
            gzipfile = GeneralUtils.CheckGzip(file = file)
            if gzipfile:
                logger.info(f'The file {file} is externally zipped and needs to be extracted')
                gunzipfn = GeneralUtils.Gunzip(
                    file = file, resultdir = resultdir, suffix = str(countf),
                )
                finallist.append(gunzipfn)
            else:
                finallist.append(file)
        return finallist

    @log_function_name
    def getEPTypeOfData(self: 'Dataset') -> str:
        """ Return typeEP values of 'Dataset' class: """
        return self.typeEP

    @log_function_name
    def getGridtype(self: 'Dataset') -> str:
        """ Return typeGRID values of 'Dataset' class: """
        return self.typeGRID

    @log_function_name
    def getLevtype(self: 'Dataset'):
        """ Return typeVERT values of 'Dataset' class: """
        return self.typeVERT

    @log_function_name
    def getRefgrid(self: 'Dataset'):
        """Return the value of eval_refgridhor."""
        return self.eval_refgridhor

    @log_function_name
    def getOrigRefgrid(self: 'Dataset'):
        """ Return eval_origrefgrid values of 'Dataset' class: """
        return self.eval_origrefgrid

    @log_function_name
    def getRefVert(self: 'Dataset'):
        """ Return eval_refvertb values of 'Dataset' class: """
        return self.eval_refvertb

    @log_function_name
    def getName(self: 'Dataset'):
        """ Return name values of 'Dataset' class: """
        return self.name

    @log_function_name
    def getCfgSettings(self: 'Dataset'):
        """ Return cfgdataset values of 'Dataset' class: """
        return self.cfgdataset

    @log_function_name
    def getCfgParamDict(self: 'Dataset'):
        """ Return cfgdataset["paramdict"] values of 'Dataset' class: """
        return self.cfgdataset["paramdict"]

    @log_function_name
    def getEvalBase(self: 'Dataset'):
        """ Return DSevalbase values of 'Dataset' class: """
        return self.DSevalbase

    @log_function_name
    def getDStoProof(self: 'Dataset'):
        """ Return DStoproof values of 'Dataset' class: """
        return self.DStoproof

    @log_function_name
    def getDSskillref(self: 'Dataset'):
        """ Return DSskillref values of 'Dataset' class: """
        return self.DSskillref

    @log_function_name
    def getOrigDataFil(self: 'Dataset', evalparas: List[str]) -> List[str]:
        """Example of input evalparas variable: evalparas = ['hlrs']"""
        filstruct = self.cfgdataset["storagefil"]
        if isinstance(filstruct, dict):
            varnames = self.getVarNamelist(evalparas)
            files = []
            for varn in varnames:
                if isinstance(filstruct[varn], str):
                    files.append(filstruct[varn])
                else:
                    files.extend(filstruct[varn])
            return files
        elif isinstance(filstruct, str):
            return [filstruct]
        else:
            return filstruct

    @log_function_name
    def getVarNamelist(
        self: 'Dataset', evalparas: List[str], metrickey: Optional[Any] = None,
    ) -> List[str]:
        """
        Retrieves a list of variable names based on a list of evaluation parameters.

        If no `metrickey` is provided, it looks up each `varname` in `self.cfgdataset["paramdict"]`
        and collects the corresponding value(s). Values may be strings or lists of strings.

        Parameters:
        ------------
            evalparas (List[str]): A list of variable names to look up.
            metrickey (Optional[Any]): If provided, currently ignored. Reserved for future use.

        Returns:
        ------------
            List[str]: A list of variable names gathered from the paramdict entries.
        """
        VarNamelist = []
        for varname in evalparas:
            for help1 in self.cfgdataset["paramdict"].keys():
                helptype = type(help1)
            if helptype is tuple:
                if metrickey is not None:
                    entry = GeneralUtils.safe_access_bib(
                        "",
                        KeyError,
                        dicttest = self.cfgdataset["paramdict"],
                        dictkey = (varname, metrickey),
                        errhandle = False,
                    )
                else:
                    entry = []
                    for help2 in self.cfgdataset["paramdict"].keys():
                        if help2[0] == varname:
                            entry.append(
                                GeneralUtils.safe_access_bib(
                                    "",
                                    KeyError,
                                    dicttest = self.cfgdataset["paramdict"],
                                    dictkey = help2,
                                    errhandle = False,
                                )
                            )
            else:
                entry = GeneralUtils.safe_access_bib(
                    "",
                    KeyError,
                    dicttest = self.cfgdataset["paramdict"],
                    dictkey = varname,
                    errhandle = False,
                ) if metrickey is None else None

            if isinstance(entry, list):
                VarNamelist.extend(entry)
            elif isinstance(entry, str):
                VarNamelist.append(entry)
        return VarNamelist

    @log_function_name
    def getEvalPara2VarName(self: 'Dataset', varname):
        """ Returns the evaluation parameters to a specific variable name """
        logger.warning(
            "EvaSuite Warning: You are using an untested function.\n"
            "If possible, please send your configuration files to: "
            "evgenii.churiulin@kit.edu for testing and validation support."
        )
        return list(self.cfgdataset["paramdict"].keys())[list(self.cfgdataset["paramdict"].values()).index(varname)]

    @log_function_name
    def getListOfVarsToCorrect(
        self: 'Dataset',
        varnames: Optional[List[str]] = None,
        listofVardicts: Optional[bool] = False,
    ) -> Union[
        Tuple[List[str], None],
        Tuple[bool, Dict[str, Any]],
        Tuple[None, None],
    ]:
        """
            Returns a List of Variable names to correct for their units; if
            varnames is given only those variables are returned which have to
            be corrected for units:
        """
        # -- Local variables:
        if listofVardicts:
            Vardictaslist = {}

        # -- Get actual values from dictionary:
        cfg_paramcorr = GeneralUtils.safe_access_bib(
            "",
            KeyError,
            dicttest=self.cfgdataset,
            dictkey="paramcorr",
            errhandle=False
        )

        if cfg_paramcorr is not None:
            logger.info(f"'cfg_paramcorr' is active. Values: {cfg_paramcorr}")

            if varnames is None:
                varkeysrel = list(cfg_paramcorr.keys())
            else:
                varnames_checked = GeneralUtils.check_for_list(varnames)
                varkeysrel = list(set(cfg_paramcorr).intersection(varnames_checked))

            varcorrlist = []
            for varkey in varkeysrel:
                key_unitcor = cfg_paramcorr[varkey].get("unitcor")
                key_timeshift = cfg_paramcorr[varkey].get("timeshift")
                if key_unitcor or key_timeshift:
                    varcorrlist.append(varkey)
                    Vardictaslist[varkey] = cfg_paramcorr[varkey]
        else:
            logger.info("No 'paramcorr' block found in cfgdataset.")
            varcorrlist = None

        if not listofVardicts:
            return varcorrlist, None
        else:
            return not(bool(varcorrlist)), Vardictaslist

    @log_function_name
    def getSubDirs(self: 'Dataset'):
        """ Return subdirs_datset values of 'Dataset' class: """
        return self.subdirs_datset

    @log_function_name
    def getPreparedFiles(self: 'Dataset'):
        """ Return PreparedFiles values of 'Dataset' class: """
        return self.PreparedFiles

    @log_function_name
    def getRecentResFiles(
        self: 'Dataset',
        metrickey: Optional[str] = None,
        allfiles: Optional[bool] = False,
    ) -> List[str]:
        """ Get actual path for output files: """
        if not(allfiles):
            if metrickey is not None and isinstance(self.RecentResFiles, dict):
                return self.RecentResFiles[metrickey]
            else:
                return GeneralUtils.check_for_list(self.RecentResFiles)
        else:
            if not isinstance(self.RecentResFiles, dict):
                return GeneralUtils.check_for_list(self.RecentResFiles)
            else:
                filelist = []
                for key1 in self.RecentResFiles.keys():
                    # -- Dict:
                    if isinstance(self.RecentResFiles[key1], dict):
                        for key2 in self.RecentResFiles[key1].keys():
                            if isinstance(self.RecentResFiles[key1][key2], dict):
                                filelist.extend(self.RecentResFiles[key1][key2].values())
                            elif isinstance(self.RecentResFiles[key1][key2], list):
                                filelist.extend(self.RecentResFiles[key1][key2])
                            else:
                                filelist.append(self.RecentResFiles[key1][key2])
                    # -- List:
                    elif isinstance(self.RecentResFiles[key1], list):
                        filelist.extend(self.RecentResFiles[key1])
                    # -- Other types:
                    else:
                        filelist.append(self.RecentResFiles[key1])

            return GeneralUtils.check_for_list(filelist)

    @log_function_name
    def getRelevantFiles(self: 'Dataset'):
        """ Return RelevantFiles values of 'Dataset' class: """
        return self.RelevantFiles

    @log_function_name
    def getRelevantFiles_ForRepair(self: 'Dataset'):
        """ Return RelevantFiles_ForRepair values of 'Dataset' class: """
        return self.RelevantFiles_ForRepair

    @log_function_name
    def getProtectVarNames(self: 'Dataset'):
        """ Return Protect_VarNames values of 'Dataset' class: """
        return self.Protect_VarNames

    @log_function_name
    def getProtectAttributes(self: 'Dataset'):
        """ Return Protect_Attributes values of 'Dataset' class: """
        return self.Protect_Attributes
