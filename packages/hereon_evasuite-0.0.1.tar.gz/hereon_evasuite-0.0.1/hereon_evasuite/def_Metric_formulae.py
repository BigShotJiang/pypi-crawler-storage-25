# EvaSuite
#
# ---------------------------------------------------------------
# Copyright (C) 2004-2025, Hereon
# Contact information: beate.geyer@hereon.de, imktro-climate-modelling@lists.kit.edu
# See AUTHORS.TXT for a list of authors
# See LICENSES/ for license information
# SPDX-License-Identifier: Apache-2.0
# ---------------------------------------------------------------

# -- Import Python modules:
import numpy as np
import xarray as xr
import xskillscore as xskill
from scipy.stats import norm
from scipy.stats import t as scipyt
from xhistogram.xarray import histogram
from typing import Any, Optional, Dict, List, Callable, Tuple
from hereon_evasuite.log_EvaSuite import get_logger, log_function_name
from hereon_evasuite.utils_formulae import BSSBootstrap_support, validate_inputs_with_warning
logger = get_logger()


################################################
# DEFS for Units Creations
@log_function_name
def units_rmse(units: Optional[str] = None) -> str:
    """ create a new unit out of the old unit """
    return f'({units})**2'


@log_function_name
def units_stay(units: Optional[str] = None) -> str:
    """ stay with the old unit """
    return units


@log_function_name
def units_one(units: Optional[str] = None) -> str:
    """ the new unit is one"""
    return '1'

################################################
# the metrics with respect to time and space
#
# x: a combined dataset of a single variable
# x[daproof]: dataarray of the data to proof (model)
# x[daref]: dataarray of the reference data (observations)
# x[daskillref]: dataarray of the skill reference (skill scores)


# -- Bias:
@log_function_name
@validate_inputs_with_warning()
def Tbias(
    x: xr.Dataset, daproof: str, daref: str,
    coordtime: Optional[str] = None,
    coordxy: Optional[List[str]] = None,
    option: Optional[Any] = None,
) -> xr.DataArray:
    """
        Input variables:
        ----------------------------
            1. x --> research dataset
            2. daproof -> variable name for stat.analysis (mod)
            3. daref -> variable name for stat.analysis (ref)
            4. coordtime -> NetCDF variable responsible to z-axis (usually time)
            5. coordxy ->  NetCDF variables responsible to x,y-axes (usually lat, lon)
            6. option -> if float -> significance level
                            dic   -> more complicated properties
        Output variables:
        ----------------------------
            1. DataArray with statistical results
    """
    return (x[daproof] - x[daref])


@log_function_name
@validate_inputs_with_warning(require_coordtime=True)
def Tbiasmean(
    x: xr.Dataset, daproof: str, daref: str,
    coordtime: Optional[str] = None,
    coordxy: Optional[List[str]] = None,
    option: Optional[Any] = None,
) -> xr.DataArray:
    return (x[daproof] - x[daref]).mean(dim = coordtime)


@log_function_name
@validate_inputs_with_warning()
def Tbiasnorm(
    x: xr.Dataset, daproof: str, daref: str,
    coordtime: Optional[str] = None,
    coordxy: Optional[List[str]] = None,
    option: Optional[Any] = None,
) -> xr.DataArray:
    return (x[daproof] - x[daref]) / x[daref]


@log_function_name
@validate_inputs_with_warning(require_coordtime=True)
def Tbiasnormmean(
    x: xr.Dataset, daproof: str, daref: str,
    coordtime: Optional[str] = None,
    coordxy: Optional[List[str]] = None,
    option: Optional[Any] = None,
) -> xr.DataArray:
    return ((x[daproof] - x[daref]).mean(dim = coordtime)) / x[daref].mean(dim = coordtime)


@log_function_name
@validate_inputs_with_warning(require_coordxy=True)
def Sbias(
    x: xr.Dataset, daproof: str, daref: str,
    coordtime: Optional[str] = None,
    coordxy: Optional[List[str]] = None,
    option: Optional[Any] = None,
) -> xr.DataArray:
    return (x[daproof] - x[daref]).mean(dim = coordxy)


@log_function_name
@validate_inputs_with_warning(require_coordxy=True, require_coordtime=True)
def Sbiasmean(
    x: xr.Dataset, daproof: str, daref: str,
    coordtime: Optional[str] = None,
    coordxy: Optional[List[str]] = None,
    option: Optional[Any] = None,
) -> xr.DataArray:
    # a temporal aggregation is unusual for spatial metrics
    return ((x[daproof] - x[daref]).mean(dim = coordxy)).mean(dim = coordtime)


@log_function_name
@validate_inputs_with_warning(require_coordxy=True)
def Sbiasnorm(
    x: xr.Dataset, daproof: str, daref: str,
    coordtime: Optional[str] = None,
    coordxy: Optional[List[str]] = None,
    option: Optional[Any] = None,
) -> xr.DataArray:
    return ((x[daproof] - x[daref]).mean(dim = coordxy)) / x[daref].mean(dim = coordxy)


@log_function_name
@validate_inputs_with_warning(require_coordxy=True, require_coordtime=True)
def Sbiasnormmean(
    x: xr.Dataset, daproof: str, daref: str,
    coordtime: Optional[str] = None,
    coordxy: Optional[List[str]] = None,
    option: Optional[Any] = None,
) -> xr.DataArray:
    # a temporal aggregation is unusual for spatial metrics
    return (
        (((x[daproof] - x[daref]).mean(dim = coordxy)).mean(dim = coordtime)) /
        x[daref].mean(dim = coordxy).mean(dim = coordtime)
    )


# -- Mean absolute error:
@log_function_name
@validate_inputs_with_warning()
def Tmae(
    x: xr.Dataset, daproof: str, daref: str,
    coordtime: Optional[str] = None,
    coordxy: Optional[List[str]] = None,
    option: Optional[Any] = None,
):
    return np.fabs(x[daproof] - x[daref])

# -- Calculate absolute difference and then mean over the specified dimension
@log_function_name
@validate_inputs_with_warning(require_coordtime=True)
def Tmaemean(
    x: xr.Dataset, daproof: str, daref: str,
    coordtime: Optional[str] = None,
    coordxy: Optional[List[str]] = None,
    option: Optional[Any] = None,
):
    return np.fabs(x[daproof] - x[daref]).mean(dim = coordtime)


@log_function_name
@validate_inputs_with_warning(require_coordxy=True)
def Smae(
    x: xr.Dataset, daproof: str, daref: str,
    coordtime: Optional[str] = None,
    coordxy: Optional[List[str]] = None,
    option: Optional[Any] = None,
):
    return (np.fabs(x[daproof] - x[daref])).mean(dim = coordxy)


@log_function_name
@validate_inputs_with_warning(require_coordxy=True, require_coordtime=True)
def Smaemean(
    x: xr.Dataset, daproof: str, daref: str,
    coordtime: Optional[str] = None,
    coordxy: Optional[List[str]] = None,
    option: Optional[Any] = None,
):
    # a temporal aggregation is unusual for spatial metrics
    return ((np.fabs(x[daproof] - x[daref])).mean(dim = coordxy)).mean(dim = coordtime)


# -- Mean absolute deviation:
@log_function_name
@validate_inputs_with_warning()
def Tmad(
    x: xr.Dataset, daproof: str, daref: str,
    coordtime: Optional[str] = None,
    coordxy: Optional[List[str]] = None,
    option: Optional[Any] = None,
):
    return (np.fabs(x[daproof] - x[daref]))


@log_function_name
@validate_inputs_with_warning(require_coordtime=True)
def Tmadmean(
    x: xr.Dataset, daproof: str, daref: str,
    coordtime: Optional[str] = None,
    coordxy: Optional[List[str]] = None,
    option: Optional[Any] = None,
):
    # Calculate absolute difference
    return (np.fabs(x[daproof] - x[daref].median(dim = coordtime))).median(dim = coordtime)


@log_function_name
@validate_inputs_with_warning(require_coordxy=True)
def Smad(
    x: xr.Dataset, daproof: str, daref: str,
    coordtime: Optional[str] = None,
    coordxy: Optional[List[str]] = None,
    option: Optional[Any] = None,
):
    return (np.fabs(x[daproof] - x[daref].median(dim = coordxy))).median(dim = coordxy)


@log_function_name
@validate_inputs_with_warning(require_coordxy=True, require_coordtime=True)
def Smadmean(
    x: xr.Dataset, daproof: str, daref: str,
    coordtime: Optional[str] = None,
    coordxy: Optional[List[str]] = None,
    option: Optional[Any] = None,
):
    # a temporal aggregation is unusual for spatial metrics
    return ((np.fabs(x[daproof] - x[daref].median(dim = coordxy))).median(dim = coordxy)).mean(dim = coordtime)


# -- Root mean squared error:
@log_function_name
@validate_inputs_with_warning()
def Trmse(
    x: xr.Dataset, daproof: str, daref: str,
    coordtime: Optional[str] = None,
    coordxy: Optional[List[str]] = None,
    option: Optional[Any] = None,
):
    # unused up to now, because sqrt(sqr(A)) is senseless
    return None


@log_function_name
@validate_inputs_with_warning(require_coordtime=True)
def Trmsemean(
    x: xr.Dataset, daproof: str, daref: str,
    coordtime: Optional[str] = None,
    coordxy: Optional[List[str]] = None,
    option: Optional[Any] = None,
):
    a = np.square(x[daproof] - x[daref])
    return np.sqrt(a.mean(dim = coordtime))


@log_function_name
@validate_inputs_with_warning()
def Trmsebcn(
    x: xr.Dataset, daproof: str, daref: str,
    coordtime: Optional[str] = None,
    coordxy: Optional[List[str]] = None,
    option: Optional[Any] = None,
):
    # unused up to now, because sqrt(sqr(A)) is senseless
    return None


@log_function_name
@validate_inputs_with_warning(require_coordxy=True, require_coordtime=True)
def Trmsebcnmean(
    x: xr.Dataset, daproof: str, daref: str,
    coordtime: Optional[str] = None,
    coordxy: Optional[List[str]] = None,
    option: Optional[Any] = None,
):
    bcor = (x[daproof] - x[daref]).mean(dim = coordtime)
    a = np.square(x[daproof] - x[daref] - bcor)
    return np.sqrt(a.mean(dim = coordtime)) / x[daref].mean(dim = coordtime)


@log_function_name
@validate_inputs_with_warning(require_coordxy=True)
def Srmse(
    x: xr.Dataset, daproof: str, daref: str,
    coordtime: Optional[str] = None,
    coordxy: Optional[List[str]] = None,
    option: Optional[Any] = None,
):
    a = np.square(x[daproof] - x[daref])
    return np.sqrt(a.mean(dim = coordxy))


@log_function_name
@validate_inputs_with_warning(require_coordxy=True, require_coordtime=True)
def Srmsemean(
    x: xr.Dataset, daproof: str, daref: str,
    coordtime: Optional[str] = None,
    coordxy: Optional[List[str]] = None,
    option: Optional[Any] = None,
):
    # a temporal aggregation is unusual for spatial metrics
    a = np.square(x[daproof] - x[daref])
    return (np.sqrt(a.mean(dim = coordxy))).mean(dim = coordtime)


# -- Tcorrel unused because Correlation of single TS is undefined:
@log_function_name
def Tcorrelmean(
    x: xr.Dataset, daproof: str, daref: str,
    coordtime: Optional[str] = None,
    coordxy: Optional[List[str]] = None,
    option: Optional[Any] = None,
):
    a = (
        (x[daproof] - x[daproof].mean(dim = coordtime)) *
        (x[daref] - x[daref].mean(dim = coordtime)) /
        x[daproof].std(dim = coordtime) / x[daref].std(dim = coordtime)
    )
    # normalized correlation consistent to definition of std with 1/n
    return a.mean(dim = coordtime)


@log_function_name
def Scorrel(
    x: xr.Dataset, daproof: str, daref: str,
    coordtime: Optional[str] = None,
    coordxy: Optional[List[str]] = None,
    option: Optional[Any] = None,
):
    a = (
        (x[daproof] - x[daproof].mean(dim = coordxy)) *
        (x[daref] - x[daref].mean(dim = coordxy)) /
        x[daproof].std(dim = coordxy) / x[daref].std(dim = coordxy)
    )
    # normalized correlation consistent to definition of std with 1/n
    return a.mean(dim = coordxy)


@log_function_name
def Scorrelmean(
    x: xr.Dataset, daproof: str, daref: str,
    coordtime: Optional[str] = None,
    coordxy: Optional[List[str]] = None,
    option: Optional[Any] = None,
):
    # a temporal aggregation is unusual for spatial metrics
    a = (
        (x[daproof] - x[daproof].mean(dim = coordxy)) *
        (x[daref] - x[daref].mean(dim = coordxy)) /
        x[daproof].std(dim = coordxy) / x[daref].std(dim = coordxy)
    )
    # normalized correlation consistent to definition of std with 1/n
    return a.mean(dim = coordxy).mean(dim = coordtime)


# -- Tklingcupta unused because Correlation of single TS is undefined:
@log_function_name
def Tklingcuptamean(
    x: xr.Dataset, daproof: str, daref: str,
    coordtime: Optional[str] = None,
    coordxy: Optional[List[str]] = None,
    option: Optional[Any] = None,
):
    acor = (
        (x[daproof] - x[daproof].mean(dim = coordtime)) *
        (x[daref] - x[daref].mean(dim = coordtime)) /
        x[daproof].std(dim = coordtime) / x[daref].std(dim = coordtime)
    )
    avar = x[daproof].std(dim = coordtime) / x[daref].std(dim = coordtime)
    amea = x[daproof].mean(dim = coordtime) / x[daref].mean(dim = coordtime)
    a = 1.0 - (
        np.sqrt(
            np.square(acor.mean(dim = coordtime) - 1.0) +
            np.square(avar - 1.0) + np.square(amea - 1.0)
        )
    )
    return a


# -- The contingency scores:
@log_function_name
def Taccuracy(
    x: xr.Dataset, daproof: str, daref: str,
    coordtime: Optional[str] = None,
    coordxy: Optional[List[str]] = None,
    option: Optional[Any] = None,
):
    a = (
        (x[daproof] * x[daref]).sum(dim = coordtime) +
        ((1.0 - x[daproof]) * (1.0 - x[daref])).sum(dim = coordtime)
    )
    a = a / ((x[daproof]).sum(dim = coordtime) + (1.0 - x[daref]).sum(dim = coordtime))
    return a


@log_function_name
def Tfalsealarm(
    x: xr.Dataset, daproof: str, daref: str,
    coordtime: Optional[str] = None,
    coordxy: Optional[List[str]] = None,
    option: Optional[Any] = None,
):
    a = (x[daproof] * (1.0 - x[daref])).sum(dim = coordtime)
    a = a / (
        (x[daproof] * x[daref]).sum(dim = coordtime) +
        (x[daproof] * (1.0 - x[daref])).sum(dim = coordtime)
    )
    return a


@log_function_name
def Tprobofdetect(
    x: xr.Dataset, daproof: str, daref: str,
    coordtime: Optional[str] = None,
    coordxy: Optional[List[str]] = None,
    option: Optional[Any] = None,
):
    a = (x[daproof] * x[daref]).sum(dim = coordtime)
    a = a / (
        (x[daproof] * x[daref]).sum(dim = coordtime) +
        ((1.0 - x[daproof]) * x[daref]).sum(dim = coordtime)
    )
    return a


@log_function_name
def Tsuccessratio(
    x: xr.Dataset, daproof: str, daref: str,
    coordtime: Optional[str] = None,
    coordxy: Optional[List[str]] = None,
    option: Optional[Any] = None,
):
    a = (x[daproof] * x[daref]).sum(dim = coordtime)
    a = a / (
        (x[daproof] * x[daref]).sum(dim = coordtime) +
        (x[daproof] * (1.0 - x[daref])).sum(dim = coordtime)
    )
    return a


@log_function_name
def Tlogoddsratio(
    x: xr.Dataset, daproof: str, daref: str,
    coordtime: Optional[str] = None,
    coordxy: Optional[List[str]] = None,
    option: Optional[Any] = None,
):
    a = (
        (x[daproof] * x[daref]).sum(dim = coordtime) *
        ((1.0 - x[daproof]) * (1.0 - x[daref])).sum(dim = coordtime)
    )
    a = np.log(a / (
        (x[daproof] * (1.0 - x[daref])).sum(dim = coordtime) *
        ((1.0 - x[daproof]) * (x[daref])).sum(dim = coordtime)
    ))
    return a


@log_function_name
def Tequitthreadsc(
    x: xr.Dataset, daproof: str, daref: str,
    coordtime: Optional[str] = None,
    coordxy: Optional[List[str]] = None,
    option: Optional[Any] = None,
):
    hitsr = (
        (x[daproof] * x[daref]).sum(dim = coordtime) +
        ((1.0 - x[daproof]) * x[daref]).sum(dim = coordtime)
    )
    hitsr = hitsr * (
        (x[daproof] * x[daref]).sum(dim = coordtime) +
        (x[daproof] * (1.0 - x[daref])).sum(dim = coordtime)
    )
    hitsr = hitsr / (
        (x[daproof]).sum(dim = coordtime) + (1.0 - x[daproof]).sum(dim = coordtime)
    )
    a = ((x[daproof] * x[daref]).sum(dim = coordtime) - hitsr)
    a = a / (
        (x[daproof] * x[daref]).sum(dim = coordtime) +
        ((1.0 - x[daproof]) * x[daref]).sum(dim = coordtime) +
        (x[daproof] * (1.0 - x[daref])).sum(dim = coordtime) - hitsr
    )
    return a


@log_function_name
def Tsediratio(
    x: xr.Dataset, daproof: str, daref: str,
    coordtime: Optional[str] = None,
    coordxy: Optional[List[str]] = None,
    option: Optional[Any] = None,
):
    F = (x[daproof] * (1.0 - x[daref])).sum(dim = coordtime)
    F = F / (
        (x[daproof] * x[daref]).sum(dim = coordtime) +
        (x[daproof] * (1.0 - x[daref])).sum(dim = coordtime)
    )
    H = (x[daproof] * x[daref]).sum(dim = coordtime)
    H = H / (
        (x[daproof] * x[daref]).sum(dim = coordtime) +
        ((1.0 - x[daproof]) * x[daref]).sum(dim = coordtime)
    )
    a = (
        (np.log(F) - np.log(H) - np.log(1.0 - F) + np.log(1.0 - H)) /
        (np.log(F) + np.log(H) + np.log(1.0 - F) + np.log(1.0 - H))
    )
    return a


# ***********************************************************************
# the skill scores involving three datasets
# ***********************************************************************
@log_function_name
def Tamsess(
    x: xr.Dataset, daproof: str, daref: str, daskillref: str,
    coordtime: Optional[str] = None,
    option: Optional[Any] = None,
):
    # -- Unused up to now, because Mean Squared error is senseless for single TS
    return None


@log_function_name
def Tamsessmean(
    x: xr.Dataset, daproof: str, daref: str, daskillref: str,
    coordtime: Optional[str] = None,
    option: Optional[Any] = None,
) -> xr.DataArray:
    # -- Ensure coordtime is treated correctly as a string or None:
    if coordtime is not None and not isinstance(coordtime, str):
        raise ValueError("Tamsessmean: coordtime must be a string or None")

    # -- Calculate the p2divp1 ratio
    p2divp1 = (
        (np.square(x[daskillref] - x[daref])).mean(dim = coordtime) /
        (np.square(x[daproof] - x[daref])).mean(dim = coordtime)
    )
    # -- Could be that nan's are not preserved:
    return xr.where((p2divp1 - 1.0) > 0.0, (-1.0) / p2divp1 + 1.0, p2divp1 - 1.0)


####
# -- BIAS related, JE-test, Bootstrapping test, Student-T test:
####
@log_function_name
def TbiasdiffJESmean(
    x: xr.Dataset, daproof: str, daref: str, daskillref: str,
    coordtime: Optional[str] = None,
    option: Optional[float] = 0.05,
):
    metric = "me"
    # -- Set significance level:
    alpha = option if option is not None else 0.05

    biasdaproof = (x[daproof] - x[daref]).mean(dim = coordtime)
    biasdaskillref = (x[daskillref] - x[daref]).mean(dim = coordtime)
    sign_diff, diff, hwci = xskill.halfwidth_ci_test(
        x[daproof],
        x[daskillref],
        x[daref],
        metric,
        time_dim = coordtime,
        dim = [],
        alpha = alpha,
    )
    JEsigt = xr.where(
        (np.abs(biasdaproof) < np.abs(biasdaskillref)) &
        (sign_diff), 1.0, np.nan
    )
    JEsigt = xr.where(
        (np.abs(biasdaproof) > np.abs(biasdaskillref)) &
        (sign_diff), -1.0, JEsigt)
    JEsigt = xr.where((sign_diff == False), 0.0, JEsigt)
    JEsigt = JEsigt.where(
        (biasdaproof.notnull().data) & (biasdaskillref.notnull().data))
    del sign_diff, diff, hwci, biasdaproof, biasdaskillref

    return JEsigt


####
# -- RMSE related, Bootstrapping test und JE test:
####
@log_function_name
def TrmsediffJESmean(
    x: xr.Dataset, daproof: str, daref: str, daskillref: str,
    coordtime: Optional[str] = None,
    option: Optional[float] = 0.05,
):
    metric = "rmse"
    # -- Set significance level:
    alpha = option if option is not None else 0.05
    #
    a = np.square(x[daproof] - x[daref])
    rmsedaproof = np.sqrt(a.mean(dim = coordtime))
    a = np.square(x[daskillref] - x[daref])
    rmsedaskillref = np.sqrt(a.mean(dim = coordtime))
    sign_diff, diff, hwci = xskill.halfwidth_ci_test(
        x[daproof],
        x[daskillref],
        x[daref],
        metric,
        time_dim = coordtime,
        dim = [],
        alpha = alpha,
    )
    JEsigt = xr.where(
        (np.abs(rmsedaproof) < np.abs(rmsedaskillref)) &
        (sign_diff), 1.0, np.nan
    )
    JEsigt = xr.where(
        (np.abs(rmsedaproof) > np.abs(rmsedaskillref)) &
        (sign_diff), -1.0, JEsigt
    )
    JEsigt = xr.where((sign_diff == False), 0.0, JEsigt)
    JEsigt = JEsigt.where(
        (rmsedaproof.notnull().data) & (rmsedaskillref.notnull().data))
    del rmsedaskillref, rmsedaproof, sign_diff, diff, hwci
    return JEsigt




@log_function_name
def TbiasdiffTTSmean(
    x: xr.Dataset, daproof: str, daref: str, daskillref: str,
    coordtime: Optional[str] = None,
    option: Optional[float] = 0.05,
):
    # -- Set significance level:
    alpha = option if option is not None else 0.05
    # mean of both bias values and pooled standard deviation
    biasdaproof = (x[daproof] - x[daref]).mean(dim = coordtime)
    biasdaskillref = (x[daskillref] - x[daref]).mean(dim = coordtime)
    nbdapr = (x[daproof] - x[daref]).sizes[coordtime]
    nbdask = (x[daskillref] - x[daref]).sizes[coordtime]
    poolvar = (
        (nbdapr - 1.0) * np.square((x[daproof] - x[daref]).std(dim = coordtime, ddof = 1.0)) +
        (nbdask - 1.0) * np.square((x[daskillref] - x[daref]).std(dim = coordtime, ddof = 1.0))
    ) / (nbdapr + nbdask - 2.0)

    ttestmod = (
        (biasdaproof - biasdaskillref) /
        (np.sqrt(poolvar) * np.sqrt(1.0 / nbdapr + 1.0 / nbdask))
    )

    tvalub = scipyt.ppf(1.0 - alpha / 2.0, nbdapr + nbdask - 2.0)
    tvallb = scipyt.ppf(alpha / 2.0, nbdapr + nbdask - 2.0)
    del nbdapr, nbdask, poolvar

    TTsigt = xr.where(
        (np.abs(biasdaproof) < np.abs(biasdaskillref)) &
        ((ttestmod > tvalub) | (ttestmod < tvallb)), 1.0, np.nan
    )
    TTsigt = xr.where(
        (np.abs(biasdaproof) > np.abs(biasdaskillref)) &
        ((ttestmod > tvalub) | (ttestmod < tvallb)), -1.0, TTsigt
    )
    TTsigt = xr.where(
        (ttestmod < tvalub) & (ttestmod > tvallb), 0.0, TTsigt)
    TTsigt = TTsigt.where(
        (biasdaproof.notnull().data) & (biasdaskillref.notnull().data))
    del biasdaproof, biasdaskillref, ttestmod, tvalub, tvallb

    return TTsigt


def get_spatial_dims_strict(da: xr.DataArray, coordtime: str) -> list[str]:
    """
    Extract spatial dims in deterministic order.

    Rules:
    - Preserve original order from da.dims
    - Remove coordtime
    """
    return [str(dim) for dim in da.dims if dim != coordtime]


def prepare_spatial_inputs(
    x: xr.Dataset,
    daproof: str,
    daref: str,
    daskillref: str,
    coordtime: str,
    transform: Optional[Callable[[xr.DataArray], xr.DataArray]] = None,
) -> Tuple[xr.DataArray, xr.DataArray, List[str]]:
    """
    Prepare aligned proof/ref arrays with strict dimension ordering.

    Returns:
        arr_proof, arr_ref, spatial_dims
    """
    # --- VALIDATE dimension consistency (STRICT)
    if not (
        x[daproof].dims == x[daref].dims == x[daskillref].dims
    ):
        raise ValueError(
            f"Dimension mismatch:\n"
            f"  {daproof}: {x[daproof].dims}\n"
            f"  {daref}: {x[daref].dims}\n"
            f"  {daskillref}: {x[daskillref].dims}"
        )

    # --- strict spatial dims (ORDER PRESERVED)
    spatial_dims: List[str] = get_spatial_dims_strict(x[daproof], coordtime)

    expected_dims = (coordtime, *spatial_dims)

    # -- Compute residuals:
    arr_proof: xr.DataArray = x[daproof] - x[daref]
    arr_ref: xr.DataArray = x[daskillref] - x[daref]

    # -- Optional transform (MAE, RMSE etc.)
    if transform is not None:
        arr_proof = transform(arr_proof)
        arr_ref = transform(arr_ref)

    # -- Enforce strict ordering
    arr_proof = arr_proof.transpose(*expected_dims)
    arr_ref = arr_ref.transpose(*expected_dims)

    return arr_proof, arr_ref, spatial_dims


# ==============================================================================
# ----                           ErrorTamsess family                        ----
# ----                             (TamsessBSSmean                          ----
# ==============================================================================
def TamsessBSSmean(
    x: xr.Dataset,
    daproof: str,
    daref: str,
    daskillref: str,
    coordtime: str = "time",
    option: Optional[float] = 0.05,
    compute: bool = True,
) -> xr.DataArray:
    """
    AMSESS (Anomaly MSE Skill Score) bootstrap significance test.

    Computes whether the anomaly MSE skill score of the proof forecast
    is significantly better or worse than that of the reference forecast,
    using bootstrap resampling across the time dimension.

    Workflow:
    ----------
    1. Resample proof and reference residuals across `coordtime` with bootstrap iterations.
    2. For each iteration, compute:
         MSE_proof = mean_t((daproof - daref)^2)
         MSE_ref   = mean_t((daskillref - daref)^2)
         Ratio     = MSE_ref / MSE_proof
         AMSESS    = 1 - max(Ratio, 1/Ratio)
    3. Estimate confidence intervals (CI) from bootstrap distribution:
         - Lower bound = q(alpha/2)
         - Upper bound = q(1 - alpha/2)
    4. Construct significance mask:
         +1 : proof significantly better
         -1 : proof significantly worse
          0 : not significant
         NaN : undefined

    Arguments:
    ----------
    x : xr.Dataset
        Dataset containing the proof, reference, and skill-ref fields.
    daproof : str
        Name of the proof forecast variable in `x`.
    daref : str
        Name of the reference (truth/observation) variable in `x`.
    daskillref : str
        Name of the skill reference forecast variable in `x`.
    coordtime : str, default="time"
        Time coordinate along which bootstrap resampling is performed.
    option : float, default=0.05
        Significance level (alpha). Default is 0.05 (95% CI).
    compute : bool, default=True
        If True, trigger full dask computation before returning.

    Returns:
    --------
    xr.DataArray
        Bootstrap significance mask with dims (rlat, rlon). Values:
          +1 : significantly positive skill
          -1 : significantly negative skill
           0 : not significant
          NaN : undefined
    """
    bss_support = BSSBootstrap_support(iterations=250)
    alpha = option if option is not None else 0.05

    # -- Prepare residual inputs (STRICT + ORDERED)
    arr_proof, arr_ref, spatial_dims = prepare_spatial_inputs(
        x, daproof, daref, daskillref, coordtime,
    )
    logger.debug("Spatial dims (ordered): %s", spatial_dims)

    return bss_support.amsess_sig(
        x = x,
        arr_proof = arr_proof,
        arr_ref = arr_ref,
        coordtime = coordtime,
        alpha = alpha,
        compute = compute,
        caller_name = "TamsessBSSmean",
    )


# ==============================================================================
# ----                       ErrorDiffBSSmean family                        ----
# ----  (BiasDiffBSSmean, MAEDiffBSSmean, MADDiffBSSmean, RMSEDiffBSSmean   ----
# ==============================================================================
def TbiasdiffBSSmean(
    x: xr.Dataset,
    daproof: str,
    daref: str,
    daskillref: str,
    coordtime: str = "time",
    option: float = 0.05,
    compute: bool = True
) -> xr.DataArray:
    """
    Bootstrap significance test for bias difference:
    ``|mean(bias_proof)| - |mean(bias_ref)|``.

    This function applies the generic bootstrap significance pipeline to
    assess whether the absolute mean bias of a candidate/proof forecast is
    significantly different from that of a skill reference.

    Pipeline
    --------
    1. Compute bias fields:
         - proof bias   = (daproof - daref)
         - ref bias     = (daskillref - daref)
    2. Bootstrap resample both bias fields along `coordtime`.
    3. Compute mean bias per bootstrap replicate.
    4. Take absolute values, then difference: ``|bias_proof| - |bias_ref|``.
    5. Estimate bootstrap confidence intervals via quantiles.
    6. Construct significance mask:
         - -1.0 → proof bias significantly larger (worse)
         - +1.0 → proof bias significantly smaller (better)
         -  0.0 → difference not significant
         -  NaN → undefined / missing

    Parameters
    ----------
    x : xr.Dataset
        Input dataset containing the forecast, reference, and skill reference fields.
    daproof : str
        Name of the proof (candidate) variable in `x`.
    daref : str
        Name of the reference (truth/observation) variable in `x`.
    daskillref : str
        Name of the skill reference variable in `x`.
    coordtime : str, default="time"
        Name of the time-like coordinate to bootstrap over.
    option : float, default=0.05
        Significance level (e.g., 0.05 for 95% confidence intervals).
    compute : bool, default=True
        If True, compute immediately (`dask.compute`).
        If False, return a lazy dask-backed DataArray.

    Returns
    -------
    xr.DataArray
        2D significance mask over (coordinates), chunk/ragged safe.
        Values:
            - -1.0 → proof worse
            - +1.0 → proof better
            -  0.0 → not significant
            -  NaN → undefined

    Notes
    -----
    - This is a thin wrapper around :meth:`BSSBootstrap_support.bss_sig_generic`
      with `reduce_op="mean"`.
    - Other metrics (MAE, MAD, RMSE) are available via `TmaediffBSSmean`,
      `TmaddiffBSSmean`, `TrmsediffBSSmean`.
    """
    bss_support = BSSBootstrap_support(iterations=250)
    alpha = option if option is not None else 0.05

    arr_proof, arr_ref, spatial_dims = prepare_spatial_inputs(
        x, daproof, daref, daskillref, coordtime
    )
    logger.debug("Spatial dims (ordered): %s", spatial_dims)

    return bss_support.bss_sig_generic(
        x=x,
        arr_proof=arr_proof,
        arr_ref=arr_ref,
        coordtime=coordtime,
        alpha=alpha,
        compute=compute,
        caller_name="TbiasdiffBSSmean",
    )


def TmaediffBSSmean(
    x: xr.Dataset,
    daproof: str,
    daref: str,
    daskillref: str,
    coordtime: str = "time",
    option: float = 0.05,
    compute: bool = True
) -> xr.DataArray:
    """
    Bootstrap significance test for MAE difference:
    ``|mean(|e_proof|)| - |mean(|e_ref|)|``.

    This function applies the generic bootstrap significance pipeline to
    assess whether the mean absolute error (MAE) of a candidate/proof
    forecast is significantly different from that of a skill reference.

    Pipeline
    --------
    1. Compute absolute error fields:
         - proof error = |daproof - daref|
         - ref error   = |daskillref - daref|
    2. Bootstrap resample both error fields along `coordtime`.
    3. Compute mean absolute error per bootstrap replicate.
    4. Difference: ``MAE_proof - MAE_ref``.
    5. Estimate bootstrap confidence intervals via quantiles.
    6. Construct significance mask:
         - -1.0 → proof MAE significantly larger (worse)
         - +1.0 → proof MAE significantly smaller (better)
         -  0.0 → difference not significant
         -  NaN → undefined / missing

    Parameters
    ----------
    x : xr.Dataset
        Input dataset containing the forecast, reference, and skill reference fields.
    daproof : str
        Name of the proof (candidate) variable in `x`.
    daref : str
        Name of the reference (truth/observation) variable in `x`.
    daskillref : str
        Name of the skill reference variable in `x`.
    coordtime : str, default="time"
        Name of the time-like coordinate to bootstrap over.
    option : float, default=0.05
        Significance level (e.g., 0.05 for 95% confidence intervals).
    compute : bool, default=True
        If True, compute immediately (`dask.compute`).
        If False, return a lazy dask-backed DataArray.

    Returns
    -------
    xr.DataArray
        2D significance mask over (rlat, rlon), chunk/ragged safe.
        Values:
            - -1.0 → proof worse
            - +1.0 → proof better
            -  0.0 → not significant
            -  NaN → undefined

    Notes
    -----
    - This is a thin wrapper around :meth:`BSSBootstrap_support.bss_sig_generic`
      with `reduce_op="mean"`.
    - Other metrics (Bias, MAD, RMSE) are available via
      `TbiasdiffBSSmean`, `TmaddiffBSSmean`, `TrmsediffBSSmean`.
    """
    bss_support = BSSBootstrap_support(iterations=250)
    alpha = option if option is not None else 0.05

    arr_proof, arr_ref, spatial_dims = prepare_spatial_inputs(
        x, daproof, daref, daskillref, coordtime, transform=abs
    )
    logger.debug("Spatial dims (ordered): %s", spatial_dims)

    return bss_support.bss_sig_generic(
        x=x,
        arr_proof=arr_proof,
        arr_ref=arr_ref,
        coordtime=coordtime,
        alpha=alpha,
        compute=compute,
        caller_name="TmaediffBSSmean",
    )


def TmaddiffBSSmean(
    x: xr.Dataset,
    daproof: str,
    daref: str,
    daskillref: str,
    coordtime: str = "time",
    option: float = 0.05,
    compute: bool = True,
) -> xr.DataArray:
    """
    Bootstrap significance test for MAD difference:
    ``|median_t(|daproof - median_t(daref)|)| - |median_t(|daskillref - median_t(daref)|)|``.

    This function applies the generic bootstrap significance pipeline to
    assess whether the median absolute deviation (MAD) of a candidate/proof
    forecast is significantly different from that of a skill reference,
    relative to the median of the reference.

    Pipeline
    --------
    1. Compute the time-median of the reference field: ``med_ref = median_t(daref)``.
    2. Compute absolute deviations:
         - proof deviations = |daproof - med_ref|
         - ref deviations   = |daskillref - med_ref|
    3. Bootstrap resample both deviation fields along `coordtime`.
    4. Compute median absolute deviation per bootstrap replicate.
    5. Difference: ``MAD_proof - MAD_ref``.
    6. Estimate bootstrap confidence intervals via quantiles.
    7. Construct significance mask:
         - -1.0 → proof MAD significantly larger (worse)
         - +1.0 → proof MAD significantly smaller (better)
         -  0.0 → difference not significant
         -  NaN → undefined / missing

    Parameters
    ----------
    x : xr.Dataset
        Input dataset containing the forecast, reference, and skill reference fields.
    daproof : str
        Name of the proof (candidate) variable in `x`.
    daref : str
        Name of the reference (truth/observation) variable in `x`.
    daskillref : str
        Name of the skill reference variable in `x`.
    coordtime : str, default="time"
        Name of the time-like coordinate to bootstrap over.
    option : float, default=0.05
        Significance level (e.g., 0.05 for 95% confidence intervals).
    compute : bool, default=True
        If True, compute immediately (`dask.compute`).
        If False, return a lazy dask-backed DataArray.

    Returns
    -------
    xr.DataArray
        2D significance mask over (rlat, rlon), chunk/ragged safe.
        Values:
            - -1.0 → proof worse
            - +1.0 → proof better
            -  0.0 → not significant
            -  NaN → undefined

    Notes
    -----
    - Uses :meth:`BSSBootstrap_support.bss_sig_generic` with `reduce_op="median"`.
    - Appropriate for distributions where the median (MAD) is more robust
      than the mean (MAE) against outliers.
    - Complements bias, MAE, and RMSE bootstrap difference tests.
    """
    bss_support = BSSBootstrap_support(iterations=250)
    alpha = option if option is not None else 0.05

    # -- Median over time of reference (spatial only):
    med_ref = x[daref].median(dim=coordtime)

    # --- strict spatial dims (ORDER PRESERVED)
    spatial_dims = get_spatial_dims_strict(x[daproof], coordtime)
    logger.debug("Spatial dims (ordered): %s", spatial_dims)

    expected_dims = (coordtime, *spatial_dims)

    # --- absolute deviations relative to median
    arr_proof = abs(x[daproof] - med_ref).transpose(*expected_dims)
    arr_ref = abs(x[daskillref] - med_ref).transpose(*expected_dims)

    return bss_support.bss_sig_generic(
        x = x,
        arr_proof = arr_proof,
        arr_ref = arr_ref,
        coordtime = coordtime,
        alpha = alpha,
        compute = compute,
        caller_name = "TmaddiffBSSmean",
        reduce_op = "median",
    )


def TrmsediffBSSmean(
    x: xr.Dataset,
    daproof: str,
    daref: str,
    daskillref: str,
    coordtime: str = "time",
    option: Optional[float] = 0.05,
    compute: bool = True,
) -> xr.DataArray:
    """
    Bootstrap significance test for RMSE difference:
    ``sqrt(mean_t((daproof - daref)^2)) - sqrt(mean_t((daskillref - daref)^2))``.

    This function applies the generic bootstrap significance pipeline to
    assess whether the root mean square error (RMSE) of a candidate/proof
    forecast is significantly different from that of a skill reference.

    Pipeline
    --------
    1. Compute squared errors:
         - proof errors = (daproof - daref)^2
         - ref errors   = (daskillref - daref)^2
    2. Bootstrap resample squared errors along `coordtime`.
    3. Reduce with mean over `coordtime` for each bootstrap replicate.
    4. Apply square-root transform → RMSE.
    5. Difference: ``RMSE_proof - RMSE_ref``.
    6. Estimate bootstrap confidence intervals via quantiles.
    7. Construct significance mask:
         - -1.0 → proof RMSE significantly larger (worse)
         - +1.0 → proof RMSE significantly smaller (better)
         -  0.0 → difference not significant
         -  NaN → undefined / missing

    Parameters
    ----------
    x : xr.Dataset
        Input dataset containing the forecast, reference, and skill reference fields.
    daproof : str
        Name of the proof (candidate) variable in `x`.
    daref : str
        Name of the reference (truth/observation) variable in `x`.
    daskillref : str
        Name of the skill reference variable in `x`.
    coordtime : str, default="time"
        Name of the time-like coordinate to bootstrap over.
    option : float, default=0.05
        Significance level (e.g., 0.05 for 95% confidence intervals).
    compute : bool, default=True
        If True, compute immediately (`dask.compute`).
        If False, return a lazy dask-backed DataArray.

    Returns
    -------
    xr.DataArray
        2D significance mask over (rlat, rlon), chunk/ragged safe.
        Values:
            - -1.0 → proof worse
            - +1.0 → proof better
            -  0.0 → not significant
            -  NaN → undefined

    Notes
    -----
    - Uses :meth:`BSSBootstrap_support.bss_sig_generic` with `reduce_op="mean"`
      and applies a square-root transform after reduction.
    - RMSE is sensitive to large errors due to squaring, making this test
      more influenced by outliers than MAE or MAD.
    - Complements bias, MAE, and MAD bootstrap difference tests.
    """
    bss_support = BSSBootstrap_support(iterations=250)
    alpha = option if option is not None else 0.05

    # -- Prepare inputs (STRICT + ORDERED):
    se_proof, se_ref, spatial_dims = prepare_spatial_inputs(
        x, daproof, daref, daskillref, coordtime,
        transform=lambda da: da ** 2,
    )

    logger.debug("Spatial dims (ordered): %s", spatial_dims)

    # -- Pass a sqrt transform to be applied AFTER mean reduction:
    return bss_support.bss_sig_generic(
        x=x,
        arr_proof=se_proof,
        arr_ref=se_ref,
        coordtime=coordtime,
        alpha=alpha,
        compute=compute,
        caller_name="TrmsediffBSSmean",
        reduce_op="mean",
        post_reduce_transform=lambda da: np.sqrt(da),
    )


@log_function_name
def TcorrelZOUSmean(
    x: xr.Dataset, daproof: str, daref: str, daskillref: str,
    coordtime: Optional[str] = None,
    option: Optional[float] = 0.075,
):
    #
    def rlowrup(rval = None, nsamp = None, alpha = None):
        zval = 0.5 * np.log((1.0 + rval) / (1.0 - rval + 1.0e-6))
        zs = np.sqrt(1.0 / (nsamp - 3.0))
        zcrit = norm.ppf(alpha / 2.0)
        zlow = zval + zs * zcrit
        zup = zval - zs * zcrit
        rlower = (np.exp(2.0 * zlow) - 1.0) / (np.exp(2.0 * zlow) + 1.0)
        rupper = (np.exp(2.0 * zup) - 1.0) / (np.exp(2.0 * zup) + 1.0)
        return rlower, rupper
    #
    alpha = option if option is not None else 0.075
    # -- Compute correlations between all 3 timeseries:
    corprfref = (
        (x[daproof] - x[daproof].mean(dim = coordtime)) *
        (x[daref] - x[daref].mean(dim = coordtime)) /
        x[daproof].std(dim = coordtime) / x[daref].std(dim = coordtime)
    )
    # -- Normalized correlation consistent to definition of std with 1/n:
    corprfref = corprfref.mean(dim = coordtime)
    corskillref = (
        (x[daskillref] - x[daskillref].mean(dim = coordtime)) *
        (x[daref] - x[daref].mean(dim = coordtime)) /
        x[daskillref].std(dim = coordtime) / x[daref].std(dim = coordtime)
    )
    # -- Normalized correlation consistent to definition of std with 1/n:
    corskillref = corskillref.mean(dim = coordtime)
    corprfskill = (
        (x[daproof] - x[daproof].mean(dim = coordtime)) *
        (x[daskillref] - x[daskillref].mean(dim = coordtime)) /
        x[daproof].std(dim = coordtime) / x[daskillref].std(dim = coordtime)
    )
    # -- Normalized correlation consistent to definition of std with 1/n:
    corprfskill = corprfskill.mean(dim = coordtime)
    # test for significant difference between corproofref and corskillref
    cordiff = corprfref - corskillref

    cor_prfref_skillref = (
        ((corprfskill - 0.5 * corprfref * corskillref) *
            (1.0 - np.square(corprfref) - np.square(corskillref) - np.square(corprfskill)) +
            np.power(corprfskill, 3.0)) /
        ((1.0 - np.square(corprfref)) * (1.0 - np.square(corskillref)))
    )
    rlow_prfref, rupp_prfref = rlowrup(
        rval = corprfref,
        alpha = alpha,
        nsamp = x[daproof].sizes[coordtime],
    )
    rlow_skillref, rupp_skillref = rlowrup(
        rval = corskillref,
        alpha = alpha,
        nsamp = x[daskillref].sizes[coordtime],
    )
    cint_diff_lowbd = cordiff - np.sqrt(
        np.square(corprfref - rlow_prfref) +
        np.square(rupp_skillref - corskillref) -
        2.0 * (cor_prfref_skillref * (corprfref - rlow_prfref) * (rupp_skillref - corskillref))
    )
    cint_diff_uppbd = cordiff + np.sqrt(
        np.square(rupp_prfref - corprfref) +
        np.square(corskillref - rlow_skillref) -
        2.0 * (cor_prfref_skillref * (rupp_prfref - corprfref) * (corskillref - rlow_skillref))
    )

    # -- Write result to file:
    Zousigt = xr.where((corprfref > corskillref) & (cint_diff_lowbd > 0.0), 1.0, np.nan)
    Zousigt = xr.where((corprfref < corskillref) & (cint_diff_uppbd < 0.0), -1.0, Zousigt)
    Zousigt = xr.where((cint_diff_uppbd > 0.0) & (cint_diff_lowbd < 0.0), 0.0, Zousigt)
    Zousigt = Zousigt.where((corprfref.notnull().data) & (corskillref.notnull().data))
    # Zousigt = Zousigt.where( (1-(Zousigt<=0)) == (1-(Zousigt<=0)), 0.0 )
    return Zousigt


# -- Scores for comparison of Distributions: options have to be introduced for
#    dimension and quantiles to look at
#    unused up to now
@log_function_name
def quantile_comm(
    x: xr.Dataset, daproof: str, daref: str,
    coordtime: Optional[str] = None,
    coordxy: Optional[List[str]] = None,
    option: Optional[Dict[str, Any]] = {'biascor': False, 'quantiles': [0.2, 0.4, 0.6, 0.8]},
) -> tuple[Any, Any]:
    # -- Control of input variables:
    if isinstance(option, dict):
        quantls = option.get('quantiles', [0.2, 0.4, 0.6, 0.8])
        biascor = option.get('biascor', False)
    else:
        logger.warning(
            "Warning: option variable set as not dictionary."
            "  quantile_comm uses default values")
        quantls = [0.2, 0.4, 0.6, 0.8]
        biascor = False
    # -- Get data depending on biascor values:
    if biascor:
        bcor = (x[daproof] - x[daref]).mean(dim = coordtime)
        moddata = x[daproof] - bcor
    else:
        moddata = x[daproof]
    # -- Computation quantiles:
    amod = moddata.quantile(quantls, dim = coordtime, method = 'linear', keep_attrs = True)
    aref = x[daref].quantile(quantls, dim = coordtime, method = 'linear', keep_attrs = True)
    return amod, aref


@log_function_name
def quantile_bias_temporal(
    x: xr.Dataset, daproof: str, daref: str,
    coordtime: Optional[str] = None,
    coordxy: Optional[List[str]] = None,
    option: Optional[Dict[str, Any]] = {'biascor': False, 'quantiles': [0.2, 0.4, 0.6, 0.8]},
):
    # -- Call common function for computation quantile:
    amod, aref = quantile_comm(x, daproof, daref, coordtime, coordxy, option)
    logger.info(f"Quantile BIAS, Dimension unter Consideration: {list(aref.dims)[0]}")
    return (amod - aref).mean(dim = list(aref.dims)[0], min_count = 1)


@log_function_name
def quantile_mae_temporal(
    x: xr.Dataset, daproof: str, daref: str,
    coordtime: Optional[str] = None,
    coordxy = None,
    option: Optional[Dict[str, Any]] = {'biascor': False, 'quantiles': [0.2, 0.4, 0.6, 0.8]},
):
    # -- Call common function for computation quantile:
    amod, aref = quantile_comm(x, daproof, daref, coordtime, coordxy, option)
    logger.info(f"Quantile MAE, Dimension unter Consideration: {list(aref.dims)[0]}")
    return (np.fabs(amod - aref)).mean(dim = list(aref.dims)[0])


@log_function_name
def quantile_iqd_temporal(
    x: xr.Dataset, daproof: str, daref: str,
    coordtime: Optional[str] = None,
    coordxy: Optional[List[str]] = None,
    option: Optional[Dict[str, Any]] = {'biascor': False, 'quantiles': [0.2, 0.4, 0.6, 0.8]},
):
    # -- Call common function for computation quantile:
    amod, aref = quantile_comm(x, daproof, daref, coordtime, coordxy, option)
    logger.info(f"Quantile IQD, Dimension unter Consideration: {list(aref.dims)[0]}")
    return (np.square(amod - aref)).sum(dim = list(aref.dims)[0], min_count = 1)


@log_function_name
def pdf_pss_temporal(
    x: xr.Dataset, daproof: str, daref: str,
    coordtime: Optional[str] = None,
    coordxy: Optional[List[str]] = None,
    option: Optional[Dict[str, Any]] = {'biascor': False, 'binlimits': None},
):
    logger.info("Jetzt bin ich ja drin in pdf_pss_temporal - funktion")
    bins = option['binlimits']  # to be defined
    logger.info("Die bins sind:" + str(bins))
    if option['biascor']:
        bcor = (x[daproof] - x[daref]).mean(dim = coordtime)
        moddata = x[daproof] - bcor
    else:
        moddata = x[daproof]
    #
    logger.info(f"MOD-Histogram with following bins and dims: {bins}/{bins}")
    amod = histogram(
        moddata,
        bins = [bins],
        dim = [coordtime],
        density = 'True',
    )
    amoddimbin = [s for s in list(amod.dims) if "_bin" in s]
    logger.info(f"Dimension Null von mod: {amoddimbin[0]}")
    amod = amod.rename({amoddimbin[0]: 'pdfbin'})
    #
    logger.info(f"REF-Histogram with following bins and dims: {bins}/{bins}")
    aref = histogram(
        x[daref],
        bins = [bins],
        dim = [coordtime],
        density = 'True',
    )
    arefdimbin = [s for s in list(aref.dims) if "_bin" in s]
    logger.info(f"Dimension Null von mod: {arefdimbin[0]}")
    aref = aref.rename({arefdimbin[0]: 'pdfbin'})
    # -- Perkins Skill Score:
    min_aproof_aref = np.minimum(amod, aref)
    # -- The problem is that here each single frequency is normalized by bin size in python:
    return min_aproof_aref.sum(dim = "pdfbin")
    #
    # solution with weights does not work at all:
    # weights=mindist1dist2.pdfbin; weights.name="weights"; help = mindist1dist2.weighted(weights)
