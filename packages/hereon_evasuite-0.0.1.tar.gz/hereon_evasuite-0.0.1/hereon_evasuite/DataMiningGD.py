# EvaSuite
#
# ---------------------------------------------------------------
# Copyright (C) 2004-2025, Hereon
# Contact information: beate.geyer@hereon.de, imktro-climate-modelling@lists.kit.edu
# See AUTHORS.TXT for a list of authors
# See LICENSES/ for license information
# SPDX-License-Identifier: Apache-2.0
# ---------------------------------------------------------------

# this is for executing unix commands in python
# -- Import python modules:
import subprocess as sp
import filecmp
from typing import Any, Optional, Dict, List, Union

# -- Import EvaSuite modules:
from hereon_evasuite.Prog_CDONCO import CDO, NCO, NCSYS
from hereon_evasuite.Prog_PyXarray_PyVis import PyXarray
from hereon_evasuite.log_EvaSuite import get_logger, log_function_name
logger = get_logger()


# -- Start:
class DataMining(object):
    @log_function_name
    def __init__(self: 'DataMining', name: str) -> None:
        """Initialization of common parameters for DataMining class:"""
        self.name = name
        logger.debug(f"DataMining-Instances: {self.name}")

    @log_function_name
    def SpatialTemporalOpera(
        self: 'DataMining',
        DataProgsToUse: Dict[str, Union[CDO, NCO, NCSYS, PyXarray]],
        filein: str,
        fileout: str,
        evalvars: List[str],
        cfgRestime: Dict[str, str],
        posdimnames: Dict[str, List[str]],
        cfgrollingm: Optional[Any] = None,
        oper_x: Optional[Any] = None,
        oper_y: Optional[Any] = None,
        oper_z: Optional[Any] = None,
        varsprot: Optional[Any] = None,
    ) -> None:
        """
        Apply spatial and/or temporal aggregation to the input dataset.

        This method performs post-processing operations on the input NetCDF file by aggregating
        data in time and spatial dimensions (`x`, `y`, `z`). It supports rolling means, domain
        reduction, and other configured statistics, and outputs the aggregated result to `fileout`.

        Parameters
        ----------
        DataProgsToUse : Dict[str, Union[CDO, NCO, NCSYS, PyXarray]]
            Dictionary of initialized backends used to execute operations on NetCDF files.

        filein : str
            Path to the input NetCDF file to be processed.

        fileout : str
            Path where the aggregated output NetCDF file will be saved.

        evalvars : List[str]
            List of variable names to apply the aggregation on.

        cfgRestime : Dict[str, str]
            Configuration dictionary for temporal resolution, including:
            - "operator_time" : str — temporal aggregation method (e.g., "mean", "sum")
            - "target_EvalFrequency" : str — frequency string (e.g., "monthly", "daily")

        posdimnames : Dict[str, List[str]]
            Mapping of expected dimension names used in the dataset, such as:
            - {"x": ["lon"], "y": ["lat"], "z": ["lev"], "t": ["time"]}

        cfgrollingm : Optional[Any], default=None
            Rolling mean configuration (e.g., window size or dict of window settings). If provided,
            this operation will be applied before final aggregation.

        oper_x : Optional[Any], default=None
            Spatial aggregation operation along the x-dimension (e.g., "mean", "max").

        oper_y : Optional[Any], default=None
            Spatial aggregation operation along the y-dimension (e.g., "mean", "min").

        oper_z : Optional[Any], default=None
            Spatial aggregation operation along the z-dimension (e.g., vertical levels).

        varsprot : Optional[Any], default=None
            List of variables to protect from aggregation (e.g., metadata variables).

        Returns
        -------
        None
            Aggregated data is saved to the location specified in `fileout`.

        Notes
        -----
        This is a core routine used in many stages of the EvaSuite pipeline where temporal or spatial
        normalization, averaging, or reduction is required prior to metric evaluation.
        """
        # -- Local variables:
        if isinstance(DataProgsToUse["pyxarray"], PyXarray):
            pyxarray_object = DataProgsToUse["pyxarray"]

        finalres = pyxarray_object.OperaSpatialTemporal(
            filein = filein,
            fileout = fileout,
            evalvars = evalvars,
            cfgRestime = cfgRestime,
            posdimnames = posdimnames,
            cfgrollingm = cfgrollingm,
            spatialopx = oper_x,
            spatialopy = oper_y,
            spatialopz = oper_z,
            varsprot = varsprot,
        )
        return finalres


class DataMiningGridded(DataMining):
    @log_function_name
    def __init__(self: 'DataMiningGridded') -> None:
        """ Initialization of variables for DataMiningGridded class:"""
        # -- Set a deligation rules for DataMiningGridded class:
        super().__init__("DataMiningGridded")

    @log_function_name
    def GridInterpolation(
        self: 'DataMiningGridded',
        cfgdatamining: Dict[str, Any],
        DataProgsToUse: Dict[str, Union[CDO, NCO, NCSYS, PyXarray]],
        cfgdataset: Dict[str, Any],
        datafile: str,
        hori_refgridf: str,
        hori_refgridtype: str,
        vert_refgridf: Any,
        vert_refgridtype: Any,
        evalparas_dat2ip: List[str],
        vert_refevalpars: Any,
        resultout: str,
        tmpfile: Optional[bool] = False,
    ) -> None:
        """
        Perform horizontal and vertical interpolation for gridded datasets.

        This method interpolates a gridded input dataset onto a user-defined
        horizontal and/or vertical reference grid according to the data-mining
        configuration. Depending on the configuration, interpolation may be
        skipped if the source grid already matches the reference grid.

        Supported interpolation backends include CDO, NCO, and PyXarray.

        Parameters
        ----------
        cfgdatamining : dict
            Data-mining configuration containing interpolation settings,
            target grids, temporal aggregation options, and masking rules.
        DataProgsToUse : dict
            Dictionary of initialized processing backends (e.g., CDO, NCO,
            PyXarray) used for interpolation.
        cfgdataset : dict
            Dataset-specific configuration (grid type, level type, parameters).
        datafile : str
            Path to the input dataset to be interpolated.
        hori_refgridf : str
            NetCDF file defining the horizontal reference grid.
        hori_refgridtype : str
            Identifier of the horizontal reference grid type.
        vert_refgridf : Any
            File or object defining the vertical reference grid.
        vert_refgridtype : Any
            Identifier of the vertical reference grid type.
        evalparas_dat2ip : list of str
            Dataset variables to be interpolated.
        vert_refevalpars : Any
            Vertical evaluation parameters used for interpolation.
        resultout : str
            Output file path for the interpolated dataset.
        tmpfile : bool, optional
            If True, keep intermediate temporary files.

        Returns
        -------
        tuple
            A tuple ``(fileres_hori, fileres_vert)`` where each element is the
            path to the horizontally and vertically interpolated file,
            respectively. Elements are ``None`` if the corresponding
            interpolation step was skipped.

        Raises
        ------
        ValueError
            If incompatible grid types are detected or unsupported grid
            configurations are requested.

        Notes
        -----
        Horizontal and vertical interpolation are performed independently.
        If the source grid already matches the reference grid, the respective
        interpolation step is skipped.
        """
        # -- Local variables (CDO, NCO, PyXarray objects):
        if isinstance(DataProgsToUse["cdo"], CDO):
            cdo_object = DataProgsToUse["cdo"]

        if isinstance(DataProgsToUse["nco"], NCO):
            nco_object = DataProgsToUse["nco"]

        if isinstance(DataProgsToUse["pyxarray"], PyXarray):
            pyxarray_object = DataProgsToUse["pyxarray"]

        # -- Pick out the horizontal grid description of the source data and the
        #    data on reference grid to check if the file to interpolate has the
        #    same horizontal grid as the reference grid:
        fileres1, fileres2 = None, None
        if hori_refgridtype is not None:
            griddesf = (
                f'griddes_{hori_refgridtype}_{cfgdatamining["targetgrid_horizontal"]}'
            )
            cdo_object.ExtractGridDesF(
                targetncdf = hori_refgridf, griddesfile = griddesf)
            grid_source = "griddes_source"
            cdo_object.ExtractGridDesF(
                targetncdf = datafile, griddesfile = grid_source,
            )
            if filecmp.cmp(griddesf, grid_source):
                logger.debug(
                    'Same hor. grid as the reference -> Interpolation was skipped.')

            elif hori_refgridtype == "gridded" or hori_refgridtype == "station":
                LCC = (
                    True if nco_object.FindVarName(
                        datafile, 'lambert_conformal_conic', PartString = True)
                    else False
                )
                fileres1 = cdo_object.IntpolHori(
                    filein = datafile,
                    fileout = resultout,
                    method = cfgdatamining["interpol_method"],
                    griddesf = griddesf,
                    lcc = LCC,
                )
            else:
                raise ValueError(
                    f"Unsupported grid type: {hori_refgridtype}."
                    " Please choose a supported grid format."
                )

            sp.check_call(["sh", "-c", "rm -rf " + griddesf + " " + grid_source])

        # -- Pickout the vertical level description of source data and data on
        #    reference grid:
        if vert_refgridtype is not None:
            vertlevs_ref = pyxarray_object.ExtractLevInfoFromNC(
                vert_gridtype = vert_refgridtype,
                ncfile = vert_refgridf,
                varlist = vert_refevalpars,
            )

            logger.debug(
                f"Height levels of reference vert. grid: {vertlevs_ref}")
            vertlevs_source = pyxarray_object.ExtractLevInfoFromNC(
                vert_gridtype = cfgdataset["levtype"],
                ncfile = datafile,
                varlist = evalparas_dat2ip,
            )
            logger.debug(
                f"Height levels of vert. grid from file to "
                f"interpolate: {vertlevs_source}"
            )

            if sorted(vertlevs_ref[vert_refevalpars[0]]) == sorted(vertlevs_source[evalparas_dat2ip[0]]):
                logger.debug(
                    'File to interpolate with the same vertical grid as '
                    'the reference -> ' + 'Interpolation was skipped.'
                )
            elif vert_refgridtype == "height":
                predata = datafile if (fileres1 is None) else fileres1
                fileres2 = cdo_object.IntpolVert(
                    filein = predata,
                    fileout = resultout,
                    targetlevs = vertlevs_ref[vert_refevalpars[0]],
                    tmpfile = tmpfile,
                )
            else:
                logger.error(
                    f'The vertical grid type {vert_refgridtype}'
                    ' is not supported as target for gridded datasets'
                )
                raise ValueError(f"Unsupported vertical grid type: {vert_refgridtype}")

        return fileres1, fileres2


class DataMiningStation(DataMining):
    @log_function_name
    def __init__(self: 'DataMiningStation') -> None:
        """Initialization of variables for DataMiningStation class"""
        # -- Set a deligation rules for DataMiningStation class:
        super().__init__("DataMiningStation")

    @log_function_name
    def GridInterpolation(
        self: 'DataMiningStation',
        cfgdatamining: Dict[str, Any],
        DataProgsToUse: Dict[str, Union[CDO, NCO, NCSYS, PyXarray]],
        cfgdataset: Dict[str, Any],
        datafile: str,
        hori_refgridf: str,
        hori_refgridtype: str,
        vert_refgridf: Any,
        vert_refgridtype: Any,
        evalparas_dat2ip: List[str],
        vert_refevalpars: Any,
        resultout: str,
        tmpfile: Optional[bool] = False,
    ) -> None:
        """
        Perform interpolation for station-based observational datasets.

        This method interpolates irregularly spaced station data onto a regular grid,
        optionally applying both horizontal and vertical transformations using reference
        grids and methods defined by the user. The output is a new NetCDF file that matches
        the desired evaluation grid and structure.

        Parameters
        ----------
        cfgdatamining : Dict[str, Any]
            Dictionary of user-defined settings for interpolation, including:
            - "targetgrid_horizontal" : str — target grid reference name (e.g., ERA5-monthly)
            - "targetgrid_vertical" : str or Any — reference for vertical grid alignment
            - "interpol_method" : str — interpolation method (e.g., bilinear, nearest)
            - "targettime_fullspan", "targettime_season", etc. — time-related controls
            - "subregions_acronyms" : list[str] — optional region masking
            - "mask_landsea", "mask_Orography" : str — optional masks

        DataProgsToUse : Dict[str, Union[CDO, NCO, NCSYS, PyXarray]]
            Dictionary of initialized processing tool interfaces (e.g., CDO, NCO).

        cfgdataset : Dict[str, Any]
            Dataset-specific settings such as:
            - "format_data", "gridtype", "levtype"
            - "storagedir", "storagefil", "paramcorr", etc.

        datafile : str
            Path to the original NetCDF station dataset to be interpolated.

        hori_refgridf : str
            Path to the NetCDF file representing the horizontal reference grid.

        hori_refgridtype : str
            Description or name of the horizontal grid type (e.g., "regular", "curvilinear").

        vert_refgridf : Any
            Path or structure containing vertical grid reference information.

        vert_refgridtype : Any
            Type/description of the vertical reference grid (e.g., pressure levels).

        evalparas_dat2ip : List[str]
            List of parameter names that should be interpolated (e.g., ["tas", "pr"]).

        vert_refevalpars : Any
            Reference vertical parameter settings for interpolation (if applicable).

        resultout : str
            Path to the output interpolated NetCDF file.

        tmpfile : Optional[bool], default=False
            Whether to treat intermediate results as temporary files (for cleanup or chaining).

        Returns
        -------
        None
            The interpolated dataset is written directly to the `resultout` path.

        Notes
        -----
        This function is a station-specific variant of gridded interpolation used in EvaSuite.
        It supports flexible configuration of interpolation methods and domain masking, and
        is typically invoked during preprocessing or evaluation workflows.
        """
        # -- Local variables (CDO, PyXarray objects):
        if isinstance(DataProgsToUse["cdo"], CDO):
            cdo_object = DataProgsToUse["cdo"]

        if isinstance(DataProgsToUse["pyxarray"], PyXarray):
            pyxarray_object = DataProgsToUse["pyxarray"]

        # -- Pick out the horizontal grid description of the source data and
        #    the data on reference grid to check if the file to interpolate has
        #    the same horizontal grid as the reference grid
        fileres1, fileres2 = None, None
        if hori_refgridtype is not None:
            logger.error(
                f"For grid type {self.name} no spatial interpolation is implemented ")

        if vert_refgridtype is not None:
            vertlevs_ref = pyxarray_object.ExtractLevInfoFromNC(
                vert_gridtype = vert_refgridtype,
                ncfile = vert_refgridf,
                varlist = vert_refevalpars,
            )
            logger.debug(f"Height levels of reference vert. grid: {vertlevs_ref}")

            vertlevs_source = pyxarray_object.ExtractLevInfoFromNC(
                vert_gridtype = cfgdataset["levtype"],
                ncfile = datafile,
                varlist = evalparas_dat2ip,
            )

            logger.debug(
                f"Height levels of vert. grid from file to interpolate: {vertlevs_source}"
            )

            if (sorted(vertlevs_ref[vert_refevalpars[0]]) ==
                    sorted(vertlevs_source[evalparas_dat2ip[0]])):
                logger.debug(
                    'File to interpolate with the same vertical grid '
                    'as the reference -> Interpolation was skipped.'
                )

            elif vert_refgridtype == "height":
                predata = datafile if (fileres1 is None) else fileres1
                fileres2 = cdo_object.IntpolVert(
                    filein = predata,
                    fileout = resultout,
                    targetlevs = vertlevs_ref[vert_refevalpars[0]],
                    tmpfile = tmpfile,
                )
            else:
                logger.error(
                    f"The vertical grid type {vert_refgridtype} "
                    f"is not supported as target for gridded datasets"
                )
                raise ValueError(f"Unsupported vertical grid type: '{vert_refgridtype}'")
        return fileres1, fileres2
