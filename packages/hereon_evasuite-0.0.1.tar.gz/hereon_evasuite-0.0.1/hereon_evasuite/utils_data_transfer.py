# EvaSuite
#
# ---------------------------------------------------------------
# Copyright (C) 2004-2025, Hereon
# Contact information: beate.geyer@hereon.de, imktro-climate-modelling@lists.kit.edu
# See AUTHORS.TXT for a list of authors
# See LICENSES/ for license information
# SPDX-License-Identifier: Apache-2.0
# ---------------------------------------------------------------
# -- Import Python modules
import os
import shutil
from typing import List
# -- Import user modules
from hereon_evasuite.log_EvaSuite import get_logger, log_function_name
logger = get_logger()


class WPDataCopier:
    """
    Handles conditional copying of data and log/config files for WP03 and WP04 directories.
    """
    def __init__(self, cfggen: dict) -> None:
        """
        Initialize the WPDataCopier.

        Parameters
        ----------
        cfggen : dict
            Configuration dictionary containing 'directoryDM_WPcompeval'.
        """
        self.dm_wp_compeval = cfggen.get('directoryDM_WPcompeval', [])
        if len(self.dm_wp_compeval) == 0:
            raise ValueError(
                "'directoryDM_WPcompeval' are not set. Check general namelist")

    def _copy_folder(self, src: str, dest: str) -> None:
        """
        Helper method to copy a folder, allowing existing directories.

        Parameters
        ----------
        src : str
            Source directory path.
        dest : str
            Destination directory path.
        """
        try:
            shutil.copytree(src, dest, dirs_exist_ok=True)
        except Exception as e:
            logger.warning(f"Could not copy {src} → {dest}: {e}")

    @log_function_name
    def wp_data_transfer(self, datadir_eva: str, savedir: str) -> None:
        """
        Transfer WP03/WP04 data folders with specific filtering logic.

        Parameters
        ----------
        datadir_Eva : str
            Base directory where WP data is stored.
        savedir : str
            Target directory to copy data into.
        """
        try:
            for subdir in self.dm_wp_compeval:
                wp_path = os.path.join(datadir_eva, subdir)
                wp_basename = os.path.basename(wp_path)
                dest_path = os.path.join(savedir, wp_basename)

                wp_lower = wp_basename.lower()
                if "wp03" not in wp_lower and "wp04" not in wp_lower:
                    raise ValueError(
                        f"Only WP03 or WP04 are supported. Found unsupported folder: {wp_basename}"
                    )

                if not os.path.exists(wp_path):
                    logger.warning(f"Skipping missing path: {wp_path}")
                    continue

                os.makedirs(dest_path, exist_ok=True)

                for item in os.listdir(wp_path):
                    src_item = os.path.join(wp_path, item)
                    dest_item = os.path.join(dest_path, item)

                    # -- Skip non-folders:
                    if not os.path.isdir(src_item):
                        continue

                    is_vs = "_vs_" in item
                    is_empty = not any(os.scandir(src_item))

                    # --- WP03: skip "_vs_" if empty
                    if "wp03" in wp_lower:
                        if is_vs and is_empty:
                            continue
                        self._copy_folder(src_item, dest_item)

                    # --- WP04: copy only "_vs_"
                    elif "wp04" in wp_lower:
                        if is_vs:
                            self._copy_folder(src_item, dest_item)

                logger.info(f"Copied WP folder: {wp_path} → {dest_path}")

        except Exception as e:
            logger.error(f"Not critical error: Failed to copy WPcompeval data: {e}")

    @log_function_name
    def logs_data_transfer(self, main_cfgfiles: List[str], savedir: str) -> None:
        """
        Copy configuration/log files to savedir.

        Parameters
        ----------
        main_cfgfiles : List[str]
            List of configuration file paths to copy.
        savedir : str
            Target directory.
        """
        for file in main_cfgfiles:
            try:
                shutil.copy(file, savedir)
            except Exception as e:
                logger.error(f"Not critical error: Failed to copy config file {file}: {e}")

    @log_function_name
    def plots_data_transfer(self, visualdir_Eva: str, savedir: str) -> None:
        """
        Copy visualization plots from visualdir to savedir.

        Parameters
        ----------
        visualdir_Eva : str
            Source directory containing visualizations.
        savedir : str
            Target directory.
        """
        try:
            for filename in os.listdir(visualdir_Eva):
                src_path = os.path.join(visualdir_Eva, filename)
                dest_path = os.path.join(savedir, filename)
                if os.path.isdir(src_path):
                    shutil.copytree(src_path, dest_path, dirs_exist_ok=True)
                else:
                    shutil.copy2(src_path, dest_path)
        except Exception as e:
            logger.error(f"Not critical error: Failed to copy visualization data: {e}")
