# EvaSuite
#
# ---------------------------------------------------------------
# Copyright (C) 2004-2025, Hereon
# Contact information: beate.geyer@hereon.de, imktro-climate-modelling@lists.kit.edu
# See AUTHORS.TXT for a list of authors
# See LICENSES/ for license information
# SPDX-License-Identifier: Apache-2.0
# ---------------------------------------------------------------

# ---------------------------------------------------------------
#    Program Description:
#    A utility class for reading, validating, renaming, and extracting
#    data from NetCDF-4 files (typically .nc) using xarray.
#
#    Key Capabilities:
#    - Reads 1D or 2D datasets with dimensions ('values_time') or ('values_time', 'values_lat', 'values_lat')
#    - Validates variable lists and their expected structure
#    - Renames known variables to standardized names for consistency
#    - Extracts metadata (long_name, units, etc.) along with the data
#    - Returns data in a dictionary structure suitable for visualization
#
#    Primary Functions:
#    - __get_variable_data: Safely extracts coordinates like values_time, values_lat, values_lat
#    - __get_file_name: Extracts the dataset name from file path using regex
#    - rename_nc: Renames legacy variable names (e.g., 'TEMP' → 'T_2M') and updates metadata
#    - read_nc: Reads NetCDF file and returns a dictionary with cleaned and structured data
#
#    History:
#    Version    Date       Name
#    ---------- ---------- ----
#    1.1        04.2025   Evgenii Churiulin, IMKTRO
#                         Initial realise
# ---------------------------------------------------------------
# -- Import python packages:
import re
import os
import numpy as np
import xarray as xr
import cartopy.crs as ccrs

from typing import List, Dict, Optional, Tuple

# -- Import user methods:
from hereon_evasuite.visual_support import load_rename_mapping
from hereon_evasuite.log_EvaSuite import get_logger, log_function_name

logger = get_logger()


class Read_nc4_2dmap:
    """
    A class to read and preprocess NetCDF-4 climate data for 1D or 2D visualizations.

    This class provides:
    ----------------------------
    - Coordinate validation and extraction (values_lat, values_lat, values_time)
    - Standardized renaming of common climate variables
    - Intelligent detection of data shape (1D vs 2D)
    - Output as a dictionary format for use in downstream plotting or analysis

    Expected input files:
    ----------------------------
    - NetCDF files with standard climate variables
    - Dimensions: ('values_time') for 1D or ('values_time', 'values_lat', 'values_lat') for 2D fields

    Attributes:
    ----------
    __lim_len_list : int
        Max number of variables allowed in the dataset.
    __lim_len_var : int
        Max number of non-coordinate variables to evaluate.
    __lat_coord, __lon_coord, __time_coord : list[str]
        Allowed coordinate names.
    """
    @log_function_name
    def __init__(self, pol_lon: float, pol_lat: float) -> None:
        """
        Initialize default configuration values and coordinate naming conventions.

        This method sets up:
        ----------------------------
            - Limits for list and variable name lengths.
            - Standard and non-standard naming conventions for latitude, longitude, and time coordinates.
            - Combined coordinate name lists for easier lookup.
            - Default ICON-EUROPE map projection parameters (pole longitude and latitude)
              loaded from the default map settings.
            - A regular expression pattern for matching filenames within a path.

        Attributes
        ----------
            __lim_len_list : int
                Maximum allowed list length for certain internal operations.
            __lim_len_var : int
                Maximum allowed variable name length.
            __nonstandard_lat : list[str]
                List of non-standard latitude coordinate names.
            __standard_lat : list[str]
                List of standard latitude coordinate names.
            __nonstandard_lon : list[str]
                List of non-standard longitude coordinate names.
            __standard_lon : list[str]
                List of standard longitude coordinate names.
            __nonstandard_time : list[str]
                List of non-standard time coordinate names.
            __standard_time : list[str]
                List of standard time coordinate names.
            __lat_coord : list[str]
                Combined list of all possible latitude coordinate names.
            __lon_coord : list[str]
                Combined list of all possible longitude coordinate names.
            __time_coord : list[str]
                Combined list of all possible time coordinate names.
            pole_longitude : float
                ICON-EUROPE rotated pole longitude (default from map settings).
            pole_latitude : float
                ICON-EUROPE rotated pole latitude (default from map settings).
            __file_mask : str
                Regular expression pattern to extract the directory name from a NetCDF file path.
        """
        self.__lim_len_list: int = 25
        self.__lim_len_var: int = 21
        # -- Variables by categories:
        #    Latitude:
        self.__nonstandard_lat: list[str] = ['rlat', 'clat']
        self.__standard_lat: list[str] = ['lat', 'latitude', 'LAT']
        #    Longitude:
        self.__nonstandard_lon: list[str] = ['rlon', 'clon']
        self.__standard_lon: list[str] = ['lon', 'longitude', 'LON']
        #    Time
        self.__nonstandard_time: list[str] = []
        self.__standard_time: list[str] = ['time', 'TIME', 'valid_time']

        self.__lat_coord: list[str] = self.__nonstandard_lat + self.__standard_lat
        self.__lon_coord: list[str] = self.__nonstandard_lon + self.__standard_lon
        self.__time_coord: list[str] = self.__nonstandard_time + self.__standard_time

        self.pole_longitude, self.pole_latitude = pol_lon, pol_lat

        # -- Special filename mask:
        # Other options: r'\.([^.]+)\.nc$', r'/([^/]+)(?=\.[^.]+\..*\.nc$)', r'/([^/]+)(?=\.[^.]+\..*\.nc$)'
        self.__file_mask = r'/([^/]+)/[^/]+\.nc$'

    def rotated_to_geographic_cartopy(
        self,
        rlon: np.ndarray,
        rlat: np.ndarray,
        pole_lat: float,
        pole_lon: float
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Convert rotated coordinates to geographical coordinates.

        Parameters:
        -----------
        rlon, rlat : np.ndarray
            Rotated longitude and latitude (in degrees).
        pole_lat, pole_lon : float
            Geographic latitude and longitude of the rotated pole (in degrees).

        Returns:
        --------
        lon, lat : np.ndarray
            Geographic coordinates (in degrees).
        """

        rotated_crs = ccrs.RotatedPole(pole_latitude=pole_lat, pole_longitude=pole_lon)
        plate_crs = ccrs.PlateCarree()
        # expects 1D inputs, so mesh first
        rlon2d, rlat2d = np.meshgrid(rlon, rlat)
        pts = plate_crs.transform_points(rotated_crs, rlon2d, rlat2d)
        lon2d, lat2d = pts[...,0], pts[...,1]
        return lon2d, lat2d

    def __get_variable_data(
        self,
        ds: xr.Dataset,
        path: str,
        var_name: str,
        coord_set: List[str],
    ) -> tuple[np.ndarray | list[str]]:
        """
        Extracts the specified coordinate variable from the dataset.

        Parameters:
        -----------
        ds : xr.Dataset
            The opened NetCDF dataset.
        path : str
            File path (used for error messages).
        var_name : str
            Name of the variable to extract ('values_time', 'values_lat', or 'lon').
        coord_set : list
            List of valid coordinate names.

        Returns:
        --------
        np.ndarray | list[str], bool
            The extracted data array (or formatted values_time strings).

        Raises:
        -------
        ValueError
            If the variable is not found in the dataset.
        """
        # -- Local variables:
        if var_name not in coord_set:
            raise ValueError(
                f"There is no '{var_name}' variable in {path}. "
                f"Solution: Please use `ncdump -h` to check your variables."
            )

        # -- Extract and preprocess coordinate data
        # -- Case 1: clon, clat:
        if var_name in ['clon', 'clat']:
            logger.info(f"Working with {var_name} (radians to degrees)")
            var_data = np.rad2deg(ds[var_name].values)

        # -- Case 2: rlon, rlat:
        elif var_name in ['rlat', 'rlon']:
            logger.info(f"Working with {var_name} (rotated to geographical coordinates)")
            # -- Extract 1D rotated coordinates
            rlat_1d = ds['rlat'].values
            rlon_1d = ds['rlon'].values

            # -- Convert to 2D geographic coordinates:
            logger.info(f'pole_latitude and pole_longitude: {self.pole_latitude} and {self.pole_longitude}')
            lon2d, lat2d = self.rotated_to_geographic_cartopy(
                rlon_1d, rlat_1d, self.pole_latitude, self.pole_longitude)

            var_data = lat2d if var_name == "rlat" else lon2d
        # -- Case 3: other cases + time:
        else:
            logger.info(f'Working with {var_name} coordinates')
            var_data = ds[var_name].data

        # -- Special handling for 'time' variable:
        if var_name == 'time':
            # -- Format the 'time' variable into a readable string
            return [str(t).split(".")[0].replace("T", " ") for t in var_data]
        return var_data

    def __get_file_name(self, path: str) -> str:
        """
        Extracts a dataset name component from the given file path using regex.

        Parameters:
        -----------
        path : str
            The full file path to the NetCDF file.

        Returns:
        --------
        str
            Extracted name segment for identifying the dataset.
        """
        # -- Extract the desired part using regex:
        match = re.search(self.__file_mask, path)
        if match:
            return match.group(1)
        else:
            # Fallback: use filename without extension
            logger.warning(f"Regex did not match path: {path}, fallback to basename.")
            return re.sub(r'\.nc$', '', path.split('/')[-1])

    def __resolve_coord_name(
        self,
        ds: xr.Dataset,
        coord_type: str,
    ) -> Optional[str]:
        """
        Resolves and prioritizes coordinate names in the dataset.

        Priority:
        ---------
        - If rotated/custom coords (e.g., rlat, clon) exist → return them
        - Else fallback to standard ones (e.g., lat)

        Parameters:
        -----------
        ds : xr.Dataset
            The dataset to scan.
        coord_type : str
            Either 'lat', 'lon' or 'time'.

        Returns:
        --------
        str or None
            The actual variable name used in the dataset.
        """
        if coord_type == 'lat':
            rotd_opt, stnd_opt = self.__nonstandard_lat, self.__standard_lat
        elif coord_type == 'lon':
            rotd_opt, stnd_opt = self.__nonstandard_lon, self.__standard_lon
        elif coord_type == 'time':
            rotd_opt, stnd_opt = self.__nonstandard_time, self.__standard_time
        else:
            raise ValueError(f"Invalid coord_type: {coord_type}. Use 'lat', 'lon' or 'time'.")

        # -- First look for rotated/custom options:
        for name in rotd_opt:
            if name in ds.variables:
                return name

        # -- Fallback to standard options:
        for name in stnd_opt:
            if name in ds.variables:
                return name
        return None

    def wait_for_file_ready(
        self,
        path: str,
        retries: int = 5,
        delay: float = 0.5,
    ) -> None:
        """
        Wait until the file exists, is non-empty, and accessible for reading.
        """
        from pathlib import Path
        import time

        for attempt in range(retries):
            try:
                file = Path(path)
                if file.exists() and file.stat().st_size > 0:
                    with open(file, 'rb'):
                        return
                logger.warning(f"[Attempt {attempt+1}/{retries}] File {path} not ready, retrying...")
            except (OSError, PermissionError):
                logger.warning(f"[Attempt {attempt+1}/{retries}] File {path} not accessible, retrying...")
            time.sleep(delay)

        raise RuntimeError(f"File {path} is still not ready after {retries} attempts.")

    @log_function_name
    def rename_nc(self, path: str, mapping_csv: str) -> None:
        """
        Renames known legacy variables to standardized names and updates their metadata.

        Parameters:
        -----------
        path : str
            Path to the NetCDF file to be modified.

        Behavior:
        ---------
            - Renames known variables (e.g., 'SIS' → 'SOD_S', 'TEMP' → 'T_2M')
            - Updates their `long_name` attributes.
            - Overwrites the NetCDF file with changes if any renaming is performed.
        """
        import time
        max_tries = 5

        # -- Load rename mapping:
        rename_mapping = load_rename_mapping(mapping_csv)

        # -- Open and modify the NetCDF file:
        try:
            self.wait_for_file_ready(path, retries=max_tries)
            with xr.open_dataset(path) as ds:
                # -- Ensure data is loaded into memory:
                ds = ds.load()
                renamed = False

                # -- Check for renaming needs:
                for new_variable, info in rename_mapping.items():
                    old_variables, new_long_name = info["old_names"], info["long_name"]
                    # -- Skip renaming if the new variable name already exists in the dataset
                    if new_variable in ds:
                        continue
                    # -- Find the first matching variable from the old names list:
                    old_name_found = next((name for name in old_variables if name in ds), None)
                    # -- Rename the variable:
                    if old_name_found:
                        ds = ds.rename({old_name_found: new_variable})
                        # Set long_name attribute:
                        ds[new_variable].attrs["long_name"] = new_long_name
                        renamed = True

                # --Check for renaming needs:
                if renamed:
                    tmp_path = path + ".tmp"
                    for attempt in range(max_tries):
                        try:
                            ds.to_netcdf(tmp_path)
                            self.wait_for_file_ready(tmp_path, retries=max_tries)
                            os.replace(tmp_path, path)
                            logger.info(f"NetCDF file updated and saved as: {path}")
                            break
                        except PermissionError:
                            logger.warning(f"Attempt {attempt + 1}: Failed to write {path}, retrying...")
                            time.sleep(0.5)
                    else:
                        raise RuntimeError(f"Failed to save {path} after {max_tries} attempts")
        except Exception as e:
            raise ValueError(f"Failed to open dataset {path}: {e}")

    @log_function_name
    def read_nc(self, path: str) -> Dict:
        """
        Reads a NetCDF file and extracts data and metadata in a structured format.

        Parameters:
        -----------
        path : str
            Path to the NetCDF file.

        Returns:
        --------
        dict:
            Dictionary of variables keyed by variable name.
            Each value is a sub-dictionary containing:
                - 'var4vis': the data array
                - 'var_lat', 'var_lon' (for 2D)
                - 'long_name', 'units', 'values_time', 'ds_name'
        bool:
            Flag for rotated coordinates

        Raises:
        -------
        TypeError:
            If the dataset does not contain expected dimensions.
        ValueError:
            If there are too many variables or unsupported dimensions.
        """
        # -- Local variables:
        max_tries = 5
        # -- Dictionary to store variable data:
        variables_dict = {}
        # -- Open the NetCDF file with context manager
        # Wait for the file to be safely ready
        self.wait_for_file_ready(path, retries=max_tries)
        with xr.open_dataset(path) as ds:
            # -- Get list of NetCDF attributes:
            variable_names = list(ds.variables.keys())
            logger.info(f'Variable names in dataset: {variable_names}')

            # -- Load attribute variables:
            coord_lat = self.__resolve_coord_name(ds, 'lat')
            coord_lon = self.__resolve_coord_name(ds, 'lon')
            coord_time = self.__resolve_coord_name(ds, 'time')

            # -- Get coordinate variables:
            coord_vars = {name for name in (coord_lat, coord_lon, coord_time) if name is not None}

            # -- Depending on input NetCDF variables change algorithms for 1D or 2D plots:
            has_lat = coord_lat in variable_names
            has_lon = coord_lon in variable_names
            has_time = coord_time in variable_names

            # -- Validate resolved coordinate names (None if not found)
            if coord_time is None:
                logger.error(f"Time coordinate could not be resolved in file: {path}")
                raise ValueError(f"Missing time coordinate in dataset '{path}'")

            # -- 1D case:
            if has_time and not (has_lat or has_lon):
                values_time = self.__get_variable_data(
                    ds, path, coord_time, self.__time_coord)
            # -- # 2D case:
            elif has_time and has_lat and has_lon:
                values_lat = self.__get_variable_data(
                    ds, path, coord_lat, self.__lat_coord)
                values_lon = self.__get_variable_data(
                    ds, path, coord_lon, self.__lon_coord)
                values_time = self.__get_variable_data(
                    ds, path, coord_time, self.__time_coord)
            else:
                logger.error(
                    f"Unknown coordinate combination in dataset '{path}'. "
                    f"Expected time-only or time+lat+lon. Found: {variable_names}"
                )
                raise TypeError(f"Unsupported variable layout in '{path}': {variable_names}")

            # -- Validate resolved coordinate names (None if not found)
            if values_time is None:
                raise ValueError(f"Variable 'values_time' is equal None in dataset '{path}'")

            # -- Get only research variable (s):
            filtered_variables = [
                var for var in ds.variables
                if var not in coord_vars and var not in ['lat', 'lon', 'rlat', 'rlon', 'clat', 'clon']
            ]
            logger.info(f'Filtered variables: {filtered_variables}')

            # -- Raise an error if there are more than eval_metrics and values_lat, values_lat, values_time variables:
            if len(variable_names) > self.__lim_len_list:
                raise ValueError(
                    f"Too many variables in the dataset '{path}'."
                    f" Found '{len(variable_names)}' variables. Limit is {self.__lim_len_list}"
                    "Solution: please check variables in your file. Use ncdump -h or increase limits"
                )
            if len(filtered_variables) > self.__lim_len_var:
                raise ValueError(
                    f"Too many filtered variables in the dataset '{path}'."
                    f" Found '{len(filtered_variables)}' variables. Limit is {self.__lim_len_var}"
                    "Solution: please check eval metrics in this file. Use ncdump -h "
                )

            # -- Check the dimensions and load accordingly:
            for var_name in filtered_variables:
                # -- Get variable:
                var = ds[var_name]
                # -- Skip scalar variables (no dimensions):
                if len(var.dims) == 0:
                    logger.info(f"Skipping scalar variable '{var_name}' with no dimensions.")
                    continue

                # -- Extract variable attributes: long_name and units
                long_name = var.attrs.get('long_name', '')
                units = var.attrs.get('units', '')
                # -- Read data:
                match var.dims:
                    # -- Read fields with (values_time, values_lon, values_lat) --> for 2D fields:
                    case (coord_time, coord_lat, coord_lon):
                        if var.sizes[coord_time] >= 1:
                            data = var.values
                            # -- Create dictionary for visualization:
                            data4visualization = {
                                'var4vis': data,
                                'var_lon': values_lon,
                                'var_lat': values_lat,
                                'long_name': long_name,
                                'units': units,
                                'time': values_time,
                                'ds_name': self.__get_file_name(path),
                            }
                    # -- Read fields with ('values_time') --> for 1D fields:
                    #    Don´t remove ',' after values_time. It is important here:
                    case (coord_time,):
                        if var.sizes[coord_time] >= 1:
                            data = var.values
                            # -- Create dictionary for visualization:
                            data4visualization = {
                                'var4vis': data,
                                'long_name': long_name,
                                'units': units,
                                'time': values_time,
                                'ds_name': self.__get_file_name(path),
                            }
                    # -- Wildcard:
                    case _:
                        # Catch-all for other dimensions
                        raise ValueError(
                            f"Unsupported dimensions - {var.dims}. Expected ({coord_time},"
                            f" {coord_lat}, {coord_lon}) for 2D plots or ({coord_time}) for 1D plots"
                        )

                # -- Add to the main variables dictionary
                variables_dict[var_name] = data4visualization
        # -- Return dictionary back:
        return variables_dict
