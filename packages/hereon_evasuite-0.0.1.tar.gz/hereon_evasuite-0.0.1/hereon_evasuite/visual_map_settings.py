# EvaSuite
#
# ---------------------------------------------------------------
# Copyright (C) 2004-2025, Hereon
# Contact information: beate.geyer@hereon.de, imktro-climate-modelling@lists.kit.edu
# See AUTHORS.TXT for a list of authors
# See LICENSES/ for license information
# SPDX-License-Identifier: Apache-2.0
# ---------------------------------------------------------------

# ---------------------------------------------------------------
#    Program description:
#    User methods for visualization of 2d plots
#
#    History:
#    Version    Date       Name
#    ---------- ---------- ----
#    1.1        02.2025   Evgenii Churiulin, IMKTRO
#                         Initial realise
#    1.2        07.2025   Evgenii Churiulin, IMKTRO
#                         added new projection
# ---------------------------------------------------------------
# -- Import python packages:
import numpy as np
import cartopy
import cartopy.crs as ccrs
import matplotlib.pyplot as plt
from matplotlib.colorbar import Colorbar
from matplotlib.colors import Colormap, Normalize
from matplotlib.cm import ScalarMappable
from matplotlib.figure import Figure
from cartopy.mpl.geoaxes import GeoAxes
from cartopy.mpl.gridliner import Gridliner

from typing import Dict, Any, Callable, Optional, Union
from hereon_evasuite.log_EvaSuite import get_logger, log_function_name
logger = get_logger()


class Map_settings:
    """Class with common settings for 2d plots (maps):"""
    # -- Cartopy layer settings:
    map_tolerance: float
    map_land_color: str
    map_land_zorder: float
    map_land_lw: float
    map_land_edgecolor: str
    map_land_alpha: float

    # -- Coastline settings:
    map_coast_resolution: str
    map_coast_lw: float
    map_coast_lc: str

    # -- Ocean settings:
    map_ocean_color: str
    map_ocean_zorder: float

    # -- Grid settings:
    map_grid_add: bool
    map_grid_lw: float
    map_grid_x_inline: bool
    map_grid_y_inline: bool
    map_grid_alpha: float
    map_grid_color: str
    map_grid_xlocs: range
    map_grid_ylocs: range

    # -- Colorbar settings:
    map_colorbar: dict
    map_colorbar_diff: str
    map_colorbar_orientation: str
    map_colorbar_orientation_diff: str
    map_colorbar_extend: str
    map_colorbar_extend_diff: str
    map_extend_ticks_manual: bool
    map_nan_colors: str

    # -- Projection-related:
    map_lamb_center_lon: float
    map_lamb_center_lat: float
    map_pole_longitude: float
    map_pole_latitude: float
    cart_projection_ref: ccrs.Projection
    map_zoom2domain: list[float]
    fig_zorder: int

    # -- Title and label customizations:
    maps_title: Optional[str]
    maps_subtitle: Optional[str]
    maps_min_values: Optional[Any]
    maps_max_values: Optional[Any]
    maps_min_values_diff: Optional[Any]
    maps_max_values_diff: Optional[Any]

    # -- Output settings:
    map_format: str
    map_dpi: int

    # -- Dynamic subplot size:
    map_width: float
    map_hight: float

    # -- Subplot settings (partial list):
    map_ncols: Optional[int]
    map_nrows: Optional[int]
    map_wspace: Optional[float]
    map_hspace: Optional[float]
    map_cbar: Optional[list]
    map_cbar_n1c2: Optional[list]
    map_cbar_diff: Optional[list]
    map_cbar_n1c3: Optional[list]
    map_title_loc: Optional[list]
    map_title_pad: Optional[float]
    map_title_fsize: Optional[float]
    map_label_pad: Optional[float]
    map_label_fsize: Optional[float]
    map_label_rotation: Optional[float]

    @log_function_name
    def __init__(
        self,
        load_values: Callable,
        subplot_type: str,
        map_user_settings: Dict[str, Any],
        cart_projection: str,
    ) -> None:
        """Initialize map visualization settings.

        This constructor loads user-defined map settings, subplot parameters, and
        colorbar styles. It also defines a constant data CRS for plotting:

        - self.cart_projection_ref = ccrs.PlateCarree(), used for interpreting
          longitude/latitude input data and for gridlines/extents.
        - The actual display projection is determined later via
          _get_current_projection(domain_type).
        """
        # === Define configuration key groups ===
        # -- Cartopy package-related visual settings
        #    (e.g., coastlines, land/ocean style, gridlines)
        map_cartopy_catalog = [
            'map_tolerance', 'coast_resolution', 'coast_lw', 'coast_lc', 'ocean_color',
            'ocean_zorder', 'land_color', 'land_zorder', 'land_lw', 'land_edgecolor',
            'land_alpha', 'grid_add', 'grid_lw', 'grid_x_inline', 'grid_y_inline',
            'grid_alpha', 'grid_color', 'grid_xlocs', 'grid_ylocs',
        ]

        # -- Settings that affect overall plot content or behavior:
        maps_catalog = [
            'maps_title', 'maps_subtitle', 'maps_min_values', 'maps_max_values',
            'maps_min_values_diff', 'maps_max_values_diff'
        ]

        # -- Output format and resolution for figure saving:
        output_catalog = ['map_format', 'map_dpi']

        # -- Subplot layout parameters (rows/cols, spacing, labels):
        map_subplots_catalog = [
            'map_ncols', 'map_nrows', 'map_wspace', 'map_hspace',
            'map_cbar', 'map_cbar_n1c2', 'map_cbar_diff', 'map_cbar_n1c3',
            'map_title_loc', 'map_title_pad', 'map_title_fsize',
            'map_label_pad', 'map_label_fsize', 'map_label_rotation',
        ]

        # -- Colorbar styling for both main and diff plots, plus nan handling
        #    and rotated pole:
        colorbar_catalog = [
            'map_colorbar', 'map_colorbar_orientation', 'map_colorbar_extend',
            'map_colorbar_diff', 'map_colorbar_orientation_diff', 'map_colorbar_extend_diff',
            'map_extend_ticks_manual', 'map_nan_colors',
            'map_lamb_center_lon', 'map_lamb_center_lat',
            'map_pole_longitude', 'map_pole_latitude',
        ]

        # === Load user settings from main user config ===
        # -- Load all Cartopy visual settings from user configuration:
        for key in map_cartopy_catalog:
            setattr(self, f"map_{key}", load_values(key, dict4settings=map_user_settings))

        # -- Load high-level map behavior overrides:
        for key in maps_catalog:
            setattr(self, key, load_values(key, dict4settings=map_user_settings))

        # -- Load output resolution and format settings:
        for key in output_catalog:
            setattr(self, key, load_values(key, dict4settings=map_user_settings))

        # === Projection-specific and subplot-specific settings ===
        # -- Load projection-specific settings (defined by cart_projection variable):
        map_proj_settings = load_values(cart_projection, dict4settings = map_user_settings)
        # -- Load zoom-to-domain flag from projection settings:
        self.map_zoom2domain = load_values('map_zoom2domain', dict4settings = map_proj_settings)
        # -- Load subplot layout dictionary based on subplot_type
        map_subplots = load_values(subplot_type, dict4settings = map_proj_settings)
        # -- Extract figure width and height:
        map_size = load_values('map_size', dict4settings = map_subplots)
        self.map_width, self.map_hight = map_size[0], map_size[1]
        # -- Load subplot grid parameters (e.g., spacing, title/label config):
        for key in map_subplots_catalog:
            setattr(self, key, load_values(key, dict4settings=map_subplots))

        # === Load remaining display settings ===
        # -- Load reference projection used for Cartopy mapping
        self.cart_projection_ref = ccrs.PlateCarree()

        # -- Z-order base layer for figures (default to 0)
        self.fig_zorder = 0
        # -- Load all colorbar settings including nan and diff handling
        for key in colorbar_catalog:
            setattr(self, key, load_values(key, dict4settings=map_user_settings))

    @log_function_name
    def _get_current_projection(self, domain_type: str) -> ccrs.Projection:
        """Return the display (axes) Cartopy projection for the given domain.

        Args:
            domain_type (str): One of {"global_PlateCarree", "copat2_LambertConformal", "RotatedPole"}.

        Returns:
            ccrs.Projection: The projection to be used for the subplot axes.

        Notes:
            - Data are always assumed to be in PlateCarree (lon/lat).
            - This method only controls how the map is displayed.
        """
        if domain_type == 'global_PlateCarree':
            proj = ccrs.PlateCarree()
        elif domain_type == 'copat2_LambertConformal':
            proj = ccrs.LambertConformal(
                central_longitude = self.map_lamb_center_lon,
                central_latitude = self.map_lamb_center_lat,
            )
        elif domain_type == 'RotatedPole':
            proj = ccrs.RotatedPole(
                pole_longitude = self.map_pole_longitude,
                pole_latitude = self.map_pole_latitude,
            )
        else:
            raise TypeError(
                f'Current domain "{domain_type}" has no correct user projection. '
                'You have to add new projection for you domain')
        logger.info(f'Current domain is {domain_type}')
        return proj

    @log_function_name
    def __extend_colorbar_ticks(self, cbar: Colorbar, norm: Normalize) -> Colorbar:
        """
        Ensure that a colorbar includes its full normalization range (vmin and vmax) as ticks.

        This method:
        ----------------------------
          - Retrieves existing ticks from the colorbar.
          - If ticks are invalid (None, empty, or contain NaNs/Infs), generates a default
            set of 7 evenly spaced ticks between `norm.vmin` and `norm.vmax`.
          - Ensures that both `norm.vmin` and `norm.vmax` are included in the tick list.
          - Removes duplicate ticks and applies the updated list to the colorbar.

        Args:
        ----------------------------
            cbar (matplotlib.colorbar.Colorbar):
                The colorbar instance to be updated.
            norm (matplotlib.colors.Normalize):
                The normalization object containing `vmin` and `vmax` values.

        Returns:
        ----------------------------
            matplotlib.colorbar.Colorbar:
                The updated colorbar with extended ticks.

        Notes:
        ----------------------------
            - If any error occurs during processing, the method logs a warning and
              returns the colorbar unchanged.
            - Uses `np.isclose` to avoid floating-point precision issues when checking
              if ticks already contain `vmin`/`vmax`.
        """
        try:
            ticks = cbar.get_ticks()

            if ticks is None or len(ticks) == 0 or np.any(~np.isfinite(ticks)):
                logger.warning("Invalid or empty ticks from colorbar. Generating new ticks.")
                ticks = np.linspace(norm.vmin, norm.vmax, 7)

            new_ticks = ticks.copy()

            if not np.any(np.isclose(new_ticks, norm.vmin)):
                new_ticks = np.insert(new_ticks, 0, norm.vmin)
            if not np.any(np.isclose(new_ticks, norm.vmax)):
                new_ticks = np.append(new_ticks, norm.vmax)

            new_ticks = np.unique(new_ticks)
            cbar.set_ticks(new_ticks)

            logger.info(f"Final ticks are: {new_ticks}")
            return cbar
        except Exception as e:
            logger.warning(f"Error extending colorbar ticks: {e}")
            return cbar

    @log_function_name
    def _single_2d_map(self, **kwargs) -> None:
        """Create single 2d map:"""
        # -- Local variables:
        logger.info('Create single 2d map:')
        # -- Define required keys
        required_keys = [
            'title', 'label', 'lon_2d', 'lat_2d', 'data4plot',
            'norm', 'cart_projection_act', 'pout']

        # -- Check if all required keys are present:
        for key in required_keys:
            if key not in kwargs:
                raise ValueError(f"Missing required argument: '{key}'")

        # -- Use the provided arguments:
        title, label = kwargs['title'], kwargs['label']
        lon_2d, lat_2d = kwargs['lon_2d'], kwargs['lat_2d']
        data4plot = kwargs['data4plot']
        norm, pout = kwargs['norm'], kwargs['pout']
        cart_projection_act = kwargs['cart_projection_act']
        modif_coordinates = kwargs.get('modif_coord', False)

        # -- Use a special colormap key based on input data (default: def_full):
        colormap_key_main = kwargs.get('colormap_key_main', None)
        colormap_key_reserve = kwargs.get('colormap_key_reserve', 'def_full')
        colormap = self.map_colorbar.get(colormap_key_main)
        if colormap is None:
            colormap = self.map_colorbar.get(colormap_key_reserve)

        logger.info(
            "\n--- Colormap Selection ---\n"
            f"Primary Key    : {colormap_key_main}\n"
            f"Fallback Key   : {colormap_key_reserve}\n"
            f"Selected Value : {colormap}\n"
            "---------------------------\n"
        )

        # -- Start visualization:
        fig, ax = plt.subplots(
            figsize = (self.map_width, self.map_hight),
            subplot_kw = dict(projection=cart_projection_act),
        )
        # -- Add cartopy objects (coastline, ocean, land, grid):
        gl = self.cartopy_fields(ax)
        # -- Update gridline label visibility based on column and row:
        gl.left_labels = True
        gl.right_labels = True
        gl.bottom_labels = True
        # -- Setup rotation for gridline labels:
        self.setup_rotation(gl)
        # -- Add title:
        self.add_map_title(fig, map_title = title)
        # -- Zoom to our domain:
        self.add_zoom_to_extend(ax)
        # -- Create colormesh:
        cnf = self.add_colormesh(
            ax, lon_2d, lat_2d, data4plot, plt.get_cmap(colormap), norm,
            mod_axis = modif_coordinates,
        )
        # -- Adding color bar:
        cbar = self.add_colorbar(fig, cnf)
        # -- Extend colorbar ticks:
        if self.map_extend_ticks_manual:
            cbar = self.__extend_colorbar_ticks(cbar, norm)
        # -- Add units to colorbar:
        self.add_colorbar_units(cbar, label)
        # -- Save figure:
        self.save_map(fig, plt_pout = f'{pout}')
        # -- Clean memory:
        self.memory_cleaner(fig)

    @log_function_name
    def _collage_2d_map(self, **kwargs) -> None:
        """Create a 12 subplots collage map:"""
        # -- Local variables:
        logger.info('Create collage 2d map:')
        # -- Define required keys
        required_keys = [
            'title', 'data', 'time', 'label', 'lon_2d', 'lat_2d', 'data4plot',
            'norm', 'cart_projection_act', 'pout']
        # -- Check if all required keys are present:
        for key in required_keys:
            if key not in kwargs:
                raise ValueError(f"Missing required argument: '{key}'")
        # -- Use the provided arguments:
        title, label = kwargs['title'], kwargs['label']
        lon_2d, lat_2d = kwargs['lon_2d'], kwargs['lat_2d']
        data, time = kwargs['data'], kwargs['time']
        data4plot = kwargs['data4plot']
        norm, pout = kwargs['norm'], kwargs['pout']
        cart_projection_act = kwargs['cart_projection_act']
        modif_coordinates = kwargs.get('modif_coord', False)

        # -- Use a special colormap key based on input data (default: def_full):
        colormap_key_main = kwargs.get('colormap_key_main', None)
        colormap_key_reserve = kwargs.get('colormap_key_reserve', 'def_full')
        colormap = self.map_colorbar.get(colormap_key_main)
        if colormap is None:
            colormap = self.map_colorbar.get(colormap_key_reserve)

        logger.info(
            "\n--- Colormap Selection ---\n"
            f"Primary Key    : {colormap_key_main}\n"
            f"Fallback Key   : {colormap_key_reserve}\n"
            f"Selected Value : {colormap}\n"
            "---------------------------\n"
        )

        # -- Create figure with subplots:
        fig, axes = plt.subplots(
            nrows = self.map_nrows, ncols = self.map_ncols,
            figsize = (self.map_width, self.map_hight),
            subplot_kw = dict(projection=cart_projection_act),
            gridspec_kw = {'wspace': self.map_wspace, 'hspace': self.map_hspace},
        )
        # -- Add title:
        self.add_map_title(fig, map_title = title)
        # -- Count the actual number of datasets (non-None values):
        num_valid_datasets = sum(1 for ds in data if ds is not None)
        # -- Add new subplots to the figure:
        for i, ax in enumerate(axes.flat):
            # -- Add cartopy objects (coastline, ocean, land, grid):
            gl = self.cartopy_fields(ax)
            # -- Add plot title (individual):
            self.add_map_subtitle(ax, subplot_title = f'{time[i]}')
            # -- Zoom to our domain:
            self.add_zoom_to_extend(ax)
            # -- Create colormesh:
            cnf = self.add_colormesh(
                ax, lon_2d, lat_2d, data4plot[i], plt.get_cmap(colormap), norm,
                mod_axis = modif_coordinates,
            )
            # -- Show labels:
            self.show_labels(gl, i, self.map_ncols, num_valid_datasets)
            # -- Setup rotation for gridline labels:
            self.setup_rotation(gl)
        # -- Adding color bar:
        cbar = self.add_colorbar(fig, cnf)
        # -- Extend colorbar ticks:
        if self.map_extend_ticks_manual:
            cbar = self.__extend_colorbar_ticks(cbar, norm)
        # -- Add units to colorbar:
        self.add_colorbar_units(cbar, label)
        # -- Save figure:
        self.save_map(fig, plt_pout = f'{pout}')
        # -- Clean memory:
        self.memory_cleaner(fig)

    @log_function_name
    def _time_collage_2d_map(self, **kwargs) -> None:
        """Create a time collage maps, if more than 12 subplots in one moment of time
           save 12 subplots in one figure, than go to the next figure:
        """
        # -- Local variables:
        # -- Define required keys
        required_keys = [
            'title', 'ds_names', 'time', 'label', 'lon_2d', 'lat_2d', 'data4plot',
            'norm', 'cart_projection_act', 'pout', 'chunk_size']

        # -- Check if all required keys are present:
        for key in required_keys:
            if key not in kwargs:
                raise ValueError(f"Missing required argument: '{key}'")

        # -- Use the provided arguments:
        title, label = kwargs['title'], kwargs['label']
        lon_2d, lat_2d = kwargs['lon_2d'], kwargs['lat_2d']
        ds_names, time = kwargs['ds_names'], kwargs['time']
        data4plot = kwargs['data4plot']
        norm, pout = kwargs['norm'], kwargs['pout']
        cart_projection_act = kwargs['cart_projection_act']
        chunk_size = kwargs['chunk_size']
        diff_norm = kwargs.get('diff_norm', None)
        modif_coordinates = kwargs.get('modif_coord', False)
        logger.info(f'Create collage plot for {title}')

        # -- Use a special colormap key based on input data (default: def_full):
        colormap_key_main = kwargs.get('colormap_key_main', None)
        colormap_key_reserve = kwargs.get('colormap_key_reserve', 'def_full')
        colormap = self.map_colorbar.get(colormap_key_main)
        if colormap is None:
            colormap = self.map_colorbar.get(colormap_key_reserve)

        logger.info(
            "\n--- Colormap Selection ---\n"
            f"Primary Key    : {colormap_key_main}\n"
            f"Fallback Key   : {colormap_key_reserve}\n"
            f"Selected Value : {colormap}\n"
            "---------------------------\n"
        )

        # -- Plotting main map:


        # -- Create figure with subplots:
        fig, axes = plt.subplots(
            nrows = self.map_nrows, ncols = self.map_ncols,
            figsize = (self.map_width, self.map_hight),
            subplot_kw = dict(projection=cart_projection_act),
            gridspec_kw = {'wspace': self.map_wspace, 'hspace': self.map_hspace},
        )
        # -- Add title:
        self.add_map_title(fig, map_title = f'{title} {time}')
        # -- Extend ds_names with None if it has fewer elements than the number of axes:
        if len(ds_names) < len(axes.flat):
            ds_names.extend([None] * (len(axes.flat) - len(ds_names)))
        # -- Count the actual number of datasets (non-None values):
        num_valid_datasets = sum(1 for ds in ds_names if ds is not None)

        last_valid_cnf = None
        last_valid_cnf2 = None
        # -- Add new subplots to the figure:
        for i, ax in enumerate(axes.flat):
            cnf = None  # Reset each loop
            if i < len(ds_names) and ds_names[i] is not None:
                # -- Add cartopy objects (coastline, ocean, land, grid):
                gl = self.cartopy_fields(ax)
                # -- Add plot title (individual):
                self.add_map_subtitle(ax, subplot_title = f'{ds_names[i]}')
                # -- Zoom to our domain:
                self.add_zoom_to_extend(ax)

                # -- Create colormesh:
                if 'Difference' in ds_names[i]:
                    cnf = self.add_colormesh(
                        ax, lon_2d, lat_2d,
                        data4plot[i],
                        plt.get_cmap(self.map_colorbar_diff),
                        diff_norm,
                        mod_axis = modif_coordinates,
                    )
                    last_valid_cnf2 = cnf
                else:
                    cnf = self.add_colormesh(
                        ax, lon_2d, lat_2d, data4plot[i],
                        plt.get_cmap(colormap), norm,
                        mod_axis = modif_coordinates,
                    )
                    last_valid_cnf = cnf
                # -- Show labels:
                self.show_labels(gl, i, self.map_ncols, num_valid_datasets)
                # -- Setup rotation for gridline labels:
                self.setup_rotation(gl)
            else:
                # -- Remove subplot if there is no corresponding data
                ax.remove()

        # -- Adding color bar:
        # -- Check if the last subplot is the difference plot:
        if last_valid_cnf2 is not None and last_valid_cnf is not None:
            logger.debug("Two colorbars activated")
            cbar_main = self.add_colorbar(
                fig, last_valid_cnf, nrows = self.map_nrows,
                num_valid_datasets = num_valid_datasets - 1
            )
            if self.map_extend_ticks_manual:
                cbar_main = self.__extend_colorbar_ticks(cbar_main, norm)
            self.add_colorbar_units(cbar_main, label)

            cbar_diff = self.add_colorbar(fig, last_valid_cnf2, lsecond_clb=True)
            # -- Temporal solution:
            if self.maps_min_values_diff is None and self.maps_max_values_diff is None:
                logger.info('default settings for diff colorbar')
            else:
                if self.map_extend_ticks_manual:
                    cbar_diff = self.__extend_colorbar_ticks(cbar_diff, diff_norm)
            cbar_diff.set_label('diff')

        elif last_valid_cnf is not None:
            logger.debug("One colorbar activated")
            cbar = self.add_colorbar(
                fig, last_valid_cnf, nrows = self.map_nrows,
                num_valid_datasets = num_valid_datasets
            )
            if self.map_extend_ticks_manual:
                cbar = self.__extend_colorbar_ticks(cbar, norm)
            self.add_colorbar_units(cbar, label)

        elif last_valid_cnf2 is not None:
            logger.debug("Only diff colorbar activated")
            cbar_diff = self.add_colorbar(fig, last_valid_cnf2, lsecond_clb=True)
            if self.map_extend_ticks_manual:
                cbar_diff = self.__extend_colorbar_ticks(cbar_diff, diff_norm)
            cbar_diff.set_label('diff')

        # -- Save figure:
        self.save_map(fig, plt_pout = f'{pout}_{time}_{chunk_size}')
        # -- Clean memory:
        self.memory_cleaner(fig)
        logger.info(f'Collage plot for {title} was done')
        logger.info(f'File was saved: {pout}_{time}_{chunk_size}')

    @log_function_name
    def cartopy_fields(self, ax: GeoAxes) -> Gridliner:
        """
        Add standard Cartopy layers (coastlines, ocean, land) and gridlines.

        Gridlines are always drawn in PlateCarree (lon/lat) coordinates,
        since self.cart_projection_ref is fixed to ccrs.PlateCarree().

        This modifies the provided GeoAxes by:
        ----------------------------
          - Drawing coastlines with the configured resolution, width, and color.
          - Adding ocean and land features with the configured styling (colors, zorder, edge/alpha).
          - Creating a gridliner using the reference projection and configured grid settings
            (visibility, inline labels, linewidth, color, alpha, x/y locations).

        Args:
        ----------------------------
            ax (cartopy.mpl.geoaxes.GeoAxes): Target axes.

        Returns:
        ----------------------------
            cartopy.mpl.gridliner.Gridliner: Configured gridliner object.

        Notes:
        ----------------------------
            - Label visibility is disabled by default here (all sides set to False) so you can
              enable and style them explicitly elsewhere if needed.
        """
        # -- Local variables:
        show_labels_by_default = False
        # -- add coastlines:
        ax.coastlines(
            resolution = self.map_coast_resolution,
            linewidth = self.map_coast_lw,
            color = self.map_coast_lc,
        )
        # -- Add ocean:
        ax.add_feature(
            cartopy.feature.OCEAN,
            color = self.map_ocean_color,
            zorder = self.map_ocean_zorder,
        )
        # -- Add land:
        ax.add_feature(
            cartopy.feature.LAND,
            color = self.map_land_color,
            zorder = self.map_land_zorder,
            linewidth = self.map_land_lw,
            edgecolor = self.map_land_edgecolor,
            alpha = self.map_land_alpha,
        )
        # -- Add grid:
        gl = ax.gridlines(
            crs = self.cart_projection_ref,
            draw_labels = self.map_grid_add,
            x_inline = self.map_grid_x_inline,
            y_inline = self.map_grid_y_inline,
            linewidth = self.map_grid_lw,
            color = self.map_grid_color,
            alpha = self.map_grid_alpha,
            xlocs = self.map_grid_xlocs,
            ylocs = self.map_grid_ylocs,
        )

        # -- Control gridline labels (left/right for y-axis, bottom/top for x-axis)
        gl.left_labels = gl.right_labels = show_labels_by_default
        gl.top_labels = gl.bottom_labels = show_labels_by_default
        return gl

    @log_function_name
    def add_zoom_to_extend(self, ax: GeoAxes, **kwargs) -> None:
        """Zoom to your domain"""
        ax.set_extent(self.map_zoom2domain, crs = self.cart_projection_ref)

    @log_function_name
    def add_colormesh(
        self,
        ax: GeoAxes,
        lon_2d: np.ndarray,
        lat_2d: np.ndarray,
        data: np.ndarray,
        color_map: Union[str, Colormap],
        norm_map: Normalize,
        **kwargs: Any,
    ) -> ScalarMappable:
        """
        Create a pcolormesh plot on a given GeoAxes.

        Args:
        ----------------------------
            ax (GeoAxes):
                The cartopy GeoAxes on which to draw the mesh.
            lon_2d (ArrayLike):
                2D array of longitudes matching the data grid.
            lat_2d (ArrayLike):
                2D array of latitudes matching the data grid.
            data (ArrayLike):
                2D data array to visualize.
            color_map (str | matplotlib.colors.Colormap):
                Colormap name or Colormap object for rendering the mesh.
            norm_map (matplotlib.colors.Normalize):
                Normalization object controlling the data-to-color mapping.
            **kwargs:
                Additional options. Supported key:
                  - mod_axis (bool): If True, set NaN color to transparent when
                    data exceeds normalization bounds.

        Returns:
        ----------------------------
            matplotlib.cm.ScalarMappable:
                The pcolormesh object created, which can be used for adding a colorbar.

        Notes:
        ----------------------------
            - The input lon_2d/lat_2d coordinates are always interpreted as
              PlateCarree (lon/lat), since self.cart_projection_ref is fixed.
        """
        modif_coordinate_axis = kwargs.get('mod_axis', False)
        # -- Compute data min/max
        data_min = np.nanmin(data)
        data_max = np.nanmax(data)
        norm_min = norm_map.vmin
        norm_max = norm_map.vmax

        logger.info(f"Norm vmin/vmax: {norm_min}, {norm_max}")
        logger.info(f"Data min/max: {data_min}, {data_max}")

        # -- Add special color for NaN values:
        if isinstance(color_map, str):
            cmap = plt.get_cmap(color_map).copy()
        else:
            cmap = color_map.copy()

        # -- Adjust set_bad dynamically
        cmap.set_bad(self.map_nan_colors)
        if modif_coordinate_axis:
            if (data_min < norm_min) or (data_max > norm_max):
                logger.warning("Data exceeds norm bounds: using transparent NaN color")
                cmap.set_bad((1, 1, 1, 0))  # Fully transparent

        # -- Create figure:
        cnf = ax.pcolormesh(
            lon_2d, lat_2d, data,
            cmap = cmap,
            norm = norm_map,
            transform = self.cart_projection_ref,
            zorder = self.fig_zorder,
        )
        return cnf

    @log_function_name
    def add_map_title(self, fig: Figure, **kwargs) -> None:
        """Add common title for subplots:"""
        map_title = kwargs.get('map_title')

        # -- No title to add:
        if map_title is None:
            return
        # -- Check type of map_title:
        if not isinstance(map_title, str):
            raise ValueError(f"'map_title' must be a string, got {type(map_title).__name__}")

        # -- Validate map_title_loc:
        tloc = self.map_title_loc
        if tloc is None:
            raise ValueError("'self.map_title_loc' must be defined (not None) to position the title")
        if not (isinstance(tloc, list) and len(tloc) >= 4):
            raise ValueError(
                "'self.map_title_loc' must be a list of at least 4 elements: [x, y, ha, fontsize]"
            )
        # -- Add title:
        fig.suptitle(
            map_title, x = tloc[0], y = tloc[1], ha = tloc[2], fontsize = tloc[3],
        )

    @log_function_name
    def add_map_subtitle(self, ax: GeoAxes, **kwargs) -> None:
        """Add subplot title:"""
        if 'subplot_title' in kwargs:
            ax.set_title(
                kwargs.get('subplot_title'),
                pad = self.map_title_pad,
                fontsize = self.map_title_fsize,
            )

    @log_function_name
    def setup_rotation(self, gl: Gridliner, **kwargs: Any) -> None:
        """
        Configure rotation and padding for gridline labels.

        This method sets the x-axis and y-axis label rotation angles as well as
        the horizontal padding for x-axis labels based on the instance's
        map configuration attributes.

        Args:
        ----------------------------
            gl (cartopy.mpl.gridliner.Gridliner):
                The Gridliner object whose label styles will be configured.
            **kwargs:
                Additional keyword arguments for future extensibility
                (currently unused).

        Side Effects:
        ----------------------------
            - Modifies `gl.xlabel_style` and `gl.ylabel_style` to set label rotation.
            - Modifies `gl.xpadding` to adjust horizontal label spacing.
        """
        gl.xlabel_style = {"rotation": self.map_label_rotation}
        gl.ylabel_style = {"rotation": self.map_label_rotation}
        # -- Setup label pad:
        gl.xpadding = self.map_label_pad

    @log_function_name
    def add_colorbar(self, figs: Figure, cnf: ScalarMappable, **kwargs: Any) -> Colorbar:
        """
        Add a colorbar to the current map figure with optional layout adjustments.

        This method:
        ----------------------------
          - Dynamically adjusts the colorbar position for specific subplot arrangements
            (e.g., 1-row layouts with 2 or 3 datasets).
          - Switches to difference colorbar settings when plotting a secondary colorbar.
          - Creates a dedicated axes for the colorbar and adds it to the figure.

        Args:
        ----------------------------
            figs (matplotlib.figure.Figure):
                The figure object to which the colorbar will be added.
            cnf (matplotlib.cm.ScalarMappable):
                The mappable object (e.g., output from `pcolormesh`, `imshow`) to associate
                with the colorbar.
            **kwargs:
                Optional parameters controlling colorbar placement:
                  - nrows (int): Number of subplot rows; affects position adjustment for small grids.
                  - num_valid_datasets (int): Dataset count, used to select appropriate layout preset.
                  - lsecond_clb (bool): If True, applies "difference" colorbar settings.

        Returns:
        ----------------------------
            matplotlib.colorbar.Colorbar:
                The created colorbar instance.

        Notes:
        ----------------------------
            - Relies on class attributes for positioning (`self.map_cbar*`), orientation,
              and extend settings.
            - The colorbar axes are added explicitly via `figs.add_axes` rather than
              using default subplot layout.
        """
        if kwargs.get('nrows') == 1:
            if kwargs.get('num_valid_datasets') == 2:
                self.map_cbar = self.map_cbar_n1c2
            elif kwargs.get('num_valid_datasets') == 3:
                self.map_cbar = self.map_cbar_n1c3

        if kwargs.get('lsecond_clb') is True:
            self.map_cbar = self.map_cbar_diff
            self.map_colorbar_orientation = self.map_colorbar_orientation_diff
            self.map_colorbar_extend = self.map_colorbar_extend_diff

        cbar_ax = figs.add_axes(self.map_cbar, autoscalex_on = True)
        cbar = figs.colorbar(
            cnf,
            cax = cbar_ax,
            orientation = self.map_colorbar_orientation,
            extend = self.map_colorbar_extend,
        )
        return cbar

    @log_function_name
    def add_colorbar_units(self, cbar: Colorbar, label: str, **kwargs: Any) -> None:
        """
        Set the label text and style for a colorbar.

        Args:
        ----------------------------
            cbar (matplotlib.colorbar.Colorbar):
                The colorbar instance to label.
            label (str):
                The text to display as the colorbar label.
            **kwargs:
                Reserved for future styling options (currently unused).

        Side Effects:
        ----------------------------
            - Modifies the label of the provided colorbar using configured font size
              (`self.map_label_fsize`) and label padding (`self.map_label_pad`).
        """
        cbar.set_label(
            label, fontsize = self.map_label_fsize, labelpad = self.map_label_pad,
        )

    @log_function_name
    def show_labels(
        self,
        gl: Gridliner,
        i: int,
        map_ncols: int,
        num_valid_datasets: int,
    ) -> None:
        """
        Configure which gridline labels are displayed for a subplot, based on its
        position in a multi-panel layout.

        Logic:
        ----------------------------
          - Bottom labels:
              * If the last row is incomplete, show for all plots in that row.
              * If the last row is complete, show only for the last row.
          - Left labels:
              * Shown only for the first column.
          - Right labels:
              * If the last row is incomplete, shown only for the final valid subplot.
              * Otherwise, shown only for the last column.

        Args:
        ----------------------------
            gl (cartopy.mpl.gridliner.Gridliner):
                The gridliner object to modify.
            i (int):
                The subplot index (zero-based).
            map_ncols (int):
                Number of subplot columns in the grid.
            num_valid_datasets (int):
                Total number of datasets being displayed.

        Side Effects:
        ----------------------------
            - Modifies `gl.bottom_labels`, `gl.left_labels`, and `gl.right_labels`
              to control label visibility.
        """
        # -- Local variables:
        ncols = map_ncols
        # -- Determine the row and column index from i:
        row, col = divmod(i, ncols)
        # -- Check if the row is the last row and if it's incomplete:
        last_row_incomplete = num_valid_datasets % ncols != 0
        last_row_index = (num_valid_datasets - 1) // ncols
        # -- Set bottom labels based on row type
        #       -> show for all if last row is incomplete
        #       -> show only for the last raw if last row completed
        if last_row_incomplete:
            gl.bottom_labels = True
        else:
            gl.bottom_labels = row == last_row_index
        # -- Show left labels only for the first column:
        gl.left_labels = col == 0
        # -- Special logic for right labels:
        if last_row_incomplete and row == last_row_index:
            # For incomplete last row, show right labels only for the last valid subplot
            gl.right_labels = i == num_valid_datasets - 1
        else:
            # For all other rows, show right labels only for the last column
            gl.right_labels = col == ncols - 1

    @log_function_name
    def save_map(self, ax: GeoAxes, **kwargs: Any) -> None:
        """Save the current map figure to file.

        Args:
        _____________
            plt_pout (str): Output path prefix. File extension comes from self.map_format.

        Raises:
        _____________
            ValueError: If plt_pout is missing or not a string.
        """
        # -- Set output parameters:
        if 'plt_pout' in kwargs and isinstance(kwargs.get('plt_pout'), str):
            # -- Plot save:
            plt.savefig(
                f"{kwargs.get('plt_pout')}{self.map_format}",
                dpi = self.map_dpi,
            )
        else:
            raise ValueError('Incorrect settings for output path for the figure')

    @log_function_name
    def memory_cleaner(self, fig: Figure, **kwargs: Any) -> None:
        """
        Close and clear a Matplotlib figure to free up memory.

        Args:
        ----------------------------
            fig (matplotlib.figure.Figure):
                The figure instance to close.
            **kwargs:
                Reserved for future options (currently unused).

        Side Effects:
        ----------------------------
            - Closes the provided figure.
            - Clears the current global figure (`plt.gcf()`).
        """
        plt.close(fig)
        plt.gcf().clear()
