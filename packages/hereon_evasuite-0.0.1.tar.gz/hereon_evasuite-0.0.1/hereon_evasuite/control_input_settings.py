# EvaSuite
#
# ---------------------------------------------------------------
# Copyright (C) 2004-2025, Hereon
# Contact information: beate.geyer@hereon.de, imktro-climate-modelling@lists.kit.edu
# See AUTHORS.TXT for a list of authors
# See LICENSES/ for license information
# SPDX-License-Identifier: Apache-2.0
# ---------------------------------------------------------------
# -- import Python modules:
import os
import glob
from typing import Union, Dict, Optional

# -- Import EvaSuite classes and modules:
from hereon_evasuite.log_EvaSuite import get_logger, log_function_name
from hereon_evasuite.GeneralUtils import SuiteUtilities
from hereon_evasuite.Prog_CDONCO import CDO, NCO, NCSYS
from hereon_evasuite.Prog_PyXarray_PyVis import PyXarray
from hereon_evasuite.Prog_Masking import PyRegionmask

# -- Activate logger:
logger = get_logger()
GenUti = SuiteUtilities()


class Control_namelists:
    @log_function_name
    def __init__(
        self,
        cfggen: dict,
        cfggendm: dict,
        sysset: dict,
        proofset: dict,
        evalset: dict,
        supported_EVAL_modes: dict,
        eval_metrics: list,
    ) -> None:
        self.cfggen = cfggen
        self.cfggendm = cfggendm
        self.sysset = sysset
        self.proofset = proofset
        self.evalset = evalset
        self.supported_EVAL_modes = supported_EVAL_modes
        self.eval_metrics = eval_metrics

    @log_function_name
    def _validate_target_eval_frequency(self, datsetlist: list) -> None:
        """
        Validates the 'target_EvalFrequency' settings in cfggen['datamining'].
        Ensures that if method == 'reselect', the targetgrid is compatible with the dataset list.
        """
        if "target_EvalFrequency" not in self.cfggendm:
            raise KeyError("Missing 'target_EvalFrequency' in datamining settings.")
        freq_settings = self.cfggendm["target_EvalFrequency"]

        if not isinstance(freq_settings, dict):
            raise TypeError("'target_EvalFrequency' must be a dictionary.")

        method = freq_settings.get("method")
        targetgrid = freq_settings.get("targetgrid")

        if method == "reselect":
            if targetgrid not in datsetlist:
                raise ValueError(
                    f"'target_EvalFrequency.method' is set to 'reselect', so "
                    f"'targetgrid' must be one of the datasets used in evaluation.\n→"
                    f" targetgrid: {targetgrid}\n→ available datasets: {datsetlist}"
                )

    @log_function_name
    def _validate_targetgrid_vertical(self, datsetlist: list) -> None:
        """
        Validates that 'targetgrid_vertical' in the datamining settings is either:
        - A dataset acronym listed in 'data2proof_acronyms' or 'evaldata_acronyms', or
        - Explicitly set to None or False (to disable vertical grid alignment).

        Raises:
        ----------------------------
            KeyError: If 'targetgrid_vertical' is missing from the datamining settings.
            ValueError: If 'targetgrid_vertical' is set to an invalid or unsupported value.
        """
        if "targetgrid_vertical" not in self.cfggendm:
            raise KeyError("'targetgrid_vertical' is missing in 'datamining' settings.")

        target = self.cfggendm["targetgrid_vertical"]
        logger.debug(f"Validating 'targetgrid_vertical': {target} against datasets: {datsetlist}")

        if target is None:
            # -- No check needed for None/False (user opted out)
            logger.debug("'targetgrid_vertical' is None — skipping vertical grid validation.")
            return

        # -- Ensure the target is a string
        if not isinstance(target, str):
            raise TypeError("'targetgrid_vertical' must be a string.")
        # -- Ensure all items in dataset list are strings:
        if not all(isinstance(ds, str) for ds in datsetlist):
            raise TypeError("All entries in the dataset list must be strings.")

        if target not in datsetlist:
            raise ValueError(
                f"'targetgrid_vertical' is set to '{target}', but it does not match"
                f" any selected dataset acronym.\n → Expected one of: {datsetlist}\n"
                f" → If you want to disable vertical alignment, set it to null or false.\n"
                f" Check that 'targetgrid_vertical' refers to a valid acronym from"
                f" 'data2proof_acronyms' or 'evaldata_acronyms'."
            )

    @log_function_name
    def _validate_targetgrid_horizontal(self, datsetlist: list) -> None:
        """
        Validates that 'targetgrid_horizontal' in the datamining settings is either:
        - A dataset acronym listed in 'data2proof_acronyms' or 'evaldata_acronyms', or
        - Explicitly set to None or False (to disable horizontal grid alignment).

        Raises:
        ----------------------------
            KeyError: If 'targetgrid_horizontal' is missing from the datamining settings.
            ValueError: If 'targetgrid_horizontal' is set to an invalid or unsupported value.
        """
        if "targetgrid_horizontal" not in self.cfggendm:
            raise KeyError("'targetgrid_horizontal' is missing in 'datamining' settings.")

        target = self.cfggendm["targetgrid_horizontal"]
        logger.debug(f"Validating 'targetgrid_horizontal': {target} against datasets: {datsetlist}")

        # If the target is None, skip the validation
        if target is None:
            logger.debug("'targetgrid_horizontal' is None — skipping horizontal grid validation.")
            return

        # -- Ensure the target is a string
        if not isinstance(target, str):
            raise TypeError("'targetgrid_horizontal' must be a string.")
        # Ensure all items in dataset list are strings
        if not all(isinstance(ds, str) for ds in datsetlist):
            raise TypeError("All entries in the dataset list must be strings.")

        if target not in datsetlist:
            raise ValueError(
                f"'targetgrid_horizontal' is set to '{target}', but it does not"
                f" match any selected dataset acronym.\n → Expected one of: {datsetlist}\n"
                f" → If you want to disable horizontal alignment, set it to null or false.\n"
                f" Check that 'targetgrid_horizontal' refers to a valid acronym from"
                f" 'data2proof_acronyms' or 'evaldata_acronyms'."
            )

    @log_function_name
    def _validate_eval_metrics_userdefined(self) -> None:
        """
        Validates that all metrics listed in 'eval_metrics' are properly defined in 'metrics_setup'
        when 'metrics2compute' is set to '${user-defined}' for the selected evaluation mode.

        Checks:
        ----------------------------
            - Metric key exists in 'metrics_setup'
            - Each metric has a defined 'calctype'
            - 'calctype' is known under 'typespec'
            - Number of required 'data2proof' datasets is satisfied

        Raises:
        ----------------------------
            KeyError: If a metric or calctype is missing or invalid.
            ValueError: If dataset requirements are not met.
        """
        mode = self.cfggen["eval_Mode"]
        mode_settings = self.cfggen["EVAL_modes_setup"].get(mode, {})
        eval_metrics_list = self.cfggen.get("eval_metrics")

        # Raise error if eval_metrics is explicitly an empty list
        if isinstance(eval_metrics_list, list) and not eval_metrics_list:
            logger.error(
                "'eval_metrics' is an empty list [].\n"
                "→ Please provide at least one metric or remove the key entirely if not needed (e.g., in CompareRAW mode)."
            )
            raise ValueError(
                "'eval_metrics' is an empty list — add at least one metric or remove the list completely."
            )

        if mode != 'CompareRAW' and not eval_metrics_list:
            logger.error(
                "'eval_metrics' is None or empty — metric validation requires at least one entry.\n"
                "→ Please define metrics in 'eval_metrics' or switch to a mode that doesn't require them."
            )
            raise ValueError(
                "'eval_metrics' is missing or empty while 'metrics2compute' is set to '${user-defined}'"
            )
        elif mode == 'CompareRAW' and not eval_metrics_list:
            logger.info("CompareRAW skip control of eval_metrics_list")
            return

        # -- Ensure that the evaluation mode uses user-defined metrics:
        if mode in ['CompareRAW', 'ComparePDF']:
            logger.info(f"Current metrics2compute is equal = {mode_settings.get('metrics2compute')}")
        else:
            if mode_settings.get("metrics2compute") != "${user-defined}":
                raise ValueError(
                    f"Evaluation mode '{mode}' is not using user-defined metrics. "
                    f"Make sure 'metrics2compute' is set to '${{user-defined}}' for the selected mode."
                )

        for metrickey in GenUti.IterNoneComp(eval_metrics_list):
            # -- Check if the metric exists in 'metrics_setup':
            if metrickey not in self.cfggen["metrics_setup"]:
                raise KeyError(
                    f"Metric '{metrickey}' is listed in 'eval_metrics' but is"
                    f" missing from 'metrics_setup'.\n → Please ensure exact naming,"
                    f" including suffixes like '_temporal'.\n Available keys:"
                    f" {list(self.cfggen['metrics_setup'].keys())}"
                )
            # -- Check if 'calctype' is present for the metric:
            metric_info = self.cfggen["metrics_setup"][metrickey]
            if "calctype" not in metric_info:
                raise KeyError(
                    f"Metric '{metrickey}' is missing the 'calctype' field in 'metrics_setup'."
                )
            # -- Check if the 'calctype' is defined in 'typespec':
            metricmode = metric_info["calctype"]
            if metricmode not in self.cfggen["metrics_setup"].get("typespec", {}):
                raise KeyError(
                    f"The 'calctype' '{metricmode}' for metric '{metrickey}'"
                    f" is not defined in 'typespec'.\n → Check that 'typespec'"
                    f" includes this calculation type."
                )
            # -- Check if the number of datasets required by the metric is provided:
            required = self.cfggen["metrics_setup"]["typespec"][metricmode]["involved_Data2Proof"]
            available = len(self.cfggen.get("data2proof_acronyms", []))
            if required > available:
                raise ValueError(
                    f"Metric '{metrickey}' (type: '{metricmode}') requires {required} data2proof datasets, "
                    f"but only {len(self.cfggen['data2proof_acronyms'])} were provided.\n"
                    f"→ Adjust your data2proof_acronyms list or choose a compatible metric."
                )

    @log_function_name
    def _validate_reference_data_required(self) -> None:
        """
        Validates that if the selected evaluation mode requires reference data,
        the user has provided 'evaldata_acronyms'.

        Raises:
        ----------------------------
            KeyError: If required keys are missing in the configuration.
            ValueError: If the evaluation mode needs reference data but none is provided.
        """
        mode = self.cfggen.get("eval_Mode")
        mode_settings = self.cfggen.get("EVAL_modes_setup", {}).get(mode)

        if mode_settings is None:
            raise KeyError(
                f"Evaluation mode '{mode}' is not defined in 'EVAL_modes_setup'."
            )
        evaldata_needed = mode_settings.get("EvalDataNeeded", False)
        evaldata_acronyms = self.cfggen.get("evaldata_acronyms", [])
        if evaldata_needed and not evaldata_acronyms:
            raise ValueError(
                f"The evaluation mode '{mode}' requires at least one reference dataset "
                f"('evaldata_acronyms'), but none were provided.\n"
                f"→ Add a dataset under 'evaldata_acronyms' or switch to a mode that doesn't require reference data."
            )

    @log_function_name
    def _validate_datasets_exist(self) -> None:
        """
        Ensures that both 'data2proof_acronyms' and 'evaldata_acronyms' are defined,
        and that at least one of them is non-empty.

        Raises:
        ----------------------------
            KeyError: If either of the required keys is missing.
            ValueError: If both lists are empty.
        """
        if "data2proof_acronyms" not in self.cfggen:
            raise KeyError("'data2proof_acronyms' is missing in cfggen.")
        if "evaldata_acronyms" not in self.cfggen:
            raise KeyError("'evaldata_acronyms' is missing in cfggen.")

        data2proof = self.cfggen["data2proof_acronyms"]
        evaldata = self.cfggen["evaldata_acronyms"]

        if not isinstance(data2proof, list):
            raise TypeError("'data2proof_acronyms' must be a list.")
        if not isinstance(evaldata, list):
            raise TypeError("'evaldata_acronyms' must be a list.")

        if not data2proof and not evaldata:
            raise ValueError(
                "Configuration invalid: both 'data2proof_acronyms' and 'evaldata_acronyms' are empty.\n"
                "→ You must provide at least one dataset to evaluate or compare against."
            )

    @log_function_name
    def _validate_unique_data2proof_acronyms(self) -> None:
        """
        Ensures that 'data2proof_acronyms' contains only unique entries.

        Raises:
        ----------------------------
            KeyError: If the key is missing.
            ValueError: If duplicate entries are found.
        """
        key = "data2proof_acronyms"
        if key not in self.cfggen:
            raise KeyError(f"'{key}' is missing in cfggen.")

        raw_acronyms = self.cfggen[key]
        if not isinstance(raw_acronyms, list):
            raise TypeError(f"'{key}' must be a list, got {type(raw_acronyms)}.")

        # Strip whitespace and validate each is a string
        acronyms = []
        for item in raw_acronyms:
            if not isinstance(item, str):
                raise TypeError(f"Each item in '{key}' must be a string, got {type(item)}.")
            acronyms.append(item.strip())

        duplicates = [item for item in set(acronyms) if acronyms.count(item) > 1]

        if duplicates:
            raise ValueError(
                f"Duplicate dataset acronyms found in '{key}': {sorted(duplicates)}\n"
                f"→ Each acronym must be unique."
            )

    @log_function_name
    def _validate_unique_evaldata_acronyms(self) -> None:
        """
        Ensures that 'evaldata_acronyms' contains only unique entries.

        Raises:
        ----------------------------
            KeyError: If the key is missing.
            ValueError: If duplicate entries are found.
        """
        key = "evaldata_acronyms"
        if key not in self.cfggen:
            raise KeyError(f"'{key}' is missing in cfggen.")

        raw_acronyms = self.cfggen[key]
        if not isinstance(raw_acronyms, list):
            raise TypeError(f"'{key}' must be a list, got {type(raw_acronyms)}.")

        acronyms = []
        for item in raw_acronyms:
            if not isinstance(item, str):
                raise TypeError(f"Each item in '{key}' must be a string, got {type(item)}.")
            acronyms.append(item.strip())

        duplicates = [item for item in set(acronyms) if acronyms.count(item) > 1]

        if duplicates:
            raise ValueError(
                f"Duplicate dataset acronyms found in '{key}': {sorted(duplicates)}\n"
                f"→ Each acronym must be unique."
            )

    @log_function_name
    def _validate_masking_program(self, maskingprog: Optional[str], supported_MaskingProg: dict) -> None:
        """
        Validates that the provided masking program is supported.

        Args:
        ----------------------------
            maskingprog: The name of the masking program selected by the user.
            supported_MaskingProg: Dictionary of supported masking program names.

        Raises:
        ----------------------------
            ValueError: If the masking program is not among the supported options.
        """
        if not maskingprog:
            raise ValueError("No masking program specified (maskingprog is None or empty).")

        if maskingprog not in supported_MaskingProg:
            raise ValueError(
                f"The masking software '{maskingprog}' is not supported.\n"
                f"→ Supported options are: {sorted(supported_MaskingProg.keys())}"
            )

    @log_function_name
    def _validate_eval_mode_supported(self) -> None:
        """
        Validates that the evaluation mode specified in 'cfggen' is supported.

        Raises:
        ----------------------------
            KeyError: If 'eval_Mode' is missing from the configuration.
            ValueError: If the evaluation mode is not listed among the supported modes.
        """
        if "eval_Mode" not in self.cfggen:
            raise KeyError("'eval_Mode' is missing in cfggen.")

        mode = self.cfggen["eval_Mode"]

        if not isinstance(mode, str) or mode not in self.supported_EVAL_modes:
            raise ValueError(
                f"Evaluation mode '{mode}' is not supported.\n"
                f"→ Supported modes: {sorted(self.supported_EVAL_modes.keys())}"
            )

    @log_function_name
    def _validate_data_dump_process_programs(self, supported_DataDumpProcessProgs: dict) -> None:
        """
        Validates that the data dump/process programs defined in 'sysset' match the supported ones.

        Args:
        ----------------------------
            supported_DataDumpProcessProgs: Dictionary of supported processing tools (e.g., CDO, NCO, etc.)

        Raises:
        ----------------------------
            KeyError: If 'DataDumpProcess_programs' is missing from sysset.
            ValueError: If any unsupported or missing programs are detected.
        """
        if "DataDumpProcess_programs" not in self.sysset:
            raise KeyError("'DataDumpProcess_programs' is missing in sysset.")

        config_keys = set(self.sysset["DataDumpProcess_programs"].keys())
        supported_keys = set(supported_DataDumpProcessProgs.keys())

        if config_keys != supported_keys:
            missing = supported_keys - config_keys
            extra = config_keys - supported_keys

            error_msg = "Mismatch in configured vs. supported data dump/process programs:\n"
            if missing:
                error_msg += f"→ Missing in config: {sorted(missing)}\n"
            if extra:
                error_msg += f"→ Unsupported in config: {sorted(extra)}\n"
            error_msg += f"Expected: {sorted(supported_keys)}"

            raise ValueError(error_msg)

    @log_function_name
    def _resolve_missing_data2proof_acronyms(self) -> None:
        """
        Ensures all 'data2proof_acronyms' are present in 'proofset'.
        If missing, but found in 'evalset', they are moved over.
        If still missing, logs an error.

        Raises:
        ----------------------------
            KeyError: If 'data2proof_acronyms' is missing from config.
        """
        if "data2proof_acronyms" not in self.cfggen:
            raise KeyError("'data2proof_acronyms' is missing in cfggen.")

        acronyms = GenUti.check_for_list(self.cfggen["data2proof_acronyms"])
        missing_from_proofset = list(set(acronyms) - set(self.proofset.keys()))

        if not missing_from_proofset:
            return  # Nothing to fix

        missing_from_evalset = list(set(missing_from_proofset) - set(self.evalset.keys()))

        if not missing_from_evalset:
            logger.warning(
                f"Some datasets listed in 'data2proof_acronyms' were not found in 'proofset', "
                f"but were found in 'evalset': {missing_from_proofset}. "
                f"→ They will be copied over."
            )
            for datkey in missing_from_proofset:
                self.proofset[datkey] = self.evalset[datkey]
        else:
            logger.error(
                f"The following datasets from 'data2proof_acronyms' are missing in both 'proofset' "
                f"and 'evalset': {missing_from_evalset}. Cannot continue. Please check you "
                "modeldata_settings.yaml or reference_datasets.yaml files."
            )
            raise ValueError(
                f"Missing datasets in 'proofset' and 'evalset': {missing_from_evalset}"
            )

    @log_function_name
    def _resolve_missing_evaldata_acronyms(self) -> None:
        """
        Ensures all 'evaldata_acronyms' are present in 'evalset'.
        If missing, but found in 'proofset', they are copied over.
        If still missing, logs an error.

        Raises:
        ----------------------------
            KeyError: If 'evaldata_acronyms' is missing in config.
        """
        if "evaldata_acronyms" not in self.cfggen:
            raise KeyError("'evaldata_acronyms' is missing in cfggen.")

        acronyms = GenUti.check_for_list(self.cfggen["evaldata_acronyms"])
        missing_from_evalset = list(set(acronyms) - set(self.evalset.keys()))

        if not missing_from_evalset:
            return  # All good

        missing_from_proofset = list(set(missing_from_evalset) - set(self.proofset.keys()))

        if not missing_from_proofset:
            logger.warning(
                f"Some datasets listed in 'evaldata_acronyms' were not found in 'evalset', "
                f"but were found in 'proofset': {missing_from_evalset}. "
                f"→ They will be copied over."
            )
            for datkey in missing_from_evalset:
                self.evalset[datkey] = self.proofset[datkey]
        else:
            logger.error(
                f"The following datasets from 'evaldata_acronyms' are missing in both 'evalset' "
                f"and 'proofset': {missing_from_proofset}. Cannot continue."
            )
            raise ValueError(
                f"Missing datasets in both 'evalset' and 'proofset': {missing_from_proofset}"
            )

    @log_function_name
    def CheckUserSetting(
        self: 'Control_namelists',
        supported_MaskingProg: Dict[str, PyRegionmask],
        supported_DataDumpProcessProgs: Dict[str, Union[CDO, NCO, NCSYS, PyXarray]],
        maskingprog: Optional[str] = None,
    ):
        """
        Perform a full validation of user configuration settings to prevent evaluation crashes.

        This method performs a comprehensive series of checks on user-defined options and system requirements
        before running any data evaluation. It verifies required acronyms, available tools, grid settings,
        interpolation consistency, and dataset completeness. This ensures that the evaluation process can
        proceed safely and predictably.

        Parameters
        ----------
        supported_MaskingProg : dict
            Dictionary mapping masking program names (e.g., 'regionmask', 'pyregion')
            to supported masking backends.

        supported_DataDumpProcessProgs : dict
            Dictionary mapping backend tools (e.g., 'CDO', 'NCO', 'NCSYS', 'PyXarray')
            to their corresponding classes.

        maskingprog : str, optional
            Name of the user-selected masking program. If None, the default masking
            program from the config will be used.

        Actions Performed
        -----------------
        - Validates that the selected evaluation mode is supported.
        - Checks for availability and compatibility of the data processing backends.
        - Validates user-defined masking program selection.
        - Ensures that `data2proof` and `evaldata` acronyms are defined and unique.
        - Auto-resolves any missing acronyms if possible.
        - Confirms dataset entries exist and are properly defined in the config.
        - Validates that reference datasets are provided when required.
        - Checks horizontal and vertical grid transformation settings for all datasets.
        - Verifies that all datasets conform to expected temporal resolution rules.
        - Confirms that custom metric settings are valid and consistent with the number of datasets.

        Raises
        ------
        ValueError, KeyError, or custom validation exceptions
            If any validation step fails or encounters missing/inconsistent configuration.

        Notes
        -----
        This method is intended to be called early in the evaluation workflow
        to avoid runtime errors and ensure configuration consistency across the pipeline.
        """
        self._validate_eval_mode_supported()
        self._validate_data_dump_process_programs(supported_DataDumpProcessProgs)
        # -- Check masking program:
        self._validate_masking_program(maskingprog, supported_MaskingProg)
        # -- Check the datasets and its settings:
        self._validate_unique_data2proof_acronyms()
        self._validate_unique_evaldata_acronyms()
        # -- Check data2proof_acronyms and evaldata_acronyms
        self._resolve_missing_data2proof_acronyms()
        self._resolve_missing_evaldata_acronyms()
        # -- Control of data2proof_acronyms and evaldata_acronyms:
        self._validate_datasets_exist()
        # -- Control of EVAL_modes_setup field:
        self._validate_reference_data_required()
        # -- Check some user settings regarding the interpolation and target frequency:
        datsetlist = self.cfggen["data2proof_acronyms"] + self.cfggen["evaldata_acronyms"]
        # -- Control of targetgrid_horizontal field:
        self._validate_targetgrid_horizontal(datsetlist)
        # -- Control of targetgrid_vertical field:
        self._validate_targetgrid_vertical(datsetlist)
        # -- Control of target_EvalFrequency field:
        self._validate_target_eval_frequency(datsetlist)
        # -- Check for number of datasets consistent to data2proof and evaldata:
        self._validate_eval_metrics_userdefined()


class Control_dataset_namelists:
    """
    Handles validation of dataset directory and file availability for a given acronym.

    This class is used to ensure that the user-provided dataset path and variable/file pattern
    are correctly defined and accessible before any data processing occurs.
    """

    def __init__(self, name, cfgdataset, var) -> None:
        """
        Initialize a dataset configuration checker.

        Parameters
        ----------
        name : str
            Acronym or identifier for the dataset (e.g., 'OBS', 'CMIP6-EC-Earth').

        cfgdataset : dict
            Dictionary containing dataset-specific configuration. Must include a key `'storagedir'`
            that points to the directory where the dataset files are located.

        var : str
            Filename pattern used to search for NetCDF or data files in the storage directory.
            Example values include: `'*.nc'`, `'tas_*.nc'`, `'pr_monthly.nc'`.

        Notes
        -----
        This constructor sets up the internal references for dataset validation.
        Use `run_all_checks()` to validate directory access and file presence.
        """
        self.name = name
        self.cfgdataset = cfgdataset
        self.research_var = var
        self.path = self.cfgdataset.get("storagedir")

    def _validate_directory(self) -> None:
        """
        Validate that the dataset directory exists and is readable.

        This method checks whether the path defined in the dataset's configuration
        (`storagedir`) is accessible. If the path is missing or unreadable, an informative
        `FileNotFoundError` is raised to help the user identify and fix the issue.

        Raises
        ------
        FileNotFoundError
            If the directory does not exist or the process lacks read permissions.

        Notes
        -----
        This check is essential before attempting to search for data files using a pattern.
        """
        if not self.path or not os.access(self.path, os.R_OK):
            raise FileNotFoundError(
                f"ERROR for data '{self.name}': The user-specified directory does not exist.\n"
                f"Check your `reference_datasets.yaml` or `modeldata_settings.yaml` config.\n"
                f"Missing directory: {self.path}"
            )

    def _validate_file_pattern(self) -> None:
        """
        Check that at least one file matches the expected filename pattern.

        This method uses the `research_var` field (e.g., '*.nc', 'tas_*.nc') to search for
        matching files in the dataset's storage directory. If no matching files are found,
        it raises a `FileNotFoundError` with detailed guidance.

        Raises
        ------
        FileNotFoundError
            If no files match the provided pattern in the specified directory.

        Notes
        -----
        - The full search path is constructed as: `os.path.join(storagedir, research_var)`
        - This check ensures that variable names and file patterns in the configuration
          are correctly aligned with the actual dataset contents.
        """
        pattern = os.path.join(self.path, self.research_var)

        if not glob.glob(pattern):
            raise FileNotFoundError(
                f"ERROR for data '{self.name}': No files found matching the pattern:\n"
                f"'{pattern}'\n"
                f"Check your variable name or file naming in the YAML configuration."
            )

    def run_all_checks(self) -> None:
        """
        Run all dataset validation checks in sequence.

        This convenience method validates both the storage directory and the
        presence of files matching the configured pattern. It ensures that
        the dataset is correctly defined and ready for use in further processing.

        Performs
        --------
        - Directory existence and readability check.
        - File pattern match check (e.g., '*.nc').

        Raises
        ------
        FileNotFoundError
            If either the directory is missing/inaccessible or no files match the pattern.
        """
        self._validate_directory()
        self._validate_file_pattern()
