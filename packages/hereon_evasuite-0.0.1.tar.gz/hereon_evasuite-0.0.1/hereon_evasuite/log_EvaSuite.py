# EvaSuite
#
# ---------------------------------------------------------------
# Copyright (C) 2004-2025, Hereon
# Contact information: beate.geyer@hereon.de, imktro-climate-modelling@lists.kit.edu
# See AUTHORS.TXT for a list of authors
# See LICENSES/ for license information
# SPDX-License-Identifier: Apache-2.0
# ---------------------------------------------------------------

import logging
import sys
import warnings
import functools
import inspect
import os
from collections import defaultdict
from pathlib import Path
from typing import Callable, TypeVar, ParamSpec, Dict, Union


# -- Internal global variable for singleton logger:
_global_logger = None


def setup_custom_logger(name: str, filename: Union[str, Path]) -> logging.Logger:
    """
    Create and configure a custom logger with both file and console output.

    The logger is configured to:
    ----------------------------
      - Log DEBUG and higher messages to a file (if `filename` is provided).
      - Log INFO and higher messages to stdout with a simplified format.
      - Suppress overly verbose output from common external libraries (matplotlib, numba, xarray, dask).
      - Redirect Python warnings to the logger.

    Args:
    ----------------------------
        name (str):
            The name of the logger (namespace for log messages).
        filename (str | None, optional):
            Path to the log file. If provided, all DEBUG+ messages are written here.
            If None, a file handler will still be created but without a specified file path,
            which may cause errors.

    Returns:
    ----------------------------
        logging.Logger:
            The configured logger instance.

    Notes:
    ----------------------------
        - File handler logs with timestamp, level, and message.
        - Stream handler (stdout) logs messages with minimal formatting.
        - Logger propagation is disabled to prevent duplicate messages in the root logger.
    """
    # -- Configure the file output:
    handlerFile = logging.FileHandler(
        filename, mode = 'w', encoding = None, delay = False)

    # formatter = logging.Formatter("%(asctime)s - %(levelname)-6s - %(prog_version)s - %(message)s")
    formatter = logging.Formatter("%(asctime)s - %(levelname)-6s - %(message)s")
    handlerFile.setFormatter(formatter)
    handlerFile.setLevel(logging.DEBUG)

    # -- Configure the standard output:
    handlerStdout = logging.StreamHandler(sys.stdout)
    formatter = logging.Formatter("\n %(message)s")
    handlerStdout.setFormatter(formatter)
    handlerStdout.setLevel(logging.INFO)

    # -- Use a scoped logger name to avoid polluting global logs
    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(handlerFile)
    logger.addHandler(handlerStdout)

    # -- Prevent propagation to root logger to avoid system spam:
    logger.propagate = False
    # -- Optional: Suppress noisy external libraries
    logging.getLogger("matplotlib").setLevel(logging.WARNING)
    logging.getLogger("numba").setLevel(logging.WARNING)
    logging.getLogger("xarray").setLevel(logging.WARNING)
    logging.getLogger("dask").setLevel(logging.WARNING)

    # -- Redirect Python warnings to logger
    def log_warning(message, category, filename, lineno, file=None, line=None):
        logger.warning(f"{category.__name__} in {filename}, line {lineno}: {message}")
    warnings.showwarning = log_warning

    return logger


def get_logger() -> logging.Logger:
    """
    Retrieve the global logger instance.

    If the global logger has not yet been initialized, this function
    will create it using `setup_custom_logger` with:
        - Name: 'main'
        - Log file: 'log_EvaSuite.txt'

    Returns:
    ----------------------------
        logging.Logger:
            The singleton logger instance used throughout the application.

    Notes:
    ----------------------------
        - Relies on the `_global_logger` global variable for persistence.
        - Ensures only one logger is created, avoiding duplicate handlers.
    """
    global _global_logger
    if _global_logger is None:
        _global_logger = setup_custom_logger('main', filename='log_EvaSuite.txt')
    return _global_logger


# -- Special function name logger
_function_call_counts: defaultdict[str, int] = defaultdict(int)
_expected_function_calls: Dict[str, int] = {}


def set_expected_function_calls(func_name: str, expected_count: int) -> None:
    """
    Set the expected number of calls for a given function.

    This is used by the `log_function_name` decorator to control when
    to print a "function called" message. If the expected call count is set,
    the message is printed only when the function has been called exactly
    that number of times.

    Args:
    ----------------------------
        func_name (str):
            The fully qualified function name (e.g., 'MyClass.my_method').
        expected_count (int):
            The number of calls after which to log the function call message.

    Side Effects:
    ----------------------------
        - Updates the `_expected_function_calls` global dictionary.
    """
    _expected_function_calls[func_name] = expected_count


P = ParamSpec("P")
R = TypeVar("R")


def log_function_name(func: Callable[P, R]) -> Callable[P, R]:
    """
    Decorator to log the name and call count of a function when it is executed.

    Behavior:
    ----------------------------
      - Tracks how many times each decorated function has been called.
      - If an expected call count is set via `set_expected_function_calls`, logs
        the function call only when that count is reached.
      - Logs the caller's file and line number for context.

    Args:
    ----------------------------
        func (Callable[P, R]):
            The function to wrap.

    Returns:
    ----------------------------
        Callable[P, R]:
            The wrapped function with added logging behavior.

    Notes:
    ----------------------------
        - If the first argument to the function is a class instance (`self`),
          the log includes the class name.
        - Uses `_function_call_counts` and `_expected_function_calls` global
          dictionaries to track and compare call counts.
    """
    @functools.wraps(func)
    def wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
        # Build full function name
        if args and hasattr(args[0], '__class__'):
            full_name = f"{args[0].__class__.__name__}.{func.__name__}"
        else:
            full_name = func.__name__

        _function_call_counts[full_name] += 1
        count = _function_call_counts[full_name]
        expected = _expected_function_calls.get(full_name)

        # Caller location (shortened)
        stack = inspect.stack()
        if len(stack) > 1:
            frame_info = stack[1]
            script_path = os.path.normpath(frame_info.filename)
            parts = script_path.split(os.sep)
            short_path = "/".join(parts[-2:]) if len(parts) >= 2 else parts[-1]
            location = f"{short_path}:{frame_info.lineno}"
        else:
            location = "unknown"

        if expected is None or count == expected:
            # -- Output in console:
            print(f"Calling: {full_name} ({count} time{'s' if count > 1 else ''}) from {location}")

        return func(*args, **kwargs)

    return wrapper
