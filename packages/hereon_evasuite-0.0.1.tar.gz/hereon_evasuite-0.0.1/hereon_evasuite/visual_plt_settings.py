# EvaSuite
#
# ---------------------------------------------------------------
# Copyright (C) 2004-2025, Hereon
# Contact information: beate.geyer@hereon.de, imktro-climate-modelling@lists.kit.edu
# See AUTHORS.TXT for a list of authors
# See LICENSES/ for license information
# SPDX-License-Identifier: Apache-2.0
# ---------------------------------------------------------------

# ----------------------------------------------------------------------
# Program Description:
# This module defines reusable classes for generating customized 1D plots
# and Taylor diagrams for model evaluation and climate visualization.
#
# Components:
# - Plot_settings: Handles matplotlib-based configuration of axes,
#   grid, titles, labels, ticks, legends, and output settings for 1D plots.
#
# - TaylorDiagram: Implements a polar-based Taylor diagram as proposed
#   by Taylor (2001), plotting model standard deviation and correlation
#   against a reference dataset.
#
# Dependencies: matplotlib, numpy, pandas, axisartist, and user-defined
# support tools (e.g., lib4support).
#
#    History:
#    Version    Date       Name
#    ---------- ---------- ----
#    1.1        04.2025   Evgenii Churiulin, IMKTRO
#                         Initial realise
# ---------------------------------------------------------------
# -- Import python packages:
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import textwrap
import statsmodels.api as sm
import mpl_toolkits.axisartist.floating_axes as fa
import mpl_toolkits.axisartist.grid_finder as gf
from matplotlib.ticker import AutoMinorLocator, NullFormatter
from matplotlib.figure import Figure
from matplotlib.projections import PolarAxes
from typing import Any, Optional, Dict, Callable, Tuple, List, cast, Literal, Union

# -- Import user methods
from hereon_evasuite.visual_support import Time_class
from hereon_evasuite.log_EvaSuite import get_logger, log_function_name
logger = get_logger()


class Plot_settings:
    """
    Class for configuring user-defined styling and behavior for 1D matplotlib plots.

    Attributes:
    -----------
    Accepts plot styling parameters such as colors, marker styles, grid types,
    and axis labels from user-defined dictionaries.

    Parameters:
    -----------
    load_values : Callable[[str, dict], Any]
        Function to retrieve individual settings from a config dictionary.
    subplot_type : str
        Key indicating which subplot configuration to load.
    plots_user_settings : Dict[str, Any]
        Dictionary containing user-defined plot settings.
    """
    # -- Main plot settings:
    plt_title_color: str
    plt_labels_color: str
    plt_llegend: bool
    plt_lgrid: bool
    plt_gtype: str
    plt_gclr: str
    plt_gstyle: str
    plt_galpha: float

    # -- Axis/time formatting:
    plt_num_x_axis: bool
    plt_time_x_axis: bool
    plt_ftime: str
    plt_day_locator: int
    plt_minorLocator: AutoMinorLocator

    # -- X axis appearance:
    plt_l_xrotation: bool
    plt_x_unit_color: str

    # -- Y axis appearance:
    plt_l_yrotation: bool
    plt_y_rotation: float
    plt_y_unit_size: float
    plt_y_unit_color: str

    # -- Extra axis and general save options:
    plt_lextra_axis: bool
    plt_lsave: bool
    plt_format: str
    plt_dpi: int

    # -- Optional plot overrides (if you later add/use them for 1D like in maps):
    plts_title: Optional[str]
    plts_subtitle: Optional[str]
    plts_min_values: Optional[Any]
    plts_max_values: Optional[Any]

    # -- Variable plot style settings (per-series arrays):
    vplt_colors: List[Optional[Any]]
    vplt_ln_styles: List[Optional[str]]
    vplt_ln_widths: List[Optional[float]]
    vplt_alphas: List[Optional[float]]

    vplt_mkr_color: List[Optional[Any]]
    vplt_mkr_size: List[Optional[float]]
    vplt_mkr_style: List[Optional[str]]

    vplt_bar_hatch: List[Optional[str]]
    vplt_bar_widths: List[float]

    # -- Subplot selection (values loaded from the chosen sublayout):
    splt_size: List[float]            # [width, height]
    splt_nrows: int
    splt_ncols: int
    splt_wspace: Optional[float]
    splt_hspace: Optional[float]
    splt_bottom: Optional[float]
    splt_top: Optional[float]
    splt_title_fsize: float
    splt_title_pad: float
    splt_label_fsize: float
    splt_xlabel_pad: float
    splt_ylabel_pad: float
    splt_x_rotation: float
    splt_x_unit_size: float
    splt_l_pos: str
    splt_bbox_x_loc: Optional[float]
    splt_bbox_y_loc: Optional[float]

    # -- Derived dimensions (from splt_size):
    plt_width: float
    plt_heigth: float

    @log_function_name
    def __init__(
        self,
        load_values: Callable,
        subplot_type: str,
        plots_user_settings: Dict[str, Any]
    ) -> None:
        """Initialization of user 1d methods for visualization:"""
        # === Define configuration key groups ===
        # -- Main plot settings (titles, legend, grid, axis basics, figure save options)
        plt_main_catalog = [
            'plt_title_color', 'plt_labels_color', 'plt_llegend', 'plt_lgrid',
            'plt_gtype', 'plt_gclr', 'plt_gstyle', 'plt_galpha', 'plt_num_x_axis',
            'plt_time_x_axis', 'plt_ftime', 'plt_day_locator', 'plt_l_xrotation',
            'plt_x_unit_color', 'plt_l_yrotation', 'plt_y_rotation', 'plt_y_unit_size',
            'plt_y_unit_color', 'plt_lextra_axis', 'plt_lsave', 'plt_format',
            'plt_dpi'
        ]

        # -- Variable plot style settings (line, marker, bar, alpha):
        vplt_keys = [
            'vplt_colors', 'vplt_ln_styles', 'vplt_ln_widths',
            'vplt_mkr_color', 'vplt_mkr_size', 'vplt_mkr_style',
            'vplt_bar_widths', 'vplt_bar_hatch', 'vplt_alphas',
        ]

        # -- Subplot layout and appearance:
        subplot_catalog = [
            'splt_nrows', 'splt_ncols', 'splt_wspace', 'splt_hspace',
            'splt_bottom', 'splt_top', 'splt_title_fsize', 'splt_title_pad',
            'splt_label_fsize', 'splt_xlabel_pad', 'splt_ylabel_pad',
            'splt_x_rotation', 'splt_x_unit_size', 'splt_l_pos',
            'splt_bbox_x_loc', 'splt_bbox_y_loc',
        ]

        # === Load user settings from main plot config ===
        # -- Load main plot settings
        for key in plt_main_catalog:
            setattr(self, key, load_values(key, dict4settings=plots_user_settings))
        # -- Special case: minor locator
        minor_locator = load_values('plt_minor_locator', dict4settings = plots_user_settings)
        self.plt_minorLocator = AutoMinorLocator(n = minor_locator)

        # -- Load variable style settings (direct dict.get)
        for key in vplt_keys:
            setattr(self, key, plots_user_settings.get(key))

        # === Load subplot-specific settings ===
        # -- Select subplot settings based on subplot_type
        plt_subplots = load_values(
            'subplots', dict4settings = plots_user_settings).get(subplot_type)
        # -- Extract figure width and height
        plt_size = load_values('splt_size', dict4settings = plt_subplots)
        self.plt_width, self.plt_heigth = plt_size[0], plt_size[1]

        # -- Load subplot parameters
        for key in subplot_catalog:
            setattr(self, key, load_values(key, dict4settings = plt_subplots))

    @log_function_name
    def correct_time(self, time: Any) -> Union[pd.Series, pd.DatetimeIndex]:
        """
        Converts string-based time series into datetime format appropriate
        for plotting and infers time resolution (monthly/hourly).

        Parameters:
        -----------
        time : Any
            Input time array (e.g., list or pandas index).

        Returns:
        --------
            pd.Series : Time array in timestamp format.
        """
        time_ctr = Time_class()
        # -- Define correct format of time_stamps depending on input data:
        self.plt_ftime = time_ctr.get_time_interval(time)
        if self.plt_ftime in ['%d.%m.%Y', '%Y-%m-%d']:
            logger.info('Monthly data')
            time = pd.to_datetime(time).to_period('M').to_timestamp()
        elif self.plt_ftime in ['%H']:
            logger.info('Hourly data')
            time = pd.to_datetime(time)
        return time

    @log_function_name
    def create_plot_data(
        self,
        ax: plt.Axes,
        data: Union[np.ndarray, list[np.ndarray]],
        ds_names: list[str],
        plot_mode: str,
        time: np.ndarray,
        subplot_idx: int,
        dataset_idx: Optional[int] = None,
    ) -> None:
        """
        Plot a dataset on the given Matplotlib axis according to the selected mode.

            Supports three plot modes: `"line"`, `"scatter"`, and `"bar"`.
            Uses user-defined visualization settings (colors, styles, widths, etc.)
            from the class attributes based on the dataset or subplot index.

        Parameters
        ----------
        ax : matplotlib.axes.Axes
            The Matplotlib axis to plot on.
        data : Sequence or nested Sequence
            The data to plot. For multiple datasets in subplots, this can be a
            nested list/array indexed as data[subplot_idx][dataset_idx].
        ds_names : Sequence[str]
            Labels/names for each dataset, used for the legend.
        plot_mode : str
            Type of plot: `"line"`, `"scatter"`, or `"bar"`.
        time : Sequence
            Time or x-axis values corresponding to `data_to_plot`.
        subplot_idx : int
            Index of the subplot in the figure.
        dataset_idx : int, optional
            Index of the dataset within the subplot. If `None`, assumes one dataset
            per subplot.

        Raises
        ------
        TypeError
            If `plot_mode` is not one of `"line"`, `"scatter"`, `"bar"`.

        Notes
        -----
            - Visualization parameters (color, linestyle, marker style, etc.) are taken
              from the object's attributes:
              `self.vplt_colors`, `self.vplt_ln_styles`, `self.vplt_ln_widths`,
              `self.vplt_alphas`, `self.vplt_mkr_style`, `self.vplt_mkr_size`,
              `self.vplt_mkr_color`, `self.vplt_bar_widths`, `self.vplt_bar_hatch`.
            - `time` can be numeric, datetime-like, or categorical.
        """

        # -- Local variables:
        # -- Support both single and subplot indices:
        if dataset_idx is not None:
            data_to_plot = data[subplot_idx][dataset_idx]
            labels = ds_names[dataset_idx]
            idx = cast(int, dataset_idx)
        else:
            data_to_plot = data[subplot_idx]
            labels = ds_names[subplot_idx]
            idx = subplot_idx

        # -- Visualization settings
        colors = self.vplt_colors[idx]
        lns = self.vplt_ln_styles[idx]
        lnw = self.vplt_ln_widths[idx]
        alp = self.vplt_alphas[idx]
        mstyle = self.vplt_mkr_style[idx]
        msize = self.vplt_mkr_size[idx]
        mfcolor = self.vplt_mkr_color[idx]
        bwidths = self.vplt_bar_widths[idx]
        bhatch = self.vplt_bar_hatch[idx]

        # -- Define algorithm for visualization depending on user request
        #    (line, scatter, bar):
        match plot_mode:
            case 'line':
                ax.plot(
                    time,
                    data_to_plot,
                    label = labels,
                    color = colors,
                    linestyle = lns,
                    linewidth = lnw,
                    alpha = alp,
                    marker = mstyle,
                    markersize = msize,
                    markerfacecolor = mfcolor,
                )
            case 'scatter':
                ax.scatter(
                    time,
                    data_to_plot,
                    label = labels,
                    c = colors,
                    s = msize,
                    marker = mstyle,
                    linewidth = msize,
                    alpha = alp,
                )
            case 'bar':
                ax.bar(
                    time,
                    data_to_plot,
                    label = labels,
                    color = colors,
                    alpha = alp,
                    ls = lns,
                    lw = lnw,
                    width = bwidths,
                    hatch = bhatch,
                )
            case _:  # wildcard
                raise TypeError('Incorrect plot_mode for visualization')

    @log_function_name
    def add_zero_line(self, ax: plt.Axes, mode: str, ymin: float, ymax: float) -> None:
        """
        Conditionally adds a horizontal zero line to the given axis.

        The zero line (y=0) is only added if the provided y-axis limits indicate
        that zero is within or near the visible range (i.e., ymin < 1 and ymax > -1).

        Parameters:
        -----------
        ax : matplotlib.axes.Axes
            The axis object where the zero line should be added.
        mode : str
            Evaluation mode (currently unused but available for future logic).
        ymin : float
            Lower limit of the y-axis.
        ymax : float
            Upper limit of the y-axis.
        """
        if mode == 'CompareRAW':
            logger.info('Zero line is turned off -> we are using absolute values')
        else:
            if ymin < 0.5 and ymax > -0.5:
                ax.axhline(0, color='black', linestyle='--', linewidth=1, alpha=0.7, zorder=0)
            else:
                logger.info(
                    f"Zero line skipped: y-range ({ymin:.2f}, {ymax:.2f}) — outside of [-1, 1]")

    @log_function_name
    def add_title_xy_label(self, ax: plt.Axes, **kwargs) -> None:
        """Add plot title and X and Y labels: """
        # -- Color of title and labels:
        tcolor, lcolor = self.plt_title_color, self.plt_labels_color
        # -- Fontsize of title and lables:
        tsize, fsize = self.splt_title_fsize, self.splt_label_fsize
        # -- Pad for title and labels (x and y):
        tpad, xlpad, ylpad = self.splt_title_pad, self.splt_xlabel_pad, self.splt_ylabel_pad
        # -- Max possible len (in simbols) for y axis:
        max_length = 25
        # -- Vars:
        title, xlabel, ylabel = kwargs.get("title"), kwargs.get("xlabel"), kwargs.get("ylabel")

        # -- Add plot title:
        if title is not None:
            if not isinstance(title, str):
                raise ValueError(f"'title' must be a string, got {type(title).__name__}")
            ax.set_title(title, color = tcolor, fontsize = tsize, pad = tpad)

        # -- Add X label:
        if xlabel is not None:
            if not isinstance(xlabel, str):
                raise ValueError(f"'xlabel' must be a string, got {type(xlabel).__name__}")
            ax.set_xlabel(xlabel, color = lcolor, fontsize = fsize, labelpad = xlpad)

        # -- Add Y label (insert line breaks if length > max_length):
        if ylabel is not None:
            if not isinstance(ylabel, str):
                raise ValueError(f"'ylabel' must be a string, got {type(ylabel).__name__}")
            frm_ylabel = "\n".join(textwrap.wrap(kwargs['ylabel'], width=max_length))
            ax.set_ylabel(frm_ylabel, color = lcolor, fontsize = fsize, labelpad = ylpad)

    @log_function_name
    def add_limits4_X_axis(self, ax: plt.Axes, **kwargs) -> None:
        """
        Apply user-defined limits and tick formatting to the X-axis.

        This method can configure the X-axis in two modes:
        ----------------------------
        1. **Numeric mode** (self.plt_num_x_axis=True):
           - Use `xlim_num=[start, stop, step]` in kwargs to set fixed numeric ticks
             via `np.arange(start, stop, step)`.

        2. **Time mode** (self.plt_time_x_axis=True):
           - Use `xlim_time=[start, end]` in kwargs to set time limits.
             `start` and `end` can be strings (matching `self.plt_ftime`),
             `datetime` objects, `pd.Timestamp`, or `np.datetime64`.
           - Automatically selects a date formatter and locator based on
             `self.plt_ftime` (e.g., '%Y-%m-%d', '%d.%m.%Y', '%H', '%Y', '%B').
           - If start and end are identical, expands limits by ±0.5 days.

        Parameters
        ----------
        ax : plt.Axes
            The Matplotlib Axes object to configure.
        **kwargs
            Additional arguments:
            - `xlim_num` : list or tuple of [start, stop, step] for numeric ticks.
            - `xlim_time` : list or tuple of [start, end] for time limits.
            - `time_frmt` : optional override for `self.plt_ftime` when parsing
              string dates.

        Notes
        -----
        - Minor ticks are automatically added in time mode.
        - Logs an error and returns if the provided time limits cannot be parsed.
        """
        # -- Local variables:
        time_frmt = self.plt_ftime

        years = mdates.YearLocator()
        months = mdates.MonthLocator()
        days = mdates.DayLocator(self.plt_day_locator)

        # -- Set limits for X axis:
        #    1. Numerical format of X axis:
        if self.plt_num_x_axis:
            xlim_num = kwargs.get('xlim_num')
            if isinstance(xlim_num, (list, tuple)) and len(xlim_num) == 3:
                ax.set_xticks(np.arange(xlim_num[0], xlim_num[1], xlim_num[2]))

        #    2. Time format of X axis (
        #       '%d.%m.%Y', '%Y-%m-%d', '%H', '%Y',  '%B', '%d-%m' or %m-%d):
        if self.plt_time_x_axis:
            xlim_time = kwargs.get('xlim_time')
            if isinstance(xlim_time, (list, tuple)) and len(xlim_time) == 2:
                # -- Convert time limits:
                try:
                    start_raw, end_raw = xlim_time[0], xlim_time[1]
                    xlim_start = (
                        pd.to_datetime(start_raw, format = time_frmt)
                        if isinstance(start_raw, str) else pd.to_datetime(start_raw)
                    )
                    xlim_end = (
                        pd.to_datetime(end_raw, format = time_frmt)
                        if isinstance(end_raw, str) else pd.to_datetime(end_raw)
                    )

                    # -- If start and end are identical (single point), expand by ±1 day
                    if xlim_start == xlim_end:
                        xlim_start -= pd.Timedelta(days=0.5)
                        xlim_end += pd.Timedelta(days=0.5)
                    ax.set_xlim(xlim_start, xlim_end)

                except (ValueError, TypeError) as exc:
                    logger.error(
                        f"Invalid time limits or format '{time_frmt}': {exc}. "
                        "Ensure 'xlim_time' matches the expected format."
                    )
                    return

                # -- Choose formatter/locator
                if time_frmt in ['%d.%m.%Y', '%Y-%m-%d']:
                    xftm = mdates.DateFormatter(time_frmt)
                    ax.xaxis.set_major_locator(days)
                elif time_frmt in ['%H']:
                    xftm = mdates.DateFormatter('%H')
                    ax.xaxis.set_major_locator(mdates.HourLocator(byhour=range(0, 24, 3)))
                elif time_frmt in ['%Y', '%B', '%d-%m', '%m-%d']:
                    xftm = mdates.DateFormatter(time_frmt)
                    ax.xaxis.set_major_locator(years if time_frmt == '%Y' else months)
                else:
                    logger.warning("Unsupported format. Defaulting to '%d.%m.%Y'")
                    xftm = mdates.DateFormatter('%d.%m.%Y')
                    ax.xaxis.set_major_locator(days)

                ax.xaxis.set_major_formatter(xftm)
                ax.xaxis.set_minor_locator(mdates.AutoDateLocator())

    @log_function_name
    def add_limits4_Y_axis(self, ax: plt.Axes, **kwargs) -> None:
        """
        Set Y-axis limits and ticks.

        If 'ylim_num' is provided in kwargs as a list or tuple of three numeric values,
        it is used to define the Y-axis ticks using np.arange(start, stop, step).

        Also applies minor tick locator and disables minor tick labels.

        Parameters:
        ----------------------------
            - ax (plt.Axes): The axis to apply Y-axis settings to.
            - ylim_num (list or tuple of 3 values): [start, stop, step] for Y ticks.
        """
        scaling_factor = 1e-3
        ylim_num = kwargs.get('ylim_num')
        # -- Set limits for Y axis:
        if isinstance(ylim_num, (list, tuple)) and len(ylim_num) == 3:
            # Get all Y data from lines
            y_data = []
            for line in ax.get_lines():
                y_data.extend(line.get_ydata())
            y_data = np.array(y_data)

            # Skip axis setting if flat or nan
            if np.all(np.isnan(y_data)) or np.nanmax(y_data) == np.nanmin(y_data):
                logger.info("Y-axis skipped: flat or nan-only.")
                return
            # Check for tiny values
            abs_max = np.nanmax(np.abs(y_data))
            if abs_max < scaling_factor:
                logger.info("Applying scientific scaling to Y-axis.")
                ax.ticklabel_format(axis='y', style='sci', scilimits=(0, 0))
                ax.yaxis.major.formatter.set_powerlimits((-3, 3))
            else:
                ax.set_yticks(np.arange(ylim_num[0], ylim_num[1], ylim_num[2]))
                ax.yaxis.set_minor_locator(self.plt_minorLocator)
                ax.yaxis.set_minor_formatter(NullFormatter())

    @log_function_name
    def add_xticks_settings(self, ax: plt.Axes, **kwargs) -> None:
        """User settings for controling location of ticks for x axes"""
        if self.plt_l_xrotation:
            # -- Set size and position of X axis ticks:
            for label in ax.xaxis.get_ticklabels():
                label.set_color(self.plt_x_unit_color)
                label.set_rotation(self.splt_x_rotation)
                label.set_fontsize(self.splt_x_unit_size)

    @log_function_name
    def add_yticks_settings(self, ax: plt.Axes, **kwargs) -> None:
        """User settings for controling location of ticks for y axes"""
        if self.plt_l_yrotation:
            # -- Set size and position of Y axis ticks:
            for label in ax.yaxis.get_ticklabels():
                label.set_color(self.plt_y_unit_color)
                label.set_rotation(self.plt_y_rotation)
                label.set_fontsize(self.plt_y_unit_size)

    @log_function_name
    def add_extra_y_axis(self, ax: plt.Axes, **kwargs) -> None:
        """Add second Y axis from right side"""
        if self.plt_lextra_axis:
            # -- Settings for major and minor Y axis:
            for which in ("major", "minor"):
                ax.tick_params(
                    axis = 'y', which=which,
                    bottom = True, top = False, left = True, right = True,
                    labelleft ='on', labelright = 'on'
                )

    @log_function_name
    def add_legend_simple(self, ax: plt.Axes, **kwargs) -> None:
        """Add legend to 1d plot:"""
        if self.plt_llegend:
            ax.legend(loc = self.splt_l_pos)

    @log_function_name
    def add_single_legend(
        self,
        fig: Optional[Figure] = None,
        axs: Optional[list[plt.Axes]] = None,
        legend_title: Optional[str] = None,
        **kwargs,
    ) -> None:
        """
        Add legends to subplots.

        Parameters:
        ----------------------------
            - fig (plt.Figure): The figure object (required for single_legend=True).
            - axs (list): List of axes objects for all subplots.
            - legend_title (str): Title for the legend. Default is None.
            - kwargs: Additional arguments for legend configuration (e.g., fontsize, frameon).
        """
        # -- Legend locations:
        lloc = self.splt_l_pos
        xl_loc, yl_loc = self.splt_bbox_x_loc, self.splt_bbox_y_loc

        # -- Skip adding the legend if disabled or marked to skip:
        if not self.plt_llegend:
            return
        # -- Add single legend for the entire figure
        if fig is None or axs is None:
            raise ValueError("Both 'fig' and 'axs' must be provided for single_legend=True")

        # -- Prepare legend options:
        legend_kwargs = {"title": legend_title}
        legend_kwargs.update(kwargs)

        # -- Get handles/labels from first subplot and add legend to full figure
        handles, labels = axs[0].get_legend_handles_labels()
        fig.legend(handles, labels, loc= lloc, bbox_to_anchor=(xl_loc, yl_loc))

    @log_function_name
    def add_grid(self, ax: plt.Axes, **kwargs) -> None:
        """Add grid to 1d plot:"""
        # -- Add grid settings:
        if self.plt_lgrid:
            # -- Control of axis for a grid:
            gtype = self.plt_gtype
            if gtype not in ("major", "minor", "both"):
                raise ValueError(f"Invalid plt_gtype: {gtype!r}")
            # -- Add grid for selected axis:
            ax.grid(
                self.plt_lgrid,
                which=cast(Literal["major", "minor", "both"], gtype),
                color = self.plt_gclr,
                linestyle = self.plt_gstyle,
                alpha = self.plt_galpha,
            )

    @log_function_name
    def save_plot(self, ax: plt.Axes, **kwargs) -> None:
        """
        Save the plot to file or display it interactively.

        If self.plt_lsave is True, saves the figure to a file using the given
        format and resolution. Requires 'plt_pout' in kwargs as output path
        (without file extension). Otherwise, displays the plot using plt.show().
        """
        # -- Output format and resolution from settings:
        frmt, dpi = self.plt_format, self.plt_dpi

        if self.plt_lsave:
            # -- Get output filename from kwargs (without extension):
            pout = kwargs.get('plt_pout')
            # -- Save figure to file with specified format and resolution (after validation):
            if isinstance(pout, str) and pout.strip():
                plt.savefig(f"{pout}.{frmt}", format = frmt, dpi = dpi)
            else:
                raise ValueError(
                    "Missing or invalid 'plt_pout' argument: expected a non-empty "
                    "string for the output file name. Make sure to pass e.g., "
                    "plt_pout='output/figure_name' when saving the plot."
                )
        else:
            # -- Show plot interactively if saving is disabled:
            plt.show()


class TaylorDiagram(object):
    """
    Taylor diagram.
    Plot model standard deviation and correlation to reference (data)
    sample in a single-quadrant polar plot, with r=stddev and
    theta=arccos(correlation).

    Taylor diagram (Taylor, 2001) implementation.
    """
    @log_function_name
    def __init__(
        self,
        refstd,
        fig=None,
        rect=111,
        label='_',
        srange=(0, 1.5),
        extend=False,
        rotation=None
    ) -> None:
        """
        Set up Taylor diagram axes, i.e. single quadrant polar
        plot, using `mpl_toolkits.axisartist.floating_axes`.

        Parameters:
        ----------------------------
            * refstd: reference standard deviation to be compared to
            * fig: input Figure or None
            * rect: subplot definition
            * label: reference label
            * srange: stddev axis extension, in units of *refstd*
            * extend: extend diagram to negative correlations
        """
        # -- Reference standard deviation:
        self.refstd = refstd

        tr = PolarAxes.PolarTransform()

        # Correlation labels
        rlocs = np.array([0, 0.2, 0.4, 0.6, 0.7, 0.8, 0.9, 0.95, 0.99, 1])
        if extend:
            # Diagram extended to negative correlations
            self.tmax = np.pi
            rlocs = np.concatenate((-rlocs[:0:-1], rlocs))
        else:
            # Diagram limited to positive correlations
            self.tmax = np.pi / 2
        tlocs = np.arccos(rlocs)        # Conversion to polar angles
        gl1 = gf.FixedLocator(tlocs)    # Positions
        tf1 = gf.DictFormatter(dict(zip(tlocs, map(str, rlocs))))

        # Standard deviation axis extent (in units of reference stddev)
        self.smin = srange[0] * self.refstd
        self.smax = srange[1] * self.refstd

        ghelper = fa.GridHelperCurveLinear(
            tr,
            extremes = (0, self.tmax, self.smin, self.smax),
            grid_locator1 = gl1, tick_formatter1 = tf1)

        if fig is None:
            fig = plt.figure()

        ax = fa.FloatingSubplot(fig, rect, grid_helper = ghelper)
        fig.add_subplot(ax)

        # Adjust axes
        ax.axis["top"].set_axis_direction("bottom")   # "Angle axis"
        ax.axis["top"].toggle(ticklabels = True, label = True)
        ax.axis["top"].major_ticklabels.set_axis_direction("top")
        ax.axis["top"].label.set_axis_direction("top")
        ax.axis["top"].label.set_text("Correlation")
        ax.axis["top"].major_ticklabels.set_color("black")
        ax.axis["top"].major_ticklabels.set_size(10)

        ax.axis["left"].set_axis_direction("bottom")  # "X axis"
        ax.axis["left"].label.set_text("Standard deviation")
        ax.axis["left"].label.set_fontsize(12)
        ax.axis["left"].major_ticklabels.set_color("black")
        ax.axis["left"].major_ticklabels.set_size(10)
        if rotation is not None:
            ax.axis["left"].major_ticklabels.set_rotation(rotation)

        ax.axis["right"].set_axis_direction("top")    # "Y-axis"
        ax.axis["right"].toggle(ticklabels=True)
        ax.axis["right"].major_ticklabels.set_axis_direction(
            "bottom" if extend else "left")
        ax.axis["right"].major_ticklabels.set_color("black")
        ax.axis["right"].major_ticklabels.set_size(10)

        if self.smin:
            ax.axis["bottom"].toggle(ticklabels=False, label=False)
        else:
            ax.axis["bottom"].set_visible(False)          # Unused

        self._ax = ax                   # Graphical axes
        self.ax = ax.get_aux_axes(tr)   # Polar coordinates

        # Add reference point and stddev contour
        l, = self.ax.plot([0], self.refstd, 'k*',
                          ls='', ms=10, label=label)
        t = np.linspace(0, self.tmax)
        r = np.zeros_like(t) + self.refstd
        self.ax.plot(t, r, 'k--', label='_')

        # Collect sample points for latter use (e.g. legend)
        self.samplePoints = [l]

    @log_function_name
    def add_sample(self, stddev, corrcoef, *args, **kwargs):
        """
        Add sample (*stddev*, *corrcoeff*) to the Taylor
        diagram. *args* and *kwargs* are directly propagated to the
        `Figure.plot` command.
        """
        l, = self.ax.plot(np.arccos(corrcoef), stddev,
                          *args, **kwargs)  # (theta, radius)
        self.samplePoints.append(l)
        return l

    @log_function_name
    def add_grid(self, *args, **kwargs):
        """Add a grid."""
        self._ax.grid(*args, **kwargs)

    @log_function_name
    def add_contours(self, levels=5, **kwargs):
        """
        Add constant centered RMS difference contours, defined by *levels*.
        """
        rs, ts = np.meshgrid(
            np.linspace(self.smin, self.smax),
            np.linspace(0, self.tmax),
        )
        # Compute centered RMS difference
        rms = np.sqrt(self.refstd**2 + rs**2 - 2 * self.refstd * rs * np.cos(ts))
        contours = self.ax.contour(ts, rs, rms, levels, **kwargs)

        return contours


class Advanced_1d_plots:
    @log_function_name
    def __init__(
        self,
        ref_data: np.ndarray,
        test_data: np.ndarray,
        percentiles: Optional[List[float]] = None,
        label_ref: str = "Reference",
        label_test: str = "Test",
    ) -> None:
        self.ref_data = ref_data
        self.test_data = test_data
        self.percentiles = percentiles or list(range(5, 100, 5))
        self.label_ref = label_ref
        self.label_test = label_test

    @log_function_name
    def _qqplot_stats(
        self,
        ref_data: np.ndarray,
        test_data: np.ndarray,
        width_percentile: float = 1.0,
    ) -> Tuple[np.ndarray, np.ndarray]:
        """Compute matching percentiles between reference and test data."""
        levels = np.arange(width_percentile, 100, width_percentile)
        ref_q = np.nanpercentile(ref_data, levels)
        test_q = np.nanpercentile(test_data, levels)
        return ref_q, test_q

    @log_function_name
    def _export_regression_csv(
        self,
        ref_data: np.ndarray,
        test_data: np.ndarray,
        filepath: str,
        meta: Dict[str, str],
    ) -> None:
        """Fit a linear regression model and export the stats to CSV."""
        ref_data = ref_data[~np.isnan(ref_data)]
        test_data = test_data[~np.isnan(test_data)]
        ref_data = sm.add_constant(ref_data)
        model = sm.OLS(test_data, ref_data).fit()

        df = pd.DataFrame({
            'parameter': model.params.index,
            'coefficient': model.params.values,
            'p_value': model.pvalues.values,
            'std_err': model.bse.values
        })
        # Add meta at the top
        with open(filepath, 'w') as f:
            for key, val in meta.items():
                f.write(f"# {key}: {val}\n")
            df.to_csv(f, index=False)

    @log_function_name
    def plot_qq(self, ax: plt.Axes) -> None:
        ax = ax or plt.gca()
        # ref, test = compare_percentiles(self.ref_data, self.test_data, self.percentiles)
        ref, test = 'test', 'test'
        ax.plot(ref, test, 'o-', label='QQ-plot')
        minval = min(np.nanmin(ref), np.nanmin(test))
        maxval = max(np.nanmax(ref), np.nanmax(test))
        ax.plot([minval, maxval], [minval, maxval], 'k--', label='1:1 Line')
        ax.set_xlabel(self.label_ref)
        ax.set_ylabel(self.label_test)
        ax.set_title("QQ Plot")
        ax.legend()

    @log_function_name
    def plot_qq_scatter(self, ax: plt.Axes) -> None:
        ax = ax or plt.gca()
        ax.scatter(self.ref_data, self.test_data, alpha=0.5, label='Data')
        minval = min(np.nanmin(self.ref_data), np.nanmin(self.test_data))
        maxval = max(np.nanmax(self.ref_data), np.nanmax(self.test_data))
        ax.plot([minval, maxval], [minval, maxval], 'k--', label='1:1 Line')
        ax.set_xlabel(self.label_ref)
        ax.set_ylabel(self.label_test)
        ax.set_title("QQ Scatter Plot")
        ax.legend()

    @log_function_name
    def plot_percentile_diff(self, ax: plt.Axes) -> None:
        ax = ax or plt.gca()
        #percentiles, diff = compare_percentiles_diff(self.ref_data, self.test_data, self.percentiles)
        percentiles, diff = 'test', 'test'
        ax.plot(percentiles, diff, marker='o')
        ax.axhline(0, color='k', linestyle='--')
        ax.set_xlabel("Percentile")
        ax.set_ylabel("Difference")
        ax.set_title("Percentile Difference")

    @log_function_name
    def export_qq_csv(self, output_path: str) -> None:
        #ref, test = compare_percentiles(self.ref_data, self.test_data, self.percentiles)
        ref, test = 'test', 'test'
        df = pd.DataFrame({
            'percentile': self.percentiles,
            self.label_ref: ref,
            self.label_test: test,
        })
        df.to_csv(output_path, index=False)

    @log_function_name
    def export_percentile_diff_csv(self, output_path: str) -> None:
        #percentiles, diff = compare_percentiles_diff(self.ref_data, self.test_data, self.percentiles)
        percentiles, diff = 'test', 'test'
        df = pd.DataFrame({
            'percentile': percentiles,
            'diff': diff,
        })
        df.to_csv(output_path, index=False)

    @log_function_name
    def export_regression_csv(self, output_path: str) -> None:
        #model = linear_regression(self.ref_data, self.test_data)
        model = 'test'
        summary = model.summary2().tables[1]  # Coefficients
        summary.to_csv(output_path)
