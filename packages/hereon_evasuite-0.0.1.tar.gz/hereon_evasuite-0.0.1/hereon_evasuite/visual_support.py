# EvaSuite
#
# ---------------------------------------------------------------
# Copyright (C) 2004-2025, Hereon
# Contact information: beate.geyer@hereon.de, imktro-climate-modelling@lists.kit.edu
# See AUTHORS.TXT for a list of authors
# See LICENSES/ for license information
# SPDX-License-Identifier: Apache-2.0
# ---------------------------------------------------------------

# -------------------------------------------------------------------
# Program Description:
# A suite of utility functions and classes for comparing, validating,
# and handling structured climate data stored in dictionaries or NetCDF files.
#
# Key Functionalities:
# - `compare_values`: Safely compare values across datasets with type awareness.
# - `compare_dicts`: Deep dictionary comparison with support for special cases like
#     Cartopy projections and nested structures.
# - `Control_data_types`: A class for enforcing strict typing of variables and lists.
# - `Time_class`: A helper class to infer time resolution (monthly, hourly) from timestamps.
#
# Target Use Cases:
# - Validating input/output data structures in climate workflows.
# - Enforcing consistency in configuration dictionaries.
# - Interpreting and preprocessing temporal data.
#
#    History:
#    Version    Date       Name
#    ---------- ---------- ----
#    1.1        04.2025   Evgenii Churiulin, IMKTRO
#                         Initial realise
# -------------------------------------------------------------------
# -- Import python packages:
import json
import time
import csv
import numpy as np
import pandas as pd
import cartopy.crs as ccrs
import mimetypes
import shutil
import os

from typing import Dict, Union, Any, Type, Tuple, List, Optional, Iterable
from datetime import datetime
# -- Import user libraries:
from hereon_evasuite.log_EvaSuite import get_logger, log_function_name
logger = get_logger()


@log_function_name
def compare_values(
    ds1: Dict[str, Any],
    ds2: Dict[str, Any],
    key: str,
    skip = True,
) -> Any:
    """
    Compares a specific key's value between two datasets.

    Supports comparison for:
    - Strings
    - Lists of strings
    - 1D NumPy arrays

    Parameters:
    -----------
    ds1 : dict
        First dataset.
    ds2 : dict
        Second dataset.
    key : str
        The dictionary key to compare.
    skip : bool, default=True
        If True, skips mismatches instead of raising an error.

    Returns:
    --------
    Any
        The validated or chosen value.

    Raises:
    -------
    TypeError
        If a mismatch is found and skip is False, or unsupported types are encountered.
    """
    # -- Extract time arrays from both datasets:
    temp_ds1 = ds1[key]
    temp_ds2 = ds2[key]

    # -- Check if both are strings or lists of strings:
    if isinstance(temp_ds1, str) and isinstance(temp_ds2, str):
        if temp_ds1 == temp_ds2:
            return temp_ds1
        else:
            if skip:
                logger.info('Temp skip')
                return temp_ds1
            else:
                raise TypeError(
                    f"The values for key '{key}' are different (string)."
                    f"Dataset1: {temp_ds1}, Dataset2: {temp_ds2}"
                )

    if isinstance(temp_ds1, list) and isinstance(temp_ds2, list) and all(isinstance(item, str) for item in temp_ds1 + temp_ds2):
        if temp_ds1 == temp_ds2:
            return temp_ds1
        else:
            mismatches = [(v1, v2) for v1, v2 in zip(temp_ds1, temp_ds2) if v1 != v2]
            if mismatches:
                logger.info("Mismatches:")
                for v1, v2 in mismatches:
                    logger.info(f"Dataset1: {v1}, Dataset2: {v2}")
            raise TypeError(
                f"The values for key '{key}' are different (list of strings).")

    # -- Check if both are lists or numpy arrays (numeric or mixed types):
    if isinstance(temp_ds1, (list, np.ndarray)) and isinstance(temp_ds2, (list, np.ndarray)):
        arr1 = np.asarray(temp_ds1)
        arr2 = np.asarray(temp_ds2)
        # Round floats to 10 decimal digits
        if np.issubdtype(arr1.dtype, np.floating):
            arr1 = np.round(arr1, decimals=10)
            arr2 = np.round(arr2, decimals=10)

        if np.array_equal(arr1, arr2):
            return temp_ds1
        else:
            logger.info(f"The values for key '{key}' are different (array or list).")
            mismatches = [(v1, v2) for v1, v2 in zip(arr1, arr2) if v1 != v2]
            if mismatches:
                logger.info("Mismatches:")
                for v1, v2 in mismatches:
                    logger.info(f"Dataset1: {v1}, Dataset2: {v2}")
            raise TypeError(f"The values for key '{key}' are different (list of strings).")
    else:
        raise TypeError(f"Unsupported type for key '{key}': {type(temp_ds1)}")


@log_function_name
def compare_dicts(
    dict1: Dict[str, Any],
    dict2: Dict[str, Any],
    path: str = ""
) -> None:
    """
    Recursively compares two nested dictionaries and prints all differences.

    Handles special cases:
    ----------------------------
    - Cartopy projections (by proj4_params)
    - Python range objects
    - Nested dicts and lists

    Parameters:
    -----------
    dict1 : dict
        The reference or user dataset.
    dict2 : dict
        The default or expected dataset.
    path : str, default=""
        Internal path for tracking nested keys during recursion.

    Output:
    -------
    Prints a summary of mismatches, or confirmation if all values match.
    """
    differences = []

    def _compare(d1, d2, p):
        for key in d1.keys():
            current_path = f"{p}.{key}" if p else key

            if key not in d2:
                differences.append(f"[Missing in second] Key '{current_path}' exists only in the first dictionary.")
                continue

            val1 = d1[key]
            val2 = d2[key]

            # Handle Cartopy projections
            if isinstance(val1, ccrs.Projection) and isinstance(val2, ccrs.Projection):
                if val1.proj4_params != val2.proj4_params:
                    differences.append(
                        f"[Mismatch] {current_path}: Projection differs:\n  {val1}\n  !=\n  {val2}"
                    )
                continue

            # Handle ranges
            if isinstance(val1, range) and isinstance(val2, range):
                if list(val1) != list(val2):
                    differences.append(
                        f"[Mismatch] {current_path}: Range differs {list(val1)} != {list(val2)}"
                    )
                continue

            # Handle nested dictionaries
            if isinstance(val1, dict) and isinstance(val2, dict):
                _compare(val1, val2, current_path)
                continue

            # Handle lists
            if isinstance(val1, list) and isinstance(val2, list):
                if val1 != val2:
                    differences.append(
                        f"[Mismatch] {current_path}: List differs {val1} != {val2}"
                    )
                continue

            # Scalar comparison
            if val1 != val2:
                differences.append(f"[Mismatch] {current_path}: {val1} != {val2}")

        # Check for missing keys in the first dictionary
        for key in d2.keys():
            current_path = f"{p}.{key}" if p else key
            if key not in d1:
                differences.append(f"[Missing in first] Key '{current_path}' exists only in the second dictionary.")

    # Run the comparison
    _compare(dict1, dict2, path)

    # Report results
    if not differences:
        logger.info("Configuration is the same.")
    else:
        logger.info("Differences found:")
        for diff in differences:
            logger.info(diff)


@log_function_name
def load_rename_mapping(csv_path: str) -> Dict[str, Dict[str, Any]]:
    """User function for loading CSV data with user names:"""
    mapping = {}
    with open(csv_path, mode='r', encoding='utf-8') as csvfile:
        # Use csv.Sniffer to auto-detect the delimiter (if needed)
        sample = csvfile.read(1024)
        csvfile.seek(0)
        dialect = csv.Sniffer().sniff(sample)
        reader = csv.DictReader(csvfile, dialect=dialect)
        for row in reader:
            new_name = row['new_name']
            old_names = row['old_names'].split('|')
            long_name = row['long_name']
            mapping[new_name] = {
                'old_names': old_names,
                'long_name': long_name
            }
    return mapping


def json_report(filein: Union[dict, list], fileout: str, mode: str = 'w') -> None:
    """
    Serialize a dictionary to a JSON file, converting NumPy arrays to lists.

    Parameters
    ----------
    filein : dict[str, Any]
        The dictionary containing data to be serialized.
        Any NumPy arrays within the dictionary will be converted to Python lists.
    fileout : str
        Path to the output JSON file.
    mode : {"w", "a"}, default "w"
        File write mode:
          - "w" : overwrite if file exists.
          - "a" : append to file (generally only useful if writing valid JSON fragments).

    Raises
    ------
    TypeError
        If the data contains objects that cannot be converted to JSON
        and are not NumPy arrays.
    """
    def convert(o: Any) -> Any:
        if isinstance(o, np.ndarray):
            return o.tolist()
        raise TypeError(f"Object of type {type(o).__name__} is not JSON serializable")

    with open(fileout, mode, encoding="utf-8") as f:
        json.dump(filein, f, ensure_ascii=False, indent=4, default=convert)


def log_paths_compact(
    logger,
    obj: Any,
    *,
    header: str = "Paths",
    base: Optional[str] = None,
    max_items: Optional[int] = None,
    level: str = "info",
) -> None:
    """
    Log paths compactly by printing the common base once and then relative tails.

    Parameters
    ----------
    obj : Any
        Either:
          - list/tuple/set of str paths
          - dict[str, list[str]] (e.g. region -> paths)
    header : str
        Header label used in the log.
    base : str, optional
        If provided, use this base path instead of computing commonpath.
    max_items : int, optional
        If provided, show only first N items per list and then "... (k more)".
    level : {"debug","info","warning","error"}
        Logger level to use.
    """
    log = getattr(logger, level)

    def _flatten_paths(x: Any) -> List[str]:
        if x is None:
            return []
        if isinstance(x, (list, tuple, set)):
            return [p for p in x if isinstance(p, str)]
        if isinstance(x, dict):
            out: List[str] = []
            for v in x.values():
                if isinstance(v, (list, tuple, set)):
                    out.extend([p for p in v if isinstance(p, str)])
            return out
        return []

    all_paths = _flatten_paths(obj)
    if not all_paths:
        log("%s: (no paths)", header)
        return

    base_path = base or os.path.commonpath(all_paths)
    log("%s:", header)
    log("  Base: %s", base_path)

    def _log_list(prefix: str, paths: Iterable[str]) -> None:
        paths = list(paths)
        show = paths if max_items is None else paths[:max_items]
        for p in show:
            log("  %s%s", prefix, os.path.relpath(p, base_path))
        if max_items is not None and len(paths) > max_items:
            log("  %s... (%d more)", prefix, len(paths) - max_items)

    if isinstance(obj, dict):
        # dict: region -> list of paths
        log("  Entries: %d", len(obj))
        for key in sorted(obj.keys()):
            paths = obj.get(key, [])
            log("  - %s (%d):", key, len(paths) if isinstance(paths, list) else 0)
            _log_list("    ", paths if isinstance(paths, (list, tuple, set)) else [])
    else:
        # list of paths
        log("  Items: %d", len(all_paths))
        _log_list("  - ", all_paths)


class Control_data_types:
    """
    A utility class to validate types of variables used in configuration and data validation workflows.

    Provides:
    ----------------------------
    - Type checking for single values, lists, and nested containers
    - Flexible support for allowing None values
    - List comparison utilities for consensus extraction

    Useful for debugging or validating structured data (e.g., user input, YAML configurations).
    """
    @log_function_name
    def __init__(self) -> None:
        """Initialization: """
        pass

    def control_type4var(
        self,
        variable: Any,
        expected_type: Union[Type, Tuple[Type, Any]],
        func_name: str,
        var_name: str
    ) -> None:
        """
        Validates that a single variable is of the expected type(s).

        Parameters:
        -----------
        variable : Any
            Variable to check.
        expected_type : type or tuple of types
            Allowed types.
        func_name : str
            Calling function name.
        var_name : str
            Variable name for context.

        Raises:
        -------
        TypeError if the type does not match.
        """
        if not isinstance(variable, expected_type):
            expected_types = (
                ", ".join(t.__name__ for t in expected_type)
                if isinstance(expected_type, tuple)
                else expected_type.__name__
            )
            raise TypeError(
                f"Expected {expected_types} for variable '{var_name}' in function '{func_name}', "
                f"but got {type(variable).__name__}."
            )

    def control_types4dict(
        self,
        variables: Dict[str, Type],
        func_name: str
    ) -> None:
        """
        Validates multiple variables and their nested types using recursion.

        Parameters:
        -----------
        variables : dict
            Dictionary where each key maps to (value, expected_type, ...)
        func_name : str
            Name of the calling function.

        Raises:
        -------
        TypeError if any variable is not of the expected type(s).
        """
        def validate_type(value, expected_types, var_name, context="root"):
            """
            Recursive helper to validate nested types.
            """
            if not isinstance(value, expected_types[0]):
                expected_type_name = (
                    ", ".join(t.__name__ for t in expected_types[0])
                    if isinstance(expected_types[0], tuple)
                    else expected_types[0].__name__
                )
                raise TypeError(
                    f"Expected {expected_type_name} for '{var_name}' at {context} "
                    f"in function '{func_name}', but got {type(value).__name__}."
                )

            # If more types are specified, recursively check nested structures
            if len(expected_types) > 1 and isinstance(value, (list, tuple, set)):
                for i, item in enumerate(value):
                    validate_type(item, expected_types[1:], var_name, f"{context}[{i}]")

        for var_name, (variable, *expected_types) in variables.items():
            validate_type(variable, expected_types, var_name)

    def control_simple_list_with_none(
        self,
        variable: Any,
        var_name: str,
        allowed_types: Tuple[Type, ...],
        func_name: str,
    ) -> None:
        """
        Validates that a list contains only None or items of allowed types.

        Parameters:
        -----------
        variable : list or None
            The list to check.
        var_name : str
            Name of the variable.
        allowed_types : tuple
            Acceptable types.
        func_name : str
            Calling function name.

        Raises:
        -------
        TypeError if any item violates allowed types.
        """
        # -- Get the allowed type names for reporting:
        allowed_type_names = ", ".join(t.__name__ for t in allowed_types)

        # Allow None directly
        if variable is None:
            return  # Nothing to check

        # Check if the variable is a list
        if not isinstance(variable, list):
            raise TypeError(
                f"Expected list for '{var_name}' in function '{func_name}', "
                f"but got {type(variable).__name__}."
            )

        # Validate each element in the list
        for i, item in enumerate(variable):
            if item is not None and not isinstance(item, allowed_types):
                raise TypeError(
                    f"Invalid type for element at index {i} in '{var_name}' in function '{func_name}'. "
                    f"Expected one of (None, {allowed_type_names}), but got {type(item).__name__}."
                )

    def control_dict_with_none(
        self,
        variable: Any,
        var_name: str,
        allowed_value_types: Tuple[Type, ...],
        func_name: str,
    ) -> None:
        """
        Validates that a dictionary contains string keys and values that are either None or of allowed types.

        Parameters:
        -----------
        variable : dict or None
            The dictionary to check.
        var_name : str
            Name of the variable.
        allowed_value_types : tuple
            Acceptable types for the dictionary values.
        func_name : str
            Calling function name.

        Raises:
        -------
        TypeError if the variable is not None or a dict, or if any key/value violates the constraints.
        """
        allowed_type_names = ", ".join(t.__name__ for t in allowed_value_types)

        if variable is None:
            return  # Acceptable

        if not isinstance(variable, dict):
            raise TypeError(
                f"Expected dict for '{var_name}' in function '{func_name}', "
                f"but got {type(variable).__name__}."
            )

        for k, v in variable.items():
            if not isinstance(k, str):
                raise TypeError(
                    f"Invalid key type in '{var_name}' in function '{func_name}'. "
                    f"Expected str, but got {type(k).__name__}."
                )
            if v is not None and not isinstance(v, allowed_value_types):
                raise TypeError(
                    f"Invalid value type for key '{k}' in '{var_name}' in function '{func_name}'. "
                    f"Expected one of (None, {allowed_type_names}), but got {type(v).__name__}."
                )

    def control_simple_value(
        self,
        variable: Any,
        var_name: str,
        allowed_types: Tuple[Type, ...],
        func_name: str,
    ) -> None:
        """
        Validates that a variable is either None or of allowed types.

        Parameters:
        -----------
        variable : Any
            Variable to check.
        var_name : str
            Variable name.
        allowed_types : tuple
            Allowed type(s).
        func_name : str
            Caller function.

        Raises:
        -------
        TypeError if variable is of an invalid type.
        """
        allowed_type_names = ", ".join(t.__name__ for t in allowed_types)

        if variable is not None and not isinstance(variable, allowed_types):
            raise TypeError(
                f"Invalid type for '{var_name}' in function '{func_name}'. "
                f"Expected one of (None, {allowed_type_names}), but got {type(variable).__name__}."
            )

    @log_function_name
    def compare_values_in_list(self, lst4compare) -> list[Any]:
        """
        Compares multiple lists and returns either the last one (if identical),
        or all lists if they differ.

        Parameters:
        -----------
        lst4compare : list of lists
            Lists to compare.

        Returns:
        --------
        list
            The final list to retain.
        """
        if all(t_list == lst4compare[0] for t_list in lst4compare):
            # Keep only the last one
            final_list = lst4compare[-1]
        else:
            # Keep all if they are different
            final_list = lst4compare
        return final_list


class Time_class:
    """
    A helper class to analyze time-related data, especially to infer the time interval
    (monthly, hourly) from a sequence of timestamp strings or pandas Timestamps.

    Methods:
    --------
    - get_time_interval: Determines if time series is monthly, hourly, or irregular.
    """
    @log_function_name
    def __init__(self) -> None:
        """Initialization"""
        pass

    @log_function_name
    def get_time_interval(self, time_stamps: List[str]) -> str:
        """
        Infers time resolution (monthly or hourly) based on input timestamps.

        Parameters:
        -----------
        time_stamps : list of str or pd.Timestamp
            List of time values in string or Timestamp format.

        Returns:
        --------
        str
            Suggested date format string (e.g., '%Y-%m-%d' or '%H').

        Notes:
        ------
        Also prints an info message describing the detected interval.
        """
        # -- Ensure time_stamps is a list of datetime objects:
        if isinstance(time_stamps, pd.DatetimeIndex):
            time_stamps = time_stamps.tolist()  # Convert DatetimeIndex to list of Timestamps

        # -- Convert timestamps to string format if necessary:
        time_stamps = [
            ts.strftime('%Y-%m-%d %H:%M:%S') if isinstance(ts, pd.Timestamp)
            else str(ts)
            for ts in time_stamps
        ]

        # -- Convert to datetime objects:
        dates = [datetime.strptime(ts, '%Y-%m-%d %H:%M:%S') for ts in time_stamps]

        # -- Compute time differences in days and hours:
        differences = np.diff(dates)
        differences_days = [diff.days for diff in differences]
        differences_hours = [diff.total_seconds() / 3600 for diff in differences]

        # -- Detect monthly data: all differences should be around 28-31 days:
        is_monthly = all(28 <= diff <= 31 for diff in differences_days)

        # -- Detect hourly data: all differences should be exactly 1 hour:
        is_hourly = all(diff == 1 for diff in differences_hours)

        # -- Print result:
        if is_monthly:
            logger.info("The data represents monthly time steps.")
            time_stamps_format = '%Y-%m-%d'
        elif is_hourly:
            logger.info("The data represents hourly time steps.")
            time_stamps_format = '%H'
        else:
            logger.info("The data does not fit strict monthly or hourly intervals.")
            time_stamps_format = '%Y-%m-%d'
        return time_stamps_format


class PathClassifier:
    def __init__(self) -> None:
        """Initialization: """
        logger.info("Support functions were activated ")

    @log_function_name
    def _time_for_sleep(self, sec: int) -> None:
        """Take a small pausa"""
        time.sleep(sec)

    @log_function_name
    def _get_list(self, paht: str) -> List[str]:
        """
        Get a list of all file paths in the specified directory.

        Args:
        ----------------------------
            path (str): The path to the directory to scan.

        Returns:
        ----------------------------
            List[str]: A list of full file paths for all files in the directory.
        """
        file_list = [
            os.path.join(paht, f)
            for f in os.listdir(paht)
            if os.path.isfile(os.path.join(paht, f))
        ]
        return file_list

    @log_function_name
    def _create_output_path(self, input_paths: List[str]) -> str:
        """
            Create output path by detecting 'DataMining' in the path and returning
            the parent folder of its parent. This ensures the visualization output
            goes to the project root (e.g., /.../test or /.../evasuite_out/...).
        """
        if not input_paths:
            raise ValueError("No input paths provided.")

        # -- Get the common path:
        comm_path = os.path.commonpath(input_paths)
        path_parts = comm_path.split("/")
        # -- Find 'DataMining' in path:
        if "DataMining" in path_parts:
            # -- Get index of 'evasuite_out':
            idx = path_parts.index('DataMining')
            if idx == 0:
                raise ValueError("Invalid path structure: 'DataMining' found at root")
            base_path_out = os.sep.join(path_parts[:idx])
        else:
            # -- Fallback to the common path:
            base_path_out = comm_path
        return base_path_out

    @log_function_name
    def _check_files(self, path: str) -> bool:
        """Checks if a file is a valid NetCDF. If not, move it and return False."""
        if "WP03" in path:
            mime, _ = mimetypes.guess_type(path)
            if mime not in {"application/x-netcdf", "application/netcdf"} and not path.endswith((".nc", ".nc4")):
                logger.info("Skipping non-NetCDF file from WP03 folder.")
                # Determine target directory: one level above
                current_dir = os.path.dirname(path)
                parent_dir = os.path.dirname(current_dir)
                target_dir = os.path.join(parent_dir, "NonNetCDF_Skipped")
                os.makedirs(target_dir, exist_ok=True)

                # Move file
                target_path = os.path.join(target_dir, os.path.basename(path))
                shutil.move(path, target_path)
                logger.warning(f"rename_nc: Moved non-NetCDF file to: {target_path}")
                return False
        return True

    @log_function_name
    def _classify_paths(self, valid_paths: list[str]) -> Tuple[List[str], List[str]]:
        """Classify NetCDF file paths into full-domain and sub-domain categories."""
        if not isinstance(valid_paths, list) or not all(isinstance(p, str) for p in valid_paths):
            raise TypeError("'valid_paths' must be a list of strings.")
        if not valid_paths:
            raise ValueError("No valid paths provided")

        # -- Initialization of lists:
        full_domain_files: List[str] = []
        sub_domain_files: List[str] = []

        for path in valid_paths:
            fname = os.path.basename(path)

            if "WP03" in path:
                if fname.endswith("_CondenseDimensions.nc"):
                    full_domain_files.append(path)
                elif (
                    fname.endswith(".nc") and
                    not fname.endswith("_EvalFrequency.nc") and
                    not fname.endswith("_CondenseDimensions.nc")
                ):
                    sub_domain_files.append(path)

            elif "WP04" in path:
                if fname.endswith("T.nc"):
                    full_domain_files.append(path)
                else:
                    sub_domain_files.append(path)

            else:
                logger.error(f"Unrecognized path structure: {path}")
                raise ValueError("Unknown path attribute: WP03 or WP04 not found in path.")

        logger.info(f"Processed {len(valid_paths)} paths")
        logger.info(f" - Full-domain files: {len(full_domain_files)}")
        logger.info(f" - Sub-domain files:  {len(sub_domain_files)}")

        return full_domain_files, sub_domain_files

    def split_subdomain_paths_by_surface(
        self,
        sub_domain_files: List[str],
    ) -> Dict[str, List[str]]:
        """
        Split sub-domain NetCDF paths into surface-based groups.

        Groups
        ------
        norm : paths without '_lnd' or '_sea'
        land : paths ending with '_lnd'
        sea  : paths ending with '_sea'

        Parameters
        ----------
        sub_domain_files : list of str
            List of sub-domain NetCDF file paths.

        Returns
        -------
        dict
            Dictionary with keys: 'norm', 'land', 'sea'
        """
        grouped = {
            "norm": [],
            "land": [],
            "sea": [],
        }

        for path in sub_domain_files:
            name = os.path.basename(path)

            # extract region token (second-to-last dot-separated part)
            # e.g. tas.CompareRAW....P_France_lnd.nc → P_France_lnd
            region = name.split(".")[-2]

            if region.endswith("_lnd"):
                grouped["land"].append(path)
            elif region.endswith("_sea"):
                grouped["sea"].append(path)
            else:
                grouped["norm"].append(path)

        return grouped
