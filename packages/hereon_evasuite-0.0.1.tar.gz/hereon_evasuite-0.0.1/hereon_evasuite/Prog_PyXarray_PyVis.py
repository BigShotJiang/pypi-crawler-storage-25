# EvaSuite
#
# ---------------------------------------------------------------
# Copyright (C) 2004-2025, Hereon
# Contact information: beate.geyer@hereon.de, imktro-climate-modelling@lists.kit.edu
# See AUTHORS.TXT for a list of authors
# See LICENSES/ for license information
# SPDX-License-Identifier: Apache-2.0
# ---------------------------------------------------------------

# -- Program classes for the Evaluation Suite
# -- Import Python modules:
import pandas as pd
import numpy as np
import xarray as xr
import matplotlib
import matplotlib.ticker  # here's where the formatter is
from typing import Any, Optional, Dict, List, Union, Tuple, Callable

# -- Import EvaSuite modules:
from hereon_evasuite.GeneralUtils import SuiteUtilities
from hereon_evasuite.log_EvaSuite import get_logger, log_function_name
from hereon_evasuite.aggreg_utils import AggregationSupport
matplotlib.use('Agg')

GenUti = SuiteUtilities()
logger = get_logger()


# -- Start:
class ProgPy(object):
    @log_function_name
    def __init__(
        self: 'ProgPy',
        name: str,
        cfgprogram: Dict[str, str],
        eval_suite_wdir: Optional[str] = None,
    ) -> None:
        """Initialization of Prog_PyXarray_PyVis. Program doesn't have return variables,
           but save data as a self.variable
        """
        self.name = name
        self.EVAL_suite_workdir = eval_suite_wdir
        self.cfgprogram = cfgprogram

        # -- Initialization of help aggregation class:
        self.ags = AggregationSupport()

        logger.debug(f"Program instance: {self.name}")

    @log_function_name
    def getName(self: 'ProgPy') -> str:
        """Getter of Name: """
        return self.name

    @log_function_name
    def getExec(self: 'ProgPy') -> None:
        """Getter of getExec: """
        return None


class PyXarray(ProgPy):
    @log_function_name
    def __init__(
        self: 'PyXarray',
        cfgprogram: Dict[str, str],
        eval_suite_wdir: Optional[str] = None,
    ) -> None:
        """Initialization """
        # -- Set a deligation rules for PyXarray class:
        super().__init__("PyXarray", cfgprogram, eval_suite_wdir)
        self.chunking = cfgprogram["chunking"] if cfgprogram["chunking"] is not None else False

    @log_function_name
    def RetainVarAttrs(
        self: 'PyXarray',
        oldds: xr.Dataset,
        newds: xr.Dataset,
        varswithattr: Optional[List[str]] = None,
        varsprot: Optional[Any] = None,
    ) -> xr.Dataset:
        """
        Restores variable attributes and optionally missing variables from an old xarray Dataset
        to a new one, typically after transformations that discard metadata (e.g., aggregation).

        This function is useful when operations like groupby, mean, or resampling
        strip variable-level metadata or drop some auxiliary variables.

        Parameters:
        ---------------
            oldds (xr.Dataset):
                The original dataset containing full metadata and variables.
            newds (xr.Dataset):
                The modified dataset possibly missing attributes or variables.
            varswithattr (Optional[List[str]], default=None):
                A list of variable names for which attributes should be restored
                from `oldds` to `newds`.
            varsprot (Optional[Any], default=None):
                A list or dict_keys-like iterable of variable names that should be
                retained (copied) from `oldds` to `newds` if they are missing.

        Returns:
        ---------------
            xr.Dataset:
                The updated dataset with restored attributes and/or protected variables.

        Notes:
        ---------------
            - Variables listed in `varsprot` that are coordinates in `oldds` will be
              re-added as coordinates in `newds`.
            - If both `varswithattr` and `varsprot` are None or empty, the original
              `newds` is returned unchanged.
        """
        if (not varswithattr) and (not varsprot):
            # -- Hopefully not none:
            return newds

        if varswithattr:
            for varname in varswithattr:
                for attribute, value in oldds[varname].attrs.items():
                    newds[varname].attrs[attribute] = value
        #
        if varsprot:
            for varname in varsprot:
                try:
                    newds[varname]
                except KeyError:
                    newds[varname] = oldds[varname]
                    # -- Dirty fix for COSMO-CLM to get copied the rotated pole
                    if varname in oldds.coords:
                        newds = newds.set_coords(names = varname)
        return newds

    @log_function_name
    def FindVarName(
        self: 'PyXarray',
        datafile: str,
        varnamelist: List[str],
    ) -> Tuple[List[str], List[str]]:
        """
        Identifies which variables from a given list are present as data variables
        in a NetCDF file.

        This function opens the dataset and compares the provided `varnamelist`
        against the dataset's `data_vars`. It returns both the intersection and the full list
        of data variables found in the file.

        Parameters:
        ------------
            datafile (str):
                Path to the NetCDF dataset to inspect.
            varnamelist (List[str]):
                List of variable names to check for presence in the dataset.

        Returns:
        ------------
            Tuple[List[str], List[str]]:
                - A list of variable names from `varnamelist` that are present in the dataset.
                - A list of all data variables in the file (`filedat.data_vars`).

        Notes:
        ------------
            - The dataset is opened with `decode_cf=False`, `decode_times=False`,
              and `decode_timedelta=False` to avoid automatic decoding.
            - Only data variables (`data_vars`) are considered, not coordinates or attributes.
        """
        with xr.open_dataset(
            datafile, decode_cf = False, decode_times = False, decode_timedelta = False,
        ) as filedat:
            varsinfile = list(filedat.data_vars)
        return list(set(varnamelist).intersection(set(varsinfile))), varsinfile

    @log_function_name
    def AllVarNamesRelevant(
        self: 'PyXarray',
        datafile: str,
        varnamelist: List[str],
    ) -> bool:
        """
        Checks whether all data variables in a NetCDF file are included in a given list of variable names.

        This function compares the dataset's `data_vars` to the provided `varnamelist`,
        and returns True only if all variables in the file are present in the list.

        Parameters:
            datafile (str):
                Path to the NetCDF dataset to check.
            varnamelist (List[str]):
                List of variable names considered relevant.

        Returns:
            bool:
                True if all variables in the dataset are in `varnamelist`;
                False otherwise.

        Notes:
            - The dataset is opened with decoding disabled (`decode_cf=False`, etc.).
            - Only `data_vars` are considered — coordinate variables are ignored.
            - This function does not check if all `varnamelist` entries exist in the file,
              only that all file variables are accounted for in the list.
        """
        with xr.open_dataset(
            datafile, decode_cf = False, decode_times = False, decode_timedelta = False,
        ) as filedat:
            varsinfile = list(filedat.data_vars)
        return len(varnamelist) == len(list(set(varnamelist).intersection(set(varsinfile))))

    @log_function_name
    def ExtractLevInfoFromNC(
        self: 'PyXarray',
        vert_gridtype = None,
        ncfile = None,
        varlist = None,
        coord3D = False,
    ):
        """ Extract information about vertical levels and return a dictionary
            with lists for each eval parameter:
        """
        logger.warning(
            "EvaSuite Warning: You are using an untested function.\n"
            "If possible, please send your configuration files to: "
            "evgenii.churiulin@kit.edu for testing and validation support."
        )
        zlevelbib = None
        if (vert_gridtype == 'height'):
            zlevelbib, coord3Dbib = {}, {}
            LevelsNC = xr.open_dataset(ncfile)
            for var in varlist:
                zlevels = None
                coordvars = list(LevelsNC[var].coords.keys())
                coordinEncAttrs = GenUti.safe_access_bib(
                    " ",
                    KeyError,
                    LevelsNC[var].encoding,
                    'coordinates',
                    errhandle = False,
                )
                coordinAttrs = GenUti.safe_access_bib(
                    " ",
                    KeyError,
                    LevelsNC[var].attrs,
                    'coordinates',
                    errhandle = False,
                )

                if coordvars:
                    if "z" in coordvars:
                        zlevels = LevelsNC["z"].data
                        coord3Dbib.update({var: "z"})
                    else:
                        findheight = GenUti.search_substring_list(
                            strlist = coordvars,
                            substr = "height",
                        )
                        if findheight:
                            # -- Only one match should occur for height in dims:
                            zlevels = LevelsNC[findheight[0]].data
                            coord3Dbib.update({var: findheight[0]})

                if zlevels is None and coordinEncAttrs:
                    coord3Dbib.update({var: None})
                    if "z" in coordinEncAttrs.split(" "):
                        zlevels = LevelsNC["z"].data
                    else:
                        findheight = GenUti.search_substring_list(
                            strlist = coordinEncAttrs.split(" "),
                            substr = "height"
                        )
                        if findheight:
                            # -- Only one match should occur for height in dims:
                            zlevels = LevelsNC[findheight[0]].data

                elif coordinAttrs:
                    coord3Dbib.update({var: None})
                    if "z" in coordinAttrs.split(" "):
                        zlevels = LevelsNC["z"].data
                    else:
                        findheight = GenUti.search_substring_list(
                            strlist = coordinAttrs.split(" "),
                            substr = "height",
                        )
                        if findheight:
                            # -- Only one match should occur for height in dims:
                            zlevels = LevelsNC[findheight[0]].data

                if zlevels is None:
                    logger.warning(
                        f"Found no height level information for variable {var}."
                        f" --> Exit program")
                else:
                    zlevels = np.array(zlevels)
                zlevelbib.update({var: zlevels})

        if coord3D:
            return zlevelbib, coord3Dbib
        else:
            return zlevelbib

    @log_function_name
    def FindDimsCoordsOfVariables(
        self: 'PyXarray',
        varnamelist: List[str],
        mode: str,
        datafile: Optional[str] = None,
        dataset: Optional[xr.Dataset] = None,
    ) -> Dict[str, List[str]]:
        """
        Finds the dimension or coordinate names associated with a list of variables
        in a given xarray Dataset.

        Depending on the specified `mode`, the function returns either:
        ------------
        - a list of dimension names (`mode="dims"`), or
        - a list of coordinate names (`mode="coords"`)
        for each variable in `varnamelist`.

        Parameters:
        ------------
            varnamelist (List[str]):
                A list of variable names to inspect.
            mode (str):
                Either "dims" or "coords" to specify which attribute to retrieve.
            datafile (Optional[str], default=None):
                Path to the NetCDF file to open, if a dataset is not already provided.
            dataset (Optional[xr.Dataset], default=None):
                An already opened xarray Dataset. Used if `datafile` is not provided.

        Returns:
        ------------
            Dict[str, List[str]]:
                A dictionary mapping each variable name to its corresponding list of
                dimensions or coordinates, depending on the mode.

        Raises:
        ------------
            ValueError: If neither `datafile` nor `dataset` is provided.
            KeyError: If any variable in `varnamelist` is not found in the dataset.
        """
        if mode not in {'dims', 'coords'}:
            logger.error("Invalid mode '%s'. Expected 'dims' or 'coords'.", mode)
            raise ValueError("Invalid mode: choose 'dims' or 'coords'.")

        def _extract(ds: xr.Dataset) -> Dict[str, List[str]]:
            valid_vars = set(varnamelist).intersection(ds.data_vars)
            return {
                var: list(ds[var].dims) if mode == 'dims' else list(ds[var].coords)
                for var in valid_vars
            }

        try:
            if dataset is not None:
                return _extract(dataset)

            if datafile is not None:
                with xr.open_dataset(datafile) as ds:
                    return _extract(ds)
            raise ValueError("No dataset or datafile provided.")
        except Exception as e:
            logger.error(
                "FindDimsCoordsOfVariables encountered an error. mode=%s, file=%s, dataset=%s\nException: %s",
                mode, datafile, dataset is not None, str(e), exc_info=True
            )
            raise

    @log_function_name
    def HarmonizeHoriGrid(
        self: 'PyXarray',
        dsetref: xr.Dataset,
        dsetmod: xr.Dataset,
        posdimnames: Dict[str, List[str]],
        varnsref: List[str],
        varnsmod: List[str],
    ) -> xr.Dataset:
        """
        Harmonizes the horizontal coordinate grid of a model dataset (`dsetmod`)
        by replacing its spatial coordinates with those from a reference dataset (`dsetref`).

        This is necessary when datasets differ slightly in grid definitions (e.g., coordinate
        dtype, precision, or naming mismatches), which can cause downstream processing errors.

        For each variable listed in `varnsmod`, the function replaces the horizontal coordinate
        values (e.g., `lon`, `lat`) with those from the corresponding variable in `dsetref`.

        Parameters:
        --------------
            dsetref (xr.Dataset):
                Reference dataset containing the correct horizontal coordinate grid.
            dsetmod (xr.Dataset):
                Model dataset to be updated with harmonized coordinates.
            posdimnames (Dict[str, List[str]]):
                Dictionary mapping variable names to their horizontal dimension names
                (e.g., {"tas": ["lon", "lat"]}).
            varnsref (List[str]):
                List of variable names from the reference dataset.
            varnsmod (List[str]):
                List of variable names from the model dataset (to harmonize).

        Returns:
        --------------
            xr.Dataset:
                A copy of the model dataset (`dsetmod`) with updated horizontal coordinates
                taken from the reference dataset (`dsetref`).

        Notes:
        --------------
            - The function assumes that variable names in `varnsmod` correspond positionally
              to those in `varnsref`.
            - Coordinate dimension names must match between datasets.
            - The actual grid alignment (e.g., shape, extent) is assumed compatible and is
              not checked explicitly.
            - If dimension names differ (e.g. `lon1` vs `lon`), this must be handled upstream.
        """
        logger.debug("Harmonization of horizontal grids prior evaluation.")

        CoordInfref = self.FindDimsCoordsOfVariables(
            varnamelist = varnsref, mode = 'coords', dataset = dsetref,
        )
        CoordInfmod = self.FindDimsCoordsOfVariables(
            varnamelist = varnsmod, mode = 'coords', dataset = dsetmod,
        )
        dim_xyref = GenUti.SplitMetaDim(
            CoordInfref, mode = 'spatial', PossibleDimDict = posdimnames)
        dim_xymod = GenUti.SplitMetaDim(
            CoordInfmod, mode = 'spatial', PossibleDimDict = posdimnames)
        #
        logger.debug(f"List of dimensions in reference dataset: {dim_xyref}")
        logger.debug(f"List of dimensions in reference dataset: {dim_xymod}")

        try:
            dsetmod = dsetmod.reindex_like(
                dsetref, method = 'nearest', tolerance = 0.001)
        except:
            raise Exception(
                "The harmonization between reference data and proof data "
                "was not successful --> Stop"
            )

        # -- Harmonize the type of rotated_pole:
        if ("rotated_pole" in dsetmod.data_vars) and ("rotated_pole" in dsetref.data_vars):
            dsetmod["rotated_pole"] = dsetref["rotated_pole"]

        # -- Return the model dataset with harmonized dimensions
        return dsetmod

    @log_function_name
    def HarmonizeTempGrid(
        self: 'PyXarray',
        dsetref: xr.Dataset,
        dsetmod: xr.Dataset,
        posdimnames: Dict[str, List[str]],
        varnsref: List[str],
        varnsmod: List[str],
        unifreqme: str,
    ) -> Tuple[xr.Dataset, xr.Dataset]:
        """
        Harmonizes the time coordinate of a model dataset (`dsetmod`) by copying the time values
        from a reference dataset (`dsetref`), typically to address inconsistencies in time formats,
        precision, or encoding.

        This is particularly useful when comparing or merging datasets where time coordinates are
        slightly mismatched due to format differences, even if they appear aligned visually.

        Parameters:
        --------------
            dsetref (xr.Dataset):
                The reference dataset providing the correct time coordinate values.
            dsetmod (xr.Dataset):
                The model dataset whose time coordinate will be replaced.
            posdimnames (Dict[str, List[str]]):
                Dictionary specifying recognized dimension types, e.g.:
                {
                    'spatial': ['lon', 'lat', 'X', 'Y'],
                    'time': ['time'],
                    'vertical': ['level', 'height']
                }
            varnsref (List[str]):
                List of variable names in the reference dataset to use for time alignment.
            varnsmod (List[str]):
                Corresponding variable names in the model dataset to align.
            unifreqme (str):
                Method used to unify frequency or handle time alignment, e.g. "resample".

        Returns:
        --------------
            Tuple[xr.Dataset, xr.Dataset]:
                - The modified model dataset with harmonized time coordinates.
                - The reference dataset (unchanged).

        Notes:
        --------------
            - The function assumes that `varnsref` and `varnsmod` correspond positionally.
            - This does not perform interpolation; it simply replaces or aligns time coordinate values.
            - If `unifreqme == "resample"`, it is assumed that frequency adjustment has already been applied.
            - Both input datasets must already be opened (i.e., passed as xarray.Dataset objects).
        """
        DimInfref = self.FindDimsCoordsOfVariables(
            varnamelist = varnsref, mode = 'dims', dataset = dsetref,
        )
        DimInfmod = self.FindDimsCoordsOfVariables(
            varnamelist = varnsmod, mode = 'dims', dataset = dsetmod,
        )

        dim_tref = GenUti.SplitMetaDim(
            DimInfref, mode = 'temporal', PossibleDimDict = posdimnames)
        dim_tmod = GenUti.SplitMetaDim(
            DimInfmod, mode = 'temporal', PossibleDimDict = posdimnames)
        #
        for varmod, varref in zip(varnsmod, varnsref):
            if varref in dim_tref.keys() and varmod in dim_tmod.keys():
                for dimes in dim_tref[varref]:
                    if dimes in dim_tmod[varmod]:
                        #
                        helpstr = (
                            f"Found for the variable {varref} the temp. "
                            f"dimension {dimes} in reference dataset and an equivalent "
                            f"in dataset to evaluate: {varmod}, {dimes}. -> Make datatype "
                            f"consistent depending on unifyfreqmethod {unifreqme}"
                        )
                        if unifreqme == "reselect":
                            logger.debug(helpstr)
                            timediff = (
                                np.max(dsetmod[dimes].data - dsetref[dimes].data)
                            )
                            timediff = timediff / np.timedelta64(1, 's')

                            if np.abs(int(timediff)) > 1:
                                logger.warning(
                                    f"The two datasets do not share the same "
                                    f"time-axis. Maximum difference is {timediff} seconds"
                                )
                            dsetmod[dimes] = dsetmod[dimes].copy(data = dsetref[dimes].data)

                        elif (unifreqme == "resample" and
                                (np.size(dsetref[dimes]) != np.size(dsetmod[dimes]))):
                            logger.debug(helpstr)
                            inters = pd.to_datetime(dsetref[dimes].data)
                            inters = inters.intersection(pd.to_datetime(dsetmod[dimes].data))
                            dsetmod = dsetmod.sel(time = inters, method = 'nearest')
                            dsetref = dsetref.sel(time = inters, method = 'nearest')
                            timediff = (
                                np.max(dsetmod[dimes].data - dsetref[dimes].data)
                            )
                            timediff = timediff / np.timedelta64(1, 's')
                            if np.abs(int(timediff)) > 1:
                                logger.warning(
                                    f"The two harmonized datasets still do not "
                                    f"share time axis. Max diff is {timediff} seconds"
                                )
                                dsetmod[dimes] = dsetmod[dimes].copy(data = dsetref[dimes].data)
                        else:
                            logger.debug("No harmonization needed here.")
        return dsetmod, dsetref

    @log_function_name
    def HarmonizeVertGrid(
        self: 'PyXarray',
        dsetref: xr.Dataset,
        dsetmod: xr.Dataset,
        posdimnames: Dict[str, List[str]],
        varnsref: List[str],
        varnsmod: List[str],
    ) -> Tuple[xr.Dataset, xr.Dataset]:
        """
        Harmonizes the vertical coordinate (e.g., height or level) of a model dataset (`dsetmod`)
        by adapting it to match the vertical structure of a reference dataset (`dsetref`).

        This is necessary when vertical dimension names or values differ between datasets,
        even if the underlying variable represents the same physical quantity.

        Parameters:
        --------------
            dsetref (xr.Dataset):
                The reference dataset providing the correct vertical coordinate.
            dsetmod (xr.Dataset):
                The model dataset to be modified.
            posdimnames (Dict[str, List[str]]):
                Dictionary specifying recognized dimension types, for example:
                {
                    'spatial': ['lon', 'lat', 'X', 'Y'],
                    'time': ['time'],
                    'vertical': ['level', 'height']
                }
            varnsref (List[str]):
                List of variable names in the reference dataset.
            varnsmod (List[str]):
                Corresponding variable names in the model dataset.

        Returns:
        --------------
            Tuple[xr.Dataset, xr.Dataset]:
                - The updated model dataset with harmonized vertical coordinates.
                - The reference dataset (unchanged).

        Notes:
        --------------
            - The function assumes that variables in `varnsref` and `varnsmod` correspond
              by position and represent the same field.
            - Vertical coordinate names may differ (e.g., `level` vs. `height`), and are
              handled based on `posdimnames`.
            - The input datasets must already be loaded as xarray.Dataset objects.
            - This function does not resample or interpolate vertical levels — it assumes
              the reference grid is authoritative and simply copies structure or metadata.
        """
        logger.debug("Harmonization of vertical grids prior evaluation.")
        DimInfref = self.FindDimsCoordsOfVariables(
            varnamelist = varnsref, mode = 'dims', dataset = dsetref,
        )
        DimInfmod = self.FindDimsCoordsOfVariables(
            varnamelist = varnsmod, mode = 'dims', dataset = dsetmod,
        )
        dim_zref = GenUti.SplitMetaDim(
            DimInfref, mode = 'vertical', PossibleDimDict = posdimnames)
        dim_zmod = GenUti.SplitMetaDim(
            DimInfmod, mode = 'vertical', PossibleDimDict = posdimnames)

        for varref, varmod in zip(varnsref, varnsmod):
            if (dim_zref[varref] and dim_zmod[varmod]):
                logger.debug(
                    f"here we have to modify vert. coord. of {varref} {varmod}")

                if len(dim_zref[varref]) == 1 and len(dim_zmod[varmod]) == 1:
                    dsetmod = dsetmod.rename(
                        {dim_zmod[varmod][0]: f"height_{varref}"})
                    dsetref = dsetref.rename(
                        {dim_zref[varref][0]: f"height_{varref}"})
                else:
                    logger.error(
                        f"Many vertical dimensions found for the variable {varref} or {varmod}")
                    logger.error(dsetmod[varref])
                    logger.error(dsetmod[varmod])
                    raise RuntimeError(
                        f"Multiple vertical dimensions detected for {varref} or {varmod}. "
                        "Ensure only one vertical dimension is present."
                    )
            else:
                logger.debug(
                    f"No vertical dimensions found for the "
                    f"variable {varref} or {varmod}")
        return dsetmod, dsetref

    @log_function_name
    def ReselectOP(
        self,
        dsetpr: xr.Dataset,
        varpr: str,
        dsetref: xr.Dataset,
        varref: str,
        tolerance: Optional[Union[str, np.timedelta64, pd.Timedelta]] = None,
        tbnd_match: str = "end",
    ) -> xr.DataArray:
        """
        Align a variable from a model dataset (`dsetpr`) to match the time axis of a reference dataset (`dsetref`).

        Handles both instantaneous and time-bounded data, based on presence of 'time_bnds' and
        `cell_methods` attributes. Supports matching using exact times, nearest within tolerance,
        and bounded interval checks for validity.

        Parameters
        ----------
        dsetpr : xr.Dataset
            Dataset containing the model or input data to be reselected.

        varpr : str
            Variable name in `dsetpr` to extract and align.

        dsetref : xr.Dataset
            Reference dataset with the desired target time axis.

        varref : str
            Variable name in `dsetref` used to infer bounding and time properties.

        tolerance : str | np.timedelta64 | pd.Timedelta, optional
            Time matching tolerance for nearest neighbor selection (e.g., '15min').
            This limits how far off a match can be.

        tbnd_match : {"end", "center"}, default "end"
            When time bounds are present, determines which part of the interval to align to:
            - "end": Use the end time of the interval.
            - "center": Use the midpoint of the interval.

        Returns
        -------
        xr.DataArray
            Data from `dsetpr[varpr]`, aligned in time to `dsetref[varref]`.

        Raises
        ------
        RuntimeError
            - If time matching fails due to tolerance limits.
            - If bounds logic is violated (e.g., data outside reference bounds).
            - If the time axis combination is unsupported.

        Logging
        -------
        Logs debug and informational messages (useful for diagnosing alignment behavior), including:
            - Dataset shape and time range.
            - Case detection logic.
            - Matching strategy and success.
            - Errors in bound mismatches or selection issues.

        Notes
        -----
        This function supports four alignment cases:
            1. Instantaneous vs Instantaneous
            2. Bounded vs Instantaneous
            3. Bounded vs Bounded
            4. Instantaneous vs Bounded

        For bounded data, both `time_bnds` and a valid `cell_methods` attribute ("mean" or "sum") are required.

        """
        bounds_tol = np.timedelta64(1, "us")
        time_bnds_name = "time_bnds"
        cell_method_attr = "cell_methods"

        def is_bounded(ds: xr.Dataset, var: str) -> bool:
            cm = ds[var].attrs.get(cell_method_attr, "")
            return (time_bnds_name in ds.data_vars) and any(m in cm for m in ["mean", "sum"])

        def tbnd_matching(tb: xr.DataArray, mode: str) -> xr.DataArray:
            return tb[:, 0] + (tb[:, 1] - tb[:, 0]) / 2 if mode == "center" else tb[:, 1]

        def match_by_time(ds: xr.Dataset, ref_time: xr.DataArray, tol) -> xr.Dataset:
            return ds.sel(time=ref_time, method="nearest", tolerance=tol)

        def check_within_bounds(t: np.ndarray, tb0: np.ndarray, tb1: np.ndarray, tol_ns: np.timedelta64) -> bool:
            return bool(np.all((tb0 - tol_ns <= t) & (t <= tb1 + tol_ns)))

        # --- Parse tolerance ---
        if isinstance(tolerance, str):
            tolerance = pd.to_timedelta(tolerance)

        pr_bounded = is_bounded(dsetpr, varpr)
        ref_bounded = is_bounded(dsetref, varref)

        # --- Dataset info ---
        logger.debug(
            "\n---- ReselectOP: Initial Dataset Check ----\n"
            "Metainformation about dsetpr: \n"
            f"dsetpr dims: {dict(dsetpr.dims)}, variable: {varpr}, shape: {dsetpr[varpr].shape}\n"
            f"dsetpr time range: {dsetpr['time'].values[0]} → {dsetpr['time'].values[-1]}\n"
            "Metainformation about dsetref: \n"
            f"dsetref dims: {dict(dsetref.dims)}, variable: {varref}, shape: {dsetref[varref].shape}\n"
            f"dsetref time range: {dsetref['time'].values[0]} → {dsetref['time'].values[-1]}\n"
            f"Bounded check → dsetpr: {is_bounded(dsetpr, varpr)}, dsetref: {is_bounded(dsetref, varref)}\n"
            f"Parsed tolerance: {tolerance} ({type(tolerance)})\n"
            f"Case Detection: pr_bounded={pr_bounded}, ref_bounded={ref_bounded}\n"
            "---------------------------------------------\n"
        )

        if not pr_bounded and not ref_bounded:
            logger.info("Case 1: Instantaneous vs Instantaneous")
            result = match_by_time(dsetpr, dsetref["time"], tolerance)
            result["time"] = dsetref["time"]
            logger.info(f"Matched {len(result['time'])} timesteps")
            return result[varpr]

        elif pr_bounded and not ref_bounded:
            logger.info("Case 2: Bounded data vs Instantaneous reference")
            dpr = dsetpr.copy()
            dpr["time"] = tbnd_matching(dpr[time_bnds_name], tbnd_match)
            dpr["savetime"] = dsetpr["time"]
            logger.info(f"Bounded times (data) matched using '{tbnd_match}' of bounds")

            dsel = match_by_time(dpr, dsetref["time"], tolerance)

            tb0 = dsel[time_bnds_name].isel(bnds=0).values
            tb1 = dsel[time_bnds_name].isel(bnds=1).values
            tref = dsetref["time"].values

            if not check_within_bounds(tref, tb0, tb1, bounds_tol):
                logger.error("Time bounds mismatch — some reference times outside data intervals")
                raise RuntimeError("Reference times fall outside data bounds.")
            else:
                logger.error("All reference times are within data bounds")
            dsel["time"] = dsetref["time"]
            return dsel[varpr]

        elif pr_bounded and ref_bounded:
            logger.info("Case 3: Bounded vs Bounded")

            dpr = dsetpr.copy()
            dref = dsetref.copy()

            # Match on one consistent bound — e.g., start or end
            dpr["time"] = tbnd_matching(dpr[time_bnds_name], tbnd_match)
            dref["time"] = tbnd_matching(dref[time_bnds_name], tbnd_match)
            logger.info(f"Matching both on '{tbnd_match}' of bounds")

            dsel = match_by_time(dpr, dref["time"], tolerance)
            # Restore original time coord from reference
            dsel["time"] = dsetref["time"]
            logger.info(f"Matched {len(dsel['time'])} timesteps")
            return dsel[varpr]

        elif not pr_bounded and ref_bounded:
            logger.info("Case 4: Instantaneous data vs Bounded reference")
            dref = dsetref.copy()
            dref["time"] = tbnd_matching(dref[time_bnds_name], tbnd_match)
            logger.info(f"Reference bounds matched using '{tbnd_match}'")

            dsel = match_by_time(dsetpr, dref["time"], tolerance)

            t = dsel["time"].values
            tb0 = dref["time_bnds"].isel(bnds=0).values
            tb1 = dref["time_bnds"].isel(bnds=1).values

            if not check_within_bounds(t, tb0, tb1, bounds_tol):
                logger.error("Some selected model data are outside reference bounds")
                raise RuntimeError("Selected data outside reference bounds.")

            dsel["time"] = dref["time"]
            return dsel[varpr]
        else:
            raise RuntimeError("Unhandled case in ReselectOP.")

    @log_function_name
    def OperaSpatialTemporal(
        self: 'PyXarray',
        filein: str,
        fileout: str,
        evalvars: List[str],
        cfgRestime: Dict[str, str],
        posdimnames: Dict[str, List[str]],
        cfgrollingm: Optional[Any] = None,
        spatialopx: Optional[Any] = None,
        spatialopy: Optional[Any] = None,
        spatialopz: Optional[Any] = None,
        refgrid_time: Optional[Any] = None,
        refgrid_timevars: Optional[Any] = None,
        varsprot: Optional[Any] = None,
    ) -> str:
        """
        Performs spatial and temporal aggregation of selected variables from a NetCDF file
        based on a provided configuration. This is the core function used to generate
        harmonized, aggregated outputs across time and space.

        Supported operations include:
        - Temporal resampling (e.g., monthly mean, seasonal max)
        - Time coordinate re-selection based on a reference grid
        - Rolling mean smoothing
        - Spatial aggregation over specified dimensions

        Parameters:
        -------
            filein (str):
                Path to the input NetCDF file.
            fileout (str):
                Path to the output NetCDF file where results will be saved.
            evalvars (List[str]):
                List of variable names to be processed from the dataset.
            cfgRestime (Dict[str, str]):
                Temporal aggregation configuration with keys:
                    - 'method': either 'reselect' or 'resample'
                    - 'freq': aggregation frequency (e.g., '1M', 'season')
                    - 'how': aggregation operation (e.g., 'mean', 'sum') [only for resample]
                    - 'tolerance': time tolerance for 'reselect' mode
            posdimnames (Dict[str, List[str]]):
                Dictionary classifying dimension types:
                    {
                        'spatial': [...],
                        'time': [...],
                        'vertical': [...]
                    }
            cfgrollingm (Optional[Any], default=None):
                Window size for rolling mean over the time dimension.
            spatialopx (Optional[Any], default=None):
                Aggregation operation along the x-direction ('mean', 'sum', or None).
            spatialopy (Optional[Any], default=None):
                Aggregation operation along the y-direction ('mean', 'sum', or None).
            spatialopz (Optional[Any], default=None):
                (Currently unused.)
            refgrid_time (Optional[Any], default=None):
                Path to reference dataset used for time alignment in 'reselect' mode.
            refgrid_timevars (Optional[Any], default=None):
                List of variable names in the reference file to use for time matching.
            varsprot (Optional[Any], default=None):
                List of variable names to preserve in the final dataset.

        Returns:
        -------
            str:
                Path to the written output NetCDF file (`fileout`).

        Raises:
        -------
            ValueError:
                If required keys are missing from `cfgRestime` or invalid configuration is detected.
            RuntimeError:
                If unsupported spatial operators are provided.

        Notes:
        -------
            - The input file is opened with xarray and processed in memory.
            - If no temporal or spatial operations are defined, the function returns the input file path.
            - Temporal operations support both full-period aggregations and resampling.
            - Time coordinate "repair" is applied after aggregation to correct time labels.
            - Final attributes and protected variables are restored before saving.
        """
        # -- Validate required key
        if "method" not in cfgRestime:
            raise ValueError("Missing required key 'method' in target_EvalFrequency")

        # -- Convert input dictionaries to single parameters:
        aggregt_mode = cfgRestime['method']
        aggregt_freq = cfgRestime.get('freq', "")
        aggregt_oper = None
        if aggregt_mode != 'reselect':
            aggregt_oper = cfgRestime.get('how')
        resel_tol = cfgRestime.get('tolerance', None)

        # -- Add logger before the artificial error:
        logger.debug("aggregt_mode: %s", aggregt_mode)
        logger.debug("aggregt_freq: %s", aggregt_freq)
        logger.debug("aggregt_oper: %s", aggregt_oper)
        logger.debug("resel_tol: %s", resel_tol)

        if aggregt_mode != "reselect" and aggregt_oper is None:
            logger.warning(
                "'how' is missing in target_EvalFrequency, required for '%s' mode", aggregt_mode)
        if aggregt_mode == "reselect" and resel_tol is None:
            logger.warning(
                "Missing 'tolerance' in target_EvalFrequency for 'reselect mode'")

        # -- Get values operx and opery:
        operx = None if spatialopx == '-' else spatialopx
        opery = None if spatialopy == '-' else spatialopy
        # -- Return the input file in case nothing has to be done:
        if aggregt_mode == '-' and not any([operx, opery]):
            logger.info("No need for aggregation. Leave file as it is.")
            return filein

        # -- Do the aggregation with an opening at first
        datset = xr.open_dataset(filein)
        endresult = xr.Dataset()
        #
        if evalvars is not None:
            datavars = list(
                set(list(datset.data_vars)).intersection(set(evalvars))
            )
        else:
            datavars = list(datset.data_vars)
        #
        DimInfov2 = self.FindDimsCoordsOfVariables(
            varnamelist = datavars, mode = 'dims', dataset = datset,
        )
        dim_time = GenUti.SplitMetaDim(
            DimInfov2, mode = 'temporal', PossibleDimDict = posdimnames)
        dim_xy = GenUti.SplitMetaDim(
            DimInfov2, mode = 'spatial', PossibleDimDict = posdimnames)

        RepairP = {}
        RepairP['needed'] = False
        for varkey in datavars:
            if aggregt_mode == "reselect" and refgrid_time is not None:
                logger.debug(f'Dates are reselected according to dates in {refgrid_time}')
                # -- Open the refgrid_time dataset:
                with xr.open_dataset(refgrid_time) as dsetref:
                    varkeyref = refgrid_timevars[0] if refgrid_timevars else None
                    logger.debug(
                        f"Start ReselectOP using time variable '{varkeyref}' "
                        "from reference dataset."
                    )
                    datarrnew = self.ReselectOP(
                        dsetpr=datset,
                        varpr=varkey,
                        dsetref=dsetref,
                        varref=varkeyref,
                        tolerance=resel_tol,
                    )

            elif aggregt_mode == "resample" and dim_time[varkey]:
                logger.debug('Dates resampled according to user settings ')
                # -- Get actual coordinates (common for all methods):
                coordtime = self.ListDimsToXarray(dim_time[varkey])
                # Define the type for the operations
                operations: Dict[str, Callable[[xr.DataArray], xr.DataArray]]
                # -- Define correct operators for different options of aggregt_freq:
                if "fullperiod" in aggregt_freq or "overperiod" in aggregt_freq:
                    # Initialization operators for these methods:
                    operations = {
                        'mean': lambda x: x.mean(dim = coordtime),
                        'std': lambda x: x.std(dim = coordtime),
                        'max': lambda x: x.max(dim = coordtime),
                        'sum': lambda x: x.sum(dim = coordtime, min_count = 1),
                    }
                elif "overperiod" not in aggregt_freq:
                    # Initializationzation operators for these methods:
                    operations = {
                        'mean': lambda ds, coord, freq: ds.resample(
                            {coord: freq}).mean(dim = coord, keep_attrs = True),
                        'std': lambda ds, coord, freq: ds.resample(
                            {coord: freq}).std(dim = coord, keep_attrs = True),
                        'max': lambda ds, coord, freq: ds.resample(
                            {coord: freq}).max(dim = coord, keep_attrs = True),
                        'min': lambda ds, coord, freq: ds.resample(
                            {coord: freq}).min(dim = coord, keep_attrs = True),
                        'sum': lambda ds, coord, freq: ds.resample(
                            {coord: freq}).sum(dim = coord, keep_attrs = True, min_count = 1),
                    }
                # -- Control of input operations:
                if aggregt_oper not in operations:
                    raise ValueError(
                        f'Func OperaSpatialTemporal of PyXarray: Unsupported '
                        f'aggregation operation: {aggregt_oper}')

                # -- Make necessary computations for:
                #        a. "fullperiod" in aggregt_freq
                #        b. "overperiod" in aggregt_freq
                #        c. "overperiod" not in aggregt_freq
                if "fullperiod" in aggregt_freq:
                    datarrnew = operations[aggregt_oper](datset[varkey])
                    datset_t = datset[coordtime].data
                    # -- Repair process:
                    RepairP["needed"] = True
                    RepairP['tlost'] = datset_t[0] + (datset_t[-1] - datset_t[0]) / 2.0

                elif "overperiod" in aggregt_freq:
                    grpby_method = self.ags.ConvertAggregKey2Groupby(aggregt_freq)
                    var4groupby = f'{coordtime}.{grpby_method}'
                    datarrnew = operations[aggregt_oper](datset[varkey].groupby(var4groupby))
                    # -- Repair process:
                    RepairP["needed"] = True
                    RepairP['start'] = datset[coordtime].data[0]

                elif "overperiod" not in aggregt_freq:
                    logger.info(f'Temporal resampling for file {filein} to freq {aggregt_freq}')
                    # -- Get resample frequensy:
                    resamplefreq = self.ags.ConvertAggregKey2Resample(aggregt_freq)
                    # -- Get values for datarrnew:
                    datarrnew = operations[aggregt_oper](datset[varkey], coordtime, resamplefreq)
                    # -- Repair process:
                    RepairP["needed"] = True
            else:
                datarrnew = datset[varkey]

            # -- Rolling mean:
            if cfgrollingm is not None:
                datarrnew = datarrnew.rolling(
                    {coordtime: cfgrollingm}, center = True).mean()

            # -- Spatial operation (should be exported):
            if (operx is not None) and (opery is not None) and dim_xy[varkey]:
                temp_dims = self.ListDimsToXarray(dim_xy[varkey])
                if operx == 'mean' and opery == 'mean':
                    datarrnew2 = datarrnew.mean(dim = temp_dims, keep_attrs = True)
                elif operx == 'sum' and opery == 'sum':
                    datarrnew2 = datarrnew.sum(dim = temp_dims, keep_attrs = True)
                else:
                    raise RuntimeError(
                        f"Aggregation operator '{operx}, {opery}' not supported "
                        "for spatial dimensions."
                    )
            else:
                datarrnew2 = datarrnew
            endresult = xr.merge([endresult, datarrnew2.to_dataset()])
        #
        if RepairP['needed']:
            # -- Get time axis (xr.DataArray) for dataset and copy it to RepairP['timeref']
            RepairP['timeref'] = datset[coordtime]
            endresultcorr = self.RepairProcessTime(
                datrepair = endresult,
                groupby_mode = aggregt_freq,
                RepairTimeP = RepairP,
            )
        else:
            endresultcorr = endresult

        # -- Repair the variable attributes and write out final file + close others;
        endresultcorr = self.RetainVarAttrs(
            oldds = datset,
            newds = endresultcorr,
            varswithattr = evalvars,
            varsprot = varsprot,
        )
        endresultcorr.to_netcdf(fileout)
        datset.close()
        endresult.close()
        #
        return fileout

    @log_function_name
    def RepairProcessTime(
        self: 'PyXarray',
        datrepair: xr.Dataset,
        groupby_mode: str,
        RepairTimeP: Dict[str, Any],
    ) -> xr.Dataset:
        """
        Repairs the time coordinate of an xarray dataset after temporal aggregation
        operations (e.g., `groupby`, `resample`) that may have renamed or distorted the
        time dimension.

        This function ensures that:
        -------
        - The time coordinate is properly named ("time")
        - Time values are reconstructed based on the aggregation method
        - Time encoding and attributes are restored from a reference time array

        Parameters:
        -------
            datrepair (xr.Dataset):
                The dataset whose time coordinate needs to be repaired.
            groupby_mode (str):
                Aggregation mode used during the operation, such as:
                'monthlyoverperiod', 'seasonaloverperiod', etc.
            RepairTimeP (Dict[str, Any]):
                Dictionary containing parameters needed for repair, may include:
                - "tlost": Single timestamp to be assigned to the dataset
                - "start": Start timestamp for generating new time values
                - "timeref": Time coordinate from the original reference dataset,
                             used to restore calendar, units, and attributes

        Returns:
        -------
            xr.Dataset:
                The dataset with a corrected and fully restored 'time' coordinate.

        Raises:
        -------
            ValueError:
                If `groupby_mode` is not recognized as a supported aggregation frequency.

        Notes:
        -------
            - If "tlost" is present, the dataset is assumed to contain a single period and
              will be assigned a single timestamp.
            - If "start" is present, the function will reconstruct a sequence of timestamps
              appropriate to the `groupby_mode`.
            - Time encoding and attributes (e.g., `units`, `calendar`, `standard_name`,
              `long_name`) are restored from `RepairTimeP['timeref']`.
            - Supports sorting the resulting dataset chronologically by time.
            - Assumes that the time coordinate is named or will be renamed to `"time"`.
        """
        if "tlost" in RepairTimeP.keys():
            datrepair.coords["time"] = RepairTimeP["tlost"]
            datrepair = datrepair.expand_dims("time")

        elif "start" in RepairTimeP.keys():
            datrepair = datrepair.rename(
                {self.ags.ConvertAggregKey2Groupby(groupby_mode): 'time'}
            )

            dicseas = {"DJF": 1, "MAM": 2, "JJA": 3, "SON": 4}

            TimeStart = pd.Timestamp(RepairTimeP['start'])
            TimeStart = pd.Timestamp(TimeStart.year, TimeStart.month, TimeStart.day)

            # -- Initialization of methods for for with time:
            mode_to_timedef = {
                "hourlyoverperiod": lambda tidx: TimeStart + pd.Timedelta(hours = tidx),
                "dailyoverperiod": lambda tidx: TimeStart + pd.Timedelta(days = (tidx - 1)),
                "weeklyoverperiod": lambda tidx: TimeStart + pd.Timedelta(weeks = (tidx - 1)),
                "monthlyoverperiod": lambda tidx: pd.date_range(
                    start = TimeStart, inclusive = "left", freq = "M", periods = tidx)[-1],
                "seasonaloverperiod": lambda tidx: pd.date_range(
                    start = TimeStart, inclusive = "left", freq = "Q-NOV", periods = dicseas[tidx])[-1],
            }
            # -- Control of available time methods:
            if groupby_mode not in mode_to_timedef:
                raise ValueError(f'Incorrect timedelta - {groupby_mode}')

            # -- Get actual function:
            timedef = mode_to_timedef[groupby_mode]
            # -- Get data using correct function:
            datrepair["time"] = [timedef(tidx) for tidx in datrepair["time"].data]

        # -- Always try to fix attributes of time-variables (because they are lost):
        # -- Get calendar from reference, fallback to default if missing:
        t_cal = RepairTimeP['timeref'].encoding.get('calendar', 'proleptic_gregorian')

        # -- Copy essential encoding fields:
        datrepair['time'].encoding['units'] = RepairTimeP['timeref'].encoding['units']
        datrepair['time'].encoding['calendar'] = t_cal

        timeref_attrs = RepairTimeP['timeref'].attrs

        # -- Check standard_name:
        if "standard_name" in timeref_attrs:
            datrepair['time'].attrs['standard_name'] = timeref_attrs['standard_name']
        else:
            logger.warning("Missing 'standard_name' in timeref; setting it to 'time'")
            timeref_attrs['standard_name'] = 'time'

        # -- Check long_name:
        if "long_name" in timeref_attrs:
            datrepair['time'].attrs['long_name'] = timeref_attrs['long_name']
        else:
            datrepair['time'].attrs['long_name'] = 'time'

        # -- Return the end result with sorted time coordinate (for seasons):
        return datrepair.sortby(datrepair["time"], ascending = True)

    @log_function_name
    def DatesInterSect(
        self: 'PyXarray',
        filein: str,
        timper: List[str],
        varcorlistdict: Dict[Any, Any],
        varsrel: List[str],
        posdimnames: Dict[str, List[str]],
    ):
        """
            Return information about how date stamps in filein intersect with the
            time period given by 'timper', it already uses information about the
            variables of interest in file 'filein';

            Return values:
            ----------------------------
                1) index group of the timestamps which intersect with 'timper' +
                2) returns if all timestamps intersect with 'timper';

            Important: The algorithm only searches up to the first entry of varsrel,
                       other vars not processed

            Example of input variables:
            ----------------------------
            ```python
            {
                'self': <hereon_evasuite.Prog_PyXarray_PyVis.PyXarray object at 0x7fffc264c2b0>,
                'filein': '/work/../hfls_Amon_MIROC6_historical_r1i1p1f1_gn_185001-194912.nc',
                'timper': ['1981-01-01T00:00', '1982-12-31T23:59'],
                'seasons': 'complete',
                'varcorlistdict': {},
                'varsrel': ['hfls'],
                'posdimnames': {
                    'spatial': ['lon', 'lat', 'X', 'Y'],
                    'time': ['time'],
                    'vertical': ['level', 'height']
                }
            }
            ```
        """
        namtime_bnds, cellmat = "time_bnds", "cell_methods"
        timedat = xr.open_dataset(filein)

        DimInfo = self.FindDimsCoordsOfVariables(
            varnamelist = varsrel, mode = 'dims', dataset = timedat,
        )
        dim_time = GenUti.SplitMetaDim(
            DimInfo, mode = 'temporal', PossibleDimDict = posdimnames,
        )
        # -- Check for the user-specified timeshifts:
        if not varsrel:
            return False, False

        for varkey in varsrel:
            # -- Start with the unit correction if needed:
            if varkey in varcorlistdict.keys():
                if varcorlistdict[varkey]["timeshift"]:
                    temp_timcor_val = varcorlistdict[varkey]["timcor_val"]
                    logger.debug(
                        f" Detect relevant times -> Shift the time axis of {varkey} "
                        f"by {''.join(temp_timcor_val[:2])}{temp_timcor_val[2]}"
                    )

                    dahelp = timedat[varkey].assign_coords({
                        dim_time[varkey][0]: (
                            timedat[varkey][dim_time[varkey][0]] +
                            pd.Timedelta(
                                int(''.join(varcorlistdict[varkey]["timcor_val"][0:2])),
                                unit = varcorlistdict[varkey]["timcor_val"][2]
                            )
                        )
                    })
                    timedat[varkey] = dahelp

            # -- Files with time_bnds are much harder to treat, only the first
            #    variable is checked for cell_methods
            if (namtime_bnds in timedat.data_vars) and (cellmat in timedat[varkey].attrs.keys()):
                if timedat[varkey].attrs[cellmat] in ["sum", "mean"]:
                    logger.debug(
                        f"Found time_bnds and cell_methods is [mean,sum] "
                        f"in the {varkey} of {filein}"
                    )
                    timedat["savetime"] = timedat["time"]
                    # -- Overwrite the time to select lowbound:
                    timedat["time"] = timedat["time_bnds"][:, 0]
                    selpdat_lowbnd = timedat.sel(time = slice(timper[0], timper[1]))
                    # -- Overwrite the time to select upbound:
                    timedat["time"] = timedat["time_bnds"][:, 1]
                    selpdat_upbnd = timedat.sel(time = slice(timper[0], timper[1]))
                    # -- Now selpdat_lowbnd["time"][0] contains the first timestep
                    #    to select + selpdat_upbnd["time"][-1] contains the first
                    #    timestep to select
                    timedat["time"] = timedat["savetime"]
                    # no time step left
                    if (selpdat_upbnd.dims["time"] == 0) and (selpdat_lowbnd.dims["time"] == 0):
                        logger.debug(
                            f'Variable {varkey} is in file but '
                            f'tim_bnds are not in the time period of interest'
                        )
                        return False, False

                    if (selpdat_upbnd.dims["time"] == 0) or (selpdat_lowbnd.dims["time"] == 0):
                        logger.debug(
                            f'Variable {varkey} is in file but one '
                            f'tim_bnd is out of time period'
                        )
                        return False, False

                    ind1, = np.where(timedat['time_bnds'][:, 1].data == selpdat_upbnd["time"].data[0])
                    ind2, = np.where(timedat['time_bnds'][:, 0].data == selpdat_lowbnd["time"].data[-1])
                    return [ind1[0], ind2[0]], (ind1[0] == 0) and (ind2[0] == timedat.dims["time"] - 1)

                else:
                    cutper = timedat.sel(time = slice(timper[0], timper[1]))
            else:
                cutper = timedat.sel(time = slice(timper[0], timper[1]))

            if cutper.sizes["time"] == 0:
                logger.debug(
                    f'Variable {varkey} is in the file but not '
                    f'in the time period of interest'
                )
                return False, False
            elif cutper.sizes["time"] == timedat.sizes["time"]:
                return [0, timedat.sizes["time"] - 1], True
            else:
                ind1, = np.where(timedat['time'].data == cutper['time'].data[0])
                ind2, = np.where(timedat['time'].data == cutper['time'].data[-1])
                return [ind1[0], ind2[0]], False

    @log_function_name
    def CutTimeStepsAndParamAndVarCor(
        self: 'PyXarray',
        filein: str,
        fileout: str,
        varnames: List[str],
        timper: List[str],
        varcorlistdict: Dict[Any, Any],
        posdimnames: Dict[str, List[str]],
        timRangeIdx: Optional[List[int]] = None,
        cutrgspat: Optional[Union[bool, Dict]] = False,
        cutrglev: Optional[Union[bool, Dict]] = False,
    ) -> str:
        """
        Cuts a dataset by time period, spatial/vertical ranges, and applies variable/unit
        corrections, similar to `cdo` operations but with additional flexibility.

        This function:
        - Optionally applies variable unit conversions and time shifts.
        - Cuts the dataset to specified spatial or vertical index ranges.
        - Selects a time slice based on a given time period (`timper`), including
          special handling for datasets with `time_bnds`.
        - Extracts only the specified variables and writes the result to a NetCDF file.

        Parameters
        ----------
        filein : str | List[str]
            Path to the input NetCDF file, or list of file paths. If a list is provided,
            multiple files will be combined with `xarray.open_mfdataset`.
        fileout : str
            Path to the output NetCDF file.
        varnames : List[str]
            Names of variables to retain in the output dataset.
        timper : List[str]
            Start and end time (inclusive) in ISO 8601 format, e.g.,
            `['1981-01-01T00:00', '1982-12-31T23:59']`.
        varcorlistdict : Dict[Any, Any]
            Dictionary specifying variable corrections. Each entry may include:
                - `"unitcor"` (bool): Whether to apply a unit correction.
                - `"corr_vals"` (list): [operator, value, new_units].
                - `"timeshift"` (bool): Whether to shift time coordinates.
                - `"timcor_val"` (list): [value, unit], e.g., `[1, 'D']` for 1 day.
        posdimnames : Dict[str, List[str]]
            Dictionary of possible dimension names, e.g.:
            {
                'spatial': ['lon', 'lat', 'X', 'Y'],
                'time': ['time'],
                'vertical': ['level', 'height']
            }
        timRangeIdx : Optional[List[int]], default=None
            Not used in this implementation; `timper` is used instead.
        cutrgspat : Optional[bool | Dict], default=False
            Spatial cut ranges. If dict, keys are dimension names and values are
            `[start, stop, step]` slices.
        cutrglev : Optional[bool | Dict], default=False
            Vertical cut ranges. Same format as `cutrgspat`.

        Returns
        -------
        str
            Path to the output NetCDF file.

        Raises
        ------
        TypeError
            If `cutrgspat` or `cutrglev` is not `False` or a dictionary.
        Exception
            If `timRangeIdx` indicates multi-dimensional cutting, which is unsupported.
        RuntimeError
            If more than 4 variables are requested for output.

        Notes
        -----
        - When `time_bnds` exists and the variable's `cell_methods` attribute is
          `'mean'` or `'sum'`, special handling ensures correct time slicing
          based on bounds.
        - Supports arithmetic corrections via operators `"+"`, `"-"`, `"*"`, `"/"`.
        - After cutting, the dataset is saved to `fileout` with preserved time bounds
          if present.
        """
        def loc_operator(datarray: xr.DataArray, coroper: str, corvalue: float):
            """ Input values:
                1. datarray -> research dataset
                2. coroper -> simbol one of math. operations
                3. corvalue -> 86400.0
            """
            if coroper == "+":
                return datarray + corvalue
            elif coroper == "-":
                return datarray - corvalue
            elif coroper == "*":
                return datarray * corvalue
            elif coroper == "/":
                return datarray / corvalue
        #
        #
        if isinstance(filein, list) and len(filein) > 1:
            dsfilein = xr.open_mfdataset(
                filein, combine = 'by_coords', parallel = True)

        elif isinstance(filein, list) and len(filein) == 1:
            dsfilein = xr.open_dataset(filein[0])

        elif isinstance(filein, str):
            dsfilein = xr.open_dataset(filein)

        #
        DimInfo = self.FindDimsCoordsOfVariables(
            varnamelist = varnames, mode = 'dims', dataset = dsfilein,
        )
        dim_time = GenUti.SplitMetaDim(
            DimInfo, mode = 'temporal', PossibleDimDict = posdimnames,
        )
        # -- At first do the corrections of variable units and time coordinate:
        if varcorlistdict:
            logger.debug(f'Modify dataset: units or timeshift {varnames}')
            #
            for varkey in varcorlistdict.keys():
                # -- Start with the unit correction if needed:
                if varcorlistdict[varkey]["unitcor"]:
                    logger.debug(
                        f'Modify the variable {varkey} by '
                        f'{varcorlistdict[varkey]["corr_vals"]}'
                    )
                    dsfilein[varkey] = loc_operator(
                        dsfilein[varkey],
                        varcorlistdict[varkey]["corr_vals"][0],
                        float(varcorlistdict[varkey]["corr_vals"][1])
                    )
                    dsfilein[varkey].attrs["units"] = varcorlistdict[varkey]["corr_vals"][2]

                # -- Shift the time axis:
                if varcorlistdict[varkey]["timeshift"]:
                    logger.debug(
                        f'Shift the time axis of {varkey} by '
                        f'{varcorlistdict[varkey]["timcor_val"]}'
                    )
                    dahelp = dsfilein[varkey].assign_coords({
                        dim_time[varkey][0]: (
                            dsfilein[varkey][dim_time[varkey][0]] +
                            pd.Timedelta(
                                int(''.join(varcorlistdict[varkey]["timcor_val"][0:2])),
                                unit = varcorlistdict[varkey]["timcor_val"][2]
                            )
                        )
                    })
                    dsfilein[varkey] = dahelp

        # -- Cut the domain:
        if cutrgspat:
            if isinstance(cutrgspat, dict):
                logger.debug('Modify dataset: Spatial cutting')
                for keyes in cutrgspat.keys():
                    if len(cutrgspat[keyes]) == 3:
                        step = cutrgspat[keyes][2]
                    else:
                        step = 1
                    dsfilein = dsfilein.isel({
                        keyes: slice(cutrgspat[keyes][0], cutrgspat[keyes][1], step)
                    })
            else:
                raise TypeError(
                    'Func CutTimeStepsAndParamAndVarCor of PyXarray: Incorrect '
                    'format of cutrgspat variable. It should be dictionary'
                )
        # -- Cut levels:
        if cutrglev:
            if isinstance(cutrglev, dict):
                logger.debug('Modify dataset: Cut levels')
                for keyes in cutrglev.keys():
                    if len(cutrglev[keyes]) == 3:
                        step = cutrglev[keyes][2]
                    else:
                        step = 1
                    dsfilein = dsfilein.isel({
                        keyes: slice(cutrglev[keyes][0], cutrglev[keyes][1], step)
                    })
            else:
                raise TypeError(
                    'Func CutTimeStepsAndParamAndVarCor of PyXarray: Incorrect '
                    'format of cutrglev variable. It should be dictionary'
                )
        # -- Finally cut off the time slices:
        if timRangeIdx is None:
            cutoffts = True
        else:
            cutoffts = True if len(np.array(timRangeIdx).shape) == 1 else False

        # -- Add info to debug file:
        logger.debug(f'Cut out time period: {timper[0]}...{timper[1]}')
        #
        if cutoffts:
            #
            if (("time_bnds" in dsfilein.data_vars) and
                    ("cell_methods" in dsfilein[varnames[0]].attrs.keys())):
                if dsfilein[varnames[0]].attrs["cell_methods"] in ["mean", "sum"]:
                    logger.info(
                        f"Habe time_bnds gefunden und cell-methods is [sum,mean]"
                        f" in DATA {filein}"
                    )
                    dsfilein["savetime"] = dsfilein["time"]
                    dsfilein["time"] = dsfilein["time_bnds"][:, 1]

                    up = dsfilein.sel(time = slice(timper[0], timper[1]))
                    dsfilein["time"] = dsfilein["time_bnds"][:, 0]

                    low = dsfilein.sel(time = slice(timper[0], timper[1]))

                    ind1low, = np.where(dsfilein['time_bnds'][:, 0] == low['time'].data[0])
                    ind1up, = np.where(dsfilein['time_bnds'][:, 1] == up['time'].data[-1])

                    if dsfilein['time_bnds'][ind1low[0], 0] >= np.datetime64(timper[0]):
                        ind1low[0] = np.fmax(ind1low[0] - 1, 0)

                    if dsfilein['time_bnds'][ind1up[0], 1] <= np.datetime64(timper[1]):
                        ind1up[0] = np.fmin(ind1up[0] + 1, dsfilein["time"].size - 1)

                    dsfilein["time"] = dsfilein["savetime"]
                    logger.info(f"Index von {ind1low} bis {ind1up}")
                    # -- The last must be increased due to python range behaviour:
                    dsfilecutT = dsfilein.isel(time = slice(ind1low[0], ind1up[0] + 1))
                else:
                    dsfilecutT = dsfilein.sel(time = slice(timper[0], timper[1]))
            else:
                dsfilecutT = dsfilein.sel(time = slice(timper[0], timper[1]))
        #
        else:
            raise Exception("The cutting of time period to user needs is not possible.")

        #
        # -- THE FOLLOWING LINES DESTROY MANY INFORMATION IN FILE, CHANGE THE
        #    WAY TO CUT OUT VARIABLES
        if len(varnames) == 1:
            dsfilecutTV = dsfilecutT[varnames[0]].to_dataset(name = varnames[0])
        elif len(varnames) == 2:
            dsfilecutTV = dsfilecutT[[varnames[0], varnames[1]]]
        elif len(varnames) == 3:
            dsfilecutTV = dsfilecutT[[varnames[0], varnames[1], varnames[2]]]
        elif len(varnames) == 4:
            dsfilecutTV = dsfilecutT[[varnames[0], varnames[1], varnames[2], varnames[3]]]
        else:
            logger.error("More than 4 variables cannot be cutted out")

        if "time_bnds" in dsfilecutT.data_vars:
            dsfilecutTV["time_bnds"] = dsfilecutT["time_bnds"]
        #
        if isinstance(filein, list) and len(filein) > 1:
            dsfilecutTV = dsfilecutTV.load()
            # -- Make sure the encoding is really empty:
            #       assert not dsfilecutTV["time"].encoding
            #       assign encoding, such that they are equal
            if "time_bnds" in dsfilecutTV.data_vars:
                dsfilecutTV["time"].encoding.update(dsfilecutTV["time_bnds"].encoding)
            dsfilecutTV.to_netcdf(fileout)
        else:
            dsfilecutTV.to_netcdf(fileout)

        dsfilecutT.close()
        dsfilecutTV.close()
        dsfilein.close()
        #
        return fileout

    @log_function_name
    def RecomputeQuant(
        self: 'PyXarray',
        compute_type,
        filein = None,
        fileout = None,
        evalvars = None,
        levtype = None,
        dictDims = None,
        datset = None,
        evalparadd = None,
    ):
        """ Recompute variables 'evalvars' depending on the compute_type:"""
        # -- The dictionary of new variable names to evaluation parameters:
        logger.warning(
            "EvaSuite Warning: You are using an untested function.\n"
            "If possible, please send your configuration files to: "
            "evgenii.churiulin@kit.edu for testing and validation support."
        )
        recnewvars = {}
        if compute_type == "grad_z":
            if levtype == "height":
                heilev, heivar3D = self.ExtractLevInfoFromNC(
                    vert_gridtype = levtype,
                    ncfile = filein,
                    varlist = evalvars,
                    coord3D = True,
                )
            else:
                raise ValueError(
                    f"The vertical gradient can only be computed for height levels"
                    f" at the moment, but levtype is {levtype}"
                )
        elif ("setvalidrange" in compute_type) or ("setmaskedrange" in compute_type):
            pass
        else:
            raise RuntimeError("This type of derivation is not allowed at the moment.")

        # -- Open depending on chunking:
        if self.chunking is False:
            dsfilein = xr.open_dataset(filein)
        else:
            dsfilein = xr.open_dataset(filein, chunks = self.chunking)

        # -- The computation:
        datavars = list(set(list(dsfilein.data_vars)).intersection(set(evalvars)))
        #
        if compute_type == "grad_z":
            dsfileout = dsfilein.copy()
            datavarsfilt = [x for x in datavars if heilev[x] is not None]
            datavarsfilt = [x for x in datavarsfilt if heilev[x].size >= 2]
            if datavarsfilt != datavars:
                invalid_vars = list(set(datavars) - set(datavarsfilt))
                logger.error(
                    f"GRADIENT in Z, some vars have only one level or no "
                    f"level information ... look at these variables: {invalid_vars}"
                )
                raise ValueError(
                    f"Cannot compute vertical gradient: variables missing level info: {invalid_vars}"
                )
            #
            for varkey in datavarsfilt:
                dsfilein = dsfilein.rename({heivar3D[varkey]: "hl_forcompute"})
                result = []
                for height in range(0, (heilev[varkey]).size - 1):
                    level = (
                        (
                            dsfilein[varkey].isel(hl_forcompute = height + 1) -
                            dsfilein[varkey].isel(hl_forcompute = height)
                        ) / (heilev[varkey][height + 1] - heilev[varkey][height])
                    )

                    level.coords['height_im' + varkey] = (
                        heilev[varkey][height] +
                        (heilev[varkey][height + 1] - heilev[varkey][height]) / 2.0
                    )
                    # -- The first position is reserved for time:
                    level = level.expand_dims('height_im' + varkey, axis = 1)

                    if height == 0:
                        result = level
                    else:
                        result = xr.concat([result, level], dim = 'height_im' + varkey)

                dsfileout[varkey].attrs['units'] = dsfileout[varkey].attrs['units'] + ' m-1'
                dsfileout[varkey] = result
                dsfileout = dsfileout.rename({varkey: varkey + "_gradz"})
                recnewvars[datset.getEvalPara2VarName(varkey) + evalparadd] = varkey + "_gradz"
            dsfileout.to_netcdf(fileout)
            dsfileout.close()

        elif ("setvalidrange" in compute_type):
            datavarsfilt = datavars
            lowbound = np.float64(compute_type.split(";")[1])
            upbound = np.float64(compute_type.split(";")[2])
            for varkey in datavarsfilt:
                # -- Should work also without np.nan:
                dsfilein[varkey] = dsfilein[varkey].where(
                    (
                        (dsfilein[varkey] > lowbound) & (dsfilein[varkey] < upbound)
                    ), np.nan
                )
                dsfilein[varkey].encoding.update({'dtype': 'float32'})
                dsfilein = dsfilein.rename({varkey: varkey + "_setvrange"})
                recnewvars[datset.getEvalPara2VarName(varkey) + evalparadd] = varkey + "_setvrange"
            dsfilein.to_netcdf(fileout)

        elif ("setmaskedrange" in compute_type):
            datavarsfilt = datavars
            lowbound = np.float64(compute_type.split(";")[1])
            upbound = np.float64(compute_type.split(";")[2])
            for varkey in datavarsfilt:
                # -- Should work also without np.nan:
                dsfilein[varkey] = xr.where(
                    (
                        (dsfilein[varkey] > lowbound) & (dsfilein[varkey] < upbound)
                    ), 1, np.nan
                )
                dsfilein[varkey].encoding.update({'dtype': 'float32'})
                dsfilein = dsfilein.rename({varkey: varkey + "_setmaskrange"})
                recnewvars[datset.getEvalPara2VarName(varkey) + evalparadd] = varkey + "_setmaskrange"
            dsfilein.to_netcdf(fileout)
        #
        dsfilein.close()
        return fileout, recnewvars

    @log_function_name
    def ComputeSubDomains(
        self: 'PyXarray',
        filenam: str,
        fileoutpre: str,
        fvarnames: List[str],
        subdoml: List[str],
        subdommasks: Dict[str, str],
        PossDimDict: Dict[str, List[str]],
    ) -> List[str]:
        """
        Compute and save statistics for specified subdomains within a dataset.

        This method extracts sub-regional statistics from a dataset by applying
        corresponding subdomain masks, averaging over spatial dimensions if present,
        and writing each subdomain result to a separate NetCDF file.

        Parameters
        ----------
        filenam : str
            Absolute path to the input dataset (e.g., "/scratch/.../WP04_EvalFinal...nc").
        fileoutpre : str
            Output file path prefix. The subdomain name and `.nc` extension will be appended.
            For example:
            - `"WP03"` in path → output file name format: `{fileoutpre}{subreg}.nc`
            - `"WP04"` in path → output file name format: `{fileoutpre}.{subreg}.nc`
        fvarnames : List[str]
            List of variable names to process (e.g.,
            `['BIAS_temporal_pr_amount', 'BIASnorm_temporal_pr_amount']`).
        subdoml : List[str]
            List of subdomain names to compute (e.g., `['Germany', 'P_Alps']`).
        subdommasks : Dict[str, str]
            Dictionary mapping subdomain names to the path of their corresponding mask file.
            Mask files must contain a variable `"MASK"` with 1 for region cells, 0 elsewhere.
            Example:
            ```python
            {
                'Germany': '/scratch/.../Germany_mask.nc',
                'P_Alps': '/scratch/.../P_Alps_mask.nc'
            }
            ```
        PossDimDict : Dict[str, List[str]]
            Dictionary describing possible dimension names for categories:
            ```python
            {
                'spatial': ['lon', 'lat', 'X', 'Y'],
                'time': ['time'],
                'vertical': ['level', 'height']
            }
            ```

        Returns
        -------
        List[str]
            List of output file paths for each computed subdomain.

        Raises
        ------
        ValueError
            If `fileoutpre` does not contain `"WP03"` or `"WP04"`.

        Notes
        -----
        - If spatial dimensions are present for a variable, the method will compute
          the mean over those dimensions before saving.
        - Each output file will include a dataset attribute `"region"` with the subdomain name.
        - The method reads the input dataset once and applies each mask sequentially.
        """
        filenames_subreg: List[str] = []
        # -- Open dataset
        logger.info('Creating datasets with regional information:')
        FinalDS = xr.open_dataset(filenam)
        meta_dim = self.FindDimsCoordsOfVariables(
            varnamelist = fvarnames, mode = 'dims', dataset = FinalDS,
        )
        dim_xy = GenUti.SplitMetaDim(
            meta_dim, mode = 'spatial', PossibleDimDict = PossDimDict,
        )

        if subdoml:
            for subreg in subdoml:
                # -- Get sub-region domain
                if "WP03" in fileoutpre:
                    filename_subreg = f"{fileoutpre}{subreg}.nc"
                elif "WP04" in fileoutpre:
                    filename_subreg = f"{fileoutpre}.{subreg}.nc"
                else:
                    raise ValueError('Incorrect place for calling ComputeSubDomains')
                # -- Open sub-domain:
                with xr.open_dataset(subdommasks[subreg]) as mask, xr.Dataset() as FinalDSsubreg:
                    MaskedDS = FinalDS.copy()
                    for varnsres in fvarnames:
                        MaskedDS[varnsres].data = FinalDS[varnsres].data * mask['MASK'].data
                        if dim_xy[varnsres]:
                            datarrnew = MaskedDS[varnsres].mean(
                                dim = self.ListDimsToXarray(dim_xy[varnsres]),
                                keep_attrs = True,
                            )
                        else:
                            datarrnew = MaskedDS[varnsres]
                        FinalDSsubreg = xr.merge([FinalDSsubreg, datarrnew.to_dataset()])
                    FinalDSsubreg.attrs['region'] = subreg
                    # -- Save subregions:
                    FinalDSsubreg.to_netcdf(filename_subreg)

                filenames_subreg.append(filename_subreg)
        # -- Close the main dataset
        FinalDS.close()
        return filenames_subreg

    def ListDimsToXarray(self: 'PyXarray', dimnamelist: List[str]) -> str:
        """
        Convert a list of dimension names into a format suitable for xarray operations.

        This method ensures that if only one dimension name is provided, it is returned
        as a plain string (instead of a list) so that it can be used directly in
        xarray aggregation or selection methods. If multiple dimension names are provided,
        the original list is returned.

        Parameters
        ----------
        dimnamelist : List[str]
            A list of dimension names (e.g., ["lon", "lat"] or ["time"]).

        Returns
        -------
        str or List[str]
            - A single dimension name as a string if the input contains only one element.
            - The original list of dimension names if there are multiple.
        """
        dimlist = GenUti.check_for_list(dimnamelist)
        if len(dimlist) == 1:
            return dimlist[0]
        else:
            return dimlist
