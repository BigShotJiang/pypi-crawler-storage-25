# EvaSuite
#
# ---------------------------------------------------------------
# Copyright (C) 2004-2025, Hereon
# Contact information: beate.geyer@hereon.de, imktro-climate-modelling@lists.kit.edu
# See AUTHORS.TXT for a list of authors
# See LICENSES/ for license information
# SPDX-License-Identifier: Apache-2.0
# ---------------------------------------------------------------


"""
################################################################################
#           THIS IS THE MAIN PROGRAM CONTROLLING THE EvaSUITE
################################################################################

authors: Ronny Petrik, Evgenii Churiulin, Beate Geyer

# SOME Pitty Points with this program:
- fuer EVALmode soll es eigene Reperatur von attributen und variablen geben,
    nutze allgemeine RetainVarsAttribs (wird schon bei UnifyEvalFrequency-methode
    in Datasets eingesetzt)

- A Land-Sea-Mask is needed for comparisons in EVALMODE=compareraw and timeseries
    (otherwise, reference data purely over land where compared with model data
    over land and ocean)

- Bug: the repairing process should consider the case where the original data
    were still not modified up to this repairing stage and so the permissions
    does not allow for attribute manipulation

- Bug: the repairing process for the attributes seems to be very slow also none
    of the attributes has to be put in (NCO create attribute is slow in case the
    attributes already exists)


History:
Version    Date       Name
---------- ---------- ----
   1.1      05.2024 Evgenii Churiulin, IMKTRO
                Start code refactoring
   1.2      08.2025 Evgenii Churiulin, IMKTRO
                Version v1.0 is ready
"""
# -- import Python modules:
import os
import yaml
import hashlib
import pandas as pd
import subprocess as sp
import shutil
# -- Fundamental package for scientific computing with Python:
import numpy as np
# -- Options functionality:
from pkg_resources import Requirement, resource_filename
from typing import Any, Union, Dict, List, Type

# -- Import EvaSuite classes and modules:
#    -- Enables logging functionality and custamize loggers:
from hereon_evasuite.log_EvaSuite import get_logger, log_function_name
from hereon_evasuite.generate_rename_mapping import Cmor_generator
from hereon_evasuite.input_parser import Init_parser
from hereon_evasuite.control_input_settings import Control_namelists
#    -- The class for the Dataset functionality:
from hereon_evasuite.Dataset import Dataset
#    -- The class for different evaluation modes:
from hereon_evasuite.EVALmode import CompareRAW, EvalRAW
from hereon_evasuite.DataMiningGD import DataMiningGridded, DataMiningStation
#    -- The class for the different programs:
from hereon_evasuite.Prog_CDONCO import CDO, NCO, NCSYS
from hereon_evasuite.Prog_Masking import PyRegionmask
from hereon_evasuite.Prog_PyXarray_PyVis import PyXarray
from hereon_evasuite.GeneralUtils import SuiteUtilities
from hereon_evasuite.visual_main import Cartopy_Visualization
from hereon_evasuite.utils_data_transfer import WPDataCopier

GenUti = SuiteUtilities()

# -- Activate logger:
logger = get_logger()
logger_fname = 'log_EvaSuite.txt'

################################################################################
#                                    MAIN PROGRAM (START)
################################################################################


class EvaSuite:
    @log_function_name
    def __init__(
        self: 'EvaSuite',
        sysset: Dict[str, Any],
        cfggen: Dict[str, Any],
        evaldata_settings: Dict[str, Any],
        proofdata_settings: Dict[str, Any],
        main_cfgfiles: List[str],
        visual_settings: Dict[str, Union[None, str]],
    ) -> None:
        """
        Initialize the EvaSuite framework with system, dataset, and visualization settings.

        This constructor:
        ----------------------------
            - Stores all system, dataset, and visualization configurations for later use.
            - Prepares EvaSuite to run evaluations by loading paths, processing options,
              and visualization configuration files.
            - Serves as the central hub for managing data flow between system-level settings,
              evaluation datasets, and proof/reference datasets.

        Args:
        ----------------------------
            sysset (dict[str, Any]):
                System configuration settings, typically loaded from `evasuite.sysconf.yaml`.
                Defines program dependencies, environment paths, and default operational settings.
            cfggen (dict[str, Any]):
                General EvaSuite configuration. Contains parameters for evaluation mode,
                global options, and processing flags.
            evaldata_settings (dict[str, Any]):
                Configuration for the evaluation dataset(s), including paths, variables,
                and preprocessing details.
            proofdata_settings (dict[str, Any]):
                Configuration for the proof/reference dataset(s), including paths, variables,
                and preprocessing details.
            main_cfgfiles (list[str]):
                Paths to the main configuration files in YAML format. Usually includes
                the general configuration, evaluation dataset configuration, and proof dataset configuration.
            visual_settings (dict[str, str | None]):
                Visualization configuration file paths for:
                  - Maps
                  - 1D plots
                  - Taylor diagrams
                Values are file paths or None to use defaults.

        Returns:
        ----------------------------
            None

        Notes:
        ----------------------------
            - This method only stores configurations; it does not execute evaluation logic.
            - The `visual_settings` dictionary allows partial specification; missing entries
              will fall back to default visualization settings.
        """
        self.sysset = sysset
        self.cfggen = cfggen
        self.cfggendm = cfggen["datamining"]
        self.evalset = evaldata_settings
        self.proofset = proofdata_settings
        self.vis_settings = visual_settings

        # -- Check if config files are consistent to program version:
        self.main_cfgfiles = main_cfgfiles

        # -- Define the possible values for program structures:
        self.supported_EVAL_modes: Dict[str, Type] = {
            "CompareRAW": CompareRAW,
            "EvalRAW": EvalRAW,
        }

        supported_grid_types: Dict[str, Type] = {
            "gridded": DataMiningGridded,
            "station": DataMiningStation,
        }

        supported_MaskingProg: Dict[str, Type] = {
            "PyRegionmask": PyRegionmask,
        }
        supported_DataDumpProcessProgs: Dict[str, Type] = {
            "cdo": CDO,
            "nco": NCO,
            "ncsys": NCSYS,
            "pyxarray": PyXarray,
        }

        # -- Check the configuration files for appearance of pre-default switches:
        #    part of settings in dictionaries self.cfggen and self.cfggendm
        #    can be changed depending on if statments:
        self.PreDefaults()

        # -- Defining the directory structure and clean it depending on CONFIGS:
        self.DefineDataStructure()

        # -- Initialize the data processing and data dump programs (the user
        #    chose the main program to use, but for specfic tasks the program
        #    used is hardcoded):
        self.DataProgsToUse: Dict[str, Union[CDO, NCO, NCSYS, PyXarray]] = {}

        for prog_name in self.sysset["DataDumpProcess_programs"].keys():
            class_name = supported_DataDumpProcessProgs[prog_name]
            self.DataProgsToUse[prog_name] = class_name(
                self.sysset["DataDumpProcess_programs"][prog_name],
                eval_suite_wdir = self.workdir_Eva,
            )

        # -- Initialize at the end the masking programs because of its dependencies:
        maskingprog = list(self.sysset["Masking_program"].keys())[0]
        self.MaskProgToUse = supported_MaskingProg[maskingprog](
            self.sysset["Masking_program"][maskingprog],
        )

        # -- Initialization of namelist_checker:
        namelist_checker = Control_namelists(
            cfggen=self.cfggen,
            cfggendm=self.cfggendm,
            sysset=self.sysset,
            proofset=self.proofset,
            evalset=self.evalset,
            supported_EVAL_modes=self.supported_EVAL_modes,
            eval_metrics=self.cfggen.get("eval_metrics", [])
        )
        # -- Check some user settings regarding the lists for data2proof and evaldata:
        namelist_checker.CheckUserSetting(
            supported_MaskingProg,
            supported_DataDumpProcessProgs,
            maskingprog,
        )

        # -- Initialize the operator classes needed for the dataset's grid types:
        grid_types_user = []
        datsetlist = self.cfggen["data2proof_acronyms"] + self.cfggen["evaldata_acronyms"]
        for datasetname in datsetlist:
            if datasetname in list(self.proofset.keys()):
                grid_types_user.append(self.proofset[datasetname]["gridtype"])
            if datasetname in list(self.evalset.keys()):
                grid_types_user.append(self.evalset[datasetname]["gridtype"])
        grid_types_user = list(set(grid_types_user))

        assert set(grid_types_user).issubset(set(supported_grid_types.keys())), \
            "One dataset carries a grid type unknown to the data operators implemented yet."

        # -- Create dictionary for DataMiningGD mining object and initialization of them:
        self.DataMiningGD: Dict[str, Union[DataMiningGridded, DataMiningStation]] = {}
        for grid_type_char, grid_type_class in supported_grid_types.items():
            if grid_type_char in grid_types_user:
                self.DataMiningGD[grid_type_char] = grid_type_class()

        # -- Allocate the datasets to be preprocessed:
        self.datasetsToProof: list[Any] = []
        self.datasetsEval: list[Any] = []

    @log_function_name
    def PreDefaults(self: 'EvaSuite') -> None:
        """
        Initialize default values in configuration dictionaries if not explicitly set by the user.

        This method sets fallback values for various configuration switches in the `cfggen` and
        `cfggendm` dictionaries. It uses `GenUti.safe_access_bib()` to safely test if a key exists
        or is set to `None`, and fills it with a default value if needed.

        This allows the evaluation suite to run with minimal user configuration,
        by predefining reasonable defaults for optional parameters.

        Affected configuration keys:
        ----------------------------
        - cfggen:
            - eval_RecompVar_type → default: False

        - cfggendm:
            - targetdom_horizontal → default: False
            - targetdom_vertical → default: False
            - subregions_reload → default: False
            - addDS_on_targrid_hori → default: False
            - mask_Orography → default: None
            - mask_dataf_Orography → default: None
            - mask_landsea → default: None
            - mask_dataf_landsea → default: None
            - target_RollingMean → default: None
        """
        # -- Local function for switches default values:
        def __set_default_if_none(
            config: Dict[str, Any],
            key: str,
            default: Any,
        ) -> None:
            """
            Set a default value for a dictionary key if it is not set or is None.

            Parameters:
                config (dict): The configuration dictionary to update.
                key (str): The key to check and potentially set.
                default (Any): The default value to assign if the key is missing or None.
            """
            values = GenUti.safe_access_bib(
                dicttest = config, dictkey = key, errhandle = False
            )
            if values is None:
                config[key] = default

        # -- Check values in namelists:
        #    CFGGEN:
        __set_default_if_none(self.cfggen, "eval_RecompVar_type", False)
        #    CFGGENDM:
        __set_default_if_none(self.cfggendm, "targetdom_horizontal", False)
        __set_default_if_none(self.cfggendm, "targetdom_vertical", False)
        __set_default_if_none(self.cfggendm, "subregions_reload", False)
        __set_default_if_none(self.cfggendm, "addDS_on_targrid_hori", False)
        __set_default_if_none(self.cfggendm, "mask_Orography", None)
        __set_default_if_none(self.cfggendm, "mask_dataf_Orography", None)
        __set_default_if_none(self.cfggendm, "mask_landsea", None)
        __set_default_if_none(self.cfggendm, "mask_dataf_landsea", None)
        __set_default_if_none(self.cfggendm, "target_RollingMean", None)

    @log_function_name
    def DefineDataStructure(self: 'EvaSuite') -> None:
        """
        Initializes or cleans the EvaSuite working directory structure based on configuration.

        This function prepares the necessary directories and cleans up existing data
        depending on the value of `eval_StartingPoint` in the general configuration (`cfggen`).

        Modes:
        -------
            - "cleanall":
                Completely removes the entire working directory (`eval_workdir`)
                and any stored metadata (e.g., `saveDSmetadata.bib.npy`).
            - "StartEvaCompute":
                Removes only result-related files (plots, evaluation data) while retaining
                prepared input data and optionally subregion masks.
            - Otherwise:
                Raises an error for unrecognized starting modes.

        Directories created:
        ---------------------
            - `eval_workdir` (main working directory)
            - Subdirectories within `eval_workdir`:
                - `directory_visualize` (for plots and visualizations)
                - `directory_datamining` (for processed evaluation data)
                - `directory_maskregions` (for subregion masks)
            - Optional: `eval_backup_dir` if defined

        Configuration keys used:
        -------------------------
            - `eval_StartingPoint`
            - `eval_workdir`
            - `directory_visualize`
            - `directory_datamining`
            - `directory_maskregions`
            - `directoryDM_WPcompeval` (list of two subdirectories under `datamining`)
            - `eval_standalone_visual` (skip setup if True)
            - `eval_backup_dir` (optional backup directory)
            - `cfggendm['subregions_reload']` (controls whether subregion masks are preserved)

        Logging:
        --------
            - Logs all cleanup and setup operations for debugging and reproducibility.

        Raises:
        -------
            - ValueError: If `eval_StartingPoint` is not a recognized value.
        """
        self.StartingPoint = self.cfggen["eval_StartingPoint"]
        self.rootdir_Eva = os.getcwd()
        self.workdir_Eva = self.cfggen["eval_workdir"]
        self.visualdir_Eva = os.path.join(self.workdir_Eva, self.cfggen["directory_visualize"])
        self.datadir_Eva = os.path.join(self.workdir_Eva, self.cfggen["directory_datamining"])
        self.subregdir_Eva = os.path.join(self.workdir_Eva, self.cfggen["directory_maskregions"])

        self.storageMetaDS_bib = os.path.join(self.workdir_Eva, "saveDSmetadata.bib")

        if not self.cfggen.get('eval_standalone_visual', False):
            if self.StartingPoint == "cleanall":
                logger.info('Cleanall - Cleaning the complete Evaluation directory')
                # Remove the whole workdir and metadata file if they exist
                if os.path.exists(self.workdir_Eva):
                    shutil.rmtree(self.workdir_Eva)
                if os.path.exists(self.storageMetaDS_bib + ".npy"):
                    os.remove(self.storageMetaDS_bib + ".npy")

            elif self.StartingPoint == "StartEvaCompute":
                logger.info("StartEvaCompute - Cleaning only result files from former Evaluation")

                log_file_path = os.path.join(self.workdir_Eva, logger_fname)
                if os.path.exists(log_file_path):
                    os.remove(log_file_path)

                for subdir in self.cfggen['directoryDM_WPcompeval']:
                    wp_path = os.path.join(self.datadir_Eva, subdir)
                    if os.path.exists(wp_path):
                        shutil.rmtree(wp_path)

                if os.path.exists(self.visualdir_Eva):
                    shutil.rmtree(self.visualdir_Eva)

                if not self.cfggendm.get("subregions_reload", True):
                    if os.path.exists(self.subregdir_Eva):
                        shutil.rmtree(self.subregdir_Eva)
            else:
                raise ValueError(
                    'Invalid "eval_StartingPoint" setting in the general configuration. '
                    'Check your "eval_StartingPoint" settings in the general config.'
                )

            logger.info('Create directories, identify host and initialize instances.')

            if self.cfggen["eval_backup_dir"]:
                os.makedirs(self.cfggen["eval_backup_dir"], exist_ok=True)

            os.makedirs(self.workdir_Eva, exist_ok=True)
            os.makedirs(self.datadir_Eva, exist_ok=True)
            os.makedirs(self.visualdir_Eva, exist_ok=True)
            os.makedirs(self.subregdir_Eva, exist_ok=True)
        else:
            logger.info("All data were saved")

            # -- Clean data from preparation folders:
            for subdir in self.cfggen['directoryDM_WPprepare']:
                wp_path = os.path.join(self.datadir_Eva, subdir)
                if os.path.exists(wp_path):
                    shutil.rmtree(wp_path)

    @log_function_name
    def ConfigDatasets(self: 'EvaSuite') -> None:
        """Initialize the instances for the datasets and create directories"""
        #
        logger.info('Initialize dataset instances and create dirs.')
        #
        additHorTargrid = GenUti.check_for_list(self.cfggendm["addDS_on_targrid_hori"])
        for datasetname in self.cfggen["data2proof_acronyms"]:
            if ((datasetname == self.cfggendm["targetgrid_horizontal"]) or
                    (GenUti.search_string_list(list(additHorTargrid), datasetname))):
                eval_refgridhor = True
            else:
                eval_refgridhor = False

            if datasetname == self.cfggendm["targetgrid_vertical"]:
                eval_refvertb = True
            else:
                eval_refvertb = False

            if datasetname == self.cfggendm["targetgrid_horizontal"]:
                eval_origrefgrid = True
            else:
                eval_origrefgrid = False

            for evalpars in self.cfggen["eval_parameters"]:
                GenUti.safe_access_bib(
                    f"Could not access parameter {evalpars} in {datasetname}.",
                    KeyError,
                    dicttest = self.proofset[datasetname]["paramdict"],
                    dictkey = evalpars,
                    errhandle = True,
                )
            # -- Initialization of Dataset --> name Data2Proof
            datasetnew = Dataset(
                datasetname,
                "Data2Proof",
                settingsDataset = self.proofset[datasetname],
                evalparas = self.cfggen["eval_parameters"],
                eval_refgridhor = eval_refgridhor,
                eval_origrefgrid = eval_origrefgrid,
                eval_refvertb = eval_refvertb,
                eval_timerefgrid = None,
                checkAR = True,
            )
            self.datasetsToProof.append(datasetnew)

        for datasetname in self.cfggen["evaldata_acronyms"]:
            if (datasetname == self.cfggendm["targetgrid_horizontal"]) or \
               (GenUti.search_string_list(list(additHorTargrid), datasetname)):
                eval_refgridhor = True
            else:
                eval_refgridhor = False

            if datasetname == self.cfggendm["targetgrid_vertical"]:
                eval_refvertb = True
            else:
                eval_refvertb = False

            if datasetname == self.cfggendm["targetgrid_horizontal"]:
                eval_origrefgrid = True
            else:
                eval_origrefgrid = False

            for evalpars in self.cfggen["eval_parameters"]:
                GenUti.safe_access_bib(
                    f"Could not access parameter {evalpars} in {datasetname}.",
                    KeyError,
                    dicttest = self.evalset[datasetname]["paramdict"],
                    dictkey = evalpars,
                    errhandle = True,
                )
            # -- Initialization of Dataset --> name EvalData
            datasetnew = Dataset(
                datasetname,
                "EvalData",
                settingsDataset = self.evalset[datasetname],
                evalparas = self.cfggen["eval_parameters"],
                eval_refgridhor = eval_refgridhor,
                eval_origrefgrid = eval_origrefgrid,
                eval_refvertb = eval_refvertb,
                eval_timerefgrid = None,
                checkAR = True,
            )
            self.datasetsEval.append(datasetnew)

        for datasets in self.datasetsEval + self.datasetsToProof:
            datasets.createDirs(
                self.datadir_Eva, self.cfggen["directoryDM_WPprepare"],
            )

    @log_function_name
    def PrepareDatasets(self: 'EvaSuite') -> None:
        """Prepare Datasets in such a way that all relevant times are in one file"""
        #
        logger.info(
            'Prepare each dataset to end up with all relevant parameters '
            'and time of interest in one file.')
        for datasets in self.datasetsToProof + self.datasetsEval:
            logger.info(f'Starting with dataset {datasets.getName()}')
            tag = "heute"
            if tag == "heute":
                # -- This is the variant with cdo-filework and xarray-helpers
                #    it is not nice and has to be replaced by "morgen"
                logger.info(
                    'Identify and Tailor relevant files (params '
                    'and time period / season of interest) ... ')
                datasets.IdentifyAndCutRelevantFiles(
                    evalparas = self.cfggen["eval_parameters"],
                    cfgdatamining = self.cfggendm,
                    DataProgsToUse = self.DataProgsToUse,
                    resultdir = datasets.getSubDirs()[0],
                    posdimnames = self.cfggen["PossibleDimNames"],
                )
                logger.info(
                    f'Determine the effort for later repairing of '
                    f'the processed files {datasets.getName()}')
                datasets.DetectRepairEffort(
                    self.cfggen["eval_parameters"],
                    self.cfggen["RepairNetcdf_variables"],
                    self.cfggen["RepairNetcdf_attributes"],
                    self.DataProgsToUse,
                    filelist = datasets.getRelevantFiles_ForRepair(),
                    Repair_TargGrid = self.cfggen["RepairNetcdf_targetgrid"],
                )
                logger.info(
                    'Merge of relevant and tailored files... {datasets.getName()}')
                datasets.MergeRelevantFiles(
                    self.DataProgsToUse, resultdir = datasets.getSubDirs()[0],
                )
            elif tag == "morgen":
                # -- This is the variant with xarray-only;
                #    it is much more elegant but leads to crashes on mistral:
                logger.info(
                    'Identify files with parameters of interest '
                    'and merge them for the period of interest ... ')
                datasets.IdentifyRelevantMergeTime(
                    evalparas = self.cfggen["eval_parameters"],
                    cfgdatamining = self.cfggendm,
                    DataProgsToUse = self.DataProgsToUse,
                    resultdir = datasets.getSubDirs()[0],
                    posdimnames = self.cfggen["PossibleDimNames"]
                )
            logger.info(f'Finished for dataset {datasets.getName()}')

    @log_function_name
    def UniqueGridforAllDatasets(self: 'EvaSuite') -> None:
        """ Interpolate all data sets to the same grid """
        self.interpol_refgridf = None
        self.interpol_refgridtype = None
        self.interpol_refvertf = None
        self.interpol_reflevtype = None
        self.interpol_refevalpars = None

        # -- Define CDO program:
        cdo_prog = self.DataProgsToUse.get("cdo")
        if not isinstance(cdo_prog, CDO):
            raise TypeError("Expected 'cdo' to be a CDO instance")

        logger.info(
            f'Each dataset is interpolated to the final evaluation grid, '
            f'user-specification: {self.cfggendm["targetgrid_horizontal"]} '
            f'(horizontal) and {self.cfggendm["targetgrid_vertical"]} (vertical)'
        )

        for datasets in self.datasetsToProof + self.datasetsEval:
            logger.info(f'Repairing dataset {datasets.getName()}')
            datasets.RepairNcdfVarsAndAttributes(
                self.DataProgsToUse,
                cdo_prog.repairlevel,
                filelist = datasets.getPreparedFiles(),
            )
            logger.info('Repair finished')

            # -- Define the reference grid for interpolation:
            if datasets.getOrigRefgrid():
                self.interpol_refgridf = datasets.getPreparedFiles()[0]
                self.interpol_refgridtype = datasets.getGridtype()
                logger.info(
                    f'Reference horizontal grid detected: interpolation '
                    f'based on grid from {self.interpol_refgridf}')

            if datasets.getRefVert():
                self.interpol_refvertf = datasets.getPreparedFiles()[0]
                self.interpol_reflevtype = datasets.getLevtype()
                self.interpol_refevalpars = datasets.getVarNamelist(
                    self.cfggen["eval_parameters"]
                )
                logger.info(
                    f'Reference vertical grid detected: interpolation '
                    f'based on grid from {self.interpol_refvertf}')

        for datasets in self.datasetsToProof + self.datasetsEval:
            logger.info(f'Interpolating dataset {datasets.getName()}')
            datasets.ChangeVertHoriGrid(
                self.cfggendm,
                self.DataMiningGD,
                self.DataProgsToUse,
                self.interpol_refgridf,
                self.interpol_refgridtype,
                self.interpol_refvertf,
                self.interpol_reflevtype,
                self.cfggen["eval_parameters"],
                self.interpol_refevalpars,
                resultdir = datasets.getSubDirs()[1],
            )
            logger.info('Interpolation finished')

        for datasets in self.datasetsToProof + self.datasetsEval:
            logger.info(
                'Determine the effort for later repairing of the processed files '
                f'{datasets.getName()}'
            )

            datasets.DetectRepairEffort(
                self.cfggen["eval_parameters"],
                self.cfggen["RepairNetcdf_variables"],
                self.cfggen["RepairNetcdf_attributes"],
                self.DataProgsToUse,
                filelist = datasets.getRelevantFiles_ForRepair(),
                Repair_TargGrid = self.cfggen["RepairNetcdf_targetgrid"],
            )

    @log_function_name
    def StoreDSMetaData(self: 'EvaSuite') -> None:
        """
        Store metadata of prepared datasets for later reuse or reruns.

        This method collects key information from all datasets involved in the current
        evaluation (both `dataToProof` and `dataForEval`) and saves them into a
        NumPy `.npy` file. This enables faster restarts or debugging in repeated runs.

        The metadata for each dataset includes:
        - Dataset type (`typeEP`): Whether it is reference or evaluation data.
        - Grid type (`typeGRID`): Gridded or station-based.
        - Grid matching status (`eval_refgridhor`, `eval_origrefgrid`): Flags related to horizontal regridding.
        - Protected variable names and attributes used during evaluation.
        - A list of recent files used or generated (`RecentResFiles`).

        Example output structure saved in the `.npy` file:
        ```python
        {
            'MIROC6-monthly': {
                'typeEP': 'Data2Proof',
                'typeGRID': 'gridded',
                'eval_refgridhor': True,
                'eval_origrefgrid': False,
                'Protect_VarNames': {},
                'Protect_Attributes': [],
                'RecentResFiles': [
                    '/path/.../hfls_Amon_MIROC6_..._FinalEvalGrid.nc'
                ]
            },
            'ERA5-monthly': {
                'typeEP': 'EvalData',
                'typeGRID': 'gridded',
                'eval_refgridhor': True,
                'eval_origrefgrid': True,
                'Protect_VarNames': {},
                'Protect_Attributes': [],
                'RecentResFiles': [
                    '/path/.../ERA5-monthly_Merged_FinalEvalGrid.nc'
                ]
            }
        }
        ```

        Notes
        -----
        - The save location is defined by `self.storageMetaDS_bib`.
        - This mechanism is essential for reproducibility and caching in EvaSuite.
        """
        logger.info('Store information about prepared datasets for a re-run')
        save_fname = self.storageMetaDS_bib
        dict_allDS: Dict[str, Any] = {}
        for datasets in self.datasetsToProof + self.datasetsEval:
            dict_allDS[datasets.getName()] = datasets.StoreDSMetaDataInFile()
        np.save(save_fname, dict_allDS)

    @log_function_name
    def LoadDSMetaData(self: 'EvaSuite') -> None:
        """ Reload numpy-saved metadata about already prepared data sets """
        logger.info('Reload information from a former evaluation run')
        loaded_allDSmeta = np.load(
            self.storageMetaDS_bib + '.npy',
            allow_pickle = True,
        )
        for datasets in self.datasetsToProof + self.datasetsEval:
            try:
                datasets.LoadDSMetaDataFromFile(
                    loadedDSbib = loaded_allDSmeta.item().get(datasets.getName())
                )
            except TypeError:
                logger.error(
                    'You try to load data from a former evaluation '
                    'but not consistent to the recent dataset settings.')
                raise ValueError(
                    "Inconsistent evaluation state detected. Use the 'cleanall' option to reset."
                )

    @log_function_name
    def EvalModeInit(self: 'EvaSuite') -> None:
        """Initialize the user-specified evaluation mode and the related directories"""
        self.EVALmode = self.supported_EVAL_modes[self.cfggen["eval_Mode"]](
            self.DataProgsToUse,
            self.DataMiningGD,
            self.MaskProgToUse,
            self.datasetsToProof,
            self.datasetsEval,
            self.cfggen,
            self.datadir_Eva,
            self.visualdir_Eva,
            self.subregdir_Eva,
            self.vis_settings,
        )

    @log_function_name
    def EvalCompute(self: 'EvaSuite') -> None:
        """Perform calculations w.r.t. the user-specified Eval_mode and the
           corresponding metrics
        """
        logger.info(
            f'Start the user-specified evaluation using the Eval_mode {self.cfggen["eval_Mode"]}')
        # -- Preassign the Working steps with class methods:
        bib_WorkingStepClasses = {
            # -- working steps shared fully or partly by the EvalModes:
            "DerivedQuantity": self.EVALmode.DerivedQuantity,
            "CombineInitReferenceDatasets": self.EVALmode.CombineInitReferenceDatasets,
            "CreateLoadSubRegMasks": self.EVALmode.CreateLoadSubRegMasks,
            "UnifyFreq": self.EVALmode.UnifyFreq,
            # -- now really and unique specific working steps for each EVALmode
            "DetermineMetrics": self.EVALmode.DetermineMetrics,
            "AggregDims": self.EVALmode.AggregDims
        }
        for Workingsteps in self.cfggen["EVAL_modes_setup"][self.cfggen["eval_Mode"]]["WorkingSteps"]:
            bib_WorkingStepClasses[Workingsteps]()

    @log_function_name
    def Visualization(self: 'EvaSuite') -> None:
        """Visualize the evaluation results depending on the user-specified Eval_mode"""
        logger.info(
            'Visualize the evaluation results depending on '
            f'the Eval_mode {self.cfggen["eval_Mode"]}'
        )
        self.EVALmode.Visualization()

    @log_function_name
    def Finalize(self: 'EvaSuite') -> None:
        """Save the results to a directory called as the hashsum of the config files"""
        os.chdir(self.rootdir_Eva)
        logger.info(
            f'   Configs are stored in users working directory {self.workdir_Eva}')
        sp.check_call(
            ["sh", "-c", "cp -R " + ' '.join(self.main_cfgfiles) + " " + \
                logger_fname + " " + self.workdir_Eva]
        )
        if (self.cfggen["eval_backup"]) and (self.cfggen["eval_backup_dir"] is None):
            # -- Create a directory unique w.r.t. the configuration settings:
            hashtagint = 0
            for fname in self.main_cfgfiles:
                hashtagint = (
                    hashtagint +
                    int(hashlib.sha256(open(fname, 'rb').read()).hexdigest(), 16)
                )
            startdate_tag = pd.Timestamp(
                self.cfggendm["targettime_fullspan"][0]).strftime('%Y-%m-%d')
            enddate_tag = pd.Timestamp(
                self.cfggendm["targettime_fullspan"][1]).strftime('%Y-%m-%d')
            savedir = (
                f"{self.workdir_Eva.rstrip('/')}_Evaldatset_"
                f"{'_'.join(GenUti.check_for_list(self.cfggen['evaldata_acronyms']))}/"
                f"{'_'.join(GenUti.check_for_list(self.cfggen['eval_parameters']))}__"
                f"{self.cfggen['eval_Mode']}__"
                f"{startdate_tag}_to_{enddate_tag}__"
                f"{self.cfggendm['aggregate_temporal']}__{hex(hashtagint)}"
            )
            #
            if not os.access(savedir, os.F_OK):
                logger.info(
                    f'Configs and Final visualizations are stored in '
                    f'hashtagged-directory "{savedir}"')
                sp.check_call(["mkdir", "-p", savedir])
            else:
                logger.info(
                    f'Configs and Final visualizations are not unique. '
                    f'Directory "{savedir}" already exists.'
                )
                logger.info('--> overwrite files')
            # -- Move all config files, the logging and results:
            sp.check_call(
                ["sh", "-c", "cp -R " + ' '.join(self.main_cfgfiles) + " " + logger_fname + " " + savedir])
            sp.check_call(
                ["sh", "-c", "cp -R " + self.visualdir_Eva + " " + savedir])

        elif self.cfggen.get("eval_backup") and self.cfggen.get("eval_backup_dir"):
            savedir = self.cfggen["eval_backup_dir"]
            logger.info(f'Configs and final results are stored in directory "{savedir}"')
            # -- Initialization of helper class:
            copier_helper = WPDataCopier(cfggen = self.cfggen)
            # -- Copy WP03 and WP04 data in a backup:
            copier_helper.wp_data_transfer(self.datadir_Eva, savedir)
            # -- Copy config files in a backup:
            copier_helper.logs_data_transfer(self.main_cfgfiles, savedir)
            # -- Copy visualization files in a backup:
            copier_helper.plots_data_transfer(self.visualdir_Eva, savedir)

        else:
            logger.info('The user did not ask for a backup.')
        logger.info('BYE')


def main() -> None:
    """
    Main entry point for running the EvaSuite application.

    This function:
    ----------------------------
      - Parses command-line arguments.
      - Loads system, general, and dataset-specific configurations.
      - Initializes the EvaSuite workflow with loaded settings.
      - Executes the selected evaluation tasks.
      - Handles any exceptions and logs appropriate error messages.

    Returns:
    ----------------------------
        None

    Side Effects:
    ----------------------------
        - Reads configuration files from disk.
        - Writes log messages to the configured logger.
        - May create output files, plots, or reports depending on settings.
        - Exits the program with a non-zero status code if an error occurs.
    """
    # -- Initialization of parser:
    inpar = Init_parser()
    # -- Defining possible options and parse the console input:
    optionss = inpar.handlingparser()
    # -- System configuration treatment:
    sysconfigf = resource_filename(
        Requirement.parse('hereon_evasuite'),
        'hereon_evasuite/system/evasuite.sysconf.yaml'
    )

    if optionss["CFGSYS"] is None:
        if os.access(sysconfigf, os.F_OK):
            logger.info(f"Location of system settings: {sysconfigf}")
            with open(sysconfigf) as yaml_file:
                sysset = yaml.load(yaml_file, Loader = yaml.FullLoader)
        else:
            raise Exception("There is no installation of a system settings file")
    else:
        logger.info(
            'Using a user-specific configuration file for external programs.')
        if os.access(optionss["CFGSYS"][0], os.F_OK):
            with open(optionss["CFGSYS"][0]) as yaml_file:
                sysset = yaml.load(yaml_file, Loader = yaml.FullLoader)
        else:
            raise Exception("The user-specific system settings was not found.")

    # -- Handling options which imply a printout:
    inpar.optionsprints(optionss, sysset)
    # -- Input configurations and databases:
    main_cfgfiles = [
        optionss["CFGGEN"][0],
        optionss["INPREF"][0],
        optionss["INPMOD"][0],
    ]
    assert all([i is not None for i in main_cfgfiles]), \
        "not all database and config files are given"

    with open(optionss["CFGGEN"][0]) as yaml_file:
        cfggen = yaml.load(
            yaml_file, Loader = yaml.FullLoader)
    with open(optionss["INPREF"][0]) as yaml_file:
        evaldata_settings = yaml.load(
            yaml_file, Loader = yaml.FullLoader)
    with open(optionss["INPMOD"][0]) as yaml_file:
        proofdata_settings = yaml.load(
            yaml_file, Loader = yaml.FullLoader)

    # -- Create cmor table based on input model and reference datasets:
    cmor_path = cfggen.get('eval_cmor_table')
    cmor_table = Cmor_generator(proofdata_settings, evaldata_settings, cmor_path)
    cmor_table.create_cmor_table()

    # -- Check visualization context:
    eva_standalone_visual = cfggen.get('eval_standalone_visual')
    inpar.log_visual_config_info(optionss, cfggen.get('eval_create_Taylor_plots'))

    # -- Create dictionary with visual settings:
    visual_settings = {
        "PLOTCONFIG": optionss["PLOTCONFIG"],
        "MAPCONFIG": optionss["MAPCONFIG"],
        "TAYLORCONFIG": optionss["TAYLORCONFIG"],
    }

    # -- Running model
    # -- Initialization of EvaSuite:
    EVAL_suite = EvaSuite(
        sysset,
        cfggen,
        evaldata_settings,
        proofdata_settings,
        main_cfgfiles,
        visual_settings,
    )
    if eva_standalone_visual is False:
        logger.info('The user is using a main run of EvaSuite')
        EVAL_suite.ConfigDatasets()
        if cfggen["eval_StartingPoint"] == "cleanall":
            EVAL_suite.PrepareDatasets()
            EVAL_suite.UniqueGridforAllDatasets()
            EVAL_suite.StoreDSMetaData()

        elif cfggen["eval_StartingPoint"] == "StartEvaCompute":
            EVAL_suite.LoadDSMetaData()

        EVAL_suite.EvalModeInit()
        EVAL_suite.EvalCompute()
        EVAL_suite.Visualization()
        EVAL_suite.Finalize()

    else:
        logger.info('The user is using a standalone visualization version of EvaSuite')

        # -- Load logical operators:
        visual_paths = cfggen.get('eval_path')
        # -- Values control:
        if visual_paths is None:
            raise ValueError('Please check values of "eval_path" in cfggen YAML file')

        if not isinstance(visual_paths, list):
            raise TypeError('Please check type of "eval_path" in cfggen YAML file')

        # -- Initialization of new visualization:
        cartopy_visual = Cartopy_Visualization(visual_settings, cfggen)
        # -- Run visualization:
        cartopy_visual.visual_main(visual_paths, eva_standalone_visual)
        # -- Copy figures:
        EVAL_suite.Finalize()


if __name__ == "__main__":
    # ------------------------- The main program ---------------------------
    main()
