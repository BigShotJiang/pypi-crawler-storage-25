# EvaSuite
#
# ---------------------------------------------------------------
# Copyright (C) 2004-2025, Hereon
# Contact information: beate.geyer@hereon.de, imktro-climate-modelling@lists.kit.edu
# See AUTHORS.TXT for a list of authors
# See LICENSES/ for license information
# SPDX-License-Identifier: Apache-2.0
# ---------------------------------------------------------------


# ---------------------------------------------------------------
#    History:
#    Version    Date       Name
#    ---------- ---------- ----
#    1.1        07.2025   Evgenii Churiulin, IMKTRO
#                         Initial realise
# ---------------------------------------------------------------
from typing import Dict
from hereon_evasuite.log_EvaSuite import get_logger, log_function_name
logger = get_logger()


class AggregationSupport:
    """Utility class for converting aggregation keywords to xarray-compatible frequencies."""

    def __init__(self: 'AggregationSupport') -> None:
        """
        Initialize supported base frequency mappings.

        Simple frequency forms (mapped directly):
        ----------------------------
            - "yearly"   → "A"      (Annual frequency, year-end)
            - "seasonal" → "Q-NOV"  (Quarterly, ending in November)
            - "monthly"  → "M"      (Month-end)
            - "weekly"   → "W"      (Weekly)
            - "daily"    → "D"      (Daily)
            - "hourly"   → "H"      (Hourly)

        Simple supported mappings:
        ----------------------------
            - "seasonaloverperiod" → "season"
            - "monthlyoverperiod"  → "month"
            - "weeklyoverperiod"   → "week"
            - "dailyoverperiod"    → "day"
            - "hourlyoverperiod"   → "hour"
        """
        self.base_freq_map: Dict[str, str] = {
            "yearly": "A",
            "seasonal": "QE-NOV",
            "monthly": "M",
            "weekly": "W",
            "daily": "D",
            "hourly": "H",
        }

        self.groupby_map: Dict[str, str] = {
            "seasonaloverperiod": "season",
            "monthlyoverperiod": "month",
            "weeklyoverperiod": "week",
            "dailyoverperiod": "day",
            "hourlyoverperiod": "hour",
        }

    @log_function_name
    def ConvertAggregKey2Groupby(self: 'AggregationSupport', groupby_time = None) -> str:
        """
        Converts a temporal aggregation keyword to an xarray groupby-compatible string.

        Parameters:
        ----------------------------
            groupby_time (str): The keyword to convert.

        Returns:
        ----------------------------
            str: The corresponding groupby-compatible key.

        Raises:
        ----------------------------
            ValueError: If the keyword is unsupported or missing.
        """
        if groupby_time is None:
            raise ValueError("No groupby_time keyword was provided.")

        key = groupby_time.strip().lower()
        if key not in self.groupby_map:
            raise ValueError(
                f"Unsupported groupby keyword: '{groupby_time}'. Supported options are: {list(self.groupby_map.keys())}"
            )
        logger.info(f"Using groupby frequency: '{groupby_time}' → '{self.groupby_map[key]}'")
        return self.groupby_map[key]

    @log_function_name
    def ConvertAggregKey2Resample(self: 'AggregationSupport', resample_freq: str) -> str:
        """
        Convert a temporal aggregation keyword into an xarray-compatible resample frequency string.

        Supports:
        ----------------------------
        - Simple formats: "monthly", "yearly"
        - Compound formats: "2-monthly" → "2M", "3-seasonal" → "3Q-NOV"
        - Handles minor formatting: " 2 - monthly "

        Parameters:
        ----------------------------
            resample_freq (str): Frequency keyword from user/configuration, e.g. "monthly" or "3-monthly".

        Returns:
        ----------------------------
            str: xarray-compatible frequency string (e.g., "M", "3M", "Q-NOV").

        Raises:
        ----------------------------
            ValueError: If the format is incorrect or contains unsupported keywords.
        """
        parts = resample_freq.split("-")

        # -- Case 1: Simple frequency keyword (e.g., "monthly", "yearly")
        if len(parts) == 1:
            key = parts[0].strip().lower()
            if key not in self.base_freq_map:
                raise ValueError(f"Unsupported resample keyword: {key}")
            result = self.base_freq_map[key]
            logger.info(f"Using simple resample frequency: '{key}' → '{result}'")
            return result

        # -- Case 2: Compound frequency (e.g., "3-monthly", "2-seasonal")
        elif len(parts) == 2:
            number_str, base_key = parts
            number_str = number_str.strip()
            base_key = base_key.strip().lower()

            # -- Ensure the number prefix is a valid integer
            if not number_str.isdigit():
                raise ValueError(f"Invalid frequency number: '{number_str}' in '{resample_freq}'")
            # -- Ensure the base keyword is supported
            if base_key not in self.base_freq_map:
                raise ValueError(f"Unsupported base frequency keyword: {base_key}")

            result = f"{number_str}{self.base_freq_map[base_key]}"
            logger.info(
                f"Using compound resample frequency: '{resample_freq}' → '{result}'"
            )
            return result
        # -- Case 3: Invalid format (more than one dash or malformed string)
        else:
            raise ValueError(f"Invalid resample frequency format: '{resample_freq}'")
