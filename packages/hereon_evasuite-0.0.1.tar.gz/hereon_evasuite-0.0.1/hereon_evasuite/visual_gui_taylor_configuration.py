# EvaSuite
#
# ---------------------------------------------------------------
# Copyright (C) 2004-2025, Hereon
# Contact information: beate.geyer@hereon.de, imktro-climate-modelling@lists.kit.edu
# See AUTHORS.TXT for a list of authors
# See LICENSES/ for license information
# SPDX-License-Identifier: Apache-2.0
# ---------------------------------------------------------------

# ---------------------------------------------------------------
# Program Description:
# Graphical User Interface (GUI) for generating YAML configuration files
# for Taylor diagrams. This interface allows users to define general settings,
# marker styles, figure parameters, and input sample/reference data for multiple
# periods. The output is a validated and consistent YAML configuration used
# for plotting Taylor diagrams.
#
# Main Components:
#
# 1. __init__(self, root)
#    - Initializes the GUI layout and scrollable frame.
#    - Builds all input sections: general settings, markers, figures, stdrefs, samples.
#    - Sets up buttons for refreshing periods, loading examples, and saving settings.
#
# 2. refresh_periods(self)
#    - Parses the user-defined 'periods' from the YAML config field.
#    - Dynamically generates input fields for reference standard deviations and samples.
#
# 3. validate_colors_list(self, colors_list)
#    - Validates that each color string in the list is acceptable for matplotlib.
#    - Raises a ValueError for any invalid color.
#
# 4. pick_color_for_marker(self)
#    - Opens a color picker dialog.
#    - Appends the selected color to the current Marker Colors list.
#
# 5. generate_rects(self, periods)
#    - Automatically generates subplot codes (e.g., 221, 222) based on number of periods.
#    - Ensures a compact layout by optimizing rows and columns.
#
# 6. show_info(self, section)
#    - Displays context-sensitive help information in a popup dialog.
#    - Supports sections: config, basic, marker, figure, stdrefs, samples.
#
# 7. update_marker_fmt_state(self, event=None)
#    - Enables/disables marker format and shape fields based on selected marker mode.
#    - Applies logic: 'text' mode uses format string, 'shape' mode uses marker shapes.
#
# 8. __fill_example_values(self)
#    - Fills the form with predefined default values for all four seasons.
#    - Populates stdrefs, samples, and default marker colors/shapes.
#
# 9. clear_reference_and_samples(self)
#    - Clears all Reference Stdrefs and Sample entries from the form.
#
# 10. _convert_to_number_or_lower(self, value)
#     - Attempts to convert a string to int or float.
#     - Falls back to lowercase string if not convertible.
#
# 11. _is_form_default(self)
#     - Checks whether current form exactly matches the built-in default example.
#     - Used to prevent incorrect use of "Save Default Example".
#
# 12. _quote_special_yaml(self, value)
#     - Ensures YAML compatibility by quoting strings with special characters.
#
# 13. _collect_settings(self, validate_default=False)
#     - Collects and validates all inputs from the GUI.
#     - Constructs a dictionary suitable for YAML export.
#     - Performs consistency checks on markers, colors, and samples.
#
# 14. save_settings(self)
#     - Prompts user for a filename and saves the current form values to a YAML file.
#
# 15. save_default_example(self)
#     - Saves a validated default YAML only if the form matches the predefined example.
# ---------------------------------------------------------------
# -- Import Python modules:
import tkinter as tk
import yaml
import math
import matplotlib.colors as mcolors
from typing import Any, Dict, List, Optional
from tkinter import ttk, filedialog, messagebox
from tkinter import colorchooser


class TaylorSettingsGUI:
    """
    A GUI tool for creating YAML configuration files used in Taylor diagram visualizations.

    This interface allows users to define:
    ----------------------------
    - General figure settings (e.g., title, size, font).
    - Marker styles (mode, format, colors, shapes).
    - Reference standard deviations and sample points for multiple periods.
    - Output preferences (format, DPI, filename).

    Features include:
    ----------------------------
    - Dynamic field generation based on user-defined periods.
    - Real-time validation and highlighting of modified fields.
    - Export options for customized or default example settings.
    """

    def __init__(self, root: tk.Tk) -> None:
        """
        Initializes the Taylor diagram settings GUI.

        Parameters:
        -----------
        root : tk.Tk
            The root Tkinter window instance.

        Actions:
        --------
        - Sets up a scrollable layout using a Canvas and Frame.
        - Creates all static and dynamic sections of the form:
            • Config input (periods)
            • General settings
            • Marker customization
            • Figure parameters
            • Reference standard deviations
            • Sample data inputs
        - Binds dynamic behavior to inputs (e.g., toggles, refresh, color picker).
        - Loads default example values for testing and validation.
        """
        self.root = root
        root.title("Taylor Diagram Settings Creator")

        # -- Scrollable frame setup:
        self.canvas = tk.Canvas(self.root, borderwidth=0, width=1200, height=800)
        self.frame = ttk.Frame(self.canvas)
        self.vsb = tk.Scrollbar(self.root, orient="vertical", command=self.canvas.yview)
        self.hsb = tk.Scrollbar(self.root, orient="horizontal", command=self.canvas.xview)
        self.canvas.configure(yscrollcommand=self.vsb.set, xscrollcommand=self.hsb.set)
        self.vsb.pack(side="right", fill="y")
        self.hsb.pack(side="bottom", fill="x")
        self.canvas.pack(side="left", fill="both", expand=True)
        self.canvas_window = self.canvas.create_window((0, 0), window=self.frame, anchor="nw")
        self.frame.bind(
            "<Configure>",
            lambda event: self.canvas.configure(
                scrollregion=self.canvas.bbox("all")
            )
        )

        # -- Form parts:
        self.entries = {}
        self.stdref_entries = {}
        self.sample_texts = {}
        self.marker_entries = {}
        self.stdref_widgets = []
        self.sample_widgets = []

        # -- Title:
        ttk.Label(
            self.frame,
            text="Taylor Diagram Settings Creator",
            font=("Arial", 16, "bold")
        ).grid(row=0, column=0, columnspan=3, pady=1)

        # -- Config Options (YAML):
        ttk.Label(
            self.frame,
            text="Config Options (YAML):").grid(row=1, column=0, sticky="w")
        self.config_text = tk.Text(self.frame, height=4, width=50)
        # -- Default:
        self.config_text.insert(tk.END, "periods: [winter, spring, summer, autumn]")
        self.config_text.grid(row=1, column=1, columnspan=1, pady=5)
        # -- Help button for Config Options (YAML):
        ttk.Button(
            self.frame,
            text="?",
            width=2,
            command=lambda: self.show_info('config')
        ).grid(row=1, column=2, padx=5)
        # -- Top control buttons:
        # -- Refresh Periods button:
        ttk.Button(
            self.frame,
            text="Refresh Periods",
            command=self.refresh_periods).grid(row=2, column=0, pady=5)
        # -- Load test case button:
        ttk.Button(
            self.frame,
            text="Example Settings",
            command=self.__fill_example_values).grid(row=2, column=1, pady=5)
        # -- Clean test case button:
        ttk.Button(
            self.frame,
            text="Clear Values",
            command=self.clear_reference_and_samples).grid(row=2, column=2, pady=5)

        # -- General Settings Section:
        general_label_row = 3
        ttk.Label(
            self.frame,
            text="General Settings",
            font=("Arial", 12, "bold")
        ).grid(row=general_label_row, column=0, columnspan=3, pady=10, sticky="w")
        # -- Help button
        ttk.Button(
            self.frame,
            text="?",
            width=2,
            command=lambda: self.show_info('basic')
        ).grid(row=general_label_row, column=2, padx=5, sticky="w")
        # -- Basic form fields:
        general_form_fields = [
            ("Figure Subtitle", "subtitle", "Precipitations"),
            ("x95 (comma-separated)", "x95", "0.05,13.9"),
            ("y95 (comma-separated)", "y95", "0.0,71.0"),
            ("x99 (comma-separated)", "x99", "0.05,19.0"),
            ("y99 (comma-separated)", "y99", "0.0,70.0"),
            ("Figure Size (comma-separated)", "figsize", "14,10"),
            ("Title Font Size", "title_fsize", "14"),
        ]

        base_row = general_label_row + 1
        for idx, (label_text, field_name, default) in enumerate(general_form_fields):
            ttk.Label(
                self.frame,
                text=label_text).grid(row = base_row + idx, column=0, sticky="w")
            var = tk.StringVar(value=default)
            entry = ttk.Entry(self.frame, textvariable=var)
            entry.grid(row=base_row + idx, column=1)
            self.entries[field_name] = var
        after_general_form_row = base_row + len(general_form_fields)

        # -- Marker Settings:
        basic_label_row = after_general_form_row
        ttk.Label(
            self.frame,
            text="Unique Settings Plot",
            font=("Arial", 12, "bold")
        ).grid(row=basic_label_row, column=0, columnspan=3, pady=10, sticky="w")
        # Help button for basic form
        ttk.Button(
            self.frame,
            text="?",
            width=2,
            command=lambda: self.show_info('basic')
        ).grid(row=basic_label_row, column=2, padx=5)

        # --- Marker Settings ---
        marker_settings_fields = [
            ("Marker Mode", "marker_mode"),
            ("Marker Format", "marker_fmt"),
            ("Marker Size", "marker_size"),
            ("Marker Shapes (comma-separated)", "marker_shapes"),
            ("Marker Colors (comma-separated)", "marker_colors"),
        ]
        # -- Default colors
        self.def_colors = "r,g,b,c,m,y,k,orange,purple,brown"
        self.def_markers = "o,s,D,^,v,>,<,p,*,X"

        self.marker_mode = tk.StringVar(value="text")
        self.marker_fmt = tk.StringVar(value="$%d$")
        self.marker_size = tk.StringVar(value="10")
        self.marker_shapes = tk.StringVar(value = self.def_markers)
        self.marker_colors = tk.StringVar(value = self.def_colors)

        # Mapping field name -> entry widgets (if you want later access)
        self.marker_entries = {}
        marker_row = basic_label_row + 1
        for idx, (label_text, field_name) in enumerate(marker_settings_fields):
            ttk.Label(
                self.frame,
                text=label_text).grid(row=marker_row + idx, column=0, sticky="w")

            if field_name == "marker_mode":
                entry = ttk.Combobox(
                    self.frame,
                    textvariable=self.marker_mode,
                    values=["text", "shape"],
                    state="readonly",
                )
                entry.bind(
                    "<<ComboboxSelected>>",
                    self.update_marker_fmt_state,
                )
            else:
                entry = ttk.Entry(self.frame, textvariable=getattr(self, field_name))
            entry.grid(row=marker_row + idx, column=1)
            # Save entry if you need later
            self.marker_entries[field_name] = entry
            if field_name == "marker_colors":
                ttk.Button(
                    self.frame,
                    text="Pick Color",
                    command=self.pick_color_for_marker
                ).grid(row=marker_row + idx, column=2, padx=5, sticky="w")
        # Help button for marker form
        ttk.Button(
            self.frame,
            text="?",
            width=2,
            command=lambda: self.show_info('marker')
        ).grid(row=marker_row - 1, column=2, padx=10)

        # Special case: disable marker_shapes initially
        self.marker_entries["marker_shapes"].configure(state="disabled")
        self.after_basic_form_row = marker_row + len(marker_settings_fields)

        # --- Figure Parameters Section
        figure_label_row = self.after_basic_form_row + 1
        ttk.Label(
            self.frame,
            text="Figure Parameters",
            font=("Arial", 12, "bold")
        ).grid(row=figure_label_row, column=0, columnspan=3, pady=10, sticky="w")
        ttk.Button(
            self.frame,
            text="?",
            width=2,
            command=lambda: self.show_info('figure')
        ).grid(row=figure_label_row, column=2, padx=5)

        figure_params_fields = [
            ("Contour Levels", "contour_levels", "5"),
            ("Contour Line Color", "contour_linecolor", "0.5"),
            ("Contour Inline Labels", "contour_inline", "1"),
            ("Contour Font Size", "contour_fontsize", "10"),
            ("Contour Label Format", "contour_fmt", "%.1f"),
            ("Save DPI", "save_dpi", "300"),
            ("Save Format", "save_format", "png"),
            ("Save Filename", "save_filename", "taylor_diagram"),
            ("Legend Font Size", "legend_fontsize", "small"),
            ("Legend Location", "legend_loc", "center"),
            ("Legend Num Points", "legend_numpoints", "1"),
        ]
        self.figure_entries = {}
        figure_base_row = figure_label_row + 1
        for idx, (label_text, field_name, default) in enumerate(figure_params_fields):
            ttk.Label(
                self.frame,
                text=label_text).grid(row=figure_base_row + idx, column=0, sticky="w")
            var = tk.StringVar(value=default)
            entry = ttk.Entry(self.frame, textvariable=var)
            entry.grid(row=figure_base_row + idx, column=1)
            self.figure_entries[field_name] = var
        self.after_basic_form_row = figure_base_row + len(figure_params_fields)

        # -- Refresh Periods:
        self.refresh_periods()

        # -- Save Buttons: nicely aligned in one row:
        save_buttons_frame = ttk.Frame(self.frame)
        # -- Save Settings to YAML
        self.save_button = ttk.Button(
            save_buttons_frame,
            text="Save Settings to YAML",
            command=self.save_settings,
        )
        # -- Save Default Example (default example):
        self.save_example_button = ttk.Button(
            save_buttons_frame,
            text="Save Default Example",
            command=self.save_default_example,
        )
        self.save_button.pack(side="left", padx=5)
        self.save_example_button.pack(side="left", padx=5)
        # --- Grid Save Buttons (after refresh_periods defines after_stdref_sample_row)
        save_buttons_frame.grid(
            row=self.after_stdref_sample_row + 1, column=0, columnspan=3, pady=10
        )

        # -- Basic example values:
        self.example_stdrefs = {
            'winter': 48.491, 'spring': 44.927, 'summer': 37.664, 'autumn': 41.589,
        }
        self.example_samples = {
            'winter': [
                [17.831, 0.360, "CCSM CRCM"], [27.062, 0.360, "CCSM MM5"],
                [33.125, 0.585, "CCSM WRFG"], [25.939, 0.385, "CGCM3 CRCM"],
                [29.593, 0.509, "CGCM3 RCM3"], [35.807, 0.609, "CGCM3 WRFG"],
                [38.449, 0.342, "GFDL ECP2"], [29.593, 0.509, "GFDL RCM3"],
                [71.215, 0.473, "HADCM3 HRM3"],
            ],
            'spring': [
                [32.174, -0.262, "CCSM CRCM"], [24.042, -0.055, "CCSM MM5"],
                [29.647, -0.040, "CCSM WRFG"], [22.820, 0.222, "CGCM3 CRCM"],
                [20.505, 0.445, "CGCM3 RCM3"], [26.917, 0.332, "CGCM3 WRFG"],
                [25.776, 0.366, "GFDL ECP2"], [18.018, 0.452, "GFDL RCM3"],
                [79.875, 0.447, "HADCM3 HRM3"],
            ],
            'summer': [
                [35.863, 0.096, "CCSM CRCM"], [43.771, 0.367, "CCSM MM5"],
                [35.890, 0.267, "CCSM WRFG"], [49.658, 0.134, "CGCM3 CRCM"],
                [28.972, 0.027, "CGCM3 RCM3"], [60.396, 0.191, "CGCM3 WRFG"],
                [46.529, 0.258, "GFDL ECP2"], [35.230, -0.014, "GFDL RCM3"],
                [87.562, 0.503, "HADCM3 HRM3"],
            ],
            'autumn': [
                [27.374, 0.150, "CCSM CRCM"], [20.270, 0.451, "CCSM MM5"],
                [21.070, 0.505, "CCSM WRFG"], [25.666, 0.517, "CGCM3 CRCM"],
                [35.073, 0.205, "CGCM3 RCM3"], [25.666, 0.517, "CGCM3 WRFG"],
                [23.409, 0.353, "GFDL ECP2"], [29.367, 0.235, "GFDL RCM3"],
                [70.065, 0.444, "HADCM3 HRM3"],
            ],
        }

    def refresh_periods(self) -> None:
        """
        Parses the YAML-defined periods and dynamically creates input fields
        for each period's reference standard deviation and sample entries.

        Also updates internal tracking of widgets for reset and validation.
        Raises a popup error if periods are not valid strings in a list.
        """
        try:
            config = yaml.safe_load(self.config_text.get("1.0", tk.END))
            periods = config.get('periods', [])

            if not isinstance(periods, list) or not all(isinstance(p, str) for p in periods):
                messagebox.showerror("Error", "Config must define 'periods' as a list of strings.")
                return

            # -- Clear existing stdref/sample widgets:
            for widget in self.stdref_widgets:
                widget.destroy()
            for widget in self.sample_widgets:
                widget.destroy()
            self.stdref_widgets.clear()
            self.sample_widgets.clear()
            self.stdref_entries.clear()
            self.sample_texts.clear()
            # -- Add new Stdrefs fields:
            base_row = self.after_basic_form_row + 4
            ttk.Label(
                self.frame,
                text="Reference Std (one per period):",
                font=("Arial", 10, "bold")
            ).grid(row=base_row, column=0, sticky="w", pady=5)
            self.stdref_widgets.append(
                self.frame.grid_slaves(row=base_row, column=0)[0]
            )
            # -- Help button for stdrefs:
            ttk.Button(
                self.frame,
                text="?",
                width=2,
                command=lambda: self.show_info('stdrefs')
            ).grid(row=base_row, column=2, padx=5)

            for i, period in enumerate(periods):
                label = ttk.Label(self.frame, text=f"{period.capitalize()} Stdref:")
                label.grid(row=base_row + i + 1, column=0, sticky="w")
                var = tk.StringVar()
                entry = ttk.Entry(self.frame, textvariable=var)
                entry.grid(row=base_row + i + 1, column=1)
                self.stdref_entries[period] = var
                self.stdref_widgets.extend([label, entry])

            # --- Add new Samples textareas ---
            text_base_row = base_row + len(periods) + 2
            ttk.Label(
                self.frame,
                text="Samples (one entry per line: STD, RHO, NAME):",
                font=("Arial", 10, "bold")
            ).grid(row=text_base_row, column=0, sticky="w", pady=5)
            self.sample_widgets.append(
                self.frame.grid_slaves(row=text_base_row, column=0)[0]
            )

            # -- Help button for samples:
            ttk.Button(
                self.frame,
                text="?",
                width=2,
                command=lambda: self.show_info('samples')
            ).grid(row=text_base_row, column=2, padx=5)

            for i, period in enumerate(periods):
                label = ttk.Label(self.frame, text=f"{period.capitalize()} Samples:")
                label.grid(row=text_base_row + i * 2 + 1, column=0, sticky="w")
                text_widget = tk.Text(self.frame, height=5, width=40)
                text_widget.grid(row=text_base_row + i * 2 + 1, column=1, pady=5)
                self.sample_texts[period] = text_widget
                self.sample_widgets.extend([label, text_widget])

            self.after_stdref_sample_row = text_base_row + len(periods) * 2 + 2
            # Update scrollregion
            self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def validate_colors_list(self, colors_list: List[str]) -> None:
        """
        Validates a list of color strings to ensure compatibility with matplotlib.

        Parameters:
        -----------
        colors_list : list of str
            Each string must be a valid named color or hex color (e.g., 'red', '#ff0000')

        Raises:
        -------
        ValueError:
            If any color string is invalid.
        """
        for color in colors_list:
            try:
                mcolors.to_rgba(color)  # Try to convert color
            except ValueError:
                raise ValueError(f"Invalid color detected: '{color}'")

    def pick_color_for_marker(self) -> None:
        """
        Opens a color picker dialog and appends the selected color to the
        Marker Colors field in the GUI. Used for customizing sample markers.
        """
        color = colorchooser.askcolor(title="Choose a color")[1]
        if color:
            existing = self.marker_colors.get().strip()
            if existing:
                new_value = f"{existing},{color}"
            else:
                new_value = color
            self.marker_colors.set(new_value)

    def generate_rects(self, periods: List[str]) -> Dict[str, int]:
        """
        Generate a subplot layout dictionary (rects) based on the number of periods.
        Uses dynamic grid sizing (rows x cols) to fit all periods in a compact layout.

        Parameters:
        ----------------------------
            periods (list of str): Names of the periods defined by the user.

        Returns:
        ----------------------------
            dict: Mapping of period name to subplot code (e.g., 221, 222, ...).
        """
        rects: Dict[str, int] = {}

        n = len(periods)
        if n == 0:
            # safe empty dict return
            return rects

        # -- Smallest possible number of columns:
        cols = math.ceil(math.sqrt(n))
        # -- Number of rows needed:
        rows = math.ceil(n / cols)

        rects = {}
        for idx, period in enumerate(periods):
            subplot_code = rows * 100 + cols * 10 + (idx + 1)
            rects[period] = subplot_code
        return rects

    def show_info(self, section: Optional[str] = None) -> None:
        """
        Displays a help dialog with contextual documentation.

        Parameters:
        -----------
        section : str, optional
            The section for which help should be displayed. Options include:
            'config', 'basic', 'marker', 'figure', 'stdrefs', 'samples'.

        Behavior:
        ---------
        If section is None or unrecognized, shows a general help popup.
        """
        info_texts = {
            'config': (
                "Config Options:\n"
                "- Define a list named 'periods' to specify the time periods or groups you want to evaluate.\n"
                "- These periods control the structure of the input form.\n"
                "- The GUI will dynamically generate fields for standard deviations and samples\n"
                "  based on the periods you specify.\n"
                "- The periods will also determine subplot placement automatically.\n"
                "\n"
                "Example 1 (standard seasons):\n"
                "  periods: [winter, spring, summer, autumn]\n"
                "\n"
                "Example 2 (specific months):\n"
                "  periods: [march, april, may, june, july, august]\n"
                "\n"
                "Notes:\n"
                "- List items must be lowercase strings without special characters.\n"
                "- After changing the Config Options, click the 'Refresh Periods' button\n"
                "  to update the form fields.\n"
            ),
            'basic': (
                "General Settings:\n"
                "- Subtitle: Title that appears on the figure.\n"
                "- Figure Size: Size of the generated figure in inches, format width,height (e.g., 14,10).\n"
                "- Title Font Size: Font size for the main figure title. \n"
                "- x95/y95 and x99/y99:\n"
                "    • These define the placement of lines indicating the 95% and 99% significance thresholds.\n"
                "    • For datasets with more than 100 samples (degrees of freedom > 100),\n"
                "      the critical correlation levels are approximately 0.195 (95% confidence)\n"
                "      and 0.254 (99% confidence).\n"
                "    • These lines are typically drawn manually based on the X and Y axis of the Taylor diagram.\n"
                "    • Example values used (based on Rawlins et al., 2012, JGR):\n"
                "        - x95: [0.05, 13.9]\n"
                "        - y95: [0.0, 71.0]\n"
                "        - x99: [0.05, 19.0]\n"
                "        - y99: [0.0, 70.0]\n"
                "    • These values mark critical correlation lines used to assess model performance."
            ),
            'marker': (
                "Unique Settings Plot:\n"
                "- Marker Mode:\n"
                "    • 'text' uses a formatted string to label points (e.g., '$%d$' → 1, 2, 3...)\n"
                "    • 'shape' uses geometric markers (e.g., 'o', '^', '*', etc.)\n"
                "- Marker Format (only used in text mode):\n"
                "    • Enter a format string that includes '%d' (e.g., '$%d$' or '%d')\n"
                "    • Each point will display the corresponding number.\n"
                "- Marker Shapes (shape mode only):\n"
                "    • Comma-separated list of marker symbols (e.g., 'o,^,s,*').\n"
                "    • Must match the number of samples.\n"
                "- Marker Colors:\n"
                "    • Comma-separated list of color codes or names (e.g., 'r,g,b' or 'red,blue,green').\n"
                "    • Must match the number of samples.\n"
            ),
            'figure': (
                "Figure Parameters Help:\n"
                "- Contour Levels: Number of contours to draw.\n"
                "- Contour Line Color: Color of the contour lines in range from 0.0 to 1.0 (e.g., '0.5' for grey).\n"
                "- Contour Inline Labels: Whether to draw labels inside contour lines (1 = yes, 0 = no).\n"
                "- Contour Font Size: Font size for labels on contours.\n"
                "- Contour Label Format: Formatting of contour labels (e.g., '%.1f').\n"
                "- Save DPI: Dots-per-inch when saving the figure (higher = sharper).\n"
                "- Save Format: Output format ('png', 'jpg', 'svg', 'pdf').\n"
                "- Save Filename: Name of the output file (without extension).\n"
                "- Legend Font Size: Size of text in the legend.\n"
                "- Legend Location: Position of the legend (e.g., 'center', 'upper left').\n"
                "- Legend Num Points: How many markers are shown per label in the legend.\n"
            ),
            'stdrefs': (
                "Reference Standard Deviations:\n"
                "- Enter one float number for each defined period.\n"
                "- These represent the standard deviation of a reference model or observation."
            ),
            'samples': (
                "Samples Data:\n"
                "- Enter one sample per line for each period.\n"
                "- Format for each line:\n"
                "    STD, RHO, NAME\n"
                "- STD: Sample standard deviation (float).\n"
                "- RHO: Correlation coefficient (float).\n"
                "- NAME: Model or sample name (string).\n"
                "- Example line:\n"
                "    17.831, 0.360, CCSM CRCM\n"
                "- If the NAME contains commas, all remaining parts are treated as part of the name.\n"
                "- Leave blank if no samples for that period."
            )
        }
        if section and section in info_texts:
            messagebox.showinfo(f"Help - {section.capitalize()}", info_texts[section])
        else:
            messagebox.showinfo("Help", "No help available for this section.")

    def update_marker_fmt_state(self, event: Optional[Any] = None) -> None:
        """
        Adjusts the state (enabled/disabled) of marker format and shape fields
        based on the selected marker mode ('text' or 'shape').

        Parameters:
        -----------
        event : Any, optional
            Tkinter event object (unused). Allows method to be used as callback.
        """
        mode = self.marker_mode.get()
        if mode == "shape":
            self.marker_fmt.set("")  # Optionally clear
            self.marker_entries["marker_fmt"].configure(state="disabled")
            self.marker_entries["marker_shapes"].configure(state="normal")
        else:
            self.marker_entries["marker_fmt"].configure(state="normal")
            self.marker_entries["marker_shapes"].configure(state="disabled")
            if not self.marker_fmt.get().strip():
                # Set default value
                self.marker_fmt.set("$%d$")

    def __fill_example_values(self) -> None:
        """
        Automatically fills all fields with built-in example values for testing.

        Populates:
        ----------------------------
        - Standard deviations for each period
        - Sample entries (std, rho, name)
        - Marker colors and shapes
        """
        try:
            for period, value in self.example_stdrefs.items():
                if period in self.stdref_entries:
                    self.stdref_entries[period].set(str(value))

            for period, sample_list in self.example_samples.items():
                if period in self.sample_texts:
                    lines = [f"{std},{rho},{name}" for std, rho, name in sample_list]
                    self.sample_texts[period].delete("1.0", tk.END)
                    self.sample_texts[period].insert(tk.END, "\n".join(lines))
            self.marker_colors.set(self.def_colors)
            self.marker_shapes.set(self.def_markers)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load example values:\n{e}")

    def clear_reference_and_samples(self) -> None:
        """
        Clears all fields associated with reference standard deviations and
        sample data. Resets them to empty for fresh input.
        """
        try:
            for var in self.stdref_entries.values():
                var.set("")
            for text_widget in self.sample_texts.values():
                text_widget.delete("1.0", tk.END)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to clear fields:\n{e}")

    def _convert_to_number_or_lower(self, value: str) -> Any:
        """
        Attempts to convert a string value to int or float.

        If the conversion fails, returns the lowercase version of the string.

        Parameters:
        -----------
        value : str
            Input value from a user entry field.

        Returns:
        --------
        int | float | str:
            The parsed numeric value or cleaned lowercase string.
        """
        try:
            return int(value)
        except ValueError:
            try:
                return float(value)
            except ValueError:
                return value.lower()

    def _is_form_default(self) -> bool:
        """
        Checks whether the current GUI form matches the built-in default example
        values for config, stdrefs, and samples.

        Returns:
        --------
        bool:
            True if form is unmodified and matches default example, False otherwise.
        """
        # -- True example values:
        default_periods = ['winter', 'spring', 'summer', 'autumn']
        default_subtitle = "Precipitations"
        default_figsize = [14, 10]
        default_marker_mode = "text"
        default_marker_fmt = "$%d$"
        default_stdrefs = self.example_stdrefs
        default_samples = self.example_samples

        try:
            config = yaml.safe_load(self.config_text.get("1.0", tk.END))
            periods = config.get('periods', [])
            if periods != default_periods:
                return False
        except Exception:
            return False

        if self.entries['subtitle'].get().strip() != default_subtitle:
            return False
        if list(map(float, self.entries['figsize'].get().split(','))) != default_figsize:
            return False
        if self.marker_mode.get() != default_marker_mode:
            return False
        if self.marker_fmt.get().strip() != default_marker_fmt:
            return False
        # Now check stdrefs
        for period in default_periods:
            try:
                if abs(float(self.stdref_entries[period].get()) - default_stdrefs[period]) > 1e-3:
                    return False
            except Exception:
                return False
        # Now check samples
        for period in default_periods:
            lines = self.sample_texts[period].get("1.0", tk.END).strip().split('\n')
            lines = [line.strip() for line in lines if line.strip()]
            example_lines = [
                f"{std},{rho},{name}" for std, rho, name in default_samples[period]
            ]
            if lines != example_lines:
                return False
        return True

    def _quote_special_yaml(self, value: str) -> str:
        """
        Quotes string values that include YAML-special characters to ensure safe dumping.

        Parameters:
        -----------
        value : str
            String to inspect and potentially quote.

        Returns:
        --------
        str:
            Original or quoted string, depending on its content.
        """
        special_chars = set('*&%{}[]<>')
        if isinstance(value, str) and any(c in value for c in special_chars):
            return f'"{value}"'
        return value

    def _collect_settings(self, validate_default: bool = False) -> Dict[str, Any]:
        """
        Gathers and validates all current form inputs into a structured dictionary
        suitable for saving as a YAML configuration file.

        Parameters:
        -----------
        validate_default : bool
            If True, checks that the form matches the built-in default before proceeding.

        Returns:
        --------
        dict:
            A full configuration dictionary containing all figure, marker, stdref, and sample settings.

        Raises:
        -------
        ValueError:
            If the form is incomplete or inconsistent (e.g., uneven sample counts).
        """
        config = yaml.safe_load(self.config_text.get("1.0", tk.END))
        periods = config.get('periods', [])

        if validate_default and not self._is_form_default():
            raise ValueError(
                "Detected changes in the form. Please use 'Save Settings to YAML' instead of saving as default example."
            )

        settings = {
            # General Settings
            'subtitle': self.entries['subtitle'].get(),
            'significance_lines': {
                '95': {
                    'x': list(map(float, self.entries['x95'].get().split(','))),
                    'y': list(map(float, self.entries['y95'].get().split(','))),
                },
                '99': {
                    'x': list(map(float, self.entries['x99'].get().split(','))),
                    'y': list(map(float, self.entries['y99'].get().split(','))),
                },
            },
            'figsize': list(map(float, self.entries['figsize'].get().split(','))),
            'title_fsize': int(self.entries['title_fsize'].get()),
            # Basic Settings
            'marker_mode': self.marker_mode.get(),
            'marker_size': int(self.marker_size.get()),
        }
        # --- Marker format or shapes
        if self.marker_mode.get() == "text":
            settings['marker_fmt'] = self.marker_fmt.get()
        elif self.marker_mode.get() == "shape":
            shapes_list = [shape.strip() for shape in self.marker_shapes.get().split(',') if shape.strip()]
            settings['marker_shapes'] = shapes_list
        # --- Marker colors
        colors_list = [
            self._convert_to_number_or_lower(color.strip())
            for color in self.marker_colors.get().split(',')
            if color.strip()
        ]
        if colors_list:
            self.validate_colors_list(colors_list)
            settings['marker_colors'] = colors_list
        # --- Stdrefs and samples
        settings['stdrefs'] = {}
        settings['samples'] = {}
        sample_lengths = []

        for period in periods:
            settings['stdrefs'][period] = float(self.stdref_entries[period].get())

            lines = self.sample_texts[period].get("1.0", tk.END).strip().split('\n')
            lines = [line for line in lines if line.strip()]
            sample_lengths.append(len(lines))

            season_samples = []
            for line in lines:
                parts = line.strip().split(',')
                if len(parts) >= 3:
                    stddev = float(parts[0].strip())
                    rho = float(parts[1].strip())
                    name = ','.join(parts[2:]).strip()
                    season_samples.append([stddev, rho, name])
                else:
                    raise ValueError(f"Invalid sample line in {period}: '{line}'")
            settings['samples'][period] = season_samples

        # --- Validate sample lengths
        if len(set(sample_lengths)) > 1:
            raise ValueError(f"Mismatch: different number of samples across periods! {sample_lengths}")

        samples_count = sample_lengths[0] if sample_lengths else 0

        if self.marker_mode.get() == "shape":
            if len(settings['marker_shapes']) < samples_count:
                raise ValueError(
                    f"Not enough marker shapes: {len(settings['marker_shapes'])} shapes provided but {samples_count} samples needed."
                )
        if 'marker_colors' in settings:
            if len(settings['marker_colors']) < samples_count:
                raise ValueError(
                    f"Not enough marker colors: {len(settings['marker_colors'])} colors provided but {samples_count} samples needed."
                )

        # --- Subplot rects
        settings['rects'] = self.generate_rects(periods)
        # --- Sanitize marker shapes and colors for YAML
        if 'marker_shapes' in settings:
            settings['marker_shapes'] = [self._quote_special_yaml(s) for s in settings['marker_shapes']]
        if 'marker_colors' in settings:
            settings['marker_colors'] = [self._quote_special_yaml(c) for c in settings['marker_colors']]
        # --- Add Figure Parameters
        settings['figure_params'] = {}
        for key, var in self.figure_entries.items():
            value = var.get().strip()
            if value:
                settings['figure_params'][key] = self._convert_to_number_or_lower(value)
        return settings

    def save_settings(self) -> None:
        """
        Collects the current GUI state and saves it to a user-specified YAML file.

        Prompts for a save location. Handles any input validation errors via popup.
        """
        try:
            settings = self._collect_settings(validate_default=False)
            save_path = filedialog.asksaveasfilename(
                defaultextension=".yaml",
                filetypes=[("YAML Files", "*.yaml *.yml")]
            )
            if save_path:
                with open(save_path, 'w') as f:
                    yaml.safe_dump(settings, f)
                messagebox.showinfo("Saved", f"Settings saved to:\n{save_path}")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def save_default_example(self) -> None:
        """
        Saves the current form as the official default example configuration.

        Only allowed if the form exactly matches the built-in example.
        Raises an error popup if the form is not in default state.
        """
        try:
            settings = self._collect_settings(validate_default=True)
            save_path = filedialog.asksaveasfilename(
                defaultextension=".yaml",
                filetypes=[("YAML Files", "*.yaml *.yml")]
            )
            if save_path:
                with open(save_path, 'w') as f:
                    yaml.safe_dump(settings, f)
                messagebox.showinfo("Saved", f"Default example saved to:\n{save_path}")
        except Exception as e:
            messagebox.showerror("Save failed", str(e))


if __name__ == "__main__":
    root = tk.Tk()
    app = TaylorSettingsGUI(root)
    root.mainloop()
