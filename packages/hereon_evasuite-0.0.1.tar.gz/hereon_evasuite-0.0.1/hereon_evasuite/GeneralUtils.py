# EvaSuite
#
# ---------------------------------------------------------------
# Copyright (C) 2004-2025, Hereon
# Contact information: beate.geyer@hereon.de, imktro-climate-modelling@lists.kit.edu
# See AUTHORS.TXT for a list of authors
# See LICENSES/ for license information
# SPDX-License-Identifier: Apache-2.0
# ---------------------------------------------------------------

# -- General modules:
import subprocess as sp
import os
import gzip
import shutil
import numpy as np
import xarray as xr
from typing import Type, Optional, Any, Union, List, Dict
# -- Import user modules:
from hereon_evasuite.log_EvaSuite import get_logger, log_function_name

logger = get_logger()


# -- A Class for using the Shell Output appropriately:
class ShellLogging:
    """
    Utility class for executing shell commands with integrated EvaSuite logging.

    This class provides convenience methods to:
    ----------------------------
      - Run a shell command and pipe its standard output and error to a file
        while logging a note (`pipedoutput`).
      - Run a shell command and capture its console output as a decoded string
        (`ConsoleOutput`).

    Attributes:
    ----------------------------
        cmd (str):
            The shell command to execute.

    Methods:
    ----------------------------
        pipedoutput(cmd_logfile, eva_logfile_note):
            Executes the stored command, redirecting stdout and stderr to
            the specified log file, and logs a message.
        ConsoleOutput():
            Executes the stored command, returning its decoded output as a
            UTF-8 string (or raw bytes if decoding fails). Returns None if
            the command fails.
    """

    def __init__(self, cmd: str) -> None:
        """
        Initialize with the shell command to execute.

        Args:
        ----------------------------
            cmd (str): The command string to run in shell operations.
        """
        self.cmd = cmd

    @log_function_name
    def pipedoutput(self, cmd_logfile: str, eva_logfile_note: str) -> None:
        # -- Saving standard output AND error ouput to logfile:
        sp.check_output(
            [self.cmd + " > " + cmd_logfile],
            stderr = sp.STDOUT,
            shell = True,
        )
        logger.debug(eva_logfile_note)

    def ConsoleOutput(self) -> Optional[str]:
        """
        Run the stored command and return its console output as text.

        Returns:
        ----------------------------
            str | None: The decoded UTF-8 output if successful, or None if the command fails.
        """
        try:
            whichout = sp.check_output(
                [self.cmd], stderr = sp.STDOUT, shell = True)
        except sp.CalledProcessError:
            whichout = None
        try:
            return whichout.decode('utf-8')
        except AttributeError:
            return whichout


class SuiteUtilities(object):
    """
    Collection of helper methods for EvaSuite system and file operations.

    This utility class provides general-purpose functions used throughout
    the EvaSuite framework,

    including:
    ----------------------------
      - Safe dictionary access with optional type checks.
      - Shell command execution with integrated logging.
      - File and directory existence checks.
      - YAML and CSV reading/writing.
      - Miscellaneous helper routines for formatting and data conversion.

    Typical usage:
    ----------------------------
        utils = SuiteUtilities()
        value = utils.safe_access_bib(config_dict, "key_name")
        utils.shell_exec("ls -l")

    Notes:
    ----------------------------
        - Many methods log their actions using the global EvaSuite logger.
        - Designed to avoid raising exceptions in common scenarios by returning
          defaults or logging warnings instead.
    """
    @log_function_name
    def __init__(self: 'SuiteUtilities') -> None:
        """Initialization of SuiteUtilities"""
        self.epsilon = 1.0 * 10**(-9)

    @log_function_name
    def ConvertSeasonNamesToMonth(self: 'SuiteUtilities', seasons: List[str]) -> List[int]:
        """Convert season names to month indices:"""
        # -- Local variables:
        # -- Define a dictionary to map season names to month indices:
        logger.info(f"Received seasons: {seasons}")
        season2months = {
            "winter": [1, 2, 12],
            "spring": [3, 4, 5],
            "summer": [6, 7, 8],
            "autumn": [9, 10, 11],  # corrected "spring" to "autumn"
            "complete": list(range(1, 13))
        }
        # -- Fill in list:
        month2extract = []
        for seasonname in seasons:
            if seasonname.startswith("Month"):
                try:
                    month = int(seasonname.split("-")[1])
                    if not 1 <= month <= 12:
                        raise ValueError('Seasonname has problem')
                    month2extract.append(month)
                    logger.debug(f"Interpreted {seasonname} as month {month}")
                except Exception:
                    logger.error(f"Invalid month format or value: '{seasonname}'")
                    raise ValueError(f"Invalid month format or value: '{seasonname}'")
            else:
                # -- control input season:
                if seasonname not in season2months:
                    logger.error(f"Unknown season: '{seasonname}'")
                    raise ValueError(
                        f"The season '{seasonname}' is not among the known options: "
                        f"{list(season2months.keys())}"
                    )
                logger.debug(f"Mapped season '{seasonname}' to months {season2months[seasonname]}")
                month2extract.extend(season2months[seasonname])
        logger.info(f"Final list of months: {month2extract}")
        return month2extract

    @log_function_name
    def NumberRound(self: 'SuiteUtilities', number: float) -> float:
        """
        Round a number to an appropriate number of digits based on its magnitude.

        - If abs(number) < epsilon → return 0.0
        - If number is large → round to 0 decimals
        - If number is small → round to more decimals

        Returns:
            float: Rounded number
        """
        logger.debug(f"Original number: {number}")
        if np.fabs(number) < self.epsilon:
            logger.debug(f"Number is smaller than epsilon ({self.epsilon}), returning 0.0")
            return 0.0

        exp = np.floor(np.log10(np.abs(number)))
        logger.debug(f"Exponent (log10 floor) = {exp}")

        if exp > 0:
            resul = round(number, 0)
        elif exp == 0:
            resul = round(number, 1)
        elif exp < 0:
            resul = round(number, int(np.fabs(exp) + 1))
        logger.debug(f"Rounded result: {resul}")
        return resul

    def safe_access_bib(
        self: 'SuiteUtilities',
        errmsg: str = '',
        exception: Type[Exception] = KeyError,
        dicttest: Optional[dict[str, Any]] = None,
        dictkey: Optional[str] = None,
        errhandle: Optional[bool] = True,
    ) -> Optional[Any]:
        """
        Safely access a value from a dictionary with optional error handling.

        Parameters:
        ----------------------------
            errmsg (str): Message to log if an error occurs.
            exception (Type[Exception]): Exception class to raise on failure.
            dicttest (dict): Dictionary to access.
            dictkey (str): Key to look up in the dictionary.
            errhandle (bool): If True, log as error and exit; otherwise, warn and return None.

        Returns:
        ----------------------------
            The value associated with the key if found, otherwise handles the error.
        """
        try:
            if dicttest is not None and dictkey is not None:
                try:
                    return dicttest[dictkey]
                except KeyError:
                    raise exception(f"Key '{dictkey}' not found.")
            else:
                raise exception(f"Missing dictionary or key: {dictkey}")
        except exception as e:
            if errhandle:
                logger.error(f"{errmsg}: {e}")
                raise SystemExit(1)
            else:
                logger.warning(f"{errmsg}: {e}")
                return None

    def check_for_list(
        self: 'SuiteUtilities',
        inputdata: Union[List[str], Dict[str, str], Any],
    ) -> Union[list[str], dict[Any, Any]]:
        """Check if the inputdata is a list or a single item, in case of latter
           convert to a list:
        """
        if isinstance(inputdata, (list, dict)):
            return inputdata
        elif inputdata is None:
            return []
        else:
            logger.warning(f"Unexpected input type ({type(inputdata)}), converting to list.")
            return [inputdata]

    @log_function_name
    def nparr_to_str(
        self: 'SuiteUtilities',
        inputdata: Any
    ) -> Union[List[str], str, Any]:
        """
        Convert a NumPy array to a list of strings.

        - If inputdata is a NumPy array (np.ndarray), convert it to a list of strings.
        - If inputdata is another type of NumPy object (like np.int64), convert it to a string.
        - Otherwise, return the inputdata unchanged.
        """
        if isinstance(inputdata, np.ndarray):
            if inputdata.ndim > 1:
                raise ValueError("nparr_to_str: does not support nested arrays")
            return list(map(str, inputdata.tolist()))
        elif isinstance(inputdata, np.generic):
            return str(inputdata)
        else:
            return inputdata

    @log_function_name
    def ConvertBibToList(
        self: 'SuiteUtilities',
        input: Union[List[str], Dict[str, Any]]
    ) -> List[str]:
        """ Convert input to a list, whether the input is a list or a dict """
        if isinstance(input, list):
            return input
        if isinstance(input, dict):
            outputlist = []
            for eintrag in input.keys():
                # -- Case of list:
                if isinstance(input[eintrag], list):
                    for werte in input[eintrag]:
                        outputlist.append(werte)
                # -- Case of str or int:
                elif isinstance(input[eintrag], (str, int)):
                    outputlist.append(input[eintrag])
                # -- Case of dict:
                elif isinstance(input[eintrag], dict):
                    for dim_list in input[eintrag].values():
                        if not isinstance(dim_list, list):
                            logger.error(f"ConvertBibToList expected list in nested dict at key '{eintrag}/list', got {type(dim_list)}")
                            raise TypeError(f"Nested value must be a list, got {type(dim_list)}")
                        for files in dim_list:
                            outputlist.append(files)
                else:
                    logger.error(f"Unsupported type {type(input[eintrag])} in key '{eintrag}'")
                    raise TypeError(
                        f"Unsupported input type: {type(input)}. Expected list, dict or str, int")

            return outputlist
        # -- Invalid top-level input type
        logger.error(f"ConvertBibToList received unsupported input type: {type(input)}")
        raise TypeError(f"Unsupported input type: {type(input)}. Expected list or dict.")

    @log_function_name
    def search_string_list(
        self: 'SuiteUtilities',
        strlist: Optional[List[str]] = None,
        search: Optional[str] = None,
    ) -> bool:
        """ Search for a string in a list of strings;
            returns True if the string is completely in one of the list elements;
            returns False if not found or if strlist is not a list
        """
        if not isinstance(strlist, list):
            logger.warning("search_string_list: Provided strlist is not a list.")
            return False
        if search is None:
            logger.warning("search_string_list: Search string is None.")
            return False
        return search in strlist

    @log_function_name
    def search_substring_list(
        self: 'SuiteUtilities',
        strlist: Optional[Dict[str, Any]] = None,
        substr: Optional[str] = None,
    ) -> Optional[List[str]]:
        """
        Search for one or more substrings in a list of strings.

        Parameters:
        ----------------------------
            strlist (list of str): The list to search through.
            substr (str or list of str): Substring(s) to search for.

        Returns:
        ----------------------------
            A list of matched strings.
            - For single substring: all matches.
            - For list of substrings: first match for each.
            Returns None if inputs are invalid.
        """
        if not strlist or not substr:
            logger.warning("search_substring_list: One or both inputs are missing.")
            return None

        if not isinstance(strlist, list) or not all(isinstance(s, str) for s in strlist):
            logger.error("search_substring_list: strlist must be a list of strings.")
            raise TypeError("strlist must be a list of strings")

        if isinstance(substr, str):
            return [s for s in strlist if substr.lower() in s.lower()]

        elif isinstance(substr, list):
            if not all(isinstance(s, str) for s in substr):
                logger.error("search_substring_list: substr list must contain only strings.")
                raise TypeError("substr list must contain only strings")

            listhelp = []
            for part in substr:
                help = [s for s in strlist if part.lower() in s.lower()]
                if help:
                    # -- Only the first match is stored (no doubles) and only
                    #    if something was found
                    listhelp.append(help[0])
            return listhelp
        else:
            logger.error(f"search_substring_list: Unsupported type for substr: {type(substr)}")
            raise TypeError("substr must be a string or a list of strings")

    @log_function_name
    def search_string_dictkeys(
        self: 'SuiteUtilities',
        keylist: List[str],
        searchstring: str,
    ) -> Optional[str]:
        """
        Search for a key from keylist that is a substring of searchstring.

        Parameters:
        ----------------------------
            keylist (List[str]): List of string keys.
            searchstring (str): String to search within.

        Returns:
        ----------------------------
            The last matching key if found, else None.

        Raises:
        ----------------------------
            TypeError: If inputs are not the expected types.
        """
        if not isinstance(keylist, list) or not all(isinstance(k, str) for k in keylist):
            logger.error("search_string_dictkeys: keylist must be a list of strings.")
            raise TypeError("keylist must be a list of strings")
        if not isinstance(searchstring, str):
            logger.error("search_string_dictkeys: searchstring must be a string.")
            raise TypeError("searchstring must be a string")
        if not keylist:
            logger.error("search_string_dictkeys: keylist must not be empty.")
            raise TypeError("keylist must not be empty")

        for lauf in keylist:
            if lauf in searchstring:
                logger.info(f"search_string_dictkeys: Found match '{lauf}' in '{searchstring}'")
                return lauf

        logger.info(f"search_string_dictkeys: No match found in '{searchstring}' from keys {keylist}")
        return None

    @log_function_name
    def ToStrProofNone(
        self: 'SuiteUtilities',
        dataobject: Optional[Any] = None
    ) -> str:
        """Return a string representation of the input or '-' if input is None.

        Args:
        ----------------------------
            dataobject (Optional[Any]): Any input object.

        Returns:
        ----------------------------
            str: The string representation of the object or '-' if None.

        Raises:
        ----------------------------
            TypeError: If the object cannot be converted to string.
        """
        if dataobject is None:
            return "-"
        try:
            return str(dataobject)
        except Exception as e:
            logger.error(
                "ToStrProofNone failed to convert %r (%s) to string: %s",
                dataobject, type(dataobject).__name__, e, exc_info=True)
            raise TypeError(
                f"Unable to convert object of type {type(dataobject).__name__} to string") from e

    def SplitMetaDim(
        self: 'SuiteUtilities',
        meta_dim: Dict[str, List[str]],
        mode: str,
        PossibleDimDict: Dict[str, List[str]],
    ) -> Dict[str, List[str]]:
        """
            Extract from a dictionary of dimensions ('meta_dim') related to a file only
            those entries which are relevant to spatial dims (mode='spatial') or temporal
            dims (mode='temporal') or vertical dims (mode='vertical'). The relevance is
            investigated using a second dictionary 'PossibleDimDict';

            Example of input variables:
            ```python
            'self': <hereon_evasuite.GeneralUtils.SuiteUtilities object at 0x7fffc57a1810>,
            'meta_dim': {'hfls': ['time', 'lat', 'lon']},
            'mode': 'temporal',
            'PossibleDimDict': {
                'spatial': ['lon', 'lat', 'X', 'Y'],
                'time': ['time'],
                'vertical': ['level', 'height']
            }
            ```
        """
        # -- Substrings are not searched, the whole string must appear in the netcdf-file:
        # -- Local variables:
        dims_methods = {
            'spatial': PossibleDimDict.get('spatial', []),
            'temporal': PossibleDimDict.get('time', []),
            'vertical': PossibleDimDict.get('vertical', []),
        }
        # -- Control of dims_methods:
        if mode not in dims_methods:
            logger.error(
                "SplitMetaDim received invalid mode '%s'. Valid modes: %s",
                mode, list(dims_methods.keys())
            )
            raise ValueError(
                f"Func SplitMetaDim: mode '{mode}' is not valid. Choose from {list(dims_methods.keys())}."
            )

        extract_dict: Dict[str, List[str]] = {}
        # -- Get actual values depending on working mode:
        searchstrings = dims_methods[mode]
        # -- Fill in the dictionary:
        for eintrag in meta_dim.keys():
            extract_dict[eintrag] = []
            for values in meta_dim[eintrag]:
                if any(x in values for x in searchstrings):
                    extract_dict[eintrag].append(values)
        return extract_dict

    @log_function_name
    def IterNoneComp(
        self: 'SuiteUtilities',
        metriciter: Optional[List[str]] = None,
        outStrNone: Optional[str] = "_",
    ) -> List[str]:
        """ Converts a list of parameters to an iterable field despite of
            NoneTyps in input;
        """
        # -- Ensure outStrNone is a string:
        outStrNone = outStrNone if outStrNone is not None else "_"

        if metriciter is None:
            return [outStrNone]

        if not isinstance(metriciter, list) or not all(isinstance(item, str) for item in metriciter):
            logger.error("IterNoneComp received invalid metriciter: %r (expected list of str)", metriciter)
            raise TypeError("metriciter must be a list of strings or None")
        return metriciter

    @log_function_name
    def makedir(self, direc: str) -> str:
        """Ensures the directory exists and is accessible, creating it if necessary."""
        if os.path.isfile(direc):
            logger.error("makedir failed: '%s' is a file, not a directory", direc)
            raise FileExistsError(f"'{direc}' exists and is a file, not a directory")

        if not os.access(direc, os.R_OK):
            try:
                os.makedirs(direc, exist_ok=True)
            except Exception as e:
                logger.error("makedir failed to create '%s': %s", direc, e, exc_info=True)
                raise
        return direc

    @log_function_name
    def create_subregs_from_Oromask(
        self: 'SuiteUtilities',
        reg: Union[np.ndarray, xr.DataArray, None],
        dictoro: Optional[dict] = None,
    ) -> Optional[
        tuple[
            Optional[Union[np.ndarray, xr.DataArray, list[str]]],
            Optional[list[list[float]]]
        ]
    ]:
        """ Create filename suffixes dependent on orographic masking dictionary
            and spatial region;
            output: list of region strings and threshold values for oromasking """
        if (reg is None) and (dictoro is None):
            return None, None
        elif (reg is not None) and (dictoro is None):
            return reg, None
        elif (reg is not None) and (dictoro is not None):
            if dictoro["method"] == "threshold":
                limits = []
                helpvert = [
                    f"oroLT{dictoro['value']}m",
                    f"oroGT{dictoro['value']}m",
                ]
                regoroname = [f"{reg}_{help}" for help in helpvert]
                # -- Values from deepest Earth points:
                limits.append([-12000, dictoro["value"]])
                # -- Values from highest Earth points:
                limits.append([dictoro["value"], 9000])

            elif dictoro["method"] == "ranges":
                limits, regoroname = [], []
                for limidx in range(len(dictoro["limits"]) - 1):
                    helpvert = f"oroBW{dictoro['limits'][limidx]}-{dictoro['limits'][limidx + 1]}m"
                    regoroname.append(f"{reg}_{helpvert}")
                    limits.append(
                        [
                            dictoro["limits"][limidx],
                            dictoro["limits"][limidx + 1],
                        ],
                    )
            return regoroname, limits
        else:
            logger.error(
                "create_subregs_from_Oromask: This combination for subregion masking "
                "is not allowed up to now."
            )
            raise ValueError("Invalid subregion masking combination in create_subregs_from_Oromask.")

    def filldict(
        self: 'SuiteUtilities',
        allkeys: List[str],
        fillval: Union[str, List[str]],
    ) -> Dict[str, Union[str, List[str]]]:
        """ fill a dictionary with value 'fillval' for all keys 'allkeys' which are not
            already in the dictionary

            Input variables:
            ----------------------------
                1. allkeys -> list of statistical parameters ['BIAS_temporal']
                2. fillval -> absolute path to the dataset
                    (.../ERA5-monthly_Merged_RelevantTimeAndParam.nc_FinalEvalGrid_EvalFrequency)

            Output variables:
            ----------------------------

        """
        if not isinstance(allkeys, list) or not all(isinstance(k, str) for k in allkeys):
            logger.error("filldict failed: allkeys must be a list of strings. Got: %r", allkeys)
            raise TypeError("allkeys must be a list of strings")
        return {key: fillval for key in allkeys}

    @log_function_name
    def CheckGzip(self: 'SuiteUtilities', file: str) -> bool:
        """ Returns true if file is really an gunzipped file """
        import zlib
        try:
            with gzip.open(file, 'rb') as fgz:
                # Read just enough to trigger header check
                fgz.read(1)
            return True
        except (gzip.BadGzipFile, EOFError, zlib.error):
            return False
        except Exception as e:
            logger.error("CheckGzip failed on file '%s': %s", file, e, exc_info=True)
            raise

    @log_function_name
    def Gunzip(
        self: 'SuiteUtilities',
        file: str,
        resultdir: str,
        suffix: Optional[str] = None,
    ) -> str:
        """
        Gunzip a file and return the filename of the extracted file.

        Args:
        ----------------------------
            file (str): Path to the `.gz` file to decompress.
            resultdir (str): Directory where the extracted file will be placed.
            suffix (str | None, optional): Extra suffix to append to the extracted file's
                name (before the extension). Defaults to None.

        Returns:
        ----------------------------
            str: Full path to the extracted file.

        Raises:
        ----------------------------
            Exception: If file decompression fails for any reason.
        """
        # -- Extract name from compressed file or construct it:
        fnsuf = '' if suffix is None else suffix
        try:
            logger.debug(f"Gunzip: Attempting to determine gunzip target filename for: {file}")
            gunzipfn = os.path.join(resultdir, os.path.splitext(os.path.basename(file))[0] + fnsuf)
        except Exception as e:
            basenf = os.path.basename(file)
            gunzipfn = os.path.join(resultdir, os.path.splitext(basenf)[0] + fnsuf)
            logger.warning(f"Gunzip: gzinfo() failed on '{file}', fallback used. Reason: {e}")
            logger.debug(f"Gunzip: Fallback filename constructed: {gunzipfn}")
        #
        logger.info(f"Gunzip: Unzipping '{file}' to '{gunzipfn}'")
        try:
            with gzip.open(file, 'rb') as f_in:
                with open(gunzipfn, 'wb') as f_out:
                    shutil.copyfileobj(f_in, f_out)
                logger.info(f"Gunzip: Successfully unzipped: {gunzipfn}")
        except Exception as e:
            logger.error(f"Gunzip: Failed to unzip file '{file}' to '{gunzipfn}': {e}")
            raise

        return gunzipfn
