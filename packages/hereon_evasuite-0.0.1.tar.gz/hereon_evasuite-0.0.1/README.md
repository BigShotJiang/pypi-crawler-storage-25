# EvaSuite

**EvaSuite** is a climate data evaluation and visualization framework designed for HPC and local environments.
It provides reproducible, configuration-driven workflows for comparing climate datasets, computing diagnostics, and generating scientific visualizations.

---

## Important Note on Installation

When installing via `pip`:

```bash
pip install hereon-evasuite
```

➡️ **Only the core EvaSuite package is installed.**

The following are **NOT included**:

* external submodules (e.g. PlotSmart)
* example datasets
* repository-level runners and workflows

These components are available in the GitLab repository and must be cloned separately if required.

---

## Environment Setup (Required)

Before running EvaSuite, you **must create a compatible Python environment**.

### Requirements

* Python ≥ 3.10
* CDO
* NCO
* NetCDF-fortran
* (Optional) X11 / GUI environment for interactive tools

---

### Recommended setup (HPC / pip)

```bash
# Create environment
python -m venv ~/evasuite_env
source ~/evasuite_env/bin/activate

# Install dependencies
pip install -r requirements.txt

# Install EvaSuite
pip install .
```

---

### Notes

Some dependencies (e.g. `numba`) are version-sensitive.
You may see warnings such as:

```
requires numba>=0.52, but you'll have numba 0.51.2
```

These are usually harmless but indicate environment mismatch.

---

## Running EvaSuite

EvaSuite is fully **configuration-driven**.
Before running, you must prepare configuration files.

---

## Required Configuration Files

The following YAML configurations are **essential**:

### System configuration (external tools)

```bash
-c, --cfgsys
```

* Defines paths to external tools (CDO, NCO, etc.)
* If not provided → uses bundled default config
* Inspect default config:

```bash
evasuite --printsys
```

---

### General configuration

```bash
-g, --cfggen
```

* Global EvaSuite options
* Workflow control and processing settings

---

### Reference datasets

```bash
-r, --inprefdat
```

* Defines observational/reference datasets

---

### Model datasets

```bash
-p, --inpproofdat
```

* Defines model or simulation datasets

---

## Optional Configuration

These are optional but commonly used:

### Plot configuration

```bash
--plot-config
```

* Custom plotting settings
* If not provided → defaults are used

---

### Map configuration

```bash
--map-config
```

* Controls map visualization settings

---

### Taylor diagram configuration

```bash
--taylor-config
```

* Required for Taylor plots
* If missing → program exits with error

---

### GUI mode (optional)

EvaSuite supports GUI-based configuration for:

* Taylor plots
* visualization workflows

Requires working X11 environment.

---

## Example Usage

```bash
evasuite \
  --cfgsys system.yaml \
  --cfggen general.yaml \
  --inprefdat reference.yaml \
  --inpproofdat model.yaml
```

---

## Repository (Full Features)

For full functionality, including:

* examples (`EXAMPLE/`)
* documentation (`DOCS/`)
* external modules
* advanced workflows

please use the GitLab repository:

```
https://gitlab.dkrz.de/clm-community/public/evasuite
```

---

## Updating EvaSuite (Source Install)

```bash
cd EvaSuite
git pull
pip uninstall hereon_evasuite
pip install .
```

---

## Uninstall

```bash
pip uninstall hereon_evasuite
```

---

## Support

* Technical: [evgenii.churiulin@kit.edu](mailto:evgenii.churiulin@kit.edu)
* Scientific: [beate.geyer@hereon.de](mailto:beate.geyer@hereon.de)
* Documentation: [evgenii.churiulin@kit.edu](mailto:evgenii.churiulin@kit.edu), [christoph.braun@kit.edu](mailto:christoph.braun@kit.edu)

---

## License

Apache-2.0
