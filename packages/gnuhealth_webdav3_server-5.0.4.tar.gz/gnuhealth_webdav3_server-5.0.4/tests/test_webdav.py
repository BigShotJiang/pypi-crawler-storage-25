# SPDX-FileCopyrightText: 2012-2017 Cédric Krier
# SPDX-FileCopyrightText: 2017-2026 GNU Solidario <health@gnusolidario.org>
# SPDX-FileCopyrightText: 2017-2026 Luis Falcon <falcon@gnuhealth.org>
#
# SPDX-License-Identifier: GPL-3.0-or-later
# This file is part of Tryton.  The COPYRIGHT file at the top level of
# this repository contains the full copyright notices and license terms.
from trytond.tests.test_tryton import ModuleTestCase


class WebdavTestCase(ModuleTestCase):
    'Test Webdav module'
    module = 'health_webdav3_server'


del ModuleTestCase
