"""PostgreSQL type OID constants and Python ↔ Postgres type coercion.

Handles encoding Python values into wire-format bytes and decoding
Postgres text-mode results back into Python objects.

Every column in a PostgreSQL result set carries a numeric type OID that
identifies its data type.  This module maps those OIDs to Python decoder
functions so that, for example, an ``int4`` column (OID 23) is automatically
converted to a Python ``int`` and a ``timestamptz`` column (OID 1184) becomes
a ``datetime``.

On the encoding side, Python values passed as query parameters are converted
to their text-mode wire representation.  Lists and tuples are encoded as
Postgres array literals (e.g. ``{1,2,3}``), which means ``ANY(:ids)`` with
a Python list just works — no special handling required.

Supported type mappings:

+-------------------+-------------------+---------------------+
| Postgres type     | OID               | Python type         |
+===================+===================+=====================+
| bool              | 16                | bool                |
| int2 / smallint   | 21                | int                 |
| int4 / integer    | 23                | int                 |
| int8 / bigint     | 20                | int                 |
| float4 / real     | 700               | float               |
| float8 / double   | 701               | float               |
| numeric / decimal | 1700              | Decimal             |
| text              | 25                | str                 |
| varchar           | 1043              | str                 |
| char / bpchar     | 1042              | str                 |
| bytea             | 17                | str (hex-encoded)   |
| date              | 1082              | date                |
| time              | 1083              | time                |
| timestamp         | 1114              | datetime            |
| timestamptz       | 1184              | datetime            |
| json              | 114               | dict / list         |
| jsonb             | 3802              | dict / list         |
| uuid              | 2950              | str                 |
| int4[]            | 1007              | list                |
| int8[]            | 1016              | list                |
| text[]            | 1009              | list                |
| float8[]          | 1022              | list                |
| varchar[]         | 1015              | list                |
+-------------------+-------------------+---------------------+

Unrecognised OIDs are returned as plain strings — the raw text from the server.
"""

from __future__ import annotations

import json
from datetime import date, datetime, time, timedelta
from decimal import Decimal
from typing import Any

# ---------------------------------------------------------------------------
# Well-known PostgreSQL type OIDs (text-mode results include these)
# ---------------------------------------------------------------------------

BOOL_OID = 16
BYTEA_OID = 17
INT2_OID = 21
INT4_OID = 23
INT8_OID = 20
FLOAT4_OID = 700
FLOAT8_OID = 701
NUMERIC_OID = 1700
TEXT_OID = 25
VARCHAR_OID = 1043
BPCHAR_OID = 1042
DATE_OID = 1082
TIME_OID = 1083
TIMESTAMP_OID = 1114
TIMESTAMPTZ_OID = 1184
JSON_OID = 114
JSONB_OID = 3802
UUID_OID = 2950
INT4_ARRAY_OID = 1007
INT8_ARRAY_OID = 1016
TEXT_ARRAY_OID = 1009
FLOAT8_ARRAY_OID = 1022
VARCHAR_ARRAY_OID = 1015

# ---------------------------------------------------------------------------
# Decode: text-mode Postgres value → Python object
# ---------------------------------------------------------------------------

_DECODERS: dict[int, Any] = {
    BOOL_OID: lambda v: v == "t",
    INT2_OID: int,
    INT4_OID: int,
    INT8_OID: int,
    FLOAT4_OID: float,
    FLOAT8_OID: float,
    NUMERIC_OID: Decimal,
    JSON_OID: json.loads,
    JSONB_OID: json.loads,
}


def _decode_date(v: str) -> date:
    return date.fromisoformat(v)


def _decode_time(v: str) -> time:
    return time.fromisoformat(v)


def _decode_timestamp(v: str) -> datetime:
    # Postgres sends e.g. "2024-01-15 10:30:00" or with fractional seconds
    return datetime.fromisoformat(v.replace(" ", "T"))


def _decode_array(v: str) -> list:
    """Parse a Postgres text-mode array literal like {1,2,3} or {"a","b"}."""
    if v == "{}":
        return []
    # Strip outer braces
    inner = v[1:-1]
    return _parse_array_elements(inner)


def _parse_array_elements(s: str) -> list:
    """Parse comma-separated elements from inside a Postgres array literal."""
    elements: list = []
    i = 0
    n = len(s)

    while i < n:
        if s[i] == '"':
            # Quoted element — find closing quote, handle \"
            i += 1
            parts: list[str] = []
            while i < n:
                if s[i] == "\\" and i + 1 < n:
                    parts.append(s[i + 1])
                    i += 2
                elif s[i] == '"':
                    i += 1  # skip closing quote
                    break
                else:
                    parts.append(s[i])
                    i += 1
            elements.append("".join(parts))
            # skip comma
            if i < n and s[i] == ",":
                i += 1
        elif s[i] == "{":
            # Nested array
            depth = 1
            start = i
            i += 1
            while i < n and depth > 0:
                if s[i] == "{":
                    depth += 1
                elif s[i] == "}":
                    depth -= 1
                i += 1
            elements.append(_decode_array(s[start:i]))
            if i < n and s[i] == ",":
                i += 1
        else:
            # Unquoted element — read until comma
            start = i
            while i < n and s[i] != ",":
                i += 1
            token = s[start:i]
            if token == "NULL":
                elements.append(None)
            else:
                elements.append(token)
            if i < n:
                i += 1  # skip comma

    return elements


_DECODERS[DATE_OID] = _decode_date
_DECODERS[TIME_OID] = _decode_time
_DECODERS[TIMESTAMP_OID] = _decode_timestamp
_DECODERS[TIMESTAMPTZ_OID] = _decode_timestamp
_DECODERS[INT4_ARRAY_OID] = _decode_array
_DECODERS[INT8_ARRAY_OID] = _decode_array
_DECODERS[TEXT_ARRAY_OID] = _decode_array
_DECODERS[FLOAT8_ARRAY_OID] = _decode_array
_DECODERS[VARCHAR_ARRAY_OID] = _decode_array


def decode_value(oid: int, raw: bytes | None) -> Any:
    """Decode a text-mode Postgres column value to a Python object.

    Called automatically for every column in every row of a query result.
    You should not normally need to call this directly.

    Parameters:
        oid: The PostgreSQL type OID from the RowDescription message.
        raw: The raw bytes from the DataRow message, or ``None`` for SQL NULL.

    Returns:
        The decoded Python value.  Returns ``None`` for SQL NULL.
        Falls back to returning the raw UTF-8 string when the OID is not
        in the decoder table.
    """
    if raw is None:
        return None
    text = raw.decode("utf-8")
    decoder = _DECODERS.get(oid)
    if decoder is not None:
        return decoder(text)
    return text


# ---------------------------------------------------------------------------
# Encode: Python value → text-mode bytes for parameterised queries
# ---------------------------------------------------------------------------

def encode_value(val: Any) -> bytes | None:
    """Encode a Python value into text-mode bytes for the Postgres wire protocol.

    Called automatically for every parameter in a parameterised query.
    You should not normally need to call this directly.

    Supports: ``None`` (NULL), ``bool``, ``int``, ``float``, ``Decimal``,
    ``str``, ``bytes``, ``datetime``, ``date``, ``time``, ``list``/``tuple``
    (arrays), and ``dict`` (JSON).

    Parameters:
        val: The Python value to encode.

    Returns:
        Text-mode bytes ready for the wire, or ``None`` to represent SQL NULL.

    Examples::

        encode_value(42)                → b'42'
        encode_value(True)              → b't'
        encode_value([1, 2, 3])         → b'{1,2,3}'
        encode_value({"key": "val"})    → b'{"key": "val"}'
        encode_value(None)              → None
    """
    if val is None:
        return None
    if isinstance(val, bool):
        return b"t" if val else b"f"
    if isinstance(val, int):
        return str(val).encode()
    if isinstance(val, float):
        return str(val).encode()
    if isinstance(val, Decimal):
        return str(val).encode()
    if isinstance(val, str):
        return val.encode("utf-8")
    if isinstance(val, bytes):
        return b"\\x" + val.hex().encode()
    if isinstance(val, datetime):
        return val.isoformat().encode()
    if isinstance(val, date):
        return val.isoformat().encode()
    if isinstance(val, time):
        return val.isoformat().encode()
    if isinstance(val, (list, tuple)):
        return _encode_array(val)
    if isinstance(val, dict):
        return json.dumps(val).encode("utf-8")
    # fallback
    return str(val).encode("utf-8")


def _encode_array(arr: list | tuple) -> bytes:
    """Encode a Python list/tuple into a Postgres array literal.

    Examples::

        [1, 2, 3]          → b'{1,2,3}'
        ["hello", "world"]  → b'{"hello","world"}'
        [[1,2],[3,4]]       → b'{{1,2},{3,4}}'
    """
    return _format_array(arr).encode("utf-8")


def _format_array(arr: list | tuple) -> str:
    parts: list[str] = []
    for item in arr:
        if item is None:
            parts.append("NULL")
        elif isinstance(item, (list, tuple)):
            parts.append(_format_array(item))
        elif isinstance(item, bool):
            parts.append("t" if item else "f")
        elif isinstance(item, (int, float, Decimal)):
            parts.append(str(item))
        elif isinstance(item, str):
            # Escape backslashes and quotes inside the element
            escaped = item.replace("\\", "\\\\").replace('"', '\\"')
            parts.append(f'"{escaped}"')
        else:
            escaped = str(item).replace("\\", "\\\\").replace('"', '\\"')
            parts.append(f'"{escaped}"')
    return "{" + ",".join(parts) + "}"
