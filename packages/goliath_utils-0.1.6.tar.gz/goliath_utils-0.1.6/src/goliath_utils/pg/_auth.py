"""SCRAM-SHA-256 and MD5 authentication for PostgreSQL.

Implements the SASL SCRAM-SHA-256 exchange (RFC 5802) used by Postgres 10+
as the default authentication method, plus the legacy MD5 password scheme
for older servers.

The SCRAM-SHA-256 handshake is a three-step challenge-response:

1. **client-first-message** — client sends username + random nonce
2. **server-first-message** — server returns its nonce, salt, and iteration count
3. **client-final-message** — client derives keys via PBKDF2, sends proof
4. **server-final-message** — server proves it knows the password too (mutual auth)

This implementation uses only the Python standard library (``hashlib``,
``hmac``, ``os``, ``base64``) — no cryptography or cffi dependencies.
"""

from __future__ import annotations

import hashlib
import hmac
import os
import base64
from dataclasses import dataclass


# ---------------------------------------------------------------------------
# MD5 authentication (legacy)
# ---------------------------------------------------------------------------

def md5_password(user: str, password: str, salt: bytes) -> bytes:
    """Build the MD5 password response expected by Postgres.

    Returns the bytes to send in a PasswordMessage (type ``p``).
    """
    # md5(md5(password + user) + salt)
    inner = hashlib.md5((password + user).encode("utf-8")).hexdigest().encode()
    outer = b"md5" + hashlib.md5(inner + salt).hexdigest().encode()
    return outer


# ---------------------------------------------------------------------------
# SCRAM-SHA-256
# ---------------------------------------------------------------------------

def _hi(password: bytes, salt: bytes, iterations: int) -> bytes:
    """PBKDF2-HMAC-SHA-256 (Hi function from RFC 5802)."""
    return hashlib.pbkdf2_hmac("sha256", password, salt, iterations)


def _hmac_sha256(key: bytes, msg: bytes) -> bytes:
    return hmac.new(key, msg, hashlib.sha256).digest()


def _h(data: bytes) -> bytes:
    return hashlib.sha256(data).digest()


def _xor(a: bytes, b: bytes) -> bytes:
    return bytes(x ^ y for x, y in zip(a, b))


@dataclass
class ScramClient:
    """Manages a single SCRAM-SHA-256 authentication exchange.

    Created internally by the protocol layer when the server requests
    SASL authentication.  You should not need to use this class directly.

    The exchange flows as:

    1. Call :meth:`client_first_message` — sends to server as SASLInitialResponse
    2. Receive server-first-message, pass to :meth:`client_final_message`
    3. Receive server-final-message, pass to :meth:`verify_server_final`

    Attributes:
        user: The PostgreSQL username.
        password: The plaintext password (used to derive PBKDF2 keys).
    """

    user: str
    password: str
    _nonce: str = ""
    _client_first_bare: str = ""
    _server_first: str = ""
    _auth_message: str = ""
    _server_key: bytes = b""

    def client_first_message(self) -> bytes:
        """Generate the client-first-message for SASLInitialResponse."""
        self._nonce = base64.b64encode(os.urandom(18)).decode("ascii")
        self._client_first_bare = f"n={self.user},r={self._nonce}"
        # gs2-header is "n,," (no channel binding)
        msg = f"n,,{self._client_first_bare}"
        return msg.encode("utf-8")

    def client_final_message(self, server_first: bytes) -> bytes:
        """Process server-first-message and return client-final-message."""
        self._server_first = server_first.decode("utf-8")
        parts = dict(kv.split("=", 1) for kv in self._server_first.split(","))

        server_nonce = parts["r"]
        salt = base64.b64decode(parts["s"])
        iterations = int(parts["i"])

        if not server_nonce.startswith(self._nonce):
            raise ValueError("Server nonce does not start with client nonce")

        salted_password = _hi(
            self.password.encode("utf-8"), salt, iterations
        )
        client_key = _hmac_sha256(salted_password, b"Client Key")
        stored_key = _h(client_key)
        self._server_key = _hmac_sha256(salted_password, b"Server Key")

        # channel-binding = base64("n,,")
        channel_binding = base64.b64encode(b"n,,").decode()
        client_final_no_proof = f"c={channel_binding},r={server_nonce}"

        self._auth_message = (
            f"{self._client_first_bare},{self._server_first},{client_final_no_proof}"
        )

        client_signature = _hmac_sha256(
            stored_key, self._auth_message.encode("utf-8")
        )
        client_proof = _xor(client_key, client_signature)
        proof_b64 = base64.b64encode(client_proof).decode()

        return f"{client_final_no_proof},p={proof_b64}".encode("utf-8")

    def verify_server_final(self, server_final: bytes) -> None:
        """Verify the server-final-message signature.

        Raises *ValueError* if the server signature doesn't match.
        """
        text = server_final.decode("utf-8")
        parts = dict(kv.split("=", 1) for kv in text.split(","))

        expected = _hmac_sha256(
            self._server_key, self._auth_message.encode("utf-8")
        )
        received = base64.b64decode(parts["v"])

        if not hmac.compare_digest(expected, received):
            raise ValueError("Server signature verification failed")
