from dataclasses import dataclass
from . import *

N_RWG = 1

@dataclass
class dio(config):
    card: str
    channel: int
    input: int | bool = False
    state: int | bool = True
    
    def __post_init__(self):
        global N_RWG
        if self.card.startswith('rwg'):
            N_RWG = max(N_RWG,int(self.card[3:])+1)
            
    @property
    def on(self):
        return self(state=True)

    @property
    def off(self):
        return self(state=False)


@dataclass
class ramp(config):
    start: float
    stop: float
    type: str = 'linear'

    def __call__(self, dur):
        if self.type == 'linear':
            return [self.start, (self.stop - self.start) / dur, 0, 0]
        elif self.type == 'lut':
            return [self.start, 9.99 / dur, 'lut', self.stop << 12]


@dataclass
class rf(config):
    card: str
    channel: int
    carrier: float
    f: float | list[float] | dict[int, float | list[float]] = None
    a: float | list[float] | dict[int, float | list[float]] = None
    p: float | None | dict[int, float | None] = None
    r: int | bool | dict[int, int | bool] = False

    def __post_init__(self):
        global N_RWG
        if self.card.startswith('rwg'):
            N_RWG = max(N_RWG,int(self.card[3:])+1)
            
    @property
    def off(self):
        if isinstance(self.a, list):
            a = [0] * len(self.a)
        elif isinstance(self.a, dict):
            a = {k: 0 for k in self.a}
        else:
            a = 0
        return self(a=a)


@dataclass
class dac(config):
    channel: int
    v: float | list[float] = 0


class wave(table):
    def __init__(self, *args, **kwargs):
        super().__init__(*args,**kwargs)
    
    def __getattribute__(self, key):
        if key.startswith('_') or key in (
            'append',
            'copy',
            'compute',
            'getdoc',
            'play',
            'size',
            'shape',
        ):
            return super().__getattribute__(key)
        val = getattr(self.__class__, key, None)
        if val is None:
            return super().__getattribute__(key)
        self.append(val)
        return self

    def __call__(self, *args, **kwargs):
        if len(args) == 0 and len(kwargs) == 0:
            shots = self.__dict__.get('shots',None)
            return wave.play(table('','seq_init'),
                    table(None,'while_') if shots is None else table(None,'for_','$20',shots),
                    *self[:],table(None,'end'),**self.__dict__)
        self[-1] = self[-1].copy()(*args,**kwargs)
        return self

    @staticmethod
    def play(*args, **kwargs):
        if len(args) > 0 and not isinstance(args[0],table):
            func = getattr(wave,args[0],None) if type(args[0]) is str else args[0]
            return func(*args[1:],**kwargs) if callable(func) else [table(*args,**kwargs)]
        dur = kwargs.get('us', 0)
        seq = []
        flex_seq = table('flex', kwargs.get('flex', 'dac_play'), dur, dac={}, on=[], off=[])
        main_seq = table('main', kwargs.get('main', 'main_play'), dur, ttl=[])
        rwg_seq = {
            f'rwg{i}': table(
                f'rwg{i}',
                kwargs.get(f'rwg{i}', 'rwg_play'),
                dur,
                sbg={},
                dio=[],
                rf=kwargs.get(f'rf{i}', []),
                org=kwargs.get(f'org{i}', []),
                sel=kwargs.get(f'sel{i}', None),
            )
            for i in range(N_RWG)
        }
        for pfl in args:
            if type(pfl) is dio:
                card = pfl.card
                chan = pfl.channel
                state = pfl.state
                if card == 'flex':
                    if state:
                        flex_seq.on.append(chan)
                    else:
                        flex_seq.off.append(chan)
                elif card == 'main':
                    main_seq.ttl.append(chan)
                else:
                    rwg_seq[card].dio.append(chan)
            elif type(pfl) is rf:
                card = pfl.card
                chan = pfl.channel
                fd = pfl.f if isinstance(pfl.f, dict) else {0: pfl.f}
                ad = pfl.a if isinstance(pfl.a, dict) else {0: pfl.a}
                pd = pfl.p if isinstance(pfl.p, dict) else {0: pfl.p}
                rd = pfl.r if isinstance(pfl.r, dict) else {0: pfl.r}
                for i in fd:
                    f = fd[i]
                    if type(f) is not expr and callable(f):
                        f = f(dur)
                    a = ad.get(i, None)
                    if type(a) is not expr and callable(a):
                        a = a(dur)
                    rwg_seq[card].sbg[(chan << 5) + i] = (
                        f,
                        a,
                        pd.get(i, None),
                        int(rd.get(i, False)),
                    )
            elif type(pfl) is dac:
                v = pfl.v
                if type(v) is not expr and callable(v):
                    v = v(dur)
                flex_seq.dac[pfl.channel] = v
            else:
                dct = {k: kwargs[k] if k in kwargs else pfl.__dict__[k] for k in pfl.__dict__}
                seq += wave.play(*pfl[:],**dct)
        return seq if len(seq) else ([flex_seq,main_seq]+list(rwg_seq.values()))