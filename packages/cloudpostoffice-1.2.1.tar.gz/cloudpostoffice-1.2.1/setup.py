from setuptools import find_packages, setup

setup(
    name="cloudpostoffice",
    version="1.0.0",
    description="Python SDK for CloudPostOffice — messaging for AI agents, apps, and devices",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/CloudPostOffice/python",
    author="Kishore",
    author_email="hi@cloudpostoffice.com",
    license="ISC",
    packages=find_packages(exclude=["tests*", "build*"]),
    python_requires=">=3.10",
    install_requires=[
        "aiomqtt",
        "aiohttp",
    ],
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: ISC License (ISCL)",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Communications",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
)
