"""
Unit tests for clientId parsing.

The auth API returns clientId as "accountRef:projectId:deviceId".
These tests verify that account_ref and project_id are extracted
correctly and never contain a colon.

Run:
    python tests/test_client_id_split.py
"""

import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))


def parse_client_id(client_id: str) -> tuple[str, str]:
    """Mirror of the logic in Device._connection_loop."""
    account_ref, project_id, *_ = client_id.split(":")
    return account_ref, project_id


def run_tests() -> None:
    passed = 0
    failed = 0

    def check(label: str, actual, expected) -> None:
        nonlocal passed, failed
        if actual == expected:
            print(f"  PASS  {label}")
            passed += 1
        else:
            print(f"  FAIL  {label}")
            print(f"        expected: {expected!r}")
            print(f"        got:      {actual!r}")
            failed += 1

    print("\nclientId split — unit tests")
    print("-" * 30)

    # Standard 3-part clientId from the API
    account_ref, project_id = parse_client_id("acct1:proj-abc:device-1")
    check("account_ref from 3-part id", account_ref, "acct1")
    check("project_id from 3-part id", project_id, "proj-abc")
    check("project_id has no colon",   ":" not in project_id, True)

    # Realistic values matching the live API format
    account_ref, project_id = parse_client_id("a1b2c3:proj-djsa1qqo:proj-djsa1qqo--device-1")
    check("realistic account_ref",      account_ref, "a1b2c3")
    check("realistic project_id",       project_id,  "proj-djsa1qqo")
    check("realistic project_id clean", ":" not in project_id, True)

    # Extra colons in deviceId part must not pollute account_ref or project_id
    account_ref, project_id = parse_client_id("acct:proj:device:with:extra:colons")
    check("extra colons — account_ref", account_ref, "acct")
    check("extra colons — project_id",  project_id,  "proj")
    check("extra colons — no colon in project_id", ":" not in project_id, True)

    # Resulting topic prefix must match ACL pattern exactly
    account_ref, project_id = parse_client_id("ref99:projX:devY")
    topic_prefix = f"{account_ref}/{project_id}"
    check("topic prefix format",        topic_prefix, "ref99/projX")
    check("topic prefix has no colon",  ":" not in topic_prefix, True)

    print(f"\nPassed: {passed}   Failed: {failed}\n")
    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    run_tests()
