"""
Live auth test — fetches a real JWT and prints every field returned by the API.

Run:
    python tests/test_auth_values.py
"""

import asyncio
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

import cloudpostoffice  # noqa: F401 — sets WindowsSelectorEventLoopPolicy on Windows
import aiohttp

# ── load .env.test if credentials not already in environment ─────────────────
import pathlib

env_file = pathlib.Path(__file__).parent.parent / ".env.test"
if env_file.exists():
    for line in env_file.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, _, v = line.partition("=")
            k, v = k.strip(), v.strip()
            if k and v and k not in os.environ:
                os.environ[k] = v

BASE_URL      = os.environ.get("CPO_BASE_URL", "https://cloudpostoffice.com")
DEVICE_ID     = os.environ.get("CPO_TEST_DEVICE_1_ID", "")
DEVICE_SECRET = os.environ.get("CPO_TEST_DEVICE_1_SECRET", "")


async def main() -> None:
    if not DEVICE_ID or not DEVICE_SECRET:
        print("ERROR: CPO_TEST_DEVICE_1_ID / CPO_TEST_DEVICE_1_SECRET not set")
        sys.exit(1)

    print(f"Base URL : {BASE_URL}")
    print(f"Device ID: {DEVICE_ID}")
    print()

    async with aiohttp.ClientSession() as session:
        async with session.post(
            f"{BASE_URL}/api/authenticate",
            json={"deviceId": DEVICE_ID, "deviceSecret": DEVICE_SECRET},
            timeout=aiohttp.ClientTimeout(total=15),
        ) as resp:
            data = await resp.json()
            if resp.status >= 400:
                print(f"Auth FAILED ({resp.status}): {data}")
                sys.exit(1)

    print("=== Raw API response ===")
    for k, v in data.items():
        if k == "token":
            print(f"  token     : {v[:40]}...  (truncated)")
        else:
            print(f"  {k:<10}: {v!r}")

    client_id = data.get("clientId", "")
    print()
    print("=== clientId split ===")
    print(f"  raw clientId : {client_id!r}")
    parts = client_id.split(":")
    print(f"  split parts  : {parts}")

    if len(parts) >= 3:
        account_ref, project_id, *rest = parts
        print(f"  account_ref  : {account_ref!r}")
        print(f"  project_id   : {project_id!r}")
        print(f"  device part  : {rest!r}")
        print()
        print("=== Expected topic paths ===")
        print(f"  inbox  : {account_ref}/{project_id}/devices/{DEVICE_ID}")
        print(f"  topic  : {account_ref}/{project_id}/topic/<name>")
    else:
        print(f"  WARNING: expected 3 parts, got {len(parts)}: {parts}")

asyncio.run(main())
