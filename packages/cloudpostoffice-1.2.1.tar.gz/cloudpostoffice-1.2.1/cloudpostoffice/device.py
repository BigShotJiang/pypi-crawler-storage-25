"""Device class — authenticates with CloudPostOffice and manages a persistent MQTT session."""

from __future__ import annotations

import asyncio
import json
import logging
import ssl
import time
from typing import Any, Callable

import aiohttp
import aiomqtt

from .exceptions import AuthenticationError, ConnectionTimeoutError

logger = logging.getLogger(__name__)

BROKER_PORT = 8883
CONNECT_TIMEOUT = 15.0
BACKOFF_INITIAL = 1.0
BACKOFF_MAX = 60.0


class Device:
    """
    A handle for a single CloudPostOffice device.

    Authenticates automatically on first use and maintains a persistent MQTT
    connection with exponential-backoff reconnection.

    Usage::

        d = Device("my-device-id", "my-secret")
        await d.send(to="other-device", msg="hello")
        await d.listen(lambda msg: print(msg))
    """

    def __init__(
        self,
        device_id: str,
        device_secret: str,
        base_url: str = "https://cloudpostoffice.com",
    ) -> None:
        self._id = device_id
        self._secret = device_secret
        self._base_url = base_url.rstrip("/")

        self._auth: dict | None = None
        self._account_ref: str | None = None
        self._project_id: str | None = None

        self._client: aiomqtt.Client | None = None
        self._intentional_disconnect = False
        self._subscriptions: list[tuple[str, Callable]] = []

        self._connected_event = asyncio.Event()
        self._connect_task: asyncio.Task | None = None
        self._tls_ctx = ssl.create_default_context()

    # ── Public API ────────────────────────────────────────────────────────────

    def _validate_topic_name(self, name: str) -> None:
        if not name or not isinstance(name, str):
            raise ValueError("Topic name must be a non-empty string")
        for char in ("/", "+", "#"):
            if char in name:
                raise ValueError(f'Topic name must not contain "{char}": "{name}"')
        if "--" in name:
            raise ValueError(f'Topic name must not contain "--": "{name}"')

    async def send(self, *, to: str, msg: Any) -> None:
        """Send a direct message to another device on the same account/project."""
        if not to:
            raise ValueError('send() requires a "to" parameter with the target device ID')
        await self._connect()
        topic = self._topic(f"devices/{to}")
        payload = json.dumps({"from": self._id, "msg": msg, "ts": int(time.time() * 1000)})
        await self._publish(topic, payload)

    async def listen(self, callback: Callable) -> "Device":
        """
        Register a callback for messages addressed to this device.
        Callback signature: fn(message) where message is {from, msg, ts}.
        Returns self for chaining.
        """
        await self._connect()
        topic = self._topic(f"devices/{self._id}")
        await self._subscribe(topic, callback)
        return self

    async def publish(self, topic_name: str, message: Any) -> None:
        """Publish a message to a named topic."""
        self._validate_topic_name(topic_name)
        await self._connect()
        topic = self._topic(f"topic/{topic_name}")
        payload = message if isinstance(message, str) else json.dumps(message)
        await self._publish(topic, payload)

    async def subscribe(self, topic_name: str, callback: Callable) -> "Device":
        """
        Subscribe to a named topic.
        Callback signature: fn(topic_name, message).
        Returns self for chaining.
        """
        self._validate_topic_name(topic_name)
        await self._connect()
        topic = self._topic(f"topic/{topic_name}")

        # Wrap to match the expected (topic_name, msg) signature
        if asyncio.iscoroutinefunction(callback):
            async def wrapped(msg: Any, _t: str = topic_name, _cb: Callable = callback) -> None:
                await _cb(_t, msg)
        else:
            def wrapped(msg: Any, _t: str = topic_name, _cb: Callable = callback) -> None:  # type: ignore[misc]
                _cb(_t, msg)

        await self._subscribe(topic, wrapped)
        return self

    def disconnect(self) -> None:
        """Gracefully signal the connection loop to stop."""
        self._intentional_disconnect = True
        if self._connect_task and not self._connect_task.done():
            self._connect_task.cancel()

    # ── Internals ─────────────────────────────────────────────────────────────

    async def _connect(self) -> None:
        """Ensure the device is connected, starting the connection loop if needed."""
        if self._connected_event.is_set():
            return

        if self._connect_task is None or self._connect_task.done():
            self._connected_event.clear()
            self._connect_task = asyncio.create_task(self._connection_loop())

        # Poll until connected, the background task fails, or we time out.
        # Using a simple poll instead of asyncio.wait avoids CancelledError
        # propagation edge-cases across nested except handlers on Python 3.10+.
        loop = asyncio.get_event_loop()
        deadline = loop.time() + CONNECT_TIMEOUT

        while not self._connected_event.is_set():
            if self._connect_task.done():
                # Task exited early (e.g. auth error) — surface the real cause.
                if not self._connect_task.cancelled():
                    self._connect_task.result()  # re-raises stored exception
                raise ConnectionTimeoutError(
                    f"MQTT connection timed out for device '{self._id}'"
                )
            remaining = deadline - loop.time()
            if remaining <= 0:
                raise ConnectionTimeoutError(
                    f"MQTT connection timed out for device '{self._id}'"
                )
            await asyncio.sleep(min(0.1, remaining))

    async def _authenticate(self) -> dict:
        async with aiohttp.ClientSession() as session:
            try:
                async with session.post(
                    f"{self._base_url}/api/authenticate",
                    json={"deviceId": self._id, "deviceSecret": self._secret},
                    timeout=aiohttp.ClientTimeout(total=15),
                ) as resp:
                    data = await resp.json()
                    if resp.status >= 400:
                        raise AuthenticationError(
                            data.get("error", "Authentication failed"),
                            status=resp.status,
                        )
                    return data
            except aiohttp.ClientError as exc:
                raise AuthenticationError(
                    f"Network error during authentication: {exc}"
                ) from exc

    async def _connection_loop(self) -> None:
        self._auth = await self._authenticate()
        client_id: str = self._auth["clientId"]
        # clientId format from the API is "accountRef:projectId:deviceId"
        # Split into exactly 3 parts — never use maxsplit=1 which would
        # collapse "projectId:deviceId" into a single wrong token.
        account_ref, project_id, *_ = client_id.split(":")
        self._account_ref = account_ref
        self._project_id = project_id

        delay = BACKOFF_INITIAL

        while not self._intentional_disconnect:
            try:
                async with aiomqtt.Client(
                    hostname=self._auth["broker"],
                    port=BROKER_PORT,
                    identifier=client_id,
                    username=self._id,
                    password=self._auth["token"],
                    tls_context=self._tls_ctx,
                    protocol=aiomqtt.ProtocolVersion.V5,
                ) as client:
                    self._client = client

                    # Re-subscribe all registered topics on every (re)connect
                    for topic_filter, _ in self._subscriptions:
                        await client.subscribe(topic_filter, qos=1)

                    self._connected_event.set()
                    delay = BACKOFF_INITIAL  # reset backoff after successful connect

                    async for message in client.messages:
                        if self._intentional_disconnect:
                            return
                        await self._dispatch(message)

            except asyncio.CancelledError:
                break

            except Exception as exc:
                if self._intentional_disconnect:
                    break
                logger.warning(
                    "Connection error (%s: %s). Reconnecting in %.1fs...",
                    type(exc).__name__, exc, delay,
                )
                self._client = None
                self._connected_event.clear()
                await asyncio.sleep(delay)
                delay = min(delay * 2, BACKOFF_MAX)

                try:
                    self._auth = await self._authenticate()
                except Exception as auth_exc:
                    logger.error("Re-authentication failed: %s", auth_exc)

        self._client = None
        self._connected_event.clear()

    async def _dispatch(self, message: aiomqtt.Message) -> None:
        topic_str = str(message.topic)
        try:
            raw = message.payload.decode()
        except Exception:
            raw = str(message.payload)
        try:
            payload: Any = json.loads(raw)
        except json.JSONDecodeError:
            payload = raw

        for topic_filter, callback in self._subscriptions:
            if topic_filter == topic_str:
                try:
                    if asyncio.iscoroutinefunction(callback):
                        await callback(payload)
                    else:
                        callback(payload)
                except Exception as exc:
                    logger.error("Handler error for topic %s: %s", topic_str, exc)

    def _topic(self, subtopic: str) -> str:
        return f"{self._account_ref}/{self._project_id}/{subtopic}"

    async def _publish(self, topic: str, payload: str) -> None:
        if self._client is None:
            raise RuntimeError("Not connected to MQTT broker")
        await self._client.publish(topic, payload=payload, qos=1)

    async def _subscribe(self, topic_filter: str, callback: Callable) -> None:
        self._subscriptions.append((topic_filter, callback))
        if self._client is not None:
            await self._client.subscribe(topic_filter, qos=1)
