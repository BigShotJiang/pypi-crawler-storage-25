"""
CloudPostOffice Python SDK.

Quick start::

    import cloudpostoffice as cpo

    cpo.configure(base_url="https://cloudpostoffice.com")

    d1 = cpo.device("device-1", "your-secret")
    d2 = cpo.device("device-2", "your-secret")

    # Direct messaging
    await d1.send(to="device-2", msg="hello")
    await d2.listen(lambda msg: print(msg))

    # Pub/Sub
    await d1.subscribe("news", lambda topic, msg: print(topic, msg))
    await d2.publish("news", {"headline": "CloudPostOffice is alive!"})

For a decorator-based MQTT client (direct broker connection, no auth)::

    from cloudpostoffice import CloudPostOfficeClient
    cpo = CloudPostOfficeClient("broker.emqx.io")

    @cpo.on("alerts/#")
    async def on_alert(payload: str):
        print(payload)

    asyncio.run(cpo.listen())
"""

from __future__ import annotations

import asyncio
import logging
import re
import sys

# aiomqtt (via paho-mqtt) uses add_reader/add_writer which are not supported
# by Windows' default ProactorEventLoop.  Switch to SelectorEventLoop on Windows
# so the SDK works out of the box without any user configuration.
if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

# Attach a stderr handler so SDK warnings (connection errors, retries) are
# visible by default without requiring the caller to configure logging.
_handler = logging.StreamHandler(sys.stderr)
_handler.setFormatter(logging.Formatter("[cloudpostoffice] %(levelname)s: %(message)s"))
logging.getLogger("cloudpostoffice").addHandler(_handler)
logging.getLogger("cloudpostoffice").setLevel(logging.WARNING)

from .client import CloudPostOfficeClient
from .device import Device
from .exceptions import AuthenticationError, CloudPostOfficeError, ConnectionTimeoutError

__version__ = "1.0.0"
__author__ = "Kishore"

_options: dict = {"base_url": "https://cloudpostoffice.com"}
_default_device: Device | None = None


def device(device_id: str, device_secret: str) -> Device:
    """
    Create a device handle.  Authenticates and connects to the MQTT broker
    automatically on first use.

    The first device created becomes the default for top-level
    ``cpo.publish()`` / ``cpo.subscribe()`` calls.

    :param device_id:     Your device ID from the dashboard.
    :param device_secret: Your device secret from the dashboard.
    :returns:             A :class:`~cloudpostoffice.device.Device` instance.

    Example::

        d = cpo.device("my-device-id", "my-secret")
        await d.send(to="other-device", msg="hello")
    """
    global _default_device
    if not device_id or not device_secret:
        raise ValueError("device() requires both a device_id and a device_secret")
    d = Device(device_id, device_secret, _options["base_url"])
    if _default_device is None:
        _default_device = d
    return d


async def publish(topic_name: str, message) -> None:
    """Publish to a named topic using the default device."""
    if _default_device is None:
        raise RuntimeError("Call cpo.device() before cpo.publish()")
    await _default_device.publish(topic_name, message)


async def subscribe(topic_name: str, callback) -> Device:
    """Subscribe to a named topic using the default device."""
    if _default_device is None:
        raise RuntimeError("Call cpo.device() before cpo.subscribe()")
    return await _default_device.subscribe(topic_name, callback)


def configure(*, base_url: str | None = None) -> None:
    """
    Override SDK-level options.  Call before creating any devices.

    :param base_url: Base URL of the CloudPostOffice API
                     (must use ``https://`` except for localhost).

    Example::

        cpo.configure(base_url="https://cloudpostoffice.com")
    """
    if base_url is not None:
        is_localhost = bool(
            re.match(r"^https?://(localhost|127\.0\.0\.1)(:\d+)?", base_url)
        )
        if not is_localhost and not base_url.startswith("https://"):
            raise ValueError(
                "base_url must use https:// (http:// is only allowed for localhost)"
            )
        _options["base_url"] = base_url


__all__ = [
    "CloudPostOfficeClient",
    "Device",
    "CloudPostOfficeError",
    "AuthenticationError",
    "ConnectionTimeoutError",
    "device",
    "publish",
    "subscribe",
    "configure",
]
