"""Custom exceptions for the CloudPostOffice SDK."""


class CloudPostOfficeError(Exception):
    """Base exception for all CloudPostOffice SDK errors."""


class AuthenticationError(CloudPostOfficeError):
    """Raised when authentication with the CloudPostOffice API fails."""

    def __init__(self, message: str, status: int = 0) -> None:
        super().__init__(message)
        self.status = status


class ConnectionTimeoutError(CloudPostOfficeError):
    """Raised when the MQTT connection times out."""
