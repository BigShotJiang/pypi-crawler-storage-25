"""CloudPostOfficeClient — lightweight decorator-based MQTT subscriber."""

from __future__ import annotations

import asyncio
import logging
from typing import Callable

import aiomqtt

logger = logging.getLogger(__name__)


def _mqtt_topic_matches(pattern: str, topic: str) -> bool:
    """Return True if *topic* matches the MQTT wildcard *pattern*."""
    def _match(pp: list[str], tp: list[str]) -> bool:
        if pp and pp[0] == "#":
            return True
        if not pp and not tp:
            return True
        if not pp or not tp:
            return False
        if pp[0] == "+" or pp[0] == tp[0]:
            return _match(pp[1:], tp[1:])
        return False

    return _match(pattern.split("/"), topic.split("/"))


class CloudPostOfficeClient:
    """
    A minimal async MQTT client with a decorator-based subscription API.

    Connects directly to any MQTT broker (no CloudPostOffice authentication).
    Use :class:`~cloudpostoffice.device.Device` when you need full
    CloudPostOffice auth + namespaced topics.

    Usage::

        cpo = CloudPostOfficeClient("broker.emqx.io")

        @cpo.on("my/topic")
        def on_message(payload: str):
            print(payload)

        @cpo.on("alerts/#")
        async def on_alert(payload: str):
            await some_coroutine(payload)

        asyncio.run(cpo.listen())
    """

    def __init__(self, broker_url: str, port: int = 1883) -> None:
        self._broker_url = broker_url
        self._port = port
        self._handlers: dict[str, Callable] = {}

    def on(self, topic: str) -> Callable:
        """
        Decorator that registers *func* as the handler for *topic*.

        Accepts both ``def`` and ``async def`` handlers transparently.

        Example::

            @cpo.on("sensors/temperature")
            async def handle_temp(payload: str):
                print(payload)
        """
        def decorator(func: Callable) -> Callable:
            self._handlers[topic] = func
            return func
        return decorator

    async def listen(self) -> None:
        """
        Connect to the broker, subscribe all registered topics, and process
        incoming messages indefinitely.

        Reconnects automatically if the connection drops — no sleep needed
        because ``async for message in client.messages`` is naturally idle
        between messages.

        Call once with ``asyncio.run(cpo.listen())``.
        """
        while True:
            try:
                async with aiomqtt.Client(self._broker_url, port=self._port) as client:
                    for topic in self._handlers:
                        await client.subscribe(topic)

                    async for message in client.messages:
                        topic_str = str(message.topic)
                        try:
                            payload = message.payload.decode()
                        except Exception:
                            payload = str(message.payload)

                        handler = self._handlers.get(topic_str)
                        if handler is None:
                            for pattern, h in self._handlers.items():
                                if _mqtt_topic_matches(pattern, topic_str):
                                    handler = h
                                    break

                        if handler is not None:
                            try:
                                if asyncio.iscoroutinefunction(handler):
                                    await handler(payload)
                                else:
                                    handler(payload)
                            except Exception as exc:
                                logger.error(
                                    "Handler error for topic %s: %s", topic_str, exc
                                )

            except aiomqtt.MqttError as exc:
                logger.warning("MQTT connection error: %s. Reconnecting…", exc)
