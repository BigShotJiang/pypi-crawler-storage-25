# Getting Started

This tutorial walks you through installing `axm-mcp` and verifying your setup.

## Prerequisites

- Python 3.12+
- [uv](https://docs.astral.sh/uv/) (recommended) or pip

## Installation

```bash
uv add axm-mcp
```

## Quick Start

See the [Quickstart](quickstart.md) guide for a hands-on tutorial.

## Next Steps

- [CLI Reference](../reference/cli.md) — Full command documentation
- [Architecture](../explanation/architecture.md) — How the project is structured
