"""Shared provider runtime wiring for product surfaces.

This module keeps surface-level provider profile parsing, encrypted local
credential lookup, endpoint model discovery, and runtime capability selection
in one place so CLI, API, and gateway do not each keep private copies of the
same rules.
"""

from __future__ import annotations

import base64
from collections.abc import Mapping
from dataclasses import dataclass, field
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import shutil
import subprocess
from typing import Any
from urllib import error, request
from urllib.parse import quote

from packages.auth import (
    AuthProfile,
    LocalEncryptedSecretCipher,
    PersistentAuthProfileStore,
    ProfileCredentialResolver,
    ProviderAuthState,
    ProviderCatalog,
    ProviderProfileFactory,
    ProviderProfileInput,
    SecretValueResolution,
    SecretReference,
    SecretStore,
    profile_from_input,
)
from packages.capabilities.runtime import CapabilityDescriptor, ModelProviderCapability
from packages.contracts.runtime import ContextBundle, ExecutionResult, ProfileState, SessionState
from packages.models import ModelRequest, ProviderRuntimeResolver
from packages.models.provider_catalog import default_provider_definitions, provider_definition
from packages.models.providers import build_model_adapter
from packages.storage import RuntimeStorageRepository
from packages.tools import ToolDefinition, ToolRuntime

_MODEL_CONTEXT_KEYS = (
    "context_length",
    "context_window",
    "max_context_length",
    "max_position_embeddings",
    "max_model_len",
    "max_input_tokens",
    "max_sequence_length",
    "max_seq_len",
    "n_ctx",
    "n_ctx_train",
)
_MODEL_OUTPUT_KEYS = (
    "max_completion_tokens",
    "max_output_tokens",
    "max_tokens",
)
DEFAULT_CONTEXT_WINDOW_TOKENS = 128_000


@dataclass(frozen=True, slots=True)
class DiscoveredProviderModel:
    model_id: str
    label: str
    context_window_tokens: int | None = None
    max_output_tokens: int | None = None
    source: str = "endpoint"
    metadata: Mapping[str, str] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class DiscoveredProviderState:
    provider_id: str
    display_name: str
    transport_display_name: str
    auth_type: str
    provider_kind: str
    runtime_enabled: bool
    status: str
    source: str
    profile_id: str | None = None
    base_url: str | None = None
    default_model: str | None = None
    reasoning_efforts: tuple[str, ...] = ()
    metadata: Mapping[str, str] = field(default_factory=dict)


def _normalize_base_url(base_url: str | None) -> str:
    return str(base_url or "").strip().rstrip("/")


def _compose_provider_url(base_url: str, endpoint_path: str) -> str:
    trimmed_base = _normalize_base_url(base_url)
    trimmed_path = endpoint_path.lstrip("/")
    if trimmed_path.startswith("v1/") and trimmed_base.endswith("/v1"):
        trimmed_path = trimmed_path[3:]
    return f"{trimmed_base}/{trimmed_path}"


def _coerce_reasonable_int(value: Any, *, minimum: int = 1024, maximum: int = 10_000_000) -> int | None:
    try:
        if isinstance(value, bool):
            return None
        if isinstance(value, str):
            value = value.strip().replace(",", "")
        parsed = int(value)
    except (TypeError, ValueError):
        return None
    if minimum <= parsed <= maximum:
        return parsed
    return None


def _iter_nested_mappings(value: Any):
    if isinstance(value, Mapping):
        yield value
        for nested in value.values():
            yield from _iter_nested_mappings(nested)
    elif isinstance(value, list):
        for item in value:
            yield from _iter_nested_mappings(item)


def _extract_nested_int(payload: Mapping[str, Any], keys: tuple[str, ...]) -> int | None:
    keyset = {key.casefold() for key in keys}
    for mapping in _iter_nested_mappings(payload):
        for key, value in mapping.items():
            if str(key).casefold() not in keyset:
                continue
            parsed = _coerce_reasonable_int(value)
            if parsed is not None:
                return parsed
    return None


def _context_window_from_payload(payload: Mapping[str, Any]) -> int | None:
    return _extract_nested_int(payload, _MODEL_CONTEXT_KEYS)


def _max_output_tokens_from_payload(payload: Mapping[str, Any]) -> int | None:
    return _extract_nested_int(payload, _MODEL_OUTPUT_KEYS)


def _provider_request_headers(
    *,
    provider_id: str,
    request_family: str,
    api_key: str | None,
    extra_headers: Mapping[str, str] | None = None,
) -> dict[str, str]:
    headers: dict[str, str] = {"Accept": "application/json", **dict(extra_headers or {})}
    if not api_key:
        return headers
    if request_family == "messages" or provider_id in {"anthropic", "minimax"}:
        headers["x-api-key"] = api_key
        headers["anthropic-version"] = "2023-06-01"
        return headers
    headers["Authorization"] = f"Bearer {api_key}"
    return headers


def _request_json(
    *,
    url: str,
    headers: Mapping[str, str],
    timeout_seconds: float = 10.0,
) -> dict[str, Any]:
    http_request = request.Request(
        url,
        headers=dict(headers),
        method="GET",
    )
    try:
        with request.urlopen(http_request, timeout=timeout_seconds) as response:
            raw_body = response.read().decode("utf-8")
            payload = json.loads(raw_body) if raw_body else {}
    except error.HTTPError as exc:  # pragma: no cover - exercised by integration tests
        detail = exc.read().decode("utf-8", errors="replace").strip()
        suffix = f" {detail[:200]}" if detail else ""
        raise RuntimeError(f"provider metadata request failed with status {exc.code}.{suffix}".strip()) from exc
    except error.URLError as exc:  # pragma: no cover - exercised by integration tests
        raise RuntimeError(f"provider metadata request failed for {url}: {exc.reason}") from exc
    if isinstance(payload, list):
        return {"data": payload}
    if not isinstance(payload, dict):
        raise RuntimeError("provider metadata response must be a JSON object")
    return {str(key): value for key, value in payload.items()}


def _provider_metadata(provider_id: str) -> Mapping[str, str]:
    definition = provider_definition(provider_id)
    if definition is None:
        return {}
    return {str(key): str(value) for key, value in dict(definition.metadata).items()}


def _provider_model_catalog_path(provider_id: str) -> str:
    configured = _provider_metadata(provider_id).get("model_catalog_path", "").strip()
    return configured or "/v1/models"


def _provider_model_detail_path(provider_id: str, model_id: str) -> str:
    metadata = _provider_metadata(provider_id)
    template = metadata.get("model_detail_path_template", "").strip()
    if template:
        return template.replace("{model_id}", quote(model_id, safe=""))
    catalog_path = _provider_model_catalog_path(provider_id)
    catalog_root = catalog_path.split("?", 1)[0].rstrip("/")
    if catalog_root.endswith("/models"):
        return f"{catalog_root}/{quote(model_id, safe='')}"
    return f"/v1/models/{quote(model_id, safe='')}"


def _provider_model_payload_list_keys(provider_id: str) -> tuple[str, ...]:
    configured = _provider_metadata(provider_id).get("model_payload_list_key", "").strip()
    keys = [configured] if configured else []
    keys.extend(["data", "models"])
    ordered: list[str] = []
    seen: set[str] = set()
    for key in keys:
        normalized = key.strip()
        if not normalized or normalized in seen:
            continue
        seen.add(normalized)
        ordered.append(normalized)
    return tuple(ordered)


def _provider_model_id_keys(provider_id: str) -> tuple[str, ...]:
    configured = _provider_metadata(provider_id).get("model_payload_id_key", "").strip()
    keys = [configured] if configured else []
    keys.extend(["id", "slug"])
    ordered: list[str] = []
    seen: set[str] = set()
    for key in keys:
        normalized = key.strip()
        if not normalized or normalized in seen:
            continue
        seen.add(normalized)
        ordered.append(normalized)
    return tuple(ordered)


def _provider_model_items(provider_id: str, payload: Mapping[str, Any]) -> tuple[Mapping[str, Any], ...]:
    for list_key in _provider_model_payload_list_keys(provider_id):
        items = payload.get(list_key)
        if not isinstance(items, list):
            continue
        return tuple(item for item in items if isinstance(item, Mapping))
    return ()


def _read_json_object(path: Path) -> dict[str, Any] | None:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    if not isinstance(payload, dict):
        return None
    return {str(key): value for key, value in payload.items()}


def _jwt_claims(token: str) -> Mapping[str, Any]:
    parts = str(token or "").split(".")
    if len(parts) < 2:
        return {}
    padded = parts[1] + "=" * (-len(parts[1]) % 4)
    try:
        decoded = base64.urlsafe_b64decode(padded.encode("ascii"))
        payload = json.loads(decoded.decode("utf-8"))
    except (ValueError, UnicodeDecodeError, json.JSONDecodeError):
        return {}
    if not isinstance(payload, dict):
        return {}
    return {str(key): value for key, value in payload.items()}


def _jwt_token_is_expiring(token: str, *, skew_seconds: int = 0) -> bool:
    claims = _jwt_claims(token)
    exp = claims.get("exp")
    if not isinstance(exp, (int, float)):
        return False
    return float(exp) <= (datetime.now(timezone.utc).timestamp() + max(0, int(skew_seconds)))


def _timestamp_string_is_expiring(value: Any, *, skew_seconds: int = 0) -> bool:
    text = str(value or "").strip()
    if not text:
        return False
    if text.endswith("Z"):
        text = f"{text[:-1]}+00:00"
    try:
        expires_at = datetime.fromisoformat(text)
    except ValueError:
        return False
    if expires_at.tzinfo is None:
        expires_at = expires_at.replace(tzinfo=timezone.utc)
    return expires_at.timestamp() <= (datetime.now(timezone.utc).timestamp() + max(0, int(skew_seconds)))


def _codex_auth_path() -> Path:
    codex_home = os.environ.get("CODEX_HOME", "").strip()
    if not codex_home:
        codex_home = str(Path.home() / ".codex")
    return Path(codex_home).expanduser() / "auth.json"


def _read_codex_cli_resolution() -> SecretValueResolution | None:
    auth_path = _codex_auth_path()
    if not auth_path.is_file():
        return None
    payload = _read_json_object(auth_path)
    if payload is None:
        return None
    tokens = payload.get("tokens")
    if not isinstance(tokens, Mapping):
        return None
    access_token = str(tokens.get("access_token", "") or "").strip()
    refresh_token = str(tokens.get("refresh_token", "") or "").strip()
    if not access_token or not refresh_token or _jwt_token_is_expiring(access_token):
        return None
    return SecretValueResolution(value=access_token, source=f"codex-cli:{auth_path}")


def _qwen_auth_path() -> Path:
    return Path.home() / ".qwen" / "oauth_creds.json"


def _hermes_auth_path() -> Path:
    hermes_home = os.environ.get("HERMES_HOME", "").strip()
    if not hermes_home:
        hermes_home = str(Path.home() / ".hermes")
    return Path(hermes_home).expanduser() / "auth.json"


def _read_hermes_provider_state(provider_id: str) -> dict[str, Any] | None:
    auth_path = _hermes_auth_path()
    if not auth_path.is_file():
        return None
    payload = _read_json_object(auth_path)
    if payload is None:
        return None
    providers = payload.get("providers")
    if not isinstance(providers, Mapping):
        return None
    state = providers.get(provider_id)
    if not isinstance(state, Mapping):
        return None
    return {str(key): value for key, value in state.items()}


def _read_hermes_credential_pool(provider_id: str) -> tuple[dict[str, Any], ...]:
    auth_path = _hermes_auth_path()
    if not auth_path.is_file():
        return ()
    payload = _read_json_object(auth_path)
    if payload is None:
        return ()
    credential_pool = payload.get("credential_pool")
    if not isinstance(credential_pool, Mapping):
        return ()
    entries = credential_pool.get(provider_id)
    if not isinstance(entries, list):
        return ()
    normalized: list[dict[str, Any]] = []
    for entry in entries:
        if isinstance(entry, Mapping):
            normalized.append({str(key): value for key, value in entry.items()})
    return tuple(normalized)


def _read_qwen_oauth_resolution() -> SecretValueResolution | None:
    auth_path = _qwen_auth_path()
    if not auth_path.is_file():
        return None
    payload = _read_json_object(auth_path)
    if payload is None:
        return None
    access_token = str(payload.get("access_token", "") or "").strip()
    if not access_token:
        return None
    try:
        expiry_ms = int(payload.get("expiry_date"))
    except (TypeError, ValueError):
        expiry_ms = 0
    if expiry_ms and expiry_ms <= int(datetime.now(timezone.utc).timestamp() * 1000):
        return None
    return SecretValueResolution(value=access_token, source=f"qwen-cli:{auth_path}")


def _read_hermes_codex_resolution() -> SecretValueResolution | None:
    auth_path = _hermes_auth_path()
    for entry in _read_hermes_credential_pool("openai-codex"):
        access_token = str(
            entry.get("runtime_api_key")
            or entry.get("access_token")
            or ""
        ).strip()
        if access_token and not _jwt_token_is_expiring(access_token):
            return SecretValueResolution(
                value=access_token,
                source=f"hermes-auth-store:{auth_path}:openai-codex:pool",
            )
    state = _read_hermes_provider_state("openai-codex")
    if state is None:
        return None
    tokens = state.get("tokens")
    if not isinstance(tokens, Mapping):
        return None
    access_token = str(tokens.get("access_token", "") or "").strip()
    if not access_token or _jwt_token_is_expiring(access_token):
        return None
    return SecretValueResolution(value=access_token, source=f"hermes-auth-store:{auth_path}:openai-codex")


def _read_copilot_resolution() -> SecretValueResolution | None:
    for env_name in ("COPILOT_GITHUB_TOKEN", "GH_TOKEN", "GITHUB_TOKEN"):
        value = os.environ.get(env_name)
        if value:
            return SecretValueResolution(value=value, source=f"env:{env_name}")
    try:
        completed = subprocess.run(
            ["gh", "auth", "token"],
            check=True,
            capture_output=True,
            text=True,
            timeout=5,
        )
    except (FileNotFoundError, subprocess.SubprocessError):
        return None
    token = completed.stdout.strip()
    if not token:
        return None
    return SecretValueResolution(value=token, source="gh-cli")


def _copilot_acp_status() -> tuple[str, str] | None:
    base_url = os.environ.get("COPILOT_ACP_BASE_URL", "").strip()
    if base_url.startswith("acp+tcp://"):
        return (base_url, "env:COPILOT_ACP_BASE_URL")
    command = (
        os.environ.get("AEGIS_COPILOT_ACP_COMMAND", "").strip()
        or os.environ.get("HERMES_COPILOT_ACP_COMMAND", "").strip()
        or os.environ.get("COPILOT_CLI_PATH", "").strip()
        or "copilot"
    )
    resolved = shutil.which(command) if command else None
    if resolved:
        return ("acp://copilot", f"command:{resolved}")
    return None


def _base_url_aliases(provider_id: str) -> tuple[str, ...]:
    aliases = {
        "openai-codex": ("HERMES_CODEX_BASE_URL",),
        "qwen-oauth": ("HERMES_QWEN_BASE_URL",),
    }
    return aliases.get(provider_id, ())


def _provider_base_url_from_env(provider_id: str, primary_env_var: str | None) -> str | None:
    candidates = []
    if primary_env_var:
        candidates.append(primary_env_var)
    candidates.extend(_base_url_aliases(provider_id))
    for env_name in candidates:
        value = os.environ.get(env_name, "").strip()
        if value:
            return value
    return None


def provider_profile_from_payload(payload: Mapping[str, Any]) -> AuthProfile:
    secret_references = tuple(
        secret_reference_from_payload(item)
        for item in payload.get("secret_references", ())
    )
    profile_input = ProviderProfileInput(
        profile_id=str(payload["profile_id"]),
        provider_id=str(payload["provider_id"]),
        secret_references=secret_references,
        priority=int(payload.get("priority", 0)),
        session_pin=str(payload["session_pin"]) if payload.get("session_pin") is not None else None,
        cooldown_until=None,
        metadata={str(key): str(value) for key, value in dict(payload.get("metadata", {})).items()},
    )
    provider_id = profile_input.provider_id
    base_url = payload.get("base_url")
    default_model = payload.get("default_model")
    transport_id = payload.get("transport_id")
    auth_method = payload.get("auth_method")
    provider_kind = payload.get("provider_kind")
    extra_headers = payload.get("extra_headers")
    catalog = ProviderCatalog.with_defaults()
    provider_defaults = catalog.get(provider_id)
    if provider_id == "openai-compatible" and (base_url is None or default_model is None):
        raise ValueError("openai-compatible provider profiles require base_url and default_model")
    if any(value is not None for value in (base_url, default_model, transport_id, auth_method, provider_kind, extra_headers)):
        default_profile = None
        if provider_defaults is not None:
            default_profile = ProviderProfileFactory(catalog).from_provider_defaults(
                provider_id,
                profile_id=profile_input.profile_id,
                secret_references=profile_input.secret_references,
                priority=profile_input.priority,
                session_pin=profile_input.session_pin,
                cooldown_until=profile_input.cooldown_until,
                metadata=profile_input.metadata,
            )
        return profile_from_input(
            profile_input,
            base_url=(
                str(base_url)
                if base_url is not None
                else (default_profile.base_url if default_profile is not None else "")
            ),
            default_model=(
                str(default_model)
                if default_model is not None
                else (default_profile.default_model if default_profile is not None else "")
            ),
            transport_id=(
                str(transport_id)
                if transport_id is not None
                else (default_profile.transport_id if default_profile is not None else "openai-compatible")
            ),
            auth_method=(
                str(auth_method)
                if auth_method is not None
                else (default_profile.auth_method if default_profile is not None else "api_key")
            ),
            provider_kind=(
                str(provider_kind)
                if provider_kind is not None
                else (default_profile.provider_kind if default_profile is not None else "custom")
            ),
            extra_headers=(
                {
                    **(dict(default_profile.extra_headers) if default_profile is not None else {}),
                    **{str(key): str(value) for key, value in dict(extra_headers or {}).items()},
                }
            ),
        )
    factory = ProviderProfileFactory(catalog)
    return factory.from_provider_defaults(
        provider_id,
        profile_id=profile_input.profile_id,
        secret_references=profile_input.secret_references,
        priority=profile_input.priority,
        session_pin=profile_input.session_pin,
        cooldown_until=profile_input.cooldown_until,
        metadata=profile_input.metadata,
    )


def secret_reference_from_payload(payload: Mapping[str, Any]) -> SecretReference:
    return SecretReference(
        reference_id=str(payload["reference_id"]),
        provider_id=str(payload["provider_id"]),
        secret_name=str(payload["secret_name"]),
        secret_key=str(payload["secret_key"]),
        source=str(payload.get("source", "workspace")),
        metadata={str(key): str(value) for key, value in dict(payload.get("metadata", {})).items()},
    )


def load_provider_profile(profile_dir: Path) -> AuthProfile | None:
    manifest_path = profile_dir / "profile.json"
    if not manifest_path.exists():
        return None
    with manifest_path.open("r", encoding="utf-8") as handle:
        payload = json.load(handle)
    if not isinstance(payload, dict):
        raise ValueError("profile.json must contain a JSON object")
    provider_payload = payload.get("provider_profile")
    if not isinstance(provider_payload, dict):
        return None
    return provider_profile_from_payload(provider_payload)


RUNTIME_LOCAL_SECRET_ENV_FILE = "runtime-local-secrets.json"


def runtime_local_secret_env_path(state_dir: Path) -> Path:
    return state_dir / RUNTIME_LOCAL_SECRET_ENV_FILE


def load_runtime_local_secret_env(state_dir: Path | None) -> dict[str, str]:
    if state_dir is None:
        return {}
    path = runtime_local_secret_env_path(state_dir)
    if not path.exists():
        return {}
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, Mapping):
        raise ValueError(f"{path} must contain a JSON object")
    resolved: dict[str, str] = {}
    for key, value in payload.items():
        text = str(value).strip()
        if text:
            resolved[str(key)] = text
    return resolved


def persist_runtime_local_secret_env(
    state_dir: Path | None,
    updates: Mapping[str, str],
) -> Path | None:
    if state_dir is None:
        return None
    filtered = {str(key): str(value).strip() for key, value in updates.items() if str(value).strip()}
    if not filtered:
        return None
    state_dir.mkdir(parents=True, exist_ok=True)
    path = runtime_local_secret_env_path(state_dir)
    payload = load_runtime_local_secret_env(state_dir)
    payload.update(filtered)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass
    return path


def capture_runtime_secret_env(
    state_dir: Path | None,
    profile: AuthProfile | None,
    *,
    environ: Mapping[str, str] | None = None,
) -> Path | None:
    if profile is None:
        return None
    source = os.environ if environ is None else environ
    updates: dict[str, str] = {}
    for reference in profile.secret_references:
        for env_var in reference.env_var_candidates():
            value = str(source.get(env_var) or "").strip()
            if value:
                updates[env_var] = value
    return persist_runtime_local_secret_env(state_dir, updates)


def build_runtime_secret_environ(
    state_dir: Path | None,
    *,
    environ: Mapping[str, str] | None = None,
) -> dict[str, str]:
    resolved = load_runtime_local_secret_env(state_dir)
    source = os.environ if environ is None else environ
    resolved.update({str(key): str(value) for key, value in source.items()})
    return resolved


def provider_profile_summary(profile: AuthProfile) -> dict[str, Any]:
    context_window_tokens = _coerce_reasonable_int(profile.metadata.get("context_window_tokens"))
    return {
        "profile_id": profile.profile_id,
        "provider_id": profile.provider_id,
        "transport_id": profile.transport_id,
        "base_url": profile.base_url,
        "default_model": profile.default_model,
        "auth_method": profile.auth_method,
        "provider_kind": profile.provider_kind,
        "extra_headers": dict(profile.extra_headers),
        "secret_reference_ids": tuple(reference.reference_id for reference in profile.secret_references),
        "context_window_tokens": context_window_tokens,
        "context_window_mode": str(profile.metadata.get("context_window_mode", "auto")),
        "reasoning_effort": str(profile.metadata.get("reasoning_effort", "")).strip() or None,
        "source": "configured",
    }


def provider_fallback_summary() -> dict[str, Any]:
    return {
        "profile_id": "",
        "provider_id": "preview",
        "transport_id": "preview",
        "base_url": None,
        "default_model": None,
        "auth_method": "preview",
        "provider_kind": "preview",
        "extra_headers": {},
        "secret_reference_ids": (),
        "context_window_tokens": None,
        "context_window_mode": "unset",
        "reasoning_effort": None,
        "source": "preview-fallback",
    }


def _normalize_env_name(candidate: str) -> str:
    return candidate.strip().replace("-", "_").replace(".", "_").upper()


class EnvironmentSecretStore(SecretStore):
    def __init__(self, environ: Mapping[str, str] | None = None) -> None:
        self.environ = environ

    def resolve(self, reference: SecretReference) -> SecretValueResolution:
        env = self.environ or os.environ
        candidates: list[str] = list(reference.env_var_candidates())
        seen = set(candidates)
        for candidate in (reference.secret_name, reference.secret_key, reference.reference_id):
            normalized = _normalize_env_name(candidate)
            if normalized and normalized not in seen:
                seen.add(normalized)
                candidates.append(normalized)
        for candidate in candidates:
            value = env.get(candidate)
            if value is not None:
                return SecretValueResolution(value=value, source=f"env:{candidate}")
        raise LookupError(f"missing environment secret for reference: {reference.reference_id}")

    def read(self, reference: SecretReference) -> str:
        return self.resolve(reference).value


class EncryptedRepositorySecretStore(SecretStore):
    def __init__(
        self,
        repository: RuntimeStorageRepository,
        *,
        cipher: LocalEncryptedSecretCipher,
    ) -> None:
        self.repository = repository
        self.cipher = cipher

    def resolve(self, reference: SecretReference) -> SecretValueResolution:
        stored = self.repository.load_auth_secret_value(reference.reference_id)
        if stored is not None:
            return SecretValueResolution(
                value=self.cipher.decrypt(stored),
                source="encrypted-local-store",
            )
        for env_name in reference.env_var_candidates():
            value = os.environ.get(env_name)
            if value is not None:
                return SecretValueResolution(value=value, source=f"env:{env_name}")
        external = self._external_resolution(reference)
        if external is not None:
            return external
        raise LookupError(f"missing stored secret for reference: {reference.reference_id}")

    def read(self, reference: SecretReference) -> str:
        return self.resolve(reference).value

    def _external_resolution(self, reference: SecretReference) -> SecretValueResolution | None:
        provider_id = reference.provider_id.strip().lower()
        if provider_id == "openai-codex":
            return _read_codex_cli_resolution() or _read_hermes_codex_resolution()
        if provider_id == "qwen-oauth":
            return _read_qwen_oauth_resolution()
        if provider_id == "copilot":
            return _read_copilot_resolution()
        return None


class SurfaceModelProviderCapability(ModelProviderCapability):
    def __init__(
        self,
        *,
        repository: RuntimeStorageRepository,
        fallback: ModelProviderCapability,
        secret_key_path: Path,
        credential_resolver: ProfileCredentialResolver | None = None,
        tool_runtime: ToolRuntime | None = None,
        active_provider_profile_id: str | None = None,
        active_provider_id: str | None = None,
        capability_id: str = "surface.model.runtime",
        surface_label: str = "surface",
    ) -> None:
        self.repository = repository
        self.fallback = fallback
        self.secret_cipher = LocalEncryptedSecretCipher.from_path(secret_key_path)
        self.credential_resolver = credential_resolver or ProfileCredentialResolver(
            EncryptedRepositorySecretStore(
                repository,
                cipher=self.secret_cipher,
            )
        )
        self.tool_runtime = tool_runtime
        self.active_provider_profile_id = active_provider_profile_id
        self.active_provider_id = active_provider_id
        self.runtime_resolver = ProviderRuntimeResolver.default()
        self._stream_observer = None
        self.descriptor = CapabilityDescriptor(
            capability_id=capability_id,
            kind="model_provider",
            version="1.0.0",
            metadata={"description": f"{surface_label} model provider runtime wired to persisted provider profiles."},
        )

    def set_active_profile(
        self,
        *,
        provider_profile_id: str | None,
        provider_id: str | None,
    ) -> None:
        self.active_provider_profile_id = provider_profile_id
        self.active_provider_id = provider_id

    def active_profile(self) -> AuthProfile | None:
        if self.active_provider_profile_id is not None:
            profile = self.repository.load_auth_profile(self.active_provider_profile_id)
            if profile is not None:
                return profile
        if self.active_provider_id is not None:
            try:
                return self.repository.select_auth_profile(self.active_provider_id)
            except LookupError:
                return None
        return None

    def resolve_credentials(self, provider_profile: AuthProfile) -> Mapping[str, str]:
        return self.credential_resolver.resolve(provider_profile).as_mapping()

    def resolve_discovered_credentials(self, provider_id: str) -> Mapping[str, str]:
        resolution = self._discovered_secret_resolution(provider_id)
        if resolution is None:
            return {}
        return {"api_key": resolution.value}

    def has_stored_secret(self, reference_id: str) -> bool:
        return self.repository.has_auth_secret_value(reference_id)

    def store_secret_value(self, reference: SecretReference, value: str) -> None:
        encrypted = self.secret_cipher.encrypt(
            reference_id=reference.reference_id,
            value=value,
        )
        self.repository.upsert_auth_secret_value(encrypted)

    def set_stream_observer(self, observer) -> None:
        self._stream_observer = observer

    def _resolved_extra_headers_for(
        self,
        *,
        provider_id: str,
        active_profile: AuthProfile | None = None,
    ) -> Mapping[str, str]:
        if active_profile is not None and active_profile.provider_id == provider_id:
            if active_profile.extra_headers:
                return dict(active_profile.extra_headers)
        definition = provider_definition(provider_id)
        if definition is None:
            return {}
        return dict(definition.extra_headers)

    def _resolved_metadata_base_url(
        self,
        *,
        provider_id: str,
        base_url: str | None,
        active_profile: AuthProfile | None = None,
    ) -> str | None:
        normalized = _normalize_base_url(base_url)
        if normalized:
            return normalized
        if active_profile is not None and active_profile.provider_id == provider_id:
            normalized = _normalize_base_url(active_profile.base_url)
            if normalized:
                return normalized
        definition = provider_definition(provider_id)
        if definition is None:
            return None
        return _provider_base_url_from_env(provider_id, definition.base_url_env_var) or definition.default_base_url

    def _resolved_metadata_api_key(
        self,
        *,
        provider_id: str,
        explicit_api_key: str | None,
        active_profile: AuthProfile | None = None,
    ) -> str | None:
        if explicit_api_key:
            return explicit_api_key
        if active_profile is not None and active_profile.provider_id == provider_id:
            try:
                bundle = self.credential_resolver.resolve(active_profile)
            except LookupError:
                bundle = None
            if bundle is not None:
                resolved = str(bundle.values.get("api_key", "")).strip()
                if resolved:
                    return resolved
        discovered = self._discovered_secret_resolution(provider_id)
        if discovered is not None:
            resolved = str(discovered.value).strip()
            if resolved:
                return resolved
        return None

    def _hinted_models(self, provider_id: str) -> tuple[DiscoveredProviderModel, ...]:
        definition = provider_definition(provider_id)
        if definition is None:
            return ()
        models: list[DiscoveredProviderModel] = []
        seen: set[str] = set()
        for model_id in definition.model_hints:
            normalized = str(model_id).strip()
            if not normalized or normalized in seen:
                continue
            seen.add(normalized)
            try:
                reasoning_efforts = self.runtime_resolver.resolve(
                    provider_id,
                    model_id=normalized,
                    base_url=definition.default_base_url,
                ).reasoning_efforts
            except Exception:
                reasoning_efforts = ()
            models.append(
                DiscoveredProviderModel(
                    model_id=normalized,
                    label=normalized,
                    context_window_tokens=_heuristic_context_window(normalized),
                    source="catalog-hint",
                    metadata={"reasoning_efforts": ",".join(reasoning_efforts)},
                )
            )
        return tuple(models)

    def _merge_discovered_models(
        self,
        primary: tuple[DiscoveredProviderModel, ...],
        fallback: tuple[DiscoveredProviderModel, ...],
    ) -> tuple[DiscoveredProviderModel, ...]:
        merged = list(primary)
        positions = {item.model_id: index for index, item in enumerate(merged)}
        for hinted in fallback:
            index = positions.get(hinted.model_id)
            if index is None:
                positions[hinted.model_id] = len(merged)
                merged.append(hinted)
                continue
            current = merged[index]
            current_reasoning = str(current.metadata.get("reasoning_efforts", "")).strip()
            hinted_reasoning = str(hinted.metadata.get("reasoning_efforts", "")).strip()
            if current.context_window_tokens is not None and current_reasoning:
                continue
            merged[index] = DiscoveredProviderModel(
                model_id=current.model_id,
                label=current.label or hinted.label,
                context_window_tokens=current.context_window_tokens or hinted.context_window_tokens,
                max_output_tokens=current.max_output_tokens or hinted.max_output_tokens,
                source=current.source,
                metadata={
                    **dict(hinted.metadata),
                    **dict(current.metadata),
                    "reasoning_efforts": current_reasoning or hinted_reasoning,
                },
            )
        return tuple(merged)

    def _profile_secret_status(self, profile: AuthProfile) -> tuple[str, str]:
        if not profile.secret_references:
            return ("not-required", "not-required")
        try:
            bundle = self.credential_resolver.resolve(profile)
        except LookupError:
            return ("missing", "missing")
        sources = tuple(dict.fromkeys(bundle.value_sources.values()))
        source_summary = ", ".join(source for source in sources if source) or "encrypted-local-store"
        return ("stored", source_summary)

    def describe(self) -> Mapping[str, object]:
        profile = self.active_profile()
        if profile is None:
            return provider_fallback_summary()
        summary = provider_profile_summary(profile)
        resolution = self.runtime_resolver.resolve(
            profile.provider_id,
            model_id=profile.default_model,
            base_url=profile.base_url,
        )
        summary.update(
            {
                "display_name": resolution.display_name,
                "transport_display_name": resolution.transport_display_name,
                "supports_streaming": resolution.supports_streaming,
                "supports_reasoning": resolution.supports_reasoning,
                "reasoning_efforts": resolution.reasoning_efforts,
                "auth_type": str(resolution.provider_metadata.get("auth_type", profile.auth_method)),
                "secret_status": self._profile_secret_status(profile)[0],
                "secret_source": self._profile_secret_status(profile)[1],
            }
        )
        return summary

    def discover_models(
        self,
        *,
        provider_id: str,
        base_url: str | None,
        api_key: str | None = None,
    ) -> tuple[DiscoveredProviderModel, ...]:
        active_profile = self.active_profile()
        resolved_base_url = self._resolved_metadata_base_url(
            provider_id=provider_id,
            base_url=base_url,
            active_profile=active_profile,
        )
        hinted_models = self._hinted_models(provider_id)
        if not resolved_base_url:
            return hinted_models
        resolution = self.runtime_resolver.resolve(
            provider_id,
            model_id=self._default_model_for(provider_id) or "model-id",
            base_url=resolved_base_url,
        )
        resolved_api_key = self._resolved_metadata_api_key(
            provider_id=provider_id,
            explicit_api_key=api_key,
            active_profile=active_profile,
        )
        try:
            payload = _request_json(
                url=_compose_provider_url(resolved_base_url, _provider_model_catalog_path(provider_id)),
                headers=_provider_request_headers(
                    provider_id=provider_id,
                    request_family=resolution.request_family,
                    api_key=resolved_api_key,
                    extra_headers=self._resolved_extra_headers_for(
                        provider_id=provider_id,
                        active_profile=active_profile,
                    ),
                ),
            )
        except RuntimeError:
            return hinted_models
        data = _provider_model_items(provider_id, payload)
        if not data:
            return hinted_models
        models: list[DiscoveredProviderModel] = []
        for item in data:
            model_id = ""
            for key in _provider_model_id_keys(provider_id):
                candidate = str(item.get(key) or "").strip()
                if candidate:
                    model_id = candidate
                    break
            if not model_id:
                continue
            context_window_tokens = _context_window_from_payload(item)
            max_output_tokens = _max_output_tokens_from_payload(item)
            label = str(item.get("name") or item.get("label") or model_id)
            reasoning_efforts = ()
            capabilities = item.get("capabilities")
            if isinstance(capabilities, Mapping):
                supports_payload = capabilities.get("supports")
                if isinstance(supports_payload, Mapping):
                    raw_efforts = supports_payload.get("reasoning_effort")
                    if isinstance(raw_efforts, list):
                        reasoning_efforts = tuple(
                            str(value).strip().lower()
                            for value in raw_efforts
                            if str(value).strip()
                        )
            models.append(
                DiscoveredProviderModel(
                    model_id=model_id,
                    label=label,
                    context_window_tokens=context_window_tokens,
                    max_output_tokens=max_output_tokens,
                    metadata={
                        "owned_by": str(item.get("owned_by", "")),
                        "reasoning_efforts": ",".join(reasoning_efforts),
                    },
                )
            )
        if not models:
            return hinted_models
        return self._merge_discovered_models(tuple(models), hinted_models)

    def detect_context_window(
        self,
        *,
        provider_id: str,
        base_url: str | None,
        model_id: str,
        api_key: str | None = None,
    ) -> int | None:
        models = self.discover_models(
            provider_id=provider_id,
            base_url=base_url,
            api_key=api_key,
        )
        for item in models:
            if item.model_id == model_id and item.context_window_tokens is not None:
                return item.context_window_tokens
        active_profile = self.active_profile()
        resolved_base_url = self._resolved_metadata_base_url(
            provider_id=provider_id,
            base_url=base_url,
            active_profile=active_profile,
        )
        if not resolved_base_url:
            return None
        resolution = self.runtime_resolver.resolve(
            provider_id,
            model_id=model_id,
            base_url=resolved_base_url,
        )
        resolved_api_key = self._resolved_metadata_api_key(
            provider_id=provider_id,
            explicit_api_key=api_key,
            active_profile=active_profile,
        )
        try:
            payload = _request_json(
                url=_compose_provider_url(resolved_base_url, _provider_model_detail_path(provider_id, model_id)),
                headers=_provider_request_headers(
                    provider_id=provider_id,
                    request_family=resolution.request_family,
                    api_key=resolved_api_key,
                    extra_headers=self._resolved_extra_headers_for(
                        provider_id=provider_id,
                        active_profile=active_profile,
                    ),
                ),
            )
        except RuntimeError:
            return _heuristic_context_window(model_id)
        return _context_window_from_payload(payload) or _heuristic_context_window(model_id)

    def reasoning_efforts(
        self,
        *,
        provider_id: str,
        model_id: str,
        base_url: str | None = None,
        api_key: str | None = None,
    ) -> tuple[str, ...]:
        resolved_base_url = _normalize_base_url(base_url)
        if resolved_base_url:
            try:
                models = self.discover_models(
                    provider_id=provider_id,
                    base_url=resolved_base_url,
                    api_key=api_key,
                )
            except Exception:
                models = ()
            for item in models:
                if item.model_id != model_id:
                    continue
                raw_efforts = str(item.metadata.get("reasoning_efforts", "")).strip()
                if raw_efforts:
                    return tuple(part for part in raw_efforts.split(",") if part)
        resolution = self.runtime_resolver.resolve(
            provider_id,
            model_id=model_id,
            base_url=base_url,
        )
        return resolution.reasoning_efforts

    def discover_provider_states(self) -> tuple[DiscoveredProviderState, ...]:
        states: list[DiscoveredProviderState] = []
        for definition in default_provider_definitions(include_discovery_only=True):
            state = self._discover_provider_state(definition.provider_id)
            self.repository.upsert_provider_auth_state(
                ProviderAuthState(
                    provider_id=state.provider_id,
                    auth_type=state.auth_type,
                    status=state.status,
                    source=state.source,
                    profile_id=state.profile_id,
                    transport_id=state.metadata.get("transport_id") or None,
                    provider_kind=state.provider_kind,
                    base_url=state.base_url,
                    default_model=state.default_model,
                    runtime_enabled=state.runtime_enabled,
                    summary=state.metadata.get("summary", ""),
                    metadata=dict(state.metadata),
                    discovered_at=datetime.now(timezone.utc),
                    updated_at=datetime.now(timezone.utc),
                )
            )
            states.append(state)
        return tuple(states)

    def discovered_provider_state(self, provider_id: str) -> DiscoveredProviderState:
        return self._discover_provider_state(provider_id)

    def _discover_provider_state(self, provider_id: str) -> DiscoveredProviderState:
        definition = provider_definition(provider_id)
        if definition is None:
            raise LookupError(f"unknown provider definition: {provider_id}")
        try:
            profile = self.repository.select_auth_profile(provider_id)
        except LookupError:
            profile = None
        active_profile = self.active_profile()
        selected_profile = profile if profile is not None else (active_profile if active_profile and active_profile.provider_id == provider_id else None)
        base_url = (
            (selected_profile.base_url if selected_profile is not None else None)
            or _provider_base_url_from_env(definition.provider_id, definition.base_url_env_var)
            or definition.default_base_url
        )
        default_model = (selected_profile.default_model if selected_profile is not None else None) or definition.default_model_id
        if selected_profile is not None:
            secret_status, secret_source = self._profile_secret_status(selected_profile)
            if secret_status == "missing":
                status = "configured-missing-secret"
            else:
                status = "configured"
            source = secret_source if secret_status != "not-required" else "profile"
        else:
            secret_resolution = self._discovered_secret_resolution(provider_id)
            if secret_resolution is not None:
                status = "authenticated"
                source = secret_resolution.source
            elif definition.auth_type == "external_process":
                process_status = _copilot_acp_status() if provider_id == "copilot-acp" else None
                if process_status is not None:
                    base_url = process_status[0]
                    status = "authenticated"
                    source = process_status[1]
                else:
                    status = "discovery-only"
                    source = definition.metadata.get("runtime_status", "discovery-only")
            elif definition.provider_kind == "local" and self._local_provider_reachable(provider_id, base_url):
                status = "available"
                source = "local-probe"
            elif not definition.runtime_enabled:
                status = "discovery-only"
                source = definition.metadata.get("runtime_status", "discovery-only")
            else:
                status = "requires-setup"
                source = "none"
        try:
            resolution = self.runtime_resolver.resolve(
                provider_id,
                model_id=default_model or definition.default_model_id,
                base_url=base_url,
            )
            transport_display_name = resolution.transport_display_name
            reasoning_efforts = resolution.reasoning_efforts
            transport_id = resolution.transport_id
        except Exception:
            transport_display_name = definition.transport_id
            reasoning_efforts = ()
            transport_id = definition.transport_id
        summary = f"{status} via {source}"
        return DiscoveredProviderState(
            provider_id=definition.provider_id,
            display_name=definition.display_name,
            transport_display_name=transport_display_name,
            auth_type=definition.auth_type,
            provider_kind=definition.provider_kind,
            runtime_enabled=definition.runtime_enabled,
            status=status,
            source=source,
            profile_id=selected_profile.profile_id if selected_profile is not None else None,
            base_url=base_url,
            default_model=default_model,
            reasoning_efforts=reasoning_efforts,
            metadata={
                "transport_id": transport_id,
                "summary": summary,
                "supports_custom_base_url": str(definition.supports_custom_base_url).lower(),
            },
        )

    def _discovered_secret_resolution(self, provider_id: str) -> SecretValueResolution | None:
        definition = provider_definition(provider_id)
        if definition is None or not definition.required_secret_keys:
            return None
        reference_metadata: dict[str, str] = {}
        if definition.env_var_names:
            reference_metadata["env_var"] = definition.env_var_names[0]
        synthetic_reference = SecretReference(
            reference_id=f"discovery:{provider_id}:api_key",
            provider_id=provider_id,
            secret_name="api_token",
            secret_key="api_key",
            source="discovery",
            metadata=reference_metadata,
        )
        try:
            return self.credential_resolver.secret_store.resolve(synthetic_reference)
        except LookupError:
            return None

    def _local_provider_reachable(self, provider_id: str, base_url: str | None) -> bool:
        if not _normalize_base_url(base_url):
            return False
        try:
            return bool(self.discover_models(provider_id=provider_id, base_url=base_url))
        except Exception:
            return False

    def _default_model_for(self, provider_id: str) -> str | None:
        try:
            guide = self.runtime_resolver.build_setup_guide(provider_id)
        except LookupError:
            return None
        return guide.suggested_model_id

    def _model_visible_tools(self) -> tuple[ToolDefinition, ...]:
        if self.tool_runtime is None:
            return ()
        return self.tool_runtime.list_tools(
            audience="model",
            enabled_only=True,
            available_only=True,
        )

    def _fallback_tool_prompt(self, tools: tuple[ToolDefinition, ...]) -> str:
        summaries = "\n".join(f"- {tool.prompt_summary()}" for tool in tools)
        return (
            "## available runtime tools\n"
            "Native provider tool calling is unavailable on this transport. "
            "Use the governed built-in tool surface through fallback markup when tool work is necessary.\n"
            "Emit <tool_call><invoke name=\"tool.id\"><parameter name=\"arg\">value</parameter></invoke></tool_call>.\n"
            "When a parameter needs structured data such as arrays or objects, encode valid JSON inside the parameter body.\n"
            "Do not include raw tool markup in the final user-facing answer.\n"
            "Tool schemas:\n"
            f"{summaries}"
        )

    def generate(
        self,
        *,
        profile: ProfileState,
        session: SessionState,
        context: ContextBundle,
        prompt: str,
    ) -> ExecutionResult:
        active_profile = self.active_profile()
        if active_profile is None:
            return self.fallback.generate(
                profile=profile,
                session=session,
                context=context,
                prompt=prompt,
            )
        resolution = self.runtime_resolver.resolve(
            active_profile.provider_id,
            model_id=active_profile.default_model or None,
            base_url=active_profile.base_url,
        )
        visible_tools = self._model_visible_tools()
        request_tools = (
            tuple(tool.model_function_schema() for tool in visible_tools)
            if resolution.supports_tools
            else ()
        )
        rendered_prompt = context.rendered_prompt or ""
        if visible_tools and not resolution.supports_tools:
            fallback_prompt = self._fallback_tool_prompt(visible_tools)
            rendered_prompt = (
                f"{rendered_prompt}\n\n{fallback_prompt}".strip()
                if rendered_prompt.strip()
                else fallback_prompt
            )

        request = ModelRequest(
            request_id=f"{session.session_id}:model",
            profile_id=profile.profile_id,
            session_id=session.session_id,
            provider_id=active_profile.provider_id,
            model_id=active_profile.default_model or "",
            prompt=prompt,
            context={
                "bundle_id": context.bundle_id,
                "token_budget": str(context.token_budget),
                "instruction_refs": ",".join(context.instruction_refs),
                "goal_ids": ",".join(context.goal_ids),
                "memory_ids": ",".join(context.memory_ids),
                "artifact_ids": ",".join(context.artifact_ids),
                "rendered_prompt": rendered_prompt,
            },
            reasoning_effort=str(active_profile.metadata.get("reasoning_effort", "")).strip() or None,
            metadata={
                "profile_mode": profile.mode,
                "session_status": session.status,
                "provider_profile_id": active_profile.profile_id,
            },
            tools=request_tools,
        )

        credentials = self.credential_resolver.resolve(active_profile).as_mapping()
        adapter = build_model_adapter(
            active_profile,
            runtime_resolver=self.runtime_resolver,
            credentials=credentials,
            adapter_id=f"adapter.models.{active_profile.provider_id}.surface",
            stream_observer=self._stream_observer,
        )
        if adapter is None:
            return self.fallback.generate(
                profile=profile,
                session=session,
                context=context,
                prompt=prompt,
            )
        result = adapter.generate(request, credentials)
        return ExecutionResult(
            execution_id=result.result_id,
            session_id=session.session_id,
            outcome="ok" if result.failure_kind is None else "failed",
            summary=result.content,
            prompt_tokens=result.usage.prompt_tokens,
            completion_tokens=result.usage.completion_tokens,
            total_tokens=result.usage.total_tokens,
            telemetry_event_ids=(request.request_id,),
            side_effects=(
                f"provider={result.provider_id}",
                f"model={result.model_id}",
                f"transport={result.metadata.get('transport_id', 'unknown')}",
                f"credential_keys={result.metadata.get('credential_keys', 'unknown')}",
            ),
            tool_calls=result.tool_calls,
        )

def register_provider_profile(
    repository: RuntimeStorageRepository,
    payload: Mapping[str, Any],
) -> AuthProfile:
    profile = provider_profile_from_payload(payload)
    PersistentAuthProfileStore(repository).register(profile)
    return profile


def _heuristic_context_window(model_id: str) -> int | None:
    normalized = model_id.casefold()
    heuristics = (
        ("gpt-4.1", 1_047_576),
        ("gpt-4o", 128_000),
        ("gpt-5", 128_000),
        ("claude", 200_000),
        ("gemini", 1_048_576),
        ("minimax-m2.5", 1_048_576),
        ("minimax-m2.7", 1_048_576),
        ("llama", 131_072),
        ("qwen", 131_072),
        ("deepseek", 128_000),
        ("kimi", 262_144),
    )
    for prefix, size in heuristics:
        if prefix in normalized:
            return size
    return DEFAULT_CONTEXT_WINDOW_TOKENS
