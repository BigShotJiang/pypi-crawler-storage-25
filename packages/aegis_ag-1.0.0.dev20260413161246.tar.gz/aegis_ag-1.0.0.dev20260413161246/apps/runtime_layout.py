from __future__ import annotations

from collections.abc import Mapping
import os
from pathlib import Path


EnvMapping = Mapping[str, str]


def _environ(environ: EnvMapping | None = None) -> EnvMapping:
    return environ if environ is not None else os.environ


def default_install_root(*, environ: EnvMapping | None = None) -> Path:
    env = _environ(environ)
    override = env.get("AEGIS_HOME")
    if override:
        return Path(override).expanduser()
    xdg_data_home = env.get("XDG_DATA_HOME")
    if xdg_data_home:
        return Path(xdg_data_home).expanduser() / "aegis"
    return Path.home() / ".local" / "share" / "aegis"


def default_cli_state_dir(*, environ: EnvMapping | None = None) -> Path:
    env = _environ(environ)
    override = env.get("AEGIS_STATE_DIR")
    if override:
        return Path(override).expanduser()
    return default_install_root(environ=env) / "state"


def default_profile_dir(*, environ: EnvMapping | None = None) -> Path:
    env = _environ(environ)
    override = env.get("AEGIS_PROFILE_DIR")
    if override:
        return Path(override).expanduser()
    return default_install_root(environ=env) / "profile"


def default_gateway_state_dir(*, environ: EnvMapping | None = None) -> Path:
    env = _environ(environ)
    override = env.get("AEGIS_GATEWAY_STATE_DIR")
    if override:
        return Path(override).expanduser()
    return default_install_root(environ=env) / "state" / "gateway"


__all__ = [
    "default_cli_state_dir",
    "default_gateway_state_dir",
    "default_install_root",
    "default_profile_dir",
]
