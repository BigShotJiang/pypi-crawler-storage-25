from __future__ import annotations

from dataclasses import dataclass
import os
import re
import threading
import time
from typing import TYPE_CHECKING

from packages.kernel.runtime import KernelOutcome
from packages.tools import ToolLifecycleEvent, normalize_companion_request

from .shell_stack import (
    Application,
    Condition,
    ConditionalContainer,
    Dimension,
    FormattedText,
    FormattedTextControl,
    Group,
    Layout,
    Live,
    Panel,
    RICH_AVAILABLE,
    Text,
    Window,
)
from .shell_ui import (
    BRAND_ACCENT,
    BRAND_ACCENT_STRONG,
    BRAND_DARK,
    BRAND_LIGHT,
    BRAND_MUTED,
    QUEUE_PREVIEW_INSET,
    compact_line,
    strip_markdown_bold,
)

if TYPE_CHECKING:
    from .shell import ProductizedShell


_STREAM_TOOL_BLOCK_PATTERNS = (
    re.compile(
        r"<(?:[\w.-]+:)?tool_call\b[^>]*>.*?</(?:[\w.-]+:)?tool_call\s*>",
        re.IGNORECASE | re.DOTALL,
    ),
    re.compile(
        r"<(?:[\w.-]+:)?invoke\b[^>]*>.*?</(?:[\w.-]+:)?invoke\s*>",
        re.IGNORECASE | re.DOTALL,
    ),
    re.compile(
        r"<(?:[\w.-]+:)?parameter\b[^>]*>.*?</(?:[\w.-]+:)?parameter\s*>",
        re.IGNORECASE | re.DOTALL,
    ),
)
_STREAM_TOOL_TAG_PATTERN = re.compile(
    r"</?(?:[\w.-]+:)?(?:tool_call|invoke|parameter)\b[^>]*>",
    re.IGNORECASE,
)
_STREAM_OPEN_TOOL_TAG_PATTERN = re.compile(
    r"<(?:[\w.-]+:)?(?:tool_call|invoke|parameter)\b[^>]*>",
    re.IGNORECASE,
)


@dataclass(frozen=True, slots=True)
class _ToolTraceDisplayParts:
    rail: str
    emoji: str
    prefix: str
    label: str
    gap: str
    body: str
    duration_gap: str
    duration: str


@dataclass(frozen=True, slots=True)
class _VisibleToolEvent:
    event: ToolLifecycleEvent
    expires_at: float


def animations_enabled() -> bool:
    return RICH_AVAILABLE and Live is not None and os.environ.get("AEGIS_NO_ANIMATION") != "1"


def turn_phase(tick: int) -> tuple[str, str, str]:
    phases = (
        ("recover.clone", "Recovering the active clone and its durable context"),
        ("aligning.identity", "Keeping Aegis identity locked"),
        ("drafting.reply", "Shaping the next reply"),
    )
    phase_label, phase_detail = phases[(tick // 3) % len(phases)]
    marker = ("·", "•", "●", "•")[tick % 4]
    return marker, phase_label, phase_detail


def summarize_progress_prompt(prompt: str) -> str:
    normalized = " ".join(prompt.split())
    if len(normalized) <= 72:
        return normalized
    return f"{normalized[:69]}..."


def pending_tooltrace_lines(shell: ProductizedShell) -> tuple[str, ...]:
    pending = shell.transcript[shell._rendered_entries :]
    lines: list[str] = []
    for entry in pending:
        if entry.kind != "tooltrace":
            continue
        body_lines = entry.body.splitlines() or [entry.body]
        for body_line in body_lines:
            normalized = strip_markdown_bold(body_line).rstrip("\n")
            if normalized:
                lines.append(normalized)
    return tuple(lines)


def turn_tool_progress_lines(
    shell: ProductizedShell,
    *,
    tool_event: ToolLifecycleEvent | None = None,
    tool_events: tuple[ToolLifecycleEvent, ...] = (),
) -> tuple[str, ...]:
    lines: list[str] = []
    seen: set[str] = set()
    for line in pending_tooltrace_lines(shell):
        if line in seen:
            continue
        seen.add(line)
        lines.append(line)
    for line in tool_event_progress_lines(shell, tool_event=tool_event, tool_events=tool_events):
        if line in seen:
            continue
        seen.add(line)
        lines.append(line)
    return tuple(lines[-12:])


def render_turn_progress_fragments(
    shell: ProductizedShell,
    *,
    prompt: str,
    tick: int,
    tool_event: ToolLifecycleEvent | None = None,
    tool_events: tuple[ToolLifecycleEvent, ...] = (),
    queued_count: int = 0,
    stream_text: str = "",
) -> FormattedText:
    marker, phase_label, phase_detail = turn_phase(tick)
    fragments: list[tuple[str, str]] = [
        ("class:progress-title", "Aegis is growing\n"),
        ("class:progress-active", f"{marker} {phase_detail}\n"),
        ("class:progress-meta", f"{phase_label} · active request: {summarize_progress_prompt(prompt)}"),
    ]
    if queued_count:
        label = "message" if queued_count == 1 else "messages"
        fragments.append(("class:progress-queue", f"\nqueued follow-ups · {queued_count} {label}"))
    tool_lines = turn_tool_progress_lines(shell, tool_event=tool_event, tool_events=tool_events)
    for tool_line in tool_lines:
        fragments.extend(render_tool_trace_fragments(tool_line, leading_newline=True))
    fragments.append(("class:progress-hint", "\nPress Enter to queue another message."))
    return FormattedText(fragments)


def render_stream_response_fragments(
    shell: ProductizedShell,
    *,
    stream_text: str,
) -> FormattedText:
    response_text = _stream_response_text(stream_text)
    if not response_text:
        return FormattedText([])
    return FormattedText(
        [
            ("class:stream-response-title", "Aegis response · streaming\n"),
            ("class:stream-response-body", response_text),
        ]
    )


def render_queued_followup_fragments(shell: ProductizedShell) -> FormattedText:
    fragments: list[tuple[str, str]] = []
    for command in shell._pending_commands:
        lines = strip_markdown_bold(command.command).splitlines() or [""]
        for index, line in enumerate(lines):
            prefix = "› " if index == 0 else "  "
            fragments.append(("", " " * QUEUE_PREVIEW_INSET))
            fragments.append(("class:queue-user", shell._pad_queue_preview_line(f"{prefix}{line}")))
            fragments.append(("", "\n"))
    if fragments:
        fragments.pop()
    return FormattedText(fragments)


def queued_turn_input_supported(shell: ProductizedShell) -> bool:
    return shell._prompt_toolkit_composer_available()


def resolve_turn_outcome(holder: dict[str, object]) -> KernelOutcome:
    error = holder.get("error")
    if isinstance(error, Exception):
        raise error
    outcome = holder.get("outcome")
    if not isinstance(outcome, KernelOutcome):
        raise RuntimeError("turn completed without a kernel outcome")
    return outcome


def run_turn_with_queued_input(shell: ProductizedShell, prompt: str) -> KernelOutcome:
    holder: dict[str, object] = {}
    stream_holder, stream_lock, stream_observer = stream_text_tracker()
    started_at = time.monotonic()
    shell._turn_started_at = started_at
    application_holder: dict[str, Application] = {}

    def invalidate_application() -> None:
        application = application_holder.get("app")
        if application is None:
            return
        try:
            application.invalidate()
        except Exception:
            return

    def raw_stream_observer(delta: str) -> None:
        stream_observer(delta)
        invalidate_application()

    def reset_stream_for_tool_event(event: ToolLifecycleEvent) -> None:
        if event.phase != "requested":
            return
        reset_stream_text(stream_holder, stream_lock)
        invalidate_application()

    tool_event_holder, tool_event_lock, tool_observer = tool_event_tracker(
        shell._record_tool_event_trace,
        reset_stream_for_tool_event,
        lambda _event: invalidate_application(),
    )
    unsubscribe = shell.runtime.tool_runtime.subscribe(tool_observer)
    shell.runtime.set_model_stream_observer(raw_stream_observer)

    def worker() -> None:
        try:
            holder["outcome"] = shell.runtime.explain_next_step(session_id=shell.session_id, prompt=prompt)
        except Exception as error:  # pragma: no cover - surfaced below
            holder["error"] = error

    thread = threading.Thread(target=worker, daemon=True)
    thread.start()
    buffer = shell._build_prompt_buffer()
    input_window = shell._build_input_window(buffer)
    command_palette = shell._build_command_palette()

    def submit(event) -> None:
        raw_command = event.current_buffer.text
        if not raw_command.strip():
            return
        event.current_buffer.append_to_history()
        event.current_buffer.text = ""
        shell._enqueue_followup_command(raw_command)
        event.app.invalidate()

    progress_window = Window(
        FormattedTextControl(
            lambda: render_turn_progress_fragments(
                shell,
                prompt=prompt,
                tick=int(max(0.0, time.monotonic() - started_at) / 0.08),
                tool_event=latest_tool_event(tool_event_holder, tool_event_lock),
                tool_events=visible_tool_events(tool_event_holder, tool_event_lock),
                queued_count=len(shell._pending_commands),
                stream_text=latest_stream_text(stream_holder, stream_lock),
            )
        ),
        wrap_lines=True,
        dont_extend_height=True,
    )
    stream_response_window = ConditionalContainer(
        content=Window(
            FormattedTextControl(
                lambda: render_stream_response_fragments(
                    shell,
                    stream_text=latest_stream_text(stream_holder, stream_lock),
                )
            ),
            wrap_lines=True,
            dont_extend_height=True,
            height=Dimension(min=3, preferred=6, max=12),
        ),
        filter=Condition(lambda: bool(latest_stream_text(stream_holder, stream_lock).strip())),
    )
    composer_body = shell._build_composer_body(
        input_window=input_window,
        command_palette=command_palette,
        top_windows=(progress_window, stream_response_window, shell._build_queue_preview_window()),
    )
    application = Application(
        layout=Layout(composer_body, focused_element=input_window),
        key_bindings=shell._build_key_bindings(submit=submit, allow_exit=False),
        style=shell._prompt_style(),
        full_screen=False,
        erase_when_done=True,
        refresh_interval=0.05,
    )
    application_holder["app"] = application

    def exit_when_complete() -> None:
        thread.join()
        if visible_tool_events(tool_event_holder, tool_event_lock):
            invalidate_application()
            time.sleep(0.18)
        reset_stream_text(stream_holder, stream_lock)
        invalidate_application()
        time.sleep(0.05)
        try:
            application.exit(result=True)
        except Exception:  # pragma: no cover - defensive cross-thread exit
            return

    threading.Thread(target=exit_when_complete, daemon=True).start()
    try:
        application.run()
    finally:
        shell._last_turn_elapsed_seconds = max(0, round(time.monotonic() - started_at))
        shell._turn_started_at = None
        shell.runtime.set_model_stream_observer(None)
        unsubscribe()
    return resolve_turn_outcome(holder)


def run_turn_with_progress(shell: ProductizedShell, prompt: str) -> KernelOutcome:
    if not animations_enabled():
        _tool_event_holder, _tool_event_lock, tool_observer = tool_event_tracker(shell._record_tool_event_trace)
        unsubscribe = shell.runtime.tool_runtime.subscribe(tool_observer)
        shell.runtime.set_model_stream_observer(lambda _delta: None)
        started_at = time.monotonic()
        shell._turn_started_at = started_at
        try:
            return shell.runtime.explain_next_step(session_id=shell.session_id, prompt=prompt)
        finally:
            shell._last_turn_elapsed_seconds = max(0, round(time.monotonic() - started_at))
            shell._turn_started_at = None
            shell.runtime.set_model_stream_observer(None)
            unsubscribe()
    if queued_turn_input_supported(shell):
        return run_turn_with_queued_input(shell, prompt)

    holder: dict[str, object] = {}
    stream_holder, stream_lock, stream_observer = stream_text_tracker()
    tool_event_holder, tool_event_lock, tool_observer = tool_event_tracker(
        shell._record_tool_event_trace,
        lambda event: reset_stream_text(stream_holder, stream_lock) if event.phase == "requested" else None,
    )
    unsubscribe = shell.runtime.tool_runtime.subscribe(tool_observer)
    shell.runtime.set_model_stream_observer(stream_observer)
    started_at = time.monotonic()
    shell._turn_started_at = started_at

    def worker() -> None:
        try:
            holder["outcome"] = shell.runtime.explain_next_step(session_id=shell.session_id, prompt=prompt)
        except Exception as error:  # pragma: no cover - surfaced below
            holder["error"] = error

    thread = threading.Thread(target=worker, daemon=True)
    thread.start()
    tick = 0
    try:
        with Live(
            render_turn_frame(
                shell,
                prompt=prompt,
                tick=tick,
                tool_events=visible_tool_events(tool_event_holder, tool_event_lock),
                stream_text=latest_stream_text(stream_holder, stream_lock),
            ),
            console=shell.console,
            refresh_per_second=18,
            transient=True,
        ) as live:
            while thread.is_alive():
                live.update(
                    render_turn_frame(
                        shell,
                        prompt=prompt,
                        tick=tick,
                        tool_event=latest_tool_event(tool_event_holder, tool_event_lock),
                        tool_events=visible_tool_events(tool_event_holder, tool_event_lock),
                        stream_text=latest_stream_text(stream_holder, stream_lock),
                    ),
                    refresh=True,
                )
                time.sleep(0.08)
                tick += 1
            thread.join(timeout=0.1)
            final_tool_events = visible_tool_events(tool_event_holder, tool_event_lock)
            live.update(
                render_turn_frame(
                    shell,
                    prompt=prompt,
                    tick=tick,
                    tool_event=latest_tool_event(tool_event_holder, tool_event_lock),
                    tool_events=final_tool_events,
                    stream_text="",
                ),
                refresh=True,
            )
            if final_tool_events:
                time.sleep(0.18)
    finally:
        shell._last_turn_elapsed_seconds = max(0, round(time.monotonic() - started_at))
        shell._turn_started_at = None
        shell.runtime.set_model_stream_observer(None)
        unsubscribe()
    return resolve_turn_outcome(holder)


def run_tool_with_progress(shell: ProductizedShell, tool_id: str, arguments: dict[str, str]):
    shell.runtime.prepare_session_surface(shell.session_id)
    tool_runtime = shell.runtime.tool_runtime
    if not animations_enabled():
        _tool_event_holder, _tool_event_lock, tool_observer = tool_event_tracker(shell._record_tool_event_trace)
        unsubscribe = tool_runtime.subscribe(tool_observer)
        try:
            return tool_runtime.invoke(tool_id, arguments, session_id=shell.session_id)
        finally:
            unsubscribe()

    holder: dict[str, object] = {}
    tool_event_holder, tool_event_lock, tool_observer = tool_event_tracker(shell._record_tool_event_trace)
    unsubscribe = tool_runtime.subscribe(tool_observer)

    def worker() -> None:
        try:
            holder["result"] = tool_runtime.invoke(tool_id, arguments, session_id=shell.session_id)
        except Exception as error:  # pragma: no cover - surfaced below
            holder["error"] = error

    thread = threading.Thread(target=worker, daemon=True)
    thread.start()
    tick = 0
    try:
        with Live(
            render_tool_frame(
                shell,
                tool_id=tool_id,
                tick=tick,
                tool_events=visible_tool_events(tool_event_holder, tool_event_lock),
            ),
            console=shell.console,
            refresh_per_second=18,
            transient=True,
        ) as live:
            while thread.is_alive():
                live.update(
                    render_tool_frame(
                        shell,
                        tool_id=tool_id,
                        tick=tick,
                        tool_event=latest_tool_event(tool_event_holder, tool_event_lock),
                        tool_events=visible_tool_events(tool_event_holder, tool_event_lock),
                    ),
                    refresh=True,
                )
                time.sleep(0.08)
                tick += 1
            thread.join(timeout=0.1)
            final_tool_events = visible_tool_events(tool_event_holder, tool_event_lock)
            live.update(
                render_tool_frame(
                    shell,
                    tool_id=tool_id,
                    tick=tick,
                    tool_event=latest_tool_event(tool_event_holder, tool_event_lock),
                    tool_events=final_tool_events,
                ),
                refresh=True,
            )
            if final_tool_events:
                time.sleep(0.14)
    finally:
        unsubscribe()
    error = holder.get("error")
    if isinstance(error, Exception):
        raise error
    result = holder.get("result")
    if result is None:
        raise RuntimeError("tool call completed without a result")
    return result


def tool_event_tracker(*extra_observers):
    holder: dict[str, object] = {"latest": None, "feed": []}
    lock = threading.Lock()

    def observer(event: ToolLifecycleEvent) -> None:
        now = time.monotonic()
        with lock:
            holder["latest"] = event
            feed = [
                item
                for item in holder.get("feed", [])
                if isinstance(item, _VisibleToolEvent) and item.expires_at > now
            ]
            feed.append(
                _VisibleToolEvent(
                    event=event,
                    expires_at=now + _tool_event_hold_seconds(event.phase),
                )
            )
            holder["feed"] = feed[-6:]
        for extra_observer in extra_observers:
            try:
                extra_observer(event)
            except Exception:
                continue

    return holder, lock, observer


def latest_tool_event(holder, lock) -> ToolLifecycleEvent | None:
    with lock:
        return holder.get("latest")


def visible_tool_events(holder, lock) -> tuple[ToolLifecycleEvent, ...]:
    now = time.monotonic()
    with lock:
        feed = [
            item
            for item in holder.get("feed", [])
            if isinstance(item, _VisibleToolEvent) and item.expires_at > now
        ]
        holder["feed"] = feed
        latest = holder.get("latest")
    events = tuple(item.event for item in feed)
    if events:
        return events
    if isinstance(latest, ToolLifecycleEvent):
        return (latest,)
    return ()


def _tool_event_hold_seconds(phase: str) -> float:
    if phase in {"requested", "execution.started"}:
        return 0.45
    if phase in {"execution.completed", "execution.failed", "approval.denied", "approval.deferred"}:
        return 1.1
    return 0.35


def stream_text_tracker():
    holder: dict[str, str] = {"raw": "", "text": ""}
    lock = threading.Lock()

    def observer(delta: str) -> None:
        if not delta:
            return
        with lock:
            raw = f"{holder['raw']}{delta}"[-16000:]
            holder["raw"] = raw
            holder["text"] = _sanitize_stream_tool_markup(raw)[-4000:]

    return holder, lock, observer


def latest_stream_text(holder, lock) -> str:
    with lock:
        return holder.get("text", "")


def reset_stream_text(holder, lock) -> None:
    with lock:
        holder["raw"] = ""
        holder["text"] = ""


def render_turn_frame(
    shell: ProductizedShell,
    *,
    prompt: str,
    tick: int,
    tool_event: ToolLifecycleEvent | None = None,
    tool_events: tuple[ToolLifecycleEvent, ...] = (),
    stream_text: str = "",
):
    marker, phase_label, phase_detail = turn_phase(tick)
    if not RICH_AVAILABLE:
        tool_summary = tool_event_summary(shell, tool_event)
        stream_preview = _stream_response_text(stream_text, limit=280)
        body = f"{marker} {phase_detail}"
        if tool_summary is not None:
            body = f"{body} | {tool_summary}"
        if stream_preview:
            body = f"{body}\n\nAegis response\n{stream_preview}"
        return body
    progress_body = Text()
    progress_body.append(f"{marker} {phase_detail}\n", style=f"bold {BRAND_ACCENT_STRONG}")
    progress_body.append(f"{phase_label}", style=BRAND_MUTED)
    tool_lines = turn_tool_progress_lines(shell, tool_event=tool_event, tool_events=tool_events)
    for tool_line in tool_lines:
        progress_body.append("\n")
        progress_body.append_text(render_tool_trace_text(tool_line))
    progress_panel = Panel(
        progress_body,
        title=f"[bold {BRAND_ACCENT}]Aegis is growing[/bold {BRAND_ACCENT}]",
        border_style=BRAND_DARK,
        padding=(0, 1),
    )
    stream_response = _stream_response_text(stream_text)
    if not stream_response:
        return progress_panel
    response_body = Text()
    response_body.append(stream_response, style=BRAND_LIGHT)
    response_panel = Panel(
        response_body,
        title=f"[bold {BRAND_ACCENT}]Aegis response[/bold {BRAND_ACCENT}]",
        border_style=BRAND_ACCENT,
        padding=(0, 1),
    )
    if Group is None:
        return progress_panel
    return Group(progress_panel, response_panel)


def render_tool_frame(
    shell: ProductizedShell,
    *,
    tool_id: str,
    tick: int,
    tool_event: ToolLifecycleEvent | None = None,
    tool_events: tuple[ToolLifecycleEvent, ...] = (),
):
    phases = tool_frame_phases(shell, tool_id, tool_event=tool_event)
    phase_label, phase_detail = phases[(tick // 3) % len(phases)]
    marker = ("·", "•", "●", "•")[tick % 4]
    if not RICH_AVAILABLE:
        tool_summary = tool_event_summary(shell, tool_event)
        return f"{marker} {phase_detail}" if tool_summary is None else f"{marker} {tool_summary}"
    body = Text()
    body.append(f"{marker} {phase_detail}\n", style=f"bold {BRAND_ACCENT_STRONG}")
    body.append(f"{phase_label} · {tool_id}", style=BRAND_MUTED)
    tool_lines = tool_event_progress_lines(shell, tool_event=tool_event, tool_events=tool_events)
    for tool_line in tool_lines:
        body.append("\n")
        body.append_text(render_tool_trace_text(tool_line))
    return Panel(
        body,
        title=f"[bold {BRAND_ACCENT}]Aegis is using a tool[/bold {BRAND_ACCENT}]",
        border_style=BRAND_DARK,
        padding=(0, 1),
    )


def tool_frame_phases(
    shell: ProductizedShell,
    tool_id: str,
    *,
    tool_event: ToolLifecycleEvent | None = None,
) -> tuple[tuple[str, str], ...]:
    if tool_id == "tool.companion.manage":
        arguments = tool_event.invocation.arguments if tool_event is not None else {}
        target_label = companion_target_label(arguments)
        action = companion_target_action(arguments)
        if action == "inspect":
            inspect_detail = (
                "Inspecting the active companion profile"
                if target_label == "companion profile"
                else f"Inspecting {target_label} for the active clone"
            )
            sync_detail = (
                "Folding the current companion state back into the live shell"
                if target_label == "companion profile"
                else f"Folding the current {target_label} back into the live shell"
            )
            return (
                ("companion.resolve", "Resolving the active companion profile and its durable files"),
                ("companion.inspect", inspect_detail),
                ("companion.sync", sync_detail),
            )
        write_detail = (
            f"Clearing {target_label} for this clone"
            if action == "clear"
            else f"Writing {target_label} so this clone keeps the update durably"
        )
        return (
            ("companion.resolve", "Resolving the active companion profile and its durable files"),
            ("companion.write", write_detail),
            ("companion.sync", f"Syncing the updated {target_label} back into the live shell"),
        )
    return (
        ("tool.bind", "Binding the requested built-in capability"),
        ("tool.execute", "Running the tool inside the current clone surface"),
        ("tool.report", "Folding the tool result back into the transcript"),
    )


def tool_trace_line(
    shell: ProductizedShell,
    tool_event: ToolLifecycleEvent | None,
) -> str | None:
    if tool_event is None:
        return None
    tool_id = tool_event.invocation.tool_id
    emoji = _tool_trace_emoji(tool_id)
    label = _tool_trace_label(tool_event)
    if tool_event.phase == "requested":
        return f"┊ {emoji} preparing {_tool_trace_prepare_label(tool_event)}…"
    if tool_event.phase == "approval.denied":
        return f"┊ {emoji} {label:<12} blocked"
    if tool_event.phase == "approval.deferred":
        return f"┊ {emoji} {label:<12} awaiting approval"
    if tool_event.phase not in {"execution.completed", "execution.failed"}:
        return None
    preview = _tool_trace_preview(tool_event.invocation.arguments, tool_id=tool_id)
    duration = _tool_trace_duration(tool_event)
    duration_part = f"  {duration}" if duration else ""
    if tool_event.phase == "execution.failed":
        if preview and tool_id in {"tool.terminal.exec", "tool.process.manage"}:
            return f"┊ {emoji} {label:<12} {preview} [error]{duration_part}"
        failure_label = compact_line(tool_event.detail or "failed", limit=28)
        return f"┊ {emoji} {label:<12} {failure_label}{duration_part}"
    if preview:
        return f"┊ {emoji} {label:<12} {preview}{duration_part}"
    return f"┊ {emoji} {label}{duration_part}"


def tool_event_progress_line(
    shell: ProductizedShell,
    tool_event: ToolLifecycleEvent | None,
) -> str | None:
    if tool_event is None:
        return None
    if tool_event.phase == "execution.started":
        emoji = _tool_trace_emoji(tool_event.invocation.tool_id)
        label = _tool_trace_started_label(tool_event)
        preview = _tool_trace_preview(tool_event.invocation.arguments, tool_id=tool_event.invocation.tool_id)
        if preview:
            return f"┊ {emoji} {label:<12} {preview}"
        return f"┊ {emoji} {label}"
    return tool_trace_line(shell, tool_event)


def tool_event_progress_lines(
    shell: ProductizedShell,
    *,
    tool_event: ToolLifecycleEvent | None = None,
    tool_events: tuple[ToolLifecycleEvent, ...] = (),
) -> tuple[str, ...]:
    lines: list[str] = []
    seen: set[tuple[str, str, str]] = set()
    events = tool_events or ((tool_event,) if tool_event is not None else ())
    for event in events[-3:]:
        line = tool_event_progress_line(shell, event)
        if line is None:
            continue
        key = (event.invocation.invocation_id, event.phase, line)
        if key in seen:
            continue
        seen.add(key)
        lines.append(line)
    return tuple(lines)


def tool_event_lines(
    shell: ProductizedShell,
    tool_event: ToolLifecycleEvent | None,
) -> tuple[str | None, str | None]:
    if tool_event is None:
        return (None, None)
    if tool_event.invocation.tool_id == "tool.companion.manage":
        return companion_tool_event_lines(shell, tool_event)
    phase_labels = {
        "requested": "Tool requested",
        "classified": "Tool classified",
        "approval.granted": "Approval granted",
        "approval.denied": "Approval denied",
        "approval.deferred": "Approval deferred",
        "execution.started": "Tool executing",
        "execution.completed": "Tool completed",
        "execution.failed": "Tool failed",
    }
    title = f"{phase_labels.get(tool_event.phase, tool_event.phase)} · {tool_event.invocation.tool_id}"
    detail = compact_line(" ".join((tool_event.detail or "").split()), limit=112) if tool_event.detail else ""
    details = [detail] if detail else []
    if tool_event.approval is not None and tool_event.approval.required_controls:
        details.append(f"controls: {', '.join(tool_event.approval.required_controls)}")
    if tool_event.execution is not None:
        details.append(f"outcome: {tool_event.execution.outcome}")
    return (title, " · ".join(part for part in details if part))


def companion_tool_event_lines(
    shell: ProductizedShell,
    tool_event: ToolLifecycleEvent,
) -> tuple[str | None, str | None]:
    target_label = companion_target_label(tool_event.invocation.arguments)
    action = companion_target_action(tool_event.invocation.arguments)
    target_title = "Companion profile" if target_label == "companion profile" else target_label
    if action == "inspect":
        phase_labels = {
            "requested": "Companion lookup queued",
            "classified": "Companion lookup classified",
            "approval.granted": "Companion read approved",
            "approval.denied": "Companion read denied",
            "approval.deferred": "Companion read deferred",
            "execution.started": f"Inspecting {target_title}",
            "execution.completed": f"{target_title} loaded",
            "execution.failed": f"{target_title} inspect failed",
        }
    else:
        phase_labels = {
            "requested": "Companion update queued",
            "classified": "Companion update classified",
            "approval.granted": "Companion write approved",
            "approval.denied": "Companion write denied",
            "approval.deferred": "Companion write deferred",
            "execution.started": f"Writing {target_title}" if action != "clear" else f"Clearing {target_title}",
            "execution.completed": f"{target_title} synced",
            "execution.failed": f"{target_title} update failed",
        }
    title = phase_labels.get(tool_event.phase, tool_event.phase)
    if tool_event.phase == "execution.completed":
        details = (
            ["current companion state is now visible in this shell"]
            if action == "inspect"
            else [f"{target_label} is now durable for this clone"]
        )
    elif tool_event.phase == "execution.started":
        details = (
            ["reading the current companion state for this clone"]
            if action == "inspect"
            else [f"keeping {target_label} aligned with this live companion"]
        )
    elif tool_event.phase == "execution.failed":
        details = [tool_event.detail]
    elif tool_event.phase in {"approval.granted", "approval.denied", "approval.deferred"} and tool_event.approval is not None:
        details = [
            tool_event.approval.reason
            or (
                f"{target_label} read {tool_event.approval.decision}"
                if action == "inspect"
                else f"{target_label} write {tool_event.approval.decision}"
            )
        ]
    else:
        details = [tool_event.detail]
    if tool_event.approval is not None and tool_event.approval.required_controls:
        details.append(f"controls: {', '.join(tool_event.approval.required_controls)}")
    if tool_event.execution is not None:
        details.append(f"outcome: {tool_event.execution.outcome}")
    return (title, " · ".join(part for part in details if part))


def companion_target_label(arguments) -> str:
    _, target = normalize_companion_request(
        action=arguments.get("action"),
        target=arguments.get("target"),
    )
    if target == "friend":
        return "FRIEND.md"
    if target == "clone":
        return "CLONE.md"
    if target == "identity":
        return "companion posture"
    return "companion profile"


def companion_target_action(arguments) -> str:
    action, _ = normalize_companion_request(
        action=arguments.get("action"),
        target=arguments.get("target"),
    )
    return action


def tool_event_summary(shell: ProductizedShell, tool_event: ToolLifecycleEvent | None) -> str | None:
    if tool_event is None:
        return None
    line = tool_event_progress_line(shell, tool_event)
    if line:
        return compact_line(strip_markdown_bold(line.replace("┊ ", "")), limit=112)
    title, _ = tool_event_lines(shell, tool_event)
    return title


def render_tool_trace_fragments(line: str, *, leading_newline: bool = False) -> list[tuple[str, str]]:
    parts = _tool_trace_display_parts(line)
    state = _tool_trace_state(line)
    emoji_style = "class:progress-tool-emoji" if state == "done" else "class:progress-tool-verb"
    label_style = "class:progress-tool-label" if state in {"done", "error"} else "class:progress-tool-verb"
    body_style = "class:progress-tool-body" if state in {"done", "error"} else "class:progress-tool-verb"
    fragments: list[tuple[str, str]] = []
    if leading_newline:
        fragments.append(("", "\n"))
    if parts.rail:
        fragments.append(("class:progress-tool-rail", parts.rail))
    if parts.emoji:
        fragments.append((emoji_style, f"{parts.emoji} "))
    if parts.prefix:
        fragments.append(("class:progress-tool-verb", parts.prefix))
    fragments.append((label_style, parts.label))
    if parts.body:
        fragments.append(("class:progress-tool-gap", parts.gap or " "))
        fragments.append((body_style, parts.body))
    if parts.duration:
        fragments.append(("class:progress-tool-gap", parts.duration_gap or "  "))
        fragments.append(("class:progress-tool-duration", parts.duration))
    return fragments


def render_tool_trace_text(line: str) -> Text:
    parts = _tool_trace_display_parts(line)
    state = _tool_trace_state(line)
    emoji_style = BRAND_ACCENT if state == "done" else BRAND_MUTED
    label_style = f"bold {BRAND_ACCENT_STRONG}" if state in {"done", "error"} else BRAND_MUTED
    body_style = BRAND_LIGHT if state in {"done", "error"} else BRAND_MUTED
    block = Text()
    if parts.rail:
        block.append(parts.rail, style=BRAND_DARK)
    if parts.emoji:
        block.append(f"{parts.emoji} ", style=emoji_style)
    if parts.prefix:
        block.append(parts.prefix, style=BRAND_MUTED)
    block.append(parts.label, style=label_style)
    if parts.body:
        block.append(parts.gap or " ")
        block.append(parts.body, style=body_style)
    if parts.duration:
        block.append(parts.duration_gap or "  ")
        block.append(parts.duration, style=BRAND_MUTED)
    return block


def _tool_trace_display_parts(line: str) -> _ToolTraceDisplayParts:
    body = strip_markdown_bold(line).rstrip("\n")
    rail = ""
    if body.startswith("┊ "):
        rail = "┊ "
        body = body[2:]
    emoji, separator, remainder = body.partition(" ")
    if not separator:
        return _ToolTraceDisplayParts(rail="", emoji="", prefix="", label=body, gap="", body="", duration_gap="", duration="")

    duration_gap = ""
    duration = ""
    duration_match = re.search(r"(?P<spacing>\s{2,})(?P<duration>\d+(?:\.\d)?s)$", remainder)
    if duration_match is not None:
        duration_gap = duration_match.group("spacing")
        duration = duration_match.group("duration")
        remainder = remainder[: duration_match.start()].rstrip()

    prefix = ""
    label = remainder
    gap = ""
    tail = ""
    if remainder.startswith("preparing "):
        prefix = "preparing "
        label = remainder.removeprefix("preparing ")
    else:
        detail_match = re.match(r"(?P<label>.+?)(?P<gap>\s{2,})(?P<body>.+)$", remainder)
        if detail_match is not None:
            label = detail_match.group("label")
            gap = detail_match.group("gap")
            tail = detail_match.group("body")

    return _ToolTraceDisplayParts(
        rail=rail,
        emoji=emoji,
        prefix=prefix,
        label=label,
        gap=gap,
        body=tail,
        duration_gap=duration_gap,
        duration=duration,
    )


def _tool_trace_state(line: str) -> str:
    normalized = strip_markdown_bold(line).rstrip("\n")
    parts = _tool_trace_display_parts(normalized)
    if "[error]" in normalized:
        return "error"
    if parts.prefix == "preparing ":
        return "active"
    if "awaiting approval" in normalized or normalized.endswith(" blocked"):
        return "active"
    if parts.body and not parts.duration:
        return "active"
    return "done"


def _tool_trace_emoji(tool_id: str) -> str:
    if tool_id in {"tool.web.search", "tool.file.search"}:
        return "🔎"
    if tool_id.startswith("tool.browser."):
        return "🌐"
    if tool_id in {"tool.web.read", "tool.file.read"}:
        return "📖"
    if tool_id in {"tool.file.write", "tool.file.patch", "tool.code.execute"}:
        return "🛠"
    if tool_id == "tool.terminal.exec":
        return "💻"
    if tool_id == "tool.process.manage":
        return "⚙"
    if tool_id in {"tool.skill.list", "tool.skill.search", "tool.skill.view", "tool.skill.manage"}:
        return "📚"
    if tool_id == "tool.cron.manage":
        return "⏰"
    if tool_id == "tool.goal.manage":
        return "🎯"
    if tool_id == "tool.memory.manage":
        return "🧠"
    if tool_id == "tool.message.send":
        return "📨"
    if tool_id == "tool.todo.manage":
        return "📋"
    if tool_id == "tool.companion.manage":
        return "🪪"
    return "⚙"


def _tool_trace_label(tool_event: ToolLifecycleEvent) -> str:
    tool_id = tool_event.invocation.tool_id
    if tool_id == "tool.skill.view":
        return "skill"
    if tool_id == "tool.skill.search":
        return "skills"
    if tool_id == "tool.skill.list":
        return "skills"
    if tool_id == "tool.skill.manage":
        action = str(tool_event.invocation.arguments.get("action") or "").strip().lower()
        if action == "install":
            return "skill"
    aliases = {
        "tool.file.search": "grep",
        "tool.file.read": "read",
        "tool.file.write": "write",
        "tool.file.patch": "patch",
        "tool.web.search": "search",
        "tool.web.read": "fetch",
        "tool.terminal.exec": "$",
        "tool.process.manage": "proc",
        "tool.skill.manage": "skills",
        "tool.cron.manage": "cron",
        "tool.goal.manage": "goals",
        "tool.memory.manage": "memory",
        "tool.todo.manage": "todo",
        "tool.message.send": "message",
        "tool.code.execute": "code",
    }
    if tool_id == "tool.companion.manage":
        target_label = companion_target_label(tool_event.invocation.arguments)
        action = companion_target_action(tool_event.invocation.arguments)
        if action == "inspect":
            return f"read {target_label}".strip()
        if action == "clear":
            return f"clear {target_label}".strip()
        return f"write {target_label}".strip()
    if tool_id.startswith("tool.browser."):
        return tool_id.removeprefix("tool.browser.")
    return aliases.get(tool_id, tool_id.removeprefix("tool."))


def _tool_trace_preview(arguments, *, tool_id: str | None = None) -> str:
    if tool_id == "tool.process.manage":
        action = str(arguments.get("action") or "").strip().lower()
        process_id = str(arguments.get("process_id") or "").strip()
        if action and process_id:
            return compact_line(f"{action} {process_id}", limit=56)
        if action:
            return compact_line(action, limit=36)
    if tool_id == "tool.terminal.exec":
        command = str(arguments.get("command") or "").strip()
        if command:
            return compact_line(command, limit=96)
    preview_keys = (
        "query",
        "pattern",
        "url",
        "path",
        "command",
        "title",
        "prompt",
        "name",
        "message",
        "text",
        "reference",
        "goal_id",
        "skill_id",
        "server_id",
    )
    for key in preview_keys:
        value = arguments.get(key)
        if value is None:
            continue
        text = str(value).strip()
        if text:
            return compact_line(text, limit=36)
    action = str(arguments.get("action") or "").strip().lower()
    if action in {"list", "ls"}:
        return "all"
    return ""


def _tool_trace_prepare_label(tool_event: ToolLifecycleEvent) -> str:
    tool_id = tool_event.invocation.tool_id
    if tool_id == "tool.terminal.exec":
        return "terminal"
    if tool_id == "tool.process.manage":
        return "process"
    if tool_id == "tool.skill.view":
        return "skill_view"
    if tool_id == "tool.skill.search":
        return "skill_search"
    if tool_id == "tool.skill.list":
        return "skill_list"
    return _tool_trace_label(tool_event)


def _tool_trace_started_label(tool_event: ToolLifecycleEvent) -> str:
    tool_id = tool_event.invocation.tool_id
    if tool_id == "tool.terminal.exec":
        return "$"
    if tool_id == "tool.process.manage":
        return "proc"
    if tool_id == "tool.skill.view":
        return "skill_view"
    if tool_id == "tool.skill.search":
        return "skill_search"
    if tool_id == "tool.skill.list":
        return "skill_list"
    return _tool_trace_label(tool_event)


def _tool_trace_duration(tool_event: ToolLifecycleEvent) -> str:
    requested_at = tool_event.invocation.requested_at
    if requested_at is None:
        return ""
    delta = max(0.0, (tool_event.occurred_at - requested_at).total_seconds())
    return f"{delta:.1f}s"


def _stream_preview(stream_text: str, *, limit: int = 220) -> str:
    normalized = " ".join(stream_text.split())
    if not normalized:
        return ""
    if len(normalized) <= limit:
        return normalized
    return f"{normalized[: limit - 3]}..."


def _stream_response_text(stream_text: str, *, limit: int = 3200) -> str:
    sanitized = _sanitize_stream_tool_markup(stream_text)
    normalized = strip_markdown_bold(sanitized.replace("\r\n", "\n").replace("\r", "\n")).lstrip("\n")
    if not normalized.strip():
        return ""
    if len(normalized) <= limit:
        return normalized
    tail = normalized[-limit:]
    newline = tail.find("\n")
    if newline >= 0:
        trimmed = tail[newline + 1 :].lstrip("\n")
        if trimmed:
            return f"...\n{trimmed}"
    return f"... {tail.lstrip()}"


def _sanitize_stream_tool_markup(raw: str) -> str:
    cleaned = raw
    for pattern in _STREAM_TOOL_BLOCK_PATTERNS:
        previous = None
        while previous != cleaned:
            previous = cleaned
            cleaned = pattern.sub("", cleaned)
    open_match = _STREAM_OPEN_TOOL_TAG_PATTERN.search(cleaned)
    if open_match is not None:
        cleaned = cleaned[: open_match.start()]
    cleaned = _STREAM_TOOL_TAG_PATTERN.sub("", cleaned)
    partial_start = _partial_tool_tag_start(cleaned)
    if partial_start is not None:
        cleaned = cleaned[:partial_start]
    cleaned = re.sub(r"\n{3,}", "\n\n", cleaned)
    return cleaned


def _partial_tool_tag_start(text: str) -> int | None:
    marker = text.rfind("<")
    if marker < 0:
        return None
    fragment = text[marker + 1 :].strip().lower()
    if ">" in fragment or not fragment:
        return marker if fragment == "" else None
    closing = fragment.startswith("/")
    if closing:
        fragment = fragment[1:]
    if ":" in fragment:
        fragment = fragment.split(":", 1)[1]
    fragment = fragment.strip()
    tool_tags = ("tool_call", "invoke", "parameter")
    if not fragment:
        return marker
    if any(name.startswith(fragment) for name in tool_tags):
        return marker
    return None
