from __future__ import annotations

from typing import TYPE_CHECKING

from .shell_stack import (
    Application,
    BeforeInput,
    Buffer,
    BufferControl,
    CompletionsMenu,
    Condition,
    ConditionalContainer,
    Dimension,
    FileHistory,
    FormattedText,
    FormattedTextControl,
    HSplit,
    KeyBindings,
    Layout,
    PROMPT_TOOLKIT_AVAILABLE,
    PromptSession,
    Style,
    Window,
    has_completions,
)
from .shell_ui import (
    BRAND_ACCENT,
    BRAND_ACCENT_STRONG,
    BRAND_DARK,
    BRAND_LIGHT,
    BRAND_MUTED,
    COMMAND_PALETTE_VISIBLE_ROWS,
    USER_HISTORY_BG,
    USER_HISTORY_FG,
)

if TYPE_CHECKING:
    from .shell import ProductizedShell


def prompt_toolkit_composer_available(shell: ProductizedShell) -> bool:
    if not PROMPT_TOOLKIT_AVAILABLE:
        return False
    return not any(
        component is None
        for component in (
            Application,
            Buffer,
            BufferControl,
            Condition,
            BeforeInput,
            ConditionalContainer,
            CompletionsMenu,
            Dimension,
            FormattedTextControl,
            HSplit,
            Layout,
            Window,
            has_completions,
        )
    )


def shell_history(shell: ProductizedShell):
    return FileHistory(str(shell.runtime.paths.state_dir / "shell-history.txt"))


def build_prompt_buffer(shell: ProductizedShell):
    from .shell import ShellCompleter

    return Buffer(
        multiline=True,
        completer=ShellCompleter(shell),
        complete_while_typing=True,
        history=shell_history(shell),
    )


def build_input_window(shell: ProductizedShell, buffer):
    return Window(
        BufferControl(
            buffer=buffer,
            input_processors=[BeforeInput("› ", style="class:composer-prefix")],
            focus_on_click=True,
        ),
        wrap_lines=True,
        dont_extend_height=True,
        height=Dimension(min=1, preferred=1, max=6),
    )


def build_command_palette(shell: ProductizedShell):
    return ConditionalContainer(
        content=CompletionsMenu(max_height=COMMAND_PALETTE_VISIBLE_ROWS, scroll_offset=1),
        filter=has_completions,
    )


def build_queue_preview_window(shell: ProductizedShell):
    return ConditionalContainer(
        content=Window(
            FormattedTextControl(lambda: shell._render_queued_followup_fragments()),
            wrap_lines=True,
            dont_extend_height=True,
        ),
        filter=Condition(lambda: bool(shell._pending_commands)),
    )


def build_divider_window(shell: ProductizedShell):
    return Window(
        FormattedTextControl([("class:composer-divider", shell._composer_divider())]),
        height=1,
        dont_extend_height=True,
    )


def build_status_window(shell: ProductizedShell):
    return Window(
        FormattedTextControl(lambda: shell._status_bar_fragments()),
        height=1,
        dont_extend_height=True,
    )


def build_composer_body(shell: ProductizedShell, *, input_window, command_palette, top_windows=()):
    return HSplit(
        [
            *top_windows,
            build_status_window(shell),
            build_divider_window(shell),
            command_palette,
            input_window,
            build_divider_window(shell),
        ]
    )


def read_command(shell: ProductizedShell) -> str:
    if not PROMPT_TOOLKIT_AVAILABLE:
        return input(f"{shell._composer_divider()}\n› ")
    if not prompt_toolkit_composer_available(shell):
        from .shell import ShellCompleter

        session = PromptSession(
            multiline=True,
            completer=ShellCompleter(shell),
            complete_while_typing=True,
            history=shell_history(shell),
            reserve_space_for_menu=COMMAND_PALETTE_VISIBLE_ROWS,
        )
        return session.prompt(
            shell._prompt_label(),
            style=shell._prompt_style(),
            key_bindings=shell._build_key_bindings(),
            prompt_continuation=shell._prompt_continuation(),
            erase_when_done=True,
        )

    buffer = build_prompt_buffer(shell)

    def submit(event) -> None:
        if event.current_buffer.text:
            event.current_buffer.append_to_history()
        event.app.exit(result=event.current_buffer.text)

    bindings = shell._build_key_bindings(submit=submit)
    input_window = build_input_window(shell, buffer)
    command_palette = build_command_palette(shell)
    composer_body = build_composer_body(
        shell,
        input_window=input_window,
        command_palette=command_palette,
    )
    application = Application(
        layout=Layout(composer_body, focused_element=input_window),
        key_bindings=bindings,
        style=shell._prompt_style(),
        full_screen=False,
        erase_when_done=True,
    )
    result = application.run()
    if result is None:
        raise EOFError
    return str(result)


def prompt_label(shell: ProductizedShell) -> str:
    divider = shell._composer_divider()
    if not PROMPT_TOOLKIT_AVAILABLE:
        return f"{divider}\n› "
    return FormattedText(
        [
            ("class:composer-divider", f"{divider}\n"),
            ("class:composer-prefix", "› "),
        ]
    )


def prompt_continuation():
    if not PROMPT_TOOLKIT_AVAILABLE:
        return "  "
    return FormattedText([("class:composer-prefix", "  ")])


def prompt_style():
    if not PROMPT_TOOLKIT_AVAILABLE:
        return None
    return Style.from_dict(prompt_style_map())


def prompt_style_map() -> dict[str, str]:
    return {
        "": f"fg:{BRAND_LIGHT}",
        "composer-divider": f"fg:{BRAND_ACCENT}",
        "composer-prefix": f"fg:{BRAND_ACCENT_STRONG} bold",
        "queue-user": f"{USER_HISTORY_FG} bg:{USER_HISTORY_BG}",
        "progress-title": f"fg:{BRAND_ACCENT} bold",
        "progress-active": f"fg:{BRAND_ACCENT_STRONG} bold",
        "progress-meta": f"fg:{BRAND_LIGHT}",
        "progress-tool": f"fg:{BRAND_LIGHT} bold",
        "progress-tool-rail": f"fg:{BRAND_DARK}",
        "progress-tool-emoji": f"fg:{BRAND_ACCENT}",
        "progress-tool-verb": f"fg:{BRAND_MUTED}",
        "progress-tool-label": f"fg:{BRAND_ACCENT_STRONG} bold",
        "progress-tool-gap": f"fg:{BRAND_LIGHT}",
        "progress-tool-body": f"fg:{BRAND_LIGHT}",
        "progress-tool-duration": f"fg:{BRAND_MUTED}",
        "progress-queue": f"fg:{BRAND_LIGHT}",
        "progress-hint": f"fg:{BRAND_LIGHT}",
        "progress-stream": f"fg:{BRAND_ACCENT_STRONG}",
        "stream-response-title": f"fg:{BRAND_ACCENT} bold",
        "stream-response-body": f"fg:{BRAND_LIGHT}",
        "completion-menu": "bg:#1b2029",
        "completion-menu.completion": f"bg:#1b2029 fg:{BRAND_LIGHT}",
        "completion-menu.completion.current": f"bg:#2a3343 fg:{BRAND_ACCENT_STRONG} bold",
        "completion-menu.meta.completion": f"bg:#1b2029 fg:{BRAND_MUTED}",
        "completion-menu.meta.completion.current": f"bg:#2a3343 fg:{BRAND_LIGHT}",
        "scrollbar.background": "bg:#1b2029",
        "scrollbar.button": f"bg:{BRAND_ACCENT}",
        "status-bar-edge": f"bg:#1b2029 fg:{BRAND_LIGHT}",
        "status-bar-model": f"bg:#1b2029 fg:{BRAND_ACCENT_STRONG} bold",
        "status-bar-sep": f"bg:#1b2029 fg:{BRAND_MUTED}",
        "status-bar-muted": f"bg:#1b2029 fg:{BRAND_LIGHT}",
        "status-bar-level": f"bg:#1b2029 fg:{BRAND_ACCENT} bold",
        "status-bar-growth-bracket": f"bg:#1b2029 fg:{BRAND_ACCENT} bold",
        "status-bar-growth-fill": f"bg:#1b2029 fg:{BRAND_ACCENT_STRONG} bold",
        "status-bar-growth-empty": f"bg:#1b2029 fg:{BRAND_DARK}",
        "status-bar-good": "bg:#1b2029 fg:#8cc28a bold",
        "status-bar-warn": f"bg:#1b2029 fg:{BRAND_ACCENT_STRONG} bold",
        "status-bar-critical": "bg:#1b2029 fg:#e17c64 bold",
    }


def build_key_bindings(*, submit=None, allow_exit: bool = True) -> KeyBindings:
    bindings = KeyBindings()
    submit_handler = submit or (lambda event: event.current_buffer.validate_and_handle())

    @bindings.add("enter")
    def _(event) -> None:
        submit_handler(event)

    @bindings.add("escape", "enter")
    def _(event) -> None:
        event.current_buffer.insert_text("\n")

    if allow_exit:

        @bindings.add("c-c")
        def _(event) -> None:
            raise KeyboardInterrupt

        @bindings.add("c-d")
        def _(event) -> None:
            raise EOFError
    else:

        @bindings.add("c-c")
        def _(event) -> None:
            event.current_buffer.text = ""

        @bindings.add("c-d")
        def _(event) -> None:
            event.current_buffer.text = ""

    return bindings
