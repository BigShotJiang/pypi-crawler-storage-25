"""Remote-control bridge from messaging surfaces into the CLI runtime."""

from __future__ import annotations

from collections.abc import Callable, Mapping
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
import json
from pathlib import Path
from typing import Any, Protocol

from apps.cli.runtime import CliRuntime
from packages.contracts.runtime import SessionState
from packages.gateway_core import GatewayInboundMessage


def _utc_now() -> datetime:
    return datetime.now(UTC)


def _mapping(value: object) -> Mapping[str, object] | None:
    return value if isinstance(value, Mapping) else None


def _optional_text(value: object) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    return text or None


class CliRuntimeLike(Protocol):
    def list_clones(self, *, limit: int = 12) -> tuple[object, ...]:
        ...

    def latest_session_for_clone(self, clone_id: str) -> SessionState | None:
        ...

    def create_clone(
        self,
        *,
        clone_id: str,
        profile_id: str | None = None,
        display_name: str | None = None,
        mode: str | None = None,
        session_id: str | None = None,
    ) -> SessionState:
        ...

    def inspect_session(self, session_id: str) -> SessionState:
        ...

    def prepare_session_surface(self, session_id: str) -> SessionState:
        ...

    def explain_next_step(
        self,
        *,
        session_id: str,
        prompt: str,
        goal_query: str | None = None,
        tool_name: str | None = None,
        tool_arguments: Mapping[str, Any] | None = None,
        delivery_payload: Mapping[str, Any] | None = None,
    ) -> Any:
        ...

    def wake(self, session_id: str, *, inspect_only: bool = False) -> Any:
        ...


CliRuntimeFactory = Callable[[Path, Path], CliRuntimeLike]


@dataclass(frozen=True, slots=True)
class FeishuCliControlConfig:
    profile_dir: str | None = None
    state_dir: str | None = None
    default_clone_id: str | None = None
    auto_create_clone: bool = False
    allow_group_chats: bool = False


@dataclass(frozen=True, slots=True)
class FeishuCliBinding:
    account_id: str
    conversation_id: str
    clone_id: str
    updated_at: str


@dataclass(slots=True)
class FeishuCliBindingStore:
    path: Path | None = None
    _bindings: dict[str, FeishuCliBinding] = field(default_factory=dict, init=False, repr=False)

    def __post_init__(self) -> None:
        self._bindings = self._load()

    def get(self, *, account_id: str, conversation_id: str) -> FeishuCliBinding | None:
        return self._bindings.get(self._key(account_id, conversation_id))

    def set(
        self,
        *,
        account_id: str,
        conversation_id: str,
        clone_id: str,
    ) -> FeishuCliBinding:
        binding = FeishuCliBinding(
            account_id=account_id,
            conversation_id=conversation_id,
            clone_id=clone_id,
            updated_at=_utc_now().isoformat(),
        )
        self._bindings[self._key(account_id, conversation_id)] = binding
        self._persist()
        return binding

    def _key(self, account_id: str, conversation_id: str) -> str:
        return f"{account_id}:{conversation_id}"

    def _load(self) -> dict[str, FeishuCliBinding]:
        if self.path is None or not self.path.exists():
            return {}
        payload = json.loads(self.path.read_text(encoding="utf-8"))
        items = payload.get("bindings")
        if not isinstance(items, list):
            return {}
        loaded: dict[str, FeishuCliBinding] = {}
        for item in items:
            if not isinstance(item, dict):
                continue
            try:
                binding = FeishuCliBinding(
                    account_id=str(item["account_id"]),
                    conversation_id=str(item["conversation_id"]),
                    clone_id=str(item["clone_id"]),
                    updated_at=str(item["updated_at"]),
                )
            except KeyError:
                continue
            loaded[self._key(binding.account_id, binding.conversation_id)] = binding
        return loaded

    def _persist(self) -> None:
        if self.path is None:
            return
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "bindings": [
                asdict(binding)
                for binding in sorted(
                    self._bindings.values(),
                    key=lambda item: (item.account_id, item.conversation_id),
                )
            ]
        }
        self.path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")


@dataclass(frozen=True, slots=True)
class FeishuCliControlResult:
    body: str | None
    clone_id: str | None = None
    session_id: str | None = None
    handled: bool = True
    summary: str | None = None


def load_feishu_cli_control_config(manifest: Mapping[str, object]) -> FeishuCliControlConfig:
    gateway_payload = _mapping(manifest.get("gateway")) or {}
    adapters_payload = _mapping(gateway_payload.get("adapters")) or {}
    feishu_payload = _mapping(adapters_payload.get("feishu")) or {}
    control_payload = _mapping(feishu_payload.get("control")) or {}
    return FeishuCliControlConfig(
        profile_dir=_optional_text(control_payload.get("profile_dir")),
        state_dir=_optional_text(control_payload.get("state_dir")),
        default_clone_id=_optional_text(control_payload.get("default_clone_id")),
        auto_create_clone=bool(control_payload.get("auto_create_clone", False)),
        allow_group_chats=bool(control_payload.get("allow_group_chats", False)),
    )


@dataclass(slots=True)
class FeishuCliControlService:
    config: FeishuCliControlConfig
    runtime_factory: CliRuntimeFactory | None = None
    binding_store: FeishuCliBindingStore | None = None
    _runtime: CliRuntimeLike | None = field(default=None, init=False, repr=False)

    def __post_init__(self) -> None:
        if self.binding_store is None:
            self.binding_store = FeishuCliBindingStore()

    def describe(self) -> Mapping[str, object]:
        clones: tuple[str, ...] = ()
        runtime_status = "uninitialized"
        error: str | None = None
        try:
            runtime = self.runtime()
        except RuntimeError as exc:
            runtime_status = "misconfigured"
            error = str(exc)
        else:
            runtime_status = "ready"
            clones = tuple(getattr(item, "clone_id", "") for item in runtime.list_clones(limit=8))
        return {
            "enabled": True,
            "runtime": "cli-runtime",
            "profile_dir": self.config.profile_dir,
            "state_dir": self.config.state_dir,
            "default_clone_id": self.config.default_clone_id,
            "auto_create_clone": self.config.auto_create_clone,
            "allow_group_chats": self.config.allow_group_chats,
            "runtime_status": runtime_status,
            "runtime_error": error,
            "known_clones": clones,
        }

    def handle_message(self, inbound: GatewayInboundMessage) -> FeishuCliControlResult:
        if inbound.sender.is_bot:
            return FeishuCliControlResult(
                body=None,
                handled=False,
                summary="ignored bot sender",
            )
        if not self.config.allow_group_chats and inbound.chat_type not in {None, "direct"}:
            return FeishuCliControlResult(
                body=(
                    "Feishu remote control currently supports private chats only. "
                    "Move this conversation to a direct message or enable "
                    "`gateway.adapters.feishu.control.allow_group_chats`."
                ),
                summary="group chat blocked",
            )

        body = inbound.body.strip()
        command, argument = self._parse_command(body)
        try:
            if command:
                return self._handle_command(inbound, command=command, argument=argument)

            runtime = self.runtime()
            clone_id = self._resolve_bound_clone(runtime, inbound)
            if clone_id is None:
                return FeishuCliControlResult(
                    body=self._clone_selection_hint(runtime),
                    summary="no clone binding",
                )

            session = self._session_for_clone(runtime, clone_id)
            runtime.prepare_session_surface(session.session_id)
            outcome = runtime.explain_next_step(
                session_id=session.session_id,
                prompt=body,
                delivery_payload={"summary": f"feishu:{inbound.event_id}"},
            )
            self.binding_store.set(
                account_id=inbound.account_id,
                conversation_id=inbound.conversation_id,
                clone_id=clone_id,
            )
            return FeishuCliControlResult(
                body=str(outcome.execution.summary),
                clone_id=clone_id,
                session_id=session.session_id,
                summary="forwarded to cli runtime",
            )
        except RuntimeError as exc:
            return FeishuCliControlResult(
                body=str(exc),
                summary="control error",
            )

    def runtime(self) -> CliRuntimeLike:
        if self._runtime is not None:
            return self._runtime
        if self.runtime_factory is None:
            if self.config.profile_dir is None or self.config.state_dir is None:
                raise RuntimeError(
                    "feishu control requires gateway.adapters.feishu.control.profile_dir "
                    "and state_dir so the bridge can target the existing CLI runtime."
                )
            self._runtime = CliRuntime.create(
                profile_dir=Path(self.config.profile_dir),
                state_dir=Path(self.config.state_dir),
            )
            return self._runtime
        profile_dir = Path(self.config.profile_dir or ".")
        state_dir = Path(self.config.state_dir or ".")
        self._runtime = self.runtime_factory(profile_dir, state_dir)
        return self._runtime

    def _handle_command(
        self,
        inbound: GatewayInboundMessage,
        *,
        command: str,
        argument: str | None,
    ) -> FeishuCliControlResult:
        runtime = self.runtime()
        if command in {"help", "start"}:
            return FeishuCliControlResult(body=self._help_text(), summary="help")
        if command in {"clones", "list"}:
            return FeishuCliControlResult(body=self._clone_listing(runtime), summary="list clones")
        if command in {"use", "bind"}:
            if not argument:
                return FeishuCliControlResult(
                    body="Usage: /use <clone_id>\nTry /clones to inspect the available clones first.",
                    summary="missing clone id",
                )
            clone_id = argument.strip()
            session = self._session_for_clone(runtime, clone_id)
            self.binding_store.set(
                account_id=inbound.account_id,
                conversation_id=inbound.conversation_id,
                clone_id=clone_id,
            )
            return FeishuCliControlResult(
                body=(
                    f"Bound this Feishu thread to clone `{clone_id}`.\n"
                    f"session_id: `{session.session_id}`\n"
                    "Send plain text next and I will continue on that local Aegis line."
                ),
                clone_id=clone_id,
                session_id=session.session_id,
                summary="clone bound",
            )
        if command == "status":
            clone_id, selection_mode = self._clone_selection(runtime, inbound)
            if clone_id is None:
                return FeishuCliControlResult(
                    body=self._clone_selection_hint(runtime),
                    summary="status without clone",
                )
            session = self._session_for_clone(runtime, clone_id)
            selection_label = {
                "bound": "bound",
                "default": "configured-default",
                "recent": "most-recent-clone",
            }.get(selection_mode or "", "unknown")
            return FeishuCliControlResult(
                body=(
                    f"Current clone: `{clone_id}`\n"
                    f"selection: `{selection_label}`\n"
                    f"session_id: `{session.session_id}`\n"
                    f"status: `{session.status}`\n"
                    f"workspace_id: `{session.workspace_id or clone_id}`"
                ),
                clone_id=clone_id,
                session_id=session.session_id,
                summary="status",
            )
        if command == "wake":
            clone_id = self._resolve_bound_clone(runtime, inbound)
            if clone_id is None:
                return FeishuCliControlResult(
                    body=self._clone_selection_hint(runtime),
                    summary="wake without binding",
                )
            session = self._session_for_clone(runtime, clone_id)
            result = runtime.wake(session.session_id)
            return FeishuCliControlResult(
                body=(
                    f"Woke clone `{clone_id}`.\n"
                    f"session_id: `{result.session.session_id}`\n"
                    f"next_step: {result.decision.rationale.summary}"
                ),
                clone_id=clone_id,
                session_id=result.session.session_id,
                summary="wake",
            )
        return FeishuCliControlResult(
            body=(
                f"Unknown command `/{command}`.\n"
                "Try /help, /clones, /use <clone_id>, /status, or /wake."
            ),
            summary="unknown command",
        )

    def _session_for_clone(self, runtime: CliRuntimeLike, clone_id: str) -> SessionState:
        session = runtime.latest_session_for_clone(clone_id)
        if session is not None:
            return session
        if not self.config.auto_create_clone:
            raise RuntimeError(
                f"unknown clone: {clone_id}. Create it locally first or enable "
                "gateway.adapters.feishu.control.auto_create_clone."
            )
        return runtime.create_clone(clone_id=clone_id)

    def _clone_selection(
        self,
        runtime: CliRuntimeLike,
        inbound: GatewayInboundMessage,
    ) -> tuple[str | None, str | None]:
        binding = self.binding_store.get(
            account_id=inbound.account_id,
            conversation_id=inbound.conversation_id,
        )
        if binding is not None:
            return binding.clone_id, "bound"
        if self.config.default_clone_id is not None:
            return self.config.default_clone_id, "default"
        clones = runtime.list_clones(limit=1)
        if not clones:
            return None, None
        return _optional_text(getattr(clones[0], "clone_id", None)), "recent"

    def _resolve_bound_clone(
        self,
        runtime: CliRuntimeLike,
        inbound: GatewayInboundMessage,
    ) -> str | None:
        clone_id, _ = self._clone_selection(runtime, inbound)
        return clone_id

    def _clone_listing(self, runtime: CliRuntimeLike) -> str:
        clones = runtime.list_clones(limit=12)
        if not clones:
            return (
                "No local Aegis clones are available yet.\n"
                "Create one from the CLI first, or configure "
                "`gateway.adapters.feishu.control.auto_create_clone` together with a default clone."
            )
        lines = ["Available local Aegis clones:"]
        for clone in clones:
            clone_id = str(getattr(clone, "clone_id", ""))
            latest_session_id = str(getattr(clone, "latest_session_id", ""))
            latest_status = str(getattr(clone, "latest_status", ""))
            session_count = int(getattr(clone, "session_count", 0) or 0)
            lines.append(
                f"- {clone_id} · latest {latest_session_id[:8]} · "
                f"{session_count} session{'s' if session_count != 1 else ''} · {latest_status}"
            )
        lines.append(
            "Plain text follows the most recently active clone by default. "
            "Send `/use <clone_id>` when you want to pin this thread to a specific clone."
        )
        return "\n".join(lines)

    def _clone_selection_hint(self, runtime: CliRuntimeLike) -> str:
        clones = runtime.list_clones(limit=8)
        if not clones:
            return (
                "This Feishu thread is not connected to a local Aegis clone yet, and no clones are "
                "available. Create one in the CLI first."
            )
        clone_id = str(getattr(clones[0], "clone_id", "") or "")
        return (
            f"This thread is not pinned yet. Plain text will continue on `{clone_id}` by default, "
            "because it is the most recently active local clone.\n"
            "Send `/use <clone_id>` if you want to pin this thread to a different clone.\n\n"
            + self._clone_listing(runtime)
        )

    def _help_text(self) -> str:
        return "\n".join(
            (
                "Feishu remote control commands:",
                "- /clones · list the local Aegis clones this bridge can see",
                "- /use <clone_id> · pin this Feishu conversation to a clone",
                "- /status · inspect the clone/session currently handling this thread",
                "- /wake · ask the active clone to refresh its next-step plan",
                "- plain text · forward the message into the active clone (defaults to the most recently active local clone)",
            )
        )

    def _parse_command(self, body: str) -> tuple[str | None, str | None]:
        if not body.startswith("/"):
            return None, None
        parts = body[1:].split(None, 1)
        command = parts[0].strip().lower()
        argument = parts[1].strip() if len(parts) > 1 else None
        return (command or None, argument)


__all__ = [
    "CliRuntimeFactory",
    "CliRuntimeLike",
    "FeishuCliBinding",
    "FeishuCliBindingStore",
    "FeishuCliControlConfig",
    "FeishuCliControlResult",
    "FeishuCliControlService",
    "load_feishu_cli_control_config",
]
