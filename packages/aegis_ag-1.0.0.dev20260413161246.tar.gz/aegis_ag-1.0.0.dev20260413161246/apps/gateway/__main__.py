from __future__ import annotations
from argparse import ArgumentParser, Namespace
from collections.abc import Iterable, Mapping, Sequence
from dataclasses import asdict, dataclass
from datetime import UTC, datetime
import getpass
import apps.cli.wizard as cli_wizard
import importlib.util
import json
import os
from pathlib import Path
import re
import shlex
import signal
import subprocess
import sys
import time
from wsgiref.simple_server import make_server

from apps.cli.shell import (
    Align,
    BRAND_ACCENT,
    BRAND_ACCENT_STRONG,
    BRAND_LIGHT,
    BRAND_MUTED,
    Console,
    Group,
    Panel,
    RICH_AVAILABLE,
    Table,
    Text,
    _resolve_aegis_version,
    render_guardian_mark,
)
from apps.provider_runtime import load_runtime_local_secret_env
from apps.runtime_layout import default_cli_state_dir, default_gateway_state_dir, default_profile_dir
from packages.gateway_core import DEFAULT_GATEWAY_ACCOUNT_ID
from packages.profile import write_profile_manifest

from . import (
    DEFAULT_FEISHU_APP_ID_ENV,
    DEFAULT_FEISHU_APP_SECRET_ENV,
    DEFAULT_FEISHU_EVENT_PATH,
    FEISHU_ADAPTER_ID,
    SUPPORTED_FEISHU_TRANSPORTS,
    build_gateway_app,
    build_gateway_plugin_registry,
    create_gateway_web_app,
)
from .feishu import FEISHU_SDK_PIP_SPEC, FeishuGatewayService

try:
    from prompt_toolkit.application import Application
    from prompt_toolkit.key_binding import KeyBindings as PromptKeyBindings
    from prompt_toolkit.layout.containers import HSplit, Window
    from prompt_toolkit.layout.controls import FormattedTextControl
    from prompt_toolkit.layout.layout import Layout
    from prompt_toolkit.shortcuts import input_dialog
    from prompt_toolkit.styles import Style as PromptStyle

    PROMPT_TOOLKIT_DIALOGS_AVAILABLE = True
except ModuleNotFoundError:  # pragma: no cover - optional wizard polish
    Application = None
    PromptKeyBindings = None
    HSplit = None
    Window = None
    FormattedTextControl = None
    Layout = None
    input_dialog = None
    PromptStyle = None
    PROMPT_TOOLKIT_DIALOGS_AVAILABLE = False


@dataclass(frozen=True)
class GatewayRuntimePaths:
    runtime_id: str
    pid_path: Path
    log_path: Path
    record_path: Path


@dataclass(frozen=True)
class GatewayRuntimeRecord:
    runtime_id: str
    service_key: str
    transport: str
    status: str
    pid: int | None
    pid_path: str
    log_path: str
    record_path: str
    command: tuple[str, ...]
    profile_dir: str
    state_dir: str
    cli_profile_dir: str | None
    cli_state_dir: str | None
    workspace_id: str
    account_id: str | None = None
    host: str | None = None
    port: int | None = None
    started_at: str | None = None
    stopped_at: str | None = None
    last_exit_code: int | None = None
    last_error: str | None = None


@dataclass(slots=True)
class FeishuGatewayWizardState:
    account_id: str
    transport: str
    event_path: str
    app_id_env_var: str
    app_secret_env_var: str
    app_id_value: str
    app_secret_value: str
    enabled: bool
    default_clone_id: str
    auto_create_clone: bool
    allow_group_chats: bool


GATEWAY_WIZARD_MAX_VISIBLE_CHOICES = cli_wizard.WIZARD_MAX_VISIBLE_CHOICES
GatewayWizardChoice = cli_wizard.WizardChoice
_GatewayWizardBackSignal = cli_wizard._WizardBackSignal
GATEWAY_WIZARD_BACK = cli_wizard.WIZARD_BACK
_interactive_shell_supported = cli_wizard._interactive_shell_supported
_gateway_wizard_dialogs_supported = cli_wizard._wizard_dialogs_supported
_shared_wizard_choice_prompt = cli_wizard._wizard_choice_prompt
_shared_wizard_text_prompt = cli_wizard._wizard_text_prompt


def _gateway_wizard_choice_label(choice: GatewayWizardChoice) -> str:
    if not choice.emoji:
        return choice.label
    return f"{choice.emoji} {choice.label}"


def _gateway_wizard_choice_window(
    total: int,
    selected: int,
    *,
    max_visible: int = GATEWAY_WIZARD_MAX_VISIBLE_CHOICES,
) -> tuple[int, int]:
    if total <= max_visible:
        return 0, total
    if selected < 0:
        selected = 0
    if selected >= total:
        selected = total - 1
    half = max_visible // 2
    start = max(0, selected - half)
    end = start + max_visible
    if end > total:
        end = total
        start = end - max_visible
    return start, end


def _gateway_wizard_choice_fragments(
    title: str,
    prompt: str,
    choices: tuple[GatewayWizardChoice, ...],
    *,
    selected: int,
    max_visible: int = GATEWAY_WIZARD_MAX_VISIBLE_CHOICES,
    allow_back: bool = False,
) -> list[tuple[str, str]]:
    fragments: list[tuple[str, str]] = [
        ("class:title", f"{title}\n"),
        ("class:prompt", f"{prompt}\n\n"),
    ]
    start, end = _gateway_wizard_choice_window(
        len(choices),
        selected,
        max_visible=max_visible,
    )
    if start > 0:
        fragments.append(("class:hint", f"↑ {start} more above\n"))
    for index in range(start, end):
        choice = choices[index]
        active = index == selected
        marker = "›" if active else " "
        label_style = "class:selected" if active else "class:item"
        detail_style = "class:selected-detail" if active else "class:detail"
        fragments.append((label_style, f"{marker} {_gateway_wizard_choice_label(choice)}\n"))
        fragments.append((detail_style, f"  {choice.detail}\n"))
    if end < len(choices):
        fragments.append(("class:hint", f"↓ {len(choices) - end} more below\n"))
    if allow_back:
        fragments.append(("class:hint", "\nEnter confirms · Esc goes back · ↑/↓ or j/k moves"))
    else:
        fragments.append(("class:hint", "\nEnter confirms · ↑/↓ or j/k moves"))
    return fragments


def _gateway_wizard_choice_menu(
    title: str,
    prompt: str,
    choices: tuple[GatewayWizardChoice, ...],
    *,
    default: str,
    allow_back: bool = False,
) -> str | _GatewayWizardBackSignal:
    if not (
        PROMPT_TOOLKIT_DIALOGS_AVAILABLE
        and Application is not None
        and PromptKeyBindings is not None
        and HSplit is not None
        and Window is not None
        and FormattedTextControl is not None
        and Layout is not None
    ):
        return default
    selected = next(
        (index for index, choice in enumerate(choices) if choice.value == default),
        0,
    )
    result: dict[str, str] = {"value": default}

    def render():
        return _gateway_wizard_choice_fragments(
            title,
            prompt,
            choices,
            selected=selected,
            allow_back=allow_back,
        )

    control = FormattedTextControl(render)
    bindings = PromptKeyBindings()

    @bindings.add("down")
    @bindings.add("j")
    def _move_down(event) -> None:
        nonlocal selected
        selected = (selected + 1) % len(choices)
        event.app.invalidate()

    @bindings.add("up")
    @bindings.add("k")
    def _move_up(event) -> None:
        nonlocal selected
        selected = (selected - 1) % len(choices)
        event.app.invalidate()

    @bindings.add("tab")
    def _move_tab(event) -> None:
        nonlocal selected
        selected = (selected + 1) % len(choices)
        event.app.invalidate()

    @bindings.add("enter")
    def _accept(event) -> None:
        result["value"] = choices[selected].value
        event.app.exit(result=result["value"])

    @bindings.add("escape")
    def _cancel(event) -> None:
        event.app.exit(result=GATEWAY_WIZARD_BACK if allow_back else default)

    application = Application(
        layout=Layout(HSplit([Window(content=control)])),
        key_bindings=bindings,
        style=_gateway_wizard_style(),
        full_screen=True,
        erase_when_done=True,
    )
    answer = application.run()
    if answer is GATEWAY_WIZARD_BACK:
        return GATEWAY_WIZARD_BACK
    return str(answer or default)


def _gateway_prompt_value(
    label: str,
    *,
    default: str | None = None,
    preserve_default_on_empty: bool = True,
) -> str:
    suffix = f" [{default}]" if default else ""
    answer = input(f"{label}{suffix}: ").strip()
    if answer:
        return answer
    if preserve_default_on_empty:
        return default or ""
    return ""


def _gateway_wizard_text_prompt(
    title: str,
    prompt: str,
    *,
    default: str | None = None,
    allow_back: bool = False,
    preserve_default_on_empty: bool = True,
) -> str | _GatewayWizardBackSignal:
    if _gateway_wizard_dialogs_supported():
        answer = _shared_wizard_text_prompt(
            title,
            prompt,
            default=default,
            allow_back=allow_back,
            preserve_default_on_empty=preserve_default_on_empty,
        )
        if answer is GATEWAY_WIZARD_BACK:
            return GATEWAY_WIZARD_BACK
        return str(answer)
    return _gateway_prompt_value(
        prompt,
        default=default,
        preserve_default_on_empty=preserve_default_on_empty,
    )


def _gateway_wizard_choice_prompt(
    title: str,
    prompt: str,
    choices: tuple[GatewayWizardChoice, ...],
    *,
    default: str | None = None,
    allow_back: bool = False,
) -> str | _GatewayWizardBackSignal:
    if not choices:
        return default or ""
    default_value = default or choices[0].value
    if _gateway_wizard_dialogs_supported():
        answer = _shared_wizard_choice_prompt(
            title,
            prompt,
            choices,
            default=default_value,
            allow_back=allow_back,
        )
        if answer is GATEWAY_WIZARD_BACK:
            return GATEWAY_WIZARD_BACK
        return str(answer)
    print(prompt)
    for index, choice in enumerate(choices, start=1):
        marker = "*" if choice.value == default_value else " "
        print(f"  {marker} {index}. {_gateway_wizard_choice_label(choice)} :: {choice.detail}")
    while True:
        answer = input(f"choice [{default_value}]: ").strip()
        if not answer:
            return default_value
        if allow_back and answer.casefold() in {"back", "b"}:
            return GATEWAY_WIZARD_BACK
        if answer.isdigit():
            index = int(answer)
            if 1 <= index <= len(choices):
                return choices[index - 1].value
        normalized = answer.casefold()
        for choice in choices:
            if normalized in {choice.value.casefold(), choice.label.casefold()}:
                return choice.value
        print("  choose a listed number, transport id, or label.")


def _gateway_bool_choices(
    *,
    enabled_label: str,
    enabled_detail: str,
    disabled_label: str,
    disabled_detail: str,
) -> tuple[GatewayWizardChoice, GatewayWizardChoice]:
    return (
        GatewayWizardChoice(
            value="yes",
            label=enabled_label,
            detail=enabled_detail,
            emoji="✅",
        ),
        GatewayWizardChoice(
            value="no",
            label=disabled_label,
            detail=disabled_detail,
            emoji="➖",
        ),
    )


def _gateway_bool_prompt(
    title: str,
    prompt: str,
    *,
    default: bool,
    enabled_label: str,
    enabled_detail: str,
    disabled_label: str,
    disabled_detail: str,
    allow_back: bool = False,
) -> bool | _GatewayWizardBackSignal:
    answer = _gateway_wizard_choice_prompt(
        title,
        prompt,
        _gateway_bool_choices(
            enabled_label=enabled_label,
            enabled_detail=enabled_detail,
            disabled_label=disabled_label,
            disabled_detail=disabled_detail,
        ),
        default="yes" if default else "no",
        allow_back=allow_back,
    )
    if answer is GATEWAY_WIZARD_BACK:
        return GATEWAY_WIZARD_BACK
    return str(answer) == "yes"


def _feishu_transport_choices() -> tuple[GatewayWizardChoice, ...]:
    details = {
        "long-connection": "Use Feishu long connection for a local bridge without webhook setup.",
    }
    return tuple(
        GatewayWizardChoice(
            value=transport,
            label=transport.replace("-", " ").title(),
            detail=details.get(transport, "Use this Feishu ingress transport."),
            emoji="🛰️",
        )
        for transport in SUPPORTED_FEISHU_TRANSPORTS
    )


def _im_setup_choices(*, allow_skip: bool) -> tuple[GatewayWizardChoice, ...]:
    choices: list[GatewayWizardChoice] = [
        GatewayWizardChoice(
            value="feishu",
            label="Feishu",
            detail="Wire a Feishu bot into Aegis IM and route plain text into your local clone runtime.",
            emoji="🪽",
        )
    ]
    if allow_skip:
        choices.append(
            GatewayWizardChoice(
                value="skip",
                label="Skip for now",
                detail="Stay local for now. You can always run `aegis im` later.",
                emoji="➖",
            )
        )
    return tuple(choices)


def _center_brand_block(renderable):
    if Align is None:
        return renderable
    return Align.center(renderable)


def _print_gateway_feishu_wizard_intro() -> None:
    if not RICH_AVAILABLE or Table is None or Panel is None or Group is None:
        print("Aegis IM // Feishu setup")
        print("  - choose the Feishu account you want to wire")
        print("  - bind App ID and App Secret cleanly")
        print("  - keep profile wiring and local credentials separate")
        print("  - check Bot, Events, Long Connection, and Permissions in Feishu")
        return
    console = Console(highlight=False, soft_wrap=True)
    brand = Table.grid(expand=True)
    brand.add_column(no_wrap=True)
    hero = Text(justify="center")
    hero.append("Bring Feishu into Aegis IM.\n", style=f"bold {BRAND_LIGHT}")
    hero.append(
        "A short setup flow for wiring credentials, clone routing, and the Feishu console path with less friction.",
        style=BRAND_MUTED,
    )
    flow = Text()
    flow.append("IM setup flow\n", style=f"bold {BRAND_ACCENT}")
    flow.append("1 · Choose the Feishu account and long-connection surface\n", style=BRAND_LIGHT)
    flow.append("2 · Paste App ID and App Secret directly into the local IM secret store\n", style=BRAND_LIGHT)
    flow.append("3 · Decide how the control bridge routes clones\n", style=BRAND_LIGHT)
    flow.append("4 · Start the bridge with credentials kept out of profile.json", style=BRAND_LIGHT)
    portal = Text()
    portal.append("Feishu console checklist\n", style=f"bold {BRAND_ACCENT}")
    portal.append("Capability · Add App Capability → Bot\n", style=BRAND_LIGHT)
    portal.append("Events · Event Subscriptions → add `im.message.receive_v1`\n", style=BRAND_LIGHT)
    portal.append("Transport · Use Long Connection for local IM bring-up\n", style=BRAND_LIGHT)
    portal.append(
        "Permissions · Enable `im:message`, `im:message.p2p_msg:readonly`, and `im:message:send_as_bot`",
        style=BRAND_LIGHT,
    )
    brand.add_row(_center_brand_block(hero))
    brand.add_row(Text(" "))
    brand.add_row(_center_brand_block(render_guardian_mark()))
    brand.add_row(Text(" "))
    content = Table.grid(expand=True)
    console_width = getattr(console.size, "width", 0)
    if console_width and console_width < 148:
        content.add_column(ratio=1, min_width=52)
        content.add_row(brand)
        content.add_row(Text(" "))
        content.add_row(flow)
        content.add_row(Text(" "))
        content.add_row(portal)
    else:
        content.add_column(ratio=11, min_width=42)
        content.add_column(ratio=12, min_width=44)
        content.add_column(ratio=12, min_width=44)
        content.add_row(brand, flow, portal)
    console.print(
        Panel(
            content,
            title=f"[bold {BRAND_ACCENT}] IM Feishu Setup v{_resolve_aegis_version()} [/bold {BRAND_ACCENT}]",
            subtitle="[bold {brand}]Polished local bridge setup for Feishu.[/bold {brand}]".replace(
                "{brand}",
                BRAND_LIGHT,
            ),
            border_style=BRAND_ACCENT,
            padding=(1, 2),
        )
    )


def _gateway_wizard_secret_prompt(
    title: str,
    prompt: str,
    *,
    allow_back: bool = False,
) -> str | _GatewayWizardBackSignal:
    if _gateway_wizard_dialogs_supported():
        answer = _shared_wizard_text_prompt(
            title,
            prompt,
            allow_back=allow_back,
            password=True,
        )
        if answer is GATEWAY_WIZARD_BACK:
            return GATEWAY_WIZARD_BACK
        return str(answer).strip()
    hint = " (leave blank to keep the current local value" + (", type back to return" if allow_back else "") + ")"
    answer = getpass.getpass(f"{prompt}{hint}: ").strip()
    if allow_back and answer.casefold() == "back":
        return GATEWAY_WIZARD_BACK
    return answer



def _print_gateway_setup_paused() -> None:
    print("Feishu IM setup paused")
    print("  No IM changes were written.")
    print("  next_commands:")
    print("  - aegis im")
    print("  - aegis im doctor")


def _ensure_feishu_sdk_available(*, reason: str) -> bool:
    if importlib.util.find_spec("lark_oapi") is not None:
        return False
    command = [
        sys.executable,
        "-m",
        "pip",
        "install",
        "--disable-pip-version-check",
        FEISHU_SDK_PIP_SPEC,
    ]
    print(f"Preparing Feishu support for {reason}...")
    try:
        subprocess.run(command, check=True)
    except (OSError, subprocess.CalledProcessError) as exc:
        rendered = " ".join(shlex.quote(part) for part in command)
        raise SystemExit(
            "Aegis could not automatically install the Feishu SDK. "
            f"Run `{rendered}` and retry."
        ) from exc
    if importlib.util.find_spec("lark_oapi") is None:
        rendered = " ".join(shlex.quote(part) for part in command)
        raise SystemExit(
            "Aegis finished the Feishu SDK install command, but `lark_oapi` is still unavailable. "
            f"Run `{rendered}` manually and retry."
        )
    print("Feishu support is ready.")
    return True


def _run_interactive_feishu_wizard(
    *,
    account_id: str,
    transport: str,
    event_path: str,
    app_id_env_var: str,
    app_secret_env_var: str,
    app_id_value: str,
    app_secret_value: str,
    enabled: bool,
    default_clone_id: str,
    auto_create_clone: bool,
    allow_group_chats: bool,
) -> FeishuGatewayWizardState | None:
    state = FeishuGatewayWizardState(
        account_id=account_id,
        transport=transport,
        event_path=event_path,
        app_id_env_var=app_id_env_var,
        app_secret_env_var=app_secret_env_var,
        app_id_value=app_id_value,
        app_secret_value=app_secret_value,
        enabled=enabled,
        default_clone_id=default_clone_id,
        auto_create_clone=auto_create_clone,
        allow_group_chats=allow_group_chats,
    )
    steps = (
        "account_id",
        "transport",
        "event_path",
        "app_id_value",
        "app_secret_value",
        "enabled",
        "default_clone_id",
        "auto_create_clone",
        "allow_group_chats",
    )
    step_index = 0
    while step_index < len(steps):
        step = steps[step_index]
        if step == "account_id":
            answer = _gateway_wizard_text_prompt(
                "Feishu Account",
                "Which Feishu gateway account id should this bridge use?",
                default=state.account_id,
                allow_back=True,
            )
            if answer is GATEWAY_WIZARD_BACK:
                return None
            state.account_id = str(answer).strip() or DEFAULT_GATEWAY_ACCOUNT_ID
            step_index += 1
            continue
        if step == "transport":
            answer = _gateway_wizard_choice_prompt(
                "Ingress Transport",
                "How should this Feishu bridge receive events?",
                _feishu_transport_choices(),
                default=state.transport,
                allow_back=True,
            )
            if answer is GATEWAY_WIZARD_BACK:
                step_index -= 1
                continue
            state.transport = str(answer)
            step_index += 1
            continue
        if step == "event_path":
            answer = _gateway_wizard_text_prompt(
                "Compatibility Event Path",
                "Which webhook-style event path should stay in the manifest for compatibility?",
                default=state.event_path,
                allow_back=True,
            )
            if answer is GATEWAY_WIZARD_BACK:
                step_index -= 1
                continue
            state.event_path = str(answer).strip() or DEFAULT_FEISHU_EVENT_PATH
            step_index += 1
            continue
        if step == "app_id_value":
            answer = _gateway_wizard_text_prompt(
                "Paste App ID",
                "Paste the Feishu App ID to store it in the local IM secret file. Leave blank to keep the current local value if one already exists.",
                default=None,
                allow_back=True,
                preserve_default_on_empty=False,
            )
            if answer is GATEWAY_WIZARD_BACK:
                step_index -= 1
                continue
            state.app_id_value = str(answer).strip()
            step_index += 1
            continue
        if step == "app_secret_value":
            answer = _gateway_wizard_secret_prompt(
                "Paste App Secret",
                "Paste the Feishu App Secret / API key to store it in the local IM secret file.",
                allow_back=True,
            )
            if answer is GATEWAY_WIZARD_BACK:
                step_index -= 1
                continue
            state.app_secret_value = str(answer).strip()
            step_index += 1
            continue
        if step == "enabled":
            answer = _gateway_bool_prompt(
                "Serve With Gateway",
                "Should Feishu also be enabled for `aegis im serve`?",
                default=state.enabled,
                enabled_label="Enable for serve",
                enabled_detail="Mount Feishu whenever you run `aegis im serve`.",
                disabled_label="Keep config only",
                disabled_detail="Write the config now, but start Feishu explicitly later.",
                allow_back=True,
            )
            if answer is GATEWAY_WIZARD_BACK:
                step_index -= 1
                continue
            state.enabled = bool(answer)
            step_index += 1
            continue
        if step == "default_clone_id":
            answer = _gateway_wizard_text_prompt(
                "Default Clone",
                "Optional: which clone should plain text fall back to before a thread is pinned? Leave blank to follow the most recent clone.",
                default=state.default_clone_id,
                allow_back=True,
                preserve_default_on_empty=False,
            )
            if answer is GATEWAY_WIZARD_BACK:
                step_index -= 1
                continue
            state.default_clone_id = str(answer).strip()
            step_index += 1
            continue
        if step == "auto_create_clone":
            answer = _gateway_bool_prompt(
                "Auto-create Missing Clone",
                "If the default clone does not exist yet, should the control bridge create it automatically?",
                default=state.auto_create_clone,
                enabled_label="Auto-create clone",
                enabled_detail="Create the configured default clone the first time Feishu needs it.",
                disabled_label="Require existing clone",
                disabled_detail="Make Feishu wait until the clone already exists locally.",
                allow_back=True,
            )
            if answer is GATEWAY_WIZARD_BACK:
                step_index -= 1
                continue
            state.auto_create_clone = bool(answer)
            step_index += 1
            continue
        if step == "allow_group_chats":
            answer = _gateway_bool_prompt(
                "Group Chats",
                "Should the Feishu control bridge accept group chats too?",
                default=state.allow_group_chats,
                enabled_label="Allow group chats",
                enabled_detail="Let the bridge respond in group chats as well as direct messages.",
                disabled_label="Direct messages only",
                disabled_detail="Keep the bridge limited to private chats.",
                allow_back=True,
            )
            if answer is GATEWAY_WIZARD_BACK:
                step_index -= 1
                continue
            state.allow_group_chats = bool(answer)
            step_index += 1
            continue
    return state


def _mapping(value: object) -> Mapping[str, object] | None:
    return value if isinstance(value, Mapping) else None


def _mapping_payload(value: object, *, path: str) -> dict[str, object]:
    if value is None:
        return {}
    if not isinstance(value, Mapping):
        raise ValueError(f"{path} must be a JSON object")
    return {str(key): item for key, item in value.items()}


def _load_profile_manifest(profile_dir: Path) -> dict[str, object]:
    manifest_path = profile_dir / "profile.json"
    if not manifest_path.exists():
        return {}
    payload = json.loads(manifest_path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("profile.json must contain a JSON object")
    return payload


GATEWAY_LOCAL_SECRET_ENV_FILE = "gateway-local-secrets.json"



def _gateway_local_secret_env_path(state_dir: Path) -> Path:
    return state_dir / GATEWAY_LOCAL_SECRET_ENV_FILE



def _load_gateway_local_secret_env(state_dir: Path) -> dict[str, str]:
    path = _gateway_local_secret_env_path(state_dir)
    if not path.exists():
        return {}
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, Mapping):
        raise ValueError(f"{path} must contain a JSON object")
    resolved: dict[str, str] = {}
    for key, value in payload.items():
        text = str(value).strip()
        if text:
            resolved[str(key)] = text
    return resolved



def _persist_gateway_local_secret_env(
    state_dir: Path,
    updates: Mapping[str, str],
) -> Path | None:
    filtered = {str(key): str(value).strip() for key, value in updates.items() if str(value).strip()}
    if not filtered:
        return None
    state_dir.mkdir(parents=True, exist_ok=True)
    path = _gateway_local_secret_env_path(state_dir)
    payload = _load_gateway_local_secret_env(state_dir)
    payload.update(filtered)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass
    return path



def _gateway_runtime_environ(
    state_dir: Path,
    *,
    cli_state_dir: Path | None = None,
) -> dict[str, str]:
    env = load_runtime_local_secret_env(cli_state_dir or state_dir)
    env.update(_load_gateway_local_secret_env(state_dir))
    env.update(os.environ)
    return env



def _read_pid(path: Path) -> int | None:
    if not path.exists():
        return None
    try:
        return int(path.read_text(encoding="utf-8").strip())
    except (OSError, ValueError):
        return None


def _pid_is_running(pid: int | None) -> bool:
    if pid is None or pid <= 0:
        return False
    try:
        os.kill(pid, 0)
    except OSError:
        return False
    return True


def _optional_text(value: object) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def _coerce_int(value: object) -> int | None:
    if value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _utc_now_iso() -> str:
    return datetime.now(UTC).isoformat()


def _default_gateway_runtime_path(
    args: Namespace,
    *,
    service_key: str,
    target: str,
    suffix: str,
) -> Path:
    normalized_target = str(target).strip().lower().replace("_", "-") or "configured"
    return args.state_dir / f"{service_key}-{normalized_target}.{suffix}"


def _default_feishu_runtime_path(args: Namespace, *, transport: str, suffix: str) -> Path:
    return _default_gateway_runtime_path(
        args,
        service_key="feishu",
        target=transport,
        suffix=suffix,
    )


def _feishu_runtime_paths(args: Namespace, *, transport: str) -> GatewayRuntimePaths:
    normalized_transport = str(transport).strip().lower().replace("_", "-") or "configured"
    return GatewayRuntimePaths(
        runtime_id=f"feishu:{normalized_transport}",
        pid_path=_default_feishu_runtime_path(args, transport=transport, suffix="pid"),
        log_path=_default_feishu_runtime_path(args, transport=transport, suffix="log"),
        record_path=_default_feishu_runtime_path(args, transport=transport, suffix="runtime.json"),
    )


def _load_runtime_record(path: Path) -> dict[str, object] | None:
    if not path.exists():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    if not isinstance(payload, dict):
        return None
    return {str(key): value for key, value in payload.items()}


def _write_runtime_record(path: Path, record: GatewayRuntimeRecord) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(asdict(record), ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def _build_feishu_runtime_record(
    args: Namespace,
    *,
    paths: GatewayRuntimePaths,
    transport: str,
    status: str,
    pid: int | None,
    existing: Mapping[str, object] | None = None,
    command: Sequence[str] | None = None,
    started_at: str | None = None,
    stopped_at: str | None = None,
    last_exit_code: int | None = None,
    last_error: str | None = None,
) -> GatewayRuntimeRecord:
    existing_payload = dict(existing or {})
    command_payload = tuple(
        str(value)
        for value in (command or existing_payload.get("command") or ())
    )
    profile_dir = _optional_text(getattr(args, "profile_dir", None)) or _optional_text(
        existing_payload.get("profile_dir")
    )
    cli_profile_dir = _optional_text(getattr(args, "cli_profile_dir", None)) or _optional_text(
        existing_payload.get("cli_profile_dir")
    )
    cli_state_dir = _optional_text(getattr(args, "cli_state_dir", None)) or _optional_text(
        existing_payload.get("cli_state_dir")
    )
    workspace_id = _optional_text(getattr(args, "workspace_id", None)) or _optional_text(
        existing_payload.get("workspace_id")
    )
    host = _optional_text(getattr(args, "host", None)) or _optional_text(existing_payload.get("host"))
    port = _coerce_int(getattr(args, "port", None))
    if port is None:
        port = _coerce_int(existing_payload.get("port"))
    if status == "running":
        stopped_at = None
        last_exit_code = None
        last_error = None
    elif last_exit_code is None:
        last_exit_code = _coerce_int(existing_payload.get("last_exit_code"))
    if last_error is None:
        last_error = _optional_text(existing_payload.get("last_error"))
    if stopped_at is None and status != "running":
        stopped_at = _optional_text(existing_payload.get("stopped_at"))
    if started_at is None:
        started_at = _optional_text(existing_payload.get("started_at"))
    if started_at is None and status in {"starting", "running"}:
        started_at = _utc_now_iso()
    return GatewayRuntimeRecord(
        runtime_id=paths.runtime_id,
        service_key="feishu",
        transport=transport,
        status=status,
        pid=pid,
        pid_path=str(paths.pid_path),
        log_path=str(paths.log_path),
        record_path=str(paths.record_path),
        command=command_payload,
        profile_dir=profile_dir or "",
        state_dir=str(getattr(args, "state_dir", paths.pid_path.parent)),
        cli_profile_dir=cli_profile_dir,
        cli_state_dir=cli_state_dir,
        workspace_id=workspace_id or "",
        account_id=_optional_text(getattr(args, "account_id", None))
        or _optional_text(existing_payload.get("account_id")),
        host=host,
        port=port,
        started_at=started_at,
        stopped_at=stopped_at,
        last_exit_code=last_exit_code,
        last_error=last_error,
    )


def _runtime_state(paths: GatewayRuntimePaths) -> dict[str, object]:
    record = _load_runtime_record(paths.record_path) or {}
    pid_from_file = _read_pid(paths.pid_path)
    pid_from_record = _coerce_int(record.get("pid"))
    pid = pid_from_file if pid_from_file is not None else pid_from_record
    pid_active = _pid_is_running(pid)
    record_status = _optional_text(record.get("status")) or "stopped"
    if pid_active:
        status = "running"
    elif record_status == "failed":
        status = "failed"
    else:
        status = "stopped"
    return {
        "record": record,
        "pid": pid,
        "pid_from_file": pid_from_file,
        "pid_from_record": pid_from_record,
        "pid_active": pid_active,
        "stale_pid": pid_from_file is not None and not pid_active,
        "status": status,
    }


def _remove_file_if_exists(path: Path) -> None:
    try:
        path.unlink()
    except FileNotFoundError:
        return


def _wait_for_pid_exit(pid: int, *, timeout_seconds: float) -> bool:
    deadline = time.monotonic() + max(timeout_seconds, 0.0)
    while time.monotonic() < deadline:
        if not _pid_is_running(pid):
            return True
        time.sleep(0.2)
    return not _pid_is_running(pid)


def _terminate_pid(pid: int, *, timeout_seconds: float, force: bool) -> str | None:
    if timeout_seconds < 0:
        raise SystemExit("--timeout must be zero or a positive number.")
    if not _pid_is_running(pid):
        return None
    try:
        os.kill(pid, signal.SIGTERM)
    except ProcessLookupError:
        return None
    except PermissionError as exc:
        raise SystemExit(f"Unable to stop process {pid}: {exc}") from exc
    if _wait_for_pid_exit(pid, timeout_seconds=timeout_seconds):
        return signal.Signals(signal.SIGTERM).name
    if not force:
        raise SystemExit(
            f"Process {pid} did not exit within {timeout_seconds:g}s. Retry with `--force` to send SIGKILL."
        )
    try:
        os.kill(pid, signal.SIGKILL)
    except ProcessLookupError:
        return signal.Signals(signal.SIGTERM).name
    except PermissionError as exc:
        raise SystemExit(f"Unable to force-stop process {pid}: {exc}") from exc
    if _wait_for_pid_exit(pid, timeout_seconds=max(timeout_seconds, 2.0)):
        return signal.Signals(signal.SIGKILL).name
    raise SystemExit(f"Process {pid} is still running after SIGKILL.")


def _build_detached_feishu_command(args: Namespace, *, transport: str) -> list[str]:
    command = [
        sys.executable,
        "-m",
        "apps.launcher",
        "im",
        "start",
        "--transport",
        transport,
        "--profile-dir",
        str(args.profile_dir),
        "--state-dir",
        str(args.state_dir),
        "--cli-profile-dir",
        str(args.cli_profile_dir),
        "--cli-state-dir",
        str(args.cli_state_dir),
        "--workspace-id",
        str(args.workspace_id),
        "--host",
        str(args.host),
        "--port",
        str(args.port),
    ]
    if args.account_id:
        command.extend(["--account-id", str(args.account_id)])
    return command


def _run_start_detached(args: Namespace, *, transport: str) -> int:
    paths = _feishu_runtime_paths(args, transport=transport)
    state = _runtime_state(paths)
    existing_pid = state["pid"]
    if state["pid_active"]:
        raise SystemExit(
            f"Feishu {transport} transport is already running in the background with pid {existing_pid}."
        )
    args.state_dir.mkdir(parents=True, exist_ok=True)
    command = _build_detached_feishu_command(args, transport=transport)
    started_at = _utc_now_iso()
    with paths.log_path.open("ab") as log_stream:
        process = subprocess.Popen(
            command,
            stdin=subprocess.DEVNULL,
            stdout=log_stream,
            stderr=subprocess.STDOUT,
            start_new_session=True,
            env=_gateway_runtime_environ(
                args.state_dir,
                cli_state_dir=args.cli_state_dir,
            ),
        )
    paths.pid_path.write_text(f"{process.pid}\n", encoding="utf-8")
    _write_runtime_record(
        paths.record_path,
        _build_feishu_runtime_record(
            args,
            paths=paths,
            transport=transport,
            status="starting",
            pid=process.pid,
            existing=state["record"],
            command=command,
            started_at=started_at,
        ),
    )
    time.sleep(0.4)
    return_code = process.poll()
    if return_code is not None:
        _remove_file_if_exists(paths.pid_path)
        log_excerpt = ""
        try:
            excerpt_lines = paths.log_path.read_text(encoding="utf-8").splitlines()[-20:]
        except OSError:
            excerpt_lines = []
        if excerpt_lines:
            log_excerpt = "\nRecent log output:\n" + "\n".join(excerpt_lines)
        _write_runtime_record(
            paths.record_path,
            _build_feishu_runtime_record(
                args,
                paths=paths,
                transport=transport,
                status="failed",
                pid=None,
                existing=state["record"],
                command=command,
                started_at=started_at,
                stopped_at=_utc_now_iso(),
                last_exit_code=return_code,
                last_error=f"process exited with code {return_code}",
            ),
        )
        raise SystemExit(
            f"Feishu {transport} transport failed to stay up in the background (exit {return_code})."
            f" Check {paths.log_path}.{log_excerpt}"
        )
    _write_runtime_record(
        paths.record_path,
        _build_feishu_runtime_record(
            args,
            paths=paths,
            transport=transport,
            status="running",
            pid=process.pid,
            existing=state["record"],
            command=command,
            started_at=started_at,
            stopped_at=None,
            last_exit_code=None,
            last_error=None,
        ),
    )
    print(f"Started Aegis IM Feishu {transport} transport in background.")
    print(f"PID: {process.pid}")
    print(f"PID file: {paths.pid_path}")
    print(f"Log file: {paths.log_path}")
    print(f"Runtime record: {paths.record_path}")
    print(f"View logs: aegis im logs --transport {transport} --follow")
    return 0


def _resolve_feishu_transport_argument(
    args: Namespace,
    *,
    service: FeishuGatewayService | None = None,
) -> str:
    requested_transport = str(getattr(args, "transport", "configured") or "configured")
    if requested_transport != "configured":
        return requested_transport
    if service is None:
        raise SystemExit(
            "Resolving `--transport configured` requires an active Feishu gateway profile."
        )
    return service.configured_transport()


def _read_log_excerpt(path: Path, *, tail: int) -> tuple[str, ...]:
    if tail < 0:
        raise SystemExit("--tail must be zero or a positive integer.")
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except OSError as exc:
        raise SystemExit(f"Unable to read log file {path}: {exc}") from exc
    if tail == 0:
        return ()
    return tuple(lines[-tail:])


def _follow_log_file(path: Path) -> None:
    with path.open("r", encoding="utf-8") as stream:
        stream.seek(0, os.SEEK_END)
        while True:
            chunk = stream.read()
            if chunk:
                print(chunk, end="")
                sys.stdout.flush()
                continue
            time.sleep(0.4)
            try:
                current_size = path.stat().st_size
            except OSError:
                current_size = stream.tell()
            if current_size < stream.tell():
                stream.seek(0)


def _format_runtime_command(record: Mapping[str, object]) -> str:
    command = record.get("command")
    if not isinstance(command, (list, tuple)):
        return "<none>"
    parts = [str(part) for part in command if str(part)]
    if not parts:
        return "<none>"
    return shlex.join(parts)


def _run_status(args: Namespace, *, service: FeishuGatewayService | None = None) -> int:
    transport = _resolve_feishu_transport_argument(args, service=service)
    paths = _feishu_runtime_paths(args, transport=transport)
    state = _runtime_state(paths)
    record = state["record"]
    print("Aegis IM runtime status")
    print(f"runtime_id: {paths.runtime_id}")
    print("service_key: feishu")
    print(f"transport: {transport}")
    print(f"status: {state['status']}")
    print(f"recorded_status: {record.get('status') or '<none>'}")
    print(f"pid: {state['pid'] if state['pid'] is not None else '<none>'}")
    print(f"pid_active: {'yes' if state['pid_active'] else 'no'}")
    print(f"stale_pid_file: {'yes' if state['stale_pid'] else 'no'}")
    print(f"pid_file: {paths.pid_path}")
    print(f"log_file: {paths.log_path}")
    print(f"record_file: {paths.record_path}")
    print(f"started_at: {record.get('started_at') or '<none>'}")
    print(f"stopped_at: {record.get('stopped_at') or '<none>'}")
    print(f"last_exit_code: {record.get('last_exit_code') if record.get('last_exit_code') is not None else '<none>'}")
    print(f"last_error: {record.get('last_error') or '<none>'}")
    print(f"account_id: {record.get('account_id') or '<none>'}")
    print(f"command: {_format_runtime_command(record)}")
    return 0


def _stop_feishu_runtime(args: Namespace, *, transport: str) -> tuple[str, str | None, GatewayRuntimePaths]:
    paths = _feishu_runtime_paths(args, transport=transport)
    state = _runtime_state(paths)
    record = state["record"]
    pid = _coerce_int(state["pid"])
    if pid is None or not state["pid_active"]:
        if state["stale_pid"]:
            _remove_file_if_exists(paths.pid_path)
        _write_runtime_record(
            paths.record_path,
            _build_feishu_runtime_record(
                args,
                paths=paths,
                transport=transport,
                status="stopped",
                pid=None,
                existing=record,
                stopped_at=_utc_now_iso(),
            ),
        )
        return "already-stopped", None, paths
    signal_name = _terminate_pid(pid, timeout_seconds=args.timeout, force=args.force)
    _remove_file_if_exists(paths.pid_path)
    _write_runtime_record(
        paths.record_path,
        _build_feishu_runtime_record(
            args,
            paths=paths,
            transport=transport,
            status="stopped",
            pid=None,
            existing=record,
            stopped_at=_utc_now_iso(),
            last_exit_code=0,
            last_error=None,
        ),
    )
    return "stopped", signal_name, paths


def _run_stop(args: Namespace, *, service: FeishuGatewayService | None = None) -> int:
    transport = _resolve_feishu_transport_argument(args, service=service)
    outcome, signal_name, paths = _stop_feishu_runtime(args, transport=transport)
    if outcome == "already-stopped":
        print(f"Feishu {transport} transport is not running.")
    else:
        print(f"Stopped Aegis IM Feishu {transport} transport.")
        print(f"Signal: {signal_name or '<none>'}")
    print(f"Log file: {paths.log_path}")
    print(f"Runtime record: {paths.record_path}")
    return 0


def _run_restart(args: Namespace, *, service: FeishuGatewayService | None = None) -> int:
    transport = _resolve_feishu_transport_argument(args, service=service)
    if transport == "long-connection":
        _ensure_feishu_sdk_available(reason="Feishu long-connection restart")
    print(f"Restarting Aegis IM Feishu {transport} transport.")
    outcome, _, _ = _stop_feishu_runtime(args, transport=transport)
    if outcome == "already-stopped":
        print("No running detached runtime was found; starting a fresh background process.")
    return _run_start_detached(args, transport=transport)


def _run_logs(args: Namespace, *, service: FeishuGatewayService | None = None) -> int:
    transport = _resolve_feishu_transport_argument(args, service=service)
    paths = _feishu_runtime_paths(args, transport=transport)
    state = _runtime_state(paths)
    if args.path:
        print(paths.log_path)
        return 0
    if not paths.log_path.exists():
        running_hint = (
            f" Background pid {state['pid']} is still recorded." if state["pid_active"] else ""
        )
        raise SystemExit(
            f"No log file found for Feishu {transport} transport at {paths.log_path}."
            f" Start it with `aegis im start --transport {transport} --detach` first.{running_hint}"
        )
    excerpt = _read_log_excerpt(paths.log_path, tail=args.tail)
    if excerpt:
        print("\n".join(excerpt))
    if args.follow:
        if not excerpt:
            print(f"Following {paths.log_path} (Ctrl-C to stop)")
        try:
            _follow_log_file(paths.log_path)
        except KeyboardInterrupt:
            return 0
    return 0


def _secret_reference_id(*, account_id: str, secret_key: str) -> str:
    normalized_account = re.sub(r"[^a-z0-9]+", "-", account_id.strip().lower()).strip("-") or "default"
    normalized_key = secret_key.replace("_", "-")
    return f"secret-feishu-{normalized_account}-{normalized_key}"


def _default_feishu_secret_env_var(*, account_id: str, secret_key: str) -> str:
    if account_id == DEFAULT_GATEWAY_ACCOUNT_ID:
        if secret_key == "app_id":
            return DEFAULT_FEISHU_APP_ID_ENV
        if secret_key == "app_secret":
            return DEFAULT_FEISHU_APP_SECRET_ENV
    normalized_account = re.sub(r"[^A-Za-z0-9]+", "_", account_id.strip()).strip("_").upper() or "DEFAULT"
    suffix = "APP_ID" if secret_key == "app_id" else "APP_SECRET"
    return f"AEGIS_FEISHU_{normalized_account}_{suffix}"


def _build_feishu_secret_reference(
    *,
    account_id: str,
    secret_key: str,
    env_var: str,
) -> dict[str, object]:
    return {
        "reference_id": _secret_reference_id(account_id=account_id, secret_key=secret_key),
        "provider_id": FEISHU_ADAPTER_ID,
        "secret_name": secret_key,
        "secret_key": secret_key,
        "metadata": {"env_var": env_var},
    }


def _find_feishu_account(
    accounts: Sequence[Mapping[str, object]],
    *,
    account_id: str,
) -> Mapping[str, object] | None:
    for account in accounts:
        current_account_id = str(account.get("account_id") or DEFAULT_GATEWAY_ACCOUNT_ID)
        if current_account_id == account_id:
            return account
    return None


def _account_secret_env_var(
    account_payload: Mapping[str, object] | None,
    *,
    secret_key: str,
) -> str | None:
    if account_payload is None:
        return None
    env_payload = _mapping(account_payload.get("env")) or {}
    direct = env_payload.get(secret_key)
    if direct is not None:
        text = str(direct).strip()
        if text:
            return text
    secret_refs = account_payload.get("secret_references")
    if not isinstance(secret_refs, list):
        return None
    for item in secret_refs:
        if not isinstance(item, Mapping):
            continue
        if str(item.get("secret_key") or "") != secret_key:
            continue
        metadata = _mapping(item.get("metadata")) or {}
        for key in ("env_var", "env", "environment_variable"):
            candidate = metadata.get(key)
            if candidate is None:
                continue
            text = str(candidate).strip()
            if text:
                return text
    return None


def _resolved_feishu_secret_env_var(
    *,
    explicit_env_var: object,
    existing_account: Mapping[str, object] | None,
    account_id: str,
    secret_key: str,
) -> str:
    if explicit_env_var is not None:
        text = str(explicit_env_var).strip()
        if text:
            return text
    return _account_secret_env_var(existing_account, secret_key=secret_key) or _default_feishu_secret_env_var(
        account_id=account_id,
        secret_key=secret_key,
    )


def _upsert_feishu_account(
    accounts: Sequence[Mapping[str, object]],
    account_payload: Mapping[str, object],
) -> list[dict[str, object]]:
    target_account_id = str(account_payload.get("account_id") or DEFAULT_GATEWAY_ACCOUNT_ID)
    resolved = [dict(account) for account in accounts]
    for index, account in enumerate(resolved):
        account_id = str(account.get("account_id") or DEFAULT_GATEWAY_ACCOUNT_ID)
        if account_id == target_account_id:
            resolved[index] = dict(account_payload)
            return resolved
    resolved.append(dict(account_payload))
    return resolved


def _resolved_defaults(
    *,
    default_profile_dir_override: Path | None = None,
    default_state_dir_override: Path | None = None,
    default_control_profile_dir_override: Path | None = None,
    default_control_state_dir_override: Path | None = None,
) -> dict[str, Path]:
    return {
        "profile_dir": default_profile_dir_override or default_profile_dir(),
        "state_dir": default_state_dir_override or default_gateway_state_dir(),
        "cli_profile_dir": default_control_profile_dir_override or default_profile_dir(),
        "cli_state_dir": default_control_state_dir_override or default_cli_state_dir(),
    }


def _add_common_gateway_options(parser: ArgumentParser, *, defaults: dict[str, Path]) -> None:
    parser.add_argument("--profile-dir", type=Path, default=defaults["profile_dir"])
    parser.add_argument("--state-dir", type=Path, default=defaults["state_dir"])
    parser.add_argument("--cli-profile-dir", type=Path, default=defaults["cli_profile_dir"])
    parser.add_argument("--cli-state-dir", type=Path, default=defaults["cli_state_dir"])
    parser.add_argument("--workspace-id", default="workspace:gateway")


def _add_http_server_options(parser: ArgumentParser) -> None:
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8788)


def _add_feishu_runtime_target_options(
    parser: ArgumentParser,
    *,
    transport_help: str,
    include_account_id: bool = False,
) -> None:
    parser.add_argument(
        "--transport",
        choices=("configured", "long-connection"),
        default="configured",
        help=transport_help,
    )
    if include_account_id:
        parser.add_argument(
            "--account-id",
            help="Explicit Feishu gateway account to use for long-connection mode.",
        )


def _add_feishu_start_options(parser: ArgumentParser) -> None:
    _add_feishu_runtime_target_options(
        parser,
        transport_help="Which Feishu ingress transport to run. 'configured' uses gateway.adapters.feishu.accounts[].surface.",
        include_account_id=True,
    )
    parser.add_argument(
        "--detach",
        action="store_true",
        help="Start the Feishu transport in a background process and return immediately.",
    )
    _add_http_server_options(parser)



def _add_feishu_status_options(parser: ArgumentParser) -> None:
    _add_feishu_runtime_target_options(
        parser,
        transport_help="Which Feishu detached transport runtime to inspect. 'configured' uses gateway.adapters.feishu.accounts[].surface.",
    )



def _add_feishu_stop_options(parser: ArgumentParser) -> None:
    _add_feishu_runtime_target_options(
        parser,
        transport_help="Which Feishu detached transport runtime to stop. 'configured' uses gateway.adapters.feishu.accounts[].surface.",
    )
    parser.add_argument(
        "--timeout",
        type=float,
        default=10.0,
        help="Seconds to wait for a graceful shutdown before failing or forcing.",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Send SIGKILL when the process does not exit within --timeout.",
    )



def _add_feishu_restart_options(parser: ArgumentParser) -> None:
    _add_feishu_runtime_target_options(
        parser,
        transport_help="Which Feishu detached transport runtime to restart. 'configured' uses gateway.adapters.feishu.accounts[].surface.",
        include_account_id=True,
    )
    _add_http_server_options(parser)
    parser.add_argument(
        "--timeout",
        type=float,
        default=10.0,
        help="Seconds to wait for the previous process to exit before failing or forcing.",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Send SIGKILL when the previous process does not exit within --timeout.",
    )



def _add_feishu_logs_options(parser: ArgumentParser) -> None:
    _add_feishu_runtime_target_options(
        parser,
        transport_help="Which Feishu detached transport log to inspect. 'configured' uses gateway.adapters.feishu.accounts[].surface.",
    )
    parser.add_argument(
        "--tail",
        type=int,
        default=80,
        help="Show the last N log lines before exiting or following. Use 0 to suppress the initial excerpt.",
    )
    parser.add_argument(
        "--follow",
        action="store_true",
        help="Keep streaming appended log output until interrupted.",
    )
    parser.add_argument(
        "--path",
        action="store_true",
        help="Print the resolved log file path and exit.",
    )


def _add_feishu_add_options(parser: ArgumentParser) -> None:
    parser.add_argument(
        "--account-id",
        default=DEFAULT_GATEWAY_ACCOUNT_ID,
        help="Feishu gateway account id to create or update.",
    )
    parser.add_argument(
        "--transport",
        choices=SUPPORTED_FEISHU_TRANSPORTS,
        default=None,
        help="Configured transport to persist for this Feishu account (defaults to existing or long-connection).",
    )
    parser.add_argument(
        "--event-path",
        default=None,
        help="Legacy webhook event path to persist for compatibility (defaults to existing or /feishu/events); long-connection does not use it directly.",
    )
    parser.add_argument(
        "--app-id-env-var",
        default=None,
        help="Environment variable alias used to resolve the Feishu App ID.",
    )
    parser.add_argument(
        "--app-secret-env-var",
        default=None,
        help="Environment variable alias used to resolve the Feishu App Secret / API key.",
    )
    parser.add_argument(
        "--app-id",
        "--api-id",
        dest="app_id",
        default=None,
        help="Optional raw Feishu App ID to store in the local gateway secret file instead of profile.json.",
    )
    parser.add_argument(
        "--app-secret",
        "--api-key",
        dest="app_secret",
        default=None,
        help="Optional raw Feishu App Secret / API key to store in the local gateway secret file instead of profile.json.",
    )
    wizard_group = parser.add_mutually_exclusive_group()
    wizard_group.add_argument(
        "--wizard",
        dest="wizard",
        action="store_true",
        default=None,
        help="Force the interactive Feishu setup wizard even when command-line flags are present.",
    )
    wizard_group.add_argument(
        "--no-wizard",
        dest="wizard",
        action="store_false",
        help="Skip the interactive wizard and write configuration directly from CLI arguments.",
    )
    enabled_group = parser.add_mutually_exclusive_group()
    enabled_group.add_argument(
        "--enabled",
        dest="enabled",
        action="store_true",
        default=None,
        help="Also enable Feishu for `aegis im serve`.",
    )
    enabled_group.add_argument(
        "--disabled",
        dest="enabled",
        action="store_false",
        help="Keep Feishu configured but excluded from `aegis im serve`.",
    )
    parser.add_argument(
        "--default-clone-id",
        help="Default local clone id for the Feishu control bridge.",
    )
    parser.add_argument(
        "--auto-create-clone",
        action="store_true",
        help="Allow the Feishu control bridge to auto-create the default clone when it is missing.",
    )
    parser.add_argument(
        "--allow-group-chats",
        action="store_true",
        help="Allow the Feishu control bridge to accept group chats.",
    )


def _build_registry():
    return build_gateway_plugin_registry()


def _build_app(args: Namespace, *, registry=None):
    args.state_dir.mkdir(parents=True, exist_ok=True)
    app, _, _ = build_gateway_app(
        profile_dir=str(args.profile_dir),
        state_dir=str(args.state_dir),
        workspace_id=args.workspace_id,
        runtime_environ=_gateway_runtime_environ(
            args.state_dir,
            cli_state_dir=args.cli_state_dir,
        ),
        plugin_registry=registry,
    )
    return app


def _service_kwargs_for(service_key: str, args: Namespace) -> dict[str, object]:
    if service_key == "feishu":
        return {
            "default_cli_profile_dir": (
                None if args.cli_profile_dir is None else str(args.cli_profile_dir)
            ),
            "default_cli_state_dir": (
                None if args.cli_state_dir is None else str(args.cli_state_dir)
            ),
            "environ": _gateway_runtime_environ(
                args.state_dir,
                cli_state_dir=args.cli_state_dir,
            ),
        }
    return {}


def _build_services(
    args: Namespace,
    *,
    service_keys: Iterable[str] | None = None,
):
    registry = _build_registry()
    app = _build_app(args, registry=registry)
    manifest = app.loaded_profile.manifest if app.loaded_profile is not None else None
    resolved_keys = (
        tuple(service_keys)
        if service_keys is not None
        else registry.configured_service_keys(manifest)
    )
    services = {
        key: registry.create_service(
            key,
            app=app,
            **_service_kwargs_for(key, args),
        )
        for key in resolved_keys
    }
    return app, services


def _build_service(args: Namespace) -> FeishuGatewayService:
    registry = _build_registry()
    app = _build_app(args, registry=registry)
    service = registry.create_service(
        "feishu",
        app=app,
        respect_enabled=False,
        **_service_kwargs_for("feishu", args),
    )
    if not isinstance(service, FeishuGatewayService):
        raise TypeError("gateway service plugin 'feishu' must build FeishuGatewayService")
    return service


def _describe_payload(service) -> dict[str, object]:
    return {
        "gateway": dict(service.app.setup_summary()),
        "feishu": dict(service.describe()),
    }


def _describe_services_payload(
    app,
    services: Mapping[str, object],
) -> dict[str, object]:
    payload: dict[str, object] = {
        "gateway": dict(app.setup_summary()),
        "services": {
            key: dict(service.describe())
            for key, service in services.items()
            if hasattr(service, "describe")
        },
    }
    for key, service in services.items():
        if hasattr(service, "describe"):
            payload[key] = dict(service.describe())
    return payload


def _print_json(payload: dict[str, object]) -> None:
    print(json.dumps(payload, ensure_ascii=False, indent=2, default=str))


def _next_steps(service) -> tuple[str, ...]:
    description = service.describe()
    accounts = tuple(description.get("accounts") or ())
    control = dict(description.get("control") or {})
    steps: list[str] = []
    if description.get("sdk_dependency_status") == "missing_optional_dependency":
        steps.append("Aegis will auto-install the Feishu SDK when you run `aegis im` or `aegis im start`.")
    if any(account.get("credentials_status") != "configured" for account in accounts if isinstance(account, dict)):
        env_vars: list[str] = []
        secret_reference_ids: list[str] = []
        for account in accounts:
            if not isinstance(account, dict):
                continue
            credential_env_vars = account.get("credential_env_vars")
            if isinstance(credential_env_vars, (list, tuple)):
                env_vars.extend(
                    value for value in credential_env_vars if isinstance(value, str) and value
                )
            else:
                env_vars.extend(
                    value
                    for value in (
                        account.get("app_id_env_var"),
                        account.get("app_secret_env_var"),
                    )
                    if isinstance(value, str) and value
                )
            secret_refs = account.get("secret_reference_ids")
            if isinstance(secret_refs, (list, tuple)):
                secret_reference_ids.extend(
                    value for value in secret_refs if isinstance(value, str) and value
                )
        if env_vars:
            steps.append(
                "Complete Feishu IM setup again with `aegis im` to store the App ID and App Secret locally, or export these advanced credential aliases manually: "
                + ", ".join(dict.fromkeys(env_vars))
            )
        elif secret_reference_ids:
            steps.append(
                "Complete Feishu IM setup again with `aegis im` or configure the active Feishu runtime secrets referenced by: "
                + ", ".join(dict.fromkeys(secret_reference_ids))
            )
    if control.get("runtime_status") != "ready":
        steps.append(
            "Make sure the IM bridge can open the local CLI runtime, or pass `--cli-profile-dir` / `--cli-state-dir` explicitly when the launcher defaults are not correct."
        )
    known_clones = tuple(control.get("known_clones") or ()) if isinstance(control, dict) else ()
    if not known_clones:
        steps.append(
            "Create a local clone first with `aegis clone demo`. Once a clone exists, plain text will route to the most recently active clone by default, and `/use demo` can pin the thread explicitly."
        )
    if not steps:
        steps.append("IM wiring looks healthy. Start it with `aegis im start --transport long-connection`. ")
    return tuple(steps)


def _doctor_lines(service, args: Namespace) -> tuple[str, ...]:
    description = service.describe()
    accounts = tuple(description.get("accounts") or ())
    control = dict(description.get("control") or {})
    lines = [
        "Aegis IM doctor",
        f"im_profile_dir: {args.profile_dir}",
        f"im_state_dir: {args.state_dir}",
        f"cli_profile_dir: {args.cli_profile_dir}",
        f"cli_state_dir: {args.cli_state_dir}",
        f"configured_transport: {description.get('configured_transport') or '<unset>'}",
        f"sdk_dependency_status: {description.get('sdk_dependency_status')}",
    ]
    if description.get("configured_transport_error"):
        lines.append(f"configured_transport_error: {description['configured_transport_error']}")
    for account in accounts:
        if not isinstance(account, dict):
            continue
        lines.append(
            "feishu_account: "
            f"{account.get('account_id')} · credentials={account.get('credentials_status')} · "
            f"surface={account.get('surface')} · event_path={account.get('event_path')}"
        )
    lines.append(f"control_runtime_status: {control.get('runtime_status') or '<unknown>'}")
    if control.get("runtime_error"):
        lines.append(f"control_runtime_error: {control['runtime_error']}")
    known_clones = tuple(control.get("known_clones") or ())
    lines.append(
        "control_known_clones: "
        + (", ".join(str(clone) for clone in known_clones if clone) or "<none>")
    )
    lines.append("next_steps:")
    lines.extend(f"- {step}" for step in _next_steps(service))
    return tuple(lines)


def _doctor_service_lines(
    service_key: str,
    service,
) -> tuple[str, ...]:
    if service_key == "feishu":
        description = service.describe()
        lines = [
            f"service[{service_key}].configured_transport: {description.get('configured_transport') or '<unset>'}",
            f"service[{service_key}].sdk_dependency_status: {description.get('sdk_dependency_status') or '<n/a>'}",
        ]
        for account in tuple(description.get("accounts") or ()):
            if not isinstance(account, dict):
                continue
            lines.append(
                f"service[{service_key}].account: {account.get('account_id')} · credentials={account.get('credentials_status')} · surface={account.get('surface')} · event_path={account.get('event_path')}"
            )
        return tuple(lines)
    description = service.describe() if hasattr(service, "describe") else {}
    lines = [
        f"service[{service_key}].configured_transport: {description.get('configured_transport') or '<unset>'}",
    ]
    for account in tuple(description.get("accounts") or ()):
        if not isinstance(account, dict):
            continue
        lines.append(
            f"service[{service_key}].account: {account.get('account_id')} · credentials={account.get('credentials_status')} · surface={account.get('surface')} · event_path={account.get('event_path')}"
        )
    return tuple(lines)


def _doctor_services_lines(app, services: Mapping[str, object], args: Namespace) -> tuple[str, ...]:
    lines = [
        "Aegis IM doctor",
        f"im_profile_dir: {args.profile_dir}",
        f"im_state_dir: {args.state_dir}",
        f"cli_profile_dir: {args.cli_profile_dir}",
        f"cli_state_dir: {args.cli_state_dir}",
        "registered_services: " + (", ".join(services.keys()) or "<none>"),
    ]
    lines.extend(
        line
        for service_key, service in services.items()
        for line in _doctor_service_lines(service_key, service)
    )
    if "feishu" in services:
        lines.append("next_steps:")
        lines.extend(f"- {step}" for step in _next_steps(services["feishu"]))
    return tuple(lines)


def _run_add_feishu(args: Namespace) -> int:
    _ensure_feishu_sdk_available(reason="Feishu setup")
    args.profile_dir.mkdir(parents=True, exist_ok=True)
    manifest = _load_profile_manifest(args.profile_dir)
    gateway_payload = _mapping_payload(manifest.get("gateway"), path="gateway")
    adapters_payload = _mapping_payload(gateway_payload.get("adapters"), path="gateway.adapters")
    feishu_payload = _mapping_payload(adapters_payload.get("feishu"), path="gateway.adapters.feishu")
    control_payload = _mapping_payload(feishu_payload.get("control"), path="gateway.adapters.feishu.control")

    account_id = str(args.account_id or DEFAULT_GATEWAY_ACCOUNT_ID).strip() or DEFAULT_GATEWAY_ACCOUNT_ID
    accounts_value = feishu_payload.get("accounts")
    if accounts_value is None:
        existing_accounts: list[dict[str, object]] = []
    elif isinstance(accounts_value, list):
        existing_accounts = []
        for index, account in enumerate(accounts_value):
            if not isinstance(account, Mapping):
                raise SystemExit(
                    f"gateway.adapters.feishu.accounts[{index}] must be a JSON object"
                )
            existing_accounts.append({str(key): value for key, value in account.items()})
    else:
        raise SystemExit("gateway.adapters.feishu.accounts must be a JSON array")

    existing_account = _find_feishu_account(existing_accounts, account_id=account_id)
    transport = (
        str(args.transport)
        if args.transport is not None
        else str(
            (existing_account or {}).get("surface")
            or feishu_payload.get("surface")
            or "long-connection"
        )
    )
    event_path = (
        str(args.event_path)
        if args.event_path is not None
        else str(
            (existing_account or {}).get("event_path")
            or feishu_payload.get("event_path")
            or DEFAULT_FEISHU_EVENT_PATH
        )
    )
    app_id_env_var = _resolved_feishu_secret_env_var(
        explicit_env_var=args.app_id_env_var,
        existing_account=existing_account,
        account_id=account_id,
        secret_key="app_id",
    )
    app_secret_env_var = _resolved_feishu_secret_env_var(
        explicit_env_var=args.app_secret_env_var,
        existing_account=existing_account,
        account_id=account_id,
        secret_key="app_secret",
    )
    app_id_value = str(args.app_id or "").strip()
    app_secret_value = str(args.app_secret or "").strip()
    enabled = bool(args.enabled) if args.enabled is not None else bool(feishu_payload.get("enabled") is True)
    default_clone_id = (
        str(args.default_clone_id).strip()
        if args.default_clone_id is not None
        else str(control_payload.get("default_clone_id") or "").strip()
    )
    auto_create_clone = bool(args.auto_create_clone) or bool(control_payload.get("auto_create_clone") is True)
    allow_group_chats = bool(args.allow_group_chats) or bool(control_payload.get("allow_group_chats") is True)

    use_wizard = bool(args.wizard) if args.wizard is not None else _interactive_shell_supported()
    if use_wizard:
        _print_gateway_feishu_wizard_intro()
        wizard_state = _run_interactive_feishu_wizard(
            account_id=account_id,
            transport=transport,
            event_path=event_path,
            app_id_env_var=app_id_env_var,
            app_secret_env_var=app_secret_env_var,
            app_id_value=app_id_value,
            app_secret_value=app_secret_value,
            enabled=enabled,
            default_clone_id=default_clone_id,
            auto_create_clone=auto_create_clone,
            allow_group_chats=allow_group_chats,
        )
        if wizard_state is None:
            _print_gateway_setup_paused()
            return 0
        account_id = wizard_state.account_id
        transport = wizard_state.transport
        event_path = wizard_state.event_path
        app_id_value = wizard_state.app_id_value
        app_secret_value = wizard_state.app_secret_value
        enabled = wizard_state.enabled
        default_clone_id = wizard_state.default_clone_id
        auto_create_clone = wizard_state.auto_create_clone
        allow_group_chats = wizard_state.allow_group_chats

    existing_account = _find_feishu_account(existing_accounts, account_id=account_id)
    app_id_env_var = _resolved_feishu_secret_env_var(
        explicit_env_var=args.app_id_env_var,
        existing_account=existing_account,
        account_id=account_id,
        secret_key="app_id",
    )
    app_secret_env_var = _resolved_feishu_secret_env_var(
        explicit_env_var=args.app_secret_env_var,
        existing_account=existing_account,
        account_id=account_id,
        secret_key="app_secret",
    )

    account_payload = {
        "account_id": account_id,
        "surface": transport,
        "event_path": event_path,
        "secret_references": [
            _build_feishu_secret_reference(
                account_id=account_id,
                secret_key="app_id",
                env_var=app_id_env_var,
            ),
            _build_feishu_secret_reference(
                account_id=account_id,
                secret_key="app_secret",
                env_var=app_secret_env_var,
            ),
        ],
    }
    feishu_payload["accounts"] = _upsert_feishu_account(existing_accounts, account_payload)
    feishu_payload["surface"] = transport
    feishu_payload["event_path"] = event_path
    feishu_payload["enabled"] = enabled

    if default_clone_id:
        control_payload["default_clone_id"] = default_clone_id
    elif use_wizard:
        control_payload.pop("default_clone_id", None)
    if auto_create_clone:
        control_payload["auto_create_clone"] = True
    elif use_wizard:
        control_payload.pop("auto_create_clone", None)
    if allow_group_chats:
        control_payload["allow_group_chats"] = True
    elif use_wizard:
        control_payload.pop("allow_group_chats", None)
    if control_payload:
        feishu_payload["control"] = control_payload
    else:
        feishu_payload.pop("control", None)

    adapters_payload["feishu"] = feishu_payload
    gateway_payload["adapters"] = adapters_payload
    manifest["gateway"] = gateway_payload
    manifest_path = write_profile_manifest(args.profile_dir, manifest)

    local_secret_path = _persist_gateway_local_secret_env(
        args.state_dir,
        {
            app_id_env_var: app_id_value,
            app_secret_env_var: app_secret_value,
        },
    )

    service = _build_service(args)
    print(f"Configured Feishu IM in {manifest_path}")
    print(f"Feishu account: {account_id}")
    print("Feishu enabled for `aegis im serve`: " + ("yes" if enabled else "no"))
    if local_secret_path is not None:
        print(f"Local IM secret file: {local_secret_path}")
        print("Raw Feishu credentials were stored locally outside profile.json.")
    print("next_steps:")
    for step in _next_steps(service):
        print(f"- {step}")
    print(f"- Start the configured bridge with `aegis im start --transport {transport}`.")
    if enabled:
        print("- Or mount every enabled HTTP gateway service with `aegis im serve`.")
    return 0


def _run_start(service, args: Namespace) -> int:
    transport = _resolve_feishu_transport_argument(args, service=service)

    if transport == "long-connection":
        _ensure_feishu_sdk_available(reason="Feishu long-connection startup")
    if args.detach:
        return _run_start_detached(args, transport=transport)

    if transport == "long-connection":
        account_label = args.account_id or "<default>"
        print("Starting Aegis IM Feishu long-connection transport")
        print(f"Feishu account: {account_label}")
        service.start_long_connection(account_id=args.account_id)
        return 0

    app = create_gateway_web_app({"feishu": service}, app=service.app)
    with make_server(args.host, args.port, app) as server:
        event_paths = ", ".join(service.event_paths) or "<none>"
        print(f"Serving Aegis IM on http://{args.host}:{args.port}")
        print(f"Feishu event paths: {event_paths}")
        server.serve_forever()
    return 0


def _run_serve(args: Namespace) -> int:
    app, services = _build_services(args)
    if not services:
        raise SystemExit("No gateway services are enabled in the active profile manifest.")
    web_app = create_gateway_web_app(services, app=app)
    with make_server(args.host, args.port, web_app) as server:
        print(f"Serving Aegis IM on http://{args.host}:{args.port}")
        for key, service in services.items():
            event_paths = ", ".join(getattr(service, "http_paths", ())) or "<none>"
            print(f"{key} event paths: {event_paths}")
        server.serve_forever()
    return 0


def _build_legacy_parser(*, defaults: dict[str, Path]) -> ArgumentParser:
    parser = ArgumentParser(description="Run the Aegis IM surface locally.")
    _add_feishu_start_options(parser)
    _add_common_gateway_options(parser, defaults=defaults)
    parser.add_argument(
        "--describe",
        action="store_true",
        help="Print the active Feishu IM configuration and exit.",
    )
    parser.add_argument(
        "--doctor",
        action="store_true",
        help="Inspect Feishu IM readiness and next steps.",
    )
    return parser


def legacy_main(
    argv: Sequence[str] | None = None,
    *,
    default_profile_dir: Path | None = None,
    default_state_dir: Path | None = None,
    default_control_profile_dir: Path | None = None,
    default_control_state_dir: Path | None = None,
) -> int:
    defaults = _resolved_defaults(
        default_profile_dir_override=default_profile_dir,
        default_state_dir_override=default_state_dir,
        default_control_profile_dir_override=default_control_profile_dir,
        default_control_state_dir_override=default_control_state_dir,
    )
    parser = _build_legacy_parser(defaults=defaults)
    args = parser.parse_args(list(argv) if argv is not None else None)
    service = _build_service(args)
    if args.describe:
        _print_json(_describe_payload(service))
        return 0
    if args.doctor:
        print("\n".join(_doctor_lines(service, args)))
        return 0
    return _run_start(service, args)


def command_main(
    argv: Sequence[str] | None = None,
    *,
    default_profile_dir: Path | None = None,
    default_state_dir: Path | None = None,
    default_control_profile_dir: Path | None = None,
    default_control_state_dir: Path | None = None,
) -> int:
    defaults = _resolved_defaults(
        default_profile_dir_override=default_profile_dir,
        default_state_dir_override=default_state_dir,
        default_control_profile_dir_override=default_control_profile_dir,
        default_control_state_dir_override=default_control_state_dir,
    )
    resolved_argv = list(argv) if argv is not None else list(sys.argv[1:])
    if not resolved_argv:
        resolved_argv = ["setup"]
    elif resolved_argv[0].startswith("-"):
        resolved_argv = ["add", "feishu", *resolved_argv]
    elif resolved_argv[0] in {"start", "status", "stop", "restart", "logs"}:
        resolved_argv = ["feishu", *resolved_argv]
    common = ArgumentParser(add_help=False)
    _add_common_gateway_options(common, defaults=defaults)

    parser = ArgumentParser(prog="aegis im", description="Operate the Aegis IM surfaces.")
    subparsers = parser.add_subparsers(dest="command")

    setup = subparsers.add_parser(
        "setup",
        parents=[common],
        help="Choose an IM surface and configure it interactively.",
    )
    setup.add_argument(
        "--default-clone-id",
        default="",
        help="Prefill which clone plain text should route to by default after setup.",
    )
    setup.set_defaults(command_action="setup")

    doctor = subparsers.add_parser(
        "doctor",
        parents=[common],
        help="Inspect all active IM services and next steps.",
    )
    doctor.set_defaults(command_action="doctor_all")

    describe = subparsers.add_parser(
        "describe",
        parents=[common],
        help="Print the active multi-service IM configuration as JSON.",
    )
    describe.set_defaults(command_action="describe_all")

    serve = subparsers.add_parser(
        "serve",
        parents=[common],
        help="Serve all enabled IM HTTP services in one process.",
    )
    _add_http_server_options(serve)
    serve.set_defaults(command_action="serve_all")

    add = subparsers.add_parser(
        "add",
        help="Write IM configuration into the active profile manifest.",
    )
    add_subparsers = add.add_subparsers(dest="add_command")
    add_feishu = add_subparsers.add_parser(
        "feishu",
        parents=[common],
        help="Add or update Feishu IM wiring in the active profile.",
    )
    _add_feishu_add_options(add_feishu)
    add_feishu.set_defaults(command_action="add_feishu")

    feishu = subparsers.add_parser("feishu", help="Operate the Feishu IM surface.")
    feishu_subparsers = feishu.add_subparsers(dest="feishu_command")

    feishu_start = feishu_subparsers.add_parser(
        "start",
        parents=[common],
        help="Start the Feishu IM server or long-connection transport.",
    )
    _add_feishu_start_options(feishu_start)
    feishu_start.set_defaults(command_action="start")

    feishu_status = feishu_subparsers.add_parser(
        "status",
        parents=[common],
        help="Inspect the detached Feishu runtime status.",
    )
    _add_feishu_status_options(feishu_status)
    feishu_status.set_defaults(command_action="status")

    feishu_stop = feishu_subparsers.add_parser(
        "stop",
        parents=[common],
        help="Stop the detached Feishu runtime for one transport.",
    )
    _add_feishu_stop_options(feishu_stop)
    feishu_stop.set_defaults(command_action="stop")

    feishu_restart = feishu_subparsers.add_parser(
        "restart",
        parents=[common],
        help="Restart the detached Feishu runtime for one transport.",
    )
    _add_feishu_restart_options(feishu_restart)
    feishu_restart.set_defaults(command_action="restart")

    feishu_logs = feishu_subparsers.add_parser(
        "logs",
        parents=[common],
        help="Inspect the detached Feishu IM process log.",
    )
    _add_feishu_logs_options(feishu_logs)
    feishu_logs.set_defaults(command_action="logs")

    feishu_describe = feishu_subparsers.add_parser(
        "describe",
        parents=[common],
        help="Print the active Feishu IM configuration as JSON.",
    )
    feishu_describe.set_defaults(command_action="describe")

    feishu_doctor = feishu_subparsers.add_parser(
        "doctor",
        parents=[common],
        help="Inspect Feishu IM readiness and next steps.",
    )
    feishu_doctor.set_defaults(command_action="doctor")

    args = parser.parse_args(resolved_argv)
    action = getattr(args, "command_action", None)
    if action is None:
        parser.print_help()
        return 2
    if action == "setup":
        return run_im_setup(
            default_clone_id=str(args.default_clone_id or "").strip(),
            default_profile_dir=args.profile_dir,
            default_state_dir=args.state_dir,
            default_control_profile_dir=args.cli_profile_dir,
            default_control_state_dir=args.cli_state_dir,
        )
    if action == "describe_all":
        app, services = _build_services(args)
        _print_json(_describe_services_payload(app, services))
        return 0
    if action == "doctor_all":
        app, services = _build_services(args)
        print("\n".join(_doctor_services_lines(app, services, args)))
        return 0
    if action == "serve_all":
        return _run_serve(args)
    if action == "add_feishu":
        return _run_add_feishu(args)

    service: FeishuGatewayService | None = None

    def ensure_service() -> FeishuGatewayService:
        nonlocal service
        if service is None:
            service = _build_service(args)
        return service

    if action == "describe":
        _print_json(_describe_payload(ensure_service()))
        return 0
    if action == "doctor":
        print("\n".join(_doctor_lines(ensure_service(), args)))
        return 0
    if action == "status":
        return _run_status(
            args,
            service=ensure_service() if args.transport == "configured" else None,
        )
    if action == "stop":
        return _run_stop(
            args,
            service=ensure_service() if args.transport == "configured" else None,
        )
    if action == "restart":
        return _run_restart(
            args,
            service=ensure_service() if args.transport == "configured" else None,
        )
    if action == "logs":
        return _run_logs(
            args,
            service=ensure_service() if args.transport == "configured" else None,
        )
    return _run_start(ensure_service(), args)


def run_im_setup(
    *,
    default_clone_id: str = "",
    default_profile_dir: Path | None = None,
    default_state_dir: Path | None = None,
    default_control_profile_dir: Path | None = None,
    default_control_state_dir: Path | None = None,
    prompt_title: str = "IM Setup",
    prompt_text: str = "Which IM should Aegis configure right now?",
    allow_skip: bool = False,
) -> int:
    answer = _gateway_wizard_choice_prompt(
        prompt_title,
        prompt_text,
        _im_setup_choices(allow_skip=allow_skip),
        default="skip" if allow_skip else "feishu",
        allow_back=not allow_skip,
    )
    if answer is GATEWAY_WIZARD_BACK or answer == "skip":
        return 0
    if answer != "feishu":
        raise SystemExit(f"Unsupported IM setup target: {answer}")
    argv = ["add", "feishu", "--wizard"]
    if default_clone_id:
        argv.extend(["--default-clone-id", default_clone_id])
    return command_main(
        argv,
        default_profile_dir=default_profile_dir,
        default_state_dir=default_state_dir,
        default_control_profile_dir=default_control_profile_dir,
        default_control_state_dir=default_control_state_dir,
    )


def main(
    argv: Sequence[str] | None = None,
    *,
    default_profile_dir: Path | None = None,
    default_state_dir: Path | None = None,
    default_control_profile_dir: Path | None = None,
    default_control_state_dir: Path | None = None,
) -> int:
    resolved_argv = list(argv) if argv is not None else list(sys.argv[1:])
    if not resolved_argv or resolved_argv[0] in {
        "setup",
        "doctor",
        "describe",
        "serve",
        "add",
        "feishu",
        "start",
        "status",
        "stop",
        "restart",
        "logs",
    }:
        return command_main(
            resolved_argv,
            default_profile_dir=default_profile_dir,
            default_state_dir=default_state_dir,
            default_control_profile_dir=default_control_profile_dir,
            default_control_state_dir=default_control_state_dir,
        )
    return legacy_main(
        resolved_argv,
        default_profile_dir=default_profile_dir,
        default_state_dir=default_state_dir,
        default_control_profile_dir=default_control_profile_dir,
        default_control_state_dir=default_control_state_dir,
    )


if __name__ == "__main__":
    raise SystemExit(main())
