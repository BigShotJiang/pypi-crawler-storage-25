"""Gateway application bootstrap."""

from .cli_control import (
    FeishuCliBinding,
    FeishuCliBindingStore,
    FeishuCliControlConfig,
    FeishuCliControlResult,
    FeishuCliControlService,
    load_feishu_cli_control_config,
)
from .feishu import (
    DEFAULT_FEISHU_APP_ID_ENV,
    DEFAULT_FEISHU_APP_SECRET_ENV,
    DEFAULT_FEISHU_EVENT_PATH,
    SUPPORTED_FEISHU_TRANSPORTS,
    FeishuGatewayAccountConfig,
    FeishuGatewayEventResult,
    FeishuGatewayService,
    build_feishu_gateway_service,
    load_feishu_gateway_accounts,
    register_feishu_gateway_service,
    resolve_feishu_account,
)
from .plugins import GatewayAdapterDescriptor, GatewayHttpService, GatewayPluginRegistry
from .runtime import (
    CHAT_BOT_ADAPTER_ID,
    FEISHU_ADAPTER_ID,
    TELEGRAM_ADAPTER_ID,
    WEBHOOK_ADAPTER_ID,
    ChatBotMessagingAdapter,
    FeishuMessagingAdapter,
    GatewayApp,
    GatewayVoiceExchange,
    TelegramMessagingAdapter,
    WebhookMessagingAdapter,
    build_gateway_app,
    register_builtin_gateway_adapters,
)
from .telegram import (
    DEFAULT_TELEGRAM_BASE_URL,
    DEFAULT_TELEGRAM_BOT_TOKEN_ENV,
    DEFAULT_TELEGRAM_EVENT_PATH,
    LEGACY_TELEGRAM_BOT_TOKEN_ENV,
    SUPPORTED_TELEGRAM_TRANSPORTS,
    TelegramGatewayAccountConfig,
    TelegramGatewayEventResult,
    TelegramGatewayService,
    TelegramResolvedAccount,
    build_telegram_gateway_service,
    load_telegram_gateway_accounts,
    register_telegram_gateway_service,
    resolve_telegram_account,
)
from .web import create_gateway_web_app


def build_gateway_plugin_registry() -> GatewayPluginRegistry:
    registry = GatewayPluginRegistry()
    register_builtin_gateway_adapters(registry)
    register_feishu_gateway_service(registry)
    register_telegram_gateway_service(registry)
    return registry


__all__ = [
    "CHAT_BOT_ADAPTER_ID",
    "DEFAULT_FEISHU_APP_ID_ENV",
    "DEFAULT_FEISHU_APP_SECRET_ENV",
    "DEFAULT_FEISHU_EVENT_PATH",
    "DEFAULT_TELEGRAM_BASE_URL",
    "DEFAULT_TELEGRAM_BOT_TOKEN_ENV",
    "DEFAULT_TELEGRAM_EVENT_PATH",
    "FEISHU_ADAPTER_ID",
    "FeishuCliBinding",
    "FeishuCliBindingStore",
    "FeishuCliControlConfig",
    "FeishuCliControlResult",
    "FeishuCliControlService",
    "FeishuGatewayAccountConfig",
    "FeishuGatewayEventResult",
    "FeishuGatewayService",
    "FeishuMessagingAdapter",
    "GatewayAdapterDescriptor",
    "GatewayApp",
    "GatewayHttpService",
    "GatewayPluginRegistry",
    "GatewayVoiceExchange",
    "LEGACY_TELEGRAM_BOT_TOKEN_ENV",
    "SUPPORTED_FEISHU_TRANSPORTS",
    "SUPPORTED_TELEGRAM_TRANSPORTS",
    "TELEGRAM_ADAPTER_ID",
    "TelegramGatewayAccountConfig",
    "TelegramGatewayEventResult",
    "TelegramGatewayService",
    "TelegramMessagingAdapter",
    "TelegramResolvedAccount",
    "WEBHOOK_ADAPTER_ID",
    "WebhookMessagingAdapter",
    "build_feishu_gateway_service",
    "build_gateway_app",
    "build_gateway_plugin_registry",
    "build_telegram_gateway_service",
    "ChatBotMessagingAdapter",
    "create_gateway_web_app",
    "load_feishu_cli_control_config",
    "load_feishu_gateway_accounts",
    "load_telegram_gateway_accounts",
    "register_builtin_gateway_adapters",
    "register_feishu_gateway_service",
    "register_telegram_gateway_service",
    "resolve_feishu_account",
    "resolve_telegram_account",
]
