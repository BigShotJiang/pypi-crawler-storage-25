"""Feishu transport bootstrap for the gateway surface."""

from __future__ import annotations

from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
import importlib.util
import json
import os
import time
from pathlib import Path
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen
from uuid import uuid4

from packages.gateway_core import (
    DEFAULT_GATEWAY_ACCOUNT_ID,
    GatewayExchange,
    GatewayInboundMessage,
    GatewayOutboundMessage,
)

from apps.provider_runtime import EnvironmentSecretStore, secret_reference_from_payload
from apps.runtime_layout import default_cli_state_dir, default_profile_dir
from packages.auth import AuthProfile, ProfileCredentialResolver, SecretReference

from .cli_control import (
    CliRuntimeFactory,
    FeishuCliBindingStore,
    FeishuCliControlService,
    load_feishu_cli_control_config,
)
from .runtime import FEISHU_ADAPTER_ID, FeishuMessagingAdapter, GatewayApp, build_gateway_app

DEFAULT_FEISHU_APP_ID_ENV = "AEGIS_FEISHU_APP_ID"
DEFAULT_FEISHU_APP_SECRET_ENV = "AEGIS_FEISHU_APP_SECRET"
LEGACY_FEISHU_APP_ID_ENV = "FEISHU_APP_ID"
LEGACY_FEISHU_APP_SECRET_ENV = "FEISHU_APP_SECRET"
DEFAULT_FEISHU_BASE_URL = "https://open.feishu.cn"
DEFAULT_FEISHU_EVENT_PATH = "/feishu/events"
DEFAULT_FEISHU_TOKEN_PATH = "/open-apis/auth/v3/tenant_access_token/internal"
SUPPORTED_FEISHU_TRANSPORTS = ("long-connection",)
FEISHU_SDK_PIP_SPEC = "lark-oapi>=1.5.3,<2"

HttpJsonRequester = Callable[[str, str, Mapping[str, object], Mapping[str, str]], Mapping[str, object]]
FeishuWSClientFactory = Callable[[Any, str, str, object, object | None], object]


def _mapping(value: object) -> Mapping[str, object] | None:
    return value if isinstance(value, Mapping) else None


def _normalize_path(value: str | None) -> str:
    text = str(value or DEFAULT_FEISHU_EVENT_PATH).strip() or DEFAULT_FEISHU_EVENT_PATH
    return text if text.startswith("/") else f"/{text}"


def _normalize_transport(value: str | None) -> str:
    normalized = str(value or "webhook").strip().lower().replace("_", "-")
    if normalized in {"long-connection", "longconnection", "websocket", "ws"}:
        return "long-connection"
    if normalized in {"event-subscription", "callback", "http", "webhook"}:
        return "webhook"
    raise ValueError("feishu transport must be one of long-connection, webhook")


def _normalize_configured_transport(value: str | None) -> str:
    normalized = str(value or "long-connection").strip().lower().replace("_", "-")
    if normalized in {"long-connection", "longconnection", "websocket", "ws"}:
        return "long-connection"
    if normalized in {"event-subscription", "callback", "http", "webhook"}:
        return "long-connection"
    raise ValueError("feishu configured transport must resolve to long-connection")


def _json_bytes(payload: Mapping[str, object]) -> bytes:
    return json.dumps(dict(payload), ensure_ascii=False).encode("utf-8")


def _default_json_request(
    method: str,
    url: str,
    payload: Mapping[str, object],
    headers: Mapping[str, str],
) -> Mapping[str, object]:
    request = Request(
        url,
        data=_json_bytes(payload),
        method=method.upper(),
        headers={
            "Content-Type": "application/json; charset=utf-8",
            "Accept": "application/json",
            "User-Agent": "aegis-gateway/feishu",
            **dict(headers),
        },
    )
    try:
        with urlopen(request, timeout=30) as response:
            raw = response.read().decode("utf-8")
    except HTTPError as exc:
        detail = exc.read().decode("utf-8")
        raise RuntimeError(
            f"feishu request failed with HTTP {exc.code}: {detail or exc.reason}"
        ) from exc
    except URLError as exc:
        raise RuntimeError(f"feishu request failed: {exc.reason}") from exc
    try:
        parsed = json.loads(raw or "{}")
    except json.JSONDecodeError as exc:
        raise RuntimeError("feishu request returned a non-JSON response") from exc
    if not isinstance(parsed, dict):
        raise RuntimeError("feishu request returned a non-object JSON response")
    if int(parsed.get("code", 0) or 0) != 0:
        raise RuntimeError(
            f"feishu request rejected: code={parsed.get('code')} msg={parsed.get('msg')}"
        )
    return parsed


def _lark_sdk_dependency_status() -> str:
    return "installed" if importlib.util.find_spec("lark_oapi") is not None else "missing_optional_dependency"


def _load_lark_sdk(lark_module: Any | None = None) -> Any:
    if lark_module is not None:
        return lark_module
    try:
        import lark_oapi as lark  # type: ignore[import-not-found]
    except ImportError as exc:  # pragma: no cover - exercised by integration path
        raise RuntimeError(
            "Feishu long-connection transport requires the bundled dependency "
            "'lark-oapi'. Reinstall Aegis or add the package to your environment if it is missing."
        ) from exc
    return lark


def _lark_log_level(lark_module: Any, level_name: str) -> object | None:
    log_levels = getattr(lark_module, "LogLevel", None)
    if log_levels is None:
        return None
    normalized = str(level_name or "INFO").strip().upper().replace("-", "_")
    return getattr(log_levels, normalized, None)


def _lark_event_payload(event: object, *, lark_module: Any) -> Mapping[str, object]:
    marshaled = getattr(getattr(lark_module, "JSON", None), "marshal", None)
    if not callable(marshaled):
        raise RuntimeError("lark_oapi.JSON.marshal is unavailable")
    raw = marshaled(event)
    try:
        parsed = json.loads(str(raw or "{}"))
    except json.JSONDecodeError as exc:
        raise RuntimeError("lark_oapi long-connection event was not valid JSON") from exc
    if not isinstance(parsed, Mapping):
        raise RuntimeError("lark_oapi long-connection event did not marshal to a JSON object")
    return parsed


def _default_ws_client_factory(
    lark_module: Any,
    app_id: str,
    app_secret: str,
    event_handler: object,
    log_level: object | None,
) -> object:
    ws_client = getattr(getattr(lark_module, "ws", None), "Client", None)
    if ws_client is None:
        raise RuntimeError("lark_oapi long-connection client is unavailable")
    return ws_client(
        app_id,
        app_secret,
        event_handler=event_handler,
        log_level=log_level,
    )


@dataclass(frozen=True, slots=True)
class FeishuGatewayAccountConfig:
    account_id: str = DEFAULT_GATEWAY_ACCOUNT_ID
    app_id_env_var: str = DEFAULT_FEISHU_APP_ID_ENV
    app_secret_env_var: str = DEFAULT_FEISHU_APP_SECRET_ENV
    secret_references: tuple[SecretReference, ...] = ()
    surface: str = "webhook"
    event_path: str = DEFAULT_FEISHU_EVENT_PATH
    base_url: str = DEFAULT_FEISHU_BASE_URL
    token_path: str = DEFAULT_FEISHU_TOKEN_PATH
    metadata: Mapping[str, object] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class FeishuResolvedAccount:
    account_id: str
    app_id: str
    app_secret: str
    config: FeishuGatewayAccountConfig


@dataclass(frozen=True, slots=True)
class FeishuGatewayEventResult:
    exchange: GatewayExchange | None
    response_body: Mapping[str, object]
    delivery_request: Mapping[str, object] | None = None
    delivery_response: Mapping[str, object] | None = None


@dataclass(slots=True)
class _FeishuTokenCacheEntry:
    token: str
    expires_at: float


def _feishu_secret_reference_from_payload(
    payload: Mapping[str, object],
    *,
    account_id: str,
) -> SecretReference:
    normalized_payload = dict(payload)
    secret_key = str(normalized_payload.get("secret_key") or "")
    if not secret_key:
        raise ValueError(
            f"feishu account '{account_id}' secret_references entries must declare secret_key"
        )
    normalized_payload.setdefault("provider_id", FEISHU_ADAPTER_ID)
    normalized_payload.setdefault("secret_name", secret_key)
    reference = secret_reference_from_payload(normalized_payload)
    if reference.provider_id != FEISHU_ADAPTER_ID:
        raise ValueError(
            f"feishu account '{account_id}' secret reference provider_id must be {FEISHU_ADAPTER_ID}"
        )
    return reference


def _secret_reference_env_alias(
    references: tuple[SecretReference, ...],
    secret_key: str,
) -> str | None:
    for reference in references:
        if reference.secret_key != secret_key:
            continue
        candidates = reference.env_var_candidates()
        if candidates:
            return candidates[0]
    return None


def _credential_env_vars(config: FeishuGatewayAccountConfig) -> tuple[str, ...]:
    if config.secret_references:
        return tuple(
            dict.fromkeys(
                env_var
                for reference in config.secret_references
                for env_var in reference.env_var_candidates()
            )
        )
    env_vars = [config.app_id_env_var, config.app_secret_env_var]
    return tuple(dict.fromkeys(value for value in env_vars if value))


def _feishu_account_profile(config: FeishuGatewayAccountConfig) -> AuthProfile:
    return AuthProfile(
        profile_id=f"gateway.feishu.{config.account_id}",
        provider_id=FEISHU_ADAPTER_ID,
        transport_id="gateway-feishu",
        auth_method="secret_reference",
        provider_kind="service",
        secret_references=config.secret_references,
        metadata={
            "surface": "gateway.feishu",
            "account_id": config.account_id,
        },
    )


def load_feishu_gateway_accounts(
    app: GatewayApp,
    *,
    respect_enabled: bool = True,
) -> tuple[FeishuGatewayAccountConfig, ...]:
    manifest = app.loaded_profile.manifest if app.loaded_profile is not None else {}
    gateway_payload = _mapping(manifest.get("gateway")) or {}
    adapters_payload = _mapping(gateway_payload.get("adapters")) or {}
    feishu_payload = _mapping(adapters_payload.get("feishu"))
    if respect_enabled and feishu_payload is not None and feishu_payload.get("enabled") is False:
        return ()

    default_surface = _normalize_configured_transport((feishu_payload or {}).get("surface"))
    default_event_path = _normalize_path((feishu_payload or {}).get("event_path"))
    default_base_url = str((feishu_payload or {}).get("base_url") or DEFAULT_FEISHU_BASE_URL)
    default_token_path = _normalize_path(
        (feishu_payload or {}).get("token_path") or DEFAULT_FEISHU_TOKEN_PATH
    )
    accounts_payload = (feishu_payload or {}).get("accounts")
    if isinstance(accounts_payload, list) and accounts_payload:
        resolved: list[FeishuGatewayAccountConfig] = []
        for index, account_payload in enumerate(accounts_payload):
            account_mapping = _mapping(account_payload)
            if account_mapping is None:
                raise ValueError("gateway.adapters.feishu.accounts entries must be JSON objects")
            account_id = str(account_mapping.get("account_id") or DEFAULT_GATEWAY_ACCOUNT_ID)
            env_payload = _mapping(account_mapping.get("env")) or {}
            secret_references_payload = account_mapping.get("secret_references")
            if secret_references_payload is None:
                secret_references = ()
            elif isinstance(secret_references_payload, list):
                secret_references = tuple(
                    _feishu_secret_reference_from_payload(item, account_id=account_id)
                    for item in secret_references_payload
                    if isinstance(item, Mapping)
                )
                if len(secret_references) != len(secret_references_payload):
                    raise ValueError(
                        f"feishu account '{account_id}' secret_references entries must be JSON objects"
                    )
            else:
                raise ValueError(
                    f"feishu account '{account_id}' secret_references must be a JSON array"
                )
            app_id_env_var = str(
                env_payload.get("app_id")
                or _secret_reference_env_alias(secret_references, "app_id")
                or ("" if secret_references else DEFAULT_FEISHU_APP_ID_ENV)
            )
            app_secret_env_var = str(
                env_payload.get("app_secret")
                or _secret_reference_env_alias(secret_references, "app_secret")
                or ("" if secret_references else DEFAULT_FEISHU_APP_SECRET_ENV)
            )
            resolved.append(
                FeishuGatewayAccountConfig(
                    account_id=account_id,
                    app_id_env_var=app_id_env_var,
                    app_secret_env_var=app_secret_env_var,
                    secret_references=secret_references,
                    surface=str(account_mapping.get("surface") or default_surface),
                    event_path=_normalize_path(account_mapping.get("event_path") or default_event_path),
                    base_url=str(account_mapping.get("base_url") or default_base_url),
                    token_path=_normalize_path(account_mapping.get("token_path") or default_token_path),
                    metadata={"manifest_index": index},
                )
            )
        return tuple(resolved)

    return (
        FeishuGatewayAccountConfig(
            event_path=default_event_path,
            surface=default_surface,
            base_url=default_base_url,
            token_path=default_token_path,
        ),
    )


def resolve_feishu_account(
    config: FeishuGatewayAccountConfig,
    *,
    environ: Mapping[str, str] | None = None,
) -> FeishuResolvedAccount:
    env = environ or os.environ
    if config.secret_references:
        credentials = ProfileCredentialResolver(EnvironmentSecretStore(env)).resolve(
            _feishu_account_profile(config)
        ).as_mapping()
        app_id = str(credentials.get("app_id") or "")
        app_secret = str(credentials.get("app_secret") or "")
        if not app_id or not app_secret:
            raise LookupError(
                f"feishu account '{config.account_id}' secret references must resolve app_id and app_secret"
            )
        return FeishuResolvedAccount(
            account_id=config.account_id,
            app_id=app_id,
            app_secret=app_secret,
            config=config,
        )

    app_id = str(env.get(config.app_id_env_var) or "")
    app_secret = str(env.get(config.app_secret_env_var) or "")
    if not app_id and config.app_id_env_var == DEFAULT_FEISHU_APP_ID_ENV:
        app_id = str(env.get(LEGACY_FEISHU_APP_ID_ENV) or "")
    if not app_secret and config.app_secret_env_var == DEFAULT_FEISHU_APP_SECRET_ENV:
        app_secret = str(env.get(LEGACY_FEISHU_APP_SECRET_ENV) or "")
    if not app_id or not app_secret:
        raise LookupError(
            f"feishu account '{config.account_id}' requires "
            f"{config.app_id_env_var} and {config.app_secret_env_var}"
        )
    return FeishuResolvedAccount(
        account_id=config.account_id,
        app_id=app_id,
        app_secret=app_secret,
        config=config,
    )


@dataclass(slots=True)
class FeishuGatewayService:
    app: GatewayApp
    account_configs: tuple[FeishuGatewayAccountConfig, ...] = ()
    http_requester: HttpJsonRequester = _default_json_request
    environ: Mapping[str, str] = field(default_factory=lambda: dict(os.environ))
    adapter: FeishuMessagingAdapter | None = None
    cli_runtime_factory: CliRuntimeFactory | None = None
    cli_binding_store: FeishuCliBindingStore | None = None
    cli_control: FeishuCliControlService | None = None
    default_cli_profile_dir: str | None = None
    default_cli_state_dir: str | None = None
    respect_enabled: bool = True
    _token_cache: dict[str, _FeishuTokenCacheEntry] = field(
        init=False,
        default_factory=dict,
        repr=False,
    )

    def __post_init__(self) -> None:
        if not self.account_configs:
            self.account_configs = load_feishu_gateway_accounts(
                self.app,
                respect_enabled=self.respect_enabled,
            )
        if self.adapter is None:
            self.adapter = FeishuMessagingAdapter(app=self.app)
        if self.cli_control is None and self.app.loaded_profile is not None:
            config = load_feishu_cli_control_config(self.app.loaded_profile.manifest)
            if config is not None:
                binding_store = self.cli_binding_store
                if binding_store is None:
                    state_root = self.app.state_dir
                    binding_path = (
                        None
                        if state_root is None
                        else os.path.join(state_root, "feishu-cli-bindings.json")
                    )
                    binding_store = FeishuCliBindingStore(
                        path=None if binding_path is None else Path(binding_path)
                    )
                self.cli_control = FeishuCliControlService(
                    config=self._resolved_cli_control_config(config),
                    runtime_factory=self.cli_runtime_factory,
                    binding_store=binding_store,
                )

    def _resolved_cli_control_config(self, config):
        profile_dir = config.profile_dir or self.default_cli_profile_dir or self.app.profile_dir
        if profile_dir is None:
            profile_dir = str(default_profile_dir(environ=self.environ))
        state_dir = config.state_dir or self.default_cli_state_dir or self._inferred_cli_state_dir()
        if state_dir is None:
            state_dir = str(default_cli_state_dir(environ=self.environ))
        return type(config)(
            profile_dir=profile_dir,
            state_dir=state_dir,
            default_clone_id=config.default_clone_id,
            auto_create_clone=config.auto_create_clone,
            allow_group_chats=config.allow_group_chats,
        )

    def _inferred_cli_state_dir(self) -> str | None:
        if self.app.state_dir is None:
            return None
        state_dir = Path(self.app.state_dir)
        if state_dir.name == "gateway" and state_dir.parent != state_dir:
            return str(state_dir.parent)
        return str(state_dir)

    @property
    def event_paths(self) -> tuple[str, ...]:
        return tuple(dict.fromkeys(config.event_path for config in self.account_configs))

    @property
    def http_paths(self) -> tuple[str, ...]:
        return self.event_paths

    def handle_http_event(
        self,
        payload: Mapping[str, object],
        *,
        path: str,
    ) -> tuple[str, Mapping[str, object]]:
        try:
            result = self.dispatch_event(payload, transport="webhook")
        except LookupError as exc:
            return "503 Service Unavailable", {"ok": False, "error": str(exc)}
        except ValueError as exc:
            return "400 Bad Request", {"ok": False, "error": str(exc)}
        except RuntimeError as exc:
            return "502 Bad Gateway", {"ok": False, "error": str(exc)}
        payload_body = dict(result.response_body)
        if result.delivery_request is not None:
            payload_body["delivery_request_path"] = result.delivery_request.get("path", "")
        return "200 OK", payload_body

    def describe(self) -> Mapping[str, object]:
        accounts: list[dict[str, object]] = []
        for config in self.account_configs:
            status = "configured"
            resolved_app_id: str | None = None
            try:
                resolved = resolve_feishu_account(config, environ=self.environ)
                resolved_app_id = resolved.app_id
            except LookupError:
                status = "missing_credentials"
            accounts.append(
                {
                    "account_id": config.account_id,
                    "surface": config.surface,
                    "event_path": config.event_path,
                    "app_id_env_var": config.app_id_env_var,
                    "app_secret_env_var": config.app_secret_env_var,
                    "credential_env_vars": _credential_env_vars(config),
                    "secret_reference_ids": tuple(
                        reference.reference_id for reference in config.secret_references
                    ),
                    "credentials_source": (
                        "secret_references" if config.secret_references else "environment"
                    ),
                    "credentials_status": status,
                    "resolved_app_id": resolved_app_id,
                }
            )
        configured_transport: str | None = None
        configured_transport_error: str | None = None
        try:
            configured_transport = self.configured_transport()
        except (LookupError, ValueError) as exc:
            configured_transport_error = str(exc)
        return {
            "adapter_id": FEISHU_ADAPTER_ID,
            "profile_id": self.app.profile_id,
            "workspace_id": self.app.workspace_id,
            "preferred_transport": "long-connection",
            "implemented_transports": (
                "python-sdk-long-connection",
            ),
            "configured_transport": configured_transport,
            "configured_transport_error": configured_transport_error,
            "sdk_dependency_status": _lark_sdk_dependency_status(),
            "event_paths": self.event_paths,
            "accounts": tuple(accounts),
            "control": (
                self.cli_control.describe()
                if self.cli_control is not None
                else {"enabled": True, "runtime": "cli-runtime", "runtime_status": "unavailable"}
            ),
        }

    def configured_transport(self) -> str:
        if not self.account_configs:
            return "long-connection"
        transports = tuple(
            dict.fromkeys(_normalize_transport(config.surface) for config in self.account_configs)
        )
        if len(transports) == 1:
            return transports[0]
        raise LookupError(
            "configured Feishu accounts use multiple transport surfaces; pass --transport explicitly"
        )

    def dispatch_event(
        self,
        payload: Mapping[str, object],
        *,
        account_id: str | None = None,
        transport: str | None = None,
    ) -> FeishuGatewayEventResult:
        challenge = payload.get("challenge")
        if challenge is not None and payload.get("event") is None:
            return FeishuGatewayEventResult(
                exchange=None,
                response_body={"ok": True, "challenge": str(challenge)},
            )

        account = self._match_account(payload, account_id=account_id)
        resolved_transport = _normalize_transport(transport or account.config.surface)
        response_body = self._base_response_body(transport=resolved_transport)
        if self.cli_control is not None:
            return self._dispatch_cli_control(
                payload,
                account=account,
                transport=resolved_transport,
                response_body=response_body,
            )
        return self._dispatch_shared_runtime(
            payload,
            account=account,
            transport=resolved_transport,
            response_body=response_body,
        )

    def _base_response_body(self, *, transport: str) -> dict[str, object]:
        return {
            "ok": True,
            "adapter_id": FEISHU_ADAPTER_ID,
            "transport": transport,
        }

    def _dispatch_cli_control(
        self,
        payload: Mapping[str, object],
        *,
        account: FeishuResolvedAccount,
        transport: str,
        response_body: Mapping[str, object],
    ) -> FeishuGatewayEventResult:
        assert self.adapter is not None
        assert self.cli_control is not None
        inbound = self.adapter.normalize_event(
            payload,
            account_id=account.account_id,
            transport=transport,
        )
        result = self.cli_control.handle_message(inbound)
        enriched_response = {
            **dict(response_body),
            "account_id": inbound.account_id,
            "conversation_id": inbound.conversation_id,
            "control_mode": "cli-runtime",
            "delivery_outcome": "ignored" if result.body is None else "delivered",
            "summary": result.summary or "",
        }
        if result.clone_id is not None:
            enriched_response["clone_id"] = result.clone_id
        if result.session_id is not None:
            enriched_response["session_id"] = result.session_id
        if result.body is None:
            return FeishuGatewayEventResult(exchange=None, response_body=enriched_response)
        outbound = self._build_control_outbound(inbound, body=result.body, session_id=result.session_id)
        return self._deliver_outbound_result(
            account,
            outbound,
            exchange=None,
            response_body=enriched_response,
        )

    def _dispatch_shared_runtime(
        self,
        payload: Mapping[str, object],
        *,
        account: FeishuResolvedAccount,
        transport: str,
        response_body: Mapping[str, object],
    ) -> FeishuGatewayEventResult:
        assert self.adapter is not None
        exchange = self.adapter.receive_event(
            payload,
            account_id=account.account_id,
            transport=transport,
        )
        enriched_response = {
            **dict(response_body),
            "account_id": exchange.route.inbound.account_id,
            "conversation_id": exchange.route.inbound.conversation_id,
            "session_id": exchange.route.session.session_id,
            "policy_decision": str(exchange.delivery.policy_result.decision),
            "delivery_outcome": exchange.delivery.outcome,
        }
        if exchange.delivery.outbound is None:
            enriched_response["summary"] = exchange.delivery.summary
            return FeishuGatewayEventResult(exchange=exchange, response_body=enriched_response)
        return self._deliver_outbound_result(
            account,
            exchange.delivery.outbound,
            exchange=exchange,
            response_body=enriched_response,
        )

    def _deliver_outbound_result(
        self,
        account: FeishuResolvedAccount,
        outbound: GatewayOutboundMessage,
        *,
        exchange: GatewayExchange | None,
        response_body: Mapping[str, object],
    ) -> FeishuGatewayEventResult:
        assert self.adapter is not None
        delivery_request = self.adapter.build_reply_request(outbound)
        delivery_response = self._send_outbound(account, outbound, delivery_request)
        enriched_response = {
            **dict(response_body),
            "external_message_id": self._external_message_id(delivery_response),
        }
        return FeishuGatewayEventResult(
            exchange=exchange,
            response_body=enriched_response,
            delivery_request=delivery_request,
            delivery_response=delivery_response,
        )

    def _external_message_id(self, response: Mapping[str, object]) -> str:
        data = _mapping(response.get("data")) or {}
        return str(data.get("message_id") or "")

    def build_long_connection_client(
        self,
        *,
        account_id: str | None = None,
        lark_module: Any | None = None,
        client_factory: FeishuWSClientFactory = _default_ws_client_factory,
        log_level: str = "INFO",
    ) -> object:
        if account_id is None and len(self.account_configs) != 1:
            raise LookupError(
                "long-connection mode requires --account-id when multiple Feishu accounts are configured"
            )
        account = self._match_account({}, account_id=account_id)
        lark = _load_lark_sdk(lark_module)
        handler = self._build_long_connection_handler(
            account=account,
            lark_module=lark,
            log_level=log_level,
        )
        return client_factory(
            lark,
            account.app_id,
            account.app_secret,
            handler,
            _lark_log_level(lark, log_level),
        )

    def start_long_connection(
        self,
        *,
        account_id: str | None = None,
        lark_module: Any | None = None,
        client_factory: FeishuWSClientFactory = _default_ws_client_factory,
        log_level: str = "INFO",
    ) -> object:
        client = self.build_long_connection_client(
            account_id=account_id,
            lark_module=lark_module,
            client_factory=client_factory,
            log_level=log_level,
        )
        start = getattr(client, "start", None)
        if not callable(start):
            raise RuntimeError("feishu long-connection client does not expose start()")
        start()
        return client

    def _build_control_outbound(
        self,
        inbound: GatewayInboundMessage,
        *,
        body: str,
        session_id: str | None,
    ) -> GatewayOutboundMessage:
        return GatewayOutboundMessage(
            message_id=f"feishu-control:{session_id or inbound.conversation_id}:{uuid4().hex[:12]}",
            account=inbound.account,
            conversation=inbound.conversation,
            session_id=session_id or f"control:{inbound.conversation_id}",
            body=body,
            reply_to_message_id=inbound.event_id,
            attachment_refs=(),
            metadata={
                **dict(inbound.metadata),
                "delivery_surface": inbound.account.surface or "feishu-control",
                "runtime_surface": "cli-runtime",
            },
        )

    def _build_long_connection_handler(
        self,
        *,
        account: FeishuResolvedAccount,
        lark_module: Any,
        log_level: str,
    ) -> object:
        dispatcher = getattr(lark_module, "EventDispatcherHandler", None)
        if dispatcher is None or not hasattr(dispatcher, "builder"):
            raise RuntimeError("lark_oapi EventDispatcherHandler builder is unavailable")

        def _handle_message(event: object) -> None:
            payload = _lark_event_payload(event, lark_module=lark_module)
            self.dispatch_event(
                payload,
                account_id=account.account_id,
                transport="long-connection",
            )

        builder = dispatcher.builder("", "", _lark_log_level(lark_module, log_level))
        builder = builder.register_p2_im_message_receive_v1(_handle_message)
        return builder.build()

    def _match_account(
        self,
        payload: Mapping[str, object],
        *,
        account_id: str | None = None,
    ) -> FeishuResolvedAccount:
        if not self.account_configs:
            raise LookupError("no Feishu gateway accounts are configured")
        if account_id is not None:
            for config in self.account_configs:
                if config.account_id == account_id:
                    return resolve_feishu_account(config, environ=self.environ)
            raise LookupError(f"unknown Feishu gateway account: {account_id}")

        header_payload = _mapping(payload.get("header")) or {}
        event_app_id = str(header_payload.get("app_id") or "")
        if event_app_id:
            matches: list[FeishuResolvedAccount] = []
            for config in self.account_configs:
                try:
                    resolved = resolve_feishu_account(config, environ=self.environ)
                except LookupError:
                    continue
                if resolved.app_id == event_app_id:
                    matches.append(resolved)
            if len(matches) == 1:
                return matches[0]

        if len(self.account_configs) == 1:
            return resolve_feishu_account(self.account_configs[0], environ=self.environ)
        raise LookupError("could not match Feishu event to a configured gateway account")

    def _tenant_access_token(self, account: FeishuResolvedAccount) -> str:
        cached = self._token_cache.get(account.account_id)
        now = time.time()
        if cached is not None and cached.expires_at - 60 > now:
            return cached.token
        response = self.http_requester(
            "POST",
            f"{account.config.base_url}{account.config.token_path}",
            {
                "app_id": account.app_id,
                "app_secret": account.app_secret,
            },
            {},
        )
        token = str(response.get("tenant_access_token") or "")
        if not token:
            raise RuntimeError("feishu token response did not include tenant_access_token")
        expires_in = int(response.get("expire", 7200) or 7200)
        self._token_cache[account.account_id] = _FeishuTokenCacheEntry(
            token=token,
            expires_at=now + expires_in,
        )
        return token

    def _send_outbound(
        self,
        account: FeishuResolvedAccount,
        outbound: GatewayOutboundMessage,
        delivery_request: Mapping[str, object],
    ) -> Mapping[str, object]:
        path = str(delivery_request.get("path") or "")
        method = str(delivery_request.get("method") or "POST")
        body = _mapping(delivery_request.get("body"))
        if not path or body is None:
            raise RuntimeError("feishu delivery request is missing a path or body payload")
        token = self._tenant_access_token(account)
        return self.http_requester(
            method,
            f"{account.config.base_url}{path}",
            body,
            {"Authorization": f"Bearer {token}"},
        )


def register_feishu_gateway_service(registry: GatewayPluginRegistry) -> GatewayPluginRegistry:
    registry.register_service(
        "feishu",
        factory=lambda app, **kwargs: FeishuGatewayService(app=app, **kwargs),
        enabled_by_default=True,
    )
    return registry


def build_feishu_gateway_service(
    *,
    profile_id: str = "profile:default",
    workspace_id: str | None = None,
    provider_profile: Mapping[str, Any] | None = None,
    profile_dir: str | None = None,
    state_dir: str | None = None,
    default_cli_profile_dir: str | Path | None = None,
    default_cli_state_dir: str | Path | None = None,
    environ: Mapping[str, str] | None = None,
    http_requester: HttpJsonRequester = _default_json_request,
    plugin_registry: GatewayPluginRegistry | None = None,
) -> FeishuGatewayService:
    app, _, _ = build_gateway_app(
        profile_id=profile_id,
        workspace_id=workspace_id,
        provider_profile=provider_profile,
        profile_dir=profile_dir,
        state_dir=state_dir,
        plugin_registry=plugin_registry,
    )
    return FeishuGatewayService(
        app=app,
        http_requester=http_requester,
        environ=dict(environ or os.environ),
        default_cli_profile_dir=(
            None if default_cli_profile_dir is None else str(Path(default_cli_profile_dir))
        ),
        default_cli_state_dir=(
            None if default_cli_state_dir is None else str(Path(default_cli_state_dir))
        ),
    )


def create_gateway_web_app(service: FeishuGatewayService):
    return create_gateway_http_app(service, app=service.app)


__all__ = [
    "DEFAULT_FEISHU_APP_ID_ENV",
    "DEFAULT_FEISHU_APP_SECRET_ENV",
    "LEGACY_FEISHU_APP_ID_ENV",
    "LEGACY_FEISHU_APP_SECRET_ENV",
    "DEFAULT_FEISHU_EVENT_PATH",
    "DEFAULT_FEISHU_BASE_URL",
    "DEFAULT_FEISHU_TOKEN_PATH",
    "SUPPORTED_FEISHU_TRANSPORTS",
    "FeishuGatewayAccountConfig",
    "FeishuGatewayEventResult",
    "FeishuGatewayService",
    "FeishuResolvedAccount",
    "build_feishu_gateway_service",
    "create_gateway_web_app",
    "load_feishu_gateway_accounts",
    "register_feishu_gateway_service",
    "resolve_feishu_account",
]
