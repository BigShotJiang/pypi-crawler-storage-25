"""Workspace-local built-in tool handlers."""

from __future__ import annotations

import ast
from collections.abc import Mapping
from contextlib import contextmanager, redirect_stdout
import io
import json
from pathlib import Path
import shutil
import signal
import subprocess
import threading
from typing import Any

from .handler_support import (
    coerce_bool,
    coerce_env,
    coerce_int,
    join_parts,
    optional_string,
    resolve_workspace_path,
    tool_summary,
    truncate,
)
from .runtime import ToolInvocation, ToolRuntime
from .surfaces import BuiltinToolDependencies, InMemoryProcessManager, ManagedProcess


def run_terminal_exec(
    invocation: ToolInvocation,
    *,
    dependencies: BuiltinToolDependencies,
) -> Mapping[str, Any]:
    command = str(invocation.arguments.get("command") or "").strip()
    if not command:
        raise ValueError("tool.terminal.exec requires a 'command' argument")
    cwd = resolve_workspace_path(
        dependencies.cwd,
        optional_string(invocation.arguments.get("cwd")),
        must_exist=True,
    )
    env = coerce_env(invocation.arguments.get("env"))
    background = coerce_bool(invocation.arguments.get("background"), default=False)
    if background:
        managed = dependencies.process_manager.start(command=command, cwd=cwd, env=env)
        return tool_summary(
            invocation,
            "\n".join(
                [
                    f"process_id: {managed.process_id}",
                    "status: running",
                    f"cwd: {managed.cwd}",
                    f"command: {managed.command}",
                ]
            ),
            side_effects=("terminal", "process"),
        )
    timeout_seconds = max(1, min(coerce_int(invocation.arguments.get("timeout_seconds"), default=20), 120))
    completed = subprocess.run(
        command,
        shell=True,
        cwd=cwd,
        env={**env} if env else None,
        capture_output=True,
        text=True,
        timeout=timeout_seconds,
    )
    body = join_parts(completed.stdout, completed.stderr)
    summary = truncate(body) or f"command exited with status {completed.returncode}"
    if completed.returncode != 0:
        raise RuntimeError(summary)
    return tool_summary(invocation, summary, side_effects=("terminal", "workspace"))


def run_process_action(invocation: ToolInvocation, *, manager: InMemoryProcessManager) -> Mapping[str, Any]:
    action = str(invocation.arguments.get("action") or "").strip().lower()
    if not action:
        raise ValueError("tool.process.manage requires an 'action' argument")
    if action in {"list", "ls"}:
        processes = manager.list()
        lines = [
            f"{process.process_id} | {'running' if process.running else f'exited({process.returncode})'} | {process.command}"
            for process in processes
        ] or ["<empty>"]
        return tool_summary(invocation, "\n".join(lines), side_effects=("process",))
    process_id = optional_string(invocation.arguments.get("process_id"))
    if process_id is None:
        raise ValueError(f"tool.process.manage action={action!r} requires 'process_id'")
    if action in {"poll", "inspect"}:
        managed = manager.capture_if_finished(process_id)
        return tool_summary(invocation, _process_summary(managed), side_effects=("process",))
    if action == "wait":
        managed = manager.wait(
            process_id,
            timeout_seconds=max(1, min(coerce_int(invocation.arguments.get("timeout_seconds"), default=20), 120)),
        )
        return tool_summary(invocation, _process_summary(managed), side_effects=("process",))
    if action == "write":
        data = str(invocation.arguments.get("input") or "")
        manager.write(process_id, data)
        managed = manager.get(process_id)
        return tool_summary(
            invocation,
            (
                f"process_id: {managed.process_id}\n"
                f"status: {'running' if managed.running else 'finished'}\n"
                f"input_written: {len(data)} bytes"
            ),
            side_effects=("process",),
        )
    if action == "kill":
        managed = manager.kill(process_id)
        return tool_summary(invocation, _process_summary(managed), side_effects=("process",))
    raise ValueError(f"tool.process.manage does not support action={action!r}")


def run_file_read(invocation: ToolInvocation, *, cwd: Path) -> Mapping[str, Any]:
    raw_path = optional_string(invocation.arguments.get("path"))
    if raw_path is None:
        raise ValueError("tool.file.read requires a 'path' argument")
    path = resolve_workspace_path(cwd, raw_path, must_exist=True)
    if not path.is_file():
        raise ValueError(f"tool.file.read requires a file path: {raw_path}")
    content = path.read_text(encoding="utf-8", errors="replace")
    start_line = max(1, coerce_int(invocation.arguments.get("start_line"), default=1))
    requested_end = coerce_int(invocation.arguments.get("end_line"), default=0)
    lines = content.splitlines()
    end_line = requested_end if requested_end > 0 else len(lines)
    if end_line < start_line:
        raise ValueError("tool.file.read requires end_line >= start_line")
    selected = lines[start_line - 1 : end_line]
    numbered = "\n".join(f"{index}. {line}" for index, line in enumerate(selected, start=start_line))
    return tool_summary(
        invocation,
        truncate(f"path: {path}\n{numbered}", limit=4000),
        side_effects=("file", "read"),
    )


def run_file_write(invocation: ToolInvocation, *, cwd: Path) -> Mapping[str, Any]:
    raw_path = optional_string(invocation.arguments.get("path"))
    content = invocation.arguments.get("content")
    if raw_path is None or content is None:
        raise ValueError("tool.file.write requires 'path' and 'content'")
    create_parents = coerce_bool(invocation.arguments.get("create_parents"), default=False)
    path = resolve_workspace_path(cwd, raw_path, must_exist=False)
    if create_parents:
        path.parent.mkdir(parents=True, exist_ok=True)
    mode = str(invocation.arguments.get("mode") or "overwrite").strip().lower()
    if mode not in {"overwrite", "append"}:
        raise ValueError("tool.file.write mode must be overwrite or append")
    if mode == "append" and path.exists():
        existing = path.read_text(encoding="utf-8", errors="replace")
        path.write_text(existing + str(content), encoding="utf-8")
    else:
        path.write_text(str(content), encoding="utf-8")
    return tool_summary(
        invocation,
        f"path: {path}\nmode: {mode}\nbytes: {len(str(content).encode('utf-8'))}",
        side_effects=("file", "write"),
    )


def run_file_patch(invocation: ToolInvocation, *, cwd: Path) -> Mapping[str, Any]:
    raw_path = optional_string(invocation.arguments.get("path"))
    search = invocation.arguments.get("search")
    replace_with = invocation.arguments.get("replace")
    if raw_path is None or search is None or replace_with is None:
        raise ValueError("tool.file.patch requires 'path', 'search', and 'replace'")
    path = resolve_workspace_path(cwd, raw_path, must_exist=True)
    content = path.read_text(encoding="utf-8", errors="replace")
    search_text = str(search)
    if search_text not in content:
        raise ValueError(f"tool.file.patch could not find the requested text in {path}")
    replace_all = coerce_bool(invocation.arguments.get("replace_all"), default=False)
    count = content.count(search_text)
    updated = content.replace(search_text, str(replace_with), -1 if replace_all else 1)
    path.write_text(updated, encoding="utf-8")
    replaced = count if replace_all else 1
    return tool_summary(
        invocation,
        f"path: {path}\nreplacements: {replaced}\nmode: {'all' if replace_all else 'first'}",
        side_effects=("file", "patch"),
    )


def run_file_search(invocation: ToolInvocation, *, cwd: Path) -> Mapping[str, Any]:
    query = str(invocation.arguments.get("query") or "").strip()
    if not query:
        raise ValueError("tool.file.search requires a 'query' argument")
    rg_path = shutil.which("rg")
    if rg_path is None:
        raise RuntimeError("tool.file.search requires rg to be installed")
    raw_path = optional_string(invocation.arguments.get("path"))
    search_root = resolve_workspace_path(cwd, raw_path, must_exist=True) if raw_path is not None else cwd.resolve()
    limit = max(1, min(coerce_int(invocation.arguments.get("limit"), default=20), 200))
    command = [rg_path, "-n", "--no-heading", "--smart-case", "--max-count", str(limit), query, str(search_root)]
    glob = optional_string(invocation.arguments.get("glob"))
    if glob is not None:
        command[1:1] = ["-g", glob]
    completed = subprocess.run(
        command,
        cwd=cwd,
        capture_output=True,
        text=True,
        timeout=20,
    )
    body = completed.stdout.strip() or completed.stderr.strip()
    if completed.returncode not in {0, 1}:
        raise RuntimeError(body or f"file search failed with status {completed.returncode}")
    summary = truncate(body) or f"no file matches for query: {query}"
    return tool_summary(invocation, summary, side_effects=("file", "search"))


def run_code_execute(
    invocation: ToolInvocation,
    *,
    runtime: ToolRuntime,
    allowlist: tuple[str, ...],
) -> Mapping[str, Any]:
    code = str(invocation.arguments.get("code") or "")
    if not code.strip():
        raise ValueError("tool.code.execute requires a 'code' argument")
    _validate_python_snippet(code)
    timeout_seconds = max(1, min(coerce_int(invocation.arguments.get("timeout_seconds"), default=10), 30))
    stdout = io.StringIO()

    def _tool_rpc(tool_id: str, arguments: Mapping[str, Any] | None = None, /, **kwargs: Any) -> Mapping[str, Any]:
        if tool_id not in allowlist:
            raise RuntimeError(f"tool RPC is not allowed for {tool_id}")
        payload = dict(arguments or {})
        payload.update(kwargs)
        result = runtime.invoke(tool_id, payload, session_id=invocation.session_id)
        return {
            "execution_id": result.execution_id,
            "outcome": result.outcome,
            "summary": result.summary,
            "side_effects": result.side_effects,
        }

    globals_dict = {
        "__builtins__": _safe_python_builtins(),
        "json": json,
        "tool": _tool_rpc,
    }
    locals_dict: dict[str, Any] = {}
    try:
        with _python_execution_timeout(timeout_seconds), redirect_stdout(stdout):
            exec(compile(code, "<aegis-tool-code>", "exec"), globals_dict, locals_dict)  # noqa: S102
    except TimeoutError as exc:
        raise RuntimeError(f"tool.code.execute timed out after {timeout_seconds} seconds") from exc
    output = stdout.getvalue().strip()
    result_value = locals_dict.get("result")
    if output and result_value is not None:
        summary = f"{output}\nresult={result_value!r}"
    elif result_value is not None:
        summary = repr(result_value)
    else:
        summary = output or "code executed successfully"
    return tool_summary(
        invocation,
        truncate(summary, limit=2000),
        side_effects=("code", "python"),
    )


def _validate_python_snippet(code: str) -> None:
    tree = ast.parse(code, mode="exec")
    blocked_names = {
        "__import__",
        "breakpoint",
        "compile",
        "eval",
        "exec",
        "globals",
        "help",
        "input",
        "locals",
        "open",
        "vars",
    }
    for node in ast.walk(tree):
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            raise ValueError("tool.code.execute does not allow imports")
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in blocked_names:
            raise ValueError(f"tool.code.execute does not allow {node.func.id}()")
        if isinstance(node, ast.Attribute) and node.attr.startswith("__"):
            raise ValueError("tool.code.execute does not allow dunder attribute access")


def _safe_python_builtins() -> dict[str, Any]:
    return {
        "abs": abs,
        "all": all,
        "any": any,
        "bool": bool,
        "dict": dict,
        "enumerate": enumerate,
        "float": float,
        "int": int,
        "len": len,
        "list": list,
        "max": max,
        "min": min,
        "print": print,
        "range": range,
        "repr": repr,
        "round": round,
        "set": set,
        "sorted": sorted,
        "str": str,
        "sum": sum,
        "tuple": tuple,
        "zip": zip,
    }


@contextmanager
def _python_execution_timeout(timeout_seconds: int):
    if timeout_seconds <= 0 or threading.current_thread() is not threading.main_thread():
        yield
        return
    if not hasattr(signal, "SIGALRM") or not hasattr(signal, "setitimer") or not hasattr(signal, "getitimer"):
        yield
        return

    def _raise_timeout(signum: int, frame: Any) -> None:  # noqa: ARG001
        raise TimeoutError("python execution timed out")

    previous_handler = signal.getsignal(signal.SIGALRM)
    previous_timer = signal.getitimer(signal.ITIMER_REAL)
    signal.signal(signal.SIGALRM, _raise_timeout)
    signal.setitimer(signal.ITIMER_REAL, float(timeout_seconds))
    try:
        yield
    finally:
        signal.setitimer(signal.ITIMER_REAL, *previous_timer)
        signal.signal(signal.SIGALRM, previous_handler)


def _process_summary(process: ManagedProcess) -> str:
    status = "running" if process.running else f"exited({process.returncode})"
    output = join_parts(process.stdout, process.stderr)
    lines = [
        f"process_id: {process.process_id}",
        f"status: {status}",
        f"cwd: {process.cwd}",
        f"command: {process.command}",
    ]
    if output:
        lines.append("output:")
        lines.append(truncate(output, limit=2000))
    return "\n".join(lines)


__all__ = [
    "run_code_execute",
    "run_file_patch",
    "run_file_read",
    "run_file_search",
    "run_file_write",
    "run_process_action",
    "run_terminal_exec",
]
