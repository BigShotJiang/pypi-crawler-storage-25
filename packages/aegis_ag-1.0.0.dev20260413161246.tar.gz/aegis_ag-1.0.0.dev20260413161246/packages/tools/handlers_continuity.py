"""Continuity-native built-in tool handlers."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from packages.contracts.runtime import ExecutionResult, GoalNode, MemoryRecord
from packages.cron import CronRuntime
from packages.profile import friend_profile_updates, merge_friend_profile_text

from .handler_support import (
    coerce_bool,
    coerce_int,
    coerce_optional_bool,
    optional_string,
    tool_summary,
    truncate,
)
from .runtime import ToolInvocation
from .surfaces import (
    CompanionManagementSurface,
    GoalManagementSurface,
    MemoryManagementSurface,
    SkillManagementSurface,
    TodoItem,
    TodoStore,
)


def run_goal_action(invocation: ToolInvocation, *, surface: GoalManagementSurface | None) -> Mapping[str, Any]:
    if surface is None:
        raise RuntimeError("goal management is not configured for this runtime")
    session_id = invocation.session_id
    requested_action = str(invocation.arguments.get("action") or "").strip().lower()
    title = str(invocation.arguments.get("title") or "").strip()
    goal_id = str(invocation.arguments.get("goal_id") or "").strip()
    parent_goal_id = (
        str(invocation.arguments.get("parent_goal_id"))
        if invocation.arguments.get("parent_goal_id") is not None
        else None
    )
    if requested_action:
        action = requested_action
    elif title and parent_goal_id:
        action = "create"
    elif title and not goal_id:
        action = "create"
    else:
        action = "update"
    if action in {"list", "ls"}:
        goals = surface.inspect_goals(session_id)
        summary = "\n".join(_goal_line(goal) for goal in goals[:12]) or "No durable goals are tracked for this session."
        return tool_summary(invocation, summary, side_effects=("goal", "state"))
    if action == "inspect":
        if not goal_id:
            raise ValueError("tool.goal.manage inspect requires a 'goal_id' argument")
        goal = surface.inspect_goal(session_id, goal_id)
        return tool_summary(invocation, _goal_line(goal), side_effects=("goal", "state"))
    if action == "create":
        if not title:
            raise ValueError("tool.goal.manage create requires a 'title' argument")
        resolved_parent_goal_id = parent_goal_id
        if resolved_parent_goal_id is None and goal_id and _goal_exists(surface, session_id, goal_id):
            resolved_parent_goal_id = goal_id
        goal = surface.create_goal(
            session_id,
            title=title,
            status=str(invocation.arguments.get("status") or "active"),
            priority=str(invocation.arguments.get("priority") or "medium"),
            owner=str(invocation.arguments.get("owner") or "shared"),
            parent_goal_id=resolved_parent_goal_id,
            dependency_refs=invocation.arguments.get("dependency_refs"),
            evidence_refs=invocation.arguments.get("evidence_refs"),
            related_memory_ids=invocation.arguments.get("related_memory_ids"),
            review_checkpoint=optional_string(invocation.arguments.get("review_checkpoint")),
            deadline=invocation.arguments.get("deadline"),
            time_sensitivity=optional_string(invocation.arguments.get("time_sensitivity")),
            reason=optional_string(invocation.arguments.get("reason")),
            activate=coerce_optional_bool(invocation.arguments.get("activate")),
        )
        return tool_summary(
            invocation,
            f"Created durable goal: {_goal_line(goal)}",
            side_effects=("goal", "state"),
        )
    if not goal_id:
        raise ValueError("tool.goal.manage requires a 'goal_id' argument unless action=create|list")
    if action == "delete":
        before, after = surface.delete_goal(
            session_id,
            goal_id,
            reason=str(invocation.arguments.get("reason") or "tool deleted goal"),
        )
        return tool_summary(
            invocation,
            f"Deleted durable goal: {_goal_line(before)} -> {_goal_line(after)}",
            side_effects=("goal", "state"),
        )
    forced_status = {
        "focus": "active",
        "complete": "completed",
        "block": "blocked",
        "defer": "deferred",
    }.get(action)
    before, after, reason = surface.update_goal(
        session_id,
        goal_id,
        title=optional_string(invocation.arguments.get("title")),
        status=forced_status if forced_status is not None else optional_string(invocation.arguments.get("status")),
        priority=optional_string(invocation.arguments.get("priority")),
        reason=optional_string(invocation.arguments.get("reason")),
    )
    return tool_summary(
        invocation,
        f"{reason}: {_goal_line(before)} -> {_goal_line(after)}",
        side_effects=("goal", "state"),
    )


def run_memory_action(
    invocation: ToolInvocation,
    *,
    surface: MemoryManagementSurface | None,
) -> Mapping[str, Any]:
    if surface is None:
        raise RuntimeError("memory management is not configured for this runtime")
    action = str(invocation.arguments.get("action") or "").strip().lower()
    if not action:
        raise ValueError("tool.memory.manage requires an 'action' argument")
    session_id = invocation.session_id
    if action in {"list", "ls"}:
        records = surface.inspect_memories(session_id)
        lines = [_memory_line(surface, record) for record in records[:20]] or ["<empty>"]
        return tool_summary(invocation, "\n".join(lines), side_effects=("memory", "inspect"))
    memory_id = optional_string(invocation.arguments.get("memory_id"))
    if action == "search":
        query = str(invocation.arguments.get("query") or "").strip()
        if not query:
            raise ValueError("tool.memory.manage search requires a 'query' argument")
        limit = max(1, min(coerce_int(invocation.arguments.get("limit"), default=5), 20))
        records = surface.search_memories(session_id, query, limit=limit)
        lines = [_memory_line(surface, record) for record in records] or ["<empty>"]
        return tool_summary(invocation, "\n".join(lines), side_effects=("memory", "search"))
    if memory_id is None:
        raise ValueError(f"tool.memory.manage action={action!r} requires 'memory_id'")
    if action == "inspect":
        record = surface.inspect_memory(session_id, memory_id)
        return tool_summary(
            invocation,
            "\n".join([_memory_line(surface, record), f"content: {record.content}"]),
            side_effects=("memory", "inspect"),
        )
    if action == "lineage":
        lineage = surface.memory_lineage(memory_id)
        state = surface.memory_state(memory_id) or "unknown"
        return tool_summary(
            invocation,
            f"memory_id: {memory_id}\nstate: {state}\nlineage: {lineage or '<none>'}",
            side_effects=("memory", "inspect"),
        )
    if action == "correct":
        corrected_content = str(
            invocation.arguments.get("content") or invocation.arguments.get("corrected_content") or ""
        ).strip()
        if not corrected_content:
            raise ValueError("tool.memory.manage correct requires 'content'")
        original, corrected, reason, lineage = surface.correct_memory(
            session_id,
            memory_id,
            corrected_content=corrected_content,
            reason=str(invocation.arguments.get("reason") or ""),
        )
        original_id = original.memory_id if original is not None else "<missing>"
        corrected_id = corrected.memory_id if corrected is not None else "<missing>"
        return tool_summary(
            invocation,
            "\n".join(
                [
                    f"original: {original_id}",
                    f"corrected: {corrected_id}",
                    f"reason: {reason}",
                    f"lineage: {lineage or '<none>'}",
                ]
            ),
            side_effects=("memory", "correction"),
        )
    if action == "delete":
        original, reason = surface.delete_memory(
            session_id,
            memory_id,
            reason=str(invocation.arguments.get("reason") or ""),
        )
        return tool_summary(
            invocation,
            f"deleted: {original.memory_id}\nreason: {reason or '<none>'}",
            side_effects=("memory", "deletion"),
        )
    if action == "pin":
        record, reason = surface.pin_memory(
            session_id,
            memory_id,
            reason=str(invocation.arguments.get("reason") or ""),
        )
        return tool_summary(
            invocation,
            f"pinned: {record.memory_id}\nreason: {reason}",
            side_effects=("memory", "pin"),
        )
    if action == "unpin":
        record, reason = surface.unpin_memory(
            session_id,
            memory_id,
            reason=str(invocation.arguments.get("reason") or ""),
        )
        return tool_summary(
            invocation,
            f"unpinned: {record.memory_id}\nreason: {reason}",
            side_effects=("memory", "pin"),
        )
    raise ValueError(f"tool.memory.manage does not support action={action!r}")


def run_todo_action(
    invocation: ToolInvocation,
    *,
    store: TodoStore,
    goal_surface: GoalManagementSurface | None,
) -> Mapping[str, Any]:
    action = str(invocation.arguments.get("action") or "").strip().lower()
    if not action:
        raise ValueError("tool.todo.manage requires an 'action' argument")
    session_id = invocation.session_id
    if action in {"list", "ls"}:
        items = store.list_items(session_id)
        lines = [_todo_line(item) for item in items] or ["<empty>"]
        return tool_summary(invocation, "\n".join(lines), side_effects=("todo", "scratchpad"))
    if action in {"add", "create"}:
        title = str(invocation.arguments.get("title") or "").strip()
        if not title:
            raise ValueError("tool.todo.manage create requires 'title'")
        item = store.upsert_item(
            session_id,
            title=title,
            status=str(invocation.arguments.get("status") or "open"),
            notes=str(invocation.arguments.get("notes") or ""),
        )
        return tool_summary(invocation, f"created: {_todo_line(item)}", side_effects=("todo", "scratchpad"))
    if action == "clear":
        removed = store.clear(session_id)
        return tool_summary(invocation, f"cleared: {removed}", side_effects=("todo", "scratchpad"))
    item_id = optional_string(invocation.arguments.get("item_id"))
    if item_id is None:
        raise ValueError(f"tool.todo.manage action={action!r} requires 'item_id'")
    if action == "inspect":
        item = store.inspect_item(session_id, item_id)
        return tool_summary(
            invocation,
            "\n".join([_todo_line(item), f"notes: {item.notes or '<none>'}"]),
            side_effects=("todo", "scratchpad"),
        )
    if action in {"update", "complete", "reopen"}:
        current = store.inspect_item(session_id, item_id)
        status = {
            "complete": "done",
            "reopen": "open",
        }.get(action, optional_string(invocation.arguments.get("status")) or current.status)
        item = store.upsert_item(
            session_id,
            item_id=item_id,
            title=optional_string(invocation.arguments.get("title")) or current.title,
            status=status,
            notes=optional_string(invocation.arguments.get("notes")) or current.notes,
            goal_id=current.goal_id,
        )
        return tool_summary(invocation, f"updated: {_todo_line(item)}", side_effects=("todo", "scratchpad"))
    if action in {"remove", "delete"}:
        removed = store.remove_item(session_id, item_id)
        return tool_summary(invocation, f"removed: {_todo_line(removed)}", side_effects=("todo", "scratchpad"))
    if action == "promote":
        if goal_surface is None:
            raise RuntimeError("todo promotion requires configured goal management")
        current = store.inspect_item(session_id, item_id)
        goal = goal_surface.create_goal(
            session_id,
            title=current.title,
            priority="medium",
            reason=current.notes or "promoted from todo scratchpad",
        )
        updated = store.upsert_item(
            session_id,
            item_id=item_id,
            title=current.title,
            status="promoted",
            notes=current.notes,
            goal_id=goal.goal_id,
        )
        return tool_summary(
            invocation,
            f"promoted: {_todo_line(updated)} -> {_goal_line(goal)}",
            side_effects=("todo", "goal"),
        )
    raise ValueError(f"tool.todo.manage does not support action={action!r}")


def run_companion_action(
    invocation: ToolInvocation,
    *,
    surface: CompanionManagementSurface | None,
) -> Mapping[str, Any]:
    if surface is None:
        raise RuntimeError("tool.companion.manage is not wired on this Aegis surface")
    action, target = normalize_companion_request(
        action=invocation.arguments.get("action"),
        target=invocation.arguments.get("target"),
    )
    profile_id = optional_string(invocation.arguments.get("profile_id"))
    if action in {"inspect", "show"}:
        if target in {"clone", "friend", "identity"}:
            return tool_summary(
                invocation,
                _inspect_companion_target(
                    surface,
                    session_id=invocation.session_id,
                    profile_id=profile_id,
                    target=target,
                ),
                side_effects=("companion", target),
            )
        profile = surface.inspect_companion(session_id=invocation.session_id, profile_id=profile_id)
        clone_text = profile.clone_text or "<empty>"
        friend_text = profile.friend_text or "<empty>"
        return tool_summary(
            invocation,
            "\n".join(
                [
                    f"profile_id: {profile.state.profile_id}",
                    f"display_name: {profile.state.display_name}",
                    f"aegis_path: {profile.aegis_path or '<packaged>'}",
                    "aegis_editable: false",
                    f"clone_path: {profile.state.clone_path or '<none>'}",
                    f"clone_text: {clone_text}",
                    f"friend_path: {profile.friend_path or '<none>'}",
                    f"friend_text: {friend_text}",
                    f"personality_preset: {profile.companion.personality_preset if profile.companion is not None else '<none>'}",
                    f"initiative: {profile.companion.initiative if profile.companion is not None else '<none>'}",
                ]
            ),
            side_effects=("companion",),
        )

    if target not in {"clone", "friend", "identity"}:
        raise ValueError(
            "tool.companion.manage requires target=clone, target=friend, or target=identity; "
            "canonical call shape is action=inspect|set|append|clear with target=clone|friend|identity"
        )
    if action in {"set", "write"}:
        if target == "identity":
            personality_preset = optional_string(invocation.arguments.get("personality_preset"))
            initiative = optional_string(invocation.arguments.get("initiative"))
            if personality_preset is None and initiative is None:
                return tool_summary(
                    invocation,
                    _inspect_companion_target(
                        surface,
                        session_id=invocation.session_id,
                        profile_id=profile_id,
                        target=target,
                    ),
                    side_effects=("companion", target),
                )
            return tool_summary(
                invocation,
                _write_companion_target(
                    surface,
                    session_id=invocation.session_id,
                    profile_id=profile_id,
                    target=target,
                    text=None,
                    personality_preset=personality_preset,
                    initiative=initiative,
                ),
                side_effects=("companion", target),
            )
        text = optional_string(invocation.arguments.get("text"))
        if text is None and target == "friend":
            text = _resolve_friend_field_patch_text(
                surface,
                session_id=invocation.session_id,
                profile_id=profile_id,
                arguments=invocation.arguments,
            )
        if text is None:
            return tool_summary(
                invocation,
                _inspect_companion_target(
                    surface,
                    session_id=invocation.session_id,
                    profile_id=profile_id,
                    target=target,
                ),
                side_effects=("companion", target),
            )
        return tool_summary(
            invocation,
            _write_companion_target(
                surface,
                session_id=invocation.session_id,
                profile_id=profile_id,
                target=target,
                text=text,
            ),
            side_effects=("companion", target),
        )
    if action == "append":
        if target == "identity":
            raise ValueError("tool.companion.manage append does not support target=identity; use action=set")
        text = optional_string(invocation.arguments.get("text"))
        if text is None and target == "friend":
            text = _resolve_friend_field_patch_text(
                surface,
                session_id=invocation.session_id,
                profile_id=profile_id,
                arguments=invocation.arguments,
            )
        if text is None:
            return tool_summary(
                invocation,
                _inspect_companion_target(
                    surface,
                    session_id=invocation.session_id,
                    profile_id=profile_id,
                    target=target,
                ),
                side_effects=("companion", target),
            )
        profile = surface.inspect_companion(session_id=invocation.session_id, profile_id=profile_id)
        existing = profile.clone_text if target == "clone" else profile.friend_text
        merged = text if not optional_string(existing) else f"{str(existing).rstrip()}\n\n{text}"
        return tool_summary(
            invocation,
            _write_companion_target(
                surface,
                session_id=invocation.session_id,
                profile_id=profile_id,
                target=target,
                text=merged,
            ),
            side_effects=("companion", target),
        )
    if action == "clear":
        if target == "identity":
            raise ValueError("tool.companion.manage clear does not support target=identity")
        return tool_summary(
            invocation,
            _write_companion_target(
                surface,
                session_id=invocation.session_id,
                profile_id=profile_id,
                target=target,
                text=None,
            ),
            side_effects=("companion", target),
        )
    raise ValueError(
        f"tool.companion.manage does not support action={action!r}; "
        "canonical actions are inspect|set|append|clear"
    )


def normalize_companion_request(*, action: Any, target: Any) -> tuple[str, str]:
    normalized_action = str(action or "").strip().lower() or "inspect"
    normalized_target = _normalize_companion_target(target)

    alias_map = {
        "inspect_friend": ("inspect", "friend"),
        "show_friend": ("inspect", "friend"),
        "read_friend": ("inspect", "friend"),
        "get_friend": ("inspect", "friend"),
        "update_friend": ("set", "friend"),
        "set_friend": ("set", "friend"),
        "write_friend": ("set", "friend"),
        "append_friend": ("append", "friend"),
        "add_friend": ("append", "friend"),
        "clear_friend": ("clear", "friend"),
        "reset_friend": ("clear", "friend"),
        "inspect_clone": ("inspect", "clone"),
        "show_clone": ("inspect", "clone"),
        "read_clone": ("inspect", "clone"),
        "get_clone": ("inspect", "clone"),
        "update_clone": ("set", "clone"),
        "set_clone": ("set", "clone"),
        "write_clone": ("set", "clone"),
        "append_clone": ("append", "clone"),
        "add_clone": ("append", "clone"),
        "clear_clone": ("clear", "clone"),
        "reset_clone": ("clear", "clone"),
        "inspect_identity": ("inspect", "identity"),
        "show_identity": ("inspect", "identity"),
        "read_identity": ("inspect", "identity"),
        "get_identity": ("inspect", "identity"),
        "set_identity": ("set", "identity"),
        "update_identity": ("set", "identity"),
        "write_identity": ("set", "identity"),
    }
    if normalized_action in alias_map:
        canonical_action, inferred_target = alias_map[normalized_action]
        return canonical_action, normalized_target or inferred_target

    if normalized_action in {"show", "read", "get"}:
        normalized_action = "inspect"
    elif normalized_action in {"write", "update"}:
        normalized_action = "set"
    elif normalized_action in {"add"}:
        normalized_action = "append"
    elif normalized_action in {"delete", "drop", "reset"}:
        normalized_action = "clear"
    return normalized_action, normalized_target


def run_skill_action(
    invocation: ToolInvocation,
    *,
    surface: SkillManagementSurface | None,
) -> Mapping[str, Any]:
    if surface is None:
        raise RuntimeError("tool.skill.manage is not wired on this Aegis surface")
    action = str(invocation.arguments.get("action") or "").strip().lower()
    if not action:
        raise ValueError("tool.skill.manage requires an 'action' argument")
    if action == "install":
        reference = str(invocation.arguments.get("reference") or invocation.arguments.get("skill_id") or "").strip()
        if not reference:
            raise ValueError("tool.skill.manage install requires 'reference'")
        record = surface.install_skill_source(reference, session_id=invocation.session_id)
        return tool_summary(
            invocation,
            "\n".join([f"source_path: {record.source_path}", f"skill_ids: {', '.join(record.skill_ids) or '<empty>'}"]),
            side_effects=("skill", "install"),
        )
    if action in {"enable", "disable"}:
        skill_id = str(invocation.arguments.get("skill_id") or "").strip()
        if not skill_id:
            raise ValueError(f"tool.skill.manage {action} requires 'skill_id'")
        updated = surface.set_skill_enabled(skill_id, action == "enable", session_id=invocation.session_id)
        return tool_summary(
            invocation,
            f"{updated.skill_id}\nenabled: {updated.enabled}",
            side_effects=("skill", "toggle"),
        )
    if action == "create":
        skill_id = str(invocation.arguments.get("skill_id") or "").strip()
        display_name = str(invocation.arguments.get("display_name") or "").strip()
        summary = str(invocation.arguments.get("summary") or "").strip()
        instruction_text = str(invocation.arguments.get("instruction_text") or "").strip()
        if not skill_id or not display_name or not summary or not instruction_text:
            raise ValueError(
                "tool.skill.manage create requires 'skill_id', 'display_name', 'summary', and 'instruction_text'"
            )
        record = surface.create_experience_skill(
            skill_id=skill_id,
            display_name=display_name,
            summary=summary,
            instruction_text=instruction_text,
            category=str(invocation.arguments.get("category") or "").strip() or None,
            install=coerce_bool(invocation.arguments.get("install"), default=True),
            overwrite=coerce_bool(invocation.arguments.get("overwrite"), default=False),
            session_id=invocation.session_id,
        )
        return tool_summary(
            invocation,
            "\n".join([f"source_path: {record.source_path}", f"skill_ids: {', '.join(record.skill_ids) or '<empty>'}"]),
            side_effects=("skill", "experience"),
        )
    raise ValueError(
        f"tool.skill.manage does not support action={action!r}; supported actions are install, enable, disable, create"
    )


def run_skill_list(
    invocation: ToolInvocation,
    *,
    surface: SkillManagementSurface | None,
) -> Mapping[str, Any]:
    if surface is None:
        raise RuntimeError("skill discovery is not wired on this Aegis surface")
    query = str(invocation.arguments.get("query") or "").strip()
    if query:
        raise ValueError("tool.skill.list does not support 'query'; use tool.skill.search")
    limit = coerce_int(invocation.arguments.get("limit"), default=12)
    installed_skills = surface.skill_catalog(session_id=invocation.session_id)
    installed_map = {skill.skill_id: skill for skill in installed_skills}
    entries = surface.list_skill_hub(limit=limit)
    lines = [
        (
            f"{entry.reference} | installed={entry.skill_id in installed_map} | "
            f"category={entry.metadata.get('category') or 'general'} | "
            f"slash=/{entry.metadata.get('slash_command') or entry.skill_id} | "
            f"{entry.display_name} | {entry.summary}"
        )
        for entry in entries
    ]
    if not query:
        active_lines = [
            f"{skill.skill_id} | enabled={skill.enabled} | active | {skill.display_name} | {skill.summary}"
            for skill in installed_skills[: min(8, limit)]
            if skill.enabled
        ]
        if active_lines:
            lines.extend(["", "active:", *active_lines])
    summary = "\n".join(lines) if lines else "<empty>"
    return tool_summary(invocation, summary)


def run_skill_search(
    invocation: ToolInvocation,
    *,
    surface: SkillManagementSurface | None,
) -> Mapping[str, Any]:
    if surface is None:
        raise RuntimeError("skill search is not wired on this Aegis surface")
    query = str(invocation.arguments.get("query") or "").strip()
    if not query:
        raise ValueError("tool.skill.search requires 'query'")
    source = str(invocation.arguments.get("source") or "").strip() or None
    limit = coerce_int(invocation.arguments.get("limit"), default=12)
    entries = surface.search_skill_sources(query, source=source, limit=limit)
    lines = [
        (
            f"{entry.reference} | trust={entry.trust_level} | "
            f"install={entry.install_reference} | "
            f"source={entry.source_label} | "
            f"{entry.display_name} | {entry.summary}"
        )
        for entry in entries
    ]
    summary = "\n".join(lines) if lines else "<empty>"
    return tool_summary(invocation, summary)


def run_skill_view(
    invocation: ToolInvocation,
    *,
    surface: SkillManagementSurface | None,
) -> Mapping[str, Any]:
    if surface is None:
        raise RuntimeError("skill viewing is not wired on this Aegis surface")
    skill_id = str(invocation.arguments.get("skill_id") or invocation.arguments.get("reference") or "").strip()
    if not skill_id:
        raise ValueError("tool.skill.view requires 'skill_id' or 'reference'")
    skill = surface.inspect_skill(skill_id, session_id=invocation.session_id)
    lines = [
        f"skill_id: {skill.skill_id}",
        f"display_name: {skill.display_name}",
        f"enabled: {skill.enabled}",
        f"version: {skill.version}",
        f"summary: {skill.summary}",
        f"provenance: {skill.provenance or 'built-in'}",
    ]
    installed = skill.metadata.get("installed")
    if isinstance(installed, bool):
        lines.append(f"installed: {installed}")
    hub_reference = str(skill.metadata.get("hub_reference") or "").strip()
    if hub_reference:
        lines.append(f"hub_reference: {hub_reference}")
    trust_level = str(skill.metadata.get("trust_level") or "").strip()
    if trust_level:
        lines.append(f"trust_level: {trust_level}")
    category = str(skill.metadata.get("category") or "").strip()
    if category:
        lines.append(f"category: {category}")
    slash_command = str(skill.metadata.get("slash_command") or "").strip()
    if slash_command:
        lines.append(f"slash_command: /{slash_command}")
    if skill.instruction_text.strip():
        lines.extend(["instruction_text:", skill.instruction_text.strip()])
    return tool_summary(invocation, "\n".join(lines))


def run_cron_action(invocation: ToolInvocation, *, runtime: CronRuntime | None) -> ExecutionResult:
    if runtime is None:
        raise RuntimeError("cron runtime is not configured")
    action = str(invocation.arguments.get("action") or "").strip().lower()
    if not action:
        raise ValueError("tool.cron.manage requires an 'action' argument")
    if action == "list":
        jobs = runtime.list_jobs(
            profile_id=optional_string(invocation.arguments.get("profile_id")),
            clone_id=optional_string(invocation.arguments.get("clone_id")),
        )
        summary = "\n".join(
            f"{job.job_id} | {job.status} | {job.name} | {job.schedule_text} | {job.action_kind}"
            for job in jobs
        ) or "<empty>"
        return ExecutionResult(
            execution_id=invocation.invocation_id,
            session_id=invocation.session_id,
            outcome="success",
            summary=summary,
            side_effects=("cron", "automation"),
        )
    if action == "create":
        name = optional_string(invocation.arguments.get("name")) or "Aegis job"
        schedule = optional_string(invocation.arguments.get("schedule"))
        job_kind = optional_string(invocation.arguments.get("job_kind"))
        if not schedule or not job_kind:
            raise ValueError("cron create requires 'schedule' and 'job_kind'")
        payload = {
            key: value
            for key, value in (
                ("message", optional_string(invocation.arguments.get("message"))),
                ("query", optional_string(invocation.arguments.get("query"))),
                ("prompt", optional_string(invocation.arguments.get("prompt"))),
            )
            if value is not None
        }
        job = runtime.create_job(
            name=name,
            schedule_text=schedule,
            action_kind=job_kind,
            payload=payload,
            profile_id=optional_string(invocation.arguments.get("profile_id")),
            clone_id=optional_string(invocation.arguments.get("clone_id")),
        )
        return ExecutionResult(
            execution_id=invocation.invocation_id,
            session_id=invocation.session_id,
            outcome="success",
            summary=(
                f"created {job.job_id}\n"
                f"name: {job.name}\n"
                f"schedule: {job.schedule_text}\n"
                f"job_kind: {job.action_kind}\n"
                f"next_run_at: {job.next_run_at.isoformat() if job.next_run_at is not None else '<none>'}"
            ),
            side_effects=("cron", "automation"),
        )
    job_id = optional_string(invocation.arguments.get("job_id"))
    if not job_id:
        raise ValueError(f"cron action '{action}' requires 'job_id'")
    if action == "inspect":
        job = runtime.inspect_job(job_id)
        return ExecutionResult(
            execution_id=invocation.invocation_id,
            session_id=invocation.session_id,
            outcome="success",
            summary=(
                f"{job.job_id}\n"
                f"name: {job.name}\n"
                f"status: {job.status}\n"
                f"schedule: {job.schedule_text}\n"
                f"job_kind: {job.action_kind}\n"
                f"next_run_at: {job.next_run_at.isoformat() if job.next_run_at is not None else '<none>'}\n"
                f"last_summary: {job.last_summary or '<none>'}"
            ),
            side_effects=("cron", "automation"),
        )
    if action == "pause":
        job = runtime.pause_job(job_id)
        summary = f"{job.job_id}\nstatus: {job.status}"
    elif action == "resume":
        job = runtime.resume_job(job_id)
        summary = (
            f"{job.job_id}\nstatus: {job.status}\n"
            f"next_run_at: {job.next_run_at.isoformat() if job.next_run_at is not None else '<none>'}"
        )
    elif action == "remove":
        job = runtime.remove_job(job_id)
        summary = f"{job.job_id}\nstatus: removed"
    else:
        raise ValueError(f"unsupported cron action: {action}")
    return ExecutionResult(
        execution_id=invocation.invocation_id,
        session_id=invocation.session_id,
        outcome="success",
        summary=summary,
        side_effects=("cron", "automation"),
    )


def _resolve_friend_field_patch_text(
    surface: CompanionManagementSurface,
    *,
    session_id: str | None,
    profile_id: str | None,
    arguments: Mapping[str, Any],
) -> str | None:
    fields_payload = arguments.get("fields")
    field_updates = friend_profile_updates(fields_payload if isinstance(fields_payload, Mapping) else {})
    field_updates.update(friend_profile_updates(arguments))
    if not field_updates:
        return None
    profile = surface.inspect_companion(session_id=session_id, profile_id=profile_id)
    return merge_friend_profile_text(profile.friend_text, field_values=field_updates)


def _normalize_companion_target(value: Any) -> str:
    normalized = str(value or "").strip().lower()
    if normalized in {"friend", "friend.md", "friend_profile", "friend-profile", "friend profile"}:
        return "friend"
    if normalized in {"clone", "clone.md", "clone_charter", "clone-charter", "clone charter"}:
        return "clone"
    if normalized in {"identity", "companion", "companion identity", "presence", "initiative", "posture"}:
        return "identity"
    return normalized


def _write_companion_target(
    surface: CompanionManagementSurface,
    *,
    session_id: str | None,
    profile_id: str | None,
    target: str,
    text: str | None,
    personality_preset: str | None = None,
    initiative: str | None = None,
) -> str:
    if target == "clone":
        updated = surface.update_clone_text(
            session_id=session_id,
            profile_id=profile_id,
            clone_text=text,
        )
        return "\n".join(
            [
                f"profile_id: {updated.state.profile_id}",
                f"target: {target}",
                f"clone_text: {updated.clone_text or '<empty>'}",
            ]
        )
    if target == "identity":
        updated = surface.update_companion_settings(
            session_id=session_id,
            profile_id=profile_id,
            personality_preset=personality_preset,
            initiative=initiative,
        )
        personality = updated.companion.personality if updated.companion is not None else ()
        return "\n".join(
            [
                f"profile_id: {updated.state.profile_id}",
                f"target: {target}",
                f"personality_preset: {updated.companion.personality_preset if updated.companion is not None else '<none>'}",
                f"initiative: {updated.companion.initiative if updated.companion is not None else '<none>'}",
                f"personality_traits: {', '.join(personality) or '<empty>'}",
            ]
        )
    updated = surface.update_friend_text(
        session_id=session_id,
        profile_id=profile_id,
        friend_text=text,
    )
    return "\n".join(
        [
            f"profile_id: {updated.state.profile_id}",
            f"target: {target}",
            f"friend_text: {updated.friend_text or '<empty>'}",
        ]
    )


def _inspect_companion_target(
    surface: CompanionManagementSurface,
    *,
    session_id: str | None,
    profile_id: str | None,
    target: str,
) -> str:
    profile = surface.inspect_companion(session_id=session_id, profile_id=profile_id)
    if target == "clone":
        return "\n".join(
            [
                f"profile_id: {profile.state.profile_id}",
                f"target: {target}",
                f"clone_text: {profile.clone_text or '<empty>'}",
            ]
        )
    if target == "identity":
        personality = profile.companion.personality if profile.companion is not None else ()
        return "\n".join(
            [
                f"profile_id: {profile.state.profile_id}",
                f"target: {target}",
                f"personality_preset: {profile.companion.personality_preset if profile.companion is not None else '<none>'}",
                f"initiative: {profile.companion.initiative if profile.companion is not None else '<none>'}",
                f"personality_traits: {', '.join(personality) or '<empty>'}",
            ]
        )
    return "\n".join(
        [
            f"profile_id: {profile.state.profile_id}",
            f"target: {target}",
            f"friend_text: {profile.friend_text or '<empty>'}",
        ]
    )


def _goal_line(goal: GoalNode) -> str:
    return f"{goal.goal_id} | {goal.status} | {goal.priority} | {goal.title}"


def _goal_exists(surface: GoalManagementSurface, session_id: str, goal_id: str) -> bool:
    try:
        surface.inspect_goal(session_id, goal_id)
    except KeyError:
        return False
    return True


def _memory_line(surface: MemoryManagementSurface, record: MemoryRecord) -> str:
    state = surface.memory_state(record.memory_id) or "active"
    lineage = surface.memory_lineage(record.memory_id)
    tags = ", ".join(record.tags) or "<none>"
    base = f"{record.memory_id} | {state} | {record.kind} | tags={tags} | {record.content}"
    if lineage:
        base += f" | lineage={lineage}"
    return truncate(base, limit=320)


def _todo_line(item: TodoItem) -> str:
    goal_part = f" | goal={item.goal_id}" if item.goal_id else ""
    return f"{item.item_id} | {item.status} | {item.title}{goal_part}"


__all__ = [
    "normalize_companion_request",
    "run_companion_action",
    "run_cron_action",
    "run_goal_action",
    "run_memory_action",
    "run_skill_action",
    "run_todo_action",
]
