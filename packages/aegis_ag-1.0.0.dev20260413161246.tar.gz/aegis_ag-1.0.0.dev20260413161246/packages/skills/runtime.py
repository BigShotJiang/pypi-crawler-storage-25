"""Skill loading, scope, dependency metadata, and skill-package discovery.

Skills are reusable procedural packages. They are not executable side effects
themselves; they are metadata-backed bundles that can be loaded, activated, and
resolved by scope.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field, replace
from datetime import datetime, timezone
from pathlib import Path
import re
from typing import Any, Callable, Mapping, Protocol, runtime_checkable

from packages.capabilities.runtime import CapabilityDescriptor, SkillCapability


@dataclass(frozen=True, slots=True)
class SkillScope:
    """Activation scope for a skill."""

    profile_ids: tuple[str, ...] = ()
    workspace_ids: tuple[str, ...] = ()
    session_ids: tuple[str, ...] = ()
    modes: tuple[str, ...] = ()

    def matches(
        self,
        *,
        profile_id: str,
        workspace_id: str | None,
        session_id: str,
        mode: str,
    ) -> bool:
        if self.profile_ids and profile_id not in self.profile_ids:
            return False
        if self.workspace_ids and (workspace_id is None or workspace_id not in self.workspace_ids):
            return False
        if self.session_ids and session_id not in self.session_ids:
            return False
        if self.modes and mode not in self.modes:
            return False
        return True


@dataclass(frozen=True, slots=True)
class SkillDependency:
    skill_id: str
    minimum_version: str | None = None
    required: bool = True


@dataclass(frozen=True, slots=True)
class SkillDefinition:
    skill_id: str
    display_name: str
    version: str
    summary: str
    scope: SkillScope = field(default_factory=SkillScope)
    dependencies: tuple[SkillDependency, ...] = ()
    provenance: str = ""
    enabled: bool = True
    instruction_text: str = ""
    entry_path: str = ""
    metadata: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class SkillActivationRecord:
    activation_id: str
    skill_id: str
    session_id: str
    profile_id: str
    workspace_id: str | None
    mode: str
    activated_at: datetime
    status: str = "active"
    detail: str | None = None
    provenance: str = ""
    dependency_ids: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class SkillManifest:
    source_path: str
    skills: tuple[SkillDefinition, ...]


@dataclass(frozen=True, slots=True)
class SkillManifestLoadRecord:
    source_path: str
    skill_ids: tuple[str, ...]
    loaded_at: datetime
    status: str = "loaded"
    detail: str | None = None


@dataclass(frozen=True, slots=True)
class SkillActivationContext:
    profile_id: str
    workspace_id: str | None
    mode: str


@runtime_checkable
class SkillLoader(Protocol):
    def load(self, path: Path) -> SkillManifest:
        """Load a skill manifest from disk."""


@runtime_checkable
class SkillCatalog(Protocol):
    def register(self, definition: SkillDefinition) -> None:
        """Register a skill definition."""

    def get(self, skill_id: str) -> SkillDefinition | None:
        """Return a skill definition if it exists."""

    def list(self) -> tuple[SkillDefinition, ...]:
        """Return all registered skills."""

    def resolve_for_context(
        self,
        *,
        profile_id: str,
        workspace_id: str | None,
        session_id: str,
        mode: str,
    ) -> tuple[SkillDefinition, ...]:
        """Return enabled skills matching the supplied scope."""


class JsonSkillLoader:
    """Load skill manifests from a JSON-shaped file."""

    def load(self, path: Path) -> SkillManifest:
        payload = json.loads(path.read_text(encoding="utf-8"))
        skills = tuple(_skill_from_dict(item, source_path=path) for item in payload.get("skills", []))
        return SkillManifest(source_path=str(path), skills=skills)


class SkillPackageLoader:
    """Load a skill package from a directory or ``SKILL.md`` entry file."""

    def load(self, path: Path) -> SkillManifest:
        definition = load_skill_package_definition(path)
        source_path = str(_resolve_skill_entry_path(path))
        return SkillManifest(source_path=source_path, skills=(definition,))


class InMemorySkillCatalog:
    """Simple in-memory catalog used for runtime wiring and tests."""

    def __init__(self) -> None:
        self._skills: dict[str, SkillDefinition] = {}

    def register(self, definition: SkillDefinition) -> None:
        existing = self._skills.get(definition.skill_id)
        if existing is not None and existing != definition:
            raise ValueError(
                f"skill is already registered with different metadata: {definition.skill_id}"
            )
        self._skills[definition.skill_id] = definition

    def get(self, skill_id: str) -> SkillDefinition | None:
        return self._skills.get(skill_id)

    def list(self) -> tuple[SkillDefinition, ...]:
        return tuple(self._skills.values())

    def add_manifest(self, manifest: SkillManifest) -> None:
        for skill in manifest.skills:
            existing = self._skills.get(skill.skill_id)
            candidate = skill
            if existing is not None:
                if _skill_identity(existing) != _skill_identity(skill):
                    raise ValueError(
                        f"skill is already registered with different metadata: {skill.skill_id}"
                    )
                candidate = replace(skill, enabled=existing.enabled)
            self._skills[candidate.skill_id] = candidate

    def resolve_for_context(
        self,
        *,
        profile_id: str,
        workspace_id: str | None,
        session_id: str,
        mode: str,
    ) -> tuple[SkillDefinition, ...]:
        resolved = [
            skill
            for skill in self.list()
            if skill.enabled
            and skill.scope.matches(
                profile_id=profile_id,
                workspace_id=workspace_id,
                session_id=session_id,
                mode=mode,
            )
        ]
        return tuple(resolved)

    def validate_dependencies(self, skill_id: str) -> tuple[str, ...]:
        skill = self._skills[skill_id]
        missing: list[str] = []
        for dependency in skill.dependencies:
            if dependency.required and dependency.skill_id not in self._skills:
                missing.append(dependency.skill_id)
        return tuple(missing)

    def set_enabled(self, skill_id: str, enabled: bool) -> SkillDefinition:
        definition = self._skills.get(skill_id)
        if definition is None:
            raise KeyError(f"skill is not registered: {skill_id}")
        updated = replace(definition, enabled=enabled)
        self._skills[skill_id] = updated
        return updated


class SkillRuntime(SkillCapability):
    """Capability adapter for skill activation."""

    def __init__(
        self,
        catalog: SkillCatalog | None = None,
        context_resolver: Callable[[str], SkillActivationContext] | None = None,
    ) -> None:
        self.descriptor = CapabilityDescriptor(
            capability_id="skill.runtime",
            kind="skill_runtime",
            version="1.0.0",
            metadata={
                "description": "In-process skill activation adapter.",
            },
        )
        self._catalog = catalog or InMemorySkillCatalog()
        self._context_resolver = context_resolver
        self._activations: list[SkillActivationRecord] = []
        self._manifest_loads: list[SkillManifestLoadRecord] = []

    @property
    def catalog(self) -> SkillCatalog:
        return self._catalog

    def register_skill(self, definition: SkillDefinition) -> None:
        self._catalog.register(definition)

    def describe(self, skill_id: str) -> SkillDefinition | None:
        return self._catalog.get(skill_id)

    def list_skills(self) -> tuple[SkillDefinition, ...]:
        return self._catalog.list()

    def load_manifest(self, path: Path, loader: SkillLoader | None = None) -> SkillManifest:
        manifest = (loader or JsonSkillLoader()).load(path)
        if hasattr(self._catalog, "add_manifest"):
            self._catalog.add_manifest(manifest)  # type: ignore[attr-defined]
        else:
            for skill in manifest.skills:
                self._catalog.register(skill)
        self._manifest_loads.append(
            SkillManifestLoadRecord(
                source_path=manifest.source_path,
                skill_ids=tuple(skill.skill_id for skill in manifest.skills),
                loaded_at=datetime.now(timezone.utc),
            )
        )
        return manifest

    def load_package(self, path: Path) -> SkillManifest:
        return self.load_manifest(path, loader=SkillPackageLoader())

    def list_manifest_loads(self) -> tuple[SkillManifestLoadRecord, ...]:
        return tuple(self._manifest_loads)

    def resolve_for_context(
        self,
        *,
        profile_id: str,
        workspace_id: str | None,
        session_id: str,
        mode: str,
    ) -> tuple[SkillDefinition, ...]:
        return self._catalog.resolve_for_context(
            profile_id=profile_id,
            workspace_id=workspace_id,
            session_id=session_id,
            mode=mode,
        )

    def activate(self, skill_name: str, *, session_id: str) -> SkillActivationRecord:
        if self._context_resolver is None:
            raise RuntimeError("skill activation requires a context resolver")
        context = self._context_resolver(session_id)
        definition = self._catalog.get(skill_name)
        if definition is None:
            raise KeyError(f"skill is not registered: {skill_name}")
        if not definition.enabled:
            raise ValueError(f"skill is disabled: {skill_name}")
        if not definition.scope.matches(
            profile_id=context.profile_id,
            workspace_id=context.workspace_id,
            session_id=session_id,
            mode=context.mode,
        ):
            raise PermissionError(f"skill is out of scope for session: {skill_name}")
        missing = []
        if hasattr(self._catalog, "validate_dependencies"):
            missing = list(self._catalog.validate_dependencies(skill_name))  # type: ignore[attr-defined]
        if missing:
            raise RuntimeError(f"skill dependencies are missing: {', '.join(missing)}")
        record = SkillActivationRecord(
            activation_id=f"{session_id}:{skill_name}",
            skill_id=skill_name,
            session_id=session_id,
            profile_id=context.profile_id,
            workspace_id=context.workspace_id,
            mode=context.mode,
            activated_at=datetime.now(timezone.utc),
            provenance=definition.provenance,
            dependency_ids=tuple(dependency.skill_id for dependency in definition.dependencies),
        )
        self._activations.append(record)
        return record

    def list_activations(self) -> tuple[SkillActivationRecord, ...]:
        return tuple(self._activations)

    def set_enabled(self, skill_id: str, enabled: bool) -> SkillDefinition:
        if hasattr(self._catalog, "set_enabled"):
            return self._catalog.set_enabled(skill_id, enabled)  # type: ignore[attr-defined]
        definition = self._catalog.get(skill_id)
        if definition is None:
            raise KeyError(f"skill is not registered: {skill_id}")
        updated = replace(definition, enabled=enabled)
        self._catalog.register(updated)
        return updated


def _skill_from_dict(payload: Mapping[str, Any], *, source_path: Path | None = None) -> SkillDefinition:
    scope_payload = payload.get("scope", {})
    dependencies = tuple(
        SkillDependency(
            skill_id=item["skill_id"],
            minimum_version=item.get("minimum_version"),
            required=item.get("required", True),
        )
        for item in payload.get("dependencies", [])
    )
    return SkillDefinition(
        skill_id=payload["skill_id"],
        display_name=payload["display_name"],
        version=payload["version"],
        summary=payload.get("summary", ""),
        scope=SkillScope(
            profile_ids=tuple(scope_payload.get("profile_ids", ())),
            workspace_ids=tuple(scope_payload.get("workspace_ids", ())),
            session_ids=tuple(scope_payload.get("session_ids", ())),
            modes=tuple(scope_payload.get("modes", ())),
        ),
        dependencies=dependencies,
        provenance=str(payload.get("provenance") or source_path or ""),
        enabled=payload.get("enabled", True),
        instruction_text=str(payload.get("instruction_text") or ""),
        entry_path=str(payload.get("entry_path") or source_path or ""),
        metadata=payload.get("metadata", {}),
    )


def _skill_identity(definition: SkillDefinition) -> SkillDefinition:
    return replace(definition, enabled=True)


def load_skill_package_definition(path: Path) -> SkillDefinition:
    entry_path = _resolve_skill_entry_path(path)
    text = entry_path.read_text(encoding="utf-8")
    frontmatter, body = _split_frontmatter(text)
    title = (
        str(frontmatter.get("name") or frontmatter.get("display_name") or "").strip()
        or _first_heading(body)
        or entry_path.parent.name.replace("-", " ").title()
    )
    summary = (
        str(frontmatter.get("description") or frontmatter.get("summary") or "").strip()
        or _first_summary(body)
        or f"Skill package loaded from {entry_path.parent.name}."
    )
    skill_id = str(frontmatter.get("skill_id") or entry_path.parent.name).strip()
    version = str(frontmatter.get("version") or "1.0.0").strip() or "1.0.0"
    metadata = {
        "kind": "skill-package",
        "entry_path": str(entry_path),
        "slash_command": _skill_command_slug(skill_id or title),
    }
    source_kind = str(frontmatter.get("source_kind") or "").strip()
    if source_kind:
        metadata["source_kind"] = source_kind
    category = str(frontmatter.get("category") or "").strip()
    if category:
        metadata["category"] = category
    for key in (
        "aliases",
        "trigger_phrases",
        "keywords",
        "platforms",
        "requires_tools",
        "requires_toolsets",
        "required_environment_variables",
    ):
        values = _frontmatter_string_list(frontmatter.get(key))
        if values:
            metadata[key] = values
    return SkillDefinition(
        skill_id=skill_id,
        display_name=title,
        version=version,
        summary=summary,
        scope=SkillScope(),
        dependencies=(),
        provenance=str(entry_path.parent),
        enabled=True,
        instruction_text=body.strip(),
        entry_path=str(entry_path),
        metadata=metadata,
    )


def _resolve_skill_entry_path(path: Path) -> Path:
    resolved = path.expanduser().resolve()
    if resolved.is_dir():
        resolved = resolved / "SKILL.md"
    if not resolved.exists():
        raise FileNotFoundError(resolved)
    if resolved.name != "SKILL.md":
        raise ValueError(f"skill packages must point at a SKILL.md file or skill directory: {resolved}")
    return resolved


def _split_frontmatter(text: str) -> tuple[dict[str, Any], str]:
    if not text.startswith("---\n"):
        return ({}, text)
    closing = text.find("\n---\n", 4)
    if closing == -1:
        return ({}, text)
    payload: dict[str, Any] = {}
    block = text[4:closing]
    for line in block.splitlines():
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        payload[key.strip()] = value.strip()
    return payload, text[closing + len("\n---\n") :]


def _frontmatter_string_list(value: Any) -> tuple[str, ...]:
    if value is None:
        return ()
    if isinstance(value, (list, tuple, set)):
        raw_items = tuple(value)
    else:
        text = str(value).strip()
        if not text:
            return ()
        raw_items: tuple[Any, ...]
        if text.startswith("[") and text.endswith("]"):
            try:
                parsed = json.loads(text)
            except json.JSONDecodeError:
                parsed = None
            if isinstance(parsed, list):
                raw_items = tuple(parsed)
            else:
                raw_items = tuple(segment.strip() for segment in text[1:-1].split(","))
        else:
            raw_items = tuple(segment.strip() for segment in text.split(","))
    normalized: list[str] = []
    seen: set[str] = set()
    for item in raw_items:
        token = str(item).strip().strip("\"'")
        if not token:
            continue
        dedupe_key = token.lower()
        if dedupe_key in seen:
            continue
        seen.add(dedupe_key)
        normalized.append(token)
    return tuple(normalized)


def _first_heading(body: str) -> str:
    for raw_line in body.splitlines():
        line = raw_line.strip()
        if not line or not line.startswith("#"):
            continue
        return line.lstrip("#").strip()
    return ""


def _first_summary(body: str) -> str:
    paragraphs: list[str] = []
    current: list[str] = []
    for raw_line in body.splitlines():
        line = raw_line.strip()
        if not line:
            if current:
                paragraphs.append(" ".join(current))
                current = []
            continue
        if line.startswith("#"):
            continue
        current.append(line)
        if len(" ".join(current)) >= 180:
            paragraphs.append(" ".join(current))
            break
    if current and not paragraphs:
        paragraphs.append(" ".join(current))
    return paragraphs[0] if paragraphs else ""


def _skill_command_slug(value: str) -> str:
    normalized = re.sub(r"[^a-z0-9-]+", "-", value.lower().replace("_", "-").replace(" ", "-"))
    return re.sub(r"-{2,}", "-", normalized).strip("-")
