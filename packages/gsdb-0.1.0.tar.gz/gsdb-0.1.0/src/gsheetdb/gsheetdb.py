"""
gsheetdb.py
-----------
A MySQL-like interface over Google Sheets.

Schema is stored in a reserved worksheet called '__schema__' with the following columns:
    table_name | column_name | data_type | primary_key | auto_increment | nullable | default | foreign_key_table | foreign_key_column

Usage:
    from gsheetdb import GSheetDB
    db = GSheetDB("gsheet_name", "service_account_credentials.json")

    db.create_table("users", [
        {"name": "id",    "type": "INTEGER", "primary_key": True, "auto_increment": True},
        {"name": "email", "type": "STRING",  "nullable": False},
        {"name": "age",   "type": "INTEGER", "nullable": True, "default": 0},
    ])

    db.insert("users", {"email": "alice@example.com", "age": 30})
    rows = db.select("users", where={"age": 30})
    db.update("users", set_values={"age": 31}, where={"email": "alice@example.com"})
    db.delete("users", where={"email": "alice@example.com"})
"""

import re
import time
import functools
from typing import Any, Optional

import gspread
from oauth2client.service_account import ServiceAccountCredentials

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
SCHEMA_SHEET = "__schema__"
SCHEMA_HEADERS = [
    "table_name", "column_name", "data_type",
    "primary_key", "auto_increment", "nullable",
    "default", "foreign_key_table", "foreign_key_column",
]
VALID_TYPES = {"STRING", "INTEGER", "FLOAT", "BOOLEAN", "DATE"}
GSHEETS_SCOPE = [
    "https://spreadsheets.google.com/feeds",
    "https://www.googleapis.com/auth/drive",
]


# ---------------------------------------------------------------------------
# Retry decorator — handles 429 / transient 5xx automatically
# ---------------------------------------------------------------------------
def _retry(max_attempts: int = 5, base_delay: float = 2.0):
    """Exponential-backoff retry for Google Sheets API calls."""
    def decorator(fn):
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            delay = base_delay
            for attempt in range(1, max_attempts + 1):
                try:
                    return fn(*args, **kwargs)
                except gspread.exceptions.APIError as e:
                    status = e.response.status_code if hasattr(e, "response") else 0
                    if status in (429, 500, 502, 503) and attempt < max_attempts:
                        print(f"[gsheetdb] API {status} — retrying in {delay:.1f}s "
                              f"(attempt {attempt}/{max_attempts})")
                        time.sleep(delay)
                        delay *= 2
                    else:
                        raise
        return wrapper
    return decorator

# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------
class GSheetDBError(Exception):
    pass

class TableNotFoundError(GSheetDBError):
    pass

class TableExistsError(GSheetDBError):
    pass

class ColumnNotFoundError(GSheetDBError):
    pass

class ConstraintError(GSheetDBError):
    pass

class ForeignKeyError(GSheetDBError):
    pass

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _truthy(val) -> bool:
    """Normalise 'TRUE'/'FALSE'/True/False from sheets to bool."""
    if isinstance(val, bool):
        return val
    return str(val).strip().upper() in ("TRUE", "1", "YES")

def _cast(value: str, data_type: str) -> Any:
    """Cast a raw string from a sheet cell to the column's declared type."""
    if value == "" or value is None:
        return None
    try:
        if data_type == "INTEGER":
            return int(float(value))
        if data_type == "FLOAT":
            return float(value)
        if data_type == "BOOLEAN":
            return _truthy(value)
    except (ValueError, TypeError):
        pass
    return value  # STRING / DATE / fallback

# ---------------------------------------------------------------------------
# Main class
# ---------------------------------------------------------------------------
class GSheetDB:
    """
    MySQL-like database backed by a single Google Spreadsheet.

    Each table is a worksheet.  A hidden '__schema__' worksheet holds all
    column definitions, constraints and foreign-key relationships.
    """

    def __init__(self, spreadsheet_name: str, credentials_file: str):
        """
        Open (or initialise) a GSheetDB-managed spreadsheet.

        Args:
            spreadsheet_name: Title of the Google Spreadsheet.
            credentials_file: Path to the service-account JSON key file.
        """
        creds = ServiceAccountCredentials.from_json_keyfile_name(credentials_file, GSHEETS_SCOPE)
        self._client = gspread.authorize(creds)
        self._spreadsheet = self._client.open(spreadsheet_name)
        # In-memory caches — invalidated whenever schema or table data changes
        self._schema_cache: list[dict] | None = None        # all rows from __schema__
        self._table_cache:  dict[str, list[dict]] = {}      # table_name → get_all_records()
        self._header_cache: dict[str, list[str]]  = {}      # table_name → row_values(1)
        self._ensure_schema_sheet()

    def invalidate_cache(self, table_name: str | None = None):
        """
        Manually drop cached data.  Call after external edits to the spreadsheet.
        Pass table_name to clear only that table; omit to clear everything.
        """
        if table_name is None:
            self._schema_cache = None
            self._table_cache.clear()
            self._header_cache.clear()
        else:
            self._table_cache.pop(table_name, None)
            self._header_cache.pop(table_name, None)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @_retry()
    def _ensure_schema_sheet(self):
        """Create the __schema__ worksheet if it doesn't exist yet."""
        titles = [ws.title for ws in self._spreadsheet.worksheets()]
        if SCHEMA_SHEET not in titles:
            ws = self._spreadsheet.add_worksheet(title=SCHEMA_SHEET, rows=1000, cols=len(SCHEMA_HEADERS))
            ws.append_row(SCHEMA_HEADERS)

    def _schema_sheet(self) -> gspread.Worksheet:
        return self._spreadsheet.worksheet(SCHEMA_SHEET)

    @_retry()
    def _get_worksheet(self, table_name: str) -> gspread.Worksheet:
        try:
            return self._spreadsheet.worksheet(table_name)
        except gspread.WorksheetNotFound:
            raise TableNotFoundError(f"Table '{table_name}' does not exist.")

    @_retry()
    def _get_table_records(self, table_name: str, force: bool = False) -> list[dict]:
        """Return all data records for a table (cached after first read per operation)."""
        if table_name not in self._table_cache or force:
            ws = self._get_worksheet(table_name)
            self._table_cache[table_name] = ws.get_all_records()
        return self._table_cache[table_name]

    def _invalidate_table(self, table_name: str):
        self._table_cache.pop(table_name, None)
        self._header_cache.pop(table_name, None)

    @_retry()
    def _get_table_headers(self, table_name: str, force: bool = False) -> list[str]:
        """Return header row for a table (cached — avoids repeated row_values(1) calls)."""
        if table_name not in self._header_cache or force:
            ws = self._get_worksheet(table_name)
            self._header_cache[table_name] = ws.row_values(1)
        return self._header_cache[table_name]

    @_retry()
    def _schema_rows(self, force: bool = False) -> list[dict]:
        """Return all rows from the schema sheet (cached after first read)."""
        if self._schema_cache is None or force:
            ws = self._schema_sheet()
            self._schema_cache = ws.get_all_records()
        return self._schema_cache

    def _invalidate_schema(self):
        self._schema_cache = None

    def _table_schema(self, table_name: str) -> list[dict]:
        """Return schema rows for a specific table, in column order."""
        rows = [r for r in self._schema_rows() if r["table_name"] == table_name]
        if not rows:
            raise TableNotFoundError(f"Table '{table_name}' not found in schema.")
        return rows

    def _column_def(self, table_name: str, column_name: str) -> dict:
        schema = self._table_schema(table_name)
        for col in schema:
            if col["column_name"] == column_name:
                return col
        raise ColumnNotFoundError(f"Column '{column_name}' not found in table '{table_name}'.")

    def _next_auto_increment(self, table_name: str, pk_col: str) -> int:
        """Return max(pk_col) + 1 from the data sheet, or 1 if empty."""
        records = self._get_table_records(table_name)
        if not records:
            return 1
        values = [r.get(pk_col) for r in records if r.get(pk_col) not in ("", None)]
        int_values = []
        for v in values:
            try:
                int_values.append(int(v))
            except (ValueError, TypeError):
                pass
        return max(int_values, default=0) + 1

    def _find_schema_row_index(self, table_name: str, column_name: str) -> int:
        """Return 1-based row index in the schema sheet for a given table/column pair."""
        records = self._schema_rows()
        for i, row in enumerate(records, start=2):  # row 1 is header
            if row["table_name"] == table_name and row["column_name"] == column_name:
                return i
        raise ColumnNotFoundError(f"No schema row for {table_name}.{column_name}")

    def _data_row_indices(self, table_name: str, where: Optional[dict] = None) -> list[int]:
        """
        Return 1-based row indices in the data sheet that match 'where'.
        Row 1 is the header row, so data starts at row 2.
        """
        all_rows = self._get_table_records(table_name)
        schema = self._table_schema(table_name)
        col_types = {c["column_name"]: c["data_type"] for c in schema}

        matched = []
        for i, row in enumerate(all_rows, start=2):
            if where is None:
                matched.append(i)
                continue
            match = True
            for k, v in where.items():
                cell_val = _cast(str(row.get(k, "")), col_types.get(k, "STRING"))
                if cell_val != v:
                    match = False
                    break
            if match:
                matched.append(i)
        return matched

    def _validate_row(self, table_name: str, row: dict, is_insert: bool = True):
        """Enforce NOT NULL, type checks, PK uniqueness, FK integrity."""
        schema = self._table_schema(table_name)
        pk_cols = [c for c in schema if _truthy(c["primary_key"])]

        for col in schema:
            col_name = col["column_name"]
            data_type = col["data_type"]
            nullable = _truthy(col["nullable"])
            auto_inc = _truthy(col["auto_increment"])
            default = col["default"]
            fk_table = col["foreign_key_table"]
            fk_col = col["foreign_key_column"]

            val = row.get(col_name)

            # Skip auto-increment PKs on insert
            if auto_inc and val is None:
                continue

            # Apply default
            if val is None and default not in ("", None):
                row[col_name] = default
                val = default

            # NOT NULL check
            if not nullable and val is None and is_insert:
                if not auto_inc:
                    raise ConstraintError(f"Column '{col_name}' cannot be NULL.")

            # Type coercion / validation
            if val is not None:
                try:
                    _cast(str(val), data_type)
                except (ValueError, TypeError):
                    raise ConstraintError(
                        f"Value '{val}' is invalid for column '{col_name}' (type {data_type})."
                    )

            # FK check
            if fk_table and fk_col and val is not None:
                ref_records = self._get_table_records(fk_table)
                ref_values = [str(r.get(fk_col, "")) for r in ref_records]
                if str(val) not in ref_values:
                    raise ForeignKeyError(
                        f"Foreign key violation: '{col_name}'='{val}' not found in "
                        f"{fk_table}.{fk_col}."
                    )

        # PK uniqueness on insert
        if is_insert and pk_cols:
            existing = self._get_table_records(table_name)
            for pk_col in pk_cols:
                if _truthy(pk_col["auto_increment"]):
                    continue
                pk_name = pk_col["column_name"]
                new_val = str(row.get(pk_name, ""))
                for ex in existing:
                    if str(ex.get(pk_name, "")) == new_val:
                        raise ConstraintError(
                            f"Duplicate entry '{new_val}' for primary key '{pk_name}'."
                        )

    def _check_fk_delete(self, table_name: str, row: dict):
        """
        Before deleting a row, check no other table references this row's PK values.
        """
        all_schema = self._schema_rows()  # cached
        # Find any column in any other table that FK-references this table
        for col in all_schema:
            if col["foreign_key_table"] == table_name and col["foreign_key_column"]:
                ref_table = col["table_name"]
                ref_col = col["column_name"]
                fk_target_col = col["foreign_key_column"]
                pk_val = str(row.get(fk_target_col, ""))
                if not pk_val:
                    continue
                ref_records = self._get_table_records(ref_table)
                for ref_row in ref_records:
                    if str(ref_row.get(ref_col, "")) == pk_val:
                        raise ForeignKeyError(
                            f"Cannot delete: row is referenced by {ref_table}.{ref_col}."
                        )

    # ------------------------------------------------------------------
    # Table operations
    # ------------------------------------------------------------------

    def create_table(self, table_name: str, columns: list[dict], if_not_exists: bool = False):
        """
        Create a new table (worksheet + schema entries).

        Args:
            table_name: Name of the new table.
            columns: List of column definitions. Each dict may contain:
                - name (str, required)
                - type (str): STRING | INTEGER | FLOAT | BOOLEAN | DATE  [default: STRING]
                - primary_key (bool)
                - auto_increment (bool)  – only valid on INTEGER PKs
                - nullable (bool)        [default: True]
                - default (any)
                - foreign_key: {"table": "...", "column": "..."}
            if_not_exists: Silently skip if table already exists.

        Example:
            db.create_table("orders", [
                {"name": "id",      "type": "INTEGER", "primary_key": True, "auto_increment": True},
                {"name": "user_id", "type": "INTEGER", "nullable": False,
                 "foreign_key": {"table": "users", "column": "id"}},
                {"name": "total",   "type": "FLOAT",   "default": 0.0},
            ])
        """
        existing_titles = [ws.title for ws in self._spreadsheet.worksheets()]
        if table_name in existing_titles:
            if if_not_exists:
                return
            raise TableExistsError(f"Table '{table_name}' already exists.")
        if table_name == SCHEMA_SHEET:
            raise GSheetDBError(f"'{SCHEMA_SHEET}' is reserved.")

        # Validate column defs
        col_names = []
        for col in columns:
            if "name" not in col:
                raise GSheetDBError("Each column must have a 'name'.")
            dtype = col.get("type", "STRING").upper()
            if dtype not in VALID_TYPES:
                raise GSheetDBError(f"Unknown type '{dtype}'. Valid: {VALID_TYPES}")
            col["type"] = dtype
            col_names.append(col["name"])

        # Create worksheet with header row
        ws = self._spreadsheet.add_worksheet(title=table_name, rows=1000, cols=max(len(columns), 10))
        ws.append_row(col_names)

        # Write schema entries
        schema_ws = self._schema_sheet()
        for col in columns:
            fk = col.get("foreign_key", {}) or {}
            schema_ws.append_row([
                table_name,
                col["name"],
                col.get("type", "STRING"),
                str(col.get("primary_key", False)).upper(),
                str(col.get("auto_increment", False)).upper(),
                str(col.get("nullable", True)).upper(),
                str(col.get("default", "")),
                fk.get("table", ""),
                fk.get("column", ""),
            ])
        self._invalidate_schema()

    def drop_table(self, table_name: str, if_exists: bool = False):
        """
        Delete a table and remove its schema entries.

        Args:
            table_name: Table to drop.
            if_exists: Silently skip if table does not exist.
        """
        try:
            ws = self._get_worksheet(table_name)
        except TableNotFoundError:
            if if_exists:
                return
            raise

        self._spreadsheet.del_worksheet(ws)

        # Remove schema rows
        schema_ws = self._schema_sheet()
        records = self._schema_rows()
        rows_to_delete = [
            i + 2  # 1-based, skip header
            for i, r in enumerate(records)
            if r["table_name"] == table_name
        ]
        for row_idx in reversed(rows_to_delete):
            schema_ws.delete_rows(row_idx)
        self._invalidate_schema()
        self._invalidate_table(table_name)

    def show_tables(self) -> list[str]:
        """Return a list of all user table names (excludes __schema__)."""
        return [ws.title for ws in self._spreadsheet.worksheets() if ws.title != SCHEMA_SHEET]

    def describe_table(self, table_name: str) -> list[dict]:
        """
        Return column definitions for a table, similar to MySQL DESCRIBE.

        Returns list of dicts with keys:
            column_name, data_type, primary_key, auto_increment,
            nullable, default, foreign_key_table, foreign_key_column
        """
        return self._table_schema(table_name)

    def rename_table(self, old_name: str, new_name: str):
        """Rename a table (worksheet + all schema references)."""
        ws = self._get_worksheet(old_name)
        existing = [w.title for w in self._spreadsheet.worksheets()]
        if new_name in existing:
            raise TableExistsError(f"A table named '{new_name}' already exists.")
        ws.update_title(new_name)

        # Update schema rows: table_name column (col A = index 1)
        schema_ws = self._schema_sheet()
        records = self._schema_rows()
        for i, row in enumerate(records, start=2):
            if row["table_name"] == old_name:
                schema_ws.update_cell(i, 1, new_name)
            # Also update any FK references pointing at old_name
            if row["foreign_key_table"] == old_name:
                schema_ws.update_cell(i, 8, new_name)
        self._invalidate_schema()

    # ------------------------------------------------------------------
    # Column operations
    # ------------------------------------------------------------------

    def add_column(self, table_name: str, column: dict):
        """
        Add a column to an existing table.

        Args:
            table_name: Target table.
            column: Column definition dict (same format as create_table columns).

        Note: Existing rows will have an empty value for the new column.
        """
        schema = self._table_schema(table_name)
        col_names = [c["column_name"] for c in schema]
        if column["name"] in col_names:
            raise GSheetDBError(f"Column '{column['name']}' already exists in '{table_name}'.")

        dtype = column.get("type", "STRING").upper()
        if dtype not in VALID_TYPES:
            raise GSheetDBError(f"Unknown type '{dtype}'.")
        column["type"] = dtype

        # Append header to data sheet
        ws = self._get_worksheet(table_name)
        headers = list(self._get_table_headers(table_name))
        headers.append(column["name"])
        ws.update("1:1", [headers])
        self._invalidate_table(table_name)

        # Append schema row
        fk = column.get("foreign_key", {}) or {}
        self._schema_sheet().append_row([
            table_name,
            column["name"],
            dtype,
            str(column.get("primary_key", False)).upper(),
            str(column.get("auto_increment", False)).upper(),
            str(column.get("nullable", True)).upper(),
            str(column.get("default", "")),
            fk.get("table", ""),
            fk.get("column", ""),
        ])

    def drop_column(self, table_name: str, column_name: str):
        """
        Remove a column from a table.

        Args:
            table_name: Target table.
            column_name: Column to remove.
        """
        ws = self._get_worksheet(table_name)
        headers = self._get_table_headers(table_name)
        if column_name not in headers:
            raise ColumnNotFoundError(f"Column '{column_name}' not found in '{table_name}'.")

        col_idx = headers.index(column_name) + 1  # 1-based
        ws.delete_columns(col_idx)
        self._invalidate_table(table_name)

        # Remove from schema
        row_idx = self._find_schema_row_index(table_name, column_name)
        self._schema_sheet().delete_rows(row_idx)

    def rename_column(self, table_name: str, old_name: str, new_name: str):
        """
        Rename a column.

        Args:
            table_name: Target table.
            old_name: Current column name.
            new_name: New column name.
        """
        ws = self._get_worksheet(table_name)
        headers = self._get_table_headers(table_name)
        if old_name not in headers:
            raise ColumnNotFoundError(f"Column '{old_name}' not found in '{table_name}'.")
        if new_name in headers:
            raise GSheetDBError(f"Column '{new_name}' already exists.")

        col_idx = headers.index(old_name) + 1
        ws.update_cell(1, col_idx, new_name)
        self._invalidate_table(table_name)

        # Update schema
        row_idx = self._find_schema_row_index(table_name, old_name)
        self._schema_sheet().update_cell(row_idx, 2, new_name)

        # Update any FK references pointing at this column in other tables
        schema_ws = self._schema_sheet()
        all_rows = self._schema_rows()
        for i, row in enumerate(all_rows, start=2):
            if row["foreign_key_table"] == table_name and row["foreign_key_column"] == old_name:
                schema_ws.update_cell(i, 9, new_name)
        self._invalidate_schema()

    def modify_column(self, table_name: str, column_name: str, updates: dict):
        """
        Modify column properties (type, nullable, default, foreign_key, etc.).

        Args:
            table_name: Target table.
            column_name: Column to modify.
            updates: Dict of properties to change. Keys:
                type, nullable, default, primary_key, auto_increment,
                foreign_key (dict with 'table' and 'column', or None to remove)

        Example:
            db.modify_column("users", "age", {"nullable": False, "default": 18})
        """
        row_idx = self._find_schema_row_index(table_name, column_name)
        schema_ws = self._schema_sheet()

        col_map = {
            "data_type": 3, "primary_key": 4, "auto_increment": 5,
            "nullable": 6, "default": 7, "foreign_key_table": 8, "foreign_key_column": 9,
        }

        for key, val in updates.items():
            if key == "type":
                dtype = val.upper()
                if dtype not in VALID_TYPES:
                    raise GSheetDBError(f"Unknown type '{dtype}'.")
                schema_ws.update_cell(row_idx, col_map["data_type"], dtype)
            elif key in ("nullable", "primary_key", "auto_increment"):
                schema_ws.update_cell(row_idx, col_map[key], str(bool(val)).upper())
            elif key == "default":
                schema_ws.update_cell(row_idx, col_map["default"], str(val) if val is not None else "")
            elif key == "foreign_key":
                if val is None:
                    schema_ws.update_cell(row_idx, col_map["foreign_key_table"], "")
                    schema_ws.update_cell(row_idx, col_map["foreign_key_column"], "")
                else:
                    schema_ws.update_cell(row_idx, col_map["foreign_key_table"], val.get("table", ""))
                    schema_ws.update_cell(row_idx, col_map["foreign_key_column"], val.get("column", ""))
            else:
                raise GSheetDBError(f"Unknown column property: '{key}'")

    # ------------------------------------------------------------------
    # DML: INSERT / SELECT / UPDATE / DELETE
    # ------------------------------------------------------------------

    def insert(self, table_name: str, row: dict) -> dict:
        """
        Insert a row into a table.

        Auto-increment PKs are assigned automatically and must NOT be included
        in the row dict (or set to None).

        Args:
            table_name: Target table.
            row: Dict of {column_name: value}.

        Returns:
            The inserted row with all values (including auto-assigned PK).

        Example:
            db.insert("users", {"email": "bob@example.com", "age": 25})
        """
        schema = self._table_schema(table_name)
        row = dict(row)  # don't mutate caller's dict

        # Assign auto-increment PKs
        for col in schema:
            if _truthy(col["auto_increment"]) and _truthy(col["primary_key"]):
                col_name = col["column_name"]
                if row.get(col_name) is None:
                    row[col_name] = self._next_auto_increment(table_name, col_name)

        self._validate_row(table_name, row, is_insert=True)

        ws = self._get_worksheet(table_name)
        headers = self._get_table_headers(table_name)
        new_row = [row.get(h, "") if row.get(h, "") != "" else "" for h in headers]
        ws.append_row(new_row, value_input_option="USER_ENTERED")
        self._invalidate_table(table_name)   # cache stale after write
        return row

    def select(
        self,
        table_name: str,
        columns: Optional[list[str]] = None,
        where: Optional[dict] = None,
        order_by: Optional[str] = None,
        descending: bool = False,
        limit: Optional[int] = None,
    ) -> list[dict]:
        """
        Query rows from a table.

        Args:
            table_name: Source table.
            columns: Columns to return; None means all (*).
            where: Dict of {column: value} equality filters (AND logic).
            order_by: Column name to sort by.
            descending: Sort direction.
            limit: Maximum rows to return.

        Returns:
            List of dicts.

        Example:
            db.select("users", columns=["id", "email"], where={"age": 30}, order_by="id")
        """
        schema = self._table_schema(table_name)
        col_types = {c["column_name"]: c["data_type"] for c in schema}

        all_rows = self._get_table_records(table_name)

        # Filter
        results = []
        for row in all_rows:
            if where:
                match = True
                for k, v in where.items():
                    cell = _cast(str(row.get(k, "")), col_types.get(k, "STRING"))
                    if cell != v:
                        match = False
                        break
                if not match:
                    continue
            # Cast all values to proper types
            cast_row = {k: _cast(str(v), col_types.get(k, "STRING")) for k, v in row.items()}
            results.append(cast_row)

        # Sort
        if order_by:
            results.sort(key=lambda r: (r.get(order_by) is None, r.get(order_by)), reverse=descending)

        # Limit
        if limit is not None:
            results = results[:limit]

        # Project columns
        if columns:
            results = [{c: r.get(c) for c in columns} for r in results]

        return results

    def update(self, table_name: str, set_values: dict, where: Optional[dict] = None) -> int:
        """
        Update rows in a table.

        Args:
            table_name: Target table.
            set_values: Dict of {column: new_value}.
            where: Optional filter (AND logic).

        Returns:
            Number of rows updated.

        Example:
            db.update("users", set_values={"age": 31}, where={"email": "alice@example.com"})
        """
        ws = self._get_worksheet(table_name)
        headers = self._get_table_headers(table_name)
        schema = self._table_schema(table_name)
        col_types = {c["column_name"]: c["data_type"] for c in schema}

        # FK and type-check set_values
        for k, v in set_values.items():
            if k not in headers:
                raise ColumnNotFoundError(f"Column '{k}' not found in '{table_name}'.")

        row_indices = self._data_row_indices(table_name, where)

        for row_idx in row_indices:
            for col_name, new_val in set_values.items():
                col_idx = headers.index(col_name) + 1
                ws.update_cell(row_idx, col_idx, new_val if new_val is not None else "",
                               value_input_option="USER_ENTERED")

        self._invalidate_table(table_name)   # cache stale after write
        return len(row_indices)

    def delete(self, table_name: str, where: Optional[dict] = None) -> int:
        """
        Delete rows from a table.

        Args:
            table_name: Target table.
            where: Optional filter. If None, deletes ALL rows (TRUNCATE behaviour).

        Returns:
            Number of rows deleted.

        Example:
            db.delete("users", where={"id": 3})
        """
        ws = self._get_worksheet(table_name)
        all_rows = self._get_table_records(table_name)
        schema = self._table_schema(table_name)
        col_types = {c["column_name"]: c["data_type"] for c in schema}

        row_indices = self._data_row_indices(table_name, where)

        # FK-on-delete check (collect actual row data first)
        for row_idx in row_indices:
            row_data = all_rows[row_idx - 2]  # -2: header offset + 0-based
            self._check_fk_delete(table_name, row_data)

        # Delete in reverse order to preserve indices
        for row_idx in reversed(row_indices):
            ws.delete_rows(row_idx)

        self._invalidate_table(table_name)   # cache stale after write
        return len(row_indices)

    # ------------------------------------------------------------------
    # Joins (basic INNER / LEFT)
    # ------------------------------------------------------------------

    def join(
        self,
        left_table: str,
        right_table: str,
        on: tuple[str, str],
        join_type: str = "INNER",
        where: Optional[dict] = None,
        columns: Optional[list[str]] = None,
    ) -> list[dict]:
        """
        Perform a basic JOIN between two tables.

        Args:
            left_table: Left (primary) table name.
            right_table: Right (secondary) table name.
            on: Tuple of (left_column, right_column) to join on.
            join_type: 'INNER' or 'LEFT'.
            where: Optional post-join filter.
            columns: Optional list of 'table.column' or bare 'column' to project.

        Returns:
            List of merged dicts. Columns from right_table are prefixed with
            '{right_table}.' when they clash with left_table columns.

        Example:
            db.join("orders", "users", on=("user_id", "id"), join_type="LEFT",
                    columns=["orders.id", "users.email", "total"])
        """
        join_type = join_type.upper()
        if join_type not in ("INNER", "LEFT"):
            raise GSheetDBError("join_type must be 'INNER' or 'LEFT'.")

        left_rows = self.select(left_table)
        right_rows = self.select(right_table)
        left_col, right_col = on

        # Build lookup from right table
        right_lookup: dict[Any, list[dict]] = {}
        for rr in right_rows:
            key = rr.get(right_col)
            right_lookup.setdefault(key, []).append(rr)

        left_schema_cols = {c["column_name"] for c in self._table_schema(left_table)}
        right_schema_cols = {c["column_name"] for c in self._table_schema(right_table)}
        clashes = left_schema_cols & right_schema_cols

        results = []
        for lr in left_rows:
            key = lr.get(left_col)
            matches = right_lookup.get(key, [])
            if not matches:
                if join_type == "LEFT":
                    merged = dict(lr)
                    for rc in right_schema_cols:
                        merged_key = f"{right_table}.{rc}" if rc in clashes else rc
                        merged[merged_key] = None
                    results.append(merged)
                # INNER: skip
                continue
            for rr in matches:
                merged = dict(lr)
                for k, v in rr.items():
                    merged_key = f"{right_table}.{k}" if k in clashes else k
                    merged[merged_key] = v
                results.append(merged)

        # Post-join where filter
        if where:
            results = [r for r in results if all(r.get(k) == v for k, v in where.items())]

        # Project columns
        if columns:
            results = [{c: r.get(c) for c in columns} for r in results]

        return results

    # ------------------------------------------------------------------
    # Utility
    # ------------------------------------------------------------------

    def truncate(self, table_name: str):
        """Delete all data rows from a table (keep headers and schema)."""
        self.delete(table_name, where=None)

    def count(self, table_name: str, where: Optional[dict] = None) -> int:
        """Return the number of rows matching the optional filter."""
        return len(self.select(table_name, where=where))

    def raw_sheet(self, table_name: str) -> gspread.Worksheet:
        """Escape hatch: return the raw gspread Worksheet object for a table."""
        return self._get_worksheet(table_name)

    # ------------------------------------------------------------------
    # Integrity check & repair
    # ------------------------------------------------------------------

    def verify_integrity(self, verbose: bool = True) -> dict:
        """
        Check consistency between the __schema__ sheet and the actual worksheets.
        Returns a report dict and optionally prints a human-readable summary.

        Checks performed:
            1. Schema columns are all present and in order in the data sheet
            2. No columns in the data sheet are missing from the schema
            3. FK target tables and columns actually exist
            4. No duplicate column definitions in schema for the same table
            5. Auto-increment PKs have no duplicate or non-integer values
            6. NOT NULL columns have no empty cells in the data sheet
            7. Tables registered in schema have a matching worksheet (and vice-versa)

        Returns:
            {
                "ok": bool,
                "errors": [str, ...],    # things that are definitely broken
                "warnings": [str, ...],  # things that are suspicious but not fatal
            }
        """
        self.invalidate_cache()   # always read fresh from the sheet for this check
        errors   = []
        warnings = []

        worksheet_titles = {ws.title for ws in self._spreadsheet.worksheets()} - {SCHEMA_SHEET}
        schema_rows      = self._schema_rows(force=True)
        schema_tables    = {}   # table_name → [col_defs]
        for row in schema_rows:
            schema_tables.setdefault(row["table_name"], []).append(row)

        # ── 1. Tables in schema but no worksheet ──────────────────────
        for tname in schema_tables:
            if tname not in worksheet_titles:
                errors.append(f"[MISSING WORKSHEET] '{tname}' is in schema but has no worksheet.")

        # ── 2. Worksheets with no schema entry ────────────────────────
        for title in worksheet_titles:
            if title not in schema_tables:
                warnings.append(f"[ORPHAN WORKSHEET] '{title}' has a worksheet but no schema entry.")

        # ── Per-table checks ──────────────────────────────────────────
        for tname, col_defs in schema_tables.items():
            if tname not in worksheet_titles:
                continue  # already reported above

            headers = self._get_table_headers(tname, force=True)
            records = self._get_table_records(tname, force=True)

            schema_col_names = [c["column_name"] for c in col_defs]

            # ── 3. Duplicate column names in schema ───────────────────
            seen = set()
            for cname in schema_col_names:
                if cname in seen:
                    errors.append(f"[DUPLICATE SCHEMA COL] '{tname}.{cname}' appears more than once in schema.")
                seen.add(cname)

            # ── 4. Schema columns missing from worksheet header ───────
            for cname in schema_col_names:
                if cname not in headers:
                    errors.append(f"[MISSING HEADER] '{tname}.{cname}' is in schema but not in worksheet header.")

            # ── 5. Worksheet columns missing from schema ───────────────
            for h in headers:
                if h not in schema_col_names:
                    warnings.append(f"[EXTRA HEADER] '{tname}.{h}' is in worksheet but not in schema.")

            # ── 6. Column order mismatch ──────────────────────────────
            ws_order     = [h for h in headers if h in schema_col_names]
            schema_order = [c for c in schema_col_names if c in headers]
            if ws_order != schema_order:
                warnings.append(
                    f"[COL ORDER] '{tname}' column order differs between schema and worksheet.\n"
                    f"  schema : {schema_order}\n"
                    f"  worksheet: {ws_order}"
                )

            # ── Per-column data checks ────────────────────────────────
            for col in col_defs:
                cname    = col["column_name"]
                dtype    = col["data_type"]
                nullable = _truthy(col["nullable"])
                auto_inc = _truthy(col["auto_increment"])
                is_pk    = _truthy(col["primary_key"])
                fk_table = col.get("foreign_key_table", "")
                fk_col   = col.get("foreign_key_column", "")

                if cname not in headers:
                    continue  # already reported

                col_values = [r.get(cname) for r in records]

                # ── 7. NOT NULL check ─────────────────────────────────
                if not nullable:
                    empty_rows = [i + 2 for i, v in enumerate(col_values)
                                  if v is None or str(v).strip() == ""]
                    if empty_rows:
                        errors.append(
                            f"[NOT NULL] '{tname}.{cname}' has empty values at rows: {empty_rows}"
                        )

                # ── 8. Type validation ────────────────────────────────
                if dtype in ("INTEGER", "FLOAT"):
                    bad_rows = []
                    for i, v in enumerate(col_values):
                        if v is None or str(v).strip() == "":
                            continue
                        try:
                            int(float(str(v))) if dtype == "INTEGER" else float(str(v))
                        except (ValueError, TypeError):
                            bad_rows.append(i + 2)
                    if bad_rows:
                        errors.append(
                            f"[TYPE] '{tname}.{cname}' ({dtype}) has non-numeric values at rows: {bad_rows}"
                        )

                # ── 9. PK uniqueness + auto-increment integrity ───────
                if is_pk:
                    non_empty = [str(v) for v in col_values if str(v).strip() != ""]
                    if len(non_empty) != len(set(non_empty)):
                        errors.append(f"[PK DUPLICATE] '{tname}.{cname}' has duplicate primary key values.")
                    if auto_inc:
                        non_int = [v for v in non_empty
                                   if not str(v).lstrip("-").isdigit()]
                        if non_int:
                            warnings.append(
                                f"[AUTO_INC] '{tname}.{cname}' has non-integer PK values: {non_int}"
                            )

                # ── 10. FK target exists ──────────────────────────────
                if fk_table and fk_col:
                    if fk_table not in worksheet_titles:
                        errors.append(
                            f"[FK MISSING TABLE] '{tname}.{cname}' references '{fk_table}' which has no worksheet."
                        )
                    elif fk_table not in schema_tables:
                        warnings.append(
                            f"[FK UNMANAGED] '{tname}.{cname}' references '{fk_table}' which has no schema entry."
                        )
                    else:
                        ref_cols = [c["column_name"] for c in schema_tables[fk_table]]
                        if fk_col not in ref_cols:
                            errors.append(
                                f"[FK MISSING COL] '{tname}.{cname}' references '{fk_table}.{fk_col}' "
                                f"but that column is not in schema."
                            )
                        else:
                            # Referential integrity: every FK value must exist in target
                            ref_records = self._get_table_records(fk_table, force=True)
                            ref_values  = {str(r.get(fk_col, "")) for r in ref_records}
                            bad_refs = [
                                (i + 2, v) for i, v in enumerate(col_values)
                                if v is not None and str(v).strip() != ""
                                and str(v) not in ref_values
                            ]
                            if bad_refs:
                                errors.append(
                                    f"[FK INTEGRITY] '{tname}.{cname}' has values not found in "
                                    f"'{fk_table}.{fk_col}': {bad_refs}"
                                )

        report = {"ok": len(errors) == 0, "errors": errors, "warnings": warnings}

        if verbose:
            self._print_integrity_report(report)

        return report

    def _print_integrity_report(self, report: dict):
        ok       = report["ok"]
        errors   = report["errors"]
        warnings = report["warnings"]

        line = "=" * 60
        print(line)
        print("  GSheetDB Integrity Report")
        print(line)

        if ok and not warnings:
            print("  ✅  All checks passed. Schema is consistent.")
        else:
            if ok:
                print("  ✅  No errors found.")
            else:
                print(f"  ❌  {len(errors)} error(s) found.\n")
                for e in errors:
                    print(f"  ERROR   {e}")

            if warnings:
                print(f"\n  ⚠️   {len(warnings)} warning(s).\n")
                for w in warnings:
                    print(f"  WARN    {w}")

        print(line)

    def repair(self, dry_run: bool = True) -> list[str]:
        """
        Attempt to automatically fix issues found by verify_integrity().

        Repairs attempted:
            - Schema rows for tables whose worksheet was deleted → removed from schema
            - Orphan worksheets with no schema → registered with all-STRING columns
            - Extra worksheet headers not in schema → added to schema as nullable STRING
            - Schema columns missing from worksheet header → appended to worksheet header

        Args:
            dry_run: If True (default), only print what would be done without changing anything.
                     Set to False to actually apply fixes.

        Returns:
            List of action strings describing what was (or would be) done.
        """
        report  = self.verify_integrity(verbose=False)
        actions = []

        worksheet_titles = {ws.title for ws in self._spreadsheet.worksheets()} - {SCHEMA_SHEET}
        schema_rows      = self._schema_rows()
        schema_tables    = {}
        for row in schema_rows:
            schema_tables.setdefault(row["table_name"], []).append(row)

        # Fix 1: remove schema rows for deleted worksheets
        for tname in list(schema_tables):
            if tname not in worksheet_titles:
                actions.append(f"REMOVE schema rows for deleted table '{tname}'")
                if not dry_run:
                    rows_to_del = [
                        i + 2 for i, r in enumerate(schema_rows)
                        if r["table_name"] == tname
                    ]
                    for idx in reversed(rows_to_del):
                        self._schema_sheet().delete_rows(idx)
                    self._invalidate_schema()

        # Fix 2: add schema entries for orphan worksheets
        for title in worksheet_titles:
            if title not in schema_tables:
                headers = self._get_table_headers(title)
                actions.append(
                    f"REGISTER orphan worksheet '{title}' with columns: {headers} (all STRING, nullable)"
                )
                if not dry_run:
                    for h in headers:
                        self._schema_sheet().append_row([
                            title, h, "STRING", "FALSE", "FALSE", "TRUE", "", "", ""
                        ])
                    self._invalidate_schema()

        # Fix 3: schema col missing from worksheet header → append header cell
        for tname, col_defs in schema_tables.items():
            if tname not in worksheet_titles:
                continue
            headers = self._get_table_headers(tname)
            for col in col_defs:
                cname = col["column_name"]
                if cname not in headers:
                    actions.append(f"ADD missing header '{cname}' to worksheet '{tname}'")
                    if not dry_run:
                        headers.append(cname)
                        ws.update("1:1", [headers])

        # Fix 4: extra worksheet header not in schema → add schema row
        for tname, col_defs in schema_tables.items():
            if tname not in worksheet_titles:
                continue
            headers          = self._get_table_headers(tname)
            schema_col_names = {c["column_name"] for c in col_defs}
            for h in headers:
                if h not in schema_col_names:
                    actions.append(
                        f"ADD schema entry for extra column '{tname}.{h}' (STRING, nullable)"
                    )
                    if not dry_run:
                        self._schema_sheet().append_row([
                            tname, h, "STRING", "FALSE", "FALSE", "TRUE", "", "", ""
                        ])
                    self._invalidate_schema()

        # Summary
        prefix = "[DRY RUN] " if dry_run else "[APPLIED] "
        print(f"\n{'=' * 60}")
        print(f"  repair({'dry_run=True' if dry_run else 'dry_run=False'})")
        print(f"{'=' * 60}")
        if not actions:
            print("  Nothing to repair.")
        for a in actions:
            print(f"  {prefix}{a}")
        print(f"{'=' * 60}\n")

        return actions