````md
# uthavu-init

Uthavu developer onboarding utility.

## Installation

```bash
pip install uthavu-init
````

## Usage

```bash
uthavu-init
```

This configures:

* GitLab Package Registry access
* pip.conf
* private framework installation support

## Example

```bash
pip install uthavu-auth==2.0.3
```

```
``` 