from pathlib import Path
from getpass import getpass

GROUP_ID = "113887622"

def setup():

    print("===================================")
    print("UTHAVU DEVELOPER SETUP")
    print("===================================")

    username = input(
        "Enter Deploy Token Username: "
    ).strip()

    password = getpass(
        "Enter Deploy Token Password: "
    ).strip()

    # =========================================
    # CREATE .netrc
    # =========================================

    netrc_path = Path.home() / ".netrc"

    netrc_content = f"""
machine gitlab.com
login {username}
password {password}
"""

    netrc_path.write_text(
        netrc_content.strip()
    )

    netrc_path.chmod(0o600)

    # =========================================
    # CREATE pip.conf
    # =========================================

    pip_dir = Path.home() / ".pip"

    pip_dir.mkdir(exist_ok=True)

    pip_conf = pip_dir / "pip.conf"

    pip_conf.write_text(
f"""
[global]
extra-index-url = https://{username}:{password}@gitlab.com/api/v4/groups/{GROUP_ID}/-/packages/pypi/simple
""".strip()
    )

    print("")
    print("===================================")
    print("Uthavu Registry Configured")
    print("===================================")

    print("")
    print("You can now install private packages.")
    print("")
    print("Example:")
    print("pip install uthavu-auth==2.0.3")


def main():

    setup()