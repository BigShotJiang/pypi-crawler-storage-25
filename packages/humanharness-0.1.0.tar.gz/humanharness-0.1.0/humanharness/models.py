from __future__ import annotations

from typing import Any, Literal
from pydantic import BaseModel, Field
import time

class FunctionDefinition(BaseModel):
    name: str
    description: str | None = None
    parameters: dict[str, Any] = Field(default_factory=dict)


class Tool(BaseModel):
    type: Literal["function"]
    function: FunctionDefinition


class ChatMessage(BaseModel):
    role: Literal[
        "system",
        "developer",
        "user",
        "assistant",
        "tool",
    ]

    content: str | list[dict[str, Any]] | None = None
    name: str | None = None
    tool_call_id: str | None = None
    tool_calls: list[ToolCall] | None = None


class ChatCompletionRequest(BaseModel):
    model: str

    messages: list[ChatMessage]

    tools: list[Tool] | None = None
    tool_choice: str | dict[str, Any] | None = None

    stream: bool = False

    temperature: float | None = 1.0
    top_p: float | None = 1.0
    max_tokens: int | None = None

    metadata: dict[str, str] | None = None

    store: bool = False


class ToolCallFunction(BaseModel):
    name: str
    arguments: str


class ToolCall(BaseModel):
    id: str
    type: Literal["function"] = "function"
    function: ToolCallFunction


class AssistantMessage(BaseModel):
    role: Literal["assistant"] = "assistant"

    content: str | None = None

    tool_calls: list[ToolCall] | None = None


class Choice(BaseModel):
    index: int = 0
    message: AssistantMessage
    finish_reason: Literal[
        "stop",
        "length",
        "tool_calls",
    ]


class Usage(BaseModel):
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int


class ChatCompletionResponse(BaseModel):
    id: str
    object: Literal["chat.completion"] = "chat.completion"
    created: int
    model: str

    choices: list[Choice]

    usage: Usage

class Model(BaseModel):
    id: str

    object: Literal["model"] = "model"

    created: int

    owned_by: str = "nobody"


class ModelListResponse(BaseModel):
    object: Literal["list"] = "list"

    data: list[Model]