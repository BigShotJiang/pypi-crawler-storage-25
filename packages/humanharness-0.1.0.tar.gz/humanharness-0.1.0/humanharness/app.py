from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from ephaptic import Ephaptic
from pathlib import Path
import asyncio
from uuid import uuid4
from typing import TypedDict

from .models import *

app = FastAPI(
    title = "HumanHarness",
    description = "Understand and debug agent harnesses from the model's perspective.",
)

ephaptic = Ephaptic.from_app(app, path='/_ws')

class StoredRequest(TypedDict):
    id: str # uuidv4
    request: ChatCompletionRequest
    promise: asyncio.Future[ChatCompletionResponse]

requests: dict[str, StoredRequest] = {}

@ephaptic.event
class ChatRequest(BaseModel):
    id: str
    request: ChatCompletionRequest

@ephaptic.identity_loader
def load(auth): return 1 # so that all users who load the app will be user '1' so that i can emit events to user '1' . i am purposefully not handling multi-user scenarios

@ephaptic.expose
async def handle_response(id: str, response: ChatCompletionResponse):
    r = requests.get(id)

    if not r: return

    r['promise'].set_result(response)

@app.get("/v1/models")
async def list_models() -> ModelListResponse:
    return ModelListResponse(data=[
        Model(
            id="human",
            created=int(time.time()),
        ),
    ])

@app.post("/v1/chat/completions")
async def create_chat_completion(request: ChatCompletionRequest) -> ChatCompletionResponse:

    payload: StoredRequest = {
        'request': request,
        'promise': asyncio.Future(),
        'id': str(uuid4()),
    }

    requests[payload['id']] = payload

    await ephaptic.to(1).emit(ChatRequest(id=payload['id'], request=request))

    return await payload['promise']

app.mount('/', StaticFiles(directory = (Path(__file__).parent / 'frontend' / 'dist'), html = True))