<script lang="ts">
    import { onMount } from "svelte";
    import { connect } from "@ephaptic/client";
    import type { EphapticService, ChatRequest } from "./lib/schema";

    let client: EphapticService;

    let requests = $state<ChatRequest[]>([]);

    let textDrafts = $state<Record<string, string>>({});
    let toolDrafts = $state<Record<string, string>>({});

    onMount(async () => {
        client = connect({ url: '/_ws' });
        client.on('ChatRequest', req => { requests = [req, ...requests] });
    });

    function guessTokenCount(text: string): number {
        return Math.floor(text.length / 4);
    }

    async function sendTextRes(reqId: string) {
        const textRes = textDrafts[reqId] || '';
        const promptTokens = 0; // where is the prompt even? lol
        const completionTokens = guessTokenCount(textRes);
        
        await client.handle_response(reqId, {
            id: `chatcmpl-human-${Date.now()}`,
            object: 'chat.completion',
            created: Math.floor(Date.now() / 1000),
            model: 'human',
            choices: [{
                index: 0,
                message: {
                    role: 'assistant',
                    content: textRes,
                },
                finish_reason: 'stop',
            }],
            usage: {
                prompt_tokens: promptTokens,
                completion_tokens: completionTokens,
                total_tokens: promptTokens + completionTokens,
            }
        });

        requests = requests.filter(r => r.id !== reqId);
        delete textDrafts[reqId];
    }

    async function sendToolRes(reqId: string, toolName: string) {
        const toolRes = toolDrafts[`${reqId}:${toolName}`] || '{}';
        const promptTokens = 0;
        const completionTokens = guessTokenCount(toolRes);

        await client.handle_response(reqId, {
            id: `chatcmpl-human-${Date.now()}`,
            object: 'chat.completion',
            created: Math.floor(Date.now() / 1000),
            model: 'human',
            choices: [{
                index: 0,
                message: {
                    role: 'assistant',
                    content: null,
                    tool_calls: [{
                        id: `call_${Date.now()}`,
                        type: 'function',
                        function: {
                            name: toolName,
                            arguments: toolRes,
                        },
                    }],
                },
                finish_reason: 'tool_calls',
            }],
            usage: {
                prompt_tokens: promptTokens,
                completion_tokens: completionTokens,
                total_tokens: promptTokens + completionTokens,
            }
        });

        requests = requests.filter(r => r.id !== reqId);
        delete toolDrafts[`${reqId}:${toolName}`];
    }
</script>

<br />

<main class="container">
    {#if requests.length === 0}
        <section class="hero">
            <hgroup>
                <h1>Human Harness</h1>
                <p>Waiting for completion requests...</p>
            </hgroup>
            <p>Set your OpenAI-compatible base URL to <code>{location.href.endsWith('/') ? location.href : location.href + '/'}v1</code>. Any completion requests will appear here instantly.</p>
            <small>Chat Completion URL: <code>{location.href.endsWith('/') ? location.href : location.href + '/'}v1/chat/completions</code>.</small>

            <progress></progress>
        </section>
    {:else}
        <header>
            <h1>Pending Requests ({requests.length})</h1>
        </header>

        {#each requests as req (req.id)}
            <article>
                <header>
                    {#if req.request.model !== 'human'}
                        Model Requested: <strong>{req.request.model}</strong>
                    {/if}
                    <span style="float: right;">ID: <small>{req.id.split('-')[0]}</small></span>
                </header>

                <section class="messages">
                    <h3>History</h3>
                    <div class="chat-box">
                        {#each req.request.messages as msg}
                            <div style="margin-bottom: 1rem;">
                                <strong>
                                    {#if msg.role === 'system' || msg.role === 'developer'}
                                        <mark>System</mark>
                                    {:else if msg.role === 'user'}
                                        👤 User <!-- These emojis were stylistic choices, not vibe coded! -->
                                    {:else if msg.role === 'assistant'}
                                        🤖 Assistant
                                    {:else if msg.role === 'tool'}
                                        🔧 Tool Result
                                    {/if}
                                </strong>

                                <div style="margin-top: 0.5rem;">
                                    {#if Array.isArray(msg.content)}
                                        {#each msg.content as part}
                                            {#if part.type === 'text'}
                                                <p style="white-space: pre-wrap; margin: 0;">{part.text}</p>
                                            {:else if part.type === 'image_url'}
                                                <img src={part.image_url.url} alt="Image content from user." style="max-width: 300px; border-radius: 8px; margin-top: 0.5rem;" />
                                            {/if}
                                        {/each}
                                    {:else if msg.content}
                                        <p style="white-space: pre-wrap; margin: 0; font-family: {msg.role === 'tool' ? 'monospace' : 'inherit'}; font-size: {msg.role === 'tool' ? '0.85em' : '1em'};">{msg.content}</p>
                                    {/if}

                                    {#if msg.tool_calls}
                                        {#each msg.tool_calls as call}
                                            <div class="call">
                                                <small><em>Called tool: <code>{call.function.name}</code> with args: {call.function.arguments}</em></small>
                                            </div>
                                        {/each}
                                    {/if}
                                </div>
                            </div>
                        {/each}
                    </div>
                </section>

                {#if req.request.tools && req.request.tools.length > 0}
                    <section>
                        <h3>Available Tools</h3>
                        <div class="grid">
                            {#each req.request.tools as tool}
                                <details>
                                    <summary role="button" class="secondary outline">
                                        🔧 {tool.function.name}
                                    </summary>
                                    <div class="tool-action">
                                        <p><small>{tool.function.description || 'No description provided.'}</small></p>
                                        
                                        <label>
                                            Arguments
                                            <textarea 
                                                bind:value={toolDrafts[`${req.id}:${tool.function.name}`]} 
                                                placeholder={JSON.stringify(tool.function.parameters, null, 2)}
                                                rows="4"
                                            ></textarea>
                                        </label>
                                        
                                        <button onclick={() => sendToolRes(req.id, tool.function.name)}>
                                            Execute Tool Call
                                        </button>
                                    </div>
                                </details>
                            {/each}
                        </div>
                    </section>
                {/if}

                <footer>
                    <h3>Text Response</h3>
                    <textarea 
                        bind:value={textDrafts[req.id]} 
                        placeholder="Type out your assistant response..." 
                        rows="4"
                    ></textarea>
                    
                    <button onclick={() => sendTextRes(req.id)}>
                        Send Text Response
                    </button>
                </footer>
            </article>
        {/each}
    {/if}
</main>