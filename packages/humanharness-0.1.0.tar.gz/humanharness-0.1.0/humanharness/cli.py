from typer import Typer
import uvicorn
from .app import app

cli = Typer()

@cli.command()
def run(port: int = 8080, host: str = '0.0.0.0', open: bool = False):
    
    if open:
        import webbrowser
        webbrowser.open(f'http://{host}:{port}/')

    uvicorn.run(app, host=host, port=port)