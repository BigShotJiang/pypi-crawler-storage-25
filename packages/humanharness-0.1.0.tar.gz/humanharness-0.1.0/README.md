# HumanHarness
Understand and debug agent harnesses from the model's perspective.

HumanHarness is a quick and easy tool to let you view an agent's harness yourself.

Simply start the app and set your OpenAI-compatible API to `http://localhost:8080/v1` or whatever port you've set.

The twist: instead of using an AI model, there is a web UI which you (probably a human) can visit, and from there, any incoming requests are shown. The full text, system prompt, and chat history. Also, any available tools are shown in the UI as buttons, with parameters you can edit. Finally, when you've finished "thinking" about it, you can type a response back.

The goal here is to be able to look at things like OpenClaw, Pi, Hermes, Claude Code, OpenAI Codex, or any other agentic framework and getting a deeper level of understanding how it works + seeing it from the AI's perspective + being able to have a bit of fun. You can also use it to help you debug model performance in your own agentic harnesses! You can see what the LLM is seeing and optimize parts of the harness (e.g. visible toolset) to help maximise model performance.

## Installation

Quick installation:

```
$ pip install humanharness
```

Or from source:

```
$ gh repo clone uukelele/HumanHarness
$ cd HumanHarness/humanharness/frontend
$ npm i && npm run build
$ cd ../..
$ pip install -e .
```

### Starting the server

```
$ humanharness
```

Starts the web server at port 8080 by default.

To auto-open in browser:

```
$ humanharness --open
```

To set another port / host:

```
$ humanharness --host 0.0.0.0 --port 8081
```

### Use with an agent

Simply set your base URL to the one that appears in the web dashboard.

For example, if using the default settings:

`http://localhost:8080/v1`

The chat completion URL would be `http://localhost:8080/v1/chat/completions`

## Features

- [x] `/v1/chat/completions`
    - [x] Text responses
    - [x] Viewing images
    - [x] JSON-based tool calling
    - [ ] XML-based tool calling
    - [ ] Other forms of multimodal content
- [ ] `/v1/responses