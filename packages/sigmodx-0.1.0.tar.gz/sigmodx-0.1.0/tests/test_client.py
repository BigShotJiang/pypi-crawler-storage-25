# Integration tests — require SIGMODX_API_KEY and SIGMODX_AGENT_ID env vars
# Run with: pytest tests/test_client.py --integration
# Skip in CI unless env vars are set

import os
import pytest
from sigmodx import SigmodxClient

SKIP = not (os.getenv("SIGMODX_API_KEY") and os.getenv("SIGMODX_AGENT_ID"))

@pytest.mark.skipif(SKIP, reason="Integration env vars not set")
def test_hash_inputs_via_client():
    client = SigmodxClient(
        api_key=os.environ["SIGMODX_API_KEY"],
        agent_id=os.environ["SIGMODX_AGENT_ID"]
    )
    result = client.hash_inputs({"invoice_id": "TEST-001", "amount": 100})
    assert result.startswith("sha256:")
    client.close()
