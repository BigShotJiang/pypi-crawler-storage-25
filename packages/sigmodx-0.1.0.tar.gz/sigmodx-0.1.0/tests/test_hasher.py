from sigmodx.hasher import hash_inputs


def test_hash_is_deterministic():
    payload = {"invoice_id": "INV-001", "amount": 32000, "vendor": "Acme"}
    assert hash_inputs(payload) == hash_inputs(payload)


def test_hash_is_order_independent():
    p1 = {"a": 1, "b": 2}
    p2 = {"b": 2, "a": 1}
    assert hash_inputs(p1) == hash_inputs(p2)


def test_different_payloads_produce_different_hashes():
    p1 = {"amount": 32000}
    p2 = {"amount": 32001}
    assert hash_inputs(p1) != hash_inputs(p2)


def test_hash_format():
    result = hash_inputs({"test": "value"})
    assert result.startswith("sha256:")
    assert len(result) == 71  # 'sha256:' (7) + 64 hex chars
