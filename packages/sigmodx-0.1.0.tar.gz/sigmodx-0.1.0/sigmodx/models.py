from dataclasses import dataclass, field
from typing import Optional
from decimal import Decimal


@dataclass
class InvoiceDecision:
    """Parameters for submitting an invoice approval decision to Sigmodx."""
    decision_type: str              # 'approve' | 'reject' | 'escalate'
    input_hash: str                 # from hash_inputs()
    rationale: str                  # min 10 chars, human-readable
    confidence: Optional[float] = None
    invoice_amount: Optional[Decimal] = None
    invoice_currency: str = 'USD'
    vendor_name: Optional[str] = None
    vendor_id: Optional[str] = None
    po_reference: Optional[str] = None
    invoice_reference: Optional[str] = None
    delegated_authority_limit: Optional[Decimal] = None

    def __post_init__(self):
        valid_types = {'approve', 'reject', 'escalate'}
        if self.decision_type not in valid_types:
            raise ValueError(f"decision_type must be one of {valid_types}")
        if len(self.rationale) < 10:
            raise ValueError("rationale must be at least 10 characters")
        if self.confidence is not None and not 0.0 <= self.confidence <= 1.0:
            raise ValueError("confidence must be between 0.0 and 1.0")


@dataclass
class DecisionResult:
    """Result returned after submitting a decision event."""
    decision_event_id: str
    requires_human_approval: bool
    agent_state: str                # 'ALLOW' | 'LIMIT' | 'BLOCK'
    created_at: str
