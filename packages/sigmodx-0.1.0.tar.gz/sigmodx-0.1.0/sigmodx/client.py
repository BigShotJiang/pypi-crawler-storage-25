import httpx
from typing import Optional
from .hasher import hash_inputs as _hash_inputs
from .models import InvoiceDecision, DecisionResult
from .exceptions import SigmodxError, AgentBlockedError


class SigmodxClient:
    """
    Client for the Sigmodx Agent API.

    Usage:
        client = SigmodxClient(
            api_key="your-api-key",
            agent_id="your-agent-uuid"
        )

        input_hash = client.hash_inputs(invoice_payload)
        result = client.submit_invoice_decision(
            decision_type="approve",
            input_hash=input_hash,
            rationale="Invoice matches PO. Vendor in good standing.",
            invoice_amount=32000,
            vendor_id="VENDOR-4821"
        )
    """

    DEFAULT_BASE_URL = "https://api.sigmodx.com"

    def __init__(
        self,
        api_key: str,
        agent_id: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 10.0
    ):
        self.api_key = api_key
        self.agent_id = agent_id
        self.base_url = base_url.rstrip('/')
        self._client = httpx.Client(
            base_url=self.base_url,
            headers={
                "Authorization": f"Bearer {api_key}",
                "User-Agent": f"sigmodx-python/0.1.0",
                "Content-Type": "application/json"
            },
            timeout=timeout
        )

    def hash_inputs(self, payload: dict) -> str:
        """
        Hash an agent input payload deterministically.
        Use this before submitting a decision to create an
        auditable fingerprint of what the agent consumed.
        The payload itself is never sent to Sigmodx.
        """
        return _hash_inputs(payload)

    def submit_invoice_decision(
        self,
        decision_type: str,
        input_hash: str,
        rationale: str,
        confidence: Optional[float] = None,
        invoice_amount=None,
        invoice_currency: str = 'USD',
        vendor_name: Optional[str] = None,
        vendor_id: Optional[str] = None,
        po_reference: Optional[str] = None,
        invoice_reference: Optional[str] = None,
        delegated_authority_limit=None
    ) -> DecisionResult:
        """Submit an invoice approval decision event to Sigmodx."""
        decision = InvoiceDecision(
            decision_type=decision_type,
            input_hash=input_hash,
            rationale=rationale,
            confidence=confidence,
            invoice_amount=invoice_amount,
            invoice_currency=invoice_currency,
            vendor_name=vendor_name,
            vendor_id=vendor_id,
            po_reference=po_reference,
            invoice_reference=invoice_reference,
            delegated_authority_limit=delegated_authority_limit
        )

        payload = {k: v for k, v in {
            "decision_type": decision.decision_type,
            "input_hash": decision.input_hash,
            "rationale": decision.rationale,
            "confidence": decision.confidence,
            "invoice_amount": float(decision.invoice_amount)
                if decision.invoice_amount else None,
            "invoice_currency": decision.invoice_currency,
            "vendor_name": decision.vendor_name,
            "vendor_id": decision.vendor_id,
            "po_reference": decision.po_reference,
            "invoice_reference": decision.invoice_reference,
            "delegated_authority_limit": float(decision.delegated_authority_limit)
                if decision.delegated_authority_limit else None,
        }.items() if v is not None}

        response = self._client.post(
            f"/agents/{self.agent_id}/decisions/invoice",
            json=payload
        )

        if response.status_code == 403:
            data = response.json()
            raise AgentBlockedError(data.get('detail') or data.get('error'))
        if response.status_code not in (200, 201):
            raise SigmodxError(
                f"Unexpected response {response.status_code}: {response.text}"
            )

        data = response.json()
        return DecisionResult(
            decision_event_id=data['decision_event_id'],
            requires_human_approval=data['requires_human_approval'],
            agent_state=data['agent_state'],
            created_at=data['created_at']
        )

    def record_outcome(
        self,
        decision_event_id: str,
        outcome: str,
        outcome_note: Optional[str] = None
    ) -> dict:
        """
        Record the post-facto outcome of a decision.
        Call this after the invoice has been processed, reversed, or disputed.

        outcome: 'processed' | 'rejected' | 'reversed' | 'disputed'
        """
        valid_outcomes = {'processed', 'rejected', 'reversed', 'disputed'}
        if outcome not in valid_outcomes:
            raise ValueError(f"outcome must be one of {valid_outcomes}")

        payload = {"outcome": outcome}
        if outcome_note:
            payload["outcome_note"] = outcome_note

        response = self._client.post(
            f"/decisions/{decision_event_id}/outcome",
            json=payload
        )
        if response.status_code == 409:
            raise SigmodxError("Outcome is already recorded and cannot be changed.")
        response.raise_for_status()
        return response.json()

    def get_reliability(self) -> dict:
        """Get the agent's current reliability state for the invoice scenario."""
        response = self._client.get(
            f"/agents/{self.agent_id}/reliability/invoice"
        )
        response.raise_for_status()
        return response.json()

    def close(self):
        self._client.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
