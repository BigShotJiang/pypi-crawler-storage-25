class SigmodxError(Exception):
    """Base exception for Sigmodx SDK errors."""
    pass


class AgentBlockedError(SigmodxError):
    """
    Raised when the agent's current state is BLOCK.
    The agent is not permitted to submit decisions or execute transactions.
    """
    def __init__(self, reason: str = None):
        self.reason = reason
        super().__init__(
            f"Agent is currently BLOCK{f': {reason}' if reason else ''}. "
            "Check the agent's reliability state in your Sigmodx org dashboard."
        )
