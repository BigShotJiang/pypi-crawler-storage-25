import hashlib
import json
from typing import Any


def hash_inputs(payload: dict[str, Any]) -> str:
    """
    Deterministically hash an agent input payload.

    Sorts keys recursively before serializing to ensure identical
    payloads always produce identical hashes regardless of key order.

    Returns a string in the format 'sha256:<hex_digest>'.

    Example:
        input_hash = hash_inputs({
            "invoice_id": "INV-2026-0042",
            "vendor_id": "VENDOR-4821",
            "amount": 32000,
        })
        # Returns: 'sha256:a3f2...'
    """
    canonical = json.dumps(payload, sort_keys=True, ensure_ascii=True,
                           separators=(',', ':'))
    digest = hashlib.sha256(canonical.encode('utf-8')).hexdigest()
    return f"sha256:{digest}"
