# Changelog

## 0.1.0 (2026-05-17)

Initial release.

- `SigmodxClient` with `submit_invoice_decision()`, `record_outcome()`,
  `get_reliability()`, `hash_inputs()`
- `hash_inputs()` standalone utility
- `AgentBlockedError` and `SigmodxError` exceptions
- `InvoiceDecision` and `DecisionResult` dataclasses
