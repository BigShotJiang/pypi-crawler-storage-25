# sigmodx — Python SDK

Python SDK for [Sigmodx](https://sigmodx.com) — audit and verification
infrastructure for AI agents making consequential decisions.

## Installation

```bash
pip install sigmodx
```

## Quickstart

```python
from sigmodx import SigmodxClient

client = SigmodxClient(
    api_key="your-api-key",      # from sigmodx.com org dashboard
    agent_id="your-agent-uuid"   # agent registered in Sigmodx
)

# Hash your agent's inputs before deciding
# Your invoice data never leaves your environment
input_hash = client.hash_inputs({
    "invoice_id": "INV-2026-0042",
    "vendor_id":  "VENDOR-4821",
    "amount":     32000,
    "po_ref":     "PO-4821"
})

# Submit the decision
result = client.submit_invoice_decision(
    decision_type="approve",
    input_hash=input_hash,
    rationale="Invoice matches PO. Vendor in good standing. Within limit.",
    invoice_amount=32000,
    vendor_id="VENDOR-4821"
)

print(result.decision_event_id)   # record this
print(result.agent_state)         # ALLOW | LIMIT | BLOCK
print(result.requires_human_approval)

# Record the outcome later
client.record_outcome(
    decision_event_id=result.decision_event_id,
    outcome="processed"
)
```

## How it works

1. **Hash inputs** — `hash_inputs()` creates a SHA-256 fingerprint of
   what your agent consumed. The raw data never leaves your environment.

2. **Submit decision** — the decision type, hash, and rationale are
   recorded in Sigmodx's append-only audit trail.

3. **Record outcome** — after execution, record what happened. Immutable
   once set.

4. **Attestation** — at the end of each period, your org admin generates
   an attestation. Auditors verify it at sigmodx.com/verify.

## Agent state

If the agent's reliability state is `BLOCK`, `submit_invoice_decision()`
raises `AgentBlockedError`. Handle it explicitly:

```python
from sigmodx import SigmodxClient, AgentBlockedError

try:
    result = client.submit_invoice_decision(...)
except AgentBlockedError as e:
    # Agent is blocked — do not proceed with execution
    log.warning(f"Agent blocked: {e.reason}")
    return escalate_to_human(invoice)
```

## Links

- [Agent API reference](https://sigmodx.com/docs/agent-api)
- [Invoice approval methodology](https://sigmodx.com/docs/methodology/invoice-approval)
- [Verify an attestation](https://sigmodx.com/verify)
- [Request pilot access](https://sigmodx.com/enterprise)
