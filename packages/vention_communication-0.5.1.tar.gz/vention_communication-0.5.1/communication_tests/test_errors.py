"""Tests for error handling and conversion."""

from __future__ import annotations

import asyncio
import unittest

from communication.errors import ConnectError, error_envelope, to_connect_error


class TestConnectError(unittest.TestCase):
    """Tests for ConnectError class."""

    def test_connect_error_initialization(self) -> None:
        """ConnectError initializes with code, message, and optional details."""
        error = ConnectError("invalid_argument", "Invalid input", details=["detail1"])
        self.assertEqual(error.code, "invalid_argument")
        self.assertEqual(error.message, "Invalid input")
        self.assertEqual(error.details, ["detail1"])

    def test_connect_error_default_details(self) -> None:
        """ConnectError defaults to empty details list."""
        error = ConnectError("internal", "Something went wrong")
        self.assertEqual(error.details, [])

    def test_connect_error_inherits_from_exception(self) -> None:
        """ConnectError is a subclass of Exception."""
        error = ConnectError("test", "message")
        self.assertIsInstance(error, Exception)
        self.assertEqual(str(error), "message")


class TestToConnectError(unittest.TestCase):
    """Tests for to_connect_error conversion function."""

    def test_connect_error_passed_through(self) -> None:
        """to_connect_error returns ConnectError as-is."""
        original = ConnectError("test", "message")
        result = to_connect_error(original)
        self.assertIs(result, original)

    def test_timeout_error_mapped_to_deadline_exceeded(self) -> None:
        """asyncio.TimeoutError maps to deadline_exceeded."""
        timeout_error = asyncio.TimeoutError("Operation timed out")
        result = to_connect_error(timeout_error)
        self.assertEqual(result.code, "deadline_exceeded")
        self.assertIn("timed out", result.message)

    def test_key_error_mapped_to_invalid_argument(self) -> None:
        """KeyError maps to invalid_argument."""
        key_error = KeyError("missing_key")
        result = to_connect_error(key_error)
        self.assertEqual(result.code, "invalid_argument")
        self.assertIn("missing_key", result.message)

    def test_value_error_mapped_to_invalid_argument(self) -> None:
        """ValueError maps to invalid_argument."""
        value_error = ValueError("Invalid value")
        result = to_connect_error(value_error)
        self.assertEqual(result.code, "invalid_argument")
        self.assertEqual(result.message, "Invalid value")

    def test_permission_error_mapped_to_permission_denied(self) -> None:
        """PermissionError maps to permission_denied."""
        perm_error = PermissionError("Access denied")
        result = to_connect_error(perm_error)
        self.assertEqual(result.code, "permission_denied")
        self.assertEqual(result.message, "Access denied")

    def test_generic_exception_mapped_to_internal(self) -> None:
        """Generic exceptions map to internal error."""
        runtime_error = RuntimeError("Something broke")
        result = to_connect_error(runtime_error)
        self.assertEqual(result.code, "internal")
        self.assertEqual(result.message, "Something broke")

    def test_exception_without_message_uses_class_name(self) -> None:
        """Exception without message uses class name."""
        error = Exception()
        result = to_connect_error(error)
        self.assertEqual(result.code, "internal")
        self.assertEqual(result.message, "Exception")


class TestErrorEnvelope(unittest.TestCase):
    """Tests for error_envelope function."""

    def test_error_envelope_structure(self) -> None:
        """error_envelope creates correct Connect error envelope structure."""
        error = ConnectError("test_code", "test message", details=["detail1"])
        envelope = error_envelope(error)
        self.assertIn("error", envelope)
        self.assertEqual(envelope["error"]["code"], "test_code")
        self.assertEqual(envelope["error"]["message"], "test message")
        self.assertEqual(envelope["error"]["details"], ["detail1"])

    def test_error_envelope_converts_exception(self) -> None:
        """error_envelope converts regular exceptions to ConnectError."""
        exception = ValueError("Invalid input")
        envelope = error_envelope(exception)
        self.assertEqual(envelope["error"]["code"], "invalid_argument")
        self.assertEqual(envelope["error"]["message"], "Invalid input")

    def test_error_envelope_empty_details(self) -> None:
        """error_envelope includes empty details list when not provided."""
        error = ConnectError("test", "message")
        envelope = error_envelope(error)
        self.assertEqual(envelope["error"]["details"], [])
