"""Integration tests for complete VentionApp workflows."""

from __future__ import annotations

import asyncio
import json
from typing import Any
from unittest.mock import AsyncMock, MagicMock

from fastapi import Request

from communication.app import VentionApp
from communication.decorators import action, stream
from communication.entries import ActionEntry, RpcBundle, StreamEntry
from communication_tests.fixtures import (
    AsyncTestBase,
    SimpleRequest,
    SimpleResponse,
    VentionAppFixture,
    get_route_paths,
    reset_decorator_state,
    wait_for_condition,
)


# ---------- Test Models ----------


class StreamPayload(SimpleResponse):
    """Test payload for streams."""

    pass


# ---------- Test Functions (will be decorated) ----------


# These will be decorated in tests
def ping_handler(req: SimpleRequest) -> SimpleResponse:
    """Ping handler for testing."""
    return SimpleResponse(message=f"Pong: {req.message}", success=True)


async def async_ping_handler(req: SimpleResponse) -> SimpleResponse:
    """Async ping handler for testing."""
    await asyncio.sleep(0.01)
    return SimpleResponse(message=f"Async Pong: {req.message}", success=True)


async def heartbeat_publisher() -> StreamPayload:
    """Heartbeat stream publisher."""
    return StreamPayload(message="heartbeat", success=True)


# ---------- Tests ----------


class TestCompleteActionWorkflow(AsyncTestBase):
    """Test complete action workflow from decorator to router."""

    def setUp(self) -> None:
        """Set up test with fresh state."""
        super().setUp()
        reset_decorator_state()
        self.fixture = VentionAppFixture()

    def tearDown(self) -> None:
        """Clean up fixture."""
        self.fixture.cleanup()
        super().tearDown()

    async def test_action_decorator_to_router_call(self) -> None:
        """Complete workflow: decorator -> app -> router -> handler."""

        # Define action with decorator
        @action(name="ping")
        def ping(req: SimpleRequest) -> SimpleResponse:
            return SimpleResponse(message=f"Pong: {req.message}", success=True)

        # Create app and finalize
        app = VentionApp(name="TestApp")
        app.finalize()

        # Get the handler from router
        route = next(
            r
            for r in app.connect_router.router.routes
            if hasattr(r, "path") and r.path.endswith("/ping")  # type: ignore[attr-defined, unused-ignore]
        )
        handler = route.endpoint  # type: ignore[attr-defined, unused-ignore]

        # Create mock request
        mock_request = MagicMock(spec=Request)
        mock_request.json = AsyncMock(return_value={"message": "Hello"})

        # Call handler
        response = await handler(mock_request)

        # Verify response
        self.assertIsNotNone(response)
        response_body = json.loads(response.body.decode())
        self.assertEqual(response_body["message"], "Pong: Hello")
        self.assertTrue(response_body["success"])

    async def test_multiple_actions_and_streams_workflow(self) -> None:
        """Multiple actions and streams work together in same app."""

        @action(name="action1")
        def action1(req: SimpleRequest) -> SimpleResponse:
            return SimpleResponse(message="action1", success=True)

        @action(name="action2")
        def action2(req: SimpleRequest) -> SimpleResponse:
            return SimpleResponse(message="action2", success=True)

        @stream(name="stream1", payload=StreamPayload)
        async def stream1() -> StreamPayload:
            return StreamPayload(message="beat", success=True)

        # Create app and finalize
        app = VentionApp(name="TestApp")
        app.finalize()

        # Both actions should be registered
        self.assertIn("action1", app.connect_router._unaries)
        self.assertIn("action2", app.connect_router._unaries)
        self.assertIn("stream1", app.connect_router._streams)

        # All routes should exist
        routes = get_route_paths(app.connect_router)
        self.assertTrue(any("/action1" in r for r in routes))
        self.assertTrue(any("/action2" in r for r in routes))
        self.assertTrue(any("/stream1" in r for r in routes))

    async def test_async_action_workflow(self) -> None:
        """Async action handler works in complete workflow."""

        @action(name="async_ping")
        async def async_ping(req: SimpleRequest) -> SimpleResponse:
            await asyncio.sleep(0.01)
            return SimpleResponse(message=f"Async: {req.message}", success=True)

        app = VentionApp(name="TestApp")
        app.finalize()

        # Get handler
        route = next(
            r
            for r in app.connect_router.router.routes
            if hasattr(r, "path") and r.path.endswith("/async_ping")  # type: ignore[attr-defined, unused-ignore]
        )
        handler = route.endpoint  # type: ignore[attr-defined, unused-ignore]

        # Create mock request
        mock_request = MagicMock(spec=Request)
        mock_request.json = AsyncMock(return_value={"message": "test"})

        # Call handler
        response = await handler(mock_request)

        # Verify response
        response_body = json.loads(response.body.decode())
        self.assertEqual(response_body["message"], "Async: test")
        self.assertTrue(response_body["success"])


class TestCompleteStreamWorkflow(AsyncTestBase):
    """Test complete stream workflow from decorator to publishing."""

    def setUp(self) -> None:
        """Set up test with fresh state."""
        super().setUp()
        reset_decorator_state()
        self.fixture = VentionAppFixture()

    def tearDown(self) -> None:
        """Clean up fixture."""
        self.fixture.cleanup()
        super().tearDown()

    async def test_stream_decorator_to_publish(self) -> None:
        """Complete workflow: decorator -> app -> publish."""

        # Define stream with decorator
        @stream(name="heartbeat", payload=StreamPayload)
        async def heartbeat() -> StreamPayload:
            return StreamPayload(message="heartbeat", success=True)

        # Create app and finalize
        app = VentionApp(name="TestApp")
        app.finalize()

        # Stream should be registered
        self.assertIn("heartbeat", app.connect_router._streams)

        # Stream route should exist
        routes = [r.path for r in app.connect_router.router.routes if hasattr(r, "path")]  # type: ignore[attr-defined, unused-ignore]
        self.assertTrue(any("/heartbeat" in r for r in routes))

        # Publish should work (publisher wrapper is available)
        await heartbeat()

        # Wait for value to be stored
        topic = app.connect_router.manager._topics.get("heartbeat")
        assert topic is not None
        topic_dict: dict[str, Any] = topic  # Type narrowing for lambda
        await wait_for_condition(lambda: topic_dict.get("last_value") is not None, timeout=0.5)

        # Verify published value
        self.assertIsNotNone(topic["last_value"])
        self.assertEqual(topic["last_value"].message, "heartbeat")

    async def test_stream_publisher_wrapper_requires_finalize(self) -> None:
        """Stream publisher wrapper requires app.finalize() to be called."""

        @stream(name="test_stream", payload=StreamPayload)
        async def publish_stream() -> StreamPayload:
            return StreamPayload(message="test", success=True)

        # Try to publish before finalize
        app = VentionApp(name="TestApp")
        # Don't call finalize()

        with self.assertRaises(RuntimeError) as context:
            await publish_stream()
        self.assertIn("app.finalize()", str(context.exception))

        # After finalize, should work
        app.finalize()
        await publish_stream()

        # Verify it was published
        topic = app.connect_router.manager._topics.get("test_stream")
        assert topic is not None
        topic_dict: dict[str, Any] = topic  # Type narrowing for lambda
        await wait_for_condition(lambda: topic_dict.get("last_value") is not None, timeout=0.5)


class TestMixedActionsAndStreams(AsyncTestBase):
    """Test apps with both actions and streams."""

    def setUp(self) -> None:
        """Set up test with fresh state."""
        super().setUp()
        reset_decorator_state()
        self.fixture = VentionAppFixture()

    def tearDown(self) -> None:
        """Clean up fixture."""
        self.fixture.cleanup()
        super().tearDown()

    async def test_proto_generation_includes_all_items(self) -> None:
        """Proto generation includes all actions and streams."""

        @action(name="action1")
        def action1(req: SimpleRequest) -> SimpleResponse:
            return SimpleResponse(message="test", success=True)

        @action(name="action2")
        def action2() -> SimpleResponse:
            return SimpleResponse(message="test", success=True)

        @stream(name="stream1", payload=StreamPayload)
        async def stream1() -> StreamPayload:
            return StreamPayload(message="test", success=True)

        @stream(name="stream2", payload=int)
        async def stream2() -> int:
            return 42

        proto_path = self.fixture.get_proto_path("integration.proto")
        app = VentionApp(name="TestApp", emit_proto=True, proto_path=proto_path)
        app.finalize()

        # Check proto file
        proto_content = self.fixture.read_proto_file(proto_path)

        # Should include all actions
        self.assertIn("rpc action1", proto_content)
        self.assertIn("rpc action2", proto_content)

        # Should include all streams
        self.assertIn("rpc stream1", proto_content)
        self.assertIn("rpc stream2", proto_content)

        # Should include message types
        self.assertIn("message SimpleRequest", proto_content)
        self.assertIn("message SimpleResponse", proto_content)
        self.assertIn("message StreamPayload", proto_content)
        self.assertIn("message stream2Message", proto_content)  # Scalar wrapper


class TestExternalBundleIntegration(AsyncTestBase):
    """Test integration with external RpcBundles."""

    def setUp(self) -> None:
        """Set up test with fresh state."""
        super().setUp()
        reset_decorator_state()
        self.fixture = VentionAppFixture()

    def tearDown(self) -> None:
        """Clean up fixture."""
        self.fixture.cleanup()
        super().tearDown()

    async def test_external_bundle_merged_with_decorators(self) -> None:
        """External bundle is merged with decorator-registered items."""

        # Register via decorator
        @action(name="decorated_action")
        def decorated() -> SimpleResponse:
            return SimpleResponse(message="decorated", success=True)

        # Create external bundle
        external_action = ActionEntry(
            name="external_action",
            func=lambda req: SimpleResponse(message="external", success=True),
            input_type=SimpleRequest,
            output_type=SimpleResponse,
        )
        external_bundle = RpcBundle(actions=[external_action], streams=[])

        # Create app, extend bundle, and finalize
        app = VentionApp(name="TestApp")
        app.register_rpc_plugin(external_bundle)
        app.finalize()

        # Both should be registered
        self.assertIn("decorated_action", app.connect_router._unaries)
        self.assertIn("external_action", app.connect_router._unaries)

    async def test_multiple_external_bundles(self) -> None:
        """Multiple external bundles can be added."""
        external_action1 = ActionEntry(
            name="external1",
            func=lambda: SimpleResponse(message="ext1", success=True),
            input_type=None,
            output_type=SimpleResponse,
        )
        external_action2 = ActionEntry(
            name="external2",
            func=lambda: SimpleResponse(message="ext2", success=True),
            input_type=None,
            output_type=SimpleResponse,
        )

        bundle1 = RpcBundle(actions=[external_action1], streams=[])
        bundle2 = RpcBundle(actions=[external_action2], streams=[])

        app = VentionApp(name="TestApp")
        app.register_rpc_plugin(bundle1)
        app.register_rpc_plugin(bundle2)
        app.finalize()

        # Both should be registered
        self.assertIn("external1", app.connect_router._unaries)
        self.assertIn("external2", app.connect_router._unaries)

    async def test_external_bundle_with_streams(self) -> None:
        """External bundle can include streams."""
        external_stream = StreamEntry(
            name="external_stream",
            func=None,
            payload_type=StreamPayload,
        )
        external_bundle = RpcBundle(actions=[], streams=[external_stream])

        app = VentionApp(name="TestApp")
        app.register_rpc_plugin(external_bundle)
        app.finalize()

        # Stream should be registered
        self.assertIn("external_stream", app.connect_router._streams)

        # Can publish to it
        app.connect_router.publish("external_stream", StreamPayload(message="test", success=True))

        # Verify it was published
        topic = app.connect_router.manager._topics.get("external_stream")
        assert topic is not None
        topic_dict: dict[str, Any] = topic  # Type narrowing for lambda
        await wait_for_condition(lambda: topic_dict.get("last_value") is not None, timeout=0.5)


class TestProtoGenerationIntegration(AsyncTestBase):
    """Test proto generation in complete integration scenarios."""

    def setUp(self) -> None:
        """Set up test with fresh state."""
        super().setUp()
        reset_decorator_state()
        self.fixture = VentionAppFixture()

    def tearDown(self) -> None:
        """Clean up fixture."""
        self.fixture.cleanup()
        super().tearDown()

    async def test_proto_includes_decorator_and_external_items(self) -> None:
        """Proto generation includes both decorator and external bundle items."""

        @action(name="decorated")
        def decorated(req: SimpleRequest) -> SimpleResponse:
            return SimpleResponse(message="test", success=True)

        external_action = ActionEntry(
            name="external",
            func=lambda req: SimpleResponse(message="ext", success=True),
            input_type=SimpleRequest,
            output_type=SimpleResponse,
        )
        external_bundle = RpcBundle(actions=[external_action], streams=[])

        proto_path = self.fixture.get_proto_path("mixed.proto")
        app = VentionApp(name="TestApp", emit_proto=True, proto_path=proto_path)
        app.register_rpc_plugin(external_bundle)
        app.finalize()

        # Check proto includes both
        proto_content = self.fixture.read_proto_file(proto_path)
        self.assertIn("rpc decorated", proto_content)
        self.assertIn("rpc external", proto_content)

    async def test_proto_service_name_from_app_name(self) -> None:
        """Proto service name is derived from app name."""

        @action(name="test_action")
        def test() -> SimpleResponse:
            return SimpleResponse(message="test", success=True)

        proto_path = self.fixture.get_proto_path("service_name.proto")
        app = VentionApp(name="MyCustomApp", emit_proto=True, proto_path=proto_path)
        app.finalize()

        proto_content = self.fixture.read_proto_file(proto_path)
        # Service name should be sanitized in proto
        self.assertIn("service MyCustomAppService", proto_content)
        # Package declaration should be present
        self.assertIn("package vention.app.v1", proto_content)
        # FQN is used in route paths, not in proto file
        # Check that routes use the FQN
        service_fqn = "vention.app.v1.MyCustomAppService"
        routes = get_route_paths(app.connect_router)
        self.assertTrue(any(service_fqn in route for route in routes))
