"""Tests for type inference utilities."""

from __future__ import annotations

import unittest
from typing import Any

from pydantic import BaseModel

from communication.typing_utils import (
    TypingError,
    infer_input_type,
    infer_output_type,
    is_pydantic_model,
)


# ---------- Test Models ----------


class TestModel(BaseModel):
    """Test Pydantic model."""

    value: str


class AnotherModel(BaseModel):
    """Another test Pydantic model."""

    count: int


# ---------- Test Functions for Type Inference ----------


def function_no_params() -> None:
    """Function with no parameters."""
    pass


def function_with_typed_param(x: str) -> None:
    """Function with typed parameter."""
    pass


def function_with_model_param(req: TestModel) -> TestModel:
    """Function with Pydantic model parameter."""
    return TestModel(value="test")


def function_with_any_param(x: Any) -> None:
    """Function with Any parameter."""
    pass


def function_with_untyped_param(x) -> None:  # type: ignore[no-untyped-def]
    """Function with untyped parameter."""
    pass


def function_with_return_type(x: str) -> str:
    """Function with return type."""
    return x


def function_with_model_return_type(x: str) -> TestModel:
    """Function with model return type."""
    return TestModel(value=x)


def function_with_no_return_type(x: str) -> None:
    """Function without return type annotation."""
    pass


def function_with_any_return_type(x: str) -> Any:
    """Function with Any return type."""
    return x


class TestMethod:
    """Test class with methods."""

    def method_with_self(self, x: str) -> None:
        """Method with self parameter."""
        pass

    def method_with_cls(cls, x: str) -> None:
        """Method with cls parameter."""
        pass


# ---------- Tests ----------


class TestInferInputType(unittest.TestCase):
    """Tests for infer_input_type function."""

    def test_no_parameters_returns_none(self) -> None:
        """infer_input_type returns None for functions with no parameters."""
        result = infer_input_type(function_no_params)
        self.assertIsNone(result)

    def test_typed_parameter_returns_type(self) -> None:
        """infer_input_type returns type for typed parameter."""
        result = infer_input_type(function_with_typed_param)
        self.assertEqual(result, str)

    def test_pydantic_model_parameter_returns_model(self) -> None:
        """infer_input_type returns Pydantic model type."""
        result = infer_input_type(function_with_model_param)
        self.assertEqual(result, TestModel)

    def test_any_parameter_returns_none(self) -> None:
        """infer_input_type returns None for Any parameter."""
        result = infer_input_type(function_with_any_param)
        self.assertIsNone(result)

    def test_untyped_parameter_raises_typing_error(self) -> None:
        """infer_input_type raises TypingError for untyped parameter."""
        with self.assertRaises(TypingError) as context:
            infer_input_type(function_with_untyped_param)
        self.assertIn("must be annotated", str(context.exception))

    def test_strips_self_parameter(self) -> None:
        """infer_input_type strips self parameter from methods."""
        obj = TestMethod()
        result = infer_input_type(obj.method_with_self)
        self.assertEqual(result, str)

    def test_strips_cls_parameter(self) -> None:
        """infer_input_type strips cls parameter from classmethods."""
        result = infer_input_type(TestMethod.method_with_cls)
        self.assertEqual(result, str)


class TestInferOutputType(unittest.TestCase):
    """Tests for infer_output_type function."""

    def test_no_return_annotation_returns_none(self) -> None:
        """infer_output_type returns None when no return annotation."""
        result = infer_output_type(function_with_no_return_type)
        self.assertIsNone(result)

    def test_typed_return_returns_type(self) -> None:
        """infer_output_type returns type for typed return."""
        result = infer_output_type(function_with_return_type)
        self.assertEqual(result, str)

    def test_model_return_returns_model(self) -> None:
        """infer_output_type returns Pydantic model type."""
        result = infer_output_type(function_with_model_return_type)
        self.assertEqual(result, TestModel)

    def test_any_return_returns_none(self) -> None:
        """infer_output_type returns None for Any return type."""
        result = infer_output_type(function_with_any_return_type)
        self.assertIsNone(result)


class TestIsPydanticModel(unittest.TestCase):
    """Tests for is_pydantic_model function."""

    def test_pydantic_model_returns_true(self) -> None:
        """is_pydantic_model returns True for Pydantic BaseModel subclasses."""
        self.assertTrue(is_pydantic_model(TestModel))
        self.assertTrue(is_pydantic_model(AnotherModel))

    def test_non_pydantic_type_returns_false(self) -> None:
        """is_pydantic_model returns False for non-Pydantic types."""
        self.assertFalse(is_pydantic_model(str))
        self.assertFalse(is_pydantic_model(int))
        self.assertFalse(is_pydantic_model(dict))
        self.assertFalse(is_pydantic_model(list))

    def test_instance_returns_false(self) -> None:
        """is_pydantic_model returns False for model instances."""
        instance = TestModel(value="test")
        self.assertFalse(is_pydantic_model(instance))

    def test_invalid_type_returns_false(self) -> None:
        """is_pydantic_model returns False for invalid types gracefully."""
        self.assertFalse(is_pydantic_model(None))
        self.assertFalse(is_pydantic_model("not a type"))
        self.assertFalse(is_pydantic_model(123))
