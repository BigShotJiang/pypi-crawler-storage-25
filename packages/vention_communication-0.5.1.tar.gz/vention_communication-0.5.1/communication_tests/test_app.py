"""Tests for VentionApp class."""

from __future__ import annotations

import os
import tempfile
import unittest
from pathlib import Path

from fastapi.routing import APIRoute

from communication.app import VentionApp
from communication.decorators import action, stream
from communication.entries import ActionEntry, RpcBundle
from communication_tests.fixtures import (
    VentionAppFixture,
    SimpleRequest,
    SimpleResponse,
    reset_decorator_state,
)


# ---------- Test Models ----------


class StreamPayload(SimpleResponse):
    """Test payload for streams."""

    pass


class TestRequest(SimpleRequest):
    """Test request model for aliasing tests."""

    user_id: int


class TestResponse(SimpleResponse):
    """Test response model for aliasing tests."""

    success_flag: bool
    error_message: str


# ---------- Test Functions ----------


@action()
def test_action(req: SimpleRequest) -> SimpleResponse:
    """Test action function."""
    return SimpleResponse(message="test", success=True)


@stream(name="test_stream", payload=StreamPayload)
async def test_stream() -> StreamPayload:
    """Test stream function."""
    return StreamPayload(message="test", success=True)


# ---------- Tests ----------


class TestVentionAppInitialization(unittest.TestCase):
    """Tests for VentionApp initialization."""

    def setUp(self) -> None:
        """Reset decorator state before each test."""
        reset_decorator_state()

    def test_default_initialization(self) -> None:
        """VentionApp initializes with default parameters."""
        app = VentionApp()
        self.assertEqual(app.name, "VentionApp")
        self.assertFalse(app.emit_proto)
        self.assertEqual(app.proto_path, "proto/app.proto")
        # connect_router is created in finalize(), not __init__()
        self.assertFalse(hasattr(app, "connect_router"))
        self.assertEqual(len(app._extra_bundles), 0)

    def test_custom_name(self) -> None:
        """VentionApp accepts custom name."""
        app = VentionApp(name="MyCustomApp")
        self.assertEqual(app.name, "MyCustomApp")
        self.assertEqual(app.service_name, "MyCustomApp")

    def test_custom_emit_proto(self) -> None:
        """VentionApp accepts custom emit_proto setting."""
        app = VentionApp(emit_proto=True)
        self.assertTrue(app.emit_proto)

    def test_custom_proto_path(self) -> None:
        """VentionApp accepts custom proto_path."""
        app = VentionApp(proto_path="custom/path.proto")
        self.assertEqual(app.proto_path, "custom/path.proto")

    def test_service_name_property(self) -> None:
        """service_name property returns sanitized name."""
        app = VentionApp(name="my-test-app")
        self.assertEqual(app.service_name, "MyTestApp")

    def test_service_name_sanitization(self) -> None:
        """service_name sanitizes various name formats."""
        test_cases = [
            ("simple", "Simple"),
            ("my_app", "MyApp"),
            ("test-app", "TestApp"),
            ("App123", "App123"),
        ]
        for name, expected in test_cases:
            with self.subTest(name=name):
                app = VentionApp(name=name)
                self.assertEqual(app.service_name, expected)

    def test_fastapi_kwargs_passed_through(self) -> None:
        """VentionApp passes kwargs to FastAPI."""
        app = VentionApp(title="Test App", version="1.0.0")
        self.assertEqual(app.title, "Test App")
        self.assertEqual(app.version, "1.0.0")


class TestVentionAppExtendBundle(unittest.TestCase):
    """Tests for register_rpc_plugin method."""

    def setUp(self) -> None:
        """Reset decorator state before each test."""
        reset_decorator_state()

    def test_register_rpc_plugin_adds_bundle(self) -> None:
        """register_rpc_plugin adds external bundle to app."""
        app = VentionApp()
        bundle = RpcBundle(
            actions=[
                ActionEntry(
                    name="external_action",
                    func=lambda x: x,
                    input_type=SimpleRequest,
                    output_type=SimpleResponse,
                )
            ],
            streams=[],
        )
        app.register_rpc_plugin(bundle)
        self.assertEqual(len(app._extra_bundles), 1)
        self.assertIs(app._extra_bundles[0], bundle)

    def test_register_rpc_plugin_multiple_bundles(self) -> None:
        """register_rpc_plugin can add multiple bundles."""
        app = VentionApp()
        bundle1 = RpcBundle(actions=[], streams=[])
        bundle2 = RpcBundle(actions=[], streams=[])
        app.register_rpc_plugin(bundle1)
        app.register_rpc_plugin(bundle2)
        self.assertEqual(len(app._extra_bundles), 2)
        self.assertIs(app._extra_bundles[0], bundle1)
        self.assertIs(app._extra_bundles[1], bundle2)

    def test_register_rpc_plugin_preserves_ordering(self) -> None:
        """register_rpc_plugin preserves order of bundles."""
        app = VentionApp()
        bundles = [RpcBundle(actions=[], streams=[]) for _ in range(3)]
        for bundle in bundles:
            app.register_rpc_plugin(bundle)
        self.assertEqual(app._extra_bundles, bundles)


class TestVentionAppFinalize(unittest.TestCase):
    """Tests for finalize method."""

    def setUp(self) -> None:
        """Reset decorator state and create fixture before each test."""
        reset_decorator_state()
        self.fixture = VentionAppFixture()

    def tearDown(self) -> None:
        """Clean up fixture after each test."""
        self.fixture.cleanup()

    def test_finalize_collects_decorator_actions(self) -> None:
        """finalize collects actions registered via decorators."""

        # Register action via decorator
        @action(name="decorated_action")
        def decorated_func(req: SimpleRequest) -> SimpleResponse:
            return SimpleResponse(message="test", success=True)

        app = VentionApp()
        app.finalize()

        # Check that router has the action
        self.assertIn("decorated_action", app.connect_router._unaries)
        entry = app.connect_router._unaries["decorated_action"]
        self.assertEqual(entry.name, "decorated_action")

    def test_finalize_collects_decorator_streams(self) -> None:
        """finalize collects streams registered via decorators."""

        # Register stream via decorator
        @stream(name="decorated_stream", payload=StreamPayload)
        async def decorated_stream() -> StreamPayload:
            return StreamPayload(message="test", success=True)

        app = VentionApp()
        app.finalize()

        # Check that router has the stream
        self.assertIn("decorated_stream", app.connect_router._streams)
        entry = app.connect_router._streams["decorated_stream"]
        self.assertEqual(entry.name, "decorated_stream")

    def test_finalize_merges_external_bundles(self) -> None:
        """finalize merges external bundles with decorator-registered items."""

        # Register via decorator
        @action(name="decorated")
        def decorated() -> None:
            pass

        # Create external bundle
        external_action = ActionEntry(
            name="external",
            func=lambda: None,
            input_type=None,
            output_type=None,
        )
        external_bundle = RpcBundle(actions=[external_action], streams=[])

        app = VentionApp()
        app.register_rpc_plugin(external_bundle)
        app.finalize()

        # Both should be registered
        self.assertIn("decorated", app.connect_router._unaries)
        self.assertIn("external", app.connect_router._unaries)

    def test_finalize_registers_routes(self) -> None:
        """finalize registers routes with ConnectRouter."""

        @action(name="test_action")
        def test_action_func(req: SimpleRequest) -> SimpleResponse:
            return SimpleResponse(message="test", success=True)

        app = VentionApp(name="TestApp")
        app.finalize()

        # Check that router is included
        service_fqn = "vention.app.v1.TestAppService"
        expected_path = f"/{service_fqn}/test_action"

        # Verify router has routes
        routes = [route.path for route in app.connect_router.router.routes if isinstance(route, APIRoute)]
        self.assertIn(expected_path, routes)

    def test_finalize_sets_global_app(self) -> None:
        """finalize sets global app for stream publishers."""
        app = VentionApp()
        app.finalize()

        from communication.decorators import _GLOBAL_APP

        self.assertIs(_GLOBAL_APP, app)

    def test_finalize_emits_proto_when_enabled(self) -> None:
        """finalize emits proto file when emit_proto is True."""

        @action(name="test_action")
        def test_action_func(req: SimpleRequest) -> SimpleResponse:
            return SimpleResponse(message="test", success=True)

        proto_path = self.fixture.get_proto_path("test.proto")
        app = VentionApp(name="TestApp", emit_proto=True, proto_path=proto_path)
        app.finalize()

        # Check that proto file was created
        self.assertTrue(os.path.exists(proto_path))

        # Check proto content
        proto_content = self.fixture.read_proto_file(proto_path)
        self.assertIn('syntax = "proto3"', proto_content)
        self.assertIn("service TestAppService", proto_content)
        self.assertIn("rpc test_action", proto_content)

    def test_finalize_does_not_emit_proto_when_disabled(self) -> None:
        """finalize does not emit proto file when emit_proto is False."""

        @action(name="test_action")
        def test_action_func(req: SimpleRequest) -> SimpleResponse:
            return SimpleResponse(message="test", success=True)

        proto_path = self.fixture.get_proto_path("test.proto")
        app = VentionApp(name="TestApp", emit_proto=False, proto_path=proto_path)
        app.finalize()

        # Check that proto file was NOT created
        self.assertFalse(os.path.exists(proto_path))

    def test_finalize_creates_proto_directory(self) -> None:
        """finalize creates proto directory if it doesn't exist."""

        @action(name="test_action")
        def test_action_func(req: SimpleRequest) -> SimpleResponse:
            return SimpleResponse(message="test", success=True)

        # Use a path with a non-existent directory
        temp_dir = Path(tempfile.mkdtemp())
        proto_path = str(temp_dir / "new_dir" / "test.proto")
        try:
            app = VentionApp(name="TestApp", emit_proto=True, proto_path=proto_path)
            app.finalize()

            # Check that directory was created
            self.assertTrue(os.path.exists(os.path.dirname(proto_path)))
            self.assertTrue(os.path.exists(proto_path))
        finally:
            import shutil

            shutil.rmtree(temp_dir)

    def test_finalize_service_fqn_format(self) -> None:
        """finalize uses correct service FQN format."""

        @action(name="test_action")
        def test_action_func(req: SimpleRequest) -> SimpleResponse:
            return SimpleResponse(message="test", success=True)

        app = VentionApp(name="MyApp")
        app.finalize()

        # Check that routes use correct FQN
        service_fqn = "vention.app.v1.MyAppService"
        routes = [route.path for route in app.connect_router.router.routes if isinstance(route, APIRoute)]
        self.assertTrue(any(service_fqn in route for route in routes))

    def test_finalize_multiple_actions_and_streams(self) -> None:
        """finalize handles multiple actions and streams."""

        @action(name="action1")
        def action1() -> None:
            pass

        @action(name="action2")
        def action2() -> None:
            pass

        @stream(name="stream1", payload=StreamPayload)
        async def stream1() -> StreamPayload:
            return StreamPayload(message="test", success=True)

        @stream(name="stream2", payload=StreamPayload)
        async def stream2() -> StreamPayload:
            return StreamPayload(message="test", success=True)

        app = VentionApp()
        app.finalize()

        # Check all are registered
        self.assertIn("action1", app.connect_router._unaries)
        self.assertIn("action2", app.connect_router._unaries)
        self.assertIn("stream1", app.connect_router._streams)
        self.assertIn("stream2", app.connect_router._streams)

    def test_finalize_applies_aliases_to_decorator_and_external_bundles(self) -> None:
        """finalize applies camelCase aliases to models from both decorators and external bundles."""

        # Register action via decorator using module-level models
        @action(name="decorated_action")
        def decorated_action(req: TestRequest) -> TestResponse:
            return TestResponse(message="ok", success=True, success_flag=True, error_message="ok")

        # Create external bundle with same models
        external_action = ActionEntry(
            name="external_action",
            func=lambda req: TestResponse(message="ok", success=True, success_flag=True, error_message="ok"),
            input_type=TestRequest,
            output_type=TestResponse,
        )
        external_bundle = RpcBundle(actions=[external_action], streams=[])

        app = VentionApp()
        app.register_rpc_plugin(external_bundle)
        app.finalize()

        # Verify aliases are applied to decorator model
        decorator_entry = app.connect_router._unaries["decorated_action"]
        self.assertIsNotNone(decorator_entry.input_type)
        self.assertIsNotNone(decorator_entry.output_type)

        # Check that fields have camelCase aliases
        assert decorator_entry.input_type is not None  # Type narrowing for mypy
        assert decorator_entry.output_type is not None  # Type narrowing for mypy
        input_fields = decorator_entry.input_type.model_fields
        self.assertEqual(input_fields["message"].alias, "message")  # Inherited from SimpleRequest
        self.assertEqual(input_fields["user_id"].alias, "userId")

        output_fields = decorator_entry.output_type.model_fields
        self.assertEqual(output_fields["success_flag"].alias, "successFlag")
        self.assertEqual(output_fields["error_message"].alias, "errorMessage")

        # Verify aliases are applied to external bundle model
        external_entry = app.connect_router._unaries["external_action"]
        self.assertIsNotNone(external_entry.input_type)
        self.assertIsNotNone(external_entry.output_type)

        # Check that fields have camelCase aliases (same model instances should be aliased)
        assert external_entry.input_type is not None  # Type narrowing for mypy
        assert external_entry.output_type is not None  # Type narrowing for mypy
        external_input_fields = external_entry.input_type.model_fields
        self.assertEqual(external_input_fields["message"].alias, "message")  # Inherited from SimpleRequest
        self.assertEqual(external_input_fields["user_id"].alias, "userId")

        external_output_fields = external_entry.output_type.model_fields
        self.assertEqual(external_output_fields["success_flag"].alias, "successFlag")
        self.assertEqual(external_output_fields["error_message"].alias, "errorMessage")

        # Verify aliases work for validation - can create instance using camelCase alias
        # This proves the aliases are working correctly
        test_req_with_alias = TestRequest(  # type: ignore[call-arg]
            message="test", userId=123
        )  # Using camelCase alias
        self.assertEqual(test_req_with_alias.user_id, 123)  # Can access via snake_case field name
        self.assertEqual(test_req_with_alias.message, "test")

        # Also verify snake_case still works (populate_by_name=True allows both)
        test_req_with_snake = TestRequest(message="test", user_id=456)
        self.assertEqual(test_req_with_snake.user_id, 456)

        # Verify response model aliases work too
        test_resp_with_alias = TestResponse(  # type: ignore[call-arg]
            message="ok", success=True, successFlag=True, errorMessage="no error"
        )
        self.assertEqual(test_resp_with_alias.success_flag, True)
        self.assertEqual(test_resp_with_alias.error_message, "no error")
