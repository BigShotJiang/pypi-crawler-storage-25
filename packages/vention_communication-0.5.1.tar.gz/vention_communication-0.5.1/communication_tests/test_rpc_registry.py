"""Tests for RpcRegistry nested model normalization."""

from __future__ import annotations

import unittest
from typing import List, Optional

from pydantic import BaseModel

from communication.entries import ActionEntry, RpcBundle
from communication.rpc_registry import RpcRegistry
from communication_tests.fixtures import reset_decorator_state


# ---------- Test Models ----------


class NestedModel(BaseModel):
    """Nested model for testing."""

    value: int


class ModelWithOptionalNested(BaseModel):
    """Model with Optional nested model."""

    nested: Optional[NestedModel] = None


class ModelWithListNested(BaseModel):
    """Model with List of nested models."""

    items: List[NestedModel]


class ModelWithOptionalListNested(BaseModel):
    """Model with Optional List of nested models."""

    items: Optional[List[NestedModel]] = None


class ModelWithListOptionalNested(BaseModel):
    """Model with List of Optional nested models."""

    items: List[Optional[NestedModel]]


# ---------- Tests ----------


class TestRpcRegistryNestedModels(unittest.TestCase):
    """Tests for RpcRegistry nested model normalization."""

    def setUp(self) -> None:
        """Reset state before each test."""
        reset_decorator_state()

    def test_optional_nested_model_normalized(self) -> None:
        """Optional nested models are normalized."""
        registry = RpcRegistry()
        bundle = RpcBundle(
            actions=[
                ActionEntry(
                    name="test_action",
                    func=lambda x: x,
                    input_type=ModelWithOptionalNested,
                    output_type=None,
                )
            ],
            streams=[],
        )
        registry.add_bundle(bundle)
        registry.get_unified_bundle()
        # Both parent and nested models should be normalized
        # Check that nested model has aliases applied
        self.assertTrue(hasattr(NestedModel, "model_fields"))
        nested_field = NestedModel.model_fields["value"]
        self.assertEqual(nested_field.alias, "value")  # No underscore, so same

    def test_list_nested_model_normalized(self) -> None:
        """List of nested models are normalized."""
        registry = RpcRegistry()
        bundle = RpcBundle(
            actions=[
                ActionEntry(
                    name="test_action",
                    func=lambda x: x,
                    input_type=ModelWithListNested,
                    output_type=None,
                )
            ],
            streams=[],
        )
        registry.add_bundle(bundle)
        registry.get_unified_bundle()
        # Nested model should be normalized
        self.assertTrue(hasattr(NestedModel, "model_fields"))

    def test_optional_list_nested_model_normalized(self) -> None:
        """Optional List of nested models are normalized."""
        registry = RpcRegistry()
        bundle = RpcBundle(
            actions=[
                ActionEntry(
                    name="test_action",
                    func=lambda x: x,
                    input_type=ModelWithOptionalListNested,
                    output_type=None,
                )
            ],
            streams=[],
        )
        registry.add_bundle(bundle)
        registry.get_unified_bundle()
        # Nested model should be normalized
        self.assertTrue(hasattr(NestedModel, "model_fields"))

    def test_list_optional_nested_model_normalized(self) -> None:
        """List of Optional nested models are normalized."""
        registry = RpcRegistry()
        bundle = RpcBundle(
            actions=[
                ActionEntry(
                    name="test_action",
                    func=lambda x: x,
                    input_type=ModelWithListOptionalNested,
                    output_type=None,
                )
            ],
            streams=[],
        )
        registry.add_bundle(bundle)
        registry.get_unified_bundle()
        # Nested model should be normalized
        self.assertTrue(hasattr(NestedModel, "model_fields"))

    def test_deeply_nested_models_normalized(self) -> None:
        """Deeply nested models are all normalized."""

        class Level1(BaseModel):
            level1_field: str

        class Level2(BaseModel):
            level2_field: str
            level1: Optional[Level1] = None

        class Level3(BaseModel):
            level3_field: str
            level2: List[Level2]

        registry = RpcRegistry()
        bundle = RpcBundle(
            actions=[
                ActionEntry(
                    name="test_action",
                    func=lambda x: x,
                    input_type=Level3,
                    output_type=None,
                )
            ],
            streams=[],
        )
        registry.add_bundle(bundle)
        registry.get_unified_bundle()

        # All nested models should be normalized
        self.assertTrue(hasattr(Level1, "model_fields"))
        self.assertTrue(hasattr(Level2, "model_fields"))
        self.assertTrue(hasattr(Level3, "model_fields"))
