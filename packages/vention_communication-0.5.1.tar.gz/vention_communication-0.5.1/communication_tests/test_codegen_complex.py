"""Tests for complex proto generation scenarios."""

from __future__ import annotations

import unittest
from typing import List, Optional

from pydantic import BaseModel

from communication.codegen import generate_proto
from communication.entries import ActionEntry, RpcBundle, StreamEntry


# ---------- Complex Test Models ----------


class NestedModel(BaseModel):
    """Model with nested Pydantic model fields."""

    name: str
    value: int


class ParentModel(BaseModel):
    """Model containing nested model."""

    id: int
    nested: NestedModel


class OptionalFieldsModel(BaseModel):
    """Model with optional fields."""

    required_field: str
    optional_str: Optional[str] = None
    optional_int: Optional[int] = None
    optional_bool: Optional[bool] = None


class ListFieldsModel(BaseModel):
    """Model with list fields."""

    name: str
    tags: List[str]
    counts: List[int]
    prices: List[float]
    flags: List[bool]


class ComplexNestedModel(BaseModel):
    """Model with nested model in list."""

    items: List[NestedModel]
    metadata: Optional[NestedModel] = None


class NonScalarFieldModel(BaseModel):
    """Model with non-scalar field types (will fall back to string)."""

    name: str
    # This will fall back to string in proto generation
    complex_data: dict  # type: ignore[type-arg]


class MixedComplexModel(BaseModel):
    """Model with all complex features combined."""

    id: int
    name: str
    nested: Optional[NestedModel] = None
    items: List[str]
    tags: Optional[List[str]] = None


# ---------- Tests ----------


class TestProtoGenerationNestedModels(unittest.TestCase):
    """Tests for proto generation with nested Pydantic models."""

    def test_nested_model_in_message(self) -> None:
        """Nested Pydantic models generate separate message definitions."""
        bundle = RpcBundle(
            actions=[
                ActionEntry(
                    name="nested_action",
                    func=lambda x: x,
                    input_type=ParentModel,
                    output_type=NestedModel,  # NestedModel used directly as output
                )
            ],
            streams=[],
        )
        proto = generate_proto("TestApp", bundle=bundle)

        # Both models should be defined
        self.assertIn("message ParentModel {", proto)
        self.assertIn("message NestedModel {", proto)

        # Nested model fields should be present
        self.assertIn("string name = 1;", proto)  # From NestedModel
        self.assertIn("int32 value = 2;", proto)  # From NestedModel

        # Parent model should reference nested model by name
        self.assertIn("int32 id = 1;", proto)
        self.assertIn("NestedModel nested = 2;", proto)  # Nested model referenced

    def test_deeply_nested_models(self) -> None:
        """Multiple levels of nesting generate all message types."""
        bundle = RpcBundle(
            actions=[
                ActionEntry(
                    name="deep_action",
                    func=lambda x: x,
                    input_type=ComplexNestedModel,
                    output_type=None,
                )
            ],
            streams=[],
        )
        proto = generate_proto("TestApp", bundle=bundle)

        # All models should be defined
        self.assertIn("message ComplexNestedModel {", proto)
        self.assertIn("message NestedModel {", proto)  # Nested model auto-generated

        # Fields should reference nested models correctly
        self.assertIn("repeated NestedModel items = 1;", proto)  # List[NestedModel] -> repeated NestedModel
        self.assertIn("NestedModel metadata = 2;", proto)  # Optional[NestedModel] -> NestedModel


class TestProtoGenerationOptionalFields(unittest.TestCase):
    """Tests for proto generation with optional fields."""

    def test_optional_fields_generate(self) -> None:
        """Optional fields are included in message definition with correct types."""
        bundle = RpcBundle(
            actions=[
                ActionEntry(
                    name="optional_action",
                    func=lambda x: x,
                    input_type=OptionalFieldsModel,
                    output_type=None,
                )
            ],
            streams=[],
        )
        proto = generate_proto("TestApp", bundle=bundle)

        # Model should be defined
        self.assertIn("message OptionalFieldsModel {", proto)

        # All fields should be present with correct types (Optional unwrapped)
        self.assertIn("string required_field = 1;", proto)
        self.assertIn("string optional_str = 2;", proto)
        self.assertIn("int32 optional_int = 3;", proto)  # Optional[int] -> int32
        self.assertIn("bool optional_bool = 4;", proto)  # Optional[bool] -> bool

    def test_optional_fields_with_defaults(self) -> None:
        """Optional fields with defaults are still included."""
        bundle = RpcBundle(
            actions=[
                ActionEntry(
                    name="optional_default_action",
                    func=lambda x: x,
                    input_type=OptionalFieldsModel,
                    output_type=OptionalFieldsModel,
                )
            ],
            streams=[],
        )
        proto = generate_proto("TestApp", bundle=bundle)

        # Model should appear only once (deduplicated)
        message_count = proto.count("message OptionalFieldsModel {")
        self.assertEqual(message_count, 1)

        # All fields should be present in both input and output
        self.assertIn("rpc optional_default_action", proto)


class TestProtoGenerationListFields(unittest.TestCase):
    """Tests for proto generation with list/array fields."""

    def test_list_fields_generate(self) -> None:
        """List fields are included in message definition with repeated prefix."""
        bundle = RpcBundle(
            actions=[
                ActionEntry(
                    name="list_action",
                    func=lambda x: x,
                    input_type=ListFieldsModel,
                    output_type=None,
                )
            ],
            streams=[],
        )
        proto = generate_proto("TestApp", bundle=bundle)

        # Model should be defined
        self.assertIn("message ListFieldsModel {", proto)

        # List fields should use repeated prefix
        self.assertIn("string name = 1;", proto)
        self.assertIn("repeated string tags = 2;", proto)  # List[str] -> repeated string
        self.assertIn("repeated int32 counts = 3;", proto)  # List[int] -> repeated int32
        self.assertIn("repeated double prices = 4;", proto)  # List[float] -> repeated double
        self.assertIn("repeated bool flags = 5;", proto)  # List[bool] -> repeated bool

    def test_list_fields_in_multiple_actions(self) -> None:
        """List fields model is deduplicated across actions."""
        bundle = RpcBundle(
            actions=[
                ActionEntry(
                    name="action1",
                    func=lambda x: x,
                    input_type=ListFieldsModel,
                    output_type=ListFieldsModel,
                ),
                ActionEntry(
                    name="action2",
                    func=lambda x: x,
                    input_type=ListFieldsModel,
                    output_type=None,
                ),
            ],
            streams=[],
        )
        proto = generate_proto("TestApp", bundle=bundle)

        # Model should appear only once
        message_count = proto.count("message ListFieldsModel {")
        self.assertEqual(message_count, 1)


class TestProtoGenerationNonScalarFields(unittest.TestCase):
    """Tests for proto generation with non-scalar field types."""

    def test_non_scalar_field_fallback(self) -> None:
        """Non-scalar fields (like dict) fall back to string type."""
        bundle = RpcBundle(
            actions=[
                ActionEntry(
                    name="non_scalar_action",
                    func=lambda x: x,
                    input_type=NonScalarFieldModel,
                    output_type=None,
                )
            ],
            streams=[],
        )
        proto = generate_proto("TestApp", bundle=bundle)

        # Model should be defined
        self.assertIn("message NonScalarFieldModel {", proto)

        # Scalar field should be correct type
        self.assertIn("string name = 1;", proto)

        # Non-scalar field (dict) should fall back to string
        # (dict type is not in _SCALAR_MAP and not a Pydantic model)
        self.assertIn("string complex_data = 2;", proto)

    def test_mixed_scalar_and_non_scalar(self) -> None:
        """Mixed scalar and non-scalar fields generate correctly."""
        bundle = RpcBundle(
            actions=[
                ActionEntry(
                    name="mixed_action",
                    func=lambda x: x,
                    input_type=MixedComplexModel,
                    output_type=None,
                )
            ],
            streams=[],
        )
        proto = generate_proto("TestApp", bundle=bundle)

        # Model should be defined
        self.assertIn("message MixedComplexModel {", proto)
        self.assertIn("message NestedModel {", proto)  # Nested model auto-generated

        # Scalar fields should have correct types
        self.assertIn("int32 id = 1;", proto)
        self.assertIn("string name = 2;", proto)

        # Complex fields should use correct types
        self.assertIn("NestedModel nested = 3;", proto)  # Optional[NestedModel] -> NestedModel
        self.assertIn("repeated string items = 4;", proto)  # List[str] -> repeated string
        self.assertIn("repeated string tags = 5;", proto)  # Optional[List[str]] -> repeated string


class TestProtoGenerationComplexCombinations(unittest.TestCase):
    """Tests for proto generation with complex combinations."""

    def test_all_complex_features_together(self) -> None:
        """Model with nested, optional, and list fields generates correctly."""
        bundle = RpcBundle(
            actions=[
                ActionEntry(
                    name="complex_action",
                    func=lambda x: x,
                    input_type=MixedComplexModel,
                    output_type=MixedComplexModel,
                )
            ],
            streams=[],
        )
        proto = generate_proto("TestApp", bundle=bundle)

        # All models should be defined
        self.assertIn("message MixedComplexModel {", proto)
        self.assertIn("message NestedModel {", proto)  # Nested model auto-generated

        # Fields should use correct types
        self.assertIn("int32 id = 1;", proto)
        self.assertIn("string name = 2;", proto)
        self.assertIn("NestedModel nested = 3;", proto)  # Optional[NestedModel] -> NestedModel
        self.assertIn("repeated string items = 4;", proto)  # List[str] -> repeated string
        self.assertIn("repeated string tags = 5;", proto)  # Optional[List[str]] -> repeated string

        # RPC should reference the model
        self.assertIn("rpc complex_action", proto)

    def test_multiple_complex_models(self) -> None:
        """Multiple complex models all generate correctly."""
        bundle = RpcBundle(
            actions=[
                ActionEntry(
                    name="action1",
                    func=lambda x: x,
                    input_type=ParentModel,
                    output_type=NestedModel,
                ),
                ActionEntry(
                    name="action2",
                    func=lambda x: x,
                    input_type=OptionalFieldsModel,
                    output_type=ListFieldsModel,
                ),
                ActionEntry(
                    name="action3",
                    func=lambda x: x,
                    input_type=ComplexNestedModel,
                    output_type=None,
                ),
            ],
            streams=[],
        )
        proto = generate_proto("TestApp", bundle=bundle)

        # All models should be defined
        self.assertIn("message ParentModel {", proto)
        self.assertIn("message NestedModel {", proto)
        self.assertIn("message OptionalFieldsModel {", proto)
        self.assertIn("message ListFieldsModel {", proto)
        self.assertIn("message ComplexNestedModel {", proto)

        # All RPCs should be present
        self.assertIn("rpc action1", proto)
        self.assertIn("rpc action2", proto)
        self.assertIn("rpc action3", proto)

    def test_complex_models_with_streams(self) -> None:
        """Complex models work with streams."""
        bundle = RpcBundle(
            actions=[
                ActionEntry(
                    name="complex_action",
                    func=lambda x: x,
                    input_type=MixedComplexModel,
                    output_type=None,
                )
            ],
            streams=[
                StreamEntry(
                    name="complex_stream",
                    func=None,
                    payload_type=ListFieldsModel,
                )
            ],
        )
        proto = generate_proto("TestApp", bundle=bundle)

        # Models should be defined
        self.assertIn("message MixedComplexModel {", proto)
        self.assertIn("message ListFieldsModel {", proto)

        # Both action and stream should be present
        self.assertIn("rpc complex_action", proto)
        self.assertIn("rpc complex_stream", proto)
        self.assertIn("stream ListFieldsModel", proto)


class TestProtoGenerationDeduplication(unittest.TestCase):
    """Tests for message type deduplication in complex scenarios."""

    def test_nested_model_reused(self) -> None:
        """Same nested model used in multiple places is deduplicated."""
        bundle = RpcBundle(
            actions=[
                ActionEntry(
                    name="action1",
                    func=lambda x: x,
                    input_type=ParentModel,
                    output_type=NestedModel,
                ),
                ActionEntry(
                    name="action2",
                    func=lambda x: x,
                    input_type=ComplexNestedModel,
                    output_type=NestedModel,
                ),
            ],
            streams=[],
        )
        proto = generate_proto("TestApp", bundle=bundle)

        # NestedModel should appear only once
        message_count = proto.count("message NestedModel {")
        self.assertEqual(message_count, 1)

        # But it should be referenced in multiple places
        self.assertIn("rpc action1", proto)
        self.assertIn("rpc action2", proto)

    def test_complex_model_reused_in_streams(self) -> None:
        """Complex models reused in actions and streams are deduplicated."""
        bundle = RpcBundle(
            actions=[
                ActionEntry(
                    name="action1",
                    func=lambda x: x,
                    input_type=ListFieldsModel,
                    output_type=ListFieldsModel,
                )
            ],
            streams=[
                StreamEntry(
                    name="stream1",
                    func=None,
                    payload_type=ListFieldsModel,
                )
            ],
        )
        proto = generate_proto("TestApp", bundle=bundle)

        # Model should appear only once
        message_count = proto.count("message ListFieldsModel {")
        self.assertEqual(message_count, 1)

        # But used in both action and stream
        self.assertIn("rpc action1", proto)
        self.assertIn("rpc stream1", proto)
