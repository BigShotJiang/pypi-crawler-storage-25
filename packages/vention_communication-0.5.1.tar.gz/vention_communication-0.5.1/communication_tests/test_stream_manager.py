"""Tests for StreamManager with async-safe task management."""

from __future__ import annotations

import asyncio

from pydantic import BaseModel

from communication.entries import StreamEntry
from communication_tests.fixtures import (
    AsyncTestBase,
    StreamManagerFixture,
    safe_queue_get,
    collect_stream_items,
    wait_for_condition,
)


# ---------- Test Models ----------


class TestPayload(BaseModel):
    """Test payload model for streams."""

    value: int
    message: str


# ---------- Tests ----------


class TestStreamManagerTopicManagement(AsyncTestBase):
    """Tests for StreamManager topic creation and management."""

    def setUp(self) -> None:
        """Set up test with StreamManager fixture."""
        super().setUp()
        self.fixture = StreamManagerFixture(self)

    async def asyncTearDown(self) -> None:
        """Clean up distributor tasks."""
        # Cleanup fixture first (cancels distributor tasks)
        self.fixture.cleanup()
        # Then let AsyncTestBase handle tracked tasks
        await super().asyncTearDown()

    async def test_ensure_topic_creates_topic(self) -> None:
        """ensure_topic creates topic structure."""
        entry = StreamEntry(
            name="test_stream",
            func=None,
            payload_type=TestPayload,
            replay=True,
            queue_maxsize=1,
            policy="latest",
        )
        self.fixture.ensure_topic(entry)

        # Check topic exists
        self.assertIn("test_stream", self.fixture.manager._topics)
        topic = self.fixture.manager._topics["test_stream"]
        self.assertEqual(topic["entry"], entry)
        self.assertIsNotNone(topic["publish_queue"])
        self.assertIsInstance(topic["subscribers"], set)
        self.assertIsNone(topic["last_value"])

    async def test_ensure_topic_idempotent(self) -> None:
        """ensure_topic is idempotent - calling multiple times doesn't recreate."""
        entry = StreamEntry(
            name="test_stream",
            func=None,
            payload_type=TestPayload,
        )
        self.fixture.ensure_topic(entry)
        first_queue = self.fixture.manager._topics["test_stream"]["publish_queue"]

        # Call again
        self.fixture.ensure_topic(entry)
        second_queue = self.fixture.manager._topics["test_stream"]["publish_queue"]

        # Should be the same queue
        self.assertIs(first_queue, second_queue)

    async def test_ensure_topic_creates_distributor_task(self) -> None:
        """ensure_topic creates distributor task when event loop is running."""
        entry = StreamEntry(
            name="test_stream",
            func=None,
            payload_type=TestPayload,
        )
        self.fixture.ensure_topic(entry)

        # Wait for task to be created
        topic = self.fixture.manager._topics["test_stream"]
        await wait_for_condition(lambda: topic.get("task") is not None, timeout=0.5)

        # Task should be created (tracked by fixture)
        self.assertIsNotNone(topic["task"])
        self.assertFalse(topic["task"].done())


class TestStreamManagerSubscription(AsyncTestBase):
    """Tests for StreamManager subscription functionality."""

    def setUp(self) -> None:
        """Set up test with StreamManager fixture."""
        super().setUp()
        self.fixture = StreamManagerFixture(self)

    async def asyncTearDown(self) -> None:
        """Clean up distributor tasks."""
        # Cleanup fixture first (cancels distributor tasks)
        self.fixture.cleanup()
        # Then let AsyncTestBase handle tracked tasks
        await super().asyncTearDown()

    async def test_subscribe_creates_subscriber(self) -> None:
        """subscribe creates subscriber with queue."""
        entry = StreamEntry(
            name="test_stream",
            func=None,
            payload_type=TestPayload,
            queue_maxsize=5,
        )
        self.fixture.ensure_topic(entry)

        subscriber = self.fixture.manager.subscribe("test_stream")

        # Check subscriber properties
        self.assertIsNotNone(subscriber.queue)
        self.assertEqual(subscriber.queue.maxsize, 5)
        topic = self.fixture.manager._topics["test_stream"]
        self.assertIn(subscriber, topic["subscribers"])

    async def test_subscribe_respects_queue_maxsize(self) -> None:
        """subscribe respects queue_maxsize from entry."""
        entry = StreamEntry(
            name="test_stream",
            func=None,
            payload_type=TestPayload,
            queue_maxsize=10,
        )
        self.fixture.ensure_topic(entry)

        subscriber = self.fixture.manager.subscribe("test_stream")
        self.assertEqual(subscriber.queue.maxsize, 10)

    async def test_multiple_subscribers_per_topic(self) -> None:
        """Multiple subscribers can subscribe to same topic."""
        entry = StreamEntry(
            name="test_stream",
            func=None,
            payload_type=TestPayload,
        )
        self.fixture.ensure_topic(entry)

        sub1 = self.fixture.manager.subscribe("test_stream")
        sub2 = self.fixture.manager.subscribe("test_stream")
        sub3 = self.fixture.manager.subscribe("test_stream")

        topic = self.fixture.manager._topics["test_stream"]
        self.assertEqual(len(topic["subscribers"]), 3)
        self.assertIn(sub1, topic["subscribers"])
        self.assertIn(sub2, topic["subscribers"])
        self.assertIn(sub3, topic["subscribers"])

    async def test_unsubscribe_removes_subscriber(self) -> None:
        """unsubscribe removes subscriber from topic."""
        entry = StreamEntry(
            name="test_stream",
            func=None,
            payload_type=TestPayload,
        )
        self.fixture.ensure_topic(entry)

        subscriber = self.fixture.manager.subscribe("test_stream")
        topic = self.fixture.manager._topics["test_stream"]
        self.assertIn(subscriber, topic["subscribers"])

        self.fixture.manager.unsubscribe("test_stream", subscriber)
        self.assertNotIn(subscriber, topic["subscribers"])

    async def test_unsubscribe_nonexistent_stream_safe(self) -> None:
        """unsubscribe is safe when stream doesn't exist."""
        entry = StreamEntry(
            name="test_stream",
            func=None,
            payload_type=TestPayload,
        )
        self.fixture.ensure_topic(entry)

        subscriber = self.fixture.manager.subscribe("test_stream")
        # Should not raise
        self.fixture.manager.unsubscribe("nonexistent", subscriber)


class TestStreamManagerPublishing(AsyncTestBase):
    """Tests for StreamManager publishing functionality."""

    def setUp(self) -> None:
        """Set up test with StreamManager fixture."""
        super().setUp()
        self.fixture = StreamManagerFixture(self)

    async def asyncTearDown(self) -> None:
        """Clean up distributor tasks."""
        # Cleanup fixture first (cancels distributor tasks)
        self.fixture.cleanup()
        # Then let AsyncTestBase handle tracked tasks
        await super().asyncTearDown()

    async def test_publish_enqueues_item(self) -> None:
        """publish enqueues item to publish queue."""
        entry = StreamEntry(
            name="test_stream",
            func=None,
            payload_type=TestPayload,
        )
        self.fixture.ensure_topic(entry)

        payload = TestPayload(value=42, message="test")
        self.fixture.manager.publish("test_stream", payload)

        # Wait for distributor to process and update last_value
        topic = self.fixture.manager._topics["test_stream"]
        await wait_for_condition(lambda: topic["last_value"] == payload, timeout=0.5)

        # Item should be stored as last_value
        self.assertEqual(topic["last_value"], payload)

    async def test_publish_raises_keyerror_unknown_stream(self) -> None:
        """publish raises KeyError for unknown stream."""
        with self.assertRaises(KeyError) as context:
            self.fixture.manager.publish("unknown", TestPayload(value=1, message="test"))
        self.assertIn("Unknown stream", str(context.exception))

    async def test_publish_distributes_to_subscribers(self) -> None:
        """publish distributes items to all subscribers."""
        entry = StreamEntry(
            name="test_stream",
            func=None,
            payload_type=TestPayload,
        )
        self.fixture.ensure_topic(entry)

        sub1 = self.fixture.manager.subscribe("test_stream")
        sub2 = self.fixture.manager.subscribe("test_stream")

        payload = TestPayload(value=42, message="test")
        self.fixture.manager.publish("test_stream", payload)

        # Wait for items to arrive (using our helper with timeout)
        items1 = await collect_stream_items(sub1.queue, max_items=1, timeout=0.5)
        items2 = await collect_stream_items(sub2.queue, max_items=1, timeout=0.5)

        self.assertEqual(len(items1), 1)
        self.assertEqual(len(items2), 1)
        self.assertEqual(items1[0], payload)
        self.assertEqual(items2[0], payload)


class TestStreamManagerReplay(AsyncTestBase):
    """Tests for StreamManager replay functionality."""

    def setUp(self) -> None:
        """Set up test with StreamManager fixture."""
        super().setUp()
        self.fixture = StreamManagerFixture(self)

    async def asyncTearDown(self) -> None:
        """Clean up distributor tasks."""
        # Cleanup fixture first (cancels distributor tasks)
        self.fixture.cleanup()
        # Then let AsyncTestBase handle tracked tasks
        await super().asyncTearDown()

    async def test_replay_enabled_replays_last_value(self) -> None:
        """When replay is enabled, new subscribers receive last value."""
        entry = StreamEntry(
            name="test_stream",
            func=None,
            payload_type=TestPayload,
            replay=True,
        )
        self.fixture.ensure_topic(entry)

        # Publish a value
        payload1 = TestPayload(value=1, message="first")
        self.fixture.manager.publish("test_stream", payload1)

        # Wait for value to be stored as last_value
        await wait_for_condition(
            lambda: self.fixture.manager._topics["test_stream"]["last_value"] == payload1,
            timeout=0.5,
        )

        # Subscribe after publishing
        subscriber = self.fixture.manager.subscribe("test_stream")

        # Should receive last value immediately
        item = await safe_queue_get(subscriber.queue, timeout=0.5)
        self.assertEqual(item, payload1)

    async def test_replay_disabled_no_replay(self) -> None:
        """When replay is disabled, new subscribers don't receive last value."""
        entry = StreamEntry(
            name="test_stream",
            func=None,
            payload_type=TestPayload,
            replay=False,
        )
        self.fixture.ensure_topic(entry)

        # Publish a value
        payload1 = TestPayload(value=1, message="first")
        self.fixture.manager.publish("test_stream", payload1)

        # Wait for value to be stored
        await wait_for_condition(
            lambda: self.fixture.manager._topics["test_stream"]["last_value"] == payload1,
            timeout=0.5,
        )

        # Subscribe after publishing
        subscriber = self.fixture.manager.subscribe("test_stream")

        # Should NOT receive last value immediately
        # Check queue is empty (no replay)
        await asyncio.sleep(0.05)  # Brief wait to ensure no async replay
        self.assertTrue(subscriber.queue.empty())

    async def test_replay_with_full_queue_latest_wins(self) -> None:
        """When queue is full and replay enabled, latest value wins."""
        entry = StreamEntry(
            name="test_stream",
            func=None,
            payload_type=TestPayload,
            replay=True,
            queue_maxsize=1,
        )
        self.fixture.ensure_topic(entry)

        # Publish values
        payload1 = TestPayload(value=1, message="first")
        payload2 = TestPayload(value=2, message="second")
        self.fixture.manager.publish("test_stream", payload1)
        self.fixture.manager.publish("test_stream", payload2)

        # Wait for latest value to be stored
        await wait_for_condition(
            lambda: self.fixture.manager._topics["test_stream"]["last_value"] == payload2,
            timeout=0.5,
        )

        # Subscribe after publishing
        subscriber = self.fixture.manager.subscribe("test_stream")

        # Should receive latest value (not first)
        item = await safe_queue_get(subscriber.queue, timeout=0.5)
        self.assertEqual(item, payload2)


class TestStreamManagerQueuePolicies(AsyncTestBase):
    """Tests for StreamManager queue policies (FIFO vs latest-wins)."""

    def setUp(self) -> None:
        """Set up test with StreamManager fixture."""
        super().setUp()
        self.fixture = StreamManagerFixture(self)

    async def asyncTearDown(self) -> None:
        """Clean up distributor tasks."""
        # Cleanup fixture first (cancels distributor tasks)
        self.fixture.cleanup()
        # Then let AsyncTestBase handle tracked tasks
        await super().asyncTearDown()

    async def test_latest_wins_policy_drops_old_items(self) -> None:
        """Latest-wins policy drops old items when queue is full."""
        entry = StreamEntry(
            name="test_stream",
            func=None,
            payload_type=TestPayload,
            policy="latest",
            queue_maxsize=2,
        )
        self.fixture.ensure_topic(entry)

        subscriber = self.fixture.manager.subscribe("test_stream")

        # Publish multiple items rapidly
        for i in range(5):
            payload = TestPayload(value=i, message=f"item{i}")
            self.fixture.manager.publish("test_stream", payload)

        # Wait for items to be distributed
        items = await collect_stream_items(subscriber.queue, max_items=5, timeout=0.5)
        # Latest-wins policy may drop items, so we should have at least some
        self.assertGreater(len(items), 0)
        # Last item should be the latest
        self.assertEqual(items[-1].value, 4)

    async def test_fifo_policy_waits_for_space(self) -> None:
        """FIFO policy waits for queue space."""
        entry = StreamEntry(
            name="test_stream",
            func=None,
            payload_type=TestPayload,
            policy="fifo",
            queue_maxsize=2,
        )
        self.fixture.ensure_topic(entry)

        subscriber = self.fixture.manager.subscribe("test_stream")

        # Publish items
        payload1 = TestPayload(value=1, message="first")
        payload2 = TestPayload(value=2, message="second")
        payload3 = TestPayload(value=3, message="third")

        self.fixture.manager.publish("test_stream", payload1)
        self.fixture.manager.publish("test_stream", payload2)
        self.fixture.manager.publish("test_stream", payload3)

        # FIFO should preserve order - wait for items
        items = await collect_stream_items(subscriber.queue, max_items=3, timeout=0.5)
        # With FIFO, items should be in order
        if len(items) >= 2:
            self.assertEqual(items[0].value, 1)
            self.assertEqual(items[1].value, 2)


class TestStreamManagerTaskCleanup(AsyncTestBase):
    """Tests to verify proper task cleanup and no hanging tasks."""

    def setUp(self) -> None:
        """Set up test with StreamManager fixture."""
        super().setUp()
        self.fixture = StreamManagerFixture(self)

    async def test_distributor_tasks_tracked(self) -> None:
        """Distributor tasks are tracked and can be cancelled."""
        entry = StreamEntry(
            name="test_stream",
            func=None,
            payload_type=TestPayload,
        )
        self.fixture.ensure_topic(entry)

        # Wait for task to be created
        topic = self.fixture.manager._topics["test_stream"]
        await wait_for_condition(lambda: topic.get("task") is not None, timeout=0.5)

        self.assertIsNotNone(topic["task"])
        self.assertIn(topic["task"], self._tasks)

    async def test_multiple_streams_multiple_tasks(self) -> None:
        """Multiple streams create multiple distributor tasks."""
        entry1 = StreamEntry(
            name="stream1",
            func=None,
            payload_type=TestPayload,
        )
        entry2 = StreamEntry(
            name="stream2",
            func=None,
            payload_type=TestPayload,
        )

        self.fixture.ensure_topic(entry1)
        self.fixture.ensure_topic(entry2)

        # Wait for tasks to be created
        topic1 = self.fixture.manager._topics["stream1"]
        topic2 = self.fixture.manager._topics["stream2"]

        await wait_for_condition(
            lambda: topic1.get("task") is not None and topic2.get("task") is not None,
            timeout=0.5,
        )

        self.assertIsNotNone(topic1["task"])
        self.assertIsNotNone(topic2["task"])
        self.assertIsNot(topic1["task"], topic2["task"])

    async def test_task_cleanup_in_teardown(self) -> None:
        """All tasks are cancelled and cleaned up in tearDown."""
        entry = StreamEntry(
            name="test_stream",
            func=None,
            payload_type=TestPayload,
        )
        self.fixture.ensure_topic(entry)

        # Wait for task to be created
        topic = self.fixture.manager._topics["test_stream"]
        await wait_for_condition(lambda: topic.get("task") is not None, timeout=0.5)

        task = topic["task"]
        self.assertIsNotNone(task)
        self.assertFalse(task.done())

        # Cleanup should cancel the task (will be checked in asyncTearDown)
