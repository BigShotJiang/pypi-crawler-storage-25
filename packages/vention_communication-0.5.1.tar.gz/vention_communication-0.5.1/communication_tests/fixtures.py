"""Test fixtures and utilities for vention-communication tests."""

from __future__ import annotations

import asyncio
import tempfile
import unittest
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Optional

from pydantic import BaseModel

from communication.decorators import _actions, _streams, set_global_app
from communication.connect_router import ConnectRouter, StreamManager
from communication.entries import StreamEntry


# ---------- Sample Enums for Testing ----------


class Status(str, Enum):
    """Test enum for status values."""

    PENDING = "pending"
    ACTIVE = "active"
    COMPLETED = "completed"


class Direction(str, Enum):
    """Test enum with values that might collide (LEFT, RIGHT)."""

    LEFT = "left"
    RIGHT = "right"
    UP = "up"
    DOWN = "down"


class FilterOperation(str, Enum):
    """Test FilterOperation enum - should get short names without prefix."""

    EQUALS = "eq"
    NOT_EQUALS = "ne"
    GREATER_THAN = "gt"


# ---------- Sample Pydantic Models for Testing ----------


class SimpleRequest(BaseModel):
    """Simple request model for testing."""

    message: str


class SimpleResponse(BaseModel):
    """Simple response model for testing."""

    message: str
    success: bool


class ComplexRequest(BaseModel):
    """Complex request model with multiple field types."""

    name: str
    count: int
    price: float
    active: bool


class NestedRequest(BaseModel):
    """Nested request model for testing complex structures."""

    inner: SimpleRequest
    count: int


class RequestWithEnum(BaseModel):
    """Request model with enum field for testing enum generation."""

    name: str
    status: Status
    direction: Optional[Direction] = None


class FilterRequest(BaseModel):
    """Request model with FilterOperation enum for testing short names."""

    field: str
    operation: FilterOperation
    value: Optional[str] = None


# ---------- Helper Functions ----------


def reset_decorator_state() -> None:
    """Clear the global decorator state between tests.

    This ensures test isolation by clearing the _actions and _streams lists.
    """
    _actions.clear()
    _streams.clear()
    set_global_app(None)


# ---------- VentionApp Fixture ----------


class VentionAppFixture:
    """Fixture helper for testing VentionApp with proper cleanup."""

    def __init__(self, temp_dir: Path | None = None) -> None:
        """Initialize fixture with optional temp directory for proto files."""
        self.temp_dir = temp_dir or Path(tempfile.mkdtemp())
        self.temp_dir.mkdir(parents=True, exist_ok=True)
        self._created_dirs: list[Path] = []

    def get_proto_path(self, filename: str = "test.proto") -> str:
        """Get a proto file path in the temp directory."""
        proto_dir = self.temp_dir / "proto"
        proto_dir.mkdir(exist_ok=True)
        self._created_dirs.append(proto_dir)
        return str(proto_dir / filename)

    def cleanup(self) -> None:
        """Clean up temporary files and directories."""
        import shutil

        if self.temp_dir.exists():
            shutil.rmtree(self.temp_dir)
        reset_decorator_state()

    def read_proto_file(self, proto_path: str) -> str:
        """Read contents of a generated proto file."""
        with open(proto_path, "r", encoding="utf-8") as f:
            return f.read()


# ---------- Async Test Base ----------


class AsyncTestBase(unittest.IsolatedAsyncioTestCase):
    """Base class for async tests with proper task cleanup.

    Tracks all created async tasks and ensures they are cancelled
    and awaited in tearDown to prevent hanging tests.
    """

    def setUp(self) -> None:
        """Set up test with task tracking."""
        self._tasks: set[asyncio.Task[Any]] = set()

    def track_task(self, task: asyncio.Task[Any]) -> asyncio.Task[Any]:
        """Track an async task for cleanup.

        Args:
            task: Task to track

        Returns:
            The same task for chaining
        """
        self._tasks.add(task)
        task.add_done_callback(lambda _: self._tasks.discard(task))
        return task

    async def asyncTearDown(self) -> None:
        """Cancel all tracked tasks and verify cleanup."""
        # Cancel all tracked tasks (only those that aren't done)
        tasks_to_cancel = [task for task in list(self._tasks) if not task.done()]

        # Cancel tasks one by one to avoid recursion issues
        for task in tasks_to_cancel:
            try:
                if not task.cancelled():
                    task.cancel()
            except Exception:
                pass  # Task might already be cancelled or gone

        # Wait briefly for tracked tasks to finish cancelling
        if tasks_to_cancel:
            try:
                # Use a shorter timeout and don't wait for all
                await asyncio.wait_for(
                    asyncio.gather(*tasks_to_cancel, return_exceptions=True),
                    timeout=0.1,
                )
            except (asyncio.TimeoutError, Exception):
                pass  # Some tasks may not cancel immediately, that's ok


# ---------- StreamManager Fixture ----------


class StreamManagerFixture:
    """Fixture helper for testing StreamManager with proper async cleanup."""

    def __init__(self, test_case: AsyncTestBase) -> None:
        """Initialize fixture with test case for task tracking.

        Args:
            test_case: AsyncTestBase instance to track tasks
        """
        self.manager = StreamManager()
        self.test_case = test_case

    def ensure_topic(self, entry: StreamEntry) -> None:
        """Ensure topic exists and track distributor task if created.

        Args:
            entry: Stream entry to create topic for
        """
        self.manager.ensure_topic(entry)
        # Track distributor task if created
        topic = self.manager._topics.get(entry.name)
        if topic and topic["task"]:
            self.test_case.track_task(topic["task"])

    def cleanup(self) -> None:
        """Cancel all distributor tasks."""
        for topic in self.manager._topics.values():
            if topic["task"] and not topic["task"].done():
                try:
                    # Mark as cancelled without recursive cancellation
                    if not topic["task"].cancelled():
                        topic["task"].cancel()
                except Exception:
                    pass  # Task might already be gone


# ---------- ConnectRouter Fixture ----------


class ConnectRouterFixture:
    """Fixture helper for testing ConnectRouter with proper async cleanup."""

    def __init__(self, test_case: AsyncTestBase) -> None:
        """Initialize fixture with test case for task tracking.

        Args:
            test_case: AsyncTestBase instance to track tasks
        """
        self.router = ConnectRouter()
        self.test_case = test_case

    async def cleanup(self) -> None:
        """Clean up all stream manager tasks."""
        # Clean up stream manager tasks
        stream_fixture = StreamManagerFixture(self.test_case)
        stream_fixture.manager = self.router.manager
        stream_fixture.cleanup()


def get_route_paths(router: ConnectRouter) -> list[str]:
    """Get all route paths from router.

    Args:
        router: ConnectRouter instance

    Returns:
        List of route path strings
    """
    return [r.path for r in router.router.routes if hasattr(r, "path")]


# ---------- Async Helper Functions ----------


async def safe_queue_get(queue: asyncio.Queue[Any], timeout: float = 1.0) -> Any:
    """Get item from queue with timeout to prevent hangs.

    Args:
        queue: Queue to get item from
        timeout: Maximum time to wait in seconds

    Returns:
        Item from queue

    Raises:
        asyncio.TimeoutError: If timeout is exceeded
    """
    return await asyncio.wait_for(queue.get(), timeout=timeout)


async def collect_stream_items(queue: asyncio.Queue[Any], max_items: int = 10, timeout: float = 2.0) -> list[Any]:
    """Collect items from queue with timeout.

    Args:
        queue: Queue to collect items from
        max_items: Maximum number of items to collect
        timeout: Maximum time to wait in seconds

    Returns:
        List of collected items
    """
    items: list[Any] = []
    start_time = asyncio.get_event_loop().time()
    while len(items) < max_items:
        elapsed = asyncio.get_event_loop().time() - start_time
        if elapsed >= timeout:
            break
        remaining_timeout = timeout - elapsed
        try:
            item = await asyncio.wait_for(queue.get(), timeout=remaining_timeout)
            items.append(item)
        except asyncio.TimeoutError:
            break
    return items


async def wait_for_condition(
    condition: Callable[[], bool],
    timeout: float = 1.0,
    check_interval: float = 0.01,
) -> None:
    """Wait for a condition to become true, checking periodically.

    Args:
        condition: Callable that returns True when condition is met
        timeout: Maximum time to wait in seconds
        check_interval: How often to check the condition

    Raises:
        asyncio.TimeoutError: If condition is not met within timeout
    """
    start_time = asyncio.get_event_loop().time()
    while not condition():
        elapsed = asyncio.get_event_loop().time() - start_time
        if elapsed >= timeout:
            raise asyncio.TimeoutError(f"Condition not met within {timeout} seconds")
        await asyncio.sleep(check_interval)
