"""Tests for ConnectRouter with async-safe task management."""

from __future__ import annotations

import asyncio
import json
from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock
from typing import Any

from fastapi import Request
from fastapi.responses import JSONResponse, StreamingResponse
from fastapi.routing import APIRoute
from pydantic import BaseModel

from communication.entries import ActionEntry, StreamEntry
from communication_tests.fixtures import (
    AsyncTestBase,
    ConnectRouterFixture,
    SimpleRequest,
    SimpleResponse,
    wait_for_condition,
)


# ---------- Test Models ----------


class StreamPayload(SimpleResponse):
    """Test payload for streams."""

    pass


# ---------- Test Functions ----------


def sync_handler(req: SimpleRequest) -> SimpleResponse:
    """Synchronous handler function."""
    return SimpleResponse(message=f"Echo: {req.message}", success=True)


async def async_handler(req: SimpleRequest) -> SimpleResponse:
    """Asynchronous handler function."""
    await asyncio.sleep(0.01)  # Simulate async work
    return SimpleResponse(message=f"Async: {req.message}", success=True)


def no_input_handler() -> SimpleResponse:
    """Handler with no input."""
    return SimpleResponse(message="No input", success=True)


def error_handler(req: SimpleRequest) -> SimpleResponse:
    """Handler that raises an error."""
    raise ValueError("Test error")


# ---------- Tests ----------


class TestConnectRouterRouteRegistration(AsyncTestBase):
    """Tests for ConnectRouter route registration."""

    def setUp(self) -> None:
        """Set up test with ConnectRouter fixture."""
        super().setUp()
        self.fixture = ConnectRouterFixture(self)

    async def asyncTearDown(self) -> None:
        """Clean up stream manager tasks."""
        await self.fixture.cleanup()
        await super().asyncTearDown()

    async def test_add_unary_registers_route(self) -> None:
        """add_unary creates POST endpoint with correct path."""
        entry = ActionEntry(
            name="test_action",
            func=sync_handler,
            input_type=SimpleRequest,
            output_type=SimpleResponse,
        )
        service_fqn = "vention.app.v1.TestService"
        self.fixture.router.add_unary(entry, service_fqn)

        # Check route is registered
        self.assertIn("test_action", self.fixture.router._unaries)
        expected_path = f"/{service_fqn}/test_action"
        routes = [route.path for route in self.fixture.router.router.routes if isinstance(route, APIRoute)]
        self.assertIn(expected_path, routes)

    async def test_add_unary_forwards_explicit_tag(self) -> None:
        """add_unary forwards entry.tag to the route."""
        entry = ActionEntry(
            name="Settings_GetRecord",
            func=sync_handler,
            input_type=SimpleRequest,
            output_type=SimpleResponse,
            tag="Settings",
        )
        service_fqn = "vention.app.v1.TestService"
        self.fixture.router.add_unary(entry, service_fqn)

        route = next(r for r in self.fixture.router.router.routes if isinstance(r, APIRoute) and r.path.endswith("/Settings_GetRecord"))
        assert isinstance(route, APIRoute)
        self.assertEqual(route.tags, ["Settings"])

    async def test_add_unary_no_tag_by_default(self) -> None:
        """add_unary omits tag when entry.tag is None."""
        entry = ActionEntry(
            name="healthcheck",
            func=no_input_handler,
            input_type=None,
            output_type=SimpleResponse,
        )
        service_fqn = "vention.app.v1.TestService"
        self.fixture.router.add_unary(entry, service_fqn)

        route = next(r for r in self.fixture.router.router.routes if isinstance(r, APIRoute) and r.path.endswith("/healthcheck"))
        assert isinstance(route, APIRoute)
        self.assertFalse(route.tags)

    async def test_add_stream_forwards_explicit_tag(self) -> None:
        """add_stream forwards entry.tag to the route."""
        entry = StreamEntry(
            name="mqtt_events",
            func=None,
            payload_type=StreamPayload,
            tag="MQTT",
        )
        service_fqn = "vention.app.v1.TestService"
        self.fixture.router.add_stream(entry, service_fqn)

        route = next(r for r in self.fixture.router.router.routes if isinstance(r, APIRoute) and r.path.endswith("/mqtt_events"))
        assert isinstance(route, APIRoute)
        self.assertEqual(route.tags, ["MQTT"])

    async def test_add_unary_forwards_summary_and_description(self) -> None:
        """add_unary forwards summary and description to the route."""
        entry = ActionEntry(
            name="documented_action",
            func=sync_handler,
            input_type=SimpleRequest,
            output_type=SimpleResponse,
            summary="Get a thing",
            description="Returns the thing with full details.",
        )
        service_fqn = "vention.app.v1.TestService"
        self.fixture.router.add_unary(entry, service_fqn)

        route = next(r for r in self.fixture.router.router.routes if isinstance(r, APIRoute) and r.path.endswith("/documented_action"))
        assert isinstance(route, APIRoute)
        self.assertEqual(route.summary, "Get a thing")
        self.assertEqual(route.description, "Returns the thing with full details.")

    async def test_add_unary_forwards_deprecated(self) -> None:
        """add_unary forwards deprecated flag to the route."""
        entry = ActionEntry(
            name="old_action",
            func=sync_handler,
            input_type=SimpleRequest,
            output_type=SimpleResponse,
            deprecated=True,
        )
        service_fqn = "vention.app.v1.TestService"
        self.fixture.router.add_unary(entry, service_fqn)

        route = next(r for r in self.fixture.router.router.routes if isinstance(r, APIRoute) and r.path.endswith("/old_action"))
        assert isinstance(route, APIRoute)
        self.assertTrue(route.deprecated)

    async def test_add_unary_exposes_openapi_schema(self) -> None:
        """add_unary exposes response_model and requestBody schema for OpenAPI."""
        entry = ActionEntry(
            name="schema_action",
            func=sync_handler,
            input_type=SimpleRequest,
            output_type=SimpleResponse,
        )
        service_fqn = "vention.app.v1.TestService"
        self.fixture.router.add_unary(entry, service_fqn)

        # Find the registered route
        route = next(r for r in self.fixture.router.router.routes if isinstance(r, APIRoute) and r.path.endswith("/schema_action"))
        assert isinstance(route, APIRoute)

        # response_model should be set to the output type
        self.assertIs(route.response_model, SimpleResponse)

        # openapi_extra should contain requestBody with input type schema
        self.assertIsNotNone(route.openapi_extra)
        assert route.openapi_extra is not None
        request_schema = route.openapi_extra["requestBody"]["content"]["application/json"]["schema"]
        self.assertIn("properties", request_schema)
        self.assertIn("message", request_schema["properties"])

    async def test_add_unary_no_input_skips_request_schema(self) -> None:
        """add_unary omits requestBody schema when input_type is None."""
        entry = ActionEntry(
            name="no_input_schema",
            func=no_input_handler,
            input_type=None,
            output_type=SimpleResponse,
        )
        service_fqn = "vention.app.v1.TestService"
        self.fixture.router.add_unary(entry, service_fqn)

        route = next(r for r in self.fixture.router.router.routes if isinstance(r, APIRoute) and r.path.endswith("/no_input_schema"))
        assert isinstance(route, APIRoute)

        # response_model still set
        self.assertIs(route.response_model, SimpleResponse)

        # No openapi_extra (no input type)
        self.assertIsNone(route.openapi_extra)

    async def test_add_stream_registers_route(self) -> None:
        """add_stream creates POST endpoint with correct path."""
        entry = StreamEntry(
            name="test_stream",
            func=None,
            payload_type=StreamPayload,
        )
        service_fqn = "vention.app.v1.TestService"
        self.fixture.router.add_stream(entry, service_fqn)

        # Check route is registered
        self.assertIn("test_stream", self.fixture.router._streams)
        expected_path = f"/{service_fqn}/test_stream"
        routes = [route.path for route in self.fixture.router.router.routes if isinstance(route, APIRoute)]
        self.assertIn(expected_path, routes)

    async def test_add_unary_multiple_actions(self) -> None:
        """Multiple unary actions can be registered."""
        entry1 = ActionEntry(
            name="action1",
            func=sync_handler,
            input_type=SimpleRequest,
            output_type=SimpleResponse,
        )
        entry2 = ActionEntry(
            name="action2",
            func=sync_handler,
            input_type=SimpleRequest,
            output_type=SimpleResponse,
        )
        service_fqn = "vention.app.v1.TestService"

        self.fixture.router.add_unary(entry1, service_fqn)
        self.fixture.router.add_unary(entry2, service_fqn)

        self.assertEqual(len(self.fixture.router._unaries), 2)
        self.assertIn("action1", self.fixture.router._unaries)
        self.assertIn("action2", self.fixture.router._unaries)


class TestConnectRouterUnaryRequestHandling(AsyncTestBase):
    """Tests for ConnectRouter unary request handling."""

    def setUp(self) -> None:
        """Set up test with ConnectRouter fixture."""
        super().setUp()
        self.fixture = ConnectRouterFixture(self)

    async def asyncTearDown(self) -> None:
        """Clean up stream manager tasks."""
        await self.fixture.cleanup()
        await super().asyncTearDown()

    def _create_mock_request(self, json_body: dict[str, Any] | None = None) -> Request:
        """Create a mock FastAPI Request object."""
        mock_request = MagicMock(spec=Request)
        if json_body is None:
            json_body = {}
        mock_request.json = AsyncMock(return_value=json_body)
        return mock_request

    async def test_unary_handler_with_pydantic_input(self) -> None:
        """Unary handler processes Pydantic model input correctly."""
        entry = ActionEntry(
            name="test_action",
            func=sync_handler,
            input_type=SimpleRequest,
            output_type=SimpleResponse,
        )
        service_fqn = "vention.app.v1.TestService"
        self.fixture.router.add_unary(entry, service_fqn)

        # Get the handler from the route
        route = next(r for r in self.fixture.router.router.routes if isinstance(r, APIRoute) and r.path.endswith("/test_action"))
        assert isinstance(route, APIRoute)
        handler = route.endpoint

        # Create mock request
        request_body = {"message": "test message"}
        mock_request = self._create_mock_request(request_body)

        # Call handler
        response = await handler(mock_request)

        # Check response
        self.assertIsInstance(response, JSONResponse)
        response_body = json.loads(response.body.decode())
        self.assertEqual(response_body["message"], "Echo: test message")
        self.assertTrue(response_body["success"])

    async def test_unary_handler_with_no_input(self) -> None:
        """Unary handler works with no input type."""
        entry = ActionEntry(
            name="no_input_action",
            func=no_input_handler,
            input_type=None,
            output_type=SimpleResponse,
        )
        service_fqn = "vention.app.v1.TestService"
        self.fixture.router.add_unary(entry, service_fqn)

        # Get the handler
        route = next(r for r in self.fixture.router.router.routes if isinstance(r, APIRoute) and r.path.endswith("/no_input_action"))
        assert isinstance(route, APIRoute)
        handler = route.endpoint

        # Create mock request (empty body)
        mock_request = self._create_mock_request({})

        # Call handler
        response = await handler(mock_request)

        # Check response
        self.assertIsInstance(response, JSONResponse)
        response_body = json.loads(response.body.decode())
        self.assertEqual(response_body["message"], "No input")
        self.assertTrue(response_body["success"])

    async def test_unary_handler_async_function(self) -> None:
        """Unary handler works with async handler function."""
        entry = ActionEntry(
            name="async_action",
            func=async_handler,
            input_type=SimpleRequest,
            output_type=SimpleResponse,
        )
        service_fqn = "vention.app.v1.TestService"
        self.fixture.router.add_unary(entry, service_fqn)

        # Get the handler
        route = next(r for r in self.fixture.router.router.routes if isinstance(r, APIRoute) and r.path.endswith("/async_action"))
        assert isinstance(route, APIRoute)
        handler = route.endpoint

        # Create mock request
        request_body = {"message": "async test"}
        mock_request = self._create_mock_request(request_body)

        # Call handler
        response = await handler(mock_request)

        # Check response
        self.assertIsInstance(response, JSONResponse)
        response_body = json.loads(response.body.decode())
        self.assertEqual(response_body["message"], "Async: async test")
        self.assertTrue(response_body["success"])

    async def test_unary_handler_error_handling(self) -> None:
        """Unary handler wraps errors in Connect error envelope."""
        entry = ActionEntry(
            name="error_action",
            func=error_handler,
            input_type=SimpleRequest,
            output_type=SimpleResponse,
        )
        service_fqn = "vention.app.v1.TestService"
        self.fixture.router.add_unary(entry, service_fqn)

        # Get the handler
        route = next(r for r in self.fixture.router.router.routes if isinstance(r, APIRoute) and r.path.endswith("/error_action"))
        assert isinstance(route, APIRoute)
        handler = route.endpoint

        # Create mock request
        request_body = {"message": "test"}
        mock_request = self._create_mock_request(request_body)

        # Call handler
        response = await handler(mock_request)

        # Check error response
        self.assertIsInstance(response, JSONResponse)
        response_body = json.loads(response.body.decode())
        self.assertIn("error", response_body)
        self.assertEqual(response_body["error"]["code"], "invalid_argument")

    async def test_unary_handler_invalid_json_body(self) -> None:
        """Unary handler handles invalid JSON body gracefully."""
        entry = ActionEntry(
            name="test_action",
            func=sync_handler,
            input_type=SimpleRequest,
            output_type=SimpleResponse,
        )
        service_fqn = "vention.app.v1.TestService"
        self.fixture.router.add_unary(entry, service_fqn)

        # Get the handler
        route = next(r for r in self.fixture.router.router.routes if isinstance(r, APIRoute) and r.path.endswith("/test_action"))
        assert isinstance(route, APIRoute)
        handler = route.endpoint

        # Create mock request that raises on json()
        mock_request = MagicMock(spec=Request)
        mock_request.json = AsyncMock(side_effect=ValueError("Invalid JSON"))

        # Call handler - should use empty dict
        response = await handler(mock_request)

        # Should still work (uses empty dict as fallback)
        self.assertIsInstance(response, JSONResponse)

    async def test_unary_handler_plain_dict_with_datetime(self) -> None:
        """Regression for RO-127: a handler returning a plain dict that contains
        a datetime value must still serialize to JSON without raising
        'Object of type datetime is not JSON serializable'."""
        tested_at = datetime(2026, 1, 15, 10, 30, 45, tzinfo=timezone.utc)

        def dict_with_datetime_handler() -> dict[str, Any]:
            return {
                "records": [
                    {"name": "A31AV", "tested": True, "tested_timestamp": tested_at},
                ]
            }

        entry = ActionEntry(
            name="list_records_action",
            func=dict_with_datetime_handler,
            input_type=None,
            output_type=None,
        )
        service_fqn = "vention.app.v1.TestService"
        self.fixture.router.add_unary(entry, service_fqn)

        route = next(
            registered_route
            for registered_route in self.fixture.router.router.routes
            if isinstance(registered_route, APIRoute) and registered_route.path.endswith("/list_records_action")
        )
        assert isinstance(route, APIRoute)
        handler = route.endpoint

        response = await handler(self._create_mock_request({}))

        self.assertIsInstance(response, JSONResponse)
        response_body = json.loads(response.body.decode())
        self.assertNotIn("error", response_body)
        self.assertEqual(response_body["records"][0]["name"], "A31AV")
        self.assertEqual(response_body["records"][0]["tested_timestamp"], tested_at.isoformat())

    async def test_unary_handler_pydantic_with_datetime(self) -> None:
        """Pydantic handler return values with datetime fields serialize as ISO strings."""

        class ResponseWithDatetime(BaseModel):
            name: str
            tested_timestamp: datetime

        tested_at = datetime(2026, 1, 15, 10, 30, 45, tzinfo=timezone.utc)

        def pydantic_handler() -> ResponseWithDatetime:
            return ResponseWithDatetime(name="A31AV", tested_timestamp=tested_at)

        entry = ActionEntry(
            name="pydantic_datetime_action",
            func=pydantic_handler,
            input_type=None,
            output_type=ResponseWithDatetime,
        )
        service_fqn = "vention.app.v1.TestService"
        self.fixture.router.add_unary(entry, service_fqn)

        route = next(
            registered_route
            for registered_route in self.fixture.router.router.routes
            if isinstance(registered_route, APIRoute) and registered_route.path.endswith("/pydantic_datetime_action")
        )
        assert isinstance(route, APIRoute)
        handler = route.endpoint

        response = await handler(self._create_mock_request({}))

        self.assertIsInstance(response, JSONResponse)
        response_body = json.loads(response.body.decode())
        self.assertNotIn("error", response_body)
        self.assertEqual(response_body["name"], "A31AV")
        serialized = response_body["tested_timestamp"]
        self.assertIsInstance(serialized, str)
        self.assertEqual(datetime.fromisoformat(serialized.replace("Z", "+00:00")), tested_at)


class TestConnectRouterStreamHandling(AsyncTestBase):
    """Tests for ConnectRouter stream endpoint handling."""

    def setUp(self) -> None:
        """Set up test with ConnectRouter fixture."""
        super().setUp()
        self.fixture = ConnectRouterFixture(self)

    async def asyncTearDown(self) -> None:
        """Clean up stream manager tasks."""
        await self.fixture.cleanup()
        await super().asyncTearDown()

    def _create_mock_request(self) -> Request:
        """Create a mock FastAPI Request object."""
        return MagicMock(spec=Request)

    async def test_stream_handler_creates_subscriber(self) -> None:
        """Stream handler creates subscriber and returns StreamingResponse."""
        entry = StreamEntry(
            name="test_stream",
            func=None,
            payload_type=StreamPayload,
        )
        service_fqn = "vention.app.v1.TestService"
        self.fixture.router.add_stream(entry, service_fqn)

        # Get the handler
        route = next(r for r in self.fixture.router.router.routes if isinstance(r, APIRoute) and r.path.endswith("/test_stream"))
        assert isinstance(route, APIRoute)
        handler = route.endpoint

        # Create mock request
        mock_request = self._create_mock_request()

        # Call handler
        response = await handler(mock_request)

        # Check response type
        self.assertIsInstance(response, StreamingResponse)
        self.assertEqual(response.media_type, "application/connect+json")
        self.assertEqual(response.headers["Transfer-Encoding"], "chunked")

        # Check that subscriber was created
        topic = self.fixture.router.manager._topics.get("test_stream")
        self.assertIsNotNone(topic)
        assert topic is not None
        self.assertGreater(len(topic["subscribers"]), 0)

    async def test_stream_handler_creates_subscriber_in_manager(self) -> None:
        """Stream handler creates subscriber in StreamManager."""
        entry = StreamEntry(
            name="test_stream",
            func=None,
            payload_type=StreamPayload,
        )
        service_fqn = "vention.app.v1.TestService"
        self.fixture.router.add_stream(entry, service_fqn)

        # Get initial subscriber count
        topic = self.fixture.router.manager._topics.get("test_stream")
        if topic:
            initial_count = len(topic["subscribers"])
        else:
            initial_count = 0

        # Get the handler
        route = next(r for r in self.fixture.router.router.routes if isinstance(r, APIRoute) and r.path.endswith("/test_stream"))
        assert isinstance(route, APIRoute)
        handler = route.endpoint

        # Create mock request
        mock_request = self._create_mock_request()

        # Call handler
        response = await handler(mock_request)
        self.assertIsInstance(response, StreamingResponse)

        # Check that subscriber was created
        topic = self.fixture.router.manager._topics.get("test_stream")
        self.assertIsNotNone(topic)
        assert topic is not None
        self.assertGreater(len(topic["subscribers"]), initial_count)


class TestConnectRouterPublish(AsyncTestBase):
    """Tests for ConnectRouter publish method."""

    def setUp(self) -> None:
        """Set up test with ConnectRouter fixture."""
        super().setUp()
        self.fixture = ConnectRouterFixture(self)

    async def asyncTearDown(self) -> None:
        """Clean up stream manager tasks."""
        await self.fixture.cleanup()
        await super().asyncTearDown()

    async def test_publish_to_registered_stream(self) -> None:
        """publish works with registered stream."""
        entry = StreamEntry(
            name="test_stream",
            func=None,
            payload_type=StreamPayload,
        )
        service_fqn = "vention.app.v1.TestService"
        self.fixture.router.add_stream(entry, service_fqn)

        # Publish should work
        payload = StreamPayload(message="test", success=True)
        self.fixture.router.publish("test_stream", payload)

        # Wait for value to be stored
        topic = self.fixture.router.manager._topics.get("test_stream")
        assert topic is not None
        await wait_for_condition(
            lambda: topic["last_value"] == payload,
            timeout=0.5,
        )

        self.assertEqual(topic["last_value"], payload)

    async def test_publish_creates_topic_if_missing(self) -> None:
        """publish creates topic if stream is registered but topic doesn't exist."""
        entry = StreamEntry(
            name="test_stream",
            func=None,
            payload_type=StreamPayload,
        )
        service_fqn = "vention.app.v1.TestService"
        self.fixture.router.add_stream(entry, service_fqn)

        # Clear the topic (simulate it not existing)
        self.fixture.router.manager._topics.clear()

        # Publish should create the topic
        payload = StreamPayload(message="test", success=True)
        self.fixture.router.publish("test_stream", payload)

        # Topic should now exist
        self.assertIn("test_stream", self.fixture.router.manager._topics)

    async def test_publish_raises_keyerror_unknown_stream(self) -> None:
        """publish raises KeyError for unknown stream."""
        with self.assertRaises(KeyError) as context:
            self.fixture.router.publish("unknown", StreamPayload(message="test", success=True))
        self.assertIn("Unknown stream", str(context.exception))


class TestConnectRouterSerialization(AsyncTestBase):
    """Tests for stream item serialization."""

    def setUp(self) -> None:
        """Set up test with ConnectRouter fixture."""
        super().setUp()
        self.fixture = ConnectRouterFixture(self)

    async def asyncTearDown(self) -> None:
        """Clean up stream manager tasks."""
        await self.fixture.cleanup()
        await super().asyncTearDown()

    async def test_serialize_pydantic_model(self) -> None:
        """Pydantic models are serialized with by_alias=True."""
        from communication.connect_router import _serialize_stream_item

        payload = StreamPayload(message="test", success=True)
        result = _serialize_stream_item(payload)
        self.assertIsInstance(result, dict)
        self.assertIn("message", result)
        self.assertIn("success", result)

    async def test_serialize_dict(self) -> None:
        """Dict items are serialized as-is."""
        from communication.connect_router import _serialize_stream_item

        item = {"key": "value", "number": 123}
        result = _serialize_stream_item(item)
        self.assertEqual(result, item)

    async def test_serialize_list(self) -> None:
        """List items are wrapped in value key."""
        from communication.connect_router import _serialize_stream_item

        item = [1, 2, 3]
        result = _serialize_stream_item(item)
        self.assertEqual(result, {"value": item})

    async def test_serialize_scalar(self) -> None:
        """Scalar values are wrapped in value key."""
        from communication.connect_router import _serialize_stream_item

        item = "string_value"
        result = _serialize_stream_item(item)
        self.assertEqual(result, {"value": item})

        item_int = 42
        result_int = _serialize_stream_item(item_int)
        self.assertEqual(result_int, {"value": item_int})

    async def test_serialize_datetime_field(self) -> None:
        """Datetime fields are serialized to ISO format strings."""
        from datetime import datetime
        from pydantic import BaseModel
        from communication.connect_router import _serialize_stream_item

        class ModelWithDatetime(BaseModel):
            name: str
            timestamp: datetime

        test_time = datetime(2024, 1, 15, 10, 30, 45)
        model = ModelWithDatetime(name="test", timestamp=test_time)
        result = _serialize_stream_item(model)

        self.assertIsInstance(result, dict)
        self.assertEqual(result["name"], "test")
        # Datetime should be serialized to ISO format string
        self.assertIsInstance(result["timestamp"], str)
        self.assertEqual(result["timestamp"], test_time.isoformat())


class TestConnectRouterStreamErrorHandling(AsyncTestBase):
    """Tests for stream error handling."""

    def setUp(self) -> None:
        """Set up test with ConnectRouter fixture."""
        super().setUp()
        self.fixture = ConnectRouterFixture(self)

    async def asyncTearDown(self) -> None:
        """Clean up stream manager tasks."""
        await self.fixture.cleanup()
        await super().asyncTearDown()

    async def test_stream_error_handling(self) -> None:
        """Stream errors are caught and sent as error trailer."""
        from communication.connect_router import _frame
        from communication.errors import error_envelope, to_connect_error

        entry = StreamEntry(
            name="error_stream",
            func=None,
            payload_type=StreamPayload,
        )
        service_fqn = "vention.app.v1.TestService"
        self.fixture.router.add_stream(entry, service_fqn)

        # Subscribe to get a subscriber
        topic = self.fixture.router.manager._topics.get("error_stream")
        assert topic is not None
        subscriber = self.fixture.router.manager.subscribe("error_stream")

        # Simulate an error by putting an exception in the queue
        test_error = ValueError("Test error")
        error_trailer = error_envelope(to_connect_error(test_error))
        error_frame = _frame(error_trailer, trailer=True)

        # Verify error frame is properly formatted
        self.assertIsInstance(error_frame, bytes)
        self.assertGreater(len(error_frame), 0)

        # Clean up
        self.fixture.router.manager.unsubscribe("error_stream", subscriber)
