"""Basic tests for proto generation functionality."""

from __future__ import annotations

import unittest


from communication.codegen import generate_proto, sanitize_service_name
from communication.entries import ActionEntry, RpcBundle
from communication_tests.fixtures import ComplexRequest, SimpleRequest, SimpleResponse


class TestSanitizeServiceName(unittest.TestCase):
    """Tests for sanitize_service_name function."""

    def test_simple_name_unchanged(self) -> None:
        """Simple alphanumeric names are capitalized."""
        self.assertEqual(sanitize_service_name("app"), "App")
        self.assertEqual(sanitize_service_name("myApp"), "MyApp")

    def test_name_with_underscores(self) -> None:
        """Underscores are removed, parts are capitalized."""
        self.assertEqual(sanitize_service_name("my_app"), "MyApp")
        self.assertEqual(sanitize_service_name("my_test_app"), "MyTestApp")

    def test_name_with_dashes(self) -> None:
        """Dashes are removed, parts are capitalized."""
        self.assertEqual(sanitize_service_name("my-app"), "MyApp")
        self.assertEqual(sanitize_service_name("my-test-app"), "MyTestApp")

    def test_name_with_numbers(self) -> None:
        """Numbers are preserved in service name."""
        self.assertEqual(sanitize_service_name("app123"), "App123")
        self.assertEqual(sanitize_service_name("app_v2"), "AppV2")

    def test_name_with_special_characters(self) -> None:
        """Special characters are removed."""
        self.assertEqual(sanitize_service_name("my@app#test"), "MyAppTest")
        self.assertEqual(sanitize_service_name("app!test?"), "AppTest")

    def test_mixed_case_preserved(self) -> None:
        """Mixed case is preserved with first letter capitalized per part."""
        self.assertEqual(sanitize_service_name("myApp"), "MyApp")
        self.assertEqual(sanitize_service_name("MyApp"), "MyApp")

    def test_empty_string_defaults(self) -> None:
        """Empty string defaults to VentionApp."""
        self.assertEqual(sanitize_service_name(""), "VentionApp")

    def test_only_special_characters_defaults(self) -> None:
        """String with only special characters defaults to VentionApp."""
        self.assertEqual(sanitize_service_name("@@@###"), "VentionApp")

    def test_single_word(self) -> None:
        """Single word has first letter capitalized."""
        self.assertEqual(sanitize_service_name("test"), "Test")
        # Function only capitalizes first letter, doesn't lowercase rest
        self.assertEqual(sanitize_service_name("TEST"), "TEST")


class TestGenerateProtoBasic(unittest.TestCase):
    """Basic tests for generate_proto function."""

    def test_proto_header(self) -> None:
        """Generated proto includes correct header."""
        bundle = RpcBundle(actions=[], streams=[])
        proto = generate_proto("TestApp", bundle=bundle)
        self.assertIn('syntax = "proto3"', proto)
        self.assertIn("package vention.app.v1", proto)
        self.assertIn('import "google/protobuf/empty.proto"', proto)

    def test_service_definition(self) -> None:
        """Generated proto includes service definition."""
        bundle = RpcBundle(actions=[], streams=[])
        proto = generate_proto("TestApp", bundle=bundle)
        self.assertIn("service TestAppService {", proto)
        self.assertIn("}", proto)

    def test_empty_service(self) -> None:
        """Empty service has no RPC methods."""
        bundle = RpcBundle(actions=[], streams=[])
        proto = generate_proto("TestApp", bundle=bundle)
        # Service should exist but be empty
        lines = proto.split("\n")
        service_start = None
        service_end = None
        for i, line in enumerate(lines):
            if "service TestAppService {" in line:
                service_start = i
            if service_start is not None and line.strip() == "}":
                service_end = i
                break
        self.assertIsNotNone(service_start)
        self.assertIsNotNone(service_end)
        # Type narrowing: assertIsNotNone ensures these are not None
        assert service_start is not None
        assert service_end is not None
        # Check that there are no RPC lines between service start and end
        rpc_lines = [line for line in lines[service_start + 1 : service_end] if "rpc" in line]
        self.assertEqual(len(rpc_lines), 0)

    def test_action_with_pydantic_models(self) -> None:
        """Action with Pydantic models generates message types and RPC."""
        bundle = RpcBundle(
            actions=[
                ActionEntry(
                    name="test_action",
                    func=lambda x: x,
                    input_type=SimpleRequest,
                    output_type=SimpleResponse,
                )
            ],
            streams=[],
        )
        proto = generate_proto("TestApp", bundle=bundle)

        # Check message definitions
        self.assertIn("message SimpleRequest {", proto)
        self.assertIn("message SimpleResponse {", proto)

        # Check message fields
        self.assertIn("string message = 1;", proto)
        self.assertIn("bool success = 2;", proto)

        # Check RPC definition
        self.assertIn("rpc test_action (SimpleRequest) returns (SimpleResponse);", proto)

    def test_message_field_types(self) -> None:
        """Pydantic model fields map to correct proto types."""
        bundle = RpcBundle(
            actions=[
                ActionEntry(
                    name="complex_action",
                    func=lambda x: x,
                    input_type=ComplexRequest,
                    output_type=None,
                )
            ],
            streams=[],
        )
        proto = generate_proto("TestApp", bundle=bundle)

        # Check field type mappings
        self.assertIn("string name = 1;", proto)
        self.assertIn("int32 count = 2;", proto)
        self.assertIn("double price = 3;", proto)
        self.assertIn("bool active = 4;", proto)

    def test_action_with_empty_input(self) -> None:
        """Action with no input uses google.protobuf.Empty."""
        bundle = RpcBundle(
            actions=[
                ActionEntry(
                    name="no_input_action",
                    func=lambda: None,
                    input_type=None,
                    output_type=SimpleResponse,
                )
            ],
            streams=[],
        )
        proto = generate_proto("TestApp", bundle=bundle)
        self.assertIn(
            "rpc no_input_action (google.protobuf.Empty) returns (SimpleResponse);",
            proto,
        )

    def test_action_with_empty_output(self) -> None:
        """Action with no output uses google.protobuf.Empty."""
        bundle = RpcBundle(
            actions=[
                ActionEntry(
                    name="no_output_action",
                    func=lambda x: None,
                    input_type=SimpleRequest,
                    output_type=None,
                )
            ],
            streams=[],
        )
        proto = generate_proto("TestApp", bundle=bundle)
        self.assertIn(
            "rpc no_output_action (SimpleRequest) returns (google.protobuf.Empty);",
            proto,
        )

    def test_multiple_actions(self) -> None:
        """Multiple actions are all included in service."""
        bundle = RpcBundle(
            actions=[
                ActionEntry(
                    name="action1",
                    func=lambda x: x,
                    input_type=SimpleRequest,
                    output_type=SimpleResponse,
                ),
                ActionEntry(
                    name="action2",
                    func=lambda: None,
                    input_type=None,
                    output_type=None,
                ),
            ],
            streams=[],
        )
        proto = generate_proto("TestApp", bundle=bundle)
        self.assertIn("rpc action1", proto)
        self.assertIn("rpc action2", proto)

    def test_duplicate_message_types_deduplicated(self) -> None:
        """Same Pydantic model used multiple times only appears once."""
        bundle = RpcBundle(
            actions=[
                ActionEntry(
                    name="action1",
                    func=lambda x: x,
                    input_type=SimpleRequest,
                    output_type=SimpleResponse,
                ),
                ActionEntry(
                    name="action2",
                    func=lambda x: x,
                    input_type=SimpleRequest,
                    output_type=SimpleResponse,
                ),
            ],
            streams=[],
        )
        proto = generate_proto("TestApp", bundle=bundle)

        # Count occurrences of message definition
        message_count = proto.count("message SimpleRequest {")
        self.assertEqual(message_count, 1)
