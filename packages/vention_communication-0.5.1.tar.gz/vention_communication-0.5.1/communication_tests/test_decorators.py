"""Tests for @action and @stream decorators."""

from __future__ import annotations

import unittest
from typing import Any
from unittest.mock import MagicMock

from pydantic import BaseModel

from communication.decorators import action, stream, collect_bundle, set_global_app
from communication_tests.fixtures import (
    reset_decorator_state,
    SimpleRequest,
    SimpleResponse,
)


# ---------- Test Models ----------


class StreamPayload(BaseModel):
    """Test payload model for streams."""

    value: int


# ---------- Test Functions ----------


def simple_function() -> None:
    """Simple function with no parameters."""
    pass


def function_with_input(req: SimpleRequest) -> SimpleResponse:
    """Function with typed input and output."""
    return SimpleResponse(message="test", success=True)


async def async_function(req: SimpleRequest) -> SimpleResponse:
    """Async function with typed input and output."""
    return SimpleResponse(message="test", success=True)


async def stream_publisher() -> StreamPayload:
    """Test stream publisher function."""
    return StreamPayload(value=42)


# ---------- Tests ----------


class TestActionDecorator(unittest.TestCase):
    """Tests for @action decorator."""

    def setUp(self) -> None:
        """Reset decorator state before each test."""
        reset_decorator_state()

    def test_action_with_explicit_name(self) -> None:
        """@action decorator registers action with explicit name."""

        @action(name="custom_action")
        def test_func(req: SimpleRequest) -> SimpleResponse:
            return SimpleResponse(message="test", success=True)

        bundle = collect_bundle()
        self.assertEqual(len(bundle.actions), 1)
        self.assertEqual(bundle.actions[0].name, "custom_action")
        self.assertEqual(bundle.actions[0].func, test_func)

    def test_action_with_implicit_name(self) -> None:
        """@action decorator uses function name when name not provided."""

        @action()
        def my_action(req: SimpleRequest) -> SimpleResponse:
            return SimpleResponse(message="test", success=True)

        bundle = collect_bundle()
        self.assertEqual(len(bundle.actions), 1)
        self.assertEqual(bundle.actions[0].name, "my_action")
        self.assertEqual(bundle.actions[0].func, my_action)

    def test_action_type_inference(self) -> None:
        """@action decorator infers input and output types from function signature."""

        @action()
        def typed_action(req: SimpleRequest) -> SimpleResponse:
            return SimpleResponse(message="test", success=True)

        bundle = collect_bundle()
        action_entry = bundle.actions[0]
        self.assertEqual(action_entry.input_type, SimpleRequest)
        self.assertEqual(action_entry.output_type, SimpleResponse)

    def test_action_no_input_type(self) -> None:
        """@action decorator handles functions with no input type."""

        @action()
        def no_input() -> SimpleResponse:
            return SimpleResponse(message="test", success=True)

        bundle = collect_bundle()
        action_entry = bundle.actions[0]
        self.assertIsNone(action_entry.input_type)
        self.assertEqual(action_entry.output_type, SimpleResponse)

    def test_action_no_output_type(self) -> None:
        """@action decorator handles functions with no output type."""

        @action()
        def no_output(req: SimpleRequest) -> None:
            pass

        bundle = collect_bundle()
        action_entry = bundle.actions[0]
        self.assertEqual(action_entry.input_type, SimpleRequest)
        self.assertIsNone(action_entry.output_type)

    def test_multiple_actions_registered(self) -> None:
        """Multiple @action decorators register all actions."""

        @action(name="action1")
        def func1(req: SimpleRequest) -> SimpleResponse:
            return SimpleResponse(message="test", success=True)

        @action(name="action2")
        def func2(req: SimpleRequest) -> SimpleResponse:
            return SimpleResponse(message="test", success=True)

        bundle = collect_bundle()
        self.assertEqual(len(bundle.actions), 2)
        names = {entry.name for entry in bundle.actions}
        self.assertEqual(names, {"action1", "action2"})

    def test_action_preserves_function(self) -> None:
        """@action decorator returns the original function."""

        @action()
        def original_func(req: SimpleRequest) -> SimpleResponse:
            return SimpleResponse(message="test", success=True)

        # Decorated function should be the original
        self.assertEqual(original_func.__name__, "original_func")


class TestStreamDecorator(unittest.TestCase):
    """Tests for @stream decorator."""

    def setUp(self) -> None:
        """Reset decorator state before each test."""
        reset_decorator_state()

    def test_stream_with_pydantic_payload(self) -> None:
        """@stream decorator registers stream with Pydantic model payload."""

        @stream(name="test_stream", payload=StreamPayload)
        async def publish_stream() -> StreamPayload:
            return StreamPayload(value=42)

        bundle = collect_bundle()
        self.assertEqual(len(bundle.streams), 1)
        stream_entry = bundle.streams[0]
        self.assertEqual(stream_entry.name, "test_stream")
        self.assertEqual(stream_entry.payload_type, StreamPayload)
        self.assertTrue(stream_entry.replay)
        self.assertEqual(stream_entry.queue_maxsize, 1)
        self.assertEqual(stream_entry.policy, "latest")

    def test_stream_with_scalar_int_payload(self) -> None:
        """@stream decorator accepts int as payload type."""

        @stream(name="int_stream", payload=int)
        async def publish_int() -> int:
            return 42

        bundle = collect_bundle()
        stream_entry = bundle.streams[0]
        self.assertEqual(stream_entry.payload_type, int)

    def test_stream_with_scalar_str_payload(self) -> None:
        """@stream decorator accepts str as payload type."""

        @stream(name="str_stream", payload=str)
        async def publish_str() -> str:
            return "test"

        bundle = collect_bundle()
        stream_entry = bundle.streams[0]
        self.assertEqual(stream_entry.payload_type, str)

    def test_stream_with_scalar_bool_payload(self) -> None:
        """@stream decorator accepts bool as payload type."""

        @stream(name="bool_stream", payload=bool)
        async def publish_bool() -> bool:
            return True

        bundle = collect_bundle()
        stream_entry = bundle.streams[0]
        self.assertEqual(stream_entry.payload_type, bool)

    def test_stream_with_scalar_float_payload(self) -> None:
        """@stream decorator accepts float as payload type."""

        @stream(name="float_stream", payload=float)
        async def publish_float() -> float:
            return 3.14

        bundle = collect_bundle()
        stream_entry = bundle.streams[0]
        self.assertEqual(stream_entry.payload_type, float)

    def test_stream_with_dict_payload(self) -> None:
        """@stream decorator accepts dict as payload type."""

        @stream(name="dict_stream", payload=dict)
        async def publish_dict() -> dict[str, Any]:
            return {"key": "value"}

        bundle = collect_bundle()
        stream_entry = bundle.streams[0]
        self.assertEqual(stream_entry.payload_type, dict)

    def test_stream_invalid_payload_type_raises(self) -> None:
        """@stream decorator raises ValueError for invalid payload types."""
        with self.assertRaises(ValueError) as context:

            @stream(name="invalid", payload=list)
            async def invalid_stream() -> list[Any]:
                return []

        self.assertIn("payload must be a pydantic BaseModel", str(context.exception))

    def test_stream_custom_replay(self) -> None:
        """@stream decorator accepts custom replay setting."""

        @stream(name="no_replay", payload=int, replay=False)
        async def no_replay_stream() -> int:
            return 42

        bundle = collect_bundle()
        stream_entry = bundle.streams[0]
        self.assertFalse(stream_entry.replay)

    def test_stream_custom_queue_maxsize(self) -> None:
        """@stream decorator accepts custom queue_maxsize."""

        @stream(name="large_queue", payload=int, queue_maxsize=10)
        async def large_queue_stream() -> int:
            return 42

        bundle = collect_bundle()
        stream_entry = bundle.streams[0]
        self.assertEqual(stream_entry.queue_maxsize, 10)

    def test_stream_custom_policy(self) -> None:
        """@stream decorator accepts custom policy."""

        @stream(name="fifo_stream", payload=int, policy="fifo")
        async def fifo_stream() -> int:
            return 42

        bundle = collect_bundle()
        stream_entry = bundle.streams[0]
        self.assertEqual(stream_entry.policy, "fifo")

    def test_stream_returns_wrapper_function(self) -> None:
        """@stream decorator returns publisher wrapper, not original function."""

        @stream(name="test_stream", payload=StreamPayload)
        async def original_func() -> StreamPayload:
            return StreamPayload(value=42)

        # The returned function should be the wrapper, not the original
        # The wrapper is async and will be different from original
        self.assertIsNotNone(original_func)
        # Wrapper should be callable
        self.assertTrue(callable(original_func))


class TestCollectBundle(unittest.TestCase):
    """Tests for collect_bundle function."""

    def setUp(self) -> None:
        """Reset decorator state before each test."""
        reset_decorator_state()

    def test_collect_bundle_returns_all_actions(self) -> None:
        """collect_bundle returns all registered actions."""

        @action(name="action1")
        def func1(req: SimpleRequest) -> SimpleResponse:
            return SimpleResponse(message="test", success=True)

        @action(name="action2")
        def func2(req: SimpleRequest) -> SimpleResponse:
            return SimpleResponse(message="test", success=True)

        bundle = collect_bundle()
        self.assertEqual(len(bundle.actions), 2)

    def test_collect_bundle_returns_all_streams(self) -> None:
        """collect_bundle returns all registered streams."""

        @stream(name="stream1", payload=int)
        async def stream1() -> int:
            return 1

        @stream(name="stream2", payload=str)
        async def stream2() -> str:
            return "test"

        bundle = collect_bundle()
        self.assertEqual(len(bundle.streams), 2)

    def test_collect_bundle_returns_mixed_actions_and_streams(self) -> None:
        """collect_bundle returns both actions and streams."""

        @action(name="action1")
        def func1(req: SimpleRequest) -> SimpleResponse:
            return SimpleResponse(message="test", success=True)

        @stream(name="stream1", payload=int)
        async def stream1() -> int:
            return 1

        bundle = collect_bundle()
        self.assertEqual(len(bundle.actions), 1)
        self.assertEqual(len(bundle.streams), 1)

    def test_collect_bundle_preserves_ordering(self) -> None:
        """collect_bundle preserves registration order."""

        @action(name="first")
        def first() -> None:
            pass

        @action(name="second")
        def second() -> None:
            pass

        @action(name="third")
        def third() -> None:
            pass

        bundle = collect_bundle()
        names = [entry.name for entry in bundle.actions]
        self.assertEqual(names, ["first", "second", "third"])

    def test_collect_bundle_creates_new_list(self) -> None:
        """collect_bundle creates new lists, not references to internal lists."""

        @action(name="action1")
        def func1() -> None:
            pass

        bundle1 = collect_bundle()
        bundle2 = collect_bundle()

        # Should be different list instances
        self.assertIsNot(bundle1.actions, bundle2.actions)
        # But should have same content
        self.assertEqual(len(bundle1.actions), len(bundle2.actions))


class TestGlobalAppState(unittest.TestCase):
    """Tests for global app state management."""

    def setUp(self) -> None:
        """Reset decorator state and global app before each test."""
        reset_decorator_state()
        set_global_app(None)

    def test_set_global_app_sets_app(self) -> None:
        """set_global_app sets the global app instance."""
        mock_app = MagicMock()
        set_global_app(mock_app)

        from communication.decorators import _GLOBAL_APP

        self.assertIs(_GLOBAL_APP, mock_app)

    def test_stream_publisher_wrapper_requires_finalized_app(self) -> None:
        """Stream publisher wrapper raises RuntimeError if app not finalized."""

        @stream(name="test_stream", payload=StreamPayload)
        async def publish_stream() -> StreamPayload:
            return StreamPayload(value=42)

        # Try to call publisher wrapper without app finalized
        import asyncio

        async def test_publish() -> None:
            with self.assertRaises(RuntimeError) as context:
                await publish_stream()
            self.assertIn("app.finalize()", str(context.exception))

        asyncio.run(test_publish())

    def test_stream_publisher_wrapper_with_finalized_app(self) -> None:
        """Stream publisher wrapper works when app is finalized."""

        @stream(name="test_stream", payload=StreamPayload)
        async def publish_stream() -> StreamPayload:
            return StreamPayload(value=42)

        # Create mock app with connect_router
        mock_app = MagicMock()
        mock_router = MagicMock()
        mock_app.connect_router = mock_router
        set_global_app(mock_app)

        # Call publisher wrapper
        import asyncio

        async def test_publish() -> None:
            result = await publish_stream()
            # Should return None (wrapper doesn't return the function result)
            self.assertIsNone(result)
            # Should have called publish on router
            mock_router.publish.assert_called_once_with("test_stream", StreamPayload(value=42))

        asyncio.run(test_publish())

    def test_stream_publisher_wrapper_raises_if_no_app(self) -> None:
        """Stream publisher wrapper raises RuntimeError if no app set."""

        @stream(name="test_stream", payload=StreamPayload)
        async def publish_stream() -> StreamPayload:
            return StreamPayload(value=42)

        # Ensure no app is set
        set_global_app(None)

        import asyncio

        async def test_publish() -> None:
            with self.assertRaises(RuntimeError) as context:
                await publish_stream()
            self.assertIn("app.finalize()", str(context.exception))

        asyncio.run(test_publish())

    def test_stream_publisher_wrapper_raises_if_no_connect_router(self) -> None:
        """Stream publisher wrapper raises RuntimeError if app has no connect_router."""

        @stream(name="test_stream", payload=StreamPayload)
        async def publish_stream() -> StreamPayload:
            return StreamPayload(value=42)

        # Create mock app without connect_router
        mock_app = MagicMock()
        mock_app.connect_router = None
        set_global_app(mock_app)

        import asyncio

        async def test_publish() -> None:
            with self.assertRaises(RuntimeError) as context:
                await publish_stream()
            self.assertIn("app.finalize()", str(context.exception))

        asyncio.run(test_publish())
