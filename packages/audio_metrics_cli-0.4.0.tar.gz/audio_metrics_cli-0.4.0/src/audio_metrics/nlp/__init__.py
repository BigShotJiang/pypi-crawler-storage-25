"""
NLP Module
==========
Natural language processing modules.

Classes:
    SummaryGenerator: Generate summaries from transcripts
    KeywordExtractor: Extract keywords and topics
"""

from .summary_generator import SummaryGenerator
from .keyword_extractor import KeywordExtractor

__all__ = [
    "SummaryGenerator",
    "KeywordExtractor",
]