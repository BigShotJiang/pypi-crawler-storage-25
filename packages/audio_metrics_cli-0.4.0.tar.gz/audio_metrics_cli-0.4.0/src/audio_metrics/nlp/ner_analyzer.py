"""
NER Analyzer Module
Named Entity Recognition using spaCy.
Extracts commercial entities, person names, locations, and more.
"""

from typing import List, Optional, Dict, Any, Tuple

from audio_metrics.core.logger import get_logger
from audio_metrics.v4.schemas import NEREntity, NERResult

logger = get_logger(__name__)


# Commercial entity patterns (regex fallback when spaCy unavailable)
_COMMERCIAL_PATTERNS = [
    # Chinese company suffixes
    r"[A-Za-z\u4e00-\u9fff]{2,15}(公司|集团|企业|有限公司|股份|控股|地产|商业|科技|银行)",
    r"(万象城|Aibee|中海地产|保利|SKP|万达|华润|腾讯|阿里|字节|百度|华为|小米)",
    # Chinese business entity names
    r"[A-Za-z\u4e00-\u9fff]{2,8}(店|馆|厅|院|中心|市场|商场)",
]

try:
    import re
    import spacy
    HAS_SPACY = True
except ImportError:
    HAS_SPACY = False


class NERAnalyzer:
    """Named Entity Recognition analyzer using spaCy."""

    def __init__(self, language: str = "xx"):
        """
        Args:
            language: Language code ('en', 'zh', or 'xx' for auto).
        """
        self.language = language
        self._nlp = None
        self._model_name = self._resolve_model_name(language)
        self._available = HAS_SPACY

    def _resolve_model_name(self, language: str) -> str:
        """Resolve the spaCy model name for the given language."""
        model_map = {
            "en": "en_core_web_sm",
            "zh": "zh_core_web_sm",
            "xx": "xx_ent_wf_sm",
        }
        return model_map.get(language, "xx_ent_wf_sm")

    def load_model(self) -> bool:
        """
        Load the spaCy NER model.

        Returns:
            True if model loaded successfully.
        """
        if not self._available:
            logger.warning("spaCy not installed, NER will use regex fallback")
            return False

        try:
            self._nlp = spacy.load(self._model_name)
            logger.info(f"Loaded spaCy NER model: {self._model_name}")
            return True
        except OSError:
            logger.warning(
                f"spaCy model '{self._model_name}' not found. "
                "Run: python -m spacy download {model_name}"
            )
            self._available = False
            return False

    def extract(
        self,
        text: str,
        language: Optional[str] = None
    ) -> List[NEREntity]:
        """
        Extract named entities from text.

        Args:
            text: Input text.
            language: Override language (uses instance language if None).

        Returns:
            List of NEREntity objects.
        """
        if not text or len(text.strip()) < 5:
            return []

        lang = language or self.language

        # Try spaCy first
        if self._available and self._nlp is not None:
            return self._extract_spacy(text)
        elif self._available:
            if self.load_model():
                return self._extract_spacy(text)

        # Fallback to regex-based entity extraction
        return self._extract_regex(text)

    def _extract_spacy(self, text: str) -> List[NEREntity]:
        """Extract entities using spaCy."""
        entities = []
        doc = self._nlp(text[:100000])  # Limit text length for performance

        for ent in doc.ents:
            # Map spaCy labels to our schema
            label = self._map_label(ent.label_)
            if label:
                entities.append(NEREntity(
                    text=ent.text,
                    label=label,
                    start_char=ent.start_char,
                    end_char=ent.end_char,
                ))

        return entities

    def _extract_regex(self, text: str) -> List[NEREntity]:
        """Extract entities using regex patterns as fallback."""
        entities = []
        import re

        for pattern in _COMMERCIAL_PATTERNS:
            for match in re.finditer(pattern, text):
                # Avoid duplicates
                if not any(
                    e.start_char <= match.start() < e.end_char
                    for e in entities
                ):
                    entities.append(NEREntity(
                        text=match.group(),
                        label="COMMERCIAL_ENTITY",
                        start_char=match.start(),
                        end_char=match.end(),
                    ))

        return entities

    def _map_label(self, spacy_label: str) -> Optional[str]:
        """Map spaCy labels to our schema labels."""
        label_map = {
            "PERSON": "PERSON",
            "ORG": "ORGANIZATION",
            "GPE": "LOCATION",
            "LOC": "LOCATION",
            "PRODUCT": "PRODUCT",
            "EVENT": "EVENT",
            "WORK_OF_ART": "PRODUCT",
            "PRODUCT": "PRODUCT",
            "MONEY": "MONEY",
            "DATE": "DATE",
            "TIME": "TIME",
            "ORDINAL": "ORDINAL",
            "CARDINAL": "CARDINAL",
        }
        return label_map.get(spacy_label)

    def aggregate(self, entities: List[NEREntity]) -> NERResult:
        """
        Aggregate extracted entities into structured result.

        Args:
            entities: List of extracted NEREntity objects.

        Returns:
            NERResult with categorized entity lists.
        """
        persons = []
        organizations = []
        locations = []
        products = []
        commercial_entities = []
        entities_by_type: Dict[str, int] = {}

        for entity in entities:
            label = entity.label
            entities_by_type[label] = entities_by_type.get(label, 0) + 1

            if label == "PERSON":
                if entity.text not in persons:
                    persons.append(entity.text)
            elif label == "ORGANIZATION":
                if entity.text not in organizations:
                    organizations.append(entity.text)
            elif label == "LOCATION":
                if entity.text not in locations:
                    locations.append(entity.text)
            elif label == "PRODUCT":
                if entity.text not in products:
                    products.append(entity.text)
            elif label == "COMMERCIAL_ENTITY":
                if entity.text not in commercial_entities:
                    commercial_entities.append(entity.text)

        return NERResult(
            total_entities=len(entities),
            entities_by_type=entities_by_type,
            persons=persons,
            organizations=organizations,
            locations=locations,
            products=products,
            commercial_entities=commercial_entities,
            all_entities=entities,
        )


def extract_entities_from_segments(
    segments: List[Dict[str, Any]],
    analyzer: Optional[NERAnalyzer] = None
) -> NERResult:
    """
    Extract named entities from a list of transcript segments.

    Args:
        segments: List of segment dicts with 'text' and optional 'speaker' fields.
        analyzer: NERAnalyzer instance (creates one if None).

    Returns:
        NERResult with all extracted entities.
    """
    if analyzer is None:
        analyzer = NERAnalyzer(language="zh")

    all_entities: List[NEREntity] = []

    for seg in segments:
        text = seg.get("text", "")
        speaker = seg.get("speaker")
        if not text:
            continue

        # Detect language
        lang = seg.get("language", "zh")
        entities = analyzer.extract(text, language=lang)

        # Tag with speaker
        for ent in entities:
            if speaker:
                ent.speaker = speaker

        all_entities.extend(entities)

    return analyzer.aggregate(all_entities)