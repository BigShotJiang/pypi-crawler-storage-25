"""
Sentiment Analyzer Module
Sentiment scoring using TextBlob (English) and snownlp (Chinese).
"""

from typing import Dict, Any

from audio_metrics.core.logger import get_logger

logger = get_logger(__name__)

try:
    from textblob import TextBlob
    HAS_TEXTBLOB = True
except ImportError:
    HAS_TEXTBLOB = False

try:
    from snownlp import SnowNLP
    HAS_SNOWNLP = True
except ImportError:
    HAS_SNOWNLP = False


# Chinese action item patterns for key point detection
_ACTION_PATTERNS = [
    "需要", "要", "必须", "记得", "别忘了", "赶紧", "尽快",
    "安排", "落实", "执行", "跟进", "处理", "解决",
    "todo", "计划", "目标", "deadline", "截止",
]

# Key point indicator keywords
_KEY_POINT_KEYWORDS = [
    "重要", "关键", "核心", "主要", "结论", "总结",
    "建议", "决定", "方案", "策略", "计划", "目标",
    "问题", "挑战", "风险", "机会", "改进",
    "IMPORTANT", "KEY", "CONCLUSION", "RECOMMEND",
    "DECISION", "ACTION", "TODO", "SUMMARY",
]


def _is_chinese(text: str) -> bool:
    """Check if text contains significant Chinese characters."""
    chinese_count = sum(1 for c in text if '\u4e00' <= c <= '\u9fff')
    return chinese_count / max(len(text), 1) > 0.3


def _sentiment_score_textblob(text: str) -> float:
    """Score sentiment using TextBlob. Returns -1 to 1."""
    if not HAS_TEXTBLOB:
        return 0.0
    try:
        blob = TextBlob(text[:5000])  # Limit for performance
        return round(blob.sentiment.polarity, 3)
    except Exception as e:
        logger.debug(f"TextBlob sentiment failed: {e}")
        return 0.0


def _sentiment_score_snownlp(text: str) -> float:
    """Score sentiment using snownlp. Returns -1 to 1."""
    if not HAS_SNOWNLP:
        return 0.0
    try:
        s = SnowNLP(text[:5000])
        # snownlp returns 0-1, where 0.5 is neutral
        score = s.sentiments
        # Convert to -1 to 1 range: (score - 0.5) * 2
        return round((score - 0.5) * 2, 3)
    except Exception as e:
        logger.debug(f"Snownlp sentiment failed: {e}")
        return 0.0


class SentimentAnalyzer:
    """Sentiment analysis for transcribed text."""

    def score(self, text: str) -> float:
        """
        Score the sentiment of text. Returns a float in [-1, 1].

        Args:
            text: Input text.

        Returns:
            Sentiment score: -1 (very negative) to 1 (very positive).
        """
        if not text or len(text.strip()) < 3:
            return 0.0

        # Detect language and use appropriate analyzer
        if _is_chinese(text) and HAS_SNOWNLP:
            return _sentiment_score_snownlp(text)
        elif HAS_TEXTBLOB:
            return _sentiment_score_textblob(text)
        elif HAS_SNOWNLP:
            return _sentiment_score_snownlp(text)
        else:
            logger.warning("No sentiment library available, returning 0.0")
            return 0.0

    def score_segments(
        self,
        segments: list[Dict[str, Any]]
    ) -> list[float]:
        """
        Score sentiment for a list of segments.

        Args:
            segments: List of segment dicts with 'text' field.

        Returns:
            List of sentiment scores (same length as input).
        """
        return [self.score(seg.get("text", "")) for seg in segments]


class KeyPointDetector:
    """Detects key points in transcript segments."""

    def __init__(self, action_patterns: list[str] = None):
        self.action_patterns = action_patterns or _ACTION_PATTERNS
        self.key_point_keywords = _KEY_POINT_KEYWORDS

    def detect(
        self,
        segments: list[Dict[str, Any]],
        sentiment_scores: list[float] = None
    ) -> list[int]:
        """
        Detect key point segment indices.

        Args:
            segments: List of segment dicts with 'text' field.
            sentiment_scores: Pre-computed sentiment scores (optional).

        Returns:
            List of segment indices that are key points.
        """
        if not segments:
            return []

        scores = sentiment_scores or [SentimentAnalyzer().score(s.get("text", ""))
                                       for s in segments]

        # Calculate statistics for thresholding
        text_lengths = [len(s.get("text", "")) for s in segments]
        if not text_lengths:
            return []

        avg_len = sum(text_lengths) / len(text_lengths)
        std_len = (sum((l - avg_len) ** 2 for l in text_lengths) / len(text_lengths)) ** 0.5

        key_point_indices = []

        for i, seg in enumerate(segments):
            text = seg.get("text", "")
            score = scores[i] if i < len(scores) else 0.0

            is_key_point = False

            # Criterion 1: Long text (above average + 1.5 * std)
            if len(text) > avg_len + 1.5 * std_len:
                is_key_point = True

            # Criterion 2: Contains action items
            for pattern in self.action_patterns:
                if pattern.lower() in text.lower():
                    is_key_point = True
                    break

            # Criterion 3: Contains key point keywords
            for kw in self.key_point_keywords:
                if kw.lower() in text.lower():
                    is_key_point = True
                    break

            # Criterion 4: High sentiment extremity (confidence)
            if abs(score) > 0.7:
                is_key_point = True

            if is_key_point:
                key_point_indices.append(i)

        return key_point_indices