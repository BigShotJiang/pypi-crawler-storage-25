"""
Topic Segmentation Module
Segments long audio into semantic topic chapters using keyword overlap.
"""

from typing import List, Dict, Any, Optional

from audio_metrics.core.logger import get_logger

logger = get_logger(__name__)


# Topic keyword groups for labeling
_TOPIC_LABELS = {
    "introduction": ["介绍", "自我介绍", "大家好", "今天", "首先", "欢迎", "hello", "hi"],
    "project_update": ["项目", "进展", "进度", "开发", "代码", "计划", "规划", "project", "sprint"],
    "business_discussion": ["客户", "市场", "销售", "合作", "签约", "合同", "订单", "business", "deal"],
    "technical": ["技术", "架构", "系统", "服务器", "性能", "测试", "部署", "tech", "infrastructure"],
    "team": ["团队", "成员", "同事", "招聘", "会议", "schedule", "team", "meeting", "agenda"],
    "reporting": ["报告", "总结", "数据", "指标", "增长", "收入", "报告", "分析", "report", "metrics"],
    "planning": ["计划", "目标", "策略", "预算", "季度", "年度", "plan", "strategy", "budget"],
    "q_and_a": ["问题", "提问", "回答", "讨论", "反馈", "question", "answer", "feedback"],
    "closing": ["谢谢", "再见", "结束", "感谢", "thanking", "goodbye", "bye"],
}


def _extract_keywords(text: str, top_n: int = 10) -> set[str]:
    """
    Extract simple keywords from text (character n-gram based).
    For Chinese: extracts 2-4 character sequences.
    For English: extracts words > 2 chars.

    Args:
        text: Input text.
        top_n: Number of top keywords to return.

    Returns:
        Set of keyword strings.
    """
    import re

    # Normalize
    text = text.lower().strip()

    # Chinese character n-grams (2-4 chars)
    chinese_ngrams = set()
    chinese_chars = [c for c in text if '\u4e00' <= c <= '\u9fff']
    for n in [2, 3, 4]:
        for i in range(len(chinese_chars) - n + 1):
            ngram = "".join(chinese_chars[i:i+n])
            # Filter common stop ngrams
            if ngram not in ("的", "了", "是", "在", "和", "有", "我", "你", "他", "她", "它",
                              "我们", "你们", "他们", "这个", "那个", "什么", "一个"):
                chinese_ngrams.add(ngram)

    # English words
    english_words = set()
    for word in re.findall(r'[a-z]{3,}', text):
        # Filter stop words
        if word not in {"the", "and", "for", "are", "but", "not", "you", "all", "can",
                         "have", "had", "was", "what", "when", "where", "which", "this",
                         "that", "with", "from", "they", "been", "will", "their", "would",
                         "there", "could", "other", "more", "also", "than", "then"}:
            english_words.add(word)

    all_keywords = chinese_ngrams | english_words
    return all_keywords


def _jaccard_similarity(set_a: set, set_b: set) -> float:
    """Compute Jaccard similarity between two sets."""
    if not set_a or not set_b:
        return 0.0
    intersection = len(set_a & set_b)
    union = len(set_a | set_b)
    return intersection / union if union > 0 else 0.0


def _label_topic(keywords: set[str]) -> str:
    """Label a topic based on its keywords."""
    for label, label_keywords in _TOPIC_LABELS.items():
        matches = sum(1 for kw in label_keywords if kw in keywords)
        if matches >= 2:
            return label

    # Check individual keyword matches
    for label, label_keywords in _TOPIC_LABELS.items():
        for kw in label_keywords:
            if any(kw in k for k in keywords):
                return label

    return "general_discussion"


class TopicSegmenter:
    """Semantic topic segmentation for transcripts."""

    def __init__(
        self,
        similarity_threshold: float = 0.3,
        min_segment_duration: float = 30.0
    ):
        """
        Args:
            similarity_threshold: Jaccard threshold below which a new topic starts.
            min_segment_duration: Minimum segment duration in seconds.
        """
        self.similarity_threshold = similarity_threshold
        self.min_segment_duration = min_segment_duration

    def segment(
        self,
        transcript_text: str,
        segments: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """
        Segment transcript into topic chapters.

        Args:
            transcript_text: Full transcript text (optional).
            segments: List of segment dicts with start/end/text fields.

        Returns:
            List of topic segment dicts with start, end, topic_label, keywords.
        """
        if not segments:
            return []

        # Group segments into windows of ~30s
        window_size = max(1, self.min_segment_duration)
        topic_segments = []
        current_topic_segments = []
        current_keywords = set()
        current_start = None

        for seg in segments:
            text = seg.get("text", "")
            start = seg.get("start", 0)
            end = seg.get("end", start)

            if not text.strip():
                continue

            seg_keywords = _extract_keywords(text, top_n=10)
            seg_duration = end - start

            if current_start is None:
                current_start = start

            # Check similarity with current topic
            similarity = _jaccard_similarity(seg_keywords, current_keywords)

            should_switch = (
                similarity < self.similarity_threshold and
                seg_duration > 5.0  # Only switch on substantive segments
            )

            if should_switch and current_topic_segments:
                # Finalize current topic
                topic_end = current_topic_segments[-1].get("end", end)
                topic_keywords = _extract_keywords(
                    " ".join(s.get("text", "") for s in current_topic_segments),
                    top_n=15
                )

                topic_segments.append({
                    "start": round(current_start, 3),
                    "end": round(topic_end, 3),
                    "topic_label": _label_topic(topic_keywords),
                    "keywords": list(topic_keywords)[:10],
                    "confidence": round(min(similarity + 0.3, 0.9), 2),
                })

                current_topic_segments = []
                current_keywords = set()
                current_start = start

            current_topic_segments.append(seg)
            current_keywords |= seg_keywords

        # Don't forget the last topic
        if current_topic_segments:
            topic_end = current_topic_segments[-1].get("end", 0)
            topic_keywords = _extract_keywords(
                " ".join(s.get("text", "") for s in current_topic_segments),
                top_n=15
            )

            topic_segments.append({
                "start": round(current_start, 3),
                "end": round(topic_end, 3),
                "topic_label": _label_topic(topic_keywords),
                "keywords": list(topic_keywords)[:10],
                "confidence": 0.5,
            })

        logger.info(
            "Topic segmentation complete",
            num_topics=len(topic_segments)
        )

        return topic_segments