"""
Audio Health Check Module
Validates and normalizes audio to standard 16kHz mono format before processing.
"""

import os
import subprocess
import tempfile
from pathlib import Path
from typing import Dict, Any, Optional, Tuple

import numpy as np

from audio_metrics.core.logger import get_logger

logger = get_logger(__name__)

# Standard format constants
STANDARD_SAMPLE_RATE = 16000
STANDARD_CHANNELS = 1  # mono


class AudioHealthCheck:
    """Validates and normalizes audio files to processing-ready format."""

    def __init__(self, target_sample_rate: int = STANDARD_SAMPLE_RATE):
        """
        Args:
            target_sample_rate: Target sample rate for normalization.
        """
        self.target_sample_rate = target_sample_rate
        self._warnings = []

    def check_and_normalize(
        self,
        audio_data: np.ndarray,
        sample_rate: int
    ) -> Tuple[np.ndarray, int, Dict[str, Any]]:
        """
        Check audio health and normalize to standard format.

        Args:
            audio_data: Raw audio data array.
            sample_rate: Original sample rate.

        Returns:
            Tuple of (normalized_audio, sample_rate, health_report)
        """
        health_report = {
            "original_sample_rate": sample_rate,
            "original_channels": self._get_channels(audio_data),
            "original_duration_s": round(len(audio_data) / sample_rate, 2),
            "normalized": False,
            "resampled": False,
            "converted_to_mono": False,
            "warnings": [],
        }

        audio_normalized = audio_data
        current_sr = sample_rate
        normalized = False

        # Step 1: Convert stereo to mono
        if self._get_channels(audio_data) > 1:
            audio_normalized = np.mean(audio_data, axis=1).astype(audio_data.dtype)
            health_report["converted_to_mono"] = True
            health_report["warnings"].append(
                "Audio was stereo, converted to mono for processing"
            )
            logger.info("Converted stereo audio to mono")
            normalized = True

        # Step 2: Resample to target rate if needed
        if current_sr != self.target_sample_rate:
            audio_normalized, current_sr = self._resample(
                audio_normalized, current_sr, self.target_sample_rate
            )
            health_report["resampled"] = True
            health_report["warnings"].append(
                f"Resampled from {sample_rate}Hz to {self.target_sample_rate}Hz"
            )
            logger.info(
                "Resampled audio",
                from_sr=sample_rate,
                to_sr=self.target_sample_rate
            )
            normalized = True

        # Step 3: Ensure float32
        if audio_normalized.dtype != np.float32:
            audio_normalized = audio_normalized.astype(np.float32)
            health_report["dtype_converted"] = True

        # Step 4: Normalize amplitude to [-1, 1]
        audio_max = np.abs(audio_normalized).max()
        if audio_max > 1.5:  # Likely 16-bit integer range
            audio_normalized = audio_normalized / 32768.0
            health_report["amplitude_normalized"] = True
        elif audio_max > 0 and audio_max < 0.001:
            # Very quiet - don't amplify noise floor
            pass
        elif audio_max > 1.0:
            audio_normalized = audio_normalized / audio_max
            health_report["amplitude_normalized"] = True

        health_report["normalized"] = normalized
        health_report["final_sample_rate"] = current_sr
        health_report["final_channels"] = 1

        return audio_normalized, current_sr, health_report

    def _get_channels(self, audio_data: np.ndarray) -> int:
        """Get number of channels from audio array."""
        if len(audio_data.shape) == 1:
            return 1
        return audio_data.shape[1] if len(audio_data.shape) > 1 else 1

    def _resample(
        self,
        audio_data: np.ndarray,
        from_sr: int,
        to_sr: int
    ) -> Tuple[np.ndarray, int]:
        """Resample audio using librosa or ffmpeg as fallback."""
        try:
            import librosa
            audio_resampled = librosa.resample(
                audio_data.astype(np.float32),
                orig_sr=from_sr,
                target_sr=to_sr
            )
            return audio_resampled, to_sr
        except ImportError:
            # Fallback to ffmpeg for resampling
            return self._resample_ffmpeg(audio_data, from_sr, to_sr)

    def _resample_ffmpeg(
        self,
        audio_data: np.ndarray,
        from_sr: int,
        to_sr: int
    ) -> Tuple[np.ndarray, int]:
        """Fallback resampling using ffmpeg via subprocess."""
        import soundfile as sf

        try:
            # Write temp file
            with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp_in:
                sf.write(tmp_in.name, audio_data, from_sr)
                tmp_in_path = tmp_in.name

            tmp_out_path = tmp_in_path + ".resampled.wav"

            # Run ffmpeg
            result = subprocess.run(
                [
                    "ffmpeg", "-y", "-i", tmp_in_path,
                    "-ar", str(to_sr), "-ac", "1",
                    tmp_out_path
                ],
                capture_output=True,
                text=True,
                timeout=60
            )

            if result.returncode == 0:
                audio_resampled, sr = sf.read(tmp_out_path)
                os.unlink(tmp_in_path)
                os.unlink(tmp_out_path)
                return audio_resampled.astype(np.float32), to_sr
            else:
                logger.warning("ffmpeg resample failed", error=result.stderr)
                os.unlink(tmp_in_path)
                return audio_data, from_sr
        except FileNotFoundError:
            logger.warning("ffmpeg not found, cannot resample")
            return audio_data, from_sr
        except Exception as e:
            logger.warning(f"Resample failed: {e}")
            return audio_data, from_sr

    def validate_duration(self, duration_s: float, max_duration: int = 3600) -> bool:
        """
        Validate audio duration is within acceptable range.

        Args:
            duration_s: Audio duration in seconds.
            max_duration: Maximum allowed duration in seconds.

        Returns:
            True if valid.

        Raises:
            ValueError: If duration is invalid.
        """
        if duration_s < 0.1:
            raise ValueError(
                f"Audio too short: {duration_s:.1f}s. Minimum is 0.1s."
            )
        if duration_s > max_duration:
            raise ValueError(
                f"Audio too long: {duration_s:.1f}s. Maximum is {max_duration}s."
            )
        return True

    def get_report(self) -> Dict[str, Any]:
        """Get the last health check report."""
        return self._warnings