"""
Fluency Analyzer Module
Analyzes speech fluency: filler words and unnatural pauses.
Reuses and extends the existing FillerDetector.
"""

from typing import List, Dict, Any, Optional

from audio_metrics.core.logger import get_logger

logger = get_logger(__name__)


# Default filler word patterns
CHINESE_FILLERS = [
    "呃", "嗯", "啊", "那个", "然后", "就是", "这个", "其实",
    "可能", "大概", "好像", "也许", "怎么说", "你知道", "我的意思是",
    "反正", "话说话", "这什么", "嗯嗯", "啊这",
]

ENGLISH_FILLERS = [
    "um", "uh", "ah", "er", "like", "you know", "sort of", "kind of",
    "basically", "actually", "literally", "i mean", "well", "right",
    "okay", "so", "yeah",
]


class FluencyAnalyzer:
    """Analyzes speech fluency including fillers and unnatural pauses."""

    def __init__(
        self,
        chinese_fillers: List[str] = None,
        english_fillers: List[str] = None,
        unnatural_pause_threshold: float = 2.0
    ):
        """
        Args:
            chinese_fillers: List of Chinese filler words.
            english_fillers: List of English filler words.
            unnatural_pause_threshold: Seconds beyond which a pause is "unnatural".
        """
        self.chinese_fillers = chinese_fillers or CHINESE_FILLERS
        self.english_fillers = english_fillers or ENGLISH_FILLERS
        self.pause_threshold = unnatural_pause_threshold

    def analyze(
        self,
        segments: List[Dict[str, Any]],
        transcript_text: str = ""
    ) -> Dict[str, Any]:
        """
        Analyze fluency from transcript segments.

        Args:
            segments: List of segment dicts with text, start, end, speaker.
            transcript_text: Full transcript text.

        Returns:
            FluencyMetrics-compatible dict.
        """
        filler_by_type: Dict[str, int] = {}
        filler_by_speaker: Dict[str, Dict[str, int]] = {}
        total_filler_count = 0
        total_words = 0

        # Process each segment for filler words
        for seg in segments:
            text = seg.get("text", "")
            speaker = seg.get("speaker", "unknown")
            if not text:
                continue

            words = text.split()
            total_words += len(words)

            # Count fillers by type
            seg_filler_counts: Dict[str, int] = {}
            text_lower = text.lower()

            for filler in self.chinese_fillers:
                # Chinese filler detection (character matching)
                count = text.count(filler)
                if count > 0:
                    seg_filler_counts[filler] = count
                    filler_by_type[filler] = filler_by_type.get(filler, 0) + count

            for filler in self.english_fillers:
                # English filler detection (word boundary)
                import re
                pattern = r'\b' + re.escape(filler) + r'\b'
                count = len(re.findall(pattern, text_lower, re.IGNORECASE))
                if count > 0:
                    seg_filler_counts[filler] = count
                    filler_by_type[filler] = filler_by_type.get(filler, 0) + count

            total_filler_count += sum(seg_filler_counts.values())

            # Per-speaker breakdown
            if speaker not in filler_by_speaker:
                filler_by_speaker[speaker] = {}
            for filler, count in seg_filler_counts.items():
                filler_by_speaker[speaker][filler] = (
                    filler_by_speaker[speaker].get(filler, 0) + count
                )

        # Detect unnatural pauses
        unnatural_pauses = self._detect_unnatural_pauses(segments)

        # Compute ratios
        filler_ratio = total_filler_count / max(total_words, 1)
        fillers_per_100_words = (total_filler_count / max(total_words, 1)) * 100

        return {
            "total_filler_count": total_filler_count,
            "filler_ratio": round(filler_ratio, 4),
            "fillers_per_100_words": round(fillers_per_100_words, 1),
            "filler_by_type": filler_by_type,
            "filler_by_speaker": filler_by_speaker,
            "unnatural_pause_count": len(unnatural_pauses),
            "unnatural_pause_total_duration_s": round(
                sum(p["duration"] for p in unnatural_pauses), 2
            ),
            "unnatural_pause_positions": [
                {"start": p["start"], "end": p["end"], "duration": p["duration"]}
                for p in unnatural_pauses
            ],
        }

    def _detect_unnatural_pauses(self, segments: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Detect unnatural pauses in speech.

        A pause is "unnatural" if:
        - It exceeds pause_threshold seconds
        - It's within a single speaker's turn (no speaker change)
        - It's not at a natural punctuation boundary

        Args:
            segments: List of segment dicts with start, end, speaker.

        Returns:
            List of unnatural pause dicts.
        """
        if len(segments) < 2:
            return []

        unnatural = []

        for i in range(1, len(segments)):
            prev = segments[i - 1]
            curr = segments[i]

            # Only detect within same speaker
            if prev.get("speaker") != curr.get("speaker"):
                continue

            gap = curr.get("start", 0) - prev.get("end", 0)

            if gap > self.pause_threshold:
                # Check if this is a natural break (surrounded by punctuation)
                prev_text = prev.get("text", "")
                curr_text = curr.get("text", "")

                natural_break = (
                    prev_text.rstrip().endswith(('。', '！', '？', '，', '.', '!', '?')) or
                    curr_text.lstrip().startswith(('好', '那么', '那', '所以', '而且', '然后'))
                )

                if not natural_break:
                    unnatural.append({
                        "start": prev.get("end", 0),
                        "end": curr.get("start", 0),
                        "duration": round(gap, 3),
                    })

        return unnatural