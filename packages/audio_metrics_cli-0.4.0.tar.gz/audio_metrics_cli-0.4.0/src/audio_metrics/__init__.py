"""
Audio Metrics CLI - Cross-platform audio analysis toolkit

Extract objective speech metrics from audio files.
Supports both single-speaker and multi-speaker conversation analysis.
Output structured JSON for further analysis.
"""

__version__ = "0.4.0"
__author__ = "OpenClaw"
__email__ = "clawbot@openclaw.ai"

from .cli import main

# Analyzers - audio processing modules
from .analyzers import (
    AudioLoader,
    VADAnalyzer,
    SpeechToText,
    ProsodyAnalyzer,
    EmotionAnalyzer,
    FillerDetector,
    SpeakerDiarization,
)

# Metrics - metrics extraction and aggregation
from .metrics import (
    SegmentMetricsExtractor,
    SpeakerMetricsAggregator,
    MetricsBuilder,
    JSONExporter,
)

# Conversation - conversation analysis
from .conversation import (
    TimelineBuilder,
    TimingRelationAnalyzer,
    ConversationDynamicsAnalyzer,
)

# NLP - natural language processing
from .nlp import (
    SummaryGenerator,
    KeywordExtractor,
)

# Pipeline - analysis orchestration
from .pipeline import AnalysisPipeline

# Exporters
from .exporters import EnhancedJSONExporter

__all__ = [
    "main",
    # Analyzers
    "AudioLoader",
    "VADAnalyzer",
    "SpeechToText",
    "ProsodyAnalyzer",
    "EmotionAnalyzer",
    "FillerDetector",
    "SpeakerDiarization",
    # Metrics
    "SegmentMetricsExtractor",
    "SpeakerMetricsAggregator",
    "MetricsBuilder",
    "JSONExporter",
    # Conversation
    "TimelineBuilder",
    "TimingRelationAnalyzer",
    "ConversationDynamicsAnalyzer",
    # NLP
    "SummaryGenerator",
    "KeywordExtractor",
    # Pipeline
    "AnalysisPipeline",
    # Exporters
    "EnhancedJSONExporter",
]