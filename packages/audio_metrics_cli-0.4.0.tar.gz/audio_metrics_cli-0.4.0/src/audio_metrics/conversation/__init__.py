"""
Conversation Module
===================
Conversation analysis and dynamics modules.

Classes:
    TimelineBuilder: Build conversation timeline from diarization
    TimingRelationAnalyzer: Analyze timing relations between speakers
    ConversationDynamicsAnalyzer: Analyze conversation dynamics
"""

from .timeline_builder import TimelineBuilder
from .timing_relation import TimingRelationAnalyzer
from .conversation_dynamics import ConversationDynamicsAnalyzer

__all__ = [
    "TimelineBuilder",
    "TimingRelationAnalyzer",
    "ConversationDynamicsAnalyzer",
]