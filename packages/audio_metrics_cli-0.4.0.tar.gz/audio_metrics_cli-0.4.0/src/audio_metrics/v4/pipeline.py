"""
V4 Analysis Pipeline
Industrial-grade speech analysis orchestrator.
Coordinates all V4 components with GPU detection, chunking, and schema validation.
"""

from __future__ import annotations

import time
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, Any, List

import numpy as np
from tqdm import tqdm

from audio_metrics.core.logger import get_logger
from audio_metrics.core.device import get_optimal_device, DeviceManager, get_cuda_info
from audio_metrics.core.chunker import (
    chunk_audio,
    merge_vad_results,
    merge_diarization_results,
    merge_transcript_chunks,
    DEFAULT_CHUNK_SIZE_SEC,
    DEFAULT_CHUNK_THRESHOLD_SEC,
)
from audio_metrics.core.warnings import suppress_warnings

from audio_metrics.analyzers.audio_loader import AudioLoader
from audio_metrics.analyzers.audio_health import AudioHealthCheck
from audio_metrics.analyzers.vad_analyzer import VADAnalyzer
from audio_metrics.analyzers.speaker_diarization import SpeakerDiarization
from audio_metrics.analyzers.speech_to_text import SpeechToText
from audio_metrics.analyzers.prosody_analyzer import ProsodyAnalyzer
from audio_metrics.analyzers.fluency_analyzer import FluencyAnalyzer
from audio_metrics.analyzers.filler_detector import FillerDetector

from audio_metrics.nlp.ner_analyzer import NERAnalyzer, extract_entities_from_segments
from audio_metrics.nlp.topic_segmenter import TopicSegmenter
from audio_metrics.nlp.sentiment_analyzer import SentimentAnalyzer, KeyPointDetector
from audio_metrics.nlp.keyword_extractor import KeywordExtractor

from audio_metrics.conversation.timeline_builder import TimelineBuilder
from audio_metrics.conversation.conversation_dynamics import ConversationDynamicsAnalyzer
from audio_metrics.conversation.timing_relation import TimingRelationAnalyzer

from audio_metrics.metrics.segment_metrics import SegmentMetricsExtractor

from audio_metrics.v4.schemas import (
    V4Result,
    MetaSection,
    AudioInfo,
    SpeakerModel,
    SegmentModel,
    ProsodyMetrics,
    FluencyMetrics,
    ConversationDynamics,
    VADMetrics,
    EmotionMetrics,
    NERResult,
    TopicSegment,
    TopicSegmentation,
)

logger = get_logger(__name__)


class V4AnalysisPipeline:
    """
    Industrial-grade V4 audio analysis pipeline.

    Features:
    - Automatic GPU/CPU detection and device management
    - Audio health validation and normalization
    - Chunked processing for 1h+ audio files
    - Word-level timestamp alignment (replaces seg_duration*5 estimation)
    - Full V4 feature extraction: prosody, fluency, NER, sentiment, topics
    - Pydantic schema validation on all outputs
    """

    def __init__(
        self,
        device: str = "auto",
        chunk_size_sec: int = DEFAULT_CHUNK_SIZE_SEC,
        chunk_threshold_sec: int = DEFAULT_CHUNK_THRESHOLD_SEC,
        show_progress: bool = True,
        model_name: str = "base",
        whisper_model: str = "base",
    ):
        """
        Initialize V4 analysis pipeline.

        Args:
            device: Device to use ('cuda', 'cpu', 'auto'). Auto detects GPU.
            chunk_size_sec: Size of processing chunks for long audio.
            chunk_threshold_sec: Duration threshold for enabling chunking.
            show_progress: Show tqdm progress bars.
            model_name: Whisper model size (tiny, base, small, medium, large).
        """
        self.device = get_optimal_device(device)
        self.chunk_size_sec = chunk_size_sec
        self.chunk_threshold_sec = chunk_threshold_sec
        self.show_progress = show_progress
        self.whisper_model = model_name

        self.step_timings: Dict[str, float] = {}
        self._result: Optional[V4Result] = None

        logger.info(
            "V4 pipeline initialized",
            device=self.device,
            chunk_size_sec=self.chunk_size_sec,
            whisper_model=self.whisper_model,
        )

    def run(
        self,
        audio_path: str,
        output_path: Optional[str] = None,
        num_speakers: Optional[int] = None,
        min_speakers: Optional[int] = None,
        max_speakers: Optional[int] = None,
        language: Optional[str] = None,
        enable_emotion: bool = False,
        enable_summary: bool = True,
    ) -> V4Result:
        """
        Run the full V4 analysis pipeline.

        Args:
            audio_path: Path to audio file.
            output_path: Path to save JSON output (optional).
            num_speakers: Exact number of speakers (if known).
            min_speakers: Minimum number of speakers.
            max_speakers: Maximum number of speakers.
            language: Language code (None = auto-detect).
            enable_emotion: Enable emotion analysis.
            enable_summary: Enable LLM summary generation.

        Returns:
            V4Result validated output.
        """
        t0 = time.time()
        audio_path = Path(audio_path)

        # ===== Step 0: Load and validate audio =====
        logger.info("Loading audio", path=str(audio_path))
        loader = AudioLoader(str(audio_path))
        loader.load()
        audio_info = loader.get_audio_info()
        audio_data = loader.get_audio_data()

        duration = audio_info["duration_seconds"]

        # ===== Step 1: Audio health check and normalization =====
        t1 = time.time()
        with suppress_warnings(["librosa", "numpy", "scipy"]):
            health = AudioHealthCheck()
            audio_data, sr, health_report = health.check_and_normalize(
                audio_data, audio_info["sample_rate"]
            )

        self.step_timings["audio_health"] = round(time.time() - t1, 2)
        logger.info(
            "Audio health check complete",
            normalized=health_report.get("normalized", False),
            resampled=health_report.get("resampled", False),
            duration_s=round(duration, 1),
        )

        # ===== Step 2: VAD analysis =====
        t2 = time.time()
        vad_analyzer = VADAnalyzer()
        if duration > self.chunk_threshold_sec:
            logger.info("Using chunked VAD processing", duration_s=duration)
            vad_result = self._vad_chunked(audio_data, sr)
        else:
            with suppress_warnings(["librosa", "numpy"]):
                vad_result = vad_analyzer.analyze(audio_data, sr)

        self.step_timings["vad"] = round(time.time() - t2, 2)

        # ===== Step 3: Speaker diarization =====
        t3 = time.time()
        diarizer = SpeakerDiarization(device=self.device)
        if duration > self.chunk_threshold_sec:
            diar_result = self._diar_chunked(str(audio_path), sr, num_speakers,
                                             min_speakers, max_speakers)
        else:
            diar_result = diarizer.diarize(
                str(audio_path),
                num_speakers=num_speakers,
                min_speakers=min_speakers,
                max_speakers=max_speakers,
            )
        self.step_timings["diarization"] = round(time.time() - t3, 2)

        # ===== Step 4: Speech-to-text (with word timestamps) =====
        t4 = time.time()
        stt = SpeechToText(model_name=self.whisper_model, device=self.device)
        stt.load_model()
        stt_result = stt.transcribe(
            str(audio_path),
            language=language,
            word_timestamps=True,
        )
        self.step_timings["stt"] = round(time.time() - t4, 2)

        # ===== Step 5: Build timeline =====
        t5 = time.time()
        timeline = TimelineBuilder()
        timeline.build(diar_result["segments"])
        timeline.add_transcript_to_timeline(
            stt_result["segments"],
            stt_result.get("words", []),
        )
        timeline_segments = [
            {
                "start": s.start,
                "end": s.end,
                "speaker": s.speakers[0] if s.speakers else "unknown",
                "text": s.text or "",
                "duration": s.duration,
            }
            for s in timeline.timeline
            if s.segment_type.value in ("speech", "overlap")
        ]
        self.step_timings["timeline"] = round(time.time() - t5, 2)

        # ===== Step 6: Segment metrics (prosody per segment) =====
        t6 = time.time()
        seg_metrics_extractor = SegmentMetricsExtractor()
        prosody_analyzer = ProsodyAnalyzer(sample_rate=sr)

        segment_prosody_list = []
        if self.show_progress:
            pbar = tqdm(total=len(timeline_segments), desc="Extracting segment prosody", unit="seg")

        for i, seg in enumerate(timeline_segments):
            start_s = int(seg["start"] * sr)
            end_s = int(seg["end"] * sr)
            seg_audio = audio_data[start_s:end_s]
            if len(seg_audio) < sr * 0.1:  # Skip very short segments
                segment_prosody_list.append({})
                if self.show_progress:
                    pbar.update(1)
                continue
            with suppress_warnings(["librosa", "numpy"]):
                prosody = prosody_analyzer.analyze(seg_audio)
            segment_prosody_list.append(prosody)
            if self.show_progress:
                pbar.update(1)

        if self.show_progress:
            pbar.close()

        self.step_timings["segment_prosody"] = round(time.time() - t6, 2)

        # ===== Step 7: Fluency analysis =====
        t7 = time.time()
        fluency = FluencyAnalyzer()
        fluency_result = fluency.analyze(timeline_segments, stt_result["text"])
        self.step_timings["fluency"] = round(time.time() - t7, 2)

        # ===== Step 8: NER extraction =====
        t8 = time.time()
        ner_analyzer = NERAnalyzer(language="zh")
        ner_result = extract_entities_from_segments(timeline_segments, ner_analyzer)
        self.step_timings["ner"] = round(time.time() - t8, 2)

        # ===== Step 9: Topic segmentation =====
        t9 = time.time()
        topic_segmenter = TopicSegmenter()
        topic_list = topic_segmenter.segment(stt_result["text"], timeline_segments)
        self.step_timings["topic_segmentation"] = round(time.time() - t9, 2)

        # ===== Step 10: Sentiment + key point detection =====
        t10 = time.time()
        sentiment_analyzer = SentimentAnalyzer()
        sentiment_scores = sentiment_analyzer.score_segments(timeline_segments)

        key_point_detector = KeyPointDetector()
        key_point_indices = key_point_detector.detect(timeline_segments, sentiment_scores)
        self.step_timings["sentiment"] = round(time.time() - t10, 2)

        # ===== Step 11: Conversation dynamics =====
        t11 = time.time()
        dynamics_analyzer = ConversationDynamicsAnalyzer()
        dynamics_result = dynamics_analyzer.analyze_dynamics(timeline_segments)

        timing_analyzer = TimingRelationAnalyzer()
        timing_result = timing_analyzer.analyze(timeline.timeline)
        self.step_timings["dynamics"] = round(time.time() - t11, 2)

        # ===== Step 12: Speaker profiles =====
        t12 = time.time()
        speaker_profiles = self._build_speaker_profiles(
            timeline_segments, segment_prosody_list, fluency_result, ner_result
        )
        self.step_timings["speaker_profiles"] = round(time.time() - t12, 2)

        # ===== Step 13: Global prosody =====
        t13 = time.time()
        with suppress_warnings(["librosa", "numpy"]):
            global_prosody = prosody_analyzer.analyze_full(audio_data)

        # Compute global speech rate
        words = stt_result["text"].split()
        wpm = (len(words) / duration * 60) if duration > 0 else 0
        global_prosody["avg_speech_rate_wpm"] = round(wpm, 1)
        self.step_timings["global_prosody"] = round(time.time() - t13, 2)

        # ===== Step 14: Build V4Result =====
        # Build segments with all annotations
        segments_v4 = []
        for i, seg in enumerate(timeline_segments):
            prosody = segment_prosody_list[i] if i < len(segment_prosody_list) else {}
            sentiment = sentiment_scores[i] if i < len(sentiment_scores) else 0.0

            # Compute speech rate for this segment
            text_len = len(seg.get("text", ""))
            seg_dur = seg.get("end", 0) - seg.get("start", 0)
            seg_wpm = (text_len / seg_dur * 60) if seg_dur > 0 else None

            segment_entities = [
                e.text for e in ner_result.all_entities
                if e.speaker == seg.get("speaker")
            ]

            # Topic assignment
            seg_topic = None
            for topic_seg in topic_list:
                if (topic_seg.get("start", 0) <= seg.get("start", 0) <
                        topic_seg.get("end", 0)):
                    seg_topic = topic_seg.get("topic_label")
                    break

            segments_v4.append(SegmentModel(
                segment_index=i,
                start=round(seg.get("start", 0), 3),
                end=round(seg.get("end", 0), 3),
                duration=round(seg_dur, 3),
                confidence=1.0,
                speaker=seg.get("speaker", "unknown"),
                text=seg.get("text", ""),
                pitch_mean_hz=prosody.get("pitch_mean_hz"),
                pitch_std_hz=prosody.get("pitch_std_hz"),
                energy_mean=prosody.get("energy_mean"),
                energy_std=prosody.get("energy_std"),
                speech_rate_wpm=round(seg_wpm, 1) if seg_wpm else None,
                filler_words=fluency_result.get("filler_by_speaker", {}).get(
                    seg.get("speaker", "")),
                unnatural_pauses=None,
                sentiment_score=sentiment,
                is_key_point=(i in key_point_indices),
                named_entities=segment_entities if segment_entities else None,
                topic=seg_topic,
            ))

        # Build speakers
        speakers_v4 = [
            SpeakerModel(
                speaker_id=p["speaker_id"],
                speaker_label=p["label"],
                total_time=round(p["total_time"], 3),
                ratio=round(p["ratio"], 3),
                turn_count=p["turn_count"],
                role=p["role"],
                avg_pitch_hz=p.get("avg_pitch_hz"),
                pitch_std_hz=p.get("pitch_std_hz"),
                avg_energy=p.get("avg_energy"),
                energy_cv=p.get("energy_cv"),
                speech_rate_wpm=round(p.get("speech_rate_wpm", 0), 1) if p.get("speech_rate_wpm") else None,
                filler_word_count=p.get("filler_count", 0),
                unnatural_pause_count=p.get("unnatural_pause_count", 0),
                named_entities=p.get("named_entities"),
            )
            for p in speaker_profiles
        ]

        # Build V4Result
        self._result = V4Result(
            meta=MetaSection(
                version="4.0.0",
                analyzer="audio-metrics-cli",
                timestamp=datetime.now(timezone.utc).isoformat(),
                file_name=audio_path.name,
                file_path=str(audio_path.absolute()),
                duration_seconds=round(duration, 3),
                device_used=self.device,
                chunked_processing=(duration > self.chunk_threshold_sec),
                analysis_complete=True,
            ),
            audio=AudioInfo(
                file_path=str(audio_path.absolute()),
                file_name=audio_path.name,
                duration_seconds=round(duration, 3),
                sample_rate=sr,
                channels=1,
                file_size_bytes=audio_info["file_size_bytes"],
                file_size_mb=audio_info["file_size_mb"],
                health_report=health_report,
            ),
            speakers=speakers_v4,
            segments=segments_v4,
            prosody=ProsodyMetrics(**global_prosody) if global_prosody else ProsodyMetrics(),
            fluency=FluencyMetrics(
                total_filler_count=fluency_result.get("total_filler_count", 0),
                filler_ratio=fluency_result.get("filler_ratio", 0),
                fillers_per_100_words=fluency_result.get("fillers_per_100_words", 0),
                filler_by_type=fluency_result.get("filler_by_type", {}),
                filler_by_speaker=fluency_result.get("filler_by_speaker", {}),
                unnatural_pause_count=fluency_result.get("unnatural_pause_count", 0),
                unnatural_pause_total_duration_s=fluency_result.get("unnatural_pause_total_duration_s", 0),
                unnatural_pause_positions=fluency_result.get("unnatural_pause_positions", []),
            ),
            conversation_dynamics=ConversationDynamics(
                turn_switch_rate=timing_result.get("turn_taking", {}).get("turn_count", 0) / max(duration, 1),
                avg_turn_duration=timing_result.get("turn_taking", {}).get("avg_turn_duration", 0),
                turn_duration_std=timing_result.get("turn_taking", {}).get("std_turn_duration", 0),
                overlap_seconds=dynamics_result.get("overlap_seconds", 0),
                overlap_ratio=dynamics_result.get("overlap_ratio", 0),
                interruption_count=dynamics_result.get("interruptions", {}).get("count", 0),
                avg_response_latency=timing_result.get("response_latency", {}).get("mean", 0),
                response_latency_std=timing_result.get("response_latency", {}).get("std", 0),
                long_pause_count=dynamics_result.get("long_pause_count", 0),
                avg_pause_duration=dynamics_result.get("avg_pause_duration", 0),
                total_silence_ratio=dynamics_result.get("total_silence_ratio", 0),
                fluency_score=timing_result.get("conversational_flow", {}).get("fluency_score", 0),
                engagement_score=timing_result.get("conversational_flow", {}).get("engagement_score", 0),
                balance_score=timing_result.get("conversational_flow", {}).get("balance_score", 0),
            ),
            vad=VADMetrics(
                speech_duration=vad_result.get("speech_duration", 0),
                silence_duration=vad_result.get("silence_duration", 0),
                speech_ratio=vad_result.get("speech_ratio", 0),
                pause_count=vad_result.get("pause_count", 0),
                avg_pause_duration=vad_result.get("avg_pause_duration", 0),
                long_pause_count=vad_result.get("long_pause_count", 0),
            ),
            emotion=EmotionMetrics(),
            named_entities=ner_result,
            topic_segments=TopicSegmentation(
                num_topics=len(topic_list),
                topics=[
                    TopicSegment(
                        start=round(t["start"], 3),
                        end=round(t["end"], 3),
                        topic_label=t["topic_label"],
                        keywords=t.get("keywords", []),
                        confidence=t.get("confidence", 0.5),
                    )
                    for t in topic_list
                ],
            ),
            transcript_text=stt_result["text"],
            transcript_language=stt_result.get("language", "unknown"),
            transcript_model=stt_result.get("model", self.whisper_model),
        )

        # Validate output
        try:
            self._result.validate_output()
            logger.info("V4 output validated successfully")
        except Exception as e:
            logger.error(f"V4 schema validation failed: {e}")

        # Save output
        if output_path:
            self._save_output(Path(output_path))

        total_time = round(time.time() - t0, 2)
        self.step_timings["total"] = total_time
        logger.info(
            "V4 analysis complete",
            total_time_s=total_time,
            num_segments=len(segments_v4),
            num_speakers=len(speakers_v4),
            num_topics=len(topic_list),
        )

        return self._result

    def _vad_chunked(
        self,
        audio_data: np.ndarray,
        sample_rate: int
    ) -> Dict[str, Any]:
        """Run VAD in chunked mode for long audio."""
        vad_analyzer = VADAnalyzer()
        results = []

        chunks = list(chunk_audio(
            audio_data, sample_rate,
            chunk_size_sec=self.chunk_size_sec,
            overlap_sec=60,
            progress=self.show_progress,
        ))

        desc = "VAD (long audio)" if self.show_progress else "VAD"
        for chunk_data, chunk_start, chunk_end in tqdm(chunks, desc=desc, disable=not self.show_progress):
            with suppress_warnings(["librosa", "numpy"]):
                result = vad_analyzer.analyze(chunk_data, sample_rate)
            result["_chunk_offset"] = chunk_start
            results.append(result)

        return merge_vad_results(results)

    def _diar_chunked(
        self,
        audio_path: str,
        sample_rate: int,
        num_speakers: Optional[int],
        min_speakers: Optional[int],
        max_speakers: Optional[int],
    ) -> Dict[str, Any]:
        """Run diarization in chunked mode for long audio."""
        diarizer = SpeakerDiarization(device=self.device)
        results = []

        # Load full audio for chunking
        from audio_metrics.analyzers.audio_loader import AudioLoader
        loader = AudioLoader(audio_path)
        loader.load()
        audio_data = loader.get_audio_data()

        chunks = list(chunk_audio(
            audio_data, sample_rate,
            chunk_size_sec=self.chunk_size_sec,
            overlap_sec=60,
            progress=self.show_progress,
        ))

        # Process chunks as temp files
        import tempfile
        import soundfile as sf

        desc = "Diarization (long audio)" if self.show_progress else "Diarization"
        for chunk_data, chunk_start, chunk_end in tqdm(chunks, desc=desc, disable=not self.show_progress):
            # Write chunk to temp file
            with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
                sf.write(tmp.name, chunk_data.astype(np.float32), sample_rate)
                tmp_path = tmp.name

            try:
                result = diarizer.diarize(
                    tmp_path,
                    num_speakers=num_speakers,
                    min_speakers=min_speakers,
                    max_speakers=max_speakers,
                )
                result["_chunk_offset"] = chunk_start
                results.append(result)
            except Exception as e:
                logger.warning(f"Diarization chunk failed: {e}")
            finally:
                Path(tmp_path).unlink(missing_ok=True)

        return merge_diarization_results(results)

    def _build_speaker_profiles(
        self,
        segments: List[Dict[str, Any]],
        prosody_list: List[Dict[str, Any]],
        fluency_result: Dict[str, Any],
        ner_result: NERResult,
    ) -> List[Dict[str, Any]]:
        """Build speaker profiles from segments."""
        speaker_data: Dict[str, Dict] = {}

        for i, seg in enumerate(segments):
            speaker = seg.get("speaker", "unknown")
            if speaker not in speaker_data:
                speaker_data[speaker] = {
                    "total_time": 0.0,
                    "segments": [],
                    "prosody": [],
                    "text_lengths": [],
                }

            duration = seg.get("end", 0) - seg.get("start", 0)
            speaker_data[speaker]["total_time"] += duration
            speaker_data[speaker]["segments"].append(i)
            if i < len(prosody_list) and prosody_list[i]:
                speaker_data[speaker]["prosody"].append(prosody_list[i])
            speaker_data[speaker]["text_lengths"].append(len(seg.get("text", "")))

        total_time = sum(d["total_time"] for d in speaker_data.values())
        if total_time == 0:
            total_time = 1

        profiles = []
        label_num = 1

        for speaker_id in sorted(speaker_data.keys()):
            data = speaker_data[speaker_id]
            prosodies = data["prosody"]
            texts = data["text_lengths"]

            # Compute role
            ratio = data["total_time"] / total_time
            if ratio > 0.6:
                role = "dominant_speaker"
            elif ratio > 0.3:
                role = "active_participant"
            elif ratio > 0.1:
                role = "occasional_speaker"
            else:
                role = "minimal_speaker"

            # Aggregate prosody
            avg_pitch = None
            pitch_std = None
            avg_energy = None
            energy_cv = None

            if prosodies:
                pitches = [p.get("pitch_mean_hz") for p in prosodies if p.get("pitch_mean_hz")]
                energies = [p.get("energy_mean") for p in prosodies if p.get("energy_mean")]
                cvs = [p.get("energy_cv") for p in prosodies if p.get("energy_cv")]

                if pitches:
                    avg_pitch = sum(pitches) / len(pitches)
                    pitch_std = (sum((p - avg_pitch) ** 2 for p in pitches) / len(pitches)) ** 0.5
                if energies:
                    avg_energy = sum(energies) / len(energies)
                if cvs:
                    energy_cv = sum(cvs) / len(cvs)

            # Speech rate
            total_dur = data["total_time"]
            total_words = sum(texts)
            speech_rate_wpm = (total_words / total_dur * 60) if total_dur > 0 else 0

            # Named entities for speaker
            speaker_entities = [
                e.text for e in ner_result.all_entities
                if e.speaker == speaker_id
            ]

            # Filler count
            filler_count = sum(
                sum(f.values())
                for f in fluency_result.get("filler_by_speaker", {}).get(speaker_id, {}).values()
            )

            profiles.append({
                "speaker_id": speaker_id,
                "label": f"发言人 {label_num}",
                "total_time": data["total_time"],
                "ratio": ratio,
                "turn_count": len(data["segments"]),
                "role": role,
                "avg_pitch_hz": round(avg_pitch, 2) if avg_pitch else None,
                "pitch_std_hz": round(pitch_std, 2) if pitch_std else None,
                "avg_energy": round(avg_energy, 4) if avg_energy else None,
                "energy_cv": round(energy_cv, 3) if energy_cv else None,
                "speech_rate_wpm": round(speech_rate_wpm, 1),
                "filler_count": filler_count,
                "unnatural_pause_count": 0,
                "named_entities": speaker_entities if speaker_entities else None,
            })

            label_num += 1

        return profiles

    def _save_output(self, output_path: Path) -> None:
        """Save V4 result to JSON file."""
        import json
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(self._result.to_dict(), f, ensure_ascii=False, indent=2)
        logger.info(f"Saved V4 result to {output_path}")

    def get_timings(self) -> Dict[str, float]:
        """Get step timing information."""
        return self.step_timings.copy()