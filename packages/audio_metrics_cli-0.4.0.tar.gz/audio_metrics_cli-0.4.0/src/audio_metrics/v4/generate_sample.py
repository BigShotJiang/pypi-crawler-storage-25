"""
Generate V4 Sample Output
Runs the V4 pipeline on a test audio file to produce standard_v4_sample.json.
"""

import sys
import json
from pathlib import Path

# Ensure src is on path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from audio_metrics.v4.pipeline import V4AnalysisPipeline
from audio_metrics.core.device import get_cuda_info

# Find a test audio file
TEST_PATHS = [
    "outputs/test_audio/meeting.m4a",
    "outputs/meeting_test/meeting.m4a",
    "tests/test_audio.wav",
    "test_audio.wav",
]

def find_test_audio():
    for p in TEST_PATHS:
        path = Path(p)
        if path.exists():
            return str(path.absolute())
    return None


def main():
    audio_path = find_test_audio()

    if audio_path is None:
        print("No test audio file found. Creating sample from schema...")

        # If no test audio, generate minimal valid sample
        from audio_metrics.v4.schemas import (
            V4Result, MetaSection, AudioInfo, SegmentModel, SpeakerModel,
            ProsodyMetrics, FluencyMetrics, ConversationDynamics, VADMetrics,
            NERResult, TopicSegment, TopicSegmentation, EmotionMetrics,
        )

        result = V4Result(
            meta=MetaSection(
                file_name="sample.wav",
                file_path="/data/sample.wav",
                duration_seconds=120.0,
                device_used="cpu",
            ),
            audio=AudioInfo(
                file_path="/data/sample.wav",
                file_name="sample.wav",
                duration_seconds=120.0,
                sample_rate=16000,
                channels=1,
                file_size_bytes=3840000,
                file_size_mb=3.66,
            ),
            speakers=[
                SpeakerModel(
                    speaker_id="speaker_0",
                    speaker_label="发言人 1",
                    total_time=60.0,
                    ratio=0.5,
                    turn_count=5,
                    role="dominant_speaker",
                    avg_pitch_hz=178.5,
                    speech_rate_wpm=150.0,
                    filler_word_count=5,
                ),
                SpeakerModel(
                    speaker_id="speaker_1",
                    speaker_label="发言人 2",
                    total_time=60.0,
                    ratio=0.5,
                    turn_count=5,
                    role="active_participant",
                    avg_pitch_hz=200.0,
                    speech_rate_wpm=140.0,
                    filler_word_count=8,
                ),
            ],
            segments=[
                SegmentModel(
                    segment_index=0,
                    start=0.0,
                    end=30.0,
                    duration=30.0,
                    confidence=0.95,
                    speaker="speaker_0",
                    text="今天我们讨论一下Aibee项目的进展情况。",
                    pitch_mean_hz=175.0,
                    energy_mean=0.024,
                    speech_rate_wpm=150.0,
                    sentiment_score=0.3,
                    is_key_point=True,
                    named_entities=["Aibee"],
                    topic="project_update",
                ),
                SegmentModel(
                    segment_index=1,
                    start=30.0,
                    end=60.0,
                    duration=30.0,
                    confidence=0.92,
                    speaker="speaker_1",
                    text="我来介绍一下客户那边的情况，万象城的项目进展顺利。",
                    pitch_mean_hz=195.0,
                    energy_mean=0.020,
                    speech_rate_wpm=140.0,
                    sentiment_score=0.2,
                    is_key_point=False,
                    named_entities=["万象城"],
                    topic="project_update",
                ),
            ],
            prosody=ProsodyMetrics(
                pitch_mean_hz=185.0,
                pitch_std_hz=16.0,
                energy_mean=0.022,
                voiced_ratio=0.8,
                avg_speech_rate_wpm=145.0,
            ),
            fluency=FluencyMetrics(
                total_filler_count=13,
                filler_ratio=0.015,
                fillers_per_100_words=1.5,
                filler_by_type={"那个": 4, "嗯": 5, "好": 2},
                filler_by_speaker={
                    "speaker_0": {"那个": 2, "嗯": 2},
                    "speaker_1": {"那个": 2, "嗯": 3, "好": 2},
                },
                unnatural_pause_count=2,
                unnatural_pause_total_duration_s=5.5,
            ),
            conversation_dynamics=ConversationDynamics(
                turn_switch_rate=0.1,
                avg_turn_duration=15.0,
                overlap_ratio=0.03,
                fluency_score=0.8,
                engagement_score=0.75,
                balance_score=0.7,
            ),
            vad=VADMetrics(
                speech_duration=100.0,
                silence_duration=20.0,
                speech_ratio=0.833,
                pause_count=8,
            ),
            named_entities=NERResult(
                total_entities=2,
                entities_by_type={"ORGANIZATION": 2},
                organizations=["Aibee", "万象城"],
                commercial_entities=["Aibee", "万象城"],
            ),
            topic_segments=TopicSegmentation(
                num_topics=2,
                topics=[
                    TopicSegment(
                        start=0.0,
                        end=60.0,
                        topic_label="project_update",
                        keywords=["项目", "进展", "Aibee", "万象城"],
                        confidence=0.85,
                    ),
                    TopicSegment(
                        start=60.0,
                        end=120.0,
                        topic_label="general_discussion",
                        keywords=["讨论", "情况", "客户"],
                        confidence=0.72,
                    ),
                ],
            ),
            transcript_text="今天我们讨论一下Aibee项目的进展情况。我来介绍一下客户那边的情况，万象城的项目进展顺利。",
            transcript_language="zh",
            transcript_model="base",
        )

        output_path = Path(__file__).parent.parent.parent / "standard_v4_sample.json"
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(result.to_dict(), f, ensure_ascii=False, indent=2)

        print(f"Sample generated: {output_path}")
        print(f"Schema validation: {'PASSED' if result.validate_output() else 'FAILED'}")
        return

    print(f"Running V4 pipeline on: {audio_path}")
    print(f"GPU info: {get_cuda_info()}")

    pipeline = V4AnalysisPipeline(
        device="auto",
        show_progress=True,
    )

    result = pipeline.run(audio_path=audio_path)

    # Save
    output_path = Path(__file__).parent.parent.parent / "standard_v4_sample.json"
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(result.to_dict(), f, ensure_ascii=False, indent=2)

    print(f"Sample saved: {output_path}")
    print(f"Timings: {pipeline.get_timings()}")


if __name__ == "__main__":
    main()