"""
V4 Output Schemas
Strict Pydantic models for the V4 audio analysis output.
All timestamps are rounded to 3 decimal places.
All constraints are enforced at validation time.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Optional, List, Dict, Any
from pydantic import (
    BaseModel,
    Field,
    field_validator,
    model_validator,
    ConfigDict,
)


def _round_timestamp(value: float) -> float:
    """Round timestamp to 3 decimal places."""
    if value is None:
        return None
    return round(float(value), 3)


def _validate_start_end(start: float, end: float, field_prefix: str = "") -> None:
    """Validate that start < end and both are non-negative."""
    if start < 0:
        raise ValueError(f"{field_prefix}start must be >= 0, got {start}")
    if end <= start:
        raise ValueError(f"{field_prefix}end must be > start, got end={end} <= start={start}")


# =============================================================================
# Field Validators
# =============================================================================

def _ts_validator(value: float) -> float:
    """Round timestamp to 3 decimal places."""
    return round(float(value), 3)


# =============================================================================
# Meta Section
# =============================================================================

class MetaSection(BaseModel):
    """Metadata about the analysis run."""

    model_config = ConfigDict(
        str_strip_whitespace=True,
    )

    version: str = Field(default="4.0.0", description="Output schema version")
    analyzer: str = Field(default="audio-metrics-cli", description="Analyzer name")
    timestamp: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    file_name: str
    file_path: str
    duration_seconds: float = Field(ge=0)
    device_used: str = Field(description="cuda or cpu")
    chunked_processing: bool = Field(default=False)
    analysis_complete: bool = True


# =============================================================================
# Audio Info
# =============================================================================

class AudioInfo(BaseModel):
    """Audio file metadata."""

    file_path: str
    file_name: str
    duration_seconds: float = Field(ge=0)
    sample_rate: int = Field(gt=0)
    channels: int = Field(ge=1)
    file_size_bytes: int = Field(ge=0)
    file_size_mb: float = Field(ge=0)
    health_report: Optional[Dict[str, Any]] = Field(default=None)


# =============================================================================
# Prosody Metrics
# =============================================================================

class ProsodyMetrics(BaseModel):
    """Global prosody metrics across the entire audio."""

    pitch_mean_hz: Optional[float] = None
    pitch_std_hz: Optional[float] = None
    pitch_min_hz: Optional[float] = None
    pitch_max_hz: Optional[float] = None
    pitch_range_hz: Optional[float] = None
    voiced_ratio: Optional[float] = Field(default=None, ge=0, le=1)

    energy_mean: Optional[float] = None
    energy_std: Optional[float] = None
    energy_min: Optional[float] = None
    energy_max: Optional[float] = None
    energy_dynamic_range: Optional[float] = None
    energy_cv: Optional[float] = None

    jitter: Optional[float] = None
    shimmer: Optional[float] = None
    hnr_db: Optional[float] = None

    spectral_centroid_mean: Optional[float] = None
    spectral_centroid_std: Optional[float] = None
    spectral_bandwidth_mean: Optional[float] = None
    spectral_bandwidth_std: Optional[float] = None
    spectral_rolloff_mean: Optional[float] = None
    spectral_contrast_mean: Optional[float] = None

    tempo_bpm: Optional[float] = None
    zero_crossing_rate_mean: Optional[float] = None
    zero_crossing_rate_std: Optional[float] = None

    mfcc_1_mean: Optional[float] = None
    mfcc_2_mean: Optional[float] = None
    mfcc_3_mean: Optional[float] = None
    mfcc_1_std: Optional[float] = None
    mfcc_2_std: Optional[float] = None
    mfcc_3_std: Optional[float] = None

    avg_speech_rate_wpm: Optional[float] = None


# =============================================================================
# Fluency Metrics
# =============================================================================

class FluencyMetrics(BaseModel):
    """Fluency metrics including filler words and unnatural pauses."""

    total_filler_count: int = 0
    filler_ratio: float = Field(default=0.0, ge=0, le=1)
    fillers_per_100_words: float = 0.0

    filler_by_type: Dict[str, int] = Field(default_factory=dict)

    # Per-speaker filler breakdown
    filler_by_speaker: Dict[str, Dict[str, int]] = Field(default_factory=dict)

    # Unnatural pauses
    unnatural_pause_count: int = 0
    unnatural_pause_total_duration_s: float = 0.0
    unnatural_pause_positions: List[Dict[str, Any]] = Field(default_factory=list)


# =============================================================================
# Conversation Dynamics
# =============================================================================

class ConversationDynamics(BaseModel):
    """Conversation-level dynamics metrics."""

    turn_switch_rate: float = 0.0
    avg_turn_duration: float = 0.0
    turn_duration_std: float = 0.0

    overlap_seconds: float = 0.0
    overlap_ratio: float = 0.0
    interruption_count: int = 0

    avg_response_latency: float = 0.0
    response_latency_std: float = 0.0

    long_pause_count: int = 0
    avg_pause_duration: float = 0.0
    total_silence_ratio: float = 0.0

    # Flow scores
    fluency_score: float = Field(default=0.0, ge=0, le=1)
    engagement_score: float = Field(default=0.0, ge=0, le=1)
    balance_score: float = Field(default=0.0, ge=0, le=1)


# =============================================================================
# NER Entity
# =============================================================================

class NEREntity(BaseModel):
    """A named entity extracted from the transcript."""

    text: str
    label: str = Field(description="Entity type: PERSON, ORG, GPE, PRODUCT, etc.")
    start_char: int = Field(ge=0)
    end_char: int = Field(ge=0)
    speaker: Optional[str] = None

    @field_validator("end_char", mode="after")
    @classmethod
    def end_after_start(cls, v: int, info) -> int:
        start = info.data.get("start_char")
        if start is not None and v <= start:
            raise ValueError(f"end_char {v} must be > start_char {start}")
        return v


class NERResult(BaseModel):
    """Aggregated NER results across the transcript."""

    total_entities: int = 0
    entities_by_type: Dict[str, int] = Field(default_factory=dict)

    persons: List[str] = Field(default_factory=list)
    organizations: List[str] = Field(default_factory=list)
    locations: List[str] = Field(default_factory=list)
    products: List[str] = Field(default_factory=list)
    commercial_entities: List[str] = Field(
        default_factory=list,
        description="Business/commercial entities like company names, brands"
    )

    all_entities: List[NEREntity] = Field(default_factory=list)

    @field_validator("all_entities", mode="before")
    @classmethod
    def _coerce_entities(cls, v):
        if v is None:
            return []
        return v


# =============================================================================
# Topic Segment
# =============================================================================

class TopicSegment(BaseModel):
    """A semantic topic segment of the audio."""

    start: float = Field(ge=0)
    end: float = Field(gt=0)

    topic_label: str
    keywords: List[str] = Field(default_factory=list)

    confidence: float = Field(ge=0, le=1, default=0.5)

    @field_validator("start", "end")
    @classmethod
    def _round_ts(cls, v: float) -> float:
        return _ts_validator(v)

    @model_validator(mode="after")
    def _validate_range(self):
        _validate_start_end(self.start, self.end, field_prefix="TopicSegment ")
        return self


# =============================================================================
# Individual Segment (Core output unit)
# =============================================================================

class SegmentModel(BaseModel):
    """
    A single audio segment with full annotation.
    This is the core output unit of the V4 pipeline.
    """

    model_config = ConfigDict(
        str_strip_whitespace=True,
    )

    # Core identifiers
    segment_index: int = Field(ge=0)
    start: float = Field(ge=0, description="Start time in seconds")
    end: float = Field(gt=0, description="End time in seconds")
    duration: float = Field(gt=0, description="Duration in seconds")
    confidence: float = Field(ge=0, le=1, default=1.0)

    # Speaker
    speaker: str

    # Transcript
    text: str = ""

    # Prosody fields
    pitch_mean_hz: Optional[float] = None
    pitch_std_hz: Optional[float] = None
    energy_mean: Optional[float] = None
    energy_std: Optional[float] = None
    speech_rate_wpm: Optional[float] = None

    # Fluency fields
    filler_words: Optional[Dict[str, int]] = None
    unnatural_pauses: Optional[int] = None

    # Content intelligence
    sentiment_score: float = Field(default=0.0, ge=-1, le=1)
    is_key_point: bool = False
    named_entities: Optional[List[str]] = None
    topic: Optional[str] = None

    # Timestamps validation
    @field_validator("start", "end", mode="before")
    @classmethod
    def _round_ts(cls, v: float) -> float:
        return _ts_validator(v)

    @model_validator(mode="after")
    def _validate_segment(self):
        if self.start < 0:
            raise ValueError(f"start must be >= 0, got {self.start}")
        if self.end <= self.start:
            raise ValueError(f"end must be > start, got end={self.end} <= start={self.start}")
        computed = round(self.end - self.start, 3)
        # Duration is informational, not strictly enforced
        return self


# =============================================================================
# Speaker Model
# =============================================================================

class SpeakerModel(BaseModel):
    """A detected speaker with aggregated metrics."""

    speaker_id: str
    speaker_label: str = Field(description="Human-readable label, e.g., '发言人 1'")
    total_time: float = Field(ge=0, description="Total speaking time in seconds")
    ratio: float = Field(ge=0, le=1, description="Fraction of total speaking time")
    turn_count: int = Field(ge=0)
    role: str = Field(
        description="Role: dominant_speaker, active_participant, "
        "occasional_speaker, minimal_speaker"
    )

    # Acoustic profile
    avg_pitch_hz: Optional[float] = None
    pitch_std_hz: Optional[float] = None
    avg_energy: Optional[float] = None
    energy_cv: Optional[float] = None
    speech_rate_wpm: Optional[float] = None

    # Fluency
    filler_word_count: int = 0
    unnatural_pause_count: int = 0

    # Content
    named_entities: Optional[List[str]] = None

    # Timestamps
    @field_validator("total_time", mode="before")
    @classmethod
    def _round_time(cls, v: float) -> float:
        return _ts_validator(v)


# =============================================================================
# Topic Segmentation
# =============================================================================

class TopicSegmentation(BaseModel):
    """Topic segmentation results."""

    num_topics: int = 0
    topics: List[TopicSegment] = Field(default_factory=list)


# =============================================================================
# VAD Metrics
# =============================================================================

class VADMetrics(BaseModel):
    """Voice Activity Detection metrics."""

    speech_duration: float = 0.0
    silence_duration: float = 0.0
    speech_ratio: float = Field(default=0.0, ge=0, le=1)
    pause_count: int = 0
    avg_pause_duration: float = 0.0
    long_pause_count: int = 0


# =============================================================================
# Emotion Metrics
# =============================================================================

class EmotionMetrics(BaseModel):
    """Emotion analysis metrics."""

    dominant_emotion: str = "neutral"
    confidence: float = Field(ge=0, le=1, default=0.5)
    emotion_probabilities: Dict[str, float] = Field(default_factory=dict)
    emotion_distribution: Dict[str, float] = Field(default_factory=dict)


# =============================================================================
# Full V4 Result (Root model)
# =============================================================================

class V4Result(BaseModel):
    """
    Complete V4 audio analysis result.
    This is the root model returned by the V4 pipeline.
    All timestamps are rounded to 3 decimal places.
    All constraints are enforced at validation time.
    """

    model_config = ConfigDict(
        str_strip_whitespace=True,
    )

    # Top-level sections
    meta: MetaSection
    audio: AudioInfo

    # Speaker and segment data
    speakers: List[SpeakerModel] = Field(default_factory=list)
    segments: List[SegmentModel] = Field(default_factory=list)

    # Analysis metrics
    prosody: ProsodyMetrics = Field(default_factory=ProsodyMetrics)
    fluency: FluencyMetrics = Field(default_factory=FluencyMetrics)
    conversation_dynamics: ConversationDynamics = Field(
        default_factory=ConversationDynamics
    )
    vad: VADMetrics = Field(default_factory=VADMetrics)
    emotion: EmotionMetrics = Field(default_factory=EmotionMetrics)

    # NLP-derived data
    named_entities: NERResult = Field(default_factory=NERResult)
    topic_segments: TopicSegmentation = Field(default_factory=TopicSegmentation)

    # Transcript
    transcript_text: str = ""
    transcript_language: str = "unknown"
    transcript_model: str = ""

    # Summary
    summary: Optional[Dict[str, Any]] = Field(default=None)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to plain dict for JSON serialization."""
        return self.model_dump(mode="json")

    def validate_output(self) -> bool:
        """
        Validate the output meets all schema constraints.

        Returns:
            True if valid.

        Raises:
            ValidationError: If any constraint is violated.
        """
        # Trigger full validation
        self.model_validate(self.model_dump(mode="python"))
        return True