"""
Long Audio Chunked Processing Module
Handles audio files > configurable threshold by splitting into manageable chunks.
"""

from typing import Generator, Tuple, List, Dict, Any, Optional

import numpy as np
from tqdm import tqdm

from audio_metrics.core.logger import get_logger

logger = get_logger(__name__)

# Default thresholds
DEFAULT_CHUNK_THRESHOLD_SEC = 3000  # 50 minutes
DEFAULT_CHUNK_SIZE_SEC = 1800       # 30 minutes per chunk
DEFAULT_CHUNK_OVERLAP_SEC = 60      # 60s overlap for context continuity


def chunk_audio(
    audio_data: np.ndarray,
    sample_rate: int,
    chunk_size_sec: int = DEFAULT_CHUNK_SIZE_SEC,
    overlap_sec: float = DEFAULT_CHUNK_OVERLAP_SEC,
    progress: bool = False
) -> Generator[Tuple[np.ndarray, float, float], None, None]:
    """
    Split audio into overlapping chunks for memory-efficient processing.

    Args:
        audio_data: Full audio array.
        sample_rate: Sample rate.
        chunk_size_sec: Size of each chunk in seconds.
        overlap_sec: Overlap between consecutive chunks in seconds.
        progress: Whether to show progress bar.

    Yields:
        Tuples of (chunk_data, chunk_start_sec, chunk_end_sec)
    """
    total_duration = len(audio_data) / sample_rate
    if total_duration <= chunk_size_sec:
        # No chunking needed
        yield audio_data, 0.0, total_duration
        return

    chunk_size_samples = int(chunk_size_sec * sample_rate)
    overlap_samples = int(overlap_sec * sample_rate)
    step_samples = chunk_size_samples - overlap_samples

    num_chunks = int(np.ceil((len(audio_data) - chunk_size_samples) / step_samples)) + 1

    if progress:
        logger.info(
            "Chunking audio for long-file processing",
            total_duration_s=round(total_duration, 1),
            chunk_size_sec=chunk_size_sec,
            num_chunks=num_chunks
        )

    chunks_desc = "Splitting audio" if progress else None

    for i in range(num_chunks):
        start_sample = i * step_samples
        end_sample = start_sample + chunk_size_samples

        if end_sample > len(audio_data):
            end_sample = len(audio_data)
            start_sample = max(0, end_sample - chunk_size_samples)

        chunk_data = audio_data[start_sample:end_sample]
        chunk_start = start_sample / sample_rate
        chunk_end = end_sample / sample_rate

        yield chunk_data, chunk_start, chunk_end


def merge_vad_results(results: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Merge VAD results from multiple chunks.

    Args:
        results: List of VAD results from each chunk.

    Returns:
        Merged VAD result with offset-corrected timestamps.
    """
    if not results:
        return {"speech_segments": [], "nonspeech_segments": []}

    all_speech = []
    all_nonspeech = []

    for result in results:
        offset = result.get("_chunk_offset", 0.0)
        for seg in result.get("speech_segments", []):
            all_speech.append({
                "start": round(seg["start"] + offset, 3),
                "end": round(seg["end"] + offset, 3),
            })
        for seg in result.get("nonspeech_segments", []):
            all_nonspeech.append({
                "start": round(seg["start"] + offset, 3),
                "end": round(seg["end"] + offset, 3),
            })

    # Sort by start time
    all_speech.sort(key=lambda x: x["start"])
    all_nonspeech.sort(key=lambda x: x["start"])

    # Compute stats
    total_speech = sum(s["end"] - s["start"] for s in all_speech)
    total_duration = max(s["end"] for s in all_speech) if all_speech else 0

    return {
        "speech_segments": all_speech,
        "nonspeech_segments": all_nonspeech,
        "speech_duration": round(total_speech, 3),
        "total_duration": round(total_duration, 3),
        "speech_ratio": round(total_speech / total_duration, 3) if total_duration > 0 else 0,
        "num_chunks": len(results),
    }


def merge_diarization_results(results: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Merge diarization results from multiple chunks.

    Args:
        results: List of diarization results from each chunk.

    Returns:
        Merged diarization result with offset-corrected segments.
    """
    all_segments = []
    speaker_times: Dict[str, Dict[str, float]] = {}

    for result in results:
        offset = result.get("_chunk_offset", 0.0)
        for seg in result.get("segments", []):
            corrected = {
                "start": round(seg["start"] + offset, 3),
                "end": round(seg["end"] + offset, 3),
                "duration": round(seg["end"] - seg["start"], 3),
                "speaker": seg["speaker"]
            }
            all_segments.append(corrected)

            speaker = seg["speaker"]
            if speaker not in speaker_times:
                speaker_times[speaker] = {"first": corrected["start"], "last": corrected["end"]}
            else:
                speaker_times[speaker]["last"] = max(speaker_times[speaker]["last"], corrected["end"])

    all_segments.sort(key=lambda x: x["start"])
    unique_speakers = list(set(s["speaker"] for s in all_segments))

    return {
        "segments": all_segments,
        "num_speakers": len(unique_speakers),
        "speakers": unique_speakers,
        "speaker_times": speaker_times,
        "num_chunks": len(results),
    }


def merge_transcript_chunks(
    chunk_results: List[Dict[str, Any]]
) -> Dict[str, Any]:
    """
    Merge transcribed text from multiple chunks into single transcript.

    Args:
        chunk_results: List of transcription results from each chunk.

    Returns:
        Merged transcript with combined text and all segments.
    """
    all_segments = []
    all_words = []
    total_text_parts = []

    for result in chunk_results:
        # Preserve chunk separator
        if total_text_parts:
            total_text_parts.append(" ")  # Space separator between chunks

        for seg in result.get("segments", []):
            corrected_start = seg.get("_chunk_offset", 0) + seg.get("start", 0)
            corrected_end = seg.get("_chunk_offset", 0) + seg.get("end", 0)
            all_segments.append({
                "start": round(corrected_start, 3),
                "end": round(corrected_end, 3),
                "text": seg["text"]
            })

        text = result.get("text", "")
        if text:
            total_text_parts.append(text)

    full_text = "".join(total_text_parts)
    all_segments.sort(key=lambda x: x["start"])

    # Count words
    words = full_text.split()
    lang = chunk_results[0].get("language", "unknown") if chunk_results else "unknown"

    return {
        "text": full_text.strip(),
        "language": lang,
        "words_total": len(words),
        "segments": all_segments,
    }


class ChunkProcessor:
    """Utility class for processing audio in chunks with progress tracking."""

    def __init__(
        self,
        chunk_size_sec: int = DEFAULT_CHUNK_SIZE_SEC,
        overlap_sec: float = DEFAULT_CHUNK_OVERLAP_SEC,
        show_progress: bool = True
    ):
        """
        Args:
            chunk_size_sec: Chunk size in seconds.
            overlap_sec: Overlap in seconds.
            show_progress: Whether to display tqdm progress bars.
        """
        self.chunk_size_sec = chunk_size_sec
        self.overlap_sec = overlap_sec
        self.show_progress = show_progress

    def process_chunks(
        self,
        audio_data: np.ndarray,
        sample_rate: int,
        process_fn,
        merge_fn,
        description: str = "Processing chunks"
    ) -> Any:
        """
        Process audio in chunks and merge results.

        Args:
            audio_data: Full audio array.
            sample_rate: Sample rate.
            process_fn: Function to call per chunk. Signature: (chunk_data, chunk_start, chunk_end) -> result
            merge_fn: Function to merge all chunk results.
            description: Description for progress bar.

        Returns:
            Merged results from all chunks.
        """
        total_duration = len(audio_data) / sample_rate

        if total_duration <= self.chunk_size_sec:
            # No chunking needed
            return process_fn(audio_data, 0.0, total_duration)

        results = []
        chunks = list(chunk_audio(
            audio_data, sample_rate,
            chunk_size_sec=self.chunk_size_sec,
            overlap_sec=self.overlap_sec,
            progress=False
        ))

        iterator = tqdm(
            enumerate(chunks),
            total=len(chunks),
            desc=description,
            unit="chunk",
            disable=not self.show_progress
        )

        for i, (chunk_data, chunk_start, chunk_end) in iterator:
            try:
                result = process_fn(chunk_data, chunk_start, chunk_end)
                if isinstance(result, dict):
                    result["_chunk_offset"] = chunk_start
                results.append(result)
            except Exception as e:
                logger.warning(
                    f"Chunk {i} failed, skipping",
                    chunk_start=round(chunk_start, 1),
                    chunk_end=round(chunk_end, 1),
                    error=str(e)
                )

        return merge_fn(results)