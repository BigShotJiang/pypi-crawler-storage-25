"""
Hardware Detection Module
Automatically detects GPU/CPU environment and manages device selection.
"""

import os
import subprocess
from typing import Optional

from audio_metrics.core.logger import get_logger

logger = get_logger(__name__)


def is_cuda_available() -> bool:
    """Check if NVIDIA GPU with CUDA is available."""
    try:
        import torch
        return torch.cuda.is_available()
    except ImportError:
        return False


def get_cuda_info() -> dict:
    """Get detailed CUDA/GPU information."""
    try:
        import torch
        if not torch.cuda.is_available():
            return {"available": False}

        device_count = torch.cuda.device_count()
        devices = []
        for i in range(device_count):
            props = torch.cuda.get_device_properties(i)
            devices.append({
                "index": i,
                "name": props.name,
                "total_memory_gb": round(props.total_memory / (1024**3), 1),
                "compute_capability": f"{props.major}.{props.minor}",
                "multi_processor_count": props.multi_processor_count,
            })

        return {
            "available": True,
            "device_count": device_count,
            "devices": devices,
            "cuda_version": torch.version.cuda or "unknown",
        }
    except ImportError:
        return {"available": False, "error": "torch not installed"}
    except Exception as e:
        return {"available": False, "error": str(e)}


def is_onnx_available() -> bool:
    """Check if ONNX Runtime is available for CPU acceleration."""
    try:
        import onnxruntime  # noqa: F401
        return True
    except ImportError:
        return False


def is_openvino_available() -> bool:
    """Check if OpenVINO is available for CPU acceleration."""
    try:
        import openvino  # noqa: F401
        return True
    except ImportError:
        return False


def detect_accelerators() -> list[str]:
    """Detect all available accelerator backends."""
    accelerators = []
    if is_cuda_available():
        accelerators.append("cuda")
    if is_onnx_available():
        accelerators.append("onnx")
    if is_openvino_available():
        accelerators.append("openvino")
    if not accelerators:
        accelerators.append("cpu")
    return accelerators


def get_optimal_device(force: Optional[str] = None) -> str:
    """
    Get the optimal device for inference.

    Args:
        force: Force a specific device ('cuda', 'cpu'). If None, auto-detect.

    Returns:
        Device string: 'cuda' or 'cpu'
    """
    if force in ("cuda", "cpu"):
        if force == "cuda" and not is_cuda_available():
            logger.warning("CUDA requested but not available, falling back to CPU")
            return "cpu"
        return force

    # Auto-detect
    if is_cuda_available():
        info = get_cuda_info()
        if info["available"]:
            device_name = info["devices"][0]["name"] if info["devices"] else "Unknown"
            total_mem = info["devices"][0]["total_memory_gb"] if info["devices"] else 0
            logger.info(
                "Using CUDA for inference",
                device=device_name,
                memory_gb=total_mem,
                device_count=info["device_count"]
            )
            return "cuda"

    logger.info("Using CPU for inference")
    if is_onnx_available():
        logger.debug("ONNX Runtime available for CPU acceleration")
    elif is_openvino_available():
        logger.debug("OpenVINO available for CPU acceleration")

    return "cpu"


class DeviceManager:
    """
    Singleton class to manage device configuration across all analyzers.
    All modules should query this rather than calling torch.cuda directly.
    """

    _instance: Optional["DeviceManager"] = None
    _device: Optional[str] = None

    def __new__(cls) -> "DeviceManager":
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def get_device(self, force: Optional[str] = None) -> str:
        """
        Get the configured device.

        Args:
            force: Override device (cuda/cpu/auto)

        Returns:
            Device string
        """
        if force:
            self._device = get_optimal_device(force)
        elif self._device is None:
            self._device = get_optimal_device()
        return self._device

    def get_info(self) -> dict:
        """Get device information summary."""
        return {
            "device": self.get_device(),
            "cuda_info": get_cuda_info(),
            "accelerators": detect_accelerators(),
        }

    def reset(self) -> None:
        """Reset device selection (useful for testing)."""
        self._device = None