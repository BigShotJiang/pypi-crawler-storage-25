"""
Warning Suppression Module
Context managers that suppress known non-fatal warnings during processing.
"""

import warnings
import logging
from typing import Optional
from contextlib import contextmanager

from audio_metrics.core.logger import get_logger

logger = get_logger(__name__)

# Patterns of warnings to suppress (compiled once)
_SUPPRESS_PATTERNS = [
    "degrees of freedom is <= 0",
    "n_frames.*should be",
    "divide by zero",
    "invalid value",
    "overflow",
    "invalid value encountered",
    "n_frames must be",
    "Could not find",
]


def _warning_matches_suppress_pattern(message: str) -> bool:
    """Check if a warning message matches any suppress pattern."""
    msg_lower = str(message).lower()
    for pattern in _SUPPRESS_PATTERNS:
        if pattern.lower() in msg_lower:
            return True
    return False


class WarningSuppressor:
    """Suppresses known non-fatal warnings and logs them as debug messages."""

    def __init__(self, modules: Optional[list[str]] = None):
        """
        Args:
            modules: List of module name prefixes to suppress. e.g., ['librosa', 'numpy'].
                     If None, suppresses all.
        """
        self.modules = modules or []
        self._suppressed_count = 0

    def __enter__(self):
        self._old_showwarning = warnings.showwarning
        self._suppressed_count = 0

        def _suppressed_warning(message, category, filename, lineno, file=None, line=None):
            module = getattr(message, "__module__", "")
            msg_str = str(message)

            # Check module filter
            if self.modules and not any(module.startswith(m) for m in self.modules):
                self._old_showwarning(message, category, filename, lineno, file, line)
                return

            # Check pattern filter
            if _warning_matches_suppress_pattern(msg_str):
                self._suppressed_count += 1
                logger.debug(
                    "Suppressed warning",
                    category=category.__name__,
                    module=module,
                    message=msg_str[:200]
                )
            else:
                self._old_showwarning(message, category, filename, lineno, file, line)

        warnings.showwarning = _suppressed_warning
        return self

    def __exit__(self, *args):
        warnings.showwarning = self._old_showwarning
        if self._suppressed_count > 0:
            logger.debug(f"Suppressed {self._suppressed_count} non-fatal warnings")


@contextmanager
def suppress_warnings(modules: Optional[list[str]] = None):
    """
    Context manager to suppress known non-fatal warnings.

    Usage:
        with suppress_warnings(["librosa", "numpy"]):
            pitch_data = librosa.pyin(audio)

    Args:
        modules: Module prefixes to suppress. None = all modules.
    """
    suppressor = WarningSuppressor(modules)
    with suppressor:
        yield suppressor