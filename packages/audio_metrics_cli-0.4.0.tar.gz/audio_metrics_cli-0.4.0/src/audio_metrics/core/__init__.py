"""
Audio Metrics Core Module
=========================
Core utilities for audio metrics processing.
"""

from .logger import get_logger, setup_logging
from .config import Config, load_config, merge_configs
from .model_manager import ModelManager, get_model_manager

# NOTE: Pipeline imports are lazy to avoid circular imports
# Use: from audio_metrics.core.pipeline import AudioAnalysisPipeline
# Or import directly: from audio_metrics.core import pipeline

__all__ = [
    "get_logger",
    "setup_logging",
    "Config",
    "load_config",
    "merge_configs",
    "ModelManager",
    "get_model_manager",
    # Pipeline classes - import directly from audio_metrics.core.pipeline
]
