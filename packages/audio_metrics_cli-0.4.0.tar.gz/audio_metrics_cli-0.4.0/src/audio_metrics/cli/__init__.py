"""CLI interface module."""

import sys
from pathlib import Path

# Import the top-level main_cli.py directly by path
# main_cli.py is at src/audio_metrics/main_cli.py
# cli/__init__.py is at src/audio_metrics/cli/__init__.py
_main_cli_path = Path(__file__).parent.parent / "main_cli.py"

import importlib.util
spec = importlib.util.spec_from_file_location("_v4_cli", _main_cli_path)
_v4_cli = importlib.util.module_from_spec(spec)
spec.loader.exec_module(_v4_cli)

main = _v4_cli.main

__all__ = ["main"]