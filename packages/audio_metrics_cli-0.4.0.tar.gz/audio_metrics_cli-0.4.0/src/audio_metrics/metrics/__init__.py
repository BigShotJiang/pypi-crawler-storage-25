"""
Metrics Module
==============
Metrics extraction and aggregation modules.

Classes:
    SegmentMetricsExtractor: Extract acoustic features per segment
    SpeakerMetricsAggregator: Aggregate metrics by speaker
    MetricsBuilder: Build complete metrics dictionary
"""

from .segment_metrics import SegmentMetricsExtractor
from .speaker_metrics import SpeakerMetricsAggregator
from .metrics_builder import MetricsBuilder
from .json_exporter import JSONExporter

__all__ = [
    "SegmentMetricsExtractor",
    "SpeakerMetricsAggregator",
    "MetricsBuilder",
    "JSONExporter",
]