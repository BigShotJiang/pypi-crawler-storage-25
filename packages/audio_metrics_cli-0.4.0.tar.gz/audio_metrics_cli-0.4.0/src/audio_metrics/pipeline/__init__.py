"""
Pipeline Module
===============
Analysis pipeline orchestration.

Classes:
    AnalysisPipeline: Main analysis pipeline orchestrating all modules
"""

from .pipeline import AnalysisPipeline

__all__ = [
    "AnalysisPipeline",
]