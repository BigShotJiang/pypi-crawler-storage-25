"""MemoryMesh exception hierarchy.

All public exceptions inherit from :class:`MemoryMeshError` so callers can
catch the entire family with a single ``except MemoryMeshError`` clause while
still being able to distinguish specific failure modes when needed.
"""

from __future__ import annotations


class MemoryMeshError(Exception):
    """Base class for all MemoryMesh exceptions."""


# ── Configuration ────────────────────────────────────────────────────────────


class ConfigError(MemoryMeshError):
    """Raised when the configuration file is missing, malformed, or invalid."""


# ── Indexing ─────────────────────────────────────────────────────────────────


class IndexingError(MemoryMeshError):
    """General failure during the indexing pipeline."""


class ParseError(IndexingError):
    """A file could not be parsed (corrupted, unsupported encoding, etc.)."""


class EmbeddingError(IndexingError):
    """The embedding provider failed to produce vectors."""


# ── Storage ──────────────────────────────────────────────────────────────────


class StorageError(MemoryMeshError):
    """A read or write to the vector store or metadata store failed."""


class EmbeddingModelMismatchError(StorageError):
    """The collection was built with a different embedding model.

    The caller must run ``memorymesh reindex --all`` before the server can start.
    """


# ── Search ───────────────────────────────────────────────────────────────────


class SearchError(MemoryMeshError):
    """The search engine failed to execute a query."""


# ── MCP tool errors ──────────────────────────────────────────────────────────


class DocumentNotFoundError(MemoryMeshError):
    """The requested document path is not inside any configured source."""


class DocumentTooLargeError(MemoryMeshError):
    """The document exceeds the ``max_bytes`` limit for ``get_document``."""
