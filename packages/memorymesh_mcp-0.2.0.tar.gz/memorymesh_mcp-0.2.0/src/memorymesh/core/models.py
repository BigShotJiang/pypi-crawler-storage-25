"""Domain models and configuration schema for MemoryMesh.

Two categories live here:

* **Config models** — Pydantic v2 models that mirror ``config.yaml``.  Every
  field has a sane default so the daemon can boot without a config file.
* **Domain models** — data structures that flow between the indexer, storage,
  search engine, and MCP tools.  Kept as Pydantic models for free validation,
  serialisation, and IDE auto-complete.
"""

from __future__ import annotations

import time
from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

FileStatusLiteral = Literal["indexed", "parse_error", "unsupported", "deleted", "pending_reindex"]

# ── Helpers ──────────────────────────────────────────────────────────────────

_DEFAULT_GLOBAL_IGNORE: list[str] = [
    "**/.git/**",
    "**/node_modules/**",
    "**/__pycache__/**",
    "**/.venv/**",
    "**/venv/**",
    "**/.env",
    "**/.env.*",
    "**/*.key",
    "**/*.pem",
    "**/id_rsa*",
    "**/secrets/**",
    "**/.ssh/**",
    "**/.aws/**",
    "**/dist/**",
    "**/build/**",
    "**/target/**",
]

# ═══════════════════════════════════════════════════════════════════════════════
# CONFIG MODELS
# ═══════════════════════════════════════════════════════════════════════════════


class SourceConfig(BaseModel):
    """A single monitored directory.

    Args:
        name: Human-readable identifier (optional).
        path: Absolute or ``~``-prefixed path to index.
        recursive: Whether to descend into subdirectories.
        extensions: Whitelist of file extensions (e.g. ``[".py", ".md"]``).
            Empty list means "use the global default extension list".
        ignore: Additional glob patterns to skip inside this source.
    """

    name: str = ""
    path: Path
    recursive: bool = True
    extensions: list[str] = Field(default_factory=list)
    ignore: list[str] = Field(default_factory=list)

    @field_validator("path", mode="before")
    @classmethod
    def _expand_path(cls, v: Any) -> Path:
        return Path(str(v)).expanduser()


class EmbeddingsConfig(BaseModel):
    """Embedding provider settings.

    Args:
        provider: Provider key — ``"sentence_transformers"`` in the MVP.
        model: Model name passed to the provider.
        device: Compute device — ``"auto"`` lets the provider decide.
        batch_size: Number of texts embedded per forward pass.
        normalize: Whether to L2-normalise vectors (enables cosine via dot product).
    """

    provider: str = "sentence_transformers"
    model: str = "all-MiniLM-L6-v2"
    device: Literal["auto", "cpu", "cuda", "mps"] = "auto"
    batch_size: int = 32
    normalize: bool = True


class RecursiveChunkingConfig(BaseModel):
    """Settings for the recursive text splitter."""

    strategy: Literal["recursive"] = "recursive"
    chunk_size: int = 512
    chunk_overlap: int = 50


class MarkdownChunkingConfig(BaseModel):
    """Settings for the heading-based markdown splitter."""

    strategy: Literal["by_heading"] = "by_heading"
    max_chunk_size: int = 800


class CodeChunkingConfig(BaseModel):
    """Settings for the tree-sitter AST-aware code splitter."""

    strategy: Literal["tree_sitter"] = "tree_sitter"
    max_chunk_size: int = 1024
    fallback: str = "recursive"


class ChunkingConfig(BaseModel):
    """Per-content-type chunking configuration."""

    default: RecursiveChunkingConfig = Field(default_factory=RecursiveChunkingConfig)
    markdown: MarkdownChunkingConfig = Field(default_factory=MarkdownChunkingConfig)
    code: CodeChunkingConfig = Field(default_factory=CodeChunkingConfig)


class OcrConfig(BaseModel):
    """Optional OCR fallback for scanned PDFs.

    Args:
        enabled: Master switch; OCR is never called when ``False``.
        backend: ``"tesseract"`` (default) or ``"easyocr"``.
        languages: Language codes passed to the backend.
        trigger: When to invoke OCR — ``"empty_text_only"`` means only when
            the native parser returned fewer than 50 characters.
        max_file_size_mb: Files larger than this are skipped by OCR.
    """

    enabled: bool = False
    backend: Literal["tesseract", "easyocr"] = "tesseract"
    languages: list[str] = Field(default_factory=lambda: ["eng"])
    trigger: Literal["empty_text_only"] = "empty_text_only"
    max_file_size_mb: int = 50


class SearchHybridConfig(BaseModel):
    """Hybrid (dense + sparse) fusion settings."""

    enabled: bool = True
    rrf_k: int = 60
    over_fetch_factor: int = 3


class SearchRerankerConfig(BaseModel):
    """Cross-encoder reranker placeholder — not implemented in the MVP."""

    enabled: bool = False


class SearchConfig(BaseModel):
    """Query-time search settings."""

    default_top_k: int = 10
    hybrid: SearchHybridConfig = Field(default_factory=SearchHybridConfig)
    reranker: SearchRerankerConfig = Field(default_factory=SearchRerankerConfig)
    parent_window_chars: int = Field(
        default=0,
        description=(
            "When > 0, search_memory returns an extended_preview with this many "
            "additional characters of context around each hit. 0 = disabled."
        ),
    )


class StorageConfig(BaseModel):
    """Paths for all persistent state managed by MemoryMesh.

    All sub-paths (``metadata_db``, ``bm25_pickle``, ``audit_log``) are
    *relative to* ``base_dir``.  Use the ``*_path`` properties to get the
    resolved absolute :class:`~pathlib.Path`.

    Note: the ``*_path`` computed properties are Python ``@property`` methods and
    do **not** appear in ``model_dump()`` / ``model_json_schema()`` output.
    """

    base_dir: Path = Field(default_factory=lambda: Path("~/.memorymesh").expanduser())
    vector_db_subdir: str = "chroma_db"
    metadata_db: str = "metadata.sqlite3"
    bm25_pickle: str = "bm25.pkl"
    audit_log: str = "audit.jsonl"

    @field_validator("base_dir", mode="before")
    @classmethod
    def _expand_base_dir(cls, v: Any) -> Path:
        return Path(str(v)).expanduser()

    @property
    def vector_db_path(self) -> Path:
        """Absolute path to the ChromaDB directory."""
        return self.base_dir / self.vector_db_subdir

    @property
    def metadata_db_path(self) -> Path:
        """Absolute path to the SQLite metadata database."""
        return self.base_dir / self.metadata_db

    @property
    def bm25_pickle_path(self) -> Path:
        """Absolute path to the BM25 pickle file."""
        return self.base_dir / self.bm25_pickle

    @property
    def audit_log_path(self) -> Path:
        """Absolute path to the JSONL audit log."""
        return self.base_dir / self.audit_log


class ServerHttpConfig(BaseModel):
    """HTTP listener settings for the streamable-http transport."""

    host: str = "127.0.0.1"
    port: int = 8765


class ServerConfig(BaseModel):
    """MCP server transport configuration."""

    transport: Literal["stdio", "streamable-http"] = "stdio"
    http: ServerHttpConfig = Field(default_factory=ServerHttpConfig)


class WatcherConfig(BaseModel):
    """Filesystem watcher settings."""

    enabled: bool = True
    debounce_ms: int = 1500
    worker_concurrency: int = 2
    use_polling: bool = False


class LoggingConfig(BaseModel):
    """Logging sink configuration.

    Args:
        level: Minimum log level string.
        format: ``"pretty"`` for coloured human-readable, ``"json"`` for NDJSON.
        file: Path to the rotating log file.  ``None`` disables file logging.
        rotation: loguru rotation spec (e.g. ``"10 MB"``).
        retention: loguru retention spec (e.g. ``"14 days"``).
    """

    level: str = "INFO"
    format: Literal["pretty", "json"] = "pretty"
    file: Path | None = Field(
        default_factory=lambda: Path("~/.memorymesh/logs/memorymesh.log").expanduser()
    )
    rotation: str = "10 MB"
    retention: str = "14 days"

    @field_validator("file", mode="before")
    @classmethod
    def _expand_file(cls, v: Any) -> Path | None:
        if v is None:
            return None
        return Path(str(v)).expanduser()


class MemoryMeshConfig(BaseModel):
    """Root configuration model for MemoryMesh.

    Mirrors the top-level keys of ``config.yaml``.  All fields have defaults
    so the daemon can boot without any config file present.
    """

    sources: list[SourceConfig] = Field(default_factory=list)
    global_ignore: list[str] = Field(
        default_factory=lambda: list(_DEFAULT_GLOBAL_IGNORE)
    )
    embeddings: EmbeddingsConfig = Field(default_factory=EmbeddingsConfig)
    chunking: ChunkingConfig = Field(default_factory=ChunkingConfig)
    ocr: OcrConfig = Field(default_factory=OcrConfig)
    search: SearchConfig = Field(default_factory=SearchConfig)
    storage: StorageConfig = Field(default_factory=StorageConfig)
    server: ServerConfig = Field(default_factory=ServerConfig)
    watcher: WatcherConfig = Field(default_factory=WatcherConfig)
    logging: LoggingConfig = Field(default_factory=LoggingConfig)


# ═══════════════════════════════════════════════════════════════════════════════
# DOMAIN MODELS
# ═══════════════════════════════════════════════════════════════════════════════


class ChunkMetadata(BaseModel):
    """Optional structural metadata attached to a chunk.

    Fields are populated by the relevant :class:`~memorymesh.chunking.base.Chunker`
    and stored alongside the chunk in ChromaDB so search hits can reference the
    exact code symbol or heading they came from.
    """

    heading_path: list[str] | None = None
    function_name: str | None = None
    class_name: str | None = None
    language: str | None = None


class ParsedDocument(BaseModel):
    """Output of a :class:`~memorymesh.parsing.base.Parser`.

    Args:
        path: Absolute path to the source file.
        text: Extracted plain text (may be empty for image-only PDFs).
        file_type: Normalised extension (e.g. ``".pdf"``).
        encoding: Detected encoding used to read the file.
        metadata: Free-form dict for parser-specific extras (page count, etc.).
    """

    path: Path
    text: str
    file_type: str
    encoding: str = "utf-8"
    metadata: dict[str, Any] = Field(default_factory=dict)


class Chunk(BaseModel):
    """A single text chunk produced by a :class:`~memorymesh.chunking.base.Chunker`.

    Args:
        path: Absolute path to the source file.
        chunk_index: Zero-based position in the file's chunk sequence.
        text: Raw chunk content.
        start_char: Character offset of the first character in the source text.
        end_char: Character offset one past the last character.
        file_type: Normalised extension of the source file.
        mtime: Modification timestamp of the source file (``os.path.getmtime``).
        source_root: Name of the :class:`SourceConfig` this file belongs to.
        metadata: Optional structural metadata (heading, function name, …).
    """

    model_config = ConfigDict(frozen=False)

    path: Path
    chunk_index: int
    text: str
    start_char: int
    end_char: int
    file_type: str = ""
    mtime: float = 0.0
    source_root: str = ""
    metadata: ChunkMetadata = Field(default_factory=ChunkMetadata)

    @property
    def id(self) -> str:
        """Stable unique identifier: ``<path>:<chunk_index>``."""
        return f"{self.path}:{self.chunk_index}"


class ChunkWithEmbedding(Chunk):
    """A :class:`Chunk` augmented with its dense embedding vector.

    Produced by passing chunks through an
    :class:`~memorymesh.embeddings.base.EmbeddingProvider`.
    """

    embedding: list[float]


class FileRecord(BaseModel):
    """Row in the ``files`` table of the metadata SQLite database.

    Args:
        path: Absolute path string (primary key).
        source_name: Name of the owning :class:`SourceConfig`.
        sha256: SHA-256 hex digest of the file contents at index time.
        mtime: ``os.path.getmtime`` value at index time.
        size_bytes: File size in bytes.
        file_type: Normalised extension.
        n_chunks: Number of chunks produced.
        status: One of ``indexed``, ``parse_error``, ``unsupported``,
            ``deleted``, ``pending_reindex``.
        error_message: Human-readable description of the last failure, if any.
        indexed_at: Unix timestamp of the last successful (or failed) index.
        embedding_model_id: The ``model_id`` of the embedding provider used.
    """

    path: str
    source_name: str
    sha256: str
    mtime: float
    size_bytes: int
    file_type: str
    n_chunks: int
    status: FileStatusLiteral
    error_message: str | None = None
    indexed_at: float = Field(default_factory=time.time)
    embedding_model_id: str = ""


class IndexResult(BaseModel):
    """Result of indexing a single file, returned by :class:`FileIndexer`.

    Args:
        path: The file that was processed.
        status: Outcome — ``indexed``, ``skipped``, ``parse_error``, ``unsupported``.
        n_chunks: Number of chunks upserted (0 for non-indexed statuses).
        duration_ms: Wall time for the full pipeline in milliseconds.
        error: Error message when ``status`` is not ``indexed`` or ``skipped``.
    """

    path: Path
    status: Literal["indexed", "skipped", "parse_error", "unsupported"]
    n_chunks: int = 0
    duration_ms: float = 0.0
    error: str | None = None


class SearchHit(BaseModel):
    """A single result from the search engine.

    Args:
        path: Absolute path to the source file.
        chunk_index: Position of this chunk within the file.
        score: Relevance score (higher is better; range depends on fusion mode).
        preview: Up to 200 characters of chunk text.
        file_type: Normalised extension.
        mtime: Modification timestamp at index time.
        source_root: Name of the owning source.
        start_char: Character offset of the first character of this chunk in the
            source file.  Populated from Chroma metadata; defaults to 0.
        end_char: Character offset one past the last character of this chunk.
            Populated from Chroma metadata; defaults to 0.
        extended_preview: Wider context window around the chunk, populated by
            :func:`~memorymesh.search.context.expand_context` when
            ``search.parent_window_chars > 0``.  ``None`` when disabled.
    """

    path: str
    chunk_index: int
    score: float
    preview: str
    file_type: str
    mtime: float
    source_root: str
    start_char: int = 0
    end_char: int = 0
    extended_preview: str | None = None


class SearchResponse(BaseModel):
    """Full response from :func:`search_memory` MCP tool.

    Args:
        hits: Ranked list of search results.
        mode: Search mode used — ``hybrid``, ``dense``, or ``sparse``.
        duration_ms: Total query latency in milliseconds.
    """

    hits: list[SearchHit]
    mode: Literal["hybrid", "dense", "sparse"]
    duration_ms: float


class SourceStats(BaseModel):
    """Per-source statistics returned by :func:`list_sources` MCP tool."""

    name: str
    path: str
    recursive: bool
    n_files_indexed: int
    n_files_pending: int
    n_files_errored: int
    last_scan_at: float | None
    total_chunks: int
    disk_size_bytes: int


class SourcesReport(BaseModel):
    """Full response from the :func:`list_sources` MCP tool."""

    sources: list[SourceStats]


class DocumentResponse(BaseModel):
    """Full response from the :func:`get_document` MCP tool.

    Args:
        path: Absolute path of the document.
        content: File contents (possibly truncated).
        file_type: Normalised extension.
        size_bytes: File size in bytes.
        mtime: Modification timestamp.
        truncated: ``True`` when ``content`` was cut at ``max_bytes``.
    """

    path: str
    content: str
    file_type: str
    size_bytes: int
    mtime: float
    truncated: bool


class IndexResponse(BaseModel):
    """Full response from the :func:`index_now` MCP tool."""

    n_files_processed: int
    n_chunks: int
    duration_ms: float
    errors: list[str] = Field(default_factory=list)
