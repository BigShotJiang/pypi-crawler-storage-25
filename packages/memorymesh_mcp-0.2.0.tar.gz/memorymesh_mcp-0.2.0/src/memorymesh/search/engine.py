"""Hybrid search engine: dense (ChromaDB) + sparse (BM25) fused via RRF.

The engine is stateless between queries — it delegates to the vector store and
BM25 index for retrieval, then fuses results.

Search modes:
- ``"hybrid"`` (default) — dense + sparse + RRF.
- ``"dense"``  — dense vector search only.
- ``"sparse"`` — BM25 only.

Privacy invariant: query text is never logged — only mode, top_k, and latency.
"""

from __future__ import annotations

import time
from typing import TYPE_CHECKING, Literal, cast

from loguru import logger

from memorymesh.core.models import SearchHit, SearchResponse
from memorymesh.search.rank_fusion import reciprocal_rank_fusion

if TYPE_CHECKING:
    from memorymesh.core.models import SearchConfig
    from memorymesh.embeddings.base import EmbeddingProvider
    from memorymesh.storage.bm25_index import BM25Index
    from memorymesh.storage.vector_store import VectorStore

SearchMode = Literal["hybrid", "dense", "sparse"]


class SearchEngine:
    """Orchestrates dense + sparse search with RRF fusion.

    Args:
        vector_store: ChromaDB vector store for dense retrieval.
        bm25_index: BM25 index for sparse retrieval.
        embedding_provider: Converts query text to a vector.
        config: Search configuration (top_k, RRF k, over-fetch factor).
    """

    def __init__(
        self,
        vector_store: VectorStore,
        bm25_index: BM25Index,
        embedding_provider: EmbeddingProvider,
        config: SearchConfig | None = None,
    ) -> None:
        from memorymesh.core.models import SearchConfig as _Cfg

        self._vector_store = vector_store
        self._bm25 = bm25_index
        self._provider = embedding_provider
        self._cfg: SearchConfig = config or _Cfg()

    def search(
        self,
        query: str,
        top_k: int | None = None,
        mode: str | SearchMode = "hybrid",
        filter_: dict[str, object] | None = None,
    ) -> SearchResponse:
        """Run a search query and return fused results.

        Args:
            query: Natural-language query string.
            top_k: Number of results to return.  Defaults to
                ``config.default_top_k``.
            mode: Search mode — ``"hybrid"``, ``"dense"``, or ``"sparse"``.
            filter_: Optional ChromaDB ``where`` filter applied to dense
                search only.

        Returns:
            :class:`~memorymesh.core.models.SearchResponse` with ranked hits.
        """
        t0 = time.perf_counter()
        k = top_k if top_k is not None else self._cfg.default_top_k
        over_fetch = k * self._cfg.hybrid.over_fetch_factor

        effective_mode: SearchMode = cast(SearchMode, mode)
        if mode == "hybrid" and not self._cfg.hybrid.enabled:
            effective_mode = "dense"

        dense_hits: list[SearchHit] = []
        sparse_hits: list[SearchHit] = []

        if effective_mode in ("hybrid", "dense"):
            query_vec = self._provider.embed_query(query)
            dense_hits = self._vector_store.search(query_vec, top_k=over_fetch, filter_=filter_)

        if effective_mode in ("hybrid", "sparse"):
            sparse_hits = self._bm25.search(query, top_k=over_fetch)

        if effective_mode == "dense":
            final_hits = dense_hits[:k]
        elif effective_mode == "sparse":
            final_hits = sparse_hits[:k]
        else:
            final_hits = self._fuse(dense_hits, sparse_hits, k)

        duration_ms = (time.perf_counter() - t0) * 1000
        logger.info(
            f"SearchEngine: mode={effective_mode!r} top_k={k} "
            f"hits={len(final_hits)} latency={duration_ms:.1f}ms"
        )
        return SearchResponse(
            hits=final_hits,
            mode=effective_mode,
            duration_ms=round(duration_ms, 2),
        )

    # ── Private ───────────────────────────────────────────────────────────────

    def _fuse(
        self,
        dense_hits: list[SearchHit],
        sparse_hits: list[SearchHit],
        top_k: int,
    ) -> list[SearchHit]:
        """Fuse dense and sparse hits via RRF, return top_k merged results."""
        dense_ids = [self._hit_id(h) for h in dense_hits]
        sparse_ids = [self._hit_id(h) for h in sparse_hits]

        fused = reciprocal_rank_fusion([dense_ids, sparse_ids], k=self._cfg.hybrid.rrf_k)

        # Build a lookup from hit_id → SearchHit, preferring dense (richer metadata)
        hit_map: dict[str, SearchHit] = {}
        for hit in reversed(sparse_hits):
            hit_map[self._hit_id(hit)] = hit
        for hit in reversed(dense_hits):
            hit_map[self._hit_id(hit)] = hit

        results: list[SearchHit] = []
        for doc_id, rrf_score in fused[:top_k]:
            if doc_id not in hit_map:
                continue
            hit = hit_map[doc_id]
            # Replace score with the RRF score for consistent ranking signal
            results.append(
                SearchHit(
                    path=hit.path,
                    chunk_index=hit.chunk_index,
                    score=round(rrf_score, 6),
                    preview=hit.preview,
                    file_type=hit.file_type,
                    mtime=hit.mtime,
                    source_root=hit.source_root,
                )
            )
        return results

    @staticmethod
    def _hit_id(hit: SearchHit) -> str:
        return f"{hit.path}:{hit.chunk_index}"
