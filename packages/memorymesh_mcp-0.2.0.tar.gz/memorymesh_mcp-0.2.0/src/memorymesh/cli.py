"""MemoryMesh CLI — complete Typer application.

Commands
--------
* ``start``   — boot the MCP server (stdio or http daemon).
* ``stop``    — gracefully stop the HTTP daemon via POST /admin/shutdown.
* ``status``  — show indexing statistics for all configured sources.
* ``index``   — trigger an immediate index of a path or all sources.
* ``reindex`` — force re-index (ignores hash cache).
* ``search``  — run a query from the terminal for quick testing.
* ``serve``   — alias for ``start`` (useful in Docker / systemd).
* ``info``    — show version and config paths.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

import typer

from memorymesh import __version__
from memorymesh.observability.logging import setup_logging

app = typer.Typer(
    name="memorymesh",
    help="MemoryMesh — local MCP hub for personal data.",
    add_completion=False,
    no_args_is_help=True,
)

_DEFAULT_CONFIG: Path | None = None
_DEFAULT_PID = Path("~/.memorymesh/daemon.pid").expanduser()
_DEFAULT_ADMIN_TOKEN_ENV = "MEMORYMESH_ADMIN_TOKEN"


# ── Global options ────────────────────────────────────────────────────────────


@app.callback()
def _global_options(
    ctx: typer.Context,
    config: Path | None = typer.Option(
        None,
        "--config",
        "-c",
        envvar="MEMORYMESH_CONFIG",
        help="Path to config.yaml.  Defaults to ~/.memorymesh/config.yaml.",
        show_default=True,
    ),
    log_level: str = typer.Option(
        "INFO",
        "--log-level",
        envvar="MEMORYMESH_LOG_LEVEL",
        help="Log level: DEBUG | INFO | WARNING | ERROR | CRITICAL",
        show_default=True,
    ),
) -> None:
    """Global options applied before every command."""
    setup_logging(level=log_level.upper())
    ctx.ensure_object(dict)
    ctx.obj["config_path"] = config


# ── Helpers ───────────────────────────────────────────────────────────────────


def _load_context(config_path: Path | None) -> tuple:
    """Bootstrap all runtime objects and return ``(mcp, app_ctx)``."""
    from memorymesh.config import load_config
    from memorymesh.embeddings.sentence_transformers_provider import (
        SentenceTransformersProvider,
    )
    from memorymesh.indexer.file_indexer import FileIndexer
    from memorymesh.observability.audit import AuditLogger
    from memorymesh.search.engine import SearchEngine
    from memorymesh.server.app import AppContext, build_mcp
    from memorymesh.storage.bm25_index import BM25Index
    from memorymesh.storage.metadata_store import MetadataStore
    from memorymesh.storage.vector_store import ChromaVectorStore

    cfg = load_config(config_path)

    provider = SentenceTransformersProvider(config=cfg.embeddings)

    vector_store = ChromaVectorStore(
        db_path=cfg.storage.vector_db_path,
        embedding_model_id=provider.model_id,
    )
    metadata_store = MetadataStore(cfg.storage.metadata_db_path)
    bm25 = BM25Index(cfg.storage.bm25_pickle_path)
    bm25.load()

    indexer = FileIndexer(
        config=cfg,
        vector_store=vector_store,
        metadata_store=metadata_store,
        embedding_provider=provider,
        bm25_index=bm25,
    )

    engine = SearchEngine(
        vector_store=vector_store,
        bm25_index=bm25,
        embedding_provider=provider,
        config=cfg.search,
    )

    audit_logger = AuditLogger(cfg.storage.audit_log_path)

    ctx_obj = AppContext(
        config=cfg,
        vector_store=vector_store,
        metadata_store=metadata_store,
        bm25=bm25,
        provider=provider,
        indexer=indexer,
        engine=engine,
        audit_logger=audit_logger,
    )
    mcp = build_mcp(ctx_obj)
    return mcp, ctx_obj


# ── Commands ──────────────────────────────────────────────────────────────────


@app.command()
def start(
    ctx: typer.Context,
    transport: str = typer.Option(
        "stdio",
        "--transport",
        "-t",
        envvar="MEMORYMESH_TRANSPORT",
        help="Transport: 'stdio' or 'streamable-http'.",
        show_default=True,
    ),
    host: str = typer.Option(
        "127.0.0.1",
        "--host",
        help="HTTP listener host (streamable-http only).",
        show_default=True,
    ),
    port: int = typer.Option(
        8765,
        "--port",
        "-p",
        help="HTTP listener port (streamable-http only).",
        show_default=True,
    ),
    detach: bool = typer.Option(
        False,
        "--detach",
        help="Launch daemon in background and return immediately.",
    ),
) -> None:
    """Start the MemoryMesh MCP server.

    Uses stdio transport by default (suitable for Claude Desktop / Cursor).
    Pass ``--transport streamable-http`` to run as an HTTP daemon.
    Add ``--detach`` to launch in the background and return immediately.
    """
    if detach:
        import subprocess

        cmd = [sys.executable, "-m", "memorymesh", "start",
               "--transport", transport, "--host", host, "--port", str(port)]
        config_path: Path | None = ctx.obj["config_path"]
        if config_path:
            cmd += ["--config", str(config_path)]

        kwargs: dict = {}
        if sys.platform == "win32":
            kwargs["creationflags"] = (
                subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP
            )
        else:
            kwargs["start_new_session"] = True

        proc = subprocess.Popen(cmd, **kwargs)
        typer.echo(f"Daemon started (PID: {proc.pid})")
        return

    config_path = ctx.obj["config_path"]
    mcp, app_ctx = _load_context(config_path)

    # Override transport / http settings from CLI flags.
    # We mutate a fresh copy rather than the frozen AppContext.
    from memorymesh.core.models import ServerConfig, ServerHttpConfig

    server_cfg = ServerConfig(
        transport=transport,  # type: ignore[arg-type]
        http=ServerHttpConfig(host=host, port=port),
    )
    # Build a new AppContext with the overridden server config.
    from dataclasses import replace as dc_replace


    new_config = app_ctx.config.model_copy(update={"server": server_cfg})
    app_ctx = dc_replace(app_ctx, config=new_config)

    app_ctx.indexer.startup()

    from memorymesh.server.transports import run

    try:
        run(mcp, app_ctx)
    finally:
        app_ctx.indexer.shutdown()


@app.command()
def serve(ctx: typer.Context) -> None:
    """Alias for ``start`` — useful in Docker / systemd unit files."""
    # Forward to start with default options.
    ctx.invoke(start)


@app.command()
def stop(
    pid_file: Path = typer.Option(
        _DEFAULT_PID,
        "--pid-file",
        help="Path to the daemon PID file.",
        show_default=True,
    ),
    token: str | None = typer.Option(
        None,
        "--token",
        envvar=_DEFAULT_ADMIN_TOKEN_ENV,
        help="Admin bearer token (MEMORYMESH_ADMIN_TOKEN).",
    ),
    host: str = typer.Option("127.0.0.1", "--host", show_default=True),
    port: int = typer.Option(8765, "--port", "-p", show_default=True),
) -> None:
    """Gracefully stop the HTTP daemon.

    First tries ``POST /admin/shutdown``; falls back to ``psutil`` process
    termination if the HTTP call fails.
    """

    # Try HTTP shutdown first.
    shutdown_ok = _http_shutdown(host, port, token)
    if shutdown_ok:
        typer.echo("MemoryMesh daemon stopped via HTTP shutdown.")
        return

    # Fallback: read PID file and terminate.
    if not pid_file.exists():
        typer.echo(
            f"No PID file found at {pid_file}.  Is the daemon running in HTTP mode?",
            err=True,
        )
        raise typer.Exit(code=1)

    try:
        pid = int(pid_file.read_text().strip())
    except (ValueError, OSError) as exc:
        typer.echo(f"Cannot read PID file: {exc}", err=True)
        raise typer.Exit(code=1) from exc

    _kill_pid(pid, pid_file)


def _http_shutdown(host: str, port: int, token: str | None) -> bool:
    """POST /admin/shutdown; return True on success."""
    try:
        import urllib.request

        url = f"http://{host}:{port}/admin/shutdown"
        headers = {}
        if token:
            headers["X-MemoryMesh-Token"] = token
        req = urllib.request.Request(url, data=b"", headers=headers, method="POST")
        with urllib.request.urlopen(req, timeout=5) as resp:
            return bool(resp.status == 200)
    except Exception:
        return False


def _kill_pid(pid: int, pid_file: Path) -> None:
    """Terminate process *pid* with psutil or os.kill fallback."""
    try:
        import psutil

        proc = psutil.Process(pid)
        proc.terminate()
        try:
            proc.wait(timeout=10)
        except psutil.TimeoutExpired:
            proc.kill()
        typer.echo(f"MemoryMesh daemon (PID {pid}) stopped.")
    except ImportError:
        import signal as _signal

        try:
            os.kill(pid, _signal.SIGTERM)
            typer.echo(f"Sent SIGTERM to PID {pid}.")
        except ProcessLookupError:
            typer.echo(f"Process {pid} is not running.", err=True)
        except PermissionError as exc:
            typer.echo(f"Cannot terminate PID {pid}: {exc}", err=True)
            raise typer.Exit(code=1) from exc
    except Exception as exc:
        typer.echo(f"Error stopping PID {pid}: {exc}", err=True)
        raise typer.Exit(code=1) from exc
    finally:
        try:
            if pid_file.exists():
                pid_file.unlink()
        except OSError:
            pass


@app.command()
def status(ctx: typer.Context) -> None:
    """Show indexing statistics for all configured sources."""
    config_path: Path | None = ctx.obj["config_path"]
    from memorymesh.config import load_config
    from memorymesh.storage.metadata_store import MetadataStore

    cfg = load_config(config_path)
    ms = MetadataStore(cfg.storage.metadata_db_path)

    if not cfg.sources:
        typer.echo("No sources configured.  Add sources to your config.yaml.")
        return

    typer.echo(f"MemoryMesh  v{__version__}")
    typer.echo(f"State dir   : {cfg.storage.base_dir}")
    typer.echo("")
    typer.echo(f"{'Source':<30} {'Indexed':>8} {'Errors':>7} {'Chunks':>8}")
    typer.echo("-" * 56)

    for src in cfg.sources:
        name = src.name or str(src.path)
        records = [r for r in ms.list_files() if r.source_name == name]
        n_indexed = sum(1 for r in records if r.status == "indexed")
        n_err = sum(1 for r in records if r.status == "parse_error")
        n_chunks = sum(r.n_chunks for r in records if r.status == "indexed")
        typer.echo(f"{name:<30} {n_indexed:>8} {n_err:>7} {n_chunks:>8}")


@app.command()
def index(
    ctx: typer.Context,
    path: Path | None = typer.Argument(
        None,
        help="File or directory to index.  Omit to index all configured sources.",
    ),
    source_name: str = typer.Option(
        "",
        "--source",
        "-s",
        help="Source name to assign (used with --path).",
    ),
    recursive: bool = typer.Option(
        True,
        "--recursive/--no-recursive",
        help="Scan subdirectories recursively (default: True).",
    ),
) -> None:
    """Index a file, directory, or all configured sources."""
    config_path: Path | None = ctx.obj["config_path"]
    _run_index(config_path, path, source_name, force=False, recursive=recursive)


@app.command()
def reindex(
    ctx: typer.Context,
    path: Path | None = typer.Argument(
        None,
        help="File or directory to force re-index.",
    ),
    source_name: str = typer.Option("", "--source", "-s"),
) -> None:
    """Force re-index (ignores the SHA-256 hash cache)."""
    config_path: Path | None = ctx.obj["config_path"]
    _run_index(config_path, path, source_name, force=True)


def _run_index(
    config_path: Path | None,
    path: Path | None,
    source_name: str,
    force: bool,
    recursive: bool = True,
) -> None:
    """Shared logic for index / reindex commands."""
    from memorymesh.config import load_config
    from memorymesh.embeddings.sentence_transformers_provider import (
        SentenceTransformersProvider,
    )
    from memorymesh.indexer.file_indexer import FileIndexer
    from memorymesh.storage.bm25_index import BM25Index
    from memorymesh.storage.metadata_store import MetadataStore
    from memorymesh.storage.vector_store import ChromaVectorStore

    cfg = load_config(config_path)
    provider = SentenceTransformersProvider(config=cfg.embeddings)
    vector_store = ChromaVectorStore(
        db_path=cfg.storage.vector_db_path,
        embedding_model_id=provider.model_id,
    )
    metadata_store = MetadataStore(cfg.storage.metadata_db_path)
    bm25 = BM25Index(cfg.storage.bm25_pickle_path)
    bm25.load()

    indexer = FileIndexer(
        config=cfg,
        vector_store=vector_store,
        metadata_store=metadata_store,
        embedding_provider=provider,
        bm25_index=bm25,
    )

    if path is not None:
        if not path.exists():
            typer.echo(f"Path not found: {path}", err=True)
            raise typer.Exit(code=1)
        if path.is_file():
            result = indexer.index_file(path, source_name=source_name, force=force)
            typer.echo(f"{result.status}  {path}  chunks={result.n_chunks}")
        else:
            results = indexer.index_directory(
                path, source_name=source_name, recursive=recursive, force=force
            )
            _print_index_summary(results)
    else:
        if not cfg.sources:
            typer.echo("No sources configured.", err=True)
            raise typer.Exit(code=1)
        for src in cfg.sources:
            src_name = src.name or str(src.path)
            typer.echo(f"Indexing source: {src_name!r} ({src.path})")
            results = indexer.index_directory(
                src.path,
                source_name=src_name,
                recursive=src.recursive,
                extensions=src.extensions or None,
                ignore_patterns=src.ignore or None,
                force=force,
            )
            _print_index_summary(results)


def _print_index_summary(results: list) -> None:
    n_indexed = sum(1 for r in results if r.status == "indexed")
    n_skipped = sum(1 for r in results if r.status == "skipped")
    n_errors = sum(1 for r in results if r.status == "parse_error")
    n_chunks = sum(r.n_chunks for r in results)
    typer.echo(
        f"  indexed={n_indexed}  skipped={n_skipped}  "
        f"errors={n_errors}  chunks={n_chunks}"
    )
    for r in results:
        if r.status == "parse_error":
            typer.echo(f"  ERROR  {r.path}: {r.error}", err=True)


@app.command()
def search(
    ctx: typer.Context,
    query: str = typer.Argument(..., help="Search query."),
    top_k: int = typer.Option(10, "--top-k", "-k", help="Number of results.", show_default=True),
    mode: str = typer.Option(
        "hybrid",
        "--mode",
        "-m",
        help="Search mode: hybrid | dense | sparse.",
        show_default=True,
    ),
) -> None:
    """Run a search query from the terminal."""
    from memorymesh.config import load_config
    from memorymesh.embeddings.sentence_transformers_provider import (
        SentenceTransformersProvider,
    )
    from memorymesh.search.engine import SearchEngine
    from memorymesh.storage.bm25_index import BM25Index
    from memorymesh.storage.vector_store import ChromaVectorStore

    config_path: Path | None = ctx.obj["config_path"]
    cfg = load_config(config_path)

    provider = SentenceTransformersProvider(config=cfg.embeddings)
    vector_store = ChromaVectorStore(
        db_path=cfg.storage.vector_db_path,
        embedding_model_id=provider.model_id,
    )
    bm25 = BM25Index(cfg.storage.bm25_pickle_path)
    bm25.load()

    engine = SearchEngine(
        vector_store=vector_store,
        bm25_index=bm25,
        embedding_provider=provider,
        config=cfg.search,
    )

    response = engine.search(query, top_k=top_k, mode=mode)

    typer.echo(
        f"mode={response.mode}  hits={len(response.hits)}  "
        f"duration={response.duration_ms:.1f}ms\n"
    )
    for i, hit in enumerate(response.hits, start=1):
        typer.echo(f"[{i}] score={hit.score:.4f}  {hit.path}:{hit.chunk_index}")
        typer.echo(f"    {hit.preview[:120]}")
        typer.echo("")


@app.command()
def info() -> None:
    """Show version and basic system information."""
    typer.echo(f"MemoryMesh  v{__version__}")
    typer.echo("Config      : ~/.memorymesh/config.yaml  (default)")
    typer.echo("State dir   : ~/.memorymesh/")
    typer.echo(f"PID file    : {_DEFAULT_PID}  (HTTP daemon)")
    typer.echo("")
    typer.echo("Commands: start  stop  status  index  reindex  search  serve  info")
