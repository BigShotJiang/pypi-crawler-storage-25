"""File indexer — the heart of MemoryMesh.

Pipeline per file:
1. Compute SHA-256 (streaming, 64 KB chunks).
2. Compare with :class:`~memorymesh.storage.metadata_store.MetadataStore` —
   skip if hash unchanged.
3. Parse → Chunk → Embed → Upsert Chroma → Upsert SQLite (in that order so
   SQLite is only updated after Chroma succeeds).
4. On any error: log.warning + write ``parse_error`` record + continue.

Reconciliation on dirty shutdown
---------------------------------
If :meth:`MetadataStore.is_clean_state` returns ``False``, :meth:`reconcile`
removes Chroma entries not present in SQLite (orphan vectors) and queues
reindexing for SQLite entries not present in Chroma (missing vectors).
"""

from __future__ import annotations

import fnmatch
import hashlib
import os
import time
from pathlib import Path
from typing import TYPE_CHECKING

from loguru import logger

from memorymesh.core.models import (
    FileRecord,
    IndexResult,
)

if TYPE_CHECKING:
    from memorymesh.core.models import MemoryMeshConfig
    from memorymesh.embeddings.base import EmbeddingProvider
    from memorymesh.storage.bm25_index import BM25Index
    from memorymesh.storage.metadata_store import MetadataStore
    from memorymesh.storage.vector_store import VectorStore


class FileIndexer:
    """Orchestrates the full parse → chunk → embed → store pipeline.

    Args:
        config: Root configuration (used for source filters and OCR settings).
        vector_store: ChromaDB wrapper for dense vectors.
        metadata_store: SQLite metadata store (source of truth).
        embedding_provider: Converts chunk text to embeddings.
        bm25_index: Sparse BM25 index.
    """

    def __init__(
        self,
        config: MemoryMeshConfig,
        vector_store: VectorStore,
        metadata_store: MetadataStore,
        embedding_provider: EmbeddingProvider,
        bm25_index: BM25Index,
    ) -> None:
        self._config = config
        self._vector_store = vector_store
        self._metadata_store = metadata_store
        self._provider = embedding_provider
        self._bm25 = bm25_index

        # Build registries once and reuse across all files
        from memorymesh.chunking.registry import get_chunker
        from memorymesh.parsing.registry import build_registry

        self._parser_registry = build_registry(ocr_config=config.ocr)
        self._get_chunker = get_chunker

        # Ensure schema exists (idempotent — safe to call every startup)
        self._metadata_store.init_schema()

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    def startup(self) -> None:
        """Mark daemon startup in SQLite; triggers reconciliation if dirty."""
        was_clean = self._metadata_store.is_clean_state()
        self._metadata_store.mark_startup()
        if not was_clean:
            logger.warning("FileIndexer: dirty shutdown detected — starting reconciliation")
            self.reconcile()

    def shutdown(self) -> None:
        """Mark clean shutdown in SQLite."""
        self._metadata_store.mark_clean_shutdown()

    # ── Core indexing ─────────────────────────────────────────────────────────

    def index_file(
        self,
        path: Path,
        source_name: str = "",
        *,
        force: bool = False,
    ) -> IndexResult:
        """Index a single file through the full pipeline.

        Args:
            path: Absolute path to the file.
            source_name: Name of the owning source (for metadata).
            force: Skip hash comparison and always re-index.

        Returns:
            :class:`~memorymesh.core.models.IndexResult` with the outcome.
        """
        t0 = time.perf_counter()

        ext = path.suffix.lower()
        parser = self._parser_registry.get(ext)
        if parser is None:
            logger.debug(f"FileIndexer: unsupported extension {ext!r} — {path.name!r}")
            return IndexResult(
                path=path,
                status="unsupported",
                duration_ms=_elapsed_ms(t0),
            )

        try:
            stat = path.stat()
        except OSError as exc:
            logger.warning(f"FileIndexer: cannot stat {path}: {exc}")
            return IndexResult(
                path=path,
                status="parse_error",
                error=str(exc),
                duration_ms=_elapsed_ms(t0),
            )

        if not force:
            try:
                current_hash = compute_hash(path)
            except OSError as exc:
                logger.warning(f"FileIndexer: cannot hash {path}: {exc}")
                return IndexResult(
                    path=path,
                    status="parse_error",
                    error=str(exc),
                    duration_ms=_elapsed_ms(t0),
                )

            existing = self._metadata_store.get_file(str(path))
            if existing is not None and existing.sha256 == current_hash:
                logger.debug(f"FileIndexer: skipping unchanged {path.name!r}")
                return IndexResult(
                    path=path,
                    status="skipped",
                    duration_ms=_elapsed_ms(t0),
                )
        else:
            current_hash = compute_hash(path)

        # ── Parse ─────────────────────────────────────────────────────────────
        try:
            doc = parser.parse(path)
        except Exception as exc:
            logger.warning(f"FileIndexer: parse failed for {path}: {exc}")
            self._record_error(path, source_name, stat, current_hash, str(exc))
            return IndexResult(
                path=path,
                status="parse_error",
                error=str(exc),
                duration_ms=_elapsed_ms(t0),
            )

        if doc.metadata.get("error"):
            err = str(doc.metadata["error"])
            logger.warning(f"FileIndexer: parser returned error for {path.name!r}: {err}")
            self._record_error(path, source_name, stat, current_hash, err)
            return IndexResult(
                path=path,
                status="parse_error",
                error=err,
                duration_ms=_elapsed_ms(t0),
            )

        # ── Chunk ─────────────────────────────────────────────────────────────
        try:
            chunker = self._get_chunker(ext, self._config.chunking)
            chunks = chunker.chunk(doc)
        except Exception as exc:
            logger.warning(f"FileIndexer: chunking failed for {path}: {exc}")
            self._record_error(path, source_name, stat, current_hash, str(exc))
            return IndexResult(
                path=path,
                status="parse_error",
                error=str(exc),
                duration_ms=_elapsed_ms(t0),
            )

        # Attach source_root and mtime to chunks
        for chunk in chunks:
            chunk.source_root = source_name
            chunk.mtime = stat.st_mtime

        # ── Embed ─────────────────────────────────────────────────────────────
        try:
            texts = [c.text for c in chunks]
            embeddings = self._provider.embed_documents(texts)
        except Exception as exc:
            logger.warning(f"FileIndexer: embedding failed for {path}: {exc}")
            self._record_error(path, source_name, stat, current_hash, str(exc))
            return IndexResult(
                path=path,
                status="parse_error",
                error=str(exc),
                duration_ms=_elapsed_ms(t0),
            )

        # ── Upsert vector store ────────────────────────────────────────────────
        from memorymesh.core.models import ChunkWithEmbedding

        chunks_with_embeddings = [
            ChunkWithEmbedding(**chunk.model_dump(), embedding=emb)
            for chunk, emb in zip(chunks, embeddings, strict=True)
        ]

        try:
            self._vector_store.delete_by_path(str(path))
            self._vector_store.upsert(chunks_with_embeddings)
        except Exception as exc:
            logger.warning(f"FileIndexer: vector upsert failed for {path}: {exc}")
            self._record_error(path, source_name, stat, current_hash, str(exc))
            return IndexResult(
                path=path,
                status="parse_error",
                error=str(exc),
                duration_ms=_elapsed_ms(t0),
            )

        # ── Upsert BM25 ───────────────────────────────────────────────────────
        try:
            self._bm25.delete_by_path(str(path))
            self._bm25.add_chunks([
                (f"{path}:{c.chunk_index}", str(path), c.text) for c in chunks
            ])
        except Exception as exc:
            logger.warning(f"FileIndexer: BM25 update failed for {path}: {exc}")
            # Non-fatal — dense search still works

        # ── Upsert metadata (only after successful vector write) ───────────────
        record = FileRecord(
            path=str(path),
            source_name=source_name,
            sha256=current_hash,
            mtime=stat.st_mtime,
            size_bytes=stat.st_size,
            file_type=ext,
            n_chunks=len(chunks),
            status="indexed",
            indexed_at=time.time(),
            embedding_model_id=self._provider.model_id,
        )
        self._metadata_store.upsert_file(record)

        duration = _elapsed_ms(t0)
        logger.info(
            f"FileIndexer: indexed {path.name!r} "
            f"chunks={len(chunks)} duration={duration:.0f}ms"
        )
        return IndexResult(
            path=path,
            status="indexed",
            n_chunks=len(chunks),
            duration_ms=duration,
        )

    def index_directory(
        self,
        root: Path,
        source_name: str = "",
        recursive: bool = True,
        extensions: list[str] | None = None,
        ignore_patterns: list[str] | None = None,
        *,
        force: bool = False,
    ) -> list[IndexResult]:
        """Index all supported files in *root*.

        Args:
            root: Directory to scan.
            source_name: Owning source name for all files.
            recursive: Whether to descend into subdirectories.
            extensions: Whitelist of lowercase extensions.  ``None`` means all
                supported types.
            ignore_patterns: Glob patterns relative to *root* to skip.
            force: Re-index even unchanged files.

        Returns:
            List of :class:`~memorymesh.core.models.IndexResult`, one per file.
        """
        results: list[IndexResult] = []
        all_ignore = list(self._config.global_ignore) + (ignore_patterns or [])
        walker = root.rglob("*") if recursive else root.glob("*")

        for path in walker:
            if not path.is_file():
                continue
            if _should_ignore(path, root, all_ignore):
                continue
            ext = path.suffix.lower()
            if extensions and ext not in extensions:
                continue
            if ext not in self._parser_registry:
                continue

            result = self.index_file(path, source_name=source_name, force=force)
            results.append(result)

        return results

    def delete_file(self, path: Path) -> None:
        """Remove a file from all indexes.

        Args:
            path: Absolute path to the file.
        """
        str_path = str(path)
        self._vector_store.delete_by_path(str_path)
        self._bm25.delete_by_path(str_path)
        self._metadata_store.mark_deleted(str_path)
        logger.info(f"FileIndexer: deleted {path.name!r} from all indexes")

    def reconcile(self) -> None:
        """Reconcile SQLite state against ChromaDB after a dirty shutdown.

        - Entries in SQLite with status ``"indexed"`` but missing in Chroma
          → reindex.
        - Chroma chunks with no corresponding SQLite entry are tolerated for
          now (they will be cleaned up on the next full scan).
        """
        logger.info("FileIndexer: reconciliation started")
        records = self._metadata_store.list_files(status="indexed")
        reindexed = 0
        for record in records:
            path = Path(record.path)
            if not path.exists():
                self._metadata_store.mark_deleted(record.path)
                continue
            result = self.index_file(path, source_name=record.source_name, force=True)
            if result.status == "indexed":
                reindexed += 1

        logger.info(f"FileIndexer: reconciliation complete (reindexed={reindexed})")

    # ── Private helpers ───────────────────────────────────────────────────────

    def _record_error(
        self,
        path: Path,
        source_name: str,
        stat: os.stat_result,
        sha256: str,
        error: str,
    ) -> None:
        record = FileRecord(
            path=str(path),
            source_name=source_name,
            sha256=sha256,
            mtime=stat.st_mtime,
            size_bytes=stat.st_size,
            file_type=path.suffix.lower(),
            n_chunks=0,
            status="parse_error",
            error_message=error[:500],
            indexed_at=time.time(),
            embedding_model_id=self._provider.model_id,
        )
        try:
            self._metadata_store.upsert_file(record)
        except Exception as exc:
            logger.warning(f"FileIndexer: failed to write error record for {path}: {exc}")


# ── Module-level helpers ──────────────────────────────────────────────────────


def compute_hash(path: Path, chunk_size: int = 65536) -> str:
    """Compute the SHA-256 hex digest of a file using streaming reads.

    Args:
        path: Absolute path to the file.
        chunk_size: Read buffer size in bytes.

    Returns:
        Lowercase hex digest string.

    Raises:
        OSError: If the file cannot be read.
    """
    h = hashlib.sha256()
    with path.open("rb") as fh:
        while True:
            block = fh.read(chunk_size)
            if not block:
                break
            h.update(block)
    return h.hexdigest()


def _elapsed_ms(t0: float) -> float:
    return (time.perf_counter() - t0) * 1000


def _should_ignore(path: Path, root: Path, patterns: list[str]) -> bool:
    """Return True if *path* matches any of *patterns* relative to *root*."""
    try:
        rel = str(path.relative_to(root))
    except ValueError:
        rel = str(path)
    full = str(path)
    for pat in patterns:
        if fnmatch.fnmatch(rel, pat) or fnmatch.fnmatch(full, pat):
            return True
        # Support glob patterns like **/node_modules/**
        parts = path.parts
        for part in parts:
            clean_pat = pat.replace("**/", "").replace("/**", "").replace("**", "")
            if clean_pat and fnmatch.fnmatch(part, clean_pat):
                return True
    return False
