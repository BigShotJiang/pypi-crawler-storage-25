"""FastMCP application factory and AppContext definition.

``AppContext`` is a frozen dataclass that holds every dependency the MCP tools
need.  It is constructed once at startup and injected into each tool via
closure inside the ``register(mcp, ctx)`` convention.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from mcp.server.fastmcp import FastMCP

if TYPE_CHECKING:
    from memorymesh.core.models import MemoryMeshConfig
    from memorymesh.embeddings.base import EmbeddingProvider
    from memorymesh.indexer.file_indexer import FileIndexer
    from memorymesh.observability.audit import AuditLogger
    from memorymesh.search.engine import SearchEngine
    from memorymesh.storage.bm25_index import BM25Index
    from memorymesh.storage.metadata_store import MetadataStore
    from memorymesh.storage.vector_store import VectorStore


@dataclass(frozen=True)
class AppContext:
    """All runtime dependencies for the MCP server.

    Frozen so tools cannot accidentally mutate shared state.

    Args:
        config: Root MemoryMesh configuration.
        vector_store: ChromaDB wrapper for dense vectors.
        metadata_store: SQLite metadata store.
        bm25: Sparse BM25 index.
        provider: Embedding provider.
        indexer: File indexer / pipeline orchestrator.
        engine: Hybrid search engine.
        audit_logger: Append-only JSONL audit logger.
    """

    config: MemoryMeshConfig
    vector_store: VectorStore
    metadata_store: MetadataStore
    bm25: BM25Index
    provider: EmbeddingProvider
    indexer: FileIndexer
    engine: SearchEngine
    audit_logger: AuditLogger


def build_mcp(ctx: AppContext) -> FastMCP:
    """Construct and configure the FastMCP instance with all tools registered.

    Args:
        ctx: Fully initialised :class:`AppContext` with all dependencies.

    Returns:
        A :class:`~mcp.server.fastmcp.FastMCP` instance ready to serve.
    """
    mcp: FastMCP = FastMCP(
        name="memorymesh",
        instructions=(
            "MemoryMesh gives you read access to the user's personal knowledge "
            "base — local files indexed from configured source directories.  "
            "Use search_memory to find relevant passages, list_sources to "
            "explore what has been indexed, get_document to read a full file, "
            "and index_now to trigger an immediate re-index."
        ),
    )

    from memorymesh.server.tools import (
        get_document,
        index_now,
        list_sources,
        search_memory,
    )

    search_memory.register(mcp, ctx)
    list_sources.register(mcp, ctx)
    get_document.register(mcp, ctx)
    index_now.register(mcp, ctx)

    return mcp
