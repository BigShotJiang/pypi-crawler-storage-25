"""MCP tool: search_memory.

Performs hybrid (dense + sparse) or pure dense/sparse semantic search over
all indexed documents and returns ranked passages with context.
"""

from __future__ import annotations

import time
from typing import TYPE_CHECKING, Annotated

from mcp.server.fastmcp import FastMCP

if TYPE_CHECKING:
    from memorymesh.server.app import AppContext


def register(mcp: FastMCP, ctx: AppContext) -> None:
    """Register the ``search_memory`` tool on *mcp* with *ctx* injected.

    Args:
        mcp: The FastMCP instance to register onto.
        ctx: Shared application context (injected via closure).
    """

    @mcp.tool()
    def search_memory(
        query: Annotated[str, "The natural-language query to search for."],
        top_k: Annotated[int, "Maximum number of results to return (1-50)."] = 10,
        mode: Annotated[
            str,
            "Search mode: 'hybrid' (default), 'dense' (semantic only), or 'sparse' (BM25 only).",
        ] = "hybrid",
        source: Annotated[
            str | None,
            "Restrict results to a specific source name. Omit to search all sources.",
        ] = None,
    ) -> dict:
        """Search the personal knowledge base for passages relevant to *query*.

        Returns a ranked list of matching text passages with file paths,
        relevance scores, and short previews.  When ``search.parent_window_chars``
        is configured, each hit also includes an ``extended_preview`` with wider
        context around the matched chunk.

        Args:
            query: Natural-language question or phrase.
            top_k: Number of results (clamped to 1-50).
            mode: ``hybrid`` | ``dense`` | ``sparse``.
            source: Optional source name filter.
        """
        t0 = time.perf_counter()
        top_k = max(1, min(50, top_k))
        filter_: dict | None = {"source_root": source} if source else None

        response = ctx.engine.search(query, top_k=top_k, mode=mode, filter_=filter_)

        # Parent Document Retriever — expand context when configured.
        window = ctx.config.search.parent_window_chars
        if window > 0:
            from memorymesh.search.context import expand_context

            for hit in response.hits:
                extended = expand_context(hit.path, hit.start_char, hit.end_char, window)
                hit.extended_preview = extended if extended else None

        latency_ms = (time.perf_counter() - t0) * 1000
        ctx.audit_logger.log_query(
            tool="search_memory",
            query=query,
            n_results=len(response.hits),
            latency_ms=latency_ms,
        )

        return {
            "mode": response.mode,
            "duration_ms": round(response.duration_ms, 2),
            "total_hits": len(response.hits),
            "hits": [
                {
                    "path": h.path,
                    "chunk_index": h.chunk_index,
                    "score": h.score,
                    "preview": h.preview,
                    "extended_preview": h.extended_preview,
                    "file_type": h.file_type,
                    "source": h.source_root,
                }
                for h in response.hits
            ],
        }
