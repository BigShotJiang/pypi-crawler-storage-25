"""Parser registry — maps file extensions to parser instances.

Usage::

    from memorymesh.parsing.registry import get_parser

    parser = get_parser(".pdf", ocr_config=config.ocr)
    if parser is None:
        # unsupported extension
        ...
    doc = parser.parse(path)
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from memorymesh.parsing.base import Parser
from memorymesh.parsing.docx import DocxParser
from memorymesh.parsing.markdown import MarkdownParser
from memorymesh.parsing.pdf import PdfParser
from memorymesh.parsing.text import TextParser

if TYPE_CHECKING:
    from memorymesh.core.models import OcrConfig


def build_registry(ocr_config: OcrConfig | None = None) -> dict[str, Parser]:
    """Create a mapping from lowercase extension → parser instance.

    Args:
        ocr_config: OCR settings forwarded to :class:`~memorymesh.parsing.pdf.PdfParser`.

    Returns:
        Dict mapping ``".ext"`` strings to parser singletons.
    """
    parsers: list[Parser] = [
        TextParser(),
        MarkdownParser(),
        PdfParser(ocr_config=ocr_config),
        DocxParser(),
    ]
    registry: dict[str, Parser] = {}
    for parser in parsers:
        for ext in parser.supported_extensions:
            registry[ext] = parser
    return registry


def get_parser(
    extension: str,
    ocr_config: OcrConfig | None = None,
    *,
    _registry: dict[str, Parser] | None = None,
) -> Parser | None:
    """Return the parser for *extension*, or ``None`` if unsupported.

    Args:
        extension: Lowercase file extension including the dot (e.g. ``".pdf"``).
        ocr_config: Forwarded to :func:`build_registry` if no cached registry is provided.
        _registry: Pre-built registry (avoids re-instantiation in hot paths).

    Returns:
        A :class:`~memorymesh.parsing.base.Parser` or ``None``.
    """
    reg = _registry if _registry is not None else build_registry(ocr_config)
    return reg.get(extension.lower())
