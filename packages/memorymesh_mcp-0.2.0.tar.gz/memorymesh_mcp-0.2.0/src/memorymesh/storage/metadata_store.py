"""SQLite-backed metadata store for MemoryMesh.

SQLite is the **single source of truth** for the indexing state.  Every write
to ChromaDB or the BM25 pickle must be preceded by a SQLite transaction that
records the intended change, and the record is only committed *after* the
downstream write succeeds.  On startup, :meth:`MetadataStore.is_clean_state`
reveals whether the previous run shut down cleanly; if not, the daemon enters
reconciliation mode (handled by :class:`~memorymesh.indexer.file_indexer.FileIndexer`).

Schema
------
``files``       — one row per indexed (or attempted) file.
``sources``     — one row per configured source, updated on each full scan.
``index_state`` — key/value pairs for daemon lifecycle bookkeeping.

Privacy invariant: this module never logs file contents or query text — only
paths, hashes, counts, and operational events.
"""

from __future__ import annotations

import sqlite3
import sys
import time
from pathlib import Path

from loguru import logger

from memorymesh.core.models import FileRecord

_DDL = """
PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS files (
    path                TEXT PRIMARY KEY,
    source_name         TEXT NOT NULL,
    sha256              TEXT NOT NULL,
    mtime               REAL NOT NULL,
    size_bytes          INTEGER NOT NULL,
    file_type           TEXT NOT NULL,
    n_chunks            INTEGER NOT NULL DEFAULT 0,
    status              TEXT NOT NULL,
    error_message       TEXT,
    indexed_at          REAL NOT NULL,
    embedding_model_id  TEXT NOT NULL DEFAULT ''
);

CREATE INDEX IF NOT EXISTS idx_files_source ON files(source_name);
CREATE INDEX IF NOT EXISTS idx_files_status ON files(status);
CREATE INDEX IF NOT EXISTS idx_files_mtime  ON files(mtime);

CREATE TABLE IF NOT EXISTS sources (
    name                TEXT PRIMARY KEY,
    path                TEXT NOT NULL,
    recursive           INTEGER NOT NULL DEFAULT 1,
    last_full_scan_at   REAL
);

CREATE TABLE IF NOT EXISTS index_state (
    key     TEXT PRIMARY KEY,
    value   TEXT NOT NULL
);
"""

_INSERT_FILE = """
INSERT INTO files
    (path, source_name, sha256, mtime, size_bytes, file_type,
     n_chunks, status, error_message, indexed_at, embedding_model_id)
VALUES
    (:path, :source_name, :sha256, :mtime, :size_bytes, :file_type,
     :n_chunks, :status, :error_message, :indexed_at, :embedding_model_id)
ON CONFLICT(path) DO UPDATE SET
    source_name        = excluded.source_name,
    sha256             = excluded.sha256,
    mtime              = excluded.mtime,
    size_bytes         = excluded.size_bytes,
    file_type          = excluded.file_type,
    n_chunks           = excluded.n_chunks,
    status             = excluded.status,
    error_message      = excluded.error_message,
    indexed_at         = excluded.indexed_at,
    embedding_model_id = excluded.embedding_model_id;
"""


class MetadataStore:
    """CRUD interface for the MemoryMesh SQLite metadata database.

    Args:
        db_path: Absolute path to the ``.sqlite3`` file.  The parent directory
            must exist (or be created by the caller) before construction.

    The connection is opened lazily on the first operation and shared for the
    lifetime of this object.  Use :meth:`close` (or a ``with`` block) to
    release it.
    """

    def __init__(self, db_path: Path) -> None:
        self._db_path = db_path
        self._conn: sqlite3.Connection | None = None

    # ── Lifecycle ────────────────────────────────────────────────────────────

    def _connection(self) -> sqlite3.Connection:
        """Return (and lazily open) the SQLite connection."""
        if self._conn is None:
            self._db_path.parent.mkdir(parents=True, exist_ok=True)
            if sys.platform != "win32":
                try:
                    self._db_path.parent.chmod(0o700)
                except OSError as exc:
                    logger.warning(
                        f"MetadataStore: could not set permissions on "
                        f"{self._db_path.parent}: {exc}"
                    )
            self._conn = sqlite3.connect(
                str(self._db_path),
                check_same_thread=False,
            )
            self._conn.row_factory = sqlite3.Row
        return self._conn

    def init_schema(self) -> None:
        """Create all tables and indexes if they do not already exist.

        Safe to call on an existing database — all statements use
        ``CREATE … IF NOT EXISTS``.
        """
        conn = self._connection()
        conn.executescript(_DDL)
        conn.commit()
        logger.debug(f"Metadata schema initialised at {self._db_path}")

    def close(self) -> None:
        """Close the SQLite connection."""
        if self._conn is not None:
            self._conn.close()
            self._conn = None

    def __enter__(self) -> MetadataStore:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    # ── index_state helpers ──────────────────────────────────────────────────

    def get_state(self, key: str) -> str | None:
        """Return the value for *key* in ``index_state``, or ``None``."""
        row = self._connection().execute(
            "SELECT value FROM index_state WHERE key = ?", (key,)
        ).fetchone()
        return row["value"] if row else None

    def set_state(self, key: str, value: str) -> None:
        """Upsert *key* → *value* in ``index_state``."""
        self._connection().execute(
            "INSERT INTO index_state(key, value) VALUES(?, ?)"
            " ON CONFLICT(key) DO UPDATE SET value = excluded.value",
            (key, value),
        )
        self._connection().commit()

    def mark_startup(self) -> None:
        """Record that the daemon has started (not yet cleanly shut down).

        Increments the ``epoch`` counter and sets ``last_clean_shutdown`` to
        ``"false"``.  Called at daemon boot, *before* serving any requests.
        """
        epoch = int(self.get_state("epoch") or "0") + 1
        conn = self._connection()
        conn.execute(
            "INSERT INTO index_state(key, value) VALUES('epoch', ?)"
            " ON CONFLICT(key) DO UPDATE SET value = excluded.value",
            (str(epoch),),
        )
        conn.execute(
            "INSERT INTO index_state(key, value) VALUES('last_clean_shutdown', 'false')"
            " ON CONFLICT(key) DO UPDATE SET value = 'false'"
        )
        conn.commit()
        logger.debug(f"Daemon startup recorded (epoch={epoch})")

    def mark_clean_shutdown(self) -> None:
        """Record that the daemon stopped cleanly.

        Must be called during graceful shutdown *after* all in-flight indexing
        operations have completed and the BM25 pickle has been flushed.
        """
        self.set_state("last_clean_shutdown", "true")
        logger.debug("Clean shutdown recorded in index_state")

    def is_clean_state(self) -> bool:
        """Return ``True`` if the previous run shut down cleanly.

        A missing ``last_clean_shutdown`` key means this is a fresh install —
        treated as clean because there is no prior state to reconcile.
        """
        value = self.get_state("last_clean_shutdown")
        return value is None or value == "true"

    # ── files table ──────────────────────────────────────────────────────────

    def upsert_file(self, record: FileRecord) -> None:
        """Insert or update a file record.

        Args:
            record: The :class:`~memorymesh.core.models.FileRecord` to persist.
        """
        self._connection().execute(_INSERT_FILE, record.model_dump())
        self._connection().commit()

    def get_file(self, path: str) -> FileRecord | None:
        """Return the record for *path*, or ``None`` if not found.

        Args:
            path: Absolute path string (primary key).
        """
        row = self._connection().execute(
            "SELECT * FROM files WHERE path = ?", (path,)
        ).fetchone()
        return FileRecord(**dict(row)) if row else None

    def delete_file(self, path: str) -> None:
        """Hard-delete the row for *path* from the database.

        Prefer :meth:`mark_deleted` for soft-delete semantics (keeps history).

        Args:
            path: Absolute path string.
        """
        self._connection().execute("DELETE FROM files WHERE path = ?", (path,))
        self._connection().commit()

    def mark_deleted(self, path: str) -> None:
        """Set ``status = 'deleted'`` for *path* without removing the row.

        Args:
            path: Absolute path string.
        """
        self._connection().execute(
            "UPDATE files SET status = 'deleted' WHERE path = ?", (path,)
        )
        self._connection().commit()

    def mark_pending_reindex(self, path: str) -> None:
        """Set ``status = 'pending_reindex'`` — used during reconciliation.

        Args:
            path: Absolute path string.
        """
        self._connection().execute(
            "UPDATE files SET status = 'pending_reindex' WHERE path = ?", (path,)
        )
        self._connection().commit()

    def list_files(
        self,
        source_name: str | None = None,
        status: str | None = None,
    ) -> list[FileRecord]:
        """Return all file records matching the optional filters.

        Args:
            source_name: Restrict to a specific source.  ``None`` = all sources.
            status: Restrict to a specific status value.  ``None`` = all statuses.
        """
        clauses: list[str] = []
        params: list[str] = []
        if source_name is not None:
            clauses.append("source_name = ?")
            params.append(source_name)
        if status is not None:
            clauses.append("status = ?")
            params.append(status)

        where = ("WHERE " + " AND ".join(clauses)) if clauses else ""
        rows = self._connection().execute(
            f"SELECT * FROM files {where}", params
        ).fetchall()
        return [FileRecord(**dict(r)) for r in rows]

    def get_stats(self, source_name: str | None = None) -> dict[str, int]:
        """Return aggregate counts by status for a source (or all sources).

        Args:
            source_name: Restrict stats to one source.  ``None`` = all.

        Returns:
            Dict mapping status string → file count.
        """
        if source_name is not None:
            rows = self._connection().execute(
                "SELECT status, COUNT(*) as cnt FROM files"
                " WHERE source_name = ? GROUP BY status",
                (source_name,),
            ).fetchall()
        else:
            rows = self._connection().execute(
                "SELECT status, COUNT(*) as cnt FROM files GROUP BY status"
            ).fetchall()
        return {r["status"]: r["cnt"] for r in rows}

    # ── sources table ────────────────────────────────────────────────────────

    def upsert_source(
        self,
        name: str,
        path: str,
        recursive: bool,
        last_full_scan_at: float | None = None,
    ) -> None:
        """Insert or update a source record.

        Args:
            name: Source identifier (primary key).
            path: Absolute path string of the monitored directory.
            recursive: Whether the source is scanned recursively.
            last_full_scan_at: Unix timestamp of the most recent full scan.
        """
        self._connection().execute(
            "INSERT INTO sources(name, path, recursive, last_full_scan_at)"
            " VALUES(?, ?, ?, ?)"
            " ON CONFLICT(name) DO UPDATE SET"
            "   path = excluded.path,"
            "   recursive = excluded.recursive,"
            "   last_full_scan_at = COALESCE(excluded.last_full_scan_at, last_full_scan_at)",
            (name, path, int(recursive), last_full_scan_at),
        )
        self._connection().commit()

    def update_source_scan_time(self, name: str) -> None:
        """Set ``last_full_scan_at`` to the current time for *name*.

        Args:
            name: Source identifier.
        """
        self._connection().execute(
            "UPDATE sources SET last_full_scan_at = ? WHERE name = ?",
            (time.time(), name),
        )
        self._connection().commit()

    def list_sources(self) -> list[dict[str, object]]:
        """Return all source rows as plain dicts."""
        rows = self._connection().execute("SELECT * FROM sources").fetchall()
        return [dict(r) for r in rows]
