# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.2.0] - 2026-05-03

### Added
- **Parent Document Retriever** — `search_memory` returns `extended_preview` with
  wider context around each hit when `search.parent_window_chars > 0`
- `SearchConfig.parent_window_chars`; `SearchHit.start_char`, `end_char`,
  `extended_preview` fields
- `memorymesh.search.context.expand_context()` helper
- GitHub Actions CI matrix (Ubuntu / Windows / macOS × Python 3.11 / 3.12)
  with coverage gate (≥ 70 %)
- Release pipeline via OIDC Trusted Publishing — no API keys stored in GitHub
- Docker + docker-compose support for long-lived daemon mode
- Pre-commit hooks (ruff + ruff-format + standard file checks)
- `CONTRIBUTING.md`, GitHub issue templates, PR template
- Auto-generated admin shutdown token logged at WARNING when
  `MEMORYMESH_ADMIN_TOKEN` is not set

### Changed
- `BM25Index.save()` writes a SHA-256 sidecar (`.pkl.sha256`);
  `load()` verifies integrity before unpickling
- State directories under `~/.memorymesh/` get `chmod 0o700` on Unix

### Fixed
- `FileIndexer.startup()` ordering bug: `was_clean` captured before
  `mark_startup()` resets the flag
- `FileIndexer.reconcile()` now correctly re-indexes pending files

## [0.1.0] - 2026-05-01

### Added
- Four MCP tools: `search_memory`, `list_sources`, `get_document`, `index_now`
- Hybrid search engine: dense (ChromaDB + sentence-transformers) + sparse (BM25)
  fused via Reciprocal Rank Fusion (k = 60)
- Parsers: plain text, Markdown, PDF (pypdf), DOCX (python-docx); optional OCR
  via tesseract / easyocr
- Chunkers: recursive text splitter, heading-based Markdown, tree-sitter
  AST-aware code splitter
- `FileIndexer` with SHA-256 change detection, incremental updates, and
  crash-safe reconciliation on boot
- `WatcherService` (watchdog) with per-path debounce timers for live re-indexing
- stdio and streamable-HTTP transports (SSE intentionally omitted — deprecated
  June 2025)
- `memorymesh start/stop/status/index/reindex/search/info` CLI
- Append-only JSONL audit log (stores SHA-256 hash of queries, never cleartext)
- Full `config.yaml` support with Pydantic v2 validation and sane defaults

[Unreleased]: https://github.com/kilhubprojects/memory-mesh/compare/v0.2.0...HEAD
[0.2.0]: https://github.com/kilhubprojects/memory-mesh/compare/v0.1.0...v0.2.0
[0.1.0]: https://github.com/kilhubprojects/memory-mesh/releases/tag/v0.1.0
