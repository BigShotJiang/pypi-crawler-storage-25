"""
core.py — Pure lottery generation logic.
No UI, no printing, no input handling.
"""

import random
from typing import List, Tuple, Optional, Dict, Any

# Game configuration dictionary
GAMES: Dict[str, Dict[str, Any]] = {
    "powerball": {
        "name": "Powerball",
        "main_count": 5,
        "main_max": 69,
        "special_max": 26,
        "special_name": "Powerball",
    },
    "mega": {
        "name": "Mega Millions",
        "main_count": 5,
        "main_max": 70,
        "special_max": 25,
        "special_name": "Mega Ball",
    },
    "automax": {
        "name": "Automax 6/49",
        "main_count": 6,
        "main_max": 49,
        "special_max": None,
        "special_name": None,
    },
}


def generate_numbers(config: Dict[str, Any]) -> Tuple[List[int], Optional[int]]:
    """
    Generate a single lottery ticket based on the game config.
    Returns (main_numbers, special_number)
    """
    main_numbers = random.sample(range(1, config["main_max"] + 1), config["main_count"])

    special_number = None
    if config["special_max"] is not None:
        special_number = random.randint(1, config["special_max"])

    return main_numbers, special_number


def generate_multiple_tickets(
    config: Dict[str, Any], count: int
) -> List[Tuple[List[int], Optional[int]]]:
    """
    Generate multiple tickets for the selected game.
    """
    return [generate_numbers(config) for _ in range(count)]

