import pytest
from lottery_gen_pkg.core import generate_numbers, generate_multiple_tickets


def test_basic_white_ball_generation():
    config = {
        "name": "Test Game",
        "main_count": 5,
        "main_max": 10,
        "special_max": None,
        "special_name": None,
    }

    numbers, special = generate_numbers(config)

    assert len(numbers) == 5
    assert all(1 <= n <= 10 for n in numbers)
    assert special is None


def test_no_replace_logic():
    config = {
        "name": "Test Game",
        "main_count": 6,
        "main_max": 20,
        "special_max": None,
        "special_name": None,
    }

    numbers, _ = generate_numbers(config)

    # random.sample() guarantees no duplicates
    assert len(numbers) == len(set(numbers))


def test_with_special_ball():
    config = {
        "name": "Test Game",
        "main_count": 5,
        "main_max": 50,
        "special_max": 12,
        "special_name": "Special",
    }

    numbers, special = generate_numbers(config)

    assert len(numbers) == 5
    assert all(1 <= n <= 50 for n in numbers)
    assert 1 <= special <= 12


def test_generate_multiple_tickets():
    config = {
        "name": "Test Game",
        "main_count": 5,
        "main_max": 69,
        "special_max": 26,
        "special_name": "Powerball",
    }

    tickets = generate_multiple_tickets(config, 5)

    assert len(tickets) == 5

    for numbers, special in tickets:
        assert len(numbers) == 5
        assert all(1 <= n <= 69 for n in numbers)
        assert 1 <= special <= 26
