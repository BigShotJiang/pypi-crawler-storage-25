"""后台守护进程（public facade）：纯事件接力，不做决策。

两个核心职责：
1. Stop   — Worker 完成 → 通知 Supervisor
2. Silent — JSONL 心跳停跳（3 分钟无写入）→ 通知 Supervisor

Plus: Reviewer 事件路由、mission 同步、async hooks、idle 检测。

Implementation is split across `keep._daemon.*` sub-modules by responsibility
(constants, runtime_state, xml_format, notify, review, worker_check,
idle, loop). This module re-exports the public API unchanged; external
callers should keep importing from `keep.daemon`.

Test helpers (`_build_event_xml`, `_format_silent_msg`, `_check_worker`, …) are
re-exported under their historical underscore-prefixed names so existing
`test_daemon_silent.py` imports continue to resolve.

`get_terminal` is rebound here so tests that do
`monkeypatch.setattr("keep.daemon.get_terminal", fake)` continue to work; the
actual call site in `_daemon.notify` reads the attribute dynamically from
`keep.terminal`.
"""

from __future__ import annotations

# ── Constants (timing, signal files, event types, logger) ─────────
from keep._daemon.constants import (
    EV_MISSION_STOP,
    EV_TASK_PROPOSED_REVIEW,
    EV_TASK_SUBMITTED_REVIEW,
    IDLE_TIMEOUT,
    LOG_FILE,
    MIN_NOTIFY_INTERVAL,
    POLL_INTERVAL,
    REPLY_INLINE_LIMIT,
    RUNTIME_STATE_FILE,
    SILENT_MAX_COUNT,
    SILENT_SUSPEND_HINT_AT,
    SILENT_TIMEOUT,
    log,
    mission_stop_signal_file,
    mission_sync_signal_file,
    stop_file,
)
from keep._daemon.loop import run_daemon

# Test-facing re-exports (historical underscore-prefixed names). Keep these
# even if tests currently look stale — the explicit export surface is our
# contract, and yanking them silently would make future bug investigations
# harder.
from keep._daemon.notify import (
    notify_all_reviewers,
    notify_reviewer,
    notify_supervisor,
    send_to_surface as _send_to_surface,
    sync_mission_to_reviewers,
)
from keep._daemon.runtime_state import (
    first_stop_suppressed as _first_stop_suppressed,
    last_notify as _last_notify,
    last_silent as _last_silent,
    load as _load_runtime_state,
    pending_stop_event as _pending_stop_event,
    idle_fired as _idle_fired,
    idle_since as _idle_since,
    review_dispatched as _review_dispatched,
    save as _save_runtime_state,
    silent_closed as _silent_closed,
    silent_count as _silent_count,
)
from keep._daemon.worker_check import check_worker as _check_worker
from keep._daemon.xml_format import (
    build_event_xml as _build_event_xml,
    build_review_summary as _build_review_summary,
    format_aggregated_silent_msg as _format_aggregated_silent_msg,
    format_review_request_msg as _format_review_request_msg,
    format_silent_msg as _format_silent_msg,
    format_stop_msg as _format_stop_msg,
)

# Rebind imports that tests/conftest monkeypatch on this module.
from keep.terminal import get_terminal  # conftest patches this name


def __getattr__(name: str):
    # Historical re-export: keep `from keep.daemon import STATE_DIR` working
    # while routing every lookup through the env-driven paths module.
    if name == "STATE_DIR":
        from keep._state import paths as _paths
        return _paths.STATE_DIR
    raise AttributeError(f"module 'keep.daemon' has no attribute {name!r}")


__all__ = [
    # Timing / policy constants
    "POLL_INTERVAL",
    "MIN_NOTIFY_INTERVAL",
    "SILENT_TIMEOUT",
    "SILENT_MAX_COUNT",
    "SILENT_SUSPEND_HINT_AT",
    "REPLY_INLINE_LIMIT",
    "IDLE_TIMEOUT",
    # Paths + signal files
    "LOG_FILE",
    "RUNTIME_STATE_FILE",
    "STATE_DIR",
    "mission_stop_signal_file",
    "mission_sync_signal_file",
    "stop_file",
    # Logger
    "log",
    # Terminal (patched by conftest)
    "get_terminal",
    # Notify
    "notify_supervisor",
    "notify_reviewer",
    "notify_all_reviewers",
    "sync_mission_to_reviewers",
    # Main entry
    "run_daemon",
]
