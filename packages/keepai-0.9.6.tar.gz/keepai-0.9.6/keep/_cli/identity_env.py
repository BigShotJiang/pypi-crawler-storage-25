"""Participant environment helpers for keep-managed agent sessions.

These env vars are injected into spawned participant processes so the process
can later self-identify when it calls back into `keep` via the CLI.
"""

from __future__ import annotations

import os
import shlex
from dataclasses import dataclass

import typer

ENV_KEEP_AGENT_TYPE = "KEEP_AGENT_TYPE"
ENV_KEEP_LAUNCH_TOKEN = "KEEP_LAUNCH_TOKEN"
ENV_KEEP_MISSION_ID = "KEEP_MISSION_ID"
ENV_KEEP_PARTICIPANT_SESSION = "KEEP_PARTICIPANT_SESSION"
ENV_KEEP_REVIEWER_ID = "KEEP_REVIEWER_ID"
ENV_KEEP_ROLE = "KEEP_ROLE"


@dataclass(frozen=True)
class KeepProcessIdentity:
    mission_id: str | None = None
    role: str | None = None
    participant_session: str | None = None
    reviewer_id: str | None = None
    launch_token: str | None = None
    agent_type: str | None = None

    def has_keep_env(self) -> bool:
        return any(
            value
            for value in (
                self.mission_id,
                self.role,
                self.participant_session,
                self.reviewer_id,
                self.launch_token,
                self.agent_type,
            )
        )


def current_keep_identity() -> KeepProcessIdentity:
    return KeepProcessIdentity(
        mission_id=os.environ.get(ENV_KEEP_MISSION_ID) or None,
        role=os.environ.get(ENV_KEEP_ROLE) or None,
        participant_session=os.environ.get(ENV_KEEP_PARTICIPANT_SESSION) or None,
        reviewer_id=os.environ.get(ENV_KEEP_REVIEWER_ID) or None,
        launch_token=os.environ.get(ENV_KEEP_LAUNCH_TOKEN) or None,
        agent_type=os.environ.get(ENV_KEEP_AGENT_TYPE) or None,
    )


def build_participant_env(
    *,
    mission_id: str,
    role: str,
    participant_session: str,
    agent_type: str,
    reviewer_id: str | None = None,
) -> dict[str, str]:
    env = {
        ENV_KEEP_MISSION_ID: mission_id,
        ENV_KEEP_ROLE: role,
        ENV_KEEP_PARTICIPANT_SESSION: participant_session,
        ENV_KEEP_AGENT_TYPE: agent_type,
    }
    if reviewer_id is not None:
        env[ENV_KEEP_REVIEWER_ID] = reviewer_id
    return env


def with_launch_token(env: dict[str, str] | None, launch_token: str) -> dict[str, str]:
    merged = dict(env or {})
    merged[ENV_KEEP_LAUNCH_TOKEN] = launch_token
    return merged


def shell_env_prefix(env: dict[str, str] | None) -> str:
    if not env:
        return ""
    return " ".join(f"{key}={shlex.quote(value)}" for key, value in env.items()) + " "


def resolve_current_participant_session(
    mission_id: str,
    *,
    role: str,
) -> str | None:
    ident = current_keep_identity()
    if not ident.has_keep_env():
        return None
    if ident.role != role:
        typer.echo(
            f"当前 keep participant role={ident.role or 'unknown'}，需要 {role} 环境变量。",
            err=True,
        )
        raise typer.Exit(1)
    if ident.mission_id != mission_id:
        typer.echo(
            f"当前 keep participant 属于 mission '{ident.mission_id or 'unknown'}'，"
            f"不是 '{mission_id}'。",
            err=True,
        )
        raise typer.Exit(1)
    if not ident.participant_session:
        typer.echo(
            f"当前 {role} session 缺少 {ENV_KEEP_PARTICIPANT_SESSION}，"
            "请获取正确环境变量后重启该 participant。",
            err=True,
        )
        raise typer.Exit(1)
    return ident.participant_session


def resolve_current_reviewer_id(mission_id: str) -> str | None:
    ident = current_keep_identity()
    if not ident.has_keep_env():
        return None
    if ident.role != "reviewer":
        typer.echo(
            f"当前 keep participant role={ident.role or 'unknown'}，需要 reviewer 环境变量。",
            err=True,
        )
        raise typer.Exit(1)
    if ident.mission_id != mission_id:
        typer.echo(
            f"当前 keep participant 属于 mission '{ident.mission_id or 'unknown'}'，"
            f"不是 '{mission_id}'。",
            err=True,
        )
        raise typer.Exit(1)
    if not ident.reviewer_id:
        typer.echo(
            f"当前 reviewer session 缺少 {ENV_KEEP_REVIEWER_ID}，"
            "请获取正确环境变量后重启该 reviewer。",
            err=True,
        )
        raise typer.Exit(1)
    return ident.reviewer_id
