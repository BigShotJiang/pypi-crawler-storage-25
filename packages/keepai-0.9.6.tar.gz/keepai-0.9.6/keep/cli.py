"""Mission CLI — command model v2 (public facade).

Wires the `typer` app tree:

    keep self <show|start|stop|reset|config>
    keep mission <create|update|remove|list|show|start|stop|pause|resume>
    keep <mission_id> <task|worker|supervisor|reviewer> <verb> ...

Command bodies delegate to `keep._cli.*` sub-modules organised by
responsibility. See `keep/_cli/__init__.py` for the split rationale. Any
test that used to patch `keep.cli.<helper>` should now patch
`keep._cli.<module>.<helper>` (the symbol actually used at call time).
"""

from __future__ import annotations

import logging
import os
import signal
import sys
import time
from importlib.metadata import version as _pkg_version
from pathlib import Path

import click
import typer
from typer.core import TyperGroup

_log = logging.getLogger("keep.cli")

from keep.agent_types import normalize_agent_type
from keep._cli.constants import (
    CREATE_HELP,
    MISSION_HELP,
    MISSION_SCOPED_HELP,
    OLD_ROOT_COMMANDS,
    _HELP,
)
from keep._cli.dispatch import dispatch_mission_scoped
from keep._cli.helpers import (
    format_timestamp,
    generate_mission_id,
    is_daemon_running,
    load_keep_config,
    require_global,
    require_mission_by_name,
    save_keep_config,
)
from keep._daemon.constants import (
    EV_MISSION_STOP,
    EV_TASK_PROPOSED_REVIEW,
    EV_TASK_SUBMITTED_REVIEW,
)
from keep._daemon.review import cancel_pending_mission_stop
from keep._cli import spawn as _spawn_mod
from keep._cli.spawn import (
    check_stop_hook_or_fail,
    launch_daemon,
)
from keep.state import (
    DEFAULT_TERMINAL,
    VALID_TERMINALS,
    create_mission,
    delete_all,
    delete_mission,
    find_supervisor,
    get_review_event,
    iter_reviewers,
    iter_workers,
    list_missions,
    list_tasks,
    load_global,
    load_mission,
    messages_dir,
    mission_terminal_type,
    mutate_mission,
    new_global,
    resolve_content,
    save_global,
    save_mission,
    task_store_dir,
)
from keep._state.participants import participant_agent_type


_REQUIRED_REVIEW_EVENTS = (
    EV_TASK_PROPOSED_REVIEW,
    EV_TASK_SUBMITTED_REVIEW,
    EV_MISSION_STOP,
)
_REVIEW_EVENT_LABELS = {
    EV_TASK_PROPOSED_REVIEW: "task_proposed_review",
    EV_TASK_SUBMITTED_REVIEW: "task_submitted_review",
    EV_MISSION_STOP: "mission_stop",
}


# ── typer app wiring ──────────────────────────────────────────


class RootGroup(TyperGroup):
    def parse_args(self, ctx: click.Context, args: list[str]) -> list[str]:
        if args and args[0].startswith("-"):
            return super().parse_args(ctx, args)
        if args and args[0] not in self.commands and args[0] not in {"-h", "--help"}:
            ctx.meta["mission_scoped_args"] = list(args)
            return []
        return super().parse_args(ctx, args)


class MissionGroup(TyperGroup):
    def parse_args(self, ctx: click.Context, args: list[str]) -> list[str]:
        if args and args[0] in MISSION_SCOPED_HELP and args[0] not in self.commands:
            ctx.meta["mission_help_args"] = list(args)
            return []
        return super().parse_args(ctx, args)


# Non-interactive: disable Rich panels (errors fall back to Click plain text)
_rich_markup_mode = None if not sys.stdout.isatty() else "rich"

app = typer.Typer(
    cls=RootGroup,
    help=_HELP,
    context_settings={"help_option_names": ["-h", "--help"]},
    invoke_without_command=True,
    no_args_is_help=True,
    rich_markup_mode=_rich_markup_mode,
)
self_app = typer.Typer(help="keep 系统管理", rich_markup_mode=_rich_markup_mode)
mission_app = typer.Typer(
    cls=MissionGroup,
    help=MISSION_HELP,
    invoke_without_command=True,
    rich_markup_mode=_rich_markup_mode,
)
config_app = typer.Typer(help="Global keep configuration", rich_markup_mode=_rich_markup_mode)
app.add_typer(self_app, name="self")
app.add_typer(mission_app, name="mission")
app.add_typer(config_app, name="config")


def _version_callback(value: bool) -> None:
    if value:
        for _dist in ("keepai", "keep"):
            try:
                typer.echo(_pkg_version(_dist))
                break
            except Exception:
                pass
        raise typer.Exit()


@app.callback()
def main(
    ctx: typer.Context,
    version: bool = typer.Option(
        False, "--version", "-V", "-v",
        callback=_version_callback, is_eager=True, help="显示版本",
    ),
) -> None:
    if ctx.invoked_subcommand is not None:
        return

    scoped_args = ctx.meta.get("mission_scoped_args")
    if not scoped_args:
        return

    mission_id = scoped_args[0]
    rest = scoped_args[1:]

    allow_discovery_help = mission_id in MISSION_SCOPED_HELP and (
        not rest
        or rest in (["--help"], ["-h"])
        or (len(rest) == 2 and rest[0] == "create" and rest[1] in {"--help", "-h"})
    )
    if mission_id in OLD_ROOT_COMMANDS and not allow_discovery_help:
        typer.echo(f"No such command '{mission_id}'", err=True)
        raise typer.Exit(2)

    # Discoverability: allow mission-scoped help without a concrete mission_id,
    # e.g. `keep task --help`, while root subjects remain only self/mission.
    if mission_id in MISSION_SCOPED_HELP:
        if not rest or rest == ["--help"] or rest == ["-h"]:
            typer.echo(MISSION_SCOPED_HELP[mission_id])
            raise typer.Exit()
        if len(rest) == 2 and rest[0] == "create" and rest[1] in {"--help", "-h"} and mission_id in CREATE_HELP:
            typer.echo(CREATE_HELP[mission_id])
            raise typer.Exit()

    if not rest:
        typer.echo(f"Mission '{mission_id}' requires a scoped command", err=True)
        raise typer.Exit(2)

    subject = rest[0]
    if len(rest) == 2 and rest[1] in {"--help", "-h"} and subject in MISSION_SCOPED_HELP:
        typer.echo(MISSION_SCOPED_HELP[subject])
        raise typer.Exit()
    if len(rest) == 3 and rest[2] in {"--help", "-h"} and subject in CREATE_HELP and rest[1] == "create":
        typer.echo(CREATE_HELP[subject])
        raise typer.Exit()

    dispatch_mission_scoped(mission_id, rest)


@mission_app.callback()
def mission_main(ctx: typer.Context) -> None:
    if ctx.invoked_subcommand is not None:
        return

    help_args = ctx.meta.get("mission_help_args")
    if not help_args:
        return

    subject = help_args[0]
    if len(help_args) == 2 and help_args[1] in {"--help", "-h"} and subject in MISSION_SCOPED_HELP:
        typer.echo(MISSION_SCOPED_HELP[subject])
        raise typer.Exit()
    if len(help_args) == 3 and help_args[2] in {"--help", "-h"} and subject in CREATE_HELP and help_args[1] == "create":
        typer.echo(CREATE_HELP[subject])
        raise typer.Exit()
    typer.echo(f"No such command '{subject}'", err=True)
    raise typer.Exit(2)


# ── self ──────────────────────────────────────────────────────


@self_app.command("start")
def self_start(
    foreground: bool = typer.Option(False, "-f", "--foreground", help="前台运行 daemon"),
) -> None:
    global_state = load_global()
    if global_state is None:
        global_state = new_global()
        save_global(global_state)
    if is_daemon_running(global_state):
        typer.echo("Daemon 已在运行", err=True)
        raise typer.Exit(1)
    launch_daemon(global_state, foreground)


@self_app.command("stop")
def self_stop() -> None:
    global_state = require_global()
    daemon_pid = global_state.get("daemon_pid")
    if daemon_pid:
        try:
            os.kill(daemon_pid, signal.SIGTERM)
        except (ProcessLookupError, TypeError):
            pass
    global_state["daemon_pid"] = None
    global_state["stopped"] = True
    save_global(global_state)
    typer.echo("Keep 已停止。")


@self_app.command("show")
def self_show() -> None:
    global_state = load_global()
    if global_state is None:
        typer.echo("Keep 未启动。")
        return

    daemon_running = is_daemon_running(global_state)
    if global_state.get("stopped"):
        state_label = "已锁定 (stopped)"
    elif daemon_running:
        state_label = "运行中"
    else:
        state_label = "异常 (daemon 未运行)"

    lines = [f"状态: {state_label}"]
    pid = global_state.get("daemon_pid")
    if pid:
        lines.append(f"Daemon PID: {pid}" + (" (运行中)" if daemon_running else " (已退出)"))

    missions = []
    for name in list_missions():
        mission = load_mission(name)
        if mission is None:
            continue
        missions.append((name, mission))

    if not missions:
        lines.append("")
        lines.append("没有 mission。用 keep mission create 创建（ID 自动生成）。")
    else:
        lines.append("")
        for name, mission in missions:
            workers = [worker["session"] for worker in iter_workers(mission)]
            supervisor = find_supervisor(mission)
            tasks = list_tasks(name)
            done = sum(1 for task in tasks if task["status"] == "completed")
            running = sum(1 for task in tasks if task["status"] == "in_progress")
            pending = sum(1 for task in tasks if task["status"] == "pending")
            workers_text = ", ".join(workers) if workers else "无"
            supervisor_text = supervisor["session"] if supervisor else "(unclaimed)"
            lines.append(
                f"  {name} — supervisor: {supervisor_text} | workers: {workers_text} | tasks: {done} done, {running} running, {pending} pending ({len(tasks)} total)"
            )

    typer.echo("\n".join(lines))


@self_app.command("reset")
def self_reset() -> None:
    global_state = require_global()

    # Step 1: best-effort close every participant's terminal surface while the
    # daemon is still alive. Mirrors `mission_remove`'s teardown path; we delegate
    # to `kill_and_close_worker` rather than re-implementing close logic.
    for mission_id in list_missions():
        try:
            mission = load_mission(mission_id)
        except Exception as exc:
            _log.warning("self reset: failed to load mission %r, skipping surface close: %s", mission_id, exc)
            continue
        if mission is None:
            continue
        supervisor = find_supervisor(mission)
        if supervisor:
            _spawn_mod.kill_and_close_worker(supervisor, mission)
        for worker in iter_workers(mission):
            _spawn_mod.kill_and_close_worker(worker, mission)
        try:
            reviewers = list(iter_reviewers(mission_id))
        except ValueError as exc:
            _log.warning("self reset: failed to iter reviewers for %r: %s", mission_id, exc)
            reviewers = []
        for reviewer in reviewers:
            _spawn_mod.kill_and_close_worker(reviewer, mission)

    # Step 2: terminate daemon so it can't race us while we clear state below.
    daemon_pid = global_state.get("daemon_pid")
    if daemon_pid:
        try:
            os.kill(daemon_pid, signal.SIGTERM)
        except (ProcessLookupError, TypeError):
            pass

    # Step 3: wipe mission + global state.
    delete_all()

    # Step 4: `delete_all()` doesn't touch daemon runtime state — remove it here
    # so a fresh daemon starts with an empty in-memory model.
    from keep._daemon.constants import RUNTIME_STATE_FILE
    RUNTIME_STATE_FILE.unlink(missing_ok=True)

    typer.echo("Keep 已重置，所有状态已清除。")


@self_app.command("config")
def self_config(
    terminal: str = typer.Option(..., "--terminal", help="Terminal type: cmux, tmux, terminal, kitty, iterm2"),
) -> None:
    """Configure keep settings (e.g. default terminal)."""
    if terminal not in VALID_TERMINALS:
        typer.echo(f"Invalid terminal '{terminal}'. Choose from: {', '.join(sorted(VALID_TERMINALS))}", err=True)
        raise typer.Exit(1)
    config = load_keep_config()
    config["terminal"] = terminal
    save_keep_config(config)
    typer.echo(f"✓ Terminal set to: {terminal}")
    prereqs = {
        "cmux": "CMUX: Settings → Socket Control → set to 'Automation Mode'",
        "tmux": "TMUX: no prerequisites",
        "terminal": "Terminal.app: System Settings → Privacy → Accessibility (grant permission to your shell/terminal)",
        "kitty": "Kitty: add 'allow_remote_control yes' and 'listen_on unix:/tmp/kitty.sock' to ~/.config/kitty/kitty.conf",
        "iterm2": "iTerm2: System Settings → Privacy → Automation (grant permission to your shell/terminal to control iTerm)",
    }
    typer.echo(f"Prerequisites: {prereqs[terminal]}")


# ── config ────────────────────────────────────────────────────


_CONFIG_SUPPORTED_KEYS = {"workers_enabled"}


@config_app.command("get")
def config_get(
    key: str = typer.Argument(..., help="Config key (e.g. workers_enabled)"),
) -> None:
    """Print the current global config value for a key."""
    from keep._state.config import get_global_config
    if key not in _CONFIG_SUPPORTED_KEYS:
        typer.echo(f"Unknown config key '{key}'. Supported: {', '.join(sorted(_CONFIG_SUPPORTED_KEYS))}", err=True)
        raise typer.Exit(1)
    config = get_global_config()
    if key == "workers_enabled":
        value = config.get(key, True)  # default True
        typer.echo(str(value).lower())


@config_app.command("set")
def config_set(
    key: str = typer.Argument(..., help="Config key (e.g. workers_enabled)"),
    value: str = typer.Argument(..., help="Value (e.g. true or false)"),
) -> None:
    """Set a global config value."""
    from keep._state.config import set_global_config
    if key not in _CONFIG_SUPPORTED_KEYS:
        typer.echo(f"Unknown config key '{key}'. Supported: {', '.join(sorted(_CONFIG_SUPPORTED_KEYS))}", err=True)
        raise typer.Exit(1)
    if key == "workers_enabled":
        lower = value.lower()
        if lower not in {"true", "false", "1", "0", "yes", "no"}:
            typer.echo(f"Invalid value '{value}' for workers_enabled. Use: true or false", err=True)
            raise typer.Exit(1)
        bool_value = lower in {"true", "1", "yes"}
        set_global_config(key, bool_value)
        typer.echo(f"workers_enabled = {str(bool_value).lower()}")


# ── mission ───────────────────────────────────────────────────


@mission_app.command("create")
def mission_create(
    terminal: str = typer.Option("", "--terminal", help="Terminal type: cmux|tmux|terminal|kitty|iterm2"),
    no_workers: bool = typer.Option(False, "--no-workers", help="Disable workers for this mission (workers_enabled=false)"),
) -> None:
    require_global()
    # Resolve terminal: explicit flag > global config > default
    if terminal:
        if terminal not in VALID_TERMINALS:
            typer.echo(f"Invalid terminal '{terminal}'. Choose from: {', '.join(sorted(VALID_TERMINALS))}", err=True)
            raise typer.Exit(1)
        resolved_terminal = terminal
    else:
        resolved_terminal = load_keep_config().get("terminal", DEFAULT_TERMINAL)
    mission_id = generate_mission_id()
    workers_enabled_flag: bool | None = False if no_workers else None
    try:
        create_mission(mission_id, terminal_type=resolved_terminal, workers_enabled=workers_enabled_flag)
    except ValueError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1)
    suffix = " (workers_enabled=false)" if no_workers else ""
    typer.echo(f"Mission '{mission_id}' 已创建。(terminal: {resolved_terminal}){suffix}")


@mission_app.command("update")
def mission_update(
    mission_id: str = typer.Argument(...),
    prompt: str = typer.Argument(""),
    terminal: str = typer.Option("", "--terminal", help="Change terminal type: cmux|tmux|terminal|kitty|iterm2"),
) -> None:
    require_global()
    require_mission_by_name(mission_id)
    if not prompt and not terminal:
        typer.echo("Nothing to update. Provide a prompt or --terminal.", err=True)
        raise typer.Exit(1)
    if terminal and terminal not in VALID_TERMINALS:
        typer.echo(f"Invalid terminal '{terminal}'. Choose from: {', '.join(sorted(VALID_TERMINALS))}", err=True)
        raise typer.Exit(1)
    with mutate_mission(mission_id) as mission:
        if prompt:
            mission["mission_prompt"] = prompt
        if terminal:
            mission["terminal_type"] = terminal
    typer.echo(f"Mission '{mission_id}' 已更新。")
    # Signal daemon to sync updated mission to reviewers
    from keep.daemon import mission_sync_signal_file
    mission_sync_signal_file(mission_id).write_text("")


@mission_app.command("remove")
def mission_remove(mission_id: str = typer.Argument(...)) -> None:
    require_global()
    mission = load_mission(mission_id)
    worker_sessions: list[str] = []
    if mission is not None:
        supervisor = find_supervisor(mission)
        if supervisor:
            worker_sessions.append(supervisor["session"])
            _spawn_mod.kill_and_close_worker(supervisor, mission)
            typer.echo(f"  Supervisor {supervisor['session'][:8]} closed")
        workers = list(iter_workers(mission))
        if workers:
            worker_sessions.extend(w["session"] for w in workers)
            for w in workers:
                _spawn_mod.kill_and_close_worker(w, mission)
            typer.echo(f"  {len(workers)} worker{'s' if len(workers) > 1 else ''} closed")
        reviewers = list(iter_reviewers(mission_id))
        if reviewers:
            for r in reviewers:
                if r.get("session"):
                    worker_sessions.append(r["session"])
                _spawn_mod.kill_and_close_worker(r, mission)
                typer.echo(f"  Reviewer {r.get('name', r['id'])} ({r['id'][:8]}) closed")
        ref = mission.get("terminal_container")
        if ref:
            try:
                from keep.terminal import get_terminal
                get_terminal(mission_terminal_type(mission)).close_mission_container(ref)
            except Exception as exc:
                _log.warning("close_mission_container %r: %s", ref, exc)
    if not delete_mission(mission_id):
        typer.echo(f"Mission '{mission_id}' 不存在", err=True)
        raise typer.Exit(1)
    from keep._daemon import runtime_state as _rt
    _rt.purge_mission(mission_id, worker_sessions)
    typer.echo(f"  Mission {mission_id} deleted")


@mission_app.command("list")
@mission_app.command("ls")
def mission_list() -> None:
    require_global()
    names = list_missions()
    if not names:
        typer.echo("没有 mission。")
        return
    lines = ["Missions:"]
    for name in names:
        mission = load_mission(name)
        if mission is None:
            continue
        task_count = len(list_tasks(name))
        lines.append(f"  {name} — {len(iter_workers(mission))} workers, {task_count} tasks")
    typer.echo("\n".join(lines))


@mission_app.command("show")
def mission_show(mission_id: str = typer.Argument(...)) -> None:
    require_global()
    mission = require_mission_by_name(mission_id)
    lines = [f"Mission '{mission_id}':"]
    lines.append(f"  状态: {mission['status']}")
    lines.append(f"  Terminal: {mission_terminal_type(mission)}")
    lines.append(f"  创建时间: {format_timestamp(mission.get('created_at'))}")
    prompt = mission.get("mission_prompt")
    lines.append(f"  Prompt: {resolve_content(prompt) if prompt else '(未设置)'}")
    lines.append(f"  Tasks dir: {task_store_dir(mission_id)}")
    typer.echo("\n".join(lines))


@mission_app.command("start")
def mission_start(mission_id: str = typer.Argument(...)) -> None:
    require_global()
    mission = require_mission_by_name(mission_id)

    # Pre-flight: verify stop hook is wired up
    # Pre-flight checks: require supervisor AND at least one reviewer
    supervisor = find_supervisor(mission)
    try:
        reviewers = list(iter_reviewers(mission_id))
    except ValueError:
        reviewers = []

    missing: list[str] = []
    if not supervisor:
        missing.append(
            f"  注册 Supervisor: keep {mission_id} supervisor create --name <session>"
        )
    if not reviewers:
        missing.append(
            f"  添加 Reviewer:   keep {mission_id} reviewer create --name <name>"
        )
    else:
        missing_review_events = _missing_review_events(reviewers)
        for event_type in missing_review_events:
            label = _REVIEW_EVENT_LABELS[event_type]
            missing.append(
                f"  Reviewer 覆盖缺失: {label} 需要至少一个 reviewer 处理"
            )
    if missing:
        typer.echo(
            f"Mission '{mission_id}' 无法启动：需要 Supervisor，且 3 个 review 事件都至少有一个 reviewer 覆盖。\n"
            + "\n".join(missing),
            err=True,
        )
        raise typer.Exit(1)

    agent_types = {
        participant_agent_type(supervisor),
        *(normalize_agent_type(r.get("agent_type")) for r in reviewers),
    }
    check_stop_hook_or_fail(agent_types)

    mission["status"] = "active"
    save_mission(mission_id, mission)
    cancel_pending_mission_stop(mission_id)
    typer.echo(f"Mission '{mission_id}' 已启动。\n")

    issues: list[str] = []

    sup_label = supervisor.get("name") or supervisor.get("session", "?")
    typer.secho(f"  ✓ Supervisor: {sup_label}", fg=typer.colors.GREEN)

    if reviewers:
        reviewer_labels = ", ".join(r.get("name") or r.get("id", "?") for r in reviewers)
        typer.secho(f"  ✓ Reviewers ({len(reviewers)}): {reviewer_labels}", fg=typer.colors.GREEN)
        coverage = _review_event_coverage(reviewers)
        coverage_summary = "; ".join(
            f"{_REVIEW_EVENT_LABELS[event_type]}="
            + ",".join(coverage[event_type])
            for event_type in _REQUIRED_REVIEW_EVENTS
        )
        typer.secho(f"  ✓ Review Coverage: {coverage_summary}", fg=typer.colors.GREEN)
    else:
        typer.secho("  ✗ Reviewers: 无", fg=typer.colors.YELLOW)
        issues.append(f"无 Reviewer——task 送审后无人判决。添加：keep {mission_id} reviewer create --name <name>")

    workers = iter_workers(mission)
    if workers:
        labels = ", ".join(w.get("name") or w.get("session", "?") for w in workers)
        typer.secho(f"  ✓ Workers ({len(workers)}): {labels}", fg=typer.colors.GREEN)
    else:
        typer.secho("  ✗ Workers: 无", fg=typer.colors.YELLOW)
        issues.append("无 Worker——无法执行任务")

    tasks = list_tasks(mission_id)
    pending = [t for t in tasks if t.get("status") not in {"completed", "deleted"}]
    if tasks:
        typer.secho(f"  ✓ Tasks: {len(pending)} pending / {len(tasks)} total", fg=typer.colors.GREEN)
    else:
        typer.secho("  ✗ Tasks: 无", fg=typer.colors.YELLOW)
        issues.append("Task 队列为空——Supervisor 收到 start 后无任务可推进")

    if issues:
        typer.echo("")
        for issue in issues:
            typer.secho(f"  ⚠  {issue}", fg=typer.colors.YELLOW)


@mission_app.command("stop")
def mission_stop(
    mission_id: str = typer.Argument(...),
    rationale: str | None = typer.Option(None, "--rationale", help="停止原因文件路径（说明 mission 为何完成）"),
    force: bool = typer.Option(False, "--force", help="跳过 reviewer 审批，直接强制停止"),
) -> None:
    require_global()
    mission = require_mission_by_name(mission_id)

    if force:
        mission["status"] = "stopped"
        save_mission(mission_id, mission)
        cancel_pending_mission_stop(mission_id)
        typer.echo(f"Mission '{mission_id}' 已强制停止。")
        return

    # When reviewers are configured, delegate stop decision to daemon/reviewers.
    try:
        reviewers = list(iter_reviewers(mission_id))
    except ValueError:
        reviewers = []

    if reviewers and mission.get("status") != "stopped":
        if EV_MISSION_STOP in _missing_review_events(reviewers):
            typer.echo(
                f"Mission '{mission_id}' 无法 stop：没有 reviewer 覆盖 mission_stop。",
                err=True,
            )
            raise typer.Exit(1)
        _mission_stop_with_review(mission_id, rationale)
        return

    # No reviewers or already stopped — stop immediately.
    mission["status"] = "stopped"
    save_mission(mission_id, mission)
    typer.echo(f"Mission '{mission_id}' 已停止。")


def _mission_stop_with_review(mission_id: str, rationale: str | None) -> None:
    """Send stop decision through reviewer(s); block until final verdict."""
    from keep.daemon import mission_stop_signal_file
    signal_path = mission_stop_signal_file(mission_id)
    signal_path.write_text(rationale or "", encoding="utf-8")
    typer.echo(f"Mission '{mission_id}' stop 已送审，等待 reviewer 判决…")
    deadline = time.time() + 1800
    event_id: str | None = None
    while time.time() < deadline:
        time.sleep(2)
        m = load_mission(mission_id)
        if m is None:
            raise typer.Exit(1)
        if m.get("status") == "stopped":
            typer.echo(f"Reviewer 已通过。Mission '{mission_id}' 已停止。")
            raise typer.Exit()
        for ev in reversed(m.get("review_events", [])):
            if ev.get("type") == "mission_stop":
                event_id = ev.get("id")
                break
        if event_id:
            break
    if not event_id:
        typer.echo("超时：reviewer 未在 30 分钟内创建审批事件。", err=True)
        raise typer.Exit(1)
    while time.time() < deadline:
        ev = get_review_event(mission_id, event_id)
        if ev and ev.get("final_verdict"):
            verdict = ev["final_verdict"]
            if verdict == "approved":
                typer.echo(f"Reviewer 已通过。Mission '{mission_id}' 已停止。")
            elif verdict == "cancelled":
                typer.echo(f"Mission '{mission_id}' stop 已取消。", err=True)
                raise typer.Exit(1)
            else:
                rationale_text = _reviewer_rationale_text(ev)
                typer.echo(f"Mission '{mission_id}' stop 被 reviewer 拒绝。{rationale_text}", err=True)
                raise typer.Exit(1)
            raise typer.Exit()
        time.sleep(2)
    typer.echo("超时：reviewer 未在 30 分钟内完成判决。", err=True)
    raise typer.Exit(1)


@mission_app.command("pause")
def mission_pause(mission_id: str = typer.Argument(...)) -> None:
    """暂停 mission：daemon 停止事件检测，supervisor send 仍可用。"""
    require_global()
    mission = require_mission_by_name(mission_id)
    if mission.get("status") == "paused":
        typer.echo(f"Mission '{mission_id}' 已经是暂停状态。")
        return
    if mission.get("status") == "stopped":
        typer.echo(f"Mission '{mission_id}' 已停止，无法暂停。", err=True)
        raise typer.Exit(1)
    mission["status"] = "paused"
    save_mission(mission_id, mission)
    typer.echo(f"Mission '{mission_id}' 已暂停。daemon 事件检测已停止，supervisor send 仍可用。")


@mission_app.command("resume")
def mission_resume(mission_id: str = typer.Argument(...)) -> None:
    """恢复 mission：从 paused 状态回到 active。"""
    require_global()
    mission = require_mission_by_name(mission_id)
    if mission.get("status") != "paused":
        typer.echo(f"Mission '{mission_id}' 不在暂停状态（当前：{mission.get('status')}）。", err=True)
        raise typer.Exit(1)
    mission["status"] = "active"
    save_mission(mission_id, mission)
    typer.echo(f"Mission '{mission_id}' 已恢复。")


def _reviewer_rationale_text(event: dict) -> str:
    parts: list[str] = []
    verdicts = dict(event.get("reviewer_verdicts") or {})
    for reviewer_id, rationale_path in dict(event.get("reviewer_rationales") or {}).items():
        if verdicts.get(reviewer_id) != "reject":
            continue
        try:
            rationale_text = Path(rationale_path).read_text(encoding="utf-8")
        except OSError:
            rationale_text = f"(rationale file not found: {rationale_path})"
        parts.append(f"\n[{reviewer_id}] {rationale_text}")
    if parts:
        return "".join(parts)

    rationale_path = event.get("rationale", "")
    if not rationale_path:
        return ""
    try:
        return "\n" + Path(rationale_path).read_text(encoding="utf-8")
    except OSError:
        return f"\n(rationale file not found: {rationale_path})"


def _reviewer_covers_event(reviewer: dict, event_type: str) -> bool:
    triggers = reviewer.get("triggers")
    if triggers is None:
        return True
    return event_type in triggers


def _review_event_coverage(reviewers: list[dict]) -> dict[str, list[str]]:
    coverage: dict[str, list[str]] = {event_type: [] for event_type in _REQUIRED_REVIEW_EVENTS}
    for reviewer in reviewers:
        label = reviewer.get("name") or reviewer.get("id", "?")
        for event_type in _REQUIRED_REVIEW_EVENTS:
            if _reviewer_covers_event(reviewer, event_type):
                coverage[event_type].append(label)
    return coverage


def _missing_review_events(reviewers: list[dict]) -> list[str]:
    coverage = _review_event_coverage(reviewers)
    return [event_type for event_type in _REQUIRED_REVIEW_EVENTS if not coverage[event_type]]


# Keep `messages_dir` re-export for any historical importer. Otherwise unused.
__all__ = ["app", "messages_dir"]


if __name__ == "__main__":
    app()
