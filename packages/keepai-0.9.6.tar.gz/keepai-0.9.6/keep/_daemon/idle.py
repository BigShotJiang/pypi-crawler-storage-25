"""Supervisor-idle detection for workers_enabled=false missions.

When workers_enabled=false, there are no workers to ping the supervisor.
Instead, we monitor the supervisor's JSONL for silence. After IDLE_TIMEOUT
seconds of no writes, we send a `mission_idle` notification directly to the
supervisor (same mechanism as `silent`, no reviewer gate, no mission status
change).

The old supervisor-stop-file path (with SUPERVISOR_IDLE_DELAY grace period
and mission_idle review event) has been removed entirely.
"""

from __future__ import annotations

import time
from typing import Any

from keep._daemon import runtime_state
from keep._daemon.constants import (
    IDLE_TIMEOUT,
    log,
)
from keep._daemon.notify import notify_supervisor
from keep._daemon.worker_check import jsonl_age
from keep._daemon.xml_format import build_event_xml
from keep.state import (
    find_supervisor,
    worker_session_id,
)
from keep._state.config import workers_enabled_global
from xml.sax.saxutils import escape as xml_escape


def _format_idle_msg(mission_name: str, idle_seconds: int) -> str:
    """Build an `<keep event="mission_idle" .../>` notification."""
    attrs: dict[str, str] = {
        "mission": mission_name,
        "role": "supervisor",
        "idle": f"{idle_seconds}s",
    }
    body = xml_escape(
        f"Supervisor has been idle for {idle_seconds}s with no workers. "
        "Please continue working on the mission."
    )
    return build_event_xml("mission_idle", attrs, body)


def check_idle(mission_name: str, mission: dict[str, Any]) -> None:
    """Detect supervisor JSONL silence for workers_enabled=false missions.

    Does nothing when workers_enabled=true (worker silent detection via
    worker_check.py is the active path in that mode).
    """
    we = mission.get("workers_enabled")
    if we is None:
        we = workers_enabled_global()
    elif isinstance(we, str):
        we = we.lower() in {"true", "1", "yes"}
    if we:
        # workers_enabled=true: worker silent notifications handle nudging the
        # supervisor. No supervisor-level idle detection needed.
        return

    sup = find_supervisor(mission)
    if not sup:
        return

    if not worker_session_id(sup):
        return

    now = time.time()
    age = jsonl_age(sup, now)
    if age is None:
        return

    if age < IDLE_TIMEOUT:
        # Supervisor is active — reset idle tracking
        runtime_state.idle_since.pop(mission_name, None)
        runtime_state.idle_fired.discard(mission_name)
        return

    if mission_name not in runtime_state.idle_since:
        runtime_state.idle_since[mission_name] = now
        runtime_state.save()
        return

    elapsed = now - runtime_state.idle_since[mission_name]
    if elapsed < IDLE_TIMEOUT:
        return

    # Allow re-notification: idle_fired is cleared as soon as we send,
    # so the next tick can fire again after another IDLE_TIMEOUT of silence.
    # (Mirrors silent notification re-arming behavior.)
    if mission_name in runtime_state.idle_fired:
        # Reset so next cycle fires again after the supervisor writes something
        return

    idle_secs = int(age)
    log.info("Supervisor idle detected for mission %r (idle %ds, workers_enabled=false)", mission_name, idle_secs)
    runtime_state.idle_fired.add(mission_name)
    runtime_state.save()

    msg = _format_idle_msg(mission_name, idle_secs)
    notify_supervisor(mission, msg)

    # Reset idle tracking immediately so the supervisor getting the nudge
    # and writing to JSONL will clear the timer cleanly.
    runtime_state.idle_since.pop(mission_name, None)
    runtime_state.idle_fired.discard(mission_name)
    runtime_state.save()
