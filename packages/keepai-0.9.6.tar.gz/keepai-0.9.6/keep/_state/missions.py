"""Mission CRUD, schema versioning, migration, per-mission lock."""

from __future__ import annotations

import json
import re
import shutil
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator

from filelock import FileLock

from keep._state import paths as _paths
from keep._state.globals_ import new_global, save_global
from keep._state.paths import (
    DEFAULT_TERMINAL,
    VALID_TERMINALS,
    atomic_write_text,
    _ensure_dirs,
    _validate_mission_name,
)

# Schema version. Bump when introducing migration-requiring changes.
# Current shape (v1):
#   - participants: no "terminal_type" or "reach" fields
#   - mission: no "relationships" / "plans" / "next_plan_id"
#   - tasks: no "rationale_review_event_id"
SCHEMA_VERSION = 2

VALID_MISSION_STATUSES = frozenset({"active", "stopped", "paused"})
VALID_PARTICIPANT_ROLES = frozenset({"worker", "supervisor"})


def mission_terminal_type(mission: dict[str, Any]) -> str:
    """Mission's terminal_type. Falls back to DEFAULT_TERMINAL only for pre-feature missions."""
    return mission.get("terminal_type") or DEFAULT_TERMINAL


def validate_mission(mission: dict[str, Any]) -> None:
    """Raise ValueError if mission violates schema invariants.

    Required fields enforced here let display/logic paths use direct dict
    access (mission["status"], mission["name"]) instead of .get with masking
    fallbacks. Bugs in serializers surface here, not at use sites.
    """
    name = mission.get("name")
    if not name:
        raise ValueError(f"Mission missing required field 'name': {mission!r}")

    status = mission.get("status")
    if status not in VALID_MISSION_STATUSES:
        raise ValueError(
            f"Mission {name!r}: invalid status {status!r}; "
            f"valid: {sorted(VALID_MISSION_STATUSES)}"
        )

    tt = mission.get("terminal_type")
    if tt is not None and tt not in VALID_TERMINALS:
        raise ValueError(
            f"Mission {name!r}: invalid terminal_type {tt!r}; "
            f"valid: {sorted(VALID_TERMINALS)}"
        )

    tc = mission.get("terminal_container")
    if tc is not None and not isinstance(tc, str):
        raise ValueError(
            f"Mission {name!r}: terminal_container must be str or None, got {type(tc).__name__}"
        )

    for p in mission.get("participants", []):
        role = p.get("role")
        if role not in VALID_PARTICIPANT_ROLES:
            raise ValueError(
                f"Mission {name!r}: participant has invalid role {role!r}; "
                f"valid: {sorted(VALID_PARTICIPANT_ROLES)}"
            )
        if not p.get("session"):
            raise ValueError(f"Mission {name!r}: participant missing 'session' field")


def _mission_file(name: str) -> Path:
    return _paths.MISSIONS_DIR / f"{name}.json"


def _mission_lock_file(name: str) -> Path:
    return _paths.MISSIONS_DIR / f"{name}.json.lock"


def _mission_resource_dir(mission_name: str) -> Path:
    return _paths.MISSIONS_DIR / mission_name


def new_mission(
    name: str,
    terminal_type: str = DEFAULT_TERMINAL,
    *,
    workers_enabled: bool | None = None,
) -> dict[str, Any]:
    mission: dict[str, Any] = {
        "schema_version": SCHEMA_VERSION,
        "name": name,
        "status": "stopped",
        "participants": [],
        "mission_prompt": None,
        "created_at": time.time(),
        "review_events": [],
        "terminal_type": terminal_type,
        "terminal_container": None,
    }
    if workers_enabled is not None:
        mission["workers_enabled"] = workers_enabled
    return mission


def _migrate_mission_shape(mission: dict[str, Any]) -> bool:
    """Run all migrations needed to bring `mission` up to SCHEMA_VERSION.

    Skipped on already-current missions. Returns True if anything was changed.
    """
    if mission.get("schema_version") == SCHEMA_VERSION:
        return False

    version = mission.get("schema_version", 0)

    # v0.3 → v0.4: workers → participants[role=worker]
    if "participants" not in mission:
        old = mission.get("workers", [])
        mission["participants"] = [
            {"session": w["session"], "role": "worker", "cache": w.get("cache")}
            for w in old
        ]
        mission.pop("workers", None)
    else:
        for p in mission["participants"]:
            # Removed dead participant fields (mission is the source of truth)
            for dead_key in ("reach", "terminal_type"):
                p.pop(dead_key, None)

    # Dead top-level fields removed in later versions
    for dead_key in ("relationships", "plans", "next_plan_id"):
        mission.pop(dead_key, None)

    # v1 → v2: add terminal_container (no readers yet; upcoming refactor)
    if version < 2:
        mission.setdefault("terminal_container", None)

    mission["schema_version"] = SCHEMA_VERSION
    return True  # always re-save to persist schema_version


def load_mission(name: str) -> dict[str, Any] | None:
    f = _mission_file(name)
    if not f.exists():
        return None
    mission = json.loads(f.read_text())
    if _migrate_mission_shape(mission):
        save_mission(name, mission)
    validate_mission(mission)
    return mission


def save_mission(name: str, mission: dict[str, Any]) -> None:
    _ensure_dirs()
    atomic_write_text(_mission_file(name), json.dumps(mission, ensure_ascii=False, indent=2))


def delete_mission(name: str) -> bool:
    f = _mission_file(name)
    if not f.exists():
        return False
    f.unlink()
    # 清理 per-mission 资源目录，但保留 messages/ 以便事后分析。
    # 若清理后外层目录为空（没有 messages/ 需要保留），一并 rmdir 掉，
    # 避免留下空壳目录。
    resource_dir = _mission_resource_dir(name)
    if resource_dir.exists():
        for child in resource_dir.iterdir():
            if child.name == "messages":
                continue
            if child.is_dir():
                shutil.rmtree(child, ignore_errors=True)
            else:
                child.unlink(missing_ok=True)
        # next() 拿第一项；空迭代器说明目录已清空，可安全 rmdir
        if next(resource_dir.iterdir(), None) is None:
            resource_dir.rmdir()
    return True


def list_missions() -> list[str]:
    """返回所有 mission 名（按文件名排序）。"""
    if not _paths.MISSIONS_DIR.exists():
        return []
    return sorted(f.stem for f in _paths.MISSIONS_DIR.glob("*.json"))


def create_mission(
    name: str,
    terminal_type: str = DEFAULT_TERMINAL,
    *,
    workers_enabled: bool | None = None,
) -> dict[str, Any]:
    """创建新 mission，如已存在则报错。"""
    _validate_mission_name(name)
    if _mission_file(name).exists():
        raise ValueError(f"Mission '{name}' 已存在")
    mission = new_mission(name, terminal_type=terminal_type, workers_enabled=workers_enabled)
    validate_mission(mission)
    save_mission(name, mission)
    return mission


def delete_all() -> None:
    """清除所有状态（global + missions + signal files）。"""
    from keep._state.globals_ import delete_global
    delete_global()
    if _paths.MISSIONS_DIR.exists():
        for f in _paths.MISSIONS_DIR.glob("*.json"):
            f.unlink()
            # 对称于 delete_mission：同步清掉 per-mission 资源目录
            # （transcript.jsonl 等）。ignore_errors 保证清理失败不反向破坏
            # 主流程。
            shutil.rmtree(_mission_resource_dir(f.stem), ignore_errors=True)
    for f in _paths.STATE_DIR.glob("stop-*"):
        f.unlink()
    # v0.4: submit-* 遗留文件清理（不再使用 UserPromptSubmit hook 确认投递）
    for f in _paths.STATE_DIR.glob("submit-*"):
        f.unlink()


@contextmanager
def mutate_mission(name: str) -> Iterator[dict[str, Any]]:
    """Acquire per-mission lock, load, yield mission for mutation, save on exit.

    Use this for any read-modify-write on mission state to prevent
    daemon and CLI from clobbering each other's writes.
    """
    _ensure_dirs()
    lock_path = _mission_lock_file(name)
    with FileLock(str(lock_path)):
        mission = load_mission(name)
        if mission is None:
            raise ValueError(f"Mission {name!r} 不存在")
        yield mission
        save_mission(name, mission)


def set_mission_container(name: str, ref: str) -> None:
    with mutate_mission(name) as mission:
        mission["terminal_container"] = ref


# ── v0.2 migration ────────────────────────────────────────────

_v2_check_done = False


def _migrate_v2() -> None:
    """检测 v0.2 active.json 并迁移为 v0.3 格式。Process-cached: only stat once per run."""
    global _v2_check_done
    if _v2_check_done:
        return
    _v2_check_done = True
    old_file = _paths.STATE_DIR / "active.json"
    if not old_file.exists():
        return
    if _paths.GLOBAL_FILE.exists():
        # 已经迁移过，清理旧文件
        old_file.unlink()
        return

    old = json.loads(old_file.read_text())
    _ensure_dirs()

    # 提取全局信息（v0.4 起不再存 supervisor_surface）
    global_state = new_global()
    global_state["daemon_pid"] = old.get("daemon_pid")

    # 提取 mission（用 worker_session 或 "default" 作为名字）
    mission_name = old.get("worker_session") or "default"
    # 清理名字中不合法字符
    mission_name = re.sub(r"[^a-zA-Z0-9_-]", "-", mission_name).strip("-") or "default"

    mission = new_mission(mission_name)
    mission["mission_prompt"] = old.get("mission_prompt")

    # 迁移 worker 为 participant(role=worker)
    worker_session = old.get("worker_session")
    if worker_session:
        mission["participants"] = [{
            "session": worker_session,
            "role": "worker",
            "cache": old.get("worker_cache"),
        }]

    save_global(global_state)
    save_mission(mission_name, mission)
    old_file.unlink()
