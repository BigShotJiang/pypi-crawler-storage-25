"""Global keep config reader/writer.

Config file: KEEP_HOME/config.json
Currently supported fields:
  workers_enabled: bool  (default True when absent)
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

_log = logging.getLogger("keep.state")

_config_cache: dict[str, Any] | None = None
_config_cache_path: Path | None = None


def _config_path() -> Path:
    from keep._state import paths as _paths
    return _paths.KEEP_HOME / "config.json"


def get_global_config() -> dict[str, Any]:
    """Read KEEP_HOME/config.json, return {} if absent or unreadable."""
    global _config_cache, _config_cache_path
    path = _config_path()
    if _config_cache is not None and _config_cache_path == path:
        return _config_cache
    if not path.exists():
        _config_cache = {}
        _config_cache_path = path
        return _config_cache
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            _config_cache = data
        else:
            _config_cache = {}
    except Exception as e:
        _log.warning("Failed to read global config %s: %s", path, e)
        _config_cache = {}
    _config_cache_path = path
    return _config_cache


def _invalidate_cache() -> None:
    global _config_cache, _config_cache_path
    _config_cache = None
    _config_cache_path = None


def set_global_config(key: str, value: Any) -> None:
    """Write a single key to KEEP_HOME/config.json (creates file if absent)."""
    global _config_cache, _config_cache_path
    from keep._state.paths import atomic_write_text
    path = _config_path()
    config = get_global_config()
    config[key] = value
    path.parent.mkdir(parents=True, exist_ok=True)
    atomic_write_text(path, json.dumps(config, indent=2, ensure_ascii=False))
    _config_cache = None  # invalidate
    _config_cache_path = None


def workers_enabled_global() -> bool:
    """Return global workers_enabled config value (default True)."""
    return bool(get_global_config().get("workers_enabled", True))


def is_workers_enabled(mission_name: str) -> bool:
    """Effective workers_enabled for a mission.

    Priority: mission-level field > global config > True (default).
    """
    from keep._state.missions import load_mission
    mission = load_mission(mission_name)
    if mission is not None:
        value = mission.get("workers_enabled")
        if value is not None:
            if isinstance(value, str):
                return value.lower() in {"true", "1", "yes"}
            return bool(value)
    return workers_enabled_global()
