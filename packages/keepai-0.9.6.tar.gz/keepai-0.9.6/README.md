# keep

> **keep** = auto**mation** minus the auto. You stay in control.

CC Worker orchestration CLI — manage multiple missions with multiple workers across your terminal of choice (cmux, iTerm2, tmux, kitty, Terminal.app).

## The Three-Party System

`keep` implements a relay system between three parties: **Human**, **Supervisor CC**, and **Worker CC**. At least one of them is always active — the system never stalls.

```
Worker stops → Daemon relays → Supervisor wakes up, evaluates, instructs Worker
                                        → Worker works → stops → Daemon relays → ...

All plans done → Supervisor notifies Human → Human decides: more plans or done
```

- **Worker CC** does the actual coding work. It doesn't know it's being managed.
- **Supervisor CC** is the Human's agent. It evaluates Worker output, runs verification (by telling Worker to review/test), and drives plans forward.
- **Human** sets the mission direction and makes final decisions. Only gets notified when Supervisor needs input.
- **Daemon** is the relay — when any Worker in any mission stops, it instantly notifies the Supervisor CC. Pure event bridge, no decisions.

> **Supervisor and Worker are homogeneous agent sessions**. Their difference is role, not kind. The current runtime supports both Claude Code and Codex interactive sessions. A plain bash shell cannot serve as either: delivering notification text to a surface is not the same as acting on it. The session must be able to parse `<keep event>` tags, run mission-scoped supervisor/task commands, and carry out the supervision loop.

## Reviewer

Reviewer 是人的分身，承载产品/技术/设计视角，作为 Supervisor 的独立外审。

### 创建 Reviewer
```bash
# 先在 ~/.keep/reviewers/ 下准备视角文件
keep <mission_id> reviewer create --name product
```

### Reviewer 的 3 个判决事件
1. **task_proposed_review** — 审批 proposed task 批量设计（通过：`proposed → pending`；拒绝：退回 `proposed`）
2. **task_submitted_review** — 审批 submitted task 完成判断（通过：`submitted → completed`；拒绝：退回 `in_progress`）
3. **mission_stop** — 最终 stop 闸门，同时承担原 `mission_align` 语义：Reviewer 在这里检查 mission 是否真的对齐 exit criteria，只有通过后 mission 才会停止

另有一个**非判决同步通知**：`mission_sync`。它只负责把最新 Mission prompt / task 摘要同步给 Reviewer，不要求 `pass` / `reject`。

## Task 状态机

proposed → awaiting_review → pending → in_progress → submitted → completed

- `proposed`：初始状态，task create 后
- `awaiting_review`：内部过渡态；Daemon 正在为 proposed 批次创建 `task_proposed_review`
- `pending`：Reviewer 批准设计，可以派发给 Worker
- `in_progress`：Worker 正在执行
- `submitted`：Supervisor 已声明完成，等待 `task_submitted_review` 审批
- `completed`：Reviewer 批准完成判断，task 正式完成

## Requirements

- Python 3.12+
- [uv](https://github.com/astral-sh/uv)
- CC Stop hook configured (see [Setup](#setup))
- One of the supported terminal backends below

### Terminal backends

Pick any one — `keep` drives them via their native automation API.

| Backend | Setup |
|---------|-------|
| **cmux** | Settings → Socket Control Mode → **Automation** |
| **iTerm2** | Settings → General → Magic → **Enable Python API**. Install deps: `uv add iterm2 pyobjc-framework-Cocoa` |
| **tmux** | `brew install tmux` (no extra config) |
| **kitty** | In `~/.config/kitty/kitty.conf`: `allow_remote_control yes` and `listen_on unix:/tmp/kitty.sock`. Export `KITTY_LISTEN_ON=unix:/tmp/kitty.sock` |
| **Terminal.app** | System Settings → Privacy & Security → Accessibility (grant to your shell/terminal). Known issue: reviewer/worker create hangs — prefer another backend for multi-role missions |

## Install

```bash
uv tool install keep
```

## Setup

Configure CC's Stop hook globally so `keep` knows when a Worker finishes a turn:

```json
// Claude Code: ~/.claude/settings.json (or your cac env settings)
{
  "hooks": {
    "Stop": [
      {
        "hooks": [{ "type": "command", "command": "bash ~/.keep/on-stop.sh" }]
      }
    ]
  }
}
```

Create the hook script:

```bash
mkdir -p ~/.keep

cat > ~/.keep/on-stop.sh << 'EOF'
#!/bin/bash
INPUT=$(cat)
SESSION_ID=$(echo "$INPUT" | jq -r '.session_id')
echo "$INPUT" > ~/.keep/stop-${SESSION_ID}
EOF

chmod +x ~/.keep/on-stop.sh
```

## Quick Start

```bash
# Start daemon
keep self start

# Create mission — ID is auto-generated and printed, e.g. 'a3f2c1d9'
# New missions start in stopped state; configure first, then start
# --terminal selects the backend; omit to use config default
keep mission create --terminal iterm2
# → Mission 'a3f2c1d9' 已创建。

# Set mission prompt (inline text or file path)
keep mission update a3f2c1d9 "Implement chat receipts"
keep mission update a3f2c1d9 ~/path/to/mission.md

# Create tasks and supervisor (allowed while stopped)
keep a3f2c1d9 task create "Backend read API"
keep a3f2c1d9 supervisor create --name my-supervisor

# Activate mission — required before worker create / send / kick
keep mission start a3f2c1d9

# Spawn worker
keep a3f2c1d9 worker create --name my-worker

# Single-worker mission: worker_id can be omitted for send/read/kick
# send requires a file path; write your message file to messages/ first
echo "开始实现 Backend read API" > ~/.keep/missions/a3f2c1d9/messages/task-1.md
keep a3f2c1d9 supervisor send ~/.keep/missions/a3f2c1d9/messages/task-1.md
keep a3f2c1d9 supervisor read
keep a3f2c1d9 supervisor kick

# Check system and mission state
keep self show
keep mission show a3f2c1d9
keep mission ls            # alias for mission list

# Stop / reset
keep self stop
keep self reset
```

## Terminal backend

Each mission maps to **one terminal container** (window / workspace / session, chosen per backend). The supervisor, reviewer, and all workers of the same mission share that container, arranged by role — supervisor top-left, reviewer top-right, workers in the bottom region. Additional workers degrade into tabs or splits depending on what the backend supports.

Pick the backend per mission with `keep mission create --terminal <name>` (`cmux | iterm2 | tmux | kitty | terminal`); omit to use the config default.

| Backend | Container | Layout |
|---------|-----------|--------|
| cmux | workspace | sup = top-left pane, reviewer = top-right pane, worker = bottom pane (extra workers become surface tabs inside the worker pane) |
| iTerm2 | window | 3 panes in 1 tab: sup \| reviewer on top, worker-1 on bottom; extra workers = new tabs |
| tmux | session | window 0 has `sup \| reviewer \| worker-1` panes; extra workers = new windows |
| kitty | OS window | one tab per role (supervisor / reviewer / worker-1); extra workers = hsplit inside the worker-1 tab |
| Terminal.app | window | one tab per role+instance (no split-pane API — pure tab degradation) |

## Multi-Mission

```bash
keep mission create   # → Mission 'aa11bb22' 已创建。
keep mission create   # → Mission 'cc33dd44' 已创建。

keep aa11bb22 worker create --name worker-a
keep aa11bb22 supervisor create --name sup-a
keep aa11bb22 task create "Step 1"

keep cc33dd44 worker create --name worker-b
keep cc33dd44 supervisor create --name sup-b
keep cc33dd44 task create "Step 1"

keep mission list
```

## Multi-Worker

A mission can have multiple workers. In that case, `supervisor send/read/kick` must explicitly pass `worker_id`.

```bash
# assuming mission id is 'a3f2c1d9'
keep a3f2c1d9 worker create --name worker-frontend
keep a3f2c1d9 worker create --name worker-backend

keep a3f2c1d9 supervisor send worker-frontend ~/.keep/missions/a3f2c1d9/messages/task-ui.md
keep a3f2c1d9 supervisor send worker-backend ~/.keep/missions/a3f2c1d9/messages/task-api.md
keep a3f2c1d9 supervisor read worker-frontend
keep a3f2c1d9 supervisor kick worker-backend
```

## Content Resolution

`mission update <mission_id> <prompt>` accepts file paths or inline text:

| Input | Detection | Behavior |
|-------|-----------|----------|
| `~/path/to/file.md` | File exists on disk | Read file content at display/use time |
| `"Implement feature X"` | Not a file path | Use text as-is |

## CLI Reference

### Self
| Command | Description |
|---------|-------------|
| `keep self start [-f]` | Start daemon (`-f`: foreground) |
| `keep self stop` | Stop daemon and lock state |
| `keep self show` | Show system status and mission summary |
| `keep self reset` | Stop daemon and clear all state |

### Mission
| Command | Description |
|---------|-------------|
| `keep mission create [--terminal <backend>]` | Create a mission (ID auto-generated, printed on creation). `--terminal`: `cmux \| iterm2 \| tmux \| kitty \| terminal` (defaults to config) |
| `keep mission update <mission_id> <prompt>` | Update mission prompt |
| `keep mission remove <mission_id>` | Delete a mission |
| `keep mission list` / `keep mission ls` | List missions |
| `keep mission show <mission_id>` | Show mission details |
| `keep mission start <mission_id>` | Mark mission active (prints supervisor/worker/task readiness check) |
| `keep mission stop <mission_id>` | Mark mission stopped |

### Mission-scoped Task
| Command | Description |
|---------|-------------|
| `keep <mission_id> task create <subject>` | Create task |
| `keep <mission_id> task update <task_id> [--status/--owner/--description/--blocks/--blocked-by]` | Update task |
| `keep <mission_id> task remove <task_id>` | Remove task |
| `keep <mission_id> task list` | List tasks |
| `keep <mission_id> task show <task_id>` | Show task |

### Mission-scoped Worker
| Command | Description |
|---------|-------------|
| `keep <mission_id> worker create [--agent <claude-code|codex>] [--name <name>] [--path <path>]` | Spawn new worker agent session, inject contract, wait for ready reply |
| `keep <mission_id> worker create --session <session_id>` | Re-attach an existing session as worker (skips spawn) |
| `keep <mission_id> worker update <worker_id> [--name <name>] [--path <path>]` | Update worker metadata |
| `keep <mission_id> worker remove <worker_id>` | Remove worker |
| `keep <mission_id> worker list` | List workers |
| `keep <mission_id> worker show <worker_id>` | Show worker details |

### Mission-scoped Supervisor
| Command | Description |
|---------|-------------|
| `keep <mission_id> supervisor create [--agent <claude-code|codex>] [--name <name>] [--path <path>]` | Create/replace supervisor agent session + contract and wait for ready reply |
| `keep <mission_id> supervisor update <supervisor_id> [--name <name>] [--path <path>]` | Update supervisor metadata |
| `keep <mission_id> supervisor remove <supervisor_id>` | Remove supervisor |
| `keep <mission_id> supervisor list` | Show current supervisor |
| `keep <mission_id> supervisor show <supervisor_id>` | Show supervisor details |
| `keep <mission_id> supervisor send [worker_id] <file_path>` | Send message file to worker (`<file_path>` must exist; files outside `messages/` are auto-copied with a warning) |
| `keep <mission_id> supervisor read [worker_id]` | Read worker latest message |
| `keep <mission_id> supervisor kick [worker_id]` | Send Enter key to worker |

## How It Works

1. **Worker creation**: `keep <mission_id> worker create` generates a UUID participant id, starts the selected agent runtime with the bootstrap prompt and contract, waits until the session emits its ready reply, then records runtime cache and contract metadata. Use `--session <id>` to re-attach an existing session without spawning a new one.
2. **Idle detection**: CC Stop hook writes a signal file when Worker finishes responding. Daemon polls for this file every 2s.
3. **Stop relay**: Daemon consumes the stop signal, always saves the Worker's full reply to `~/.keep/missions/<name>/messages/` (as `<seq>-worker-<session>-stop.md`), then injects a `<keep event="stop" mission="..." worker="..." output_file="...">` notification into the Supervisor session. `output_file` is included when the reply exceeds 200 characters; the path can be forwarded directly to downstream workers — no transcription needed.
4. **Stall detection**: Worker idle >3min triggers a stall notification with progressive backoff (180s → 240s → 300s). Multiple workers stalling simultaneously produce a single aggregated `[stall ×N]` message instead of N separate messages.
5. **Stall hint**: At `stall_count=2`, the notification body includes a hint suggesting the Supervisor can remove the worker and re-attach it later via `worker create --session`. At the cap (`stall_max=10`), automatic reminders stop.
6. **Runtime state persistence**: Stall counts, notification timestamps, and closed-worker state survive daemon restarts (`~/.keep/daemon-runtime.json`). Worker bootstrap state is persisted per-worker so the first real task stop is never mistakenly suppressed after a restart.
7. **Send is fire-and-forget**: `keep <mission_id> supervisor send ...` delivers text via the active backend's automation API (cmux RPC / iTerm2 Python API / tmux / kitty / AppleScript). Text is split-sent with CR + 2s gap to escape the CC TUI's bracketed-paste envelope. Success = text reached the terminal; CC queues it if Worker is busy.
8. **Supervisor creation**: each mission stores one supervisor participant via `keep <mission_id> supervisor create`. Daemon resolves `session → PID → backend-specific surface ref` dynamically on each notification (e.g. `CMUX_SURFACE_ID` for cmux, iTerm2 session id, tmux pane id, kitty window id, Terminal.app tab id).
9. **Dormant until supervisor exists**: a mission without a supervisor participant is skipped by daemon event routing.
10. **Active mission required**: `supervisor send`, `supervisor kick`, and `worker create` (both spawn and `--session`) are blocked when the mission is `stopped`. Run `keep mission start <id>` first.
11. **Multi-mission routing**: daemon iterates active missions and routes events per mission-local supervisor relationship.
12. **Cache refresh**: Worker cache (PID, surface_id, JSONL path) auto-refreshes on `supervisor send/read/kick`.

## State Files

```
~/.keep/
  global.json                          # daemon_pid, stopped
  daemon-runtime.json                  # persisted stall counts, notify timestamps, closed set
  daemon.log                           # daemon log
  stop-<session_id>                    # signal file (CC Stop hook writes, daemon consumes)
  on-stop.sh                           # CC Stop hook script
  missions/<name>.json                 # per-mission: participants, relationships, mission_prompt
  missions/<name>/transcript.jsonl     # worker→supervisor reply transcript
  missions/<name>/messages/            # unified inbox: all mission communications
    index.json                         # sequential index of all events (worker stop, daemon events, supervisor sends)
    <seq>-worker-<session>-stop.md     # worker stop output (always written, full content)
    <seq>-daemon-<type>.md             # daemon events (align, stall)
    <arbitrary>.md                     # supervisor message files
```

Participant roles: `worker` (managed CC), `supervisor` (human proxy). Mission has 0 or 1 supervisor; claim replaces.

## License

MIT
