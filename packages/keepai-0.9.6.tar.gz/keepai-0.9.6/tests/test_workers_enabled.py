"""Tests for workers_enabled config / mission field / idle detection.

Covers:
  - Global config read/write (keep._state.config)
  - is_workers_enabled resolver (global/mission/default)
  - Daemon check_idle skips for workers_enabled=true
  - Daemon check_idle sends mission_idle notification for workers_enabled=false
  - CLI: keep config get/set workers_enabled
  - CLI: keep mission create --no-workers
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any

import pytest
from typer.testing import CliRunner

from keep.cli import app
from keep._state.config import (
    get_global_config,
    is_workers_enabled,
    set_global_config,
    workers_enabled_global,
)
from keep.state import (
    create_mission,
    load_mission,
    mutate_mission,
    new_global,
    save_global,
)


runner = CliRunner()


# ── Fixtures ────────────────────────────────────────────────────────


@pytest.fixture(autouse=True)
def _isolate_keep_home(tmp_path, monkeypatch):
    """Give each test its own KEEP_HOME so config/mission state is isolated."""
    monkeypatch.setenv("KEEP_HOME", str(tmp_path))
    yield


@pytest.fixture
def _global_state(tmp_path, monkeypatch):
    """Create a minimal global.json so CLI commands that call require_global() pass."""
    monkeypatch.setenv("KEEP_HOME", str(tmp_path))
    gs = new_global()
    save_global(gs)
    return gs


# ── Global config read/write ─────────────────────────────────────


def test_get_global_config_absent_returns_empty():
    assert get_global_config() == {}


def test_workers_enabled_global_default_is_true():
    assert workers_enabled_global() is True


def test_set_and_get_workers_enabled_false():
    set_global_config("workers_enabled", False)
    assert workers_enabled_global() is False


def test_set_and_get_workers_enabled_true_explicit():
    set_global_config("workers_enabled", True)
    assert workers_enabled_global() is True


def test_set_global_config_writes_json(tmp_path, monkeypatch):
    monkeypatch.setenv("KEEP_HOME", str(tmp_path))
    set_global_config("workers_enabled", False)
    config_file = tmp_path / "config.json"
    assert config_file.exists()
    data = json.loads(config_file.read_text())
    assert data["workers_enabled"] is False


def test_set_global_config_preserves_other_keys(tmp_path, monkeypatch):
    monkeypatch.setenv("KEEP_HOME", str(tmp_path))
    set_global_config("other_key", "hello")
    set_global_config("workers_enabled", False)
    config = get_global_config()
    assert config["other_key"] == "hello"
    assert config["workers_enabled"] is False


# ── is_workers_enabled resolver ──────────────────────────────────


def test_is_workers_enabled_default_true_no_config():
    create_mission("testm")
    assert is_workers_enabled("testm") is True


def test_is_workers_enabled_global_false_propagates():
    set_global_config("workers_enabled", False)
    create_mission("testm")
    assert is_workers_enabled("testm") is False


def test_is_workers_enabled_mission_overrides_global_false():
    set_global_config("workers_enabled", False)
    create_mission("testm", workers_enabled=True)
    assert is_workers_enabled("testm") is True


def test_is_workers_enabled_mission_overrides_global_true():
    # global default is True, mission says False
    create_mission("testm", workers_enabled=False)
    assert is_workers_enabled("testm") is False


def test_is_workers_enabled_mission_none_uses_global():
    # mission has no workers_enabled field → falls through to global
    set_global_config("workers_enabled", False)
    create_mission("testm")
    # Verify the mission actually has no workers_enabled field
    m = load_mission("testm")
    assert "workers_enabled" not in m
    assert is_workers_enabled("testm") is False


def test_is_workers_enabled_mission_explicit_none_uses_global():
    # Passing workers_enabled=None to create_mission → absent from JSON
    create_mission("testm", workers_enabled=None)
    m = load_mission("testm")
    assert "workers_enabled" not in m
    assert is_workers_enabled("testm") is True  # global default


# ── Mission create with workers_enabled field ────────────────────


def test_create_mission_workers_enabled_false_persists():
    create_mission("testm", workers_enabled=False)
    m = load_mission("testm")
    assert m["workers_enabled"] is False


def test_create_mission_workers_enabled_true_persists():
    create_mission("testm", workers_enabled=True)
    m = load_mission("testm")
    assert m["workers_enabled"] is True


def test_create_mission_workers_enabled_absent_by_default():
    create_mission("testm")
    m = load_mission("testm")
    assert "workers_enabled" not in m


# ── Daemon check_idle behavior ───────────────────────────────────


def _make_mission(
    mission_name: str,
    jsonl_path: str | None = None,
    workers_enabled: bool | None = None,
) -> dict[str, Any]:
    """Build a minimal mission dict with a supervisor participant."""
    cache: dict[str, Any] = {}
    if jsonl_path:
        cache["jsonl_path"] = jsonl_path
    d: dict[str, Any] = {
        "name": mission_name,
        "status": "active",
        "participants": [
            {
                "session": "sup-session-1",
                "role": "supervisor",
                "cache": cache,
            }
        ],
    }
    if workers_enabled is not None:
        d["workers_enabled"] = workers_enabled
    return d


@pytest.fixture
def _clear_idle_runtime():
    from keep._daemon import runtime_state
    runtime_state.idle_since.clear()
    runtime_state.idle_fired.clear()
    yield
    runtime_state.idle_since.clear()
    runtime_state.idle_fired.clear()


def test_check_idle_skips_when_workers_enabled_true(
    tmp_path, monkeypatch, _clear_idle_runtime,
):
    """When workers_enabled=true, check_idle is a no-op."""
    # Create mission with workers_enabled=True (default)
    create_mission("testm")

    notifications: list[str] = []
    monkeypatch.setattr(
        "keep._daemon.idle.notify_supervisor",
        lambda _mission, msg: notifications.append(msg),
    )

    from keep._daemon.idle import check_idle
    mission = _make_mission("testm")
    check_idle("testm", mission)

    assert notifications == [], "check_idle should be a no-op for workers_enabled=true"


def test_check_idle_skips_when_no_supervisor(
    tmp_path, monkeypatch, _clear_idle_runtime,
):
    """When workers_enabled=false but no supervisor, check_idle does nothing."""
    create_mission("testm", workers_enabled=False)

    notifications: list[str] = []
    monkeypatch.setattr(
        "keep._daemon.idle.notify_supervisor",
        lambda _mission, msg: notifications.append(msg),
    )

    from keep._daemon.idle import check_idle
    mission = {
        "name": "testm",
        "status": "active",
        "workers_enabled": False,
        "participants": [],
    }
    check_idle("testm", mission)

    assert notifications == []


def test_check_idle_skips_when_no_jsonl_path(
    tmp_path, monkeypatch, _clear_idle_runtime,
):
    """Supervisor exists but has no jsonl_path → no idle detection."""
    create_mission("testm", workers_enabled=False)

    notifications: list[str] = []
    monkeypatch.setattr(
        "keep._daemon.idle.notify_supervisor",
        lambda _mission, msg: notifications.append(msg),
    )

    from keep._daemon.idle import check_idle
    mission = _make_mission("testm", jsonl_path=None, workers_enabled=False)
    check_idle("testm", mission)

    assert notifications == []


def test_check_idle_no_notification_when_jsonl_fresh(
    tmp_path, monkeypatch, _clear_idle_runtime,
):
    """Fresh JSONL (just written) → no mission_idle notification."""
    create_mission("testm", workers_enabled=False)
    jsonl = tmp_path / "sup.jsonl"
    jsonl.write_text('{"type": "assistant"}', encoding="utf-8")
    # mtime is "now", so age < IDLE_TIMEOUT

    notifications: list[str] = []
    monkeypatch.setattr(
        "keep._daemon.idle.notify_supervisor",
        lambda _mission, msg: notifications.append(msg),
    )

    from keep._daemon.idle import check_idle
    mission = _make_mission("testm", jsonl_path=str(jsonl), workers_enabled=False)
    check_idle("testm", mission)

    assert notifications == []


def test_check_idle_sends_notification_when_jsonl_stale(
    tmp_path, monkeypatch, _clear_idle_runtime,
):
    """JSONL older than IDLE_TIMEOUT → mission_idle notification sent to supervisor."""
    from keep._daemon.constants import IDLE_TIMEOUT
    from keep._daemon import runtime_state

    create_mission("testm", workers_enabled=False)
    jsonl = tmp_path / "sup.jsonl"
    jsonl.write_text('{"type": "assistant"}', encoding="utf-8")

    # Set mtime to IDLE_TIMEOUT + 10 seconds ago
    stale_time = time.time() - IDLE_TIMEOUT - 10
    import os
    os.utime(jsonl, (stale_time, stale_time))

    # Pre-seed idle_since so the "start timer" path is already past
    runtime_state.idle_since["testm"] = stale_time - IDLE_TIMEOUT
    runtime_state.save()

    notifications: list[str] = []
    monkeypatch.setattr(
        "keep._daemon.idle.notify_supervisor",
        lambda _mission, msg: notifications.append(msg),
    )

    from keep._daemon.idle import check_idle
    mission = _make_mission("testm", jsonl_path=str(jsonl), workers_enabled=False)
    check_idle("testm", mission)

    assert len(notifications) == 1, "Expected exactly one mission_idle notification"
    msg = notifications[0]
    assert 'event="mission_idle"' in msg
    assert "testm" in msg
    assert 'role="supervisor"' in msg


def test_check_idle_notification_is_valid_xml(
    tmp_path, monkeypatch, _clear_idle_runtime,
):
    """mission_idle notification is well-formed XML."""
    from xml.etree import ElementTree
    from keep._daemon.constants import IDLE_TIMEOUT
    from keep._daemon import runtime_state

    create_mission("testm", workers_enabled=False)
    jsonl = tmp_path / "sup.jsonl"
    jsonl.write_text("{}", encoding="utf-8")

    stale_time = time.time() - IDLE_TIMEOUT - 10
    import os
    os.utime(jsonl, (stale_time, stale_time))

    runtime_state.idle_since["testm"] = stale_time - IDLE_TIMEOUT
    runtime_state.save()

    notifications: list[str] = []
    monkeypatch.setattr(
        "keep._daemon.idle.notify_supervisor",
        lambda _mission, msg: notifications.append(msg),
    )

    from keep._daemon.idle import check_idle
    mission = _make_mission("testm", jsonl_path=str(jsonl), workers_enabled=False)
    check_idle("testm", mission)

    assert notifications
    root = ElementTree.fromstring(notifications[0])
    assert root.tag == "keep"
    assert root.attrib["event"] == "mission_idle"
    assert root.attrib["mission"] == "testm"


def test_check_idle_resets_after_notification(
    tmp_path, monkeypatch, _clear_idle_runtime,
):
    """After sending the notification, idle tracking is reset."""
    from keep._daemon.constants import IDLE_TIMEOUT
    from keep._daemon import runtime_state

    create_mission("testm", workers_enabled=False)
    jsonl = tmp_path / "sup.jsonl"
    jsonl.write_text("{}", encoding="utf-8")

    stale_time = time.time() - IDLE_TIMEOUT - 10
    import os
    os.utime(jsonl, (stale_time, stale_time))

    runtime_state.idle_since["testm"] = stale_time - IDLE_TIMEOUT
    runtime_state.save()

    monkeypatch.setattr(
        "keep._daemon.idle.notify_supervisor",
        lambda *a: None,
    )

    from keep._daemon.idle import check_idle
    mission = _make_mission("testm", jsonl_path=str(jsonl), workers_enabled=False)
    check_idle("testm", mission)

    # After notification, idle_since should be cleared and idle_fired should be clear
    assert "testm" not in runtime_state.idle_since
    assert "testm" not in runtime_state.idle_fired


# ── CLI: keep config get / set ───────────────────────────────────


def test_cli_config_get_workers_enabled_default(_global_state):
    result = runner.invoke(app, ["config", "get", "workers_enabled"])
    assert result.exit_code == 0
    assert "true" in result.output


def test_cli_config_set_workers_enabled_false_then_get(_global_state):
    set_result = runner.invoke(app, ["config", "set", "workers_enabled", "false"])
    assert set_result.exit_code == 0
    assert "false" in set_result.output

    get_result = runner.invoke(app, ["config", "get", "workers_enabled"])
    assert get_result.exit_code == 0
    assert "false" in get_result.output


def test_cli_config_set_workers_enabled_true_then_get(_global_state):
    runner.invoke(app, ["config", "set", "workers_enabled", "false"])
    set_result = runner.invoke(app, ["config", "set", "workers_enabled", "true"])
    assert set_result.exit_code == 0

    get_result = runner.invoke(app, ["config", "get", "workers_enabled"])
    assert get_result.exit_code == 0
    assert "true" in get_result.output


def test_cli_config_get_unknown_key_exits_1(_global_state):
    result = runner.invoke(app, ["config", "get", "nonexistent_key"])
    assert result.exit_code == 1


def test_cli_config_set_unknown_key_exits_1(_global_state):
    result = runner.invoke(app, ["config", "set", "nonexistent_key", "blah"])
    assert result.exit_code == 1


def test_cli_config_set_invalid_value_exits_1(_global_state):
    result = runner.invoke(app, ["config", "set", "workers_enabled", "maybe"])
    assert result.exit_code == 1


# ── CLI: keep mission create --no-workers ────────────────────────


def test_cli_mission_create_no_workers_flag(_global_state):
    result = runner.invoke(app, ["mission", "create", "--no-workers"])
    assert result.exit_code == 0
    assert "workers_enabled=false" in result.output


def test_cli_mission_create_no_workers_sets_field(_global_state, tmp_path, monkeypatch):
    monkeypatch.setenv("KEEP_HOME", str(tmp_path))
    # Need global state in the new tmp_path
    gs = new_global()
    save_global(gs)

    result = runner.invoke(app, ["mission", "create", "--no-workers"])
    assert result.exit_code == 0

    # Find the mission name from output
    output = result.output.strip()
    # Output: "Mission '<id>' 已创建。..."
    import re
    m = re.search(r"Mission '([^']+)'", output)
    assert m, f"Could not find mission name in output: {output!r}"
    mission_name = m.group(1)

    mission = load_mission(mission_name)
    assert mission is not None
    assert mission.get("workers_enabled") is False


def test_cli_mission_create_default_no_workers_field(_global_state, tmp_path, monkeypatch):
    monkeypatch.setenv("KEEP_HOME", str(tmp_path))
    gs = new_global()
    save_global(gs)

    result = runner.invoke(app, ["mission", "create"])
    assert result.exit_code == 0
    assert "workers_enabled=false" not in result.output

    import re
    m = re.search(r"Mission '([^']+)'", result.output)
    assert m
    mission_name = m.group(1)

    mission = load_mission(mission_name)
    assert mission is not None
    assert "workers_enabled" not in mission


# ── CR-004: additional unit tests ───────────────────────────────────


def test_jsonl_age_missing_file():
    from keep._daemon.worker_check import jsonl_age
    participant = {"cache": {"jsonl_path": "/nonexistent/path/sup.jsonl"}}
    result = jsonl_age(participant, time.time())
    assert result is None


def test_is_workers_enabled_string_false_treated_as_disabled():
    """String 'false' in mission JSON must not be truthy."""
    create_mission("testm")
    with mutate_mission("testm") as m:
        m["workers_enabled"] = "false"
    assert is_workers_enabled("testm") is False


def test_is_workers_enabled_string_true_treated_as_enabled():
    create_mission("testm")
    with mutate_mission("testm") as m:
        m["workers_enabled"] = "true"
    assert is_workers_enabled("testm") is True


def test_check_idle_renotifies_after_second_timeout(tmp_path, monkeypatch, _clear_idle_runtime):
    """After reset, a second IDLE_TIMEOUT of silence fires a second notification."""
    from keep._daemon.constants import IDLE_TIMEOUT
    from keep._daemon import runtime_state

    create_mission("testm", workers_enabled=False)
    jsonl = tmp_path / "sup.jsonl"
    jsonl.write_text("{}", encoding="utf-8")

    stale_time = time.time() - IDLE_TIMEOUT - 10
    import os
    os.utime(jsonl, (stale_time, stale_time))

    # Pre-seed so first notification fires
    runtime_state.idle_since["testm"] = stale_time - IDLE_TIMEOUT

    notifications: list[str] = []
    monkeypatch.setattr("keep._daemon.idle.notify_supervisor", lambda _m, msg: notifications.append(msg))

    from keep._daemon.idle import check_idle
    mission = _make_mission("testm", jsonl_path=str(jsonl), workers_enabled=False)

    # First call — fires notification and resets tracking
    check_idle("testm", mission)
    assert len(notifications) == 1

    # Simulate another IDLE_TIMEOUT of silence: re-seed idle_since
    runtime_state.idle_since["testm"] = time.time() - IDLE_TIMEOUT - 1

    # Second call — should fire again
    check_idle("testm", mission)
    assert len(notifications) == 2
