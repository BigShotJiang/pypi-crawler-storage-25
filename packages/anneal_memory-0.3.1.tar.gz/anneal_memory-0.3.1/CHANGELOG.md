# Changelog

All notable changes to anneal-memory. Format is loosely [Keep a Changelog](https://keepachangelog.com/en/1.1.0/); this project uses [SemVer](https://semver.org/spec/v2.0.0.html).

## [0.3.1] — 2026-05-17

Phantom-re-save fix. `validated_save_continuity` now refuses to run when no wrap is in progress, closing a path where a second save in the same session — with no fresh `prepare_wrap` — would re-run the immune pass against an empty episode set, demote every citation, and inflate the session counter. The wrap is now structurally a once-per-session operation: `prepare_wrap` mints the snapshot, `save_continuity` consumes it, and a save with no snapshot is a hard error.

**Pre-1.0 policy reminder.** anneal-memory is in 0.x; breaking changes between minor *and patch* versions are possible. This release removes one return-dict field — see Breaking changes.

### Breaking changes

- **`validated_save_continuity` refuses a save with no wrap in progress.** Calling `validated_save_continuity` (or the MCP `save_continuity` tool / CLI `save-continuity` subcommand) with no wrap in progress now raises `ValueError("No wrap in progress…")`. "No wrap in progress" means any of: `prepare_wrap` was never called; `prepare_wrap` returned `status="empty"` for a zero-episode session (it cancels the wrap rather than starting one); or the session already completed its wrap (`wrap_completed` clears the snapshot). Previously a no-snapshot call fell through to a `skipped_prepare` path that re-fetched the full episode set and saved anyway — a documented foot-gun: after a completed wrap that set is empty, so graduation ran against zero valid episode IDs and demoted every 2x/3x citation, feedback an agent would "fix" by re-saving (a loop that also incremented `sessions_produced` each pass). A caller that runs `prepare_wrap` but does not check `status` before saving will now get this error on an empty session — guard with `if wrap["status"] == "ready"`. The wrap-state check is a precondition, evaluated *before* continuity-text validation, so a no-wrap save reports "No wrap in progress" rather than a misleading "missing sections" error. The canonical path is unchanged: `prepare_wrap` → compress → `validated_save_continuity`, once per session. Library users driving their own wrap lifecycle via a direct `store.wrap_started(token=…, episode_ids=…)` call are unaffected — that creates a snapshot.
- **`skipped_prepare` removed from `SaveContinuityResult`.** With the refusal above, the field could only ever be `False` — it is removed from the `SaveContinuityResult` TypedDict, the MCP `save_continuity` text response, and the CLI `save-continuity --json` output. Callers reading `result["skipped_prepare"]` will get a `KeyError`; drop the access — there is no longer a skipped-prepare state to report.

### Fixed

- **Phantom re-save inflated the session counter and re-ran the immune pass.** The structural refusal above closes this. The `wrap_token` machinery (minted by `prepare_wrap`, consumed by `wrap_completed`'s compare-and-swap) was already correct — v0.3.1 gates `validated_save_continuity` on the snapshot's presence so the consumed-once semantics are enforced, not merely available.

### Changed — docs

- **README MCP setup reworked; `server.json` updated.** The README's old single MCP config block lacked the `serve` subcommand and covered only one harness. v0.3.1 ships three verified, per-harness config blocks — Claude Code / Cursor / Windsurf (`mcpServers` JSON), Codex (`.codex/config.toml`), and Gemini CLI (`.gemini/settings.json`) — using the explicit `anneal-memory … serve` form, and `server.json` uses `serve` too. Note: bare no-subcommand startup (`anneal-memory --project-name X`) remains fully backward-compatible — `cli.main()` delegates to the server when no subcommand is given. `serve` is the explicit, recommended form, not a fix for a non-launching config.
- **"CLAUDE.md snippet" reframed to "agent-instructions snippet"** across the README, `docs/`, and the `examples/` snippet files, with placement guidance: `CLAUDE.md` for Claude Code, `AGENTS.md` for Codex, `GEMINI.md` for Gemini CLI. The snippet is harness-neutral, so the two example files are renamed to match — `CLAUDE.md.example` → `agent-instructions.example` and `CLAUDE.md.cli.example` → `agent-instructions.cli.example`. A stale "two-layer memory" line in those file headers was also corrected to "four-layer."
- **"Wrap once" guidance added** to both agent-instructions snippets and the README's Session Hygiene section: wrap exactly once per session, and a `save_continuity` report of demoted graduations is the immune system working, not an error to chase with a re-save.

### Test surface

- **704 → 707 tests.** Added `test_phantom_resave_after_completed_wrap_is_refused` (the core regression — a completed wrap followed by a second save raises, with no extra wrap row and no `sessions_produced` increment), `test_empty_prepare_wrap_then_save_is_refused` (an empty `prepare_wrap` is refused on save too), and `test_refusal_precedes_text_validation` (the wrap-state refusal wins over a structure error). The former `skipped_prepare` tests were repurposed — two now assert the refusal, one now exercises the low-level `store.wrap_completed` primitive directly. Cold `validated_save_continuity` / MCP-`save_continuity` call sites across the suite now run `prepare_wrap` first, exercising the canonical pipeline.

## [0.3.0] — 2026-05-01

Deprecation cleanup release. Removes the v0.2.0-deprecated `prepare_wrap_package()` public wrapper and the legacy no-arg form of `Store.wrap_started()`. Tightens both surfaces from runtime DeprecationWarning to call-site enforcement so the canonical pipeline has exactly one valid state machine. Bundles two Diogenes overnight LOWs and seven review-pass fixes from a four-layer code review pipeline (session-code-review + domain-expert + cross-substrate consultation + integration semantics).

**Pre-1.0 deprecation policy reminder.** anneal-memory is in 0.x. Breaking changes between minor versions are expected. Pin tightly (`anneal-memory>=0.2,<0.3`) if you depend on a specific public surface; the v0.2.x → v0.3.0 cycle removed two surfaces that emitted DeprecationWarning for one full minor cycle.

### Breaking changes

- **`prepare_wrap_package()` removed.** The public wrapper was deprecated in v0.2.0 and emitted `DeprecationWarning` directing callers to `prepare_wrap(store, ...)` for one full minor cycle (v0.2.0 → v0.2.3). It is now gone from `anneal_memory.continuity`, `anneal_memory.__init__`, and the package `__all__`. Callers using `from anneal_memory import prepare_wrap_package` or `from anneal_memory.continuity import prepare_wrap_package` will get `ImportError` on upgrade. Migration: use `prepare_wrap(store, *, max_chars=20000, staleness_days=7)` for the canonical pipeline (recommended), or call the private `_build_wrap_package()` helper directly if you genuinely need to construct a package from pre-fetched episodes without touching a store (no API stability guarantee — private symbol).
- **`Store.wrap_started()` signature tightened.** The legacy no-arg form was deprecated in v0.2.0 and emitted `DeprecationWarning("legacy call form")`. v0.3.0 removes the deprecation branch and tightens the signature: `wrap_started(*, token: str, episode_ids: list[str])` — both required keyword-only, no defaults. Calling `store.wrap_started()` with no args, or with only one of the two, now raises `TypeError` at the Python call site. Calling with `token=""` raises `ValueError("token must be non-empty")`. Calling with a non-list `episode_ids` (string, tuple, generator) raises `TypeError("episode_ids must be a list")`. The canonical pipeline (`prepare_wrap` → `validated_save_continuity`) was unaffected throughout the deprecation cycle; this signature tightening only affects callers that bypass the canonical pipeline by calling `wrap_started()` directly. Migration: pass `token=uuid.uuid4().hex, episode_ids=[]` for the empty-snapshot case, or `token=uuid.uuid4().hex, episode_ids=[<ep.id for ep in store.episodes_since_wrap()>]` for the snapshot case (or just call `prepare_wrap(store)` which does both for you).
- **`Store.wrap_started()` audit-log shape.** `wrap_started` audit events now always include `wrap_episode_count` and `wrap_episode_ids` fields (previously conditional — only present when `episode_ids` was non-empty). This restores forensic discrimination: an audit entry with `wrap_episode_count: 0` and `wrap_episode_ids: []` now means "agent explicitly started a wrap with no snapshot content" rather than "audit entry from a legacy version that didn't log these fields." Mixed pre-v0.3.0 / post-v0.3.0 audit logs (e.g. a long-running store upgraded mid-life) require shape-tolerant readers — branch on key presence with default value, not key-presence-as-signal. The asymmetry that justified the conditional logging (legacy no-arg form passed `None` and an empty list looked like the legacy default) no longer applies.

### Fixed — Diogenes overnight review (2 LOWs)

- **`store.py` `Store._batch()` rollback `_conn` guard.** Both rollback sites (`store.py` yield-wrapper at the `except BaseException:` block and the post-commit-failure rollback) called `self._conn.rollback()` inside `try/except sqlite3.Error: pass`. If `self._conn` is `None` (construction-failure path), `rollback()` raises `AttributeError`, which is NOT a `sqlite3.Error` subclass — the swallowing handler doesn't catch it, the `AttributeError` masks the primary exception. Both sites now guard with `if self._conn is not None:` before the rollback. The current invariant ("`_batch()` is unreachable when `_conn` is None") makes this defensive — but the guard preserves error-signal integrity if a future refactor widens the reachable state. The `AttributeError`-masks-primary-exception failure mode is real; the guard prevents it without changing any reachable code path today.
- **`store.py` `StoreError` "Raised by" enumeration drift.** The class-level docstring listed `_db_boundary`-wrapped methods inline and the enumeration omitted `wrap_completed` and `load_wrap_snapshot` (both public, both `_db_boundary`-wrapped, both hit the closed-store guard). v0.3.0 replaces the inline enumeration with a pointer to the canonical source of truth: grep at the call sites (`with self._db_boundary(...)`) — making the enumeration a structural lookup rather than a static list that can drift from the actual surface. The replacement narrative explicitly disambiguates the `_db_boundary`-wrapped subset (closed-store guard + SQLite errors) from file-write surfaces (`save_continuity`, `save_meta`, and their internal helpers `_prepare_continuity_write` / `_prepare_meta_write`) which raise `StoreError` from disk-full / permission failures rather than from the closed-store guard.

### Fixed — review-pass docstring + comment drift

The deprecation removal exposed several stale references to the removed APIs in places review of the API change itself didn't naturally surface. Layer 1+2 of the review pipeline caught these.

- **`load_wrap_snapshot()` docstring drift on Returns vs Raises.** Pre-v0.3.0 the docstring claimed Case 2 ("`wrap_started_at` set, `wrap_token` empty") returned `None` as a tolerated state. The implementation has raised `StoreError` on this state since v0.2.0 (10.5c.4 fix-pass). The docstring is now corrected: returns `None` only for the idle state; raises `StoreError` for partial-state metadata. Adds the explicit note that the canonical encoding for `episode_ids=[]` is the JSON string `"[]"` — accepted as a valid empty snapshot, not flagged as partial state.
- **`load_wrap_snapshot()` StoreError message references removed API.** The raise message named `store.wrap_started() with no arguments` as a possible cause. v0.3.0 removed that API path; the message now correctly names the remaining causes (mid-upgrade v0.1.x database with a stale legacy flag, or a manual metadata edit).
- **`validated_save_continuity` comment references removed API.** The comment in `continuity.py` at the snapshot-load boundary referenced "the 10.5c.4 Layer 1 finding where a caller could reach 'wrap_in_progress=True but snapshot absent' via a direct no-arg `store.wrap_started()` call." The no-arg call path no longer exists. Comment updated to reflect the v0.3.0 state: the API path that produced the partial state is removed; the `load_wrap_snapshot` integrity guard remains as belt-and-suspenders defense for mid-upgrade v0.1.x databases.
- **`_build_wrap_package` docstring used bare `store.wrap_started()` form.** Now uses canonical `store.wrap_started(token=..., episode_ids=...)` — the bare form would raise TypeError under v0.3.0.
- **`docs/library-quickstart.md` migration prose updated.** The deprecation notices for `prepare_wrap_package()` are now historical ("removed in v0.3.0") rather than active deprecation warnings. The canonical pipeline guidance is preserved unchanged.

### Fixed — review-pass code hygiene

- **`Store.wrap_started()` runtime type guard on `episode_ids`.** The signature requires `list[str]` but Python doesn't enforce type hints at runtime. Pre-fix, passing a string, tuple, or generator silently round-tripped through `list(episode_ids)`. The generator case was the load-bearing one: `list(generator)` exhausts the generator, then `len(episode_ids)` in the audit-log payload raises `TypeError` AFTER the SQL writes have already committed — leaving the store in a partial-state with no audit entry. The new explicit `isinstance(episode_ids, list)` guard fails fast at the entry point. The materialized `ids_list = list(episode_ids)` is now built once before the SQL transaction so the SQL path and the audit path see the same in-memory snapshot.
- **`test_prepare_wrap_canonical_pipeline_emits_no_deprecation` filter narrowed.** The regression gate previously caught any DeprecationWarning emitted during the canonical pipeline. Python stdlib upgrades (sqlite3, json, datetime, asyncio) sometimes surface DeprecationWarnings the canonical pipeline transitively touches; the broad gate would flake on those. Now filtered to anneal_memory-specific warnings (`if "anneal_memory" in (w.filename or "")`).

### Test surface

- **708 → 704 tests.** Net delta:
  - **Removed** (7): TestPrepareWrapPackage (9 tests on the deprecated wrapper) replaced 1:1 by TestBuildWrapPackage targeting the private helper (same coverage); TestPrepareWrapPackageDeprecation (7 tests on the deprecation machinery) replaced by 2 tests in TestCanonicalPipelineNoDeprecation (regression gate against any deprecated surface in the canonical pipeline); 3 deleted tests on the legacy `wrap_started()` no-arg form (`test_no_arg_wrap_started_then_canonical_save_raises`, `test_wrap_started_token_without_ids_raises`, `test_wrap_started_ids_without_token_raises`) — premises gone with the legacy form.
  - **Added** (3 structural-invariant tests): `test_wrap_started_missing_args_raises_typeerror` locks Python's required-kwargs enforcement at the call site (regression gate against accidentally re-adding defaults that would re-introduce the partial-state failure mode); `test_wrap_started_empty_token_raises` covers the remaining `ValueError` contract (empty token); `test_wrap_started_non_list_episode_ids_raises` covers the new isinstance guard including the generator atomicity hazard; `test_load_wrap_snapshot_empty_list_round_trip` locks the canonical empty-snapshot encoding round-trip (the whole correctness of `episode_ids=[]` hinges on `"[]"` being truthy in the partial-state guard, and pre-v0.3.0 no test exercised this round-trip — Layer 3 review caught the gap).
  - 12 test sites across `test_audit.py` (4) + `test_continuity.py` (1 + 1 still in the legacy-state-machine block + several new) + `test_store.py` (3) + `test_server.py` (2) + `test_associations.py` (1) rewritten from `with pytest.warns(DeprecationWarning, match="legacy call form"): store.wrap_started()` to canonical `store.wrap_started(token=uuid.uuid4().hex, episode_ids=[])`.
  - All 704 passing.

### Meta — review-pipeline calibration

The four-layer review pipeline (session-code-review + domain-expert + cross-substrate consultation + integration semantics) caught two non-trivial mechanism-accuracy errors *in the v0.3.0 docstring rewrites themselves* — exactly the failure mode the v0.2.3 calibration finding (`feedback_consultation_blind_to_mechanism_accuracy_errors_in_code_describing_prose`) warned about. Layer 2 (domain expert) caught the first: the rewritten StoreError docstring claimed "the canonical list of wrapped operations is the StoreOperation Literal," but the Literal includes file-write operation identifiers that are NOT `_db_boundary`-wrapped. Layer 3 (Complement) caught the second: after Layer 2's fix, the docstring still claimed file-write ops "have their own bullets above" — true for `save_continuity` and `save_meta`, false for the `_prepare_*_write` internal helpers. Both fixes shipped in this release.

Pattern lesson: when a previous release ships a calibration finding about a specific failure mode, the next release that touches the same surface must explicitly re-verify that surface against the failure mode. Consultation review is necessary but not sufficient for prose-describing-code — code-level verification (open the named function, confirm prose matches) remains non-replaceable. v0.3.0 ran two rounds of code-level verification on every docstring claim about code mechanism in the diff; the second round caught the surviving error from the first.

## [0.2.3] — 2026-04-30

Mechanism-accuracy precision pass on top of v0.2.2's positioning expansion. Two doc-only fixes from Diogenes overnight review of v0.2.2 (commit `1f8d82c`). No public API changes. No behavior change. Drop-in upgrade from v0.2.2.

### Fixed

- **README § Memory poisoning resistance — point 2 mechanism description was wrong.** v0.2.2 shipped point 2 as *"Anti-inbreeding catches sustained near-duplicate poisoning. ... the explanation-overlap check rejects citations whose content is too similar to the graduation claim — sustained poisoning that just repeats itself doesn't accumulate evidence weight."* The actual `check_explanation_overlap(explanation, episode_content)` function in `graduation.py:230` does the opposite comparison: it requires at least 2 meaningful words from the **explanation** to appear in the cited **episode's content**, catching ungrounded/fabricated explanations rather than near-duplicate content. v0.2.2's prose conflated the explanation-overlap check (anti-fraud) with citation-reuse caps in `detect_citation_gaming` (anti-repetition). Point 2 now describes what the code actually does: *"Explanation-grounding check rejects ungrounded citations."* Heading and mechanism description both corrected; the security argument is preserved (poisoned trajectories where the attacker controls graduation-claim text but cannot rewrite the cited episode body still fail this check) but the framing is now anti-fraud rather than anti-repetition.
- **`StoreError` class "Raised by" enumeration was missing the cross-method closed-store guard.** Every `_db_boundary`-wrapped public method (`record`, `get`, `delete`, `recall`, `episodes_since_wrap`, `status`, `wrap_started`, `wrap_cancelled`, `get_wrap_started_at`, `get_wrap_history`, `record_associations`, `decay_associations`, `get_associations`, `get_association_context`, `association_stats`, `prune`) raises bare `StoreError("Cannot {operation} on a closed store", operation=..., path=...)` via the boundary's pre-yield closed-state check (`store.py:2397`). v0.2.2's docstring documented `_db_boundary`'s `StoreDatabaseError` behavior but omitted this parallel `StoreError` path; callers writing `except StoreDatabaseError:` around a method on a possibly-closed store would miss the closed-store guard. Docstring now enumerates the wrapped methods and explicitly notes that `StoreDatabaseError` is NOT raised on this path because no SQL ran.

### Pattern note

Both fixes are siblings of the v0.2.1/v0.2.2 docstring-drift family at the same surface (parallel docstrings within `store.py`). Same generalization stands: when fixing a docstring-drift bug, check parallel docstrings + class-level enumerations for the same class of error before declaring fix complete.

### Meta — calibration finding

Both v0.2.2 sections that needed correction here passed full 3-agent consultation review (complement + contrarian + anansi) before commit. The reviewers caught calibration over-claims (eTAMP "structural defense" → "structural inference"; HeLa-Mem "convergent" → "adjacent"; Article 12 "increasingly read as" → predictive hedge) but did NOT catch that point 2 described the wrong code mechanism — because consultation agents do prose review, not code review. Operational lesson: for prose that describes implementation mechanisms (Security/§-Validation/§-Audit sections, "the X check rejects Y" claims), consultation is necessary but not sufficient. Code-level verification — opening the named function and confirming the prose matches — is non-replaceable. Saved as a calibration finding in flow's feedback memory; future docs-touching sessions on this codebase route prose-describing-code through both gates.

## [0.2.2] — 2026-04-29

Documentation precision pass — public README positioning expansion + StoreError docstring completeness fix. No public API changes. No data migration. Drop-in upgrade from v0.2.1.

### Added — README positioning sections

- **Security § Memory poisoning resistance.** New subsection citing the eTAMP attack class ("Poison Once, Exploit Forever," Zou et al., [arXiv:2604.02623](https://arxiv.org/abs/2604.02623), April 2026 — environment-injected memory poisoning against ChatGPT Atlas + Perplexity Comet + OpenClaw, 32.5% ASR on GPT-4-mini) and the three-mechanism partial defense the architecture provides: single-shot poisoning stalls at 1x (no continuity-layer influence without independent citations), anti-inbreeding catches sustained near-duplicate poisoning, SHA-256 audit trail provides forensic surface. Explicit "structural inference, not empirical defense — anneal-memory has not been tested against eTAMP directly" disclaimer; sustained adversarial campaigns with diverse contaminated trajectories can still graduate (the immune system bounds *cost* of poisoning attacks, not the possibility).
- **Consolidation Landscape § April 2026 adjacent architectures.** Names HeLa-Mem (Zhu et al., [arXiv:2604.16839](https://arxiv.org/abs/2604.16839), ACL 2026 accepted, explicit Hebbian + Reflective Agent) and GAM (Wu et al., [arXiv:2604.12285](https://arxiv.org/abs/2604.12285), April 2026 preprint, hierarchical graph-based — *not* classical Hebbian). Distinguishes by architecture-class AND peer-review status. Both decouple encoding from consolidation; neither has citation-validated quality gates. The differentiator is increasingly *what gates the consolidation*, not whether consolidation happens.
- **Compliance § Provenance vs timestamps.** Descriptive distinction between timestamp-only logs and provenance chains for Article 12 traceability. anneal-memory ships at the provenance-chain level (SHA-256-chained audit + citation-required graduation). Predictive hedge: as regulatory guidance and case law develop through August 2026 enforcement and after, this distinction may become a differential compliance gate. AWS AgentCore reference date-stamped to "April 2026 architecture" so the contrast doesn't bind to a moving target.

### Fixed — Diogenes overnight review (2 LOWs)

- `store.py` `StoreError` class "Raised by" enumeration was incomplete. Documented `Store.save_continuity`, `Store.save_meta`, `Store.load_wrap_snapshot`; was missing `Store.wrap_completed` (raises bare `StoreError` when `episode_ids` exceeds the SQLite IN-clause variable limit at line 1544) and `Store.close` (raises bare `StoreError` when called inside an active `_batch()` context at line 3006). Both are public methods callers invoke directly. Trailing summary line widened from "file-write + integrity paths" to "file-write + integrity + invariant-guard paths" to accurately reflect the close() guard.
- `store.py` `close()` Raises section documented only `StoreDatabaseError`. Now also documents the `StoreError` path raised when called inside `_batch()`, including caller guidance to widen `except StoreDatabaseError:` to `except StoreError:` if the guard surface matters to error handling.

### Pattern note

Both LOWs are siblings of the v0.2.1 `_db_boundary` docstring drift fix — same family (parallel docstrings within the same file) at different surfaces (class-level enumeration vs method-level Raises). Generalizes: when fixing a docstring-drift bug, check parallel docstrings + class-level enumerations for the same class of error before declaring fix complete.

### Meta

The README positioning sections went through 3-agent consultation review (complement + contrarian + anansi) before commit. Initial drafts over-claimed on multiple axes — calibrations applied: eTAMP "structural defense" → "structural inference, not empirical defense"; HeLa-Mem + GAM "convergent validators" → "adjacent architectures"; Article 12 "increasingly read as" → descriptive distinction + predictive hedge. All three claims are framed as inferential-rather-than-empirical; targeted empirical evaluation (e.g., direct eTAMP variant testing) is on the future-work surface, not in this release.

## [0.2.1] — 2026-04-14

Documentation-verification pass + tooling hardening. Every one of the 12 framework integration guides has now been exercised end-to-end against a live `pip install` of the framework; every guide header is pinned with a "Verified against" line. Combined with 10.5d's prior run of the top 5 (LangGraph, CrewAI, OpenAI Agents SDK, Pydantic AI, smolagents), the final hit rate across all 12 guides was 9/12 had load-bearing drift — 15 integration bugs total fixed between v0.2.0 and v0.2.1.

No public API changes. No data migration. Drop-in upgrade from v0.2.0.

### Fixed — framework integration guides

- **google-adk.** `BaseMemoryService.search_memory` signature was wrong — the real ADK protocol is `(*, app_name: str, user_id: str, query: str) -> SearchMemoryResponse` (keyword-only three-tuple), not `(query) -> dict`. `MemoryEntry.content` is a `google.genai.types.Content` wrapper, not a plain string. Consumer-side `tool_context.search_memory(query)` returns `SearchMemoryResponse` with a `.memories` attribute, not a dict with `"results"`. Rewrote the `AnnealMemoryService` example and the `tool_context.search_memory` usage snippet against live `google-adk 1.30.0`. Verified with a real `MemoryEntry` round-trip.
- **llamaindex.** `BaseMemoryBlock.name` is a required field; guide's `AnnealMemoryBlock` failed to declare it and raised `ValidationError` at construction. `_aput` signature drift — real API is `_aput(self, messages: list[ChatMessage]) -> None` (a list of messages, no `**kwargs`). Guide had `_aput(self, message, **kwargs)` singular, which would have silently no-op'd on every flush (`hasattr(list, "content")` is False) and recorded zero episodes. Verified with a real `ChatMessage` list round-trip against `llama-index-core 0.14.20`.
- **haystack.** `Tracer.trace` signature missing `parent_span` — real protocol is `(operation_name, tags=None, parent_span=None)` and Haystack internals pass it as a kwarg; guide's two-arg signature would have raised `TypeError` on first real invocation. Guide's custom tracer was also missing `current_span()` (abstract on base `Tracer`) and the span class was missing `set_tags` / `raw_span` / `get_correlation_data_for_logs` (Haystack internals call all of them). `AgentBreakpoint` API was completely wrong — guide used `AgentBreakpoint(break_after_agent_step=3)` which is not a real kwarg; the real dataclass is `AgentBreakpoint(agent_name: str, break_point: Breakpoint | ToolBreakpoint)`. Rewrote the breakpoint example with the correct `Breakpoint(component_name, visit_count)` wrapper. Verified against `haystack-ai 2.27.0`.
- **camel-ai.** `TaskDecomposedEvent` has no `task_id` field — a decomposition describes the edge from a parent task into its children, so the real fields are `parent_task_id` and `subtask_ids`. Guide accessed `event.task_id` which would have raised `AttributeError` the first time a workforce decomposed a task. Rewrote the `log_task_decomposed` recording to surface `parent_task_id` + the list of `subtask_ids`. Verified with all 11 `WorkforceCallback` abstract methods implemented and real event objects against `camel-ai 0.2.90`.

### Verified clean (no drift)

- **autogen / ag2** — verified against `ag2 0.11.5`. All three hooks (`update_agent_state`, `process_all_messages_before_reply`, `process_message_before_send`) fire with the exact signatures the guide uses. Confirmed against `ConversableAgent._process_message_before_send` source.
- **dspy** — verified against `dspy 3.1.3`. All 5 `BaseCallback` lifecycle hooks, `dspy.configure(callbacks=[...])`, `ChainOfThought` / `ReAct` / `Retrieve` / `LM` / `MIPROv2` surface, and the `MemoryAwareRAG` subclass pattern all verified. `dspy.Module` tracks sub-modules without `super().__init__()`.
- **anthropic-agents (claude-agent-sdk)** — verified against `claude-agent-sdk 0.1.59`. `ClaudeAgentOptions(setting_sources, hooks)`, `HookMatcher(hooks=[callable])`, async hook callback signature, all four hook event names (`Stop`, `PostToolUse`, `PreCompact`, `UserPromptSubmit`) verified against the real `Literal` union, `query(prompt, options)` signature, `Store.status().episodes_since_wrap` accessor.

### Fixed — Diogenes overnight review (3 LOWs)

- `store.py` `_db_boundary` docstring opening line drift. Said "any `sqlite3.Error` subclass"; implementation catches `sqlite3.DatabaseError` specifically (`InterfaceError` API-misuse bugs propagate bare by design — documented lower in the same docstring). Opening line now matches implementation.
- `store.py` `close()` inside `_batch()` context. Previously raised `"Cannot batch_commit on a closed store"` which attributed the failure to the wrong operation. Added explicit guard at top of `close()` that raises `StoreError("Cannot close() while inside _batch() context", operation="close")`.
- `pyproject.toml` `[tool.pytest.ini_options]` gained `filterwarnings = ["error::DeprecationWarning"]`. Local dev has always caught `DeprecationWarning` via `-W error`; CI did not enforce the same gate. All 707 tests remain green with the flag set — CI now catches any deprecation regression the dev environment would catch.

### Internal notes

- `assert`-for-mypy-narrowing count held at 3 sites (`continuity.py:505`, `continuity.py:897`, `server.py:153`). No current risk (`python -O` is uncommon in this codebase's deployment). Gate: if this reaches 5+ sites, evaluate whether `if not X: raise StoreError(...)` is cleaner than the assert idiom.
- `StoreOperation` Literal unchanged from v0.2.0 (25 values). The 10.5c.6 drift test still runs on every CI matrix job.

### Meta

The v0.2.0 → v0.2.1 delta is almost entirely "documentation drift caught by exercising the docs against reality." This reinforces the framework-guide maintenance cadence committed in v0.2.0: every ~8 weeks OR on a major framework release, whichever comes first. 12-of-12 guides now have pinned version headers, so the next verification pass can diff against a concrete baseline instead of reading the prose cold.

## [0.2.0] — 2026-04-14

Library-first release. The library is now the canonical product; MCP server and CLI are thin adapters that delegate to the same pipeline. Every public integration guide was exercised against a live `pip install` before release (Session 10.5d). Substantial hardening of the wrap pipeline: session-handshake token closes the prepare/save TOCTOU window, two-phase file/DB commit survives crashes in every intermediate state, all SQLite failures surface through a typed exception hierarchy with pickle-safe cross-process retry dispatch.

### Breaking changes

- **Engine removed.** The automated compression engine is gone. Compression is cognition — it must involve the agent's own judgment, not a delegated "engine" LLM. Every access pattern (library, MCP, CLI) now runs the same agent-driven pipeline: `prepare_wrap(store)` → agent compresses → `validated_save_continuity(store, text, ...)`. If you were importing or subclassing `Engine`, it no longer exists; rewrite to the canonical pipeline.
- **Exception hierarchy rebuilt.** `StoreError` no longer subclasses `OSError`. New hierarchy:
  - `AnnealMemoryError(Exception)` — library base, catches everything
  - `StoreError(AnnealMemoryError)` — file/path failures (continuity write, meta sidecar, tmp sidecar)
  - `StoreDatabaseError(StoreError)` — SQLite failures (locked DB, disk full, corruption, integrity violations after retries)
  Code that caught `except OSError` on store operations must migrate to `except StoreError` or `except AnnealMemoryError`. Code that caught `except StoreError` continues to work unchanged (it now catches both file-origin and DB-origin failures via the subclass relationship). We deliberately do not mirror PEP 249 / DB-API 2.0 — anneal-memory is a library consuming a database, not a driver.
- **`validated_save_continuity` return shape.** `wrap_result` is now a plain `dict[str, Any]` (via `dataclasses.asdict`) instead of a `WrapResult` dataclass. The entire `SaveContinuityResult` is JSON-serializable top-to-bottom. Library users who want the typed object can reconstruct it via `WrapResult(**result["wrap_result"])`.
- **`Store.wrap_started()` signature.** The no-arg form now emits `DeprecationWarning`. Canonical form adds keyword-only `token` + `episode_ids` parameters, used by the library pipeline to persist the frozen wrap snapshot.
- **`prepare_wrap_package` deprecated.** The pure helper still works but emits `DeprecationWarning`. The canonical entry point is `prepare_wrap(store, *, max_chars=None, staleness_days=None)` which runs the full pipeline: snapshot freezing, handshake token, wrap lifecycle. Scheduled for removal in v0.3.0.

### Added

- **Library canonical + thin transport adapters.** `anneal_memory.continuity` holds the canonical `prepare_wrap` and `validated_save_continuity` pipelines. MCP server and CLI transports parse their transport-native inputs, call the library, and format their transport-native outputs. A cross-transport parity test locks equivalence as a structural invariant — any future drift between the three access patterns breaks CI. This was triggered by Diogenes catching the `validated_save_continuity` implementation diverging from MCP/CLI 12 hours after v0.1.9's `10.5c` doc migration shipped.
- **`Store.get_wrap_history() → list[WrapRecord]`** — public read API for wrap history. Replaces the prior private `Store._conn` access in the history/diff/stats/export CLI subcommands.
- **`Store.load_wrap_snapshot() → WrapSnapshot | None`** — returns the frozen wrap-in-progress snapshot (token + episode IDs) or `None` on the legacy skipped_prepare path. Raises `StoreError` on partial-state integrity failures. External callers can use it for stuck-wrap diagnostics.
- **`Store.get_wrap_started_at() → str | None`** — public read-only accessor for the currently-in-flight wrap timestamp. Used by the new `wrap-status` CLI subcommand.
- **`format_wrap_package_text(result) → str`** — canonical text formatter for the wrap package, extracted from the CLI transport so library users and custom transports can reuse it.
- **`today` parameter on `validated_save_continuity`** — optional deterministic date override for test/experiment runs. Defaults to wall-clock `date.today().isoformat()`.
- **`wrap_token` parameter on `validated_save_continuity`** — optional keyword for explicit commit-atomic verification. When the caller round-trips the token from the prior `prepare_wrap` response, a mismatch raises `ValueError`. Without the token, the frozen-snapshot filter still applies because the library consults the persisted snapshot whenever it's present.
- **Session-handshake token (`10.5c.4`).** `prepare_wrap` mints `uuid.uuid4().hex` and persists it alongside the frozen episode-ID list in store metadata via `Store.wrap_started(token=..., episode_ids=...)`. `validated_save_continuity` filters its re-fetched episode set down to the snapshot and verifies the token via compare-and-swap `UPDATE` inside `wrap_completed`. Episodes recorded between prepare and save stay with `session_id IS NULL` and appear in the NEXT wrap's compression window — no data loss, no silent absorption. Transports round-trip the token: MCP via `Wrap token: <hex>` trailer + `wrap_token` tool arg with JSON schema pattern constraint `^[0-9a-f]{32}$`; CLI via `Wrap token: <hex>` trailer + `--wrap-token` flag.
- **Audit chain-of-custody enrichment.** New audit fields on wrap lifecycle events: `wrap_token` on all three (`wrap_started`, `wrap_cancelled`, `wrap_completed`), plus `wrap_episode_ids` + `wrap_episode_count` on `wrap_started` and `wrap_cancelled`. The audit trail alone can now reconstruct "which episodes went into wrap #N" by matching tokens — useful for cross-process forensics.
- **Two-phase commit pipeline (`10.5c.5`).** `validated_save_continuity` is now fully transactional across continuity.md + meta.json + SQLite DML:
  - New `Store._batch()` context manager accumulates DML inside a single SQLite transaction and defers audit events until after commit.
  - `Store._prepare_continuity_write(text, token_hex)` and `Store._prepare_meta_write(meta, token_hex)` write tmp sidecars with uuid-paired suffixes (`<stem>.<12hex>.md.tmp` / `<stem>.<12hex>.json.tmp`) so concurrent writers cannot collide and operators can group tmp files by prefix on recovery.
  - `Store._fsync_dir(path)` POSIX durability helper fsyncs the containing directory after `os.replace()` so crashes don't revert externalized filenames.
  - `PRAGMA synchronous=FULL` on connection init so `commit()` fsyncs the WAL — required for the 2PC "DB commit ⇒ durable" invariant.
  - DB commit happens BEFORE the file renames. Any crash before commit → full rollback (DB reverts, tmp sidecars can be left or cleaned). Any crash after commit → operator recovery via the preserved tmp sidecars (they are NOT unlinked on post-commit failure paths).
  - Startup orphan detection emits `warnings.warn(UserWarning, ...)` for any orphan tmp files from prior crashed pipelines, grouped by wrap_token prefix, with ready-to-copy `mv` recovery commands. In-flight tmp files matching the currently-active `wrap_token` are filtered out to avoid false positives during another writer's batch window.
  - macOS durability caveat documented: `os.fsync` is weaker than Linux; true durability on macOS would need `fcntl(F_FULLFSYNC)` which stdlib doesn't expose.
  - `record()` and `delete()` are now batch-aware (check `_defer_commit` + route audit through `_audit_log`). Outside a batch their behavior is unchanged.
- **SQLite error wrapping (`10.5c.6`).** `Store._db_boundary(operation)` context manager wraps every SQLite-touching block in every public Store method. Any `sqlite3.DatabaseError` escaping the block (including `OperationalError`, `IntegrityError` after retry exhaustion, `DatabaseError`) surfaces as `StoreDatabaseError` with the underlying exception attached via `__cause__`. The boundary catches `sqlite3.DatabaseError` specifically — not `sqlite3.Error` — so `InterfaceError` API-misuse programming bugs propagate bare with accurate stack traces. `StoreOperation` `Literal` expanded from 4 values to 25 (one per wrapped method); a CI drift test grep-scans `store.py` for every `_db_boundary()` + `operation=` literal and cross-references against `typing.get_args(StoreOperation)` with bidirectional equality assertion — structural drift protection, not discipline.
- **`cause_type_name: str | None`** on `StoreError` / `StoreDatabaseError`. Populated at raise time with `type(exc).__name__` and survives pickle / `copy.deepcopy`. Callers who need to branch on "retryable OperationalError vs non-retryable IntegrityError" after the exception has crossed a process boundary can dispatch on this string. `__cause__` does NOT survive pickle (standard Python limitation) — `cause_type_name` is the pickle-safe bridge.
- **Single generic pickle reconstructor.** `_reconstruct_store_error(cls, ...)` replaces parallel per-subclass functions. Adding new `StoreError` subclasses no longer requires writing a new reconstructor.
- **Idempotent `close()`.** `Store.close()` uses a `_closed: bool` flag with post-close hierarchy guard. Calling `close()` multiple times is safe. We deliberately do NOT null `_conn` — doing so caused an earlier regression where post-close calls raised bare `AttributeError` before reaching the `_db_boundary`, bypassing the hierarchy contract.
- **Three operator-surface CLI subcommands for stuck-wrap recovery:**
  - `anneal-memory wrap-status` — shows current wrap lifecycle state (idle / in-progress, token, started_at).
  - `anneal-memory wrap-cancel` — cancels an in-progress wrap and clears the snapshot.
  - `anneal-memory wrap-token-current` — prints the currently-active wrap_token for scripted recovery flows.
- **CLI: 24 total subcommands.** Operator surface (status, integrity, export, import, history, diff, stats, wrap-status, wrap-cancel, wrap-token-current) plus agent-driven compression (`prepare-wrap`, `save-continuity`) plus the standard episode CRUD and associations/Hebbian/limbic queries. `CLAUDE.md` snippet teaches agents the full cognitive workflow.
- **Framework integration guides verified against live packages (`10.5d`).** Every one of the 12 integration guides has been pinned to a real version and the top 5 were exercised end-to-end with `pip install` + working example code:
  - **LangGraph / LangChain** — verified clean against `langchain 1.2.15` + `langgraph 1.1.6`
  - **CrewAI** — verified against `crewai 1.14.1`; fixed 2 load-bearing bugs (`event.result_summary` → `event.output.raw`, `event.worker_id` → `event.output.agent`) that had silently broken multi-agent attribution
  - **OpenAI Agents SDK** — verified against `openai-agents 0.13.6`; fixed 2 bugs (`response.output[i].text` single-level traversal → nested `item.content[j].text`, `tool.name` unconditional access → `getattr` with class-name fallback for hosted tool types)
  - **Pydantic AI** — verified against `pydantic-ai 1.81.0`; fixed 6 bugs (`wrap_run` attribute → `run`, all hook callbacks keyword-only after `ctx`, param renames `request_ctx` → `request_context` and `tool_call` → `call`, `WrapRunHandler` is zero-arg, `@Agent.tool` class-level decorator replaced with plain function)
  - **smolagents** — verified against `smolagents 1.24.0`; fixed 1 bug (`agent.model([{dict}])` → `agent.model.generate(messages=[ChatMessage(...)])`)
- **TypedDict return shapes.** `PrepareWrapResult`, `SaveContinuityResult`, `WrapPackageDict`, `StalePatternDict`, `WrapSnapshot`. Library users get autocomplete and mypy-level key-typo detection; transport adapters can annotate their boundaries precisely. Drift tests assert the declared keys match the runtime dict keys.

### Changed

- **Tmp sidecar filenames now include unique uuid suffixes** (`<stem>.<12hex>.md.tmp`). Previous naming would collide under concurrent writers.
- **Atomic-write invariant widened.** The broad-cleanup path now fires on `finally`, not just `except OSError` — non-OSError failures no longer leave orphan tmp files.
- **`get_wrap_history` legacy swallow tightened.** Still silently returns `[]` for "no such table" (legacy path preserved), but any other database failure now surfaces as `StoreDatabaseError` with `operation="get_wrap_history"` instead of bare `sqlite3.OperationalError`.
- **Structured context on transport-surfaced errors.** MCP `server.py` and CLI `cli.py` both catch `StoreError` and surface `.operation` / `.path` context in their transport-native error payloads.
- **Constructor wrap.** `Store.__init__` wraps `connect` + PRAGMAs + `_init_schema` + `_warn_orphan_tmp_files` in `_db_boundary("schema_init")` with a local try/except so orphan detection failure doesn't abort construction.
- **Tombstone description corrected.** `integrity.py`'s `delete_episode` integrity description + `Store.delete()` docstring rewritten with the honest field list + GDPR framing + opt-out pointer. Regenerated `tool-integrity.json` + regression test.
- **`_tool_status()` audit health visibility.** New `AuditTrail.stats()` + 4 new `StoreStatus` fields expose audit chain length / verification state / last-event timestamp via both the MCP `status` tool and the CLI `status` subcommand.

### Fixed

- **Diogenes: `test_carried_forward_not_validated skipped_non_today`** — assertion tightened to the invariant it was supposed to guard.
- **Diogenes: CLI `--wrap-token` format validation** — `_WRAP_TOKEN_RE` moved from `server.py` to `store.py`, imported into both transports (fixes cli→server import inversion).
- **`close()` nulling `_conn` regression.** An earlier iteration of the close-idempotency work nulled `self._conn`, which meant post-close calls raised bare `AttributeError` before reaching the hierarchy. Replaced with the `_closed` flag approach that preserves the hierarchy contract.
- **Replay race on wrap commit (L3 codex).** Verify-then-act sequence between `Store.load_wrap_snapshot()` and `Store.wrap_completed()` had a concurrent-replay window. Moved the verify INTO the commit's atomic boundary as a compare-and-swap `UPDATE` inside `wrap_completed`.
- **Auto-prune regression in 2PC.** The commit-ordering change briefly made the post-wrap auto-prune run before the DB commit, which could silently drop episodes on crash. Moved auto-prune to its correct phase.
- **Residual-window data loss in 2PC.** Early Pass-1 of the two-phase commit had a window between file rename and DB commit where a crash could leave the file visible with no DB record. Closed by flipping the phase ordering (DB commit first, then file rename).
- **Recoverability-identity pairing (L3 codex).** Pre-fix, multiple crashed wraps produced unpaired `.md.tmp` + `.json.tmp` files with no way to group them for operator recovery. The new uuid suffixes are derived from the `wrap_token`, so one deterministic batch_id pairs both tmp files — a single structural fix eliminated three surface-level symptoms (pairing + false-positive warnings + warning-text accuracy).

### Test coverage

- **707 passing tests** (from 514 at v0.1.9 — net +193 across the v0.2.0 arc).
- Full 5-review-pass on 10.5c.6: L1 session-code-review (11 findings) + L2 Python stdlib/exception design expert (10) in parallel + L3 3-agent consultation (10) + L3.5 codex post-fix (3, including a HIGH regression the fix itself introduced) + L4 integration semantics (21/21 pass). All 34 findings addressed before release.

### Session lineage

v0.1.9 → v0.2.0 arc: sessions 10.5a (core CLI) → 10.5b (extended CLI + engine removal) → 10.5c (library-first positioning) → 10.5c.1 (rule-of-three elimination) → 10.5c.2 (doc canonical-entry migration) → 10.5c.3 (exception hierarchy + TypedDict) → 10.5c.4 (session-handshake token) → 10.5c.4a (operator surface) → 10.5c.5 (two-phase commit) → 10.5c.6 (SQLite error wrapping) → 10.5d (framework integration verification).

---

## [0.1.9] — 2026-04-08

Pre-v0.2.0 stability release. `delete_episode` MCP tool, README rewrite (grounding thesis + production failures), security Layer 2 (host-verifiable manifest resource), Diogenes warmup fixes.

## [0.1.8] — 2026-04-07

Hebbian associations (v2 Deep Hebbian — co-citation during consolidation) + limbic layer (affective state tagging on associations).

## [0.1.6] — 2026-04-03

Hardening release.

## [0.1.5] — 2026-04-02

Compliance layer: hash-chained JSONL audit trail, weekly rotation, actor identity, content-hash-only (GDPR-compatible), `on_event` callback.

## [0.1.0] — 2026-04-01

Initial PyPI release. Two-layer memory (episodic SQLite + continuity markdown), graduation pipeline, immune system, MCP server (stdio transport, newline-delimited JSON).

[0.2.0]: https://github.com/phillipclapham/anneal-memory/compare/v0.1.9...v0.2.0
[0.1.9]: https://github.com/phillipclapham/anneal-memory/releases/tag/v0.1.9
[0.1.8]: https://github.com/phillipclapham/anneal-memory/releases/tag/v0.1.8
[0.1.6]: https://github.com/phillipclapham/anneal-memory/releases/tag/v0.1.6
[0.1.5]: https://github.com/phillipclapham/anneal-memory/releases/tag/v0.1.5
[0.1.0]: https://github.com/phillipclapham/anneal-memory/releases/tag/v0.1.0
