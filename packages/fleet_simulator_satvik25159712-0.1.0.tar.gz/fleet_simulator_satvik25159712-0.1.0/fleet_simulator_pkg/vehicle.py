"""
vehicle.py
This file represents a single delivery vehicle with persistent state.
Each vehicle maintains its own position, speed, fuel and engine
temperature across telemetry ticks.
"""
import random

DEFAULT_LAT = 53.3498
DEFAULT_LON = -6.2603


class Vehicle:
    """
    A single fleet vehicle with state that updates each tick.
    """

    def __init__(self, vehicle_id, driver_name, route_id,
                 start_lat=DEFAULT_LAT, start_lon=DEFAULT_LON):
        self.vehicle_id = vehicle_id
        self.driver_name = driver_name
        self.route_id = route_id
        self.lat = start_lat
        self.lon = start_lon
        self.speed_kmh = 0.0
        self.fuel_percent = random.uniform(60.0, 100.0)
        self.engine_temp_c = random.uniform(75.0, 95.0)
        # Small random fault probability so some vehicles generate alerts
        self._fault_probability = random.uniform(0.0, 0.15)

    def update_state(self):
        """
        Advance vehicle state by one telemetry tick.
        Simulates realistic GPS drift, speed changes,
        fuel drain and occasional engine temperature spikes.
        """
        # Simulates a GPS movement 
        self.lat += random.uniform(-0.005, 0.005)
        self.lon += random.uniform(-0.005, 0.005)

        # speed transitions
        speed_delta = random.uniform(-15, 15)
        self.speed_kmh = max(0.0, min(110.0, self.speed_kmh + speed_delta))

        # Fuel drains proportionally to speed
        fuel_drain = (self.speed_kmh / 100.0) * random.uniform(0.05, 0.2)
        self.fuel_percent = max(5.0, self.fuel_percent - fuel_drain)

        # Engine temp — occasionally made to spike on faulty vehicles
        if random.random() < self._fault_probability:
            self.engine_temp_c = random.uniform(105.0, 120.0)
        else:
            temp_delta = random.uniform(-2, 2)
            self.engine_temp_c = max(75.0, min(95.0,
                                    self.engine_temp_c + temp_delta))

    def to_dict(self):
        """Serialise current state to a dict for JSON encoding."""
        return {
            "vehicle_id":    self.vehicle_id,
            "driver_name":   self.driver_name,
            "route_id":      self.route_id,
            "lat":           round(self.lat, 6),
            "lon":           round(self.lon, 6),
            "speed_kmh":     round(self.speed_kmh, 2),
            "fuel_percent":  round(self.fuel_percent, 2),
            "engine_temp_c": round(self.engine_temp_c, 2),
        }