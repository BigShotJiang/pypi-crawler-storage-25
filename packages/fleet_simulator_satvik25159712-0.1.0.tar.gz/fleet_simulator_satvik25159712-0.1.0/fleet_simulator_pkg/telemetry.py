"""
telemetry.py
A timestamped snapshot of one vehicle at one point in time.
This is the payload sent to AWS API Gateway.
"""
import datetime


class TelemetryReading:
    """
    Immutable snapshot of a vehicle's state at a single moment.
    """

    def __init__(self, vehicle_id, driver_name, route_id,
                 lat, lon, speed_kmh, fuel_percent, engine_temp_c):
        self.vehicle_id   = vehicle_id
        self.driver_name  = driver_name
        self.route_id     = route_id
        self.timestamp    = datetime.datetime.now(
                                datetime.timezone.utc).isoformat()
        self.lat          = lat
        self.lon          = lon
        self.speed_kmh    = speed_kmh
        self.fuel_percent = fuel_percent
        self.engine_temp_c = engine_temp_c

    @classmethod
    def from_vehicle(cls, vehicle):
        """Create a reading directly from a Vehicle instance."""
        return cls(
            vehicle_id    = vehicle.vehicle_id,
            driver_name   = vehicle.driver_name,
            route_id      = vehicle.route_id,
            lat           = vehicle.lat,
            lon           = vehicle.lon,
            speed_kmh     = vehicle.speed_kmh,
            fuel_percent  = vehicle.fuel_percent,
            engine_temp_c = vehicle.engine_temp_c,
        )

    def to_dict(self):
        """Serialise to a flat dict for JSON encoding."""
        return {
            "vehicle_id":    self.vehicle_id,
            "driver_name":   self.driver_name,
            "route_id":      self.route_id,
            "timestamp":     self.timestamp,
            "lat":           self.lat,
            "lon":           self.lon,
            "speed_kmh":     self.speed_kmh,
            "fuel_percent":  self.fuel_percent,
            "engine_temp_c": self.engine_temp_c,
        }