"""
simulator.py
Manages a fleet of Vehicle objects and drives the telemetry loop.
Sends TelemetryReading objects to AWS API Gateway via HTTP POST.
"""
import json
import time
import urllib.request
import urllib.error
from .vehicle import Vehicle
from .telemetry import TelemetryReading

DEFAULT_FLEET = [
    {"vehicle_id": "VAN-001", "driver_name": "Raghu Bandi",  "route_id": "ROUTE-D1"},
    {"vehicle_id": "VAN-002", "driver_name": "Manju Kolar",  "route_id": "ROUTE-D2"},
    {"vehicle_id": "VAN-003", "driver_name": "Shubham Dube", "route_id": "ROUTE-D3"},
    {"vehicle_id": "VAN-004", "driver_name": "Pranith Raj", "route_id": "ROUTE-D4"},
    {"vehicle_id": "VAN-005", "driver_name": "Nikhil Bandi", "route_id": "ROUTE-D5"},
]


class FleetSimulator:
    """
    Manages a fleet of vehicles and drives a continuous telemetry loop.
    """

    def __init__(self, fleet_config=None, api_url=None, api_key=None):
        """
        Initialise with a fleet and optional API target.

        Args:
            fleet_config (list): List of dicts with vehicle_id,
                driver_name, route_id. Uses DEFAULT_FLEET if None.
            api_url (str): API Gateway endpoint URL.
            api_key (str): Optional x-api-key header value.
        """
        config = fleet_config if fleet_config is not None else DEFAULT_FLEET
        self.vehicles = [
            Vehicle(v["vehicle_id"], v["driver_name"], v["route_id"])
            for v in config
        ]
        self.api_url = api_url
        self.api_key = api_key

    def generate_readings(self):
        """Advance all vehicles one tick. Returns list of TelemetryReadings."""
        readings = []
        for vehicle in self.vehicles:
            vehicle.update_state()
            readings.append(TelemetryReading.from_vehicle(vehicle))
        return readings

    def send_reading(self, reading):
        """
        POST a single TelemetryReading to API Gateway.
        Returns True on HTTP 200/201/202, False on failure.
        """
        if not self.api_url:
            return False
        payload = json.dumps(reading.to_dict()).encode("utf-8")
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["x-api-key"] = self.api_key
        req = urllib.request.Request(
            self.api_url, data=payload, headers=headers, method="POST"
        )
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                return resp.status in (200, 201, 202)
        except urllib.error.URLError as e:
            print(f"  [ERROR] {reading.vehicle_id}: {e}")
            return False

    def run(self, interval_seconds=5.0, max_ticks=None,
            dry_run=False, on_reading=None):
        """
        Start the simulation loop.

        Args:
            interval_seconds (float): Pause between ticks.
            max_ticks (int): Stop after this many ticks. None = run forever.
            dry_run (bool): Print to console instead of sending to AWS.
            on_reading (callable): Optional callback per reading.
        """
        tick = 0
        print(f"[FleetSimulator] Starting — {len(self.vehicles)} vehicles, "
              f"interval={interval_seconds}s, dry_run={dry_run}")
        try:
            while True:
                tick += 1
                readings = self.generate_readings()
                for reading in readings:
                    if dry_run or not self.api_url:
                        print(f"  [tick {tick:04d}] {reading.vehicle_id} | "
                              f"speed={reading.speed_kmh:.1f}km/h | "
                              f"fuel={reading.fuel_percent:.1f}% | "
                              f"temp={reading.engine_temp_c:.1f}C")
                    else:
                        ok = self.send_reading(reading)
                        print(f"  [tick {tick:04d}] {reading.vehicle_id} → "
                              f"{'OK' if ok else 'FAIL'}")
                    if on_reading:
                        on_reading(reading)
                if max_ticks and tick >= max_ticks:
                    print(f"[FleetSimulator] Done — {max_ticks} ticks.")
                    break
                time.sleep(interval_seconds)
        except KeyboardInterrupt:
            print("\n[FleetSimulator] Stopped.")

    def get_fleet_summary(self):
        """Return current state of all vehicles as a list of dicts."""
        return [v.to_dict() for v in self.vehicles]