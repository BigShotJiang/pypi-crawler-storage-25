"""
test_simulator.py
Unit tests for fleet_simulator_pkg.
Run with: python3 -m pytest tests/ -v
"""
from fleet_simulator_pkg.vehicle import Vehicle
from fleet_simulator_pkg.telemetry import TelemetryReading
from fleet_simulator_pkg.simulator import FleetSimulator


class TestVehicle:

    def test_initialises_with_correct_id(self):
        v = Vehicle("VAN-001", "Raghu Bandi", "ROUTE-D1")
        assert v.vehicle_id == "VAN-001"

    def test_fuel_starts_within_range(self):
        v = Vehicle("VAN-001", "Raghu Bandi", "ROUTE-D1")
        assert 60.0 <= v.fuel_percent <= 100.0

    def test_fuel_drains_after_updates(self):
        v = Vehicle("VAN-001", "Raghu Bandi", "ROUTE-D1")
        initial = v.fuel_percent
        for _ in range(20):
            v.update_state()
        assert v.fuel_percent <= initial

    def test_speed_stays_within_bounds(self):
        v = Vehicle("VAN-001", "Raghu Bandi", "ROUTE-D1")
        for _ in range(50):
            v.update_state()
        assert 0.0 <= v.speed_kmh <= 110.0

    def test_to_dict_has_all_keys(self):
        v = Vehicle("VAN-001", "Raghu Bandi", "ROUTE-D1")
        keys = set(v.to_dict().keys())
        assert keys == {"vehicle_id", "driver_name", "route_id",
                        "lat", "lon", "speed_kmh",
                        "fuel_percent", "engine_temp_c"}


class TestTelemetryReading:

    def test_from_vehicle_captures_id(self):
        v = Vehicle("VAN-002", "Manju Kolar", "ROUTE-D2")
        r = TelemetryReading.from_vehicle(v)
        assert r.vehicle_id == "VAN-002"

    def test_timestamp_is_utc_iso(self):
        v = Vehicle("VAN-002", "Manju Kolar", "ROUTE-D2")
        r = TelemetryReading.from_vehicle(v)
        assert "T" in r.timestamp
        assert "+" in r.timestamp or "Z" in r.timestamp

    def test_to_dict_includes_timestamp(self):
        v = Vehicle("VAN-003", "Shubham Dube", "ROUTE-D3")
        d = TelemetryReading.from_vehicle(v).to_dict()
        assert "timestamp" in d


class TestFleetSimulator:

    def test_default_fleet_has_five_vehicles(self):
        sim = FleetSimulator()
        assert len(sim.vehicles) == 5

    def test_custom_fleet_config(self):
        sim = FleetSimulator(fleet_config=[
            {"vehicle_id": "T-01", "driver_name": "Arun", "route_id": "R1"},
        ])
        assert len(sim.vehicles) == 1
        assert sim.vehicles[0].vehicle_id == "T-01"

    def test_generate_readings_count(self):
        sim = FleetSimulator()
        assert len(sim.generate_readings()) == 5

    def test_callback_fires_for_each_reading(self):
        sim = FleetSimulator()
        collected = []
        sim.run(interval_seconds=0, max_ticks=2,
                dry_run=True, on_reading=lambda r: collected.append(r))
        assert len(collected) == 10  
        # 5 vehicles x 2 ticks
        