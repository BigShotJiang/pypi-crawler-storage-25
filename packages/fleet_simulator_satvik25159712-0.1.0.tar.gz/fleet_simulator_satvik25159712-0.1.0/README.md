# fleet-simulator-satvik25159712

Reusable Python library for simulating delivery vehicle fleet telemetry.
Generates GPS, speed, fuel and engine temperature readings and posts
them to AWS API Gateway.

## Install
pip install fleet-simulator-satvik25159712

## Quick start
from fleet_simulator_pkg import FleetSimulator
sim = FleetSimulator()
sim.run(dry_run=True, max_ticks=5)