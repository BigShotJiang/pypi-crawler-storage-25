"""
Local Evaluator — runs the DriftGard evaluation engine locally via WASM.
No prompt/response data leaves the customer environment.

Requires Node.js 18+ installed (uses wasm-bindgen JS glue).
"""

import json
import os
import subprocess
from typing import Any, Dict

_WASM_DIR = os.path.join(os.path.dirname(__file__), "wasm")


def evaluate_local(control_pack: Dict[str, Any], request: Dict[str, Any]) -> Dict[str, Any]:
    """
    Run evaluation locally via WASM.

    Args:
        control_pack: The cached control pack object.
        request: The evaluation request (prompt, response, tool_call, identity, etc.)

    Returns:
        The verdict dict: { allowed, risk_score, violations, flags }

    Raises:
        RuntimeError: If Node.js is not available or WASM evaluation fails.
    """
    cp_json = json.dumps(control_pack)
    req_json = json.dumps(request)

    script = (
        "const { evaluate } = require('./driftgard_evaluator.js');\n"
        f"console.log(evaluate({json.dumps(cp_json)}, {json.dumps(req_json)}));\n"
    )

    try:
        result = subprocess.run(
            ["node", "-e", script],
            capture_output=True,
            text=True,
            cwd=_WASM_DIR,
            timeout=10,
        )
    except FileNotFoundError:
        raise RuntimeError(
            "Node.js not found. Local evaluation requires Node.js 18+. "
            "Install from https://nodejs.org/"
        )
    except subprocess.TimeoutExpired:
        raise RuntimeError("WASM evaluation timed out (10s)")

    if result.returncode != 0:
        raise RuntimeError(f"WASM evaluation failed: {result.stderr.strip()}")

    return json.loads(result.stdout)
