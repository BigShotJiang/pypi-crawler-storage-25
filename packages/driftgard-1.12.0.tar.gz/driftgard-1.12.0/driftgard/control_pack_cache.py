"""
Control Pack Cache — fetches and caches the active control pack for local evaluation.

On init: fetches the active control pack from the DriftGard API.
Background: refreshes on a configurable interval via a daemon thread.
Stale pack: uses last-known-good if refresh fails. Raises if no pack exists.
"""

import threading
import time
from typing import Any, Callable, Dict, Optional

import requests


class ControlPackCache:
    def __init__(
        self,
        api_key: str,
        base_url: str,
        project_id: str,
        refresh_interval_seconds: float = 60.0,
        timeout: int = 10,
        on_refresh: Optional[Callable[[Dict[str, Any]], None]] = None,
    ):
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._project_id = project_id
        self._refresh_interval = refresh_interval_seconds
        self._timeout = timeout
        self._on_refresh = on_refresh

        self._control_pack: Optional[Dict[str, Any]] = None
        self._control_pack_id: Optional[str] = None
        self._control_pack_version: int = 0
        self._last_refreshed_at: Optional[str] = None
        self._stale: bool = False
        self._timer: Optional[threading.Timer] = None
        self._stopped = False

    def init(self) -> None:
        """Fetch the active control pack. Must be called before evaluating."""
        self._refresh()
        self._schedule_refresh()

    def destroy(self) -> None:
        """Stop background refresh."""
        self._stopped = True
        if self._timer:
            self._timer.cancel()
            self._timer = None

    def get_control_pack(self) -> Dict[str, Any]:
        """Get the cached control pack. Raises if no pack is available."""
        if self._control_pack is None:
            raise RuntimeError(
                "No control pack available. Call init() first or check that "
                "the project has an active control pack."
            )
        return self._control_pack

    def get_meta(self) -> Dict[str, Any]:
        """Get cache metadata for audit reporting."""
        return {
            "control_pack_id": self._control_pack_id,
            "version": self._control_pack_version,
            "stale": self._stale,
            "last_refreshed_at": self._last_refreshed_at,
        }

    def _refresh(self) -> None:
        url = f"{self._base_url}/audit/cli/control-packs/active"
        try:
            res = requests.get(
                url,
                params={"project_id": self._project_id},
                headers={"x-api-key": self._api_key},
                timeout=self._timeout,
            )
            res.raise_for_status()
            data = res.json()
            cp = data.get("control_pack")
            if not cp:
                raise RuntimeError("No active control pack found for this project")

            self._control_pack = cp
            self._control_pack_id = cp.get("control_pack_id", "")
            self._control_pack_version = int(cp.get("version", 0))
            self._last_refreshed_at = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
            self._stale = False

            if self._on_refresh:
                self._on_refresh({"success": True, "version": self._control_pack_version})

        except Exception as e:
            msg = str(e)
            if self._control_pack:
                self._stale = True
                if self._on_refresh:
                    self._on_refresh({
                        "success": False,
                        "error": msg,
                        "stale": True,
                        "version": self._control_pack_version,
                    })
            else:
                if self._on_refresh:
                    self._on_refresh({"success": False, "error": msg})
                raise RuntimeError(f"Failed to fetch control pack: {msg}")

    def _schedule_refresh(self) -> None:
        if self._stopped or self._refresh_interval <= 0:
            return
        self._timer = threading.Timer(self._refresh_interval, self._background_refresh)
        self._timer.daemon = True
        self._timer.start()

    def _background_refresh(self) -> None:
        if self._stopped:
            return
        try:
            self._refresh()
        except Exception:
            pass  # Already handled in _refresh
        self._schedule_refresh()
