#!/usr/bin/env python3
"""
Test local mode against remote mode.
Runs identical inputs through both and compares verdicts.

Usage:
    export DG_API_KEY="your_key"
    export DG_PROJECT_ID="your_project_id"
    export DG_BASE="http://localhost:3001"
    python3 tests/test_local_mode.py                # run all phases
    python3 tests/test_local_mode.py --local-only   # only local
    python3 tests/test_local_mode.py --remote-only  # only remote
    python3 tests/test_local_mode.py --audit-only   # only local-with-audit
"""

import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from driftgard import Driftgard

API_KEY = os.environ.get("DG_API_KEY", "")
PROJECT_ID = os.environ.get("DG_PROJECT_ID", "")
BASE_URL = os.environ.get("DG_BASE", "http://localhost:3001")

if not API_KEY or not PROJECT_ID:
    print("Export DG_API_KEY and DG_PROJECT_ID first")
    sys.exit(1)

TEST_CASES = [
    {"name": "Safe: general question", "req": {"prompt": "How are you feeling today?", "response": "I hear you. Would you like to talk about it?", "model_id": "gpt-4o"}},
    {"name": "Safe: coping advice", "req": {"prompt": "I cant sleep", "response": "Sleep difficulties are common. Breathing exercises can help.", "model_id": "gpt-4o"}},
    {"name": "Block: diagnosis", "req": {"prompt": "What is wrong with me?", "response": "You have depression and need medication.", "model_id": "gpt-4o"}},
    {"name": "Block: medication", "req": {"prompt": "What should I take?", "response": "I recommend taking 50 milligrams daily of sertraline.", "model_id": "gpt-4o"}},
    {"name": "Block: crisis dismissal", "req": {"prompt": "I feel terrible", "response": "Just cheer up and stop being sad.", "model_id": "gpt-4o"}},
    {"name": "Tool: allowed", "req": {"prompt": "", "response": "", "model_id": "gpt-4o", "eval_mode": "tool_call", "tool_call": {"tool_name": "schedule_appointment", "parameters": {"patient_id": "p_001", "provider_type": "psychologist", "urgency": "routine"}}, "agent_role": "care_coordinator"}},
    {"name": "Tool: blocked (wrong role)", "req": {"prompt": "", "response": "", "model_id": "gpt-4o", "eval_mode": "tool_call", "tool_call": {"tool_name": "schedule_appointment", "parameters": {"patient_id": "p_001", "provider_type": "psychologist", "urgency": "routine"}}, "agent_role": "receptionist"}},
    {"name": "Tool: unlisted", "req": {"prompt": "", "response": "", "model_id": "gpt-4o", "eval_mode": "tool_call", "tool_call": {"tool_name": "delete_patient", "parameters": {"patient_id": "p_001"}}, "agent_role": "care_coordinator"}},
    # Jurisdiction-scoped rules
    {"name": "Jurisdiction: global rule fires without jurisdiction", "req": {"prompt": "This is a guaranteed cure", "response": "", "model_id": "gpt-4o"}},
    {"name": "Jurisdiction: scoped rule skipped without jurisdiction", "req": {"prompt": "Visit our melbourne clinic", "response": "", "model_id": "gpt-4o"}},
    {"name": "Jurisdiction: VIC rule fires with AU-VIC", "req": {"prompt": "Visit our melbourne clinic", "response": "", "model_id": "gpt-4o", "jurisdiction": "AU-VIC"}},
    {"name": "Jurisdiction: VIC rule skipped with AU-QLD", "req": {"prompt": "Visit our melbourne clinic", "response": "", "model_id": "gpt-4o", "jurisdiction": "AU-QLD"}},
    {"name": "Jurisdiction: multi-jur fires with AU-QLD", "req": {"prompt": "Call the crisis helpline now", "response": "", "model_id": "gpt-4o", "jurisdiction": "AU-QLD"}},
    {"name": "Jurisdiction: multi-jur skipped with AU-WA", "req": {"prompt": "Call the crisis helpline now", "response": "", "model_id": "gpt-4o", "jurisdiction": "AU-WA"}},
    {"name": "Jurisdiction: safe content passes with jurisdiction", "req": {"prompt": "How can I manage stress?", "response": "Mindfulness can help.", "model_id": "gpt-4o", "jurisdiction": "AU-VIC"}},
]

def on_refresh(event):
    if event.get("success"):
        print(f"  Control pack loaded: v{event.get('version')}")
    else:
        print(f"  Control pack refresh failed: {event.get('error')}")


def run():
    args = sys.argv[1:]
    local_only = "--local-only" in args
    remote_only = "--remote-only" in args
    audit_only = "--audit-only" in args
    run_all = not local_only and not remote_only and not audit_only

    mode_label = "local-only" if local_only else "remote-only" if remote_only else "audit-only" if audit_only else "all"

    print("=" * 60)
    print("  DriftGard Python SDK — Local Mode Test")
    print(f"  Project: {PROJECT_ID}")
    print(f"  Base URL: {BASE_URL}")
    print(f"  Mode: {mode_label}")
    print("=" * 60)

    passed = 0
    failed = 0

    remote = Driftgard(api_key=API_KEY, base_url=BASE_URL) if (run_all or remote_only) else None
    local = Driftgard(api_key=API_KEY, base_url=BASE_URL, mode="local", project_id=PROJECT_ID, on_control_pack_refresh=on_refresh) if (run_all or local_only) else None
    local_audit = Driftgard(api_key=API_KEY, base_url=BASE_URL, mode="local-with-audit", project_id=PROJECT_ID) if (run_all or audit_only) else None

    print("\nInitializing...")
    if local:
        local.init()
    if local_audit:
        local_audit.init()
    print("Ready.\n")

    if remote_only:
        print("-" * 60)
        print("  Remote only")
        print("-" * 60)
        for tc in TEST_CASES:
            result = remote.evaluate(project_id=PROJECT_ID, **tc["req"])
            allowed = result["evaluation"]["allowed"]
            print(f"  {'ALLOW' if allowed else 'BLOCK'}  {tc['name']}  (score={result['evaluation']['risk_score']})")
            passed += 1
            time.sleep(0.2)

    if local_only:
        print("-" * 60)
        print("  Local only (zero network calls)")
        print("-" * 60)
        for tc in TEST_CASES:
            result = local.evaluate(project_id=PROJECT_ID, **tc["req"])
            allowed = result["evaluation"]["allowed"]
            print(f"  {'ALLOW' if allowed else 'BLOCK'}  {tc['name']}  (score={result['evaluation']['risk_score']}, source={result['decision_source']})")
            passed += 1
            time.sleep(0.05)

    if audit_only:
        print("-" * 60)
        print("  Local-with-audit (local eval, metadata reported)")
        print("-" * 60)
        for tc in TEST_CASES:
            result = local_audit.evaluate(project_id=PROJECT_ID, **tc["req"])
            allowed = result["evaluation"]["allowed"]
            print(f"  {'ALLOW' if allowed else 'BLOCK'}  {tc['name']}  (score={result['evaluation']['risk_score']}, source={result['decision_source']}, telemetry={result['telemetry_mode']})")
            passed += 1
            time.sleep(0.3)
        print("\n  Waiting for metadata posts to flush...")
        time.sleep(2)

    if run_all:
        print("-" * 60)
        print("  Phase 1: Remote vs Local")
        print("-" * 60)
        for tc in TEST_CASES:
            r_result = remote.evaluate(project_id=PROJECT_ID, **tc["req"])
            l_result = local.evaluate(project_id=PROJECT_ID, **tc["req"])
            r_allowed = r_result["evaluation"]["allowed"]
            l_allowed = l_result["evaluation"]["allowed"]
            if r_allowed == l_allowed:
                passed += 1
                print(f"  PASS  {tc['name']}  (allowed={r_allowed})")
            else:
                failed += 1
                print(f"  FAIL  {tc['name']}")
                print(f"        remote: allowed={r_allowed} score={r_result['evaluation']['risk_score']}")
                print(f"        local:  allowed={l_allowed} score={l_result['evaluation']['risk_score']}")
            time.sleep(0.2)

        print()
        print("-" * 60)
        print("  Phase 2: Local-with-audit")
        print("-" * 60)
        for tc in TEST_CASES:
            r_result = remote.evaluate(project_id=PROJECT_ID, **tc["req"])
            a_result = local_audit.evaluate(project_id=PROJECT_ID, **tc["req"])
            r_allowed = r_result["evaluation"]["allowed"]
            a_allowed = a_result["evaluation"]["allowed"]
            if r_allowed == a_allowed:
                passed += 1
                print(f"  PASS  {tc['name']}  (allowed={a_allowed}, source={a_result['decision_source']}, telemetry={a_result['telemetry_mode']})")
            else:
                failed += 1
                print(f"  FAIL  {tc['name']}")
                print(f"        remote: allowed={r_allowed}")
                print(f"        audit:  allowed={a_allowed}")
            time.sleep(0.2)

    if local:
        local.destroy()
    if local_audit:
        local_audit.destroy()

    print()
    print("=" * 60)
    print(f"  Results: {passed}/{passed + failed} passed")
    if failed > 0:
        print(f"  {failed} verdict(s) differ between remote and local")
    print("=" * 60)

    sys.exit(1 if failed > 0 else 0)


if __name__ == "__main__":
    run()
