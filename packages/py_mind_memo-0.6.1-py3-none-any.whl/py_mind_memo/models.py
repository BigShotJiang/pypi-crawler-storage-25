import uuid
from typing import List, Optional

class Reference:
    """トピック間の参照関係を表すクラス"""
    def __init__(self, source_id: str, target_id: str):
        self.id = str(uuid.uuid4())
        self.source_id = source_id
        self.target_id = target_id
        # 制御点の相対または絶対座標。Noneの場合は描画時に自動計算
        self.cp1_x: Optional[float] = None
        self.cp1_y: Optional[float] = None
        self.cp2_x: Optional[float] = None
        self.cp2_y: Optional[float] = None

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "source_id": self.source_id,
            "target_id": self.target_id,
            "cp1_x": self.cp1_x,
            "cp1_y": self.cp1_y,
            "cp2_x": self.cp2_x,
            "cp2_y": self.cp2_y
        }

    @classmethod
    def from_dict(cls, data: dict) -> 'Reference':
        ref = cls(data["source_id"], data["target_id"])
        ref.id = data.get("id", str(uuid.uuid4()))
        ref.cp1_x = data.get("cp1_x")
        ref.cp1_y = data.get("cp1_y")
        ref.cp2_x = data.get("cp2_x")
        ref.cp2_y = data.get("cp2_y")
        return ref

class Node:
    """マインドマップの単一のトピックを表すクラス"""
    def __init__(self, text: str, parent: Optional['Node'] = None):
        self.id = str(uuid.uuid4())
        self.text = text
        self.parent = parent
        self.children: List['Node'] = []
        self.direction = None  # 'left' or 'right' (主にルートの子ノードで使用)
        
        # UI表示用のプロパティ
        self.x = 0.0
        self.y = 0.0
        self.width = 100
        self.height = 40
        self.color = None
        self.collapsed = False
        self.image_data: Optional[str] = None  # Base64 encoded PNG data
        self.image_path: Optional[str] = None  # Original image file path

    def add_child(self, text: str, direction: Optional[str] = None) -> 'Node':
        child = Node(text, parent=self)
        if direction:
            child.direction = direction
        else:
            # 親の方向を継承
            child.direction = self.direction
        child.color = self.color # 親の色を継承
        self.children.append(child)
        return child

    def remove_child(self, node: 'Node'):
        if node in self.children:
            self.children.remove(node)

    def move_to(self, new_parent: 'Node'):
        """このノードを新しい親ノードの下に移動する"""
        if self.parent:
            self.parent.remove_child(self)
        self.parent = new_parent
        new_parent.children.append(self)
        self.color = new_parent.color # 移動した先の親の色を継承
        # 方向は新しい親の方向を引き継ぐか、ルート直下なら再計算が必要だが
        if new_parent.parent is None: # ルート直下への移動
             self.direction = None # 再計算させる
        else:
             self.direction = new_parent.direction
        
        # 移動先の親が折りたたまれている場合は展開する
        if new_parent.collapsed:
            new_parent.collapsed = False

    def update_direction_recursive(self, direction):
        """ノードとその子孫の方向を再帰的に更新"""
        self.direction = direction
        for child in self.children:
            child.update_direction_recursive(direction)

    def is_descendant_of(self, potential_ancestor):
        """このノードが指定したノードの子孫かどうかをチェック"""
        curr = self
        while curr:
            if curr == potential_ancestor:
                return True
            curr = curr.parent
        return False

    def to_dict(self) -> dict:
        """シリアライズ用の辞書変換"""
        return {
            "id": self.id,
            "text": self.text,
            "direction": self.direction,
            "color": self.color,
            "collapsed": self.collapsed,
            "image_data": self.image_data,
            "image_path": self.image_path,
            "children": [child.to_dict() for child in self.children]
        }

    @classmethod
    def from_dict(cls, data: dict, parent: Optional['Node'] = None) -> 'Node':
        """辞書からの復元"""
        node = cls(data["text"], parent=parent)
        node.id = data.get("id", str(uuid.uuid4()))
        node.direction = data.get("direction")
        node.color = data.get("color")
        node.collapsed = data.get("collapsed", False)
        node.image_data = data.get("image_data")
        node.image_path = data.get("image_path")
        for child_data in data.get("children", []):
            child = cls.from_dict(child_data, parent=node)
            node.children.append(child)
        return node

class MindMapModel:
    """マインドマップ全体を管理するモデル"""
    def __init__(self, root_text: str = "Root Topic"):
        self.root = Node(root_text)
        self.references: List[Reference] = []
        self._is_modified = False
        self.modification_count = 0

    @property
    def is_modified(self) -> bool:
        return self._is_modified

    @is_modified.setter
    def is_modified(self, value: bool):
        self._is_modified = value
        if value:
            self.modification_count += 1

    def add_node(self, parent_node: Node, text: str = "New Topic") -> Node:
        """指定したノードに子ノードを追加する。ルート直下の場合は方向を自動調整する。"""
        direction = None
        if parent_node == self.root:
            direction = self.get_balanced_direction()
        
        node = parent_node.add_child(text, direction)
        self.is_modified = True
        return node

    def get_balanced_direction(self, exclude_node: Optional[Node] = None) -> str:
        """ルートの子ノードの左右バランスを考慮した方向を返す"""
        right_nodes = [c for c in self.root.children if c.direction != 'left' and c != exclude_node]
        left_nodes = [c for c in self.root.children if c.direction == 'left' and c != exclude_node]
        
        if len(right_nodes) <= len(left_nodes):
            return 'right'
        else:
            return 'left'

    def find_node_by_id(self, node_id: str, current: Optional[Node] = None) -> Optional[Node]:
        if current is None:
            current = self.root
        
        if current.id == node_id:
            return current
        
        for child in current.children:
            found = self.find_node_by_id(node_id, child)
            if found:
                return found
        return None

    def find_reference_by_id(self, ref_id: str) -> Optional[Reference]:
        for ref in self.references:
            if ref.id == ref_id:
                return ref
        return None

    def save(self) -> dict:
        return {
            "root": self.root.to_dict(),
            "references": [ref.to_dict() for ref in self.references]
        }

    def save_with_revision(self) -> tuple:
        """データとその時点のリビジョン番号を返す"""
        return self.save(), self.modification_count

    def load(self, data: dict):
        if "root" in data:
            self.root = Node.from_dict(data["root"])
            self.references = [Reference.from_dict(r) for r in data.get("references", [])]
        else:
            # 古いバージョンの形式（ルートトピック直書き）との互換性用
            self.root = Node.from_dict(data)
            self.references = []

    def _move_node(self, node: Node, offset: int) -> bool:
        """指定されたノードを、親のchildrenリスト内で指定オフセット分移動する"""
        if not node.parent:
            return False
            
        siblings = node.parent.children
        try:
            idx = siblings.index(node)
        except ValueError:
            return False
            
        new_idx = idx + offset
        if 0 <= new_idx < len(siblings):
            siblings[idx], siblings[new_idx] = siblings[new_idx], siblings[idx]
            self.is_modified = True
            return True
        return False

    def move_node_up(self, node: Node) -> bool:
        """指定されたノードを、親のchildrenリスト内で1つ前（上/反時計回り）に移動する"""
        return self._move_node(node, -1)

    def move_node_down(self, node: Node) -> bool:
        """指定されたノードを、親のchildrenリスト内で1つ後ろ（下/時計回り）に移動する"""
        return self._move_node(node, 1)
