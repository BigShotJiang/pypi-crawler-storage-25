"""Exceptions for LCMD-DB client."""


class LCMDError(Exception):
    """Base exception for all LCMD client errors."""


class DatasetNotFoundError(LCMDError):
    pass


class DownloadError(LCMDError):
    pass


class SchemaError(LCMDError):
    pass


class AssemblyError(LCMDError):
    pass
