"""Dataset module — lazy, typed, indexed access to entity data."""

from ._base import Dataset
from ._fragments import FragmentDataset
from ._molecules import MoleculeDataset
from ._reactions import ReactionDataset

__all__ = [
    "Dataset",
    "FragmentDataset",
    "MoleculeDataset",
    "ReactionDataset",
]
