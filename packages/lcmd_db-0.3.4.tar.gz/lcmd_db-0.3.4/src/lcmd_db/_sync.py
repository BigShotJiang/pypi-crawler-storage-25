"""Stub synchronization -- regenerates ``_overloads.py`` and per-subset modules."""

from __future__ import annotations

import logging
from pathlib import Path

from ._cache import DownloadCache
from ._codegen import _client_version, generate_overloads, generate_typed_module
from ._schema_store import SchemaStore, SubsetSchemas

logger = logging.getLogger(__name__)

_OVERLOADS_PATH = Path(__file__).parent / "_overloads.py"
_MARKER_PREFIX = "# marker: "


def _read_current_marker() -> str:
    try:
        first_line = _OVERLOADS_PATH.read_text("utf-8").split("\n", 1)[0]
        if first_line.startswith(_MARKER_PREFIX):
            return first_line[len(_MARKER_PREFIX) :]
    except OSError:
        pass
    return ""


def _compute_marker(
    schema_store: SchemaStore,
    schemas: dict[str, SubsetSchemas] | None = None,
) -> str:
    return f"{_client_version()}:{schema_store.content_hash(schemas)}"


def sync_stubs(
    cache: DownloadCache | None = None,
    *,
    force: bool = False,
) -> bool:
    """Regenerate ``_overloads.py`` and per-subset modules if schemas changed.

    Returns ``True`` if any files were (re)written.
    """
    if cache is None:
        cache = DownloadCache()

    store = SchemaStore(cache)
    schemas = store.load_all()
    marker = _compute_marker(store, schemas)

    if not force and _read_current_marker() == marker:
        return False

    if not schemas and not force:
        return False

    written = False

    entity_schemas = {slug: entry.entities for slug, entry in schemas.items()}
    ftype_map = {
        slug: entry.fragment_types
        for slug, entry in schemas.items()
        if entry.fragment_types
    }
    atemplate_map = {
        slug: entry.assembly_templates
        for slug, entry in schemas.items()
        if entry.assembly_templates
    }
    source = generate_overloads(
        entity_schemas,
        marker,
        fragment_types_map=ftype_map,
        assembly_templates_map=atemplate_map,
    )
    try:
        _OVERLOADS_PATH.write_text(source, encoding="utf-8")
        logger.debug("Regenerated _overloads.py (marker=%s)", marker)
        written = True
    except OSError as exc:
        logger.debug("Cannot write _overloads.py (read-only install?): %s", exc)

    written |= _sync_subset_modules(schemas)

    return written


def _sync_subset_modules(
    schemas: dict[str, SubsetSchemas],
) -> bool:
    """Write per-subset typed modules into ``lcmd_db/subsets/``."""
    from .subsets import _subsets_dir

    out = _subsets_dir()
    try:
        out.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        logger.debug("Cannot create subsets dir (read-only install?): %s", exc)
        return False

    written = False
    for subset_slug, entry in schemas.items():
        if not entry.entities:
            continue
        dest = out / f"{subset_slug}.py"
        try:
            source = generate_typed_module(
                subset_slug,
                entry.entities,
                subset_name=entry.subset_name,
                description=entry.description,
                fragment_types=entry.fragment_types,
                assembly_templates=entry.assembly_templates,
            )
            dest.write_text(source, encoding="utf-8")
            logger.debug("Generated %s", dest)
            written = True
        except OSError as exc:
            logger.debug("Cannot write %s: %s", dest, exc)

    return written
