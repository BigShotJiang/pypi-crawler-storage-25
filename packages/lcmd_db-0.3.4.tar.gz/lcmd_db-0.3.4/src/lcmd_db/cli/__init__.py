"""LCMD-DB CLI — tools for dataset management, typing, and cache control."""

from __future__ import annotations

import click

from .cache import cache
from .download import download
from .schema import schema
from .stubs import stubs


@click.group()
@click.version_option(package_name="lcmd-db")
@click.option(
    "--base-url",
    envvar="LCMD_DB_BASE_URL",
    default=None,
    help="Override the API base URL.",
)
@click.option(
    "--cache-dir",
    envvar="LCMD_DB_CACHE_DIR",
    type=click.Path(),
    default=None,
    help="Override the cache directory.",
)
def cli(base_url: str | None, cache_dir: str | None) -> None:
    """LCMD-DB — Python client for the LCMD molecular database."""
    from ..settings import settings

    if base_url is not None:
        settings.base_url = base_url
    if cache_dir is not None:
        settings.cache_dir = cache_dir


cli.add_command(download)
cli.add_command(schema)
cli.add_command(stubs)
cli.add_command(cache)


def main() -> None:
    cli()
