"""Schema command — inspect property definitions for a dataset."""

from __future__ import annotations

import click

from ._options import entity_type_option, subset_argument


@click.command()
@subset_argument
@entity_type_option
def schema(subset: str, entity_type: str) -> None:
    """Show property schema for a dataset.

    \b
    Examples:
        lcmd-db schema qm9
        lcmd-db schema qm9 --entity-type reactions
    """
    from .._schema import schema as fetch_schema
    from ..types import EntityType

    props = fetch_schema(subset, EntityType(entity_type))

    if not props:
        click.echo(f"No {entity_type} properties for '{subset}'")
        return

    for prop in props:
        units = f" ({prop.units})" if prop.units else ""
        intrinsic = " [built-in]" if prop.is_intrinsic else ""
        click.echo(f"  {prop.slug}: {prop.data_type.value}{units}{intrinsic}")
