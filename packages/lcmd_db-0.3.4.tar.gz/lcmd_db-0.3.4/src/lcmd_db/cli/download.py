"""Download command — fetch a dataset to the local cache."""

from __future__ import annotations

import click

from ._options import data_format_option, force_option, include_option, subset_argument


@click.command()
@subset_argument
@include_option
@data_format_option
@force_option
def download(
    subset: str,
    include: tuple[str, ...],
    data_format: str,
    force: bool,
) -> None:
    """Download a dataset to the local cache.

    \b
    Examples:
        lcmd-db download qm9
        lcmd-db download qm9 --include molecules --include structures
        lcmd-db download qm9 -f csv --force
    """
    from ..client import _load_dataset_impl

    data = _load_dataset_impl(
        subset,
        include=include,
        data_format=data_format,
        force_download=force,
    )

    for name, df in data.dataframes.items():
        click.echo(f"{name}: {df.shape[0]} rows, {df.shape[1]} columns")

    if data.metadata and data.metadata.structures_count:
        click.echo(f"structures: {data.metadata.structures_count} files")
