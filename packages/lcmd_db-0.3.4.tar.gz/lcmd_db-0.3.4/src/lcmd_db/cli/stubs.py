"""Stub commands — generate and sync type stubs for IDE autocomplete."""

from __future__ import annotations

from pathlib import Path

import click

from ._options import (
    entity_types_option,
    fetch_all_schemas,
    resolve_entity_types,
    subset_argument,
)


@click.group()
def stubs() -> None:
    """Manage type stubs for IDE autocomplete."""


@stubs.command()
@subset_argument
@click.option(
    "-o",
    "--output-dir",
    type=click.Path(file_okay=False),
    default=None,
    help="Output directory (default: lcmd_db/subsets/ inside the installed package).",
)
@entity_types_option
def generate(
    subset: str, output_dir: str | None, entity_types: tuple[str, ...]
) -> None:
    """Generate a typed Python module for a dataset.

    Fetches property schemas from the API and produces a module with
    TypedDicts, typed entity classes, and a typed load() function.

    \b
    Examples:
        lcmd-db stubs generate qm9
        lcmd-db stubs generate qm9 -o ./types/
        lcmd-db stubs generate qm9 --entity-types molecules
    """
    from .._codegen import generate_typed_module
    from ..subsets import _subsets_dir

    schemas = fetch_all_schemas(subset, resolve_entity_types(entity_types))

    if not schemas:
        raise click.ClickException(f"No properties found for subset '{subset}'")

    source = generate_typed_module(subset, schemas)  # type: ignore[arg-type]
    out = Path(output_dir) if output_dir else _subsets_dir()
    out.mkdir(parents=True, exist_ok=True)
    dest = out / f"{subset}.py"
    dest.write_text(source, encoding="utf-8")
    click.echo(f"Generated {dest}")


@stubs.command()
def sync() -> None:
    """Regenerate type stubs from cached metadata.

    Scans all downloaded datasets and rebuilds overload stubs and
    per-subset typed modules so your IDE picks up autocomplete.
    """
    from .._sync import sync_stubs

    if sync_stubs(force=True):
        click.echo("Regenerated stubs")
    else:
        click.echo("No cached schemas found — download a dataset first")
