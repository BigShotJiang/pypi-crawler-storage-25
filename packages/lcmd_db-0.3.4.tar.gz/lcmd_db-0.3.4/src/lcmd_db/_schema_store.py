"""Aggregates property schemas from cached metadata.json files for codegen."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

from ._cache import DownloadCache
from .types import (
    ENTITY_TYPES,
    AssemblyTemplateInfo,
    DataFormat,
    PropertyInfo,
    SubsetMetadata,
)


class SubsetSchemas:
    """Aggregated schemas and metadata for a single subset."""

    def __init__(self) -> None:
        self.entities: dict[str, list[PropertyInfo]] = {}
        self.subset_name: str = ""
        self.description: str = ""
        self.fragment_types: list[str] = []
        self.assembly_templates: list[AssemblyTemplateInfo] = []


class SchemaStore:
    """Read-only view over cached ``metadata.json`` files.

    The download cache is the sole source of truth.
    """

    def __init__(self, cache: DownloadCache) -> None:
        self._cache = cache

    def load_all(self) -> dict[str, SubsetSchemas]:
        """Return ``{subset_slug: SubsetSchemas}`` aggregated across all cached downloads."""
        result: dict[str, SubsetSchemas] = {}

        for data_dir in self._cache.iter_extracted_dirs():
            meta = SubsetMetadata.model_validate(
                json.loads((data_dir / "metadata.json").read_bytes())
            )
            if not meta.subset:
                continue

            if meta.subset not in result:
                result[meta.subset] = SubsetSchemas()

            entry = result[meta.subset]
            if meta.subset_name:
                entry.subset_name = meta.subset_name
            if meta.description:
                entry.description = meta.description

            if not entry.fragment_types:
                entry.fragment_types = _read_fragment_types(data_dir, meta.data_format)

            if not entry.assembly_templates and meta.assembly_templates:
                entry.assembly_templates = meta.assembly_templates

            for entity_type in ENTITY_TYPES:
                entity = meta.entities.get(entity_type)
                if entity is None or not entity.properties:
                    continue

                existing = entry.entities.get(entity_type, [])
                entry.entities[entity_type] = _union_properties(
                    existing, entity.properties
                )

        return result

    def content_hash(self, schemas: dict[str, SubsetSchemas] | None = None) -> str:
        if schemas is None:
            schemas = self.load_all()
        canonical = json.dumps(
            {
                slug: {
                    "entities": {
                        et: sorted(p.slug for p in props)
                        for et, props in sorted(entry.entities.items())
                    },
                    "assembly": [
                        {"slug": t.slug, "slots": [s.id for s in t.slots]}
                        for t in entry.assembly_templates
                    ],
                }
                for slug, entry in sorted(schemas.items())
            },
            sort_keys=True,
        )
        return hashlib.sha256(canonical.encode()).hexdigest()[:12]


def _read_fragment_types(data_dir: Path, data_format: str) -> list[str]:
    """Read fragment type slugs from the lookup table in any supported format."""
    from .client import _READERS

    try:
        fmt = DataFormat(data_format)
    except ValueError:
        fmt = DataFormat.PARQUET

    ft_path = data_dir / f"fragment_types.{fmt.value}"
    if not ft_path.exists():
        return []

    df = _READERS[fmt](ft_path)
    return sorted(df["slug"].to_list())


def _union_properties(
    existing: list[PropertyInfo],
    new: list[PropertyInfo],
) -> list[PropertyInfo]:
    seen = {p.slug for p in existing}
    return existing + [p for p in new if p.slug not in seen]
