"""Tests for assembly template execution and SubsetData.assembly_templates."""

from __future__ import annotations

import textwrap
from pathlib import Path

import polars as pl
import pytest
from lcmd_db._assembly import AssemblyTemplate, _find_uv
from lcmd_db.exceptions import AssemblyError
from lcmd_db.types import (
    AssemblyResult,
    AssemblyTemplateInfo,
    DataFormat,
    SlotInfo,
    SubsetData,
    SubsetMetadata,
)

ASSEMBLY_SCRIPT = textwrap.dedent("""\
    # /// script
    # requires-python = ">=3.10"
    # dependencies = []
    # ///
    import json, sys

    def assemble(slots):
        core = slots.get("core")
        sub1 = slots.get("sub1")
        if not core:
            return {"success": False, "error": "missing core"}
        parts = [core]
        if sub1:
            parts.append(sub1)
        return {"success": True, "smiles": ".".join(parts)}

    data = json.load(sys.stdin)
    if isinstance(data, list):
        json.dump([assemble(d) for d in data], sys.stdout)
    else:
        json.dump(assemble(data), sys.stdout)
""")

TEMPLATE_INFO = AssemblyTemplateInfo(
    slug="default",
    name="Default Assembler",
    description="Joins fragments with a dot",
    assembler_name="dot_joiner",
    slots=[
        SlotInfo(id="core", fragment_type="backbone", required=True),
        SlotInfo(
            id="sub1",
            fragment_type="substituent",
            required=False,
            default="[H]",
        ),
    ],
)


@pytest.fixture()
def assembly_dir(tmp_path: Path) -> Path:
    adir = tmp_path / "assembly"
    adir.mkdir()
    (adir / "default.py").write_text(ASSEMBLY_SCRIPT)
    return adir


@pytest.fixture()
def template(assembly_dir: Path) -> AssemblyTemplate:
    return AssemblyTemplate(TEMPLATE_INFO, assembly_dir / "default.py")


@pytest.fixture()
def subset_with_assembly(tmp_path: Path, assembly_dir: Path) -> SubsetData:
    pl.DataFrame(
        {"id": [1], "smiles": ["[*]C"], "fragment_type_slug": ["backbone"]}
    ).write_parquet(tmp_path / "fragments.parquet")

    meta = SubsetMetadata.model_validate(
        {
            "subset": "test_asm",
            "subset_name": "Test Assembly",
            "data_format": "parquet",
            "entities": {
                "fragments": {"count": 1, "columns": 3, "properties": []},
            },
            "assembly_templates": [TEMPLATE_INFO.model_dump()],
        }
    )
    return SubsetData._from_download(
        data_dir=tmp_path,
        data_format=DataFormat.PARQUET,
        fragments=pl.read_parquet(tmp_path / "fragments.parquet"),
        metadata=meta,
    )


class TestFindUv:
    def test_returns_path(self) -> None:
        assert Path(_find_uv()).exists()

    def test_cached_across_calls(self) -> None:
        assert _find_uv() is _find_uv()


class TestAssemblyTemplateProperties:
    def test_slug(self, template: AssemblyTemplate) -> None:
        assert template.slug == "default"

    def test_name(self, template: AssemblyTemplate) -> None:
        assert template.name == "Default Assembler"

    def test_description(self, template: AssemblyTemplate) -> None:
        assert template.description == "Joins fragments with a dot"

    def test_slots(self, template: AssemblyTemplate) -> None:
        assert len(template.slots) == 2
        assert template.slots[0].id == "core"
        assert template.slots[1].id == "sub1"

    def test_repr(self, template: AssemblyTemplate) -> None:
        r = repr(template)
        assert "default" in r
        assert "core" in r


class TestAssemble:
    def test_single(self, template: AssemblyTemplate) -> None:
        result = template.assemble(core="C")
        assert result == "C.[H]"

    def test_with_optional_slot(self, template: AssemblyTemplate) -> None:
        result = template.assemble(core="C", sub1="N")
        assert result == "C.N"

    def test_optional_uses_default(self, template: AssemblyTemplate) -> None:
        result = template.assemble(core="C")
        assert "[H]" in result

    def test_missing_required_raises(self, template: AssemblyTemplate) -> None:
        with pytest.raises(AssemblyError, match="missing required slot 'core'"):
            template.assemble(sub1="N")

    def test_unknown_slot_raises(self, template: AssemblyTemplate) -> None:
        with pytest.raises(AssemblyError, match="unknown slot"):
            template.assemble(core="C", unknown="X")

    def test_script_error_raises(self, tmp_path: Path) -> None:
        bad_script = tmp_path / "bad.py"
        bad_script.write_text(
            textwrap.dedent("""\
                # /// script
                # requires-python = ">=3.10"
                # dependencies = []
                # ///
                import json, sys
                data = json.load(sys.stdin)
                json.dump({"success": False, "error": "deliberate failure"}, sys.stdout)
            """)
        )
        info = AssemblyTemplateInfo(
            slug="bad",
            slots=[SlotInfo(id="x", fragment_type="t", required=True)],
        )
        t = AssemblyTemplate(info, bad_script)
        with pytest.raises(AssemblyError, match="deliberate failure"):
            t.assemble(x="C")

    def test_nonzero_exit_raises(self, tmp_path: Path) -> None:
        script = tmp_path / "crash.py"
        script.write_text(
            textwrap.dedent("""\
                # /// script
                # requires-python = ">=3.10"
                # dependencies = []
                # ///
                import sys
                print("something went wrong", file=sys.stderr)
                sys.exit(1)
            """)
        )
        info = AssemblyTemplateInfo(
            slug="crash",
            slots=[SlotInfo(id="x", fragment_type="t", required=True)],
        )
        t = AssemblyTemplate(info, script)
        with pytest.raises(AssemblyError, match="Assembly script failed"):
            t.assemble(x="C")

    def test_invalid_json_output_raises(self, tmp_path: Path) -> None:
        script = tmp_path / "badjson.py"
        script.write_text(
            textwrap.dedent("""\
                # /// script
                # requires-python = ">=3.10"
                # dependencies = []
                # ///
                import json, sys
                json.load(sys.stdin)
                print("not valid json {{{")
            """)
        )
        info = AssemblyTemplateInfo(
            slug="badjson",
            slots=[SlotInfo(id="x", fragment_type="t", required=True)],
        )
        t = AssemblyTemplate(info, script)
        with pytest.raises(AssemblyError, match="invalid JSON"):
            t.assemble(x="C")


class TestAssembleBatch:
    def test_batch(self, template: AssemblyTemplate) -> None:
        results = template.assemble_batch(
            [
                {"core": "C", "sub1": "N"},
                {"core": "O"},
            ]
        )
        assert len(results) == 2
        assert all(isinstance(r, AssemblyResult) for r in results)
        assert results[0].success
        assert results[0].smiles == "C.N"
        assert results[1].success

    def test_batch_partial_failure(self, template: AssemblyTemplate) -> None:
        results = template.assemble_batch(
            [
                {"core": "C"},
                {"core": ""},
            ]
        )
        assert results[0].success
        assert not results[1].success
        assert results[1].error is not None


class TestSaveScript:
    def test_copies_script(self, template: AssemblyTemplate, tmp_path: Path) -> None:
        dest = tmp_path / "saved.py"
        returned = template.save_script(dest)
        assert returned == dest
        assert dest.exists()
        assert "assemble" in dest.read_text()


class TestSubsetDataAssemblyTemplates:
    def test_returns_templates(self, subset_with_assembly: SubsetData) -> None:
        templates = subset_with_assembly.assembly_templates
        assert "default" in templates
        assert isinstance(templates["default"], AssemblyTemplate)

    def test_cached_across_calls(self, subset_with_assembly: SubsetData) -> None:
        first = subset_with_assembly.assembly_templates
        second = subset_with_assembly.assembly_templates
        assert first is second

    def test_empty_when_no_data_dir(self) -> None:
        data = SubsetData()
        assert data.assembly_templates == {}

    def test_empty_when_no_metadata(self, tmp_path: Path) -> None:
        data = SubsetData._from_download(
            data_dir=tmp_path,
            data_format=DataFormat.PARQUET,
        )
        assert data.assembly_templates == {}

    def test_skips_missing_scripts(self, tmp_path: Path) -> None:
        meta = SubsetMetadata.model_validate(
            {
                "subset": "test",
                "entities": {},
                "assembly_templates": [
                    {"slug": "nonexistent", "slots": []},
                ],
            }
        )
        data = SubsetData._from_download(
            data_dir=tmp_path,
            data_format=DataFormat.PARQUET,
            metadata=meta,
        )
        assert data.assembly_templates == {}

    def test_assemble_via_subset_data(self, subset_with_assembly: SubsetData) -> None:
        template = subset_with_assembly.assembly_templates["default"]
        result = template.assemble(core="CC")
        assert "CC" in result


class TestSubsetDataFromDownloadFactory:
    def test_plain_constructor_has_no_data_dir(self) -> None:
        data = SubsetData()
        assert data._data_dir is None
        assert data._data_format == DataFormat.PARQUET

    def test_factory_sets_private_fields(self, tmp_path: Path) -> None:
        data = SubsetData._from_download(
            data_dir=tmp_path,
            data_format=DataFormat.CSV,
        )
        assert data._data_dir == tmp_path
        assert data._data_format == DataFormat.CSV
