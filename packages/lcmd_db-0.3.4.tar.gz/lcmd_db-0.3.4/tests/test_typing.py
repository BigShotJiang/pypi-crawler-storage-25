"""End-to-end typing tests: metadata → stubs → pyright verification.

Test cases live in ``tests/typing_cases/*.py`` as real Python files
using ``assert_type()``.  Pyright runs once on the whole directory;
errors are grouped per file and exposed as parametrized test cases.
"""

from __future__ import annotations

import json
import subprocess
import sys
from collections.abc import Iterator
from pathlib import Path

import pytest
from lcmd_db._codegen import generate_typed_module
from lcmd_db.subsets import _subsets_dir
from lcmd_db.types import PropertyDataType, PropertyInfo

TYPING_CASES_DIR = Path(__file__).parent / "typing_cases"

TYPING_TEST_SCHEMAS: dict[str, list[PropertyInfo]] = {
    "molecules": [
        PropertyInfo(slug="energy", data_type=PropertyDataType.FLOAT, is_required=True),
        PropertyInfo(
            slug="atom_count", data_type=PropertyDataType.INTEGER, is_required=True
        ),
        PropertyInfo(
            slug="smiles", data_type=PropertyDataType.STRING, is_required=True
        ),
        PropertyInfo(
            slug="converged", data_type=PropertyDataType.BOOLEAN, is_required=True
        ),
        PropertyInfo(
            slug="dipole", data_type=PropertyDataType.FLOAT, is_required=False
        ),
    ],
    "reactions": [
        PropertyInfo(
            slug="barrier", data_type=PropertyDataType.FLOAT, is_required=True
        ),
        PropertyInfo(
            slug="step_count", data_type=PropertyDataType.INTEGER, is_required=True
        ),
        PropertyInfo(
            slug="mechanism", data_type=PropertyDataType.STRING, is_required=True
        ),
        PropertyInfo(
            slug="reversible", data_type=PropertyDataType.BOOLEAN, is_required=True
        ),
        PropertyInfo(
            slug="yield_pct", data_type=PropertyDataType.FLOAT, is_required=False
        ),
    ],
    "fragments": [
        PropertyInfo(slug="charge", data_type=PropertyDataType.FLOAT, is_required=True),
        PropertyInfo(slug="size", data_type=PropertyDataType.INTEGER, is_required=True),
        PropertyInfo(slug="name", data_type=PropertyDataType.STRING, is_required=True),
        PropertyInfo(
            slug="aromatic", data_type=PropertyDataType.BOOLEAN, is_required=True
        ),
        PropertyInfo(
            slug="weight", data_type=PropertyDataType.FLOAT, is_required=False
        ),
    ],
}


def _pyright_errors_by_file(directory: Path) -> dict[str, list[str]]:
    """Run pyright once on *directory*, return ``{filename: [errors]}``."""
    raw = subprocess.run(
        [sys.executable, "-m", "pyright", "--outputjson", str(directory)],
        capture_output=True,
        text=True,
    )
    data = json.loads(raw.stdout)
    errors: dict[str, list[str]] = {}
    for d in data.get("generalDiagnostics", []):
        if d.get("severity") != "error":
            continue
        name = Path(d["file"]).name
        errors.setdefault(name, []).append(d["message"])
    return errors


@pytest.fixture(scope="session")
def _typing_stubs() -> Iterator[None]:
    dest = _subsets_dir() / "_typing_test.py"
    source = generate_typed_module("_typing_test", TYPING_TEST_SCHEMAS)
    dest.write_text(source, encoding="utf-8")
    yield
    dest.unlink(missing_ok=True)


@pytest.fixture(scope="session")
def pyright_errors(_typing_stubs: None) -> dict[str, list[str]]:
    return _pyright_errors_by_file(TYPING_CASES_DIR)


_ALL_CASES = sorted(TYPING_CASES_DIR.glob("*.py"))


@pytest.mark.parametrize("case", _ALL_CASES, ids=[c.stem for c in _ALL_CASES])
def test_typecheck(case: Path, pyright_errors: dict[str, list[str]]) -> None:
    errors = pyright_errors.get(case.name, [])
    assert errors == [], "\n".join(errors)


class TestPropertySubscriptRuntime:
    def test_molecule_properties(self) -> None:
        from lcmd_db.types import Molecule

        mol = Molecule(id=1, properties={"energy": -76.0, "smiles": "O"})
        assert mol.properties["energy"] == -76.0
        assert mol.properties["smiles"] == "O"

    def test_reaction_properties(self) -> None:
        from lcmd_db.types import Reaction

        rxn = Reaction(id=1, properties={"barrier": 0.5})
        assert rxn.properties["barrier"] == 0.5

    def test_fragment_properties(self) -> None:
        from lcmd_db.types import Fragment

        frag = Fragment(id=1, properties={"charge": -1})
        assert frag.properties["charge"] == -1
