from __future__ import annotations

from lcmd_db.settings import Settings


class TestSettings:
    def test_defaults(self) -> None:
        s = Settings()
        assert s.base_url == "https://lcmd-app.epfl.ch"
        assert s.timeout == 300
        assert s.cache_dir is None
        assert s.auto_sync_stubs is True

    def test_env_override(self, monkeypatch) -> None:
        monkeypatch.setenv("LCMD_DB_BASE_URL", "http://localhost:8000")
        monkeypatch.setenv("LCMD_DB_TIMEOUT", "60")
        s = Settings()
        assert s.base_url == "http://localhost:8000"
        assert s.timeout == 60

    def test_mutable(self) -> None:
        s = Settings()
        s.base_url = "http://test"
        assert s.base_url == "http://test"
