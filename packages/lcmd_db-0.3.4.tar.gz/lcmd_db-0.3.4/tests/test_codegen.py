from __future__ import annotations

import pytest
from lcmd_db._codegen import (
    _filter_identifier,
    _filter_python_type,
    generate_overloads,
    generate_typed_module,
)
from lcmd_db.types import AssemblyTemplateInfo, PropertyDataType, PropertyInfo, SlotInfo


def _props(*slugs_and_types: tuple[str, PropertyDataType]) -> list[PropertyInfo]:
    return [PropertyInfo(slug=s, data_type=dt) for s, dt in slugs_and_types]


SAMPLE_SCHEMAS = {
    "qm9": {
        "molecules": _props(
            ("molecular_weight", PropertyDataType.FLOAT),
            ("smiles", PropertyDataType.STRING),
            ("converged", PropertyDataType.BOOLEAN),
        ),
    },
    "spice": {
        "molecules": _props(("energy", PropertyDataType.FLOAT)),
        "reactions": _props(("barrier", PropertyDataType.INTEGER)),
    },
}


class TestGenerateOverloads:
    def test_compiles(self) -> None:
        source = generate_overloads(SAMPLE_SCHEMAS, "test:abc")
        compile(source, "<test>", "exec")

    def test_marker_in_header(self) -> None:
        source = generate_overloads(SAMPLE_SCHEMAS, "1.0:xyz")
        assert source.startswith("# marker: 1.0:xyz")

    def test_has_overload_per_subset(self) -> None:
        source = generate_overloads(SAMPLE_SCHEMAS, "m")
        assert 'Literal["qm9"]' in source
        assert 'Literal["spice"]' in source

    def test_has_generic_fallback(self) -> None:
        source = generate_overloads(SAMPLE_SCHEMAS, "m")
        assert sum(1 for line in source.splitlines() if "subset: str" in line) >= 1

    def test_property_literals(self) -> None:
        source = generate_overloads(SAMPLE_SCHEMAS, "m")
        assert '"molecular_weight"' in source
        assert '"smiles"' in source

    def test_uses_singular_param_names(self) -> None:
        source = generate_overloads(SAMPLE_SCHEMAS, "m")
        assert "molecule_properties" in source
        assert "reaction_properties" in source
        assert "molecules_properties" not in source

    def test_parameterized_return(self) -> None:
        source = generate_overloads(SAMPLE_SCHEMAS, "m")
        assert "_sub_qm9.MoleculeProps" in source
        assert "_sub_spice.MoleculeProps" in source
        assert "_sub_spice.ReactionProps" in source

    def test_empty_schemas(self) -> None:
        source = generate_overloads({}, "empty")
        compile(source, "<test>", "exec")
        assert "subset: str" in source

    def test_fragment_types_in_overloads(self) -> None:
        source = generate_overloads(
            SAMPLE_SCHEMAS,
            "m",
            fragment_types_map={"qm9": ["backbone", "linker"]},
        )
        compile(source, "<test>", "exec")
        assert 'Literal["backbone", "linker"]' in source

    def test_assembly_templates_in_overloads(self) -> None:
        templates = [
            AssemblyTemplateInfo(
                slug="default",
                name="Default",
                slots=[SlotInfo(id="core", fragment_type="backbone", required=True)],
            )
        ]
        source = generate_overloads(
            SAMPLE_SCHEMAS,
            "m",
            assembly_templates_map={"qm9": templates},
        )
        compile(source, "<test>", "exec")
        assert "_sub_qm9.AssemblyTemplates" in source


class TestGenerateTypedModule:
    def test_compiles(self) -> None:
        source = generate_typed_module("qm9", SAMPLE_SCHEMAS["qm9"])
        compile(source, "<test>", "exec")

    def test_literal_type(self) -> None:
        source = generate_typed_module("qm9", SAMPLE_SCHEMAS["qm9"])
        assert "MoleculeProperty" in source
        assert '"molecular_weight"' in source

    def test_props_typeddict(self) -> None:
        source = generate_typed_module("qm9", SAMPLE_SCHEMAS["qm9"])
        assert "MoleculeProps" in source
        assert "molecular_weight: float" in source
        assert "smiles: str" in source
        assert "converged: bool" in source

    def test_load_function(self) -> None:
        source = generate_typed_module("qm9", SAMPLE_SCHEMAS["qm9"])
        assert "def load(" in source
        assert 'lcmd_db.load_dataset(\n        "qm9"' in source

    def test_multi_entity(self) -> None:
        source = generate_typed_module("spice", SAMPLE_SCHEMAS["spice"])
        assert "MoleculeProperty" in source
        assert "ReactionProperty" in source
        assert "ReactionProps" in source
        assert "barrier: int" in source

    def test_props_typeddict_class(self) -> None:
        source = generate_typed_module("qm9", SAMPLE_SCHEMAS["qm9"])
        assert "class MoleculeProps(TypedDict" in source
        assert "molecular_weight: float" in source
        assert "smiles: str" in source
        assert "converged: bool" in source

    def test_parameterized_return_type(self) -> None:
        source = generate_typed_module("qm9", SAMPLE_SCHEMAS["qm9"])
        assert (
            "SubsetData[MoleculeProps, dict[str, Value], dict[str, Value], str | None, dict[str, object]]"
            in source
        )

    def test_multi_entity_return_type(self) -> None:
        source = generate_typed_module("spice", SAMPLE_SCHEMAS["spice"])
        assert (
            "SubsetData[MoleculeProps, ReactionProps, dict[str, Value], str | None, dict[str, object]]"
            in source
        )

    def test_assembly_template_codegen(self) -> None:
        templates = [
            AssemblyTemplateInfo(
                slug="default",
                name="Default Assembler",
                slots=[
                    SlotInfo(id="core", fragment_type="backbone", required=True),
                    SlotInfo(
                        id="sub1",
                        fragment_type="substituent",
                        required=False,
                        default="[*]H",
                    ),
                ],
            )
        ]
        source = generate_typed_module(
            "test",
            {"fragments": SAMPLE_SCHEMAS["qm9"]["molecules"]},
            assembly_templates=templates,
        )
        assert "class AssemblyTemplates(TypedDict):" in source
        assert "default: AssemblyTemplate" in source
        assert "def assemble_default(" in source
        assert "core: str," in source
        assert 'sub1: str | None = "[*]H"' in source
        assert "-> str:" in source
        assert "def _get_subset_data()" in source
        assert "_get_subset_data().assembly_templates" in source

    def test_no_cache_function_without_templates(self) -> None:
        source = generate_typed_module("qm9", SAMPLE_SCHEMAS["qm9"])
        assert "_get_subset_data" not in source
        assert "_subset_data" not in source

    def test_fragment_types_literal(self) -> None:
        source = generate_typed_module(
            "test",
            {"fragments": SAMPLE_SCHEMAS["qm9"]["molecules"]},
            fragment_types=["backbone", "linker"],
        )
        assert 'FragmentType = Literal["backbone", "linker"]' in source
        assert 'Literal["backbone", "linker"],' in source


class TestPythonTypeFilter:
    def test_float(self) -> None:
        assert _filter_python_type(PropertyDataType.FLOAT) == "float"

    def test_integer(self) -> None:
        assert _filter_python_type(PropertyDataType.INTEGER) == "int"

    def test_string(self) -> None:
        assert _filter_python_type(PropertyDataType.STRING) == "str"

    def test_boolean(self) -> None:
        assert _filter_python_type(PropertyDataType.BOOLEAN) == "bool"

    def test_from_string(self) -> None:
        assert _filter_python_type("float") == "float"
        assert _filter_python_type("integer") == "int"

    def test_unknown_falls_back_to_str(self) -> None:
        assert _filter_python_type("unknown_type") == "str"


class TestIdentifierFilter:
    @pytest.mark.parametrize(
        ("slug", "expected"),
        [
            ("energy", "energy"),
            ("homo_energy", "homo_energy"),
            ("homo-cation", "homo_cation"),
            ("homo-dication", "homo_dication"),
            ("t-SNE Dim1", "t_sne_dim1"),
            ("HOMO Energy (eV)", "homo_energy_ev"),
            ("1st_property", "1st_property"),
            ("", "unnamed"),
        ],
    )
    def test_sanitize(self, slug: str, expected: str) -> None:
        assert _filter_identifier(slug) == expected

    def test_result_is_identifier(self) -> None:
        for slug in ["homo-cation", "energy (eV)", "α-angle", "charge"]:
            result = _filter_identifier(slug)
            assert result.replace(
                "0123456789", ""
            ).isidentifier() or result == _filter_identifier(slug)


class TestEmptySchemas:
    def test_generate_typed_module_raises_on_empty(self) -> None:
        with pytest.raises(ValueError, match="No properties"):
            generate_typed_module("empty", {})

    def test_codegen_with_hyphenated_slugs(self) -> None:
        props = _props(("homo-cation", PropertyDataType.FLOAT))
        source = generate_typed_module("test", {"molecules": props})
        assert "homo_cation: float" in source
        assert 'Literal["homo_cation"]' in source
