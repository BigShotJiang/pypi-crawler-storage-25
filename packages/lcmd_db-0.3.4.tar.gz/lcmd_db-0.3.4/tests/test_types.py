from __future__ import annotations

import polars as pl
from lcmd_db.types import (
    DataFormat,
    EntityType,
    PropertyDataType,
    PropertyInfo,
    SubsetData,
    SubsetMetadata,
)


class TestPropertyInfo:
    def test_parse_from_dict(self) -> None:
        p = PropertyInfo.model_validate(
            {"slug": "mw", "data_type": "float", "units": "g/mol"}
        )
        assert p.slug == "mw"
        assert p.data_type == PropertyDataType.FLOAT
        assert p.units == "g/mol"

    def test_coerces_unknown_data_type(self) -> None:
        p = PropertyInfo.model_validate({"slug": "x", "data_type": "unknown"})
        assert p.data_type == PropertyDataType.STRING

    def test_defaults(self) -> None:
        p = PropertyInfo(slug="x")
        assert p.name == ""
        assert p.data_type == PropertyDataType.STRING
        assert p.is_intrinsic is False


class TestSubsetMetadata:
    def test_parse_metadata_json(self) -> None:
        raw = {
            "subset": "qm9",
            "subset_name": "QM9",
            "data_format": "parquet",
            "entities": {
                "molecules": {
                    "count": 100,
                    "columns": 5,
                    "properties": [{"slug": "mw", "data_type": "float"}],
                }
            },
            "structures_count": 100,
        }
        meta = SubsetMetadata.model_validate(raw)
        assert meta.subset == "qm9"
        assert meta.entities["molecules"].count == 100
        assert meta.entities["molecules"].properties[0].slug == "mw"
        assert meta.structures_count == 100

    def test_missing_optional_fields(self) -> None:
        meta = SubsetMetadata.model_validate({"subset": "x"})
        assert meta.entities == {}
        assert meta.structures_count is None


class TestSubsetData:
    def test_empty(self) -> None:
        assert SubsetData().dataframes == {}

    def test_dataframes_property(self) -> None:
        data = SubsetData(molecules=pl.DataFrame({"a": [1]}))
        assert "molecules" in data.dataframes
        assert "reactions" not in data.dataframes

    def test_all_entities(self) -> None:
        df = pl.DataFrame({"a": [1]})
        data = SubsetData(molecules=df, reactions=df, fragments=df)
        assert len(data.dataframes) == 3


class TestEnums:
    def test_data_format_compares_as_str(self) -> None:
        assert DataFormat.PARQUET == "parquet"
        assert DataFormat.CSV.value == "csv"

    def test_entity_type_values(self) -> None:
        assert set(EntityType) == {
            EntityType.MOLECULES,
            EntityType.REACTIONS,
            EntityType.FRAGMENTS,
        }
