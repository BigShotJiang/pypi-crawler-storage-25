from __future__ import annotations

import polars as pl
import pytest
from lcmd_db.dataset._molecules import MoleculeDataset
from lcmd_db.dataset._source import EagerSource, LazySource
from lcmd_db.types import EntityMetadata, Molecule, PropertyInfo


@pytest.fixture()
def mol_df() -> pl.DataFrame:
    return pl.DataFrame(
        {
            "id": [1, 2, 3, 4, 5],
            "smiles": ["C", "CC", "CCC", "CCCC", "CCCCC"],
            "weight": [16.0, 30.0, 44.0, 58.0, 72.0],
        }
    )


@pytest.fixture()
def dataset(mol_df: pl.DataFrame) -> MoleculeDataset[dict]:
    return MoleculeDataset(EagerSource(mol_df))


class TestLazyLoading:
    def test_df_not_materialized_on_init(self, mol_df: pl.DataFrame) -> None:
        ds = MoleculeDataset(EagerSource(mol_df))
        assert ds._df is None

    def test_df_materialized_on_access(self, dataset: MoleculeDataset[dict]) -> None:
        _ = dataset[0]
        assert dataset._df is not None

    def test_len_without_materialization_for_lazy_source(
        self, tmp_path: object
    ) -> None:
        lf = pl.LazyFrame({"id": [1, 2, 3], "smiles": ["C", "CC", "CCC"]})
        ds = MoleculeDataset(LazySource(lf))
        assert len(ds) == 3
        assert ds._df is None


class TestIndexing:
    def test_int_index_returns_entry(self, dataset: MoleculeDataset[dict]) -> None:
        mol = dataset[0]
        assert isinstance(mol, Molecule)
        assert mol.id == 1

    def test_negative_index(self, dataset: MoleculeDataset[dict]) -> None:
        mol = dataset[-1]
        assert mol.id == 5

    def test_slice_returns_dataset(self, dataset: MoleculeDataset[dict]) -> None:
        sub = dataset[1:3]
        assert isinstance(sub, MoleculeDataset)
        assert len(sub) == 2

    def test_list_index_returns_dataset(self, dataset: MoleculeDataset[dict]) -> None:
        sub = dataset[[0, 2, 4]]
        assert isinstance(sub, MoleculeDataset)
        assert len(sub) == 3

    def test_out_of_bounds_raises(self, dataset: MoleculeDataset[dict]) -> None:
        with pytest.raises(pl.exceptions.OutOfBoundsError):
            dataset[100]


class TestIteration:
    def test_iter_yields_all_entries(self, dataset: MoleculeDataset[dict]) -> None:
        entries = list(dataset)
        assert len(entries) == 5
        assert all(isinstance(e, Molecule) for e in entries)

    def test_iter_preserves_order(self, dataset: MoleculeDataset[dict]) -> None:
        ids = [mol.id for mol in dataset]
        assert ids == [1, 2, 3, 4, 5]


class TestFilterSelect:
    def test_filter_reduces_rows(self, dataset: MoleculeDataset[dict]) -> None:
        filtered = dataset.filter(pl.col("weight") > 40)
        assert len(filtered) == 3
        assert isinstance(filtered, MoleculeDataset)

    def test_filter_returns_lazy_source(self, dataset: MoleculeDataset[dict]) -> None:
        filtered = dataset.filter(pl.col("weight") > 40)
        assert isinstance(filtered._source, LazySource)
        assert filtered._df is None

    def test_select_keeps_id_and_columns(self, dataset: MoleculeDataset[dict]) -> None:
        selected = dataset.select("smiles")
        assert set(selected.columns) == {"id", "smiles"}

    def test_select_returns_lazy_source(self, dataset: MoleculeDataset[dict]) -> None:
        selected = dataset.select("smiles")
        assert isinstance(selected._source, LazySource)


class TestTrainTestSplit:
    def test_split_sizes(self, dataset: MoleculeDataset[dict]) -> None:
        train, test = dataset.train_test_split(test_size=0.4, seed=0)
        assert len(train) == 3
        assert len(test) == 2

    def test_split_preserves_type(self, dataset: MoleculeDataset[dict]) -> None:
        train, test = dataset.train_test_split()
        assert isinstance(train, MoleculeDataset)
        assert isinstance(test, MoleculeDataset)

    def test_split_is_deterministic(self, dataset: MoleculeDataset[dict]) -> None:
        t1, _ = dataset.train_test_split(seed=42)
        t2, _ = dataset.train_test_split(seed=42)
        assert list(t1) == list(t2)

    def test_no_overlap(self, dataset: MoleculeDataset[dict]) -> None:
        train, test = dataset.train_test_split()
        train_ids = {m.id for m in train}
        test_ids = {m.id for m in test}
        assert train_ids.isdisjoint(test_ids)
        assert train_ids | test_ids == {1, 2, 3, 4, 5}


class TestConversions:
    def test_to_polars(self, dataset: MoleculeDataset[dict]) -> None:
        df = dataset.to_polars()
        assert isinstance(df, pl.DataFrame)
        assert df.height == 5


class TestProperties:
    def test_properties_returns_none_without_metadata(
        self, dataset: MoleculeDataset[dict]
    ) -> None:
        assert dataset.properties is None

    def test_properties_returns_list_with_metadata(self, mol_df: pl.DataFrame) -> None:
        meta = EntityMetadata(
            count=5,
            columns=3,
            properties=[PropertyInfo(slug="weight", data_type="float")],
        )
        ds = MoleculeDataset(EagerSource(mol_df), metadata=meta)
        assert ds.properties is not None
        assert len(ds.properties) == 1
        assert ds.properties[0].slug == "weight"


class TestRepr:
    def test_repr_contains_class_name(self, dataset: MoleculeDataset[dict]) -> None:
        r = repr(dataset)
        assert "MoleculeDataset" in r
        assert "len=5" in r
