from __future__ import annotations

from lcmd_db._cache import DownloadCache
from lcmd_db._schema_store import SchemaStore


class TestSchemaStore:
    def test_loads_from_metadata(self, cache: DownloadCache) -> None:
        schemas = SchemaStore(cache).load_all()
        assert "test_subset" in schemas
        assert "molecules" in schemas["test_subset"].entities
        slugs = {p.slug for p in schemas["test_subset"].entities["molecules"]}
        assert {"molecular_weight", "smiles", "energy", "converged"} <= slugs

    def test_content_hash_stable(self, cache: DownloadCache) -> None:
        store = SchemaStore(cache)
        assert store.content_hash() == store.content_hash()

    def test_content_hash_is_12_char_hex(self, tmp_path) -> None:
        h = SchemaStore(DownloadCache(tmp_path / "empty")).content_hash()
        assert isinstance(h, str) and len(h) == 12

    def test_content_hash_with_preloaded_schemas(self, cache: DownloadCache) -> None:
        store = SchemaStore(cache)
        schemas = store.load_all()
        assert store.content_hash(schemas) == store.content_hash()

    def test_unions_across_downloads(
        self, cache: DownloadCache, subset_factory
    ) -> None:
        subset_factory(
            "test_subset",
            cache_key="second",
            properties=[{"slug": "extra_prop", "data_type": "integer"}],
        )
        schemas = SchemaStore(cache).load_all()
        slugs = {p.slug for p in schemas["test_subset"].entities["molecules"]}
        assert "extra_prop" in slugs
        assert "molecular_weight" in slugs
