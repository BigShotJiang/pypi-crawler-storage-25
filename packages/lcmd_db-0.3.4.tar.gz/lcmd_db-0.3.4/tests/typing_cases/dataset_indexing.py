"""Dataset __getitem__: int → entity, slice/list → Dataset."""

from typing import assert_type

from lcmd_db.dataset import (
    Dataset,
    FragmentDataset,
    MoleculeDataset,
    ReactionDataset,
)
from lcmd_db.subsets._typing_test import (
    FragmentProps,
    MoleculeProps,
    ReactionProps,
)
from lcmd_db.types import Fragment, Molecule, Reaction


def check_int_index(
    mol_ds: MoleculeDataset[MoleculeProps],
    rxn_ds: ReactionDataset[ReactionProps],
    frag_ds: FragmentDataset[FragmentProps],
) -> None:
    assert_type(mol_ds[0], Molecule[MoleculeProps])
    assert_type(mol_ds[0].properties["energy"], float)
    assert_type(mol_ds[0].properties, MoleculeProps)
    assert_type(rxn_ds[0], Reaction[ReactionProps])
    assert_type(frag_ds[0], Fragment[FragmentProps])


def check_slice_index(
    mol_ds: MoleculeDataset[MoleculeProps],
    rxn_ds: ReactionDataset[ReactionProps],
    frag_ds: FragmentDataset[FragmentProps],
) -> None:
    assert_type(mol_ds[0:5], Dataset[Molecule[MoleculeProps]])
    assert_type(rxn_ds[0:5], Dataset[Reaction[ReactionProps]])
    assert_type(frag_ds[0:5], Dataset[Fragment[FragmentProps]])


def check_list_index(mol_ds: MoleculeDataset[MoleculeProps]) -> None:
    assert_type(mol_ds[[1, 2, 3]], Dataset[Molecule[MoleculeProps]])
