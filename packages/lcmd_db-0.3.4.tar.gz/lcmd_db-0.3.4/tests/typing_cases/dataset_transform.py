"""filter, select, and train_test_split preserve the entity type parameter."""

from typing import assert_type

import polars as pl
from lcmd_db.dataset import Dataset, FragmentDataset, MoleculeDataset, ReactionDataset
from lcmd_db.subsets._typing_test import FragmentProps, MoleculeProps, ReactionProps
from lcmd_db.types import Fragment, Molecule, Reaction


def check_filter(
    mol_ds: MoleculeDataset[MoleculeProps],
    rxn_ds: ReactionDataset[ReactionProps],
    frag_ds: FragmentDataset[FragmentProps],
) -> None:
    assert_type(mol_ds.filter(pl.col("energy") > 0), Dataset[Molecule[MoleculeProps]])
    assert_type(rxn_ds.filter(pl.col("barrier") > 0), Dataset[Reaction[ReactionProps]])
    assert_type(frag_ds.filter(pl.col("charge") > 0), Dataset[Fragment[FragmentProps]])


def check_select(mol_ds: MoleculeDataset[MoleculeProps]) -> None:
    assert_type(mol_ds.select("energy"), Dataset[Molecule[MoleculeProps]])


def check_train_test_split(mol_ds: MoleculeDataset[MoleculeProps]) -> None:
    train, test = mol_ds.train_test_split()
    assert_type(train, Dataset[Molecule[MoleculeProps]])
    assert_type(test, Dataset[Molecule[MoleculeProps]])
