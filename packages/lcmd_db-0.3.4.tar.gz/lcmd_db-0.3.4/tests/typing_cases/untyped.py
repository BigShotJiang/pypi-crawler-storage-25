"""Without stubs, the default generic gives dict[str, Value] everywhere."""

from pathlib import Path
from typing import assert_type

from lcmd_db.dataset import FragmentDataset, MoleculeDataset, ReactionDataset
from lcmd_db.types import Fragment, Molecule, Participant, Reaction, Value


def check_molecule(mol: Molecule) -> None:
    assert_type(mol.properties, dict[str, Value])
    assert_type(mol.id, int)
    assert_type(mol.structure_path, Path | None)


def check_reaction(rxn: Reaction) -> None:
    assert_type(rxn.properties, dict[str, Value])
    assert_type(rxn.id, int)
    assert_type(rxn.participants, list[Participant])


def check_fragment(frag: Fragment) -> None:
    assert_type(frag.properties, dict[str, Value])
    assert_type(frag.id, int)
    assert_type(frag.fragment_type, str | None)


def check_molecule_dataset(ds: MoleculeDataset) -> None:
    assert_type(ds[0], Molecule[dict[str, Value]])


def check_reaction_dataset(ds: ReactionDataset) -> None:
    assert_type(ds[0], Reaction[dict[str, Value]])


def check_fragment_dataset(ds: FragmentDataset) -> None:
    assert_type(ds[0], Fragment[dict[str, Value]])
