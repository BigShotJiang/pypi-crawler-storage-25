"""Entity field types: TypedDict properties + subscript, id, optional fields."""

from pathlib import Path
from typing import assert_type

from lcmd_db.subsets._typing_test import (
    FragmentProps,
    MoleculeProps,
    ReactionProps,
)
from lcmd_db.types import Fragment, Molecule, Participant, Reaction


def check_molecule_properties(mol: Molecule[MoleculeProps]) -> None:
    assert_type(mol.properties, MoleculeProps)
    assert_type(mol.properties["energy"], float)
    assert_type(mol.properties["dipole"], float | None)
    assert_type(mol.id, int)
    assert_type(mol.structure_path, Path | None)


def check_reaction_properties(rxn: Reaction[ReactionProps]) -> None:
    assert_type(rxn.properties, ReactionProps)
    assert_type(rxn.properties["barrier"], float)
    assert_type(rxn.id, int)
    assert_type(rxn.participants, list[Participant])


def check_fragment_properties(frag: Fragment[FragmentProps]) -> None:
    assert_type(frag.properties, FragmentProps)
    assert_type(frag.properties["charge"], float)
    assert_type(frag.id, int)
    assert_type(frag.fragment_type, str | None)
