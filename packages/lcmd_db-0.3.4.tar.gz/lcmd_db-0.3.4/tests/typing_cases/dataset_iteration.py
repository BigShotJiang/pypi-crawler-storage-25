"""Iterating over a dataset yields typed entities."""

from typing import assert_type

from lcmd_db.dataset import FragmentDataset, MoleculeDataset, ReactionDataset
from lcmd_db.subsets._typing_test import FragmentProps, MoleculeProps, ReactionProps
from lcmd_db.types import Fragment, Molecule, Reaction


def check_iteration(
    mol_ds: MoleculeDataset[MoleculeProps],
    rxn_ds: ReactionDataset[ReactionProps],
    frag_ds: FragmentDataset[FragmentProps],
) -> None:
    assert_type(next(iter(mol_ds)), Molecule[MoleculeProps])
    assert_type(next(iter(rxn_ds)), Reaction[ReactionProps])
    assert_type(next(iter(frag_ds)), Fragment[FragmentProps])
