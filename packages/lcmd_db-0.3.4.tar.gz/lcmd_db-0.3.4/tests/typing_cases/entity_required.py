"""Required properties return the bare type; optional properties return type | None."""

from typing import assert_type

from lcmd_db.subsets._typing_test import FragmentProps, MoleculeProps, ReactionProps
from lcmd_db.types import Fragment, Molecule, Reaction


def check_molecule_required(mol: Molecule[MoleculeProps]) -> None:
    assert_type(mol.properties["energy"], float)
    assert_type(mol.properties["smiles"], str)


def check_molecule_optional(mol: Molecule[MoleculeProps]) -> None:
    assert_type(mol.properties["dipole"], float | None)


def check_reaction_required(rxn: Reaction[ReactionProps]) -> None:
    assert_type(rxn.properties["barrier"], float)


def check_reaction_optional(rxn: Reaction[ReactionProps]) -> None:
    assert_type(rxn.properties["yield_pct"], float | None)


def check_fragment_required(frag: Fragment[FragmentProps]) -> None:
    assert_type(frag.properties["charge"], float)


def check_fragment_optional(frag: Fragment[FragmentProps]) -> None:
    assert_type(frag.properties["weight"], float | None)
