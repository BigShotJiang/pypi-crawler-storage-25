"""SubsetData generic narrowing: as_dataset returns typed datasets."""

from typing import assert_type

from lcmd_db.dataset import FragmentDataset, MoleculeDataset, ReactionDataset
from lcmd_db.subsets._typing_test import (
    FragmentProps,
    MoleculeProps,
    ReactionProps,
    load,
)
from lcmd_db.types import SubsetData, Value


def check_as_dataset_untyped(data: SubsetData) -> None:
    assert_type(data.as_dataset("molecules"), MoleculeDataset[dict[str, Value]])
    assert_type(data.as_dataset("reactions"), ReactionDataset[dict[str, Value]])
    assert_type(data.as_dataset("fragments"), FragmentDataset[dict[str, Value]])


def check_as_dataset_typed(
    data: SubsetData[MoleculeProps, ReactionProps, FragmentProps],
) -> None:
    assert_type(data.as_dataset("molecules"), MoleculeDataset[MoleculeProps])
    assert_type(data.as_dataset("reactions"), ReactionDataset[ReactionProps])
    assert_type(data.as_dataset("fragments"), FragmentDataset[FragmentProps])


def check_load_return_type() -> None:
    result = load()
    assert_type(result, SubsetData[MoleculeProps, ReactionProps, FragmentProps])
