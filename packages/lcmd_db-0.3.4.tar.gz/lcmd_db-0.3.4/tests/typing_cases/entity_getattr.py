"""Properties are accessed via subscript, not __getattr__."""

from typing import assert_type

from lcmd_db.subsets._typing_test import FragmentProps, MoleculeProps, ReactionProps
from lcmd_db.types import Fragment, Molecule, Reaction


def check_molecule_subscript(mol: Molecule[MoleculeProps]) -> None:
    assert_type(mol.properties["energy"], float)
    assert_type(mol.properties["atom_count"], int)
    assert_type(mol.properties["smiles"], str)
    assert_type(mol.properties["converged"], bool)


def check_reaction_subscript(rxn: Reaction[ReactionProps]) -> None:
    assert_type(rxn.properties["barrier"], float)
    assert_type(rxn.properties["step_count"], int)
    assert_type(rxn.properties["mechanism"], str)
    assert_type(rxn.properties["reversible"], bool)


def check_fragment_subscript(frag: Fragment[FragmentProps]) -> None:
    assert_type(frag.properties["charge"], float)
    assert_type(frag.properties["size"], int)
    assert_type(frag.properties["name"], str)
    assert_type(frag.properties["aromatic"], bool)
