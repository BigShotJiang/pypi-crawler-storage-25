"""Multiple entity types from the same generated stub coexist correctly."""

from typing import assert_type

from lcmd_db.dataset import FragmentDataset, MoleculeDataset, ReactionDataset
from lcmd_db.subsets._typing_test import FragmentProps, MoleculeProps, ReactionProps
from lcmd_db.types import Fragment, Molecule, Reaction


def check_all_entities(
    mol: Molecule[MoleculeProps],
    rxn: Reaction[ReactionProps],
    frag: Fragment[FragmentProps],
) -> None:
    assert_type(mol.properties["energy"], float)
    assert_type(rxn.properties["barrier"], float)
    assert_type(frag.properties["charge"], float)


def check_all_datasets(
    mol_ds: MoleculeDataset[MoleculeProps],
    rxn_ds: ReactionDataset[ReactionProps],
    frag_ds: FragmentDataset[FragmentProps],
) -> None:
    assert_type(mol_ds[0], Molecule[MoleculeProps])
    assert_type(rxn_ds[0], Reaction[ReactionProps])
    assert_type(frag_ds[0], Fragment[FragmentProps])
