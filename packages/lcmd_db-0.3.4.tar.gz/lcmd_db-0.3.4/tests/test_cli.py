from __future__ import annotations

from click.testing import CliRunner
from lcmd_db.cli import cli

runner = CliRunner()


class TestRootCli:
    def test_help(self) -> None:
        result = runner.invoke(cli, ["--help"])
        assert result.exit_code == 0
        assert "LCMD-DB" in result.output

    def test_version(self) -> None:
        result = runner.invoke(cli, ["--version"])
        assert result.exit_code == 0


class TestCacheCommands:
    def test_cache_dir(self) -> None:
        result = runner.invoke(cli, ["cache", "dir"])
        assert result.exit_code == 0
        assert "lcmd-db" in result.output

    def test_cache_list_empty(self) -> None:
        result = runner.invoke(cli, ["cache", "list"])
        assert result.exit_code == 0

    def test_cache_clear(self) -> None:
        result = runner.invoke(cli, ["cache", "clear"])
        assert result.exit_code == 0


class TestStubsCommands:
    def test_stubs_sync(self) -> None:
        result = runner.invoke(cli, ["stubs", "sync"])
        assert result.exit_code == 0

    def test_stubs_generate_help(self) -> None:
        result = runner.invoke(cli, ["stubs", "generate", "--help"])
        assert result.exit_code == 0
        assert "SUBSET" in result.output


class TestDownloadCommand:
    def test_help(self) -> None:
        result = runner.invoke(cli, ["download", "--help"])
        assert result.exit_code == 0
        assert "--include" in result.output
        assert "--format" in result.output


class TestSchemaCommand:
    def test_help(self) -> None:
        result = runner.invoke(cli, ["schema", "--help"])
        assert result.exit_code == 0
        assert "--entity-type" in result.output
