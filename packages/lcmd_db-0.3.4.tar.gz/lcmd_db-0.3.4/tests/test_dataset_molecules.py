from __future__ import annotations

from pathlib import Path

import polars as pl
import pytest
from lcmd_db.dataset._molecules import MoleculeDataset
from lcmd_db.dataset._source import EagerSource
from lcmd_db.types import Molecule


@pytest.fixture()
def mol_df() -> pl.DataFrame:
    return pl.DataFrame(
        {
            "id": [1, 2, 3],
            "smiles": ["C", "CC", "CCC"],
            "weight": [16.0, 30.0, 44.0],
        }
    )


class TestEntryResolution:
    def test_entry_is_molecule(self, mol_df: pl.DataFrame) -> None:
        ds = MoleculeDataset(EagerSource(mol_df))
        mol = ds[0]
        assert isinstance(mol, Molecule)

    def test_id_extracted(self, mol_df: pl.DataFrame) -> None:
        ds = MoleculeDataset(EagerSource(mol_df))
        assert ds[0].id == 1
        assert ds[2].id == 3

    def test_id_excluded_from_properties(self, mol_df: pl.DataFrame) -> None:
        ds = MoleculeDataset(EagerSource(mol_df))
        mol = ds[0]
        assert "id" not in mol.properties

    def test_properties_contain_all_columns(self, mol_df: pl.DataFrame) -> None:
        ds = MoleculeDataset(EagerSource(mol_df))
        mol = ds[0]
        assert mol.properties["smiles"] == "C"
        assert mol.properties["weight"] == 16.0

    def test_frozen(self, mol_df: pl.DataFrame) -> None:
        ds = MoleculeDataset(EagerSource(mol_df))
        mol = ds[0]
        with pytest.raises(AttributeError):
            mol.id = 999  # type: ignore[misc]


class TestStructurePaths:
    def test_no_structures_dir(self, mol_df: pl.DataFrame) -> None:
        ds = MoleculeDataset(EagerSource(mol_df))
        assert ds[0].structure_path is None

    def test_structure_path_resolved(
        self, mol_df: pl.DataFrame, tmp_path: Path
    ) -> None:
        structures = tmp_path / "structures"
        structures.mkdir()
        (structures / "1.xyz").write_text("xyz data")

        ds = MoleculeDataset(EagerSource(mol_df), structures_dir=structures)
        assert ds[0].structure_path == structures / "1.xyz"
        assert ds[1].structure_path is None  # 2.xyz doesn't exist

    def test_with_source_preserves_structures_dir(
        self, mol_df: pl.DataFrame, tmp_path: Path
    ) -> None:
        structures = tmp_path / "structures"
        structures.mkdir()
        ds = MoleculeDataset(EagerSource(mol_df), structures_dir=structures)
        sub = ds[0:2]
        assert sub._structures_dir == structures
