"""Edge cases for Dataset classes."""

from __future__ import annotations

import polars as pl
import pytest
from lcmd_db.dataset._molecules import MoleculeDataset
from lcmd_db.dataset._reactions import ReactionDataset
from lcmd_db.dataset._source import EagerSource


def _empty_mol_df() -> pl.DataFrame:
    return pl.DataFrame({"id": [], "smiles": []}).cast({"id": pl.Int64})


def _mol_df(n: int = 10) -> pl.DataFrame:
    return pl.DataFrame({"id": list(range(n)), "w": [float(i) for i in range(n)]})


class TestEmptyDataset:
    @pytest.mark.parametrize("attr", ["__len__", "__iter__"])
    def test_empty_dataset_basic_ops(self, attr: str) -> None:
        ds = MoleculeDataset(EagerSource(_empty_mol_df()))
        if attr == "__len__":
            assert len(ds) == 0
        else:
            assert list(ds) == []

    def test_filter_to_empty(self) -> None:
        ds = MoleculeDataset(EagerSource(_mol_df(3)))
        assert len(ds.filter(pl.col("w") > 9999)) == 0

    def test_train_test_split_empty(self) -> None:
        ds = MoleculeDataset(EagerSource(_empty_mol_df()))
        train, test = ds.train_test_split()
        assert len(train) == 0
        assert len(test) == 0


class TestSingleRow:
    def test_single_molecule(self) -> None:
        ds = MoleculeDataset(EagerSource(pl.DataFrame({"id": [1], "smiles": ["C"]})))
        assert len(ds) == 1
        assert ds[0].id == 1

    def test_split_single_row_preserves_total(self) -> None:
        ds = MoleculeDataset(EagerSource(pl.DataFrame({"id": [1], "smiles": ["C"]})))
        train, test = ds.train_test_split(test_size=0.5)
        assert len(train) + len(test) == 1


class TestReactionMissingSources:
    def test_participants_without_molecules_gives_empty(self) -> None:
        rxn_df = pl.DataFrame({"id": [10], "barrier": [0.5]})
        parts_df = pl.DataFrame(
            {
                "reaction_id": [10],
                "molecule_id": [1],
                "role": ["reactant"],
                "step_from": [0.0],
                "step_to": [None],
                "label": [""],
            }
        )
        ds = ReactionDataset(
            EagerSource(rxn_df),
            participants_source=EagerSource(parts_df),
            molecules_source=None,
        )
        assert ds[0].participants == []

    def test_no_sources_gives_empty_participants(self) -> None:
        ds = ReactionDataset(EagerSource(pl.DataFrame({"id": [1], "x": [0]})))
        assert ds[0].participants == []


class TestChainedOperations:
    def test_filter_then_iterate(self) -> None:
        ds = MoleculeDataset(EagerSource(_mol_df(5)))
        mols = list(ds.filter(pl.col("w") >= 3))
        assert {m.id for m in mols} == {3, 4}

    @pytest.mark.parametrize("test_size", [0.2, 0.5, 0.8])
    def test_filter_then_split_preserves_total(self, test_size: float) -> None:
        ds = MoleculeDataset(EagerSource(_mol_df(20)))
        sub = ds.filter(pl.col("w") >= 10)
        train, test = sub.train_test_split(test_size=test_size)
        assert len(train) + len(test) == 10

    def test_select_drops_unselected_columns(self) -> None:
        df = pl.DataFrame({"id": [1], "a": ["x"], "b": [1.0], "c": [True]})
        ds = MoleculeDataset(EagerSource(df))
        mol = ds.select("a")[0]
        assert "a" in mol.properties
        assert "b" not in mol.properties
        assert "c" not in mol.properties
