from __future__ import annotations

from pathlib import Path

import polars as pl
import pytest
from lcmd_db.dataset._source import (
    DataSource,
    EagerSource,
    LazySource,
    source_for,
    source_for_entity,
)
from lcmd_db.types import DataFormat


class TestLazySource:
    def test_columns_without_collecting(self) -> None:
        lf = pl.LazyFrame({"a": [1], "b": ["x"]})
        src = LazySource(lf)
        assert src.columns == ["a", "b"]

    def test_lazy_returns_lazyframe(self) -> None:
        lf = pl.LazyFrame({"a": [1]})
        src = LazySource(lf)
        assert isinstance(src.lazy, pl.LazyFrame)

    def test_collect_returns_dataframe(self) -> None:
        lf = pl.LazyFrame({"a": [1, 2]})
        src = LazySource(lf)
        df = src.collect()
        assert isinstance(df, pl.DataFrame)
        assert df.height == 2

    def test_satisfies_protocol(self) -> None:
        src = LazySource(pl.LazyFrame({"x": [1]}))
        assert isinstance(src, DataSource)


class TestEagerSource:
    def test_columns(self) -> None:
        df = pl.DataFrame({"a": [1], "b": ["x"]})
        src = EagerSource(df)
        assert src.columns == ["a", "b"]

    def test_collect_returns_same_dataframe(self) -> None:
        df = pl.DataFrame({"a": [1]})
        src = EagerSource(df)
        assert src.collect() is df

    def test_lazy_wraps_in_lazyframe(self) -> None:
        df = pl.DataFrame({"a": [1]})
        src = EagerSource(df)
        assert isinstance(src.lazy, pl.LazyFrame)

    def test_satisfies_protocol(self) -> None:
        src = EagerSource(pl.DataFrame({"x": [1]}))
        assert isinstance(src, DataSource)


class TestSourceFor:
    def test_parquet(self, tmp_path: Path) -> None:
        path = tmp_path / "data.parquet"
        pl.DataFrame({"id": [1]}).write_parquet(path)
        src = source_for(path)
        assert isinstance(src, LazySource)
        assert src.collect().height == 1

    def test_csv(self, tmp_path: Path) -> None:
        path = tmp_path / "data.csv"
        pl.DataFrame({"id": [1]}).write_csv(path)
        src = source_for(path)
        assert isinstance(src, LazySource)

    def test_json(self, tmp_path: Path) -> None:
        path = tmp_path / "data.json"
        pl.DataFrame({"id": [1]}).write_json(path)
        src = source_for(path)
        assert isinstance(src, EagerSource)

    def test_unsupported_format_raises(self, tmp_path: Path) -> None:
        path = tmp_path / "data.xyz"
        path.touch()
        with pytest.raises(ValueError, match="Unsupported format"):
            source_for(path)


class TestSourceForEntity:
    def test_returns_source_when_file_exists(self, tmp_path: Path) -> None:
        pl.DataFrame({"id": [1]}).write_parquet(tmp_path / "molecules.parquet")
        src = source_for_entity(tmp_path, "molecules", DataFormat.PARQUET)
        assert src is not None
        assert src.collect().height == 1

    def test_returns_none_when_missing(self, tmp_path: Path) -> None:
        assert source_for_entity(tmp_path, "reactions", DataFormat.PARQUET) is None
