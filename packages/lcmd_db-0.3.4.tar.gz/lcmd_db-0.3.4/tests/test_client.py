from __future__ import annotations

from pathlib import Path

import polars as pl
import pytest
from lcmd_db._cache import DownloadCache
from lcmd_db.client import (
    _attach_structure_paths,
    _build_download_url,
    _build_include_set,
    _is_not_found,
    _read_entity,
    _read_metadata,
)
from lcmd_db.types import DataFormat, SubsetData


class TestBuildIncludeSet:
    def test_default(self) -> None:
        assert _build_include_set(("molecules",), False) == {"molecules"}

    def test_include_structures_adds_molecules(self) -> None:
        result = _build_include_set(("reactions",), include_structures=True)
        assert result == {"reactions", "structures", "molecules"}

    def test_multiple(self) -> None:
        result = _build_include_set(("molecules", "reactions"), False)
        assert result == {"molecules", "reactions"}

    def test_invalid_include_raises(self) -> None:
        with pytest.raises(ValueError, match="Invalid include values"):
            _build_include_set(("xyz",), False)

    def test_mixed_valid_invalid_raises(self) -> None:
        with pytest.raises(ValueError, match="xyz"):
            _build_include_set(("molecules", "xyz"), False)


class TestBuildDownloadUrl:
    def test_basic(self) -> None:
        url = _build_download_url(
            "qm9", {"molecules"}, DataFormat.PARQUET, None, None, None
        )
        assert "/api/v1/subsets/qm9/download/" in url
        assert "data_format=parquet" in url
        assert "include=molecules" in url

    def test_with_properties(self) -> None:
        url = _build_download_url(
            "qm9", {"molecules"}, DataFormat.CSV, ["mw", "smiles"], None, None
        )
        assert "molecule_properties=mw%2Csmiles" in url


class TestReadEntity:
    def test_reads_parquet(self, cache: DownloadCache) -> None:
        data_dir = next(cache.iter_extracted_dirs())
        df = _read_entity(data_dir, "molecules", DataFormat.PARQUET)
        assert df is not None
        assert df.shape[0] == 3

    def test_missing_entity_returns_none(self, cache: DownloadCache) -> None:
        data_dir = next(cache.iter_extracted_dirs())
        assert _read_entity(data_dir, "reactions", DataFormat.PARQUET) is None


class TestReadMetadata:
    def test_parses_metadata(self, cache: DownloadCache) -> None:
        data_dir = next(cache.iter_extracted_dirs())
        meta = _read_metadata(data_dir)
        assert meta is not None
        assert meta.subset == "test_subset"
        assert "molecules" in meta.entities
        assert meta.entities["molecules"].count == 3

    def test_missing_returns_none(self, tmp_path: Path) -> None:
        assert _read_metadata(tmp_path) is None


class TestAttachStructurePaths:
    def test_adds_column(self, tmp_path: Path) -> None:
        structures = tmp_path / "structures"
        structures.mkdir()
        (structures / "1.xyz").write_text("xyz")

        df = pl.DataFrame({"id": [1, 2]})
        result = _attach_structure_paths(df, structures)
        assert "structure_path" in result.columns

    def test_no_structures_dir(self, tmp_path: Path) -> None:
        df = pl.DataFrame({"id": [1]})
        result = _attach_structure_paths(df, tmp_path / "nonexistent")
        assert "structure_path" not in result.columns


class TestSubsetDataWiring:
    @pytest.fixture()
    def subset_data(self, cache: DownloadCache) -> SubsetData:
        data_dir = next(cache.iter_extracted_dirs())
        return SubsetData._from_download(
            data_dir=data_dir,
            data_format=DataFormat.PARQUET,
            molecules=_read_entity(data_dir, "molecules", DataFormat.PARQUET),
            metadata=_read_metadata(data_dir),
        )

    def test_data_dir_and_format_set(self, subset_data: SubsetData) -> None:
        assert subset_data._data_dir is not None
        assert subset_data._data_format == DataFormat.PARQUET

    def test_as_dataset_returns_molecule_dataset(self, subset_data: SubsetData) -> None:
        from lcmd_db.dataset._molecules import MoleculeDataset

        ds = subset_data.as_dataset("molecules")
        assert isinstance(ds, MoleculeDataset)
        assert len(ds) == 3


class TestIsNotFound:
    def test_requests_http_error_404(self) -> None:
        exc = type("HTTPError", (Exception,), {})()
        resp = type("Response", (), {"status_code": 404})()
        exc.response = resp  # type: ignore[attr-defined]
        assert _is_not_found(exc) is True

    def test_requests_http_error_500(self) -> None:
        exc = type("HTTPError", (Exception,), {})()
        resp = type("Response", (), {"status_code": 500})()
        exc.response = resp  # type: ignore[attr-defined]
        assert _is_not_found(exc) is False

    def test_urllib_http_error_404(self) -> None:
        exc = type("HTTPError", (Exception,), {"code": 404})()
        assert _is_not_found(exc) is True

    def test_generic_exception(self) -> None:
        assert _is_not_found(Exception("404 not found")) is False
