from __future__ import annotations

from lcmd_db._cache import DownloadCache


class TestComputeCacheKey:
    def test_deterministic(self) -> None:
        a = DownloadCache.compute_cache_key("qm9", ["molecules"], "parquet")
        b = DownloadCache.compute_cache_key("qm9", ["molecules"], "parquet")
        assert a == b

    def test_different_params_different_key(self) -> None:
        a = DownloadCache.compute_cache_key("qm9", ["molecules"], "parquet")
        b = DownloadCache.compute_cache_key(
            "qm9", ["molecules", "reactions"], "parquet"
        )
        assert a != b

    def test_order_independent(self) -> None:
        a = DownloadCache.compute_cache_key("qm9", ["molecules", "reactions"], "csv")
        b = DownloadCache.compute_cache_key("qm9", ["reactions", "molecules"], "csv")
        assert a == b

    def test_properties_affect_key(self) -> None:
        a = DownloadCache.compute_cache_key(
            "qm9", ["molecules"], "parquet", molecule_properties=["mw"]
        )
        b = DownloadCache.compute_cache_key(
            "qm9", ["molecules"], "parquet", molecule_properties=["mw", "smiles"]
        )
        assert a != b

    def test_length(self) -> None:
        key = DownloadCache.compute_cache_key("qm9", ["molecules"], "parquet")
        assert len(key) == 16


class TestDownloadCache:
    def test_iter_finds_metadata(self, cache: DownloadCache) -> None:
        dirs = list(cache.iter_extracted_dirs())
        assert len(dirs) >= 1
        assert all((d / "metadata.json").exists() for d in dirs)

    def test_clear_nonexistent_is_noop(self, cache: DownloadCache) -> None:
        cache.clear("nonexistent_subset_xyz")
