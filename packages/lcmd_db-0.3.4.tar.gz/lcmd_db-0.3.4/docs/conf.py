"""Sphinx configuration for lcmd[db]."""

import lcmd_db

project = "lcmd[db]"
author = "LCMD, EPFL"
copyright = "2026, LCMD, EPFL"
version = lcmd_db.__version__
release = lcmd_db.__version__

extensions = [
    "sphinx.ext.autodoc",
    "sphinx.ext.autosummary",
    "sphinx.ext.intersphinx",
    "sphinx.ext.napoleon",
    "sphinx.ext.viewcode",
    "sphinx_autodoc_typehints",
    "sphinx_copybutton",
    "sphinx_design",
    "sphinx_toolbox.more_autodoc.typevars",
    "sphinx_toolbox.more_autodoc.generic_bases",
    "sphinx_click",
]

html_theme = "pydata_sphinx_theme"
html_title = "lcmd[db]"
html_static_path = ["_static"]
html_css_files = ["custom.css"]

html_theme_options = {
    "logo": {
        "image_light": "_static/logo.svg",
        "image_dark": "_static/logo-dark.svg",
    },
    "github_url": "https://github.com/lcmd-epfl/db",
    "show_toc_level": 2,
    "navigation_with_keys": False,
    "show_prev_next": True,
    "pygments_light_style": "default",
    "pygments_dark_style": "monokai",
    "header_links_before_dropdown": 6,
    "navbar_align": "left",
    "back_to_top_button": True,
    "use_edit_page_button": True,
    "icon_links": [
        {
            "name": "LCMD Database",
            "url": "https://lcmd-app.epfl.ch",
            "icon": "fa-solid fa-database",
        },
    ],
}

html_context = {
    "github_user": "lcmd-epfl",
    "github_repo": "db",
    "github_version": "master",
    "doc_path": "packages/lcmd-client/docs/",
}

# Copybutton
copybutton_prompt_text = r">>> |\.\.\. |\$ "
copybutton_prompt_is_regexp = True

# Autodoc
autodoc_default_options = {
    "members": True,
    "show-inheritance": True,
    "member-order": "bysource",
}
autodoc_typehints = "description"
autodoc_typehints_description_target = "documented_params"
autodoc_class_signature = "separated"
autosummary_generate = True

# Type display
always_use_bars_union = True
python_display_short_literal_types = True

# sphinx-autodoc-typehints
typehints_defaults = "braces"
typehints_use_signature = False
typehints_use_signature_return = False
simplify_optional_unions = True
typehints_fully_qualified = False


def _typehints_formatter(annotation: object, config: object) -> str | None:
    """Render TypeVars by name and fix polars cross-references."""
    from typing import TypeVar

    if isinstance(annotation, TypeVar):
        return f"``{annotation.__name__}``"
    if isinstance(annotation, type):
        module = getattr(annotation, "__module__", "")
        qualname = getattr(annotation, "__qualname__", "")
        if module.startswith("polars.") and "." not in qualname:
            return f":py:class:`polars.{qualname}`"
    ref = str(annotation)
    if ref.startswith("polars."):
        return f":py:class:`{ref}`"
    return None


typehints_formatter = _typehints_formatter

# sphinx-toolbox
all_typevars = False
no_unbound_typevars = True
generic_bases_fully_qualified = False

# Napoleon
napoleon_google_docstring = True
napoleon_numpy_docstring = False
napoleon_attr_annotations = True

# Intersphinx
_POLARS_URL = "https://docs.pola.rs/api/python/stable/"
intersphinx_mapping = {
    "python": ("https://docs.python.org/3", None),
    "polars": (_POLARS_URL, ("_polars_inv.inv", None)),
    "pandas": ("https://pandas.pydata.org/pandas-docs/stable/", None),
    "ase": ("https://wiki.fysik.dtu.dk/ase/", None),
}

autodoc_type_aliases = {
    "Value": "Value",
    "pl.DataFrame": "polars.DataFrame",
    "pl.LazyFrame": "polars.LazyFrame",
    "pl.Expr": "polars.Expr",
}

add_module_names = False
toc_object_entries_show_parents = "hide"
exclude_patterns = ["_build"]
suppress_warnings = ["autodoc.import_object"]
nitpicky = False
