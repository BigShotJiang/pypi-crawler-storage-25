CLI Reference
=============

.. click:: lcmd_db.cli:cli
   :prog: lcmd-db
   :nested: full
   :commands: download,schema,stubs,cache
