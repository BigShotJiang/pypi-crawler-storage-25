lcmd[db]
========

Python client for the `LCMD molecular database <https://lcmd-app.epfl.ch>`_.

.. code-block:: python

   from lcmd_db import load_dataset

   data = load_dataset("oscar_nhc")
   molecules = data.as_dataset("molecules")
   mol = molecules[0]
   print(mol.properties["smiles"], mol.properties["energy"])

Installation
------------

.. tab-set::

   .. tab-item:: uv

      .. code-block:: bash

         uv add lcmd-db

   .. tab-item:: pip

      .. code-block:: bash

         pip install lcmd-db

.. grid:: 3
   :gutter: 3

   .. grid-item-card:: Get Started
      :link: get-started/index
      :link-type: doc

      Examples for molecules, reactions, fragments, and assembly.

   .. grid-item-card:: CLI
      :link: cli
      :link-type: doc

      Download data, inspect schemas, manage cache and stubs.

   .. grid-item-card:: API Reference
      :link: api/index
      :link-type: doc

      Full reference for all classes, functions, and types.

.. toctree::
   :maxdepth: 2
   :hidden:

   get-started/index
   cli
   api/index
