Typed Stubs
===========

After the first download, per-subset type stubs are auto-generated so
your IDE autocompletes property keys and narrows types.

.. code-block:: python

   from lcmd_db.subsets import oscar_nhc

   data = oscar_nhc.load()
   mol = data.as_dataset("molecules")[0]
   mol.properties["energy"]  # IDE shows: float | None with docstring

   from lcmd_db.subsets import fragflp

   fragflp.FragmentType     # Literal["backbone", "lewis_acid_aryl", ...]
   fragflp.assemble_default(LAr1="...", LAr2="...", ...)  # typed kwargs

Manual sync:

.. code-block:: bash

   $ lcmd-db stubs sync
   $ lcmd-db stubs generate oscar_nhc

Disable auto-sync:

.. code-block:: bash

   $ export LCMD_DB_AUTO_SYNC_STUBS=false
