Get Started
===========

Step-by-step guides for loading, filtering, and exporting data from the
LCMD molecular database.

.. grid:: 2
   :gutter: 3

   .. grid-item-card:: Molecules
      :link: molecules
      :link-type: doc

      Load molecular datasets, filter by properties, export to Polars/Pandas.

   .. grid-item-card:: Reactions
      :link: reactions
      :link-type: doc

      Work with reaction datasets and participant molecules.

   .. grid-item-card:: Fragments
      :link: fragments
      :link-type: doc

      Query typed fragment categories and filter by type.

   .. grid-item-card:: Assembly
      :link: assembly
      :link-type: doc

      Combine fragment SMILES into full molecules using templates.

   .. grid-item-card:: Typed Stubs
      :link: typed-stubs
      :link-type: doc

      IDE autocomplete and type narrowing for property keys.

   .. grid-item-card:: Configuration
      :link: configuration
      :link-type: doc

      Environment variables and settings.

.. toctree::
   :maxdepth: 1
   :hidden:

   molecules
   reactions
   fragments
   assembly
   typed-stubs
   configuration
