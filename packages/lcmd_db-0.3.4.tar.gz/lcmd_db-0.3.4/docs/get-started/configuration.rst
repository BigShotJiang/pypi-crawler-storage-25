Configuration
=============

All settings are configurable via environment variables:

.. list-table::
   :header-rows: 1
   :widths: 30 15 55

   * - Variable
     - Default
     - Description
   * - ``LCMD_DB_BASE_URL``
     - ``https://lcmd-app.epfl.ch``
     - API base URL
   * - ``LCMD_DB_CACHE_DIR``
     - system cache
     - Local cache directory
   * - ``LCMD_DB_TIMEOUT``
     - ``300``
     - Download timeout in seconds
   * - ``LCMD_DB_AUTO_SYNC_STUBS``
     - ``true``
     - Auto-regenerate stubs on import
