Fragments
=========

The **FragFLP** subset contains frustrated Lewis pair fragments with
typed fragment categories.

.. code-block:: python

   from lcmd_db import load_dataset
   import polars as pl

   data = load_dataset("fragflp", include=["fragments"])
   fragments = data.as_dataset("fragments")

   frag = fragments[0]
   frag.properties["smiles"]
   frag.fragment_type  # "backbone", "lewis_acid_aryl", etc.

   # Filter by type
   acids = fragments.filter(pl.col("fragment_type_slug") == "lewis_acid_aryl")

With :doc:`typed stubs <typed-stubs>`, ``fragment_type`` is narrowed to a
``Literal`` of the known types instead of plain ``str``.

.. seealso::

   :class:`~lcmd_db.FragmentDataset` --- full API reference,
   :doc:`assembly` --- combine fragments into molecules,
   :doc:`typed-stubs` --- IDE autocomplete for property keys
