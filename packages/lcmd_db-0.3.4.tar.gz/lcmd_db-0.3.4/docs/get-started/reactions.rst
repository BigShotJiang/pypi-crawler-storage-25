Reactions
=========

The **Pictet-Spengler** subset contains reactions with thermodynamic
properties and participant molecules.

.. code-block:: python

   from lcmd_db import load_dataset, ParticipantRole

   data = load_dataset("pictet_spengler", include=["molecules", "reactions"])
   reactions = data.as_dataset("reactions")
   rxn = reactions[0]

   rxn.properties["deltadeltag"]    # relative free energy
   rxn.properties["deltag_int1"]    # intermediate barrier

   # Participants with roles
   for p in rxn.participants:
       print(p.role.value, p.molecule.properties["smiles"][:40])

   # Filter by role
   catalysts = [
       p.molecule for p in rxn.participants
       if p.role == ParticipantRole.CATALYST
   ]

.. dropdown:: Available participant roles

   ``REACTANT``, ``PRODUCT``, ``CATALYST``, ``CO_CATALYST``,
   ``SUBSTRATE``, ``INTERMEDIATE``, ``TRANSITION_STATE``, ``SOLVENT``, ``ADDITIVE``.

.. seealso::

   :class:`~lcmd_db.ReactionDataset` --- full API reference,
   :class:`~lcmd_db.ParticipantRole` --- all role values,
   :doc:`typed-stubs` --- IDE autocomplete for property keys
