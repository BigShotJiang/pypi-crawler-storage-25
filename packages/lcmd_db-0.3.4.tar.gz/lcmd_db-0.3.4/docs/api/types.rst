Entry Types
===========

.. autosummary::
   :nosignatures:

   lcmd_db.Molecule
   lcmd_db.Reaction
   lcmd_db.Fragment
   lcmd_db.Participant
   lcmd_db.ParticipantRole
   lcmd_db.SubsetData
   lcmd_db.SubsetMetadata
   lcmd_db.PropertyInfo

Type Parameters
---------------

.. autotypevar:: lcmd_db.types.Properties

   Properties type parameter for :class:`Molecule`, :class:`Reaction`, and :class:`Fragment`.
   Defaults to ``dict[str, Value]``; narrowed to a ``TypedDict`` with per-subset stubs.

.. autotypevar:: lcmd_db.types.FType

   Fragment type parameter for :class:`Fragment`.
   Defaults to ``str | None``; narrowed to a ``Literal`` with per-subset stubs.

.. data:: lcmd_db.types.Value
   :type: TypeAlias
   :value: str | int | float | bool | None

   Union of allowed property value types.

Molecule
--------

.. autoclass:: lcmd_db.Molecule
   :members:
   :exclude-members: __init__

Reaction
--------

.. autoclass:: lcmd_db.Reaction
   :members:
   :exclude-members: __init__

Fragment
--------

.. autoclass:: lcmd_db.Fragment
   :members:
   :exclude-members: __init__

Participants
------------

.. autoclass:: lcmd_db.Participant
   :members:
   :exclude-members: __init__
   :no-show-inheritance:

.. autoclass:: lcmd_db.ParticipantRole
   :members:
   :undoc-members:
   :exclude-members: __new__

Container
---------

.. autoclass:: lcmd_db.SubsetData
   :members:
   :exclude-members: __init__

Metadata
--------

.. autoclass:: lcmd_db.SubsetMetadata
   :members:
   :exclude-members: __init__, model_config

.. autoclass:: lcmd_db.types.EntityMetadata
   :members:
   :exclude-members: __init__, model_config

.. autoclass:: lcmd_db.PropertyInfo
   :members:
   :exclude-members: __init__, model_config

Enums
-----

.. autoclass:: lcmd_db.DataFormat
   :members:
   :undoc-members:
   :exclude-members: __new__

.. autoclass:: lcmd_db.EntityType
   :members:
   :undoc-members:
   :exclude-members: __new__

.. autoclass:: lcmd_db.PropertyDataType
   :members:
   :undoc-members:
   :exclude-members: __new__
