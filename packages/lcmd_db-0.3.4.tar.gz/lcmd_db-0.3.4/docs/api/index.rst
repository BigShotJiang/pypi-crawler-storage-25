API Reference
=============

.. toctree::
   :maxdepth: 2

   client
   types
   dataset
   assembly
   adapters
