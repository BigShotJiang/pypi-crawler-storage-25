Assembly
========

.. autosummary::
   :nosignatures:

   lcmd_db.AssemblyTemplate
   lcmd_db.AssemblyResult
   lcmd_db.AssemblyTemplateInfo
   lcmd_db.SlotInfo

Template
--------

.. autoclass:: lcmd_db.AssemblyTemplate
   :members:
   :exclude-members: __init__

Result
------

.. autoclass:: lcmd_db.AssemblyResult
   :members:
   :exclude-members: __init__

Metadata
--------

.. autoclass:: lcmd_db.AssemblyTemplateInfo
   :members:
   :exclude-members: __init__, model_config

.. autoclass:: lcmd_db.SlotInfo
   :members:
   :exclude-members: __init__, model_config
