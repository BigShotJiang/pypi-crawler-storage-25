Client
======

.. autosummary::
   :nosignatures:

   lcmd_db.load_dataset
   lcmd_db.clear_cache
   lcmd_db.schema
   lcmd_db.settings.Settings

Loading
-------

.. autofunction:: lcmd_db.load_dataset

.. autofunction:: lcmd_db.clear_cache

Schema
------

.. autofunction:: lcmd_db.schema

Settings
--------

.. autoclass:: lcmd_db.settings.Settings
   :members:
   :exclude-members: model_config

Exceptions
----------

.. autoexception:: lcmd_db.LCMDError

.. autoexception:: lcmd_db.DatasetNotFoundError
   :show-inheritance:

.. autoexception:: lcmd_db.DownloadError
   :show-inheritance:

.. autoexception:: lcmd_db.SchemaError
   :show-inheritance:

.. autoexception:: lcmd_db.AssemblyError
   :show-inheritance:
