class TransportClosedError(RuntimeError):
    pass
