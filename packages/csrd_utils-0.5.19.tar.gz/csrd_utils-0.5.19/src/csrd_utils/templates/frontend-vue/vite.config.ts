import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

export default defineConfig({
  plugins: [vue()],
  server: {
    port: ${frontend_port},
    proxy: {
      '/api': {
        target: 'http://${gateway_host}:${gateway_port}',
        changeOrigin: true,
      },
    },
  },
})
