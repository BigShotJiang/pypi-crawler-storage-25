from sv_smartpdf import parse

def main():
    # Example usage (assuming 'sample.pdf' exists)
    try:
        doc = parse("sample.pdf")
        
        print(f"Title: {doc.title}")
        print(f"Pages: {doc.metadata.page_count}")
        
        print("\nSections:")
        def print_section(sec, indent=0):
            print(f"{'  ' * indent}- {sec.title}: {len(sec.content)} chars")
            for child in sec.children:
                print_section(child, indent + 1)
                
        for section in doc.sections:
            print_section(section)
            
    except Exception as e:
        print(f"Error: {e}")
        print("Please provide 'sample.pdf' in the current directory to run this example.")
        
    if 'doc' in locals():
        print(f"\nTables Extracted: {len(doc.tables)}")
        if len(doc.tables) > 0:
            print("First table preview:")
            print(doc.tables[0].df.head())

if __name__ == "__main__":
    main()
