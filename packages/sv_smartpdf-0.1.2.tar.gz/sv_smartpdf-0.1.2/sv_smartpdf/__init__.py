"""
sv-smartpdf: High-level PDF structure extraction library.
"""

from .core import Document, parse
from .config import SmartPDFConfig
from .models import Section, Table, Figure, Reference

__version__ = "0.1.2"
__all__ = ["parse", "Document", "SmartPDFConfig", "Section", "Table", "Figure", "Reference"]
