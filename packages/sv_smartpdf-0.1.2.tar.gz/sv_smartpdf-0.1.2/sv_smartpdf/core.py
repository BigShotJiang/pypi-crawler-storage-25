from typing import Union, IO, List, Optional, Any, Dict
from os import PathLike

from .config import SmartPDFConfig
from .models import Section, Table, Figure, Reference, Metadata
from .parsers.pymupdf_parser import PyMuPDFParser
from .parsers.base import BaseParser, ParsedData

class Document:
    """High-level representation of a parsed PDF document."""
    
    def __init__(self, data: 'ParsedData'):
        self._data = data
        
    @property
    def title(self) -> Optional[str]:
        return self._data.metadata.title
        
    @property
    def metadata(self) -> Metadata:
        return self._data.metadata
        
    @property
    def sections(self) -> List[Section]:
        return self._data.sections
        
    @property
    def tables(self) -> List[Table]:
        return self._data.tables
        
    @property
    def figures(self) -> List[Figure]:
        return self._data.figures
        
    @property
    def references(self) -> List[Reference]:
        return self._data.references
        
    def to_markdown(self) -> str:
        """Convert the document sections to Markdown format."""
        md = ""
        if self.title:
            md += f"# {self.title}\n\n"
        for section in self.sections:
            md += section.to_markdown()
        return md
        
    def to_dict(self) -> Dict[str, Any]:
        """Convert the document to a dictionary."""
        return {
            "metadata": self.metadata.model_dump() if hasattr(self.metadata, 'model_dump') else self.metadata.dict(),
            "sections": [s.model_dump() if hasattr(s, 'model_dump') else s.dict() for s in self.sections],
            "tables": [t.model_dump() if hasattr(t, 'model_dump') else t.dict() for t in self.tables],
            "figures": [f.model_dump() if hasattr(f, 'model_dump') else f.dict() for f in self.figures],
            "references": [r.model_dump() if hasattr(r, 'model_dump') else r.dict() for r in self.references],
        }

def get_parser(config: SmartPDFConfig) -> BaseParser:
    """Factory function to get the appropriate parser based on config."""
    if config.backend.lower() == "pymupdf":
        return PyMuPDFParser(config)
    else:
        raise ValueError(f"Unsupported backend: {config.backend}")

def parse(
    file_or_path: Union[str, PathLike, bytes, IO[bytes]],
    config: Optional[SmartPDFConfig] = None,
    **kwargs
) -> Document:
    """
    Parse a PDF file into a high-level Document object.
    
    Args:
        file_or_path: Path to the PDF file, URL, bytes, or file-like object.
        config: Optional SmartPDFConfig object.
        **kwargs: Configuration overrides if config is not provided.
        
    Returns:
        Document: A parsed representation of the PDF.
    """
    if config is None:
        config = SmartPDFConfig(**kwargs)
        
    if isinstance(file_or_path, str) and (file_or_path.startswith("http://") or file_or_path.startswith("https://")):
        import urllib.request
        with urllib.request.urlopen(file_or_path) as response:
            file_or_path = response.read()
            
    parser = get_parser(config)
    parsed_data = parser.parse(file_or_path)
    return Document(parsed_data)
