from pydantic import BaseModel, ConfigDict
from typing import List, Optional
import pandas as pd

class BoundingBox(BaseModel):
    x0: float
    y0: float
    x1: float
    y1: float

class Reference(BaseModel):
    id: str
    text: str
    authors: List[str] = []
    year: Optional[int] = None
    title: Optional[str] = None

class Figure(BaseModel):
    id: str
    caption: Optional[str] = None
    bbox: Optional[BoundingBox] = None
    page_number: int
    image_bytes: Optional[bytes] = None

class Table(BaseModel):
    id: str
    caption: Optional[str] = None
    bbox: Optional[BoundingBox] = None
    page_number: int
    data: List[List[str]]
    
    model_config = ConfigDict(arbitrary_types_allowed=True)
    
    @property
    def df(self) -> pd.DataFrame:
        if not self.data:
            return pd.DataFrame()
        # Assume first row is header if we have data
        if len(self.data) > 1:
            return pd.DataFrame(self.data[1:], columns=self.data[0])
        return pd.DataFrame(self.data)

class Section(BaseModel):
    title: str
    level: int
    content: str
    children: List['Section'] = []
    
    def to_markdown(self) -> str:
        md = f"{'#' * self.level} {self.title}\n\n{self.content}\n\n"
        for child in self.children:
            md += child.to_markdown()
        return md

class Metadata(BaseModel):
    title: Optional[str] = None
    authors: List[str] = []
    creation_date: Optional[str] = None
    producer: Optional[str] = None
    page_count: int = 0
