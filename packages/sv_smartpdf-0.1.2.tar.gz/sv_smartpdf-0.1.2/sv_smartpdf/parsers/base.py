from abc import ABC, abstractmethod
from typing import Union, IO
from os import PathLike
from ..models import Section, Table, Figure, Reference, Metadata
from ..config import SmartPDFConfig

class ParsedData:
    """Intermediate data structure returned by parsers."""
    def __init__(self):
        self.metadata: Metadata = Metadata()
        self.sections: list[Section] = []
        self.tables: list[Table] = []
        self.figures: list[Figure] = []
        self.references: list[Reference] = []

class BaseParser(ABC):
    """Base class for all PDF parsers."""
    
    def __init__(self, config: SmartPDFConfig):
        self.config = config
        
    @abstractmethod
    def parse(self, file_or_path: Union[str, PathLike, bytes, IO[bytes]]) -> ParsedData:
        pass
