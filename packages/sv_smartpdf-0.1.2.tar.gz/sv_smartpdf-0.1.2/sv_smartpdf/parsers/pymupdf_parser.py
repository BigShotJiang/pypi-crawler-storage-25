import fitz  # PyMuPDF
from typing import Union, IO
from os import PathLike
import io
import collections

from .base import BaseParser, ParsedData
from ..models import Section, Table

class PyMuPDFParser(BaseParser):
    """Parser implementation using PyMuPDF (fitz) and pdfplumber for tables."""
    
    def parse(self, file_or_path: Union[str, PathLike, bytes, IO[bytes]]) -> ParsedData:
        data = ParsedData()
        
        # Save raw bytes or path for pdfplumber fallback
        raw_source = file_or_path
        if hasattr(file_or_path, 'read'):
            raw_source = file_or_path.read()  # read to bytes
            # Reset pointer if possible, though fitz takes bytes
            
        # Open the document with PyMuPDF
        if isinstance(raw_source, (str, PathLike)):
            doc = fitz.open(raw_source)
        elif isinstance(raw_source, bytes):
            doc = fitz.open("pdf", raw_source)
        else:
            raise ValueError("Unsupported file_or_path type")
            
        try:
            self._extract_metadata(doc, data)
            self._extract_content(doc, data)
            if self.config.extract_tables:
                self._extract_tables(raw_source, data)
        finally:
            doc.close()
            
        return data
        
    def _extract_metadata(self, doc: fitz.Document, data: ParsedData):
        meta = doc.metadata
        if meta:
            data.metadata.title = meta.get("title")
            data.metadata.authors = [a.strip() for a in meta.get("author", "").split(",") if a.strip()]
            data.metadata.creation_date = meta.get("creationDate")
            data.metadata.producer = meta.get("producer")
        data.metadata.page_count = len(doc)
        
    def _get_base_font_size(self, doc: fitz.Document) -> float:
        """Heuristic to find the most common font size (body text)."""
        sizes = collections.Counter()
        # Scan first few pages to determine base font
        for page_num in range(min(5, len(doc))):
            page = doc[page_num]
            blocks = page.get_text("dict")["blocks"]
            for b in blocks:
                if "lines" in b:
                    for line in b["lines"]:
                        for s in line["spans"]:
                            if s["text"].strip():
                                sizes[round(s["size"])] += len(s["text"])
        if sizes:
            return sizes.most_common(1)[0][0]
        return 11.0 # default fallback
        
    def _is_heading(self, text: str, size: float, is_bold: bool, base_size: float) -> int:
        """Returns heading level (1-4) or 0 if not a heading."""
        import re
        text_upper = text.upper()
        
        # Explicit Regex patterns
        if re.match(r'^(CHAPTER|PART)[\s\-\–\—\ufffd]*[A-Z0-9IVX]+', text_upper):
            return 1
        if re.match(r'^\d+\.\s+[A-Z]', text):
            return 2
        if re.match(r'^[A-Z][A-Z\s]+$', text_upper) and len(text) > 5 and is_bold:
            return 2
            
        # Font size heuristics
        if size >= base_size * 1.4:
            return 1
        elif size >= base_size * 1.15 and is_bold:
            return 2
        elif size >= base_size * 1.05 and is_bold:
            return 3
        elif is_bold and size >= self.config.heading_font_size_threshold:
            return 3
            
        return 0
        
    def _extract_content(self, doc: fitz.Document, data: ParsedData):
        """Extract content with smart heading detection and real hierarchy building."""
        base_size = self._get_base_font_size(doc)
        
        # Heuristic: Extract Title from the largest text on the first page
        if not data.metadata.title and len(doc) > 0:
            page1_blocks = doc[0].get_text("dict", sort=True)["blocks"]
            largest_text = ""
            max_s = 0.0
            for b in page1_blocks:
                if "lines" in b:
                    for line in b["lines"]:
                        for s in line["spans"]:
                            txt = s["text"].strip()
                            if s["size"] > max_s and len(txt) > 3:
                                max_s = s["size"]
                                largest_text = txt
            if largest_text:
                data.metadata.title = largest_text
        
        root_section = Section(title="Document Root", level=0, content="")
        stack = [root_section]
        last_heading_title = ""
        
        for page_num in range(len(doc)):
            page = doc[page_num]
            # sort=True ensures blocks are roughly in reading order
            blocks = page.get_text("dict", sort=True)["blocks"]
            
            for b in blocks:
                if "lines" not in b:
                    continue
                    
                for line in b["lines"]:
                    # Group spans in the line
                    line_text = ""
                    max_size = 0.0
                    is_bold = False
                    
                    for s in line["spans"]:
                        text = s["text"].strip()
                        if not text:
                            continue
                        line_text += text + " "
                        if s["size"] > max_size:
                            max_size = s["size"]
                        if s["flags"] & 2 ** 4:
                            is_bold = True
                            
                    import re
                    line_text = re.sub(r'\s+', ' ', line_text).strip()
                    if not line_text:
                        continue
                        
                    # Skip common headers/footers (noise)
                    text_upper = line_text.upper()
                    if "NATURAL LANGUAGE PROCESSING" in text_upper or "QUESTION BANK" in text_upper:
                        continue
                        
                    level = self._is_heading(line_text, max_size, is_bold, base_size)
                    
                    if level > 0:
                        # Avoid duplicate consecutive headings
                        if line_text == last_heading_title:
                            continue
                            
                        new_section = Section(title=line_text, level=level, content="")
                        last_heading_title = line_text
                        
                        # Find correct parent in stack
                        while stack[-1].level >= level and len(stack) > 1:
                            stack.pop()
                            
                        stack[-1].children.append(new_section)
                        stack.append(new_section)
                    else:
                        # Properly attach non-heading text as content to the active section
                        if stack[-1].content:
                            stack[-1].content += " "
                        stack[-1].content += line_text
                        last_heading_title = "" # Reset duplicate heading blocker
                        
        data.sections = root_section.children

    def _extract_tables(self, raw_source: Union[str, PathLike, bytes], data: ParsedData):
        """Extract tables using pdfplumber as a fallback."""
        try:
            import pdfplumber
        except ImportError:
            # Silently skip if pdfplumber is not installed, or we could log a warning.
            return
            
        file_obj = raw_source
        if isinstance(file_obj, bytes):
            file_obj = io.BytesIO(file_obj)
            
        try:
            with pdfplumber.open(file_obj) as pdf:
                for i, page in enumerate(pdf.pages):
                    tables = page.extract_tables()
                    for idx, table in enumerate(tables):
                        if not table:
                            continue
                        # Clean table
                        clean_table = []
                        for row in table:
                            clean_row = [str(cell).strip() if cell is not None else "" for cell in row]
                            # Only add rows that aren't completely empty
                            if any(clean_row):
                                clean_table.append(clean_row)
                                
                        if clean_table:
                            data.tables.append(Table(
                                id=f"table_p{i+1}_{idx+1}",
                                page_number=i+1,
                                data=clean_table
                            ))
        except Exception:
            pass # Handle gracefully if pdfplumber fails
