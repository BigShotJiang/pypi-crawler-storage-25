from pydantic import BaseModel, Field

class SmartPDFConfig(BaseModel):
    """Configuration for the SmartPDF parser."""
    
    extract_tables: bool = True
    extract_figures: bool = True
    extract_references: bool = True
    
    # Advanced settings
    backend: str = Field(default="pymupdf", description="Backend parser to use (pymupdf, docling, unstructured)")
    use_ocr_fallback: bool = False
    language: str = "eng"
    
    # Heading detection heuristics (if ML is not used)
    heading_font_size_threshold: float = 12.0
    detect_reading_order: bool = True
