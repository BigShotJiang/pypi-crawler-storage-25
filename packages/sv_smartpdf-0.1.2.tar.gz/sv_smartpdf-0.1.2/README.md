# sv-smartpdf

The best high-level PDF structure extraction library in Python that solves the painful manual work developers currently face.

Existing tools are powerful but low-level. `sv-smartpdf` provides a beautiful, high-level interface for extracting hierarchical sections, tables, figures, and metadata from complex PDFs.

## Installation

```bash
pip install sv-smartpdf
```

For OCR support:
```bash
pip install sv-smartpdf[ocr]
```

## Quick Start

```python
from sv_smartpdf import parse

# Parse a document
doc = parse("paper.pdf")

# Beautiful high-level interface
print(doc.title)
print(doc.metadata)

# Hierarchical sections
for section in doc.sections:
    print(f"{'  ' * section.level}- {section.title}")
    
# Rich table objects
for table in doc.tables:
    print(table.df) # pandas DataFrame
```
