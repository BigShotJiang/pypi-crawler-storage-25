from sv_smartpdf.models import Section

def test_section_to_markdown():
    section = Section(
        title="Main Heading",
        level=1,
        content="This is the main content.",
        children=[
            Section(
                title="Sub Heading",
                level=2,
                content="Sub content."
            )
        ]
    )
    
    md = section.to_markdown()
    assert "# Main Heading" in md
    assert "This is the main content." in md
    assert "## Sub Heading" in md
    assert "Sub content." in md
