from __future__ import annotations

from typing import Any

from fastapi import FastAPI
from pydantic import BaseModel, Field

from state_trace.memory import MemoryEngine


class StoreRequest(BaseModel):
    text: str
    context: dict[str, Any] = Field(default_factory=dict)


class RetrieveRequest(BaseModel):
    query: str
    context: dict[str, Any] = Field(default_factory=dict)
    limit: int = 5
    depth_limit: int = 2
    include_compressed: bool = False
    include_all_namespaces: bool = False
    explain: bool = False


class RetrieveBriefRequest(RetrieveRequest):
    mode: str = "small_model"


def create_app(engine: MemoryEngine | None = None) -> FastAPI:
    app = FastAPI(title="state-trace", version="0.1.0")
    memory_engine = engine or MemoryEngine()

    @app.post("/store")
    def store_memory(request: StoreRequest) -> dict[str, Any]:
        node = memory_engine.store(request.text, request.context)
        return {
            "node": node.model_dump(mode="json"),
            "graph": memory_engine.graph_snapshot(),
        }

    @app.post("/retrieve")
    def retrieve_memory(request: RetrieveRequest) -> dict[str, Any]:
        return memory_engine.retrieve(
            query=request.query,
            context=request.context,
            limit=request.limit,
            depth_limit=request.depth_limit,
            include_compressed=request.include_compressed,
            include_all_namespaces=request.include_all_namespaces,
            explain=request.explain,
        )

    @app.post("/retrieve_brief")
    def retrieve_memory_brief(request: RetrieveBriefRequest) -> dict[str, Any]:
        return memory_engine.retrieve_brief(
            query=request.query,
            context=request.context,
            limit=request.limit,
            depth_limit=request.depth_limit,
            include_compressed=request.include_compressed,
            mode=request.mode,
            include_all_namespaces=request.include_all_namespaces,
            explain=request.explain,
        )

    @app.get("/graph")
    def get_graph() -> dict[str, list[dict]]:
        return memory_engine.graph_snapshot()

    return app


app = create_app()
