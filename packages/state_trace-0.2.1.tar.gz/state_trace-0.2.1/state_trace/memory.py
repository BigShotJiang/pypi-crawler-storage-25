from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any

from state_trace.capacity import CapacityConfig, decay_importance, enforce_capacity, update_recency
from state_trace.graph import GraphManager
from state_trace.ingestion import (
    ingest_agent_log,
    ingest_agent_log_file,
    ingest_event,
    ingest_runtime_action,
    ingest_runtime_observation,
    ingest_runtime_test_result,
)
from state_trace.retrieval import RetrievalFeatureConfig, build_agent_brief, retrieve
from state_trace.scoring import ScoreConfig
from state_trace.storage import SQLiteBackend, is_sqlite_path
from state_trace.types import Edge, Node


SCORE_COMPONENT_KEYS = (
    "relevance",
    "causal_proximity",
    "state_match",
    "artifact_bridge",
    "edge_semantic_bonus",
    "provenance_bonus",
    "intent_bonus",
    "sequence_bonus",
    "temporal_bonus",
    "supersession_bonus",
    "query_term_bonus",
)


def _build_score_explanations(nodes: list[dict[str, Any]]) -> list[dict[str, Any]]:
    explanations: list[dict[str, Any]] = []
    for node in nodes:
        breakdown = {key: round(float(node.get(key, 0.0) or 0.0), 4) for key in SCORE_COMPONENT_KEYS}
        top_signals = sorted(
            ((key, value) for key, value in breakdown.items() if abs(value) >= 0.05),
            key=lambda item: abs(item[1]),
            reverse=True,
        )[:4]
        explanations.append(
            {
                "id": node.get("id"),
                "type": node.get("type"),
                "score": node.get("score"),
                "breakdown": breakdown,
                "top_signals": [{"component": key, "value": value} for key, value in top_signals],
                "matched_terms": node.get("matched_terms", []),
                "depth": node.get("depth"),
            }
        )
    return explanations


class MemoryEngine:
    def __init__(
        self,
        capacity_limit: float = 64.0,
        storage_path: str | Path | None = None,
        score_config: ScoreConfig | None = None,
        capacity_config: CapacityConfig | None = None,
        namespace: str | None = None,
    ) -> None:
        self.capacity_limit = capacity_limit
        self.storage_path = Path(storage_path) if storage_path else None
        self.score_config = score_config or ScoreConfig()
        self.capacity_config = capacity_config or CapacityConfig()
        self.namespace = namespace
        self._sqlite: SQLiteBackend | None = None
        if self.storage_path and is_sqlite_path(self.storage_path):
            self._sqlite = SQLiteBackend(self.storage_path)
            self.graph_manager = self._sqlite.load()
        elif self.storage_path and self.storage_path.exists():
            self.graph_manager = GraphManager.load_json(self.storage_path)
        else:
            self.graph_manager = GraphManager()
        self._runtime_sessions: dict[str, dict[str, Any]] = {}

    def store(self, text: str, context: dict[str, Any] | None = None) -> Node:
        node = ingest_event(text=text, context=self._apply_namespace(context), graph_manager=self.graph_manager)
        self.step()
        self._save()
        return node

    def store_agent_log(
        self,
        log_or_path: str | Path | dict[str, Any] | list[dict[str, Any]],
        context: dict[str, Any] | None = None,
        apply_step: bool = False,
    ) -> dict[str, Any]:
        result = ingest_agent_log(
            log_or_path=log_or_path,
            graph_manager=self.graph_manager,
            context=self._apply_namespace(context),
        )
        if apply_step:
            self.step()
        self._save()
        return result

    def ingest_text(
        self,
        transcript: str,
        context: dict[str, Any] | None = None,
        extractor: Any | None = None,
        apply_step: bool = False,
    ) -> dict[str, Any]:
        """Convert a freeform agent/chat transcript into typed nodes + edges.

        Uses a deterministic heuristic by default; pass an OpenAITranscriptExtractor
        (or any object with an `extract(text, context) -> agent_log_dict` method)
        to swap in an LLM-backed parser.
        """
        from state_trace.extraction_llm import HeuristicTranscriptExtractor, extract_agent_log_from_text

        chosen = extractor or HeuristicTranscriptExtractor()
        normalized_log = extract_agent_log_from_text(transcript, context=context, extractor=chosen)
        return self.store_agent_log(normalized_log, context=context, apply_step=apply_step)

    def store_agent_log_file(
        self,
        path: str | Path,
        context: dict[str, Any] | None = None,
        apply_step: bool = False,
    ) -> dict[str, Any]:
        result = ingest_agent_log_file(
            path=path,
            graph_manager=self.graph_manager,
            context=self._apply_namespace(context),
        )
        if apply_step:
            self.step()
        self._save()
        return result

    def retrieve(
        self,
        query: str,
        context: dict[str, Any] | None = None,
        limit: int = 5,
        depth_limit: int = 2,
        include_compressed: bool = False,
        feature_config: RetrievalFeatureConfig | None = None,
        include_all_namespaces: bool = False,
        explain: bool = False,
    ) -> dict[str, Any]:
        active_namespace = None if include_all_namespaces else self.namespace
        graph_manager = self.graph_manager.namespace_view(active_namespace) if active_namespace else self.graph_manager
        result = retrieve(
            query=query,
            context=context,
            graph_manager=graph_manager,
            score_config=self.score_config,
            depth_limit=depth_limit,
            limit=limit,
            include_compressed=include_compressed,
            feature_config=feature_config,
        )
        result["namespace"] = active_namespace
        if explain:
            result["explanations"] = _build_score_explanations(result.get("nodes", []))
        self._save()
        return result

    def retrieve_brief(
        self,
        query: str,
        context: dict[str, Any] | None = None,
        limit: int = 5,
        depth_limit: int = 2,
        include_compressed: bool = False,
        mode: str = "small_model",
        feature_config: RetrievalFeatureConfig | None = None,
        include_all_namespaces: bool = False,
        explain: bool = False,
    ) -> dict[str, Any]:
        result = self.retrieve(
            query=query,
            context=context,
            limit=limit,
            depth_limit=depth_limit,
            include_compressed=include_compressed,
            feature_config=feature_config,
            include_all_namespaces=include_all_namespaces,
            explain=explain,
        )
        brief = build_agent_brief(query=query, retrieval_result=result, mode=mode, feature_config=feature_config)
        brief["namespace"] = result.get("namespace")
        if explain:
            brief["explanations"] = result.get("explanations", [])
        return brief

    def record_action(self, text: str, context: dict[str, Any] | None = None, apply_step: bool = False) -> Node:
        runtime_context = self._apply_namespace(context)
        runtime_state = self._runtime_state(runtime_context)
        result = ingest_runtime_action(text=text, context=runtime_context, graph_manager=self.graph_manager, runtime_state=runtime_state)
        if apply_step:
            self.step()
        self._save()
        return result["node"]

    def record_observation(self, text: str, context: dict[str, Any] | None = None, apply_step: bool = False) -> Node:
        runtime_context = self._apply_namespace(context)
        runtime_state = self._runtime_state(runtime_context)
        result = ingest_runtime_observation(
            text=text,
            context=runtime_context,
            graph_manager=self.graph_manager,
            runtime_state=runtime_state,
        )
        if apply_step:
            self.step()
        self._save()
        return result["node"]

    def record_test_result(
        self,
        command: str,
        observation: str,
        context: dict[str, Any] | None = None,
        apply_step: bool = False,
    ) -> dict[str, Node]:
        runtime_context = self._apply_namespace(context)
        runtime_state = self._runtime_state(runtime_context)
        result = ingest_runtime_test_result(
            command=command,
            observation=observation,
            context=runtime_context,
            graph_manager=self.graph_manager,
            runtime_state=runtime_state,
        )
        if apply_step:
            self.step()
        self._save()
        return {"action": result["action"], "observation": result["observation"]}

    def link(self, node_a: str | Node, node_b: str | Node, edge_type: str = "related_to", weight: float = 1.0) -> Edge:
        source_id = node_a.id if isinstance(node_a, Node) else node_a
        target_id = node_b.id if isinstance(node_b, Node) else node_b
        edge = self.graph_manager.add_edge(Edge(source=source_id, target=target_id, type=edge_type, weight=weight))
        self._save()
        return edge

    def step(self, reference_time: datetime | None = None) -> dict[str, Any]:
        update_recency(self.graph_manager, reference_time=reference_time)
        decay_importance(self.graph_manager, reference_time=reference_time)
        result = enforce_capacity(self.graph_manager, max_capacity=self.capacity_limit, config=self.capacity_config)
        self._save()
        return result

    def graph_snapshot(self) -> dict[str, list[dict]]:
        return self.graph_manager.to_dict()

    def get_node(self, node_id: str) -> Node | None:
        return self.graph_manager.get_node(node_id)

    def clear_runtime_session(self, session_id: str) -> None:
        self._runtime_sessions.pop(session_id, None)

    def list_namespaces(self) -> list[str]:
        seen: set[str] = set()
        for node in self.graph_manager.all_nodes():
            ns = node.metadata.get("namespace")
            if ns:
                seen.add(str(ns))
        return sorted(seen)

    def current_state(
        self,
        session: str | None = None,
        goal: str | None = None,
        include_all_namespaces: bool = False,
    ) -> dict[str, Any]:
        """Return the live working-memory view for a session.

        Graphiti can answer "what was true at time T"; state-trace's coding-agent
        lane is narrower and more actionable: *right now*, what's the open task,
        which files are in play, which hypotheses are live, and which ones were
        superseded? Filters out invalid_at!=None and anything overridden by a
        `supersedes` edge.
        """
        active_namespace = None if include_all_namespaces else self.namespace
        graph = self.graph_manager.namespace_view(active_namespace) if active_namespace else self.graph_manager
        session_key = str(session) if session else None

        superseded_ids = {edge.target for edge in graph.all_edges() if edge.type == "supersedes"}

        def in_session(node: Node) -> bool:
            if session_key is None:
                return True
            meta_session = node.metadata.get("session") or node.metadata.get("session_id")
            return str(meta_session) == session_key if meta_session is not None else False

        def live(node: Node) -> bool:
            return node.invalid_at is None and node.id not in superseded_ids and not node.metadata.get("compressed")

        session_member_ids: set[str] = {
            node.id for node in graph.all_nodes(include_compressed=False) if in_session(node)
        }

        task_nodes: list[Node] = []
        observation_nodes: list[Node] = []
        decision_nodes: list[Node] = []
        file_nodes: dict[str, Node] = {}
        test_nodes: list[Node] = []

        for node in graph.all_nodes(include_compressed=False):
            if not live(node):
                continue
            if node.type == "file":
                # file nodes are shared anchors across sessions; include only
                # those connected to session-scoped nodes (so "active files"
                # reflects what's in play for *this* session). Don't apply the
                # goal filter to anchors — they don't carry goal metadata.
                if session_key is not None:
                    neighbors = {
                        neighbor.id for neighbor, _ in graph.get_neighbors(node.id, direction="both")
                    }
                    if not (neighbors & session_member_ids):
                        continue
                existing = file_nodes.get(node.content)
                if existing is None or node.importance > existing.importance:
                    file_nodes[node.content] = node
                continue
            if goal and str(node.metadata.get("goal") or "") != str(goal):
                continue
            if not in_session(node):
                continue
            if node.type == "task":
                task_nodes.append(node)
            elif node.type == "observation":
                observation_nodes.append(node)
            elif node.type == "decision":
                decision_nodes.append(node)
            elif node.type == "test":
                test_nodes.append(node)

        def _step(node: Node) -> int:
            value = node.metadata.get("step_index")
            return int(value) if value is not None else -1

        def _recency_key(node: Node) -> tuple:
            # Most-recent-first. Primary sort: event_at (the semantic "when
            # did the thing happen"). Tiebreak on created_at — dogfood
            # finding: within one runtime session, multiple record_observation
            # calls share an episode's event_at stamp, so event_at alone ties
            # and falls back to insertion order. created_at varies per write
            # and breaks those ties correctly. Final tiebreak on step_index
            # so trajectory-based ingestion preserves step ordering.
            event_at = node.event_at or node.created_at
            return (event_at, node.created_at, _step(node))

        task_nodes.sort(key=lambda node: (node.importance, _step(node)), reverse=True)
        observation_nodes.sort(key=_recency_key, reverse=True)
        decision_nodes.sort(key=_recency_key, reverse=True)

        active_files = sorted(
            file_nodes.values(),
            key=lambda node: (
                bool(node.metadata.get("edited")),
                bool(node.metadata.get("error_related")),
                node.importance,
            ),
            reverse=True,
        )

        def _serialize(node: Node) -> dict[str, Any]:
            return {
                "id": node.id,
                "type": node.type,
                "content": node.content,
                "importance": node.importance,
                "step_index": node.metadata.get("step_index"),
                "status": node.metadata.get("status"),
                "files": node.metadata.get("files", []),
            }

        return {
            "session": session_key,
            "goal": goal,
            "active_task": _serialize(task_nodes[0]) if task_nodes else None,
            "latest_observation": _serialize(observation_nodes[0]) if observation_nodes else None,
            "latest_decision": _serialize(decision_nodes[0]) if decision_nodes else None,
            "active_files": [_serialize(node) for node in active_files[:6]],
            "live_tests": [_serialize(node) for node in test_nodes[:4]],
            "live_observation_count": len(observation_nodes),
            "live_decision_count": len(decision_nodes),
        }

    def failed_hypotheses(
        self,
        session: str | None = None,
        goal: str | None = None,
        limit: int = 10,
        include_all_namespaces: bool = False,
    ) -> list[dict[str, Any]]:
        """Return memories that are known to have failed and shouldn't be retried.

        Four sources:
          1. Nodes with `invalid_at` set (explicit temporal invalidation).
          2. Nodes with status="error" that never got a later `validates`/`verified_by` edge.
          3. Nodes pointed at by a `supersedes` edge (a later memory explicitly replaced them).
          4. Nodes tagged with `metadata.rejected_angle=True` — concluded dead
             ends recorded as status=info (the "we decided not to go down this
             path" signal, which isn't an error but shouldn't be re-proposed).

        Callers should treat these as "do not propose again" entries when guiding
        a coding agent — this is the bounded-working-memory equivalent of the
        "what was tried and rejected" signal Graphiti has to infer from facts.
        """
        active_namespace = None if include_all_namespaces else self.namespace
        graph = self.graph_manager.namespace_view(active_namespace) if active_namespace else self.graph_manager
        session_key = str(session) if session else None

        superseded_ids = {edge.target for edge in graph.all_edges() if edge.type == "supersedes"}
        validated_ids = {
            edge.source
            for edge in graph.all_edges()
            if edge.type in {"validates", "verified_by"}
        }

        failures: list[dict[str, Any]] = []
        for node in graph.all_nodes(include_compressed=False):
            if session_key is not None:
                meta_session = node.metadata.get("session") or node.metadata.get("session_id")
                if str(meta_session) != session_key:
                    continue
            if goal and str(node.metadata.get("goal") or "") != str(goal):
                continue

            invalid = node.invalid_at is not None
            superseded = node.id in superseded_ids
            errored = (
                node.metadata.get("status") == "error"
                and node.id not in validated_ids
                and node.type in {"observation", "decision", "test"}
            )
            rejected_angle = bool(node.metadata.get("rejected_angle"))
            if not (invalid or superseded or errored or rejected_angle):
                continue

            reason = []
            if invalid:
                reason.append("invalidated")
            if superseded:
                reason.append("superseded")
            if errored:
                reason.append("error_without_recovery")
            if rejected_angle:
                reason.append("rejected_angle")

            failures.append(
                {
                    "id": node.id,
                    "type": node.type,
                    "content": node.content,
                    "reason": reason,
                    "step_index": node.metadata.get("step_index"),
                    "files": node.metadata.get("files", []),
                    "error_signatures": node.metadata.get("error_signatures", []),
                }
            )

        failures.sort(key=lambda item: (item["step_index"] is None, item["step_index"] or 0), reverse=True)
        return failures[:limit]

    def _apply_namespace(self, context: dict[str, Any] | None) -> dict[str, Any]:
        merged = dict(context or {})
        if self.namespace and "namespace" not in merged:
            merged["namespace"] = self.namespace
        return merged

    def _save(self) -> None:
        if not self.storage_path:
            return
        if self._sqlite is not None:
            self._sqlite.save(self.graph_manager)
            return
        self.graph_manager.save_json(self.storage_path)

    def _runtime_state(self, context: dict[str, Any]) -> dict[str, Any]:
        session_id = str(context.get("session") or context.get("session_id") or "default-session")
        state = self._runtime_sessions.setdefault(
            session_id,
            {
                "session_id": session_id,
                "goal": context.get("goal"),
                "next_step_index": 0,
                "current_step_index": 0,
                "step_open": False,
            },
        )
        if context.get("goal"):
            state["goal"] = context["goal"]
        return state
