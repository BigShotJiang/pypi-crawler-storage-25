"""MCP server exposing state-trace working memory to agent harnesses.

Usage (stdio, suitable for Claude Code / Codex CLI):

    uv run state-trace-mcp

Config via env vars:
  STATE_TRACE_STORAGE_PATH   durable path (.db/.sqlite for SQLite, else JSON)
  STATE_TRACE_NAMESPACE      default namespace for stored/retrieved memories
  STATE_TRACE_CAPACITY_LIMIT float working-memory budget (default 256)
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any

from state_trace.memory import MemoryEngine


def _resolve_default_storage() -> str:
    env = os.environ.get("STATE_TRACE_STORAGE_PATH")
    if env:
        return env
    home = Path(os.path.expanduser("~")) / ".state-trace"
    home.mkdir(parents=True, exist_ok=True)
    return str(home / "memory.db")


def _engine() -> MemoryEngine:
    storage_path = _resolve_default_storage()
    namespace = os.environ.get("STATE_TRACE_NAMESPACE") or None
    capacity_limit = float(os.environ.get("STATE_TRACE_CAPACITY_LIMIT", "256"))
    return MemoryEngine(
        capacity_limit=capacity_limit,
        storage_path=storage_path,
        namespace=namespace,
    )


def _json_safe(value: Any) -> Any:
    if isinstance(value, dict):
        return {key: _json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(item) for item in value]
    try:
        json.dumps(value)
        return value
    except TypeError:
        return str(value)


def build_server() -> Any:
    """Construct the FastMCP server. Imported lazily so the package does not
    hard-depend on the optional mcp SDK."""
    try:
        from mcp.server.fastmcp import FastMCP
    except ImportError as exc:  # pragma: no cover - optional dependency
        raise RuntimeError(
            "The mcp SDK is required to run the state-trace MCP server. "
            "Install with: pip install 'state-trace[mcp]' (or `pip install mcp`)."
        ) from exc

    engine = _engine()
    mcp = FastMCP("state-trace")

    @mcp.tool()
    def store(text: str, context: dict[str, Any] | None = None) -> dict[str, Any]:
        """Store a typed working-memory node. Context may include:
        type (task/observation/decision/file/...), session, goal, file/files,
        importance (0-1), status, action_kind. Returns the created node.
        """
        node = engine.store(text, context)
        return _json_safe(node.model_dump(mode="json"))

    @mcp.tool()
    def retrieve(
        query: str,
        context: dict[str, Any] | None = None,
        limit: int = 5,
        depth_limit: int = 2,
        include_all_namespaces: bool = False,
        explain: bool = False,
    ) -> dict[str, Any]:
        """Retrieve memories and causal chains most relevant to `query` and
        `context`. `explain=True` returns per-node score breakdowns.
        """
        return _json_safe(
            engine.retrieve(
                query=query,
                context=context,
                limit=limit,
                depth_limit=depth_limit,
                include_all_namespaces=include_all_namespaces,
                explain=explain,
            )
        )

    @mcp.tool()
    def retrieve_brief(
        query: str,
        context: dict[str, Any] | None = None,
        mode: str = "small_model",
        limit: int = 5,
        include_all_namespaces: bool = False,
        explain: bool = False,
    ) -> dict[str, Any]:
        """Budgeted brief for small coding agents. Returns patch_file,
        rerun_command, tests_to_rerun, current_state, failed_attempts,
        recommended_actions. `mode` is "small_model" or "large_model".
        """
        return _json_safe(
            engine.retrieve_brief(
                query=query,
                context=context,
                mode=mode,
                limit=limit,
                include_all_namespaces=include_all_namespaces,
                explain=explain,
            )
        )

    @mcp.tool()
    def record_action(text: str, context: dict[str, Any] | None = None) -> dict[str, Any]:
        """Record an action the agent just took (e.g. `edit "src/auth.ts"`)."""
        node = engine.record_action(text, context)
        return _json_safe(node.model_dump(mode="json"))

    @mcp.tool()
    def record_observation(text: str, context: dict[str, Any] | None = None) -> dict[str, Any]:
        """Record an observation from a tool or command the agent just ran."""
        node = engine.record_observation(text, context)
        return _json_safe(node.model_dump(mode="json"))

    @mcp.tool()
    def record_test_result(
        command: str,
        observation: str,
        context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Record a test command + its observation as a linked pair."""
        pair = engine.record_test_result(command=command, observation=observation, context=context)
        return _json_safe({key: node.model_dump(mode="json") for key, node in pair.items()})

    @mcp.tool()
    def ingest_agent_log_file(path: str, context: dict[str, Any] | None = None) -> dict[str, Any]:
        """Ingest an agent trajectory (SWE-agent .traj, OpenHands JSON, or
        normalized agent_log JSON) into memory."""
        return _json_safe(engine.store_agent_log_file(path=path, context=context))

    @mcp.tool()
    def current_state(
        session: str | None = None,
        goal: str | None = None,
        include_all_namespaces: bool = False,
    ) -> dict[str, Any]:
        """Return the live working-memory view for a session: active task,
        latest observation/decision, non-stale active files, live tests.
        Filters out invalidated and superseded nodes. Use this to answer
        "what's actually true right now" without re-running retrieval.
        """
        return _json_safe(
            engine.current_state(
                session=session,
                goal=goal,
                include_all_namespaces=include_all_namespaces,
            )
        )

    @mcp.tool()
    def failed_hypotheses(
        session: str | None = None,
        goal: str | None = None,
        limit: int = 10,
        include_all_namespaces: bool = False,
    ) -> list[dict[str, Any]]:
        """Return memories known to have failed — invalidated, superseded, or
        errored-without-recovery. The "do not propose again" signal for
        coding agents planning the next step.
        """
        return _json_safe(
            engine.failed_hypotheses(
                session=session,
                goal=goal,
                limit=limit,
                include_all_namespaces=include_all_namespaces,
            )
        )

    @mcp.tool()
    def list_namespaces() -> list[str]:
        """List every namespace present in stored memory."""
        return engine.list_namespaces()

    @mcp.tool()
    def graph_snapshot() -> dict[str, Any]:
        """Dump the full graph as {nodes: [...], edges: [...]}."""
        return _json_safe(engine.graph_snapshot())

    return mcp


def main() -> None:
    server = build_server()
    try:
        server.run()
    except KeyboardInterrupt:  # pragma: no cover - user abort
        sys.exit(0)


if __name__ == "__main__":  # pragma: no cover
    main()
