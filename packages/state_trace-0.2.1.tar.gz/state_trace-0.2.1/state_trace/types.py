from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field, model_validator

from state_trace.utils import utc_now


class Node(BaseModel):
    id: str
    type: str
    content: str
    importance: float = Field(default=0.5, ge=0.0, le=1.0)
    recency: float = Field(default=1.0, ge=0.0, le=1.0)
    access_count: int = Field(default=0, ge=0)
    capacity_used: float = Field(default=1.0, ge=0.0)
    capacity_max: float = Field(default=8.0, gt=0.0)
    created_at: datetime = Field(default_factory=utc_now)
    updated_at: datetime = Field(default_factory=utc_now)
    event_at: datetime | None = None
    valid_at: datetime | None = None
    invalid_at: datetime | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def apply_temporal_defaults(self) -> "Node":
        if self.event_at is None:
            self.event_at = self.created_at
        if self.valid_at is None:
            self.valid_at = self.event_at
        return self

    def touch(self) -> None:
        self.access_count += 1
        self.recency = 1.0
        self.updated_at = utc_now()


class Edge(BaseModel):
    source: str
    target: str
    type: str
    weight: float = Field(default=1.0, ge=0.0)
    created_at: datetime = Field(default_factory=utc_now)
    valid_at: datetime | None = None
    invalid_at: datetime | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def apply_temporal_defaults(self) -> "Edge":
        if self.valid_at is None:
            self.valid_at = self.created_at
        return self
