from __future__ import annotations

import csv
import json
import random
import statistics
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Iterable, Sequence

POLICY_MODEL_DEFAULTS = {
    "openai": {"small_model": "gpt-5.4-mini", "large_model": "gpt-5.4"},
    "codex": {"small_model": "gpt-5.4-mini", "large_model": "gpt-5.3-codex"},
    "codex_api": {"small_model": "gpt-5.1-codex-mini", "large_model": "gpt-5.2-codex"},
}
POLICY_REASONING_DEFAULTS = {
    "openai": {"small_reasoning": "low", "large_reasoning": "low"},
    "codex": {"small_reasoning": "medium", "large_reasoning": "high"},
    "codex_api": {"small_reasoning": "medium", "large_reasoning": "high"},
}


@dataclass(frozen=True)
class CaseSplit:
    name: str
    train_groups: tuple[str, ...]
    test_groups: tuple[str, ...]
    train_cases: list[Any]
    test_cases: list[Any]


def build_group_splits(
    cases: Sequence[Any],
    holdout_fraction: float = 0.25,
    repeats: int = 4,
    seed: int = 7,
) -> list[CaseSplit]:
    grouped: dict[str, list[Any]] = {}
    for case in cases:
        grouped.setdefault(str(case.group_id), []).append(case)

    groups = sorted(grouped)
    if not groups:
        return []

    if len(groups) <= 8:
        splits: list[CaseSplit] = []
        for index, group_id in enumerate(groups, start=1):
            test_groups = (group_id,)
            train_groups = tuple(group for group in groups if group != group_id)
            splits.append(
                CaseSplit(
                    name=f"fold_{index}",
                    train_groups=train_groups,
                    test_groups=test_groups,
                    train_cases=_cases_for_groups(grouped, train_groups),
                    test_cases=_cases_for_groups(grouped, test_groups),
                )
            )
        return splits

    rng = random.Random(seed)
    holdout_count = max(1, int(round(len(groups) * max(0.05, min(0.9, holdout_fraction)))))
    seen: set[tuple[str, ...]] = set()
    splits: list[CaseSplit] = []

    while len(splits) < max(1, repeats):
        sampled = tuple(sorted(rng.sample(groups, holdout_count)))
        if sampled in seen:
            continue
        seen.add(sampled)
        train_groups = tuple(group for group in groups if group not in sampled)
        splits.append(
            CaseSplit(
                name=f"split_{len(splits) + 1}",
                train_groups=train_groups,
                test_groups=sampled,
                train_cases=_cases_for_groups(grouped, train_groups),
                test_cases=_cases_for_groups(grouped, sampled),
            )
        )
    return splits


def bootstrap_confidence_interval(
    values: Sequence[float],
    metric_fn: Callable[[Sequence[float]], float] = statistics.mean,
    bootstrap_samples: int = 800,
    confidence: float = 0.95,
    seed: int = 7,
) -> tuple[float, float, float]:
    values = list(values)
    if not values:
        return (0.0, 0.0, 0.0)

    point_estimate = float(metric_fn(values))
    if len(values) == 1 or bootstrap_samples <= 0:
        return (point_estimate, point_estimate, point_estimate)

    rng = random.Random(seed)
    bootstrapped: list[float] = []
    for _ in range(bootstrap_samples):
        sample = [values[rng.randrange(len(values))] for _ in range(len(values))]
        bootstrapped.append(float(metric_fn(sample)))

    bootstrapped.sort()
    lower_index = max(0, int(((1.0 - confidence) / 2.0) * len(bootstrapped)))
    upper_index = min(len(bootstrapped) - 1, int((1.0 - ((1.0 - confidence) / 2.0)) * len(bootstrapped)) - 1)
    return (point_estimate, bootstrapped[lower_index], bootstrapped[upper_index])


def summarize_live_rows(
    rows: Sequence[dict[str, Any]],
    bootstrap_samples: int = 800,
    seed: int = 7,
) -> dict[str, tuple[float, float, float]]:
    success = [float(row.get("success", 0.0)) for row in rows]
    step_accuracy = [
        float(row.get("steps_completed", 0.0)) / max(int(row.get("total_steps", 0) or 0), 1)
        for row in rows
    ]
    artifact_at_1 = [float(row.get("artifact_at_1", 0.0)) for row in rows]
    avg_tokens = [float(row.get("avg_tokens", 0.0)) for row in rows]
    avg_latency_ms = [float(row.get("avg_latency_ms", 0.0)) for row in rows]
    return {
        "success": bootstrap_confidence_interval(success, bootstrap_samples=bootstrap_samples, seed=seed),
        "step_accuracy": bootstrap_confidence_interval(step_accuracy, bootstrap_samples=bootstrap_samples, seed=seed + 1),
        "artifact_at_1": bootstrap_confidence_interval(artifact_at_1, bootstrap_samples=bootstrap_samples, seed=seed + 2),
        "avg_tokens": bootstrap_confidence_interval(avg_tokens, bootstrap_samples=bootstrap_samples, seed=seed + 3),
        "avg_latency_ms": bootstrap_confidence_interval(avg_latency_ms, bootstrap_samples=bootstrap_samples, seed=seed + 4),
    }


def summarize_scalar_rows(
    rows: Sequence[dict[str, Any]],
    field: str,
    bootstrap_samples: int = 800,
    seed: int = 7,
) -> tuple[float, float, float]:
    values = [float(row.get(field, 0.0)) for row in rows]
    return bootstrap_confidence_interval(values, bootstrap_samples=bootstrap_samples, seed=seed)


def write_json(path: str | Path, payload: Any) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def write_rows_csv(path: str | Path, rows: Iterable[dict[str, Any]]) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    rows = list(rows)
    fieldnames: list[str] = []
    seen = set()
    for row in rows:
        for field in row:
            if field in seen:
                continue
            seen.add(field)
            fieldnames.append(field)
    with target.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def resolve_policy_models(policy: str, small_model: str = "", large_model: str = "") -> tuple[str, str]:
    defaults = POLICY_MODEL_DEFAULTS.get(policy, POLICY_MODEL_DEFAULTS["openai"])
    return (small_model or defaults["small_model"], large_model or defaults["large_model"])


def resolve_policy_reasoning(policy: str, small_reasoning: str = "", large_reasoning: str = "") -> tuple[str, str]:
    defaults = POLICY_REASONING_DEFAULTS.get(policy, POLICY_REASONING_DEFAULTS["openai"])
    return (small_reasoning or defaults["small_reasoning"], large_reasoning or defaults["large_reasoning"])


def _cases_for_groups(grouped: dict[str, list[Any]], group_ids: Sequence[str]) -> list[Any]:
    cases: list[Any] = []
    for group_id in group_ids:
        cases.extend(grouped.get(group_id, []))
    return cases
