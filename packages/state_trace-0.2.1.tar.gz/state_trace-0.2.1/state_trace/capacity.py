from __future__ import annotations

from datetime import datetime

import networkx as nx
import numpy as np
from pydantic import BaseModel

from state_trace.graph import GraphManager
from state_trace.summarization import summarize_cluster, summarize_resolved_tasks
from state_trace.types import Node
from state_trace.utils import utc_now


PROTECTED_TYPES = {"goal", "decision", "session"}
ACTIVE_PHASE = "active_working_set"
RESOLVED_PHASE = "resolved_task_snapshot"
COLD_PHASE = "cold_episodic_trail"


class CapacityConfig(BaseModel):
    enable_lifecycle_phases: bool = True
    enable_resolved_snapshots: bool = True
    enable_cluster_summarization: bool = True


def update_recency(
    graph_manager: GraphManager,
    reference_time: datetime | None = None,
    half_life_hours: float = 24.0,
) -> None:
    reference_time = reference_time or utc_now()
    for node in graph_manager.all_nodes():
        age_hours = max((reference_time - node.updated_at).total_seconds() / 3600.0, 0.0)
        freshness = float(np.exp(-age_hours / max(half_life_hours, 1e-6)))
        access_boost = min(node.access_count * 0.03, 0.25)
        compressed_penalty = 0.15 if node.metadata.get("compressed") else 0.0
        node.recency = float(np.clip(freshness + access_boost - compressed_penalty, 0.0, 1.0))
        graph_manager.update_node(node)


def decay_importance(
    graph_manager: GraphManager,
    reference_time: datetime | None = None,
    daily_decay: float = 0.08,
) -> None:
    reference_time = reference_time or utc_now()
    for node in graph_manager.all_nodes():
        age_days = max((reference_time - node.updated_at).total_seconds() / 86400.0, 0.0)
        decay_factor = float(np.exp(-daily_decay * age_days))
        access_protection = min(node.access_count * 0.02, 0.2)
        protected_floor = 0.45 if node.type in PROTECTED_TYPES or node.importance >= 0.8 else 0.05
        compressed_penalty = 0.1 if node.metadata.get("compressed") else 0.0
        node.importance = float(
            np.clip(max(protected_floor, node.importance * decay_factor + access_protection - compressed_penalty), 0.0, 1.0)
        )
        graph_manager.update_node(node)


def total_capacity(graph_manager: GraphManager) -> float:
    return round(sum(node.capacity_used for node in graph_manager.all_nodes()), 3)


def enforce_capacity(
    graph_manager: GraphManager,
    max_capacity: float,
    config: CapacityConfig | None = None,
) -> dict[str, list[str] | float]:
    config = config or CapacityConfig()
    summary_nodes: list[str] = []
    compressed_nodes: list[str] = []
    removed_nodes: list[str] = []
    if config.enable_lifecycle_phases:
        update_lifecycle_phases(graph_manager)
    else:
        for node in graph_manager.all_nodes():
            if "lifecycle_phase" in node.metadata:
                node.metadata.pop("lifecycle_phase", None)
                graph_manager.update_node(node)

    if total_capacity(graph_manager) <= max_capacity:
        return {
            "capacity_used": total_capacity(graph_manager),
            "summary_nodes": summary_nodes,
            "compressed": compressed_nodes,
            "removed": removed_nodes,
        }

    if config.enable_resolved_snapshots:
        for summary in summarize_resolved_tasks(graph_manager):
            if total_capacity(graph_manager) <= max_capacity:
                break
            summary_nodes.append(summary.id)

    if config.enable_cluster_summarization:
        for cluster in _dense_clusters(graph_manager, config):
            if total_capacity(graph_manager) <= max_capacity:
                break
            summary = summarize_cluster(graph_manager, cluster)
            if summary:
                summary_nodes.append(summary.id)

    active_nodes = sorted(
        graph_manager.all_nodes(),
        key=lambda node: _retention_score(node, config),
    )
    for node in active_nodes:
        if total_capacity(graph_manager) <= max_capacity:
            break
        if node.type in PROTECTED_TYPES and node.importance >= 0.6:
            continue
        if not node.metadata.get("compressed") and node.importance < 0.65:
            if _compress_node(node, graph_manager, config):
                compressed_nodes.append(node.id)

    removable_nodes = sorted(
        graph_manager.all_nodes(),
        key=lambda node: (_retention_score(node, config), node.capacity_used),
    )
    for node in removable_nodes:
        if total_capacity(graph_manager) <= max_capacity:
            break
        if node.metadata.get("summary"):
            continue
        if node.type in PROTECTED_TYPES and node.importance >= 0.6:
            continue
        if node.importance > 0.5 and node.recency > 0.45:
            continue
        removed_nodes.append(node.id)
        graph_manager.remove_node(node.id)

    if total_capacity(graph_manager) > max_capacity:
        hard_cap_nodes = sorted(
            graph_manager.all_nodes(),
            key=lambda node: (_retention_score(node, config), node.importance, node.recency, node.capacity_used),
        )
        for node in hard_cap_nodes:
            if total_capacity(graph_manager) <= max_capacity:
                break
            if node.metadata.get("summary"):
                continue
            if node.type in {"session", "goal"}:
                continue
            removed_nodes.append(node.id)
            graph_manager.remove_node(node.id)

    return {
        "capacity_used": total_capacity(graph_manager),
        "summary_nodes": summary_nodes,
        "compressed": compressed_nodes,
        "removed": removed_nodes,
    }


def update_lifecycle_phases(graph_manager: GraphManager) -> None:
    latest_steps_by_session: dict[str, int] = {}
    resolved_sessions: set[str] = set()

    for node in graph_manager.all_nodes():
        session_id = node.metadata.get("session")
        step_index = node.metadata.get("step_index")
        if session_id is not None and step_index is not None:
            latest_steps_by_session[str(session_id)] = max(latest_steps_by_session.get(str(session_id), -1), int(step_index))
        if node.type == "task" and (node.metadata.get("submitted") or graph_manager.find_edges(target=node.id, edge_type="solves")):
            if session_id is not None:
                resolved_sessions.add(str(session_id))

    for node in graph_manager.all_nodes():
        phase = _determine_lifecycle_phase(node, latest_steps_by_session, resolved_sessions)
        node.metadata["lifecycle_phase"] = phase
        graph_manager.update_node(node)


def _dense_clusters(graph_manager: GraphManager, config: CapacityConfig) -> list[list[str]]:
    active_node_ids = [
        node.id
        for node in graph_manager.all_nodes(include_compressed=False)
        if node.type not in PROTECTED_TYPES and not node.metadata.get("summary")
    ]
    subgraph = graph_manager.graph.subgraph(active_node_ids).copy()
    undirected = subgraph.to_undirected()
    dense_clusters: list[list[str]] = []

    for component in nx.connected_components(undirected):
        if len(component) < 3:
            continue
        component_graph = undirected.subgraph(component)
        density = nx.density(component_graph)
        average_retention = np.mean(
            [_retention_score(graph_manager.get_node(node_id), config) for node_id in component if graph_manager.get_node(node_id)]
        )
        if density >= 0.45 and average_retention < 0.7:
            dense_clusters.append(sorted(component))

    dense_clusters.sort(key=len, reverse=True)
    return dense_clusters


def _compress_node(node: Node, graph_manager: GraphManager, config: CapacityConfig) -> bool:
    if node.metadata.get("compressed") or node.metadata.get("summary") or node.type in PROTECTED_TYPES:
        return False
    phase = node.metadata.get("lifecycle_phase") if config.enable_lifecycle_phases else None
    if phase == ACTIVE_PHASE and node.importance >= 0.45:
        return False
    node.metadata["compressed"] = True
    node.metadata["compressed_at"] = utc_now().isoformat()
    node.metadata["original_content"] = node.content
    node.content = f"Compressed memory: {node.content[:120]}"
    compression_ratio = 0.5 if phase == RESOLVED_PHASE else 0.35 if phase == COLD_PHASE else 0.4
    node.capacity_used = round(max(0.2, node.capacity_used * compression_ratio), 3)
    graph_manager.update_node(node)
    return True


def _retention_score(node: Node | None, config: CapacityConfig | None = None) -> float:
    config = config or CapacityConfig()
    if node is None:
        return 0.0
    access_signal = min(node.access_count / 5.0, 1.0)
    protected_bonus = 0.15 if node.type in PROTECTED_TYPES else 0.0
    temporal_penalty = 0.12 if node.invalid_at is not None else 0.0
    episode_penalty = 0.05 if node.type == "episode" else 0.0
    phase = node.metadata.get("lifecycle_phase") if config.enable_lifecycle_phases else None
    phase_bonus = 0.16 if phase == ACTIVE_PHASE else 0.08 if phase == RESOLVED_PHASE else -0.06 if phase == COLD_PHASE else 0.0
    summary_bonus = 0.12 if config.enable_resolved_snapshots and node.metadata.get("resolved_summary") else 0.0
    return (
        (node.importance * 0.45)
        + (node.recency * 0.35)
        + (access_signal * 0.2)
        + protected_bonus
        + phase_bonus
        + summary_bonus
        - temporal_penalty
        - episode_penalty
    )


def _determine_lifecycle_phase(
    node: Node,
    latest_steps_by_session: dict[str, int],
    resolved_sessions: set[str],
) -> str:
    session_id = str(node.metadata.get("session")) if node.metadata.get("session") is not None else None
    if node.metadata.get("resolved_summary"):
        return RESOLVED_PHASE
    if node.invalid_at is not None and node.type not in {"task", "file"}:
        return COLD_PHASE
    if session_id is None:
        return ACTIVE_PHASE if node.invalid_at is None else COLD_PHASE

    latest_step = latest_steps_by_session.get(session_id, -1)
    node_step = int(node.metadata.get("step_index", latest_step)) if node.metadata.get("step_index") is not None else None

    if node.invalid_at is None and (
        node.metadata.get("current", True)
        or node.type in {"task", "file"}
        or (node_step is not None and node_step >= latest_step - 1)
    ):
        return ACTIVE_PHASE

    if session_id in resolved_sessions and (
        node.type in {"task", "file", "patch_hunk", "test", "decision", "observation"}
        or node.metadata.get("submitted")
    ):
        return RESOLVED_PHASE

    return COLD_PHASE
