"""LangGraph memory adapter.

Minimal duck-typed wrapper exposing state-trace as a drop-in working memory
layer for LangGraph graphs. The adapter does not import LangGraph itself so it
stays cheap for users who only want the class contract.

Typical usage inside a LangGraph node::

    memory = StateTraceLangGraphMemory(
        engine=MemoryEngine(storage_path="memory.db", namespace="repo-x"),
        default_session="coding-session-1",
    )

    # inside a node
    for message in state["messages"]:
        memory.add_message(message)
    brief = memory.retrieve_brief("what file should I patch next?")
    new_state = {"memory_brief": brief}
"""

from __future__ import annotations

from typing import Any, Iterable

from state_trace.memory import MemoryEngine


class StateTraceLangGraphMemory:
    def __init__(
        self,
        engine: MemoryEngine | None = None,
        default_session: str = "langgraph-session",
        default_goal: str | None = None,
    ) -> None:
        self.engine = engine or MemoryEngine()
        self.default_session = default_session
        self.default_goal = default_goal

    # --- write path ---------------------------------------------------------

    def add_message(self, message: Any) -> None:
        """Record a LangChain-style message (``{role, content}`` or an object
        with ``.type``/``.content``)."""
        role, content = _coerce_message(message)
        context = {
            "session": self.default_session,
            "goal": self.default_goal,
            "role": role,
        }
        if role in {"tool", "observation", "function"}:
            self.engine.record_observation(content, context)
        elif role in {"ai", "assistant", "action"}:
            self.engine.record_action(content, context)
        else:
            self.engine.store(content, {**context, "type": "observation" if role == "user" else "task"})

    def add_messages(self, messages: Iterable[Any]) -> None:
        for message in messages:
            self.add_message(message)

    def record_test_result(self, command: str, observation: str, context: dict[str, Any] | None = None) -> None:
        merged = {"session": self.default_session, "goal": self.default_goal, **(context or {})}
        self.engine.record_test_result(command=command, observation=observation, context=merged)

    # --- read path ----------------------------------------------------------

    def retrieve(self, query: str, context: dict[str, Any] | None = None, limit: int = 5) -> dict[str, Any]:
        merged = {"session": self.default_session, "goal": self.default_goal, **(context or {})}
        return self.engine.retrieve(query=query, context=merged, limit=limit)

    def retrieve_brief(
        self,
        query: str,
        context: dict[str, Any] | None = None,
        mode: str = "small_model",
    ) -> dict[str, Any]:
        merged = {"session": self.default_session, "goal": self.default_goal, **(context or {})}
        return self.engine.retrieve_brief(query=query, context=merged, mode=mode)


def _coerce_message(message: Any) -> tuple[str, str]:
    if isinstance(message, dict):
        return str(message.get("role") or message.get("type") or "user"), str(message.get("content") or "")
    role = getattr(message, "type", None) or getattr(message, "role", None) or "user"
    content = getattr(message, "content", None) or ""
    return str(role), str(content)
