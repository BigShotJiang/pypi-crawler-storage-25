"""LlamaIndex memory adapter.

Exposes state-trace as a BaseMemory-compatible duck-typed class. No LlamaIndex
dependency is required at import time; you can plug this into a LlamaIndex
agent that expects a memory with ``put``/``get`` methods.

Example::

    memory = StateTraceLlamaIndexMemory(
        engine=MemoryEngine(storage_path="memory.db", namespace="repo-x"),
    )
    memory.put({"role": "user", "content": "why is login broken?"})
    brief_text = memory.get(query="why is login broken?")
"""

from __future__ import annotations

from typing import Any, Iterable

from state_trace.memory import MemoryEngine


class StateTraceLlamaIndexMemory:
    def __init__(
        self,
        engine: MemoryEngine | None = None,
        session_id: str = "llama-session",
        goal: str | None = None,
        mode: str = "small_model",
    ) -> None:
        self.engine = engine or MemoryEngine()
        self.session_id = session_id
        self.goal = goal
        self.mode = mode

    def put(self, message: Any) -> None:
        role, content = _coerce_message(message)
        context = {"session": self.session_id, "goal": self.goal, "role": role}
        if role in {"tool", "observation", "function"}:
            self.engine.record_observation(content, context)
        elif role in {"assistant", "ai", "action"}:
            self.engine.record_action(content, context)
        else:
            self.engine.store(content, {**context, "type": "observation" if role == "user" else "task"})

    def put_messages(self, messages: Iterable[Any]) -> None:
        for message in messages:
            self.put(message)

    def get(self, query: str = "", **kwargs: Any) -> str:
        """Return a compact brief rendered as plain text — what most LlamaIndex
        agents expect from a memory `.get()` call."""
        if not query:
            return ""
        brief = self.engine.retrieve_brief(
            query=query,
            context={"session": self.session_id, "goal": self.goal},
            mode=kwargs.get("mode", self.mode),
        )
        return str(brief.get("rendered") or brief.get("summary", ""))

    def get_all(self) -> list[dict[str, Any]]:
        return self.engine.graph_snapshot().get("nodes", [])

    def reset(self) -> None:
        self.engine.clear_runtime_session(self.session_id)


def _coerce_message(message: Any) -> tuple[str, str]:
    if isinstance(message, dict):
        return str(message.get("role") or message.get("type") or "user"), str(message.get("content") or "")
    role = getattr(message, "role", None) or getattr(message, "type", None) or "user"
    content = getattr(message, "content", None) or ""
    return str(role), str(content)
