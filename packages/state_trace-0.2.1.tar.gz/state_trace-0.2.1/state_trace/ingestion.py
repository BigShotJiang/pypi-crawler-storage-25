from __future__ import annotations

from pathlib import Path
from typing import Any

from state_trace.extraction import extract_event, make_anchor_node
from state_trace.graph import GraphManager
from state_trace.types import Edge, Node
from state_trace.utils import (
    classify_observation_status,
    compact_text,
    derive_step_files,
    estimate_capacity,
    extract_diff_files,
    extract_error_signatures,
    extract_file_paths,
    extract_issue_text_from_history,
    extract_issue_title,
    extract_patch_hunks,
    extract_symbol_names,
    extract_test_targets,
    infer_action_kind,
    load_json_path,
    slugify,
    tokenize,
    utc_now,
)


def ingest_event(text: str, context: dict[str, Any] | None, graph_manager: GraphManager) -> Node:
    extraction = extract_event(text, context, graph_manager)
    graph_manager.add_node(extraction.node)
    for edge in extraction.edge_candidates:
        if graph_manager.has_node(edge.source) and graph_manager.has_node(edge.target):
            graph_manager.add_edge(edge)
    return extraction.node


def ingest_agent_log(
    log_or_path: str | Path | dict[str, Any] | list[dict[str, Any]],
    graph_manager: GraphManager,
    context: dict[str, Any] | None = None,
) -> dict[str, Any]:
    normalized = _normalize_agent_log(log_or_path, context or {})
    session_id = normalized["session_id"]
    issue_title = normalized["issue_title"]
    issue_text = normalized.get("issue_text", "")
    goal = normalized.get("goal") or f"resolve {issue_title}"

    task_node = ingest_event(
        issue_title,
        {
            "type": "task",
            "session": session_id,
            "goal": goal,
            "importance": 0.96,
            "stable_id": True,
            "issue_text": issue_text,
            "repo": normalized.get("repo"),
            "source": normalized.get("source"),
            "source_url": normalized.get("source_url"),
            "keywords": normalized.get("keywords"),
        },
        graph_manager,
    )
    issue_episode = _create_episode_node(
        graph_manager=graph_manager,
        session_id=session_id,
        goal=goal,
        step_index=-1,
        episode_kind="issue",
        issue_title=issue_title,
        issue_text=issue_text,
        repo=normalized.get("repo"),
        source=normalized.get("source"),
        source_url=normalized.get("source_url"),
        files=[],
    )
    _safe_add_edge(graph_manager, task_node.id, issue_episode.id, "derived_from", 0.95)

    created_node_ids = [task_node.id, issue_episode.id]
    previous_node = task_node
    last_edit_node: Node | None = None
    last_error_node: Node | None = None

    for step in normalized["steps"]:
        action_text = step.get("action", "").strip()
        observation_text = step.get("observation", "").strip()
        thought_text = step.get("thought", "").strip()
        action_kind = step.get("action_kind") or infer_action_kind(action_text)
        files = list(step.get("files") or derive_step_files(action_text, observation_text, thought_text, action_kind))
        step_index = int(step["index"])
        episode_node = _create_episode_node(
            graph_manager=graph_manager,
            session_id=session_id,
            goal=goal,
            step_index=step_index,
            episode_kind="step",
            issue_title=issue_title,
            issue_text="",
            repo=normalized.get("repo"),
            source=normalized.get("source"),
            source_url=normalized.get("source_url"),
            files=files,
            action=action_text,
            observation=observation_text,
            thought=thought_text,
        )
        created_node_ids.append(episode_node.id)

        action_node = ingest_event(
            _build_action_content(step_index, action_text, thought_text),
            {
                "type": "decision",
                "session": session_id,
                "goal": goal,
                "importance": _action_importance(action_kind),
                "files": files,
                "step_index": step_index,
                "action_kind": action_kind,
                "thought": thought_text,
                "episode_id": episode_node.id,
                "related_to": [task_node.id],
                "source": normalized.get("source"),
                "source_url": normalized.get("source_url"),
                "repo": normalized.get("repo"),
                "event_at": episode_node.event_at,
                "valid_at": episode_node.valid_at,
            },
            graph_manager,
        )
        created_node_ids.append(action_node.id)
        _safe_add_edge(graph_manager, previous_node.id, action_node.id, "precedes", 0.95)
        _safe_add_edge(graph_manager, action_node.id, episode_node.id, "derived_from", 0.92)
        if last_error_node and action_kind in {"open", "edit", "find_file", "submit"}:
            _safe_add_edge(graph_manager, last_error_node.id, action_node.id, "motivates", 0.9)
        _annotate_file_nodes(graph_manager, files, action_kind, step_index, status=None, episode_id=episode_node.id)
        created_node_ids.extend(
            _attach_code_artifacts(
                graph_manager=graph_manager,
                parent_node=action_node,
                session_id=session_id,
                goal=goal,
                step_index=step_index,
                files=files,
                action=action_text,
                observation="",
                thought=thought_text,
                action_kind=action_kind,
                status=None,
                error_signatures=[],
                episode_id=episode_node.id,
                repo=normalized.get("repo"),
                source=normalized.get("source"),
                source_url=normalized.get("source_url"),
                task_node_id=task_node.id,
            )
        )
        if action_kind in {"edit", "submit"} and files:
            _invalidate_prior_states(
                graph_manager=graph_manager,
                session_id=session_id,
                files=files,
                before_step_index=step_index,
                invalidated_by=action_node.id,
                reason="edited_after_failure",
                node_types={"observation"},
                statuses={"error"},
            )

        if action_kind == "edit":
            last_edit_node = action_node

        current_primary = action_node
        if observation_text:
            status = step.get("status") or classify_observation_status(observation_text)
            error_signatures = list(step.get("error_signatures") or extract_error_signatures(observation_text))
            observation_node = ingest_event(
                _build_observation_content(observation_text, error_signatures),
                {
                    "type": "observation",
                    "session": session_id,
                    "goal": goal,
                    "importance": _observation_importance(status, error_signatures),
                    "files": files,
                    "step_index": step_index,
                    "action_kind": action_kind,
                    "status": status,
                    "error_signatures": error_signatures,
                    "episode_id": episode_node.id,
                    "related_to": [task_node.id, action_node.id],
                    "source": normalized.get("source"),
                    "source_url": normalized.get("source_url"),
                    "repo": normalized.get("repo"),
                    "event_at": episode_node.event_at,
                    "valid_at": episode_node.valid_at,
                },
                graph_manager,
            )
            created_node_ids.append(observation_node.id)
            _safe_add_edge(graph_manager, action_node.id, observation_node.id, "causes", 1.0)
            _safe_add_edge(graph_manager, previous_node.id, observation_node.id, "precedes", 0.7)
            _safe_add_edge(graph_manager, observation_node.id, episode_node.id, "derived_from", 0.92)

            if status == "error":
                last_error_node = observation_node
                if last_edit_node:
                    _safe_add_edge(graph_manager, last_edit_node.id, observation_node.id, "rejected_by", 0.92)
            if status == "success" and last_edit_node:
                _safe_add_edge(graph_manager, last_edit_node.id, observation_node.id, "validates", 0.95)
                _safe_add_edge(graph_manager, last_edit_node.id, observation_node.id, "verified_by", 0.97)
                if files:
                    _invalidate_prior_states(
                        graph_manager=graph_manager,
                        session_id=session_id,
                        files=files,
                        before_step_index=step_index,
                        invalidated_by=observation_node.id,
                        reason="validated_after_edit",
                        node_types={"observation"},
                        statuses={"error"},
                    )
            if status == "success" and action_kind in {"python", "pytest", "submit"}:
                _safe_add_edge(graph_manager, observation_node.id, task_node.id, "solves", 0.9)
                _safe_add_edge(graph_manager, task_node.id, observation_node.id, "verified_by", 0.9)
            if status != "error":
                _safe_add_edge(graph_manager, observation_node.id, task_node.id, "supports", 0.82)
            _annotate_file_nodes(graph_manager, files, action_kind, step_index, status=status, episode_id=episode_node.id)
            created_node_ids.extend(
                _attach_code_artifacts(
                    graph_manager=graph_manager,
                    parent_node=observation_node,
                    session_id=session_id,
                    goal=goal,
                    step_index=step_index,
                    files=files,
                    action=action_text,
                    observation=observation_text,
                    thought=thought_text,
                    action_kind=action_kind,
                    status=status,
                    error_signatures=error_signatures,
                    episode_id=episode_node.id,
                    repo=normalized.get("repo"),
                    source=normalized.get("source"),
                    source_url=normalized.get("source_url"),
                    task_node_id=task_node.id,
                )
            )

            current_primary = observation_node

        previous_node = current_primary

    submission_diff = normalized.get("submission_diff", "")
    submission_files = normalized.get("submission_files") or extract_diff_files(submission_diff)
    if submission_diff:
        submission_episode = _create_episode_node(
            graph_manager=graph_manager,
            session_id=session_id,
            goal=goal,
            step_index=len(normalized["steps"]),
            episode_kind="submission",
            issue_title=issue_title,
            issue_text="",
            repo=normalized.get("repo"),
            source=normalized.get("source"),
            source_url=normalized.get("source_url"),
            files=submission_files,
            action="submit",
            observation=submission_diff,
            thought="submitted patch",
        )
        created_node_ids.append(submission_episode.id)
        submit_node = ingest_event(
            f"Submitted patch for {issue_title}",
            {
                "type": "decision",
                "session": session_id,
                "goal": goal,
                "importance": 0.98,
                "files": submission_files,
                "submission_diff": compact_text(submission_diff, limit=600),
                "step_index": len(normalized["steps"]),
                "action_kind": "submit",
                "episode_id": submission_episode.id,
                "related_to": [task_node.id],
                "source": normalized.get("source"),
                "source_url": normalized.get("source_url"),
                "repo": normalized.get("repo"),
                "event_at": submission_episode.event_at,
                "valid_at": submission_episode.valid_at,
            },
            graph_manager,
        )
        created_node_ids.append(submit_node.id)
        _safe_add_edge(graph_manager, previous_node.id, submit_node.id, "precedes", 0.95)
        _safe_add_edge(graph_manager, submit_node.id, task_node.id, "solves", 1.0)
        _safe_add_edge(graph_manager, submit_node.id, submission_episode.id, "derived_from", 0.96)
        _safe_add_edge(graph_manager, submit_node.id, task_node.id, "supports", 0.94)
        _annotate_file_nodes(
            graph_manager,
            submission_files,
            action_kind="submit",
            step_index=len(normalized["steps"]),
            status="success",
            episode_id=submission_episode.id,
        )
        created_node_ids.extend(
            _attach_code_artifacts(
                graph_manager=graph_manager,
                parent_node=submit_node,
                session_id=session_id,
                goal=goal,
                step_index=len(normalized["steps"]),
                files=submission_files,
                action="submit",
                observation=submission_diff,
                thought="submitted patch",
                action_kind="submit",
                status="success",
                error_signatures=[],
                episode_id=submission_episode.id,
                repo=normalized.get("repo"),
                source=normalized.get("source"),
                source_url=normalized.get("source_url"),
                task_node_id=task_node.id,
                submission_diff=submission_diff,
            )
        )
        task_node.metadata["submitted"] = True
        task_node.metadata["submitted_at"] = submit_node.event_at.isoformat() if submit_node.event_at else utc_now().isoformat()
        graph_manager.update_node(task_node)

    return {
        "session_id": session_id,
        "issue_node_id": task_node.id,
        "node_ids": created_node_ids,
        "node_count": len(created_node_ids),
        "source": normalized.get("source"),
        "issue_title": issue_title,
    }


def ingest_agent_log_file(
    path: str | Path,
    graph_manager: GraphManager,
    context: dict[str, Any] | None = None,
) -> dict[str, Any]:
    return ingest_agent_log(Path(path), graph_manager=graph_manager, context=context)


def normalize_agent_log(
    log_or_path: str | Path | dict[str, Any] | list[dict[str, Any]],
    context: dict[str, Any] | None = None,
) -> dict[str, Any]:
    return _normalize_agent_log(log_or_path, context or {})


def ingest_runtime_action(
    text: str,
    context: dict[str, Any],
    graph_manager: GraphManager,
    runtime_state: dict[str, Any],
) -> dict[str, Any]:
    session_id = str(context.get("session") or context.get("session_id") or runtime_state.get("session_id") or "default-session")
    goal = str(context.get("goal") or runtime_state.get("goal") or f"progress {session_id}")
    runtime_state["session_id"] = session_id
    runtime_state["goal"] = goal

    if runtime_state.get("step_open"):
        runtime_state["next_step_index"] = int(runtime_state.get("current_step_index", runtime_state.get("next_step_index", 0))) + 1
        runtime_state["step_open"] = False
        runtime_state["current_episode_id"] = None

    step_index = int(context.get("step_index", runtime_state.get("next_step_index", 0)))
    action_kind = str(context.get("action_kind") or infer_action_kind(text))
    thought = str(context.get("thought", "") or "")
    files = list(context.get("files") or extract_file_paths("\n".join([text, thought])))
    task_node = _ensure_runtime_task(graph_manager, session_id, goal, context)
    runtime_state["task_node_id"] = task_node.id

    episode_node = _create_episode_node(
        graph_manager=graph_manager,
        session_id=session_id,
        goal=goal,
        step_index=step_index,
        episode_kind="live_step",
        issue_title=task_node.content,
        issue_text=str(context.get("issue_text", "")),
        repo=context.get("repo"),
        source=context.get("source", "runtime"),
        source_url=context.get("source_url"),
        files=files,
        action=text,
        observation="",
        thought=thought,
    )
    action_node = ingest_event(
        _build_action_content(step_index, text, thought),
        {
            "type": "decision",
            "session": session_id,
            "goal": goal,
            "importance": float(context.get("importance", _action_importance(action_kind))),
            "files": files,
            "step_index": step_index,
            "action_kind": action_kind,
            "thought": thought,
            "episode_id": episode_node.id,
            "related_to": [task_node.id],
            "source": context.get("source", "runtime"),
            "source_url": context.get("source_url"),
            "repo": context.get("repo"),
            "event_at": episode_node.event_at,
            "valid_at": episode_node.valid_at,
        },
        graph_manager,
    )

    previous_primary_id = runtime_state.get("previous_primary_id") or task_node.id
    _safe_add_edge(graph_manager, previous_primary_id, action_node.id, "precedes", 0.95)
    _safe_add_edge(graph_manager, action_node.id, episode_node.id, "derived_from", 0.92)
    if runtime_state.get("last_error_id") and action_kind in {"open", "edit", "find_file", "submit", "pytest", "python", "test"}:
        _safe_add_edge(graph_manager, runtime_state["last_error_id"], action_node.id, "motivates", 0.9)

    _annotate_file_nodes(graph_manager, files, action_kind, step_index, status=None, episode_id=episode_node.id)
    if action_kind in {"edit", "submit"} and files:
        _invalidate_prior_states(
            graph_manager=graph_manager,
            session_id=session_id,
            files=files,
            before_step_index=step_index,
            invalidated_by=action_node.id,
            reason="edited_after_failure",
            node_types={"observation"},
            statuses={"error"},
        )

    created_ids = [episode_node.id, action_node.id]
    created_ids.extend(
        _attach_code_artifacts(
            graph_manager=graph_manager,
            parent_node=action_node,
            session_id=session_id,
            goal=goal,
            step_index=step_index,
            files=files,
            action=text,
            observation="",
            thought=thought,
            action_kind=action_kind,
            status=None,
            error_signatures=[],
            episode_id=episode_node.id,
            repo=context.get("repo"),
            source=context.get("source", "runtime"),
            source_url=context.get("source_url"),
            task_node_id=task_node.id,
        )
    )

    if action_kind == "edit":
        runtime_state["last_edit_id"] = action_node.id
    runtime_state["current_step_index"] = step_index
    runtime_state["current_episode_id"] = episode_node.id
    runtime_state["last_action_id"] = action_node.id
    runtime_state["last_action_kind"] = action_kind
    runtime_state["previous_primary_id"] = action_node.id
    runtime_state["next_step_index"] = step_index
    runtime_state["step_open"] = True
    return {"episode": episode_node, "node": action_node, "created_ids": created_ids}


def ingest_runtime_observation(
    text: str,
    context: dict[str, Any],
    graph_manager: GraphManager,
    runtime_state: dict[str, Any],
) -> dict[str, Any]:
    session_id = str(context.get("session") or context.get("session_id") or runtime_state.get("session_id") or "default-session")
    goal = str(context.get("goal") or runtime_state.get("goal") or f"progress {session_id}")
    runtime_state["session_id"] = session_id
    runtime_state["goal"] = goal

    step_index = int(context.get("step_index", runtime_state.get("current_step_index", runtime_state.get("next_step_index", 0))))
    action_kind = str(context.get("action_kind") or runtime_state.get("last_action_kind") or "message")
    files = list(context.get("files") or extract_file_paths(text))
    error_signatures = list(context.get("error_signatures") or extract_error_signatures(text))
    status = str(context.get("status") or classify_observation_status(text))
    task_node = _ensure_runtime_task(graph_manager, session_id, goal, context)
    runtime_state["task_node_id"] = task_node.id

    episode_node = graph_manager.get_node(str(runtime_state.get("current_episode_id", "")))
    if episode_node is None:
        episode_node = _create_episode_node(
            graph_manager=graph_manager,
            session_id=session_id,
            goal=goal,
            step_index=step_index,
            episode_kind="live_step",
            issue_title=task_node.content,
            issue_text=str(context.get("issue_text", "")),
            repo=context.get("repo"),
            source=context.get("source", "runtime"),
            source_url=context.get("source_url"),
            files=files,
            action="",
            observation=text,
            thought="",
        )

    observation_metadata = {
        "type": "observation",
        "session": session_id,
        "goal": goal,
        "importance": float(context.get("importance", _observation_importance(status, error_signatures))),
        "files": files,
        "step_index": step_index,
        "action_kind": action_kind,
        "status": status,
        "error_signatures": error_signatures,
        "episode_id": episode_node.id,
        "related_to": [task_node.id] + ([runtime_state["last_action_id"]] if runtime_state.get("last_action_id") else []),
        "source": context.get("source", "runtime"),
        "source_url": context.get("source_url"),
        "repo": context.get("repo"),
        "event_at": episode_node.event_at,
        "valid_at": episode_node.valid_at,
    }
    # Pass through the dead-end / rejected-angle signal so failed_hypotheses
    # can surface concluded-but-not-error observations.
    if context.get("rejected_angle"):
        observation_metadata["rejected_angle"] = True
    observation_node = ingest_event(
        _build_observation_content(text, error_signatures),
        observation_metadata,
        graph_manager,
    )

    if runtime_state.get("last_action_id"):
        _safe_add_edge(graph_manager, runtime_state["last_action_id"], observation_node.id, "causes", 1.0)
    previous_primary_id = runtime_state.get("previous_primary_id") or task_node.id
    if previous_primary_id != observation_node.id:
        _safe_add_edge(graph_manager, previous_primary_id, observation_node.id, "precedes", 0.7)
    _safe_add_edge(graph_manager, observation_node.id, episode_node.id, "derived_from", 0.92)

    if status == "error":
        runtime_state["last_error_id"] = observation_node.id
        if runtime_state.get("last_edit_id"):
            _safe_add_edge(graph_manager, runtime_state["last_edit_id"], observation_node.id, "rejected_by", 0.92)
    if status == "success" and runtime_state.get("last_edit_id"):
        _safe_add_edge(graph_manager, runtime_state["last_edit_id"], observation_node.id, "validates", 0.95)
        _safe_add_edge(graph_manager, runtime_state["last_edit_id"], observation_node.id, "verified_by", 0.97)
        if files:
            _invalidate_prior_states(
                graph_manager=graph_manager,
                session_id=session_id,
                files=files,
                before_step_index=step_index,
                invalidated_by=observation_node.id,
                reason="validated_after_edit",
                node_types={"observation"},
                statuses={"error"},
            )
    if status == "success" and action_kind in {"python", "pytest", "submit", "test"}:
        _safe_add_edge(graph_manager, observation_node.id, task_node.id, "solves", 0.9)
        _safe_add_edge(graph_manager, task_node.id, observation_node.id, "verified_by", 0.9)
    if status != "error":
        _safe_add_edge(graph_manager, observation_node.id, task_node.id, "supports", 0.82)

    _annotate_file_nodes(graph_manager, files, action_kind, step_index, status=status, episode_id=episode_node.id)
    created_ids = [observation_node.id]
    created_ids.extend(
        _attach_code_artifacts(
            graph_manager=graph_manager,
            parent_node=observation_node,
            session_id=session_id,
            goal=goal,
            step_index=step_index,
            files=files,
            action=str(context.get("action", "")),
            observation=text,
            thought=str(context.get("thought", "")),
            action_kind=action_kind,
            status=status,
            error_signatures=error_signatures,
            episode_id=episode_node.id,
            repo=context.get("repo"),
            source=context.get("source", "runtime"),
            source_url=context.get("source_url"),
            task_node_id=task_node.id,
            submission_diff=str(context.get("submission_diff", "")),
        )
    )

    runtime_state["previous_primary_id"] = observation_node.id
    runtime_state["step_open"] = False
    runtime_state["current_episode_id"] = None
    runtime_state["current_step_index"] = step_index
    runtime_state["next_step_index"] = step_index + 1
    return {"episode": episode_node, "node": observation_node, "created_ids": created_ids}


def ingest_runtime_test_result(
    command: str,
    observation: str,
    context: dict[str, Any],
    graph_manager: GraphManager,
    runtime_state: dict[str, Any],
) -> dict[str, Any]:
    action_result = ingest_runtime_action(
        text=command,
        context={**context, "action_kind": str(context.get("action_kind") or infer_action_kind(command) or "pytest")},
        graph_manager=graph_manager,
        runtime_state=runtime_state,
    )
    observation_result = ingest_runtime_observation(
        text=observation,
        context={**context, "action": command, "action_kind": action_result["node"].metadata.get("action_kind")},
        graph_manager=graph_manager,
        runtime_state=runtime_state,
    )
    return {
        "action": action_result["node"],
        "observation": observation_result["node"],
        "created_ids": action_result["created_ids"] + observation_result["created_ids"],
    }


def _normalize_agent_log(
    log_or_path: str | Path | dict[str, Any] | list[dict[str, Any]],
    context: dict[str, Any],
) -> dict[str, Any]:
    source_path = Path(log_or_path) if isinstance(log_or_path, (str, Path)) else None
    payload = load_json_path(source_path) if source_path else log_or_path

    if isinstance(payload, dict) and payload.get("format") == "agent_log":
        normalized = dict(payload)
    elif isinstance(payload, dict) and "trajectory" in payload:
        normalized = _normalize_swe_agent_trajectory(payload, source_path, context)
    elif isinstance(payload, list):
        normalized = _normalize_openhands_events(payload, source_path, context)
    else:
        raise ValueError("Unsupported agent log format")

    normalized.setdefault("source", context.get("source", "agent_log"))
    normalized.setdefault("source_url", context.get("source_url"))
    normalized.setdefault("repo", context.get("repo"))
    normalized.setdefault("issue_text", "")
    normalized.setdefault("issue_title", extract_issue_title(normalized.get("issue_text", "")))
    normalized.setdefault("goal", f"resolve {normalized['issue_title']}")
    normalized.setdefault("session_id", context.get("session") or f"{normalized['source']}:{slugify(normalized['issue_title'])}")
    normalized.setdefault("submission_diff", "")
    normalized.setdefault("submission_files", extract_diff_files(normalized["submission_diff"]))

    for index, step in enumerate(normalized.get("steps", [])):
        step.setdefault("index", index)
        step.setdefault("action", "")
        step.setdefault("thought", "")
        step.setdefault("observation", "")
        step.setdefault("action_kind", infer_action_kind(step["action"]))
        step.setdefault("files", derive_step_files(step["action"], step["observation"], step["thought"], step["action_kind"]))
        if "status" not in step and step["observation"]:
            step["status"] = classify_observation_status(step["observation"])
        if "error_signatures" not in step:
            step["error_signatures"] = extract_error_signatures(step["observation"])

    return normalized


def _normalize_swe_agent_trajectory(
    payload: dict[str, Any],
    source_path: Path | None,
    context: dict[str, Any],
) -> dict[str, Any]:
    issue_text = context.get("issue_text") or extract_issue_text_from_history(payload.get("history"))
    issue_title = context.get("issue_title") or extract_issue_title(issue_text)
    trajectory = payload.get("trajectory", [])
    steps = []

    for index, step in enumerate(trajectory):
        action = str(step.get("action", ""))
        observation = str(step.get("observation", ""))
        thought = str(step.get("thought", "") or step.get("response", ""))
        files = derive_step_files(action, observation, thought, infer_action_kind(action))
        steps.append(
            {
                "index": index,
                "action": action,
                "thought": thought,
                "observation": observation,
                "files": files,
                "action_kind": infer_action_kind(action),
                "status": classify_observation_status(observation) if observation else "info",
                "error_signatures": extract_error_signatures(observation),
            }
        )

    session_id = context.get("session") or (source_path.stem if source_path else f"swe-agent:{slugify(issue_title)}")
    info = payload.get("info") or {}
    return {
        "format": "agent_log",
        "source": "swe-agent",
        "source_url": context.get("source_url"),
        "session_id": session_id,
        "repo": context.get("repo"),
        "issue_title": issue_title,
        "issue_text": issue_text,
        "goal": f"resolve {issue_title}",
        "steps": steps,
        "submission_diff": str(info.get("submission", "")),
        "submission_files": extract_diff_files(str(info.get("submission", ""))),
    }


def _normalize_openhands_events(
    payload: list[dict[str, Any]],
    source_path: Path | None,
    context: dict[str, Any],
) -> dict[str, Any]:
    issue_text = context.get("issue_text", "")
    first_user_message = next(
        (
            str(event.get("message", ""))
            for event in payload
            if event.get("source") == "user" and str(event.get("message", "")).strip()
        ),
        "",
    )
    if not issue_text:
        issue_text = first_user_message
    issue_title = context.get("issue_title") or extract_issue_title(issue_text)

    steps = []
    for index, event in enumerate(payload):
        if event.get("source") not in {"agent", "user"}:
            continue
        action = str(event.get("action", event.get("message", "")))
        observation = str(event.get("observation", event.get("content", "")) or event.get("message", ""))
        thought = str(event.get("message", "")) if event.get("source") == "agent" else ""
        files = derive_step_files(action, observation, thought, infer_action_kind(action))
        steps.append(
            {
                "index": index,
                "action": action,
                "thought": thought,
                "observation": observation if event.get("source") == "agent" else "",
                "files": files,
                "action_kind": infer_action_kind(action),
                "status": classify_observation_status(observation) if observation else "info",
                "error_signatures": extract_error_signatures(observation),
            }
        )

    session_id = context.get("session") or (source_path.stem if source_path else f"openhands:{slugify(issue_title)}")
    return {
        "format": "agent_log",
        "source": "openhands",
        "source_url": context.get("source_url"),
        "session_id": session_id,
        "repo": context.get("repo"),
        "issue_title": issue_title,
        "issue_text": issue_text,
        "goal": f"resolve {issue_title}",
        "steps": steps,
        "submission_diff": "",
        "submission_files": [],
    }


def _build_action_content(step_index: int, action: str, thought: str) -> str:
    action = compact_text(action, limit=220)
    if thought:
        return f"Step {step_index}: {action}. Intent: {compact_text(thought, limit=180)}"
    return f"Step {step_index}: {action}"


def _build_observation_content(observation: str, error_signatures: list[str]) -> str:
    if error_signatures:
        return compact_text(f"{error_signatures[0]} | {observation}", limit=420)
    return compact_text(observation, limit=420)


def _action_importance(action_kind: str) -> float:
    if action_kind in {"edit", "open", "find_file", "submit"}:
        return 0.86
    if action_kind in {"python", "pytest", "test"}:
        return 0.82
    if action_kind in {"create", "read"}:
        return 0.74
    return 0.6


def _observation_importance(status: str, error_signatures: list[str]) -> float:
    if status == "error":
        return 0.92 if error_signatures else 0.85
    if status == "success":
        return 0.8
    return 0.64


def _safe_add_edge(
    graph_manager: GraphManager,
    source: str,
    target: str,
    edge_type: str,
    weight: float,
) -> None:
    if source == target:
        return
    if not graph_manager.has_node(source) or not graph_manager.has_node(target):
        return
    graph_manager.add_edge(Edge(source=source, target=target, type=edge_type, weight=weight))


def _annotate_file_nodes(
    graph_manager: GraphManager,
    files: list[str],
    action_kind: str,
    step_index: int,
    status: str | None,
    episode_id: str | None = None,
) -> None:
    for file_path in files:
        file_node = make_anchor_node(graph_manager, "file", file_path, {"path": file_path})
        action_kinds = set(file_node.metadata.get("action_kinds", []))
        action_kinds.add(action_kind)
        step_indices = set(file_node.metadata.get("step_indices", []))
        step_indices.add(step_index)
        file_node.metadata["action_kinds"] = sorted(action_kinds)
        file_node.metadata["step_indices"] = sorted(step_indices)
        if action_kind in {"edit", "submit"}:
            file_node.metadata["edited"] = True
            file_node.importance = max(file_node.importance, 0.86)
        if action_kind in {"open", "find_file"}:
            file_node.metadata["inspected"] = True
            file_node.importance = max(file_node.importance, 0.78)
        if status == "error":
            file_node.metadata["error_related"] = True
        graph_manager.update_node(file_node)
        if episode_id:
            _safe_add_edge(graph_manager, file_node.id, episode_id, "derived_from", 0.72)


def _create_episode_node(
    graph_manager: GraphManager,
    session_id: str,
    goal: str,
    step_index: int,
    episode_kind: str,
    issue_title: str,
    issue_text: str,
    repo: str | None,
    source: str | None,
    source_url: str | None,
    files: list[str],
    action: str = "",
    observation: str = "",
    thought: str = "",
) -> Node:
    episode_id = f"episode:{slugify(session_id, max_length=24)}:{episode_kind}:{step_index if step_index >= 0 else 'root'}"
    existing = graph_manager.get_node(episode_id)
    if existing is not None:
        return existing

    raw_parts = [issue_title, issue_text, action, observation, thought, " ".join(files)]
    raw_text = "\n".join(part for part in raw_parts if part).strip() or issue_title
    event_time = utc_now()
    metadata = {
        "session": session_id,
        "goal": goal,
        "repo": repo,
        "source": source,
        "source_url": source_url,
        "files": files,
        "step_index": step_index,
        "episode_kind": episode_kind,
        "raw_action": action,
        "raw_observation": observation,
        "raw_thought": thought,
        "issue_title": issue_title,
        "keywords": sorted(tokenize(raw_text)),
        "current": True,
    }
    node = Node(
        id=episode_id,
        type="episode",
        content=_build_episode_content(step_index, episode_kind, issue_title, action, observation),
        importance=0.34 if episode_kind == "step" else 0.42,
        recency=1.0,
        capacity_used=estimate_capacity(raw_text, metadata),
        capacity_max=8.0,
        event_at=event_time,
        valid_at=event_time,
        metadata=metadata,
    )
    graph_manager.add_node(node)
    return node


def _build_episode_content(step_index: int, episode_kind: str, issue_title: str, action: str, observation: str) -> str:
    if episode_kind == "issue":
        return compact_text(f"Issue episode: {issue_title}", limit=180)
    if episode_kind == "submission":
        return compact_text(f"Submission episode for {issue_title}", limit=180)
    summary = action or observation or issue_title
    return compact_text(f"Episode {step_index}: {summary}", limit=220)


def _invalidate_prior_states(
    graph_manager: GraphManager,
    session_id: str,
    files: list[str],
    before_step_index: int,
    invalidated_by: str,
    reason: str,
    node_types: set[str],
    statuses: set[str] | None = None,
) -> None:
    if not files:
        return

    file_set = set(files)
    for node in graph_manager.all_nodes():
        if node.id == invalidated_by or node.type not in node_types:
            continue
        if node.metadata.get("session") != session_id:
            continue
        step_index = node.metadata.get("step_index")
        if step_index is None or int(step_index) >= before_step_index:
            continue
        if node.invalid_at is not None:
            continue
        node_files = set(node.metadata.get("files", []))
        if not node_files or not (node_files & file_set):
            continue
        if statuses and node.metadata.get("status") not in statuses:
            continue

        invalidated_at = utc_now()
        node.invalid_at = invalidated_at
        node.metadata["current"] = False
        node.metadata["invalidated_by"] = invalidated_by
        node.metadata["superseded_by"] = invalidated_by
        node.metadata["invalidated_reason"] = reason
        node.metadata["invalidated_at"] = invalidated_at.isoformat()
        node.metadata["superseded_at"] = invalidated_at.isoformat()
        graph_manager.update_node(node)
        _safe_add_edge(
            graph_manager,
            invalidated_by,
            node.id,
            "supersedes",
            0.96 if reason == "validated_after_edit" else 0.88,
        )
        _safe_add_edge(graph_manager, invalidated_by, node.id, "contradicts", 0.82)
        _safe_add_edge(graph_manager, node.id, invalidated_by, "rejected_by", 0.82)


def _ensure_runtime_task(
    graph_manager: GraphManager,
    session_id: str,
    goal: str,
    context: dict[str, Any],
) -> Node:
    existing = next(
        (
            node
            for node in graph_manager.all_nodes()
            if node.type == "task" and node.metadata.get("session") == session_id
        ),
        None,
    )
    if existing is not None:
        return existing

    issue_title = str(context.get("issue_title") or context.get("task") or goal or session_id)
    issue_text = str(context.get("issue_text") or issue_title)
    return ingest_event(
        issue_title,
        {
            "type": "task",
            "session": session_id,
            "goal": goal,
            "importance": float(context.get("importance", 0.94)),
            "issue_text": issue_text,
            "repo": context.get("repo"),
            "source": context.get("source", "runtime"),
            "source_url": context.get("source_url"),
        },
        graph_manager,
    )


def _attach_code_artifacts(
    graph_manager: GraphManager,
    parent_node: Node,
    session_id: str,
    goal: str,
    step_index: int,
    files: list[str],
    action: str,
    observation: str,
    thought: str,
    action_kind: str,
    status: str | None,
    error_signatures: list[str],
    episode_id: str | None,
    repo: str | None,
    source: str | None,
    source_url: str | None,
    task_node_id: str | None,
    submission_diff: str = "",
) -> list[str]:
    created_ids: list[str] = []
    episode_node = graph_manager.get_node(episode_id) if episode_id else None

    command_node: Node | None = None
    if parent_node.type == "decision" and action.strip():
        command_node = ingest_event(
            compact_text(action, limit=220),
            {
                "type": "command",
                "command": True,
                "session": session_id,
                "goal": goal,
                "files": files,
                "step_index": step_index,
                "action_kind": action_kind,
                "episode_id": episode_id,
                "repo": repo,
                "source": source,
                "source_url": source_url,
                "disable_auto_links": True,
                "event_at": parent_node.event_at,
                "valid_at": parent_node.valid_at,
            },
            graph_manager,
        )
        created_ids.append(command_node.id)
        _safe_add_edge(graph_manager, parent_node.id, command_node.id, "executes", 0.96)
        if episode_node:
            _safe_add_edge(graph_manager, command_node.id, episode_node.id, "derived_from", 0.86)

    target_tests = _unique_preserve_order(extract_test_targets("\n".join([action, observation, submission_diff, " ".join(files)])))
    for test_target in target_tests:
        test_node = ingest_event(
            test_target,
            {
                "type": "test",
                "test_target": test_target,
                "session": session_id,
                "goal": goal,
                "files": files,
                "step_index": step_index,
                "episode_id": episode_id,
                "repo": repo,
                "source": source,
                "source_url": source_url,
                "disable_auto_links": True,
                "event_at": parent_node.event_at,
                "valid_at": parent_node.valid_at,
            },
            graph_manager,
        )
        created_ids.append(test_node.id)
        if command_node:
            _safe_add_edge(graph_manager, command_node.id, test_node.id, "runs", 0.94)
        else:
            _safe_add_edge(graph_manager, parent_node.id, test_node.id, "verifies", 0.86)
        if status == "success":
            _safe_add_edge(graph_manager, test_node.id, parent_node.id, "verified_by", 0.94)
        elif status == "error":
            _safe_add_edge(graph_manager, test_node.id, parent_node.id, "contradicts", 0.88)

    raw_symbol_text = "\n".join([action, thought, observation, submission_diff])
    for symbol_name in _unique_preserve_order(extract_symbol_names(raw_symbol_text)):
        symbol_node = ingest_event(
            symbol_name,
            {
                "type": "symbol",
                "symbol": True,
                "session": session_id,
                "goal": goal,
                "files": files,
                "step_index": step_index,
                "episode_id": episode_id,
                "repo": repo,
                "source": source,
                "source_url": source_url,
                "disable_auto_links": True,
                "event_at": parent_node.event_at,
                "valid_at": parent_node.valid_at,
            },
            graph_manager,
        )
        created_ids.append(symbol_node.id)
        edge_type = "touches_symbol" if action_kind in {"edit", "submit", "create"} else "references_symbol"
        _safe_add_edge(graph_manager, parent_node.id, symbol_node.id, edge_type, 0.86)
        if command_node:
            _safe_add_edge(graph_manager, command_node.id, symbol_node.id, "references_symbol", 0.8)
        for file_path in files:
            file_node = make_anchor_node(graph_manager, "file", file_path, {"path": file_path})
            _safe_add_edge(graph_manager, symbol_node.id, file_node.id, "references_file", 0.78)

    for signature in _unique_preserve_order(error_signatures):
        signature_node = ingest_event(
            signature,
            {
                "type": "error_signature",
                "error_signature": True,
                "session": session_id,
                "goal": goal,
                "files": files,
                "step_index": step_index,
                "episode_id": episode_id,
                "repo": repo,
                "source": source,
                "source_url": source_url,
                "disable_auto_links": True,
                "event_at": parent_node.event_at,
                "valid_at": parent_node.valid_at,
            },
            graph_manager,
        )
        created_ids.append(signature_node.id)
        _safe_add_edge(graph_manager, parent_node.id, signature_node.id, "emits_error", 0.96)
        if task_node_id:
            _safe_add_edge(graph_manager, signature_node.id, task_node_id, "contradicts", 0.86)
        for file_path in files:
            file_node = make_anchor_node(graph_manager, "file", file_path, {"path": file_path})
            _safe_add_edge(graph_manager, signature_node.id, file_node.id, "fails_in", 0.92)

    diff_text = submission_diff if submission_diff else (observation if "@@" in observation else "")
    for hunk in extract_patch_hunks(diff_text):
        hunk_node = ingest_event(
            hunk,
            {
                "type": "patch_hunk",
                "patch_hunk": True,
                "session": session_id,
                "goal": goal,
                "files": files,
                "step_index": step_index,
                "episode_id": episode_id,
                "repo": repo,
                "source": source,
                "source_url": source_url,
                "disable_auto_links": True,
                "event_at": parent_node.event_at,
                "valid_at": parent_node.valid_at,
            },
            graph_manager,
        )
        created_ids.append(hunk_node.id)
        _safe_add_edge(graph_manager, parent_node.id, hunk_node.id, "contains_patch", 0.95)
        for file_path in files:
            file_node = make_anchor_node(graph_manager, "file", file_path, {"path": file_path})
            _safe_add_edge(graph_manager, hunk_node.id, file_node.id, "patches_file", 0.94)
        for symbol_name in extract_symbol_names(hunk):
            symbol_node = ingest_event(
                symbol_name,
                {
                    "type": "symbol",
                    "symbol": True,
                    "session": session_id,
                    "goal": goal,
                    "files": files,
                    "step_index": step_index,
                    "episode_id": episode_id,
                    "repo": repo,
                    "source": source,
                    "source_url": source_url,
                    "disable_auto_links": True,
                    "event_at": parent_node.event_at,
                    "valid_at": parent_node.valid_at,
                },
                graph_manager,
            )
            _safe_add_edge(graph_manager, hunk_node.id, symbol_node.id, "touches_symbol", 0.86)

    return _unique_preserve_order(created_ids)


def _unique_preserve_order(values: list[Any]) -> list[Any]:
    seen = set()
    ordered: list[Any] = []
    for value in values:
        if value in seen:
            continue
        seen.add(value)
        ordered.append(value)
    return ordered
