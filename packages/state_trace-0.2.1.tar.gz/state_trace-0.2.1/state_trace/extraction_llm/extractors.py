"""Convert freeform text transcripts into the normalized agent-log shape.

The heuristic extractor is deterministic and has no external deps; it parses
role-tagged or numbered log lines and infers action/observation pairs using the
same heuristics as the structured agent-log ingester.

The OpenAI extractor sends a single structured request. Use it for transcripts
that don't have explicit role tags or step markers.
"""

from __future__ import annotations

import json
import os
import re
from typing import Any, Protocol

from state_trace.utils import classify_observation_status, extract_file_paths, infer_action_kind


ROLE_PREFIX_RE = re.compile(
    r"""
    ^\s*
    (?P<role>thought|thinking|reasoning|action|tool|command|run|observation|observe|result|output|error|stdout|stderr|test|assistant|user)
    [\s:>\-]+
    """,
    re.IGNORECASE | re.VERBOSE,
)

STEP_HEADER_RE = re.compile(r"^\s*(?:step|turn|iteration)\s*[:#]?\s*(\d+)\b", re.IGNORECASE)


class TranscriptExtractor(Protocol):
    def extract(self, text: str, context: dict[str, Any] | None = None) -> dict[str, Any]:
        """Return a dict compatible with MemoryEngine.store_agent_log()."""


class HeuristicTranscriptExtractor:
    """Deterministic transcript -> agent_log converter.

    Handles three common transcript formats:
      1. role-tagged (``Thought: ...`` / ``Action: ...`` / ``Observation: ...``)
      2. step-numbered blocks (``Step 1: ...`` followed by freeform text)
      3. flat prose — falls back to grouping consecutive non-empty lines
    """

    def extract(self, text: str, context: dict[str, Any] | None = None) -> dict[str, Any]:
        context = dict(context or {})
        lines = [line.rstrip() for line in text.splitlines()]
        issue_title = str(context.get("issue_title") or _infer_issue_title(lines))
        steps = _group_into_steps(lines)
        return {
            "format": "agent_log",
            "source": context.get("source", "freeform_transcript"),
            "source_url": context.get("source_url"),
            "repo": context.get("repo"),
            "session_id": context.get("session") or context.get("session_id") or "freeform-transcript",
            "goal": context.get("goal"),
            "issue_title": issue_title,
            "issue_text": context.get("issue_text") or issue_title,
            "steps": steps,
            "submission_diff": context.get("submission_diff", ""),
        }


class OpenAITranscriptExtractor:
    """Optional: uses OpenAI Responses API to convert arbitrary transcripts.

    Requires ``openai>=2.0`` and ``OPENAI_API_KEY``. Falls back to the heuristic
    extractor when the SDK is unavailable or returns a non-JSON response.
    """

    def __init__(self, model: str = "gpt-5.4-mini", client: Any | None = None) -> None:
        self.model = model
        self._client = client

    def _get_client(self) -> Any | None:
        if self._client is not None:
            return self._client
        try:
            from openai import OpenAI
        except ImportError:  # pragma: no cover - optional
            return None
        if not os.environ.get("OPENAI_API_KEY"):
            return None
        self._client = OpenAI()
        return self._client

    def extract(self, text: str, context: dict[str, Any] | None = None) -> dict[str, Any]:
        client = self._get_client()
        if client is None:
            return HeuristicTranscriptExtractor().extract(text, context)

        prompt = _build_prompt(text)
        try:
            response = client.responses.create(
                model=self.model,
                input=prompt,
                response_format={"type": "json_object"},
            )
            raw = getattr(response, "output_text", None) or getattr(response, "text", None) or ""
            payload = json.loads(raw)
        except Exception:  # pragma: no cover - network/parse failures
            return HeuristicTranscriptExtractor().extract(text, context)

        context = dict(context or {})
        merged = {
            "format": "agent_log",
            "source": context.get("source", "llm_transcript"),
            "source_url": context.get("source_url"),
            "repo": context.get("repo") or payload.get("repo"),
            "session_id": context.get("session") or payload.get("session_id") or "llm-transcript",
            "goal": context.get("goal") or payload.get("goal"),
            "issue_title": context.get("issue_title") or payload.get("issue_title") or "freeform transcript",
            "issue_text": context.get("issue_text") or payload.get("issue_text", ""),
            "steps": _normalize_llm_steps(payload.get("steps", [])),
            "submission_diff": payload.get("submission_diff", context.get("submission_diff", "")),
        }
        return merged


def extract_agent_log_from_text(
    text: str,
    context: dict[str, Any] | None = None,
    extractor: TranscriptExtractor | None = None,
) -> dict[str, Any]:
    chosen = extractor or HeuristicTranscriptExtractor()
    return chosen.extract(text, context)


def _infer_issue_title(lines: list[str]) -> str:
    for line in lines:
        stripped = line.strip()
        if not stripped:
            continue
        if stripped.lower().startswith(("issue:", "title:", "problem:", "task:")):
            return stripped.split(":", 1)[1].strip() or stripped
        return stripped[:180]
    return "freeform transcript"


def _group_into_steps(lines: list[str]) -> list[dict[str, Any]]:
    chunks: list[list[tuple[str, str]]] = [[]]
    for line in lines:
        stripped = line.strip()
        if STEP_HEADER_RE.match(stripped):
            if chunks[-1]:
                chunks.append([])
            continue
        if not stripped:
            if chunks[-1]:
                chunks.append([])
            continue
        role, content = _split_role(stripped)
        chunks[-1].append((role, content))
    chunks = [chunk for chunk in chunks if chunk]
    steps: list[dict[str, Any]] = []
    for index, chunk in enumerate(chunks):
        action = _join_role(chunk, {"action", "tool", "command", "run", "assistant"})
        thought = _join_role(chunk, {"thought", "thinking", "reasoning"})
        observation = _join_role(chunk, {"observation", "observe", "result", "output", "error", "stdout", "stderr", "test"})
        if not action and not observation:
            merged = " ".join(content for _, content in chunk)
            action = merged
        files = sorted(set(extract_file_paths(" ".join([action, thought, observation]))))
        action_kind = infer_action_kind(action or thought or observation)
        status = classify_observation_status(observation) if observation else None
        steps.append(
            {
                "index": index,
                "action": action,
                "thought": thought,
                "observation": observation,
                "files": files,
                "action_kind": action_kind,
                "status": status,
            }
        )
    return steps


def _split_role(line: str) -> tuple[str, str]:
    match = ROLE_PREFIX_RE.match(line)
    if not match:
        return "unknown", line
    role = match.group("role").lower()
    body = line[match.end():].strip()
    return role, body


def _join_role(chunk: list[tuple[str, str]], roles: set[str]) -> str:
    parts = [content for role, content in chunk if role in roles]
    return " ".join(parts).strip()


def _normalize_llm_steps(steps: Any) -> list[dict[str, Any]]:
    if not isinstance(steps, list):
        return []
    normalized: list[dict[str, Any]] = []
    for index, step in enumerate(steps):
        if not isinstance(step, dict):
            continue
        action = str(step.get("action", "") or "")
        observation = str(step.get("observation", "") or "")
        thought = str(step.get("thought", "") or "")
        files = step.get("files") or extract_file_paths(" ".join([action, observation, thought]))
        normalized.append(
            {
                "index": int(step.get("index", index)),
                "action": action,
                "observation": observation,
                "thought": thought,
                "files": sorted({str(item) for item in files}),
                "action_kind": step.get("action_kind") or infer_action_kind(action or thought),
                "status": step.get("status") or classify_observation_status(observation),
            }
        )
    return normalized


def _build_prompt(text: str) -> str:
    return (
        "Convert the following agent or coding-session transcript into a JSON object with:\n"
        "- issue_title (short sentence)\n"
        "- issue_text\n"
        "- steps (ordered list of {index, action, observation, thought, files, action_kind, status})\n"
        "- submission_diff (the final patch if present, else empty)\n"
        "action_kind ∈ {edit, open, find_file, submit, python, pytest, read, create, other}.\n"
        "status ∈ {success, error, info, null}.\n"
        "Respond with only the JSON object.\n\n"
        "TRANSCRIPT:\n"
        + text
    )
