from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


STOPWORDS = {
    "a",
    "an",
    "and",
    "are",
    "as",
    "at",
    "be",
    "because",
    "been",
    "but",
    "by",
    "for",
    "from",
    "how",
    "if",
    "in",
    "into",
    "is",
    "it",
    "its",
    "of",
    "on",
    "or",
    "still",
    "that",
    "the",
    "their",
    "then",
    "there",
    "these",
    "they",
    "this",
    "to",
    "was",
    "were",
    "what",
    "when",
    "why",
    "with",
}

PATH_TOKEN_RE = re.compile(r"[A-Za-z0-9_./:-]+")
FILE_EXTENSION_RE = re.compile(r"\.[A-Za-z0-9]{1,8}$")
FILELIKE_EXTENSIONS = {
    "c",
    "cc",
    "cfg",
    "cpp",
    "css",
    "csv",
    "go",
    "h",
    "hpp",
    "html",
    "ini",
    "java",
    "js",
    "json",
    "jsx",
    "md",
    "php",
    "py",
    "rb",
    "rs",
    "sh",
    "sql",
    "svg",
    "toml",
    "ts",
    "tsx",
    "txt",
    "xml",
    "yaml",
    "yml",
}
SYMBOL_RE = re.compile(r"\b([A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)+)\b")
CALLABLE_SYMBOL_RE = re.compile(r"\b([A-Za-z_][A-Za-z0-9_]*)\s*\(")
PYTEST_TARGET_RE = re.compile(r"\b([A-Za-z0-9_./-]+::[A-Za-z0-9_][A-Za-z0-9_]*)\b")


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def normalize_text(text: str) -> str:
    return re.sub(r"\s+", " ", text.strip().lower())


def compact_text(text: str, limit: int = 420) -> str:
    normalized = re.sub(r"\s+", " ", text.strip())
    if len(normalized) <= limit:
        return normalized
    return normalized[: limit - 3].rstrip() + "..."


def tokenize_sequence(text: str) -> list[str]:
    if not text:
        return []

    tokens: list[str] = []
    for raw_token in PATH_TOKEN_RE.findall(normalize_text(text)):
        if raw_token and raw_token not in STOPWORDS:
            tokens.append(raw_token)
        for subtoken in re.split(r"[_./:-]+", raw_token):
            if len(subtoken) > 1 and subtoken not in STOPWORDS:
                tokens.append(subtoken)
    return tokens


def tokenize(text: str) -> set[str]:
    return set(tokenize_sequence(text))


def flatten_context_values(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        return [value]
    if isinstance(value, (int, float, bool)):
        return [str(value)]
    if isinstance(value, dict):
        flattened: list[str] = []
        for dict_value in value.values():
            flattened.extend(flatten_context_values(dict_value))
        return flattened
    if isinstance(value, (list, tuple, set)):
        flattened = []
        for item in value:
            flattened.extend(flatten_context_values(item))
        return flattened
    return [str(value)]


def extract_context_tokens(context: dict[str, Any] | None) -> set[str]:
    if not context:
        return set()

    tokens: set[str] = set()
    for value in context.values():
        for text in flatten_context_values(value):
            tokens.update(tokenize(text))
    return tokens


def slugify(text: str, max_length: int = 40) -> str:
    normalized = normalize_text(text)
    slug = re.sub(r"[^a-z0-9]+", "-", normalized).strip("-")
    slug = slug[:max_length].strip("-")
    return slug or "memory"


def estimate_capacity(text: str, metadata: dict[str, Any] | None = None) -> float:
    word_cost = max(1.0, len(text.split()) / 12.0)
    metadata_cost = 0.15 * len(metadata or {})
    return round(word_cost + metadata_cost, 3)


def jaccard_similarity(left: set[str], right: set[str]) -> float:
    if not left or not right:
        return 0.0
    union = left | right
    if not union:
        return 0.0
    return len(left & right) / len(union)


def top_terms(tokens: set[str], limit: int = 5) -> list[str]:
    return sorted(tokens)[:limit]


def load_json_path(path: str | Path) -> Any:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def extract_file_paths(text: str) -> list[str]:
    if not text:
        return []

    filtered: list[str] = []
    seen = set()
    for match in PATH_TOKEN_RE.findall(text):
        cleaned = _normalize_path_candidate(match)
        if not cleaned or not _looks_like_path(cleaned):
            continue
        if cleaned in seen:
            continue
        seen.add(cleaned)
        filtered.append(cleaned)
    return filtered


def derive_step_files(action: str, observation: str, thought: str, action_kind: str) -> list[str]:
    action_files = extract_file_paths(action)
    observation_files = extract_file_paths(observation)
    thought_files = extract_file_paths(thought)

    if action_kind in {"open", "read"}:
        return _unique_preserve_order(action_files or thought_files)
    if action_kind == "find_file":
        return _unique_preserve_order(observation_files or action_files or thought_files)
    if action_kind in {"edit", "create", "rm"}:
        return _unique_preserve_order(action_files + observation_files + thought_files)
    if action_kind in {"python", "python3", "pytest", "test", "submit"}:
        return _unique_preserve_order(action_files + observation_files + thought_files)
    if action_kind in {"ls", "pip"}:
        return _unique_preserve_order(action_files)
    return _unique_preserve_order(action_files + observation_files + thought_files)


def _normalize_path_candidate(candidate: str) -> str:
    cleaned = candidate.strip("\"'`()[]{}<>")
    cleaned = cleaned.rstrip(".,:;!?")
    cleaned = re.sub(r"^(?:[A-Za-z]:)?(?:/testbed/|/workspace/|/[A-Za-z0-9_.-]+__[A-Za-z0-9_.-]+/)", "", cleaned)
    cleaned = cleaned.removeprefix("a/").removeprefix("b/")
    cleaned = re.sub(r":\d+(?::\d+)?$", "", cleaned)
    if cleaned in {"start/end", "end_of_edit"}:
        return ""
    return cleaned.strip()


def _looks_like_path(candidate: str) -> bool:
    if not candidate or candidate in {".", ".."}:
        return False
    lowered = candidate.lower()
    if lowered.startswith(("http://", "https://")):
        return False
    if lowered.startswith(("/usr/", "/root/", "/var/", "/etc/")):
        return False

    if "/" in candidate:
        segments = [segment for segment in candidate.split("/") if segment]
        if len(segments) < 1:
            return False
        if not any(any(char.isalpha() for char in segment) for segment in segments):
            return False
        if len(segments) == 1:
            return bool(FILE_EXTENSION_RE.search(segments[0]))
        return True

    if candidate.count(".") == 1 and candidate.replace(".", "", 1).isdigit():
        return False
    if not FILE_EXTENSION_RE.search(candidate):
        return False

    stem, _, suffix = candidate.rpartition(".")
    return bool(stem) and any(char.isalpha() for char in stem) and suffix.lower() in FILELIKE_EXTENSIONS


def extract_diff_files(diff_text: str) -> list[str]:
    files: list[str] = []
    seen = set()
    for line in diff_text.splitlines():
        if not line.startswith("+++ "):
            continue
        cleaned = line.removeprefix("+++ ").strip()
        if cleaned == "/dev/null":
            continue
        cleaned = cleaned.removeprefix("a/").removeprefix("b/")
        if cleaned not in seen:
            seen.add(cleaned)
            files.append(cleaned)
    return files


def extract_patch_hunks(diff_text: str, limit: int = 6) -> list[str]:
    if not diff_text:
        return []

    hunks: list[str] = []
    current: list[str] = []
    for line in diff_text.splitlines():
        if line.startswith("@@"):
            if current:
                hunks.append(compact_text("\n".join(current), limit=320))
                current = []
            current.append(line)
            continue
        if current:
            if line.startswith(("diff --git", "index ", "--- ", "+++ ")):
                continue
            current.append(line)
    if current:
        hunks.append(compact_text("\n".join(current), limit=320))
    return hunks[:limit]


def is_test_target(value: str) -> bool:
    lowered = value.lower()
    basename = lowered.rsplit("/", 1)[-1]
    return (
        "::" in lowered
        or "/tests/" in lowered
        or lowered.startswith("tests/")
        or basename.startswith("test_")
        or basename.endswith("_test.py")
    )


def extract_test_targets(text: str) -> list[str]:
    if not text:
        return []

    targets: list[str] = []
    seen = set()
    for path in extract_file_paths(text):
        if not is_test_target(path):
            continue
        if path not in seen:
            seen.add(path)
            targets.append(path)

    for match in PYTEST_TARGET_RE.findall(text):
        cleaned = _normalize_path_candidate(match)
        if cleaned and cleaned not in seen:
            seen.add(cleaned)
            targets.append(cleaned)
    return targets


def extract_symbol_names(text: str, limit: int = 10) -> list[str]:
    if not text:
        return []

    symbols: list[str] = []
    seen = set()
    file_paths = set(extract_file_paths(text))

    for match in SYMBOL_RE.findall(text):
        cleaned = match.strip()
        if cleaned in file_paths or is_test_target(cleaned):
            continue
        if cleaned.count(".") == 1 and cleaned.lower().split(".", 1)[1] in FILELIKE_EXTENSIONS:
            continue
        if cleaned not in seen:
            seen.add(cleaned)
            symbols.append(cleaned)

    for match in CALLABLE_SYMBOL_RE.findall(text):
        cleaned = match.strip()
        if len(cleaned) < 3 or cleaned.lower() in STOPWORDS:
            continue
        if cleaned not in seen:
            seen.add(cleaned)
            symbols.append(cleaned)
    return symbols[:limit]


def extract_error_signatures(text: str) -> list[str]:
    if not text:
        return []

    signatures: list[str] = []
    seen = set()
    patterns = [
        r"([A-Za-z]+Error:\s+[^\n]+)",
        r"([A-Za-z]+Exception:\s+[^\n]+)",
        r"(Traceback \(most recent call last\):)",
    ]
    for pattern in patterns:
        for match in re.findall(pattern, text):
            signature = compact_text(match, limit=180)
            if signature not in seen:
                seen.add(signature)
                signatures.append(signature)
    return signatures


def classify_observation_status(text: str) -> str:
    lowered = text.lower()
    if any(marker in lowered for marker in ("traceback", "error", "exception", "failed", "syntaxerror", "attributeerror")):
        return "error"
    if any(marker in lowered for marker in ("completed successfully", "result: true", "ok", "passed", "345")):
        return "success"
    return "info"


def infer_action_kind(action: str) -> str:
    stripped = action.strip()
    if not stripped:
        return "message"
    return stripped.split()[0].lower().strip(":")


def _unique_preserve_order(values: list[str]) -> list[str]:
    seen = set()
    ordered: list[str] = []
    for value in values:
        if value in seen:
            continue
        seen.add(value)
        ordered.append(value)
    return ordered


def extract_issue_title(issue_text: str) -> str:
    if not issue_text:
        return "Agent task"

    lines = [line.strip() for line in issue_text.splitlines() if line.strip()]
    issue_section = False
    for line in lines:
        if line.upper() == "ISSUE:":
            issue_section = True
            continue
        if issue_section and not line.startswith(("```", "**", "#")):
            return line

    for line in lines:
        if not line.startswith(("```", "**", "#")):
            return compact_text(line, limit=120)
    return "Agent task"


def extract_issue_text_from_history(history: list[dict[str, Any]] | None) -> str:
    if not history:
        return ""

    candidates: list[str] = []
    for item in history:
        if item.get("role") != "user":
            continue
        content = str(item.get("content", ""))
        if "ISSUE:" in content or "We're currently solving the following issue" in content:
            if "--- DEMONSTRATION ---" in content:
                content = content.split("--- DEMONSTRATION ---", 1)[-1]
            candidates.append(content.strip())
    return candidates[-1] if candidates else ""
