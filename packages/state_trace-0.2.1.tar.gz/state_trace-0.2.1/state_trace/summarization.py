from __future__ import annotations

from collections import defaultdict

import numpy as np

from state_trace.extraction import make_node_id
from state_trace.graph import GraphManager
from state_trace.types import Edge, Node
from state_trace.utils import utc_now


def summarize_cluster(graph_manager: GraphManager, node_ids: list[str]) -> Node | None:
    nodes = [graph_manager.get_node(node_id) for node_id in node_ids]
    cluster = [node for node in nodes if node and not node.metadata.get("compressed")]
    if len(cluster) < 2:
        return None

    summary_content = _build_summary_content(cluster)
    summary_node = Node(
        id=make_node_id(graph_manager, "concept", f"summary {summary_content}"),
        type="concept",
        content=summary_content,
        importance=float(min(1.0, max(np.mean([node.importance for node in cluster]), 0.35))),
        recency=float(max(np.mean([node.recency for node in cluster]), 0.4)),
        access_count=sum(node.access_count for node in cluster),
        capacity_used=max(1.0, round(sum(node.capacity_used for node in cluster) * 0.35, 3)),
        capacity_max=max(node.capacity_max for node in cluster),
        metadata={
            "summary": True,
            "compressed_node_ids": [node.id for node in cluster],
            "cluster_types": sorted({node.type for node in cluster}),
        },
    )
    graph_manager.add_node(summary_node)

    incoming_edges: dict[tuple[str, str], float] = defaultdict(float)
    outgoing_edges: dict[tuple[str, str], float] = defaultdict(float)

    for node in cluster:
        for source, _, _, payload in graph_manager.graph.in_edges(node.id, keys=True, data=True):
            edge: Edge = payload["data"]
            if source in node_ids:
                continue
            incoming_edges[(source, edge.type)] = max(incoming_edges[(source, edge.type)], edge.weight)
        for _, target, _, payload in graph_manager.graph.out_edges(node.id, keys=True, data=True):
            edge: Edge = payload["data"]
            if target in node_ids:
                continue
            outgoing_edges[(target, edge.type)] = max(outgoing_edges[(target, edge.type)], edge.weight)

    for (source, edge_type), weight in incoming_edges.items():
        if graph_manager.has_node(source):
            graph_manager.add_edge(Edge(source=source, target=summary_node.id, type=edge_type, weight=weight))
    for (target, edge_type), weight in outgoing_edges.items():
        if graph_manager.has_node(target):
            graph_manager.add_edge(Edge(source=summary_node.id, target=target, type=edge_type, weight=weight))

    for node in cluster:
        node.metadata["compressed"] = True
        node.metadata["summary_id"] = summary_node.id
        node.metadata["compressed_at"] = utc_now().isoformat()
        node.capacity_used = round(max(0.15, node.capacity_used * 0.15), 3)
        graph_manager.update_node(node)
        graph_manager.add_edge(Edge(source=summary_node.id, target=node.id, type="summarizes", weight=1.0))

    return summary_node


def summarize_resolved_tasks(graph_manager: GraphManager) -> list[Node]:
    summaries: list[Node] = []
    for task_node in graph_manager.all_nodes(include_compressed=False):
        if task_node.type != "task":
            continue
        summary = summarize_resolved_task(graph_manager, task_node.id)
        if summary is not None:
            summaries.append(summary)
    return summaries


def summarize_resolved_task(graph_manager: GraphManager, task_node_id: str) -> Node | None:
    task_node = graph_manager.get_node(task_node_id)
    if task_node is None or not _is_resolved_task(graph_manager, task_node):
        return None

    existing = next(
        (
            node
            for node in graph_manager.all_nodes()
            if node.metadata.get("resolved_summary_task_id") == task_node_id
        ),
        None,
    )
    if existing is not None:
        return existing

    winning_nodes = _winning_path_nodes(graph_manager, task_node)
    if len(winning_nodes) < 2:
        return None

    content = _build_resolved_summary_content(task_node, winning_nodes)
    summary_node = Node(
        id=make_node_id(graph_manager, "concept", f"resolved {task_node.id} {content}"),
        type="concept",
        content=content,
        importance=float(min(1.0, max(np.mean([node.importance for node in winning_nodes]), 0.55))),
        recency=float(max(np.mean([node.recency for node in winning_nodes]), 0.5)),
        access_count=sum(node.access_count for node in winning_nodes),
        capacity_used=max(1.0, round(sum(node.capacity_used for node in winning_nodes) * 0.28, 3)),
        capacity_max=max(node.capacity_max for node in winning_nodes),
        metadata={
            "summary": True,
            "resolved_summary": True,
            "resolved_summary_task_id": task_node.id,
            "session": task_node.metadata.get("session"),
            "goal": task_node.metadata.get("goal"),
            "winning_path_node_ids": [node.id for node in winning_nodes],
            "lifecycle_phase": "resolved_task_snapshot",
        },
    )
    graph_manager.add_node(summary_node)
    _preserve_external_edges(graph_manager, winning_nodes, summary_node)

    for node in winning_nodes:
        graph_manager.add_edge(Edge(source=summary_node.id, target=node.id, type="summarizes", weight=1.0))
        if node.id != task_node.id and node.metadata.get("lifecycle_phase") != "active_working_set":
            node.metadata["lifecycle_phase"] = "resolved_task_snapshot"
            graph_manager.update_node(node)

    return summary_node


def _build_summary_content(nodes: list[Node]) -> str:
    fragments = []
    for node in nodes[:4]:
        fragments.append(f"[{node.type}] {node.content}")
    content = "; ".join(fragments)
    return f"Compressed memory cluster: {content[:280]}"


def _is_resolved_task(graph_manager: GraphManager, task_node: Node) -> bool:
    if task_node.metadata.get("submitted"):
        return True
    incoming_solves = graph_manager.find_edges(target=task_node.id, edge_type="solves")
    return bool(incoming_solves)


def _winning_path_nodes(graph_manager: GraphManager, task_node: Node) -> list[Node]:
    session_id = task_node.metadata.get("session")
    if not session_id:
        return [task_node]

    session_nodes = [node for node in graph_manager.all_nodes() if node.metadata.get("session") == session_id]
    if not session_nodes:
        return [task_node]

    def latest(nodes: list[Node]) -> list[Node]:
        ranked = sorted(
            nodes,
            key=lambda node: (
                node.metadata.get("step_index") is None,
                int(node.metadata.get("step_index", -1)),
                node.updated_at,
            ),
        )
        return ranked[-1:] if ranked else []

    winning: list[Node] = [task_node]
    winning.extend(
        latest(
            [
                node
                for node in session_nodes
                if node.type == "decision" and node.metadata.get("action_kind") in {"edit", "submit"}
            ]
        )
    )
    winning.extend(latest([node for node in session_nodes if node.type == "observation" and node.metadata.get("status") == "success"]))
    winning.extend(
        latest(
            [
                node
                for node in session_nodes
                if node.type == "file" and (node.metadata.get("edited") or graph_manager.find_edges(target=node.id, edge_type="patches_file"))
            ]
        )
    )
    winning.extend(latest([node for node in session_nodes if node.type == "patch_hunk"]))
    winning.extend(latest([node for node in session_nodes if node.type == "test"]))

    unique: list[Node] = []
    seen = set()
    for node in winning:
        if node.id in seen:
            continue
        seen.add(node.id)
        unique.append(node)
    return unique


def _build_resolved_summary_content(task_node: Node, winning_nodes: list[Node]) -> str:
    fragments = [f"[{node.type}] {node.content}" for node in winning_nodes[:5]]
    return f"Resolved task snapshot for {task_node.content}: " + "; ".join(fragment[:140] for fragment in fragments)


def _preserve_external_edges(graph_manager: GraphManager, winning_nodes: list[Node], summary_node: Node) -> None:
    winning_ids = {node.id for node in winning_nodes}
    incoming_edges: dict[tuple[str, str], float] = defaultdict(float)
    outgoing_edges: dict[tuple[str, str], float] = defaultdict(float)

    for node in winning_nodes:
        for source, _, _, payload in graph_manager.graph.in_edges(node.id, keys=True, data=True):
            edge: Edge = payload["data"]
            if source in winning_ids:
                continue
            incoming_edges[(source, edge.type)] = max(incoming_edges[(source, edge.type)], edge.weight)
        for _, target, _, payload in graph_manager.graph.out_edges(node.id, keys=True, data=True):
            edge: Edge = payload["data"]
            if target in winning_ids:
                continue
            outgoing_edges[(target, edge.type)] = max(outgoing_edges[(target, edge.type)], edge.weight)

    for (source, edge_type), weight in incoming_edges.items():
        if graph_manager.has_node(source):
            graph_manager.add_edge(Edge(source=source, target=summary_node.id, type=edge_type, weight=weight))
    for (target, edge_type), weight in outgoing_edges.items():
        if graph_manager.has_node(target):
            graph_manager.add_edge(Edge(source=summary_node.id, target=target, type=edge_type, weight=weight))
