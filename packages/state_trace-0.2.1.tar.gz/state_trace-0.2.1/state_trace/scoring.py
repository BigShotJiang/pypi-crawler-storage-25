from __future__ import annotations

from pydantic import BaseModel, Field

from state_trace.types import Node


class ScoreConfig(BaseModel):
    relevance_weight: float = Field(default=0.3, ge=0.0)
    recency_weight: float = Field(default=0.2, ge=0.0)
    importance_weight: float = Field(default=0.2, ge=0.0)
    causal_proximity_weight: float = Field(default=0.15, ge=0.0)
    state_match_weight: float = Field(default=0.1, ge=0.0)
    staleness_weight: float = Field(default=0.05, ge=0.0)


def score_node(
    node: Node,
    relevance: float,
    causal_proximity: float,
    state_match: float,
    config: ScoreConfig | None = None,
) -> float:
    config = config or ScoreConfig()
    staleness = 1.0 - node.recency
    score = (
        (config.relevance_weight * relevance)
        + (config.recency_weight * node.recency)
        + (config.importance_weight * node.importance)
        + (config.causal_proximity_weight * causal_proximity)
        + (config.state_match_weight * state_match)
        - (config.staleness_weight * staleness)
    )
    return round(score, 6)
