from __future__ import annotations

import json
from pathlib import Path

import networkx as nx

from state_trace.types import Edge, Node


def _node_namespace(node: Node) -> str | None:
    ns = node.metadata.get("namespace")
    return str(ns) if ns is not None else None


class GraphManager:
    def __init__(self) -> None:
        self.graph = nx.MultiDiGraph()

    def has_node(self, node_id: str) -> bool:
        return node_id in self.graph

    def add_node(self, node: Node) -> Node:
        self.graph.add_node(node.id, data=node)
        return node

    def get_node(self, node_id: str) -> Node | None:
        node_data = self.graph.nodes.get(node_id)
        if not node_data:
            return None
        return node_data["data"]

    def update_node(self, node: Node) -> Node:
        if node.id not in self.graph:
            raise KeyError(f"Node not found: {node.id}")
        self.graph.nodes[node.id]["data"] = node
        return node

    def remove_node(self, node_id: str) -> None:
        if node_id in self.graph:
            self.graph.remove_node(node_id)

    def all_nodes(self, include_compressed: bool = True, namespace: str | None = None) -> list[Node]:
        nodes = [payload["data"] for _, payload in self.graph.nodes(data=True)]
        if namespace is not None:
            nodes = [node for node in nodes if _node_namespace(node) in (namespace, None)]
        if include_compressed:
            return nodes
        return [node for node in nodes if not node.metadata.get("compressed")]

    def namespace_view(self, namespace: str | None) -> "GraphManager":
        """Return a new GraphManager containing only nodes (and edges between them)
        whose metadata.namespace matches the given namespace, or have no namespace.
        Used for hard isolation during retrieval when the engine has a namespace set."""
        if namespace is None:
            return self
        view = GraphManager()
        allowed_ids: set[str] = set()
        for node in self.all_nodes(include_compressed=True):
            if _node_namespace(node) in (namespace, None):
                view.add_node(node)
                allowed_ids.add(node.id)
        for edge in self.all_edges():
            if edge.source in allowed_ids and edge.target in allowed_ids:
                view.add_edge(edge)
        return view

    def add_edge(self, edge: Edge) -> Edge:
        if edge.source not in self.graph or edge.target not in self.graph:
            raise KeyError(f"Cannot link missing nodes: {edge.source} -> {edge.target}")

        existing_edges = self.graph.get_edge_data(edge.source, edge.target, default={})
        for key, payload in existing_edges.items():
            existing_edge: Edge = payload["data"]
            if existing_edge.type == edge.type:
                existing_edge.weight = max(existing_edge.weight, edge.weight)
                self.graph[edge.source][edge.target][key]["data"] = existing_edge
                return existing_edge

        edge_key = f"{edge.type}:{len(existing_edges) + 1}"
        self.graph.add_edge(edge.source, edge.target, key=edge_key, data=edge)
        return edge

    def all_edges(self) -> list[Edge]:
        return [payload["data"] for _, _, _, payload in self.graph.edges(keys=True, data=True)]

    def find_edges(
        self,
        source: str | None = None,
        target: str | None = None,
        edge_type: str | None = None,
    ) -> list[Edge]:
        matches: list[Edge] = []
        for current_source, current_target, _, payload in self.graph.edges(keys=True, data=True):
            edge: Edge = payload["data"]
            if source and current_source != source:
                continue
            if target and current_target != target:
                continue
            if edge_type and edge.type != edge_type:
                continue
            matches.append(edge)
        return matches

    def get_neighbors(
        self,
        node_id: str,
        direction: str = "both",
        edge_types: set[str] | None = None,
    ) -> list[tuple[Node, Edge]]:
        if node_id not in self.graph:
            return []

        neighbors: list[tuple[Node, Edge]] = []

        if direction in {"out", "both"}:
            for _, target, _, payload in self.graph.out_edges(node_id, keys=True, data=True):
                edge: Edge = payload["data"]
                if edge_types and edge.type not in edge_types:
                    continue
                target_node = self.get_node(target)
                if target_node:
                    neighbors.append((target_node, edge))

        if direction in {"in", "both"}:
            for source, _, _, payload in self.graph.in_edges(node_id, keys=True, data=True):
                edge: Edge = payload["data"]
                if edge_types and edge.type not in edge_types:
                    continue
                source_node = self.get_node(source)
                if source_node:
                    neighbors.append((source_node, edge))

        return neighbors

    def get_subgraph(self, node_ids: list[str]) -> dict[str, list[dict]]:
        subgraph = self.graph.subgraph(node_ids).copy()
        nodes = [subgraph.nodes[node_id]["data"].model_dump(mode="json") for node_id in subgraph.nodes]
        edges = [payload["data"].model_dump(mode="json") for _, _, _, payload in subgraph.edges(keys=True, data=True)]
        return {"nodes": nodes, "edges": edges}

    def to_dict(self) -> dict[str, list[dict]]:
        return {
            "nodes": [node.model_dump(mode="json") for node in self.all_nodes()],
            "edges": [edge.model_dump(mode="json") for edge in self.all_edges()],
        }

    @classmethod
    def from_dict(cls, payload: dict) -> "GraphManager":
        manager = cls()
        for node_data in payload.get("nodes", []):
            manager.add_node(Node.model_validate(node_data))
        for edge_data in payload.get("edges", []):
            edge = Edge.model_validate(edge_data)
            if manager.has_node(edge.source) and manager.has_node(edge.target):
                manager.add_edge(edge)
        return manager

    def save_json(self, path: str | Path) -> None:
        target = Path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(json.dumps(self.to_dict(), indent=2), encoding="utf-8")

    @classmethod
    def load_json(cls, path: str | Path) -> "GraphManager":
        source = Path(path)
        if not source.exists():
            return cls()
        return cls.from_dict(json.loads(source.read_text(encoding="utf-8")))
