from __future__ import annotations

import re
import sqlite3
from pathlib import Path
from typing import Iterable

from state_trace.graph import GraphManager
from state_trace.types import Edge, Node


SQLITE_EXTENSIONS = {".db", ".sqlite", ".sqlite3"}


SCHEMA = """
CREATE TABLE IF NOT EXISTS nodes (
    id TEXT PRIMARY KEY,
    payload TEXT NOT NULL,
    type TEXT NOT NULL,
    namespace TEXT,
    content TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_nodes_type ON nodes(type);
CREATE INDEX IF NOT EXISTS idx_nodes_namespace ON nodes(namespace);

CREATE TABLE IF NOT EXISTS edges (
    source TEXT NOT NULL,
    target TEXT NOT NULL,
    type TEXT NOT NULL,
    payload TEXT NOT NULL,
    PRIMARY KEY (source, target, type)
);
CREATE INDEX IF NOT EXISTS idx_edges_source ON edges(source);
CREATE INDEX IF NOT EXISTS idx_edges_target ON edges(target);

CREATE VIRTUAL TABLE IF NOT EXISTS node_fts USING fts5(
    id UNINDEXED,
    type UNINDEXED,
    namespace UNINDEXED,
    content,
    tokenize='porter'
);
"""


FTS_SAFE = re.compile(r"[A-Za-z0-9_]+")


def is_sqlite_path(path: str | Path | None) -> bool:
    if path is None:
        return False
    return Path(path).suffix.lower() in SQLITE_EXTENSIONS


def _connect(path: str | Path) -> sqlite3.Connection:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(target), timeout=30.0, isolation_level=None)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.executescript(SCHEMA)
    return conn


def _fts_document(node: Node) -> str:
    parts: list[str] = [node.content]
    for key in ("path", "issue_title", "raw_action", "raw_observation", "raw_thought"):
        value = node.metadata.get(key)
        if value:
            parts.append(str(value))
    for key in ("files", "error_signatures", "keywords"):
        value = node.metadata.get(key)
        if isinstance(value, (list, tuple)):
            parts.append(" ".join(str(item) for item in value))
    return " ".join(parts)


def _namespace_of(node: Node) -> str | None:
    ns = node.metadata.get("namespace")
    return str(ns) if ns is not None else None


def _upsert_node(conn: sqlite3.Connection, node: Node) -> None:
    conn.execute(
        """
        INSERT INTO nodes(id, payload, type, namespace, content, updated_at)
        VALUES (?, ?, ?, ?, ?, ?)
        ON CONFLICT(id) DO UPDATE SET
          payload=excluded.payload,
          type=excluded.type,
          namespace=excluded.namespace,
          content=excluded.content,
          updated_at=excluded.updated_at
        """,
        (
            node.id,
            node.model_dump_json(),
            node.type,
            _namespace_of(node),
            node.content,
            node.updated_at.isoformat(),
        ),
    )
    conn.execute("DELETE FROM node_fts WHERE id = ?", (node.id,))
    conn.execute(
        "INSERT INTO node_fts(id, type, namespace, content) VALUES (?, ?, ?, ?)",
        (node.id, node.type, _namespace_of(node) or "", _fts_document(node)),
    )


def _upsert_edge(conn: sqlite3.Connection, edge: Edge) -> None:
    conn.execute(
        """
        INSERT INTO edges(source, target, type, payload)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(source, target, type) DO UPDATE SET payload=excluded.payload
        """,
        (edge.source, edge.target, edge.type, edge.model_dump_json()),
    )


def save_graph(graph_manager: GraphManager, path: str | Path) -> None:
    conn = _connect(path)
    try:
        conn.execute("BEGIN")
        known_node_ids: set[str] = set()
        known_edge_keys: set[tuple[str, str, str]] = set()
        for node in graph_manager.all_nodes():
            _upsert_node(conn, node)
            known_node_ids.add(node.id)
        for edge in graph_manager.all_edges():
            _upsert_edge(conn, edge)
            known_edge_keys.add((edge.source, edge.target, edge.type))

        existing_node_ids = {row[0] for row in conn.execute("SELECT id FROM nodes")}
        stale_nodes = existing_node_ids - known_node_ids
        for node_id in stale_nodes:
            conn.execute("DELETE FROM nodes WHERE id = ?", (node_id,))
            conn.execute("DELETE FROM node_fts WHERE id = ?", (node_id,))

        existing_edge_keys = {
            (row[0], row[1], row[2]) for row in conn.execute("SELECT source, target, type FROM edges")
        }
        stale_edges = existing_edge_keys - known_edge_keys
        for source, target, edge_type in stale_edges:
            conn.execute(
                "DELETE FROM edges WHERE source=? AND target=? AND type=?",
                (source, target, edge_type),
            )
        conn.execute("COMMIT")
    except Exception:
        conn.execute("ROLLBACK")
        raise
    finally:
        conn.close()


def load_graph(path: str | Path) -> GraphManager:
    target = Path(path)
    if not target.exists():
        return GraphManager()
    conn = _connect(path)
    try:
        manager = GraphManager()
        for row in conn.execute("SELECT payload FROM nodes"):
            manager.add_node(Node.model_validate_json(row[0]))
        for row in conn.execute("SELECT payload FROM edges"):
            edge = Edge.model_validate_json(row[0])
            if manager.has_node(edge.source) and manager.has_node(edge.target):
                manager.add_edge(edge)
        return manager
    finally:
        conn.close()


def _sanitize_fts_terms(query: str) -> list[str]:
    return [match.group(0) for match in FTS_SAFE.finditer(query) if len(match.group(0)) >= 2]


def fts_seed_ids(
    path: str | Path,
    query: str,
    namespace: str | None = None,
    limit: int = 32,
) -> list[tuple[str, float]]:
    target = Path(path)
    if not target.exists():
        return []
    terms = _sanitize_fts_terms(query)
    if not terms:
        return []
    fts_query = " OR ".join(f'"{term}"' for term in terms)
    conn = _connect(path)
    try:
        if namespace is not None:
            cursor = conn.execute(
                """
                SELECT id, bm25(node_fts) AS rank
                FROM node_fts
                WHERE node_fts MATCH ? AND namespace = ?
                ORDER BY rank LIMIT ?
                """,
                (fts_query, namespace, limit),
            )
        else:
            cursor = conn.execute(
                """
                SELECT id, bm25(node_fts) AS rank
                FROM node_fts
                WHERE node_fts MATCH ?
                ORDER BY rank LIMIT ?
                """,
                (fts_query, limit),
            )
        rows = cursor.fetchall()
    finally:
        conn.close()
    if not rows:
        return []
    ranks = [row[1] for row in rows]
    worst = max(ranks)
    if worst <= 0:
        return [(row[0], 1.0) for row in rows]
    return [(row[0], float(max(0.0, 1.0 - (row[1] / (worst + 1e-6))))) for row in rows]


class SQLiteBackend:
    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)

    def save(self, graph_manager: GraphManager) -> None:
        save_graph(graph_manager, self.path)

    def load(self) -> GraphManager:
        return load_graph(self.path)

    def fts_seed_ids(self, query: str, namespace: str | None = None, limit: int = 32) -> list[tuple[str, float]]:
        return fts_seed_ids(self.path, query, namespace=namespace, limit=limit)

    def delete_namespace(self, namespace: str) -> int:
        conn = _connect(self.path)
        try:
            conn.execute("BEGIN")
            ids = [row[0] for row in conn.execute("SELECT id FROM nodes WHERE namespace = ?", (namespace,))]
            for node_id in ids:
                conn.execute("DELETE FROM nodes WHERE id = ?", (node_id,))
                conn.execute("DELETE FROM node_fts WHERE id = ?", (node_id,))
                conn.execute("DELETE FROM edges WHERE source = ? OR target = ?", (node_id, node_id))
            conn.execute("COMMIT")
            return len(ids)
        except Exception:
            conn.execute("ROLLBACK")
            raise
        finally:
            conn.close()


def ids_intersection(rows: Iterable[str], selection: set[str]) -> list[str]:
    return [row for row in rows if row in selection]
