from __future__ import annotations

from state_trace.adapters import StateTraceLangGraphMemory, StateTraceLlamaIndexMemory
from state_trace.memory import MemoryEngine


def test_langgraph_adapter_round_trips_messages_into_memory() -> None:
    engine = MemoryEngine(capacity_limit=48.0, namespace="langgraph-repo")
    memory = StateTraceLangGraphMemory(engine=engine, default_session="lg-session", default_goal="restore login")
    memory.add_messages(
        [
            {"role": "user", "content": "Login is broken. Find the file and fix it."},
            {"role": "assistant", "content": 'edit "src/auth.ts"'},
            {"role": "tool", "content": "tests/test_auth.py::test_refresh_retry PASSED"},
        ]
    )
    brief = memory.retrieve_brief("what file should I patch?")
    assert brief["patch_file"] == "src/auth.ts"
    assert brief["namespace"] == "langgraph-repo"


def test_llama_index_adapter_returns_rendered_brief() -> None:
    engine = MemoryEngine(capacity_limit=48.0, namespace="llama-repo")
    memory = StateTraceLlamaIndexMemory(engine=engine, session_id="llama-session", goal="restore login")
    memory.put_messages(
        [
            {"role": "user", "content": "Login returns 401 after refresh. Please fix src/auth.ts."},
            {"role": "assistant", "content": 'edit "src/auth.ts"'},
            {"role": "tool", "content": "tests/test_auth.py::test_refresh_retry PASSED"},
        ]
    )
    rendered = memory.get("which file should I patch?")
    assert "src/auth.ts" in rendered
    assert rendered.startswith("QUERY:")
