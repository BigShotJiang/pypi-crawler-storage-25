from __future__ import annotations

from state_trace.extraction_llm import HeuristicTranscriptExtractor, extract_agent_log_from_text
from state_trace.memory import MemoryEngine


ROLE_TAGGED_TRANSCRIPT = """
Issue: Login returns 401 after refresh token exchange.

Step 1:
Thought: inspect the refresh handler in src/auth.ts
Action: open "src/auth.ts"
Observation: file opened; auth.ts line 42 still strips Authorization header before retry.

Step 2:
Action: edit "src/auth.ts"
Observation: applied patch to preserve Authorization header on retry.

Step 3:
Action: pytest tests/test_auth.py::test_refresh_retry
Observation: tests/test_auth.py::test_refresh_retry PASSED
""".strip()


def test_heuristic_extractor_builds_agent_log_shape() -> None:
    log = extract_agent_log_from_text(ROLE_TAGGED_TRANSCRIPT, {"session": "auth-debug"})
    assert log["session_id"] == "auth-debug"
    assert log["issue_title"].startswith("Login returns 401")
    assert len(log["steps"]) >= 3
    actions = [step["action"] for step in log["steps"]]
    assert any("open" in action for action in actions)
    assert any("edit" in action for action in actions)
    files_touched = {file_path for step in log["steps"] for file_path in step["files"]}
    assert "src/auth.ts" in files_touched


def test_ingest_text_populates_graph_and_retrieves_artifact() -> None:
    engine = MemoryEngine(capacity_limit=96.0, namespace="auth-repo")
    engine.ingest_text(ROLE_TAGGED_TRANSCRIPT, {"session": "auth-debug", "goal": "restore login"})

    brief = engine.retrieve_brief(
        "which file should I patch?",
        {"session": "auth-debug", "goal": "restore login"},
        mode="small_model",
    )
    assert brief["patch_file"] == "src/auth.ts"
    assert brief["namespace"] == "auth-repo"


def test_openai_extractor_falls_back_without_credentials() -> None:
    from state_trace.extraction_llm import OpenAITranscriptExtractor

    extractor = OpenAITranscriptExtractor(client=None)
    log = extractor.extract(ROLE_TAGGED_TRANSCRIPT, {"session": "fallback"})
    assert log["session_id"] == "fallback"
    assert log["steps"], "fallback must produce parsed steps"
