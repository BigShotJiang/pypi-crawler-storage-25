from datetime import timedelta

from state_trace.capacity import CapacityConfig
from state_trace.memory import MemoryEngine
from state_trace.utils import utc_now


def test_capacity_decay_and_compression() -> None:
    engine = MemoryEngine(capacity_limit=8.0)

    first = engine.store(
        "Login still returns 401 after refresh token rotation",
        {"type": "observation", "session": "auth-debug", "importance": 0.35},
    )
    second = engine.store(
        "Cookie replay leaves the session in a stale state",
        {"type": "observation", "session": "auth-debug", "related_to": [first.id], "importance": 0.3},
    )
    third = engine.store(
        "The retry loop reuses the expired authorization header",
        {"type": "observation", "session": "auth-debug", "related_to": [second.id], "importance": 0.3},
    )

    old_time = utc_now() - timedelta(days=10)
    for node_id in (first.id, second.id, third.id):
        node = engine.get_node(node_id)
        assert node is not None
        node.updated_at = old_time
        engine.graph_manager.update_node(node)

    engine.capacity_limit = 4.0
    result = engine.step(reference_time=utc_now())

    updated_first = engine.get_node(first.id)
    if updated_first is not None:
        assert updated_first.recency < 0.8
        assert updated_first.importance < 0.35

    assert any(node.metadata.get("compressed") or node.metadata.get("summary") for node in engine.graph_manager.all_nodes())


def test_capacity_assigns_lifecycle_phases_and_builds_resolved_snapshot() -> None:
    engine = MemoryEngine(capacity_limit=6.0)
    engine.store_agent_log(
        {
            "format": "agent_log",
            "source": "agent_log",
            "session_id": "resolved-auth",
            "repo": "example/auth-service",
            "issue_title": "Login still broken after refresh",
            "issue_text": "Login still broken after refresh token exchange",
            "goal": "restore login",
            "steps": [
                {
                    "index": 0,
                    "action": 'open "src/auth.ts"',
                    "thought": "Inspect auth flow",
                    "observation": "AttributeError: login still fails with a 401 in src/auth.ts",
                    "files": ["src/auth.ts"],
                    "action_kind": "open",
                    "status": "error",
                    "error_signatures": ["AttributeError: login still fails with a 401 in src/auth.ts"],
                },
                {
                    "index": 1,
                    "action": 'edit "src/auth.ts"',
                    "thought": "Patch refresh retry",
                    "observation": "Updated src/auth.ts to preserve the Authorization header",
                    "files": ["src/auth.ts"],
                    "action_kind": "edit",
                    "status": "info",
                    "error_signatures": [],
                },
                {
                    "index": 2,
                    "action": "pytest tests/test_auth.py::test_refresh_retry",
                    "thought": "Verify the fix",
                    "observation": "tests/test_auth.py::test_refresh_retry PASSED",
                    "files": ["src/auth.ts", "tests/test_auth.py::test_refresh_retry"],
                    "action_kind": "pytest",
                    "status": "success",
                    "error_signatures": [],
                },
            ],
            "submission_diff": "diff --git a/src/auth.ts b/src/auth.ts\n+++ b/src/auth.ts\n@@\n- old\n+ new\n",
            "submission_files": ["src/auth.ts"],
        }
    )

    result = engine.step(reference_time=utc_now())

    phases = {node.metadata.get("lifecycle_phase") for node in engine.graph_manager.all_nodes()}
    assert "active_working_set" in phases
    assert "resolved_task_snapshot" in phases
    assert any(node.metadata.get("resolved_summary") for node in engine.graph_manager.all_nodes())
    assert result["summary_nodes"]


def test_capacity_can_disable_lifecycle_snapshots() -> None:
    engine = MemoryEngine(capacity_limit=6.0, capacity_config=CapacityConfig(enable_lifecycle_phases=False, enable_resolved_snapshots=False))
    engine.store(
        "Fix auth retry",
        {"type": "task", "session": "auth-disable", "goal": "restore login", "importance": 0.9},
    )
    engine.store(
        "Updated auth.ts to preserve header",
        {"type": "decision", "session": "auth-disable", "goal": "restore login", "importance": 0.8},
    )
    engine.store(
        "tests/test_auth.py::test_refresh_retry PASSED",
        {"type": "observation", "session": "auth-disable", "goal": "restore login", "status": "success", "importance": 0.7},
    )

    result = engine.step(reference_time=utc_now())

    assert not any(node.metadata.get("lifecycle_phase") for node in engine.graph_manager.all_nodes())
    assert not any(node.metadata.get("resolved_summary") for node in engine.graph_manager.all_nodes())
    assert not result["summary_nodes"]


def test_capacity_enforces_hard_limit() -> None:
    engine = MemoryEngine(capacity_limit=2.0)
    for index in range(8):
        engine.store(
            f"Noise observation {index}",
            {"type": "observation", "session": "hard-cap", "importance": 0.2},
        )

    result = engine.step(reference_time=utc_now())

    assert result["capacity_used"] <= 2.0
