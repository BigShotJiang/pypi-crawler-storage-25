from __future__ import annotations

import math
import re
from collections import Counter
from pathlib import Path

from state_trace.memory import MemoryEngine
from state_trace.utils import load_json_path


FIXTURE_DIR = Path(__file__).resolve().parent.parent / "examples" / "data" / "agent_logs"
STOPWORDS = {
    "a",
    "an",
    "and",
    "as",
    "at",
    "be",
    "by",
    "for",
    "how",
    "in",
    "is",
    "it",
    "of",
    "on",
    "or",
    "still",
    "the",
    "to",
    "was",
    "what",
    "where",
    "which",
    "why",
}


def test_real_world_agent_log_retrieval_surfaces_patch_files() -> None:
    cases = [
        (
            "marshmallow__marshmallow-1867.json",
            "Which file fixed the 344 vs 345 milliseconds bug?",
            {"session": "swe-agent-marshmallow-1867", "repo": "marshmallow-code/marshmallow"},
            "src/marshmallow/fields.py",
        ),
        (
            "pydicom__pydicom-1458.json",
            "Why did float pixel data fail without Pixel Representation, and where did the agent patch it?",
            {"session": "swe-agent-pydicom-1458", "repo": "pydicom/pydicom"},
            "pydicom/pixel_data_handlers/numpy_handler.py",
        ),
    ]

    for fixture_name, query, context, expected_file in cases:
        engine = MemoryEngine(capacity_limit=256.0)
        engine.store_agent_log(load_json_path(FIXTURE_DIR / fixture_name))
        result = engine.retrieve(query, context, limit=5, depth_limit=3)

        top_node = result["nodes"][0]
        top_text = f"{top_node['content']} {' '.join(top_node['metadata'].get('files', []))}"

        assert top_node["type"] == "file"
        assert expected_file in top_text


def test_graph_retrieval_beats_flat_vector_rank1_on_real_agent_logs() -> None:
    fixture_name = "marshmallow__marshmallow-1867.json"
    query = "Which file fixed the 344 vs 345 milliseconds bug?"
    context = {"session": "swe-agent-marshmallow-1867", "repo": "marshmallow-code/marshmallow"}
    expected_file = "src/marshmallow/fields.py"
    log = load_json_path(FIXTURE_DIR / fixture_name)

    engine = MemoryEngine(capacity_limit=256.0)
    engine.store_agent_log(log)
    graph_result = engine.retrieve(query, context, limit=5, depth_limit=3)

    baseline = _FlatVectorBaseline()
    baseline.store_agent_log(log)
    vector_result = baseline.retrieve(query, context, limit=5)

    graph_top = graph_result["nodes"][0]
    vector_top = vector_result[0]

    assert graph_top["type"] == "file"
    assert expected_file in f"{graph_top['content']} {' '.join(graph_top['metadata'].get('files', []))}"
    assert vector_top["type"] != "file"


class _FlatVectorBaseline:
    def __init__(self) -> None:
        self.chunks: list[dict] = []

    def store_agent_log(self, log: dict) -> None:
        self.chunks = [
            {"id": f"{log['session_id']}:issue", "type": "task", "text": f"{log['issue_title']} {log.get('issue_text', '')}"}
        ]
        for step in log["steps"]:
            self.chunks.append(
                {
                    "id": f"{log['session_id']}:step:{step['index']}",
                    "type": "chunk",
                    "text": " ".join(
                        part
                        for part in [
                            step.get("thought", ""),
                            step.get("action", ""),
                            step.get("observation", ""),
                            " ".join(step.get("files", [])),
                        ]
                        if part
                    ),
                }
            )

    def retrieve(self, query: str, context: dict | None = None, limit: int = 5) -> list[dict]:
        query_text = f"{query} {' '.join(str(value) for value in (context or {}).values())}".strip()
        query_vector = _vectorize(query_text)
        ranked = sorted(
            (
                {
                    "id": chunk["id"],
                    "type": chunk["type"],
                    "text": chunk["text"],
                    "score": _cosine_similarity(query_vector, _vectorize(chunk["text"])),
                }
                for chunk in self.chunks
            ),
            key=lambda item: item["score"],
            reverse=True,
        )
        return ranked[:limit]


def _vectorize(text: str) -> Counter[str]:
    tokens = []
    for raw in re.findall(r"[A-Za-z0-9_./:-]+", text.lower()):
        if raw not in STOPWORDS:
            tokens.append(raw)
        for subtoken in re.split(r"[_./:-]+", raw):
            if len(subtoken) > 1 and subtoken not in STOPWORDS:
                tokens.append(subtoken)
    return Counter(tokens)


def _cosine_similarity(left: Counter[str], right: Counter[str]) -> float:
    if not left or not right:
        return 0.0
    keys = set(left) | set(right)
    numerator = sum(left[key] * right[key] for key in keys)
    left_norm = math.sqrt(sum(value * value for value in left.values()))
    right_norm = math.sqrt(sum(value * value for value in right.values()))
    if not left_norm or not right_norm:
        return 0.0
    return numerator / (left_norm * right_norm)
