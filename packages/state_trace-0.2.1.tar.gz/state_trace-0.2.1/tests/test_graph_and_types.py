from state_trace import GraphManager, Node
from state_trace.types import Edge
from state_trace.utils import estimate_capacity, extract_file_paths


def test_node_creation_and_storage() -> None:
    node = Node(
        id="task:fix-login",
        type="task",
        content="Fix the login regression",
        importance=0.9,
        capacity_used=estimate_capacity("Fix the login regression"),
        capacity_max=8.0,
    )
    graph = GraphManager()
    graph.add_node(node)

    stored = graph.get_node("task:fix-login")
    assert stored is not None
    assert stored.type == "task"
    assert stored.importance == 0.9


def test_edge_linking_between_nodes() -> None:
    graph = GraphManager()
    task = Node(
        id="task:fix-login",
        type="task",
        content="Fix the login regression",
        importance=0.9,
        capacity_used=1.0,
        capacity_max=8.0,
    )
    file_node = Node(
        id="file:src-auth-ts",
        type="file",
        content="src/auth.ts",
        importance=0.7,
        capacity_used=1.0,
        capacity_max=8.0,
    )
    graph.add_node(task)
    graph.add_node(file_node)

    edge = graph.add_edge(Edge(source=task.id, target=file_node.id, type="related_to", weight=0.8))

    assert edge.type == "related_to"
    assert graph.find_edges(source=task.id, target=file_node.id, edge_type="related_to")


def test_extract_file_paths_handles_agent_log_tokens() -> None:
    text = """
    find_file "missing_colon.py"
    Opened /workspace/project/tests/missing_colon.py:4
    diff --git a/src/auth.ts b/src/auth.ts
    precision.lower copy.deepcopy
    """

    paths = extract_file_paths(text)

    assert "missing_colon.py" in paths
    assert "project/tests/missing_colon.py" in paths
    assert "src/auth.ts" in paths
    assert "src/marshmallow/fields.py" in extract_file_paths("/marshmallow-code__marshmallow/src/marshmallow/fields.py")
    assert "tests/missing_colon.py" in extract_file_paths("/SWE-agent__test-repo/tests/missing_colon.py")
    assert "precision.lower" not in paths
    assert "copy.deepcopy" not in paths
