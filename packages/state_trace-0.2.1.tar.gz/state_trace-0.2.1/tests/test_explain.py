from __future__ import annotations

from state_trace.memory import MemoryEngine


def test_explain_returns_score_breakdown() -> None:
    engine = MemoryEngine(capacity_limit=24.0)
    task = engine.store(
        "Fix login by tracing the refresh token path",
        {"type": "task", "session": "auth-debug", "goal": "restore login", "file": "auth.ts"},
    )
    engine.store(
        "Login still returns 401 after refresh token exchange",
        {
            "type": "observation",
            "session": "auth-debug",
            "goal": "restore login",
            "file": "auth.ts",
            "blocks": [task.id],
        },
    )

    result = engine.retrieve(
        "why is login still broken?",
        {"session": "auth-debug", "goal": "restore login"},
        explain=True,
    )
    explanations = result["explanations"]
    assert explanations, "explain=True must return explanations"
    first = explanations[0]
    assert "breakdown" in first
    assert "top_signals" in first
    assert {"relevance", "state_match", "causal_proximity"}.issubset(first["breakdown"].keys())

    brief = engine.retrieve_brief(
        "why is login still broken?",
        {"session": "auth-debug", "goal": "restore login"},
        explain=True,
    )
    assert brief["explanations"], "brief explain=True must surface explanations"


def test_explain_not_included_by_default() -> None:
    engine = MemoryEngine(capacity_limit=24.0)
    engine.store("note", {"type": "observation"})
    result = engine.retrieve("note")
    assert "explanations" not in result
