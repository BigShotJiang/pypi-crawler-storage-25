from __future__ import annotations

import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
EXAMPLES = REPO_ROOT / "examples"
if str(EXAMPLES) not in sys.path:
    sys.path.insert(0, str(EXAMPLES))


def test_dry_run_harness_scores_state_trace_above_no_memory(capsys) -> None:
    import swebench_verified_eval as harness

    harness.main(["--dry-run", "--backends", "no_memory", "state_trace"])
    captured = capsys.readouterr().out
    assert "dry_run=True" in captured
    assert "state_trace" in captured
    rows = [line for line in captured.splitlines() if line.startswith(("state_trace", "no_memory"))]
    assert len(rows) == 2
    state_trace_a1 = float(rows[0].split()[2]) if rows[0].startswith("state_trace") else float(rows[1].split()[2])
    no_memory_a1 = float(rows[1].split()[2]) if rows[0].startswith("state_trace") else float(rows[0].split()[2])
    assert state_trace_a1 >= no_memory_a1
    assert state_trace_a1 >= 0.66, "state_trace should localize at least 2/3 of the synthetic instances"
