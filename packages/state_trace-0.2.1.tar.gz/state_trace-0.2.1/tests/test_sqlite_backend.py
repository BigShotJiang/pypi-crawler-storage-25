from __future__ import annotations

from pathlib import Path

from state_trace.memory import MemoryEngine
from state_trace.storage import SQLiteBackend, fts_seed_ids, is_sqlite_path


def test_sqlite_path_detection() -> None:
    assert is_sqlite_path("memory.db")
    assert is_sqlite_path("memory.sqlite3")
    assert not is_sqlite_path("memory.json")
    assert not is_sqlite_path(None)


def test_engine_persists_through_sqlite_backend(tmp_path: Path) -> None:
    storage = tmp_path / "engine.db"
    first = MemoryEngine(capacity_limit=32.0, storage_path=storage)
    first.store("auth.ts", {"type": "file", "importance": 0.7})
    task = first.store(
        "Fix login by tracing the refresh token path",
        {"type": "task", "session": "auth-debug", "goal": "restore login", "file": "auth.ts"},
    )
    first.store(
        "Login still returns 401 after refresh token exchange",
        {
            "type": "observation",
            "session": "auth-debug",
            "goal": "restore login",
            "file": "auth.ts",
            "blocks": [task.id],
        },
    )

    second = MemoryEngine(capacity_limit=32.0, storage_path=storage)
    reopened_ids = {node.id for node in second.graph_manager.all_nodes()}
    assert task.id in reopened_ids

    seeds = fts_seed_ids(storage, "refresh token")
    seed_ids = {seed_id for seed_id, _ in seeds}
    assert seed_ids, "FTS should return at least one candidate for refresh token query"


def test_sqlite_backend_concurrent_reader_sees_writes(tmp_path: Path) -> None:
    storage = tmp_path / "shared.db"
    writer = MemoryEngine(capacity_limit=24.0, storage_path=storage)
    writer.store("first note", {"type": "observation"})

    reader_backend = SQLiteBackend(storage)
    snapshot = reader_backend.load()
    assert any(node.content == "first note" for node in snapshot.all_nodes())

    writer.store("second note", {"type": "observation"})
    snapshot_after = reader_backend.load()
    contents = {node.content for node in snapshot_after.all_nodes()}
    assert {"first note", "second note"}.issubset(contents)


def test_sqlite_backend_prunes_deleted_nodes(tmp_path: Path) -> None:
    storage = tmp_path / "prune.db"
    engine = MemoryEngine(capacity_limit=24.0, storage_path=storage)
    scratch = engine.store("scratch note", {"type": "observation"})
    engine.graph_manager.remove_node(scratch.id)
    engine._save()  # type: ignore[attr-defined]

    reopen = MemoryEngine(capacity_limit=24.0, storage_path=storage)
    ids = {node.id for node in reopen.graph_manager.all_nodes()}
    assert scratch.id not in ids
