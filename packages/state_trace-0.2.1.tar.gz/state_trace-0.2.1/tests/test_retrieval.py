from state_trace.memory import MemoryEngine


def test_retrieval_returns_causal_debug_context() -> None:
    engine = MemoryEngine(capacity_limit=24.0)

    file_node = engine.store("auth.ts", {"type": "file", "importance": 0.7})
    task_node = engine.store(
        "Fix login by tracing the refresh token path",
        {"type": "task", "session": "auth-debug", "goal": "restore login", "file": "auth.ts", "importance": 0.92},
    )
    observation_node = engine.store(
        "Login still returns 401 after refresh token exchange",
        {
            "type": "observation",
            "session": "auth-debug",
            "goal": "restore login",
            "file": "auth.ts",
            "blocks": [task_node.id],
            "importance": 0.88,
        },
    )
    decision_node = engine.store(
        "Authorization header is dropped before the retry request reaches auth.ts",
        {
            "type": "decision",
            "session": "auth-debug",
            "goal": "restore login",
            "related_to": [task_node.id, observation_node.id],
            "file": "auth.ts",
            "importance": 0.91,
        },
    )
    engine.link(task_node.id, file_node.id, edge_type="related_to", weight=0.9)
    engine.link(decision_node.id, file_node.id, edge_type="related_to", weight=0.9)

    result = engine.retrieve("Why is login still broken?", {"session": "auth-debug", "goal": "restore login"}, limit=5, depth_limit=3)

    node_types = {node["type"] for node in result["nodes"]}
    node_ids = [node["id"] for node in result["nodes"]]

    assert "observation" in node_types
    assert "task" in node_types
    assert "file" in node_types
    assert observation_node.id in node_ids
    assert result["chains"]
    assert "State-aware scoring" in result["reasoning"]
