from fastapi.testclient import TestClient

from state_trace.api import create_app
from state_trace.memory import MemoryEngine


def test_api_store_and_retrieve() -> None:
    app = create_app(MemoryEngine(capacity_limit=20.0))
    client = TestClient(app)

    store_response = client.post(
        "/store",
        json={"text": "auth.ts", "context": {"type": "file", "importance": 0.7}},
    )
    assert store_response.status_code == 200

    client.post(
        "/store",
        json={
            "text": "Login still returns 401 after refresh",
            "context": {"type": "observation", "session": "auth-debug", "goal": "restore login", "file": "auth.ts"},
        },
    )
    retrieve_response = client.post(
        "/retrieve",
        json={"query": "Why is login still broken?", "context": {"session": "auth-debug", "goal": "restore login"}},
    )

    assert retrieve_response.status_code == 200
    payload = retrieve_response.json()
    assert "summary" in payload
    assert payload["nodes"]


def test_api_retrieve_brief() -> None:
    app = create_app(MemoryEngine(capacity_limit=64.0))
    client = TestClient(app)

    client.post(
        "/store",
        json={
            "text": "Fix retry handling in src/auth.ts",
            "context": {"type": "decision", "session": "auth-debug", "goal": "restore login", "files": ["src/auth.ts"]},
        },
    )
    client.post(
        "/store",
        json={
            "text": "pytest tests/test_auth.py::test_refresh_retry",
            "context": {"type": "command", "session": "auth-debug", "goal": "restore login", "test_target": "tests/test_auth.py::test_refresh_retry"},
        },
    )

    response = client.post(
        "/retrieve_brief",
        json={
            "query": "Which file should I patch and what test should I rerun?",
            "context": {"session": "auth-debug", "goal": "restore login"},
            "mode": "small_model",
        },
    )

    assert response.status_code == 200
    payload = response.json()
    assert "target_files" in payload
    assert "recommended_actions" in payload
    assert payload["token_estimate"] <= payload["token_budget"]
