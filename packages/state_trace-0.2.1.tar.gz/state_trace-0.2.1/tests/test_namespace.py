from __future__ import annotations

from state_trace.memory import MemoryEngine


def test_namespace_isolates_retrieval() -> None:
    engine_a = MemoryEngine(capacity_limit=48.0, namespace="repo-a")
    engine_a.store(
        "Login still returns 401 after refresh token exchange",
        {"type": "observation", "session": "auth", "file": "auth.ts"},
    )

    engine_b = MemoryEngine(
        capacity_limit=48.0,
        namespace="repo-b",
    )
    engine_b.graph_manager = engine_a.graph_manager  # share underlying graph
    engine_b.store(
        "Build fails on Windows due to path separator",
        {"type": "observation", "session": "build", "file": "builder.py"},
    )

    result_a = engine_a.retrieve("what broke login?", {"session": "auth"})
    contents_a = {node["content"] for node in result_a["nodes"]}
    assert any("401" in content for content in contents_a)
    assert not any("Windows" in content for content in contents_a)
    assert result_a["namespace"] == "repo-a"

    result_b = engine_b.retrieve("what broke the build?", {"session": "build"})
    contents_b = {node["content"] for node in result_b["nodes"]}
    assert any("Windows" in content for content in contents_b)
    assert not any("401" in content for content in contents_b)


def test_namespace_opt_out_returns_cross_namespace_results() -> None:
    engine = MemoryEngine(capacity_limit=48.0, namespace="repo-a")
    engine.store(
        "Login still returns 401 after refresh token exchange",
        {"type": "observation", "session": "auth", "file": "auth.ts", "namespace": "repo-a"},
    )
    engine.store(
        "Build fails on Windows due to path separator",
        {"type": "observation", "session": "build", "file": "builder.py", "namespace": "repo-b"},
    )

    scoped = engine.retrieve("what broke?", {})
    scoped_contents = {node["content"] for node in scoped["nodes"]}
    assert any("401" in content for content in scoped_contents)
    assert not any("Windows" in content for content in scoped_contents)

    unscoped = engine.retrieve("what broke?", {}, include_all_namespaces=True)
    unscoped_contents = {node["content"] for node in unscoped["nodes"]}
    assert any("401" in content for content in unscoped_contents)
    assert any("Windows" in content for content in unscoped_contents)
    assert unscoped["namespace"] is None


def test_list_namespaces_reports_stored_values() -> None:
    engine = MemoryEngine(capacity_limit=48.0)
    engine.store("first", {"type": "observation", "namespace": "alpha"})
    engine.store("second", {"type": "observation", "namespace": "beta"})
    engine.store("third", {"type": "observation", "namespace": "alpha"})
    assert engine.list_namespaces() == ["alpha", "beta"]
