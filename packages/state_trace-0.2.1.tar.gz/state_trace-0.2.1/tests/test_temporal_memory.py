from state_trace.memory import MemoryEngine


def test_agent_log_creates_episode_provenance_and_invalidates_stale_errors() -> None:
    engine = MemoryEngine(capacity_limit=128.0)
    engine.store_agent_log(_sample_auth_log())

    episode_nodes = [node for node in engine.graph_manager.all_nodes() if node.type == "episode"]
    error_observations = [
        node
        for node in engine.graph_manager.all_nodes()
        if node.type == "observation" and node.metadata.get("status") == "error"
    ]

    assert len(episode_nodes) >= 4
    assert error_observations
    assert error_observations[0].invalid_at is not None
    assert error_observations[0].metadata.get("superseded_by")
    assert error_observations[0].metadata.get("invalidated_reason") in {"edited_after_failure", "validated_after_edit"}
    assert engine.graph_manager.find_edges(target=error_observations[0].id, edge_type="supersedes")

    file_result = engine.retrieve(
        "Which file should I patch to fix login?",
        {"session": "auth-debug", "goal": "restore login"},
        limit=5,
        depth_limit=4,
    )

    assert file_result["nodes"][0]["type"] == "file"
    assert "src/auth.ts" in file_result["nodes"][0]["content"]
    assert file_result["nodes"][0]["provenance"]


def test_history_queries_can_surface_superseded_state() -> None:
    engine = MemoryEngine(capacity_limit=128.0)
    engine.store_agent_log(_sample_auth_log())

    result = engine.retrieve(
        "What failed before the fix in auth.ts?",
        {"session": "auth-debug", "goal": "restore login"},
        limit=5,
        depth_limit=4,
    )

    invalidated_nodes = [node for node in result["nodes"] if node.get("invalid_at")]
    assert invalidated_nodes
    assert "Hybrid seeding" in result["reasoning"]


def test_exact_path_query_prefers_matching_file_node() -> None:
    engine = MemoryEngine(capacity_limit=64.0)

    task = engine.store(
        "Fix login regression in the auth flow",
        {"type": "task", "session": "repo-debug", "goal": "restore login", "importance": 0.9},
    )
    auth_decision = engine.store(
        "Investigate refresh retry logic in src/auth.ts",
        {
            "type": "decision",
            "session": "repo-debug",
            "goal": "restore login",
            "files": ["src/auth.ts"],
            "related_to": [task.id],
            "importance": 0.88,
        },
    )
    middleware_decision = engine.store(
        "Middleware also touches login cookies in src/middleware.ts",
        {
            "type": "decision",
            "session": "repo-debug",
            "goal": "restore login",
            "files": ["src/middleware.ts"],
            "related_to": [task.id],
            "importance": 0.7,
        },
    )
    engine.link(auth_decision.id, middleware_decision.id, edge_type="related_to", weight=0.5)

    result = engine.retrieve(
        "Which file should I patch: src/auth.ts?",
        {"session": "repo-debug", "goal": "restore login"},
        limit=5,
        depth_limit=3,
    )

    assert result["nodes"][0]["type"] == "file"
    assert result["nodes"][0]["content"] == "src/auth.ts"


def test_edge_aware_traversal_prefers_patch_edges_over_generic_links() -> None:
    engine = MemoryEngine(capacity_limit=96.0)

    task = engine.store(
        "Fix login retry regression",
        {"type": "task", "session": "repo-debug", "goal": "restore login", "importance": 0.9},
    )
    distractor_file = engine.store(
        "docs/auth.md",
        {"type": "file", "session": "repo-debug", "goal": "restore login", "importance": 0.98},
    )
    engine.link(task.id, distractor_file.id, edge_type="related_to", weight=1.0)

    engine.store(
        "Patch retry handling in src/auth.ts",
        {
            "type": "decision",
            "session": "repo-debug",
            "goal": "restore login",
            "files": ["src/auth.ts"],
            "action_kind": "edit",
            "related_to": [task.id],
            "importance": 0.72,
        },
    )
    engine.store(
        "401 still fails in src/auth.ts until the Authorization header survives retry",
        {
            "type": "observation",
            "session": "repo-debug",
            "goal": "restore login",
            "files": ["src/auth.ts"],
            "status": "error",
            "related_to": [task.id],
            "importance": 0.68,
        },
    )

    result = engine.retrieve(
        "Which file should I patch to fix login?",
        {"session": "repo-debug", "goal": "restore login"},
        limit=5,
        depth_limit=3,
    )

    assert result["nodes"][0]["type"] == "file"
    assert result["nodes"][0]["content"] == "src/auth.ts"
    assert "edge-aware graph traversal" in result["reasoning"]


def test_small_model_brief_surfaces_patch_target_and_fits_budget() -> None:
    engine = MemoryEngine(capacity_limit=128.0)
    engine.store_agent_log(_sample_auth_log())

    brief = engine.retrieve_brief(
        "Why is login still broken and what file should I patch?",
        {"session": "auth-debug", "goal": "restore login"},
        limit=5,
        depth_limit=4,
        mode="small_model",
    )

    assert brief["target_files"][0] == "src/auth.ts"
    assert brief["recommended_actions"][0] == "patch_file: src/auth.ts"
    assert brief["token_estimate"] <= brief["token_budget"]


def test_history_brief_keeps_superseded_failure_context() -> None:
    engine = MemoryEngine(capacity_limit=128.0)
    engine.store_agent_log(_sample_auth_log())

    brief = engine.retrieve_brief(
        "What failed before the fix in auth.ts?",
        {"session": "auth-debug", "goal": "restore login"},
        limit=5,
        depth_limit=4,
        mode="small_model",
    )

    assert brief["failed_attempts"]
    assert any("stale" in item for item in brief["failed_attempts"])


def test_online_runtime_memory_creates_code_artifacts_and_brief() -> None:
    engine = MemoryEngine(capacity_limit=128.0)
    context = {
        "session": "live-auth",
        "goal": "restore login",
        "issue_title": "Login still broken after refresh",
        "repo": "example/auth-service",
        "files": ["src/auth.ts"],
        "thought": "Inspect AuthService.login retry handling",
    }

    engine.record_action('open "src/auth.ts" and inspect AuthService.login', context)
    engine.record_observation(
        "AttributeError: login still fails with a 401 in src/auth.ts",
        {**context, "status": "error"},
    )
    engine.record_action(
        'edit "src/auth.ts" to patch AuthService.login',
        {**context, "action_kind": "edit"},
    )
    engine.record_test_result(
        "pytest tests/test_auth.py::test_refresh_retry",
        "tests/test_auth.py::test_refresh_retry PASSED",
        {**context, "files": ["src/auth.ts", "tests/test_auth.py::test_refresh_retry"]},
    )

    node_types = {node.type for node in engine.graph_manager.all_nodes()}
    assert {"command", "test", "symbol", "error_signature"} <= node_types

    brief = engine.retrieve_brief(
        "Which file should I patch and what test should I rerun?",
        {"session": "live-auth", "goal": "restore login"},
        limit=8,
        depth_limit=4,
        mode="small_model",
    )

    assert brief["patch_file"] == "src/auth.ts"
    assert "tests/test_auth.py::test_refresh_retry" in brief["tests_to_rerun"][0]
    assert any(action.startswith("rerun_test:") for action in brief["recommended_actions"])


def test_current_state_returns_live_non_superseded_view() -> None:
    engine = MemoryEngine(capacity_limit=128.0)
    engine.store_agent_log(_sample_auth_log())

    state = engine.current_state(session="auth-debug", goal="restore login")

    assert state["active_task"] is not None
    assert state["active_task"]["type"] == "task"
    assert state["active_files"], "expected at least one live file"
    assert any("auth.ts" in file_node["content"] for file_node in state["active_files"])

    latest = state["latest_observation"]
    assert latest is not None
    assert latest["status"] != "error", "superseded error observation must not surface as latest"


def test_failed_hypotheses_surfaces_invalidated_errors_and_hides_validated() -> None:
    engine = MemoryEngine(capacity_limit=128.0)
    engine.store_agent_log(_sample_auth_log())

    failures = engine.failed_hypotheses(session="auth-debug", goal="restore login")

    assert failures, "auth log's initial 401 observation should be a failed hypothesis"
    assert all("auth.ts" in str(item.get("content", "")) or item["type"] != "file" for item in failures)
    assert any("invalidated" in item["reason"] or "superseded" in item["reason"] for item in failures)


def test_current_state_scopes_to_session() -> None:
    engine = MemoryEngine(capacity_limit=64.0)
    engine.store(
        "Fix login regression",
        {"type": "task", "session": "session-a", "goal": "restore login", "importance": 0.9},
    )
    engine.store(
        "Fix billing receipt",
        {"type": "task", "session": "session-b", "goal": "fix receipts", "importance": 0.9},
    )

    state_a = engine.current_state(session="session-a")
    state_b = engine.current_state(session="session-b")

    assert state_a["active_task"]["content"].startswith("Fix login")
    assert state_b["active_task"]["content"].startswith("Fix billing")


def test_retrieve_brief_does_not_force_patch_file_for_non_file_queries() -> None:
    """Dogfood regression: a 'what is the 100x opportunity' style query that's
    about an observation (not a file edit) must not set patch_file to whatever
    file happens to be ranked in target_files. Pre-fix, this misled an agent
    into inspecting state_trace/retrieval.py when the answer was in text."""
    engine = MemoryEngine(capacity_limit=96.0)
    ctx = {"session": "opp-session", "goal": "find leverage"}
    engine.store(
        "Find highest leverage improvement for JobForge",
        {"type": "task", "importance": 0.95, **ctx},
    )
    engine.record_observation(
        "JobForge currently loads portals.yml (52K tokens) into every turn's prefix; moving it behind an on-demand retrieval MCP saves ~26 percent of context window per turn.",
        {**ctx, "files": ["/Users/me/JobForge/portals.yml"], "status": "info"},
    )
    engine.record_observation(
        "We wrote a note about state_trace/retrieval.py for unrelated reasons",
        {**ctx, "files": ["state_trace/retrieval.py"], "status": "info"},
    )

    brief = engine.retrieve_brief(
        "what is the 100x opportunity for JobForge",
        {"session": "opp-session", "goal": "find leverage"},
        mode="small_model",
    )

    # The top ranked node is an observation, not a file, AND the query intent
    # is general (not locate_file). patch_file must be None in this case.
    assert brief["patch_file"] in {None, "", "None"}, (
        f"patch_file should be None for non-file-oriented queries; got {brief['patch_file']!r}"
    )


def test_retrieve_brief_preserves_load_bearing_detail_in_top_evidence() -> None:
    """Dogfood regression: evidence[0] used to truncate at 96 chars, cutting
    off the actual actionable numbers. Now the top evidence line gets a wider
    budget so specifics survive compaction."""
    engine = MemoryEngine(capacity_limit=96.0)
    ctx = {"session": "detail-session", "goal": "keep detail"}
    engine.store(
        "Find the 100x token opportunity",
        {"type": "task", "importance": 0.95, **ctx},
    )
    detail = (
        "The 100x opportunity is that JobForge loads portals.yml (~52K tokens) "
        "into the prefix of every apply turn, cached or not, occupying ~26 percent "
        "of the 200K context window. Moving portals behind an on-demand MCP saves ~52K tokens per turn."
    )
    engine.record_observation(detail, {**ctx, "status": "info"})

    brief = engine.retrieve_brief(
        "what is the 100x opportunity",
        {"session": "detail-session", "goal": "keep detail"},
        mode="small_model",
    )

    # The load-bearing specifics ("52K tokens", "portals.yml") must survive
    # through to the rendered brief; pre-fix they got truncated.
    rendered = brief.get("rendered", "")
    assert "52K" in rendered or "52K tokens" in rendered, (
        f"top evidence should retain '52K' detail in rendered brief; got: {rendered!r}"
    )
    assert "portals.yml" in rendered, (
        f"top evidence should retain 'portals.yml' in rendered brief; got: {rendered!r}"
    )


def test_retrieve_brief_target_files_falls_back_to_lexical_paths() -> None:
    """Cold-start case: only one file node exists in the graph but the issue
    text mentions several paths. Pre-fix, target_files == [single file node]
    and Artifact@5 == Artifact@1 by construction. After fix, target_files
    mines lexical candidates from query + node content + issue_text."""
    engine = MemoryEngine(capacity_limit=128.0)
    ctx = {"session": "cold-start", "goal": "localize fix"}
    engine.store(
        "Login 401 after refresh in src/auth.ts",
        {
            "type": "task",
            "importance": 0.95,
            "issue_text": (
                "Login still broken. Suspect src/auth.ts, src/middleware/session.ts, "
                "and possibly tests/test_auth.py. The refresh retry in "
                "src/utils/refresh_client.ts also looks wrong."
            ),
            **ctx,
        },
    )
    engine.store(
        "src/auth.ts",
        {"type": "file", "path": "src/auth.ts", "file": "src/auth.ts", "importance": 0.7, **ctx},
    )

    brief = engine.retrieve_brief(
        "which file should I patch to fix login",
        {"session": "cold-start", "goal": "localize fix"},
        mode="small_model",
    )

    # The primary file node should still rank first.
    assert brief["target_files"], "expected at least one target file"
    assert brief["target_files"][0] == "src/auth.ts"

    # Lexical fallback should surface additional candidates from the issue text.
    assert len(brief["target_files"]) >= 3, (
        f"expected lexical fallback to add more candidates; got {brief['target_files']!r}"
    )
    # At least one of the fallback paths should come from the issue_text.
    assert any(
        candidate != "src/auth.ts" and candidate.endswith((".ts", ".py"))
        for candidate in brief["target_files"]
    )


def test_current_state_latest_observation_is_truly_most_recent() -> None:
    """Dogfood regression: within one runtime session, multiple record_observation
    calls share step_index=0. Before the fix, current_state sorted observations
    by step_index only and returned insertion order as 'latest', so the newest
    write wasn't the one surfaced. Now sort is by event_at -> most recent wins."""
    import time
    engine = MemoryEngine(capacity_limit=128.0)
    ctx = {"session": "recency-session", "goal": "verify recency"}
    engine.store("Verify ordering", {"type": "task", "importance": 0.9, **ctx})
    engine.record_observation("First observation", {**ctx, "status": "info"})
    time.sleep(0.01)  # ensure event_at differs
    engine.record_observation("Second observation", {**ctx, "status": "info"})
    time.sleep(0.01)
    engine.record_observation("Third observation — newest", {**ctx, "status": "info"})

    state = engine.current_state(session="recency-session")

    assert state["latest_observation"] is not None
    assert state["latest_observation"]["content"] == "Third observation — newest", (
        f"latest_observation should be the most recent write, not the first; "
        f"got: {state['latest_observation']['content']!r}"
    )


def test_failed_hypotheses_surfaces_rejected_angle_observations() -> None:
    """Dogfood regression: concluded dead-ends recorded as status=info with
    rejected_angle=True should surface from failed_hypotheses with reason
    ['rejected_angle']. Pre-fix, only error/invalidated/superseded worked."""
    engine = MemoryEngine(capacity_limit=64.0)
    ctx = {"session": "dead-end-session", "goal": "decide direction"}
    engine.store("Decide product direction", {"type": "task", "importance": 0.9, **ctx})
    engine.record_observation(
        "We concluded that filesystem-first mode isn't worth building for JobForge — the harness already externalizes state to files, so state-trace would duplicate work.",
        {**ctx, "status": "info", "rejected_angle": True},
    )
    engine.record_observation(
        "We also noticed the sky is blue",
        {**ctx, "status": "info"},
    )

    failures = engine.failed_hypotheses(session="dead-end-session")

    assert failures, "rejected_angle observation should appear in failed_hypotheses"
    assert any("rejected_angle" in item["reason"] for item in failures), (
        f"expected 'rejected_angle' in failure reasons; got: {[f['reason'] for f in failures]}"
    )
    # The unrelated info observation must NOT appear.
    contents = " ".join(item["content"] for item in failures)
    assert "sky is blue" not in contents, "plain status=info notes should not become failed hypotheses"


def _sample_auth_log() -> dict:
    return {
        "format": "agent_log",
        "source": "agent_log",
        "session_id": "auth-debug",
        "repo": "example/auth-service",
        "issue_title": "Login still broken after refresh",
        "issue_text": "Login still broken after refresh token exchange",
        "goal": "restore login",
        "steps": [
            {
                "index": 0,
                "action": 'open "src/auth.ts"',
                "thought": "Inspect the failing auth path",
                "observation": "AttributeError: login still fails with a 401 in src/auth.ts",
                "files": ["src/auth.ts"],
                "action_kind": "open",
                "status": "error",
                "error_signatures": ["AttributeError: login still fails with a 401 in src/auth.ts"],
            },
            {
                "index": 1,
                "action": 'edit "src/auth.ts"',
                "thought": "Patch the refresh header handling",
                "observation": "Updated src/auth.ts to preserve the Authorization header",
                "files": ["src/auth.ts"],
                "action_kind": "edit",
                "status": "info",
                "error_signatures": [],
            },
            {
                "index": 2,
                "action": "pytest tests/test_auth.py",
                "thought": "Verify the auth fix",
                "observation": "auth tests passed",
                "files": ["src/auth.ts"],
                "action_kind": "pytest",
                "status": "success",
                "error_signatures": [],
            },
        ],
        "submission_diff": "diff --git a/src/auth.ts b/src/auth.ts\n+++ b/src/auth.ts\n@@\n- old\n+ new\n",
        "submission_files": ["src/auth.ts"],
    }
