from dataclasses import dataclass

from state_trace.benchmarking import (
    build_group_splits,
    bootstrap_confidence_interval,
    resolve_policy_models,
    resolve_policy_reasoning,
    summarize_live_rows,
)


@dataclass(frozen=True)
class _Case:
    case_id: str
    group_id: str


def test_build_group_splits_uses_leave_one_group_out_for_small_group_sets() -> None:
    cases = [
        _Case(case_id="a1", group_id="group-a"),
        _Case(case_id="a2", group_id="group-a"),
        _Case(case_id="b1", group_id="group-b"),
        _Case(case_id="c1", group_id="group-c"),
    ]

    splits = build_group_splits(cases, holdout_fraction=0.5, repeats=10, seed=7)

    assert len(splits) == 3
    assert {split.test_groups for split in splits} == {("group-a",), ("group-b",), ("group-c",)}
    for split in splits:
        assert set(split.train_groups).isdisjoint(split.test_groups)
        assert len(split.test_cases) >= 1


def test_bootstrap_confidence_interval_handles_single_value() -> None:
    point, lower, upper = bootstrap_confidence_interval([0.75], bootstrap_samples=200)
    assert point == 0.75
    assert lower == 0.75
    assert upper == 0.75


def test_summarize_live_rows_returns_metric_intervals() -> None:
    rows = [
        {"success": 1, "steps_completed": 3, "total_steps": 3, "artifact_at_1": 1.0, "avg_tokens": 180.0, "avg_latency_ms": 12.0},
        {"success": 0, "steps_completed": 1, "total_steps": 3, "artifact_at_1": 0.0, "avg_tokens": 200.0, "avg_latency_ms": 20.0},
    ]

    summary = summarize_live_rows(rows, bootstrap_samples=200, seed=11)

    assert summary["success"][0] == 0.5
    assert summary["artifact_at_1"][0] == 0.5
    assert summary["avg_tokens"][0] == 190.0


def test_resolve_policy_models_uses_codex_defaults() -> None:
    small_model, large_model = resolve_policy_models("codex")

    assert small_model == "gpt-5.4-mini"
    assert large_model == "gpt-5.3-codex"


def test_resolve_policy_models_uses_codex_api_defaults() -> None:
    small_model, large_model = resolve_policy_models("codex_api")

    assert small_model == "gpt-5.1-codex-mini"
    assert large_model == "gpt-5.2-codex"


def test_resolve_policy_reasoning_honors_overrides() -> None:
    small_reasoning, large_reasoning = resolve_policy_reasoning("codex", "low", "")

    assert small_reasoning == "low"
    assert large_reasoning == "high"
