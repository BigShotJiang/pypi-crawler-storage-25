class TemplateLoader:
    pass