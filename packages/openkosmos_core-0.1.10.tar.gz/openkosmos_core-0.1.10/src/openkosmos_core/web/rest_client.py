from abc import ABC, abstractmethod
from http import HTTPMethod, HTTPStatus

import httpx
from httpx import Timeout
from httpx._models import Response
from pydantic import BaseModel

from openkosmos_core.common.type import LogMode
from openkosmos_core.setting import Setting
from openkosmos_core.web.model import HttpHeaders, RestClientConfig

log = Setting.logger("rest")


class RestClientResponse:
    def __init__(self, response: Response):
        self._response = response
        self._map_function = None
        self._return_json: bool = True

    def return_json(self, value: bool):
        self._return_json = value
        return self

    def status_code(self):
        return self._response.status_code

    def body(self, type=None, return_json: bool = None):
        result = self._response
        if (self._return_json if return_json is None else return_json):
            if type is None:
                result = result.json()
            else:
                result = type(**result.json())

        if self._map_function is None:
            return result
        else:
            return self._map_function(result)

    def map(self, map_function):
        self._map_function = map_function
        return self


class RestClientCallback:

    def before_execute_headers(self, headers: HttpHeaders) -> HttpHeaders:
        return headers

    def before_execute_params(self, params):
        return params

    def on_exception(self, exception):
        raise exception

    def on_failure(self, code: HTTPStatus, response: Response):
        raise Exception(f"{code.value} {code.name}: {response.content}")


class RestClientExecutor(ABC):

    def __init__(self, config: RestClientConfig, path: str = None):
        self._config = config
        self._path: str = path
        self._params = None
        self._form_data = None
        self._json_data = None
        self._files = None
        self._headers: HttpHeaders = config.create_http_headers()
        self._callback: RestClientCallback = None

    @abstractmethod
    def method(self):
        pass

    def callback(self, value: RestClientCallback):
        self._callback = value
        return self

    def path(self, value: str):
        self._path = value
        return self

    def params(self, value):
        self._params = value
        return self

    def headers(self, value: HttpHeaders):
        self._headers = value
        return self

    def header(self, key: str, value):
        self._headers.extra(key=key, value=value)
        return self

    def form_data(self, value):
        self._form_data = value
        return self

    def json_data(self, value):
        self._json_data = value
        return self

    def files(self, value=None):
        self._files = value
        return self

    @abstractmethod
    def execute_request(self, url: str, headers: HttpHeaders, params) -> Response:
        pass

    @staticmethod
    def to_http_params(params: dict | BaseModel = None):
        if isinstance(params, dict):
            return params
        else:
            return None if params is None else params.model_dump(by_alias=True, exclude_none=True)

    def retrieve(self) -> RestClientResponse:

        url = self._config.get_url(self._path)

        if self._config.log_mode != LogMode.NONE:
            log.debug(f"{self.method()} url: {url}")
            log.debug(f"{self.method()} params: {self._params}")

        if self._config.log_mode == LogMode.ALL:
            if self.method() == HTTPMethod.POST or self.method() == HTTPMethod.PUT:
                if self._json_data is not None:
                    log.debug(f"{self.method()} body: {self._json_data}")
                elif self._form_data is not None:
                    log.debug(f"{self.method()} body: {self._form_data}")
                elif self._files is not None:
                    log.debug(f"{self.method()} body: files")
                else:
                    log.debug(f"{self.method()} body: None")

        try:
            response = self.execute_request(url=url,
                                            headers=self._callback.before_execute_headers(self._headers),
                                            params=RestClientExecutor.to_http_params(
                                                self._callback.before_execute_params(self._params)))
        except Exception as e:
            self._callback.on_exception(e)

        if self._config.log_mode == LogMode.ALL:
            log.debug(f"{self.method()} response[{response.status_code}]: {response.content}")

        http_status = HTTPStatus(response.status_code)

        if not http_status.is_success:
            self._callback.on_failure(http_status, response)

        return RestClientResponse(response)


class RestClientGetExecutor(RestClientExecutor):
    def method(self):
        return HTTPMethod.GET

    def execute_request(self, url: str, headers: HttpHeaders, params) -> Response:
        return httpx.get(url, params=params, headers=headers.to_headers(),
                         timeout=Timeout(timeout=self._config.timeout))


class RestClientPostExecutor(RestClientExecutor):
    def method(self):
        return HTTPMethod.POST

    def execute_request(self, url: str, headers: HttpHeaders, params) -> Response:
        if self._json_data is not None:
            return httpx.post(url, params=params, headers=headers.to_headers(),
                              json=self._json_data, timeout=Timeout(timeout=self._config.timeout))
        elif self._form_data is not None:
            return httpx.post(url, params=params,
                              headers=headers.content_type("multipart/form-data").to_headers(),
                              data=self._form_data, timeout=Timeout(timeout=self._config.timeout))
        elif self._files is not None:
            return httpx.post(url, params=params, headers=headers.content_type().to_headers(),
                              files=self._files, timeout=Timeout(timeout=self._config.timeout))
        else:
            return httpx.post(url, params=params, headers=headers.to_headers(),
                              timeout=Timeout(timeout=self._config.timeout))


class RestClientPutExecutor(RestClientExecutor):
    def method(self):
        return HTTPMethod.PUT

    def execute_request(self, url: str, headers: HttpHeaders, params) -> Response:
        if self._json_data is not None:
            return httpx.put(url, params=params, headers=headers.to_headers(), json=self._json_data,
                             timeout=Timeout(timeout=self._config.timeout))
        else:
            return httpx.put(url, params=params, headers=headers.to_headers(),
                             timeout=Timeout(timeout=self._config.timeout))


class RestClientDeleteExecutor(RestClientExecutor):
    def method(self):
        return HTTPMethod.DELETE

    def execute_request(self, url: str, headers: HttpHeaders, params) -> Response:
        if self._json_data is not None:
            with httpx.Client() as client:
                return client.request("DELETE", url=url, params=params, json=self._json_data,
                                      headers=headers.to_headers(),
                                      timeout=Timeout(timeout=self._config.timeout))
        else:
            return httpx.delete(url, params=params, headers=headers.to_headers(),
                                timeout=Timeout(timeout=self._config.timeout))


class RestClient:
    def __init__(self, config: RestClientConfig):
        self._api_config = config
        self._callback: RestClientCallback = RestClientCallback()

    def callback(self, callback: RestClientCallback):
        self._callback = callback
        return self

    def api_config(self):
        return self._api_config

    def get(self, path: str = None, callback: RestClientCallback = None):
        return RestClientGetExecutor(self._api_config, path).callback(
            self._callback if callback is None else callback)

    def post(self, path: str = None, callback: RestClientCallback = None):
        return RestClientPostExecutor(self._api_config, path).callback(
            self._callback if callback is None else callback)

    def put(self, path: str = None, callback: RestClientCallback = None):
        return RestClientPutExecutor(self._api_config, path).callback(
            self._callback if callback is None else callback)

    def delete(self, path: str = None, callback: RestClientCallback = None):
        return RestClientDeleteExecutor(self._api_config, path).callback(
            self._callback if callback is None else callback)
