from typing import Optional

from openkosmos_core.common.model import BaseConfig
from openkosmos_core.common.type import LogMode


class HttpHeaders:

    def __init__(self):
        self._content_type: str = "application/json"
        self._authorization: Optional[str] = None
        self._extra_headers: Optional[dict] = {}

    def to_headers(self):
        headers = {}
        if self._content_type is not None:
            headers["Content-Type"] = self._content_type
        if self._authorization is not None:
            headers["Authorization"] = "Bearer " + self._authorization
        return headers | self._extra_headers

    def extra(self, key: str, value: str):
        self._extra_headers[key] = value
        return self

    def extras(self, value: dict):
        if value is not None:
            self._extra_headers = value
        return self

    def authorization(self, value: str = None):
        self._authorization = value
        return self

    def content_type(self, value: str = None):
        self._content_type = value
        return self


class ClientConfig(BaseConfig):
    base_url: str
    api_key: Optional[str] = None
    api_prefix: str = ""
    log_mode: LogMode = LogMode.NONE
    extra_headers: Optional[dict] = None
    timeout: 10.0

    def create_http_headers(self) -> HttpHeaders:
        return HttpHeaders().authorization(self.api_key).extras(self.extra_headers)

    def get_url(self, path: str):
        return f"{self.base_url}{self.api_prefix}{path}"


class RestClientConfig(ClientConfig):
    pass


class WebClientConfig(ClientConfig):
    pass
