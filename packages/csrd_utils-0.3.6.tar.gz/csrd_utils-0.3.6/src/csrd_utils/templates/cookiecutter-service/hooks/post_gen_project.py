#!/usr/bin/env python3
"""Validate composable feature combinations for generated services."""

from __future__ import annotations

from pathlib import Path

HAS_DATABASE = {{ "True" if cookiecutter.has_database else "False" }}
HAS_WORKERS = {{ "True" if cookiecutter.has_workers else "False" }}
HAS_CACHING = {{ "True" if cookiecutter.has_caching else "False" }}
HAS_DELEGATES = {{ "True" if cookiecutter.has_delegates else "False" }}
HAS_STRUCTURED_LOGGING = {{ "True" if cookiecutter.has_structured_logging else "False" }}
DB_KIND = "{{ cookiecutter.database }}"
BROKER = "{{ cookiecutter.broker }}"
CACHE_BACKEND = "{{ cookiecutter.cache_backend }}"
UPSTREAMS = "{{ cookiecutter.upstreams }}"


def _prune_disabled_files() -> None:
    root = Path.cwd()

    def _unlink(relpath: str) -> None:
        path = root / relpath
        if path.exists():
            path.unlink()

    def _rmdir_if_empty(relpath: str) -> None:
        path = root / relpath
        if path.exists() and path.is_dir() and not any(path.iterdir()):
            path.rmdir()

    if not HAS_DATABASE:
        _unlink("src/app/dependencies/item_repository.py")
        _unlink("src/app/repositories/item_repository.py")

    if not HAS_DELEGATES:
        _unlink("src/app/dependencies/delegates.py")
        _unlink("src/app/delegates/upstreams.py")

    if not HAS_WORKERS:
        _unlink("src/app/dependencies/worker_broker.py")
        _unlink("src/app/workers/tasks.py")

    if not HAS_CACHING:
        _unlink("src/app/cache.py")

    if not HAS_STRUCTURED_LOGGING:
        _unlink("src/app/middleware/logging.py")

    _rmdir_if_empty("src/app/repositories")
    _rmdir_if_empty("src/app/delegates")
    _rmdir_if_empty("src/app/workers")
    _rmdir_if_empty("src/app/middleware")


def main() -> int:
    errors: list[str] = []

    if HAS_DATABASE and DB_KIND not in {"sqlite", "maria", "postgres"}:
        errors.append(f"Unsupported database: {DB_KIND}")

    if HAS_WORKERS and BROKER not in {"redis", "rabbitmq"}:
        errors.append(f"Unsupported worker broker: {BROKER}")

    if HAS_CACHING and CACHE_BACKEND != "redis":
        errors.append(f"Unsupported cache backend: {CACHE_BACKEND}")

    if HAS_DELEGATES and not UPSTREAMS.strip():
        errors.append("Delegates enabled but no upstreams configured")

    if errors:
        print("Template validation failed:")
        for message in errors:
            print(f"- {message}")
        return 1

    _prune_disabled_files()
    print("Template validation passed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
