"""Command-line interface for csrd-utils."""

from __future__ import annotations

import argparse
import json
from importlib.metadata import version
from pathlib import Path
from typing import TypedDict

from .augmentor import ServiceAugmentor
from .doctor import run_doctor
from .generator import generate_service
from .resources import features_path


class GenerateServiceArgs(TypedDict):
    name: str
    output_dir: Path
    description: str
    port: int
    model_name: str
    model_name_plural: str
    has_database: bool
    database: str
    has_delegates: bool
    upstreams: str
    has_workers: bool
    broker: str
    has_caching: bool
    cache_backend: str
    has_structured_logging: bool
    overwrite_if_exists: bool


def _prompt_text(label: str, default: str) -> str:
    value = input(f"{label} [{default}]: ").strip()
    return value or default


def _prompt_bool(label: str, default: bool) -> bool:
    suffix = "Y/n" if default else "y/N"
    value = input(f"{label} ({suffix}): ").strip().lower()
    if not value:
        return default
    return value in {"y", "yes", "true", "1"}


def _prompt_choice(label: str, choices: list[str], default: str) -> str:
    rendered = ", ".join(choices)
    while True:
        value = input(f"{label} [{default}] ({rendered}): ").strip().lower()
        if not value:
            return default
        if value in choices:
            return value
        print(f"ERROR: Invalid choice '{value}'. Expected one of: {rendered}")


def _prompt_int(label: str, default: int) -> int:
    while True:
        value = input(f"{label} [{default}]: ").strip()
        if not value:
            return default
        try:
            return int(value)
        except ValueError:
            print("ERROR: Enter a valid integer")


def _collect_new_service_config(args: argparse.Namespace) -> GenerateServiceArgs:
    explicit_interactive = getattr(args, "interactive", None)
    interactive = (
        bool(explicit_interactive) if explicit_interactive is not None else args.name is None
    )

    # Non-interactive mode keeps current flag-driven behavior.
    if not interactive:
        has_database = args.database != "none"
        selected_database = "sqlite" if not has_database else args.database
        return GenerateServiceArgs(
            {
                "name": args.name,
                "output_dir": args.output,
                "description": args.description,
                "port": args.port,
                "model_name": args.model_name,
                "model_name_plural": args.model_name_plural,
                "has_database": has_database,
                "database": selected_database,
                "has_delegates": args.delegates,
                "upstreams": args.upstreams,
                "has_workers": args.workers,
                "broker": args.broker,
                "has_caching": args.caching,
                "cache_backend": args.cache_backend,
                "has_structured_logging": args.structured_logging,
                "overwrite_if_exists": args.force,
            }
        )

    print("Interactive mode: press Enter to accept defaults.")

    name = _prompt_text("Service name", args.name or "my-service")
    output_dir = Path(_prompt_text("Output directory", str(args.output)))
    description = _prompt_text("Service description", args.description)
    port = _prompt_int("HTTP port", args.port)
    model_name = _prompt_text("Model name", args.model_name)

    plural_default = args.model_name_plural
    if plural_default == "items" and model_name != "Item":
        plural_default = f"{model_name.lower()}s"
    model_name_plural = _prompt_text("Model name plural", plural_default)

    database = _prompt_choice("Database", ["sqlite", "maria", "postgres", "none"], args.database)
    has_database = database != "none"
    selected_database = "sqlite" if not has_database else database

    has_delegates = _prompt_bool("Enable delegates", args.delegates)
    upstreams_default = args.upstreams
    if has_delegates and not upstreams_default:
        upstreams_default = "http://service-a:8080"
    upstreams = (
        _prompt_text("Delegates upstreams (comma-separated)", upstreams_default)
        if has_delegates
        else ""
    )

    has_workers = _prompt_bool("Enable workers", args.workers)
    broker = (
        _prompt_choice("Worker broker", ["redis", "rabbitmq"], args.broker)
        if has_workers
        else args.broker
    )

    has_caching = _prompt_bool("Enable caching", args.caching)
    cache_backend = (
        _prompt_choice("Cache backend", ["redis"], args.cache_backend)
        if has_caching
        else args.cache_backend
    )

    has_structured_logging = _prompt_bool("Enable structured logging", args.structured_logging)
    overwrite_if_exists = _prompt_bool("Overwrite if target exists", args.force)

    return GenerateServiceArgs(
        {
            "name": name,
            "output_dir": output_dir,
            "description": description,
            "port": port,
            "model_name": model_name,
            "model_name_plural": model_name_plural,
            "has_database": has_database,
            "database": selected_database,
            "has_delegates": has_delegates,
            "upstreams": upstreams,
            "has_workers": has_workers,
            "broker": broker,
            "has_caching": has_caching,
            "cache_backend": cache_backend,
            "has_structured_logging": has_structured_logging,
            "overwrite_if_exists": overwrite_if_exists,
        }
    )


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="csrd", description="csrd utilities")
    parser.add_argument(
        "-v",
        "--version",
        action="version",
        version=f"csrd-utils {version('csrd-utils')}",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    feature = sub.add_parser("feature", help="Feature operations")
    feature_sub = feature.add_subparsers(dest="feature_command", required=True)

    list_cmd = feature_sub.add_parser("list", help="List bundled features")
    list_cmd.set_defaults(plan=False)

    for name, plan in (("add", False), ("plan", True)):
        cmd = feature_sub.add_parser(name, help=f"{name} feature")
        cmd.add_argument("feature", help="Feature name, e.g. workers")
        cmd.add_argument("--service", type=Path, default=Path.cwd(), help="Service root path")
        if name == "plan":
            cmd.add_argument("--json", action="store_true", help="Print plan as JSON")
        cmd.set_defaults(plan=plan)

    doctor = sub.add_parser("doctor", help="Validate service compatibility")
    doctor.add_argument("--service", type=Path, default=Path.cwd(), help="Service root path")
    doctor.add_argument("--json", action="store_true", help="Print doctor report as JSON")

    new = sub.add_parser("new", help="Generate new assets")
    new_sub = new.add_subparsers(dest="new_command", required=True)
    service = new_sub.add_parser("service", help="Generate a service from bundled template")
    service.add_argument("--name", help="Service name")
    service.add_argument("--output", type=Path, default=Path.cwd(), help="Output directory")
    service.add_argument(
        "--description",
        default="A microservice using the csrd library stack",
        help="Service description",
    )
    service.add_argument("--port", type=int, default=8080, help="HTTP service port")
    service.add_argument("--model-name", default="Item", help="Primary model name")
    service.add_argument("--model-name-plural", default="items", help="Plural model name")
    service.add_argument(
        "--database", choices=["sqlite", "maria", "postgres", "none"], default="sqlite"
    )
    service.add_argument("--delegates", action="store_true", help="Enable delegates")
    service.add_argument("--upstreams", default="", help="Comma-separated upstream URLs")
    service.add_argument("--workers", action="store_true", help="Enable workers")
    service.add_argument("--broker", choices=["redis", "rabbitmq"], default="redis")
    service.add_argument("--caching", action="store_true", help="Enable caching")
    service.add_argument("--cache-backend", choices=["redis"], default="redis")
    service.add_argument(
        "--structured-logging",
        dest="structured_logging",
        action="store_true",
        default=True,
        help="Enable structured logging",
    )
    service.add_argument(
        "--no-structured-logging",
        dest="structured_logging",
        action="store_false",
        help="Disable structured logging",
    )
    service.add_argument("--interactive", dest="interactive", action="store_true", default=None)
    service.add_argument("--no-interactive", dest="interactive", action="store_false")
    service.add_argument("--force", action="store_true", help="Overwrite existing generated path")

    return parser


def _list_features() -> int:
    with features_path() as feature_lib:
        names = sorted(
            path.name
            for path in feature_lib.iterdir()
            if path.is_dir() and (path / "manifest.yaml").exists()
        )
    if not names:
        print("No bundled features found.")
        return 1
    for name in names:
        print(name)
    return 0


def _run_doctor(service: Path, as_json: bool) -> int:
    report = run_doctor(service)
    payload = {
        "ok": report.ok,
        "errors": report.errors,
        "warnings": report.warnings,
    }
    if as_json:
        print(json.dumps(payload, indent=2, sort_keys=True))
    else:
        if report.ok:
            print("Doctor check passed.")
        else:
            print("Doctor check failed.")
        for err in report.errors:
            print(f"ERROR: {err}")
        for warning in report.warnings:
            print(f"WARN: {warning}")
    return 0 if report.ok else 1


def main() -> int:
    parser = _build_parser()
    args = parser.parse_args()

    if args.command == "new" and args.new_command == "service":
        try:
            config = _collect_new_service_config(args)
            generated = generate_service(**config)
        except (FileExistsError, ValueError) as exc:
            print(f"ERROR: {exc}")
            return 1
        except KeyboardInterrupt:
            print("\nCancelled.")
            return 1
        print(f"Generated service at: {generated}")
        return 0

    if args.command == "doctor":
        return _run_doctor(args.service, args.json)

    if args.command != "feature" or args.feature_command not in {"add", "plan", "list"}:
        parser.print_help()
        return 0

    if args.feature_command == "list":
        return _list_features()

    with features_path() as feature_lib:
        augmentor = ServiceAugmentor(args.service, feature_lib)
        if args.feature_command == "plan" and args.json:
            plan = augmentor.build_plan(args.feature)
            if plan is None:
                return 1
            print(
                json.dumps(
                    {
                        "feature": args.feature,
                        "service": str(args.service.resolve()),
                        "modifies": plan["modifies"],
                        "creates": plan["creates"],
                    },
                    indent=2,
                    sort_keys=True,
                )
            )
            return 0
        success, changes = augmentor.add_feature(args.feature, plan=args.plan)

    if not success:
        return 1

    if args.plan:
        print("Plan validated.")
    else:
        print(f"Feature '{args.feature}' added.")
        if changes:
            for change in changes:
                print(f"- {change}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
