"""Tool loop system prompt builder — framework detection and prompt generation.

Now framework-aware: detects the target framework from the user's task description
and injects framework-specific development rules into the system prompt.
"""
from __future__ import annotations

import json
import re
from pathlib import Path


# ── Framework patterns for task-based detection ──────────────────────

_TASK_FRAMEWORK_PATTERNS: list[tuple[str, str, str]] = [
    ("laravel",    r"laravel",                     "PHP"),
    ("django",     r"django",                      "Python"),
    ("fastapi",    r"fastapi",                     "Python"),
    ("flask",      r"\bflask\b",                   "Python"),
    ("react",      r"\breact\b",                   "JavaScript"),
    ("nextjs",     r"next\.?js?\b",                "JavaScript"),
    ("vue",        r"\bvue\b",                     "JavaScript"),
    ("angular",    r"\bangular\b",                 "JavaScript"),
    ("svelte",     r"\bsvelte(?:kit)?\b",           "JavaScript"),
    ("express",    r"\bexpress\b",                 "JavaScript"),
    ("node",       r"\bnode(?:\.js)?\b",           "JavaScript"),
    ("spring",     r"\bspring\b",                  "Java"),
    ("rails",      r"\brails\b",                   "Ruby"),
    ("go",         r"\b(?:golang|go(?:\s+lang)?)\b", "Go"),
    ("gin",        r"\bgin\b",                     "Go"),
    ("rust",       r"\brust\b",                    "Rust"),
    ("flutter",    r"\bflutter\b",                 "Dart"),
    ("wordpress",  r"\bwordpress\b",              "PHP"),
    ("symfony",    r"\bsymfony\b",                "PHP"),
]

_FRAMEWORK_RULES: dict[str, str] = {
    "laravel": (
        "## Laravel / PHP Development Rules\n"
        "- Use MVC pattern: Models in app/Models, Views in resources/views, Controllers in app/Http/Controllers\n"
        "- Use Eloquent ORM for database queries — not raw SQL\n"
        "- Use Blade templating for views: @extends, @section, @yield\n"
        "- Use Artisan CLI: php artisan make:model, php artisan migrate, php artisan serve\n"
        "- Routes in routes/web.php (web) and routes/api.php (API)\n"
        "- Validation in Form Requests or validate() method\n"
        "- Use dependency injection in controllers\n"
        "- Migrations for schema changes, Seeders for test data\n"
        "- Follow PSR-4 autoloading and PSR-12 coding style\n"
        "- Use Laravel's built-in authentication (Sanctum, Breeze, Jetstream)\n"
        "- Queue jobs for slow tasks, Schedule for cron\n"
        "- Use env() or config() for configuration, never hardcode secrets\n"
    ),
    "django": (
        "## Django / Python Development Rules\n"
        "- Use MTV pattern: Models define data, Templates define UI, Views define logic\n"
        "- Use Django ORM for queries: Model.objects.filter(), select_related(), prefetch_related()\n"
        "- URL dispatcher in urls.py, views in views.py\n"
        "- Use class-based views (ListView, DetailView, CreateView) where possible\n"
        "- Forms for input validation, ModelForm for model-backed forms\n"
        "- Migrations via python manage.py makemigrations && migrate\n"
        "- Admin interface via admin.py registration\n"
        "- Settings in settings.py, separate dev/prod settings for security\n"
        "- Use environment variables for secrets (python-decouple or django-environ)\n"
    ),
    "fastapi": (
        "## FastAPI / Python Development Rules\n"
        "- Use Pydantic models for request/response validation with `model_config = ConfigDict(from_attributes=True)`\n"
        "- Path operations: @app.get(), @app.post(), @app.put(), @app.delete()\n"
        "- Dependency injection with Depends() for auth, DB sessions\n"
        "- SQLAlchemy async for database, Alembic for migrations\n"
        "- Use HTTPException for error responses, status codes from fastapi.status\n"
        "- BackgroundTasks for post-response work\n"
        "- CORS middleware config in app startup\n"
        "- OpenAPI docs auto-generated at /docs and /redoc\n"
        "## Python Common Pitfalls to Avoid\n"
        "- NEVER use `passlib[bcrypt]` with `bcrypt>=4.1.0` — pin `bcrypt==4.0.1` or use `argon2-cffi` instead\n"
        "- Always use `datetime.now(timezone.utc)` instead of `datetime.now()` for timezone-aware datetimes\n"
        "- When using UUID primary keys in Pydantic models, use `id: UUID` type (not str) or add a `@field_validator` to convert\n"
        "- SQLAlchemy relationship foreign_keys must reference the model class, not string names, when using `mapped_column`\n"
        "- Always verify import paths match actual directory structure (e.g., `app.repositories` not `app.repository`)\n"
        "- Use `pytest` fixtures with `yield` for proper teardown of database sessions\n"
        "- For SQLite with SQLAlchemy, use synchronous engine (not async) due to threading constraints\n"
        "- Passwords must be truncated to 72 bytes before bcrypt hashing: `password[:72].encode()`\n"
    ),
    "react": (
        "## React / JavaScript Development Rules\n"
        "- Functional components with hooks — no class components\n"
        "- Use TypeScript for type safety (interfaces for props, state)\n"
        "- State management: useState for local, useReducer for complex, Context for shared\n"
        "- Side effects via useEffect with proper cleanup\n"
        "- Fetch data with React Query / TanStack Query or SWR\n"
        "- Routing with React Router v6 (createBrowserRouter or <Routes>)\n"
        "- Styling: Tailwind CSS, CSS Modules, or styled-components\n"
        "- Component per file, named exports, index.ts barrel files\n"
    ),
    "nextjs": (
    "## Next.js / JavaScript Development Rules\n"
        "- App Router (app/) preferred over Pages Router\n"
        "- Server Components by default, 'use client' for interactivity\n"
        "- File-based routing: app/page.tsx for /, app/blog/[slug]/page.tsx for /blog/:slug\n"
        "- Data fetching: fetch() in Server Components, Route Handlers for APIs\n"
        "- Layouts via layout.tsx, loading states via loading.tsx, errors via error.tsx\n"
        "- Metadata API for SEO: export const metadata = { title, description }\n"
        "- Server Actions for form submissions and mutations\n"
    ),
    "vue": (
        "## Vue / JavaScript Development Rules\n"
        "- Use Composition API (setup script) over Options API\n"
        "- Single File Components: <template>, <script setup>, <style scoped>\n"
        "- Use Pinia for state management, Vue Router for routing\n"
        "- v-for with :key, v-if/v-else for conditional rendering\n"
        "- Reactive data via ref() and reactive(), computed() for derived state\n"
        "- Watch with watch() or watchEffect() for side effects\n"
        "- Use provide/inject for deep prop drilling avoidance\n"
        "- Composition functions in composables/ directory\n"
    ),
    "angular": (
        "## Angular / TypeScript Development Rules\n"
        "- Standalone components preferred over NgModules\n"
        "- Use Angular CLI: ng generate component, ng serve, ng build\n"
        "- Reactive Forms over Template-Driven Forms\n"
        "- Use RxJS Observables with async pipe, not manual subscribe\n"
        "- Lazy-load feature modules via loadChildren in routes\n"
        "- Use @Injectable() services with providedIn: 'root'\n"
        "- OnPush change detection strategy for performance\n"
    ),
    "svelte": (
        "## Svelte / JavaScript Development Rules\n"
        "- Single-file components: <script>, <style>, template (no separate files)\n"
        "- Reactive declarations: $: derived = expression\n"
        "- Use SvelteKit for full-stack apps (file-based routing)\n"
        "- Stores for shared state: writable(), readable(), derived()\n"
        "- Bindings with bind:value, event handlers with on:click\n"
        "- Slots for content projection, {#each} for lists\n"
    ),
    "express": (
        "## Express.js / Node.js Development Rules\n"
        "- RESTful routing: app.get(), app.post(), app.put(), app.delete()\n"
        "- Modular routes with express.Router()\n"
        "- Middleware chain: app.use() for auth, parsing, logging\n"
        "- Error handling middleware: (err, req, res, next) => {}\n"
        "- Use helmet for security headers, cors for CORS\n"
        "- Environment config via dotenv\n"
        "- Use async middleware wrappers to catch promise rejections\n"
        "- Input validation with Joi, Zod, or express-validator\n"
    ),
    "node": (
        "## Node.js Development Rules\n"
        "- CommonJS or ES modules (type: 'module' in package.json)\n"
        "- Use npm or yarn for package management\n"
        "- Async/await for async operations, never raw callbacks\n"
        "- Environment variables via process.env, .env files\n"
    ),
    "spring": (
        "## Spring Boot / Java Development Rules\n"
        "- Annotations: @RestController, @Service, @Repository, @Entity\n"
        "- Dependency injection via constructor injection (not @Autowired on fields)\n"
        "- Use Jakarta persistence with @Entity, @Repository\n"
        "- application.yml or application.properties for config, profiles for env\n"
        "- Maven (pom.xml) or Gradle (build.gradle) for builds\n"
        "- REST endpoints with @GetMapping, @PostMapping, etc.\n"
        "- @Valid + jakarta.validation for request validation\n"
        "- JPA Repository interface for data access\n"
        "- @ExceptionHandler for global error handling\n"
        "- Use Lombok to reduce boilerplate (@Data, @Builder, @Slf4j)\n"
    ),
    "rails": (
        "## Ruby on Rails Development Rules\n"
        "- Convention over Configuration: follow Rails naming conventions\n"
        "- MVC: Models in app/models, Views in app/views, Controllers in app/controllers\n"
        "- Active Record for ORM: migrations, validations, associations\n"
        "- RESTful routes in config/routes.rb with resources\n"
        "- Use Gemfile for dependencies, bundle install\n"
        "- ERB or Haml for templates, partials for reuse (_partial.html.erb)\n"
        "- Strong parameters in controllers, not mass assignment\n"
        "- Use Rails generators: rails generate model, controller, migration\n"
        "- Testing with RSpec or Minitest\n"
    ),
    "go": (
        "## Go Development Rules\n"
        "- Standard project layout: cmd/, internal/, pkg/, api/\n"
        "- Use go.mod for module, go.sum for dependency checksums\n"
        "- Error handling: always check errors, never ignore them\n"
        "- Use interfaces for abstraction, structs for data\n"
        "- Goroutines + channels for concurrency, sync.WaitGroup for coordination\n"
        "- Context for cancellation and timeouts\n"
        "- Testing: _test.go files, go test, table-driven tests\n"
        "- Use gofmt/golint for formatting\n"
        "- JSON handling: encoding/json with struct tags\n"
    ),
    "gin": (
        "## Gin / Go Web Development Rules\n"
        "- Router: gin.Default() or gin.New() with middleware\n"
        "- Handlers: func(c *gin.Context), c.JSON(), c.BindJSON()\n"
        "- Route groups for API versioning\n"
        "- Middleware: gin.Logger(), gin.Recovery(), custom via c.Next()\n"
        "- Use go mod for dependencies\n"
    ),
    "flutter": (
        "## Flutter / Dart Development Rules\n"
        "- Material Design widgets: Scaffold, AppBar, etc.\n"
        "- StatelessWidget vs StatefulWidget\n"
        "- Use pubspec.yaml for dependencies, flutter pub get\n"
        "- State management: Provider, Riverpod, Bloc, or GetX\n"
        "- Navigator 2.0 or go_router for routing\n"
        "- const constructors for performance\n"
        "- Use Dart's null safety (?, !, late)\n"
    ),
    "wordpress": (
        "## WordPress / PHP Development Rules\n"
        "- Follow WordPress Coding Standards\n"
        "- Use wp_enqueue_script/style for assets, not hardcoded <link>/<script>\n"
        "- Custom post types and taxonomies via register_post_type()\n"
        "- Use WP_Query, not raw SQL queries\n"
        "- Hooks: add_action() and add_filter() for extensibility\n"
        "- Sanitize/validate all input: sanitize_text_field(), wp_kses()\n"
        "- Options API (get_option/update_option) for settings\n"
        "- Transients API for caching expensive operations\n"
    ),
    "symfony": (
        "## Symfony / PHP Development Rules\n"
        "- MVC with bundles: controller, entity, repository, form, twig\n"
        "- Doctrine ORM with annotations/attributes\n"
        "- YAML or PHP attributes for routing\n"
        "- Dependency injection via autowiring\n"
        "- Twig templating: {{ }}, {% %}, template inheritance\n"
        "- Maker bundle: bin/console make:controller, make:entity\n"
        "- Use Symfony forms for input handling\n"
    ),
    "flask": (
        "## Flask / Python Development Rules\n"
        "- Minimal app factory pattern: create_app()\n"
        "- Flask-SQLAlchemy for ORM, Flask-Migrate (Alembic) for migrations\n"
        "- Blueprints for modular route organization\n"
        "- @app.route() decorators, methods=['GET', 'POST']\n"
        "- Jinja2 templates with template inheritance\n"
        "- WTForms for form handling and CSRF protection\n"
        "- Use Flask-Login for session auth\n"
    ),
    "rust": (
        "## Rust Development Rules\n"
        "- Use Cargo: cargo new, cargo build, cargo run, cargo test\n"
        "- Ownership and borrowing: & for references, &mut for mutable\n"
        "- Result<T, E> for recoverable errors, unwrap() sparingly\n"
        "- Use Option<T> for nullable values, pattern matching\n"
        "- Traits for shared behavior, derive macros for boilerplate\n"
        "- Modules and crates for organization\n"
    ),
}

_DEFAULT_FRAMEWORK_RULES: dict[str, str] = {
    "PHP": (
        "## PHP Development Rules\n"
        "- Use PSR-4 autoloading with Composer\n"
        "- Follow PSR-12 coding style\n"
        "- Use .php extension, <?php opening tag\n"
        "- Type hints for function parameters and return types\n"
    ),
    "Python": (
        "## Python Development Rules\n"
        "- Follow PEP 8 style: snake_case, 4-space indent\n"
        "- Type hints for all function signatures\n"
        "- Use virtual environments (venv) for dependencies\n"
        "- requirements.txt or pyproject.toml for packages\n"
        "## Python Common Pitfalls\n"
        "- Pin `bcrypt==4.0.1` when using `passlib[bcrypt]` — newer bcrypt breaks passlib\n"
        "- Always use `datetime.now(timezone.utc)` for timezone-aware datetimes\n"
        "- Use `UUID` type (not str) in Pydantic models for SQLAlchemy UUID columns\n"
        "- Verify import paths match actual directory structure before writing code\n"
        "- Passwords must be truncated to 72 bytes before bcrypt hashing\n"
        "- Use `pytest` fixtures with `yield` for proper database session teardown\n"
        "- For SQLite with SQLAlchemy, use synchronous engine (not async)\n"
    ),
    "JavaScript": (
        "## JavaScript/TypeScript Development Rules\n"
        "- Use ES modules (import/export) not CommonJS\n"
        "- Prefer const over let, never use var\n"
        "- Use async/await for promises\n"
        "- package.json for dependencies, scripts for automation\n"
    ),
    "Java": (
        "## Java Development Rules\n"
        "- Use Maven (pom.xml) or Gradle (build.gradle) for builds\n"
        "- Follow Java naming conventions: PascalCase classes, camelCase methods\n"
        "- Use Optional<T> to avoid null pointer exceptions\n"
        "- Streams and lambdas for collection processing\n"
        "- Unit tests with JUnit 5, mocking with Mockito\n"
    ),
    "Ruby": (
        "## Ruby Development Rules\n"
        "- Follow Ruby style: snake_case methods, 2-space indent\n"
        "- Use Gemfile for dependencies, bundle exec for commands\n"
        "- Blocks and yield for iteration and callbacks\n"
        "- RSpec for testing, let/let! for test setup\n"
    ),
    "Go": (
        "## Go Development Rules\n"
        "- gofmt formatting mandatory\n"
        "- Error handling: if err != nil { return err }\n"
        "- Use go mod for modules, go get for dependencies\n"
    ),
}


def _detect_framework_from_task(task: str) -> tuple[str, str] | None:
    """Detect framework and language from the user's task description.

    Returns (framework_key, language) or None if no framework detected.
    """
    lowered = task.lower()
    for key, pattern, lang in _TASK_FRAMEWORK_PATTERNS:
        if re.search(pattern, lowered):
            return key, lang
    return None


def _framework_prompt_section(framework_key: str, language: str) -> str:
    """Return framework-specific rules for the system prompt."""
    rules = _FRAMEWORK_RULES.get(framework_key)
    if rules:
        return rules
    return _DEFAULT_FRAMEWORK_RULES.get(language, "")


def _detect_framework(self) -> str:
    """Detect project framework from config files."""
    cwd = Path.cwd()
    detectors = [
        ("Next.js", ["next.config.js", "next.config.ts", "next.config.mjs"]),
        ("React + Vite", ["vite.config.ts", "vite.config.js"]),
        ("Vue", ["vue.config.js"]),
        ("Svelte", ["svelte.config.js"]),
        ("Angular", ["angular.json"]),
        ("Django", ["manage.py"]),
        ("Flask", ["app.py", "wsgi.py"]),
        ("FastAPI", ["main.py"]),
        ("Express", ["app.js", "server.js"]),
        ("Go", ["go.mod"]),
        ("Rust", ["Cargo.toml"]),
        ("Flutter", ["pubspec.yaml"]),
    ]
    for fw, files in detectors:
        if any((cwd / f).exists() for f in files):
            if fw == "FastAPI":
                if _has_fastapi_dependency(cwd):
                    return fw
                continue
            if fw == "React + Vite":
                if (cwd / "vite.config.ts").exists() or (cwd / "vite.config.js").exists():
                    if (cwd / "src" / "App.vue").exists() or any((cwd / f).exists() for f in ["vue.config.js"]):
                        return "Vue + Vite"
                return fw
            return fw
    pkg_json = cwd / "package.json"
    if pkg_json.exists():
        try:
            pkg = json.loads(pkg_json.read_text())
            deps = {**pkg.get("dependencies", {}), **pkg.get("devDependencies", {})}
            if "next" in deps: return "Next.js"
            if "react" in deps: return "React"
            if "vue" in deps: return "Vue"
            if "svelte" in deps: return "Svelte"
            if "express" in deps: return "Express"
        except json.JSONDecodeError:
            pass
    return "vanilla"


def _has_fastapi_dependency(cwd: Path) -> bool:
    """Return True if fastapi appears in pyproject.toml or requirements.txt."""
    for candidate in ["pyproject.toml", "requirements.txt", "requirements-dev.txt"]:
        path = cwd / candidate
        if path.exists():
            try:
                if "fastapi" in path.read_text(encoding="utf-8").lower():
                    return True
            except OSError:
                pass
    return False


def _detect_package_manager(self) -> str | None:
    """Detect the project package manager from lock files and config.

    Checks for pnpm, yarn, bun, npm, pip, pipenv, go, and cargo markers.

    Returns:
        Package manager name or None if no known manager is detected.
    """
    cwd = Path.cwd()
    if (cwd / "package.json").exists():
        if (cwd / "pnpm-lock.yaml").exists(): return "pnpm"
        if (cwd / "yarn.lock").exists(): return "yarn"
        if (cwd / "bun.lockb").exists(): return "bun"
        return "npm"
    if (cwd / "pyproject.toml").exists(): return "pip"
    if (cwd / "Pipfile").exists(): return "pipenv"
    if (cwd / "go.mod").exists(): return "go"
    if (cwd / "Cargo.toml").exists(): return "cargo"
    return None


def _get_current_task(self) -> str:
    """Extract the current user task from conversation messages."""
    if self._messages:
        for msg in reversed(self._messages):
            content = msg.get("content")
            if msg.get("role") == "user" and isinstance(content, str):
                return content
    return ""


def _build_system_prompt(self) -> str:
    """Build a rich system prompt aware of the project stack and the user's current task."""
    fw = self._framework or self._detect_framework()
    pkg_mgr = self._detect_package_manager() or "auto"
    cwd = Path.cwd()
    cwd_name = cwd.name

    has_frontend = any(
        (cwd / d).is_dir()
        for d in ["frontend", "client", "web", "app", "src/app", "src/pages"]
    )
    has_backend = any(
        (cwd / d).is_dir()
        for d in ["backend", "server", "api", "src/api"]
    )
    has_docker = (cwd / "docker-compose.yml").exists() or (cwd / "docker-compose.yaml").exists()
    has_tests = any(
        (cwd / d).is_dir()
        for d in ["tests", "test", "__tests__", "spec"]
    )

    stack_parts: list[str] = []
    if has_frontend and has_backend:
        stack_parts.append("fullstack monorepo")
    if has_docker:
        stack_parts.append("Docker Compose")
    if has_tests:
        stack_parts.append("test suite present")
    stack_line = f"Stack: {', '.join(stack_parts)}" if stack_parts else ""

    # ── Detect framework from the current task ──────────────────
    current_task = _get_current_task(self)
    detected = _detect_framework_from_task(current_task)
    task_fw_key = detected[0] if detected else None
    task_lang = detected[1] if detected else None

    context = f"""You are WIDDX, an expert AI software engineer working in the terminal.

Project: {cwd_name}  |  Framework: {fw}  |  Package manager: {pkg_mgr}
{stack_line}

## Tools
- Read(file_path, offset?, limit?)          — read a file; always read before editing
- Write(file_path, content, overwrite?)     — create or overwrite a file
- Edit(file_path, old_string, new_string)   — precise string replacement (include 3+ lines of context)
- Grep(pattern, path?)                      — regex search across files
- Glob(pattern, path?)                      — find files by pattern
- ListDir(path)                             — explore directory structure
- Bash(command, timeout?)                   — run shell commands
- WebSearch(query)                          — search documentation or the web

## Workflow
1. **Understand intent first.** Before writing any code, think about what the user really wants. For new projects, ask about architecture, features, and preferences before starting. For ambiguous requests, seek clarification.
2. **Plan before building.** For anything beyond a simple fix, outline your approach. Share the plan with the user briefly so they can confirm.
3. **Always Read a file before editing** — never guess its contents.
4. Use ListDir and Glob to explore unfamiliar directories first.
5. Write complete, working code — no placeholders, no TODOs, no "..." ellipsis.
6. After writing code, verify it with Bash (run it, lint it, or test it).
7. If a test suite exists, run it after any change.
8. For fullstack tasks: backend first → frontend → wire together.
9. Use Edit for targeted changes; use Write(overwrite=true) only for full rewrites.
10. When a command fails, read the error carefully before retrying.
11. Prefer small, focused changes over large rewrites.
12. Never truncate file content when writing — always write the complete file.
"""

    # ── Inject framework-specific rules ─────────────────────────
    if task_fw_key and task_lang:
        fw_section = _framework_prompt_section(task_fw_key, task_lang)
        if fw_section:
            context += "\n" + fw_section
    elif fw != "vanilla":
        context += f"\n## Framework\nThis project uses {fw}. Use the appropriate conventions for this framework.\n"

    context += f"""
## Project context
{self._project_context or "(run /index to scan project)"}
"""

    if self._project_md:
        context += f"\n## Project Memory (WIDDX.md)\n{self._project_md[:4000]}"

    skill_manager = getattr(self, "_skill_manager", None)
    if skill_manager:
        task = getattr(self, "_current_task", "") or ""
        active_skills = skill_manager.match_skills(task)
        if active_skills:
            context += "\n\n## Relevant Skills\n" + "\n\n".join(active_skills)

        missing = skill_manager.missing_domains(task)
        if missing:
            context += (
                "\n\n## Unfamiliar Technologies Detected\n"
                + ", ".join(missing)
                + f"\nSuggest: `/bootstrap {missing[0]}` to learn this technology."
            )

    return context.strip()
