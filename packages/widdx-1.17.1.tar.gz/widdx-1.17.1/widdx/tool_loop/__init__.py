"""Tool loop — Claude Code pattern: model ↔ tools ↔ model via native Function Calling.

Experience:
  - Build-Test-Fix loop: generate → lint → test → fix → repeat
  - Multi-agent collaboration for complex tasks
  - Framework-aware prompts
  - Quality gates before task completion
  - Streaming output for real-time feedback
"""
from __future__ import annotations

import json
import logging
import sys
import time
from pathlib import Path

logger = logging.getLogger("widdx.tool_loop")

from ..git_ops import GitOps
from ..hooks import HookManager
from ..mcp import MCPRegistry
from ..permissions import PermissionManager
from ..repair_memory import RepairMemory
from ..semantic_index import SemanticIndex
from ..skills import SkillManager
from ..verifier import ProjectVerifier
from .display import (
    _format_result,
    _get_console,
    _render_diff,
    _reshape_line,
    _summarize_final,
    print_tool_call,
    print_tool_result,
)
from .system_prompt import _build_system_prompt, _detect_framework, _detect_package_manager
from .tools import TOOL_DEFINITIONS, _execute_tool, _parse_args, _verify_file


class ToolLoop:
    """World-class agent loop with Build-Test-Fix cycle.

    Claude Code pattern:
      user message → model decides: tool_call or text_response
      if tool_call → execute locally → feed result back → repeat
      if text_response → verify quality gates → return to user
    """

    # ── Injected methods from sub-modules ──────────────────────────
    _detect_framework = _detect_framework
    _detect_package_manager = _detect_package_manager
    _build_system_prompt = _build_system_prompt
    _parse_args = _parse_args
    _execute_tool = _execute_tool
    _verify_file = staticmethod(_verify_file)
    _summarize_final = _summarize_final
    _format_result = _format_result

    TOOL_DEFINITIONS = TOOL_DEFINITIONS

    def __init__(self, router, max_steps: int = 100,
                 context_limit: int = 128000, auto_compact_pct: int = 70,
                 auto_commit: bool = True) -> None:
        """Initialize the tool loop with router, permissions, and subsystems.

        Sets up PermissionManager, SkillManager, RepairMemory,
        ProjectVerifier, HookManager, MCPRegistry, and conversation state.

        Args:
            router: The LLM router instance.
            max_steps: Maximum tool-call steps per run (default 100).
            context_limit: Token limit before forced compaction (default 128K).
            auto_compact_pct: Auto-compact when context reaches this % (default 70).
            auto_commit: Auto-commit file changes after the run (default True).
        """
        self._router = router
        self._max_steps = max_steps
        self._context_limit = context_limit
        self._auto_compact_pct = auto_compact_pct
        self._auto_commit = auto_commit
        auto = not self._router.config.get("tools", {}).get("shell_require_approval", False)
        self._permissions = PermissionManager(auto_approve=auto)
        self._messages: list[dict] = []
        self._project_context = ""
        self._framework: str | None = None
        self._created_files: list[str] = []
        self._edited_files: list[str] = []
        self._test_attempts = 0
        self._max_test_attempts = 3
        self._tool_calls_count = 0
        self._total_cost = 0
        self._backups: dict[str, str] = {}
        # Tracks consecutive identical errors per (tool, args) key for retry loop.
        self._tool_error_counts: dict[str, dict] = {}
        self._project_md: str = ""
        self._git = GitOps()
        self._skill_manager = SkillManager()
        self._skill_manager.load()
        self._repair_memory = RepairMemory(
            self._router.memory,
            getattr(self._router, 'config', None),
        )
        self._verifier = ProjectVerifier(
            router=self._router, repair_memory=self._repair_memory,
        )
        self._hook_manager = HookManager(router=self._router)
        self._hook_manager.load()
        mcp_cfg_path = self._router.config.get("mcp", {}).get("config_path", "~/.widdx/mcp.json")
        self._mcp_registry = MCPRegistry(config_path=mcp_cfg_path)
        self._mcp_registry.load()
        self._sem_index: SemanticIndex | None = None

    def _ensure_semantic_index(self) -> SemanticIndex:
        """Lazy-init semantic code search. Indexes project on first call."""
        if self._sem_index is not None:
            return self._sem_index
        self._sem_index = SemanticIndex()
        try:
            stats = self._sem_index.index_project(
                Path.cwd(), batch_size=100
            )
            if stats["chunks"] > 0:
                logger.debug(
                    "Semantic index: %d files, %d chunks in %.1fs",
                    stats["files"], stats["chunks"], stats["elapsed"]
                )
        except ImportError:
            logger.debug("Semantic search unavailable (missing deps)")
        return self._sem_index

    def set_project_context(self, context: str) -> None:
        """Store the project context summary for system prompts."""
        self._project_context = context

    def set_framework(self, framework: str) -> None:
        """Override the auto-detected project framework."""
        self._framework = framework

    def set_project_md(self, content: str) -> None:
        """Store the project memory (WIDDX.md) content for system prompts."""
        self._project_md = content

    def set_skill_manager(self, skill_manager: SkillManager) -> None:
        """Replace the default SkillManager — useful for dependency injection in tests."""
        self._skill_manager = skill_manager

    def set_hook_manager(self, hook_manager: HookManager) -> None:
        """Replace the default HookManager — useful for dependency injection in tests."""
        self._hook_manager = hook_manager

    def set_mcp_registry(self, mcp_registry: MCPRegistry) -> None:
        """Replace the default MCPRegistry — useful for dependency injection in tests."""
        self._mcp_registry = mcp_registry

    def shutdown(self) -> None:
        """Clean up resources: disconnect MCP servers, etc."""
        try:
            self._mcp_registry.disconnect()
        except Exception:
            pass

    def clear_context(self) -> None:
        """Reset conversation state — messages, file tracking, error counts."""
        self._messages.clear()
        self._created_files.clear()
        self._edited_files.clear()
        self._backups.clear()
        self._tool_error_counts.clear()
        self._test_attempts = 0

    # ------------------------------------------------------------------
    # Main loop
    # ------------------------------------------------------------------

    def run(self, user_message: str, conversation_history: list[dict] | None = None) -> str:
        """Full agent loop with streaming output and persistent context."""
        if conversation_history:
            self._messages = list(conversation_history)
        else:
            self._messages = []
        self._messages.append({"role": "user", "content": user_message})

        self._created_files.clear()
        self._edited_files.clear()
        self._backups.clear()
        self._test_attempts = 0
        self._tool_calls_count = 0
        self._total_cost = 0
        self._tool_error_counts.clear()

        c = _get_console()
        start_time = time.time()

        for step in range(self._max_steps):
            system = self._build_system_prompt()

            # ── Semantic search injection ──────────────────────────
            if step == 0:
                try:
                    sem = self._ensure_semantic_index()
                    if sem.is_ready and sem.chunk_count > 0:
                        context = sem.search_context(
                            user_message, top_k=6, max_chars=6000,
                        )
                        if context:
                            system = f"{system}\n\n## Relevant Code (semantic search)\n{context}"
                except Exception:
                    pass  # Never block the loop on search failure

            # ── Context size management ──────────────────────────
            msg_tokens = self._router._estimate_tokens(self._messages)
            sys_tokens = self._router._estimate_tokens([{"role": "system", "content": system}])
            total_tokens = msg_tokens + sys_tokens
            pct = int(total_tokens / self._context_limit * 100)
            warp_pct = self._auto_compact_pct
            if pct >= 95:
                c.print(f"\n  [error]⚠ Context at {pct}% ({total_tokens//1000}K/{self._context_limit//1000}K) — too large.[/]")
                return f"Context too large ({total_tokens} tokens). Use /compact and retry."
            if pct >= warp_pct:
                c.print(f"\n  [warning]⚠ Context at {pct}% — auto-compacting...[/]")
                report = self.compact()
                c.print(f"  [dim]{report}[/]")
                # Re-estimate after compact
                msg_tokens = self._router._estimate_tokens(self._messages)
                sys_tokens = self._router._estimate_tokens([{"role": "system", "content": system}])
                total_tokens = msg_tokens + sys_tokens
                pct = int(total_tokens / self._context_limit * 100)
            if pct >= 80:
                c.print(f"\n  [warning]⚠ Context at {pct}% — consider /compact when convenient.[/]")

            # ── Stream the LLM response ───────────────────────────
            all_tools = TOOL_DEFINITIONS + self._mcp_registry.tool_definitions()
            stream = self._router.call_with_tools_streaming(
                system, self._messages, all_tools
            )

            tool_calls = []
            full_text = ""
            first_token = True
            _line_buffer = ""
            _stream_renderer = None

            # ── Animated thinking indicator with phase cycling ─────
            try:
                from rich.progress import Progress, SpinnerColumn, TextColumn
                _thinking_phases = [
                    "Analyzing task...",
                    "Generating approach...",
                    "Writing solution...",
                    "Reviewing output...",
                ]
                _phase_idx = 0
                _thinking_progress = Progress(
                    SpinnerColumn(spinner_name="dots12", style="brand"),
                    TextColumn("[dim]{}[/]"),
                    console=c,
                    transient=True,
                )
                _thinking_task = _thinking_progress.add_task(
                    _thinking_phases[0], total=None
                )
                _thinking_progress.start()
                _has_thinking_spinner = True
            except Exception as _e:
                logger.debug("Thinking spinner unavailable: %s", _e)
                c.print("\n[brand]\u25c6[/] ", end="")
                sys.stdout.flush()
                _has_thinking_spinner = False

            for event in stream:
                etype = event.get("type", "")

                if etype == "error":
                    if _has_thinking_spinner:
                        _thinking_progress.stop()
                    c.print(f"\n[error]✗ {event['content']}[/]")
                    return f"Error: {event['content']}"

                if etype == "text":
                    if first_token:
                        if _has_thinking_spinner:
                            _thinking_progress.stop()
                        from .. import ui
                        _stream_renderer = ui.LiveStreamRenderer()
                        _stream_renderer.start()
                        c.print()
                        first_token = False
                    token = event["content"]
                    full_text += token
                    _line_buffer += token

                    # Cycle thinking phase every ~50 chars
                    if _has_thinking_spinner and len(full_text) < 5 and len(full_text.replace("\n", "")) % 3 == 0:
                        try:
                            _phase_idx = (_phase_idx + 1) % len(_thinking_phases)
                            _thinking_progress.update(
                                _thinking_task,
                                description=_thinking_phases[_phase_idx],
                            )
                        except Exception as _e:
                            logger.debug("Stream renderer update failed: %s", _e)

                    if _stream_renderer is not None:
                        _stream_renderer.feed(token)
                    # No else — if renderer exists, it handles all output

                if etype == "tool_call":
                    if _stream_renderer is not None:
                        _stream_renderer.finish()
                        _stream_renderer = None
                    tool_calls.append(event)

                if etype == "done":
                    usage = event.get("usage", {})
                    if usage:
                        inp = usage.get("input", 0)
                        out = usage.get("output", 0)
                        pricing = self._router.PRICING.get(
                            self._router.executor_model,
                            {"input": 0.27, "output": 1.10}
                        )
                        self._total_cost += (
                            (inp / 1_000_000) * pricing["input"]
                            + (out / 1_000_000) * pricing["output"]
                        )
                    # Stop live renderer — content already on screen
                    if _stream_renderer is not None:
                        _stream_renderer.finish()
                        _stream_renderer = None
                    break

            # ── Stop thinking spinner if still running ───────────
            if _has_thinking_spinner:
                try:
                    _thinking_progress.stop()
                except Exception as _e:
                    logger.debug("Failed to stop thinking spinner: %s", _e)

            # ── No tool calls → return final text ────────────────
            if not tool_calls:
                if full_text:
                    self._messages.append({"role": "assistant", "content": full_text})
                    elapsed = time.time() - start_time
                    # Text already rendered by LiveStreamRenderer during streaming.
                    # _format_result must NOT re-print it — only show the footer.
                    return self._format_result(full_text, elapsed, step,
                                               use_markdown=False)
                return "Done."

            # ── Tool calls detected ───────────────────────────────
            self._tool_calls_count += len(tool_calls)

            assistant_msg: dict = {"role": "assistant", "content": full_text or None}
            assistant_msg["tool_calls"] = [
                {"id": tc.get("id", f"call_{i}"), "type": "function",
                 "function": {"name": tc["name"], "arguments": tc["arguments"]}}
                for i, tc in enumerate(tool_calls)
            ]
            self._messages.append(assistant_msg)

            for i, tc in enumerate(tool_calls):
                tool_name = tc["name"]
                raw_args = tc.get("arguments", "{}")
                args = self._parse_args(raw_args)

                # Claude Code style: ⏺ ToolName(arg)
                print_tool_call(tool_name, args)

                tool_output = self._execute_tool(tool_name, raw_args)

                # ── Smart retry: stop on repeated identical errors ──
                tool_key = f"{tool_name}:{raw_args}"
                if "error" in tool_output:
                    prev = self._tool_error_counts.get(tool_key, {"count": 0, "msg": ""})
                    same_error = prev["msg"] == tool_output["error"]
                    if same_error and prev["count"] >= 1:
                        c.print(
                            f"  [dim]⎿[/]  [error]Same error twice — stopping to avoid loop[/]\n"
                            f"  [dim]   {_reshape_line(tool_output['error'][:80])}[/]"
                        )
                        self._messages.append({
                            "role": "tool",
                            "tool_call_id": tc.get("id", f"call_{i}"),
                            "content": json.dumps({
                                "error": tool_output["error"],
                                "fatal": True,
                                "note": "This tool failed twice with the same error. Do NOT retry. Explain the problem to the user.",
                            }, ensure_ascii=False),
                        })
                        continue
                    self._tool_error_counts[tool_key] = {
                        "count": prev["count"] + 1,
                        "msg": tool_output["error"],
                    }
                else:
                    self._tool_error_counts.pop(tool_key, None)

                # ⎿ result line
                print_tool_result(tool_name, tool_output)

                # Inline diff for Write (overwrite) and Edit
                if isinstance(tool_output, dict) and "_diff_old" in tool_output:
                    _render_diff(
                        tool_output["_diff_old"],
                        tool_output["_diff_new"],
                        tool_output.get("_diff_path", ""),
                    )

                # Verification failure — surface immediately
                verification = tool_output.get("verification") if isinstance(tool_output, dict) else None
                if verification and "error" in verification:
                    c.print("  [dim]⎿[/]  [warning]Verification failed[/]")
                    if verification.get("output"):
                        for vline in verification["output"].splitlines()[:5]:
                            c.print(f"  [dim]   {_reshape_line(vline)}[/]")

                # Strip internal display keys before sending to LLM
                llm_output = {
                    k: v for k, v in tool_output.items()
                    if not k.startswith("_diff_")
                } if isinstance(tool_output, dict) else tool_output

                self._messages.append({
                    "role": "tool",
                    "tool_call_id": tc.get("id", f"call_{i}"),
                    "content": json.dumps(llm_output, ensure_ascii=False),
                })

        if self._auto_commit and self._git.is_repo and self._git.has_changes():
            self._auto_commit_changes()

        return self._summarize_final()

    # ------------------------------------------------------------------
    # Auto-commit
    # ------------------------------------------------------------------

    def _auto_commit_changes(self) -> None:
        """Auto-commit file changes as a single per-run commit."""
        from ..ui.console import get_console
        c = get_console()

        # ── Ask first time in session ─────────────────────────────────
        if not hasattr(self, '_auto_commit_confirmed'):
            c.print("\n  [warning]Auto-commit will create a git commit.[/]")
            c.print(f"  Files: {len(self._edited_files)} edited, {len(self._created_files)} created")
            choice = input("  Allow auto-commit? [y/N]: ").strip().lower()
            if choice != 'y':
                return
            self._auto_commit_confirmed = True

        first_user = next(
            (m.get("content", "") for m in self._messages
             if m.get("role") == "user" and isinstance(m.get("content"), str)),
            None,
        )
        title = (first_user or "widdx: automated changes").strip()[:72]
        msg = f"widdx: {title}\n\nAuto-commit after {self._tool_calls_count} tool calls ({len(self._edited_files)} files edited, {len(self._created_files)} created)."
        result = self._git.commit(msg, include_all=False)
        if result.get("ok"):
            c.print(f"  [dim]⎿[/] [green]✔ Auto-committed: {title}[/]")
        else:
            c.print(f"  [dim]⎿[/] [warning]Auto-commit skipped: {result.get('error', 'unknown')}[/]")

    # ------------------------------------------------------------------
    # Compaction
    # ------------------------------------------------------------------

    def compact(self) -> str:
        """Summarize conversation history to save context space.

        Preserves the last 8 messages (instead of 6) for better continuity.
        Tool-call results carrying file diffs are also kept regardless of position.
        """
        if len(self._messages) <= 8:
            return "Conversation is already short — no compaction needed."

        # Keep last 8 messages + any messages with file diff content
        keep = self._messages[-8:]
        to_summarize = self._messages[:-8]

        # Also preserve messages containing verification or diff content
        preserved = []
        still_to_summarize = []
        for msg in to_summarize:
            content = msg.get("content", "")
            if isinstance(content, str) and any(kw in content for kw in ("diff --git", "Verification", "verified")):
                preserved.append(msg)
            else:
                still_to_summarize.append(msg)
        to_summarize = still_to_summarize

        if not to_summarize:
            return "Nothing to compact."

        history_text = ""
        for msg in to_summarize:
            role = msg.get("role", "?")
            content = msg.get("content", "")
            if content and isinstance(content, str):
                history_text += f"[{role}] {content[:200]}\n"

        prompt = (
            "Summarize this coding conversation history in 3-5 bullet points. "
            "Include what was built, key decisions, and current state. "
            "Be concise — this will replace the full history to save context.\n\n"
            f"{history_text[:6000]}"
        )

        result = self._router.call_executor(
            "You are a conversation summarizer. Return only the summary, no preamble.",
            prompt,
            max_tokens=1024,
        )

        summary_text = result.get("text", "") if "text" in result else ""
        if not summary_text or "error" in result:
            return "Compaction failed — try again or use /clear."

        old_tokens = self._router._estimate_tokens(to_summarize)

        self._messages = (
            preserved
            + [
                {"role": "user", "content": f"[Conversation summary from earlier]\n{summary_text}"},
                {"role": "assistant", "content": "Understood. I'll use this context for the rest of the session."},
            ]
            + keep
        )

        saved = old_tokens
        return f"Compacted {len(to_summarize)} messages → ~{saved} tokens saved. Preserved {len(preserved)} important messages."
