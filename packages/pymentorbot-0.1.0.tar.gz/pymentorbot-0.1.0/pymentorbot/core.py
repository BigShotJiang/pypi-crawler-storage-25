EXPLANATIONS = {
    "lambda": "lambda creates a small anonymous function.",
    "kwargs": "**kwargs collects extra named arguments into a dictionary.",
    "args": "*args collects extra positional arguments into a tuple.",
    "yield": "yield returns generator values one at a time."
}

def explain(topic):
    key = str(topic).strip().lower()
    return EXPLANATIONS.get(
        key,
        f"Sorry, no explanation found for '{topic}'. Try: lambda, kwargs, args, yield"
    )
