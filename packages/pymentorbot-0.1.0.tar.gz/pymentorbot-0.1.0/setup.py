from setuptools import setup, find_packages

setup(
    name="pymentorbot",
    version="0.1.0",
    packages=find_packages(),
    entry_points={"console_scripts": ["pymentorbot=pymentorbot_cli:main"]},
)
