/**
 * Estonian translation for bootstrap-datepicker
 * Ando Roots <https: //github.com/anroots>
 * Fixes by Illimar Tambek <<https: //github.com/ragulka>
 */
(function () {
  Datepicker.locales.et = {
    days: ["Pühapäev", "Esmaspäev", "Teisipäev", "Kolmapäev", "Neljapäev", "Reede", "Laupäev"],
    daysShort: ["Pühap", "Esmasp", "Teisip", "Kolmap", "Neljap", "Reede", "Laup"],
    daysMin: ["P", "E", "T", "K", "N", "R", "L"],
    months: ["Jaanuar", "Veebruar", "Märts", "Aprill", "Mai", "Juuni", "Juuli", "August", "September", "Oktoober", "November", "Detsember"],
    monthsShort: ["Jaan", "Veebr", "Märts", "Apr", "Mai", "Juuni", "Juuli", "Aug", "Sept", "Okt", "Nov", "Dets"],
    today: "Täna",
    clear: "Tühjenda",
    weekStart: 1,
    format: "dd.mm.yyyy"
  };
}());
