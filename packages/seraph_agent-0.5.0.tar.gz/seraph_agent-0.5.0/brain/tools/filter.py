"""
Seraph Smart Tool Filter — only send relevant tools to the LLM.

Instead of sending all 25+ tool schemas (wasting ~2K tokens every call),
analyze the user's message and only include tools that are relevant.
Saves 30-50% on input tokens.
"""

import re
import logging
from typing import List, Dict

logger = logging.getLogger("seraph.tools.filter")

# Keyword → tool mapping
TOOL_KEYWORDS = {
    "terminal": ["run", "execute", "command", "shell", "bash", "cmd", "install", "pip", "npm", "apt"],
    "read_file": ["read", "file", "open", "cat", "show me", "contents of", "what's in"],
    "write_file": ["write", "create", "save", "make a file", "generate", "build"],
    "list_files": ["files", "directory", "folder", "ls", "list", "what files"],
    "web_search": ["search", "google", "find", "look up", "what is", "who is", "when did"],
    "web_fetch": ["fetch", "url", "website", "page", "scrape", "download page"],
    "ssh": ["ssh", "server", "vps", "remote", "deploy", "systemctl", "journalctl", "botuser"],
    "git": ["git", "commit", "push", "pull", "branch", "repo", "clone"],
    "git_clone": ["clone", "repo"],
    "generate_image": ["image", "picture", "photo", "draw", "generate image", "dall-e", "create image"],
    "browse": ["browse", "screenshot", "open page", "visit", "browser"],
    "text_to_speech": ["speak", "say", "voice", "tts", "read aloud", "audio"],
    "transcribe": ["transcribe", "speech to text", "whisper", "audio to text"],
    "audit_file": ["audit", "check code", "review code", "bugs", "issues"],
    "audit_directory": ["audit all", "audit directory", "audit project"],
    "send_email": ["email", "send email", "mail"],
    "query_sqlite": ["database", "sqlite", "sql", "query", "select", "table"],
    "health_check": ["health", "status", "diagnostics"],
    "verify_claim": ["verify", "fact check", "is it true", "grounding"],
    "import_api": ["openapi", "swagger", "api spec", "import api"],
    "export_conversation": ["export", "download chat", "save conversation"],
    "usage_stats": ["usage", "cost", "tokens", "spending"],
}

# Tools that should ALWAYS be available (general purpose)
ALWAYS_INCLUDE = {"terminal", "write_file", "read_file", "web_search"}

# Max tools to send (balance between capability and token cost)
MAX_TOOLS = 12


def filter_tools(message: str, all_tool_schemas: List[Dict]) -> List[Dict]:
    """
    Filter tool schemas to only include relevant ones based on the message.

    Returns a subset of tool schemas that match the user's intent.
    """
    if not message or not all_tool_schemas:
        return all_tool_schemas

    msg_lower = message.lower()
    relevant_names = set(ALWAYS_INCLUDE)

    # Match keywords
    for tool_name, keywords in TOOL_KEYWORDS.items():
        for keyword in keywords:
            if keyword in msg_lower:
                relevant_names.add(tool_name)
                break

    # If very few matches, include all (user might be vague)
    if len(relevant_names) <= len(ALWAYS_INCLUDE):
        # Check if message is a question or conversation (no tools needed)
        question_words = ["what", "why", "how", "when", "where", "who", "explain", "tell me"]
        is_question = any(msg_lower.startswith(w) for w in question_words)
        if is_question and len(msg_lower) < 100:
            return []  # No tools for simple questions — saves all tool tokens

    # Filter schemas
    filtered = [s for s in all_tool_schemas if s.get("function", {}).get("name") in relevant_names]

    # Cap at MAX_TOOLS
    if len(filtered) > MAX_TOOLS:
        filtered = filtered[:MAX_TOOLS]

    logger.debug(f"Tool filter: {len(all_tool_schemas)} -> {len(filtered)} tools for: {msg_lower[:50]}")
    return filtered
