"""
Seraph Terminal Tool — execute shell commands.
"""

import subprocess
import logging
import os
from pathlib import Path
from .registry import register_tool

logger = logging.getLogger("seraph.tools.terminal")

# Working directory for the agent
WORK_DIR = Path.home() / ".seraph" / "workspace"
WORK_DIR.mkdir(parents=True, exist_ok=True)


BLOCKED_PATTERNS = [
    "rm -rf /", "rm -rf /*", "rm -rf ~", "rm -rf $HOME",
    "format ", "del /f /s /q C:", "mkfs", ":(){:|:&};:",
    "dd if=/dev/zero", "dd if=/dev/random",
    "> /dev/sda", "chmod -R 777 /",
    "wget -O- | sh", "curl | sh", "curl | bash",
    "echo '' > /etc/passwd", "cat /etc/shadow",
    ":(){ :|:& };:", "fork bomb",
    "shutdown", "reboot", "poweroff", "halt",
    "DROP DATABASE", "DROP TABLE", "TRUNCATE TABLE",
    "sudo rm", "sudo dd", "sudo mkfs",
]

BLOCKED_SUBSTRINGS_CASE_INSENSITIVE = [
    "/etc/shadow", "/etc/passwd",
    "authorized_keys",
]


def run_command(command: str, working_directory: str = "") -> dict:
    """Execute a shell command with security guardrails."""
    cwd = working_directory or str(WORK_DIR)

    # Security: block dangerous commands
    for b in BLOCKED_PATTERNS:
        if b in command:
            return {"error": f"BLOCKED: dangerous command pattern '{b}' detected", "blocked": True}

    cmd_lower = command.lower()
    for b in BLOCKED_SUBSTRINGS_CASE_INSENSITIVE:
        if b in cmd_lower:
            return {"error": f"BLOCKED: access to sensitive path '{b}'", "blocked": True}

    # Security: run preemptive checks if available
    try:
        from agent.preemptive_checks import run_preemptive_checks, should_block, format_checks
        checks = run_preemptive_checks("terminal", {"command": command})
        if should_block(checks):
            return {"error": format_checks(checks), "blocked": True, "checks": checks}
    except ImportError:
        pass

    logger.info(f"Executing: {command} (cwd: {cwd})")

    try:
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=60,
            cwd=cwd,
        )

        output = result.stdout
        if result.stderr:
            output += "\n" + result.stderr

        # Cap output to prevent token overflow
        if len(output) > 5000:
            output = output[:5000] + "\n... (truncated)"

        return {
            "stdout": result.stdout[:5000],
            "stderr": result.stderr[:2000],
            "exit_code": result.returncode,
            "command": command,
        }

    except subprocess.TimeoutExpired:
        return {"error": f"Command timed out after 60s: {command}"}
    except Exception as e:
        return {"error": str(e)}


# Register the tool
register_tool(
    name="terminal",
    description="Execute a shell command on the local machine. Use for: running scripts, installing packages, git operations, file manipulation, system commands. Returns stdout, stderr, and exit code.",
    parameters={
        "type": "object",
        "properties": {
            "command": {
                "type": "string",
                "description": "The shell command to execute"
            },
            "working_directory": {
                "type": "string",
                "description": "Working directory (default: ~/.seraph/workspace)"
            }
        },
        "required": ["command"]
    },
    handler=run_command,
)
