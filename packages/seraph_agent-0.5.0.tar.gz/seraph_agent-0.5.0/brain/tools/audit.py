"""
Seraph Audit Tool — the self-auditing loop.

Reads code, finds issues, scores, fixes, re-audits until clean.
This is what makes Seraph different from every other agent platform.
"""

import os
import json
import logging
import subprocess
import time
from pathlib import Path
from .registry import register_tool

logger = logging.getLogger("seraph.tools.audit")

WORK_DIR = Path.home() / ".seraph" / "workspace"


def audit_file(path: str) -> dict:
    """
    Audit a single file for code quality issues.

    Checks for:
    - Syntax errors
    - Common bug patterns
    - Missing error handling
    - Security issues
    - Code quality
    """
    try:
        file_path = Path(path)
        if not file_path.is_absolute():
            file_path = WORK_DIR / path

        if not file_path.exists():
            return {"error": f"File not found: {path}"}

        content = file_path.read_text(encoding="utf-8", errors="replace")
        ext = file_path.suffix.lower()
        issues = []

        # Determine language
        if ext in (".py",):
            issues = _audit_python(content, str(file_path))
        elif ext in (".js", ".ts", ".jsx", ".tsx"):
            issues = _audit_javascript(content, str(file_path))
        else:
            return {"path": str(file_path), "issues": [], "message": f"No audit rules for {ext} files"}

        # Score
        criticals = len([i for i in issues if i["severity"] == "CRITICAL"])
        highs = len([i for i in issues if i["severity"] == "HIGH"])
        mediums = len([i for i in issues if i["severity"] == "MEDIUM"])
        lows = len([i for i in issues if i["severity"] == "LOW"])

        if criticals > 0:
            score = "F"
        elif highs > 0:
            score = "D"
        elif mediums > 0:
            score = "C"
        elif lows > 0:
            score = "B"
        else:
            score = "A"

        return {
            "path": str(file_path),
            "lines": content.count("\n") + 1,
            "issues": issues,
            "score": score,
            "counts": {"critical": criticals, "high": highs, "medium": mediums, "low": lows},
            "total_issues": len(issues),
        }

    except Exception as e:
        return {"error": str(e)}


def _audit_python(content: str, filepath: str) -> list:
    """Audit Python code."""
    issues = []
    lines = content.split("\n")

    for i, line in enumerate(lines, 1):
        stripped = line.strip()

        # CRITICAL: bare except
        if stripped == "except:" or stripped.startswith("except:"):
            issues.append({
                "severity": "CRITICAL",
                "line": i,
                "message": "Bare except: catches KeyboardInterrupt and SystemExit. Use except Exception:",
                "code": stripped,
            })

        # HIGH: no timeout on requests
        if "requests.get(" in stripped or "requests.post(" in stripped:
            if "timeout" not in stripped:
                issues.append({
                    "severity": "HIGH",
                    "line": i,
                    "message": "HTTP request without timeout — can hang forever",
                    "code": stripped[:80],
                })

        # HIGH: non-atomic file write
        if "json.dump(" in stripped and ".tmp" not in stripped:
            if "with open(" in lines[i-2] if i >= 2 else "":
                # Check if there's an os.replace nearby
                nearby = "\n".join(lines[max(0,i-1):min(len(lines),i+3)])
                if "os.replace" not in nearby and "_os.replace" not in nearby:
                    issues.append({
                        "severity": "HIGH",
                        "line": i,
                        "message": "Non-atomic JSON write — crash during write corrupts file. Use write-to-tmp then os.replace",
                        "code": stripped[:80],
                    })

        # MEDIUM: file opened without with statement
        if "open(" in stripped and "with " not in stripped and "= open(" in stripped:
            issues.append({
                "severity": "MEDIUM",
                "line": i,
                "message": "File opened without 'with' statement — file handle may leak",
                "code": stripped[:80],
            })

        # MEDIUM: datetime.now(timezone.utc) deprecated
        if "datetime.now(timezone.utc)" in stripped:
            issues.append({
                "severity": "MEDIUM",
                "line": i,
                "message": "datetime.now(timezone.utc) is deprecated. Use datetime.now(timezone.utc)",
                "code": stripped[:80],
            })

        # LOW: print statement in production code
        if stripped.startswith("print(") and "debug" not in filepath.lower() and "test" not in filepath.lower():
            issues.append({
                "severity": "LOW",
                "line": i,
                "message": "print() in production code — use logger instead",
                "code": stripped[:80],
            })

    # Syntax check
    try:
        import py_compile
        py_compile.compile(filepath, doraise=True)
    except py_compile.PyCompileError as e:
        issues.insert(0, {
            "severity": "CRITICAL",
            "line": 0,
            "message": f"Syntax error: {e}",
            "code": "",
        })

    return issues


def _audit_javascript(content: str, filepath: str) -> list:
    """Audit JavaScript/TypeScript code."""
    issues = []
    lines = content.split("\n")

    for i, line in enumerate(lines, 1):
        stripped = line.strip()

        # HIGH: catch with empty block
        if stripped == "} catch (e) {}" or stripped == "} catch {}":
            issues.append({
                "severity": "HIGH",
                "line": i,
                "message": "Empty catch block — errors silently swallowed",
                "code": stripped,
            })

        # HIGH: no timeout on fetch
        if "fetch(" in stripped and "timeout" not in stripped and "AbortController" not in content:
            issues.append({
                "severity": "MEDIUM",
                "line": i,
                "message": "fetch() without timeout/AbortController",
                "code": stripped[:80],
            })

        # MEDIUM: console.log in production
        if "console.log(" in stripped and "test" not in filepath.lower():
            issues.append({
                "severity": "LOW",
                "line": i,
                "message": "console.log() in production code",
                "code": stripped[:80],
            })

        # MEDIUM: var usage
        if stripped.startswith("var "):
            issues.append({
                "severity": "LOW",
                "line": i,
                "message": "Use const/let instead of var",
                "code": stripped[:80],
            })

    return issues


def audit_directory(directory: str, pattern: str = "*.py") -> dict:
    """Audit all files in a directory matching a pattern."""
    dir_path = Path(directory)
    if not dir_path.is_absolute():
        dir_path = WORK_DIR / directory

    if not dir_path.exists():
        return {"error": f"Directory not found: {directory}"}

    results = []
    total_issues = 0

    for f in sorted(dir_path.rglob(pattern)):
        if "__pycache__" in str(f) or ".bak" in str(f):
            continue
        result = audit_file(str(f))
        if "error" not in result:
            results.append({
                "file": f.name,
                "path": str(f),
                "score": result["score"],
                "issues": result["total_issues"],
                "counts": result["counts"],
            })
            total_issues += result["total_issues"]

    # Overall score
    scores = [r["score"] for r in results]
    if "F" in scores:
        overall = "F"
    elif "D" in scores:
        overall = "D"
    elif "C" in scores:
        overall = "C"
    elif "B" in scores:
        overall = "B"
    else:
        overall = "A"

    return {
        "directory": str(dir_path),
        "files_audited": len(results),
        "total_issues": total_issues,
        "overall_score": overall,
        "files": results,
    }


# Register tools
register_tool(
    name="audit_file",
    description="Audit a single code file for bugs, security issues, and quality problems. Returns a score (A-F) and list of issues with severity, line number, and description.",
    parameters={
        "type": "object",
        "properties": {
            "path": {
                "type": "string",
                "description": "Path to the file to audit"
            }
        },
        "required": ["path"]
    },
    handler=audit_file,
)

register_tool(
    name="audit_directory",
    description="Audit all code files in a directory. Returns per-file scores and an overall score. Use for auditing entire projects.",
    parameters={
        "type": "object",
        "properties": {
            "directory": {
                "type": "string",
                "description": "Directory path to audit"
            },
            "pattern": {
                "type": "string",
                "description": "File pattern to match (default: *.py). Use *.js for JavaScript."
            }
        },
        "required": ["directory"]
    },
    handler=audit_directory,
)
