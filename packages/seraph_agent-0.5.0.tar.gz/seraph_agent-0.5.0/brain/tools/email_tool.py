"""
Seraph Email Tool — send emails via SMTP.
"""

import os
import logging
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from .registry import register_tool

logger = logging.getLogger("seraph.tools.email")


def send_email(to: str, subject: str, body: str, html: bool = False) -> dict:
    """Send an email via SMTP."""
    smtp_host = os.environ.get("SERAPH_SMTP_HOST", "smtp.gmail.com")
    smtp_port = int(os.environ.get("SERAPH_SMTP_PORT", "587"))
    smtp_user = os.environ.get("SERAPH_SMTP_USER", "")
    smtp_pass = os.environ.get("SERAPH_SMTP_PASS", "")
    from_addr = os.environ.get("SERAPH_FROM_EMAIL", smtp_user)

    if not smtp_user or not smtp_pass:
        return {"error": "SMTP not configured. Set SERAPH_SMTP_USER and SERAPH_SMTP_PASS."}

    try:
        msg = MIMEMultipart("alternative")
        msg["Subject"] = subject
        msg["From"] = from_addr
        msg["To"] = to

        if html:
            msg.attach(MIMEText(body, "html"))
        else:
            msg.attach(MIMEText(body, "plain"))

        with smtplib.SMTP(smtp_host, smtp_port) as server:
            server.starttls()
            server.login(smtp_user, smtp_pass)
            server.sendmail(from_addr, [to], msg.as_string())

        logger.info(f"Email sent to {to}: {subject}")
        return {
            "status": "sent",
            "to": to,
            "subject": subject,
        }

    except Exception as e:
        logger.error(f"Email failed: {e}")
        return {"error": str(e)}


register_tool(
    name="send_email",
    description="Send an email via SMTP. Requires SERAPH_SMTP_USER and SERAPH_SMTP_PASS environment variables. Use for: sending reports, notifications, outreach.",
    parameters={
        "type": "object",
        "properties": {
            "to": {
                "type": "string",
                "description": "Recipient email address"
            },
            "subject": {
                "type": "string",
                "description": "Email subject line"
            },
            "body": {
                "type": "string",
                "description": "Email body text"
            },
            "html": {
                "type": "boolean",
                "description": "Whether body is HTML (default: false)"
            }
        },
        "required": ["to", "subject", "body"]
    },
    handler=send_email,
)
