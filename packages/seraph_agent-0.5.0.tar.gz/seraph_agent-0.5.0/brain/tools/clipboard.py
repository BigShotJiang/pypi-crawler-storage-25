"""
Seraph Clipboard Tool — read/write system clipboard.

Cross-platform: uses pbcopy/pbpaste (macOS), xclip (Linux),
clip/powershell (Windows).
"""

import subprocess
import platform
import logging
from .registry import register_tool

logger = logging.getLogger("seraph.tools.clipboard")

SYSTEM = platform.system()


def clipboard_read() -> dict:
    """Read current clipboard contents."""
    try:
        if SYSTEM == "Darwin":
            result = subprocess.run(["pbpaste"], capture_output=True, text=True, timeout=5)
        elif SYSTEM == "Linux":
            result = subprocess.run(["xclip", "-selection", "clipboard", "-o"], capture_output=True, text=True, timeout=5)
        elif SYSTEM == "Windows":
            result = subprocess.run(["powershell", "-Command", "Get-Clipboard"], capture_output=True, text=True, timeout=5)
        else:
            return {"error": f"Unsupported platform: {SYSTEM}"}

        if result.returncode == 0:
            content = result.stdout
            return {"content": content[:5000], "length": len(content), "truncated": len(content) > 5000}
        return {"error": f"Clipboard read failed: {result.stderr[:200]}"}
    except FileNotFoundError:
        return {"error": f"Clipboard tool not found for {SYSTEM}"}
    except Exception as e:
        return {"error": str(e)}


def clipboard_write(text: str) -> dict:
    """Write text to system clipboard."""
    try:
        if SYSTEM == "Darwin":
            proc = subprocess.Popen(["pbcopy"], stdin=subprocess.PIPE)
            proc.communicate(text.encode("utf-8"), timeout=5)
        elif SYSTEM == "Linux":
            proc = subprocess.Popen(["xclip", "-selection", "clipboard"], stdin=subprocess.PIPE)
            proc.communicate(text.encode("utf-8"), timeout=5)
        elif SYSTEM == "Windows":
            proc = subprocess.Popen(["clip"], stdin=subprocess.PIPE)
            proc.communicate(text.encode("utf-8"), timeout=5)
        else:
            return {"error": f"Unsupported platform: {SYSTEM}"}

        return {"status": "copied", "length": len(text)}
    except FileNotFoundError:
        return {"error": f"Clipboard tool not found for {SYSTEM}"}
    except Exception as e:
        return {"error": str(e)}


def clipboard_tool(action: str = "read", text: str = "") -> dict:
    if action == "read":
        return clipboard_read()
    elif action == "write":
        if not text:
            return {"error": "Provide text to copy"}
        return clipboard_write(text)
    return {"error": f"Unknown action: {action}. Use: read, write"}


register_tool(
    name="clipboard",
    description="Read or write the system clipboard. Actions: read (paste), write (copy).",
    parameters={
        "type": "object",
        "properties": {
            "action": {"type": "string", "enum": ["read", "write"]},
            "text": {"type": "string", "description": "Text to copy (for write action)"},
        },
        "required": ["action"],
    },
    handler=clipboard_tool,
)
