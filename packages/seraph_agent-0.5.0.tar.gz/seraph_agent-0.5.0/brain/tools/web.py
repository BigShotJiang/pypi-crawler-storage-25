"""
Seraph Web Tools — search and fetch web pages.
"""

import logging
import requests
from .registry import register_tool

logger = logging.getLogger("seraph.tools.web")


def web_search(query: str) -> dict:
    """Search the web using DuckDuckGo."""
    try:
        resp = requests.get(
            "https://html.duckduckgo.com/html/",
            params={"q": query},
            headers={"User-Agent": "Seraph/0.1"},
            timeout=10,
        )
        if resp.status_code == 200:
            # Basic extraction from HTML
            from html.parser import HTMLParser
            results = []

            class DDGParser(HTMLParser):
                in_result = False
                current = {}

                def handle_starttag(self, tag, attrs):
                    attrs_dict = dict(attrs)
                    if tag == "a" and "result__a" in attrs_dict.get("class", ""):
                        self.in_result = True
                        self.current = {"url": attrs_dict.get("href", ""), "title": ""}

                def handle_data(self, data):
                    if self.in_result:
                        self.current["title"] += data.strip()

                def handle_endtag(self, tag):
                    if tag == "a" and self.in_result:
                        self.in_result = False
                        if self.current.get("title"):
                            results.append(self.current)

            parser = DDGParser()
            parser.feed(resp.text)

            return {
                "query": query,
                "results": results[:10],
                "count": len(results[:10]),
            }

        return {"error": f"Search returned {resp.status_code}"}

    except Exception as e:
        return {"error": str(e)}


def web_fetch(url: str) -> dict:
    """Fetch a web page and return its text content."""
    try:
        resp = requests.get(
            url,
            headers={"User-Agent": "Seraph/0.1"},
            timeout=15,
        )

        content = resp.text

        # Strip HTML tags for cleaner output
        import re
        # Remove script and style blocks
        content = re.sub(r'<script[^>]*>.*?</script>', '', content, flags=re.DOTALL)
        content = re.sub(r'<style[^>]*>.*?</style>', '', content, flags=re.DOTALL)
        # Remove tags
        content = re.sub(r'<[^>]+>', ' ', content)
        # Clean whitespace
        content = re.sub(r'\s+', ' ', content).strip()

        # Cap output
        if len(content) > 8000:
            content = content[:8000] + "... (truncated)"

        return {
            "url": url,
            "status": resp.status_code,
            "content": content,
            "length": len(content),
        }

    except Exception as e:
        return {"error": str(e)}


# Register tools
register_tool(
    name="web_search",
    description="Search the web using DuckDuckGo. Returns a list of results with titles and URLs.",
    parameters={
        "type": "object",
        "properties": {
            "query": {
                "type": "string",
                "description": "The search query"
            }
        },
        "required": ["query"]
    },
    handler=web_search,
)

register_tool(
    name="web_fetch",
    description="Fetch a web page and return its text content (HTML stripped). Use for reading articles, documentation, or any web page.",
    parameters={
        "type": "object",
        "properties": {
            "url": {
                "type": "string",
                "description": "The URL to fetch"
            }
        },
        "required": ["url"]
    },
    handler=web_fetch,
)
