"""
Seraph Export HTML — rich conversation export.

Exports conversations as styled HTML files with:
- Dark theme matching Telegram
- Message bubbles
- Code syntax highlighting
- Tool call display
- Timestamps
"""

import json
import time
import logging
from pathlib import Path
from .registry import register_tool

logger = logging.getLogger("seraph.tools.export_html")

HTML_TEMPLATE = """<!DOCTYPE html>
<html><head>
<title>Seraph Conversation - {title}</title>
<meta charset="utf-8">
<style>
* {{ margin: 0; padding: 0; box-sizing: border-box; }}
body {{ font-family: -apple-system, system-ui, sans-serif; background: #0a0a0a; color: #e0e0e0; padding: 20px; max-width: 800px; margin: 0 auto; }}
h1 {{ color: #6366f1; margin-bottom: 5px; font-size: 22px; }}
.meta {{ color: #888; margin-bottom: 30px; font-size: 13px; }}
.msg {{ margin-bottom: 12px; padding: 12px 16px; border-radius: 12px; max-width: 85%; line-height: 1.6; white-space: pre-wrap; word-break: break-word; }}
.msg.user {{ background: #6366f1; color: white; margin-left: auto; border-bottom-right-radius: 4px; }}
.msg.assistant {{ background: #1e1e2e; border: 1px solid #333; border-bottom-left-radius: 4px; }}
.msg.tool {{ background: #1a1a2e; border: 1px solid #2a2a4e; font-family: monospace; font-size: 13px; color: #aaa; }}
.msg .role {{ font-size: 11px; color: #888; margin-bottom: 4px; text-transform: uppercase; letter-spacing: 1px; }}
pre {{ background: #111; padding: 10px; border-radius: 6px; overflow-x: auto; margin: 8px 0; }}
code {{ font-family: 'Fira Code', monospace; font-size: 13px; }}
</style></head><body>
<h1>Seraph Conversation</h1>
<div class="meta">{meta}</div>
{messages}
</body></html>"""


def _escape_html(text: str) -> str:
    return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def export_to_html(messages: list = None, title: str = "", output_path: str = "") -> dict:
    """Export conversation to styled HTML."""
    if not messages:
        return {"error": "No messages to export"}

    workspace = Path.home() / ".seraph" / "workspace"
    workspace.mkdir(parents=True, exist_ok=True)

    if not output_path:
        output_path = str(workspace / f"conversation_{int(time.time())}.html")

    if not title:
        title = f"Conversation {time.strftime('%Y-%m-%d %H:%M')}"

    msg_html = ""
    for m in messages:
        role = m.get("role", "unknown")
        content = m.get("content", "")
        if not content or not isinstance(content, str):
            continue

        css_class = role if role in ("user", "assistant", "tool") else "assistant"
        escaped = _escape_html(content)
        # Basic code block rendering
        escaped = escaped.replace("```", "</code></pre>") if "```" in escaped else escaped
        msg_html += f'<div class="msg {css_class}"><div class="role">{role}</div>{escaped}</div>\n'

    meta = f"Messages: {len(messages)} | Exported: {time.strftime('%Y-%m-%d %H:%M:%S UTC', time.gmtime())}"

    html = HTML_TEMPLATE.format(title=_escape_html(title), meta=meta, messages=msg_html)

    Path(output_path).write_text(html, encoding="utf-8")
    return {"status": "exported", "path": output_path, "messages": len(messages), "size_kb": len(html) // 1024}


register_tool(
    name="export_html",
    description="Export conversation to a styled HTML file with dark theme, message bubbles, and code highlighting.",
    parameters={
        "type": "object",
        "properties": {
            "title": {"type": "string", "description": "Title for the export"},
            "output_path": {"type": "string", "description": "Output file path (optional)"},
        },
    },
    handler=lambda title="", output_path="": export_to_html(title=title, output_path=output_path),
)
