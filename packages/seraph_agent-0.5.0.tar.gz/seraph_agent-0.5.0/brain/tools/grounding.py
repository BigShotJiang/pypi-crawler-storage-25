"""
Seraph Search Grounding — verify LLM responses against web search.

When the agent makes a factual claim, this tool can check it against
real search results to reduce hallucination.
"""

import logging
import requests
import re
from typing import Dict, List
from .registry import register_tool

logger = logging.getLogger("seraph.tools.grounding")


def ground_claim(claim: str, num_sources: int = 3) -> dict:
    """
    Verify a factual claim against web search results.

    Returns search evidence supporting or contradicting the claim.
    """
    try:
        # Search for the claim
        resp = requests.get(
            "https://html.duckduckgo.com/html/",
            params={"q": claim},
            headers={"User-Agent": "Seraph/0.1"},
            timeout=10,
        )

        if resp.status_code != 200:
            return {"error": f"Search failed: HTTP {resp.status_code}"}

        # Extract results
        from html.parser import HTMLParser
        results = []

        class DDGParser(HTMLParser):
            in_result = False
            in_snippet = False
            current = {}

            def handle_starttag(self, tag, attrs):
                attrs_dict = dict(attrs)
                cls = attrs_dict.get("class", "")
                if tag == "a" and "result__a" in cls:
                    self.in_result = True
                    self.current = {"url": attrs_dict.get("href", ""), "title": "", "snippet": ""}
                if tag == "a" and "result__snippet" in cls:
                    self.in_snippet = True

            def handle_data(self, data):
                if self.in_result and not self.in_snippet:
                    self.current["title"] += data.strip()
                if self.in_snippet:
                    self.current["snippet"] += data.strip()

            def handle_endtag(self, tag):
                if tag == "a" and self.in_snippet:
                    self.in_snippet = False
                if tag == "a" and self.in_result and not self.in_snippet:
                    self.in_result = False
                    if self.current.get("title"):
                        results.append(self.current)

        parser = DDGParser()
        parser.feed(resp.text)

        sources = results[:num_sources]

        if not sources:
            return {
                "claim": claim,
                "grounded": False,
                "confidence": "low",
                "reason": "No search results found to verify",
                "sources": [],
            }

        # Simple keyword matching to check if sources support the claim
        claim_words = set(re.findall(r'\w+', claim.lower()))
        support_count = 0

        for source in sources:
            source_text = (source.get("title", "") + " " + source.get("snippet", "")).lower()
            source_words = set(re.findall(r'\w+', source_text))
            overlap = len(claim_words & source_words)
            relevance = overlap / len(claim_words) if claim_words else 0
            source["relevance"] = round(relevance, 2)
            if relevance > 0.3:
                support_count += 1

        if support_count >= 2:
            confidence = "high"
            grounded = True
        elif support_count == 1:
            confidence = "medium"
            grounded = True
        else:
            confidence = "low"
            grounded = False

        return {
            "claim": claim,
            "grounded": grounded,
            "confidence": confidence,
            "supporting_sources": support_count,
            "sources": [
                {"title": s.get("title", ""), "snippet": s.get("snippet", "")[:200], "relevance": s.get("relevance", 0)}
                for s in sources
            ],
        }

    except Exception as e:
        return {"error": str(e)}


register_tool(
    name="verify_claim",
    description="Verify a factual claim against web search results. Use when making factual statements to reduce hallucination. Returns confidence level (high/medium/low) and supporting sources.",
    parameters={
        "type": "object",
        "properties": {
            "claim": {
                "type": "string",
                "description": "The factual claim to verify"
            },
            "num_sources": {
                "type": "integer",
                "description": "Number of sources to check (default: 3)"
            }
        },
        "required": ["claim"]
    },
    handler=ground_claim,
)
