"""
Seraph Progress Tool — show progress bars in chat.

For long-running operations, report progress back to the user.
"""

import time
import logging
from .registry import register_tool

logger = logging.getLogger("seraph.tools.progress")

# Active progress trackers
_trackers = {}


def progress(action: str, task_id: str = "", label: str = "", current: int = 0, total: int = 100) -> dict:
    if action == "start":
        task_id = task_id or f"task_{int(time.time())}"
        _trackers[task_id] = {
            "label": label,
            "current": 0,
            "total": total,
            "started": time.time(),
            "status": "running",
        }
        bar = _render_bar(0, total, label)
        return {"task_id": task_id, "display": bar, "status": "started"}

    elif action == "update":
        if task_id not in _trackers:
            return {"error": f"Task not found: {task_id}"}
        _trackers[task_id]["current"] = current
        if label:
            _trackers[task_id]["label"] = label
        bar = _render_bar(current, _trackers[task_id]["total"], _trackers[task_id]["label"])
        return {"task_id": task_id, "display": bar, "percent": int(current / _trackers[task_id]["total"] * 100)}

    elif action == "complete":
        if task_id in _trackers:
            elapsed = time.time() - _trackers[task_id]["started"]
            lbl = _trackers[task_id]["label"]
            del _trackers[task_id]
            return {"task_id": task_id, "display": f"{lbl}: Done ({int(elapsed)}s)", "status": "complete"}
        return {"task_id": task_id, "status": "complete"}

    elif action == "list":
        return {"active": {k: v for k, v in _trackers.items()}}

    return {"error": f"Unknown action: {action}"}


def _render_bar(current: int, total: int, label: str = "") -> str:
    if total <= 0:
        return f"{label}: 0%"
    pct = min(100, int(current / total * 100))
    filled = pct // 5
    bar = "[" + "#" * filled + "-" * (20 - filled) + "]"
    return f"{label}: {bar} {pct}% ({current}/{total})"


register_tool(
    name="progress",
    description="Show progress for long-running tasks. Actions: start, update, complete, list.",
    parameters={
        "type": "object",
        "properties": {
            "action": {"type": "string", "enum": ["start", "update", "complete", "list"]},
            "task_id": {"type": "string", "description": "Task identifier"},
            "label": {"type": "string", "description": "Progress label"},
            "current": {"type": "integer", "description": "Current progress value"},
            "total": {"type": "integer", "description": "Total value (default: 100)"},
        },
        "required": ["action"],
    },
    handler=progress,
)
