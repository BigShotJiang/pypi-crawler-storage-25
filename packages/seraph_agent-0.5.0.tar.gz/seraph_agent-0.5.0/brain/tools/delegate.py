"""
Seraph Delegate Tool — spawn focused sub-tasks.

Creates a child context with restricted tools and focused goal.
The child runs in the same process but with isolated conversation.
Parent only sees the summary, not intermediate steps.
"""

import json
import logging
from typing import Dict, List, Optional
from .registry import register_tool

logger = logging.getLogger("seraph.tools.delegate")

# Tools children cannot use
BLOCKED_TOOLS = frozenset([
    "delegate_task",     # No recursive delegation
    "request_approval",  # No user interaction
    "send_notification", # No side effects
])

MAX_ITERATIONS = 20


def delegate_task(goal: str, context: str = "", tools: list = None) -> dict:
    """
    Delegate a focused task to a sub-context.

    The sub-context gets its own conversation with a focused system prompt.
    It runs until completion and returns a summary.
    """
    import os
    import sys
    sys.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parent.parent))

    try:
        from agent.llm import LLMProvider
        from tools.registry import get_openai_tool_schemas, execute_tool

        llm = LLMProvider(
            provider=os.environ.get("SERAPH_PROVIDER", "openai"),
            model=os.environ.get("SERAPH_MODEL", "gpt-5.4"),
        )

        # Build focused system prompt
        system = (
            "You are a focused sub-agent working on a specific delegated task.\n"
            f"\nYOUR TASK:\n{goal}\n"
        )
        if context:
            system += f"\nCONTEXT:\n{context}\n"
        system += (
            "\nComplete this task using the tools available to you. "
            "When finished, provide a clear summary of what you did and the results."
        )

        # Filter tools
        all_tools = get_openai_tool_schemas()
        if tools:
            allowed = set(tools) - BLOCKED_TOOLS
            all_tools = [t for t in all_tools if t.get("function", {}).get("name") in allowed]
        else:
            all_tools = [t for t in all_tools if t.get("function", {}).get("name") not in BLOCKED_TOOLS]

        # Run the sub-agent loop
        messages = [{"role": "user", "content": goal}]
        total_tokens = 0

        for iteration in range(MAX_ITERATIONS):
            response = llm.chat(messages=messages, system=system, tools=all_tools or None)
            total_tokens += response.input_tokens + response.output_tokens

            if not response.tool_calls:
                # Done — return the final response
                return {
                    "status": "completed",
                    "result": response.text,
                    "iterations": iteration + 1,
                    "tokens_used": total_tokens,
                }

            # Handle tool calls
            tool_call_msg = {
                "role": "assistant",
                "content": response.text or None,
                "tool_calls": [
                    {"id": tc["id"], "type": "function", "function": {"name": tc["name"], "arguments": json.dumps(tc["arguments"])}}
                    for tc in response.tool_calls
                ],
            }
            messages.append(tool_call_msg)

            import asyncio
            for tc in response.tool_calls:
                if tc["name"] in BLOCKED_TOOLS:
                    result_str = json.dumps({"error": f"Tool '{tc['name']}' not available in sub-tasks"})
                else:
                    try:
                        loop = asyncio.new_event_loop()
                        result = loop.run_until_complete(execute_tool(tc["name"], tc["arguments"]))
                        loop.close()
                    except Exception as e:
                        result = {"error": str(e)}
                    result_str = json.dumps(result, default=str)[:5000]

                messages.append({"role": "tool", "tool_call_id": tc["id"], "content": result_str})

        return {
            "status": "max_iterations",
            "result": "Task did not complete within iteration limit.",
            "iterations": MAX_ITERATIONS,
            "tokens_used": total_tokens,
        }

    except Exception as e:
        return {"status": "error", "error": str(e)}


register_tool(
    name="delegate_task",
    description="Delegate a focused sub-task. Creates an isolated context with its own tools and conversation. Use for: parallel research, code generation, focused analysis. Returns a summary when done.",
    parameters={
        "type": "object",
        "properties": {
            "goal": {"type": "string", "description": "Clear description of the task to accomplish"},
            "context": {"type": "string", "description": "Additional context or constraints"},
            "tools": {"type": "array", "items": {"type": "string"}, "description": "Specific tools to allow (default: all except blocked)"},
        },
        "required": ["goal"],
    },
    handler=delegate_task,
)
