"""
Seraph HomeAssistant Tool — smart home control.

Control lights, switches, sensors, automations via HA REST API.
Set SERAPH_HA_URL and SERAPH_HA_TOKEN.
"""

import os
import logging
import requests
from .registry import register_tool

logger = logging.getLogger("seraph.tools.homeassistant")

HA_URL = os.environ.get("SERAPH_HA_URL", "http://homeassistant.local:8123")
HA_TOKEN = os.environ.get("SERAPH_HA_TOKEN", "")


def _ha_api(method: str, endpoint: str, data: dict = None) -> dict:
    if not HA_TOKEN:
        return {"error": "SERAPH_HA_TOKEN not set"}
    headers = {"Authorization": f"Bearer {HA_TOKEN}", "Content-Type": "application/json"}
    url = f"{HA_URL}/api{endpoint}"
    try:
        if method == "GET":
            resp = requests.get(url, headers=headers, timeout=10)
        else:
            resp = requests.post(url, headers=headers, json=data or {}, timeout=10)
        if resp.status_code == 200:
            return resp.json() if resp.text else {"status": "ok"}
        return {"error": f"HA API {resp.status_code}: {resp.text[:200]}"}
    except Exception as e:
        return {"error": str(e)}


def homeassistant(action: str, entity_id: str = "", service: str = "", data: dict = None) -> dict:
    if action == "states":
        states = _ha_api("GET", "/states")
        if isinstance(states, list):
            return {
                "count": len(states),
                "entities": [
                    {"entity_id": s["entity_id"], "state": s["state"], "name": s.get("attributes", {}).get("friendly_name", "")}
                    for s in states[:50]
                ],
            }
        return states

    elif action == "state":
        if not entity_id:
            return {"error": "Provide entity_id"}
        return _ha_api("GET", f"/states/{entity_id}")

    elif action == "call_service":
        if not service:
            return {"error": "Provide service (e.g. light/turn_on)"}
        domain, svc = service.split("/", 1) if "/" in service else (service, "")
        payload = data or {}
        if entity_id:
            payload["entity_id"] = entity_id
        return _ha_api("POST", f"/services/{domain}/{svc}", payload)

    elif action == "turn_on":
        if not entity_id:
            return {"error": "Provide entity_id"}
        domain = entity_id.split(".")[0]
        return _ha_api("POST", f"/services/{domain}/turn_on", {"entity_id": entity_id, **(data or {})})

    elif action == "turn_off":
        if not entity_id:
            return {"error": "Provide entity_id"}
        domain = entity_id.split(".")[0]
        return _ha_api("POST", f"/services/{domain}/turn_off", {"entity_id": entity_id})

    elif action == "history":
        return _ha_api("GET", f"/history/period?filter_entity_id={entity_id}&minimal_response" if entity_id else "/history/period?minimal_response")

    return {"error": f"Unknown action: {action}. Use: states, state, call_service, turn_on, turn_off, history"}


register_tool(
    name="homeassistant",
    description="Control smart home via HomeAssistant. Actions: states (list all), state (get one), turn_on, turn_off, call_service, history.",
    parameters={
        "type": "object",
        "properties": {
            "action": {"type": "string", "enum": ["states", "state", "turn_on", "turn_off", "call_service", "history"]},
            "entity_id": {"type": "string", "description": "Entity ID (e.g. light.living_room)"},
            "service": {"type": "string", "description": "Service to call (e.g. light/turn_on)"},
            "data": {"type": "object", "description": "Service data (e.g. brightness, color)"},
        },
        "required": ["action"],
    },
    handler=homeassistant,
)
