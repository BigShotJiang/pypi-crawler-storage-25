"""
Seraph Context Compression — summarize long conversations using LLM.
"""

import logging
from .registry import register_tool

logger = logging.getLogger("seraph.tools.context")


def compress_conversation(messages: list, llm=None) -> dict:
    """Compress a conversation history into a summary using the LLM."""
    if not messages or len(messages) < 4:
        return {"error": "Not enough messages to compress"}

    if not llm:
        # Simple fallback: keep first 2 and last 4 messages
        compressed = messages[:2] + [{"role": "system", "content": "[Earlier conversation compressed]"}] + messages[-4:]
        return {
            "original_count": len(messages),
            "compressed_count": len(compressed),
            "messages": compressed,
            "method": "truncation",
        }

    # Use LLM to summarize the middle of the conversation
    middle = messages[2:-4]
    if not middle:
        return {"original_count": len(messages), "compressed_count": len(messages), "method": "none"}

    summary_prompt = (
        "Summarize this conversation excerpt in 2-3 sentences. "
        "Focus on: key decisions made, important facts shared, tasks discussed. "
        "Be concise.\n\n"
    )
    for m in middle:
        summary_prompt += f"[{m['role']}]: {m['content'][:200]}\n"

    try:
        response = llm.chat(
            messages=[{"role": "user", "content": summary_prompt}],
            system="You are a conversation summarizer. Be extremely concise.",
        )

        summary_msg = {"role": "system", "content": f"[Conversation summary: {response.text}]"}
        compressed = messages[:2] + [summary_msg] + messages[-4:]

        return {
            "original_count": len(messages),
            "compressed_count": len(compressed),
            "summary": response.text,
            "messages": compressed,
            "method": "llm_summary",
            "tokens_saved": sum(len(m.get("content", "")) for m in middle) // 4,
        }

    except Exception as e:
        logger.error(f"LLM compression failed: {e}")
        compressed = messages[:2] + [{"role": "system", "content": "[Earlier conversation compressed]"}] + messages[-4:]
        return {
            "original_count": len(messages),
            "compressed_count": len(compressed),
            "method": "fallback_truncation",
            "error": str(e),
        }
