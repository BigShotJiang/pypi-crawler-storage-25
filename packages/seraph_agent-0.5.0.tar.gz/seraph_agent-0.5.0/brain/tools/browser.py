"""
Seraph Browser Tool — take screenshots and interact with web pages.

Uses Playwright for real browser automation (headless Chrome).
Falls back to requests+BeautifulSoup if Playwright not installed.
"""

import os
import logging
import time
import json
from pathlib import Path
from .registry import register_tool

logger = logging.getLogger("seraph.tools.browser")

WORK_DIR = Path.home() / ".seraph" / "workspace"


def browse_page(url: str, screenshot: bool = False, wait_seconds: int = 3) -> dict:
    """
    Open a URL in a headless browser, optionally take a screenshot.
    Returns the page text content and screenshot path if requested.
    """
    # Try Playwright first
    try:
        from playwright.sync_api import sync_playwright

        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            page = browser.new_page(viewport={"width": 1280, "height": 720})
            page.goto(url, timeout=15000)
            time.sleep(wait_seconds)

            title = page.title()
            text = page.inner_text("body")[:8000]

            result = {
                "url": url,
                "title": title,
                "content": text,
                "method": "playwright",
            }

            if screenshot:
                WORK_DIR.mkdir(parents=True, exist_ok=True)
                filename = f"screenshot_{int(time.time())}.png"
                filepath = WORK_DIR / filename
                page.screenshot(path=str(filepath))
                result["screenshot"] = str(filepath)

            browser.close()
            return result

    except ImportError:
        logger.info("Playwright not installed, using requests fallback")
    except Exception as e:
        logger.warning(f"Playwright failed: {e}, using requests fallback")

    # Fallback: requests + basic HTML parsing
    try:
        import requests
        import re

        resp = requests.get(url, headers={"User-Agent": "Seraph/0.1"}, timeout=15)
        content = resp.text

        # Extract title
        title_match = re.search(r"<title>(.*?)</title>", content, re.IGNORECASE | re.DOTALL)
        title = title_match.group(1).strip() if title_match else ""

        # Strip HTML
        content = re.sub(r'<script[^>]*>.*?</script>', '', content, flags=re.DOTALL)
        content = re.sub(r'<style[^>]*>.*?</style>', '', content, flags=re.DOTALL)
        content = re.sub(r'<[^>]+>', ' ', content)
        content = re.sub(r'\s+', ' ', content).strip()

        return {
            "url": url,
            "title": title,
            "content": content[:8000],
            "method": "requests_fallback",
            "screenshot": None,
        }

    except Exception as e:
        return {"error": str(e)}


def browser_action(url: str = "", action: str = "read", selector: str = "",
                    value: str = "", screenshot: bool = False, wait_seconds: int = 3) -> dict:
    """Full browser automation — read, click, type, fill, screenshot."""
    if action == "read" or not action:
        return browse_page(url, screenshot, wait_seconds)

    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        return {"error": "pip install playwright && playwright install chromium"}

    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            page = browser.new_page()
            if url:
                page.goto(url, timeout=15000)
                time.sleep(wait_seconds)

            result = {}
            if action == "click" and selector:
                page.click(selector, timeout=5000)
                result = {"clicked": selector, "title": page.title()}
            elif action == "type" and selector and value:
                page.fill(selector, value)
                result = {"typed": value, "into": selector}
            elif action == "screenshot":
                WORK_DIR.mkdir(parents=True, exist_ok=True)
                filepath = WORK_DIR / f"screenshot_{int(time.time())}.png"
                page.screenshot(path=str(filepath), full_page=True)
                result = {"screenshot": str(filepath)}
            elif action == "pdf":
                WORK_DIR.mkdir(parents=True, exist_ok=True)
                filepath = WORK_DIR / f"page_{int(time.time())}.pdf"
                page.pdf(path=str(filepath))
                result = {"pdf": str(filepath)}
            elif action == "evaluate" and value:
                js_result = page.evaluate(value)
                result = {"js_result": str(js_result)[:5000]}
            else:
                result = {"text": page.inner_text("body")[:8000], "title": page.title()}

            if screenshot and "screenshot" not in result:
                WORK_DIR.mkdir(parents=True, exist_ok=True)
                filepath = WORK_DIR / f"screenshot_{int(time.time())}.png"
                page.screenshot(path=str(filepath))
                result["screenshot"] = str(filepath)

            browser.close()
            return result
    except Exception as e:
        return {"error": str(e)}


def read_pdf(file_path: str = "", url: str = "") -> dict:
    """Read and extract text from a PDF file or URL."""
    try:
        import fitz  # PyMuPDF
    except ImportError:
        # Fallback: try pdfplumber
        try:
            import pdfplumber
            if url:
                import requests, tempfile
                resp = requests.get(url, timeout=30)
                tmp = tempfile.NamedTemporaryFile(suffix=".pdf", delete=False)
                tmp.write(resp.content)
                tmp.close()
                file_path = tmp.name
            if not file_path:
                return {"error": "Provide file_path or url"}
            with pdfplumber.open(file_path) as pdf:
                text = ""
                for page in pdf.pages[:50]:
                    text += page.extract_text() or ""
                    text += "\n---\n"
                return {"text": text[:20000], "pages": len(pdf.pages)}
        except ImportError:
            return {"error": "pip install PyMuPDF or pdfplumber for PDF support"}

    if url:
        import requests, tempfile
        resp = requests.get(url, timeout=30)
        tmp = tempfile.NamedTemporaryFile(suffix=".pdf", delete=False)
        tmp.write(resp.content)
        tmp.close()
        file_path = tmp.name

    if not file_path:
        return {"error": "Provide file_path or url"}

    try:
        doc = fitz.open(file_path)
        text = ""
        for page in doc[:50]:
            text += page.get_text() + "\n---\n"
        return {"text": text[:20000], "pages": len(doc), "path": file_path}
    except Exception as e:
        return {"error": str(e)}


register_tool(
    name="browse",
    description="Full browser automation: read pages, click elements, type text, take screenshots, save as PDF. Actions: read, click, type, screenshot, pdf, evaluate.",
    parameters={
        "type": "object",
        "properties": {
            "url": {"type": "string", "description": "URL to open"},
            "action": {"type": "string", "enum": ["read", "click", "type", "screenshot", "pdf", "evaluate"],
                       "description": "Action to perform (default: read)"},
            "selector": {"type": "string", "description": "CSS selector for click/type"},
            "value": {"type": "string", "description": "Text to type or JS to evaluate"},
            "screenshot": {"type": "boolean", "description": "Also take a screenshot"},
            "wait_seconds": {"type": "integer", "description": "Seconds to wait (default: 3)"},
        },
        "required": ["url"],
    },
    handler=browser_action,
)

register_tool(
    name="read_pdf",
    description="Read and extract text from a PDF file or URL. Supports up to 50 pages.",
    parameters={
        "type": "object",
        "properties": {
            "file_path": {"type": "string", "description": "Path to local PDF file"},
            "url": {"type": "string", "description": "URL of PDF to download and read"},
        },
    },
    handler=read_pdf,
)
