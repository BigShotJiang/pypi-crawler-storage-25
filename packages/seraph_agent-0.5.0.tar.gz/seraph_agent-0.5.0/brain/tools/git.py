"""
Seraph Git Tool — git operations for code management.
"""

import subprocess
import logging
from pathlib import Path
from .registry import register_tool

logger = logging.getLogger("seraph.tools.git")

WORK_DIR = Path.home() / ".seraph" / "workspace"


def git_command(command: str, repo_path: str = "") -> dict:
    """Run a git command."""
    cwd = repo_path or str(WORK_DIR)

    # Safety: block destructive commands without confirmation
    dangerous = ["push --force", "reset --hard", "clean -fd"]
    for d in dangerous:
        if d in command:
            return {"error": f"Blocked dangerous git command: git {command}. Use with caution."}

    full_cmd = f"git {command}"
    logger.info(f"Git: {full_cmd} (cwd: {cwd})")

    try:
        result = subprocess.run(
            full_cmd,
            shell=True,
            capture_output=True,
            text=True,
            timeout=60,
            cwd=cwd,
        )

        output = result.stdout
        if result.stderr:
            output += "\n" + result.stderr

        if len(output) > 5000:
            output = output[:5000] + "\n...(truncated)"

        return {
            "stdout": result.stdout[:5000],
            "stderr": result.stderr[:2000],
            "exit_code": result.returncode,
            "command": f"git {command}",
        }

    except subprocess.TimeoutExpired:
        return {"error": "Git command timed out after 60s"}
    except Exception as e:
        return {"error": str(e)}


def git_clone(url: str, directory: str = "") -> dict:
    """Clone a git repository."""
    target = directory or url.split("/")[-1].replace(".git", "")
    target_path = WORK_DIR / target

    if target_path.exists():
        return {"error": f"Directory already exists: {target_path}"}

    return git_command(f"clone {url} {target_path}")


register_tool(
    name="git",
    description="Run any git command (status, log, diff, commit, pull, push, branch, etc). Use for version control operations.",
    parameters={
        "type": "object",
        "properties": {
            "command": {
                "type": "string",
                "description": "Git command without 'git' prefix (e.g. 'status', 'log --oneline -10', 'diff')"
            },
            "repo_path": {
                "type": "string",
                "description": "Path to git repo (default: workspace)"
            }
        },
        "required": ["command"]
    },
    handler=git_command,
)

register_tool(
    name="git_clone",
    description="Clone a git repository into the workspace.",
    parameters={
        "type": "object",
        "properties": {
            "url": {
                "type": "string",
                "description": "Git repository URL"
            },
            "directory": {
                "type": "string",
                "description": "Target directory name (default: repo name)"
            }
        },
        "required": ["url"]
    },
    handler=git_clone,
)
