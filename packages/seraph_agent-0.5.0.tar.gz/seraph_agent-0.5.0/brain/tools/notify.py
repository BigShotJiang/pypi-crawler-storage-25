"""
Seraph Notification Tool — send alerts to the user.

Used by cron jobs, background tasks, and error handlers to ping the user.
"""

import os
import logging
import requests
from .registry import register_tool

logger = logging.getLogger("seraph.tools.notify")


def send_notification(message: str, level: str = "info") -> dict:
    """Send a notification to the user via Telegram."""
    token = os.environ.get("SERAPH_TELEGRAM_TOKEN", "")
    chat_id = os.environ.get("SERAPH_ALLOWED_USERS", "").split(",")[0].strip()

    if not token or not chat_id:
        return {"error": "Telegram not configured for notifications"}

    prefix = {"info": "INFO", "warning": "WARNING", "error": "ERROR", "success": "OK"}.get(level, "INFO")
    text = f"[{prefix}] {message}"

    try:
        resp = requests.post(
            f"https://api.telegram.org/bot{token}/sendMessage",
            json={"chat_id": chat_id, "text": text},
            timeout=10,
        )
        if resp.status_code == 200:
            return {"status": "sent", "level": level}
        else:
            return {"error": f"Telegram error {resp.status_code}"}
    except Exception as e:
        return {"error": str(e)}


register_tool(
    name="notify",
    description="Send a notification to the user via Telegram. Use for: alerting about completed tasks, errors, or important events. Levels: info, warning, error, success.",
    parameters={
        "type": "object",
        "properties": {
            "message": {"type": "string", "description": "Notification message"},
            "level": {"type": "string", "description": "Level: info, warning, error, success", "enum": ["info", "warning", "error", "success"]},
        },
        "required": ["message"],
    },
    handler=send_notification,
)
