"""
Seraph Fuzzy Match — fuzzy file/command/string matching.

No external dependencies — uses custom Levenshtein distance.
"""

import os
import logging
from pathlib import Path
from typing import List, Tuple
from .registry import register_tool

logger = logging.getLogger("seraph.tools.fuzzy")


def levenshtein(s1: str, s2: str) -> int:
    """Calculate Levenshtein edit distance between two strings."""
    if len(s1) < len(s2):
        return levenshtein(s2, s1)
    if len(s2) == 0:
        return len(s1)

    prev_row = range(len(s2) + 1)
    for i, c1 in enumerate(s1):
        curr_row = [i + 1]
        for j, c2 in enumerate(s2):
            insertions = prev_row[j + 1] + 1
            deletions = curr_row[j] + 1
            substitutions = prev_row[j] + (c1 != c2)
            curr_row.append(min(insertions, deletions, substitutions))
        prev_row = curr_row

    return prev_row[-1]


def fuzzy_score(query: str, candidate: str) -> float:
    """Score 0.0-1.0 how well query matches candidate. 1.0 = perfect match."""
    q = query.lower()
    c = candidate.lower()

    if q == c:
        return 1.0
    if q in c:
        return 0.9 - (len(c) - len(q)) * 0.01

    distance = levenshtein(q, c)
    max_len = max(len(q), len(c))
    if max_len == 0:
        return 0.0
    return max(0.0, 1.0 - distance / max_len)


def fuzzy_find_files(query: str, directory: str = "", limit: int = 10) -> dict:
    """Find files matching a fuzzy query."""
    search_dir = Path(directory) if directory else Path.home() / ".seraph" / "workspace"
    if not search_dir.exists():
        return {"error": f"Directory not found: {search_dir}"}

    candidates = []
    try:
        for f in search_dir.rglob("*"):
            if f.is_file() and not any(p.startswith(".") for p in f.parts):
                score = fuzzy_score(query, f.name)
                if score > 0.3:
                    candidates.append((score, str(f.relative_to(search_dir)), str(f)))
    except Exception as e:
        return {"error": str(e)}

    candidates.sort(reverse=True)
    return {
        "query": query,
        "matches": [
            {"name": name, "path": path, "score": round(score, 2)}
            for score, name, path in candidates[:limit]
        ],
    }


def fuzzy_match_list(query: str, candidates: list, limit: int = 5) -> dict:
    """Fuzzy match a query against a list of strings."""
    scored = [(fuzzy_score(query, c), c) for c in candidates]
    scored.sort(reverse=True)
    return {
        "query": query,
        "matches": [
            {"text": text, "score": round(score, 2)}
            for score, text in scored[:limit] if score > 0.2
        ],
    }


register_tool(
    name="fuzzy_find",
    description="Fuzzy search for files or strings. Finds approximate matches even with typos. Use for: finding files by partial name, matching commands.",
    parameters={
        "type": "object",
        "properties": {
            "query": {"type": "string", "description": "Search query (can be approximate)"},
            "directory": {"type": "string", "description": "Directory to search in (for file search)"},
            "candidates": {"type": "array", "items": {"type": "string"}, "description": "List of strings to match against (for list search)"},
            "limit": {"type": "integer", "description": "Max results (default: 10)"},
        },
        "required": ["query"],
    },
    handler=lambda query, directory="", candidates=None, limit=10: (
        fuzzy_match_list(query, candidates, limit) if candidates
        else fuzzy_find_files(query, directory, limit)
    ),
)
