"""
Seraph Session Search — search across all past conversations.

Searches FTS5 index + metadata for finding past discussions,
decisions, and context from previous sessions.
"""

import logging
from .registry import register_tool

logger = logging.getLogger("seraph.tools.session_search")


def search_sessions(query: str, limit: int = 10, role: str = "") -> dict:
    """Search across all past conversation sessions."""
    from memory.store import get_memory
    mem = get_memory()

    try:
        results = mem.search_history(query, limit=limit)

        if role:
            results = [r for r in results if r.get("role") == role]

        return {
            "query": query,
            "count": len(results),
            "results": [
                {
                    "role": r.get("role", ""),
                    "content": r.get("content", "")[:300],
                    "session": r.get("session_id", ""),
                    "time": r.get("time", ""),
                }
                for r in results
            ],
        }
    except Exception as e:
        return {"error": str(e)}


register_tool(
    name="search_sessions",
    description="Search across all past conversation sessions. Finds previous discussions, decisions, and context. Use when the user references something from a past conversation.",
    parameters={
        "type": "object",
        "properties": {
            "query": {"type": "string", "description": "Search query"},
            "limit": {"type": "integer", "description": "Max results (default: 10)"},
            "role": {"type": "string", "description": "Filter by role: user, assistant, or empty for all"},
        },
        "required": ["query"],
    },
    handler=search_sessions,
)
