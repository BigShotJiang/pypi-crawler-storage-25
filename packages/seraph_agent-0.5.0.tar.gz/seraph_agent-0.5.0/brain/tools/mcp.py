"""
Seraph MCP Tool — Model Context Protocol support.

Connects to MCP servers and exposes their tools as Seraph tools.
Supports both stdio and HTTP MCP transports.
"""

import json
import subprocess
import logging
import time
from pathlib import Path
from typing import Dict, List, Optional
from .registry import register_tool

logger = logging.getLogger("seraph.tools.mcp")

MCP_CONFIG = Path.home() / ".seraph" / "mcp.json"


def _load_mcp_config() -> dict:
    if MCP_CONFIG.exists():
        try:
            return json.loads(MCP_CONFIG.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return {}


def _call_mcp_stdio(command: list, method: str, params: dict = None, timeout: int = 30) -> dict:
    """Call an MCP server via stdio transport."""
    request = {
        "jsonrpc": "2.0",
        "id": int(time.time()),
        "method": method,
        "params": params or {},
    }

    try:
        proc = subprocess.run(
            command,
            input=json.dumps(request) + "\n",
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        if proc.stdout:
            for line in proc.stdout.strip().splitlines():
                try:
                    resp = json.loads(line)
                    if "result" in resp:
                        return resp["result"]
                    if "error" in resp:
                        return {"error": resp["error"]}
                except json.JSONDecodeError:
                    continue
        return {"error": f"No response from MCP server. stderr: {proc.stderr[:200]}"}
    except subprocess.TimeoutExpired:
        return {"error": f"MCP server timed out after {timeout}s"}
    except Exception as e:
        return {"error": str(e)}


def list_mcp_servers() -> dict:
    """List configured MCP servers."""
    config = _load_mcp_config()
    servers = config.get("mcpServers", {})
    return {
        "count": len(servers),
        "servers": [
            {"name": name, "command": cfg.get("command", ""), "args": cfg.get("args", [])}
            for name, cfg in servers.items()
        ],
    }


def call_mcp_tool(server_name: str, tool_name: str, arguments: dict = None) -> dict:
    """Call a tool on an MCP server."""
    config = _load_mcp_config()
    servers = config.get("mcpServers", {})

    if server_name not in servers:
        return {"error": f"MCP server '{server_name}' not configured. Available: {list(servers.keys())}"}

    server = servers[server_name]
    command = [server.get("command", "")] + server.get("args", [])

    if not command[0]:
        return {"error": f"No command configured for MCP server '{server_name}'"}

    # Set environment
    env = dict(__import__("os").environ)
    env.update(server.get("env", {}))

    return _call_mcp_stdio(
        command,
        "tools/call",
        {"name": tool_name, "arguments": arguments or {}},
    )


def get_mcp_tools(server_name: str) -> dict:
    """List tools available on an MCP server."""
    config = _load_mcp_config()
    servers = config.get("mcpServers", {})

    if server_name not in servers:
        return {"error": f"MCP server '{server_name}' not found"}

    server = servers[server_name]
    command = [server.get("command", "")] + server.get("args", [])

    return _call_mcp_stdio(command, "tools/list")


register_tool(
    name="mcp",
    description="Connect to MCP (Model Context Protocol) servers and call their tools. Actions: list_servers, list_tools, call_tool.",
    parameters={
        "type": "object",
        "properties": {
            "action": {"type": "string", "enum": ["list_servers", "list_tools", "call_tool"]},
            "server_name": {"type": "string", "description": "MCP server name (from mcp.json)"},
            "tool_name": {"type": "string", "description": "Tool name on the MCP server"},
            "arguments": {"type": "object", "description": "Arguments for the MCP tool"},
        },
        "required": ["action"],
    },
    handler=lambda action, server_name="", tool_name="", arguments=None: (
        list_mcp_servers() if action == "list_servers"
        else get_mcp_tools(server_name) if action == "list_tools"
        else call_mcp_tool(server_name, tool_name, arguments) if action == "call_tool"
        else {"error": f"Unknown action: {action}"}
    ),
)
