"""
Seraph Transcription Tool — speech-to-text using OpenAI Whisper.
"""

import os
import logging
import requests
from pathlib import Path
from .registry import register_tool

logger = logging.getLogger("seraph.tools.transcribe")


def transcribe_audio(file_path: str, language: str = "") -> dict:
    """Transcribe an audio file using OpenAI Whisper API."""
    api_key = os.environ.get("OPENAI_API_KEY", "")
    if not api_key:
        return {"error": "OPENAI_API_KEY not set"}

    path = Path(file_path)
    if not path.exists():
        return {"error": f"File not found: {file_path}"}

    # Max 25MB
    if path.stat().st_size > 25 * 1024 * 1024:
        return {"error": "File too large (max 25MB). Split with ffmpeg first."}

    try:
        with open(path, "rb") as f:
            data = {"model": "whisper-1"}
            if language:
                data["language"] = language

            resp = requests.post(
                "https://api.openai.com/v1/audio/transcriptions",
                headers={"Authorization": f"Bearer {api_key}"},
                files={"file": (path.name, f)},
                data=data,
                timeout=120,
            )

        if resp.status_code == 200:
            result = resp.json()
            return {
                "text": result.get("text", ""),
                "file": str(path),
                "duration_hint": "check file metadata",
            }
        else:
            return {"error": f"Whisper error {resp.status_code}: {resp.text[:200]}"}

    except Exception as e:
        return {"error": str(e)}


register_tool(
    name="transcribe",
    description="Transcribe an audio file to text using OpenAI Whisper. Supports mp3, mp4, m4a, wav, webm. Max 25MB.",
    parameters={
        "type": "object",
        "properties": {
            "file_path": {
                "type": "string",
                "description": "Path to the audio file"
            },
            "language": {
                "type": "string",
                "description": "Language code (e.g. 'en', 'es'). Leave empty for auto-detect."
            }
        },
        "required": ["file_path"]
    },
    handler=transcribe_audio,
)
