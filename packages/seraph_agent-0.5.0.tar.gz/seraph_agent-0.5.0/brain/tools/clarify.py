"""
Seraph Clarify Tool — ask user for clarification mid-task.

When the agent is unsure, it can ask the user a specific question
and wait for the answer before continuing.
"""

import logging
from .registry import register_tool

logger = logging.getLogger("seraph.tools.clarify")


def clarify(question: str, options: list = None) -> dict:
    """
    Ask the user a clarification question.
    Returns the question to be displayed — the user's next message becomes the answer.
    """
    result = {
        "type": "clarification_needed",
        "question": question,
    }
    if options:
        result["options"] = options[:10]
        result["display"] = f"{question}\n\nOptions:\n" + "\n".join(f"  {i+1}. {o}" for i, o in enumerate(options))
    else:
        result["display"] = question
    return result


register_tool(
    name="clarify",
    description="Ask the user a clarification question when you need more information to proceed. The user's next message will be the answer.",
    parameters={
        "type": "object",
        "properties": {
            "question": {"type": "string", "description": "The question to ask"},
            "options": {"type": "array", "items": {"type": "string"}, "description": "Optional multiple-choice options"},
        },
        "required": ["question"],
    },
    handler=clarify,
)
