"""
Seraph Patch Tool — parse and apply unified diffs.

Applies patches to files without needing the full file content.
Supports unified diff format (diff -u / git diff).
"""

import re
import logging
from pathlib import Path
from .registry import register_tool

logger = logging.getLogger("seraph.tools.patch")


def apply_patch(patch_text: str, base_dir: str = "") -> dict:
    """Apply a unified diff patch to files."""
    results = []
    current_file = None
    hunks = []
    current_hunk = None

    for line in patch_text.splitlines():
        # Detect file header
        if line.startswith("--- "):
            pass
        elif line.startswith("+++ "):
            path = line[4:].strip()
            if path.startswith("b/"):
                path = path[2:]
            current_file = path
            hunks = []
        elif line.startswith("@@ "):
            match = re.match(r"@@ -(\d+)(?:,\d+)? \+(\d+)(?:,\d+)? @@", line)
            if match:
                current_hunk = {
                    "old_start": int(match.group(1)),
                    "new_start": int(match.group(2)),
                    "lines": [],
                }
                hunks.append(current_hunk)
        elif current_hunk is not None:
            if line.startswith("+") or line.startswith("-") or line.startswith(" "):
                current_hunk["lines"].append(line)
            elif line == "" or not line.startswith("\\"):
                current_hunk["lines"].append(" " + line)

        # Apply when we hit a new file or end
        if (line.startswith("diff ") or line.startswith("--- ")) and current_file and hunks:
            result = _apply_hunks(current_file, hunks, base_dir)
            results.append(result)
            current_file = None
            hunks = []
            current_hunk = None

    # Apply last file
    if current_file and hunks:
        result = _apply_hunks(current_file, hunks, base_dir)
        results.append(result)

    return {
        "files_patched": len([r for r in results if r.get("status") == "ok"]),
        "files_failed": len([r for r in results if r.get("status") != "ok"]),
        "results": results,
    }


def _apply_hunks(filepath: str, hunks: list, base_dir: str) -> dict:
    """Apply hunks to a single file."""
    if base_dir:
        full_path = Path(base_dir) / filepath
    else:
        full_path = Path(filepath)

    try:
        if full_path.exists():
            original = full_path.read_text(encoding="utf-8").splitlines(keepends=True)
        else:
            original = []

        result = list(original)
        offset = 0

        for hunk in hunks:
            old_start = hunk["old_start"] - 1 + offset
            new_lines = []
            removed = 0

            for line in hunk["lines"]:
                if line.startswith("+"):
                    new_lines.append(line[1:] + "\n")
                elif line.startswith("-"):
                    removed += 1
                elif line.startswith(" "):
                    new_lines.append(line[1:] + "\n")

            result[old_start:old_start + removed] = new_lines
            offset += len(new_lines) - removed

        full_path.parent.mkdir(parents=True, exist_ok=True)
        full_path.write_text("".join(result), encoding="utf-8")
        return {"file": filepath, "status": "ok", "hunks": len(hunks)}

    except Exception as e:
        return {"file": filepath, "status": "error", "error": str(e)}


register_tool(
    name="apply_patch",
    description="Apply a unified diff patch to files. Supports git diff format. Useful for applying code changes without sending full file contents.",
    parameters={
        "type": "object",
        "properties": {
            "patch_text": {"type": "string", "description": "The unified diff patch text"},
            "base_dir": {"type": "string", "description": "Base directory for relative paths"},
        },
        "required": ["patch_text"],
    },
    handler=apply_patch,
)
