"""
Seraph Mixture of Agents — multi-model parallel then aggregate.

For extremely complex problems:
1. Send the query to 3-4 frontier models in parallel
2. Collect all responses
3. Have the strongest model synthesize the best answer

Based on "Mixture-of-Agents Enhances LLM Capabilities" (Wang et al.)
"""

import os
import json
import time
import logging
import requests
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import List, Dict
from .registry import register_tool

logger = logging.getLogger("seraph.tools.mixture")

# Reference models (diverse perspectives)
REFERENCE_MODELS = [
    {"provider": "openai", "model": "gpt-5.4"},
    {"provider": "openai", "model": "gpt-4o"},
]

# Aggregator (strongest available)
AGGREGATOR_MODEL = {"provider": "openai", "model": "gpt-5.4"}

MIN_SUCCESSFUL = 2


def _call_model(provider: str, model: str, prompt: str, system: str = "", api_key: str = "") -> Dict:
    """Call a single model and return its response."""
    if not api_key:
        if provider == "openai":
            api_key = os.environ.get("OPENAI_API_KEY", "")
        elif provider == "anthropic":
            api_key = os.environ.get("ANTHROPIC_API_KEY", "")

    if not api_key:
        return {"error": f"No API key for {provider}", "model": model}

    try:
        if provider in ("openai", "openrouter"):
            base_url = "https://api.openai.com/v1" if provider == "openai" else "https://openrouter.ai/api/v1"
            messages = []
            if system:
                messages.append({"role": "system", "content": system})
            messages.append({"role": "user", "content": prompt})

            resp = requests.post(
                f"{base_url}/chat/completions",
                headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
                json={"model": model, "messages": messages, "max_completion_tokens": 4096},
                timeout=60,
            )
            if resp.status_code == 200:
                text = resp.json()["choices"][0]["message"]["content"]
                return {"model": model, "response": text, "tokens": resp.json().get("usage", {}).get("total_tokens", 0)}
            return {"error": f"HTTP {resp.status_code}", "model": model}

        elif provider == "anthropic":
            resp = requests.post(
                "https://api.anthropic.com/v1/messages",
                headers={
                    "x-api-key": api_key,
                    "content-type": "application/json",
                    "anthropic-version": "2023-06-01",
                },
                json={"model": model, "max_tokens": 4096, "messages": [{"role": "user", "content": prompt}]},
                timeout=60,
            )
            if resp.status_code == 200:
                text = resp.json()["content"][0]["text"]
                return {"model": model, "response": text}
            return {"error": f"HTTP {resp.status_code}", "model": model}

    except Exception as e:
        return {"error": str(e), "model": model}

    return {"error": "Unknown provider", "model": model}


def mixture_of_agents(query: str, system_context: str = "") -> dict:
    """
    Process a query using Mixture of Agents.

    1. Send to all reference models in parallel
    2. Aggregate responses with the strongest model
    """
    start = time.time()

    # Step 1: Parallel reference responses
    results = []
    with ThreadPoolExecutor(max_workers=4) as executor:
        futures = {}
        for ref in REFERENCE_MODELS:
            future = executor.submit(
                _call_model,
                ref["provider"],
                ref["model"],
                query,
                system_context,
            )
            futures[future] = ref["model"]

        for future in as_completed(futures, timeout=90):
            model = futures[future]
            try:
                result = future.result()
                results.append(result)
            except Exception as e:
                results.append({"model": model, "error": str(e)})

    successful = [r for r in results if "response" in r]
    if len(successful) < MIN_SUCCESSFUL:
        return {
            "error": f"Only {len(successful)}/{len(REFERENCE_MODELS)} models responded",
            "partial_results": results,
        }

    # Step 2: Aggregate
    aggregation_prompt = (
        f"You are synthesizing the best answer from multiple AI models.\n\n"
        f"Original question: {query}\n\n"
    )
    for i, r in enumerate(successful):
        aggregation_prompt += f"--- Model {i+1} ({r['model']}) ---\n{r['response'][:3000]}\n\n"
    aggregation_prompt += (
        "Synthesize the best possible answer by combining the strongest points "
        "from each model's response. Resolve any contradictions. Be comprehensive."
    )

    aggregated = _call_model(
        AGGREGATOR_MODEL["provider"],
        AGGREGATOR_MODEL["model"],
        aggregation_prompt,
    )

    elapsed = time.time() - start

    return {
        "response": aggregated.get("response", "Aggregation failed"),
        "models_used": len(successful),
        "models_total": len(REFERENCE_MODELS),
        "elapsed_seconds": round(elapsed, 1),
        "model_responses": [
            {"model": r["model"], "preview": r.get("response", r.get("error", ""))[:200]}
            for r in results
        ],
    }


register_tool(
    name="mixture_of_agents",
    description="Process a complex query using multiple AI models in parallel, then synthesize the best answer. Use for: extremely difficult problems, when you need diverse perspectives, or when accuracy is critical.",
    parameters={
        "type": "object",
        "properties": {
            "query": {"type": "string", "description": "The complex question or task"},
            "system_context": {"type": "string", "description": "Additional context for all models"},
        },
        "required": ["query"],
    },
    handler=mixture_of_agents,
)
