"""
Seraph QR Code Tool — generate QR codes for pairing and sharing.

No external dependencies — uses a minimal QR code generator.
Outputs as text (terminal) or saves as image via the vision tool.
"""

import logging
from .registry import register_tool

logger = logging.getLogger("seraph.tools.qr")


def _generate_qr_text(data: str, border: int = 1) -> str:
    """Generate a QR-like text representation. For real QR, use qrcode library."""
    # Simple text representation for terminal display
    # In production, install 'qrcode' package for real QR codes
    try:
        import qrcode
        qr = qrcode.QRCode(version=1, box_size=1, border=border)
        qr.add_data(data)
        qr.make(fit=True)

        lines = []
        matrix = qr.get_matrix()
        for row in matrix:
            line = ""
            for cell in row:
                line += "##" if cell else "  "
            lines.append(line)
        return "\n".join(lines)
    except ImportError:
        # Fallback: just show the data
        return f"[QR Code]\n{data}\n\n(Install 'qrcode' package for visual QR: pip install qrcode)"


def qr_code(action: str = "generate", data: str = "", output: str = "text") -> dict:
    if action == "generate":
        if not data:
            return {"error": "Provide data to encode"}
        qr_text = _generate_qr_text(data)
        return {
            "data": data,
            "qr": qr_text,
            "format": output,
        }

    elif action == "pairing":
        # Generate a pairing QR code with bot info
        import os
        bot_name = os.environ.get("SERAPH_BOT_NAME", "seraph")
        import json
        pairing_data = json.dumps({"bot": bot_name, "type": "pair", "ts": __import__("time").time()})
        qr_text = _generate_qr_text(pairing_data)
        return {"type": "pairing", "qr": qr_text, "data": pairing_data}

    return {"error": f"Unknown action: {action}"}


register_tool(
    name="qr_code",
    description="Generate QR codes for pairing, sharing URLs, or encoding data. Actions: generate, pairing.",
    parameters={
        "type": "object",
        "properties": {
            "action": {"type": "string", "enum": ["generate", "pairing"]},
            "data": {"type": "string", "description": "Data to encode in QR code"},
            "output": {"type": "string", "description": "Output format: text (default)"},
        },
        "required": ["action"],
    },
    handler=qr_code,
)
