"""
Seraph OpenAPI Tool Import — auto-generate tools from any API spec.

Give it a Swagger/OpenAPI spec URL and it creates callable tools automatically.
No manual tool writing needed.

Usage:
  from tools.openapi_import import import_openapi_tools
  import_openapi_tools("https://petstore.swagger.io/v2/swagger.json")
"""

import json
import logging
import requests
from typing import Dict, List
from .registry import register_tool

logger = logging.getLogger("seraph.tools.openapi")


def import_openapi_tools(spec_url: str, prefix: str = "", max_endpoints: int = 20) -> dict:
    """
    Import tools from an OpenAPI/Swagger spec URL.

    Each endpoint becomes a callable tool that the LLM can use.
    """
    try:
        resp = requests.get(spec_url, timeout=15)
        if resp.status_code != 200:
            return {"error": f"Failed to fetch spec: HTTP {resp.status_code}"}

        spec = resp.json()
    except Exception as e:
        return {"error": f"Failed to load spec: {e}"}

    # Detect spec version
    is_v3 = "openapi" in spec
    title = spec.get("info", {}).get("title", "API")
    base_url = ""

    if is_v3:
        servers = spec.get("servers", [])
        if servers:
            base_url = servers[0].get("url", "")
    else:
        # Swagger 2.0
        host = spec.get("host", "")
        base_path = spec.get("basePath", "")
        schemes = spec.get("schemes", ["https"])
        base_url = f"{schemes[0]}://{host}{base_path}"

    paths = spec.get("paths", {})
    imported = 0

    for path, methods in paths.items():
        if imported >= max_endpoints:
            break

        for method, details in methods.items():
            if method not in ("get", "post", "put", "delete", "patch"):
                continue
            if imported >= max_endpoints:
                break

            op_id = details.get("operationId", f"{method}_{path}".replace("/", "_").replace("{", "").replace("}", ""))
            summary = details.get("summary", details.get("description", f"{method.upper()} {path}"))[:100]
            tool_name = f"{prefix}{op_id}" if prefix else op_id

            # Build parameters schema
            params = {}
            required = []

            for param in details.get("parameters", []):
                param_name = param.get("name", "")
                param_type = param.get("schema", {}).get("type", param.get("type", "string"))
                param_desc = param.get("description", "")
                param_in = param.get("in", "query")

                params[param_name] = {
                    "type": param_type,
                    "description": f"{param_desc} (in: {param_in})" if param_desc else f"Parameter (in: {param_in})",
                }
                if param.get("required"):
                    required.append(param_name)

            # Create handler function
            full_url = f"{base_url}{path}"
            http_method = method.upper()

            def make_handler(url, method, params_spec):
                def handler(**kwargs):
                    try:
                        # Substitute path parameters
                        call_url = url
                        query_params = {}
                        body = {}

                        for key, val in kwargs.items():
                            if f"{{{key}}}" in call_url:
                                call_url = call_url.replace(f"{{{key}}}", str(val))
                            else:
                                query_params[key] = val

                        if method in ("GET", "DELETE"):
                            r = requests.request(method, call_url, params=query_params, timeout=15)
                        else:
                            r = requests.request(method, call_url, json=query_params or body, timeout=15)

                        if r.status_code < 400:
                            try:
                                return {"status": r.status_code, "data": r.json()}
                            except Exception:
                                return {"status": r.status_code, "data": r.text[:2000]}
                        else:
                            return {"error": f"HTTP {r.status_code}", "body": r.text[:500]}

                    except Exception as e:
                        return {"error": str(e)}

                return handler

            handler = make_handler(full_url, http_method, params)

            register_tool(
                name=tool_name,
                description=f"[API] {summary} ({http_method} {path})",
                parameters={
                    "type": "object",
                    "properties": params,
                    "required": required,
                },
                handler=handler,
            )

            imported += 1
            logger.info(f"Imported API tool: {tool_name} ({http_method} {path})")

    return {
        "api": title,
        "base_url": base_url,
        "tools_imported": imported,
        "spec_version": "3.x" if is_v3 else "2.0",
    }


# Register the importer itself as a tool
def _import_api(spec_url: str, prefix: str = "") -> dict:
    return import_openapi_tools(spec_url, prefix)


register_tool(
    name="import_api",
    description="Import tools from an OpenAPI/Swagger spec URL. Each API endpoint becomes a callable tool. Example: import_api('https://petstore.swagger.io/v2/swagger.json')",
    parameters={
        "type": "object",
        "properties": {
            "spec_url": {
                "type": "string",
                "description": "URL to the OpenAPI/Swagger spec JSON"
            },
            "prefix": {
                "type": "string",
                "description": "Prefix for imported tool names (optional)"
            }
        },
        "required": ["spec_url"]
    },
    handler=_import_api,
)
