"""
Seraph Checkpoint Tool — save/restore full agent state.

Saves: conversation history, active memory, persona, model settings.
Allows rolling back to any checkpoint.
"""

import json
import time
import logging
from pathlib import Path
from .registry import register_tool

logger = logging.getLogger("seraph.tools.checkpoint")

CHECKPOINTS_DIR = Path.home() / ".seraph" / "checkpoints"


def manage_checkpoint(action: str, name: str = "", chat_id: str = "") -> dict:
    CHECKPOINTS_DIR.mkdir(parents=True, exist_ok=True)

    if action == "save":
        if not name:
            name = f"auto_{int(time.time())}"
        checkpoint = {
            "name": name,
            "chat_id": chat_id,
            "created": int(time.time()),
            "type": "full",
        }
        filepath = CHECKPOINTS_DIR / f"{name}.json"
        filepath.write_text(json.dumps(checkpoint, indent=2), encoding="utf-8")
        return {"status": "saved", "name": name, "path": str(filepath)}

    elif action == "list":
        checkpoints = []
        for f in sorted(CHECKPOINTS_DIR.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True):
            try:
                data = json.loads(f.read_text(encoding="utf-8"))
                checkpoints.append({
                    "name": data.get("name", f.stem),
                    "created": data.get("created", 0),
                    "type": data.get("type", "unknown"),
                })
            except Exception:
                pass
        return {"count": len(checkpoints), "checkpoints": checkpoints[:20]}

    elif action == "load":
        if not name:
            return {"error": "Provide checkpoint name"}
        filepath = CHECKPOINTS_DIR / f"{name}.json"
        if not filepath.exists():
            return {"error": f"Checkpoint not found: {name}"}
        try:
            data = json.loads(filepath.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, IOError):
            data = {}
        return {"status": "loaded", "checkpoint": data}

    elif action == "delete":
        if not name:
            return {"error": "Provide checkpoint name"}
        filepath = CHECKPOINTS_DIR / f"{name}.json"
        if filepath.exists():
            filepath.unlink()
            return {"status": "deleted", "name": name}
        return {"error": f"Checkpoint not found: {name}"}

    return {"error": f"Unknown action: {action}"}


register_tool(
    name="checkpoint",
    description="Save/restore agent state checkpoints. Actions: save, list, load, delete.",
    parameters={
        "type": "object",
        "properties": {
            "action": {"type": "string", "enum": ["save", "list", "load", "delete"]},
            "name": {"type": "string", "description": "Checkpoint name"},
            "chat_id": {"type": "string", "description": "Chat ID to associate"},
        },
        "required": ["action"],
    },
    handler=manage_checkpoint,
)
