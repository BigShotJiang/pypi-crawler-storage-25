"""
Seraph File Tools — read, write, and list files.
"""

import os
import logging
from pathlib import Path
from .registry import register_tool

logger = logging.getLogger("seraph.tools.files")

WORK_DIR = Path.home() / ".seraph" / "workspace"
WORK_DIR.mkdir(parents=True, exist_ok=True)


def read_file(path: str) -> dict:
    """Read a file and return its contents."""
    try:
        # Resolve relative paths to workspace
        file_path = Path(path)
        if not file_path.is_absolute():
            file_path = WORK_DIR / path

        if not file_path.exists():
            return {"error": f"File not found: {path}"}

        content = file_path.read_text(encoding="utf-8", errors="replace")

        # Cap at 10000 chars to prevent token overflow
        if len(content) > 10000:
            content = content[:10000] + "\n... (truncated, file is " + str(len(file_path.read_text())) + " chars)"

        return {
            "content": content,
            "path": str(file_path),
            "size": file_path.stat().st_size,
            "lines": content.count("\n") + 1,
        }

    except Exception as e:
        return {"error": str(e)}


def write_file(path: str, content: str) -> dict:
    """Write content to a file. Creates parent directories if needed."""
    try:
        file_path = Path(path)
        if not file_path.is_absolute():
            file_path = WORK_DIR / path

        # Create parent dirs
        file_path.parent.mkdir(parents=True, exist_ok=True)

        file_path.write_text(content, encoding="utf-8")
        logger.info(f"Wrote {len(content)} chars to {file_path}")

        return {
            "path": str(file_path),
            "size": len(content),
            "lines": content.count("\n") + 1,
            "status": "written",
        }

    except Exception as e:
        return {"error": str(e)}


def list_files(directory: str = "", pattern: str = "*") -> dict:
    """List files in a directory."""
    try:
        dir_path = Path(directory) if directory else WORK_DIR
        if not dir_path.is_absolute():
            dir_path = WORK_DIR / directory

        if not dir_path.exists():
            return {"error": f"Directory not found: {directory}"}

        files = []
        for f in sorted(dir_path.glob(pattern)):
            files.append({
                "name": f.name,
                "path": str(f),
                "is_dir": f.is_dir(),
                "size": f.stat().st_size if f.is_file() else 0,
            })

        # Cap at 100 entries
        if len(files) > 100:
            files = files[:100]

        return {
            "directory": str(dir_path),
            "files": files,
            "count": len(files),
        }

    except Exception as e:
        return {"error": str(e)}


# Register tools
register_tool(
    name="read_file",
    description="Read the contents of a file. Returns the text content, file size, and line count.",
    parameters={
        "type": "object",
        "properties": {
            "path": {
                "type": "string",
                "description": "File path (relative to workspace or absolute)"
            }
        },
        "required": ["path"]
    },
    handler=read_file,
)

register_tool(
    name="write_file",
    description="Write content to a file. Creates the file and parent directories if they don't exist. Use for creating scripts, config files, HTML, code, etc.",
    parameters={
        "type": "object",
        "properties": {
            "path": {
                "type": "string",
                "description": "File path (relative to workspace or absolute)"
            },
            "content": {
                "type": "string",
                "description": "The content to write to the file"
            }
        },
        "required": ["path", "content"]
    },
    handler=write_file,
)

register_tool(
    name="list_files",
    description="List files in a directory. Returns file names, paths, sizes, and whether each is a directory.",
    parameters={
        "type": "object",
        "properties": {
            "directory": {
                "type": "string",
                "description": "Directory path (default: workspace)"
            },
            "pattern": {
                "type": "string",
                "description": "Glob pattern to filter files (default: *)"
            }
        },
    },
    handler=list_files,
)
