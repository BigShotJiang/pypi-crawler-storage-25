"""
Seraph Export Tool — export conversations and data.
"""

import json
import time
import logging
from pathlib import Path
from .registry import register_tool

logger = logging.getLogger("seraph.tools.export")

WORK_DIR = Path.home() / ".seraph" / "workspace"


def export_conversation(session_id: str = "", format: str = "markdown") -> dict:
    """Export a conversation to a file."""
    from memory.store import get_memory
    memory = get_memory()

    if not session_id:
        # Export all sessions
        messages = memory.conn.execute(
            "SELECT role, content, created_at, session_id FROM conversations ORDER BY id"
        ).fetchall()
    else:
        messages = memory.conn.execute(
            "SELECT role, content, created_at FROM conversations WHERE session_id=? ORDER BY id",
            (session_id,)
        ).fetchall()

    if not messages:
        return {"error": "No messages to export"}

    WORK_DIR.mkdir(parents=True, exist_ok=True)

    if format == "markdown":
        lines = ["# Seraph Conversation Export\n"]
        for m in messages:
            role = m["role"].upper()
            content = m["content"]
            ts = m["created_at"]
            lines.append(f"### [{role}] {ts}\n{content}\n")

        filename = f"export_{int(time.time())}.md"
        filepath = WORK_DIR / filename
        filepath.write_text("\n".join(lines), encoding="utf-8")

    elif format == "json":
        data = [{"role": m["role"], "content": m["content"], "time": m["created_at"]} for m in messages]
        filename = f"export_{int(time.time())}.json"
        filepath = WORK_DIR / filename
        filepath.write_text(json.dumps(data, indent=2), encoding="utf-8")

    else:
        return {"error": f"Unknown format: {format}. Use 'markdown' or 'json'."}

    return {
        "path": str(filepath),
        "messages": len(messages),
        "format": format,
    }


register_tool(
    name="export_conversation",
    description="Export conversation history to a file (markdown or JSON). Use for: saving chat logs, creating reports, backing up conversations.",
    parameters={
        "type": "object",
        "properties": {
            "session_id": {
                "type": "string",
                "description": "Session to export (empty = all sessions)"
            },
            "format": {
                "type": "string",
                "description": "Export format: markdown or json",
                "enum": ["markdown", "json"]
            }
        },
    },
    handler=export_conversation,
)
