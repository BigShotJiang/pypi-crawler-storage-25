"""
Seraph Approval Tool — human-in-the-loop for dangerous operations.

When a tool wants to do something dangerous (delete files, run destructive
commands, send emails), it can request approval first.
"""

import time
import logging
from .registry import register_tool

logger = logging.getLogger("seraph.tools.approval")

# Pending approvals: {approval_id: {action, status, ...}}
_pending = {}


def request_approval(action: str, details: str = "", risk_level: str = "high") -> dict:
    """
    Request human approval for a dangerous action.
    Returns immediately with an approval_id. The user must approve via /approve command.
    """
    approval_id = f"approval_{int(time.time())}"
    _pending[approval_id] = {
        "action": action,
        "details": details,
        "risk_level": risk_level,
        "status": "pending",
        "requested_at": int(time.time()),
    }
    return {
        "type": "approval_required",
        "approval_id": approval_id,
        "action": action,
        "details": details,
        "risk_level": risk_level,
        "message": f"This action requires approval: {action}\nRisk: {risk_level}\n\nReply 'approve' or 'deny'.",
    }


def check_approval(approval_id: str) -> dict:
    """Check status of a pending approval."""
    if approval_id not in _pending:
        return {"error": "Approval not found"}
    return _pending[approval_id]


def grant_approval(approval_id: str) -> dict:
    """Grant an approval."""
    if approval_id not in _pending:
        return {"error": "Approval not found"}
    _pending[approval_id]["status"] = "approved"
    _pending[approval_id]["approved_at"] = int(time.time())
    return {"status": "approved", "approval_id": approval_id}


def deny_approval(approval_id: str) -> dict:
    """Deny an approval."""
    if approval_id not in _pending:
        return {"error": "Approval not found"}
    _pending[approval_id]["status"] = "denied"
    return {"status": "denied", "approval_id": approval_id}


def list_pending() -> dict:
    """List all pending approvals."""
    pending = {k: v for k, v in _pending.items() if v["status"] == "pending"}
    return {"count": len(pending), "approvals": pending}


register_tool(
    name="request_approval",
    description="Request human approval before performing a dangerous action (deleting files, running destructive commands, sending emails). The user must approve before you proceed.",
    parameters={
        "type": "object",
        "properties": {
            "action": {"type": "string", "description": "What action needs approval"},
            "details": {"type": "string", "description": "Details about what will happen"},
            "risk_level": {"type": "string", "enum": ["low", "medium", "high", "critical"]},
        },
        "required": ["action"],
    },
    handler=request_approval,
)
