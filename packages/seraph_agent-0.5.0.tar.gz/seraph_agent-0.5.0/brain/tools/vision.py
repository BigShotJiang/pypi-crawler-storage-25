"""
Seraph Vision — understand images on any model.

If the current model supports vision, sends image directly.
If not, uses a vision-capable model as a one-off describer.
"""

import os
import logging
import base64
import requests
from pathlib import Path
from .registry import register_tool

logger = logging.getLogger("seraph.tools.vision")

# Models that support vision
VISION_MODELS = {"gpt-5.4", "gpt-4.1", "gpt-4o", "gpt-4-turbo", "claude-opus-4-6", "claude-sonnet-4-6"}

# Fallback vision model when current model can't see
FALLBACK_VISION_MODEL = "gpt-4o"


def describe_image(image_path: str = "", image_url: str = "", question: str = "What is in this image?") -> dict:
    """Describe an image using vision. Works on any model via fallback."""
    api_key = os.environ.get("OPENAI_API_KEY", "")
    if not api_key:
        return {"error": "OPENAI_API_KEY not set for vision"}

    # Build image content
    if image_path:
        path = Path(image_path)
        if not path.exists():
            return {"error": f"Image not found: {image_path}"}
        with open(path, "rb") as f:
            img_data = base64.b64encode(f.read()).decode()
        image_content = {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{img_data}"}}
    elif image_url:
        image_content = {"type": "image_url", "image_url": {"url": image_url}}
    else:
        return {"error": "Provide image_path or image_url"}

    try:
        resp = requests.post(
            "https://api.openai.com/v1/chat/completions",
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            json={
                "model": FALLBACK_VISION_MODEL,
                "messages": [
                    {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": question},
                            image_content,
                        ],
                    }
                ],
                "max_completion_tokens": 1000,
            },
            timeout=30,
        )

        if resp.status_code == 200:
            data = resp.json()
            description = data["choices"][0]["message"]["content"]
            tokens = data.get("usage", {})
            return {
                "description": description,
                "model_used": FALLBACK_VISION_MODEL,
                "tokens": tokens.get("total_tokens", 0),
            }
        else:
            return {"error": f"Vision API error {resp.status_code}: {resp.text[:200]}"}

    except Exception as e:
        return {"error": str(e)}


def can_current_model_see(model: str) -> bool:
    """Check if the current model supports vision natively."""
    return model in VISION_MODELS


register_tool(
    name="describe_image",
    description="Describe or analyze an image. Works with any model — uses vision-capable model as fallback. Provide either a local file path or URL.",
    parameters={
        "type": "object",
        "properties": {
            "image_path": {"type": "string", "description": "Local path to image file"},
            "image_url": {"type": "string", "description": "URL of image"},
            "question": {"type": "string", "description": "What to analyze (default: 'What is in this image?')"},
        },
    },
    handler=describe_image,
)
