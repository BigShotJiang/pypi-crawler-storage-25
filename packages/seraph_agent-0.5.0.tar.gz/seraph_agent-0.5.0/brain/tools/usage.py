"""
Seraph Usage Tracker — track token usage and costs.
"""

import json
import time
import logging
from pathlib import Path
from datetime import datetime, timezone
from .registry import register_tool

logger = logging.getLogger("seraph.usage")

USAGE_PATH = Path.home() / ".seraph" / "usage.json"

# Model pricing ($ per 1M tokens)
PRICING = {
    "gpt-5.4": {"input": 5.0, "output": 15.0},
    "gpt-4.1": {"input": 2.0, "output": 8.0},
    "gpt-4o": {"input": 2.5, "output": 10.0},
    "gpt-4o-mini": {"input": 0.15, "output": 0.6},
    "gpt-4.1-mini": {"input": 0.4, "output": 1.6},
    "gpt-4.1-nano": {"input": 0.1, "output": 0.4},
    "claude-opus-4-6": {"input": 15.0, "output": 75.0},
    "claude-sonnet-4-6": {"input": 3.0, "output": 15.0},
    "claude-haiku-4-5": {"input": 0.8, "output": 4.0},
}


def _load_usage() -> dict:
    if USAGE_PATH.exists():
        try:
            return json.loads(USAGE_PATH.read_text())
        except Exception:
            pass
    return {"sessions": [], "total": {"input_tokens": 0, "output_tokens": 0, "cost_usd": 0.0, "requests": 0}}


def _save_usage(data: dict):
    USAGE_PATH.parent.mkdir(parents=True, exist_ok=True)
    USAGE_PATH.write_text(json.dumps(data, indent=2))


def track(model: str, input_tokens: int, output_tokens: int):
    """Track a single API call."""
    data = _load_usage()
    pricing = PRICING.get(model, {"input": 5.0, "output": 15.0})
    cost = (input_tokens * pricing["input"] / 1_000_000) + (output_tokens * pricing["output"] / 1_000_000)

    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")

    # Find or create today's session
    today_session = None
    for s in data["sessions"]:
        if s["date"] == today:
            today_session = s
            break
    if not today_session:
        today_session = {"date": today, "input_tokens": 0, "output_tokens": 0, "cost_usd": 0.0, "requests": 0}
        data["sessions"].append(today_session)

    today_session["input_tokens"] += input_tokens
    today_session["output_tokens"] += output_tokens
    today_session["cost_usd"] += cost
    today_session["requests"] += 1

    data["total"]["input_tokens"] += input_tokens
    data["total"]["output_tokens"] += output_tokens
    data["total"]["cost_usd"] += cost
    data["total"]["requests"] += 1

    # Keep last 90 days
    data["sessions"] = data["sessions"][-90:]

    _save_usage(data)


def get_usage_stats() -> dict:
    """Get usage statistics."""
    data = _load_usage()
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    today_session = next((s for s in data["sessions"] if s["date"] == today), {})

    return {
        "today": {
            "input_tokens": today_session.get("input_tokens", 0),
            "output_tokens": today_session.get("output_tokens", 0),
            "cost_usd": round(today_session.get("cost_usd", 0), 4),
            "requests": today_session.get("requests", 0),
        },
        "total": {
            "input_tokens": data["total"]["input_tokens"],
            "output_tokens": data["total"]["output_tokens"],
            "cost_usd": round(data["total"]["cost_usd"], 4),
            "requests": data["total"]["requests"],
        },
        "days_tracked": len(data["sessions"]),
    }


register_tool(
    name="usage_stats",
    description="Get token usage and cost statistics. Shows today's usage and all-time totals.",
    parameters={"type": "object", "properties": {}},
    handler=get_usage_stats,
)
