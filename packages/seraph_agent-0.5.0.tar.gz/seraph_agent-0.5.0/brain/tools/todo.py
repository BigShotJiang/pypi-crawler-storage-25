"""
Seraph Todo Tool — persistent task tracking.

The agent can create, update, and complete tasks.
Stored in SQLite via memory store.
"""

import json
import time
import logging
from pathlib import Path
from .registry import register_tool

logger = logging.getLogger("seraph.tools.todo")

TODOS_FILE = Path.home() / ".seraph" / "todos.json"


def _load() -> list:
    if TODOS_FILE.exists():
        try:
            return json.loads(TODOS_FILE.read_text(encoding="utf-8"))
        except Exception:
            return []
    return []


def _save(todos: list):
    TODOS_FILE.parent.mkdir(parents=True, exist_ok=True)
    tmp = TODOS_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(todos, indent=2), encoding="utf-8")
    tmp.replace(TODOS_FILE)


def manage_todos(action: str, text: str = "", todo_id: int = 0) -> dict:
    todos = _load()

    if action == "add":
        todo = {"id": len(todos) + 1, "text": text, "status": "pending", "created": int(time.time())}
        todos.append(todo)
        _save(todos)
        return {"status": "added", "todo": todo}

    elif action == "complete":
        for t in todos:
            if t["id"] == todo_id:
                t["status"] = "done"
                t["completed"] = int(time.time())
                _save(todos)
                return {"status": "completed", "todo": t}
        return {"error": f"Todo #{todo_id} not found"}

    elif action == "delete":
        todos = [t for t in todos if t["id"] != todo_id]
        _save(todos)
        return {"status": "deleted", "id": todo_id}

    elif action == "list":
        pending = [t for t in todos if t["status"] == "pending"]
        done = [t for t in todos if t["status"] == "done"]
        return {"pending": pending, "done": done[-10:], "total": len(todos)}

    elif action == "clear_done":
        todos = [t for t in todos if t["status"] != "done"]
        _save(todos)
        return {"status": "cleared", "remaining": len(todos)}

    return {"error": f"Unknown action: {action}"}


register_tool(
    name="todo",
    description="Manage a persistent todo list. Actions: add, complete, delete, list, clear_done.",
    parameters={
        "type": "object",
        "properties": {
            "action": {"type": "string", "enum": ["add", "complete", "delete", "list", "clear_done"]},
            "text": {"type": "string", "description": "Todo text (for add)"},
            "todo_id": {"type": "integer", "description": "Todo ID (for complete/delete)"},
        },
        "required": ["action"],
    },
    handler=manage_todos,
)
