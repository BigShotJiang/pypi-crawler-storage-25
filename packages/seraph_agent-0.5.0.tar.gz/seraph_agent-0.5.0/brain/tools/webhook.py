"""
Seraph Webhooks — trigger actions via HTTP POST.

Register webhook URLs that fire when specific events happen
(tool execution, errors, daily summary, etc.).
"""

import os
import json
import logging
import requests
import time
from pathlib import Path
from .registry import register_tool

logger = logging.getLogger("seraph.tools.webhook")

WEBHOOK_FILE = Path.home() / ".seraph" / "webhooks.json"


def _load_webhooks() -> list:
    """Load registered webhooks from disk."""
    if WEBHOOK_FILE.exists():
        try:
            return json.loads(WEBHOOK_FILE.read_text(encoding="utf-8"))
        except Exception:
            return []
    return []


def _save_webhooks(webhooks: list):
    """Save webhooks to disk atomically."""
    WEBHOOK_FILE.parent.mkdir(parents=True, exist_ok=True)
    tmp = WEBHOOK_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(webhooks, indent=2), encoding="utf-8")
    tmp.replace(WEBHOOK_FILE)


def register_webhook(name: str, url: str, events: list = None, secret: str = "") -> dict:
    """Register a new webhook."""
    webhooks = _load_webhooks()

    # Check for duplicates
    for w in webhooks:
        if w["name"] == name:
            return {"error": f"Webhook '{name}' already exists. Delete it first."}

    webhook = {
        "name": name,
        "url": url,
        "events": events or ["all"],
        "secret": secret,
        "created": int(time.time()),
        "active": True,
    }
    webhooks.append(webhook)
    _save_webhooks(webhooks)
    return {"status": "registered", "name": name, "events": webhook["events"]}


def fire_webhook(event: str, data: dict) -> list:
    """Fire all webhooks registered for an event."""
    webhooks = _load_webhooks()
    results = []

    for w in webhooks:
        if not w.get("active", True):
            continue
        if "all" not in w.get("events", []) and event not in w.get("events", []):
            continue

        payload = {
            "event": event,
            "timestamp": int(time.time()),
            "data": data,
        }

        headers = {"Content-Type": "application/json"}
        if w.get("secret"):
            import hashlib
            import hmac
            sig = hmac.new(w["secret"].encode(), json.dumps(payload).encode(), hashlib.sha256).hexdigest()
            headers["X-Seraph-Signature"] = sig

        try:
            resp = requests.post(w["url"], json=payload, headers=headers, timeout=5)
            results.append({"name": w["name"], "status": resp.status_code})
        except Exception as e:
            results.append({"name": w["name"], "error": str(e)})

    return results


def list_webhooks() -> dict:
    """List all registered webhooks."""
    webhooks = _load_webhooks()
    return {
        "count": len(webhooks),
        "webhooks": [
            {"name": w["name"], "url": w["url"][:50], "events": w["events"], "active": w.get("active", True)}
            for w in webhooks
        ],
    }


def delete_webhook(name: str) -> dict:
    """Delete a webhook by name."""
    webhooks = _load_webhooks()
    new_list = [w for w in webhooks if w["name"] != name]
    if len(new_list) == len(webhooks):
        return {"error": f"Webhook '{name}' not found"}
    _save_webhooks(new_list)
    return {"status": "deleted", "name": name}


register_tool(
    name="manage_webhook",
    description="Register, list, or delete webhooks. Webhooks fire HTTP POST requests when events happen (tool_call, error, daily_summary).",
    parameters={
        "type": "object",
        "properties": {
            "action": {"type": "string", "enum": ["register", "list", "delete", "fire"], "description": "Action to perform"},
            "name": {"type": "string", "description": "Webhook name (for register/delete)"},
            "url": {"type": "string", "description": "Webhook URL (for register)"},
            "events": {"type": "array", "items": {"type": "string"}, "description": "Events to trigger on (default: all)"},
            "event": {"type": "string", "description": "Event name (for fire)"},
            "data": {"type": "object", "description": "Payload data (for fire)"},
        },
        "required": ["action"],
    },
    handler=lambda action, name="", url="", events=None, event="", data=None, **kw: (
        register_webhook(name, url, events) if action == "register"
        else list_webhooks() if action == "list"
        else delete_webhook(name) if action == "delete"
        else fire_webhook(event, data or {}) if action == "fire"
        else {"error": f"Unknown action: {action}"}
    ),
)
