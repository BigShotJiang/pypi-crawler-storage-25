"""
Seraph Interrupt Tool — cancel running tool executions.

Works with the process registry to kill hung processes.
"""

import logging
from .registry import register_tool

logger = logging.getLogger("seraph.tools.interrupt")


def interrupt_tool(process_id: int = 0, all_running: bool = False) -> dict:
    """Interrupt running processes."""
    from agent.process_registry import get_process_registry
    registry = get_process_registry()

    if all_running:
        running = registry.list_running()
        killed = 0
        for proc in running:
            if registry.kill_process(proc.pid):
                killed += 1
        return {"status": "interrupted", "killed": killed, "total_running": len(running)}

    if process_id:
        proc = registry.get(process_id)
        if not proc:
            return {"error": f"Process {process_id} not found"}
        if registry.kill_process(process_id):
            return {"status": "killed", "pid": process_id, "name": proc.name}
        return {"error": f"Failed to kill process {process_id}"}

    # List running processes
    running = registry.list_running()
    if not running:
        return {"status": "nothing_running", "message": "No running processes to interrupt"}

    return {
        "running": [
            {"pid": p.pid, "name": p.name, "command": p.command[:80], "elapsed": p.elapsed_str()}
            for p in running
        ],
        "message": "Provide process_id to kill a specific process, or set all_running=true",
    }


register_tool(
    name="interrupt",
    description="Interrupt or cancel running tool executions. List running processes, kill by PID, or kill all.",
    parameters={
        "type": "object",
        "properties": {
            "process_id": {"type": "integer", "description": "PID to kill"},
            "all_running": {"type": "boolean", "description": "Kill all running processes"},
        },
    },
    handler=interrupt_tool,
)
