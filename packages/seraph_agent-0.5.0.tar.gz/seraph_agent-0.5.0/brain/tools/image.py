"""
Seraph Image Tool — generate images with DALL-E or download from URL.
"""

import os
import logging
import requests
import time
from pathlib import Path
from .registry import register_tool

logger = logging.getLogger("seraph.tools.image")

WORK_DIR = Path.home() / ".seraph" / "workspace"


def generate_image(prompt: str, size: str = "1024x1024", quality: str = "standard") -> dict:
    """Generate an image using OpenAI DALL-E."""
    api_key = os.environ.get("OPENAI_API_KEY", "")
    if not api_key:
        return {"error": "OPENAI_API_KEY not set"}

    try:
        resp = requests.post(
            "https://api.openai.com/v1/images/generations",
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            json={
                "model": "dall-e-3",
                "prompt": prompt,
                "n": 1,
                "size": size,
                "quality": quality,
            },
            timeout=60,
        )

        if resp.status_code == 200:
            data = resp.json()
            image_url = data["data"][0]["url"]
            revised_prompt = data["data"][0].get("revised_prompt", prompt)

            # Download image to workspace
            img_resp = requests.get(image_url, timeout=30)
            filename = f"image_{int(time.time())}.png"
            filepath = WORK_DIR / filename
            WORK_DIR.mkdir(parents=True, exist_ok=True)
            filepath.write_bytes(img_resp.content)

            return {
                "url": image_url,
                "local_path": str(filepath),
                "revised_prompt": revised_prompt,
                "size": size,
            }
        else:
            return {"error": f"DALL-E error {resp.status_code}: {resp.text[:200]}"}

    except Exception as e:
        return {"error": str(e)}


register_tool(
    name="generate_image",
    description="Generate an image using DALL-E 3. Returns a URL and saves the image locally. Use for: creating logos, illustrations, mockups, concept art, social media images.",
    parameters={
        "type": "object",
        "properties": {
            "prompt": {
                "type": "string",
                "description": "Detailed description of the image to generate"
            },
            "size": {
                "type": "string",
                "description": "Image size: 1024x1024, 1792x1024, or 1024x1792",
                "enum": ["1024x1024", "1792x1024", "1024x1792"]
            },
            "quality": {
                "type": "string",
                "description": "Quality: standard or hd",
                "enum": ["standard", "hd"]
            }
        },
        "required": ["prompt"]
    },
    handler=generate_image,
)
