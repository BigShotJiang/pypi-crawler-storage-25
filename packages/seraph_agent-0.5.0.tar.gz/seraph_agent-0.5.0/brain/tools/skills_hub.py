"""
Seraph Skills Hub — browse, install, sync skills from registries.

Skills are stored in ~/.seraph/skills/<name>/SKILL.md
Can install from GitHub repos or local directories.
"""

import os
import json
import shutil
import logging
import subprocess
import time
from pathlib import Path
from typing import Dict, List
from .registry import register_tool

logger = logging.getLogger("seraph.tools.skills_hub")

SKILLS_DIR = Path.home() / ".seraph" / "skills"
HUB_CACHE = Path.home() / ".seraph" / "skills_cache.json"

# Built-in skill registry
REGISTRY = {
    "seraph/code-review": {"description": "Automated code review with scoring", "url": ""},
    "seraph/deploy": {"description": "Deploy to various platforms", "url": ""},
    "seraph/tdd": {"description": "Test-driven development workflow", "url": ""},
    "seraph/debug": {"description": "Systematic debugging procedure", "url": ""},
    "seraph/research": {"description": "Deep research with source verification", "url": ""},
}


def skills_hub(action: str, name: str = "", url: str = "", source: str = "community") -> dict:
    SKILLS_DIR.mkdir(parents=True, exist_ok=True)

    if action == "list":
        installed = []
        for d in SKILLS_DIR.iterdir():
            if d.is_dir() and (d / "SKILL.md").exists():
                content = (d / "SKILL.md").read_text(encoding="utf-8", errors="replace")
                desc = ""
                for line in content.splitlines():
                    if line.startswith("description:"):
                        desc = line.split(":", 1)[1].strip()
                        break
                installed.append({"name": d.name, "description": desc, "path": str(d)})
        return {"installed": installed, "count": len(installed)}

    elif action == "search":
        query = name.lower()
        matches = []
        for rname, info in REGISTRY.items():
            if query in rname.lower() or query in info["description"].lower():
                matches.append({"name": rname, "description": info["description"]})
        return {"query": name, "matches": matches, "count": len(matches)}

    elif action == "install":
        if not name and not url:
            return {"error": "Provide skill name or URL"}

        if url:
            # Install from git URL
            skill_name = url.rstrip("/").split("/")[-1].replace(".git", "")
            target = SKILLS_DIR / skill_name
            if target.exists():
                return {"error": f"Skill '{skill_name}' already installed. Use update or remove first."}
            try:
                result = subprocess.run(
                    ["git", "clone", "--depth", "1", url, str(target)],
                    capture_output=True, text=True, timeout=30,
                )
                if result.returncode == 0:
                    # Security scan
                    from skills.guard import scan_skill, should_allow_install, format_scan_report
                    scan = scan_skill(target, source=source)
                    allowed, reason = should_allow_install(scan)
                    if not allowed:
                        shutil.rmtree(target, ignore_errors=True)
                        return {"error": f"Skill blocked by security scan: {reason}", "report": format_scan_report(scan)}
                    return {"status": "installed", "name": skill_name, "path": str(target), "trust_score": scan.trust_score}
                return {"error": f"Git clone failed: {result.stderr[:200]}"}
            except Exception as e:
                return {"error": str(e)}

        elif name in REGISTRY:
            reg_url = REGISTRY[name].get("url", "")
            if reg_url:
                return skills_hub("install", url=reg_url, source="trusted")
            return {"error": f"Skill '{name}' has no install URL yet"}
        else:
            return {"error": f"Skill '{name}' not found in registry"}

    elif action == "remove":
        if not name:
            return {"error": "Provide skill name"}
        target = SKILLS_DIR / name
        if target.exists():
            shutil.rmtree(target, ignore_errors=True)
            return {"status": "removed", "name": name}
        return {"error": f"Skill not found: {name}"}

    elif action == "update":
        if not name:
            return {"error": "Provide skill name"}
        target = SKILLS_DIR / name
        if not target.exists():
            return {"error": f"Skill not installed: {name}"}
        try:
            result = subprocess.run(
                ["git", "-C", str(target), "pull", "--ff-only"],
                capture_output=True, text=True, timeout=30,
            )
            return {"status": "updated", "name": name, "output": result.stdout[:200]}
        except Exception as e:
            return {"error": str(e)}

    return {"error": f"Unknown action: {action}. Use: list, search, install, remove, update"}


register_tool(
    name="skills_hub",
    description="Browse, install, update, and remove skills from registries. Actions: list, search, install (from URL or registry), remove, update.",
    parameters={
        "type": "object",
        "properties": {
            "action": {"type": "string", "enum": ["list", "search", "install", "remove", "update"]},
            "name": {"type": "string", "description": "Skill name or search query"},
            "url": {"type": "string", "description": "Git URL to install from"},
            "source": {"type": "string", "description": "Trust level: trusted, community (default: community)"},
        },
        "required": ["action"],
    },
    handler=skills_hub,
)
