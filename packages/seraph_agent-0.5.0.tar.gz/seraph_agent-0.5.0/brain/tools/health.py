"""
Seraph Health Check — system status and diagnostics.
"""

import time
import logging
import platform
import os
from pathlib import Path
from .registry import register_tool

logger = logging.getLogger("seraph.tools.health")

_start_time = time.time()


def health_check() -> dict:
    """Run a comprehensive health check."""
    from memory.store import get_memory
    from tools.registry import get_all_tools

    mem = get_memory()
    tools = get_all_tools()
    uptime = time.time() - _start_time

    hours = int(uptime // 3600)
    minutes = int((uptime % 3600) // 60)

    # Check memory DB
    mem_ok = True
    try:
        mem.get_message_count()
    except Exception:
        mem_ok = False

    # Check disk space
    seraph_dir = Path.home() / ".seraph"
    db_size = 0
    if (seraph_dir / "memory.db").exists():
        db_size = (seraph_dir / "memory.db").stat().st_size

    return {
        "status": "healthy",
        "uptime": f"{hours}h {minutes}m",
        "uptime_seconds": int(uptime),
        "platform": platform.system(),
        "python": platform.python_version(),
        "tools_loaded": len(tools),
        "memory_ok": mem_ok,
        "memory_messages": mem.get_message_count(),
        "memory_sessions": mem.get_session_count(),
        "memory_db_size_kb": db_size // 1024,
        "model": os.environ.get("SERAPH_MODEL", "?"),
        "provider": os.environ.get("SERAPH_PROVIDER", "?"),
    }


register_tool(
    name="health_check",
    description="Run a system health check. Returns uptime, tool count, memory status, model info.",
    parameters={"type": "object", "properties": {}},
    handler=health_check,
)
