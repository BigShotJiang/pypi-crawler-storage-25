"""
Seraph Rate Limiter — prevent API cost overrun.
"""

import time
import logging
from collections import defaultdict

logger = logging.getLogger("seraph.ratelimit")


class RateLimiter:
    """Token bucket rate limiter per user."""

    def __init__(self, requests_per_minute: int = 20, daily_cost_limit: float = 5.0):
        self.rpm = requests_per_minute
        self.daily_limit = daily_cost_limit
        self._buckets = defaultdict(list)  # user_id -> list of timestamps
        self._daily_cost = 0.0
        self._cost_reset_day = ""

    def check(self, user_id: str) -> tuple:
        """Check if a request is allowed. Returns (allowed, reason)."""
        now = time.time()

        # Check daily cost limit
        from datetime import datetime, timezone
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        if today != self._cost_reset_day:
            self._daily_cost = 0.0
            self._cost_reset_day = today

        if self._daily_cost >= self.daily_limit:
            return False, f"Daily cost limit reached (${self._daily_cost:.2f}/${self.daily_limit:.2f})"

        # Check rate limit
        bucket = self._buckets[user_id]
        # Remove old entries
        bucket[:] = [t for t in bucket if now - t < 60]

        if len(bucket) >= self.rpm:
            return False, f"Rate limit: {self.rpm} requests/minute"

        bucket.append(now)
        return True, None

    def add_cost(self, cost: float):
        """Track cost."""
        self._daily_cost += cost


# Singleton
_limiter = None

def get_limiter() -> RateLimiter:
    global _limiter
    if _limiter is None:
        _limiter = RateLimiter()
    return _limiter
