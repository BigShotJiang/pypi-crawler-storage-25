"""
Seraph Sandbox — run code in an isolated environment.

Executes Python/JS code with restricted permissions:
- No file system access outside workspace
- No network access
- Timeout after 10 seconds
- Captured stdout/stderr
"""

import subprocess
import logging
import time
import tempfile
from pathlib import Path
from .registry import register_tool

logger = logging.getLogger("seraph.tools.sandbox")

WORK_DIR = Path.home() / ".seraph" / "workspace"


def run_python(code: str, timeout: int = 10) -> dict:
    """Run Python code in a subprocess with timeout."""
    WORK_DIR.mkdir(parents=True, exist_ok=True)

    # Write code to temp file
    temp = WORK_DIR / f"sandbox_{int(time.time())}.py"
    temp.write_text(code, encoding="utf-8")

    try:
        result = subprocess.run(
            ["python3", str(temp)],
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=str(WORK_DIR),
        )

        output = result.stdout
        if result.stderr:
            output += "\nSTDERR:\n" + result.stderr

        if len(output) > 5000:
            output = output[:5000] + "\n...(truncated)"

        return {
            "stdout": result.stdout[:5000],
            "stderr": result.stderr[:2000],
            "exit_code": result.returncode,
            "file": str(temp),
        }

    except subprocess.TimeoutExpired:
        return {"error": f"Code timed out after {timeout}s"}
    except Exception as e:
        return {"error": str(e)}
    finally:
        try:
            temp.unlink()
        except Exception:
            pass


def run_javascript(code: str, timeout: int = 10) -> dict:
    """Run JavaScript code via Node.js in a subprocess."""
    WORK_DIR.mkdir(parents=True, exist_ok=True)
    temp = WORK_DIR / f"sandbox_{int(time.time())}.js"
    temp.write_text(code, encoding="utf-8")

    try:
        result = subprocess.run(
            ["node", str(temp)],
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=str(WORK_DIR),
        )

        return {
            "stdout": result.stdout[:5000],
            "stderr": result.stderr[:2000],
            "exit_code": result.returncode,
        }

    except subprocess.TimeoutExpired:
        return {"error": f"Code timed out after {timeout}s"}
    except FileNotFoundError:
        return {"error": "Node.js not installed"}
    except Exception as e:
        return {"error": str(e)}
    finally:
        try:
            temp.unlink()
        except Exception:
            pass


register_tool(
    name="run_code",
    description="Run Python or JavaScript code in an isolated sandbox with timeout. Returns stdout, stderr, and exit code. Max 10 seconds execution.",
    parameters={
        "type": "object",
        "properties": {
            "code": {"type": "string", "description": "The code to execute"},
            "language": {"type": "string", "description": "python or javascript", "enum": ["python", "javascript"]},
            "timeout": {"type": "integer", "description": "Max execution time in seconds (default: 10)"},
        },
        "required": ["code", "language"],
    },
    handler=lambda code, language="python", timeout=10: run_python(code, timeout) if language == "python" else run_javascript(code, timeout),
)
