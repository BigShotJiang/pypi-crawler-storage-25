"""
Seraph Tool Registry — manages all tools the agent can use.
"""

import logging
from typing import Dict, Callable, Any

logger = logging.getLogger("seraph.tools")


# Global tool registry
_tools: Dict[str, dict] = {}


def register_tool(name: str, description: str, parameters: dict, handler: Callable):
    """Register a tool that the agent can call."""
    _tools[name] = {
        "name": name,
        "description": description,
        "parameters": parameters,
        "handler": handler,
    }
    logger.debug(f"Registered tool: {name}")


def get_tool(name: str) -> dict:
    """Get a tool by name."""
    return _tools.get(name)


def get_all_tools() -> Dict[str, dict]:
    """Get all registered tools."""
    return _tools


def get_openai_tool_schemas() -> list:
    """Get tool schemas in OpenAI function calling format."""
    schemas = []
    for name, tool in _tools.items():
        schemas.append({
            "type": "function",
            "function": {
                "name": name,
                "description": tool["description"],
                "parameters": tool["parameters"],
            }
        })
    return schemas


async def execute_tool(name: str, arguments: dict) -> Any:
    """Execute a tool by name with arguments. Rules are checked first."""
    # Check rules BEFORE execution
    try:
        from rules.enforcer import get_enforcer
        enforcer = get_enforcer()
        allowed, message = enforcer.check(name, arguments)
        if not allowed:
            logger.warning(f"Tool {name} blocked: {message}")
            return {"error": message, "blocked": True}
        if message:
            logger.info(f"Tool {name} warning: {message}")
    except ImportError:
        pass  # Rules module not available

    tool = _tools.get(name)
    if not tool:
        return {"error": f"Unknown tool: {name}"}

    try:
        result = tool["handler"](**arguments)
        return result
    except Exception as e:
        logger.error(f"Tool {name} failed: {e}")
        return {"error": str(e)}
