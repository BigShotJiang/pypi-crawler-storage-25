"""
Seraph Database Tool — run SQLite queries.
"""

import sqlite3
import logging
import json
from pathlib import Path
from .registry import register_tool

logger = logging.getLogger("seraph.tools.database")


def query_sqlite(db_path: str, query: str, params: list = None) -> dict:
    """Run a SQL query on a SQLite database."""
    try:
        path = Path(db_path)
        if not path.exists():
            return {"error": f"Database not found: {db_path}"}

        conn = sqlite3.connect(str(path))
        conn.row_factory = sqlite3.Row

        cursor = conn.execute(query, params or [])

        # Check if it's a SELECT query
        if query.strip().upper().startswith("SELECT") or query.strip().upper().startswith("PRAGMA"):
            rows = cursor.fetchall()
            results = [dict(r) for r in rows]

            # Cap results
            if len(results) > 100:
                results = results[:100]

            conn.close()
            return {
                "rows": results,
                "count": len(results),
                "columns": [d[0] for d in cursor.description] if cursor.description else [],
            }
        else:
            conn.commit()
            affected = cursor.rowcount
            conn.close()
            return {
                "affected_rows": affected,
                "status": "executed",
            }

    except Exception as e:
        return {"error": str(e)}


register_tool(
    name="query_sqlite",
    description="Run a SQL query on a SQLite database. Use for: reading data, running analytics, checking database state. Supports SELECT, INSERT, UPDATE, DELETE.",
    parameters={
        "type": "object",
        "properties": {
            "db_path": {
                "type": "string",
                "description": "Path to the SQLite database file"
            },
            "query": {
                "type": "string",
                "description": "SQL query to execute"
            },
            "params": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Query parameters (for parameterized queries)"
            }
        },
        "required": ["db_path", "query"]
    },
    handler=query_sqlite,
)
