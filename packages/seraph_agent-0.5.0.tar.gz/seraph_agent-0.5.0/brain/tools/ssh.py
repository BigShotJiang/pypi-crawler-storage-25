"""
Seraph SSH Tool — execute commands on remote servers.
"""

import subprocess
import logging
import os
from pathlib import Path
from .registry import register_tool

logger = logging.getLogger("seraph.tools.ssh")

# Default SSH config
DEFAULT_KEY = str(Path.home() / ".ssh" / "hetzner_trading")
DEFAULT_HOST = "botuser@65.109.13.25"


def ssh_exec(command: str, host: str = "", key_path: str = "") -> dict:
    """Execute a command on a remote server via SSH."""
    host = host or DEFAULT_HOST
    key = key_path or DEFAULT_KEY

    if not Path(key).exists():
        return {"error": f"SSH key not found: {key}"}

    ssh_cmd = f'ssh -i "{key}" -o StrictHostKeyChecking=no -o ConnectTimeout=10 {host} "{command}"'

    logger.info(f"SSH: {host} > {command[:80]}")

    try:
        result = subprocess.run(
            ssh_cmd,
            shell=True,
            capture_output=True,
            text=True,
            timeout=60,
        )

        output = result.stdout
        if result.stderr:
            output += "\n" + result.stderr

        if len(output) > 5000:
            output = output[:5000] + "\n...(truncated)"

        return {
            "stdout": result.stdout[:5000],
            "stderr": result.stderr[:2000],
            "exit_code": result.returncode,
            "host": host,
            "command": command,
        }

    except subprocess.TimeoutExpired:
        return {"error": f"SSH command timed out after 60s"}
    except Exception as e:
        return {"error": str(e)}


register_tool(
    name="ssh",
    description="Execute a command on a remote server via SSH. Default server is the Hetzner VPS (botuser@65.109.13.25). Use for: checking bot status, reading logs, restarting services, editing remote files.",
    parameters={
        "type": "object",
        "properties": {
            "command": {
                "type": "string",
                "description": "The command to run on the remote server"
            },
            "host": {
                "type": "string",
                "description": "SSH host (default: botuser@65.109.13.25)"
            },
            "key_path": {
                "type": "string",
                "description": "Path to SSH key (default: ~/.ssh/hetzner_trading)"
            }
        },
        "required": ["command"]
    },
    handler=ssh_exec,
)
