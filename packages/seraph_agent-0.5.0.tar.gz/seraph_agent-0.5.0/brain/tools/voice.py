"""
Seraph Voice Tool — text-to-speech using OpenAI TTS.

Generates audio from text and sends as voice message.
"""

import os
import time
import logging
import requests
from pathlib import Path
from .registry import register_tool

logger = logging.getLogger("seraph.tools.voice")

WORK_DIR = Path.home() / ".seraph" / "workspace"


def text_to_speech(text: str, voice: str = "alloy", speed: float = 1.0) -> dict:
    """Convert text to speech using OpenAI TTS API."""
    api_key = os.environ.get("OPENAI_API_KEY", "")
    if not api_key:
        return {"error": "OPENAI_API_KEY not set"}

    if len(text) > 4096:
        text = text[:4096]

    try:
        resp = requests.post(
            "https://api.openai.com/v1/audio/speech",
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            json={
                "model": "tts-1",
                "input": text,
                "voice": voice,
                "speed": speed,
                "response_format": "opus",
            },
            timeout=30,
        )

        if resp.status_code == 200:
            WORK_DIR.mkdir(parents=True, exist_ok=True)
            filename = f"voice_{int(time.time())}.opus"
            filepath = WORK_DIR / filename
            filepath.write_bytes(resp.content)

            return {
                "path": str(filepath),
                "size": len(resp.content),
                "voice": voice,
                "text_length": len(text),
                "format": "opus",
            }
        else:
            return {"error": f"TTS error {resp.status_code}: {resp.text[:200]}"}

    except Exception as e:
        return {"error": str(e)}


register_tool(
    name="text_to_speech",
    description="Convert text to speech audio using OpenAI TTS. Voices: alloy, echo, fable, onyx, nova, shimmer. Returns path to audio file.",
    parameters={
        "type": "object",
        "properties": {
            "text": {
                "type": "string",
                "description": "Text to convert to speech (max 4096 chars)"
            },
            "voice": {
                "type": "string",
                "description": "Voice to use: alloy, echo, fable, onyx, nova, shimmer",
                "enum": ["alloy", "echo", "fable", "onyx", "nova", "shimmer"]
            },
            "speed": {
                "type": "number",
                "description": "Speed multiplier 0.25-4.0 (default: 1.0)"
            }
        },
        "required": ["text"]
    },
    handler=text_to_speech,
)
