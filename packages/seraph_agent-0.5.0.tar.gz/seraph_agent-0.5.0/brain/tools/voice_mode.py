"""
Seraph Voice Mode — continuous voice conversation.

Records audio, transcribes, processes, speaks response.
Uses OpenAI Whisper for STT and TTS for speech.
"""

import os
import time
import logging
import requests
import tempfile
from pathlib import Path
from .registry import register_tool

logger = logging.getLogger("seraph.tools.voice_mode")

WORKSPACE = Path.home() / ".seraph" / "workspace"


def voice_respond(text: str, voice: str = "alloy") -> dict:
    """Convert text response to speech and return audio file path."""
    api_key = os.environ.get("OPENAI_API_KEY", "")
    if not api_key:
        return {"error": "OPENAI_API_KEY not set"}

    WORKSPACE.mkdir(parents=True, exist_ok=True)
    output_path = WORKSPACE / f"voice_{int(time.time())}.mp3"

    try:
        resp = requests.post(
            "https://api.openai.com/v1/audio/speech",
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            json={
                "model": "tts-1",
                "input": text[:4096],
                "voice": voice,
                "response_format": "mp3",
            },
            timeout=30,
        )
        if resp.status_code == 200:
            output_path.write_bytes(resp.content)
            return {
                "audio_path": str(output_path),
                "size_kb": len(resp.content) // 1024,
                "voice": voice,
                "text_length": len(text),
            }
        return {"error": f"TTS error {resp.status_code}: {resp.text[:200]}"}
    except Exception as e:
        return {"error": str(e)}


def transcribe_audio(file_path: str) -> dict:
    """Transcribe audio file to text using Whisper."""
    api_key = os.environ.get("OPENAI_API_KEY", "")
    if not api_key:
        return {"error": "OPENAI_API_KEY not set"}

    path = Path(file_path)
    if not path.exists():
        return {"error": f"File not found: {file_path}"}

    try:
        with open(path, "rb") as f:
            resp = requests.post(
                "https://api.openai.com/v1/audio/transcriptions",
                headers={"Authorization": f"Bearer {api_key}"},
                files={"file": (path.name, f, "audio/mpeg")},
                data={"model": "whisper-1"},
                timeout=30,
            )
        if resp.status_code == 200:
            return {"text": resp.json().get("text", ""), "file": file_path}
        return {"error": f"Whisper error {resp.status_code}"}
    except Exception as e:
        return {"error": str(e)}


register_tool(
    name="voice_respond",
    description="Convert text to speech audio. Returns an audio file path. Voices: alloy, echo, fable, onyx, nova, shimmer.",
    parameters={
        "type": "object",
        "properties": {
            "text": {"type": "string", "description": "Text to convert to speech"},
            "voice": {"type": "string", "description": "Voice: alloy, echo, fable, onyx, nova, shimmer", "enum": ["alloy", "echo", "fable", "onyx", "nova", "shimmer"]},
        },
        "required": ["text"],
    },
    handler=voice_respond,
)
