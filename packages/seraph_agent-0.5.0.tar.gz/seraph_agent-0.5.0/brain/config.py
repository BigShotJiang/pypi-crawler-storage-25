"""
Seraph Configuration — loads from ~/.seraph/config.yaml + .env + environment.

Priority: environment vars > .env > config.yaml > defaults
"""

import os
import yaml
import logging
from pathlib import Path
from typing import Any, Dict, Optional

logger = logging.getLogger("seraph.config")

SERAPH_DIR = Path.home() / ".seraph"
CONFIG_PATH = SERAPH_DIR / "config.yaml"
ENV_PATH = SERAPH_DIR / ".env"

# Also check project-level .env
PROJECT_ENV = Path.cwd() / ".env"

DEFAULTS = {
    "provider": "openai",
    "model": "gpt-5.4",
    "gateway_port": 18800,
    "brain_port": 18801,
    "max_iterations": 10,
    "max_tokens": 4096,
    "temperature": 0.7,
    "memory": {
        "enabled": True,
        "search": "fts5",
        "cleanup_days": 90,
    },
    "skills": {
        "auto_generate": True,
        "directory": str(SERAPH_DIR / "skills"),
    },
    "audit": {
        "enabled": True,
        "max_rounds": 5,
    },
    "telegram": {
        "enabled": False,
        "token": "",
        "allowed_users": [],
    },
    "discord": {
        "enabled": False,
        "token": "",
        "allowed_users": [],
    },
    "budget": {
        "enabled": False,
        "daily_limit_usd": 5.0,
        "model_routing": "quality",  # "quality" or "budget"
    },
}


class Config:
    """Seraph configuration manager."""

    def __init__(self):
        self._data = {}
        self._load()

    def _load(self):
        """Load config from all sources."""
        # Start with defaults
        self._data = self._deep_copy(DEFAULTS)

        # Load config.yaml
        if CONFIG_PATH.exists():
            try:
                with open(CONFIG_PATH) as f:
                    yaml_data = yaml.safe_load(f) or {}
                self._deep_merge(self._data, yaml_data)
                logger.info(f"Loaded config from {CONFIG_PATH}")
            except Exception as e:
                logger.warning(f"Failed to load config.yaml: {e}")

        # Load .env files
        for env_path in [ENV_PATH, PROJECT_ENV]:
            if env_path.exists():
                self._load_env(env_path)

        # Map env vars to config
        self._apply_env_overrides()

    def _load_env(self, path: Path):
        """Load environment variables from .env file."""
        try:
            with open(path) as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith("#") and "=" in line:
                        key, value = line.split("=", 1)
                        os.environ.setdefault(key.strip(), value.strip())
        except Exception as e:
            logger.warning(f"Failed to load {path}: {e}")

    def _apply_env_overrides(self):
        """Override config with environment variables."""
        env_map = {
            "SERAPH_PROVIDER": "provider",
            "SERAPH_MODEL": "model",
            "SERAPH_GATEWAY_PORT": "gateway_port",
            "SERAPH_BRAIN_PORT": "brain_port",
        }
        for env_key, config_key in env_map.items():
            val = os.environ.get(env_key)
            if val:
                self._data[config_key] = val

        # Telegram
        tg_token = os.environ.get("SERAPH_TELEGRAM_TOKEN")
        if tg_token:
            self._data["telegram"]["enabled"] = True
            self._data["telegram"]["token"] = tg_token
        tg_users = os.environ.get("SERAPH_ALLOWED_USERS", "")
        if tg_users:
            self._data["telegram"]["allowed_users"] = [int(x.strip()) for x in tg_users.split(",") if x.strip()]

        # Discord
        dc_token = os.environ.get("SERAPH_DISCORD_TOKEN")
        if dc_token:
            self._data["discord"]["enabled"] = True
            self._data["discord"]["token"] = dc_token

    def get(self, key: str, default: Any = None) -> Any:
        """Get a config value using dot notation: config.get('memory.enabled')"""
        keys = key.split(".")
        val = self._data
        for k in keys:
            if isinstance(val, dict):
                val = val.get(k)
            else:
                return default
            if val is None:
                return default
        return val

    def set(self, key: str, value: Any):
        """Set a config value using dot notation."""
        keys = key.split(".")
        d = self._data
        for k in keys[:-1]:
            if k not in d:
                d[k] = {}
            d = d[k]
        d[keys[-1]] = value

    def save(self):
        """Save current config to config.yaml."""
        SERAPH_DIR.mkdir(parents=True, exist_ok=True)
        # Don't save secrets to yaml
        save_data = self._deep_copy(self._data)
        for secret_key in ["telegram.token", "discord.token"]:
            keys = secret_key.split(".")
            d = save_data
            for k in keys[:-1]:
                d = d.get(k, {})
            if keys[-1] in d:
                d[keys[-1]] = "***"

        import os as _os
        tmp_path = str(CONFIG_PATH) + ".tmp"
        with open(tmp_path, "w") as f:
            yaml.dump(save_data, f, default_flow_style=False, sort_keys=False)
        _os.replace(tmp_path, str(CONFIG_PATH))
        logger.info(f"Config saved to {CONFIG_PATH}")

    def to_dict(self) -> Dict:
        """Get full config as dict (secrets masked)."""
        d = self._deep_copy(self._data)
        if d.get("telegram", {}).get("token"):
            d["telegram"]["token"] = "***set***"
        if d.get("discord", {}).get("token"):
            d["discord"]["token"] = "***set***"
        return d

    @staticmethod
    def _deep_copy(d: dict) -> dict:
        import copy
        return copy.deepcopy(d)

    @staticmethod
    def _deep_merge(base: dict, override: dict):
        for k, v in override.items():
            if k in base and isinstance(base[k], dict) and isinstance(v, dict):
                Config._deep_merge(base[k], v)
            else:
                base[k] = v


# Singleton
_config = None

def get_config() -> Config:
    global _config
    if _config is None:
        _config = Config()
    return _config
