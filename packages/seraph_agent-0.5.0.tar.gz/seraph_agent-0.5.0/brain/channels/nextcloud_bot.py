"""
Seraph Nextcloud Talk Channel -- polls Nextcloud Talk API for messages.
"""

import os
import time
import json
import logging
import threading
import requests

logger = logging.getLogger("seraph.nextcloud")
from channels.base import ChannelBase


class SeraphNextcloudBot(ChannelBase):
    CHANNEL_NAME = "nextcloud"
    MAX_MESSAGE_LENGTH = 32000

    def __init__(self, allowed_users=None):
        super().__init__(allowed_users=allowed_users)
        self.server = os.environ.get("SERAPH_NEXTCLOUD_URL", "").rstrip("/")
        self.user = os.environ.get("SERAPH_NEXTCLOUD_USER", "")
        self.password = os.environ.get("SERAPH_NEXTCLOUD_PASS", "")
        self.last_known = {}

    def _headers(self):
        return {"OCS-APIRequest": "true", "Accept": "application/json"}

    def _auth(self):
        return (self.user, self.password)

    def send_message(self, chat_id, text, **kwargs):
        try:
            requests.post(
                f"{self.server}/ocs/v2.php/apps/spreed/api/v1/chat/{chat_id}",
                auth=self._auth(), headers=self._headers(),
                json={"message": text[:32000]}, timeout=10)
        except Exception as e:
            logger.error(f"Nextcloud send: {e}")

    def run(self):
        if not self.server or not self.user:
            logger.error("Set SERAPH_NEXTCLOUD_URL, SERAPH_NEXTCLOUD_USER, SERAPH_NEXTCLOUD_PASS")
            return
        logger.info(f"Nextcloud Talk: polling {self.server}")
        while True:
            try:
                resp = requests.get(
                    f"{self.server}/ocs/v2.php/apps/spreed/api/v4/room",
                    auth=self._auth(), headers=self._headers(), timeout=10)
                if resp.status_code == 200:
                    rooms = resp.json().get("ocs", {}).get("data", [])
                    for room in rooms:
                        token = room.get("token", "")
                        last_msg = room.get("lastMessage", {})
                        msg_id = last_msg.get("id", 0)
                        if token in self.last_known and msg_id > self.last_known[token]:
                            actor = last_msg.get("actorId", "")
                            if actor != self.user:
                                text = last_msg.get("message", "")
                                if text:
                                    self.process_message(token, actor, text)
                        self.last_known[token] = msg_id
            except Exception as e:
                logger.error(f"Nextcloud poll: {e}")
            time.sleep(5)


def start_nextcloud_bot():
    bot = SeraphNextcloudBot()
    threading.Thread(target=bot.run, daemon=True).start()
    return True
