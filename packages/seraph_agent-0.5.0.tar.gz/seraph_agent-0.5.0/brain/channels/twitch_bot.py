"""
Seraph Twitch Channel -- connects via Twitch IRC (TMI).
"""

import os
import socket
import time
import logging
import threading

logger = logging.getLogger("seraph.twitch")
from channels.base import ChannelBase


class SeraphTwitchBot(ChannelBase):
    CHANNEL_NAME = "twitch"
    MAX_MESSAGE_LENGTH = 500

    def __init__(self, allowed_users=None):
        super().__init__(allowed_users=allowed_users)
        self.oauth = os.environ.get("SERAPH_TWITCH_OAUTH", "")
        self.channel = os.environ.get("SERAPH_TWITCH_CHANNEL", "")
        self.nickname = os.environ.get("SERAPH_TWITCH_NICK", "seraph")
        self.sock = None

    def send_message(self, chat_id, text, **kwargs):
        if self.sock:
            for chunk in self.chunk_message(text):
                try:
                    self.sock.send(f"PRIVMSG #{self.channel} :{chunk}\r\n".encode())
                except Exception as e:
                    logger.error(f"Twitch send: {e}")
                time.sleep(1.5)

    def run(self):
        if not self.oauth or not self.channel:
            logger.error("Set SERAPH_TWITCH_OAUTH and SERAPH_TWITCH_CHANNEL")
            return
        while True:
            try:
                self.sock = socket.socket()
                self.sock.connect(("irc.chat.twitch.tv", 6667))
                self.sock.send(f"PASS {self.oauth}\r\n".encode())
                self.sock.send(f"NICK {self.nickname}\r\n".encode())
                self.sock.send(f"JOIN #{self.channel}\r\n".encode())
                logger.info(f"Twitch: joined #{self.channel}")
                buffer = ""
                while True:
                    data = self.sock.recv(4096).decode("utf-8", errors="replace")
                    if not data:
                        break
                    buffer += data
                    while "\r\n" in buffer:
                        line, buffer = buffer.split("\r\n", 1)
                        if line.startswith("PING"):
                            self.sock.send("PONG :tmi.twitch.tv\r\n".encode())
                        elif "PRIVMSG" in line:
                            try:
                                user = line.split("!")[0].lstrip(":")
                                msg = line.split(f"PRIVMSG #{self.channel} :")[1]
                                if f"@{self.nickname}" in msg.lower() or msg.startswith("!"):
                                    clean = msg.replace(f"@{self.nickname}", "").strip()
                                    if clean:
                                        self.process_message(f"#{self.channel}", user, clean)
                            except Exception:
                                pass
            except Exception as e:
                logger.error(f"Twitch: {e}")
                time.sleep(10)


def start_twitch_bot():
    bot = SeraphTwitchBot()
    threading.Thread(target=bot.run, daemon=True).start()
    return True
