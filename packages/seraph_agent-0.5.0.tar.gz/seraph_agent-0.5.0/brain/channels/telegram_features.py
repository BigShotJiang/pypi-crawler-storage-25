"""
Seraph Telegram Advanced Features — forum topics, webhook, draft chunking, status reactions.

These features are imported and used by the main telegram.py channel adapter.
Separated for cleanliness — each feature is a mixin or utility.
"""

import json
import time
import logging
import threading
from typing import Optional, Dict, List, Callable
from pathlib import Path

logger = logging.getLogger("seraph.telegram.features")


# ─── Forum Topic Threading ────────────────────────────────────────
# Telegram supergroups can have "topics" (forum threads).
# Each topic gets its own session — messages within a topic form one conversation.

class ForumTopicManager:
    """Manage Telegram forum topic → session mapping."""

    def __init__(self):
        self.topic_sessions: Dict[str, str] = {}  # "chat:topic" -> session_id

    def get_session_key(self, chat_id: int, message_thread_id: int = None) -> str:
        """Get the session key for a chat/topic combination."""
        if message_thread_id:
            key = f"{chat_id}:{message_thread_id}"
            if key not in self.topic_sessions:
                self.topic_sessions[key] = f"tg_{chat_id}_topic_{message_thread_id}"
            return self.topic_sessions[key]
        return f"chat_{chat_id}"

    def extract_thread_id(self, message: dict) -> Optional[int]:
        """Extract the forum topic thread ID from a Telegram message."""
        return message.get("message_thread_id")

    def build_reply_params(self, chat_id: int, thread_id: int = None,
                           reply_to_msg: int = None) -> dict:
        """Build parameters for replying in the correct topic."""
        params = {"chat_id": chat_id}
        if thread_id:
            params["message_thread_id"] = thread_id
        if reply_to_msg:
            params["reply_parameters"] = {"message_id": reply_to_msg}
        return params


# ─── Draft Stream Chunking ────────────────────────────────────────
# Long streaming responses need to be chunked into multiple Telegram messages
# (max 4096 chars each). This handles the streaming + chunking + editing.

class DraftStreamChunker:
    """
    Stream long responses across multiple Telegram messages.

    Instead of one huge message (which would exceed 4096 char limit),
    this creates and edits messages in real-time as text streams in,
    automatically splitting to a new message when approaching the limit.
    """

    def __init__(self, api_call: Callable, chat_id: int, thread_id: int = None):
        self.api_call = api_call
        self.chat_id = chat_id
        self.thread_id = thread_id
        self.current_msg_id: Optional[int] = None
        self.current_text = ""
        self.message_ids: List[int] = []
        self.last_edit_time = 0.0
        self.edit_interval = 1.0  # seconds between edits
        self.max_chunk_size = 3800  # Leave room for formatting

    def _send_params(self) -> dict:
        params = {"chat_id": self.chat_id}
        if self.thread_id:
            params["message_thread_id"] = self.thread_id
        return params

    def start(self):
        """Start a new streaming session."""
        self.current_msg_id = None
        self.current_text = ""
        self.message_ids = []

    def append(self, text: str):
        """Append text to the stream. Auto-creates/edits/splits messages."""
        self.current_text += text
        now = time.time()

        # Check if we need to split to a new message
        if len(self.current_text) > self.max_chunk_size and self.current_msg_id:
            # Finalize current message
            self._edit_current(self.current_text[:self.max_chunk_size])
            # Start new message with overflow
            self.current_text = self.current_text[self.max_chunk_size:]
            self.current_msg_id = None

        # Throttle edits
        if now - self.last_edit_time < self.edit_interval:
            return

        if len(self.current_text) < 10:
            return  # Don't send tiny fragments

        if self.current_msg_id:
            self._edit_current(self.current_text + " ▍")
        else:
            self._send_new(self.current_text + " ▍")

        self.last_edit_time = now

    def finish(self):
        """Finalize the stream — send/edit the final text without cursor."""
        if not self.current_text:
            return

        if self.current_msg_id:
            self._edit_current(self.current_text)
        else:
            self._send_new(self.current_text)

    def _send_new(self, text: str):
        """Send a new message."""
        params = {**self._send_params(), "text": text}
        result = self.api_call("sendMessage", params)
        if result.get("ok"):
            self.current_msg_id = result["result"]["message_id"]
            self.message_ids.append(self.current_msg_id)

    def _edit_current(self, text: str):
        """Edit the current message."""
        if not self.current_msg_id:
            return
        try:
            self.api_call("editMessageText", {
                "chat_id": self.chat_id,
                "message_id": self.current_msg_id,
                "text": text,
            })
        except Exception:
            pass


# ─── Status Reactions ──────────────────────────────────────────────
# Show thinking/processing status via emoji reactions instead of "typing..."

class StatusReactions:
    """
    Use Telegram reactions to show agent status.

    - 🤔 = thinking
    - ⚡ = executing tools
    - ✅ = done
    - ❌ = error
    """

    THINKING = "🤔"
    EXECUTING = "⚡"
    DONE = "✅"
    ERROR = "❌"

    def __init__(self, api_call: Callable):
        self.api_call = api_call

    def set_reaction(self, chat_id: int, message_id: int, emoji: str):
        """Set a reaction on a message."""
        try:
            self.api_call("setMessageReaction", {
                "chat_id": chat_id,
                "message_id": message_id,
                "reaction": [{"type": "emoji", "emoji": emoji}],
            })
        except Exception:
            pass  # Reactions might not be supported in all chats

    def thinking(self, chat_id: int, message_id: int):
        self.set_reaction(chat_id, message_id, self.THINKING)

    def executing(self, chat_id: int, message_id: int):
        self.set_reaction(chat_id, message_id, self.EXECUTING)

    def done(self, chat_id: int, message_id: int):
        self.set_reaction(chat_id, message_id, self.DONE)

    def error(self, chat_id: int, message_id: int):
        self.set_reaction(chat_id, message_id, self.ERROR)

    def clear(self, chat_id: int, message_id: int):
        """Remove all reactions."""
        try:
            self.api_call("setMessageReaction", {
                "chat_id": chat_id,
                "message_id": message_id,
                "reaction": [],
            })
        except Exception:
            pass


# ─── Webhook Mode ──────────────────────────────────────────────────
# Instead of polling, receive updates via webhook (better for production).

class WebhookReceiver:
    """
    Receive Telegram updates via webhook instead of long polling.

    Requires:
    - A public URL (or ngrok/cloudflare tunnel)
    - The gateway to proxy /webhook/telegram to this handler
    """

    def __init__(self, token: str, webhook_url: str):
        self.token = token
        self.base_url = f"https://api.telegram.org/bot{token}"
        self.webhook_url = webhook_url

    def setup_webhook(self) -> bool:
        """Register the webhook with Telegram."""
        import requests
        try:
            resp = requests.post(f"{self.base_url}/setWebhook", json={
                "url": self.webhook_url,
                "allowed_updates": ["message", "callback_query", "message_reaction"],
                "drop_pending_updates": False,
            }, timeout=10)
            if resp.status_code == 200 and resp.json().get("ok"):
                logger.info(f"Webhook set: {self.webhook_url}")
                return True
            logger.error(f"Webhook setup failed: {resp.text}")
            return False
        except Exception as e:
            logger.error(f"Webhook setup error: {e}")
            return False

    def remove_webhook(self) -> bool:
        """Remove the webhook (switch back to polling)."""
        import requests
        try:
            resp = requests.post(f"{self.base_url}/deleteWebhook", timeout=10)
            return resp.status_code == 200
        except Exception:
            return False

    def parse_update(self, body: bytes) -> Optional[dict]:
        """Parse an incoming webhook update."""
        try:
            return json.loads(body)
        except json.JSONDecodeError:
            return None


# ─── Sticker Vision ────────────────────────────────────────────────
# Download sticker images and analyze them with the vision tool.

def handle_sticker(api_call: Callable, token: str, message: dict) -> Optional[str]:
    """
    Handle a sticker message — download the image and describe it.

    Returns the description text, or None if it can't be processed.
    """
    sticker = message.get("sticker", {})
    if not sticker:
        return None

    # Get the sticker thumbnail (static image)
    thumb = sticker.get("thumbnail") or sticker.get("thumb")
    if not thumb:
        # For animated/video stickers, try the file directly
        file_id = sticker.get("file_id", "")
        emoji = sticker.get("emoji", "")
        return f"[Sticker: {emoji}]" if emoji else "[Sticker]"

    file_id = thumb.get("file_id", "")
    if not file_id:
        return None

    try:
        import requests

        # Download sticker image
        file_info = api_call("getFile", {"file_id": file_id})
        if not file_info.get("ok"):
            return None

        file_path = file_info["result"]["file_path"]
        download_url = f"https://api.telegram.org/file/bot{token}/{file_path}"

        resp = requests.get(download_url, timeout=10)
        if resp.status_code != 200:
            return None

        # Save and analyze
        workspace = Path.home() / ".seraph" / "workspace"
        workspace.mkdir(parents=True, exist_ok=True)
        save_path = workspace / f"sticker_{int(time.time())}.webp"
        save_path.write_bytes(resp.content)

        # Use vision tool to describe
        import asyncio
        from tools.registry import execute_tool
        loop = asyncio.new_event_loop()
        result = loop.run_until_complete(
            execute_tool("describe_image", {"image_path": str(save_path), "question": "What does this sticker show?"})
        )
        loop.close()

        # Clean up
        try:
            save_path.unlink()
        except Exception:
            pass

        emoji = sticker.get("emoji", "")
        description = result.get("description", "")
        return f"[Sticker {emoji}: {description}]" if description else f"[Sticker: {emoji}]"

    except Exception as e:
        logger.debug(f"Sticker vision error: {e}")
        emoji = sticker.get("emoji", "")
        return f"[Sticker: {emoji}]" if emoji else "[Sticker]"
