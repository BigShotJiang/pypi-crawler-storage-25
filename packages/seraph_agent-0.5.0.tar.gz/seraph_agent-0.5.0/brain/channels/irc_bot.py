"""
Seraph IRC Channel -- full agent with real IRC socket connection.
"""

import os
import socket
import time
import logging
import threading

logger = logging.getLogger("seraph.irc")
from channels.base import ChannelBase


class SeraphIRCBot(ChannelBase):
    CHANNEL_NAME = "irc"
    MAX_MESSAGE_LENGTH = 512

    def __init__(self, allowed_users=None):
        super().__init__(allowed_users=allowed_users)
        self.server = os.environ.get("SERAPH_IRC_SERVER", "")
        self.port = int(os.environ.get("SERAPH_IRC_PORT", "6667"))
        self.channel_name = os.environ.get("SERAPH_IRC_CHANNEL", "")
        self.nickname = os.environ.get("SERAPH_IRC_NICK", "seraph")
        self.sock = None

    def send_message(self, chat_id, text, **kwargs):
        if self.sock:
            for chunk in self.chunk_message(text):
                for line in chunk.split("\n"):
                    if line.strip():
                        try:
                            self.sock.send(f"PRIVMSG {chat_id} :{line}\r\n".encode("utf-8"))
                        except Exception as e:
                            logger.error(f"IRC send: {e}")
                        time.sleep(0.5)

    def run(self):
        if not self.server:
            logger.error("Set SERAPH_IRC_SERVER, SERAPH_IRC_CHANNEL, SERAPH_IRC_NICK")
            return
        while True:
            try:
                self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                self.sock.connect((self.server, self.port))
                self.sock.send(f"NICK {self.nickname}\r\n".encode())
                self.sock.send(f"USER {self.nickname} 0 * :Seraph\r\n".encode())
                time.sleep(2)
                if self.channel_name:
                    self.sock.send(f"JOIN {self.channel_name}\r\n".encode())
                logger.info(f"IRC: connected to {self.server}, joined {self.channel_name}")
                buffer = ""
                while True:
                    data = self.sock.recv(4096).decode("utf-8", errors="replace")
                    if not data:
                        break
                    buffer += data
                    while "\r\n" in buffer:
                        line, buffer = buffer.split("\r\n", 1)
                        if line.startswith("PING"):
                            self.sock.send(f"PONG{line[4:]}\r\n".encode())
                        elif "PRIVMSG" in line:
                            try:
                                nick = line.split("!")[0].lstrip(":")
                                _, _, rest = line.partition(" PRIVMSG ")
                                target, _, msg = rest.partition(" :")
                                is_dm = target == self.nickname
                                if is_dm or self.nickname.lower() in msg.lower():
                                    reply = nick if is_dm else target
                                    clean = msg.replace(self.nickname, "").strip()
                                    if clean:
                                        self.process_message(reply, nick, clean)
                            except Exception:
                                pass
            except Exception as e:
                logger.error(f"IRC: {e}")
                time.sleep(10)


def start_irc_bot():
    bot = SeraphIRCBot()
    threading.Thread(target=bot.run, daemon=True).start()
    return True
