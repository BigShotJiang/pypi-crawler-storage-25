"""
Seraph Feishu/Lark Channel -- event subscription webhook with real API.
"""

import os
import json
import time
import logging
import threading
import requests
from http.server import HTTPServer, BaseHTTPRequestHandler

logger = logging.getLogger("seraph.feishu")
from channels.base import ChannelBase


class SeraphFeishuBot(ChannelBase):
    CHANNEL_NAME = "feishu"
    MAX_MESSAGE_LENGTH = 4096

    def __init__(self, allowed_users=None):
        super().__init__(allowed_users=allowed_users)
        self.app_id = os.environ.get("SERAPH_FEISHU_APP_ID", "")
        self.app_secret = os.environ.get("SERAPH_FEISHU_APP_SECRET", "")
        self._token = ""
        self._token_expires = 0

    def _get_token(self):
        if time.time() < self._token_expires and self._token:
            return self._token
        try:
            resp = requests.post(
                "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal",
                json={"app_id": self.app_id, "app_secret": self.app_secret},
                timeout=10)
            if resp.status_code == 200:
                data = resp.json()
                self._token = data.get("tenant_access_token", "")
                self._token_expires = time.time() + data.get("expire", 7200) - 300
        except Exception as e:
            logger.error(f"Feishu token: {e}")
        return self._token

    def send_message(self, chat_id, text, **kwargs):
        token = self._get_token()
        if not token:
            return
        try:
            requests.post(
                "https://open.feishu.cn/open-apis/im/v1/messages",
                params={"receive_id_type": "chat_id"},
                headers={"Authorization": f"Bearer {token}"},
                json={"receive_id": chat_id, "msg_type": "text",
                      "content": json.dumps({"text": text})},
                timeout=10)
        except Exception as e:
            logger.error(f"Feishu send: {e}")

    def handle_webhook(self, body):
        data = json.loads(body) if isinstance(body, (str, bytes)) else body
        if "challenge" in data:
            return {"challenge": data["challenge"]}
        event = data.get("event", {})
        msg = event.get("message", {})
        text = ""
        if msg.get("message_type") == "text":
            try:
                text = json.loads(msg.get("content", "{}")).get("text", "")
            except Exception:
                pass
        sender = event.get("sender", {}).get("sender_id", {}).get("open_id", "")
        chat_id = msg.get("chat_id", "")
        if text and sender and chat_id:
            self.process_message(chat_id, sender, text)
        return {"ok": True}

    def run(self):
        if not self.app_id:
            logger.error("Set SERAPH_FEISHU_APP_ID and SERAPH_FEISHU_APP_SECRET")
            return
        port = int(os.environ.get("SERAPH_FEISHU_PORT", "3979"))
        bot = self

        class Handler(BaseHTTPRequestHandler):
            def do_POST(self):
                length = int(self.headers.get("Content-Length", 0))
                body = self.rfile.read(length)
                result = bot.handle_webhook(body)
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps(result).encode())

            def log_message(self, *args):
                pass

        server = HTTPServer(("0.0.0.0", port), Handler)
        logger.info(f"Feishu webhook on port {port}")
        server.serve_forever()


def start_feishu_bot():
    bot = SeraphFeishuBot()
    threading.Thread(target=bot.run, daemon=True).start()
    return True
