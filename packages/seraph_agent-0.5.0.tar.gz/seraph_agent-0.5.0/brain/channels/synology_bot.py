"""
Seraph Synology Chat Channel -- webhook integration with Synology Chat.
"""

import os
import json
import logging
import threading
import requests
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import parse_qs

logger = logging.getLogger("seraph.synology")
from channels.base import ChannelBase


class SeraphSynologyBot(ChannelBase):
    CHANNEL_NAME = "synology"
    MAX_MESSAGE_LENGTH = 4096

    def __init__(self, allowed_users=None):
        super().__init__(allowed_users=allowed_users)
        self.incoming_url = os.environ.get("SERAPH_SYNOLOGY_INCOMING_URL", "")
        self.outgoing_token = os.environ.get("SERAPH_SYNOLOGY_TOKEN", "")

    def send_message(self, chat_id, text, **kwargs):
        if not self.incoming_url:
            return
        try:
            requests.post(self.incoming_url,
                json={"text": text[:4096]}, timeout=10)
        except Exception as e:
            logger.error(f"Synology send: {e}")

    def handle_webhook(self, body):
        if isinstance(body, bytes):
            body = body.decode("utf-8", errors="replace")
        params = parse_qs(body) if "=" in body else {}
        if not params:
            try:
                params = json.loads(body)
            except Exception:
                params = {}

        token = params.get("token", [""])[0] if isinstance(params.get("token"), list) else params.get("token", "")
        if self.outgoing_token and token != self.outgoing_token:
            return ""

        text = params.get("text", [""])[0] if isinstance(params.get("text"), list) else params.get("text", "")
        user = params.get("user_id", [""])[0] if isinstance(params.get("user_id"), list) else params.get("user_id", "unknown")
        if text:
            self.process_message("synology", str(user), text)
        return ""

    def run(self):
        if not self.incoming_url:
            logger.error("Set SERAPH_SYNOLOGY_INCOMING_URL and SERAPH_SYNOLOGY_TOKEN")
            return
        port = int(os.environ.get("SERAPH_SYNOLOGY_PORT", "3985"))
        bot = self

        class Handler(BaseHTTPRequestHandler):
            def do_POST(self):
                length = int(self.headers.get("Content-Length", 0))
                body = self.rfile.read(length)
                bot.handle_webhook(body)
                self.send_response(200)
                self.end_headers()
            def log_message(self, *args): pass

        server = HTTPServer(("0.0.0.0", port), Handler)
        logger.info(f"Synology Chat webhook on port {port}")
        server.serve_forever()


def start_synology_bot():
    bot = SeraphSynologyBot()
    threading.Thread(target=bot.run, daemon=True).start()
    return True
