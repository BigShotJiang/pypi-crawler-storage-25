"""
Seraph Slack Channel — connects via Slack Socket Mode (no webhook needed).

Runs alongside Telegram + Discord. Same brain, different channel.
"""

import os
import asyncio
import json
import time
import logging
import requests
import threading
import websocket
from pathlib import Path

logger = logging.getLogger("seraph.slack")

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from agent.llm import LLMProvider
from tools.registry import get_all_tools, get_openai_tool_schemas, execute_tool
from memory.store import get_memory

SLACK_API = "https://slack.com/api"


class SeraphSlackBot:
    """Slack bot using Socket Mode."""

    def __init__(self, bot_token: str, app_token: str, allowed_users: list = None):
        self.bot_token = bot_token
        self.app_token = app_token
        self.allowed_users = allowed_users or []
        self.conversations = {}
        self.llm = None
        self.identity = ""
        self.memory = get_memory()
        self.bot_user_id = None

        seraph_dir = Path.home() / ".seraph"
        soul_path = seraph_dir / "SOUL.md"
        if soul_path.exists():
            self.identity = soul_path.read_text()

        try:
            self.llm = LLMProvider(
                provider=os.environ.get("SERAPH_PROVIDER", "openai"),
                model=os.environ.get("SERAPH_MODEL", "gpt-5.4"),
            )
        except Exception as e:
            logger.error(f"Slack LLM init failed: {e}")

    def _api(self, method: str, data: dict = None) -> dict:
        """Call Slack API."""
        try:
            resp = requests.post(
                f"{SLACK_API}/{method}",
                headers={"Authorization": f"Bearer {self.bot_token}", "Content-Type": "application/json"},
                json=data or {},
                timeout=10,
            )
            return resp.json() if resp.status_code == 200 else {}
        except Exception as e:
            logger.error(f"Slack API error: {e}")
            return {}

    def send_message(self, channel: str, text: str):
        """Send a message to a Slack channel."""
        if len(text) > 3000:
            chunks = [text[i:i+2900] for i in range(0, len(text), 2900)]
            for chunk in chunks:
                self._api("chat.postMessage", {"channel": channel, "text": chunk})
                time.sleep(0.5)
        else:
            self._api("chat.postMessage", {"channel": channel, "text": text})

    def process_message(self, channel: str, user: str, text: str):
        """Process a Slack message through the LLM."""
        if self.allowed_users and user not in self.allowed_users:
            return
        if not self.llm:
            return

        if channel not in self.conversations:
            self.conversations[channel] = []

        history = self.conversations[channel]
        history.append({"role": "user", "content": text})

        session_key = f"slack_{channel}"
        self.memory.save_message(session_key, channel, "user", text)

        if len(history) > 20:
            history = history[-20:]
            self.conversations[channel] = history

        active_mem = self.memory.format_active_for_prompt()
        full_identity = self.identity + ("\n\n" + active_mem if active_mem else "")

        try:
            tools = get_openai_tool_schemas()
            for iteration in range(10):
                response = self.llm.chat(messages=history, system=full_identity, tools=tools if tools else None)

                if not response.tool_calls:
                    if response.text:
                        history.append({"role": "assistant", "content": response.text})
                        self.send_message(channel, response.text)
                        self.memory.save_message(session_key, channel, "assistant", response.text)
                    break

                tool_call_msg = {
                    "role": "assistant", "content": response.text or None,
                    "tool_calls": [{"id": tc["id"], "type": "function", "function": {"name": tc["name"], "arguments": json.dumps(tc["arguments"])}} for tc in response.tool_calls]
                }
                history.append(tool_call_msg)

                for tc in response.tool_calls:
                    loop = asyncio.new_event_loop()
                    result = loop.run_until_complete(execute_tool(tc["name"], tc["arguments"]))
                    loop.close()
                    history.append({"role": "tool", "tool_call_id": tc["id"], "content": json.dumps(result, default=str)[:5000]})

        except Exception as e:
            logger.error(f"Slack message error: {e}")
            self.send_message(channel, f"Error: {e}")

    def run(self):
        """Connect via Socket Mode."""
        # Get bot user ID
        auth = self._api("auth.test")
        if auth.get("ok"):
            self.bot_user_id = auth.get("user_id")
            logger.info(f"Slack connected as {auth.get('user', '?')} (ID: {self.bot_user_id})")
        else:
            logger.error("Slack auth failed")
            return

        # Connect to Socket Mode
        try:
            resp = requests.post(
                f"{SLACK_API}/apps.connections.open",
                headers={"Authorization": f"Bearer {self.app_token}"},
                timeout=10,
            )
            data = resp.json()
            if not data.get("ok"):
                logger.error(f"Socket Mode connection failed: {data}")
                return

            ws_url = data["url"]
            logger.info("Slack Socket Mode connected")

            def on_message(ws, message):
                try:
                    data = json.loads(message)
                except (json.JSONDecodeError, IOError):
                    data = {}
                if data.get("type") == "events_api":
                    # Acknowledge
                    ws.send(json.dumps({"envelope_id": data.get("envelope_id")}))
                    event = data.get("payload", {}).get("event", {})
                    if event.get("type") == "message" and not event.get("bot_id"):
                        channel = event.get("channel", "")
                        user = event.get("user", "")
                        text = event.get("text", "")
                        if text and self.bot_user_id and f"<@{self.bot_user_id}>" in text:
                            text = text.replace(f"<@{self.bot_user_id}>", "").strip()
                            threading.Thread(target=self.process_message, args=(channel, user, text), daemon=True).start()

            ws = websocket.WebSocketApp(ws_url, on_message=on_message)
            ws.run_forever()

        except Exception as e:
            logger.error(f"Slack Socket Mode error: {e}")


def start_slack_bot():
    """Start Slack bot in background thread."""
    bot_token = os.environ.get("SERAPH_SLACK_BOT_TOKEN", "")
    app_token = os.environ.get("SERAPH_SLACK_APP_TOKEN", "")
    if not bot_token or not app_token:
        return None

    bot = SeraphSlackBot(bot_token=bot_token, app_token=app_token)
    thread = threading.Thread(target=bot.run, daemon=True)
    thread.start()
    logger.info("Slack bot started")
    return bot
