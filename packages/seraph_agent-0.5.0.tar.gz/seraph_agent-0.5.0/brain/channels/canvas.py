"""
Seraph Canvas — live visual workspace the agent can draw on.

Serves a web-based canvas at /canvas that the agent can:
- Push HTML/CSS/JS components to
- Render charts, diagrams, tables
- Display code with syntax highlighting
- Show images and media
- Run JavaScript in the browser
- Reset/clear the canvas

The agent controls the canvas via the canvas tool.
Users open it in any browser.
"""

import os
import json
import time
import logging
import threading
from pathlib import Path
from typing import Dict, List
from tools.registry import register_tool

logger = logging.getLogger("seraph.canvas")

CANVAS_PORT = int(os.environ.get("SERAPH_CANVAS_PORT", "18803"))

# Canvas state — what's currently displayed
_canvas_state = {
    "elements": [],  # List of {id, type, content, style}
    "title": "Seraph Canvas",
    "theme": "dark",
    "updated": 0,
}

_canvas_lock = threading.Lock()


CANVAS_HTML = """<!DOCTYPE html>
<html><head>
<title>Seraph Canvas</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: -apple-system, system-ui, sans-serif; background: #0a0a0a; color: #e0e0e0; min-height: 100vh; }
#header { padding: 12px 20px; background: #111; border-bottom: 1px solid #222; display: flex; justify-content: space-between; align-items: center; }
#header h1 { font-size: 18px; color: #6366f1; }
#header .status { font-size: 12px; color: #888; }
#canvas { padding: 20px; display: flex; flex-direction: column; gap: 16px; }
.element { background: #1e1e2e; border: 1px solid #333; border-radius: 12px; padding: 16px; animation: fadeIn 0.3s ease; }
.element.html { padding: 0; overflow: hidden; border-radius: 12px; }
.element.html iframe { width: 100%; border: none; min-height: 200px; background: white; }
.element.code { font-family: 'Fira Code', monospace; font-size: 13px; background: #111; white-space: pre-wrap; overflow-x: auto; }
.element.text { line-height: 1.6; }
.element.chart { min-height: 300px; }
.element.image img { max-width: 100%; border-radius: 8px; }
.element h2 { color: #6366f1; margin-bottom: 8px; font-size: 16px; }
.element .meta { font-size: 11px; color: #666; margin-top: 8px; }
table { width: 100%; border-collapse: collapse; }
th, td { padding: 8px 12px; text-align: left; border-bottom: 1px solid #333; }
th { color: #6366f1; font-weight: 600; }
@keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
</style></head><body>
<div id="header">
    <h1 id="title">Seraph Canvas</h1>
    <div class="status" id="status">Connecting...</div>
</div>
<div id="canvas"></div>
<script>
let lastUpdate = 0;
async function poll() {
    try {
        const resp = await fetch('/canvas/state?since=' + lastUpdate);
        const data = await resp.json();
        if (data.updated > lastUpdate) {
            lastUpdate = data.updated;
            document.getElementById('title').textContent = data.title || 'Seraph Canvas';
            renderElements(data.elements || []);
        }
        document.getElementById('status').textContent = 'Live';
    } catch(e) {
        document.getElementById('status').textContent = 'Reconnecting...';
    }
    setTimeout(poll, 1000);
}

function renderElements(elements) {
    const canvas = document.getElementById('canvas');
    canvas.innerHTML = '';
    for (const el of elements) {
        const div = document.createElement('div');
        div.className = 'element ' + (el.type || 'text');
        div.id = 'el-' + el.id;

        if (el.type === 'html') {
            const iframe = document.createElement('iframe');
            iframe.srcdoc = el.content;
            iframe.style.minHeight = (el.height || 300) + 'px';
            div.appendChild(iframe);
        } else if (el.type === 'code') {
            if (el.title) { const h = document.createElement('h2'); h.textContent = el.title; div.appendChild(h); }
            const pre = document.createElement('pre');
            pre.textContent = el.content;
            div.appendChild(pre);
        } else if (el.type === 'image') {
            const img = document.createElement('img');
            img.src = el.content;
            img.alt = el.title || '';
            div.appendChild(img);
        } else if (el.type === 'table') {
            if (el.title) { const h = document.createElement('h2'); h.textContent = el.title; div.appendChild(h); }
            div.innerHTML += el.content;
        } else {
            if (el.title) { const h = document.createElement('h2'); h.textContent = el.title; div.appendChild(h); }
            const p = document.createElement('div');
            p.innerHTML = el.content;
            div.appendChild(p);
        }
        canvas.appendChild(div);
    }
}
poll();
</script></body></html>"""


def canvas_push(element_type: str = "text", content: str = "", title: str = "",
                element_id: str = "", style: dict = None, height: int = 300) -> dict:
    """Push an element to the canvas."""
    with _canvas_lock:
        eid = element_id or f"el_{int(time.time())}_{len(_canvas_state['elements'])}"
        element = {
            "id": eid,
            "type": element_type,
            "content": content,
            "title": title,
            "style": style or {},
            "height": height,
            "added": time.time(),
        }

        # Replace existing element with same ID
        _canvas_state["elements"] = [e for e in _canvas_state["elements"] if e["id"] != eid]
        _canvas_state["elements"].append(element)
        _canvas_state["updated"] = time.time()

    return {"status": "pushed", "id": eid, "elements": len(_canvas_state["elements"])}


def canvas_clear() -> dict:
    """Clear all canvas elements."""
    with _canvas_lock:
        _canvas_state["elements"] = []
        _canvas_state["updated"] = time.time()
    return {"status": "cleared"}


def canvas_set_title(title: str) -> dict:
    """Set canvas title."""
    with _canvas_lock:
        _canvas_state["title"] = title
        _canvas_state["updated"] = time.time()
    return {"status": "title_set", "title": title}


def canvas_remove(element_id: str) -> dict:
    """Remove a specific element."""
    with _canvas_lock:
        before = len(_canvas_state["elements"])
        _canvas_state["elements"] = [e for e in _canvas_state["elements"] if e["id"] != element_id]
        _canvas_state["updated"] = time.time()
        removed = before - len(_canvas_state["elements"])
    return {"status": "removed" if removed else "not_found", "id": element_id}


def canvas_eval(js_code: str) -> dict:
    """Push JavaScript to execute in the canvas browser."""
    return canvas_push("html", f"<script>{js_code}</script>", element_id="eval_script")


def canvas_tool(action: str, element_type: str = "text", content: str = "",
                title: str = "", element_id: str = "", height: int = 300,
                js_code: str = "") -> dict:
    if action == "push":
        return canvas_push(element_type, content, title, element_id, height=height)
    elif action == "clear":
        return canvas_clear()
    elif action == "title":
        return canvas_set_title(title or content)
    elif action == "remove":
        return canvas_remove(element_id)
    elif action == "eval":
        return canvas_eval(js_code or content)
    elif action == "state":
        return {"elements": len(_canvas_state["elements"]), "title": _canvas_state["title"]}
    return {"error": f"Unknown action: {action}"}


def start_canvas_server(port: int = CANVAS_PORT) -> bool:
    """Start the canvas HTTP server."""
    try:
        from flask import Flask, request, jsonify, Response

        app = Flask(__name__)

        @app.route("/canvas")
        def canvas_page():
            return Response(CANVAS_HTML, content_type="text/html")

        @app.route("/canvas/state")
        def canvas_state():
            since = float(request.args.get("since", 0))
            return jsonify(_canvas_state)

        thread = threading.Thread(
            target=lambda: app.run(host="0.0.0.0", port=port, debug=False, use_reloader=False),
            daemon=True,
        )
        thread.start()
        logger.info(f"Canvas server started on port {port}")
        return True
    except Exception as e:
        logger.error(f"Canvas server error: {e}")
        return False


register_tool(
    name="canvas",
    description="Control a live visual workspace in the browser. Push HTML, code, tables, charts, images. Actions: push, clear, title, remove, eval (run JS), state.",
    parameters={
        "type": "object",
        "properties": {
            "action": {"type": "string", "enum": ["push", "clear", "title", "remove", "eval", "state"]},
            "element_type": {"type": "string", "enum": ["text", "html", "code", "image", "table"], "description": "Type of element to push"},
            "content": {"type": "string", "description": "Element content (HTML, code, text, image URL)"},
            "title": {"type": "string", "description": "Element or canvas title"},
            "element_id": {"type": "string", "description": "Element ID (for update/remove)"},
            "height": {"type": "integer", "description": "Height in pixels for HTML elements"},
            "js_code": {"type": "string", "description": "JavaScript to execute (for eval action)"},
        },
        "required": ["action"],
    },
    handler=canvas_tool,
)
