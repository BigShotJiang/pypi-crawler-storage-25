"""
Seraph QQ Bot Channel -- connects via QQ Bot open platform webhook.
"""

import os
import json
import logging
import threading
import requests
from http.server import HTTPServer, BaseHTTPRequestHandler

logger = logging.getLogger("seraph.qqbot")
from channels.base import ChannelBase


class SeraphQQBot(ChannelBase):
    CHANNEL_NAME = "qqbot"
    MAX_MESSAGE_LENGTH = 4096

    def __init__(self, allowed_users=None):
        super().__init__(allowed_users=allowed_users)
        self.app_id = os.environ.get("SERAPH_QQ_APP_ID", "")
        self.app_secret = os.environ.get("SERAPH_QQ_APP_SECRET", "")
        self._token = ""
        self._token_expires = 0

    def _get_token(self):
        if time.time() < self._token_expires and self._token:
            return self._token
        try:
            import time
            resp = requests.post("https://bots.qq.com/app/getAppAccessToken",
                json={"appId": self.app_id, "clientSecret": self.app_secret},
                timeout=10)
            if resp.status_code == 200:
                data = resp.json()
                self._token = data.get("access_token", "")
                self._token_expires = time.time() + int(data.get("expires_in", 7200)) - 300
        except Exception as e:
            logger.error(f"QQ token: {e}")
        return self._token

    def send_message(self, chat_id, text, **kwargs):
        token = self._get_token()
        if not token:
            return
        try:
            msg_id = kwargs.get("msg_id", "")
            body = {"content": text[:4096], "msg_type": 0}
            if msg_id:
                body["msg_id"] = msg_id
            requests.post(
                f"https://api.sgroup.qq.com/channels/{chat_id}/messages",
                headers={"Authorization": f"QQBot {token}"},
                json=body, timeout=10)
        except Exception as e:
            logger.error(f"QQ send: {e}")

    def handle_webhook(self, body):
        data = json.loads(body) if isinstance(body, (str, bytes)) else body
        op = data.get("op", 0)
        if op == 13:  # Verification
            return {"op": 13, "d": {"plain_token": data.get("d", {}).get("plain_token", ""),
                                     "event_ts": data.get("d", {}).get("event_ts", "")}}
        t = data.get("t", "")
        d = data.get("d", {})
        if t in ("AT_MESSAGE_CREATE", "MESSAGE_CREATE", "C2C_MESSAGE_CREATE"):
            text = d.get("content", "").strip()
            author = d.get("author", {}).get("id", "")
            channel_id = d.get("channel_id", d.get("group_openid", ""))
            if text and author:
                self.process_message(channel_id, author, text)
        return {"ok": True}

    def run(self):
        if not self.app_id:
            logger.error("Set SERAPH_QQ_APP_ID and SERAPH_QQ_APP_SECRET")
            return
        port = int(os.environ.get("SERAPH_QQ_PORT", "3984"))
        bot = self

        class Handler(BaseHTTPRequestHandler):
            def do_POST(self):
                length = int(self.headers.get("Content-Length", 0))
                body = self.rfile.read(length)
                result = bot.handle_webhook(body)
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps(result).encode())
            def log_message(self, *args): pass

        server = HTTPServer(("0.0.0.0", port), Handler)
        logger.info(f"QQ Bot webhook on port {port}")
        server.serve_forever()


def start_qq_bot():
    import time
    bot = SeraphQQBot()
    threading.Thread(target=bot.run, daemon=True).start()
    return True
