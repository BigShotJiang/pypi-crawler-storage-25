"""
Seraph Nostr Channel -- connects to relays via WebSocket for DMs.
"""

import os
import json
import time
import logging
import threading

logger = logging.getLogger("seraph.nostr")
from channels.base import ChannelBase


class SeraphNostrBot(ChannelBase):
    CHANNEL_NAME = "nostr"
    MAX_MESSAGE_LENGTH = 65536

    def __init__(self, allowed_users=None):
        super().__init__(allowed_users=allowed_users)
        self.relays = os.environ.get("SERAPH_NOSTR_RELAYS", "wss://relay.damus.io").split(",")
        self.private_key = os.environ.get("SERAPH_NOSTR_PRIVATE_KEY", "")

    def send_message(self, chat_id, text, **kwargs):
        logger.info(f"[Nostr] -> {chat_id}: {text[:80]}")

    def run(self):
        if not self.private_key:
            logger.error("Set SERAPH_NOSTR_PRIVATE_KEY and SERAPH_NOSTR_RELAYS")
            return
        try:
            import websocket
        except ImportError:
            logger.error("pip install websocket-client for Nostr")
            return
        for relay in self.relays:
            threading.Thread(target=self._connect, args=(relay.strip(),), daemon=True).start()

    def _connect(self, relay_url):
        import websocket as ws
        logger.info(f"Nostr: connecting to {relay_url}")

        def on_message(wsapp, message):
            try:
                data = json.loads(message)
                if data[0] == "EVENT":
                    event = data[2]
                    if event.get("kind") == 4:
                        content = event.get("content", "")
                        pubkey = event.get("pubkey", "")
                        if content:
                            self.process_message(pubkey, pubkey, content)
            except Exception:
                pass

        def on_open(wsapp):
            wsapp.send(json.dumps(["REQ", "seraph", {"kinds": [4], "limit": 10}]))

        try:
            wsapp = ws.WebSocketApp(relay_url, on_message=on_message, on_open=on_open)
            wsapp.run_forever()
        except Exception as e:
            logger.error(f"Nostr relay {relay_url}: {e}")


def start_nostr_bot():
    bot = SeraphNostrBot()
    threading.Thread(target=bot.run, daemon=True).start()
    return True
