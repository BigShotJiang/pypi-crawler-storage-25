"""
Seraph PWA — Progressive Web App companion.

Serves a mobile-friendly chat app that can be installed to home screen
on iOS, Android, Windows, macOS. Works offline with service worker.
No App Store needed.

Features:
- Full chat interface
- Push notifications (via Notification API)
- Offline support (service worker cache)
- Install to home screen prompt
- Dark theme matching desktop
"""

import os
import json
import time
import logging
import threading
from pathlib import Path
from typing import Optional

logger = logging.getLogger("seraph.pwa")

PWA_PORT = int(os.environ.get("SERAPH_PWA_PORT", "18804"))

MANIFEST = {
    "name": "Seraph",
    "short_name": "Seraph",
    "description": "AI agent that audits itself",
    "start_url": "/",
    "display": "standalone",
    "background_color": "#0a0a0a",
    "theme_color": "#6366f1",
    "orientation": "portrait",
    "icons": [
        {"src": "/icon-192.png", "sizes": "192x192", "type": "image/png"},
        {"src": "/icon-512.png", "sizes": "512x512", "type": "image/png"},
    ],
}

SERVICE_WORKER = """
const CACHE = 'seraph-v1';
const ASSETS = ['/', '/manifest.json'];

self.addEventListener('install', e => {
    e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)));
    self.skipWaiting();
});

self.addEventListener('activate', e => {
    e.waitUntil(caches.keys().then(keys =>
        Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))
    ));
});

self.addEventListener('fetch', e => {
    if (e.request.method !== 'GET') return;
    e.respondWith(
        fetch(e.request).catch(() => caches.match(e.request))
    );
});

self.addEventListener('push', e => {
    const data = e.data ? e.data.json() : { title: 'Seraph', body: 'New message' };
    e.waitUntil(self.registration.showNotification(data.title, {
        body: data.body,
        icon: '/icon-192.png',
        badge: '/icon-192.png',
        vibrate: [100, 50, 100],
    }));
});
"""

PWA_HTML = """<!DOCTYPE html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#6366f1">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<link rel="manifest" href="/manifest.json">
<title>Seraph</title>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
:root { --safe-bottom: env(safe-area-inset-bottom, 0px); }
body { font-family: -apple-system, system-ui, sans-serif; background: #0a0a0a; color: #e0e0e0;
       height: 100vh; height: 100dvh; display: flex; flex-direction: column; overflow: hidden;
       -webkit-user-select: none; user-select: none; }
#header { padding: 16px 20px; padding-top: max(16px, env(safe-area-inset-top));
          background: #111; border-bottom: 1px solid #222; display: flex;
          justify-content: space-between; align-items: center; flex-shrink: 0; }
#header h1 { font-size: 20px; color: #6366f1; }
#header .model { font-size: 12px; color: #888; }
#msgs { flex: 1; overflow-y: auto; padding: 16px; -webkit-overflow-scrolling: touch; }
.msg { margin-bottom: 10px; max-width: 85%; padding: 10px 14px; border-radius: 16px;
       line-height: 1.5; word-break: break-word; white-space: pre-wrap; font-size: 15px; }
.msg.user { background: #6366f1; color: white; margin-left: auto;
            border-bottom-right-radius: 4px; }
.msg.bot { background: #1e1e2e; border: 1px solid #333;
           border-bottom-left-radius: 4px; }
.msg.sys { text-align: center; color: #666; font-size: 13px; margin: 0 auto; }
#input-row { padding: 12px 16px; padding-bottom: max(12px, var(--safe-bottom));
             background: #111; border-top: 1px solid #222; display: flex; gap: 8px; flex-shrink: 0; }
#input { flex: 1; background: #1e1e2e; border: 1px solid #333; color: #e0e0e0;
         padding: 12px 16px; border-radius: 24px; font-size: 16px; outline: none;
         -webkit-appearance: none; }
#input:focus { border-color: #6366f1; }
#send { background: #6366f1; color: white; border: none; width: 44px; height: 44px;
        border-radius: 50%; font-size: 20px; cursor: pointer; flex-shrink: 0; }
.typing { color: #888; font-style: italic; padding: 8px 14px; }
#install-banner { display: none; padding: 12px 20px; background: #1a1a2e;
                  border-bottom: 1px solid #333; text-align: center; cursor: pointer; }
#install-banner:hover { background: #222; }
</style></head><body>

<div id="install-banner" onclick="installPWA()">Install Seraph to your home screen</div>

<div id="header">
    <h1>Seraph</h1>
    <div class="model" id="model">AI Agent</div>
</div>
<div id="msgs">
    <div class="msg sys">Send a message to start</div>
</div>
<div id="input-row">
    <input id="input" placeholder="Message..." autocomplete="off" enterkeyhint="send">
    <button id="send">&#x27A4;</button>
</div>

<script>
const msgs = document.getElementById('msgs');
const input = document.getElementById('input');
const API = window.location.origin;

function addMsg(text, cls) {
    const d = document.createElement('div');
    d.className = 'msg ' + cls;
    d.textContent = text;
    msgs.appendChild(d);
    msgs.scrollTop = msgs.scrollHeight;
}

async function send() {
    const text = input.value.trim();
    if (!text) return;
    addMsg(text, 'user');
    input.value = '';
    const typing = document.createElement('div');
    typing.className = 'typing';
    typing.textContent = 'Thinking...';
    msgs.appendChild(typing);
    msgs.scrollTop = msgs.scrollHeight;

    try {
        const resp = await fetch(API + '/api/v1/chat', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({message: text}),
        });
        const data = await resp.json();
        typing.remove();
        addMsg(data.response || data.error || 'No response', 'bot');
    } catch(e) {
        typing.remove();
        addMsg('Connection error', 'sys');
    }
}

document.getElementById('send').onclick = send;
input.onkeydown = e => { if (e.key === 'Enter') send(); };

// PWA install
let deferredPrompt;
window.addEventListener('beforeinstallprompt', e => {
    e.preventDefault();
    deferredPrompt = e;
    document.getElementById('install-banner').style.display = 'block';
});
function installPWA() {
    if (deferredPrompt) {
        deferredPrompt.prompt();
        deferredPrompt.userChoice.then(() => {
            document.getElementById('install-banner').style.display = 'none';
            deferredPrompt = null;
        });
    }
}

// Register service worker
if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/sw.js');
}

// Request notification permission
if ('Notification' in window && Notification.permission === 'default') {
    Notification.requestPermission();
}
</script></body></html>"""

# SVG icon placeholder (purple circle with S)
ICON_SVG = """<svg xmlns="http://www.w3.org/2000/svg" width="512" height="512" viewBox="0 0 512 512">
<rect width="512" height="512" rx="128" fill="#6366f1"/>
<text x="256" y="340" font-family="Arial" font-size="280" font-weight="bold" fill="white" text-anchor="middle">S</text>
</svg>"""


def start_pwa_server(port: int = PWA_PORT) -> bool:
    """Start the PWA server."""
    try:
        from flask import Flask, request, jsonify, Response

        app = Flask(__name__)

        @app.route("/")
        def index():
            return Response(PWA_HTML, content_type="text/html")

        @app.route("/manifest.json")
        def manifest():
            return jsonify(MANIFEST)

        @app.route("/sw.js")
        def service_worker():
            return Response(SERVICE_WORKER, content_type="application/javascript")

        @app.route("/icon-192.png")
        @app.route("/icon-512.png")
        def icon():
            # Serve SVG as fallback (real app would have PNG)
            return Response(ICON_SVG, content_type="image/svg+xml")

        @app.route("/api/v1/chat", methods=["POST"])
        def chat():
            data = request.json or {}
            message = data.get("message", "")
            if not message:
                return jsonify({"error": "No message"})
            # Route to brain API
            import requests as req
            try:
                brain_port = int(os.environ.get("SERAPH_BRAIN_PORT", "18801"))
                resp = req.post(
                    f"http://localhost:{brain_port}/api/v1/chat",
                    json={"message": message},
                    timeout=60,
                )
                return jsonify(resp.json())
            except Exception as e:
                return jsonify({"error": str(e)})

        thread = threading.Thread(
            target=lambda: app.run(host="0.0.0.0", port=port, debug=False, use_reloader=False),
            daemon=True,
        )
        thread.start()
        logger.info(f"PWA server started on port {port}")
        return True

    except Exception as e:
        logger.error(f"PWA server error: {e}")
        return False


def start_pwa() -> bool:
    if not os.environ.get("SERAPH_PWA_ENABLED", ""):
        logger.info("SERAPH_PWA_ENABLED not set - PWA disabled")
        return False
    return start_pwa_server()
