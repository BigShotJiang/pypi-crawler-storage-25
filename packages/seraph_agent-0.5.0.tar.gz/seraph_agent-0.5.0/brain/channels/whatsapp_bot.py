"""
Seraph WhatsApp Channel — connects via Meta WhatsApp Cloud API.

Requires: WhatsApp Business API token + phone number ID + webhook verification.
"""

import os
import json
import time
import logging
import requests
import threading
from pathlib import Path
from flask import Flask, request as flask_request, jsonify

logger = logging.getLogger("seraph.whatsapp")

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from agent.llm import LLMProvider
from tools.registry import get_all_tools, get_openai_tool_schemas, execute_tool
from memory.store import get_memory

WA_API = "https://graph.facebook.com/v21.0"


class SeraphWhatsAppBot:
    """WhatsApp bot via Cloud API."""

    def __init__(self, token: str, phone_id: str, verify_token: str, allowed_numbers: list = None):
        self.token = token
        self.phone_id = phone_id
        self.verify_token = verify_token
        self.allowed_numbers = allowed_numbers or []
        self.conversations = {}
        self.llm = None
        self.identity = ""
        self.memory = get_memory()

        seraph_dir = Path.home() / ".seraph"
        soul_path = seraph_dir / "SOUL.md"
        if soul_path.exists():
            self.identity = soul_path.read_text()

        try:
            self.llm = LLMProvider(
                provider=os.environ.get("SERAPH_PROVIDER", "openai"),
                model=os.environ.get("SERAPH_MODEL", "gpt-5.4"),
            )
        except Exception as e:
            logger.error(f"WhatsApp LLM init failed: {e}")

    def send_message(self, to: str, text: str):
        """Send a WhatsApp message."""
        if len(text) > 4096:
            text = text[:4096]

        try:
            resp = requests.post(
                f"{WA_API}/{self.phone_id}/messages",
                headers={
                    "Authorization": f"Bearer {self.token}",
                    "Content-Type": "application/json",
                },
                json={
                    "messaging_product": "whatsapp",
                    "to": to,
                    "type": "text",
                    "text": {"body": text},
                },
                timeout=10,
            )
            if resp.status_code != 200:
                logger.error(f"WhatsApp send error: {resp.text[:200]}")
        except Exception as e:
            logger.error(f"WhatsApp send failed: {e}")

    def process_message(self, from_number: str, text: str):
        """Process a WhatsApp message."""
        if self.allowed_numbers and from_number not in self.allowed_numbers:
            return
        if not self.llm:
            return

        if from_number not in self.conversations:
            self.conversations[from_number] = []

        history = self.conversations[from_number]
        history.append({"role": "user", "content": text})

        session_key = f"whatsapp_{from_number}"
        self.memory.save_message(session_key, from_number, "user", text)

        if len(history) > 20:
            history = history[-20:]
            self.conversations[from_number] = history

        active_mem = self.memory.format_active_for_prompt()
        full_identity = self.identity + ("\n\n" + active_mem if active_mem else "")

        try:
            response = self.llm.chat(messages=history, system=full_identity)
            if response.text:
                history.append({"role": "assistant", "content": response.text})
                self.send_message(from_number, response.text)
                self.memory.save_message(session_key, from_number, "assistant", response.text)
        except Exception as e:
            logger.error(f"WhatsApp processing error: {e}")
            self.send_message(from_number, f"Error: {e}")

    def create_webhook_app(self) -> Flask:
        """Create Flask app for WhatsApp webhook."""
        app = Flask(__name__)
        bot = self

        @app.route("/webhook/whatsapp", methods=["GET"])
        def verify():
            mode = flask_request.args.get("hub.mode")
            token = flask_request.args.get("hub.verify_token")
            challenge = flask_request.args.get("hub.challenge")
            if mode == "subscribe" and token == bot.verify_token:
                return challenge, 200
            return "Forbidden", 403

        @app.route("/webhook/whatsapp", methods=["POST"])
        def receive():
            data = flask_request.json
            if not data:
                return "OK", 200

            for entry in data.get("entry", []):
                for change in entry.get("changes", []):
                    value = change.get("value", {})
                    for msg in value.get("messages", []):
                        if msg.get("type") == "text":
                            from_number = msg["from"]
                            text = msg["text"]["body"]
                            threading.Thread(target=bot.process_message, args=(from_number, text), daemon=True).start()

            return "OK", 200

        return app


def start_whatsapp_bot(port: int = 18803):
    """Start WhatsApp webhook server."""
    token = os.environ.get("SERAPH_WHATSAPP_TOKEN", "")
    phone_id = os.environ.get("SERAPH_WHATSAPP_PHONE_ID", "")
    verify = os.environ.get("SERAPH_WHATSAPP_VERIFY_TOKEN", "seraph_verify")

    if not token or not phone_id:
        return None

    bot = SeraphWhatsAppBot(token=token, phone_id=phone_id, verify_token=verify)
    app = bot.create_webhook_app()

    thread = threading.Thread(target=lambda: app.run(host="0.0.0.0", port=port, debug=False), daemon=True)
    thread.start()
    logger.info(f"WhatsApp webhook started on port {port}")
    return bot
