"""
Seraph MS Teams Channel -- Bot Framework webhook handler.
"""

import os
import json
import logging
import threading
import requests
from http.server import HTTPServer, BaseHTTPRequestHandler

logger = logging.getLogger("seraph.msteams")
from channels.base import ChannelBase


class SeraphTeamsBot(ChannelBase):
    CHANNEL_NAME = "msteams"
    MAX_MESSAGE_LENGTH = 28000

    def __init__(self, allowed_users=None):
        super().__init__(allowed_users=allowed_users)
        self.app_id = os.environ.get("SERAPH_TEAMS_APP_ID", "")
        self.app_secret = os.environ.get("SERAPH_TEAMS_APP_SECRET", "")
        self._reply_urls = {}

    def send_message(self, chat_id, text, **kwargs):
        url = self._reply_urls.get(chat_id)
        if url:
            try:
                requests.post(url, json={"type": "message", "text": text},
                    headers={"Content-Type": "application/json"}, timeout=10)
            except Exception as e:
                logger.error(f"Teams send: {e}")

    def handle_webhook(self, body):
        activity = json.loads(body) if isinstance(body, (str, bytes)) else body
        if activity.get("type") == "message":
            text = activity.get("text", "")
            user_id = activity.get("from", {}).get("id", "")
            conv_id = activity.get("conversation", {}).get("id", "")
            svc = activity.get("serviceUrl", "")
            self._reply_urls[conv_id] = f"{svc}/v3/conversations/{conv_id}/activities"
            if text:
                self.process_message(conv_id, user_id, text)
        return {"status": "ok"}

    def run(self):
        if not self.app_id:
            logger.error("Set SERAPH_TEAMS_APP_ID and SERAPH_TEAMS_APP_SECRET")
            return
        port = int(os.environ.get("SERAPH_TEAMS_PORT", "3978"))
        bot = self

        class Handler(BaseHTTPRequestHandler):
            def do_POST(self):
                length = int(self.headers.get("Content-Length", 0))
                body = self.rfile.read(length)
                result = bot.handle_webhook(body)
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps(result).encode())

            def log_message(self, *args):
                pass

        server = HTTPServer(("0.0.0.0", port), Handler)
        logger.info(f"Teams webhook on port {port}")
        server.serve_forever()


def start_msteams_bot():
    bot = SeraphTeamsBot()
    threading.Thread(target=bot.run, daemon=True).start()
    return True
