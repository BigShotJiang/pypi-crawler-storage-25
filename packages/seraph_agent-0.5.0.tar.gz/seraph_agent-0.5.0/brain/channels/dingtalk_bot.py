"""
Seraph DingTalk Channel -- webhook handler for DingTalk bot.
"""

import os
import json
import logging
import threading
import requests
from http.server import HTTPServer, BaseHTTPRequestHandler

logger = logging.getLogger("seraph.dingtalk")
from channels.base import ChannelBase


class SeraphDingTalkBot(ChannelBase):
    CHANNEL_NAME = "dingtalk"
    MAX_MESSAGE_LENGTH = 4096

    def __init__(self, allowed_users=None):
        super().__init__(allowed_users=allowed_users)
        self.webhook = os.environ.get("SERAPH_DINGTALK_WEBHOOK", "")

    def send_message(self, chat_id, text, **kwargs):
        if self.webhook:
            try:
                requests.post(self.webhook,
                    json={"msgtype": "text", "text": {"content": text[:4096]}},
                    timeout=10)
            except Exception as e:
                logger.error(f"DingTalk send: {e}")

    def handle_webhook(self, body):
        data = json.loads(body) if isinstance(body, (str, bytes)) else body
        text = data.get("text", {}).get("content", "").strip()
        user_id = data.get("senderStaffId", data.get("senderId", ""))
        conv_id = data.get("conversationId", "default")
        if text and user_id:
            self.process_message(conv_id, user_id, text)
        return {"msgtype": "empty"}

    def run(self):
        if not self.webhook:
            logger.error("Set SERAPH_DINGTALK_WEBHOOK")
            return
        port = int(os.environ.get("SERAPH_DINGTALK_PORT", "3982"))
        bot = self

        class Handler(BaseHTTPRequestHandler):
            def do_POST(self):
                length = int(self.headers.get("Content-Length", 0))
                body = self.rfile.read(length)
                result = bot.handle_webhook(body)
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps(result).encode())

            def log_message(self, *args):
                pass

        server = HTTPServer(("0.0.0.0", port), Handler)
        logger.info(f"DingTalk webhook on port {port}")
        server.serve_forever()


def start_dingtalk_bot():
    bot = SeraphDingTalkBot()
    threading.Thread(target=bot.run, daemon=True).start()
    return True
