"""
Seraph SMS Channel -- Twilio webhook for inbound, API for outbound.
"""

import os
import json
import logging
import threading
import requests
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import parse_qs

logger = logging.getLogger("seraph.sms")
from channels.base import ChannelBase


class SeraphSMSBot(ChannelBase):
    CHANNEL_NAME = "sms"
    MAX_MESSAGE_LENGTH = 1600

    def __init__(self, allowed_users=None):
        super().__init__(allowed_users=allowed_users)
        self.twilio_sid = os.environ.get("SERAPH_TWILIO_SID", "")
        self.twilio_token = os.environ.get("SERAPH_TWILIO_TOKEN", "")
        self.twilio_from = os.environ.get("SERAPH_TWILIO_FROM", "")

    def send_message(self, chat_id, text, **kwargs):
        try:
            requests.post(
                f"https://api.twilio.com/2010-04-01/Accounts/{self.twilio_sid}/Messages.json",
                auth=(self.twilio_sid, self.twilio_token),
                data={"To": chat_id, "From": self.twilio_from, "Body": text[:1600]},
                timeout=10)
        except Exception as e:
            logger.error(f"SMS send: {e}")

    def handle_webhook(self, body):
        """Handle inbound SMS from Twilio webhook."""
        params = parse_qs(body if isinstance(body, str) else body.decode("utf-8", errors="replace"))
        text = params.get("Body", [""])[0]
        sender = params.get("From", [""])[0]
        if text and sender:
            self.process_message(sender, sender, text)
        # Return TwiML empty response
        return '<?xml version="1.0" encoding="UTF-8"?><Response></Response>'

    def run(self):
        if not self.twilio_sid:
            logger.error("Set SERAPH_TWILIO_SID, SERAPH_TWILIO_TOKEN, SERAPH_TWILIO_FROM")
            return
        port = int(os.environ.get("SERAPH_SMS_PORT", "3981"))
        bot = self

        class Handler(BaseHTTPRequestHandler):
            def do_POST(self):
                length = int(self.headers.get("Content-Length", 0))
                body = self.rfile.read(length)
                result = bot.handle_webhook(body)
                self.send_response(200)
                self.send_header("Content-Type", "text/xml")
                self.end_headers()
                self.wfile.write(result.encode() if isinstance(result, str) else result)

            def log_message(self, *args):
                pass

        server = HTTPServer(("0.0.0.0", port), Handler)
        logger.info(f"SMS webhook on port {port}")
        server.serve_forever()


def start_sms_bot():
    bot = SeraphSMSBot()
    threading.Thread(target=bot.run, daemon=True).start()
    return True
