"""
Seraph Google Chat Channel -- webhook handler.
"""

import os
import json
import logging
import threading
import requests
from http.server import HTTPServer, BaseHTTPRequestHandler

logger = logging.getLogger("seraph.googlechat")
from channels.base import ChannelBase


class SeraphGoogleChatBot(ChannelBase):
    CHANNEL_NAME = "googlechat"
    MAX_MESSAGE_LENGTH = 4096

    def __init__(self, allowed_users=None):
        super().__init__(allowed_users=allowed_users)
        self.webhook = os.environ.get("SERAPH_GOOGLE_CHAT_WEBHOOK", "")

    def send_message(self, chat_id, text, **kwargs):
        # Google Chat responds via the webhook URL provided in the event
        reply_url = kwargs.get("reply_url", self.webhook)
        if reply_url:
            try:
                requests.post(reply_url, json={"text": text[:4096]}, timeout=10)
            except Exception as e:
                logger.error(f"Google Chat send: {e}")

    def handle_webhook(self, body):
        data = json.loads(body) if isinstance(body, (str, bytes)) else body
        event_type = data.get("type", "")
        if event_type == "MESSAGE":
            text = data.get("message", {}).get("text", "").strip()
            sender = data.get("user", {}).get("name", "")
            space = data.get("space", {}).get("name", "")
            if text and sender:
                self.process_message(space, sender, text)
            return {"text": "Processing..."}
        return {}

    def run(self):
        port = int(os.environ.get("SERAPH_GOOGLE_CHAT_PORT", "3983"))
        bot = self

        class Handler(BaseHTTPRequestHandler):
            def do_POST(self):
                length = int(self.headers.get("Content-Length", 0))
                body = self.rfile.read(length)
                result = bot.handle_webhook(body)
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps(result).encode())

            def log_message(self, *args):
                pass

        server = HTTPServer(("0.0.0.0", port), Handler)
        logger.info(f"Google Chat webhook on port {port}")
        server.serve_forever()


def start_googlechat_bot():
    bot = SeraphGoogleChatBot()
    threading.Thread(target=bot.run, daemon=True).start()
    return True
