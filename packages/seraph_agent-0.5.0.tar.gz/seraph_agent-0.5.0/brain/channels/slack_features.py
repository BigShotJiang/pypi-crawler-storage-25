"""
Seraph Slack Advanced Features — auto-threading, app home, interactive messages, blocks.

Imported by slack_bot.py.
"""

import json
import time
import logging
from typing import Dict, List, Optional, Callable

logger = logging.getLogger("seraph.slack.features")


# ─── Auto-Threading ───────────────────────────────────────────────

class SlackThreadManager:
    """Manage Slack thread-based conversations."""

    def __init__(self):
        self.thread_sessions: Dict[str, str] = {}  # "channel:thread_ts" -> session_key

    def get_session_key(self, channel: str, thread_ts: str = None) -> str:
        """Get session key. Each thread is its own session."""
        if thread_ts:
            key = f"{channel}:{thread_ts}"
            if key not in self.thread_sessions:
                self.thread_sessions[key] = f"slack_{channel}_{thread_ts}"
            return self.thread_sessions[key]
        return f"slack_{channel}"

    def should_thread(self, channel_type: str, message_count: int) -> bool:
        """Decide if we should create a thread (keep channels clean)."""
        return channel_type == "channel" and message_count == 0  # Always thread in channels


# ─── Block Kit ────────────────────────────────────────────────────

def build_status_blocks(model: str, tools: int, sessions: int, cost: float) -> list:
    """Build Slack Block Kit blocks for /status."""
    return [
        {
            "type": "header",
            "text": {"type": "plain_text", "text": "⚡ Seraph Status"},
        },
        {
            "type": "section",
            "fields": [
                {"type": "mrkdwn", "text": f"*Model:*\n{model}"},
                {"type": "mrkdwn", "text": f"*Tools:*\n{tools}"},
                {"type": "mrkdwn", "text": f"*Sessions:*\n{sessions}"},
                {"type": "mrkdwn", "text": f"*Cost Today:*\n${cost:.4f}"},
            ],
        },
        {"type": "divider"},
        {
            "type": "actions",
            "elements": [
                {"type": "button", "text": {"type": "plain_text", "text": "New Chat"}, "action_id": "new_chat"},
                {"type": "button", "text": {"type": "plain_text", "text": "Usage"}, "action_id": "show_usage"},
                {"type": "button", "text": {"type": "plain_text", "text": "Models"}, "action_id": "show_models"},
            ],
        },
    ]


def build_error_blocks(error: str) -> list:
    """Build error display blocks."""
    return [
        {
            "type": "section",
            "text": {"type": "mrkdwn", "text": f"❌ *Error*\n```{error[:2900]}```"},
        },
    ]


def build_code_blocks(code: str, language: str = "") -> list:
    """Build code display blocks."""
    return [
        {
            "type": "section",
            "text": {"type": "mrkdwn", "text": f"```{code[:2900]}```"},
        },
    ]


# ─── App Home Tab ─────────────────────────────────────────────────

def build_app_home_view(user_id: str, model: str, sessions: int, skills: int) -> dict:
    """Build the App Home tab view for Slack."""
    return {
        "type": "home",
        "blocks": [
            {
                "type": "header",
                "text": {"type": "plain_text", "text": "⚡ Seraph"},
            },
            {
                "type": "section",
                "text": {"type": "mrkdwn", "text": "The AI agent that audits itself."},
            },
            {"type": "divider"},
            {
                "type": "section",
                "fields": [
                    {"type": "mrkdwn", "text": f"*Model:*\n{model}"},
                    {"type": "mrkdwn", "text": f"*Active Sessions:*\n{sessions}"},
                    {"type": "mrkdwn", "text": f"*Skills:*\n{skills}"},
                    {"type": "mrkdwn", "text": f"*Status:*\n🟢 Online"},
                ],
            },
            {"type": "divider"},
            {
                "type": "section",
                "text": {"type": "mrkdwn", "text": "*Quick Actions*"},
            },
            {
                "type": "actions",
                "elements": [
                    {"type": "button", "text": {"type": "plain_text", "text": "📊 Usage"}, "action_id": "home_usage"},
                    {"type": "button", "text": {"type": "plain_text", "text": "🔧 Tools"}, "action_id": "home_tools"},
                    {"type": "button", "text": {"type": "plain_text", "text": "🧠 Memory"}, "action_id": "home_memory"},
                    {"type": "button", "text": {"type": "plain_text", "text": "📋 Config"}, "action_id": "home_config"},
                ],
            },
        ],
    }


# ─── Event Handling ───────────────────────────────────────────────

def handle_slack_event(event: dict, process_fn: Callable, api_call: Callable) -> Optional[dict]:
    """Handle a Slack event from the Events API."""
    event_type = event.get("type", "")

    if event_type == "url_verification":
        return {"challenge": event.get("challenge", "")}

    inner = event.get("event", {})
    inner_type = inner.get("type", "")

    if inner_type == "app_mention":
        channel = inner.get("channel", "")
        user = inner.get("user", "")
        text = inner.get("text", "").strip()
        thread_ts = inner.get("thread_ts") or inner.get("ts", "")

        # Remove bot mention from text
        text = text.split(">", 1)[-1].strip() if ">" in text else text

        if text:
            process_fn(channel, user, text, thread_ts)
        return {"ok": True}

    if inner_type == "message":
        # DM or thread reply
        channel_type = inner.get("channel_type", "")
        if channel_type == "im":  # Direct message
            channel = inner.get("channel", "")
            user = inner.get("user", "")
            text = inner.get("text", "")
            if text and not inner.get("bot_id"):  # Ignore bot's own messages
                process_fn(channel, user, text)
        return {"ok": True}

    if inner_type == "app_home_opened":
        user = inner.get("user", "")
        # Publish app home view
        view = build_app_home_view(user, "claude-sonnet-4-6", 0, 0)
        api_call("views.publish", {"user_id": user, "view": view})
        return {"ok": True}

    return {"ok": True}


# ─── Message Chunking ─────────────────────────────────────────────

def chunk_slack_message(text: str, max_length: int = 3000) -> List[str]:
    """Split long text for Slack (limit 4000 but keep 3000 for safety with formatting)."""
    if len(text) <= max_length:
        return [text]

    chunks = []
    while text:
        if len(text) <= max_length:
            chunks.append(text)
            break
        split_at = text.rfind("\n", 0, max_length)
        if split_at == -1 or split_at < max_length // 2:
            split_at = text.rfind(" ", 0, max_length)
        if split_at == -1:
            split_at = max_length
        chunks.append(text[:split_at])
        text = text[split_at:].lstrip()

    return chunks
