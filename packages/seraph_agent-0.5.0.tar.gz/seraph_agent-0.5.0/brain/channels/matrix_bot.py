"""
Seraph Matrix Channel -- full agent with Matrix client-server API sync.
"""

import os
import time
import json
import logging
import threading
import requests

logger = logging.getLogger("seraph.matrix")
from channels.base import ChannelBase


class SeraphMatrixBot(ChannelBase):
    CHANNEL_NAME = "matrix"
    MAX_MESSAGE_LENGTH = 65536

    def __init__(self, allowed_users=None):
        super().__init__(allowed_users=allowed_users)
        self.homeserver = os.environ.get("SERAPH_MATRIX_HOMESERVER", "")
        self.token = os.environ.get("SERAPH_MATRIX_TOKEN", "")
        self.user_id = os.environ.get("SERAPH_MATRIX_USER_ID", "")
        self.since = ""

    def send_message(self, chat_id, text, **kwargs):
        if not self.homeserver or not self.token:
            return
        try:
            txn = str(int(time.time() * 1000))
            url = f"{self.homeserver}/_matrix/client/r0/rooms/{chat_id}/send/m.room.message/{txn}"
            requests.put(url, headers={"Authorization": f"Bearer {self.token}"},
                json={"msgtype": "m.text", "body": text}, timeout=10)
        except Exception as e:
            logger.error(f"Matrix send: {e}")

    def run(self):
        if not self.homeserver or not self.token:
            logger.error("Set SERAPH_MATRIX_HOMESERVER and SERAPH_MATRIX_TOKEN")
            return
        logger.info(f"Matrix: syncing from {self.homeserver}")
        while True:
            try:
                params = {"timeout": 30000}
                if self.since:
                    params["since"] = self.since
                resp = requests.get(f"{self.homeserver}/_matrix/client/r0/sync",
                    headers={"Authorization": f"Bearer {self.token}"},
                    params=params, timeout=60)
                if resp.status_code != 200:
                    time.sleep(5)
                    continue
                data = resp.json()
                self.since = data.get("next_batch", self.since)
                for room_id, room in data.get("rooms", {}).get("join", {}).items():
                    for event in room.get("timeline", {}).get("events", []):
                        if event.get("type") == "m.room.message":
                            sender = event.get("sender", "")
                            if sender == self.user_id:
                                continue
                            body = event.get("content", {}).get("body", "")
                            if body:
                                self.process_message(room_id, sender, body)
            except Exception as e:
                logger.error(f"Matrix sync: {e}")
                time.sleep(5)


def start_matrix_bot():
    bot = SeraphMatrixBot()
    threading.Thread(target=bot.run, daemon=True).start()
    return True
