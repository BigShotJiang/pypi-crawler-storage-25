"""
Seraph Voice Wake — wake word detection + continuous voice mode.

Listens for "Hey Seraph" (or custom wake word), then records audio,
transcribes via Whisper, processes through the agent, speaks response.

Requires: pip install openwakeword pyaudio

Falls back gracefully if audio hardware not available.
"""

import os
import time
import wave
import struct
import logging
import threading
import tempfile
import requests
from pathlib import Path
from typing import Optional, Callable

logger = logging.getLogger("seraph.voice_wake")

WAKE_WORD = os.environ.get("SERAPH_WAKE_WORD", "hey_jarvis")  # openwakeword model name
SAMPLE_RATE = 16000
CHANNELS = 1
CHUNK_SIZE = 1280  # 80ms at 16kHz
SILENCE_THRESHOLD = 500
SILENCE_DURATION = 1.5  # seconds of silence to stop recording
MAX_RECORD_SECONDS = 30
WORKSPACE = Path.home() / ".seraph" / "workspace"


class VoiceWakeEngine:
    """Continuous voice wake word detection and conversation."""

    def __init__(self, process_fn: Optional[Callable] = None, tts_fn: Optional[Callable] = None):
        self.process_fn = process_fn
        self.tts_fn = tts_fn
        self.running = False
        self.listening = False
        self.thread = None
        self.wake_model = None

    def _init_wake_model(self):
        """Initialize wake word detection model."""
        try:
            from openwakeword.model import Model
            self.wake_model = Model(
                wakeword_models=[WAKE_WORD],
                inference_framework="onnx",
            )
            logger.info(f"Wake word model loaded: {WAKE_WORD}")
            return True
        except ImportError:
            logger.warning("openwakeword not installed. pip install openwakeword")
            return False
        except Exception as e:
            logger.error(f"Wake word init error: {e}")
            return False

    def _init_audio(self):
        """Initialize audio input."""
        try:
            import pyaudio
            self.pa = pyaudio.PyAudio()
            self.stream = self.pa.open(
                format=pyaudio.paInt16,
                channels=CHANNELS,
                rate=SAMPLE_RATE,
                input=True,
                frames_per_buffer=CHUNK_SIZE,
            )
            logger.info("Audio input initialized")
            return True
        except ImportError:
            logger.warning("pyaudio not installed. pip install pyaudio")
            return False
        except Exception as e:
            logger.error(f"Audio init error: {e}")
            return False

    def _record_until_silence(self) -> Optional[str]:
        """Record audio until silence is detected. Returns path to wav file."""
        WORKSPACE.mkdir(parents=True, exist_ok=True)
        filepath = WORKSPACE / f"wake_recording_{int(time.time())}.wav"
        frames = []
        silence_frames = 0
        max_frames = int(MAX_RECORD_SECONDS * SAMPLE_RATE / CHUNK_SIZE)
        silence_limit = int(SILENCE_DURATION * SAMPLE_RATE / CHUNK_SIZE)

        logger.info("Recording...")

        for _ in range(max_frames):
            if not self.running:
                break
            try:
                data = self.stream.read(CHUNK_SIZE, exception_on_overflow=False)
                frames.append(data)

                # Check volume level
                samples = struct.unpack(f"<{CHUNK_SIZE}h", data)
                volume = max(abs(s) for s in samples)

                if volume < SILENCE_THRESHOLD:
                    silence_frames += 1
                else:
                    silence_frames = 0

                if silence_frames >= silence_limit and len(frames) > 10:
                    break
            except Exception:
                break

        if len(frames) < 5:
            return None

        # Save as WAV
        try:
            with wave.open(str(filepath), "wb") as wf:
                wf.setnchannels(CHANNELS)
                wf.setsampwidth(2)
                wf.setframerate(SAMPLE_RATE)
                wf.writeframes(b"".join(frames))
            logger.info(f"Recorded {len(frames)} frames -> {filepath}")
            return str(filepath)
        except Exception as e:
            logger.error(f"WAV save error: {e}")
            return None

    def _transcribe(self, audio_path: str) -> str:
        """Transcribe audio via Whisper API."""
        api_key = os.environ.get("OPENAI_API_KEY", "")
        if not api_key:
            return ""
        try:
            with open(audio_path, "rb") as f:
                resp = requests.post(
                    "https://api.openai.com/v1/audio/transcriptions",
                    headers={"Authorization": f"Bearer {api_key}"},
                    files={"file": (Path(audio_path, timeout=15).name, f, "audio/wav")},
                    data={"model": "whisper-1"},
                    timeout=15,
                )
            if resp.status_code == 200:
                return resp.json().get("text", "")
        except Exception as e:
            logger.error(f"Transcription error: {e}")
        return ""

    def _speak(self, text: str):
        """Speak response via TTS."""
        if self.tts_fn:
            self.tts_fn(text)
            return

        api_key = os.environ.get("OPENAI_API_KEY", "")
        if not api_key:
            return

        try:
            resp = requests.post(
                "https://api.openai.com/v1/audio/speech",
                headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
                json={"model": "tts-1", "input": text[:4096], "voice": "nova", "response_format": "mp3"},
                timeout=30,
            )
            if resp.status_code == 200:
                WORKSPACE.mkdir(parents=True, exist_ok=True)
                audio_path = WORKSPACE / f"response_{int(time.time())}.mp3"
                audio_path.write_bytes(resp.content)
                # Play audio (cross-platform)
                import subprocess
                import platform
                if platform.system() == "Darwin":
                    subprocess.Popen(["afplay", str(audio_path)])
                elif platform.system() == "Windows":
                    subprocess.Popen(["powershell", "-Command", f'(New-Object Media.SoundPlayer "{audio_path}").PlaySync()'])
                elif platform.system() == "Linux":
                    subprocess.Popen(["mpg123", "-q", str(audio_path)])
        except Exception as e:
            logger.error(f"TTS error: {e}")

    def start(self):
        """Start wake word listening."""
        self.running = True
        self.thread = threading.Thread(target=self._loop, daemon=True)
        self.thread.start()
        logger.info("Voice wake engine started")

    def stop(self):
        self.running = False
        try:
            if hasattr(self, "stream") and self.stream:
                self.stream.stop_stream()
                self.stream.close()
            if hasattr(self, "pa") and self.pa:
                self.pa.terminate()
        except Exception:
            pass

    def _loop(self):
        """Main wake word detection loop."""
        if not self._init_wake_model():
            logger.warning("Voice wake disabled: no wake word model")
            return
        if not self._init_audio():
            logger.warning("Voice wake disabled: no audio input")
            return

        import numpy as np

        logger.info(f"Listening for wake word: '{WAKE_WORD}'...")

        while self.running:
            try:
                data = self.stream.read(CHUNK_SIZE, exception_on_overflow=False)
                audio = np.frombuffer(data, dtype=np.int16).astype(np.float32) / 32768.0

                # Check for wake word
                prediction = self.wake_model.predict(audio)

                for model_name, score in prediction.items():
                    if score > 0.5:
                        logger.info(f"Wake word detected! ({model_name}: {score:.2f})")

                        # Record user's speech
                        audio_path = self._record_until_silence()
                        if not audio_path:
                            continue

                        # Transcribe
                        text = self._transcribe(audio_path)
                        if not text:
                            continue
                        logger.info(f"Heard: {text}")

                        # Process through agent
                        if self.process_fn:
                            response = self.process_fn("voice", "voice_user", text, "Voice")
                            if response:
                                self._speak(response)

                        # Cleanup
                        try:
                            Path(audio_path).unlink(missing_ok=True)
                        except Exception:
                            pass

            except Exception as e:
                logger.error(f"Voice wake error: {e}")
                time.sleep(1)


def start_voice_wake(process_fn=None, tts_fn=None) -> bool:
    """Start voice wake engine if enabled."""
    if not os.environ.get("SERAPH_VOICE_WAKE", ""):
        logger.info("SERAPH_VOICE_WAKE not set - Voice wake disabled")
        return False
    engine = VoiceWakeEngine(process_fn, tts_fn)
    engine.start()
    return True
