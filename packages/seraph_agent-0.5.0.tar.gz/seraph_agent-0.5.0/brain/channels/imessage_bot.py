"""
Seraph iMessage Channel -- polls BlueBubbles bridge for messages.
"""

import os
import time
import logging
import threading
import requests

logger = logging.getLogger("seraph.imessage")
from channels.base import ChannelBase


class SeraphiMessageBot(ChannelBase):
    CHANNEL_NAME = "imessage"
    MAX_MESSAGE_LENGTH = 20000

    def __init__(self, allowed_users=None):
        super().__init__(allowed_users=allowed_users)
        self.bridge = os.environ.get("SERAPH_IMESSAGE_BRIDGE", "http://localhost:1234")
        self.password = os.environ.get("SERAPH_IMESSAGE_PASSWORD", "")
        self.last_check = time.time() * 1000

    def send_message(self, chat_id, text, **kwargs):
        try:
            requests.post(f"{self.bridge}/api/v1/message/text",
                json={"chatGuid": chat_id, "message": text},
                params={"password": self.password}, timeout=10)
        except Exception as e:
            logger.error(f"iMessage send: {e}")

    def run(self):
        if not self.bridge:
            logger.error("Set SERAPH_IMESSAGE_BRIDGE (BlueBubbles URL)")
            return
        logger.info(f"iMessage: polling {self.bridge}")
        while True:
            try:
                resp = requests.get(f"{self.bridge}/api/v1/message",
                    params={"password": self.password, "after": int(self.last_check),
                            "limit": 20, "sort": "DESC"},
                    timeout=10)
                if resp.status_code == 200:
                    data = resp.json()
                    for msg in reversed(data.get("data", [])):
                        if msg.get("isFromMe"):
                            continue
                        text = msg.get("text", "")
                        sender = msg.get("handle", {}).get("address", "")
                        chat_guid = msg.get("chats", [{}])[0].get("guid", "")
                        ts = msg.get("dateCreated", 0)
                        if text and sender and ts > self.last_check:
                            self.process_message(chat_guid, sender, text)
                            self.last_check = max(self.last_check, ts)
            except Exception as e:
                logger.error(f"iMessage poll: {e}")
            time.sleep(5)


def start_imessage_bot():
    bot = SeraphiMessageBot()
    threading.Thread(target=bot.run, daemon=True).start()
    return True
