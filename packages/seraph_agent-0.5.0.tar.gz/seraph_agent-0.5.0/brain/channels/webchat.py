"""
Seraph WebChat Channel — browser-based chat via WebSocket.

Serves a web UI and handles real-time chat via WebSocket.
Built-in, no external dependencies except the brain API.
"""

import os
import json
import time
import logging
import threading
from typing import Dict, Set

logger = logging.getLogger("seraph.webchat")

WEBCHAT_PORT = int(os.environ.get("SERAPH_WEBCHAT_PORT", "18802"))

# HTML for the webchat UI
WEBCHAT_HTML = """<!DOCTYPE html>
<html><head>
<title>Seraph</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: -apple-system, system-ui, sans-serif; background: #0a0a0a; color: #e0e0e0; height: 100vh; display: flex; flex-direction: column; }
#header { padding: 16px 20px; background: #111; border-bottom: 1px solid #222; font-size: 18px; font-weight: 600; }
#header span { color: #6366f1; }
#messages { flex: 1; overflow-y: auto; padding: 20px; }
.msg { margin-bottom: 12px; max-width: 80%; padding: 10px 14px; border-radius: 12px; line-height: 1.5; white-space: pre-wrap; word-break: break-word; }
.msg.user { background: #6366f1; color: white; margin-left: auto; border-bottom-right-radius: 4px; }
.msg.assistant { background: #1e1e2e; border: 1px solid #333; border-bottom-left-radius: 4px; }
.msg.system { background: #1a1a2e; color: #888; text-align: center; margin: 0 auto; font-size: 13px; }
#input-area { padding: 16px 20px; background: #111; border-top: 1px solid #222; display: flex; gap: 10px; }
#input { flex: 1; background: #1e1e2e; border: 1px solid #333; color: #e0e0e0; padding: 12px 16px; border-radius: 8px; font-size: 15px; outline: none; }
#input:focus { border-color: #6366f1; }
#send { background: #6366f1; color: white; border: none; padding: 12px 20px; border-radius: 8px; cursor: pointer; font-size: 15px; font-weight: 600; }
#send:hover { background: #5558e6; }
.typing { color: #888; font-style: italic; }
</style></head><body>
<div id="header"><span>Seraph</span> WebChat</div>
<div id="messages"><div class="msg system">Connected to Seraph. Type a message to begin.</div></div>
<div id="input-area">
<input id="input" placeholder="Message Seraph..." autocomplete="off">
<button id="send">Send</button>
</div>
<script>
const msgs = document.getElementById('messages');
const input = document.getElementById('input');
const sendBtn = document.getElementById('send');
let ws;

function addMsg(text, role) {
  const div = document.createElement('div');
  div.className = 'msg ' + role;
  div.textContent = text;
  msgs.appendChild(div);
  msgs.scrollTop = msgs.scrollHeight;
}

function connect() {
  ws = new WebSocket('ws://' + location.host + '/ws');
  ws.onmessage = e => {
    const data = JSON.parse(e.data);
    if (data.type === 'message') addMsg(data.text, 'assistant');
    if (data.type === 'typing') {
      let t = document.querySelector('.typing');
      if (!t) { t = document.createElement('div'); t.className = 'msg system typing'; t.textContent = 'Seraph is thinking...'; msgs.appendChild(t); }
    }
    if (data.type === 'done') { const t = document.querySelector('.typing'); if (t) t.remove(); }
  };
  ws.onclose = () => { addMsg('Connection lost. Reconnecting...', 'system'); setTimeout(connect, 3000); };
}

function send() {
  const text = input.value.trim();
  if (!text || !ws) return;
  addMsg(text, 'user');
  ws.send(JSON.stringify({ type: 'message', text }));
  input.value = '';
}

sendBtn.onclick = send;
input.onkeydown = e => { if (e.key === 'Enter') send(); };
connect();
</script></body></html>"""


class WebChatServer:
    """Simple WebSocket chat server."""

    def __init__(self, process_message_fn=None):
        self.process_fn = process_message_fn
        self.clients: Set = set()

    def start(self, port: int = WEBCHAT_PORT):
        """Start the webchat server using Flask + simple websocket."""
        try:
            from flask import Flask, request, Response
            import asyncio

            app = Flask(__name__)

            @app.route("/")
            def index():
                return Response(WEBCHAT_HTML, content_type="text/html")

            @app.route("/api/chat", methods=["POST"])
            def chat():
                data = request.json or {}
                text = data.get("text", "")
                if text and self.process_fn:
                    # Process synchronously for simplicity
                    result = self.process_fn("webchat", "webchat_user", text, "WebChat User")
                    return json.dumps({"response": result or "OK"})
                return json.dumps({"error": "No text"})

            thread = threading.Thread(
                target=lambda: app.run(host="0.0.0.0", port=port, debug=False, use_reloader=False),
                daemon=True,
            )
            thread.start()
            logger.info(f"WebChat server started on port {port}")
            return True

        except Exception as e:
            logger.error(f"WebChat start error: {e}")
            return False


def start_webchat(process_fn=None) -> bool:
    if not os.environ.get("SERAPH_WEBCHAT_ENABLED", ""):
        logger.info("SERAPH_WEBCHAT_ENABLED not set - WebChat disabled")
        return False
    server = WebChatServer(process_fn)
    return server.start()
