"""
Seraph Telegram Channel — connects to Telegram Bot API via polling.

Simple, reliable, no webhook setup needed. Just provide a bot token.
"""

import os
import json
import time
import logging
import signal
import atexit
import requests
from typing import Optional
import asyncio
from pathlib import Path

logger = logging.getLogger("seraph.telegram")

# Import the LLM, identity, and tools
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from agent.llm import LLMProvider, LLMResponse

# Import and register all tools
from tools import terminal, files, web, ssh, git, image, browser, voice, audit, email_tool, database, transcribe, usage, export, health, openapi_import, grounding, vision, sandbox, notify, webhook
from tools import clarify, todo, patch, approval, fuzzy, session_search, voice_mode, mcp, checkpoint, delegate, mixture, export_html
from tools import homeassistant, skills_hub, interrupt, clipboard, progress, qr_code
from channels.canvas import canvas_tool, start_canvas_server
from tools.registry import get_all_tools, get_openai_tool_schemas, execute_tool
from tools.filter import filter_tools

# Import context manager and personas
from agent.context_manager import should_compress, auto_compress
from agent.personas import load_persona, list_personas
from agent.prompt_compiler import compile_prompt, estimate_conversation_tokens
from agent.heartbeat import get_heartbeat
from agent.self_improve import run_improvement_cycle, get_improvement_history
from agent.loop_detection import LoopDetector
from agent.model_router import get_router
from agent.url_safety import check_url
from agent.process_registry import get_process_registry
from cron.scheduler import get_scheduler

# Import memory
from memory.store import get_memory


def _run_tool(name: str, args: dict):
    """Sync wrapper for async tool execution."""
    try:
        loop = asyncio.new_event_loop()
        result = loop.run_until_complete(execute_tool(name, args))
        loop.close()
        return result
    except Exception as e:
        return {"error": str(e)}


class SeraphTelegramBot:
    """Telegram bot that connects to Seraph's brain."""

    def __init__(self, token: str, allowed_users: list = None):
        self.token = token
        self.base_url = f"https://api.telegram.org/bot{token}"
        self.allowed_users = allowed_users or []  # Empty = allow all
        self.offset = 0
        self.conversations = {}  # chat_id -> message history
        self.llm = None
        self.identity = ""

        # Load skills
        self.skills = []
        self.current_persona = "default"

        # Rate limiting: max 20 messages per user per minute
        self.rate_limits = {}  # user_id -> list of timestamps
        self.rate_max = 20
        self.rate_window = 60

        # Load identity
        seraph_dir = Path.home() / ".seraph"
        soul_path = seraph_dir / "SOUL.md"
        if soul_path.exists():
            self.identity = soul_path.read_text()
            logger.info(f"Loaded identity ({len(self.identity)} chars)")
        else:
            self.identity = "You are Seraph, a self-improving AI agent. Be helpful, direct, and honest."

        # Initialize LLM with failover
        try:
            provider = os.environ.get("SERAPH_PROVIDER", "anthropic")
            model = os.environ.get("SERAPH_MODEL", "claude-sonnet-4-6")
            self.llm = LLMProvider(provider=provider, model=model)
            logger.info(f"LLM provider connected: {provider}/{model}")
        except Exception as e:
            logger.error(f"Failed to initialize LLM: {e}")

        # Initialize failover system
        try:
            from agent.failover import AuthProfileStore
            from models.router import ModelRouter
            self.auth_store = AuthProfileStore()
            self.model_router = ModelRouter(default_model=os.environ.get("SERAPH_MODEL", "claude-sonnet-4-6"))
            self.failover_chain = self.model_router.get_failover_chain(self.model_router.default_model).models
            logger.info(f"Failover chain: {self.failover_chain}")
        except Exception as e:
            logger.warning(f"Failover init: {e}")
            self.auth_store = None
            self.model_router = None
            self.failover_chain = []

        # Initialize session store (persistent)
        try:
            from sessions.store import get_session_store
            self.session_store = get_session_store()
            logger.info("Session store connected")
        except Exception as e:
            logger.warning(f"Session store: {e}")
            self.session_store = None

        # Initialize telemetry
        try:
            from diagnostics.telemetry import get_telemetry
            self.telemetry = get_telemetry()
        except Exception:
            self.telemetry = None

        # Initialize Telegram advanced features
        try:
            from channels.telegram_features import ForumTopicManager, StatusReactions, DraftStreamChunker
            self.forum_topics = ForumTopicManager()
            self.status_reactions = StatusReactions(self._api_call)
        except Exception:
            self.forum_topics = None
            self.status_reactions = None

        # Initialize dreaming engine activity tracker
        try:
            from agent.dreaming import get_dreaming_engine
            self.dreaming = get_dreaming_engine()
        except Exception:
            self.dreaming = None

        # Initialize memory
        self.memory = get_memory()
        total_msgs = self.memory.get_message_count()
        total_sessions = self.memory.get_session_count()
        logger.info(f"Memory loaded: {total_msgs} messages across {total_sessions} sessions")

    def _api_call(self, method: str, data: dict = None) -> dict:
        """Call Telegram Bot API."""
        url = f"{self.base_url}/{method}"
        try:
            if data:
                resp = requests.post(url, json=data, timeout=30)
            else:
                resp = requests.get(url, timeout=30)
            if resp.status_code == 200:
                return resp.json()
            else:
                logger.error(f"Telegram API error: {resp.status_code} {resp.text[:200]}")
                return {}
        except Exception as e:
            logger.error(f"Telegram API request failed: {e}")
            return {}

    def send_message(self, chat_id: int, text: str, parse_mode: str = "HTML", reply_to: int = None):
        """Send a message to a Telegram chat, optionally as a reply."""
        # Telegram message limit is 4096 chars
        base_params = {"chat_id": chat_id, "parse_mode": parse_mode}
        if reply_to:
            base_params["reply_parameters"] = {"message_id": reply_to}

        if len(text) > 4096:
            chunks = [text[i:i+4000] for i in range(0, len(text), 4000)]
            for chunk in chunks:
                self._api_call("sendMessage", {**base_params, "text": chunk})
                time.sleep(0.5)
        else:
            self._api_call("sendMessage", {**base_params, "text": text})

    def send_typing(self, chat_id: int):
        """Show typing indicator."""
        self._api_call("sendChatAction", {
            "chat_id": chat_id,
            "action": "typing",
        })

    def send_with_keyboard(self, chat_id: int, text: str, buttons: list, parse_mode: str = "HTML"):
        """Send a message with inline keyboard buttons.
        buttons: list of rows, each row is list of {"text": "label", "callback_data": "action"}
        """
        self._api_call("sendMessage", {
            "chat_id": chat_id,
            "text": text,
            "parse_mode": parse_mode,
            "reply_markup": {"inline_keyboard": buttons},
        })

    def answer_callback(self, callback_id: str, text: str = ""):
        """Answer a callback query (button press)."""
        self._api_call("answerCallbackQuery", {
            "callback_query_id": callback_id,
            "text": text,
        })

    def get_updates(self) -> list:
        """Get new messages via long polling."""
        result = self._api_call("getUpdates", {
            "offset": self.offset,
            "timeout": 30,
            "allowed_updates": ["message", "callback_query"],
        })
        updates = result.get("result", [])
        if updates:
            self.offset = updates[-1]["update_id"] + 1
        return updates

    def process_message(self, chat_id: int, user_id: int, text: str, first_name: str = ""):
        """Process an incoming message through the LLM."""
        # Check allowed users
        if self.allowed_users and user_id not in self.allowed_users:
            self.send_message(chat_id, "You're not authorized to use this bot.")
            return

        # Budget check
        budget_str = self.memory.kv_get(f"budget_{user_id}")
        if budget_str:
            try:
                from tools.usage import get_usage_stats
                today_cost = get_usage_stats()["today"]["cost_usd"]
                if today_cost >= float(budget_str):
                    self.send_message(chat_id, f"Daily budget exceeded (${float(budget_str):.2f}). Resets tomorrow.", parse_mode="")
                    return
            except Exception:
                pass

        # Rate limiting
        now = time.time()
        if user_id not in self.rate_limits:
            self.rate_limits[user_id] = []
        self.rate_limits[user_id] = [t for t in self.rate_limits[user_id] if now - t < self.rate_window]
        if len(self.rate_limits[user_id]) >= self.rate_max:
            self.send_message(chat_id, f"Slow down. Max {self.rate_max} messages per minute.", parse_mode="")
            return
        self.rate_limits[user_id].append(now)

        if not self.llm:
            self.send_message(chat_id, "LLM not connected. Set ANTHROPIC_API_KEY and restart.")
            return

        # Handle /btw side-question (no context pollution)
        if text.startswith("/btw "):
            try:
                from agent.btw import handle_btw
                history = self.conversations.get(chat_id, [])
                response = handle_btw(text[5:], history, self.identity, self.llm)
                self.send_message(chat_id, response, parse_mode="")
            except Exception as e:
                self.send_message(chat_id, f"Error: {e}", parse_mode="")
            return

        # Handle /focus and /unfocus (thread binding)
        if text.startswith("/focus") or text == "/unfocus":
            try:
                from agent.focus import get_focus_manager
                fm = get_focus_manager()
                thread_id = str(getattr(self, '_last_thread_id', chat_id))
                if text == "/unfocus":
                    self.send_message(chat_id, fm.unfocus("telegram", str(chat_id), thread_id), parse_mode="")
                elif text.strip() == "/focus":
                    self.send_message(chat_id, fm.get_status("telegram", str(chat_id), thread_id), parse_mode="")
                else:
                    target = text[7:].strip()
                    self.send_message(chat_id, fm.focus("telegram", str(chat_id), thread_id, target), parse_mode="")
            except Exception as e:
                self.send_message(chat_id, f"Focus error: {e}", parse_mode="")
            return

        # Handle other commands
        if text.startswith("/"):
            self._handle_command(chat_id, text, user_id)
            return

        # Ambient learning — track every message
        try:
            from agent.ambient_learning import get_ambient_learner
            get_ambient_learner().on_message(str(user_id), text)
        except Exception:
            pass

        # Link understanding — auto-fetch URLs in the message
        try:
            from agent.link_understanding import process_message_links
            text, fetched_urls = process_message_links(text)
            if fetched_urls:
                logger.info(f"Link understanding: fetched {len(fetched_urls)} URLs")
        except Exception:
            pass

        # Show typing
        self.send_typing(chat_id)

        # Get or create conversation history
        if chat_id not in self.conversations:
            # Try loading from persistent memory
            session_key = f"chat_{chat_id}"
            saved = self.memory.get_session_history(session_key, limit=20)
            if saved:
                self.conversations[chat_id] = [{"role": m["role"], "content": m["content"]} for m in saved]
                logger.info(f"Restored {len(saved)} messages from memory for chat {chat_id}")
            else:
                self.conversations[chat_id] = []

        history = self.conversations[chat_id]

        # Add user message
        history.append({"role": "user", "content": text})

        # Save to persistent memory
        session_key = f"chat_{chat_id}"
        self.memory.save_message(session_key, str(chat_id), "user", text)

        # Auto-compress when approaching token limit
        if should_compress(history):
            history = auto_compress(history, llm=self.llm, target_messages=15)
            self.conversations[chat_id] = history
            logger.info(f"Auto-compressed chat {chat_id} to {len(history)} messages")
        elif len(history) > 30:
            history = history[-20:]
            self.conversations[chat_id] = history

        # Lazy injection — only load memory when conversation is established
        conv_tokens = estimate_conversation_tokens(history)
        if len(history) <= 2:
            full_identity = compile_prompt(
                identity=self.identity,
                conversation_tokens=conv_tokens,
            )
        else:
            active_mem = self.memory.format_active_for_prompt()
            user_profile = self.memory.format_user_for_prompt(str(user_id))
            full_identity = compile_prompt(
                identity=self.identity,
                active_memory=active_mem,
                user_profile=user_profile,
                conversation_tokens=conv_tokens,
            )

        # Inject context anchors (pinned facts that survive compaction)
        try:
            from agent.context_anchors import get_anchor_store
            anchor_text = get_anchor_store().format_for_prompt()
            if anchor_text:
                full_identity += "\n\n" + anchor_text
        except Exception:
            pass

        # Inject bootstrap files (project-specific instructions)
        try:
            from agent.bootstrap import inject_bootstrap
            full_identity = inject_bootstrap(full_identity)
        except Exception:
            pass

        # Inject ambient learning preferences
        try:
            from agent.ambient_learning import get_ambient_learner
            prefs = get_ambient_learner().format_for_prompt()
            if prefs:
                full_identity += "\n\n" + prefs
        except Exception:
            pass

        # Call LLM with tool loop + failover + telemetry
        try:
            all_tools = get_openai_tool_schemas()
            tools = filter_tools(text, all_tools)  # Smart filtering saves 30-50% tokens
            max_iterations = 10
            total_input = 0
            total_output = 0
            loop_detector = LoopDetector()

            # Track activity for dreaming engine
            if self.dreaming:
                self.dreaming.record_activity()

            # Set status reaction on user's message
            if self.status_reactions and hasattr(self, '_last_user_msg_id'):
                self.status_reactions.thinking(chat_id, self._last_user_msg_id)

            for iteration in range(max_iterations):
                self.send_typing(chat_id)

                # LLM call with failover wrapping
                call_start = time.time()
                try:
                    response = self.llm.chat(
                        messages=history,
                        system=full_identity,
                        tools=tools if tools else None,
                    )
                except Exception as llm_err:
                    # Try failover
                    if self.failover_chain and self.auth_store:
                        from agent.failover import classify_error, FailoverState
                        err_type = classify_error(str(llm_err))
                        logger.warning(f"LLM error ({err_type}): {llm_err}, trying failover...")
                        recovered = False
                        for fallback_model in self.failover_chain:
                            if fallback_model == self.llm.model:
                                continue
                            try:
                                from agent.llm import get_provider_for_model
                                fb_provider = get_provider_for_model(fallback_model) or self.llm.provider
                                fb_llm = LLMProvider(provider=fb_provider, model=fallback_model)
                                response = fb_llm.chat(messages=history, system=full_identity, tools=tools if tools else None)
                                logger.info(f"Failover success: {fallback_model}")
                                recovered = True
                                break
                            except Exception:
                                continue
                        if not recovered:
                            raise llm_err
                    else:
                        raise

                call_duration = int((time.time() - call_start) * 1000)

                # Track telemetry
                if self.telemetry:
                    self.telemetry.track_llm_call(
                        provider=self.llm.provider, model=self.llm.model,
                        input_tokens=response.input_tokens, output_tokens=response.output_tokens,
                        duration_ms=call_duration,
                    )

                # Track usage in model router
                if self.model_router:
                    self.model_router.track_usage(self.llm.model, response.input_tokens, response.output_tokens)

                total_input += response.input_tokens
                total_output += response.output_tokens

                # Track usage
                try:
                    from tools.usage import track
                    track(self.llm.model, response.input_tokens, response.output_tokens)
                except Exception:
                    pass

                # If no tool calls — we have a final text response
                if not response.tool_calls:
                    if response.text:
                        # Confidence gating — check if response is certain
                        try:
                            from agent.confidence import assess_confidence, should_auto_search
                            assessment = assess_confidence(response.text)
                            if assessment.caveat:
                                response.text = assessment.caveat + response.text
                        except Exception:
                            pass

                        history.append({"role": "assistant", "content": response.text})
                        self.send_message(chat_id, response.text, parse_mode="")
                        self.memory.save_message(session_key, str(chat_id), "assistant", response.text, response.output_tokens)

                        # Clear restart recovery — completed successfully
                        try:
                            from agent.restart_recovery import mark_completed
                            mark_completed(session_key)
                        except Exception:
                            pass

                        # Ambient learning — track response
                        try:
                            from agent.ambient_learning import get_ambient_learner
                            get_ambient_learner().on_response_sent(len(response.text))
                        except Exception:
                            pass
                    elif iteration == 0 and not response.text:
                        # Try streaming for first response without tools
                        streamed_text = ""
                        sent_msg_id = None
                        last_edit = 0

                        for chunk in self.llm.chat_stream(history, full_identity):
                            if isinstance(chunk, str):
                                streamed_text += chunk
                                # Edit message every 1 second to show progress
                                now = time.time()
                                if now - last_edit > 1 and len(streamed_text) > 20:
                                    if sent_msg_id:
                                        try:
                                            self._api_call("editMessageText", {
                                                "chat_id": chat_id,
                                                "message_id": sent_msg_id,
                                                "text": streamed_text + " |",
                                            })
                                        except Exception:
                                            pass
                                    else:
                                        result = self._api_call("sendMessage", {
                                            "chat_id": chat_id,
                                            "text": streamed_text + " |",
                                        })
                                        if result.get("ok"):
                                            sent_msg_id = result["result"]["message_id"]
                                    last_edit = now

                        if streamed_text:
                            if sent_msg_id:
                                self._api_call("editMessageText", {
                                    "chat_id": chat_id,
                                    "message_id": sent_msg_id,
                                    "text": streamed_text,
                                })
                            else:
                                self.send_message(chat_id, streamed_text, parse_mode="")
                            history.append({"role": "assistant", "content": streamed_text})
                            self.memory.save_message(session_key, str(chat_id), "assistant", streamed_text)
                    break

                # Handle tool calls
                # Add assistant message with tool calls to history
                tool_call_msg = {
                    "role": "assistant",
                    "content": response.text or None,
                    "tool_calls": [
                        {
                            "id": tc["id"],
                            "type": "function",
                            "function": {
                                "name": tc["name"],
                                "arguments": json.dumps(tc["arguments"]),
                            }
                        }
                        for tc in response.tool_calls
                    ]
                }
                history.append(tool_call_msg)

                # Execute each tool and add results
                for tc in response.tool_calls:
                    tool_name = tc["name"]
                    tool_args = tc["arguments"]

                    logger.info(f"Tool call: {tool_name}({json.dumps(tool_args)[:100]})")
                    self.send_typing(chat_id)

                    # Execute the tool (with self-healing on failure)
                    result = _run_tool(tool_name, tool_args)

                    # Self-healing: if tool failed, try to auto-fix
                    if isinstance(result, dict) and "error" in result:
                        try:
                            from agent.self_healing import classify_failure, attempt_recovery
                            failure_type = classify_failure(tool_name, str(result["error"]))
                            if failure_type != "unknown":
                                recovery = attempt_recovery(tool_name, tool_args, str(result["error"]), failure_type)
                                if recovery and recovery.get("retry"):
                                    retry_args = recovery.get("retry_args", tool_args)
                                    result = _run_tool(tool_name, retry_args)
                                    if isinstance(result, dict) and "error" not in result:
                                        logger.info(f"Self-healed: {recovery.get('action')}")
                        except Exception:
                            pass

                    # Ambient learning — track tool usage
                    try:
                        from agent.ambient_learning import get_ambient_learner
                        get_ambient_learner().on_tool_call(tool_name)
                    except Exception:
                        pass

                    # Save restart recovery state
                    try:
                        from agent.restart_recovery import save_state
                        completed_tools = [tc2["name"] for tc2 in response.tool_calls[:response.tool_calls.index(tc)+1]]
                        save_state(session_key, str(chat_id), str(user_id), "telegram",
                                   text, iteration, completed_tools, self.llm.model)
                    except Exception:
                        pass

                    # Loop detection
                    loop_check = loop_detector.record(tool_name, tool_args, result)
                    if loop_check["action"] == "break":
                        logger.warning(f"Loop detected: {loop_check['reason']}")
                        self.send_message(chat_id, f"Stopped: {loop_check['reason']}", parse_mode="")
                        break
                    elif loop_check["action"] == "warn":
                        result["_loop_warning"] = loop_check["reason"]

                    result_str = json.dumps(result, default=str)

                    # Cap tool output
                    if len(result_str) > 5000:
                        result_str = result_str[:5000] + "...(truncated)"

                    logger.info(f"Tool result: {result_str[:200]}")

                    # Add tool result to history
                    history.append({
                        "role": "tool",
                        "tool_call_id": tc["id"],
                        "content": result_str,
                    })

                # Loop continues — LLM will see tool results and decide next action

            logger.info(
                f"Chat {chat_id}: {len(text)} chars in, iterations={iteration+1}, "
                f"{total_input}+{total_output} tokens"
            )

            # Auto-skill generation: if conversation was complex (5+ tool calls), try to extract a skill
            if iteration >= 3 and len(history) >= 10:
                try:
                    from skills.generator import generate_skill_from_conversation
                    skill = generate_skill_from_conversation(history, self.llm)
                    if skill:
                        logger.info(f"Auto-generated skill: {skill.get('name', '?')}")
                except Exception as e:
                    logger.debug(f"Skill generation skipped: {e}")

        except Exception as e:
            logger.error(f"Error processing message: {e}")
            self.send_message(chat_id, "Something went wrong. Try again or use /new to start fresh.", parse_mode="")


    def _handle_voice(self, chat_id: int, file_id: str) -> str:
        """Download and transcribe a voice message."""
        try:
            # Get file path from Telegram
            file_info = self._api_call("getFile", {"file_id": file_id})
            if not file_info.get("ok"):
                return ""

            file_path = file_info["result"]["file_path"]
            download_url = f"https://api.telegram.org/file/bot{self.token}/{file_path}"

            # Download the voice file
            import requests
            resp = requests.get(download_url, timeout=30)
            if resp.status_code != 200:
                return ""

            # Save to temp file
            from pathlib import Path
            import time
            temp_dir = Path.home() / ".seraph" / "workspace"
            temp_dir.mkdir(parents=True, exist_ok=True)
            temp_file = temp_dir / f"voice_{int(time.time())}.ogg"
            temp_file.write_bytes(resp.content)

            # Transcribe using Whisper
            result = _run_tool("transcribe", {"file_path": str(temp_file)})

            # Clean up temp file
            try:
                temp_file.unlink()
            except Exception:
                pass

            return result.get("text", "")

        except Exception as e:
            logger.error(f"Voice handling error: {e}")
            return ""

    def _download_telegram_file(self, file_id: str, save_name: str = "") -> str:
        """Download a file from Telegram and save to workspace."""
        try:
            file_info = self._api_call("getFile", {"file_id": file_id})
            if not file_info.get("ok"):
                return ""
            file_path = file_info["result"]["file_path"]
            download_url = f"https://api.telegram.org/file/bot{self.token}/{file_path}"
            resp = requests.get(download_url, timeout=30)
            if resp.status_code != 200:
                return ""
            from pathlib import Path
            workspace = Path.home() / ".seraph" / "workspace"
            workspace.mkdir(parents=True, exist_ok=True)
            if not save_name:
                save_name = file_path.split("/")[-1]
            save_path = workspace / save_name
            save_path.write_bytes(resp.content)
            logger.info(f"Downloaded file: {save_path} ({len(resp.content)} bytes)")
            return str(save_path)
        except Exception as e:
            logger.error(f"File download error: {e}")
            return ""

    def _send_file(self, chat_id: int, file_path: str, caption: str = ""):
        """Send a file to a Telegram chat."""
        try:
            from pathlib import Path
            p = Path(file_path)
            if not p.exists():
                self.send_message(chat_id, f"File not found: {file_path}", parse_mode="")
                return
            with open(p, "rb") as f:
                files = {"document": (p.name, f)}
                data = {"chat_id": chat_id}
                if caption:
                    data["caption"] = caption[:1024]
                resp = requests.post(
                    f"{self.base_url}/sendDocument",
                    data=data,
                    files=files,
                    timeout=30,
                )
                if resp.status_code == 200:
                    logger.info(f"Sent file: {p.name} to {chat_id}")
                else:
                    logger.error(f"Send file error: {resp.status_code}")
        except Exception as e:
            logger.error(f"Send file error: {e}")

    def _handle_command(self, chat_id: int, text: str, user_id: int = 0):
        """Handle bot commands."""
        parts = text.split()
        cmd = parts[0].lower()
        args = " ".join(parts[1:]) if len(parts) > 1 else ""

        if cmd == "/start":
            tools_count = len(get_all_tools())
            self.send_message(chat_id,
                "⚡ <b>Seraph</b> — the AI agent that audits itself.\n\n"
                "Just talk to me. I can think, code, search the web, create files, and execute commands.\n\n"
                "<b>Commands:</b>\n"
                "/new — Fresh conversation\n"
                "/model — View or change model\n"
                "/status — System status\n"
                "/tools — List available tools\n"
                "/exec &lt;cmd&gt; — Run a shell command\n"
                "/search &lt;query&gt; — Search the web\n"
                "/read &lt;file&gt; — Read a file\n"
                "/write &lt;file&gt; — Write a file (content in next msg)\n"
                "/files — List workspace files\n"
                "/skill — List skills\n"
                "/memory — View memory status\n"
                "/persona — Switch personality\n"
                "/raw &lt;msg&gt; — Direct LLM (zero overhead)\n"
                "/sandbox &lt;code&gt; — Run Python code\n"
                "/branch — Fork conversation\n"
                "/undo — Undo last exchange\n"
                "/checkpoint — Save conversation state\n"
                "/restore — Restore a checkpoint\n"
                "/compress — Smart compress conversation\n"
                "/retry — Retry last response\n"
                "/improve — Self-improvement cycle\n"
                "/cron — Manage scheduled jobs\n"
                "/heartbeat — Health monitor status\n"
                "/usage — Token usage this session\n"
                "/config — View/change settings\n"
                "/update — Pull latest from git\n"
                "/restart — Restart the bot\n"
                "/backup — Backup all data\n"
                "/logs — View recent logs\n"
                "/budget — Daily spending limit\n"
                "/template — Prompt templates\n"
                "/id — Show your Telegram ID\n"
                "/help — Show this help\n\n"
                f"<b>{tools_count} tools loaded</b> | Model: {self.llm.model if self.llm else 'none'}",
                reply_markup={"inline_keyboard": [
                    [{"text": "New Chat", "callback_data": "cmd_new"}, {"text": "Status", "callback_data": "cmd_status"}],
                    [{"text": "Usage", "callback_data": "cmd_usage"}, {"text": "Memory", "callback_data": "cmd_memory"}],
                    [{"text": "Tools", "callback_data": "cmd_tools"}],
                ]},
            )

        elif cmd == "/new":
            self.conversations.pop(chat_id, None)
            self.send_message(chat_id, "🔄 Conversation cleared. Fresh start.", parse_mode="")

        elif cmd == "/model":
            if args:
                # Change model
                old_model = self.llm.model if self.llm else "none"
                try:
                    self.llm.model = args
                    self.send_message(chat_id, f"✅ Model changed: {old_model} → {args}", parse_mode="")
                except Exception as e:
                    self.send_message(chat_id, f"❌ Failed to change model: {e}", parse_mode="")
            else:
                model = self.llm.model if self.llm else "not connected"
                self.send_message(chat_id,
                    f"🤖 Current model: <b>{model}</b>\n\n"
                    "Change with: /model &lt;model-name&gt;\n\n"
                    "Examples:\n"
                    "• /model gpt-5.4\n"
                    "• /model gpt-4.1\n"
                    "• /model gpt-4o\n"
                    "• /model claude-sonnet-4-6\n"
                    "• /model claude-opus-4-6",
                )

        elif cmd == "/status":
            convos = len(self.conversations)
            model = self.llm.model if self.llm else "not connected"
            provider = self.llm.provider if self.llm else "none"
            tools_count = len(get_all_tools())
            msg_count = sum(len(h) for h in self.conversations.values())
            self.send_message(chat_id,
                f"⚡ <b>Seraph Status</b>\n\n"
                f"Status: 🟢 Running\n"
                f"Provider: {provider}\n"
                f"Model: {model}\n"
                f"Tools: {tools_count} loaded\n"
                f"Conversations: {convos}\n"
                f"Messages in memory: {msg_count}\n"
                f"Identity: {len(self.identity)} chars",
            )

        elif cmd == "/tools":
            tools = get_all_tools()
            tool_list = "\n".join(f"• <b>{name}</b> — {t['description'][:60]}" for name, t in tools.items())
            self.send_message(chat_id, f"🔧 <b>Available Tools ({len(tools)})</b>\n\n{tool_list}")

        elif cmd == "/exec":
            if not args:
                self.send_message(chat_id, "Usage: /exec <command>\nExample: /exec ls -la", parse_mode="")
                return
            self.send_typing(chat_id)
            from tools.registry import execute_tool
            result = _run_tool("terminal", {"command": args})
            output = result.get("stdout", "") + result.get("stderr", "")
            if not output:
                output = json.dumps(result, indent=2)
            # Wrap in code block
            if len(output) > 3900:
                output = output[:3900] + "\n...(truncated)"
            self.send_message(chat_id, f"<pre>{output}</pre>")

        elif cmd == "/search":
            if not args:
                self.send_message(chat_id, "Usage: /search <query>", parse_mode="")
                return
            self.send_typing(chat_id)
            result = _run_tool("web_search", {"query": args})
            results = result.get("results", [])
            if results:
                msg = f"🔍 <b>Search: {args}</b>\n\n"
                for r in results[:5]:
                    msg += f"• <a href=\"{r['url']}\">{r['title']}</a>\n"
                self.send_message(chat_id, msg)
            else:
                self.send_message(chat_id, f"No results for: {args}", parse_mode="")

        elif cmd == "/read":
            if not args:
                self.send_message(chat_id, "Usage: /read <filepath>", parse_mode="")
                return
            result = _run_tool("read_file", {"path": args})
            if "error" in result:
                self.send_message(chat_id, f"❌ {result['error']}", parse_mode="")
            else:
                content = result.get("content", "")
                if len(content) > 3900:
                    content = content[:3900] + "\n...(truncated)"
                self.send_message(chat_id, f"📄 <b>{args}</b> ({result.get('lines',0)} lines)\n\n<pre>{content}</pre>")

        elif cmd == "/files":
            directory = args or ""
            result = _run_tool("list_files", {"directory": directory})
            files = result.get("files", [])
            if files:
                msg = f"📁 <b>{result.get('directory', 'workspace')}</b>\n\n"
                for f in files[:30]:
                    icon = "📁" if f["is_dir"] else "📄"
                    size = f"{f['size']:,}" if f['size'] > 0 else ""
                    msg += f"{icon} {f['name']} {size}\n"
                self.send_message(chat_id, msg)
            else:
                self.send_message(chat_id, "Empty directory", parse_mode="")

        elif cmd == "/skill":
            if self.skills:
                msg = "📚 <b>Installed Skills</b>\n\n"
                for s in self.skills:
                    msg += f"• <b>{s['name']}</b>\n"
                self.send_message(chat_id, msg)
            else:
                self.send_message(chat_id, "No skills installed yet.\nSkills go in ~/.seraph/skills/", parse_mode="")

        elif cmd == "/memory":
            total_msgs = self.memory.get_message_count()
            total_sessions = self.memory.get_session_count()
            active = self.memory.get_all_active()
            user = self.memory.get_user(str(chat_id))
            self.send_message(chat_id,
                f"🧠 <b>Memory Status</b>\n\n"
                f"<b>Tier 1 — Active Memory:</b> {len(active)} facts stored\n"
                f"<b>Tier 2 — Archive:</b> {total_msgs} messages across {total_sessions} sessions\n"
                f"<b>Tier 3 — User Profile:</b> {len(user.get('facts',[]))} facts, {len(user.get('corrections',[]))} corrections\n"
                f"<b>Tier 4 — Skills:</b> {len(self.skills)} loaded\n\n"
                f"Commands:\n"
                f"/remember &lt;fact&gt; — Save a fact to active memory\n"
                f"/forget &lt;key&gt; — Remove a fact\n"
                f"/recall &lt;query&gt; — Search conversation history",
            )

        elif cmd == "/remember":
            if not args:
                self.send_message(chat_id, "Usage: /remember <key>=<value>\nExample: /remember name=David", parse_mode="")
                return
            if "=" in args:
                key, value = args.split("=", 1)
                self.memory.set_active(key.strip(), value.strip())
                self.send_message(chat_id, f"✅ Remembered: {key.strip()} = {value.strip()}", parse_mode="")
            else:
                # Auto-key
                self.memory.set_active(f"fact_{int(time.time())}", args)
                self.send_message(chat_id, f"✅ Remembered: {args}", parse_mode="")

        elif cmd == "/forget":
            if not args:
                active = self.memory.get_all_active()
                if active:
                    msg = "Active memories:\n" + "\n".join(f"• {k}: {v}" for k, v in active.items())
                    msg += "\n\nUsage: /forget <key>"
                    self.send_message(chat_id, msg, parse_mode="")
                else:
                    self.send_message(chat_id, "No active memories to forget", parse_mode="")
                return
            self.memory.delete_active(args.strip())
            self.send_message(chat_id, f"✅ Forgot: {args.strip()}", parse_mode="")

        elif cmd == "/recall":
            if not args:
                self.send_message(chat_id, "Usage: /recall <search query>\nSearches all past conversations", parse_mode="")
                return
            results = self.memory.search_history(args, limit=5)
            if results:
                msg = f"🔍 <b>Recall: {args}</b>\n\n"
                for r in results:
                    msg += f"[{r['role']}] {r['snippet'][:150]}\n<i>{r['time']}</i>\n\n"
                self.send_message(chat_id, msg)
            else:
                self.send_message(chat_id, f"No memories matching: {args}", parse_mode="")

        elif cmd == "/personality":
            if args:
                self.identity = args
                self.send_message(chat_id, f"✅ Identity updated ({len(args)} chars)", parse_mode="")
            else:
                preview = self.identity[:200] + "..." if len(self.identity) > 200 else self.identity
                self.send_message(chat_id, f"Current identity ({len(self.identity)} chars):\n\n{preview}", parse_mode="")

        elif cmd == "/compress":
            if chat_id in self.conversations:
                old_len = len(self.conversations[chat_id])
                self.conversations[chat_id] = auto_compress(self.conversations[chat_id], llm=self.llm, target_messages=8)
                new_len = len(self.conversations[chat_id])
                self.send_message(chat_id, f"Compressed: {old_len} -> {new_len} messages", parse_mode="")
            else:
                self.send_message(chat_id, "Nothing to compress", parse_mode="")

        elif cmd == "/retry":
            if chat_id in self.conversations and len(self.conversations[chat_id]) >= 2:
                # Remove last assistant message and re-process last user message
                history = self.conversations[chat_id]
                while history and history[-1]["role"] == "assistant":
                    history.pop()
                if history and history[-1]["role"] == "user":
                    last_msg = history[-1]["content"]
                    history.pop()
                    self.send_message(chat_id, "🔄 Retrying...", parse_mode="")
                    self.process_message(chat_id, 0, last_msg)
                    return
            self.send_message(chat_id, "Nothing to retry", parse_mode="")

        elif cmd == "/usage":
            try:
                from tools.usage import get_usage_stats
                stats = get_usage_stats()
                today = stats["today"]
                total = stats["total"]
                self.send_message(chat_id,
                    f"📊 <b>Usage Stats</b>\n\n"
                    f"<b>Today:</b>\n"
                    f"  Requests: {today['requests']}\n"
                    f"  Tokens: {today['input_tokens']:,} in / {today['output_tokens']:,} out\n"
                    f"  Cost: ${today['cost_usd']:.4f}\n\n"
                    f"<b>All Time ({stats['days_tracked']} days):</b>\n"
                    f"  Requests: {total['requests']:,}\n"
                    f"  Tokens: {total['input_tokens']:,} in / {total['output_tokens']:,} out\n"
                    f"  Cost: ${total['cost_usd']:.4f}",
                )
            except Exception as e:
                self.send_message(chat_id, f"Usage error: {e}", parse_mode="")

        elif cmd == "/send":
            if not args:
                self.send_message(chat_id, "Usage: /send <filepath>", parse_mode="")
                return
            self._send_file(chat_id, args.strip())

        elif cmd == "/stop":
            self.send_message(chat_id, "⏹ No active task to stop", parse_mode="")

        elif cmd == "/help":
            self._handle_command(chat_id, "/start")

        elif cmd == "/undo":
            if chat_id in self.conversations:
                history = self.conversations[chat_id]
                # Remove last assistant + user message pair
                removed = 0
                while history and history[-1]["role"] == "assistant":
                    history.pop()
                    removed += 1
                while history and history[-1]["role"] == "tool":
                    history.pop()
                    removed += 1
                if history and history[-1]["role"] == "user":
                    last_msg = history[-1]["content"][:50]
                    history.pop()
                    removed += 1
                    self.send_message(chat_id, f"Rewound {removed} messages. Last removed: \"{last_msg}...\"", parse_mode="")
                else:
                    self.send_message(chat_id, "Nothing to undo", parse_mode="")
            else:
                self.send_message(chat_id, "No conversation to undo", parse_mode="")

        elif cmd == "/checkpoint":
            # Save a named checkpoint of the current conversation
            if chat_id in self.conversations:
                name = args or f"checkpoint_{int(time.time())}"
                history = self.conversations[chat_id]
                self.memory.kv_set(f"checkpoint_{chat_id}_{name}", json.dumps(history))
                self.send_message(chat_id, f"Checkpoint saved: {name} ({len(history)} messages)", parse_mode="")
            else:
                self.send_message(chat_id, "No conversation to checkpoint", parse_mode="")

        elif cmd == "/restore":
            if not args:
                self.send_message(chat_id, "Usage: /restore <checkpoint-name>", parse_mode="")
                return
            saved = self.memory.kv_get(f"checkpoint_{chat_id}_{args.strip()}")
            if saved:
                try:
                    self.conversations[chat_id] = json.loads(saved)
                except (json.JSONDecodeError, IOError):
                    self.conversations[chat_id] = {}
                self.send_message(chat_id, f"Restored checkpoint: {args.strip()} ({len(self.conversations[chat_id])} messages)", parse_mode="")
            else:
                self.send_message(chat_id, f"Checkpoint not found: {args.strip()}", parse_mode="")

        elif cmd == "/persona":
            if args:
                persona_text = load_persona(args.strip())
                if persona_text:
                    self.identity = persona_text
                    self.send_message(chat_id, f"Persona switched to: {args.strip()}", parse_mode="")
                else:
                    self.send_message(chat_id, f"Persona not found: {args.strip()}", parse_mode="")
            else:
                personas = list_personas()
                msg = "Available personas:\n\n"
                for p in personas:
                    msg += f"  {p['name']} ({p['type']}) — {p['preview']}\n"
                msg += "\nUsage: /persona <name>"
                self.send_message(chat_id, msg, parse_mode="")

        elif cmd == "/branch":
            # Conversation branching — fork current conversation
            if chat_id in self.conversations:
                import copy
                branch_key = f"branch_{chat_id}_{int(time.time())}"
                self.memory.kv_set(branch_key, json.dumps(self.conversations[chat_id]))
                branch_id = branch_key.split("_")[-1]
                self.send_message(chat_id, f"Conversation branched. Branch ID: {branch_id}\nContinue here — the branch is saved. Use /restore branch_{chat_id}_{branch_id} to go back.", parse_mode="")
            else:
                self.send_message(chat_id, "No conversation to branch", parse_mode="")

        elif cmd == "/raw":
            # Passthrough mode — zero overhead, direct LLM call
            if not args:
                self.send_message(chat_id, "Usage: /raw <message>\nSends directly to the LLM with zero injection (no memory, no tools, no identity).", parse_mode="")
                return
            self.send_typing(chat_id)
            try:
                response = self.llm.chat(
                    messages=[{"role": "user", "content": args}],
                    system="",
                    tools=None,
                )
                if response.text:
                    self.send_message(chat_id, response.text, parse_mode="")
                else:
                    self.send_message(chat_id, "(empty response)", parse_mode="")
            except Exception as e:
                self.send_message(chat_id, f"Error: {e}", parse_mode="")

        elif cmd == "/sandbox":
            if not args:
                self.send_message(chat_id, "Usage: /sandbox <python code>\nRuns code in isolated sandbox (10s timeout)", parse_mode="")
                return
            self.send_typing(chat_id)
            result = _run_tool("run_code", {"code": args, "language": "python"})
            if "error" in result:
                self.send_message(chat_id, f"Error: {result['error']}", parse_mode="")
            else:
                output = result.get("stdout", "") or "(no output)"
                stderr = result.get("stderr", "")
                msg = f"Exit: {result.get('exit_code', '?')}\n\n{output}"
                if stderr:
                    msg += f"\n\nSTDERR:\n{stderr}"
                if len(msg) > 3900:
                    msg = msg[:3900] + "\n...(truncated)"
                self.send_message(chat_id, msg, parse_mode="")

        elif cmd == "/cron":
            scheduler = get_scheduler()
            if not args:
                jobs = scheduler.list_jobs()
                if jobs:
                    msg = f"Cron jobs ({len(jobs)}):\n\n"
                    for j in jobs:
                        status = "ON" if j["enabled"] else "OFF"
                        msg += f"  [{status}] {j['name']} — {j['schedule']}\n    cmd: {j['command'][:60]}\n    runs: {j['run_count']}\n\n"
                    msg += "Usage:\n  /cron add <name> <schedule> <command>\n  /cron remove <name>"
                else:
                    msg = "No cron jobs.\n\nUsage:\n  /cron add <name> <schedule> <command>\n  /cron remove <name>\n\nSchedules: every 5m, every 1h, daily 09:00"
                self.send_message(chat_id, msg, parse_mode="")
            elif args.startswith("add "):
                parts = args[4:].split(" ", 2)
                if len(parts) < 3:
                    self.send_message(chat_id, "Usage: /cron add <name> <schedule> <command>\nExample: /cron add backup every_1h /exec tar czf backup.tar.gz ~/.seraph/", parse_mode="")
                    return
                name = parts[0]
                # Find schedule (could be "every 5m" or "daily 09:00" — 2 words)
                rest = parts[1] + " " + parts[2]
                if rest.startswith("every ") or rest.startswith("daily "):
                    schedule_parts = rest.split(" ", 2)
                    if len(schedule_parts) >= 3:
                        schedule = schedule_parts[0] + " " + schedule_parts[1]
                        command = schedule_parts[2]
                    else:
                        schedule = rest
                        command = ""
                else:
                    schedule = parts[1]
                    command = parts[2]
                if command:
                    scheduler.add_job(name, schedule, command)
                    self.send_message(chat_id, f"Cron job added: {name} ({schedule})", parse_mode="")
                else:
                    self.send_message(chat_id, "Could not parse schedule. Use: every 5m, every 1h, daily 09:00", parse_mode="")
            elif args.startswith("remove "):
                name = args[7:].strip()
                if scheduler.remove_job(name):
                    self.send_message(chat_id, f"Removed cron job: {name}", parse_mode="")
                else:
                    self.send_message(chat_id, f"Job not found: {name}", parse_mode="")
            else:
                self.send_message(chat_id, "Usage: /cron, /cron add <name> <schedule> <cmd>, /cron remove <name>", parse_mode="")

        elif cmd == "/improve":
            if args == "history":
                history = get_improvement_history(10)
                if history:
                    msg = "Recent improvements:\n\n"
                    for h in history[-10:]:
                        msg += f"  [{h['category']}] {h['description']}\n  {h['timestamp'][:16]}\n\n"
                    self.send_message(chat_id, msg, parse_mode="")
                else:
                    self.send_message(chat_id, "No improvement history yet.", parse_mode="")
            elif args == "auto":
                # Register daily self-improvement cron job
                scheduler = get_scheduler()
                scheduler.add_job("self_improve", "every 6h", "self_improve")
                self.send_message(chat_id, "Auto-improvement enabled: runs every 6 hours.\nUse /cron to manage.", parse_mode="")
            else:
                self.send_message(chat_id, "Running self-improvement cycle...", parse_mode="")
                self.send_typing(chat_id)
                try:
                    results = run_improvement_cycle(self.memory, self.llm)
                    steps = results.get("steps", [])
                    msg = "Self-improvement cycle complete:\n\n"
                    for s in steps:
                        name = s["name"].replace("_", " ").title()
                        details = ", ".join(f"{k}={v}" for k, v in s.items() if k != "name")
                        msg += f"  {name}: {details}\n"
                    msg += "\nUse /improve history to see all improvements.\nUse /improve auto to run every 6h."
                    self.send_message(chat_id, msg, parse_mode="")
                except Exception as e:
                    self.send_message(chat_id, f"Improvement cycle failed: {e}", parse_mode="")

        elif cmd == "/heartbeat":
            if args == "on":
                self.heartbeat.start()
                self.send_message(chat_id, "Heartbeat enabled (every 60s)", parse_mode="")
            elif args == "off":
                self.heartbeat.stop()
                self.send_message(chat_id, "Heartbeat paused", parse_mode="")
            else:
                status = self.heartbeat.get_status()
                self.send_message(chat_id,
                    f"Heartbeat:\n\n"
                    f"  Status: {status['status']}\n"
                    f"  Uptime: {status['uptime']}\n"
                    f"  Checks: {status['checks']}\n"
                    f"  Errors (5m): {status['error_rate_5m']}\n"
                    f"  Conversations: {status['conversations']}\n\n"
                    f"  /heartbeat on — enable\n"
                    f"  /heartbeat off — pause",
                    parse_mode=""
                )

        elif cmd == "/config":
            if args:
                # Set a config value: /config key=value
                if "=" in args:
                    key, value = args.split("=", 1)
                    self.memory.kv_set(f"config_{key.strip()}", value.strip())
                    self.send_message(chat_id, f"Config set: {key.strip()} = {value.strip()}", parse_mode="")
                else:
                    # Get a config value
                    val = self.memory.kv_get(f"config_{args.strip()}")
                    if val:
                        self.send_message(chat_id, f"Config {args.strip()} = {val}", parse_mode="")
                    else:
                        self.send_message(chat_id, f"Config '{args.strip()}' not set", parse_mode="")
            else:
                # Show all config
                model = self.llm.model if self.llm else "none"
                provider = self.llm.provider if self.llm else "none"
                tools_count = len(get_all_tools())
                self.send_message(chat_id,
                    f"Settings:\n"
                    f"  provider: {provider}\n"
                    f"  model: {model}\n"
                    f"  tools: {tools_count}\n"
                    f"  memory: enabled\n\n"
                    f"Set with: /config key=value",
                    parse_mode=""
                )

        elif cmd == "/doctor":
            self.send_typing(chat_id)
            from agent.doctor import run_doctor, format_doctor_report
            result = run_doctor()
            report = format_doctor_report(result)
            self.send_message(chat_id, report, parse_mode="")

        elif cmd == "/approve":
            from agent.pairing import approve_user, list_pending, deny_user
            if not args:
                pending = list_pending()
                if pending["pending"]:
                    msg = "Pending pairing requests:\n\n"
                    for uid, info in pending["pending"].items():
                        msg += f"  {info.get('name', uid)} — code: {info['code']}\n"
                    msg += "\nUsage: /approve <code> or /approve deny <user_id>"
                else:
                    msg = f"No pending requests. {pending['approved_count']} approved users."
                self.send_message(chat_id, msg, parse_mode="")
            elif args.startswith("deny "):
                ok, reason = deny_user(args[5:].strip())
                self.send_message(chat_id, reason, parse_mode="")
            else:
                ok, reason = approve_user(code=args.strip())
                if not ok:
                    ok, reason = approve_user(user_id=args.strip())
                self.send_message(chat_id, reason, parse_mode="")

        elif cmd == "/think":
            from agent.thinking import list_levels, THINKING_LEVELS
            if args and args.strip() in THINKING_LEVELS:
                self.memory.kv_set(f"thinking_{user_id}", args.strip())
                level = THINKING_LEVELS[args.strip()]
                self.send_message(chat_id, f"Thinking level: {args.strip()} — {level['description']}", parse_mode="")
            else:
                levels = list_levels()
                current = self.memory.kv_get(f"thinking_{user_id}") or "medium"
                msg = f"Current: {current}\n\nLevels:\n"
                for l in levels:
                    marker = " <-" if l["level"] == current else ""
                    msg += f"  {l['level']}: {l['description']}{marker}\n"
                msg += "\nUsage: /think <level>"
                self.send_message(chat_id, msg, parse_mode="")

        elif cmd == "/insights":
            from agent.insights import get_insights
            data = get_insights()
            msg = f"Insights:\n\n"
            msg += f"  Conversations: {data['total_conversations']}\n"
            msg += f"  Messages: {data['total_messages']}\n"
            msg += f"  Avg response: {data['avg_response_tokens']} tokens\n\n"
            if data["top_tools"]:
                msg += "Top tools:\n"
                for t in data["top_tools"][:5]:
                    msg += f"  {t['tool']}: {t['count']} calls\n"
            if data["daily_trend"]:
                msg += "\nDaily trend:\n"
                for d in data["daily_trend"]:
                    msg += f"  {d['date']}: {d['messages']} msgs\n"
            self.send_message(chat_id, msg, parse_mode="")

        elif cmd == "/update":
            self.send_message(chat_id, "Checking for updates...", parse_mode="")
            self.send_typing(chat_id)
            import subprocess
            seraph_dir = str(Path(__file__).resolve().parent.parent.parent)
            try:
                # Check if git repo
                result = subprocess.run(["git", "-C", seraph_dir, "status", "--porcelain"], capture_output=True, text=True, timeout=10)
                if result.returncode != 0:
                    self.send_message(chat_id, "Not a git repo. Clone from GitHub first.", parse_mode="")
                    return

                dirty = result.stdout.strip()
                if dirty:
                    self.send_message(chat_id, f"Local changes detected:\n{dirty[:500]}\n\nCommit or stash first.", parse_mode="")
                    return

                # Pull latest
                result = subprocess.run(["git", "-C", seraph_dir, "pull", "--ff-only"], capture_output=True, text=True, timeout=30)
                output = result.stdout.strip()
                if "Already up to date" in output:
                    self.send_message(chat_id, "Already up to date.", parse_mode="")
                elif result.returncode == 0:
                    self.send_message(chat_id, f"Updated:\n{output[:500]}\n\nRestart with /restart to apply.", parse_mode="")
                else:
                    self.send_message(chat_id, f"Update failed:\n{result.stderr[:500]}", parse_mode="")
            except Exception as e:
                self.send_message(chat_id, f"Update error: {e}", parse_mode="")

        elif cmd == "/restart":
            self.send_message(chat_id, "Restarting...", parse_mode="")
            self._shutdown()
            import subprocess, sys
            subprocess.Popen([sys.executable] + sys.argv)
            os._exit(0)

        elif cmd == "/backup":
            self.send_typing(chat_id)
            import subprocess, shutil
            seraph_data = Path.home() / ".seraph"
            backup_dir = seraph_data / "backups"
            backup_dir.mkdir(parents=True, exist_ok=True)
            backup_name = f"seraph_backup_{int(time.time())}"
            backup_path = backup_dir / f"{backup_name}.tar.gz"
            try:
                # Backup memory.db, config, skills, cron (NOT .env)
                files_to_backup = []
                for pattern in ["memory.db", "config.yaml", "SOUL.md", "heartbeat.json"]:
                    f = seraph_data / pattern
                    if f.exists():
                        files_to_backup.append(str(f))
                for subdir in ["skills", "cron", "personas", "plugins"]:
                    d = seraph_data / subdir
                    if d.exists():
                        files_to_backup.append(str(d))

                result = subprocess.run(
                    ["tar", "czf", str(backup_path)] + files_to_backup,
                    capture_output=True, text=True, timeout=30,
                )
                if backup_path.exists():
                    size_kb = backup_path.stat().st_size // 1024
                    self.send_message(chat_id, f"Backup created: {backup_name}.tar.gz ({size_kb}KB)", parse_mode="")
                    self._send_file(chat_id, str(backup_path), caption="Seraph backup")
                else:
                    self.send_message(chat_id, f"Backup failed: {result.stderr[:200]}", parse_mode="")
            except Exception as e:
                self.send_message(chat_id, f"Backup error: {e}", parse_mode="")

        elif cmd == "/logs":
            try:
                # Read last 30 lines from the log
                import subprocess
                result = subprocess.run(
                    ["tail", "-30", str(Path.home() / ".seraph" / "seraph.log")],
                    capture_output=True, text=True, timeout=5,
                )
                if result.stdout:
                    log_text = result.stdout[-3900:]
                    self.send_message(chat_id, f"Recent logs:\n\n{log_text}", parse_mode="")
                else:
                    # Try capturing from logger
                    self.send_message(chat_id, "No log file found. Logs go to stdout.", parse_mode="")
            except Exception as e:
                self.send_message(chat_id, f"Log error: {e}", parse_mode="")

        elif cmd == "/budget":
            if args:
                try:
                    limit = float(args)
                    self.memory.kv_set(f"budget_{user_id}", str(limit))
                    self.send_message(chat_id, f"Daily budget set: ${limit:.2f}", parse_mode="")
                except ValueError:
                    self.send_message(chat_id, "Usage: /budget <amount>\nExample: /budget 5.00", parse_mode="")
            else:
                budget = self.memory.kv_get(f"budget_{user_id}")
                try:
                    from tools.usage import get_usage_stats
                    stats = get_usage_stats()
                    today_cost = stats["today"]["cost_usd"]
                except Exception:
                    today_cost = 0
                if budget:
                    self.send_message(chat_id, f"Daily budget: ${float(budget):.2f}\nSpent today: ${today_cost:.4f}\nRemaining: ${float(budget) - today_cost:.4f}", parse_mode="")
                else:
                    self.send_message(chat_id, f"No budget set. Spent today: ${today_cost:.4f}\n\nSet with: /budget <amount>", parse_mode="")

        elif cmd == "/template":
            templates_dir = Path.home() / ".seraph" / "templates"
            templates_dir.mkdir(parents=True, exist_ok=True)
            if not args:
                templates = list(templates_dir.glob("*.md"))
                if templates:
                    msg = "Prompt templates:\n\n"
                    for t in templates:
                        msg += f"  {t.stem}\n"
                    msg += "\nUsage: /template <name> [args]"
                    self.send_message(chat_id, msg, parse_mode="")
                else:
                    self.send_message(chat_id, "No templates. Create .md files in ~/.seraph/templates/", parse_mode="")
            else:
                parts = args.split(" ", 1)
                tpl_name = parts[0]
                tpl_args = parts[1] if len(parts) > 1 else ""
                tpl_file = templates_dir / f"{tpl_name}.md"
                if tpl_file.exists():
                    template = tpl_file.read_text()
                    if tpl_args:
                        template = template.replace("{{input}}", tpl_args)
                    self.process_message(chat_id, user_id, template, first_name)
                else:
                    self.send_message(chat_id, f"Template not found: {tpl_name}", parse_mode="")

        elif cmd == "/id":
            self.send_message(chat_id, f"Your Telegram ID: {user_id}\nChat ID: {chat_id}", parse_mode="")

        else:
            self.send_message(chat_id, f"Unknown command: {cmd}\nType /help for commands", parse_mode="")

    def _shutdown(self):
        """Graceful shutdown — flush memory, save state."""
        logger.info("Shutting down gracefully...")
        try:
            # Flush all conversations to memory
            for chat_id, history in self.conversations.items():
                session_key = f"chat_{chat_id}"
                for msg in history[-5:]:  # Save last 5 unsaved
                    pass  # Already saved during process_message
            # Close memory database
            if hasattr(self, 'memory') and self.memory:
                self.memory.close()
                logger.info("Memory database closed")
        except Exception as e:
            logger.error(f"Shutdown error: {e}")
        logger.info("Shutdown complete")

    def run(self):
        """Main polling loop."""
        # Register shutdown handlers
        signal.signal(signal.SIGINT, lambda s, f: self._shutdown())
        signal.signal(signal.SIGTERM, lambda s, f: self._shutdown())
        atexit.register(self._shutdown)

        # Verify token
        me = self._api_call("getMe")
        if not me.get("ok"):
            logger.error("Invalid bot token!")
            return

        bot_info = me["result"]
        logger.info(f"Bot: @{bot_info['username']} (ID: {bot_info['id']})")

        # Heartbeat monitor (off by default — enable with /heartbeat on)
        self.heartbeat = get_heartbeat(self)

        # Wire cron executor for self-improvement jobs
        def _cron_executor(command):
            if command == "self_improve":
                try:
                    results = run_improvement_cycle(self.memory, self.llm)
                    logger.info(f"Cron self-improve: {results}")
                    return results
                except Exception as e:
                    logger.error(f"Cron self-improve failed: {e}")
                    return {"error": str(e)}
            else:
                return _run_tool("terminal", {"command": command})

        scheduler = get_scheduler()
        scheduler.executor = _cron_executor

        print(f"\n{'='*50}")
        print(f"  SERAPH TELEGRAM BOT")
        print(f"  Bot: @{bot_info['username']}")
        print(f"  Model: {self.llm.model if self.llm else 'not connected'}")
        print(f"  Heartbeat: every 60s")
        print(f"  Status: Running")
        print(f"{'='*50}\n")

        # Polling loop
        error_count = 0
        while True:
            try:
                updates = self.get_updates()
                error_count = 0  # Reset on success
                for update in updates:
                    # Handle callback queries (inline button presses)
                    if "callback_query" in update:
                        cb = update["callback_query"]
                        cb_id = cb["id"]
                        cb_data = cb.get("data", "")
                        cb_chat = cb.get("message", {}).get("chat", {}).get("id", 0)
                        cb_user = cb.get("from", {}).get("id", 0)
                        cb_name = cb.get("from", {}).get("first_name", "")
                        self.answer_callback(cb_id, cb_data)
                        if cb_data.startswith("cmd_"):
                            self._handle_command(cb_chat, f"/{cb_data[4:]}", cb_user)
                        elif cb_data:
                            self.process_message(cb_chat, cb_user, cb_data, cb_name)
                        continue

                    msg = update.get("message", {})
                    if not msg:
                        continue

                    chat_id = msg["chat"]["id"]
                    user_id = msg["from"]["id"]
                    first_name = msg["from"].get("first_name", "")
                    msg_id = msg.get("message_id", 0)
                    self._last_user_msg_id = msg_id

                    # Forum topic support — extract thread_id for session routing
                    thread_id = msg.get("message_thread_id")
                    if self.forum_topics and thread_id:
                        session_key = self.forum_topics.get_session_key(chat_id, thread_id)
                    else:
                        session_key = f"chat_{chat_id}"

                    # Track message in telemetry
                    if self.telemetry:
                        self.telemetry.track_message("telegram", "inbound")

                    # Handle stickers — describe with vision
                    if "sticker" in msg:
                        try:
                            from channels.telegram_features import handle_sticker
                            description = handle_sticker(self._api_call, self.token, msg)
                            if description:
                                self.process_message(chat_id, user_id, description, first_name)
                        except Exception as e:
                            logger.debug(f"Sticker handling: {e}")
                        continue

                    # Handle text messages
                    if "text" in msg:
                        text = msg["text"]
                        chat_type = msg["chat"].get("type", "private")

                        # Group chat: only respond to @mentions or replies to bot
                        if chat_type in ("group", "supergroup"):
                            bot_username = bot_info.get("username", "")
                            is_mention = f"@{bot_username}" in text
                            is_reply = msg.get("reply_to_message", {}).get("from", {}).get("id") == bot_info.get("id")
                            if not is_mention and not is_reply:
                                continue  # Ignore non-directed group messages
                            text = text.replace(f"@{bot_username}", "").strip()

                        logger.info(f"Message from {first_name} ({user_id}): {text[:50]}")
                        self.process_message(chat_id, user_id, text, first_name)

                    # Handle voice messages — transcribe then process
                    elif "voice" in msg or "audio" in msg:
                        voice = msg.get("voice") or msg.get("audio")
                        file_id = voice.get("file_id", "")
                        if file_id:
                            logger.info(f"Voice from {first_name} ({user_id})")
                            self.send_typing(chat_id)
                            text = self._handle_voice(chat_id, file_id)
                            if text:
                                self.send_message(chat_id, f"🎤 Heard: {text[:200]}", parse_mode="")
                                self.process_message(chat_id, user_id, text, first_name)

                    # Handle photos -- download and analyze with vision
                    elif "photo" in msg:
                        photos = msg["photo"]
                        file_id = photos[-1]["file_id"]
                        caption = msg.get("caption", "What is in this image?")
                        logger.info(f"Photo from {first_name} ({user_id})")
                        self.send_typing(chat_id)
                        saved = self._download_telegram_file(file_id, f"photo_{int(time.time())}.jpg")
                        if saved:
                            result = _run_tool("describe_image", {"image_path": saved, "question": caption})
                            description = result.get("description", "Could not analyze image.")
                            self.send_message(chat_id, description, parse_mode="")
                            if caption != "What is in this image?":
                                self.process_message(chat_id, user_id, f"[Image: {description[:200]}] {caption}", first_name)
                        else:
                            self.send_message(chat_id, "Failed to download image.", parse_mode="")

                    # Handle documents — download, save, read into context
                    elif "document" in msg:
                        doc = msg["document"]
                        filename = doc.get("file_name", "unknown")
                        file_id = doc.get("file_id", "")
                        file_size = doc.get("file_size", 0)
                        caption = msg.get("caption", "")
                        logger.info(f"Document from {first_name}: {filename} ({file_size} bytes)")

                        # Skip files over 10MB
                        if file_size > 10 * 1024 * 1024:
                            self.send_message(chat_id, f"File too large: {filename} ({file_size // 1024 // 1024}MB). Max 10MB.", parse_mode="")
                        elif file_id:
                            self.send_typing(chat_id)
                            saved = self._download_telegram_file(file_id, filename)
                            if saved:
                                # Try to read text content for context injection
                                content_preview = ""
                                try:
                                    text_extensions = {".py", ".js", ".ts", ".json", ".md", ".txt", ".csv", ".yaml", ".yml", ".html", ".css", ".sh", ".env", ".toml", ".cfg", ".ini", ".xml", ".sql", ".log"}
                                    from pathlib import Path
                                    ext = Path(filename).suffix.lower()
                                    if ext in text_extensions:
                                        content = Path(saved).read_text(encoding="utf-8", errors="replace")
                                        content_preview = content[:3000]
                                except Exception:
                                    pass

                                if content_preview and caption:
                                    # Inject file content + caption into conversation
                                    self.process_message(chat_id, user_id, f"[File: {filename}]\n```\n{content_preview}\n```\n\n{caption}", first_name)
                                elif content_preview:
                                    self.process_message(chat_id, user_id, f"[File: {filename}]\n```\n{content_preview}\n```\n\nAnalyze this file.", first_name)
                                else:
                                    self.send_message(chat_id, f"Saved: {filename}\nPath: {saved}\n\nUse /read {saved} to view it.", parse_mode="")
                            else:
                                self.send_message(chat_id, f"Failed to download: {filename}", parse_mode="")

            except KeyboardInterrupt:
                self._shutdown()
                break
            except Exception as e:
                logger.error(f"Polling error: {e}")
                if hasattr(self, 'heartbeat'):
                    self.heartbeat.record_error(str(e))
                # Exponential backoff: 5s, 10s, 20s, 40s, max 60s
                backoff = min(60, 5 * (2 ** min(error_count, 4)))
                error_count += 1
                logger.info(f"Reconnecting in {backoff}s (attempt {error_count})...")
                time.sleep(backoff)
                if error_count > 20:
                    logger.error("Too many errors, shutting down")
                    self._shutdown()
                    break


def main():
    """Entry point."""
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    )

    token = os.environ.get("SERAPH_TELEGRAM_TOKEN", "")
    if not token:
        print("Set SERAPH_TELEGRAM_TOKEN environment variable")
        print("Get a token from @BotFather on Telegram")
        return

    # Optional: restrict to specific user IDs
    allowed = os.environ.get("SERAPH_ALLOWED_USERS", "")
    allowed_users = [int(x.strip()) for x in allowed.split(",") if x.strip()] if allowed else []

    bot = SeraphTelegramBot(token=token, allowed_users=allowed_users)
    bot.run()


if __name__ == "__main__":
    main()
