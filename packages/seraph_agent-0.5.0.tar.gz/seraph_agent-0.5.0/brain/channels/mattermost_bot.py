"""
Seraph Mattermost Channel -- WebSocket event stream + REST API.
"""

import os
import json
import time
import logging
import threading
import requests

logger = logging.getLogger("seraph.mattermost")
from channels.base import ChannelBase


class SeraphMattermostBot(ChannelBase):
    CHANNEL_NAME = "mattermost"
    MAX_MESSAGE_LENGTH = 16383

    def __init__(self, allowed_users=None):
        super().__init__(allowed_users=allowed_users)
        self.url = os.environ.get("SERAPH_MATTERMOST_URL", "").rstrip("/")
        self.token = os.environ.get("SERAPH_MATTERMOST_TOKEN", "")
        self.bot_user_id = ""

    def send_message(self, chat_id, text, **kwargs):
        try:
            requests.post(f"{self.url}/api/v4/posts",
                headers={"Authorization": f"Bearer {self.token}"},
                json={"channel_id": chat_id, "message": text},
                timeout=10)
        except Exception as e:
            logger.error(f"Mattermost send: {e}")

    def run(self):
        if not self.url or not self.token:
            logger.error("Set SERAPH_MATTERMOST_URL and SERAPH_MATTERMOST_TOKEN")
            return

        # Get bot user ID
        try:
            resp = requests.get(f"{self.url}/api/v4/users/me",
                headers={"Authorization": f"Bearer {self.token}"}, timeout=10)
            if resp.status_code == 200:
                self.bot_user_id = resp.json().get("id", "")
        except Exception:
            pass

        logger.info(f"Mattermost: connecting to {self.url}")
        ws_url = self.url.replace("https://", "wss://").replace("http://", "ws://")

        while True:
            try:
                import websocket
                def on_message(ws, message):
                    try:
                        data = json.loads(message)
                        event = data.get("event", "")
                        if event == "posted":
                            post = json.loads(data.get("data", {}).get("post", "{}"))
                            user_id = post.get("user_id", "")
                            if user_id == self.bot_user_id:
                                return
                            text = post.get("message", "")
                            channel_id = post.get("channel_id", "")
                            if text:
                                self.process_message(channel_id, user_id, text)
                    except Exception:
                        pass

                ws = websocket.WebSocketApp(
                    f"{ws_url}/api/v4/websocket",
                    header={"Authorization": f"Bearer {self.token}"},
                    on_message=on_message)
                ws.run_forever()
            except ImportError:
                logger.error("pip install websocket-client for Mattermost")
                return
            except Exception as e:
                logger.error(f"Mattermost WS: {e}")
                time.sleep(10)


def start_mattermost_bot():
    bot = SeraphMattermostBot()
    threading.Thread(target=bot.run, daemon=True).start()
    return True
