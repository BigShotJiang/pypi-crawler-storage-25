"""
Seraph Email Channel -- IMAP polling for inbound, SMTP for outbound.
"""

import os
import imaplib
import smtplib
import email
import time
import logging
import threading
from email.mime.text import MIMEText

logger = logging.getLogger("seraph.email")
from channels.base import ChannelBase


class SeraphEmailBot(ChannelBase):
    CHANNEL_NAME = "email"
    MAX_MESSAGE_LENGTH = 1000000

    def __init__(self, allowed_users=None):
        super().__init__(allowed_users=allowed_users)
        self.imap_host = os.environ.get("SERAPH_IMAP_HOST", "")
        self.imap_port = int(os.environ.get("SERAPH_IMAP_PORT", "993"))
        self.smtp_host = os.environ.get("SERAPH_SMTP_HOST", "")
        self.smtp_port = int(os.environ.get("SERAPH_SMTP_PORT", "587"))
        self.email_user = os.environ.get("SERAPH_EMAIL_USER", "")
        self.email_pass = os.environ.get("SERAPH_EMAIL_PASS", "")

    def send_message(self, chat_id, text, **kwargs):
        try:
            msg = MIMEText(text)
            msg["Subject"] = kwargs.get("subject", "Seraph")
            msg["From"] = self.email_user
            msg["To"] = chat_id
            with smtplib.SMTP(self.smtp_host, self.smtp_port) as server:
                server.starttls()
                server.login(self.email_user, self.email_pass)
                server.send_message(msg)
        except Exception as e:
            logger.error(f"Email send: {e}")

    def run(self):
        if not self.imap_host or not self.email_user:
            logger.error("Set SERAPH_IMAP_HOST, SERAPH_EMAIL_USER, SERAPH_EMAIL_PASS")
            return
        logger.info(f"Email: polling {self.imap_host} as {self.email_user}")
        while True:
            try:
                mail = imaplib.IMAP4_SSL(self.imap_host, self.imap_port)
                mail.login(self.email_user, self.email_pass)
                mail.select("INBOX")
                _, data = mail.search(None, "UNSEEN")
                for num in data[0].split():
                    _, msg_data = mail.fetch(num, "(RFC822)")
                    raw = email.message_from_bytes(msg_data[0][1])
                    sender = email.utils.parseaddr(raw["From"])[1]
                    subject = raw.get("Subject", "")
                    body = ""
                    if raw.is_multipart():
                        for part in raw.walk():
                            if part.get_content_type() == "text/plain":
                                body = part.get_payload(decode=True).decode("utf-8", errors="replace")
                                break
                    else:
                        body = raw.get_payload(decode=True).decode("utf-8", errors="replace")
                    if body and sender:
                        text = f"[Subject: {subject}]\n{body[:5000]}" if subject else body[:5000]
                        self.process_message(sender, sender, text)
                    mail.store(num, "+FLAGS", "\\Seen")
                mail.logout()
            except Exception as e:
                logger.error(f"Email poll: {e}")
            time.sleep(30)


def start_email_bot():
    bot = SeraphEmailBot()
    threading.Thread(target=bot.run, daemon=True).start()
    return True
