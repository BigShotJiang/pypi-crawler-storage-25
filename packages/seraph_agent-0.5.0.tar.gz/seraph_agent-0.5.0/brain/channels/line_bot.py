"""
Seraph LINE Channel -- webhook handler for LINE Messaging API.
"""

import os
import json
import logging
import threading
import requests
from http.server import HTTPServer, BaseHTTPRequestHandler

logger = logging.getLogger("seraph.line")
from channels.base import ChannelBase


class SeraphLineBot(ChannelBase):
    CHANNEL_NAME = "line"
    MAX_MESSAGE_LENGTH = 5000

    def __init__(self, allowed_users=None):
        super().__init__(allowed_users=allowed_users)
        self.token = os.environ.get("SERAPH_LINE_TOKEN", "")
        self.secret = os.environ.get("SERAPH_LINE_SECRET", "")

    def send_message(self, chat_id, text, **kwargs):
        try:
            requests.post("https://api.line.me/v2/bot/message/push",
                headers={"Authorization": f"Bearer {self.token}",
                         "Content-Type": "application/json"},
                json={"to": chat_id, "messages": [{"type": "text", "text": text[:5000]}]},
                timeout=10)
        except Exception as e:
            logger.error(f"LINE send: {e}")

    def handle_webhook(self, body):
        data = json.loads(body) if isinstance(body, (str, bytes)) else body
        for event in data.get("events", []):
            if event.get("type") == "message" and event.get("message", {}).get("type") == "text":
                text = event["message"]["text"]
                user_id = event.get("source", {}).get("userId", "")
                reply_token = event.get("replyToken", "")
                if text and user_id:
                    self.process_message(user_id, user_id, text)
        return {"ok": True}

    def run(self):
        if not self.token:
            logger.error("Set SERAPH_LINE_TOKEN and SERAPH_LINE_SECRET")
            return
        port = int(os.environ.get("SERAPH_LINE_PORT", "3980"))
        bot = self

        class Handler(BaseHTTPRequestHandler):
            def do_POST(self):
                length = int(self.headers.get("Content-Length", 0))
                body = self.rfile.read(length)
                result = bot.handle_webhook(body)
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps(result).encode())

            def log_message(self, *args):
                pass

        server = HTTPServer(("0.0.0.0", port), Handler)
        logger.info(f"LINE webhook on port {port}")
        server.serve_forever()


def start_line_bot():
    bot = SeraphLineBot()
    threading.Thread(target=bot.run, daemon=True).start()
    return True
