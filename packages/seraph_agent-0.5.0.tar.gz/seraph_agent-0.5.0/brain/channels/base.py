"""
Seraph Channel Base  --  shared logic for ALL channel adapters.

Every channel (Telegram, Discord, Slack, IRC, Matrix, etc.) needs the same core:
1. LLM integration with failover
2. Tool execution loop
3. Conversation history (in-memory + persistent)
4. Memory (active + archive)
5. Rate limiting
6. Compaction (context overflow)

This base class provides all of that. Channel adapters just implement:
- send_message(chat_id, text)  --  how to deliver a response
- send_typing(chat_id)  --  how to show typing indicator
- get_updates()  --  how to receive new messages (polling channels)
- or handle_webhook(data)  --  how to receive via webhook

That's it. The brain logic is identical across all channels.
"""

import os
import sys
import json
import time
import asyncio
import logging
from typing import Dict, List, Optional, Any, Callable
from pathlib import Path

logger = logging.getLogger("seraph.channel.base")

# Add brain to path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from agent.llm import LLMProvider, LLMResponse
from tools.registry import get_openai_tool_schemas, execute_tool
from tools.filter import filter_tools
from agent.context_manager import should_compress, auto_compress
from agent.prompt_compiler import compile_prompt, estimate_conversation_tokens
from agent.loop_detection import LoopDetector
from memory.store import get_memory


def _run_tool(name: str, args: dict):
    """Sync wrapper for async tool execution."""
    try:
        loop = asyncio.new_event_loop()
        result = loop.run_until_complete(execute_tool(name, args))
        loop.close()
        return result
    except Exception as e:
        return {"error": str(e)}


class ChannelBase:
    """
    Base class for all channel adapters.

    Provides the full agent loop  --  LLM calls, tool execution, memory,
    rate limiting, compaction, failover. Subclasses just implement
    message delivery and receiving.
    """

    CHANNEL_NAME = "base"  # Override in subclass
    MAX_MESSAGE_LENGTH = 4096  # Override per platform
    RATE_LIMIT_MAX = 20
    RATE_LIMIT_WINDOW = 60

    def __init__(self, allowed_users: list = None):
        self.allowed_users = allowed_users or []
        self.conversations: Dict[str, List[Dict]] = {}  # chat_id -> history
        self.rate_limits: Dict[str, List[float]] = {}
        self.identity = ""
        self.llm: Optional[LLMProvider] = None
        self.memory = get_memory()

        # Load identity
        soul_path = Path.home() / ".seraph" / "SOUL.md"
        if soul_path.exists():
            self.identity = soul_path.read_text()
        else:
            self.identity = "You are Seraph, a self-improving AI agent."

        # Initialize LLM
        try:
            provider = os.environ.get("SERAPH_PROVIDER", "anthropic")
            model = os.environ.get("SERAPH_MODEL", "claude-sonnet-4-6")
            self.llm = LLMProvider(provider=provider, model=model)
        except Exception as e:
            logger.error(f"[{self.CHANNEL_NAME}] LLM init failed: {e}")

        # Failover
        try:
            from agent.failover import AuthProfileStore
            from models.router import ModelRouter
            self.model_router = ModelRouter(default_model=os.environ.get("SERAPH_MODEL", "claude-sonnet-4-6"))
            self.failover_chain = self.model_router.get_failover_chain(self.model_router.default_model).models
        except Exception:
            self.model_router = None
            self.failover_chain = []

        # Telemetry
        try:
            from diagnostics.telemetry import get_telemetry
            self.telemetry = get_telemetry()
        except Exception:
            self.telemetry = None

    # ─── Methods to Override ──────────────────────────────────────

    def send_message(self, chat_id: str, text: str, **kwargs):
        """Send a message. Override in subclass."""
        raise NotImplementedError

    def send_typing(self, chat_id: str):
        """Show typing indicator. Override in subclass."""
        pass

    def chunk_message(self, text: str) -> List[str]:
        """Split long messages for this platform."""
        if len(text) <= self.MAX_MESSAGE_LENGTH:
            return [text]
        chunks = []
        while text:
            if len(text) <= self.MAX_MESSAGE_LENGTH:
                chunks.append(text)
                break
            split = text.rfind("\n", 0, self.MAX_MESSAGE_LENGTH - 100)
            if split == -1 or split < self.MAX_MESSAGE_LENGTH // 2:
                split = text.rfind(" ", 0, self.MAX_MESSAGE_LENGTH - 100)
            if split == -1:
                split = self.MAX_MESSAGE_LENGTH - 100
            chunks.append(text[:split])
            text = text[split:].lstrip()
        return chunks

    # ─── Auth + Rate Limiting ─────────────────────────────────────

    def is_authorized(self, user_id: str) -> bool:
        """Check if user is allowed."""
        if not self.allowed_users:
            return True
        return user_id in [str(u) for u in self.allowed_users]

    def check_rate_limit(self, user_id: str) -> bool:
        """Returns True if rate limited (should block)."""
        now = time.time()
        if user_id not in self.rate_limits:
            self.rate_limits[user_id] = []
        self.rate_limits[user_id] = [
            t for t in self.rate_limits[user_id]
            if now - t < self.RATE_LIMIT_WINDOW
        ]
        if len(self.rate_limits[user_id]) >= self.RATE_LIMIT_MAX:
            return True
        self.rate_limits[user_id].append(now)
        return False

    # ─── Core Agent Loop ──────────────────────────────────────────

    def process_message(self, chat_id: str, user_id: str, text: str, **kwargs):
        """
        Process a message through the core agent.

        Uses agent/core.py as the SINGLE brain -- no duplicated logic.
        """
        if not self.is_authorized(user_id):
            self.send_message(chat_id, "Not authorized.")
            return

        if self.check_rate_limit(user_id):
            self.send_message(chat_id, f"Rate limited. Max {self.RATE_LIMIT_MAX}/min.")
            return

        # Use the core agent
        try:
            from agent.core import get_agent
            agent = get_agent()
            session_key = f"{self.CHANNEL_NAME}_{chat_id}"
            response = agent.process(text, user_id=user_id, session_key=session_key,
                                     channel=self.CHANNEL_NAME)
            if response.text:
                for chunk in self.chunk_message(response.text):
                    self.send_message(chat_id, chunk)
            return
        except Exception as e:
            logger.warning(f"Core agent fallback: {e}")

        # Fallback: direct LLM call if core agent fails

        if not self.llm:
            self.send_message(chat_id, "LLM not connected. Check API keys.")
            return

        # Track telemetry
        if self.telemetry:
            self.telemetry.track_message(self.CHANNEL_NAME, "inbound")

        self.send_typing(chat_id)

        # Get/create conversation history
        if chat_id not in self.conversations:
            session_key = f"{self.CHANNEL_NAME}_{chat_id}"
            saved = self.memory.get_session_history(session_key, limit=20)
            if saved:
                self.conversations[chat_id] = [
                    {"role": m["role"], "content": m["content"]} for m in saved
                ]
            else:
                self.conversations[chat_id] = []

        history = self.conversations[chat_id]
        history.append({"role": "user", "content": text})

        # Save to memory
        session_key = f"{self.CHANNEL_NAME}_{chat_id}"
        self.memory.save_message(session_key, user_id, "user", text)

        # Auto-compress
        if should_compress(history):
            history = auto_compress(history, llm=self.llm, target_messages=15)
            self.conversations[chat_id] = history
        elif len(history) > 30:
            history = history[-20:]
            self.conversations[chat_id] = history

        # Build prompt
        conv_tokens = estimate_conversation_tokens(history)
        if len(history) <= 2:
            full_identity = compile_prompt(identity=self.identity, conversation_tokens=conv_tokens)
        else:
            active_mem = self.memory.format_active_for_prompt()
            user_profile = self.memory.format_user_for_prompt(user_id)
            full_identity = compile_prompt(
                identity=self.identity,
                active_memory=active_mem,
                user_profile=user_profile,
                conversation_tokens=conv_tokens,
            )

        # Tool loop with failover
        try:
            all_tools = get_openai_tool_schemas()
            tools = filter_tools(text, all_tools)
            loop_detector = LoopDetector()

            for iteration in range(10):
                self.send_typing(chat_id)

                # LLM call with failover
                call_start = time.time()
                try:
                    response = self.llm.chat(
                        messages=history,
                        system=full_identity,
                        tools=tools if tools else None,
                    )
                except Exception as llm_err:
                    response = self._try_failover(history, full_identity, tools, llm_err)
                    if response is None:
                        raise llm_err

                call_ms = int((time.time() - call_start) * 1000)
                if self.telemetry:
                    self.telemetry.track_llm_call(
                        self.llm.provider, self.llm.model,
                        response.input_tokens, response.output_tokens, call_ms,
                    )
                if self.model_router:
                    self.model_router.track_usage(self.llm.model, response.input_tokens, response.output_tokens)

                # No tool calls  --  final response
                if not response.tool_calls:
                    if response.text:
                        history.append({"role": "assistant", "content": response.text})
                        for chunk in self.chunk_message(response.text):
                            self.send_message(chat_id, chunk)
                        self.memory.save_message(
                            session_key, chat_id, "assistant", response.text, response.output_tokens
                        )
                    break

                # Tool calls
                tool_call_msg = {
                    "role": "assistant",
                    "content": response.text or None,
                    "tool_calls": [
                        {
                            "id": tc["id"], "type": "function",
                            "function": {"name": tc["name"], "arguments": json.dumps(tc["arguments"])},
                        }
                        for tc in response.tool_calls
                    ],
                }
                history.append(tool_call_msg)

                for tc in response.tool_calls:
                    tool_start = time.time()
                    result = _run_tool(tc["name"], tc["arguments"])
                    tool_ms = int((time.time() - tool_start) * 1000)

                    if self.telemetry:
                        self.telemetry.track_tool_call(tc["name"], tool_ms, "error" not in result)

                    # Loop detection
                    loop_check = loop_detector.record(tc["name"], tc["arguments"], result)
                    if loop_check["action"] == "break":
                        self.send_message(chat_id, f"Stopped: {loop_check['reason']}")
                        break

                    result_str = json.dumps(result, default=str)
                    if len(result_str) > 5000:
                        result_str = result_str[:5000] + "...(truncated)"

                    history.append({
                        "role": "tool",
                        "tool_call_id": tc["id"],
                        "content": result_str,
                    })

        except Exception as e:
            logger.error(f"[{self.CHANNEL_NAME}] Error: {e}")
            self.send_message(chat_id, "Something went wrong. Try again.")

    def _try_failover(self, history, system, tools, original_error) -> Optional[LLMResponse]:
        """Try fallback models if primary fails."""
        if not self.failover_chain:
            return None
        for model_id in self.failover_chain:
            if model_id == self.llm.model:
                continue
            try:
                from agent.llm import get_provider_for_model
                provider = get_provider_for_model(model_id) or self.llm.provider
                fb = LLMProvider(provider=provider, model=model_id)
                response = fb.chat(messages=history, system=system, tools=tools if tools else None)
                logger.info(f"[{self.CHANNEL_NAME}] Failover to {model_id} succeeded")
                return response
            except Exception:
                continue
        return None

    def clear_conversation(self, chat_id: str):
        """Clear a conversation."""
        self.conversations.pop(chat_id, None)
