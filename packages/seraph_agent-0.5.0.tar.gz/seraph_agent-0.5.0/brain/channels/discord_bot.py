"""
Seraph Discord Channel — connects to Discord via bot gateway.

Runs alongside the Telegram bot. Same brain, different channel.
"""

import os
import asyncio
import json
import time
import logging
import requests
import threading
import websocket
from typing import Optional
from pathlib import Path

logger = logging.getLogger("seraph.discord")

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from agent.llm import LLMProvider
from tools.registry import get_all_tools, get_openai_tool_schemas, execute_tool
from memory.store import get_memory

DISCORD_API = "https://discord.com/api/v10"


class SeraphDiscordBot:
    """Discord bot using gateway WebSocket."""

    def __init__(self, token: str, allowed_users: list = None):
        self.token = token
        self.allowed_users = allowed_users or []
        self.conversations = {}
        self.llm = None
        self.identity = ""
        self.memory = get_memory()
        self.heartbeat_interval = 41250
        self.sequence = None
        self.session_id = None
        self.bot_user_id = None

        # Load identity
        seraph_dir = Path.home() / ".seraph"
        soul_path = seraph_dir / "SOUL.md"
        if soul_path.exists():
            self.identity = soul_path.read_text()

        # Initialize LLM
        try:
            self.llm = LLMProvider(
                provider=os.environ.get("SERAPH_PROVIDER", "openai"),
                model=os.environ.get("SERAPH_MODEL", "gpt-5.4"),
            )
            logger.info("Discord LLM provider connected")
        except Exception as e:
            logger.error(f"Failed to initialize LLM for Discord: {e}")

    def _api_call(self, method: str, endpoint: str, data: dict = None) -> dict:
        """Call Discord REST API."""
        url = f"{DISCORD_API}{endpoint}"
        headers = {
            "Authorization": f"Bot {self.token}",
            "Content-Type": "application/json",
        }
        try:
            if method == "GET":
                resp = requests.get(url, headers=headers, timeout=10)
            elif method == "POST":
                resp = requests.post(url, headers=headers, json=data, timeout=10)
            else:
                return {"error": f"Unknown method: {method}"}

            if resp.status_code in (200, 201, 204):
                return resp.json() if resp.text else {}
            else:
                logger.error(f"Discord API {resp.status_code}: {resp.text[:200]}")
                return {"error": f"HTTP {resp.status_code}"}
        except Exception as e:
            logger.error(f"Discord API error: {e}")
            return {"error": str(e)}

    def send_message(self, channel_id: str, content: str):
        """Send a message to a Discord channel."""
        # Discord message limit is 2000 chars
        if len(content) > 2000:
            chunks = [content[i:i+1900] for i in range(0, len(content), 1900)]
            for chunk in chunks:
                self._api_call("POST", f"/channels/{channel_id}/messages", {"content": chunk})
                time.sleep(0.5)
        else:
            self._api_call("POST", f"/channels/{channel_id}/messages", {"content": content})

    def send_typing(self, channel_id: str):
        """Show typing indicator."""
        self._api_call("POST", f"/channels/{channel_id}/typing")

    def process_message(self, channel_id: str, user_id: str, content: str, username: str = ""):
        """Process a Discord message through the LLM."""
        if self.allowed_users and user_id not in self.allowed_users:
            return

        if not self.llm:
            self.send_message(channel_id, "LLM not connected.")
            return

        # Handle commands
        if content.startswith("/"):
            self._handle_command(channel_id, content)
            return

        self.send_typing(channel_id)

        # Get conversation history
        if channel_id not in self.conversations:
            session_key = f"discord_{channel_id}"
            saved = self.memory.get_session_history(session_key, limit=20)
            if saved:
                self.conversations[channel_id] = [{"role": m["role"], "content": m["content"]} for m in saved]
            else:
                self.conversations[channel_id] = []

        history = self.conversations[channel_id]
        history.append({"role": "user", "content": content})

        # Save to memory
        session_key = f"discord_{channel_id}"
        self.memory.save_message(session_key, channel_id, "user", content)

        if len(history) > 20:
            history = history[-20:]
            self.conversations[channel_id] = history

        # Build prompt with memory
        active_mem = self.memory.format_active_for_prompt()
        full_identity = self.identity
        if active_mem:
            full_identity += "\n\n" + active_mem

        try:
            tools = get_openai_tool_schemas()

            for iteration in range(10):
                self.send_typing(channel_id)

                response = self.llm.chat(
                    messages=history,
                    system=full_identity,
                    tools=tools if tools else None,
                )

                if not response.tool_calls:
                    if response.text:
                        history.append({"role": "assistant", "content": response.text})
                        self.send_message(channel_id, response.text)
                        self.memory.save_message(session_key, channel_id, "assistant", response.text)
                    break

                # Handle tool calls
                tool_call_msg = {
                    "role": "assistant",
                    "content": response.text or None,
                    "tool_calls": [
                        {
                            "id": tc["id"],
                            "type": "function",
                            "function": {
                                "name": tc["name"],
                                "arguments": json.dumps(tc["arguments"]),
                            }
                        }
                        for tc in response.tool_calls
                    ]
                }
                history.append(tool_call_msg)

                for tc in response.tool_calls:
                    loop = asyncio.new_event_loop()
                    result = loop.run_until_complete(execute_tool(tc["name"], tc["arguments"]))
                    loop.close()

                    result_str = json.dumps(result, default=str)[:5000]
                    history.append({
                        "role": "tool",
                        "tool_call_id": tc["id"],
                        "content": result_str,
                    })

            logger.info(f"Discord {channel_id}: processed message from {username}")

        except Exception as e:
            logger.error(f"Discord message error: {e}")
            self.send_message(channel_id, f"Error: {e}")

    def _handle_command(self, channel_id: str, text: str):
        """Handle Discord slash commands."""
        cmd = text.split()[0].lower()
        args = text[len(cmd):].strip()

        if cmd in ("/new", "/clear"):
            self.conversations.pop(channel_id, None)
            self.send_message(channel_id, "Conversation cleared.")

        elif cmd == "/status":
            model = self.llm.model if self.llm else "none"
            tools = len(get_all_tools())
            self.send_message(channel_id, f"**Seraph Status**\nModel: {model}\nTools: {tools}\nMemory: active")

        elif cmd == "/model":
            if args:
                self.llm.model = args
                self.send_message(channel_id, f"Model changed to: {args}")
            else:
                self.send_message(channel_id, f"Current model: {self.llm.model}")

        elif cmd == "/help":
            self.send_message(channel_id,
                "**Seraph Commands**\n"
                "/new — Fresh conversation\n"
                "/model — View/change model\n"
                "/status — System status\n"
                "/help — This help\n\n"
                "Or just talk to me."
            )
        else:
            self.send_message(channel_id, f"Unknown command: {cmd}")

    def _on_message(self, ws, message):
        """Handle incoming WebSocket messages."""
        try:
            data = json.loads(message)
        except (json.JSONDecodeError, IOError):
            data = {}
        op = data.get("op")
        t = data.get("t")
        d = data.get("d", {})

        if data.get("s"):
            self.sequence = data["s"]

        if op == 10:  # Hello
            self.heartbeat_interval = d.get("heartbeat_interval", 41250)
            # Send identify
            ws.send(json.dumps({
                "op": 2,
                "d": {
                    "token": self.token,
                    "intents": 513,  # GUILDS + GUILD_MESSAGES
                    "properties": {
                        "os": "windows",
                        "browser": "seraph",
                        "device": "seraph",
                    }
                }
            }))
            # Start heartbeat
            threading.Thread(target=self._heartbeat_loop, args=(ws,), daemon=True).start()

        elif op == 11:  # Heartbeat ACK
            pass

        elif t == "READY":
            self.session_id = d.get("session_id")
            user = d.get("user", {})
            self.bot_user_id = user.get("id")
            logger.info(f"Discord connected as {user.get('username')}#{user.get('discriminator')} (ID: {self.bot_user_id})")

        elif t == "MESSAGE_CREATE":
            # Don't respond to own messages
            author = d.get("author", {})
            if author.get("id") == self.bot_user_id:
                return
            if author.get("bot"):
                return

            content = d.get("content", "")
            channel_id = d.get("channel_id", "")
            user_id = author.get("id", "")
            username = author.get("username", "")

            if not content:
                return

            # Check if bot was mentioned or in DM
            is_dm = d.get("guild_id") is None
            mentioned = any(m.get("id") == self.bot_user_id for m in d.get("mentions", []))

            if is_dm or mentioned:
                # Strip mention from content
                if mentioned:
                    content = content.replace(f"<@{self.bot_user_id}>", "").replace(f"<@!{self.bot_user_id}>", "").strip()

                logger.info(f"Discord message from {username}: {content[:50]}")
                threading.Thread(target=self.process_message, args=(channel_id, user_id, content, username), daemon=True).start()

    def _heartbeat_loop(self, ws):
        """Send heartbeats to keep connection alive."""
        while True:
            time.sleep(self.heartbeat_interval / 1000)
            try:
                ws.send(json.dumps({"op": 1, "d": self.sequence}))
            except Exception:
                break

    def _on_error(self, ws, error):
        logger.error(f"Discord WebSocket error: {error}")

    def _on_close(self, ws, code, reason):
        logger.warning(f"Discord WebSocket closed: {code} {reason}")

    def run(self):
        """Connect to Discord gateway and start listening."""
        # Get gateway URL
        resp = requests.get(f"{DISCORD_API}/gateway/bot", headers={
            "Authorization": f"Bot {self.token}"
        }, timeout=10)
        if resp.status_code != 200:
            logger.error(f"Failed to get gateway URL: {resp.text}")
            return

        gateway_url = resp.json().get("url", "wss://gateway.discord.gg") + "/?v=10&encoding=json"

        logger.info(f"Connecting to Discord gateway...")

        ws = websocket.WebSocketApp(
            gateway_url,
            on_message=self._on_message,
            on_error=self._on_error,
            on_close=self._on_close,
        )
        ws.run_forever()


def start_discord_bot():
    """Start Discord bot in a background thread."""
    token = os.environ.get("SERAPH_DISCORD_TOKEN", "")
    if not token:
        logger.info("No SERAPH_DISCORD_TOKEN set — Discord disabled")
        return None

    allowed = os.environ.get("SERAPH_DISCORD_ALLOWED_USERS", "")
    allowed_users = [x.strip() for x in allowed.split(",") if x.strip()] if allowed else []

    bot = SeraphDiscordBot(token=token, allowed_users=allowed_users)
    thread = threading.Thread(target=bot.run, daemon=True)
    thread.start()
    logger.info("Discord bot started in background")
    return bot
