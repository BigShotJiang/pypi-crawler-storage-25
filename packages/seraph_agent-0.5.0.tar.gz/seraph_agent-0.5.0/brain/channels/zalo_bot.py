"""
Seraph Zalo Channel -- Zalo OA (Official Account) API webhook.
"""

import os
import json
import time
import logging
import threading
import requests
from http.server import HTTPServer, BaseHTTPRequestHandler

logger = logging.getLogger("seraph.zalo")
from channels.base import ChannelBase


class SeraphZaloBot(ChannelBase):
    CHANNEL_NAME = "zalo"
    MAX_MESSAGE_LENGTH = 2000

    def __init__(self, allowed_users=None):
        super().__init__(allowed_users=allowed_users)
        self.oa_id = os.environ.get("SERAPH_ZALO_OA_ID", "")
        self.access_token = os.environ.get("SERAPH_ZALO_ACCESS_TOKEN", "")
        self.app_secret = os.environ.get("SERAPH_ZALO_APP_SECRET", "")

    def send_message(self, chat_id, text, **kwargs):
        if not self.access_token:
            return
        try:
            requests.post("https://openapi.zalo.me/v3.0/oa/message/cs",
                headers={"access_token": self.access_token, "Content-Type": "application/json"},
                json={
                    "recipient": {"user_id": chat_id},
                    "message": {"text": text[:2000]},
                }, timeout=10)
        except Exception as e:
            logger.error(f"Zalo send: {e}")

    def handle_webhook(self, body):
        data = json.loads(body) if isinstance(body, (str, bytes)) else body
        event = data.get("event_name", "")
        if event == "user_send_text":
            msg = data.get("message", {})
            text = msg.get("text", "")
            sender = data.get("sender", {}).get("id", "")
            if text and sender:
                self.process_message(sender, sender, text)
        return {"error": 0, "message": "ok"}

    def run(self):
        if not self.access_token:
            logger.error("Set SERAPH_ZALO_OA_ID, SERAPH_ZALO_ACCESS_TOKEN")
            return
        port = int(os.environ.get("SERAPH_ZALO_PORT", "3986"))
        bot = self

        class Handler(BaseHTTPRequestHandler):
            def do_POST(self):
                length = int(self.headers.get("Content-Length", 0))
                body = self.rfile.read(length)
                result = bot.handle_webhook(body)
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps(result).encode())
            def log_message(self, *args): pass

        server = HTTPServer(("0.0.0.0", port), Handler)
        logger.info(f"Zalo OA webhook on port {port}")
        server.serve_forever()


def start_zalo_bot():
    bot = SeraphZaloBot()
    threading.Thread(target=bot.run, daemon=True).start()
    return True
