"""
Seraph Signal Channel -- uses signal-cli for real messaging.
"""

import os
import json
import time
import subprocess
import logging
import threading

logger = logging.getLogger("seraph.signal")
from channels.base import ChannelBase


class SeraphSignalBot(ChannelBase):
    CHANNEL_NAME = "signal"
    MAX_MESSAGE_LENGTH = 4096

    def __init__(self, allowed_users=None):
        super().__init__(allowed_users=allowed_users)
        self.signal_cli = os.environ.get("SERAPH_SIGNAL_CLI", "signal-cli")
        self.phone = os.environ.get("SERAPH_SIGNAL_PHONE", "")

    def send_message(self, chat_id, text, **kwargs):
        try:
            subprocess.run([self.signal_cli, "-u", self.phone, "send", "-m", text, chat_id],
                capture_output=True, timeout=15)
        except Exception as e:
            logger.error(f"Signal send: {e}")

    def run(self):
        if not self.phone:
            logger.error("Set SERAPH_SIGNAL_PHONE and SERAPH_SIGNAL_CLI")
            return
        logger.info(f"Signal: listening on {self.phone}")
        while True:
            try:
                result = subprocess.run(
                    [self.signal_cli, "-u", self.phone, "receive", "--json", "--timeout", "30"],
                    capture_output=True, text=True, timeout=60)
                for line in result.stdout.strip().split("\n"):
                    if not line:
                        continue
                    try:
                        msg = json.loads(line)
                        envelope = msg.get("envelope", {})
                        data = envelope.get("dataMessage", {})
                        text = data.get("message", "")
                        sender = envelope.get("source", "")
                        if text and sender:
                            self.process_message(sender, sender, text)
                    except json.JSONDecodeError:
                        pass
            except subprocess.TimeoutExpired:
                pass
            except Exception as e:
                logger.error(f"Signal receive: {e}")
                time.sleep(5)


def start_signal_bot():
    bot = SeraphSignalBot()
    threading.Thread(target=bot.run, daemon=True).start()
    return True
