"""
Seraph Tlon/Urbit Channel -- connects to an Urbit ship via HTTP API.
"""

import os
import time
import json
import logging
import threading
import requests

logger = logging.getLogger("seraph.tlon")
from channels.base import ChannelBase


class SeraphTlonBot(ChannelBase):
    CHANNEL_NAME = "tlon"
    MAX_MESSAGE_LENGTH = 65536

    def __init__(self, allowed_users=None):
        super().__init__(allowed_users=allowed_users)
        self.ship_url = os.environ.get("SERAPH_URBIT_URL", "http://localhost:8080")
        self.ship_code = os.environ.get("SERAPH_URBIT_CODE", "")
        self.channel = os.environ.get("SERAPH_URBIT_CHANNEL", "")
        self._cookie = ""
        self._event_id = 0

    def _auth(self):
        try:
            resp = requests.post(f"{self.ship_url}/~/login",
                data={"password": self.ship_code}, timeout=10)
            if resp.status_code == 200:
                self._cookie = resp.headers.get("set-cookie", "").split(";")[0]
                return True
        except Exception as e:
            logger.error(f"Urbit auth: {e}")
        return False

    def send_message(self, chat_id, text, **kwargs):
        if not self._cookie:
            self._auth()
        self._event_id += 1
        try:
            requests.put(f"{self.ship_url}/~/channel/seraph-{int(time.time())}",
                headers={"Cookie": self._cookie},
                json=[{
                    "id": self._event_id, "action": "poke",
                    "ship": chat_id, "app": "chat-store",
                    "mark": "chat-action",
                    "json": {"message": {"path": self.channel, "envelope": {
                        "uid": str(int(time.time())), "number": self._event_id,
                        "author": "~seraph", "when": int(time.time() * 1000),
                        "letter": {"text": text[:65536]}
                    }}}
                }], timeout=10)
        except Exception as e:
            logger.error(f"Urbit send: {e}")

    def run(self):
        if not self.ship_code:
            logger.error("Set SERAPH_URBIT_URL, SERAPH_URBIT_CODE, SERAPH_URBIT_CHANNEL")
            return
        if not self._auth():
            return
        logger.info(f"Tlon/Urbit: connected to {self.ship_url}")

        self._event_id += 1
        channel_id = f"seraph-{int(time.time())}"
        try:
            requests.put(f"{self.ship_url}/~/channel/{channel_id}",
                headers={"Cookie": self._cookie},
                json=[{"id": self._event_id, "action": "subscribe",
                       "ship": "~zod", "app": "chat-store", "path": "/mailbox"}],
                timeout=10)
        except Exception:
            pass

        while True:
            try:
                resp = requests.get(f"{self.ship_url}/~/channel/{channel_id}",
                    headers={"Cookie": self._cookie}, stream=True, timeout=60)
                for line in resp.iter_lines():
                    if not line:
                        continue
                    decoded = line.decode("utf-8", errors="replace")
                    if decoded.startswith("data:"):
                        try:
                            data = json.loads(decoded[5:])
                            if data.get("json", {}).get("message"):
                                msg = data["json"]["message"]
                                author = msg.get("envelope", {}).get("author", "")
                                letter = msg.get("envelope", {}).get("letter", {})
                                text = letter.get("text", "")
                                if text and author != "~seraph":
                                    self.process_message(author, author, text)
                        except json.JSONDecodeError:
                            pass
            except Exception as e:
                logger.error(f"Urbit stream: {e}")
                time.sleep(10)
                self._auth()


def start_tlon_bot():
    bot = SeraphTlonBot()
    threading.Thread(target=bot.run, daemon=True).start()
    return True
