"""
Seraph WhatsApp Advanced Features — Business API, media, templates, reactions.

WhatsApp Business API integration via Cloud API.
"""

import json
import time
import logging
import requests
from typing import Dict, List, Optional

logger = logging.getLogger("seraph.whatsapp.features")


# ─── WhatsApp Cloud API ───────────────────────────────────────────

class WhatsAppAPI:
    """WhatsApp Cloud API client."""

    BASE = "https://graph.facebook.com/v20.0"

    def __init__(self, phone_number_id: str, access_token: str):
        self.phone_id = phone_number_id
        self.token = access_token
        self.headers = {
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json",
        }

    def send_text(self, to: str, text: str, reply_to: str = "") -> dict:
        """Send a text message."""
        body = {
            "messaging_product": "whatsapp",
            "to": to,
            "type": "text",
            "text": {"body": text[:4096]},
        }
        if reply_to:
            body["context"] = {"message_id": reply_to}

        return self._post(body)

    def send_reaction(self, to: str, message_id: str, emoji: str) -> dict:
        """React to a message with an emoji."""
        return self._post({
            "messaging_product": "whatsapp",
            "to": to,
            "type": "reaction",
            "reaction": {"message_id": message_id, "emoji": emoji},
        })

    def send_image(self, to: str, image_url: str, caption: str = "") -> dict:
        """Send an image."""
        body = {
            "messaging_product": "whatsapp",
            "to": to,
            "type": "image",
            "image": {"link": image_url},
        }
        if caption:
            body["image"]["caption"] = caption[:1024]
        return self._post(body)

    def send_document(self, to: str, doc_url: str, filename: str, caption: str = "") -> dict:
        """Send a document."""
        body = {
            "messaging_product": "whatsapp",
            "to": to,
            "type": "document",
            "document": {"link": doc_url, "filename": filename},
        }
        if caption:
            body["document"]["caption"] = caption[:1024]
        return self._post(body)

    def send_template(self, to: str, template_name: str, language: str = "en_US",
                      parameters: list = None) -> dict:
        """Send a template message (for initiating conversations)."""
        components = []
        if parameters:
            components.append({
                "type": "body",
                "parameters": [
                    {"type": "text", "text": str(p)} for p in parameters
                ],
            })
        return self._post({
            "messaging_product": "whatsapp",
            "to": to,
            "type": "template",
            "template": {
                "name": template_name,
                "language": {"code": language},
                "components": components,
            },
        })

    def send_interactive_buttons(self, to: str, body_text: str,
                                  buttons: List[Dict]) -> dict:
        """Send interactive button message."""
        return self._post({
            "messaging_product": "whatsapp",
            "to": to,
            "type": "interactive",
            "interactive": {
                "type": "button",
                "body": {"text": body_text[:1024]},
                "action": {
                    "buttons": [
                        {
                            "type": "reply",
                            "reply": {"id": b["id"][:256], "title": b["title"][:20]},
                        }
                        for b in buttons[:3]  # Max 3 buttons
                    ],
                },
            },
        })

    def send_interactive_list(self, to: str, body_text: str, button_text: str,
                               sections: List[Dict]) -> dict:
        """Send interactive list message."""
        return self._post({
            "messaging_product": "whatsapp",
            "to": to,
            "type": "interactive",
            "interactive": {
                "type": "list",
                "body": {"text": body_text[:1024]},
                "action": {
                    "button": button_text[:20],
                    "sections": [
                        {
                            "title": s["title"][:24],
                            "rows": [
                                {
                                    "id": r["id"][:200],
                                    "title": r["title"][:24],
                                    "description": r.get("description", "")[:72],
                                }
                                for r in s.get("rows", [])[:10]
                            ],
                        }
                        for s in sections[:10]
                    ],
                },
            },
        })

    def mark_read(self, message_id: str) -> dict:
        """Mark a message as read."""
        return self._post({
            "messaging_product": "whatsapp",
            "status": "read",
            "message_id": message_id,
        })

    def download_media(self, media_id: str) -> Optional[bytes]:
        """Download media (images, documents, voice) from WhatsApp."""
        try:
            # Get media URL
            resp = requests.get(
                f"{self.BASE}/{media_id}",
                headers=self.headers,
                timeout=10,
            )
            if resp.status_code != 200:
                return None

            media_url = resp.json().get("url", "")
            if not media_url:
                return None

            # Download the actual file
            media_resp = requests.get(
                media_url,
                headers=self.headers,
                timeout=30,
            )
            if media_resp.status_code == 200:
                return media_resp.content
            return None

        except Exception as e:
            logger.error(f"WhatsApp media download error: {e}")
            return None

    def _post(self, body: dict) -> dict:
        """Make a POST request to the WhatsApp Cloud API."""
        try:
            resp = requests.post(
                f"{self.BASE}/{self.phone_id}/messages",
                headers=self.headers,
                json=body,
                timeout=15,
            )
            if resp.status_code in (200, 201):
                return resp.json()
            logger.error(f"WhatsApp API error {resp.status_code}: {resp.text[:200]}")
            return {"error": resp.status_code}
        except Exception as e:
            logger.error(f"WhatsApp API error: {e}")
            return {"error": str(e)}


# ─── Webhook Parsing ──────────────────────────────────────────────

def parse_webhook(body: dict) -> List[Dict]:
    """Parse incoming WhatsApp webhook into normalized messages."""
    messages = []

    for entry in body.get("entry", []):
        for change in entry.get("changes", []):
            value = change.get("value", {})
            wa_messages = value.get("messages", [])

            for msg in wa_messages:
                parsed = {
                    "from": msg.get("from", ""),
                    "message_id": msg.get("id", ""),
                    "timestamp": int(msg.get("timestamp", 0)),
                    "type": msg.get("type", "text"),
                }

                if msg.get("type") == "text":
                    parsed["text"] = msg.get("text", {}).get("body", "")

                elif msg.get("type") == "image":
                    parsed["media_id"] = msg.get("image", {}).get("id", "")
                    parsed["caption"] = msg.get("image", {}).get("caption", "")
                    parsed["mime_type"] = msg.get("image", {}).get("mime_type", "")

                elif msg.get("type") == "document":
                    parsed["media_id"] = msg.get("document", {}).get("id", "")
                    parsed["filename"] = msg.get("document", {}).get("filename", "")
                    parsed["caption"] = msg.get("document", {}).get("caption", "")

                elif msg.get("type") == "audio":
                    parsed["media_id"] = msg.get("audio", {}).get("id", "")
                    parsed["mime_type"] = msg.get("audio", {}).get("mime_type", "")

                elif msg.get("type") == "interactive":
                    interactive = msg.get("interactive", {})
                    if interactive.get("type") == "button_reply":
                        parsed["text"] = interactive.get("button_reply", {}).get("title", "")
                        parsed["button_id"] = interactive.get("button_reply", {}).get("id", "")
                    elif interactive.get("type") == "list_reply":
                        parsed["text"] = interactive.get("list_reply", {}).get("title", "")
                        parsed["list_id"] = interactive.get("list_reply", {}).get("id", "")

                elif msg.get("type") == "reaction":
                    parsed["reaction_emoji"] = msg.get("reaction", {}).get("emoji", "")
                    parsed["reaction_message_id"] = msg.get("reaction", {}).get("message_id", "")

                messages.append(parsed)

    return messages


# ─── Message Chunking ─────────────────────────────────────────────

def chunk_whatsapp_message(text: str, max_length: int = 4096) -> List[str]:
    """Split long text for WhatsApp (max 4096 chars)."""
    if len(text) <= max_length:
        return [text]

    chunks = []
    while text:
        if len(text) <= max_length:
            chunks.append(text)
            break
        split_at = text.rfind("\n", 0, max_length)
        if split_at == -1 or split_at < max_length // 2:
            split_at = text.rfind(" ", 0, max_length)
        if split_at == -1:
            split_at = max_length
        chunks.append(text[:split_at])
        text = text[split_at:].lstrip()

    return chunks
