"""
Seraph Discord Advanced Features — threads, slash commands, reactions, embeds.

Imported by discord_bot.py. Separated for cleanliness.
"""

import json
import time
import logging
from typing import Dict, List, Optional, Callable

logger = logging.getLogger("seraph.discord.features")

DISCORD_API = "https://discord.com/api/v10"


# ─── Thread Management ────────────────────────────────────────────

class DiscordThreadManager:
    """Manage Discord threads for long conversations."""

    def __init__(self, api_call: Callable):
        self.api_call = api_call
        self.thread_sessions: Dict[str, str] = {}  # thread_id -> session_key

    def get_session_key(self, channel_id: str, thread_id: str = None) -> str:
        """Get session key for a channel/thread."""
        if thread_id:
            if thread_id not in self.thread_sessions:
                self.thread_sessions[thread_id] = f"discord_thread_{thread_id}"
            return self.thread_sessions[thread_id]
        return f"discord_{channel_id}"

    def create_thread(self, channel_id: str, message_id: str, name: str) -> Optional[Dict]:
        """Create a thread from a message for long conversations."""
        return self.api_call("POST", f"/channels/{channel_id}/messages/{message_id}/threads", {
            "name": name[:100],
            "auto_archive_duration": 1440,  # 24 hours
        })

    def should_create_thread(self, message_count: int, channel_type: int) -> bool:
        """Check if we should create a thread (after 3+ exchanges in a public channel)."""
        return message_count >= 3 and channel_type == 0  # GUILD_TEXT


# ─── Slash Commands ────────────────────────────────────────────────

SLASH_COMMANDS = [
    {
        "name": "chat",
        "description": "Send a message to Seraph",
        "options": [{"name": "message", "type": 3, "description": "Your message", "required": True}],
    },
    {
        "name": "new",
        "description": "Start a fresh conversation",
    },
    {
        "name": "status",
        "description": "Show Seraph's current status",
    },
    {
        "name": "model",
        "description": "View or change the AI model",
        "options": [{"name": "name", "type": 3, "description": "Model name", "required": False}],
    },
    {
        "name": "exec",
        "description": "Run a shell command",
        "options": [{"name": "command", "type": 3, "description": "Command to run", "required": True}],
    },
    {
        "name": "search",
        "description": "Search the web",
        "options": [{"name": "query", "type": 3, "description": "Search query", "required": True}],
    },
    {
        "name": "usage",
        "description": "Show token usage and costs",
    },
    {
        "name": "memory",
        "description": "View memory status",
    },
    {
        "name": "audit",
        "description": "Run a code audit",
        "options": [{"name": "target", "type": 3, "description": "Target to audit", "required": True}],
    },
]


def register_slash_commands(token: str, application_id: str, guild_id: str = ""):
    """Register slash commands with Discord."""
    import requests
    headers = {"Authorization": f"Bot {token}", "Content-Type": "application/json"}

    if guild_id:
        url = f"{DISCORD_API}/applications/{application_id}/guilds/{guild_id}/commands"
    else:
        url = f"{DISCORD_API}/applications/{application_id}/commands"

    registered = 0
    for cmd in SLASH_COMMANDS:
        try:
            resp = requests.post(url, headers=headers, json=cmd, timeout=10)
            if resp.status_code in (200, 201):
                registered += 1
            else:
                logger.warning(f"Failed to register /{cmd['name']}: {resp.status_code}")
        except Exception as e:
            logger.error(f"Slash command registration error: {e}")

    logger.info(f"Registered {registered}/{len(SLASH_COMMANDS)} slash commands")
    return registered


def handle_interaction(interaction: dict, process_fn: Callable) -> dict:
    """Handle a Discord interaction (slash command or button press)."""
    interaction_type = interaction.get("type", 0)

    # Type 1: PING (verification)
    if interaction_type == 1:
        return {"type": 1}  # PONG

    # Type 2: APPLICATION_COMMAND (slash command)
    if interaction_type == 2:
        data = interaction.get("data", {})
        cmd_name = data.get("name", "")
        options = {
            opt["name"]: opt.get("value", "")
            for opt in data.get("options", [])
        }

        channel_id = interaction.get("channel_id", "")
        user = interaction.get("member", {}).get("user", interaction.get("user", {}))
        user_id = user.get("id", "")

        # Process the command
        if cmd_name == "chat":
            text = options.get("message", "")
            if text:
                # Defer response (we'll edit it later)
                return {
                    "type": 5,  # DEFERRED_CHANNEL_MESSAGE_WITH_SOURCE
                    "_process": lambda: process_fn(channel_id, user_id, text),
                }

        elif cmd_name == "new":
            return {
                "type": 4,  # CHANNEL_MESSAGE_WITH_SOURCE
                "data": {"content": "🔄 Conversation cleared. Fresh start."},
            }

        elif cmd_name == "status":
            return {
                "type": 4,
                "data": {"content": "⚡ Seraph is running."},
            }

        return {"type": 4, "data": {"content": f"Command /{cmd_name} not implemented yet."}}

    # Type 3: MESSAGE_COMPONENT (button press)
    if interaction_type == 3:
        custom_id = interaction.get("data", {}).get("custom_id", "")
        return {"type": 6, "_custom_id": custom_id}  # DEFERRED_UPDATE_MESSAGE

    return {"type": 1}


# ─── Embeds ────────────────────────────────────────────────────────

def build_embed(title: str, description: str, color: int = 0x7c3aed,
                fields: list = None, footer: str = "") -> dict:
    """Build a Discord embed object."""
    embed = {
        "title": title,
        "description": description[:4096],
        "color": color,
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }
    if fields:
        embed["fields"] = [
            {"name": f["name"][:256], "value": f["value"][:1024], "inline": f.get("inline", False)}
            for f in fields[:25]
        ]
    if footer:
        embed["footer"] = {"text": footer[:2048]}
    return embed


def build_status_embed(model: str, tools_count: int, sessions: int) -> dict:
    """Build the /status embed."""
    return build_embed(
        "⚡ Seraph Status",
        "The AI agent that audits itself",
        fields=[
            {"name": "Model", "value": model, "inline": True},
            {"name": "Tools", "value": str(tools_count), "inline": True},
            {"name": "Sessions", "value": str(sessions), "inline": True},
        ],
        footer="seraph.so",
    )


# ─── Reaction Status ──────────────────────────────────────────────

class DiscordReactions:
    """Use Discord reactions to show processing status."""

    THINKING = "🤔"
    EXECUTING = "⚡"
    DONE = "✅"
    ERROR = "❌"

    def __init__(self, api_call: Callable):
        self.api_call = api_call

    def add(self, channel_id: str, message_id: str, emoji: str):
        """Add a reaction to a message."""
        import urllib.parse
        encoded = urllib.parse.quote(emoji)
        self.api_call("PUT", f"/channels/{channel_id}/messages/{message_id}/reactions/{encoded}/@me")

    def remove(self, channel_id: str, message_id: str, emoji: str):
        """Remove bot's reaction from a message."""
        import urllib.parse
        encoded = urllib.parse.quote(emoji)
        self.api_call("DELETE", f"/channels/{channel_id}/messages/{message_id}/reactions/{encoded}/@me")

    def thinking(self, channel_id: str, message_id: str):
        self.add(channel_id, message_id, self.THINKING)

    def done(self, channel_id: str, message_id: str):
        self.remove(channel_id, message_id, self.THINKING)
        self.add(channel_id, message_id, self.DONE)


# ─── Message Chunking ─────────────────────────────────────────────

def chunk_discord_message(text: str, max_length: int = 2000) -> List[str]:
    """Split a long message into Discord-sized chunks (max 2000 chars)."""
    if len(text) <= max_length:
        return [text]

    chunks = []
    while text:
        if len(text) <= max_length:
            chunks.append(text)
            break

        # Try to split at a newline
        split_at = text.rfind("\n", 0, max_length)
        if split_at == -1 or split_at < max_length // 2:
            # Try to split at a space
            split_at = text.rfind(" ", 0, max_length)
        if split_at == -1:
            split_at = max_length

        chunks.append(text[:split_at])
        text = text[split_at:].lstrip()

    return chunks
