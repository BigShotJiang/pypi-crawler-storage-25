"""
Seraph Auth — multi-user authentication and permission management.

Users are stored in SQLite. Each user gets their own memory namespace,
conversation history, and permission level.
"""

import json
import logging
from pathlib import Path
from memory.store import get_memory

logger = logging.getLogger("seraph.auth")

# Permission levels
OWNER = "owner"       # Full access, can add/remove users
ADMIN = "admin"       # Full access, can't remove owner
USER = "user"         # Chat only, no terminal/SSH/exec
BLOCKED = "blocked"   # No access


class UserManager:
    """Manages user authentication and permissions."""

    def __init__(self, owner_ids: list = None):
        self.memory = get_memory()
        self.owner_ids = owner_ids or []
        self._ensure_owners()

    def _ensure_owners(self):
        """Make sure owner IDs are registered."""
        for uid in self.owner_ids:
            user = self.get_user(str(uid))
            if not user.get("role"):
                self.set_role(str(uid), OWNER)

    def get_user(self, user_id: str) -> dict:
        """Get user profile."""
        return self.memory.get_user(user_id)

    def set_role(self, user_id: str, role: str):
        """Set a user's permission role."""
        self.memory.update_user(user_id, preferences={"role": role})
        logger.info(f"User {user_id} role set to {role}")

    def get_role(self, user_id: str) -> str:
        """Get a user's role."""
        user = self.get_user(user_id)
        return user.get("preferences", {}).get("role", "")

    def is_allowed(self, user_id: str) -> bool:
        """Check if a user is allowed to use the bot."""
        role = self.get_role(user_id)
        if role == BLOCKED:
            return False
        if role in (OWNER, ADMIN, USER):
            return True
        # If no role set and no owner restriction, allow
        if not self.owner_ids:
            return True
        # If owner_ids set but user not registered, deny
        return int(user_id) in self.owner_ids

    def can_use_tools(self, user_id: str) -> bool:
        """Check if user can use dangerous tools (terminal, SSH, exec)."""
        role = self.get_role(user_id)
        return role in (OWNER, ADMIN)

    def add_user(self, user_id: str, name: str = "", role: str = USER):
        """Add a new authorized user."""
        self.memory.update_user(user_id, name=name, preferences={"role": role})

    def remove_user(self, user_id: str):
        """Remove a user (set to blocked)."""
        self.set_role(user_id, BLOCKED)

    def list_users(self) -> list:
        """List all registered users."""
        rows = self.memory.conn.execute(
            "SELECT user_id, name, preferences FROM user_profiles ORDER BY user_id"
        ).fetchall()
        users = []
        for r in rows:
            try:
                prefs = json.loads(r["preferences"]) if r["preferences"] else {}
            except (json.JSONDecodeError, IOError):
                prefs = {}
            users.append({
                "user_id": r["user_id"],
                "name": r["name"] or "?",
                "role": prefs.get("role", "none"),
            })
        return users


# Singleton
_manager = None

def get_user_manager(owner_ids: list = None) -> UserManager:
    global _manager
    if _manager is None:
        _manager = UserManager(owner_ids=owner_ids)
    return _manager
