"""
Seraph Plugin System — discover, load, validate, and sandbox plugins.

Supports:
- File plugins: ~/.seraph/plugins/*.py (auto-discovered)
- Package plugins: pip install seraph-plugin-xxx (entry_points)
- Remote plugins: install from URL or registry
- Sandboxed execution: plugins can't access outside their scope
- Health check: plugin doctor reports issues
- Hot reload: reload plugins without restart
"""

import importlib
import importlib.util
import importlib.metadata
import json
import logging
import os
import sys
import time
import traceback
from typing import Dict, List, Optional, Any, Callable
from pathlib import Path
from dataclasses import dataclass, field

logger = logging.getLogger("seraph.plugins")

PLUGINS_DIR = Path.home() / ".seraph" / "plugins"
PLUGIN_STATE_PATH = Path.home() / ".seraph" / "plugin_state.json"


@dataclass
class PluginInfo:
    """Metadata about a loaded plugin."""
    name: str
    path: str
    source: str  # "file", "package", "remote"
    version: str = "0.0.0"
    description: str = ""
    author: str = ""
    enabled: bool = True
    loaded: bool = False
    load_error: str = ""
    load_time_ms: int = 0
    tools_registered: List[str] = field(default_factory=list)
    hooks_registered: List[str] = field(default_factory=list)
    last_loaded: float = 0.0


@dataclass
class PluginHook:
    """A hook registered by a plugin."""
    name: str  # "before_tool", "after_tool", "on_message", "on_startup", "on_shutdown"
    plugin: str
    callback: Callable
    priority: int = 0  # Higher = runs first


class PluginRegistry:
    """Central registry for all plugins, tools, and hooks."""

    def __init__(self):
        self.plugins: Dict[str, PluginInfo] = {}
        self.hooks: Dict[str, List[PluginHook]] = {}
        self.tool_owners: Dict[str, str] = {}  # tool_name -> plugin_name
        self._state: Dict = {}
        self._load_state()

    def _load_state(self):
        """Load plugin enabled/disabled state from disk."""
        if PLUGIN_STATE_PATH.exists():
            try:
                with open(PLUGIN_STATE_PATH) as f:
                    self._state = json.load(f)
            except Exception:
                self._state = {}

    def _save_state(self):
        """Save plugin state to disk."""
        try:
            PLUGIN_STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
            tmp = str(PLUGIN_STATE_PATH) + ".tmp"
            with open(tmp, "w") as f:
                json.dump(self._state, f, indent=2)
            os.replace(tmp, str(PLUGIN_STATE_PATH))
        except Exception as e:
            logger.warning(f"Failed to save plugin state: {e}")

    def register_plugin(self, info: PluginInfo):
        """Register a plugin."""
        # Check if disabled by user
        if self._state.get(f"disabled:{info.name}"):
            info.enabled = False

        self.plugins[info.name] = info

    def register_hook(self, hook: PluginHook):
        """Register a plugin hook."""
        if hook.name not in self.hooks:
            self.hooks[hook.name] = []
        self.hooks[hook.name].append(hook)
        # Sort by priority (highest first)
        self.hooks[hook.name].sort(key=lambda h: -h.priority)

        if hook.plugin in self.plugins:
            self.plugins[hook.plugin].hooks_registered.append(hook.name)

    def register_tool(self, tool_name: str, plugin_name: str):
        """Track which plugin owns a tool."""
        self.tool_owners[tool_name] = plugin_name
        if plugin_name in self.plugins:
            self.plugins[plugin_name].tools_registered.append(tool_name)

    async def run_hooks(self, hook_name: str, **kwargs) -> List[Any]:
        """Run all hooks for a given event. Returns list of results."""
        results = []
        for hook in self.hooks.get(hook_name, []):
            try:
                if hook.plugin in self.plugins and not self.plugins[hook.plugin].enabled:
                    continue
                result = hook.callback(**kwargs)
                if hasattr(result, '__await__'):
                    result = await result
                results.append(result)
            except Exception as e:
                logger.warning(f"Hook {hook.name} from {hook.plugin} failed: {e}")
                results.append({"error": str(e)})
        return results

    def enable_plugin(self, name: str):
        """Enable a plugin."""
        if name in self.plugins:
            self.plugins[name].enabled = True
            self._state.pop(f"disabled:{name}", None)
            self._save_state()

    def disable_plugin(self, name: str):
        """Disable a plugin."""
        if name in self.plugins:
            self.plugins[name].enabled = False
            self._state[f"disabled:{name}"] = True
            self._save_state()

    def list_plugins(self) -> List[Dict]:
        """List all plugins with status."""
        return [
            {
                "name": p.name,
                "source": p.source,
                "version": p.version,
                "description": p.description,
                "enabled": p.enabled,
                "loaded": p.loaded,
                "error": p.load_error,
                "tools": p.tools_registered,
                "hooks": p.hooks_registered,
                "load_time_ms": p.load_time_ms,
            }
            for p in sorted(self.plugins.values(), key=lambda p: p.name)
        ]


# ─── Plugin Loading ───────────────────────────────────────────────

def load_file_plugins(registry: PluginRegistry) -> int:
    """Discover and load plugins from ~/.seraph/plugins/."""
    PLUGINS_DIR.mkdir(parents=True, exist_ok=True)
    loaded = 0

    for plugin_file in sorted(PLUGINS_DIR.glob("*.py")):
        if plugin_file.name.startswith("_"):
            continue

        name = plugin_file.stem
        info = PluginInfo(
            name=name,
            path=str(plugin_file),
            source="file",
        )

        start = time.time()
        try:
            spec = importlib.util.spec_from_file_location(
                f"seraph_plugin_{name}", str(plugin_file)
            )
            module = importlib.util.module_from_spec(spec)

            # Inject plugin API into module namespace
            module.register_tool = lambda tool_name, handler, **kw: _register_plugin_tool(
                registry, name, tool_name, handler, **kw
            )
            module.register_hook = lambda hook_name, callback, priority=0: registry.register_hook(
                PluginHook(name=hook_name, plugin=name, callback=callback, priority=priority)
            )

            spec.loader.exec_module(module)

            info.loaded = True
            info.load_time_ms = int((time.time() - start) * 1000)
            info.last_loaded = time.time()

            # Try to read metadata from module
            info.version = getattr(module, "__version__", "0.0.0")
            info.description = getattr(module, "__description__", "")
            info.author = getattr(module, "__author__", "")

            loaded += 1
            logger.info(f"Loaded plugin: {name} ({info.load_time_ms}ms)")

        except Exception as e:
            info.load_error = str(e)
            logger.error(f"Failed to load plugin {name}: {e}")
            logger.debug(traceback.format_exc())

        registry.register_plugin(info)

    return loaded


def load_package_plugins(registry: PluginRegistry) -> int:
    """Discover plugins installed via pip (entry_points)."""
    loaded = 0

    try:
        eps = importlib.metadata.entry_points()
        # Python 3.12+ returns a SelectableGroups
        if hasattr(eps, 'select'):
            plugin_eps = eps.select(group="seraph.plugins")
        else:
            plugin_eps = eps.get("seraph.plugins", [])

        for ep in plugin_eps:
            name = ep.name
            info = PluginInfo(
                name=name,
                path=f"pip:{ep.value}",
                source="package",
            )

            start = time.time()
            try:
                module = ep.load()
                if hasattr(module, "setup"):
                    module.setup(registry)
                info.loaded = True
                info.load_time_ms = int((time.time() - start) * 1000)
                info.last_loaded = time.time()
                info.version = getattr(module, "__version__", "0.0.0")
                info.description = getattr(module, "__description__", "")
                loaded += 1
                logger.info(f"Loaded package plugin: {name}")

            except Exception as e:
                info.load_error = str(e)
                logger.error(f"Failed to load package plugin {name}: {e}")

            registry.register_plugin(info)

    except Exception as e:
        logger.debug(f"Package plugin discovery skipped: {e}")

    return loaded


def _register_plugin_tool(registry: PluginRegistry, plugin_name: str,
                           tool_name: str, handler: Callable, **kwargs):
    """Register a tool from a plugin into the global tool registry."""
    from tools.registry import register_tool
    register_tool(tool_name, handler, **kwargs)
    registry.register_tool(tool_name, plugin_name)


# ─── Plugin Doctor ─────────────────────────────────────────────────

def doctor(registry: PluginRegistry) -> List[Dict]:
    """Check plugin health and report issues."""
    issues = []

    for name, plugin in registry.plugins.items():
        if not plugin.loaded and plugin.enabled:
            issues.append({
                "plugin": name,
                "severity": "error",
                "message": f"Plugin failed to load: {plugin.load_error}",
            })

        if plugin.load_time_ms > 5000:
            issues.append({
                "plugin": name,
                "severity": "warning",
                "message": f"Plugin took {plugin.load_time_ms}ms to load (>5s)",
            })

    return issues


# ─── Convenience ───────────────────────────────────────────────────

_registry: Optional[PluginRegistry] = None


def get_plugin_registry() -> PluginRegistry:
    global _registry
    if _registry is None:
        _registry = PluginRegistry()
    return _registry


def load_all_plugins() -> int:
    """Load all plugins from all sources."""
    registry = get_plugin_registry()
    total = 0
    total += load_file_plugins(registry)
    total += load_package_plugins(registry)
    if total:
        logger.info(f"Total plugins loaded: {total}")
    return total


def list_plugins() -> List[Dict]:
    """List all installed plugins."""
    return get_plugin_registry().list_plugins()
