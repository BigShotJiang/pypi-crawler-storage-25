"""
Example Seraph Plugin — shows how to create a custom tool.

To install: copy this file to ~/.seraph/plugins/
To create your own: follow this pattern and call register_tool()
"""

# Import the registry from the tools module
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from tools.registry import register_tool


def hello_world(name: str = "World") -> dict:
    """A simple example tool."""
    return {
        "message": f"Hello, {name}! This is a Seraph plugin.",
        "status": "working",
    }


# Register the tool — this is all it takes
register_tool(
    name="hello_plugin",
    description="Example plugin tool. Says hello. Use this as a template for building your own plugins.",
    parameters={
        "type": "object",
        "properties": {
            "name": {
                "type": "string",
                "description": "Name to greet"
            }
        },
    },
    handler=hello_world,
)
