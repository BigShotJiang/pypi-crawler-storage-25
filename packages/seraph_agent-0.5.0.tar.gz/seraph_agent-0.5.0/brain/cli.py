"""
Seraph CLI — onboarding wizard and management commands.

Usage:
  seraph onboard     Interactive setup wizard
  seraph run         Start the agent
  seraph status      Check health
  seraph doctor      Run diagnostics
"""

import os
import sys
import json
from pathlib import Path

SERAPH_DIR = Path.home() / ".seraph"


def main():
    if len(sys.argv) < 2:
        print_help()
        return

    cmd = sys.argv[1]
    if cmd == "onboard":
        onboard()
    elif cmd == "run":
        run()
    elif cmd == "status":
        status()
    elif cmd == "doctor":
        doctor()
    elif cmd in ("version", "--version", "-v"):
        print("Seraph v0.1.0")
    elif cmd in ("help", "--help", "-h"):
        print_help()
    else:
        print(f"Unknown command: {cmd}")
        print_help()


def print_help():
    print("""Seraph v0.1.0 - The AI agent that audits itself.

Usage:
  seraph onboard      Interactive setup wizard
  seraph run           Start the agent
  seraph status        Check if running
  seraph doctor        Run diagnostics
  seraph version       Print version

First time? Run: seraph onboard
""")


def onboard():
    """Interactive setup wizard."""
    print("\n" + "=" * 50)
    print("  SERAPH ONBOARDING")
    print("  The AI agent that audits itself")
    print("=" * 50 + "\n")

    # Create directories
    dirs = [SERAPH_DIR, SERAPH_DIR / "skills", SERAPH_DIR / "workspace",
            SERAPH_DIR / "cron", SERAPH_DIR / "personas", SERAPH_DIR / "templates"]
    for d in dirs:
        d.mkdir(parents=True, exist_ok=True)
    print("[OK] Created ~/.seraph directories\n")

    # Provider
    print("Step 1: Choose your AI provider")
    print("  1. OpenAI (GPT-5.4, GPT-4o)")
    print("  2. Anthropic (Claude Opus, Sonnet)")
    print("  3. OpenRouter (200+ models)")
    choice = input("\nChoose (1/2/3) [1]: ").strip() or "1"

    providers = {"1": "openai", "2": "anthropic", "3": "openrouter"}
    provider = providers.get(choice, "openai")

    # API key
    key_names = {"openai": "OPENAI_API_KEY", "anthropic": "ANTHROPIC_API_KEY", "openrouter": "OPENROUTER_API_KEY"}
    key_name = key_names[provider]
    print(f"\nStep 2: Enter your {provider.title()} API key")
    api_key = input(f"  {key_name}: ").strip()
    if not api_key:
        print("  Skipped (set later in .env)")

    # Model
    models = {
        "openai": ["gpt-5.4", "gpt-4.1", "gpt-4o", "gpt-4o-mini"],
        "anthropic": ["claude-opus-4-6", "claude-sonnet-4-6", "claude-haiku-4-5"],
        "openrouter": ["openai/gpt-5.4", "anthropic/claude-sonnet-4-6"],
    }
    print(f"\nStep 3: Choose model")
    for i, m in enumerate(models[provider], 1):
        print(f"  {i}. {m}")
    model_choice = input(f"\nChoose [1]: ").strip() or "1"
    try:
        model = models[provider][int(model_choice) - 1]
    except (IndexError, ValueError):
        model = models[provider][0]

    # Telegram
    print("\nStep 4: Telegram bot (optional)")
    print("  Get a token from @BotFather on Telegram")
    tg_token = input("  Bot token (or Enter to skip): ").strip()

    tg_user = ""
    if tg_token:
        print("  Your Telegram user ID (send /id to @userinfobot)")
        tg_user = input("  User ID: ").strip()

    # Write .env
    env_path = Path(__file__).resolve().parent.parent / ".env"
    env_lines = [
        f"SERAPH_PROVIDER={provider}",
        f"SERAPH_MODEL={model}",
    ]
    if api_key:
        env_lines.append(f"{key_name}={api_key}")
    if tg_token:
        env_lines.append(f"SERAPH_TELEGRAM_TOKEN={tg_token}")
    if tg_user:
        env_lines.append(f"SERAPH_ALLOWED_USERS={tg_user}")

    env_path.write_text("\n".join(env_lines) + "\n")
    print(f"\n[OK] Saved .env")

    # SOUL.md
    soul_path = SERAPH_DIR / "SOUL.md"
    if not soul_path.exists():
        soul_path.write_text(
            "# SOUL.md\n\nI am Seraph, a self-improving AI agent.\n"
            "I find every issue, fix every bug, and learn from experience.\n"
            "I am direct, honest, and efficient.\n"
        )
        print("[OK] Created SOUL.md")

    print("\n" + "=" * 50)
    print("  SETUP COMPLETE!")
    print(f"  Provider: {provider}")
    print(f"  Model: {model}")
    print(f"  Telegram: {'enabled' if tg_token else 'disabled'}")
    print("=" * 50)
    print("\n  Run: seraph run")
    print("  Or:  python3 run.py\n")


def run():
    """Start the agent."""
    run_py = Path(__file__).resolve().parent.parent / "run.py"
    if not run_py.exists():
        print("Error: run.py not found")
        sys.exit(1)
    os.execvp(sys.executable, [sys.executable, str(run_py)])


def status():
    """Check if agent is running."""
    import requests
    print("Seraph Status:")
    try:
        resp = requests.get("http://localhost:18801/health", timeout=3)
        if resp.status_code == 200:
            print("  Brain: ONLINE")
        else:
            print(f"  Brain: ERROR ({resp.status_code})")
    except Exception:
        print("  Brain: OFFLINE")


def doctor():
    """Run diagnostics."""
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from agent.doctor import run_doctor, format_doctor_report
    result = run_doctor()
    print(format_doctor_report(result))


if __name__ == "__main__":
    main()
