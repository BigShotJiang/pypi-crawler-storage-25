"""
Seraph Memory Store — 4-tier persistent memory using SQLite + FTS5.

Tier 1: Active memory — key facts injected into every prompt
Tier 2: Archive — full conversation history, searchable via FTS5
Tier 3: User profiles — preferences, corrections, patterns
Tier 4: Skills — learned procedures (handled by skills module)
"""

import sqlite3
import json
import logging
import time
from pathlib import Path
from typing import List, Dict, Optional
from datetime import datetime, timezone

logger = logging.getLogger("seraph.memory")

SERAPH_DIR = Path.home() / ".seraph"
DB_PATH = SERAPH_DIR / "memory.db"


class MemoryStore:
    """Persistent memory with full-text search."""

    def __init__(self, db_path: str = ""):
        self.db_path = db_path or str(DB_PATH)
        SERAPH_DIR.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(self.db_path)
        self.conn.row_factory = sqlite3.Row
        self._init_db()
        logger.info(f"Memory store opened: {self.db_path}")

    def _init_db(self):
        """Create tables and FTS5 index."""
        self.conn.executescript("""
            -- Tier 1: Active memory (key facts, always in prompt)
            CREATE TABLE IF NOT EXISTS active_memory (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                key TEXT UNIQUE NOT NULL,
                value TEXT NOT NULL,
                created_at TEXT DEFAULT (datetime('now')),
                updated_at TEXT DEFAULT (datetime('now'))
            );

            -- Tier 2: Conversation archive
            CREATE TABLE IF NOT EXISTS conversations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id TEXT NOT NULL,
                chat_id TEXT NOT NULL,
                role TEXT NOT NULL,
                content TEXT NOT NULL,
                tokens INTEGER DEFAULT 0,
                created_at TEXT DEFAULT (datetime('now'))
            );

            -- FTS5 index for searching conversation history
            CREATE VIRTUAL TABLE IF NOT EXISTS conversations_fts USING fts5(
                content,
                content=conversations,
                content_rowid=id
            );

            -- Trigger to keep FTS in sync
            CREATE TRIGGER IF NOT EXISTS conversations_ai AFTER INSERT ON conversations BEGIN
                INSERT INTO conversations_fts(rowid, content) VALUES (new.id, new.content);
            END;

            -- Tier 3: User profiles
            CREATE TABLE IF NOT EXISTS user_profiles (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id TEXT UNIQUE NOT NULL,
                name TEXT,
                preferences TEXT DEFAULT '{}',
                corrections TEXT DEFAULT '[]',
                facts TEXT DEFAULT '[]',
                created_at TEXT DEFAULT (datetime('now')),
                updated_at TEXT DEFAULT (datetime('now'))
            );

            -- General key-value store for misc persistent data
            CREATE TABLE IF NOT EXISTS kv_store (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL,
                updated_at TEXT DEFAULT (datetime('now'))
            );

            CREATE INDEX IF NOT EXISTS idx_conv_session ON conversations(session_id);
            CREATE INDEX IF NOT EXISTS idx_conv_chat ON conversations(chat_id);
            CREATE INDEX IF NOT EXISTS idx_conv_time ON conversations(created_at);
        """)
        self.conn.commit()

    # ─── Tier 1: Active Memory ───────────────────────────────

    def set_active(self, key: str, value: str):
        """Set an active memory fact (always in prompt)."""
        self.conn.execute(
            "INSERT INTO active_memory (key, value, updated_at) VALUES (?, ?, datetime('now')) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=datetime('now')",
            (key, value)
        )
        self.conn.commit()
        logger.info(f"Active memory set: {key}")

    def get_active(self, key: str) -> Optional[str]:
        """Get an active memory fact."""
        row = self.conn.execute("SELECT value FROM active_memory WHERE key=?", (key,)).fetchone()
        return row["value"] if row else None

    def get_all_active(self) -> Dict[str, str]:
        """Get all active memory facts."""
        rows = self.conn.execute("SELECT key, value FROM active_memory ORDER BY key").fetchall()
        return {r["key"]: r["value"] for r in rows}

    def delete_active(self, key: str):
        """Delete an active memory fact."""
        self.conn.execute("DELETE FROM active_memory WHERE key=?", (key,))
        self.conn.commit()

    def format_active_for_prompt(self) -> str:
        """Format active memory as text for injection into system prompt."""
        facts = self.get_all_active()
        if not facts:
            return ""
        lines = [f"- {k}: {v}" for k, v in facts.items()]
        return "## Active Memory\n" + "\n".join(lines)

    # ─── Tier 2: Conversation Archive ────────────────────────

    def save_message(self, session_id: str, chat_id: str, role: str, content: str, tokens: int = 0):
        """Save a message to the conversation archive."""
        self.conn.execute(
            "INSERT INTO conversations (session_id, chat_id, role, content, tokens) VALUES (?, ?, ?, ?, ?)",
            (session_id, chat_id, role, content, tokens)
        )
        self.conn.commit()

    def get_session_history(self, session_id: str, limit: int = 50) -> List[Dict]:
        """Get recent messages from a session."""
        rows = self.conn.execute(
            "SELECT role, content, created_at FROM conversations WHERE session_id=? ORDER BY id DESC LIMIT ?",
            (session_id, limit)
        ).fetchall()
        return [{"role": r["role"], "content": r["content"], "time": r["created_at"]} for r in reversed(rows)]

    def search_history(self, query: str, limit: int = 10) -> List[Dict]:
        """Full-text search across all conversation history."""
        rows = self.conn.execute(
            """SELECT c.role, c.content, c.session_id, c.created_at,
                      highlight(conversations_fts, 0, '<b>', '</b>') as snippet
               FROM conversations_fts fts
               JOIN conversations c ON c.id = fts.rowid
               WHERE conversations_fts MATCH ?
               ORDER BY rank
               LIMIT ?""",
            (query, limit)
        ).fetchall()
        return [
            {
                "role": r["role"],
                "content": r["content"][:200],
                "snippet": r["snippet"][:200],
                "session": r["session_id"],
                "time": r["created_at"],
            }
            for r in rows
        ]

    def get_session_count(self) -> int:
        """Get total number of unique sessions."""
        row = self.conn.execute("SELECT COUNT(DISTINCT session_id) as cnt FROM conversations").fetchone()
        return row["cnt"]

    def get_message_count(self) -> int:
        """Get total messages stored."""
        row = self.conn.execute("SELECT COUNT(*) as cnt FROM conversations").fetchone()
        return row["cnt"]

    # ─── Tier 3: User Profiles ───────────────────────────────

    def get_user(self, user_id: str) -> Dict:
        """Get or create a user profile."""
        row = self.conn.execute("SELECT * FROM user_profiles WHERE user_id=?", (user_id,)).fetchone()
        if row:
            try:
                prefs = json.loads(row["preferences"])
            except (json.JSONDecodeError, TypeError):
                prefs = {}
            try:
                corrections = json.loads(row["corrections"])
            except (json.JSONDecodeError, TypeError):
                corrections = []
            try:
                facts = json.loads(row["facts"])
            except (json.JSONDecodeError, TypeError):
                facts = []
            return {
                "user_id": row["user_id"],
                "name": row["name"],
                "preferences": prefs,
                "corrections": corrections,
                "facts": facts,
            }
        # Create new profile
        self.conn.execute(
            "INSERT INTO user_profiles (user_id) VALUES (?)", (user_id,)
        )
        self.conn.commit()
        return {"user_id": user_id, "name": None, "preferences": {}, "corrections": [], "facts": []}

    def update_user(self, user_id: str, name: str = None, preferences: Dict = None,
                    corrections: List = None, facts: List = None):
        """Update a user profile."""
        user = self.get_user(user_id)
        if name:
            user["name"] = name
        if preferences:
            user["preferences"].update(preferences)
        if corrections:
            user["corrections"].extend(corrections)
            user["corrections"] = user["corrections"][-50:]  # Keep last 50
        if facts:
            user["facts"].extend(facts)
            user["facts"] = user["facts"][-100:]  # Keep last 100

        self.conn.execute(
            """UPDATE user_profiles SET name=?, preferences=?, corrections=?, facts=?, updated_at=datetime('now')
               WHERE user_id=?""",
            (user["name"], json.dumps(user["preferences"]), json.dumps(user["corrections"]),
             json.dumps(user["facts"]), user_id)
        )
        self.conn.commit()

    def format_user_for_prompt(self, user_id: str) -> str:
        """Format user profile for injection into system prompt."""
        user = self.get_user(user_id)
        parts = []
        if user["name"]:
            parts.append(f"User name: {user['name']}")
        if user["preferences"]:
            parts.append(f"Preferences: {json.dumps(user['preferences'])}")
        if user["facts"]:
            parts.append("Known facts: " + "; ".join(user["facts"][-10:]))
        if user["corrections"]:
            parts.append("Past corrections: " + "; ".join(user["corrections"][-5:]))
        if not parts:
            return ""
        return "## User Profile\n" + "\n".join(parts)

    # ─── Key-Value Store ─────────────────────────────────────

    def kv_set(self, key: str, value: str):
        """Set a key-value pair."""
        self.conn.execute(
            "INSERT INTO kv_store (key, value, updated_at) VALUES (?, ?, datetime('now')) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=datetime('now')",
            (key, value)
        )
        self.conn.commit()

    def kv_get(self, key: str) -> Optional[str]:
        """Get a value by key."""
        row = self.conn.execute("SELECT value FROM kv_store WHERE key=?", (key,)).fetchone()
        return row["value"] if row else None

    # ─── Cleanup ─────────────────────────────────────────────

    def cleanup_old(self, days: int = 90):
        """Delete conversations older than N days."""
        self.conn.execute(
            "DELETE FROM conversations WHERE created_at < datetime('now', ?)",
            (f"-{days} days",)
        )
        self.conn.commit()
        self.conn.execute("VACUUM")
        logger.info(f"Cleaned up conversations older than {days} days")

    def close(self):
        """Close the database connection."""
        self.conn.close()


# Singleton instance
_store = None

def get_memory() -> MemoryStore:
    """Get the global memory store instance."""
    global _store
    if _store is None:
        _store = MemoryStore()
    return _store
