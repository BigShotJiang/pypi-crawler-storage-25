"""
Seraph ACP Server — Agent Client Protocol for IDE integration.

ACP lets IDEs (VS Code, JetBrains, Cursor) drive Seraph over stdio.
The IDE sends prompts, Seraph executes tools and streams responses back.

Protocol: NDJSON over stdio (same as OpenClaw's ACP bridge).

Supported ACP methods:
- initialize — handshake + capabilities
- newSession — create a fresh session
- loadSession — reconnect to existing session
- listSessions — list available sessions
- prompt — send a user message
- cancel — abort current generation
- session/set_mode — change thinking/tool verbosity

Usage:
  python -m brain.acp.server                    # stdio mode
  seraph acp                                    # via CLI

Configure in VS Code settings.json:
  "acp.command": "seraph acp"
"""

import sys
import json
import time
import uuid
import logging
import asyncio
from typing import Dict, List, Optional, Any
from pathlib import Path

logger = logging.getLogger("seraph.acp")

SERAPH_DIR = Path.home() / ".seraph"


class ACPSession:
    """An ACP session bound to a Seraph conversation."""
    def __init__(self, session_id: str, seraph_session_key: str = ""):
        self.session_id = session_id
        self.seraph_key = seraph_session_key or f"acp_{session_id}"
        self.created_at = time.time()
        self.message_count = 0
        self.active_prompt_id: Optional[str] = None
        self.cancelled = False
        self.mode = {
            "think_level": "normal",      # "off", "normal", "high"
            "tool_verbosity": "normal",    # "quiet", "normal", "verbose"
            "reasoning": True,
            "usage_detail": False,
        }


class ACPServer:
    """
    ACP server that bridges IDE prompts to Seraph's agent brain.

    Communicates over stdin/stdout using NDJSON.
    Each line is a JSON object with "method" and optional "id"/"params".
    """

    def __init__(self):
        self.sessions: Dict[str, ACPSession] = {}
        self.active_session: Optional[ACPSession] = None
        self._initialized = False
        self._abort_event = asyncio.Event()

    def handle_message(self, message: dict) -> Optional[dict]:
        """Handle an incoming ACP message. Returns response or None for notifications."""
        method = message.get("method", "")
        params = message.get("params", {})
        msg_id = message.get("id")

        handler = {
            "initialize": self._handle_initialize,
            "newSession": self._handle_new_session,
            "loadSession": self._handle_load_session,
            "listSessions": self._handle_list_sessions,
            "prompt": self._handle_prompt,
            "cancel": self._handle_cancel,
            "session/set_mode": self._handle_set_mode,
            "ping": self._handle_ping,
            "shutdown": self._handle_shutdown,
            "notifications/initialized": lambda p: None,  # Notification, no response
        }.get(method)

        if handler is None:
            return self._error(msg_id, -32601, f"Unknown method: {method}")

        try:
            result = handler(params)
            if result is None and method.startswith("notifications/"):
                return None  # Notifications don't get responses
            return self._respond(msg_id, result or {})
        except Exception as e:
            logger.error(f"ACP handler error for {method}: {e}")
            return self._error(msg_id, -32000, str(e))

    # ─── ACP Method Handlers ──────────────────────────────────────

    def _handle_initialize(self, params: dict) -> dict:
        """Handshake — exchange capabilities."""
        self._initialized = True
        return {
            "protocolVersion": "2024-11-05",
            "capabilities": {
                "tools": True,
                "streaming": True,
                "sessions": True,
                "modes": ["think_level", "tool_verbosity", "reasoning"],
            },
            "serverInfo": {
                "name": "seraph",
                "version": "0.2.0",
                "description": "The AI agent that audits itself",
            },
        }

    def _handle_new_session(self, params: dict) -> dict:
        """Create a fresh ACP session."""
        session_id = params.get("sessionId", str(uuid.uuid4())[:8])
        session = ACPSession(session_id)
        self.sessions[session_id] = session
        self.active_session = session

        logger.info(f"ACP new session: {session_id}")
        return {
            "sessionId": session_id,
            "created": True,
        }

    def _handle_load_session(self, params: dict) -> dict:
        """Reconnect to an existing session."""
        session_id = params.get("sessionId", "")

        if session_id in self.sessions:
            self.active_session = self.sessions[session_id]
            return {"sessionId": session_id, "loaded": True, "messageCount": self.active_session.message_count}

        # Try loading from session store
        try:
            from sessions.store import get_session_store
            store = get_session_store()
            session_data = store.get_session(f"acp_{session_id}")
            if session_data:
                session = ACPSession(session_id, f"acp_{session_id}")
                session.message_count = session_data.get("message_count", 0)
                self.sessions[session_id] = session
                self.active_session = session

                # Replay message history
                messages = store.get_messages(f"acp_{session_id}")
                history = []
                for msg in messages:
                    history.append({
                        "role": msg["role"],
                        "content": msg["content"],
                    })
                    self._emit_event("session_history", {
                        "role": msg["role"],
                        "content": msg["content"],
                    })

                return {"sessionId": session_id, "loaded": True, "messageCount": len(messages)}
        except Exception as e:
            logger.warning(f"Failed to load session {session_id}: {e}")

        # Create new if not found
        return self._handle_new_session({"sessionId": session_id})

    def _handle_list_sessions(self, params: dict) -> dict:
        """List available sessions."""
        sessions = []
        for sid, s in self.sessions.items():
            sessions.append({
                "sessionId": sid,
                "messageCount": s.message_count,
                "createdAt": s.created_at,
                "active": s == self.active_session,
            })

        # Also check session store
        try:
            from sessions.store import get_session_store
            store = get_session_store()
            stored = store.list_sessions(status="active", limit=20)
            for s in stored:
                if s["id"].startswith("acp_"):
                    acp_id = s["id"][4:]
                    if acp_id not in self.sessions:
                        sessions.append({
                            "sessionId": acp_id,
                            "messageCount": s.get("message_count", 0),
                            "createdAt": s.get("created_at", 0),
                            "active": False,
                        })
        except Exception:
            pass

        return {"sessions": sessions}

    def _handle_prompt(self, params: dict) -> dict:
        """Process a user prompt through the agent."""
        if not self.active_session:
            self._handle_new_session({})

        session = self.active_session
        text = ""

        # Extract text from prompt content
        content = params.get("content", [])
        if isinstance(content, str):
            text = content
        elif isinstance(content, list):
            for block in content:
                if isinstance(block, dict) and block.get("type") == "text":
                    text += block.get("text", "")
                elif isinstance(block, str):
                    text += block

        if not text:
            return {"error": "Empty prompt"}

        session.message_count += 1
        session.cancelled = False
        prompt_id = str(uuid.uuid4())[:8]
        session.active_prompt_id = prompt_id

        # Emit thinking status
        self._emit_event("status", {"state": "thinking", "promptId": prompt_id})

        # Process through brain
        try:
            response_text = self._process_prompt(session, text)

            if session.cancelled:
                self._emit_event("status", {"state": "cancelled", "promptId": prompt_id})
                return {"cancelled": True}

            # Emit response
            self._emit_event("assistant_message", {
                "content": response_text,
                "promptId": prompt_id,
            })

            session.active_prompt_id = None
            self._emit_event("status", {"state": "idle"})

            return {
                "promptId": prompt_id,
                "content": response_text,
                "stopReason": "end_turn",
            }

        except Exception as e:
            logger.error(f"ACP prompt error: {e}")
            self._emit_event("status", {"state": "error", "error": str(e)})
            return {"error": str(e)}

    def _handle_cancel(self, params: dict) -> dict:
        """Cancel the current generation."""
        if self.active_session:
            self.active_session.cancelled = True
            self.active_session.active_prompt_id = None
            self._abort_event.set()
        return {"cancelled": True}

    def _handle_set_mode(self, params: dict) -> dict:
        """Change session mode settings."""
        if not self.active_session:
            return {"error": "No active session"}

        for key in ("think_level", "tool_verbosity", "reasoning", "usage_detail"):
            if key in params:
                self.active_session.mode[key] = params[key]

        return {"mode": self.active_session.mode}

    def _handle_ping(self, params: dict) -> dict:
        return {}

    def _handle_shutdown(self, params: dict) -> dict:
        logger.info("ACP shutdown requested")
        return {"ok": True}

    # ─── Brain Integration ────────────────────────────────────────

    def _process_prompt(self, session: ACPSession, text: str) -> str:
        """Send prompt to Seraph brain and get response."""
        try:
            import os
            sys.path.insert(0, str(Path(__file__).parent.parent))
            from agent.llm import LLMProvider

            provider = os.environ.get("SERAPH_PROVIDER", "anthropic")
            model = os.environ.get("SERAPH_MODEL", "claude-sonnet-4-6")

            llm = LLMProvider(provider=provider, model=model)

            # Load identity
            identity = "You are Seraph, a coding AI agent."
            soul_path = SERAPH_DIR / "SOUL.md"
            if soul_path.exists():
                identity = soul_path.read_text()

            # Simple call for now — full tool loop integration TODO
            response = llm.chat(
                messages=[{"role": "user", "content": text}],
                system=identity,
            )
            return response.text

        except Exception as e:
            logger.error(f"Brain call failed: {e}")
            return f"Error: {e}"

    # ─── Event Emission ───────────────────────────────────────────

    def _emit_event(self, event_type: str, data: dict):
        """Send an event notification to the IDE."""
        event = {
            "jsonrpc": "2.0",
            "method": f"notifications/{event_type}",
            "params": data,
        }
        self._write(event)

    # ─── Protocol Helpers ─────────────────────────────────────────

    def _respond(self, msg_id: Any, result: dict) -> dict:
        return {"jsonrpc": "2.0", "id": msg_id, "result": result}

    def _error(self, msg_id: Any, code: int, message: str) -> dict:
        return {"jsonrpc": "2.0", "id": msg_id, "error": {"code": code, "message": message}}

    def _write(self, data: dict):
        """Write NDJSON to stdout."""
        sys.stdout.write(json.dumps(data) + "\n")
        sys.stdout.flush()

    # ─── Main Loop ────────────────────────────────────────────────

    def run_stdio(self):
        """Run ACP server over stdio."""
        logger.info("Seraph ACP server starting (stdio)")

        for line in sys.stdin:
            line = line.strip()
            if not line:
                continue

            try:
                message = json.loads(line)
            except json.JSONDecodeError:
                continue

            response = self.handle_message(message)
            if response is not None:
                self._write(response)

            # Check for shutdown
            if message.get("method") == "shutdown":
                break


def main():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(name)s] %(message)s",
        stream=sys.stderr,
    )
    server = ACPServer()
    server.run_stdio()


if __name__ == "__main__":
    main()
