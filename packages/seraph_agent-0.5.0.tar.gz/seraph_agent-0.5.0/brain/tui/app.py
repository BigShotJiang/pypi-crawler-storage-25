"""
Seraph TUI — Terminal User Interface.

Full terminal interface with:
- Chat log with scrolling
- Status bar (model, tokens, cost)
- Command palette
- Session selector
- Tool execution overlay

Usage: seraph tui
"""

import sys
import os
import time
import json
import logging
import threading
from typing import Optional, List

logger = logging.getLogger("seraph.tui")

# Add brain to path
sys.path.insert(0, str(__import__("pathlib").Path(__file__).parent.parent))


class SeraphTUI:
    """Terminal-based chat interface for Seraph."""

    def __init__(self):
        self.running = False
        self.messages: List[dict] = []
        self.input_buffer = ""
        self.model = os.environ.get("SERAPH_MODEL", "claude-sonnet-4-6")
        self.provider = os.environ.get("SERAPH_PROVIDER", "anthropic")
        self.session_key = f"tui_{int(time.time())}"
        self.total_tokens = 0
        self.total_cost = 0.0
        self.llm = None
        self.status = "ready"

    def start(self):
        """Start the TUI."""
        self.running = True
        self._init_llm()
        self._draw_header()

        print(f"  Model: {self.model} ({self.provider})")
        print(f"  Type a message and press Enter. Commands start with /")
        print(f"  /help for commands, /quit to exit")
        print(f"  {'─' * 50}\n")

        while self.running:
            try:
                user_input = input("  You: ").strip()
                if not user_input:
                    continue

                if user_input.startswith("/"):
                    self._handle_command(user_input)
                else:
                    self._process_message(user_input)

            except (KeyboardInterrupt, EOFError):
                self.running = False
                print("\n  Goodbye.")

    def _init_llm(self):
        """Initialize the LLM."""
        try:
            from agent.llm import LLMProvider
            self.llm = LLMProvider(provider=self.provider, model=self.model)
        except Exception as e:
            print(f"  ⚠ LLM init failed: {e}")

    def _draw_header(self):
        """Draw the TUI header."""
        print("\n╔═══════════════════════════════════════╗")
        print("║         SERAPH TUI v0.2.0             ║")
        print("╚═══════════════════════════════════════╝")

    def _process_message(self, text: str):
        """Process a user message."""
        if not self.llm:
            print("  ⚠ LLM not connected.")
            return

        self.messages.append({"role": "user", "content": text})
        self.status = "thinking..."
        self._show_status()

        try:
            # Load identity
            from pathlib import Path
            soul_path = Path.home() / ".seraph" / "SOUL.md"
            identity = soul_path.read_text() if soul_path.exists() else "You are Seraph."

            # Stream response
            print("  Seraph: ", end="", flush=True)

            full_text = ""
            for chunk in self.llm.chat_stream(self.messages, identity):
                if isinstance(chunk, str):
                    print(chunk, end="", flush=True)
                    full_text += chunk
                elif hasattr(chunk, 'text') and chunk.text:
                    print(chunk.text, end="", flush=True)
                    full_text += chunk.text
                    self.total_tokens += chunk.input_tokens + chunk.output_tokens

            print()  # Newline after response
            self.messages.append({"role": "assistant", "content": full_text})
            self.status = "ready"

        except Exception as e:
            print(f"\n  ⚠ Error: {e}")
            self.status = "error"

    def _handle_command(self, cmd: str):
        """Handle a / command."""
        parts = cmd.split()
        command = parts[0].lower()
        args = " ".join(parts[1:]) if len(parts) > 1 else ""

        if command in ("/quit", "/exit", "/q"):
            self.running = False
            print("  Goodbye.")

        elif command == "/help":
            print("  Commands:")
            print("    /new          Clear conversation")
            print("    /model <name> Change model")
            print("    /status       Show status")
            print("    /history      Show message count")
            print("    /session      Show session info")
            print("    /tokens       Show token usage")
            print("    /quit         Exit TUI")

        elif command == "/new":
            self.messages = []
            self.session_key = f"tui_{int(time.time())}"
            print("  Conversation cleared.")

        elif command == "/model":
            if args:
                old = self.model
                self.model = args
                self._init_llm()
                print(f"  Model: {old} → {self.model}")
            else:
                print(f"  Current model: {self.model}")

        elif command == "/status":
            print(f"  Status: {self.status}")
            print(f"  Model: {self.model} ({self.provider})")
            print(f"  Messages: {len(self.messages)}")
            print(f"  Tokens: {self.total_tokens:,}")
            print(f"  Session: {self.session_key}")

        elif command == "/history":
            print(f"  Messages: {len(self.messages)}")
            for m in self.messages[-10:]:
                role = m["role"].upper()
                text = m["content"][:60]
                print(f"    [{role}] {text}")

        elif command == "/tokens":
            print(f"  Total tokens: {self.total_tokens:,}")
            print(f"  Estimated cost: ${self.total_cost:.4f}")

        elif command == "/session":
            print(f"  Session: {self.session_key}")

        elif command == "/btw":
            if args:
                from agent.btw import handle_btw
                identity = ""
                soul = __import__("pathlib").Path.home() / ".seraph" / "SOUL.md"
                if soul.exists():
                    identity = soul.read_text()
                response = handle_btw(args, self.messages, identity, self.llm)
                print(f"  (btw) {response}")
            else:
                print("  Usage: /btw <question>")

        else:
            print(f"  Unknown command: {command}. Type /help")

    def _show_status(self):
        """Show status in the terminal."""
        pass  # In a full TUI this would update a status bar


def main():
    """Entry point for the TUI."""
    logging.basicConfig(level=logging.WARNING)  # Quiet mode for TUI
    tui = SeraphTUI()
    tui.start()


if __name__ == "__main__":
    main()
