"""
Seraph Diagnostics — telemetry and observability.

Tracks:
- LLM call latency and token usage
- Tool execution time and success rate
- Session duration and message counts
- Error rates by provider
- Memory/CPU usage

Can export to:
- Local JSON logs (default)
- OpenTelemetry collector (optional)
- Console (debug mode)
"""

import json
import time
import logging
import os
import threading
from typing import Dict, List, Optional
from pathlib import Path
from dataclasses import dataclass, field
from collections import defaultdict

logger = logging.getLogger("seraph.diagnostics")

SERAPH_DIR = Path.home() / ".seraph"
METRICS_PATH = SERAPH_DIR / "metrics.json"


@dataclass
class Metric:
    """A single metric data point."""
    name: str
    value: float
    tags: Dict[str, str] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)


@dataclass
class SpanContext:
    """A tracing span for tracking operation duration."""
    name: str
    start_time: float
    tags: Dict[str, str] = field(default_factory=dict)
    end_time: float = 0.0
    error: str = ""

    @property
    def duration_ms(self) -> int:
        end = self.end_time or time.time()
        return int((end - self.start_time) * 1000)


class TelemetryCollector:
    """Collects and aggregates telemetry data."""

    def __init__(self):
        self.metrics: List[Metric] = []
        self.spans: List[SpanContext] = []
        self.counters: Dict[str, int] = defaultdict(int)
        self.histograms: Dict[str, List[float]] = defaultdict(list)
        self._lock = threading.Lock()
        self._start_time = time.time()
        self._otel_enabled = False

        # Check for OpenTelemetry
        try:
            import opentelemetry
            self._otel_enabled = bool(os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT"))
        except ImportError:
            pass

    # ─── Metrics ──────────────────────────────────────────────────

    def record(self, name: str, value: float, **tags):
        """Record a metric value."""
        with self._lock:
            self.metrics.append(Metric(name=name, value=value, tags=tags))
            # Keep last 10K metrics
            if len(self.metrics) > 10000:
                self.metrics = self.metrics[-5000:]

    def increment(self, name: str, amount: int = 1, **tags):
        """Increment a counter."""
        key = f"{name}:{json.dumps(tags, sort_keys=True)}" if tags else name
        with self._lock:
            self.counters[key] += amount

    def histogram(self, name: str, value: float, **tags):
        """Record a value in a histogram (for percentiles)."""
        key = f"{name}:{json.dumps(tags, sort_keys=True)}" if tags else name
        with self._lock:
            self.histograms[key].append(value)
            if len(self.histograms[key]) > 1000:
                self.histograms[key] = self.histograms[key][-500:]

    # ─── Spans (Tracing) ─────────────────────────────────────────

    def start_span(self, name: str, **tags) -> SpanContext:
        """Start a tracing span."""
        span = SpanContext(name=name, start_time=time.time(), tags=tags)
        return span

    def end_span(self, span: SpanContext, error: str = ""):
        """End a tracing span and record it."""
        span.end_time = time.time()
        span.error = error
        with self._lock:
            self.spans.append(span)
            if len(self.spans) > 5000:
                self.spans = self.spans[-2500:]

        # Record as histogram
        self.histogram(f"span.{span.name}.duration_ms", span.duration_ms)
        if error:
            self.increment(f"span.{span.name}.errors")

    # ─── Convenience Methods ─────────────────────────────────────

    def track_llm_call(self, provider: str, model: str, input_tokens: int,
                       output_tokens: int, duration_ms: int, error: str = ""):
        """Track an LLM API call."""
        self.record("llm.input_tokens", input_tokens, provider=provider, model=model)
        self.record("llm.output_tokens", output_tokens, provider=provider, model=model)
        self.histogram("llm.duration_ms", duration_ms, provider=provider)
        self.increment("llm.calls", provider=provider, model=model)
        if error:
            self.increment("llm.errors", provider=provider, error_type=error[:50])

    def track_tool_call(self, tool: str, duration_ms: int, success: bool):
        """Track a tool execution."""
        self.histogram("tool.duration_ms", duration_ms, tool=tool)
        self.increment("tool.calls", tool=tool)
        if not success:
            self.increment("tool.errors", tool=tool)

    def track_message(self, channel: str, direction: str):
        """Track a message (inbound or outbound)."""
        self.increment(f"message.{direction}", channel=channel)

    # ─── Reporting ────────────────────────────────────────────────

    def get_summary(self) -> Dict:
        """Get a summary of all collected telemetry."""
        with self._lock:
            uptime = time.time() - self._start_time

            # Aggregate histograms
            histogram_summary = {}
            for key, values in self.histograms.items():
                if values:
                    sorted_vals = sorted(values)
                    n = len(sorted_vals)
                    histogram_summary[key] = {
                        "count": n,
                        "avg": sum(sorted_vals) / n,
                        "p50": sorted_vals[n // 2],
                        "p95": sorted_vals[int(n * 0.95)] if n >= 20 else sorted_vals[-1],
                        "p99": sorted_vals[int(n * 0.99)] if n >= 100 else sorted_vals[-1],
                        "min": sorted_vals[0],
                        "max": sorted_vals[-1],
                    }

            return {
                "uptime_seconds": int(uptime),
                "counters": dict(self.counters),
                "histograms": histogram_summary,
                "total_metrics": len(self.metrics),
                "total_spans": len(self.spans),
                "otel_enabled": self._otel_enabled,
            }

    def export_json(self) -> str:
        """Export metrics as JSON."""
        return json.dumps(self.get_summary(), indent=2, default=str)

    def save(self):
        """Save current metrics to disk."""
        try:
            SERAPH_DIR.mkdir(parents=True, exist_ok=True)
            tmp = str(METRICS_PATH) + ".tmp"
            with open(tmp, "w") as f:
                f.write(self.export_json())
            os.replace(tmp, str(METRICS_PATH))
        except Exception as e:
            logger.warning(f"Failed to save metrics: {e}")


# Singleton
_collector: Optional[TelemetryCollector] = None

def get_telemetry() -> TelemetryCollector:
    global _collector
    if _collector is None:
        _collector = TelemetryCollector()
    return _collector
