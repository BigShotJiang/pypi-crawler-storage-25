"""
Seraph Sandbox — Docker/Podman isolation for exec commands.

When sandbox is enabled, all terminal/exec tool calls run inside a container
with restricted access:
- Workspace directory mounted read-write
- No network access (optional)
- CPU/memory limits
- Timeout enforcement
- No access to host filesystem outside workspace

Falls back to subprocess if Docker/Podman is not available.
"""

import os
import subprocess
import logging
import time
import shutil
from typing import Optional, Dict
from pathlib import Path

logger = logging.getLogger("seraph.security.sandbox")

WORKSPACE = Path.home() / ".seraph" / "workspace"


def detect_runtime() -> Optional[str]:
    """Detect available container runtime: docker, podman, or None."""
    for runtime in ["docker", "podman"]:
        if shutil.which(runtime):
            try:
                result = subprocess.run(
                    [runtime, "info"], capture_output=True, text=True, timeout=5
                )
                if result.returncode == 0:
                    return runtime
            except Exception:
                continue
    return None


def build_exec_args(
    command: str,
    workspace: str = None,
    runtime: str = "docker",
    image: str = "python:3.12-slim",
    network: bool = False,
    memory_limit: str = "512m",
    cpu_limit: str = "1.0",
    timeout: int = 30,
    env_vars: Dict[str, str] = None,
) -> list:
    """
    Build Docker/Podman exec arguments for sandboxed command execution.

    Returns the full command list to pass to subprocess.run().
    """
    ws = workspace or str(WORKSPACE)

    args = [
        runtime, "run",
        "--rm",  # Remove container after exit
        "--name", f"seraph-sandbox-{int(time.time())}",
        "-w", "/workspace",  # Working directory inside container
        "-v", f"{ws}:/workspace:rw",  # Mount workspace
        "-m", memory_limit,  # Memory limit
        "--cpus", cpu_limit,  # CPU limit
        "--pids-limit", "100",  # Process limit
    ]

    if not network:
        args.append("--network=none")

    # Environment variables
    if env_vars:
        for key, val in env_vars.items():
            args.extend(["-e", f"{key}={val}"])

    # Image and command
    args.extend([image, "bash", "-c", command])

    return args


def run_sandboxed(
    command: str,
    workspace: str = None,
    timeout: int = 30,
    network: bool = False,
    image: str = "python:3.12-slim",
) -> Dict:
    """
    Run a command in a sandboxed container.

    Falls back to direct subprocess if no container runtime is available.
    """
    runtime = detect_runtime()

    if runtime:
        return _run_container(command, workspace, timeout, network, image, runtime)
    else:
        logger.warning("No container runtime found, running unsandboxed")
        return _run_direct(command, workspace, timeout)


def _run_container(
    command: str,
    workspace: str,
    timeout: int,
    network: bool,
    image: str,
    runtime: str,
) -> Dict:
    """Run command in a container."""
    ws = workspace or str(WORKSPACE)
    Path(ws).mkdir(parents=True, exist_ok=True)

    args = build_exec_args(
        command=command,
        workspace=ws,
        runtime=runtime,
        image=image,
        network=network,
        timeout=timeout,
    )

    try:
        result = subprocess.run(
            args,
            capture_output=True,
            text=True,
            timeout=timeout + 10,  # Extra time for container startup
        )

        return {
            "stdout": result.stdout[:10000],
            "stderr": result.stderr[:5000],
            "exit_code": result.returncode,
            "sandboxed": True,
            "runtime": runtime,
        }

    except subprocess.TimeoutExpired:
        # Kill the container
        container_name = f"seraph-sandbox-{int(time.time())}"
        subprocess.run([runtime, "kill", container_name], capture_output=True, timeout=5)
        return {
            "error": f"Command timed out after {timeout}s",
            "sandboxed": True,
            "runtime": runtime,
        }

    except Exception as e:
        logger.error(f"Sandbox exec error: {e}")
        return {"error": str(e), "sandboxed": True}


def _run_direct(command: str, workspace: str, timeout: int) -> Dict:
    """Fallback: run command directly (no sandbox). Uses shell but with blocklist."""
    ws = workspace or str(WORKSPACE)
    Path(ws).mkdir(parents=True, exist_ok=True)

    # Security: block dangerous commands even in fallback mode
    blocked = ["rm -rf /", "dd if=/dev", "mkfs", "shutdown", "reboot", "poweroff"]
    for b in blocked:
        if b in command:
            return {"error": f"BLOCKED: {b}", "sandboxed": False}

    try:
        import shlex
        # Use shlex.split to avoid shell injection where possible
        # Fall back to shell=True only for pipes/redirects
        needs_shell = any(c in command for c in ["|", ">", "<", "&&", "||", ";", "`", "$(" ])
        if needs_shell:
            args = command
            use_shell = True
        else:
            args = shlex.split(command)
            use_shell = False

        result = subprocess.run(
            args,
            shell=use_shell,
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=ws,
        )
        return {
            "stdout": result.stdout[:10000],
            "stderr": result.stderr[:5000],
            "exit_code": result.returncode,
            "sandboxed": False,
        }

    except subprocess.TimeoutExpired:
        return {"error": f"Command timed out after {timeout}s", "sandboxed": False}
    except Exception as e:
        return {"error": str(e), "sandboxed": False}
