"""
Seraph Secrets Manager — secure credential storage and rotation.

Features:
- Multi-source resolution: env vars > .env file > secrets store > vault
- Degraded mode: keep running on last-known-good if secrets fail
- Secret rotation tracking
- Runtime secret resolution (no restart needed)
- Never log secret values
"""

import os
import json
import time
import logging
import hashlib
from typing import Dict, Optional, Any
from pathlib import Path
from dataclasses import dataclass, field

logger = logging.getLogger("seraph.secrets")

SERAPH_DIR = Path.home() / ".seraph"
SECRETS_PATH = SERAPH_DIR / "secrets.json"  # Encrypted at rest
SECRETS_SNAPSHOT_PATH = SERAPH_DIR / ".secrets_snapshot.json"  # Last known good


@dataclass
class SecretEntry:
    """A stored secret."""
    key: str
    value: str  # Never logged
    source: str  # "env", "dotenv", "store", "vault"
    last_rotated: float = 0.0
    expires_at: float = 0.0  # 0 = never expires
    provider: str = ""  # Which provider this key is for


@dataclass
class SecretsSnapshot:
    """Point-in-time snapshot of all resolved secrets."""
    secrets: Dict[str, SecretEntry] = field(default_factory=dict)
    resolved_at: float = 0.0
    is_degraded: bool = False
    degraded_reason: str = ""


class SecretsManager:
    """
    Manages secrets with multi-source resolution and degraded mode.

    Resolution priority:
    1. Environment variables (highest — always wins)
    2. .env file
    3. Secrets store (~/.seraph/secrets.json)
    4. Last-known-good snapshot (degraded mode)
    """

    def __init__(self):
        self._active_snapshot: Optional[SecretsSnapshot] = None
        self._last_good_snapshot: Optional[SecretsSnapshot] = None
        self._store: Dict[str, SecretEntry] = {}
        self._env_loaded = False
        self._load_store()

    def _load_store(self):
        """Load the secrets store from disk."""
        if SECRETS_PATH.exists():
            try:
                with open(SECRETS_PATH) as f:
                    data = json.load(f)
                for key, entry_data in data.items():
                    self._store[key] = SecretEntry(**entry_data)
            except Exception as e:
                logger.warning(f"Failed to load secrets store: {e}")

        # Load last-known-good snapshot
        if SECRETS_SNAPSHOT_PATH.exists():
            try:
                with open(SECRETS_SNAPSHOT_PATH) as f:
                    data = json.load(f)
                secrets = {}
                for key, entry_data in data.get("secrets", {}).items():
                    secrets[key] = SecretEntry(**entry_data)
                self._last_good_snapshot = SecretsSnapshot(
                    secrets=secrets,
                    resolved_at=data.get("resolved_at", 0),
                )
            except Exception:
                pass

    def resolve(self) -> SecretsSnapshot:
        """
        Resolve all secrets from all sources.

        Returns a snapshot. If resolution fails, returns last-known-good
        (degraded mode) rather than crashing.
        """
        try:
            snapshot = self._do_resolve()
            # Save as last-known-good
            self._active_snapshot = snapshot
            self._last_good_snapshot = snapshot
            self._save_snapshot(snapshot)
            return snapshot

        except Exception as e:
            logger.error(f"Secret resolution failed: {e}")
            if self._last_good_snapshot:
                logger.warning("Using last-known-good secrets snapshot (degraded mode)")
                degraded = SecretsSnapshot(
                    secrets=self._last_good_snapshot.secrets,
                    resolved_at=self._last_good_snapshot.resolved_at,
                    is_degraded=True,
                    degraded_reason=str(e),
                )
                self._active_snapshot = degraded
                return degraded

            raise RuntimeError(f"Secret resolution failed with no fallback: {e}")

    def _do_resolve(self) -> SecretsSnapshot:
        """Actually resolve secrets from all sources."""
        secrets: Dict[str, SecretEntry] = {}

        # Load .env files
        for env_path in [SERAPH_DIR / ".env", Path.cwd() / ".env"]:
            if env_path.exists():
                self._load_dotenv(env_path, secrets)

        # Load from store
        for key, entry in self._store.items():
            if key not in secrets:
                secrets[key] = entry

        # Override with environment variables (highest priority)
        known_keys = {
            "OPENAI_API_KEY", "ANTHROPIC_API_KEY", "GOOGLE_API_KEY",
            "DEEPSEEK_API_KEY", "GROQ_API_KEY", "TOGETHER_API_KEY",
            "XAI_API_KEY", "MISTRAL_API_KEY", "OPENROUTER_API_KEY",
            "FIREWORKS_API_KEY", "NVIDIA_API_KEY", "VENICE_API_KEY",
            "GITHUB_TOKEN", "AZURE_OPENAI_API_KEY", "AZURE_OPENAI_ENDPOINT",
            "AWS_ACCESS_KEY_ID", "AWS_SECRET_ACCESS_KEY", "AWS_REGION",
            "CLOUDFLARE_API_TOKEN", "CLOUDFLARE_ACCOUNT_ID",
            "SERAPH_TELEGRAM_TOKEN", "SERAPH_DISCORD_TOKEN",
            "MOONSHOT_API_KEY", "QWEN_API_KEY", "STEPFUN_API_KEY",
            "PERPLEXITY_API_KEY", "MINIMAX_API_KEY", "VOLCENGINE_API_KEY",
        }
        for key in known_keys:
            val = os.environ.get(key, "")
            if val:
                secrets[key] = SecretEntry(
                    key=key, value=val, source="env",
                    last_rotated=time.time(),
                )

        return SecretsSnapshot(
            secrets=secrets,
            resolved_at=time.time(),
        )

    def _load_dotenv(self, path: Path, secrets: Dict[str, SecretEntry]):
        """Load secrets from a .env file."""
        try:
            with open(path) as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith("#") and "=" in line:
                        key, value = line.split("=", 1)
                        key = key.strip()
                        value = value.strip().strip("'\"")
                        if value:
                            secrets[key] = SecretEntry(
                                key=key, value=value, source="dotenv",
                                last_rotated=time.time(),
                            )
        except Exception as e:
            logger.warning(f"Failed to load {path}: {e}")

    def get(self, key: str) -> Optional[str]:
        """Get a secret value. Never returns None for required keys — use get_or_raise."""
        if self._active_snapshot:
            entry = self._active_snapshot.secrets.get(key)
            if entry:
                return entry.value
        return os.environ.get(key, "")

    def get_or_raise(self, key: str) -> str:
        """Get a secret value or raise if not found."""
        val = self.get(key)
        if not val:
            raise ValueError(f"Required secret not found: {key}")
        return val

    def set(self, key: str, value: str, provider: str = ""):
        """Store a secret in the persistent store."""
        self._store[key] = SecretEntry(
            key=key, value=value, source="store",
            last_rotated=time.time(), provider=provider,
        )
        self._save_store()

    def delete(self, key: str):
        """Remove a secret from the store."""
        self._store.pop(key, None)
        self._save_store()

    def list_keys(self) -> list:
        """List all available secret keys (values redacted)."""
        if not self._active_snapshot:
            self.resolve()
        return [
            {
                "key": entry.key,
                "source": entry.source,
                "provider": entry.provider,
                "has_value": bool(entry.value),
                "masked": entry.value[:4] + "***" if len(entry.value) > 4 else "***",
            }
            for entry in (self._active_snapshot.secrets.values() if self._active_snapshot else [])
        ]

    def is_degraded(self) -> bool:
        """Check if running in degraded mode."""
        return self._active_snapshot.is_degraded if self._active_snapshot else False

    def _save_store(self):
        """Save the secrets store to disk."""
        try:
            SERAPH_DIR.mkdir(parents=True, exist_ok=True)
            data = {
                key: {
                    "key": e.key, "value": e.value, "source": e.source,
                    "last_rotated": e.last_rotated, "expires_at": e.expires_at,
                    "provider": e.provider,
                }
                for key, e in self._store.items()
            }
            tmp = str(SECRETS_PATH) + ".tmp"
            with open(tmp, "w") as f:
                json.dump(data, f, indent=2)
            os.replace(tmp, str(SECRETS_PATH))
        except Exception as e:
            logger.error(f"Failed to save secrets store: {e}")

    def _save_snapshot(self, snapshot: SecretsSnapshot):
        """Save last-known-good snapshot."""
        try:
            SERAPH_DIR.mkdir(parents=True, exist_ok=True)
            data = {
                "resolved_at": snapshot.resolved_at,
                "secrets": {
                    key: {
                        "key": e.key, "value": e.value, "source": e.source,
                        "last_rotated": e.last_rotated, "expires_at": e.expires_at,
                        "provider": e.provider,
                    }
                    for key, e in snapshot.secrets.items()
                },
            }
            tmp = str(SECRETS_SNAPSHOT_PATH) + ".tmp"
            with open(tmp, "w") as f:
                json.dump(data, f, indent=2)
            os.replace(tmp, str(SECRETS_SNAPSHOT_PATH))
        except Exception as e:
            logger.warning(f"Failed to save secrets snapshot: {e}")


# Singleton
_manager: Optional[SecretsManager] = None


def get_secrets_manager() -> SecretsManager:
    global _manager
    if _manager is None:
        _manager = SecretsManager()
    return _manager
