"""
Seraph Rule Enforcer — hard rules that the AI cannot bypass.

Unlike soft instructions in the system prompt, these are enforced at the code level.
If a rule blocks an action, the LLM never sees the result — it's intercepted before execution.
"""

import json
import logging
import re
from pathlib import Path
from typing import Dict, List, Optional, Tuple

logger = logging.getLogger("seraph.rules")

RULES_DIR = Path.home() / ".seraph" / "rules"


class Rule:
    """A single enforceable rule."""
    def __init__(self, name: str, description: str, action: str = "block",
                 tool_match: str = "*", pattern: str = "", enabled: bool = True):
        self.name = name
        self.description = description
        self.action = action  # "block" or "warn"
        self.tool_match = tool_match  # tool name or "*" for all
        self.pattern = pattern  # regex pattern to match in arguments
        self.enabled = enabled

    def matches(self, tool_name: str, arguments: Dict) -> bool:
        """Check if this rule applies to a tool call."""
        if not self.enabled:
            return False

        # Check tool match
        if self.tool_match != "*" and self.tool_match != tool_name:
            return False

        # Check pattern against arguments
        if self.pattern:
            args_str = json.dumps(arguments)
            if not re.search(self.pattern, args_str, re.IGNORECASE):
                return False

        return True

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "description": self.description,
            "action": self.action,
            "tool_match": self.tool_match,
            "pattern": self.pattern,
            "enabled": self.enabled,
        }

    @classmethod
    def from_dict(cls, d: dict) -> 'Rule':
        return cls(**d)


class RuleEnforcer:
    """Manages and enforces rules on tool calls."""

    def __init__(self):
        self.rules: List[Rule] = []
        self._load_rules()
        self._add_defaults()

    def _load_rules(self):
        """Load rules from disk."""
        RULES_DIR.mkdir(parents=True, exist_ok=True)
        rules_file = RULES_DIR / "rules.json"
        if rules_file.exists():
            try:
                data = json.loads(rules_file.read_text())
                self.rules = [Rule.from_dict(r) for r in data]
                logger.info(f"Loaded {len(self.rules)} rules")
            except Exception as e:
                logger.error(f"Failed to load rules: {e}")

    def _add_defaults(self):
        """Add default safety rules if none exist."""
        if not self.rules:
            self.rules = [
                Rule(
                    name="block-rm-rf",
                    description="Block destructive rm -rf commands",
                    action="block",
                    tool_match="terminal",
                    pattern=r"rm\s+-rf\s+/",
                ),
                Rule(
                    name="block-env-overwrite",
                    description="Block overwriting .env files with cat >",
                    action="block",
                    tool_match="terminal",
                    pattern=r"cat\s*>\s*.*\.env",
                ),
                Rule(
                    name="block-format-disk",
                    description="Block disk formatting commands",
                    action="block",
                    tool_match="terminal",
                    pattern=r"(format\s+|mkfs\s+|dd\s+if=)",
                ),
                Rule(
                    name="warn-ssh-root",
                    description="Warn when SSHing as root",
                    action="warn",
                    tool_match="ssh",
                    pattern=r"root@",
                ),
                Rule(
                    name="block-delete-db",
                    description="Block deleting database files",
                    action="block",
                    tool_match="terminal",
                    pattern=r"rm\s+.*\.(db|sqlite|json)",
                ),
            ]
            self._save_rules()

    def _save_rules(self):
        """Save rules to disk."""
        rules_file = RULES_DIR / "rules.json"
        rules_file.write_text(json.dumps([r.to_dict() for r in self.rules], indent=2))

    def check(self, tool_name: str, arguments: Dict) -> Tuple[bool, Optional[str]]:
        """
        Check if a tool call is allowed.

        Returns: (allowed, message)
        - (True, None) — allowed
        - (True, "warning message") — allowed but warned
        - (False, "block message") — blocked
        """
        for rule in self.rules:
            if rule.matches(tool_name, arguments):
                if rule.action == "block":
                    msg = f"BLOCKED by rule '{rule.name}': {rule.description}"
                    logger.warning(msg)
                    return False, msg
                elif rule.action == "warn":
                    msg = f"WARNING from rule '{rule.name}': {rule.description}"
                    logger.info(msg)
                    return True, msg

        return True, None

    def add_rule(self, rule: Rule):
        """Add a new rule."""
        # Remove existing rule with same name
        self.rules = [r for r in self.rules if r.name != rule.name]
        self.rules.append(rule)
        self._save_rules()
        logger.info(f"Added rule: {rule.name}")

    def remove_rule(self, name: str) -> bool:
        """Remove a rule by name."""
        before = len(self.rules)
        self.rules = [r for r in self.rules if r.name != name]
        if len(self.rules) < before:
            self._save_rules()
            return True
        return False

    def list_rules(self) -> List[Dict]:
        """List all rules."""
        return [r.to_dict() for r in self.rules]


# Singleton
_enforcer = None

def get_enforcer() -> RuleEnforcer:
    global _enforcer
    if _enforcer is None:
        _enforcer = RuleEnforcer()
    return _enforcer
