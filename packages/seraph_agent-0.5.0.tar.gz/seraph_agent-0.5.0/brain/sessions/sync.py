"""
Seraph Session Sync — share conversation context across channels.

When you talk on Telegram, then switch to Discord, Seraph remembers.
All channels share the same memory but maintain separate conversation threads.
Cross-channel context is available via memory search.
"""

import logging
from typing import Dict, List, Optional
from pathlib import Path

logger = logging.getLogger("seraph.sessions")

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from memory.store import get_memory


class SessionManager:
    """Manages sessions across all channels."""

    def __init__(self):
        self.memory = get_memory()
        self.active_sessions: Dict[str, dict] = {}

    def get_session(self, channel: str, chat_id: str) -> dict:
        """Get or create a session for a channel+chat combination."""
        key = f"{channel}_{chat_id}"
        if key not in self.active_sessions:
            self.active_sessions[key] = {
                "channel": channel,
                "chat_id": chat_id,
                "session_key": key,
                "message_count": 0,
                "created": True,
            }
        return self.active_sessions[key]

    def get_cross_channel_context(self, user_id: str, limit: int = 5) -> List[Dict]:
        """Get recent messages from ALL channels for a user.

        This is what enables continuity across Telegram → Discord → Slack.
        """
        # Search memory for recent messages from this user across all channels
        results = self.memory.conn.execute(
            """SELECT role, content, session_id, created_at
               FROM conversations
               WHERE chat_id = ?
               ORDER BY id DESC LIMIT ?""",
            (user_id, limit)
        ).fetchall()

        return [
            {
                "role": r["role"],
                "content": r["content"][:200],
                "channel": r["session_id"].split("_")[0] if "_" in r["session_id"] else "unknown",
                "time": r["created_at"],
            }
            for r in reversed(results)
        ]

    def get_summary(self) -> dict:
        """Get session summary across all channels."""
        total_msgs = self.memory.get_message_count()
        total_sessions = self.memory.get_session_count()

        # Count by channel
        channels = {}
        rows = self.memory.conn.execute(
            "SELECT session_id, COUNT(*) as cnt FROM conversations GROUP BY session_id"
        ).fetchall()
        for r in rows:
            sid = r["session_id"]
            channel = sid.split("_")[0] if "_" in sid else "unknown"
            channels[channel] = channels.get(channel, 0) + r["cnt"]

        return {
            "total_messages": total_msgs,
            "total_sessions": total_sessions,
            "channels": channels,
            "active_sessions": len(self.active_sessions),
        }


# Singleton
_manager = None

def get_session_manager() -> SessionManager:
    global _manager
    if _manager is None:
        _manager = SessionManager()
    return _manager
