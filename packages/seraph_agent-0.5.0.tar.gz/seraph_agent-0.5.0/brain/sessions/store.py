"""
Seraph Session Store — SQLite-backed session persistence.

Features:
- Session CRUD (create, read, update, delete)
- Message history persistence
- Session search (FTS5)
- Session archive
- Write locks (prevent concurrent writes)
- Transcript export
- Compaction state tracking
"""

import json
import time
import sqlite3
import logging
import os
from typing import Dict, List, Optional, Any
from pathlib import Path
from contextlib import contextmanager

logger = logging.getLogger("seraph.sessions")

SERAPH_DIR = Path.home() / ".seraph"
DB_PATH = SERAPH_DIR / "sessions.db"


class SessionStore:
    """SQLite-backed session persistence."""

    def __init__(self, db_path: Path = None):
        self.db_path = db_path or DB_PATH
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _init_db(self):
        """Initialize database schema."""
        with self._conn() as conn:
            conn.executescript("""
                PRAGMA journal_mode = WAL;
                PRAGMA busy_timeout = 5000;
                PRAGMA foreign_keys = ON;

                CREATE TABLE IF NOT EXISTS sessions (
                    id TEXT PRIMARY KEY,
                    title TEXT DEFAULT '',
                    agent_id TEXT DEFAULT 'main',
                    channel TEXT DEFAULT '',
                    user_id TEXT DEFAULT '',
                    model TEXT DEFAULT '',
                    provider TEXT DEFAULT '',
                    status TEXT DEFAULT 'active',
                    message_count INTEGER DEFAULT 0,
                    token_count INTEGER DEFAULT 0,
                    cost_usd REAL DEFAULT 0.0,
                    compaction_count INTEGER DEFAULT 0,
                    last_summary TEXT DEFAULT '',
                    created_at REAL NOT NULL,
                    updated_at REAL NOT NULL,
                    archived_at REAL DEFAULT 0
                );

                CREATE TABLE IF NOT EXISTS messages (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id TEXT NOT NULL,
                    role TEXT NOT NULL,
                    content TEXT NOT NULL,
                    tool_calls TEXT DEFAULT '[]',
                    tool_results TEXT DEFAULT '[]',
                    tokens INTEGER DEFAULT 0,
                    created_at REAL NOT NULL,
                    FOREIGN KEY (session_id) REFERENCES sessions(id) ON DELETE CASCADE
                );

                CREATE INDEX IF NOT EXISTS idx_messages_session
                    ON messages(session_id, created_at);

                CREATE INDEX IF NOT EXISTS idx_sessions_updated
                    ON sessions(updated_at DESC);

                CREATE INDEX IF NOT EXISTS idx_sessions_status
                    ON sessions(status);

                -- FTS5 for full-text search across messages
                CREATE VIRTUAL TABLE IF NOT EXISTS messages_fts USING fts5(
                    content, session_id UNINDEXED,
                    content='messages', content_rowid='id'
                );

                -- Triggers to keep FTS in sync
                CREATE TRIGGER IF NOT EXISTS messages_ai AFTER INSERT ON messages BEGIN
                    INSERT INTO messages_fts(rowid, content, session_id)
                    VALUES (new.id, new.content, new.session_id);
                END;

                CREATE TRIGGER IF NOT EXISTS messages_ad AFTER DELETE ON messages BEGIN
                    INSERT INTO messages_fts(messages_fts, rowid, content, session_id)
                    VALUES ('delete', old.id, old.content, old.session_id);
                END;

                CREATE TRIGGER IF NOT EXISTS messages_au AFTER UPDATE ON messages BEGIN
                    INSERT INTO messages_fts(messages_fts, rowid, content, session_id)
                    VALUES ('delete', old.id, old.content, old.session_id);
                    INSERT INTO messages_fts(rowid, content, session_id)
                    VALUES (new.id, new.content, new.session_id);
                END;
            """)

    @contextmanager
    def _conn(self):
        """Get a database connection."""
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    # ─── Session CRUD ──────────────────────────────────────────────

    def create_session(self, session_id: str, **kwargs) -> Dict:
        """Create a new session."""
        now = time.time()
        with self._conn() as conn:
            conn.execute(
                """INSERT INTO sessions (id, title, agent_id, channel, user_id,
                   model, provider, created_at, updated_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    session_id,
                    kwargs.get("title", ""),
                    kwargs.get("agent_id", "main"),
                    kwargs.get("channel", ""),
                    kwargs.get("user_id", ""),
                    kwargs.get("model", ""),
                    kwargs.get("provider", ""),
                    now, now,
                ),
            )
        return self.get_session(session_id)

    def get_session(self, session_id: str) -> Optional[Dict]:
        """Get a session by ID."""
        with self._conn() as conn:
            row = conn.execute(
                "SELECT * FROM sessions WHERE id = ?", (session_id,)
            ).fetchone()
            return dict(row) if row else None

    def list_sessions(self, status: str = "active", limit: int = 50,
                      offset: int = 0) -> List[Dict]:
        """List sessions, most recent first."""
        with self._conn() as conn:
            rows = conn.execute(
                """SELECT * FROM sessions WHERE status = ?
                   ORDER BY updated_at DESC LIMIT ? OFFSET ?""",
                (status, limit, offset),
            ).fetchall()
            return [dict(r) for r in rows]

    def update_session(self, session_id: str, **kwargs):
        """Update session metadata."""
        allowed = {"title", "model", "provider", "status", "message_count",
                    "token_count", "cost_usd", "compaction_count", "last_summary"}
        updates = {k: v for k, v in kwargs.items() if k in allowed}
        if not updates:
            return

        updates["updated_at"] = time.time()
        set_clause = ", ".join(f"{k} = ?" for k in updates)
        values = list(updates.values()) + [session_id]

        with self._conn() as conn:
            conn.execute(
                f"UPDATE sessions SET {set_clause} WHERE id = ?", values
            )

    def delete_session(self, session_id: str):
        """Delete a session and all its messages."""
        with self._conn() as conn:
            conn.execute("DELETE FROM sessions WHERE id = ?", (session_id,))

    def archive_session(self, session_id: str):
        """Archive a session (soft delete)."""
        with self._conn() as conn:
            conn.execute(
                "UPDATE sessions SET status = 'archived', archived_at = ? WHERE id = ?",
                (time.time(), session_id),
            )

    # ─── Messages ──────────────────────────────────────────────────

    def add_message(self, session_id: str, role: str, content: str,
                    tool_calls: list = None, tool_results: list = None,
                    tokens: int = 0):
        """Add a message to a session."""
        now = time.time()
        with self._conn() as conn:
            conn.execute(
                """INSERT INTO messages (session_id, role, content, tool_calls,
                   tool_results, tokens, created_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (
                    session_id, role, content,
                    json.dumps(tool_calls or []),
                    json.dumps(tool_results or []),
                    tokens, now,
                ),
            )
            # Update session counts
            conn.execute(
                """UPDATE sessions SET
                   message_count = message_count + 1,
                   token_count = token_count + ?,
                   updated_at = ?
                   WHERE id = ?""",
                (tokens, now, session_id),
            )

    def get_messages(self, session_id: str, limit: int = 0) -> List[Dict]:
        """Get all messages for a session."""
        with self._conn() as conn:
            query = "SELECT * FROM messages WHERE session_id = ? ORDER BY created_at"
            if limit > 0:
                query += f" DESC LIMIT {limit}"
                rows = conn.execute(query, (session_id,)).fetchall()
                return [dict(r) for r in reversed(rows)]
            else:
                rows = conn.execute(query, (session_id,)).fetchall()
                return [dict(r) for r in rows]

    def replace_messages(self, session_id: str, messages: List[Dict]):
        """Replace all messages in a session (used after compaction)."""
        with self._conn() as conn:
            conn.execute("DELETE FROM messages WHERE session_id = ?", (session_id,))
            now = time.time()
            for msg in messages:
                conn.execute(
                    """INSERT INTO messages (session_id, role, content, tool_calls,
                       tool_results, tokens, created_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?)""",
                    (
                        session_id,
                        msg.get("role", ""),
                        msg.get("content", ""),
                        json.dumps(msg.get("tool_calls", [])),
                        json.dumps(msg.get("tool_results", [])),
                        msg.get("tokens", 0),
                        msg.get("created_at", now),
                    ),
                )
            conn.execute(
                "UPDATE sessions SET message_count = ?, updated_at = ? WHERE id = ?",
                (len(messages), now, session_id),
            )

    # ─── Search ────────────────────────────────────────────────────

    def search(self, query: str, limit: int = 20) -> List[Dict]:
        """Full-text search across all messages."""
        with self._conn() as conn:
            rows = conn.execute(
                """SELECT m.*, s.title as session_title
                   FROM messages_fts f
                   JOIN messages m ON f.rowid = m.id
                   JOIN sessions s ON m.session_id = s.id
                   WHERE messages_fts MATCH ?
                   ORDER BY rank
                   LIMIT ?""",
                (query, limit),
            ).fetchall()
            return [dict(r) for r in rows]

    # ─── Export ─────────────────────────────────────────────────────

    def export_transcript(self, session_id: str) -> str:
        """Export a session as markdown transcript."""
        session = self.get_session(session_id)
        if not session:
            return ""

        messages = self.get_messages(session_id)
        lines = [
            f"# Session: {session.get('title', session_id)}",
            f"Created: {time.strftime('%Y-%m-%d %H:%M', time.localtime(session['created_at']))}",
            f"Model: {session.get('model', 'unknown')}",
            f"Messages: {len(messages)}",
            "",
        ]

        for msg in messages:
            role = msg["role"].upper()
            content = msg["content"]
            lines.append(f"## [{role}]")
            lines.append(content)
            lines.append("")

        return "\n".join(lines)

    # ─── Stats ─────────────────────────────────────────────────────

    def get_stats(self) -> Dict:
        """Get overall session stats."""
        with self._conn() as conn:
            row = conn.execute(
                """SELECT
                   COUNT(*) as total_sessions,
                   SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active,
                   SUM(CASE WHEN status = 'archived' THEN 1 ELSE 0 END) as archived,
                   SUM(message_count) as total_messages,
                   SUM(token_count) as total_tokens,
                   SUM(cost_usd) as total_cost
                   FROM sessions"""
            ).fetchone()
            return dict(row) if row else {}


# Singleton
_store: Optional[SessionStore] = None

def get_session_store() -> SessionStore:
    global _store
    if _store is None:
        _store = SessionStore()
    return _store
