"""
Seraph Control UI — REST API backend for the web dashboard.

Serves:
- Session management (list, view, delete, archive)
- Model selection and provider status
- Channel health monitoring
- Usage/cost tracking
- Plugin management
- Config editor
- Skill management
- Real-time events via SSE
"""

import json
import time
import logging
import asyncio
import os
from typing import Dict, List, Optional
from pathlib import Path
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
import threading

logger = logging.getLogger("seraph.control_ui")

SERAPH_DIR = Path.home() / ".seraph"
UI_DIST = Path(__file__).parent / "dist"  # Built frontend assets


UI_AUTH_TOKEN = os.getenv("SERAPH_UI_TOKEN", os.getenv("SERAPH_BRAIN_TOKEN", ""))


class ControlAPIHandler(BaseHTTPRequestHandler):
    """HTTP request handler for the Control UI API."""

    server_version = "Seraph/0.2.0"

    def log_message(self, format, *args):
        logger.debug(f"[ControlUI] {format % args}")

    def _check_auth(self) -> bool:
        """Check auth for API endpoints. Returns True if authorized."""
        if not UI_AUTH_TOKEN:
            return True  # No token = no auth required
        # Check header
        auth = self.headers.get("Authorization", "")
        if auth.replace("Bearer ", "") == UI_AUTH_TOKEN:
            return True
        # Check query param
        parsed = urlparse(self.path)
        params = parse_qs(parsed.query)
        if params.get("token", [""])[0] == UI_AUTH_TOKEN:
            return True
        return False

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        params = parse_qs(parsed.query)

        # ── API Routes ──
        if path == "/api/health":
            self._json_response(self._get_health())

        # Auth required for all other API endpoints
        elif path.startswith("/api/") and not self._check_auth():
            self._json_response({"error": "unauthorized"}, 401)

        elif path == "/api/sessions":
            self._json_response(self._get_sessions(params))

        elif path.startswith("/api/sessions/") and path.count("/") == 3:
            session_id = path.split("/")[3]
            self._json_response(self._get_session(session_id))

        elif path.startswith("/api/sessions/") and path.endswith("/messages"):
            session_id = path.split("/")[3]
            self._json_response(self._get_messages(session_id, params))

        elif path == "/api/models":
            self._json_response(self._get_models())

        elif path == "/api/providers":
            self._json_response(self._get_providers())

        elif path == "/api/channels":
            self._json_response(self._get_channels())

        elif path == "/api/usage":
            self._json_response(self._get_usage())

        elif path == "/api/plugins":
            self._json_response(self._get_plugins())

        elif path == "/api/skills":
            self._json_response(self._get_skills())

        elif path == "/api/config":
            self._json_response(self._get_config())

        elif path == "/api/secrets":
            self._json_response(self._get_secrets())

        elif path == "/api/memory":
            self._json_response(self._get_memory_stats())

        elif path == "/api/cron":
            self._json_response(self._get_cron_jobs())

        elif path == "/api/events":
            self._handle_sse()

        # ── Static Files (frontend) ──
        elif path == "/" or path == "/index.html":
            self._serve_file("index.html", "text/html")
        elif path.endswith(".js"):
            self._serve_file(path.lstrip("/"), "application/javascript")
        elif path.endswith(".css"):
            self._serve_file(path.lstrip("/"), "text/css")
        elif path.endswith(".svg"):
            self._serve_file(path.lstrip("/"), "image/svg+xml")
        else:
            # SPA fallback — serve index.html for client-side routing
            self._serve_file("index.html", "text/html")

    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path

        body = b""
        length = int(self.headers.get("Content-Length", 0))
        if length > 0:
            body = self.rfile.read(length)

        try:
            data = json.loads(body) if body else {}
        except json.JSONDecodeError:
            data = {}

        if path == "/api/sessions":
            self._json_response(self._create_session(data))

        elif path.startswith("/api/sessions/") and path.endswith("/archive"):
            session_id = path.split("/")[3]
            self._json_response(self._archive_session(session_id))

        elif path == "/api/config":
            self._json_response(self._update_config(data))

        elif path.startswith("/api/plugins/") and path.endswith("/enable"):
            plugin = path.split("/")[3]
            self._json_response(self._enable_plugin(plugin))

        elif path.startswith("/api/plugins/") and path.endswith("/disable"):
            plugin = path.split("/")[3]
            self._json_response(self._disable_plugin(plugin))

        elif path == "/api/chat":
            self._json_response(self._send_chat(data))

        else:
            self._json_response({"error": "Not found"}, 404)

    def do_DELETE(self):
        parsed = urlparse(self.path)
        path = parsed.path

        if path.startswith("/api/sessions/"):
            session_id = path.split("/")[3]
            self._json_response(self._delete_session(session_id))
        else:
            self._json_response({"error": "Not found"}, 404)

    def do_OPTIONS(self):
        self.send_response(200)
        self._set_cors()
        self.end_headers()

    # ─── API Implementations ──────────────────────────────────────

    def _get_health(self) -> dict:
        import platform
        return {
            "status": "running",
            "version": "0.2.0",
            "uptime_seconds": int(time.time() - getattr(self.server, 'start_time', time.time())),
            "platform": platform.system(),
            "python": platform.python_version(),
        }

    def _get_sessions(self, params: dict) -> dict:
        try:
            from sessions.store import get_session_store
            store = get_session_store()
            status = params.get("status", ["active"])[0]
            limit = int(params.get("limit", ["50"])[0])
            sessions = store.list_sessions(status=status, limit=limit)
            return {"sessions": sessions, "count": len(sessions)}
        except Exception as e:
            return {"sessions": [], "error": str(e)}

    def _get_session(self, session_id: str) -> dict:
        try:
            from sessions.store import get_session_store
            session = get_session_store().get_session(session_id)
            return session or {"error": "Session not found"}
        except Exception as e:
            return {"error": str(e)}

    def _get_messages(self, session_id: str, params: dict) -> dict:
        try:
            from sessions.store import get_session_store
            limit = int(params.get("limit", ["100"])[0])
            messages = get_session_store().get_messages(session_id, limit=limit)
            return {"messages": messages, "count": len(messages)}
        except Exception as e:
            return {"messages": [], "error": str(e)}

    def _get_models(self) -> dict:
        try:
            from models.router import ModelRouter
            router = ModelRouter()
            return {
                "models": router.list_models(),
                "providers": router.list_providers(),
            }
        except Exception as e:
            return {"error": str(e)}

    def _get_providers(self) -> dict:
        try:
            from agent.llm import list_providers
            providers = list_providers()
            # Check which have API keys set
            for p in providers:
                env_key = p.get("env_key", "")
                p["configured"] = bool(os.environ.get(env_key, ""))
            return {"providers": providers}
        except Exception as e:
            return {"error": str(e)}

    def _get_channels(self) -> dict:
        channels = []
        channel_configs = {
            "telegram": {"env": "SERAPH_TELEGRAM_TOKEN", "name": "Telegram"},
            "discord": {"env": "SERAPH_DISCORD_TOKEN", "name": "Discord"},
            "slack": {"env": "SERAPH_SLACK_BOT_TOKEN", "name": "Slack"},
            "whatsapp": {"env": "SERAPH_WHATSAPP_TOKEN", "name": "WhatsApp"},
        }
        for ch_id, cfg in channel_configs.items():
            channels.append({
                "id": ch_id,
                "name": cfg["name"],
                "configured": bool(os.environ.get(cfg["env"], "")),
                "status": "active" if os.environ.get(cfg["env"]) else "unconfigured",
            })
        return {"channels": channels}

    def _get_usage(self) -> dict:
        try:
            from tools.usage import get_usage_stats
            return get_usage_stats()
        except Exception:
            return {"today": {"requests": 0, "cost_usd": 0}, "total": {"requests": 0, "cost_usd": 0}}

    def _get_plugins(self) -> dict:
        try:
            from plugins.loader import list_plugins
            return {"plugins": list_plugins()}
        except Exception as e:
            return {"plugins": [], "error": str(e)}

    def _get_skills(self) -> dict:
        skills_dir = SERAPH_DIR / "skills"
        skills = []
        if skills_dir.exists():
            for skill_dir in sorted(skills_dir.iterdir()):
                if skill_dir.is_dir():
                    skill_md = skill_dir / "SKILL.md"
                    skills.append({
                        "name": skill_dir.name,
                        "has_definition": skill_md.exists(),
                        "files": len(list(skill_dir.glob("*"))),
                    })
        return {"skills": skills, "count": len(skills)}

    def _get_config(self) -> dict:
        try:
            from config import get_config
            return get_config().to_dict()
        except Exception as e:
            return {"error": str(e)}

    def _get_secrets(self) -> dict:
        try:
            from secrets.manager import get_secrets_manager
            sm = get_secrets_manager()
            return {
                "keys": sm.list_keys(),
                "degraded": sm.is_degraded(),
            }
        except Exception as e:
            return {"error": str(e)}

    def _get_memory_stats(self) -> dict:
        try:
            from memory.store import get_memory
            mem = get_memory()
            return {
                "messages": mem.get_message_count(),
                "sessions": mem.get_session_count(),
                "active_facts": len(mem.get_all_active()),
            }
        except Exception as e:
            return {"error": str(e)}

    def _get_cron_jobs(self) -> dict:
        try:
            from cron.scheduler import get_scheduler
            scheduler = get_scheduler()
            return {"jobs": scheduler.list_jobs()}
        except Exception as e:
            return {"jobs": [], "error": str(e)}

    def _create_session(self, data: dict) -> dict:
        try:
            from sessions.store import get_session_store
            session_id = data.get("id", f"ui_{int(time.time())}")
            store = get_session_store()
            return store.create_session(session_id, **data)
        except Exception as e:
            return {"error": str(e)}

    def _archive_session(self, session_id: str) -> dict:
        try:
            from sessions.store import get_session_store
            get_session_store().archive_session(session_id)
            return {"ok": True, "archived": session_id}
        except Exception as e:
            return {"error": str(e)}

    def _delete_session(self, session_id: str) -> dict:
        try:
            from sessions.store import get_session_store
            get_session_store().delete_session(session_id)
            return {"ok": True, "deleted": session_id}
        except Exception as e:
            return {"error": str(e)}

    def _update_config(self, data: dict) -> dict:
        try:
            from config import get_config
            cfg = get_config()
            for key, value in data.items():
                cfg.set(key, value)
            cfg.save()
            return {"ok": True, "updated": list(data.keys())}
        except Exception as e:
            return {"error": str(e)}

    def _enable_plugin(self, name: str) -> dict:
        try:
            from plugins.loader import get_plugin_registry
            get_plugin_registry().enable_plugin(name)
            return {"ok": True, "enabled": name}
        except Exception as e:
            return {"error": str(e)}

    def _disable_plugin(self, name: str) -> dict:
        try:
            from plugins.loader import get_plugin_registry
            get_plugin_registry().disable_plugin(name)
            return {"ok": True, "disabled": name}
        except Exception as e:
            return {"error": str(e)}

    def _send_chat(self, data: dict) -> dict:
        # Route to brain
        return {"error": "Chat via control UI not yet implemented"}

    def _handle_sse(self):
        """Server-Sent Events endpoint for real-time updates."""
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Connection", "keep-alive")
        self._set_cors()
        self.end_headers()

        try:
            while True:
                # Send heartbeat every 15 seconds
                event = json.dumps({"type": "heartbeat", "time": time.time()})
                self.wfile.write(f"data: {event}\n\n".encode())
                self.wfile.flush()
                time.sleep(15)
        except (BrokenPipeError, ConnectionResetError):
            pass

    # ─── Helpers ──────────────────────────────────────────────────

    def _json_response(self, data: dict, status: int = 200):
        body = json.dumps(data, indent=2, default=str).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self._set_cors()
        self.end_headers()
        self.wfile.write(body)

    def _serve_file(self, filename: str, content_type: str):
        filepath = UI_DIST / filename
        if filepath.exists():
            body = filepath.read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        else:
            # Serve a minimal HTML if no built frontend
            self._serve_default_html()

    def _serve_default_html(self):
        html = DEFAULT_HTML.encode()
        self.send_response(200)
        self.send_header("Content-Type", "text/html")
        self.send_header("Content-Length", str(len(html)))
        self.end_headers()
        self.wfile.write(html)

    def _set_cors(self):
        # Security: restrict CORS to localhost origins only
        origin = self.headers.get("Origin", "")
        allowed = {"http://localhost:18802", "http://127.0.0.1:18802",
                    "http://localhost:3000", "http://127.0.0.1:3000"}
        if origin in allowed:
            self.send_header("Access-Control-Allow-Origin", origin)
        else:
            self.send_header("Access-Control-Allow-Origin", "http://localhost:18802")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")


# ─── Built-in Dashboard HTML ─────────────────────────────────────

DEFAULT_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Seraph Control</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { font-family: -apple-system, system-ui, sans-serif; background: #0a0a0f; color: #e0e0e0; }
  .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
  h1 { color: #7c3aed; margin-bottom: 20px; }
  .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 16px; margin-bottom: 24px; }
  .card { background: #1a1a2e; border: 1px solid #2a2a3e; border-radius: 12px; padding: 20px; }
  .card h2 { color: #a78bfa; font-size: 14px; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 12px; }
  .stat { font-size: 32px; font-weight: 700; color: #fff; }
  .stat-label { font-size: 12px; color: #888; margin-top: 4px; }
  .list { list-style: none; }
  .list li { padding: 8px 0; border-bottom: 1px solid #1a1a2e; font-size: 14px; }
  .badge { display: inline-block; padding: 2px 8px; border-radius: 12px; font-size: 11px; font-weight: 600; }
  .badge-green { background: #064e3b; color: #34d399; }
  .badge-gray { background: #1f2937; color: #9ca3af; }
  .badge-purple { background: #2e1065; color: #a78bfa; }
  table { width: 100%; border-collapse: collapse; }
  th, td { text-align: left; padding: 10px; border-bottom: 1px solid #1a1a2e; font-size: 13px; }
  th { color: #888; font-weight: 500; }
  #status { color: #34d399; }
  .section { margin-bottom: 32px; }
  .section h2 { color: #c4b5fd; margin-bottom: 12px; font-size: 18px; }
  a { color: #7c3aed; text-decoration: none; }
  a:hover { text-decoration: underline; }
</style>
</head>
<body>
<div class="container">
  <h1>⚡ Seraph Control</h1>
  <div class="grid">
    <div class="card">
      <h2>Status</h2>
      <div class="stat" id="status">Loading...</div>
      <div class="stat-label" id="uptime"></div>
    </div>
    <div class="card">
      <h2>Sessions</h2>
      <div class="stat" id="sessions">-</div>
      <div class="stat-label">Active conversations</div>
    </div>
    <div class="card">
      <h2>Today's Cost</h2>
      <div class="stat" id="cost">$0.00</div>
      <div class="stat-label" id="requests">0 requests</div>
    </div>
    <div class="card">
      <h2>Providers</h2>
      <div class="stat" id="providers">-</div>
      <div class="stat-label">Configured</div>
    </div>
  </div>

  <div class="section">
    <h2>Channels</h2>
    <table id="channels-table">
      <tr><th>Channel</th><th>Status</th></tr>
    </table>
  </div>

  <div class="section">
    <h2>Models</h2>
    <table id="models-table">
      <tr><th>Model</th><th>Provider</th><th>Quality</th><th>Cost</th></tr>
    </table>
  </div>

  <div class="section">
    <h2>Plugins</h2>
    <table id="plugins-table">
      <tr><th>Plugin</th><th>Status</th><th>Tools</th></tr>
    </table>
  </div>
</div>

<script>
async function load() {
  try {
    const [health, sessions, usage, providers, channels, models, plugins] = await Promise.all([
      fetch('/api/health').then(r => r.json()),
      fetch('/api/sessions').then(r => r.json()),
      fetch('/api/usage').then(r => r.json()),
      fetch('/api/providers').then(r => r.json()),
      fetch('/api/channels').then(r => r.json()),
      fetch('/api/models').then(r => r.json()),
      fetch('/api/plugins').then(r => r.json()),
    ]);

    document.getElementById('status').textContent = health.status || 'unknown';
    document.getElementById('uptime').textContent = 'Uptime: ' + Math.floor((health.uptime_seconds || 0) / 60) + 'm';
    document.getElementById('sessions').textContent = sessions.count || 0;
    document.getElementById('cost').textContent = '$' + ((usage.today || {}).cost_usd || 0).toFixed(4);
    document.getElementById('requests').textContent = ((usage.today || {}).requests || 0) + ' requests';

    const configured = (providers.providers || []).filter(p => p.configured).length;
    document.getElementById('providers').textContent = configured + '/' + (providers.providers || []).length;

    // Channels
    const ct = document.getElementById('channels-table');
    for (const ch of (channels.channels || [])) {
      const badge = ch.configured ? '<span class="badge badge-green">active</span>' : '<span class="badge badge-gray">unconfigured</span>';
      ct.innerHTML += '<tr><td>' + ch.name + '</td><td>' + badge + '</td></tr>';
    }

    // Models (top 10)
    const mt = document.getElementById('models-table');
    for (const m of (models.models || []).slice(0, 10)) {
      mt.innerHTML += '<tr><td>' + m.id + '</td><td><span class="badge badge-purple">' + m.provider + '</span></td><td>' + m.quality + '</td><td>' + m.cost + '</td></tr>';
    }

    // Plugins
    const pt = document.getElementById('plugins-table');
    for (const p of (plugins.plugins || [])) {
      const badge = p.loaded ? '<span class="badge badge-green">loaded</span>' : '<span class="badge badge-gray">failed</span>';
      pt.innerHTML += '<tr><td>' + p.name + '</td><td>' + badge + '</td><td>' + (p.tools || []).join(', ') + '</td></tr>';
    }
  } catch (e) {
    document.getElementById('status').textContent = 'Error: ' + e.message;
  }
}
load();
setInterval(load, 30000);
</script>
</body>
</html>"""


# ─── Server ──────────────────────────────────────────────────────

def start_control_ui(port: int = 18802, host: str = "127.0.0.1"):
    """Start the Control UI HTTP server."""
    server = HTTPServer((host, port), ControlAPIHandler)
    server.start_time = time.time()
    logger.info(f"Control UI: http://{host}:{port}")

    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    return server


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    port = int(os.environ.get("SERAPH_UI_PORT", "18802"))
    server = start_control_ui(port, "0.0.0.0")
    print(f"Control UI running at http://localhost:{port}")
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        server.shutdown()
