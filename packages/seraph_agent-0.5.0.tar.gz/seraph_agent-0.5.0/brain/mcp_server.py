"""
Seraph MCP Server — expose Seraph's tools as an MCP server.

This lets IDEs, Claude Code, and other MCP clients use Seraph's tools.
Supports stdio transport (for CLI/IDE integration).

Usage:
  python -m brain.mcp_server                    # stdio mode
  python -m brain.mcp_server --http :8080       # HTTP/SSE mode (future)
"""

import sys
import json
import logging
from typing import Dict, List, Any

logger = logging.getLogger("seraph.mcp_server")


class SeraphMCPServer:
    """MCP server that exposes Seraph's tools over stdio."""

    def __init__(self):
        self.tools: Dict[str, Dict] = {}
        self._load_tools()

    def _load_tools(self):
        """Load all Seraph tools as MCP tool definitions."""
        try:
            from tools.registry import get_all_tools
            all_tools = get_all_tools()
            for name, tool_def in all_tools.items():
                self.tools[name] = {
                    "name": name,
                    "description": tool_def.get("description", ""),
                    "inputSchema": tool_def.get("parameters", {"type": "object", "properties": {}}),
                }
            logger.info(f"MCP server loaded {len(self.tools)} tools")
        except Exception as e:
            logger.error(f"Failed to load tools for MCP: {e}")

    def handle_request(self, request: dict) -> dict:
        """Handle a JSON-RPC request."""
        method = request.get("method", "")
        params = request.get("params", {})
        req_id = request.get("id")

        if method == "initialize":
            return self._respond(req_id, {
                "protocolVersion": "2024-11-05",
                "capabilities": {
                    "tools": {"listChanged": False},
                },
                "serverInfo": {
                    "name": "seraph",
                    "version": "0.2.0",
                },
            })

        elif method == "tools/list":
            return self._respond(req_id, {
                "tools": list(self.tools.values()),
            })

        elif method == "tools/call":
            tool_name = params.get("name", "")
            arguments = params.get("arguments", {})
            return self._handle_tool_call(req_id, tool_name, arguments)

        elif method == "ping":
            return self._respond(req_id, {})

        elif method == "notifications/initialized":
            return None  # Notifications don't get responses

        else:
            return self._error(req_id, -32601, f"Method not found: {method}")

    def _handle_tool_call(self, req_id: Any, tool_name: str, arguments: dict) -> dict:
        """Execute a tool call and return the result."""
        if tool_name not in self.tools:
            return self._error(req_id, -32602, f"Unknown tool: {tool_name}")

        try:
            import asyncio
            from tools.registry import execute_tool

            loop = asyncio.new_event_loop()
            result = loop.run_until_complete(execute_tool(tool_name, arguments))
            loop.close()

            # Format as MCP content
            content = []
            if isinstance(result, dict):
                text = json.dumps(result, indent=2, default=str)
            else:
                text = str(result)

            content.append({"type": "text", "text": text})

            return self._respond(req_id, {
                "content": content,
                "isError": "error" in (result if isinstance(result, dict) else {}),
            })

        except Exception as e:
            return self._respond(req_id, {
                "content": [{"type": "text", "text": f"Tool error: {e}"}],
                "isError": True,
            })

    def _respond(self, req_id: Any, result: dict) -> dict:
        return {"jsonrpc": "2.0", "id": req_id, "result": result}

    def _error(self, req_id: Any, code: int, message: str) -> dict:
        return {"jsonrpc": "2.0", "id": req_id, "error": {"code": code, "message": message}}

    def run_stdio(self):
        """Run the MCP server over stdio (for Claude Code, IDEs, etc.)."""
        logger.info("Seraph MCP server starting (stdio mode)")

        for line in sys.stdin:
            line = line.strip()
            if not line:
                continue

            try:
                request = json.loads(line)
            except json.JSONDecodeError:
                continue

            response = self.handle_request(request)
            if response is not None:
                sys.stdout.write(json.dumps(response) + "\n")
                sys.stdout.flush()


def main():
    """Entry point for MCP server."""
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(name)s] %(message)s",
        stream=sys.stderr,  # Log to stderr, stdout is for MCP protocol
    )

    server = SeraphMCPServer()

    if "--http" in sys.argv:
        port = 8080
        for i, arg in enumerate(sys.argv):
            if arg == "--http" and i + 1 < len(sys.argv):
                try:
                    port = int(sys.argv[i + 1].lstrip(":"))
                except ValueError:
                    pass
        # TODO: HTTP/SSE transport
        logger.error("HTTP/SSE transport not yet implemented. Use stdio mode.")
        sys.exit(1)
    else:
        server.run_stdio()


if __name__ == "__main__":
    main()
