"""
Seraph Brain Server — full HTTP API.

The Gateway (Go) and external tools talk to this.
Handles: chat, memory, skills, tools, config, usage, sessions.
"""

import json
import asyncio
import logging
import sys
from pathlib import Path
from flask import Flask, request, jsonify

sys.path.insert(0, str(Path(__file__).parent))

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(name)s] %(levelname)s: %(message)s")
logger = logging.getLogger("seraph.brain")

app = Flask(__name__)

# ─── Auth Middleware ──────────────────────────────────────────────
import os
import functools

BRAIN_AUTH_TOKEN = os.environ.get("SERAPH_BRAIN_TOKEN", "")

def require_auth(f):
    """Require auth token on all API endpoints (except /health)."""
    @functools.wraps(f)
    def decorated(*args, **kwargs):
        if not BRAIN_AUTH_TOKEN:
            return f(*args, **kwargs)  # No token configured = no auth required
        # Check Authorization header
        auth = request.headers.get("Authorization", "")
        token = auth.replace("Bearer ", "")
        # Check query param fallback
        if not token:
            token = request.args.get("token", "")
        if token != BRAIN_AUTH_TOKEN:
            return jsonify({"error": "unauthorized"}), 401
        return f(*args, **kwargs)
    return decorated

# Lazy imports to avoid circular dependencies
def _get_llm():
    import os
    from agent.llm import LLMProvider
    return LLMProvider(
        provider=os.environ.get("SERAPH_PROVIDER", "openai"),
        model=os.environ.get("SERAPH_MODEL", "gpt-5.4"),
    )

# Session storage
_sessions = {}
_llm = None


@app.route("/health", methods=["GET"])
def health():
    from memory.store import get_memory
    from tools.registry import get_all_tools
    mem = get_memory()
    return jsonify({
        "status": "running",
        "version": "0.1.0",
        "sessions": len(_sessions),
        "tools": len(get_all_tools()),
        "memory_messages": mem.get_message_count(),
        "memory_sessions": mem.get_session_count(),
    })


@require_auth
@app.route("/api/v1/chat", methods=["POST"])
def chat():
    """Process a message through the LLM with tools."""
    data = request.json
    if not data or "text" not in data:
        return jsonify({"error": "missing 'text' field"}), 400

    global _llm
    if not _llm:
        _llm = _get_llm()

    session_id = data.get("session_id", "default")
    text = data["text"]
    user_id = data.get("user_id", "")

    # Get or create session history
    if session_id not in _sessions:
        _sessions[session_id] = []
    history = _sessions[session_id]
    history.append({"role": "user", "content": text})

    if len(history) > 20:
        _sessions[session_id] = history[-20:]
        history = _sessions[session_id]

    # Build system prompt
    from agent.prompt_builder import build_system_prompt
    system = build_system_prompt(user_id=user_id)

    # Call LLM with tools
    from tools.registry import get_openai_tool_schemas, execute_tool
    tools = get_openai_tool_schemas()

    total_tokens = 0
    for iteration in range(10):
        response = _llm.chat(messages=history, system=system, tools=tools if tools else None)
        total_tokens += response.input_tokens + response.output_tokens

        if not response.tool_calls:
            if response.text:
                history.append({"role": "assistant", "content": response.text})
                # Save to memory
                from memory.store import get_memory
                mem = get_memory()
                mem.save_message(session_id, user_id or session_id, "user", text)
                mem.save_message(session_id, user_id or session_id, "assistant", response.text)

            return jsonify({
                "text": response.text,
                "session_id": session_id,
                "tokens": total_tokens,
                "iterations": iteration + 1,
                "model": _llm.model,
            })

        # Execute tools
        tool_call_msg = {
            "role": "assistant", "content": response.text or None,
            "tool_calls": [{"id": tc["id"], "type": "function", "function": {"name": tc["name"], "arguments": json.dumps(tc["arguments"])}} for tc in response.tool_calls]
        }
        history.append(tool_call_msg)

        for tc in response.tool_calls:
            loop = asyncio.new_event_loop()
            try:
                result = loop.run_until_complete(execute_tool(tc["name"], tc["arguments"]))
            finally:
                loop.close()
            history.append({"role": "tool", "tool_call_id": tc["id"], "content": json.dumps(result, default=str)[:5000]})

    return jsonify({"text": "[Max iterations]", "session_id": session_id, "tokens": total_tokens})


@require_auth
@app.route("/api/v1/memory", methods=["GET"])
def get_memory_status():
    from memory.store import get_memory
    mem = get_memory()
    return jsonify({
        "active": mem.get_all_active(),
        "total_messages": mem.get_message_count(),
        "total_sessions": mem.get_session_count(),
    })


@require_auth
@app.route("/api/v1/memory/remember", methods=["POST"])
def remember():
    data = request.json
    from memory.store import get_memory
    mem = get_memory()
    mem.set_active(data["key"], data["value"])
    return jsonify({"status": "remembered", "key": data["key"]})


@require_auth
@app.route("/api/v1/memory/search", methods=["GET"])
def search_memory():
    query = request.args.get("q", "")
    limit = request.args.get("limit", 10, type=int)
    from memory.store import get_memory
    mem = get_memory()
    results = mem.search_history(query, limit)
    return jsonify({"query": query, "results": results})


@require_auth
@app.route("/api/v1/tools", methods=["GET"])
def list_tools():
    from tools.registry import get_all_tools
    tools = get_all_tools()
    return jsonify({
        "tools": [{"name": n, "description": t["description"]} for n, t in tools.items()],
        "count": len(tools),
    })


@require_auth
@app.route("/api/v1/tools/execute", methods=["POST"])
def execute_tool_api():
    data = request.json
    name = data.get("name", "")
    arguments = data.get("arguments", {})
    from tools.registry import execute_tool
    loop = asyncio.new_event_loop()
    try:
        result = loop.run_until_complete(execute_tool(name, arguments))
    finally:
        loop.close()
    return jsonify(result)


@require_auth
@app.route("/api/v1/skills", methods=["GET"])
def list_skills():
    from skills.generator import load_all_skills
    skills = load_all_skills()
    return jsonify({"skills": [{"name": s["name"], "description": s.get("description", "")} for s in skills], "count": len(skills)})


@require_auth
@app.route("/api/v1/rules", methods=["GET"])
def list_rules():
    from rules.enforcer import get_enforcer
    return jsonify({"rules": get_enforcer().list_rules()})


@require_auth
@app.route("/api/v1/usage", methods=["GET"])
def get_usage():
    from tools.usage import get_usage_stats
    return jsonify(get_usage_stats())


@require_auth
@app.route("/api/v1/sessions", methods=["GET"])
def list_sessions_api():
    return jsonify({
        "sessions": [{"id": sid, "messages": len(msgs)} for sid, msgs in _sessions.items()],
        "count": len(_sessions),
    })


@require_auth
@app.route("/api/v1/config", methods=["GET"])
def get_config():
    from config import get_config
    return jsonify(get_config().to_dict())


@require_auth
@app.route("/api/v1/model", methods=["GET", "POST"])
def model_api():
    global _llm
    if request.method == "POST":
        data = request.json
        new_model = data.get("model", "")
        if new_model and _llm:
            old = _llm.model
            _llm.model = new_model
            return jsonify({"old": old, "new": new_model})
        return jsonify({"error": "missing model field"}), 400
    return jsonify({"model": _llm.model if _llm else "not initialized"})


def main():
    # Load tools
    from tools import terminal, files, web, ssh, git, image, browser, voice, audit, email_tool, database, transcribe, usage, export
    from plugins.loader import load_plugins
    load_plugins()

    port = 18801
    logger.info(f"Seraph Brain API starting on port {port}")
    app.run(host="0.0.0.0", port=port, debug=False)


if __name__ == "__main__":
    main()
