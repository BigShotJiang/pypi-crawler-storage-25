"""
Seraph Context References — track files and URLs referenced in conversation.

Knows which files the agent has read, which URLs it fetched, so it can:
- Avoid re-reading the same file
- Track what's in context
- Provide "what have I looked at" summary
"""

import time
import logging
from typing import Dict, List, Set

logger = logging.getLogger("seraph.context_refs")


class ContextReferences:
    """Track files and URLs referenced in a conversation."""

    def __init__(self):
        self.files: Dict[str, dict] = {}   # path -> {read_at, size, preview}
        self.urls: Dict[str, dict] = {}    # url -> {fetched_at, status}
        self.snippets: List[dict] = []     # code snippets injected

    def add_file(self, path: str, size: int = 0, preview: str = ""):
        self.files[path] = {
            "read_at": time.time(),
            "size": size,
            "preview": preview[:100],
        }

    def add_url(self, url: str, status: int = 200):
        self.urls[url] = {
            "fetched_at": time.time(),
            "status": status,
        }

    def add_snippet(self, source: str, content: str, language: str = ""):
        self.snippets.append({
            "source": source,
            "preview": content[:200],
            "language": language,
            "added_at": time.time(),
        })

    def has_file(self, path: str) -> bool:
        return path in self.files

    def has_url(self, url: str) -> bool:
        return url in self.urls

    def get_summary(self) -> dict:
        return {
            "files_read": len(self.files),
            "urls_fetched": len(self.urls),
            "snippets": len(self.snippets),
            "files": list(self.files.keys())[-10:],
            "urls": list(self.urls.keys())[-10:],
        }

    def format_for_prompt(self) -> str:
        """Format references for injection into system prompt."""
        if not self.files and not self.urls:
            return ""

        parts = ["[Context References]"]
        if self.files:
            parts.append(f"Files read: {', '.join(list(self.files.keys())[-5:])}")
        if self.urls:
            parts.append(f"URLs fetched: {', '.join(list(self.urls.keys())[-5:])}")
        return "\n".join(parts)

    def reset(self):
        self.files.clear()
        self.urls.clear()
        self.snippets.clear()
