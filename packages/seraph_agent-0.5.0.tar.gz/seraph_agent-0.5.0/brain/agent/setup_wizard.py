"""
Seraph Setup Wizard — interactive first-run onboarding.

Walks new users through:
1. API key setup (pick provider + enter key)
2. Model selection
3. Channel configuration (Telegram, Discord, etc.)
4. Identity customization (SOUL.md)
5. First test message

Runs via CLI: seraph init --interactive
Or auto-triggers on first run if no config exists.
"""

import os
import sys
import logging
from pathlib import Path
from typing import Optional

logger = logging.getLogger("seraph.wizard")

SERAPH_DIR = Path.home() / ".seraph"


def run_wizard():
    """Run the interactive setup wizard."""
    print("\n╔═══════════════════════════════════════╗")
    print("║     SERAPH SETUP WIZARD               ║")
    print("║     Let's get you started.             ║")
    print("╚═══════════════════════════════════════╝\n")

    # Create directories
    for d in ["skills", "memory", "sessions", "plugins", "workspace", "cron"]:
        (SERAPH_DIR / d).mkdir(parents=True, exist_ok=True)

    # Step 1: Provider + API Key
    print("Step 1: Choose your AI provider\n")
    print("  1) Anthropic (Claude) — recommended")
    print("  2) OpenAI (GPT)")
    print("  3) Google (Gemini)")
    print("  4) DeepSeek")
    print("  5) OpenRouter (200+ models)")
    print("  6) Ollama (local, free)")
    print()

    choice = _prompt("Pick a number [1]: ", "1")
    provider_map = {
        "1": ("anthropic", "ANTHROPIC_API_KEY", "claude-sonnet-4-6"),
        "2": ("openai", "OPENAI_API_KEY", "gpt-4.1"),
        "3": ("google", "GOOGLE_API_KEY", "gemini-2.5-pro"),
        "4": ("deepseek", "DEEPSEEK_API_KEY", "deepseek-chat"),
        "5": ("openrouter", "OPENROUTER_API_KEY", "anthropic/claude-sonnet-4-6"),
        "6": ("ollama", "", "llama3.3"),
    }

    provider, env_key, default_model = provider_map.get(choice, provider_map["1"])
    print(f"\n  Provider: {provider}")

    # Get API key
    api_key = ""
    if env_key:
        existing = os.environ.get(env_key, "")
        if existing:
            print(f"  API key found in environment ({env_key})")
            api_key = existing
        else:
            api_key = _prompt(f"  Enter your {env_key}: ", "")
            if not api_key:
                print(f"  ⚠ No key provided. Set {env_key} later in ~/.seraph/.env")

    # Step 2: Model selection
    print(f"\nStep 2: Choose model [default: {default_model}]")
    model = _prompt(f"  Model [{default_model}]: ", default_model)

    # Step 3: Channels
    print("\nStep 3: Configure channels (optional)\n")

    tg_token = ""
    setup_tg = _prompt("  Set up Telegram? [y/N]: ", "n").lower()
    if setup_tg in ("y", "yes"):
        tg_token = _prompt("  Telegram bot token (from @BotFather): ", "")

    discord_token = ""
    setup_discord = _prompt("  Set up Discord? [y/N]: ", "n").lower()
    if setup_discord in ("y", "yes"):
        discord_token = _prompt("  Discord bot token: ", "")

    # Step 4: Write config
    print("\nStep 4: Writing configuration...")

    # Write .env
    env_lines = [f"SERAPH_PROVIDER={provider}", f"SERAPH_MODEL={model}"]
    if api_key and env_key:
        env_lines.append(f"{env_key}={api_key}")
    if tg_token:
        env_lines.append(f"SERAPH_TELEGRAM_TOKEN={tg_token}")
    if discord_token:
        env_lines.append(f"SERAPH_DISCORD_TOKEN={discord_token}")

    env_path = SERAPH_DIR / ".env"
    env_path.write_text("\n".join(env_lines) + "\n")
    print(f"  Written: {env_path}")

    # Write config.yaml
    config_lines = [
        f"provider: {provider}",
        f"model: {model}",
        "gateway_port: 18800",
        "brain_port: 18801",
        "",
        "memory:",
        "  enabled: true",
        "  search: fts5",
        "",
        "skills:",
        "  auto_generate: true",
        "",
        "audit:",
        "  enabled: true",
    ]
    if tg_token:
        config_lines.extend(["", "telegram:", "  enabled: true"])
    if discord_token:
        config_lines.extend(["", "discord:", "  enabled: true"])

    config_path = SERAPH_DIR / "config.yaml"
    config_path.write_text("\n".join(config_lines) + "\n")
    print(f"  Written: {config_path}")

    # Write default SOUL.md if not exists
    soul_path = SERAPH_DIR / "SOUL.md"
    if not soul_path.exists():
        soul_path.write_text(
            "# SOUL.md — Who I Am\n\n"
            "I am Seraph — a self-improving AI agent that audits itself.\n\n"
            "## Core Principles\n"
            "- Find every issue, fix every bug, re-audit until clean\n"
            "- Learn from experience and create reusable skills\n"
            "- Never say 'done' without proof\n"
            "- Do all work myself\n"
        )
        print(f"  Written: {soul_path}")

    # Step 5: Test
    print("\n✅ Setup complete!\n")
    print("  Run 'seraph run' to start your agent.")
    if tg_token:
        print("  Telegram bot will start automatically.")
    print("  Dashboard: http://localhost:18802")
    print()

    # Offer test
    test = _prompt("  Send a test message now? [Y/n]: ", "y").lower()
    if test in ("y", "yes", ""):
        _test_connection(provider, model, api_key, env_key)


def _prompt(message: str, default: str) -> str:
    """Prompt with default value."""
    try:
        value = input(message).strip()
        return value if value else default
    except (EOFError, KeyboardInterrupt):
        return default


def _test_connection(provider: str, model: str, api_key: str, env_key: str):
    """Test the LLM connection."""
    print("\n  Testing connection...", end=" ", flush=True)
    try:
        if env_key and api_key:
            os.environ[env_key] = api_key

        sys.path.insert(0, str(Path(__file__).parent.parent))
        from agent.llm import LLMProvider

        llm = LLMProvider(provider=provider, model=model)
        response = llm.chat(
            messages=[{"role": "user", "content": "Say 'Hello from Seraph!' in exactly those words."}],
            system="Respond with exactly the text requested.",
        )
        if response.text:
            print(f"✅\n  Response: {response.text[:100]}")
        else:
            print(f"⚠ Empty response")
    except Exception as e:
        print(f"❌\n  Error: {e}")
        print(f"  Check your API key and try again.")


def needs_setup() -> bool:
    """Check if setup wizard should run."""
    return not (SERAPH_DIR / "config.yaml").exists()


if __name__ == "__main__":
    run_wizard()
