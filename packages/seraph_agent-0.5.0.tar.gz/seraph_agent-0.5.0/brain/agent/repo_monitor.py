"""
Seraph Live Repo Monitor — watches git repos 24/7.

Auto-reviews PRs, diagnoses CI failures, alerts on bad pushes.
Runs as a background daemon checking repos on an interval.
"""

import os
import json
import time
import logging
import threading
import subprocess
from typing import Dict, List, Optional, Callable
from pathlib import Path

logger = logging.getLogger("seraph.repo_monitor")

SERAPH_DIR = Path.home() / ".seraph"


class RepoMonitor:
    """Watch git repos for changes and auto-respond."""

    def __init__(self):
        self.repos: Dict[str, Dict] = {}  # name -> {path, branch, last_commit}
        self.active = False
        self.check_interval = 300  # 5 minutes
        self.notify_fn: Optional[Callable] = None
        self._thread: Optional[threading.Thread] = None

    def add_repo(self, name: str, path: str, branch: str = "main") -> Dict:
        """Add a repo to monitor."""
        self.repos[name] = {
            "path": path, "branch": branch,
            "last_commit": self._get_head(path),
            "last_check": time.time(),
        }
        return {"watching": name, "path": path, "branch": branch}

    def remove_repo(self, name: str) -> Dict:
        if name in self.repos:
            del self.repos[name]
            return {"removed": name}
        return {"error": f"Not watching: {name}"}

    def start(self, notify_fn: Callable = None):
        """Start monitoring."""
        self.active = True
        self.notify_fn = notify_fn
        self._thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self._thread.start()
        logger.info(f"Repo monitor started: {len(self.repos)} repos")

    def stop(self):
        self.active = False

    def _monitor_loop(self):
        while self.active:
            for name, repo in list(self.repos.items()):
                try:
                    self._check_repo(name, repo)
                except Exception as e:
                    logger.warning(f"Repo check failed for {name}: {e}")
            time.sleep(self.check_interval)

    def _check_repo(self, name: str, repo: Dict):
        """Check a repo for new commits, PRs, CI status."""
        path = repo["path"]

        # Pull latest
        try:
            subprocess.run(["git", "-C", path, "fetch", "--quiet"],
                           capture_output=True, timeout=30)
        except Exception:
            return

        # Check for new commits
        current_head = self._get_head(path)
        if current_head and current_head != repo.get("last_commit"):
            # New commits
            diff = self._get_diff_summary(path, repo["last_commit"], current_head)
            repo["last_commit"] = current_head
            if diff and self.notify_fn:
                self.notify_fn(
                    f"[Repo: {name}] New commits detected:\n{diff}"
                )

        # Check CI status (if GitHub)
        try:
            result = subprocess.run(
                ["gh", "run", "list", "--repo", path, "--limit", "1", "--json", "status,conclusion,name"],
                capture_output=True, text=True, timeout=15,
            )
            if result.returncode == 0:
                runs = json.loads(result.stdout)
                if runs and runs[0].get("conclusion") == "failure":
                    if self.notify_fn:
                        self.notify_fn(
                            f"[Repo: {name}] CI FAILED: {runs[0].get('name', 'unknown')}"
                        )
        except Exception:
            pass

        repo["last_check"] = time.time()

    def _get_head(self, path: str) -> str:
        try:
            result = subprocess.run(
                ["git", "-C", path, "rev-parse", "HEAD"],
                capture_output=True, text=True, timeout=5,
            )
            return result.stdout.strip() if result.returncode == 0 else ""
        except Exception:
            return ""

    def _get_diff_summary(self, path: str, old: str, new: str) -> str:
        try:
            result = subprocess.run(
                ["git", "-C", path, "log", "--oneline", f"{old}..{new}"],
                capture_output=True, text=True, timeout=10,
            )
            return result.stdout.strip()[:500] if result.returncode == 0 else ""
        except Exception:
            return ""

    def list_repos(self) -> List[Dict]:
        return [
            {"name": n, "path": r["path"], "branch": r["branch"],
             "last_check": r.get("last_check", 0)}
            for n, r in self.repos.items()
        ]


_monitor = None

def get_repo_monitor() -> RepoMonitor:
    global _monitor
    if _monitor is None:
        _monitor = RepoMonitor()
    return _monitor
