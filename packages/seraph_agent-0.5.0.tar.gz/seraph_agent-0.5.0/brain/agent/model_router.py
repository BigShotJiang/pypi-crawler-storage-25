"""
Seraph Model Router — smart routing + failover + credential pool.

Three capabilities in one module:
1. Smart routing: auto-pick cheap vs strong model based on message complexity
2. Failover chain: if primary model fails, try fallbacks automatically
3. Credential pool: rotate API keys when one hits rate limits

Better than OpenClaw's (which only does failover) and Hermes's (which only
does smart routing). Seraph does all three.
"""

import os
import re
import time
import logging
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple

logger = logging.getLogger("seraph.model_router")

# Complexity keywords that demand the strong model
_COMPLEX_KEYWORDS = {
    "debug", "implement", "refactor", "analyze", "architecture",
    "design", "compare", "optimize", "review", "audit", "deploy",
    "investigate", "benchmark", "migrate", "security", "performance",
    "explain the code", "write a function", "fix the bug", "build",
    "create a script", "set up", "configure", "integrate",
}

# Simple patterns that can use the cheap model
_SIMPLE_PATTERNS = [
    r"^(hi|hello|hey|thanks|ok|yes|no|sure|got it)",
    r"^what (is|are|was|were) ",
    r"^(when|where|who) ",
    r"^how (do|does|can|to) ",
    r"^(tell me|remind me|show me)",
]


@dataclass
class ModelEntry:
    """A model with its credentials and health status."""
    provider: str       # openai, anthropic, openrouter
    model: str          # gpt-5.4, claude-opus-4-6
    api_key: str
    tier: str           # "strong", "standard", "cheap"
    max_tokens: int = 128000
    cost_per_1k_input: float = 0.0
    cost_per_1k_output: float = 0.0

    # Health tracking
    error_count: int = 0
    last_error: float = 0
    cooldown_until: float = 0
    total_requests: int = 0

    def is_available(self) -> bool:
        """Check if model is available (not in cooldown)."""
        if self.cooldown_until > time.time():
            return False
        return True

    def record_success(self):
        self.error_count = 0
        self.total_requests += 1

    def record_failure(self):
        self.error_count += 1
        self.last_error = time.time()
        self.total_requests += 1
        # Exponential backoff: 30s, 60s, 120s, 300s max
        backoff = min(300, 30 * (2 ** min(self.error_count - 1, 4)))
        self.cooldown_until = time.time() + backoff
        logger.warning(f"Model {self.model} failed ({self.error_count}x), cooldown {backoff}s")


class ModelRouter:
    """Routes requests to the best available model."""

    def __init__(self):
        self.models: List[ModelEntry] = []
        self.smart_routing_enabled = True
        self._load_from_env()

    def _load_from_env(self):
        """Load models from environment variables."""
        # Primary model
        provider = os.environ.get("SERAPH_PROVIDER", "openai")
        model = os.environ.get("SERAPH_MODEL", "gpt-5.4")
        api_key = ""

        if provider == "openai":
            api_key = os.environ.get("OPENAI_API_KEY", "")
        elif provider == "anthropic":
            api_key = os.environ.get("ANTHROPIC_API_KEY", "")
        elif provider == "openrouter":
            api_key = os.environ.get("OPENROUTER_API_KEY", "")

        if api_key:
            self.models.append(ModelEntry(
                provider=provider, model=model, api_key=api_key, tier="strong",
            ))

        # Cheap model for simple questions (if available)
        cheap_model = os.environ.get("SERAPH_CHEAP_MODEL", "")
        cheap_provider = os.environ.get("SERAPH_CHEAP_PROVIDER", provider)
        if cheap_model:
            cheap_key = ""
            if cheap_provider == "openai":
                cheap_key = os.environ.get("OPENAI_API_KEY", "")
            elif cheap_provider == "anthropic":
                cheap_key = os.environ.get("ANTHROPIC_API_KEY", "")
            elif cheap_provider == "openrouter":
                cheap_key = os.environ.get("OPENROUTER_API_KEY", "")

            if cheap_key:
                self.models.append(ModelEntry(
                    provider=cheap_provider, model=cheap_model, api_key=cheap_key, tier="cheap",
                ))

        # Fallback models
        fallback_str = os.environ.get("SERAPH_FALLBACK_MODELS", "")
        if fallback_str:
            for entry in fallback_str.split(","):
                entry = entry.strip()
                if "/" in entry:
                    fb_provider, fb_model = entry.split("/", 1)
                    fb_key = ""
                    if fb_provider == "openai":
                        fb_key = os.environ.get("OPENAI_API_KEY", "")
                    elif fb_provider == "anthropic":
                        fb_key = os.environ.get("ANTHROPIC_API_KEY", "")
                    elif fb_provider == "openrouter":
                        fb_key = os.environ.get("OPENROUTER_API_KEY", "")
                    if fb_key:
                        self.models.append(ModelEntry(
                            provider=fb_provider, model=fb_model, api_key=fb_key, tier="standard",
                        ))

        logger.info(f"Model router: {len(self.models)} models loaded")

    def add_model(self, provider: str, model: str, api_key: str, tier: str = "standard"):
        """Add a model to the pool."""
        self.models.append(ModelEntry(
            provider=provider, model=model, api_key=api_key, tier=tier,
        ))

    def classify_complexity(self, message: str) -> str:
        """
        Classify message complexity: 'simple', 'moderate', 'complex'.

        Used for smart routing to save costs on simple questions.
        """
        if not message:
            return "moderate"

        msg_lower = message.lower().strip()

        # Short messages are usually simple
        if len(msg_lower) < 30:
            for pattern in _SIMPLE_PATTERNS:
                if re.match(pattern, msg_lower):
                    return "simple"

        # Check for complexity keywords
        complexity_score = 0
        for keyword in _COMPLEX_KEYWORDS:
            if keyword in msg_lower:
                complexity_score += 1

        # Tool-calling indicators
        if any(w in msg_lower for w in ["```", "code", "function", "class", "error", "traceback"]):
            complexity_score += 2

        # Long messages with code are complex
        if len(message) > 500:
            complexity_score += 1

        if complexity_score >= 3:
            return "complex"
        elif complexity_score >= 1:
            return "moderate"
        return "simple"

    def select_model(self, message: str = "", require_tools: bool = False) -> Optional[ModelEntry]:
        """
        Select the best available model for a request.

        Smart routing: simple questions use cheap model, complex use strong.
        Failover: if selected model is in cooldown, try next available.
        """
        if not self.models:
            return None

        # Determine desired tier
        if self.smart_routing_enabled and not require_tools:
            complexity = self.classify_complexity(message)
            if complexity == "simple":
                desired_tier = "cheap"
            elif complexity == "complex":
                desired_tier = "strong"
            else:
                desired_tier = "standard"
        else:
            desired_tier = "strong"

        # Try desired tier first
        for entry in self.models:
            if entry.tier == desired_tier and entry.is_available():
                return entry

        # Fallback: try any available model (prefer strong > standard > cheap)
        for tier in ["strong", "standard", "cheap"]:
            for entry in self.models:
                if entry.tier == tier and entry.is_available():
                    return entry

        # All in cooldown — return the one with shortest remaining cooldown
        if self.models:
            available_soonest = min(self.models, key=lambda m: m.cooldown_until)
            return available_soonest

        return None

    def get_failover(self, failed_model: str) -> Optional[ModelEntry]:
        """Get the next available model after a failure."""
        for entry in self.models:
            if entry.model != failed_model and entry.is_available():
                return entry
        return None

    def get_status(self) -> Dict:
        """Get router status for /status command."""
        return {
            "models": len(self.models),
            "smart_routing": self.smart_routing_enabled,
            "entries": [
                {
                    "model": m.model,
                    "provider": m.provider,
                    "tier": m.tier,
                    "available": m.is_available(),
                    "errors": m.error_count,
                    "requests": m.total_requests,
                }
                for m in self.models
            ],
        }


# Singleton
_router = None

def get_router() -> ModelRouter:
    global _router
    if _router is None:
        _router = ModelRouter()
    return _router
