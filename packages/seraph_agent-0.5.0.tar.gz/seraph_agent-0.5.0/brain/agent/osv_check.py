"""
Seraph OSV Malware Check — scan packages for known malware before installing.

Queries Google's OSV (Open Source Vulnerabilities) API to check if an npm/pip
package has any MAL-* advisories (confirmed malware). Regular CVEs are ignored.

Free, public API. ~300ms latency. Fail-open on network errors.
"""

import json
import logging
import re
import urllib.request
from typing import Optional, Tuple

logger = logging.getLogger("seraph.osv")

OSV_API = "https://api.osv.dev/v1/query"


def check_package(name: str, ecosystem: str = "npm") -> Tuple[bool, Optional[str]]:
    """
    Check a package for known malware.

    Returns (safe, reason). safe=True means no malware found.
    Fail-open: returns (True, None) on network errors.
    """
    # Normalize ecosystem
    eco_map = {"npm": "npm", "pip": "PyPI", "pypi": "PyPI", "cargo": "crates.io",
               "go": "Go", "maven": "Maven", "nuget": "NuGet", "rubygems": "RubyGems"}
    osv_ecosystem = eco_map.get(ecosystem.lower(), ecosystem)

    body = json.dumps({"package": {"name": name, "ecosystem": osv_ecosystem}}).encode()

    try:
        req = urllib.request.Request(OSV_API, data=body,
            headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read())

        vulns = data.get("vulns", [])
        malware = [v for v in vulns if any(
            a.startswith("MAL-") for a in v.get("aliases", [])
        )]

        if malware:
            ids = [v.get("id", "?") for v in malware[:3]]
            summary = malware[0].get("summary", "Known malware")
            return False, f"MALWARE DETECTED: {', '.join(ids)} — {summary}"

        return True, None

    except Exception as e:
        logger.debug(f"OSV check failed for {name}: {e}")
        return True, None  # Fail-open


def check_mcp_package(command: str) -> Tuple[bool, Optional[str]]:
    """Check an MCP server command for malware before launching."""
    # Extract package name from npx/uvx commands
    parts = command.strip().split()
    if not parts:
        return True, None

    pkg = None
    eco = "npm"

    if parts[0] in ("npx", "npm"):
        # npx @scope/package or npx package
        for p in parts[1:]:
            if not p.startswith("-"):
                pkg = p.split("@")[0] if "@" in p and not p.startswith("@") else p
                eco = "npm"
                break
    elif parts[0] in ("uvx", "pip", "pipx"):
        for p in parts[1:]:
            if not p.startswith("-"):
                pkg = p.split("==")[0].split(">=")[0]
                eco = "pip"
                break

    if not pkg:
        return True, None

    return check_package(pkg, eco)
