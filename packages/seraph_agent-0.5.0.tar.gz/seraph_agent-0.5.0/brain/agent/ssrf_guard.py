"""
Seraph SSRF Guard — block requests to internal/dangerous endpoints.

Prevents tool calls from accessing:
- Localhost / loopback (127.x.x.x, ::1)
- Private networks (10.x, 172.16-31.x, 192.168.x)
- Link-local (169.254.x.x)
- Cloud metadata (169.254.169.254, metadata.google.internal)
- Common database ports on any host
"""

import ipaddress
import socket
import logging
from typing import Optional
from urllib.parse import urlparse

logger = logging.getLogger("seraph.ssrf")

BLOCKED_NETWORKS = [
    ipaddress.ip_network("127.0.0.0/8"),
    ipaddress.ip_network("10.0.0.0/8"),
    ipaddress.ip_network("172.16.0.0/12"),
    ipaddress.ip_network("192.168.0.0/16"),
    ipaddress.ip_network("169.254.0.0/16"),
    ipaddress.ip_network("0.0.0.0/8"),
    ipaddress.ip_network("::1/128"),
    ipaddress.ip_network("fc00::/7"),
    ipaddress.ip_network("fe80::/10"),
]

BLOCKED_HOSTNAMES = frozenset({
    "localhost", "metadata.google.internal", "metadata.internal",
    "metadata", "instance-data", "169.254.169.254",
})

BLOCKED_PORTS = frozenset({
    6379,   # Redis
    5432,   # PostgreSQL
    3306,   # MySQL
    27017,  # MongoDB
    11211,  # Memcached
    9200,   # Elasticsearch
    2379,   # etcd
    8500,   # Consul
})


def is_blocked_ip(ip_str: str) -> bool:
    """Check if an IP address is in a blocked range."""
    try:
        ip = ipaddress.ip_address(ip_str)
        return any(ip in net for net in BLOCKED_NETWORKS)
    except ValueError:
        return False


def is_blocked_hostname(hostname: str) -> bool:
    """Check if a hostname resolves to a blocked IP."""
    if hostname.lower() in BLOCKED_HOSTNAMES:
        return True

    # Resolve hostname and check IP
    try:
        addrs = socket.getaddrinfo(hostname, None, socket.AF_UNSPEC, socket.SOCK_STREAM)
        for family, _, _, _, sockaddr in addrs:
            ip_str = sockaddr[0]
            if is_blocked_ip(ip_str):
                return True
    except (socket.gaierror, OSError):
        pass  # Can't resolve — allow (DNS failure is different from SSRF)

    return False


def check_url(url: str) -> Optional[str]:
    """
    Check if a URL is safe to request.

    Returns None if safe, or a reason string if blocked.
    """
    try:
        parsed = urlparse(url)
    except Exception:
        return "Invalid URL"

    # Scheme check
    if parsed.scheme not in ("http", "https"):
        return f"Blocked scheme: {parsed.scheme}"

    hostname = parsed.hostname or ""
    if not hostname:
        return "No hostname"

    # Direct hostname check
    if hostname.lower() in BLOCKED_HOSTNAMES:
        return f"Blocked hostname: {hostname}"

    # Port check
    port = parsed.port
    if port and port in BLOCKED_PORTS:
        return f"Blocked port: {port}"

    # IP check (if hostname is an IP)
    if is_blocked_ip(hostname):
        return f"Blocked IP: {hostname}"

    # DNS resolution check (detect SSRF via DNS rebinding)
    if is_blocked_hostname(hostname):
        return f"Hostname resolves to blocked IP: {hostname}"

    return None  # Safe


def guard_url(url: str) -> str:
    """
    Guard a URL — raise ValueError if blocked.

    Use this as a decorator/wrapper around requests calls.
    """
    reason = check_url(url)
    if reason:
        raise ValueError(f"SSRF blocked: {url} — {reason}")
    return url
