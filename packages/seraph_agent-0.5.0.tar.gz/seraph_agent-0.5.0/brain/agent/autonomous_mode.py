"""
Seraph Autonomous Mode — set a goal and walk away.

Tell Seraph "build me a landing page" and it works for hours autonomously.
Sends progress updates to your channel. Only asks questions when truly stuck.

Usage:
  /auto build a portfolio website with dark theme
  /auto audit all my bots and fix every issue
  /auto research competitors and write a report
"""

import os
import json
import time
import logging
import threading
from typing import Dict, List, Optional, Callable
from dataclasses import dataclass, field

logger = logging.getLogger("seraph.autonomous")


@dataclass
class AutonomousTask:
    goal: str
    session_key: str
    channel: str
    chat_id: str
    user_id: str
    status: str = "running"  # running, paused, completed, failed, stuck
    steps_completed: int = 0
    steps_total: int = 0
    current_step: str = ""
    started_at: float = field(default_factory=time.time)
    updates: List[str] = field(default_factory=list)
    questions: List[str] = field(default_factory=list)
    max_iterations: int = 50
    update_interval: int = 300  # Send progress every 5 min


class AutonomousRunner:
    """Run tasks autonomously with progress reporting."""

    def __init__(self):
        self.active_tasks: Dict[str, AutonomousTask] = {}
        self.send_fn: Optional[Callable] = None  # channel send function

    def start_task(self, goal: str, session_key: str, channel: str,
                   chat_id: str, user_id: str) -> AutonomousTask:
        """Start an autonomous task in a background thread."""
        task = AutonomousTask(
            goal=goal, session_key=session_key, channel=channel,
            chat_id=chat_id, user_id=user_id,
        )
        self.active_tasks[session_key] = task

        thread = threading.Thread(
            target=self._run_task, args=(task,), daemon=True
        )
        thread.start()

        return task

    def _run_task(self, task: AutonomousTask):
        """Execute the autonomous task loop."""
        try:
            from agent.core import get_agent

            agent = get_agent()
            last_update = time.time()

            # Initial planning prompt
            plan_prompt = (
                f"I need you to work AUTONOMOUSLY on this goal. Do NOT ask me questions "
                f"unless you are completely stuck. Work through it step by step, use tools, "
                f"and keep going until the goal is fully achieved.\n\n"
                f"GOAL: {task.goal}\n\n"
                f"Start by making a plan, then execute each step. "
                f"After each major step, briefly state what you did and what's next."
            )

            # First iteration — plan
            response = agent.process(
                plan_prompt, user_id=task.user_id,
                session_key=task.session_key, channel=task.channel,
            )
            task.steps_completed += 1
            task.current_step = "Planning complete"

            # Send initial update
            self._send_update(task, f"Started autonomous task: {task.goal}\n\nPlan:\n{response.text[:500]}")

            # Continue iterations
            continue_prompt = "Continue working on the goal. Execute the next step. Don't ask me — just do it."

            for i in range(task.max_iterations - 1):
                if task.status != "running":
                    break

                response = agent.process(
                    continue_prompt, user_id=task.user_id,
                    session_key=task.session_key, channel=task.channel,
                )
                task.steps_completed += 1

                # Check if done
                done_signals = ["completed", "finished", "done", "all steps", "goal achieved",
                                "task complete", "everything is done"]
                if any(s in response.text.lower() for s in done_signals):
                    task.status = "completed"
                    self._send_update(task, f"Autonomous task COMPLETED!\n\n{response.text[:1000]}")
                    break

                # Check if stuck
                stuck_signals = ["i need your input", "which do you prefer", "should i",
                                 "please clarify", "i'm not sure which"]
                if any(s in response.text.lower() for s in stuck_signals):
                    task.status = "stuck"
                    task.questions.append(response.text[:500])
                    self._send_update(task, f"Need your input:\n\n{response.text[:500]}\n\nReply to continue or /auto stop")
                    # Wait for user response (timeout 30 min)
                    wait_start = time.time()
                    while task.status == "stuck" and time.time() - wait_start < 1800:
                        time.sleep(10)
                    if task.status == "stuck":
                        task.status = "failed"
                        self._send_update(task, "Autonomous task timed out waiting for input.")
                        break
                    task.status = "running"

                # Periodic progress update
                if time.time() - last_update > task.update_interval:
                    self._send_update(task, f"Progress: step {task.steps_completed}\n{response.text[:200]}")
                    last_update = time.time()

            if task.status == "running":
                task.status = "completed"
                self._send_update(task, f"Autonomous task finished after {task.steps_completed} steps.")

        except Exception as e:
            task.status = "failed"
            logger.error(f"Autonomous task failed: {e}")
            self._send_update(task, f"Autonomous task FAILED: {e}")

        finally:
            self.active_tasks.pop(task.session_key, None)

    def _send_update(self, task: AutonomousTask, message: str):
        """Send a progress update to the user's channel."""
        task.updates.append(message)
        if self.send_fn:
            try:
                self.send_fn(task.channel, task.chat_id, f"[AUTO] {message}")
            except Exception as e:
                logger.warning(f"Auto update send failed: {e}")

    def stop_task(self, session_key: str) -> str:
        """Stop an autonomous task."""
        task = self.active_tasks.get(session_key)
        if task:
            task.status = "paused"
            return f"Stopped autonomous task after {task.steps_completed} steps."
        return "No active autonomous task."

    def resume_task(self, session_key: str, user_input: str = "") -> str:
        """Resume a stuck/paused task with optional user input."""
        task = self.active_tasks.get(session_key)
        if task and task.status in ("stuck", "paused"):
            if user_input:
                from agent.core import get_agent
                agent = get_agent()
                agent.process(user_input, user_id=task.user_id,
                              session_key=task.session_key, channel=task.channel)
            task.status = "running"
            return "Resumed autonomous task."
        return "No task to resume."

    def get_status(self) -> List[Dict]:
        """Get status of all active tasks."""
        return [
            {"session": t.session_key, "goal": t.goal[:100], "status": t.status,
             "steps": t.steps_completed, "elapsed": int(time.time() - t.started_at)}
            for t in self.active_tasks.values()
        ]


_runner = None

def get_autonomous_runner() -> AutonomousRunner:
    global _runner
    if _runner is None:
        _runner = AutonomousRunner()
    return _runner
