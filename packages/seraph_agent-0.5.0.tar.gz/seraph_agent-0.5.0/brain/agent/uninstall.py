"""
Seraph Uninstall — clean removal of all Seraph data.

Removes: ~/.seraph/, pip package, cron jobs, systemd services.
Asks for confirmation before deleting.
"""

import os
import shutil
import logging
from pathlib import Path

logger = logging.getLogger("seraph.uninstall")

SERAPH_DIR = Path.home() / ".seraph"


def uninstall(confirm: bool = False, keep_data: bool = False) -> dict:
    """Uninstall Seraph."""
    if not confirm:
        return {
            "warning": "This will delete ALL Seraph data. Pass confirm=True to proceed.",
            "will_delete": [
                str(SERAPH_DIR),
                "pip package: seraph-agent",
            ],
        }

    removed = []

    # Remove data directory
    if not keep_data and SERAPH_DIR.exists():
        shutil.rmtree(SERAPH_DIR)
        removed.append(str(SERAPH_DIR))

    # Uninstall pip package
    try:
        import subprocess
        subprocess.run(["pip", "uninstall", "seraph-agent", "-y"],
                       capture_output=True, timeout=30)
        removed.append("pip:seraph-agent")
    except Exception:
        pass

    return {"uninstalled": True, "removed": removed}
