"""
Seraph Process Registry — track running background processes.

When tools spawn subprocesses (terminal, sandbox, ssh), register them here.
Allows: listing running processes, killing hung ones, tracking resource usage.
"""

import os
import time
import signal
import logging
import threading
from dataclasses import dataclass, field
from typing import Dict, List, Optional

logger = logging.getLogger("seraph.processes")


@dataclass
class ProcessEntry:
    pid: int
    name: str
    command: str
    started: float
    chat_id: int = 0
    status: str = "running"  # running, completed, killed, failed
    exit_code: Optional[int] = None

    def elapsed(self) -> float:
        return time.time() - self.started

    def elapsed_str(self) -> str:
        secs = int(self.elapsed())
        if secs < 60:
            return f"{secs}s"
        elif secs < 3600:
            return f"{secs // 60}m {secs % 60}s"
        else:
            return f"{secs // 3600}h {(secs % 3600) // 60}m"

    def is_alive(self) -> bool:
        if self.status != "running":
            return False
        try:
            os.kill(self.pid, 0)  # Signal 0 = check if process exists
            return True
        except (OSError, ProcessLookupError):
            self.status = "completed"
            return False


class ProcessRegistry:
    """Thread-safe registry of background processes."""

    def __init__(self):
        self._processes: Dict[int, ProcessEntry] = {}
        self._lock = threading.Lock()
        self._counter = 0

    def register(self, pid: int, name: str, command: str, chat_id: int = 0) -> ProcessEntry:
        """Register a new process."""
        entry = ProcessEntry(
            pid=pid,
            name=name,
            command=command[:200],
            started=time.time(),
            chat_id=chat_id,
        )
        with self._lock:
            self._processes[pid] = entry
            self._counter += 1
        logger.info(f"Process registered: {name} (PID {pid})")
        return entry

    def unregister(self, pid: int, exit_code: int = 0):
        """Mark a process as completed."""
        with self._lock:
            if pid in self._processes:
                self._processes[pid].status = "completed"
                self._processes[pid].exit_code = exit_code

    def kill_process(self, pid: int) -> bool:
        """Kill a registered process."""
        with self._lock:
            entry = self._processes.get(pid)
            if not entry:
                return False

        try:
            os.kill(pid, signal.SIGTERM)
            time.sleep(0.5)
            try:
                os.kill(pid, signal.SIGKILL)
            except (OSError, ProcessLookupError):
                pass
            entry.status = "killed"
            logger.info(f"Process killed: {entry.name} (PID {pid})")
            return True
        except (OSError, ProcessLookupError):
            entry.status = "completed"
            return False

    def list_running(self) -> List[ProcessEntry]:
        """List all currently running processes."""
        with self._lock:
            alive = []
            for entry in self._processes.values():
                if entry.is_alive():
                    alive.append(entry)
            return alive

    def list_all(self, limit: int = 20) -> List[ProcessEntry]:
        """List all processes (including completed)."""
        with self._lock:
            entries = sorted(self._processes.values(), key=lambda p: p.started, reverse=True)
            return entries[:limit]

    def get(self, pid: int) -> Optional[ProcessEntry]:
        """Get a specific process entry."""
        with self._lock:
            return self._processes.get(pid)

    def cleanup(self, max_age: int = 3600):
        """Remove old completed entries."""
        now = time.time()
        with self._lock:
            to_remove = [
                pid for pid, entry in self._processes.items()
                if entry.status != "running" and now - entry.started > max_age
            ]
            for pid in to_remove:
                del self._processes[pid]

    def get_stats(self) -> Dict:
        """Get process stats."""
        with self._lock:
            running = sum(1 for e in self._processes.values() if e.is_alive())
            total = len(self._processes)
            return {
                "running": running,
                "total": total,
                "lifetime": self._counter,
            }


# Singleton
_registry = None

def get_process_registry() -> ProcessRegistry:
    global _registry
    if _registry is None:
        _registry = ProcessRegistry()
    return _registry
