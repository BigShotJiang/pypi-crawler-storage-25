"""
Seraph Restart Recovery — resume after crash.

Saves agent state periodically so that after a crash:
1. Detects incomplete runs
2. Offers to resume from where it left off
3. Restores conversation context

State is saved to ~/.seraph/recovery.json on every tool call completion.
"""

import json
import time
import os
import logging
from typing import Dict, Optional, List
from pathlib import Path
from dataclasses import dataclass

logger = logging.getLogger("seraph.recovery")

SERAPH_DIR = Path.home() / ".seraph"
RECOVERY_PATH = SERAPH_DIR / "recovery.json"


@dataclass
class RecoveryState:
    """State saved for crash recovery."""
    session_key: str
    chat_id: str
    user_id: str
    channel: str
    last_user_message: str
    iteration: int
    tool_calls_completed: List[str]
    timestamp: float
    model: str
    status: str  # "running", "completed", "crashed"


def save_state(session_key: str, chat_id: str, user_id: str, channel: str,
               last_message: str, iteration: int, tool_calls: List[str],
               model: str):
    """Save recovery state after each tool call."""
    state = {
        "session_key": session_key,
        "chat_id": chat_id,
        "user_id": user_id,
        "channel": channel,
        "last_user_message": last_message[:1000],
        "iteration": iteration,
        "tool_calls_completed": tool_calls[-20:],  # Last 20
        "timestamp": time.time(),
        "model": model,
        "status": "running",
    }
    try:
        SERAPH_DIR.mkdir(parents=True, exist_ok=True)
        tmp = str(RECOVERY_PATH) + ".tmp"
        with open(tmp, "w") as f:
            json.dump(state, f, indent=2)
        os.replace(tmp, str(RECOVERY_PATH))
    except Exception as e:
        logger.debug(f"Recovery save error: {e}")


def mark_completed(session_key: str):
    """Mark a run as completed (no recovery needed)."""
    try:
        if RECOVERY_PATH.exists():
            with open(RECOVERY_PATH) as f:
                state = json.load(f)
            if state.get("session_key") == session_key:
                state["status"] = "completed"
                tmp = str(RECOVERY_PATH) + ".tmp"
                with open(tmp, "w") as f:
                    json.dump(state, f, indent=2)
                os.replace(tmp, str(RECOVERY_PATH))
    except Exception:
        pass


def check_recovery() -> Optional[Dict]:
    """Check if there's an incomplete run to recover from."""
    if not RECOVERY_PATH.exists():
        return None

    try:
        with open(RECOVERY_PATH) as f:
            state = json.load(f)

        if state.get("status") != "running":
            return None

        # Check if it's recent enough to recover (within 1 hour)
        age = time.time() - state.get("timestamp", 0)
        if age > 3600:
            # Too old — mark as crashed and skip
            state["status"] = "crashed_stale"
            tmp = str(RECOVERY_PATH) + ".tmp2"
            with open(tmp, "w") as f:
                json.dump(state, f, indent=2)
            os.replace(tmp, str(RECOVERY_PATH))
            return None

        return state

    except Exception:
        return None


def format_recovery_prompt(state: Dict) -> str:
    """Format a recovery state as a prompt for the LLM."""
    tools = state.get("tool_calls_completed", [])
    tool_summary = ", ".join(tools[-5:]) if tools else "none"

    return (
        f"[RECOVERY] The previous session was interrupted. "
        f"You were working on: \"{state.get('last_user_message', '')[:200]}\"\n"
        f"Progress: iteration {state.get('iteration', 0)}, "
        f"tools completed: {tool_summary}\n"
        f"Continue from where you left off."
    )


def clear_recovery():
    """Clear the recovery state."""
    try:
        if RECOVERY_PATH.exists():
            RECOVERY_PATH.unlink()
    except Exception:
        pass
