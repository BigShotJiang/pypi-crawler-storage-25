"""
Seraph Insights — conversation analytics and patterns.

Tracks: tool usage frequency, topic distribution, response quality,
conversation length trends, peak usage times.
"""

import json
import time
import logging
from pathlib import Path
from typing import Dict, List
from datetime import datetime, timezone
from collections import Counter

logger = logging.getLogger("seraph.insights")

INSIGHTS_FILE = Path.home() / ".seraph" / "insights.json"


def _load() -> dict:
    if INSIGHTS_FILE.exists():
        try:
            return json.loads(INSIGHTS_FILE.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {
        "tool_usage": {},
        "daily_messages": {},
        "avg_response_tokens": [],
        "topics": {},
        "total_conversations": 0,
        "total_messages": 0,
    }


def _save(data: dict):
    INSIGHTS_FILE.parent.mkdir(parents=True, exist_ok=True)
    tmp = INSIGHTS_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
    tmp.replace(INSIGHTS_FILE)


def record_tool_use(tool_name: str):
    """Record a tool being used."""
    data = _load()
    data["tool_usage"][tool_name] = data["tool_usage"].get(tool_name, 0) + 1
    _save(data)


def record_message(role: str, tokens: int = 0):
    """Record a message sent/received."""
    data = _load()
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    data["daily_messages"][today] = data["daily_messages"].get(today, 0) + 1
    data["total_messages"] = data.get("total_messages", 0) + 1
    if tokens > 0 and role == "assistant":
        data["avg_response_tokens"].append(tokens)
        # Keep last 100
        data["avg_response_tokens"] = data["avg_response_tokens"][-100:]
    _save(data)


def record_conversation():
    """Record a new conversation started."""
    data = _load()
    data["total_conversations"] = data.get("total_conversations", 0) + 1
    _save(data)


def get_insights() -> dict:
    """Get analytics summary."""
    data = _load()

    # Top tools
    tool_usage = data.get("tool_usage", {})
    top_tools = sorted(tool_usage.items(), key=lambda x: x[1], reverse=True)[:10]

    # Avg response tokens
    tokens = data.get("avg_response_tokens", [])
    avg_tokens = sum(tokens) / len(tokens) if tokens else 0

    # Daily trend (last 7 days)
    daily = data.get("daily_messages", {})
    recent_days = sorted(daily.items())[-7:]

    return {
        "total_conversations": data.get("total_conversations", 0),
        "total_messages": data.get("total_messages", 0),
        "avg_response_tokens": int(avg_tokens),
        "top_tools": [{"tool": t, "count": c} for t, c in top_tools],
        "daily_trend": [{"date": d, "messages": c} for d, c in recent_days],
    }
