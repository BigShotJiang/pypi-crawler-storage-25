"""
Seraph Live Dashboard — real-time view of agent activity.

OPT-IN ONLY. Off by default. Enable with:
  /dashboard on     (from Telegram/Discord)
  SERAPH_DASHBOARD=true  (in .env)
  seraph dashboard   (CLI opens browser)

Shows in real-time:
- Left: every tool call as it happens
- Right: agent thinking/reasoning
- Bottom: token usage, cost, model, session

Works alongside Telegram/Discord — you chat on your phone,
watch the brain work on your laptop.
"""

import os
import json
import time
import logging
import threading
from typing import Dict, List, Optional, Callable
from collections import deque

logger = logging.getLogger("seraph.live_dashboard")


class LiveDashboard:
    """Real-time activity stream for the web dashboard."""

    def __init__(self):
        self.enabled = os.environ.get("SERAPH_DASHBOARD", "").lower() in ("true", "1", "on")
        self.events: deque = deque(maxlen=500)
        self.listeners: List[Callable] = []
        self.current_session: str = ""
        self.current_model: str = ""
        self.stats = {
            "total_tokens": 0,
            "total_cost": 0.0,
            "tool_calls": 0,
            "llm_calls": 0,
            "started_at": time.time(),
        }

    def enable(self):
        self.enabled = True
        self._emit("system", {"message": "Live dashboard enabled"})

    def disable(self):
        self._emit("system", {"message": "Live dashboard disabled"})
        self.enabled = False

    def toggle(self) -> bool:
        if self.enabled:
            self.disable()
        else:
            self.enable()
        return self.enabled

    # ─── Event Emitters (called by agent core) ────────────────────

    def on_message_received(self, channel: str, user: str, text: str):
        if not self.enabled:
            return
        self._emit("message_in", {
            "channel": channel, "user": user, "text": text[:200],
        })

    def on_thinking(self, session: str, model: str):
        if not self.enabled:
            return
        self.current_session = session
        self.current_model = model
        self._emit("thinking", {"session": session, "model": model})

    def on_tool_call(self, tool: str, args: Dict, duration_ms: int = 0):
        if not self.enabled:
            return
        self.stats["tool_calls"] += 1
        self._emit("tool_call", {
            "tool": tool,
            "args": {k: str(v)[:100] for k, v in args.items()},
            "duration_ms": duration_ms,
        })

    def on_tool_result(self, tool: str, result: Dict, success: bool):
        if not self.enabled:
            return
        preview = ""
        if isinstance(result, dict):
            if "error" in result:
                preview = f"ERROR: {result['error'][:150]}"
            elif "stdout" in result:
                preview = result["stdout"][:150]
            else:
                preview = json.dumps(result, default=str)[:150]
        self._emit("tool_result", {
            "tool": tool, "success": success, "preview": preview,
        })

    def on_llm_call(self, model: str, input_tokens: int, output_tokens: int,
                    duration_ms: int, cost: float = 0):
        if not self.enabled:
            return
        self.stats["llm_calls"] += 1
        self.stats["total_tokens"] += input_tokens + output_tokens
        self.stats["total_cost"] += cost
        self._emit("llm_call", {
            "model": model, "input_tokens": input_tokens,
            "output_tokens": output_tokens, "duration_ms": duration_ms,
            "cost": round(cost, 6),
        })

    def on_response(self, text: str, confidence: float = 0):
        if not self.enabled:
            return
        self._emit("response", {
            "text": text[:500], "confidence": confidence,
        })

    def on_error(self, error: str):
        if not self.enabled:
            return
        self._emit("error", {"message": error[:300]})

    # ─── Event Infrastructure ─────────────────────────────────────

    def _emit(self, event_type: str, data: Dict):
        event = {
            "type": event_type,
            "data": data,
            "timestamp": time.time(),
        }
        self.events.append(event)
        for listener in self.listeners:
            try:
                listener(event)
            except Exception:
                pass

    def add_listener(self, fn: Callable):
        self.listeners.append(fn)

    def remove_listener(self, fn: Callable):
        self.listeners = [l for l in self.listeners if l != fn]

    def get_recent_events(self, limit: int = 50) -> List[Dict]:
        return list(self.events)[-limit:]

    def get_stats(self) -> Dict:
        return {
            **self.stats,
            "uptime_seconds": int(time.time() - self.stats["started_at"]),
            "enabled": self.enabled,
            "current_session": self.current_session,
            "current_model": self.current_model,
            "event_count": len(self.events),
        }

    def get_sse_stream(self):
        """Generator for Server-Sent Events stream."""
        last_idx = len(self.events)
        while True:
            current = len(self.events)
            if current > last_idx:
                for event in list(self.events)[last_idx:current]:
                    yield f"data: {json.dumps(event)}\n\n"
                last_idx = current
            time.sleep(0.5)


_dashboard = None

def get_live_dashboard() -> LiveDashboard:
    global _dashboard
    if _dashboard is None:
        _dashboard = LiveDashboard()
    return _dashboard
