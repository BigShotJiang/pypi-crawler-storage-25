"""
Seraph Thread Ownership — in group chats, bind threads to users.

Prevents user B from hijacking user A's conversation in a shared group.
Each thread/topic is owned by whoever started it.

The owner can:
- Continue the conversation normally
- /transfer to give ownership to someone else
- /public to make the thread open to everyone

Others can:
- Read the thread
- React to it
- NOT send messages that trigger the agent (unless /public)
"""

import time
import logging
from typing import Dict, Optional

logger = logging.getLogger("seraph.thread_ownership")


class ThreadOwnership:
    """Manage per-thread user ownership in group chats."""

    def __init__(self):
        # Key: "channel:chat_id:thread_id" → {"owner": user_id, "public": bool}
        self.owners: Dict[str, Dict] = {}

    def claim(self, channel: str, chat_id: str, thread_id: str, user_id: str) -> bool:
        """Claim ownership of a thread (first message wins)."""
        key = self._key(channel, chat_id, thread_id)
        if key not in self.owners:
            self.owners[key] = {
                "owner": user_id,
                "public": False,
                "claimed_at": time.time(),
            }
            return True
        return False  # Already owned

    def is_owner(self, channel: str, chat_id: str, thread_id: str, user_id: str) -> bool:
        """Check if a user owns a thread."""
        key = self._key(channel, chat_id, thread_id)
        entry = self.owners.get(key)
        if not entry:
            return True  # Unclaimed — anyone can use
        if entry["public"]:
            return True  # Public thread
        return entry["owner"] == user_id

    def transfer(self, channel: str, chat_id: str, thread_id: str,
                 from_user: str, to_user: str) -> bool:
        """Transfer ownership to another user."""
        key = self._key(channel, chat_id, thread_id)
        entry = self.owners.get(key)
        if not entry or entry["owner"] != from_user:
            return False
        entry["owner"] = to_user
        return True

    def make_public(self, channel: str, chat_id: str, thread_id: str, user_id: str) -> bool:
        """Make a thread public (anyone can use it)."""
        key = self._key(channel, chat_id, thread_id)
        entry = self.owners.get(key)
        if not entry or entry["owner"] != user_id:
            return False
        entry["public"] = True
        return True

    def make_private(self, channel: str, chat_id: str, thread_id: str, user_id: str) -> bool:
        """Make a thread private again."""
        key = self._key(channel, chat_id, thread_id)
        entry = self.owners.get(key)
        if not entry or entry["owner"] != user_id:
            return False
        entry["public"] = False
        return True

    def get_owner(self, channel: str, chat_id: str, thread_id: str) -> Optional[str]:
        """Get the owner of a thread."""
        key = self._key(channel, chat_id, thread_id)
        entry = self.owners.get(key)
        return entry["owner"] if entry else None

    def _key(self, channel: str, chat_id: str, thread_id: str) -> str:
        return f"{channel}:{chat_id}:{thread_id}"


_mgr = None

def get_thread_ownership() -> ThreadOwnership:
    global _mgr
    if _mgr is None:
        _mgr = ThreadOwnership()
    return _mgr
