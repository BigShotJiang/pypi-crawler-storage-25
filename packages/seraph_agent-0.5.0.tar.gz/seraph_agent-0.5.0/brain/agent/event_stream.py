"""
Seraph Active Listener / Event Stream — real-time SSE event streaming.

Pushes events (tool calls, messages, errors, heartbeat) to connected
clients via Server-Sent Events (SSE).
"""

import json
import time
import logging
import threading
from typing import Dict, Set, Callable, List
from collections import deque

logger = logging.getLogger("seraph.events")

MAX_HISTORY = 100


class EventStream:
    """Manages real-time event streaming."""

    def __init__(self):
        self.listeners: List[Callable] = []
        self.history: deque = deque(maxlen=MAX_HISTORY)
        self._lock = threading.Lock()

    def emit(self, event_type: str, data: dict = None):
        """Emit an event to all listeners."""
        event = {
            "type": event_type,
            "data": data or {},
            "timestamp": time.time(),
        }
        with self._lock:
            self.history.append(event)
            for listener in self.listeners:
                try:
                    listener(event)
                except Exception as e:
                    logger.error(f"Event listener error: {e}")

    def add_listener(self, fn: Callable):
        with self._lock:
            self.listeners.append(fn)

    def remove_listener(self, fn: Callable):
        with self._lock:
            self.listeners = [l for l in self.listeners if l is not fn]

    def get_history(self, limit: int = 20, event_type: str = "") -> list:
        with self._lock:
            events = list(self.history)
            if event_type:
                events = [e for e in events if e["type"] == event_type]
            return events[-limit:]

    def format_sse(self, event: dict) -> str:
        """Format event as SSE for HTTP streaming."""
        data = json.dumps(event)
        return f"data: {data}\n\n"

    # Convenience methods
    def tool_called(self, tool_name: str, args: dict):
        self.emit("tool_call", {"tool": tool_name, "args": {k: str(v)[:100] for k, v in args.items()}})

    def tool_completed(self, tool_name: str, elapsed: float):
        self.emit("tool_result", {"tool": tool_name, "elapsed_ms": int(elapsed * 1000)})

    def message_received(self, channel: str, user: str, preview: str):
        self.emit("message", {"channel": channel, "user": user, "preview": preview[:100]})

    def message_sent(self, channel: str, preview: str):
        self.emit("reply", {"channel": channel, "preview": preview[:100]})

    def error(self, error: str):
        self.emit("error", {"error": error[:200]})


# Singleton
_stream = None

def get_event_stream() -> EventStream:
    global _stream
    if _stream is None:
        _stream = EventStream()
    return _stream
