"""
Seraph Preemptive Error Detection — catch problems BEFORE they happen.

Scans the context before executing an action and blocks if it detects:
- Uncommitted git changes before deploy
- Missing env vars before a service start
- Failing tests before merge
- Wrong branch before push
- Missing dependencies before build
- Database not running before migration
"""

import os
import re
import subprocess
import logging
from typing import Dict, List, Optional, Tuple

logger = logging.getLogger("seraph.preemptive")


class PreemptiveCheck:
    """A preemptive check result."""
    check_name: str
    passed: bool
    message: str
    severity: str  # "block", "warn", "info"
    fix_suggestion: str = ""


# Use plain dict since we can't guarantee dataclass import order
def make_check(name, passed, message, severity, fix=""):
    return {"check_name": name, "passed": passed, "message": message,
            "severity": severity, "fix_suggestion": fix}


def run_preemptive_checks(tool_name: str, args: dict,
                           context: dict = None) -> List[Dict]:
    """
    Run checks BEFORE executing a tool call.

    Returns list of check results. If any have severity="block", the action
    should be stopped and the user should be warned.
    """
    checks = []

    if tool_name == "terminal":
        command = args.get("command", "")
        checks.extend(_check_terminal_command(command))

    elif tool_name == "write_file":
        path = args.get("path", args.get("file_path", ""))
        checks.extend(_check_file_write(path, args.get("content", "")))

    elif tool_name == "ssh":
        command = args.get("command", "")
        checks.extend(_check_ssh_command(command, args))

    elif tool_name == "git":
        action = args.get("action", "")
        checks.extend(_check_git_action(action, args))

    return checks


def _check_terminal_command(command: str) -> List[Dict]:
    """Check a terminal command for potential issues."""
    checks = []
    cmd_lower = command.lower().strip()

    # Destructive commands
    if re.search(r'rm\s+-rf\s+/', cmd_lower):
        checks.append(make_check(
            "destructive_rm", False,
            f"Destructive command: '{command[:50]}' — this will delete files permanently",
            "block",
            "Are you sure? Specify the exact path instead of using root paths.",
        ))

    # Deploy without tests
    if any(word in cmd_lower for word in ["deploy", "push", "release", "publish"]):
        # Check if tests were run recently
        try:
            result = subprocess.run(["git", "status", "--porcelain"], capture_output=True, text=True, timeout=5)
            if result.stdout.strip():
                checks.append(make_check(
                    "uncommitted_changes", False,
                    f"Uncommitted changes detected. Don't deploy dirty.",
                    "block",
                    "Run 'git add . && git commit' first.",
                ))
        except Exception:
            pass

    # Force push
    if "push" in cmd_lower and ("--force" in cmd_lower or "-f" in cmd_lower):
        checks.append(make_check(
            "force_push", False,
            "Force push will overwrite remote history",
            "block",
            "Use --force-with-lease instead, or resolve conflicts normally.",
        ))

    # Sudo on sensitive files
    if "sudo" in cmd_lower and any(f in cmd_lower for f in ["/etc/passwd", "/etc/shadow", "authorized_keys"]):
        checks.append(make_check(
            "sudo_sensitive", False,
            "Modifying sensitive system files with sudo",
            "block",
            "Be very careful with system auth files. Double-check the command.",
        ))

    return checks


def _check_file_write(path: str, content: str) -> List[Dict]:
    """Check a file write for potential issues."""
    checks = []

    # Writing to sensitive files
    sensitive = [".env", "credentials", ".key", ".pem", "password", "secret"]
    for s in sensitive:
        if s in path.lower():
            checks.append(make_check(
                "sensitive_file", True,
                f"Writing to potentially sensitive file: {path}",
                "warn",
                "Make sure this file is in .gitignore.",
            ))
            break

    # Overwriting without backup
    if os.path.exists(path):
        size = os.path.getsize(path)
        if size > 10000:  # > 10KB
            checks.append(make_check(
                "large_overwrite", True,
                f"Overwriting {path} ({size:,} bytes) — consider backup first",
                "warn",
                f"Run 'cp {path} {path}.bak' before overwriting.",
            ))

    return checks


def _check_ssh_command(command: str, args: dict) -> List[Dict]:
    """Check SSH commands for issues."""
    checks = []

    # Reboot/shutdown
    if any(word in command.lower() for word in ["reboot", "shutdown", "poweroff", "halt"]):
        checks.append(make_check(
            "remote_reboot", False,
            f"About to reboot/shutdown a remote server",
            "block",
            "Are you sure? This will disconnect all sessions.",
        ))

    # rm -rf on remote
    if re.search(r'rm\s+-rf\s+/', command.lower()):
        checks.append(make_check(
            "remote_destructive", False,
            "Destructive rm -rf on remote server",
            "block",
            "Specify the exact directory. Never use rm -rf / on a remote server.",
        ))

    return checks


def _check_git_action(action: str, args: dict) -> List[Dict]:
    """Check git operations for issues."""
    checks = []

    if action == "push":
        # Check current branch
        try:
            result = subprocess.run(["git", "branch", "--show-current"], capture_output=True, text=True, timeout=5)
            branch = result.stdout.strip()
            if branch in ("main", "master", "production"):
                checks.append(make_check(
                    "push_to_main", True,
                    f"Pushing directly to {branch}",
                    "warn",
                    f"Consider using a feature branch and PR instead of pushing to {branch}.",
                ))
        except Exception:
            pass

    if action in ("reset", "checkout") and args.get("hard", False):
        checks.append(make_check(
            "hard_reset", False,
            "Hard reset will discard all uncommitted changes permanently",
            "block",
            "Stash your changes first: git stash",
        ))

    return checks


def format_checks(checks: List[Dict]) -> str:
    """Format check results for display."""
    if not checks:
        return ""

    blockers = [c for c in checks if c["severity"] == "block" and not c["passed"]]
    warnings = [c for c in checks if c["severity"] == "warn"]

    lines = []
    if blockers:
        lines.append("🛑 BLOCKED — fix these before proceeding:")
        for c in blockers:
            lines.append(f"  • {c['message']}")
            if c["fix_suggestion"]:
                lines.append(f"    Fix: {c['fix_suggestion']}")

    if warnings:
        lines.append("⚠️ Warnings:")
        for c in warnings:
            lines.append(f"  • {c['message']}")

    return "\n".join(lines)


def should_block(checks: List[Dict]) -> bool:
    """Check if any results should block execution."""
    return any(c["severity"] == "block" and not c["passed"] for c in checks)


# Stub for compatibility
def dataclass_stub(cls):
    return cls
