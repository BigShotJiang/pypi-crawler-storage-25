"""
Seraph Agent Marketplace — download complete agent personalities.

Not just skills — full agent configs with identity, tools, model, and skills.
"DevOps Agent", "Trading Agent", "Content Writer Agent" — one-click install.
"""

import json
import os
import time
import logging
import requests
import shutil
from typing import Dict, List
from pathlib import Path

logger = logging.getLogger("seraph.agent_market")

SERAPH_DIR = Path.home() / ".seraph"
AGENTS_DIR = SERAPH_DIR / "agents"
REGISTRY_URL = os.environ.get("SERAPH_AGENT_REGISTRY", "https://registry.seraph.so/api/v1/agents")


BUILTIN_AGENTS = [
    {
        "name": "devops",
        "description": "DevOps automation — Docker, CI/CD, deployments, monitoring",
        "model": "claude-sonnet-4-6",
        "identity": "You are a DevOps engineer. You automate infrastructure, manage deployments, monitor systems, and write CI/CD pipelines. You prefer infrastructure-as-code and automated solutions.",
        "skills": ["devops", "software-development"],
        "tools_priority": ["terminal", "ssh", "files", "git"],
    },
    {
        "name": "trader",
        "description": "Crypto/stock trading analysis — charts, signals, portfolio management",
        "model": "claude-sonnet-4-6",
        "identity": "You are a trading analyst. You analyze markets, read charts, track signals, and manage positions. You are cautious with risk and always set stop losses.",
        "skills": ["data-science"],
        "tools_priority": ["web_search", "web_fetch", "terminal"],
    },
    {
        "name": "writer",
        "description": "Content creation — blog posts, social media, newsletters, copywriting",
        "model": "claude-sonnet-4-6",
        "identity": "You are a professional content writer. You craft engaging content for blogs, social media, newsletters, and marketing. Your writing is clear, concise, and persuasive.",
        "skills": ["creative", "social-media", "email"],
        "tools_priority": ["web_search", "files"],
    },
    {
        "name": "researcher",
        "description": "Deep research — literature review, competitive analysis, fact-checking",
        "model": "claude-opus-4-6",
        "identity": "You are a research analyst. You find authoritative sources, verify claims, compare data, and produce structured research reports. You cite every source.",
        "skills": ["research"],
        "tools_priority": ["web_search", "web_fetch", "files"],
    },
    {
        "name": "security",
        "description": "Security analysis — vulnerability scanning, code review, penetration testing",
        "model": "claude-sonnet-4-6",
        "identity": "You are a cybersecurity expert. You find vulnerabilities, review code for security issues, and recommend hardening measures. You follow OWASP guidelines.",
        "skills": ["red-teaming", "software-development"],
        "tools_priority": ["terminal", "files", "browse"],
    },
    {
        "name": "coder",
        "description": "Software engineer — full-stack development, debugging, architecture",
        "model": "claude-sonnet-4-6",
        "identity": "You are a senior software engineer. You write clean, tested, production-ready code. You follow best practices, handle edge cases, and document your work.",
        "skills": ["software-development", "github"],
        "tools_priority": ["terminal", "files", "git", "browse"],
    },
]


def list_agents() -> List[Dict]:
    """List all available agent personalities."""
    agents = [{"name": a["name"], "description": a["description"],
               "source": "builtin", "installed": False} for a in BUILTIN_AGENTS]

    # Check installed
    AGENTS_DIR.mkdir(parents=True, exist_ok=True)
    for d in AGENTS_DIR.iterdir():
        if d.is_dir() and (d / "agent.json").exists():
            try:
                config = json.loads((d / "agent.json").read_text())
                # Mark as installed
                for a in agents:
                    if a["name"] == config.get("name"):
                        a["installed"] = True
                        break
                else:
                    agents.append({"name": config.get("name", d.name),
                                   "description": config.get("description", ""),
                                   "source": "installed", "installed": True})
            except Exception:
                pass

    return agents


def install_agent(name: str) -> Dict:
    """Install an agent personality."""
    # Check builtins first
    agent = next((a for a in BUILTIN_AGENTS if a["name"] == name), None)
    if not agent:
        return {"error": f"Agent '{name}' not found. Available: {[a['name'] for a in BUILTIN_AGENTS]}"}

    agent_dir = AGENTS_DIR / name
    agent_dir.mkdir(parents=True, exist_ok=True)

    # Save agent config
    (agent_dir / "agent.json").write_text(json.dumps(agent, indent=2))

    # Save identity
    (agent_dir / "SOUL.md").write_text(
        f"# {name.title()} Agent\n\n{agent['identity']}\n"
    )

    return {"installed": name, "path": str(agent_dir)}


def load_agent(name: str) -> Optional[Dict]:
    """Load an installed agent's config."""
    agent_dir = AGENTS_DIR / name
    config_path = agent_dir / "agent.json"
    if config_path.exists():
        return json.loads(config_path.read_text())

    # Check builtins
    return next((a for a in BUILTIN_AGENTS if a["name"] == name), None)


from typing import Optional
