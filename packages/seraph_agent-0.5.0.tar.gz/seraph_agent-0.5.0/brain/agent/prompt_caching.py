"""
Seraph Prompt Caching — Anthropic cache_control for 75% input cost reduction.

Uses Anthropic's prompt caching to avoid re-processing the system prompt
and early conversation turns on every request. Places cache breakpoints at:
1. System prompt (stable across all turns)
2-4. Last 3 user/assistant messages (rolling window)

Only applies to Anthropic models. Other providers ignore this.
"""

import copy
import logging
from typing import Dict, List, Any

logger = logging.getLogger("seraph.prompt_cache")

CACHE_MARKER = {"type": "ephemeral"}
MAX_BREAKPOINTS = 4  # Anthropic limit


def apply_prompt_caching(messages: List[Dict], system: str = "",
                         provider: str = "") -> tuple:
    """
    Apply Anthropic prompt caching to messages.

    Returns (cached_messages, cached_system) with cache_control markers.
    Only modifies for Anthropic provider. Returns unchanged for others.
    """
    if provider != "anthropic":
        return messages, system

    cached_messages = copy.deepcopy(messages)
    cached_system = system

    # Strategy: system_and_3
    # Breakpoint 1: System prompt
    # Breakpoints 2-4: Last 3 non-system messages

    breakpoints_used = 0

    # Mark system prompt for caching (handled separately by Anthropic SDK)
    # The SDK accepts cache_control in the system parameter
    if system:
        cached_system = [{"type": "text", "text": system, "cache_control": CACHE_MARKER}]
        breakpoints_used += 1

    # Find last 3 user/assistant messages to cache
    eligible = []
    for i, msg in enumerate(cached_messages):
        if msg.get("role") in ("user", "assistant"):
            eligible.append(i)

    # Take last 3
    cache_indices = eligible[-(MAX_BREAKPOINTS - breakpoints_used):]

    for idx in cache_indices:
        msg = cached_messages[idx]
        content = msg.get("content")

        if content is None or content == "":
            msg["cache_control"] = CACHE_MARKER
        elif isinstance(content, str):
            msg["content"] = [
                {"type": "text", "text": content, "cache_control": CACHE_MARKER}
            ]
        elif isinstance(content, list) and content:
            # Add cache marker to last content block
            last_block = content[-1]
            if isinstance(last_block, dict):
                last_block["cache_control"] = CACHE_MARKER
            else:
                content.append({"type": "text", "text": "", "cache_control": CACHE_MARKER})
        else:
            msg["cache_control"] = CACHE_MARKER

    return cached_messages, cached_system


def estimate_cache_savings(messages: List[Dict], system: str = "") -> Dict:
    """Estimate token savings from prompt caching."""
    total_chars = len(system)
    for msg in messages:
        content = msg.get("content", "")
        if isinstance(content, str):
            total_chars += len(content)
        elif isinstance(content, list):
            for block in content:
                if isinstance(block, dict):
                    total_chars += len(block.get("text", ""))

    total_tokens = total_chars // 4  # Rough estimate
    cached_tokens = len(system) // 4  # System prompt is always cached
    # Plus early messages that don't change
    stable_messages = messages[:-3] if len(messages) > 3 else []
    for msg in stable_messages:
        content = msg.get("content", "")
        if isinstance(content, str):
            cached_tokens += len(content) // 4

    savings_pct = (cached_tokens / total_tokens * 100) if total_tokens > 0 else 0

    return {
        "total_estimated_tokens": total_tokens,
        "cacheable_tokens": cached_tokens,
        "savings_pct": round(savings_pct, 1),
        "cost_reduction": f"~{savings_pct:.0f}% on cache hits",
    }
