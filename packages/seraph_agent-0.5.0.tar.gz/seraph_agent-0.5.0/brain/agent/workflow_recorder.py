"""
Seraph Workflow Recorder — do it once, replay forever.

Records every tool call during a conversation and saves it as a replayable
workflow. Next time, one command replays the entire sequence.

Usage:
  /record start           — start recording
  /record stop            — stop and save
  /record list            — list saved workflows
  /replay <name>          — replay a workflow
"""

import json
import time
import os
import logging
from typing import Dict, List, Optional
from pathlib import Path
from dataclasses import dataclass, field

logger = logging.getLogger("seraph.recorder")

SERAPH_DIR = Path.home() / ".seraph"
WORKFLOWS_DIR = SERAPH_DIR / "workflows"


@dataclass
class RecordedStep:
    tool: str
    args: Dict
    result_summary: str = ""
    duration_ms: int = 0
    timestamp: float = field(default_factory=time.time)


@dataclass
class Workflow:
    name: str
    description: str
    steps: List[RecordedStep] = field(default_factory=list)
    trigger: str = ""  # Original user message
    created_at: float = field(default_factory=time.time)
    replay_count: int = 0


class WorkflowRecorder:
    """Record and replay tool call workflows."""

    def __init__(self):
        self.recording: Optional[Workflow] = None
        self.is_recording = False

    def start(self, trigger: str = "") -> str:
        """Start recording."""
        self.recording = Workflow(
            name=f"workflow_{int(time.time())}",
            description="",
            trigger=trigger,
        )
        self.is_recording = True
        return "Recording started. Every tool call will be captured."

    def record_step(self, tool: str, args: Dict, result: Dict, duration_ms: int = 0):
        """Record a tool call step."""
        if not self.is_recording or not self.recording:
            return

        summary = ""
        if isinstance(result, dict):
            if "error" in result:
                summary = f"ERROR: {result['error'][:100]}"
            elif "stdout" in result:
                summary = result["stdout"][:100]
            else:
                summary = json.dumps(result, default=str)[:100]

        self.recording.steps.append(RecordedStep(
            tool=tool, args=args, result_summary=summary, duration_ms=duration_ms,
        ))

    def stop(self, name: str = "", description: str = "") -> Dict:
        """Stop recording and save the workflow."""
        if not self.recording:
            return {"error": "Not recording"}

        self.is_recording = False
        workflow = self.recording

        if name:
            workflow.name = name
        if description:
            workflow.description = description

        # Auto-generate description from steps
        if not workflow.description:
            tools_used = list(dict.fromkeys(s.tool for s in workflow.steps))
            workflow.description = f"Workflow using: {', '.join(tools_used[:5])}"

        # Save
        path = self._save(workflow)
        self.recording = None

        return {
            "saved": workflow.name,
            "steps": len(workflow.steps),
            "path": str(path),
        }

    def replay(self, name: str, execute_fn=None) -> Dict:
        """Replay a saved workflow."""
        workflow = self._load(name)
        if not workflow:
            return {"error": f"Workflow '{name}' not found"}

        results = []
        for i, step in enumerate(workflow.steps):
            logger.info(f"Replay [{i+1}/{len(workflow.steps)}]: {step.tool}")
            if execute_fn:
                try:
                    result = execute_fn(step.tool, step.args)
                    results.append({"step": i+1, "tool": step.tool, "ok": "error" not in (result if isinstance(result, dict) else {})})
                except Exception as e:
                    results.append({"step": i+1, "tool": step.tool, "error": str(e)})
            else:
                results.append({"step": i+1, "tool": step.tool, "skipped": True})

        workflow.replay_count += 1
        self._save(workflow)

        succeeded = sum(1 for r in results if r.get("ok"))
        return {
            "replayed": name,
            "total_steps": len(workflow.steps),
            "succeeded": succeeded,
            "results": results,
        }

    def list_workflows(self) -> List[Dict]:
        """List all saved workflows."""
        WORKFLOWS_DIR.mkdir(parents=True, exist_ok=True)
        workflows = []
        for f in sorted(WORKFLOWS_DIR.glob("*.json")):
            try:
                with open(f) as fh:
                    data = json.load(fh)
                workflows.append({
                    "name": data.get("name", f.stem),
                    "description": data.get("description", ""),
                    "steps": len(data.get("steps", [])),
                    "replays": data.get("replay_count", 0),
                    "created": data.get("created_at", 0),
                })
            except Exception:
                pass
        return workflows

    def _save(self, workflow: Workflow) -> Path:
        WORKFLOWS_DIR.mkdir(parents=True, exist_ok=True)
        path = WORKFLOWS_DIR / f"{workflow.name}.json"
        data = {
            "name": workflow.name,
            "description": workflow.description,
            "trigger": workflow.trigger,
            "steps": [{"tool": s.tool, "args": s.args, "result": s.result_summary}
                       for s in workflow.steps],
            "created_at": workflow.created_at,
            "replay_count": workflow.replay_count,
        }
        tmp = str(path) + ".tmp"
        with open(tmp, "w") as f:
            json.dump(data, f, indent=2)
        os.replace(tmp, str(path))
        return path

    def _load(self, name: str) -> Optional[Workflow]:
        path = WORKFLOWS_DIR / f"{name}.json"
        if not path.exists():
            return None
        try:
            with open(path) as f:
                data = json.load(f)
            workflow = Workflow(
                name=data["name"], description=data.get("description", ""),
                trigger=data.get("trigger", ""),
                created_at=data.get("created_at", 0),
                replay_count=data.get("replay_count", 0),
            )
            for s in data.get("steps", []):
                workflow.steps.append(RecordedStep(
                    tool=s["tool"], args=s.get("args", {}),
                    result_summary=s.get("result", ""),
                ))
            return workflow
        except Exception:
            return None


_recorder = None

def get_recorder() -> WorkflowRecorder:
    global _recorder
    if _recorder is None:
        _recorder = WorkflowRecorder()
    return _recorder
