"""
Seraph URL Safety — block malicious URLs before fetching.

Checks:
1. Blocked domains (phishing, malware, tracking)
2. Private IP ranges (SSRF prevention)
3. Suspicious patterns (data: URIs, javascript:, file://)
4. Homograph attacks (unicode lookalike domains)
"""

import re
import socket
import logging
from urllib.parse import urlparse
from typing import Tuple

logger = logging.getLogger("seraph.url_safety")

# Known malicious/dangerous domains
BLOCKED_DOMAINS = {
    "bit.ly", "tinyurl.com",  # URL shorteners (hide real destination)
    "grabify.link", "iplogger.org", "2no.co",  # IP loggers
    "discord.gift",  # Common phishing
}

# Blocked TLDs often used for malware
SUSPICIOUS_TLDS = {".tk", ".ml", ".ga", ".cf", ".gq", ".zip", ".mov"}

# Private/reserved IP ranges (SSRF prevention)
PRIVATE_RANGES = [
    ("10.0.0.0", "10.255.255.255"),
    ("172.16.0.0", "172.31.255.255"),
    ("192.168.0.0", "192.168.255.255"),
    ("127.0.0.0", "127.255.255.255"),
    ("169.254.0.0", "169.254.255.255"),
    ("0.0.0.0", "0.255.255.255"),
]

# Dangerous URI schemes
BLOCKED_SCHEMES = {"javascript", "data", "file", "ftp", "gopher", "telnet", "ldap"}


def _ip_to_int(ip: str) -> int:
    parts = ip.split(".")
    if len(parts) != 4:
        return 0
    try:
        return sum(int(p) << (8 * (3 - i)) for i, p in enumerate(parts))
    except ValueError:
        return 0


def _is_private_ip(ip: str) -> bool:
    """Check if an IP address is in a private/reserved range."""
    ip_int = _ip_to_int(ip)
    if ip_int == 0:
        return False
    for start, end in PRIVATE_RANGES:
        if _ip_to_int(start) <= ip_int <= _ip_to_int(end):
            return True
    return False


def _has_homograph(domain: str) -> bool:
    """Detect unicode homograph attacks (cyrillic/greek lookalikes)."""
    try:
        ascii_domain = domain.encode("ascii")
        return False  # Pure ASCII is fine
    except UnicodeEncodeError:
        # Contains non-ASCII characters — possible homograph
        return True


def check_url(url: str) -> Tuple[bool, str]:
    """
    Check if a URL is safe to fetch.

    Returns:
        (is_safe, reason)
        is_safe=True means OK to proceed
        is_safe=False means blocked with reason
    """
    if not url or not isinstance(url, str):
        return False, "Empty or invalid URL"

    url = url.strip()

    # Check scheme
    try:
        parsed = urlparse(url)
    except Exception:
        return False, "Cannot parse URL"

    scheme = (parsed.scheme or "").lower()

    if scheme in BLOCKED_SCHEMES:
        return False, f"Blocked scheme: {scheme}://"

    if scheme not in ("http", "https", ""):
        return False, f"Unsupported scheme: {scheme}://"

    # Check hostname
    hostname = (parsed.hostname or "").lower()
    if not hostname:
        return False, "No hostname in URL"

    # Blocked domains
    for blocked in BLOCKED_DOMAINS:
        if hostname == blocked or hostname.endswith(f".{blocked}"):
            return False, f"Blocked domain: {hostname}"

    # Suspicious TLDs
    for tld in SUSPICIOUS_TLDS:
        if hostname.endswith(tld):
            logger.warning(f"Suspicious TLD in URL: {hostname}")
            # Warning only, don't block (some legitimate sites use these)
            break

    # Homograph detection
    if _has_homograph(hostname):
        return False, f"Possible homograph attack: {hostname}"

    # SSRF: check if hostname resolves to private IP
    try:
        ip = socket.gethostbyname(hostname)
        if _is_private_ip(ip):
            return False, f"SSRF blocked: {hostname} resolves to private IP {ip}"
    except socket.gaierror:
        # Can't resolve — might be OK (could be temporary DNS issue)
        pass

    # Check for suspicious port
    port = parsed.port
    if port and port not in (80, 443, 8080, 8443, 3000, 5000, 8000, 8888):
        logger.warning(f"Unusual port in URL: {hostname}:{port}")

    # Check for overly long URLs (potential buffer overflow/exploit)
    if len(url) > 2048:
        return False, "URL too long (>2048 chars)"

    # Check for encoded null bytes
    if "%00" in url or "\x00" in url:
        return False, "Null byte in URL"

    return True, "OK"


def sanitize_url(url: str) -> str:
    """
    Sanitize a URL for safe display.
    Strips credentials, normalizes encoding.
    """
    try:
        parsed = urlparse(url)
        # Strip userinfo (credentials in URL)
        if parsed.username or parsed.password:
            safe = parsed._replace(
                netloc=f"{parsed.hostname}" + (f":{parsed.port}" if parsed.port else "")
            )
            return safe.geturl()
        return url
    except Exception:
        return url
