"""
Seraph /btw — side-question without context pollution.

Ask a quick question without it entering the conversation history.
The LLM sees the full context but the question + answer are discarded after.

Usage: /btw what's the current SOL price?
"""

import logging
from typing import Dict, Optional, List

logger = logging.getLogger("seraph.btw")


def handle_btw(text: str, history: List[Dict], identity: str, llm) -> str:
    """
    Process a /btw side-question.

    Uses the current conversation as context but doesn't modify history.
    Returns the response text (caller should NOT append to history).
    """
    # Build a temporary message list: full history + the btw question
    temp_messages = list(history)  # Shallow copy — don't modify original
    temp_messages.append({"role": "user", "content": text})

    # Add a system hint that this is a side question
    btw_system = (
        identity + "\n\n"
        "[SIDE QUESTION] The user asked a quick side question with /btw. "
        "Answer it concisely. This exchange will NOT be saved to conversation history, "
        "so don't reference it in future responses."
    )

    try:
        response = llm.chat(messages=temp_messages, system=btw_system)
        return response.text or "No response."
    except Exception as e:
        logger.error(f"/btw error: {e}")
        return f"Error: {e}"
