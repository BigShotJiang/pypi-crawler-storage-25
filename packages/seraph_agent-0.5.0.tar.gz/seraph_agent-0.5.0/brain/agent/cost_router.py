"""
Seraph Cost-Aware Per-Message Router — route each message to the cheapest model that's good enough.

Not just "budget mode" — actually analyzes each message and picks the optimal model:
- "what time is it" → nano ($0.0001)
- "review this 500 line file" → sonnet ($0.01)
- "architect a system" → opus ($0.15)

User sets a daily budget, router maximizes quality within it.
"""

import re
import time
import logging
from typing import Dict, Optional, Tuple
from dataclasses import dataclass

logger = logging.getLogger("seraph.cost_router")


@dataclass
class RoutingDecision:
    """Result of routing a message to a model."""
    model: str
    provider: str
    reason: str
    estimated_cost: float
    complexity: str  # "trivial", "simple", "medium", "complex", "expert"
    budget_remaining: float


# ─── Message Complexity Analysis ──────────────────────────────────

TRIVIAL_PATTERNS = [
    r"^(?:hi|hello|hey|yo|thanks|ok|yes|no|sure|bye|gn|gm)[\s!?.]*$",
    r"^what(?:'s| is) (?:the )?(?:time|date|day)[\s?]*$",
    r"^(?:how are you|what's up|sup)[\s?]*$",
]

SIMPLE_PATTERNS = [
    r"^(?:search|google|look up)\s+",
    r"^(?:read|show|cat|view)\s+\S+\s*$",
    r"^(?:list|ls)\s+",
    r"^/\w+",  # Slash commands
    r"^(?:run|exec|execute)\s+.{1,50}$",  # Short commands
    r"^(?:what is|define|explain)\s+\w+\s*\??$",  # Simple definitions
]

COMPLEX_PATTERNS = [
    r"(?:review|audit|analyze)\s+(?:this|the)\s+(?:code|file|project|repo)",
    r"(?:refactor|rewrite|redesign|architect)",
    r"(?:build|create|implement|develop)\s+(?:a|an|the)\s+",
    r"(?:debug|fix|solve|diagnose)\s+(?:this|the|a)\s+(?:complex|tricky|weird)",
    r"(?:compare|evaluate|assess)\s+(?:multiple|several|different)",
    r"(?:plan|strategy|roadmap|design)\s+",
]

EXPERT_PATTERNS = [
    r"(?:security|vulnerability|exploit|penetration)",
    r"(?:distributed|microservices|scalability|architecture)",
    r"(?:machine learning|neural|training|fine-tune)",
    r"(?:financial|trading|portfolio|risk)",
    r"(?:legal|compliance|regulation|policy)",
]


def analyze_complexity(message: str) -> str:
    """Classify message complexity."""
    msg = message.strip()
    msg_lower = msg.lower()

    # Very short messages are trivial
    if len(msg) < 10:
        return "trivial"

    for pattern in TRIVIAL_PATTERNS:
        if re.match(pattern, msg_lower):
            return "trivial"

    for pattern in EXPERT_PATTERNS:
        if re.search(pattern, msg_lower):
            return "expert"

    for pattern in COMPLEX_PATTERNS:
        if re.search(pattern, msg_lower):
            return "complex"

    for pattern in SIMPLE_PATTERNS:
        if re.search(pattern, msg_lower):
            return "simple"

    # Length-based heuristic
    word_count = len(msg.split())
    if word_count > 100:
        return "complex"
    elif word_count > 30:
        return "medium"

    # Check for code blocks
    if "```" in msg or msg.count("\n") > 10:
        return "complex"

    return "medium"


# ─── Model Tiers ──────────────────────────────────────────────────

MODEL_TIERS = {
    "trivial": [
        ("gpt-4.1-nano", "openai", 0.0001),
        ("claude-haiku-4-5", "anthropic", 0.0003),
        ("gemini-2.0-flash", "google", 0.0001),
    ],
    "simple": [
        ("gpt-4.1-mini", "openai", 0.0005),
        ("claude-haiku-4-5", "anthropic", 0.0003),
        ("gemini-2.5-flash", "google", 0.0002),
        ("deepseek-chat", "deepseek", 0.0002),
    ],
    "medium": [
        ("claude-sonnet-4-6", "anthropic", 0.005),
        ("gpt-4.1", "openai", 0.003),
        ("gemini-2.5-pro", "google", 0.003),
    ],
    "complex": [
        ("claude-sonnet-4-6", "anthropic", 0.01),
        ("gpt-4.1", "openai", 0.005),
        ("claude-opus-4-6", "anthropic", 0.05),
    ],
    "expert": [
        ("claude-opus-4-6", "anthropic", 0.15),
        ("gpt-5.4", "openai", 0.05),
        ("o3", "openai", 0.10),
    ],
}


class CostAwareRouter:
    """Route messages to the cheapest adequate model within budget."""

    def __init__(self, daily_budget: float = 5.0, default_model: str = "claude-sonnet-4-6"):
        self.daily_budget = daily_budget
        self.default_model = default_model
        self.spent_today = 0.0
        self.last_reset = ""
        self.decisions: list = []

    def route(self, message: str, needs_tools: bool = False,
              needs_vision: bool = False) -> RoutingDecision:
        """Pick the best model for this message within budget."""
        self._maybe_reset()

        complexity = analyze_complexity(message)
        remaining = self.daily_budget - self.spent_today

        # If budget is nearly exhausted, force cheapest
        if remaining < 0.01:
            return RoutingDecision(
                model="gpt-4.1-nano", provider="openai",
                reason="Budget exhausted, using cheapest model",
                estimated_cost=0.0001, complexity=complexity,
                budget_remaining=remaining,
            )

        # Get candidates for this complexity level
        candidates = MODEL_TIERS.get(complexity, MODEL_TIERS["medium"])

        # Filter by what we can afford
        affordable = [c for c in candidates if c[2] <= remaining]
        if not affordable:
            affordable = MODEL_TIERS["trivial"]  # Fallback to cheapest

        # If needs tools, skip models that might not support them well
        if needs_tools and complexity == "trivial":
            complexity = "simple"
            affordable = MODEL_TIERS["simple"]

        # Pick the first (best) affordable option
        model, provider, est_cost = affordable[0]

        decision = RoutingDecision(
            model=model, provider=provider,
            reason=f"Complexity={complexity}, est_cost=${est_cost:.4f}",
            estimated_cost=est_cost, complexity=complexity,
            budget_remaining=remaining,
        )

        self.decisions.append({
            "message_preview": message[:50],
            "complexity": complexity,
            "model": model,
            "cost": est_cost,
            "time": time.time(),
        })
        # Keep last 100
        self.decisions = self.decisions[-100:]

        return decision

    def record_actual_cost(self, cost: float):
        """Record actual cost after an LLM call."""
        self.spent_today += cost

    def get_stats(self) -> dict:
        """Get routing statistics."""
        complexity_counts = {}
        for d in self.decisions:
            c = d["complexity"]
            complexity_counts[c] = complexity_counts.get(c, 0) + 1

        return {
            "daily_budget": self.daily_budget,
            "spent_today": round(self.spent_today, 4),
            "remaining": round(self.daily_budget - self.spent_today, 4),
            "total_routed": len(self.decisions),
            "complexity_distribution": complexity_counts,
        }

    def _maybe_reset(self):
        """Reset daily spending at midnight."""
        import datetime
        today = datetime.date.today().isoformat()
        if today != self.last_reset:
            self.spent_today = 0.0
            self.last_reset = today


_router = None

def get_cost_router(budget: float = 5.0) -> CostAwareRouter:
    global _router
    if _router is None:
        _router = CostAwareRouter(daily_budget=budget)
    return _router
