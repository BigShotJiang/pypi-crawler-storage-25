"""
Seraph Personas — switch between different agent identities.

Each persona has its own SOUL.md, tone, and behavior.
Switch via /persona command or API.
"""

import logging
from pathlib import Path
from typing import Dict, List, Optional

logger = logging.getLogger("seraph.personas")

SERAPH_DIR = Path.home() / ".seraph"
PERSONAS_DIR = SERAPH_DIR / "personas"

# Built-in personas
BUILTIN = {
    "default": "You are Seraph, a self-improving AI agent. Direct, honest, efficient.",
    "coder": "You are Seraph in coder mode. Write clean, tested, production-quality code. Prefer showing code over explaining. Use proper error handling. Test everything.",
    "researcher": "You are Seraph in researcher mode. Always search before answering. Cite sources. Verify claims. Never guess. If you don't know, say so and look it up.",
    "writer": "You are Seraph in writer mode. Write clear, engaging, human-sounding content. No AI slop. No 'in today's digital landscape'. Short sentences. Strong verbs. Active voice.",
    "tutor": "You are Seraph in tutor mode. Explain concepts step by step. Use analogies. Check understanding. Adapt to the learner's level. Be patient and encouraging.",
}


def load_persona(name: str) -> Optional[str]:
    """Load a persona by name."""
    # Check built-in first
    if name in BUILTIN:
        return BUILTIN[name]

    # Check custom personas
    persona_file = PERSONAS_DIR / f"{name}.md"
    if persona_file.exists():
        return persona_file.read_text()

    # Check SOUL.md directly
    soul_path = SERAPH_DIR / "SOUL.md"
    if name == "soul" and soul_path.exists():
        return soul_path.read_text()

    return None


def save_persona(name: str, content: str):
    """Save a custom persona."""
    PERSONAS_DIR.mkdir(parents=True, exist_ok=True)
    (PERSONAS_DIR / f"{name}.md").write_text(content)
    logger.info(f"Saved persona: {name}")


def list_personas() -> List[Dict]:
    """List all available personas."""
    personas = [{"name": k, "type": "built-in", "preview": v[:60]} for k, v in BUILTIN.items()]

    PERSONAS_DIR.mkdir(parents=True, exist_ok=True)
    for f in PERSONAS_DIR.glob("*.md"):
        content = f.read_text()
        personas.append({
            "name": f.stem,
            "type": "custom",
            "preview": content[:60],
        })

    return personas
