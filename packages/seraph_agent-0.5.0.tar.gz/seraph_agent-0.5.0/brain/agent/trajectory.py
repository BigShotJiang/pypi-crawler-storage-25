"""
Seraph Trajectory — conversation trajectory tracking and replay.

Records every step of a conversation: user messages, tool calls,
tool results, assistant responses, timestamps, token usage.
Enables: replay, analysis, debugging, training data generation.
"""

import json
import time
import logging
from pathlib import Path
from typing import Dict, List, Optional
from datetime import datetime, timezone

logger = logging.getLogger("seraph.trajectory")

TRAJECTORIES_DIR = Path.home() / ".seraph" / "trajectories"


class TrajectoryRecorder:
    """Records a single conversation trajectory."""

    def __init__(self, session_id: str = ""):
        self.session_id = session_id or f"traj_{int(time.time())}"
        self.steps: List[Dict] = []
        self.started = time.time()
        self.total_tokens = 0

    def record_user(self, text: str):
        self.steps.append({
            "type": "user",
            "content": text,
            "timestamp": time.time(),
        })

    def record_assistant(self, text: str, tokens: int = 0):
        self.steps.append({
            "type": "assistant",
            "content": text,
            "tokens": tokens,
            "timestamp": time.time(),
        })
        self.total_tokens += tokens

    def record_tool_call(self, tool_name: str, args: dict):
        self.steps.append({
            "type": "tool_call",
            "tool": tool_name,
            "args": {k: str(v)[:200] for k, v in args.items()},
            "timestamp": time.time(),
        })

    def record_tool_result(self, tool_name: str, result: dict, elapsed: float = 0):
        self.steps.append({
            "type": "tool_result",
            "tool": tool_name,
            "result_preview": str(result)[:500],
            "elapsed_ms": int(elapsed * 1000),
            "timestamp": time.time(),
        })

    def record_error(self, error: str):
        self.steps.append({
            "type": "error",
            "error": error[:500],
            "timestamp": time.time(),
        })

    def save(self) -> str:
        """Save trajectory to disk."""
        TRAJECTORIES_DIR.mkdir(parents=True, exist_ok=True)
        filepath = TRAJECTORIES_DIR / f"{self.session_id}.json"

        data = {
            "session_id": self.session_id,
            "started": self.started,
            "ended": time.time(),
            "duration_seconds": int(time.time() - self.started),
            "total_steps": len(self.steps),
            "total_tokens": self.total_tokens,
            "tool_calls": sum(1 for s in self.steps if s["type"] == "tool_call"),
            "steps": self.steps,
        }

        tmp = filepath.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
        tmp.replace(filepath)
        return str(filepath)

    def get_summary(self) -> dict:
        """Get trajectory summary."""
        tool_counts = {}
        for s in self.steps:
            if s["type"] == "tool_call":
                tool = s["tool"]
                tool_counts[tool] = tool_counts.get(tool, 0) + 1

        return {
            "session_id": self.session_id,
            "steps": len(self.steps),
            "tokens": self.total_tokens,
            "tool_calls": sum(tool_counts.values()),
            "tools_used": tool_counts,
            "duration": int(time.time() - self.started),
        }


def list_trajectories(limit: int = 20) -> List[Dict]:
    """List saved trajectories."""
    TRAJECTORIES_DIR.mkdir(parents=True, exist_ok=True)
    results = []
    for f in sorted(TRAJECTORIES_DIR.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)[:limit]:
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
            results.append({
                "session_id": data.get("session_id", f.stem),
                "steps": data.get("total_steps", 0),
                "tokens": data.get("total_tokens", 0),
                "tool_calls": data.get("tool_calls", 0),
                "duration": data.get("duration_seconds", 0),
            })
        except Exception:
            pass
    return results


def load_trajectory(session_id: str) -> Optional[Dict]:
    """Load a saved trajectory."""
    filepath = TRAJECTORIES_DIR / f"{session_id}.json"
    if filepath.exists():
        try:
            return json.loads(filepath.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, IOError):
            pass
    return None
