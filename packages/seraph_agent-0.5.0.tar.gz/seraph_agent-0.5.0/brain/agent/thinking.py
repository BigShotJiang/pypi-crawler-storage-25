"""
Seraph Thinking Levels — control reasoning depth.

Levels:
- none: fastest, no extended reasoning
- low: minimal thinking, good for simple tasks
- medium: balanced (default)
- high: deep reasoning for complex problems
- max: maximum reasoning, uses most tokens

Maps to provider-specific parameters (temperature, reasoning tokens).
"""

import logging
from typing import Dict, Optional

logger = logging.getLogger("seraph.thinking")

THINKING_LEVELS = {
    "none": {
        "description": "No reasoning, fastest response",
        "temperature": 0.3,
        "max_tokens_multiplier": 0.5,
        "openai_reasoning_effort": None,
        "anthropic_thinking": False,
    },
    "low": {
        "description": "Minimal reasoning",
        "temperature": 0.5,
        "max_tokens_multiplier": 0.7,
        "openai_reasoning_effort": "low",
        "anthropic_thinking": False,
    },
    "medium": {
        "description": "Balanced reasoning (default)",
        "temperature": 0.7,
        "max_tokens_multiplier": 1.0,
        "openai_reasoning_effort": "medium",
        "anthropic_thinking": True,
    },
    "high": {
        "description": "Deep reasoning for complex problems",
        "temperature": 0.8,
        "max_tokens_multiplier": 1.5,
        "openai_reasoning_effort": "high",
        "anthropic_thinking": True,
    },
    "max": {
        "description": "Maximum reasoning, highest token usage",
        "temperature": 1.0,
        "max_tokens_multiplier": 2.0,
        "openai_reasoning_effort": "high",
        "anthropic_thinking": True,
    },
}

DEFAULT_LEVEL = "medium"


def get_thinking_params(level: str, provider: str = "openai") -> Dict:
    """Get provider-specific parameters for a thinking level."""
    config = THINKING_LEVELS.get(level, THINKING_LEVELS[DEFAULT_LEVEL])

    params = {
        "temperature": config["temperature"],
        "max_tokens_multiplier": config["max_tokens_multiplier"],
    }

    if provider == "openai":
        if config["openai_reasoning_effort"]:
            params["reasoning_effort"] = config["openai_reasoning_effort"]
    elif provider == "anthropic":
        params["thinking"] = config["anthropic_thinking"]

    return params


def list_levels() -> list:
    """List available thinking levels."""
    return [
        {"level": name, "description": config["description"]}
        for name, config in THINKING_LEVELS.items()
    ]


def auto_select_level(message: str, tool_count: int = 0) -> str:
    """Auto-select thinking level based on message complexity."""
    msg_lower = message.lower()

    # Short simple messages = low
    if len(message) < 50 and not any(w in msg_lower for w in ["debug", "analyze", "complex", "why"]):
        return "low"

    # Code/debugging = high
    if any(w in msg_lower for w in ["debug", "traceback", "error", "architect", "design", "optimize"]):
        return "high"

    # Tool-heavy = medium
    if tool_count > 3:
        return "medium"

    return "medium"
