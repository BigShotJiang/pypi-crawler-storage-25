"""
Seraph /dock — switch reply channel mid-conversation.

"Continue this on Telegram" or "Send the next response to Discord."
Routes the NEXT response to a different channel while keeping the session.

Usage:
  /dock telegram    — next replies go to Telegram
  /dock discord     — next replies go to Discord
  /dock reset       — back to current channel
"""

import logging
from typing import Dict, Optional

logger = logging.getLogger("seraph.dock")


class DockManager:
    """Manage cross-channel reply routing."""

    def __init__(self):
        # session_key → {"channel": "telegram", "chat_id": "12345"}
        self.docks: Dict[str, Dict] = {}

    def dock(self, session_key: str, target_channel: str, target_chat_id: str = "") -> str:
        """Route future replies for this session to another channel."""
        self.docks[session_key] = {
            "channel": target_channel,
            "chat_id": target_chat_id,
        }
        return f"Docked to {target_channel}. Next replies go there."

    def undock(self, session_key: str) -> str:
        """Remove dock — replies go back to originating channel."""
        if session_key in self.docks:
            old = self.docks.pop(session_key)
            return f"Undocked from {old['channel']}. Replies return to origin."
        return "Not docked anywhere."

    def get_dock(self, session_key: str) -> Optional[Dict]:
        """Get the dock target for a session, or None."""
        return self.docks.get(session_key)

    def is_docked(self, session_key: str) -> bool:
        return session_key in self.docks


_mgr = None

def get_dock_manager() -> DockManager:
    global _mgr
    if _mgr is None:
        _mgr = DockManager()
    return _mgr
