"""
Seraph Batch Runner — parallel batch processing across multiple prompts.

Run the agent on a dataset of prompts in parallel with checkpointing.
Useful for: benchmarks, data processing, bulk operations.

Usage:
    python -m brain.agent.batch_runner --input prompts.jsonl --workers 4
"""

import json
import time
import os
import logging
from typing import Dict, List
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import dataclass

logger = logging.getLogger("seraph.batch")

SERAPH_DIR = Path.home() / ".seraph"


@dataclass
class BatchResult:
    prompt: str
    response: str
    tokens: int
    duration_ms: int
    success: bool
    error: str = ""


def run_single(prompt: str, model: str = "", provider: str = "") -> Dict:
    """Run a single prompt through the agent."""
    try:
        import sys
        sys.path.insert(0, str(Path(__file__).parent.parent))
        from agent.core import SeraphAgent, AgentConfig

        config = AgentConfig()
        if model:
            config.model = model
        if provider:
            config.provider = provider

        agent = SeraphAgent(config)
        response = agent.process(prompt, session_key=f"batch_{int(time.time())}")

        return {
            "prompt": prompt[:200],
            "response": response.text[:2000],
            "tokens": response.tokens_used,
            "duration_ms": response.duration_ms,
            "success": True,
        }
    except Exception as e:
        return {"prompt": prompt[:200], "response": "", "tokens": 0,
                "duration_ms": 0, "success": False, "error": str(e)}


def run_batch(prompts: List[str], workers: int = 4,
              model: str = "", provider: str = "",
              output_path: str = "") -> List[Dict]:
    """Run multiple prompts in parallel."""
    results = []
    start = time.time()

    logger.info(f"Batch: {len(prompts)} prompts, {workers} workers")

    with ProcessPoolExecutor(max_workers=workers) as executor:
        futures = {
            executor.submit(run_single, p, model, provider): i
            for i, p in enumerate(prompts)
        }

        for future in as_completed(futures):
            idx = futures[future]
            try:
                result = future.result()
                results.append(result)
                status = "OK" if result["success"] else "FAIL"
                logger.info(f"  [{idx+1}/{len(prompts)}] {status} ({result['duration_ms']}ms)")
            except Exception as e:
                results.append({"prompt": prompts[idx][:200], "success": False, "error": str(e)})

    duration = int((time.time() - start) * 1000)

    # Save results
    if output_path:
        with open(output_path, "w") as f:
            for r in results:
                f.write(json.dumps(r) + "\n")
        logger.info(f"Results saved to {output_path}")

    succeeded = sum(1 for r in results if r.get("success"))
    logger.info(f"Batch complete: {succeeded}/{len(prompts)} succeeded ({duration}ms)")

    return results


def load_prompts(path: str) -> List[str]:
    """Load prompts from a JSONL file."""
    prompts = []
    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                data = json.loads(line)
                prompts.append(data.get("prompt", data.get("text", data.get("input", line))))
            except json.JSONDecodeError:
                prompts.append(line)
    return prompts


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--model", default="")
    parser.add_argument("--provider", default="")
    parser.add_argument("--output", default="batch_results.jsonl")
    args = parser.parse_args()

    prompts = load_prompts(args.input)
    run_batch(prompts, args.workers, args.model, args.provider, args.output)
