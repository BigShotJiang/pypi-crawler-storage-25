"""
Seraph Doctor — diagnostics, migration checker, config validator.

Runs comprehensive checks on the Seraph installation:
- Config validation (missing required values)
- Memory DB integrity
- Tool loading status
- Channel connectivity
- Disk space
- Python version
- Dependencies
- Stale data cleanup
"""

import os
import sys
import json
import time
import logging
import platform
from pathlib import Path
from typing import List, Dict

logger = logging.getLogger("seraph.doctor")

SERAPH_DIR = Path.home() / ".seraph"


def _check(name: str, fn, *args) -> dict:
    """Run a diagnostic check."""
    try:
        ok, detail = fn(*args)
        return {"name": name, "status": "pass" if ok else "fail", "detail": detail}
    except Exception as e:
        return {"name": name, "status": "error", "detail": str(e)}


def check_python_version() -> tuple:
    v = sys.version_info
    ok = v.major == 3 and v.minor >= 10
    return ok, f"Python {v.major}.{v.minor}.{v.micro}" + ("" if ok else " (need 3.10+)")


def check_config() -> tuple:
    env_file = Path(__file__).resolve().parent.parent.parent / ".env"
    if not env_file.exists():
        env_file = SERAPH_DIR / ".env"
    if not env_file.exists():
        return False, "No .env file found"

    content = env_file.read_text()
    required = ["SERAPH_PROVIDER", "SERAPH_MODEL"]
    missing = [k for k in required if k not in content]
    if missing:
        return False, f"Missing in .env: {', '.join(missing)}"
    return True, f".env loaded ({len(content.splitlines())} lines)"


def check_api_key() -> tuple:
    provider = os.environ.get("SERAPH_PROVIDER", "openai")
    if provider == "openai":
        key = os.environ.get("OPENAI_API_KEY", "")
    elif provider == "anthropic":
        key = os.environ.get("ANTHROPIC_API_KEY", "")
    else:
        key = os.environ.get("OPENROUTER_API_KEY", "")

    if not key:
        return False, f"No API key for provider '{provider}'"
    return True, f"{provider} key: {key[:8]}...{key[-4:]}"


def check_telegram() -> tuple:
    token = os.environ.get("SERAPH_TELEGRAM_TOKEN", "")
    if not token:
        return False, "SERAPH_TELEGRAM_TOKEN not set"
    return True, f"Token: {token[:10]}..."


def check_memory_db() -> tuple:
    db_path = SERAPH_DIR / "memory.db"
    if not db_path.exists():
        return False, "memory.db not found (will be created on first run)"
    size = db_path.stat().st_size
    return True, f"memory.db: {size // 1024}KB"


def check_disk_space() -> tuple:
    import shutil
    total, used, free = shutil.disk_usage(str(SERAPH_DIR.parent))
    free_gb = free / (1024 ** 3)
    ok = free_gb > 1.0
    return ok, f"{free_gb:.1f}GB free" + ("" if ok else " (need >1GB)")


def check_tools() -> tuple:
    try:
        sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
        from tools.registry import get_all_tools
        tools = get_all_tools()
        return True, f"{len(tools)} tools loaded"
    except Exception as e:
        return False, f"Tool loading failed: {e}"


def check_soul() -> tuple:
    soul = SERAPH_DIR / "SOUL.md"
    if not soul.exists():
        return False, "SOUL.md not found (using default identity)"
    size = len(soul.read_text())
    return True, f"SOUL.md: {size} chars"


def check_stale_data() -> tuple:
    workspace = SERAPH_DIR / "workspace"
    if not workspace.exists():
        return True, "No workspace directory"

    stale = []
    now = time.time()
    for f in workspace.iterdir():
        if f.is_file() and now - f.stat().st_mtime > 7 * 86400:
            stale.append(f.name)

    if stale:
        return True, f"{len(stale)} files older than 7 days in workspace"
    return True, "Workspace clean"


def run_doctor() -> dict:
    """Run all diagnostic checks."""
    checks = [
        _check("Python version", check_python_version),
        _check("Config (.env)", check_config),
        _check("API key", check_api_key),
        _check("Telegram token", check_telegram),
        _check("Memory database", check_memory_db),
        _check("Disk space", check_disk_space),
        _check("Tools", check_tools),
        _check("Identity (SOUL.md)", check_soul),
        _check("Stale data", check_stale_data),
    ]

    passed = sum(1 for c in checks if c["status"] == "pass")
    failed = sum(1 for c in checks if c["status"] == "fail")
    errors = sum(1 for c in checks if c["status"] == "error")

    return {
        "platform": platform.system(),
        "python": platform.python_version(),
        "checks": checks,
        "summary": {
            "total": len(checks),
            "passed": passed,
            "failed": failed,
            "errors": errors,
            "healthy": failed == 0 and errors == 0,
        },
    }


def format_doctor_report(result: dict) -> str:
    """Format doctor results for display."""
    lines = [f"Seraph Doctor ({result['platform']}, Python {result['python']})\n"]
    for check in result["checks"]:
        icon = {"pass": "[OK]", "fail": "[!!]", "error": "[??]"}[check["status"]]
        lines.append(f"  {icon} {check['name']}: {check['detail']}")

    s = result["summary"]
    lines.append(f"\n  {s['passed']}/{s['total']} checks passed")
    if not s["healthy"]:
        lines.append(f"  {s['failed']} failed, {s['errors']} errors")

    return "\n".join(lines)
