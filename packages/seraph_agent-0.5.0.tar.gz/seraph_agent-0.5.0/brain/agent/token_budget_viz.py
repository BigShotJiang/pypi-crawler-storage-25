"""
Seraph Token Budget Visualization — show users what's eating their context window.

Real-time breakdown:
- System prompt: 20% (1,200 tokens)
- Active memory: 15% (900 tokens)
- Conversation history: 50% (3,000 tokens)
- Tool definitions: 15% (900 tokens)
- Available: 6,000 tokens

Let users trim specific parts instead of blind compaction.
"""

import logging
from typing import Dict, List, Tuple
from dataclasses import dataclass

logger = logging.getLogger("seraph.token_viz")

CHARS_PER_TOKEN = 4  # Rough estimate


@dataclass
class BudgetSlice:
    """One slice of the token budget."""
    name: str
    tokens: int
    percentage: float
    details: str = ""
    trimmable: bool = False


@dataclass
class TokenBudget:
    """Full token budget breakdown."""
    context_window: int
    used: int
    available: int
    usage_pct: float
    slices: List[BudgetSlice]
    warning: str = ""


def estimate_tokens(text: str) -> int:
    """Estimate token count from text."""
    if not text:
        return 0
    return max(1, len(text) // CHARS_PER_TOKEN)


def analyze_budget(
    system_prompt: str,
    messages: List[Dict],
    tools: List[Dict],
    active_memory: str = "",
    user_profile: str = "",
    context_anchors: str = "",
    context_window: int = 200000,
) -> TokenBudget:
    """
    Analyze the full token budget and produce a breakdown.
    """
    slices = []

    # System prompt / identity
    sys_tokens = estimate_tokens(system_prompt)
    slices.append(BudgetSlice(
        name="Identity/System Prompt",
        tokens=sys_tokens,
        percentage=0,
        details=f"{len(system_prompt)} chars",
        trimmable=False,
    ))

    # Active memory
    mem_tokens = estimate_tokens(active_memory)
    if mem_tokens > 0:
        slices.append(BudgetSlice(
            name="Active Memory",
            tokens=mem_tokens,
            percentage=0,
            details=f"{active_memory.count(chr(10))+1} facts",
            trimmable=True,
        ))

    # User profile
    profile_tokens = estimate_tokens(user_profile)
    if profile_tokens > 0:
        slices.append(BudgetSlice(
            name="User Profile",
            tokens=profile_tokens,
            percentage=0,
            trimmable=True,
        ))

    # Context anchors
    anchor_tokens = estimate_tokens(context_anchors)
    if anchor_tokens > 0:
        slices.append(BudgetSlice(
            name="Pinned Context",
            tokens=anchor_tokens,
            percentage=0,
            trimmable=False,  # Anchors are non-trimmable by design
        ))

    # Conversation history
    history_tokens = 0
    user_msgs = 0
    assistant_msgs = 0
    tool_msgs = 0
    for msg in messages:
        content = msg.get("content", "")
        if isinstance(content, str):
            msg_tokens = estimate_tokens(content)
        else:
            msg_tokens = estimate_tokens(str(content))

        # Tool calls in assistant messages
        if msg.get("tool_calls"):
            msg_tokens += estimate_tokens(str(msg["tool_calls"]))

        history_tokens += msg_tokens
        role = msg.get("role", "")
        if role == "user":
            user_msgs += 1
        elif role == "assistant":
            assistant_msgs += 1
        elif role == "tool":
            tool_msgs += 1

    slices.append(BudgetSlice(
        name="Conversation History",
        tokens=history_tokens,
        percentage=0,
        details=f"{user_msgs} user, {assistant_msgs} assistant, {tool_msgs} tool results",
        trimmable=True,
    ))

    # Tool definitions
    tool_tokens = 0
    for tool in tools:
        tool_tokens += estimate_tokens(str(tool))
    slices.append(BudgetSlice(
        name="Tool Definitions",
        tokens=tool_tokens,
        percentage=0,
        details=f"{len(tools)} tools loaded",
        trimmable=True,
    ))

    # Calculate totals
    total_used = sum(s.tokens for s in slices)
    available = max(0, context_window - total_used)

    # Set percentages
    for s in slices:
        s.percentage = (s.tokens / context_window * 100) if context_window > 0 else 0

    # Warning
    usage_pct = total_used / context_window * 100 if context_window > 0 else 0
    warning = ""
    if usage_pct > 90:
        warning = "CRITICAL: Context nearly full. Compaction needed immediately."
    elif usage_pct > 75:
        warning = "WARNING: Context window 75%+ used. Consider compacting."
    elif usage_pct > 50:
        warning = "Context usage moderate. Plenty of room."

    return TokenBudget(
        context_window=context_window,
        used=total_used,
        available=available,
        usage_pct=usage_pct,
        slices=slices,
        warning=warning,
    )


def format_budget(budget: TokenBudget) -> str:
    """Format budget as a visual text display."""
    lines = [
        f"Token Budget ({budget.usage_pct:.0f}% used)",
        f"{'=' * 40}",
    ]

    # Bar chart
    bar_width = 30
    for s in budget.slices:
        filled = int(s.percentage / 100 * bar_width)
        bar = "█" * filled + "░" * (bar_width - filled)
        trim = " [trim]" if s.trimmable else ""
        lines.append(f"  {s.name:.<25s} {bar} {s.percentage:>5.1f}% ({s.tokens:,} tok){trim}")
        if s.details:
            lines.append(f"  {'':25s} {s.details}")

    lines.extend([
        f"{'=' * 40}",
        f"  Used: {budget.used:,} / {budget.context_window:,} tokens",
        f"  Available: {budget.available:,} tokens",
    ])

    if budget.warning:
        lines.append(f"\n  {budget.warning}")

    return "\n".join(lines)


def format_budget_compact(budget: TokenBudget) -> str:
    """One-line budget summary."""
    return f"Context: {budget.usage_pct:.0f}% ({budget.used:,}/{budget.context_window:,} tokens, {budget.available:,} free)"
