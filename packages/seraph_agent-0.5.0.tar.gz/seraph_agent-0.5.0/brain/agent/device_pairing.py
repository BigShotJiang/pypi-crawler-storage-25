"""
Seraph Device Pairing — pair mobile/desktop devices via QR code or token.

Flow:
1. Gateway generates a pairing token (short-lived)
2. Token is displayed as QR code or copied manually
3. Companion app sends the token to /api/v1/pair
4. Gateway validates and registers the device
5. Device gets a long-lived auth token for future connections

Paired devices can:
- Approve exec requests via push notification
- Receive session updates in real-time
- Send messages to the agent
"""

import json
import time
import secrets
import logging
import os
from typing import Dict, Optional, List
from pathlib import Path
from dataclasses import dataclass, field

logger = logging.getLogger("seraph.device_pairing")

SERAPH_DIR = Path.home() / ".seraph"
DEVICES_PATH = SERAPH_DIR / "devices.json"


@dataclass
class PairedDevice:
    """A paired companion device."""
    id: str
    name: str
    platform: str  # "ios", "macos", "android", "windows", "linux", "web"
    auth_token: str
    paired_at: float
    last_seen: float = 0.0
    push_token: str = ""
    capabilities: List[str] = field(default_factory=list)


@dataclass
class PairingRequest:
    """A pending pairing request."""
    token: str
    created_at: float
    expires_at: float
    claimed: bool = False


class DevicePairingManager:
    """Manage device pairing, tokens, and paired device registry."""

    def __init__(self):
        self.devices: Dict[str, PairedDevice] = {}
        self.pending: Dict[str, PairingRequest] = {}
        self._load()

    def _load(self):
        if DEVICES_PATH.exists():
            try:
                with open(DEVICES_PATH) as f:
                    data = json.load(f)
                for d in data.get("devices", []):
                    device = PairedDevice(**d)
                    self.devices[device.id] = device
            except Exception as e:
                logger.warning(f"Failed to load devices: {e}")

    def _save(self):
        try:
            SERAPH_DIR.mkdir(parents=True, exist_ok=True)
            data = {"devices": [
                {"id": d.id, "name": d.name, "platform": d.platform,
                 "auth_token": d.auth_token, "paired_at": d.paired_at,
                 "last_seen": d.last_seen, "push_token": d.push_token,
                 "capabilities": d.capabilities}
                for d in self.devices.values()
            ]}
            tmp = str(DEVICES_PATH) + ".tmp"
            with open(tmp, "w") as f:
                json.dump(data, f, indent=2)
            os.replace(tmp, str(DEVICES_PATH))
        except Exception as e:
            logger.error(f"Failed to save devices: {e}")

    def create_token(self, ttl: int = 300) -> PairingRequest:
        """Generate a short-lived pairing token."""
        token = secrets.token_urlsafe(16)
        now = time.time()
        req = PairingRequest(token=token, created_at=now, expires_at=now + ttl)
        self.pending[token] = req
        self.pending = {t: p for t, p in self.pending.items() if p.expires_at > now}
        return req

    def claim(self, token: str, name: str, platform: str,
              capabilities: list = None) -> Optional[PairedDevice]:
        """Claim a pairing token and register a device."""
        req = self.pending.get(token)
        if not req or time.time() > req.expires_at or req.claimed:
            return None
        device = PairedDevice(
            id=secrets.token_hex(8), name=name, platform=platform,
            auth_token=secrets.token_urlsafe(32),
            paired_at=time.time(), last_seen=time.time(),
            capabilities=capabilities or ["notifications"],
        )
        self.devices[device.id] = device
        req.claimed = True
        self._save()
        logger.info(f"Device paired: {name} ({platform})")
        return device

    def validate(self, auth_token: str) -> Optional[PairedDevice]:
        """Validate a device auth token."""
        for d in self.devices.values():
            if secrets.compare_digest(d.auth_token, auth_token):
                d.last_seen = time.time()
                return d
        return None

    def unpair(self, device_id: str) -> bool:
        if device_id in self.devices:
            del self.devices[device_id]
            self._save()
            return True
        return False

    def list_devices(self) -> List[Dict]:
        return [
            {"id": d.id, "name": d.name, "platform": d.platform,
             "paired_at": d.paired_at, "last_seen": d.last_seen,
             "online": time.time() - d.last_seen < 300,
             "capabilities": d.capabilities}
            for d in self.devices.values()
        ]

    def qr_data(self, token: str, gateway_url: str) -> str:
        return json.dumps({"type": "seraph_pair", "token": token,
                           "gateway": gateway_url, "version": "0.2.0"})


_mgr = None
def get_device_manager():
    global _mgr
    if _mgr is None:
        _mgr = DevicePairingManager()
    return _mgr
