"""
Seraph Channel Mirror — cross-post messages between channels.

Mirror agent responses from one channel to another. E.g., mirror all
Telegram responses to a Discord channel for archiving or team visibility.
"""

import logging
from typing import Dict, List, Optional, Callable

logger = logging.getLogger("seraph.mirror")


class ChannelMirror:
    """Mirror messages between channels."""

    def __init__(self):
        # List of mirror rules: {"from": "telegram:123", "to": "discord:456"}
        self.rules: List[Dict] = []
        self.senders: Dict[str, Callable] = {}  # channel_name -> send_fn

    def add_rule(self, from_channel: str, from_chat: str,
                 to_channel: str, to_chat: str) -> Dict:
        rule = {
            "from": f"{from_channel}:{from_chat}",
            "to": f"{to_channel}:{to_chat}",
        }
        if rule not in self.rules:
            self.rules.append(rule)
        return {"added": rule}

    def remove_rule(self, from_channel: str, from_chat: str,
                    to_channel: str, to_chat: str) -> Dict:
        key_from = f"{from_channel}:{from_chat}"
        key_to = f"{to_channel}:{to_chat}"
        self.rules = [r for r in self.rules if not (r["from"] == key_from and r["to"] == key_to)]
        return {"removed": True}

    def register_sender(self, channel_name: str, send_fn: Callable):
        """Register a channel's send function for mirroring."""
        self.senders[channel_name] = send_fn

    def mirror(self, source_channel: str, source_chat: str, text: str):
        """Mirror a message to all configured targets."""
        source_key = f"{source_channel}:{source_chat}"
        for rule in self.rules:
            if rule["from"] == source_key:
                target = rule["to"]
                target_channel, target_chat = target.split(":", 1)
                sender = self.senders.get(target_channel)
                if sender:
                    try:
                        sender(target_chat, f"[Mirror from {source_channel}] {text}")
                    except Exception as e:
                        logger.warning(f"Mirror failed {source_key} -> {target}: {e}")

    def list_rules(self) -> List[Dict]:
        return self.rules


_mirror = None

def get_mirror() -> ChannelMirror:
    global _mirror
    if _mirror is None:
        _mirror = ChannelMirror()
    return _mirror
