"""
Seraph Tool Loop Detection — prevent infinite tool call loops.

Detects 3 types of loops:
1. Generic repeat: same tool+args called N times in a row
2. Ping-pong: alternating between two tool calls
3. No-progress: same tool returns identical results repeatedly

Uses SHA-256 hashing for efficient pattern matching.
Circuit breaker at 30 total calls per conversation turn.
"""

import hashlib
import json
import logging
from dataclasses import dataclass, field
from typing import List, Dict, Optional

logger = logging.getLogger("seraph.loop_detection")

WARNING_THRESHOLD = 5
CRITICAL_THRESHOLD = 10
CIRCUIT_BREAKER = 30
HISTORY_SIZE = 40


@dataclass
class ToolRecord:
    tool_name: str
    args_hash: str
    result_hash: str = ""
    signature: str = ""  # tool_name:args_hash


@dataclass
class LoopDetector:
    history: List[ToolRecord] = field(default_factory=list)
    total_calls: int = 0

    def _hash(self, data) -> str:
        """SHA-256 hash of deterministic JSON."""
        try:
            serialized = json.dumps(data, sort_keys=True, default=str)
        except (TypeError, ValueError):
            serialized = str(data)
        return hashlib.sha256(serialized.encode()).hexdigest()[:16]

    def record(self, tool_name: str, args: dict, result: dict = None) -> dict:
        """
        Record a tool call and check for loops.

        Returns:
            {"action": "allow"} — proceed normally
            {"action": "warn", "reason": "..."} — inject warning into context
            {"action": "break", "reason": "..."} — stop the tool loop
        """
        self.total_calls += 1
        args_hash = self._hash(args)
        result_hash = self._hash(result) if result else ""
        signature = f"{tool_name}:{args_hash}"

        record = ToolRecord(
            tool_name=tool_name,
            args_hash=args_hash,
            result_hash=result_hash,
            signature=signature,
        )
        self.history.append(record)

        # Trim history
        if len(self.history) > HISTORY_SIZE:
            self.history = self.history[-HISTORY_SIZE:]

        # Circuit breaker — hard stop
        if self.total_calls >= CIRCUIT_BREAKER:
            logger.error(f"Circuit breaker: {self.total_calls} tool calls in one turn")
            return {
                "action": "break",
                "reason": f"Circuit breaker: {self.total_calls} tool calls. Stopping to prevent runaway loop.",
                "type": "circuit_breaker",
            }

        # Check 1: Generic repeat (same tool+args N times)
        repeat = self._check_generic_repeat(signature)
        if repeat >= CRITICAL_THRESHOLD:
            return {
                "action": "break",
                "reason": f"Loop detected: {tool_name} called {repeat} times with identical arguments. Breaking loop.",
                "type": "generic_repeat",
                "count": repeat,
            }
        if repeat >= WARNING_THRESHOLD:
            return {
                "action": "warn",
                "reason": f"Warning: {tool_name} called {repeat} times with same args. Consider a different approach.",
                "type": "generic_repeat",
                "count": repeat,
            }

        # Check 2: Ping-pong (A-B-A-B pattern)
        pong = self._check_ping_pong()
        if pong >= CRITICAL_THRESHOLD:
            return {
                "action": "break",
                "reason": f"Ping-pong loop detected: alternating between tools {pong} times. Breaking.",
                "type": "ping_pong",
                "count": pong,
            }
        if pong >= WARNING_THRESHOLD:
            return {
                "action": "warn",
                "reason": f"Possible ping-pong loop ({pong} alternations). Try a different approach.",
                "type": "ping_pong",
                "count": pong,
            }

        # Check 3: No-progress (same result hash repeatedly)
        no_prog = self._check_no_progress(tool_name, result_hash)
        if no_prog >= CRITICAL_THRESHOLD:
            return {
                "action": "break",
                "reason": f"No-progress loop: {tool_name} returning identical results {no_prog} times. Breaking.",
                "type": "no_progress",
                "count": no_prog,
            }
        if no_prog >= WARNING_THRESHOLD:
            return {
                "action": "warn",
                "reason": f"No progress: {tool_name} returning same result {no_prog} times.",
                "type": "no_progress",
                "count": no_prog,
            }

        return {"action": "allow"}

    def _check_generic_repeat(self, signature: str) -> int:
        """Count consecutive identical signatures from the end."""
        count = 0
        for rec in reversed(self.history):
            if rec.signature == signature:
                count += 1
            else:
                break
        return count

    def _check_ping_pong(self) -> int:
        """Detect A-B-A-B alternation pattern."""
        if len(self.history) < 4:
            return 0

        a = self.history[-1].signature
        b = self.history[-2].signature if len(self.history) >= 2 else None

        if a == b or not b:
            return 0

        count = 0
        expected_a = True
        for rec in reversed(self.history):
            if expected_a and rec.signature == a:
                count += 1
                expected_a = False
            elif not expected_a and rec.signature == b:
                count += 1
                expected_a = True
            else:
                break

        return count // 2  # pairs

    def _check_no_progress(self, tool_name: str, result_hash: str) -> int:
        """Count consecutive calls to same tool with identical results."""
        if not result_hash:
            return 0

        count = 0
        for rec in reversed(self.history):
            if rec.tool_name == tool_name and rec.result_hash == result_hash:
                count += 1
            elif rec.tool_name == tool_name:
                break
            else:
                break
        return count

    def reset(self):
        """Reset for a new conversation turn."""
        self.history.clear()
        self.total_calls = 0
