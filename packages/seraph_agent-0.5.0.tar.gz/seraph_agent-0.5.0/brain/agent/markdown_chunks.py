"""
Seraph Markdown Fence Balancing — ensure code blocks are properly closed across chunks.

When splitting long messages for Telegram/Discord (4096/2000 char limits),
code blocks might get split in the middle. This ensures every chunk has
balanced ``` fences — if a chunk starts inside a code block, it opens one;
if it ends inside one, it closes it.
"""

import re
import logging
from typing import List

logger = logging.getLogger("seraph.markdown_chunks")

FENCE_RE = re.compile(r'^```(\w*)\s*$', re.MULTILINE)


def count_fences(text: str) -> int:
    """Count the number of ``` fences in text."""
    return len(FENCE_RE.findall(text)) + text.count("```")


def is_inside_fence(text: str) -> bool:
    """Check if the end of text is inside an unclosed code fence."""
    # Count triple backticks — odd number means unclosed
    count = 0
    i = 0
    while i < len(text):
        if text[i:i+3] == "```":
            count += 1
            i += 3
        else:
            i += 1
    return count % 2 == 1


def detect_fence_language(text: str) -> str:
    """Detect the language of the last opened fence."""
    matches = list(FENCE_RE.finditer(text))
    if matches:
        last = matches[-1]
        lang = last.group(1)
        return lang
    return ""


def balance_fence_chunks(chunks: List[str]) -> List[str]:
    """
    Ensure every chunk has balanced code fences.

    If a chunk ends inside a code block, close it.
    If the next chunk continues from inside a code block, open it.
    """
    if len(chunks) <= 1:
        return chunks

    balanced = []
    in_fence = False
    fence_lang = ""

    for i, chunk in enumerate(chunks):
        modified = chunk

        # If we're continuing from inside a fence, open one
        if in_fence:
            modified = f"```{fence_lang}\n{modified}"

        # Check if this chunk ends inside a fence
        if is_inside_fence(modified):
            fence_lang = detect_fence_language(modified)
            modified += "\n```"
            in_fence = True
        else:
            in_fence = False
            fence_lang = ""

        balanced.append(modified)

    return balanced


def chunk_with_balanced_fences(text: str, max_length: int = 4000) -> List[str]:
    """
    Split text into chunks with balanced markdown fences.

    1. Split at natural boundaries (newlines, paragraphs)
    2. Ensure code fences are balanced in each chunk
    """
    if len(text) <= max_length:
        return [text]

    # First pass: split at natural boundaries
    raw_chunks = []
    current = ""

    for line in text.split("\n"):
        if len(current) + len(line) + 1 > max_length and current:
            raw_chunks.append(current)
            current = line
        else:
            current = current + "\n" + line if current else line

    if current:
        raw_chunks.append(current)

    # Second pass: balance fences
    return balance_fence_chunks(raw_chunks)
