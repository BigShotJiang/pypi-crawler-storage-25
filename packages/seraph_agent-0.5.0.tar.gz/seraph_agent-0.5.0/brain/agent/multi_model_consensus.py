"""
Seraph Multi-Model Consensus — query 3 models, only proceed if 2/3 agree.

For critical decisions (deleting files, deploying, financial operations),
one model might hallucinate. Three rarely agree on the same hallucination.

Modes:
- "verify": Ask 3 models the same question, check agreement
- "critique": Primary answers, two others critique
- "vote": Three models vote yes/no on an action
"""

import json
import time
import logging
import asyncio
import concurrent.futures
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field

logger = logging.getLogger("seraph.consensus")


@dataclass
class ConsensusResult:
    """Result of a multi-model consensus check."""
    agreed: bool
    agreement_ratio: float  # 0.0 to 1.0
    decision: str  # "proceed", "block", "uncertain"
    responses: List[Dict] = field(default_factory=list)
    reason: str = ""
    duration_ms: int = 0


# Actions that require consensus
CRITICAL_ACTIONS = {
    "terminal": [
        r"rm\s+-rf", r"sudo\s+rm", r"DROP\s+TABLE", r"DELETE\s+FROM",
        r"mkfs", r"dd\s+if=", r"format\s+",
        r"git\s+push\s+--force", r"git\s+reset\s+--hard",
        r"systemctl\s+stop", r"kill\s+-9",
    ],
    "write_file": [
        r"\.env$", r"credentials", r"\.key$", r"\.pem$",
        r"authorized_keys", r"passwd", r"shadow",
    ],
    "ssh": [
        r"rm\s+-rf", r"reboot", r"shutdown", r"poweroff",
    ],
}


def requires_consensus(tool_name: str, args: dict) -> bool:
    """Check if a tool call requires multi-model consensus."""
    import re

    patterns = CRITICAL_ACTIONS.get(tool_name, [])
    if not patterns:
        return False

    # Check command/path against patterns
    check_value = ""
    if tool_name == "terminal":
        check_value = args.get("command", "")
    elif tool_name == "write_file":
        check_value = args.get("path", args.get("file_path", ""))
    elif tool_name == "ssh":
        check_value = args.get("command", "")

    for pattern in patterns:
        if re.search(pattern, check_value, re.IGNORECASE):
            return True

    return False


async def verify_with_consensus(
    question: str,
    primary_response: str,
    llm_call_fn,
    models: List[Tuple[str, str]] = None,
) -> ConsensusResult:
    """
    Verify a response by asking multiple models.

    Args:
        question: The original question/task
        primary_response: The primary model's response to verify
        llm_call_fn: async function(messages, system, model, provider) -> response
        models: List of (model, provider) tuples to query
    """
    start = time.time()

    if models is None:
        models = [
            ("claude-haiku-4-5", "anthropic"),
            ("gpt-4.1-mini", "openai"),
            ("gemini-2.5-flash", "google"),
        ]

    verification_prompt = f"""You are a safety reviewer. A user asked an AI the following:

USER: {question[:500]}

The AI responded with this plan:
{primary_response[:1000]}

Is this response safe and correct? Answer with:
- AGREE if the response is safe and appropriate
- DISAGREE if the response is dangerous, incorrect, or inappropriate
- UNCERTAIN if you can't determine

Then explain your reasoning in 1-2 sentences.

Format: AGREE/DISAGREE/UNCERTAIN: <reason>"""

    responses = []

    # Query models in parallel
    async def query_model(model, provider):
        try:
            messages = [{"role": "user", "content": verification_prompt}]
            response = await llm_call_fn(messages, "", model, provider)
            text = response.text if hasattr(response, 'text') else str(response)
            return {"model": model, "provider": provider, "response": text}
        except Exception as e:
            return {"model": model, "provider": provider, "response": f"ERROR: {e}"}

    # Run in parallel
    tasks = [query_model(m, p) for m, p in models]
    results = await asyncio.gather(*tasks)
    responses = list(results)

    # Count votes
    agree = 0
    disagree = 0
    uncertain = 0

    for r in responses:
        text = r["response"].upper()
        if text.startswith("AGREE"):
            agree += 1
            r["vote"] = "agree"
        elif text.startswith("DISAGREE"):
            disagree += 1
            r["vote"] = "disagree"
        else:
            uncertain += 1
            r["vote"] = "uncertain"

    total = agree + disagree + uncertain
    agreement_ratio = agree / total if total > 0 else 0

    if agree >= 2:
        decision = "proceed"
        reason = f"{agree}/{total} models agree the action is safe"
    elif disagree >= 2:
        decision = "block"
        reasons = [r["response"][:100] for r in responses if r.get("vote") == "disagree"]
        reason = f"{disagree}/{total} models flagged issues: {'; '.join(reasons)}"
    else:
        decision = "uncertain"
        reason = f"No consensus: {agree} agree, {disagree} disagree, {uncertain} uncertain"

    return ConsensusResult(
        agreed=decision == "proceed",
        agreement_ratio=agreement_ratio,
        decision=decision,
        responses=responses,
        reason=reason,
        duration_ms=int((time.time() - start) * 1000),
    )


def format_consensus(result: ConsensusResult) -> str:
    """Format consensus result for display."""
    icon = "✅" if result.agreed else "⚠️" if result.decision == "uncertain" else "🛑"
    lines = [
        f"{icon} Consensus: {result.decision.upper()} ({result.agreement_ratio:.0%} agreement)",
        f"   {result.reason}",
    ]
    for r in result.responses:
        vote_icon = {"agree": "✅", "disagree": "❌", "uncertain": "❓"}.get(r.get("vote", ""), "❓")
        lines.append(f"   {vote_icon} {r['model']}: {r['response'][:80]}")

    return "\n".join(lines)
