"""
Seraph Agent-to-Agent Protocol — your Seraph talks to other Seraphs.

Enables direct agent communication:
- "Ask David's agent for the API docs"
- "Tell the DevOps agent to deploy staging"
- Agents negotiate, share context, collaborate

Uses the gateway WebSocket for inter-agent messaging.
"""

import json
import time
import logging
import requests
from typing import Dict, List, Optional
from dataclasses import dataclass, field

logger = logging.getLogger("seraph.a2a")


@dataclass
class AgentPeer:
    """A known remote Seraph agent."""
    name: str
    gateway_url: str
    auth_token: str = ""
    last_seen: float = 0.0
    capabilities: List[str] = field(default_factory=list)


@dataclass
class A2AMessage:
    """A message between agents."""
    from_agent: str
    to_agent: str
    content: str
    message_type: str = "request"  # request, response, notify
    request_id: str = ""
    timestamp: float = field(default_factory=time.time)


class AgentNetwork:
    """Manage connections to other Seraph agents."""

    def __init__(self):
        self.peers: Dict[str, AgentPeer] = {}
        self.inbox: List[A2AMessage] = []
        self.my_name = "seraph"

    def add_peer(self, name: str, gateway_url: str, auth_token: str = "") -> Dict:
        """Register a peer agent."""
        self.peers[name] = AgentPeer(
            name=name, gateway_url=gateway_url.rstrip("/"),
            auth_token=auth_token,
        )
        return {"added": name, "url": gateway_url}

    def remove_peer(self, name: str) -> Dict:
        if name in self.peers:
            del self.peers[name]
            return {"removed": name}
        return {"error": f"Unknown peer: {name}"}

    def send_message(self, to: str, content: str,
                     msg_type: str = "request") -> Dict:
        """Send a message to a peer agent."""
        peer = self.peers.get(to)
        if not peer:
            return {"error": f"Unknown agent: {to}. Add with /agent add <name> <url>"}

        msg = A2AMessage(
            from_agent=self.my_name, to_agent=to, content=content,
            message_type=msg_type, request_id=f"a2a_{int(time.time())}",
        )

        try:
            headers = {"Content-Type": "application/json"}
            if peer.auth_token:
                headers["Authorization"] = f"Bearer {peer.auth_token}"

            resp = requests.post(
                f"{peer.gateway_url}/api/v1/chat",
                headers=headers,
                json={
                    "message": content,
                    "user_id": f"agent:{self.my_name}",
                    "session_id": f"a2a_{self.my_name}_{to}",
                    "channel": "agent",
                },
                timeout=120,
            )

            if resp.status_code == 200:
                data = resp.json()
                response_text = data.get("text", "")
                peer.last_seen = time.time()

                response_msg = A2AMessage(
                    from_agent=to, to_agent=self.my_name,
                    content=response_text, message_type="response",
                    request_id=msg.request_id,
                )
                self.inbox.append(response_msg)

                return {"from": to, "response": response_text[:2000]}
            else:
                return {"error": f"Agent {to} returned {resp.status_code}"}

        except Exception as e:
            return {"error": f"Failed to reach {to}: {e}"}

    def list_peers(self) -> List[Dict]:
        return [
            {"name": p.name, "url": p.gateway_url,
             "last_seen": p.last_seen, "online": time.time() - p.last_seen < 300}
            for p in self.peers.values()
        ]

    def get_inbox(self, limit: int = 20) -> List[Dict]:
        return [
            {"from": m.from_agent, "content": m.content[:200],
             "type": m.message_type, "time": m.timestamp}
            for m in self.inbox[-limit:]
        ]


_network = None

def get_agent_network() -> AgentNetwork:
    global _network
    if _network is None:
        _network = AgentNetwork()
    return _network
