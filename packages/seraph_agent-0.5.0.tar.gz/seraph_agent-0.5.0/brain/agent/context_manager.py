"""
Seraph Context Manager — auto-compress when approaching token limit.

Monitors conversation length and compresses before hitting the LLM's
context window. No more sudden failures from token overflow.
"""

import logging
from typing import List, Dict

logger = logging.getLogger("seraph.context")

# Rough token estimates (1 token ~ 4 chars)
def estimate_tokens(messages: List[Dict]) -> int:
    """Estimate total tokens in a message list."""
    total = 0
    for m in messages:
        content = m.get("content", "")
        if isinstance(content, str):
            total += len(content) // 4
        elif isinstance(content, list):
            for part in content:
                if isinstance(part, dict):
                    total += len(str(part.get("text", ""))) // 4
    return total


def should_compress(messages: List[Dict], max_tokens: int = 100000) -> bool:
    """Check if conversation needs compression."""
    return estimate_tokens(messages) > max_tokens * 0.7  # Compress at 70% capacity


def auto_compress(messages: List[Dict], llm=None, target_messages: int = 10) -> List[Dict]:
    """
    Automatically compress conversation when it gets too long.

    Strategy:
    1. Keep first 2 messages (establishes context)
    2. Summarize the middle using LLM (or truncate if no LLM)
    3. Keep last N messages (recent context)
    """
    if len(messages) <= target_messages:
        return messages

    keep_start = 2
    keep_end = target_messages - keep_start - 1  # Reserve 1 for summary
    middle = messages[keep_start:-keep_end]

    if not middle:
        return messages

    # Try LLM summary
    if llm:
        try:
            summary_text = ""
            for m in middle:
                role = m.get("role", "?")
                content = m.get("content", "")
                if isinstance(content, str) and len(content) > 10:
                    summary_text += f"[{role}]: {content[:150]}\n"

            response = llm.chat(
                messages=[{"role": "user", "content": f"Summarize this conversation in 2-3 sentences:\n{summary_text}"}],
                system="Be extremely concise. Focus on decisions and key information.",
            )

            summary_msg = {
                "role": "system",
                "content": f"[Previous conversation summary: {response.text}]"
            }

            compressed = messages[:keep_start] + [summary_msg] + messages[-keep_end:]
            logger.info(f"Auto-compressed: {len(messages)} -> {len(compressed)} messages (LLM summary)")
            return compressed

        except Exception as e:
            logger.warning(f"LLM compression failed: {e}")

    # Fallback: simple truncation
    compressed = messages[:keep_start] + [
        {"role": "system", "content": "[Earlier conversation truncated to save context]"}
    ] + messages[-keep_end:]
    logger.info(f"Auto-compressed: {len(messages)} -> {len(compressed)} messages (truncation)")
    return compressed
