"""
Seraph Screen Reader — see the user's screen and help proactively.

Takes periodic screenshots and analyzes them for:
- Errors visible on screen
- Code that could be improved
- UI issues
- Terminal output that needs attention

Opt-in only. User enables with /screen on.
"""

import os
import time
import logging
import threading
import subprocess
from typing import Dict, Optional, Callable
from pathlib import Path

logger = logging.getLogger("seraph.screen")

SERAPH_DIR = Path.home() / ".seraph"


class ScreenReader:
    """Monitor screen and provide proactive help."""

    def __init__(self):
        self.active = False
        self.interval = 30  # seconds between captures
        self.last_analysis = ""
        self.notify_fn: Optional[Callable] = None
        self._thread: Optional[threading.Thread] = None

    def start(self, notify_fn: Callable = None):
        """Start screen monitoring."""
        self.active = True
        self.notify_fn = notify_fn
        self._thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self._thread.start()
        logger.info("Screen reader started")

    def stop(self):
        """Stop screen monitoring."""
        self.active = False
        logger.info("Screen reader stopped")

    def capture(self) -> Optional[str]:
        """Take a screenshot. Returns path to saved image."""
        try:
            SERAPH_DIR.mkdir(parents=True, exist_ok=True)
            filepath = SERAPH_DIR / "workspace" / f"screen_{int(time.time())}.png"
            filepath.parent.mkdir(parents=True, exist_ok=True)

            import sys
            if sys.platform == "darwin":
                subprocess.run(["screencapture", "-x", str(filepath)],
                               capture_output=True, timeout=5)
            elif sys.platform == "win32":
                # Use PowerShell screenshot
                ps_cmd = f"""
                Add-Type -AssemblyName System.Windows.Forms
                [System.Windows.Forms.Screen]::PrimaryScreen | ForEach-Object {{
                    $bitmap = New-Object System.Drawing.Bitmap($_.Bounds.Width, $_.Bounds.Height)
                    $graphics = [System.Drawing.Graphics]::FromImage($bitmap)
                    $graphics.CopyFromScreen($_.Bounds.Location, [System.Drawing.Point]::Empty, $_.Bounds.Size)
                    $bitmap.Save('{filepath}')
                }}"""
                subprocess.run(["powershell", "-Command", ps_cmd],
                               capture_output=True, timeout=10)
            else:
                # Linux — try gnome-screenshot or scrot
                for cmd in [["gnome-screenshot", "-f", str(filepath)],
                            ["scrot", str(filepath)]]:
                    try:
                        subprocess.run(cmd, capture_output=True, timeout=5)
                        break
                    except FileNotFoundError:
                        continue

            if filepath.exists():
                return str(filepath)
            return None

        except Exception as e:
            logger.debug(f"Screenshot failed: {e}")
            return None

    def analyze(self, screenshot_path: str) -> Optional[str]:
        """Analyze a screenshot for issues using vision."""
        try:
            from tools.registry import execute_tool
            import asyncio
            loop = asyncio.new_event_loop()
            result = loop.run_until_complete(execute_tool("describe_image", {
                "image_path": screenshot_path,
                "question": (
                    "Look at this screen. Is there anything that needs attention? "
                    "Error messages, warnings, failed builds, code issues, or anything "
                    "the developer might want help with? If nothing notable, say 'nothing'."
                ),
            }))
            loop.close()

            description = result.get("description", "")
            if description and "nothing" not in description.lower():
                return description
            return None

        except Exception as e:
            logger.debug(f"Screen analysis failed: {e}")
            return None

    def _monitor_loop(self):
        """Background monitoring loop."""
        while self.active:
            try:
                path = self.capture()
                if path:
                    analysis = self.analyze(path)
                    if analysis and analysis != self.last_analysis:
                        self.last_analysis = analysis
                        if self.notify_fn:
                            self.notify_fn(f"[Screen] I noticed: {analysis}")
                    # Clean up screenshot
                    try:
                        os.unlink(path)
                    except Exception:
                        pass
            except Exception as e:
                logger.debug(f"Screen monitor error: {e}")

            time.sleep(self.interval)


_reader = None

def get_screen_reader() -> ScreenReader:
    global _reader
    if _reader is None:
        _reader = ScreenReader()
    return _reader
