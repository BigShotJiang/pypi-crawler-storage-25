"""
Seraph Context Cache — cache repeated system prompts to save tokens.

If the identity + active memory hasn't changed since last call,
we can tell the LLM provider to use a cached version.
Saves 30-50% on input tokens for the system prompt portion.
"""

import hashlib
import time
import logging
from typing import Dict, Optional, Tuple

logger = logging.getLogger("seraph.cache")


class ContextCache:
    """Cache system prompts to avoid re-sending identical context."""

    def __init__(self, ttl_seconds: int = 300):
        self.ttl = ttl_seconds
        self._cache: Dict[str, dict] = {}  # hash -> {"text": ..., "timestamp": ..., "hits": ...}
        self._last_hash: Optional[str] = None
        self.stats = {"hits": 0, "misses": 0, "tokens_saved": 0}

    def _hash(self, text: str) -> str:
        return hashlib.sha256(text.encode()).hexdigest()[:16]

    def check(self, system_prompt: str) -> Tuple[bool, str]:
        """
        Check if this system prompt is cached.
        Returns: (is_cached, cache_key)
        """
        h = self._hash(system_prompt)
        entry = self._cache.get(h)

        if entry and (time.time() - entry["timestamp"]) < self.ttl:
            self.stats["hits"] += 1
            entry["hits"] += 1
            # Estimate tokens saved (roughly 1 token per 4 chars)
            self.stats["tokens_saved"] += len(system_prompt) // 4
            self._last_hash = h
            return True, h

        # Cache miss — store it
        self.stats["misses"] += 1
        self._cache[h] = {
            "text": system_prompt,
            "timestamp": time.time(),
            "hits": 0,
            "length": len(system_prompt),
        }
        self._last_hash = h

        # Cleanup old entries
        if len(self._cache) > 50:
            cutoff = time.time() - self.ttl
            self._cache = {k: v for k, v in self._cache.items() if v["timestamp"] > cutoff}

        return False, h

    def get_stats(self) -> Dict:
        """Get cache performance stats."""
        total = self.stats["hits"] + self.stats["misses"]
        hit_rate = (self.stats["hits"] / total * 100) if total > 0 else 0
        return {
            "hits": self.stats["hits"],
            "misses": self.stats["misses"],
            "hit_rate": round(hit_rate, 1),
            "tokens_saved": self.stats["tokens_saved"],
            "cost_saved_usd": round(self.stats["tokens_saved"] * 3 / 1_000_000, 4),  # Estimate at $3/M
            "cached_prompts": len(self._cache),
        }

    def invalidate(self):
        """Clear the cache (e.g., when identity changes)."""
        self._cache.clear()
        self._last_hash = None
        logger.info("Context cache invalidated")


# Singleton
_cache = None

def get_cache() -> ContextCache:
    global _cache
    if _cache is None:
        _cache = ContextCache()
    return _cache
