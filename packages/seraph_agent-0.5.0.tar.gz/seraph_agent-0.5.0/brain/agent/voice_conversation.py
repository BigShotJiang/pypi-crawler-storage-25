"""
Seraph Voice Conversations — talk to Seraph like a phone call.

Real-time voice in (transcription) + voice out (TTS).
Not just read-aloud — actual conversational voice interaction.

Requires: microphone access, OpenAI Whisper/Deepgram for STT, ElevenLabs/OpenAI for TTS.
"""

import os
import time
import logging
import threading
from typing import Optional, Callable

logger = logging.getLogger("seraph.voice_conv")


class VoiceConversation:
    """Real-time voice conversation with the agent."""

    def __init__(self):
        self.active = False
        self.listening = False
        self.speaking = False
        self.stt_provider = os.environ.get("SERAPH_STT_PROVIDER", "openai")  # openai, deepgram
        self.tts_provider = os.environ.get("SERAPH_TTS_PROVIDER", "openai")  # openai, elevenlabs
        self.tts_voice = os.environ.get("SERAPH_TTS_VOICE", "alloy")
        self.process_fn: Optional[Callable] = None  # Agent process function
        self.speak_fn: Optional[Callable] = None  # TTS output function

    def start(self, process_fn: Callable):
        """Start voice conversation mode."""
        self.active = True
        self.process_fn = process_fn
        self._thread = threading.Thread(target=self._listen_loop, daemon=True)
        self._thread.start()
        logger.info("Voice conversation started")
        return "Voice mode ON. Speak naturally — I'm listening."

    def stop(self):
        """Stop voice conversation."""
        self.active = False
        return "Voice mode OFF."

    def _listen_loop(self):
        """Continuous listen -> transcribe -> respond -> speak loop."""
        while self.active:
            try:
                # Record audio
                audio_path = self._record_chunk()
                if not audio_path:
                    time.sleep(0.5)
                    continue

                # Transcribe
                text = self._transcribe(audio_path)
                if not text or len(text.strip()) < 2:
                    continue

                logger.info(f"Voice heard: {text[:50]}")

                # Process through agent
                if self.process_fn:
                    response = self.process_fn(text)
                    if response:
                        # Speak the response
                        self._speak(response)

            except Exception as e:
                logger.debug(f"Voice loop error: {e}")
                time.sleep(1)

    def _record_chunk(self, duration: float = 5.0) -> Optional[str]:
        """Record audio from microphone. Returns path to wav file."""
        try:
            import pyaudio
            import wave
            from pathlib import Path

            CHUNK = 1024
            FORMAT = pyaudio.paInt16
            CHANNELS = 1
            RATE = 16000

            p = pyaudio.PyAudio()
            stream = p.open(format=FORMAT, channels=CHANNELS,
                            rate=RATE, input=True, frames_per_buffer=CHUNK)

            frames = []
            for _ in range(int(RATE / CHUNK * duration)):
                if not self.active:
                    break
                data = stream.read(CHUNK, exception_on_overflow=False)
                frames.append(data)

            stream.stop_stream()
            stream.close()
            p.terminate()

            # Check if there was actual audio (not silence)
            audio_data = b"".join(frames)
            if max(audio_data) < 10:  # Silence threshold
                return None

            path = Path.home() / ".seraph" / "workspace" / f"voice_{int(time.time())}.wav"
            path.parent.mkdir(parents=True, exist_ok=True)
            with wave.open(str(path), "wb") as wf:
                wf.setnchannels(CHANNELS)
                wf.setsampwidth(p.get_sample_size(FORMAT))
                wf.setframerate(RATE)
                wf.writeframes(audio_data)

            return str(path)

        except ImportError:
            logger.debug("pyaudio not installed for voice recording")
            return None
        except Exception as e:
            logger.debug(f"Recording error: {e}")
            return None

    def _transcribe(self, audio_path: str) -> str:
        """Transcribe audio to text."""
        try:
            if self.stt_provider == "openai":
                from openai import OpenAI
                client = OpenAI()
                with open(audio_path, "rb") as f:
                    result = client.audio.transcriptions.create(
                        model="whisper-1", file=f, language="en",
                    )
                return result.text
            elif self.stt_provider == "deepgram":
                import requests
                key = os.environ.get("DEEPGRAM_API_KEY", "")
                with open(audio_path, "rb") as f:
                    resp = requests.post(
                        "https://api.deepgram.com/v1/listen",
                        headers={"Authorization": f"Token {key}"},
                        data=f.read(), timeout=10,
                    )
                if resp.status_code == 200:
                    return resp.json().get("results", {}).get("channels", [{}])[0].get(
                        "alternatives", [{}])[0].get("transcript", "")
            return ""
        except Exception as e:
            logger.debug(f"Transcription error: {e}")
            return ""
        finally:
            try:
                os.unlink(audio_path)
            except Exception:
                pass

    def _speak(self, text: str):
        """Convert text to speech and play it."""
        self.speaking = True
        try:
            if self.tts_provider == "openai":
                from openai import OpenAI
                from pathlib import Path
                client = OpenAI()
                response = client.audio.speech.create(
                    model="tts-1", voice=self.tts_voice, input=text[:4096],
                )
                audio_path = Path.home() / ".seraph" / "workspace" / "tts_output.mp3"
                response.stream_to_file(str(audio_path))
                self._play_audio(str(audio_path))
            elif self.tts_provider == "elevenlabs":
                import requests
                key = os.environ.get("ELEVENLABS_API_KEY", "")
                voice_id = os.environ.get("ELEVENLABS_VOICE_ID", "21m00Tcm4TlvDq8ikWAM")
                resp = requests.post(
                    f"https://api.elevenlabs.io/v1/text-to-speech/{voice_id}",
                    headers={"xi-api-key": key},
                    json={"text": text[:5000], "model_id": "eleven_monolingual_v1"},
                    timeout=30,
                )
                if resp.status_code == 200:
                    audio_path = Path.home() / ".seraph" / "workspace" / "tts_output.mp3"
                    audio_path.write_bytes(resp.content)
                    self._play_audio(str(audio_path))
        except Exception as e:
            logger.debug(f"TTS error: {e}")
        finally:
            self.speaking = False

    def _play_audio(self, path: str):
        """Play an audio file."""
        import sys
        import subprocess
        try:
            if sys.platform == "darwin":
                subprocess.run(["afplay", path], capture_output=True, timeout=30)
            elif sys.platform == "win32":
                subprocess.run(["powershell", "-c", f"(New-Object Media.SoundPlayer '{path}').PlaySync()"],
                               capture_output=True, timeout=30)
            else:
                subprocess.run(["aplay", path], capture_output=True, timeout=30)
        except Exception:
            pass


_conv = None

def get_voice_conversation() -> VoiceConversation:
    global _conv
    if _conv is None:
        _conv = VoiceConversation()
    return _conv
