"""
Seraph Prompt Builder — assembles the full system prompt from all sources.

Order:
1. Identity (SOUL.md)
2. Active memory (key facts)
3. User profile (preferences, corrections)
4. Available skills summary
5. Cross-channel context (if switching channels)
6. Rules summary
"""

import logging
from pathlib import Path
from typing import Optional

logger = logging.getLogger("seraph.prompt")

SERAPH_DIR = Path.home() / ".seraph"


def build_system_prompt(
    user_id: str = "",
    channel: str = "",
    include_skills: bool = True,
    include_rules: bool = True,
) -> str:
    """Build the full system prompt from all sources."""
    parts = []

    # 1. Identity
    soul_path = SERAPH_DIR / "SOUL.md"
    if soul_path.exists():
        parts.append(soul_path.read_text())
    else:
        parts.append("You are Seraph, a self-improving AI agent. Be helpful, direct, and honest.")

    # 2. Active memory
    try:
        from memory.store import get_memory
        memory = get_memory()
        active = memory.format_active_for_prompt()
        if active:
            parts.append(active)
    except Exception:
        pass

    # 3. User profile
    if user_id:
        try:
            from memory.store import get_memory
            memory = get_memory()
            profile = memory.format_user_for_prompt(user_id)
            if profile:
                parts.append(profile)
        except Exception:
            pass

    # 4. Skills summary
    if include_skills:
        try:
            from skills.generator import load_all_skills
            skills = load_all_skills()
            if skills:
                skill_list = "\n".join(f"- {s['name']}: {s.get('description', '')[:80]}" for s in skills)
                parts.append(f"## Available Skills\n{skill_list}")
        except Exception:
            pass

    # 5. Rules summary
    if include_rules:
        try:
            from rules.enforcer import get_enforcer
            enforcer = get_enforcer()
            rules = enforcer.list_rules()
            if rules:
                active_rules = [r for r in rules if r["enabled"]]
                if active_rules:
                    rule_list = "\n".join(f"- {r['name']}: {r['description']}" for r in active_rules)
                    parts.append(f"## Active Rules\n{rule_list}")
        except Exception:
            pass

    # 6. Current context
    parts.append(f"\n## Context\nChannel: {channel or 'unknown'}")

    return "\n\n".join(parts)
