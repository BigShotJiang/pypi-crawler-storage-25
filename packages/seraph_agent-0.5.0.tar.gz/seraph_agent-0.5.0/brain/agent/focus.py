"""
Seraph /focus — bind a thread/topic to a specific session or subagent.

In group chats with multiple topics/threads, /focus routes all messages
in THAT thread to a specific session. /unfocus removes the binding.

Usage:
  /focus project-alpha    — bind this thread to session "project-alpha"
  /focus                  — show current binding
  /unfocus                — remove binding
"""

import logging
from typing import Dict, Optional

logger = logging.getLogger("seraph.focus")


class FocusManager:
    """Manage thread → session bindings."""

    def __init__(self):
        # Key: "channel:chat_id:thread_id" → session_key
        self.bindings: Dict[str, str] = {}

    def focus(self, channel: str, chat_id: str, thread_id: str, target_session: str) -> str:
        """Bind a thread to a session."""
        key = f"{channel}:{chat_id}:{thread_id}"
        self.bindings[key] = target_session
        return f"Thread focused on session: {target_session}"

    def unfocus(self, channel: str, chat_id: str, thread_id: str) -> str:
        """Remove thread binding."""
        key = f"{channel}:{chat_id}:{thread_id}"
        if key in self.bindings:
            old = self.bindings.pop(key)
            return f"Unfocused from session: {old}"
        return "No focus binding on this thread."

    def get_session(self, channel: str, chat_id: str, thread_id: str) -> Optional[str]:
        """Get the bound session for a thread, or None."""
        key = f"{channel}:{chat_id}:{thread_id}"
        return self.bindings.get(key)

    def get_status(self, channel: str, chat_id: str, thread_id: str) -> str:
        """Show current focus status."""
        session = self.get_session(channel, chat_id, thread_id)
        if session:
            return f"This thread is focused on session: {session}"
        return "No focus binding. Use /focus <session> to bind."

    def list_bindings(self) -> list:
        """List all active bindings."""
        return [{"thread": k, "session": v} for k, v in self.bindings.items()]


_mgr = None

def get_focus_manager() -> FocusManager:
    global _mgr
    if _mgr is None:
        _mgr = FocusManager()
    return _mgr
