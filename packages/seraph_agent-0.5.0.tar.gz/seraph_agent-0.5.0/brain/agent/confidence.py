"""
Seraph Confidence Gating — know when you're guessing vs certain.

Analyzes LLM responses for confidence signals and acts accordingly:
- High confidence (>80%): deliver response directly
- Medium confidence (40-80%): deliver with caveat
- Low confidence (<40%): auto-search web or ask clarifying question

Also provides confidence scoring for tool call decisions.
"""

import re
import logging
from typing import Dict, Optional, Tuple
from dataclasses import dataclass

logger = logging.getLogger("seraph.confidence")


@dataclass
class ConfidenceAssessment:
    """Assessment of response confidence."""
    score: float  # 0.0 to 1.0
    level: str  # "high", "medium", "low"
    signals: list  # What signals drove the score
    action: str  # "deliver", "caveat", "search", "clarify"
    caveat: str = ""  # Optional caveat to prepend


# ─── Uncertainty Signals ──────────────────────────────────────────

LOW_CONFIDENCE_PHRASES = [
    "i think", "i believe", "i'm not sure", "i'm not certain",
    "it might be", "it could be", "possibly", "perhaps",
    "if i recall", "from what i remember", "i may be wrong",
    "i don't have access to", "i can't verify", "approximately",
    "generally speaking", "in most cases", "typically",
    "as far as i know", "to the best of my knowledge",
    "it's possible that", "there's a chance",
]

HIGH_CONFIDENCE_PHRASES = [
    "the answer is", "this is because", "the correct",
    "according to the documentation", "the code shows",
    "i can confirm", "the output is", "the error is",
    "looking at the file", "the result shows",
    "based on the data", "the logs show",
]

HEDGING_PATTERNS = [
    r"(?:may|might|could|possibly|perhaps)\s+(?:be|have|cause)",
    r"I (?:think|believe|assume|guess)",
    r"not (?:entirely |completely |100% )?(?:sure|certain)",
    r"(?:around|approximately|roughly|about)\s+\d",
]

FACTUAL_PATTERNS = [
    r"the (?:error|bug|issue|problem) is",
    r"line \d+ (?:shows|has|contains)",
    r"the (?:function|method|class|variable) `?\w+`? (?:does|returns|takes)",
    r"(?:according to|based on|from) (?:the|this)",
]


def assess_confidence(response_text: str, context: dict = None) -> ConfidenceAssessment:
    """
    Assess the confidence level of an LLM response.

    Analyzes linguistic signals to determine if the AI is certain or guessing.
    """
    text_lower = response_text.lower()
    signals = []
    score = 0.7  # Start neutral-high

    # Check for low confidence signals
    low_count = 0
    for phrase in LOW_CONFIDENCE_PHRASES:
        if phrase in text_lower:
            low_count += 1
            signals.append(f"low: '{phrase}'")

    # Check for high confidence signals
    high_count = 0
    for phrase in HIGH_CONFIDENCE_PHRASES:
        if phrase in text_lower:
            high_count += 1
            signals.append(f"high: '{phrase}'")

    # Check regex patterns
    for pattern in HEDGING_PATTERNS:
        if re.search(pattern, text_lower):
            low_count += 1
            signals.append(f"hedge: {pattern[:30]}")

    for pattern in FACTUAL_PATTERNS:
        if re.search(pattern, text_lower):
            high_count += 1
            signals.append(f"factual: {pattern[:30]}")

    # Check if response contains code/data (higher confidence)
    has_code = "```" in response_text or response_text.count("\n    ") > 3
    if has_code:
        high_count += 2
        signals.append("contains code")

    # Check if response is very short (might be uncertain)
    if len(response_text) < 50 and "?" in response_text:
        low_count += 1
        signals.append("short + question mark")

    # Check context clues
    if context:
        # If the question is about current/live data, confidence should be lower
        # unless we have tool results to back it up
        has_tool_results = context.get("has_tool_results", False)
        is_factual_query = context.get("is_factual_query", False)

        if is_factual_query and not has_tool_results:
            low_count += 2
            signals.append("factual query without tool verification")
        elif has_tool_results:
            high_count += 2
            signals.append("backed by tool results")

    # Calculate score
    total = high_count + low_count
    if total > 0:
        score = 0.5 + (high_count - low_count) / (total * 2)  # Range: 0.0 to 1.0
    score = max(0.0, min(1.0, score))

    # Determine level and action
    if score >= 0.8:
        level = "high"
        action = "deliver"
        caveat = ""
    elif score >= 0.4:
        level = "medium"
        action = "caveat"
        caveat = ""
    else:
        level = "low"
        action = "search"  # Or "clarify"
        caveat = "I'm not fully certain about this. "

    return ConfidenceAssessment(
        score=score, level=level, signals=signals,
        action=action, caveat=caveat,
    )


def should_auto_search(assessment: ConfidenceAssessment, message: str) -> bool:
    """Decide if we should automatically search the web to verify."""
    if assessment.score >= 0.6:
        return False

    # Only auto-search for factual questions
    factual_indicators = [
        "what is", "what are", "how to", "how do", "when did",
        "where is", "who is", "why does", "how much", "how many",
        "is it true", "can you", "does it",
    ]
    msg_lower = message.lower()
    return any(ind in msg_lower for ind in factual_indicators)


def should_ask_clarification(assessment: ConfidenceAssessment, message: str) -> Tuple[bool, str]:
    """Decide if we should ask for clarification instead of guessing."""
    if assessment.score >= 0.4:
        return False, ""

    # Check if the message is ambiguous
    ambiguous_patterns = [
        (r"(?:fix|change|update|modify) (?:it|that|this)", "What specifically should I fix? Can you point me to the file or describe the issue?"),
        (r"^(?:do it|go|run|start|stop)$", "Can you be more specific about what you'd like me to do?"),
        (r"(?:the|that) (?:thing|stuff|one)", "Which one are you referring to?"),
    ]

    msg_lower = message.lower().strip()
    for pattern, question in ambiguous_patterns:
        if re.search(pattern, msg_lower):
            return True, question

    return False, ""
