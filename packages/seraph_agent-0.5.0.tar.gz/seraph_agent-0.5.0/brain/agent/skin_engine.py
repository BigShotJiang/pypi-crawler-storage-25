"""
Seraph Skin Engine — customizable CLI themes.

Skins are YAML files in ~/.seraph/skins/ defining colors, icons, and layout.
Switch with: seraph skin <name> or /skin <name>
"""

import os
import logging
from typing import Dict, Optional
from pathlib import Path

logger = logging.getLogger("seraph.skin")

SERAPH_DIR = Path.home() / ".seraph"
SKINS_DIR = SERAPH_DIR / "skins"

DEFAULT_SKIN = {
    "name": "default",
    "colors": {
        "banner_border": "#7c3aed",
        "banner_title": "#a78bfa",
        "banner_text": "#e0e0e0",
        "accent": "#7c3aed",
        "success": "#34d399",
        "error": "#ef4444",
        "warning": "#f59e0b",
        "info": "#3b82f6",
        "dim": "#6b7280",
        "prompt": "#e0e0e0",
    },
    "icons": {
        "thinking": "...",
        "success": "OK",
        "error": "ERR",
        "warning": "!",
        "tool": ">",
        "user": "You:",
        "agent": "Seraph:",
    },
}

BUILTIN_SKINS = {
    "default": DEFAULT_SKIN,
    "minimal": {**DEFAULT_SKIN, "name": "minimal",
                "icons": {"thinking": ".", "success": "+", "error": "x",
                          "warning": "!", "tool": "$", "user": ">", "agent": "<"}},
    "hacker": {**DEFAULT_SKIN, "name": "hacker",
               "colors": {**DEFAULT_SKIN["colors"], "banner_border": "#00ff00",
                          "accent": "#00ff00", "prompt": "#00ff00", "banner_text": "#00ff00"}},
}


def load_skin(name: str = "default") -> Dict:
    """Load a skin by name."""
    if name in BUILTIN_SKINS:
        return BUILTIN_SKINS[name]

    skin_path = SKINS_DIR / f"{name}.yaml"
    if skin_path.exists():
        try:
            import yaml
            with open(skin_path) as f:
                custom = yaml.safe_load(f) or {}
            merged = {**DEFAULT_SKIN, **custom}
            merged["colors"] = {**DEFAULT_SKIN["colors"], **custom.get("colors", {})}
            merged["icons"] = {**DEFAULT_SKIN["icons"], **custom.get("icons", {})}
            return merged
        except Exception as e:
            logger.warning(f"Failed to load skin {name}: {e}")

    return DEFAULT_SKIN


def list_skins() -> list:
    """List all available skins."""
    skins = list(BUILTIN_SKINS.keys())
    SKINS_DIR.mkdir(parents=True, exist_ok=True)
    for f in SKINS_DIR.glob("*.yaml"):
        skins.append(f.stem)
    return sorted(set(skins))


def get_active_skin() -> Dict:
    """Get the currently active skin."""
    name = os.environ.get("SERAPH_SKIN", "default")
    return load_skin(name)
