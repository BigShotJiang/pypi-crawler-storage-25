"""
Seraph Heartbeat — periodic self-check that monitors bot health.

Runs every 60s in a background thread. Tracks:
- Telegram API reachability
- Memory DB health
- Error rate (alerts if >5 errors in 5 min)
- Uptime
- Conversation count

Sends Telegram alert if something is wrong.
"""

import os
import time
import logging
import threading
import requests
from pathlib import Path
from datetime import datetime, timezone

logger = logging.getLogger("seraph.heartbeat")

HEARTBEAT_INTERVAL = 60  # seconds
ERROR_THRESHOLD = 5      # errors in window = alert
ERROR_WINDOW = 300       # 5 minute window
HEARTBEAT_FILE = Path.home() / ".seraph" / "heartbeat.json"


class Heartbeat:
    """Background health monitor."""

    def __init__(self, bot=None):
        self.bot = bot  # Reference to SeraphTelegramBot
        self.running = False
        self.thread = None
        self.start_time = time.time()
        self.check_count = 0
        self.errors = []  # timestamps of recent errors
        self.last_alert = 0
        self.status = "starting"

    def record_error(self, error_msg: str = ""):
        """Record an error for rate tracking."""
        now = time.time()
        self.errors.append(now)
        # Prune old errors outside window
        self.errors = [t for t in self.errors if now - t < ERROR_WINDOW]

    def get_error_rate(self) -> int:
        """Errors in the last 5 minutes."""
        now = time.time()
        self.errors = [t for t in self.errors if now - t < ERROR_WINDOW]
        return len(self.errors)

    def start(self):
        """Start the heartbeat background thread."""
        self.running = True
        self.thread = threading.Thread(target=self._loop, daemon=True)
        self.thread.start()
        logger.info("Heartbeat started")

    def stop(self):
        """Stop the heartbeat."""
        self.running = False
        self.status = "stopped"

    def _check_telegram(self) -> bool:
        """Verify Telegram API is reachable."""
        token = os.environ.get("SERAPH_TELEGRAM_TOKEN", "")
        if not token:
            return False
        try:
            resp = requests.get(
                f"https://api.telegram.org/bot{token}/getMe",
                timeout=10,
            )
            return resp.status_code == 200 and resp.json().get("ok", False)
        except Exception:
            return False

    def _check_memory(self) -> bool:
        """Verify memory DB is accessible via the bot's existing connection."""
        try:
            if self.bot and hasattr(self.bot, 'memory') and self.bot.memory:
                self.bot.memory.get_message_count()
                return True
            # No bot reference — skip memory check (not an error)
            return True
        except Exception:
            return False

    def _send_alert(self, message: str):
        """Send an alert via Telegram to the owner."""
        now = time.time()
        # Rate limit alerts: max 1 per 30 minutes
        if now - self.last_alert < 1800:
            return

        token = os.environ.get("SERAPH_TELEGRAM_TOKEN", "")
        chat_id = os.environ.get("SERAPH_ALLOWED_USERS", "").split(",")[0].strip()
        if not token or not chat_id:
            return

        try:
            requests.post(
                f"https://api.telegram.org/bot{token}/sendMessage",
                json={"chat_id": chat_id, "text": f"[HEARTBEAT] {message}"},
                timeout=10,
            )
            self.last_alert = now
            logger.warning(f"Heartbeat alert sent: {message}")
        except Exception as e:
            logger.error(f"Failed to send heartbeat alert: {e}")

    def get_status(self) -> dict:
        """Get current heartbeat status."""
        uptime = time.time() - self.start_time
        hours = int(uptime // 3600)
        minutes = int((uptime % 3600) // 60)
        return {
            "status": self.status,
            "uptime": f"{hours}h {minutes}m",
            "uptime_seconds": int(uptime),
            "checks": self.check_count,
            "error_rate_5m": self.get_error_rate(),
            "conversations": len(self.bot.conversations) if self.bot else 0,
            "last_check": datetime.now(timezone.utc).isoformat(),
        }

    def _write_heartbeat_file(self):
        """Write status to disk for external monitoring."""
        import json
        try:
            HEARTBEAT_FILE.parent.mkdir(parents=True, exist_ok=True)
            tmp = HEARTBEAT_FILE.with_suffix(".tmp")
            tmp.write_text(json.dumps(self.get_status(), indent=2))
            tmp.replace(HEARTBEAT_FILE)
        except Exception:
            pass

    def _loop(self):
        """Main heartbeat loop."""
        # Wait 30s before first check (let bot finish starting)
        time.sleep(30)
        self.status = "healthy"

        while self.running:
            try:
                self.check_count += 1

                # Check Telegram API
                tg_ok = self._check_telegram()
                if not tg_ok:
                    self.record_error("Telegram API unreachable")
                    logger.warning("Heartbeat: Telegram API unreachable")

                # Check memory
                mem_ok = self._check_memory()
                if not mem_ok:
                    self.record_error("Memory DB error")
                    logger.warning("Heartbeat: Memory DB error")

                # Check error rate
                error_rate = self.get_error_rate()
                if error_rate >= ERROR_THRESHOLD:
                    self.status = "degraded"
                    self._send_alert(
                        f"High error rate: {error_rate} errors in 5 min. "
                        f"Telegram={'OK' if tg_ok else 'DOWN'}, "
                        f"Memory={'OK' if mem_ok else 'DOWN'}"
                    )
                elif tg_ok and mem_ok:
                    self.status = "healthy"

                # Write to disk for external watchers
                self._write_heartbeat_file()

                logger.debug(
                    f"Heartbeat #{self.check_count}: {self.status} "
                    f"(tg={'OK' if tg_ok else 'DOWN'}, mem={'OK' if mem_ok else 'DOWN'}, "
                    f"errors={error_rate})"
                )

            except Exception as e:
                logger.error(f"Heartbeat check failed: {e}")
                self.record_error(str(e))

            time.sleep(HEARTBEAT_INTERVAL)


# Singleton
_heartbeat = None

def get_heartbeat(bot=None) -> Heartbeat:
    global _heartbeat
    if _heartbeat is None:
        _heartbeat = Heartbeat(bot)
    elif bot and not _heartbeat.bot:
        _heartbeat.bot = bot
    return _heartbeat
