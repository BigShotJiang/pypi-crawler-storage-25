"""
Seraph One-Click Deploy — deploy to Vercel/Railway/Fly with one command.

/deploy vercel    — push to Vercel
/deploy railway   — push to Railway
/deploy fly       — push to Fly.io
/deploy docker    — build and push Docker image

Handles: git push, env vars, DNS, SSL — everything.
"""

import os
import json
import subprocess
import logging
import time
from typing import Dict, Optional

logger = logging.getLogger("seraph.deploy")


def deploy_vercel(project_dir: str = ".", env_vars: Dict = None) -> Dict:
    """Deploy to Vercel."""
    try:
        # Check if vercel CLI is installed
        result = subprocess.run(["vercel", "--version"], capture_output=True, timeout=5)
        if result.returncode != 0:
            return {"error": "Install Vercel CLI: npm i -g vercel"}

        # Deploy
        cmd = ["vercel", "--yes", "--prod"]
        result = subprocess.run(cmd, capture_output=True, text=True,
                                timeout=300, cwd=project_dir)

        if result.returncode == 0:
            # Extract URL from output
            url = ""
            for line in result.stdout.split("\n"):
                if "https://" in line:
                    url = line.strip()
                    break
            return {"deployed": "vercel", "url": url, "output": result.stdout[-500:]}
        else:
            return {"error": f"Vercel deploy failed: {result.stderr[:300]}"}

    except Exception as e:
        return {"error": str(e)}


def deploy_railway(project_dir: str = ".") -> Dict:
    """Deploy to Railway."""
    try:
        result = subprocess.run(["railway", "--version"], capture_output=True, timeout=5)
        if result.returncode != 0:
            return {"error": "Install Railway CLI: npm i -g @railway/cli"}

        result = subprocess.run(["railway", "up", "--detach"],
                                capture_output=True, text=True,
                                timeout=300, cwd=project_dir)

        if result.returncode == 0:
            return {"deployed": "railway", "output": result.stdout[-500:]}
        else:
            return {"error": f"Railway deploy failed: {result.stderr[:300]}"}

    except Exception as e:
        return {"error": str(e)}


def deploy_fly(project_dir: str = ".") -> Dict:
    """Deploy to Fly.io."""
    try:
        result = subprocess.run(["fly", "version"], capture_output=True, timeout=5)
        if result.returncode != 0:
            return {"error": "Install Fly CLI: curl -L https://fly.io/install.sh | sh"}

        # Check if fly.toml exists
        if not os.path.exists(os.path.join(project_dir, "fly.toml")):
            # Launch new app
            subprocess.run(["fly", "launch", "--yes", "--no-deploy"],
                           capture_output=True, timeout=60, cwd=project_dir)

        result = subprocess.run(["fly", "deploy"],
                                capture_output=True, text=True,
                                timeout=600, cwd=project_dir)

        if result.returncode == 0:
            return {"deployed": "fly", "output": result.stdout[-500:]}
        else:
            return {"error": f"Fly deploy failed: {result.stderr[:300]}"}

    except Exception as e:
        return {"error": str(e)}


def deploy_docker(project_dir: str = ".", image_name: str = "",
                  registry: str = "") -> Dict:
    """Build and push Docker image."""
    try:
        if not image_name:
            image_name = f"seraph-app-{int(time.time())}"

        full_name = f"{registry}/{image_name}" if registry else image_name

        # Build
        result = subprocess.run(
            ["docker", "build", "-t", full_name, "."],
            capture_output=True, text=True, timeout=600, cwd=project_dir,
        )
        if result.returncode != 0:
            return {"error": f"Docker build failed: {result.stderr[:300]}"}

        # Push if registry specified
        if registry:
            push = subprocess.run(
                ["docker", "push", full_name],
                capture_output=True, text=True, timeout=300,
            )
            if push.returncode != 0:
                return {"error": f"Docker push failed: {push.stderr[:300]}"}

        return {"deployed": "docker", "image": full_name,
                "pushed": bool(registry)}

    except Exception as e:
        return {"error": str(e)}


def deploy(platform: str, project_dir: str = ".", **kwargs) -> Dict:
    """Deploy to any platform."""
    deployers = {
        "vercel": deploy_vercel,
        "railway": deploy_railway,
        "fly": deploy_fly,
        "docker": deploy_docker,
    }
    fn = deployers.get(platform.lower())
    if not fn:
        return {"error": f"Unknown platform: {platform}. Available: {list(deployers.keys())}"}
    return fn(project_dir, **kwargs)
