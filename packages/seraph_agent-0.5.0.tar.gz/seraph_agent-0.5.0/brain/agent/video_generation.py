"""
Seraph Video Generation — generate videos via provider registry.

Supports: Fal, Runway, Pika, Stability AI, Luma.
Provider registry pattern — same as image/TTS/search.
"""

import os
import logging
import time
import requests
from typing import Dict, Optional, List

logger = logging.getLogger("seraph.video_gen")

PROVIDERS = {
    "fal": {
        "url": "https://fal.run/fal-ai/fast-svd-lcm",
        "env_key": "FAL_KEY",
    },
    "runway": {
        "url": "https://api.runwayml.com/v1/generations",
        "env_key": "RUNWAY_API_KEY",
    },
    "luma": {
        "url": "https://api.lumalabs.ai/dream-machine/v1/generations",
        "env_key": "LUMA_API_KEY",
    },
}


def generate_video(prompt: str, provider: str = "fal",
                   duration: int = 4, aspect: str = "16:9") -> Dict:
    """Generate a video from a text prompt."""
    cfg = PROVIDERS.get(provider)
    if not cfg:
        return {"error": f"Unknown provider: {provider}. Available: {list(PROVIDERS.keys())}"}

    api_key = os.environ.get(cfg["env_key"], "")
    if not api_key:
        return {"error": f"Set {cfg['env_key']} for {provider} video generation"}

    try:
        headers = {"Authorization": f"Key {api_key}", "Content-Type": "application/json"}
        body = {"prompt": prompt, "num_frames": duration * 8, "aspect_ratio": aspect}

        resp = requests.post(cfg["url"], headers=headers, json=body, timeout=120)
        if resp.status_code in (200, 201):
            data = resp.json()
            video_url = data.get("video", {}).get("url", data.get("url", data.get("output", "")))
            return {"video_url": video_url, "provider": provider, "prompt": prompt}
        else:
            return {"error": f"{provider} error {resp.status_code}: {resp.text[:200]}"}
    except Exception as e:
        return {"error": str(e)}


def list_providers() -> List[Dict]:
    return [
        {"name": name, "env_key": cfg["env_key"], "configured": bool(os.environ.get(cfg["env_key"]))}
        for name, cfg in PROVIDERS.items()
    ]
