"""
Seraph Agent Core — THE reasoning loop.

This is the SINGLE brain that ALL channels call into.
Telegram, Discord, Slack, IRC — they all route messages here.

The core handles:
- LLM calls with failover
- Tool execution with self-healing
- Memory (active + archive + user profiles)
- Context anchors (pinned facts)
- Bootstrap file injection
- Compaction (context overflow)
- Confidence gating
- Ambient learning
- Restart recovery
- Telemetry tracking
"""

import os
import sys
import json
import time
import asyncio
import logging
from pathlib import Path
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, field

logger = logging.getLogger("seraph.agent")

SERAPH_DIR = Path.home() / ".seraph"
sys.path.insert(0, str(Path(__file__).parent.parent))


@dataclass
class AgentConfig:
    provider: str = "anthropic"
    model: str = "claude-sonnet-4-6"
    max_iterations: int = 25
    max_tokens: int = 8192
    temperature: float = 0.7
    identity_file: str = "SOUL.md"
    memory_enabled: bool = True
    skills_enabled: bool = True
    audit_enabled: bool = True


@dataclass
class AgentResponse:
    text: str
    tool_calls: List[str] = field(default_factory=list)
    session_id: str = ""
    tokens_used: int = 0
    cost_usd: float = 0.0
    duration_ms: int = 0
    confidence: float = 0.0


def _run_tool(name: str, args: dict) -> dict:
    """Sync wrapper for async tool execution."""
    try:
        from tools.registry import execute_tool
        loop = asyncio.new_event_loop()
        result = loop.run_until_complete(execute_tool(name, args))
        loop.close()
        return result
    except Exception as e:
        return {"error": str(e)}


class SeraphAgent:
    """
    The core agent — ONE brain for all channels.

    Usage:
        agent = SeraphAgent()
        response = agent.process("Hello", user_id="123", session_key="chat_123")
    """

    def __init__(self, config: AgentConfig = None):
        self.config = config or AgentConfig()
        self.config.provider = os.environ.get("SERAPH_PROVIDER", self.config.provider)
        self.config.model = os.environ.get("SERAPH_MODEL", self.config.model)

        # LLM
        self.llm = None
        try:
            from agent.llm import LLMProvider
            self.llm = LLMProvider(provider=self.config.provider, model=self.config.model)
        except Exception as e:
            logger.error(f"LLM init: {e}")

        # Memory
        self.memory = None
        try:
            from memory.store import get_memory
            self.memory = get_memory()
        except Exception as e:
            logger.warning(f"Memory init: {e}")

        # Identity
        self.identity = "You are Seraph, a self-improving AI agent."
        soul_path = SERAPH_DIR / self.config.identity_file
        if soul_path.exists():
            self.identity = soul_path.read_text(encoding="utf-8", errors="replace")

        # Failover
        self.failover_chain = []
        try:
            from models.router import ModelRouter
            router = ModelRouter(default_model=self.config.model)
            self.failover_chain = router.get_failover_chain(self.config.model).models
        except Exception:
            pass

        # Telemetry
        self.telemetry = None
        try:
            from diagnostics.telemetry import get_telemetry
            self.telemetry = get_telemetry()
        except Exception:
            pass

        # Conversations (in-memory, backed by session store)
        self.conversations: Dict[str, List[Dict]] = {}

        logger.info(f"Agent ready: {self.config.provider}/{self.config.model}")

    def process(self, text: str, user_id: str = "", session_key: str = "",
                channel: str = "api") -> AgentResponse:
        """
        Process a message through the full agent loop.

        This is the MAIN ENTRY POINT — every channel calls this.
        """
        start = time.time()

        if not self.llm:
            return AgentResponse(text="LLM not connected. Check API keys.")

        # Link understanding — auto-fetch URLs
        try:
            from agent.link_understanding import process_message_links
            text, _ = process_message_links(text)
        except Exception:
            pass

        # Ambient learning
        try:
            from agent.ambient_learning import get_ambient_learner
            get_ambient_learner().on_message(user_id, text)
        except Exception:
            pass

        # Dreaming activity
        try:
            from agent.dreaming import get_dreaming_engine
            get_dreaming_engine().record_activity()
        except Exception:
            pass

        # Get/restore conversation history
        if session_key not in self.conversations:
            if self.memory:
                saved = self.memory.get_session_history(session_key, limit=20)
                if saved:
                    self.conversations[session_key] = [
                        {"role": m["role"], "content": m["content"]} for m in saved
                    ]
                else:
                    self.conversations[session_key] = []
            else:
                self.conversations[session_key] = []

        history = self.conversations[session_key]
        history.append({"role": "user", "content": text})

        # Save to memory
        if self.memory:
            self.memory.save_message(session_key, user_id, "user", text)

        # Auto-compress
        try:
            from agent.context_manager import should_compress, auto_compress
            if should_compress(history):
                history = auto_compress(history, llm=self.llm, target_messages=15)
                self.conversations[session_key] = history
            elif len(history) > 30:
                history = history[-20:]
                self.conversations[session_key] = history
        except Exception:
            if len(history) > 30:
                history = history[-20:]
                self.conversations[session_key] = history

        # Build system prompt
        full_identity = self.identity

        # Context anchors
        try:
            from agent.context_anchors import get_anchor_store
            anchors = get_anchor_store().format_for_prompt()
            if anchors:
                full_identity += "\n\n" + anchors
        except Exception:
            pass

        # Bootstrap files
        try:
            from agent.bootstrap import inject_bootstrap
            full_identity = inject_bootstrap(full_identity)
        except Exception:
            pass

        # Memory injection (for established conversations)
        if self.memory and len(history) > 2:
            try:
                active_mem = self.memory.format_active_for_prompt()
                user_profile = self.memory.format_user_for_prompt(user_id)
                if active_mem:
                    full_identity += "\n\n## Active Memory\n" + active_mem
                if user_profile:
                    full_identity += "\n\n## User Profile\n" + user_profile
            except Exception:
                pass

        # Ambient learning preferences
        try:
            from agent.ambient_learning import get_ambient_learner
            prefs = get_ambient_learner().format_for_prompt()
            if prefs:
                full_identity += "\n\n" + prefs
        except Exception:
            pass

        # Tool loop
        try:
            from tools.registry import get_openai_tool_schemas
            from tools.filter import filter_tools
            from agent.loop_detection import LoopDetector

            all_tools = get_openai_tool_schemas()
            tools = filter_tools(text, all_tools)
            loop_detector = LoopDetector()
            total_input = 0
            total_output = 0
            final_text = ""

            for iteration in range(self.config.max_iterations):
                # LLM call with failover
                call_start = time.time()
                try:
                    response = self.llm.chat(
                        messages=history, system=full_identity,
                        tools=tools if tools else None,
                    )
                except Exception as llm_err:
                    response = self._try_failover(history, full_identity, tools, llm_err)
                    if response is None:
                        return AgentResponse(text=f"LLM error: {llm_err}",
                                             duration_ms=int((time.time()-start)*1000))

                call_ms = int((time.time() - call_start) * 1000)
                total_input += response.input_tokens
                total_output += response.output_tokens

                # Telemetry
                if self.telemetry:
                    self.telemetry.track_llm_call(
                        self.llm.provider, self.llm.model,
                        response.input_tokens, response.output_tokens, call_ms,
                    )

                # Track usage
                try:
                    from tools.usage import track
                    track(self.llm.model, response.input_tokens, response.output_tokens)
                except Exception:
                    pass

                # Final response (no tool calls)
                if not response.tool_calls:
                    final_text = response.text or ""

                    # Confidence gating
                    try:
                        from agent.confidence import assess_confidence
                        assessment = assess_confidence(final_text)
                        if assessment.caveat:
                            final_text = assessment.caveat + final_text
                    except Exception:
                        pass

                    history.append({"role": "assistant", "content": final_text})
                    if self.memory:
                        self.memory.save_message(session_key, session_key, "assistant",
                                                 final_text, response.output_tokens)

                    # Clear restart recovery
                    try:
                        from agent.restart_recovery import mark_completed
                        mark_completed(session_key)
                    except Exception:
                        pass

                    break

                # Tool calls
                tool_call_msg = {
                    "role": "assistant",
                    "content": response.text or None,
                    "tool_calls": [
                        {"id": tc["id"], "type": "function",
                         "function": {"name": tc["name"],
                                      "arguments": json.dumps(tc["arguments"])}}
                        for tc in response.tool_calls
                    ],
                }
                history.append(tool_call_msg)

                for tc in response.tool_calls:
                    tool_name = tc["name"]
                    tool_args = tc["arguments"]

                    # Execute with self-healing
                    result = _run_tool(tool_name, tool_args)

                    if isinstance(result, dict) and "error" in result:
                        try:
                            from agent.self_healing import classify_failure, attempt_recovery
                            failure = classify_failure(tool_name, str(result["error"]))
                            if failure != "unknown":
                                recovery = attempt_recovery(tool_name, tool_args,
                                                            str(result["error"]), failure)
                                if recovery and recovery.get("retry"):
                                    result = _run_tool(tool_name,
                                                       recovery.get("retry_args", tool_args))
                        except Exception:
                            pass

                    # Telemetry
                    if self.telemetry:
                        self.telemetry.track_tool_call(tool_name, 0,
                                                       "error" not in (result if isinstance(result, dict) else {}))

                    # Ambient learning
                    try:
                        from agent.ambient_learning import get_ambient_learner
                        get_ambient_learner().on_tool_call(tool_name)
                    except Exception:
                        pass

                    # Loop detection
                    loop_check = loop_detector.record(tool_name, tool_args, result)
                    if loop_check["action"] == "break":
                        final_text = f"Stopped: {loop_check['reason']}"
                        break

                    # Save recovery state
                    try:
                        from agent.restart_recovery import save_state
                        save_state(session_key, str(user_id), user_id, channel,
                                   text, iteration, [tool_name], self.llm.model)
                    except Exception:
                        pass

                    result_str = json.dumps(result, default=str)
                    if len(result_str) > 5000:
                        result_str = result_str[:5000] + "...(truncated)"

                    history.append({
                        "role": "tool",
                        "tool_call_id": tc["id"],
                        "content": result_str,
                    })

            duration = int((time.time() - start) * 1000)

            # Skill extraction for complex conversations
            if iteration >= 3:
                try:
                    from agent.skill_extraction import extract_skill_from_conversation, save_skill
                    skill = extract_skill_from_conversation(history, session_key)
                    if skill and skill.confidence >= 0.5:
                        save_skill(skill)
                except Exception:
                    pass

            return AgentResponse(
                text=final_text,
                tool_calls=[tc["name"] for tc in response.tool_calls] if response.tool_calls else [],
                session_id=session_key,
                tokens_used=total_input + total_output,
                duration_ms=duration,
            )

        except Exception as e:
            logger.error(f"Agent error: {e}")
            return AgentResponse(text=f"Error: {e}",
                                 duration_ms=int((time.time()-start)*1000))

    def _try_failover(self, history, system, tools, original_error):
        """Try fallback models."""
        for model_id in self.failover_chain:
            if model_id == self.llm.model:
                continue
            try:
                from agent.llm import LLMProvider, get_provider_for_model
                provider = get_provider_for_model(model_id) or self.llm.provider
                fb = LLMProvider(provider=provider, model=model_id)
                return fb.chat(messages=history, system=system,
                               tools=tools if tools else None)
            except Exception:
                continue
        return None

    def clear(self, session_key: str):
        """Clear a conversation."""
        self.conversations.pop(session_key, None)

    def handle_btw(self, text: str, session_key: str) -> str:
        """Handle /btw side-question without polluting history."""
        try:
            from agent.btw import handle_btw
            history = self.conversations.get(session_key, [])
            return handle_btw(text, history, self.identity, self.llm)
        except Exception as e:
            return f"Error: {e}"


# Singleton
_agent = None

def get_agent(config: AgentConfig = None) -> SeraphAgent:
    global _agent
    if _agent is None:
        _agent = SeraphAgent(config)
    return _agent
