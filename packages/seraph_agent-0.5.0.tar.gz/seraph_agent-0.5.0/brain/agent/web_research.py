"""
Seraph Web Research Environment — structured research workflow.

Multi-step research: search -> read -> extract -> synthesize.
Produces structured research reports with sources.
"""

import logging
import time
from typing import Dict, List
from dataclasses import dataclass, field

logger = logging.getLogger("seraph.research")


@dataclass
class ResearchResult:
    query: str
    sources: List[Dict] = field(default_factory=list)
    findings: List[str] = field(default_factory=list)
    summary: str = ""
    confidence: float = 0.0
    duration_ms: int = 0


def research(query: str, max_sources: int = 5, llm=None) -> ResearchResult:
    """Run a structured web research workflow."""
    start = time.time()
    result = ResearchResult(query=query)

    # Step 1: Search
    try:
        from tools.registry import execute_tool
        import asyncio
        loop = asyncio.new_event_loop()
        search_result = loop.run_until_complete(
            execute_tool("web_search", {"query": query, "num_results": max_sources})
        )
        loop.close()

        sources = search_result.get("results", [])[:max_sources]
        result.sources = sources
    except Exception as e:
        logger.warning(f"Research search failed: {e}")
        result.summary = f"Search failed: {e}"
        return result

    # Step 2: Read top sources
    for source in sources[:3]:
        try:
            url = source.get("url", "")
            if url:
                from agent.link_understanding import fetch_url_content
                content = fetch_url_content(url)
                if content:
                    source["content"] = content[:3000]
                    result.findings.append(f"From {url}: {content[:200]}...")
        except Exception:
            pass

    # Step 3: Synthesize (if LLM available)
    if llm and result.findings:
        try:
            findings_text = "\n\n".join(result.findings[:5])
            prompt = (
                f"Research query: {query}\n\n"
                f"Sources found:\n{findings_text}\n\n"
                f"Provide a concise research summary with key findings."
            )
            response = llm.chat(
                messages=[{"role": "user", "content": prompt}],
                system="You are a research assistant. Synthesize findings concisely.",
            )
            result.summary = response.text
            result.confidence = 0.7 if len(result.sources) >= 3 else 0.4
        except Exception as e:
            result.summary = f"Synthesis failed: {e}"

    result.duration_ms = int((time.time() - start) * 1000)
    return result
