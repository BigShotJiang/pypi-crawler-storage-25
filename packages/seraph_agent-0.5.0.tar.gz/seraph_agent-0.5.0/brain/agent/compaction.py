"""
Seraph Session Compaction — prevents context overflow.

When conversation history approaches the model's context window, compaction
summarizes older messages into a condensed summary, preserving:
- Active tasks and their status
- Decisions made and rationale
- Key identifiers (file paths, URLs, IDs, tokens)
- The last user request and what was being done

Based on OpenClaw's approach but simpler and more robust.
"""

import json
import logging
import time
from typing import Dict, List, Any, Optional
from dataclasses import dataclass

logger = logging.getLogger("seraph.compaction")

# Token estimation: ~4 chars per token (rough but fast)
CHARS_PER_TOKEN = 4

# When to trigger compaction (% of context window used)
COMPACTION_THRESHOLD = 0.75

# How much history to keep after compaction (% of context window)
TARGET_AFTER_COMPACTION = 0.40

# Safety margin for token estimation inaccuracy
SAFETY_MARGIN = 1.2

# Minimum messages to keep (never compact below this)
MIN_MESSAGES_KEEP = 4

# Overhead for the summarization prompt itself
SUMMARIZATION_OVERHEAD_TOKENS = 2048


@dataclass
class CompactionResult:
    """Result of a compaction operation."""
    compacted: bool
    summary: str = ""
    messages_before: int = 0
    messages_after: int = 0
    tokens_before: int = 0
    tokens_after: int = 0
    duration_ms: int = 0


SUMMARIZATION_SYSTEM = """You are summarizing a conversation for context preservation.
Your summary will replace the older messages so the AI can continue working.

MUST PRESERVE:
- Active tasks and their current status (in-progress, blocked, done)
- Batch operation progress (e.g., '5/17 items completed')
- The last thing the user requested and what was being done
- Decisions made and their rationale
- TODOs, open questions, and constraints
- Any commitments or follow-ups promised
- All file paths, URLs, UUIDs, IDs, tokens, API keys, hostnames exactly as written

PRIORITIZE recent context over older history.
Keep it concise but complete — nothing critical should be lost.
Output ONLY the summary text, no preamble."""


def estimate_tokens(text: str) -> int:
    """Estimate token count from text length."""
    if not text:
        return 0
    return max(1, int(len(text) / CHARS_PER_TOKEN * SAFETY_MARGIN))


def estimate_messages_tokens(messages: List[Dict]) -> int:
    """Estimate total tokens across all messages."""
    total = 0
    for msg in messages:
        content = msg.get("content", "")
        if isinstance(content, str):
            total += estimate_tokens(content)
        elif isinstance(content, list):
            # Handle structured content blocks
            for block in content:
                if isinstance(block, dict):
                    total += estimate_tokens(json.dumps(block))
                elif isinstance(block, str):
                    total += estimate_tokens(block)
        # Add overhead for role, tool metadata, etc.
        total += 10
    return total


def needs_compaction(messages: List[Dict], context_window: int) -> bool:
    """Check if the conversation needs compaction."""
    if len(messages) <= MIN_MESSAGES_KEEP:
        return False
    current_tokens = estimate_messages_tokens(messages)
    threshold = int(context_window * COMPACTION_THRESHOLD)
    return current_tokens >= threshold


def split_messages_for_compaction(messages: List[Dict], context_window: int) -> tuple:
    """
    Split messages into (to_summarize, to_keep).

    Keeps the most recent messages that fit within TARGET_AFTER_COMPACTION,
    and marks the rest for summarization.

    Never splits in the middle of a tool call/result pair.
    """
    if len(messages) <= MIN_MESSAGES_KEEP:
        return [], messages

    target_keep_tokens = int(context_window * TARGET_AFTER_COMPACTION)

    # Walk backwards from the end, accumulating messages to keep
    keep_tokens = 0
    split_index = len(messages)

    for i in range(len(messages) - 1, -1, -1):
        msg_tokens = estimate_messages_tokens([messages[i]])
        if keep_tokens + msg_tokens > target_keep_tokens:
            split_index = i + 1
            break
        keep_tokens += msg_tokens

    # Ensure we keep at least MIN_MESSAGES_KEEP
    split_index = min(split_index, len(messages) - MIN_MESSAGES_KEEP)
    split_index = max(split_index, 0)

    # Don't split in the middle of a tool call/result pair
    # If the split point lands on a tool result, move it back to include the tool call
    if split_index < len(messages):
        msg = messages[split_index]
        role = msg.get("role", "")
        if role in ("tool", "tool_result"):
            # Walk back to find the assistant message with the tool call
            for j in range(split_index - 1, -1, -1):
                if messages[j].get("role") == "assistant":
                    split_index = j
                    break

    to_summarize = messages[:split_index]
    to_keep = messages[split_index:]

    return to_summarize, to_keep


def build_summary_prompt(messages: List[Dict], previous_summary: str = "") -> str:
    """Build the prompt for the summarization LLM call."""
    parts = []

    if previous_summary:
        parts.append(f"PREVIOUS CONTEXT SUMMARY:\n{previous_summary}")
        parts.append("---")

    parts.append("CONVERSATION TO SUMMARIZE:")
    for msg in messages:
        role = msg.get("role", "unknown").upper()
        content = msg.get("content", "")
        if isinstance(content, list):
            content = json.dumps(content)
        if len(content) > 2000:
            content = content[:2000] + "... [truncated]"
        parts.append(f"[{role}]: {content}")

    parts.append("---")
    parts.append("Write a concise summary preserving all critical context:")

    return "\n\n".join(parts)


async def compact_session(
    messages: List[Dict],
    context_window: int,
    llm_call,
    previous_summary: str = "",
) -> CompactionResult:
    """
    Compact a session's message history.

    Args:
        messages: Full message history
        context_window: Model's context window in tokens
        llm_call: Async function(messages, system) -> LLMResponse
        previous_summary: Summary from a previous compaction

    Returns:
        CompactionResult with the new messages list
    """
    start = time.time()
    tokens_before = estimate_messages_tokens(messages)

    if not needs_compaction(messages, context_window):
        return CompactionResult(
            compacted=False,
            messages_before=len(messages),
            messages_after=len(messages),
            tokens_before=tokens_before,
            tokens_after=tokens_before,
        )

    logger.info(
        f"Compacting session: {len(messages)} messages, "
        f"~{tokens_before} tokens (threshold: {int(context_window * COMPACTION_THRESHOLD)})"
    )

    to_summarize, to_keep = split_messages_for_compaction(messages, context_window)

    if not to_summarize:
        return CompactionResult(
            compacted=False,
            messages_before=len(messages),
            messages_after=len(messages),
            tokens_before=tokens_before,
            tokens_after=tokens_before,
        )

    # Generate summary via LLM
    summary_prompt = build_summary_prompt(to_summarize, previous_summary)
    summary_messages = [{"role": "user", "content": summary_prompt}]

    try:
        response = await llm_call(summary_messages, SUMMARIZATION_SYSTEM)
        summary = response.text if hasattr(response, 'text') else str(response)
    except Exception as e:
        logger.error(f"Compaction summarization failed: {e}")
        # Fallback: just truncate without summary
        summary = previous_summary or "Context was compacted but summarization failed."

    # Build new message list: summary as system context + kept messages
    new_messages = [
        {"role": "system", "content": f"[Previous conversation summary]\n{summary}"},
        *to_keep,
    ]

    tokens_after = estimate_messages_tokens(new_messages)
    duration = int((time.time() - start) * 1000)

    logger.info(
        f"Compaction complete: {len(messages)} -> {len(new_messages)} messages, "
        f"~{tokens_before} -> ~{tokens_after} tokens ({duration}ms)"
    )

    return CompactionResult(
        compacted=True,
        summary=summary,
        messages_before=len(messages),
        messages_after=len(new_messages),
        tokens_before=tokens_before,
        tokens_after=tokens_after,
        duration_ms=duration,
    )
