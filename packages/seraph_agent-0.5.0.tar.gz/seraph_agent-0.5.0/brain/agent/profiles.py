"""
Seraph Profiles — multiple named agent personalities.

Each profile has its own: identity (SOUL.md), model, provider, memory scope,
skill set, and rules. Switch profiles with /profile <name>.

Profiles stored in ~/.seraph/profiles/<name>/
"""

import os
import json
import logging
import shutil
from typing import Dict, List, Optional
from pathlib import Path

logger = logging.getLogger("seraph.profiles")

SERAPH_DIR = Path.home() / ".seraph"
PROFILES_DIR = SERAPH_DIR / "profiles"


def list_profiles() -> List[Dict]:
    """List all available profiles."""
    PROFILES_DIR.mkdir(parents=True, exist_ok=True)
    profiles = [{"name": "default", "path": str(SERAPH_DIR), "active": True}]
    for d in sorted(PROFILES_DIR.iterdir()):
        if d.is_dir():
            config = {}
            cfg_path = d / "profile.json"
            if cfg_path.exists():
                try:
                    config = json.loads(cfg_path.read_text())
                except Exception:
                    pass
            profiles.append({
                "name": d.name,
                "path": str(d),
                "model": config.get("model", ""),
                "provider": config.get("provider", ""),
                "description": config.get("description", ""),
                "active": False,
            })
    return profiles


def create_profile(name: str, model: str = "", provider: str = "",
                   description: str = "", copy_from: str = "default") -> Dict:
    """Create a new profile."""
    profile_dir = PROFILES_DIR / name
    if profile_dir.exists():
        return {"error": f"Profile '{name}' already exists"}

    profile_dir.mkdir(parents=True)

    # Copy identity from source
    if copy_from == "default":
        soul_src = SERAPH_DIR / "SOUL.md"
    else:
        soul_src = PROFILES_DIR / copy_from / "SOUL.md"

    soul_dst = profile_dir / "SOUL.md"
    if soul_src.exists():
        shutil.copy2(soul_src, soul_dst)
    else:
        soul_dst.write_text(f"# {name}\n\nI am {name}, a Seraph agent profile.\n")

    # Save profile config
    config = {
        "name": name, "model": model or os.environ.get("SERAPH_MODEL", ""),
        "provider": provider or os.environ.get("SERAPH_PROVIDER", ""),
        "description": description,
    }
    (profile_dir / "profile.json").write_text(json.dumps(config, indent=2))
    (profile_dir / "skills").mkdir(exist_ok=True)

    return {"created": name, "path": str(profile_dir)}


def load_profile(name: str) -> Optional[Dict]:
    """Load a profile's configuration."""
    if name == "default":
        return {"name": "default", "path": str(SERAPH_DIR),
                "model": os.environ.get("SERAPH_MODEL", ""),
                "provider": os.environ.get("SERAPH_PROVIDER", "")}

    profile_dir = PROFILES_DIR / name
    if not profile_dir.exists():
        return None

    config = {"name": name, "path": str(profile_dir)}
    cfg_path = profile_dir / "profile.json"
    if cfg_path.exists():
        try:
            config.update(json.loads(cfg_path.read_text()))
        except Exception:
            pass

    # Load identity
    soul = profile_dir / "SOUL.md"
    if soul.exists():
        config["identity"] = soul.read_text(encoding="utf-8", errors="replace")

    return config


def delete_profile(name: str) -> Dict:
    """Delete a profile."""
    if name == "default":
        return {"error": "Cannot delete default profile"}
    profile_dir = PROFILES_DIR / name
    if not profile_dir.exists():
        return {"error": f"Profile '{name}' not found"}
    shutil.rmtree(profile_dir)
    return {"deleted": name}
