"""
Seraph LLM Provider — 23 providers, 200+ models.

Supports: Anthropic, OpenAI, Google, DeepSeek, Ollama, Groq, Together, xAI,
Mistral, Fireworks, OpenRouter, GitHub Copilot, Amazon Bedrock, Azure,
NVIDIA, Cloudflare AI Gateway, Vercel AI Gateway, Venice, LiteLLM, vLLM,
Qwen, Moonshot, StepFun, BytePlus/Volcengine, Minimax.
"""

import os
import json
import logging
import time
import copy
from typing import Dict, List, Any, Optional
from dataclasses import dataclass

logger = logging.getLogger("seraph.llm")


@dataclass
class LLMResponse:
    """Response from an LLM provider."""
    text: str
    tool_calls: List[Dict] = None
    input_tokens: int = 0
    output_tokens: int = 0
    model: str = ""
    stop_reason: str = ""
    provider: str = ""

    def __post_init__(self):
        if self.tool_calls is None:
            self.tool_calls = []


# ─── Provider Registry ─────────────────────────────────────────────
# Most providers speak the OpenAI chat completions format.
# Only Anthropic, Google, and Bedrock need custom implementations.

OPENAI_COMPATIBLE_PROVIDERS = {
    "openai": {
        "base_url": "https://api.openai.com/v1",
        "env_key": "OPENAI_API_KEY",
        "max_tokens_field": "max_completion_tokens",
    },
    "deepseek": {
        "base_url": "https://api.deepseek.com/v1",
        "env_key": "DEEPSEEK_API_KEY",
    },
    "ollama": {
        "base_url": "http://localhost:11434/v1",
        "env_key": "OLLAMA_API_KEY",
        "auth_optional": True,
    },
    "groq": {
        "base_url": "https://api.groq.com/openai/v1",
        "env_key": "GROQ_API_KEY",
    },
    "together": {
        "base_url": "https://api.together.xyz/v1",
        "env_key": "TOGETHER_API_KEY",
    },
    "xai": {
        "base_url": "https://api.x.ai/v1",
        "env_key": "XAI_API_KEY",
    },
    "mistral": {
        "base_url": "https://api.mistral.ai/v1",
        "env_key": "MISTRAL_API_KEY",
    },
    "fireworks": {
        "base_url": "https://api.fireworks.ai/inference/v1",
        "env_key": "FIREWORKS_API_KEY",
    },
    "openrouter": {
        "base_url": "https://openrouter.ai/api/v1",
        "env_key": "OPENROUTER_API_KEY",
        "extra_headers": {
            "HTTP-Referer": "https://seraph.so",
            "X-Title": "Seraph Agent",
        },
    },
    "nvidia": {
        "base_url": "https://integrate.api.nvidia.com/v1",
        "env_key": "NVIDIA_API_KEY",
    },
    "venice": {
        "base_url": "https://api.venice.ai/api/v1",
        "env_key": "VENICE_API_KEY",
    },
    "moonshot": {
        "base_url": "https://api.moonshot.cn/v1",
        "env_key": "MOONSHOT_API_KEY",
    },
    "stepfun": {
        "base_url": "https://api.stepfun.com/v1",
        "env_key": "STEPFUN_API_KEY",
    },
    "qwen": {
        "base_url": "https://dashscope.aliyuncs.com/compatible-mode/v1",
        "env_key": "QWEN_API_KEY",
    },
    "minimax": {
        "base_url": "https://api.minimax.chat/v1",
        "env_key": "MINIMAX_API_KEY",
    },
    "litellm": {
        "base_url": "http://localhost:4000/v1",
        "env_key": "LITELLM_API_KEY",
        "auth_optional": True,
    },
    "vllm": {
        "base_url": "http://localhost:8000/v1",
        "env_key": "VLLM_API_KEY",
        "auth_optional": True,
    },
    "volcengine": {
        "base_url": "https://ark.cn-beijing.volces.com/api/v3",
        "env_key": "VOLCENGINE_API_KEY",
    },
    "perplexity": {
        "base_url": "https://api.perplexity.ai",
        "env_key": "PERPLEXITY_API_KEY",
    },
    "github_copilot": {
        "base_url": "https://api.githubcopilot.com",
        "env_key": "GITHUB_TOKEN",
        "extra_headers": {
            "Editor-Version": "Seraph/1.0",
            "Copilot-Integration-Id": "seraph-agent",
        },
    },
}

# Custom providers that need their own API format
CUSTOM_PROVIDERS = {"anthropic", "google", "azure", "bedrock", "cloudflare", "vercel"}

ALL_PROVIDERS = set(OPENAI_COMPATIBLE_PROVIDERS.keys()) | CUSTOM_PROVIDERS


class LLMProvider:
    """Multi-provider LLM interface — 23 providers, one API."""

    def __init__(self, provider: str = "openai", model: str = "gpt-5.4",
                 api_key: str = "", base_url: str = ""):
        self.provider = provider
        self.model = model
        self.base_url_override = base_url
        self.api_key = api_key or self._find_api_key()
        self._request_count = 0
        self._last_request_time = 0.0

        # Validate provider
        if provider not in ALL_PROVIDERS:
            raise ValueError(
                f"Unknown provider '{provider}'. "
                f"Available: {sorted(ALL_PROVIDERS)}"
            )

        # Auth check (skip for local providers)
        provider_cfg = OPENAI_COMPATIBLE_PROVIDERS.get(provider, {})
        if not self.api_key and not provider_cfg.get("auth_optional") and provider not in CUSTOM_PROVIDERS:
            raise ValueError(
                f"No API key for '{provider}'. "
                f"Set {provider_cfg.get('env_key', provider.upper() + '_API_KEY')} in .env"
            )

        logger.info(f"LLM Provider: {provider} / {model}")

    def _find_api_key(self) -> str:
        """Auto-detect API key from environment."""
        # Check OpenAI-compatible registry first
        cfg = OPENAI_COMPATIBLE_PROVIDERS.get(self.provider)
        if cfg:
            return os.environ.get(cfg["env_key"], "")

        # Custom providers
        env_map = {
            "anthropic": "ANTHROPIC_API_KEY",
            "google": "GOOGLE_API_KEY",
            "azure": "AZURE_OPENAI_API_KEY",
            "bedrock": "AWS_ACCESS_KEY_ID",
            "cloudflare": "CLOUDFLARE_API_TOKEN",
            "vercel": "VERCEL_API_TOKEN",
        }
        return os.environ.get(env_map.get(self.provider, ""), "")

    # ─── Main Entry Point ──────────────────────────────────────────

    def chat(self, messages: List[Dict], system: str = "",
             tools: List[Dict] = None) -> LLMResponse:
        """Send a chat request to the LLM."""
        # Route to provider implementation
        if self.provider == "anthropic":
            return self._call_anthropic(messages, system, tools)
        elif self.provider == "google":
            return self._call_google(messages, system, tools)
        elif self.provider == "azure":
            return self._call_azure(messages, system, tools)
        elif self.provider == "bedrock":
            return self._call_bedrock(messages, system, tools)
        elif self.provider == "cloudflare":
            return self._call_cloudflare_gateway(messages, system, tools)
        elif self.provider == "vercel":
            return self._call_vercel_gateway(messages, system, tools)
        elif self.provider in OPENAI_COMPATIBLE_PROVIDERS:
            return self._call_openai_compatible(messages, system, tools)
        else:
            raise ValueError(f"No implementation for provider: {self.provider}")

    # ─── Anthropic (Custom Format) ─────────────────────────────────

    def _call_anthropic(self, messages: List[Dict], system: str,
                        tools: List[Dict] = None) -> LLMResponse:
        """Call Anthropic Claude API."""
        import anthropic

        client = anthropic.Anthropic(api_key=self.api_key)

        kwargs = {
            "model": self.model,
            "max_tokens": 8192,
            "messages": messages,
        }
        if system:
            kwargs["system"] = system
        if tools:
            kwargs["tools"] = tools

        try:
            response = client.messages.create(**kwargs)

            text = ""
            tool_calls = []

            for block in response.content:
                if block.type == "text":
                    text += block.text
                elif block.type == "tool_use":
                    tool_calls.append({
                        "id": block.id,
                        "name": block.name,
                        "arguments": block.input,
                    })

            return LLMResponse(
                text=text,
                tool_calls=tool_calls,
                input_tokens=response.usage.input_tokens,
                output_tokens=response.usage.output_tokens,
                model=self.model,
                stop_reason=response.stop_reason,
                provider="anthropic",
            )

        except anthropic.RateLimitError:
            logger.warning("Anthropic rate limited, waiting 30s...")
            time.sleep(30)
            return self._call_anthropic(messages, system, tools)
        except Exception as e:
            logger.error(f"Anthropic API error: {e}")
            return LLMResponse(text=f"Error: {e}", model=self.model, provider="anthropic")

    # ─── Google Gemini (Custom Format) ─────────────────────────────

    def _call_google(self, messages: List[Dict], system: str,
                     tools: List[Dict] = None) -> LLMResponse:
        """Call Google Gemini API."""
        import requests

        api_key = self.api_key or os.environ.get("GOOGLE_API_KEY", "")
        if not api_key:
            return LLMResponse(text="Error: GOOGLE_API_KEY not set", model=self.model, provider="google")

        # Convert OpenAI-style messages to Gemini format
        contents = []
        for msg in messages:
            role = "user" if msg["role"] == "user" else "model"
            content = msg.get("content", "")
            if isinstance(content, str) and content:
                contents.append({"role": role, "parts": [{"text": content}]})

        body = {"contents": contents}
        if system:
            body["systemInstruction"] = {"parts": [{"text": system}]}

        # Tool support
        if tools:
            gemini_tools = []
            for tool in tools:
                fn = tool.get("function", tool)
                gemini_tools.append({
                    "functionDeclarations": [{
                        "name": fn.get("name", ""),
                        "description": fn.get("description", ""),
                        "parameters": fn.get("parameters", fn.get("input_schema", {})),
                    }]
                })
            body["tools"] = gemini_tools

        body["generationConfig"] = {
            "maxOutputTokens": 8192,
            "temperature": 0.7,
        }

        url = f"https://generativelanguage.googleapis.com/v1beta/models/{self.model}:generateContent?key={api_key}"

        try:
            resp = requests.post(url, json=body, timeout=60)
            if resp.status_code != 200:
                logger.error(f"Gemini error {resp.status_code}: {resp.text[:300]}")
                return LLMResponse(text=f"Gemini error: {resp.status_code}", model=self.model, provider="google")

            data = resp.json()
            candidates = data.get("candidates", [])
            if not candidates:
                return LLMResponse(text="No response from Gemini", model=self.model, provider="google")

            parts = candidates[0].get("content", {}).get("parts", [])
            text = ""
            tool_calls = []
            for part in parts:
                if "text" in part:
                    text += part["text"]
                elif "functionCall" in part:
                    fc = part["functionCall"]
                    tool_calls.append({
                        "id": f"call_{int(time.time())}_{fc['name']}",
                        "name": fc["name"],
                        "arguments": fc.get("args", {}),
                    })

            usage = data.get("usageMetadata", {})
            return LLMResponse(
                text=text,
                tool_calls=tool_calls,
                input_tokens=usage.get("promptTokenCount", 0),
                output_tokens=usage.get("candidatesTokenCount", 0),
                model=self.model,
                stop_reason=candidates[0].get("finishReason", ""),
                provider="google",
            )

        except Exception as e:
            logger.error(f"Google Gemini error: {e}")
            return LLMResponse(text=f"Error: {e}", model=self.model, provider="google")

    # ─── Azure OpenAI (Custom URL Format) ──────────────────────────

    def _call_azure(self, messages: List[Dict], system: str,
                    tools: List[Dict] = None) -> LLMResponse:
        """Call Azure OpenAI — uses api-key header instead of Bearer token."""
        import requests

        endpoint = os.environ.get("AZURE_OPENAI_ENDPOINT", "")
        api_version = os.environ.get("AZURE_OPENAI_API_VERSION", "2024-10-21")
        deployment = os.environ.get("AZURE_OPENAI_DEPLOYMENT", self.model)

        if not endpoint:
            return LLMResponse(text="Error: AZURE_OPENAI_ENDPOINT not set", model=self.model, provider="azure")

        url = f"{endpoint}/openai/deployments/{deployment}/chat/completions?api-version={api_version}"

        full_messages = []
        if system:
            full_messages.append({"role": "system", "content": system})
        full_messages.extend(messages)

        body = {"messages": full_messages, "max_tokens": 4096}
        if tools:
            body["tools"] = self._format_openai_tools(tools)

        headers = {"api-key": self.api_key, "Content-Type": "application/json"}

        try:
            resp = requests.post(url, headers=headers, json=body, timeout=60)
            return self._parse_openai_response(resp, "azure")
        except Exception as e:
            logger.error(f"Azure OpenAI error: {e}")
            return LLMResponse(text=f"Error: {e}", model=self.model, provider="azure")

    # ─── Amazon Bedrock (AWS SDK) ──────────────────────────────────

    def _call_bedrock(self, messages: List[Dict], system: str,
                      tools: List[Dict] = None) -> LLMResponse:
        """Call Amazon Bedrock — uses boto3 with AWS credentials."""
        try:
            import boto3
        except ImportError:
            return LLMResponse(
                text="Error: boto3 not installed. Run: pip install boto3",
                model=self.model, provider="bedrock",
            )

        region = os.environ.get("AWS_REGION", "us-east-1")
        client = boto3.client("bedrock-runtime", region_name=region)

        full_messages = []
        if system:
            full_messages.append({"role": "system", "content": system})
        full_messages.extend(messages)

        body = {
            "messages": full_messages,
            "max_tokens": 4096,
            "anthropic_version": "bedrock-2023-05-31",
        }
        if tools:
            body["tools"] = tools

        try:
            response = client.invoke_model(
                modelId=self.model,
                contentType="application/json",
                accept="application/json",
                body=json.dumps(body),
            )
            result = json.loads(response["body"].read())

            text = ""
            tool_calls = []
            for block in result.get("content", []):
                if block.get("type") == "text":
                    text += block["text"]
                elif block.get("type") == "tool_use":
                    tool_calls.append({
                        "id": block["id"],
                        "name": block["name"],
                        "arguments": block.get("input", {}),
                    })

            usage = result.get("usage", {})
            return LLMResponse(
                text=text,
                tool_calls=tool_calls,
                input_tokens=usage.get("input_tokens", 0),
                output_tokens=usage.get("output_tokens", 0),
                model=self.model,
                stop_reason=result.get("stop_reason", ""),
                provider="bedrock",
            )

        except Exception as e:
            logger.error(f"Bedrock error: {e}")
            return LLMResponse(text=f"Error: {e}", model=self.model, provider="bedrock")

    # ─── Cloudflare AI Gateway (Proxy) ─────────────────────────────

    def _call_cloudflare_gateway(self, messages: List[Dict], system: str,
                                  tools: List[Dict] = None) -> LLMResponse:
        """Cloudflare AI Gateway — proxies to any provider with caching/logging."""
        import requests

        account_id = os.environ.get("CLOUDFLARE_ACCOUNT_ID", "")
        gateway_id = os.environ.get("CLOUDFLARE_GATEWAY_ID", "")
        target_provider = os.environ.get("CLOUDFLARE_TARGET_PROVIDER", "openai")

        if not account_id or not gateway_id:
            return LLMResponse(
                text="Error: Set CLOUDFLARE_ACCOUNT_ID and CLOUDFLARE_GATEWAY_ID",
                model=self.model, provider="cloudflare",
            )

        base = f"https://gateway.ai.cloudflare.com/v1/{account_id}/{gateway_id}/{target_provider}"
        url = f"{base}/chat/completions"

        full_messages = []
        if system:
            full_messages.append({"role": "system", "content": system})
        full_messages.extend(messages)

        body = {"model": self.model, "messages": full_messages, "max_tokens": 4096}
        if tools:
            body["tools"] = self._format_openai_tools(tools)

        # Use the target provider's API key
        target_key_env = OPENAI_COMPATIBLE_PROVIDERS.get(target_provider, {}).get("env_key", "OPENAI_API_KEY")
        target_key = os.environ.get(target_key_env, self.api_key)

        headers = {
            "Authorization": f"Bearer {target_key}",
            "Content-Type": "application/json",
        }

        try:
            resp = requests.post(url, headers=headers, json=body, timeout=60)
            return self._parse_openai_response(resp, "cloudflare")
        except Exception as e:
            logger.error(f"Cloudflare Gateway error: {e}")
            return LLMResponse(text=f"Error: {e}", model=self.model, provider="cloudflare")

    # ─── Vercel AI Gateway (Proxy) ─────────────────────────────────

    def _call_vercel_gateway(self, messages: List[Dict], system: str,
                              tools: List[Dict] = None) -> LLMResponse:
        """Vercel AI Gateway — proxies to configured provider."""
        import requests

        gateway_url = os.environ.get("VERCEL_AI_GATEWAY_URL", "")
        if not gateway_url:
            return LLMResponse(
                text="Error: Set VERCEL_AI_GATEWAY_URL",
                model=self.model, provider="vercel",
            )

        full_messages = []
        if system:
            full_messages.append({"role": "system", "content": system})
        full_messages.extend(messages)

        body = {"model": self.model, "messages": full_messages, "max_tokens": 4096}
        if tools:
            body["tools"] = self._format_openai_tools(tools)

        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

        try:
            resp = requests.post(f"{gateway_url}/chat/completions", headers=headers, json=body, timeout=60)
            return self._parse_openai_response(resp, "vercel")
        except Exception as e:
            logger.error(f"Vercel Gateway error: {e}")
            return LLMResponse(text=f"Error: {e}", model=self.model, provider="vercel")

    # ─── Generic OpenAI-Compatible Handler ─────────────────────────

    def _call_openai_compatible(self, messages: List[Dict], system: str,
                                 tools: List[Dict] = None) -> LLMResponse:
        """Generic handler for all OpenAI-compatible providers."""
        import requests

        cfg = OPENAI_COMPATIBLE_PROVIDERS[self.provider]
        base_url = self.base_url_override or cfg["base_url"]
        url = f"{base_url}/chat/completions"

        full_messages = []
        if system:
            full_messages.append({"role": "system", "content": system})
        full_messages.extend(messages)

        # Build body
        max_field = cfg.get("max_tokens_field", "max_tokens")
        body = {
            "model": self.model,
            "messages": full_messages,
            max_field: 4096,
        }
        if tools:
            body["tools"] = self._format_openai_tools(tools)

        # Build headers
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        # Provider-specific extra headers
        extra = cfg.get("extra_headers", {})
        headers.update(extra)

        try:
            resp = requests.post(url, headers=headers, json=body, timeout=60)
            return self._parse_openai_response(resp, self.provider)

        except Exception as e:
            logger.error(f"{self.provider} API error: {e}")
            return LLMResponse(text=f"Error: {e}", model=self.model, provider=self.provider)

    # ─── Streaming ─────────────────────────────────────────────────

    def chat_stream(self, messages: List[Dict], system: str = "",
                    tools: List[Dict] = None):
        """Stream a chat response, yielding partial text chunks."""
        if self.provider in OPENAI_COMPATIBLE_PROVIDERS:
            yield from self._stream_openai_compatible(messages, system, tools)
        elif self.provider == "anthropic":
            yield from self._stream_anthropic(messages, system, tools)
        else:
            # Fallback to non-streaming
            response = self.chat(messages, system, tools)
            yield response

    def _stream_openai_compatible(self, messages: List[Dict], system: str,
                                   tools: List[Dict] = None):
        """Stream from any OpenAI-compatible provider."""
        import requests

        cfg = OPENAI_COMPATIBLE_PROVIDERS.get(self.provider, {})
        base_url = self.base_url_override or cfg.get("base_url", "https://api.openai.com/v1")
        url = f"{base_url}/chat/completions"

        full_messages = []
        if system:
            full_messages.append({"role": "system", "content": system})
        full_messages.extend(messages)

        max_field = cfg.get("max_tokens_field", "max_tokens")
        body = {
            "model": self.model,
            "messages": full_messages,
            max_field: 4096,
        }

        # Don't stream when tools are present (tool calls don't stream well)
        if tools:
            body["tools"] = self._format_openai_tools(tools)
            resp = self.chat(messages, system, tools)
            yield resp
            return

        body["stream"] = True

        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        headers.update(cfg.get("extra_headers", {}))

        try:
            resp = requests.post(url, headers=headers, json=body, timeout=60, stream=True)
            if resp.status_code != 200:
                yield LLMResponse(text=f"Error: {resp.status_code}", model=self.model, provider=self.provider)
                return

            for line in resp.iter_lines():
                if not line:
                    continue
                decoded = line.decode("utf-8", errors="replace")
                if not decoded.startswith("data: "):
                    continue
                data_str = decoded[6:]
                if data_str.strip() == "[DONE]":
                    break
                try:
                    chunk = json.loads(data_str)
                    delta = chunk.get("choices", [{}])[0].get("delta", {})
                    content = delta.get("content", "")
                    if content:
                        yield content
                except json.JSONDecodeError:
                    continue

        except Exception as e:
            logger.error(f"{self.provider} streaming error: {e}")
            yield f"Error: {e}"

    def _stream_anthropic(self, messages: List[Dict], system: str,
                          tools: List[Dict] = None):
        """Stream from Anthropic."""
        if tools:
            resp = self.chat(messages, system, tools)
            yield resp
            return

        try:
            import anthropic

            client = anthropic.Anthropic(api_key=self.api_key)

            kwargs = {
                "model": self.model,
                "max_tokens": 8192,
                "messages": messages,
            }
            if system:
                kwargs["system"] = system

            with client.messages.stream(**kwargs) as stream:
                for text in stream.text_stream:
                    yield text

        except Exception as e:
            logger.error(f"Anthropic streaming error: {e}")
            yield f"Error: {e}"

    # ─── Shared Helpers ────────────────────────────────────────────

    def _format_openai_tools(self, tools: List[Dict]) -> List[Dict]:
        """Normalize tool definitions to OpenAI function-calling format."""
        formatted = []
        for tool in tools:
            if "function" in tool:
                formatted.append(tool)
            elif "name" in tool:
                formatted.append({
                    "type": "function",
                    "function": {
                        "name": tool["name"],
                        "description": tool.get("description", ""),
                        "parameters": tool.get("parameters", tool.get("input_schema", {})),
                    },
                })
            else:
                formatted.append(tool)
        return formatted

    def _parse_openai_response(self, resp, provider: str) -> LLMResponse:
        """Parse a standard OpenAI chat completions response."""
        if resp.status_code != 200:
            error_text = resp.text[:300] if hasattr(resp, 'text') else str(resp.status_code)
            logger.error(f"{provider} error {resp.status_code}: {error_text}")
            return LLMResponse(
                text=f"{provider} error: {resp.status_code}",
                model=self.model, provider=provider,
            )

        data = resp.json()
        choices = data.get("choices", [])
        if not choices:
            return LLMResponse(text="No response", model=self.model, provider=provider)

        choice = choices[0]
        message = choice.get("message", {})
        text = message.get("content", "") or ""
        tool_calls = []

        if message.get("tool_calls"):
            for tc in message["tool_calls"]:
                args = tc.get("function", {}).get("arguments", "{}")
                if isinstance(args, str):
                    try:
                        args = json.loads(args)
                    except json.JSONDecodeError:
                        args = {}
                tool_calls.append({
                    "id": tc.get("id", f"call_{int(time.time())}"),
                    "name": tc.get("function", {}).get("name", ""),
                    "arguments": args,
                })

        usage = data.get("usage", {})
        return LLMResponse(
            text=text,
            tool_calls=tool_calls,
            input_tokens=usage.get("prompt_tokens", 0),
            output_tokens=usage.get("completion_tokens", 0),
            model=self.model,
            stop_reason=choice.get("finish_reason", ""),
            provider=provider,
        )


# ─── Convenience ───────────────────────────────────────────────────

def list_providers() -> List[Dict]:
    """List all available providers with their config requirements."""
    providers = []
    for name, cfg in OPENAI_COMPATIBLE_PROVIDERS.items():
        providers.append({
            "name": name,
            "type": "openai_compatible",
            "env_key": cfg["env_key"],
            "base_url": cfg["base_url"],
            "auth_required": not cfg.get("auth_optional", False),
        })
    for name in CUSTOM_PROVIDERS:
        env_map = {
            "anthropic": "ANTHROPIC_API_KEY",
            "google": "GOOGLE_API_KEY",
            "azure": "AZURE_OPENAI_API_KEY",
            "bedrock": "AWS_ACCESS_KEY_ID",
            "cloudflare": "CLOUDFLARE_API_TOKEN",
            "vercel": "VERCEL_API_TOKEN",
        }
        providers.append({
            "name": name,
            "type": "custom",
            "env_key": env_map.get(name, ""),
            "auth_required": True,
        })
    return sorted(providers, key=lambda p: p["name"])


def get_provider_for_model(model_id: str) -> Optional[str]:
    """Guess provider from model ID prefix."""
    prefixes = {
        "gpt-": "openai", "o1-": "openai", "o3-": "openai", "o4-": "openai",
        "claude-": "anthropic",
        "gemini-": "google",
        "deepseek-": "deepseek",
        "llama-": "together", "llama3": "together",
        "mixtral-": "mistral", "mistral-": "mistral",
        "grok-": "xai",
        "qwen-": "qwen", "qwen2": "qwen",
        "accounts/fireworks": "fireworks",
        "meta-llama/": "together",
    }
    for prefix, provider in prefixes.items():
        if model_id.startswith(prefix) or model_id.lower().startswith(prefix):
            return provider
    return None
