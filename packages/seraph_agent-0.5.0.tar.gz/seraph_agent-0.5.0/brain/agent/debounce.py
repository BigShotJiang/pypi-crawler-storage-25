"""
Seraph Inbound Message Debounce — combine rapid-fire messages into one.

When a user sends 5 messages in 2 seconds, combine them into one LLM call
instead of making 5 separate calls. Saves tokens and gives better responses.

Configurable window (default 2 seconds). After the window closes,
all accumulated messages are joined with newlines and processed as one.
"""

import time
import logging
import threading
from typing import Dict, List, Callable, Optional
from dataclasses import dataclass, field

logger = logging.getLogger("seraph.debounce")

DEFAULT_WINDOW_MS = 2000  # 2 seconds


@dataclass
class PendingBatch:
    messages: List[str] = field(default_factory=list)
    first_received: float = 0.0
    last_received: float = 0.0
    user_id: str = ""
    timer: Optional[threading.Timer] = None


class MessageDebouncer:
    """Debounce rapid-fire messages per chat."""

    def __init__(self, window_ms: int = DEFAULT_WINDOW_MS):
        self.window_s = window_ms / 1000
        self.pending: Dict[str, PendingBatch] = {}  # chat_id -> batch
        self._lock = threading.Lock()

    def receive(self, chat_id: str, user_id: str, text: str,
                process_fn: Callable[[str, str, str], None]):
        """
        Receive a message. Either starts a new batch window or adds to existing.

        After the window expires, calls process_fn(chat_id, user_id, combined_text).
        """
        with self._lock:
            if chat_id in self.pending:
                batch = self.pending[chat_id]
                batch.messages.append(text)
                batch.last_received = time.time()

                # Cancel existing timer and set a new one
                if batch.timer:
                    batch.timer.cancel()
                batch.timer = threading.Timer(
                    self.window_s,
                    self._flush,
                    args=(chat_id, process_fn),
                )
                batch.timer.start()
            else:
                # First message — start a new batch
                batch = PendingBatch(
                    messages=[text],
                    first_received=time.time(),
                    last_received=time.time(),
                    user_id=user_id,
                )
                self.pending[chat_id] = batch

                # Set timer to flush after window
                batch.timer = threading.Timer(
                    self.window_s,
                    self._flush,
                    args=(chat_id, process_fn),
                )
                batch.timer.start()

    def _flush(self, chat_id: str, process_fn: Callable):
        """Flush the pending batch — combine messages and process."""
        with self._lock:
            batch = self.pending.pop(chat_id, None)

        if not batch or not batch.messages:
            return

        # Combine messages
        if len(batch.messages) == 1:
            combined = batch.messages[0]
        else:
            combined = "\n".join(batch.messages)
            logger.info(f"Debounced {len(batch.messages)} messages for {chat_id}")

        # Process the combined message
        try:
            process_fn(chat_id, batch.user_id, combined)
        except Exception as e:
            logger.error(f"Debounce process error: {e}")

    def cancel(self, chat_id: str):
        """Cancel pending batch for a chat."""
        with self._lock:
            batch = self.pending.pop(chat_id, None)
            if batch and batch.timer:
                batch.timer.cancel()

    def get_pending_count(self) -> int:
        """Get number of chats with pending batches."""
        return len(self.pending)


_debouncer = None

def get_debouncer(window_ms: int = DEFAULT_WINDOW_MS) -> MessageDebouncer:
    global _debouncer
    if _debouncer is None:
        _debouncer = MessageDebouncer(window_ms)
    return _debouncer
