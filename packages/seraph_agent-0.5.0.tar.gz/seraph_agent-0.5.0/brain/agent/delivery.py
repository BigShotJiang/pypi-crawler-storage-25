"""
Seraph Delivery Queue — reliable message delivery with retry.

Ensures messages get delivered even if the channel is temporarily down.
Queues failed deliveries and retries with exponential backoff.
"""

import json
import time
import logging
import threading
from pathlib import Path
from typing import Dict, List, Callable, Optional
from collections import deque

logger = logging.getLogger("seraph.delivery")

QUEUE_FILE = Path.home() / ".seraph" / "delivery_queue.json"
MAX_RETRIES = 5
RETRY_BACKOFF = [5, 15, 30, 60, 120]  # seconds


class DeliveryItem:
    def __init__(self, channel: str, target: str, message: str, metadata: dict = None):
        self.channel = channel
        self.target = target
        self.message = message
        self.metadata = metadata or {}
        self.attempts = 0
        self.next_retry = 0
        self.created = time.time()
        self.last_error = ""

    def to_dict(self) -> dict:
        return {
            "channel": self.channel,
            "target": self.target,
            "message": self.message[:5000],
            "metadata": self.metadata,
            "attempts": self.attempts,
            "next_retry": self.next_retry,
            "created": self.created,
            "last_error": self.last_error,
        }

    @classmethod
    def from_dict(cls, d: dict) -> 'DeliveryItem':
        item = cls(d["channel"], d["target"], d["message"], d.get("metadata", {}))
        item.attempts = d.get("attempts", 0)
        item.next_retry = d.get("next_retry", 0)
        item.created = d.get("created", time.time())
        item.last_error = d.get("last_error", "")
        return item


class DeliveryQueue:
    """Persistent message delivery queue with retry logic."""

    def __init__(self):
        self.queue: deque = deque()
        self.senders: Dict[str, Callable] = {}  # channel -> send function
        self.running = False
        self.thread = None
        self._lock = threading.Lock()
        self._load()

    def register_sender(self, channel: str, send_fn: Callable):
        """Register a send function for a channel."""
        self.senders[channel] = send_fn

    def enqueue(self, channel: str, target: str, message: str, metadata: dict = None):
        """Add a message to the delivery queue."""
        item = DeliveryItem(channel, target, message, metadata)
        with self._lock:
            self.queue.append(item)
            self._save()
        logger.debug(f"Enqueued delivery: {channel} -> {target}")

    def deliver(self, channel: str, target: str, message: str, metadata: dict = None) -> bool:
        """Try to deliver immediately, queue on failure."""
        sender = self.senders.get(channel)
        if not sender:
            self.enqueue(channel, target, message, metadata)
            return False

        try:
            sender(target, message)
            return True
        except Exception as e:
            logger.warning(f"Delivery failed ({channel} -> {target}): {e}")
            self.enqueue(channel, target, message, metadata)
            return False

    def _process_queue(self):
        """Process pending deliveries."""
        now = time.time()
        with self._lock:
            retried = deque()
            while self.queue:
                item = self.queue.popleft()

                if item.next_retry > now:
                    retried.append(item)
                    continue

                if item.attempts >= MAX_RETRIES:
                    logger.error(f"Delivery permanently failed: {item.channel} -> {item.target} after {item.attempts} attempts")
                    continue

                sender = self.senders.get(item.channel)
                if not sender:
                    retried.append(item)
                    continue

                try:
                    sender(item.target, item.message)
                    logger.info(f"Delivery retry succeeded: {item.channel} -> {item.target}")
                except Exception as e:
                    item.attempts += 1
                    backoff = RETRY_BACKOFF[min(item.attempts - 1, len(RETRY_BACKOFF) - 1)]
                    item.next_retry = now + backoff
                    item.last_error = str(e)[:200]
                    retried.append(item)

            self.queue = retried
            self._save()

    def start(self):
        """Start background retry thread."""
        self.running = True
        self.thread = threading.Thread(target=self._loop, daemon=True)
        self.thread.start()

    def stop(self):
        self.running = False

    def _loop(self):
        while self.running:
            self._process_queue()
            time.sleep(10)

    def _load(self):
        if QUEUE_FILE.exists():
            try:
                data = json.loads(QUEUE_FILE.read_text(encoding="utf-8"))
                self.queue = deque(DeliveryItem.from_dict(d) for d in data)
            except Exception:
                self.queue = deque()

    def _save(self):
        try:
            QUEUE_FILE.parent.mkdir(parents=True, exist_ok=True)
            data = [item.to_dict() for item in self.queue]
            tmp = QUEUE_FILE.with_suffix(".tmp")
            tmp.write_text(json.dumps(data), encoding="utf-8")
            tmp.replace(QUEUE_FILE)
        except Exception as e:
            logger.error(f"Failed to save delivery queue: {e}")

    def get_status(self) -> dict:
        with self._lock:
            return {
                "pending": len(self.queue),
                "channels": list(self.senders.keys()),
                "items": [item.to_dict() for item in list(self.queue)[:10]],
            }


# Singleton
_queue = None

def get_delivery_queue() -> DeliveryQueue:
    global _queue
    if _queue is None:
        _queue = DeliveryQueue()
    return _queue
