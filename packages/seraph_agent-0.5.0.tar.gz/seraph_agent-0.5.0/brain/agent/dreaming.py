"""
Seraph Dreaming — background memory consolidation.

Runs during idle periods (no active conversations) to:
1. Consolidate short-term memories into long-term patterns
2. Identify recurring user preferences
3. Extract reusable skills from conversation history
4. Prune stale memories
5. Build concept vocabulary for better retrieval

Inspired by OpenClaw's memory-core/dreaming.ts but implemented natively.
"""

import json
import time
import logging
import threading
from typing import Dict, List, Optional
from pathlib import Path
from datetime import datetime, timezone, timedelta

logger = logging.getLogger("seraph.dreaming")

SERAPH_DIR = Path.home() / ".seraph"
DREAM_LOG_PATH = SERAPH_DIR / "dream_log.json"


class DreamingEngine:
    """
    Background memory consolidation engine.

    Runs as a daemon thread, waking up periodically to process memories.
    Only runs when the agent is idle (no active conversations).
    """

    def __init__(self, idle_threshold_seconds: int = 300, cycle_interval: int = 3600):
        self.idle_threshold = idle_threshold_seconds  # 5 min idle = start dreaming
        self.cycle_interval = cycle_interval  # Dream every hour
        self.last_activity = time.time()
        self.last_dream = 0.0
        self.dream_count = 0
        self._running = False
        self._thread: Optional[threading.Thread] = None

    def record_activity(self):
        """Call this when any user interaction happens."""
        self.last_activity = time.time()

    def is_idle(self) -> bool:
        """Check if the agent has been idle long enough to dream."""
        return time.time() - self.last_activity >= self.idle_threshold

    def start(self):
        """Start the dreaming daemon thread."""
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._run_loop, daemon=True)
        self._thread.start()
        logger.info("Dreaming engine started")

    def stop(self):
        """Stop the dreaming daemon."""
        self._running = False

    def _run_loop(self):
        """Main dreaming loop — runs in background thread."""
        while self._running:
            time.sleep(60)  # Check every minute

            if not self.is_idle():
                continue

            if time.time() - self.last_dream < self.cycle_interval:
                continue

            try:
                self._dream_cycle()
            except Exception as e:
                logger.error(f"Dream cycle error: {e}")

    def _dream_cycle(self):
        """Run one consolidation cycle."""
        start = time.time()
        logger.info("Dreaming: starting consolidation cycle...")

        results = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "actions": [],
        }

        # 1. Prune stale memories
        pruned = self._prune_stale_memories()
        if pruned:
            results["actions"].append(f"Pruned {pruned} stale memories")

        # 2. Consolidate repeated patterns
        patterns = self._find_patterns()
        if patterns:
            results["actions"].append(f"Found {len(patterns)} recurring patterns")

        # 3. Extract user preferences
        prefs = self._extract_preferences()
        if prefs:
            results["actions"].append(f"Updated {len(prefs)} user preferences")

        # 4. Archive old sessions
        archived = self._archive_old_sessions()
        if archived:
            results["actions"].append(f"Archived {archived} old sessions")

        duration = int((time.time() - start) * 1000)
        results["duration_ms"] = duration
        self.last_dream = time.time()
        self.dream_count += 1

        # Log the dream
        self._save_dream_log(results)
        logger.info(f"Dream cycle complete ({duration}ms): {results['actions']}")

    def _prune_stale_memories(self) -> int:
        """Remove memories older than cleanup_days."""
        try:
            from memory.store import get_memory
            mem = get_memory()
            cutoff_days = 90
            pruned = mem.prune_old_messages(cutoff_days)
            return pruned
        except Exception:
            return 0

    def _find_patterns(self) -> List[Dict]:
        """Find recurring patterns in conversation history."""
        # TODO: Use LLM to identify patterns in recent conversations
        # For now, return empty
        return []

    def _extract_preferences(self) -> List[Dict]:
        """Extract user preferences from conversation corrections."""
        # TODO: Analyze user corrections (e.g., "no, I meant X") and store as preferences
        return []

    def _archive_old_sessions(self) -> int:
        """Archive sessions older than 7 days."""
        try:
            from sessions.store import get_session_store
            store = get_session_store()
            sessions = store.list_sessions(status="active", limit=100)
            archived = 0
            cutoff = time.time() - (7 * 86400)
            for s in sessions:
                if s.get("updated_at", 0) < cutoff:
                    store.archive_session(s["id"])
                    archived += 1
            return archived
        except Exception:
            return 0

    def _save_dream_log(self, entry: dict):
        """Append to dream log."""
        try:
            log = []
            if DREAM_LOG_PATH.exists():
                with open(DREAM_LOG_PATH) as f:
                    log = json.load(f)
            log.append(entry)
            log = log[-100:]  # Keep last 100
            import os
            tmp = str(DREAM_LOG_PATH) + ".tmp"
            with open(tmp, "w") as f:
                json.dump(log, f, indent=2)
            os.replace(tmp, str(DREAM_LOG_PATH))
        except Exception:
            pass

    def get_stats(self) -> Dict:
        """Get dreaming stats."""
        return {
            "dream_count": self.dream_count,
            "last_dream": self.last_dream,
            "is_idle": self.is_idle(),
            "idle_seconds": int(time.time() - self.last_activity),
            "running": self._running,
        }


_engine: Optional[DreamingEngine] = None

def get_dreaming_engine() -> DreamingEngine:
    global _engine
    if _engine is None:
        _engine = DreamingEngine()
    return _engine
