"""
Seraph Bootstrap — auto-load project-specific instructions at session start.

Looks for BOOTSTRAP.md, CLAUDE.md, SERAPH.md, .seraph/instructions.md
in the workspace and injects them into the system prompt.

This is how project-specific context gets loaded — coding conventions,
deployment instructions, team rules, architecture notes.
"""

import os
import logging
from typing import List, Optional
from pathlib import Path

logger = logging.getLogger("seraph.bootstrap")

# Files to look for, in priority order
BOOTSTRAP_FILES = [
    "SERAPH.md",
    "BOOTSTRAP.md",
    "CLAUDE.md",
    ".seraph/instructions.md",
    ".seraph/BOOTSTRAP.md",
    ".claude/CLAUDE.md",
    "AGENTS.md",
    ".cursorrules",
    ".github/copilot-instructions.md",
]

MAX_BOOTSTRAP_SIZE = 50_000  # 50KB max total bootstrap content
MAX_SINGLE_FILE = 20_000    # 20KB max per file


def find_bootstrap_files(workspace: str = None) -> List[Path]:
    """Find all bootstrap files in the workspace."""
    ws = Path(workspace) if workspace else Path.cwd()
    found = []

    for filename in BOOTSTRAP_FILES:
        path = ws / filename
        if path.exists() and path.is_file():
            found.append(path)

    # Also check parent directories (up to 3 levels)
    parent = ws.parent
    for _ in range(3):
        if parent == parent.parent:
            break
        for filename in BOOTSTRAP_FILES[:3]:  # Only check top-priority files
            path = parent / filename
            if path.exists() and path.is_file():
                found.append(path)
        parent = parent.parent

    return found


def load_bootstrap_content(workspace: str = None) -> str:
    """
    Load and combine all bootstrap files.

    Returns a formatted string ready for injection into the system prompt.
    """
    files = find_bootstrap_files(workspace)
    if not files:
        return ""

    parts = []
    total_size = 0

    for path in files:
        try:
            size = path.stat().st_size
            if size > MAX_SINGLE_FILE:
                logger.warning(f"Bootstrap file too large, truncating: {path} ({size} bytes)")

            content = path.read_text(encoding="utf-8", errors="replace")[:MAX_SINGLE_FILE]
            total_size += len(content)

            if total_size > MAX_BOOTSTRAP_SIZE:
                logger.warning("Bootstrap total size exceeded, stopping file loading")
                break

            parts.append(f"## {path.name}\n{content}")
            logger.info(f"Loaded bootstrap: {path.name} ({len(content)} chars)")

        except Exception as e:
            logger.warning(f"Failed to read bootstrap {path}: {e}")

    if not parts:
        return ""

    return "## Project Instructions (auto-loaded)\n\n" + "\n\n---\n\n".join(parts)


def inject_bootstrap(system_prompt: str, workspace: str = None) -> str:
    """
    Inject bootstrap content into the system prompt.

    Appends bootstrap content after the identity/personality section.
    """
    bootstrap = load_bootstrap_content(workspace)
    if not bootstrap:
        return system_prompt

    return system_prompt + "\n\n" + bootstrap
