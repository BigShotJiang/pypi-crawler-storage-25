"""
Seraph Self-Healing Tool Chain — auto-diagnose and fix tool failures.

When a tool call fails, instead of just reporting the error, this module:
1. Classifies the failure
2. Attempts automatic recovery
3. Only reports to user if self-healing fails

Common auto-fixes:
- Missing package → pip install
- Permission denied → suggest/run chmod
- File not found → search for similar files
- Connection refused → check service status
- Timeout → retry with longer timeout
- JSON decode error → attempt to parse partial output
"""

import re
import os
import time
import logging
import subprocess
import asyncio
from typing import Dict, Optional, Tuple
from pathlib import Path

logger = logging.getLogger("seraph.self_healing")


def classify_failure(tool_name: str, error: str) -> str:
    """Classify a tool failure for auto-recovery."""
    err_lower = error.lower()

    if "modulenotfounderror" in err_lower or "no module named" in err_lower:
        return "missing_package"
    if "permission denied" in err_lower or "eacces" in err_lower:
        return "permission"
    if "no such file or directory" in err_lower or "filenotfounderror" in err_lower:
        return "file_not_found"
    if "connection refused" in err_lower or "econnrefused" in err_lower:
        return "connection_refused"
    if "timed out" in err_lower or "timeout" in err_lower:
        return "timeout"
    if "json" in err_lower and ("decode" in err_lower or "parse" in err_lower):
        return "json_error"
    if "disk" in err_lower and ("full" in err_lower or "space" in err_lower):
        return "disk_full"
    if "memory" in err_lower or "oom" in err_lower:
        return "out_of_memory"
    if "command not found" in err_lower or "not recognized" in err_lower:
        return "command_not_found"
    if "rate limit" in err_lower or "429" in err_lower:
        return "rate_limited"

    return "unknown"


def attempt_recovery(tool_name: str, args: dict, error: str,
                     failure_type: str) -> Optional[Dict]:
    """
    Attempt to automatically fix the failure and retry.

    Returns the tool result if recovery succeeded, or None if it failed.
    """
    logger.info(f"Self-healing: {failure_type} in {tool_name}")

    if failure_type == "missing_package":
        return _fix_missing_package(error)

    elif failure_type == "file_not_found":
        return _fix_file_not_found(tool_name, args, error)

    elif failure_type == "connection_refused":
        return _fix_connection_refused(error)

    elif failure_type == "timeout":
        return _fix_timeout(tool_name, args)

    elif failure_type == "command_not_found":
        return _fix_command_not_found(error)

    elif failure_type == "json_error":
        return _fix_json_error(error)

    elif failure_type == "permission":
        return _fix_permission(tool_name, args, error)

    elif failure_type == "rate_limited":
        return _fix_rate_limit()

    return None


def _fix_missing_package(error: str) -> Optional[Dict]:
    """Auto-install missing Python packages."""
    match = re.search(r"No module named '(\w+)'", error)
    if not match:
        match = re.search(r"ModuleNotFoundError.*'(\w+)'", error)
    if not match:
        return None

    package = match.group(1)
    # Common name mappings
    name_map = {
        "cv2": "opencv-python",
        "PIL": "Pillow",
        "sklearn": "scikit-learn",
        "yaml": "pyyaml",
        "bs4": "beautifulsoup4",
        "dotenv": "python-dotenv",
    }
    pip_name = name_map.get(package, package)

    logger.info(f"Auto-installing: {pip_name}")
    try:
        result = subprocess.run(
            ["pip", "install", pip_name],
            capture_output=True, text=True, timeout=60,
        )
        if result.returncode == 0:
            return {"self_healed": True, "action": f"Installed {pip_name}", "retry": True}
    except Exception:
        pass

    return None


def _fix_file_not_found(tool_name: str, args: dict, error: str) -> Optional[Dict]:
    """Search for the file in nearby locations."""
    path = args.get("path", args.get("file_path", args.get("file", "")))
    if not path:
        return None

    filename = os.path.basename(path)
    search_dirs = [
        os.path.dirname(path),
        os.getcwd(),
        str(Path.home()),
        str(Path.home() / ".seraph" / "workspace"),
    ]

    for search_dir in search_dirs:
        if not os.path.isdir(search_dir):
            continue
        for root, dirs, files in os.walk(search_dir):
            if filename in files:
                found = os.path.join(root, filename)
                return {
                    "self_healed": True,
                    "action": f"File found at: {found}",
                    "suggested_path": found,
                    "retry": True,
                    "retry_args": {**args, "path": found},
                }
            # Limit search depth
            if root.count(os.sep) - search_dir.count(os.sep) > 3:
                break

    return None


def _fix_connection_refused(error: str) -> Optional[Dict]:
    """Check if the service needs to be started."""
    # Extract host:port from error
    match = re.search(r"(\d+\.\d+\.\d+\.\d+):(\d+)", error)
    if not match:
        match = re.search(r"localhost:(\d+)", error)

    if match:
        port = match.group(2) if len(match.groups()) > 1 else match.group(1)
        try:
            result = subprocess.run(
                ["lsof", "-i", f":{port}"],
                capture_output=True, text=True, timeout=5,
            )
            if not result.stdout.strip():
                return {
                    "self_healed": False,
                    "diagnosis": f"Nothing listening on port {port}",
                    "suggestion": f"Start the service that should be listening on port {port}",
                }
        except Exception:
            pass

    return None


def _fix_timeout(tool_name: str, args: dict) -> Optional[Dict]:
    """Retry with a longer timeout."""
    return {
        "self_healed": True,
        "action": "Retrying with 2x timeout",
        "retry": True,
        "retry_args": {**args, "timeout": args.get("timeout", 30) * 2},
    }


def _fix_command_not_found(error: str) -> Optional[Dict]:
    """Suggest installing the missing command."""
    match = re.search(r"(?:command not found|not recognized).*?(\w+)", error, re.IGNORECASE)
    if match:
        cmd = match.group(1)
        # Common install suggestions
        install_map = {
            "node": "Install Node.js: https://nodejs.org",
            "npm": "Install Node.js: https://nodejs.org",
            "go": "Install Go: https://go.dev/dl/",
            "docker": "Install Docker: https://docs.docker.com/get-docker/",
            "git": "Install git: apt install git / brew install git",
            "python3": "Install Python: https://python.org",
            "pip": "pip is included with Python 3.4+",
            "curl": "apt install curl / brew install curl",
            "jq": "apt install jq / brew install jq",
        }
        suggestion = install_map.get(cmd, f"Install '{cmd}' using your package manager")
        return {"self_healed": False, "diagnosis": f"Command '{cmd}' not found", "suggestion": suggestion}

    return None


def _fix_json_error(error: str) -> Optional[Dict]:
    """Try to extract usable data from malformed JSON."""
    return {"self_healed": False, "diagnosis": "Malformed JSON in output", "suggestion": "The command output wasn't valid JSON. Try running it again."}


def _fix_permission(tool_name: str, args: dict, error: str) -> Optional[Dict]:
    """Diagnose permission issues."""
    path = args.get("path", args.get("file_path", ""))
    if path:
        return {
            "self_healed": False,
            "diagnosis": f"Permission denied on {path}",
            "suggestion": f"Run: chmod +r {path} (or use sudo if needed)",
        }
    return None


def _fix_rate_limit() -> Optional[Dict]:
    """Wait and retry on rate limits."""
    logger.info("Rate limited, waiting 30s before retry...")
    time.sleep(30)
    return {"self_healed": True, "action": "Waited 30s for rate limit", "retry": True}


# ─── Integration Point ───────────────────────────────────────────

async def execute_with_healing(tool_name: str, args: dict,
                                execute_fn, max_retries: int = 2) -> dict:
    """
    Execute a tool with automatic self-healing on failure.

    Wraps the normal tool execution with failure detection and recovery.
    """
    for attempt in range(max_retries + 1):
        try:
            result = await execute_fn(tool_name, args)

            # Check if result indicates an error
            if isinstance(result, dict) and "error" in result:
                error = str(result["error"])
                failure_type = classify_failure(tool_name, error)

                if failure_type != "unknown" and attempt < max_retries:
                    recovery = attempt_recovery(tool_name, args, error, failure_type)
                    if recovery and recovery.get("retry"):
                        logger.info(f"Self-healed: {recovery.get('action')}")
                        args = recovery.get("retry_args", args)
                        continue  # Retry with fixed args
                    elif recovery:
                        # Add diagnosis to result
                        result["_self_healing"] = recovery
                        return result

            return result

        except Exception as e:
            error = str(e)
            failure_type = classify_failure(tool_name, error)

            if failure_type != "unknown" and attempt < max_retries:
                recovery = attempt_recovery(tool_name, args, error, failure_type)
                if recovery and recovery.get("retry"):
                    args = recovery.get("retry_args", args)
                    continue

            return {"error": error, "self_healing_attempted": True}

    return {"error": "Max retries exceeded", "self_healing_attempted": True}
