"""
Seraph Conversation Branching — git for conversations.

"Try approach A" → branch. "Try approach B" → branch. Compare. Merge winner.

Features:
- Branch a conversation at any point
- Run parallel approaches
- Compare results across branches
- Merge the winning branch back
- Undo/redo across branches
"""

import json
import time
import copy
import logging
import os
from typing import Dict, List, Optional
from pathlib import Path
from dataclasses import dataclass, field

logger = logging.getLogger("seraph.branching")

SERAPH_DIR = Path.home() / ".seraph"


@dataclass
class Branch:
    """A conversation branch."""
    id: str
    parent_id: str  # "" for root
    name: str
    messages: List[Dict] = field(default_factory=list)
    created_at: float = field(default_factory=time.time)
    forked_at_index: int = 0  # Message index where this branched from parent
    active: bool = True
    result_summary: str = ""  # Summary of what happened in this branch


class ConversationTree:
    """Manage branched conversations."""

    def __init__(self, session_id: str):
        self.session_id = session_id
        self.branches: Dict[str, Branch] = {}
        self.current_branch: str = "main"
        self._ensure_main()

    def _ensure_main(self):
        if "main" not in self.branches:
            self.branches["main"] = Branch(id="main", parent_id="", name="main")

    def get_current(self) -> Branch:
        """Get the current branch."""
        return self.branches.get(self.current_branch, self.branches["main"])

    def get_messages(self) -> List[Dict]:
        """Get messages from the current branch."""
        return self.get_current().messages

    def add_message(self, message: Dict):
        """Add a message to the current branch."""
        self.get_current().messages.append(message)

    def fork(self, name: str = "") -> str:
        """
        Fork the current conversation into a new branch.

        Returns the new branch ID.
        """
        parent = self.get_current()
        branch_id = f"branch_{int(time.time())}_{len(self.branches)}"

        if not name:
            name = f"Branch {len(self.branches)}"

        new_branch = Branch(
            id=branch_id,
            parent_id=parent.id,
            name=name,
            messages=copy.deepcopy(parent.messages),
            forked_at_index=len(parent.messages),
        )

        self.branches[branch_id] = new_branch
        self.current_branch = branch_id

        logger.info(f"Forked '{parent.name}' -> '{name}' at message {len(parent.messages)}")
        return branch_id

    def switch(self, branch_id: str) -> bool:
        """Switch to a different branch."""
        if branch_id in self.branches:
            self.current_branch = branch_id
            return True
        return False

    def merge(self, source_branch_id: str, target_branch_id: str = "main") -> bool:
        """
        Merge a branch into another (default: main).

        Keeps the source branch's messages from the fork point onward
        and appends them to the target.
        """
        source = self.branches.get(source_branch_id)
        target = self.branches.get(target_branch_id)

        if not source or not target:
            return False

        # Get messages that are unique to the source branch
        fork_index = source.forked_at_index
        new_messages = source.messages[fork_index:]

        if new_messages:
            # Replace target messages from fork point with source messages
            target.messages = target.messages[:fork_index] + new_messages

        # Switch to target
        self.current_branch = target_branch_id

        logger.info(f"Merged '{source.name}' into '{target.name}' ({len(new_messages)} messages)")
        return True

    def compare(self) -> List[Dict]:
        """Compare all active branches."""
        comparisons = []
        for branch in self.branches.values():
            if not branch.active:
                continue
            last_assistant = ""
            for msg in reversed(branch.messages):
                if msg.get("role") == "assistant":
                    last_assistant = msg.get("content", "")[:200]
                    break

            comparisons.append({
                "id": branch.id,
                "name": branch.name,
                "messages": len(branch.messages),
                "forked_at": branch.forked_at_index,
                "last_response": last_assistant,
                "is_current": branch.id == self.current_branch,
            })

        return comparisons

    def undo(self, count: int = 1) -> int:
        """Undo the last N message pairs (user + assistant)."""
        messages = self.get_current().messages
        removed = 0
        for _ in range(count):
            # Remove last assistant message
            while messages and messages[-1].get("role") in ("assistant", "tool"):
                messages.pop()
                removed += 1
            # Remove last user message
            if messages and messages[-1].get("role") == "user":
                messages.pop()
                removed += 1
        return removed

    def list_branches(self) -> List[Dict]:
        """List all branches."""
        return [
            {
                "id": b.id,
                "name": b.name,
                "parent": b.parent_id,
                "messages": len(b.messages),
                "forked_at": b.forked_at_index,
                "active": b.active,
                "is_current": b.id == self.current_branch,
                "created_at": b.created_at,
            }
            for b in self.branches.values()
        ]

    def delete_branch(self, branch_id: str) -> bool:
        """Delete a branch (can't delete main)."""
        if branch_id == "main":
            return False
        if branch_id in self.branches:
            del self.branches[branch_id]
            if self.current_branch == branch_id:
                self.current_branch = "main"
            return True
        return False
