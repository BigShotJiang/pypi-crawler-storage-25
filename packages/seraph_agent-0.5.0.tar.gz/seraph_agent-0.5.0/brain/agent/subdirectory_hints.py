"""
Seraph Subdirectory Hints — auto-detect project type from files.

Scans the workspace to detect what kind of project it is and adjusts
the system prompt with relevant context. E.g., if it sees package.json,
it knows it's a Node.js project and adds npm/node context.
"""

import os
import logging
from typing import Dict, List
from pathlib import Path

logger = logging.getLogger("seraph.hints")

HINTS = {
    "package.json": {"type": "nodejs", "hint": "Node.js project. Use npm/yarn/pnpm. Check package.json for scripts."},
    "pyproject.toml": {"type": "python", "hint": "Python project with pyproject.toml. Use pip/uv/poetry."},
    "requirements.txt": {"type": "python", "hint": "Python project. Install deps with pip install -r requirements.txt."},
    "Cargo.toml": {"type": "rust", "hint": "Rust project. Use cargo build/test/run."},
    "go.mod": {"type": "go", "hint": "Go project. Use go build/test/run."},
    "Gemfile": {"type": "ruby", "hint": "Ruby project. Use bundle install, rails commands."},
    "pom.xml": {"type": "java", "hint": "Java Maven project. Use mvn compile/test/package."},
    "build.gradle": {"type": "java", "hint": "Java Gradle project. Use gradle build/test."},
    "Makefile": {"type": "make", "hint": "Has Makefile. Check make targets with make help or cat Makefile."},
    "docker-compose.yml": {"type": "docker", "hint": "Docker Compose project. Use docker compose up/down."},
    "Dockerfile": {"type": "docker", "hint": "Dockerized project. Build with docker build."},
    ".github/workflows": {"type": "ci", "hint": "GitHub Actions CI/CD configured."},
    "next.config.js": {"type": "nextjs", "hint": "Next.js project. Use npm run dev, pages in app/ or pages/."},
    "next.config.mjs": {"type": "nextjs", "hint": "Next.js project. Use npm run dev."},
    "tsconfig.json": {"type": "typescript", "hint": "TypeScript project. Compile with tsc."},
    ".env": {"type": "env", "hint": "Has .env file. Check for required environment variables."},
    "terraform": {"type": "terraform", "hint": "Terraform infrastructure. Use terraform plan/apply."},
    "k8s": {"type": "kubernetes", "hint": "Kubernetes configs present. Use kubectl apply."},
    "prisma/schema.prisma": {"type": "prisma", "hint": "Prisma ORM. Use npx prisma generate/migrate."},
    "supabase": {"type": "supabase", "hint": "Supabase project. Check supabase/ directory."},
}


def detect_project(workspace: str = None) -> List[Dict]:
    """Detect project type from workspace files."""
    ws = Path(workspace) if workspace else Path.cwd()
    detected = []

    for marker, info in HINTS.items():
        path = ws / marker
        if path.exists():
            detected.append(info)

    return detected


def format_hints(workspace: str = None) -> str:
    """Format detected hints for injection into system prompt."""
    hints = detect_project(workspace)
    if not hints:
        return ""

    types = list(set(h["type"] for h in hints))
    hint_lines = [h["hint"] for h in hints]

    return (
        f"## Project Context (auto-detected)\n"
        f"Project types: {', '.join(types)}\n" +
        "\n".join(f"- {h}" for h in hint_lines)
    )
