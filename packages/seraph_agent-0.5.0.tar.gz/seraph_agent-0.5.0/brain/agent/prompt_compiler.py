"""
Seraph Prompt Compiler — minify system prompts to reduce token waste.

Strips unnecessary whitespace, deduplicates lines, and enforces
a hard token budget so the LLM's context isn't eaten by overhead.
"""

import re
import logging
from typing import List, Dict, Optional

logger = logging.getLogger("seraph.prompt_compiler")

# Hard budget: system overhead gets at most this % of context
MAX_SYSTEM_PERCENT = 0.20  # 20% for system, 80% for conversation
CHARS_PER_TOKEN = 4  # rough estimate


def minify(text: str) -> str:
    """
    Compress a system prompt without losing meaning.

    - Collapse multiple blank lines into one
    - Strip trailing whitespace per line
    - Remove markdown decorators that waste tokens (---, ===, ***)
    - Deduplicate identical lines
    """
    if not text:
        return text

    lines = text.splitlines()
    out = []
    seen = set()
    prev_blank = False

    for line in lines:
        stripped = line.rstrip()

        # Skip pure decoration lines
        if re.match(r'^[\-=\*~]{3,}$', stripped):
            continue

        # Collapse multiple blanks
        if not stripped:
            if prev_blank:
                continue
            prev_blank = True
            out.append("")
            continue
        prev_blank = False

        # Deduplicate exact lines (keeps first occurrence)
        if stripped in seen:
            continue
        seen.add(stripped)

        out.append(stripped)

    return "\n".join(out).strip()


def enforce_budget(system_prompt: str, conversation_tokens: int, model_context: int = 128000) -> str:
    """
    Trim system prompt if it exceeds the budget.

    Budget: system gets max 20% of (model_context - conversation_tokens).
    If over budget, truncate from the middle (keep start + end).
    """
    available = model_context - conversation_tokens
    max_system_tokens = int(available * MAX_SYSTEM_PERCENT)
    max_system_chars = max_system_tokens * CHARS_PER_TOKEN

    if len(system_prompt) <= max_system_chars:
        return system_prompt

    # Over budget — keep first 60% and last 30%, cut the middle
    keep_start = int(max_system_chars * 0.6)
    keep_end = int(max_system_chars * 0.3)

    trimmed = (
        system_prompt[:keep_start]
        + "\n\n[...context trimmed to fit budget...]\n\n"
        + system_prompt[-keep_end:]
    )

    logger.info(
        f"System prompt trimmed: {len(system_prompt)} -> {len(trimmed)} chars "
        f"(budget: {max_system_chars} chars / {max_system_tokens} tokens)"
    )
    return trimmed


def compile_prompt(
    identity: str,
    active_memory: str = "",
    user_profile: str = "",
    conversation_tokens: int = 0,
    model_context: int = 128000,
) -> str:
    """
    Build and optimize the full system prompt.

    1. Minify each component
    2. Assemble with minimal separators
    3. Enforce token budget
    """
    parts = [minify(identity)]

    if active_memory:
        mem = minify(active_memory)
        if mem:
            parts.append(f"[Memory]\n{mem}")

    if user_profile:
        prof = minify(user_profile)
        if prof:
            parts.append(f"[User]\n{prof}")

    full = "\n\n".join(parts)

    # Enforce budget
    full = enforce_budget(full, conversation_tokens, model_context)

    return full


def estimate_conversation_tokens(messages: List[Dict]) -> int:
    """Quick token estimate for a message list."""
    total = 0
    for m in messages:
        content = m.get("content", "")
        if isinstance(content, str):
            total += len(content) // CHARS_PER_TOKEN
        elif isinstance(content, list):
            for part in content:
                if isinstance(part, dict):
                    total += len(str(part)) // CHARS_PER_TOKEN
        # Tool calls add overhead
        if m.get("tool_calls"):
            total += sum(len(str(tc)) // CHARS_PER_TOKEN for tc in m["tool_calls"])
    return total
