"""
Seraph Tailscale — remote access via Tailscale Funnel/Serve.

Expose the brain API over Tailscale for remote access.
Requires tailscale CLI installed and authenticated.
"""

import subprocess
import logging
import os

logger = logging.getLogger("seraph.tailscale")


def tailscale_status() -> dict:
    """Get Tailscale connection status."""
    try:
        result = subprocess.run(["tailscale", "status", "--json"], capture_output=True, text=True, timeout=10)
        if result.returncode == 0:
            import json
            data = json.loads(result.stdout)
            return {
                "connected": True,
                "hostname": data.get("Self", {}).get("HostName", ""),
                "ip": data.get("Self", {}).get("TailscaleIPs", [""])[0],
                "online": data.get("Self", {}).get("Online", False),
            }
        return {"connected": False, "error": result.stderr[:200]}
    except FileNotFoundError:
        return {"connected": False, "error": "Tailscale CLI not installed"}
    except Exception as e:
        return {"connected": False, "error": str(e)}


def tailscale_serve(port: int = 18801, protocol: str = "https") -> dict:
    """Expose a local port via Tailscale Serve."""
    try:
        result = subprocess.run(
            ["tailscale", "serve", f"{protocol}://localhost:{port}"],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode == 0:
            return {"status": "serving", "port": port, "output": result.stdout[:200]}
        return {"error": result.stderr[:200]}
    except Exception as e:
        return {"error": str(e)}


def tailscale_funnel(port: int = 18801) -> dict:
    """Expose a local port to the public internet via Tailscale Funnel."""
    try:
        result = subprocess.run(
            ["tailscale", "funnel", str(port)],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode == 0:
            return {"status": "funneled", "port": port, "output": result.stdout[:200]}
        return {"error": result.stderr[:200]}
    except Exception as e:
        return {"error": str(e)}
