"""
Seraph Link Understanding — auto-fetch URLs from user messages.

When a user sends a message containing URLs, automatically fetch the page
content and inject it into the context. SSRF-safe.

Features:
- Detect bare URLs in messages (skip markdown links)
- SSRF protection (block internal IPs, metadata endpoints)
- Fetch with timeout and size limit
- Extract readable text (strip HTML)
- Inject as context without user seeing the fetch
"""

import re
import logging
import ipaddress
import requests
from typing import List, Optional, Tuple
from urllib.parse import urlparse

logger = logging.getLogger("seraph.link_understanding")

MAX_LINKS = 3
MAX_FETCH_SIZE = 100_000  # 100KB max per page
FETCH_TIMEOUT = 10

# Markdown link pattern: [text](url)
MARKDOWN_LINK_RE = re.compile(r'\[[^\]]*\]\((https?://\S+?)\)', re.IGNORECASE)
# Bare URL pattern
BARE_URL_RE = re.compile(r'https?://\S+', re.IGNORECASE)

# Blocked hosts / IPs for SSRF protection
BLOCKED_RANGES = [
    ipaddress.ip_network("127.0.0.0/8"),
    ipaddress.ip_network("10.0.0.0/8"),
    ipaddress.ip_network("172.16.0.0/12"),
    ipaddress.ip_network("192.168.0.0/16"),
    ipaddress.ip_network("169.254.0.0/16"),  # Link-local
    ipaddress.ip_network("::1/128"),          # IPv6 loopback
    ipaddress.ip_network("fc00::/7"),         # IPv6 private
    ipaddress.ip_network("fe80::/10"),        # IPv6 link-local
]

BLOCKED_HOSTNAMES = {
    "localhost", "metadata.google.internal", "169.254.169.254",
    "metadata", "metadata.internal",
}


def is_safe_url(url: str) -> bool:
    """Check if a URL is safe to fetch (not internal/SSRF)."""
    try:
        parsed = urlparse(url)
        hostname = parsed.hostname or ""

        if not hostname:
            return False

        # Block known dangerous hostnames
        if hostname.lower() in BLOCKED_HOSTNAMES:
            return False

        # Block by scheme
        if parsed.scheme not in ("http", "https"):
            return False

        # Block internal IPs
        try:
            ip = ipaddress.ip_address(hostname)
            for network in BLOCKED_RANGES:
                if ip in network:
                    return False
        except ValueError:
            pass  # Not an IP, it's a hostname — OK

        # Block file:// and other schemes that might sneak through
        if parsed.port and parsed.port in (6379, 5432, 3306, 27017, 11211):
            return False  # Common database ports

        return True
    except Exception:
        return False


def extract_urls(message: str) -> List[str]:
    """Extract URLs from a message, skipping markdown links."""
    if not message:
        return []

    # Remove markdown links first
    stripped = MARKDOWN_LINK_RE.sub(" ", message)

    seen = set()
    urls = []
    for match in BARE_URL_RE.finditer(stripped):
        url = match.group(0).rstrip(".,;:!?)")  # Strip trailing punctuation
        if url in seen:
            continue
        if not is_safe_url(url):
            logger.warning(f"Blocked unsafe URL: {url}")
            continue
        seen.add(url)
        urls.append(url)
        if len(urls) >= MAX_LINKS:
            break

    return urls


def fetch_url_content(url: str) -> Optional[str]:
    """Fetch a URL and extract readable text content."""
    try:
        resp = requests.get(url, timeout=FETCH_TIMEOUT, headers={
            "User-Agent": "Seraph/0.2 (AI Agent; +https://seraph.so)",
            "Accept": "text/html,text/plain,application/json",
        }, allow_redirects=True, stream=True)

        if resp.status_code != 200:
            return None

        # Check content type
        ct = resp.headers.get("content-type", "").lower()
        if "text/html" in ct:
            # Read up to MAX_FETCH_SIZE
            content = resp.content[:MAX_FETCH_SIZE].decode("utf-8", errors="replace")
            return _extract_text_from_html(content)
        elif "text/plain" in ct or "application/json" in ct:
            return resp.text[:MAX_FETCH_SIZE]
        else:
            return None  # Binary content, skip

    except Exception as e:
        logger.debug(f"Fetch failed for {url}: {e}")
        return None


def _extract_text_from_html(html: str) -> str:
    """Extract readable text from HTML, stripping tags."""
    import re
    # Remove script and style blocks
    text = re.sub(r'<script[^>]*>.*?</script>', '', html, flags=re.DOTALL | re.IGNORECASE)
    text = re.sub(r'<style[^>]*>.*?</style>', '', text, flags=re.DOTALL | re.IGNORECASE)
    # Remove HTML tags
    text = re.sub(r'<[^>]+>', ' ', text)
    # Clean whitespace
    text = re.sub(r'\s+', ' ', text).strip()
    # Decode HTML entities
    try:
        import html
        text = html.unescape(text)
    except Exception:
        pass
    return text[:10000]  # Cap at 10K chars


def process_message_links(message: str) -> Tuple[str, List[str]]:
    """
    Process a message for link understanding.

    Returns (enriched_message, fetched_urls).
    If URLs were found and fetched, appends the content as context.
    """
    urls = extract_urls(message)
    if not urls:
        return message, []

    fetched = []
    context_parts = []

    for url in urls:
        content = fetch_url_content(url)
        if content and len(content) > 50:  # Skip trivial content
            fetched.append(url)
            # Truncate to 3000 chars per URL
            truncated = content[:3000]
            context_parts.append(f"[Content from {url}]:\n{truncated}")

    if context_parts:
        enriched = message + "\n\n---\n" + "\n\n".join(context_parts)
        return enriched, fetched

    return message, []
