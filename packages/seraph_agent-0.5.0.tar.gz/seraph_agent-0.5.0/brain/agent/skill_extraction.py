"""
Seraph Skill Extraction — extract executable procedures from conversations.

Not vague "learnings" — concrete, testable, replayable procedures:
"When user says X, run tools A→B→C with these parameters, verify with D."

Triggers after complex tool-heavy conversations (5+ tool calls).
"""

import json
import time
import logging
import os
from typing import Dict, List, Optional
from pathlib import Path
from dataclasses import dataclass, field

logger = logging.getLogger("seraph.skill_extraction")

SKILLS_DIR = Path.home() / ".seraph" / "skills"


@dataclass
class ExtractedStep:
    """A single step in a skill procedure."""
    tool: str
    args_template: Dict  # Args with {{variables}} for parameterization
    expected_output: str  # What a successful result looks like
    description: str


@dataclass
class ExtractedSkill:
    """A skill extracted from a conversation."""
    name: str
    description: str
    trigger: str  # "When user says..."
    steps: List[ExtractedStep]
    variables: Dict[str, str]  # Variable name -> description
    verification: str  # How to verify success
    confidence: float  # 0-1
    source_session: str
    extracted_at: float = field(default_factory=time.time)


def extract_tool_chain(messages: List[Dict]) -> List[Dict]:
    """Extract the sequence of tool calls from a conversation."""
    chain = []
    for msg in messages:
        if msg.get("role") == "assistant" and msg.get("tool_calls"):
            for tc in msg["tool_calls"]:
                fn = tc.get("function", tc)
                name = fn.get("name", tc.get("name", ""))
                args_raw = fn.get("arguments", tc.get("arguments", "{}"))
                if isinstance(args_raw, str):
                    try:
                        args = json.loads(args_raw)
                    except json.JSONDecodeError:
                        args = {}
                else:
                    args = args_raw
                chain.append({"tool": name, "args": args, "id": tc.get("id", "")})

        elif msg.get("role") == "tool":
            # Attach result to the last tool call
            content = msg.get("content", "")
            if chain:
                chain[-1]["result"] = content[:500]

    return chain


def detect_patterns(chain: List[Dict]) -> List[Dict]:
    """Detect repeating patterns in tool call sequences."""
    if len(chain) < 3:
        return []

    patterns = []
    # Look for 2-3 tool sequences that repeat
    for window_size in (2, 3):
        for i in range(len(chain) - window_size):
            pattern = [c["tool"] for c in chain[i:i+window_size]]
            # Check if this pattern appears again
            count = 0
            for j in range(i + window_size, len(chain) - window_size + 1):
                candidate = [c["tool"] for c in chain[j:j+window_size]]
                if candidate == pattern:
                    count += 1
            if count > 0:
                patterns.append({
                    "tools": pattern,
                    "occurrences": count + 1,
                    "window": window_size,
                    "start_index": i,
                })

    return patterns


def parameterize_args(args: Dict, all_args: List[Dict]) -> Tuple:
    """
    Convert concrete args into parameterized templates.

    If multiple tool calls use the same tool with different args,
    the varying parts become {{variables}}.
    """
    template = {}
    variables = {}

    for key, value in args.items():
        if isinstance(value, str):
            # Check if this value varies across similar tool calls
            values_for_key = [a.get(key, "") for a in all_args if key in a]
            unique_values = set(str(v) for v in values_for_key)

            if len(unique_values) > 1:
                # This varies — make it a variable
                var_name = key
                template[key] = f"{{{{{var_name}}}}}"
                variables[var_name] = f"The {key} parameter (e.g., {value})"
            else:
                template[key] = value
        else:
            template[key] = value

    return template, variables


from typing import Tuple


def extract_skill_from_conversation(
    messages: List[Dict],
    session_id: str = "",
    llm_call=None,
) -> Optional[ExtractedSkill]:
    """
    Attempt to extract a reusable skill from a conversation.

    Only triggers if the conversation had 5+ tool calls.
    """
    chain = extract_tool_chain(messages)
    if len(chain) < 5:
        return None

    # Get the user's original request
    user_messages = [m["content"] for m in messages if m.get("role") == "user"]
    original_request = user_messages[0] if user_messages else ""

    # Get the final outcome
    assistant_messages = [m["content"] for m in messages if m.get("role") == "assistant" and m.get("content")]
    final_response = assistant_messages[-1] if assistant_messages else ""

    # Build steps
    steps = []
    for tc in chain:
        step = ExtractedStep(
            tool=tc["tool"],
            args_template=tc["args"],
            expected_output=tc.get("result", "")[:200],
            description=f"Call {tc['tool']}",
        )
        steps.append(step)

    # Detect patterns
    patterns = detect_patterns(chain)

    # Build the skill
    tool_names = list(dict.fromkeys(tc["tool"] for tc in chain))  # Unique, ordered
    name = "_".join(tool_names[:3]) + "_skill"

    skill = ExtractedSkill(
        name=name,
        description=f"Procedure extracted from conversation: {original_request[:100]}",
        trigger=original_request[:200],
        steps=steps,
        variables={},
        verification=f"Expected outcome: {final_response[:200]}",
        confidence=min(0.3 + len(chain) * 0.05 + len(patterns) * 0.1, 0.9),
        source_session=session_id,
    )

    return skill


def save_skill(skill: ExtractedSkill) -> str:
    """Save an extracted skill to disk as SKILL.md."""
    skill_dir = SKILLS_DIR / skill.name
    skill_dir.mkdir(parents=True, exist_ok=True)

    # Build SKILL.md
    lines = [
        f"---",
        f"name: {skill.name}",
        f"description: {skill.description}",
        f"confidence: {skill.confidence:.1f}",
        f"extracted: {time.strftime('%Y-%m-%d %H:%M')}",
        f"source: {skill.source_session}",
        f"---",
        f"",
        f"# {skill.name}",
        f"",
        f"## When to Use",
        f"{skill.trigger}",
        f"",
        f"## Steps",
    ]

    for i, step in enumerate(skill.steps, 1):
        args_str = json.dumps(step.args_template)
        lines.append(f"{i}. **{step.tool}**({args_str})")
        if step.expected_output:
            lines.append(f"   Expected: {step.expected_output[:100]}")

    lines.extend([
        f"",
        f"## Verification",
        f"{skill.verification}",
        f"",
        f"## Variables",
    ])
    for var, desc in skill.variables.items():
        lines.append(f"- `{{{{{var}}}}}`: {desc}")

    content = "\n".join(lines)
    skill_path = skill_dir / "SKILL.md"
    skill_path.write_text(content, encoding="utf-8")

    # Also save raw JSON for programmatic replay (atomic)
    json_path = skill_dir / "skill.json"
    tmp_path = str(json_path) + ".tmp"
    with open(tmp_path, "w") as f:
        json.dump({
            "name": skill.name,
            "trigger": skill.trigger,
            "steps": [{"tool": s.tool, "args": s.args_template} for s in skill.steps],
            "variables": skill.variables,
            "confidence": skill.confidence,
        }, f, indent=2)
    os.replace(tmp_path, str(json_path))

    logger.info(f"Saved skill: {skill.name} ({len(skill.steps)} steps, confidence={skill.confidence:.1f})")
    return str(skill_path)
