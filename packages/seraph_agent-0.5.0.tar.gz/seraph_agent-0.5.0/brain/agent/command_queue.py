"""
Seraph Command Queue — serialize LLM calls per session.

Prevents race conditions when multiple messages arrive for the same session.
Each session gets its own lane. Messages are queued and processed in order.

Also supports priority lanes:
- "user" lane: interactive messages (high priority)
- "cron" lane: scheduled jobs (low priority)
- "subagent" lane: subagent runs (medium priority)
"""

import time
import logging
import threading
from typing import Dict, Callable, Optional, Any
from collections import deque
from dataclasses import dataclass

logger = logging.getLogger("seraph.command_queue")


@dataclass
class QueueEntry:
    task: Callable
    session_key: str
    priority: int  # Higher = first
    enqueued_at: float
    resolve: Optional[Callable] = None
    reject: Optional[Callable] = None


class CommandLane:
    """A single-threaded execution lane."""

    def __init__(self, name: str):
        self.name = name
        self.queue: deque = deque()
        self.running = False
        self._lock = threading.Lock()
        self._worker: Optional[threading.Thread] = None

    def enqueue(self, task: Callable, priority: int = 0) -> None:
        """Add a task to the lane."""
        with self._lock:
            entry = QueueEntry(
                task=task, session_key=self.name,
                priority=priority, enqueued_at=time.time(),
            )
            self.queue.append(entry)

            if not self.running:
                self.running = True
                self._worker = threading.Thread(target=self._process, daemon=True)
                self._worker.start()

    def _process(self):
        """Process queue entries one at a time."""
        while True:
            with self._lock:
                if not self.queue:
                    self.running = False
                    return
                entry = self.queue.popleft()

            try:
                entry.task()
            except Exception as e:
                logger.error(f"[{self.name}] Task error: {e}")

    @property
    def size(self) -> int:
        return len(self.queue)


class CommandQueue:
    """Multi-lane command queue. One lane per session."""

    def __init__(self):
        self.lanes: Dict[str, CommandLane] = {}
        self._lock = threading.Lock()

    def enqueue(self, session_key: str, task: Callable, priority: int = 0):
        """Queue a task for a session. Creates lane if needed."""
        with self._lock:
            if session_key not in self.lanes:
                self.lanes[session_key] = CommandLane(session_key)

        self.lanes[session_key].enqueue(task, priority)

    def get_queue_size(self, session_key: str = None) -> int:
        """Get queue size for a session or total across all lanes."""
        if session_key:
            lane = self.lanes.get(session_key)
            return lane.size if lane else 0
        return sum(lane.size for lane in self.lanes.values())

    def clear_lane(self, session_key: str):
        """Clear all pending tasks for a session."""
        with self._lock:
            if session_key in self.lanes:
                self.lanes[session_key].queue.clear()

    def list_active(self) -> list:
        """List all active lanes."""
        return [
            {"session": name, "queued": lane.size, "running": lane.running}
            for name, lane in self.lanes.items()
            if lane.running or lane.size > 0
        ]


_queue = None

def get_command_queue() -> CommandQueue:
    global _queue
    if _queue is None:
        _queue = CommandQueue()
    return _queue
