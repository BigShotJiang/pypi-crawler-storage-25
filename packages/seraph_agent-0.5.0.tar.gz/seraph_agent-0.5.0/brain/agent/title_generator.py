"""
Seraph Title Generator — auto-title conversations.

Generates a short title from the first few messages.
Used for session management and history display.
"""

import re
import logging
from typing import List, Dict, Optional

logger = logging.getLogger("seraph.title")


def generate_title(messages: List[Dict], llm=None) -> str:
    """
    Generate a conversation title from messages.

    Strategy:
    1. If LLM available, use it for a smart title
    2. Otherwise, extract keywords from first user message
    """
    if not messages:
        return "New conversation"

    # Find first user message
    first_user = ""
    for m in messages[:5]:
        if m.get("role") == "user":
            content = m.get("content", "")
            if isinstance(content, str) and len(content) > 5:
                first_user = content
                break

    if not first_user:
        return "New conversation"

    # Try LLM
    if llm:
        try:
            response = llm.chat(
                messages=[{"role": "user", "content": f"Generate a 3-5 word title for this conversation. Just the title, nothing else.\n\nUser's first message: {first_user[:200]}"}],
                system="Generate very short conversation titles. 3-5 words max. No quotes.",
            )
            title = response.text.strip().strip('"').strip("'")
            if 3 < len(title) < 60:
                return title
        except Exception:
            pass

    # Fallback: extract from first message
    clean = re.sub(r'[^\w\s]', '', first_user[:100]).strip()
    words = clean.split()[:6]
    title = " ".join(words)
    if len(title) > 50:
        title = title[:47] + "..."
    return title or "New conversation"
