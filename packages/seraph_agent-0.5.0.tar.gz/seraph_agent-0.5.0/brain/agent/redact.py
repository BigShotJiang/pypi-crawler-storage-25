"""
Seraph Redact — strip sensitive data from logs and transcripts.

Redacts: API keys, tokens, passwords, emails, phone numbers, IPs,
credit cards, SSNs, and custom patterns.
"""

import re
import logging
from typing import List

logger = logging.getLogger("seraph.redact")

PATTERNS = [
    # API keys and tokens
    (r"sk-[a-zA-Z0-9]{20,}", "[REDACTED_API_KEY]"),
    (r"sk-ant-[a-zA-Z0-9\-]{20,}", "[REDACTED_ANTHROPIC_KEY]"),
    (r"xoxb-[a-zA-Z0-9\-]{20,}", "[REDACTED_SLACK_TOKEN]"),
    (r"xoxp-[a-zA-Z0-9\-]{20,}", "[REDACTED_SLACK_TOKEN]"),
    (r"ghp_[a-zA-Z0-9]{36}", "[REDACTED_GITHUB_TOKEN]"),
    (r"gho_[a-zA-Z0-9]{36}", "[REDACTED_GITHUB_TOKEN]"),
    (r"glpat-[a-zA-Z0-9\-]{20,}", "[REDACTED_GITLAB_TOKEN]"),
    (r"AKIA[A-Z0-9]{16}", "[REDACTED_AWS_KEY]"),
    (r"Bearer\s+[a-zA-Z0-9\.\-_]{20,}", "Bearer [REDACTED_TOKEN]"),
    (r"token[\"']?\s*[:=]\s*[\"'][a-zA-Z0-9\.\-_]{20,}[\"']", "token=[REDACTED]"),

    # Passwords in URLs and strings
    (r"password[\"']?\s*[:=]\s*[\"'][^\"']{3,}[\"']", "password=[REDACTED]"),
    (r"passwd[\"']?\s*[:=]\s*[\"'][^\"']{3,}[\"']", "passwd=[REDACTED]"),
    (r"secret[\"']?\s*[:=]\s*[\"'][^\"']{3,}[\"']", "secret=[REDACTED]"),
    (r"://[^:]+:[^@]+@", "://[REDACTED]@"),

    # PII
    (r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b", "[REDACTED_EMAIL]"),
    (r"\b\d{3}[-.]?\d{3}[-.]?\d{4}\b", "[REDACTED_PHONE]"),
    (r"\b\d{3}[-]?\d{2}[-]?\d{4}\b", "[REDACTED_SSN]"),
    (r"\b(?:\d{4}[-\s]?){3}\d{4}\b", "[REDACTED_CC]"),

    # Private IPs (in logs)
    (r"\b(?:192\.168|10\.(?:\d{1,3}))\.\d{1,3}\.\d{1,3}\b", "[REDACTED_IP]"),
]

_COMPILED = [(re.compile(p, re.IGNORECASE), r) for p, r in PATTERNS]


def redact(text: str) -> str:
    """Redact sensitive data from text."""
    if not text:
        return text
    result = text
    for pattern, replacement in _COMPILED:
        result = pattern.sub(replacement, result)
    return result


def redact_dict(data: dict) -> dict:
    """Redact sensitive data from a dictionary (recursive)."""
    if not isinstance(data, dict):
        return data

    result = {}
    sensitive_keys = {"password", "secret", "token", "api_key", "apikey",
                      "auth", "credential", "private_key", "access_token"}

    for key, value in data.items():
        if any(s in key.lower() for s in sensitive_keys):
            result[key] = "[REDACTED]"
        elif isinstance(value, str):
            result[key] = redact(value)
        elif isinstance(value, dict):
            result[key] = redact_dict(value)
        elif isinstance(value, list):
            result[key] = [redact(str(v)) if isinstance(v, str) else v for v in value]
        else:
            result[key] = value
    return result
