"""
Seraph i18n — internationalization for system messages.

System messages (errors, status, commands) in the user's preferred language.
Agent responses are already multi-language (LLM handles that).
This is for the bot's OWN UI messages.

Supported: en, es, fr, de, pt, zh, ja, ko, ar, ru
"""

import logging
from typing import Dict, Optional

logger = logging.getLogger("seraph.i18n")

# Default language
DEFAULT_LANG = "en"

TRANSLATIONS: Dict[str, Dict[str, str]] = {
    "not_authorized": {
        "en": "You're not authorized to use this bot.",
        "es": "No tienes autorización para usar este bot.",
        "fr": "Vous n'êtes pas autorisé à utiliser ce bot.",
        "de": "Sie sind nicht berechtigt, diesen Bot zu verwenden.",
        "pt": "Você não está autorizado a usar este bot.",
        "zh": "您无权使用此机器人。",
        "ja": "このボットを使用する権限がありません。",
        "ko": "이 봇을 사용할 권한이 없습니다.",
        "ar": "ليس لديك صلاحية لاستخدام هذا البوت.",
        "ru": "У вас нет прав на использование этого бота.",
    },
    "rate_limited": {
        "en": "Slow down. Too many messages.",
        "es": "Más despacio. Demasiados mensajes.",
        "fr": "Doucement. Trop de messages.",
        "de": "Langsamer. Zu viele Nachrichten.",
        "pt": "Devagar. Muitas mensagens.",
        "zh": "请慢一些。消息太多了。",
        "ja": "ゆっくりしてください。メッセージが多すぎます。",
        "ko": "천천히 하세요. 메시지가 너무 많습니다.",
        "ru": "Помедленнее. Слишком много сообщений.",
    },
    "llm_not_connected": {
        "en": "LLM not connected. Check API keys.",
        "es": "LLM no conectado. Verifica las claves API.",
        "fr": "LLM non connecté. Vérifiez les clés API.",
        "de": "LLM nicht verbunden. API-Schlüssel prüfen.",
        "pt": "LLM não conectado. Verifique as chaves API.",
        "zh": "LLM未连接。请检查API密钥。",
        "ja": "LLMが接続されていません。APIキーを確認してください。",
        "ko": "LLM이 연결되지 않았습니다. API 키를 확인하세요.",
        "ru": "LLM не подключен. Проверьте ключи API.",
    },
    "conversation_cleared": {
        "en": "Conversation cleared. Fresh start.",
        "es": "Conversación borrada. Nuevo comienzo.",
        "fr": "Conversation effacée. Nouveau départ.",
        "de": "Gespräch gelöscht. Neuanfang.",
        "pt": "Conversa limpa. Novo começo.",
        "zh": "对话已清除。重新开始。",
        "ja": "会話をクリアしました。新しく始めましょう。",
        "ko": "대화가 지워졌습니다. 새로 시작합니다.",
        "ru": "Диалог очищен. Начинаем сначала.",
    },
    "error_occurred": {
        "en": "Something went wrong. Try again.",
        "es": "Algo salió mal. Inténtalo de nuevo.",
        "fr": "Quelque chose s'est mal passé. Réessayez.",
        "de": "Etwas ist schiefgegangen. Versuchen Sie es erneut.",
        "pt": "Algo deu errado. Tente novamente.",
        "zh": "出了点问题。请重试。",
        "ja": "問題が発生しました。もう一度お試しください。",
        "ko": "문제가 발생했습니다. 다시 시도하세요.",
        "ru": "Что-то пошло не так. Попробуйте снова.",
    },
    "status_running": {
        "en": "Running",
        "es": "En ejecución",
        "fr": "En cours",
        "de": "Läuft",
        "pt": "Em execução",
        "zh": "运行中",
        "ja": "実行中",
        "ko": "실행 중",
        "ru": "Работает",
    },
}

# Per-user language preferences
_user_langs: Dict[str, str] = {}


def set_user_lang(user_id: str, lang: str):
    """Set a user's preferred language."""
    if lang in ("en", "es", "fr", "de", "pt", "zh", "ja", "ko", "ar", "ru"):
        _user_langs[user_id] = lang


def get_user_lang(user_id: str) -> str:
    """Get a user's preferred language."""
    return _user_langs.get(user_id, DEFAULT_LANG)


def t(key: str, user_id: str = "", lang: str = "") -> str:
    """Translate a system message key."""
    target_lang = lang or get_user_lang(user_id) or DEFAULT_LANG
    translations = TRANSLATIONS.get(key, {})
    return translations.get(target_lang, translations.get("en", key))


def available_languages() -> list:
    return ["en", "es", "fr", "de", "pt", "zh", "ja", "ko", "ar", "ru"]
