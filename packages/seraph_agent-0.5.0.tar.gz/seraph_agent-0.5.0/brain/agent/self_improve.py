"""
Seraph Self-Improvement — autonomous evolution loop.

Runs periodically (via cron) to make the bot better over time:
1. Audit own code for bugs and issues
2. Review recent conversations for patterns
3. Generate new skills from successful complex tasks
4. Update SOUL.md with learned behaviors
5. Log improvements for transparency

This is what makes Seraph different — it gets better without human intervention.
"""

import os
import json
import time
import logging
from pathlib import Path
from datetime import datetime, timezone
from typing import Dict, List, Optional

logger = logging.getLogger("seraph.self_improve")

SERAPH_DIR = Path.home() / ".seraph"
IMPROVE_LOG = SERAPH_DIR / "improvements.json"
SOUL_PATH = SERAPH_DIR / "SOUL.md"

# Keys that self-improve must NEVER touch
PROTECTED_FILES = {
    ".env",
    "rules/rules.json",
    "auth.json",
}


def _load_log() -> list:
    """Load improvement history."""
    if IMPROVE_LOG.exists():
        try:
            return json.loads(IMPROVE_LOG.read_text(encoding="utf-8"))
        except Exception:
            return []
    return []


def _save_log(entries: list):
    """Save improvement history atomically."""
    IMPROVE_LOG.parent.mkdir(parents=True, exist_ok=True)
    tmp = IMPROVE_LOG.with_suffix(".tmp")
    tmp.write_text(json.dumps(entries[-100:], indent=2), encoding="utf-8")  # Keep last 100
    tmp.replace(IMPROVE_LOG)


def _log_improvement(category: str, description: str, details: str = ""):
    """Record an improvement action."""
    entries = _load_log()
    entries.append({
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "category": category,
        "description": description,
        "details": details[:500],
    })
    _save_log(entries)
    logger.info(f"Self-improve [{category}]: {description}")


def review_conversations(memory, llm, limit: int = 5) -> List[Dict]:
    """
    Review recent conversations for patterns and insights.

    Looks for:
    - Repeated questions (should become skills)
    - Errors the bot made (should be learned from)
    - User corrections (should update behavior)
    """
    improvements = []

    try:
        # Get recent messages directly from DB
        try:
            rows = memory.conn.execute(
                "SELECT role, content, session_id, created_at FROM conversations ORDER BY created_at DESC LIMIT ?",
                (limit * 10,)
            ).fetchall()
            recent = [{"role": r["role"], "content": r["content"], "session_id": r["session_id"]} for r in rows]
        except Exception:
            recent = []
        if not recent or len(recent) < 4:
            return improvements

        # Group by session
        sessions = {}
        for msg in recent:
            sid = msg.get("session_id", "unknown")
            if sid not in sessions:
                sessions[sid] = []
            sessions[sid].append(msg)

        # Analyze each session for patterns
        for sid, msgs in list(sessions.items())[:limit]:
            # Look for user corrections ("no", "wrong", "not that", "I said")
            corrections = []
            for m in msgs:
                content = m.get("content", "").lower() if isinstance(m.get("content"), str) else ""
                if m.get("role") == "user" and any(w in content for w in ["no ", "wrong", "not that", "i said", "i meant", "that's incorrect"]):
                    corrections.append(m.get("content", ""))

            if corrections:
                improvements.append({
                    "type": "correction",
                    "session": sid,
                    "corrections": corrections[:3],
                })

        _log_improvement("review", f"Reviewed {len(sessions)} sessions, found {len(improvements)} patterns")

    except Exception as e:
        logger.error(f"Conversation review failed: {e}")

    return improvements


def generate_skills_from_recent(memory, llm, limit: int = 3) -> int:
    """Auto-generate skills from recent complex conversations."""
    from skills.generator import generate_skill_from_conversation

    generated = 0
    try:
        try:
            rows = memory.conn.execute(
                "SELECT role, content, session_id FROM conversations ORDER BY created_at DESC LIMIT 50"
            ).fetchall()
            recent = [{"role": r["role"], "content": r["content"], "session_id": r["session_id"]} for r in rows]
        except Exception:
            recent = []
        if not recent:
            return 0

        # Group into sessions
        sessions = {}
        for msg in recent:
            sid = msg.get("session_id", "unknown")
            if sid not in sessions:
                sessions[sid] = []
            sessions[sid].append({"role": msg.get("role", "user"), "content": msg.get("content", "")})

        # Try to generate skills from complex sessions (10+ messages)
        for sid, msgs in list(sessions.items())[:limit]:
            if len(msgs) >= 10:
                skill = generate_skill_from_conversation(msgs, llm)
                if skill:
                    generated += 1
                    _log_improvement("skill", f"Generated skill: {skill.get('name', '?')}")

    except Exception as e:
        logger.error(f"Skill generation failed: {e}")

    return generated


def audit_own_code(llm) -> Dict:
    """
    Self-audit: have the LLM review Seraph's own source code for issues.

    Focuses on the most critical files only (not a full audit).
    """
    brain_dir = Path(__file__).resolve().parent.parent
    critical_files = [
        brain_dir / "channels" / "telegram.py",
        brain_dir / "agent" / "llm.py",
        brain_dir / "memory" / "store.py",
        brain_dir / "tools" / "registry.py",
    ]

    issues = []
    for filepath in critical_files:
        if not filepath.exists():
            continue

        code = filepath.read_text(encoding="utf-8")
        if len(code) > 15000:
            # Only audit first and last 5000 chars for token efficiency
            code = code[:5000] + "\n...(middle truncated)...\n" + code[-5000:]

        try:
            response = llm.chat(
                messages=[{"role": "user", "content": f"Review this Python code for CRITICAL bugs only (crashes, data loss, security). Be very concise. If no critical issues, say 'CLEAN'.\n\nFile: {filepath.name}\n```python\n{code}\n```"}],
                system="You are a code reviewer. Only report CRITICAL issues that cause crashes or data loss. One line per issue. If the code is fine, say CLEAN.",
            )

            text = response.text.strip()
            if "CLEAN" not in text.upper():
                issues.append({
                    "file": filepath.name,
                    "issues": text[:500],
                })

        except Exception as e:
            logger.error(f"Self-audit failed for {filepath.name}: {e}")

    result = {
        "files_audited": len(critical_files),
        "issues_found": len(issues),
        "issues": issues,
    }

    _log_improvement("audit", f"Self-audited {len(critical_files)} files, {len(issues)} issues found")
    return result


def learn_from_corrections(improvements: List[Dict], memory) -> int:
    """
    Apply lessons from user corrections to active memory.

    When users correct the bot, store the correction so it doesn't
    repeat the same mistake.
    """
    learned = 0
    for imp in improvements:
        if imp.get("type") != "correction":
            continue

        for correction in imp.get("corrections", []):
            if len(correction) > 20:
                # Store as active memory so it's in every future prompt
                key = f"learned_{int(time.time())}_{learned}"
                memory.set_active(key, f"User correction: {correction[:200]}")
                learned += 1
                _log_improvement("learn", f"Learned from correction: {correction[:100]}")

    return learned


def run_improvement_cycle(memory, llm) -> Dict:
    """
    Run one full self-improvement cycle.

    Called by cron scheduler or manually via /improve command.
    """
    logger.info("Starting self-improvement cycle...")
    results = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "steps": [],
    }

    # Step 1: Review recent conversations
    improvements = review_conversations(memory, llm)
    results["steps"].append({
        "name": "review_conversations",
        "patterns_found": len(improvements),
    })

    # Step 2: Learn from corrections
    learned = learn_from_corrections(improvements, memory)
    results["steps"].append({
        "name": "learn_from_corrections",
        "lessons_learned": learned,
    })

    # Step 3: Generate skills from complex conversations
    skills_generated = generate_skills_from_recent(memory, llm)
    results["steps"].append({
        "name": "generate_skills",
        "skills_created": skills_generated,
    })

    # Step 4: Self-audit critical code
    audit = audit_own_code(llm)
    results["steps"].append({
        "name": "self_audit",
        "files_audited": audit["files_audited"],
        "issues_found": audit["issues_found"],
    })

    # Log the full cycle
    _log_improvement("cycle", f"Improvement cycle complete: {len(improvements)} patterns, {learned} lessons, {skills_generated} skills, {audit['issues_found']} code issues")

    logger.info(f"Self-improvement cycle complete: {json.dumps(results, indent=2)}")
    return results


def get_improvement_history(limit: int = 20) -> list:
    """Get recent improvement actions."""
    entries = _load_log()
    return entries[-limit:]
