"""
Seraph DM Pairing — verification codes for unknown users.

When an unknown user messages the bot, they get a pairing code.
The owner approves via /approve command. Only then can they interact.
"""

import json
import time
import random
import string
import logging
from pathlib import Path
from typing import Dict, Optional, Tuple

logger = logging.getLogger("seraph.pairing")

PAIRING_FILE = Path.home() / ".seraph" / "pairing.json"


def _load() -> dict:
    if PAIRING_FILE.exists():
        try:
            return json.loads(PAIRING_FILE.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {"approved": [], "pending": {}, "denied": []}


def _save(data: dict):
    PAIRING_FILE.parent.mkdir(parents=True, exist_ok=True)
    tmp = PAIRING_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
    tmp.replace(PAIRING_FILE)


def generate_code() -> str:
    """Generate a 6-character pairing code."""
    return "".join(random.choices(string.ascii_uppercase + string.digits, k=6))


def is_approved(user_id: str) -> bool:
    """Check if a user is approved."""
    data = _load()
    return str(user_id) in data.get("approved", [])


def is_denied(user_id: str) -> bool:
    """Check if a user is denied."""
    data = _load()
    return str(user_id) in data.get("denied", [])


def request_pairing(user_id: str, display_name: str = "", channel: str = "") -> str:
    """Create a pairing request. Returns the pairing code."""
    data = _load()
    code = generate_code()
    data["pending"][str(user_id)] = {
        "code": code,
        "name": display_name,
        "channel": channel,
        "requested_at": int(time.time()),
    }
    _save(data)
    logger.info(f"Pairing request: {display_name} ({user_id}) -> code {code}")
    return code


def approve_user(user_id: str = "", code: str = "") -> Tuple[bool, str]:
    """Approve a user by ID or pairing code."""
    data = _load()

    # By code
    if code:
        for uid, info in data.get("pending", {}).items():
            if info.get("code") == code.upper():
                if uid not in data["approved"]:
                    data["approved"].append(uid)
                del data["pending"][uid]
                _save(data)
                return True, f"Approved: {info.get('name', uid)} ({uid})"
        return False, f"Code not found: {code}"

    # By user ID
    uid = str(user_id)
    if uid in data.get("pending", {}):
        info = data["pending"][uid]
        if uid not in data["approved"]:
            data["approved"].append(uid)
        del data["pending"][uid]
        _save(data)
        return True, f"Approved: {info.get('name', uid)} ({uid})"

    # Direct approval without pending request
    if uid not in data["approved"]:
        data["approved"].append(uid)
        _save(data)
        return True, f"Approved: {uid}"

    return False, f"Already approved: {uid}"


def deny_user(user_id: str) -> Tuple[bool, str]:
    """Deny a user."""
    data = _load()
    uid = str(user_id)
    if uid not in data["denied"]:
        data["denied"].append(uid)
    if uid in data.get("pending", {}):
        del data["pending"][uid]
    _save(data)
    return True, f"Denied: {uid}"


def list_pending() -> Dict:
    """List pending pairing requests."""
    data = _load()
    return {
        "pending": data.get("pending", {}),
        "approved_count": len(data.get("approved", [])),
        "denied_count": len(data.get("denied", [])),
    }


def list_approved() -> list:
    """List approved users."""
    data = _load()
    return data.get("approved", [])
