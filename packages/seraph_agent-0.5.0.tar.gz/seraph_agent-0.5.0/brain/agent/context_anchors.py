"""
Seraph Context Anchors — pinned facts that survive compaction.

When context gets compacted (summarized to save tokens), critical facts
can be lost. Context anchors are user-pinned or system-pinned facts
that are ALWAYS injected into the prompt, no matter how many times
compaction runs.

Examples:
- "NEVER modify API keys" (user rule)
- "VPS is at 65.109.13.25" (infrastructure fact)
- "User prefers terse responses" (preference)
"""

import json
import time
import logging
import os
from typing import Dict, List, Optional
from pathlib import Path
from dataclasses import dataclass

logger = logging.getLogger("seraph.context_anchors")

SERAPH_DIR = Path.home() / ".seraph"
ANCHORS_PATH = SERAPH_DIR / "context_anchors.json"


@dataclass
class ContextAnchor:
    """A fact that must survive compaction."""
    id: str
    text: str
    source: str  # "user", "system", "learned"
    priority: int  # Higher = more important, injected first
    created_at: float
    created_by: str = ""  # user_id or "system"
    category: str = ""  # "rule", "fact", "preference", "identity"
    token_estimate: int = 0


class AnchorStore:
    """Manage context anchors that persist across compactions."""

    def __init__(self):
        self.anchors: Dict[str, ContextAnchor] = {}
        self._load()

    def _load(self):
        if ANCHORS_PATH.exists():
            try:
                with open(ANCHORS_PATH, encoding="utf-8") as f:
                    data = json.load(f)
                for a in data.get("anchors", []):
                    anchor = ContextAnchor(**a)
                    self.anchors[anchor.id] = anchor
            except Exception as e:
                logger.warning(f"Failed to load anchors: {e}")

    def _save(self):
        try:
            SERAPH_DIR.mkdir(parents=True, exist_ok=True)
            data = {"anchors": [
                {"id": a.id, "text": a.text, "source": a.source,
                 "priority": a.priority, "created_at": a.created_at,
                 "created_by": a.created_by, "category": a.category,
                 "token_estimate": a.token_estimate}
                for a in self.anchors.values()
            ]}
            tmp = str(ANCHORS_PATH) + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
            os.replace(tmp, str(ANCHORS_PATH))
        except Exception as e:
            logger.error(f"Failed to save anchors: {e}")

    def add(self, text: str, source: str = "user", priority: int = 50,
            created_by: str = "", category: str = "fact") -> ContextAnchor:
        """Add a context anchor."""
        anchor_id = f"anchor_{int(time.time())}_{len(self.anchors)}"
        anchor = ContextAnchor(
            id=anchor_id, text=text, source=source,
            priority=priority, created_at=time.time(),
            created_by=created_by, category=category,
            token_estimate=len(text) // 4,
        )
        self.anchors[anchor_id] = anchor
        self._save()
        logger.info(f"Anchor added: {text[:50]}...")
        return anchor

    def remove(self, anchor_id: str) -> bool:
        if anchor_id in self.anchors:
            del self.anchors[anchor_id]
            self._save()
            return True
        return False

    def get_all(self, max_tokens: int = 2000) -> List[ContextAnchor]:
        """Get all anchors, sorted by priority, within token budget."""
        sorted_anchors = sorted(self.anchors.values(), key=lambda a: -a.priority)
        result = []
        total_tokens = 0
        for a in sorted_anchors:
            if total_tokens + a.token_estimate > max_tokens:
                break
            result.append(a)
            total_tokens += a.token_estimate
        return result

    def format_for_prompt(self, max_tokens: int = 2000) -> str:
        """Format anchors as a prompt section."""
        anchors = self.get_all(max_tokens)
        if not anchors:
            return ""

        lines = ["## Pinned Context (always active)"]
        for a in anchors:
            prefix = {"rule": "RULE", "fact": "FACT", "preference": "PREF", "identity": "SELF"}.get(a.category, "NOTE")
            lines.append(f"- [{prefix}] {a.text}")

        return "\n".join(lines)

    def list_anchors(self) -> List[Dict]:
        return [
            {"id": a.id, "text": a.text, "source": a.source,
             "priority": a.priority, "category": a.category,
             "created_at": a.created_at}
            for a in sorted(self.anchors.values(), key=lambda a: -a.priority)
        ]


_store = None

def get_anchor_store() -> AnchorStore:
    global _store
    if _store is None:
        _store = AnchorStore()
    return _store
