"""
Seraph Website Policy — respect robots.txt and terms of service.

Before scraping/fetching a website, check if robots.txt allows it.
Blocks scraping of sites that explicitly deny bots.
"""

import logging
import urllib.request
from typing import Optional, Dict
from urllib.parse import urlparse

logger = logging.getLogger("seraph.policy")

_cache: Dict[str, bool] = {}


def check_robots_txt(url: str, user_agent: str = "Seraph") -> bool:
    """Check if robots.txt allows our agent to access this URL. Returns True if allowed."""
    try:
        parsed = urlparse(url)
        robots_url = f"{parsed.scheme}://{parsed.netloc}/robots.txt"

        # Cache check
        if robots_url in _cache:
            return _cache[robots_url]

        req = urllib.request.Request(robots_url, headers={"User-Agent": user_agent})
        with urllib.request.urlopen(req, timeout=5) as resp:
            text = resp.read().decode("utf-8", errors="replace")

        # Simple parser — check for Disallow: / for our user agent or *
        path = parsed.path or "/"
        allowed = True
        current_agent = None

        for line in text.split("\n"):
            line = line.strip()
            if line.lower().startswith("user-agent:"):
                agent = line.split(":", 1)[1].strip()
                current_agent = agent
            elif line.lower().startswith("disallow:") and current_agent in ("*", user_agent, "Seraph"):
                disallowed = line.split(":", 1)[1].strip()
                if disallowed == "/" or path.startswith(disallowed):
                    allowed = False

        _cache[robots_url] = allowed
        return allowed

    except Exception:
        return True  # Fail-open: if we can't read robots.txt, proceed


def should_fetch(url: str) -> tuple:
    """Check if we should fetch this URL. Returns (allowed, reason)."""
    if not check_robots_txt(url):
        return False, f"Blocked by robots.txt: {url}"
    return True, "Allowed"
