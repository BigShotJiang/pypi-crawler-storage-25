"""
Seraph Proactive Alerts — messages YOU without being asked.

Monitors conditions and alerts when something needs attention:
- Server disk >90%
- SSL cert expiring in <7 days
- Price drops/spikes
- CI failures
- Cron job failures
- Memory/CPU alerts
"""

import time
import logging
import threading
import subprocess
from typing import Dict, List, Optional, Callable
from dataclasses import dataclass, field

logger = logging.getLogger("seraph.alerts")


@dataclass
class AlertRule:
    name: str
    check_fn: str  # Shell command to run
    condition: str  # "contains", "exit_nonzero", "threshold"
    threshold_value: str = ""
    interval: int = 300  # seconds
    channel: str = ""
    chat_id: str = ""
    last_triggered: float = 0
    cooldown: int = 3600  # Don't re-alert for 1 hour
    enabled: bool = True


class AlertManager:
    """Manage proactive alert rules."""

    def __init__(self):
        self.rules: List[AlertRule] = []
        self.notify_fn: Optional[Callable] = None
        self.active = False
        self._thread: Optional[threading.Thread] = None

    def add_rule(self, name: str, command: str, condition: str = "exit_nonzero",
                 threshold: str = "", interval: int = 300,
                 channel: str = "", chat_id: str = "") -> Dict:
        rule = AlertRule(
            name=name, check_fn=command, condition=condition,
            threshold_value=threshold, interval=interval,
            channel=channel, chat_id=chat_id,
        )
        self.rules.append(rule)
        return {"added": name, "command": command, "interval": f"{interval}s"}

    def remove_rule(self, name: str) -> Dict:
        self.rules = [r for r in self.rules if r.name != name]
        return {"removed": name}

    def start(self, notify_fn: Callable = None):
        self.active = True
        self.notify_fn = notify_fn
        self._thread = threading.Thread(target=self._check_loop, daemon=True)
        self._thread.start()
        logger.info(f"Alert manager started: {len(self.rules)} rules")

    def stop(self):
        self.active = False

    def _check_loop(self):
        while self.active:
            for rule in self.rules:
                if not rule.enabled:
                    continue
                if time.time() - rule.last_triggered < rule.cooldown:
                    continue
                try:
                    self._check_rule(rule)
                except Exception as e:
                    logger.debug(f"Alert check {rule.name}: {e}")
            time.sleep(60)

    def _check_rule(self, rule: AlertRule):
        try:
            result = subprocess.run(
                rule.check_fn, shell=True,
                capture_output=True, text=True, timeout=30,
            )

            triggered = False
            message = ""

            if rule.condition == "exit_nonzero" and result.returncode != 0:
                triggered = True
                message = f"Command failed (exit {result.returncode}): {result.stderr[:200]}"

            elif rule.condition == "contains" and rule.threshold_value in result.stdout:
                triggered = True
                message = f"Output contains '{rule.threshold_value}': {result.stdout[:200]}"

            elif rule.condition == "threshold":
                try:
                    value = float(result.stdout.strip())
                    threshold = float(rule.threshold_value)
                    if value >= threshold:
                        triggered = True
                        message = f"Value {value} >= threshold {threshold}"
                except ValueError:
                    pass

            if triggered:
                rule.last_triggered = time.time()
                alert_msg = f"ALERT [{rule.name}]: {message}"
                logger.warning(alert_msg)
                if self.notify_fn:
                    self.notify_fn(rule.channel, rule.chat_id, alert_msg)

        except subprocess.TimeoutExpired:
            pass

    def add_common_rules(self, channel: str = "", chat_id: str = ""):
        """Add common monitoring rules."""
        common = [
            ("disk-space", "df -h / | tail -1 | awk '{print $5}' | tr -d '%'", "threshold", "90", 3600),
            ("memory", "free -m | awk '/Mem:/{printf \"%.0f\", $3/$2*100}'", "threshold", "90", 1800),
            ("load", "cat /proc/loadavg | awk '{print $1}'", "threshold", "4", 900),
        ]
        for name, cmd, cond, thresh, interval in common:
            self.add_rule(name, cmd, cond, thresh, interval, channel, chat_id)

    def list_rules(self) -> List[Dict]:
        return [
            {"name": r.name, "command": r.check_fn[:50], "condition": r.condition,
             "interval": r.interval, "enabled": r.enabled,
             "last_triggered": r.last_triggered}
            for r in self.rules
        ]


_manager = None

def get_alert_manager() -> AlertManager:
    global _manager
    if _manager is None:
        _manager = AlertManager()
    return _manager
