"""
Seraph Process Kill-Tree — cross-platform process tree termination.

When a tool command times out or needs to be killed, this ensures ALL
child processes are terminated too. Otherwise orphan processes leak.

Supports Windows (taskkill /T) and Unix (process group SIGTERM→SIGKILL).
"""

import os
import signal
import logging
import subprocess
import time
import sys

logger = logging.getLogger("seraph.process_tree")

DEFAULT_GRACE_MS = 3000
MAX_GRACE_MS = 60000


def kill_tree(pid: int, grace_ms: int = DEFAULT_GRACE_MS):
    """Kill a process and all its children. Cross-platform."""
    if not pid or pid <= 0:
        return

    grace_ms = max(100, min(grace_ms, MAX_GRACE_MS))

    if sys.platform == "win32":
        _kill_tree_windows(pid, grace_ms)
    else:
        _kill_tree_unix(pid, grace_ms)


def _kill_tree_windows(pid: int, grace_ms: int):
    """Windows: use taskkill /T for tree kill."""
    try:
        # Graceful first (no /F)
        subprocess.run(["taskkill", "/PID", str(pid), "/T"],
                       capture_output=True, timeout=5)
        time.sleep(grace_ms / 1000)

        # Check if still running
        check = subprocess.run(["tasklist", "/FI", f"PID eq {pid}"],
                               capture_output=True, text=True, timeout=5)
        if str(pid) in check.stdout:
            # Force kill
            subprocess.run(["taskkill", "/F", "/PID", str(pid), "/T"],
                           capture_output=True, timeout=5)
    except Exception as e:
        logger.debug(f"Windows kill-tree error for PID {pid}: {e}")


def _kill_tree_unix(pid: int, grace_ms: int):
    """Unix: SIGTERM to process group, then SIGKILL."""
    try:
        # Send SIGTERM to process group
        pgid = os.getpgid(pid)
        os.killpg(pgid, signal.SIGTERM)
    except (ProcessLookupError, PermissionError):
        # Process already dead or not owned
        try:
            os.kill(pid, signal.SIGTERM)
        except (ProcessLookupError, PermissionError):
            return
    except Exception:
        try:
            os.kill(pid, signal.SIGTERM)
        except Exception:
            return

    # Wait grace period
    time.sleep(grace_ms / 1000)

    # Force kill if still alive
    try:
        os.kill(pid, 0)  # Check if alive
        try:
            pgid = os.getpgid(pid)
            os.killpg(pgid, signal.SIGKILL)
        except Exception:
            os.kill(pid, signal.SIGKILL)
    except (ProcessLookupError, PermissionError):
        pass  # Already dead


def get_children(pid: int) -> list:
    """Get child PIDs of a process. Cross-platform."""
    children = []
    try:
        if sys.platform == "win32":
            result = subprocess.run(
                ["wmic", "process", "where", f"ParentProcessId={pid}", "get", "ProcessId"],
                capture_output=True, text=True, timeout=5,
            )
            for line in result.stdout.splitlines():
                line = line.strip()
                if line.isdigit():
                    children.append(int(line))
        else:
            result = subprocess.run(
                ["pgrep", "-P", str(pid)],
                capture_output=True, text=True, timeout=5,
            )
            for line in result.stdout.splitlines():
                line = line.strip()
                if line.isdigit():
                    children.append(int(line))
    except Exception:
        pass
    return children
