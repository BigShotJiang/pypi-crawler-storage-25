"""
Seraph Ambient Learning — learn from user behavior without being asked.

Tracks silently:
- Which responses get retried (user didn't like it)
- Which tool calls get undone (wrong action)
- Which corrections the user makes ("no, I meant X")
- Response length preferences (do they prefer terse or detailed?)
- Time-of-day patterns (what do they work on when?)
- Command frequency (what do they do most?)

Builds a shadow profile that improves over time.
"""

import json
import time
import logging
import os
from typing import Dict, List, Optional
from pathlib import Path
from collections import defaultdict

logger = logging.getLogger("seraph.ambient_learning")

SERAPH_DIR = Path.home() / ".seraph"
LEARNING_PATH = SERAPH_DIR / "ambient_learnings.json"


class AmbientLearner:
    """Silently learns from user behavior patterns."""

    def __init__(self):
        self.data = {
            "corrections": [],       # "No, I meant X" patterns
            "retries": [],           # Messages that got /retry'd
            "undos": [],             # Actions that got /undo'd
            "preferences": {},       # Detected preferences
            "tool_frequency": {},    # Which tools used most
            "time_patterns": {},     # Activity by hour
            "response_feedback": {   # Implicit feedback
                "too_long": 0,
                "too_short": 0,
                "just_right": 0,
            },
            "command_history": [],   # Recent commands for pattern detection
        }
        self._load()

    def _load(self):
        if LEARNING_PATH.exists():
            try:
                with open(LEARNING_PATH, encoding="utf-8") as f:
                    saved = json.load(f)
                    self.data.update(saved)
            except Exception:
                pass

    def _save(self):
        try:
            SERAPH_DIR.mkdir(parents=True, exist_ok=True)
            tmp = str(LEARNING_PATH) + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(self.data, f, indent=2, default=str)
            os.replace(tmp, str(LEARNING_PATH))
        except Exception as e:
            logger.debug(f"Save learnings: {e}")

    # ─── Event Tracking ──────────────────────────────────────────

    def on_message(self, user_id: str, text: str):
        """Track every incoming message for patterns."""
        import datetime
        hour = datetime.datetime.now().hour
        hour_key = str(hour)
        self.data["time_patterns"][hour_key] = self.data["time_patterns"].get(hour_key, 0) + 1

        # Detect corrections
        corrections = [
            "no, i meant", "no i meant", "that's not what i",
            "i said", "not that", "wrong", "i wanted",
            "actually, ", "actually i", "no, ", "nope, ",
        ]
        text_lower = text.lower()
        for phrase in corrections:
            if text_lower.startswith(phrase) or f" {phrase}" in text_lower:
                self.data["corrections"].append({
                    "text": text[:200],
                    "time": time.time(),
                    "user": user_id,
                })
                self.data["corrections"] = self.data["corrections"][-50:]
                self._detect_preference_from_correction(text)
                break

        # Track command usage
        if text.startswith("/"):
            cmd = text.split()[0]
            self.data["command_history"].append({"cmd": cmd, "time": time.time()})
            self.data["command_history"] = self.data["command_history"][-200:]

    def on_retry(self, user_id: str, original_message: str):
        """Track when a user retries (implies dissatisfaction)."""
        self.data["retries"].append({
            "message": original_message[:200],
            "time": time.time(),
            "user": user_id,
        })
        self.data["retries"] = self.data["retries"][-30:]
        self._save()

    def on_undo(self, user_id: str, undone_action: str):
        """Track when a user undoes an action."""
        self.data["undos"].append({
            "action": undone_action[:200],
            "time": time.time(),
            "user": user_id,
        })
        self.data["undos"] = self.data["undos"][-30:]
        self._save()

    def on_tool_call(self, tool_name: str):
        """Track tool usage frequency."""
        self.data["tool_frequency"][tool_name] = self.data["tool_frequency"].get(tool_name, 0) + 1

    def on_response_sent(self, response_length: int, was_retry: bool = False):
        """Track response length patterns."""
        if was_retry:
            # If they retried, the previous response was probably wrong length
            if response_length > 500:
                self.data["response_feedback"]["too_long"] += 1
            else:
                self.data["response_feedback"]["too_short"] += 1
        else:
            self.data["response_feedback"]["just_right"] += 1

        # Save periodically (every 10 events)
        total = sum(self.data["response_feedback"].values())
        if total % 10 == 0:
            self._save()

    # ─── Preference Detection ────────────────────────────────────

    def _detect_preference_from_correction(self, text: str):
        """Extract a preference from a correction."""
        text_lower = text.lower()

        # Length preference
        if any(w in text_lower for w in ["shorter", "brief", "concise", "terse", "less"]):
            self.data["preferences"]["response_length"] = "short"
        elif any(w in text_lower for w in ["longer", "more detail", "elaborate", "explain more"]):
            self.data["preferences"]["response_length"] = "long"

        # Format preference
        if any(w in text_lower for w in ["no emoji", "no emojis", "stop using emoji"]):
            self.data["preferences"]["emojis"] = False
        if any(w in text_lower for w in ["code only", "just the code", "skip the explanation"]):
            self.data["preferences"]["code_only"] = True
        if any(w in text_lower for w in ["don't use markdown", "plain text"]):
            self.data["preferences"]["markdown"] = False

        self._save()

    # ─── Insights ─────────────────────────────────────────────────

    def get_insights(self) -> Dict:
        """Get learned insights about the user."""
        insights = {
            "preferences": self.data.get("preferences", {}),
            "top_tools": sorted(
                self.data.get("tool_frequency", {}).items(),
                key=lambda x: -x[1]
            )[:10],
            "peak_hours": sorted(
                self.data.get("time_patterns", {}).items(),
                key=lambda x: -x[1]
            )[:5],
            "correction_count": len(self.data.get("corrections", [])),
            "retry_count": len(self.data.get("retries", [])),
            "undo_count": len(self.data.get("undos", [])),
        }

        # Response length preference from feedback
        fb = self.data.get("response_feedback", {})
        if fb.get("too_long", 0) > fb.get("too_short", 0) * 2:
            insights["inferred_preference"] = "User prefers shorter responses"
        elif fb.get("too_short", 0) > fb.get("too_long", 0) * 2:
            insights["inferred_preference"] = "User prefers detailed responses"

        return insights

    def format_for_prompt(self) -> str:
        """Format learned preferences as a prompt injection."""
        prefs = self.data.get("preferences", {})
        if not prefs:
            return ""

        lines = ["## User Preferences (learned)"]
        if prefs.get("response_length") == "short":
            lines.append("- User prefers SHORT, concise responses")
        elif prefs.get("response_length") == "long":
            lines.append("- User prefers DETAILED, thorough responses")
        if prefs.get("emojis") is False:
            lines.append("- Do NOT use emojis")
        if prefs.get("code_only"):
            lines.append("- User prefers code-only responses, skip explanations")
        if prefs.get("markdown") is False:
            lines.append("- Use plain text, not markdown")

        return "\n".join(lines) if len(lines) > 1 else ""


_learner = None

def get_ambient_learner() -> AmbientLearner:
    global _learner
    if _learner is None:
        _learner = AmbientLearner()
    return _learner
