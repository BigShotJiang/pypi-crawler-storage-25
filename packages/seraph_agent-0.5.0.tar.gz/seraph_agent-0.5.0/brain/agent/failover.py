"""
Seraph Auth Failover — automatic model + provider failover.

When a model request fails (rate limit, auth error, timeout, context overflow),
this module handles:
1. Auth profile rotation (try next API key for same provider)
2. Model failover (try next model in the fallback chain)
3. Context overflow recovery (trigger compaction + retry)
4. Rate limit backoff (exponential with jitter)
5. Cooldown tracking (don't retry known-bad profiles)
"""

import json
import os
import time
import random
import logging
from typing import Dict, List, Optional, Callable, Any
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger("seraph.failover")

SERAPH_DIR = Path.home() / ".seraph"
AUTH_PROFILES_PATH = SERAPH_DIR / "auth_profiles.json"
COOLDOWN_PATH = SERAPH_DIR / "auth_cooldowns.json"

# Error classification
RATE_LIMIT_CODES = {429}
AUTH_ERROR_CODES = {401, 403}
CONTEXT_OVERFLOW_PATTERNS = [
    "context_length_exceeded",
    "maximum context length",
    "token limit",
    "too many tokens",
    "context window",
    "max_tokens",
]
BILLING_PATTERNS = [
    "billing",
    "quota",
    "insufficient_quota",
    "exceeded your current quota",
    "credit",
    "payment",
]


@dataclass
class AuthProfile:
    """An API key / credential for a provider."""
    id: str
    provider: str
    api_key: str
    label: str = ""
    last_used: float = 0.0
    last_failed: float = 0.0
    failure_count: int = 0
    cooldown_until: float = 0.0
    is_default: bool = False

    @property
    def is_cooled_down(self) -> bool:
        return time.time() < self.cooldown_until

    @property
    def is_healthy(self) -> bool:
        return not self.is_cooled_down and self.failure_count < 5


@dataclass
class FailoverDecision:
    """What to do after a failure."""
    action: str  # "retry", "rotate_auth", "failover_model", "compact", "abort"
    model: str = ""
    provider: str = ""
    auth_profile_id: str = ""
    backoff_seconds: float = 0.0
    reason: str = ""


@dataclass
class FailoverState:
    """Tracks failover state across retries within a single request."""
    original_model: str = ""
    original_provider: str = ""
    current_model: str = ""
    current_provider: str = ""
    attempts: int = 0
    max_attempts: int = 5
    auth_profiles_tried: List[str] = field(default_factory=list)
    models_tried: List[str] = field(default_factory=list)
    last_error: str = ""
    compaction_attempted: bool = False


class AuthProfileStore:
    """Manages API key profiles with cooldown tracking."""

    def __init__(self):
        self.profiles: Dict[str, AuthProfile] = {}
        self._load()

    def _load(self):
        """Load auth profiles from disk."""
        if AUTH_PROFILES_PATH.exists():
            try:
                with open(AUTH_PROFILES_PATH) as f:
                    data = json.load(f)
                for p in data.get("profiles", []):
                    profile = AuthProfile(**p)
                    self.profiles[profile.id] = profile
            except Exception as e:
                logger.warning(f"Failed to load auth profiles: {e}")

        # Load cooldowns
        if COOLDOWN_PATH.exists():
            try:
                with open(COOLDOWN_PATH) as f:
                    cooldowns = json.load(f)
                for pid, until in cooldowns.items():
                    if pid in self.profiles:
                        self.profiles[pid].cooldown_until = until
            except Exception:
                pass

        # Auto-discover from environment
        self._discover_env_profiles()

    def _discover_env_profiles(self):
        """Create profiles from environment API keys."""
        env_providers = {
            "OPENAI_API_KEY": "openai",
            "ANTHROPIC_API_KEY": "anthropic",
            "GOOGLE_API_KEY": "google",
            "DEEPSEEK_API_KEY": "deepseek",
            "GROQ_API_KEY": "groq",
            "TOGETHER_API_KEY": "together",
            "XAI_API_KEY": "xai",
            "MISTRAL_API_KEY": "mistral",
            "OPENROUTER_API_KEY": "openrouter",
        }
        for env_key, provider in env_providers.items():
            key = os.environ.get(env_key, "")
            if key:
                pid = f"env_{provider}"
                if pid not in self.profiles:
                    self.profiles[pid] = AuthProfile(
                        id=pid,
                        provider=provider,
                        api_key=key,
                        label=f"From {env_key}",
                        is_default=True,
                    )

    def get_profiles_for_provider(self, provider: str) -> List[AuthProfile]:
        """Get all healthy profiles for a provider, sorted by preference."""
        profiles = [
            p for p in self.profiles.values()
            if p.provider == provider and p.is_healthy
        ]
        # Default profiles first, then by last_used (most recently successful first)
        profiles.sort(key=lambda p: (not p.is_default, -p.last_used))
        return profiles

    def mark_success(self, profile_id: str):
        """Mark a profile as successfully used."""
        if profile_id in self.profiles:
            p = self.profiles[profile_id]
            p.last_used = time.time()
            p.failure_count = 0
            p.cooldown_until = 0

    def mark_failure(self, profile_id: str, cooldown_seconds: int = 300):
        """Mark a profile as failed with cooldown."""
        if profile_id in self.profiles:
            p = self.profiles[profile_id]
            p.last_failed = time.time()
            p.failure_count += 1
            # Exponential cooldown: 5min, 15min, 45min, 2h
            multiplier = min(p.failure_count, 4)
            actual_cooldown = cooldown_seconds * (3 ** (multiplier - 1))
            p.cooldown_until = time.time() + actual_cooldown
            logger.warning(
                f"Auth profile {profile_id} failed (#{p.failure_count}), "
                f"cooldown {actual_cooldown}s"
            )
            self._save_cooldowns()

    def _save_cooldowns(self):
        """Persist cooldowns to disk."""
        try:
            cooldowns = {
                pid: p.cooldown_until
                for pid, p in self.profiles.items()
                if p.cooldown_until > time.time()
            }
            SERAPH_DIR.mkdir(parents=True, exist_ok=True)
            tmp = str(COOLDOWN_PATH) + ".tmp"
            with open(tmp, "w") as f:
                json.dump(cooldowns, f)
            os.replace(tmp, str(COOLDOWN_PATH))
        except Exception as e:
            logger.warning(f"Failed to save cooldowns: {e}")


def classify_error(error: str, status_code: int = 0) -> str:
    """Classify an error for failover decision."""
    error_lower = error.lower()

    if status_code in RATE_LIMIT_CODES or "rate_limit" in error_lower or "429" in error_lower:
        return "rate_limit"

    if status_code in AUTH_ERROR_CODES or "unauthorized" in error_lower or "forbidden" in error_lower:
        return "auth_error"

    if any(p in error_lower for p in CONTEXT_OVERFLOW_PATTERNS):
        return "context_overflow"

    if any(p in error_lower for p in BILLING_PATTERNS):
        return "billing_error"

    if "timeout" in error_lower or "timed out" in error_lower:
        return "timeout"

    if "connection" in error_lower or "network" in error_lower:
        return "network_error"

    return "unknown"


def decide_failover(
    error: str,
    status_code: int,
    state: FailoverState,
    auth_store: AuthProfileStore,
    failover_chain: List[str],
) -> FailoverDecision:
    """
    Decide what to do after a failure.

    Returns a FailoverDecision with the recommended action.
    """
    if state.attempts >= state.max_attempts:
        return FailoverDecision(
            action="abort",
            reason=f"Max attempts ({state.max_attempts}) exceeded. Last error: {error}",
        )

    error_type = classify_error(error, status_code)

    # Context overflow → compact and retry
    if error_type == "context_overflow" and not state.compaction_attempted:
        return FailoverDecision(
            action="compact",
            model=state.current_model,
            provider=state.current_provider,
            reason="Context window exceeded, compacting history",
        )

    # Rate limit → backoff + maybe rotate auth
    if error_type == "rate_limit":
        # Try another auth profile for same provider first
        profiles = auth_store.get_profiles_for_provider(state.current_provider)
        untried = [p for p in profiles if p.id not in state.auth_profiles_tried]

        if untried:
            profile = untried[0]
            return FailoverDecision(
                action="rotate_auth",
                model=state.current_model,
                provider=state.current_provider,
                auth_profile_id=profile.id,
                backoff_seconds=2.0 + random.uniform(0, 2),
                reason=f"Rate limited, rotating to auth profile {profile.id}",
            )

        # No more profiles → failover to next model
        return _decide_model_failover(state, failover_chain, "Rate limited on all auth profiles")

    # Auth error → rotate auth, then failover model
    if error_type == "auth_error":
        profiles = auth_store.get_profiles_for_provider(state.current_provider)
        untried = [p for p in profiles if p.id not in state.auth_profiles_tried]

        if untried:
            return FailoverDecision(
                action="rotate_auth",
                model=state.current_model,
                provider=state.current_provider,
                auth_profile_id=untried[0].id,
                reason=f"Auth failed, trying profile {untried[0].id}",
            )

        return _decide_model_failover(state, failover_chain, "Auth failed on all profiles")

    # Billing error → failover to different provider
    if error_type == "billing_error":
        return _decide_model_failover(state, failover_chain, "Billing/quota error")

    # Timeout/network → retry with backoff
    if error_type in ("timeout", "network_error"):
        backoff = min(2 ** state.attempts + random.uniform(0, 2), 30)
        return FailoverDecision(
            action="retry",
            model=state.current_model,
            provider=state.current_provider,
            backoff_seconds=backoff,
            reason=f"{error_type}, retrying with {backoff:.1f}s backoff",
        )

    # Unknown error → retry once, then failover
    if state.attempts < 2:
        return FailoverDecision(
            action="retry",
            model=state.current_model,
            provider=state.current_provider,
            backoff_seconds=3.0,
            reason=f"Unknown error, retrying: {error[:100]}",
        )

    return _decide_model_failover(state, failover_chain, f"Persistent error: {error[:100]}")


def _decide_model_failover(
    state: FailoverState,
    failover_chain: List[str],
    reason: str,
) -> FailoverDecision:
    """Try the next model in the failover chain."""
    for model_id in failover_chain:
        if model_id not in state.models_tried:
            # Determine provider for this model
            from brain.agent.llm import get_provider_for_model
            provider = get_provider_for_model(model_id) or state.current_provider

            return FailoverDecision(
                action="failover_model",
                model=model_id,
                provider=provider,
                reason=f"{reason}. Failing over to {model_id}",
            )

    return FailoverDecision(
        action="abort",
        reason=f"{reason}. No more models in failover chain.",
    )
