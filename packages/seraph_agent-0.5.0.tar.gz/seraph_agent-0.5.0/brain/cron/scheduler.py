"""
Seraph Cron Scheduler — run tasks on a schedule.

Tasks are stored in ~/.seraph/cron/jobs.json and executed by a background thread.
"""

import json
import time
import logging
import threading
from pathlib import Path
from datetime import datetime, timezone
from typing import Dict, List, Optional, Callable

logger = logging.getLogger("seraph.cron")

SERAPH_DIR = Path.home() / ".seraph"
JOBS_PATH = SERAPH_DIR / "cron" / "jobs.json"


class CronJob:
    """A scheduled task with optional channel delivery."""
    def __init__(self, name: str, schedule: str, command: str, enabled: bool = True,
                 deliver_to: str = "", deliver_channel: str = ""):
        self.name = name
        self.schedule = schedule  # "every 5m", "every 1h", "daily 09:00"
        self.command = command
        self.enabled = enabled
        self.last_run = 0
        self.run_count = 0
        self.last_result = None
        self.deliver_to = deliver_to  # chat_id to send results to
        self.deliver_channel = deliver_channel  # "telegram", "discord", etc.

    def should_run(self) -> bool:
        """Check if this job should run now."""
        if not self.enabled:
            return False

        now = time.time()
        elapsed = now - self.last_run

        if self.schedule.startswith("every "):
            interval_str = self.schedule[6:].strip()
            if interval_str.endswith("m"):
                interval = int(interval_str[:-1]) * 60
            elif interval_str.endswith("h"):
                interval = int(interval_str[:-1]) * 3600
            elif interval_str.endswith("s"):
                interval = int(interval_str[:-1])
            else:
                interval = int(interval_str)
            return elapsed >= interval

        if self.schedule.startswith("daily "):
            target_time = self.schedule[6:].strip()  # "09:00"
            now_utc = datetime.now(timezone.utc)
            hour, minute = map(int, target_time.split(":"))
            if now_utc.hour == hour and now_utc.minute == minute and elapsed > 120:
                return True

        return False

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "schedule": self.schedule,
            "command": self.command,
            "enabled": self.enabled,
            "last_run": self.last_run,
            "run_count": self.run_count,
        }

    @classmethod
    def from_dict(cls, d: dict) -> 'CronJob':
        job = cls(d["name"], d["schedule"], d["command"], d.get("enabled", True))
        job.last_run = d.get("last_run", 0)
        job.run_count = d.get("run_count", 0)
        return job


class Scheduler:
    """Manages and runs cron jobs."""

    def __init__(self):
        self.jobs: List[CronJob] = []
        self.running = False
        self.thread = None
        self.executor: Optional[Callable] = None  # Set by the bot to execute commands
        self.delivery_callback: Optional[Callable] = None  # Set by bot: delivery_callback(channel, chat_id, text)
        self._load_jobs()

    def _load_jobs(self):
        """Load jobs from disk."""
        JOBS_PATH.parent.mkdir(parents=True, exist_ok=True)
        if JOBS_PATH.exists():
            try:
                data = json.loads(JOBS_PATH.read_text())
                self.jobs = [CronJob.from_dict(j) for j in data]
                logger.info(f"Loaded {len(self.jobs)} cron jobs")
            except Exception as e:
                logger.error(f"Failed to load cron jobs: {e}")

    def _save_jobs(self):
        """Save jobs to disk."""
        try:
            data = [j.to_dict() for j in self.jobs]
            JOBS_PATH.write_text(json.dumps(data, indent=2))
        except Exception as e:
            logger.error(f"Failed to save cron jobs: {e}")

    def add_job(self, name: str, schedule: str, command: str) -> CronJob:
        """Add a new cron job."""
        # Remove existing job with same name
        self.jobs = [j for j in self.jobs if j.name != name]
        job = CronJob(name, schedule, command)
        self.jobs.append(job)
        self._save_jobs()
        logger.info(f"Added cron job: {name} ({schedule})")
        return job

    def remove_job(self, name: str) -> bool:
        """Remove a cron job."""
        before = len(self.jobs)
        self.jobs = [j for j in self.jobs if j.name != name]
        if len(self.jobs) < before:
            self._save_jobs()
            return True
        return False

    def list_jobs(self) -> List[Dict]:
        """List all jobs."""
        return [j.to_dict() for j in self.jobs]

    def start(self, executor: Callable = None):
        """Start the scheduler background thread."""
        self.executor = executor
        self.running = True
        self.thread = threading.Thread(target=self._run_loop, daemon=True)
        self.thread.start()
        logger.info("Cron scheduler started")

    def stop(self):
        """Stop the scheduler."""
        self.running = False

    def _run_loop(self):
        """Background loop that checks and runs jobs."""
        while self.running:
            for job in self.jobs:
                if job.should_run():
                    logger.info(f"Running cron job: {job.name}")
                    try:
                        if self.executor:
                            result = self.executor(job.command)
                            job.last_result = result

                            # Deliver result to channel if configured
                            if job.deliver_to and job.deliver_channel and self.delivery_callback:
                                try:
                                    result_text = json.dumps(result, default=str)[:3000] if isinstance(result, dict) else str(result)[:3000]
                                    self.delivery_callback(job.deliver_channel, job.deliver_to,
                                                           f"[Cron: {job.name}]\n{result_text}")
                                except Exception as de:
                                    logger.warning(f"Cron delivery failed: {de}")

                        job.last_run = time.time()
                        job.run_count += 1
                        self._save_jobs()
                    except Exception as e:
                        logger.error(f"Cron job {job.name} failed: {e}")

            time.sleep(30)  # Check every 30 seconds


# Singleton
_scheduler = None

def get_scheduler() -> Scheduler:
    global _scheduler
    if _scheduler is None:
        _scheduler = Scheduler()
    return _scheduler
