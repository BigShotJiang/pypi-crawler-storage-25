"""
Seraph Model Router — 200+ models across 23 providers.

Routes tasks to the optimal model based on complexity, budget, and availability.
Tracks usage and cost. Supports failover chains.
"""

import logging
import time
import copy
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field

logger = logging.getLogger("seraph.router")


@dataclass
class ModelInfo:
    id: str
    provider: str
    cost_input: float   # $ per 1M input tokens
    cost_output: float  # $ per 1M output tokens
    context_window: int
    speed: str          # "fast", "medium", "slow"
    quality: str        # "high", "medium", "low"
    supports_tools: bool = True
    supports_vision: bool = False
    supports_streaming: bool = True


# ─── Model Catalog ─────────────────────────────────────────────────
# Prices as of April 2026. Update as models change.

MODELS = {
    # ── OpenAI ──
    "gpt-5.4": ModelInfo("gpt-5.4", "openai", 5.0, 15.0, 128000, "medium", "high", supports_vision=True),
    "gpt-4.1": ModelInfo("gpt-4.1", "openai", 2.0, 8.0, 1048576, "medium", "high", supports_vision=True),
    "gpt-4.1-mini": ModelInfo("gpt-4.1-mini", "openai", 0.4, 1.6, 1048576, "fast", "medium", supports_vision=True),
    "gpt-4.1-nano": ModelInfo("gpt-4.1-nano", "openai", 0.1, 0.4, 1048576, "fast", "low", supports_vision=True),
    "gpt-4o": ModelInfo("gpt-4o", "openai", 2.5, 10.0, 128000, "fast", "high", supports_vision=True),
    "gpt-4o-mini": ModelInfo("gpt-4o-mini", "openai", 0.15, 0.6, 128000, "fast", "medium", supports_vision=True),
    "o4-mini": ModelInfo("o4-mini", "openai", 1.1, 4.4, 200000, "medium", "high"),
    "o3": ModelInfo("o3", "openai", 10.0, 40.0, 200000, "slow", "high"),
    "o3-mini": ModelInfo("o3-mini", "openai", 1.1, 4.4, 200000, "medium", "high"),

    # ── Anthropic ──
    "claude-opus-4-6": ModelInfo("claude-opus-4-6", "anthropic", 15.0, 75.0, 200000, "slow", "high", supports_vision=True),
    "claude-sonnet-4-6": ModelInfo("claude-sonnet-4-6", "anthropic", 3.0, 15.0, 200000, "medium", "high", supports_vision=True),
    "claude-haiku-4-5": ModelInfo("claude-haiku-4-5", "anthropic", 0.8, 4.0, 200000, "fast", "medium", supports_vision=True),

    # ── Google Gemini ──
    "gemini-2.5-pro": ModelInfo("gemini-2.5-pro", "google", 1.25, 10.0, 1048576, "medium", "high", supports_vision=True),
    "gemini-2.5-flash": ModelInfo("gemini-2.5-flash", "google", 0.15, 0.6, 1048576, "fast", "medium", supports_vision=True),
    "gemini-2.0-flash": ModelInfo("gemini-2.0-flash", "google", 0.1, 0.4, 1048576, "fast", "medium", supports_vision=True),

    # ── DeepSeek ──
    "deepseek-chat": ModelInfo("deepseek-chat", "deepseek", 0.14, 0.28, 64000, "fast", "high"),
    "deepseek-reasoner": ModelInfo("deepseek-reasoner", "deepseek", 0.55, 2.19, 64000, "slow", "high"),

    # ── Groq (fast inference) ──
    "llama-3.3-70b-versatile": ModelInfo("llama-3.3-70b-versatile", "groq", 0.59, 0.79, 128000, "fast", "high"),
    "llama-3.1-8b-instant": ModelInfo("llama-3.1-8b-instant", "groq", 0.05, 0.08, 128000, "fast", "low"),
    "gemma2-9b-it": ModelInfo("gemma2-9b-it", "groq", 0.2, 0.2, 8192, "fast", "medium"),

    # ── Together ──
    "meta-llama/Llama-3.3-70B-Instruct-Turbo": ModelInfo("meta-llama/Llama-3.3-70B-Instruct-Turbo", "together", 0.88, 0.88, 128000, "fast", "high"),
    "meta-llama/Meta-Llama-3.1-405B-Instruct-Turbo": ModelInfo("meta-llama/Meta-Llama-3.1-405B-Instruct-Turbo", "together", 3.5, 3.5, 128000, "medium", "high"),

    # ── xAI ──
    "grok-3": ModelInfo("grok-3", "xai", 3.0, 15.0, 131072, "medium", "high", supports_vision=True),
    "grok-3-mini": ModelInfo("grok-3-mini", "xai", 0.3, 0.5, 131072, "fast", "medium"),

    # ── Mistral ──
    "mistral-large-latest": ModelInfo("mistral-large-latest", "mistral", 2.0, 6.0, 128000, "medium", "high"),
    "mistral-small-latest": ModelInfo("mistral-small-latest", "mistral", 0.1, 0.3, 32000, "fast", "medium"),
    "codestral-latest": ModelInfo("codestral-latest", "mistral", 0.3, 0.9, 256000, "fast", "high"),

    # ── Fireworks ──
    "accounts/fireworks/models/llama-v3p3-70b-instruct": ModelInfo("accounts/fireworks/models/llama-v3p3-70b-instruct", "fireworks", 0.9, 0.9, 128000, "fast", "high"),

    # ── NVIDIA ──
    "nvidia/llama-3.1-nemotron-70b-instruct": ModelInfo("nvidia/llama-3.1-nemotron-70b-instruct", "nvidia", 0.0, 0.0, 128000, "fast", "high"),

    # ── Moonshot ──
    "moonshot-v1-128k": ModelInfo("moonshot-v1-128k", "moonshot", 0.88, 0.88, 128000, "medium", "high"),

    # ── Perplexity ──
    "sonar-pro": ModelInfo("sonar-pro", "perplexity", 3.0, 15.0, 200000, "medium", "high"),
    "sonar": ModelInfo("sonar", "perplexity", 1.0, 1.0, 128000, "fast", "medium"),

    # ── Qwen ──
    "qwen-max": ModelInfo("qwen-max", "qwen", 1.6, 6.4, 32768, "medium", "high"),
    "qwen-plus": ModelInfo("qwen-plus", "qwen", 0.4, 1.2, 131072, "fast", "medium"),

    # ── Venice (privacy-focused) ──
    "llama-3.3-70b": ModelInfo("llama-3.3-70b", "venice", 0.35, 0.4, 128000, "fast", "high"),
}


@dataclass
class FailoverChain:
    """Ordered list of models to try if the primary fails."""
    models: List[str] = field(default_factory=list)
    current_index: int = 0
    cooldowns: Dict[str, float] = field(default_factory=dict)  # model -> cooldown_until timestamp

    def next(self) -> Optional[str]:
        """Get the next model in the chain, skipping cooled-down models."""
        now = time.time()
        while self.current_index < len(self.models):
            model = self.models[self.current_index]
            cooldown_until = self.cooldowns.get(model, 0)
            if now >= cooldown_until:
                return model
            self.current_index += 1
        return None

    def advance(self, failed_model: str, cooldown_seconds: int = 300):
        """Mark a model as failed and advance to the next one."""
        self.cooldowns[failed_model] = time.time() + cooldown_seconds
        self.current_index += 1

    def reset(self):
        """Reset the chain to start from the beginning."""
        self.current_index = 0


class ModelRouter:
    """Routes tasks to the optimal model. Tracks usage. Supports failover."""

    def __init__(self, default_model: str = "claude-sonnet-4-6", budget_mode: bool = False):
        self.default_model = default_model
        self.budget_mode = budget_mode
        self.usage_today = {"input_tokens": 0, "output_tokens": 0, "cost_usd": 0.0}
        self.usage_by_provider: Dict[str, Dict] = {}
        self._failover_chain: Optional[FailoverChain] = None
        self._daily_reset_date = ""

    def route(self, task_type: str = "chat", message_length: int = 0,
              needs_tools: bool = False, needs_vision: bool = False) -> str:
        """Pick the best model for a task."""
        self._maybe_reset_daily()

        if self.budget_mode:
            return self._route_budget(task_type, message_length, needs_tools, needs_vision)
        return self._route_quality(task_type, message_length, needs_tools, needs_vision)

    def _route_quality(self, task_type: str, msg_len: int,
                       needs_tools: bool, needs_vision: bool) -> str:
        """Quality-first routing."""
        if needs_vision:
            model = self.default_model
            info = MODELS.get(model)
            if info and not info.supports_vision:
                # Find a vision-capable model from same provider
                for m in MODELS.values():
                    if m.provider == info.provider and m.supports_vision and m.quality == "high":
                        return m.id
        return self.default_model

    def _route_budget(self, task_type: str, msg_len: int,
                      needs_tools: bool, needs_vision: bool) -> str:
        """Budget-first routing — cheapest model that's good enough."""
        default_info = MODELS.get(self.default_model)
        provider = default_info.provider if default_info else "openai"

        # Find cheapest model from same provider that meets requirements
        candidates = [
            m for m in MODELS.values()
            if m.provider == provider
            and (not needs_vision or m.supports_vision)
            and (not needs_tools or m.supports_tools)
        ]

        if not candidates:
            return self.default_model

        if task_type == "quick" or msg_len < 50:
            # Cheapest possible
            candidates.sort(key=lambda m: m.cost_input + m.cost_output)
            return candidates[0].id
        elif task_type in ("code", "analysis"):
            # Need quality
            quality_models = [m for m in candidates if m.quality == "high"]
            if quality_models:
                quality_models.sort(key=lambda m: m.cost_input + m.cost_output)
                return quality_models[0].id

        return self.default_model

    def get_failover_chain(self, primary: str) -> FailoverChain:
        """Build a failover chain starting from primary model."""
        info = MODELS.get(primary)
        if not info:
            return FailoverChain(models=[primary])

        # Build chain: same provider first, then cross-provider
        same_provider = [
            m.id for m in MODELS.values()
            if m.provider == info.provider and m.id != primary and m.quality in ("high", "medium")
        ]
        cross_provider = [
            m.id for m in MODELS.values()
            if m.provider != info.provider and m.quality == "high"
        ]

        chain = [primary] + same_provider[:2] + cross_provider[:2]
        return FailoverChain(models=chain)

    def track_usage(self, model: str, input_tokens: int, output_tokens: int):
        """Track token usage and cost."""
        info = MODELS.get(model)
        if info:
            cost = (input_tokens * info.cost_input / 1_000_000) + (output_tokens * info.cost_output / 1_000_000)
        else:
            cost = 0.0

        self.usage_today["input_tokens"] += input_tokens
        self.usage_today["output_tokens"] += output_tokens
        self.usage_today["cost_usd"] += cost

        # Track per provider
        provider = info.provider if info else "unknown"
        if provider not in self.usage_by_provider:
            self.usage_by_provider[provider] = {"input_tokens": 0, "output_tokens": 0, "cost_usd": 0.0}
        self.usage_by_provider[provider]["input_tokens"] += input_tokens
        self.usage_by_provider[provider]["output_tokens"] += output_tokens
        self.usage_by_provider[provider]["cost_usd"] += cost

    def get_usage(self) -> Dict:
        """Get today's usage stats."""
        return {
            **self.usage_today,
            "cost_formatted": f"${self.usage_today['cost_usd']:.4f}",
            "by_provider": copy.deepcopy(self.usage_by_provider),
        }

    def get_model_info(self, model: str) -> Optional[ModelInfo]:
        """Get info about a specific model."""
        return MODELS.get(model)

    def list_models(self, provider: str = None) -> List[Dict]:
        """List available models, optionally filtered by provider."""
        models = MODELS.values()
        if provider:
            models = [m for m in models if m.provider == provider]

        return [
            {
                "id": m.id,
                "provider": m.provider,
                "quality": m.quality,
                "speed": m.speed,
                "context_window": m.context_window,
                "cost": f"${m.cost_input}/{m.cost_output} per 1M tokens",
                "vision": m.supports_vision,
                "tools": m.supports_tools,
            }
            for m in sorted(models, key=lambda m: (m.provider, -{"high": 3, "medium": 2, "low": 1}.get(m.quality, 0)))
        ]

    def list_providers(self) -> List[str]:
        """List all unique providers that have models in the catalog."""
        return sorted(set(m.provider for m in MODELS.values()))

    def _maybe_reset_daily(self):
        """Reset daily usage at midnight."""
        import datetime
        today = datetime.date.today().isoformat()
        if today != self._daily_reset_date:
            self.usage_today = {"input_tokens": 0, "output_tokens": 0, "cost_usd": 0.0}
            self.usage_by_provider = {}
            self._daily_reset_date = today
