"""
Seraph Config Schema — validates config.yaml against a typed schema.

Catches misconfigurations at startup instead of at runtime.
Supports migration from older config versions.
"""

import logging
from typing import Dict, List, Any, Optional, Tuple

logger = logging.getLogger("seraph.config_schema")

# ─── Schema Definition ─────────────────────────────────────────────
# Each entry: (type, required, default, description, validator_fn)

SCHEMA = {
    "provider": (str, False, "openai", "Default LLM provider"),
    "model": (str, False, "claude-sonnet-4-6", "Default model"),
    "gateway_port": (int, False, 18800, "Gateway WebSocket port"),
    "brain_port": (int, False, 18801, "Brain HTTP port"),
    "max_iterations": (int, False, 25, "Max agent loop iterations"),
    "max_tokens": (int, False, 8192, "Max output tokens per response"),
    "temperature": (float, False, 0.7, "LLM temperature"),
    "memory": {
        "enabled": (bool, False, True, "Enable persistent memory"),
        "search": (str, False, "fts5", "Search engine: fts5 or lancedb"),
        "cleanup_days": (int, False, 90, "Days to keep memory"),
    },
    "skills": {
        "auto_generate": (bool, False, True, "Auto-generate skills from conversations"),
        "directory": (str, False, "~/.seraph/skills", "Skills directory"),
        "marketplace_url": (str, False, "", "Skills marketplace URL"),
    },
    "audit": {
        "enabled": (bool, False, True, "Enable self-auditing"),
        "max_rounds": (int, False, 5, "Max audit rounds"),
    },
    "telegram": {
        "enabled": (bool, False, False, "Enable Telegram channel"),
        "token": (str, False, "", "Telegram bot token"),
        "allowed_users": (list, False, [], "Allowed user IDs"),
        "group_policy": (str, False, "allowlist", "Group access policy: open or allowlist"),
        "webhook_mode": (bool, False, False, "Use webhook instead of polling"),
        "webhook_url": (str, False, "", "Webhook URL"),
    },
    "discord": {
        "enabled": (bool, False, False, "Enable Discord channel"),
        "token": (str, False, "", "Discord bot token"),
        "allowed_users": (list, False, [], "Allowed user IDs"),
    },
    "slack": {
        "enabled": (bool, False, False, "Enable Slack channel"),
        "bot_token": (str, False, "", "Slack bot OAuth token"),
        "app_token": (str, False, "", "Slack app-level token"),
    },
    "whatsapp": {
        "enabled": (bool, False, False, "Enable WhatsApp channel"),
        "phone_number_id": (str, False, "", "WhatsApp phone number ID"),
        "access_token": (str, False, "", "WhatsApp access token"),
    },
    "budget": {
        "enabled": (bool, False, False, "Enable budget tracking"),
        "daily_limit_usd": (float, False, 5.0, "Daily spending limit in USD"),
        "model_routing": (str, False, "quality", "Routing strategy: quality or budget"),
    },
    "gateway": {
        "bind": (str, False, "loopback", "Bind mode: loopback, lan, tailnet"),
        "auth_mode": (str, False, "token", "Auth mode: none, token, password"),
        "tls_enabled": (bool, False, False, "Enable TLS"),
        "tls_cert": (str, False, "", "TLS certificate path"),
        "tls_key": (str, False, "", "TLS key path"),
    },
    "sandbox": {
        "enabled": (bool, False, False, "Enable sandbox for exec"),
        "runtime": (str, False, "docker", "Sandbox runtime: docker or podman"),
        "workspace_only": (bool, False, True, "Restrict file access to workspace"),
    },
    "failover": {
        "enabled": (bool, False, True, "Enable model failover"),
        "max_retries": (int, False, 3, "Max retry attempts"),
        "fallback_models": (list, False, [], "Fallback model IDs"),
    },
}


@dataclass_or_dict
class ValidationIssue:
    path: str
    message: str
    severity: str  # "error", "warning"


def validate_config(config: Dict, schema: Dict = None, path: str = "") -> List[Dict]:
    """
    Validate a config dict against the schema.

    Returns list of issues: [{"path": "key.subkey", "message": "...", "severity": "error|warning"}]
    """
    if schema is None:
        schema = SCHEMA

    issues = []

    for key, spec in schema.items():
        full_path = f"{path}.{key}" if path else key

        if isinstance(spec, dict):
            # Nested section
            sub_config = config.get(key, {})
            if not isinstance(sub_config, dict):
                issues.append({
                    "path": full_path,
                    "message": f"Expected dict, got {type(sub_config).__name__}",
                    "severity": "error",
                })
                continue
            issues.extend(validate_config(sub_config, spec, full_path))
            continue

        expected_type, required, default, description = spec[:4]
        value = config.get(key)

        if value is None:
            if required:
                issues.append({
                    "path": full_path,
                    "message": f"Required field missing (expected {expected_type.__name__})",
                    "severity": "error",
                })
            continue

        # Type check
        if not isinstance(value, expected_type):
            # Allow int for float fields
            if expected_type == float and isinstance(value, int):
                continue
            issues.append({
                "path": full_path,
                "message": f"Expected {expected_type.__name__}, got {type(value).__name__}: {repr(value)[:50]}",
                "severity": "error",
            })

    # Check for unknown keys
    for key in config:
        full_path = f"{path}.{key}" if path else key
        if key not in schema:
            issues.append({
                "path": full_path,
                "message": f"Unknown config key",
                "severity": "warning",
            })

    return issues


# ─── Config Migration ──────────────────────────────────────────────

MIGRATIONS = [
    # (old_path, new_path, transform_fn)
    ("max_completion_tokens", "max_tokens", None),
    ("telegram_token", "telegram.token", None),
    ("discord_token", "discord.token", None),
    ("budget_mode", "budget.model_routing", lambda v: "budget" if v else "quality"),
]


def migrate_config(config: Dict) -> Tuple[Dict, List[str]]:
    """
    Apply migrations to update old config format to current.

    Returns (migrated_config, list_of_changes).
    """
    import copy
    migrated = copy.deepcopy(config)
    changes = []

    for old_path, new_path, transform in MIGRATIONS:
        old_keys = old_path.split(".")
        new_keys = new_path.split(".")

        # Check if old key exists
        val = migrated
        found = True
        for k in old_keys:
            if isinstance(val, dict) and k in val:
                val = val[k]
            else:
                found = False
                break

        if not found:
            continue

        # Apply transform
        if transform:
            val = transform(val)

        # Set new key
        target = migrated
        for k in new_keys[:-1]:
            if k not in target:
                target[k] = {}
            target = target[k]
        target[new_keys[-1]] = val

        # Remove old key
        target = migrated
        for k in old_keys[:-1]:
            target = target.get(k, {})
        if old_keys[-1] in target:
            del target[old_keys[-1]]

        changes.append(f"Migrated {old_path} -> {new_path}")

    return migrated, changes


# Fix: can't use @dataclass without import
def dataclass_or_dict(cls):
    """Passthrough — issues are plain dicts."""
    return cls
