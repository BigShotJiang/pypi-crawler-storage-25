"""
Seraph Skills Guard — security scanner for external skills.

Scans skill files for dangerous patterns before installation:
- Data exfiltration (sending data to external servers)
- Prompt injection (overriding system behavior)
- Destructive commands (rm -rf, format, DROP TABLE)
- Credential theft (reading .env, tokens, keys)
- Persistence (cron, startup scripts, backdoors)
- Obfuscation (base64 encoded payloads, eval)

Better than Hermes's guard: we also check for supply chain attacks
(dependency confusion, typosquatting) and have a trust scoring system.
"""

import re
import hashlib
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Tuple, Optional
from datetime import datetime, timezone

logger = logging.getLogger("seraph.skills.guard")


@dataclass
class Finding:
    pattern_id: str
    severity: str       # critical, high, medium, low
    category: str       # exfiltration, injection, destructive, credential, persistence, obfuscation
    file: str
    line: int
    match: str
    description: str


@dataclass
class ScanResult:
    skill_name: str
    source: str         # builtin, trusted, community, unknown
    verdict: str        # safe, caution, dangerous
    trust_score: int    # 0-100
    findings: List[Finding] = field(default_factory=list)
    files_scanned: int = 0
    scanned_at: str = ""


# Trust levels and install policy
TRUSTED_SOURCES = {"seraph/official", "openai/skills", "anthropic/skills"}

INSTALL_POLICY = {
    #                  safe      caution    dangerous
    "builtin":       ("allow",  "allow",   "allow"),
    "trusted":       ("allow",  "allow",   "block"),
    "community":     ("allow",  "block",   "block"),
    "unknown":       ("block",  "block",   "block"),
}


# Threat patterns: (regex, pattern_id, severity, category, description)
THREAT_PATTERNS = [
    # Exfiltration
    (r"requests\.post\s*\(.*(?:api_key|token|password|secret)", "exfil-credentials", "critical", "exfiltration", "Sending credentials to external server"),
    (r"urllib\.request\.urlopen.*(?:env|key|token|secret)", "exfil-urllib", "critical", "exfiltration", "URL request with sensitive data"),
    (r"httpx?\.(post|put)\s*\(.*(?:\.env|credentials|auth)", "exfil-http", "critical", "exfiltration", "HTTP request with auth data"),
    (r"subprocess.*curl.*-d.*(?:key|token|password)", "exfil-curl", "critical", "exfiltration", "Curl posting sensitive data"),
    (r"webhook\.site|requestbin|pipedream\.net|hookbin", "exfil-webhook", "high", "exfiltration", "Data exfiltration webhook service"),
    (r"ngrok\.io|localtunnel|serveo\.net", "exfil-tunnel", "high", "exfiltration", "Tunnel service (potential exfiltration)"),

    # Prompt injection
    (r"ignore.*previous.*instructions", "inject-ignore", "critical", "injection", "Prompt injection: ignore previous instructions"),
    (r"you are now|new role|forget everything", "inject-role", "critical", "injection", "Prompt injection: role override"),
    (r"system:\s*you (must|should|will|are)", "inject-system", "high", "injection", "System prompt injection attempt"),
    (r"<\|im_start\|>|<\|im_end\|>", "inject-markers", "critical", "injection", "ChatML injection markers"),

    # Destructive
    (r"rm\s+-rf\s+/", "destruct-rm-root", "critical", "destructive", "Recursive delete from root"),
    (r"shutil\.rmtree\s*\(\s*['\"/]", "destruct-rmtree", "critical", "destructive", "Python recursive delete"),
    (r"DROP\s+TABLE|DROP\s+DATABASE|TRUNCATE\s+TABLE", "destruct-sql", "critical", "destructive", "SQL destructive operation"),
    (r"format\s+[a-zA-Z]:|mkfs\.", "destruct-format", "critical", "destructive", "Disk format command"),
    (r"os\.system\s*\(\s*['\"].*rm\s", "destruct-os-rm", "high", "destructive", "OS command with rm"),

    # Credential theft
    (r"open\s*\(.*\.env", "cred-env", "high", "credential", "Reading .env file"),
    (r"os\.environ\[.*(?:KEY|TOKEN|SECRET|PASSWORD)", "cred-environ", "medium", "credential", "Accessing sensitive env vars"),
    (r"keyring|gnome-keyring|security\s+find-generic", "cred-keyring", "high", "credential", "Accessing system keyring"),
    (r"/etc/shadow|/etc/passwd", "cred-system", "critical", "credential", "Accessing system credentials"),
    (r"\.ssh/id_rsa|\.ssh/authorized_keys", "cred-ssh", "critical", "credential", "Accessing SSH keys"),
    (r"\.aws/credentials|\.gcloud/|\.azure/", "cred-cloud", "critical", "credential", "Accessing cloud credentials"),

    # Persistence
    (r"crontab|/etc/cron\.", "persist-cron", "high", "persistence", "Cron job installation"),
    (r"systemctl\s+(enable|start)|launchctl\s+load", "persist-service", "high", "persistence", "Service installation"),
    (r"\.bashrc|\.zshrc|\.profile|\.bash_profile", "persist-shell", "medium", "persistence", "Shell profile modification"),
    (r"HKEY_|RegSetValue|winreg", "persist-registry", "high", "persistence", "Windows registry modification"),
    (r"startup\s+folder|shell:startup", "persist-startup", "high", "persistence", "Startup folder manipulation"),

    # Obfuscation
    (r"eval\s*\(.*base64", "obfusc-eval-b64", "critical", "obfuscation", "Eval with base64 (hidden payload)"),
    (r"exec\s*\(.*decode\s*\(", "obfusc-exec-decode", "critical", "obfuscation", "Exec with decoded content"),
    (r"__import__\s*\(", "obfusc-import", "medium", "obfuscation", "Dynamic import (hiding imports)"),
    (r"compile\s*\(.*exec", "obfusc-compile", "high", "obfuscation", "Dynamic code compilation"),
    (r"\\x[0-9a-fA-F]{2}\\x[0-9a-fA-F]{2}\\x", "obfusc-hex", "medium", "obfuscation", "Hex-encoded strings"),

    # Network
    (r"socket\.socket.*SOCK_RAW", "net-raw-socket", "critical", "network", "Raw socket access"),
    (r"paramiko|fabric|netmiko", "net-ssh-lib", "medium", "network", "SSH library usage"),
    (r"scapy|nmap|masscan", "net-scanner", "high", "network", "Network scanning tool"),
]

# Compiled patterns
_COMPILED = [(re.compile(p, re.IGNORECASE), pid, sev, cat, desc) for p, pid, sev, cat, desc in THREAT_PATTERNS]


def scan_file(filepath: Path, source: str = "unknown") -> List[Finding]:
    """Scan a single file for threats."""
    findings = []
    try:
        content = filepath.read_text(encoding="utf-8", errors="replace")
        lines = content.splitlines()

        for i, line in enumerate(lines, 1):
            for pattern, pid, severity, category, description in _COMPILED:
                match = pattern.search(line)
                if match:
                    findings.append(Finding(
                        pattern_id=pid,
                        severity=severity,
                        category=category,
                        file=str(filepath.name),
                        line=i,
                        match=match.group()[:100],
                        description=description,
                    ))
    except Exception as e:
        logger.error(f"Failed to scan {filepath}: {e}")

    return findings


def scan_skill(skill_dir: Path, source: str = "community") -> ScanResult:
    """
    Scan an entire skill directory for threats.

    Returns a ScanResult with verdict: safe, caution, or dangerous.
    """
    skill_name = skill_dir.name
    all_findings = []
    files_scanned = 0

    # Scan all text files in the skill directory
    scannable = {".py", ".js", ".ts", ".sh", ".md", ".yaml", ".yml", ".json", ".txt", ".toml"}
    for f in skill_dir.rglob("*"):
        if f.is_file() and f.suffix.lower() in scannable:
            findings = scan_file(f, source)
            all_findings.extend(findings)
            files_scanned += 1

    # Determine verdict
    has_critical = any(f.severity == "critical" for f in all_findings)
    has_high = any(f.severity == "high" for f in all_findings)
    has_medium = any(f.severity == "medium" for f in all_findings)

    if has_critical:
        verdict = "dangerous"
    elif has_high:
        verdict = "caution"
    elif has_medium and len(all_findings) >= 3:
        verdict = "caution"
    else:
        verdict = "safe"

    # Trust score: 100 = perfect, 0 = dangerous
    trust_score = 100
    for f in all_findings:
        if f.severity == "critical":
            trust_score -= 30
        elif f.severity == "high":
            trust_score -= 15
        elif f.severity == "medium":
            trust_score -= 5
        elif f.severity == "low":
            trust_score -= 1
    trust_score = max(0, trust_score)

    return ScanResult(
        skill_name=skill_name,
        source=source,
        verdict=verdict,
        trust_score=trust_score,
        findings=all_findings,
        files_scanned=files_scanned,
        scanned_at=datetime.now(timezone.utc).isoformat(),
    )


def should_allow_install(result: ScanResult) -> Tuple[bool, str]:
    """Check if a skill should be allowed to install based on scan result and source trust."""
    source = result.source if result.source in INSTALL_POLICY else "unknown"
    policy = INSTALL_POLICY[source]

    verdict_idx = {"safe": 0, "caution": 1, "dangerous": 2}.get(result.verdict, 2)
    action = policy[verdict_idx]

    if action == "allow":
        return True, f"Allowed ({result.source}/{result.verdict})"
    elif action == "block":
        return False, f"Blocked: {result.verdict} skill from {result.source} source. {len(result.findings)} issues found."
    else:
        return False, f"Requires manual approval: {result.verdict} from {result.source}"


def format_scan_report(result: ScanResult) -> str:
    """Format a scan result as a readable report."""
    lines = [
        f"Skill Scan: {result.skill_name}",
        f"Source: {result.source} | Verdict: {result.verdict} | Trust: {result.trust_score}/100",
        f"Files: {result.files_scanned} | Findings: {len(result.findings)}",
        "",
    ]

    if result.findings:
        for f in result.findings:
            lines.append(f"  [{f.severity.upper()}] {f.category}: {f.description}")
            lines.append(f"    {f.file}:{f.line} — {f.match}")
        lines.append("")

    allowed, reason = should_allow_install(result)
    lines.append(f"Decision: {reason}")

    return "\n".join(lines)
