"""
Seraph Skill Marketplace — browse, install, publish, and rate skills.

Skills are hosted on GitHub or a central registry.
Each skill has: name, description, author, version, rating, install count.

Registry format (JSON):
{
    "skills": [
        {
            "name": "web-scraper",
            "description": "Scrape any website and extract structured data",
            "author": "bosskalash",
            "version": "1.0.0",
            "repo": "https://github.com/bosskalash/seraph-skill-web-scraper",
            "downloads": 1234,
            "rating": 4.5,
            "verified": true
        }
    ]
}
"""

import json
import time
import logging
import os
import subprocess
import requests
from typing import Dict, List, Optional
from pathlib import Path

logger = logging.getLogger("seraph.marketplace")

SERAPH_DIR = Path.home() / ".seraph"
SKILLS_DIR = SERAPH_DIR / "skills"
REGISTRY_CACHE = SERAPH_DIR / "marketplace_cache.json"
REGISTRY_URL = os.environ.get("SERAPH_REGISTRY_URL", "https://registry.seraph.so/api/v1/skills")
CACHE_TTL = 3600  # 1 hour


def fetch_registry(force: bool = False) -> List[Dict]:
    """Fetch the skill registry, with caching."""
    # Check cache first
    if not force and REGISTRY_CACHE.exists():
        try:
            with open(REGISTRY_CACHE) as f:
                data = json.load(f)
            if time.time() - data.get("fetched_at", 0) < CACHE_TTL:
                return data.get("skills", [])
        except Exception:
            pass

    # Fetch from registry
    try:
        resp = requests.get(REGISTRY_URL, timeout=10)
        if resp.status_code == 200:
            data = resp.json()
            skills = data.get("skills", [])
            # Cache it
            cache = {"skills": skills, "fetched_at": time.time()}
            SERAPH_DIR.mkdir(parents=True, exist_ok=True)
            tmp = str(REGISTRY_CACHE) + ".tmp"
            with open(tmp, "w") as f:
                json.dump(cache, f)
            os.replace(tmp, str(REGISTRY_CACHE))
            return skills
    except Exception as e:
        logger.warning(f"Registry fetch failed: {e}")

    # Fallback to cache even if stale
    if REGISTRY_CACHE.exists():
        try:
            with open(REGISTRY_CACHE) as f:
                return json.load(f).get("skills", [])
        except Exception:
            pass

    return []


def search_skills(query: str) -> List[Dict]:
    """Search the marketplace for skills."""
    skills = fetch_registry()
    query_lower = query.lower()
    results = []
    for skill in skills:
        name = skill.get("name", "").lower()
        desc = skill.get("description", "").lower()
        tags = " ".join(skill.get("tags", [])).lower()
        if query_lower in name or query_lower in desc or query_lower in tags:
            results.append(skill)
    return sorted(results, key=lambda s: -s.get("downloads", 0))


def install_skill(name_or_url: str) -> Dict:
    """Install a skill from the marketplace or a direct URL."""
    SKILLS_DIR.mkdir(parents=True, exist_ok=True)

    # Direct git URL
    if name_or_url.startswith("http") and (".git" in name_or_url or "github.com" in name_or_url):
        return _install_from_git(name_or_url)

    # Search registry for the skill
    skills = fetch_registry()
    skill = next((s for s in skills if s.get("name") == name_or_url), None)
    if not skill:
        return {"error": f"Skill '{name_or_url}' not found in marketplace"}

    repo = skill.get("repo", "")
    if not repo:
        return {"error": f"Skill '{name_or_url}' has no repository URL"}

    result = _install_from_git(repo)
    if "error" not in result:
        result["marketplace"] = True
        result["version"] = skill.get("version", "")
        result["author"] = skill.get("author", "")
    return result


def _install_from_git(url: str) -> Dict:
    """Clone a skill from a git URL."""
    # Extract name from URL
    name = url.rstrip("/").split("/")[-1].replace(".git", "")
    if name.startswith("seraph-skill-"):
        name = name[13:]  # Strip prefix

    dest = SKILLS_DIR / name
    if dest.exists():
        # Update existing
        try:
            subprocess.run(["git", "-C", str(dest), "pull"], capture_output=True, timeout=30)
            return {"installed": name, "path": str(dest), "action": "updated"}
        except Exception as e:
            return {"error": f"Failed to update {name}: {e}"}

    try:
        result = subprocess.run(
            ["git", "clone", "--depth", "1", url, str(dest)],
            capture_output=True, text=True, timeout=60,
        )
        if result.returncode == 0:
            # Verify it has SKILL.md
            if not (dest / "SKILL.md").exists():
                return {"installed": name, "path": str(dest), "warning": "No SKILL.md found"}
            return {"installed": name, "path": str(dest), "action": "installed"}
        else:
            return {"error": f"Git clone failed: {result.stderr[:200]}"}
    except Exception as e:
        return {"error": str(e)}


def uninstall_skill(name: str) -> Dict:
    """Remove an installed skill."""
    dest = SKILLS_DIR / name
    if not dest.exists():
        return {"error": f"Skill '{name}' not installed"}

    import shutil
    shutil.rmtree(dest)
    return {"uninstalled": name}


def list_installed() -> List[Dict]:
    """List all installed skills."""
    SKILLS_DIR.mkdir(parents=True, exist_ok=True)
    skills = []
    for d in sorted(SKILLS_DIR.iterdir()):
        if d.is_dir() and (d / "SKILL.md").exists():
            # Read first line of SKILL.md for description
            desc = ""
            try:
                content = (d / "SKILL.md").read_text(encoding="utf-8", errors="replace")
                for line in content.split("\n"):
                    if line.strip() and not line.startswith("#") and not line.startswith("---"):
                        desc = line.strip()[:100]
                        break
            except Exception:
                pass
            skills.append({
                "name": d.name,
                "path": str(d),
                "description": desc,
                "has_json": (d / "skill.json").exists(),
            })
    return skills


def publish_skill(name: str, repo_url: str) -> Dict:
    """Publish a skill to the marketplace (requires auth)."""
    api_key = os.environ.get("SERAPH_REGISTRY_KEY", "")
    if not api_key:
        return {"error": "Set SERAPH_REGISTRY_KEY to publish skills"}

    skill_dir = SKILLS_DIR / name
    if not skill_dir.exists():
        return {"error": f"Skill '{name}' not found locally"}

    # Read skill metadata
    metadata = {"name": name, "repo": repo_url}
    skill_md = skill_dir / "SKILL.md"
    if skill_md.exists():
        content = skill_md.read_text(encoding="utf-8", errors="replace")
        for line in content.split("\n"):
            if line.strip() and not line.startswith("#") and not line.startswith("---"):
                metadata["description"] = line.strip()[:200]
                break

    try:
        resp = requests.post(
            REGISTRY_URL,
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
            json=metadata,
            timeout=15,
        )
        if resp.status_code in (200, 201):
            return {"published": name, "url": repo_url}
        else:
            return {"error": f"Registry error {resp.status_code}: {resp.text[:200]}"}
    except Exception as e:
        return {"error": str(e)}
