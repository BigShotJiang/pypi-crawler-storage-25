"""
Seraph Skill Generator — auto-creates reusable skills from experience.

When the agent solves a complex task, it can extract the procedure into a
reusable skill document. Next time a similar task comes up, it loads the
skill instead of figuring it out from scratch.

This is the Karpathy "auto-research" loop applied to agent skills.
"""

import json
import logging
import time
from pathlib import Path
from typing import Optional, Dict, List

logger = logging.getLogger("seraph.skills")

SKILLS_DIR = Path.home() / ".seraph" / "skills"


def load_all_skills() -> List[Dict]:
    """Load all installed skills."""
    SKILLS_DIR.mkdir(parents=True, exist_ok=True)
    skills = []
    for skill_dir in SKILLS_DIR.iterdir():
        if skill_dir.is_dir():
            skill_file = skill_dir / "SKILL.md"
            if skill_file.exists():
                content = skill_file.read_text()
                # Parse frontmatter
                name = skill_dir.name
                description = ""
                if content.startswith("---"):
                    end = content.find("---", 3)
                    if end > 0:
                        frontmatter = content[3:end].strip()
                        for line in frontmatter.split("\n"):
                            if line.startswith("description:"):
                                description = line.split(":", 1)[1].strip()
                            elif line.startswith("name:"):
                                name = line.split(":", 1)[1].strip()

                skills.append({
                    "name": name,
                    "description": description,
                    "path": str(skill_file),
                    "content": content,
                    "size": len(content),
                })
    return skills


def get_skill(name: str) -> Optional[Dict]:
    """Get a specific skill by name."""
    skill_path = SKILLS_DIR / name / "SKILL.md"
    if skill_path.exists():
        return {
            "name": name,
            "content": skill_path.read_text(),
            "path": str(skill_path),
        }
    return None


def create_skill(name: str, description: str, content: str) -> Dict:
    """Create a new skill from content."""
    skill_dir = SKILLS_DIR / name
    skill_dir.mkdir(parents=True, exist_ok=True)

    skill_content = f"""---
name: {name}
description: {description}
created: {time.strftime('%Y-%m-%d %H:%M:%S UTC', time.gmtime())}
auto_generated: true
---

{content}
"""

    skill_file = skill_dir / "SKILL.md"
    skill_file.write_text(skill_content)
    logger.info(f"Created skill: {name} ({len(content)} chars)")

    return {
        "name": name,
        "path": str(skill_file),
        "size": len(skill_content),
        "status": "created",
    }


def generate_skill_from_conversation(messages: List[Dict], llm=None) -> Optional[Dict]:
    """
    Analyze a conversation and generate a reusable skill if the task was complex enough.

    This is the auto-learning loop:
    1. Look at what the agent just did
    2. If it was multi-step and non-trivial, extract the procedure
    3. Save it as a skill for future use
    """
    if not llm or len(messages) < 6:
        return None

    # Build context from recent conversation
    context = ""
    for m in messages[-20:]:
        role = m.get("role", "?")
        content = m.get("content", "")
        if isinstance(content, str) and len(content) > 10:
            context += f"[{role}]: {content[:300]}\n"

    prompt = f"""Analyze this conversation and determine if the agent performed a reusable multi-step task.

If YES — extract a skill document with:
1. A clear name (kebab-case, e.g. "deploy-nextjs-site")
2. A one-line description
3. Step-by-step procedure that could be followed next time
4. Any important notes or gotchas

If NO — the conversation was just chat or a one-off question, respond with just "NO_SKILL".

Conversation:
{context}

Respond in this format ONLY if a skill should be created:
SKILL_NAME: name-here
SKILL_DESCRIPTION: one line description
SKILL_CONTENT:
## Steps
1. ...
2. ...
"""

    try:
        response = llm.chat(
            messages=[{"role": "user", "content": prompt}],
            system="You extract reusable procedures from conversations. Be concise and practical.",
        )

        text = response.text.strip()
        if "NO_SKILL" in text:
            return None

        # Parse the response
        lines = text.split("\n")
        name = ""
        description = ""
        content_lines = []
        in_content = False

        for line in lines:
            if line.startswith("SKILL_NAME:"):
                name = line.split(":", 1)[1].strip()
            elif line.startswith("SKILL_DESCRIPTION:"):
                description = line.split(":", 1)[1].strip()
            elif line.startswith("SKILL_CONTENT:"):
                in_content = True
            elif in_content:
                content_lines.append(line)

        if name and content_lines:
            content = "\n".join(content_lines).strip()
            return create_skill(name, description, content)

    except Exception as e:
        logger.error(f"Skill generation failed: {e}")

    return None


def find_matching_skill(query: str, skills: List[Dict] = None) -> Optional[Dict]:
    """Find a skill that matches a query/task description."""
    if skills is None:
        skills = load_all_skills()

    query_lower = query.lower()
    for skill in skills:
        # Simple keyword matching — could be upgraded to semantic search
        name_match = any(word in skill["name"].lower() for word in query_lower.split())
        desc_match = any(word in skill.get("description", "").lower() for word in query_lower.split())
        if name_match or desc_match:
            return skill

    return None
