# Seraph

**The AI agent that audits itself.**

Self-improving, self-auditing, multi-channel AI agent platform. 45 tools, 22 channels, runs everywhere.

## Why Seraph?

| | OpenClaw | Hermes | Seraph |
|--|----------|--------|--------|
| Self-improving | No | Yes | **Yes** |
| Self-auditing | No | No | **Yes** |
| Anti-dilution | No | No | **Yes** |
| Windows native | Clunky | No (WSL) | **Yes** |
| Channels | 22 | 16 | **22** |
| Tools | ~30 | 48 | **45** |
| Models | ~10 | 200+ | **200+** |
| Memory | SQLite | SQLite+FTS5 | **SQLite+FTS5** |
| Skills guard | No | Regex | **Regex + trust scoring** |
| Smart routing | No | Yes | **Yes + failover + pool** |
| Canvas | Electron | No | **Web (any browser)** |
| Companion app | Native | No | **PWA (all platforms)** |

## Install

**Quick start (pip):**
```bash
pip install seraph-agent
seraph onboard
```

**From source:**
```bash
git clone https://github.com/bosskalash/seraph.git
cd seraph
pip install -e ".[all]"
python3 brain/cli.py onboard
```

**Docker:**
```bash
git clone https://github.com/bosskalash/seraph.git
cd seraph
cp .env.example .env  # edit with your keys
docker compose up -d
```

**Manual:**
```bash
git clone https://github.com/bosskalash/seraph.git ~/seraph
cd ~/seraph
pip install requests flask pyyaml openai
# Edit .env with your API keys
python3 run.py
```

## Setup

1. Get an API key from [OpenAI](https://platform.openai.com) or [Anthropic](https://console.anthropic.com)
2. Get a Telegram bot token from [@BotFather](https://t.me/BotFather)
3. Run `seraph onboard` or edit `.env`:
```env
SERAPH_PROVIDER=openai
SERAPH_MODEL=gpt-5.4
OPENAI_API_KEY=your-key-here
SERAPH_TELEGRAM_TOKEN=your-bot-token
SERAPH_ALLOWED_USERS=your-telegram-id
```
4. Run: `python3 run.py`
5. Message your bot on Telegram

## 45 Built-in Tools

| Category | Tools |
|----------|-------|
| **Core** | terminal, read_file, write_file, list_files, clipboard |
| **Web** | web_search, web_fetch, browse (headless) |
| **Code** | run_code (sandbox), apply_patch, audit_file, audit_directory |
| **AI** | describe_image (vision), mixture_of_agents, delegate_task, verify_claim |
| **Media** | generate_image (DALL-E), text_to_speech, transcribe, voice_respond |
| **Comms** | send_email, notify, manage_webhook, send_notification |
| **Data** | query_sqlite, export_conversation, export_html, search_sessions |
| **DevOps** | ssh, git, git_clone, import_api (OpenAPI), health_check |
| **Smart Home** | homeassistant |
| **Workflow** | todo, checkpoint, clarify, request_approval, interrupt, progress |
| **Skills** | skills_hub (install/search/sync), fuzzy_find, mcp (Model Context Protocol) |
| **Meta** | canvas (visual workspace), qr_code, usage_stats |

## 22 Channels

| Channel | Protocol | Status |
|---------|----------|--------|
| Telegram | Bot API | Production |
| Discord | Gateway WS | Ready |
| Slack | Socket Mode | Ready |
| WhatsApp | Cloud API | Ready |
| Signal | signal-cli REST | Ready |
| Matrix | Client-Server | Ready |
| Email | IMAP + SMTP | Ready |
| SMS | Twilio | Ready |
| IRC | Raw socket | Ready |
| MS Teams | Bot Framework | Ready |
| Google Chat | Webhook API | Ready |
| LINE | Messaging API | Ready |
| Mattermost | REST API | Ready |
| Twitch | IRC over SSL | Ready |
| Nostr | Relay protocol | Ready |
| DingTalk | Robot API | Ready |
| Feishu/Lark | Open API | Ready |
| iMessage | BlueBubbles | Ready |
| WebChat | HTTP server | Ready |
| Canvas | Visual workspace | Ready |
| Voice Wake | Mic + wake word | Ready |
| PWA | Progressive Web App | Ready |

## 40+ Slash Commands

```
/new         Fresh conversation         /improve     Self-improvement cycle
/model       View or change model       /cron        Manage scheduled jobs
/status      System status              /heartbeat   Health monitor
/tools       List available tools       /doctor      Run diagnostics
/exec        Run a shell command        /approve     DM pairing approval
/search      Search the web             /think       Set reasoning level
/read        Read a file                /insights    Conversation analytics
/files       List workspace files       /update      Pull latest from git
/memory      Memory status              /restart     Restart the bot
/remember    Save a fact                /backup      Backup all data
/forget      Remove a fact              /logs        View recent logs
/recall      Search past conversations  /budget      Daily spending limit
/persona     Switch personality         /template    Prompt templates
/raw         Direct LLM (zero overhead) /config      View/change settings
/sandbox     Run Python code            /compress    Smart compress
/branch      Fork conversation          /retry       Retry last response
/undo        Undo last exchange         /send        Send a file
/checkpoint  Save conversation state    /id          Show Telegram ID
/restore     Restore a checkpoint       /help        Show all commands
```

## Architecture

```
User (Telegram/Discord/Slack/22 channels)
  |
  v
Gateway (Go) -- HTTP proxy, health, routing
  |
  v
Brain (Python) -- LLM reasoning + 45 tools
  |
  v
SQLite -- memory (FTS5), sessions, skills, rules
  |
  v
Canvas / PWA -- visual workspace + mobile app
```

## What Makes Seraph Different

### Anti-Dilution Engine
Other platforms waste 30-50% of context on bloated system prompts. Seraph has:
- **Smart tool filtering** -- only sends relevant tools per message
- **Prompt compiler** -- minifies, deduplicates, strips decorations
- **Context budget** -- system overhead capped at 20%
- **Lazy injection** -- memory only loaded when conversation needs it
- **`/raw` mode** -- zero injection, direct LLM access

### Self-Improvement Loop
The agent improves itself over time:
- Reviews conversations for user corrections
- Stores lessons in active memory
- Auto-generates reusable skills from complex tasks
- Self-audits its own code for bugs
- Runs on cron (every 6h) or manual (`/improve`)

### Skills Guard
Every external skill is security-scanned before installation:
- 30+ threat patterns (exfiltration, injection, destructive, credential theft)
- Trust scoring (0-100)
- Install policy by source (builtin/trusted/community)

### Canvas
Live visual workspace at `http://localhost:18803/canvas`. The agent can push HTML, code, tables, charts, and run JavaScript in your browser.

### Model Router
- **Smart routing** -- simple questions use cheap model, complex use strong
- **Failover chain** -- auto-switch when a model is down
- **Credential pool** -- rotate API keys with exponential backoff

## Configuration

### YAML Config (`~/.seraph/config.yaml`)
```yaml
model: gpt-5.4
provider: openai
memory:
  enabled: true
skills:
  auto_generate: true
audit:
  enabled: true
  max_rounds: 5
```

### Identity (`~/.seraph/SOUL.md`)
Customize who your agent is. Injected into every prompt.

### MCP Servers (`~/.seraph/mcp.json`)
```json
{
  "mcpServers": {
    "context7": {
      "command": "npx",
      "args": ["-y", "@upstash/context7-mcp"]
    }
  }
}
```

### Supported Models
- OpenAI: gpt-5.4, gpt-4.1, gpt-4o, gpt-4o-mini
- Anthropic: claude-opus-4-6, claude-sonnet-4-6, claude-haiku-4-5
- OpenRouter: 200+ models via one API key

## Testing

```bash
pip install -e ".[dev]"
python -m pytest tests/ -v
```

## License

MIT
