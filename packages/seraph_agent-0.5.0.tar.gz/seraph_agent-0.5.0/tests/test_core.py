"""Tests for core modules — compaction, failover, sessions, secrets, security."""
import sys, os, time, json, tempfile
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent / "brain"))


def test_compaction():
    from agent.compaction import estimate_tokens, needs_compaction, split_messages_for_compaction
    assert estimate_tokens("hello world") > 0
    msgs = [{"role": "user", "content": "x" * 400}] * 50
    assert needs_compaction(msgs, 8000)
    assert not needs_compaction(msgs, 200000)
    to_sum, to_keep = split_messages_for_compaction(msgs, 8000)
    assert len(to_keep) >= 4


def test_failover_classification():
    from agent.failover import classify_error
    assert classify_error("rate_limit_exceeded", 429) == "rate_limit"
    assert classify_error("unauthorized", 401) == "auth_error"
    assert classify_error("context_length_exceeded", 400) == "context_overflow"
    assert classify_error("exceeded your current quota", 402) == "billing_error"
    assert classify_error("connection timeout", 0) == "timeout"


def test_session_store():
    from sessions.store import SessionStore
    db = Path(tempfile.mktemp(suffix=".db"))
    store = SessionStore(db_path=db)
    store.create_session("test-1", title="Test")
    store.add_message("test-1", "user", "hello", tokens=5)
    store.add_message("test-1", "assistant", "hi", tokens=3)
    s = store.get_session("test-1")
    assert s["message_count"] == 2
    msgs = store.get_messages("test-1")
    assert len(msgs) == 2
    results = store.search("hello")
    assert len(results) >= 1
    db.unlink()


def test_secrets_manager():
    from secrets.manager import SecretsManager
    sm = SecretsManager()
    snap = sm.resolve()
    assert not snap.is_degraded


def test_ssrf_guard():
    from agent.ssrf_guard import check_url
    from agent.link_understanding import is_safe_url
    assert check_url("http://127.0.0.1:8080") is not None  # Blocked
    assert check_url("http://169.254.169.254/metadata") is not None  # Blocked
    assert check_url("https://api.openai.com/v1") is None  # Allowed
    assert not is_safe_url("http://localhost/admin")


def test_context_anchors():
    from agent.context_anchors import AnchorStore
    store = AnchorStore()
    store.add("Never modify API keys", source="user", priority=100, category="rule")
    anchors = store.get_all()
    assert len(anchors) >= 1
    prompt = store.format_for_prompt()
    assert "Never modify API keys" in prompt


def test_cost_router():
    from agent.cost_router import analyze_complexity, CostAwareRouter
    assert analyze_complexity("hi") == "trivial"
    result = analyze_complexity("review this 500 line codebase and refactor the architecture")
    assert result in ("complex", "expert"), f"Expected complex/expert, got {result}"
    router = CostAwareRouter(daily_budget=5.0)
    decision = router.route("hi")
    assert decision.complexity == "trivial"


def test_confidence():
    from agent.confidence import assess_confidence
    high = assess_confidence("The error is on line 45. The function returns None because the variable is undefined.")
    assert high.score >= 0.5
    low = assess_confidence("I think it might be possible that perhaps this could work, but I'm not sure.")
    assert low.score < high.score


def test_markdown_chunks():
    from agent.markdown_chunks import chunk_with_balanced_fences, is_inside_fence
    assert not is_inside_fence("hello")
    assert is_inside_fence("```python\nprint('hi')")
    long_text = "\n".join(["Line " + str(i) + " " + "x" * 80 for i in range(200)])
    chunks = chunk_with_balanced_fences(long_text, max_length=4000)
    assert len(chunks) >= 2, f"Expected 2+ chunks, got {len(chunks)} for {len(long_text)} chars"


def test_debounce():
    from agent.debounce import MessageDebouncer
    d = MessageDebouncer(window_ms=100)
    assert d.get_pending_count() == 0


def test_i18n():
    from agent.i18n import t, set_user_lang
    assert t("not_authorized") == "You're not authorized to use this bot."
    set_user_lang("123", "es")
    assert "autorización" in t("not_authorized", user_id="123").lower()


if __name__ == "__main__":
    test_compaction()
    test_failover_classification()
    test_session_store()
    test_secrets_manager()
    test_ssrf_guard()
    test_context_anchors()
    test_cost_router()
    test_confidence()
    test_markdown_chunks()
    test_debounce()
    test_i18n()
    print("ALL CORE TESTS PASS")
