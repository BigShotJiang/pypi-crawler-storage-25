"""Tests for Seraph agent modules."""
import sys
import time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "brain"))

import pytest


class TestLoopDetection:
    def test_normal_calls_allowed(self):
        from agent.loop_detection import LoopDetector
        ld = LoopDetector()
        for i in range(4):
            r = ld.record(f"tool_{i}", {"arg": i})
            assert r["action"] == "allow"

    def test_generic_repeat_warning(self):
        from agent.loop_detection import LoopDetector
        ld = LoopDetector()
        for i in range(6):
            r = ld.record("web_search", {"query": "same"})
        assert r["action"] == "warn"

    def test_generic_repeat_break(self):
        from agent.loop_detection import LoopDetector
        ld = LoopDetector()
        for i in range(11):
            r = ld.record("web_search", {"query": "same"})
        assert r["action"] == "break"

    def test_circuit_breaker(self):
        from agent.loop_detection import LoopDetector
        ld = LoopDetector()
        for i in range(31):
            r = ld.record(f"tool_{i % 10}", {"arg": i})
        assert r["action"] == "break"
        assert r["type"] == "circuit_breaker"

    def test_reset(self):
        from agent.loop_detection import LoopDetector
        ld = LoopDetector()
        ld.record("test", {})
        ld.reset()
        assert ld.total_calls == 0


class TestModelRouter:
    def test_classify_simple(self):
        from agent.model_router import ModelRouter
        mr = ModelRouter()
        assert mr.classify_complexity("hi") == "simple"

    def test_classify_complex(self):
        from agent.model_router import ModelRouter
        mr = ModelRouter()
        assert mr.classify_complexity("debug this architecture and refactor") == "complex"

    def test_failover(self):
        from agent.model_router import ModelEntry
        entry = ModelEntry(provider="openai", model="test", api_key="k", tier="strong")
        assert entry.is_available()
        entry.record_failure()
        assert not entry.is_available()
        entry.record_success()
        assert entry.error_count == 0


class TestURLSafety:
    def test_normal_url(self):
        from agent.url_safety import check_url
        ok, _ = check_url("https://google.com")
        assert ok

    def test_blocked_domain(self):
        from agent.url_safety import check_url
        ok, _ = check_url("https://grabify.link/abc")
        assert not ok

    def test_blocked_scheme(self):
        from agent.url_safety import check_url
        ok, _ = check_url("javascript:alert(1)")
        assert not ok

    def test_ssrf(self):
        from agent.url_safety import check_url
        ok, _ = check_url("http://127.0.0.1:8080/admin")
        assert not ok

    def test_null_byte(self):
        from agent.url_safety import check_url
        ok, _ = check_url("https://example.com/%00")
        assert not ok


class TestRedact:
    def test_api_key(self):
        from agent.redact import redact
        assert "REDACTED" in redact("sk-abc123def456ghi789jkl012")

    def test_password(self):
        from agent.redact import redact
        assert "REDACTED" in redact('password="mysecret123"')

    def test_dict_redact(self):
        from agent.redact import redact_dict
        d = redact_dict({"api_key": "secret", "name": "David"})
        assert d["api_key"] == "[REDACTED]"
        assert d["name"] == "David"


class TestPromptCompiler:
    def test_minify(self):
        from agent.prompt_compiler import minify
        result = minify("---\nHello\n===\nWorld\n\n\nDuplicate\nDuplicate")
        assert "---" not in result
        assert result.count("Duplicate") == 1

    def test_budget(self):
        from agent.prompt_compiler import enforce_budget
        short = "Hello"
        assert enforce_budget(short, 1000, 128000) == short
        huge = "x " * 50000
        trimmed = enforce_budget(huge, 100000, 128000)
        assert len(trimmed) < len(huge)


class TestContextManager:
    def test_should_compress(self):
        from agent.context_manager import should_compress
        small = [{"role": "user", "content": "hi"}]
        assert not should_compress(small)

    def test_auto_compress(self):
        from agent.context_manager import auto_compress
        msgs = [{"role": "user", "content": f"msg_{i}"} for i in range(25)]
        compressed = auto_compress(msgs, llm=None, target_messages=8)
        assert len(compressed) <= 8


class TestSkillsGuard:
    def test_safe_skill(self):
        import tempfile
        from skills.guard import scan_skill
        d = Path(tempfile.mkdtemp()) / "safe"
        d.mkdir()
        (d / "run.py").write_text('print("hello")')
        result = scan_skill(d)
        assert result.verdict == "safe"
        assert result.trust_score == 100
        import shutil; shutil.rmtree(d.parent)

    def test_dangerous_skill(self):
        import tempfile
        from skills.guard import scan_skill
        d = Path(tempfile.mkdtemp()) / "evil"
        d.mkdir()
        (d / "run.py").write_text('import os; os.system("rm -rf /")')
        result = scan_skill(d)
        assert result.verdict in ("caution", "dangerous")
        assert result.trust_score < 100
        import shutil; shutil.rmtree(d.parent)


class TestDoctor:
    def test_run_doctor(self):
        from agent.doctor import run_doctor
        result = run_doctor()
        assert result["summary"]["total"] >= 5
        assert "checks" in result


class TestPairing:
    def test_pairing_flow(self):
        from agent.pairing import request_pairing, approve_user, is_approved, PAIRING_FILE
        code = request_pairing("test_u", "Test")
        assert len(code) == 6
        assert not is_approved("test_u")
        ok, _ = approve_user(code=code)
        assert ok
        assert is_approved("test_u")
        if PAIRING_FILE.exists():
            PAIRING_FILE.unlink()
