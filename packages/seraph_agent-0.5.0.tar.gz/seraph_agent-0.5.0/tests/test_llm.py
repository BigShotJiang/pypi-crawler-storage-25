"""Tests for LLM provider — provider registry, model detection, response parsing."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent / "brain"))

from agent.llm import (
    LLMProvider, LLMResponse, list_providers, get_provider_for_model,
    ALL_PROVIDERS, OPENAI_COMPATIBLE_PROVIDERS, CUSTOM_PROVIDERS,
)


def test_provider_count():
    """Should have 26+ providers."""
    assert len(ALL_PROVIDERS) >= 26


def test_openai_compatible_count():
    """Should have 20+ OpenAI-compatible providers."""
    assert len(OPENAI_COMPATIBLE_PROVIDERS) >= 20


def test_custom_providers():
    """Custom providers should include anthropic, google, azure, bedrock."""
    for p in ("anthropic", "google", "azure", "bedrock"):
        assert p in CUSTOM_PROVIDERS


def test_provider_auto_detect():
    """Should detect provider from model name."""
    cases = [
        ("gpt-4.1", "openai"),
        ("claude-sonnet-4-6", "anthropic"),
        ("gemini-2.5-pro", "google"),
        ("deepseek-chat", "deepseek"),
        ("grok-3", "xai"),
        ("mistral-large-latest", "mistral"),
    ]
    for model, expected in cases:
        assert get_provider_for_model(model) == expected, f"{model} should detect as {expected}"


def test_list_providers():
    """list_providers should return all providers with metadata."""
    providers = list_providers()
    assert len(providers) >= 26
    for p in providers:
        assert "name" in p
        assert "type" in p
        assert p["type"] in ("openai_compatible", "custom")


def test_llm_response_defaults():
    """LLMResponse should have sane defaults."""
    r = LLMResponse(text="hello")
    assert r.text == "hello"
    assert r.tool_calls == []
    assert r.input_tokens == 0
    assert r.output_tokens == 0


def test_unknown_provider_raises():
    """Should raise for unknown provider."""
    try:
        LLMProvider(provider="nonexistent_provider_xyz", model="test")
        assert False, "Should have raised"
    except ValueError as e:
        assert "Unknown provider" in str(e)


if __name__ == "__main__":
    test_provider_count()
    test_openai_compatible_count()
    test_custom_providers()
    test_provider_auto_detect()
    test_list_providers()
    test_llm_response_defaults()
    test_unknown_provider_raises()
    print("ALL LLM TESTS PASS")
