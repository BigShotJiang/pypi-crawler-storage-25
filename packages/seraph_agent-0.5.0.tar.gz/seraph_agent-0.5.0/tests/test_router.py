"""Tests for model router — routing, failover, usage tracking."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent / "brain"))

from models.router import ModelRouter, MODELS, FailoverChain


def test_model_catalog():
    assert len(MODELS) >= 30


def test_default_route():
    router = ModelRouter("claude-sonnet-4-6")
    assert router.route() == "claude-sonnet-4-6"


def test_failover_chain():
    router = ModelRouter("claude-sonnet-4-6")
    chain = router.get_failover_chain("claude-sonnet-4-6")
    assert chain.models[0] == "claude-sonnet-4-6"
    assert len(chain.models) >= 3


def test_failover_advance():
    chain = FailoverChain(models=["a", "b", "c"])
    assert chain.next() == "a"
    chain.advance("a")
    assert chain.next() == "b"


def test_usage_tracking():
    router = ModelRouter()
    router.track_usage("claude-sonnet-4-6", 1000, 500)
    usage = router.get_usage()
    assert usage["input_tokens"] == 1000
    assert usage["output_tokens"] == 500
    assert usage["cost_usd"] > 0


def test_list_models():
    router = ModelRouter()
    models = router.list_models()
    assert len(models) >= 30
    for m in models:
        assert "id" in m and "provider" in m


def test_list_providers():
    router = ModelRouter()
    providers = router.list_providers()
    assert "anthropic" in providers
    assert "openai" in providers


if __name__ == "__main__":
    test_model_catalog()
    test_default_route()
    test_failover_chain()
    test_failover_advance()
    test_usage_tracking()
    test_list_models()
    test_list_providers()
    print("ALL ROUTER TESTS PASS")
