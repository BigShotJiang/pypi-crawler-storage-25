"""Tests for Seraph tools."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "brain"))

import pytest


class TestToolFilter:
    def test_ssh_keyword(self):
        from tools.filter import filter_tools
        schemas = [{"function": {"name": "ssh"}}, {"function": {"name": "terminal"}}]
        result = filter_tools("ssh into server", schemas)
        names = [s["function"]["name"] for s in result]
        assert "ssh" in names

    def test_simple_question_no_tools(self):
        from tools.filter import filter_tools
        schemas = [{"function": {"name": "terminal"}}]
        result = filter_tools("what is python?", schemas)
        assert result == []

    def test_empty_message_returns_all(self):
        from tools.filter import filter_tools
        schemas = [{"function": {"name": "a"}}, {"function": {"name": "b"}}]
        result = filter_tools("", schemas)
        assert len(result) == 2


class TestFuzzy:
    def test_levenshtein(self):
        from tools.fuzzy import levenshtein
        assert levenshtein("kitten", "sitting") == 3
        assert levenshtein("", "") == 0
        assert levenshtein("abc", "abc") == 0

    def test_fuzzy_score_exact(self):
        from tools.fuzzy import fuzzy_score
        assert fuzzy_score("test", "test") == 1.0

    def test_fuzzy_score_substring(self):
        from tools.fuzzy import fuzzy_score
        assert fuzzy_score("test", "testing") > 0.7


class TestTodo:
    def test_add_and_complete(self):
        from tools.todo import manage_todos, TODOS_FILE
        manage_todos("clear_done")
        r = manage_todos("add", text="Test task")
        assert r["status"] == "added"
        tid = r["todo"]["id"]
        r = manage_todos("complete", todo_id=tid)
        assert r["status"] == "completed"
        manage_todos("clear_done")
        if TODOS_FILE.exists():
            TODOS_FILE.unlink()


class TestApproval:
    def test_request_and_list(self):
        from tools.approval import request_approval, list_pending
        r = request_approval("delete files")
        assert r["type"] == "approval_required"
        p = list_pending()
        assert p["count"] >= 1


class TestClarify:
    def test_with_options(self):
        from tools.clarify import clarify
        r = clarify("Which?", ["A", "B", "C"])
        assert r["type"] == "clarification_needed"
        assert len(r["options"]) == 3


class TestProgress:
    def test_lifecycle(self):
        from tools.progress import progress
        r = progress("start", label="Test", total=100)
        assert r["status"] == "started"
        tid = r["task_id"]
        r = progress("update", task_id=tid, current=50)
        assert r["percent"] == 50
        r = progress("complete", task_id=tid)
        assert r["status"] == "complete"


class TestCheckpoint:
    def test_save_and_delete(self):
        from tools.checkpoint import manage_checkpoint
        r = manage_checkpoint("save", name="test_cp")
        assert r["status"] == "saved"
        r = manage_checkpoint("delete", name="test_cp")
        assert r["status"] == "deleted"
