# custom cut flow functions

import awkward as ak
import numpy as np
import hist
from collections import defaultdict


def get_pt_hist(object:ak.Array, mask:ak.Array):
       h_pt  = hist.Hist(hist.axis.Regular(300, 0, 300,   name="pt",  label="$p_T$ (GeV)"))
       h_pt.fill(ak.flatten(object[mask].pt))
       return h_pt

def get_eta_hist(object:ak.Array, mask:ak.Array):
        h_eta = hist.Hist(hist.axis.Regular(50, -2.5, 2.5, name="eta", label=r"$\eta$"))
        h_eta.fill(ak.flatten(object[mask].eta))
        return h_eta


def make_event_counts(events:ak.Array, obj_name:str, object_masks:list[list], event_masks:list[list]):
    """
    gets number of events for various events and object level cuts
    gotta use lambda functions for object_masks or else this doesn't work
    example:

    object_masks = [
    ("raw",      lambda obj: ak.full_like(obj.pt, True, dtype=bool)),
    ("eta_cut",  lambda obj: np.abs(obj.eta) < 2.3),
    ("pt_cut",   lambda obj: obj.pt > 20),
    ("genFlav5", lambda obj: obj.genPartFlav == 5),
    ]     
    """
    results = defaultdict()

    results['total_events'] = len(events)

    for e_name, e_fn in event_masks:
        event_subset = events[e_fn(events)]
        obj = getattr(event_subset, obj_name)
        results[e_name]['n_events'] = len(event_subset)
        
        for obj_cut_name, obj_fn in object_masks:
            obj_mask = obj_fn(obj)  # compute mask fresh on the event subset
            results[e_name][obj_cut_name] = ak.sum(ak.num(obj[obj_mask]))            



       

# def get_pt_hist(obj, mask, binning: list):

#     if isinstance(binning, list) and len(binning) == 3:
#         bins, min_bin, max_bin = binning
#         h_pt = hist.Hist(hist.axis.Regular(bins, min_bin, max_bin, name="pt", label="$p_T$ (GeV)"))
#         h_pt.fill(ak.flatten(obj[mask].pt))
#         return h_pt
    
#     if isinstance(binning, list) and all(isinstance(b, int) for b in binning):
#         h_pt = hist.Hist(hist.axis.Variable(binning, name="pt", label="$p_T$ (GeV)"))
#         h_pt.fill(ak.flatten(obj[mask].pt))
#         return h_pt
    
#     raise ValueError("binning must be either Regularly binned: [bins, min_bin, max_bin] or Variably binned: [bin_1, bin_2, ..., bin_n]")

    

def make_cutflow(object: ak.Array, cut_masks:list[list], hist_fn):

    cutflows = defaultdict(dict) 

    raw_mask = ak.full_like(object.pt, True, dtype=bool) # This will break if we ever give it an object without a pt field
    cumulative_mask = raw_mask

    cutflows["single_cut"]["raw"] = hist_fn(object, raw_mask)
    cutflows["iterative_cut"]["raw"] = hist_fn(object, raw_mask)

    for cut_name, mask in cut_masks:

        cumulative_mask = cumulative_mask & mask # every other iteration

        cutflows["single_cut"][cut_name] = hist_fn(object, mask)
        cutflows["iterative_cut"][cut_name] = hist_fn(object, cumulative_mask)
        
    return cutflows


def make_pt_eta_cutflow(object: ak.Array, cut_masks:list[list]):
    """
    Makes pt and eta cutflows for a given object collection.
    
    Args:
        obj: awkward array collection (e.g. events.Tau, events.Electron)
        cut_masks: list of (name, mask) tuples e.g. [("pt_cut", obj.pt > 20), ...]
    
    Returns:
        dict with keys:
            "pt_cutflows":  dict with "single_cut" and "iterative_cut" -> hist.Hist
            "eta_cutflows": dict with "single_cut" and "iterative_cut" -> hist.Hist
    """

    results = defaultdict(dict)

    results["pt_cutflows"] = make_cutflow(object, cut_masks, get_pt_hist)

    results["eta_cutflows"] = make_cutflow(object, cut_masks, get_eta_hist)

    return results
