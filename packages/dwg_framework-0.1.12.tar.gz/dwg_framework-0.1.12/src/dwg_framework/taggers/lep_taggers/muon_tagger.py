from .common import global_tight_sip3d
import numpy as np
import awkward as ak

def tag_muon_quality(muon): #use on raw muon collection

    """
    Add 'isGold', 'isSilver', 'isBronze' boolean field to events.Muon based on cuts.
    Add 'qual_tag' integer field to events.Muon, binary numbers
    """

    
    # define variables
    abs_eta   = np.abs(muon.eta)
    abs_dxy   = np.abs(muon.dxy)
    abs_dz    = np.abs(muon.dz)
    sip3d     = muon.sip3d
    pt        = muon.pt
    iso03pt   = muon.pfRelIso03_all * pt
    miniIsoPt = muon.miniPFRelIso_all * pt
    pfIsoId   = muon.pfIsoId
    tight     = muon.tightId
    medium    = muon.mediumId
    low_pt_not_in_endcap = (pt >= 6) | (abs_eta < 1.2) # if muon has pt < 6, abs_eta < 1.2 allows them to stay in selection
    
    
    # --- Baseline selection ---
    baseline_mask = (
        (abs_eta < 2.5)
        & (sip3d < 6)
        & (abs_dxy < 0.05)
        & (abs_dz  < 0.1)
        & (iso03pt   < (20 + 300/pt))
        & (miniIsoPt < (20 + 300/pt))
        & low_pt_not_in_endcap
    )

    # --- Quality tags ---

    gold_silver_mask = ( 
        baseline_mask
        & (iso03pt   <= 4)
        & (miniIsoPt <= 4)
        & tight
    )
    
    gold_mask = (
        gold_silver_mask
        & (sip3d < global_tight_sip3d)
    )
        
    silver_mask = (
        gold_silver_mask
        & (sip3d >= global_tight_sip3d)
    )

    bronze_mask = baseline_mask & ~gold_silver_mask

    muon = ak.with_field(muon, ~baseline_mask, 'isFail')
    muon = ak.with_field(muon, baseline_mask, 'isBaseline') #redundant because isBaseline == isGold | isSilver | isBronze, but nice to have for convenience
    muon = ak.with_field(muon, gold_mask, 'isGold')
    muon = ak.with_field(muon, silver_mask, 'isSilver')
    muon = ak.with_field(muon, bronze_mask, 'isBronze')
    
    #qual_tag = ak.full_like(muon.pt, -1, dtype=int)
    #qual_tag = ak.where(muon.isBronze, 1, qual_tag)
    #qual_tag = ak.where(muon.isSilver, 10, qual_tag)
    #qual_tag = ak.where(muon.isGold, 100, qual_tag)
    
    #muon = ak.with_field(muon, qual_tag, "qual_tag")


    ### New masks here!!
    
    tight_ID = baseline_mask & tight
    
    tight_SIP3D = baseline_mask & (sip3d < global_tight_sip3d)
    
    tight_ISO = baseline_mask & (miniIsoPt <= 4) & (iso03pt <= 4)
    
    muon = ak.with_field(muon, tight_ID, 'tight_ID')
    muon = ak.with_field(muon, tight_SIP3D, 'tight_SIP3D')
    muon = ak.with_field(muon, tight_ISO, 'tight_ISO')

    medium_gold = (
        baseline_mask 
        & (iso03pt   <= 4)
        & (miniIsoPt <= 4)
        & medium
        & (sip3d < global_tight_sip3d)
    )
             

    tight_minus_prompt = (
        baseline_mask 
        & (iso03pt   <= 4)
        & (miniIsoPt <= 4)
        & (sip3d < global_tight_sip3d)
        & (muon.nTrackerLayers > 5)
        & (muon.nStations > 1)
        & (muon.isPFcand)
        & (muon.isGlobal)
    )

    # --- Experimental Baseline selection ---
    exp_baseline_mask = (
        (abs_eta < 2.5)
        & (sip3d < 6)
        # & (abs_dxy < 0.05)
        # & (abs_dz  < 0.1)
        & (iso03pt   < (20 + 300/pt))
        & (miniIsoPt < (20 + 300/pt))
        & low_pt_not_in_endcap
    )

    muon = ak.with_field(muon, exp_baseline_mask, 'isExpBaseline')
    muon = ak.with_field(muon, medium_gold, 'isMedGold')
    muon = ak.with_field(muon, tight_minus_prompt, 'isGoldTightMinusPrompt')


    #qual_tag = ak.where(muon.tight_ID, 20, qual_tag)
    #qual_tag = ak.where(muon.tight_SIP3D, 200, qual_tag)
    #qual_tag = ak.where(muon.tight_ISO, 2000, qual_tag)
    
    #muon = ak.with_field(muon, qual_tag, "qual_tag")

    return muon