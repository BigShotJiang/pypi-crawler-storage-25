import tomlkit
from collections import defaultdict
from pathlib import Path

from .constants import DEFAULT_TOML_FILE
from .file_paths import _get_toml_path, _get_redirector, _safe_toml_write

#make function to spawn new jupyter notebook and fileset_config file

_THIS_DIR = Path(__file__).resolve().parent




class FilesetBuilder:
    """
    idea here is to have a class for loading and storing dataset toml in memory, interacting with toml (dumping info), and generating filesets safely.
    """
    def __init__(self, toml_file:str=DEFAULT_TOML_FILE, config=None):
        
        toml_path = _get_toml_path(toml_file)
        with open(toml_path, "r") as f:
            self.toml = tomlkit.load(f)
        
        self.metadata_keys = self.toml["metadata_keys"]
        
        if config is not None:
            # format_path = _get_toml_path(config) # if I'm going to be calling this from the directory my notebook is in, then _get_toml_path is probably wrong. _get_toml_path gets them the path to the sample_tools directory
            # with open(format_path, "r") as f:
            with open(config, "r") as f:
                self.config = tomlkit.load(f)

        else:
            self.config = None

    def dump_dataset_names(self):
        skip = {"cern_redirector", "lpc_redirector", "metadata_keys"}
        return [k for k in self.toml.keys() if k not in skip]
    
    def get_num_workers(self):
        if self.config is None:
            print("cannot return workers before initializing with fileset_config.toml file")
            return
        
        return int(self.config['num_workers']) # type: ignore
    
    def spawn_config(self, name="fileset_config.toml"):
        running_dir = Path.cwd()
        if not (running_dir / name).exists():
            
            new_config_toml = tomlkit.document()
            
            datasets = self.dump_dataset_names()

            datasets_array = tomlkit.array()
            datasets_array.multiline(True)

            for dataset_name in datasets:
                datasets_array.append([dataset_name, 1])

            new_config_toml["datasets"] = datasets_array
            new_config_toml["num_workers"] = 1

            # add more here if I add more functionality to fileset_config.toml

            _safe_toml_write(new_config_toml, (running_dir / "fileset_config.toml"))
            print(f"spawned config file at: {running_dir / "fileset_config.toml"}")
            return
        print(f"config file already exists at: {running_dir / "fileset_config.toml"}")



    def format_for_local(self):

        """
        must return a fileset of this dictionary structure:
        fileset                                 → dict
        └── "TTJetsDiLept2018UL"                → str key (dataset name)
            ├── "files"                         → dict
            │   └── "local_path/...file.root"   → str key (file path)
            │       └── "Events"                → str value (tree name)
            └── "metadata"                      → dict
                ├── "is_mc": True               → bool value
                └── "is_UL": True               → bool value
        └── "Wto2L2Nu"                          → str key (dataset name)
            ...
        """

        if self.config is None:
            print("cannot format before initializing with fileset_config.toml file")
            return

        dataset_list = self.config['datasets']
        num_workers   = self.config['num_workers']
        
        fileset = defaultdict(dict)
        
        for name, num_files in dataset_list: # type: ignore
            
            dataset = self.toml[name] # full dataset dict (from inside the toml)
            
            files_dict = {}

            for file in dataset["local_files"][:num_files]: # type: ignore
                files_dict[str(Path(dataset["local_path"]) / file)] = dataset["branch"] # type: ignore
                
            #print(files_dict) # debug
            fileset[name]["files"] = files_dict
            
            metadata_dict = {}

            for key in self.metadata_keys: # type: ignore
                metadata_dict[key] = dataset[key] # type: ignore
            fileset[name]["metadata"] = metadata_dict
        
        return dict(fileset)
    


    def format_for_remote(self):

        """
        must return a fileset of this dictionary structure:
        fileset                                 → dict
        └── "TTJetsDiLept2018UL"                → str key (dataset name)
            ├── "files"                         → dict
            │   └── "local_path/...file.root"   → str key (file path)
            │       └── "Events"                → str value (tree name)
            └── "metadata"                      → dict
                ├── "is_mc": True               → bool value
                └── "is_UL": True               → bool value
        └── "Wto2L2Nu"                          → str key (dataset name)
            ...
        """

        if self.config is None:
            print("cannot format before initializing with fileset_config.toml file")
            return

        dataset_list = self.config['datasets']
        num_workers   = self.config['num_workers']
        
        fileset = defaultdict(dict)
        
        for name, num_files in dataset_list: # type: ignore
            
            dataset = self.toml[name] # full dataset dict (from inside the toml)
            
            files_dict = {}

            red = _get_redirector(self.toml, name)

            #for file in dataset["local_files"][:num_files]: # type: ignore
            #    files_dict[str(Path(dataset["local_path"]) / file)] = dataset["branch"] # type: ignore

            # use .txt file
            with open(_THIS_DIR / "txt_files" / f"{name}.txt", "r") as f:
                files_to_run_on = [red + line.strip() for line in f.readlines()[:num_files]]
                for f in files_to_run_on:
                    files_dict[f] = dataset["branch"] # type: ignore
                
            #print(files_to_run_on) # debug
            
           
            metadata_dict = {}

            for key in self.metadata_keys: # type: ignore
                metadata_dict[key] = dataset[key] # type: ignore
            fileset[name]["files"] = files_dict
            fileset[name]["metadata"] = metadata_dict
        
        return dict(fileset)