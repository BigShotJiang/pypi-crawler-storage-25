import tomlkit

from .file_paths import _get_toml_path

from .constants import DEFAULT_TOML_FILE, DEFAULT_LOCAL_SAMPLE_DIR

REQUIRED_DEFAULTS = {
    "cern_redirector": "root://cms-xrd-global.cern.ch/",
    "lpc_redirector": "root://cmsxrootd.fnal.gov/",
    "metadata_keys": ["is_MC", "is_UL", "is_SMS"], # must also edit below if adding new metadata
}

def _ensure_top_level_keys(open_toml: dict) -> dict:
    for key, default in REQUIRED_DEFAULTS.items():
        if key not in open_toml:
            open_toml[key] = default
    return open_toml

def add_empty_entry(toml_file: str=DEFAULT_TOML_FILE, dataset_name:str = "empty"):
    
    toml_path = _get_toml_path(toml_file)

    with open(toml_path, "rb") as f:
        open_toml = tomlkit.load(f)

    _ensure_top_level_keys(open_toml)

    open_toml[dataset_name] = {
        "local_files"     : [],
        "local_path"      : "",
        "name_on_DAS"     : "dataset=/...",
        "DAS_txt_file"    : "",
        "pref_redirector" : "cern",
        "branch"          : "Events",
        # download settings
        "download_all"    : False,
        "num_to_download" : 3,
        # job settings
        "use_all_files"   : True, # May remove this in the future based on how I setup run_config.toml
        "num_to_run"      : 3,   # May remove this in the future based on how I setup run_config.toml
        "group_name"      : "None",
        # booleans (must manually set for each sample)
        "is_MC"           : True,
        "is_UL"           : False,
        "is_SMS"          : False,
    }

    with open(toml_path, "w") as f:
        tomlkit.dump(open_toml, f) #not a safe toml write, other files have an example where we first make a tmp file, I should update this
    return

def add_many_empty_entries(toml_file: str=DEFAULT_TOML_FILE, dataset_name:str = "empty"):
    for count in range(10):
        this_name = dataset_name + str(count)
        add_empty_entry(toml_file, this_name)
    return

# a function to scan a toml and append new meta data keys with default value if they're not present in the toml?

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    #parser.add_argument("name", help="Dataset name")
    parser.add_argument("--many", action="store_true", help="Add 10 entries")
    args = parser.parse_args()
    
    if args.many:
        add_many_empty_entries()
    else:
        add_empty_entry()