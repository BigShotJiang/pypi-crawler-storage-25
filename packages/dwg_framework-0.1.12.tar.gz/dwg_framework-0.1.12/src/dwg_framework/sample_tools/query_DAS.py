import subprocess
from pathlib import Path


def _das_query(query: str, format_output:bool=True): # uses absolute path to the dasgoclient command relative to my system

    """
    returns a list of all the root files on CMS DAS
    like: https://cmsweb.cern.ch/das/request?instance=prod/global&input=file+dataset%3D%2FSlepSnuCascade_MN1-220_MN2-260_MC1-240_TuneCP5_13p6TeV_madgraphMLM-pythia8%2FRun3Summer23BPixNanoAODv12-130X_mcRun3_2023_realistic_postBPix_v6-v3%2FNANOAODSIM
    """

    dataset = query.replace("dataset=", "").strip() # not very robust but makes sure we get good format

    result = subprocess.run(
        ["/Users/derekgrove/Code/dasgoclient/dasgoclient_osx", "-query", f"file dataset={dataset}"],
        capture_output=True,
        text=True,
        check=True
    )
    
    #print(result.stdout.strip().split("\n"))
    return result.stdout.strip().split("\n")

def _strip_down_dasgo_query(query):

    output = _das_query(query)

    filenames = [Path(p).name for p in output]

    print(filenames)
    return filenames

if __name__ == "__main__":
    _das_query("dataset=/SlepSnuCascade_MN1-220_MN2-260_MC1-240_TuneCP5_13p6TeV_madgraphMLM-pythia8/Run3Summer23BPixNanoAODv12-130X_mcRun3_2023_realistic_postBPix_v6-v3/NANOAODSIM")