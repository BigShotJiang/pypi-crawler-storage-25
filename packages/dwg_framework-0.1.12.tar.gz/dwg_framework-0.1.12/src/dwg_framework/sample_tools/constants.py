DEFAULT_LOCAL_SAMPLE_DIR = "local_samples"
DEFAULT_TOML_FILE = "datasets.toml"
DEFAULT_TXT_FILE_DIR = "txt_files"