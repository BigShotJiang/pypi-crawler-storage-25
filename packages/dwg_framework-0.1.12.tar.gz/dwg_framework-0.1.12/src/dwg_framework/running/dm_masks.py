import awkward as ak

from .SMS_masspoints import masspoints_dict


"""
These functions are written assuming you are loading your file with the NanoAODSchema, i.e.:

from coffea.nanoevents import NanoEventsFactory, NanoAODSchema

events = NanoEventsFactory.from_root(
{"local_samples/TChiWZ_ZToLL_mZmin_2018UL/0DBC9D13-B696-4047-BFCC-A9E2CACECC53.root": "Events"},
schemaclass=NanoAODSchema,
metadata={"dataset": "your_dataset"},
mode="eager",
).events()

This will compact the GenModel and thus they're accesible like events.GenModel.your_mass_point

these functions could be rewritten slightly to work for BaseSchema as well, but you'd be using raw branch names from the .root file
"""
def get_SMS_masspoints(events, dataset) -> dict:
    """
    returns dict{"delta_m1": mask1, "delta_m2": mask2} for the dataset defined in SMS_masspoints.
    """
    if dataset not in masspoints_dict:
        raise KeyError(f"{dataset} not found in SMS_masspoints. Available: {list(masspoints_dict.keys())}")
    sample_mps = masspoints_dict[dataset]['mass_points']
    branch_prepend = masspoints_dict[dataset]['append']

    masks = {}
    all_false = ak.full_like(events.event, False, dtype=bool)

    for dm, mp_list in sample_mps.items():
        if dm == 'append':
            continue
        masks[dm] = all_false
        for mp in mp_list:
            branch = branch_prepend + mp
            if branch not in events.GenModel.fields:
                continue
            masks[dm] = masks[dm] | events.GenModel[branch]
    return masks
            
            

"""
what do I want??

masks = {
"dm1": dm1_mask
"dm2": dm2_mask
....
}
"""