import cloudpickle
from datetime import datetime
from dask.distributed import Client
from dask.distributed import LocalCluster
from coffea import processor
from coffea.nanoevents import NanoAODSchema, BaseSchema
from pathlib import Path

from dwg_framework import FilesetBuilder # type: ignore

def run_analysis(processor_instance, mode:str="virtual", dataset_format:str="local", make_pikl:bool=True, pikl_name:str="", skipbadfiles:bool=True, use_fileset="fileset_config.toml"):

    if not (Path.cwd() / use_fileset).exists():
        builder = FilesetBuilder()
        builder.spawn_config(name=use_fileset)
    
    builder = FilesetBuilder(config=use_fileset) # this loads the config file in the RUNNING DIRECTORY, go edit that one.

    if dataset_format == "local":
        fileset = builder.format_for_local()
    elif dataset_format == "remote":
        fileset = builder.format_for_remote()

    num_workers = builder.get_num_workers()

    cluster = None
    client = None

    if mode == "dask":
        cluster = LocalCluster()
        client = Client(cluster)
        cluster.scale(num_workers) # type: ignore
        executor = processor.DaskExecutor(client=client)
    elif mode == "_dask":
        client = Client()
        executor = processor.DaskExecutor(client=client)
    elif mode == "coffea":
        client = Client("tls://localhost:8786")
        executor = processor.DaskExecutor(client=client)
    elif mode == "virtual":
        executor = processor.IterativeExecutor()
    else:
        print("unknown mode, try 'dask', 'coffea', or 'virtual'.")
        exit()

    #timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    #output_dir = f"pikls/{timestamp}"
    output_dir = "pikls"

    runner = processor.Runner(
        executor=executor,
        schema=NanoAODSchema, # type: ignore
        savemetrics=True,
        skipbadfiles=skipbadfiles,
    )

    # if running on custom ntuples, need to change the above to use BaseSchema

    result, metrics = runner(fileset, processor_instance=processor_instance) # type: ignore

    if make_pikl:
        Path(output_dir).mkdir(parents=True, exist_ok=True)        
        if pikl_name == "":
            output_file = f"{output_dir}/all_datasets_full.pkl"
        else:
            output_file = f"{output_dir}/{pikl_name}"
        with open(output_file, "wb") as f:
            cloudpickle.dump({'results': result, 'metrics': metrics}, f)
        print(f"Saved {output_file}")

    if cluster is not None:
        cluster.close()
    if client is not None:
        client.close()
    

    return result, metrics