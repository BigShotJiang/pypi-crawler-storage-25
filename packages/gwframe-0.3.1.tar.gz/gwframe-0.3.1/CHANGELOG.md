# Changelog

## [Unreleased]

## [0.3.1] - 2026-05-11

### Added

- `FrameReader` context manager for efficient repeated reads from the same file
  — holds the stream and TOC open, avoiding re-opening on every call
- `FrameReader.read()` supports the same parameters as `read()`: single/multi
  channel, time-based slicing, `frame_index`, and `allow_invalid`
- `FrameReader.info`, `FrameReader.channels`, `FrameReader.frames`, and
  `FrameReader.channel_details()` for metadata access without re-reading

### Changed

- `read()` now opens the file stream once per call instead of re-opening for
  each channel or frame index in multi-channel and time-sliced reads

## [0.3.0] - 2026-04-13

### Added

- Masked array support for ADC channels using the channel-level `dataValid` flag
  (frame spec v3-v8)
- `allow_invalid` parameter on `read()`, `read_bytes()`, and `read_frames()` to
  return `numpy.ma.MaskedArray` for channels with invalid data
- `InvalidDataError` exception raised when reading invalid data without
  `allow_invalid=True`
- `OnMaskLoss` enum (`warn`, `raise`, `ignore`) to control behavior when mask
  fidelity is lost on write
- `TimeSeries.mask` field and `TimeSeries.to_masked()` convenience method for
  working with masked data without storing masked arrays directly
- Frame spec version detection via `get_version()` in the inspect module
- `gwframe inspect` CLI command with tiered verbosity (`-v` channels, `-vv`
  frames, `-vvv` per-channel detail)
- `ChannelInfo` dataclass, `get_channels_by_type()`, and `get_channel_details()`
  in the inspect module
- `FrameWriter.open()` / `FrameWriter.close()` methods as an alternative to the
  context manager protocol
- Atomic file writes — `FrameWriter` now writes to a temporary file and
  atomically moves it to the final path on close
- `FrameIndexError` for clearer error messages when accessing invalid frame
  indices

### Changed

- Operations now preserve masks and frame spec version through read/write
  roundtrips
- `TimeSeries` stores mask as a separate field instead of using
  `numpy.ma.MaskedArray` directly in the `array` field
- Use native NumPy dtypes where applicable across read, write, and inspect

### Fixed

- `Frame.start` setter now propagates to the written GPS time (previously the
  original GPS time was silently kept)

## [0.2.2] - 2026-03-25

### Fixed

- Fix memory leak in nanobind bindings for bytes-based frame reading
- Update minimum version of typer to 0.20

## [0.2.1] - 2026-03-18

### Added

- Add ADC channel write support

### Fixed

- Fix `read()` and `read_bytes()` returning empty results for frames with many
  channels (e.g. large ADC files) by switching to TOC-based channel enumeration

## [0.2.0] - 2026-03-17

### Added

- Add `gwframe select` command to keep only specified channels

### Changed

- Renamed `t0` parameter/attribute to `start` across `TimeSeries`, `FrameInfo`,
  and related APIs
- Renamed `channel` parameter to `channels` in `read()` and `read_bytes()`

## [0.1.2] - 2025-11-18

### Added

- Allow writing frames as bytes

## [0.1.1] - 2025-11-06

### Fixed

- Fix issue with wheels with 'dirty' tags being generated randomly in CI jobs
  * Prevented a subset of wheels from being published
  * No functional API change

## [0.1.0] - 2025-11-06

- Initial release

[unreleased]: https://git.ligo.org/olivia.godwin/gwframe/-/compare/0.3.1...main
[0.3.1]: https://git.ligo.org/olivia.godwin/gwframe/-/tags/0.3.1
[0.3.0]: https://git.ligo.org/olivia.godwin/gwframe/-/tags/0.3.0
[0.2.2]: https://git.ligo.org/olivia.godwin/gwframe/-/tags/0.2.2
[0.2.1]: https://git.ligo.org/olivia.godwin/gwframe/-/tags/0.2.1
[0.2.0]: https://git.ligo.org/olivia.godwin/gwframe/-/tags/0.2.0
[0.1.2]: https://git.ligo.org/olivia.godwin/gwframe/-/tags/0.1.2
[0.1.1]: https://git.ligo.org/olivia.godwin/gwframe/-/tags/0.1.1
[0.1.0]: https://git.ligo.org/olivia.godwin/gwframe/-/tags/0.1.0
