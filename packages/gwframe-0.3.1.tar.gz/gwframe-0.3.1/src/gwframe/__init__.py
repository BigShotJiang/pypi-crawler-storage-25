# Copyright (c) 2025, California Institute of Technology and contributors
#
# You should have received a copy of the licensing terms for this
# software included in the file "LICENSE" located in the top-level
# directory of this package. If you did not, you can view a copy at
# https://git.ligo.org/olivia.godwin/gwframe/-/raw/main/LICENSE

from __future__ import annotations

from . import _core  # type: ignore[attr-defined]
from .read import FrameReader, read, read_bytes, read_frames
from .types import TimeSeries
from .write import Frame, FrameWriter, write, write_bytes

# Get version from setuptools_scm
try:
    from ._version import __version__
except ImportError:
    __version__ = "0.0.0"

__all__ = [
    "Frame",
    "FrameReader",
    "FrameWriter",
    "TimeSeries",
    "__version__",
    "read",
    "read_bytes",
    "read_frames",
    "write",
    "write_bytes",
]
