"""Tests for gwframe CLI commands."""

from __future__ import annotations

import shutil

import numpy as np
import pytest
from typer.testing import CliRunner

import gwframe
from gwframe.cli import app
from gwframe.inspect import get_channels
from gwframe.operations import (
    drop_channels,
    rename_channels,
    resize_frames,
    select_channels,
)

# Import fixtures from test_operations
pytest_plugins = ["gwframe.tests.test_operations"]

runner = CliRunner()


class TestRenameCommand:
    """Tests for gwframe rename command."""

    def test_rename_basic(self, single_frame_file, tmp_path):
        """Test basic rename command."""
        output_dir = tmp_path / "output"

        result = runner.invoke(
            app,
            [
                "rename",
                str(single_frame_file),
                "-o",
                str(output_dir),
                "-m",
                "L1:CHAN1=>L1:RENAMED1",
                "-m",
                "L1:CHAN2=>L1:RENAMED2",
            ],
        )

        assert result.exit_code == 0, result.stdout
        assert output_dir.exists()

        # Verify channels were renamed
        output_file = output_dir / single_frame_file.name
        channels = get_channels(str(output_file))
        assert "L1:RENAMED1" in channels
        assert "L1:RENAMED2" in channels
        assert "L1:CHAN1" not in channels
        assert "L1:CHAN2" not in channels

    def test_rename_in_place(self, single_frame_file, tmp_path):
        """Test rename with --in-place."""
        # Copy file to tmp_path so we can modify it
        test_file = tmp_path / "test.gwf"
        shutil.copy(single_frame_file, test_file)

        result = runner.invoke(
            app,
            [
                "rename",
                str(test_file),
                "-i",
                "-m",
                "L1:CHAN1=>L1:RENAMED",
            ],
        )

        assert result.exit_code == 0, result.stdout

        # Verify file was modified in place
        channels = get_channels(str(test_file))
        assert "L1:RENAMED" in channels
        assert "L1:CHAN1" not in channels

    def test_rename_single_file_output(self, single_frame_file, tmp_path):
        """Test rename with single file output."""
        output_file = tmp_path / "output.gwf"

        result = runner.invoke(
            app,
            [
                "rename",
                str(single_frame_file),
                "-o",
                str(output_file),
                "-m",
                "L1:CHAN1=>L1:RENAMED",
            ],
        )

        assert result.exit_code == 0, result.stdout
        assert output_file.exists()

        # Verify channels were renamed
        channels = get_channels(str(output_file))
        assert "L1:RENAMED" in channels

    def test_rename_mutual_exclusivity(self, single_frame_file, tmp_path):
        """Test that --in-place and -o are mutually exclusive."""
        output_dir = tmp_path / "output"

        result = runner.invoke(
            app,
            [
                "rename",
                str(single_frame_file),
                "-o",
                str(output_dir),
                "-i",
                "-m",
                "L1:CHAN1=>TEST:RENAMED",
            ],
        )

        assert result.exit_code != 0
        assert "mutually exclusive" in result.stdout.lower()


class TestDropCommand:
    """Tests for gwframe drop command."""

    def test_drop_basic(self, single_frame_file, tmp_path):
        """Test basic drop command."""
        output_dir = tmp_path / "output"

        result = runner.invoke(
            app,
            [
                "drop",
                str(single_frame_file),
                "-o",
                str(output_dir),
                "-c",
                "L1:CHAN1",
            ],
        )

        assert result.exit_code == 0, result.stdout

        # Verify channel was dropped
        output_file = output_dir / single_frame_file.name
        channels = get_channels(str(output_file))
        assert "L1:CHAN1" not in channels
        assert "L1:CHAN2" in channels

    def test_drop_in_place(self, single_frame_file, tmp_path):
        """Test drop with --in-place."""
        test_file = tmp_path / "test.gwf"
        shutil.copy(single_frame_file, test_file)

        result = runner.invoke(app, ["drop", str(test_file), "-i", "-c", "L1:CHAN1"])

        assert result.exit_code == 0, result.stdout

        # Verify channel was dropped
        channels = get_channels(str(test_file))
        assert "L1:CHAN1" not in channels
        assert "L1:CHAN2" in channels

    def test_drop_multiple_channels(self, single_frame_file, tmp_path):
        """Test dropping multiple channels."""
        output_dir = tmp_path / "output"

        result = runner.invoke(
            app,
            [
                "drop",
                str(single_frame_file),
                "-o",
                str(output_dir),
                "-c",
                "L1:CHAN1",
                "-c",
                "L1:CHAN2",
            ],
        )

        assert result.exit_code == 0, result.stdout

        # Verify both channels were dropped
        output_file = output_dir / single_frame_file.name
        channels = get_channels(str(output_file))
        assert "L1:CHAN1" not in channels
        assert "L1:CHAN2" not in channels


class TestSelectCommand:
    """Tests for gwframe select command."""

    def test_select_basic(self, single_frame_file, tmp_path):
        """Test basic select command."""
        output_dir = tmp_path / "output"

        result = runner.invoke(
            app,
            [
                "select",
                str(single_frame_file),
                "-o",
                str(output_dir),
                "-c",
                "L1:CHAN1",
            ],
        )

        assert result.exit_code == 0, result.stdout

        # Verify only selected channel remains
        output_file = output_dir / single_frame_file.name
        channels = get_channels(str(output_file))
        assert "L1:CHAN1" in channels
        assert "L1:CHAN2" not in channels
        assert "L1:CHAN3" not in channels

    def test_select_in_place(self, single_frame_file, tmp_path):
        """Test select with --in-place."""
        test_file = tmp_path / "test.gwf"
        shutil.copy(single_frame_file, test_file)

        result = runner.invoke(app, ["select", str(test_file), "-i", "-c", "L1:CHAN1"])

        assert result.exit_code == 0, result.stdout

        # Verify only selected channel remains
        channels = get_channels(str(test_file))
        assert "L1:CHAN1" in channels
        assert "L1:CHAN2" not in channels

    def test_select_multiple_channels(self, single_frame_file, tmp_path):
        """Test selecting multiple channels."""
        output_dir = tmp_path / "output"

        result = runner.invoke(
            app,
            [
                "select",
                str(single_frame_file),
                "-o",
                str(output_dir),
                "-c",
                "L1:CHAN1",
                "-c",
                "L1:CHAN3",
            ],
        )

        assert result.exit_code == 0, result.stdout

        # Verify only selected channels remain
        output_file = output_dir / single_frame_file.name
        channels = get_channels(str(output_file))
        assert "L1:CHAN1" in channels
        assert "L1:CHAN3" in channels
        assert "L1:CHAN2" not in channels

    def test_select_single_file_output(self, single_frame_file, tmp_path):
        """Test select with single file output."""
        output_file = tmp_path / "output.gwf"

        result = runner.invoke(
            app,
            [
                "select",
                str(single_frame_file),
                "-o",
                str(output_file),
                "-c",
                "L1:CHAN1",
            ],
        )

        assert result.exit_code == 0, result.stdout
        assert output_file.exists()

        channels = get_channels(str(output_file))
        assert "L1:CHAN1" in channels
        assert "L1:CHAN2" not in channels

    def test_select_mutual_exclusivity(self, single_frame_file, tmp_path):
        """Test that --in-place and -o are mutually exclusive."""
        output_dir = tmp_path / "output"

        result = runner.invoke(
            app,
            [
                "select",
                str(single_frame_file),
                "-o",
                str(output_dir),
                "-i",
                "-c",
                "L1:CHAN1",
            ],
        )

        assert result.exit_code != 0
        assert "mutually exclusive" in result.stdout.lower()

    def test_select_recursive(self, tmp_path, sample_data, create_test_frame):
        """Test select with --recursive flag."""
        # Create nested directory structure
        sub_dir = tmp_path / "data" / "sub"
        sub_dir.mkdir(parents=True)
        n_samples = sample_data["n_samples"]

        file_path = sub_dir / "nested.gwf"
        with gwframe.FrameWriter(str(file_path)) as writer:
            channels_data = {
                "L1:CHAN1": np.arange(n_samples, dtype=np.float32),
                "L1:CHAN2": np.arange(n_samples, dtype=np.float32) * 2,
            }
            frame = create_test_frame(
                sample_data["t0"], sample_data["duration"], channels_data
            )
            writer.write_frame(frame)

        output_dir = tmp_path / "output"

        result = runner.invoke(
            app,
            [
                "select",
                str(tmp_path / "data"),
                "-o",
                str(output_dir),
                "-r",
                "-c",
                "L1:CHAN1",
            ],
        )

        assert result.exit_code == 0, result.stdout

        output_files = list(output_dir.glob("*.gwf"))
        assert len(output_files) == 1
        channels = get_channels(str(output_files[0]))
        assert "L1:CHAN1" in channels
        assert "L1:CHAN2" not in channels


class TestResizeCommand:
    """Tests for gwframe resize command."""

    def test_resize_basic(self, multi_frame_file, tmp_path, sample_data):
        """Test basic resize command."""
        output_dir = tmp_path / "output"
        target_duration = sample_data["duration"] / 2

        result = runner.invoke(
            app,
            [
                "resize",
                str(multi_frame_file),
                "-o",
                str(output_dir),
                "-d",
                str(target_duration),
            ],
        )

        assert result.exit_code == 0, result.stdout

        # Verify frames were resized
        output_file = output_dir / multi_frame_file.name
        frames = list(gwframe.read_frames(str(output_file)))
        # Each of 3 original frames split in 2 = 6 frames
        assert len(frames) == 6
        for frame in frames:
            assert abs(frame.duration - target_duration) < 1e-9

    def test_resize_in_place(self, multi_frame_file, tmp_path, sample_data):
        """Test resize with --in-place."""
        test_file = tmp_path / "test.gwf"
        shutil.copy(multi_frame_file, test_file)
        target_duration = sample_data["duration"] / 2

        result = runner.invoke(
            app, ["resize", str(test_file), "-i", "-d", str(target_duration)]
        )

        assert result.exit_code == 0, result.stdout

        # Verify frames were resized in place
        frames = list(gwframe.read_frames(str(test_file)))
        assert len(frames) == 6


class TestImputeCommand:
    """Tests for gwframe impute command."""

    def test_impute_basic(self, tmp_path):
        """Test basic impute command."""
        # Create a file with NaN values
        input_file = tmp_path / "input.gwf"
        data_with_nan = np.array([1.0, 2.0, np.nan, 4.0, np.nan])

        gwframe.write(
            str(input_file),
            data_with_nan,
            start=1234567890.0,
            sample_rate=1,
            name="L1:CHAN",
        )

        output_dir = tmp_path / "output"

        result = runner.invoke(
            app, ["impute", str(input_file), "-o", str(output_dir), "-f", "0.0"]
        )

        assert result.exit_code == 0, result.stdout

        # Verify NaNs were replaced
        output_file = output_dir / input_file.name
        data = gwframe.read(str(output_file), "L1:CHAN")
        assert not np.any(np.isnan(data.array))
        assert data.array[2] == 0.0
        assert data.array[4] == 0.0

    def test_impute_in_place(self, tmp_path):
        """Test impute with --in-place."""
        test_file = tmp_path / "test.gwf"
        data_with_nan = np.array([1.0, np.nan, 3.0])

        gwframe.write(
            str(test_file),
            data_with_nan,
            start=1234567890.0,
            sample_rate=1,
            name="L1:CHAN",
        )

        result = runner.invoke(app, ["impute", str(test_file), "-i", "-f", "999.0"])

        assert result.exit_code == 0, result.stdout

        # Verify NaNs were replaced in place
        data = gwframe.read(str(test_file), "L1:CHAN")
        assert data.array[1] == 999.0

    def test_impute_specific_value(self, tmp_path):
        """Test impute replacing specific value."""
        input_file = tmp_path / "input.gwf"
        data = np.array([1.0, -999.0, 3.0, -999.0])

        gwframe.write(
            str(input_file),
            data,
            start=1234567890.0,
            sample_rate=1,
            name="L1:CHAN",
        )

        output_dir = tmp_path / "output"

        result = runner.invoke(
            app,
            [
                "impute",
                str(input_file),
                "-o",
                str(output_dir),
                "-r",
                "-999.0",
                "-f",
                "0.0",
            ],
        )

        assert result.exit_code == 0, result.stdout

        # Verify -999.0 values were replaced
        output_file = output_dir / input_file.name
        result_data = gwframe.read(str(output_file), "L1:CHAN")
        assert result_data.array[1] == 0.0
        assert result_data.array[3] == 0.0


class TestCombineCommand:
    """Tests for gwframe combine command."""

    def test_combine_files_with_filtering(
        self, tmp_path, sample_data, create_test_frame
    ):
        """Test combine command with files and channel filtering."""
        # Create two files with different channels
        file1 = tmp_path / "file1.gwf"
        file2 = tmp_path / "file2.gwf"
        n_samples = sample_data["n_samples"]

        data = np.arange(n_samples, dtype=np.float32)

        with gwframe.FrameWriter(str(file1)) as writer:
            channels = {"L1:CHAN_A": data, "L1:CHAN_B": data * 2}
            frame = create_test_frame(
                sample_data["t0"], sample_data["duration"], channels
            )
            writer.write_frame(frame)

        with gwframe.FrameWriter(str(file2)) as writer:
            channels = {"L1:CHAN_C": data * 3}
            frame = create_test_frame(
                sample_data["t0"], sample_data["duration"], channels
            )
            writer.write_frame(frame)

        output_dir = tmp_path / "output"

        # Test basic combine
        result = runner.invoke(
            app, ["combine", str(file1), str(file2), "-o", str(output_dir)]
        )
        assert result.exit_code == 0, result.stdout

        output_files = list(output_dir.glob("*.gwf"))
        frames = list(gwframe.read_frames(str(output_files[0])))
        assert "L1:CHAN_A" in frames[0]
        assert "L1:CHAN_B" in frames[0]
        assert "L1:CHAN_C" in frames[0]

        # Test with --keep filtering
        output_dir_keep = tmp_path / "output_keep"
        result = runner.invoke(
            app,
            [
                "combine",
                str(file1),
                str(file2),
                "-o",
                str(output_dir_keep),
                "-k",
                "L1:CHAN_A",
                "-k",
                "L1:CHAN_C",
            ],
        )
        assert result.exit_code == 0

        output_files = list(output_dir_keep.glob("*.gwf"))
        frames = list(gwframe.read_frames(str(output_files[0])))
        assert "L1:CHAN_A" in frames[0]
        assert "L1:CHAN_C" in frames[0]
        assert "L1:CHAN_B" not in frames[0]

    def test_combine_errors(self, single_frame_file, tmp_path):
        """Test combine error handling."""
        output_dir = tmp_path / "output"

        # Test less than 2 sources
        result = runner.invoke(
            app, ["combine", str(single_frame_file), "-o", str(output_dir)]
        )
        assert result.exit_code != 0
        assert "at least 2" in result.stdout.lower()


class TestRecompressCommand:
    """Tests for gwframe recompress command."""

    def test_recompress_basic(self, single_frame_file, tmp_path):
        """Test basic recompress command."""
        output_dir = tmp_path / "output"

        result = runner.invoke(
            app,
            [
                "recompress",
                str(single_frame_file),
                "-o",
                str(output_dir),
                "-c",
                "GZIP",
                "-l",
                "9",
            ],
        )

        assert result.exit_code == 0, result.stdout
        assert (output_dir / single_frame_file.name).exists()

        # Verify data integrity after recompression
        output_file = output_dir / single_frame_file.name
        original_data = gwframe.read(str(single_frame_file), "L1:CHAN1")
        recompressed_data = gwframe.read(str(output_file), "L1:CHAN1")
        assert np.allclose(original_data.array, recompressed_data.array)

    def test_recompress_in_place(self, single_frame_file, tmp_path):
        """Test recompress with --in-place."""
        test_file = tmp_path / "test.gwf"
        shutil.copy(single_frame_file, test_file)

        # Read original data
        original_data = gwframe.read(str(test_file), "L1:CHAN1")

        result = runner.invoke(app, ["recompress", str(test_file), "-i", "-c", "RAW"])

        assert result.exit_code == 0, result.stdout

        # Verify data integrity after in-place recompression
        recompressed_data = gwframe.read(str(test_file), "L1:CHAN1")
        assert np.allclose(original_data.array, recompressed_data.array)


class TestCLIVsAPI:
    """Tests comparing CLI results with direct API calls."""

    def test_rename_cli_matches_api(self, single_frame_file, tmp_path):
        """Test that CLI rename produces same results as API."""
        cli_output = tmp_path / "cli_output"
        api_output = tmp_path / "api_output"

        channel_map = {"L1:CHAN1": "TEST:RENAMED1"}

        # Run via CLI
        result = runner.invoke(
            app,
            [
                "rename",
                str(single_frame_file),
                "-o",
                str(cli_output),
                "-m",
                "L1:CHAN1=>TEST:RENAMED1",
            ],
        )
        assert result.exit_code == 0

        # Run via API
        rename_channels(
            str(single_frame_file), str(api_output), channel_map=channel_map
        )

        # Compare results
        cli_file = cli_output / single_frame_file.name
        api_file = api_output / single_frame_file.name

        cli_channels = sorted(get_channels(str(cli_file)))
        api_channels = sorted(get_channels(str(api_file)))
        assert cli_channels == api_channels

        # Compare data
        cli_data = gwframe.read(str(cli_file), "TEST:RENAMED1")
        api_data = gwframe.read(str(api_file), "TEST:RENAMED1")
        assert np.allclose(cli_data.array, api_data.array)

    def test_drop_cli_matches_api(self, single_frame_file, tmp_path):
        """Test that CLI drop produces same results as API."""
        cli_output = tmp_path / "cli_output"
        api_output = tmp_path / "api_output"

        # Run via CLI
        result = runner.invoke(
            app,
            ["drop", str(single_frame_file), "-o", str(cli_output), "-c", "L1:CHAN1"],
        )
        assert result.exit_code == 0

        # Run via API
        drop_channels(
            str(single_frame_file), str(api_output), channels_to_drop=["L1:CHAN1"]
        )

        # Compare results
        cli_file = cli_output / single_frame_file.name
        api_file = api_output / single_frame_file.name

        cli_channels = sorted(get_channels(str(cli_file)))
        api_channels = sorted(get_channels(str(api_file)))
        assert cli_channels == api_channels

    def test_select_cli_matches_api(self, single_frame_file, tmp_path):
        """Test that CLI select produces same results as API."""
        cli_output = tmp_path / "cli_output"
        api_output = tmp_path / "api_output"

        # Run via CLI
        result = runner.invoke(
            app,
            [
                "select",
                str(single_frame_file),
                "-o",
                str(cli_output),
                "-c",
                "L1:CHAN1",
                "-c",
                "L1:CHAN3",
            ],
        )
        assert result.exit_code == 0

        # Run via API
        select_channels(
            str(single_frame_file),
            str(api_output),
            channels_to_select=["L1:CHAN1", "L1:CHAN3"],
        )

        # Compare results
        cli_file = cli_output / single_frame_file.name
        api_file = api_output / single_frame_file.name

        cli_channels = sorted(get_channels(str(cli_file)))
        api_channels = sorted(get_channels(str(api_file)))
        assert cli_channels == api_channels

        # Compare data
        for chan in ["L1:CHAN1", "L1:CHAN3"]:
            cli_data = gwframe.read(str(cli_file), chan)
            api_data = gwframe.read(str(api_file), chan)
            assert np.allclose(cli_data.array, api_data.array)

    def test_resize_cli_matches_api(self, multi_frame_file, tmp_path, sample_data):
        """Test that CLI resize produces same results as API."""
        cli_output = tmp_path / "cli_output"
        api_output = tmp_path / "api_output"
        target_duration = sample_data["duration"] / 2

        # Run via CLI
        result = runner.invoke(
            app,
            [
                "resize",
                str(multi_frame_file),
                "-o",
                str(cli_output),
                "-d",
                str(target_duration),
            ],
        )
        assert result.exit_code == 0

        # Run via API
        resize_frames(
            str(multi_frame_file), str(api_output), target_duration=target_duration
        )

        # Compare results
        cli_file = cli_output / multi_frame_file.name
        api_file = api_output / multi_frame_file.name

        cli_frames = list(gwframe.read_frames(str(cli_file)))
        api_frames = list(gwframe.read_frames(str(api_file)))
        assert len(cli_frames) == len(api_frames)

        # Compare frame data
        for cli_frame, api_frame in zip(cli_frames, api_frames):
            assert abs(cli_frame.start - api_frame.start) < 1e-9
            assert abs(cli_frame.duration - api_frame.duration) < 1e-9


class TestErrorHandling:
    """Tests for CLI error handling."""

    def test_missing_output_dir(self, single_frame_file):
        """Test that missing output directory is caught."""
        result = runner.invoke(
            app, ["rename", str(single_frame_file), "-m", "L1:CHAN1=>TEST:RENAMED"]
        )

        assert result.exit_code != 0
        assert "output" in result.stdout.lower() or "required" in result.stdout.lower()

    def test_invalid_mapping_format(self, single_frame_file, tmp_path):
        """Test that invalid mapping format is caught."""
        output_dir = tmp_path / "output"

        result = runner.invoke(
            app,
            [
                "rename",
                str(single_frame_file),
                "-o",
                str(output_dir),
                "-m",
                "INVALID_MAPPING",
            ],
        )

        assert result.exit_code != 0
        assert "invalid" in result.stdout.lower()

    def test_no_files_found(self, tmp_path):
        """Test handling when no files are found."""
        empty_dir = tmp_path / "empty"
        empty_dir.mkdir()
        output_dir = tmp_path / "output"

        result = runner.invoke(
            app,
            ["rename", str(empty_dir), "-o", str(output_dir), "-m", "A=>B"],
        )

        assert result.exit_code != 0
        assert "no files" in result.stdout.lower()


class TestInspectCommand:
    """Tests for gwframe inspect command."""

    def test_inspect_default(self, single_frame_file):
        """Test inspect with no verbosity (level 0) shows file summary."""
        result = runner.invoke(app, ["inspect", str(single_frame_file)])
        assert result.exit_code == 0, result.stdout

        output = result.stdout
        # Should show filename
        assert single_frame_file.name in output
        # Should show frame and channel counts
        assert "Frames:" in output
        assert "Channels:" in output
        # Should show compression
        assert "Compression:" in output
        # Should show GPS range
        assert "GPS:" in output
        # Should NOT show channel listing or frame table
        assert "CHAN1" not in output

    def test_inspect_verbose_1(self, single_frame_file):
        """Test inspect -v shows channel listing."""
        result = runner.invoke(app, ["inspect", "-v", str(single_frame_file)])
        assert result.exit_code == 0, result.stdout

        output = result.stdout
        # Should show file summary
        assert "Frames:" in output
        # Should show channel listing with names
        assert "L1:CHAN1" in output
        assert "L1:CHAN2" in output
        assert "L1:CHAN3" in output
        # Should show channel type
        assert "proc" in output
        # Should NOT show per-frame table
        assert "Frame #" not in output

    def test_inspect_verbose_2(self, single_frame_file):
        """Test inspect -vv shows channels and per-frame table."""
        result = runner.invoke(app, ["inspect", "-vv", str(single_frame_file)])
        assert result.exit_code == 0, result.stdout

        output = result.stdout
        # Should show channel listing
        assert "L1:CHAN1" in output
        # Should show frame table
        assert "GPS Start" in output
        assert "Duration" in output
        # Should show frame name
        assert "TEST" in output

    def test_inspect_verbose_3(self, single_frame_file):
        """Test inspect -vvv shows detailed channel info and frame table."""
        result = runner.invoke(app, ["inspect", "-vvv", str(single_frame_file)])
        assert result.exit_code == 0, result.stdout

        output = result.stdout
        # Should show detailed channel table (not simple listing)
        assert "Dtype" in output
        assert "Rate (Hz)" in output
        assert "Samples" in output
        assert "Unit" in output
        # Should show channel names
        assert "L1:CHAN1" in output
        # Should show frame table
        assert "GPS Start" in output

    def test_inspect_multiframe(self, multi_frame_file):
        """Test inspect on multi-frame file."""
        result = runner.invoke(app, ["inspect", str(multi_frame_file)])
        assert result.exit_code == 0, result.stdout

        output = result.stdout
        assert "Frames:" in output
        # Multi-frame file has 3 frames
        assert "3" in output

    def test_inspect_multiframe_verbose(self, multi_frame_file):
        """Test inspect -vv on multi-frame file shows all frames."""
        result = runner.invoke(app, ["inspect", "-vv", str(multi_frame_file)])
        assert result.exit_code == 0, result.stdout

        output = result.stdout
        # Should list all 3 frames in frame table
        assert "GPS Start" in output

    def test_inspect_file_size(self, single_frame_file):
        """Test inspect shows file size."""
        result = runner.invoke(app, ["inspect", str(single_frame_file)])
        assert result.exit_code == 0, result.stdout

        # Should show size in some unit (B, KB, MB, GB)
        output = result.stdout
        assert any(unit in output for unit in (" B", " KB", " MB", " GB"))

    def test_inspect_gps_range(self, single_frame_file, sample_data):
        """Test inspect shows correct GPS range."""
        result = runner.invoke(app, ["inspect", str(single_frame_file)])
        assert result.exit_code == 0, result.stdout

        output = result.stdout
        # Should contain the GPS start time
        assert str(int(sample_data["t0"])) in output

    def test_inspect_channel_types(self, tmp_path):
        """Test inspect correctly shows different channel types."""
        test_file = tmp_path / "mixed_types.gwf"

        frame = gwframe.Frame(start=1234567890.0, duration=1.0, name="L1", run=1)
        frame.add_channel(
            "L1:ADC_CHAN",
            np.arange(100, dtype=np.float32),
            sample_rate=100,
            channel_type="adc",
        )
        frame.add_channel(
            "L1:PROC_CHAN",
            np.arange(100, dtype=np.float64),
            sample_rate=100,
            channel_type="proc",
        )
        frame.write(str(test_file))

        result = runner.invoke(app, ["inspect", "-v", str(test_file)])
        assert result.exit_code == 0, result.stdout

        output = result.stdout
        assert "L1:ADC_CHAN" in output
        assert "L1:PROC_CHAN" in output
        assert "adc" in output
        assert "proc" in output

    def test_inspect_channel_type_counts(self, tmp_path):
        """Test inspect summary shows type counts."""
        test_file = tmp_path / "type_counts.gwf"

        frame = gwframe.Frame(start=1234567890.0, duration=1.0, name="L1", run=1)
        frame.add_channel(
            "L1:ADC1",
            np.arange(100, dtype=np.float32),
            sample_rate=100,
            channel_type="adc",
        )
        frame.add_channel(
            "L1:PROC1",
            np.arange(100, dtype=np.float64),
            sample_rate=100,
            channel_type="proc",
        )
        frame.add_channel(
            "L1:PROC2",
            np.arange(100, dtype=np.float64),
            sample_rate=100,
            channel_type="proc",
        )
        frame.write(str(test_file))

        result = runner.invoke(app, ["inspect", str(test_file)])
        assert result.exit_code == 0, result.stdout

        output = result.stdout
        assert "1 adc" in output
        assert "2 proc" in output

    def test_inspect_detailed_channel_info(self, tmp_path):
        """Test inspect -vvv shows correct per-channel details."""
        test_file = tmp_path / "detail.gwf"

        frame = gwframe.Frame(start=1234567890.0, duration=1.0, name="L1", run=1)
        data = np.arange(16384, dtype=np.float64)
        frame.add_channel(
            "L1:STRAIN", data, sample_rate=16384, unit="strain", channel_type="proc"
        )
        frame.write(str(test_file))

        result = runner.invoke(app, ["inspect", "-vvv", str(test_file)])
        assert result.exit_code == 0, result.stdout

        output = result.stdout
        assert "L1:STRAIN" in output
        assert "float64" in output
        assert "16384" in output  # sample rate or sample count
        assert "strain" in output

    def test_inspect_many_frames_truncation(self, tmp_path):
        """Test inspect -vv truncates frame table for large files."""
        test_file = tmp_path / "many_frames.gwf"

        with gwframe.FrameWriter(str(test_file)) as writer:
            for i in range(50):
                data = np.zeros(16, dtype=np.float32)
                writer.write(
                    data,
                    start=1234567890.0 + i,
                    sample_rate=16,
                    name="L1:TEST",
                    unit="counts",
                )

        result = runner.invoke(app, ["inspect", "-vv", str(test_file)])
        assert result.exit_code == 0, result.stdout

        output = result.stdout
        # Should show truncation indicator
        assert "more" in output.lower()

    def test_inspect_nonexistent_file(self, tmp_path):
        """Test inspect with nonexistent file."""
        result = runner.invoke(app, ["inspect", str(tmp_path / "nonexistent.gwf")])
        assert result.exit_code != 0

    def test_inspect_invalid_file(self, tmp_path):
        """Test inspect with invalid (non-GWF) file."""
        bad_file = tmp_path / "bad.gwf"
        bad_file.write_bytes(b"not a gwf file")

        result = runner.invoke(app, ["inspect", str(bad_file)])
        assert result.exit_code != 0

    def test_inspect_empty_frame(self, tmp_path):
        """Test inspect on a frame with no channels."""
        test_file = tmp_path / "empty.gwf"

        frame = gwframe.Frame(start=1234567890.0, duration=1.0, name="L1", run=1)
        frame.write(str(test_file))

        result = runner.invoke(app, ["inspect", str(test_file)])
        assert result.exit_code == 0, result.stdout

        output = result.stdout
        assert "Channels:" in output
        # Should show 0 channels
        assert "0" in output

    def test_inspect_sections_order_verbose_3(self, single_frame_file):
        """Test that at -vvv, channels section appears before frames section."""
        result = runner.invoke(app, ["inspect", "-vvv", str(single_frame_file)])
        assert result.exit_code == 0, result.stdout

        output = result.stdout
        # Find the section rule headers (not the summary line "Frames: N")
        # The rule headers contain the word surrounded by rule characters
        lines = output.split("\n")
        channels_line = next(
            (
                i
                for i, line in enumerate(lines)
                if "Channels" in line and "Dtype" not in line and ":" not in line
            ),
            None,
        )
        frames_line = next(
            (i for i, line in enumerate(lines) if "Frames" in line and ":" not in line),
            None,
        )
        # Both section headers should exist
        assert channels_line is not None
        assert frames_line is not None
        # Channels section should come before Frames section
        assert channels_line < frames_line


class TestReplaceCommand:
    """Tests for gwframe replace command."""

    def test_replace_basic(self, tmp_path, sample_data, create_test_frame):
        """Replace a channel's data from an update file."""
        n_samples = sample_data["n_samples"]
        base_file = tmp_path / "base.gwf"
        update_file = tmp_path / "update.gwf"
        output_dir = tmp_path / "output"

        base_data = np.zeros(n_samples, dtype=np.float32)
        update_data = np.ones(n_samples, dtype=np.float32)

        with gwframe.FrameWriter(str(base_file)) as writer:
            frame = create_test_frame(
                sample_data["t0"],
                sample_data["duration"],
                {"L1:CHAN1": base_data, "L1:CHAN2": base_data * 2},
            )
            writer.write_frame(frame)

        with gwframe.FrameWriter(str(update_file)) as writer:
            frame = create_test_frame(
                sample_data["t0"],
                sample_data["duration"],
                {"L1:CHAN1": update_data},
            )
            writer.write_frame(frame)

        result = runner.invoke(
            app,
            [
                "replace",
                str(base_file),
                "--update",
                str(update_file),
                "-o",
                str(output_dir),
                "-c",
                "L1:CHAN1",
            ],
        )

        assert result.exit_code == 0, result.stdout

        output_file = output_dir / base_file.name
        assert output_file.exists()

        # Replaced channel should match the update file
        replaced = gwframe.read(str(output_file), "L1:CHAN1")
        np.testing.assert_array_equal(update_data, replaced.array)

        # Untouched channel should still match the base
        untouched = gwframe.read(str(output_file), "L1:CHAN2")
        np.testing.assert_array_equal(base_data * 2, untouched.array)

    def test_replace_empty_base_directory(
        self, tmp_path, sample_data, create_test_frame
    ):
        """An empty base directory should exit 1 with 'No base files found'."""
        empty_base = tmp_path / "empty_base"
        empty_base.mkdir()

        update_file = tmp_path / "update.gwf"
        with gwframe.FrameWriter(str(update_file)) as writer:
            frame = create_test_frame(
                sample_data["t0"],
                sample_data["duration"],
                {"L1:CHAN1": np.ones(sample_data["n_samples"], dtype=np.float32)},
            )
            writer.write_frame(frame)

        result = runner.invoke(
            app,
            [
                "replace",
                str(empty_base),
                "--update",
                str(update_file),
                "-o",
                str(tmp_path / "out"),
            ],
        )
        assert result.exit_code == 1
        assert "No base files found" in result.stdout

    def test_replace_empty_update_directory(
        self, tmp_path, sample_data, create_test_frame
    ):
        """An empty update directory should exit 1 with 'No update files found'."""
        base_file = tmp_path / "base.gwf"
        with gwframe.FrameWriter(str(base_file)) as writer:
            frame = create_test_frame(
                sample_data["t0"],
                sample_data["duration"],
                {"L1:CHAN1": np.zeros(sample_data["n_samples"], dtype=np.float32)},
            )
            writer.write_frame(frame)

        empty_update = tmp_path / "empty_update"
        empty_update.mkdir()

        result = runner.invoke(
            app,
            [
                "replace",
                str(base_file),
                "--update",
                str(empty_update),
                "-o",
                str(tmp_path / "out"),
            ],
        )
        assert result.exit_code == 1
        assert "No update files found" in result.stdout


class TestRecompressInvalidCompression:
    """cli.py:789-794 — invalid compression string should exit cleanly."""

    def test_recompress_rejects_unknown_compression(self, single_frame_file, tmp_path):
        result = runner.invoke(
            app,
            [
                "recompress",
                str(single_frame_file),
                "-o",
                str(tmp_path / "out"),
                "-c",
                "NOTACOMPRESSION",
            ],
        )
        assert result.exit_code == 1
        assert "Invalid compression type" in result.stdout


class TestOutputOptionValidation:
    """CLI validation for mutually-exclusive --in-place and --output-dir."""

    def test_rename_rejects_in_place_and_output_dir(self, single_frame_file, tmp_path):
        """Passing both --in-place and --output-dir should exit non-zero."""
        result = runner.invoke(
            app,
            [
                "rename",
                str(single_frame_file),
                "--in-place",
                "--output-dir",
                str(tmp_path / "out"),
                "-m",
                "L1:CHAN1=>L1:RENAMED",
            ],
        )
        assert result.exit_code == 1
        assert "mutually exclusive" in result.stdout


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
