# Copyright (c) 2025, California Institute of Technology and contributors
#
# You should have received a copy of the licensing terms for this
# software included in the file "LICENSE" located in the top-level
# directory of this package. If you did not, you can view a copy at
# https://git.ligo.org/olivia.godwin/gwframe/-/raw/main/LICENSE

"""Data types and constants for gwframe."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, IntEnum
from typing import TYPE_CHECKING

import numpy as np

from . import _core  # type: ignore[attr-defined]

if TYPE_CHECKING:
    import numpy.typing as npt


class DetectorLocation(IntEnum):
    """
    Detector location identifiers for GWF files.

    These constants identify specific gravitational wave detectors
    and are used with the GetDetector function.

    - G1: GEO600 (Germany)
    - H1: LIGO Hanford 4km (USA)
    - H2: LIGO Hanford 2km (USA, decommissioned)
    - K1: KAGRA (Japan)
    - L1: LIGO Livingston 4km (USA)
    - T1: TAMA300 (Japan, decommissioned)
    - V1: Virgo (Italy)
    """

    G1 = _core.DETECTOR_LOCATION_G1  # GEO600
    H1 = _core.DETECTOR_LOCATION_H1  # LIGO Hanford 4km
    H2 = _core.DETECTOR_LOCATION_H2  # LIGO Hanford 2km (decommissioned)
    K1 = _core.DETECTOR_LOCATION_K1  # KAGRA
    L1 = _core.DETECTOR_LOCATION_L1  # LIGO Livingston 4km
    T1 = _core.DETECTOR_LOCATION_T1  # TAMA300 (decommissioned)
    V1 = _core.DETECTOR_LOCATION_V1  # Virgo


class ChannelType(str, Enum):
    """
    Channel data types in GWF files.

    - PROC: Processed data (FrProcData)
    - ADC: Raw ADC data (FrAdcData)
    - SIM: Simulated data (FrSimData)
    """

    PROC = "proc"
    ADC = "adc"
    SIM = "sim"


class Compression(IntEnum):
    """
    Compression schemes for GWF files.

    See LIGO-T970130 for details on compression algorithms.

    Standard modes:
    - RAW: No compression
    - GZIP: Standard GZIP compression
    - DIFF_GZIP: Differentiate data then apply GZIP
    - ZERO_SUPPRESS_WORD_2: Zero-suppress 2-byte (16-bit) words
    - ZERO_SUPPRESS_WORD_4: Zero-suppress 4-byte (32-bit) words
    - ZERO_SUPPRESS_WORD_8: Zero-suppress 8-byte (64-bit) words

    Meta modes (adaptive):
    - ZERO_SUPPRESS_OTHERWISE_GZIP: Zero-suppress integers, GZIP floats (recommended)
    - BEST_COMPRESSION: Try all modes, use best compression ratio

    Aliases:
    - ZERO_SUPPRESS_SHORT: Alias for ZERO_SUPPRESS_WORD_2
    - ZERO_SUPPRESS_INT_FLOAT: Alias for ZERO_SUPPRESS_WORD_4
    """

    # Standard compression modes
    RAW = _core.FrVect.RAW
    GZIP = _core.FrVect.GZIP
    DIFF_GZIP = _core.FrVect.DIFF_GZIP
    ZERO_SUPPRESS_WORD_2 = _core.FrVect.ZERO_SUPPRESS_WORD_2
    ZERO_SUPPRESS_WORD_4 = _core.FrVect.ZERO_SUPPRESS_WORD_4
    ZERO_SUPPRESS_WORD_8 = _core.FrVect.ZERO_SUPPRESS_WORD_8

    # Meta compression modes (adaptive)
    ZERO_SUPPRESS_OTHERWISE_GZIP = _core.FrVect.ZERO_SUPPRESS_OTHERWISE_GZIP
    BEST_COMPRESSION = _core.FrVect.BEST_COMPRESSION

    # Backward compatibility aliases
    ZERO_SUPPRESS_SHORT = _core.FrVect.ZERO_SUPPRESS_SHORT
    ZERO_SUPPRESS_INT_FLOAT = _core.FrVect.ZERO_SUPPRESS_INT_FLOAT


_DTYPE_TO_FRVECT: dict[np.dtype, int] = {
    np.dtype("float64"): _core.FrVect.FR_VECT_8R,
    np.dtype("float32"): _core.FrVect.FR_VECT_4R,
    np.dtype("int32"): _core.FrVect.FR_VECT_4S,
    np.dtype("int16"): _core.FrVect.FR_VECT_2S,
    np.dtype("int64"): _core.FrVect.FR_VECT_8S,
    np.dtype("uint8"): _core.FrVect.FR_VECT_1U,
    np.dtype("uint16"): _core.FrVect.FR_VECT_2U,
    np.dtype("uint32"): _core.FrVect.FR_VECT_4U,
    np.dtype("uint64"): _core.FrVect.FR_VECT_8U,
    np.dtype("complex64"): _core.FrVect.FR_VECT_8C,
    np.dtype("complex128"): _core.FrVect.FR_VECT_16C,
}

_FRVECT_TO_DTYPE: dict[int, np.dtype] = {v: k for k, v in _DTYPE_TO_FRVECT.items()}


def frvect_to_dtype(code: int) -> np.dtype:
    """Map a frameCPP FrVect type code to a NumPy dtype.

    Raises
    ------
    ValueError
        If the code does not correspond to a NumPy-representable type.
    """
    try:
        return _FRVECT_TO_DTYPE[code]
    except KeyError as exc:
        msg = f"Unsupported frameCPP vector type code: {code}"
        raise ValueError(msg) from exc


class OnMaskLoss(str, Enum):
    """Behavior when mask information cannot be preserved in the frame format.

    On frame spec versions < 9, only ADC channels support a (channel-level)
    data-valid flag. Proc and sim channels have no masking support, and ADC
    masking is per-channel (not per-sample). This enum controls what happens
    when a masked array is written to a channel type that cannot preserve the
    full mask.
    """

    WARN = "warn"
    RAISE = "raise"
    IGNORE = "ignore"


class FrameSpec(IntEnum):
    """Frame specification version for GWF files.

    Controls which version of the frame format is used when writing:

    - V8: Frame spec v8 (default). ADC channels support a channel-level
      data-valid flag; proc/sim channels have no masking support.
    """

    V8 = 8


class FrProcDataType(IntEnum):
    """
    Type classification for FrProcData structures.

    Indicates the dimensionality and structure of processed data.
    """

    UNKNOWN = _core.FrProcData.UNKNOWN_TYPE
    TIME_SERIES = _core.FrProcData.TIME_SERIES
    FREQUENCY_SERIES = _core.FrProcData.FREQUENCY_SERIES
    OTHER_1D_SERIES_DATA = _core.FrProcData.OTHER_1D_SERIES_DATA
    TIME_FREQUENCY = _core.FrProcData.TIME_FREQUENCY
    WAVELETS = _core.FrProcData.WAVELETS
    MULTI_DIMENSIONAL = _core.FrProcData.MULTI_DIMENSIONAL


class FrProcDataSubType(IntEnum):
    """
    Subtype classification for FrProcData structures.

    Provides detailed information about the data processing or analysis type.
    """

    UNKNOWN = _core.FrProcData.UNKNOWN_SUB_TYPE
    DFT = _core.FrProcData.DFT
    AMPLITUDE_SPECTRAL_DENSITY = _core.FrProcData.AMPLITUDE_SPECTRAL_DENSITY
    POWER_SPECTRAL_DENSITY = _core.FrProcData.POWER_SPECTRAL_DENSITY
    CROSS_SPECTRAL_DENSITY = _core.FrProcData.CROSS_SPECTRAL_DENSITY
    COHERENCE = _core.FrProcData.COHERENCE
    TRANSFER_FUNCTION = _core.FrProcData.TRANSFER_FUNCTION


@dataclass(slots=True, frozen=True)
class FrameInfo:
    """
    Metadata about a single frame in a GWF file.

    This dataclass holds metadata for a frame without the actual channel data.

    Attributes
    ----------
    index : int
        Frame index in the file (0-based)
    start : float
        Start time in GPS seconds
    duration : float
        Frame duration in seconds
    name : str
        Frame name (e.g., 'H1', 'L1')
    run : int
        Run number (negative for simulated data)
    frame_number : int
        Frame sequence number

    Examples
    --------
    >>> info = gwframe.get_info('data.gwf')
    >>> frame = info.frames[0]
    >>> print(f"Frame {frame.index}: {frame.name} at GPS {frame.start}")
    """

    index: int
    start: float
    duration: float
    name: str
    run: int
    frame_number: int


@dataclass(slots=True, frozen=True)
class FrameFileInfo:
    """
    Complete metadata about a GWF file.

    This dataclass holds file-level and frame-level metadata for a GWF file.

    Attributes
    ----------
    num_frames : int
        Total number of frames in the file
    channels : list[str]
        List of all channel names in the file
    frames : list[FrameInfo]
        List of metadata for each frame
    compression : int
        Compression scheme used for all channels in the file (e.g., Compression.GZIP)
    frame_spec : int or None
        Frame specification version (e.g., 8). None if unknown.

    Examples
    --------
    >>> info = gwframe.get_info('data.gwf')
    >>> print(f"File contains {info.num_frames} frames")
    >>> print(f"Channels: {', '.join(info.channels)}")
    >>> print(f"Frame spec: v{info.frame_spec}")
    >>> print(f"Compression: {Compression(info.compression).name}")
    >>> # Preserve compression when writing
    >>> with FrameWriter('output.gwf', **info.compression_settings) as writer:
    ...     pass
    """

    num_frames: int
    channels: list[str]
    frames: list[FrameInfo]
    compression: int
    frame_spec: int | None = None

    @property
    def compression_settings(self) -> dict[str, int]:
        """
        Return compression settings as kwargs for FrameWriter.

        Returns
        -------
        dict[str, int]
            Compression settings suitable for FrameWriter constructor

        Examples
        --------
        >>> info = gwframe.get_info('input.gwf')
        >>> with gwframe.FrameWriter(
        ...     'output.gwf', **info.compression_settings
        ... ) as writer:
        ...     # Frames written with same compression as input file
        ...     pass
        """
        return {"compression": self.compression}


@dataclass(slots=True, frozen=True)
class TimeSeries:
    """
    Time series data from a GWF channel.

    This dataclass holds the array data and metadata for a channel read from
    a GWF file.

    Attributes
    ----------
    array : np.ndarray
        NumPy array containing the time series data
    name : str
        Channel name (e.g., 'H1:LOSC-STRAIN')
    dtype : np.dtype
        NumPy dtype of the samples. Always mirrors ``array.dtype``.
    start : float
        Start time in GPS seconds
    dt : float
        Sample spacing in seconds
    duration : float
        Total duration in seconds
    sample_rate : float
        Sampling rate in Hz (1/dt)
    unit : str
        Physical unit of the data (e.g., 'strain')
    type : str
        Channel type: 'proc' (processed), 'adc' (raw ADC), or 'sim' (simulated)
    mask : np.ndarray or None
        Boolean mask where ``True`` indicates invalid samples. ``None`` when
        all samples are valid. Only populated when reading with
        ``allow_invalid=True`` and the file contains dataValid flags.

    Examples
    --------
    >>> data = gwframe.read('data.gwf', 'H1:LOSC-STRAIN')
    >>> print(f"Channel: {data.name}")
    >>> print(f"Duration: {data.duration} s at {data.sample_rate} Hz")
    >>> print(f"Data shape: {data.array.shape}")
    >>> # Check for invalid samples
    >>> if data.mask is not None:
    ...     print(f"Invalid samples: {data.mask.sum()}")
    """

    array: npt.NDArray[np.floating]
    name: str
    dtype: np.dtype
    start: float
    dt: float
    duration: float
    sample_rate: float
    unit: str
    type: str
    mask: npt.NDArray[np.bool_] | None = None

    def to_masked(self) -> npt.NDArray[np.floating] | np.ma.MaskedArray:
        """Return data as a masked array if a mask is present, otherwise plain array.

        This is useful when passing data to APIs that understand masked arrays,
        or when you want numpy operations to automatically skip invalid samples.

        Returns
        -------
        np.ma.MaskedArray or np.ndarray
            Masked array if ``mask`` is set, plain array otherwise.
        """
        if self.mask is not None:
            return np.ma.MaskedArray(self.array, mask=self.mask)
        return self.array
