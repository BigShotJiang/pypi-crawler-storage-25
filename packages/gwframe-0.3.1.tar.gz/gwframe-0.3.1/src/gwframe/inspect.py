# Copyright (c) 2025, California Institute of Technology and contributors
#
# You should have received a copy of the licensing terms for this
# software included in the file "LICENSE" located in the top-level
# directory of this package. If you did not, you can view a copy at
# https://git.ligo.org/olivia.godwin/gwframe/-/raw/main/LICENSE

"""File inspection and metadata functions."""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from os import PathLike, fspath
from typing import TYPE_CHECKING

from . import _core  # type: ignore[attr-defined]
from .types import Compression, FrameFileInfo, FrameInfo, frvect_to_dtype

if TYPE_CHECKING:
    import numpy as np


@dataclass(slots=True, frozen=True)
class ChannelInfo:
    """
    Metadata about a single channel in a GWF file.

    Attributes
    ----------
    name : str
        Channel name (e.g., 'H1:LOSC-STRAIN')
    type : str
        Channel type: 'adc', 'proc', or 'sim'
    dtype : np.dtype
        NumPy dtype of the channel samples (e.g., ``np.dtype('float64')``).
    sample_rate : float
        Sampling rate in Hz
    n_samples : int
        Number of samples in the channel
    unit : str
        Physical unit of the data (e.g., 'strain')
    """

    name: str
    type: str
    dtype: np.dtype
    sample_rate: float
    n_samples: int
    unit: str

    @property
    def dtype_name(self) -> str:
        """Human-readable name for the data type (e.g., 'float64')."""
        return self.dtype.name


def get_channels(filename: str | PathLike[str]) -> list[str]:
    """
    Get a list of all channels in a GWF file.

    Parameters
    ----------
    filename : str or path-like
        Path to the GWF file

    Returns
    -------
    channels : list[str]
        List of all channel names

    Examples
    --------
    >>> channels = gwframe.get_channels('data.gwf')
    >>> print(f"Found {len(channels)} channels")
    >>> for channel in channels:
    ...     print(channel)
    """
    stream = _core.IFrameFStream(fspath(filename))
    toc = stream.get_toc()
    return [*toc.get_adc(), *toc.get_proc(), *toc.get_sim()]


def get_channels_by_type(
    filename: str | PathLike[str],
) -> dict[str, list[str]]:
    """
    Get channel names grouped by type (adc, proc, sim).

    Parameters
    ----------
    filename : str or path-like
        Path to the GWF file

    Returns
    -------
    channels : dict[str, list[str]]
        Dictionary with keys 'adc', 'proc', 'sim' mapping to channel name lists

    Examples
    --------
    >>> by_type = gwframe.get_channels_by_type('data.gwf')
    >>> print(f"ADC channels: {len(by_type['adc'])}")
    >>> print(f"Proc channels: {len(by_type['proc'])}")
    """
    stream = _core.IFrameFStream(fspath(filename))
    toc = stream.get_toc()
    return {
        "adc": list(toc.get_adc()),
        "proc": list(toc.get_proc()),
        "sim": list(toc.get_sim()),
    }


def get_channel_details(
    filename: str | PathLike[str],
    frame_index: int = 0,
) -> list[ChannelInfo]:
    """
    Get detailed metadata for all channels in a GWF file.

    Reads channel headers (without decompressing data) to extract sample rate,
    data type, sample count, and units for each channel.

    Parameters
    ----------
    filename : str or path-like
        Path to the GWF file
    frame_index : int, optional
        Frame index to read metadata from (default: 0)

    Returns
    -------
    details : list[ChannelInfo]
        List of channel metadata, ordered by type (adc, proc, sim)

    Examples
    --------
    >>> details = gwframe.get_channel_details('data.gwf')
    >>> for ch in details:
    ...     print(f"{ch.name}: {ch.dtype_name} @ {ch.sample_rate} Hz")
    """
    path = fspath(filename)
    stream = _core.IFrameFStream(path)
    toc = stream.get_toc()
    return _get_channel_details_from_stream(stream, toc, frame_index)


def _get_channel_details_from_stream(
    stream: _core.IFrameFStream,
    toc: _core.FrTOC,
    frame_index: int = 0,
) -> list[ChannelInfo]:
    """Build list of ChannelInfo from an already-open stream and TOC."""
    results: list[ChannelInfo] = []
    type_readers = [
        ("adc", list(toc.get_adc()), stream.read_fr_adc_data),
        ("proc", list(toc.get_proc()), stream.read_fr_proc_data),
        ("sim", list(toc.get_sim()), stream.read_fr_sim_data),
    ]

    for ch_type, ch_names, reader in type_readers:
        for ch_name in ch_names:
            fr_data = reader(frame_index, ch_name)

            sample_rate = (
                fr_data.get_sample_rate() if ch_type in ("adc", "sim") else None
            )

            vect = fr_data.get_data_vector(0)

            if sample_rate is None and vect.get_n_dim() > 0:
                dim = vect.get_dim(0)
                dx = dim.dx
                sample_rate = 1.0 / dx if dx > 0 else 0.0

            results.append(
                ChannelInfo(
                    name=ch_name,
                    type=ch_type,
                    dtype=frvect_to_dtype(vect.get_type()),
                    sample_rate=sample_rate or 0.0,
                    n_samples=vect.get_n_data(),
                    unit=vect.get_unit_y(),
                )
            )

    return results


def _detect_compression(stream: _core.IFrameFStream, toc: _core.FrTOC) -> int:
    """
    Detect file-level compression scheme from available channels.

    Compression is set at the stream level when writing frames, so all channels
    should use the same compression scheme. However, very small data arrays may
    be left uncompressed (RAW) even when compression is specified, as the
    compression overhead would exceed any space savings. This function samples
    multiple channels and prefers non-RAW schemes to identify the intended
    file-level compression that should be used when writing similar files.

    Parameters
    ----------
    stream : IFrameFStream
        Open frame file stream
    toc : FrTOC
        Table of contents for the file

    Returns
    -------
    int
        Compression scheme value (e.g., Compression.GZIP, Compression.RAW)
    """
    compression_schemes = []

    # Sample channels by type: (channel_list, read_method)
    channel_types = [
        (toc.get_proc(), stream.read_fr_proc_data),
        (toc.get_adc(), stream.read_fr_adc_data),
        (toc.get_sim(), stream.read_fr_sim_data),
    ]

    for channel_list, read_method in channel_types:
        # Sample up to 5 channels of this type
        for channel_name in channel_list[:5]:
            try:
                fr_data = read_method(0, channel_name)
                vect = fr_data.get_data_vector(0)

                # Quick check: if not compressed, it's RAW
                if not vect.is_compressed():
                    compression_schemes.append(Compression.RAW.value)
                else:
                    # Get the actual compression scheme
                    compression_schemes.append(vect.get_compression_scheme())
            except Exception:  # noqa: BLE001, S112
                # Skip channels that fail to read
                continue

    # If we found compression schemes, pick the best one
    if compression_schemes:
        # Prefer non-RAW compression (RAW might just be from small data)
        non_raw = [c for c in compression_schemes if c != Compression.RAW.value]
        if non_raw:
            # Return the most common non-RAW compression
            return Counter(non_raw).most_common(1)[0][0]
        # If everything is RAW, return RAW
        return Compression.RAW.value

    # Default to RAW if no channels found
    return Compression.RAW.value


def get_info(filename: str | PathLike[str]) -> FrameFileInfo:
    """
    Get metadata about a GWF file.

    Parameters
    ----------
    filename : str or path-like
        Path to the GWF file

    Returns
    -------
    info : FrameFileInfo
        Structured metadata containing:
        - num_frames: number of frames in file
        - channels: list of all channel names
        - frames: list of FrameInfo objects with complete frame metadata

    Examples
    --------
    >>> info = gwframe.get_info('data.gwf')
    >>> print(f"File contains {info.num_frames} frames")
    >>> print(f"Frame 0: {info.frames[0].name} at GPS {info.frames[0].start}")
    >>> print(f"Channels: {', '.join(info.channels)}")
    """
    stream = _core.IFrameFStream(fspath(filename))
    toc = stream.get_toc()
    return _build_info_from_stream(stream, toc, fspath(filename))


def _build_info_from_stream(
    stream: _core.IFrameFStream,
    toc: _core.FrTOC,
    source_path: str,
) -> FrameFileInfo:
    """Build FrameFileInfo from an already-open stream and TOC."""
    num_frames = stream.get_number_of_frames()

    # Get all channels
    channels = [*toc.get_adc(), *toc.get_proc(), *toc.get_sim()]

    # Detect compression from first available channel in first frame
    compression = _detect_compression(stream, toc)

    # Detect frame specification version
    try:
        frame_spec = int(stream.get_version())
    except (AttributeError, RuntimeError):
        frame_spec = None

    # Read each frame header to get complete metadata
    frames = []
    for i in range(num_frames):
        # Read frame header
        frame_h = stream.read_frame_n(i)

        # Extract metadata from frame header
        time = frame_h.get_gps_time()
        gps_start = float(time.sec) + float(time.nsec) * 1e-9

        frames.append(
            FrameInfo(
                index=i,
                start=gps_start,
                duration=frame_h.get_dt(),
                name=frame_h.get_name(),
                run=frame_h.get_run(),
                frame_number=frame_h.get_frame(),
            )
        )

    return FrameFileInfo(
        num_frames=num_frames,
        channels=channels,
        frames=frames,
        compression=compression,
        frame_spec=frame_spec,
    )
