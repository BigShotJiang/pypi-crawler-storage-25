"""
crunr GPU demo — trains a small ResNet-style CNN for ~5 minutes on a T4 GPU.
Cost: < $0.02 on g4dn.xlarge spot.

No requirements.txt needed — PyTorch ships pre-installed on AWS Deep Learning AMIs.

Run with:
    crunr run demo.py --gpu --instance g4dn.xlarge --s3-bucket crunr-yourname-outputs
"""

import json
import time
from pathlib import Path

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset

# ---------------------------------------------------------------------------
# Setup
# ---------------------------------------------------------------------------

Path("outputs").mkdir(exist_ok=True)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("=" * 52)
print("  crunr GPU Demo — ResNet-style CNN Training")
print("=" * 52)
print(f"  Device  : {device}")
if device.type == "cuda":
    props = torch.cuda.get_device_properties(0)
    print(f"  GPU     : {props.name}")
    print(f"  VRAM    : {props.total_memory / 1e9:.1f} GB")
    print(f"  CUDA    : {torch.version.cuda}")
print(f"  PyTorch : {torch.__version__}")
print()

# ---------------------------------------------------------------------------
# Synthetic dataset  (32×32 colour images, 10 classes)
# Avoids download latency while keeping realistic tensor shapes and sizes.
# ---------------------------------------------------------------------------

NUM_TRAIN = 50_000
NUM_TEST  =  5_000
IMG_SIZE  = 32
CLASSES   = 10
BATCH     = 256
EPOCHS    = 12      # ~5 min on g4dn.xlarge (T4)

print(f"Generating dataset  ({NUM_TRAIN:,} train / {NUM_TEST:,} test)  ...")
torch.manual_seed(42)

X_train = torch.randn(NUM_TRAIN, 3, IMG_SIZE, IMG_SIZE)
y_train = torch.randint(0, CLASSES, (NUM_TRAIN,))
X_test  = torch.randn(NUM_TEST,  3, IMG_SIZE, IMG_SIZE)
y_test  = torch.randint(0, CLASSES, (NUM_TEST,))

train_loader = DataLoader(
    TensorDataset(X_train, y_train),
    batch_size=BATCH, shuffle=True, pin_memory=(device.type == "cuda"),
)
test_loader = DataLoader(
    TensorDataset(X_test, y_test),
    batch_size=BATCH, shuffle=False, pin_memory=(device.type == "cuda"),
)
print(f"Batches     : {len(train_loader)} train / {len(test_loader)} test")
print()

# ---------------------------------------------------------------------------
# Model — small ResNet-style CNN (~1.2 M params)
# ---------------------------------------------------------------------------

class ResBlock(nn.Module):
    def __init__(self, channels: int) -> None:
        super().__init__()
        self.body = nn.Sequential(
            nn.Conv2d(channels, channels, 3, padding=1, bias=False),
            nn.BatchNorm2d(channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels, channels, 3, padding=1, bias=False),
            nn.BatchNorm2d(channels),
        )
        self.act = nn.ReLU(inplace=True)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.act(self.body(x) + x)


def build_model(num_classes: int = 10) -> nn.Module:
    return nn.Sequential(
        # stem
        nn.Conv2d(3, 64, 3, padding=1, bias=False),
        nn.BatchNorm2d(64),
        nn.ReLU(inplace=True),
        ResBlock(64),
        # stage 2 — downsample
        nn.Conv2d(64, 128, 3, stride=2, padding=1, bias=False),
        nn.BatchNorm2d(128),
        nn.ReLU(inplace=True),
        ResBlock(128),
        # stage 3 — downsample
        nn.Conv2d(128, 256, 3, stride=2, padding=1, bias=False),
        nn.BatchNorm2d(256),
        nn.ReLU(inplace=True),
        ResBlock(256),
        # head
        nn.AdaptiveAvgPool2d(1),
        nn.Flatten(),
        nn.Linear(256, num_classes),
    )


model = build_model(CLASSES).to(device)
total_params = sum(p.numel() for p in model.parameters())
print(f"Model params: {total_params:,}")

criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=1e-3)
scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=EPOCHS)

# ---------------------------------------------------------------------------
# Training loop
# ---------------------------------------------------------------------------

history = []
job_start = time.time()

header = f"{'Epoch':>5}  {'Train Loss':>10}  {'Train Acc':>9}  {'Val Acc':>7}  {'LR':>8}  {'Time':>6}"
print(header)
print("─" * len(header))

for epoch in range(1, EPOCHS + 1):
    t0 = time.time()

    # — train —
    model.train()
    total_loss = correct = seen = 0
    for xb, yb in train_loader:
        xb, yb = xb.to(device, non_blocking=True), yb.to(device, non_blocking=True)
        optimizer.zero_grad(set_to_none=True)
        logits = model(xb)
        loss = criterion(logits, yb)
        loss.backward()
        optimizer.step()
        total_loss += loss.item() * len(xb)
        correct    += (logits.argmax(1) == yb).sum().item()
        seen       += len(xb)

    train_loss = total_loss / seen
    train_acc  = correct / seen

    # — validate —
    model.eval()
    correct = seen = 0
    with torch.no_grad():
        for xb, yb in test_loader:
            xb, yb = xb.to(device, non_blocking=True), yb.to(device, non_blocking=True)
            correct += (model(xb).argmax(1) == yb).sum().item()
            seen    += len(xb)
    val_acc = correct / seen

    scheduler.step()
    current_lr = scheduler.get_last_lr()[0]
    epoch_time = time.time() - t0

    print(
        f"{epoch:>5}  {train_loss:>10.4f}  {train_acc:>8.1%}  "
        f"{val_acc:>6.1%}  {current_lr:>8.2e}  {epoch_time:>5.1f}s"
    )

    history.append({
        "epoch":      epoch,
        "train_loss": round(train_loss, 6),
        "train_acc":  round(train_acc,  6),
        "val_acc":    round(val_acc,    6),
        "lr":         round(current_lr, 8),
        "elapsed_s":  round(epoch_time, 2),
    })

total_time = time.time() - job_start

# ---------------------------------------------------------------------------
# Save outputs
# ---------------------------------------------------------------------------

# Model checkpoint
torch.save(model.state_dict(), "outputs/model.pt")
print("\nSaved  outputs/model.pt")

# Full training history as JSON (load in notebook for plotting)
Path("outputs/history.json").write_text(json.dumps(history, indent=2))
print("Saved  outputs/history.json")

# Human-readable summary
best = max(history, key=lambda r: r["val_acc"])
gpu_line = (
    f"{torch.cuda.get_device_name(0)}  ({torch.cuda.get_device_properties(0).total_memory / 1e9:.1f} GB VRAM)"
    if device.type == "cuda" else "CPU"
)

summary = f"""crunr GPU Demo — Training Summary
==================================
Device         : {gpu_line}
PyTorch        : {torch.__version__}
Model params   : {total_params:,}
Dataset        : {NUM_TRAIN:,} train  /  {NUM_TEST:,} test  (synthetic 32x32 RGB)
Epochs trained : {EPOCHS}
Total time     : {total_time / 60:.1f} min  ({total_time:.0f}s)

Best val acc   : {best['val_acc']:.2%}  (epoch {best['epoch']})
Final val acc  : {history[-1]['val_acc']:.2%}
Final train acc: {history[-1]['train_acc']:.2%}
Final loss     : {history[-1]['train_loss']:.4f}

Outputs
-------
  outputs/model.pt       model weights
  outputs/history.json   per-epoch metrics (loss, acc, lr)
  outputs/summary.txt    this report
"""

Path("outputs/summary.txt").write_text(summary)
print("Saved  outputs/summary.txt")

print()
print(summary)
