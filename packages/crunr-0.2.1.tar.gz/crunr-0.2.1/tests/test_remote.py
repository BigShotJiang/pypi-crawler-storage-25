"""Tests for remote helpers (no live AWS needed)."""

import pytest
from crunr.remote import _shell_quote, _ssh_opts


def test_shell_quote_simple():
    assert _shell_quote("hello") == "'hello'"


def test_shell_quote_with_spaces():
    assert _shell_quote("hello world") == "'hello world'"


def test_shell_quote_with_single_quotes():
    # Standard POSIX escaping: 'it'\''s alive' — end quote, literal ', start quote
    result = _shell_quote("it's alive")
    # Must start/end with single quote and contain the POSIX escape sequence
    assert result.startswith("'")
    assert result.endswith("'")
    assert "it" in result and "alive" in result


def test_ssh_opts_contains_key():
    opts = _ssh_opts()
    assert "-i" in opts


def test_ssh_opts_no_strict_host_check():
    opts = _ssh_opts()
    combined = " ".join(opts)
    assert "StrictHostKeyChecking=no" in combined


def test_ssh_opts_no_known_hosts():
    import os
    opts = _ssh_opts()
    combined = " ".join(opts)
    assert f"UserKnownHostsFile={os.devnull}" in combined
