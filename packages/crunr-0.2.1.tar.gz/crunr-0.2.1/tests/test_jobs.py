"""Tests for jobs module."""

import json
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import patch

import pytest


def _make_dt(year=2025, month=1, day=1, hour=0, minute=0, second=0):
    return datetime(year, month, day, hour, minute, second, tzinfo=timezone.utc)


def test_generate_job_id_unique():
    from crunr.jobs import generate_job_id
    ids = {generate_job_id() for _ in range(100)}
    assert len(ids) == 100


def test_generate_job_id_length():
    from crunr.jobs import generate_job_id
    assert len(generate_job_id()) == 12


def test_record_writes_to_file(tmp_path):
    jobs_path = tmp_path / "jobs.json"
    runr_dir = tmp_path

    with patch("crunr.jobs._RUNR_DIR", runr_dir), patch("crunr.jobs._JOBS_PATH", jobs_path):
        from crunr import jobs as j
        result = j.record(
            job_id="abc123",
            command="python train.py",
            instance_type="t3.micro",
            instance_id="i-12345",
            spot=True,
            spot_price=0.01,
            started_at=_make_dt(hour=0),
            ended_at=_make_dt(hour=1),
            exit_code=0,
            region="us-east-1",
            profile="default",
        )

    assert jobs_path.exists()
    data = json.loads(jobs_path.read_text())
    assert len(data) == 1
    assert data[0]["job_id"] == "abc123"
    assert data[0]["exit_code"] == 0
    assert data[0]["duration_s"] == pytest.approx(3600.0, rel=1e-3)
    assert data[0]["cost_usd"] == pytest.approx(0.01, rel=1e-3)


def test_record_appends(tmp_path):
    jobs_path = tmp_path / "jobs.json"
    runr_dir = tmp_path

    with patch("crunr.jobs._RUNR_DIR", runr_dir), patch("crunr.jobs._JOBS_PATH", jobs_path):
        from crunr import jobs as j
        for i in range(3):
            j.record(
                job_id=f"job{i}",
                command="echo hi",
                instance_type="t3.nano",
                instance_id=f"i-{i}",
                spot=True,
                spot_price=0.005,
                started_at=_make_dt(),
                ended_at=_make_dt(minute=10),
                exit_code=0,
                region="us-east-1",
                profile="default",
            )

    data = json.loads(jobs_path.read_text())
    assert len(data) == 3
