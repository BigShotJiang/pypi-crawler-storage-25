"""Tests for CLI argument parsing."""

import sys
import pytest
from unittest.mock import patch


def _parse(args_str: str):
    from crunr.cli import _build_parser
    parser = _build_parser()
    return parser.parse_args(args_str.split())


def test_run_defaults():
    args = _parse("run train.py")
    assert args.script == "train.py"
    assert args.gpu is False
    assert args.on_demand is False
    assert args.memory is None
    assert args.instance is None
    assert args.env == []
    assert args.dir == "."


def test_run_gpu_flags():
    args = _parse("run train.py --gpu --memory 32")
    assert args.gpu is True
    assert args.memory == 32.0


def test_run_instance_override():
    args = _parse("run train.py --instance g5.xlarge")
    assert args.instance == "g5.xlarge"


def test_run_on_demand():
    args = _parse("run train.py --on-demand")
    assert args.on_demand is True


def test_run_env_vars():
    args = _parse("run train.py --env EPOCHS=10 --env LR=0.01")
    assert args.env == ["EPOCHS=10", "LR=0.01"]


def test_run_profile_and_region():
    args = _parse("run train.py --profile work --region eu-west-1")
    assert args.profile == "work"
    assert args.region == "eu-west-1"


def test_auth_default():
    args = _parse("auth")
    assert args.profile_name == "default"
    assert args.list is False


def test_auth_named_profile():
    args = _parse("auth myprofile")
    assert args.profile_name == "myprofile"


def test_auth_list_flag():
    args = _parse("auth --list")
    assert args.list is True


def test_auth_verify():
    args = _parse("auth --verify myprofile")
    assert args.verify == "myprofile"


def test_auth_set_default():
    args = _parse("auth --default work")
    assert args.default == "work"


def test_parse_env_valid():
    from crunr.cli import _parse_env
    result = _parse_env(["KEY=value", "FOO=bar=baz"])
    assert result == {"KEY": "value", "FOO": "bar=baz"}


def test_parse_env_invalid(capsys):
    from crunr.cli import _parse_env
    with pytest.raises(SystemExit):
        _parse_env(["NOEQUALS"])


def test_version_flag(capsys):
    from crunr.cli import _build_parser
    parser = _build_parser()
    with pytest.raises(SystemExit) as exc:
        parser.parse_args(["--version"])
    assert exc.value.code == 0
