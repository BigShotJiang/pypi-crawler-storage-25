"""Tests for config module."""

import pytest
from crunr.config import (
    CPU_CANDIDATES,
    GPU_CANDIDATES,
    ALL_PROFILES,
    get_profile,
    InstanceProfile,
)


def test_cpu_candidates_ordered_by_size():
    """CPU candidates should go from nano to larger types."""
    assert CPU_CANDIDATES[0].instance_type == "t3.nano"


def test_gpu_candidates_start_with_cheapest():
    """GPU candidates should start with g4dn.xlarge (cheapest GPU)."""
    assert GPU_CANDIDATES[0].instance_type == "g4dn.xlarge"


def test_all_profiles_includes_both():
    assert "t3.nano" in ALL_PROFILES
    assert "g4dn.xlarge" in ALL_PROFILES


def test_get_profile_known():
    p = get_profile("g5.xlarge")
    assert p is not None
    assert p.gpu is True
    assert p.gpu_memory_gb == 24.0


def test_get_profile_unknown():
    assert get_profile("x99.mega") is None


def test_profile_immutable():
    p = get_profile("t3.micro")
    with pytest.raises(Exception):
        p.vcpus = 99  # type: ignore[misc]


def test_no_duplicate_instance_types():
    all_types = [p.instance_type for p in CPU_CANDIDATES + GPU_CANDIDATES]
    assert len(all_types) == len(set(all_types)), "Duplicate instance type found"
