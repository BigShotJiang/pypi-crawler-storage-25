"""crunr CLI — argparse entrypoint and run orchestrator."""

from __future__ import annotations

import argparse
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from . import __version__, console
from .auth import (
    cmd_auth,
    cmd_list_profiles,
    cmd_set_default,
    cmd_verify,
    get_boto3_session,
)
from .config import MIN_DISK_GB_CPU, MIN_DISK_GB_GPU, REMOTE_WORKSPACE, S3_DEFAULT_PREFIX
from .crunr_config import get_s3_config, set_s3_config
from .jobs import cmd_jobs, generate_job_id, record
from .provision import (
    ensure_key_pair,
    ensure_security_group,
    get_ami,
    launch_with_fallback,
    select_instance,
    terminate_instance,
    wait_for_running,
)
from .remote import (
    check_tools,
    detect_ssh_user,
    install_deps,
    rsync_down,
    rsync_up,
    run_job,
    upload_outputs_to_s3,
    wait_cloud_init,
    wait_for_ssh,
)


# ---------------------------------------------------------------------------
# Main entrypoint
# ---------------------------------------------------------------------------

def main() -> None:
    parser = _build_parser()
    args = parser.parse_args()

    if not hasattr(args, "func"):
        parser.print_help()
        sys.exit(0)

    args.func(args)


# ---------------------------------------------------------------------------
# Parser
# ---------------------------------------------------------------------------

def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="crunr",
        description="crunr — Run any compute job on AWS with a single command.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=_EPILOG,
    )
    parser.add_argument(
        "--version", "-V",
        action="version",
        version=f"crunr {__version__}",
    )

    sub = parser.add_subparsers(title="commands", metavar="<command>")

    # ── run ──────────────────────────────────────────────────────────────
    run_p = sub.add_parser(
        "run",
        help="Run a script or command on an EC2 instance.",
        description="Provision a cloud instance, run your code, stream output, download results.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=_RUN_EPILOG,
    )
    run_p.add_argument(
        "script",
        nargs="?",
        help="Script or shell command to run. Omit to run an interactive shell.",
    )
    run_p.add_argument(
        "--gpu", action="store_true",
        help="Request a GPU instance (cheapest available by default).",
    )
    run_p.add_argument(
        "--memory", type=float, metavar="GB",
        help="Minimum GPU VRAM (with --gpu) or RAM in GB.",
    )
    run_p.add_argument(
        "--instance", metavar="TYPE",
        help="Exact EC2 instance type (e.g. g5.xlarge). Overrides --gpu/--memory selection.",
    )
    run_p.add_argument(
        "--env", action="append", metavar="KEY=VALUE", default=[],
        help="Environment variable(s) passed to the job. Repeat for multiple.",
    )
    run_p.add_argument(
        "--dir", metavar="PATH", default=".",
        help="Local directory to sync (default: current directory).",
    )
    run_p.add_argument(
        "--disk", type=int, metavar="GB", default=0,
        help=(
            "Root EBS volume size in GB. "
            f"Defaults: {MIN_DISK_GB_CPU} GB for CPU jobs, {MIN_DISK_GB_GPU} GB for GPU jobs. "
            "Use a larger value when your dataset or outputs exceed the default."
        ),
    )
    run_p.add_argument(
        "--on-demand", dest="on_demand", action="store_true",
        help="Use on-demand pricing instead of spot (more reliable, more expensive).",
    )
    run_p.add_argument(
        "--profile", metavar="NAME",
        help="AWS credential profile to use (default: 'default').",
    )
    run_p.add_argument(
        "--region", metavar="REGION",
        help="Override the AWS region from your profile.",
    )

    # S3 persistence flags
    s3_group = run_p.add_argument_group("S3 output persistence")
    s3_group.add_argument(
        "--s3", action="store_true",
        help="Back up outputs to S3 using saved config (run 'crunr s3 setup' first).",
    )
    s3_group.add_argument(
        "--s3-bucket", metavar="NAME", dest="s3_bucket",
        help="S3 bucket name to store outputs. Created if it does not exist.",
    )
    s3_group.add_argument(
        "--s3-prefix", metavar="PREFIX", dest="s3_prefix", default=None,
        help=f"S3 key prefix (default: {S3_DEFAULT_PREFIX}).",
    )
    s3_group.add_argument(
        "--s3-no-local", action="store_true", dest="s3_no_local",
        help="Skip local download when S3 backup succeeds (S3 becomes the only copy).",
    )
    s3_group.add_argument(
        "--s3-ttl", type=int, metavar="DAYS", dest="s3_ttl", default=None,
        help="Auto-expire this job's S3 data after N days.",
    )

    run_p.set_defaults(func=cmd_run)

    # ── auth ─────────────────────────────────────────────────────────────
    auth_p = sub.add_parser(
        "auth",
        help="Configure AWS credentials.",
        description="Add or update AWS credentials for use with crunr.",
    )
    auth_p.add_argument(
        "profile_name",
        nargs="?",
        default="default",
        metavar="PROFILE",
        help="Profile name to create/update (default: 'default').",
    )
    auth_p.add_argument(
        "--list", "-l", action="store_true",
        help="List all configured profiles.",
    )
    auth_p.add_argument(
        "--verify", metavar="PROFILE", nargs="?", const="default",
        help="Verify that a profile's credentials are valid.",
    )
    auth_p.add_argument(
        "--default", metavar="PROFILE",
        help="Make an existing profile the default.",
    )
    auth_p.set_defaults(func=_dispatch_auth)

    # ── jobs ─────────────────────────────────────────────────────────────
    jobs_p = sub.add_parser(
        "jobs",
        help="List previous runs.",
        description="Show a history of jobs run with crunr.",
    )
    jobs_p.set_defaults(func=lambda _: cmd_jobs())

    # ── ps ───────────────────────────────────────────────────────────────
    ps_p = sub.add_parser(
        "ps",
        help="List any crunr instances currently running in AWS.",
        description="Show all EC2 instances tagged ManagedBy=crunr that are still alive.",
    )
    ps_p.add_argument("--profile", metavar="NAME", help="AWS credential profile.")
    ps_p.add_argument("--region",  metavar="REGION", help="AWS region to check.")
    ps_p.set_defaults(func=cmd_ps)

    # ── clean ─────────────────────────────────────────────────────────────
    clean_p = sub.add_parser(
        "clean",
        help="Terminate all crunr instances left running in AWS.",
        description="Find and terminate every EC2 instance tagged ManagedBy=crunr.",
    )
    clean_p.add_argument("--profile", metavar="NAME", help="AWS credential profile.")
    clean_p.add_argument("--region",  metavar="REGION", help="AWS region to check.")
    clean_p.add_argument(
        "--yes", "-y", action="store_true",
        help="Skip confirmation prompt.",
    )
    clean_p.set_defaults(func=cmd_clean)

    # ── s3 ───────────────────────────────────────────────────────────────
    s3_p = sub.add_parser(
        "s3",
        help="Manage S3 output persistence.",
        description=(
            "Set up and manage S3 output storage.\n\n"
            "Outputs uploaded to S3 survive network failures, client disconnects,\n"
            "and instance termination — download them any time with 'crunr s3 pull'."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    s3_p.set_defaults(func=lambda _: (s3_p.print_help(), sys.exit(0)))
    s3_sub = s3_p.add_subparsers(title="s3 subcommands", metavar="<subcommand>")

    # s3 setup
    s3_setup_p = s3_sub.add_parser(
        "setup",
        help="Create an S3 bucket and save it as the default for all future runs.",
        description="Create (or reuse) an S3 bucket, configure IAM, and save the config.",
    )
    s3_setup_p.add_argument("--bucket", metavar="NAME", help="Bucket name (prompted if omitted).")
    s3_setup_p.add_argument(
        "--prefix", metavar="PREFIX", default=S3_DEFAULT_PREFIX,
        help=f"Key prefix inside the bucket (default: {S3_DEFAULT_PREFIX}).",
    )
    s3_setup_p.add_argument("--profile", metavar="NAME", help="AWS credential profile.")
    s3_setup_p.add_argument("--region",  metavar="REGION", help="AWS region.")
    s3_setup_p.add_argument(
        "--ttl", type=int, metavar="DAYS", default=None,
        help="Auto-expire job data after N days (sets an S3 lifecycle rule).",
    )
    s3_setup_p.set_defaults(func=cmd_s3_setup)

    # s3 list
    s3_list_p = s3_sub.add_parser(
        "list",
        help="List jobs stored in S3.",
        description="Show all jobs stored in the configured S3 bucket.",
    )
    s3_list_p.add_argument("--bucket", metavar="NAME", help="Override saved bucket name.")
    s3_list_p.add_argument("--prefix", metavar="PREFIX", default=None, help="Override saved prefix.")
    s3_list_p.add_argument("--profile", metavar="NAME", help="AWS credential profile.")
    s3_list_p.add_argument("--region",  metavar="REGION", help="AWS region.")
    s3_list_p.set_defaults(func=cmd_s3_list)

    # s3 pull
    s3_pull_p = s3_sub.add_parser(
        "pull",
        help="Download a job's outputs from S3.",
        description="Download outputs, log, and metadata for a specific job from S3.",
    )
    s3_pull_p.add_argument("job_id", metavar="JOB_ID", help="Job ID to download.")
    s3_pull_p.add_argument(
        "--dest", metavar="DIR", default=None,
        help="Local destination directory (default: ./crunr-<JOB_ID>/).",
    )
    s3_pull_p.add_argument(
        "--outputs-only", action="store_true", dest="outputs_only",
        help="Download only the outputs/ directory (skip log and metadata).",
    )
    s3_pull_p.add_argument(
        "--no-log", action="store_true", dest="no_log",
        help="Skip downloading stdout.log.",
    )
    s3_pull_p.add_argument("--bucket", metavar="NAME", help="Override saved bucket name.")
    s3_pull_p.add_argument("--prefix", metavar="PREFIX", default=None, help="Override saved prefix.")
    s3_pull_p.add_argument("--profile", metavar="NAME", help="AWS credential profile.")
    s3_pull_p.add_argument("--region",  metavar="REGION", help="AWS region.")
    s3_pull_p.set_defaults(func=cmd_s3_pull)

    # s3 status
    s3_status_p = s3_sub.add_parser(
        "status",
        help="Show S3 bucket statistics and saved config.",
        description="Display current S3 config and storage usage.",
    )
    s3_status_p.add_argument("--bucket", metavar="NAME", help="Override saved bucket name.")
    s3_status_p.add_argument("--prefix", metavar="PREFIX", default=None, help="Override saved prefix.")
    s3_status_p.add_argument("--profile", metavar="NAME", help="AWS credential profile.")
    s3_status_p.add_argument("--region",  metavar="REGION", help="AWS region.")
    s3_status_p.set_defaults(func=cmd_s3_status)

    # s3 rm
    s3_rm_p = s3_sub.add_parser(
        "rm",
        help="Delete a job's data from S3.",
        description="Permanently delete all S3 objects for a specific job.",
    )
    s3_rm_p.add_argument("job_id", metavar="JOB_ID", help="Job ID to delete.")
    s3_rm_p.add_argument("--yes", "-y", action="store_true", help="Skip confirmation prompt.")
    s3_rm_p.add_argument("--bucket", metavar="NAME", help="Override saved bucket name.")
    s3_rm_p.add_argument("--prefix", metavar="PREFIX", default=None, help="Override saved prefix.")
    s3_rm_p.add_argument("--profile", metavar="NAME", help="AWS credential profile.")
    s3_rm_p.add_argument("--region",  metavar="REGION", help="AWS region.")
    s3_rm_p.set_defaults(func=cmd_s3_rm)

    return parser


def _dispatch_auth(args: argparse.Namespace) -> None:
    if args.list:
        cmd_list_profiles()
    elif args.verify is not None:
        cmd_verify(args.verify)
    elif args.default:
        cmd_set_default(args.default)
    else:
        cmd_auth(args.profile_name)


# ---------------------------------------------------------------------------
# S3 config helpers
# ---------------------------------------------------------------------------

def _resolve_s3_config(args: argparse.Namespace, region: str) -> Optional[dict[str, Any]]:
    """Return an S3 config dict or None.

    Priority: explicit --s3-bucket flag > --s3 (saved config) > nothing.
    """
    bucket = getattr(args, "s3_bucket", None)
    if bucket:
        return {
            "bucket": bucket,
            "prefix": getattr(args, "s3_prefix", None) or S3_DEFAULT_PREFIX,
            "region": region,
        }

    if getattr(args, "s3", False):
        cfg = get_s3_config()
        if not cfg:
            console.error(
                "--s3 requires a saved S3 config. "
                "Run [bold]crunr s3 setup[/bold] first, or pass --s3-bucket NAME."
            )
            sys.exit(1)
        return cfg

    return None


def _ensure_s3_resources(
    session: Any,
    region: str,
    bucket: str,
    prefix: str,
    ttl_days: Optional[int] = None,
) -> str:
    """Create/verify bucket + IAM instance profile. Returns profile ARN."""
    from .iam import ensure_instance_profile
    from .s3 import ensure_bucket, set_ttl

    s3_client = session.client("s3", region_name=region)
    iam_client = session.client("iam")

    ensure_bucket(s3_client, bucket, region)

    if ttl_days:
        set_ttl(s3_client, bucket, prefix, ttl_days)
        console.ok(f"TTL: objects expire after {ttl_days} days")

    with console.spinner("Setting up IAM instance profile for S3 access…"):
        profile_arn = ensure_instance_profile(iam_client, bucket, prefix)
    console.ok(f"IAM instance profile ready")

    return profile_arn


def _s3_cfg_from_args_or_saved(args: argparse.Namespace, region: str) -> dict[str, Any]:
    """Resolve S3 config for s3 subcommands. Exits if no config is available."""
    bucket = getattr(args, "bucket", None)
    prefix = getattr(args, "prefix", None)

    if bucket:
        return {
            "bucket": bucket,
            "prefix": prefix or S3_DEFAULT_PREFIX,
            "region": region,
        }

    saved = get_s3_config()
    if not saved:
        console.error(
            "No S3 config found. Run [bold]crunr s3 setup[/bold] first, "
            "or pass --bucket NAME."
        )
        sys.exit(1)

    if prefix:
        saved = dict(saved, prefix=prefix)
    return saved


# ---------------------------------------------------------------------------
# cmd_run — the core orchestrator
# ---------------------------------------------------------------------------

def cmd_run(args: argparse.Namespace) -> None:
    check_tools()

    local_dir = Path(args.dir).expanduser().resolve()
    if not local_dir.is_dir():
        console.error(f"Directory not found: {local_dir}")
        sys.exit(1)

    if args.script:
        script_path = Path(args.script)
        if script_path.suffix == ".py":
            command = f"python3 {args.script}"
        elif script_path.suffix in (".sh", ".bash"):
            command = f"bash {args.script}"
        else:
            command = args.script
    else:
        command = "bash"

    env_vars = _parse_env(args.env)

    profile = getattr(args, "profile", None)
    region_override = getattr(args, "region", None)

    console.header("crunr", f"v{__version__}  •  {local_dir.name}/  →  AWS")

    # Phase 1: Local setup
    console.step("Phase 1 — local setup")

    session = get_boto3_session(profile, region_override)
    region = session.region_name or "us-east-1"
    ec2 = session.client("ec2", region_name=region)

    use_spot = not args.on_demand
    gpu = args.gpu or (args.instance and _is_gpu_instance(args.instance))

    with console.spinner("Selecting instance type…"):
        inst_profile, price_per_hour, is_spot = select_instance(
            ec2,
            gpu=gpu,
            min_memory_gb=args.memory,
            instance_type=args.instance,
            use_spot=use_spot,
        )

    pricing_label = "spot" if is_spot else "on-demand"
    console.ok(
        f"Instance: [bold]{inst_profile.instance_type}[/bold]  "
        f"[dim]{pricing_label} ${price_per_hour:.4f}/hr[/dim]"
    )

    with console.spinner("Looking up AMI…"):
        ami_id, root_device = get_ami(ec2, gpu)
    console.ok(f"AMI: {ami_id}  [dim]root device: {root_device}[/dim]")

    disk_gb: int = args.disk
    min_disk = MIN_DISK_GB_GPU if gpu else MIN_DISK_GB_CPU
    if disk_gb and disk_gb < min_disk:
        console.warn(
            f"--disk {disk_gb} GB is below the minimum ({min_disk} GB). Using {min_disk} GB instead."
        )
        disk_gb = min_disk
    if disk_gb:
        console.ok(f"Disk: {disk_gb} GB  [dim]gp3 EBS, deleted on termination[/dim]")
    else:
        console.info(f"  Disk: AMI default ({min_disk} GB)")

    with console.spinner("Ensuring security group exists…"):
        sg_id = ensure_security_group(ec2)

    with console.spinner("Ensuring SSH key pair exists…"):
        key_name = ensure_key_pair(ec2)

    # S3 setup (still Phase 1 — must happen before launch so we have the IAM profile ARN)
    s3_cfg = _resolve_s3_config(args, region)
    instance_profile_arn: Optional[str] = None

    if s3_cfg:
        console.step("Phase 1b — S3 / IAM setup")
        try:
            instance_profile_arn = _ensure_s3_resources(
                session=session,
                region=region,
                bucket=s3_cfg["bucket"],
                prefix=s3_cfg["prefix"],
                ttl_days=getattr(args, "s3_ttl", None),
            )
            console.ok(
                f"S3 bucket: [bold]s3://{s3_cfg['bucket']}/{s3_cfg['prefix']}/[/bold]"
            )
        except Exception as exc:
            console.warn(f"S3 setup failed: {exc}. Continuing without S3 backup.")
            s3_cfg = None

    # Phase 2: Provision
    console.step("Phase 2 — provisioning instance")
    started_at = datetime.now(timezone.utc)
    job_id = generate_job_id()
    remote_dir = f"{REMOTE_WORKSPACE}/job-{job_id}"

    instance_id: Optional[str] = None
    actual_is_spot = is_spot
    exit_code: int = 1
    outputs_path: Optional[Path] = None
    s3_ok = False

    _setup_interrupt_handler()

    try:
        with console.spinner(f"Launching {inst_profile.instance_type} instance…"):
            instance_id, actual_is_spot = launch_with_fallback(
                ec2,
                instance_type=inst_profile.instance_type,
                ami_id=ami_id,
                root_device=root_device,
                sg_id=sg_id,
                key_name=key_name,
                spot=is_spot,
                env_vars=env_vars,
                disk_gb=disk_gb,
                instance_profile_arn=instance_profile_arn,
            )

        launch_label = "spot" if actual_is_spot else "on-demand"
        console.ok(f"Instance {instance_id} launched ({launch_label})")

        public_ip = wait_for_running(ec2, instance_id)
        console.ok(f"Instance running at {public_ip}")

        # Phase 3: Sync
        console.step("Phase 3 — syncing code")
        wait_for_ssh(public_ip)
        console.ok("SSH port open")

        ssh_user = detect_ssh_user(public_ip)
        wait_cloud_init(public_ip, ssh_user)
        console.ok("Cloud-init complete")

        rsync_up(public_ip, ssh_user, local_dir, remote_dir)
        install_deps(public_ip, ssh_user, remote_dir)

        # Phase 4: Execute
        console.step("Phase 4 — executing job")
        exit_code = run_job(
            host=public_ip,
            user=ssh_user,
            remote_dir=remote_dir,
            command=command,
            job_id=job_id,
            env_vars=env_vars,
        )

        # Phase 5: Collect
        console.step("Phase 5 — collecting outputs")

        # 5a: EC2 → S3 (instance pushes using its IAM role — survives client disconnect)
        if s3_cfg and instance_id:
            s3_ok = upload_outputs_to_s3(
                host=public_ip,
                user=ssh_user,
                remote_dir=remote_dir,
                job_id=job_id,
                bucket=s3_cfg["bucket"],
                prefix=s3_cfg["prefix"],
                region=s3_cfg["region"],
            )

        # 5b: EC2 → local (best-effort when S3 succeeded; required when no S3)
        skip_local = s3_ok and getattr(args, "s3_no_local", False)
        if not skip_local:
            try:
                outputs_path = rsync_down(public_ip, ssh_user, remote_dir, local_dir)
            except Exception as dl_exc:
                if s3_ok:
                    console.warn(
                        f"Local download failed ({dl_exc}). "
                        f"Your outputs are safe in S3.\n"
                        f"  Recover with: [bold]crunr s3 pull {job_id}[/bold]"
                    )
                else:
                    console.warn(
                        f"Local download failed: {dl_exc}. "
                        "Outputs may be lost — instance will be terminated."
                    )
        else:
            console.ok("Local download skipped (--s3-no-local). Outputs are in S3.")

    except KeyboardInterrupt:
        console.warn("Interrupted — terminating instance…")
        exit_code = 130
    except Exception as exc:  # noqa: BLE001
        console.error(f"Unexpected error: {exc}")
        exit_code = 1
    finally:
        ended_at = datetime.now(timezone.utc)

        if instance_id:
            terminate_instance(ec2, instance_id)

        job_record = record(
            job_id=job_id,
            command=command,
            instance_type=inst_profile.instance_type,
            instance_id=instance_id or "unknown",
            spot=actual_is_spot,
            spot_price=price_per_hour,
            started_at=started_at,
            ended_at=ended_at,
            exit_code=exit_code,
            region=region,
            profile=profile or "default",
        )

        # Upload metadata.json to S3 so 'crunr s3 list' can show job details
        if s3_cfg and s3_ok:
            try:
                from .s3 import upload_metadata
                s3_client = session.client("s3", region_name=region)
                upload_metadata(s3_client, s3_cfg["bucket"], s3_cfg["prefix"], job_id, job_record)
            except Exception as meta_exc:
                console.warn(f"Failed to upload job metadata to S3: {meta_exc}")

        outputs_str = str(outputs_path) if outputs_path else None
        console.summary_panel(
            job_id=job_id,
            instance_type=inst_profile.instance_type,
            duration_s=job_record["duration_s"],
            cost_usd=job_record["cost_usd"],
            exit_code=exit_code,
            outputs_path=outputs_str,
        )

        if s3_ok and s3_cfg:
            s3_url = f"s3://{s3_cfg['bucket']}/{s3_cfg['prefix']}/{job_id}/"
            console.info(f"  S3 backup → {s3_url}")
            console.info(f"  Download later: crunr s3 pull {job_id}")

    sys.exit(exit_code)


# ---------------------------------------------------------------------------
# S3 subcommands
# ---------------------------------------------------------------------------

def cmd_s3_setup(args: argparse.Namespace) -> None:
    """Interactive (or flag-driven) S3 setup: bucket, IAM, saved config."""
    from .iam import ensure_instance_profile
    from .s3 import ensure_bucket, set_ttl

    profile = getattr(args, "profile", None)
    region_override = getattr(args, "region", None)
    session = get_boto3_session(profile, region_override)
    region = session.region_name or "us-east-1"

    bucket = getattr(args, "bucket", None)
    prefix = getattr(args, "prefix", None) or S3_DEFAULT_PREFIX
    ttl_days = getattr(args, "ttl", None)

    if not bucket:
        existing = get_s3_config()
        default_bucket = existing.get("bucket", "") if existing else ""
        bucket = console.prompt("S3 bucket name", default=default_bucket)
        if not bucket:
            console.error("Bucket name is required.")
            sys.exit(1)

    console.header("crunr s3 setup", f"bucket: {bucket}  prefix: {prefix}")

    s3_client = session.client("s3", region_name=region)
    iam_client = session.client("iam")

    ensure_bucket(s3_client, bucket, region)

    if ttl_days:
        set_ttl(s3_client, bucket, prefix, ttl_days)
        console.ok(f"TTL: objects expire after {ttl_days} days")

    with console.spinner("Setting up IAM instance profile…"):
        profile_arn = ensure_instance_profile(iam_client, bucket, prefix)
    console.ok(f"IAM profile: {profile_arn}")

    cfg: dict[str, Any] = {
        "bucket": bucket,
        "prefix": prefix,
        "region": region,
    }
    if ttl_days:
        cfg["ttl_days"] = ttl_days

    set_s3_config(cfg)
    console.ok(f"Config saved — all future [bold]crunr run --s3[/bold] calls will use this bucket.")
    console.info(f"  Run with S3: crunr run --s3 script.py")
    console.info(f"  Or per-run:  crunr run --s3-bucket {bucket} script.py")


def cmd_s3_list(args: argparse.Namespace) -> None:
    """List jobs stored in S3."""
    from .s3 import list_jobs

    profile = getattr(args, "profile", None)
    region_override = getattr(args, "region", None)
    session = get_boto3_session(profile, region_override)
    region = session.region_name or "us-east-1"

    cfg = _s3_cfg_from_args_or_saved(args, region)
    s3_client = session.client("s3", region_name=cfg["region"])

    console.info(f"  Listing jobs in s3://{cfg['bucket']}/{cfg['prefix']}/")
    with console.spinner("Fetching job list from S3…"):
        jobs = list_jobs(s3_client, cfg["bucket"], cfg["prefix"])

    console.s3_jobs_table(jobs)

    if jobs:
        console.info(f"  {len(jobs)} job(s) found.")
        console.info(f"  Download: crunr s3 pull <JOB_ID>")


def cmd_s3_pull(args: argparse.Namespace) -> None:
    """Download a job's outputs from S3."""
    from .s3 import download_job

    profile = getattr(args, "profile", None)
    region_override = getattr(args, "region", None)
    session = get_boto3_session(profile, region_override)
    region = session.region_name or "us-east-1"

    cfg = _s3_cfg_from_args_or_saved(args, region)
    job_id = args.job_id

    dest_str = getattr(args, "dest", None)
    dest_dir = Path(dest_str).expanduser().resolve() if dest_str else Path.cwd() / f"crunr-{job_id}"

    outputs_only = getattr(args, "outputs_only", False)
    include_log = not getattr(args, "no_log", False)

    s3_client = session.client("s3", region_name=cfg["region"])

    console.header("crunr s3 pull", f"{job_id} → {dest_dir}")

    count = download_job(
        s3=s3_client,
        bucket=cfg["bucket"],
        prefix=cfg["prefix"],
        job_id=job_id,
        dest_dir=dest_dir,
        outputs_only=outputs_only,
        include_log=include_log,
    )

    if count:
        console.ok(f"Downloaded {count} file(s) to {dest_dir}")
    else:
        console.warn(f"No files downloaded for job {job_id}.")
        sys.exit(1)


def cmd_s3_status(args: argparse.Namespace) -> None:
    """Show saved S3 config and bucket statistics."""
    from .s3 import get_bucket_stats

    profile = getattr(args, "profile", None)
    region_override = getattr(args, "region", None)
    session = get_boto3_session(profile, region_override)
    region = session.region_name or "us-east-1"

    cfg = _s3_cfg_from_args_or_saved(args, region)
    s3_client = session.client("s3", region_name=cfg["region"])

    console.header("crunr s3 status")
    console.info(f"  bucket  : {cfg['bucket']}")
    console.info(f"  prefix  : {cfg['prefix']}")
    console.info(f"  region  : {cfg['region']}")

    with console.spinner("Fetching bucket statistics…"):
        stats = get_bucket_stats(s3_client, cfg["bucket"], cfg["prefix"])

    job_count = stats.get("count", 0)
    total_bytes = stats.get("bytes", 0)

    if total_bytes >= 1_073_741_824:
        size_str = f"{total_bytes / 1_073_741_824:.2f} GB"
    elif total_bytes >= 1_048_576:
        size_str = f"{total_bytes / 1_048_576:.2f} MB"
    elif total_bytes >= 1024:
        size_str = f"{total_bytes / 1024:.1f} KB"
    else:
        size_str = f"{total_bytes} B"

    console.ok(f"Jobs stored : {job_count}")
    console.ok(f"Total size  : {size_str}")


def cmd_s3_rm(args: argparse.Namespace) -> None:
    """Delete a job's artifacts from S3."""
    from .s3 import delete_job

    profile = getattr(args, "profile", None)
    region_override = getattr(args, "region", None)
    yes = getattr(args, "yes", False)
    session = get_boto3_session(profile, region_override)
    region = session.region_name or "us-east-1"

    cfg = _s3_cfg_from_args_or_saved(args, region)
    job_id = args.job_id
    s3_client = session.client("s3", region_name=cfg["region"])

    s3_path = f"s3://{cfg['bucket']}/{cfg['prefix']}/{job_id}/"
    console.warn(f"This will permanently delete all objects under {s3_path}")

    if not yes:
        console.info("  Pass --yes to skip this prompt.")
        answer = console.prompt("Delete? [y/N]", default="N")
        if answer.lower() not in ("y", "yes"):
            console.info("Aborted — nothing deleted.")
            return

    with console.spinner(f"Deleting {job_id} from S3…"):
        count = delete_job(s3_client, cfg["bucket"], cfg["prefix"], job_id)

    if count:
        console.ok(f"Deleted {count} object(s) for job {job_id}.")
    else:
        console.warn(f"No objects found for job {job_id} — nothing deleted.")


# ---------------------------------------------------------------------------
# cmd_ps / cmd_clean
# ---------------------------------------------------------------------------

_RUNR_FILTERS = [
    {"Name": "tag:ManagedBy", "Values": ["crunr"]},
    {"Name": "instance-state-name", "Values": ["pending", "running", "stopping", "stopped"]},
]


def _find_runr_instances(ec2: Any) -> list[dict]:  # type: ignore[type-arg]
    resp = ec2.describe_instances(Filters=_RUNR_FILTERS)
    instances = []
    for reservation in resp.get("Reservations", []):
        for inst in reservation.get("Instances", []):
            instances.append(inst)
    return instances


def cmd_ps(args: argparse.Namespace) -> None:
    profile = getattr(args, "profile", None)
    region  = getattr(args, "region",  None)
    session = get_boto3_session(profile, region)
    ec2     = session.client("ec2", region_name=session.region_name or "us-east-1")

    with console.spinner("Checking for running crunr instances…"):
        instances = _find_runr_instances(ec2)

    if not instances:
        console.ok("No crunr instances currently running.")
        return

    from rich.table import Table
    from rich import box
    from rich.console import Console

    out = Console()
    table = Table(box=box.SIMPLE_HEAD, header_style="bold bright_blue", border_style="dim")
    table.add_column("Instance ID",   no_wrap=True)
    table.add_column("Type",          no_wrap=True)
    table.add_column("State",         no_wrap=True)
    table.add_column("Public IP",     no_wrap=True)
    table.add_column("Launched",      no_wrap=True)

    for inst in instances:
        state = inst["State"]["Name"]
        color = "green" if state == "running" else "yellow" if state == "pending" else "dim"
        table.add_row(
            inst["InstanceId"],
            inst.get("InstanceType", "?"),
            f"[{color}]{state}[/{color}]",
            inst.get("PublicIpAddress", "—"),
            str(inst.get("LaunchTime", "?"))[:16].replace("+00:00", " UTC"),
        )

    out.print(table)
    console.warn(f"{len(instances)} instance(s) still running — use [bold]crunr clean[/bold] to terminate them.")


def cmd_clean(args: argparse.Namespace) -> None:
    profile = getattr(args, "profile", None)
    region  = getattr(args, "region",  None)
    yes     = getattr(args, "yes",     False)
    session = get_boto3_session(profile, region)
    ec2     = session.client("ec2", region_name=session.region_name or "us-east-1")

    with console.spinner("Scanning for orphaned crunr instances…"):
        instances = _find_runr_instances(ec2)

    if not instances:
        console.ok("Nothing to clean up — no crunr instances found.")
        return

    ids = [i["InstanceId"] for i in instances]
    console.warn(f"Found {len(ids)} orphaned instance(s): {', '.join(ids)}")

    if not yes:
        console.info("  Pass --yes to skip this prompt.")
        answer = console.prompt("Terminate all of them? [y/N]", default="N")
        if answer.lower() not in ("y", "yes"):
            console.info("Aborted — nothing terminated.")
            return

    from .provision import terminate_instance
    for iid in ids:
        terminate_instance(ec2, iid)

    console.ok(f"Terminated {len(ids)} instance(s). Your AWS bill stops here.")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _parse_env(raw: list[str]) -> dict[str, str]:
    result: dict[str, str] = {}
    for item in raw:
        if "=" not in item:
            console.error(f"Invalid --env value: '{item}'. Use KEY=VALUE format.")
            sys.exit(1)
        k, _, v = item.partition("=")
        result[k.strip()] = v
    return result


def _is_gpu_instance(instance_type: str) -> bool:
    from .config import GPU_CANDIDATES
    gpu_types = {p.instance_type for p in GPU_CANDIDATES}
    return instance_type in gpu_types


def _setup_interrupt_handler() -> None:
    pass


# ---------------------------------------------------------------------------
# Help text
# ---------------------------------------------------------------------------

_EPILOG = """\
examples:
  crunr auth                             # set up AWS credentials (first-time setup)
  crunr run train.py --gpu               # cheapest GPU instance, spot pricing
  crunr run train.py --gpu --memory 24   # at least 24 GB VRAM
  crunr run train.py --gpu --disk 200    # 200 GB root volume for large datasets
  crunr run train.py --instance g5.xlarge
  crunr run preprocess.py                # cheapest CPU instance (t3 series)
  crunr run preprocess.py --env BATCH=512 --env LR=0.001

  # S3 output persistence
  crunr s3 setup --bucket my-crunr-outputs   # one-time setup
  crunr run train.py --gpu --s3              # run with S3 backup (uses saved config)
  crunr run train.py --gpu --s3-bucket my-crunr-outputs  # explicit bucket
  crunr s3 list                              # list all jobs in S3
  crunr s3 pull <JOB_ID>                     # download a job's outputs
  crunr s3 status                            # show bucket usage
  crunr s3 rm <JOB_ID>                       # delete a job from S3

  crunr jobs                                 # show local run history
  crunr ps                                   # list any instances still running in AWS
  crunr clean                                # terminate all orphaned crunr instances
"""

_RUN_EPILOG = """\
examples:
  crunr run train.py
  crunr run train.py --gpu
  crunr run train.py --gpu --memory 32
  crunr run train.py --gpu --disk 200        # 200 GB root volume
  crunr run train.py --instance p3.2xlarge --on-demand
  crunr run train.py --env EPOCHS=50 --env LR=0.001
  crunr run train.py --dir ~/projects/my-model --profile work

  # S3 persistence — outputs survive network failures
  crunr run train.py --s3                    # use saved S3 config
  crunr run train.py --s3-bucket my-bucket   # explicit bucket (auto-created)
  crunr run train.py --s3 --s3-no-local      # S3 only (no local download)
  crunr run train.py --s3 --s3-ttl 30        # auto-delete from S3 after 30 days
"""
