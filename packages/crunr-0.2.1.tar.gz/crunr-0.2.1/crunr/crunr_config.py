"""Persistent crunr config: ~/.crunr/config.json (distinct from stdlib 'config')."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Optional

_CONFIG_PATH = Path("~/.crunr/config.json").expanduser()


def load() -> dict[str, Any]:
    if not _CONFIG_PATH.exists():
        return {}
    try:
        return json.loads(_CONFIG_PATH.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}


def save(data: dict[str, Any]) -> None:
    _CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    _CONFIG_PATH.write_text(json.dumps(data, indent=2), encoding="utf-8")


def get_s3_config() -> Optional[dict[str, Any]]:
    return load().get("s3")


def set_s3_config(s3_cfg: dict[str, Any]) -> None:
    data = load()
    data["s3"] = s3_cfg
    save(data)


def clear_s3_config() -> None:
    data = load()
    data.pop("s3", None)
    save(data)
