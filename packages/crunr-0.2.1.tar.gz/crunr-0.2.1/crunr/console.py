"""Terminal output helpers built on Rich."""

from __future__ import annotations

import sys
from contextlib import contextmanager
from typing import Generator

from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn, TimeElapsedColumn
from rich.table import Table
from rich.text import Text
from rich import box

# Shared console — stderr for status, stdout for job output
_err = Console(stderr=True, highlight=False)
_out = Console(stderr=False, highlight=False)


# ---------------------------------------------------------------------------
# Styled printers
# ---------------------------------------------------------------------------

def step(msg: str) -> None:
    _err.print(f"[bold cyan]▸[/bold cyan] {msg}")


def ok(msg: str) -> None:
    _err.print(f"[bold green]✓[/bold green] {msg}")


def warn(msg: str) -> None:
    _err.print(f"[bold yellow]⚠[/bold yellow]  {msg}")


def error(msg: str) -> None:
    _err.print(f"[bold red]✗[/bold red] {msg}")


def info(msg: str) -> None:
    _err.print(f"[dim]{msg}[/dim]")


def header(title: str, subtitle: str = "") -> None:
    parts = [f"[bold]{title}[/bold]"]
    if subtitle:
        parts.append(f"[dim]{subtitle}[/dim]")
    _err.print(Panel("\n".join(parts), border_style="bright_blue", padding=(0, 2)))


def job_line(text: str) -> None:
    """Print a line of live job output verbatim to stdout."""
    _out.print(text, end="")


# ---------------------------------------------------------------------------
# Spinner context manager
# ---------------------------------------------------------------------------

@contextmanager
def spinner(msg: str) -> Generator[None, None, None]:
    with Progress(
        SpinnerColumn(style="cyan"),
        TextColumn("[progress.description]{task.description}"),
        TimeElapsedColumn(),
        console=_err,
        transient=True,
    ) as progress:
        progress.add_task(msg, total=None)
        yield


# ---------------------------------------------------------------------------
# Summary panel
# ---------------------------------------------------------------------------

def summary_panel(
    job_id: str,
    instance_type: str,
    duration_s: float,
    cost_usd: float,
    exit_code: int,
    outputs_path: str | None,
) -> None:
    status_color = "green" if exit_code == 0 else "red"
    status_label = "success" if exit_code == 0 else f"failed (exit {exit_code})"

    mins, secs = divmod(int(duration_s), 60)
    hrs, mins = divmod(mins, 60)
    if hrs:
        duration_str = f"{hrs}h {mins}m {secs}s"
    elif mins:
        duration_str = f"{mins}m {secs}s"
    else:
        duration_str = f"{secs}s"

    text = Text()
    text.append("  job id       ", style="dim")
    text.append(f"{job_id}\n", style="bold")

    text.append("  instance     ", style="dim")
    text.append(f"{instance_type}\n")

    text.append("  duration     ", style="dim")
    text.append(f"{duration_str}\n")

    text.append("  cost         ", style="dim")
    text.append(f"${cost_usd:.4f}\n")

    text.append("  status       ", style="dim")
    text.append(f"{status_label}\n", style=f"bold {status_color}")

    if outputs_path:
        text.append("  outputs      ", style="dim")
        text.append(f"{outputs_path}\n", style="cyan")

    text.append("\n  $0.00 idle cost after this point", style="dim italic")

    border = "green" if exit_code == 0 else "red"
    _err.print(Panel(text, title="[bold]run complete[/bold]", border_style=border, padding=(0, 1)))


# ---------------------------------------------------------------------------
# Jobs table
# ---------------------------------------------------------------------------

def jobs_table(records: list[dict]) -> None:  # type: ignore[type-arg]
    if not records:
        _err.print("[dim]No jobs recorded yet. Run [bold]crunr run <script>[/bold] to start.[/dim]")
        return

    table = Table(
        box=box.SIMPLE_HEAD,
        show_header=True,
        header_style="bold bright_blue",
        border_style="dim",
        padding=(0, 1),
    )
    table.add_column("Job ID", style="dim", no_wrap=True)
    table.add_column("Date", no_wrap=True)
    table.add_column("Instance", no_wrap=True)
    table.add_column("Duration", justify="right")
    table.add_column("Cost", justify="right", style="yellow")
    table.add_column("Status", justify="center")

    for r in reversed(records):
        exit_code = r.get("exit_code", -1)
        status_text = "✓ ok" if exit_code == 0 else f"✗ {exit_code}"
        status_style = "green" if exit_code == 0 else "red"

        duration_s = r.get("duration_s", 0)
        mins, secs = divmod(int(duration_s), 60)
        hrs, mins = divmod(mins, 60)
        if hrs:
            dur_str = f"{hrs}h{mins}m"
        elif mins:
            dur_str = f"{mins}m{secs}s"
        else:
            dur_str = f"{secs}s"

        cost = r.get("cost_usd", 0)
        table.add_row(
            r.get("job_id", "?")[:12],
            r.get("started_at", "?")[:16].replace("T", " "),
            r.get("instance_type", "?"),
            dur_str,
            f"${cost:.4f}",
            Text(status_text, style=status_style),
        )

    _out.print(table)


# ---------------------------------------------------------------------------
# Auth helpers
# ---------------------------------------------------------------------------

def profiles_table(profiles: list[dict]) -> None:  # type: ignore[type-arg]
    if not profiles:
        _err.print("[dim]No profiles configured. Run [bold]crunr auth[/bold] to add one.[/dim]")
        return

    table = Table(
        box=box.SIMPLE_HEAD,
        header_style="bold bright_blue",
        border_style="dim",
        padding=(0, 1),
    )
    table.add_column("Profile")
    table.add_column("Region")
    table.add_column("Key ID")
    table.add_column("Default", justify="center")

    for p in profiles:
        table.add_row(
            p.get("name", "?"),
            p.get("region", "?"),
            p.get("key_id", "?"),
            "★" if p.get("is_default") else "",
        )

    _out.print(table)


def prompt(msg: str, default: str = "") -> str:
    suffix = f" [{default}]" if default else ""
    _err.print(f"[cyan]{msg}{suffix}:[/cyan] ", end="")
    value = input()
    return value.strip() or default


def prompt_secret(msg: str) -> str:
    import getpass
    _err.print(f"[cyan]{msg}:[/cyan] ", end="")
    return getpass.getpass("")


def s3_jobs_table(jobs: list[dict]) -> None:  # type: ignore[type-arg]
    """Display S3 job list returned by crunr.s3.list_jobs()."""
    if not jobs:
        _err.print(
            "[dim]No jobs found in S3. Run [bold]crunr run --s3-bucket BUCKET script.py[/bold] to start.[/dim]"
        )
        return

    table = Table(
        box=box.SIMPLE_HEAD,
        show_header=True,
        header_style="bold bright_blue",
        border_style="dim",
        padding=(0, 1),
    )
    table.add_column("Job ID", style="dim", no_wrap=True)
    table.add_column("Date", no_wrap=True)
    table.add_column("Instance", no_wrap=True)
    table.add_column("Duration", justify="right")
    table.add_column("Cost", justify="right", style="yellow")
    table.add_column("Status", justify="center")
    table.add_column("S3 Size", justify="right", style="dim")

    for j in jobs:
        meta = j.get("metadata", {})
        job_id = j.get("job_id", "?")

        exit_code = meta.get("exit_code", -1)
        status_text = "✓ ok" if exit_code == 0 else f"✗ {exit_code}"
        status_style = "green" if exit_code == 0 else "red"

        duration_s = meta.get("duration_s", 0)
        mins, secs = divmod(int(duration_s), 60)
        hrs, mins = divmod(mins, 60)
        if hrs:
            dur_str = f"{hrs}h{mins}m"
        elif mins:
            dur_str = f"{mins}m{secs}s"
        else:
            dur_str = f"{secs}s"

        size_bytes = j.get("size_bytes", 0)
        if size_bytes >= 1_073_741_824:
            size_str = f"{size_bytes / 1_073_741_824:.1f} GB"
        elif size_bytes >= 1_048_576:
            size_str = f"{size_bytes / 1_048_576:.1f} MB"
        elif size_bytes >= 1024:
            size_str = f"{size_bytes / 1024:.1f} KB"
        elif size_bytes:
            size_str = f"{size_bytes} B"
        else:
            size_str = "—"

        cost = meta.get("cost_usd", 0)
        started = meta.get("started_at", "?")
        date_str = (started[:16] if started and started != "?" else "?").replace("T", " ")

        table.add_row(
            job_id[:12],
            date_str,
            meta.get("instance_type", "?"),
            dur_str,
            f"${cost:.4f}" if cost else "?",
            Text(status_text, style=status_style),
            size_str,
        )

    _out.print(table)


def choose(msg: str, options: list[tuple[str, str]]) -> str:
    """Numbered menu. Returns the value (first element) of the chosen option."""
    _err.print(f"\n[bold]{msg}[/bold]")
    for i, (value, label) in enumerate(options, 1):
        _err.print(f"  [cyan]{i:2}.[/cyan] {label}  [dim]({value})[/dim]")
    while True:
        raw = prompt(f"Enter number [1-{len(options)}]")
        if raw.isdigit() and 1 <= int(raw) <= len(options):
            return options[int(raw) - 1][0]
        warn("Invalid choice — enter a number from the list.")
