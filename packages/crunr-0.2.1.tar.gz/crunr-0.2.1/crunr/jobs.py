"""Job history: record runs, display table. Stored at ~/.crunr/jobs.json."""

from __future__ import annotations

import json
import os
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from . import console
from .config import JOBS_FILE, RUNR_DIR

# ---------------------------------------------------------------------------
# Job record schema
# ---------------------------------------------------------------------------

_RUNR_DIR = Path(RUNR_DIR).expanduser()
_JOBS_PATH = Path(JOBS_FILE).expanduser()


def _ensure_dir() -> None:
    _RUNR_DIR.mkdir(parents=True, exist_ok=True)


def generate_job_id() -> str:
    return uuid.uuid4().hex[:12]


# ---------------------------------------------------------------------------
# Record & read
# ---------------------------------------------------------------------------

def record(
    job_id: str,
    command: str,
    instance_type: str,
    instance_id: str,
    spot: bool,
    spot_price: float,
    started_at: datetime,
    ended_at: datetime,
    exit_code: int,
    region: str,
    profile: str,
) -> dict[str, Any]:
    """Build a job record dict, persist it, and return it."""
    duration_s = (ended_at - started_at).total_seconds()
    cost_usd = spot_price * (duration_s / 3600.0)

    record_dict: dict[str, Any] = {
        "job_id": job_id,
        "command": command,
        "instance_type": instance_type,
        "instance_id": instance_id,
        "spot": spot,
        "spot_price_per_hour": round(spot_price, 6),
        "started_at": started_at.astimezone(timezone.utc).isoformat(),
        "ended_at": ended_at.astimezone(timezone.utc).isoformat(),
        "duration_s": round(duration_s, 1),
        "cost_usd": round(cost_usd, 6),
        "exit_code": exit_code,
        "region": region,
        "profile": profile,
    }

    _append(record_dict)
    return record_dict


def _append(entry: dict[str, Any]) -> None:
    _ensure_dir()
    records = _load()
    records.append(entry)
    _JOBS_PATH.write_text(json.dumps(records, indent=2), encoding="utf-8")


def _load() -> list[dict[str, Any]]:
    if not _JOBS_PATH.exists():
        return []
    try:
        data = json.loads(_JOBS_PATH.read_text(encoding="utf-8"))
        if isinstance(data, list):
            return data
    except (json.JSONDecodeError, OSError):
        pass
    return []


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------

def cmd_jobs() -> None:
    records = _load()
    console.jobs_table(records)
