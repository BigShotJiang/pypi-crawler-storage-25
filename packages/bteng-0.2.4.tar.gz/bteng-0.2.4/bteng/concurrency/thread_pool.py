"""Fixed-size worker thread pool for async node execution."""
from __future__ import annotations

import os
from concurrent.futures import Future, ThreadPoolExecutor
from typing import Any, Callable, TypeVar

_T = TypeVar("_T")


class ThreadPool:
    """Fixed-size worker thread pool.

    AsyncActionNode submits work via submit() and polls the returned
    Future each tick until it is ready.  Threads stay alive for the
    lifetime of the executor — no thread-creation overhead during execution.

    Usage::

        pool = ThreadPool(num_threads=4)
        fut = pool.submit(lambda: NodeStatus.SUCCESS)
        # later in tick():
        if fut.done():
            return fut.result()
    """

    def __init__(self, num_threads: int = 4) -> None:
        if num_threads <= 0:
            num_threads = os.cpu_count() or 4
        self._num_threads = num_threads
        self._executor = ThreadPoolExecutor(
            max_workers=num_threads, thread_name_prefix="bteng-worker"
        )
        self._stopped = False

    def submit(self, fn: Callable[..., _T], *args: Any, **kwargs: Any) -> "Future[_T]":
        """Submit a callable for async execution.

        Returns a Future that becomes ready when a worker finishes the task.
        Raises RuntimeError if the pool has been stopped.
        """
        if self._stopped:
            raise RuntimeError("ThreadPool: submit on stopped pool")
        return self._executor.submit(fn, *args, **kwargs)

    @property
    def thread_count(self) -> int:
        return self._num_threads

    def pending_tasks(self) -> int:
        return self._executor._work_queue.qsize()  # type: ignore[attr-defined]

    def wait_all(self) -> None:
        """Block until all submitted tasks complete."""
        self._executor.shutdown(wait=True, cancel_futures=False)

    def shutdown(self) -> None:
        """Stop the pool and wait for running tasks to finish."""
        self._stopped = True
        self._executor.shutdown(wait=True)

    def __del__(self) -> None:
        if not self._stopped:
            try:
                self._executor.shutdown(wait=False)
            except Exception:
                pass

    def __repr__(self) -> str:
        return f"ThreadPool(threads={self._num_threads}, stopped={self._stopped})"
