"""CLI entry point: bteng <command> [options]."""

from __future__ import annotations

import argparse
import sys
import time
from importlib.metadata import PackageNotFoundError, version


def _get_version() -> str:
    try:
        return version("bteng")
    except PackageNotFoundError:
        from bteng import __version__

        return __version__


def cmd_run(args: argparse.Namespace) -> int:
    from bteng.blackboard.blackboard import Blackboard
    from bteng.core.engine import BehaviorTreeEngine
    from bteng.factory.factory import NodeFactory
    from bteng.logging.tracer import ExecutionTracer
    from bteng.plugins.loader import load_plugin_file

    for plugin in args.plugin or []:
        load_plugin_file(plugin)

    tracer = ExecutionTracer() if args.log or args.verbose else None
    bb = Blackboard.create("cli")

    viz = None
    if args.viz:
        from bteng.visualization.btviz import BTViz
        viz = BTViz(enabled=True, output_dir=args.viz_dir or ".")

    try:
        engine = BehaviorTreeEngine.from_xml(
            args.xml_file,
            tree_id=args.tree,
            blackboard=bb,
            tracer=tracer,
            hz=args.hz,
            viz=viz,
        )
    except Exception as exc:
        print(f"[bteng] Error loading tree: {exc}", file=sys.stderr)
        return 1

    if args.graphviz:
        from bteng.visualization.graphviz_export import export_graphviz

        dot = export_graphviz(engine.root, output_path=args.graphviz)
        print(f"[bteng] Graphviz DOT written to {args.graphviz}")

    print(f"[bteng] Running tree from {args.xml_file!r}")
    try:
        status = engine.run_until_complete(max_ticks=args.max_ticks)
    except KeyboardInterrupt:
        engine.halt()
        status = None
        print("\n[bteng] Halted by user.")

    print(f"[bteng] Final status: {status}")

    if tracer:
        if args.verbose:
            tracer.print_summary()
        if args.log:
            tracer.save(args.log)
            print(f"[bteng] Execution log saved to {args.log!r}")

    return 0


def cmd_viz(args: argparse.Namespace) -> int:
    from bteng.blackboard.blackboard import Blackboard
    from bteng.factory.factory import NodeFactory
    from bteng.plugins.loader import load_plugin_file
    from bteng.xml_parser.parser import XMLTreeParser
    from bteng.visualization.graphviz_export import export_graphviz, render_png

    for plugin in args.plugin or []:
        load_plugin_file(plugin)

    bb = Blackboard.create("viz")
    parser = XMLTreeParser()
    try:
        root = parser.parse_file(args.xml_file, tree_id=args.tree, blackboard=bb)
    except Exception as exc:
        print(f"[bteng] Error loading tree: {exc}", file=sys.stderr)
        return 1

    output = args.output or "tree.dot"
    if args.format in ("png", "svg"):
        render_png(root, output)
        print(f"[bteng] Image written to {output!r}")
    else:
        export_graphviz(root, output_path=output)
        print(f"[bteng] DOT file written to {output!r}")

    return 0


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="bteng",
        description="BTEng Behavior Tree Engine",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {_get_version()}",
    )
    sub = parser.add_subparsers(dest="command", metavar="command")

    # -- run -----------------------------------------------------------
    run_p = sub.add_parser("run", help="Run a behavior tree from XML")
    run_p.add_argument("xml_file", help="Path to XML tree definition")
    run_p.add_argument("--tree", default=None, help="Tree ID to run")
    run_p.add_argument("--hz", type=float, default=None, help="Tick frequency (Hz)")
    run_p.add_argument("--max-ticks", type=int, dest="max_ticks", default=None)
    run_p.add_argument("--log", default=None, help="Save execution log (JSON)")
    run_p.add_argument("--graphviz", default=None, help="Export DOT file after load")
    run_p.add_argument("--plugin", action="append", default=[], metavar="FILE")
    run_p.add_argument("-v", "--verbose", action="store_true")
    run_p.add_argument("--viz", action="store_true", help="Enable BTViz visualization")
    run_p.add_argument("--viz-dir", dest="viz_dir", default=".", metavar="DIR",
                       help="Output directory for BTViz files (default: .)")

    # -- viz -----------------------------------------------------------
    viz_p = sub.add_parser("viz", help="Visualize a behavior tree")
    viz_p.add_argument("xml_file")
    viz_p.add_argument("--tree", default=None)
    viz_p.add_argument("--output", default="tree.dot")
    viz_p.add_argument("--format", choices=["dot", "png", "svg"], default="dot")
    viz_p.add_argument("--plugin", action="append", default=[], metavar="FILE")

    args = parser.parse_args()

    if args.command == "run":
        sys.exit(cmd_run(args))
    elif args.command == "viz":
        sys.exit(cmd_viz(args))
    else:
        parser.print_help()
        sys.exit(0)


if __name__ == "__main__":
    main()
