"""Async action node — runs work in a background thread."""
from __future__ import annotations

import threading
from concurrent.futures import Future
from typing import Optional

from bteng.core.node import NodeConfig, NodeStatus
from bteng.concurrency.cancellation_token import CancellationToken
from bteng.nodes.leaf.action import ActionNode


class AsyncActionNode(ActionNode):
    """Runs execute_async() in a background thread, returns RUNNING while in-flight.

    Override :meth:`execute_async` with long-running logic.
    Check ``token.is_cancelled()`` periodically for cooperative cancellation.

    The node can use a shared :class:`~bteng.concurrency.ThreadPool` injected
    by the executor (set_thread_pool), or falls back to daemon threads.

    Example::

        class MyTask(AsyncActionNode):
            def execute_async(self, token: CancellationToken) -> NodeStatus:
                for i in range(10):
                    if token.is_cancelled():
                        return NodeStatus.FAILURE
                    time.sleep(0.1)
                return NodeStatus.SUCCESS
    """

    JOIN_TIMEOUT = 5.0  # seconds to wait when halting

    def __init__(self, name: str, config: Optional[NodeConfig] = None) -> None:
        super().__init__(name, config)
        self._thread:       Optional[threading.Thread] = None
        self._future:       Optional[Future]           = None
        self._result:       Optional[NodeStatus]       = None
        self._cancel_token: CancellationToken          = CancellationToken.create()
        self._lock          = threading.Lock()
        self._thread_pool   = None  # Optional[ThreadPool] — injected by executor

    def set_thread_pool(self, pool: Any) -> None:
        """Inject a shared ThreadPool (called by TreeExecutor before first tick)."""
        self._thread_pool = pool

    def tick(self) -> NodeStatus:
        if self._status != NodeStatus.RUNNING:
            # Start fresh
            with self._lock:
                self._result = None
            self._cancel_token.reset()

            if self._thread_pool is not None:
                self._future = self._thread_pool.submit(
                    self.execute_async, self._cancel_token
                )
                self._thread = None
            else:
                self._future = None
                self._thread = threading.Thread(
                    target=self._thread_body,
                    daemon=True,
                    name=f"bteng-{self.name}",
                )
                self._thread.start()
            return NodeStatus.RUNNING

        # Check for completion
        if self._future is not None:
            if self._future.done():
                try:
                    return self._future.result()
                except Exception:
                    return NodeStatus.FAILURE
            return NodeStatus.RUNNING

        with self._lock:
            if self._result is not None:
                return self._result
        return NodeStatus.RUNNING

    def _thread_body(self) -> None:
        try:
            result = self.execute_async(self._cancel_token)
        except Exception:
            result = NodeStatus.FAILURE
        with self._lock:
            self._result = result

    def _on_halt(self) -> None:
        self._cancel_token.cancel()
        if self._future is not None:
            try:
                self._future.result(timeout=self.JOIN_TIMEOUT)
            except Exception:
                pass
            self._future = None
        if self._thread is not None and self._thread.is_alive():
            self._thread.join(timeout=self.JOIN_TIMEOUT)
        with self._lock:
            self._result = None
        self._thread = None

    def execute_async(self, token: CancellationToken) -> NodeStatus:
        """Override with long-running logic.  Runs in a background thread.

        Poll ``token.is_cancelled()`` (or ``token.is_set()`` for compat) to
        support cooperative cancellation when the node is halted.
        """
        raise NotImplementedError(f"{type(self).__name__}.execute_async() not implemented")


# type hint placeholder — avoids circular import with ThreadPool
from typing import Any  # noqa: E402
