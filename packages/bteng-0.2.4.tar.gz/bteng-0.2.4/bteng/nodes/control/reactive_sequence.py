"""Reactive Sequence control node."""

from __future__ import annotations

from bteng.core.node import ControlNode, NodeStatus


class ReactiveSequenceNode(ControlNode):
    """Re-evaluates ALL children from the first each tick.

    Conditions earlier in the sequence can interrupt a running action.
    * Child FAILURE → halt subsequent children, return FAILURE.
    * Child RUNNING → halt subsequent children, return RUNNING.
    * All SUCCESS → return SUCCESS.
    """

    def __init__(self, name: str = "ReactiveSequence", children=None, config=None):
        super().__init__(name, children or [], config)

    def tick(self) -> NodeStatus:
        for i, child in enumerate(self._children):
            status = child.execute_tick()

            if status == NodeStatus.FAILURE:
                self._halt_from(i + 1)
                return NodeStatus.FAILURE

            if status == NodeStatus.RUNNING:
                self._halt_from(i + 1)
                return NodeStatus.RUNNING

            # SUCCESS → continue

        return NodeStatus.SUCCESS

    def _halt_from(self, idx: int) -> None:
        for j in range(idx, len(self._children)):
            self._children[j].halt()
