"""Reactive Fallback control node."""

from __future__ import annotations

from bteng.core.node import ControlNode, NodeStatus


class ReactiveFallbackNode(ControlNode):
    """Re-evaluates ALL children from the first each tick.

    A higher-priority child succeeding can interrupt a running lower-priority child.
    * Child SUCCESS → halt subsequent children, return SUCCESS.
    * Child RUNNING → halt subsequent children, return RUNNING.
    * All FAILURE → return FAILURE.
    """

    def __init__(self, name: str = "ReactiveFallback", children=None, config=None):
        super().__init__(name, children or [], config)

    def tick(self) -> NodeStatus:
        for i, child in enumerate(self._children):
            status = child.execute_tick()

            if status == NodeStatus.SUCCESS:
                self._halt_from(i + 1)
                return NodeStatus.SUCCESS

            if status == NodeStatus.RUNNING:
                self._halt_from(i + 1)
                return NodeStatus.RUNNING

            # FAILURE → continue

        return NodeStatus.FAILURE

    def _halt_from(self, idx: int) -> None:
        for j in range(idx, len(self._children)):
            self._children[j].halt()
