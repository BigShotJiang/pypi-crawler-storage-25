"""Parallel control node."""
from __future__ import annotations

from enum import Enum
from typing import List, Optional

from bteng.core.node import ControlNode, NodeStatus, TreeNode


# ── ParallelPolicy ────────────────────────────────────────────────────────────

class ParallelPolicy(Enum):
    """Controls when ParallelNode decides to return SUCCESS or FAILURE.

    REQUIRE_ALL_SUCCESS   — Return SUCCESS only when every child has succeeded.
    REQUIRE_ONE_SUCCESS   — Return SUCCESS as soon as any single child succeeds.
    REQUIRE_ALL_COMPLETE  — Wait for every child to finish; use success_threshold
                            to determine the final result (0 = all must succeed).
    """
    REQUIRE_ALL_SUCCESS  = "require_all_success"
    REQUIRE_ONE_SUCCESS  = "require_one_success"
    REQUIRE_ALL_COMPLETE = "require_all_complete"


# ── ParallelNode ──────────────────────────────────────────────────────────────

class ParallelNode(ControlNode):
    """Tick ALL children every tick simultaneously.

    Args:
        success_threshold:
            How many children must succeed for overall SUCCESS.
            -1 (default) means all children.
            Ignored when policy=REQUIRE_ONE_SUCCESS.
        failure_threshold:
            How many children must fail for overall FAILURE. Default = 1.
        policy:
            ParallelPolicy enum controlling result computation.
            When provided, overrides threshold semantics.
    """

    def __init__(
        self,
        name:               str                         = "Parallel",
        children:           Optional[List[TreeNode]]   = None,
        config=None,
        success_threshold:  int                         = -1,
        failure_threshold:  int                         = 1,
        policy:             Optional[ParallelPolicy]   = None,
    ) -> None:
        super().__init__(name, children or [], config)
        n = len(self._children)
        self._policy            = policy
        self._failure_threshold = failure_threshold

        if policy == ParallelPolicy.REQUIRE_ONE_SUCCESS:
            self._success_threshold = 1
        elif policy in (ParallelPolicy.REQUIRE_ALL_SUCCESS, ParallelPolicy.REQUIRE_ALL_COMPLETE):
            self._success_threshold = n
        else:
            self._success_threshold = n if success_threshold < 0 else success_threshold

    def tick(self) -> NodeStatus:
        success_count = 0
        failure_count = 0

        for child in self._children:
            if child.status == NodeStatus.SUCCESS:
                success_count += 1
                continue
            if child.status == NodeStatus.FAILURE:
                failure_count += 1
                continue

            child_status = child.execute_tick()
            if child_status == NodeStatus.SUCCESS:
                success_count += 1
            elif child_status == NodeStatus.FAILURE:
                failure_count += 1

        if success_count >= self._success_threshold:
            self._halt_running_children()
            self._reset_children_status()
            return NodeStatus.SUCCESS

        if failure_count >= self._failure_threshold:
            self._halt_running_children()
            self._reset_children_status()
            return NodeStatus.FAILURE

        return NodeStatus.RUNNING

    def halt(self) -> None:
        self._halt_running_children()
        self._reset_children_status()
        self._status = NodeStatus.IDLE

    def _halt_running_children(self) -> None:
        for child in self._children:
            if child.status == NodeStatus.RUNNING:
                child.halt()

    def _reset_children_status(self) -> None:
        for child in self._children:
            child._status = NodeStatus.IDLE

    @classmethod
    def provided_ports(cls):
        from bteng.core.node import InputPort
        return [InputPort("success_threshold", "Min successes for overall SUCCESS (0=all)")]
