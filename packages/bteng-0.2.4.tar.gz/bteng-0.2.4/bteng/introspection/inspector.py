"""Runtime introspection: execution history, active path, per-node stats, explainability."""
from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Set

from bteng.core.node import NodeID, NodeStatus, NodeType


# ── NodeExecutionRecord ───────────────────────────────────────────────────────

@dataclass
class NodeExecutionRecord:
    """Immutable snapshot of one node's state after a single execute_tick() call."""
    uid:            NodeID
    name:           str
    node_type:      NodeType
    status:         NodeStatus
    tick_time:      float         # time.monotonic()
    duration:       float         # seconds
    failure_reason: str = ""
    halt_reason:    str = ""


# ── ExplainEntry ──────────────────────────────────────────────────────────────

@dataclass
class ExplainEntry:
    """One entry in the explainability log."""
    timestamp:  float
    node_uid:   NodeID
    node_name:  str
    event:      str   # "selected", "succeeded", "failed", "halted", "skipped"
    reason:     str   # e.g., "child 'CheckBattery' returned FAILURE"


# ── NodeStats ─────────────────────────────────────────────────────────────────

@dataclass
class NodeStats:
    """Per-node aggregate statistics across all ticks since last reset()."""
    tick_count:     int   = 0
    success_count:  int   = 0
    failure_count:  int   = 0
    total_duration: float = 0.0   # seconds
    max_duration:   float = 0.0
    min_duration:   float = float("inf")


# ── Inspector ─────────────────────────────────────────────────────────────────

class Inspector:
    """Passive observer that collects data as the executor runs the tree.

    WHAT IT TRACKS
    --------------
    - running_nodes_  : set of NodeIDs currently in RUNNING state
    - active_path_    : ordered list from root to deepest running node
    - history_        : ring buffer of NodeExecutionRecords (bounded by max_history)
    - stats_          : per-node tick/success/failure counts and timing aggregates
    - explain_log_    : human-readable explanations of why nodes were selected/failed

    Thread safety: a single mutex guards all mutable state.
    """

    EventCallback = Callable[["NodeExecutionRecord"], None]

    @classmethod
    def create(cls) -> "Inspector":
        return cls()

    def __init__(self, max_history: int = 50_000) -> None:
        self._lock          = threading.Lock()
        self._running_nodes: Set[NodeID]                  = set()
        self._active_path:   List[NodeID]                 = []
        self._history:       List[NodeExecutionRecord]    = []
        self._stats:         Dict[NodeID, NodeStats]      = {}
        self._explain_log:   List[ExplainEntry]           = []
        self._subscribers:   Dict[int, "Inspector.EventCallback"] = {}
        self._next_sub_id:   int = 0
        self._max_history:   int = max_history

    # ── Called by executor after each node tick ───────────────────────────────

    def on_node_tick(
        self,
        uid:            NodeID,
        name:           str,
        node_type:      NodeType,
        old_status:     NodeStatus,
        new_status:     NodeStatus,
        duration:       float,
        failure_reason: str = "",
    ) -> None:
        record = NodeExecutionRecord(
            uid=uid, name=name, node_type=node_type,
            status=new_status, tick_time=time.monotonic(),
            duration=duration, failure_reason=failure_reason,
        )
        with self._lock:
            # Update running-node set
            if new_status == NodeStatus.RUNNING:
                self._running_nodes.add(uid)
            else:
                self._running_nodes.discard(uid)

            # Update active path (simple: track all running nodes ordered by tick)
            if new_status == NodeStatus.RUNNING and uid not in self._active_path:
                self._active_path.append(uid)
            elif new_status != NodeStatus.RUNNING:
                try:
                    self._active_path.remove(uid)
                except ValueError:
                    pass

            # Append to history ring buffer
            self._history.append(record)
            if len(self._history) > self._max_history:
                self._history.pop(0)

            # Update per-node stats
            stats = self._stats.setdefault(uid, NodeStats())
            stats.tick_count     += 1
            stats.total_duration += duration
            stats.max_duration    = max(stats.max_duration, duration)
            stats.min_duration    = min(stats.min_duration, duration)
            if new_status == NodeStatus.SUCCESS:
                stats.success_count += 1
            elif new_status == NodeStatus.FAILURE:
                stats.failure_count += 1

            cbs = list(self._subscribers.values())

        for cb in cbs:
            try:
                cb(record)
            except Exception:
                pass

    def on_node_halt(self, uid: NodeID, name: str, reason: str = "") -> None:
        with self._lock:
            self._running_nodes.discard(uid)
            try:
                self._active_path.remove(uid)
            except ValueError:
                pass

    # ── Query API ─────────────────────────────────────────────────────────────

    def running_nodes(self) -> List[NodeID]:
        """NodeIDs whose status is currently RUNNING."""
        with self._lock:
            return list(self._running_nodes)

    def active_path(self) -> List[NodeID]:
        """Ordered path from root to the deepest currently-running node."""
        with self._lock:
            return list(self._active_path)

    def execution_history(self, max_entries: int = 0) -> List[NodeExecutionRecord]:
        """Return recent entries from the execution history.

        max_entries=0 returns the full buffer.
        """
        with self._lock:
            if max_entries == 0:
                return list(self._history)
            return list(self._history[-max_entries:])

    def stats_for(self, uid: NodeID) -> Optional[NodeStats]:
        with self._lock:
            return self._stats.get(uid)

    def all_stats(self) -> Dict[NodeID, NodeStats]:
        with self._lock:
            return dict(self._stats)

    # ── Explainability log ────────────────────────────────────────────────────

    def add_explanation(
        self, uid: NodeID, name: str, event: str, reason: str
    ) -> None:
        """Record a human-readable explanation of a significant execution decision."""
        entry = ExplainEntry(
            timestamp=time.monotonic(), node_uid=uid, node_name=name,
            event=event, reason=reason,
        )
        with self._lock:
            self._explain_log.append(entry)

    def explanations(self) -> List[ExplainEntry]:
        with self._lock:
            return list(self._explain_log)

    # ── Event subscriptions ───────────────────────────────────────────────────

    def subscribe(self, callback: "Inspector.EventCallback") -> int:
        """Register a listener called after each node tick.

        Returns a subscription ID for later removal.  Keep callbacks fast.
        """
        with self._lock:
            sub_id = self._next_sub_id
            self._next_sub_id += 1
            self._subscribers[sub_id] = callback
            return sub_id

    def unsubscribe(self, subscription_id: int) -> None:
        with self._lock:
            self._subscribers.pop(subscription_id, None)

    # ── Maintenance ───────────────────────────────────────────────────────────

    def reset(self) -> None:
        """Clear history, stats, and explain log (subscriptions kept)."""
        with self._lock:
            self._running_nodes.clear()
            self._active_path.clear()
            self._history.clear()
            self._stats.clear()
            self._explain_log.clear()

    def set_max_history(self, n: int) -> None:
        self._max_history = n

    def __repr__(self) -> str:
        return (
            f"Inspector(running={len(self._running_nodes)}, "
            f"history={len(self._history)}, stats={len(self._stats)})"
        )
