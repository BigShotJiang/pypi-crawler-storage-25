""" gitodo-bin-darwin-x64 """


def main() -> None:
    print("  gitodo-bin-darwin-x64  ")
