"""`keep <mission_id> supervisor ...` verb dispatch.

Covers both the CRUD verbs (create/list/show/update/remove) and the
interactive Supervisor→Worker verbs (send/read/kick).
"""

from __future__ import annotations

import json
from pathlib import Path

import typer

from keep._cli.contracts import (
    build_contract_metadata,
    build_supervisor_bootstrap_prompt_v1,
    build_supervisor_contract_v1,
)
from keep._cli.helpers import (
    ensure_file_in_messages_dir,
    ensure_worker_online_or_fail,
    extract_named_option,
    generate_session_id,
    parse_name_path_update,
    parse_worker_target_or_fail,
    require_mission_active,
    resolve_session_id_by_prefix_or_fail,
    validate_spawn_path_or_fail,
)
from keep._cli import spawn as _spawn_mod
from keep.agents.cc import CCAgent
from keep.state import (
    add_supervisor,
    append_message_index,
    find_supervisor,
    mission_terminal_type,
    mutate_mission,
    remove_supervisor,
)
from keep.terminal import get_terminal


def _cmd_create(mission_id: str, mission: dict, payload: list[str]) -> None:
    name, rest = extract_named_option(payload, "--name")
    path, rest = extract_named_option(rest, "--path")
    if rest:
        typer.echo("No such argument", err=True)
        raise typer.Exit(2)
    validate_spawn_path_or_fail(path)
    session = generate_session_id()
    append_system_prompt = build_supervisor_contract_v1()
    bootstrap_prompt = build_supervisor_bootstrap_prompt_v1(mission_id, session, name)
    contract = build_contract_metadata("supervisor", append_system_prompt, bootstrap_prompt)
    terminal_type = mission_terminal_type(mission)
    cache, _info = _spawn_mod.spawn_and_wait_for_ready(
        session,
        path,
        terminal_type=terminal_type,
        bootstrap_prompt=bootstrap_prompt,
        append_system_prompt=append_system_prompt,
        role="supervisor",
        mission_id=mission_id,
    )
    try:
        add_supervisor(
            mission_id,
            session,
            cache=cache,
            name=name,
            path=path,
            contract=contract,
        )
    except ValueError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1)
    typer.echo(f"Supervisor '{session}' 已创建。")


def _cmd_list(mission: dict) -> None:
    supervisor = find_supervisor(mission)
    if supervisor is None:
        typer.echo("(无 supervisor)")
        return
    typer.echo(supervisor["session"])


def _cmd_show(mission: dict, payload: list[str]) -> None:
    if not payload:
        typer.echo("supervisor_id is required", err=True)
        raise typer.Exit(2)
    resolved = resolve_session_id_by_prefix_or_fail(
        mission=mission,
        role="supervisor",
        raw_id=payload[0],
        id_label="supervisor_id",
    )
    supervisor = find_supervisor(mission)
    if supervisor is None or supervisor.get("session") != resolved:
        typer.echo(f"Supervisor '{payload[0]}' 不存在", err=True)
        raise typer.Exit(1)
    typer.echo(json.dumps(supervisor, ensure_ascii=False, indent=2))


def _cmd_update(mission_id: str, mission: dict, payload: list[str]) -> None:
    supervisor_id, name, path = parse_name_path_update(payload, id_label="supervisor_id")
    resolved = resolve_session_id_by_prefix_or_fail(
        mission=mission,
        role="supervisor",
        raw_id=supervisor_id,
        id_label="supervisor_id",
    )
    supervisor = find_supervisor(mission)
    if supervisor is None or supervisor.get("session") != resolved:
        typer.echo(f"Supervisor '{supervisor_id}' 不存在", err=True)
        raise typer.Exit(1)
    with mutate_mission(mission_id) as locked_mission:
        locked_sup = find_supervisor(locked_mission)
        if locked_sup is None or locked_sup.get("session") != resolved:
            typer.echo(f"Supervisor '{supervisor_id}' 不存在", err=True)
            raise typer.Exit(1)
        if name is not None:
            locked_sup["name"] = name
        if path is not None:
            locked_sup["path"] = path
    typer.echo(f"Supervisor '{resolved}' 已更新。")


def _cmd_remove(mission_id: str, mission: dict, payload: list[str]) -> None:
    if not payload:
        typer.echo("supervisor_id is required", err=True)
        raise typer.Exit(2)
    resolved = resolve_session_id_by_prefix_or_fail(
        mission=mission,
        role="supervisor",
        raw_id=payload[0],
        id_label="supervisor_id",
    )
    supervisor = find_supervisor(mission)
    if supervisor is None or supervisor.get("session") != resolved:
        typer.echo(f"Supervisor '{payload[0]}' 不存在", err=True)
        raise typer.Exit(1)
    _spawn_mod.kill_and_close_worker(supervisor, mission)
    remove_supervisor(mission_id)
    from keep._daemon import runtime_state as _rt
    _rt.purge_worker(mission_id, resolved)
    typer.echo(f"Supervisor '{resolved}' 已删除。")


def _cmd_read(mission_id: str, mission: dict, payload: list[str]) -> None:
    worker, _ = parse_worker_target_or_fail(mission, payload, command="read")
    target_worker_id = worker["session"]
    _, _, info = ensure_worker_online_or_fail(worker=worker, mission_id=mission_id, mission=mission)

    agent = CCAgent()
    if info.jsonl_path is not None:
        last = agent.last_message(target_worker_id, jsonl_path=info.jsonl_path)
    else:
        last = agent.last_message(target_worker_id)
    if last is None:
        typer.echo(f"Worker '{target_worker_id}' 暂无可读消息", err=True)
        raise typer.Exit(1)
    typer.echo(last.text)


def _cmd_send(mission_id: str, mission: dict, payload: list[str]) -> None:
    require_mission_active(mission_id, mission)
    if not payload:
        typer.echo("file_path is required", err=True)
        raise typer.Exit(2)
    worker, rest_payload = parse_worker_target_or_fail(mission, payload, command="send")
    if not rest_payload:
        typer.echo("file_path is required", err=True)
        raise typer.Exit(2)
    if len(rest_payload) != 1:
        typer.echo("supervisor send takes exactly one file path argument", err=True)
        raise typer.Exit(2)

    file_arg = rest_payload[0]
    # Reject inline strings up-front to preserve the caller-friendly error;
    # ensure_file_in_messages_dir only emits a generic "file not found".
    if not file_arg.startswith(("/", "~", "./", "../")):
        if not Path(file_arg).expanduser().is_file():
            typer.echo("Error: message must be a file path, not an inline string", err=True)
            raise typer.Exit(2)

    final_path = ensure_file_in_messages_dir(mission, file_arg, label="message file")

    sup = find_supervisor(mission)
    supervisor_session = sup["session"][:8] if sup else "unknown"
    append_message_index(mission["name"], {
        "role": "supervisor",
        "session": supervisor_session,
        "type": "send",
        "file": final_path.name,
    })

    target_worker_id = worker["session"]
    terminal_type, target_id, _ = ensure_worker_online_or_fail(
        worker=worker, mission_id=mission_id, mission=mission
    )
    message = final_path.read_text(encoding="utf-8")
    get_terminal(terminal_type).send_text(target_id, message)
    typer.echo(f"已发送到 worker '{target_worker_id}'。")


def _cmd_kick(mission_id: str, mission: dict, payload: list[str]) -> None:
    require_mission_active(mission_id, mission)
    worker, _ = parse_worker_target_or_fail(mission, payload, command="kick")
    target_worker_id = worker["session"]
    terminal_type, target_id, _ = ensure_worker_online_or_fail(
        worker=worker, mission_id=mission_id, mission=mission
    )
    get_terminal(terminal_type).send_key(target_id, "enter")
    typer.echo(f"已触发 worker '{target_worker_id}'。")


def dispatch(mission_id: str, mission: dict, command: str | None, payload: list[str]) -> None:
    if command == "create":
        _cmd_create(mission_id, mission, payload)
    elif command == "list":
        _cmd_list(mission)
    elif command == "show":
        _cmd_show(mission, payload)
    elif command == "update":
        _cmd_update(mission_id, mission, payload)
    elif command == "remove":
        _cmd_remove(mission_id, mission, payload)
    elif command == "read":
        _cmd_read(mission_id, mission, payload)
    elif command == "send":
        _cmd_send(mission_id, mission, payload)
    elif command == "kick":
        _cmd_kick(mission_id, mission, payload)
    else:
        typer.echo(f"No such command '{command}'", err=True)
        raise typer.Exit(2)
