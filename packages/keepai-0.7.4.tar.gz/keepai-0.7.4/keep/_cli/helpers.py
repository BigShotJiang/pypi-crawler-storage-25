"""Parsing, validation, and resolution helpers for CLI dispatch."""

from __future__ import annotations

import json
import os
import uuid
from datetime import datetime
from pathlib import Path

import click
import typer

from keep._cli.constants import (
    COMMAND_HELP,
    KEEP_CONFIG_PATH,
    TASK_STATUS_ALLOWED,
    UUID_CANONICAL_RE,
    UUID_PREFIX_RE,
)
from keep.state import (
    append_message_index,
    find_supervisor,
    find_worker,
    iter_reviewers,
    iter_workers,
    load_global,
    load_mission,
    messages_dir,
    mission_terminal_type,
    save_mission,
)
from keep.worker import WorkerInfo, resolve_worker, worker_cache_from_info


# ── keep config ─────────────────────────────────────────────────
def load_keep_config() -> dict:
    if KEEP_CONFIG_PATH.exists():
        return json.loads(KEEP_CONFIG_PATH.read_text())
    return {}


def save_keep_config(config: dict) -> None:
    KEEP_CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    KEEP_CONFIG_PATH.write_text(json.dumps(config, indent=2))


# ── required preconditions ─────────────────────────────────────
def require_global() -> dict:
    state = load_global()
    if state is None:
        typer.echo("没有活跃的 keep。先运行 keep self start", err=True)
        raise typer.Exit(1)
    return state


def require_mission_by_name(name: str) -> dict:
    mission = load_mission(name)
    if mission is None:
        typer.echo(f"Mission '{name}' 不存在", err=True)
        raise typer.Exit(1)
    return mission


def require_mission_active(mission_id: str, mission: dict) -> None:
    if mission.get("status") == "stopped":
        typer.echo(
            f"Mission '{mission_id}' 已停止，daemon 不会处理事件。"
            f" 请先运行：keep mission start {mission_id}",
            err=True,
        )
        raise typer.Exit(1)


# ── id / session generators ────────────────────────────────────
def generate_session_id() -> str:
    return str(uuid.uuid4())


def generate_mission_id() -> str:
    return uuid.uuid4().hex[:8]


# ── formatting ─────────────────────────────────────────────────
def format_timestamp(ts: float | None) -> str:
    if not ts:
        return "未知"
    return datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M:%S")


# ── option parsing ─────────────────────────────────────────────
def extract_named_option(args: list[str], option: str) -> tuple[str | None, list[str]]:
    rest = list(args)
    if option not in rest:
        return None, rest
    index = rest.index(option)
    if index + 1 >= len(rest):
        typer.echo(f"Missing value for {option}", err=True)
        raise typer.Exit(2)
    value = rest[index + 1]
    del rest[index:index + 2]
    return value, rest


# ── resolvers (by UUID or prefix) ──────────────────────────────
def resolve_session_id_by_prefix_or_fail(
    *,
    mission: dict,
    role: str,
    raw_id: str,
    id_label: str,
) -> str:
    participants = [
        p for p in mission.get("participants", []) if p.get("role") == role and isinstance(p.get("session"), str)
    ]
    sessions = [p["session"] for p in participants]

    if UUID_CANONICAL_RE.fullmatch(raw_id):
        if raw_id in sessions:
            return raw_id
        typer.echo(f"{id_label} '{raw_id}' 不存在", err=True)
        raise typer.Exit(1)

    if not UUID_PREFIX_RE.fullmatch(raw_id):
        typer.echo(f"{id_label} 必须是 UUID 或唯一前缀", err=True)
        raise typer.Exit(1)

    matches = [session for session in sessions if session.startswith(raw_id)]
    if not matches:
        typer.echo(f"{id_label} '{raw_id}' 不存在", err=True)
        raise typer.Exit(1)
    if len(matches) > 1:
        candidates = ", ".join(sorted(matches))
        typer.echo(f"{id_label} '{raw_id}' 歧义: {candidates}", err=True)
        raise typer.Exit(1)
    return matches[0]


def resolve_reviewer_id_by_prefix_or_fail(*, mission_id: str, raw_id: str) -> str:
    """Resolve a reviewer_id (full or prefix) to a canonical id, or exit(1)."""
    try:
        reviewers = list(iter_reviewers(mission_id))
    except ValueError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1)

    # Match by id or name first
    for r in reviewers:
        if r.get("id") == raw_id or r.get("name") == raw_id:
            return r["id"]

    ids = [r["id"] for r in reviewers if "id" in r]
    matches = [rid for rid in ids if rid.startswith(raw_id)]
    if not matches:
        typer.echo(f"Reviewer '{raw_id}' 不存在", err=True)
        raise typer.Exit(1)
    if len(matches) > 1:
        candidates = ", ".join(sorted(matches))
        typer.echo(f"Reviewer '{raw_id}' 歧义: {candidates}", err=True)
        raise typer.Exit(1)
    return matches[0]


def resolve_task_status_or_fail(status: str) -> str:
    if status not in TASK_STATUS_ALLOWED:
        allowed = ", ".join(sorted(TASK_STATUS_ALLOWED))
        typer.echo(f"Invalid --status '{status}'. allowed: {allowed}", err=True)
        raise typer.Exit(2)
    return status


# ── payload parsers ────────────────────────────────────────────
def parse_task_update_payload(payload: list[str]) -> tuple[str, dict[str, object]]:
    """Returns (task_id, patch)."""
    if payload and payload[0] in {"-h", "--help"}:
        typer.echo(COMMAND_HELP["task"]["update"])
        raise typer.Exit()
    if not payload:
        typer.echo("Task id is required", err=True)
        raise typer.Exit(2)

    task_id = payload[0]
    rest = payload[1:]
    option_map = {
        "--subject": "subject",
        "--description": "description",
        "--status": "status",
        "--owner": "owner",
        "--blocks": "blocks",
        "--blocked-by": "blockedBy",
    }

    patch: dict[str, object] = {}
    index = 0
    while index < len(rest):
        option = rest[index]
        field = option_map.get(option)
        if field is None:
            if option.startswith("--"):
                typer.echo(f"No such option '{option}'", err=True)
            else:
                typer.echo(f"Unexpected argument '{option}'", err=True)
            raise typer.Exit(2)
        if index + 1 >= len(rest):
            typer.echo(f"Missing value for {option}", err=True)
            raise typer.Exit(2)

        value = rest[index + 1]
        if field in {"blocks", "blockedBy"}:
            patch[field] = [item.strip() for item in value.split(",") if item.strip()]
        elif field == "status":
            patch[field] = resolve_task_status_or_fail(value)
        else:
            patch[field] = value
        index += 2

    return task_id, patch


def parse_name_path_update(payload: list[str], *, id_label: str) -> tuple[str, str | None, str | None]:
    if not payload:
        typer.echo(f"{id_label} is required", err=True)
        raise typer.Exit(2)

    target_id = payload[0]
    rest = payload[1:]
    name: str | None = None
    path: str | None = None
    index = 0
    while index < len(rest):
        option = rest[index]
        if option not in {"--name", "--path"}:
            if option.startswith("--"):
                typer.echo(f"No such option '{option}'", err=True)
            else:
                typer.echo(f"Unexpected argument '{option}'", err=True)
            raise typer.Exit(2)
        if index + 1 >= len(rest):
            typer.echo(f"Missing value for {option}", err=True)
            raise typer.Exit(2)
        value = rest[index + 1]
        if option == "--name":
            name = value
        else:
            path = value
        index += 2

    return target_id, name, path


def parse_worker_target_or_fail(mission: dict, payload: list[str], *, command: str) -> tuple[dict, list[str]]:
    """Select the target worker from a (possibly empty / prefixed) payload.

    Returns (worker_dict, remaining_payload_after_worker_id).
    """
    workers = iter_workers(mission)
    if payload and payload[0] in {"-h", "--help"}:
        help_text = COMMAND_HELP.get("supervisor", {}).get(command)
        if help_text:
            typer.echo(help_text)
            raise typer.Exit()
        typer.echo(f"Usage: keep <mission_id> supervisor {command} [worker_id]")
        raise typer.Exit()

    if not workers:
        typer.echo("Worker not found in mission", err=True)
        raise typer.Exit(1)

    if len(workers) == 1:
        only_worker = workers[0]
        if not payload:
            if command == "send":
                typer.echo("message is required", err=True)
                raise typer.Exit(2)
            return only_worker, []
        if payload[0].startswith("--"):
            raise click.UsageError(f"No such option '{payload[0]}'")

        if command == "send":
            if len(payload) > 1:
                resolved = resolve_session_id_by_prefix_or_fail(
                    mission=mission,
                    role="worker",
                    raw_id=payload[0],
                    id_label="worker_id",
                )
                worker = find_worker(mission, resolved)
                if worker is None:
                    typer.echo("Worker not found in mission", err=True)
                    raise typer.Exit(1)
                return worker, payload[1:]
            return only_worker, payload

        resolved = resolve_session_id_by_prefix_or_fail(
            mission=mission,
            role="worker",
            raw_id=payload[0],
            id_label="worker_id",
        )
        worker = find_worker(mission, resolved)
        if worker is None:
            typer.echo("Worker not found in mission", err=True)
            raise typer.Exit(1)
        return worker, payload[1:]

    if not payload:
        typer.echo("Multiple workers found; specify worker_id", err=True)
        raise typer.Exit(1)
    if payload[0].startswith("--"):
        raise click.UsageError(f"No such option '{payload[0]}'")
    if command == "send" and len(payload) == 1:
        typer.echo("Multiple workers found; specify worker_id", err=True)
        raise typer.Exit(1)

    resolved = resolve_session_id_by_prefix_or_fail(
        mission=mission,
        role="worker",
        raw_id=payload[0],
        id_label="worker_id",
    )
    worker = find_worker(mission, resolved)
    if worker is None:
        typer.echo("Worker not found in mission", err=True)
        raise typer.Exit(1)
    return worker, payload[1:]


# ── worker runtime cache + online check ────────────────────────
def refresh_worker_cache(worker: dict, mission_name: str, mission: dict) -> WorkerInfo:
    terminal_type = mission_terminal_type(mission)
    info = resolve_worker(worker["session"], terminal_type)
    if info.running:
        new_cache = worker_cache_from_info(info)
        # Non-cmux terminals: target_id is stable, preserve existing cache value
        if new_cache.get("target_id") is None:
            existing_target_id = (worker.get("cache") or {}).get("target_id")
            if existing_target_id:
                new_cache["target_id"] = existing_target_id
        if new_cache != worker.get("cache"):
            worker["cache"] = new_cache
            save_mission(mission_name, mission)
    return info


def ensure_worker_online_or_fail(*, worker: dict, mission_id: str, mission: dict) -> tuple[str, str, WorkerInfo]:
    info = refresh_worker_cache(worker, mission_id, mission)
    if not info.running:
        typer.echo("Worker is offline", err=True)
        raise typer.Exit(1)
    target_id = (worker.get("cache") or {}).get("target_id")
    if not target_id:
        typer.echo("Worker target unavailable", err=True)
        raise typer.Exit(1)
    return mission_terminal_type(mission), str(target_id), info


# ── path + file helpers ────────────────────────────────────────
def validate_spawn_path_or_fail(path: str | None) -> None:
    if path is None:
        return
    if not os.path.isdir(path):
        typer.echo(f"path 不存在或不是目录: {path}", err=True)
        raise typer.Exit(1)


def ensure_file_in_messages_dir(
    mission: dict, file_arg: str, label: str = "file", record_index: bool = False
) -> Path:
    """Copy file into mission messages/ dir if not already there. Returns final path.

    If record_index is True, appends an entry to index.json after copying.
    """
    src_path = Path(file_arg).expanduser().resolve()
    if not src_path.is_file():
        typer.echo(f"Error: {label} not found: {file_arg}", err=True)
        raise typer.Exit(2)
    msg_dir = messages_dir(mission["name"])
    if src_path.parent.resolve() != msg_dir.resolve():
        dest = msg_dir / src_path.name
        dest.write_bytes(src_path.read_bytes())
        typer.echo(f"Warning: {label} copied to {dest} — create new message files here.", err=True)
        final_path = dest
    else:
        final_path = src_path
    if record_index:
        sup = find_supervisor(mission)
        supervisor_session = sup["session"][:8] if sup else "unknown"
        append_message_index(mission["name"], {
            "role": "supervisor",
            "session": supervisor_session,
            "type": "rationale",
            "file": final_path.name,
        })
    return final_path


def is_daemon_running(global_state: dict) -> bool:
    pid = global_state.get("daemon_pid")
    if not pid:
        return False
    try:
        os.kill(pid, 0)
        return True
    except (ProcessLookupError, TypeError):
        return False
