"""Mission-scoped dispatch: `keep <mission_id> <resource> <command> ...`.

Routes to the per-resource module (`dispatch_task`, `dispatch_worker`,
`dispatch_supervisor`, `dispatch_reviewer`) after loading the mission.
"""

from __future__ import annotations

import typer

from keep._cli import (
    dispatch_reviewer,
    dispatch_supervisor,
    dispatch_task,
    dispatch_worker,
)
from keep._cli.helpers import require_global, require_mission_by_name


def dispatch_mission_scoped(mission_id: str, args: list[str]) -> None:
    if not args:
        typer.echo(f"Mission '{mission_id}' requires a scoped command", err=True)
        raise typer.Exit(2)

    require_global()
    mission = require_mission_by_name(mission_id)
    resource = args[0]
    command = args[1] if len(args) > 1 else None
    payload = args[2:]

    if resource == "task":
        dispatch_task.dispatch(mission_id, mission, command, payload)
    elif resource == "worker":
        dispatch_worker.dispatch(mission_id, mission, command, payload)
    elif resource == "supervisor":
        dispatch_supervisor.dispatch(mission_id, mission, command, payload)
    elif resource == "reviewer":
        dispatch_reviewer.dispatch(mission_id, mission, command, payload)
    else:
        typer.echo(f"No such command '{resource}'", err=True)
        raise typer.Exit(2)
