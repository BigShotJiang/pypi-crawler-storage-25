"""Claude-session spawn, readiness wait, terminal teardown, daemon launch.

All I/O that touches real terminals / subprocesses / signals lives here so the
rest of `_cli/` remains pure orchestration. Tests stub these symbols via
`monkeypatch.setattr("keep._cli.spawn.<name>", ...)`.
"""

from __future__ import annotations

import json
import os
import shlex
import signal
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Callable

import typer

from keep.agents.cc import CCAgent
from keep.state import (
    STATE_DIR,
    iter_workers,
    load_mission,
    mission_terminal_type,
    save_global,
    set_mission_container,
)
from keep.terminal import get_terminal
from keep.worker import WorkerInfo, resolve_worker, worker_cache_from_info


def spawn_claude_session(
    session: str,
    path: str | None,
    *,
    bootstrap_prompt: str,
    append_system_prompt: str,
    terminal_type: str,
    role: str,
    mission_id: str,
) -> str:
    """Spawn a Claude session inside the mission's shared terminal container.

    Ensures the container exists (creating it on first call for the mission),
    persists the ref onto ``mission["terminal_container"]``, and spawns the
    participant at the role-appropriate location. Returns the target_id of
    the newly spawned surface.
    """
    target_path = path or os.getcwd()

    prompt_fd, prompt_path = tempfile.mkstemp(prefix="keep-sysprompt-", suffix=".txt")
    try:
        os.write(prompt_fd, append_system_prompt.encode())
    finally:
        os.close(prompt_fd)

    claude_cmd = (
        f"claude --dangerously-skip-permissions {shlex.quote(bootstrap_prompt)}"
        f" --session-id {shlex.quote(session)}"
        f" --append-system-prompt-file {shlex.quote(prompt_path)}"
    )

    mission = load_mission(mission_id)
    if mission is None:
        raise RuntimeError(f"Mission {mission_id!r} not found")

    terminal = get_terminal(terminal_type)
    ref = mission.get("terminal_container")
    if ref is None:
        ref = terminal.ensure_mission_container(mission_id)
        set_mission_container(mission_id, ref)

    if role == "supervisor":
        role_index = 0
    elif role == "reviewer":
        role_index = 0
    elif role == "worker":
        # Re-read mission under the lock elsewhere; here we just need the
        # current worker count to pick a fresh index. Concurrent worker
        # creations in the same mission are serialised upstream by
        # `mutate_mission`, so the index we compute here stays correct.
        fresh = load_mission(mission_id) or mission
        role_index = sum(1 for _ in iter_workers(fresh))
    else:
        raise ValueError(f"unknown role: {role!r}")

    target_id = terminal.spawn_in_container(ref, role, role_index, target_path, claude_cmd)
    return target_id


def is_ready_message_present(jsonl_path: str | Path | None) -> bool:
    if not jsonl_path:
        return False
    agent = CCAgent()
    last = agent.last_message("", jsonl_path=jsonl_path)
    return last is not None and bool(last.text.strip())


def wait_for_worker_ready(
    session: str,
    *,
    terminal_type: str,
    attempts: int = 10,
    interval: float = 0.2,
) -> WorkerInfo:
    info = resolve_worker(session, terminal_type)
    jsonl_attempts = max(attempts, 300)
    for _ in range(jsonl_attempts - 1):
        if info.jsonl_path is not None:
            break
        time.sleep(interval)
        info = resolve_worker(session, terminal_type)

    if info.jsonl_path is None:
        return info

    ready_attempts = max(attempts, 300)
    for _ in range(ready_attempts):
        if is_ready_message_present(info.jsonl_path):
            return info
        time.sleep(interval)
    raise TimeoutError(f"Session '{session}' did not reach ready state")


def spawn_and_wait_for_ready(
    session: str,
    path: str | None,
    *,
    terminal_type: str,
    bootstrap_prompt: str,
    append_system_prompt: str,
    role: str,
    mission_id: str,
    on_failure: Callable[[], None] | None = None,
) -> tuple[dict, WorkerInfo]:
    """Spawn a Claude session and block until transcript signals readiness.

    Returns (cache, info). On timeout or missing jsonl, invokes `on_failure`
    (for rollback cleanup) then raises `typer.Exit(1)` after printing the error.
    """
    target_id = spawn_claude_session(
        session,
        path,
        bootstrap_prompt=bootstrap_prompt,
        append_system_prompt=append_system_prompt,
        terminal_type=terminal_type,
        role=role,
        mission_id=mission_id,
    )
    try:
        info = wait_for_worker_ready(session, terminal_type=terminal_type)
    except TimeoutError as exc:
        typer.echo(str(exc), err=True)
        if on_failure is not None:
            try:
                on_failure()
            except Exception:
                pass
        raise typer.Exit(1)
    if info.jsonl_path is None:
        typer.echo(f"未找到可用的 session '{session}'", err=True)
        if on_failure is not None:
            try:
                on_failure()
            except Exception:
                pass
        raise typer.Exit(1)
    cache = worker_cache_from_info(info)
    if target_id and not cache.get("target_id"):
        cache["target_id"] = target_id
    return cache, info


def kill_and_close_worker(worker: dict, mission: dict) -> None:
    """Kill worker process (if running) and close its terminal surface. Best-effort, never raises."""
    try:
        info = resolve_worker(worker["session"], None)
        if info.running and info.pid:
            try:
                os.kill(info.pid, signal.SIGTERM)
            except (ProcessLookupError, OSError):
                pass
        target_id = (worker.get("cache") or {}).get("target_id")
        if target_id:
            try:
                get_terminal(mission_terminal_type(mission)).close(target_id)
            except Exception:
                pass
    except Exception:
        pass


def launch_daemon(global_state: dict, foreground: bool) -> None:
    global_state["stopped"] = False
    if foreground:
        global_state["daemon_pid"] = os.getpid()
        save_global(global_state)
        typer.echo(f"Daemon 已启动，PID {os.getpid()}，前台模式。")
        from keep.daemon import run_daemon
        run_daemon()
        return

    STATE_DIR.mkdir(parents=True, exist_ok=True)
    with open(STATE_DIR / "daemon.log", "a", encoding="utf-8") as log_file:
        proc = subprocess.Popen(
            [sys.executable, "-m", "keep.daemon_runner"],
            stdout=log_file,
            stderr=log_file,
        )
    global_state["daemon_pid"] = proc.pid
    save_global(global_state)
    typer.echo(f"Daemon 已启动，PID {proc.pid}，后台模式。")


def check_stop_hook_or_fail() -> None:
    """Block mission start if the Claude stop hook is not correctly configured."""
    hook_script = STATE_DIR / "on-stop.sh"
    config_dir = os.environ.get("CLAUDE_CONFIG_DIR") or str(Path.home() / ".claude")
    settings_path = Path(config_dir) / "settings.json"

    errors: list[str] = []

    if not hook_script.exists():
        errors.append(
            f"  缺少 stop hook 脚本: {hook_script}\n"
            f"  修复：cat > {hook_script} << 'EOF'\n"
            f"  #!/bin/bash\n"
            f"  INPUT=$(cat)\n"
            f"  SESSION_ID=$(echo \"$INPUT\" | jq -r '.session_id')\n"
            f"  echo \"$INPUT\" > {STATE_DIR}/stop-${{SESSION_ID}}\n"
            f"  EOF\n"
            f"  chmod +x {hook_script}"
        )

    if settings_path.exists():
        try:
            settings = json.loads(settings_path.read_text())
        except Exception as exc:
            errors.append(
                f"  Claude settings 解析失败: {settings_path}\n"
                f"  错误: {exc}\n"
                f"  修复：检查 JSON 语法或重新生成 settings.json"
            )
            settings = None
        if settings is not None:
            stop_hooks = settings.get("hooks", {}).get("Stop", [])
            hook_str = json.dumps(stop_hooks)
            # Match both absolute path and ~ shorthand
            hook_tilde = str(hook_script).replace(str(Path.home()), "~")
            if str(hook_script) not in hook_str and hook_tilde not in hook_str:
                errors.append(
                    f"  Claude settings 未配置 stop hook: {settings_path}\n"
                    f"  修复：在 settings.json 的 hooks.Stop 中添加:\n"
                    f'  {{"type": "command", "command": "bash {hook_script}"}}'
                )
    else:
        errors.append(
            f"  未找到 Claude settings: {settings_path}\n"
            f"  修复：创建 {settings_path} 并配置 hooks.Stop"
        )

    if errors:
        typer.echo(
            "Mission 无法启动：stop hook 未生效，worker 完成后 supervisor 将收不到通知。\n"
            + "\n".join(errors),
            err=True,
        )
        raise typer.Exit(1)
