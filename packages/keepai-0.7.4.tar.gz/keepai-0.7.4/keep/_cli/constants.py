"""Static text and validation data for the CLI layer."""

from __future__ import annotations

import re
from pathlib import Path

KEEP_CONFIG_PATH = Path.home() / ".keep" / "config.json"

_HELP = """keep CLI

全局主体只有：
  self
  mission
"""

MISSION_HELP = """mission 管理

Commands:
  create
  update
  remove
  list
  show
  start
  stop

Mission-scoped 用法:
  keep <mission_id> task ...
  keep <mission_id> supervisor ...
  keep <mission_id> worker ...
  keep <mission_id> reviewer ...

继续查看:
  keep mission task -h
  keep mission supervisor -h
  keep mission worker -h
  keep mission reviewer -h
"""

MISSION_SCOPED_HELP = {
    "task": """Usage: keep <mission_id> task [OPTIONS] COMMAND [ARGS]...\n\nCommands:\n  create\n  update\n  remove\n  list\n  show\n  review\n""",
    "supervisor": """Usage: keep <mission_id> supervisor [OPTIONS] COMMAND [ARGS]...\n\nCommands:\n  create\n  update\n  remove\n  list\n  show\n  send\n  read\n  kick\n""",
    "worker": """Usage: keep <mission_id> worker [OPTIONS] COMMAND [ARGS]...\n\nCommands:\n  create\n  update\n  remove\n  list\n  show\n""",
    "reviewer": """Usage: keep <mission_id> reviewer [OPTIONS] COMMAND [ARGS]...\n\nCommands:\n  create\n  update\n  remove\n  list\n  show\n  <event_id> pass [<rationale_msg_file>]\n  <event_id> reject <rationale_msg_file>\n""",
}

OLD_ROOT_COMMANDS = {
    "start", "stop", "resume", "status", "send", "read", "kick",
    "transcript", "plan", "prompt", "worker",
}

TASK_STATUS_ALLOWED = {
    "draft", "pending", "in_progress", "awaiting_review", "claimed",
    "completed", "deleted",
}

REVIEW_EVENT_TERMINAL_VERDICTS = {"pass", "reject"}

UUID_CANONICAL_RE = re.compile(
    r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
)
UUID_PREFIX_RE = re.compile(r"^[0-9a-fA-F-]{1,36}$")

CREATE_HELP = {
    "supervisor": """Usage: keep <mission_id> supervisor create [OPTIONS]\n\nOptions:\n  --name TEXT\n  --path TEXT\n  -h, --help
""",
    "worker": """Usage: keep <mission_id> worker create [OPTIONS]\n\nOptions:\n  --name TEXT\n  --path TEXT\n  -h, --help
""",
    "reviewer": """Usage: keep <mission_id> reviewer create [OPTIONS]\n\nOptions:\n  --name TEXT\n  --path TEXT\n  -h, --help
""",
}

COMMAND_HELP = {
    "task": {
        "create": """Usage: keep <mission_id> task create <subject>\n""",
        "update": """Usage: keep <mission_id> task update <task_id> [--subject TEXT] [--description TEXT] [--status TEXT] [--owner TEXT] [--blocks CSV] [--blocked-by CSV]\n""",
    },
    "supervisor": {
        "send": """Usage: keep <mission_id> supervisor send [worker_id] <file_path>\n\nSupervisor→Worker 单向工具：supervisor 发送指令文件给指定 worker。\n""",
        "read": """Usage: keep <mission_id> supervisor read [worker_id]\n""",
        "kick": """Usage: keep <mission_id> supervisor kick [worker_id]\n""",
    },
}
