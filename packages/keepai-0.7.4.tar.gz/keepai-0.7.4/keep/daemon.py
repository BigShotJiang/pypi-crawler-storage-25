"""后台守护进程（public facade）：纯事件接力，不做决策。

两个核心职责：
1. Stop  — Worker 完成 → 通知 Supervisor
2. Stall — JSONL 心跳停跳（3 分钟无写入）→ 通知 Supervisor

Plus: Reviewer 事件路由、mission 同步、async hooks、quiescent 检测。

Implementation is split across `keep._daemon.*` sub-modules by responsibility
(constants, runtime_state, xml_format, notify, review, worker_check,
quiescent, loop). This module re-exports the public API unchanged; external
callers should keep importing from `keep.daemon`.

Test helpers (`_build_event_xml`, `_format_stall_msg`, `_check_worker`, …) are
re-exported under their historical underscore-prefixed names so existing
`test_daemon_stall.py` imports continue to resolve.

`get_terminal` is rebound here so tests that do
`monkeypatch.setattr("keep.daemon.get_terminal", fake)` continue to work; the
actual call site in `_daemon.notify` reads the attribute dynamically from
`keep.terminal`.
"""

from __future__ import annotations

# ── Constants (timing, signal files, event types, logger) ─────────
from keep._daemon.constants import (
    EV_MISSION_QUIESCENT,
    EV_MISSION_STOP,
    EV_TASK_RATIONALE,
    EV_TASK_REVIEW,
    LOG_FILE,
    MIN_NOTIFY_INTERVAL,
    POLL_INTERVAL,
    QUIESCENT_TIMEOUT,
    REPLY_INLINE_LIMIT,
    RUNTIME_STATE_FILE,
    STALL_MAX_COUNT,
    STALL_SUSPEND_HINT_AT,
    STALL_TIMEOUT,
    SUPERVISOR_QUIESCENT_DELAY,
    log,
    mission_stop_signal_file,
    mission_sync_signal_file,
    stop_file,
)
from keep._daemon.loop import run_daemon

# Test-facing re-exports (historical underscore-prefixed names). Keep these
# even if tests currently look stale — the explicit export surface is our
# contract, and yanking them silently would make future bug investigations
# harder.
from keep._daemon.notify import (
    notify_all_reviewers,
    notify_reviewer,
    notify_supervisor,
    send_to_surface as _send_to_surface,
    sync_mission_to_reviewers,
)
from keep._daemon.runtime_state import (
    first_stop_suppressed as _first_stop_suppressed,
    last_notify as _last_notify,
    last_stall as _last_stall,
    load as _load_runtime_state,
    pending_stop_event as _pending_stop_event,
    quiescent_fired as _quiescent_fired,
    quiescent_since as _quiescent_since,
    review_dispatched as _review_dispatched,
    save as _save_runtime_state,
    stall_closed as _stall_closed,
    stall_count as _stall_count,
    supervisor_stopped_since as _supervisor_stopped_since,
)
from keep._daemon.worker_check import check_worker as _check_worker
from keep._daemon.xml_format import (
    build_event_xml as _build_event_xml,
    build_review_summary as _build_review_summary,
    format_aggregated_stall_msg as _format_aggregated_stall_msg,
    format_review_request_msg as _format_review_request_msg,
    format_stall_msg as _format_stall_msg,
    format_stop_msg as _format_stop_msg,
)

# Rebind imports that tests/conftest monkeypatch on this module.
from keep.state import STATE_DIR  # re-export for historical imports
from keep.terminal import get_terminal  # conftest patches this name


__all__ = [
    # Timing / policy constants
    "POLL_INTERVAL",
    "MIN_NOTIFY_INTERVAL",
    "STALL_TIMEOUT",
    "STALL_MAX_COUNT",
    "STALL_SUSPEND_HINT_AT",
    "REPLY_INLINE_LIMIT",
    "QUIESCENT_TIMEOUT",
    "SUPERVISOR_QUIESCENT_DELAY",
    # Paths + signal files
    "LOG_FILE",
    "RUNTIME_STATE_FILE",
    "STATE_DIR",
    "mission_stop_signal_file",
    "mission_sync_signal_file",
    "stop_file",
    # Logger
    "log",
    # Terminal (patched by conftest)
    "get_terminal",
    # Notify
    "notify_supervisor",
    "notify_reviewer",
    "notify_all_reviewers",
    "sync_mission_to_reviewers",
    # Main entry
    "run_daemon",
]
