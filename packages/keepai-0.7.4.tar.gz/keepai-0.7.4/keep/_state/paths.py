"""Shared filesystem paths, atomic write, name validation.

Everything else in `_state` depends on this module. Keep it dependency-free.

Tests monkeypatch `STATE_DIR` / `MISSIONS_DIR` / `GLOBAL_FILE` on this module
(via the `keep.state` facade). Sub-modules must read these dynamically, i.e.
`from keep._state import paths as _paths` then `_paths.STATE_DIR`, not
`from keep._state.paths import STATE_DIR`. Otherwise the patch won't propagate.
"""

from __future__ import annotations

import logging
import os
import re
from pathlib import Path

_log = logging.getLogger("keep.state")

STATE_DIR = Path.home() / ".keep"
GLOBAL_FILE = STATE_DIR / "global.json"
MISSIONS_DIR = STATE_DIR / "missions"

_MISSION_NAME_RE = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9_-]*$")

DEFAULT_TERMINAL = "cmux"
VALID_TERMINALS = frozenset({"cmux", "tmux", "terminal", "kitty", "iterm2"})


def _ensure_dirs() -> None:
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    MISSIONS_DIR.mkdir(parents=True, exist_ok=True)


def atomic_write_text(path: Path, text: str) -> None:
    """Write text to path atomically: write to .tmp then os.replace.

    Prevents partial / corrupt JSON if the process dies mid-write.
    """
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def _validate_mission_name(name: str) -> None:
    if not _MISSION_NAME_RE.match(name):
        raise ValueError(
            f"Mission name 不合法: '{name}'（只允许字母、数字、-、_，不能以 -/_ 开头）"
        )
