"""Internal state package.

`keep.state` is the public facade that re-exports everything from here.
Modules are split by responsibility (mission, tasks, reviewers, transcript, etc.).
External callers should continue to import from `keep.state`; this package
is an implementation detail.
"""
