"""Inline/file content resolution helper."""

from __future__ import annotations

from pathlib import Path


def resolve_content(value: str | None) -> str:
    """解析内容：如果是文件路径则读取文件，否则原样返回。

    CPython 3.12 `Path.is_file()` 没把 ENAMETOOLONG (errno 63) 加进 _ignore_error
    白名单——macOS 单段路径字节 > 255（中文 3 字节，inline 长内容很容易踩）会抛
    OSError 而不是返回 False。CPython 3.14 已修。这里手动兜底。
    """
    if not value:
        return ""
    path = Path(value).expanduser()
    try:
        is_file = path.is_file()
    except OSError:
        is_file = False
    if is_file:
        return path.read_text()
    return value
