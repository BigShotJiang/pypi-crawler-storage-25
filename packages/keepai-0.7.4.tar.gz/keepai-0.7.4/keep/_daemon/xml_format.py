"""XML message construction for daemon → supervisor / reviewer notifications.

All outgoing `<keep event=...>` payloads route through `build_event_xml` so
attribute quoting / escaping is uniform and single-line (Escape breaks
Claude Code mid-generation if multi-line).
"""

from __future__ import annotations

from pathlib import Path
from typing import Any
from xml.sax.saxutils import escape as xml_escape, quoteattr

from keep._daemon.constants import (
    EV_MISSION_QUIESCENT,
    EV_MISSION_STOP,
    EV_TASK_RATIONALE,
    EV_TASK_REVIEW,
    STALL_MAX_COUNT,
    STALL_SUSPEND_HINT_AT,
    log,
)


def build_event_xml(
    kind: str,
    attrs: dict[str, str],
    body: str = "",
) -> str:
    """Build a well-formed `<keep event=... ...>body</keep>` element.

    - Attribute values go through `xml.sax.saxutils.quoteattr` (which
      handles both quoting and escaping in one step and returns the value
      already wrapped in quotes).
    - `body` is embedded **as-is**. The caller is responsible for
      constructing valid body content: plain text must already be
      `xml_escape`-d, nested elements must have their own text content
      escaped. The helper does not guess structure.
    - Empty body → self-closing tag `<keep ... />`.

    Returns a single-line XML string (no embedded newlines).
    """
    attr_str = " ".join(f"{k}={quoteattr(v)}" for k, v in attrs.items())
    if attr_str:
        open_tag = f"<keep event={quoteattr(kind)} {attr_str}"
    else:
        open_tag = f"<keep event={quoteattr(kind)}"
    if not body:
        return f"{open_tag}/>"
    return f"{open_tag}>{body}</keep>"


def format_stall_msg(
    mission_name: str,
    session: str,
    age: int,
    stall_count: int,
) -> str:
    body = ""
    if stall_count == STALL_SUSPEND_HINT_AT:
        body = xml_escape(
            f"若认为此 worker 工作已告一段落，可 `keep {mission_name} worker remove {session[:8]}` 暂停，"
            f"需要时用 `keep {mission_name} worker create --session {session}` 拉回。"
        )
    return build_event_xml(
        "stall",
        {
            "mission": mission_name,
            "worker": session,
            "silent": f"{age}s",
            "stall_count": str(stall_count),
            "stall_max": str(STALL_MAX_COUNT),
        },
        body,
    )


def format_stop_msg(
    mission_name: str,
    session: str,
    last_msg: str,
    output_file: Path | None = None,
) -> str:
    """构造 stop 事件消息，含嵌套 `<reply>` 元素。

    `last_msg` 是 Worker 任意文本回复（经常包含 `<`, `>`, `&`, 甚至字面
    `</reply>` / `</keep>` ——review 报告、代码示例、XML 讨论都会命中），
    必须在包进 `<reply>` 前 `xml_escape`。外层标签和属性交给 `build_event_xml`。
    """
    attrs: dict[str, str] = {"mission": mission_name, "worker": session}
    if output_file:
        attrs["output_file"] = str(output_file)
    escaped_reply = xml_escape(last_msg)
    return build_event_xml("stop", attrs, f"<reply>{escaped_reply}</reply>")


def format_aggregated_stall_msg(
    mission_name: str,
    stalls: list[dict[str, Any]],
) -> str:
    """多 worker 同时 stall 时的聚合消息，一条代替 N 条。"""
    max_count = max(s["stall_count"] for s in stalls)
    return build_event_xml(
        "stall",
        {
            "mission": mission_name,
            "workers": str(len(stalls)),
            "stall_count_max": str(max_count),
            "stall_max": str(STALL_MAX_COUNT),
        },
    )


def format_review_request_msg(
    mission_name: str,
    event_id: str,
    event_type: str,
    summary: str,
) -> str:
    """构造发给 Reviewer 的 review 请求消息。"""
    body = xml_escape(summary)
    return build_event_xml(
        "review_request",
        {"mission": mission_name, "event_id": event_id, "type": event_type},
        body,
    )


# ── Review summary builder ────────────────────────────────────────
def _read_rationale(rationale_path: str) -> str:
    """Read a rationale file if path is set; return a pre-formatted block.

    Returns empty string if no path configured; returns a sentinel line if the
    file is missing so the reviewer sees *something* actionable.
    """
    if not rationale_path:
        return ""
    try:
        return "\n\nSupervisor rationale:\n" + Path(rationale_path).read_text(encoding="utf-8")
    except OSError:
        return f"\n\nSupervisor rationale: (file not found: {rationale_path})"


def build_review_summary(event: dict[str, Any], mission_name: str) -> str:
    """Build a human-readable summary for a review event dispatch."""
    event_type = event.get("type")
    event_id = event.get("id", "?")
    if not event_type:
        log.error(
            "Review event %s [%s] missing 'type' field — using fallback summary; event=%r",
            event_id, mission_name, event,
        )
        return f"Review event {event_id} (UNKNOWN TYPE) pending verdict."

    builder = _SUMMARY_BUILDERS.get(event_type)
    if builder is None:
        return f"Review event {event_id} ({event_type}) pending verdict."
    return builder(event, mission_name, event_id)


def _summary_task_review(event: dict[str, Any], mission_name: str, event_id: str) -> str:
    task_ids = event.get("task_ids", [])
    subjects = event.get("task_subjects", task_ids)
    rationale_text = _read_rationale(event.get("rationale", ""))
    return (
        f"{len(task_ids)} tasks awaiting review:\n"
        + "\n".join(str(s) for s in subjects)
        + rationale_text
        + f"\nSubmit verdict: keep {mission_name} reviewer {event_id} pass|reject <file>"
    )


def _summary_task_rationale(event: dict[str, Any], mission_name: str, event_id: str) -> str:
    task_ids = event.get("task_ids") or (
        [str(event["task_id"])] if event.get("task_id") else []
    )
    subjects = event.get("task_subjects", [])
    rationale_text = _read_rationale(event.get("rationale", ""))
    tasks_text = "\n".join(
        subjects[i] if i < len(subjects) else f"Task #{tid}"
        for i, tid in enumerate(task_ids)
    )
    return (
        tasks_text
        + rationale_text
        + f"\nSubmit verdict: keep {mission_name} reviewer {event_id} pass|reject <file>"
    )


def _summary_mission_stop(event: dict[str, Any], mission_name: str, event_id: str) -> str:
    rationale_text = _read_rationale(event.get("rationale", ""))
    return (
        f"Mission '{mission_name}' stop requested."
        f"{rationale_text}\n"
        f"Approve to stop, reject to continue.\n"
        f"Submit: keep {mission_name} reviewer {event_id} pass|reject <file>"
    )


def _summary_mission_quiescent(event: dict[str, Any], mission_name: str, event_id: str) -> str:
    idle_secs = event.get("idle_seconds", 0)
    if idle_secs == 0:
        context = "supervisor stopped without creating any workers"
    else:
        idle_min = idle_secs // 60
        context = f"supervisor and all workers have been idle for {idle_min}+ minutes"
    return (
        f"Mission '{mission_name}' has gone quiescent: {context}.\n"
        f"Review the supervisor's last output and decide:\n"
        f"  - pass: supervisor has completed its work or is unrecoverable → mission will be stopped\n"
        f"  - reject + rationale: supervisor should continue → rationale will be sent to supervisor as a wake-up message\n"
        f"Submit: keep {mission_name} reviewer {event_id} pass|reject <file>"
    )


_SUMMARY_BUILDERS = {
    EV_TASK_REVIEW: _summary_task_review,
    EV_TASK_RATIONALE: _summary_task_rationale,
    EV_MISSION_STOP: _summary_mission_stop,
    EV_MISSION_QUIESCENT: _summary_mission_quiescent,
}
