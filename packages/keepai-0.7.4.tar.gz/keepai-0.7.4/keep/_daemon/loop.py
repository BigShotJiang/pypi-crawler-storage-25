"""Daemon main loop: iterate missions, route events, sleep, repeat.

Intentionally thin — all detection and notification logic lives in sibling
modules (`worker_check`, `quiescent`, `review`, `notify`). `run_daemon` is the
only function exported back to the public facade.
"""

from __future__ import annotations

import os
import signal
import sys
import time
from typing import Any

from keep._daemon import runtime_state
from keep._daemon.constants import POLL_INTERVAL, log
from keep._daemon.constants import stop_file as _stop_file  # noqa: F401  (re-exported via facade)
from keep._daemon.notify import notify_supervisor
from keep._daemon.quiescent import check_quiescent
from keep._daemon.review import (
    check_mission_stop_signal,
    check_mission_sync_signal,
    check_pending_review_verdicts,
    check_task_review_events,
)
from keep._daemon.worker_check import check_worker
from keep._daemon.xml_format import format_aggregated_stall_msg, format_stall_msg
from keep.hooks import fire_hook
from keep.state import (
    STATE_DIR,
    find_supervisor,
    iter_workers,
    list_missions,
    list_tasks,
    load_global,
    load_mission,
    write_and_index_message,
)


def _startup() -> None:
    """One-time daemon startup: clean stale signals, restore runtime state."""
    log.info("Daemon started (pid=%d)", os.getpid())

    for f in STATE_DIR.glob("stop-*"):
        f.unlink(missing_ok=True)
        log.info(f"Cleaned stale signal: {f.name}")

    runtime_state.load()


def _install_signal_handlers() -> None:
    def handle_signal(signum: int, frame: Any) -> None:
        log.info("Daemon stopping")
        sys.exit(0)

    signal.signal(signal.SIGTERM, handle_signal)
    signal.signal(signal.SIGINT, handle_signal)


def _write_stall_to_messages(mission_name: str, stall_batch: list[dict[str, Any]], msg: str) -> None:
    """Persist stall event to messages/ index. Never raises."""
    try:
        if len(stall_batch) == 1:
            write_and_index_message(
                mission_name,
                role="daemon",
                session=stall_batch[0]["session"],
                event_type="stall",
                content=msg,
            )
        else:
            write_and_index_message(
                mission_name,
                role="daemon",
                event_type="stall",
                content=msg,
            )
    except Exception as e:
        log.warning("Failed to write stall event to messages/ [%s]: %s", mission_name, e)


def _process_stall_batch(mission_name: str, mission: dict[str, Any], stall_batch: list[dict[str, Any]]) -> None:
    """Build, persist, notify, fire hook for a batch of simultaneous stalls."""
    if not stall_batch:
        return
    if len(stall_batch) == 1:
        s = stall_batch[0]
        msg = format_stall_msg(
            mission_name,
            s["session"],
            s["age"],
            s["stall_count"],
        )
    else:
        msg = format_aggregated_stall_msg(mission_name, stall_batch)

    _write_stall_to_messages(mission_name, stall_batch, msg)
    notify_supervisor(mission, msg)
    fire_hook("stall", {"mission": mission_name, "workers": len(stall_batch)})


def _tick_mission(mission_name: str) -> None:
    """Run one tick of detection / routing for a single mission.

    Returns early when mission is stopped / paused / unclaimed.
    """
    mission = load_mission(mission_name)
    if mission is None or mission.get("status") in {"stopped", "paused"}:
        return

    # ── mission stop signal (from CLI) ──────────────────────
    # Must be checked before supervisor guard, because stop signal is written
    # by the CLI before setting status=stopped.
    if check_mission_stop_signal(mission_name, mission):
        return  # Mission was stopped immediately
    mission = load_mission(mission_name) or mission
    if mission.get("status") == "stopped":
        return

    # Unclaimed mission = dormant. 没 supervisor 说明还没 wire 起来，
    # 主动跳过比"跑完再丢弃"更干净，也不留 warning 噪声。
    if not find_supervisor(mission):
        return

    # ── reviewer verdict polling ────────────────────────────
    # Check pending review events; settle any where all reviewers have
    # submitted (this mutates mission state, reload afterwards).
    check_pending_review_verdicts(mission_name, mission)
    mission = load_mission(mission_name) or mission
    if mission.get("status") == "stopped":
        return

    # ── mission sync signal (from mission update / reviewer add) ──
    check_mission_sync_signal(mission_name, mission)

    # Fetch tasks once; shared by rationale check, review check, and align detection.
    try:
        current_tasks: list[dict[str, Any]] = list_tasks(mission_name)
    except Exception as e:
        log.warning("Failed to list tasks [%s]: %s", mission_name, e)
        current_tasks = []

    # ── task review events ──────────────────────────────────
    check_task_review_events(mission_name, mission, tasks=current_tasks)

    # ── worker stop/stall detection ─────────────────────────
    stall_batch: list[dict[str, Any]] = []
    for worker in iter_workers(mission):
        stall = check_worker(mission_name, mission, worker)
        if stall:
            stall_batch.append(stall)
    _process_stall_batch(mission_name, mission, stall_batch)

    # ── quiescent detection ─────────────────────────────────
    check_quiescent(mission_name, mission)


def run_daemon() -> None:
    _startup()
    _install_signal_handlers()

    while True:
        try:
            g = load_global()
            if g is None:
                log.info("No active keep, exiting")
                break

            for mission_name in list_missions():
                _tick_mission(mission_name)

        except Exception:
            log.exception("Daemon main loop error")

        time.sleep(POLL_INTERVAL)
