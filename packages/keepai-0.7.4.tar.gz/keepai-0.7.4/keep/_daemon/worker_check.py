"""Per-worker stop / stall detection.

`check_worker` is called once per worker per tick. It:
  - consumes stop-file → persists reply → notifies supervisor (with first-stop
    suppression + throttle), returns None
  - detects JSONL-mtime stall and returns a stall info dict for batching
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any

from keep._daemon import runtime_state
from keep._daemon.constants import (
    MIN_NOTIFY_INTERVAL,
    REPLY_INLINE_LIMIT,
    STALL_MAX_COUNT,
    STALL_TIMEOUT,
    log,
    stop_file,
)
from keep._daemon.notify import notify_supervisor
from keep._daemon.xml_format import format_stop_msg
from keep.state import (
    append_transcript,
    mutate_mission,
    worker_session_id,
    write_and_index_message,
)


def _save_worker_output(
    mission_name: str,
    session: str,
    content: str,
) -> Path | None:
    """把 Worker 的 stop 回复写入 messages/ 并追加索引，返回路径。内容为空则返回 None。"""
    if not content:
        return None
    try:
        _, out_file = write_and_index_message(
            mission_name,
            role="worker",
            session=session,
            event_type="stop",
            content=content,
        )
        return out_file
    except Exception as e:
        log.warning("Failed to save worker output [%s/%s]: %s", mission_name, session, e)
        return None


def _mark_worker_bootstrapped(mission_name: str, session: str) -> None:
    """Persist bootstrapped=True so daemon restart doesn't re-suppress the next stop."""
    try:
        with mutate_mission(mission_name) as m:
            for p in m.get("participants", []):
                if p.get("role") == "worker" and p.get("session") == session:
                    p["bootstrapped"] = True
                    return
                return
    except Exception as e:
        log.warning("Failed to mark worker %s bootstrapped: %s", session, e)


def _read_stop_payload(sf: Path, mission_name: str, session: str) -> str:
    """Parse the stop-signal JSON; return last_assistant_message or empty string.

    Never raises — all failure modes produce an empty message and log a warning,
    since observability must not break the main event-relay flow.
    """
    try:
        stop_data = json.loads(sf.read_text())
    except (json.JSONDecodeError, OSError) as e:
        log.warning(
            "stop signal [%s/%s] unreadable (%s): %s — sup will see empty reply",
            mission_name, session, sf, e,
        )
        return ""
    last_msg = stop_data.get("last_assistant_message", "")
    if not last_msg:
        log.warning(
            "stop signal [%s/%s] has no last_assistant_message field; sup will see empty reply (path=%s)",
            mission_name, session, sf,
        )
    return last_msg


def _handle_stop(
    mission_name: str,
    mission: dict[str, Any],
    session: str,
    sf: Path,
    key: str,
) -> None:
    """Consume stop signal: persist reply, notify supervisor with throttle + first-stop suppression."""
    last_msg = _read_stop_payload(sf, mission_name, session)

    sf.unlink(missing_ok=True)
    runtime_state.last_stall.pop(key, None)
    runtime_state.stall_count.pop(key, None)
    runtime_state.stall_closed.discard(key)

    now = time.time()
    last = runtime_state.last_notify.get(key, 0)
    if now - last < MIN_NOTIFY_INTERVAL:
        log.info("Stop signal consumed, throttled (%.0fs since last notify)", now - last)
        runtime_state.save()
        return

    # Persist Worker→Supervisor reply to transcript before notifying.
    # append_transcript never raises — observability must not break the main
    # event-relay flow.
    append_transcript(
        mission_name,
        direction="worker_to_sup",
        worker=session,
        content=last_msg,
        kind="stop_reply",
    )

    if session not in runtime_state.first_stop_suppressed:
        runtime_state.first_stop_suppressed.add(session)
        runtime_state.last_notify[key] = now
        log.info("Initial stop suppressed [%s/%s]", mission_name, session)
        _mark_worker_bootstrapped(mission_name, session)
        runtime_state.save()
        return

    # Always persist full output to messages/ (100% write)
    saved_file = _save_worker_output(mission_name, session, last_msg)
    # output_file in notification only when reply exceeds inline limit
    inline_reply = last_msg
    notify_output_file: Path | None = None
    if len(last_msg) > REPLY_INLINE_LIMIT:
        notify_output_file = saved_file
        inline_reply = last_msg[:REPLY_INLINE_LIMIT] + "…"
    msg = format_stop_msg(mission_name, session, inline_reply, notify_output_file)
    notify_supervisor(mission, msg)
    runtime_state.last_notify[key] = now
    log.info("Stop signal consumed [%s/%s]", mission_name, session)
    runtime_state.save()


def _check_stall(
    mission_name: str,
    session: str,
    worker: dict[str, Any],
    key: str,
) -> dict[str, Any] | None:
    """Return stall info dict if JSONL mtime exceeds the (escalating) timeout; else None."""
    cache = worker.get("cache") or {}
    jsonl = cache.get("jsonl_path")
    if not jsonl:
        return None
    jsonl_path = Path(jsonl)
    if not jsonl_path.exists():
        return None

    mtime = jsonl_path.stat().st_mtime
    now = time.time()
    age = now - mtime
    last_stall = runtime_state.last_stall.get(key, 0)
    # 渐进式退避：1st=180s, 2nd=240s, 3rd+=300s
    count_so_far = runtime_state.stall_count.get(key, 0)
    effective_timeout = min(STALL_TIMEOUT + count_so_far * 60, 300)
    if age <= effective_timeout or now - last_stall <= effective_timeout:
        return None

    if key in runtime_state.stall_closed:
        runtime_state.last_stall[key] = now
        log.info(
            "JSONL stall suppressed (closed) [%s/%s] (%ds)",
            mission_name, session, int(age),
        )
        runtime_state.save()
        return None

    count = runtime_state.stall_count.get(key, 0) + 1
    runtime_state.stall_count[key] = count
    runtime_state.last_stall[key] = now
    if count >= STALL_MAX_COUNT:
        runtime_state.stall_closed.add(key)
    log.info(
        "JSONL stall detected [%s/%s] (%ds) count=%d/%d",
        mission_name, session, int(age), count, STALL_MAX_COUNT,
    )
    runtime_state.save()
    return {
        "session": session,
        "age": int(age),
        "stall_count": count,
    }


def check_worker(
    mission_name: str,
    mission: dict[str, Any],
    worker: dict[str, Any],
) -> dict[str, Any] | None:
    """对一个 worker 做 stop/stall 检测。

    Stop 事件：立即通知 supervisor，返回 None。
    Stall 事件：更新状态后返回 stall info dict，由调用方聚合发送。
    无事件：返回 None。
    """
    session = worker.get("session")
    if not session:
        return None

    session_id = worker_session_id(worker)
    if not session_id:
        return None

    key = f"{mission_name}:{session}"
    sf = stop_file(session_id)

    if sf.exists():
        _handle_stop(mission_name, mission, session, sf, key)
        return None

    return _check_stall(mission_name, session, worker, key)
