"""Internal daemon package.

`keep.daemon` is the public facade that re-exports everything from here.
Modules are split by responsibility (runtime_state, xml_format, notify,
review, worker_check, quiescent, loop). External callers should continue to
import from `keep.daemon`; this package is an implementation detail.
"""
