"""Daemon constants, signal-file paths, module logger.

Kept dependency-light so every other `_daemon.*` module can import from here
without risk of cycles.

STATE_DIR is captured once at import (mirrors the long-standing daemon.py
behaviour). Tests that want a custom STATE_DIR must patch
`keep._state.paths.STATE_DIR` *before* importing `keep.daemon` / this module.
"""

from __future__ import annotations

import logging
from pathlib import Path

from keep.state import STATE_DIR

# ── Filesystem layout ─────────────────────────────────────────────
STATE_DIR.mkdir(parents=True, exist_ok=True)
LOG_FILE = STATE_DIR / "daemon.log"
RUNTIME_STATE_FILE = STATE_DIR / "daemon-runtime.json"

# ── Logger ────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [daemon] %(message)s",
    handlers=[logging.FileHandler(LOG_FILE)],
)
log = logging.getLogger("keep.daemon")

# ── Review event types ────────────────────────────────────────────
EV_TASK_RATIONALE = "task_rationale"
EV_TASK_REVIEW = "task_review"
EV_MISSION_STOP = "mission_stop"
EV_MISSION_QUIESCENT = "mission_quiescent"

# ── Timing / policy constants ─────────────────────────────────────
POLL_INTERVAL = 2
MIN_NOTIFY_INTERVAL = 10   # 最小通知间隔，防刷屏
STALL_TIMEOUT = 180        # JSONL 无写入多久后视为 stall（秒）
STALL_MAX_COUNT = 10       # 连续 stall 事件最多发送次数
STALL_SUSPEND_HINT_AT = 2  # 第几次 stall 时附上 worker remove/restore 提示
REPLY_INLINE_LIMIT = 200   # stop reply 超过此长度则截断，完整内容溢写到文件
QUIESCENT_TIMEOUT = 300    # 所有 worker 空闲超过此时间（秒）视为 quiescent
SUPERVISOR_QUIESCENT_DELAY = 10  # supervisor 停止后等待多久再触发 quiescent


# ── Signal file path helpers ──────────────────────────────────────
def mission_stop_signal_file(mission_name: str) -> Path:
    return STATE_DIR / f"mission-stop-{mission_name}"


def mission_sync_signal_file(mission_name: str) -> Path:
    return STATE_DIR / f"mission-sync-{mission_name}"


def stop_file(session_id: str) -> Path:
    return STATE_DIR / f"stop-{session_id}"
