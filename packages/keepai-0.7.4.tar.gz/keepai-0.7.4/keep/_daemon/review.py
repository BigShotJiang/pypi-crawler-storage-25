"""Review event lifecycle: dispatch, verdict aggregation, signal-file checks.

Per-type verdict actions (marking tasks, stopping missions, etc.) live in
`verdict_handlers.py` to keep this module focused on the lifecycle edges.
Called by the daemon main loop once per mission tick. Any mutation to mission
status goes through `mutate_mission` so atomic writes + per-mission locks are
respected.
"""

from __future__ import annotations

from typing import Any

from keep._daemon import runtime_state, verdict_handlers
from keep._daemon.constants import (
    EV_MISSION_STOP,
    EV_TASK_REVIEW,
    log,
    mission_stop_signal_file,
    mission_sync_signal_file,
)
from keep._daemon.notify import notify_all_reviewers, sync_mission_to_reviewers
from keep._daemon.xml_format import (
    build_review_summary,
    format_review_request_msg,
)
from keep.state import (
    add_review_event,
    get_review_event,
    iter_reviewers,
    list_tasks,
    load_mission,
    mutate_mission,
    update_review_event,
    update_task,
)


# ── Dispatch ──────────────────────────────────────────────────────
def dispatch_review_event(
    mission_name: str,
    mission: dict[str, Any],
    event_id: str,
    event_type: str,
    summary: str,
) -> None:
    """发送 review 请求给所有 reviewers，标记为已 dispatch。"""
    dispatch_key = f"{mission_name}:{event_id}"
    if dispatch_key in runtime_state.review_dispatched:
        return
    msg = format_review_request_msg(mission_name, event_id, event_type, summary)
    notify_all_reviewers(mission, msg)
    runtime_state.review_dispatched.add(dispatch_key)
    log.info("Review event %s dispatched to reviewers [%s]", event_id, mission_name)
    runtime_state.save()


# ── Verdict aggregation ───────────────────────────────────────────
def aggregate_reviewer_verdict(
    mission_name: str,
    event: dict[str, Any],
) -> str | None:
    """聚合所有 reviewer 的判决。

    返回 "approved"、"rejected" 或 None（尚有 reviewer 未提交判决）。

    规则：
    - 全部 reviewer 均提交了判决 → 聚合
    - 聚合：全部 pass → "approved"；任一 reject → "rejected"
    - 若无 reviewer 配置，直接返回 "approved"（fallthrough）
    """
    try:
        reviewers = list(iter_reviewers(mission_name))
    except Exception as e:
        log.warning("Failed to iter reviewers for aggregation [%s]: %s", mission_name, e)
        return None

    if not reviewers:
        return "approved"

    verdicts: dict[str, str] = event.get("reviewer_verdicts", {})
    reviewer_ids = [r["id"] for r in reviewers if "id" in r]

    for rid in reviewer_ids:
        if rid not in verdicts:
            return None  # Still waiting

    if any(v == "reject" for v in verdicts.values()):
        return "rejected"
    return "approved"


def handle_review_verdict(
    mission_name: str,
    mission: dict[str, Any],
    event_id: str,
    verdict: str,
) -> None:
    """处理聚合后的判决（approved 或 rejected）：settle 事件 + dispatch 到对应 handler。"""
    try:
        event = get_review_event(mission_name, event_id)
    except Exception as e:
        log.warning("Cannot load review event %s [%s]: %s", event_id, mission_name, e)
        return

    event_type = event.get("type")
    if not event_type:
        log.error(
            "Review event %s [%s] missing 'type' field — cannot dispatch verdict %r; event=%r",
            event_id, mission_name, verdict, event,
        )
        return
    log.info(
        "Review verdict: %s for event %s (type=%s) [%s]",
        verdict, event_id, event_type, mission_name,
    )

    # Mark event as settled
    try:
        update_review_event(mission_name, event_id, final_verdict=verdict)
    except Exception as e:
        log.warning("Failed to update review event %s: %s", event_id, e)
    runtime_state.review_dispatched.discard(f"{mission_name}:{event_id}")

    # Reload mission so subsequent save_mission calls don't overwrite final_verdict
    reloaded = load_mission(mission_name)
    if reloaded is not None:
        mission.update(reloaded)

    verdict_handlers.dispatch(mission_name, mission, event_id, event, event_type, verdict)


# ── Pending / signal checks (called by main loop) ─────────────────
def check_pending_review_verdicts(mission_name: str, mission: dict[str, Any]) -> None:
    """检查所有未结案的 review events：派发未 dispatch 的事件，聚合已有判决。"""
    try:
        review_events = mission.get("review_events", [])
    except Exception:
        return

    for event in list(review_events):  # snapshot; mission mutates mid-loop
        event_id = event.get("id")
        if not event_id:
            continue
        # Reload from disk to pick up verdicts submitted since last tick
        fresh_event = get_review_event(mission_name, event_id)
        if fresh_event is None:
            continue
        if fresh_event.get("final_verdict"):
            continue
        # Dispatch to reviewers if not yet sent (handles events created by CLI)
        dispatch_key = f"{mission_name}:{event_id}"
        if dispatch_key not in runtime_state.review_dispatched:
            event_type = fresh_event.get("type")
            if not event_type:
                log.error(
                    "Review event %s [%s] missing 'type' field — skipping dispatch; event=%r",
                    event_id, mission_name, fresh_event,
                )
                continue
            summary = build_review_summary(fresh_event, mission_name)
            dispatch_review_event(mission_name, mission, event_id, event_type, summary)
        verdict = aggregate_reviewer_verdict(mission_name, fresh_event)
        if verdict is not None:
            handle_review_verdict(mission_name, mission, event_id, verdict)
            updated = load_mission(mission_name)
            if updated is not None:
                mission.update(updated)


def check_task_review_events(
    mission_name: str,
    mission: dict[str, Any],
    tasks: list[dict[str, Any]] | None = None,
) -> None:
    """检测 awaiting_review tasks，为同一批次创建 review event 并路由给 reviewers。"""
    if tasks is None:
        try:
            tasks = list_tasks(mission_name)
        except Exception as e:
            log.warning("Failed to list tasks for review check [%s]: %s", mission_name, e)
            return

    awaiting = [
        t for t in tasks
        if t.get("status") == "awaiting_review" and not t.get("review_event_id")
    ]
    if not awaiting:
        return

    task_ids = [str(t["id"]) for t in awaiting]
    subjects = [f"#{t['id']} {t.get('subject', '')}" for t in awaiting]
    rationale = awaiting[0].get("review_rationale", "") if awaiting else ""
    try:
        event_data: dict[str, Any] = {
            "type": EV_TASK_REVIEW,
            "task_ids": task_ids,
            "task_subjects": subjects,
            "reviewer_verdicts": {},
        }
        if rationale:
            event_data["rationale"] = rationale
        event_id = add_review_event(mission_name, event_data)
        for t in awaiting:
            try:
                update_task(mission_name, str(t["id"]), {"review_event_id": event_id})
            except Exception as e:
                log.warning(
                    "Failed to link task %s to review event %s: %s",
                    t["id"], event_id, e,
                )
        log.info(
            "Created task_review event %s for %d tasks [%s]",
            event_id, len(awaiting), mission_name,
        )
    except Exception as e:
        log.warning("Failed to create task_review event for mission %r: %s", mission_name, e)
        return

    summary = (
        f"{len(awaiting)} tasks awaiting review:\n"
        + "\n".join(subjects)
        + f"\nSubmit verdict: keep {mission_name} reviewer {event_id} pass|reject <file>"
    )
    dispatch_review_event(mission_name, mission, event_id, EV_TASK_REVIEW, summary)


def check_mission_sync_signal(mission_name: str, mission: dict[str, Any]) -> None:
    """检测 mission sync 信号文件，有则推送最新 mission 内容给所有 reviewers。"""
    sf = mission_sync_signal_file(mission_name)
    if not sf.exists():
        return
    sf.unlink(missing_ok=True)
    log.info("Mission sync signal detected, syncing to reviewers [%s]", mission_name)
    sync_mission_to_reviewers(mission_name, mission)


def check_mission_stop_signal(mission_name: str, mission: dict[str, Any]) -> bool:
    """检测 mission stop 信号文件，如有 reviewers 则创建 review event，否则直接 stop。

    返回 True 表示 mission 被停止（无论直接还是通过 review），调用方应 continue。
    """
    sf = mission_stop_signal_file(mission_name)
    if not sf.exists():
        return False

    try:
        reviewers = list(iter_reviewers(mission_name))
    except Exception:
        reviewers = []

    if not reviewers:
        sf.unlink(missing_ok=True)
        with mutate_mission(mission_name) as fresh:
            fresh["status"] = "stopped"
        mission["status"] = "stopped"
        log.info("mission_stop: no reviewers, stopping immediately [%s]", mission_name)
        return True

    # Already has a pending stop event — consume signal file to prevent re-dispatch on restart
    if mission_name in runtime_state.pending_stop_event:
        sf.unlink(missing_ok=True)
        return False

    rationale_path = sf.read_text(encoding="utf-8").strip()
    sf.unlink(missing_ok=True)
    try:
        event_data: dict[str, Any] = {
            "type": EV_MISSION_STOP,
            "reviewer_verdicts": {},
        }
        if rationale_path:
            event_data["rationale"] = rationale_path
        event_id = add_review_event(mission_name, event_data)
        runtime_state.pending_stop_event[mission_name] = event_id
        runtime_state.save()
        log.info("Created mission_stop review event %s [%s]", event_id, mission_name)
    except Exception as e:
        log.warning("Failed to create mission_stop event for %r: %s", mission_name, e)
        return False

    summary = build_review_summary(event_data | {"id": event_id}, mission_name)
    dispatch_review_event(mission_name, mission, event_id, EV_MISSION_STOP, summary)
    return False
