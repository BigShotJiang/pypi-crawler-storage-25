"""Outbound notifications to supervisor / reviewers.

All `send_text` calls are wrapped in `send_to_surface`: best-effort, exceptions
logged with traceback, never raised to the daemon main loop.

The `get_terminal` function is imported at module level so
`monkeypatch.setattr("keep.daemon.get_terminal", fake)` via the facade keeps
working (conftest relies on this import path).
"""

from __future__ import annotations

from typing import Any
from xml.sax.saxutils import escape as xml_escape

from keep import terminal as _terminal
from keep._daemon.constants import log
from keep._daemon.xml_format import build_event_xml
from keep.state import (
    find_supervisor,
    iter_reviewers,
    list_tasks,
    mission_terminal_type,
)


def send_to_surface(terminal_type: str, target_id: str, message: str) -> bool:
    """Best-effort send. Returns True on success, False on failure (logged with traceback)."""
    try:
        _terminal.get_terminal(terminal_type).send_text(target_id, message)
        return True
    except Exception:
        log.exception(
            "send to terminal=%s target=%s failed (msg head=%r)",
            terminal_type, target_id, message[:80],
        )
        return False


def notify_supervisor(mission: dict[str, Any], message: str) -> None:
    """通知 mission 的 supervisor。claim 缺失或 target_id 未缓存则丢事件。"""
    mission_name = mission.get("name", "?")
    sup = find_supervisor(mission)
    if not sup:
        # 主循环理应过滤 unclaimed mission，到这就是 invariant 破了。warning 而不是 debug。
        log.warning(
            "notify_supervisor called on mission %r with no supervisor — invariant violation, dropping: %s",
            mission_name, message[:80],
        )
        return
    terminal_type = mission_terminal_type(mission)
    target_id = (sup.get("cache") or {}).get("target_id")
    if not target_id:
        log.warning(
            "Supervisor for mission %r has no target_id in cache, dropping event",
            mission_name,
        )
        return
    # 替换换行符，避免 Escape 打断 Supervisor 正在运行的 generation
    safe_message = message.replace("\n", " ")
    log.info(
        "→ Supervisor[%s] %s: %s",
        mission_name, target_id[:8], safe_message[:120],
    )
    send_to_surface(terminal_type, target_id, safe_message)


def notify_reviewer(mission: dict[str, Any], reviewer: dict[str, Any], message: str) -> None:
    """通知单个 reviewer。reviewer 必须有 cache.target_id。"""
    mission_name = mission.get("name", "?")
    reviewer_id = reviewer.get("id", "?")
    terminal_type = mission_terminal_type(mission)
    target_id = (reviewer.get("cache") or {}).get("target_id")
    if not target_id:
        log.warning(
            "Reviewer %s/%s has no target_id in cache, dropping message",
            mission_name, reviewer_id,
        )
        return
    safe_message = message.replace("\n", " ")
    log.info(
        "→ Reviewer[%s/%s] %s: %s",
        mission_name, reviewer_id, target_id[:8], safe_message[:120],
    )
    send_to_surface(terminal_type, target_id, safe_message)


def notify_all_reviewers(mission: dict[str, Any], message: str) -> None:
    """通知 mission 的所有 reviewers。session 不可达的 reviewer 静默跳过。"""
    mission_name = mission.get("name", "?")
    try:
        reviewers = list(iter_reviewers(mission_name))
    except Exception as e:
        log.warning("Failed to iter reviewers for mission %r: %s", mission_name, e)
        return
    if not reviewers:
        log.debug("No reviewers for mission %r", mission_name)
        return
    for reviewer in reviewers:
        try:
            notify_reviewer(mission, reviewer, message)
        except Exception as e:
            log.warning("Failed to notify reviewer %s: %s", reviewer.get("id"), e)


def sync_mission_to_reviewers(mission_name: str, mission: dict[str, Any]) -> None:
    """推送最新 mission 内容（prompt + tasks 摘要）给所有 reviewers。纯信息同步，无判决。"""
    try:
        reviewers = list(iter_reviewers(mission_name))
    except Exception as e:
        log.warning("Failed to iter reviewers for mission %r: %s", mission_name, e)
        return
    if not reviewers:
        return

    prompt = mission.get("mission_prompt") or "(未设置)"
    tasks = list_tasks(mission_name)
    if tasks:
        lines = [f"#{t['id']} [{t['status']}] {t['subject']}" for t in tasks]
        tasks_summary = "\n".join(lines)
    else:
        tasks_summary = "(无 task)"

    body = xml_escape(
        f"Mission {mission_name} 信息同步:\n"
        f"Prompt: {prompt}\n"
        f"Tasks:\n{tasks_summary}"
    )
    msg = build_event_xml(
        "mission_sync",
        {"mission": mission_name},
        body,
    )
    for reviewer in reviewers:
        try:
            notify_reviewer(mission, reviewer, msg)
        except Exception as e:
            log.warning("Failed to sync mission to reviewer %s: %s", reviewer.get("id"), e)
