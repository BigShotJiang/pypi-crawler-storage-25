"""Kitty terminal backend for keep.

Requires in ~/.config/kitty/kitty.conf:
    allow_remote_control yes
    listen_on unix:/tmp/kitty.sock   # or any path; set KITTY_LISTEN_ON env var

The socket path is read from KITTY_LISTEN_ON environment variable of the
running Claude Code process (same pattern as CMUX_SURFACE_ID for cmux).

Mission-container model
-----------------------
A mission = one kitty **OS window**, identified by its OS-window id. We
persist that id as the container ref (a string). Live lookup is via
``kitty @ ls --all`` which returns JSON keyed by ``os_window_id``.

Layout inside the OS window (tab-per-role):

  * supervisor+0 = first tab, titled ``supervisor``.
  * reviewer+0   = new tab in same OS window, titled ``reviewer``.
  * worker+0     = new tab titled ``worker-1``.
  * worker+N>=1  = horizontal split within the ``worker-1`` tab
    (``--type=window --location=hsplit --match title:worker-1``).

target_id = kitty window id (string), same as before.

Falls back to ``close-tab --match title:<T>`` for every tab whose title
starts with a known role when closing the container (kitty has no direct
``close-os-window`` subcommand at least through the current release).
"""
from __future__ import annotations
import json
import os
import subprocess
import time


def _os_window_title(mission_id: str) -> str:
    return f"keep-{mission_id}"


class KittyTerminal:
    def __init__(self, socket_path: str | None = None):
        self._socket = socket_path or os.environ.get("KITTY_LISTEN_ON", "")
        if not self._socket:
            raise RuntimeError(
                "Kitty socket not configured. Set KITTY_LISTEN_ON env var or "
                "add 'listen_on unix:/tmp/kitty.sock' to ~/.config/kitty/kitty.conf "
                "and 'allow_remote_control yes'."
            )

    def _run(self, *args: str) -> str:
        cmd = ["kitty", "@", "--to", self._socket, *args]
        return subprocess.check_output(cmd, text=True).strip()

    def _run_silent(self, *args: str) -> None:
        cmd = ["kitty", "@", "--to", self._socket, *args]
        subprocess.run(cmd, capture_output=True)

    def _ls(self) -> list[dict]:
        """Return the parsed `kitty @ ls` JSON — list of OS windows."""
        raw = self._run("ls")
        return json.loads(raw)

    def _find_os_window(self, ref: str) -> dict | None:
        """Look up an OS window by id string. Returns the dict or None."""
        try:
            target = int(ref)
        except ValueError:
            return None
        for osw in self._ls():
            if osw.get("id") == target:
                return osw
        return None

    def ensure_mission_container(self, mission_id: str) -> str:
        """Create (or return) the OS window for this mission. Returns its id as str."""
        title = _os_window_title(mission_id)
        for osw in self._ls():
            # Match by any tab whose title is our mission title (we title the
            # first tab "supervisor" but set the OS window title too via launch).
            first_tab = (osw.get("tabs") or [{}])[0]
            if first_tab.get("title") == title:
                return str(osw["id"])

        # Create a new OS window. Launch a login shell so the first tab has a
        # process; the title flag sets the OS-window and tab titles.
        out = self._run(
            "launch", "--type=os-window",
            "--os-window-title", title,
            "--tab-title", title,
        )
        # `launch` prints the new window id (numeric).
        kitty_window_id = out.strip()
        if not kitty_window_id:
            raise RuntimeError("kitty @ launch returned empty window id")

        # Give kitty a beat to register the new OS window before we query it.
        time.sleep(0.2)
        for osw in self._ls():
            # Find the OS window whose first tab has our title.
            tabs = osw.get("tabs") or []
            if tabs and tabs[0].get("title") == title:
                return str(osw["id"])
        raise RuntimeError(
            f"kitty: created OS window with title {title!r} but could not "
            f"locate it in `kitty @ ls` output"
        )

    def spawn_in_container(
        self,
        container_ref: str,
        role: str,
        role_index: int,
        cwd: str,
        cmd: str,
    ) -> str:
        """Launch a participant inside the mission's OS window. Returns window id."""
        osw = self._find_os_window(container_ref)
        if osw is None:
            raise RuntimeError(
                f"kitty: mission OS window not found: {container_ref!r}"
            )
        # All launch commands need to target this specific OS window. There is
        # no explicit --os-window flag, so we pin them via --match on a
        # tab we control. For the first supervisor spawn the OS window already
        # exists with a default tab titled after the mission — we rename that
        # tab to "supervisor" so later launches can --match title:supervisor.
        sup_tab_title = "supervisor"

        if role == "supervisor" and role_index == 0:
            # Rename the default tab to "supervisor" and run cmd inside its
            # current window via launch --type=window --self (no new window).
            first_tab = (osw.get("tabs") or [{}])[0]
            tab_id = first_tab.get("id")
            if tab_id is None:
                raise RuntimeError("kitty: OS window has no tabs")
            self._run_silent(
                "set-tab-title", "--match", f"id:{tab_id}", sup_tab_title,
            )
            # Launch a new window inside this tab running cmd, reusing it as
            # the supervisor surface. `--match id:<tid>` pins to the tab.
            win_id = self._run(
                "launch", "--type=window",
                "--match", f"id:{tab_id}",
                "--cwd", cwd,
                "--", "bash", "-c", cmd,
            )
            return win_id.strip()

        if role == "reviewer" and role_index == 0:
            win_id = self._run(
                "launch", "--type=tab",
                "--tab-title", "reviewer",
                "--match", f"title:{sup_tab_title}",
                "--cwd", cwd,
                "--", "bash", "-c", cmd,
            )
            return win_id.strip()

        if role == "worker" and role_index == 0:
            win_id = self._run(
                "launch", "--type=tab",
                "--tab-title", "worker-1",
                "--match", f"title:{sup_tab_title}",
                "--cwd", cwd,
                "--", "bash", "-c", cmd,
            )
            return win_id.strip()

        if role == "worker" and role_index >= 1:
            # Extra workers split inside the worker-1 tab (horizontal split).
            win_id = self._run(
                "launch", "--type=window",
                "--location=hsplit",
                "--match", "title:worker-1",
                "--cwd", cwd,
                "--", "bash", "-c", cmd,
            )
            return win_id.strip()

        raise ValueError(f"kitty: unsupported role/index combo: {role!r}+{role_index}")

    def close_mission_container(self, container_ref: str) -> None:
        """Close every tab in the mission OS window; when empty, kitty drops the OS window."""
        osw = self._find_os_window(container_ref)
        if osw is None:
            return
        for tab in osw.get("tabs") or []:
            tab_id = tab.get("id")
            if tab_id is None:
                continue
            # close-tab takes a --match tab selector.
            self._run_silent("close-tab", "--match", f"id:{tab_id}")

    def send_text(self, target_id: str, text: str) -> None:
        """Send body then CR to Kitty window as two separate calls.

        CRITICAL: do NOT collapse into one `send-text ... text + "\\r"`,
        and do NOT shorten the sleep. See keep/terminals/iterm2.py
        send_text() for the full root-cause writeup. Summary:

          Claude Code's TUI enables bracketed paste mode. When a terminal
          wraps a payload in "\\e[200~ ... \\e[201~" (either because the
          terminal auto-bracketed a paste-sized write, or because a future
          kitty version starts doing it), ANY "\\r" inside that envelope
          is interpreted as a multi-line newline, NOT submit — the
          message stays stuck in the input buffer.

          Splitting the body and CR into two `send-text` calls with a
          ~2s gap in between ensures the CR lands OUTSIDE any paste
          envelope, so the TUI treats it as Enter.

          Kitty's `send-text` today does not bracket by default, but
          aligning all backends on this pattern removes a whole class of
          future regressions and matches cmux/iterm2.
        """
        self._run_silent(
            "send-text", "--match", f"id:{target_id}", text
        )
        time.sleep(2)
        self._run_silent(
            "send-text", "--match", f"id:{target_id}", "\r"
        )

    def send_key(self, target_id: str, key: str) -> None:
        """Send a named key. Raises ValueError for unsupported keys."""
        key_map = {"escape": "\x1b", "enter": "\r", "ctrl-c": "\x03"}
        if key not in key_map:
            raise ValueError(f"Kitty: unsupported key {key!r}; valid: {sorted(key_map)}")
        self._run_silent(
            "send-text", "--match", f"id:{target_id}", key_map[key]
        )

    def read_screen(self, target_id: str) -> str:
        return self._run(
            "get-text", "--match", f"id:{target_id}", "--extent", "screen"
        )

    def close(self, target_id: str) -> None:
        self._run_silent("close-window", "--match", f"id:{target_id}")

    def resolve_target_id(self, pid: int) -> str | None:
        # Kitty window id is assigned at spawn and stored in cache; no runtime discovery.
        return None
