"""Unit tests for the Terminal.app backend's mission-container API.

Every AppleScript call is intercepted by stubbing subprocess.run /
check_output. Quartz, pyobjc and the keystroke path are not exercised here.
"""
from __future__ import annotations

import subprocess

import pytest

from keep.terminals import terminal_app as ta_mod
from keep.terminals.terminal_app import TerminalAppTerminal


class _Calls:
    def __init__(self):
        self.run: list[list[str]] = []
        self.check_output: list[list[str]] = []
        self.check_output_returns: list[str] = []


@pytest.fixture
def calls(monkeypatch):
    c = _Calls()

    def fake_run(argv, *args, **kwargs):
        c.run.append(list(argv))
        return subprocess.CompletedProcess(argv, 0, stdout=b"", stderr=b"")

    def fake_check_output(argv, *args, **kwargs):
        c.check_output.append(list(argv))
        if c.check_output_returns:
            return c.check_output_returns.pop(0)
        return ""

    monkeypatch.setattr(ta_mod.subprocess, "run", fake_run)
    monkeypatch.setattr(ta_mod.subprocess, "check_output", fake_check_output)
    monkeypatch.setattr(ta_mod.time, "sleep", lambda *a, **k: None)
    return c


# ---------------------------------------------------------------------------
# ensure_mission_container
# ---------------------------------------------------------------------------


def test_ensure_creates_new_window_when_none_match(calls):
    # First osascript call is the window-lookup → empty; second is the creator.
    calls.check_output_returns = ["", "12345"]
    term = TerminalAppTerminal()

    ref = term.ensure_mission_container("mx")

    assert ref == "12345"
    # Two osascript invocations: lookup, then create.
    osas = [c for c in calls.check_output if c and c[0] == "osascript"]
    assert len(osas) == 2, calls.check_output


def test_ensure_returns_existing_window(calls):
    calls.check_output_returns = ["54321"]
    term = TerminalAppTerminal()

    ref = term.ensure_mission_container("mx")
    assert ref == "54321"
    # Should have made the lookup call only (no create).
    assert len(calls.check_output) == 1, calls.check_output


# ---------------------------------------------------------------------------
# spawn_in_container
# ---------------------------------------------------------------------------


def test_spawn_supervisor_reuses_first_tab(calls):
    calls.check_output_returns = ["12345"]
    term = TerminalAppTerminal()

    out = term.spawn_in_container("12345", "supervisor", 0, "/tmp", "claude")
    assert out == "12345"
    # AppleScript mentions supervisor title and do script.
    script = " ".join(calls.check_output[-1])
    assert "supervisor" in script
    assert "do script" in script


def test_spawn_reviewer_opens_new_tab(calls):
    calls.check_output_returns = ["12345"]
    term = TerminalAppTerminal()

    term.spawn_in_container("12345", "reviewer", 0, "/tmp", "claude")
    script = " ".join(calls.check_output[-1])
    # Opens a new tab: keystroke "t" using command down is the tell
    assert "keystroke \"t\"" in script
    assert "reviewer" in script


def test_spawn_worker_n_opens_tab_with_indexed_title(calls):
    calls.check_output_returns = ["12345"]
    term = TerminalAppTerminal()

    term.spawn_in_container("12345", "worker", 2, "/tmp", "claude")
    script = " ".join(calls.check_output[-1])
    assert "worker-3" in script


# ---------------------------------------------------------------------------
# close_mission_container
# ---------------------------------------------------------------------------


def test_close_mission_container_closes_window(calls):
    term = TerminalAppTerminal()
    term.close_mission_container("12345")

    # osascript ran with a close-window script.
    calls_run = [c for c in calls.run if c and c[0] == "osascript"]
    assert calls_run, calls.run
    joined = " ".join(calls_run[-1])
    assert "close" in joined and "12345" in joined
