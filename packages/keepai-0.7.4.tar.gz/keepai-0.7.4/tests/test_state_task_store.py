from pathlib import Path

import pytest

from keep import state


@pytest.fixture
def isolated_state(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    state_dir = tmp_path / "state"
    missions_dir = state_dir / "missions"
    tasks_root = state_dir / "keep_id" / "tasks"
    missions_dir.mkdir(parents=True)
    tasks_root.mkdir(parents=True)
    monkeypatch.setattr(state, "STATE_DIR", state_dir)
    monkeypatch.setattr(state, "MISSIONS_DIR", missions_dir)
    return state_dir


def test_task_store_dir_is_per_mission(isolated_state: Path) -> None:
    task_dir = state.task_store_dir("mission-1")
    assert task_dir == isolated_state / "keep_id" / "tasks" / "mission-1"


def test_create_task_initializes_lock_highwatermark_and_first_task(isolated_state: Path) -> None:
    task = state.create_task("mission-1", subject="first task")
    task_dir = state.task_store_dir("mission-1")

    assert task["id"] == "1"
    assert task["subject"] == "first task"
    assert task["description"] == ""
    assert task["status"] == "draft"
    assert task["owner"] == ""
    assert task["blocks"] == []
    assert task["blockedBy"] == []
    assert (task_dir / ".lock").exists()
    assert (task_dir / ".highwatermark").read_text(encoding="utf-8").strip() == "1"
    assert (task_dir / "1.json").exists()


def test_create_task_increments_highwatermark(isolated_state: Path) -> None:
    first = state.create_task("mission-1", subject="one")
    second = state.create_task("mission-1", subject="two")

    assert first["id"] == "1"
    assert second["id"] == "2"
    assert state.highwatermark_file("mission-1").read_text(encoding="utf-8").strip() == "2"


def test_list_tasks_returns_id_order(isolated_state: Path) -> None:
    state.create_task("mission-1", subject="one")
    state.create_task("mission-1", subject="two")
    tasks = state.list_tasks("mission-1")
    assert [task["id"] for task in tasks] == ["1", "2"]


def test_update_task_supports_task_fields_only(isolated_state: Path) -> None:
    state.create_task("mission-1", subject="one")
    updated = state.update_task(
        "mission-1",
        "1",
        {
            "description": "desc",
            "status": "in_progress",
            "owner": "supervisor-1",
            "blocks": ["2"],
            "blockedBy": ["3"],
        },
    )
    assert updated["description"] == "desc"
    assert updated["status"] == "in_progress"
    assert updated["owner"] == "supervisor-1"
    assert updated["blocks"] == ["2"]
    assert updated["blockedBy"] == ["3"]


def test_remove_task_deletes_task_file(isolated_state: Path) -> None:
    state.create_task("mission-1", subject="one")
    assert state.remove_task("mission-1", "1") is True
    assert not (state.task_store_dir("mission-1") / "1.json").exists()


def test_mission_state_no_longer_embeds_plans() -> None:
    mission = state.new_mission("mission-1")
    assert "plans" not in mission
    assert "next_plan_id" not in mission
