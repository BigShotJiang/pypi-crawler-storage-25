"""Regression tests for concurrent mission-state mutators.

Participant CRUD (`add_supervisor` / `add_worker` / `remove_*`) used to take a
`mission: dict` argument and mutate it in-memory; callers then did their own
`load_mission` + `save_mission`. That pattern races with any other process
holding a file lock via `mutate_mission(mission_id)` (reviewers, daemon):

    T1 (participant add): load → mutate in-mem                         → save
    T2 (reviewer add):                          lock → load → mutate → save
                                                                          ^
                                                           T1's save now overwrites

These tests stress the fix: every mutator takes `mission_id` and serialises
through `mutate_mission`. A barrier releases N threads simultaneously so
they really contend on the lock; the final state must show *every* add.
"""

from __future__ import annotations

import threading
import uuid
from pathlib import Path

import pytest

from keep import state


@pytest.fixture
def isolated_state(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    state_dir = tmp_path / "state"
    missions_dir = state_dir / "missions"
    missions_dir.mkdir(parents=True)
    monkeypatch.setattr(state, "STATE_DIR", state_dir)
    monkeypatch.setattr(state, "GLOBAL_FILE", state_dir / "global.json")
    monkeypatch.setattr(state, "MISSIONS_DIR", missions_dir)
    state.save_global(state.new_global())
    return state_dir


def _run_concurrently(fns: list) -> list[BaseException | None]:
    """Release all `fns` together through a barrier; collect any exception."""
    barrier = threading.Barrier(len(fns))
    errors: list[BaseException | None] = [None] * len(fns)

    def wrapped(idx: int, fn):
        try:
            barrier.wait(timeout=5)
            fn()
        except BaseException as exc:  # noqa: BLE001 — capture for assertion
            errors[idx] = exc

    threads = [threading.Thread(target=wrapped, args=(i, fn)) for i, fn in enumerate(fns)]
    for t in threads:
        t.start()
    for t in threads:
        t.join(timeout=10)
        assert not t.is_alive(), "race test deadlocked — mutators not releasing lock"
    return errors


def test_concurrent_add_supervisor_and_reviewer_both_visible(isolated_state: Path) -> None:
    """Supervisor add (participants.py) and reviewer add (reviewers.py) must not clobber each other.

    Historical bug: `add_supervisor(mission, ...)` mutated `mission` in memory
    and the caller called `save_mission`, bypassing `mutate_mission`'s lock
    while `add_reviewer(mission_id, ...)` held it and produced a stale-read
    write on unlock.
    """
    for i in range(10):
        mission_id = f"mission-r{i}"
        state.create_mission(mission_id)

        sup_session = str(uuid.uuid4())
        reviewer_payload = {
            "name": "rev-a",
            "path": "/tmp/rev",
            "status": "active",
            "session": str(uuid.uuid4()),
        }

        errors = _run_concurrently([
            lambda mid=mission_id, s=sup_session: state.add_supervisor(mid, s),
            lambda mid=mission_id, d=reviewer_payload: state.add_reviewer(mid, d),
        ])
        assert all(e is None for e in errors), f"concurrent ops errored: {errors!r}"

        mission = state.load_mission(mission_id)
        assert mission is not None
        sup = state.find_supervisor(mission)
        assert sup is not None and sup["session"] == sup_session, (
            f"iter={i}: supervisor lost; participants={mission.get('participants')}"
        )
        reviewers = list(state.iter_reviewers(mission_id))
        assert len(reviewers) == 1, (
            f"iter={i}: reviewer lost; reviewers={reviewers!r}"
        )


def test_concurrent_add_workers_all_visible(isolated_state: Path) -> None:
    """N parallel add_worker calls on the same mission must all land."""
    for i in range(10):
        mission_id = f"mission-w{i}"
        state.create_mission(mission_id)

        sessions = [str(uuid.uuid4()) for _ in range(5)]
        errors = _run_concurrently([
            lambda mid=mission_id, s=sess: state.add_worker(mid, s, cache={"target_id": f"t-{s[:4]}"})
            for sess in sessions
        ])
        assert all(e is None for e in errors), f"iter={i} errors: {errors!r}"

        mission = state.load_mission(mission_id)
        assert mission is not None
        workers = state.iter_workers(mission)
        got = {w["session"] for w in workers}
        assert got == set(sessions), (
            f"iter={i}: workers lost; got={got!r}, want={set(sessions)!r}"
        )


def test_concurrent_mixed_participants_and_reviewers(isolated_state: Path) -> None:
    """Mix supervisor + workers + reviewers all contending on one mission's lock.

    This is the full shape of the race hit in production: supervisor create,
    worker create, reviewer create all kicked off roughly together.
    """
    for i in range(5):
        mission_id = f"mission-mix{i}"
        state.create_mission(mission_id)

        sup_session = str(uuid.uuid4())
        worker_sessions = [str(uuid.uuid4()) for _ in range(3)]
        reviewer_payloads = [
            {"name": f"rev-{j}", "path": "/tmp/r", "status": "active", "session": str(uuid.uuid4())}
            for j in range(2)
        ]

        fns = (
            [lambda mid=mission_id, s=sup_session: state.add_supervisor(mid, s)]
            + [lambda mid=mission_id, s=sess: state.add_worker(mid, s) for sess in worker_sessions]
            + [lambda mid=mission_id, d=pl: state.add_reviewer(mid, d) for pl in reviewer_payloads]
        )
        errors = _run_concurrently(fns)
        assert all(e is None for e in errors), f"iter={i} errors: {errors!r}"

        mission = state.load_mission(mission_id)
        assert mission is not None
        sup = state.find_supervisor(mission)
        assert sup is not None and sup["session"] == sup_session, f"iter={i}: sup lost"
        got_workers = {w["session"] for w in state.iter_workers(mission)}
        assert got_workers == set(worker_sessions), (
            f"iter={i}: workers lost; got={got_workers!r}, want={set(worker_sessions)!r}"
        )
        got_reviewers = list(state.iter_reviewers(mission_id))
        assert len(got_reviewers) == len(reviewer_payloads), (
            f"iter={i}: reviewers lost; got={got_reviewers!r}"
        )


def _unlocked_add_supervisor(mission_id: str, session: str) -> None:
    """The pre-fix pattern, open-coded: load → mutate in-memory → save, **no lock**.

    Used by `test_race_actually_happens_without_lock` to confirm our concurrent
    harness really contends (otherwise the fix-validated tests would be vacuous
    — they'd pass even if the lock did nothing, because threads happened not
    to interleave).
    """
    mission = state.load_mission(mission_id)
    if mission is None:
        raise ValueError(f"Mission {mission_id!r} 不存在")
    mission.setdefault("participants", []).append(
        {"session": session, "role": "supervisor", "name": "", "path": "", "contract": None, "cache": None}
    )
    # Simulate realistic think/spawn delay between load and save so the race window
    # is wide. Without this the threads serialise accidentally on fast filesystems.
    import time
    time.sleep(0.01)
    state.save_mission(mission_id, mission)


def _unlocked_add_reviewer(mission_id: str, payload: dict) -> None:
    """Lock-free variant of add_reviewer mirroring what the supervisor path used to do."""
    mission = state.load_mission(mission_id)
    if mission is None:
        raise ValueError(f"Mission {mission_id!r} 不存在")
    mission.setdefault("reviewers", []).append({**payload, "id": str(uuid.uuid4())})
    import time
    time.sleep(0.01)
    state.save_mission(mission_id, mission)


def test_race_actually_happens_without_lock(isolated_state: Path) -> None:
    """Proof that the harness + sleep window actually exposes the race.

    Runs the **unlocked** variants concurrently on the same mission across
    many iterations; expects at least one iteration to lose data. If this
    test ever flakes to "all iterations consistent", the race window has
    closed and the other tests in this file may be vacuously green — revisit
    the sleep / iteration count.
    """
    lost_iterations = 0
    iterations = 20
    for i in range(iterations):
        mission_id = f"mission-proof{i}"
        state.create_mission(mission_id)

        sup_session = str(uuid.uuid4())
        reviewer_payload = {
            "name": "rev", "path": "/tmp/rev", "status": "active",
            "session": str(uuid.uuid4()),
        }

        errors = _run_concurrently([
            lambda mid=mission_id, s=sup_session: _unlocked_add_supervisor(mid, s),
            lambda mid=mission_id, d=reviewer_payload: _unlocked_add_reviewer(mid, d),
        ])
        if any(e is not None for e in errors):
            # Exception from `atomic_write_text`'s tmp-file collision also
            # counts as a failure mode the lock prevents.
            lost_iterations += 1
            continue
        mission = state.load_mission(mission_id)
        if mission is None:
            lost_iterations += 1
            continue
        has_sup = state.find_supervisor(mission) is not None
        has_reviewer = len(list(state.iter_reviewers(mission_id))) == 1
        if not (has_sup and has_reviewer):
            lost_iterations += 1
    assert lost_iterations > 0, (
        f"race was supposed to be exposable but {iterations} iterations all landed both writes — "
        "sleep window may need widening"
    )


def test_concurrent_add_then_remove_worker_leaves_consistent_state(isolated_state: Path) -> None:
    """add_worker and remove_worker contending must not leave duplicate or stale entries."""
    for i in range(10):
        mission_id = f"mission-ar{i}"
        state.create_mission(mission_id)

        sess_keep = str(uuid.uuid4())
        sess_churn = str(uuid.uuid4())
        # Pre-seed the churn worker so remove_worker has something to remove.
        state.add_worker(mission_id, sess_churn, cache={"target_id": "churn"})

        errors = _run_concurrently([
            lambda mid=mission_id, s=sess_keep: state.add_worker(mid, s, cache={"target_id": "keep"}),
            lambda mid=mission_id, s=sess_churn: state.remove_worker(mid, s),
        ])
        assert all(e is None for e in errors), f"iter={i} errors: {errors!r}"

        mission = state.load_mission(mission_id)
        got = {w["session"] for w in state.iter_workers(mission)}
        assert got == {sess_keep}, (
            f"iter={i}: unexpected workers after concurrent add+remove: {got!r}"
        )
