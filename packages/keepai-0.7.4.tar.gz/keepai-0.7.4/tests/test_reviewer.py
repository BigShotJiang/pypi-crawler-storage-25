from pathlib import Path

import pytest

from keep import state


@pytest.fixture
def isolated_state(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    state_dir = tmp_path / "state"
    missions_dir = state_dir / "missions"
    missions_dir.mkdir(parents=True)
    monkeypatch.setattr(state, "STATE_DIR", state_dir)
    monkeypatch.setattr(state, "MISSIONS_DIR", missions_dir)
    return state_dir


@pytest.fixture
def mission_id(isolated_state: Path) -> str:
    name = "test-mission"
    state.create_mission(name)
    return name


# ── Task default status ───────────────────────────────────────


def test_task_default_status_is_draft(isolated_state: Path) -> None:
    task = state.create_task("m1", subject="do something")
    assert task["status"] == "draft"


# ── Reviewer CRUD ─────────────────────────────────────────────
#
# Reviewer IDs are opaque UUID4 strings (see `keep._state.reviewers.
# _next_reviewer_id`). Tests must not hard-code them; use whatever
# `add_reviewer` returns.


def _is_uuid_like(value: str) -> bool:
    # UUID4 canonical form: 8-4-4-4-12 hex.
    import re
    return bool(re.fullmatch(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", value))


def test_add_reviewer_returns_reviewer_id(mission_id: str) -> None:
    reviewer_id = state.add_reviewer(mission_id, {"session": "sess-abc", "role": "reviewer"})
    assert isinstance(reviewer_id, str)
    assert _is_uuid_like(reviewer_id)


def test_add_reviewer_stores_data(mission_id: str) -> None:
    reviewer_id = state.add_reviewer(mission_id, {"session": "sess-abc", "role": "reviewer"})
    reviewer = state.get_reviewer(mission_id, reviewer_id)
    assert reviewer["session"] == "sess-abc"
    assert reviewer["role"] == "reviewer"
    assert reviewer["id"] == reviewer_id


def test_get_reviewer_existing(mission_id: str) -> None:
    reviewer_id = state.add_reviewer(mission_id, {"session": "sess-1", "role": "reviewer"})
    reviewer = state.get_reviewer(mission_id, reviewer_id)
    assert reviewer["id"] == reviewer_id


def test_get_reviewer_nonexistent_raises(mission_id: str) -> None:
    with pytest.raises(ValueError, match="r99"):
        state.get_reviewer(mission_id, "r99")


def test_remove_reviewer_then_get_raises(mission_id: str) -> None:
    reviewer_id = state.add_reviewer(mission_id, {"session": "sess-1", "role": "reviewer"})
    state.remove_reviewer(mission_id, reviewer_id)
    with pytest.raises(ValueError, match=reviewer_id):
        state.get_reviewer(mission_id, reviewer_id)


def test_remove_reviewer_nonexistent_raises(mission_id: str) -> None:
    with pytest.raises(ValueError, match="r99"):
        state.remove_reviewer(mission_id, "r99")


def test_update_reviewer_updates_field(mission_id: str) -> None:
    reviewer_id = state.add_reviewer(mission_id, {"session": "sess-1", "role": "reviewer"})
    updated = state.update_reviewer(mission_id, reviewer_id, status="active")
    assert updated["status"] == "active"
    # Persisted
    reloaded = state.get_reviewer(mission_id, reviewer_id)
    assert reloaded["status"] == "active"


def test_update_reviewer_nonexistent_raises(mission_id: str) -> None:
    with pytest.raises(ValueError, match="r99"):
        state.update_reviewer(mission_id, "r99", status="active")


def test_iter_reviewers_returns_all(mission_id: str) -> None:
    id1 = state.add_reviewer(mission_id, {"session": "sess-1", "role": "reviewer"})
    id2 = state.add_reviewer(mission_id, {"session": "sess-2", "role": "reviewer"})
    reviewers = list(state.iter_reviewers(mission_id))
    assert len(reviewers) == 2
    ids = {r["id"] for r in reviewers}
    assert ids == {id1, id2}


def test_iter_reviewers_empty(mission_id: str) -> None:
    reviewers = list(state.iter_reviewers(mission_id))
    assert reviewers == []


# ── Review Event CRUD ─────────────────────────────────────────


def test_add_review_event_returns_event_id(mission_id: str) -> None:
    event_id = state.add_review_event(mission_id, {"type": "lgtm", "reviewer": "r1"})
    assert event_id == "re1"


def test_add_review_event_stores_data(mission_id: str) -> None:
    state.add_review_event(mission_id, {"type": "lgtm", "reviewer": "r1"})
    event = state.get_review_event(mission_id, "re1")
    assert event["type"] == "lgtm"
    assert event["reviewer"] == "r1"
    assert event["id"] == "re1"


def test_get_review_event_existing(mission_id: str) -> None:
    state.add_review_event(mission_id, {"type": "request_changes"})
    event = state.get_review_event(mission_id, "re1")
    assert event["id"] == "re1"


def test_get_review_event_nonexistent_raises(mission_id: str) -> None:
    with pytest.raises(ValueError, match="re99"):
        state.get_review_event(mission_id, "re99")


def test_update_review_event_updates_field(mission_id: str) -> None:
    state.add_review_event(mission_id, {"type": "lgtm"})
    updated = state.update_review_event(mission_id, "re1", resolved=True)
    assert updated["resolved"] is True
    # Persisted
    reloaded = state.get_review_event(mission_id, "re1")
    assert reloaded["resolved"] is True


def test_update_review_event_nonexistent_raises(mission_id: str) -> None:
    with pytest.raises(ValueError, match="re99"):
        state.update_review_event(mission_id, "re99", resolved=True)


def test_add_multiple_review_events_sequential_ids(mission_id: str) -> None:
    id1 = state.add_review_event(mission_id, {"type": "lgtm"})
    id2 = state.add_review_event(mission_id, {"type": "request_changes"})
    assert id1 == "re1"
    assert id2 == "re2"
