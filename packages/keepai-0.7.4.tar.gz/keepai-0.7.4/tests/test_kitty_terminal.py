"""Unit tests for the kitty backend's mission-container API.

Subprocess is fully stubbed; no real kitty socket is contacted.
"""
from __future__ import annotations

import json
import subprocess

import pytest

from keep.terminals import kitty as kitty_mod
from keep.terminals.kitty import KittyTerminal


class _Calls:
    def __init__(self):
        self.check_output: list[list[str]] = []
        self.run: list[list[str]] = []
        self.check_output_returns: dict[tuple[str, ...], str] = {}

    def key(self, argv) -> tuple[str, ...]:
        # Drop the "kitty @ --to <sock>" prefix for readability.
        return tuple(a for a in argv if a not in {"kitty", "@", "--to"} and not a.startswith("/"))


@pytest.fixture
def calls(monkeypatch):
    c = _Calls()

    def fake_check_output(argv, *args, **kwargs):
        c.check_output.append(list(argv))
        key = c.key(argv)
        if key in c.check_output_returns:
            return c.check_output_returns[key]
        # default: `ls` returns an empty tree
        if key and key[0] == "ls":
            return "[]"
        if key and key[0] == "launch":
            return "11"
        return ""

    def fake_run(argv, *args, **kwargs):
        c.run.append(list(argv))
        return subprocess.CompletedProcess(argv, 0, stdout=b"", stderr=b"")

    monkeypatch.setattr(kitty_mod.subprocess, "check_output", fake_check_output)
    monkeypatch.setattr(kitty_mod.subprocess, "run", fake_run)
    monkeypatch.setattr(kitty_mod.time, "sleep", lambda *a, **k: None)
    return c


@pytest.fixture
def term(monkeypatch):
    monkeypatch.setenv("KITTY_LISTEN_ON", "/tmp/keep-kitty.sock")
    return KittyTerminal()


# ---------------------------------------------------------------------------
# ensure_mission_container
# ---------------------------------------------------------------------------


def test_ensure_creates_new_os_window(calls, term, monkeypatch):
    # First `ls` → no match; after launch, second `ls` → new OS window.
    ls_responses = iter(["[]", json.dumps([
        {"id": 42, "tabs": [{"id": 100, "title": "keep-mx"}]},
    ])])

    def fake_check_output(argv, *args, **kwargs):
        calls.check_output.append(list(argv))
        key = calls.key(argv)
        if key and key[0] == "ls":
            return next(ls_responses)
        if key and key[0] == "launch":
            return "11"
        return ""

    monkeypatch.setattr(kitty_mod.subprocess, "check_output", fake_check_output)

    ref = term.ensure_mission_container("mx")

    assert ref == "42"
    launches = [c for c in calls.check_output if "launch" in c and "--type=os-window" in c]
    assert launches, calls.check_output


def test_ensure_returns_existing_os_window(calls, term):
    existing = [
        {"id": 7, "tabs": [{"id": 20, "title": "keep-mx"}]},
    ]
    calls.check_output_returns[("ls",)] = json.dumps(existing)

    ref = term.ensure_mission_container("mx")

    assert ref == "7"
    launches = [c for c in calls.check_output if "launch" in c and "--type=os-window" in c]
    assert not launches, "must not create a new OS window when one matches"


# ---------------------------------------------------------------------------
# spawn_in_container
# ---------------------------------------------------------------------------


def test_spawn_supervisor_reuses_first_tab(calls, term, monkeypatch):
    osw = [{"id": 5, "tabs": [{"id": 200, "title": "keep-mx"}]}]

    def fake_check_output(argv, *args, **kwargs):
        calls.check_output.append(list(argv))
        key = calls.key(argv)
        if key and key[0] == "ls":
            return json.dumps(osw)
        if key and key[0] == "launch" and "--type=window" in key:
            return "301"
        if key and key[0] == "launch":
            return "11"
        return ""

    monkeypatch.setattr(kitty_mod.subprocess, "check_output", fake_check_output)

    out = term.spawn_in_container("5", "supervisor", 0, "/tmp", "claude")

    assert out == "301"
    # Tab title must be set to "supervisor".
    set_title = [c for c in calls.run if "set-tab-title" in c]
    assert set_title, calls.run


def test_spawn_reviewer_opens_new_tab(calls, term):
    osw = [{"id": 5, "tabs": [{"id": 200, "title": "keep-mx"}]}]
    calls.check_output_returns[("ls",)] = json.dumps(osw)

    term.spawn_in_container("5", "reviewer", 0, "/tmp", "claude")

    new_tabs = [c for c in calls.check_output if "launch" in c and "--type=tab" in c]
    assert new_tabs, calls.check_output
    assert any("--tab-title" in c and "reviewer" in c for c in new_tabs)


def test_spawn_worker_0_opens_new_tab_worker_1(calls, term):
    osw = [{"id": 5, "tabs": [{"id": 200, "title": "keep-mx"}]}]
    calls.check_output_returns[("ls",)] = json.dumps(osw)

    term.spawn_in_container("5", "worker", 0, "/tmp", "claude")

    tabs = [c for c in calls.check_output if "launch" in c and "--type=tab" in c]
    assert tabs, calls.check_output
    assert any("worker-1" in c for c in tabs)


def test_spawn_worker_n_splits_inside_worker_tab(calls, term):
    osw = [{"id": 5, "tabs": [{"id": 200, "title": "keep-mx"}]}]
    calls.check_output_returns[("ls",)] = json.dumps(osw)

    term.spawn_in_container("5", "worker", 1, "/tmp", "claude")

    # Splits within worker tab use --type=window + --location=hsplit.
    hsplits = [
        c for c in calls.check_output
        if "launch" in c and "--location=hsplit" in c
    ]
    assert hsplits, calls.check_output


def test_spawn_raises_when_container_not_found(calls, term):
    calls.check_output_returns[("ls",)] = "[]"
    with pytest.raises(RuntimeError, match="mission OS window not found"):
        term.spawn_in_container("99", "supervisor", 0, "/tmp", "claude")


# ---------------------------------------------------------------------------
# close_mission_container
# ---------------------------------------------------------------------------


def test_close_mission_container_closes_all_tabs(calls, term):
    osw = [
        {"id": 5, "tabs": [
            {"id": 200, "title": "supervisor"},
            {"id": 201, "title": "reviewer"},
            {"id": 202, "title": "worker-1"},
        ]},
    ]
    calls.check_output_returns[("ls",)] = json.dumps(osw)

    term.close_mission_container("5")

    close_calls = [c for c in calls.run if "close-tab" in c]
    # One close-tab per tab.
    assert len(close_calls) == 3, calls.run
