"""Unit tests for the tmux backend's mission-container API.

All ``subprocess`` calls are stubbed so the tests do not spawn real tmux
processes.
"""
from __future__ import annotations

import subprocess
from unittest.mock import MagicMock

import pytest

from keep.terminals import tmux as tmux_mod
from keep.terminals.tmux import TmuxTerminal


class _Calls:
    """Capture every subprocess.run / check_output invocation for assertions."""

    def __init__(self):
        self.run: list[list[str]] = []
        self.check_output: list[list[str]] = []
        # Per-call scripted return values keyed by a predicate over argv
        self.check_output_returns: dict[str, str] = {}
        self.run_returncode_map: dict[str, int] = {}


@pytest.fixture
def calls(monkeypatch):
    c = _Calls()

    def fake_run(argv, *args, **kwargs):
        c.run.append(list(argv))
        rc = 0
        key = " ".join(argv[:3])
        rc = c.run_returncode_map.get(key, 0)
        return subprocess.CompletedProcess(argv, rc, stdout=b"", stderr=b"")

    def fake_check_output(argv, *args, **kwargs):
        c.check_output.append(list(argv))
        # pick scripted return by first 2 tokens after "tmux"
        key = " ".join(argv[:3])
        if key in c.check_output_returns:
            return c.check_output_returns[key]
        # default fallbacks for common lookups
        if "display-message" in argv:
            if "#{pane_id}" in argv:
                return "%42\n"
            if "#{window_index}" in argv:
                return "0\n"
        if "split-window" in argv or "new-window" in argv:
            return "%99\n"
        return ""

    monkeypatch.setattr(tmux_mod.subprocess, "run", fake_run)
    monkeypatch.setattr(tmux_mod.subprocess, "check_output", fake_check_output)
    monkeypatch.setattr(tmux_mod.time, "sleep", lambda *a, **k: None)
    return c


# ---------------------------------------------------------------------------
# ensure_mission_container
# ---------------------------------------------------------------------------


def test_ensure_mission_container_creates_new_session(calls, monkeypatch):
    # has-session returns non-zero → session missing → must create one.
    calls.run_returncode_map["tmux has-session -t"] = 1
    term = TmuxTerminal()

    ref = term.ensure_mission_container("abcdef1234")

    assert ref == "keep-abcdef12"
    # First call should be has-session, second new-session, third rename.
    assert ["tmux", "has-session", "-t", "keep-abcdef12"] in calls.run
    new_session_calls = [c for c in calls.run if "new-session" in c]
    assert new_session_calls, f"expected new-session call, got {calls.run!r}"


def test_ensure_mission_container_reuses_existing_session(calls):
    # has-session returns 0 → session exists → do not recreate.
    term = TmuxTerminal()

    ref = term.ensure_mission_container("abcdef1234")

    assert ref == "keep-abcdef12"
    new_session_calls = [c for c in calls.run if "new-session" in c]
    assert not new_session_calls, f"must not re-create: {calls.run!r}"


# ---------------------------------------------------------------------------
# spawn_in_container
# ---------------------------------------------------------------------------


def test_spawn_supervisor_targets_pane_0(calls):
    term = TmuxTerminal()
    out = term.spawn_in_container("keep-m", "supervisor", 0, "/tmp", "echo hi")

    assert out == "keep-m:0.%42"
    # send-keys must carry the cd + cmd payload.
    sent = [c for c in calls.run if "send-keys" in c]
    assert sent, calls.run
    assert any("cd /tmp && echo hi" in " ".join(c) for c in sent)


def test_spawn_reviewer_splits_right(calls):
    calls.check_output_returns["tmux split-window -h"] = "%77\n"
    term = TmuxTerminal()
    out = term.spawn_in_container("keep-m", "reviewer", 0, "/tmp", "claude")

    assert out == "keep-m:0.%42"
    split = [c for c in calls.check_output if "split-window" in c and "-h" in c]
    assert split, calls.check_output


def test_spawn_worker_0_splits_down(calls):
    term = TmuxTerminal()
    term.spawn_in_container("keep-m", "worker", 0, "/tmp", "claude")

    split = [c for c in calls.check_output if "split-window" in c and "-v" in c]
    assert split, calls.check_output


def test_spawn_worker_n_opens_new_window(calls):
    term = TmuxTerminal()
    term.spawn_in_container("keep-m", "worker", 1, "/tmp", "claude")

    new_win = [c for c in calls.check_output if "new-window" in c]
    assert new_win, calls.check_output
    # window name should be worker-2
    assert any("worker-2" in " ".join(c) for c in new_win)


# ---------------------------------------------------------------------------
# close_mission_container
# ---------------------------------------------------------------------------


def test_close_mission_container_kills_session(calls):
    term = TmuxTerminal()
    term.close_mission_container("keep-m")

    kill = [c for c in calls.run if "kill-session" in c]
    assert kill == [["tmux", "kill-session", "-t", "keep-m"]], calls.run


# ---------------------------------------------------------------------------
# send_text preserves two-call pattern
# ---------------------------------------------------------------------------


def test_send_text_sends_body_then_enter_separately(calls):
    term = TmuxTerminal()
    term.send_text("keep-m:0.%42", "some body")

    send_keys = [c for c in calls.run if "send-keys" in c]
    # Expect 2 send-keys: one with body, one with Enter.
    assert len(send_keys) == 2, calls.run
    assert send_keys[0][-1] == "some body"
    assert send_keys[1][-1] == "Enter"
