## reject: task #1 设计缺失

**问题**：

1. subject 为 `--title`，是 CLI 参数名而非实际标题——task 创建时 `--title` 未传值
2. description 为空——执行者无从理解需要做什么
3. 无验收标准——无法判断完成与否
4. 无 owner——不知道谁来执行

**期望**：

重新创建 task，至少包含：
- 有意义的标题（如"实现 RateLimiter 类与 pytest 测试套件"）
- 描述：交付物路径、接口规范、使用的算法
- 验收标准：对应 mission 中的 AC1–AC5
