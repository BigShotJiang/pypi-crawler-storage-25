拒绝原因：

目标文件 /tmp/keep-test-8c71119e.txt 不存在。

验收检查：
- `ls -la /tmp/keep-test-*.txt` → no matches found
- 文件未被创建，任务未完成

Worker 需要执行：
1. `echo 'SUCCESS' > /tmp/keep-test-8c71119e.txt`
2. `cat /tmp/keep-test-8c71119e.txt` 确认内容
3. 报告完成
