# Supervisor 高阶真实监督实验手册（mation 专用）

> 目标：验证 **Supervisor 只通过 supervisor 会话做决策与指挥**，不直接触达 worker；同时覆盖 stop/stall 事件链路与返工闭环。

## 1) 实验边界（必须遵守）

### 角色边界

- ✅ 允许：
  - 与 `supervisor` 会话交互（read/send/kick）
  - 通过 `task update` 管理任务状态
- ❌ 禁止：
  - 直接对 `worker` 下发指令（绕过 supervisor）
  - 把“执行动作”与“监督决策”混在同一角色里

### 命令模型（项目特有）

- 全局：
  - `mation self ...`
  - `mation mission ...`
- Mission 作用域：
  - `mation <mission_id> task ...`
  - `mation <mission_id> worker ...`
  - `mation <mission_id> supervisor ...`
- 注意：`_` 不是 mission 占位符（`mation _ mission -h` 无效）

### 事件机制约束

- stop 自动通知依赖 Stop hook：`bash ~/.mation/on-stop.sh`
- stall 降级链路：A3 → A2 → A1 → A0
- 连续上限 10 次；到 A0 后停止自动 stall 提醒

---

## 2) 重置并创建实验对象（标准起手）

### Step A: 清理同名 mission

```bash
mation mission remove <mission_id>
```

### Step B: 创建 mission 与参与者

```bash
mation mission create <mission_id>
mation <mission_id> supervisor create --name exp-supervisor --path "<repo_path>"
mation <mission_id> worker create --name exp-worker-a --path "/tmp/mation-exp-<tag>-a"
mation <mission_id> worker create --name exp-worker-b --path "/tmp/mation-exp-<tag>-b"
```

### Step C: 建任务图（高阶监督版）

```bash
mation <mission_id> task create "Define supervision strategy and task routing"
mation <mission_id> task create "Initialize Python package skeleton and pyproject"
mation <mission_id> task create "Implement todo core storage layer"
mation <mission_id> task create "Implement CLI commands add/list/done/remove"
mation <mission_id> task create "Implement input validation and error messages"
mation <mission_id> task create "Write minimal tests and run verification"
mation <mission_id> task create "Run manual e2e scenario and capture evidence"
mation <mission_id> task create "Produce final quality report and risk list"
```

---

## 3) Supervisor 监督循环（唯一合法执行路径）

> 核心：**你只和 supervisor 会话沟通**，由 supervisor 去驱动 worker。

### 标准循环

```bash
mation <mission_id> task update <task_id> --status in_progress --owner <owner_id>
mation <mission_id> supervisor send <worker_id> "<指令>"
mation <mission_id> supervisor kick <worker_id>
mation <mission_id> supervisor read <worker_id>
# 视结果决定：completed / 返工 / 转派
mation <mission_id> task update <task_id> --status completed
```

### 返工判定（必须出现至少一次）

满足任一条件就返工，不得直接 completed：

- 只给结论，不给验证证据（命令、输出、日志片段）
- 只跑 happy path，未覆盖错误路径/边界条件
- 改动过快且解释不足（疑似补丁式修复）

返工示例动作：

```bash
mation <mission_id> supervisor send <worker_id> "补充失败路径验证与复现步骤；附命令输出"
mation <mission_id> supervisor kick <worker_id>
```

---

## 4) 事件验收（mation 特有）

### stop 验收必须满足

- daemon 日志出现 `<mation event="stop" ...>`
- daemon 日志出现 `Stop signal consumed [...]`
- supervisor 可读到对应 worker 回复

```bash
tail -n 200 ~/.mation/daemon.log
```

### stall 验收必须满足

- 能观察到 A3 → A2 → A1 → A0
- 达到 10 次后不再继续自动 stall 提醒

---

## 5) 证据清单（每轮都要留痕）

每个 task 至少保留以下之一：

1. `supervisor read` 的关键回复片段
2. 对应验证命令与输出（测试、日志、CLI）
3. 返工指令与二次结果

建议最终整理为：

- `任务ID -> 决策 -> 证据 -> 风险`

---

## 6) 最小通过标准

1. task 全部 `completed`
2. stop 自动通知链路通过
3. stall 降级链路可观测
4. 至少一次返工闭环（有指令、有补充证据、有再决策）
5. 全流程未出现“绕过 supervisor 直接控制 worker”的越界行为
