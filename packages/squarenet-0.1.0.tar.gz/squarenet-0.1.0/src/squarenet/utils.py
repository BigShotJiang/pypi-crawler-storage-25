import numpy as np
import matplotlib.pyplot as plt
from numpy.lib.stride_tricks import sliding_window_view
from importlib import resources

def checkerboard(grid, scales):
    n = grid.shape[0]
    I, J = np.arange(n)[:, None], np.arange(n)[None, :]

    fig, axes = plt.subplots(2, 2, figsize=(8, 8))  # grille 2x2

    for ax, i in zip(axes.flat, scales):
        H = n // i
        mask = (I // H) % 2 == (J // H) % 2
        
        ax.scatter(grid[mask, 0], grid[mask, 1],
                color="blue", s=3)
        ax.set_aspect("equal")
        ax.set_xticks([])
        ax.set_yticks([])
        for spine in ax.spines.values():
            spine.set_visible(False)

    plt.tight_layout()
    plt.show()

def grid_disorder(net):
    """
    Measures the "disorder" of a D-dimensional grid.

    Args:
        net (np.ndarray): Grid of shape (*IJ, D), points already sorted with attached coordinates.
    
    Returns:
        int: Total number of consecutive inversions along all axes (lower is better).
    """
    total_disorder = 0
    D = net.shape[-1]
    for axis in range(D):
        # Move the sorting axis to the front
        axes_order = (axis,) + tuple(i for i in range(net.ndim - 1) if i != axis) + (net.ndim - 1,)
        net_perm = np.transpose(net, axes_order)
        
        # Flatten all remaining axes except the sorting axis
        shape = net_perm.shape
        flat_net = net_perm.reshape(shape[0], -1, D)
        
        # Count consecutive inversions along the axis
        coords = flat_net[..., axis]  # shape (axis_size, n_cols)
        inv = np.sum(coords[:-1, :] > coords[1:, :])  # i > i+1
        total_disorder += inv
    return total_disorder

def initpoint(method, size):
    N, D = size
    if method == "test":
        points = np.random.rand(N, D)
    if method == "france":
        import geopandas as gpd
        from shapely.geometry import Point

        # Charger le GeoJSON
        with resources.files("squarenet.data").joinpath("france.geojson").open("r") as f:
            gdf = gpd.read_file(f)
        metropole = gdf[~gdf['nom'].isin([
            'Guadeloupe', 'Martinique', 'Guyane', 'La Réunion', 'Mayotte', 'Corse'
        ])]


        # Merge regions
        france = metropole.union_all()

        # Bounding box
        minx, miny, maxx, maxy = france.bounds

        def sample_points(polygon, n_points):
            points = []
            
            while len(points) < n_points:
                x = np.random.uniform(minx, maxx)
                y = np.random.uniform(miny, maxy)
                p = Point(x, y)
                
                if polygon.contains(p):
                    points.append(p)
            
            return np.array([[p.x, p.y] for p in points])

        # Generate sample
        points = sample_points(france, N)
    return points

def gram(self, X, ws):
    """
    Compute a sparse Gram matrix using local neighborhoods within a window.

    Args:
        X (np.ndarray): Input features of shape (N, C)
        ws (int or sequence): Half window size per dimension.
                             If int → same for all dims
                             If sequence → one per grid dim

    Returns:
        np.ndarray: Sparse Gram matrix of shape (N, K)
    """

    # Map to grid → (*IJ, C)
    Xg = self.map(X)
    *grid_shape, C = Xg.shape
    ndim = len(grid_shape)
    d = ws

    # Handle window size
    if isinstance(d, int):
        d = [d] * ndim
    else:
        assert len(d) == ndim, "d must match number of grid dimensions"

    # Padding
    pad_width = [(di, di) for di in d] + [(0, 0)]
    X_padded = np.pad(Xg, pad_width, mode='constant')

    # Window shape
    window_shape = tuple(2 * di + 1 for di in d)

    # Extract patches
    patches = sliding_window_view(
        X_padded,
        window_shape=window_shape,
        axis=tuple(range(ndim))
    )

    # Compute K = number of neighbors
    K = np.prod(window_shape)

    # reshape → (*IJ, K, C)
    patches = patches.reshape(*grid_shape, K, C)

    # center → (*IJ, 1, C)
    center = Xg[(...,) + (None, slice(None))]

    # dot product → (*IJ, K)
    G = np.sum(center * patches, axis=-1)

    # back to (N, K)
    G = self.invert_map(G)

    return G