from .core import SquareNet
from .utils import checkerboard, initpoint, grid_disorder, gram

__all__ = ["squarenet"]
__version__ = "0.1.0"