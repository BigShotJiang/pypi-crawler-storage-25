from dataclasses import dataclass

from marshmallow_dataclass import class_schema

from semantha_sdk.rest.rest_client import RestSchema

from semantha_sdk.model.error_container import ErrorContainer
from typing import List
from typing import Optional

@dataclass
class PromptValidationResult:
    """ author semantha, this is a generated class do not change manually! """
    # VALID or INVALID
    status: Optional[str] = None
    missing_system_prompt_params: Optional[List[str]] = None
    missing_user_prompt_params: Optional[List[str]] = None
    errors: Optional[ErrorContainer] = None

PromptValidationResultSchema = class_schema(PromptValidationResult, base_schema=RestSchema)
