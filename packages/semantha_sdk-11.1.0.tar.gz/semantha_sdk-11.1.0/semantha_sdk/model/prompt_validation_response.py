from dataclasses import dataclass

from marshmallow_dataclass import class_schema

from semantha_sdk.rest.rest_client import RestSchema

from semantha_sdk.model.prompt_validation_result import PromptValidationResult
from typing import Optional

@dataclass
class PromptValidationResponse:
    """ author semantha, this is a generated class do not change manually! """
    rendered_system_prompt: Optional[str] = None
    rendered_user_prompt: Optional[str] = None
    response: Optional[str] = None
    validation_result: Optional[PromptValidationResult] = None

PromptValidationResponseSchema = class_schema(PromptValidationResponse, base_schema=RestSchema)
