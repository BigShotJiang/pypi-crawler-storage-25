from dataclasses import dataclass

from marshmallow_dataclass import class_schema

from semantha_sdk.rest.rest_client import RestSchema

from semantha_sdk.model.custom_field import CustomField
from typing import List
from typing import Optional

@dataclass
class PromptValidationTemplate:
    """ author semantha, this is a generated class do not change manually! """
    user_prompt: str
    system_prompt: Optional[str] = None
    temperature: Optional[float] = None
    top_k: Optional[int] = None
    custom_fields: Optional[List[CustomField]] = None

PromptValidationTemplateSchema = class_schema(PromptValidationTemplate, base_schema=RestSchema)
