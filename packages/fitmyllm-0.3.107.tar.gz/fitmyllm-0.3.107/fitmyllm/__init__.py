"""FitMyLLM — Find the best local AI model for your GPU."""
from importlib.metadata import version as _pkg_version, PackageNotFoundError

try:
    __version__ = _pkg_version("fitmyllm")
except PackageNotFoundError:
    __version__ = "0.0.0"  # fallback for editable/dev installs
