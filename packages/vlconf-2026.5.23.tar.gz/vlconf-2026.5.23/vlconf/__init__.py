# init

__version__ = "2026.05.23"

#####################
# Message verbosity
#####################

print_verbosity=2
log_verbosity = 1


##################################
# matplotlib presets
##################################
import matplotlib.pyplot as plt



def conf_matplotlib(
    reset=False,
    legend_marker_scale=2,
    grid=True,
    grid_alpha=0.3,
    fig_autolayout=True,
    labelsize=17,
    labelpad=14,
    font_size=17,
    fig_size=(8, 6),
):
    """Configure matplotlib plot style.

    Parameters
    ----------
    reset : bool
            Whether or not to reset the plot
            layout before configuring.
    fig_size : tuple of int
               The size of the figure.
    fig_autolayout : bool
                     To turn on the figure autolayout
                     or not.
    grid : bool
           Turn grid on or off.
    grid_alpha : float
                 The transparency level of the
                 grid.
    labelsize : int
                The axes label size.
    labelpad : int
               The axes label pad.
    legend_marker_scale : int
                          The legend marker scale.
    """

    import matplotlib.pyplot as plt

    if reset:
        reset_matplotlib()

    plt.rcParams.update({"font.size": font_size})
    plt.rcParams.update({"figure.figsize": fig_size})
    plt.rcParams.update({"axes.grid": grid})
    plt.rcParams.update({"axes.labelpad": labelpad})
    plt.rcParams.update({"axes.labelsize": labelsize})
    plt.rcParams.update({"figure.autolayout": fig_autolayout})
    plt.rcParams.update({"grid.alpha": grid_alpha})
    plt.rcParams.update({"legend.markerscale": legend_marker_scale})


def reset_matplotlib():
    import matplotlib

    matplotlib.rcParams.update(matplotlib.rcParamsDefault)




PRL_SINGLE_COL_TWO_PANELS_RC = {
    # Text
    "font.size": 8,
    "axes.labelsize": 8.5,
    "axes.titlesize": 8.5,
    "xtick.labelsize": 8,
    "ytick.labelsize": 8,
    "legend.fontsize": 7.5,
    "figure.titlesize": 8.5,
    "axes.labelpad": 1.5,
    # Math/text rendering
    "mathtext.fontset": "cm",
    "font.family": "serif",
    "font.serif": ["Computer Modern Roman", "CMU Serif", "DejaVu Serif"],

    # Lines and markers
    "axes.linewidth": 0.6,
    "lines.linewidth": 1.0,
    "lines.markersize": 3.0,
    "patch.linewidth": 0.6,

    # Ticks
    "xtick.direction": "in",
    "ytick.direction": "in",
    "xtick.major.size": 3.0,
    "ytick.major.size": 3.0,
    "xtick.minor.size": 1.8,
    "ytick.minor.size": 1.8,
    "xtick.major.width": 0.6,
    "ytick.major.width": 0.6,
    "xtick.minor.width": 0.5,
    "ytick.minor.width": 0.5,
    "xtick.top": True,
    "ytick.right": True,
    "axes.grid": False,

    # Export
    "figure.dpi": 300,
    "savefig.dpi": 600,
    "savefig.bbox": "tight",
    "savefig.pad_inches": 0.015,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
}

PRL_DOUBLE_COL_TWO_PANELS_RC = {
    # Text
    "font.size": 8,
    "axes.labelsize": 9,
    "axes.titlesize": 9,
    "xtick.labelsize": 8,
    "ytick.labelsize": 8,
    "legend.fontsize": 8,
    "figure.titlesize": 9,
    "axes.labelpad": 2.0,
    # Math/text rendering
    "mathtext.fontset": "cm",
    "font.family": "serif",
    "font.serif": ["Computer Modern Roman", "CMU Serif", "DejaVu Serif"],

    # Lines and markers
    "axes.linewidth": 0.65,
    "lines.linewidth": 1.1,
    "lines.markersize": 3.5,
    "patch.linewidth": 0.65,

    # Ticks
    "xtick.direction": "in",
    "ytick.direction": "in",
    "xtick.major.size": 3.2,
    "ytick.major.size": 3.2,
    "xtick.minor.size": 2.0,
    "ytick.minor.size": 2.0,
    "xtick.major.width": 0.65,
    "ytick.major.width": 0.65,
    "xtick.minor.width": 0.5,
    "ytick.minor.width": 0.5,
    "xtick.top": True,
    "ytick.right": True,
    "axes.grid": False,

    # Export
    "figure.dpi": 300,
    "savefig.dpi": 600,
    "savefig.bbox": "tight",
    "savefig.pad_inches": 0.02,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
}


PRL_SINGLE_COL_SINGLE_PANEL_RC = {
    # Text
    "font.size": 8,
    "axes.labelsize": 8.5,
    "axes.titlesize": 8.5,
    "xtick.labelsize": 8,
    "ytick.labelsize": 8,
    "legend.fontsize": 7.5,
    "figure.titlesize": 8.5,
    "axes.labelpad": 2.0,
    # Math/text rendering
    "mathtext.fontset": "cm",
    "font.family": "serif",
    "font.serif": ["Computer Modern Roman", "CMU Serif", "DejaVu Serif"],

    # Lines and markers
    "axes.linewidth": 0.6,
    "lines.linewidth": 1.0,
    "lines.markersize": 3.0,
    "patch.linewidth": 0.6,

    # Ticks
    "xtick.direction": "in",
    "ytick.direction": "in",
    "xtick.major.size": 3.0,
    "ytick.major.size": 3.0,
    "xtick.minor.size": 1.8,
    "ytick.minor.size": 1.8,
    "xtick.major.width": 0.6,
    "ytick.major.width": 0.6,
    "xtick.minor.width": 0.5,
    "ytick.minor.width": 0.5,
    "xtick.top": True,
    "ytick.right": True,

    # Axes
    "axes.grid": False,

    # Export
    "figure.dpi": 300,
    "savefig.dpi": 600,
    "savefig.bbox": "tight",
    "savefig.pad_inches": 0.015,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
}


def init_single_panel_single_column_figenv(
    figsize=(3.375, 2.35),
    **subplots_kwargs,
):
    plt.rcParams.update(PRL_SINGLE_COL_SINGLE_PANEL_RC)

    fig, ax = plt.subplots(
        1, 1,
        figsize=figsize,
        constrained_layout=True,
        **subplots_kwargs,
    )

    return fig, ax

def init_two_panel_single_column_figenv():
    plt.rcParams.update(PRL_SINGLE_COL_TWO_PANELS_RC)

    fig, axs = plt.subplots(
        1, 2,
        figsize=(3.375, 1.65),
        constrained_layout=True,
    )

    return fig, axs


def init_two_panel_double_column_figenv():
    plt.rcParams.update(PRL_DOUBLE_COL_TWO_PANELS_RC)

    fig, axs = plt.subplots(
        1, 2,
        figsize=(6.75, 2.7),
        constrained_layout=True,
    )

    return fig, axs
