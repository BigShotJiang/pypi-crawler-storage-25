"""DeFiStream API client."""

from __future__ import annotations

import os
from typing import Any, Literal

import httpx

from .exceptions import (
    AuthenticationError,
    DeFiStreamError,
    NotFoundError,
    QuotaExceededError,
    RateLimitError,
    ServerError,
    ValidationError,
)
from .models import ResponseMetadata
from .protocols import (
    AAVEProtocol,
    AsyncAAVEProtocol,
    AsyncBinanceProtocol,
    AsyncBitcoinNativeProtocol,
    AsyncERC20Protocol,
    AsyncHyperliquidProtocol,
    AsyncLidoProtocol,
    AsyncNativeProtocol,
    AsyncStaderProtocol,
    AsyncThresholdProtocol,
    AsyncTRC20Protocol,
    AsyncTronNativeProtocol,
    AsyncUniswapProtocol,
    BinanceProtocol,
    BitcoinNativeProtocol,
    ERC20Protocol,
    HyperliquidProtocol,
    LidoProtocol,
    NativeProtocol,
    StaderProtocol,
    ThresholdProtocol,
    TRC20Protocol,
    TronNativeProtocol,
    UniswapProtocol,
)

DEFAULT_BASE_URL = "https://api.defistream.dev/v1"

# Columns the server emits as timestamps. We normalize all of them to a
# timezone-aware UTC datetime regardless of how the server encoded them
# (native TIMESTAMP, ISO string, or epoch seconds). Newer server builds
# (>= 2026-04) ship parquet with native Datetime(UTC); older builds ship
# stringified datetimes; JSON responses carry epoch seconds or ISO strings
# depending on endpoint.
_TIME_COLUMNS = ("time", "block_time", "window")


def _normalize_time_columns_polars(df):
    """Coerce known time columns to ``pl.Datetime('us', 'UTC')`` in-place.

    Handles three server encodings so the same client works against old and
    new server builds:
      * already temporal — passthrough
      * Utf8 ISO string (old HL/Binance parquet, all JSON)   — ``str.to_datetime``
      * numeric epoch seconds (EVM decoders, some JSON)      — ``from_epoch``
    """
    import polars as pl

    exprs = []
    for col in _TIME_COLUMNS:
        if col not in df.columns:
            continue
        dtype = df[col].dtype
        if dtype.is_temporal():
            continue
        if dtype == pl.Utf8:
            exprs.append(pl.col(col).str.to_datetime(time_zone="UTC").alias(col))
        elif dtype.is_numeric():
            exprs.append(
                pl.from_epoch(col, time_unit="s")
                .dt.replace_time_zone("UTC")
                .alias(col)
            )
    if exprs:
        df = df.with_columns(exprs)
    return df


def _normalize_time_columns_pandas(df):
    """Pandas counterpart to ``_normalize_time_columns_polars``.

    Mirrors the dtype-dispatch: numeric → ``to_datetime(unit='s')``, strings
    → ``to_datetime`` (ISO inference), already-datetime → passthrough.
    """
    import pandas as pd

    for col in _TIME_COLUMNS:
        if col not in df.columns:
            continue
        if pd.api.types.is_datetime64_any_dtype(df[col]):
            continue
        if pd.api.types.is_numeric_dtype(df[col]):
            df[col] = pd.to_datetime(df[col], unit="s", utc=True)
        else:
            df[col] = pd.to_datetime(df[col], utc=True)
    return df


class Wallets:
    """Wallet label management — list, upsert, and delete wallet labels.

    Labels are stored in the user's private namespace (auto-assigned by the API gateway).
    Public labels (Binance, exchanges, etc.) are read-only and used by default in queries.

    Example::

        client = DeFiStream()

        # Upload labels from a DataFrame
        import pandas as pd
        df = pd.DataFrame({
            "address": ["0xabc...", "bc1q..."],
            "labels": ["My Whale", "BTC Cold"],
            "categories": ["whale", "hodl"],
            "entity": ["PersonalWhale", "MyCold"],
        })
        client.wallets.upsert(df)

        # List own labels
        labels = client.wallets.list(limit=100)

        # Delete a label
        client.wallets.delete("0xabc...")
    """

    def __init__(self, client: "DeFiStream"):
        self._client = client

    def list(
        self,
        category: str | None = None,
        entity: str | None = None,
        search: str | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> list[dict]:
        """List wallet labels in your namespace.

        Args:
            category: Filter by category (e.g., 'whale', 'exchange').
            entity: Filter by entity name (e.g., 'Binance').
            search: Search labels by substring.
            limit: Max results (default 100).
            offset: Pagination offset.

        Returns:
            List of label dicts with address, labels, categories, entity.
        """
        params = {"limit": limit, "offset": offset}
        if category:
            params["category"] = category
        if entity:
            params["entity"] = entity
        if search:
            params["search"] = search

        response = self._client._client.get("/wallets/labels", params=params)
        if response.status_code >= 400:
            self._client._handle_error_response(response)
        data = response.json()
        return data.get("data", [])

    def get(self, address: str) -> dict | None:
        """Look up a single address in your namespace.

        Args:
            address: Wallet address (e.g., '0xabc...' or 'bc1q...').

        Returns:
            Label dict or None if not found.
        """
        response = self._client._client.get(f"/wallets/labels/{address}")
        if response.status_code == 404:
            return None
        if response.status_code >= 400:
            self._client._handle_error_response(response)
        return response.json()

    def upsert(self, data) -> dict:
        """Bulk upsert wallet labels from a DataFrame or parquet bytes.

        Args:
            data: pandas DataFrame, polars DataFrame, or parquet bytes.
                  Must have 'address' column. 'labels' and 'categories'
                  should be list columns. Optional: 'entity' (str).

        Returns:
            Dict with 'status', 'upserted' count, 'namespace'.

        Example::

            import pandas as pd
            df = pd.DataFrame({
                "address": ["0xabc...", "bc1q..."],
                "labels": [["My Whale"], ["BTC Cold"]],
                "categories": [["whale"], ["hodl"]],
                "entity": ["PersonalWhale", "MyCold"],
            })
            client.wallets.upsert(df)
        """
        import io

        if hasattr(data, "to_parquet"):
            # pandas DataFrame
            buf = io.BytesIO()
            data.to_parquet(buf, index=False)
            body = buf.getvalue()
        elif hasattr(data, "write_parquet"):
            # polars DataFrame
            buf = io.BytesIO()
            data.write_parquet(buf)
            body = buf.getvalue()
        elif isinstance(data, bytes):
            body = data
        else:
            raise ValueError("data must be a pandas/polars DataFrame or parquet bytes")

        fmt = "parquet"

        response = self._client._client.post(
            "/wallets/labels/upsert",
            content=body,
            headers={"Content-Type": "application/octet-stream"},
        )
        if response.status_code >= 400:
            self._client._handle_error_response(response)
        return response.json()

    def delete(self, address: str) -> dict:
        """Delete a wallet label from your namespace.

        Args:
            address: Wallet address to delete.

        Returns:
            Dict with 'status' and 'address'.
        """
        response = self._client._client.delete(f"/wallets/labels/{address}")
        if response.status_code >= 400:
            self._client._handle_error_response(response)
        return response.json()


class AsyncWallets:
    """Async version of Wallets. Same API but all methods are async."""

    def __init__(self, client: "AsyncDeFiStream"):
        self._client = client

    async def list(
        self,
        category: str | None = None,
        entity: str | None = None,
        search: str | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> list[dict]:
        params = {"limit": limit, "offset": offset}
        if category:
            params["category"] = category
        if entity:
            params["entity"] = entity
        if search:
            params["search"] = search

        response = await self._client._client.get("/wallets/labels", params=params)
        if response.status_code >= 400:
            self._client._handle_error_response(response)
        data = response.json()
        return data.get("data", [])

    async def get(self, address: str) -> dict | None:
        response = await self._client._client.get(f"/wallets/labels/{address}")
        if response.status_code == 404:
            return None
        if response.status_code >= 400:
            self._client._handle_error_response(response)
        return response.json()

    async def upsert(self, data) -> dict:
        import io

        if hasattr(data, "to_parquet"):
            buf = io.BytesIO()
            data.to_parquet(buf, index=False)
            body = buf.getvalue()
        elif hasattr(data, "write_parquet"):
            buf = io.BytesIO()
            data.write_parquet(buf)
            body = buf.getvalue()
        elif isinstance(data, bytes):
            body = data
        else:
            raise ValueError("data must be a pandas/polars DataFrame or parquet bytes")

        response = await self._client._client.post(
            "/wallets/labels/upsert",
            content=body,
            headers={"Content-Type": "application/octet-stream"},
        )
        if response.status_code >= 400:
            self._client._handle_error_response(response)
        return response.json()

    async def delete(self, address: str) -> dict:
        response = await self._client._client.delete(f"/wallets/labels/{address}")
        if response.status_code >= 400:
            self._client._handle_error_response(response)
        return response.json()
DEFAULT_TIMEOUT = 600.0


class BaseClient:
    """Base client with shared functionality."""

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = 3,
    ):
        # Read API key from argument or environment
        self.api_key = api_key or os.environ.get("DEFISTREAM_API_KEY")
        if not self.api_key:
            raise ValueError(
                "API key required. Pass api_key or set DEFISTREAM_API_KEY environment variable."
            )

        self.base_url = (base_url or os.environ.get("DEFISTREAM_BASE_URL", DEFAULT_BASE_URL)).rstrip("/")
        self.timeout = timeout
        self.max_retries = max_retries
        self.last_response: ResponseMetadata = ResponseMetadata()

    def _get_headers(self) -> dict[str, str]:
        """Get request headers."""
        return {
            "X-API-Key": self.api_key,  # type: ignore
            "Accept": "application/json",
        }

    def _parse_response_metadata(self, headers: httpx.Headers) -> ResponseMetadata:
        """Parse rate limit and quota info from response headers."""
        return ResponseMetadata(
            rate_limit=int(headers.get("X-RateLimit-Limit", 0)) or None,
            quota_remaining=int(headers.get("X-RateLimit-Remaining", 0)) or None,
            request_cost=int(headers.get("X-Request-Cost", 0)) or None,
        )

    def _handle_error_response(self, response: httpx.Response) -> None:
        """Handle error responses."""
        status_code = response.status_code

        try:
            data = response.json()
            message = data.get("error", data.get("message", response.text))
            error_code = data.get("code", "")
        except Exception:
            message = response.text
            error_code = ""

        if status_code == 401:
            raise AuthenticationError(message, status_code, response)

        if status_code == 403:
            if error_code == "quota_exceeded":
                # Try to extract remaining quota from response
                remaining = 0
                try:
                    remaining = int(data.get("remaining", 0))
                except (ValueError, TypeError):
                    pass
                raise QuotaExceededError(message, remaining=remaining, status_code=status_code, response=response)
            raise AuthenticationError(message, status_code, response)

        if status_code == 404:
            raise NotFoundError(message, status_code, response)

        if status_code == 429:
            retry_after = response.headers.get("Retry-After")
            raise RateLimitError(
                message,
                retry_after=float(retry_after) if retry_after else None,
                status_code=status_code,
                response=response,
            )

        if status_code == 400:
            raise ValidationError(message, status_code, response)

        if status_code >= 500:
            raise ServerError(message, status_code, response)

        raise DeFiStreamError(message, status_code, response)

    def _process_response(
        self,
        response: httpx.Response,
        as_dataframe: Literal["pandas", "polars"] | None = None,
        output_file: str | None = None,
        response_key: str = "events",
    ) -> list[dict[str, Any]] | Any:
        """Process response and optionally convert to DataFrame or save to file."""
        self.last_response = self._parse_response_metadata(response.headers)

        if response.status_code >= 400:
            self._handle_error_response(response)

        content_type = response.headers.get("Content-Type", "")

        # Handle file output
        if output_file:
            if output_file.endswith(".parquet"):
                with open(output_file, "wb") as f:
                    f.write(response.content)
            else:
                with open(output_file, "w") as f:
                    f.write(response.text)
            return None

        # Handle CSV response
        if "text/csv" in content_type:
            csv_text = response.text
            if as_dataframe == "pandas":
                import io
                import pandas as pd
                return pd.read_csv(io.StringIO(csv_text))
            elif as_dataframe == "polars":
                import io
                import polars as pl
                return pl.read_csv(io.StringIO(csv_text))
            return csv_text

        # Handle Parquet response
        if "application/octet-stream" in content_type or "application/parquet" in content_type:
            if as_dataframe == "pandas":
                import io
                import pandas as pd
                df = pd.read_parquet(io.BytesIO(response.content))
                return _normalize_time_columns_pandas(df)
            elif as_dataframe == "polars":
                import io
                import polars as pl
                df = pl.read_parquet(io.BytesIO(response.content))
                return _normalize_time_columns_polars(df)
            return response.content

        # Handle JSON response
        data = response.json()

        if data.get("status") == "error":
            raise DeFiStreamError(data.get("error", "Unknown error"))

        events = data.get(response_key, [])

        if as_dataframe == "pandas":
            import pandas as pd
            df = pd.DataFrame(events)
            return _normalize_time_columns_pandas(df)
        elif as_dataframe == "polars":
            import polars as pl
            df = pl.DataFrame(events)
            return _normalize_time_columns_polars(df)

        return events


# ---------------------------------------------------------------------------
# Chain / exchange namespace classes
# ---------------------------------------------------------------------------

class EVMChain:
    """EVM chain protocols."""

    def __init__(self, client: BaseClient):
        self.erc20 = ERC20Protocol(client)
        self.native = NativeProtocol(client)
        self.aave_v3 = AAVEProtocol(client)
        self.uniswap_v3 = UniswapProtocol(client)
        self.lido = LidoProtocol(client)
        self.stader = StaderProtocol(client)
        self.threshold = ThresholdProtocol(client)


class TronChain:
    """Tron chain protocols."""

    def __init__(self, client: BaseClient):
        self.trc20 = TRC20Protocol(client)
        self.native = TronNativeProtocol(client)


class BitcoinChain:
    """Bitcoin chain protocols."""

    def __init__(self, client: BaseClient):
        self.native = BitcoinNativeProtocol(client)


class ExchangeNamespace:
    """Exchange data protocols."""

    def __init__(self, client: BaseClient):
        self.hyperliquid = HyperliquidProtocol(client)
        self.binance = BinanceProtocol(client)


class AsyncEVMChain:
    """Async EVM chain protocols."""

    def __init__(self, client: BaseClient):
        self.erc20 = AsyncERC20Protocol(client)
        self.native = AsyncNativeProtocol(client)
        self.aave_v3 = AsyncAAVEProtocol(client)
        self.uniswap_v3 = AsyncUniswapProtocol(client)
        self.lido = AsyncLidoProtocol(client)
        self.stader = AsyncStaderProtocol(client)
        self.threshold = AsyncThresholdProtocol(client)


class AsyncTronChain:
    """Async Tron chain protocols."""

    def __init__(self, client: BaseClient):
        self.trc20 = AsyncTRC20Protocol(client)
        self.native = AsyncTronNativeProtocol(client)


class AsyncBitcoinChain:
    """Async Bitcoin chain protocols."""

    def __init__(self, client: BaseClient):
        self.native = AsyncBitcoinNativeProtocol(client)


class AsyncExchangeNamespace:
    """Async exchange data protocols."""

    def __init__(self, client: BaseClient):
        self.hyperliquid = AsyncHyperliquidProtocol(client)
        self.binance = AsyncBinanceProtocol(client)


# ---------------------------------------------------------------------------
# Main client classes
# ---------------------------------------------------------------------------

class DeFiStream(BaseClient):
    """
    Synchronous DeFiStream API client with builder pattern.

    Example:
        >>> from defistream import DeFiStream
        >>> client = DeFiStream(api_key="dsk_...")
        >>>
        >>> # EVM protocols
        >>> df = (
        ...     client.evm.erc20.transfers("USDT")
        ...     .network("ETH")
        ...     .block_range(24000000, 24100000)
        ...     .as_df()
        ... )
        >>>
        >>> # Tron
        >>> df = client.tron.trc20.transfers("USDT").as_df()
        >>>
        >>> # Bitcoin
        >>> df = client.bitcoin.native.transfers().as_df()
        >>>
        >>> # Exchange data
        >>> df = client.exchange.binance.ohlcv().token("BTC").as_df()
        >>> df = client.exchange.hyperliquid.fills().tokens("ETH").as_df()
    """

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = 3,
    ):
        super().__init__(api_key, base_url, timeout, max_retries)
        self._http_client: httpx.Client | None = None

        # Chain namespaces
        self.evm = EVMChain(self)
        self.tron = TronChain(self)
        self.bitcoin = BitcoinChain(self)
        self.exchange = ExchangeNamespace(self)
        self.wallets = Wallets(self)

    @property
    def _client(self) -> httpx.Client:
        """Lazy-initialize HTTP client."""
        if self._http_client is None:
            self._http_client = httpx.Client(
                base_url=self.base_url,
                headers=self._get_headers(),
                timeout=self.timeout,
            )
        return self._http_client

    def close(self) -> None:
        """Close the HTTP client."""
        if self._http_client is not None:
            self._http_client.close()
            self._http_client = None

    def __enter__(self) -> "DeFiStream":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    def _request(
        self,
        method: str,
        path: str,
        params: dict[str, Any] | None = None,
        as_dataframe: Literal["pandas", "polars"] | None = None,
        output_file: str | None = None,
        response_key: str = "events",
    ) -> list[dict[str, Any]] | Any:
        """Make HTTP request."""
        if params is None:
            params = {}

        if output_file:
            if output_file.endswith(".parquet"):
                params["format"] = "parquet"
            elif output_file.endswith(".csv"):
                params["format"] = "csv"

        response = self._client.request(method, path, params=params)
        return self._process_response(response, as_dataframe, output_file, response_key)

    def protocols(self) -> list[str]:
        """Get list of available protocols."""
        response = self._client.get("/protocols")
        if response.status_code >= 400:
            self._handle_error_response(response)
        data = response.json()
        if isinstance(data, list):
            return data
        return data.get("protocols", [])

    def aggregate_schema(self, protocol: str) -> dict[str, Any]:
        """Get the aggregate schema for a protocol.

        Args:
            protocol: Protocol name (e.g. ``"erc20"``, ``"aave_v3"``).

        Returns:
            Schema dictionary describing available aggregate fields.
        """
        response = self._client.get(f"/{protocol}/aggregate_schema")
        if response.status_code >= 400:
            self._handle_error_response(response)
        return response.json()


class AsyncDeFiStream(BaseClient):
    """
    Asynchronous DeFiStream API client with builder pattern.

    Example:
        >>> import asyncio
        >>> from defistream import AsyncDeFiStream
        >>>
        >>> async def main():
        ...     async with AsyncDeFiStream(api_key="dsk_...") as client:
        ...         df = await (
        ...             client.evm.erc20.transfers("USDT")
        ...             .network("ETH")
        ...             .block_range(24000000, 24100000)
        ...             .as_df()
        ...         )
        ...
        >>> asyncio.run(main())
    """

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = 3,
    ):
        super().__init__(api_key, base_url, timeout, max_retries)
        self._http_client: httpx.AsyncClient | None = None

        # Chain namespaces (async versions)
        self.evm = AsyncEVMChain(self)
        self.tron = AsyncTronChain(self)
        self.bitcoin = AsyncBitcoinChain(self)
        self.exchange = AsyncExchangeNamespace(self)
        self.wallets = AsyncWallets(self)

    @property
    def _client(self) -> httpx.AsyncClient:
        """Lazy-initialize async HTTP client."""
        if self._http_client is None:
            self._http_client = httpx.AsyncClient(
                base_url=self.base_url,
                headers=self._get_headers(),
                timeout=self.timeout,
            )
        return self._http_client

    async def close(self) -> None:
        """Close the async HTTP client."""
        if self._http_client is not None:
            await self._http_client.aclose()
            self._http_client = None

    async def __aenter__(self) -> "AsyncDeFiStream":
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    async def _request(
        self,
        method: str,
        path: str,
        params: dict[str, Any] | None = None,
        as_dataframe: Literal["pandas", "polars"] | None = None,
        output_file: str | None = None,
        response_key: str = "events",
    ) -> list[dict[str, Any]] | Any:
        """Make async HTTP request."""
        if params is None:
            params = {}

        if output_file:
            if output_file.endswith(".parquet"):
                params["format"] = "parquet"
            elif output_file.endswith(".csv"):
                params["format"] = "csv"

        response = await self._client.request(method, path, params=params)
        return self._process_response(response, as_dataframe, output_file, response_key)

    async def protocols(self) -> list[str]:
        """Get list of available protocols."""
        response = await self._client.get("/protocols")
        if response.status_code >= 400:
            self._handle_error_response(response)
        data = response.json()
        if isinstance(data, list):
            return data
        return data.get("protocols", [])

    async def aggregate_schema(self, protocol: str) -> dict[str, Any]:
        """Get the aggregate schema for a protocol.

        Args:
            protocol: Protocol name (e.g. ``"erc20"``, ``"aave_v3"``).

        Returns:
            Schema dictionary describing available aggregate fields.
        """
        response = await self._client.get(f"/{protocol}/aggregate_schema")
        if response.status_code >= 400:
            self._handle_error_response(response)
        return response.json()
