from __future__ import annotations

from typing import Any, Dict

from appdynamics.agent.core.logs import setup_logger
from appdynamics.agent.services.event_processor import EventProcessor
from appdynamics.agent.interceptor.utils.genai_event import GenAIEvent, GenAIEventConfig
import threading
from appdynamics import config

class EventService:
    """
    Entry-point to report events. Routes events to per-type
    EventProcessor instances that buffer and publish via their sink threads.
    """

    def __init__(self, agent: Any):
        self.agent = agent
        self._processors: Dict[str, EventProcessor] = {}
        self._processors_lock = threading.Lock()

    # -------------------------------- Ingestion -------------------------------
    def add_event(self, event_type: str, event: Dict[str, Any]) -> None:
        if not config.ENABLE_GENAI_EVENTS:
            return
        # based on event_type, get the processor
        processor = self._processors.get(event_type)
        if not processor and event_type == GenAIEvent.EVENT_TYPE:
            with self._processors_lock:
                if event_type not in self._processors:
                    genai_event_config = GenAIEventConfig()
                    if not genai_event_config.register_url or not genai_event_config.publish_url or not genai_event_config.request_headers:
                        self.agent.logger.warning('Please configure event service url, account name, access key and other parameters properly')
                        return
                    self.agent.logger.info(f'Configuring processor for {event_type}')
                    processor = EventProcessor(self.agent, genai_event_config)
                    self._processors[event_type] = processor

        processor.add_event(event)

    # ------------------------------- Lifecycle --------------------------------
    def stop(self) -> None:
        for processor in self._processors.values():
            processor.stop()

