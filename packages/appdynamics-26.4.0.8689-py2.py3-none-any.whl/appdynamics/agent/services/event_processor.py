from __future__ import annotations

import threading
import queue
from dataclasses import dataclass
from typing import Any, Dict, Optional

from appdynamics.agent.core.logs import setup_logger
from appdynamics.agent.services.event_service_sink import EventServiceSink


@dataclass
class EventProcessorConfig:
    """
    Configuration for an EventProcessor and its sink thread behavior.
    """
    event_type: str
    publish_url: str
    register_url: str
    request_headers: Dict[str, str]
    max_queue_size: int
    chunk_size: int
    max_wait_seconds: int
    normal_pause_seconds: float
    long_pause_pause_seconds: int
    send_attempt_max: int
    schema_payload: Dict[str, Any]


class EventProcessor:
    """
    Per-event-type processor that buffers events into a bounded in-memory queue
    and signals its dedicated sink thread when batching conditions are met.

    On full queue, new incoming events are dropped and a warning is logged.
    """

    def __init__(self, agent: Any, config: EventProcessorConfig):
        self.agent = agent
        self.config = config

        self.event_queue = queue.Queue(maxsize=self.config.max_queue_size)
        self.signal = threading.Event()
        self.dropped_events_count = 0
        self.sink = EventServiceSink(
            agent=self.agent,
            event_type=self.config.event_type,
            config=self.config,
            signal=self.signal,
            event_queue=self.event_queue,
        )
        self.sink.daemon = True
        self.sink.start()

    def add_event(self, event: Dict[str, Any]) -> None:
        """
        Ingest one event. If queue is full, drop the offered event.
        Signal the sink if batching threshold is met.
        """
        try:
            self.event_queue.put_nowait(event)
        except queue.Full:
            self.dropped_events_count += 1
            self.agent.logger.debug(
                'Event queue full for %s. Dropped incoming event. dropped_total=%d',
                self.config.event_type,
                self.dropped_events_count)
            return
        # Signal when we have at least chunk_size events
        if self.event_queue.qsize() >= self.config.chunk_size:
            self.signal.set()

    def stop(self) -> None:
        if self.sink:
            self.sink.stop()
            self.signal.set()

