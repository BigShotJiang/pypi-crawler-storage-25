# Copyright (c) AppDynamics, Inc., and its affiliates
# 2015
# All Rights Reserved

"""Launch Splunk OpenTelemetry alongside AppDynamics when needed."""

from __future__ import unicode_literals
import contextvars
import os

try:
    from opentelemetry import trace
    from opentelemetry.sdk.trace import SpanProcessor as _SpanProcessorBase
    _has_otel = True
except ImportError:
    _SpanProcessorBase = object
    _has_otel = False

from appdynamics import config
from appdynamics.agent.core.logs import setup_logger


OTEL_LAUNCH_NOT_ATTEMPTED = 'not_attempted'
OTEL_LAUNCH_SUCCESS = 'success'
OTEL_LAUNCH_FAILED = 'failed'

# OTel environment variables populated from AppD config during migration.
OTEL_CFG_RESOURCE_ATTRIBUTES = 'OTEL_RESOURCE_ATTRIBUTES'
OTEL_CFG_SERVICE_NAME = 'OTEL_SERVICE_NAME'

_otel_launch_state = OTEL_LAUNCH_NOT_ATTEMPTED

# Pending AppD BT attributes for the current execution context.
# When AppD's start_transaction runs before the OTel span is created
# (AppD is outer wrapper), the BT info is stored here. A SpanProcessor
# then picks it up when the OTel span starts.
_pending_bt = contextvars.ContextVar('_pending_bt', default=None)  # type: contextvars.ContextVar[tuple | None]


def is_otel_launched():
    return _otel_launch_state == OTEL_LAUNCH_SUCCESS


def is_otel_launch_failed():
    return _otel_launch_state == OTEL_LAUNCH_FAILED


def _has_resource_attribute(key):
    attrs = os.environ.get(OTEL_CFG_RESOURCE_ATTRIBUTES)
    if not attrs:
        return False

    for item in attrs.split(','):
        item = item.strip()
        if not item:
            continue

        name, sep, _ = item.partition('=')
        if sep and name.strip() == key:
            return True

    return False


def _set_resource_attribute_if_missing(key, value):
    if not value or _has_resource_attribute(key):
        return

    entry = '{}={}'.format(key, value)
    attrs = os.environ.get(OTEL_CFG_RESOURCE_ATTRIBUTES)
    if attrs:
        os.environ[OTEL_CFG_RESOURCE_ATTRIBUTES] = '{},{}'.format(attrs, entry)
    else:
        os.environ[OTEL_CFG_RESOURCE_ATTRIBUTES] = entry


def _migrate_appd_config_to_otel_env():
    _set_resource_attribute_if_missing('service.namespace', config.AGENT_APPLICATION_NAME)

    if config.AGENT_TIER_NAME and not os.environ.get(OTEL_CFG_SERVICE_NAME):
        os.environ[OTEL_CFG_SERVICE_NAME] = config.AGENT_TIER_NAME

    _set_resource_attribute_if_missing('deployment.environment.name', config.AGENT_ACCOUNT_NAME)


def set_pending_bt_attributes(bt_name, tier_name, app_name):
    """Store BT attributes for the current execution context.

    Called from Agent._set_otel_bt_span_attributes when no OTel span is
    active yet (AppD wrapper is outer).  The _AppdBTSpanProcessor will
    apply them when the OTel span starts.
    """
    _pending_bt.set((bt_name, tier_name, app_name))


def clear_pending_bt_attributes():
    """Clear pending BT attributes for the current execution context."""
    _pending_bt.set(None)


def _get_and_clear_pending_bt():
    pending = _pending_bt.get()
    if pending is None:
        return None
    _pending_bt.set(None)
    return pending


_distro = None  # type: SplunkDistro | None


def _activate_auto_instrumentation(distro):
    # Import path changed between opentelemetry-instrumentation versions.
    try:
        from opentelemetry.instrumentation.auto_instrumentation import _load_instrumentors
    except ImportError:
        from opentelemetry.instrumentation.auto_instrumentation._load import _load_instrumentors

    _load_instrumentors(distro)


def launch_splunk_otel(activate_instrumentors=True):  # type: (...) -> bool
    """Launch Splunk OTel: configure provider and optionally activate auto-instrumentation.

    In dual mode, auto-instrumentation should be activated AFTER AppD interceptors
    are registered so that OTel wraps around AppD (outer wrapper), ensuring the
    OTel span exists when AppD's start_transaction sets span attributes.

    Parameters
    ----------
    activate_instrumentors : bool
        If True, activate OTel auto-instrumentation immediately.
        If False, only configure the TracerProvider; call
        activate_otel_instrumentors() separately afterward.
    """
    global _otel_launch_state, _distro

    if is_otel_launched():
        return True
    if is_otel_launch_failed():
        return False

    logger = setup_logger('appdynamics.agent')
    try:
        from splunk_otel.distro import SplunkDistro
        from splunk_otel.configurator import SplunkConfigurator
    except ImportError:
        _otel_launch_state = OTEL_LAUNCH_FAILED
        logger.error('Splunk OpenTelemetry is required for deployment mode %r. '
                     'Install it with: pip install splunk-opentelemetry',
                     config.AGENT_DEPLOYMENT_MODE)
        return False

    try:
        _migrate_appd_config_to_otel_env()
        distro = SplunkDistro()
        distro.configure()

        configurator = SplunkConfigurator()
        configurator.configure()

        _register_bt_span_processor(logger)

        if activate_instrumentors:
            _activate_instrumentors_safe(distro, logger)
        else:
            _distro = distro

        _otel_launch_state = OTEL_LAUNCH_SUCCESS
        return True
    except Exception:
        _otel_launch_state = OTEL_LAUNCH_FAILED
        logger.exception('Failed to launch Splunk OpenTelemetry Python agent.')
        return False


def activate_otel_instrumentors():
    """Activate OTel auto-instrumentation (deferred from launch_splunk_otel).

    Call this AFTER AppD interceptors are registered in dual mode so that
    OTel's framework wrappers are the outermost layer.
    """
    global _distro
    if _distro is None:
        return
    logger = setup_logger('appdynamics.agent')
    _activate_instrumentors_safe(_distro, logger)
    _distro = None


def _activate_instrumentors_safe(distro, logger):
    try:
        _activate_auto_instrumentation(distro)
    except ImportError:
        logger.warning('OpenTelemetry auto-instrumentation loader is not available; '
                       'continuing without zero-code framework instrumentation.')
    except Exception:
        logger.exception('Failed to activate OpenTelemetry auto-instrumentation; '
                         'continuing without zero-code framework instrumentation.')


class _AppdBTSpanProcessor(_SpanProcessorBase):
    """SpanProcessor that injects AppD BT attributes into OTel spans.

    Handles the case where AppD is the outer wrapper — the OTel span does
    not yet exist when AppD's ``start_transaction`` runs.  The BT info is
    stored via ``set_pending_bt_attributes`` and this processor applies it
    when the OTel span starts.
    """

    def __init__(self, logger):
        self._logger = logger

    def on_start(self, span, parent_context=None):
        self._logger.debug('_AppdBTSpanProcessor.on_start called for span: %s', span.name)
        pending = _get_and_clear_pending_bt()
        if pending is not None:
            bt_name, tier_name, app_name = pending
            self._logger.debug('Applying pending AppD BT attributes to OTel span: bt_name=%s', bt_name)
            span.set_attribute('appd.bt.name', bt_name)
            if tier_name:
                span.set_attribute('appd.tier.name', tier_name)
            if app_name:
                span.set_attribute('appd.app.name', app_name)

    def on_end(self, span):
        pass

    def shutdown(self):
        pass

    def force_flush(self, timeout_millis=None):
        return True


def _register_bt_span_processor(logger):
    """Register _AppdBTSpanProcessor on the active TracerProvider."""
    if not _has_otel:
        return
    try:
        provider = trace.get_tracer_provider()
        if hasattr(provider, 'add_span_processor'):
            provider.add_span_processor(_AppdBTSpanProcessor(logger))
            logger.debug('Registered AppD BT span processor for dual-mode attribute injection.')
        else:
            logger.debug('TracerProvider does not support add_span_processor; '
                         'AppD BT attributes may not appear on OTel spans.')
    except Exception:
        logger.debug('Failed to register AppD BT span processor.')
