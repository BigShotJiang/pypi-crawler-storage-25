from __future__ import annotations

from appdynamics import config

import time
from typing import Any, Dict, List, Optional, Union
from uuid import UUID
from dataclasses import dataclass
from appdynamics.agent.interceptor.utils.genai_utils import GenaiConstants
from appdynamics.agent.interceptor.utils import genai_utils
from appdynamics.agent.interceptor.base import BaseInterceptor


# LangChain imports
try:
    from langchain_core.callbacks import BaseCallbackHandler  # type: ignore
except Exception:
    BaseCallbackHandler = None


def _now_ms() -> int:
    return int(time.time() * 1000)


@dataclass
class _LLMRunState:
    """State tracked for a single LLM run, keyed by run_id."""
    start_time_ms: int
    llm_class: Optional[str] = None
    model_name: Optional[str] = None
    is_chat: bool = False
    is_stream: bool = False
    time_to_first_token_ms: Optional[int] = None


def _get_vendor_rules() -> List[Dict[str, Any]]:
    """Lightweight vendor detection rules.

    Each rule contains a canonical vendor name and a list of substrings which,
    if present in class/model/params, indicate that vendor.
    """
    return [
        {"name": "Azure OpenAI", "keys": ["azureopenai", "azure-openai", "azure_openai"]},
        {"name": "OpenAI", "keys": ["openai", "gpt-", "o1-", "o3-"]},
        {"name": "Anthropic", "keys": ["anthropic", "claude"]},
        {"name": "Ollama", "keys": ["ollama"]},
        {"name": "Bedrock", "keys": ["bedrock", "amazonbedrock", "awsbedrock"]},
        {"name": "Cohere", "keys": ["cohere"]},
        {"name": "Mistral", "keys": ["mistral"]},
        {"name": "HuggingFace", "keys": ["huggingface", "transformers", "hf-"]},
        {"name": "Google", "keys": ["vertexai", "google", "gemini", "palm", "generativeai"]},
    ]


def _detect_vendor_from_strings(values: List[str]) -> Optional[str]:
    values_l = [v.lower() for v in values if isinstance(v, str)]
    if not values_l:
        return None
    for rule in _get_vendor_rules():
        for key in rule["keys"]:
            if any(key in v for v in values_l):
                return rule["name"]
    return None


if BaseCallbackHandler is not None:  # Guard for missing LangChain dependency

    class _AppDynamicsLangchainCallbackHandler(BaseCallbackHandler):
        """Lightweight handler that emits an LLM event per LangChain LLM call."""

        def __init__(self, agent):
            super().__init__()
            self._agent = agent
            self._run_states: Dict[UUID, _LLMRunState] = {}

        def _get_active_bt(self):
            try:
                return self._agent.get_current_bt()
            except Exception:
                return None

        def _get_state(self, run_id: UUID) -> Optional[_LLMRunState]:
            """Retrieve state for a given run_id."""
            return self._run_states.get(run_id)

        def _pop_state(self, run_id: UUID) -> Optional[_LLMRunState]:
            return self._run_states.pop(run_id, None)

        def _compute_latency_ms(self, state: _LLMRunState) -> int:
            return _now_ms() - state.start_time_ms

        def check_duplicate_instrumentation(self, llm_class="", vendor="") -> bool:
            """Check if the LLM class is already instrumented."""
            if vendor is None:
                vendor = _detect_vendor_from_strings([
                    llm_class
                ]) or ""
            if vendor in ["OpenAI", "Azure OpenAI"] and config.ENABLE_OPENAI: # check for openai/azureopenai client instrumentation
                self._agent.logger.debug("[AppD LangChain] OpenAI or Azure OpenAI client instrumentation is enabled; skipping event reporting in langchainllm.py")
                return True
            return False

        def _emit_llm_event(
            self, 
            state: _LLMRunState, 
            bt, 
            err_detail: Optional[str], 
            latency_ms: int, 
            reporting_values: Dict[str, Any],
            time_to_first_token_ms: Optional[int] = None,
            time_per_output_token_ms: Optional[int] = None
        ):
            model_name = state.model_name or state.llm_class or "unknown"
            vendor = _detect_vendor_from_strings([
                state.llm_class,
                state.model_name or "",
            ]) or "LangChain"
            if self.check_duplicate_instrumentation(None, vendor):
                return
            operation_name = GenaiConstants.GENAI_CHAT_OPERATION if state.is_chat else GenaiConstants.GENAI_TEXT_OPERATION
            genai_utils.emit_llm_event(
                agent=self._agent,
                bt=bt,
                err_detail=err_detail,
                gen_ai_system=vendor,
                gen_ai_operation_name=operation_name,
                model=model_name,
                reporting_values=reporting_values,
                latency_ms=latency_ms,
                time_to_first_token_ms=time_to_first_token_ms,
                time_per_output_token_ms=time_per_output_token_ms,
                streaming=state.is_stream,
                event_start_time=state.start_time_ms / 1000
            )

        def on_chat_model_start(
            self,
            serialized: Dict[str, Any],
            messages: List[Any],
            *,
            run_id: UUID,
            tags: Optional[List[str]] = None,
            parent_run_id: Optional[UUID] = None,
            metadata: Optional[Dict[str, Any]] = None,
            **kwargs: Any,
        ) -> Any:
            """Initialize timing/context for ChatModel runs (parity with on_llm_start)."""
            llm_class = serialized.get("name") if isinstance(serialized, dict) else str(serialized)
            if self.check_duplicate_instrumentation(llm_class, None):
                return
            invocation_params = kwargs.get("invocation_params") or {}
            options = kwargs.get("options") or {}
            model_name = (
                kwargs.get("model")
                or kwargs.get("model_name")
                or (metadata.get("ls_model_name") if metadata else None)
                or invocation_params.get("model")
                or invocation_params.get("model_name")
                or options.get("model")
                or options.get("model_name")
            )
            is_stream = bool(
                kwargs.get("stream")
                or invocation_params.get("stream")
                or options.get("stream")
            )
            
            # Store state keyed by run_id
            self._run_states[run_id] = _LLMRunState(
                start_time_ms=_now_ms(),
                llm_class=llm_class,
                model_name=model_name,
                is_chat=True,
                is_stream=is_stream
            )

        def on_llm_start(
            self,
            serialized: Dict[str, Any],
            prompts: List[str],
            *,
            run_id: UUID,
            tags: Optional[List[str]] = None,
            parent_run_id: Optional[UUID] = None,
            metadata: Optional[Dict[str, Any]] = None,
            **kwargs: Any,
        ) -> None:
            """Mark start of an LLM call and stash context for event creation.
            """
            llm_class = serialized.get("name") if isinstance(serialized, dict) else str(serialized)
            if self.check_duplicate_instrumentation(llm_class, None):
                return
            invocation_params = kwargs.get("invocation_params") or {}
            options = kwargs.get("options") or {}
            model_name = (
                kwargs.get("model")
                or kwargs.get("model_name")
                or (metadata.get("ls_model_name") if metadata else None)
                or invocation_params.get("model")
                or invocation_params.get("model_name")
                or options.get("model")
                or options.get("model_name")
            )
            is_stream = bool(
                kwargs.get("stream")
                or invocation_params.get("stream")
                or options.get("stream")
                or False
            )
            
            # Store state keyed by run_id
            llm_class = serialized.get("name") if isinstance(serialized, dict) else str(serialized)
            self._run_states[run_id] = _LLMRunState(
                start_time_ms=_now_ms(),
                llm_class=llm_class,
                model_name=model_name,
                is_chat=False,  # Explicitly mark non-chat path
                is_stream=is_stream
            )

        def on_llm_end(
            self,
            response: Any,
            *,
            run_id: UUID,
            parent_run_id: Union[UUID, None] = None,
            **kwargs: Any,
        ) -> None:  # type: ignore[override]
            """Compute metrics and emit a successful LLM event."""
            state = self._pop_state(run_id)
            if state is None:
                self._agent.logger.debug("[AppD LangChain] on_llm_end: No state found; skipping event")
                return

            bt = self._get_active_bt()
            latency_ms = self._compute_latency_ms(state)

            llm_output = getattr(response, "llm_output", {}) or {}
            token_usage = llm_output.get("token_usage") or llm_output.get("usage")
            if token_usage is None: # for ollama, bedrock get token usage from generation info
                token_usage, updated_model_name = genai_utils.derive_token_usage_from_generation_info(
                    llm_result=response, existing_model_name=state.model_name
                )
                if updated_model_name and not state.model_name:
                    state.model_name = updated_model_name

            reporting_values: Dict[str, Any] = {}
            if token_usage is not None:
                prompt_tokens = (
                    token_usage.get("prompt_tokens")
                    or token_usage.get("input_token_count")
                    or token_usage.get("input_tokens")
                    or 0
                )
                completion_tokens = (
                    token_usage.get("completion_tokens")
                    or token_usage.get("generated_token_count")
                    or token_usage.get("output_tokens")
                    or 0
                )
                total_tokens = token_usage.get("total_tokens")
                if total_tokens is None:
                    total_tokens = prompt_tokens + completion_tokens

                reporting_values[GenaiConstants.INPUT_TOKENS_METRIC_NAME] = prompt_tokens
                reporting_values[GenaiConstants.COMPLETION_TOKENS_METRIC_NAME] = completion_tokens
                reporting_values[GenaiConstants.TOKENS_METRIC_NAME] = total_tokens

            # Calculate time_per_output_token for streaming responses
            time_per_output_token_ms = None
            completion_tokens = reporting_values.get(GenaiConstants.COMPLETION_TOKENS_METRIC_NAME, 0)
            if state.is_stream and state.time_to_first_token_ms is not None and completion_tokens > 0:
                time_per_output_token_ms = round((latency_ms - state.time_to_first_token_ms) / completion_tokens)

            self._emit_llm_event(
                state, 
                bt, 
                err_detail=None, 
                latency_ms=latency_ms, 
                reporting_values=reporting_values,
                time_to_first_token_ms=state.time_to_first_token_ms,
                time_per_output_token_ms=time_per_output_token_ms
            )

        def on_llm_new_token(
            self,
            token: str,
            *,
            chunk: Any,
            run_id: UUID,
            parent_run_id: Optional[UUID] = None,
            tags: Optional[List[str]] = None,
            **kwargs: Any,
        ) -> None:
            """Handle streaming tokens. Mark the run as streaming and track time to first token."""
            state = self._get_state(run_id)
            if state is None:
                self._agent.logger.debug("[AppD LangChain] on_llm_new_token: No state found for run_id=%s", run_id)
                return
            if state.is_stream:
                return
            # Mark as streaming
            state.is_stream = True
            
            # Set time to first token if this is the first token
            if state.time_to_first_token_ms is None:
                state.time_to_first_token_ms = _now_ms() - state.start_time_ms

        def on_llm_error(
            self,
            error: Exception,
            *,
            run_id: UUID,
            parent_run_id: Union[UUID, None] = None,
            **kwargs: Any,
        ) -> None:
            """Emit a failed LLM event with error details and latency"""
            state = self._pop_state(run_id)
            if state is None:
                self._agent.logger.debug("[AppD LangChain] on_llm_error: No state found; skipping event")
                return

            latency_ms = self._compute_latency_ms(state)
            bt = self._get_active_bt()
            self._emit_llm_event(state, bt, err_detail=str(error), latency_ms=latency_ms, reporting_values={})


class LangchainCallbackManagerInitInterceptor(BaseInterceptor):

    def ___init__(self, __init__, cls_inst, *args, **kwargs):
        __init__(cls_inst, *args, **kwargs)
        # Ensure our callback is present if not already.
        for handler in cls_inst.inheritable_handlers:
            if isinstance(handler, _AppDynamicsLangchainCallbackHandler):
                break
        else:
            cls_inst.add_handler(_AppDynamicsLangchainCallbackHandler(self.agent), inherit=True)


def intercept_langchain_llm_callbacks(agent, mod=None):
    """Intercept BaseCallbackManager init"""
    LangchainCallbackManagerInitInterceptor(agent, mod.BaseCallbackManager).attach('__init__')
