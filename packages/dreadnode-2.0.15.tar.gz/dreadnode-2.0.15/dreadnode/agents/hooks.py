"""Optional agent hooks: tool metrics and conversation summarization.

These hooks are opt-in — users register them explicitly on an ``Agent`` via
the ``hooks=`` constructor argument. Transient-error backoff is handled inline
by the agent loop (see ``Agent._try_backoff``) and is not a hook.
"""

import contextlib
import typing as t
from dataclasses import dataclass

from dreadnode.agents.events import (
    AgentEvent,
    AgentStep,
    ToolEnd,
    ToolStart,
)
from dreadnode.agents.reactions import Reaction, Retry
from dreadnode.core.hook import Hook, hook
from dreadnode.generators.generator import Generator
from dreadnode.generators.message import Message, make_compaction_message

if t.TYPE_CHECKING:
    from datetime import datetime


# =============================================================================
# Tool Metrics
# =============================================================================


def tool_metrics(*, detailed: bool = False) -> Hook:
    """
    Creates an agent hook to log metrics about tool usage, execution time, and success rates.

    Args:
        detailed: If True, logs metrics for each specific tool in addition to general stats.
                  If False, only logs aggregate statistics across all tools.

    Returns:
        A Hook instance that can be registered with an agent.
    """
    _start_times: dict[str, datetime] = {}

    @hook(AgentEvent)
    async def tool_metrics(event: AgentEvent) -> None:
        from dreadnode import log_metric

        if isinstance(event, ToolStart):
            log_metric("tool/total_count", 1)
            _start_times[event.tool_call.id] = event.timestamp

            if detailed:
                tool_name = event.tool_call.name
                log_metric(f"tool/count.{tool_name}", 1)

        elif isinstance(event, ToolEnd):
            tool_name = event.tool_call.name
            start_time = _start_times.pop(event.tool_call.id, event.timestamp)
            duration_seconds = (event.timestamp - start_time).total_seconds()

            log_metric("tool/total_time", duration_seconds)
            log_metric("tool/success_rate", 1)

            if detailed:
                log_metric(f"tool/time.{tool_name}", duration_seconds)
                log_metric(f"tool/avg_time.{tool_name}", duration_seconds)
                log_metric(f"tool/success_rate.{tool_name}", 1)

    return tool_metrics


# =============================================================================
# Summarization
# =============================================================================

CONTEXT_LENGTH_ERROR_PATTERNS = [
    "context_length_exceeded",
    "context window",
    "token limit",
    "maximum context length",
    "is too long",
    "chunk too big",
    "prompt is too long",
    "too many tokens",
]


@dataclass
class Summary:
    analysis: str
    summary: str


_SUMMARIZATION_SYSTEM_PROMPT = """\
Your task is to create a detailed summary of the conversation so far, paying close attention to the user's explicit requests and your previous actions.
This summary should be thorough in capturing technical details, code patterns, and architectural decisions that would be essential for continuing development work without losing context.

Before providing your final summary, wrap your analysis in <analysis> tags to organize your thoughts and ensure you've covered all necessary points. In your analysis process:

1. Chronologically analyze each message and section of the conversation. For each section thoroughly identify:
- The user's explicit requests and intents
- Your approach to addressing the user's requests
- Key decisions, technical concepts and code patterns
- Specific technical details like paths, usernames, structured objects, and code
- Tool interactions performed with a specific focus on intent and outcome
- Errors that you ran into and how you fixed them
- Pay special attention to specific user feedback that you received, especially if the user told you to do something differently.

2. Double-check for technical accuracy and completeness, addressing each required element thoroughly.

Your summary should include the following sections:

1. Primary Request and Intent: Capture all of the user's explicit requests and intents in detail
2. Key Technical Concepts: List all important technical concepts, technologies, and frameworks discussed.
3. Files and Code Sections: Enumerate specific files and code sections examined, modified, or created. Pay special attention to the most recent messages and include full code snippets where applicable and include a summary of why this file read or edit is important.
4. Errors and fixes: List all errors that you ran into, and how you fixed them. Pay special attention to specific user feedback that you received, especially if the user told you to do something differently.
5. Problem Solving: Document problems solved and any ongoing troubleshooting efforts.
6. All user messages: List ALL user messages that are not tool results. These are critical for understanding the users' feedback and changing intent.
7. Pending Tasks: Outline any pending tasks that you have explicitly been asked to work on.
8. Current Work: Describe in detail precisely what was being worked on immediately before this summary request, paying special attention to the most recent messages from both user and assistant. Include file names and code snippets where applicable.
9. Optional Next Step: List the next step that you will take that is related to the most recent work you were doing. IMPORTANT: ensure that this step is DIRECTLY in line with the user's explicit requests, and the task you were working on immediately before this summary request. If your last task was concluded, then only list next steps if they are explicitly in line with the users request. Do not start on tangential requests without confirming with the user first.
If there is a next step, include direct quotes from the most recent conversation showing exactly what task you were working on and where you left off. This should be verbatim to ensure there's no drift in task interpretation.
"""

_SUMMARIZATION_USER_TEMPLATE = """\
Please provide your summary based on the conversation below, following the system instructions and ensuring precision and thoroughness in your response.

{guidance_section}<conversation>
{conversation}
</conversation>"""


async def summarize_conversation(
    generator: "str | Generator",
    conversation: str,
    *,
    guidance: str = "",
) -> Summary:
    """Run the summarization prompt against the given generator and return a Summary."""
    import re

    from dreadnode.generators.generator import GenerateParams
    from dreadnode.generators.generator import get_generator as _get_generator

    if isinstance(generator, str):
        generator = _get_generator(generator)

    guidance_section = ""
    if guidance:
        guidance_section = f"Additional summarization guidance:\n{guidance}\n\n"

    messages = [
        Message(role="system", content=_SUMMARIZATION_SYSTEM_PROMPT),
        Message(
            role="user",
            content=_SUMMARIZATION_USER_TEMPLATE.format(
                guidance_section=guidance_section,
                conversation=conversation,
            ),
        ),
    ]

    results = await generator.generate_messages(
        [messages],
        [generator.params or GenerateParams()],
    )

    result = results[0]
    if isinstance(result, BaseException):
        raise result

    response_text = result.message.content

    analysis = ""
    summary_text = response_text
    analysis_match = re.search(r"<analysis>(.*?)</analysis>", response_text, re.DOTALL)
    if analysis_match:
        analysis = analysis_match.group(1).strip()
    summary_match = re.search(r"<summary>(.*?)</summary>", response_text, re.DOTALL)
    if summary_match:
        summary_text = summary_match.group(1).strip()

    return Summary(analysis=analysis, summary=summary_text)


def _is_context_length_error(error: BaseException) -> bool:
    """Checks if an exception is likely due to exceeding the context window."""
    with contextlib.suppress(ImportError):
        from litellm.exceptions import ContextWindowExceededError

        if isinstance(error, ContextWindowExceededError):
            return True

    error_str = str(error).lower()
    return any(pattern in error_str for pattern in CONTEXT_LENGTH_ERROR_PATTERNS)


def _describe_generation_error(error: BaseException) -> dict[str, t.Any]:
    """Best-effort structured dump of a generation error for diagnostic logs.

    Returns a dict of litellm-known attributes when present. Never raises:
    attribute access that fails is silently omitted, so callers can log the
    result safely even for hostile or malformed exception objects.

    Intended for one-per-failure diagnostic logging at the generation error
    site. Presence flags are included for fields whose *content* is not
    itself safe to log (raw bodies may be arbitrary length); they tell a
    future debugger whether structured data exists to look at without
    dumping it into every log line.
    """
    fields: dict[str, t.Any] = {"type": type(error).__name__}

    with contextlib.suppress(Exception):
        msg = str(error)
        if msg:
            fields["message"] = msg if len(msg) <= 500 else msg[:500] + "...<truncated>"

    for attr in ("status_code", "llm_provider", "model", "request_id"):
        with contextlib.suppress(Exception):
            val = getattr(error, attr, None)
            if val is not None:
                fields[attr] = val

    with contextlib.suppress(Exception):
        fields["has_body"] = bool(getattr(error, "body", None))

    with contextlib.suppress(Exception):
        resp = getattr(error, "response", None)
        if resp is not None:
            text = getattr(resp, "text", "") or ""
            fields["has_response_text"] = bool(text)

    return fields


def find_summarization_boundary(
    messages: list[Message],
    min_messages_to_keep: int = 10,
    max_summarize_chars: int | None = None,
) -> int:
    """Find a clean message boundary for summarization.

    Walks messages from the start and enumerates every safe split point that
    leaves at least ``min_messages_to_keep`` messages in the "keep" portion.
    A boundary is safe when both sides of the cut are API-valid chat
    sequences — no orphaned ``tool_calls`` and no orphaned ``tool`` responses.
    Two kinds of positions qualify:

    - **After a simple assistant message** (no ``tool_calls``) — the natural
      end of a complete conversational turn.
    - **After a complete tool-call group** — every ``tool_call.id`` from a
      preceding ``assistant`` message has a matching ``tool`` response. The
      cut falls after the last matching tool response, so neither side has a
      dangling tool call or result.

    When ``max_summarize_chars`` is provided, returns the largest safe split
    whose cumulative ``len(str(message))`` stays within the cap. This keeps
    the summarizer call from overflowing the same provider context that
    triggered recovery. ``str(message)`` is exactly what the summarizer
    receives (see ``Agent._try_overflow_recovery``) so the cap and the actual
    serialized input measure the same string — including elision of image
    URLs (``ContentImageUrl.__str__``) and tool-call arguments
    (``ToolCall.__str__``).

    Returns:
        Index splitting ``messages[:boundary]`` (to summarize) from
        ``messages[boundary:]`` (to keep).  Returns ``0`` when no valid
        boundary exists.
    """
    # Enumerate every safe boundary with its cumulative serialized char count.
    # (0, 0) is always a valid "no compaction" candidate.
    candidates: list[tuple[int, int]] = [(0, 0)]
    running_chars = 0
    # Tool-call ids from the most recent assistant(tool_calls) that have not
    # yet been resolved by matching tool responses. When empty, the preceding
    # tool-call group is complete and the position is API-safe to cut at.
    pending_tool_ids: set[str] = set()
    for i, message in enumerate(messages):
        if len(messages) - i <= min_messages_to_keep:
            break
        running_chars += len(str(message))
        if message.role == "assistant":
            tool_calls = getattr(message, "tool_calls", None)
            if tool_calls:
                pending_tool_ids = {tc.id for tc in tool_calls}
            elif not pending_tool_ids:
                candidates.append((i + 1, running_chars))
        elif (
            message.role == "tool"
            and getattr(message, "tool_call_id", None)
            and message.tool_call_id in pending_tool_ids
        ):
            pending_tool_ids.discard(message.tool_call_id)
            if not pending_tool_ids:
                candidates.append((i + 1, running_chars))

    if max_summarize_chars is None:
        return candidates[-1][0]

    # Cumulative sizes are monotonic in boundary order, so the largest
    # boundary whose size fits the cap is the best match. Walk candidates
    # from latest to earliest and return the first that fits.
    for boundary, size in reversed(candidates):
        if size <= max_summarize_chars:
            return boundary
    return 0


def _get_model_context_budget(model_or_generator: "str | Generator | None") -> int:
    """Usable token budget for automatic compaction threshold.

    Returns 75% of the model's max input tokens when known via LiteLLM
    metadata, otherwise a conservative 100_000 fallback.
    """
    model_str = model_or_generator
    if hasattr(model_or_generator, "model"):
        model_str = model_or_generator.model
    if not isinstance(model_str, str):
        return 100_000
    try:
        import litellm

        lookup = model_str
        while lookup not in litellm.model_cost:
            if "/" not in lookup:
                break
            lookup = "/".join(lookup.split("/")[1:])
        if lookup in litellm.model_cost:
            info = litellm.model_cost[lookup]
            max_input = info.get("max_input_tokens") or info.get("max_tokens", 0)
            if max_input and max_input > 0:
                return int(max_input * 0.75)
    except Exception:  # noqa: S110 - best-effort model metadata fallback should stay quiet
        pass
    return 100_000


def _make_summarize_hook(
    model: str | Generator | None = None,
    max_tokens: int = 100_000,
    min_messages_to_keep: int = 10,
    guidance: str = "",
) -> "Hook":
    """Create a hook that auto-summarizes when context gets too long."""
    if min_messages_to_keep < 2:
        raise ValueError("min_messages_to_keep must be at least 2.")

    @hook(AgentEvent)  # Decorator on the INNER function, not the factory
    async def _summarize_hook(event: AgentEvent) -> Reaction | None:
        # Threshold compaction only — overflow recovery is agent-owned
        # (handled by Agent._try_overflow_recovery at the error site).
        if not isinstance(event, AgentStep):
            return None

        budget = _get_model_context_budget(event.generator) if event.generator else max_tokens
        if event.usage.total_tokens <= 0 or event.usage.total_tokens <= budget:
            return None

        summarizer_model = model or event.generator
        if summarizer_model is None:
            return None

        event_messages = getattr(event, "messages", None)
        if not event_messages:
            return None

        messages = list(event_messages)
        if len(messages) <= min_messages_to_keep:
            return None

        system_message: Message | None = (
            messages.pop(0) if messages and messages[0].role == "system" else None
        )

        best_boundary = find_summarization_boundary(messages, min_messages_to_keep)
        if best_boundary == 0:
            return None

        to_summarize = messages[:best_boundary]
        to_keep = messages[best_boundary:]
        if not to_summarize:
            return None

        summary = await summarize_conversation(
            summarizer_model,
            "\n".join(str(msg) for msg in to_summarize),
            guidance=guidance,
        )

        new_messages: list[Message] = []
        if system_message:
            new_messages.append(system_message)
        new_messages.append(
            make_compaction_message(
                summary.summary,
                messages_compacted=len(to_summarize),
                trigger="threshold",
            )
        )
        new_messages.extend(to_keep)

        # Always Retry — replaces messages rather than extending them.
        # Continue would append new_messages to the existing list (agent.py),
        # leaving the old messages in place. Retry replaces them.
        return Retry(messages=new_messages)

    return _summarize_hook


# Pre-instantiated with defaults -- this is what the wrapper discovers
summarize_when_long = _make_summarize_hook()
