<!-- AUTO-GENERATED — do not hand-edit. -->
<!-- source: packages/docs/src/content/docs/cli/optimize.mdx -->
<!-- public: https://docs.dreadnode.io/cli/optimize/ -->
<!-- bundle: dreadnode-cli.json (regenerate via `just docs sync` or pre-commit) -->

# Optimization

> Submit and manage agent optimization jobs.

Terminal window

```
$ dn optimize <command>
```

Optimize agents with jobs.

Shared options

Commands that hit the platform or a runtime server accept these flags:

* `--profile`, `--server`, `--api-key`, `--organization`, `--workspace`, `--project` — authenticate and scope against a Dreadnode platform. See [Authentication](../getting-started/authentication.md).

## submit

Terminal window

```
$ dn optimize submit <--model> <str> <--capability> <str> <--dataset> <str> <--reward-recipe> <literal[contains_v1,> <exact_match_v1,> <row_reward_v1,> <trajectory_imitation_v1]>
```

Submit a hosted optimization job.

**Options**

* `--model` *(**Required**)* — Model identifier
* `--capability` *(**Required**)* — Capability ref in NAME\@VERSION form
* `--dataset` *(**Required**)* — Training dataset ref in NAME\@VERSION form
* `--reward-recipe` — Hosted reward recipe name **\[required]** *\[choices: contains\_v1, exact\_match\_v1, row\_reward\_v1, trajectory\_imitation\_v1]*
* `--val-dataset` — Optional validation dataset ref in NAME\@VERSION form
* `--reward-params` — Reward recipe parameters as JSON
* `--agent-name` — Optional agent name when the capability exports multiple agents
* `--objective` — Optional natural-language optimization objective
* `--name` — Optional optimization job name
* `--run-ref` — Run reference for tracking
* `--tag` — Tag for the job (repeatable)
* `--seed` — Random seed for reproducibility
* `--max-metric-calls` — Maximum metric evaluation calls
* `--max-trials` — Maximum optimization trials before stopping
* `--max-trials-without-improvement` — Stop after this many finished trials without improving the best score
* `--max-runtime-sec` — Maximum hosted runtime seconds before the job is timed out
* `--reflection-lm` — Language model for reflection steps
* `--max-reflection-examples` — Maximum examples for reflection
* `--max-side-info-chars` — Maximum characters of side information
* `--track-best-outputs` *(default `False`)*
* `--display-progress-bar` *(default `False`)*
* `--capture-traces`, `--no-capture-traces` *(default `True`)*
* `--include-outputs`, `--no-include-outputs` *(default `True`)*
* `--include-errors`, `--no-include-errors` *(default `True`)*
* `--wait` *(default `False`)*
* `--poll-interval-sec` *(default `5.0`)* — Polling interval in seconds
* `--timeout-sec` — Timeout in seconds for waiting
* `--json` *(default `False`)*

## list

Terminal window

```
$ dn optimize list
```

List hosted optimization jobs.

**Options**

* `--page` *(default `1`)*
* `--page-size` *(default `20`)*
* `--status` — *\[choices: queued, running, completed, failed, cancelled]*
* `--backend` — *\[choices: gepa]*
* `--target-kind` — *\[choices: capability\_agent]*
* `--json` *(default `False`)*

## get

Terminal window

```
$ dn optimize get <job-id>
```

Get a hosted optimization job.

**Options**

* `<job-id>`, `--job-id` *(**Required**)*
* `--json` *(default `False`)*

## wait

Terminal window

```
$ dn optimize wait <job-id>
```

Wait for a hosted optimization job to reach a terminal state.

**Options**

* `<job-id>`, `--job-id` *(**Required**)*
* `--poll-interval-sec` *(default `5.0`)* — Polling interval in seconds
* `--timeout-sec` — Timeout in seconds for waiting
* `--json` *(default `False`)*

## logs

Terminal window

```
$ dn optimize logs <job-id>
```

Show hosted optimization logs.

**Options**

* `<job-id>`, `--job-id` *(**Required**)*
* `--json` *(default `False`)*

## artifacts

Terminal window

```
$ dn optimize artifacts <job-id>
```

Show hosted optimization artifacts.

**Options**

* `<job-id>`, `--job-id` *(**Required**)*
* `--json` *(default `False`)*

## cancel

Terminal window

```
$ dn optimize cancel <job-id>
```

Cancel a hosted optimization job.

**Options**

* `<job-id>`, `--job-id` *(**Required**)*
* `--json` *(default `False`)*

## retry

Terminal window

```
$ dn optimize retry <job-id>
```

Retry a terminal hosted optimization job.

**Options**

* `<job-id>`, `--job-id` *(**Required**)*
* `--json` *(default `False`)*
