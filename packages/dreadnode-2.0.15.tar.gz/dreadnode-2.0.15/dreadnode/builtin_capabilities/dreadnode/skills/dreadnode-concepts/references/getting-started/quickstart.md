<!-- AUTO-GENERATED — do not hand-edit. -->
<!-- source: packages/docs/src/content/docs/getting-started/quickstart.mdx -->
<!-- public: https://docs.dreadnode.io/getting-started/quickstart/ -->
<!-- bundle: dreadnode-concepts.json (regenerate via `just docs sync` or pre-commit) -->

# Quickstart

> Start in the Dreadnode TUI and run your first offensive security or AI red team workflow in minutes.

## Step 1: Install Dreadnode

Terminal window

```
curl -fsSL https://dreadnode.io/install.sh | bash
```

Verify the install:

Terminal window

```
dreadnode --help
```

Note

If `dreadnode` is not resolving, your shell may not have picked up the installer’s bin directory yet. Run `which dreadnode` and `echo "$PATH"`, then open a new terminal and try again.

## Step 2: Launch the TUI

Terminal window

```
cd your-project
dreadnode
```

Tip

`dn` is installed as an alias for `dreadnode` — both run the same binary. The rest of these docs use `dn`.

On first launch, Dreadnode opens the TUI and prompts you to create an account or log in before creating your first session.

## Step 3: Sign in

Create a Dreadnode account or paste an existing API key. New accounts come with starter credits.

The first screen lets you choose between two login methods:

* **Browser login** — the fastest path for most users.
* **API key** — useful when you already have a Dreadnode key.

After login, you land on the welcome screen with the composer focused and your first session ready.

## Step 4: Ask your first question

Type directly into the composer and press `Enter`:

```
what does this target do and where should I start testing?
```

Other good first prompts:

```
what attack surface do you see in this codebase?
```

```
where is the main entry point and auth flow?
```

```
explain the folder structure from an offsec perspective
```

The TUI ships with a default tool set — file access, shell execution, and a built-in web research loop (`web_search`, `web_extract`, `fetch`) — so first prompts work without installing anything. See [Default tools](https://docs.dreadnode.io/tui/default-tools/) for the full list.

## Step 5: Add capabilities

Press `Ctrl+P` to browse capabilities.

Use `Tab` to switch between the **Available** registry and your **Installed** list, `Space` to toggle install, and `Enter` to read the details for the highlighted capability. Capabilities bundle specialised agents, tools, skills, MCP servers, and workers for AI red teaming, pentesting, and security testing.

Once a capability is installed, use `Ctrl+A` or `/agent <name>` to start a session with one of its agents.

## Step 6: Revisit sessions

Press `Ctrl+B` any time to open the session browser.

From there you can:

* jump back into an older conversation
* search sessions by preview text or id
* start a fresh session with `n`
* delete a session with `d`

## Provider keys and BYOK models

If you want to use provider-hosted models directly, set the provider environment variable before launching the TUI.

Terminal window

```
export ANTHROPIC_API_KEY="sk-ant-..."
export OPENAI_API_KEY="sk-..."
```

Inside the TUI, run `/secrets` to inspect configured secrets and provider presets.

## What’s next

* Press `?` inside the TUI for live keybindings and slash-command help
* Go deeper on login, profiles, and provider setup in [Authentication](./authentication.md)
* Install capabilities for extra agents, tools, and skills in [Installing capabilities](../capabilities/installing.md)
* Inspect workspace runtime records in [Managing runtimes](../runtimes/managing.md)
