<!-- AUTO-GENERATED — do not hand-edit. -->
<!-- source: packages/docs/src/content/docs/getting-started/overview.mdx -->
<!-- public: https://docs.dreadnode.io/getting-started/overview/ -->
<!-- bundle: dreadnode-concepts.json (regenerate via `just docs sync` or pre-commit) -->

# Overview

> Dreadnode is a terminal-native platform for building, evaluating, and deploying offensive security agents.

Dreadnode is a terminal-native platform for building, evaluating, and deploying offensive security agents. You install one binary, drop into a TUI in any project, and drive the whole workflow — prototyping agents, running evaluations, inspecting traces — from your terminal or the web.

## Start here

* **[Quickstart](./quickstart.md)** — install, launch the TUI, and run your first session.
* **[Authentication](./authentication.md)** — profiles, workspaces, and BYOK provider keys.
* **[Installing capabilities](../capabilities/installing.md)** — add agents, tools, skills, and MCP servers to the TUI.
* **[Self-hosting](https://docs.dreadnode.io/self-hosting/)** — deploy the platform on your own Kubernetes cluster.

## What the TUI gives you on day one

A fresh TUI session has everything needed for a useful first conversation. You can ask it to map an unfamiliar target, draft a test plan, or run a tool call against a local codebase without installing anything.

* **[Default tools](https://docs.dreadnode.io/tui/default-tools/)** — file read, shell, web search, multi-page extraction, direct fetch, and the rest of the standard pool.
* **[Capabilities](../capabilities/overview.md)** — bundles of agents, tools, skills, and MCP servers that specialise the TUI for AI red teaming, pentesting, or vuln research.
* **[Chat models](../platform/chat-models.md)** — hosted Dreadnode models plus BYOK access to Anthropic, OpenAI, Google, and others.
* **[Traces & analysis](https://docs.dreadnode.io/tui/analysis/)** — replay every tool call, span, and model turn for any session.

Press `?` inside the TUI for live keybindings and slash-command help.

Tip

`dn` is installed as an alias for `dreadnode` — both run the same binary. The rest of these docs use `dn` for brevity.
