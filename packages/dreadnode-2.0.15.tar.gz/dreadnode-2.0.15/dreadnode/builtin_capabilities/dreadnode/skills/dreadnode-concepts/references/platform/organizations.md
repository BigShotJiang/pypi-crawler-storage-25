<!-- AUTO-GENERATED — do not hand-edit. -->
<!-- source: packages/docs/src/content/docs/platform/organizations.mdx -->
<!-- public: https://docs.dreadnode.io/platform/organizations/ -->
<!-- bundle: dreadnode-concepts.json (regenerate via `just docs sync` or pre-commit) -->

# Organizations

> Understand how organizations group users, workspaces, and billing on Dreadnode.

Organizations are the top-level ownership boundary on Dreadnode. Everything else starts here: membership, workspaces, credits, billing, and most platform URLs.

If you only need the hierarchy and boundary model, start with the [Manage overview](./overview.md). This page is the organization deep dive.

## What an organization is

An organization represents a team, company, or group that shares access to the platform. Each organization has:

* A unique `key` (URL slug) used in API paths and URLs
* A display `name`
* A member list with role-based access
* Workspaces that contain projects
* Billing and usage context in SaaS mode

In practice, the organization is the answer to “who owns this work?” The workspace then answers “who inside that owner should collaborate on it?”

## Workflow: how organizations enter daily work

Organizations show up earlier in the product than many users realize.

1. During onboarding, Dreadnode validates your username and, in SaaS mode, your organization name.
2. The app redirects you into an organization-scoped URL.
3. Settings, membership, workspaces, registry pages, and billing all use that active organization context.
4. TUI and CLI profiles carry a default organization so later commands can resolve workspaces and projects underneath it.

If you are debugging a context mismatch, the organization is the first thing to verify.

## Membership and roles

Users are added to an organization as members. Each member has a role that determines their permissions:

| Role        | What they can do                                        |
| ----------- | ------------------------------------------------------- |
| Owner       | Full access — manage members, workspaces, billing, keys |
| Contributor | Create and manage workspaces and projects               |
| Reader      | View workspaces, projects, and traces                   |

Organization role is not the same thing as workspace permission. A user can be a broad org-level member and still have limited access inside a specific shared workspace.

### Invitations

Organization owners can invite users by email. Invitations have an expiration window and can be accepted or rejected by the recipient. External invites can be toggled on or off per organization.

Organization invitations and member management (role updates, removals) are available on all plans and require the **Owner** role.

### Teams

Teams are the bridge between organization membership and workspace access.

* You organize members into reusable groups at the organization level.
* You grant those teams access to shared workspaces.
* Workspace access then flows from that team assignment instead of having to be managed user by user every time.

## Organization limits

Each organization has a configurable maximum member count (default: 500). Platform administrators can adjust this limit.

## Managing organizations

* **Display name:** Update the organization display name from Settings (owner role required).
* **Members:** Manage members, update roles, and remove members from the organization settings page.
* **Teams:** Organize members into teams for workspace access control.
* **Workspaces:** Create and manage workspaces within the organization.

The App settings shell is the main operator surface here:

* `General` for org identity
* `Members` to Manage members
* `Workspaces` to shape collaboration boundaries
* `Billing` for SaaS credit-backed usage

### Availability checks

During onboarding, the platform validates usernames and organization keys in real time. Organization keys only need to be unique among other organization keys (they can overlap with usernames).

### Hub pages

The org sidebar includes a **Hub** section for org-scoped package types:

* [Capabilities](../capabilities/overview.md) for published agent, tool, skill, and MCP bundles
* [Security Tasks](https://docs.dreadnode.io/evaluations/tasks/) for reusable execution environments and verification logic
* [Datasets](https://docs.dreadnode.io/datasets/overview/) for versioned dataset artifacts
* [Models](https://docs.dreadnode.io/models/overview/) for versioned model artifacts

These pages are scoped to the active organization URL and show the versions currently published into that org.

## Relationship to other concepts

```
Organization
  ├── Members (users with roles)
  ├── Invitations (pending)
  ├── Workspaces
  │     ├── Projects
  │     │     ├── Sessions
  │     │     └── Traces
  │     └── Permissions (user + team)
  ├── Sandboxes (org-scoped)
  └── Credits (SaaS mode)
```
