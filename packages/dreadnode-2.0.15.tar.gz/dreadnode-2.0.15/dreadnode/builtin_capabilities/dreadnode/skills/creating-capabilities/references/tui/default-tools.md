<!-- AUTO-GENERATED — do not hand-edit. -->
<!-- source: packages/docs/src/content/docs/tui/default-tools.mdx -->
<!-- public: https://docs.dreadnode.io/tui/default-tools/ -->
<!-- bundle: capability-authoring.json (regenerate via `just docs sync` or pre-commit) -->

# Default tools

> The default tools every Dreadnode agent ships with — file ops, execution, web research, session state, and memory.

Every agent runs on top of a fixed tool pool. Capabilities add to it — they never remove from it. The tools below are available in every session, for every agent, regardless of which capabilities are installed.

Note

None of these tools prompt for approval by default. In interactive mode, the session policy can still pause a tool call before it runs (see [Autonomy](https://docs.dreadnode.io/tui/autonomy/)) — but the tool itself does not classify any of its calls as dangerous. If you need stricter gating, register a custom policy.

## File operations

| Tool    | Parameters                                                 | Does                                                                       |
| ------- | ---------------------------------------------------------- | -------------------------------------------------------------------------- |
| `read`  | `file_path: str`, `offset: int?`, `limit: int?`            | Read a file with line numbers, pagination, binary detection                |
| `write` | `file_path: str`, `content: str`, `cwd: str?`              | Write or overwrite a file, creating parent directories                     |
| `ls`    | `path: str?`, `ignore: list[str]?`, `cwd: str?`            | Tree-style listing with sensible ignores (`.git`, `node_modules`, `.venv`) |
| `glob`  | `pattern: str`, `path: str?`, `cwd: str?`                  | Find files by glob — ripgrep-backed, `pathlib` fallback                    |
| `grep`  | `pattern: str`, `path: str?`, `include: str?`, `cwd: str?` | Regex content search — ripgrep-backed                                      |

## Edits

Edits are surgical by design — they fail rather than produce wrong output when the expected state doesn’t match.

| Tool           | Parameters                                                                                  | Does                                                      |
| -------------- | ------------------------------------------------------------------------------------------- | --------------------------------------------------------- |
| `edit_file`    | `path: str`, `old_string: str`, `new_string: str`, `replace_all: bool = False`, `cwd: str?` | Fuzzy-matched text replacement in one file                |
| `multiedit`    | `path: str`, `edits: list[dict]`, `cwd: str?`                                               | Apply several sequential edits to one file atomically     |
| `delete_lines` | `path: str`, `start_line: int`, `end_line: int`, `cwd: str?`                                | Delete an inclusive line range                            |
| `insert_lines` | `path: str`, `line_number: int`, `content: str`, `cwd: str?`                                | Insert content before a 1-indexed line                    |
| `apply_patch`  | `patch_text: str`, `cwd: str?`                                                              | Apply a multi-file `Add`/`Update`/`Delete` patch envelope |

## Execution

| Tool     | Parameters                                                                 | Does                                                   |
| -------- | -------------------------------------------------------------------------- | ------------------------------------------------------ |
| `bash`   | `cmd: str`, `timeout: int = 120`, `cwd: str?`, `env: dict?`, `input: str?` | Run a shell command via `bash -c` with timeout control |
| `python` | `code: str`, `timeout: int = 120`, `cwd: str?`, `env: dict?`               | Execute a Python snippet in a subprocess (stdout only) |

## Network

The web toolchain is intentionally split by job: use `web_search` to discover candidate sources, `web_extract` to turn selected URLs into comparable evidence, and `fetch` when you need direct single-page retrieval.

| Tool          | Parameters                                                                                                  | Does                                                                                                                                                                                                         |
| ------------- | ----------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `fetch`       | `url: str`, `format: "markdown"\|"text"\|"html" = "markdown"`, `timeout: int = 30`, `headers: dict?`        | HTTP `GET` for a single URL. Returns structured metadata (`final_url`, `content_type`, `title`, `truncated`) plus fetched content. 5 MB download cap, 50 KB output cap. Optional HTML → markdown             |
| `web_search`  | `query: str`, `num_results: int = 5`, `allowed_domains: list[str]?`, `blocked_domains: list[str]?`          | Web search. Returns structured result metadata (`title`, `url`, `snippet`, `domain`, `rank`, plus `backend` and `warnings`). Provider selection is runtime-controlled (see below); the agent does not choose |
| `web_extract` | `urls: list[str]`, `format: "markdown"\|"text"\|"html" = "markdown"`, `timeout: int = 30`, `headers: dict?` | Research-oriented multi-page extraction. Accepts up to 5 unique URLs, deduplicates repeats, and returns one structured page record per URL with success/error state                                          |

`web_search` is backend-pluggable but selection is runtime-controlled, not agent-controlled. DuckDuckGo is always available. Set `FIRECRAWL_API_KEY` (with optional `FIRECRAWL_API_URL` for self-hosted / gateway deployments), `EXA_API_KEY` for Exa, or `GOOGLE_API_KEY` + `GOOGLE_CSE_ID` for Google Custom Search — the resolver picks the first configured provider in that order. `DREADNODE_WEB_SEARCH_BACKEND` pins a preferred provider globally; if the pinned provider isn’t configured the resolver warns and falls through to the auto chain. The answering provider is reported in the response’s `backend` field.

## Session state

These tools don’t touch the outside world — they manipulate session-visible state the agent uses to stay organized.

| Tool     | Parameters                                                                                 | Does                                                                         |
| -------- | ------------------------------------------------------------------------------------------ | ---------------------------------------------------------------------------- |
| `report` | `content: str`, `title: str?`, `filename: str?`, `format: "markdown"\|"text" = "markdown"` | Persist a named report under `.dreadnode/reports/` and log it as an artifact |
| `think`  | `thought: str`                                                                             | Record a reasoning step as a no-op log entry — a scratchpad                  |
| `todo`   | `todos: list[TodoItem]`                                                                    | Replace the session’s todo list and emit progress metrics                    |

A `TodoItem` is `{id: str, content: str, status: "pending" | "in_progress" | "completed" | "cancelled", priority: "high" | "medium" | "low"}`.

## Human-in-the-loop

`ask_user` is the tool agents call when they genuinely need input. In interactive mode it pauses the turn and surfaces a prompt above the composer; under autonomous mode (`HeadlessSessionPolicy`) it returns `deny` immediately so the agent can keep moving.

| Tool       | Parameters                                                                                                                                                     | Does                                    |
| ---------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------- |
| `ask_user` | `question: str`, `options: list?`, `kind: "input"\|"choice"\|"approval"?`, `details: str?`, `allow_free_text: bool?`, `default_option: str?`, `severity: str?` | Pause and prompt the user for an answer |
| `confirm`  | `action: str`, `default_yes: bool = False`                                                                                                                     | Yes/No wrapper around `ask_user`        |

See [Prompts and approvals](https://docs.dreadnode.io/tui/prompts-and-approvals/) for what the reader sees when these fire.

## Memory

The `Memory` toolset exposes a per-session key/value store through four methods:

| Method             | Parameters               | Does                                  |
| ------------------ | ------------------------ | ------------------------------------- |
| `save_memory`      | `key: str`, `value: str` | Store a value under `key`             |
| `retrieve_memory`  | `key: str`               | Read the value stored under `key`     |
| `list_memory_keys` |                          | List every key the session has stored |
| `clear_memory`     | `key: str?`              | Clear one key, or the entire store    |

Memory is per-session and in-memory — a `/new` session starts empty, and the store doesn’t survive across runtime restarts.

## What isn’t on this list

* **Capability tools.** Anything from a loaded capability (e.g. `dreadnode_cli` from the bundled `dreadnode` capability, or tools from a capability you install). Browse the capabilities screen (`Ctrl+P`) to see what’s loaded.
* **MCP tools.** Tools exposed by MCP servers the runtime has connected to.
* **Subagent delegation.** A capability can declare `links` that synthesize delegate tools; none are present by default.

The active runtime’s full tool list is visible from the tools dialog.
