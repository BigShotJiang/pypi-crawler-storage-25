"""Clean runtime client — session management, chat, events, discovery.

No server lifecycle management, no subprocess spawning, no TUI concerns.
Connects to an already-running runtime server over HTTP + WebSocket.
"""

import asyncio
import contextlib
import json
import os
import typing as t
from urllib.parse import quote, urlsplit, urlunsplit

import httpx
from loguru import logger
from websockets.exceptions import ConnectionClosed

from dreadnode.app.api.client import AuthenticationError
from dreadnode.app.client import models
from dreadnode.app.client.interactive import (
    TurnCancelledError,
    TurnFailedError,
    _RuntimeInteractiveTransport,
)
from dreadnode.app.client.transports import (
    StreamingASGITransport,
    _RuntimeSocketProtocol,
    _WebsocketsRuntimeSocket,
)
from dreadnode.app.env import read_env_with_deprecation
from dreadnode.app.server.runtime_events import RuntimeEventEnvelope

_SUBSCRIBE_RECONNECT_INITIAL_DELAY = 0.25
_SUBSCRIBE_RECONNECT_MAX_DELAY = 15.0

__all__ = [
    "DEFAULT_MODEL",
    "DEFAULT_RUNTIME_URL",
    "RuntimeClient",
    "TurnCancelledError",
    "TurnFailedError",
]


def _default_runtime_url() -> str:
    """Resolve the runtime URL from env at call time.

    Precedence: ``DREADNODE_RUNTIME_URL`` > composed from ``DREADNODE_RUNTIME_HOST``
    + ``DREADNODE_RUNTIME_PORT`` (with legacy ``DREADNODE_SERVER_HOST`` / ``_PORT``
    accepted and warned) > ``http://127.0.0.1:8787``.
    """
    explicit_url = os.environ.get("DREADNODE_RUNTIME_URL")
    if explicit_url:
        return explicit_url
    host = read_env_with_deprecation("DREADNODE_RUNTIME_HOST", "DREADNODE_SERVER_HOST", "127.0.0.1")
    port = read_env_with_deprecation("DREADNODE_RUNTIME_PORT", "DREADNODE_SERVER_PORT", "8787")
    return f"http://{host}:{port}"


def _default_auth_token() -> str | None:
    """Resolve the bearer token from env.

    Precedence: ``DREADNODE_RUNTIME_TOKEN`` > ``SANDBOX_AUTH_TOKEN`` (legacy,
    warns once).
    """
    return read_env_with_deprecation("DREADNODE_RUNTIME_TOKEN", "SANDBOX_AUTH_TOKEN")


# Resolved at import; consumers that spawn the server subprocess need the
# decomposed host/port pair. Lazy per-instance resolution in ``RuntimeClient.__init__``
# still reads current env.
DEFAULT_RUNTIME_HOST = read_env_with_deprecation(
    "DREADNODE_RUNTIME_HOST", "DREADNODE_SERVER_HOST", "127.0.0.1"
)
DEFAULT_RUNTIME_PORT = int(
    read_env_with_deprecation("DREADNODE_RUNTIME_PORT", "DREADNODE_SERVER_PORT", "8787")
)
DEFAULT_RUNTIME_URL = _default_runtime_url()
DEFAULT_MODEL = "anthropic/claude-opus-4-6"

if t.TYPE_CHECKING:
    from dreadnode.app.api.models import HumanInputResponse


class RuntimeClient:
    """Client for interacting with a running Dreadnode runtime server.

    Provides session management, chat streaming, event subscription,
    and runtime discovery. Assumes the server is already running —
    use :class:`~dreadnode.app.client.managed_client.ManagedRuntimeClient`
    when you need to start or manage the server process.
    """

    def __init__(
        self,
        server_url: str | None = None,
        *,
        auth_token: str | None = None,
        transport: httpx.AsyncBaseTransport | None = None,
        default_notify_source: str | None = None,
        default_session_labels: dict[str, list[str]] | None = None,
        default_session_origin: str | None = None,
    ) -> None:
        # Resolve env lazily per instance so tests setting env after import still work.
        self.server_url = (server_url or _default_runtime_url()).rstrip("/")
        self._auth_token = auth_token if auth_token is not None else _default_auth_token()
        self._http_client = httpx.AsyncClient(
            base_url=self.server_url,
            timeout=None,  # noqa: S113 - long-lived runtime client intentionally disables global timeout
            transport=transport,
            headers=self._build_auth_headers(),
        )
        # Used as the fallback ``source`` on ``notify`` calls (CAP-WCLI-014).
        # Worker-hosted clients set this to ``capability.<name>``; standalone
        # clients leave it as None and must supply ``source`` explicitly.
        self._default_notify_source = default_notify_source
        # Reserved labels that this client stamps on every ``create_session``
        # call (CAP-WCLI-022). Worker-bound clients populate this with
        # ``worker:<name>``; standalone clients leave it empty.
        self._default_session_labels: dict[str, list[str]] = dict(default_session_labels or {})
        # SES-ORG-003: worker-bound clients set this to ``worker`` so the
        # platform stamps ``origin=worker`` on every session. Standalone
        # clients leave it ``None`` and the runtime's default ``user`` applies.
        self._default_session_origin = default_session_origin
        self._started = False
        self._interactive_transport: _RuntimeInteractiveTransport | None = None

    def _build_auth_headers(self) -> dict[str, str]:
        if self._auth_token:
            return {"Authorization": f"Bearer {self._auth_token}"}
        return {}

    def _interactive_websocket_url(self) -> str:
        parsed = urlsplit(self.server_url)
        scheme = "wss" if parsed.scheme == "https" else "ws"
        return urlunsplit((scheme, parsed.netloc, "/api/ws", "", ""))

    def _get_interactive_transport(self) -> _RuntimeInteractiveTransport:
        if self._interactive_transport is None:
            self._interactive_transport = _RuntimeInteractiveTransport(self)
        return self._interactive_transport

    @property
    def is_started(self) -> bool:
        """Whether the client has verified server connectivity."""
        return self._started

    async def start(self) -> None:
        """Verify the server is reachable.

        Subclasses override this to add server lifecycle management
        (e.g., auto-starting an in-process or subprocess server).
        """
        if self._started:
            return
        if not await self._is_healthy():
            raise RuntimeError(
                f"Could not connect to Dreadnode runtime server at {self.server_url}"
            )
        self._started = True

    async def close(self) -> None:
        """Close network resources (HTTP client and interactive transport)."""
        interactive = self._interactive_transport
        self._interactive_transport = None
        if interactive is not None:
            await interactive.close()
        await self._http_client.aclose()

    async def _is_healthy(self) -> bool:
        try:
            response = await self._http_client.get("/api/health", timeout=1.0)
        except httpx.HTTPError as exc:
            logger.debug("Health check failed | error={}", exc)
            return False
        healthy = response.status_code == 200
        logger.debug("Health check | status={} | healthy={}", response.status_code, healthy)
        return healthy

    # ── Runtime discovery ─────────────────────────────────────────

    async def fetch_runtime_info(self) -> models.RuntimeInfo:
        """Fetch runtime metadata from the connected server."""
        logger.debug("Fetching runtime info")
        await self.start()
        response = await self._http_client.get("/api/runtime")
        response.raise_for_status()
        info = models.RuntimeInfo.from_dict(response.json())
        logger.debug(
            "Runtime info | status={} | version={} | capabilities={}",
            info.status,
            info.version,
            len(info.capabilities),
        )
        return info

    async def fetch_tools(self) -> list[models.ToolInfo]:
        """Fetch available tools from runtime."""
        logger.debug("Fetching tools")
        await self.start()
        resp = await self._http_client.get("/api/tools")
        resp.raise_for_status()
        tools = [models.ToolInfo.from_dict(t) for t in resp.json().get("tools", [])]
        logger.debug("Fetched tools | count={}", len(tools))
        return tools

    async def fetch_skills(self) -> list[models.SkillInfo]:
        """Fetch available skills from runtime."""
        logger.debug("Fetching skills")
        await self.start()
        resp = await self._http_client.get("/api/skills")
        resp.raise_for_status()
        skills = [models.SkillInfo.from_dict(s) for s in resp.json().get("skills", [])]
        logger.debug("Fetched skills | count={}", len(skills))
        return skills

    async def fetch_mcp_detail(self, capability: str, server_name: str) -> dict[str, t.Any]:
        """Fetch full detail for an MCP server."""
        logger.debug("Fetching MCP detail | server={}:{}", capability, server_name)
        await self.start()
        resp = await self._http_client.get(f"/api/mcp/{capability}/{server_name}")
        resp.raise_for_status()
        data = resp.json()
        logger.debug(
            "Fetched MCP detail | server={}:{} | tools={}",
            capability,
            server_name,
            data.get("tool_count", 0),
        )
        return data

    async def reconnect_mcp_server(self, capability: str, server_name: str) -> dict[str, t.Any]:
        """Reconnect an MCP server and return updated detail."""
        logger.debug("Reconnecting MCP server | server={}:{}", capability, server_name)
        await self.start()
        resp = await self._http_client.post(f"/api/mcp/{capability}/{server_name}/reconnect")
        resp.raise_for_status()
        data = resp.json()
        logger.debug(
            "MCP reconnect complete | server={}:{} | status={}",
            capability,
            server_name,
            data.get("status"),
        )
        return data

    async def fetch_worker_detail(self, capability: str, worker_name: str) -> dict[str, t.Any]:
        """Fetch full detail for a capability worker."""
        logger.debug("Fetching worker detail | worker={}:{}", capability, worker_name)
        await self.start()
        resp = await self._http_client.get(f"/api/workers/{capability}/{worker_name}")
        resp.raise_for_status()
        data = resp.json()
        logger.debug(
            "Fetched worker detail | worker={}:{} | state={}",
            capability,
            worker_name,
            data.get("state"),
        )
        return data

    async def restart_worker(self, capability: str, worker_name: str) -> dict[str, t.Any]:
        """Restart a capability worker and return updated detail."""
        logger.debug("Restarting worker | worker={}:{}", capability, worker_name)
        await self.start()
        resp = await self._http_client.post(f"/api/workers/{capability}/{worker_name}/restart")
        resp.raise_for_status()
        data = resp.json()
        logger.debug(
            "Worker restart complete | worker={}:{} | state={}",
            capability,
            worker_name,
            data.get("state"),
        )
        return data

    async def fetch_skill_content(self, name: str) -> str:
        """Fetch rendered skill content by name."""
        logger.debug("Fetching skill content | name={}", name)
        await self.start()
        resp = await self._http_client.get(f"/api/skills/{name}")
        resp.raise_for_status()
        data = resp.json()
        return str(data.get("rendered", "") or data.get("instructions", ""))

    async def reload_capabilities(self) -> models.RuntimeInfo:
        """Tell the server to re-discover capabilities and return updated runtime info."""
        logger.info("Reloading capabilities")
        await self.start()
        response = await self._http_client.post("/api/reload")
        response.raise_for_status()
        info = models.RuntimeInfo.from_dict(response.json())
        logger.info("Capabilities reloaded | count={}", len(info.capabilities))
        return info

    # ── Session management ────────────────────────────────────────

    async def list_sessions(self, *, include_platform: bool = False) -> list[models.SessionInfo]:
        """List in-process sessions from the connected server (the boot/swap fast path).

        Returns only sessions the runtime knows about in memory. ``include_platform``
        is preserved for callers that don't yet differentiate the two paths — when
        true, the runtime falls back to delegating to ``browse_sessions(page=1, limit=100)``
        and returns the flat ``sessions`` list. New code wanting paginated platform
        history should call :meth:`browse_sessions` directly so it gets the
        envelope (``total``, ``page``, etc.).
        """
        logger.debug("Listing sessions | include_platform={}", include_platform)
        await self.start()
        if include_platform:
            envelope = await self.browse_sessions(page=1, limit=100)
            return list(envelope.sessions)
        response = await self._http_client.get("/api/sessions")
        response.raise_for_status()
        sessions = [models.SessionInfo.from_dict(item) for item in response.json()]
        logger.debug("Listed sessions | count={}", len(sessions))
        return sessions

    async def browse_sessions(
        self,
        *,
        page: int = 1,
        limit: int = 20,
        sort_by: t.Literal[
            "updated_at", "last_message_at", "created_at", "message_count"
        ] = "updated_at",
        sort_dir: t.Literal["asc", "desc"] = "desc",
        archived: t.Literal["active", "archived", "any"] = "active",
        label: list[str] | None = None,
        user_id: str | None = None,
        project_id: list[str] | None = None,
        origin: list[str] | None = None,
        search: str | None = None,
        include_workload_sessions: bool = False,
    ) -> models.SessionListResult:
        """Paginated browse of platform-persisted sessions for this workspace.

        Pass-through for the platform's ``GET /sessions`` query shape — the
        runtime forwards every kwarg as a query param and returns the
        platform's paginated envelope verbatim. In-process sessions are
        not merged on this path; the table view trusts that
        ``_register_session_with_platform`` syncs new sessions within a
        turn. Use :meth:`list_sessions` for live in-process state.

        ``include_workload_sessions`` (SES-LST-009) defaults to ``False``
        so the table view hides eval (and future optimization / training
        / world) runs. Callers that want them — the agents page, analytics
        — pass ``True``.
        """
        logger.debug(
            "Browsing sessions | page={} limit={} sort={}:{}",
            page,
            limit,
            sort_by,
            sort_dir,
        )
        await self.start()
        # httpx serializes list values as repeated query params, matching
        # how the platform client wires `?label=` / `?project_id=`.
        params: dict[str, t.Any] = {
            "page": page,
            "limit": limit,
            "sort_by": sort_by,
            "sort_dir": sort_dir,
            "archived": archived,
            "include_workload_sessions": include_workload_sessions,
        }
        if user_id is not None:
            params["user_id"] = user_id
        if search:
            params["search"] = search
        if project_id:
            params["project_id"] = list(project_id)
        if origin:
            params["origin"] = list(origin)
        if label:
            params["label"] = list(label)
        response = await self._http_client.get("/api/sessions/browse", params=params)
        response.raise_for_status()
        envelope = models.SessionListResult.from_dict(response.json())
        logger.debug(
            "Browsed sessions | total={} page={}/{} returned={}",
            envelope.total,
            envelope.page,
            envelope.total_pages,
            len(envelope.sessions),
        )
        return envelope

    async def browse_session_facets(
        self,
        *,
        archived: t.Literal["active", "archived", "any"] = "active",
        label: list[str] | None = None,
        user_id: str | None = None,
        project_id: list[str] | None = None,
        origin: list[str] | None = None,
        search: str | None = None,
        include_workload_sessions: bool = False,
    ) -> models.SessionFacets:
        """Per-key value counts for the sidebar facets on the table view.

        Parallels :meth:`browse_sessions` — takes the same filter set
        (minus pagination / sort) and returns a typed
        :class:`~dreadnode.app.client.models.SessionFacets` envelope.
        Keys with zero matches are omitted by the platform, so the result
        only carries the keys the caller can act on. Honors the same
        SES-LST-009 workload default as the list endpoint.
        """
        logger.debug("Browsing session facets | archived={}", archived)
        await self.start()
        params: dict[str, t.Any] = {
            "archived": archived,
            "include_workload_sessions": include_workload_sessions,
        }
        if user_id is not None:
            params["user_id"] = user_id
        if search:
            params["search"] = search
        if project_id:
            params["project_id"] = list(project_id)
        if origin:
            params["origin"] = list(origin)
        if label:
            params["label"] = list(label)
        response = await self._http_client.get("/api/sessions/facets", params=params)
        response.raise_for_status()
        facets = models.SessionFacets.from_dict(response.json())
        logger.debug("Browsed session facets | keys={}", len(facets.labels))
        return facets

    async def create_session(
        self,
        *,
        capability: str | None = None,
        agent: str | None = None,
        model: str | None = None,
        session_id: str | None = None,
        project: str | None = None,
        generate_params_extra: dict[str, t.Any] | None = None,
        policy: str | dict[str, t.Any] | None = None,
        labels: dict[str, list[str]] | None = None,
        origin: str | None = None,
    ) -> models.SessionInfo:
        """Create or resolve a session on the server.

        If *session_id* is provided and a session with that ID already
        exists, the call is idempotent and returns the existing session
        (CAP-WCLI-003).
        """
        logger.debug(
            "Creating session | agent={} | model={} | project={} | policy={} | session_id={}",
            agent,
            model,
            project,
            policy,
            session_id[:8] if session_id else None,
        )
        await self.start()
        payload: dict[str, t.Any] = {}
        if capability is not None:
            payload["capability"] = capability
        if agent is not None:
            payload["agent"] = agent
        if model is not None:
            payload["model"] = model
        if session_id is not None:
            payload["session_id"] = session_id
        if project is not None:
            payload["project"] = project
        if generate_params_extra is not None:
            payload["generate_params_extra"] = generate_params_extra
        if policy is not None:
            payload["policy"] = policy
        # Merge client-bound default labels (CAP-WCLI-022) with any explicit
        # per-call labels. Explicit values win on conflict.
        merged_labels: dict[str, list[str]] = {
            key: list(values) for key, values in self._default_session_labels.items()
        }
        if labels:
            for key, values in labels.items():
                merged_labels[key] = list(values)
        if merged_labels:
            payload["labels"] = merged_labels
        # SES-ORG-003: explicit per-call origin wins; otherwise fall back to
        # the client-bound default (worker-bound clients set this to
        # ``worker``). Standalone clients leave it unset so the runtime's
        # ``user`` default applies.
        resolved_origin = origin if origin is not None else self._default_session_origin
        if resolved_origin is not None:
            payload["origin"] = resolved_origin
        response = await self._http_client.post("/api/sessions", json=payload)
        response.raise_for_status()
        session = models.SessionInfo.from_dict(response.json())
        logger.info(
            "Session created | session_id={} | capability={}",
            session.session_id[:8],
            session.capability,
        )
        return session

    async def reset_session(self, session_id: str) -> None:
        """Reset a server session."""
        logger.info("Resetting session | session_id={}", session_id[:8])
        await self.start()
        response = await self._http_client.post(f"/api/sessions/{session_id}/reset")
        response.raise_for_status()

    async def set_session_title(self, session_id: str, title: str) -> None:
        """Persist a session title on the server."""
        logger.info("Setting session title | session_id={}", session_id[:8])
        await self.start()
        response = await self._http_client.post(
            f"/api/sessions/{session_id}/title",
            json={"title": title},
        )
        response.raise_for_status()

    async def set_session_policy(
        self,
        session_id: str,
        policy: str | dict[str, t.Any] | None,
    ) -> dict[str, t.Any]:
        """Swap a session's active policy mid-run.

        Returns the server response dict with ``policy_name``,
        ``policy_is_autonomous``, and ``policy_display_label``
        populated from the resolved policy class.
        """
        logger.info("Setting session policy | session_id={} policy={}", session_id[:8], policy)
        await self.start()
        response = await self._http_client.post(
            f"/api/sessions/{session_id}/policy",
            json={"policy": policy},
        )
        response.raise_for_status()
        return dict(response.json())

    async def compact_session(self, session_id: str, *, guidance: str = "") -> dict[str, t.Any]:
        """Request manual compaction of a session."""
        logger.info("Compacting session | session_id={}", session_id[:8])
        await self.start()
        payload: dict[str, t.Any] = {}
        if guidance:
            payload["guidance"] = guidance
        response = await self._http_client.post(
            f"/api/sessions/{session_id}/compact",
            json=payload,
        )
        response.raise_for_status()
        return response.json()

    async def fetch_session_messages(self, session_id: str) -> list[dict[str, t.Any]]:
        """Fetch conversation messages for a session."""
        logger.debug("Fetching session messages | session_id={}", session_id[:8])
        await self.start()
        response = await self._http_client.get(f"/api/sessions/{session_id}/messages")
        response.raise_for_status()
        messages = response.json()
        logger.debug(
            "Fetched session messages | session_id={} | count={}", session_id[:8], len(messages)
        )
        return messages

    async def delete_session(self, session_id: str) -> None:
        """Delete a server session."""
        logger.info("Deleting session | session_id={}", session_id[:8])
        await self.start()
        response = await self._http_client.delete(f"/api/sessions/{session_id}")
        response.raise_for_status()

    # ── Turn execution ────────────────────────────────────────────

    async def cancel_session(self, session_id: str) -> None:
        """Cancel the active turn for a session."""
        await self.start()
        await self._get_interactive_transport().cancel_session(session_id)

    async def stream_chat(
        self,
        *,
        session_id: str,
        message: str,
        model: str | None = None,
        agent: str | None = None,
        reset: bool = False,
        generate_params_extra: dict[str, t.Any] | None = None,
    ) -> t.AsyncIterator[dict[str, t.Any]]:
        """Stream websocket chat events for one session turn."""
        logger.debug(
            "WS stream starting | session={} | model={} | agent={}", session_id[:8], model, agent
        )
        await self.start()
        event_count = 0
        transport = self._get_interactive_transport()
        async for event in transport.stream_chat(
            session_id=session_id,
            message=message,
            model=model,
            agent=agent,
            reset=reset,
            generate_params_extra=generate_params_extra,
        ):
            event_count += 1
            event_type = str(event.get("type", "")).lower()
            logger.debug("WS event | type={} | session={}", event_type, session_id[:8])
            yield event
        logger.debug("WS stream complete | session={} | events={}", session_id[:8], event_count)

    async def run_turn(
        self,
        *,
        session_id: str,
        message: str,
        model: str | None = None,
        agent: str | None = None,
        reset: bool = False,
        generate_params_extra: dict[str, t.Any] | None = None,
    ) -> dict[str, t.Any]:
        """Run a turn to completion and return the terminal ``turn.completed``
        payload (CAP-WEVT-007): ``response_text``, ``tool_calls``, ``usage``,
        ``duration_ms``, ``turn_id``.

        Use this when you want the final result without iterating individual
        agent events. For streaming UIs, use :meth:`stream_chat` instead.

        Raises :class:`TurnFailedError` on ``turn.failed`` (carrying the
        ``error_type``, ``partial_response``, and any attempted tool calls)
        and :class:`TurnCancelledError` on ``turn.cancelled``.
        """
        logger.debug(
            "WS run_turn | session={} | model={} | agent={}",
            session_id[:8],
            model,
            agent,
        )
        await self.start()
        return await self._get_interactive_transport().run_turn(
            session_id=session_id,
            message=message,
            model=model,
            agent=agent,
            reset=reset,
            generate_params_extra=generate_params_extra,
        )

    # ── Event subscription ────────────────────────────────────────

    async def subscribe_session(self, session_id: str) -> None:
        """Keep a session subscribed on the interactive websocket."""
        logger.debug("Subscribing to session stream | session={}", session_id[:8])
        await self.start()
        await self._get_interactive_transport().subscribe_session(session_id)

    async def unsubscribe_session(self, session_id: str) -> None:
        """Drop a session subscription from the interactive websocket."""
        logger.debug("Unsubscribing from session stream | session={}", session_id[:8])
        await self.start()
        await self._get_interactive_transport().unsubscribe_session(session_id)

    async def subscribe(self, *kinds: str) -> t.AsyncIterator[RuntimeEventEnvelope]:
        """Subscribe to runtime-bus events filtered by ``kinds`` (CAP-WCLI-018).

        Returns an async iterator yielding :class:`RuntimeEventEnvelope`
        values. ``kinds`` is variadic; passing none subscribes to every
        event. Session- and runtime-scope envelopes both flow through —
        consumers inspect ``session_id`` to distinguish (CAP-WEVT-002).

        The iterator yields events until the caller closes it
        (``aclose()`` or breaking out of ``async for``) or authentication
        is rejected. History is not replayed (CAP-WCLI-020).

        On transient transport loss the client reconnects with
        exponential backoff, reinstates the original ``kinds`` filter,
        and yields a synthetic ``transport.reconnected`` envelope before
        resuming (CAP-WCLI-021). Events published while disconnected
        are not replayed; subscribers that need durability own their
        own resync.

        Peer of :meth:`subscribe_session` (CAP-WCLI-011); independent
        from the interactive transport, so standalone worker processes
        can iterate the runtime bus without opening a session-control
        channel.
        """
        await self.start()

        first_connection = True
        backoff = _SUBSCRIBE_RECONNECT_INITIAL_DELAY
        while True:
            try:
                socket = await self._open_event_stream_socket(kinds)
            except AuthenticationError:
                raise
            except Exception as exc:
                if first_connection:
                    raise
                logger.debug(
                    "Runtime event stream reconnect failed | error={} | backoff={:.2f}s",
                    exc,
                    backoff,
                )
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, _SUBSCRIBE_RECONNECT_MAX_DELAY)
                continue

            logger.debug(
                "Runtime event stream opened | kinds={} | reconnect={}",
                sorted(kinds) or "*",
                not first_connection,
            )
            if not first_connection:
                yield RuntimeEventEnvelope(
                    seq=0,
                    kind="transport.reconnected",
                    payload={"kinds": sorted(kinds)},
                )
            first_connection = False
            backoff = _SUBSCRIBE_RECONNECT_INITIAL_DELAY

            try:
                while True:
                    try:
                        raw = await socket.recv_text()
                    except AuthenticationError:
                        raise
                    except (RuntimeError, ConnectionClosed, OSError) as exc:
                        # Transient transport loss — close this socket,
                        # reconnect, and yield ``transport.reconnected``.
                        logger.debug("Runtime event stream transient loss | error={}", exc)
                        break
                    envelope_data = json.loads(raw)
                    yield RuntimeEventEnvelope.model_validate(envelope_data)
            finally:
                with contextlib.suppress(Exception):
                    await socket.close()

    async def _open_event_stream_socket(
        self,
        kinds: tuple[str, ...],
    ) -> _RuntimeSocketProtocol:
        """Open a websocket against ``/api/ws/events`` with the kind filter."""
        parsed = urlsplit(self.server_url)
        scheme = "wss" if parsed.scheme == "https" else "ws"
        query = "&".join(f"kinds={quote(kind, safe='')}" for kind in kinds)
        url = urlunsplit((scheme, parsed.netloc, "/api/ws/events", query, ""))
        headers = self._build_auth_headers()

        http_transport = self._http_client._transport
        if isinstance(http_transport, StreamingASGITransport):
            return await http_transport.websocket_connect(url=url, headers=headers)
        if http_transport is not None:
            raise RuntimeError(
                "Runtime event stream is unavailable with an injected HTTP transport"
            )

        from websockets.asyncio.client import connect

        connection = await connect(
            url,
            additional_headers=headers or None,
            ping_interval=20,
            ping_timeout=20,
        )
        return _WebsocketsRuntimeSocket(connection)

    async def publish(
        self,
        kind: str,
        payload: dict[str, t.Any] | None = None,
        *,
        session_id: str | None = None,
    ) -> dict[str, t.Any]:
        """Publish an event onto the runtime event bus (CAP-WCLI-013).

        When *session_id* is provided the event is session-scoped; otherwise
        it is runtime-scope. Subscribers matching the event's ``kind`` receive
        it regardless of scope (CAP-WEVT-002). Reserved-prefix kinds
        (``turn.``, ``prompt.``, ``session.``, ``transport.``,
        ``capabilities.``) are rejected at the server per CAP-WEVT-003.
        """
        body = {"kind": kind, "payload": payload or {}}
        await self.start()
        if session_id is not None:
            logger.debug("Publishing event | session={} | kind={}", session_id[:8], kind)
            response = await self._http_client.post(
                f"/api/sessions/{session_id}/events",
                json=body,
            )
        else:
            logger.debug("Publishing runtime-scope event | kind={}", kind)
            response = await self._http_client.post("/api/events", json=body)
        response.raise_for_status()
        return response.json()

    async def notify(
        self,
        title: str,
        *,
        body: str | None = None,
        severity: t.Literal["info", "warning", "error", "success"] = "info",
        source: str | None = None,
        session_id: str | None = None,
    ) -> dict[str, t.Any]:
        """Publish a user-facing notification (CAP-WCLI-014, CAP-WEVT-004).

        Notifications are runtime-scope unless *session_id* is provided.
        *source* defaults to the client's configured
        ``default_notify_source`` — worker-hosted clients get
        ``capability.<name>``; standalone clients leave it empty unless
        the caller supplies one.
        """
        return await self.publish(
            kind="notify",
            payload={
                "source": source or self._default_notify_source or "",
                "title": title,
                "body": body,
                "severity": severity,
            },
            session_id=session_id,
        )

    # ── Prompt responses ──────────────────────────────────────────

    async def send_permission_response(
        self,
        session_id: str,
        request_id: str,
        decision: str,
    ) -> None:
        """Send a permission decision back to the server via the interactive websocket."""
        logger.debug(
            "Sending permission response | session={} | request_id={} | decision={}",
            session_id[:8],
            request_id,
            decision,
        )
        await self.start()
        await self._get_interactive_transport().send_permission_response(
            session_id,
            request_id,
            decision,
        )

    async def send_human_input_response(
        self,
        session_id: str,
        response: "HumanInputResponse",
    ) -> None:
        """Send a human input response back to the server via the interactive websocket."""
        logger.debug("Sending human input response | session={}", session_id[:8])
        await self.start()
        await self._get_interactive_transport().send_human_input_response(session_id, response)

    # ── File system & shell ───────────────────────────────────────

    async def list_files(
        self,
        path: str | None = None,
        depth: int = 10,
    ) -> list[dict[str, t.Any]]:
        """List files in a directory on the server."""
        logger.debug("Listing files | path={} | depth={}", path, depth)
        await self.start()
        params: dict[str, t.Any] = {"depth": depth}
        if path:
            params["path"] = path
        response = await self._http_client.get("/api/files", params=params)
        response.raise_for_status()
        return response.json().get("entries", [])

    async def read_file(self, path: str) -> str:
        """Read a file's content from the server."""
        logger.debug("Reading file | path={}", path)
        await self.start()
        response = await self._http_client.get("/api/files/read", params={"path": path})
        response.raise_for_status()
        return response.json().get("content", "")

    async def execute_shell(
        self,
        command: str,
        *,
        cwd: str | None = None,
        timeout: int = 30,  # noqa: ASYNC109
    ) -> dict[str, t.Any]:
        """Execute a shell command on the server."""
        logger.debug("Executing shell command | cwd={} | timeout={}", cwd, timeout)
        await self.start()
        response = await self._http_client.post(
            "/api/shell",
            params={"command": command, "timeout": timeout, **({"cwd": cwd} if cwd else {})},
        )
        response.raise_for_status()
        return response.json()
