"""System prompt generation for the Dreadnode agent runtime."""

import typing as t
from functools import cache
from textwrap import dedent

from loguru import logger

from dreadnode.builtin_capabilities import (
    read_builtin_agent_prompt,
    read_builtin_skill_instructions,
)

__all__ = [
    "get_concepts_prompt",
    "get_core_system_prompt",
    "get_default_agent_system_prompt",
    "get_platform_context",
    "get_runtime_shell_prompt",
]

_DEFAULT_CAPABILITY_NAME = "dreadnode"
_DEFAULT_AGENT_NAME = "dreadnode"
_CONCEPTS_SKILL_NAME = "dreadnode-concepts"


def _get_cli_commands() -> str:
    """Extract CLI commands dynamically from cyclopts registry.

    Note: Accesses cyclopts internal `_commands` dict. If cyclopts changes
    its internals, the CLI section will be omitted from the system prompt.
    """
    try:
        from dreadnode.app.cli.main import cli

        # Access internal command registry — guarded by try/except
        command_registry = getattr(cli, "_commands", None)
        if command_registry is None:
            return ""

        commands: list[str] = []
        for name, sub_app in command_registry.items():
            # Skip flags like --help, --version
            if name.startswith("-"):
                continue

            help_text = getattr(sub_app, "help", "") or ""
            if not help_text:
                default_cmd = getattr(sub_app, "default_command", None)
                if default_cmd and hasattr(default_cmd, "__doc__") and default_cmd.__doc__:
                    help_text = default_cmd.__doc__.strip().split("\n")[0]

            if help_text:
                commands.append(f"- `dreadnode {name}` — {help_text}")

        return "\n".join(sorted(commands)) if commands else ""
    except Exception:
        logger.debug("CLI command introspection failed", exc_info=True)
        return ""


def _get_slash_commands() -> str:
    """Extract TUI slash commands from the commands registry."""
    try:
        from dreadnode.app.tui.commands import SLASH_COMMANDS

        lines: list[str] = []
        for cmd in SLASH_COMMANDS:
            hint = f" {cmd.hint}" if cmd.hint else ""
            lines.append(f"- `{cmd.name}{hint}` — {cmd.description}")

        return "\n".join(lines) if lines else ""
    except Exception:
        logger.debug("Slash command introspection failed", exc_info=True)
        return ""


def get_platform_context() -> str:
    """Build dynamic platform context string if credentials are available."""
    try:
        from dreadnode import _get_default_instance

        instance = _get_default_instance()
        if not instance.can_sync:
            return ""

        profile = instance.profile
        parts: list[str] = []

        org_key = getattr(profile, "org_key", None)
        workspace_key = getattr(profile, "workspace_key", None)
        project_key = getattr(profile, "project_key", None)

        if org_key:
            parts.append(f"- Organization: {org_key}")
        if workspace_key:
            parts.append(f"- Workspace: {workspace_key}")
        if project_key:
            parts.append(f"- Project: {project_key}")

        if not parts:
            return ""
        return "\n## Current platform context\n\n" + "\n".join(parts) + "\n"
    except Exception:
        logger.debug("Platform context extraction failed", exc_info=True)
        return ""


def _emergency_default_agent_prompt() -> str:
    """Minimal fallback when the bundled @dreadnode prompt is unavailable."""
    return dedent("""\
        You are the emergency fallback Dreadnode agent.

        The bundled `@dreadnode` capability prompt could not be loaded, so rely only on the
        runtime shell, the currently available tools, and the active capability metadata.

        Work carefully: inspect before acting, make one change at a time, validate findings,
        and report evidence, impact, and limitations clearly. Persist substantial deliverables
        with `report` when that tool is available. Use `dreadnode_cli` for exact CLI syntax.""")


def _emergency_concepts_prompt() -> str:
    """Minimal fallback when the bundled dreadnode-concepts skill is unavailable."""
    return dedent("""\
        ## Concepts Fallback

        Bundled Dreadnode concepts assets are unavailable in this environment.

        Only the host-owned runtime shell, the currently loaded capabilities, and the tools
        visible in this session are guaranteed. Use `dreadnode --help` for exact CLI guidance.""")


def _read_bundled_prompt_or_fallback(
    *,
    kind: str,
    capability_name: str,
    asset_name: str,
    reader: t.Callable[[str, str], str],
    fallback: str,
) -> str:
    """Load a bundled prompt asset, or return a minimal emergency fallback."""
    bundled = reader(capability_name, asset_name)
    if bundled:
        return bundled

    logger.warning(
        "Bundled {} asset missing for capability={} asset={}; using emergency fallback",
        kind,
        capability_name,
        asset_name,
    )
    return fallback


@cache
def get_default_agent_system_prompt() -> str:
    """Return the bundled @dreadnode prompt, with a minimal emergency fallback."""
    return _read_bundled_prompt_or_fallback(
        kind="agent prompt",
        capability_name=_DEFAULT_CAPABILITY_NAME,
        asset_name=_DEFAULT_AGENT_NAME,
        reader=read_builtin_agent_prompt,
        fallback=_emergency_default_agent_prompt(),
    )


@cache
def get_runtime_shell_prompt() -> str:
    """Build host-owned runtime prompt sections shared across agents."""
    sections: list[str] = [
        dedent("""\
            Dreadnode runs agents inside an isolated runtime shell. The host runtime injects platform context, built-in tools, and capability metadata around the active agent prompt.""")
    ]

    # Dynamic CLI commands (omit section entirely if introspection fails)
    cli_commands = _get_cli_commands()
    if cli_commands:
        sections.append(
            "## Dreadnode CLI\n\n"
            "The user may ask about Dreadnode commands. Available commands:\n\n"
            f"{cli_commands}\n\n"
            "Run `dreadnode --help` or `dreadnode <command> --help` for detailed usage."
        )

    # Dynamic slash commands (omit section entirely if introspection fails)
    slash_commands = _get_slash_commands()
    if slash_commands:
        sections.append(
            "## In-app slash commands\n\n"
            "When running in the TUI, these slash commands are available:\n\n"
            f"{slash_commands}"
        )

    return "\n\n".join(sections)


@cache
def get_concepts_prompt() -> str:
    """Return bundled dreadnode-concepts content, with a minimal emergency fallback."""
    return _read_bundled_prompt_or_fallback(
        kind="concepts",
        capability_name=_DEFAULT_CAPABILITY_NAME,
        asset_name=_CONCEPTS_SKILL_NAME,
        reader=read_builtin_skill_instructions,
        fallback=_emergency_concepts_prompt(),
    )


@cache
def get_core_system_prompt() -> str:
    """Build the fallback runtime prompt when no capability agent prompt is active."""
    sections = [
        get_default_agent_system_prompt(),
        get_runtime_shell_prompt(),
        get_concepts_prompt(),
    ]
    return "\n\n".join(section for section in sections if section)
