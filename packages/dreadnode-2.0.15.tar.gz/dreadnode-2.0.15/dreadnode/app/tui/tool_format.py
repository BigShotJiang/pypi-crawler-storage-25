"""Pre-render helpers for tool calls — NOT the tool display layer.

The actual tool display layer lives in :mod:`dreadnode.app.tui.widgets.tool`
(the ``ToolCall`` Textual widget + ``render_tool_call`` Rich renderer).
This module is the pre-render step those consumers need: given a tool
name + args, produce a compact label (``"read(pyproject.toml)"``); given
a tool name + args + result, produce a one-line summary (``"Read 42
lines."``). Messages have no equivalent pre-render module because
``Message.content`` — the wire format is already
displayable — whereas tool calls require computation to pick an
interesting arg to show inline and to compress large results.

The reason this lives at the ``tui/`` top level rather than inside the
``widgets/`` folder is that it has no Textual/Rich dependency — that
lets :class:`CapabilitiesManager` import it to re-seed the registry on
every runtime refresh without pulling widget code into the manager
layer.

The registry API (:func:`register_tool_key_args`, :func:`register_tool_summarizer`,
:func:`clear_tool_registry`) lets capabilities teach the TUI about
their own tools without editing this file. The :class:`CapabilitiesManager`
seeds it from each tool's JSON Schema via :func:`derive_key_args_from_schema`
on every ``/api/tools`` refresh. Built-in tools get sensible defaults
via :data:`_BUILTIN_TOOL_KEY_ARGS` installed at import time, and tools
with no usable schema fall back to the first short string argument.
"""

import json
import re
import typing as t

_PATH_ARGS = {"file_path", "path", "filename", "url"}


# =============================================================================
# Registration API
# =============================================================================

Summarizer = t.Callable[[str, dict[str, t.Any], t.Any], str | None]

# Populated by :func:`register_tool_key_args`. Lowercased tool name →
# ordered list of argument keys to try when building a compact label.
_TOOL_KEY_ARGS: dict[str, list[str]] = {}

# Populated by :func:`register_tool_summarizer`. Lowercased tool name →
# a ``(name, args, result) -> str | None`` callable that returns a
# compact one-line summary of the result. ``None`` means "fall back to
# the generic first-line summarizer".
_TOOL_SUMMARIZERS: dict[str, Summarizer] = {}


def register_tool_key_args(name: str, keys: list[str]) -> None:
    """Register the preferred argument keys for a tool's compact label."""
    if not name:
        return
    _TOOL_KEY_ARGS[name.lower()] = list(keys)


def register_tool_summarizer(name: str, summarizer: Summarizer) -> None:
    """Register a per-tool result summarizer."""
    if not name:
        return
    _TOOL_SUMMARIZERS[name.lower()] = summarizer


def clear_tool_registry() -> None:
    """Reset the registry and re-install the built-in defaults."""
    _TOOL_KEY_ARGS.clear()
    _TOOL_SUMMARIZERS.clear()
    for name, keys in _BUILTIN_TOOL_KEY_ARGS.items():
        _TOOL_KEY_ARGS[name] = list(keys)
    _TOOL_SUMMARIZERS.update(_BUILTIN_TOOL_SUMMARIZERS)


def derive_key_args_from_schema(schema: dict[str, t.Any] | None) -> list[str]:
    """Pick argument keys to show in a compact label from a JSON Schema.

    Prefers the schema's ``required`` list in order, then falls back to
    the order of ``properties``. Keeps only string-typed properties
    (including ``anyOf``/``oneOf`` with a string branch) since non-string
    values rarely make useful inline labels. Returns at most three keys.
    """
    if not isinstance(schema, dict):
        return []
    properties = schema.get("properties")
    if not isinstance(properties, dict) or not properties:
        return []

    required = schema.get("required")
    ordered: list[str] = []
    seen: set[str] = set()
    if isinstance(required, list):
        for name in required:
            if isinstance(name, str) and name in properties and name not in seen:
                ordered.append(name)
                seen.add(name)
    for name in properties:
        if isinstance(name, str) and name not in seen:
            ordered.append(name)
            seen.add(name)

    def _is_string_like(prop: t.Any) -> bool:
        if not isinstance(prop, dict):
            return False
        prop_type = prop.get("type")
        if prop_type == "string":
            return True
        if isinstance(prop_type, list) and "string" in prop_type:
            return True
        for key in ("anyOf", "oneOf"):
            branches = prop.get(key)
            if isinstance(branches, list) and any(_is_string_like(b) for b in branches):
                return True
        return False

    keys = [name for name in ordered if _is_string_like(properties.get(name))]
    return keys[:3]


# =============================================================================
# Built-in seed data
# =============================================================================
#
# These are the tools ``dreadnode.tools.default_tools()`` ships — the
# "built-in" capability group the runtime server always exposes. They
# are seeded on import and re-installed by :func:`clear_tool_registry`.

_BUILTIN_TOOL_KEY_ARGS: dict[str, list[str]] = {
    # Execution tools
    "bash": ["command", "cmd"],
    "shell": ["command", "cmd"],
    "execute": ["cmd"],
    "python": ["code"],
    "dreadnode_cli": ["command"],
    # File tools
    "read": ["file_path", "path", "filename", "url"],
    "read_file": ["file_path", "path"],
    "write": ["file_path", "path"],
    "write_file": ["file_path", "path"],
    "edit": ["file_path", "path"],
    "edit_file": ["path", "file_path"],
    "multiedit": ["path"],
    "insert_lines": ["path"],
    "delete_lines": ["path"],
    "apply_patch": ["patch_text"],
    # Search tools
    "grep": ["pattern", "query"],
    "search": ["pattern", "query"],
    "glob": ["pattern"],
    "find": ["pattern", "path"],
    "ls": ["path"],
    # Web tools
    "web_search": ["query"],
    "fetch": ["url"],
    "web_extract": ["urls"],
    # Reporting and recall tools
    "report": ["title", "filename"],
    "session_search": ["query"],
    # Interaction tools
    "think": ["thought"],
    "ask_user": ["question"],
    "finish_task": ["summary"],
}


def _first_line(text: str) -> str:
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    if not lines:
        return ""
    first = lines[0]
    if len(lines) > 1:
        return f"{first[:100]}..."
    return first[:120] + ("..." if len(first) > 120 else "")


def _get_result_text(res: t.Any) -> str:
    if isinstance(res, str):
        return res
    if isinstance(res, dict):
        return (
            str(res.get("stdout", ""))
            or str(res.get("output", ""))
            or str(res.get("error", ""))
            or str(res.get("stderr", ""))
        )
    if isinstance(res, list):
        return "\n".join(str(x) for x in res)
    return str(res)


def _summarize_read(_name: str, _args: dict[str, t.Any], result: t.Any) -> str | None:
    text = _get_result_text(result)
    lines = len(text.splitlines())
    return f"Read {lines} line{'s' if lines != 1 else ''}."


def _summarize_search(_name: str, _args: dict[str, t.Any], result: t.Any) -> str | None:
    text = _get_result_text(result)
    lines = len([line for line in text.splitlines() if line.strip()])
    return f"Found {lines} result{'s' if lines != 1 else ''}."


def _summarize_list(_name: str, _args: dict[str, t.Any], result: t.Any) -> str | None:
    text = _get_result_text(result)
    items = len(text.split())
    return f"Listed {items} item{'s' if items != 1 else ''}."


def _summarize_shell(_name: str, args: dict[str, t.Any], result: t.Any) -> str | None:
    text = _get_result_text(result)
    cmd = str(args.get("command", "") or args.get("cmd", "") or "").strip()
    if cmd.startswith("ls"):
        items = len(text.split())
        return f"Listed {items} item{'s' if items != 1 else ''}."
    return _first_line(text) or None


def _summarize_edit(_name: str, _args: dict[str, t.Any], _result: t.Any) -> str | None:
    return "Succeeded. File edited."


def _try_parse_structured_payload(result: t.Any) -> dict[str, t.Any] | None:
    if isinstance(result, dict):
        return result
    if not isinstance(result, str):
        return None
    try:
        parsed = json.loads(result)
    except Exception:
        return None
    return parsed if isinstance(parsed, dict) else None


def _summarize_web_search(_name: str, _args: dict[str, t.Any], result: t.Any) -> str | None:
    payload = _try_parse_structured_payload(result)
    if payload is None:
        return _first_line(_get_result_text(result)) or None

    results = payload.get("results")
    if not isinstance(results, list):
        return _first_line(_get_result_text(result)) or None

    count = payload.get("result_count", len(results))
    if not isinstance(count, int):
        count = len(results)
    if count == 0:
        return "No web results found."
    return f"Found {count} web result{'s' if count != 1 else ''}."


def _summarize_fetch(_name: str, _args: dict[str, t.Any], result: t.Any) -> str | None:
    payload = _try_parse_structured_payload(result)
    if payload is None:
        return _first_line(_get_result_text(result)) or None

    title = payload.get("title")
    final_url = payload.get("final_url") or payload.get("url")
    truncated = bool(payload.get("truncated"))

    if isinstance(title, str) and title.strip():
        suffix = " (truncated)." if truncated else "."
        return f"Fetched {title.strip()}{suffix}"
    if isinstance(final_url, str) and final_url.strip():
        suffix = " (truncated)." if truncated else "."
        return f"Fetched {final_url.strip()}{suffix}"
    return "Fetched web content."


def _summarize_web_extract(_name: str, _args: dict[str, t.Any], result: t.Any) -> str | None:
    payload = _try_parse_structured_payload(result)
    if payload is None:
        return _first_line(_get_result_text(result)) or None

    requested = payload.get("requested_count")
    extracted = payload.get("extracted_count")
    if not isinstance(requested, int) or not isinstance(extracted, int):
        return _first_line(_get_result_text(result)) or None

    if requested == 0:
        return "No pages extracted."
    if extracted == requested:
        return f"Extracted {extracted} page{'s' if extracted != 1 else ''}."
    return f"Extracted {extracted} of {requested} pages."


_BUILTIN_TOOL_SUMMARIZERS: dict[str, Summarizer] = {
    "read": _summarize_read,
    "read_file": _summarize_read,
    "glob": _summarize_search,
    "find": _summarize_search,
    "search": _summarize_search,
    "grep": _summarize_search,
    "ls": _summarize_list,
    "list_directory": _summarize_list,
    "list": _summarize_list,
    "web_search": _summarize_web_search,
    "fetch": _summarize_fetch,
    "web_extract": _summarize_web_extract,
    "bash": _summarize_shell,
    "shell": _summarize_shell,
    "run_command": _summarize_shell,
    "execute": _summarize_shell,
    "edit": _summarize_edit,
    "replace": _summarize_edit,
    "write": _summarize_edit,
    "write_file": _summarize_edit,
    "patch": _summarize_edit,
}


# Seed on import so the first render before any refresh still works.
clear_tool_registry()


def _truncate_arg(val: str, key: str, max_len: int) -> str:
    """Truncate a tool argument for display, preserving the meaningful part."""
    short = val.strip().replace("\n", " ")
    if len(short) <= max_len:
        return short
    # For path-like args, keep the filename and truncate the middle
    if key in _PATH_ARGS or "/" in short:
        # Find the last path component
        last_sep = short.rfind("/")
        if last_sep > 0:
            tail = short[last_sep:]  # e.g. "/conversation.py"
            if len(tail) < max_len - 4:  # room for ".../" prefix
                head_budget = max_len - len(tail) - 3  # 3 for "..."
                return short[:head_budget] + "..." + tail
    # Default: truncate from the right
    return short[:max_len] + "..."


def _format_tool_label(name: str, args: dict[str, t.Any], max_arg_len: int = 60) -> str:
    """Format tool name with its key argument: ``read(pyproject.toml)``."""
    key_names = _TOOL_KEY_ARGS.get(name.lower(), [])
    for key in key_names:
        val = args.get(key)
        if isinstance(val, str) and val.strip():
            return f"{name}({_truncate_arg(val, key, max_arg_len)})"
        if isinstance(val, list):
            values = [item.strip() for item in val if isinstance(item, str) and item.strip()]
            if values:
                first = _truncate_arg(values[0], key, max_arg_len)
                if len(values) == 1:
                    return f"{name}({first})"
                return f"{name}({first}, +{len(values) - 1})"
    # Fallback: show first string arg if short enough
    for val in args.values():
        if isinstance(val, str) and val.strip() and len(val) < 40:
            short = val.strip().replace("\n", " ")
            return f"{name}({short})"
    return name


def _summarize_tool_result(name: str, args: dict[str, t.Any], result: t.Any) -> str | None:
    """Return a compact one-line summary of a tool result.

    Routes through the registered summarizer for ``name`` (if any),
    otherwise falls back to the generic first-line summary. Always
    honors the shared "output truncated/saved" markers before dispatch.
    """
    if result is None:
        return None

    text = _get_result_text(result)
    if not text.strip():
        return None

    offload_match = re.search(
        r"\.\.\. \[(?P<lines>\d+) lines truncated — full output saved to (?P<path>[^\]]+)\] \.\.\.",
        text,
    )
    if offload_match:
        lines = offload_match.group("lines")
        path = offload_match.group("path")
        return f"Output truncated ({lines} lines). Saved to {path}."

    if "full output saved to" in text:
        path_match = re.search(r"full output saved to (?P<path>[^\s\]]+)", text)
        if path_match:
            return f"Output saved to {path_match.group('path')}."

    summarizer = _TOOL_SUMMARIZERS.get(name.lower())
    if summarizer is not None:
        return summarizer(name, args, result)

    return _first_line(text) or None
