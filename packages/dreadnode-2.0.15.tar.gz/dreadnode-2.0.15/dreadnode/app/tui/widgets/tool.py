"""Widgets and helpers for displaying tool calls."""

from __future__ import annotations

import re
from typing import TYPE_CHECKING, Any

from rich.text import Text
from textual.reactive import reactive
from textual.widget import Widget

from dreadnode.app.tui.theme import ACCENT, ERROR, FG_FAINTEST, FG_MUTED

if TYPE_CHECKING:
    from rich.console import RenderableType


def render_tool_call(
    label: str,
    *,
    meta: str | None = None,
    details: str = "",
    meta_style: str = FG_FAINTEST,
) -> Text:
    """Render a tool call as Rich Text.

    Pure rendering function — no awareness of display modes.
    Used by ToolCall.render() as the single output path.

    ``meta_style`` colors the ``↳ <meta>`` line; defaults to the same
    dim gray used for summaries. Errored calls pass :data:`ERROR` so the
    failure pops without changing the tool-name color.
    """
    text = Text()
    text.append("│ ", style=FG_FAINTEST)

    match = re.match(r"^([a-zA-Z0-9_-]+)\((.*)\)$", label)
    if match:
        name, args = match.groups()
        text.append(name, style=ACCENT)
        text.append(f"({args})", style=FG_MUTED)
    else:
        text.append(label, style=ACCENT)

    if meta:
        # Multi-line metas (typically multi-line errors like
        # "Command failed (1):\n<stderr>...") need each continuation
        # line prefixed with the gutter so the bordered widget stays
        # visually contiguous instead of leaking bare text into the
        # conversation flow.
        meta_lines = meta.splitlines() or [""]
        text.append("\n│ ↳ ", style=meta_style)
        text.append(meta_lines[0], style=meta_style)
        for line in meta_lines[1:]:
            text.append("\n│   ", style=meta_style)
            text.append(line, style=meta_style)

    if details:
        lines = details.splitlines()
        prefix = "\n│   " if meta else "\n│ ↳ "
        text.append(f"{prefix}{lines[0]}", style=FG_FAINTEST)
        for line in lines[1:]:
            text.append(f"\n│   {line}", style=FG_FAINTEST)

    return text


class ToolCall(Widget):
    """A widget to display a tool call — in-progress or completed.

    Used by both the live interactive stream (tool_start → tool_end) and the
    transcript rebuild path. Stores full data; display mode is resolved
    at render time via app._output_mode.
    """

    tool_name: reactive[str] = reactive("")
    meta: reactive[str] = reactive("")
    details: reactive[str] = reactive("")
    error: reactive[str] = reactive("")

    def __init__(
        self,
        *,
        name: str,
        details: str = "",
        meta: str | None = None,
        error: str | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.tool_name = name
        self.details = details
        self.meta = meta or ""
        self.error = error or ""

    def _output_mode(self) -> str:
        try:
            return self.app.output_mode  # type: ignore[attr-defined]
        except Exception:
            return "compact"

    def _get_visible_details(self) -> str:
        """Return details respecting the app-level output mode.

        Applies 8-line truncation for display. The full details are
        always stored on the widget — truncation is render-time only.
        """
        if not self.details:
            return ""
        if self._output_mode() != "expanded":
            return ""
        lines = self.details.splitlines()
        if len(lines) > 8:
            omitted = len(lines) - 6
            return "\n".join(lines[:3] + [f"... {omitted} lines omitted ..."] + lines[-3:])
        return self.details

    def _get_visible_error(self) -> str:
        """Return the error string respecting the app-level output mode.

        Mirrors :meth:`_get_visible_details`: compact mode keeps the
        first line only (so the failure is still visible at a glance
        without a multi-screen traceback dominating the conversation),
        expanded mode shows the full error with the same 8-line
        truncation applied to long bodies.
        """
        if not self.error:
            return ""
        lines = self.error.splitlines() or [""]
        if self._output_mode() != "expanded":
            first = lines[0]
            if len(lines) > 1:
                return f"{first} (+{len(lines) - 1} more lines)"
            return first
        if len(lines) > 8:
            omitted = len(lines) - 6
            return "\n".join(lines[:3] + [f"... {omitted} lines omitted ..."] + lines[-3:])
        return self.error

    def complete(
        self,
        *,
        meta: str | None = None,
        details: str = "",
        error: str | None = None,
    ) -> None:
        """Transition from in-progress to completed state."""
        if meta is not None:
            self.meta = meta
        self.details = details
        if error:
            self.error = error

    def render(self) -> RenderableType:
        """Render the tool call."""
        if self.error:
            visible_error = self._get_visible_error()
            return render_tool_call(
                self.tool_name,
                meta=f"error: {visible_error}",
                meta_style=ERROR,
            )
        visible_details = self._get_visible_details()
        return render_tool_call(
            self.tool_name,
            meta=None if visible_details else (self.meta or None),
            details=visible_details,
        )
