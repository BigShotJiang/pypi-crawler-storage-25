"""Full-screen session picker — DataTable with search + filter chips.

Replaces the former Rich-Text scroll list with a DataTable for
preview/origin/project/agent/updated/labels. In-process sessions render
immediately; a platform browse page is async-merged on top so
worker-created and archived sessions show up without blocking the UI.

A read-only facets sidebar was dropped from this pass — it duplicated
information the search bar and filter-chip strip already carry. The
facets *endpoint* (``/api/sessions/facets``) and runtime wrapper stay
in place for a future clickable-sidebar follow-up.

Return contract (unchanged from the previous picker):
  None                    — Escape pressed, no selection
  "__new__"               — N pressed, create new session
  "<session_id>"          — Enter on a row
  "__deletes__:a,b|<x>"   — pending deletes + action
"""

import typing as t
from dataclasses import dataclass
from datetime import UTC, datetime

from loguru import logger
from rich.text import Text
from textual import work
from textual.screen import Screen
from textual.widgets import DataTable, Static

from dreadnode.app.client.models import SessionInfo
from dreadnode.app.tui.screens.base import (
    _bind_status_bar_to_app,
    handle_search_input_key,
    render_hint_bar,
    render_screen_header,
    render_search_bar,
)
from dreadnode.app.tui.theme import (
    ACCENT,
    ERROR,
    FG_FAINTEST,
    FG_MUTED,
    FG_SUBTLE,
    WARNING,
)
from dreadnode.app.tui.turn_state_phase import (
    TurnStatePhase,
    is_running_phase,
)
from dreadnode.app.tui.widgets.status_bar import StatusBar

if t.TYPE_CHECKING:
    from textual.app import ComposeResult
    from textual.events import Key

    from dreadnode.app.client.runtime_client import RuntimeClient
    from dreadnode.app.tui.app import SessionRecord


# ── Helpers ──────────────────────────────────────────────────────────────────


def _relative_time(iso_ts: str | None) -> str:
    """Format an ISO timestamp as a human-friendly relative string."""
    if not iso_ts:
        return "-"
    try:
        dt = datetime.fromisoformat(iso_ts)
    except ValueError:
        return iso_ts[:16]
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=UTC)
    delta = datetime.now(tz=UTC) - dt
    seconds = int(delta.total_seconds())
    if seconds < 60:
        return "just now"
    minutes = seconds // 60
    if minutes < 60:
        return f"{minutes}m ago"
    hours = minutes // 60
    if hours < 24:
        return f"{hours}h ago"
    days = hours // 24
    if days < 7:
        return f"{days}d ago"
    return dt.strftime("%b %d")


def _truncate(text: str, max_len: int) -> str:
    text = text.strip().replace("\n", " ")
    if len(text) > max_len:
        return text[: max_len - 1] + "\u2026"
    return text


def _preview(info: SessionInfo, record: "SessionRecord | None", max_len: int = 60) -> Text:
    """Pick the best short description for a row.

    Precedence:
      1. ``SessionRecord.title`` — the TUI-local label the app sets when a
         session becomes meaningful (takes priority so a user-edited title
         survives platform refreshes).
      2. ``SessionInfo.title`` — platform-persisted title.
      3. ``SessionInfo.preview`` — server-generated snippet.
      4. First user message in the cached transcript (in-process only).
      5. Muted ``(empty)`` placeholder for sessions with no content yet.

    Returns a Rich ``Text`` — plain for the populated branches (so user
    content containing ``[`` isn't mis-parsed as markup) and styled for
    the empty placeholder.
    """
    if record is not None and record.title:
        return Text(_truncate(record.title, max_len))
    if info.title:
        return Text(_truncate(info.title, max_len))
    if info.preview:
        return Text(_truncate(info.preview, max_len))
    if record is not None:
        for entry in record.transcript:
            if entry.role == "user" and entry.content:
                return Text(_truncate(entry.content, max_len))
    return Text("(empty)", style=FG_FAINTEST)


def _origin_label(info: SessionInfo) -> str:
    """Collapse ``session.origin`` (SES-ORG-001) to a single display string.

    ``user`` is the runtime default; anything else (``eval``, ``worker``)
    is a writer-stamped discriminator. For ``user`` rows, prefer the
    owner's username/email from ``created_by`` when we have it so the
    column reads as an identity, not a generic ``user`` chip.
    """
    if info.origin and info.origin != "user":
        return info.origin
    if info.created_by is not None:
        return info.created_by.username or info.created_by.email or "user"
    return "user"


def _status_badges(info: SessionInfo, record: "SessionRecord | None", *, is_active: bool) -> str:
    """Inline chips rendered before the preview — 'active', 'running',
    'frozen', 'archived', etc. Returned as a single string so we can stuff
    it into one DataTable cell; the cell is pre-formatted Rich markup.
    """
    chips: list[tuple[str, str]] = []
    if is_active:
        chips.append(("active", ACCENT))
    if info.frozen_at:
        chips.append(("frozen", WARNING))
    if info.archived_at:
        chips.append(("archived", FG_MUTED))
    if info.visibility == "workspace":
        chips.append(("shared", FG_SUBTLE))

    state = record.turn_state if record is not None else None
    if state is not None:
        if is_running_phase(state.phase):
            chips.append(("running", ACCENT))
        elif state.phase is TurnStatePhase.AWAITING_PERMISSION:
            chips.append(("approval", WARNING))
        elif state.phase is TurnStatePhase.AWAITING_INPUT:
            chips.append(("input", WARNING))
        elif state.phase is TurnStatePhase.FAILED:
            chips.append(("failed", ERROR))

    if record is not None:
        if record.unread_events > 0:
            chips.append((f"{record.unread_events} unread", FG_MUTED))
        if record.queued_messages:
            chips.append((f"{len(record.queued_messages)} queued", FG_MUTED))
        if record.resync_required:
            chips.append(("stale", WARNING))

    if not chips:
        return ""
    text = Text()
    for i, (label, color) in enumerate(chips):
        if i > 0:
            text.append(" ")
        text.append(f"[{label}]", style=color)
    return text.markup


def _labels_cell(info: SessionInfo) -> str:
    """Flatten the label map into a compact display string.

    Every label is rendered as ``key=val``, joined with spaces. Origin
    lives in its own column (SES-ORG-007) and isn't a label anymore, so
    nothing is filtered out here.
    """
    parts: list[str] = []
    for key, values in sorted(info.labels.items()):
        for value in values:
            parts.append(f"{key}={value}")
    joined = " ".join(parts)
    return _truncate(joined, 40) if joined else "-"


# ── Search bar filter grammar ────────────────────────────────────────────────


@dataclass(frozen=True, slots=True)
class _ParsedSearch:
    """Decomposed query string: free-text plus structured `key:value` filters.

    Grammar matches the runtimes-picker style (``state:running``, etc.)
    so muscle memory transfers. Known keys become server-side filter
    params on :meth:`RuntimeClient.browse_sessions`; any unknown
    ``key:value`` token is dropped into ``free_text`` so it becomes
    part of the full-text ``search`` param rather than silently
    disappearing.
    """

    free_text: str = ""
    archived: t.Literal["active", "archived", "any"] = "active"
    origin: str | None = None
    project: str | None = None

    def browse_kwargs(self) -> dict[str, t.Any]:
        kwargs: dict[str, t.Any] = {"archived": self.archived}
        if self.origin is not None:
            kwargs["origin"] = [self.origin]
            # SES-LST-015 / SES-LST-009: an explicit workload origin
            # (``eval`` today) needs the workload-hide default toggled
            # off to return non-empty results.
            if self.origin != "user":
                kwargs["include_workload_sessions"] = True
        if self.project is not None:
            kwargs["project_id"] = [self.project]
        if self.free_text:
            kwargs["search"] = self.free_text
        return kwargs


def _parse_search(query: str) -> _ParsedSearch:
    text_terms: list[str] = []
    archived: t.Literal["active", "archived", "any"] = "active"
    origin: str | None = None
    project: str | None = None
    for token in query.split():
        if ":" in token:
            key, value = token.split(":", 1)
            key = key.strip().lower()
            value = value.strip()
            if key == "status" and value in {"active", "archived", "any"}:
                archived = t.cast(
                    "t.Literal['active', 'archived', 'any']",
                    value,
                )
                continue
            if key == "origin" and value:
                origin = value
                continue
            if key == "project" and value:
                project = value
                continue
        text_terms.append(token)
    return _ParsedSearch(
        free_text=" ".join(text_terms).strip(),
        archived=archived,
        origin=origin,
        project=project,
    )


# ── Row model ────────────────────────────────────────────────────────────────


@dataclass(slots=True)
class _Row:
    """One visible session — backed by a SessionRecord for in-process rows,
    or a plain SessionInfo for platform-only rows arrived from browse.

    ``record`` is ``None`` for rows that exist only on the platform; in
    that case the row has no live TurnState, unread count, or queued
    messages — it's strictly metadata for browsing purposes.
    """

    session_id: str
    info: SessionInfo
    record: "SessionRecord | None" = None

    @property
    def sort_key(self) -> str:
        return self.info.updated_at or self.info.created_at or ""


# ── Screen ───────────────────────────────────────────────────────────────────


class SessionPickerScreen(Screen[str | None]):
    """Full-screen session picker — DataTable + facets sidebar."""

    def __init__(
        self,
        sessions: dict[str, "SessionRecord"],
        active_session_id: str | None = None,
        managed_client: "RuntimeClient | None" = None,
        **kwargs: t.Any,
    ) -> None:
        super().__init__(**kwargs)
        self._sessions = dict(sessions)
        self._active_session_id = active_session_id
        self._managed_client = managed_client

        # Merged row state. `_platform_rows` holds the latest platform
        # page; `_rows` is the computed union used for rendering.
        self._platform_rows: dict[str, SessionInfo] = {}
        self._rows: list[_Row] = []

        # UI state.
        self._cursor: int = 0
        self._search_query: str = ""
        self._pending_deletes: list[str] = []
        self._platform_loading: bool = False

    # ── Compose ──────────────────────────────────────────────────────────

    def compose(self) -> "ComposeResult":
        yield Static(id="session-header")
        yield Static(id="session-search")
        yield Static(id="session-filter-chips")
        yield DataTable(id="session-table")
        yield Static(id="session-hint-bar")
        yield StatusBar(id="global-status-bar")

    def on_mount(self) -> None:
        _bind_status_bar_to_app(self, self.query_one("#global-status-bar", StatusBar))

        table = self.query_one("#session-table", DataTable)
        table.cursor_type = "row"
        table.zebra_stripes = True
        table.add_columns(
            "",  # status chips
            "Preview",
            "Origin",
            "Project",
            "Agent",
            "Updated",
            "Labels",
        )

        self._rebuild_rows()
        self._render_all()
        table.focus()
        self._load_platform_page()

    # ── Keyboard handling ────────────────────────────────────────────────

    def on_key(self, event: "Key") -> None:
        key = event.key

        # Let control sequences and function keys pass through to app bindings
        if key.startswith("ctrl+") or (key.startswith("f") and key[1:].isdigit()):
            return

        if key == "up":
            if self._rows:
                self._cursor = max(0, self._cursor - 1)
                self._apply_cursor_to_table()
        elif key == "down":
            if self._rows:
                self._cursor = min(len(self._rows) - 1, self._cursor + 1)
                self._apply_cursor_to_table()
        elif key == "enter":
            if self._rows and 0 <= self._cursor < len(self._rows):
                sid = self._rows[self._cursor].session_id
                self._dismiss_with_deletes(sid)
        elif key == "escape":
            if self._search_query:
                self._search_query = ""
                self._cursor = 0
                self._reload_on_search_change()
            else:
                self._dismiss_with_deletes(None)
        elif event.character == "n" and not self._search_query:
            self._dismiss_with_deletes("__new__")
        elif event.character == "d" and not self._search_query:
            self._delete_current()
        else:
            search_result = handle_search_input_key(
                self._search_query,
                key=key,
                character=event.character,
            )
            if not search_result.handled:
                return
            if search_result.new_query == self._search_query:
                return
            self._search_query = search_result.new_query
            if search_result.cursor_should_reset:
                self._cursor = 0
            self._reload_on_search_change()

        event.prevent_default()
        event.stop()

    # ── Exit ─────────────────────────────────────────────────────────────

    def _dismiss_with_deletes(self, result: str | None) -> None:
        """Dismiss the screen, bundling any pending deletes into the result.

        Kept byte-identical to the previous picker so ``_on_session_picked``
        on the app doesn't need to branch by screen version. The app
        parses ``__deletes__:a,b|<action>`` and fans deletes out to
        ``managed_client.delete_session``.
        """
        if self._pending_deletes:
            deletes = ",".join(self._pending_deletes)
            if result is None:
                self.dismiss(f"__deletes__:{deletes}")
            else:
                self.dismiss(f"__deletes__:{deletes}|{result}")
        else:
            self.dismiss(result)

    def _delete_current(self) -> None:
        if not self._rows or self._cursor >= len(self._rows):
            return
        sid = self._rows[self._cursor].session_id
        # Only in-process sessions can be locally deleted pre-dismiss. For
        # platform-only rows we still queue the delete — the app routes it
        # through ``managed_client.delete_session``, which hits the platform
        # regardless of in-process presence.
        self._pending_deletes.append(sid)
        self._sessions.pop(sid, None)
        self._platform_rows.pop(sid, None)
        self._rebuild_rows()
        self._cursor = min(self._cursor, max(0, len(self._rows) - 1))
        self._render_all()

    # ── Data merge ───────────────────────────────────────────────────────

    def _rebuild_rows(self) -> None:
        """Recompute the merged row list from in-process + platform state,
        applying the current search filter and pinning the active row first.
        """
        parsed = _parse_search(self._search_query)

        # Union — in-process SessionRecord wins over platform SessionInfo
        # when the same session_id appears in both.
        unified: dict[str, _Row] = {}
        for sid, info in self._platform_rows.items():
            if self._skip_by_archive_filter(info, parsed):
                continue
            unified[sid] = _Row(session_id=sid, info=info, record=None)
        for sid, record in self._sessions.items():
            # Don't show pending-deleted rows.
            if sid in self._pending_deletes:
                continue
            if self._skip_by_archive_filter(record.info, parsed):
                continue
            unified[sid] = _Row(session_id=sid, info=record.info, record=record)

        rows = list(unified.values())
        rows = [r for r in rows if self._row_matches_filter(r, parsed)]
        rows.sort(key=lambda r: r.sort_key, reverse=True)

        if self._active_session_id is not None:
            active_row = unified.get(self._active_session_id)
            if active_row is not None and self._row_matches_filter(active_row, parsed):
                rows = [active_row] + [r for r in rows if r.session_id != active_row.session_id]

        self._rows = rows
        self._cursor = min(self._cursor, max(0, len(self._rows) - 1))

    @staticmethod
    def _skip_by_archive_filter(info: SessionInfo, parsed: _ParsedSearch) -> bool:
        """Filter out rows whose archived state doesn't match the parsed
        archived tri-state. The platform already respects this param on
        the browse path, but in-process rows bypass that filter — we
        apply the same predicate here so the merged view stays coherent.
        """
        if parsed.archived == "any":
            return False
        is_archived = info.archived_at is not None
        if parsed.archived == "archived":
            return not is_archived
        # "active"
        return is_archived

    @staticmethod
    def _row_matches_filter(row: _Row, parsed: _ParsedSearch) -> bool:
        """Client-side free-text fallback for in-process rows.

        The platform `browse_sessions` call already applies `search` on
        its side, but in-process rows don't round-trip the platform on
        this path. Mirroring the free-text predicate here means typing
        in the search bar filters both sets consistently.

        Includes ``record.title`` (TUI-local label) and the cached
        transcript's first user message — the same signals ``_preview``
        uses — so a row that's only findable by its locally-cached
        title doesn't silently drop out when the user searches for a
        word they can see on screen.
        """
        info = row.info
        if parsed.origin is not None:
            if info.origin != parsed.origin:
                return False
        if parsed.project is not None and info.project != parsed.project:
            return False
        if not parsed.free_text:
            return True
        needle = parsed.free_text.lower()
        haystack_parts: list[str] = [
            info.title or "",
            info.preview or "",
            info.session_id,
            info.agent or "",
            info.capability or "",
            info.project or "",
        ]
        if row.record is not None:
            if row.record.title:
                haystack_parts.append(row.record.title)
            for entry in row.record.transcript:
                if entry.role == "user" and entry.content:
                    haystack_parts.append(entry.content)
                    break  # first user message is enough for search
        return needle in " ".join(haystack_parts).lower()

    # ── Async platform load ──────────────────────────────────────────────

    def _reload_on_search_change(self) -> None:
        self._rebuild_rows()
        self._render_all()
        self._load_platform_page()

    @work(exclusive=True, group="session-browse")
    async def _load_platform_page(self) -> None:
        """Fetch the current filter's browse page + facets from the runtime.

        Single in-flight policy via ``exclusive=True`` — rapid search
        typing cancels stale fetches so the UI only ever reflects the
        latest query. The in-process view stays visible the whole time.
        """
        if self._managed_client is None:
            return
        self._platform_loading = True
        parsed = _parse_search(self._search_query)
        browse_kwargs = parsed.browse_kwargs()
        try:
            envelope = await self._managed_client.browse_sessions(limit=50, **browse_kwargs)
        except Exception:
            logger.opt(exception=True).warning("Failed to browse platform sessions")
            self._platform_loading = False
            return
        self._platform_rows = {s.session_id: s for s in envelope.sessions}
        self._platform_loading = False
        self._rebuild_rows()
        self._render_all()

    # ── Render ───────────────────────────────────────────────────────────

    def _render_all(self) -> None:
        self._render_header()
        self._render_search()
        self._render_filter_chips()
        self._render_table()
        self._render_hints()

    def _render_header(self) -> None:
        self.query_one("#session-header", Static).update(
            render_screen_header(
                "Sessions",
                "Browse and resume conversation sessions",
                count=len(self._rows),
            )
        )

    def _render_search(self) -> None:
        self.query_one("#session-search", Static).update(
            render_search_bar(
                self._search_query,
                cursor=self._cursor,
                visible_count=len(self._rows),
                placeholder=("Search\u2026  filters: status:archived  origin:user  project:<key>"),
            )
        )

    def _render_filter_chips(self) -> None:
        parsed = _parse_search(self._search_query)
        chips: list[tuple[str, str]] = []
        if parsed.archived != "active":
            chips.append((f"status:{parsed.archived}", WARNING))
        if parsed.origin is not None:
            chips.append((f"origin:{parsed.origin}", ACCENT))
        if parsed.project is not None:
            chips.append((f"project:{parsed.project}", ACCENT))
        if self._platform_loading:
            chips.append(("loading\u2026", FG_FAINTEST))
        text = Text()
        for index, (label, color) in enumerate(chips):
            if index > 0:
                text.append("  ", style=FG_FAINTEST)
            text.append(f"[{label}]", style=color)
        self.query_one("#session-filter-chips", Static).update(text)

    def _render_table(self) -> None:
        table = self.query_one("#session-table", DataTable)
        table.clear()
        for row in self._rows:
            is_active = row.session_id == self._active_session_id
            chips = _status_badges(row.info, row.record, is_active=is_active)
            preview = _preview(row.info, row.record)
            origin = _origin_label(row.info)
            project = row.info.project or "-"
            agent = row.info.agent or row.info.capability or "default"
            updated = _relative_time(row.info.updated_at or row.info.created_at)
            labels = _labels_cell(row.info)
            table.add_row(
                Text.from_markup(chips) if chips else "",
                preview,
                origin,
                project,
                agent,
                updated,
                labels,
                key=row.session_id,
            )

        if self._rows:
            self._apply_cursor_to_table()

    def _apply_cursor_to_table(self) -> None:
        table = self.query_one("#session-table", DataTable)
        if 0 <= self._cursor < len(self._rows):
            table.move_cursor(row=self._cursor, column=0, animate=False, scroll=True)
            self._render_search()

    def _render_hints(self) -> None:
        hints: list[tuple[str, str]] = [
            ("Enter", "select"),
            ("N", "new"),
            ("D", "delete"),
            ("Esc", "back"),
            ("Type", "search"),
        ]
        self.query_one("#session-hint-bar", Static).update(render_hint_bar(hints))

    # ── DataTable click / highlight wiring ───────────────────────────────

    def on_data_table_row_highlighted(self, event: DataTable.RowHighlighted) -> None:
        self._cursor = event.cursor_row
        self._render_search()

    def on_data_table_row_selected(self, event: DataTable.RowSelected) -> None:
        if event.row_key is None:
            return
        sid = str(event.row_key.value)
        self._dismiss_with_deletes(sid)
