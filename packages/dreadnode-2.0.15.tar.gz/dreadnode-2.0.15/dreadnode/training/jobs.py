"""Sandbox-facing job payloads, entrypoints, and result contracts for training."""

from __future__ import annotations

import argparse
import asyncio
import importlib
import json
import os
import re
from dataclasses import fields
from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal

import httpx
import numpy as np
from pydantic import BaseModel, ConfigDict, Field, PrivateAttr
from typing_extensions import Self

from dreadnode import Dreadnode
from dreadnode.agents import Agent
from dreadnode.agents.tools import Toolset, tool_method
from dreadnode.generators.generator import GeneratedMessage, GenerateParams, Generator, Usage
from dreadnode.generators.message import Message
from dreadnode.tools.task import finish_task, give_up_on_task
from dreadnode.training.etl import (
    OpenAIConversation,
    RLPromptRow,
    load_conversations_from_worlds_dataset,
    load_prompt_rows_from_dataset,
    load_rl_prompt_rows_from_worlds_dataset,
    load_sft_conversations_from_worlds_dataset,
)
from dreadnode.training.etl.sft import (
    SFTConversation,
    load_openai_conversations_from_dataset,
    load_sft_conversations_from_dataset,
)
from dreadnode.training.recipes import (
    RewardPromptRow,
    RewardRecipeRegistry,
    RewardTaskDefinition,
)
from dreadnode.training.rollouts.worlds import (
    build_worlds_reward_shaper_from_config,
    run_worlds_agent_rollout,
)
from dreadnode.training.tinker import (
    TinkerSFTConfig,
    TinkerSFTTrainer,
    load_from_conversations,
    load_from_messages,
)
from dreadnode.training.tinker.rl import (
    TinkerRLConfig,
    TinkerRLRolloutGroup,
    train_tinker_rl,
)

if TYPE_CHECKING:
    from collections.abc import Sequence

    from dreadnode.training.tinker.trainer import TrainingState


TrainingJobBackend = Literal["tinker", "ray"]
TrainingJobTrainerType = Literal["sft", "rl"]
TrainingJobStatus = Literal["completed", "failed", "cancelled"]


class TrainingCapabilityPayload(BaseModel):
    """Capability metadata resolved by the API control plane."""

    model_config = ConfigDict(extra="forbid")

    id: str
    name: str
    version: str
    runtime_digest: str | None = None
    manifest: dict[str, Any]
    file_manifest: list[dict[str, Any]]
    artifact_s3_prefix: str
    entry_prompt: str | None = None


class TrainingDatasetPayload(BaseModel):
    """Dataset metadata resolved by the API control plane."""

    model_config = ConfigDict(extra="forbid")

    id: str
    reference: str
    name: str
    version: str
    format: str
    row_count: int | None = None
    splits: dict[str, Any] | None = None
    artifacts: dict[str, Any]
    summary: str | None = None


class TrainingTaskPayload(BaseModel):
    """Task metadata resolved by the API control plane."""

    model_config = ConfigDict(extra="forbid")

    id: str
    reference: str
    name: str
    version: str
    instruction: str | None = None
    ports: dict[str, Any] | None = None
    verification: dict[str, Any] | None = None
    solution: dict[str, Any] | None = None
    sandbox_provider: str
    s3_key: str


class TrainingWorldPayload(BaseModel):
    """Worlds backend metadata resolved by the API control plane."""

    model_config = ConfigDict(extra="forbid")

    id: str
    name: str | None = None
    manifest_backend_id: str | None = None
    server_url: str
    artifact_refs: dict[str, Any] = Field(default_factory=dict)
    stats: dict[str, Any] = Field(default_factory=dict)


class BaseTrainingJobPayload(BaseModel):
    """Common payload fields for hosted training execution."""

    model_config = ConfigDict(extra="forbid")

    schema_version: Literal["2026-03-18"] = "2026-03-18"
    job_id: str
    organization_id: str
    workspace_id: str
    created_by: str | None = None
    name: str | None = None
    backend: TrainingJobBackend
    trainer_type: TrainingJobTrainerType
    algorithm: str | None = None
    model: str
    project_ref: str | None = None
    run_ref: str | None = None
    tags: list[str] = Field(default_factory=list)
    config: dict[str, Any] = Field(default_factory=dict)


class TinkerSFTJobPayload(BaseTrainingJobPayload):
    """Resolved payload for a Tinker SFT sandbox job."""

    backend: Literal["tinker"] = "tinker"
    trainer_type: Literal["sft"] = "sft"
    capability: TrainingCapabilityPayload
    dataset: TrainingDatasetPayload | None = None
    trajectory_datasets: list[TrainingDatasetPayload] = Field(default_factory=list)
    eval_dataset: TrainingDatasetPayload | None = None


class TinkerRLJobPayload(BaseTrainingJobPayload):
    """Resolved payload for a Tinker RL sandbox job."""

    backend: Literal["tinker"] = "tinker"
    trainer_type: Literal["rl"] = "rl"
    capability: TrainingCapabilityPayload
    task: TrainingTaskPayload | None = None
    world: TrainingWorldPayload | None = None
    prompt_dataset: TrainingDatasetPayload | None = None
    trajectory_datasets: list[TrainingDatasetPayload] = Field(default_factory=list)
    reward_recipe: dict[str, Any] | None = None


_WORLDS_AGENT_SYSTEM_PROMPT = (
    "You are an expert penetration tester operating in a simulated Active Directory "
    "environment. Explore the network, enumerate resources, obtain credentials, and "
    "escalate privileges toward the stated goal. Execute commands methodically, use "
    "tool results to inform the next step, and finish the task when you have reached "
    "the goal or cannot make further progress."
)


class _WorldsHTTPToolset(Toolset):
    """Minimal HTTP toolset for interacting with a live Worlds backend."""

    model_config = ConfigDict(arbitrary_types_allowed=True)

    server_url: str

    _client: httpx.AsyncClient | None = PrivateAttr(default=None)
    _principal_id: str | None = PrivateAttr(default=None)
    _host_id: str | None = PrivateAttr(default=None)
    _domain: str | None = PrivateAttr(default=None)
    _known_creds: list[str] = PrivateAttr(default_factory=list)
    _compromised_hosts: list[str] = PrivateAttr(default_factory=list)

    async def __aenter__(self) -> Self:
        if self._client is None:
            self._client = httpx.AsyncClient(base_url=self.server_url, timeout=30.0)
        return self

    async def __aexit__(self, *args: object) -> None:
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    @tool_method(catch=True, variants=["all"])
    async def list_commands(self) -> dict[str, Any]:
        """List the commands available in the Worlds environment."""

        client = self._require_client()
        response = await client.get("/commands")
        response.raise_for_status()
        payload = response.json()
        if isinstance(payload, dict):
            return payload
        return {"commands": []}

    @tool_method(catch=True, variants=["all"])
    async def run_command(self, command: str) -> dict[str, Any]:
        """Execute a shell-like command against the Worlds backend."""

        client = self._require_client()
        request_body = {
            "command": command,
            "principal_id": self._principal_id,
            "host_id": self._host_id,
            "domain": self._domain,
            "known_creds": list(self._known_creds),
            "compromised_hosts": list(self._compromised_hosts),
        }
        response = await client.post("/run", json=request_body)
        response.raise_for_status()
        result = response.json()
        if not isinstance(result, dict):
            raise TypeError("Worlds backend returned a non-object run response")

        context_updates = result.get("context_updates")
        if isinstance(context_updates, dict):
            principal_id = context_updates.get("principal_id")
            host_id = context_updates.get("host_id")
            domain = context_updates.get("domain")
            compromised_host = context_updates.get("compromised_host")
            acquired_cred = context_updates.get("acquired_cred")
            if isinstance(principal_id, str):
                self._principal_id = principal_id
            if isinstance(host_id, str):
                self._host_id = host_id
            if isinstance(domain, str):
                self._domain = domain
            if (
                isinstance(compromised_host, str)
                and compromised_host not in self._compromised_hosts
            ):
                self._compromised_hosts.append(compromised_host)
            if isinstance(acquired_cred, str) and acquired_cred not in self._known_creds:
                self._known_creds.append(acquired_cred)

        return {
            "stdout": result.get("stdout", ""),
            "stderr": result.get("stderr", ""),
            "exit_code": result.get("exit_code", 0),
            "events": result.get("events", []),
            "context_updates": context_updates or {},
        }

    @tool_method(catch=True, variants=["all"])
    async def get_context(self) -> dict[str, Any]:
        """Return the current mutable rollout context."""

        return {
            "principal_id": self._principal_id,
            "host_id": self._host_id,
            "domain": self._domain,
            "known_creds": list(self._known_creds),
            "compromised_hosts": list(self._compromised_hosts),
        }

    def _require_client(self) -> httpx.AsyncClient:
        if self._client is None:
            raise RuntimeError("Worlds HTTP client has not been initialized")
        return self._client


class _TinkerSamplingGenerator(Generator):
    """Generator adapter that drives DN Agents from a Tinker sampling client."""

    model_config = ConfigDict(arbitrary_types_allowed=True)

    sampling_client: Any = Field(exclude=True)
    tokenizer: Any = Field(exclude=True)

    async def supports_function_calling(self) -> bool | None:
        return False

    def _generate_single_message(
        self,
        *,
        message_batch: list[Message],
        batch_params: GenerateParams,
    ) -> GeneratedMessage | BaseException:
        try:
            prompt_text = _render_prompt_text(
                tokenizer=self.tokenizer,
                messages=[
                    message.model_dump(exclude_none=True, mode="json")
                    for message in message_batch
                ],
            )
            prompt_tokens = self.tokenizer.encode(
                prompt_text,
                add_special_tokens=True,
            )
            tinker = _get_tinker_module()
            sampling_params = _build_sampling_params(
                tinker=tinker,
                params=batch_params,
            )
            sample_response = self.sampling_client.sample(
                prompt=tinker.types.ModelInput.from_ints(tokens=prompt_tokens),
                sampling_params=sampling_params,
                num_samples=1,
            ).result()
            sequence = _extract_first_sequence(sample_response)
            completion_tokens = list(getattr(sequence, "tokens", []))
            completion_text = self.tokenizer.decode(completion_tokens)
            usage = Usage(
                input_tokens=len(prompt_tokens),
                output_tokens=len(completion_tokens),
                total_tokens=len(prompt_tokens) + len(completion_tokens),
            )
            return GeneratedMessage(
                message=Message(role="assistant", content=completion_text),
                stop_reason=_stop_reason_from_sampling_response(sample_response),
                usage=usage,
                extra={"raw_generated_text": completion_text},
            )
        except Exception as exc:  # noqa: BLE001
            return exc

    async def generate_messages(
        self,
        messages: Sequence[Sequence[Message]],
        params: Sequence[GenerateParams],
    ) -> Sequence[GeneratedMessage | BaseException]:
        results: list[GeneratedMessage | BaseException] = []
        for message_batch, batch_params in zip(messages, params, strict=False):
            results.append(
                self._generate_single_message(
                    message_batch=list(message_batch),
                    batch_params=batch_params,
                )
            )
        return results


TrainingJobPayload = TinkerSFTJobPayload | TinkerRLJobPayload


class TrainingJobResult(BaseModel):
    """Structured result written back by sandboxed training execution."""

    model_config = ConfigDict(extra="forbid")

    status: TrainingJobStatus
    metrics: dict[str, Any] = Field(default_factory=dict)
    artifacts: dict[str, Any] = Field(default_factory=dict)
    external_job_id: str | None = None
    error: str | None = None


def _build_configured_dreadnode() -> Dreadnode:
    """Return a configured Dreadnode client from sandbox environment variables."""

    return Dreadnode().configure(
        server=os.environ["DREADNODE_SERVER"],
        api_key=os.environ["DREADNODE_API_KEY"],
        organization=os.environ["DREADNODE_ORGANIZATION"],
        workspace=os.environ["DREADNODE_WORKSPACE"],
        project=os.environ.get("DREADNODE_PROJECT") or None,
    )


def _build_tinker_sft_config(payload: TinkerSFTJobPayload) -> TinkerSFTConfig:
    """Build a Tinker SFT config from a sandbox job payload."""

    allowed_keys = {field.name for field in fields(TinkerSFTConfig)}
    config = {
        key: value
        for key, value in payload.config.items()
        if key in allowed_keys and value is not None
    }
    config["base_model"] = payload.model
    return TinkerSFTConfig(**config)


def _get_tinker_module() -> Any:
    """Return the installed Tinker runtime module."""

    try:
        return importlib.import_module("tinker")
    except ModuleNotFoundError as exc:
        raise RuntimeError("Tinker is not installed in the training environment") from exc


def _get_positive_int(
    config: dict[str, Any],
    key: str,
    *,
    default: int,
) -> int:
    value = config.get(key, default)
    if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
        return default
    return value


def _get_positive_float(
    config: dict[str, Any],
    key: str,
    *,
    default: float,
) -> float:
    value = config.get(key, default)
    if isinstance(value, bool) or not isinstance(value, int | float) or value <= 0:
        return default
    return float(value)


def _get_non_negative_float(
    config: dict[str, Any],
    key: str,
    *,
    default: float,
) -> float:
    value = config.get(key, default)
    if isinstance(value, bool) or not isinstance(value, int | float) or value < 0:
        return default
    return float(value)


def _get_optional_string(config: dict[str, Any], key: str) -> str | None:
    value = config.get(key)
    if not isinstance(value, str):
        return None
    normalized = value.strip()
    return normalized or None


def _get_string_list(config: dict[str, Any], key: str) -> list[str]:
    value = config.get(key)
    if not isinstance(value, list):
        return []
    return [item for item in value if isinstance(item, str) and item]


def _messages_from_conversations(
    conversations: list[SFTConversation],
) -> list[list[dict[str, str]]]:
    """Extract normalized message lists from ETL conversation records."""

    return [conversation.messages for conversation in conversations]


def _build_sft_metrics(
    *,
    state: TrainingState,
    train_examples: int,
    gradient_accumulation_steps: int,
    learning_rate: float,
    eval_examples: int,
    eval_loss: float | None,
) -> dict[str, Any]:
    """Build hosted-job-friendly summary metrics and history from Tinker training state."""

    losses = [float(loss) for loss in getattr(state, "losses", [])]
    metrics: dict[str, Any] = {
        "train/steps": int(getattr(state, "step", len(losses))),
        "train/num_examples": train_examples,
        "train/num_sequences_processed": int(
            getattr(state, "total_sequences_processed", 0)
        ),
        "train/num_tokens_processed": int(getattr(state, "total_tokens_processed", 0)),
        "train/gradient_accumulation_steps": gradient_accumulation_steps,
    }
    if losses:
        history_steps = list(range(1, len(losses) + 1))
        metrics.update(
            {
                "steps": history_steps,
                "train_loss": losses,
                "train/loss_last": losses[-1],
                "train/loss_mean": float(sum(losses) / len(losses)),
                "train/loss_best": min(losses),
            }
        )
        if learning_rate > 0:
            metrics["learning_rate"] = [learning_rate] * len(losses)
        if eval_loss is not None:
            metrics["val_loss"] = [None] * (len(losses) - 1) + [float(eval_loss)]
    if eval_examples > 0:
        metrics["eval/num_examples"] = eval_examples
    if eval_loss is not None:
        metrics["eval/loss"] = float(eval_loss)
    return metrics


def _select_prompt_batch(
    *,
    prompt_rows: list[RLPromptRow],
    step: int,
    batch_size: int,
) -> list[RLPromptRow]:
    if batch_size >= len(prompt_rows):
        return prompt_rows
    start = ((step - 1) * batch_size) % len(prompt_rows)
    batch = prompt_rows[start : start + batch_size]
    if len(batch) == batch_size:
        return batch
    remainder = batch_size - len(batch)
    return batch + prompt_rows[:remainder]


def _render_instruction(
    instruction: str | None,
    context: dict[str, str | int | None],
) -> str | None:
    if not instruction:
        return instruction

    def _replacer(match: re.Match[str]) -> str:
        key = match.group(1).strip()
        value = context.get(key)
        if value is None:
            return match.group(0)
        return str(value)

    return re.sub(r"\{\{\s*(\w+)\s*\}\}", _replacer, instruction)


def _render_task_instruction(
    *,
    prompt_row: RLPromptRow,
    task: TrainingTaskPayload | None,
) -> str | None:
    if task is None:
        return None
    if not task.instruction:
        return None
    rendered = _render_instruction(task.instruction, prompt_row.template_context)
    if rendered and "{{" not in rendered:
        return rendered.strip()
    return None


def _build_prompt_messages(
    *,
    prompt_row: RLPromptRow,
    capability_prompt: str | None,
    task_instruction: str | None,
) -> list[dict[str, str]]:
    system_parts = [
        part.strip()
        for part in (capability_prompt, task_instruction)
        if isinstance(part, str) and part.strip()
    ]
    messages: list[dict[str, str]] = []
    if system_parts:
        messages.append({"role": "system", "content": "\n\n".join(system_parts)})
    if prompt_row.messages:
        messages.extend(prompt_row.messages)
        return messages
    if prompt_row.prompt:
        messages.append({"role": "user", "content": prompt_row.prompt})
        return messages
    raise ValueError("Prompt row did not contain prompt text or messages")


def _render_prompt_text(
    *,
    tokenizer: Any,
    messages: list[dict[str, Any]],
) -> str:
    apply_chat_template = getattr(tokenizer, "apply_chat_template", None)
    if callable(apply_chat_template):
        try:
            rendered = apply_chat_template(
                messages,
                tokenize=False,
                add_generation_prompt=True,
            )
            if isinstance(rendered, str) and rendered.strip():
                return rendered
        except (AttributeError, TypeError, ValueError):
            pass
    rendered_messages = []
    for message in messages:
        role = message["role"].capitalize()
        content = str(message.get("content", ""))
        tool_calls = message.get("tool_calls")
        if isinstance(tool_calls, list) and tool_calls:
            content = (
                f"{content}\n"
                if content
                else ""
            ) + json.dumps({"tool_calls": tool_calls}, sort_keys=True)
        rendered_messages.append(f"{role}:\n{content}")
    return "\n\n".join(rendered_messages) + "\n\nAssistant:\n"


def _extract_target_logprobs(
    *,
    logprob_response: Any,
    target_length: int,
) -> list[float]:
    raw_logprobs = getattr(logprob_response, "prompt_logprobs", None)
    if raw_logprobs is None and isinstance(logprob_response, list | tuple):
        raw_logprobs = logprob_response
    if raw_logprobs is None and hasattr(logprob_response, "to_numpy"):
        raw_logprobs = logprob_response
    if raw_logprobs is None:
        wrapped_logprobs = getattr(logprob_response, "logprobs", None)
        if wrapped_logprobs is not None:
            raw_logprobs = wrapped_logprobs
    if raw_logprobs is None:
        loss_fn_outputs = getattr(logprob_response, "loss_fn_outputs", None)
        if isinstance(loss_fn_outputs, list) and loss_fn_outputs:
            first_output = loss_fn_outputs[0]
            if isinstance(first_output, dict):
                raw_logprobs = first_output.get("logprobs")
            else:
                raw_logprobs = getattr(first_output, "logprobs", None)
    if raw_logprobs is None:
        raise RuntimeError("Tinker compute_logprobs response is missing logprobs")
    if hasattr(raw_logprobs, "to_numpy"):
        raw_logprobs = raw_logprobs.to_numpy()
    values = [float(value) for value in raw_logprobs if value is not None]
    if len(values) < target_length:
        raise RuntimeError("Tinker compute_logprobs response was shorter than expected")
    return values[:target_length]


def _build_rl_datum(
    *,
    tinker: Any,
    full_tokens: list[int],
    prompt_token_count: int,
    reward: float,
    target_logprobs: list[float],
) -> Any:
    input_tokens = full_tokens[:-1]
    target_tokens = full_tokens[1:]
    token_rewards = [0.0] * prompt_token_count + [reward] * (
        len(full_tokens) - prompt_token_count
    )
    shifted_advantages = token_rewards[1:]
    if len(target_tokens) != len(target_logprobs) or len(target_tokens) != len(
        shifted_advantages
    ):
        raise RuntimeError("RL datum shapes are inconsistent")
    return tinker.types.Datum(
        model_input=tinker.types.ModelInput.from_ints(tokens=input_tokens),
        loss_fn_inputs={
            "target_tokens": np.asarray(target_tokens, dtype=np.int32),
            "logprobs": np.asarray(target_logprobs, dtype=np.float32),
            "advantages": np.asarray(shifted_advantages, dtype=np.float32),
        },
    )


def _build_reward_prompt_row(prompt_row: RLPromptRow) -> RewardPromptRow:
    return RewardPromptRow(
        expected_output=prompt_row.expected_output,
        reward=prompt_row.reward,
        metadata=dict(prompt_row.metadata),
        template_context=dict(prompt_row.template_context),
    )


def _build_reward_task_definition(
    task: TrainingTaskPayload | None,
) -> RewardTaskDefinition | None:
    if task is None:
        return None
    verification = (
        dict(task.verification) if isinstance(task.verification, dict) else None
    )
    return RewardTaskDefinition(reference=task.reference, verification=verification)


def _build_tinker_rl_config(payload: TinkerRLJobPayload) -> TinkerRLConfig:
    """Build a Tinker RL config from a sandbox job payload."""

    config = dict(payload.config)
    return TinkerRLConfig(
        base_model=payload.model,
        algorithm=_get_rl_algorithm(payload.algorithm),
        lora_rank=_get_positive_int(config, "lora_rank", default=16),
        steps=_get_positive_int(config, "steps", default=1),
        num_rollouts=_get_positive_int(config, "num_rollouts", default=8),
        batch_size=_get_positive_int(
            config,
            "batch_size",
            default=min(_get_positive_int(config, "num_rollouts", default=8), 8),
        ),
        learning_rate=_get_positive_float(config, "learning_rate", default=1e-4),
        weight_sync_interval=_get_positive_int(
            config,
            "weight_sync_interval",
            default=1,
        ),
        checkpoint_interval=_get_positive_int(
            config,
            "checkpoint_interval",
            default=max(_get_positive_int(config, "steps", default=1), 1),
        ),
        max_new_tokens=_get_positive_int(config, "max_new_tokens", default=128),
        temperature=_get_non_negative_float(config, "temperature", default=0.0),
        stop=_get_string_list(config, "stop"),
        execution_mode=config.get("execution_mode", "sync"),
        max_steps_off_policy=_get_positive_int(
            config,
            "max_steps_off_policy",
            default=1,
        ),
    )


def _build_sampling_params(*, tinker: Any, params: GenerateParams) -> Any:
    return tinker.types.SamplingParams(
        max_tokens=params.max_tokens or 128,
        temperature=float(params.temperature or 0.0),
        stop=params.stop or None,
    )


def _extract_first_sequence(sample_response: Any) -> Any:
    sequences = getattr(sample_response, "sequences", None)
    if not isinstance(sequences, list) or not sequences:
        raise RuntimeError("Tinker sampling response did not contain any sequences")
    return sequences[0]


def _stop_reason_from_sampling_response(
    sample_response: Any,
) -> Literal["stop", "length", "content_filter", "tool_calls", "unknown"]:
    finish_reason = getattr(sample_response, "finish_reason", None)
    if finish_reason in {
        "stop",
        "length",
        "content_filter",
        "tool_calls",
        "unknown",
    }:
        return finish_reason
    return "unknown"


def _get_rl_algorithm(
    value: str | None,
) -> Literal["importance_sampling", "ppo"]:
    if value == "ppo":
        return "ppo"
    return "importance_sampling"


def _build_worlds_agent_system_prompt(
    capability_prompt: str | None,
) -> str:
    if capability_prompt and capability_prompt.strip():
        return f"{capability_prompt.strip()}\n\n{_WORLDS_AGENT_SYSTEM_PROMPT}"
    return _WORLDS_AGENT_SYSTEM_PROMPT


def _terminal_signal_value(signals: list[dict[str, Any]]) -> float:
    total = 0.0
    for signal in signals:
        value = signal.get("value")
        if isinstance(value, int | float):
            total += float(value)
    return total


def _build_worlds_turn_reward_to_go(
    turns: list[dict[str, Any]],
    *,
    terminal_signals: list[dict[str, Any]],
) -> list[float]:
    rewards: list[float] = []
    for turn in turns:
        value = turn.get("reward")
        rewards.append(float(value) if isinstance(value, int | float) else 0.0)
    if rewards:
        rewards[-1] += _terminal_signal_value(terminal_signals)
    reward_to_go = [0.0] * len(rewards)
    running = 0.0
    for index in range(len(rewards) - 1, -1, -1):
        running += rewards[index]
        reward_to_go[index] = running
    return reward_to_go


def _iter_worlds_rollout_datums(
    *,
    rollout_result: Any,
    tokenizer: Any,
    tinker: Any,
    sampling_client: Any,
) -> tuple[list[Any], float]:
    message_log = rollout_result.message_log
    metadata = rollout_result.metadata if isinstance(rollout_result.metadata, dict) else {}
    raw_turns = metadata.get("turns")
    terminal_signals = metadata.get("terminal_signals")
    if not isinstance(raw_turns, list):
        raw_turns = []
    if not isinstance(terminal_signals, list):
        terminal_signals = []
    reward_to_go = _build_worlds_turn_reward_to_go(
        [turn for turn in raw_turns if isinstance(turn, dict)],
        terminal_signals=[signal for signal in terminal_signals if isinstance(signal, dict)],
    )

    datums: list[Any] = []
    assistant_turn_index = 0
    for message_index, message in enumerate(message_log):
        if message.get("role") != "assistant":
            continue
        if assistant_turn_index >= len(raw_turns):
            break
        turn = raw_turns[assistant_turn_index]
        assistant_turn_index += 1
        if not isinstance(turn, dict):
            continue
        target_text = turn.get("raw_generated_text") or turn.get("generated_text") or message.get("content")
        if not isinstance(target_text, str) or not target_text.strip():
            continue
        prefix_messages = message_log[:message_index]
        prompt_text = _render_prompt_text(
            tokenizer=tokenizer,
            messages=[dict(prefix_message) for prefix_message in prefix_messages],
        )
        prompt_tokens = tokenizer.encode(prompt_text, add_special_tokens=True)
        target_tokens = tokenizer.encode(target_text, add_special_tokens=False)
        full_tokens = prompt_tokens + target_tokens
        if len(full_tokens) < 2:
            continue
        logprob_response = sampling_client.compute_logprobs(
            prompt=tinker.types.ModelInput.from_ints(tokens=full_tokens)
        ).result()
        target_logprobs = _extract_target_logprobs(
            logprob_response=logprob_response,
            target_length=len(full_tokens) - 1,
        )
        reward = reward_to_go[min(assistant_turn_index - 1, len(reward_to_go) - 1)]
        datums.append(
            _build_rl_datum(
                tinker=tinker,
                full_tokens=full_tokens,
                prompt_token_count=len(prompt_tokens),
                reward=reward,
                target_logprobs=target_logprobs,
            )
        )
    return datums, float(getattr(rollout_result, "final_reward", 0.0))


async def _run_worlds_rollout(
    *,
    sampling_client: Any,
    tokenizer: Any,
    payload: TinkerRLJobPayload,
    reward_policy: dict[str, Any] | None,
    rollout_index: int,
) -> Any:
    if payload.world is None:
        raise ValueError("Live Worlds rollouts require a resolved world target")
    generator = _TinkerSamplingGenerator(
        model=payload.model,
        params=GenerateParams(),
        sampling_client=sampling_client,
        tokenizer=tokenizer,
    )
    reward_shaper = build_worlds_reward_shaper_from_config(reward_policy)
    goal = _get_optional_string(payload.config, "world_goal") or "Domain Admins"
    metadata = {
        "world_manifest_id": payload.world.id if payload.world is not None else None,
        "rollout_index": rollout_index,
    }
    async with _WorldsHTTPToolset(server_url=payload.world.server_url) as toolset:
        agent = Agent(
            name="worlds-training-agent",
            model=generator,
            instructions=_build_worlds_agent_system_prompt(
                payload.capability.entry_prompt
            ),
            tools=[toolset, finish_task, give_up_on_task],
            tool_mode="json-in-xml",
            max_steps=_get_positive_int(payload.config, "max_turns", default=8),
        )
        return await run_worlds_agent_rollout(
            agent,
            goal,
            reward_shaper=reward_shaper,
            metadata=metadata,
        )


def _generate_worlds_tinker_rl_rollout_group(
    *,
    sampling_client: Any,
    tokenizer: Any,
    generation_step: int,
    model_version: int,
    scheduled_at_training_step: int,
    config: TinkerRLConfig,
    payload: TinkerRLJobPayload,
    tinker: Any,
) -> TinkerRLRolloutGroup:
    datums: list[Any] = []
    rollout_rewards: list[float] = []
    world_reward = payload.config.get("world_reward")
    reward_policy = world_reward if isinstance(world_reward, dict) else None
    target_rollouts = max(1, min(config.num_rollouts, config.batch_size))
    for rollout_index in range(target_rollouts):
        rollout_result = asyncio.run(
            _run_worlds_rollout(
                sampling_client=sampling_client,
                tokenizer=tokenizer,
                payload=payload,
                reward_policy=reward_policy,
                rollout_index=rollout_index,
            )
        )
        rollout_datums, final_reward = _iter_worlds_rollout_datums(
            rollout_result=rollout_result,
            tokenizer=tokenizer,
            tinker=tinker,
            sampling_client=sampling_client,
        )
        if rollout_datums:
            datums.extend(rollout_datums)
            rollout_rewards.append(final_reward)
    return TinkerRLRolloutGroup(
        generation_step=generation_step,
        model_version=model_version,
        scheduled_at_training_step=scheduled_at_training_step,
        datums=datums,
        rewards=rollout_rewards,
    )


def _generate_tinker_rl_rollout_group(
    *,
    sampling_client: Any,
    tokenizer: Any,
    generation_step: int,
    model_version: int,
    scheduled_at_training_step: int,
    config: TinkerRLConfig,
    prompt_rows: list[RLPromptRow],
    capability_prompt: str | None,
    task: TrainingTaskPayload | None,
    reward_recipe: dict[str, Any] | None,
    reward_registry: RewardRecipeRegistry,
    reward_task: RewardTaskDefinition | None,
    tinker: Any,
) -> TinkerRLRolloutGroup:
    """Generate one prompt-group worth of RL datums and rewards."""

    batch_rows = _select_prompt_batch(
        prompt_rows=prompt_rows,
        step=generation_step,
        batch_size=config.batch_size,
    )
    datums: list[Any] = []
    step_rewards: list[float] = []

    for prompt_row in batch_rows:
        task_instruction = _render_task_instruction(
            prompt_row=prompt_row,
            task=task,
        )
        prompt_messages = _build_prompt_messages(
            prompt_row=prompt_row,
            capability_prompt=capability_prompt,
            task_instruction=task_instruction,
        )
        prompt_text = _render_prompt_text(
            tokenizer=tokenizer,
            messages=prompt_messages,
        )
        prompt_tokens = tokenizer.encode(prompt_text, add_special_tokens=True)
        prompt_input = tinker.types.ModelInput.from_ints(tokens=prompt_tokens)
        sampling_params = tinker.types.SamplingParams(
            max_tokens=config.max_new_tokens,
            temperature=config.temperature,
            stop=config.stop or None,
        )
        sample_response = sampling_client.sample(
            prompt=prompt_input,
            sampling_params=sampling_params,
            num_samples=1,
        ).result()
        if not getattr(sample_response, "sequences", None):
            continue

        sequence = sample_response.sequences[0]
        completion_tokens = list(sequence.tokens)
        completion_text = tokenizer.decode(completion_tokens).strip()
        reward_result = reward_registry.evaluate(
            reward_recipe=reward_recipe,
            completion=completion_text,
            prompt_row=_build_reward_prompt_row(prompt_row),
            task=reward_task,
        )
        reward = reward_result.reward
        step_rewards.append(reward)

        full_tokens = prompt_tokens + completion_tokens
        if len(full_tokens) < 2:
            continue
        logprob_response = sampling_client.compute_logprobs(
            prompt=tinker.types.ModelInput.from_ints(tokens=full_tokens)
        ).result()
        target_logprobs = _extract_target_logprobs(
            logprob_response=logprob_response,
            target_length=len(full_tokens) - 1,
        )
        datums.append(
            _build_rl_datum(
                tinker=tinker,
                full_tokens=full_tokens,
                prompt_token_count=len(prompt_tokens),
                reward=reward,
                target_logprobs=target_logprobs,
            )
        )

    return TinkerRLRolloutGroup(
        generation_step=generation_step,
        model_version=model_version,
        scheduled_at_training_step=scheduled_at_training_step,
        datums=datums,
        rewards=step_rewards,
    )


def run_tinker_sft_job(payload: TinkerSFTJobPayload) -> TrainingJobResult:
    """Execute one hosted Tinker SFT job from a resolved payload."""

    dn = _build_configured_dreadnode()
    pull_packages: list[str] = []
    if payload.dataset is not None:
        pull_packages.append(
            f"dataset://{payload.dataset.reference.replace('@', ':', 1)}"
        )
    pull_packages.extend(
        f"dataset://{dataset.reference.replace('@', ':', 1)}"
        for dataset in payload.trajectory_datasets
    )
    if payload.eval_dataset is not None:
        pull_packages.append(
            f"dataset://{payload.eval_dataset.reference.replace('@', ':', 1)}"
        )
    if not pull_packages:
        raise ValueError(
            "Tinker SFT payload did not include any dataset or trajectory dataset references"
        )
    pull_result = dn.pull_package(pull_packages)
    if not pull_result.success:
        raise RuntimeError("; ".join(pull_result.errors) or "Dataset pull failed")

    train_dataset = (
        dn.load_package(f"dataset://{payload.dataset.reference}")
        if payload.dataset is not None
        else None
    )
    trajectory_datasets = [
        dn.load_package(f"dataset://{dataset.reference}")
        for dataset in payload.trajectory_datasets
    ]
    eval_dataset = (
        dn.load_package(f"dataset://{payload.eval_dataset.reference}")
        if payload.eval_dataset is not None
        else None
    )

    # Collect OpenAI conversations (with tool_calls) from worlds datasets
    openai_conversations: list[OpenAIConversation] = []
    for trajectory_dataset in trajectory_datasets:
        openai_conversations.extend(
            load_conversations_from_worlds_dataset(
                trajectory_dataset,
                system_prompt=payload.capability.entry_prompt,
            )
        )

    # Collect plain SFT conversations from regular datasets. Per-record
    # dispatch: rows with structured tool_calls / tool_call_id (e.g.
    # `dn eval get-transcript` exports) are picked up by the OpenAI loader
    # and routed through the renderer-aware path so the model's native
    # tool-call template is applied at tokenization time. Plain text rows
    # take the existing SFT loader path.
    sft_conversations: list[SFTConversation] = []
    if train_dataset is not None:
        sft_conversations.extend(
            load_sft_conversations_from_dataset(
                train_dataset,
                system_prompt=payload.capability.entry_prompt,
            )
        )
        openai_conversations.extend(
            load_openai_conversations_from_dataset(
                train_dataset,
                system_prompt=payload.capability.entry_prompt,
            )
        )

    if not openai_conversations and not sft_conversations:
        raise ValueError(
            "Training inputs did not produce any usable conversations. "
            "Each dataset row must contain a `messages` list, a Worlds/ATIF "
            "`steps` list with user/agent messages, or a prompt + completion "
            "pair (`prompt`/`input` + `expected_output`/`output`)."
        )

    eval_conversations: list[SFTConversation] = []
    eval_openai_conversations: list[OpenAIConversation] = []
    if eval_dataset is not None:
        eval_conversations = load_sft_conversations_from_dataset(
            eval_dataset,
            system_prompt=payload.capability.entry_prompt,
        )
        eval_openai_conversations = load_openai_conversations_from_dataset(
            eval_dataset,
            system_prompt=payload.capability.entry_prompt,
        )

    config = _build_tinker_sft_config(payload)
    trainer = TinkerSFTTrainer(config)

    # Convert worlds trajectories using model-specific renderer
    train_data = load_from_conversations(
        openai_conversations,
        trainer.renderer,
        config.max_sequence_length,
    )

    # Convert plain SFT conversations using legacy path
    if sft_conversations:
        train_data.extend(
            load_from_messages(
                _messages_from_conversations(sft_conversations),
                trainer.tokenizer,
                config.max_sequence_length,
            )
        )

    eval_data = load_from_messages(
        _messages_from_conversations(eval_conversations),
        trainer.tokenizer,
        config.max_sequence_length,
    )
    if eval_openai_conversations:
        eval_data.extend(
            load_from_conversations(
                eval_openai_conversations,
                trainer.renderer,
                config.max_sequence_length,
            )
        )
    state = trainer.train(train_data, eval_data or None, log_to_dreadnode=False)
    eval_loss: float | None = None
    if eval_data:
        eval_loss = trainer.evaluate(
            eval_data,
            step=config.steps,
            log_to_dreadnode=False,
        )

    return TrainingJobResult(
        status="completed",
        metrics=_build_sft_metrics(
            state=state,
            train_examples=len(train_data),
            gradient_accumulation_steps=config.gradient_accumulation_steps,
            learning_rate=config.learning_rate,
            eval_examples=len(eval_data),
            eval_loss=eval_loss,
        ),
        artifacts={
            "capability": f"{payload.capability.name}@{payload.capability.version}",
            "checkpoints": list(getattr(state, "checkpoints", [])),
            **(
                {"dataset": payload.dataset.reference}
                if payload.dataset is not None
                else {}
            ),
            **(
                {
                    "trajectory_datasets": [
                        dataset.reference for dataset in payload.trajectory_datasets
                    ]
                }
                if payload.trajectory_datasets
                else {}
            ),
            **(
                {"eval_dataset": payload.eval_dataset.reference}
                if payload.eval_dataset is not None
                else {}
            ),
        },
    )


def run_tinker_rl_job(payload: TinkerRLJobPayload) -> TrainingJobResult:
    """Execute one hosted Tinker RL job from a resolved payload."""

    dn = _build_configured_dreadnode()
    pull_packages: list[str] = []
    if payload.prompt_dataset is not None:
        pull_packages.append(
            f"dataset://{payload.prompt_dataset.reference.replace('@', ':', 1)}"
        )
    pull_packages.extend(
        f"dataset://{dataset.reference.replace('@', ':', 1)}"
        for dataset in payload.trajectory_datasets
    )
    if not pull_packages and payload.world is None:
        raise ValueError(
            "Tinker RL payload did not include prompt datasets, trajectory datasets, or a live Worlds target"
        )
    if pull_packages:
        pull_result = dn.pull_package(pull_packages)
        if not pull_result.success:
            raise RuntimeError("; ".join(pull_result.errors) or "Prompt dataset pull failed")

    prompt_dataset = (
        dn.load_package(f"dataset://{payload.prompt_dataset.reference}")
        if payload.prompt_dataset is not None
        else None
    )
    trajectory_datasets = [
        dn.load_package(f"dataset://{dataset.reference}")
        for dataset in payload.trajectory_datasets
    ]
    tinker = _get_tinker_module()
    rl_config = _build_tinker_rl_config(payload)
    prompt_rows: list[RLPromptRow] = []
    if prompt_dataset is not None:
        prompt_rows.extend(
            load_prompt_rows_from_dataset(
                prompt_dataset,
                split=_get_optional_string(payload.config, "prompt_split"),
                limit=max(rl_config.num_rollouts, rl_config.batch_size),
            )
        )
    for trajectory_dataset in trajectory_datasets:
        prompt_rows.extend(
            load_rl_prompt_rows_from_worlds_dataset(
                trajectory_dataset,
                system_prompt=payload.capability.entry_prompt,
                limit=max(rl_config.num_rollouts, rl_config.batch_size),
            )
        )
    if payload.world is None and not prompt_rows:
        raise ValueError("Prompt dataset did not produce any usable prompt rows")

    reward_registry = RewardRecipeRegistry()
    reward_task = _build_reward_task_definition(payload.task)
    reward_recipe = payload.reward_recipe
    if reward_recipe is None and payload.prompt_dataset is None and payload.trajectory_datasets:
        reward_recipe = {"name": "trajectory_imitation_v1"}
    if payload.world is not None:
        training_result = train_tinker_rl(
            tinker=tinker,
            config=rl_config,
            job_id=payload.job_id,
            generate_group=lambda **kwargs: _generate_worlds_tinker_rl_rollout_group(
                config=rl_config,
                payload=payload,
                tinker=tinker,
                **kwargs,
            ),
        )
    else:
        training_result = train_tinker_rl(
            tinker=tinker,
            config=rl_config,
            job_id=payload.job_id,
            generate_group=lambda **kwargs: _generate_tinker_rl_rollout_group(
                config=rl_config,
                prompt_rows=prompt_rows,
                capability_prompt=payload.capability.entry_prompt,
                task=payload.task,
                reward_recipe=reward_recipe,
                reward_registry=reward_registry,
                reward_task=reward_task,
                tinker=tinker,
                **kwargs,
            ),
        )

    return TrainingJobResult(
        status="completed",
        metrics=dict(training_result.metrics),
        artifacts={
            "capability": f"{payload.capability.name}@{payload.capability.version}",
            "execution_mode": rl_config.execution_mode,
            "checkpoints": list(training_result.checkpoints),
            **(
                {"prompt_dataset": payload.prompt_dataset.reference}
                if payload.prompt_dataset is not None
                else {}
            ),
            **(
                {
                    "trajectory_datasets": [
                        dataset.reference for dataset in payload.trajectory_datasets
                    ]
                }
                if payload.trajectory_datasets
                else {}
            ),
            **({"task": payload.task.reference} if payload.task is not None else {}),
            **(
                {"world_manifest_id": payload.world.id, "world_server_url": payload.world.server_url}
                if payload.world is not None
                else {}
            ),
        },
    )


def run_training_job(payload: TrainingJobPayload) -> TrainingJobResult:
    """Dispatch a sandbox training payload to the matching SDK runtime."""

    if isinstance(payload, TinkerSFTJobPayload):
        return run_tinker_sft_job(payload)
    if isinstance(payload, TinkerRLJobPayload):
        return run_tinker_rl_job(payload)
    raise ValueError(
        f"Unsupported training payload backend/trainer_type: {payload.backend}/{payload.trainer_type}"
    )


def main(argv: list[str] | None = None) -> int:
    """CLI entrypoint for sandboxed training job execution."""

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--payload", required=True, help="Path to the job payload JSON")
    parser.add_argument("--result", required=True, help="Path to write the result JSON")
    args = parser.parse_args(argv)

    try:
        payload = load_training_job_payload(args.payload)
        result = run_training_job(payload)
    except (
        FileNotFoundError,
        KeyError,
        OSError,
        RuntimeError,
        TypeError,
        ValueError,
    ) as exc:  # pragma: no cover - exercised via API orchestration
        result = TrainingJobResult(status="failed", error=str(exc))

    write_training_job_result(result, args.result)
    return 0 if result.status == "completed" else 1


def parse_training_job_payload(data: dict[str, Any]) -> TrainingJobPayload:
    """Parse a JSON-compatible training job payload."""

    backend = data.get("backend")
    trainer_type = data.get("trainer_type")
    if backend == "tinker" and trainer_type == "sft":
        return TinkerSFTJobPayload.model_validate(data)
    if backend == "tinker" and trainer_type == "rl":
        return TinkerRLJobPayload.model_validate(data)
    raise ValueError(
        f"Unsupported training payload backend/trainer_type: {backend}/{trainer_type}"
    )


def load_training_job_payload(path: str | Path) -> TrainingJobPayload:
    """Load a training job payload from disk."""

    payload_path = Path(path)
    return parse_training_job_payload(json.loads(payload_path.read_text(encoding="utf-8")))


def write_training_job_result(result: TrainingJobResult, path: str | Path) -> Path:
    """Persist a structured training job result to disk."""

    result_path = Path(path)
    result_path.parent.mkdir(parents=True, exist_ok=True)
    result_path.write_text(result.model_dump_json(indent=2), encoding="utf-8")
    return result_path


def load_training_job_result(path: str | Path) -> TrainingJobResult:
    """Load a structured training job result from disk."""

    result_path = Path(path)
    return TrainingJobResult.model_validate_json(result_path.read_text(encoding="utf-8"))


__all__ = [
    "BaseTrainingJobPayload",
    "TinkerRLJobPayload",
    "TinkerSFTJobPayload",
    "TrainingCapabilityPayload",
    "TrainingDatasetPayload",
    "TrainingJobPayload",
    "TrainingJobResult",
    "TrainingTaskPayload",
    "load_training_job_payload",
    "load_training_job_result",
    "main",
    "parse_training_job_payload",
    "run_tinker_rl_job",
    "run_tinker_sft_job",
    "run_training_job",
    "write_training_job_result",
]


if __name__ == "__main__":
    raise SystemExit(main())
