"""Web search tool with pluggable backend adapters.

The agent-facing surface (:func:`web_search` and :class:`WebSearchResponse`)
is stable. Backend selection is internal — the runtime picks the provider
from env config and the auto fallback chain; the agent does not choose.
New providers plug in by registering a :class:`Backend` in :data:`_BACKENDS`.
"""

import asyncio
import os
import typing as t
from dataclasses import dataclass, field
from urllib.parse import parse_qs, urlparse

import httpx
from loguru import logger

from dreadnode.agents.tools import tool

# ---------------------------------------------------------------------------
# Public response shape
# ---------------------------------------------------------------------------


class WebSearchResult(t.TypedDict):
    title: str
    url: str
    snippet: str
    rank: int
    domain: str


class WebSearchFilters(t.TypedDict):
    allowed_domains: list[str]
    blocked_domains: list[str]


class WebSearchResponse(t.TypedDict):
    success: bool
    query: str
    backend: str
    result_count: int
    applied_filters: WebSearchFilters
    warnings: list[str]
    results: list[WebSearchResult]


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

MAX_RESULTS = 10
DEFAULT_HTTP_TIMEOUT = 30.0

_BACKEND_ENV_VAR = "DREADNODE_WEB_SEARCH_BACKEND"

# Auto-mode picks the first configured backend in this order. DuckDuckGo
# is last because it always reports as configured (no credentials), so
# stronger providers win when their keys are present.
_AUTO_PREFERENCE_ORDER: tuple[str, ...] = ("firecrawl", "exa", "google", "duckduckgo")

_FIRECRAWL_DEFAULT_API_URL = "https://api.firecrawl.dev"


# ---------------------------------------------------------------------------
# Backend plumbing
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class BackendOutcome:
    """What a backend returns to the resolver.

    ``hits`` is the unranked list of ``{title, url, snippet}`` dicts.
    Rank and domain are added later by :func:`_rank_results`. A non-empty
    ``error`` means the backend itself failed — callers surface it via
    ``warnings`` and flip ``success=False`` on the final response.
    """

    hits: list[dict[str, str]]
    warnings: list[str] = field(default_factory=list)
    error: str | None = None


BackendSearchFn = t.Callable[[str, int], t.Awaitable[BackendOutcome]]


@dataclass(frozen=True)
class Backend:
    name: str
    search: BackendSearchFn
    is_configured: t.Callable[[], bool]


# ---------------------------------------------------------------------------
# Backend adapters
# ---------------------------------------------------------------------------


async def _duckduckgo_backend(query: str, num_results: int) -> BackendOutcome:
    """DuckDuckGo search. No credentials required."""
    try:
        from duckduckgo_search import DDGS
    except ImportError:
        return await _duckduckgo_lite_backend(query, num_results)

    def _run() -> list[dict[str, t.Any]]:
        with DDGS() as ddgs:
            return list(ddgs.text(query, max_results=num_results))

    try:
        results = await asyncio.to_thread(_run)
    except Exception as exc:
        return BackendOutcome(hits=[], error=f"DuckDuckGo search failed: {exc}")

    return BackendOutcome(
        hits=[
            {
                "title": str(item.get("title") or "No title"),
                "url": _unwrap_ddg_redirect(str(item.get("href") or item.get("link") or "")),
                "snippet": str(item.get("body") or item.get("snippet") or ""),
            }
            for item in results
        ]
    )


async def _duckduckgo_lite_backend(query: str, num_results: int) -> BackendOutcome:
    """HTML-scrape fallback for DuckDuckGo when the Python client is absent."""
    try:
        from bs4 import BeautifulSoup
    except ImportError:
        return BackendOutcome(
            hits=[],
            error="DuckDuckGo search is unavailable: install 'duckduckgo-search' or 'beautifulsoup4'.",
        )

    try:
        async with httpx.AsyncClient(timeout=DEFAULT_HTTP_TIMEOUT) as client:
            response = await client.get(
                "https://lite.duckduckgo.com/lite/",
                params={"q": query},
                headers={"User-Agent": "Mozilla/5.0"},
            )
            response.raise_for_status()
    except Exception as exc:
        return BackendOutcome(hits=[], error=f"DuckDuckGo search failed: {exc}")

    soup = BeautifulSoup(response.text, "html.parser")
    hits: list[dict[str, str]] = []
    for link in soup.select("a.result-link")[:num_results]:
        snippet_elem = link.find_next("td", class_="result-snippet")
        hits.append(
            {
                "title": link.get_text(strip=True),
                "url": _unwrap_ddg_redirect(str(link.get("href") or "")),
                "snippet": snippet_elem.get_text(strip=True) if snippet_elem else "",
            }
        )
    return BackendOutcome(hits=hits)


def _unwrap_ddg_redirect(url: str) -> str:
    """Return the real target hidden inside a DuckDuckGo ``/l/?uddg=...`` link.

    DDG's lite interface wraps outbound results in a redirect and the href
    arrives as ``//duckduckgo.com/l/?uddg=<encoded-target>`` (sometimes
    ``https:``-prefixed or path-only). Feeding that into ``fetch`` /
    ``web_extract`` would just hit the redirector. Non-redirect URLs pass
    through unchanged.
    """
    if not url:
        return url
    candidate = url
    if candidate.startswith("//"):
        candidate = "https:" + candidate
    elif candidate.startswith("/"):
        candidate = "https://duckduckgo.com" + candidate

    parsed = urlparse(candidate)
    host = (parsed.hostname or "").lower()
    if not (host == "duckduckgo.com" or host.endswith(".duckduckgo.com")):
        return url
    if not parsed.path.startswith("/l/"):
        return url

    target = parse_qs(parsed.query).get("uddg")
    if not target or not target[0]:
        return url
    return target[0]


async def _google_backend(query: str, num_results: int) -> BackendOutcome:
    """Google Custom Search API. Requires GOOGLE_API_KEY + GOOGLE_CSE_ID."""
    api_key = os.environ.get("GOOGLE_API_KEY")
    cse_id = os.environ.get("GOOGLE_CSE_ID")
    if not api_key or not cse_id:
        return BackendOutcome(hits=[], error="Google search is not configured.")

    try:
        async with httpx.AsyncClient(timeout=DEFAULT_HTTP_TIMEOUT) as client:
            response = await client.get(
                "https://www.googleapis.com/customsearch/v1",
                params={
                    "key": api_key,
                    "cx": cse_id,
                    "q": query,
                    "num": num_results,
                },
            )
            response.raise_for_status()
            data = response.json()
    except Exception as exc:
        return BackendOutcome(hits=[], error=f"Google search failed: {exc}")

    items = data.get("items") or []
    return BackendOutcome(
        hits=[
            {
                "title": str(item.get("title") or "No title"),
                "url": str(item.get("link") or ""),
                "snippet": str(item.get("snippet") or ""),
            }
            for item in items
        ]
    )


async def _exa_backend(query: str, num_results: int) -> BackendOutcome:
    """Exa neural search. Requires EXA_API_KEY.

    Exa returns a richer record than we expose — we keep the common shape
    so downstream consumers don't fork on provider. See
    https://docs.exa.ai/reference/search.
    """
    api_key = os.environ.get("EXA_API_KEY")
    if not api_key:
        return BackendOutcome(hits=[], error="Exa search is not configured.")

    try:
        async with httpx.AsyncClient(timeout=DEFAULT_HTTP_TIMEOUT) as client:
            response = await client.post(
                "https://api.exa.ai/search",
                headers={"x-api-key": api_key, "content-type": "application/json"},
                json={
                    "query": query,
                    "numResults": num_results,
                    "type": "auto",
                    "contents": {"highlights": {"numSentences": 2}},
                },
            )
            response.raise_for_status()
            data = response.json()
    except Exception as exc:
        return BackendOutcome(hits=[], error=f"Exa search failed: {exc}")

    items = data.get("results") or []
    return BackendOutcome(
        hits=[
            {
                "title": str(item.get("title") or "No title"),
                "url": str(item.get("url") or ""),
                "snippet": _exa_snippet(item),
            }
            for item in items
        ]
    )


def _exa_snippet(item: dict[str, t.Any]) -> str:
    """Pick the best short snippet Exa gave us."""
    highlights = item.get("highlights")
    if isinstance(highlights, list):
        for candidate in highlights:
            if isinstance(candidate, str) and candidate.strip():
                return candidate.strip()
    for key in ("summary", "text"):
        candidate = item.get(key)
        if isinstance(candidate, str) and candidate.strip():
            return candidate.strip()[:400]
    return ""


async def _firecrawl_backend(query: str, num_results: int) -> BackendOutcome:
    """Firecrawl search. Requires FIRECRAWL_API_KEY.

    ``FIRECRAWL_API_URL`` overrides the base URL (for self-hosted Firecrawl
    or a managed gateway). See https://docs.firecrawl.dev/api-reference/v2-search.
    """
    api_key = os.environ.get("FIRECRAWL_API_KEY")
    if not api_key:
        return BackendOutcome(hits=[], error="Firecrawl search is not configured.")

    base_url = (os.environ.get("FIRECRAWL_API_URL") or _FIRECRAWL_DEFAULT_API_URL).rstrip("/")

    try:
        async with httpx.AsyncClient(timeout=DEFAULT_HTTP_TIMEOUT) as client:
            response = await client.post(
                f"{base_url}/v2/search",
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/json",
                },
                json={"query": query, "limit": num_results},
            )
            response.raise_for_status()
            data = response.json()
    except Exception as exc:
        return BackendOutcome(hits=[], error=f"Firecrawl search failed: {exc}")

    items = _firecrawl_extract_items(data)
    return BackendOutcome(
        hits=[
            {
                "title": str(item.get("title") or "No title"),
                "url": str(item.get("url") or ""),
                "snippet": str(
                    item.get("description") or item.get("snippet") or item.get("content") or ""
                ),
            }
            for item in items
        ]
    )


def _firecrawl_extract_items(payload: t.Any) -> list[dict[str, t.Any]]:
    """Firecrawl has shipped several response shapes; coerce them to one list.

    Observed shapes: ``{"data": [...]}``, ``{"data": {"web": [...]}}``,
    ``{"data": {"results": [...]}}``, or the top-level variants without the
    ``data`` wrapper.
    """
    if not isinstance(payload, dict):
        return []

    data = payload.get("data")
    if isinstance(data, list):
        return [item for item in data if isinstance(item, dict)]
    if isinstance(data, dict):
        for key in ("web", "results"):
            items = data.get(key)
            if isinstance(items, list):
                return [item for item in items if isinstance(item, dict)]

    for key in ("web", "results"):
        items = payload.get(key)
        if isinstance(items, list):
            return [item for item in items if isinstance(item, dict)]
    return []


# ---------------------------------------------------------------------------
# Registry + resolver
# ---------------------------------------------------------------------------


_BACKENDS: dict[str, Backend] = {
    "duckduckgo": Backend(
        name="duckduckgo",
        search=_duckduckgo_backend,
        is_configured=lambda: True,
    ),
    "google": Backend(
        name="google",
        search=_google_backend,
        is_configured=lambda: bool(
            os.environ.get("GOOGLE_API_KEY") and os.environ.get("GOOGLE_CSE_ID")
        ),
    ),
    "exa": Backend(
        name="exa",
        search=_exa_backend,
        is_configured=lambda: bool(os.environ.get("EXA_API_KEY")),
    ),
    "firecrawl": Backend(
        name="firecrawl",
        search=_firecrawl_backend,
        is_configured=lambda: bool(os.environ.get("FIRECRAWL_API_KEY")),
    ),
}


def _resolve_backend() -> tuple[Backend, list[str]]:
    """Pick a backend from env preference, then the auto fallback chain.

    ``DREADNODE_WEB_SEARCH_BACKEND`` is a soft preference: if it names an
    unknown or unconfigured backend, we emit a warning and fall through to
    the auto order — we never skip straight to DuckDuckGo while a stronger
    provider is configured.
    """
    warnings: list[str] = []

    env_pref = (os.environ.get(_BACKEND_ENV_VAR) or "").strip().lower() or None
    if env_pref and env_pref != "auto":
        pinned = _BACKENDS.get(env_pref)
        if pinned is None:
            warnings.append(f"Unknown {_BACKEND_ENV_VAR} value {env_pref!r}; using auto selection.")
        elif pinned.is_configured():
            return pinned, warnings
        else:
            warnings.append(
                f"{pinned.name} (from {_BACKEND_ENV_VAR}) is not configured; "
                "falling through to auto selection."
            )

    for name in _AUTO_PREFERENCE_ORDER:
        candidate = _BACKENDS.get(name)
        if candidate and candidate.is_configured():
            return candidate, warnings

    # DuckDuckGo always reports as configured; this is defensive.
    return _BACKENDS["duckduckgo"], warnings


# ---------------------------------------------------------------------------
# Normalization
# ---------------------------------------------------------------------------


def _normalize_domains(domains: list[str] | None) -> list[str]:
    if not domains:
        return []

    normalized: list[str] = []
    for domain in domains:
        cleaned = domain.strip().lower()
        if cleaned.startswith(("http://", "https://")):
            cleaned = urlparse(cleaned).hostname or ""
        cleaned = cleaned.lstrip(".")
        if cleaned and cleaned not in normalized:
            normalized.append(cleaned)
    return normalized


def _extract_domain(url: str) -> str:
    parsed = urlparse(url)
    return (parsed.hostname or "").lower()


def _domain_matches(candidate: str, domains: list[str]) -> bool:
    return any(candidate == domain or candidate.endswith(f".{domain}") for domain in domains)


def _filter_results(
    results: list[dict[str, str]],
    allowed_domains: list[str],
    blocked_domains: list[str],
) -> list[dict[str, str]]:
    filtered: list[dict[str, str]] = []
    for result in results:
        domain = _extract_domain(result.get("url", ""))
        if allowed_domains and not _domain_matches(domain, allowed_domains):
            continue
        if blocked_domains and _domain_matches(domain, blocked_domains):
            continue
        filtered.append(result)
    return filtered


def _rank_results(results: list[dict[str, str]]) -> list[WebSearchResult]:
    ranked: list[WebSearchResult] = []
    for index, result in enumerate(results, start=1):
        url = result.get("url", "")
        ranked.append(
            {
                "title": result.get("title") or "No title",
                "url": url,
                "snippet": result.get("snippet") or "",
                "rank": index,
                "domain": _extract_domain(url),
            }
        )
    return ranked


# ---------------------------------------------------------------------------
# Tool
# ---------------------------------------------------------------------------


@tool(catch=True)
async def web_search(
    query: t.Annotated[str, "Search query"],
    *,
    num_results: t.Annotated[int, "Number of results to return (max 10)"] = 5,
    allowed_domains: t.Annotated[
        list[str] | None, "Only include results from these domains or their subdomains"
    ] = None,
    blocked_domains: t.Annotated[
        list[str] | None, "Exclude results from these domains or their subdomains"
    ] = None,
) -> WebSearchResponse:
    """
    Search the web and return structured results.

    Returns a stable payload (``title``, ``url``, ``snippet``, ``domain``,
    ``rank``) regardless of which provider answered. Provider selection is
    handled by the runtime; the response includes a ``backend`` field for
    observability, but the agent does not choose it.

    Backend errors produce ``success=False`` with an empty result set and
    an entry in ``warnings``.
    """
    if allowed_domains and blocked_domains:
        raise ValueError("Cannot specify both allowed_domains and blocked_domains.")

    normalized_num_results = max(1, min(num_results, MAX_RESULTS))
    normalized_allowed = _normalize_domains(allowed_domains)
    normalized_blocked = _normalize_domains(blocked_domains)

    chosen, warnings = _resolve_backend()
    logger.info("Searching ({}): {}", chosen.name, query)

    outcome = await chosen.search(query, normalized_num_results)
    warnings = [*warnings, *outcome.warnings]
    success = outcome.error is None
    if outcome.error:
        warnings.append(outcome.error)

    filtered = _filter_results(outcome.hits, normalized_allowed, normalized_blocked)
    ranked = _rank_results(filtered)

    if success and not ranked:
        warnings.append(
            "No results for this query."
            if not outcome.hits
            else "All results were filtered out by domain rules."
        )

    return {
        "success": success,
        "query": query,
        "backend": chosen.name,
        "result_count": len(ranked),
        "applied_filters": {
            "allowed_domains": normalized_allowed,
            "blocked_domains": normalized_blocked,
        },
        "warnings": warnings,
        "results": ranked,
    }
