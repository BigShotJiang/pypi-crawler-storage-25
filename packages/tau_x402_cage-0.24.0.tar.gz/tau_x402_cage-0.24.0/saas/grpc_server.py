"""gRPC server for the Tau x402 Cage.

Parallel entrypoint to the FastAPI SaaS in ``saas/app.py``. Contract parity
is the discipline: every HTTP op has a gRPC method here, every verdict has
the same semantics, every signed envelope is byte-for-byte identical.

Architecture
------------

The gRPC server is a client of the existing UDS daemon, the exact same
shape as the FastAPI layer. It does not talk to the prover, it does not
hold invariant state, and it does not spawn Tau. All it does:

    1. Authenticate the gRPC call (bearer token interceptor).
    2. Translate the inbound protobuf message into the daemon's JSON-over-UDS
       shape (for ``CheckPayment``, this means calling ``adapter.x402_client.mediate``
       to reuse the existing signing + fail-closed flow).
    3. Translate the daemon's response back into a protobuf message.

The wire shape on gRPC is verdict-only. We deliberately do not leak
HybridProver / fragment / prover-backend details into the protobuf
schema — those are daemon implementation details and would make the
schema unstable as the prover stack evolves.

Auth
----

Single auth surface with the HTTP layer: ``TAU_X402_API_KEYS`` env var.
The bearer-token interceptor checks the ``authorization`` metadata on
every RPC except ``Health`` (liveness must work without credentials,
same as ``GET /v1/health``).

Activation
----------

Set ``TAU_X402_GRPC_ENABLED=1`` and (optionally) ``TAU_X402_GRPC_PORT``.
No new CLI subcommand — the gRPC server is started by the SaaS process
entrypoint when the flag is on.
"""
from __future__ import annotations

import json
import logging
import os
import socket
import threading
from concurrent import futures
from dataclasses import dataclass
from typing import Dict, Iterable, Mapping, Optional, Tuple

try:
    import grpc
except ImportError as exc:  # pragma: no cover - optional extra
    raise ImportError(
        "saas/grpc_server.py requires grpcio: "
        "`pip install tau-x402-cage[grpc]` or `pip install grpcio`"
    ) from exc

from adapter.verdict_signer import SignedEnvelope
from adapter.x402_client import UdsDaemonClient, mediate
from saas import grpc_pb2, grpc_pb2_grpc

logger = logging.getLogger(__name__)

# Version string surfaced on the Health response. Stays in lockstep with
# ``saas.app.APP_VERSION`` / ``pyproject.toml``. We import it lazily to avoid
# forcing FastAPI as a hard dep of the gRPC server.
try:
    from saas.app import APP_VERSION as _APP_VERSION
except Exception:  # pragma: no cover - FastAPI missing in minimal installs
    _APP_VERSION = "unknown"


DEFAULT_GRPC_PORT = 50051
DEFAULT_MAX_WORKERS = 16


# ── auth interceptor ─────────────────────────────────────────────────────────


class _BearerAuthInterceptor(grpc.ServerInterceptor):
    """Verify ``authorization: Bearer <token>`` against ``TAU_X402_API_KEYS``.

    Skips auth for the ``Health`` method so liveness probes work without a
    key, mirroring the HTTP surface where ``GET /v1/health`` is also
    unauthenticated.

    Token lookups happen against an immutable token set built at ctor time.
    Rotating keys = restart the process (same operational contract as the
    HTTP layer's ``SaasConfig.from_env``).
    """

    #: Methods that bypass the auth check. Full-path form required by
    #: grpc's interceptor contract — ``/<package.service>/<method>``.
    _UNAUTH_METHODS = frozenset(
        [
            "/tau.x402.cage.v1.CageService/Health",
        ]
    )

    def __init__(self, bearer_tokens: Iterable[str]) -> None:
        self._tokens = frozenset(bearer_tokens)

    def intercept_service(self, continuation, handler_call_details):
        method = handler_call_details.method
        if method in self._UNAUTH_METHODS:
            return continuation(handler_call_details)

        metadata = dict(handler_call_details.invocation_metadata or ())
        authorization = metadata.get("authorization", "")
        if not authorization.startswith("Bearer "):
            return _unauth_handler("missing Bearer token")
        token = authorization[len("Bearer "):].strip()
        if not token or token not in self._tokens:
            return _unauth_handler("invalid API key")
        return continuation(handler_call_details)


def _unauth_handler(detail: str) -> grpc.RpcMethodHandler:
    """Return an RpcMethodHandler that aborts every call with UNAUTHENTICATED."""

    def abort(unused_request, context: grpc.ServicerContext):
        context.abort(grpc.StatusCode.UNAUTHENTICATED, detail)

    return grpc.unary_unary_rpc_method_handler(abort)


# ── servicer ─────────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class GrpcServerConfig:
    """Configuration bag for :class:`CageGrpcServer`.

    Kept small and frozen so tests can construct a server without env
    plumbing, and so production env parsing (in :func:`from_env`) has a
    single target shape.
    """

    daemon_socket: str
    bearer_tokens: Tuple[str, ...]
    hmac_secret: bytes
    port: int = DEFAULT_GRPC_PORT
    host: str = "0.0.0.0"
    max_workers: int = DEFAULT_MAX_WORKERS

    @classmethod
    def from_env(cls) -> "GrpcServerConfig":
        keys_raw = os.environ.get("TAU_X402_API_KEYS", "{}")
        try:
            api_keys = json.loads(keys_raw)
        except json.JSONDecodeError as exc:
            raise RuntimeError(
                "TAU_X402_API_KEYS must be JSON object {tenant_id: api_key}"
            ) from exc
        if not isinstance(api_keys, dict):
            raise RuntimeError("TAU_X402_API_KEYS must decode to an object")
        tokens = tuple(api_keys.values())

        secret_hex = os.environ.get("TAU_X402_HMAC_SECRET")
        if not secret_hex:
            raise RuntimeError(
                "TAU_X402_HMAC_SECRET must be set (32+ hex chars)"
            )
        try:
            secret = bytes.fromhex(secret_hex)
        except ValueError as exc:
            raise RuntimeError("TAU_X402_HMAC_SECRET must be hex-encoded") from exc
        if len(secret) < 16:
            raise RuntimeError("TAU_X402_HMAC_SECRET must be >= 16 bytes")

        socket_path = os.environ.get("TAU_X402_SOCKET", "/tmp/tau-x402-cage.sock")
        port = int(os.environ.get("TAU_X402_GRPC_PORT", str(DEFAULT_GRPC_PORT)))
        host = os.environ.get("TAU_X402_GRPC_HOST", "0.0.0.0")

        return cls(
            daemon_socket=socket_path,
            bearer_tokens=tokens,
            hmac_secret=secret,
            port=port,
            host=host,
        )


class CageServiceServicer(grpc_pb2_grpc.CageServiceServicer):
    """gRPC surface that proxies every call to the existing UDS daemon.

    ``CheckPayment`` reuses :func:`adapter.x402_client.mediate` so that:
      * the signing path is identical to the HTTP surface (byte-identical
        envelopes for the same input);
      * fail-closed behaviour is identical (daemon down → signed reject);
      * future changes to ``mediate`` propagate automatically.

    ``Health`` and ``InspectPolicy`` talk to the daemon via the lightweight
    ``UdsDaemonClient.request`` helper — there's no reason to ship those ops
    through the mediation path.
    """

    def __init__(self, daemon_socket: str, hmac_secret: bytes) -> None:
        self._daemon_socket = daemon_socket
        self._hmac_secret = hmac_secret

    # ── CheckPayment ────────────────────────────────────────────────────

    def CheckPayment(
        self,
        request: grpc_pb2.CheckPaymentRequest,
        context: grpc.ServicerContext,
    ) -> grpc_pb2.CheckPaymentResponse:
        """Evaluate a payment intent. Byte-identical semantics to HTTP /v1/check."""
        headers, body = _request_to_http_shape(request)
        client = UdsDaemonClient(socket_path=self._daemon_socket)
        try:
            _status, _response_headers, response_body = mediate(
                headers=headers,
                body=body,
                secret=self._hmac_secret,
                daemon=client,
            )
        except Exception as exc:  # defence-in-depth; mediate already fails closed
            logger.exception("grpc CheckPayment mediate raised: %s", exc)
            context.abort(grpc.StatusCode.INTERNAL, f"cage mediate failed: {exc}")
            raise  # unreachable — abort raises RpcError
        envelope = SignedEnvelope.from_json(response_body.decode("utf-8"))
        return _envelope_to_response(envelope)

    # ── Health ──────────────────────────────────────────────────────────

    def Health(
        self,
        request: grpc_pb2.Empty,
        context: grpc.ServicerContext,
    ) -> grpc_pb2.HealthResponse:
        """Liveness probe. Mirrors HTTP /v1/health exactly."""
        return grpc_pb2.HealthResponse(status="ok", version=_APP_VERSION)

    # ── InspectPolicy ───────────────────────────────────────────────────

    def InspectPolicy(
        self,
        request: grpc_pb2.Empty,
        context: grpc.ServicerContext,
    ) -> grpc_pb2.InspectPolicyResponse:
        """Return a read-only snapshot of the active policy."""
        client = UdsDaemonClient(socket_path=self._daemon_socket)
        try:
            response = client.request({"op": "inspect_policy"})
        except (FileNotFoundError, ConnectionRefusedError, socket.timeout) as exc:
            context.abort(
                grpc.StatusCode.UNAVAILABLE,
                f"cage daemon unreachable: {type(exc).__name__}",
            )
            raise  # unreachable
        except Exception as exc:
            context.abort(
                grpc.StatusCode.INTERNAL,
                f"inspect_policy failed: {exc}",
            )
            raise  # unreachable

        invariants = [
            grpc_pb2.InvariantSummary(
                kind=str(inv.get("class", "")),
                rule_id=str(inv.get("rule_id", "")),
                params_json=json.dumps(inv.get("scope_hint") or inv.get("params") or {}),
            )
            for inv in response.get("invariants", [])
        ]
        return grpc_pb2.InspectPolicyResponse(
            revision_id=str(response.get("active_revision_id") or ""),
            compile_hash=str(response.get("compile_hash") or ""),
            active_invariants=int(response.get("active_invariants") or 0),
            invariants=invariants,
        )


# ── request / response translation ───────────────────────────────────────────


def _request_to_http_shape(
    request: grpc_pb2.CheckPaymentRequest,
) -> Tuple[Dict[str, str], bytes]:
    """Translate protobuf CheckPaymentRequest → (headers, raw body) for mediate().

    We reuse ``adapter.x402_client.mediate`` to keep signing semantics in a
    single code path. ``mediate`` expects HTTP-shaped inputs (headers dict +
    raw body bytes) because it feeds them to ``parse_intent``, which accepts
    exactly that shape.
    """
    body: Dict[str, object] = {
        "amount": request.amount,
    }
    # Only emit keys the client explicitly set. Protobuf scalars default to
    # empty strings / zeros; sending those to the daemon would turn defaults
    # into explicit values on the wire and clash with the HTTP layer's
    # "unknown fields pass through verbatim" contract.
    if request.currency:
        body["currency"] = request.currency
    if request.provider:
        body["provider"] = request.provider
    if request.counterparty:
        body["counterparty"] = request.counterparty
    if request.rail:
        body["rail"] = request.rail
    if request.timestamp:
        body["timestamp"] = request.timestamp
    if request.request_id:
        body["request_id"] = request.request_id
    if request.metadata_json:
        try:
            body["metadata"] = json.loads(request.metadata_json)
        except json.JSONDecodeError:
            # Fail closed on malformed metadata — daemon parser will reject
            # anyway; we just skip it so the parse error fires with a clear
            # message rather than a protobuf-specific stack trace.
            pass

    headers = {"content-type": "application/json"}
    raw = json.dumps(body).encode("utf-8")
    return headers, raw


def _envelope_to_response(env: SignedEnvelope) -> grpc_pb2.CheckPaymentResponse:
    """Translate a SignedEnvelope → protobuf CheckPaymentResponse.

    Fields that are ``None`` on the envelope come through as empty strings
    on the protobuf message (protobuf proto3 scalars don't have nullability).
    The wire is still unambiguous because the signed envelope itself is the
    source of truth; the protobuf response is a convenience representation.
    """
    return grpc_pb2.CheckPaymentResponse(
        outcome=env.outcome,
        rule_id=env.rule_id or "",
        witness=env.witness or "",
        reason_text=env.reason_text or "",
        issued_at_unix=int(env.issued_at_unix),
        ttl_seconds=int(env.ttl_seconds),
        intent_hash=env.intent_hash or "",
        mac_hex=env.mac_hex or "",
        mac_alg=getattr(env, "mac_alg", "HMAC-SHA256") or "HMAC-SHA256",
        algorithm=getattr(env, "algorithm", "hmac-sha256") or "hmac-sha256",
        version=getattr(env, "version", "v1") or "v1",
        policy_revision_id=getattr(env, "policy_revision_id", None) or "",
        proof_backend=getattr(env, "proof_backend", None) or "",
        proof_strength=getattr(env, "proof_strength", None) or "",
        prover_mode=getattr(env, "prover_mode", None) or "",
        compile_hash=getattr(env, "compile_hash", None) or "",
    )


# ── server lifecycle ─────────────────────────────────────────────────────────


class CageGrpcServer:
    """Lifecycle wrapper around a grpc.Server bound to :class:`CageServiceServicer`.

    Usage::

        server = CageGrpcServer(
            daemon_socket="/run/cage.sock",
            bearer_tokens=["sk_test_acme_123"],
            hmac_secret=b"\\x00" * 32,
            port=50051,
        )
        server.start()
        server.wait_for_termination()

    The thread pool is sized for sidecar deployments (16 workers by default);
    tune via ``max_workers`` when fronting many agents from one service.

    Graceful shutdown: :meth:`stop` calls ``grpc.Server.stop(grace)`` and
    joins the underlying thread pool so callers can rely on "no orphan
    threads after stop()".
    """

    def __init__(
        self,
        daemon_socket: str,
        bearer_tokens: Iterable[str],
        hmac_secret: bytes,
        *,
        port: int = DEFAULT_GRPC_PORT,
        host: str = "0.0.0.0",
        max_workers: int = DEFAULT_MAX_WORKERS,
    ) -> None:
        self._daemon_socket = daemon_socket
        self._hmac_secret = hmac_secret
        self._tokens = tuple(bearer_tokens)
        self._port = port
        self._host = host
        self._max_workers = max_workers
        self._executor: Optional[futures.ThreadPoolExecutor] = None
        self._server: Optional[grpc.Server] = None
        self._bound_port: Optional[int] = None
        self._lock = threading.Lock()

    @classmethod
    def from_config(cls, config: GrpcServerConfig) -> "CageGrpcServer":
        return cls(
            daemon_socket=config.daemon_socket,
            bearer_tokens=config.bearer_tokens,
            hmac_secret=config.hmac_secret,
            port=config.port,
            host=config.host,
            max_workers=config.max_workers,
        )

    @property
    def port(self) -> int:
        """Return the port the server is bound to.

        Useful when ``port=0`` was passed and the OS picked an ephemeral port
        (tests lean on this to avoid collisions).
        """
        if self._bound_port is None:
            raise RuntimeError("server not started")
        return self._bound_port

    def start(self) -> int:
        """Bind + start the server. Returns the bound port."""
        with self._lock:
            if self._server is not None:
                raise RuntimeError("server already started")
            self._executor = futures.ThreadPoolExecutor(max_workers=self._max_workers)
            interceptors = (_BearerAuthInterceptor(self._tokens),)
            server = grpc.server(self._executor, interceptors=interceptors)
            grpc_pb2_grpc.add_CageServiceServicer_to_server(
                CageServiceServicer(
                    daemon_socket=self._daemon_socket,
                    hmac_secret=self._hmac_secret,
                ),
                server,
            )
            bound = server.add_insecure_port(f"{self._host}:{self._port}")
            if bound == 0:
                self._executor.shutdown(wait=False)
                raise RuntimeError(
                    f"grpc server failed to bind {self._host}:{self._port}"
                )
            server.start()
            self._server = server
            self._bound_port = bound
            logger.info("grpc server listening on %s:%d", self._host, bound)
            return bound

    def stop(self, grace: float = 1.0) -> None:
        """Stop the server + drain the thread pool. Idempotent."""
        with self._lock:
            server = self._server
            executor = self._executor
            self._server = None
            self._executor = None
        if server is None:
            return
        event = server.stop(grace)
        event.wait(timeout=max(grace + 1.0, 2.0))
        if executor is not None:
            executor.shutdown(wait=True)

    def wait_for_termination(self, timeout: Optional[float] = None) -> bool:
        """Block on the underlying grpc.Server. Returns True on clean stop."""
        if self._server is None:
            raise RuntimeError("server not started")
        return self._server.wait_for_termination(timeout=timeout)


__all__ = [
    "CageGrpcServer",
    "CageServiceServicer",
    "GrpcServerConfig",
]
