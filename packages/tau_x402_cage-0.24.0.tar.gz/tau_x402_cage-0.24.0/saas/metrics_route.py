"""Prometheus ``/metrics`` route for the SaaS process (v0.9.0).

Exposes the module-level ``CageMetrics`` singleton as Prometheus text
exposition. Auth is a single bearer token drawn from
``TAU_X402_METRICS_TOKEN`` (fails closed when unset) so ops scrapers
carry their own credential, distinct from the tenant API keys. Keeping
the scrape credential separate avoids leaking tenant keys into
Prometheus retrievers or federated scrapers.

Design
------

* The route factory ``build_metrics_router()`` resolves its token + metrics
  instance at build time (or lazily from the process environment if the
  caller does not pass them), so tests can inject a fresh
  :class:`CageMetrics` without leaking state across cases.
* When ``prometheus_client`` is not installed, the route returns 503 so
  operators see a clear signal rather than a confusingly empty body.
* ``Content-Type`` is the wire format Prometheus expects
  (``text/plain; version=0.0.4; charset=utf-8``).
"""
from __future__ import annotations

import os
from typing import Optional

try:
    from fastapi import APIRouter, Header, HTTPException
    from fastapi.responses import Response
except ImportError as exc:  # pragma: no cover - optional dep
    raise ImportError(
        "saas/metrics_route requires FastAPI: `pip install tau-x402-cage[saas]`"
    ) from exc

from adapter.metrics import (
    CageMetrics,
    _NullMetrics,
    get_default as default_metrics,
    is_available as metrics_available,
)


def build_metrics_router(
    *,
    metrics: "CageMetrics | _NullMetrics | None" = None,
    token: Optional[str] = None,
) -> APIRouter:
    """Build a FastAPI router exposing ``/metrics``.

    Args:
        metrics: optional pre-built :class:`CageMetrics`. When None, the
            module-level default singleton is used — same one the daemon
            increments.
        token: expected bearer token. When None, read from
            ``TAU_X402_METRICS_TOKEN`` at call time. Empty / unset token
            fails closed (every request rejected with 403).
    """
    resolved_metrics = metrics if metrics is not None else default_metrics()
    resolved_token = (
        token if token is not None
        else os.environ.get("TAU_X402_METRICS_TOKEN", "")
    )

    router = APIRouter()

    def _check_auth(authorization: str) -> None:
        if not resolved_token:
            raise HTTPException(
                status_code=403,
                detail="metrics scrape not provisioned "
                       "(TAU_X402_METRICS_TOKEN unset)",
            )
        if not authorization.startswith("Bearer "):
            raise HTTPException(
                status_code=403, detail="missing Bearer token"
            )
        supplied = authorization[len("Bearer "):].strip()
        if supplied != resolved_token:
            raise HTTPException(status_code=403, detail="invalid token")

    @router.get("/metrics")
    def metrics_endpoint(
        authorization: str = Header(default=""),
    ) -> Response:
        _check_auth(authorization)
        if not metrics_available():
            raise HTTPException(
                status_code=503,
                detail="prometheus_client not installed on this deployment",
            )
        body = resolved_metrics.render_text()
        return Response(
            content=body,
            media_type=resolved_metrics.content_type(),
        )

    return router
