"""Pydantic response models for the SaaS FastAPI surface.

These models exist so FastAPI can emit a typed, enterprise-friendly OpenAPI
3.1 schema at ``/openapi.json`` and render ``/docs``. Procurement reviewers
ask for "the API spec" — we generate it from these models instead of
hand-maintaining a separate swagger file.

Design notes
------------

* Every public route has a request model + response model — no
  ``Dict[str, Any]`` return types. That's what lets the OpenAPI generator
  produce actionable schemas (fields + types + descriptions).
* The ``SignedEnvelopeModel`` deliberately mirrors the
  ``adapter.verdict_signer.SignedEnvelope`` dataclass shape 1:1. We keep
  them as separate types (rather than ``pydantic.BaseModel`` subclassing
  the dataclass) because the envelope is serialized by
  ``SignedEnvelope.to_json`` with its own canonical separators, and we
  don't want Pydantic picking up field-order changes silently.
* ``ErrorEnvelope`` matches FastAPI's default validation-error shape on
  ``detail`` while staying typed for 401/403/500 hand-raised errors too.
* The daemon operation response models (``InspectPolicy``, ``Proposal``,
  ``Revision``, ``Branch``) are present so future HTTP endpoints that
  expose those operations don't need to reinvent their schema. v0.9.0
  wires the ones the SaaS currently surfaces; the rest act as a
  contract target for v0.10+.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

try:
    from pydantic import BaseModel, Field
except ImportError as exc:  # pragma: no cover - FastAPI always brings pydantic
    raise ImportError(
        "saas/models.py requires pydantic (installed via `tau-x402-cage[saas]`)"
    ) from exc


# ── error envelope ───────────────────────────────────────────────────────────


class ErrorEnvelope(BaseModel):
    """Uniform error response shape.

    FastAPI's default is ``{"detail": "..."}``; we document it here so the
    OpenAPI schema lists 4xx/5xx responses with a real model rather than
    an untyped blob.
    """

    detail: str = Field(
        ..., description="Human-readable error reason."
    )

    model_config = {
        "json_schema_extra": {
            "examples": [
                {"detail": "invalid API key"},
                {"detail": "missing Bearer token"},
            ]
        }
    }


# ── /v1/check request + response ─────────────────────────────────────────────


class CheckPaymentRequest(BaseModel):
    """An x402-shaped payment intent the agent wants the cage to evaluate.

    The schema mirrors ``adapter.payment_intent_matcher.parse_x402``. The
    SaaS proxies the intent to the daemon verbatim and returns the
    daemon's signed verdict envelope. Unknown extra fields are preserved
    on the wire so rail-specific metadata (e.g. ``rail="x402"``) passes
    through without a schema update.
    """

    amount: str = Field(
        ...,
        description="Decimal amount as a string (avoids float precision loss).",
        examples=["50.00", "1.25"],
    )
    currency: str = Field(
        default="USDC",
        description="ISO-style currency code. USDC is the x402 reference rail.",
        examples=["USDC", "USD"],
    )
    provider: str = Field(
        ...,
        description="Service provider the agent is paying (e.g. 'anthropic').",
        examples=["anthropic", "openai"],
    )
    counterparty: str = Field(
        ...,
        description="Concrete payee identifier (vendor id / wallet / facilitator).",
        examples=["vendor_x", "0xabc123"],
    )
    rail: Optional[str] = Field(
        default=None,
        description="Payment rail identifier. Defaults to 'x402' on the daemon.",
        examples=["x402", "mpp"],
    )
    timestamp: Optional[int] = Field(
        default=None,
        description="Unix timestamp (seconds). Defaults to server time.",
        examples=[1700000000],
    )
    metadata: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Free-form rail-specific metadata (pass-through).",
    )
    request_id: Optional[str] = Field(
        default=None,
        description="Client-supplied idempotency id, echoed in the envelope.",
    )

    model_config = {
        "json_schema_extra": {
            "examples": [
                {
                    "amount": "50.00",
                    "currency": "USDC",
                    "provider": "anthropic",
                    "counterparty": "vendor_x",
                    "rail": "x402",
                    "timestamp": 1700000000,
                }
            ]
        }
    }


class SignedEnvelopeModel(BaseModel):
    """Wire shape of ``adapter.verdict_signer.SignedEnvelope``.

    Present as a typed model so the OpenAPI schema documents every field
    an auditor would want to inspect (MAC, intent_hash, TTL, v2 provenance).
    The v2 provenance fields are optional so the same model describes both
    envelope versions.
    """

    outcome: str = Field(
        ..., description="'permit' or 'reject'.", examples=["permit", "reject"]
    )
    rule_id: Optional[str] = Field(
        default=None,
        description="Rule that fired on reject (None on permit).",
        examples=["max_per_call", "spending_cap"],
    )
    witness: Optional[str] = Field(
        default=None,
        description="Machine-readable violation witness (e.g. 'intent=1001,cap=50').",
    )
    reason_text: Optional[str] = Field(
        default=None,
        description="Plain-English explanation — the TTI-critical field.",
    )
    issued_at_unix: int = Field(
        ..., description="Unix seconds timestamp when the verdict was signed."
    )
    ttl_seconds: int = Field(
        ..., description="How long the envelope stays replay-resistant."
    )
    intent_hash: str = Field(
        ..., description="SHA-256 of the canonical PaymentIntent, hex-encoded."
    )
    mac_hex: str = Field(
        ..., description="Hex-encoded HMAC-SHA256 or Ed25519 signature."
    )
    mac_alg: str = Field(
        default="HMAC-SHA256",
        description="Legacy human label for the MAC algorithm.",
    )
    algorithm: str = Field(
        default="hmac-sha256",
        description="Canonical algorithm id bound inside the signed payload.",
    )
    version: str = Field(
        default="v1",
        description="Envelope wire version: 'v1' (no provenance) or 'v2'.",
    )
    policy_revision_id: Optional[str] = Field(default=None)
    proof_backend: Optional[str] = Field(default=None)
    proof_strength: Optional[str] = Field(default=None)
    prover_mode: Optional[str] = Field(default=None)
    compile_hash: Optional[str] = Field(default=None)


class CheckPaymentResponse(BaseModel):
    """Response from ``POST /v1/check``.

    The HTTP status code encodes the coarse verdict (200 permit, 403
    reject). The body is the full signed envelope so clients can verify
    the MAC and inspect the witness without a second round trip.
    """

    outcome: str = Field(..., description="'permit' or 'reject'.")
    rule_id: Optional[str] = Field(default=None)
    witness: Optional[str] = Field(default=None)
    reason_text: Optional[str] = Field(default=None)
    issued_at_unix: int = Field(...)
    ttl_seconds: int = Field(...)
    intent_hash: str = Field(...)
    mac_hex: str = Field(...)
    mac_alg: str = Field(default="HMAC-SHA256")
    algorithm: str = Field(default="hmac-sha256")
    version: str = Field(default="v1")
    policy_revision_id: Optional[str] = Field(default=None)
    proof_backend: Optional[str] = Field(default=None)
    proof_strength: Optional[str] = Field(default=None)
    prover_mode: Optional[str] = Field(default=None)
    compile_hash: Optional[str] = Field(default=None)

    model_config = {
        "json_schema_extra": {
            "examples": [
                {
                    "outcome": "reject",
                    "rule_id": "max_per_call",
                    "witness": "intent=1001,cap=50",
                    "reason_text": "Single-call cap 50 USDC exceeded (intent: 1001)",
                    "issued_at_unix": 1700000000,
                    "ttl_seconds": 30,
                    "intent_hash": "ab3c…",
                    "mac_hex": "7e91…",
                    "mac_alg": "HMAC-SHA256",
                    "algorithm": "hmac-sha256",
                    "version": "v1",
                }
            ]
        }
    }


# ── /v1/health, /v1/usage ────────────────────────────────────────────────────


class HealthResponse(BaseModel):
    """Liveness probe response."""

    status: str = Field(..., description="'ok' when the SaaS is serving.")
    version: str = Field(..., description="Application version string.")

    model_config = {
        "json_schema_extra": {
            "examples": [{"status": "ok", "version": "0.9.0"}]
        }
    }


class UsageCounters(BaseModel):
    """Per-verdict counter pair."""

    permit: int = Field(default=0, ge=0)
    reject: int = Field(default=0, ge=0)


class MetricsResponse(BaseModel):
    """Response from ``GET /v1/usage`` — per-tenant verdict counters.

    Named ``MetricsResponse`` per the v0.9.0 spec so future Prometheus
    work reuses the same contract. Current implementation returns the
    in-memory counter snapshot for the authenticated tenant only.
    """

    tenant: str = Field(..., description="Authenticated tenant id.")
    counters: UsageCounters = Field(
        default_factory=UsageCounters,
        description="Cumulative permit/reject counts since process start.",
    )

    model_config = {
        "json_schema_extra": {
            "examples": [
                {
                    "tenant": "acme",
                    "counters": {"permit": 12, "reject": 3},
                }
            ]
        }
    }


# ── policy inspection / explanation (daemon ops, contract target) ────────────


class InvariantSummary(BaseModel):
    """One invariant currently installed in the policy."""

    kind: str = Field(..., description="Invariant type (e.g. 'max_per_call').")
    rule_id: str = Field(..., description="Stable id used on reject witnesses.")
    params: Dict[str, Any] = Field(
        default_factory=dict,
        description="Type-specific parameters (amount caps, windows, allowlists).",
    )


class InspectPolicyResponse(BaseModel):
    """Response to a policy-inspection request.

    Contract target: the HTTP endpoint is not yet exposed in v0.9.0 but
    the daemon already answers ``op=inspect_policy``. Shipping the model
    now lets clients pin against the schema before the route lands.
    """

    revision_id: Optional[str] = Field(default=None)
    compile_hash: Optional[str] = Field(default=None)
    invariants: List[InvariantSummary] = Field(default_factory=list)


class ExplainPolicyResponse(BaseModel):
    """Response to a human-facing policy-explanation request."""

    revision_id: Optional[str] = Field(default=None)
    explanation: str = Field(
        ..., description="Plain-English description of the active policy."
    )
    rules: List[str] = Field(
        default_factory=list,
        description="Ordered list of rule sentences, one per invariant.",
    )


# ── proposals / approval queue (daemon ops, contract target) ─────────────────


class ProposalResponse(BaseModel):
    """A single entry in the agent-proposes / human-approves queue."""

    proposal_id: str = Field(...)
    status: str = Field(
        ..., description="'pending', 'approved', 'rejected', or 'expired'."
    )
    proposed_by: Optional[str] = Field(default=None)
    created_at_unix: int = Field(...)
    diff: Optional[Dict[str, Any]] = Field(
        default=None, description="Structured policy diff the proposer submitted."
    )


class ProposalListResponse(BaseModel):
    """List response for the approval queue."""

    proposals: List[ProposalResponse] = Field(default_factory=list)
    total: int = Field(default=0, ge=0)


# ── revisions / branches (daemon ops, contract target) ───────────────────────


class RevisionResponse(BaseModel):
    """One policy revision in the audit chain."""

    revision_id: str = Field(...)
    parent_id: Optional[str] = Field(default=None)
    created_at_unix: int = Field(...)
    compile_hash: Optional[str] = Field(default=None)
    delta: Optional[Dict[str, Any]] = Field(
        default=None, description="Structured delta from parent revision."
    )


class BranchResponse(BaseModel):
    """A named branch pointing at a revision head."""

    name: str = Field(...)
    head_revision_id: str = Field(...)
    created_at_unix: int = Field(...)
