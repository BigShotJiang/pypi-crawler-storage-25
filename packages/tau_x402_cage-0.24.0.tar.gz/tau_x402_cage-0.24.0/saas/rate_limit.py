"""Per-tenant rate limiting and monthly quotas for the SaaS (v0.12.0).

Why this module exists
----------------------

``POST /v1/check`` is the SaaS's only interesting surface and it is
unmetered by default. A buggy customer agent loop can hammer the cage
and, once fragment-v2 policies enter the mix, drag real money with it
(z3 bounded unrolling is not free). Monthly quotas are table-stakes for
tiered pricing. Both concerns live here so the SaaS middleware has a
single gate to call.

Design
------

* Two knobs per tenant: a **token bucket** enforcing steady-state QPS
  plus a fixed burst, and a **monthly counter** clipping total volume.
* A :class:`RateLimiter` Protocol so the SaaS middleware never cares
  whether the backing store is in-process dict or Redis.
* :class:`InMemoryRateLimiter` is zero-dep (process-local, adequate
  for single-replica dev and tests).
* :class:`RedisRateLimiter` talks to Redis over an atomic Lua script so
  concurrent acquires across multiple SaaS replicas cannot double-count.
* Fail-closed preflight on Redis unreachable at startup — matches the
  v0.8.0 history-store pattern. Silent in-memory fallback on a
  Redis-configured deployment would put QPS on a per-replica rather
  than per-tenant basis, which is the specific failure the Redis
  backend exists to prevent.
* All state mutation goes through :meth:`try_acquire`; it returns a
  rich :class:`AcquireResult` so the caller can surface ``Retry-After``
  and observability headers without a second round trip.

Per-tenant overrides
--------------------

``TAU_X402_RATE_LIMIT_OVERRIDES`` is a JSON object keyed by tenant id;
missing tenants fall through to the defaults. This is a v0.12.0
pragmatic shortcut — enterprise tenants negotiate custom limits and we
need somewhere to put them without a control plane yet.
"""
from __future__ import annotations

import json
import logging
import math
import os
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Mapping, Optional, Protocol


logger = logging.getLogger(__name__)


# ── data types ───────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class RateLimitConfig:
    """Resolved configuration for a single tenant's limits.

    Immutable on purpose — a fresh config object is built when an
    override is applied, never mutated in place.
    """

    qps: float
    burst: int
    monthly_quota: int

    def __post_init__(self) -> None:
        if self.qps <= 0:
            raise ValueError(f"qps must be > 0, got {self.qps}")
        if self.burst <= 0:
            raise ValueError(f"burst must be > 0, got {self.burst}")
        if self.monthly_quota < 0:
            raise ValueError(
                f"monthly_quota must be >= 0, got {self.monthly_quota}"
            )


@dataclass(frozen=True)
class AcquireResult:
    """Outcome of a single :meth:`RateLimiter.try_acquire` call.

    ``allowed`` is the load-bearing field; the rest drive response
    headers so clients and dashboards see the same numbers the limiter
    saw.
    """

    allowed: bool
    remaining: int
    reset_at_unix: int
    retry_after_s: float
    limit: int
    quota_remaining: int
    quota_limit: int
    quota_reset_at_unix: int
    reason: Optional[str] = None  # "qps" or "quota" on reject, None on permit


@dataclass(frozen=True)
class QuotaStatus:
    """Monthly-quota snapshot for observability / ``/v1/usage``."""

    allowed: bool
    remaining: int
    reset_at_unix: int
    retry_after_s: float
    limit: int


# ── protocol ─────────────────────────────────────────────────────────────────


class RateLimiter(Protocol):
    """Contract every rate-limiter backend implements.

    The SaaS middleware depends on this protocol; concrete backends
    (in-memory, Redis, or a future hosted KV service) plug in behind
    :func:`build_rate_limiter`.
    """

    def try_acquire(self, tenant_id: str) -> AcquireResult:
        """Try to reserve one admission slot for ``tenant_id``.

        Returns an :class:`AcquireResult` whose ``allowed`` flag tells
        the caller whether to proceed or return 429.
        """
        ...

    def monthly_quota_status(self, tenant_id: str) -> QuotaStatus:
        """Read-only quota snapshot; no state mutation."""
        ...


class RateLimitError(RuntimeError):
    """Raised when the backing store is unreachable or misconfigured."""


# ── clocks + month boundaries ────────────────────────────────────────────────


Clock = Callable[[], float]


def _default_clock() -> float:
    """Unix timestamp with sub-second resolution. Injectable for tests."""
    return time.time()


def _month_key(ts: float) -> str:
    """Stable ``YYYY-MM`` bucket for the quota counter.

    UTC on purpose: tenant local timezones drift the reset boundary,
    which operators hate and auditors cannot reason about.
    """
    struct = time.gmtime(ts)
    return f"{struct.tm_year:04d}-{struct.tm_mon:02d}"


def _month_reset_at(ts: float) -> int:
    """Unix timestamp of the next month rollover (UTC), seconds."""
    struct = time.gmtime(ts)
    year = struct.tm_year
    month = struct.tm_mon + 1
    if month > 12:
        month = 1
        year += 1
    # ``calendar.timegm`` would be ideal but stdlib ``time.gmtime`` +
    # manual compose keeps the dependency surface tiny.
    rollover = time.struct_time(
        (year, month, 1, 0, 0, 0, 0, 0, 0)
    )
    # ``timegm`` is in ``calendar``; use it — round-trip is well-defined.
    import calendar
    return int(calendar.timegm(rollover))


# ── in-memory token bucket ───────────────────────────────────────────────────


@dataclass
class _BucketState:
    """Mutable state for one tenant's token bucket + monthly counter.

    Locked by :class:`InMemoryRateLimiter._lock` when read or written.
    Kept as a dataclass (not a frozen one) specifically because token
    bucket math mutates in place inside the hot path; the immutability
    rule applies to the public-facing result objects.
    """

    tokens: float
    last_refill_unix: float
    monthly_count: int
    monthly_bucket: str


class InMemoryRateLimiter:
    """Process-local token-bucket + monthly-counter rate limiter.

    Adequate for single-replica dev deployments. Multiple SaaS replicas
    share nothing — each one enforces its own bucket independently, so
    a tenant's effective QPS is ``N × qps``. Production ships the Redis
    backend for exactly this reason.
    """

    def __init__(
        self,
        default_config: RateLimitConfig,
        *,
        overrides: Optional[Mapping[str, RateLimitConfig]] = None,
        clock: Optional[Clock] = None,
    ) -> None:
        self._default = default_config
        self._overrides: Dict[str, RateLimitConfig] = dict(overrides or {})
        self._clock = clock or _default_clock
        self._lock = threading.Lock()
        self._state: Dict[str, _BucketState] = {}

    def _config_for(self, tenant_id: str) -> RateLimitConfig:
        return self._overrides.get(tenant_id, self._default)

    def _state_for(
        self,
        tenant_id: str,
        cfg: RateLimitConfig,
        now: float,
    ) -> _BucketState:
        """Return or initialize bucket state, rolling the month counter
        when the calendar month changes."""
        state = self._state.get(tenant_id)
        current_month = _month_key(now)
        if state is None:
            state = _BucketState(
                tokens=float(cfg.burst),
                last_refill_unix=now,
                monthly_count=0,
                monthly_bucket=current_month,
            )
            self._state[tenant_id] = state
            return state
        if state.monthly_bucket != current_month:
            # Month rolled over — reset counter but keep the bucket
            # tokens since QPS and quota are orthogonal.
            state.monthly_count = 0
            state.monthly_bucket = current_month
        return state

    @staticmethod
    def _refill(state: _BucketState, cfg: RateLimitConfig, now: float) -> None:
        """Add tokens accrued since the last refill, capped at burst."""
        elapsed = max(0.0, now - state.last_refill_unix)
        if elapsed <= 0.0:
            return
        added = elapsed * cfg.qps
        state.tokens = min(float(cfg.burst), state.tokens + added)
        state.last_refill_unix = now

    def try_acquire(self, tenant_id: str) -> AcquireResult:
        cfg = self._config_for(tenant_id)
        now = self._clock()
        with self._lock:
            state = self._state_for(tenant_id, cfg, now)
            self._refill(state, cfg, now)

            quota_remaining_before = max(0, cfg.monthly_quota - state.monthly_count)
            quota_reset = _month_reset_at(now)

            # Quota check first: a tenant who has blown their monthly
            # allowance cannot consume a bucket token either.
            if state.monthly_count >= cfg.monthly_quota:
                # No token consumed, no counter bumped.
                return AcquireResult(
                    allowed=False,
                    remaining=int(state.tokens),
                    reset_at_unix=_bucket_reset_at(state, cfg, now),
                    retry_after_s=max(0.0, quota_reset - now),
                    limit=cfg.burst,
                    quota_remaining=0,
                    quota_limit=cfg.monthly_quota,
                    quota_reset_at_unix=quota_reset,
                    reason="quota",
                )

            if state.tokens < 1.0:
                retry_after = (1.0 - state.tokens) / cfg.qps
                return AcquireResult(
                    allowed=False,
                    remaining=0,
                    reset_at_unix=_bucket_reset_at(state, cfg, now),
                    retry_after_s=retry_after,
                    limit=cfg.burst,
                    quota_remaining=quota_remaining_before,
                    quota_limit=cfg.monthly_quota,
                    quota_reset_at_unix=quota_reset,
                    reason="qps",
                )

            # Permit — consume a token and bump the monthly counter.
            state.tokens -= 1.0
            state.monthly_count += 1
            return AcquireResult(
                allowed=True,
                remaining=int(state.tokens),
                reset_at_unix=_bucket_reset_at(state, cfg, now),
                retry_after_s=0.0,
                limit=cfg.burst,
                quota_remaining=max(0, cfg.monthly_quota - state.monthly_count),
                quota_limit=cfg.monthly_quota,
                quota_reset_at_unix=quota_reset,
                reason=None,
            )

    def monthly_quota_status(self, tenant_id: str) -> QuotaStatus:
        cfg = self._config_for(tenant_id)
        now = self._clock()
        with self._lock:
            state = self._state_for(tenant_id, cfg, now)
            remaining = max(0, cfg.monthly_quota - state.monthly_count)
            reset = _month_reset_at(now)
            return QuotaStatus(
                allowed=state.monthly_count < cfg.monthly_quota,
                remaining=remaining,
                reset_at_unix=reset,
                retry_after_s=max(0.0, reset - now) if remaining == 0 else 0.0,
                limit=cfg.monthly_quota,
            )


def _bucket_reset_at(
    state: _BucketState, cfg: RateLimitConfig, now: float
) -> int:
    """Unix timestamp when the bucket returns to full ``burst`` tokens."""
    deficit = max(0.0, cfg.burst - state.tokens)
    if deficit <= 0.0:
        return int(math.floor(now))
    return int(math.ceil(now + deficit / cfg.qps))


# ── Redis token bucket ───────────────────────────────────────────────────────


_ACQUIRE_LUA = """
-- KEYS[1] = bucket key (hash: tokens, last_refill_ms)
-- KEYS[2] = monthly counter key (int)
-- ARGV[1] = now_ms
-- ARGV[2] = qps (float)
-- ARGV[3] = burst (int)
-- ARGV[4] = monthly_quota (int)
-- ARGV[5] = monthly_ttl_s (int)
-- Returns {allowed, tokens_int, monthly_count, retry_after_ms}
local now_ms = tonumber(ARGV[1])
local qps = tonumber(ARGV[2])
local burst = tonumber(ARGV[3])
local quota = tonumber(ARGV[4])
local monthly_ttl = tonumber(ARGV[5])

local bucket = redis.call('HMGET', KEYS[1], 'tokens', 'last_refill_ms')
local tokens = tonumber(bucket[1])
local last_ms = tonumber(bucket[2])
if tokens == nil then
    tokens = burst
    last_ms = now_ms
end

local elapsed_ms = now_ms - last_ms
if elapsed_ms < 0 then
    elapsed_ms = 0
end
local added = (elapsed_ms / 1000.0) * qps
tokens = math.min(burst, tokens + added)

local count = tonumber(redis.call('GET', KEYS[2]) or '0')

if count >= quota then
    -- quota exhausted: persist refilled tokens but do not consume.
    redis.call('HMSET', KEYS[1], 'tokens', tostring(tokens), 'last_refill_ms', tostring(now_ms))
    redis.call('EXPIRE', KEYS[1], monthly_ttl)
    return {0, math.floor(tokens), count, -1, 2}
end

if tokens < 1.0 then
    redis.call('HMSET', KEYS[1], 'tokens', tostring(tokens), 'last_refill_ms', tostring(now_ms))
    redis.call('EXPIRE', KEYS[1], monthly_ttl)
    local deficit = 1.0 - tokens
    local retry_ms = math.ceil((deficit / qps) * 1000.0)
    return {0, 0, count, retry_ms, 1}
end

tokens = tokens - 1.0
redis.call('HMSET', KEYS[1], 'tokens', tostring(tokens), 'last_refill_ms', tostring(now_ms))
redis.call('EXPIRE', KEYS[1], monthly_ttl)
count = redis.call('INCR', KEYS[2])
-- Set TTL the first time the counter is created so the month rolls.
if count == 1 then
    redis.call('EXPIRE', KEYS[2], monthly_ttl)
end
return {1, math.floor(tokens), count, 0, 0}
"""


class RedisRateLimiter:
    """Redis-backed token-bucket + monthly-quota rate limiter.

    The hot path is a single ``EVALSHA`` against :data:`_ACQUIRE_LUA`,
    which reads and mutates the bucket + counter atomically. This keeps
    the behaviour correct under concurrent SaaS replicas (the whole
    reason Redis is here in the first place).

    Startup fails fast (``RateLimitError``) if Redis is unreachable.
    Matches the history-store and revision-sync patterns — silent
    in-memory fallback would give an operator an "all green" SaaS that
    was in fact running N independent buckets per replica.
    """

    def __init__(
        self,
        url: str,
        default_config: RateLimitConfig,
        *,
        overrides: Optional[Mapping[str, RateLimitConfig]] = None,
        redis_client: Any = None,
        key_prefix: str = "tau-x402-cage:rate:",
        clock: Optional[Clock] = None,
    ) -> None:
        if not url and redis_client is None:
            raise ValueError(
                "RedisRateLimiter requires a url or a redis_client"
            )
        self._url = url
        self._default = default_config
        self._overrides: Dict[str, RateLimitConfig] = dict(overrides or {})
        self._key_prefix = key_prefix
        self._clock = clock or _default_clock
        if redis_client is not None:
            self._client = redis_client
        else:
            try:
                import redis  # type: ignore[import-untyped]
            except ImportError as exc:
                raise RateLimitError(
                    "redis backend requested but the `redis` package is not "
                    "installed. Install with: "
                    "pip install 'tau-x402-cage[rate-limit-redis]'"
                ) from exc
            try:
                self._client = redis.Redis.from_url(
                    url,
                    decode_responses=True,
                    socket_connect_timeout=2.0,
                )
            except Exception as exc:  # pragma: no cover
                raise RateLimitError(
                    f"could not construct redis client for url={url!r}: {exc}"
                ) from exc
        self._preflight()
        # Register the Lua script once; the client re-sends on NOSCRIPT.
        try:
            self._acquire_script = self._client.register_script(_ACQUIRE_LUA)
        except Exception as exc:  # pragma: no cover
            raise RateLimitError(
                f"redis SCRIPT LOAD failed at {self._url!r}: {exc}"
            ) from exc

    def _preflight(self) -> None:
        try:
            ok = self._client.ping()
        except Exception as exc:
            raise RateLimitError(
                f"redis unreachable at {self._url!r}: {exc}. Refusing to "
                f"start with silent in-memory fallback; fix Redis or "
                f"switch TAU_X402_RATE_LIMIT_BACKEND=memory."
            ) from exc
        if not ok:
            raise RateLimitError(
                f"redis PING returned falsy value at {self._url!r}; aborting"
            )

    def _config_for(self, tenant_id: str) -> RateLimitConfig:
        return self._overrides.get(tenant_id, self._default)

    def _bucket_key(self, tenant_id: str) -> str:
        return f"{self._key_prefix}bucket:{tenant_id}"

    def _monthly_key(self, tenant_id: str, now: float) -> str:
        return f"{self._key_prefix}monthly:{tenant_id}:{_month_key(now)}"

    def try_acquire(self, tenant_id: str) -> AcquireResult:
        cfg = self._config_for(tenant_id)
        now = self._clock()
        now_ms = int(now * 1000)
        quota_reset = _month_reset_at(now)
        monthly_ttl = max(60, int(quota_reset - now) + 60)  # small buffer
        bucket_key = self._bucket_key(tenant_id)
        monthly_key = self._monthly_key(tenant_id, now)

        try:
            raw = self._acquire_script(
                keys=[bucket_key, monthly_key],
                args=[now_ms, cfg.qps, cfg.burst, cfg.monthly_quota, monthly_ttl],
            )
        except Exception as exc:
            # Fail-closed on hot-path Redis outages. The preflight
            # already gated startup; anything here is a transient blip,
            # which we surface to the operator as a reject rather than
            # papering over with a permit.
            logger.error("redis rate limiter unreachable: %s", exc)
            raise RateLimitError(
                f"redis acquire failed at {self._url!r}: {exc}"
            ) from exc

        allowed_int, tokens_int, count, retry_ms, reason_code = _coerce_lua(raw)
        allowed = allowed_int == 1
        quota_remaining = max(0, cfg.monthly_quota - int(count))
        bucket_reset = _bucket_reset_from_tokens(
            tokens=float(tokens_int), cfg=cfg, now=now
        )
        if allowed:
            reason = None
            retry_after = 0.0
        elif reason_code == 2:
            reason = "quota"
            retry_after = max(0.0, quota_reset - now)
        else:
            reason = "qps"
            retry_after = max(0.0, retry_ms / 1000.0) if retry_ms > 0 else 0.0
        return AcquireResult(
            allowed=allowed,
            remaining=int(tokens_int),
            reset_at_unix=bucket_reset,
            retry_after_s=retry_after,
            limit=cfg.burst,
            quota_remaining=quota_remaining,
            quota_limit=cfg.monthly_quota,
            quota_reset_at_unix=quota_reset,
            reason=reason,
        )

    def monthly_quota_status(self, tenant_id: str) -> QuotaStatus:
        cfg = self._config_for(tenant_id)
        now = self._clock()
        monthly_key = self._monthly_key(tenant_id, now)
        try:
            raw = self._client.get(monthly_key)
        except Exception as exc:
            raise RateLimitError(
                f"redis get monthly counter failed at {self._url!r}: {exc}"
            ) from exc
        count = int(raw) if raw is not None else 0
        remaining = max(0, cfg.monthly_quota - count)
        reset = _month_reset_at(now)
        return QuotaStatus(
            allowed=count < cfg.monthly_quota,
            remaining=remaining,
            reset_at_unix=reset,
            retry_after_s=max(0.0, reset - now) if remaining == 0 else 0.0,
            limit=cfg.monthly_quota,
        )


def _coerce_lua(raw: Any) -> tuple[int, int, int, int, int]:
    """Normalize the Lua script return value across redis-py and fakeredis.

    Both surface a list; we pin types to keep downstream math honest.
    """
    if not isinstance(raw, (list, tuple)) or len(raw) < 5:
        raise RateLimitError(f"malformed Lua reply: {raw!r}")
    return (
        int(raw[0]),
        int(raw[1]),
        int(raw[2]),
        int(raw[3]),
        int(raw[4]),
    )


def _bucket_reset_from_tokens(
    *, tokens: float, cfg: RateLimitConfig, now: float
) -> int:
    deficit = max(0.0, cfg.burst - tokens)
    if deficit <= 0.0:
        return int(math.floor(now))
    return int(math.ceil(now + deficit / cfg.qps))


# ── factory ──────────────────────────────────────────────────────────────────


_ENV_BACKEND = "TAU_X402_RATE_LIMIT_BACKEND"
_ENV_QPS = "TAU_X402_RATE_LIMIT_QPS"
_ENV_BURST = "TAU_X402_RATE_LIMIT_BURST"
_ENV_QUOTA = "TAU_X402_MONTHLY_QUOTA"
_ENV_REDIS_URL = "TAU_X402_RATE_LIMIT_REDIS_URL"
_ENV_OVERRIDES = "TAU_X402_RATE_LIMIT_OVERRIDES"


def _parse_overrides(
    raw: str, default: RateLimitConfig
) -> Dict[str, RateLimitConfig]:
    """Parse the override JSON blob into a tenant -> config map.

    A bad blob raises ``RateLimitError`` — we want a loud startup
    error rather than a silent fall-through to defaults, which would
    leave paying tenants on freemium limits without anyone noticing.
    """
    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise RateLimitError(
            f"{_ENV_OVERRIDES} must be valid JSON: {exc}"
        ) from exc
    if not isinstance(parsed, dict):
        raise RateLimitError(
            f"{_ENV_OVERRIDES} must decode to an object "
            f"{{tenant_id: {{qps, burst, monthly_quota}}}}"
        )
    out: Dict[str, RateLimitConfig] = {}
    for tenant_id, spec in parsed.items():
        if not isinstance(spec, dict):
            raise RateLimitError(
                f"{_ENV_OVERRIDES} entry for {tenant_id!r} must be an object"
            )
        qps = float(spec.get("qps", default.qps))
        burst = int(spec.get("burst", default.burst))
        quota = int(spec.get("monthly_quota", default.monthly_quota))
        try:
            out[tenant_id] = RateLimitConfig(
                qps=qps, burst=burst, monthly_quota=quota
            )
        except ValueError as exc:
            raise RateLimitError(
                f"{_ENV_OVERRIDES} entry for {tenant_id!r}: {exc}"
            ) from exc
    return out


def build_rate_limiter(
    env: Optional[Mapping[str, str]] = None,
    *,
    redis_client: Any = None,
    clock: Optional[Clock] = None,
) -> RateLimiter:
    """Factory: pick an implementation based on environment.

    Reads the following env vars:

    * ``TAU_X402_RATE_LIMIT_BACKEND`` — ``memory`` (default) or ``redis``.
    * ``TAU_X402_RATE_LIMIT_QPS`` — default 10 req/s per tenant.
    * ``TAU_X402_RATE_LIMIT_BURST`` — default 20 tokens.
    * ``TAU_X402_MONTHLY_QUOTA`` — default 100_000 per tenant per calendar month.
    * ``TAU_X402_RATE_LIMIT_REDIS_URL`` — required when backend is ``redis``.
    * ``TAU_X402_RATE_LIMIT_OVERRIDES`` — optional JSON object keyed by
      tenant id: ``{"acme": {"qps": 100, "burst": 200, "monthly_quota": 10000000}}``.

    On preflight failure (Redis unreachable) or malformed override JSON,
    raises :class:`RateLimitError` so the SaaS fails to boot.
    """
    env = env if env is not None else os.environ
    backend = env.get(_ENV_BACKEND, "memory").strip().lower()

    try:
        qps = float(env.get(_ENV_QPS, "10"))
    except ValueError as exc:
        raise RateLimitError(f"{_ENV_QPS} must be a number: {exc}") from exc
    try:
        burst = int(env.get(_ENV_BURST, "20"))
    except ValueError as exc:
        raise RateLimitError(f"{_ENV_BURST} must be an integer: {exc}") from exc
    try:
        quota = int(env.get(_ENV_QUOTA, "100000"))
    except ValueError as exc:
        raise RateLimitError(f"{_ENV_QUOTA} must be an integer: {exc}") from exc

    try:
        default_cfg = RateLimitConfig(qps=qps, burst=burst, monthly_quota=quota)
    except ValueError as exc:
        raise RateLimitError(str(exc)) from exc

    overrides_raw = env.get(_ENV_OVERRIDES, "").strip()
    overrides = (
        _parse_overrides(overrides_raw, default_cfg) if overrides_raw else {}
    )

    if backend == "memory":
        return InMemoryRateLimiter(
            default_cfg, overrides=overrides, clock=clock
        )
    if backend == "redis":
        url = env.get(_ENV_REDIS_URL, "")
        if not url and redis_client is None:
            raise RateLimitError(
                f"{_ENV_BACKEND}=redis requires {_ENV_REDIS_URL} (or an "
                f"injected redis client)"
            )
        return RedisRateLimiter(
            url=url,
            default_config=default_cfg,
            overrides=overrides,
            redis_client=redis_client,
            clock=clock,
        )
    raise RateLimitError(
        f"{_ENV_BACKEND} must be 'memory' or 'redis', got {backend!r}"
    )
