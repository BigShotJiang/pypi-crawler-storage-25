"""FastAPI entry point for the hosted Tau x402 Cage SaaS.

Endpoints:

    POST /v1/check          -> proxy a payment intent to the cage daemon,
                               return the signed verdict envelope
    GET  /v1/health         -> liveness
    GET  /v1/usage           -> usage counters for the authenticated tenant

Auth: single-tenant API key in `Authorization: Bearer <key>` header. Keys are
loaded from env var `TAU_X402_API_KEYS` as a JSON object `{tenant_id: api_key}`
so rotations and per-tenant provisioning are config-file operations. A real
production deployment would back this with a KV store or Postgres; env vars
keep the V1 scaffold runnable on Fly.io free tier without a database.

Billing: every permit/reject is reported to Stripe metered billing via a
dedicated `BillingReporter`. The scaffold ships a NullBillingReporter so the
whole service runs without Stripe credentials; wire `STRIPE_API_KEY` +
`STRIPE_METER_EVENT_NAME` and swap to `StripeBillingReporter` for live meter
ingestion.

Design note: the FastAPI layer is deliberately thin. All policy logic lives
in the daemon; this module's only responsibilities are auth, rate limiting,
usage tracking, and translating HTTP <-> UDS.
"""
from __future__ import annotations

import json
import logging
import math
import os
import threading
import time
from dataclasses import dataclass, field
from decimal import Decimal
from typing import Any, Callable, Dict, Mapping, Optional, Protocol

try:
    from fastapi import Depends, FastAPI, Header, HTTPException, Request
    from fastapi.responses import JSONResponse
except ImportError as exc:
    raise ImportError(
        "saas/ requires FastAPI: `pip install tau-x402-cage[saas]` or "
        "`pip install fastapi uvicorn`"
    ) from exc

from adapter.metrics import get_default as default_metrics
from adapter.payment_intent_matcher import InvalidPaymentIntent, parse as parse_intent
from adapter.verdict_signer import Verdict, sign
from adapter.x402_client import UdsDaemonClient, mediate
from saas.billing import BillingReporter, NullBillingReporter
from saas.models import (
    CheckPaymentRequest,
    CheckPaymentResponse,
    ErrorEnvelope,
    HealthResponse,
    MetricsResponse,
)
from saas.rate_limit import (
    AcquireResult,
    RateLimitError,
    RateLimiter,
    build_rate_limiter,
)

logger = logging.getLogger(__name__)

#: Application version string surfaced in the OpenAPI spec and /v1/health.
#: Kept in sync with ``pyproject.toml`` at release time.
APP_VERSION = "0.18.0"

#: Paths that are exempt from per-tenant rate limiting. The web UI is
#: bearer-token-gated on its own credential and is a human-facing read
#: surface, not a per-tenant metered API. Health is intentionally
#: unauthenticated and must stay open for load balancer probes.
_RATE_LIMIT_EXEMPT_PREFIXES = ("/v1/health", "/ui/", "/metrics", "/docs", "/redoc", "/openapi.json")

#: OpenAPI tag metadata. Tags group routes by audience so procurement
#: reviewers see a structured spec rather than a flat list of endpoints.
OPENAPI_TAGS = [
    {
        "name": "Payment",
        "description": (
            "Payment-intent evaluation. `POST /v1/check` returns the signed "
            "verdict envelope for an x402/MPP payment intent."
        ),
    },
    {
        "name": "Policy",
        "description": (
            "Read-only policy inspection and explanation. Contract target "
            "for v0.10+; daemon already answers these ops over UDS."
        ),
    },
    {
        "name": "Revision",
        "description": (
            "Policy revision chain and named branches. Contract target "
            "for v0.10+; daemon already tracks revisions over UDS."
        ),
    },
    {
        "name": "Proposal",
        "description": (
            "Agent-proposes / human-approves queue. Contract target for "
            "v0.10+; daemon already answers queue ops over UDS."
        ),
    },
    {
        "name": "Ops",
        "description": "Liveness probe and per-tenant usage counters.",
    },
]

#: Long-form description rendered at the top of `/docs` (Swagger UI).
APP_DESCRIPTION = """\
Hosted formal policy cage for x402 / MPP agentic payments.

The SaaS is a thin HTTP front for the cage daemon. All policy logic lives
in the daemon; this service's only responsibilities are auth, rate
limiting, usage tracking, and translating HTTP <-> UDS.

**Auth:** single-tenant API key in `Authorization: Bearer <key>`.

**Verdicts:** every `/v1/check` response carries a MAC-signed envelope
bound to the intent hash. Clients verify the MAC to detect tampering;
the TTL field blocks replay.

**Spec:** OpenAPI 3.1 at `/openapi.json`. Swagger UI at `/docs`. The
schema is regenerated from the Pydantic models in `saas.models`; run
`python scripts/regen-openapi.py` to refresh the committed snapshot at
`docs/api/openapi.json`.
"""


# ── configuration ────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class SaasConfig:
    """Configuration for the SaaS wrapper. Loaded from env via `from_env()`.

    ``jwt`` is optional: when set, the SaaS enables a JWT/OIDC path on
    top of the existing API-key path. The two paths coexist; the API
    key path stays unchanged, and JWT is additive.
    """

    api_keys: Dict[str, str]  # {tenant_id: api_key}
    socket_path: str
    hmac_secret: bytes
    billing: BillingReporter
    jwt: Optional["JwtConfig"] = None  # type: ignore[name-defined]  # forward ref for import ordering
    # v0.12.0: per-tenant rate limiter. None means "no rate limiting" —
    # useful for the OpenAPI fixture and tests that don't exercise the
    # middleware. ``from_env`` always builds one.
    rate_limiter: Optional[RateLimiter] = None

    @classmethod
    def from_env(cls) -> "SaasConfig":
        keys_raw = os.environ.get("TAU_X402_API_KEYS", "{}")
        try:
            api_keys = json.loads(keys_raw)
        except json.JSONDecodeError as exc:
            raise RuntimeError(
                "TAU_X402_API_KEYS must be JSON object {tenant_id: api_key}"
            ) from exc
        if not isinstance(api_keys, dict):
            raise RuntimeError("TAU_X402_API_KEYS must decode to an object")

        secret_hex = os.environ.get("TAU_X402_HMAC_SECRET")
        if not secret_hex:
            raise RuntimeError(
                "TAU_X402_HMAC_SECRET must be set (32+ hex bytes)"
            )
        try:
            secret = bytes.fromhex(secret_hex)
        except ValueError as exc:
            raise RuntimeError("TAU_X402_HMAC_SECRET must be hex-encoded") from exc
        if len(secret) < 16:
            raise RuntimeError("TAU_X402_HMAC_SECRET must be >= 16 bytes")

        socket_path = os.environ.get("TAU_X402_SOCKET", "/tmp/tau-x402-cage.sock")

        # Billing wiring: swap in StripeBillingReporter when env has STRIPE_API_KEY.
        if os.environ.get("STRIPE_API_KEY"):
            from saas.billing import StripeBillingReporter  # late import
            billing: BillingReporter = StripeBillingReporter.from_env()
        else:
            billing = NullBillingReporter()

        # Optional JWT config. Late import so sites that don't install
        # the [auth-jwt] extra still load the SaaS module.
        jwt_config = None
        if os.environ.get("TAU_X402_JWT_JWKS_URL") or os.environ.get("TAU_X402_JWT_ISSUER") or os.environ.get("TAU_X402_JWT_AUDIENCE"):
            try:
                from saas.auth_jwt import JwtConfig as _JwtConfig  # late import
            except ImportError as exc:
                raise RuntimeError(
                    "JWT auth configured but PyJWT missing. "
                    "`pip install tau-x402-cage[auth-jwt]`"
                ) from exc
            jwt_config = _JwtConfig.from_env()

        # Rate limiter: always built. ``build_rate_limiter`` honors the
        # backend env var and fails closed on unreachable Redis.
        rate_limiter = build_rate_limiter()

        return cls(
            api_keys=dict(api_keys),
            socket_path=socket_path,
            hmac_secret=secret,
            billing=billing,
            jwt=jwt_config,
            rate_limiter=rate_limiter,
        )


# ── in-memory usage counters (per-tenant) ────────────────────────────────────


@dataclass
class UsageCounter:
    """Thread-safe per-tenant usage counters."""

    _lock: threading.Lock = field(default_factory=threading.Lock)
    _by_tenant: Dict[str, Dict[str, int]] = field(default_factory=dict)

    def record(self, tenant_id: str, verdict: str) -> None:
        with self._lock:
            bucket = self._by_tenant.setdefault(tenant_id, {"permit": 0, "reject": 0})
            bucket[verdict] = bucket.get(verdict, 0) + 1

    def snapshot(self, tenant_id: str) -> Dict[str, int]:
        with self._lock:
            return dict(self._by_tenant.get(tenant_id, {"permit": 0, "reject": 0}))


# ── app factory ──────────────────────────────────────────────────────────────


def _rate_limit_headers(result: AcquireResult) -> Dict[str, str]:
    """Serialize an :class:`AcquireResult` into response headers.

    Emitted on every metered response (permit and reject alike) so
    dashboards and client libraries can reason about remaining capacity
    without a second call.
    """
    return {
        "X-RateLimit-Limit": str(result.limit),
        "X-RateLimit-Remaining": str(result.remaining),
        "X-RateLimit-Reset-At": str(result.reset_at_unix),
        "X-RateLimit-Quota-Limit": str(result.quota_limit),
        "X-RateLimit-Quota-Remaining": str(result.quota_remaining),
        "X-RateLimit-Quota-Reset-At": str(result.quota_reset_at_unix),
    }


def _resolve_tenant(
    authorization: str, key_to_tenant: Mapping[str, str]
) -> Optional[str]:
    """Resolve the bearer token without raising.

    Returns None when the header is missing or unknown. Rate limit
    middleware leans on this so an unauthenticated request still flows
    through to the auth dependency (which issues the correct 401).
    """
    if not authorization.startswith("Bearer "):
        return None
    token = authorization[len("Bearer "):].strip()
    return key_to_tenant.get(token)


def create_app(config: Optional[SaasConfig] = None) -> FastAPI:
    """Build a FastAPI app with the given config, or load from env if None."""
    cfg = config or SaasConfig.from_env()
    usage = UsageCounter()
    metrics = default_metrics()

    # Flip api_keys around so the auth check is a single dict lookup.
    key_to_tenant: Dict[str, str] = {v: k for k, v in cfg.api_keys.items()}

    # Build the JWT verifier once per app. The verifier holds the JWKS
    # cache so it must outlive individual requests.
    jwt_verifier = None
    if cfg.jwt is not None:
        from saas.auth_jwt import JwtError, JwtVerifier  # late import
        jwt_verifier = JwtVerifier(cfg.jwt)
        # Pre-warm best-effort: a failure here should not kill app
        # boot (the IdP may be briefly unreachable at deploy time).
        # get_key() at request time will surface any hard failure.
        try:
            jwt_verifier.prewarm()
        except Exception:  # noqa: BLE001 — defensive
            logger.exception("JWKS pre-warm failed; will retry on first request")

    app = FastAPI(
        title="tau-x402-cage SaaS",
        version=APP_VERSION,
        description=APP_DESCRIPTION,
        openapi_tags=OPENAPI_TAGS,
        # Swagger UI and ReDoc stay on FastAPI's defaults (/docs, /redoc);
        # OpenAPI spec is served at /openapi.json. Everything is listed in
        # the main README under "API reference".
    )

    def _authed_tenant(authorization: str = Header(default="")) -> str:
        """Dependency: resolve a tenant id from the Authorization header.

        Order of precedence:
            1. If JWT is configured, try JWT verification first.
            2. If JWT verification fails OR JWT is not configured,
               fall back to the static API-key map.
            3. Neither match -> 401.

        Both paths return the same tenant id so usage counters, rate
        limits, and billing don't care which auth path the caller
        used. A tenant may be authenticated via an API key OR a JWT,
        whichever is present.
        """
        if not authorization.startswith("Bearer "):
            raise HTTPException(status_code=401, detail="missing Bearer token")
        token = authorization[len("Bearer "):].strip()

        # 1. JWT path (if configured).
        if jwt_verifier is not None:
            from saas.auth_jwt import JwtError  # late import
            try:
                claims = jwt_verifier.verify(token)
                return jwt_verifier.tenant_from_claims(claims)
            except JwtError:
                # Fall through to API-key path: token might be a
                # static key rather than a JWT (e.g. a CI caller
                # that hasn't been migrated to SSO yet).
                pass

        # 2. API-key fallback.
        tenant = key_to_tenant.get(token)
        if tenant is None:
            raise HTTPException(status_code=401, detail="invalid credentials")
        return tenant

    # ── rate-limit middleware ────────────────────────────────────────────
    #
    # Only meter metered routes (see ``_RATE_LIMIT_EXEMPT_PREFIXES``). Runs
    # AFTER auth in the mental model (we only meter known tenants), but in
    # ASGI terms middleware runs BEFORE the route dependency; we replicate
    # the bearer lookup here and skip unknown callers so the real auth
    # dependency emits the canonical 401.
    if cfg.rate_limiter is not None:
        rate_limiter = cfg.rate_limiter

        @app.middleware("http")
        async def rate_limit_middleware(request: Request, call_next):
            path = request.url.path
            if any(path.startswith(p) for p in _RATE_LIMIT_EXEMPT_PREFIXES):
                return await call_next(request)

            authorization = request.headers.get("authorization", "")
            tenant = _resolve_tenant(authorization, key_to_tenant)
            if tenant is None:
                # Let the auth dependency raise the real 401 downstream.
                return await call_next(request)

            try:
                result = rate_limiter.try_acquire(tenant)
            except RateLimitError:
                logger.exception("rate limiter unreachable; rejecting request")
                return JSONResponse(
                    status_code=503,
                    content={"detail": "rate limiter unavailable"},
                )

            if not result.allowed:
                metrics.record_rate_limit_rejected(
                    tenant=tenant, reason=result.reason or "qps"
                )
                headers = _rate_limit_headers(result)
                headers["Retry-After"] = str(max(1, int(math.ceil(result.retry_after_s))))
                detail = (
                    "monthly quota exhausted"
                    if result.reason == "quota"
                    else "rate limit exceeded"
                )
                if result.reason == "quota":
                    headers["X-RateLimit-Quota-Exhausted"] = "monthly"
                return JSONResponse(
                    status_code=429,
                    content={"detail": detail},
                    headers=headers,
                )

            response = await call_next(request)
            for k, v in _rate_limit_headers(result).items():
                response.headers[k] = v
            return response

    @app.get(
        "/v1/health",
        response_model=HealthResponse,
        tags=["Ops"],
        summary="Liveness probe",
        description=(
            "Unauthenticated liveness check. Returns `{status: 'ok', "
            "version: ...}` when the SaaS process is serving."
        ),
    )
    def health() -> HealthResponse:
        return HealthResponse(status="ok", version=APP_VERSION)

    @app.get(
        "/v1/usage",
        response_model=MetricsResponse,
        tags=["Ops"],
        summary="Tenant usage counters",
        description=(
            "Returns the cumulative permit/reject counts for the "
            "authenticated tenant since the SaaS process started."
        ),
        responses={401: {"model": ErrorEnvelope, "description": "Missing or invalid API key"}},
    )
    def get_usage(tenant: str = Depends(_authed_tenant)) -> MetricsResponse:
        snap = usage.snapshot(tenant)
        return MetricsResponse(
            tenant=tenant,
            counters={"permit": snap.get("permit", 0), "reject": snap.get("reject", 0)},
        )

    # v0.7.0: read-only web UI mounted on request, gated by env flag so the
    # pure-API surface stays unchanged for existing SaaS callers.
    # The web UI routes are marked ``include_in_schema=False`` inside
    # ``build_router`` so they don't pollute the OpenAPI spec.
    if os.environ.get("TAU_CAGE_WEB_UI_ENABLED") == "1":
        from saas.web_ui.routes import build_router, mount_static_on
        ui_router = build_router(socket_path=cfg.socket_path)
        app.include_router(ui_router, prefix="/ui", include_in_schema=False)
        mount_static_on(app)

    # v0.9.0: Prometheus /metrics. Gated by the presence of a dedicated
    # scrape token so a misconfigured SaaS deployment cannot leak counter
    # data to unauthenticated clients.
    if os.environ.get("TAU_X402_METRICS_TOKEN"):
        from saas.metrics_route import build_metrics_router
        app.include_router(build_metrics_router())

    @app.post(
        "/v1/check",
        response_model=CheckPaymentResponse,
        tags=["Payment"],
        summary="Evaluate a payment intent",
        description=(
            "Proxy an x402/MPP payment intent to the cage daemon. The "
            "response body is the signed verdict envelope; the HTTP "
            "status encodes the coarse verdict (200 permit, 403 reject)."
        ),
        responses={
            401: {"model": ErrorEnvelope, "description": "Missing or invalid API key"},
            403: {
                "model": CheckPaymentResponse,
                "description": "Reject verdict. Body is the signed envelope.",
            },
            500: {"model": ErrorEnvelope, "description": "Daemon unreachable or internal error"},
        },
    )
    async def check(
        payload: CheckPaymentRequest,
        request: Request,
        tenant: str = Depends(_authed_tenant),
    ) -> JSONResponse:
        """Proxy a payment intent to the cage daemon and return the signed envelope.

        Accepts JSON body in the x402 request shape (see
        `adapter.payment_intent_matcher.parse_x402` for the schema). Returns the
        signed verdict envelope as the response body; HTTP status reflects the
        verdict (200 permit, 403 reject, 500 on unrecoverable errors).
        """
        # Re-read the raw body bytes so `mediate()` sees the exact wire
        # payload the client sent (preserves unknown rail-specific metadata
        # and keeps the signature-relevant canonicalization in one place).
        # `payload` exists purely to drive OpenAPI schema + 422 validation.
        del payload
        raw_body = await request.body()
        # Headers come through as a lowercase mapping; convert for the parser.
        headers = {k: v for k, v in request.headers.items()}

        client = UdsDaemonClient(socket_path=cfg.socket_path)
        status, response_headers, response_body = mediate(
            headers=headers,
            body=raw_body,
            secret=cfg.hmac_secret,
            daemon=client,
        )
        verdict = response_headers.get("X-Policy-Verdict", "unknown")
        usage.record(tenant, verdict)
        try:
            cfg.billing.record_check(tenant_id=tenant, verdict=verdict)
        except Exception:  # billing must never fail the request path
            logger.exception("billing reporter failed; request continuing")
        return JSONResponse(
            status_code=status,
            content=json.loads(response_body) if response_body else {},
            headers=response_headers,
        )

    return app
