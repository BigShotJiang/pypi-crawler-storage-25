"""FastAPI router for the read-only web UI.

Contract:
  * Every route is ``GET``. POST/PUT/DELETE return 405 (FastAPI default
    because we never register them).
  * Auth is a shared dependency: ``Authorization: Bearer $TAU_CAGE_WEB_UI_TOKEN``.
    If the env var is unset at router-build time the dependency raises 403
    on every hit — fail closed.
  * All daemon reads go through a ``DaemonReader`` object the caller injects.
    Tests stub this out; production uses ``UdsDaemonClient.request``.

The router is built by ``build_router()`` rather than being a module-level
singleton so the caller can pass in the socket path + token. This mirrors
how ``saas.app.create_app`` works.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Dict, Mapping, Optional, Protocol

try:
    from fastapi import APIRouter, Depends, Header, HTTPException, Query, Request
    from fastapi.responses import HTMLResponse
    from fastapi.staticfiles import StaticFiles
    from fastapi.templating import Jinja2Templates
except ImportError as exc:  # pragma: no cover - optional dep
    raise ImportError(
        "saas/web_ui requires FastAPI + Jinja2: "
        "`pip install tau-x402-cage[saas]`"
    ) from exc

from adapter.x402_client import UdsDaemonClient


# ── daemon-reader abstraction ────────────────────────────────────────────────


class DaemonReader(Protocol):
    """Anything that can answer a read-only daemon op.

    We model reads as ``request(dict) -> dict`` so tests can stub the
    daemon without a real UDS round-trip. Production uses
    ``UdsDaemonClient.request``.
    """

    def request(self, payload: Mapping[str, object]) -> Dict[str, Any]: ...


@dataclass(frozen=True)
class DaemonReaderFromSocket:
    """Adapter turning a socket path into a DaemonReader."""

    socket_path: str
    timeout_sec: float = 2.0

    def request(self, payload: Mapping[str, object]) -> Dict[str, Any]:
        client = UdsDaemonClient(
            socket_path=self.socket_path, timeout_sec=self.timeout_sec,
        )
        return client.request(payload)


# ── template + static paths ──────────────────────────────────────────────────

_WEB_UI_DIR = Path(__file__).resolve().parent
_TEMPLATES_DIR = _WEB_UI_DIR / "templates"
_STATIC_DIR = _WEB_UI_DIR / "static"


def _build_templates() -> Jinja2Templates:
    return Jinja2Templates(directory=str(_TEMPLATES_DIR))


# ── router factory ───────────────────────────────────────────────────────────


def build_router(
    *,
    reader: Optional[DaemonReader] = None,
    socket_path: Optional[str] = None,
    token: Optional[str] = None,
) -> APIRouter:
    """Build the ``/ui`` router.

    Args:
        reader: optional pre-built DaemonReader. When None, one is constructed
            from ``socket_path`` (or falls back to the default UDS path).
        socket_path: UDS path to the cage daemon. Unused if ``reader`` is set.
        token: expected bearer token. When None, read from
            ``TAU_CAGE_WEB_UI_TOKEN`` at call time. When the resolved token
            is still None/empty, the router refuses every request with 403
            so misconfiguration fails closed.
    """
    resolved_token = token if token is not None else os.environ.get(
        "TAU_CAGE_WEB_UI_TOKEN", ""
    )
    resolved_reader: DaemonReader
    if reader is not None:
        resolved_reader = reader
    else:
        resolved_reader = DaemonReaderFromSocket(
            socket_path=socket_path or "/tmp/tau-x402-cage.sock",
        )

    templates = _build_templates()
    router = APIRouter()

    def _check_auth(authorization: str = Header(default="")) -> None:
        # Fail closed: no configured token => every request rejected.
        if not resolved_token:
            raise HTTPException(
                status_code=403,
                detail="web UI not provisioned (TAU_CAGE_WEB_UI_TOKEN unset)",
            )
        if not authorization.startswith("Bearer "):
            raise HTTPException(status_code=403, detail="missing Bearer token")
        supplied = authorization[len("Bearer "):].strip()
        if supplied != resolved_token:
            raise HTTPException(status_code=403, detail="invalid token")

    def _safe_read(op: str, extra: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        payload: Dict[str, Any] = {"op": op}
        if extra:
            payload.update(extra)
        try:
            return resolved_reader.request(payload)
        except (FileNotFoundError, ConnectionRefusedError) as exc:
            return {
                "verdict": "error",
                "category": "daemon_unreachable",
                "reason": f"{type(exc).__name__}",
            }
        except Exception as exc:  # pragma: no cover - defensive
            return {
                "verdict": "error",
                "category": "daemon_error",
                "reason": str(exc),
            }

    # ── routes ───────────────────────────────────────────────────────────

    @router.get("/", response_class=HTMLResponse)
    def landing(request: Request, _: None = Depends(_check_auth)) -> HTMLResponse:
        health = _safe_read("health")
        policy = _safe_read("inspect_policy")
        return templates.TemplateResponse(
            request,
            "index.html",
            {"health": health, "policy": policy},
        )

    @router.get("/policy", response_class=HTMLResponse)
    def policy(request: Request, _: None = Depends(_check_auth)) -> HTMLResponse:
        data = _safe_read("inspect_policy")
        active = _safe_read("active_revision")
        return templates.TemplateResponse(
            request,
            "policy.html",
            {"policy": data, "active": active},
        )

    @router.get("/revisions", response_class=HTMLResponse)
    def revisions(
        request: Request,
        limit: int = Query(default=50, ge=1, le=500),
        offset: int = Query(default=0, ge=0),
        _: None = Depends(_check_auth),
    ) -> HTMLResponse:
        data = _safe_read("revision_log")
        entries = data.get("revisions") or []
        total = data.get("length", len(entries))
        # Newest-first slice — revision_log currently has no server-side
        # pagination, so we slice here. Acceptable for V1 audit use where
        # chains are measured in dozens, not millions.
        window = list(reversed(entries))[offset : offset + limit]
        return templates.TemplateResponse(
            request,
            "revisions.html",
            {
                "entries": window,
                "total": total,
                "limit": limit,
                "offset": offset,
                "has_prev": offset > 0,
                "has_next": (offset + limit) < total,
            },
        )

    @router.get("/revisions/diff", response_class=HTMLResponse)
    def revisions_diff(
        request: Request,
        from_: str = Query(alias="from"),
        to: str = Query(...),
        _: None = Depends(_check_auth),
    ) -> HTMLResponse:
        """Render a pretty-printed delta between two revisions.

        Calls the v0.6.0 ``diff_revisions`` op and pipes the result through
        the v0.11.0 ``adapter.diff_renderer`` HTML renderer. Returns 404
        when either revision is missing so the front-door API is
        conventional even though the route itself is a soft wrapper.
        """
        from adapter.diff_renderer import render_revision_diff_html

        data = _safe_read("diff_revisions", {"a": from_, "b": to})
        if data.get("verdict") != "ok":
            category = data.get("category", "error")
            reason = data.get("reason", "diff failed")
            if category == "unknown_revision":
                raise HTTPException(status_code=404, detail=reason)
            # Other daemon-level errors render as a 200 with a banner so
            # operators see the failure mode. Shape matches the rest of
            # the web UI's "soft" error pages.
            return templates.TemplateResponse(
                request,
                "revision_diff.html",
                {
                    "from_rev": from_, "to_rev": to, "data": data,
                    "diff_html": "", "error": reason,
                },
            )
        diff_html = render_revision_diff_html(data)
        return templates.TemplateResponse(
            request,
            "revision_diff.html",
            {
                "from_rev": from_,
                "to_rev": to,
                "data": data,
                "diff_html": diff_html,
                "error": None,
            },
        )

    @router.get("/revisions/{revision_id}", response_class=HTMLResponse)
    def revision_detail(
        request: Request,
        revision_id: str,
        _: None = Depends(_check_auth),
    ) -> HTMLResponse:
        data = _safe_read("revision_log")
        entries = data.get("revisions") or []
        match = next(
            (r for r in entries if r.get("config_hash") == revision_id
             or r.get("revision_id") == revision_id),
            None,
        )
        return templates.TemplateResponse(
            request,
            "revision_detail.html",
            {
                "revision_id": revision_id,
                "revision": match,
            },
        )

    @router.get("/verdicts", response_class=HTMLResponse)
    def verdicts(
        request: Request,
        limit: int = Query(default=50, ge=1, le=500),
        offset: int = Query(default=0, ge=0),
        _: None = Depends(_check_auth),
    ) -> HTMLResponse:
        data = _safe_read(
            "recent_verdicts", {"limit": limit, "offset": offset},
        )
        entries = data.get("entries") or []
        total = data.get("total", 0)
        return templates.TemplateResponse(
            request,
            "verdicts.html",
            {
                "entries": entries,
                "total": total,
                "limit": limit,
                "offset": offset,
                "has_prev": offset > 0,
                "has_next": (offset + limit) < total,
            },
        )

    @router.get("/health", response_class=HTMLResponse)
    def health(request: Request, _: None = Depends(_check_auth)) -> HTMLResponse:
        data = _safe_read("health")
        return templates.TemplateResponse(
            request, "health.html", {"health": data},
        )

    @router.get("/guarantees", response_class=HTMLResponse)
    def guarantees(
        request: Request,
        _: None = Depends(_check_auth),
    ) -> HTMLResponse:
        """Explicit guarantees surface — v0.14.0.

        Renders the catalog the cage currently delivers in three columns:
        what you get (active), what's off (inactive), and what you lose if
        the cage is disabled (plain-English per guarantee). Closes the
        "make value visible" loop: an auditor reading this page answers
        both "what does the cage claim?" and "what's the tradeoff of
        turning it off?" without reading code.
        """
        data = _safe_read("guarantees")
        entries = data.get("guarantees") or []
        active = [g for g in entries if g.get("active")]
        inactive = [g for g in entries if not g.get("active")]
        return templates.TemplateResponse(
            request,
            "guarantees.html",
            {
                "data": data,
                "entries": entries,
                "active": active,
                "inactive": inactive,
            },
        )

    @router.get("/safety", response_class=HTMLResponse)
    def safety(
        request: Request,
        window: int = Query(default=86400, ge=0),
        top_n: int = Query(default=5, ge=1, le=50),
        _: None = Depends(_check_auth),
    ) -> HTMLResponse:
        """Safety comparison dashboard — v0.13.0, extended v0.15.0.

        Renders the ``risk_aggregate`` op over the configured window so
        operators see "what would have spent without the cage" rolled up
        by provider and rule. Default window: 24 hours. Read-only; the
        template auto-refreshes every 30 seconds via a tiny inline script.

        v0.15.0 also fetches ``active_constraints`` + ``mutation_failures``
        to surface the risk-dashboard primitives on the same page. Each
        daemon read is a single-shot; ``_safe_read`` returns an error
        envelope on failure so the template renders a per-section banner
        instead of 500-ing the whole page.
        """
        data = _safe_read(
            "risk_aggregate", {"window_seconds": window, "top_n": top_n},
        )
        constraints = _safe_read("active_constraints")
        mutation_failures = _safe_read(
            "mutation_failures", {"limit": 20},
        )
        # v0.17.0: runtime guard state. Gated on the daemon exposing the
        # `runtime_state` op; the template renders a graceful unavailable
        # notice when the daemon is older than v0.17.0.
        runtime_state = _safe_read("runtime_state")
        return templates.TemplateResponse(
            request,
            "safety.html",
            {
                "aggregate": data,
                "window": window,
                "top_n": top_n,
                "constraints": constraints,
                "mutation_failures": mutation_failures,
                "runtime_state": runtime_state,
            },
        )

    # Static assets are mounted lazily by the host app via
    # `mount_static_on(app)`; we don't mount them on the APIRouter because
    # FastAPI only supports StaticFiles on the top-level app.
    return router


def mount_static_on(app, prefix: str = "/ui/static") -> None:
    """Mount the web-UI static directory on the host FastAPI app.

    Kept separate from ``build_router`` because APIRouter doesn't support
    ``mount()``. The host app calls this once after including the router.
    """
    app.mount(
        prefix,
        StaticFiles(directory=str(_STATIC_DIR)),
        name="tau_cage_web_ui_static",
    )
