"""Read-only web UI for policy inspection (v0.7.0).

Mounts under ``/ui`` on the hosted SaaS app when
``TAU_CAGE_WEB_UI_ENABLED=1``. The surface is intentionally tiny: five HTML
pages rendered server-side from the daemon's existing read-only ops
(``inspect_policy``, ``revision_log``, ``active_revision``,
``recent_verdicts``, ``health``). No POSTs. No state. No JS framework.

Design choices:
  * Jinja2 templates + inline CSS only. A CISO in an incident room should
    be able to read the source in one sitting.
  * Auth defaults closed. If the hosting app has no bearer middleware and
    the operator hasn't set ``TAU_CAGE_WEB_UI_TOKEN``, every UI request is
    rejected. Failing open here would be catastrophic.
  * All templates render the same ``_layout`` macro so the Tau Net brand
    (monospace, cream background, no gradients, question-led H1s) stays
    consistent.
"""

from saas.web_ui.routes import build_router

__all__ = ["build_router"]
