// Tiny progressive-enhancement helper for the tau-x402-cage web UI.
//
// Deliberately small: the server renders every page, this just wires:
//   * Keyboard shortcuts for pagination (j/k)
//   * Optional auto-refresh on /ui/verdicts and /ui/health
//
// No dependencies, no bundler.
(function () {
  "use strict";

  function byQuery(sel) {
    return document.querySelector(sel);
  }

  function navTo(url) {
    window.location.href = url;
  }

  function pagerClick(selector) {
    var el = byQuery(selector);
    if (el && el.tagName === "A") {
      el.click();
    }
  }

  // j/k = next/prev page on list views.
  document.addEventListener("keydown", function (e) {
    if (e.target && (e.target.tagName === "INPUT" ||
                     e.target.tagName === "TEXTAREA")) {
      return;
    }
    if (e.key === "j") pagerClick("nav.pager a:last-of-type");
    if (e.key === "k") pagerClick("nav.pager a:first-of-type");
  });

  // Opt-in refresh via ?refresh=10 on verdicts / health pages.
  var url = new URL(window.location.href);
  var refresh = parseInt(url.searchParams.get("refresh") || "0", 10);
  if (refresh > 0 && refresh <= 3600) {
    window.setTimeout(function () {
      window.location.reload();
    }, refresh * 1000);
  }
})();
