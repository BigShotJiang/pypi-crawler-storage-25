"""JWT / OIDC verifier for the hosted SaaS.

Enterprise prospects need to integrate with their existing IdP (Auth0,
Keycloak, Okta, Cognito, Google Workspace, Azure AD) rather than manage
bearer tokens out-of-band. A generic JWKS verifier covers all of them
with one implementation.

Design
------

- **Algorithm allowlist:** RS256 + ES256. Reject HS* (shared-secret
  family, wrong trust model for IdP integration) and `none` (the classic
  JWT pitfall). Enforced by passing an explicit `algorithms=` list to
  PyJWT on every decode; never trust the `alg` in the token header.
- **JWKS caching:** keys are cached by `kid` with a 1h TTL. A `kid`
  cache miss triggers a refresh; if still unknown after refresh, we
  raise `JwtKeyFetchError`. Refresh is synchronous per miss (first
  request pays the fetch cost) but the cache is pre-warmed at startup
  by ``prewarm()`` so the hot path stays fast in steady state.
- **Fail semantics on JWKS fetch:**
    * first fetch fails -> fail-closed (raise; token cannot be verified
      if we have no keys at all).
    * refresh fails while a usable cache exists -> fail-open (keep
      serving with the cached keys so a transient IdP outage does not
      cascade into a SaaS outage). Last-good cache is preserved.
- **HTTPS-only JWKS:** we reject `http://` URLs at config time. An
  attacker who can MITM the JWKS fetch can forge any token they want.
- **Claim enforcement:** `iss` exact match, `aud` exact-or-inclusion,
  `exp` / `iat` / `nbf` with ``clock_skew_s`` tolerance. PyJWT handles
  the time-based claims when we pass `require=["exp"]` and a `leeway`
  keyword.
- **Thread safety:** the JWKS cache is protected by a single
  ``threading.Lock``. JWKS is small (few keys) so a coarse lock is
  fine; swap for a reader-writer lock if scale forces it.

Scope
-----

Pure SaaS-layer concern. The daemon's UDS protocol is unchanged — JWT
terminates at the HTTP boundary and ``_authed_tenant`` in
``saas/app.py`` resolves the JWT subject into the same tenant id the
bearer-token path uses for usage counters, rate limits, and billing.
"""
from __future__ import annotations

import json
import logging
import threading
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence

try:
    import jwt  # PyJWT
    from jwt import PyJWKClient  # noqa: F401 — reserved for future use
except ImportError as exc:  # pragma: no cover — guarded by extra
    raise ImportError(
        "saas/auth_jwt.py requires PyJWT: "
        "`pip install tau-x402-cage[auth-jwt]`"
    ) from exc


logger = logging.getLogger(__name__)


# ── allowlist ────────────────────────────────────────────────────────────────

#: Asymmetric signing algorithms we accept. Shared-secret (HS*) algorithms
#: are deliberately excluded: they presume the verifier holds the signing
#: key, which defeats the IdP-federation model. ``none`` is excluded for
#: obvious reasons.
ALLOWED_ALGORITHMS: tuple[str, ...] = ("RS256", "ES256")


# ── errors ───────────────────────────────────────────────────────────────────


class JwtError(Exception):
    """Base class for JWT verification failures.

    Callers can catch this to treat every JWT failure uniformly (e.g.
    translate to 401). Specific subclasses let callers distinguish
    recoverable (expired; client should refresh) from non-recoverable
    (tampered; reject) cases when logging or emitting metrics.
    """


class JwtInvalidError(JwtError):
    """Token signature fails verification or the token is malformed."""


class JwtExpiredError(JwtError):
    """``exp`` has passed or ``nbf`` is in the future (respects skew)."""


class JwtKeyFetchError(JwtError):
    """Unable to obtain signing keys: either the JWKS endpoint is
    unreachable on first fetch, or the token's ``kid`` is unknown even
    after a cache refresh."""


class JwtClaimError(JwtError):
    """A non-time claim (``iss``, ``aud``, custom) failed its check."""


# ── configuration ────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class JwtConfig:
    """Configuration for the SaaS JWT verifier.

    Loaded from env via :meth:`from_env`. When ``jwks_url`` is empty we
    treat JWT auth as disabled; the SaaS falls back to bearer tokens.

    All fields are exact-match when enforcing. ``audience`` may be a
    single string or a list of strings; a token is accepted if its
    ``aud`` claim either equals (string case) or contains any element
    of (list case) the configured audience.
    """

    jwks_url: str
    issuer: str
    audience: str
    tenant_claim: str = "sub"
    clock_skew_s: int = 10
    jwks_ttl_s: int = 3600

    @classmethod
    def from_env(cls, env: Optional[Mapping[str, str]] = None) -> Optional["JwtConfig"]:
        """Build a config from env, or return ``None`` when JWT is unset.

        We require ``TAU_X402_JWT_JWKS_URL`` AND ``TAU_X402_JWT_ISSUER``
        AND ``TAU_X402_JWT_AUDIENCE`` to enable JWT. Partial configs
        raise — silent fallback to bearer-only would surprise an
        operator who thought they'd wired SSO.
        """
        import os

        e = env if env is not None else os.environ
        jwks_url = e.get("TAU_X402_JWT_JWKS_URL", "").strip()
        issuer = e.get("TAU_X402_JWT_ISSUER", "").strip()
        audience = e.get("TAU_X402_JWT_AUDIENCE", "").strip()
        tenant_claim = e.get("TAU_X402_JWT_TENANT_CLAIM", "sub").strip() or "sub"

        # All-unset -> JWT disabled.
        if not jwks_url and not issuer and not audience:
            return None
        # Partial-config -> misconfiguration.
        missing = [
            name for name, val in (
                ("TAU_X402_JWT_JWKS_URL", jwks_url),
                ("TAU_X402_JWT_ISSUER", issuer),
                ("TAU_X402_JWT_AUDIENCE", audience),
            ) if not val
        ]
        if missing:
            raise RuntimeError(
                "JWT auth partially configured; missing env vars: "
                f"{missing}. Either set all three or unset all three."
            )
        if not jwks_url.lower().startswith("https://"):
            raise RuntimeError(
                f"TAU_X402_JWT_JWKS_URL must be https://; got {jwks_url!r}. "
                "An attacker who can MITM the JWKS fetch can forge any token."
            )
        return cls(
            jwks_url=jwks_url,
            issuer=issuer,
            audience=audience,
            tenant_claim=tenant_claim,
        )


# ── JWKS cache ───────────────────────────────────────────────────────────────


@dataclass
class _JwksEntry:
    """A single cached signing key."""

    kid: str
    key: Any  # PyJWT algorithm-native key object
    alg: str
    fetched_at: float


class JwksCache:
    """Thread-safe JWKS cache keyed by ``kid``.

    Strategy
    --------
    - On first use, fetch the JWKS document, populate the cache.
    - On ``kid`` lookup:
        * hit within TTL -> return cached key.
        * miss (unknown kid) -> attempt refresh. If after refresh the
          ``kid`` is still unknown, raise ``JwtKeyFetchError``.
        * hit but stale (older than TTL) -> refresh opportunistically;
          keep serving from cache if the refresh fails (fail-open).
    """

    def __init__(self, jwks_url: str, ttl_s: int = 3600) -> None:
        self._jwks_url = jwks_url
        self._ttl_s = ttl_s
        self._lock = threading.Lock()
        self._entries: Dict[str, _JwksEntry] = {}
        self._last_fetch_at: float = 0.0

    def prewarm(self) -> None:
        """Fetch JWKS eagerly so the first token verification does not
        pay the HTTP cost. Safe to call at startup; caller decides
        whether to surface failures or swallow them."""
        self._refresh(require_success=True)

    def get_key(self, kid: str) -> _JwksEntry:
        """Return the signing key for ``kid`` or raise
        :class:`JwtKeyFetchError`.

        Does a cache refresh on miss. Never blocks the hot path on a
        refresh for a hit: if the cache entry is stale, we return the
        cached key and schedule no background refresh (call
        :meth:`prewarm` from a periodic task if aggressive freshness
        is required).
        """
        with self._lock:
            entry = self._entries.get(kid)
            if entry is not None:
                return entry
        # Miss: refresh and retry. Refresh happens outside the lock so
        # a concurrent decode for a known kid does not block on HTTP.
        self._refresh(require_success=False)
        with self._lock:
            entry = self._entries.get(kid)
            if entry is None:
                raise JwtKeyFetchError(
                    f"unknown kid={kid!r} after JWKS refresh from {self._jwks_url}"
                )
            return entry

    def _refresh(self, *, require_success: bool) -> None:
        """Re-fetch the JWKS document and update the cache.

        When ``require_success=True`` and the HTTP fetch fails, we
        raise :class:`JwtKeyFetchError` — this path is used on first
        fetch where no cache exists to fall back to.

        When ``require_success=False`` we fail-open: log, keep the
        existing cache, and let the caller decide via a subsequent
        ``get_key`` whether the requested ``kid`` is actually
        recoverable.
        """
        try:
            document = self._fetch_jwks()
        except (urllib.error.URLError, OSError, ValueError) as exc:
            if require_success and not self._entries:
                raise JwtKeyFetchError(
                    f"JWKS fetch failed ({self._jwks_url}): {exc}"
                ) from exc
            # Fail-open: preserve last-good cache, just log.
            logger.warning(
                "JWKS refresh failed; serving from cached keys (%d known). url=%s err=%s",
                len(self._entries), self._jwks_url, exc,
            )
            return

        now = time.time()
        new_entries: Dict[str, _JwksEntry] = {}
        for raw_key in document.get("keys", []):
            kid = raw_key.get("kid")
            alg = raw_key.get("alg")
            if not kid or alg not in ALLOWED_ALGORITHMS:
                # Skip keys we wouldn't accept anyway. Logging would
                # be noisy here — IdPs publish keys for every
                # algorithm they support.
                continue
            try:
                algo = jwt.algorithms.get_default_algorithms()[alg]
                key = algo.from_jwk(json.dumps(raw_key))
            except Exception as exc:  # noqa: BLE001 — defensive
                logger.warning(
                    "skipping malformed JWK kid=%s alg=%s err=%s", kid, alg, exc,
                )
                continue
            new_entries[kid] = _JwksEntry(kid=kid, key=key, alg=alg, fetched_at=now)

        if not new_entries and require_success:
            raise JwtKeyFetchError(
                f"JWKS at {self._jwks_url} returned no usable keys "
                f"(allowlist={ALLOWED_ALGORITHMS})"
            )

        with self._lock:
            # Replace atomically. If the fetch returned an empty set
            # (unlikely but possible during a rotation gap) we keep
            # the previous cache so verification keeps working.
            if new_entries:
                self._entries = new_entries
                self._last_fetch_at = now

    def _fetch_jwks(self) -> Dict[str, Any]:
        """HTTP GET the JWKS document. Overridable in tests."""
        req = urllib.request.Request(self._jwks_url, method="GET")
        with urllib.request.urlopen(req, timeout=10) as resp:  # noqa: S310 — https enforced at config time
            raw = resp.read()
        return json.loads(raw)


# ── verifier ─────────────────────────────────────────────────────────────────


class JwtVerifier:
    """Verify JWT bearer tokens against a JWKS-backed IdP.

    Construct once at app startup, call :meth:`verify` per request.

    Example
    -------

    >>> cfg = JwtConfig(
    ...     jwks_url="https://example.auth0.com/.well-known/jwks.json",
    ...     issuer="https://example.auth0.com/",
    ...     audience="https://cage.example.com",
    ... )
    >>> v = JwtVerifier(cfg)
    >>> claims = v.verify(token)  # doctest: +SKIP
    >>> tenant = v.tenant_from_claims(claims, cfg.tenant_claim)  # doctest: +SKIP
    """

    def __init__(
        self,
        config: JwtConfig,
        *,
        jwks_cache: Optional[JwksCache] = None,
    ) -> None:
        self._config = config
        self._jwks = jwks_cache or JwksCache(config.jwks_url, ttl_s=config.jwks_ttl_s)

    @property
    def config(self) -> JwtConfig:
        return self._config

    @property
    def jwks(self) -> JwksCache:
        return self._jwks

    def prewarm(self) -> None:
        """Eagerly populate the JWKS cache. Safe to call multiple times."""
        self._jwks.prewarm()

    def verify(self, token: str) -> Dict[str, Any]:
        """Decode + verify a JWT and return its claims.

        Raises one of the :class:`JwtError` subclasses on any failure.
        Never returns partial / unverified claims.
        """
        if not token or not isinstance(token, str):
            raise JwtInvalidError("empty or non-string token")

        # Peek at the header to resolve the signing kid. We do NOT
        # trust any claim from this step — only the header metadata.
        try:
            header = jwt.get_unverified_header(token)
        except jwt.PyJWTError as exc:
            raise JwtInvalidError(f"malformed token header: {exc}") from exc

        alg = header.get("alg")
        if alg not in ALLOWED_ALGORITHMS:
            raise JwtInvalidError(
                f"algorithm {alg!r} not in allowlist {ALLOWED_ALGORITHMS}"
            )

        kid = header.get("kid")
        if not kid:
            raise JwtInvalidError("token header missing 'kid'")

        try:
            jwks_entry = self._jwks.get_key(kid)
        except JwtKeyFetchError:
            raise
        except Exception as exc:  # noqa: BLE001 — surface as key-fetch failure
            raise JwtKeyFetchError(str(exc)) from exc

        # Defence-in-depth: even if the IdP re-used a kid for a
        # different alg, refuse to decode with anything outside the
        # allowlist.
        if jwks_entry.alg not in ALLOWED_ALGORITHMS:
            raise JwtInvalidError(
                f"JWKS entry alg {jwks_entry.alg!r} not in allowlist"
            )

        try:
            claims = jwt.decode(
                token,
                key=jwks_entry.key,
                algorithms=[jwks_entry.alg],
                audience=self._config.audience,
                issuer=self._config.issuer,
                leeway=self._config.clock_skew_s,
                options={
                    "verify_signature": True,
                    "verify_exp": True,
                    "verify_iat": True,
                    "verify_nbf": True,
                    "verify_iss": True,
                    "verify_aud": True,
                    "require": ["exp"],
                },
            )
        except jwt.ExpiredSignatureError as exc:
            raise JwtExpiredError(f"token exp: {exc}") from exc
        except jwt.ImmatureSignatureError as exc:
            # nbf in the future
            raise JwtExpiredError(f"token not yet valid: {exc}") from exc
        except jwt.InvalidIssuerError as exc:
            raise JwtClaimError(f"iss mismatch: {exc}") from exc
        except jwt.InvalidAudienceError as exc:
            raise JwtClaimError(f"aud mismatch: {exc}") from exc
        except jwt.MissingRequiredClaimError as exc:
            raise JwtClaimError(f"missing required claim: {exc}") from exc
        except jwt.InvalidSignatureError as exc:
            raise JwtInvalidError(f"signature invalid: {exc}") from exc
        except jwt.DecodeError as exc:
            raise JwtInvalidError(f"decode failed: {exc}") from exc
        except jwt.InvalidTokenError as exc:
            # Catch-all for any remaining PyJWT validation error.
            raise JwtInvalidError(f"invalid token: {exc}") from exc

        return claims

    # ── tenant mapping ────────────────────────────────────────────────

    def tenant_from_claims(
        self,
        claims: Mapping[str, Any],
        mapping_rule: Optional[str] = None,
    ) -> str:
        """Extract the tenant id from verified claims.

        ``mapping_rule`` is the claim name to use (default: the
        ``tenant_claim`` from config). A dotted rule like
        ``"https://cage.example/tenant_id"`` is also supported for
        custom-namespaced claims (common in Auth0 rules).

        Raises :class:`JwtClaimError` when the claim is missing or
        not a non-empty string.
        """
        rule = mapping_rule or self._config.tenant_claim
        if rule not in claims:
            raise JwtClaimError(
                f"tenant claim {rule!r} missing from token "
                f"(available: {sorted(claims.keys())})"
            )
        value = claims[rule]
        if not isinstance(value, str) or not value:
            raise JwtClaimError(
                f"tenant claim {rule!r} must be a non-empty string, got {type(value).__name__}"
            )
        return value


__all__ = [
    "ALLOWED_ALGORITHMS",
    "JwksCache",
    "JwtClaimError",
    "JwtConfig",
    "JwtError",
    "JwtExpiredError",
    "JwtInvalidError",
    "JwtKeyFetchError",
    "JwtVerifier",
]
