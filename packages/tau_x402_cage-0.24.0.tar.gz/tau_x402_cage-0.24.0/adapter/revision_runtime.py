"""Cross-revision runtime awareness for decision envelopes (v0.21.0).

At the runtime decision boundary — not at declare/mutation time — the
caller benefits from seeing:

  * ``previous_policy_revision`` / ``current_policy_revision`` so they
    can correlate a decision with the policy version it ran under.
  * ``revision_transition_issue`` when the runtime observes a shape
    worth warning about. The canonical v0.21.0 example is
    "limit relaxation during active tightening" — a monitored limit
    was weakened while adaptive tightening was signalling danger.

This module is a thin read-only probe. It does NOT change the
admission decision; it only produces observational metadata that the
caller glues onto the decision envelope.

The admission-time :class:`adapter.cross_revision.CrossRevisionValidator`
remains the authoritative "reject the transition at declare time"
machinery. The runtime probe is strictly observational; when the
probe flags an issue, the decision envelope carries it alongside the
existing rule-level violation so callers see "we admitted on the
rule layer but the revision envelope is suspicious".
"""
from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import Any, Dict, Mapping, Optional, Sequence, Tuple

from adapter.cross_revision import NoWeakening
from adapter.runtime_guard import (
    NULL_TIGHTENING_STATE_SOURCE,
    TighteningStateSource,
)


@dataclass(frozen=True)
class RevisionRuntimeContext:
    """Compact revision-awareness snapshot for the decision envelope.

    Fields:
        previous_policy_revision:
            Id of the revision immediately preceding ``current`` on the
            active branch. ``None`` on genesis or when the log is empty.
        current_policy_revision:
            Id of the revision that admitted the decision. ``None`` when
            no log is wired.
        transition_issue:
            Populated only when a runtime warning applies. Shape:
            ``{"kind": <str>, "details": {<str>: <json>}}``. None
            otherwise so the envelope field stays absent when nothing
            to flag.
    """

    previous_policy_revision: Optional[str] = None
    current_policy_revision: Optional[str] = None
    transition_issue: Optional[Mapping[str, Any]] = None

    @property
    def has_warning(self) -> bool:
        return self.transition_issue is not None

    def to_wire(self) -> Dict[str, Any]:
        return {
            "previous_policy_revision": self.previous_policy_revision,
            "current_policy_revision": self.current_policy_revision,
            "revision_transition_issue": (
                dict(self.transition_issue)
                if self.transition_issue is not None
                else None
            ),
        }


def compute_revision_runtime_context(
    *,
    revision_log: Any = None,
    current_revision: Any = None,
    tightening_source: Optional[TighteningStateSource] = None,
    agent_id: Optional[str] = None,
) -> RevisionRuntimeContext:
    """Build the runtime revision-context probe output.

    Args:
        revision_log:
            The daemon's :class:`adapter.policy_revision.RevisionLog`
            (or any object with a ``latest`` / ``get_revision`` shape).
            ``None`` is accepted: the probe degrades cleanly to an
            empty context with no ids.
        current_revision:
            The revision under which this decision is being made. If
            ``None``, falls back to ``revision_log.latest``. Either
            form is accepted so tests can pass a synthetic revision
            without building a full log.
        tightening_source:
            Adaptive-tightening state source (agent A's Protocol —
            see :data:`adapter.runtime_guard.TighteningStateSource`).
            When ``None``, defaults to the null source so transition
            warnings never false-positive before agent A merges.
        agent_id:
            The agent whose tightening state we consult. ``None`` means
            "no agent context" and the transition check degrades to
            "no warning" (can't ask a question we have no subject for).

    Returns:
        :class:`RevisionRuntimeContext` with the populated fields.
    """
    current = current_revision
    if current is None and revision_log is not None:
        current = getattr(revision_log, "latest", None)
        # ``latest`` is sometimes a method on mock logs; unwrap if so.
        if callable(current):
            try:
                current = current()
            except Exception:  # noqa: BLE001 — defensive against exotic logs
                current = None
    current_id = _revision_id(current)
    previous_id = _previous_revision_id(current, revision_log)
    source = tightening_source or NULL_TIGHTENING_STATE_SOURCE
    issue = _detect_transition_issue(
        previous_revision=_resolve_previous(current, revision_log),
        current_revision=current,
        tightening_source=source,
        agent_id=agent_id,
    )
    return RevisionRuntimeContext(
        previous_policy_revision=previous_id,
        current_policy_revision=current_id,
        transition_issue=issue,
    )


# ── helpers ────────────────────────────────────────────────────────────────


def _revision_id(rev: Any) -> Optional[str]:
    if rev is None:
        return None
    rid = getattr(rev, "revision_id", None)
    if rid is None:
        rid = getattr(rev, "id", None)
    return str(rid) if rid is not None else None


def _previous_revision_id(current: Any, log: Any) -> Optional[str]:
    if current is None:
        return None
    # Preferred: ``predecessor_revision_id`` (matches PolicyRevision).
    prev = getattr(current, "predecessor_revision_id", None)
    if prev is None:
        prev = getattr(current, "parent_revision_id", None)
    if prev is None:
        return None
    return str(prev)


def _resolve_previous(current: Any, log: Any) -> Any:
    """Best-effort load of the PolicyRevision object preceding ``current``.

    The detection path needs to read invariant-level fields off both
    sides. We try two log-shaped accessors (``get_revision`` and
    ``find_revision``) and fall back to walking ``revisions`` if neither
    is present. Returns ``None`` if we can't resolve — the detector
    handles that gracefully by skipping the check.
    """
    prev_id = _previous_revision_id(current, log)
    if not prev_id or log is None:
        return None
    for method_name in ("get_revision", "find_revision", "lookup"):
        getter = getattr(log, method_name, None)
        if callable(getter):
            try:
                candidate = getter(prev_id)
            except Exception:  # noqa: BLE001 — defensive
                candidate = None
            if candidate is not None:
                return candidate
    revisions = getattr(log, "revisions", None)
    if revisions:
        for rev in revisions:
            if _revision_id(rev) == prev_id:
                return rev
    return None


def _detect_transition_issue(
    *,
    previous_revision: Any,
    current_revision: Any,
    tightening_source: TighteningStateSource,
    agent_id: Optional[str],
) -> Optional[Mapping[str, Any]]:
    """Return a transition-issue descriptor, or ``None`` if clean.

    Today the single case surfaced is
    ``limit_relaxation_during_active_tightening``: a monitored limit
    (SpendingCap / MaxPerCall / etc.) was weakened between the
    previous and current revisions while adaptive tightening is
    active for the agent making the decision.

    Returns ``None`` when:
      * Either revision is unavailable (we never fabricate warnings).
      * No monitored class was weakened.
      * The tightening source reports no active tightening (or
        ``agent_id`` is None — we have no subject to query).
    """
    if previous_revision is None or current_revision is None:
        return None
    if agent_id is None:
        return None
    try:
        if not tightening_source.is_tightening_active(agent_id):
            return None
    except Exception:  # noqa: BLE001 — fail-open on broken source
        return None
    weakenings = _weakenings_between(previous_revision, current_revision)
    if not weakenings:
        return None
    return {
        "kind": "limit_relaxation_during_active_tightening",
        "details": {
            "agent_id": agent_id,
            "weakened_rules": list(weakenings),
            "from_revision": _revision_id(previous_revision),
            "to_revision": _revision_id(current_revision),
        },
    }


def _weakenings_between(
    previous_revision: Any, current_revision: Any,
) -> Tuple[str, ...]:
    """Reuse NoWeakening's comparators to detect monitored-limit weakenings.

    We run a NoWeakening validator on the ``main`` monitored branch
    regardless of which branch the revision actually lives on: the
    probe is observational, so its branch scope is broader than the
    admission gate's. Downstream consumers can filter by branch in
    their dashboard if they want a narrower surface.
    """
    validator = NoWeakening()
    try:
        violations = validator.validate_transition(
            previous_revision, current_revision, "main"
        )
    except Exception:  # noqa: BLE001 — defensive
        return ()
    return tuple(sorted({v.category for v in violations}))


__all__ = [
    "RevisionRuntimeContext",
    "compute_revision_runtime_context",
]
