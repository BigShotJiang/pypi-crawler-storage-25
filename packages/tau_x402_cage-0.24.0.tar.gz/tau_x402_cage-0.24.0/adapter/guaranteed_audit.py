"""Audit-grade evidence chain for Guaranteed Mode (v0.19.0).

Guaranteed Mode is the bank-deployable tier: policies are admitted only
after a totality-proof + pure-Tau prover pass; runtime decisions are
signed off a statically-proven guard state; mutations go through the
strict no-weakening pipeline. Everything the cage does in this mode
produces append-only evidence records that an internal bank reviewer
(or an external compliance auditor) can verify offline against a
published public key or HMAC secret.

This module is the end-of-pipeline audit surface. It consumes the
outputs of:

  * ``adapter.guaranteed_language`` / ``guaranteed_prover`` — the
    admission path. Produces :class:`PolicyAdmissionEvidence` at the
    moment a policy revision is admitted.
  * ``adapter.guaranteed_runtime`` — the live decision path. Produces
    :class:`RuntimeDecisionEvidence` on every guaranteed-mode verdict.
  * ``adapter.guaranteed_mutation`` — the strict mutation pipeline.
    Rejected-weakening attempts emit a :class:`PolicyAdmissionEvidence`
    with ``totality_status="failed"`` (so the audit trail records the
    attempt, not a silent drop).

Wire shape
----------

Evidence is stored as JSON lines on disk (one record per line, UTF-8,
LF-terminated) at ``~/.tau-x402-cage/guaranteed_audit.jsonl``, overridable
via the ``TAU_X402_CAGE_AUDIT_STORE`` env var.

Each line carries one of two ``_record`` discriminators:

  * ``{"_record": "policy_admission", ...}``
  * ``{"_record": "runtime_decision", ...}``

A signed audit bundle ( :class:`GuaranteedAuditBundle` ) packages a
window of these records into a two-line JSONL file with an HMAC sidecar.
The layout mirrors ``adapter.audit_export`` so the same verification
toolchain works across both surfaces:

  line 1 = canonical JSON of ``{"bundle_version": "1", "records": [...]}``
  line 2 = ``{"signature": "<hex HMAC-SHA256>", "algorithm": "hmac-sha256"}``

The HMAC is computed over line 1's bytes (without trailing newline) so
reformatting doesn't invalidate an otherwise-identical bundle. We use
HMAC (not ed25519) by default here because the audit store is usually
sealed inside the bank's trust boundary — the shared-secret model is a
better fit than public-key distribution. Ed25519 can be layered on top
by feeding ``GuaranteedAuditBundle.serialize()`` into
``adapter.audit_export.sign_bundle``; those surfaces are explicitly kept
separate.

Immutability guarantees
-----------------------

* Evidence dataclasses are ``frozen=True`` and carry read-only mapping
  proxies for any dict fields so a caller who obtains a reference cannot
  mutate it.
* :class:`GuaranteedAuditBundle` is append-only; once ``serialize()``
  has been called the bundle locks and subsequent ``add_admission`` /
  ``add_decision`` calls raise :class:`AuditBundleLocked`.
* Canonical JSON (``sort_keys=True``, compact separators) is used on
  every serialisation path so two bundles over the same inputs produce
  byte-identical output.

Scope boundaries
----------------

* We do NOT re-run the prover. Bundles record which backend admitted
  the policy; an auditor who wants to re-prove fetches the compiled
  source separately. This matches the pattern in
  ``adapter.audit_export`` (integrity + provenance, not soundness).
* We do NOT enforce TTL at the audit layer. An admission from six
  months ago is still a verifiable piece of evidence; the consumer
  decides whether to act on it.
* We do NOT touch ``adapter.audit_export``. That module ships the
  flexible-mode ed25519-signed export of revision/branch/proposal logs.
  Guaranteed Mode gets its own evidence chain so the trust model stays
  explicit.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import os
import tempfile
import threading
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from types import MappingProxyType
from typing import Any, Iterable, List, Literal, Mapping, Optional, Tuple


# ── schema constants ────────────────────────────────────────────────────────


#: Frozen bundle schema version. Breaking wire changes bump to "2" and keep
#: v1 readers parsing every v1 bundle.
BUNDLE_VERSION_V1 = "1"

#: HMAC algorithm label written into the signature sidecar.
AUDIT_ALGORITHM_HMAC = "hmac-sha256"

#: Record-type discriminators for JSON-lines records.
RECORD_POLICY_ADMISSION = "policy_admission"
RECORD_RUNTIME_DECISION = "runtime_decision"

#: Valid totality-check outcomes. ``skipped`` is the escape hatch a
#: guaranteed-mode deployment MUST NOT use in production but which stays
#: representable so downgrade-debug loops can surface it.
TOTALITY_STATUS = ("passed", "failed", "skipped")

#: Default relative store path under ``~``.
DEFAULT_STORE_RELPATH = Path(".tau-x402-cage") / "guaranteed_audit.jsonl"


# ── exceptions ──────────────────────────────────────────────────────────────


class GuaranteedAuditError(ValueError):
    """Raised on malformed evidence input or canonical serialisation failure.

    Distinct from the runtime-tier failure codes (those live in
    ``adapter.guaranteed_errors``). This exception means the audit layer
    itself can't process the record — wrong shape, invalid timestamp,
    non-JSON-encodable field — not that the underlying guaranteed-mode
    check failed.
    """


class AuditBundleLocked(GuaranteedAuditError):
    """Raised when ``add_*`` is called on a bundle that has been serialised.

    Bundles are append-only. Once :meth:`GuaranteedAuditBundle.serialize`
    produces bytes, the bundle is immutable and further additions would
    invalidate the returned signature. Callers who need more evidence
    must construct a new bundle.
    """


class AuditSignatureError(GuaranteedAuditError):
    """Raised on signature verification failure or malformed bundle bytes."""


# ── helpers ─────────────────────────────────────────────────────────────────


def _canonical_dumps(obj: Any) -> str:
    """Single-source-of-truth canonical JSON serialisation.

    ``sort_keys`` + compact separators make the output byte-stable across
    Python versions, platforms, and call sites. Same on sign and verify so
    the signature is reproducible.
    """
    try:
        return json.dumps(obj, sort_keys=True, separators=(",", ":"))
    except TypeError as exc:
        raise GuaranteedAuditError(f"record is not JSON-serialisable: {exc}") from exc


def _isoformat_utc(ts: datetime) -> str:
    """Render a timezone-aware datetime as UTC ISO-8601.

    Naive datetimes are assumed UTC (the evidence path produces UTC stamps
    internally). ISO-8601 strings round-trip via :func:`datetime.fromisoformat`.
    """
    if not isinstance(ts, datetime):
        raise GuaranteedAuditError(
            f"expected datetime, got {type(ts).__name__}"
        )
    if ts.tzinfo is None:
        ts = ts.replace(tzinfo=timezone.utc)
    else:
        ts = ts.astimezone(timezone.utc)
    return ts.isoformat()


def _parse_iso(text: str) -> datetime:
    """Parse an ISO-8601 string back into a UTC-aware datetime."""
    if not isinstance(text, str):
        raise GuaranteedAuditError(
            f"expected ISO timestamp string, got {type(text).__name__}"
        )
    try:
        ts = datetime.fromisoformat(text)
    except ValueError as exc:
        raise GuaranteedAuditError(f"malformed ISO-8601 timestamp {text!r}: {exc}") from exc
    if ts.tzinfo is None:
        ts = ts.replace(tzinfo=timezone.utc)
    return ts


def _freeze_mapping(raw: Mapping[str, Any]) -> Mapping[str, Any]:
    """Return a read-only mapping proxy over a deep-copied plain-dict.

    Guard state summaries come in as arbitrary JSON-shaped dicts. We
    refuse anything that isn't a pure dict-of-JSON-scalars / lists /
    nested dicts so the evidence path can never be subverted by a live
    reference to mutable caller state.
    """
    if raw is None:
        raw = {}
    if not isinstance(raw, Mapping):
        raise GuaranteedAuditError(
            f"expected Mapping for guard_state_summary, got {type(raw).__name__}"
        )
    # Round-trip through canonical JSON to reject non-serialisable values
    # and deep-copy any nested containers at the same time.
    canonical = _canonical_dumps(dict(raw))
    parsed = json.loads(canonical)
    return MappingProxyType(parsed)


# ── evidence dataclasses ────────────────────────────────────────────────────


@dataclass(frozen=True)
class PolicyAdmissionEvidence:
    """A frozen, hashable record of a single policy-admission event.

    Emitted when the guaranteed-mode language/prover/totality pipeline
    admits (or rejects) a revision. An auditor can cross-reference
    ``revision_id`` + ``compile_hash`` against the prover's artifact
    store to re-run the proof offline.

    Fields:
        policy_id            : human-readable policy name (e.g. ``"bank-prod"``).
        revision_id          : UUID / content-hash of the revision.
        policy_source_hash   : SHA-256 over the canonical YAML/JSON source text.
        compile_hash         : hash from the :class:`GuaranteedProofArtifact`.
        proof_result         : free-form prover-verdict label (e.g. ``"proven"``).
        prove_backend_version: identifier of the prover build that decided.
        prove_timestamp      : UTC datetime at which the prover returned.
        totality_status      : one of ``passed`` / ``failed`` / ``skipped``.
        language_tier_version: the guaranteed-language tier this admission
                               was proven in (e.g. ``"tier-1"``).
        admitted_at          : UTC datetime the evidence was stamped.
        admitted_by          : optional actor id when mutation governance
                               applied actor-auth; ``None`` on automatic
                               promotions (e.g. startup bootstrap).
    """

    policy_id: str
    revision_id: str
    policy_source_hash: str
    compile_hash: str
    proof_result: str
    prove_backend_version: str
    prove_timestamp: datetime
    totality_status: str
    language_tier_version: str
    admitted_at: datetime
    admitted_by: Optional[str] = None

    def __post_init__(self) -> None:
        if self.totality_status not in TOTALITY_STATUS:
            raise GuaranteedAuditError(
                f"totality_status must be one of {TOTALITY_STATUS}, "
                f"got {self.totality_status!r}"
            )
        for name in ("policy_id", "revision_id", "policy_source_hash",
                     "compile_hash", "proof_result", "prove_backend_version",
                     "language_tier_version"):
            val = getattr(self, name)
            if not isinstance(val, str) or not val:
                raise GuaranteedAuditError(
                    f"PolicyAdmissionEvidence.{name} must be a non-empty str, got {val!r}"
                )
        if self.admitted_by is not None and not isinstance(self.admitted_by, str):
            raise GuaranteedAuditError(
                f"admitted_by must be str or None, got {type(self.admitted_by).__name__}"
            )

    def to_dict(self) -> dict:
        """Canonical-JSON-ready dict."""
        return {
            "policy_id": self.policy_id,
            "revision_id": self.revision_id,
            "policy_source_hash": self.policy_source_hash,
            "compile_hash": self.compile_hash,
            "proof_result": self.proof_result,
            "prove_backend_version": self.prove_backend_version,
            "prove_timestamp": _isoformat_utc(self.prove_timestamp),
            "totality_status": self.totality_status,
            "language_tier_version": self.language_tier_version,
            "admitted_at": _isoformat_utc(self.admitted_at),
            "admitted_by": self.admitted_by,
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "PolicyAdmissionEvidence":
        try:
            return cls(
                policy_id=data["policy_id"],
                revision_id=data["revision_id"],
                policy_source_hash=data["policy_source_hash"],
                compile_hash=data["compile_hash"],
                proof_result=data["proof_result"],
                prove_backend_version=data["prove_backend_version"],
                prove_timestamp=_parse_iso(data["prove_timestamp"]),
                totality_status=data["totality_status"],
                language_tier_version=data["language_tier_version"],
                admitted_at=_parse_iso(data["admitted_at"]),
                admitted_by=data.get("admitted_by"),
            )
        except KeyError as exc:
            raise GuaranteedAuditError(
                f"PolicyAdmissionEvidence.from_dict missing field: {exc}"
            ) from exc


@dataclass(frozen=True)
class RuntimeDecisionEvidence:
    """A frozen record of a single guaranteed-mode runtime verdict.

    Emitted on every call to the guaranteed-mode runtime path. The
    ``guard_state_summary`` is a MappingProxyType wrapping a canonical-
    JSON-validated snapshot of the guard counters (NOT full payment
    history — see scope boundaries above). Tampering with the summary
    at rest changes the bundle's HMAC; tampering with the live dict is
    impossible because the proxy blocks writes.

    Fields:
        decision_id              : UUID for this specific verdict.
        payment_intent_hash      : SHA-256 of the intent the verdict is
                                   about. Matches ``SignedEnvelope.intent_hash``.
        policy_revision_used     : the revision id that evaluated the call.
        proof_mode               : frozen to ``"guaranteed"``; the evidence
                                   shape exists solely for guaranteed-tier
                                   verdicts.
        proof_artifact_reference : ``<artifact_id>:<short-content-hash>``.
        guard_state_summary      : immutable mapping of counters / caps /
                                   velocities at decision time. Hash-stable.
        allow                    : True permit, False reject.
        reason                   : machine-readable reason (e.g. ``"RUNTIME_GUARD_VIOLATION"``).
        explanation              : deterministic English explanation.
        decision_timestamp       : UTC datetime the verdict was issued.
    """

    decision_id: str
    payment_intent_hash: str
    policy_revision_used: str
    proof_mode: Literal["guaranteed"]
    proof_artifact_reference: str
    guard_state_summary: Mapping[str, Any]
    allow: bool
    reason: str
    explanation: str
    decision_timestamp: datetime

    def __post_init__(self) -> None:
        if self.proof_mode != "guaranteed":
            raise GuaranteedAuditError(
                f"RuntimeDecisionEvidence.proof_mode must be 'guaranteed', "
                f"got {self.proof_mode!r}"
            )
        for name in ("decision_id", "payment_intent_hash", "policy_revision_used",
                     "proof_artifact_reference", "reason", "explanation"):
            val = getattr(self, name)
            if not isinstance(val, str) or not val:
                raise GuaranteedAuditError(
                    f"RuntimeDecisionEvidence.{name} must be a non-empty str, got {val!r}"
                )
        if not isinstance(self.allow, bool):
            raise GuaranteedAuditError(
                f"RuntimeDecisionEvidence.allow must be bool, got {type(self.allow).__name__}"
            )
        # Re-wrap the guard-state in a frozen proxy if the caller handed us
        # a plain dict. ``dataclasses.replace`` isn't used here because the
        # class is frozen; we mutate via ``object.__setattr__`` for this one
        # field so the public contract stays "pass a Mapping, get back a proxy".
        if not isinstance(self.guard_state_summary, MappingProxyType):
            object.__setattr__(
                self, "guard_state_summary",
                _freeze_mapping(self.guard_state_summary),
            )

    def to_dict(self) -> dict:
        return {
            "decision_id": self.decision_id,
            "payment_intent_hash": self.payment_intent_hash,
            "policy_revision_used": self.policy_revision_used,
            "proof_mode": self.proof_mode,
            "proof_artifact_reference": self.proof_artifact_reference,
            "guard_state_summary": dict(self.guard_state_summary),
            "allow": self.allow,
            "reason": self.reason,
            "explanation": self.explanation,
            "decision_timestamp": _isoformat_utc(self.decision_timestamp),
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "RuntimeDecisionEvidence":
        try:
            return cls(
                decision_id=data["decision_id"],
                payment_intent_hash=data["payment_intent_hash"],
                policy_revision_used=data["policy_revision_used"],
                proof_mode=data["proof_mode"],
                proof_artifact_reference=data["proof_artifact_reference"],
                guard_state_summary=data.get("guard_state_summary") or {},
                allow=bool(data["allow"]),
                reason=data["reason"],
                explanation=data["explanation"],
                decision_timestamp=_parse_iso(data["decision_timestamp"]),
            )
        except KeyError as exc:
            raise GuaranteedAuditError(
                f"RuntimeDecisionEvidence.from_dict missing field: {exc}"
            ) from exc


# ── append-only JSON-lines store ────────────────────────────────────────────


def _resolve_store_path(override: Optional[Path] = None) -> Path:
    """Resolve the JSON-lines store path.

    Precedence:
      1. explicit ``override``
      2. ``TAU_X402_CAGE_AUDIT_STORE`` env var
      3. ``~/.tau-x402-cage/guaranteed_audit.jsonl``

    The parent directory is created on write; we DON'T create it here so
    callers that only want to read don't pollute the home directory.
    """
    if override is not None:
        return Path(override).expanduser()
    env = os.environ.get("TAU_X402_CAGE_AUDIT_STORE")
    if env:
        return Path(env).expanduser()
    return Path.home() / DEFAULT_STORE_RELPATH


def append_admission_record(
    evidence: PolicyAdmissionEvidence,
    *,
    store_path: Optional[Path] = None,
) -> Path:
    """Append a single admission record to the JSONL store.

    Atomic per-line: we open in append mode with a single ``write`` of
    the canonical record plus newline, which on POSIX filesystems is
    atomic for writes below PIPE_BUF (~4KB — our records are well under
    that). The store is inherently append-only; we never seek backwards.
    """
    return _append_record(
        record_type=RECORD_POLICY_ADMISSION,
        payload=evidence.to_dict(),
        store_path=store_path,
    )


def append_decision_record(
    evidence: RuntimeDecisionEvidence,
    *,
    store_path: Optional[Path] = None,
) -> Path:
    """Append a single runtime-decision record to the JSONL store."""
    return _append_record(
        record_type=RECORD_RUNTIME_DECISION,
        payload=evidence.to_dict(),
        store_path=store_path,
    )


def _append_record(
    *,
    record_type: str,
    payload: dict,
    store_path: Optional[Path],
) -> Path:
    """Lowest-level JSONL-append primitive.

    Wraps every record with an ``_record`` discriminator so the reader
    can dispatch on type without guessing at shape. Returns the resolved
    store path for the caller's logs.
    """
    target = _resolve_store_path(store_path)
    target.parent.mkdir(parents=True, exist_ok=True)
    record = {"_record": record_type, **payload}
    line = _canonical_dumps(record) + "\n"
    with open(target, "a", encoding="utf-8") as f:
        f.write(line)
    return target


def iter_records(
    *,
    store_path: Optional[Path] = None,
) -> Iterable[Tuple[str, dict]]:
    """Yield ``(record_type, payload)`` for every record in the store.

    Silently tolerates empty stores (returns no items). Malformed JSON
    lines raise :class:`GuaranteedAuditError` with the line number so
    operators can find the corruption. We deliberately don't skip them:
    a corrupted audit log is a load-bearing signal.
    """
    target = _resolve_store_path(store_path)
    if not target.exists():
        return
    with open(target, "r", encoding="utf-8") as f:
        for lineno, line in enumerate(f, start=1):
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError as exc:
                raise GuaranteedAuditError(
                    f"audit store line {lineno}: malformed JSON: {exc}"
                ) from exc
            rtype = obj.get("_record")
            if rtype not in (RECORD_POLICY_ADMISSION, RECORD_RUNTIME_DECISION):
                raise GuaranteedAuditError(
                    f"audit store line {lineno}: unknown _record {rtype!r}"
                )
            payload = {k: v for k, v in obj.items() if k != "_record"}
            yield (rtype, payload)


def load_admissions(
    *,
    store_path: Optional[Path] = None,
) -> List[PolicyAdmissionEvidence]:
    """Load all admission evidence records from the store, in order."""
    out: List[PolicyAdmissionEvidence] = []
    for rtype, payload in iter_records(store_path=store_path):
        if rtype == RECORD_POLICY_ADMISSION:
            out.append(PolicyAdmissionEvidence.from_dict(payload))
    return out


def load_decisions(
    *,
    store_path: Optional[Path] = None,
) -> List[RuntimeDecisionEvidence]:
    """Load all runtime-decision evidence records from the store, in order."""
    out: List[RuntimeDecisionEvidence] = []
    for rtype, payload in iter_records(store_path=store_path):
        if rtype == RECORD_RUNTIME_DECISION:
            out.append(RuntimeDecisionEvidence.from_dict(payload))
    return out


def find_admission_by_revision(
    revision_id: str,
    *,
    store_path: Optional[Path] = None,
) -> Optional[PolicyAdmissionEvidence]:
    """Return the most recent admission evidence for ``revision_id`` or None."""
    hit: Optional[PolicyAdmissionEvidence] = None
    for ev in load_admissions(store_path=store_path):
        if ev.revision_id == revision_id:
            hit = ev  # keep walking so the latest admission wins
    return hit


def find_decision_by_id(
    decision_id: str,
    *,
    store_path: Optional[Path] = None,
) -> Optional[RuntimeDecisionEvidence]:
    """Return the decision evidence for ``decision_id`` or None."""
    for ev in load_decisions(store_path=store_path):
        if ev.decision_id == decision_id:
            return ev
    return None


# ── bundle ─────────────────────────────────────────────────────────────────


class GuaranteedAuditBundle:
    """Append-only, HMAC-signed bundle of guaranteed-mode evidence.

    Usage::

        bundle = GuaranteedAuditBundle()
        bundle.add_admission(evidence)
        bundle.add_decision(decision)
        signed = bundle.serialize(hmac_key=secret)
        # bundle is now locked; further add_* raises AuditBundleLocked

    Layout on the wire (two JSONL lines):

        line 1 — ``{"bundle_version": "1", "records": [...], "created_at": "..."}``
        line 2 — ``{"signature": "<hex>", "algorithm": "hmac-sha256"}``

    The HMAC covers line 1's bytes WITHOUT the trailing newline so an
    editor that reformats trailing whitespace doesn't invalidate an
    otherwise-identical signature.

    Thread-safety: a single bundle is not safe for concurrent mutation
    from multiple threads. Serialise additions inside a lock if the
    daemon is going to emit from more than one worker.
    """

    __slots__ = ("_admissions", "_decisions", "_locked", "_lock", "_created_at")

    def __init__(self, *, created_at: Optional[datetime] = None) -> None:
        self._admissions: List[PolicyAdmissionEvidence] = []
        self._decisions: List[RuntimeDecisionEvidence] = []
        self._locked: bool = False
        self._lock = threading.Lock()
        self._created_at = created_at or datetime.now(tz=timezone.utc)

    # ── additions ──────────────────────────────────────────────────────────

    def add_admission(self, evidence: PolicyAdmissionEvidence) -> None:
        """Append a :class:`PolicyAdmissionEvidence` to the bundle.

        Raises :class:`AuditBundleLocked` if :meth:`serialize` has been
        called. Bundles are append-only by construction — once a caller
        has a signature over the records, new records would invalidate
        it.
        """
        if not isinstance(evidence, PolicyAdmissionEvidence):
            raise GuaranteedAuditError(
                f"add_admission expected PolicyAdmissionEvidence, "
                f"got {type(evidence).__name__}"
            )
        with self._lock:
            if self._locked:
                raise AuditBundleLocked(
                    "bundle is sealed after serialize(); "
                    "construct a new GuaranteedAuditBundle to add more records"
                )
            self._admissions.append(evidence)

    def add_decision(self, evidence: RuntimeDecisionEvidence) -> None:
        """Append a :class:`RuntimeDecisionEvidence` to the bundle.

        See :meth:`add_admission` for locking semantics.
        """
        if not isinstance(evidence, RuntimeDecisionEvidence):
            raise GuaranteedAuditError(
                f"add_decision expected RuntimeDecisionEvidence, "
                f"got {type(evidence).__name__}"
            )
        with self._lock:
            if self._locked:
                raise AuditBundleLocked(
                    "bundle is sealed after serialize(); "
                    "construct a new GuaranteedAuditBundle to add more records"
                )
            self._decisions.append(evidence)

    # ── accessors ──────────────────────────────────────────────────────────

    @property
    def admission_count(self) -> int:
        return len(self._admissions)

    @property
    def decision_count(self) -> int:
        return len(self._decisions)

    @property
    def is_locked(self) -> bool:
        return self._locked

    # ── serialise / verify ─────────────────────────────────────────────────

    def _build_payload(self) -> dict:
        """Build the signed-line payload. Pure function of current contents."""
        records: List[dict] = []
        for adm in self._admissions:
            records.append({"_record": RECORD_POLICY_ADMISSION, **adm.to_dict()})
        for dec in self._decisions:
            records.append({"_record": RECORD_RUNTIME_DECISION, **dec.to_dict()})
        return {
            "bundle_version": BUNDLE_VERSION_V1,
            "created_at": _isoformat_utc(self._created_at),
            "records": records,
        }

    def serialize(self, *, hmac_key: bytes) -> bytes:
        """Freeze the bundle, sign it, and return the JSONL bytes.

        After this returns, the bundle rejects further additions. HMAC
        key must be at least 16 bytes to match the cage-wide convention
        in ``verdict_signer``.
        """
        if not isinstance(hmac_key, (bytes, bytearray)):
            raise GuaranteedAuditError(
                f"hmac_key must be bytes, got {type(hmac_key).__name__}"
            )
        if len(hmac_key) < 16:
            raise GuaranteedAuditError("hmac_key must be at least 16 bytes")
        with self._lock:
            if self._locked:
                raise AuditBundleLocked(
                    "bundle already serialised; call serialize() exactly once"
                )
            payload = self._build_payload()
            payload_line = _canonical_dumps(payload)
            mac = hmac.new(
                bytes(hmac_key),
                payload_line.encode("utf-8"),
                hashlib.sha256,
            ).hexdigest()
            sig_line = _canonical_dumps({
                "signature": mac,
                "algorithm": AUDIT_ALGORITHM_HMAC,
            })
            self._locked = True
            return (payload_line + "\n" + sig_line + "\n").encode("utf-8")

    @staticmethod
    def verify(blob: bytes, key: bytes) -> bool:
        """Verify an HMAC-signed bundle against the expected key.

        Returns True iff:
          * the bundle parses into two JSONL lines
          * the declared algorithm matches ``hmac-sha256``
          * the HMAC over line 1 matches the sidecar signature
          * ``bundle_version`` is the frozen v1

        Does NOT validate every record's shape — that's what
        :func:`bundle_records` does. This method is a hot-path integrity
        check that answers one question: "was this bundle produced by
        someone who holds the key?"
        """
        try:
            return GuaranteedAuditBundle._verify_structured(blob, key).valid
        except GuaranteedAuditError:
            return False

    @staticmethod
    def _verify_structured(blob: bytes, key: bytes) -> "BundleVerifyResult":
        if not isinstance(blob, (bytes, bytearray)):
            raise GuaranteedAuditError(
                f"verify expects bytes, got {type(blob).__name__}"
            )
        if not isinstance(key, (bytes, bytearray)):
            raise GuaranteedAuditError(
                f"key must be bytes, got {type(key).__name__}"
            )
        try:
            text = bytes(blob).decode("utf-8")
        except UnicodeDecodeError as exc:
            raise GuaranteedAuditError(f"bundle bytes are not valid UTF-8: {exc}") from exc
        if "\n" not in text:
            return BundleVerifyResult(False, "bundle is not a two-line JSONL file")
        payload_line, _, rest = text.partition("\n")
        sig_line = rest.rstrip("\n")
        if not sig_line:
            return BundleVerifyResult(False, "bundle missing signature line")
        try:
            payload = json.loads(payload_line)
        except json.JSONDecodeError as exc:
            return BundleVerifyResult(False, f"payload line is not valid JSON: {exc}")
        try:
            sig_record = json.loads(sig_line)
        except json.JSONDecodeError as exc:
            return BundleVerifyResult(False, f"signature line is not valid JSON: {exc}")
        if not isinstance(payload, dict):
            return BundleVerifyResult(False, "payload is not a JSON object")
        version = payload.get("bundle_version")
        if version != BUNDLE_VERSION_V1:
            return BundleVerifyResult(
                False,
                f"unsupported bundle_version {version!r}; expected v{BUNDLE_VERSION_V1}",
            )
        alg = sig_record.get("algorithm")
        if alg != AUDIT_ALGORITHM_HMAC:
            return BundleVerifyResult(
                False,
                f"unsupported signature algorithm {alg!r}; expected {AUDIT_ALGORITHM_HMAC}",
            )
        provided_sig = sig_record.get("signature")
        if not isinstance(provided_sig, str) or not provided_sig:
            return BundleVerifyResult(False, "signature record missing 'signature' field")
        expected = hmac.new(
            bytes(key), payload_line.encode("utf-8"), hashlib.sha256
        ).hexdigest()
        if not hmac.compare_digest(provided_sig, expected):
            return BundleVerifyResult(
                False,
                "signature mismatch — bundle tampered or wrong key",
            )
        return BundleVerifyResult(True, None, payload=payload)


@dataclass(frozen=True)
class BundleVerifyResult:
    """Structured outcome of :meth:`GuaranteedAuditBundle._verify_structured`."""

    valid: bool
    reason: Optional[str] = None
    payload: Optional[dict] = field(default=None, repr=False)


def bundle_records(blob: bytes) -> Tuple[
    Tuple[PolicyAdmissionEvidence, ...],
    Tuple[RuntimeDecisionEvidence, ...],
]:
    """Parse a verified bundle's records (does NOT verify the signature).

    Separate from :meth:`GuaranteedAuditBundle.verify` so a caller can
    parse + act in two steps: verify first (cheap, integrity), then
    parse (allocation-heavy, only needed if acting).
    """
    if not isinstance(blob, (bytes, bytearray)):
        raise GuaranteedAuditError(
            f"bundle_records expects bytes, got {type(blob).__name__}"
        )
    try:
        text = bytes(blob).decode("utf-8")
    except UnicodeDecodeError as exc:
        raise GuaranteedAuditError(f"bundle bytes are not valid UTF-8: {exc}") from exc
    payload_line = text.split("\n", 1)[0]
    try:
        payload = json.loads(payload_line)
    except json.JSONDecodeError as exc:
        raise GuaranteedAuditError(f"payload line is not valid JSON: {exc}") from exc
    records = payload.get("records")
    if not isinstance(records, list):
        raise GuaranteedAuditError("payload.records is not a list")
    admissions: List[PolicyAdmissionEvidence] = []
    decisions: List[RuntimeDecisionEvidence] = []
    for entry in records:
        if not isinstance(entry, dict):
            raise GuaranteedAuditError(
                f"record entry must be a dict, got {type(entry).__name__}"
            )
        rtype = entry.get("_record")
        body = {k: v for k, v in entry.items() if k != "_record"}
        if rtype == RECORD_POLICY_ADMISSION:
            admissions.append(PolicyAdmissionEvidence.from_dict(body))
        elif rtype == RECORD_RUNTIME_DECISION:
            decisions.append(RuntimeDecisionEvidence.from_dict(body))
        else:
            raise GuaranteedAuditError(f"unknown _record {rtype!r}")
    return tuple(admissions), tuple(decisions)


# ── export helpers ──────────────────────────────────────────────────────────


def export_range(
    *,
    since: Optional[datetime] = None,
    until: Optional[datetime] = None,
    store_path: Optional[Path] = None,
) -> GuaranteedAuditBundle:
    """Build a bundle from all store records in ``[since, until]``.

    Inclusive on both ends. When ``since`` / ``until`` are None, the
    range is unbounded on that side. Evidence timestamps are compared
    using ``admitted_at`` for admissions and ``decision_timestamp`` for
    decisions, both UTC.
    """
    bundle = GuaranteedAuditBundle()
    since_utc = _normalise_opt_utc(since)
    until_utc = _normalise_opt_utc(until)
    for adm in load_admissions(store_path=store_path):
        if _in_range(adm.admitted_at, since_utc, until_utc):
            bundle.add_admission(adm)
    for dec in load_decisions(store_path=store_path):
        if _in_range(dec.decision_timestamp, since_utc, until_utc):
            bundle.add_decision(dec)
    return bundle


def _normalise_opt_utc(ts: Optional[datetime]) -> Optional[datetime]:
    if ts is None:
        return None
    if ts.tzinfo is None:
        return ts.replace(tzinfo=timezone.utc)
    return ts.astimezone(timezone.utc)


def _in_range(
    ts: datetime,
    since: Optional[datetime],
    until: Optional[datetime],
) -> bool:
    ts_utc = ts if ts.tzinfo is not None else ts.replace(tzinfo=timezone.utc)
    if since is not None and ts_utc < since:
        return False
    if until is not None and ts_utc > until:
        return False
    return True


# ── temp-store context manager (demo / test convenience) ─────────────────────


class temporary_audit_store:
    """Context manager that redirects the audit store to a fresh tempdir.

    Used by the bank evaluation demo and the test suite so the default
    ``~/.tau-x402-cage/`` path is never touched during runs. Restores
    the previous ``TAU_X402_CAGE_AUDIT_STORE`` env var on exit.
    """

    def __init__(self) -> None:
        self._tmp: Optional[tempfile.TemporaryDirectory] = None
        self._prev: Optional[str] = None
        self._path: Optional[Path] = None

    def __enter__(self) -> Path:
        self._tmp = tempfile.TemporaryDirectory(prefix="tau-x402-audit-")
        self._path = Path(self._tmp.name) / "guaranteed_audit.jsonl"
        self._prev = os.environ.get("TAU_X402_CAGE_AUDIT_STORE")
        os.environ["TAU_X402_CAGE_AUDIT_STORE"] = str(self._path)
        return self._path

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        if self._prev is None:
            os.environ.pop("TAU_X402_CAGE_AUDIT_STORE", None)
        else:
            os.environ["TAU_X402_CAGE_AUDIT_STORE"] = self._prev
        if self._tmp is not None:
            self._tmp.cleanup()
        self._tmp = None
        self._path = None
        self._prev = None
