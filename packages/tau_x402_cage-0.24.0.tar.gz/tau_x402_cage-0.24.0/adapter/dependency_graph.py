"""Dependency graph for incremental pointwise revision.

Given a set of declared invariants, decides which pairs can interact. An
"interaction" means the pair shares a dimension such that adding or
removing one member of the pair could change whether the other composes
consistently. Two invariants that share no interaction dimension cannot
affect each other's SAT status, so a mutation touching one need not
re-evaluate the other.

Interaction dimensions (conservative — false positives are safe; false
negatives would be catastrophic):

  * `amount`           -- MaxPerCall, SpendingCap, JurisdictionRule-with-caps
  * `provider`         -- ProviderAllowlist, MutualExclusion, SpendingCap(per_provider_per_window)
  * `counterparty`     -- CounterpartyConstraint
  * `jurisdiction`     -- JurisdictionRule
  * `temporal_window`  -- SpendingCap(per_window), RollingWindowCap, RetryRateLimit
  * `fragment_v1`      -- everything Tau decides
  * `fragment_v2`      -- everything z3 decides

The graph produces an "affected subgraph" for a given set of changed
invariants: the transitive closure of everything that shares a dimension
with anything in the change set.

Edge rule (commutative): `interacts(inv_a, inv_b)` iff they share at
least one dimension.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import FrozenSet, Iterable, Set, Tuple

from adapter.invariants import (
    CounterpartyConstraint,
    Invariant,
    JurisdictionRule,
    MaxPerCall,
    MutualExclusion,
    ProviderAllowlist,
    RetryRateLimit,
    RollingWindowCap,
    SpendingCap,
)


# ── dimension inference ──────────────────────────────────────────────────────


def dimensions(inv: Invariant) -> FrozenSet[str]:
    """Return the set of interaction dimensions this invariant touches."""
    dims: set[str] = set()
    if isinstance(inv, MaxPerCall):
        dims.update({"amount", "fragment_v1"})
    elif isinstance(inv, SpendingCap):
        if inv.scope == "per_tx":
            dims.update({"amount", "fragment_v1"})
        else:  # per_window, per_provider_per_window
            dims.update({"amount", "temporal_window", "fragment_v2"})
            if inv.scope == "per_provider_per_window":
                dims.add("provider")
    elif isinstance(inv, ProviderAllowlist):
        dims.update({"provider", "fragment_v1"})
    elif isinstance(inv, CounterpartyConstraint):
        dims.update({"counterparty", "fragment_v1"})
    elif isinstance(inv, MutualExclusion):
        dims.update({"provider", "fragment_v1"})
    elif isinstance(inv, JurisdictionRule):
        dims.add("jurisdiction")
        dims.add("fragment_v1")
        # Inner invariants contribute their own dimensions (composition).
        for sub in inv.additional_invariants:
            dims.update(dimensions(sub))
    elif isinstance(inv, RetryRateLimit):
        dims.update({"temporal_window", "provider", "counterparty", "fragment_v2"})
    elif isinstance(inv, RollingWindowCap):
        dims.update({"temporal_window", "fragment_v2"})
        if inv.group_by == "provider":
            dims.add("provider")
        elif inv.group_by == "counterparty":
            dims.add("counterparty")
    return frozenset(dims)


def interacts(a: Invariant, b: Invariant) -> bool:
    """True iff `a` and `b` share at least one interaction dimension."""
    return bool(dimensions(a) & dimensions(b))


# ── graph API ────────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class DependencyGraph:
    """Dependency graph over a set of invariants.

    The graph is rebuilt from scratch per invariant-set snapshot (set sizes
    are small, N<100 in realistic policies, so O(N^2) pairwise scan is
    cheaper than maintaining incremental edge indexes). Constructed in
    linear time over N.
    """

    invariants: tuple

    def affected_subgraph(
        self,
        changed: Iterable[Invariant],
    ) -> Tuple[Invariant, ...]:
        """Return the transitive closure of invariants that interact with
        anything in `changed`. Always includes `changed` itself.

        Order: deterministic (input order of `invariants`), so audit logs
        stay stable across runs.
        """
        changed_set: Set[int] = {id(c) for c in changed}
        # Also seed with invariants from self.invariants that are == one of
        # the changed set (identity-vs-value disambiguation).
        for inv in self.invariants:
            if any(inv == c for c in changed):
                changed_set.add(id(inv))

        affected_ids: Set[int] = set(changed_set)
        # Fixed-point closure: keep adding neighbors until no new node found.
        grew = True
        while grew:
            grew = False
            for inv in self.invariants:
                if id(inv) in affected_ids:
                    continue
                for other in self.invariants:
                    if id(other) not in affected_ids:
                        continue
                    if interacts(inv, other):
                        affected_ids.add(id(inv))
                        grew = True
                        break
        # Stable input-order slice.
        return tuple(inv for inv in self.invariants if id(inv) in affected_ids)

    def is_disjoint(self, probe: Invariant) -> bool:
        """True iff `probe` shares NO dimension with any existing invariant.

        A disjoint add is the fast-path: it cannot contradict anything, so
        the daemon can skip the prover entirely and admit immediately.
        (Strict mode still records the revision; the admission reason
        becomes "disjoint with active set".)
        """
        return not any(interacts(probe, other) for other in self.invariants)
