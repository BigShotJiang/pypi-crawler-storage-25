"""Explicit guarantees surface (v0.14.0).

What the cage claims to deliver, classified by component, with a plain-English
description of what fails when the cage is disabled. Shipped as a first-class
read surface on the daemon, CLI, and web UI so an operator (or their auditor)
can enumerate — at any moment — the exact set of guarantees in force AND the
tradeoff they would accept by turning the cage off.

Design notes:

*   Every guarantee is a frozen `Guarantee` dataclass so the catalog is
    immutable end-to-end. Enumeration builds a fresh list on every call.
*   `enumerate_guarantees` introspects a running daemon + registry +
    history store to decide which guarantees are currently `active`. A
    guarantee can be shipped in the catalog but reported `active=False`
    when its enabling component is not wired — e.g. `G-SIG-02` when
    signing is HMAC, `G-TMP-03` when no `InstabilityGuard` is declared.
*   The `provided_by` field is a string (module path), not a live import,
    so we can reference sibling modules that do not yet exist in this
    tree (cross-revision validator, mutation-governance policy). See the
    patch-12 scope note: we intentionally avoid importing those modules
    from this file.
*   The `evidence` dict is JSON-safe by construction — only str, int,
    bool, None, list, and nested dict values are admitted. This keeps
    the daemon-op JSON round-trip trivial.

The catalog itself is the value prop: it tells an operator, explicitly,
what they gain from running the cage and what they give up by turning
it off. See ``docs/guarantees.md`` for the narrative.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Literal, Mapping, Optional, Sequence

# ── types ───────────────────────────────────────────────────────────────────

#: Category taxonomy. Kept small on purpose so the dashboard can render
#: one column per category without overwhelming the operator.
GuaranteeCategory = Literal[
    "signature",
    "provenance",
    "decidability",
    "temporal",
    "governance",
    "observability",
]

_CATEGORIES: tuple[GuaranteeCategory, ...] = (
    "signature",
    "provenance",
    "decidability",
    "temporal",
    "governance",
    "observability",
)


@dataclass(frozen=True)
class Guarantee:
    """One claim the cage makes.

    Fields:
        id: stable short identifier (e.g. ``G-SIG-01``). Appears in the
            dashboard and in wire payloads. Never rewrites a historical
            id — new guarantees append, retired ones stay in the catalog
            but report ``active=False`` with a deprecation-style reason.
        summary: one-sentence plain-English description of what the
            cage delivers when this guarantee is active.
        category: which column of the dashboard this sits under.
        provided_by: module path (as a string) of the component that
            delivers the guarantee. Descriptive, not imported.
        lost_if_disabled: plain-English description of the failure mode
            the operator accepts by turning the cage off. This is the
            load-bearing field for the dashboard's "What you lose"
            column — it is what an auditor reads.
        active: whether the guarantee is currently in force given the
            introspected daemon configuration.
        evidence: free-form JSON-safe dict of runtime evidence. May
            include active invariant counts, configured signing
            algorithm, feature flags, etc. Deliberately bounded to
            JSON-serialisable primitives for op round-trip.
        inactive_reason: when `active=False`, a short human-readable
            phrase explaining why. Empty string when `active=True`.
    """

    id: str
    summary: str
    category: GuaranteeCategory
    provided_by: str
    lost_if_disabled: str
    active: bool
    evidence: Mapping[str, Any] = field(default_factory=dict)
    inactive_reason: str = ""

    def to_wire(self) -> Dict[str, Any]:
        """JSON-safe serialisation for daemon-op responses."""
        return {
            "id": self.id,
            "summary": self.summary,
            "category": self.category,
            "provided_by": self.provided_by,
            "lost_if_disabled": self.lost_if_disabled,
            "active": self.active,
            "evidence": dict(self.evidence),
            "inactive_reason": self.inactive_reason,
        }


# ── JSON safety helper ──────────────────────────────────────────────────────


_JSON_PRIMITIVES = (str, int, float, bool, type(None))


def _json_safe(value: Any) -> Any:
    """Return a JSON-safe copy of ``value``.

    Rejects bytes, `Decimal`, and other non-primitive scalars by stringifying
    them. Accepts nested dicts and lists of JSON-safe values. Used so the
    ``evidence`` dict never leaks a bytes/Decimal into the wire payload.
    """
    if isinstance(value, _JSON_PRIMITIVES):
        return value
    if isinstance(value, Mapping):
        return {str(k): _json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, frozenset, set)):
        return [_json_safe(v) for v in value]
    # Bytes, Decimal, dataclasses etc. fall through to str() — the guarantee
    # payload is for human consumption first, machine consumption second.
    return str(value)


def _safe_evidence(**kwargs: Any) -> Dict[str, Any]:
    """Build an evidence dict with every value run through `_json_safe`."""
    return {k: _json_safe(v) for k, v in kwargs.items()}


# ── catalog / enumeration ───────────────────────────────────────────────────


def _invariant_class_names(registry: Any) -> List[str]:
    """Names of the classes currently resident in the registry.

    Kept defensive so the function works against the real `X402Registry`
    (which exposes `invariants` as a tuple) and any stub that exposes the
    same attribute shape.
    """
    invariants = getattr(registry, "invariants", ()) or ()
    return [type(inv).__name__ for inv in invariants]


def _signing_algorithm(env: Mapping[str, str]) -> str:
    """Resolve the configured signing algorithm, defaulting to HMAC."""
    algo = env.get("TAU_CAGE_SIGNING_ALGORITHM", "hmac-sha256")
    return algo.strip() or "hmac-sha256"


def _metrics_token_configured(env: Mapping[str, str]) -> bool:
    """True iff a non-empty TAU_X402_METRICS_TOKEN is set."""
    return bool((env.get("TAU_X402_METRICS_TOKEN") or "").strip())


def _probe_module(module_path: str) -> bool:
    """Return True iff the named module can be imported at call time.

    Used to gate guarantees on sibling modules (mutation-governance,
    cross-revision validator) that may or may not be present depending
    on which patches have landed on this branch. Never imports the
    module into our namespace.
    """
    import importlib.util
    try:
        spec = importlib.util.find_spec(module_path)
    except (ImportError, ValueError, ModuleNotFoundError):
        return False
    return spec is not None


def _mutation_governance_min_reviewers(daemon_config: Mapping[str, Any]) -> int:
    """Inspect ``daemon_config`` for a mutation-governance policy and return
    the ``min_reviewers`` it requires. Returns 0 when no such policy is wired.
    """
    gov = daemon_config.get("mutation_governance") or {}
    try:
        return int(gov.get("min_reviewers") or 0)
    except (TypeError, ValueError):
        return 0


def _cross_revision_rules(daemon_config: Mapping[str, Any]) -> Sequence[str]:
    """Names of cross-revision validator rules currently loaded."""
    rules = daemon_config.get("cross_revision_rules") or ()
    try:
        return tuple(str(r) for r in rules)
    except TypeError:
        return ()


def enumerate_guarantees(
    registry: Any,
    daemon_config: Mapping[str, Any],
    history_store: Any = None,
    env: Optional[Mapping[str, str]] = None,
) -> List[Guarantee]:
    """Build the guarantee catalog for the current daemon configuration.

    Args:
        registry: live ``X402Registry`` (any object with an ``invariants``
            attribute). Used to decide which temporal/self-ref guarantees
            are active.
        daemon_config: dict-shaped snapshot of daemon wiring:
            - ``signing_algorithm``: optional override for HMAC/Ed25519.
              When absent we read ``TAU_CAGE_SIGNING_ALGORITHM``.
            - ``require_human_approval``: bool
            - ``approval_queue_configured``: bool
            - ``hybrid_prover_wired``: bool
            - ``z3_prover_wired``: bool
            - ``mutation_governance``: optional dict with ``min_reviewers``
            - ``cross_revision_rules``: optional sequence of rule names
            - ``envelope_version``: string, defaults to "v2"
        history_store: passed through for evidence collection only.
            None is tolerated so the function is usable from dry-run
            callers without a live store.
        env: environment mapping. Defaults to ``os.environ``.

    Returns:
        A fresh list of `Guarantee` instances. Order is stable (category,
        then id) so the CLI/web UI can rely on iteration order.
    """
    environ = env if env is not None else os.environ
    invariant_classes = set(_invariant_class_names(registry))
    signing_algo = (
        daemon_config.get("signing_algorithm")
        or _signing_algorithm(environ)
    )
    envelope_version = daemon_config.get("envelope_version") or "v2"
    hybrid_wired = bool(daemon_config.get("hybrid_prover_wired"))
    z3_wired = bool(daemon_config.get("z3_prover_wired"))
    approval_queue_configured = bool(
        daemon_config.get("approval_queue_configured")
    )
    require_human_approval = bool(daemon_config.get("require_human_approval"))
    min_reviewers = _mutation_governance_min_reviewers(daemon_config)
    cross_rules = _cross_revision_rules(daemon_config)
    metrics_token = _metrics_token_configured(environ)
    # `metrics` optional extra is considered installed when the
    # prometheus_client package resolves. We don't import it; we only
    # ask importlib whether it exists.
    metrics_extra_installed = _probe_module("prometheus_client")

    active_invariant_count = len(list(getattr(registry, "invariants", ()) or ()))

    # Prevented-risk counter from the history store is best-effort. We
    # accept any object that answers ``count("reject")``; otherwise the
    # evidence field stays 0.
    reject_count = 0
    if history_store is not None:
        counter = getattr(history_store, "count", None)
        if callable(counter):
            try:
                reject_count = int(counter("reject"))
            except Exception:  # pragma: no cover - defensive
                reject_count = 0

    out: List[Guarantee] = []

    # ── signature ───────────────────────────────────────────────────────

    out.append(Guarantee(
        id="G-SIG-01",
        category="signature",
        summary="Every verdict is MAC-bound to the intent.",
        provided_by="adapter/verdict_signer.py",
        lost_if_disabled=(
            "The facilitator cannot prove the verdict came from the cage. "
            "An attacker can forge a permit with no cryptographic trail."
        ),
        active=True,
        evidence=_safe_evidence(
            signing_algorithm=signing_algo,
            envelope_version=envelope_version,
        ),
    ))

    ed25519_active = signing_algo == "ed25519"
    out.append(Guarantee(
        id="G-SIG-02",
        category="signature",
        summary="Ed25519 asymmetric signing available.",
        provided_by="adapter/verdict_signer.py",
        lost_if_disabled=(
            "No offline public-key verification. Auditors and downstream "
            "consumers must share the HMAC secret to verify verdicts."
        ),
        active=ed25519_active,
        evidence=_safe_evidence(signing_algorithm=signing_algo),
        inactive_reason=(
            "" if ed25519_active
            else f"signing algorithm is {signing_algo}, not ed25519"
        ),
    ))

    # ── provenance ──────────────────────────────────────────────────────

    v2_active = envelope_version == "v2"
    out.append(Guarantee(
        id="G-PROV-01",
        category="provenance",
        summary="Every verdict carries the policy_revision_id that produced it.",
        provided_by="adapter/verdict_signer.py (v2 envelope)",
        lost_if_disabled=(
            "Post-hoc 'which policy decided this' is unanswerable. A "
            "verdict returned last Tuesday cannot be traced back to the "
            "rule set in force at that moment."
        ),
        active=v2_active,
        evidence=_safe_evidence(envelope_version=envelope_version),
        inactive_reason=(
            "" if v2_active
            else f"envelope_version={envelope_version!r}, v2 required"
        ),
    ))

    out.append(Guarantee(
        id="G-PROV-02",
        category="provenance",
        summary="Audit export is byte-deterministic + signed.",
        provided_by="adapter/audit_export.py",
        lost_if_disabled=(
            "A regulator cannot verify log integrity offline. The audit "
            "trail becomes non-repudiable only if you trust the exporting "
            "operator."
        ),
        active=True,
        evidence=_safe_evidence(available=True),
    ))

    # ── decidability ────────────────────────────────────────────────────

    out.append(Guarantee(
        id="G-DEC-01",
        category="decidability",
        summary=(
            "Declare-time contradiction detection "
            "(fragment v1 Tau-decidable)."
        ),
        provided_by="adapter/tau_compiler.py",
        lost_if_disabled=(
            "Inconsistent rules are admitted and surface only at runtime, "
            "when a payment inexplicably cannot be decided either way."
        ),
        active=True,
        evidence=_safe_evidence(fragment="v1"),
    ))

    out.append(Guarantee(
        id="G-DEC-02",
        category="decidability",
        summary="Bounded-horizon fragment v2 (z3) consistency check.",
        provided_by="adapter/z3_compiler.py",
        lost_if_disabled=(
            "Temporal rule conflicts (rolling windows, rate limits, "
            "per-window caps) go undetected until they fire in production."
        ),
        active=z3_wired,
        evidence=_safe_evidence(z3_prover_wired=z3_wired),
        inactive_reason=(
            "" if z3_wired else "z3 prover not wired in this daemon"
        ),
    ))

    out.append(Guarantee(
        id="G-DEC-03",
        category="decidability",
        summary="Cross-fragment hybrid verdict.",
        provided_by="adapter/hybrid_prover.py",
        lost_if_disabled=(
            "v1/v2 boundary contradictions are invisible. A rule set that "
            "is SAT in v1 alone and SAT in v2 alone can still be UNSAT "
            "when composed, and only the hybrid prover catches that."
        ),
        active=hybrid_wired,
        evidence=_safe_evidence(hybrid_prover_wired=hybrid_wired),
        inactive_reason=(
            "" if hybrid_wired else "HybridProver not wired in this daemon"
        ),
    ))

    # ── temporal ────────────────────────────────────────────────────────

    retry_active = "RetryRateLimit" in invariant_classes
    out.append(Guarantee(
        id="G-TMP-01",
        category="temporal",
        summary="RetryRateLimit enforcement live (past-LTL O).",
        provided_by="adapter/invariants.py::RetryRateLimit",
        lost_if_disabled=(
            "Flooding attacks. An agent that retries after a reject can "
            "exhaust the provider's rate budget because nothing observes "
            "the history of recent attempts."
        ),
        active=retry_active,
        evidence=_safe_evidence(
            active_invariants=sorted(invariant_classes),
        ),
        inactive_reason=(
            "" if retry_active
            else "no RetryRateLimit declared in the active registry"
        ),
    ))

    window_active = "RollingWindowCap" in invariant_classes
    out.append(Guarantee(
        id="G-TMP-02",
        category="temporal",
        summary="RollingWindowCap enforcement live.",
        provided_by="adapter/invariants.py::RollingWindowCap",
        lost_if_disabled=(
            "An agent can overspend within a sliding time window because "
            "nothing aggregates recent payments against a ceiling."
        ),
        active=window_active,
        evidence=_safe_evidence(
            active_invariants=sorted(invariant_classes),
        ),
        inactive_reason=(
            "" if window_active
            else "no RollingWindowCap declared in the active registry"
        ),
    ))

    instability_active = "InstabilityGuard" in invariant_classes
    out.append(Guarantee(
        id="G-TMP-03",
        category="temporal",
        summary="InstabilityGuard self-referential tightening live.",
        provided_by="adapter/self_ref_policy.py::InstabilityGuard",
        lost_if_disabled=(
            "A provider that starts rejecting your traffic keeps receiving "
            "full-amount attempts. The cage cannot tighten caps in response "
            "to its own recent rejects."
        ),
        active=instability_active,
        evidence=_safe_evidence(
            active_invariants=sorted(invariant_classes),
        ),
        inactive_reason=(
            "" if instability_active
            else "no InstabilityGuard declared in the active registry"
        ),
    ))

    # ── governance ──────────────────────────────────────────────────────

    two_person_active = (
        approval_queue_configured
        and require_human_approval
        and min_reviewers >= 2
    )
    two_person_reason = ""
    if not two_person_active:
        if not approval_queue_configured:
            two_person_reason = "approval queue not configured"
        elif not require_human_approval:
            two_person_reason = "require_human_approval=False"
        elif min_reviewers < 2:
            two_person_reason = (
                f"mutation_governance.min_reviewers={min_reviewers}, need >= 2"
            )
    out.append(Guarantee(
        id="G-GOV-01",
        category="governance",
        summary="Two-person integrity on sensitive mutations.",
        provided_by="adapter/mutation_governance.py",
        lost_if_disabled=(
            "A single compromised operator account can rewrite policy "
            "unilaterally. No second reviewer blocks a bad mutation."
        ),
        active=two_person_active,
        evidence=_safe_evidence(
            approval_queue_configured=approval_queue_configured,
            require_human_approval=require_human_approval,
            min_reviewers=min_reviewers,
        ),
        inactive_reason=two_person_reason,
    ))

    no_weakening_active = "NoWeakening" in cross_rules
    out.append(Guarantee(
        id="G-GOV-02",
        category="governance",
        summary="Cross-revision non-weakening enforced.",
        provided_by="adapter/cross_revision.py",
        lost_if_disabled=(
            "A new revision can silently relax a prior rule (raising a "
            "cap, broadening an allowlist) without any process flag. "
            "Policy drift is invisible."
        ),
        active=no_weakening_active,
        evidence=_safe_evidence(cross_revision_rules=list(cross_rules)),
        inactive_reason=(
            "" if no_weakening_active
            else "NoWeakening rule not loaded into cross-revision validator"
        ),
    ))

    # ── observability ───────────────────────────────────────────────────

    out.append(Guarantee(
        id="G-OBS-01",
        category="observability",
        summary="Tamper-evident audit log.",
        provided_by="adapter/policy_revision.py::RevisionLog",
        lost_if_disabled=(
            "Silent history rewrite is possible. An attacker with disk "
            "access can edit the revision log and leave no trace."
        ),
        active=True,
        evidence=_safe_evidence(available=True),
    ))

    out.append(Guarantee(
        id="G-OBS-02",
        category="observability",
        summary="Safety comparison counterfactual on every verdict.",
        provided_by="adapter/safety_comparison.py",
        lost_if_disabled=(
            "No 'without-cage' comparison. Operators cannot show, per "
            "verdict, what would have spent if the cage were off."
        ),
        active=True,
        evidence=_safe_evidence(
            reject_history_length=reject_count,
            active_invariant_count=active_invariant_count,
        ),
    ))

    metrics_active = metrics_extra_installed and metrics_token
    metrics_reason = ""
    if not metrics_active:
        if not metrics_extra_installed:
            metrics_reason = "prometheus_client extra not installed"
        elif not metrics_token:
            metrics_reason = "TAU_X402_METRICS_TOKEN unset"
    out.append(Guarantee(
        id="G-OBS-03",
        category="observability",
        summary="Prometheus /metrics endpoint.",
        provided_by="saas/metrics_route.py",
        lost_if_disabled=(
            "No real-time scraping. Alerting on reject spikes, prover "
            "latency, or queue depth depends on log tailing."
        ),
        active=metrics_active,
        evidence=_safe_evidence(
            metrics_extra_installed=metrics_extra_installed,
            metrics_token_configured=metrics_token,
        ),
        inactive_reason=metrics_reason,
    ))

    # Stable sort: category order, then id order.
    category_rank = {c: i for i, c in enumerate(_CATEGORIES)}
    out.sort(key=lambda g: (category_rank.get(g.category, 99), g.id))
    return out


def split_by_status(
    guarantees: Sequence[Guarantee],
) -> tuple[List[Guarantee], List[Guarantee]]:
    """Partition a list into (active, inactive). Stable order preserved."""
    active = [g for g in guarantees if g.active]
    inactive = [g for g in guarantees if not g.active]
    return active, inactive


__all__ = [
    "Guarantee",
    "GuaranteeCategory",
    "enumerate_guarantees",
    "split_by_status",
]
