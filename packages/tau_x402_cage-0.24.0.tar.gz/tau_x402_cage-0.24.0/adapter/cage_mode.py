"""Cage mode: enforce / shadow / advisory.

v0.13.0 introduces three daemon-level operating modes so an operator can
deploy the cage in a production request flow without it blocking anything
while they build confidence:

* ``enforce`` (default, pre-v0.13.0 behaviour) — rejecting intents produce a
  ``reject`` verdict on the wire (HTTP 403 via the mediator). This is the
  only mode that ever returns a negative outcome to the caller.
* ``shadow`` — every ``check_payment`` runs the full admission pipeline
  normally; the verdict is computed; but the wire response is ALWAYS a
  ``permit`` envelope. When the would-be verdict is reject, we tag it on
  the signed envelope (``shadow_would_reject=true``, ``rule_id`` + reason
  preserved in dedicated fields) and on a dedicated metrics counter. The
  intent behind shadow is: "drop it into production, don't interrupt
  traffic, read the summary tomorrow, then decide."
* ``advisory`` — identical wire behaviour to shadow, but the metric and
  log line use the ``advisory_would_reject`` surface so a deployment can
  run advisory permanently alongside enforce to catch drift. Example: an
  operator running in enforce mode gates a new rule in advisory first so
  they see its effect on live traffic without risking a wrong reject.

Mode selection propagates to three places:

1. The signed v2 envelope: ``mode`` is part of the canonical MAC input so
   an auditor can prove cryptographically that a given verdict was
   issued in a specific mode. Tampering with the ``mode`` field breaks
   verify(). This is the load-bearing property: without MAC binding, an
   attacker could replay a "permit in shadow mode" envelope as a
   "permit in enforce mode" and claim the system approved a transfer.
2. The HTTP response: ``X-Policy-Mode`` header on every response so an
   observer without a signed-envelope parser still sees the mode.
3. The Prometheus surface: separate shadow / advisory counters so
   dashboards differentiate "would have rejected" from actually-rejected
   admissions.

The trust model: mode is a DAEMON-level decision. Per-tenant mode is out
of scope here; an operator wanting shadow for some tenants and enforce
for others should run two daemons with different env vars.
"""
from __future__ import annotations

from enum import Enum
from typing import Optional


class CageMode(str, Enum):
    """Wire-stable identifier for the daemon's operating mode.

    Inheriting from ``str`` so the enum value serialises transparently to
    JSON (``"enforce"``, ``"shadow"``, ``"advisory"``) and is safe inside
    the canonical MAC input (the signer treats it as a plain string).
    Adding a mode means bumping the enum here + the metric set in
    ``adapter/metrics.py`` + covering it in tests; the enum is
    deliberately not open-ended.
    """

    ENFORCE = "enforce"
    SHADOW = "shadow"
    ADVISORY = "advisory"


#: Default mode when nothing is configured. Matches pre-v0.13.0 behaviour
#: so an upgrade is a no-op for existing deployments.
DEFAULT_MODE: CageMode = CageMode.ENFORCE


def parse_mode(value: Optional[str]) -> CageMode:
    """Normalise a config string (env var / CLI flag / policy field) to CageMode.

    Empty / None resolves to :data:`DEFAULT_MODE`. Unknown values raise
    ``ValueError`` with a message listing the supported options so the
    CLI can surface it verbatim. We reject unknown modes loudly because a
    typo (e.g. ``TAU_CAGE_MODE=shaddow``) would otherwise silently run in
    enforce and the operator would think they were in shadow.
    """
    if value is None or value == "":
        return DEFAULT_MODE
    normalised = str(value).strip().lower()
    for mode in CageMode:
        if mode.value == normalised:
            return mode
    valid = ", ".join(m.value for m in CageMode)
    raise ValueError(
        f"unknown cage mode {value!r}; expected one of: {valid}"
    )


def is_non_enforcing(mode: CageMode) -> bool:
    """True iff this mode never returns a reject to the wire.

    Shadow and advisory both short-circuit reject verdicts into permit
    envelopes (tagged). ``enforce`` is the only mode that returns a real
    reject. The distinction between shadow and advisory is observability
    only — both permit on the wire.
    """
    return mode in (CageMode.SHADOW, CageMode.ADVISORY)
