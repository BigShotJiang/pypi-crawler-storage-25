"""Cross-revision compositional invariants (v0.14.0).

A ``CrossRevisionInvariant`` is a rule *about rules across time*. Where a
normal :class:`adapter.invariants.Invariant` asks "is this current payment
admissible under the current policy?", a ``CrossRevisionInvariant`` asks
"is this *transition* from policy revision N to revision N+1 admissible?"

The three shipped types cover the compositional claims the safety-layer
spec calls out:

  * :class:`NoWeakening` — a production branch cannot weaken monitored
    limits. Each monitored invariant class in ``new_revision`` must be at
    least as strict as the corresponding instance in ``old_revision``.
  * :class:`OverridesMustExpire` — short-lived overrides (tagged
    ``override=True`` via an ``affected_scope["overrides"]`` marker) must
    carry an ``expires_at_unix`` within ``now + max_ttl_seconds``.
  * :class:`BranchRespectsCore` — when merging into a core branch, a
    merge commit must not remove any invariant of protected classes that
    are present in the core branch's current head.

Each invariant reports structured violations via ``ValidationResult`` so
the daemon can surface them in its rejection envelope with the category
``"cross_revision_violation"``. Composition is by list-container
(:class:`CrossRevisionValidator`) rather than by subclassing so operators
can mix shipped types with their own bespoke rules without touching this
file.

Integration points
  * :meth:`adapter.policy_revision.RevisionLog.append` accepts an optional
    validator and refuses to persist a revision whose transition would
    violate it.
  * :meth:`adapter.policy_revision.RevisionLog.merge_branch` runs the
    same check against the fabricated merge commit so three-way merges
    also respect the compositional rules.
  * ``CageDaemon.__init__`` wires an optional validator through env-var
    defaults (``TAU_CAGE_CROSS_REVISION_NO_WEAKENING`` etc.).
  * ``tau-x402-cage cross-revision --candidate policy.yaml`` dry-runs a
    candidate against the daemon's active revision for CI gating.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from typing import TYPE_CHECKING, Any, Dict, FrozenSet, List, Optional, Sequence, Tuple

from adapter.invariants import (
    AdaptiveTighteningPolicy,
    BurstVelocityCap,
    MaxPerCall,
    PeerAuthenticationPolicy,
    ProviderAllowlist,
    RetryRateLimit,
    RollingWindowCap,
    SpendingCap,
)

if TYPE_CHECKING:  # pragma: no cover - import-time cycle avoidance
    from adapter.policy_revision import PolicyRevision


# ── result types ─────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class CrossRevisionViolation:
    """A single rejected transition fact.

    Fields:
      invariant_name : human-readable name of the cross-revision invariant
                       that refused the transition (e.g. ``"NoWeakening"``).
      category       : short machine-friendly bucket (e.g.
                       ``"weakened_spending_cap"``). Useful for metrics.
      reason         : prose explanation suitable for a CLI or rejection
                       envelope ``reason`` field.
      old_value      : serialisable summary of the pre-transition instance
                       (``None`` when the old side is vacuous, e.g. when
                       a protected invariant class is freshly removed).
      new_value      : serialisable summary of the post-transition instance
                       (``None`` when the new side is vacuous).
    """

    invariant_name: str
    category: str
    reason: str
    old_value: Optional[Dict[str, Any]] = None
    new_value: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        """JSON-safe dict; stable across minor versions."""
        return {
            "invariant_name": self.invariant_name,
            "category": self.category,
            "reason": self.reason,
            "old_value": dict(self.old_value) if self.old_value is not None else None,
            "new_value": dict(self.new_value) if self.new_value is not None else None,
        }


@dataclass(frozen=True)
class ValidationResult:
    """Aggregate result from :meth:`CrossRevisionValidator.validate`.

    ``valid`` is ``True`` iff ``violations`` is empty; callers can key on
    either. ``violations`` is a ``tuple`` so the result is hashable and
    safe to stash in caches or revision metadata.
    """

    valid: bool
    violations: Tuple[CrossRevisionViolation, ...] = ()

    def to_dict(self) -> Dict[str, Any]:
        return {
            "valid": self.valid,
            "violations": [v.to_dict() for v in self.violations],
        }


# ── abstract base ────────────────────────────────────────────────────────────


class CrossRevisionInvariant:
    """Abstract base: validate one transition ``(old, new, branch)``.

    Subclasses implement :meth:`validate_transition`. Keep subclasses
    side-effect free; the validator may call them speculatively (dry-run
    CLI, pre-admission check, post-append replay) and any mutation would
    poison those paths.
    """

    # Human-readable name surfaced on violations. Subclasses override.
    name: str = "CrossRevisionInvariant"

    def validate_transition(
        self,
        old_revision: Optional["PolicyRevision"],
        new_revision: "PolicyRevision",
        branch: str,
    ) -> Tuple[CrossRevisionViolation, ...]:
        """Return tuple of violations; empty iff the transition is clean."""
        raise NotImplementedError


# ── helpers: keying invariants by (class, scope) so we can compare ───────────


def _spending_cap_scope_key(inv: SpendingCap) -> Tuple[str, Any, Any]:
    """Scope key for :class:`SpendingCap`.

    Caps with different scope shapes are not directly comparable (you
    can't strengthen a global ``per_window`` cap by replacing it with a
    provider-scoped cap and vice versa). We key on
    ``(currency, scope, provider)``; the strictness comparison then only
    runs between caps with an identical scope key.
    """
    return (inv.currency, inv.scope, inv.provider)


def _invariants_by_class(
    invariants: Sequence[Any],
) -> Dict[str, List[Any]]:
    """Group a revision's invariants by runtime class name.

    Returns a ``dict`` mapping e.g. ``"SpendingCap"`` -> list of caps.
    Duplicate instances collapse to the same list entry; callers decide
    how to dedupe.
    """
    out: Dict[str, List[Any]] = {}
    for inv in invariants:
        out.setdefault(type(inv).__name__, []).append(inv)
    return out


# ── NoWeakening ──────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class NoWeakening(CrossRevisionInvariant):
    """Production branch cannot weaken monitored limits.

    "Strengthening" means making the rule reject strictly more payments.
    For each monitored class we match old-vs-new instances by their
    comparison key and check that the new value is at least as strict:

      * :class:`SpendingCap` — lower ``max_amount`` is stricter. Scoped by
        ``(currency, scope, provider)`` so cross-scope replacements are
        reported as "removed old scope / added new scope" instead of
        silently accepted.
      * :class:`MaxPerCall` — lower ``max_amount`` is stricter, keyed by
        currency.
      * :class:`ProviderAllowlist` — shrinking the provider set is
        stricter. The new set must be a subset of the old set.

    Transitions that introduce a new instance with no predecessor are
    allowed (they can only tighten). Transitions that remove a monitored
    instance entirely are reported as a weakening (implicit loosening:
    the rule no longer constrains anything).

    Only runs when ``branch == monitored_branch`` (default ``"main"``).
    Feature branches aren't production so they can relax caps freely
    during development; the check re-fires when the branch merges back
    into ``main``.
    """

    monitored_classes: FrozenSet[str] = field(
        default_factory=lambda: frozenset({
            "SpendingCap",
            "MaxPerCall",
            "ProviderAllowlist",
            # v1.1.0 — past-LTL + windowed rule classes. Weakening any of
            # these is a loosening transition that NoWeakening must
            # refuse on a monitored branch without an approval token.
            "RetryRateLimit",
            "RollingWindowCap",
            "BurstVelocityCap",
            # v1.2.0 (v0.22.0) — meta-policies. Weakening a meta-policy
            # means: (a) raising any AdaptiveTighteningPolicy threshold
            # (less-frequent triggering = less tightening); (b) adding a
            # uid to PeerAuthenticationPolicy.allowed_peer_uids (more
            # peers may mutate). Removing / lowering is tightening.
            "AdaptiveTighteningPolicy",
            "PeerAuthenticationPolicy",
        })
    )
    monitored_branch: str = "main"

    name: str = field(default="NoWeakening", init=False, repr=False)

    def __post_init__(self) -> None:
        if not isinstance(self.monitored_classes, frozenset):
            # Normalise eagerly; a tuple passed by a CLI caller would
            # make later set operations behave differently.
            object.__setattr__(
                self, "monitored_classes", frozenset(self.monitored_classes),
            )

    # ── public entry point ────────────────────────────────────────────────

    def validate_transition(
        self,
        old_revision: Optional["PolicyRevision"],
        new_revision: "PolicyRevision",
        branch: str,
    ) -> Tuple[CrossRevisionViolation, ...]:
        if branch != self.monitored_branch:
            return ()
        if old_revision is None:
            # Genesis on the monitored branch: nothing to weaken.
            return ()

        old_by_class = _invariants_by_class(old_revision.invariants)
        new_by_class = _invariants_by_class(new_revision.invariants)

        violations: List[CrossRevisionViolation] = []
        for cls_name in sorted(self.monitored_classes):
            old_instances = old_by_class.get(cls_name, [])
            new_instances = new_by_class.get(cls_name, [])
            if cls_name == "SpendingCap":
                violations.extend(
                    self._check_spending_caps(old_instances, new_instances)
                )
            elif cls_name == "MaxPerCall":
                violations.extend(
                    self._check_max_per_calls(old_instances, new_instances)
                )
            elif cls_name == "ProviderAllowlist":
                violations.extend(
                    self._check_provider_allowlists(old_instances, new_instances)
                )
            elif cls_name == "RetryRateLimit":
                violations.extend(
                    self._check_retry_rate_limits(old_instances, new_instances)
                )
            elif cls_name == "RollingWindowCap":
                violations.extend(
                    self._check_rolling_window_caps(old_instances, new_instances)
                )
            elif cls_name == "BurstVelocityCap":
                violations.extend(
                    self._check_burst_velocity_caps(old_instances, new_instances)
                )
            elif cls_name == "AdaptiveTighteningPolicy":
                violations.extend(
                    self._check_adaptive_tightening_policies(
                        old_instances, new_instances,
                    )
                )
            elif cls_name == "PeerAuthenticationPolicy":
                violations.extend(
                    self._check_peer_authentication_policies(
                        old_instances, new_instances,
                    )
                )
            # Unknown monitored class names are ignored silently; callers
            # can only register classes we know how to compare, but we
            # don't raise because that would block a forward-compat op.
        return tuple(violations)

    # ── per-class comparators ─────────────────────────────────────────────

    def _check_spending_caps(
        self,
        old: Sequence[SpendingCap],
        new: Sequence[SpendingCap],
    ) -> List[CrossRevisionViolation]:
        violations: List[CrossRevisionViolation] = []
        old_by_scope: Dict[Tuple[Any, ...], SpendingCap] = {
            _spending_cap_scope_key(c): c for c in old
        }
        new_by_scope: Dict[Tuple[Any, ...], SpendingCap] = {
            _spending_cap_scope_key(c): c for c in new
        }
        for key, old_cap in old_by_scope.items():
            new_cap = new_by_scope.get(key)
            if new_cap is None:
                violations.append(CrossRevisionViolation(
                    invariant_name=self.name,
                    category="removed_spending_cap",
                    reason=(
                        f"SpendingCap(scope={old_cap.scope}, currency={old_cap.currency}"
                        + (f", provider={old_cap.provider}" if old_cap.provider else "")
                        + f", max={old_cap.max_amount}) removed on monitored branch; "
                        "production may not drop a cap (implicit loosening)."
                    ),
                    old_value=_serialize_spending_cap(old_cap),
                    new_value=None,
                ))
                continue
            # Same scope key; compare strictness.
            if new_cap.max_amount > old_cap.max_amount:
                violations.append(CrossRevisionViolation(
                    invariant_name=self.name,
                    category="weakened_spending_cap",
                    reason=(
                        f"SpendingCap({old_cap.scope}, {old_cap.currency}"
                        + (f", {old_cap.provider}" if old_cap.provider else "")
                        + f") weakened: max_amount {old_cap.max_amount} -> "
                        f"{new_cap.max_amount} on branch {self.monitored_branch!r}."
                    ),
                    old_value=_serialize_spending_cap(old_cap),
                    new_value=_serialize_spending_cap(new_cap),
                ))
        # New caps with no old-side match are allowed (can only tighten).
        return violations

    def _check_max_per_calls(
        self,
        old: Sequence[MaxPerCall],
        new: Sequence[MaxPerCall],
    ) -> List[CrossRevisionViolation]:
        violations: List[CrossRevisionViolation] = []
        old_by_ccy: Dict[str, MaxPerCall] = {c.currency: c for c in old}
        new_by_ccy: Dict[str, MaxPerCall] = {c.currency: c for c in new}
        for ccy, old_cap in old_by_ccy.items():
            new_cap = new_by_ccy.get(ccy)
            if new_cap is None:
                violations.append(CrossRevisionViolation(
                    invariant_name=self.name,
                    category="removed_max_per_call",
                    reason=(
                        f"MaxPerCall({old_cap.max_amount} {ccy}) removed on "
                        f"branch {self.monitored_branch!r}; production may not "
                        "drop a single-call cap."
                    ),
                    old_value=_serialize_max_per_call(old_cap),
                    new_value=None,
                ))
                continue
            if new_cap.max_amount > old_cap.max_amount:
                violations.append(CrossRevisionViolation(
                    invariant_name=self.name,
                    category="weakened_max_per_call",
                    reason=(
                        f"MaxPerCall({ccy}) weakened: max_amount "
                        f"{old_cap.max_amount} -> {new_cap.max_amount}."
                    ),
                    old_value=_serialize_max_per_call(old_cap),
                    new_value=_serialize_max_per_call(new_cap),
                ))
        return violations

    def _check_provider_allowlists(
        self,
        old: Sequence[ProviderAllowlist],
        new: Sequence[ProviderAllowlist],
    ) -> List[CrossRevisionViolation]:
        violations: List[CrossRevisionViolation] = []
        if not old:
            return violations
        if not new:
            # All allowlists removed: the post-transition state allows
            # every provider — strictly weaker.
            for old_list in old:
                violations.append(CrossRevisionViolation(
                    invariant_name=self.name,
                    category="removed_provider_allowlist",
                    reason=(
                        f"ProviderAllowlist({sorted(old_list.providers)}) removed; "
                        "post-transition every provider would be permitted."
                    ),
                    old_value=_serialize_provider_allowlist(old_list),
                    new_value=None,
                ))
            return violations
        old_union: FrozenSet[str] = frozenset().union(*(a.providers for a in old))
        new_union: FrozenSet[str] = frozenset().union(*(a.providers for a in new))
        added = new_union - old_union
        if added:
            violations.append(CrossRevisionViolation(
                invariant_name=self.name,
                category="weakened_provider_allowlist",
                reason=(
                    f"ProviderAllowlist widened on branch {self.monitored_branch!r}: "
                    f"added {sorted(added)}."
                ),
                old_value={"providers": sorted(old_union)},
                new_value={"providers": sorted(new_union)},
            ))
        return violations

    # ── v1.1.0 comparators ────────────────────────────────────────────────

    def _check_retry_rate_limits(
        self,
        old: Sequence[RetryRateLimit],
        new: Sequence[RetryRateLimit],
    ) -> List[CrossRevisionViolation]:
        """Strictness for RetryRateLimit: larger ``min_gap_seconds`` is stricter.

        Lowering the gap lets retries happen sooner after a reject, which
        weakens the rate limit. Removing the rule entirely is a weakening
        too (retries become unrestricted). Keying is trivial — there is
        one RetryRateLimit per rule set by convention; if multiple are
        declared we compare against the smallest old-side gap (most
        permissive) to avoid false positives from parallel-cap sets.
        """
        violations: List[CrossRevisionViolation] = []
        if not old:
            return violations
        if not new:
            for old_rule in old:
                violations.append(CrossRevisionViolation(
                    invariant_name=self.name,
                    category="removed_retry_rate_limit",
                    reason=(
                        f"RetryRateLimit(min_gap_seconds={old_rule.min_gap_seconds}) "
                        "removed; post-transition retries are unrestricted."
                    ),
                    old_value={"min_gap_seconds": old_rule.min_gap_seconds},
                    new_value=None,
                ))
            return violations
        old_max = max(r.min_gap_seconds for r in old)
        new_max = max(r.min_gap_seconds for r in new)
        if new_max < old_max:
            violations.append(CrossRevisionViolation(
                invariant_name=self.name,
                category="weakened_retry_rate_limit",
                reason=(
                    f"RetryRateLimit weakened on branch {self.monitored_branch!r}: "
                    f"max min_gap_seconds {old_max} -> {new_max}."
                ),
                old_value={"min_gap_seconds": old_max},
                new_value={"min_gap_seconds": new_max},
            ))
        return violations

    def _check_rolling_window_caps(
        self,
        old: Sequence[RollingWindowCap],
        new: Sequence[RollingWindowCap],
    ) -> List[CrossRevisionViolation]:
        """Strictness for RollingWindowCap: lower ``max_count`` is stricter.

        Keyed by ``group_by`` so per-provider and global caps are
        compared independently. For the same group_by, a larger
        ``max_count`` is weaker. Shortening the window with the same
        ``max_count`` also weakens (shorter window = fewer events
        contribute, so the cap binds less often). Adding a new key is
        allowed (strictly tightens); removing one is a weakening.
        """
        violations: List[CrossRevisionViolation] = []
        old_by_key: Dict[str, RollingWindowCap] = {c.group_by: c for c in old}
        new_by_key: Dict[str, RollingWindowCap] = {c.group_by: c for c in new}
        for key, old_cap in old_by_key.items():
            new_cap = new_by_key.get(key)
            if new_cap is None:
                violations.append(CrossRevisionViolation(
                    invariant_name=self.name,
                    category="removed_rolling_window_cap",
                    reason=(
                        f"RollingWindowCap(group_by={key}, "
                        f"max_count={old_cap.max_count}) removed; "
                        "production may not drop a rolling-window cap."
                    ),
                    old_value={
                        "group_by": key,
                        "max_count": old_cap.max_count,
                        "window_seconds": old_cap.window_seconds,
                    },
                    new_value=None,
                ))
                continue
            if new_cap.max_count > old_cap.max_count:
                violations.append(CrossRevisionViolation(
                    invariant_name=self.name,
                    category="weakened_rolling_window_cap",
                    reason=(
                        f"RollingWindowCap(group_by={key}) weakened: "
                        f"max_count {old_cap.max_count} -> {new_cap.max_count}."
                    ),
                    old_value={
                        "group_by": key,
                        "max_count": old_cap.max_count,
                    },
                    new_value={
                        "group_by": key,
                        "max_count": new_cap.max_count,
                    },
                ))
            elif new_cap.window_seconds < old_cap.window_seconds:
                violations.append(CrossRevisionViolation(
                    invariant_name=self.name,
                    category="weakened_rolling_window_cap",
                    reason=(
                        f"RollingWindowCap(group_by={key}) weakened: "
                        f"window_seconds {old_cap.window_seconds} -> "
                        f"{new_cap.window_seconds} (shorter window reduces "
                        "the aggregate's bindingness)."
                    ),
                    old_value={
                        "group_by": key,
                        "window_seconds": old_cap.window_seconds,
                    },
                    new_value={
                        "group_by": key,
                        "window_seconds": new_cap.window_seconds,
                    },
                ))
        return violations

    def _check_burst_velocity_caps(
        self,
        old: Sequence[BurstVelocityCap],
        new: Sequence[BurstVelocityCap],
    ) -> List[CrossRevisionViolation]:
        """Strictness for BurstVelocityCap: lower ``max_per_window`` is stricter.

        Keyed by ``(currency, cross_provider)``: cross-provider vs
        per-provider are distinct enforcement surfaces, so we don't
        collapse them. For same key, a higher ``max_per_window`` is
        weaker; shortening the window is also weaker.
        """
        violations: List[CrossRevisionViolation] = []
        old_by_key: Dict[Tuple[str, bool], BurstVelocityCap] = {
            (c.currency, c.cross_provider): c for c in old
        }
        new_by_key: Dict[Tuple[str, bool], BurstVelocityCap] = {
            (c.currency, c.cross_provider): c for c in new
        }
        for key, old_cap in old_by_key.items():
            new_cap = new_by_key.get(key)
            if new_cap is None:
                violations.append(CrossRevisionViolation(
                    invariant_name=self.name,
                    category="removed_burst_velocity_cap",
                    reason=(
                        f"BurstVelocityCap(currency={key[0]}, "
                        f"cross_provider={key[1]}, "
                        f"max_per_window={old_cap.max_per_window}) removed."
                    ),
                    old_value={
                        "currency": key[0],
                        "cross_provider": key[1],
                        "max_per_window": str(old_cap.max_per_window),
                        "window_seconds": old_cap.window_seconds,
                    },
                    new_value=None,
                ))
                continue
            if new_cap.max_per_window > old_cap.max_per_window:
                violations.append(CrossRevisionViolation(
                    invariant_name=self.name,
                    category="weakened_burst_velocity_cap",
                    reason=(
                        f"BurstVelocityCap({key[0]}, "
                        f"cross_provider={key[1]}) weakened: max_per_window "
                        f"{old_cap.max_per_window} -> {new_cap.max_per_window}."
                    ),
                    old_value={
                        "max_per_window": str(old_cap.max_per_window),
                    },
                    new_value={
                        "max_per_window": str(new_cap.max_per_window),
                    },
                ))
            elif new_cap.window_seconds < old_cap.window_seconds:
                violations.append(CrossRevisionViolation(
                    invariant_name=self.name,
                    category="weakened_burst_velocity_cap",
                    reason=(
                        f"BurstVelocityCap({key[0]}, "
                        f"cross_provider={key[1]}) weakened: window_seconds "
                        f"{old_cap.window_seconds} -> {new_cap.window_seconds}."
                    ),
                    old_value={"window_seconds": old_cap.window_seconds},
                    new_value={"window_seconds": new_cap.window_seconds},
                ))
        return violations

    # ── v1.2.0 meta-policy comparators ────────────────────────────────────

    def _check_adaptive_tightening_policies(
        self,
        old: Sequence[AdaptiveTighteningPolicy],
        new: Sequence[AdaptiveTighteningPolicy],
    ) -> List[CrossRevisionViolation]:
        """Weakening semantics for ``AdaptiveTighteningPolicy``.

        A tightening policy is STRICTER when it fires more aggressively.
        Lowering any trigger threshold = stricter (trigger fires on
        smaller deviations). Raising any trigger threshold = weaker.
        Larger per-trigger deltas = stricter (level climbs faster toward
        saturation). Smaller deltas = weaker.

        We also treat ``half_life_seconds`` asymmetrically: LONGER
        half-life means level stays elevated longer = stricter;
        SHORTER half-life = weaker.

        Only one AdaptiveTighteningPolicy is expected per revision by
        convention; if multiple are present we compare the first old to
        the first new (same ordering) and ignore extras. Removing the
        policy entirely is weakening.
        """
        violations: List[CrossRevisionViolation] = []
        if not old:
            # Introducing a new meta-policy where none was before is a
            # tightening transition (the cage now observes a parameter
            # set where it previously ran at defaults).
            return violations
        if not new:
            old_policy = old[0]
            violations.append(CrossRevisionViolation(
                invariant_name=self.name,
                category="removed_adaptive_tightening_policy",
                reason=(
                    "AdaptiveTighteningPolicy removed on branch "
                    f"{self.monitored_branch!r}; the cage would revert to "
                    "default tightening parameters which may be weaker."
                ),
                old_value=_serialize_adaptive_policy(old_policy),
                new_value=None,
            ))
            return violations
        old_p, new_p = old[0], new[0]

        # Thresholds: lower is stricter → a RAISE (new > old) is weakening.
        threshold_fields = (
            ("retry_density_per_min_threshold", "retry density"),
            ("denial_rate_threshold", "denial rate"),
            ("velocity_multiplier_threshold", "velocity multiplier"),
            ("identical_count_threshold", "identical count"),
        )
        for attr, label in threshold_fields:
            old_v = getattr(old_p, attr)
            new_v = getattr(new_p, attr)
            if new_v > old_v:
                violations.append(CrossRevisionViolation(
                    invariant_name=self.name,
                    category="weakened_adaptive_tightening_threshold",
                    reason=(
                        f"AdaptiveTighteningPolicy weakened on branch "
                        f"{self.monitored_branch!r}: {label} threshold "
                        f"{old_v} -> {new_v} (higher = fires less often)."
                    ),
                    old_value={attr: str(old_v)},
                    new_value={attr: str(new_v)},
                ))

        # half_life_seconds: longer is stricter (level stays elevated
        # longer). A DECREASE is weakening.
        if new_p.half_life_seconds < old_p.half_life_seconds:
            violations.append(CrossRevisionViolation(
                invariant_name=self.name,
                category="weakened_adaptive_tightening_half_life",
                reason=(
                    f"AdaptiveTighteningPolicy weakened: half_life_seconds "
                    f"{old_p.half_life_seconds} -> {new_p.half_life_seconds} "
                    "(shorter half-life = tightening decays faster)."
                ),
                old_value={"half_life_seconds": old_p.half_life_seconds},
                new_value={"half_life_seconds": new_p.half_life_seconds},
            ))

        # per_trigger_deltas: smaller deltas = weaker tightening response.
        # Reducing any known trigger's delta (without removing the key) is
        # weakening. Adding a new trigger-key is tightening (more triggers
        # fire); removing one is weakening (that trigger stops clamping).
        old_deltas = dict(old_p.per_trigger_deltas)
        new_deltas = dict(new_p.per_trigger_deltas)
        for trig, old_delta in old_deltas.items():
            if trig not in new_deltas:
                violations.append(CrossRevisionViolation(
                    invariant_name=self.name,
                    category="weakened_adaptive_tightening_delta",
                    reason=(
                        f"AdaptiveTighteningPolicy weakened: per-trigger "
                        f"delta {trig!r} removed (trigger no longer clamps)."
                    ),
                    old_value={trig: str(old_delta)},
                    new_value=None,
                ))
                continue
            new_delta = new_deltas[trig]
            if new_delta < old_delta:
                violations.append(CrossRevisionViolation(
                    invariant_name=self.name,
                    category="weakened_adaptive_tightening_delta",
                    reason=(
                        f"AdaptiveTighteningPolicy weakened: per-trigger "
                        f"delta {trig!r} lowered {old_delta} -> {new_delta} "
                        "(smaller step toward saturation)."
                    ),
                    old_value={trig: str(old_delta)},
                    new_value={trig: str(new_delta)},
                ))
        return violations

    def _check_peer_authentication_policies(
        self,
        old: Sequence[PeerAuthenticationPolicy],
        new: Sequence[PeerAuthenticationPolicy],
    ) -> List[CrossRevisionViolation]:
        """Weakening semantics for ``PeerAuthenticationPolicy``.

        ADDING a uid / actor-claim / signing-key to an allowed set =
        MORE peers can mutate = WEAKENING. Requires an approval token.

        REMOVING from any allowed set = FEWER peers can mutate =
        TIGHTENING. Passes freely.

        Flipping ``require_peer_uid`` from True to False or
        ``require_signed_actor_claim`` from True to False are also
        weakening (relaxing an auth requirement).
        """
        violations: List[CrossRevisionViolation] = []
        if not old:
            return violations
        if not new:
            old_policy = old[0]
            violations.append(CrossRevisionViolation(
                invariant_name=self.name,
                category="removed_peer_authentication_policy",
                reason=(
                    "PeerAuthenticationPolicy removed on branch "
                    f"{self.monitored_branch!r}; daemon would accept "
                    "mutations from any peer. Strictly weaker."
                ),
                old_value=_serialize_peer_auth_policy(old_policy),
                new_value=None,
            ))
            return violations
        old_p, new_p = old[0], new[0]

        added_uids = new_p.allowed_peer_uids - old_p.allowed_peer_uids
        if added_uids:
            violations.append(CrossRevisionViolation(
                invariant_name=self.name,
                category="weakened_peer_authentication_uids",
                reason=(
                    f"PeerAuthenticationPolicy widened on branch "
                    f"{self.monitored_branch!r}: added peer uids "
                    f"{sorted(added_uids)}."
                ),
                old_value={
                    "allowed_peer_uids": sorted(old_p.allowed_peer_uids),
                },
                new_value={
                    "allowed_peer_uids": sorted(new_p.allowed_peer_uids),
                },
            ))

        added_claims = new_p.allowed_actor_claims - old_p.allowed_actor_claims
        if added_claims:
            violations.append(CrossRevisionViolation(
                invariant_name=self.name,
                category="weakened_peer_authentication_claims",
                reason=(
                    f"PeerAuthenticationPolicy widened: added actor claims "
                    f"{sorted(added_claims)}."
                ),
                old_value={
                    "allowed_actor_claims": sorted(old_p.allowed_actor_claims),
                },
                new_value={
                    "allowed_actor_claims": sorted(new_p.allowed_actor_claims),
                },
            ))

        added_keys = new_p.allowed_signing_keys - old_p.allowed_signing_keys
        if added_keys:
            violations.append(CrossRevisionViolation(
                invariant_name=self.name,
                category="weakened_peer_authentication_keys",
                reason=(
                    f"PeerAuthenticationPolicy widened: added signing keys "
                    f"{sorted(added_keys)}."
                ),
                old_value={
                    "allowed_signing_keys": sorted(old_p.allowed_signing_keys),
                },
                new_value={
                    "allowed_signing_keys": sorted(new_p.allowed_signing_keys),
                },
            ))

        if old_p.require_peer_uid and not new_p.require_peer_uid:
            violations.append(CrossRevisionViolation(
                invariant_name=self.name,
                category="weakened_peer_authentication_require_peer_uid",
                reason=(
                    "PeerAuthenticationPolicy weakened: require_peer_uid "
                    "True -> False (kernel-verified uid no longer required)."
                ),
                old_value={"require_peer_uid": True},
                new_value={"require_peer_uid": False},
            ))
        if (
            old_p.require_signed_actor_claim
            and not new_p.require_signed_actor_claim
        ):
            violations.append(CrossRevisionViolation(
                invariant_name=self.name,
                category="weakened_peer_authentication_require_signed_claim",
                reason=(
                    "PeerAuthenticationPolicy weakened: "
                    "require_signed_actor_claim True -> False."
                ),
                old_value={"require_signed_actor_claim": True},
                new_value={"require_signed_actor_claim": False},
            ))
        return violations


# ── OverridesMustExpire ──────────────────────────────────────────────────────


@dataclass(frozen=True)
class OverridesMustExpire(CrossRevisionInvariant):
    """Temporary overrides must expire within ``max_ttl_seconds``.

    An override is any invariant flagged via the *override marker* in the
    revision's ``affected_scope["overrides"]`` map. The marker is a dict
    keyed by invariant index (the position of the invariant in the
    revision's ``invariants`` tuple) whose value is an object with
    ``expires_at_unix`` (int, epoch seconds).

    The check is:

      * For each override introduced in ``new_revision`` that was not in
        ``old_revision``, require ``expires_at_unix`` to be set AND to
        lie within ``[now, now + max_ttl_seconds]`` (``now`` supplied by
        the caller, defaults to the revision's ``admitted_at_unix``).
      * An invariant without an override marker is not an override and
        is ignored by this rule (so normal new invariants pass through).

    We key overrides by (class_name, repr) so the check survives the
    serialiser round-trip. Removing or shortening an override's TTL in a
    later revision is allowed; extending one past the limit is not
    (that's the "renewed forever" failure mode this rule exists to stop).
    """

    max_ttl_seconds: int

    name: str = field(default="OverridesMustExpire", init=False, repr=False)

    def __post_init__(self) -> None:
        if not isinstance(self.max_ttl_seconds, int) or self.max_ttl_seconds <= 0:
            raise ValueError(
                "OverridesMustExpire.max_ttl_seconds must be a positive int; "
                f"got {self.max_ttl_seconds!r}"
            )

    def validate_transition(
        self,
        old_revision: Optional["PolicyRevision"],
        new_revision: "PolicyRevision",
        branch: str,
    ) -> Tuple[CrossRevisionViolation, ...]:
        overrides_new = self._overrides(new_revision)
        if not overrides_new:
            return ()
        overrides_old = self._overrides(old_revision) if old_revision else {}
        # We validate overrides that are *present* in the new revision:
        # any override currently active must have a bounded expiry. This
        # also catches "renewed forever" flows where an older override is
        # re-declared with a pushed-out expiry.
        now = int(new_revision.admitted_at_unix or 0)
        upper_bound = now + self.max_ttl_seconds
        violations: List[CrossRevisionViolation] = []
        for key, entry in overrides_new.items():
            expires_at = entry.get("expires_at_unix")
            inv_summary = entry.get("inv_summary") or {}
            if expires_at is None:
                violations.append(CrossRevisionViolation(
                    invariant_name=self.name,
                    category="override_missing_expires_at",
                    reason=(
                        f"Override {key[0]}({key[1]}) declared without "
                        f"expires_at_unix; policy requires a bounded TTL of "
                        f"<= {self.max_ttl_seconds}s."
                    ),
                    old_value=overrides_old.get(key),
                    new_value=entry,
                ))
                continue
            try:
                expires_at_int = int(expires_at)
            except (TypeError, ValueError):
                violations.append(CrossRevisionViolation(
                    invariant_name=self.name,
                    category="override_invalid_expires_at",
                    reason=(
                        f"Override {key[0]} has non-integer expires_at_unix "
                        f"{expires_at!r}."
                    ),
                    old_value=overrides_old.get(key),
                    new_value=entry,
                ))
                continue
            if expires_at_int > upper_bound:
                violations.append(CrossRevisionViolation(
                    invariant_name=self.name,
                    category="override_ttl_too_long",
                    reason=(
                        f"Override {key[0]} expires_at_unix={expires_at_int} "
                        f"exceeds limit {upper_bound} "
                        f"(max_ttl_seconds={self.max_ttl_seconds}s from "
                        f"admitted_at_unix={now})."
                    ),
                    old_value=overrides_old.get(key),
                    new_value=entry,
                ))
        return tuple(violations)

    @staticmethod
    def _overrides(
        revision: Optional["PolicyRevision"],
    ) -> Dict[Tuple[str, str], Dict[str, Any]]:
        """Return a map of override-marked invariants on ``revision``.

        Key is ``(class_name, repr)``; value carries the override's
        expiry + a summary of the underlying invariant. Revisions with
        no override metadata return an empty map (the no-op path).
        """
        if revision is None:
            return {}
        scope = getattr(revision, "affected_scope", None) or {}
        overrides_meta = scope.get("overrides") or {}
        invariants = list(revision.invariants)
        out: Dict[Tuple[str, str], Dict[str, Any]] = {}
        if isinstance(overrides_meta, dict):
            # Dict keyed by str(index) -> {"expires_at_unix": int}
            for idx_raw, entry in overrides_meta.items():
                try:
                    idx = int(idx_raw)
                except (TypeError, ValueError):
                    continue
                if idx < 0 or idx >= len(invariants):
                    continue
                if not isinstance(entry, dict):
                    continue
                inv = invariants[idx]
                key = (type(inv).__name__, repr(inv))
                out[key] = {
                    "expires_at_unix": entry.get("expires_at_unix"),
                    "inv_summary": {
                        "class_name": type(inv).__name__,
                        "repr": repr(inv),
                    },
                }
        return out


# ── BranchRespectsCore ───────────────────────────────────────────────────────


#: Canonical "this rule is core-protected" tag. Consumed by
#: :class:`BranchRespectsCore` out of
#: ``affected_scope["overrides"][rule_id]`` tuples.
CORE_PROTECTION_TAG: str = "core"


@dataclass(frozen=True)
class BranchRespectsCore(CrossRevisionInvariant):
    """Merges / feature mutations must not drop core-protected rules.

    v0.22.0 adds a second check surface on top of the class-level
    check already shipped in v0.14.0:

      1. **Class-level (legacy)**: on the merge boundary, every
         protected invariant class present on the pre-merge head must
         still have at least one representative on the merge commit.
         Controlled by ``protected_classes``.

      2. **Rule-level (v0.22.0)**: on ANY feature-branch mutation, a
         rule whose ``affected_scope["overrides"][rule_id]`` contains
         the canonical ``"core"`` protection tag MUST remain carried
         forward — i.e. the new revision's ``overrides`` map must
         still mark the same rule_id with the ``"core"`` tag.

    The rule-level surface is the reason this invariant no longer
    needs a non-empty ``protected_classes`` set: callers who only use
    the rule-level provenance path can pass ``protected_classes=()``
    and still benefit from the check. The class-level surface is
    preserved for callers who haven't migrated their policies to
    rule-level provenance yet.

    Detection of the merge boundary (class-level check):

      * Either ``branch == core_branch_name`` AND the new revision's
        ``merge_parent_ids`` is populated (so this is a three-way merge
        commit landing on core).
      * Or ``new_revision.proof_backend == "three-way-merge"`` regardless
        of branch name, so the check still fires for fast-forward-less
        merges built by :meth:`RevisionLog._build_three_way_merge_revision`.

    The rule-level check fires on ANY transition where the new revision
    is on a non-core branch and the old revision carried a
    core-protected rule_id. Feature branches may not drop the
    ``"core"`` tag on a rule; main-branch transitions are free to
    mutate (the branch owner is the protection constituency).
    """

    core_branch_name: str
    protected_classes: FrozenSet[str] = field(default_factory=frozenset)
    #: Set of protection-class tags that count as "core" for the
    #: rule-level check. Default is the canonical ``{"core"}``; callers
    #: that want stricter fencing (e.g. ``{"core", "audit"}``) override.
    core_protection_tags: FrozenSet[str] = field(
        default_factory=lambda: frozenset({CORE_PROTECTION_TAG})
    )

    name: str = field(default="BranchRespectsCore", init=False, repr=False)

    def __post_init__(self) -> None:
        if not isinstance(self.core_branch_name, str) or not self.core_branch_name:
            raise ValueError(
                "BranchRespectsCore.core_branch_name must be a non-empty string"
            )
        if not isinstance(self.protected_classes, frozenset):
            object.__setattr__(
                self, "protected_classes", frozenset(self.protected_classes),
            )
        if not isinstance(self.core_protection_tags, frozenset):
            object.__setattr__(
                self,
                "core_protection_tags",
                frozenset(self.core_protection_tags),
            )
        if not self.core_protection_tags:
            raise ValueError(
                "BranchRespectsCore.core_protection_tags must be non-empty"
            )
        # v0.22.0: protected_classes may be empty when the caller is
        # using rule-level provenance only. The class-level check will
        # no-op in that case; the rule-level check still fires.

    def validate_transition(
        self,
        old_revision: Optional["PolicyRevision"],
        new_revision: "PolicyRevision",
        branch: str,
    ) -> Tuple[CrossRevisionViolation, ...]:
        violations: List[CrossRevisionViolation] = []
        # Class-level check: legacy v0.14.0 surface. Fires on merge boundary.
        violations.extend(
            self._class_level_violations(old_revision, new_revision, branch)
        )
        # Rule-level check: v0.22.0 surface. Fires on every non-core
        # branch transition that drops a core-protected rule_id.
        violations.extend(
            self._rule_level_violations(old_revision, new_revision, branch)
        )
        return tuple(violations)

    # ── class-level (v0.14.0 legacy) ──────────────────────────────────────

    def _class_level_violations(
        self,
        old_revision: Optional["PolicyRevision"],
        new_revision: "PolicyRevision",
        branch: str,
    ) -> List[CrossRevisionViolation]:
        if not self.protected_classes:
            return []
        if not self._is_merge_into_core(new_revision, branch):
            return []
        if old_revision is None:
            return []
        old_classes = {type(i).__name__ for i in old_revision.invariants}
        new_classes = {type(i).__name__ for i in new_revision.invariants}
        missing_after_merge: List[str] = []
        for cls in sorted(self.protected_classes):
            if cls in old_classes and cls not in new_classes:
                missing_after_merge.append(cls)
        if not missing_after_merge:
            return []
        return [
            CrossRevisionViolation(
                invariant_name=self.name,
                category="merge_dropped_protected_class",
                reason=(
                    f"Merge commit on branch {self.core_branch_name!r} drops "
                    f"protected invariant class {cls!r} that was present on "
                    "the pre-merge head."
                ),
                old_value={"class_name": cls, "present_on_core": True},
                new_value={"class_name": cls, "present_on_merge_commit": False},
            )
            for cls in missing_after_merge
        ]

    # ── rule-level (v0.22.0) ──────────────────────────────────────────────

    def _rule_level_violations(
        self,
        old_revision: Optional["PolicyRevision"],
        new_revision: "PolicyRevision",
        branch: str,
    ) -> List[CrossRevisionViolation]:
        """Reject transitions that strip ``"core"`` from a protected rule.

        Runs on the non-core branch domain: feature branches are the
        restricted surface. Transitions on the core branch itself are
        free to mutate (the branch owner is the constituency that gets
        to redefine what counts as "core"). Genesis transitions on any
        branch are accepted (nothing to compare against).
        """
        # When we're on the core branch, feature-branch restrictions
        # don't apply. NoWeakening already covers the production-
        # protection surface there.
        if branch == self.core_branch_name:
            return []
        if old_revision is None:
            return []
        # Read the FULL overrides map on both sides (not filtered to
        # protected) so we can tell "demoted" apart from "dropped".
        old_all = _rule_level_overrides_raw(old_revision)
        new_all = _rule_level_overrides_raw(new_revision)
        violations: List[CrossRevisionViolation] = []
        for rule_id, old_tags in sorted(old_all.items()):
            old_core = old_tags & self.core_protection_tags
            if not old_core:
                # Not protected to begin with; nothing to defend.
                continue
            new_tags = new_all.get(rule_id)
            if new_tags is not None and new_tags == old_tags:
                # Identical provenance: no change to the rule's
                # protection classes — the mutation leaves the rule
                # untouched.
                continue
            # Any change to a protected rule on a feature branch is a
            # violation. Disambiguate between "dropped entirely" and
            # "demoted (core tag removed)" for the reason string.
            if new_tags is None:
                reason = (
                    f"Feature branch {branch!r} drops core-protected rule "
                    f"{rule_id!r}: present in pre-transition overrides "
                    f"with tags {sorted(old_tags)}, absent from new "
                    "revision."
                )
            else:
                new_core = new_tags & self.core_protection_tags
                if not new_core:
                    reason = (
                        f"Feature branch {branch!r} demotes core-protected "
                        f"rule {rule_id!r}: tags transitioned "
                        f"{sorted(old_tags)} -> {sorted(new_tags)}, losing "
                        "at least one core-protection class."
                    )
                else:
                    # Tags differ but "core" still present. We STILL treat
                    # this as a violation because feature branches aren't
                    # authorised to rewrite core rule provenance at all;
                    # main is the constituency for that redefinition.
                    reason = (
                        f"Feature branch {branch!r} rewrites tags on "
                        f"core-protected rule {rule_id!r}: "
                        f"{sorted(old_tags)} -> {sorted(new_tags)}. "
                        "Feature branches may not mutate core-protected "
                        "rule provenance."
                    )
            violations.append(CrossRevisionViolation(
                invariant_name=self.name,
                category="feature_branch_mutated_core_rule",
                reason=reason,
                old_value={
                    "rule_id": rule_id,
                    "protection_classes": sorted(old_tags),
                },
                new_value={
                    "rule_id": rule_id,
                    "protection_classes": (
                        sorted(new_tags) if new_tags is not None else None
                    ),
                },
            ))
        return violations

    def _is_merge_into_core(
        self,
        new_revision: "PolicyRevision",
        branch: str,
    ) -> bool:
        # Primary signal: caller says we're on the core branch AND the
        # revision itself is marked as a merge commit.
        if branch == self.core_branch_name and new_revision.merge_parent_ids is not None:
            return True
        # Secondary signal: the proof backend tag set by the three-way
        # merge builder. Belt + braces so we still fire when callers
        # forget to pass ``branch``.
        if (
            getattr(new_revision, "proof_backend", "") == "three-way-merge"
            and getattr(new_revision, "branch", "") == self.core_branch_name
        ):
            return True
        return False


def _rule_level_overrides_raw(
    revision: Optional["PolicyRevision"],
) -> Dict[str, FrozenSet[str]]:
    """Return the full rule-level overrides map (no protection filter).

    Accepts the v0.22.0 shape ``{rule_id: (class, ...)}``. Silently
    ignores the earlier OverridesMustExpire shape (dict-valued,
    integer-keyed) so both shapes coexist in the same ``overrides``
    key — callers may populate either without disturbing the other.
    """
    if revision is None:
        return {}
    scope = getattr(revision, "affected_scope", None) or {}
    raw = scope.get("overrides") or {}
    if not isinstance(raw, dict):
        return {}
    out: Dict[str, FrozenSet[str]] = {}
    for key, value in raw.items():
        if not isinstance(key, str):
            continue
        if isinstance(value, dict):
            # Legacy OverridesMustExpire entry — not our concern.
            continue
        if not isinstance(value, (tuple, list)):
            continue
        out[key] = frozenset(str(t) for t in value)
    return out


def _rule_level_overrides(
    revision: Optional["PolicyRevision"],
    core_protection_tags: FrozenSet[str],
) -> Dict[str, FrozenSet[str]]:
    """Filtered projection — keeps only rules carrying a core-protection tag.

    Thin wrapper over :func:`_rule_level_overrides_raw` for callers
    (and tests) that specifically want the "protected rules" view.
    """
    raw = _rule_level_overrides_raw(revision)
    return {
        key: tags for key, tags in raw.items()
        if tags & core_protection_tags
    }


# ── validator container ──────────────────────────────────────────────────────


@dataclass(frozen=True)
class CrossRevisionValidator:
    """A bundle of :class:`CrossRevisionInvariant` instances.

    Order of registration is preserved and surfaces on the resulting
    ``ValidationResult.violations`` tuple so operators get deterministic
    reports — handy for CI diffs. An empty validator is valid: it
    accepts every transition (matches the pre-v0.14 default).
    """

    invariants: Tuple[CrossRevisionInvariant, ...] = ()

    def __post_init__(self) -> None:
        # Accept lists / tuples uniformly; stash as a tuple for hashability.
        if not isinstance(self.invariants, tuple):
            object.__setattr__(self, "invariants", tuple(self.invariants))

    def __bool__(self) -> bool:
        return bool(self.invariants)

    def __len__(self) -> int:
        return len(self.invariants)

    def validate(
        self,
        old_revision: Optional["PolicyRevision"],
        new_revision: "PolicyRevision",
        branch: str,
    ) -> ValidationResult:
        """Run every cross-revision invariant, collecting all violations.

        We run every invariant even if the first one already returned a
        violation so operators see the full picture in one shot. That
        matches the ``policy_linter`` design choice: short-circuiting
        hides compounding problems.
        """
        all_violations: List[CrossRevisionViolation] = []
        for inv in self.invariants:
            violations = inv.validate_transition(old_revision, new_revision, branch)
            if violations:
                all_violations.extend(violations)
        return ValidationResult(
            valid=not all_violations,
            violations=tuple(all_violations),
        )


# ── env-driven default wiring ────────────────────────────────────────────────


def build_validator_from_env(env: Dict[str, str]) -> Optional[CrossRevisionValidator]:
    """Build a validator based on ``TAU_CAGE_CROSS_REVISION_*`` env vars.

    Returns ``None`` when no cross-revision feature is enabled so callers
    can short-circuit without paying for an empty validator. Intended to
    be called from :class:`daemon.cli._cmd_run` with ``os.environ``.

    Recognised variables:
      ``TAU_CAGE_CROSS_REVISION_NO_WEAKENING``        -- "1" enables with the default
                                                         monitored class set.
      ``TAU_CAGE_CROSS_REVISION_OVERRIDE_TTL``        -- positive int = max TTL
                                                         seconds; enables the rule.
      ``TAU_CAGE_CROSS_REVISION_CORE_BRANCH``         -- branch name; enables
                                                         BranchRespectsCore with the
                                                         default protected-class set.
    """
    invariants: List[CrossRevisionInvariant] = []
    if env.get("TAU_CAGE_CROSS_REVISION_NO_WEAKENING", "").strip() in ("1", "true", "yes"):
        invariants.append(NoWeakening())
    override_ttl_raw = env.get("TAU_CAGE_CROSS_REVISION_OVERRIDE_TTL", "").strip()
    if override_ttl_raw:
        try:
            override_ttl = int(override_ttl_raw)
        except ValueError:
            raise ValueError(
                f"TAU_CAGE_CROSS_REVISION_OVERRIDE_TTL must be a positive int; "
                f"got {override_ttl_raw!r}"
            )
        if override_ttl > 0:
            invariants.append(OverridesMustExpire(max_ttl_seconds=override_ttl))
    core_branch = env.get("TAU_CAGE_CROSS_REVISION_CORE_BRANCH", "").strip()
    if core_branch:
        invariants.append(BranchRespectsCore(
            core_branch_name=core_branch,
            protected_classes=frozenset({"SpendingCap", "ProviderAllowlist"}),
        ))
    if not invariants:
        return None
    return CrossRevisionValidator(invariants=tuple(invariants))


# ── serialisation helpers (shared with RevisionLog for violation payloads) ───


def _serialize_spending_cap(cap: SpendingCap) -> Dict[str, Any]:
    """JSON-safe summary of a SpendingCap for violation payloads.

    Uses strings for amounts so downstream parsers keep full Decimal
    precision; repr(Decimal) is allocator-friendly.
    """
    return {
        "class_name": "SpendingCap",
        "max_amount": str(cap.max_amount),
        "currency": cap.currency,
        "scope": cap.scope,
        "window_seconds": cap.window_seconds,
        "provider": cap.provider,
    }


def _serialize_max_per_call(cap: MaxPerCall) -> Dict[str, Any]:
    return {
        "class_name": "MaxPerCall",
        "max_amount": str(cap.max_amount),
        "currency": cap.currency,
    }


def _serialize_provider_allowlist(lst: ProviderAllowlist) -> Dict[str, Any]:
    return {
        "class_name": "ProviderAllowlist",
        "providers": sorted(lst.providers),
    }


def _serialize_adaptive_policy(p: AdaptiveTighteningPolicy) -> Dict[str, Any]:
    """JSON-safe summary of an AdaptiveTighteningPolicy.

    Decimals flow through as strings so the downstream parser keeps full
    precision. ``per_trigger_deltas`` is flattened to a sorted dict for
    stable diffing.
    """
    return {
        "class_name": "AdaptiveTighteningPolicy",
        "retry_density_per_min_threshold": str(p.retry_density_per_min_threshold),
        "denial_rate_threshold": str(p.denial_rate_threshold),
        "velocity_multiplier_threshold": str(p.velocity_multiplier_threshold),
        "identical_count_threshold": p.identical_count_threshold,
        "identical_window_seconds": p.identical_window_seconds,
        "decision_window_seconds": p.decision_window_seconds,
        "half_life_seconds": p.half_life_seconds,
        "per_trigger_deltas": {k: str(v) for k, v in p.per_trigger_deltas},
    }


def _serialize_peer_auth_policy(p: PeerAuthenticationPolicy) -> Dict[str, Any]:
    return {
        "class_name": "PeerAuthenticationPolicy",
        "allowed_peer_uids": sorted(p.allowed_peer_uids),
        "allowed_actor_claims": sorted(p.allowed_actor_claims),
        "allowed_signing_keys": sorted(p.allowed_signing_keys),
        "require_peer_uid": p.require_peer_uid,
        "require_signed_actor_claim": p.require_signed_actor_claim,
    }


# The ``CrossRevisionRejected`` exception type is defined inside
# ``adapter.policy_revision`` so it can subclass ``RevisionLogError``
# without creating an import cycle. Import it from there.
