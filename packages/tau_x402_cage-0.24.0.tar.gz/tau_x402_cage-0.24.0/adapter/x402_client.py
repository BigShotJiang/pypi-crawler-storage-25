"""End-to-end x402 mediation entry point.

Flow for a single x402 pre-settlement check:

    HTTP 402 request (headers + body)
        v
    parse()  -> PaymentIntent  (payment_intent_matcher.py)
        v
    DaemonClient.check()  -> Verdict  (queries Tau cage daemon over UDS)
        v
    sign()  -> SignedEnvelope  (verdict_signer.py)
        v
    to_http_response()  -> (status, headers, body)  (x402_envelope.py)

Fails closed: daemon unreachable or protocol error produces a reject envelope,
never a permit. The failure shape is a signed reject so the facilitator can
detect it cryptographically, a plain 500 would be indistinguishable from
network drop of a permit header.

Patch 8: when the daemon carries an active PolicyRevision, mediate() emits
a v2 envelope with MAC-bound provenance. The plain 3-arg call path (no
revision) continues to emit v1 envelopes unchanged -- existing callers in
`saas/` and this file's fail-closed branches keep working without changes.
"""

from __future__ import annotations

import json
import logging
import socket
from dataclasses import dataclass
from typing import Mapping, Optional, Protocol, Tuple

from adapter.payment_intent_matcher import (
    InvalidPaymentIntent,
    PaymentIntent,
    parse as parse_intent,
)
from adapter.policy_revision import PolicyRevision
from adapter.verdict_signer import (
    ShadowInfo,
    SignedEnvelope,
    Verdict,
    sign,
)
from adapter.x402_envelope import to_http_response

logger = logging.getLogger(__name__)


DEFAULT_SOCKET = "/tmp/tau-x402-cage.sock"
DEFAULT_TIMEOUT_SEC = 0.5  # p95 latency target is 10ms; 0.5s is generous


class DaemonClient(Protocol):
    """Anything that turns a PaymentIntent into a Verdict.

    Implementations MAY also expose `check_with_revision()` to return the
    active PolicyRevision alongside the verdict. `mediate()` probes for
    that method with `hasattr`, so clients that only implement `check()`
    still work but always get v1 envelopes.
    """

    def check(self, intent: PaymentIntent) -> Verdict: ...


@dataclass(frozen=True)
class UdsDaemonClient:
    """Production DaemonClient: JSON-over-UDS to the cage daemon."""

    socket_path: str = DEFAULT_SOCKET
    timeout_sec: float = DEFAULT_TIMEOUT_SEC

    def check(self, intent: PaymentIntent) -> Verdict:
        """Return a Verdict. Back-compat path; provenance dropped.

        Prefer `check_with_revision` when the caller needs v2 MAC binding.
        """
        verdict, _, _ = self._check_raw(intent)
        return verdict

    def check_with_revision(
        self, intent: PaymentIntent
    ) -> Tuple[Verdict, Optional[PolicyRevision]]:
        """Return (Verdict, PolicyRevision | None).

        When the daemon response carries provenance fields, we rebuild a
        lightweight PolicyRevision carrying just the MAC-bound fields; the
        invariants tuple is left empty because mediate() only needs the
        provenance for signing. When no provenance is present the revision
        is None and callers emit v1 envelopes.
        """
        verdict, revision, _ = self._check_raw(intent)
        return verdict, revision

    def check_with_comparison(
        self, intent: PaymentIntent
    ) -> Tuple[Verdict, Optional[PolicyRevision], Optional[str]]:
        """Return (Verdict, PolicyRevision | None, without_system | None).

        Extension of :meth:`check_with_revision` that surfaces the
        safety-comparison counterfactual (v0.13.0).
        """
        verdict, revision, without_system, _shadow = self._check_raw(intent)
        return verdict, revision, without_system

    def check_with_metadata(
        self, intent: PaymentIntent
    ) -> Tuple[Verdict, Optional[PolicyRevision], Optional[str], Optional[ShadowInfo]]:
        """Return (Verdict, revision, without_system, shadow) (v0.13.0).

        Preferred entry point for ``mediate()`` since v0.13.0: returns
        both the safety-comparison counterfactual and the shadow/advisory
        metadata so the signer can MAC-bind everything the daemon produced
        into one v2 envelope.
        """
        return self._check_raw(intent)

    def request(self, payload: Mapping[str, object]) -> dict:
        """Send an arbitrary daemon op and return the decoded JSON response.

        Thin JSON-over-UDS helper shared by `_check_raw()` and by read-only
        inspectors (e.g. the web UI). Keeps all socket handling in one place;
        callers never touch the framing directly.

        Raises:
            FileNotFoundError / ConnectionRefusedError: daemon not running.
            socket.timeout: daemon didn't respond within `timeout_sec`.
            RuntimeError: daemon returned a malformed JSON response.
        """
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.settimeout(self.timeout_sec)
        try:
            s.connect(self.socket_path)
            s.sendall((json.dumps(dict(payload)) + "\n").encode("utf-8"))
            f = s.makefile("r")
            response_line = f.readline()
        finally:
            s.close()
        try:
            return json.loads(response_line)
        except json.JSONDecodeError as exc:
            raise RuntimeError(f"daemon response not valid JSON: {exc}") from exc

    def _check_raw(
        self, intent: PaymentIntent
    ) -> Tuple[Verdict, Optional[PolicyRevision], Optional[str], Optional[ShadowInfo]]:
        request = {
            "op": "check_payment",
            "intent": {
                "amount": str(intent.amount),
                "currency": intent.currency,
                "provider": intent.provider,
                "counterparty": intent.counterparty,
                "rail": intent.rail,
                "timestamp_unix": intent.timestamp_unix,
                "metadata": dict(intent.metadata),
                "request_id": intent.request_id,
            },
        }
        response = self.request(request)
        outcome = response.get("verdict")
        if outcome not in ("permit", "reject"):
            raise RuntimeError(f"daemon returned unexpected verdict: {outcome!r}")
        verdict = Verdict(
            outcome=outcome,
            rule_id=response.get("rule_id"),
            witness=response.get("witness"),
            reason_text=response.get("reason_text"),
            ttl_seconds=int(response.get("ttl_seconds", 30)),
        )
        revision = _revision_from_response(response)
        without_system = response.get("without_system")
        if without_system is not None and without_system not in ("permit", "reject"):
            without_system = None
        shadow = _shadow_from_response(response)
        return verdict, revision, without_system, shadow


def _shadow_from_response(response: Mapping[str, object]) -> Optional[ShadowInfo]:
    """Rebuild a ShadowInfo from a daemon check_payment response (v0.13.0).

    Returns None when talking to pre-v0.13 daemons (no ``mode`` field in the
    response); callers then fall back to the legacy envelope shape.
    """
    mode = response.get("mode")
    if not mode:
        return None
    return ShadowInfo(
        mode=str(mode),
        would_reject=bool(response.get("shadow_would_reject", False)),
        rule_id=(
            str(response["shadow_rule_id"])
            if response.get("shadow_rule_id") is not None
            else None
        ),
        reason_text=(
            str(response["shadow_reason_text"])
            if response.get("shadow_reason_text") is not None
            else None
        ),
    )


def _revision_from_response(response: Mapping[str, object]) -> Optional[PolicyRevision]:
    """Rebuild a minimal PolicyRevision from daemon response provenance fields.

    Only used for MAC binding at signing time; the invariants tuple is empty
    because we don't round-trip them across the wire for every check. An
    auditor wanting full invariants queries `op=active_revision` directly.
    """
    rev_id = response.get("policy_revision_id")
    if not rev_id:
        return None
    return PolicyRevision(
        revision_id=str(rev_id),
        invariants=tuple(),
        proof_backend=str(response.get("proof_backend") or "unknown"),
        proof_strength=str(response.get("proof_strength") or "unknown"),
        prover_mode=str(response.get("prover_mode") or "compat"),
        compile_hash=(
            str(response["compile_hash"])
            if response.get("compile_hash") is not None
            else None
        ),
        fragment_version=None,
        tau_backend_version=None,
        admitted_at_unix=0,
        predecessor_revision_id=None,
    )


def _fail_closed_verdict(reason: str) -> Verdict:
    """Build a reject verdict for unrecoverable errors. Signed + returned."""
    return Verdict(
        outcome="reject",
        rule_id="cage_unavailable",
        witness=None,
        reason_text=f"Tau cage unavailable: {reason}",
        ttl_seconds=5,  # short TTL on failure, don't paper over outages
    )


def mediate(
    headers: Mapping[str, str],
    body: bytes,
    secret: bytes,
    daemon: Optional[DaemonClient] = None,
) -> tuple[int, dict[str, str], bytes]:
    """Mediate one x402 payment intent end-to-end. Always returns a signed response.

    This is the single entry point a facilitator calls. If anything goes wrong
   , malformed intent, daemon down, daemon protocol error, the response is
    a signed reject envelope, never an unsigned error.

    Signature is unchanged from pre-patch-8 so existing callers in `saas/`
    and older integrations keep working. When the injected daemon exposes
    `check_with_revision()` and returns a non-None PolicyRevision, mediate
    opts into v2 envelope signing (provenance MAC-bound); otherwise it emits
    a legacy v1 envelope.

    Args:
        headers: HTTP request headers from the payer
        body:    raw HTTP request body (bytes)
        secret:  HMAC secret shared between cage and facilitator
        daemon:  DaemonClient to query. Defaults to UdsDaemonClient().
    """
    daemon = daemon or UdsDaemonClient()

    # Step 1: parse. On schema failure we can't bind to a specific intent, so
    # emit an unbound reject, facilitator will also bounce based on its own
    # schema check. This failure path is rare; real facilitators validate shape
    # before asking the cage.
    try:
        intent = parse_intent(headers, body)
    except InvalidPaymentIntent as exc:
        logger.warning("payment intent rejected at parse: %s", exc)
        # Build a synthetic intent for binding purposes, we still need
        # something to hash. Using request attributes that failed validation
        # is fine because the reject is final.
        fake_intent = PaymentIntent(
            amount=__import__("decimal").Decimal("1"),
            currency="USDC",
            provider="unknown",
            counterparty="unknown",
            rail="x402",
            timestamp_unix=0,
        )
        v = Verdict(
            outcome="reject",
            rule_id="invalid_payment_intent",
            reason_text=f"Payment intent failed validation: {exc}",
            ttl_seconds=5,
        )
        env = sign(v, fake_intent, secret)
        return to_http_response(env)

    # Step 2: query daemon. Fail closed on any error. Prefer the fully
    # metadata-aware path (v0.13+: revision + shadow + without_system);
    # then comparison-only (v0.13 without shadow); then revision-only
    # (v0.8+); else plain check() and emit a v1 envelope.
    revision: Optional[PolicyRevision] = None
    without_system: Optional[str] = None
    shadow: Optional[ShadowInfo] = None
    try:
        if hasattr(daemon, "check_with_metadata"):
            verdict, revision, without_system, shadow = daemon.check_with_metadata(intent)  # type: ignore[attr-defined]
        elif hasattr(daemon, "check_with_comparison"):
            verdict, revision, without_system = daemon.check_with_comparison(intent)  # type: ignore[attr-defined]
        elif hasattr(daemon, "check_with_revision"):
            verdict, revision = daemon.check_with_revision(intent)  # type: ignore[attr-defined]
        else:
            verdict = daemon.check(intent)
    except (FileNotFoundError, ConnectionRefusedError, socket.timeout) as exc:
        logger.error("cage daemon unreachable: %s", exc)
        verdict = _fail_closed_verdict(f"{type(exc).__name__}")
    except (OSError, RuntimeError) as exc:
        logger.error("cage daemon protocol error: %s", exc)
        verdict = _fail_closed_verdict(f"protocol: {exc}")

    # Step 3: sign + wire-serialize. `sign()` emits v2 when a revision,
    # a without_system value, OR shadow info is provided; v1 when none.
    env = sign(
        verdict,
        intent,
        secret,
        revision=revision,
        without_system=without_system,
        shadow=shadow,
    )
    return to_http_response(env)
