"""HistoryStore: pluggable backend for the daemon's payment/reject/verdict history.

The x402 cage's RollingWindowCap and RetryRateLimit invariants reason over a
ring buffer of `PaymentIntent`s (permits + rejects). Until v0.8.0 this ring
buffer lived in-process as a `tuple[PaymentIntent, ...]` on `CageDaemon`;
every daemon restart reset state and replicas could not share it.

v0.8.0 extracts the ring buffer behind the `HistoryStore` Protocol so the
daemon can be wired to:

* ``InMemoryHistoryStore`` — zero-dep, process-local, identical semantics
  to the pre-v0.8.0 behaviour. Default.
* ``RedisHistoryStore`` — Redis LPUSH + LTRIM backed, durable across
  restarts, shareable across replicas, inspectable by the web UI or audit
  tooling. Fail-closed on Redis unreachable at daemon startup — operators
  must know when the backing store is down, not be silently downgraded to
  in-memory.

The store holds THREE streams, selected by ``kind``:

* ``"permit"`` — payment history used by RollingWindowCap for window counts.
* ``"reject"`` — reject history used by RetryRateLimit for back-off gap.
* ``"verdict"`` — verdict-annotated summaries used by the web UI's
  /ui/verdicts ring buffer and the ``recent_verdicts`` daemon op.

The first two carry ``PaymentIntent`` objects; the third carries dicts
shaped by ``daemon.server._intent_summary`` + the verdict envelope. We
normalise via ``_encode`` / ``_decode`` so both shapes survive a JSON
round-trip through Redis.

Wire-level design:

* Redis lists are used as ring buffers via ``LPUSH`` + ``LTRIM``. Head of
  the list is the NEWEST entry; oldest is trimmed on overflow.
* Keys are namespaced: ``<prefix>history:<kind>``.
* Values are JSON strings; `PaymentIntent`s are serialised via
  ``_intent_to_json`` (Decimal → str, metadata preserved, request_id
  preserved). Verdict dicts are serialised as-is.

Ordering contract:

* ``append`` appends the newest entry.
* ``recent(kind, limit, offset)`` returns entries from newest to oldest,
  i.e. reversed insertion order. Matches the shape the web UI expects.
* The RollingWindowCap / RetryRateLimit invariant code expects entries in
  OLDEST-first order; see ``recent_oldest_first`` for that view. We keep
  the two views explicit so callers don't silently reverse a list twice.
"""
from __future__ import annotations

import json
from decimal import Decimal
from typing import Any, Iterable, Protocol, Union

from adapter.payment_intent_matcher import PaymentIntent


# Tagged union shape stored in each entry so decode can reconstruct the
# right Python object without ambiguity.
_TAG_INTENT = "intent"
_TAG_VERDICT = "verdict"


def _intent_to_json(intent: PaymentIntent) -> dict[str, Any]:
    """Serialise a PaymentIntent to a JSON-safe dict.

    Decimal → str (full precision), metadata preserved as-is, request_id
    preserved (``None`` survives the round-trip as JSON null). The tag
    field distinguishes payment-intent rows from verdict-summary rows so
    the decoder never has to guess at the shape.
    """
    return {
        "_tag": _TAG_INTENT,
        "amount": str(intent.amount),
        "currency": intent.currency,
        "provider": intent.provider,
        "counterparty": intent.counterparty,
        "rail": intent.rail,
        "timestamp_unix": intent.timestamp_unix,
        "metadata": dict(intent.metadata),
        "request_id": intent.request_id,
    }


def _intent_from_json(d: dict[str, Any]) -> PaymentIntent:
    """Reconstruct a PaymentIntent from a dict produced by ``_intent_to_json``.

    ``PaymentIntent.__post_init__`` re-validates all fields, so a corrupted
    Redis row fails loudly at decode rather than at enforcement time.
    """
    return PaymentIntent(
        amount=Decimal(str(d["amount"])),
        currency=str(d["currency"]),
        provider=str(d["provider"]),
        counterparty=str(d["counterparty"]),
        rail=str(d["rail"]),
        timestamp_unix=int(d["timestamp_unix"]),
        metadata={str(k): str(v) for k, v in (d.get("metadata") or {}).items()},
        request_id=d.get("request_id"),
    )


def _encode(item: Union[PaymentIntent, dict[str, Any]]) -> str:
    """Encode an item (PaymentIntent or verdict-summary dict) to a JSON string.

    Verdict-summary dicts are tagged ``_tag="verdict"`` so decode can tell
    them apart from PaymentIntents without peeking at the shape.
    """
    if isinstance(item, PaymentIntent):
        return json.dumps(_intent_to_json(item), ensure_ascii=False)
    # Assume verdict-summary dict. Tag it so decode doesn't have to guess.
    tagged = dict(item)
    tagged["_tag"] = _TAG_VERDICT
    return json.dumps(tagged, ensure_ascii=False)


def _decode(raw: str) -> Union[PaymentIntent, dict[str, Any]]:
    """Decode a JSON string produced by ``_encode`` back to its Python shape."""
    d = json.loads(raw)
    tag = d.get("_tag")
    if tag == _TAG_INTENT:
        return _intent_from_json(d)
    if tag == _TAG_VERDICT:
        # Preserve all keys except the internal tag.
        return {k: v for k, v in d.items() if k != "_tag"}
    raise ValueError(f"unknown history row tag: {tag!r}")


_ALLOWED_KINDS = frozenset({"permit", "reject", "verdict"})


def _check_kind(kind: str) -> None:
    if kind not in _ALLOWED_KINDS:
        raise ValueError(
            f"kind must be one of {sorted(_ALLOWED_KINDS)}, got {kind!r}"
        )


def _is_shadow_rejected(entry: Union[PaymentIntent, dict[str, Any]]) -> bool:
    """Return True iff this history entry is a shadow-mode reject record.

    PaymentIntent rows are never shadow-tagged (they carry no metadata
    fields we'd use). Verdict-summary dicts carry ``shadow_rejected=True``
    when the daemon recorded a would-have-rejected intent through
    shadow/advisory mode. Used by the ``shadow_only`` filter path on
    ``recent()``.
    """
    if isinstance(entry, dict):
        return bool(entry.get("shadow_rejected"))
    return False


class HistoryStore(Protocol):
    """Protocol for pluggable history backends.

    Implementations must be thread-safe; the daemon already serialises
    registry mutations under its own lock but treats the store as a
    concurrently-writable shared resource.
    """

    def append(
        self,
        item: Union[PaymentIntent, dict[str, Any]],
        kind: str = "permit",
    ) -> None:
        """Append one item to the ``kind`` stream. Newest-last semantics."""
        ...

    def recent(
        self,
        kind: str = "permit",
        limit: int = 50,
        offset: int = 0,
        shadow_only: bool = False,
    ) -> list[Union[PaymentIntent, dict[str, Any]]]:
        """Return a window of entries from NEWEST to OLDEST for ``kind``.

        ``offset`` counts from the newest end; ``limit`` is capped by the
        backing store's current length.

        When ``shadow_only=True`` (v0.13.0), only return entries tagged
        ``shadow_rejected=True`` in their metadata. Used by the
        ``shadow-summary`` CLI to walk just the rejects-that-became-
        permits; ignored for entries that aren't verdict-summary dicts
        (e.g. plain PaymentIntent rows in the permit/reject streams).
        """
        ...

    def recent_oldest_first(
        self,
        kind: str = "permit",
    ) -> tuple[Union[PaymentIntent, dict[str, Any]], ...]:
        """Return ALL entries for ``kind`` as an oldest-first tuple.

        Used by RollingWindowCap / RetryRateLimit, which iterate in
        insertion order. Implementations should bound their memory use so
        this method doesn't blow up on a full ring buffer (10_000 entries
        by default).
        """
        ...

    def count(self, kind: str = "permit") -> int:
        """Return the current length of the ``kind`` stream."""
        ...

    def clear(self) -> None:
        """Drop all streams. Primarily useful for tests."""
        ...


class InMemoryHistoryStore:
    """Process-local ring buffer implementation. Default backend.

    Preserves the exact semantics of the pre-v0.8.0 in-process tuples:
    each stream is independently capped at ``cap`` entries, oldest trimmed
    on overflow. Thread-safe via a single per-store lock; the daemon's
    registry lock is sufficient for its own call sites but third-party
    callers (e.g. future async web UI) need the store itself to be safe.
    """

    def __init__(self, cap: int = 10_000) -> None:
        if cap <= 0:
            raise ValueError(f"cap must be > 0, got {cap}")
        self._cap = cap
        # Use a plain list per kind and slice for trim. The cap keeps
        # memory bounded so the O(n) trim cost stays small in practice.
        self._streams: dict[str, list[Union[PaymentIntent, dict[str, Any]]]] = {
            "permit": [],
            "reject": [],
            "verdict": [],
        }
        import threading
        self._lock = threading.Lock()

    @property
    def backend(self) -> str:
        return "memory"

    def append(
        self,
        item: Union[PaymentIntent, dict[str, Any]],
        kind: str = "permit",
    ) -> None:
        _check_kind(kind)
        with self._lock:
            stream = self._streams[kind]
            stream.append(item)
            overflow = len(stream) - self._cap
            if overflow > 0:
                # Trim oldest `overflow` entries.
                del stream[:overflow]

    def recent(
        self,
        kind: str = "permit",
        limit: int = 50,
        offset: int = 0,
        shadow_only: bool = False,
    ) -> list[Union[PaymentIntent, dict[str, Any]]]:
        _check_kind(kind)
        if limit < 0:
            raise ValueError(f"limit must be >= 0, got {limit}")
        if offset < 0:
            raise ValueError(f"offset must be >= 0, got {offset}")
        with self._lock:
            stream = self._streams[kind]
            if shadow_only:
                # Filter in-place over the full stream before applying the
                # (offset, limit) window so the caller gets exactly
                # `limit` shadow entries rather than a limit-sized
                # window mostly made of non-shadow entries. Newest-first.
                filtered = [
                    e for e in stream if _is_shadow_rejected(e)
                ]
                total = len(filtered)
                end = max(total - offset, 0)
                start = max(end - limit, 0)
                return list(reversed(filtered[start:end]))
            total = len(stream)
            end = max(total - offset, 0)
            start = max(end - limit, 0)
            window = stream[start:end]
            # Newest-first window.
            return list(reversed(window))

    def recent_oldest_first(
        self,
        kind: str = "permit",
    ) -> tuple[Union[PaymentIntent, dict[str, Any]], ...]:
        _check_kind(kind)
        with self._lock:
            return tuple(self._streams[kind])

    def count(self, kind: str = "permit") -> int:
        _check_kind(kind)
        with self._lock:
            return len(self._streams[kind])

    def clear(self) -> None:
        with self._lock:
            for k in self._streams:
                self._streams[k].clear()


class HistoryStoreError(RuntimeError):
    """Raised when the backing history store is unreachable or misconfigured."""


class RedisHistoryStore:
    """Redis-backed ring buffer implementation.

    Each stream maps to a Redis list at ``<key_prefix>history:<kind>``.
    ``append`` issues ``LPUSH`` + ``LTRIM 0 cap-1`` under a pipeline so the
    cap is enforced atomically. ``recent`` is a single ``LRANGE``; the list
    is stored newest-at-head so no reversal is needed on the read path.

    Startup fails fast (``HistoryStoreError``) if Redis is unreachable.
    This is deliberate: silently degrading to in-memory on an operator-
    configured Redis URL would hide the outage AND produce two replicas
    with divergent rolling windows (→ incorrect RetryRateLimit verdicts).

    Thread-safety is inherited from ``redis-py``'s connection pool.
    """

    def __init__(
        self,
        url: str,
        *,
        key_prefix: str = "tau-x402-cage:",
        cap: int = 10_000,
        redis_client: Any = None,
    ) -> None:
        if not url and redis_client is None:
            raise ValueError("RedisHistoryStore requires a url or a redis_client")
        if cap <= 0:
            raise ValueError(f"cap must be > 0, got {cap}")
        self._url = url
        self._key_prefix = key_prefix
        self._cap = cap
        if redis_client is not None:
            # Explicitly injected client — typically fakeredis for tests.
            self._client = redis_client
        else:
            try:
                import redis  # type: ignore[import-untyped]
            except ImportError as exc:
                raise HistoryStoreError(
                    "redis backend requested but the `redis` package is not "
                    "installed. Install with: pip install 'tau-x402-cage[history-redis]'"
                ) from exc
            try:
                # decode_responses=True so LRANGE returns str not bytes,
                # keeping JSON parsing straightforward.
                self._client = redis.Redis.from_url(
                    url,
                    decode_responses=True,
                    socket_connect_timeout=2.0,
                )
            except Exception as exc:  # pragma: no cover — redis.from_url is strict
                raise HistoryStoreError(
                    f"could not construct redis client for url={url!r}: {exc}"
                ) from exc
        # Preflight: ping the server so the daemon fails fast at startup
        # rather than at the first append. Operators deserve to know.
        self._preflight()

    def _preflight(self) -> None:
        """Verify connectivity by issuing PING; fail-closed on error."""
        try:
            ok = self._client.ping()
        except Exception as exc:
            raise HistoryStoreError(
                f"redis unreachable at {self._url!r}: {exc}. Refusing to "
                f"start with silent in-memory fallback; fix Redis or "
                f"switch --history-backend=memory."
            ) from exc
        if not ok:
            raise HistoryStoreError(
                f"redis PING returned falsy value at {self._url!r}; aborting"
            )

    @property
    def backend(self) -> str:
        return "redis"

    def _key(self, kind: str) -> str:
        return f"{self._key_prefix}history:{kind}"

    def append(
        self,
        item: Union[PaymentIntent, dict[str, Any]],
        kind: str = "permit",
    ) -> None:
        _check_kind(kind)
        payload = _encode(item)
        key = self._key(kind)
        # Pipeline the push + trim so the cap is enforced atomically.
        # LTRIM 0 cap-1 keeps the newest `cap` entries (head-side).
        pipe = self._client.pipeline()
        pipe.lpush(key, payload)
        pipe.ltrim(key, 0, self._cap - 1)
        pipe.execute()

    def recent(
        self,
        kind: str = "permit",
        limit: int = 50,
        offset: int = 0,
        shadow_only: bool = False,
    ) -> list[Union[PaymentIntent, dict[str, Any]]]:
        _check_kind(kind)
        if limit < 0:
            raise ValueError(f"limit must be >= 0, got {limit}")
        if offset < 0:
            raise ValueError(f"offset must be >= 0, got {offset}")
        if limit == 0:
            return []
        key = self._key(kind)
        if shadow_only:
            # Redis LRANGE doesn't filter server-side, so we pull the
            # full list and decode + filter client-side. The ring buffer
            # cap bounds this to 10k entries by default; shadow summaries
            # are typically run against 24h windows so this is fine.
            raw_all = self._client.lrange(key, 0, -1)
            decoded = [_decode(r) for r in raw_all]
            filtered = [e for e in decoded if _is_shadow_rejected(e)]
            return filtered[offset:offset + limit]
        # List is stored newest-at-head, so LRANGE offset .. offset+limit-1
        # gives us a newest-first window directly.
        raw = self._client.lrange(key, offset, offset + limit - 1)
        return [_decode(r) for r in raw]

    def recent_oldest_first(
        self,
        kind: str = "permit",
    ) -> tuple[Union[PaymentIntent, dict[str, Any]], ...]:
        _check_kind(kind)
        key = self._key(kind)
        # LRANGE 0 -1 returns newest-first; reverse for oldest-first.
        raw = self._client.lrange(key, 0, -1)
        return tuple(reversed([_decode(r) for r in raw]))

    def count(self, kind: str = "permit") -> int:
        _check_kind(kind)
        return int(self._client.llen(self._key(kind)))

    def clear(self) -> None:
        # Only delete our own namespaced keys; never FLUSHDB somebody
        # else's database.
        for kind in _ALLOWED_KINDS:
            self._client.delete(self._key(kind))


def build_history_store(
    backend: str,
    *,
    redis_url: str | None = None,
    key_prefix: str = "tau-x402-cage:",
    cap: int = 10_000,
    redis_client: Any = None,
) -> HistoryStore:
    """Factory used by the daemon CLI to pick an implementation by name.

    ``backend`` must be one of:

    * ``"memory"`` — process-local ring buffer (default, zero-dep).
    * ``"redis"`` — Redis-backed ring buffer; ``redis_url`` is required.

    Raises ``HistoryStoreError`` on Redis unreachable so ``daemon/cli.py``
    can surface a clean startup error.
    """
    if backend == "memory":
        return InMemoryHistoryStore(cap=cap)
    if backend == "redis":
        if not redis_url and redis_client is None:
            raise HistoryStoreError(
                "--history-backend=redis requires --redis-url (or "
                "TAU_CAGE_HISTORY_REDIS_URL env var)"
            )
        return RedisHistoryStore(
            url=redis_url or "",
            key_prefix=key_prefix,
            cap=cap,
            redis_client=redis_client,
        )
    raise HistoryStoreError(
        f"unknown history backend {backend!r}; "
        f"expected 'memory' or 'redis'"
    )
