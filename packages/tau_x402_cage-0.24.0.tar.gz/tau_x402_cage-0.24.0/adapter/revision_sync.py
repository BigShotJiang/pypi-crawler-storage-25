"""Multi-node revision-sync over Redis pub/sub (v0.11.0).

Each daemon replica holds its own ``RevisionLog``. Until v0.11.0, a
`create_branch` or `merge_branch` on replica A never reached replica B.
Production x402 deployments want at least two replicas for HA, so we
need the branching graph, the revision chain, and the active head to
stay coherent across replicas.

Design shape:

* **Fan-out, not consensus.** Every replica publishes its own mutations
  to a shared Redis channel. Every replica subscribes. Convergence is
  *eventually consistent at the revision-id level*: revision ids are
  content-addressed, so two replicas producing "the same" admission
  generate the same id and either wins safely. Concurrent writes
  producing genuinely different ids both land on both replicas,
  preserving the audit trail intact.
* **Fail-open publish.** Publishing must never block or break the
  local mutation path. If Redis is flaky we log and drop; the
  per-revision jsonl audit trail remains the source of truth on each
  replica.
* **Fail-closed preflight.** When a sync URL is configured but Redis
  is unreachable at startup, the daemon refuses to start. Silent
  in-memory fallback would leave an operator thinking their two
  replicas are sync'd when in fact they aren't.
* **Loop prevention.** Every record carries a ``source_client_id``.
  Subscribers ignore records stamped with their own id so a publish
  never round-trips back into the originating log.
* **Idempotency.** Revision records are keyed by ``revision_id``;
  branch records by a stable hash of their serialised content. The
  subscriber maintains a bounded LRU-ish seen set so late-arriving
  duplicates (e.g. after a reconnect) don't double-append.

Wire format on the channel: one JSON object per Redis pub/sub message,
with these shapes:

  { "_sync_kind": "revision",
    "source_client_id": "...",
    "revision": { ...PolicyRevision.to_dict()... } }

  { "_sync_kind": "branch_create",
    "source_client_id": "...",
    "branch": { ...Branch.to_dict()... } }

  { "_sync_kind": "branch_checkout",
    "source_client_id": "...",
    "name": "<branch_name>" }

  { "_sync_kind": "branch_merge",
    "source_client_id": "...",
    "src": "...", "dst": "...",
    "merge_kind": "fast-forward" | "three-way",
    "new_head_revision_id": "...",
    "reviewer": "...",
    "revision": { ... }  # only on three-way merges, carries the merge commit
  }

The shapes intentionally mirror the in-log ``_record_type`` discriminators
used by `adapter.policy_revision.RevisionLog`, so a subscriber's apply
path is one tight switch statement.
"""
from __future__ import annotations

import hashlib
import json
import logging
import threading
import time
import uuid
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Callable, Deque, Optional

from adapter.policy_revision import (
    Branch,
    PolicyRevision,
    RevisionLog,
    RevisionLogError,
)


logger = logging.getLogger(__name__)


# Wire-format discriminators. Kept as module constants so both publisher and
# subscriber share the exact literal and tests can reference them.
KIND_REVISION = "revision"
KIND_BRANCH_CREATE = "branch_create"
KIND_BRANCH_CHECKOUT = "branch_checkout"
KIND_BRANCH_MERGE = "branch_merge"

_ALL_KINDS = frozenset({
    KIND_REVISION,
    KIND_BRANCH_CREATE,
    KIND_BRANCH_CHECKOUT,
    KIND_BRANCH_MERGE,
})


class RevisionSyncError(RuntimeError):
    """Raised for sync-layer startup or configuration failures.

    Hot-path publish failures are logged and swallowed (fail-open); this
    exception is reserved for conditions an operator must know about --
    typically Redis unreachable at startup under a configured URL.
    """


@dataclass(frozen=True)
class SyncConfig:
    """Configuration for the revision-sync pub/sub layer.

    Fields:
        url                         : Redis URL (e.g. redis://host:6379/0).
                                      Required unless an explicit redis
                                      client is injected for tests.
        channel                     : Redis pub/sub channel name. All
                                      replicas sharing a policy graph must
                                      agree on this.
        client_id                   : Unique per-replica identifier. Used
                                      for loop prevention. Auto-generated
                                      when empty.
        idempotency_window_seconds  : How long a revision_id / branch-record
                                      hash stays in the "recently seen" set.
                                      Duplicates arriving within the window
                                      are dropped. 900s (15m) is generous
                                      for a reconnect; we prune aggressively
                                      past that to keep memory bounded.
    """

    url: str
    channel: str = "tau-x402-cage:revision-sync"
    client_id: str = ""
    idempotency_window_seconds: int = 900

    def resolved_client_id(self) -> str:
        """Return a concrete client id, generating one if needed.

        Frozen dataclass, so generation is idempotent at the call site
        (callers cache the returned value rather than mutating the config).
        """
        if self.client_id:
            return self.client_id
        return f"sync-{uuid.uuid4().hex[:12]}"


# ── Publisher ──────────────────────────────────────────────────────────────


class RevisionSyncPublisher:
    """Publishes revision / branch records to Redis.

    Design contract:
    * ``publish_*`` must NEVER block the local mutation. Wire errors are
      logged and dropped; the local jsonl audit trail remains truth.
    * We do not retry inline; a retry loop would conflate local mutation
      latency with Redis latency. Operators wanting at-least-once delivery
      can bolt on a reconciliation job against the jsonl audit.
    * The publisher does not maintain any background threads. All work
      happens in the caller's thread, so shutdown is trivially safe.
    """

    def __init__(
        self,
        config: SyncConfig,
        *,
        redis_client: Any = None,
    ) -> None:
        self._config = config
        self._client_id = config.resolved_client_id()
        if redis_client is not None:
            self._client = redis_client
        else:
            self._client = _build_redis_client(config.url)

    @property
    def client_id(self) -> str:
        return self._client_id

    @property
    def channel(self) -> str:
        return self._config.channel

    def publish_revision(self, revision: PolicyRevision) -> None:
        """Publish a new ``PolicyRevision``. Fail-open on wire errors."""
        payload = {
            "_sync_kind": KIND_REVISION,
            "source_client_id": self._client_id,
            "revision": revision.to_dict(),
        }
        self._publish_raw(payload)

    def publish_branch_create(self, branch: Branch) -> None:
        """Publish a branch-create record."""
        payload = {
            "_sync_kind": KIND_BRANCH_CREATE,
            "source_client_id": self._client_id,
            "branch": branch.to_dict(),
        }
        self._publish_raw(payload)

    def publish_branch_checkout(self, name: str) -> None:
        """Publish a branch-checkout (active-branch swap) record."""
        payload = {
            "_sync_kind": KIND_BRANCH_CHECKOUT,
            "source_client_id": self._client_id,
            "name": name,
        }
        self._publish_raw(payload)

    def publish_branch_merge(
        self,
        *,
        src: str,
        dst: str,
        merge_kind: str,
        new_head_revision_id: Optional[str],
        reviewer: str,
        merge_revision: Optional[PolicyRevision] = None,
    ) -> None:
        """Publish a merge event.

        ``merge_revision`` is populated only on three-way merges (the
        newly-fabricated merge commit). For fast-forward merges the dst
        head just advances to an existing revision id, so no new record
        is needed; the subscriber fetches the local revision by id.
        """
        payload: dict[str, Any] = {
            "_sync_kind": KIND_BRANCH_MERGE,
            "source_client_id": self._client_id,
            "src": src,
            "dst": dst,
            "merge_kind": merge_kind,
            "new_head_revision_id": new_head_revision_id,
            "reviewer": reviewer,
        }
        if merge_revision is not None:
            payload["revision"] = merge_revision.to_dict()
        self._publish_raw(payload)

    def _publish_raw(self, payload: dict[str, Any]) -> None:
        """Serialise + publish. Fail-open; never raises into the caller."""
        try:
            line = json.dumps(payload, sort_keys=True, ensure_ascii=False)
        except (TypeError, ValueError) as exc:
            # Serialisation failure is a bug on the producing side, but we
            # still fail-open because the alternative is to leave the local
            # mutation unfinished. Surface as a WARNING so operators see it.
            logger.warning(
                "revision_sync: could not serialise payload (kind=%r): %s",
                payload.get("_sync_kind"), exc,
            )
            return
        try:
            self._client.publish(self._config.channel, line)
        except Exception as exc:  # noqa: BLE001 -- fail-open is the contract
            logger.warning(
                "revision_sync: publish failed (kind=%r): %s",
                payload.get("_sync_kind"), exc,
            )

    def close(self) -> None:
        """Release the underlying redis client if we created it.

        Safe to call on a publisher that was built with an injected
        client; redis-py handles ``close()`` on shared clients idempotently.
        """
        try:
            close = getattr(self._client, "close", None)
            if callable(close):
                close()
        except Exception:  # noqa: BLE001 -- shutdown must be robust
            logger.debug("revision_sync: publisher close raised", exc_info=True)


# ── Subscriber ─────────────────────────────────────────────────────────────


# Type alias for the callback the subscriber fires AFTER an apply completes.
# Called on the subscriber thread; callbacks must be non-blocking or use
# their own queue. Not a contract we enforce, but callers should respect it.
ApplyCallback = Callable[[dict[str, Any]], None]


class RevisionSyncSubscriber:
    """Background thread that applies remote revision/branch records.

    One instance per daemon. Wraps a ``RevisionLog`` and a Redis pub/sub
    channel; on each message the subscriber thread decodes the payload,
    filters by ``source_client_id`` (loop prevention), checks the
    idempotency set, and applies the record to the log under a lock
    supplied by the caller (typically the daemon's registry lock).

    Lifecycle:
      * ``__init__`` builds the redis client and a pubsub object.
      * ``start()`` spins up the worker thread; idempotent.
      * ``stop()`` signals the worker to exit and joins it. Idempotent.

    The subscriber tracks "connected" / "last message at" so the daemon's
    ``health`` op can expose a cheap freshness signal.
    """

    def __init__(
        self,
        config: SyncConfig,
        log: RevisionLog,
        *,
        registry_lock: Optional[threading.Lock] = None,
        callback: Optional[ApplyCallback] = None,
        redis_client: Any = None,
        own_client_id: Optional[str] = None,
    ) -> None:
        self._config = config
        self._log = log
        self._lock = registry_lock or threading.Lock()
        self._callback = callback
        self._own_client_id = own_client_id or config.resolved_client_id()
        if redis_client is not None:
            self._client = redis_client
        else:
            self._client = _build_redis_client(config.url)
        self._pubsub: Any = None
        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        # Idempotency: bounded seen-set. We pair a deque (FIFO insertion
        # order) with a set for O(1) membership. When the deque tops the
        # cap we evict from the front and drop the corresponding entry.
        self._seen: set[str] = set()
        self._seen_order: Deque[tuple[str, float]] = deque()
        self._seen_cap = 4096
        self._connected_flag = threading.Event()
        self._last_message_at: Optional[float] = None

    # ── lifecycle ──────────────────────────────────────────────────────

    def start(self) -> None:
        """Spin up the listener thread. Idempotent.

        The subscribe happens on the worker thread so ``start()`` returns
        immediately; ``connected()`` flips true once the pubsub loop has
        registered with Redis.
        """
        if self._thread is not None and self._thread.is_alive():
            return
        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._run,
            name=f"revision-sync-{self._own_client_id}",
            daemon=True,
        )
        self._thread.start()

    def stop(self, timeout: float = 2.0) -> None:
        """Signal the worker to exit and join it. Idempotent and bounded."""
        self._stop_event.set()
        # Poking pubsub.close() nudges the blocking listen() out; redis-py
        # propagates a connection-closed exception on the loop.
        if self._pubsub is not None:
            try:
                self._pubsub.close()
            except Exception:  # noqa: BLE001 -- shutdown path
                logger.debug("revision_sync: pubsub close raised", exc_info=True)
        thread = self._thread
        if thread is not None and thread.is_alive():
            thread.join(timeout=timeout)
        self._thread = None
        # Best-effort close of the connection itself.
        try:
            close = getattr(self._client, "close", None)
            if callable(close):
                close()
        except Exception:  # noqa: BLE001
            logger.debug("revision_sync: subscriber client close raised", exc_info=True)

    def connected(self) -> bool:
        return self._connected_flag.is_set()

    def last_message_at(self) -> Optional[float]:
        return self._last_message_at

    def subscriber_lag_ms(self) -> int:
        """Wall-clock milliseconds since the last message.

        Returns ``-1`` when we have not yet seen any message (the shape
        fits the wire easier than ``None``). Callers can use ``>= 0`` as
        a proxy for "lag is measurable".
        """
        if self._last_message_at is None:
            return -1
        return max(0, int((time.monotonic() - self._last_message_at) * 1000))

    # ── run loop ───────────────────────────────────────────────────────

    def _run(self) -> None:
        """Worker-thread main loop.

        We subscribe once, then iterate messages. redis-py's FakeRedis
        shim and real redis both support ``pubsub().subscribe(channel)``
        plus ``get_message(timeout=...)``. Using a timeout lets us check
        the stop event without blocking indefinitely when the channel
        is quiet.
        """
        try:
            self._pubsub = self._client.pubsub(ignore_subscribe_messages=True)
            self._pubsub.subscribe(self._config.channel)
            self._connected_flag.set()
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "revision_sync: subscriber could not subscribe to %r: %s",
                self._config.channel, exc,
            )
            return
        while not self._stop_event.is_set():
            try:
                msg = self._pubsub.get_message(timeout=0.5)
            except Exception as exc:  # noqa: BLE001
                # Transient Redis disconnects shouldn't kill the whole
                # daemon; log and retry after a short breather. A
                # permanently broken connection will keep looping until
                # stop() is called, which is exactly what we want during
                # operator-led failover.
                logger.warning("revision_sync: subscriber recv error: %s", exc)
                if self._stop_event.wait(timeout=1.0):
                    break
                continue
            if msg is None:
                continue
            data = msg.get("data")
            if data is None:
                continue
            self._handle_raw_message(data)
        self._connected_flag.clear()

    def _handle_raw_message(self, data: Any) -> None:
        """Decode + validate + route one raw message. Never raises upward."""
        try:
            if isinstance(data, bytes):
                data = data.decode("utf-8")
            if not isinstance(data, str):
                logger.warning("revision_sync: non-string message data: %r", type(data))
                return
            payload = json.loads(data)
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            logger.warning("revision_sync: malformed message: %s", exc)
            return
        if not isinstance(payload, dict):
            logger.warning("revision_sync: message not a JSON object: %r", type(payload))
            return
        self._last_message_at = time.monotonic()
        source = payload.get("source_client_id")
        if source == self._own_client_id:
            # Loop prevention: our own publisher round-tripped back.
            return
        kind = payload.get("_sync_kind")
        if kind not in _ALL_KINDS:
            logger.warning("revision_sync: unknown sync kind: %r", kind)
            return
        try:
            applied = self._apply(kind, payload)
        except Exception as exc:  # noqa: BLE001
            logger.warning("revision_sync: apply failed (kind=%r): %s", kind, exc)
            return
        if applied and self._callback is not None:
            try:
                self._callback(payload)
            except Exception:  # noqa: BLE001 -- callbacks must not crash us
                logger.exception("revision_sync: callback raised (kind=%r)", kind)

    # ── apply helpers ──────────────────────────────────────────────────

    def _apply(self, kind: str, payload: dict[str, Any]) -> bool:
        """Route a validated payload onto the local log.

        Returns ``True`` when we actually mutated local state, ``False``
        when the record was a duplicate / no-op so callers can distinguish
        the two cases in tests and metrics.
        """
        if kind == KIND_REVISION:
            return self._apply_revision(payload)
        if kind == KIND_BRANCH_CREATE:
            return self._apply_branch_create(payload)
        if kind == KIND_BRANCH_CHECKOUT:
            return self._apply_branch_checkout(payload)
        if kind == KIND_BRANCH_MERGE:
            return self._apply_branch_merge(payload)
        return False

    def _apply_revision(self, payload: dict[str, Any]) -> bool:
        d = payload.get("revision")
        if not isinstance(d, dict):
            logger.warning("revision_sync: revision payload missing 'revision'")
            return False
        try:
            rev = PolicyRevision.from_dict(d)
        except RevisionLogError as exc:
            logger.warning("revision_sync: could not rehydrate revision: %s", exc)
            return False
        key = f"rev:{rev.revision_id}"
        if self._seen_recent(key):
            return False
        with self._lock:
            # Idempotent at the log level: if an equal id is already there
            # from a concurrent mutation, don't double-append.
            if rev.revision_id in self._log._revisions_by_id:
                self._mark_seen(key)
                return False
            self._log.append(rev)
            self._mark_seen(key)
        return True

    def _apply_branch_create(self, payload: dict[str, Any]) -> bool:
        d = payload.get("branch")
        if not isinstance(d, dict):
            logger.warning("revision_sync: branch_create payload missing 'branch'")
            return False
        try:
            branch = Branch.from_dict(d)
        except RevisionLogError as exc:
            logger.warning("revision_sync: could not rehydrate branch: %s", exc)
            return False
        key = f"br:{_stable_hash(d)}"
        if self._seen_recent(key):
            return False
        with self._lock:
            existing = self._log._branches.get(branch.name)
            # Keep the later-created record if names collide; that matches
            # the publisher's own "create overwrites" semantics.
            self._log._branches[branch.name] = branch
            self._mark_seen(key)
            return existing is None or existing != branch

    def _apply_branch_checkout(self, payload: dict[str, Any]) -> bool:
        name = payload.get("name")
        if not isinstance(name, str) or not name:
            logger.warning("revision_sync: branch_checkout missing 'name'")
            return False
        key = f"co:{name}:{payload.get('source_client_id')}"
        # Checkout is idempotent by construction (set the active branch);
        # we still use the seen-set as a weak dedup across reconnects.
        if self._seen_recent(key):
            return False
        with self._lock:
            # Only apply if the branch exists locally -- otherwise a stray
            # checkout from a replica that created a branch out of order
            # would leave us pointing at a phantom.
            if name not in self._log._branches:
                logger.debug(
                    "revision_sync: checkout for unknown branch %r; deferring", name
                )
                return False
            self._log._active_branch = name
            self._mark_seen(key)
            return True

    def _apply_branch_merge(self, payload: dict[str, Any]) -> bool:
        dst = payload.get("dst")
        new_head = payload.get("new_head_revision_id")
        merge_kind = payload.get("merge_kind")
        if not isinstance(dst, str) or not dst:
            logger.warning("revision_sync: branch_merge missing 'dst'")
            return False
        key = (
            f"mg:{dst}:{new_head}:{merge_kind}:{payload.get('src')}"
        )
        if self._seen_recent(key):
            return False
        # Three-way merges carry a merge-commit revision that must land
        # BEFORE the head pointer swap so callers observing the new head
        # see a populated revision.
        changed = False
        rev_d = payload.get("revision")
        if merge_kind == "three-way" and isinstance(rev_d, dict):
            try:
                merge_rev = PolicyRevision.from_dict(rev_d)
            except RevisionLogError as exc:
                logger.warning("revision_sync: merge revision rehydrate failed: %s", exc)
                merge_rev = None
            if merge_rev is not None:
                rev_key = f"rev:{merge_rev.revision_id}"
                if not self._seen_recent(rev_key):
                    with self._lock:
                        if merge_rev.revision_id not in self._log._revisions_by_id:
                            self._log.append(merge_rev)
                            changed = True
                    self._mark_seen(rev_key)
        if not isinstance(new_head, str):
            # FF to empty dst (rare) or malformed -- nothing to point at.
            self._mark_seen(key)
            return changed
        with self._lock:
            existing = self._log._branches.get(dst)
            if existing is None:
                # We haven't seen this branch yet; record a stub so a
                # subsequent branch_create record merges cleanly.
                self._log._branches[dst] = Branch(
                    name=dst,
                    head_revision_id=new_head,
                    created_at=0,
                    created_by="",
                )
                changed = True
            else:
                if existing.head_revision_id != new_head:
                    self._log._branches[dst] = existing.with_head(new_head)
                    changed = True
        self._mark_seen(key)
        return changed

    # ── idempotency ────────────────────────────────────────────────────

    def _seen_recent(self, key: str) -> bool:
        self._prune_expired()
        return key in self._seen

    def _mark_seen(self, key: str) -> None:
        now = time.monotonic()
        if key in self._seen:
            return
        self._seen.add(key)
        self._seen_order.append((key, now))
        if len(self._seen_order) > self._seen_cap:
            old_key, _ts = self._seen_order.popleft()
            self._seen.discard(old_key)

    def _prune_expired(self) -> None:
        """Evict entries older than the idempotency window.

        Cheap amortised: we only prune entries that crossed the window,
        not the whole set on every call. Bound is the cap so memory is
        always O(cap).
        """
        if not self._seen_order:
            return
        horizon = time.monotonic() - self._config.idempotency_window_seconds
        while self._seen_order and self._seen_order[0][1] < horizon:
            old_key, _ts = self._seen_order.popleft()
            self._seen.discard(old_key)


# ── Adapter facade ─────────────────────────────────────────────────────────


@dataclass
class RevisionSyncAdapter:
    """Opaque wrapper bundling the publisher + subscriber for a daemon.

    The daemon holds one of these when multi-node sync is active. Tests
    can inject a fake one with both halves stubbed. The adapter exposes
    the minimum surface the daemon needs:

      * ``publish_revision`` / ``publish_branch_*`` -- thin passthroughs.
      * ``start`` / ``stop`` -- subscriber lifecycle.
      * ``health`` -- whatever the daemon wants to surface in ``op_health``.

    Attribute access is intentional: no behaviour beyond delegation, so
    the adapter doesn't bury the implementation and tests can reach
    through to the inner objects when needed.
    """

    publisher: RevisionSyncPublisher
    subscriber: RevisionSyncSubscriber

    @property
    def client_id(self) -> str:
        return self.publisher.client_id

    def start(self) -> None:
        self.subscriber.start()

    def stop(self, timeout: float = 2.0) -> None:
        self.subscriber.stop(timeout=timeout)
        self.publisher.close()

    # ── publish passthroughs ───────────────────────────────────────────

    def publish_revision(self, revision: PolicyRevision) -> None:
        self.publisher.publish_revision(revision)

    def publish_branch_create(self, branch: Branch) -> None:
        self.publisher.publish_branch_create(branch)

    def publish_branch_checkout(self, name: str) -> None:
        self.publisher.publish_branch_checkout(name)

    def publish_branch_merge(
        self,
        *,
        src: str,
        dst: str,
        merge_kind: str,
        new_head_revision_id: Optional[str],
        reviewer: str,
        merge_revision: Optional[PolicyRevision] = None,
    ) -> None:
        self.publisher.publish_branch_merge(
            src=src,
            dst=dst,
            merge_kind=merge_kind,
            new_head_revision_id=new_head_revision_id,
            reviewer=reviewer,
            merge_revision=merge_revision,
        )

    def health(self) -> dict[str, Any]:
        return {
            "connected": self.subscriber.connected(),
            "subscriber_lag_ms": self.subscriber.subscriber_lag_ms(),
            "channel": self.publisher.channel,
            "client_id": self.client_id,
        }


# ── Factory ────────────────────────────────────────────────────────────────


def build_revision_sync(
    config: SyncConfig,
    log: RevisionLog,
    *,
    registry_lock: Optional[threading.Lock] = None,
    callback: Optional[ApplyCallback] = None,
    redis_client: Any = None,
    preflight: bool = True,
) -> RevisionSyncAdapter:
    """Construct a wired ``RevisionSyncAdapter``.

    Preflight is fail-closed by default: we PING Redis (via the publisher
    client) so the CLI can surface a clean error before the daemon opens
    its UDS. Tests using an injected ``redis_client`` can skip preflight
    by passing ``preflight=False`` (fakeredis answers PING, but some
    integration fakes may not).

    ``registry_lock`` should be the daemon's own lock; shared-lock semantics
    keep subscriber-applied mutations from interleaving with local ops.
    """
    client_id = config.resolved_client_id()
    # Build the publisher first so preflight ping runs inside its build.
    publisher = RevisionSyncPublisher(config, redis_client=redis_client)
    if preflight:
        try:
            ok = publisher._client.ping()
        except Exception as exc:  # noqa: BLE001
            raise RevisionSyncError(
                f"redis unreachable at {config.url!r}: {exc}. Refusing to "
                f"start with silent in-memory fallback; fix Redis or unset "
                f"TAU_CAGE_REVISION_SYNC_REDIS_URL."
            ) from exc
        if not ok:
            raise RevisionSyncError(
                f"redis PING returned falsy at {config.url!r}; aborting"
            )
    subscriber = RevisionSyncSubscriber(
        config,
        log,
        registry_lock=registry_lock,
        callback=callback,
        redis_client=redis_client,
        own_client_id=client_id,
    )
    return RevisionSyncAdapter(publisher=publisher, subscriber=subscriber)


# ── module-private helpers ─────────────────────────────────────────────────


def _build_redis_client(url: str) -> Any:
    """Construct a redis-py client. Fail-closed on import errors."""
    if not url:
        raise RevisionSyncError(
            "revision_sync requires a non-empty URL (or an injected redis_client)"
        )
    try:
        import redis  # type: ignore[import-untyped]
    except ImportError as exc:
        raise RevisionSyncError(
            "revision_sync needs the `redis` package. "
            "Install with: pip install 'tau-x402-cage[sync-redis]'"
        ) from exc
    try:
        return redis.Redis.from_url(
            url,
            decode_responses=True,
            socket_connect_timeout=2.0,
        )
    except Exception as exc:  # noqa: BLE001 -- redis.from_url is strict
        raise RevisionSyncError(
            f"could not construct redis client for url={url!r}: {exc}"
        ) from exc


def _stable_hash(d: dict[str, Any]) -> str:
    """Content-address a dict by its sorted-keys JSON form.

    Used to key branch / checkout records in the idempotency set so
    re-deliveries don't double-apply. Short sha256 prefix (16 hex chars)
    keeps the set keys compact without meaningfully raising collision
    risk in a per-replica bounded window.
    """
    line = json.dumps(d, sort_keys=True, ensure_ascii=False)
    return hashlib.sha256(line.encode("utf-8")).hexdigest()[:16]
