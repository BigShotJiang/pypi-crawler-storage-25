"""Shim surface for v0.19.0 Guaranteed Mode (D6/D8 agent slice).

Agents 1-3 own the real implementations of the language/prover/runtime/
mutation modules (``guaranteed_language``, ``guaranteed_prover``,
``guaranteed_proof_artifact``, ``guaranteed_runtime``,
``guaranteed_mutation``, ``guaranteed_errors``). Until they merge, this
module provides minimal, strict dataclasses + functions so the audit
evidence path (D6) and the bank-evaluation demo (D8) have something
concrete to integrate against.

When agents 1-3 land their PRs, delete this file and delete the
``try / except ImportError`` fallback at the top of
``adapter/guaranteed_audit_integration.py``.

TODO(integration): remove after v0.19.0 language/prover/runtime/mutation merges.

Design notes
------------

* The shapes here intentionally mirror what D1-D5 agents declared in
  the dispatch brief (ProofArtifact with artifact_id + content hash;
  runtime emits GuaranteedDecision; mutation uses NoWeakening).
* The shim prover is **not** a real prover. It returns ``proven`` for
  any registry + totality-passing input and deterministically rejects
  weakening mutations. This is enough to exercise the audit chain.
* We keep enums as string literals (``proven`` / ``refuted`` /
  ``unknown``) so the agent 1-3 PRs can promote them to ``enum.Enum``
  without breaking wire shape.
"""

from __future__ import annotations

import hashlib
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from decimal import Decimal
from typing import Any, Dict, List, Literal, Mapping, Optional, Sequence, Tuple

from adapter.invariants import (
    Invariant,
    MaxPerCall,
    ProviderAllowlist,
    SpendingCap,
    Violation,
)
from adapter.payment_intent_matcher import PaymentIntent
from adapter.x402_registry import X402Registry


#: Shim language/prover version strings stamped into evidence records.
GUARANTEED_LANGUAGE_VERSION = "shim-tier-1"
GUARANTEED_PROVER_VERSION = "shim-prover-0.1"


# ── failure codes (agents 1-3 provide the real enum in guaranteed_errors) ──


class GuaranteedFailureCode:
    """Named failure codes mirroring the eventual ``guaranteed_errors`` enum."""

    POLICY_NOT_GUARANTEED = "POLICY_NOT_GUARANTEED"
    PROOF_REFUTED = "PROOF_REFUTED"
    PROOF_UNKNOWN = "PROOF_UNKNOWN"
    TOTALITY_FAILED = "TOTALITY_FAILED"
    RUNTIME_GUARD_VIOLATION = "RUNTIME_GUARD_VIOLATION"
    MUTATION_WEAKENS_SAFETY = "MUTATION_WEAKENS_SAFETY"
    MUTATION_ACTOR_REJECTED = "MUTATION_ACTOR_REJECTED"


@dataclass(frozen=True)
class GuaranteedFailure(Exception):
    """Raised when a guaranteed-mode check fails for a known reason."""

    code: str
    message: str

    def __str__(self) -> str:  # noqa: D401 - standard dunder
        return f"[{self.code}] {self.message}"


# ── proof artifacts ────────────────────────────────────────────────────────


def _canonical_invariant_repr(inv: Invariant) -> str:
    """Stable string representation of an invariant for hashing.

    Mirrors what ``policy_revision._serialize_invariant`` would yield so
    two runs of the shim produce identical hashes over the same policy.
    """
    fields: List[str] = [type(inv).__name__]
    for slot in sorted(vars(inv).keys()):
        val = getattr(inv, slot)
        if isinstance(val, Decimal):
            val = str(val)
        elif isinstance(val, frozenset):
            val = sorted(val)
        fields.append(f"{slot}={val}")
    return "|".join(fields)


@dataclass(frozen=True)
class GuaranteedProofArtifact:
    """Compact record of a guaranteed-mode admission decision.

    Agents 1-3 will extend this with the pure-Tau proof token, a Z3
    witness when relevant, and the exact prover call trace. The shim
    keeps just enough for the audit chain to record provenance.
    """

    artifact_id: str
    compile_hash: str
    proof_result: Literal["proven", "refuted", "unknown"]
    backend: str
    totality_status: str
    witness: Optional[str] = None
    source_hash: str = ""

    @property
    def short_content_hash(self) -> str:
        """First 12 hex chars of ``compile_hash`` — enough to tie an
        evidence record to an artifact without duplicating the full hash
        in every decision row."""
        return self.compile_hash[:12]

    @property
    def reference(self) -> str:
        """``<artifact_id>:<short-content-hash>`` — the shape
        :class:`RuntimeDecisionEvidence.proof_artifact_reference` expects."""
        return f"{self.artifact_id}:{self.short_content_hash}"


class ProofArtifactStore:
    """In-memory artifact store; agent-2 will persist to disk.

    Acts like a dict-of-artifact_id and keeps the surface minimal so
    later replacements don't have to preserve internal accessors.
    """

    def __init__(self) -> None:
        self._by_id: Dict[str, GuaranteedProofArtifact] = {}

    def put(self, artifact: GuaranteedProofArtifact) -> None:
        if not isinstance(artifact, GuaranteedProofArtifact):
            raise TypeError(
                f"store.put expected GuaranteedProofArtifact, got {type(artifact).__name__}"
            )
        self._by_id[artifact.artifact_id] = artifact

    def get(self, artifact_id: str) -> Optional[GuaranteedProofArtifact]:
        return self._by_id.get(artifact_id)

    def __len__(self) -> int:
        return len(self._by_id)


# ── language / prover ──────────────────────────────────────────────────────


class GuaranteedLanguage:
    """Shim wrapper over a subset of fragment-v1 invariants.

    Agent-1 ships the real totality + termination checks. The shim
    declares the invariant types the D6/D8 slice exercises as
    "totality-passing" and anything else as ``skipped``.
    """

    _TOTAL_TYPES = (SpendingCap, MaxPerCall, ProviderAllowlist)

    def is_total(self, invariants: Sequence[Invariant]) -> Tuple[bool, str]:
        """Check totality of a set of invariants.

        Returns ``(passed, reason)``:
          * ``(True, "passed")`` when every invariant is in the
            guaranteed-totality subset.
          * ``(False, "skipped: <class-name>")`` when a non-covered
            invariant appears. Shim policy: don't reject outright, just
            flag as ``skipped`` so the audit record reflects the gap.
        """
        for inv in invariants:
            if not isinstance(inv, self._TOTAL_TYPES):
                return (False, f"skipped: {type(inv).__name__}")
        return (True, "passed")


class GuaranteedProver:
    """Shim prover that records admission decisions as artifacts.

    Always returns ``proven`` for fragment-v1 invariants. Agents 2/3
    replace with the real pure-Tau + totality chain.
    """

    def __init__(self, *, artifact_store: Optional[ProofArtifactStore] = None) -> None:
        self._artifacts = artifact_store or ProofArtifactStore()

    @property
    def artifacts(self) -> ProofArtifactStore:
        return self._artifacts

    def prove_admission(
        self,
        *,
        policy_id: str,
        revision_id: str,
        invariants: Sequence[Invariant],
        policy_source: str,
    ) -> GuaranteedProofArtifact:
        """Attempt admission proof; produce an artifact on every outcome.

        The totality-check outcome is recorded but does not block
        admission — the shim lets ``skipped`` admissions through so the
        bank demo can show the evidence record shape. Agent-1's real
        implementation will reject on ``skipped`` in strict mode.
        """
        language = GuaranteedLanguage()
        total_ok, reason = language.is_total(invariants)
        totality_status = "passed" if total_ok else ("skipped" if reason.startswith("skipped:") else "failed")

        compile_hash = hashlib.sha256(
            ("|".join(_canonical_invariant_repr(i) for i in invariants)).encode("utf-8")
        ).hexdigest()
        source_hash = hashlib.sha256(policy_source.encode("utf-8")).hexdigest()
        artifact = GuaranteedProofArtifact(
            artifact_id=str(uuid.uuid4()),
            compile_hash=compile_hash,
            proof_result="proven",
            backend=GUARANTEED_PROVER_VERSION,
            totality_status=totality_status,
            witness=None,
            source_hash=source_hash,
        )
        self._artifacts.put(artifact)
        return artifact


# ── runtime ────────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class GuaranteedDecision:
    """A single runtime verdict in guaranteed mode.

    Matches the wire shape agents 1-3 will emit. Includes a deterministic
    explanation string so the bank demo can print it verbatim and the
    audit record can bind it into evidence without reformatting.
    """

    allow: bool
    reason: str
    explanation: str
    decision_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    guard_state_summary: Mapping[str, Any] = field(default_factory=dict)


def _summarise_guard_state(
    registry: X402Registry,
    history: Sequence[PaymentIntent],
    intent: PaymentIntent,
) -> Dict[str, Any]:
    """Hash-stable snapshot of the guard counters for the intent's window.

    Deliberately excludes full history. Only per-rule counters + caps go
    into the audit record. Key order is alphabetical after JSON
    canonicalisation, so the returned dict is safe to hash repeatedly.
    """
    summary: Dict[str, Any] = {
        "intent_amount": str(intent.amount),
        "intent_currency": intent.currency,
        "intent_provider": intent.provider,
        "history_size": len(history),
    }
    for inv in registry.invariants:
        name = type(inv).__name__
        if isinstance(inv, SpendingCap):
            cutoff = intent.timestamp_unix - (inv.window_seconds or 0)
            cumul = sum(
                (p.amount for p in history
                 if p.currency == inv.currency
                 and p.timestamp_unix >= cutoff),
                Decimal("0"),
            )
            summary[f"{name}_cap_{inv.scope}"] = str(inv.max_amount)
            summary[f"{name}_cumulative_{inv.scope}"] = str(cumul)
        elif isinstance(inv, MaxPerCall):
            summary[f"{name}_max"] = str(inv.max_amount)
        elif isinstance(inv, ProviderAllowlist):
            summary[f"{name}_size"] = len(inv.providers)
    return summary


def guaranteed_should_pay_x402(
    *,
    intent: PaymentIntent,
    registry: X402Registry,
    policy_revision_id: str,
    proof_artifact: GuaranteedProofArtifact,
    history: Sequence[PaymentIntent] = (),
) -> GuaranteedDecision:
    """Guaranteed-mode runtime check for a single payment intent.

    Mirrors ``should_pay_x402`` but:
      * refuses to run unless the proof artifact is ``proven`` + the
        policy revision matches (can't smuggle a different registry in).
      * includes a ``guard_state_summary`` hash-stable snapshot so the
        evidence record is reproducible.
      * always produces a deterministic explanation.
    """
    if proof_artifact.proof_result != "proven":
        raise GuaranteedFailure(
            code=GuaranteedFailureCode.POLICY_NOT_GUARANTEED,
            message=(
                f"proof artifact {proof_artifact.artifact_id} has "
                f"proof_result={proof_artifact.proof_result!r}; "
                f"guaranteed mode requires 'proven'"
            ),
        )
    violation: Optional[Violation] = registry.check_payment(intent, history)
    guard_state = _summarise_guard_state(registry, history, intent)
    if violation is None:
        return GuaranteedDecision(
            allow=True,
            reason="allow",
            explanation=(
                f"Guaranteed-mode: intent for "
                f"{intent.amount} {intent.currency} to {intent.provider} "
                f"satisfied every rule in revision {policy_revision_id}."
            ),
            guard_state_summary=guard_state,
        )
    return GuaranteedDecision(
        allow=False,
        reason=GuaranteedFailureCode.RUNTIME_GUARD_VIOLATION,
        explanation=(
            f"Guaranteed-mode: rule {violation.rule_id} rejected the intent. "
            f"{violation.reason_text}"
        ),
        guard_state_summary=guard_state,
    )


# ── mutation pipeline ──────────────────────────────────────────────────────


@dataclass(frozen=True)
class MutationProposal:
    """Shim proposal: 'here is the new invariant set I want to admit'."""

    proposed_invariants: Tuple[Invariant, ...]
    actor_id: Optional[str] = None
    approval_token: Optional[str] = None


@dataclass(frozen=True)
class MutationOutcome:
    """Outcome of a mutation pipeline run.

    Agents 4/5 ship the full pipeline with multi-stage proofs; the shim
    exercises only the ``NoWeakening`` gate, which is enough to
    demonstrate the audit trail on a rejected mutation.
    """

    accepted: bool
    reason: str
    explanation: str
    resulting_artifact: Optional[GuaranteedProofArtifact] = None


class GuaranteedMutationPipeline:
    """Strict mutation pipeline: reject anything that weakens safety.

    The shim only recognises ``SpendingCap.max_amount`` and
    ``MaxPerCall.max_amount`` as safety-bearing scalar knobs. Raising
    either without an approval_token is classified as weakening and
    rejected. Tightening is always allowed.
    """

    def __init__(self, prover: GuaranteedProver) -> None:
        self._prover = prover

    def propose(
        self,
        *,
        current_invariants: Sequence[Invariant],
        proposal: MutationProposal,
        policy_id: str,
        new_revision_id: str,
        new_policy_source: str,
    ) -> MutationOutcome:
        """Run the no-weakening check and (if accepted) produce a new artifact."""
        weakens_reason = self._weakens_safety(current_invariants, proposal.proposed_invariants)
        if weakens_reason is not None and proposal.approval_token is None:
            return MutationOutcome(
                accepted=False,
                reason=GuaranteedFailureCode.MUTATION_WEAKENS_SAFETY,
                explanation=(
                    f"NoWeakening rejected mutation: {weakens_reason}. "
                    f"Supply an explicit approval_token to override "
                    f"(not recommended for production policies)."
                ),
            )
        artifact = self._prover.prove_admission(
            policy_id=policy_id,
            revision_id=new_revision_id,
            invariants=tuple(proposal.proposed_invariants),
            policy_source=new_policy_source,
        )
        return MutationOutcome(
            accepted=True,
            reason="admitted",
            explanation=(
                f"Mutation admitted; new artifact "
                f"{artifact.artifact_id} proves the updated registry."
            ),
            resulting_artifact=artifact,
        )

    @staticmethod
    def _weakens_safety(
        current: Sequence[Invariant], proposed: Sequence[Invariant],
    ) -> Optional[str]:
        """Return a human-readable reason string when the proposal weakens
        safety, else None.

        Only scalar cap-raising counts as weakening here. Removing an
        invariant entirely is a separate classification the agents 4/5
        module will cover; the shim flags the canonical "raise per_tx cap"
        case the bank demo exercises.
        """
        def by_cls_scope(rs: Sequence[Invariant]) -> Dict[tuple, Invariant]:
            out: Dict[tuple, Invariant] = {}
            for r in rs:
                if isinstance(r, SpendingCap):
                    out[("SpendingCap", r.scope, r.currency, r.provider)] = r
                elif isinstance(r, MaxPerCall):
                    out[("MaxPerCall", r.currency)] = r
            return out

        cur_map = by_cls_scope(current)
        new_map = by_cls_scope(proposed)
        for key, new_rule in new_map.items():
            if key not in cur_map:
                continue
            old_rule = cur_map[key]
            old_cap = getattr(old_rule, "max_amount", None)
            new_cap = getattr(new_rule, "max_amount", None)
            if old_cap is None or new_cap is None:
                continue
            if new_cap > old_cap:
                return (
                    f"{key[0]} {key[1:]} cap raised from {old_cap} to {new_cap}"
                )
        return None


# ── evidence builders ──────────────────────────────────────────────────────


def build_admission_evidence(
    *,
    policy_id: str,
    revision_id: str,
    policy_source: str,
    artifact: GuaranteedProofArtifact,
    admitted_by: Optional[str] = None,
    prove_timestamp: Optional[datetime] = None,
    admitted_at: Optional[datetime] = None,
):
    """Build a :class:`PolicyAdmissionEvidence` from the shim surface.

    Late import to avoid a circular module graph (guaranteed_audit
    imports from us at demo time via the integration path).
    """
    from adapter.guaranteed_audit import PolicyAdmissionEvidence

    now = datetime.now(tz=timezone.utc)
    return PolicyAdmissionEvidence(
        policy_id=policy_id,
        revision_id=revision_id,
        policy_source_hash=artifact.source_hash or hashlib.sha256(policy_source.encode()).hexdigest(),
        compile_hash=artifact.compile_hash,
        proof_result=artifact.proof_result,
        prove_backend_version=artifact.backend,
        prove_timestamp=prove_timestamp or now,
        totality_status=artifact.totality_status,
        language_tier_version=GUARANTEED_LANGUAGE_VERSION,
        admitted_at=admitted_at or now,
        admitted_by=admitted_by,
    )


def build_decision_evidence(
    *,
    intent: PaymentIntent,
    decision: GuaranteedDecision,
    policy_revision_id: str,
    artifact: GuaranteedProofArtifact,
    decision_timestamp: Optional[datetime] = None,
):
    """Build a :class:`RuntimeDecisionEvidence` from the shim surface."""
    from adapter.guaranteed_audit import RuntimeDecisionEvidence
    from adapter.verdict_signer import hash_intent

    return RuntimeDecisionEvidence(
        decision_id=decision.decision_id,
        payment_intent_hash=hash_intent(intent),
        policy_revision_used=policy_revision_id,
        proof_mode="guaranteed",
        proof_artifact_reference=artifact.reference,
        guard_state_summary=decision.guard_state_summary,
        allow=decision.allow,
        reason=decision.reason,
        explanation=decision.explanation,
        decision_timestamp=decision_timestamp or datetime.now(tz=timezone.utc),
    )
