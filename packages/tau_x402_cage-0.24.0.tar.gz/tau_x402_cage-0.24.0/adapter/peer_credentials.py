"""Kernel-verified peer credentials over Unix domain sockets (v0.22.0).

The daemon's UDS endpoint needs to answer "who am I talking to?" at the
syscall boundary — not by trusting a client-supplied JSON field. Two
portable calls do this:

  * Linux: ``getsockopt(SOL_SOCKET, SO_PEERCRED)`` → struct ucred
    ``(pid: u32, uid: u32, gid: u32)``
  * macOS: ``getsockopt(SOL_LOCAL, LOCAL_PEERCRED)`` → struct xucred
    ``(version: u32, uid: u32, ngroups: u16, groups[16]: u32)``

macOS does not have ``SOL_LOCAL`` exposed on the socket module, but its
numeric value is 0 and ``socket.LOCAL_PEERCRED`` is defined on Darwin
builds of CPython. Additionally, ``getpeereid(2)`` returns
``(uid, gid)`` via a libc call and is the documented macOS idiom; we
use it as a fallback when ``LOCAL_PEERCRED`` is not available or
returns a malformed xucred.

The module is pure-structure: lookup returns a :class:`PeerCredentials`
value (or ``None`` when the kernel declined). Callers decide what to do
with a ``None`` — in the cage daemon, a meta-policy with
``require_peer_uid=True`` rejects such connections.

Tests mock :func:`lookup_peer_credentials` rather than constructing real
sockets so they don't depend on a second process; that's intentional.
"""
from __future__ import annotations

import os
import socket
import struct
import sys
from dataclasses import dataclass
from typing import Optional

__all__ = [
    "PeerCredentials",
    "lookup_peer_credentials",
    "peer_credentials_available",
]


@dataclass(frozen=True)
class PeerCredentials:
    """Kernel-reported identity of the peer on a UDS connection.

    ``pid`` is populated on Linux (SO_PEERCRED) but not on macOS
    (LOCAL_PEERCRED / getpeereid do not return a pid). Callers that
    require a pid for mutation attribution should fail closed on
    ``None``.
    """

    uid: int
    gid: Optional[int] = None
    pid: Optional[int] = None
    source: str = "unknown"  # "SO_PEERCRED" / "LOCAL_PEERCRED" / "getpeereid"


def peer_credentials_available() -> bool:
    """Return True iff this platform exposes a peer-cred lookup we support.

    A False return does NOT mean the daemon cannot run — it means the
    daemon will treat every connection as ``peer_uid=None`` and a
    PeerAuthenticationPolicy with ``require_peer_uid=True`` will reject
    everything. Operators should only disable ``require_peer_uid`` after
    they have verified the host kernel really cannot report creds.
    """
    if sys.platform.startswith("linux"):
        return hasattr(socket, "SO_PEERCRED")
    if sys.platform == "darwin":
        return hasattr(socket, "LOCAL_PEERCRED") or _getpeereid_available()
    return False


def lookup_peer_credentials(
    conn: socket.socket,
) -> Optional[PeerCredentials]:
    """Look up the peer credentials for an accepted UDS connection.

    Returns ``None`` when no reliable credential can be obtained. Never
    raises — failure modes include kernel support missing, socket
    already closed, or the struct returning a zero version (macOS
    ``xucred`` returns ``version=0`` when no creds are available).

    Args:
        conn: an ``AF_UNIX`` / ``SOCK_STREAM`` socket accepted from a
            :class:`socketserver.UnixStreamServer`-derived server.
    """
    if not isinstance(conn, socket.socket):
        return None

    if sys.platform.startswith("linux"):
        return _lookup_linux(conn)
    if sys.platform == "darwin":
        creds = _lookup_darwin_peercred(conn)
        if creds is not None:
            return creds
        return _lookup_darwin_getpeereid(conn)
    return None


# ── Linux ──────────────────────────────────────────────────────────────────


def _lookup_linux(conn: socket.socket) -> Optional[PeerCredentials]:
    """SO_PEERCRED returns ``struct ucred`` — 3 x u32 (pid, uid, gid)."""
    try:
        data = conn.getsockopt(
            socket.SOL_SOCKET,
            socket.SO_PEERCRED,  # type: ignore[attr-defined]
            struct.calcsize("3i"),
        )
    except (OSError, AttributeError):
        return None
    if len(data) < struct.calcsize("3i"):
        return None
    pid, uid, gid = struct.unpack("3i", data)
    return PeerCredentials(
        uid=int(uid), gid=int(gid), pid=int(pid), source="SO_PEERCRED",
    )


# ── macOS ──────────────────────────────────────────────────────────────────


# macOS's LOCAL protocol level is 0 in practice. ``socket.SOL_LOCAL`` is
# not exposed on CPython's Darwin build, but all documented examples use
# 0 directly. We guard the call with a try/except and fall through to
# getpeereid on any failure.
_DARWIN_SOL_LOCAL = 0


def _lookup_darwin_peercred(conn: socket.socket) -> Optional[PeerCredentials]:
    """LOCAL_PEERCRED returns ``struct xucred``.

    xucred layout (mach-style, little-endian on all current Apple Silicon
    and Intel Macs):
        u_int   cr_version       (== XUCRED_VERSION == 0, always)
        uid_t   cr_uid            (u32)
        short   cr_ngroups
        gid_t   cr_groups[16]

    We only care about ``cr_uid``. ``cr_version`` is always 0, so we
    cannot use it as a sentinel; we validate that the returned buffer is
    at least 8 bytes (version + uid).
    """
    if not hasattr(socket, "LOCAL_PEERCRED"):
        return None
    try:
        data = conn.getsockopt(
            _DARWIN_SOL_LOCAL,
            socket.LOCAL_PEERCRED,  # type: ignore[attr-defined]
            76,  # xucred is 76 bytes; ample buffer.
        )
    except (OSError, AttributeError):
        return None
    if len(data) < 8:
        return None
    _version, uid = struct.unpack_from("II", data, 0)
    return PeerCredentials(
        uid=int(uid), gid=None, pid=None, source="LOCAL_PEERCRED",
    )


def _lookup_darwin_getpeereid(
    conn: socket.socket,
) -> Optional[PeerCredentials]:
    """``int getpeereid(int s, uid_t *euid, gid_t *egid)`` via ctypes.

    Recommended macOS API; stable across versions. Returns 0 on success.
    """
    try:
        import ctypes  # local import: only needed on Darwin fallback.

        libc = ctypes.CDLL("libc.dylib")
        libc.getpeereid.argtypes = [
            ctypes.c_int,
            ctypes.POINTER(ctypes.c_uint32),
            ctypes.POINTER(ctypes.c_uint32),
        ]
        libc.getpeereid.restype = ctypes.c_int
        uid = ctypes.c_uint32()
        gid = ctypes.c_uint32()
        ret = libc.getpeereid(conn.fileno(), ctypes.byref(uid), ctypes.byref(gid))
        if ret != 0:
            return None
        return PeerCredentials(
            uid=int(uid.value),
            gid=int(gid.value),
            pid=None,
            source="getpeereid",
        )
    except Exception:  # noqa: BLE001 — ctypes/lib errors → None.
        return None


def _getpeereid_available() -> bool:
    try:
        import ctypes  # noqa: F401

        libc = ctypes.CDLL("libc.dylib")
        return hasattr(libc, "getpeereid")
    except Exception:  # noqa: BLE001
        return False
