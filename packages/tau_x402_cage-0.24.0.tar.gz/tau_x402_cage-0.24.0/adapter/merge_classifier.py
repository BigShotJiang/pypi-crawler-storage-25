"""Semantic merge-conflict classification (v0.14.0).

A raw ``BranchMergeConflict`` names the invariant classes both branches touched
but does not explain *why* the merge failed. When an operator is deciding
whether to force a merge, retract one side, or escalate to the author, they
want to see:

  * **syntactic** — same invariant, identical shape, trivial difference
    (whitespace / ordering). Should never happen in practice because
    content-addressed deltas deduplicate identical invariants before the
    classifier runs, but we keep defensive code here so the taxonomy is
    complete.
  * **semantic** — same invariant class, genuinely different values. E.g.
    ``SpendingCap($100)`` on one branch vs ``SpendingCap($50)`` on the other
    for the same provider. The operator's job is to pick which value to
    keep.
  * **temporal** — at least one side introduced a *temporal* invariant
    (RetryRateLimit, RollingWindowCap, per-window SpendingCap,
    InstabilityGuard). These overlap on the same time window with
    incompatible constraints; merging them without human review risks a
    "tighter when you expected looser" surprise.
  * **unsupported_fragment** — one side introduces a fragment-v2 invariant
    that the other branch's prover chain cannot compose. Merging would
    produce a policy the active deployment cannot actually decide.

Design notes:

  * **Pure function, no I/O, no mutation.** ``classify_conflict`` returns a
    list of new ``ClassifiedConflict`` instances. Inputs are the two deltas
    and the ancestor invariant set; the classifier never touches a
    ``RevisionLog``. Mirrors the immutability rule in
    ``common/coding-style.md``: every result is a new dataclass.
  * **Serialized inputs, not live Invariant instances.** Callers pass the
    ``{added, removed}`` dict shape that ``PolicyRevision.delta`` uses. We
    rehydrate just enough to call ``is_fragment_v2_invariant`` so the
    fragment detection always matches the prover's view.
  * **Category precedence when ambiguous.** A class may technically qualify
    for several categories; we pick the most informative one in this
    priority order:

        unsupported_fragment  >  temporal  >  syntactic  >  semantic

    so operators see the hardest gate first.

See ``docs/revision_branching.md`` for the taxonomy + examples and
``adapter/conflict_renderer.py`` for the CLI presentation wiring.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Dict, List, Literal, Optional, Sequence

from adapter.policy_revision import _rehydrate_invariant


# ── taxonomy ─────────────────────────────────────────────────────────────────


ConflictCategory = Literal[
    "syntactic",
    "semantic",
    "temporal",
    "unsupported_fragment",
]


#: Ordering used when a single class could match more than one category. The
#: classifier picks the first match walking this tuple.
_CATEGORY_PRIORITY: tuple[ConflictCategory, ...] = (
    "unsupported_fragment",
    "temporal",
    "syntactic",
    "semantic",
)


@dataclass(frozen=True)
class ClassifiedConflict:
    """One classified entry in a ``BranchMergeConflict``'s conflict list.

    Fields:
        class_name       : invariant class name that conflicts.
        category         : the taxonomy bucket (see module docstring).
        src_inv          : representative source-side invariant (serialized
                           ``{class_name, repr}`` dict) or ``None`` if the
                           source side only removed this class.
        dst_inv          : representative destination-side invariant or
                           ``None`` if the destination side only removed.
        diagnosis        : plain-English one-liner naming the offending
                           values. Safe to surface in UI / webhooks /
                           CLI output.
        suggested_repair : optional one-liner hint ("retract the branch
                           $X copy first"). None when no safe automatic
                           hint applies.
    """

    class_name: str
    category: ConflictCategory
    src_inv: Optional[Dict[str, Any]] = None
    dst_inv: Optional[Dict[str, Any]] = None
    diagnosis: str = ""
    suggested_repair: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """JSON-safe dict mirror; ``None`` fields are emitted as ``null``
        so downstream JSON consumers see a stable shape."""
        return {
            "class_name": self.class_name,
            "category": self.category,
            "src_inv": dict(self.src_inv) if self.src_inv is not None else None,
            "dst_inv": dict(self.dst_inv) if self.dst_inv is not None else None,
            "diagnosis": self.diagnosis,
            "suggested_repair": self.suggested_repair,
        }


# ── fragment-v2 detection (thin wrapper over tau_compiler/z3_compiler) ──────


def _entry_is_fragment_v2(entry: Dict[str, Any]) -> bool:
    """Return True iff a serialized invariant entry is a fragment-v2 rule.

    The canonical detector lives in ``adapter.z3_compiler`` and operates on
    live ``Invariant`` instances. The classifier takes the serialized
    ``{class_name, repr}`` shape off the wire, so we rehydrate just to
    reuse that detector. Rehydration cost is negligible — classifier runs
    only on merge conflicts, not on the hot path.

    Defensive: any rehydration failure (e.g. unknown class, malformed
    repr) is treated as "not v2" rather than raising, so a corrupt
    delta degrades into a ``semantic`` classification instead of
    crashing the merge op.
    """
    if not isinstance(entry, dict):
        return False
    try:
        inv = _rehydrate_invariant(entry)
    except Exception:  # noqa: BLE001 — defensive over any rehydration error.
        return False
    try:
        from adapter.z3_compiler import is_fragment_v2_invariant
    except Exception:  # noqa: BLE001 — z3_compiler pulls imports we may lack.
        return False
    try:
        return bool(is_fragment_v2_invariant(inv))
    except Exception:  # noqa: BLE001 — treat detector failure as "not v2".
        return False


def _repr_key(entry: Dict[str, Any]) -> Optional[str]:
    """Deterministic string key for an invariant's ``repr`` payload.

    Two entries with the same key represent the SAME concrete invariant
    (modulo JSON dict key ordering, which ``sort_keys=True`` normalises).
    Used to detect the rare "syntactic" case: both sides added an
    identical invariant but the conflict detector still flagged the
    class. Returns None on malformed entries.
    """
    if not isinstance(entry, dict):
        return None
    repr_d = entry.get("repr")
    if not isinstance(repr_d, dict):
        return None
    try:
        return json.dumps(repr_d, sort_keys=True)
    except (TypeError, ValueError):
        return None


# ── per-class collectors ────────────────────────────────────────────────────


def _group_by_class(
    entries: Sequence[Dict[str, Any]],
    class_name: str,
) -> List[Dict[str, Any]]:
    """Return every entry in ``entries`` whose ``class_name`` matches.

    Defensive: skips non-dict entries, stops at class-name mismatch, never
    raises. Mirrors ``conflict_renderer._invariants_by_class`` but targets
    a single class so the classifier doesn't build a full index.
    """
    out: List[Dict[str, Any]] = []
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        if entry.get("class_name") == class_name:
            out.append(entry)
    return out


def _pick_representative(
    added: Sequence[Dict[str, Any]],
    removed: Sequence[Dict[str, Any]],
) -> Optional[Dict[str, Any]]:
    """Choose a representative entry for a side's involvement in a class.

    Prefers an ``added`` entry because that's the value the side is
    actively proposing. Falls back to a ``removed`` entry when the side's
    only operation was a retraction. Returns ``None`` when the side is
    empty (treated as "didn't touch this class").
    """
    if added:
        return added[0]
    if removed:
        return removed[0]
    return None


# ── classification primitives ───────────────────────────────────────────────


def _is_syntactic_only(
    src_added: Sequence[Dict[str, Any]],
    src_removed: Sequence[Dict[str, Any]],
    dst_added: Sequence[Dict[str, Any]],
    dst_removed: Sequence[Dict[str, Any]],
) -> bool:
    """True iff both sides touched this class with IDENTICAL invariants.

    This should not produce a conflict in practice because
    ``_find_conflicting_invariants`` short-circuits identical add/add
    pairs. We still detect it defensively so the taxonomy is complete
    when a future ancestor interaction fabricates such a case.
    """
    src_add_keys = {_repr_key(e) for e in src_added if _repr_key(e) is not None}
    dst_add_keys = {_repr_key(e) for e in dst_added if _repr_key(e) is not None}
    src_rem_keys = {_repr_key(e) for e in src_removed if _repr_key(e) is not None}
    dst_rem_keys = {_repr_key(e) for e in dst_removed if _repr_key(e) is not None}
    return (
        bool(src_add_keys or src_rem_keys or dst_add_keys or dst_rem_keys)
        and src_add_keys == dst_add_keys
        and src_rem_keys == dst_rem_keys
    )


def _any_is_temporal(*entry_groups: Sequence[Dict[str, Any]]) -> bool:
    """True iff at least one entry across ``entry_groups`` is fragment-v2.

    Fragment v2 membership is our working proxy for "temporal" because
    every v2 invariant carries a time-window predicate (per_window cap,
    rolling count, retry gap, instability guard). Fragment v1 invariants
    (MaxPerCall, ProviderAllowlist, etc.) are purely per-intent and have
    no temporal overlap to reason about.
    """
    for group in entry_groups:
        for entry in group:
            if _entry_is_fragment_v2(entry):
                return True
    return False


def _has_unsupported_fragment(
    *entry_groups: Sequence[Dict[str, Any]],
    prover_supports_v2: bool,
) -> bool:
    """True iff at least one side contributed a v2 rule the deployment
    cannot prove. Only meaningful when ``prover_supports_v2`` is False.
    """
    if prover_supports_v2:
        return False
    return _any_is_temporal(*entry_groups)


# ── diagnosis writers ───────────────────────────────────────────────────────


def _describe_inline(entry: Dict[str, Any]) -> str:
    """One-line description of a serialized invariant suitable for diagnosis.

    Reuses the conflict_renderer class-specific descriptions when available
    so operator-facing messages stay consistent across surfaces (CLI,
    webhooks, web UI).
    """
    try:
        from adapter.conflict_renderer import describe_invariant
        return describe_invariant(entry)
    except Exception:  # noqa: BLE001 — renderer failures must not block diagnosis.
        cls = entry.get("class_name", "<unknown>") if isinstance(entry, dict) else "<unknown>"
        return f"{cls}(...)"


def _diagnose_semantic(
    class_name: str,
    src_inv: Optional[Dict[str, Any]],
    dst_inv: Optional[Dict[str, Any]],
) -> str:
    """Compose a diagnosis for a ``semantic`` conflict.

    Naming both invariants helps the operator see the difference without
    opening another tool. When one side only removed, we say so.
    """
    if src_inv is not None and dst_inv is not None:
        return (
            f"{class_name}: both branches declared conflicting values "
            f"(src: {_describe_inline(src_inv)}; dst: {_describe_inline(dst_inv)})"
        )
    if src_inv is not None:
        return (
            f"{class_name}: src added {_describe_inline(src_inv)} "
            f"while dst retracted its own copy"
        )
    if dst_inv is not None:
        return (
            f"{class_name}: dst added {_describe_inline(dst_inv)} "
            f"while src retracted its own copy"
        )
    return f"{class_name}: both branches modified this class in incompatible ways"


def _diagnose_temporal(
    class_name: str,
    src_inv: Optional[Dict[str, Any]],
    dst_inv: Optional[Dict[str, Any]],
) -> str:
    """Compose a diagnosis for a ``temporal`` conflict.

    The extra sentence flagging window overlap gives operators the
    vocabulary to explain the failure upstream ("two different RateLimits
    for the same pair").
    """
    base = _diagnose_semantic(class_name, src_inv, dst_inv)
    return (
        f"{base}. Both constraints apply to the same time window, "
        f"so merging blindly would pick the tighter one silently."
    )


def _diagnose_syntactic(class_name: str) -> str:
    return (
        f"{class_name}: both branches added the IDENTICAL invariant "
        f"(same class, same repr). Safe to keep either copy."
    )


def _diagnose_unsupported_fragment(
    class_name: str,
    src_inv: Optional[Dict[str, Any]],
    dst_inv: Optional[Dict[str, Any]],
) -> str:
    offender = src_inv if src_inv is not None else dst_inv
    if offender is not None:
        return (
            f"{class_name}: merge would introduce a fragment-v2 invariant "
            f"({_describe_inline(offender)}) but the destination prover "
            f"chain is fragment-v1 only. Enable z3 or upgrade the deployment."
        )
    return (
        f"{class_name}: merge would introduce a fragment-v2 invariant "
        f"but the destination prover chain is fragment-v1 only."
    )


# ── repair suggestions ─────────────────────────────────────────────────────


def _suggest_repair(
    category: ConflictCategory,
    class_name: str,
    src_branch: str,
    dst_branch: str,
) -> Optional[str]:
    """Return an optional operator hint for how to unblock the merge.

    Deliberately conservative: we only emit a hint when there is a clear
    cheapest action. For open-ended cases (e.g. two semantic values of
    equal standing) we return None so the CLI doesn't nudge the operator
    toward one branch over the other.
    """
    if category == "syntactic":
        return (
            f"Auto-resolve by retracting the duplicate {class_name} on {src_branch!r} "
            f"(both copies are identical)."
        )
    if category == "unsupported_fragment":
        return (
            f"Enable the z3 prover chain on {dst_branch!r} before merging, "
            f"or drop the {class_name} rule from {src_branch!r}."
        )
    if category == "temporal":
        return (
            f"Decide which window applies to {dst_branch!r} and retract the other "
            f"{class_name} before retrying the merge."
        )
    # semantic — no safe auto-hint; operator must choose a value.
    return None


# ── main API ────────────────────────────────────────────────────────────────


def classify_conflict(
    src_delta: Dict[str, Any],
    dst_delta: Dict[str, Any],
    ancestor_invariants: Sequence[Dict[str, Any]] = (),
    *,
    src_branch: str = "src",
    dst_branch: str = "dst",
    prover_supports_v2: bool = True,
) -> List[ClassifiedConflict]:
    """Classify each invariant class that conflicts between ``src`` and ``dst``.

    Arguments:
        src_delta              : ``{"added": [...], "removed": [...]}`` as
                                 emitted by ``RevisionLog._delta_vs``.
        dst_delta              : same shape for the destination branch.
        ancestor_invariants    : serialized invariants present at the common
                                 ancestor. Currently unused by the classifier
                                 but threaded through so future categories
                                 (e.g. "both removed same ancestor") can
                                 consult it without an API break.
        src_branch / dst_branch: branch names used in diagnosis text /
                                 repair hints.
        prover_supports_v2     : whether the destination deployment has a
                                 fragment-v2 prover (z3) configured. When
                                 False, any v2 invariant on either side
                                 becomes ``unsupported_fragment``.

    Returns a new list of ``ClassifiedConflict`` instances, one per
    conflicting class. The list is sorted by class name for deterministic
    output. Empty list ⇒ the deltas don't actually conflict (caller should
    treat that as a disjoint merge).
    """
    del ancestor_invariants  # reserved for future classification rules.
    src_added = src_delta.get("added") or []
    src_removed = src_delta.get("removed") or []
    dst_added = dst_delta.get("added") or []
    dst_removed = dst_delta.get("removed") or []
    if not isinstance(src_added, list):
        src_added = []
    if not isinstance(src_removed, list):
        src_removed = []
    if not isinstance(dst_added, list):
        dst_added = []
    if not isinstance(dst_removed, list):
        dst_removed = []

    # Gather every class that BOTH sides touched. The caller
    # (``RevisionLog._find_conflicting_invariants``) has already culled
    # idempotent add/add pairs, so every class reaching the classifier is
    # a real conflict candidate.
    src_classes = {
        entry.get("class_name")
        for entry in list(src_added) + list(src_removed)
        if isinstance(entry, dict) and isinstance(entry.get("class_name"), str)
    }
    dst_classes = {
        entry.get("class_name")
        for entry in list(dst_added) + list(dst_removed)
        if isinstance(entry, dict) and isinstance(entry.get("class_name"), str)
    }
    overlap = sorted((src_classes & dst_classes) - {None})

    classified: List[ClassifiedConflict] = []
    for class_name in overlap:
        if class_name is None:
            continue
        s_add = _group_by_class(src_added, class_name)
        s_rem = _group_by_class(src_removed, class_name)
        d_add = _group_by_class(dst_added, class_name)
        d_rem = _group_by_class(dst_removed, class_name)

        # Category resolution walks _CATEGORY_PRIORITY top-down and picks
        # the first that matches so operators see the hardest gate first.
        category: ConflictCategory
        if _has_unsupported_fragment(
            s_add, s_rem, d_add, d_rem,
            prover_supports_v2=prover_supports_v2,
        ):
            category = "unsupported_fragment"
        elif _any_is_temporal(s_add, s_rem, d_add, d_rem):
            category = "temporal"
        elif _is_syntactic_only(s_add, s_rem, d_add, d_rem):
            category = "syntactic"
        else:
            category = "semantic"

        src_inv = _pick_representative(s_add, s_rem)
        dst_inv = _pick_representative(d_add, d_rem)

        diagnosis = diagnose(
            ClassifiedConflict(
                class_name=class_name,
                category=category,
                src_inv=src_inv,
                dst_inv=dst_inv,
            )
        )
        classified.append(
            ClassifiedConflict(
                class_name=class_name,
                category=category,
                src_inv=src_inv,
                dst_inv=dst_inv,
                diagnosis=diagnosis,
                suggested_repair=_suggest_repair(
                    category, class_name, src_branch, dst_branch
                ),
            )
        )
    return classified


def diagnose(conflict: ClassifiedConflict) -> str:
    """Plain-English one-liner describing a ``ClassifiedConflict``.

    Pure function; no I/O. Used by the classifier to populate the
    ``diagnosis`` field; exposed publicly so callers that construct
    ``ClassifiedConflict`` directly (e.g. tests, bespoke tooling) can
    reuse the phrasing.
    """
    if conflict.category == "syntactic":
        return _diagnose_syntactic(conflict.class_name)
    if conflict.category == "temporal":
        return _diagnose_temporal(
            conflict.class_name, conflict.src_inv, conflict.dst_inv
        )
    if conflict.category == "unsupported_fragment":
        return _diagnose_unsupported_fragment(
            conflict.class_name, conflict.src_inv, conflict.dst_inv
        )
    return _diagnose_semantic(
        conflict.class_name, conflict.src_inv, conflict.dst_inv
    )


__all__ = [
    "ClassifiedConflict",
    "ConflictCategory",
    "classify_conflict",
    "diagnose",
]
