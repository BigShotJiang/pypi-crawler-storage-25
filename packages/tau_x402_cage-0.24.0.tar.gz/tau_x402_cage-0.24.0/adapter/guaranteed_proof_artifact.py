"""Proof artifacts + append-only artifact store for Guaranteed Mode (v0.19.0).

Deliverable 2.C of the "Guaranteed Mode" track. Every successful or rejected
attempt through `GuaranteedProver.prove()` produces exactly one
`GuaranteedProofArtifact`: an immutable dataclass carrying every field an
auditor needs to re-run the same check later -- policy_revision_id,
compile_hash, backend version, language tier version, verdict, timing, plus
the failure payload on reject.

The artifact is deliberately minimal: it does NOT carry the raw compiled-Tau
source (that lives in the compile cache addressed by ``compile_hash``) and it
does NOT carry a witness (Guaranteed Mode runs over fragment v1 -- the
TauConsistencyProver does not surface witnesses today; if it ever does, the
schema accepts one).

Persistence: JSON-lines on disk, one artifact per line, append-only. Stable
canonical serialization (sorted keys, UTC timestamps, Decimals-as-strings) so
`compile_hash` stays byte-identical across machines.
"""

from __future__ import annotations

import json
import os
import threading
import uuid
from dataclasses import asdict, dataclass, field, replace
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Iterator, Literal, Optional, Sequence

# Best-effort import of agent 1's failure code / payload types. If agent 1's
# branch has not landed yet we fall back to local stubs -- the public shape is
# identical so callers do not notice.
# TODO: remove stubs after agent 1 (adapter.guaranteed_errors) merges.
try:  # pragma: no cover - exercised by both branches
    from adapter.guaranteed_errors import (  # type: ignore[attr-defined]
        GuaranteedFailure,
        GuaranteedFailureCode,
    )
except ImportError:  # agent 1 branch not yet on master
    from adapter._guaranteed_stubs import (  # type: ignore[no-redef]
        GuaranteedFailure,
        GuaranteedFailureCode,
    )


ProofOutcome = Literal["consistent", "inconsistent", "rejected"]


# ── environment ─────────────────────────────────────────────────────────────


#: Env var operators point at a custom artifact store location. Defaults to
#: ``~/.tau-x402-cage/guaranteed_proofs.jsonl`` so a fresh install works with
#: zero configuration.
ARTIFACT_STORE_ENV_VAR = "TAU_X402_CAGE_PROOF_STORE"


def _default_store_path() -> Path:
    return Path.home() / ".tau-x402-cage" / "guaranteed_proofs.jsonl"


def _resolved_store_path(override: Optional[Path | str] = None) -> Path:
    """Resolve the artifact store path with env-var precedence.

    Priority: explicit constructor override > env var > default.
    """
    if override is not None:
        return Path(override)
    env = os.environ.get(ARTIFACT_STORE_ENV_VAR)
    if env:
        return Path(env)
    return _default_store_path()


# ── dataclasses ─────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class GuaranteedProofArtifact:
    """Durable evidence that a guaranteed proof was attempted.

    All fields are immutable (frozen dataclass). Mutation raises
    ``dataclasses.FrozenInstanceError``. Every attempt through
    ``GuaranteedProver.prove()`` produces exactly one artifact regardless of
    outcome.

    Fields:
        artifact_id: UUID4 hex string; unique per attempt.
        policy_revision_id: content-addressed id of the policy under proof.
            Matches ``adapter.policy_revision.PolicyRevision.revision_id``
            when the caller has a revision; for ad-hoc proofs the caller
            passes a deterministic placeholder (often the compile_hash).
        compile_hash: SHA-256 of the canonical compiled-Tau source fed to
            the authoritative prover. Stable across machines.
        tau_backend_version: version string of the Tau runtime that decided
            the proof (``"unknown"`` if ``tau --version`` could not be probed).
        language_tier_version: version string of the Guaranteed Mode language
            tier -- from ``GuaranteedLanguage.describe()["version"]``. Bumps
            when the admissible invariant set or totality contract changes.
        proof_result: ``"consistent"``, ``"inconsistent"``, or ``"rejected"``.
            A successful rejection (e.g. Tau proved UNSAT) maps to
            ``"inconsistent"``. A conservative failure (timeout, unsupported
            construct, backend unavailable) maps to ``"rejected"``.
        totality_check_passed: ``True`` iff every invariant in the policy
            satisfied the language-tier totality contract. Always ``True``
            for the "consistent"/"inconsistent" outcomes (the prover short-
            circuits on totality failure before reaching Tau).
        prove_timestamp: UTC, ISO-8601 with offset, microsecond precision.
        prove_budget_ms: the budget the caller passed to ``prove()``.
        failure: populated iff ``proof_result == "rejected"``. Carries the
            agent-1 structured failure payload.
    """

    artifact_id: str
    policy_revision_id: str
    compile_hash: str
    tau_backend_version: str
    language_tier_version: str
    proof_result: ProofOutcome
    totality_check_passed: bool
    prove_timestamp: datetime
    prove_budget_ms: int
    failure: Optional[GuaranteedFailure] = None

    def to_canonical_dict(self) -> dict[str, Any]:
        """JSON-safe dict with stable key ordering and timestamp formatting."""
        failure_payload: Optional[dict[str, Any]]
        if self.failure is None:
            failure_payload = None
        else:
            # `GuaranteedFailure` may be either the real agent-1 dataclass or
            # our stub. Both expose ``code`` and ``message``; agent 1's
            # version also exposes ``details``. We serialise defensively.
            payload: dict[str, Any] = {
                "code": _failure_code_to_str(self.failure.code),
                "message": getattr(self.failure, "message", ""),
            }
            details = getattr(self.failure, "details", None)
            if details is not None:
                payload["details"] = _jsonable(details)
            failure_payload = payload
        return {
            "artifact_id": self.artifact_id,
            "compile_hash": self.compile_hash,
            "failure": failure_payload,
            "language_tier_version": self.language_tier_version,
            "policy_revision_id": self.policy_revision_id,
            "proof_budget_ms": self.prove_budget_ms,
            "proof_result": self.proof_result,
            "prove_timestamp": self.prove_timestamp.astimezone(timezone.utc).isoformat(),
            "tau_backend_version": self.tau_backend_version,
            "totality_check_passed": self.totality_check_passed,
        }

    @classmethod
    def from_canonical_dict(cls, d: dict[str, Any]) -> "GuaranteedProofArtifact":
        """Inverse of ``to_canonical_dict``. Validates required fields."""
        _required = (
            "artifact_id", "compile_hash", "language_tier_version",
            "policy_revision_id", "proof_budget_ms", "proof_result",
            "prove_timestamp", "tau_backend_version", "totality_check_passed",
        )
        missing = [k for k in _required if k not in d]
        if missing:
            raise ValueError(f"artifact missing required fields: {missing}")
        failure = None
        if d.get("failure") is not None:
            failure = _reconstruct_failure(d["failure"])
        return cls(
            artifact_id=str(d["artifact_id"]),
            policy_revision_id=str(d["policy_revision_id"]),
            compile_hash=str(d["compile_hash"]),
            tau_backend_version=str(d["tau_backend_version"]),
            language_tier_version=str(d["language_tier_version"]),
            proof_result=_coerce_outcome(d["proof_result"]),
            totality_check_passed=bool(d["totality_check_passed"]),
            prove_timestamp=_parse_timestamp(d["prove_timestamp"]),
            prove_budget_ms=int(d["proof_budget_ms"]),
            failure=failure,
        )


@dataclass(frozen=True)
class GuaranteedProofResult:
    """Successful-prove return type for ``GuaranteedProver.prove()``.

    Callers that want the structured failure on reject receive a
    ``GuaranteedFailure`` instead of this type -- the two are never mixed on
    the success path.

    Fields:
        artifact: the persisted ``GuaranteedProofArtifact`` describing the
            attempt. Always populated on success.
        consistent: ``True`` if the policy was proven consistent (SAT),
            ``False`` if proven inconsistent (UNSAT).
        witness: always ``None`` in v0.19.0. The pure-Tau fragment-v1 path
            does not currently surface witnesses; we keep the field so
            consumers can plan for a future upgrade without breaking the
            wire shape.
    """

    artifact: GuaranteedProofArtifact
    consistent: bool
    witness: Optional[Any] = None


# ── store ───────────────────────────────────────────────────────────────────


class ProofArtifactStore:
    """Append-only JSON-lines store for guaranteed proof artifacts.

    Thread-safe for single-process writers. Cross-process safety is achieved
    by the kernel's ``O_APPEND`` guarantee -- concurrent writers race only on
    line ordering, never on line interleaving. Readers tolerate partial writes
    by raising on the malformed line (the audit trail must NEVER silently drop
    records).
    """

    def __init__(self, path: Optional[Path | str] = None) -> None:
        self._path = _resolved_store_path(path)
        self._lock = threading.Lock()

    # ── configuration ──────────────────────────────────────────────────────

    @property
    def path(self) -> Path:
        return self._path

    # ── write side ────────────────────────────────────────────────────────

    def save(self, artifact: GuaranteedProofArtifact) -> None:
        """Append an artifact to the store.

        Atomic per-line via ``O_APPEND``. Raises ``OSError`` if the parent
        directory is not writable.
        """
        if not isinstance(artifact, GuaranteedProofArtifact):  # defensive
            raise TypeError(
                f"expected GuaranteedProofArtifact, got {type(artifact).__name__}"
            )
        line = json.dumps(artifact.to_canonical_dict(), sort_keys=True)
        with self._lock:
            self._path.parent.mkdir(parents=True, exist_ok=True)
            # Use O_APPEND so concurrent writers don't step on each other.
            fd = os.open(
                self._path,
                os.O_WRONLY | os.O_CREAT | os.O_APPEND,
                0o600,
            )
            try:
                os.write(fd, (line + "\n").encode("utf-8"))
            finally:
                os.close(fd)

    # ── read side ─────────────────────────────────────────────────────────

    def load(self, artifact_id: str) -> Optional[GuaranteedProofArtifact]:
        """Return the artifact with the given id, or ``None`` if not found."""
        if not isinstance(artifact_id, str) or not artifact_id:
            raise ValueError("artifact_id must be a non-empty string")
        for art in self._iter_artifacts():
            if art.artifact_id == artifact_id:
                return art
        return None

    def list_for_revision(
        self, policy_revision_id: str
    ) -> list[GuaranteedProofArtifact]:
        """Return every artifact recorded against a given policy revision."""
        if not isinstance(policy_revision_id, str) or not policy_revision_id:
            raise ValueError("policy_revision_id must be a non-empty string")
        return [
            a for a in self._iter_artifacts()
            if a.policy_revision_id == policy_revision_id
        ]

    def _iter_artifacts(self) -> Iterator[GuaranteedProofArtifact]:
        if not self._path.exists():
            return
        with self._path.open("r", encoding="utf-8") as fh:
            for raw in fh:
                line = raw.strip()
                if not line:
                    continue
                yield GuaranteedProofArtifact.from_canonical_dict(json.loads(line))


# ── helpers ────────────────────────────────────────────────────────────────


def make_artifact_id() -> str:
    """UUID4 hex string (32 chars)."""
    return uuid.uuid4().hex


def utc_now() -> datetime:
    """Timezone-aware UTC ``datetime`` used for new artifacts."""
    return datetime.now(timezone.utc)


def _failure_code_to_str(code: Any) -> str:
    """Accept enum members, strings, or anything with a ``.name`` / ``.value``."""
    if isinstance(code, str):
        return code
    name = getattr(code, "name", None)
    if name is not None:
        return str(name)
    value = getattr(code, "value", None)
    if value is not None:
        return str(value)
    return str(code)


def _reconstruct_failure(payload: dict[str, Any]) -> GuaranteedFailure:
    """Rebuild a ``GuaranteedFailure`` from its JSON-safe dict form."""
    raw_code = payload.get("code", "")
    # Try to rehydrate through the real enum; fall back to the raw string.
    try:
        code = GuaranteedFailureCode[raw_code]  # type: ignore[misc]
    except (KeyError, TypeError):
        code = raw_code  # stub path: the code field is just a str.
    message = payload.get("message", "") or "(no message)"
    details = payload.get("details") or payload.get("context") or {}
    # Agent 2 originally used ``details=``; agent 1's real schema is
    # ``context=`` + requires non-empty ``message``. Try the real shape
    # first, fall back to the stub shape if we're running pre-merge.
    try:
        from adapter.guaranteed_language import GUARANTEED_LANGUAGE_VERSION
        return GuaranteedFailure(  # type: ignore[call-arg]
            code=code,
            message=message,
            context=dict(details),
            language_version=GUARANTEED_LANGUAGE_VERSION,
        )
    except (ImportError, TypeError):
        return GuaranteedFailure(  # type: ignore[call-arg]
            code=code,
            message=message,
            details=dict(details),
        )


def _coerce_outcome(raw: Any) -> ProofOutcome:
    s = str(raw)
    if s not in ("consistent", "inconsistent", "rejected"):
        raise ValueError(f"unknown proof_result: {s!r}")
    return s  # type: ignore[return-value]


def _parse_timestamp(raw: Any) -> datetime:
    if isinstance(raw, datetime):
        return raw if raw.tzinfo else raw.replace(tzinfo=timezone.utc)
    return datetime.fromisoformat(str(raw))


def _jsonable(value: Any) -> Any:
    """Coerce arbitrary ``details`` into JSON-safe primitives."""
    if value is None or isinstance(value, (bool, int, float, str)):
        return value
    if isinstance(value, dict):
        return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_jsonable(v) for v in value]
    return str(value)
