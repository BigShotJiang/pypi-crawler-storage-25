"""Webhook sink for verdicts (v0.10.0).

Stream every cage verdict to an external HTTP endpoint so operators can fan
out into Datadog, S3-via-Lambda, Splunk, a customer SIEM, or any other
webhook receiver. Design goals:

* **Never block the hot path.** Verdict emission is fire-and-forget via a
  bounded in-memory queue + a background worker thread. ``_op_check_payment``
  returns its response before the sink ever sees the verdict.
* **Back-pressure by dropping OLDEST, not blocking.** If an operator's
  webhook is slow or down, we refuse to let the producer stall. The queue is
  a ring; when full, the oldest unsent verdict is evicted and
  ``webhook_dropped_total`` is bumped on the Prometheus registry.
* **Fail-closed at config time, fail-silent at runtime.** Invalid YAML or a
  malformed sink URL aborts daemon startup (matches v0.8.0 Redis behaviour).
  Once running, a flaky webhook just gets circuit-broken; the cage never
  rejects an admission because the sink had a bad day.
* **HMAC-signed deliveries.** Every POST carries a timestamped HMAC-SHA256
  over the canonical body so receivers can pin the source. Headers:
  ``X-Cage-Signature``, ``X-Cage-Timestamp``, ``X-Cage-Verdict-Id``.
* **Filters at config time.** ``only_verdicts`` and ``only_rules`` let
  operators route permits to one sink and rejects to another (e.g.
  permits → warehouse, rejects → pager).
* **Exponential retry with circuit breaker.** 5xx and network errors
  retry with backoff capped at 30s. After 5 consecutive failures the sink
  opens its circuit for 60s, queueing new verdicts in the meantime.

Zero new third-party deps: uses stdlib ``http.client`` for HTTP and stdlib
``hmac`` + ``hashlib`` for signing. When ``httpx`` is already imported on
the daemon process we prefer it (better connection pooling) but do not
require it.

See ``docs/webhooks.md`` for the end-to-end wire protocol, retry policy,
and Datadog / S3 integration worked examples.
"""
from __future__ import annotations

import collections
import hashlib
import hmac
import json
import logging
import os
import queue as _queue
import threading
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Callable, Iterable, Optional, Sequence
from urllib.parse import urlparse

from adapter.metrics import CageMetrics, _NullMetrics

logger = logging.getLogger(__name__)

__all__ = [
    "WebhookConfig",
    "WebhookConfigError",
    "WebhookSink",
    "canonicalize_verdict",
    "compute_signature",
    "load_webhook_config",
]


# Sentinel used to signal the worker thread to shut down.
_SHUTDOWN = object()

# Retry / circuit-breaker defaults. The constants live here rather than on
# WebhookSink so tests can monkey-patch them for deterministic timing without
# poking at instance attributes.
DEFAULT_TIMEOUT_S: float = 3.0
DEFAULT_RETRY: int = 3
DEFAULT_QUEUE_SIZE: int = 10_000
MAX_BACKOFF_S: float = 30.0
CIRCUIT_BREAKER_THRESHOLD: int = 5
CIRCUIT_BREAKER_COOLDOWN_S: float = 60.0


class WebhookConfigError(ValueError):
    """Raised when a webhook YAML / dict config is malformed.

    The daemon treats this as a fail-closed startup error — the whole
    process refuses to start rather than silently dropping sinks. Matches
    the v0.8.0 Redis-history failure mode.
    """


# ── canonicalisation + signature ─────────────────────────────────────────────


def canonicalize_verdict(verdict: dict[str, Any]) -> bytes:
    """Return the canonical bytes hashed by ``X-Cage-Signature``.

    The signature body is a deterministic JSON encoding of the verdict
    payload: UTF-8, ``ensure_ascii=False``, sorted keys, no extra spaces.
    Using ``json.dumps`` with these flags lets Python and Go/Node
    receivers reproduce the exact bytes without a second-order ``jcs``
    dependency (which would be overkill for a primitive envelope).
    """
    return json.dumps(verdict, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def compute_signature(secret: bytes, timestamp: str, body: bytes) -> str:
    """Return the hex HMAC-SHA256 over ``timestamp + "." + body``.

    Prefixing the timestamp into the MAC input (a la Stripe's webhook
    signature) blocks replay attacks: an attacker who grabs a signed
    request cannot re-submit it under a different time window without
    invalidating the signature.
    """
    if not isinstance(secret, (bytes, bytearray)):
        raise TypeError("secret must be bytes")
    mac = hmac.new(secret, digestmod=hashlib.sha256)
    mac.update(timestamp.encode("ascii"))
    mac.update(b".")
    mac.update(body)
    return mac.hexdigest()


# ── config surface ───────────────────────────────────────────────────────────


@dataclass(frozen=True)
class WebhookConfig:
    """One webhook sink's configuration.

    Configs are immutable by design: rotating a secret or adjusting a
    filter requires spawning a new :class:`WebhookSink`, which keeps the
    in-flight queue semantics unambiguous (no "which config was active
    when this verdict got signed?" race).

    Attributes:
        name: Human-readable identifier surfaced in logs + metrics.
        url: Absolute http(s) URL the worker POSTs to.
        secret: Shared HMAC secret. Bytes, minimum 16 bytes (warn if
            shorter). Never logged.
        timeout_s: Per-request HTTP timeout in seconds.
        retry: How many retries before giving up on a single verdict.
        queue_size: Ring-buffer capacity. Full queue drops OLDEST.
        only_verdicts: If set, only deliver verdicts whose ``verdict``
            field is in this set. Typical values: ``{"reject"}``.
        only_rules: If set, only deliver rejects whose ``rule_id`` is in
            this set. Permits are filtered out unless "permit" is in
            ``only_verdicts`` AND ``only_rules`` is empty.
    """

    name: str
    url: str
    secret: bytes
    timeout_s: float = DEFAULT_TIMEOUT_S
    retry: int = DEFAULT_RETRY
    queue_size: int = DEFAULT_QUEUE_SIZE
    only_verdicts: frozenset[str] = field(default_factory=frozenset)
    only_rules: frozenset[str] = field(default_factory=frozenset)

    def __post_init__(self) -> None:
        if not self.name or not isinstance(self.name, str):
            raise WebhookConfigError("webhook sink requires a non-empty name")
        parsed = urlparse(self.url or "")
        if parsed.scheme not in ("http", "https") or not parsed.netloc:
            raise WebhookConfigError(
                f"webhook sink {self.name!r}: url must be http(s)://host/path, got {self.url!r}"
            )
        if not isinstance(self.secret, (bytes, bytearray)) or len(self.secret) < 16:
            raise WebhookConfigError(
                f"webhook sink {self.name!r}: secret must be bytes of length >= 16"
            )
        if self.timeout_s <= 0:
            raise WebhookConfigError(
                f"webhook sink {self.name!r}: timeout_s must be > 0"
            )
        if self.retry < 0:
            raise WebhookConfigError(
                f"webhook sink {self.name!r}: retry must be >= 0"
            )
        if self.queue_size < 1:
            raise WebhookConfigError(
                f"webhook sink {self.name!r}: queue_size must be >= 1"
            )
        for verdict in self.only_verdicts:
            if verdict not in ("permit", "reject"):
                raise WebhookConfigError(
                    f"webhook sink {self.name!r}: only_verdicts contains {verdict!r}, "
                    f"must be permit|reject"
                )

    def matches(self, verdict: dict[str, Any]) -> bool:
        """Return True iff this verdict should be delivered to this sink."""
        if self.only_verdicts:
            if verdict.get("verdict") not in self.only_verdicts:
                return False
        if self.only_rules:
            # A permit has no rule_id; only_rules implicitly filters permits out
            # unless the operator also whitelisted "permit" in only_verdicts.
            rule_id = verdict.get("rule_id")
            if rule_id is None or rule_id not in self.only_rules:
                return False
        return True


def load_webhook_config(source: Any) -> list[WebhookConfig]:
    """Load and validate a webhook config from a YAML path, string, or dict.

    ``source`` may be:

    * a ``str`` or ``os.PathLike`` pointing at a YAML file on disk;
    * a ``bytes``/``str`` YAML document;
    * an already-parsed ``dict``/``list``.

    Schema:

    .. code-block:: yaml

        version: 1
        webhooks:
          - name: datadog
            url: https://http-intake.logs.datadoghq.com/api/v2/logs
            secret_env: DATADOG_WEBHOOK_SECRET
            timeout_s: 3.0
            retry: 3
            queue_size: 10000
            only_verdicts: [reject]
            only_rules: [spending_cap_per_tx]

    ``secret`` can be provided inline or pulled from the environment via
    ``secret_env``. Inline secrets get an audit warning logged; env-var is
    the recommended production path.
    """
    try:
        import yaml  # local import so tests without YAML still import this module
    except ImportError as exc:  # pragma: no cover - yaml is a transitive dep
        raise WebhookConfigError(
            "PyYAML is required to parse webhook config; "
            "install `pyyaml` or pass a parsed dict"
        ) from exc

    parsed: Any
    if isinstance(source, (str, bytes, bytearray)) and not _looks_like_path(source):
        parsed = yaml.safe_load(source)
    elif isinstance(source, (str, os.PathLike)):
        with open(source, "r", encoding="utf-8") as fh:
            parsed = yaml.safe_load(fh)
    else:
        parsed = source

    if parsed is None:
        return []
    if not isinstance(parsed, dict):
        raise WebhookConfigError(
            f"webhook config must be a mapping at top level, got {type(parsed).__name__}"
        )

    entries = parsed.get("webhooks")
    if entries is None:
        return []
    if not isinstance(entries, list):
        raise WebhookConfigError("`webhooks:` must be a list")

    out: list[WebhookConfig] = []
    for idx, entry in enumerate(entries):
        if not isinstance(entry, dict):
            raise WebhookConfigError(
                f"webhook[{idx}] must be a mapping, got {type(entry).__name__}"
            )
        out.append(_parse_entry(entry, idx))
    return out


def _looks_like_path(source: Any) -> bool:
    """Heuristic: an existing file path vs an inline YAML body.

    A bytes/str source that (a) has no newlines, (b) is <= 4096 chars, and
    (c) names an existing file is treated as a path. Everything else is
    treated as a YAML document. Mistakes here just fall through to
    yaml.safe_load, which will surface a readable parse error.
    """
    if isinstance(source, (bytes, bytearray)):
        try:
            source = source.decode("utf-8")
        except UnicodeDecodeError:
            return False
    if not isinstance(source, str):
        return False
    if "\n" in source or len(source) > 4096:
        return False
    try:
        return os.path.isfile(source)
    except (OSError, ValueError):
        return False


def _parse_entry(entry: dict[str, Any], idx: int) -> WebhookConfig:
    """Turn one parsed mapping into a :class:`WebhookConfig`."""
    name = entry.get("name") or f"webhook_{idx}"
    url = entry.get("url")
    if not url:
        raise WebhookConfigError(f"webhook[{idx}] ({name!r}): missing `url`")

    secret: Optional[bytes] = None
    if "secret_env" in entry:
        env_name = entry["secret_env"]
        if not isinstance(env_name, str) or not env_name:
            raise WebhookConfigError(
                f"webhook[{idx}] ({name!r}): `secret_env` must be a non-empty string"
            )
        env_val = os.environ.get(env_name)
        if not env_val:
            raise WebhookConfigError(
                f"webhook[{idx}] ({name!r}): env var {env_name!r} is unset or empty"
            )
        secret = env_val.encode("utf-8")
    elif "secret" in entry:
        raw = entry["secret"]
        if isinstance(raw, str):
            secret = raw.encode("utf-8")
        elif isinstance(raw, (bytes, bytearray)):
            secret = bytes(raw)
        else:
            raise WebhookConfigError(
                f"webhook[{idx}] ({name!r}): `secret` must be str or bytes"
            )
        logger.warning(
            "webhook[%s] (%s): inline `secret` in config. Prefer `secret_env:` "
            "so the secret never lands in a config file.",
            idx, name,
        )
    else:
        raise WebhookConfigError(
            f"webhook[{idx}] ({name!r}): must provide `secret:` or `secret_env:`"
        )

    only_verdicts = frozenset(entry.get("only_verdicts") or [])
    only_rules = frozenset(entry.get("only_rules") or [])

    return WebhookConfig(
        name=str(name),
        url=str(url),
        secret=secret,
        timeout_s=float(entry.get("timeout_s", DEFAULT_TIMEOUT_S)),
        retry=int(entry.get("retry", DEFAULT_RETRY)),
        queue_size=int(entry.get("queue_size", DEFAULT_QUEUE_SIZE)),
        only_verdicts=only_verdicts,
        only_rules=only_rules,
    )


# ── transport ────────────────────────────────────────────────────────────────


class _HTTPResult:
    """Lightweight result shape so tests can drop in a fake transport."""

    __slots__ = ("status_code",)

    def __init__(self, status_code: int) -> None:
        self.status_code = status_code


def _default_transport(
    url: str, headers: dict[str, str], body: bytes, timeout_s: float
) -> _HTTPResult:
    """Stdlib-only transport. Kept small so tests can swap it out."""
    import http.client
    parsed = urlparse(url)
    conn_cls = (
        http.client.HTTPSConnection if parsed.scheme == "https"
        else http.client.HTTPConnection
    )
    conn = conn_cls(parsed.netloc, timeout=timeout_s)
    try:
        path = parsed.path or "/"
        if parsed.query:
            path = f"{path}?{parsed.query}"
        conn.request("POST", path, body=body, headers=headers)
        resp = conn.getresponse()
        resp.read()  # drain
        return _HTTPResult(status_code=resp.status)
    finally:
        conn.close()


# ── webhook sink (background worker) ─────────────────────────────────────────


class WebhookSink:
    """Async verdict delivery to one HTTP endpoint.

    One :class:`WebhookSink` == one worker thread. Multiple sinks run
    independently. The hot path (``_op_check_payment``) calls
    :meth:`emit` which is non-blocking: the verdict is stamped with an
    ID, wrapped with a filter check, and shovelled into the ring buffer.
    The worker drains the buffer, signs each body, POSTs it, and
    handles retries / circuit breaking.
    """

    def __init__(
        self,
        url: str,
        secret: bytes,
        *,
        name: Optional[str] = None,
        timeout_s: float = DEFAULT_TIMEOUT_S,
        retry: int = DEFAULT_RETRY,
        queue_size: int = DEFAULT_QUEUE_SIZE,
        only_verdicts: Iterable[str] = (),
        only_rules: Iterable[str] = (),
        metrics: "CageMetrics | _NullMetrics | None" = None,
        transport: Optional[Callable[[str, dict[str, str], bytes, float], _HTTPResult]] = None,
        sleep: Callable[[float], None] = time.sleep,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        self._config = WebhookConfig(
            name=name or _derive_name(url),
            url=url,
            secret=secret,
            timeout_s=timeout_s,
            retry=retry,
            queue_size=queue_size,
            only_verdicts=frozenset(only_verdicts),
            only_rules=frozenset(only_rules),
        )
        # Use ``deque`` rather than ``queue.Queue`` so we can atomically
        # drop OLDEST on overflow. A standard FIFO queue would block
        # put() or raise Full; neither lets us evict the stale entry
        # without a second lock.
        self._buf: collections.deque[Any] = collections.deque(maxlen=queue_size)
        self._buf_lock = threading.Lock()
        self._not_empty = threading.Condition(self._buf_lock)
        self._shutdown = threading.Event()
        self._worker: Optional[threading.Thread] = None
        self._metrics = metrics
        self._transport = transport or _default_transport
        self._sleep = sleep
        self._clock = clock

        # Circuit breaker state. ``_circuit_open_until`` is a monotonic
        # deadline; while now() < that, the worker drains the queue but
        # drops each entry without attempting delivery (honouring
        # back-pressure semantics — nothing stalls).
        self._consecutive_failures = 0
        self._circuit_open_until = 0.0

        # Metrics for introspection (also useful in tests).
        self._delivered = 0
        self._dropped = 0
        self._failed = 0

    @classmethod
    def from_config(
        cls,
        cfg: WebhookConfig,
        *,
        metrics: "CageMetrics | _NullMetrics | None" = None,
        transport: Optional[Callable[[str, dict[str, str], bytes, float], _HTTPResult]] = None,
    ) -> "WebhookSink":
        """Construct from a validated :class:`WebhookConfig`."""
        return cls(
            url=cfg.url,
            secret=cfg.secret,
            name=cfg.name,
            timeout_s=cfg.timeout_s,
            retry=cfg.retry,
            queue_size=cfg.queue_size,
            only_verdicts=cfg.only_verdicts,
            only_rules=cfg.only_rules,
            metrics=metrics,
            transport=transport,
        )

    @property
    def name(self) -> str:
        return self._config.name

    @property
    def url(self) -> str:
        return self._config.url

    @property
    def config(self) -> WebhookConfig:
        return self._config

    # ── producer-side API ────────────────────────────────────────────────────

    def emit(self, verdict: dict[str, Any]) -> bool:
        """Queue a verdict for async delivery. NEVER blocks.

        Returns True if the verdict entered the queue (or matched no
        filter — silently dropped), False if the ring was full and an
        older verdict had to be evicted. Return value is informational
        only; the hot path never checks it.
        """
        if not self._config.matches(verdict):
            return True
        envelope = _build_envelope(verdict, self._config.secret, self._clock)
        with self._buf_lock:
            # ``deque(maxlen=N)`` silently drops the oldest on append when
            # full, so we check length first to know whether to increment
            # ``webhook_dropped_total``.
            dropped = len(self._buf) >= self._config.queue_size
            self._buf.append(envelope)
            if dropped:
                self._dropped += 1
                _bump_dropped(self._metrics, self._config.name)
            self._not_empty.notify()
        return not dropped

    # ── lifecycle ────────────────────────────────────────────────────────────

    def start(self) -> None:
        """Spawn the worker thread. Idempotent; start() after start() is a no-op."""
        if self._worker is not None and self._worker.is_alive():
            return
        self._shutdown.clear()
        self._worker = threading.Thread(
            target=self._run, name=f"webhook-sink/{self._config.name}", daemon=True,
        )
        self._worker.start()

    def stop(self, *, drain_timeout_s: float = 5.0) -> None:
        """Signal the worker to exit and wait for it.

        Does NOT attempt to drain pending verdicts — we choose at-most-once
        on shutdown rather than block indefinitely. A graceful drain is
        the operator's job (e.g. a k8s ``preStop`` hook that sleeps while
        the queue drops).
        """
        self._shutdown.set()
        with self._buf_lock:
            self._not_empty.notify_all()
        worker = self._worker
        if worker is not None and worker.is_alive():
            worker.join(timeout=drain_timeout_s)
        self._worker = None

    # ── worker loop ──────────────────────────────────────────────────────────

    def _run(self) -> None:
        while not self._shutdown.is_set():
            envelope = self._pop_next(timeout_s=0.1)
            if envelope is None:
                continue
            if self._circuit_open():
                # Drop silently — the caller already accepted this into the
                # ring. Metrics capture it under ``dropped`` so operators
                # can still see the volume loss in Grafana.
                self._dropped += 1
                _bump_dropped(self._metrics, self._config.name)
                continue
            delivered = self._deliver_with_retry(envelope)
            if delivered:
                self._consecutive_failures = 0
                self._delivered += 1
            else:
                self._failed += 1
                self._consecutive_failures += 1
                if self._consecutive_failures >= CIRCUIT_BREAKER_THRESHOLD:
                    self._circuit_open_until = (
                        self._clock() + CIRCUIT_BREAKER_COOLDOWN_S
                    )
                    logger.warning(
                        "webhook sink %r: %d consecutive failures, "
                        "opening circuit for %.0fs",
                        self._config.name,
                        self._consecutive_failures,
                        CIRCUIT_BREAKER_COOLDOWN_S,
                    )

    def _pop_next(self, *, timeout_s: float) -> Any:
        with self._not_empty:
            if not self._buf:
                self._not_empty.wait(timeout=timeout_s)
            if not self._buf:
                return None
            return self._buf.popleft()

    def _circuit_open(self) -> bool:
        if self._circuit_open_until == 0.0:
            return False
        if self._clock() >= self._circuit_open_until:
            # Cooldown elapsed -- half-open: reset to zero so the next
            # attempt either succeeds (closed) or re-opens the circuit.
            self._circuit_open_until = 0.0
            self._consecutive_failures = 0
            return False
        return True

    def _deliver_with_retry(self, envelope: dict[str, Any]) -> bool:
        body = envelope["_body"]
        headers = envelope["_headers"]
        attempts = self._config.retry + 1
        backoff = 0.5
        for attempt in range(attempts):
            if self._shutdown.is_set():
                return False
            try:
                result = self._transport(
                    self._config.url, headers, body, self._config.timeout_s,
                )
            except Exception as exc:
                logger.debug(
                    "webhook %r POST raised %s on attempt %d/%d",
                    self._config.name, exc, attempt + 1, attempts,
                )
            else:
                if 200 <= result.status_code < 300:
                    return True
                if 400 <= result.status_code < 500 and result.status_code != 429:
                    # 4xx (except 429) = permanent, don't retry. A 404 means
                    # the endpoint moved; retrying just wastes quota.
                    logger.warning(
                        "webhook %r got %d; not retrying",
                        self._config.name, result.status_code,
                    )
                    return False
                logger.debug(
                    "webhook %r got %d on attempt %d/%d",
                    self._config.name, result.status_code, attempt + 1, attempts,
                )
            # Backoff before next attempt (skip after last).
            if attempt + 1 < attempts:
                self._sleep(min(backoff, MAX_BACKOFF_S))
                backoff = min(backoff * 2, MAX_BACKOFF_S)
        return False

    # ── introspection (tests) ────────────────────────────────────────────────

    def metrics_snapshot(self) -> dict[str, int]:
        """Return per-sink counters. Separate from the Prometheus surface."""
        return {
            "delivered": self._delivered,
            "dropped": self._dropped,
            "failed": self._failed,
            "queued": len(self._buf),
            "consecutive_failures": self._consecutive_failures,
            "circuit_open": 1 if self._circuit_open_until else 0,
        }

    @property
    def circuit_open_until(self) -> float:
        """Monotonic deadline the circuit reopens at. 0.0 == closed."""
        return self._circuit_open_until

    def force_close_circuit(self) -> None:
        """Reset the circuit breaker. Test helper; never called in production."""
        self._circuit_open_until = 0.0
        self._consecutive_failures = 0


# ── envelope construction ────────────────────────────────────────────────────


def _build_envelope(
    verdict: dict[str, Any],
    secret: bytes,
    clock: Callable[[], float],
) -> dict[str, Any]:
    """Stamp a verdict with an ID + HMAC signature, return the body + headers.

    The verdict dict is deep-copied (shallow merge is enough here — the
    daemon already passes plain dict/str/int/float/None leaves) so the
    caller can keep mutating its copy without affecting what we send.
    """
    verdict_id = str(uuid.uuid4())
    # Use wall-clock time for the signature timestamp so receivers can
    # implement time-skew checks the same way Stripe / Slack do. The
    # monotonic clock, if injected, is only used for circuit-breaker
    # deadlines.
    timestamp = str(int(time.time()))
    body = canonicalize_verdict(verdict)
    signature = compute_signature(secret, timestamp, body)
    headers = {
        "Content-Type": "application/json; charset=utf-8",
        "User-Agent": "tau-x402-cage-webhook/0.10",
        "X-Cage-Signature": f"sha256={signature}",
        "X-Cage-Timestamp": timestamp,
        "X-Cage-Verdict-Id": verdict_id,
    }
    return {
        "_body": body,
        "_headers": headers,
        "_verdict_id": verdict_id,
        "_timestamp": timestamp,
    }


def _derive_name(url: str) -> str:
    parsed = urlparse(url)
    return parsed.netloc or "webhook"


# ── metrics plumbing ─────────────────────────────────────────────────────────
#
# v0.9.0's ``CageMetrics`` doesn't know about webhook counters — those are
# new in v0.10.0. We bolt them on lazily so an operator running without the
# ``[metrics]`` extra still works (the no-op stand-in swallows the bump).


_DROPPED_COUNTER_NAME = "tau_x402_webhook_dropped_total"
_DROPPED_COUNTER_ATTR = "_webhook_dropped"


def _bump_dropped(
    metrics: "CageMetrics | _NullMetrics | None",
    sink_name: str,
) -> None:
    """Best-effort bump of ``webhook_dropped_total{sink=...}``.

    If ``metrics`` is None or a :class:`_NullMetrics`, this is a no-op.
    Otherwise we lazy-register a Counter on the existing Prometheus
    registry so the metric surface mesh stays in one place.
    """
    if metrics is None or getattr(metrics, "backend", None) == "null":
        return
    registry = getattr(metrics, "_registry", None)
    if registry is None:
        return
    counter = getattr(metrics, _DROPPED_COUNTER_ATTR, None)
    if counter is None:
        try:
            from prometheus_client import Counter
        except ImportError:  # pragma: no cover - metrics path gates on this already
            return
        counter = Counter(
            _DROPPED_COUNTER_NAME,
            "Verdicts dropped because their webhook sink's queue was full "
            "or its circuit breaker was open.",
            labelnames=("sink",),
            registry=registry,
        )
        setattr(metrics, _DROPPED_COUNTER_ATTR, counter)
    counter.labels(sink=sink_name).inc()
