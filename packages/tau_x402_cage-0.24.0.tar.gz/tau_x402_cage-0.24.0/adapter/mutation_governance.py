"""Policy-over-policy: governance rules for how invariants themselves may change.

v0.14.0 introduces the "sellable feature" surface of the cage: control over
HOW money rules change. The existing approval queue (v0.7.0) answers WHO
can sign off on a proposal; mutation governance answers WHO can PROPOSE
what, and under WHICH conditions. This module is the declarative policy-
over-policy layer.

Four axes:

    1. Actor authorization — each `mutation_actor` (agent or human) is
       either wildcarded (``can_propose: "*"``) or restricted to a set of
       invariant CLASS names (``SpendingCap``, ``ProviderAllowlist``, ...).
       An actor not listed in the policy cannot propose ANYTHING.

    2. Approval requirements — per-invariant-class rules specify
       ``min_reviewers`` (default 1), ``reviewer_must_differ_from_submitter``
       (default True), and ``reviewers_must_differ`` (default True). A
       proposal admits only once the queue has gathered that many DISTINCT
       reviewer approvals.

    3. Strict-mode requirement — temporal invariants (RetryRateLimit,
       RollingWindowCap, InstabilityGuard) whose semantics only the strict
       prover mode can soundly admit. When a `strict_mode_required_for`
       class is declared under ``compat``/``verified``, the declare is
       refused with category=``governance_violation`` before it reaches
       the prover chain.

    4. Temporal-rule bounds — `window_seconds` / `min_gap_seconds` must
       fall within `[min_window_seconds, max_window_seconds]`. Prevents
       the two common footguns: a 7-day window that makes every payment
       "inside the window" (effectively a hard ceiling) and a sub-second
       window that makes the rule effectively per-transaction without
       the operator realising.

The module is deliberately framework-free: the Python classes enforce the
rules, the daemon wires the classes into its ops, and the CLI surfaces a
status / dry-run view. Tests cover each axis independently and the four
composed through the daemon.

YAML schema:

    governance:
      version: 1
      mutation_actors:
        - id: agent-payroll
          can_propose: [SpendingCap, MaxPerCall]
        - id: agent-treasury
          can_propose: [ProviderAllowlist, CounterpartyConstraint]
        - id: compliance-bot
          can_propose: "*"
      approval_requirements:
        SpendingCap:
          min_reviewers: 1
          reviewer_must_differ_from_submitter: true
        ProviderAllowlist:
          min_reviewers: 2
          reviewers_must_differ: true
      strict_mode_required_for:
        - RetryRateLimit
        - RollingWindowCap
        - InstabilityGuard
      temporal_rule_policy:
        max_window_seconds: 86400
        min_window_seconds: 60

Activation:

    TAU_CAGE_GOVERNANCE_YAML=/etc/tau-x402-cage/governance.yaml

When the env var points at a missing / malformed file the daemon FAILS
CLOSED at startup — we refuse to run with a governance policy that the
operator thinks is enforced but isn't.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Any, Dict, FrozenSet, Iterable, List, Mapping, Optional, Tuple

from adapter.invariants import (
    Invariant,
    RetryRateLimit,
    RollingWindowCap,
    SpendingCap,
)


# ── errors ───────────────────────────────────────────────────────────────────


class GovernanceLoadError(ValueError):
    """Raised when a governance YAML is missing, malformed, or self-inconsistent.

    Fail-closed: if the env var points at a file we can't parse we refuse
    to start the daemon rather than silently running without governance.
    """


# ── verdict types ────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class GovernanceVerdict:
    """Outcome of ``check_propose`` for an actor + invariant pair.

    Fields:
        allowed              : whether the propose is authorized.
        reason               : human-readable reason; None on allow.
        required_reviewers   : min distinct reviewers needed before admission
                               (defaults to 1 when no rule matches).
    """

    allowed: bool
    reason: Optional[str] = None
    required_reviewers: int = 1


# ── actor config ─────────────────────────────────────────────────────────────


# Sentinel matched literally against YAML entries to mean "any invariant class".
_WILDCARD = "*"


@dataclass(frozen=True)
class MutationActor:
    """A single mutation_actor block.

    `can_propose_wildcard` and `can_propose_classes` are mutually exclusive
    in construction: when the YAML says ``can_propose: "*"`` we set the
    wildcard flag and leave the class set empty.
    """

    id: str
    can_propose_wildcard: bool = False
    can_propose_classes: FrozenSet[str] = frozenset()

    def may_propose(self, class_name: str) -> bool:
        if self.can_propose_wildcard:
            return True
        return class_name in self.can_propose_classes


# ── approval requirement ─────────────────────────────────────────────────────


@dataclass(frozen=True)
class ApprovalRequirement:
    """Per-invariant-class approval gate.

    Fields:
        min_reviewers                      : number of DISTINCT reviewers
                                             whose approvals must accumulate
                                             before admission runs.
        reviewer_must_differ_from_submitter: legacy two-person integrity;
                                             set False only for trusted CI
                                             bots approving their own draft.
        reviewers_must_differ              : when min_reviewers > 1, the same
                                             reviewer approving twice does NOT
                                             count twice. The approval queue
                                             enforces this by storing the
                                             reviewers list.
    """

    min_reviewers: int = 1
    reviewer_must_differ_from_submitter: bool = True
    reviewers_must_differ: bool = True

    def __post_init__(self) -> None:
        if self.min_reviewers < 1:
            raise GovernanceLoadError(
                f"approval_requirements.min_reviewers must be >= 1, got {self.min_reviewers}"
            )


# Default requirement applied when no per-class rule matches: single reviewer,
# two-person integrity, dedup reviewers. Keeps v0.7.0 semantics as the floor.
_DEFAULT_REQUIREMENT = ApprovalRequirement()


# ── temporal-rule policy ─────────────────────────────────────────────────────


@dataclass(frozen=True)
class TemporalRulePolicy:
    """Numeric bounds on temporal invariants.

    Scoped to invariants that carry a time window: ``SpendingCap`` with
    per_window / per_provider_per_window scope, ``RollingWindowCap``, and
    ``RetryRateLimit`` (whose window is ``min_gap_seconds``).
    """

    min_window_seconds: Optional[int] = None
    max_window_seconds: Optional[int] = None

    def __post_init__(self) -> None:
        if self.min_window_seconds is not None and self.min_window_seconds < 0:
            raise GovernanceLoadError(
                f"temporal_rule_policy.min_window_seconds must be >= 0, "
                f"got {self.min_window_seconds}"
            )
        if (
            self.min_window_seconds is not None
            and self.max_window_seconds is not None
            and self.min_window_seconds > self.max_window_seconds
        ):
            raise GovernanceLoadError(
                f"temporal_rule_policy bounds inverted: "
                f"min={self.min_window_seconds} > max={self.max_window_seconds}"
            )


# ── main policy ──────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class GovernancePolicy:
    """Loaded governance policy. Immutable after construction."""

    version: int = 1
    actors: Tuple[MutationActor, ...] = ()
    approval_requirements: Mapping[str, ApprovalRequirement] = field(
        default_factory=dict
    )
    strict_mode_required_for: FrozenSet[str] = frozenset()
    temporal_rule_policy: TemporalRulePolicy = field(default_factory=TemporalRulePolicy)

    # ── lookups ────────────────────────────────────────────────────────────

    def get_actor(self, actor_id: str) -> Optional[MutationActor]:
        for a in self.actors:
            if a.id == actor_id:
                return a
        return None

    def get_requirement(self, class_name: str) -> ApprovalRequirement:
        return self.approval_requirements.get(class_name, _DEFAULT_REQUIREMENT)

    # ── the four policy axes ───────────────────────────────────────────────

    def check_propose(
        self, actor_id: Optional[str], invariant: Invariant
    ) -> GovernanceVerdict:
        """Is `actor_id` authorized to propose this invariant?

        When `actor_id` is None or empty, we treat the submission as
        anonymous and accept it (back-compat: pre-v0.14 callers never set
        an actor). Operators who want to block anonymous submissions must
        set TAU_CAGE_GOVERNANCE_REQUIRE_ACTOR=1 at daemon level.
        """
        class_name = type(invariant).__name__
        # Always report the requirement so the caller knows how many
        # reviewers to collect even on an allow.
        req = self.get_requirement(class_name)
        if not actor_id:
            return GovernanceVerdict(
                allowed=True,
                reason=None,
                required_reviewers=req.min_reviewers,
            )
        actor = self.get_actor(actor_id)
        if actor is None:
            return GovernanceVerdict(
                allowed=False,
                reason=(
                    f"actor {actor_id!r} not authorized to propose: "
                    f"no mutation_actors entry for this id"
                ),
                required_reviewers=req.min_reviewers,
            )
        if not actor.may_propose(class_name):
            return GovernanceVerdict(
                allowed=False,
                reason=(
                    f"actor {actor_id} not authorized to propose {class_name}"
                ),
                required_reviewers=req.min_reviewers,
            )
        return GovernanceVerdict(
            allowed=True,
            reason=None,
            required_reviewers=req.min_reviewers,
        )

    def check_approve(
        self,
        class_name: str,
        reviewers_approved: Iterable[str],
    ) -> bool:
        """Have enough DISTINCT reviewers approved to unlock admission?

        When `reviewers_must_differ` is True (the default) duplicates are
        collapsed before the count is compared against min_reviewers.
        """
        req = self.get_requirement(class_name)
        ids = [r for r in reviewers_approved if r]
        if req.reviewers_must_differ:
            distinct = len(set(ids))
        else:
            distinct = len(ids)
        return distinct >= req.min_reviewers

    def check_prover_mode(self, class_name: str, current_mode: str) -> bool:
        """Is `class_name` legal to admit under `current_mode`?

        Temporal invariants listed in `strict_mode_required_for` are only
        admissible when the daemon is in ``strict`` mode. Classes absent
        from the list are always legal.
        """
        if class_name not in self.strict_mode_required_for:
            return True
        return current_mode == "strict"

    def check_temporal_bounds(
        self, invariant: Invariant
    ) -> Tuple[bool, Optional[str]]:
        """Does the invariant's time window fall within policy bounds?

        Returns (True, None) when the invariant is non-temporal, carries
        no window, or sits inside both configured bounds. Otherwise
        returns (False, reason-with-offending-bound).
        """
        window = _extract_window_seconds(invariant)
        if window is None:
            return (True, None)
        t = self.temporal_rule_policy
        if t.min_window_seconds is not None and window < t.min_window_seconds:
            return (
                False,
                (
                    f"{type(invariant).__name__} window {window}s below "
                    f"temporal_rule_policy.min_window_seconds="
                    f"{t.min_window_seconds}"
                ),
            )
        if t.max_window_seconds is not None and window > t.max_window_seconds:
            return (
                False,
                (
                    f"{type(invariant).__name__} window {window}s exceeds "
                    f"temporal_rule_policy.max_window_seconds="
                    f"{t.max_window_seconds}"
                ),
            )
        return (True, None)

    # ── serialization ──────────────────────────────────────────────────────

    def to_dict(self) -> Dict[str, Any]:
        """JSON/YAML-safe representation suitable for round-trip tests."""
        actors_out: List[Dict[str, Any]] = []
        for a in self.actors:
            can_propose: Any
            if a.can_propose_wildcard:
                can_propose = _WILDCARD
            else:
                can_propose = sorted(a.can_propose_classes)
            actors_out.append({"id": a.id, "can_propose": can_propose})
        reqs_out: Dict[str, Dict[str, Any]] = {}
        for name, req in self.approval_requirements.items():
            reqs_out[name] = {
                "min_reviewers": req.min_reviewers,
                "reviewer_must_differ_from_submitter": (
                    req.reviewer_must_differ_from_submitter
                ),
                "reviewers_must_differ": req.reviewers_must_differ,
            }
        return {
            "governance": {
                "version": self.version,
                "mutation_actors": actors_out,
                "approval_requirements": reqs_out,
                "strict_mode_required_for": sorted(self.strict_mode_required_for),
                "temporal_rule_policy": {
                    "min_window_seconds": (
                        self.temporal_rule_policy.min_window_seconds
                    ),
                    "max_window_seconds": (
                        self.temporal_rule_policy.max_window_seconds
                    ),
                },
            }
        }

    def summary(self) -> str:
        """Human-readable one-block overview for `governance status`."""
        lines: List[str] = [f"Governance policy v{self.version}"]
        lines.append(f"  mutation_actors: {len(self.actors)}")
        for a in self.actors:
            if a.can_propose_wildcard:
                scope = "*"
            else:
                scope = ",".join(sorted(a.can_propose_classes)) or "(none)"
            lines.append(f"    - {a.id}: {scope}")
        lines.append(
            f"  approval_requirements: {len(self.approval_requirements)}"
        )
        for name, req in sorted(self.approval_requirements.items()):
            lines.append(
                f"    - {name}: min_reviewers={req.min_reviewers} "
                f"must_differ={req.reviewers_must_differ} "
                f"not_submitter={req.reviewer_must_differ_from_submitter}"
            )
        lines.append(
            f"  strict_mode_required_for: "
            f"{sorted(self.strict_mode_required_for) or '(none)'}"
        )
        t = self.temporal_rule_policy
        lines.append(
            f"  temporal_rule_policy: "
            f"min={t.min_window_seconds} max={t.max_window_seconds}"
        )
        return "\n".join(lines)


# ── loading ──────────────────────────────────────────────────────────────────


def load_governance_from_env(
    env: Optional[Mapping[str, str]] = None,
) -> Optional[GovernancePolicy]:
    """Load a GovernancePolicy from `TAU_CAGE_GOVERNANCE_YAML` if set.

    Returns None when the env var is unset/empty (feature disabled).
    Raises GovernanceLoadError — i.e. FAILS CLOSED at daemon startup —
    when the path is set but the file is missing, unreadable, or
    self-inconsistent.
    """
    source = env if env is not None else os.environ
    path_str = (source.get("TAU_CAGE_GOVERNANCE_YAML") or "").strip()
    if not path_str:
        return None
    return load_governance_from_path(Path(path_str))


def load_governance_from_path(path: Path) -> GovernancePolicy:
    """Parse and validate a governance YAML at `path`."""
    if not path.exists():
        raise GovernanceLoadError(
            f"governance YAML not found: {path} "
            f"(TAU_CAGE_GOVERNANCE_YAML points at a missing file; "
            f"fail-closed to avoid running without the intended policy)"
        )
    try:
        text = path.read_text(encoding="utf-8")
    except OSError as exc:
        raise GovernanceLoadError(f"governance YAML unreadable: {path}: {exc}") from exc
    try:
        import yaml  # type: ignore
    except ImportError as exc:
        raise GovernanceLoadError(
            "governance policy requires PyYAML. `pip install pyyaml` and retry."
        ) from exc
    try:
        parsed = yaml.safe_load(text)
    except Exception as exc:  # pragma: no cover - defensive YAML errors
        raise GovernanceLoadError(f"governance YAML malformed at {path}: {exc}") from exc
    if parsed is None:
        raise GovernanceLoadError(f"governance YAML at {path} is empty")
    return _build_policy_from_dict(parsed, source=str(path))


def load_governance_from_dict(data: Mapping[str, Any]) -> GovernancePolicy:
    """In-memory variant of load_governance_from_path for tests and round-trip."""
    return _build_policy_from_dict(data, source="<dict>")


def _build_policy_from_dict(
    data: Mapping[str, Any], source: str
) -> GovernancePolicy:
    if not isinstance(data, Mapping):
        raise GovernanceLoadError(
            f"governance YAML {source}: top-level must be a mapping, got {type(data).__name__}"
        )
    block = data.get("governance")
    if block is None:
        # Tolerate a flat shape where the YAML is *just* the governance block.
        # Operators hand-writing short files shouldn't be forced to nest.
        if _looks_like_governance_block(data):
            block = data
        else:
            raise GovernanceLoadError(
                f"governance YAML {source}: missing top-level 'governance:' key"
            )
    if not isinstance(block, Mapping):
        raise GovernanceLoadError(
            f"governance YAML {source}: 'governance' must be a mapping"
        )
    version = int(block.get("version", 1))
    if version != 1:
        raise GovernanceLoadError(
            f"governance YAML {source}: only version=1 is supported, got {version}"
        )
    actors = _parse_actors(block.get("mutation_actors") or [], source=source)
    approval_reqs = _parse_approval_requirements(
        block.get("approval_requirements") or {}, source=source
    )
    strict_required = _parse_strict_list(
        block.get("strict_mode_required_for") or [], source=source
    )
    temporal = _parse_temporal_policy(
        block.get("temporal_rule_policy") or {}, source=source
    )
    return GovernancePolicy(
        version=version,
        actors=actors,
        approval_requirements=approval_reqs,
        strict_mode_required_for=strict_required,
        temporal_rule_policy=temporal,
    )


def _looks_like_governance_block(data: Mapping[str, Any]) -> bool:
    """Heuristic: the flat shape has at least one of the four policy keys."""
    keys = {
        "mutation_actors",
        "approval_requirements",
        "strict_mode_required_for",
        "temporal_rule_policy",
    }
    return any(k in data for k in keys)


def _parse_actors(raw: Any, *, source: str) -> Tuple[MutationActor, ...]:
    if not isinstance(raw, list):
        raise GovernanceLoadError(
            f"{source}: mutation_actors must be a list, got {type(raw).__name__}"
        )
    actors: List[MutationActor] = []
    seen_ids: set = set()
    for idx, entry in enumerate(raw):
        if not isinstance(entry, Mapping):
            raise GovernanceLoadError(
                f"{source}: mutation_actors[{idx}] must be a mapping"
            )
        actor_id = str(entry.get("id") or "").strip()
        if not actor_id:
            raise GovernanceLoadError(
                f"{source}: mutation_actors[{idx}] missing non-empty 'id'"
            )
        if actor_id in seen_ids:
            raise GovernanceLoadError(
                f"{source}: duplicate mutation_actor id {actor_id!r}"
            )
        seen_ids.add(actor_id)
        cp = entry.get("can_propose")
        if cp is None:
            raise GovernanceLoadError(
                f"{source}: mutation_actors[{idx}] missing 'can_propose'"
            )
        wildcard = False
        classes: FrozenSet[str]
        if isinstance(cp, str):
            if cp.strip() == _WILDCARD:
                wildcard = True
                classes = frozenset()
            else:
                # Allow a single class as a bare string.
                classes = frozenset({cp.strip()})
        elif isinstance(cp, list):
            names: List[str] = []
            for c in cp:
                if not isinstance(c, str) or not c.strip():
                    raise GovernanceLoadError(
                        f"{source}: mutation_actors[{idx}].can_propose entries "
                        f"must be non-empty strings, got {c!r}"
                    )
                names.append(c.strip())
            classes = frozenset(names)
        else:
            raise GovernanceLoadError(
                f"{source}: mutation_actors[{idx}].can_propose must be "
                f"'*' or a list of class names, got {type(cp).__name__}"
            )
        actors.append(
            MutationActor(
                id=actor_id,
                can_propose_wildcard=wildcard,
                can_propose_classes=classes,
            )
        )
    return tuple(actors)


def _parse_approval_requirements(
    raw: Any, *, source: str
) -> Dict[str, ApprovalRequirement]:
    if not isinstance(raw, Mapping):
        raise GovernanceLoadError(
            f"{source}: approval_requirements must be a mapping, "
            f"got {type(raw).__name__}"
        )
    out: Dict[str, ApprovalRequirement] = {}
    for class_name, body in raw.items():
        if not isinstance(class_name, str) or not class_name.strip():
            raise GovernanceLoadError(
                f"{source}: approval_requirements keys must be class name "
                f"strings, got {class_name!r}"
            )
        if not isinstance(body, Mapping):
            body = {}
        try:
            req = ApprovalRequirement(
                min_reviewers=int(body.get("min_reviewers", 1)),
                reviewer_must_differ_from_submitter=bool(
                    body.get("reviewer_must_differ_from_submitter", True)
                ),
                reviewers_must_differ=bool(body.get("reviewers_must_differ", True)),
            )
        except (TypeError, ValueError) as exc:
            raise GovernanceLoadError(
                f"{source}: approval_requirements[{class_name!r}] invalid: {exc}"
            ) from exc
        out[class_name.strip()] = req
    return out


def _parse_strict_list(raw: Any, *, source: str) -> FrozenSet[str]:
    if not isinstance(raw, list):
        raise GovernanceLoadError(
            f"{source}: strict_mode_required_for must be a list, "
            f"got {type(raw).__name__}"
        )
    names: List[str] = []
    for entry in raw:
        if not isinstance(entry, str) or not entry.strip():
            raise GovernanceLoadError(
                f"{source}: strict_mode_required_for entries must be "
                f"non-empty strings, got {entry!r}"
            )
        names.append(entry.strip())
    return frozenset(names)


def _parse_temporal_policy(raw: Any, *, source: str) -> TemporalRulePolicy:
    if not isinstance(raw, Mapping):
        raise GovernanceLoadError(
            f"{source}: temporal_rule_policy must be a mapping, "
            f"got {type(raw).__name__}"
        )

    def _maybe_int(v: Any, field_name: str) -> Optional[int]:
        if v is None:
            return None
        try:
            return int(v)
        except (TypeError, ValueError) as exc:
            raise GovernanceLoadError(
                f"{source}: temporal_rule_policy.{field_name} must be int, "
                f"got {v!r}"
            ) from exc

    return TemporalRulePolicy(
        min_window_seconds=_maybe_int(raw.get("min_window_seconds"), "min_window_seconds"),
        max_window_seconds=_maybe_int(raw.get("max_window_seconds"), "max_window_seconds"),
    )


# ── helpers ──────────────────────────────────────────────────────────────────


def _extract_window_seconds(invariant: Invariant) -> Optional[int]:
    """Return the time-window field for temporal invariants, None otherwise.

    * `SpendingCap` with per_window / per_provider_per_window uses
      `window_seconds`.
    * `RollingWindowCap` uses `window_seconds`.
    * `RetryRateLimit` uses `min_gap_seconds` (same intent: how long is
      the relevant look-back).
    * `InstabilityGuard` carries `window_seconds`; handled by attribute
      lookup below.
    """
    if isinstance(invariant, SpendingCap):
        if invariant.window_seconds is None:
            return None
        return int(invariant.window_seconds)
    if isinstance(invariant, RollingWindowCap):
        return int(invariant.window_seconds)
    if isinstance(invariant, RetryRateLimit):
        return int(invariant.min_gap_seconds)
    # InstabilityGuard lives in a sibling module; avoid a hard import loop.
    window = getattr(invariant, "window_seconds", None)
    if isinstance(window, int):
        return window
    return None


__all__ = [
    "ApprovalRequirement",
    "GovernanceLoadError",
    "GovernancePolicy",
    "GovernanceVerdict",
    "MutationActor",
    "TemporalRulePolicy",
    "load_governance_from_dict",
    "load_governance_from_env",
    "load_governance_from_path",
]
