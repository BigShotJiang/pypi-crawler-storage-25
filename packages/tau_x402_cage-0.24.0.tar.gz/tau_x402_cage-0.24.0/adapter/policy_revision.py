"""Durable PolicyRevision records + append-only RevisionLog.

A PolicyRevision freezes the state of the cage's admission decisions at a
single point in time: the invariant set that was just admitted, the proof
backend that admitted it, the daemon mode under which it was admitted, and
the compile-hash / fragment-version / tau-backend-version that give an
auditor enough provenance to re-run the check later.

The RevisionLog holds an ordered chain of PolicyRevisions. It can persist
to disk as JSON-lines and replay on daemon startup so operators do not lose
their audit trail across daemon restarts.

Design notes:
  * Immutable dataclasses (frozen=True). Every mutation returns a new value.
  * JSON-lines on disk, one revision per line, append-only. Corrupted lines
    raise on load, we never silently drop records from the audit trail.
  * Invariants are serialized via {class_name, repr}. On load we look up
    class_name in an INVARIANT_CONSTRUCTORS map and rehydrate via a stored
    repr-equivalent dict. Only classes registered at import time can rehydrate
    so auditors can confirm the wire taxonomy by reading the registry.
  * `revision_id` is derived from (config_hash, nonce). This keeps the id
    content-addressed (same invariants => same config_hash) while still
    unique per admission (nonce rotates).

Branching (v0.7.0):
  * Revisions carry an optional `branch` field (default `"main"`). Revisions
    on different branches share ancestry up to the branch point, forming a
    DAG rather than a linear chain.
  * `Branch` records live in the same jsonl, discriminated by a
    `_record_type` tag. Revisions are written as untagged dicts so v0.6.x
    readers see the same shape.
  * The log's `latest` returns the head of the currently-active branch, not
    the last physically-appended revision. This keeps `_apply_revision`
    semantics branch-aware without touching the hot-path callers.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field, fields
from decimal import Decimal
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Optional, Tuple

from adapter.invariants import (
    CounterpartyConstraint,
    Invariant,
    JurisdictionRule,
    MaxPerCall,
    MutualExclusion,
    ProviderAllowlist,
    RetryRateLimit,
    RollingWindowCap,
    SpendingCap,
)


# ── invariant (de)serialization map ──────────────────────────────────────────


def _serialize_spending_cap(inv: SpendingCap) -> Dict[str, Any]:
    return {
        "max_amount": str(inv.max_amount),
        "currency": inv.currency,
        "scope": inv.scope,
        "window_seconds": inv.window_seconds,
        "provider": inv.provider,
    }


def _construct_spending_cap(d: Dict[str, Any]) -> SpendingCap:
    return SpendingCap(
        max_amount=Decimal(str(d["max_amount"])),
        currency=d.get("currency", "USDC"),
        scope=d.get("scope", "per_window"),
        window_seconds=d.get("window_seconds"),
        provider=d.get("provider"),
    )


def _serialize_max_per_call(inv: MaxPerCall) -> Dict[str, Any]:
    return {"max_amount": str(inv.max_amount), "currency": inv.currency}


def _construct_max_per_call(d: Dict[str, Any]) -> MaxPerCall:
    return MaxPerCall(
        max_amount=Decimal(str(d["max_amount"])),
        currency=d.get("currency", "USDC"),
    )


def _serialize_provider_allowlist(inv: ProviderAllowlist) -> Dict[str, Any]:
    return {"providers": sorted(inv.providers)}


def _construct_provider_allowlist(d: Dict[str, Any]) -> ProviderAllowlist:
    return ProviderAllowlist(providers=frozenset(d.get("providers", [])))


def _serialize_retry_rate_limit(inv: RetryRateLimit) -> Dict[str, Any]:
    return {"min_gap_seconds": inv.min_gap_seconds}


def _construct_retry_rate_limit(d: Dict[str, Any]) -> RetryRateLimit:
    return RetryRateLimit(min_gap_seconds=int(d["min_gap_seconds"]))


def _serialize_rolling_window_cap(inv: RollingWindowCap) -> Dict[str, Any]:
    return {
        "max_count": inv.max_count,
        "window_seconds": inv.window_seconds,
        "group_by": inv.group_by,
    }


def _construct_rolling_window_cap(d: Dict[str, Any]) -> RollingWindowCap:
    return RollingWindowCap(
        max_count=int(d["max_count"]),
        window_seconds=int(d["window_seconds"]),
        group_by=d.get("group_by", "provider"),
    )


def _serialize_counterparty_constraint(inv: CounterpartyConstraint) -> Dict[str, Any]:
    return {
        "approved_ids": sorted(inv.approved_ids),
        "sanctioned_ids": sorted(inv.sanctioned_ids),
    }


def _construct_counterparty_constraint(d: Dict[str, Any]) -> CounterpartyConstraint:
    return CounterpartyConstraint(
        approved_ids=frozenset(d.get("approved_ids", [])),
        sanctioned_ids=frozenset(d.get("sanctioned_ids", [])),
    )


def _serialize_mutual_exclusion(inv: MutualExclusion) -> Dict[str, Any]:
    return {
        "group_a": sorted(inv.group_a),
        "group_b": sorted(inv.group_b),
    }


def _construct_mutual_exclusion(d: Dict[str, Any]) -> MutualExclusion:
    return MutualExclusion(
        group_a=frozenset(d.get("group_a", [])),
        group_b=frozenset(d.get("group_b", [])),
    )


def _serialize_jurisdiction_rule(inv: JurisdictionRule) -> Dict[str, Any]:
    return {
        "jurisdiction": inv.jurisdiction,
        "additional_invariants": [
            _serialize_invariant(sub) for sub in inv.additional_invariants
        ],
    }


def _construct_jurisdiction_rule(d: Dict[str, Any]) -> JurisdictionRule:
    subs = tuple(
        _rehydrate_invariant(sub) for sub in d.get("additional_invariants", [])
    )
    return JurisdictionRule(
        jurisdiction=d["jurisdiction"],
        additional_invariants=subs,
    )


#: Map class-name -> (serializer, constructor). Registered at import time;
#: auditors inspect this dict to enumerate the full rehydration taxonomy.
INVARIANT_SERIALIZERS: Dict[str, Callable[[Invariant], Dict[str, Any]]] = {
    "SpendingCap": _serialize_spending_cap,
    "MaxPerCall": _serialize_max_per_call,
    "ProviderAllowlist": _serialize_provider_allowlist,
    "RetryRateLimit": _serialize_retry_rate_limit,
    "RollingWindowCap": _serialize_rolling_window_cap,
    "CounterpartyConstraint": _serialize_counterparty_constraint,
    "MutualExclusion": _serialize_mutual_exclusion,
    "JurisdictionRule": _serialize_jurisdiction_rule,
}


INVARIANT_CONSTRUCTORS: Dict[str, Callable[[Dict[str, Any]], Invariant]] = {
    "SpendingCap": _construct_spending_cap,
    "MaxPerCall": _construct_max_per_call,
    "ProviderAllowlist": _construct_provider_allowlist,
    "RetryRateLimit": _construct_retry_rate_limit,
    "RollingWindowCap": _construct_rolling_window_cap,
    "CounterpartyConstraint": _construct_counterparty_constraint,
    "MutualExclusion": _construct_mutual_exclusion,
    "JurisdictionRule": _construct_jurisdiction_rule,
}


class RevisionLogError(ValueError):
    """Raised for malformed revision-log lines or unknown invariant classes."""


class CrossRevisionRejected(RevisionLogError):
    """Raised when a cross-revision validator refuses to admit a revision.

    Subclass of :class:`RevisionLogError` so existing ``except
    RevisionLogError`` call sites keep working; new callers can catch
    this specifically to render the structured violations. The attached
    ``result`` carries the full list of
    :class:`adapter.cross_revision.CrossRevisionViolation` entries.
    """

    def __init__(self, message: str, result: Any) -> None:
        super().__init__(message)
        self.result = result


def _serialize_invariant(inv: Invariant) -> Dict[str, Any]:
    cls = type(inv).__name__
    ser = INVARIANT_SERIALIZERS.get(cls)
    if ser is None:
        raise RevisionLogError(
            f"cannot serialize invariant {cls!r}: no serializer registered"
        )
    return {"class_name": cls, "repr": ser(inv)}


def _rehydrate_invariant(entry: Dict[str, Any]) -> Invariant:
    if not isinstance(entry, dict):
        raise RevisionLogError(f"invariant entry not a dict: {entry!r}")
    cls = entry.get("class_name")
    repr_d = entry.get("repr")
    if cls is None or repr_d is None:
        raise RevisionLogError(
            f"invariant entry missing class_name/repr: {entry!r}"
        )
    ctor = INVARIANT_CONSTRUCTORS.get(cls)
    if ctor is None:
        raise RevisionLogError(
            f"no constructor registered for invariant class {cls!r}"
        )
    return ctor(repr_d)


# ── PolicyRevision ───────────────────────────────────────────────────────────


@dataclass(frozen=True)
class PolicyRevision:
    """A single admitted revision of the cage's policy state.

    Load-bearing for provenance: every signed x402 verdict envelope v2 MACs
    (revision_id, proof_backend, proof_strength, prover_mode, compile_hash)
    so downstream verifiers can correlate the envelope back to the exact
    policy state that decided the payment.

    Pointwise-revision fields (v0.6.0+):
        delta               : what changed vs predecessor. Shape:
                              {"added": [ser, ...], "removed": [ser, ...]}.
                              Empty dict for the genesis revision.
        revision_depth      : 0 for genesis, +1 for every admitted child.
                              Indexing into the chain without walking.

    Fields:
        revision_id             : content-addressed id = f"{config_hash}:{nonce}".
        invariants              : tuple of active invariants at this revision.
        proof_backend           : prover backend name
                                  ("tau" | "z3" | "chained:tau->pattern" | "python-pattern").
        proof_strength          : "complete" | "pattern" | "pattern+tau-inconclusive" | ...
        prover_mode             : "compat" | "verified" | "strict".
        compile_hash            : SHA-256 of the Tau/z3 source fed to the prover
                                  (None for pattern-only admissions).
        fragment_version        : which semantic fragment the compiler targeted
                                  ("v1", "v2", None).
        tau_backend_version     : version string of the Tau runtime when reachable.
        admitted_at_unix        : epoch seconds when the admission succeeded.
        predecessor_revision_id : revision_id of the preceding revision.
        delta                   : structural diff vs predecessor (see above).
        revision_depth          : index into the chain; 0 for genesis.
        merge_parent_ids        : v0.8.0 — populated only on merge commits built
                                  by three-way merge. Tuple (dst_parent, src_parent)
                                  recording both sides of the merge. For non-merge
                                  revisions this is ``None`` and
                                  ``predecessor_revision_id`` is the only parent.
    """

    revision_id: str
    invariants: tuple
    proof_backend: str
    proof_strength: str
    prover_mode: str
    compile_hash: Optional[str]
    fragment_version: Optional[str]
    tau_backend_version: Optional[str]
    admitted_at_unix: int
    predecessor_revision_id: Optional[str]
    # v0.6.0 pointwise-revision fields (defaults keep v0.5.x callers working)
    delta: Dict[str, Any] = field(default_factory=dict)
    revision_depth: int = 0
    # v0.7.0 branching: which branch this revision lives on. Defaults to
    # "main" so existing callers + persisted v0.6.x logs round-trip unchanged.
    branch: str = "main"
    # v0.8.0 three-way-merge: (dst_parent_id, src_parent_id) on merge commits,
    # None on ordinary linear revisions. Chain walks must follow both parents
    # when this is set; see RevisionLog._all_parents().
    merge_parent_ids: Optional[Tuple[str, str]] = None
    # v0.13.0 strict mutation contract: risk taxonomy (low|medium|high) and
    # the shared-variable scope projection captured at admit time. Both are
    # optional so v0.12.x logs round-trip unchanged; new revisions carry
    # them whenever the daemon routed through ``apply_revision_delta_strict``.
    #
    # v0.22.0 adds an optional ``overrides`` key to ``affected_scope``:
    #
    #     affected_scope["overrides"] = {
    #         "<rule_id>": ("core", ...),  # tuple of protection classes
    #         ...
    #     }
    #
    # Keys are caller-chosen stable rule identifiers; values are tuples of
    # protection-class tags. ``"core"`` is the canonical tag meaning
    # "BranchRespectsCore refuses to drop this rule on a feature → main
    # merge". Tests and callers may register additional classes for
    # forward compatibility; unknown tags are simply ignored by the
    # guaranteed-mutation validator.
    #
    # The ``overrides`` key can ALSO carry the earlier shape used by
    # :class:`adapter.cross_revision.OverridesMustExpire` — a dict keyed
    # by string-of-integer invariant index whose values are
    # ``{"expires_at_unix": int}``. The two shapes are distinguishable
    # by value type: dict → TTL override; tuple → core-protection
    # provenance. Both can coexist inside the same ``overrides`` map.
    mutation_risk: Optional[str] = None
    affected_scope: Optional[Dict[str, Any]] = None

    # Alias for brief-compatibility -- callers may reference either name.
    @property
    def parent_revision_id(self) -> Optional[str]:
        return self.predecessor_revision_id

    # ── (de)serialization ───────────────────────────────────────────────────

    def to_dict(self) -> Dict[str, Any]:
        """JSON-safe dict representation. Invariants are serialized via
        `{class_name, repr}` so the dict round-trips cleanly."""
        d: Dict[str, Any] = {
            "revision_id": self.revision_id,
            "invariants": [_serialize_invariant(inv) for inv in self.invariants],
            "proof_backend": self.proof_backend,
            "proof_strength": self.proof_strength,
            "prover_mode": self.prover_mode,
            "compile_hash": self.compile_hash,
            "fragment_version": self.fragment_version,
            "tau_backend_version": self.tau_backend_version,
            "admitted_at_unix": self.admitted_at_unix,
            "predecessor_revision_id": self.predecessor_revision_id,
            "delta": dict(self.delta),
            "revision_depth": self.revision_depth,
            "branch": self.branch,
        }
        # Only emit merge_parent_ids on actual merge commits so linear
        # revisions round-trip byte-identical to v0.7.0.
        if self.merge_parent_ids is not None:
            d["merge_parent_ids"] = list(self.merge_parent_ids)
        # v0.13.0: mutation_risk / affected_scope only written when the
        # revision was admitted through the strict mutation contract path.
        # Keeps pre-v0.13 records byte-identical on round-trip.
        if self.mutation_risk is not None:
            d["mutation_risk"] = self.mutation_risk
        if self.affected_scope is not None:
            d["affected_scope"] = dict(self.affected_scope)
        return d

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "PolicyRevision":
        """Rebuild a PolicyRevision from its JSON-safe dict."""
        required = {
            "revision_id",
            "invariants",
            "proof_backend",
            "proof_strength",
            "prover_mode",
            "admitted_at_unix",
        }
        missing = required - d.keys()
        if missing:
            raise RevisionLogError(
                f"PolicyRevision dict missing fields: {sorted(missing)}"
            )
        invariants = tuple(_rehydrate_invariant(e) for e in d["invariants"])
        raw_merge = d.get("merge_parent_ids")
        merge_parents: Optional[Tuple[str, str]] = None
        if raw_merge is not None:
            if (
                not isinstance(raw_merge, (list, tuple))
                or len(raw_merge) != 2
                or not all(isinstance(x, str) for x in raw_merge)
            ):
                raise RevisionLogError(
                    f"merge_parent_ids must be a 2-tuple of strings, got {raw_merge!r}"
                )
            merge_parents = (raw_merge[0], raw_merge[1])
        raw_scope = d.get("affected_scope")
        parsed_scope: Optional[Dict[str, Any]] = None
        if raw_scope is not None:
            if not isinstance(raw_scope, dict):
                raise RevisionLogError(
                    f"affected_scope must be a dict, got {type(raw_scope).__name__}"
                )
            parsed_scope = dict(raw_scope)
        return cls(
            revision_id=d["revision_id"],
            invariants=invariants,
            proof_backend=d["proof_backend"],
            proof_strength=d["proof_strength"],
            prover_mode=d["prover_mode"],
            compile_hash=d.get("compile_hash"),
            fragment_version=d.get("fragment_version"),
            tau_backend_version=d.get("tau_backend_version"),
            admitted_at_unix=int(d["admitted_at_unix"]),
            predecessor_revision_id=d.get("predecessor_revision_id"),
            delta=dict(d.get("delta", {})),
            revision_depth=int(d.get("revision_depth", 0)),
            branch=str(d.get("branch", "main")),
            merge_parent_ids=merge_parents,
            mutation_risk=d.get("mutation_risk"),
            affected_scope=parsed_scope,
        )

    # ── factory from a ProofToken + committed registry ─────────────────────

    @classmethod
    def from_proof_token(
        cls,
        token: Any,  # ProofToken; typed Any to dodge an import cycle
        invariants: Iterable[Invariant],
        predecessor_revision_id: Optional[str],
    ) -> "PolicyRevision":
        """Build a PolicyRevision from a decisive ProofToken.

        `revision_id` = f"{config_hash}:{nonce}". Content-addressed (config_hash)
        + unique per admission (nonce), which matches how the underlying token
        is deduped elsewhere in the pipeline.
        """
        config_hash = getattr(token, "config_hash", "")
        nonce = getattr(token, "nonce", "")
        revision_id = f"{config_hash}:{nonce}"
        return cls(
            revision_id=revision_id,
            invariants=tuple(invariants),
            proof_backend=getattr(token, "backend", "unknown"),
            proof_strength=getattr(token, "proof_strength", "unknown"),
            prover_mode=getattr(token, "prover_mode", None) or "compat",
            compile_hash=getattr(token, "compile_hash", None),
            fragment_version=getattr(token, "fragment_version", None),
            tau_backend_version=getattr(token, "tau_backend_version", None),
            admitted_at_unix=int(getattr(token, "issued_at_unix", 0)),
            predecessor_revision_id=predecessor_revision_id,
        )


# ── Branch model (v0.7.0) ────────────────────────────────────────────────────


#: Default branch name. Revisions admitted before any explicit `create_branch`
#: call live on this branch so pre-v0.7 callers and stored logs round-trip.
DEFAULT_BRANCH = "main"


@dataclass(frozen=True)
class Branch:
    """A named pointer into the revision DAG.

    Branches are cheap metadata; the heavy state lives in the `PolicyRevision`
    records. A branch stores only its current head and provenance (creator +
    creation time) so auditors can reconstruct who opened a shadow policy and
    when.

    Fields:
        name             : the branch's short human-readable handle.
        head_revision_id : revision_id at the branch's tip, or None when the
                           branch was opened against an empty log (genesis).
        created_at       : epoch seconds when the branch was created.
        created_by       : free-form creator identifier (operator id, service
                           name, etc.). Empty string when unknown.
    """

    name: str
    head_revision_id: Optional[str]
    created_at: int
    created_by: str = ""

    def with_head(self, head_revision_id: Optional[str]) -> "Branch":
        """Return a copy of this branch pointing at a new head.

        Frozen dataclass, so the old Branch is untouched; callers should
        replace their reference with the returned value.
        """
        return Branch(
            name=self.name,
            head_revision_id=head_revision_id,
            created_at=self.created_at,
            created_by=self.created_by,
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "_record_type": "branch",
            "name": self.name,
            "head_revision_id": self.head_revision_id,
            "created_at": self.created_at,
            "created_by": self.created_by,
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "Branch":
        name = d.get("name")
        if not isinstance(name, str) or not name:
            raise RevisionLogError(f"branch record missing 'name': {d!r}")
        return cls(
            name=name,
            head_revision_id=d.get("head_revision_id"),
            created_at=int(d.get("created_at", 0)),
            created_by=str(d.get("created_by", "")),
        )


@dataclass(frozen=True)
class BranchMergeConflict:
    """Structured result returned by `RevisionLog.merge_branch` when a
    three-way merge is not possible because both branches touched the same
    invariant class relative to the common ancestor.

    Shape matches the docstring: two delta sets describing what each side
    changed relative to the common ancestor, plus an explicit enumeration
    of the class names that overlap so callers don't have to diff the
    two delta sets themselves.

    Fields:
        src                    : source branch name (the branch with the work).
        dst                    : destination branch name.
        src_head               : revision_id of src's head.
        dst_head               : revision_id of dst's head.
        common_ancestor        : revision_id shared by both heads (may be None
                                 if the branches share no common ancestor, e.g.
                                 an orphaned branch created from empty log).
        src_delta              : serialized {added, removed} of src_head vs
                                 common ancestor.
        dst_delta              : serialized {added, removed} of dst_head vs
                                 common ancestor.
        conflicting_invariants : v0.8.0 — list of {class_name, src_ops, dst_ops}
                                 entries naming each invariant class both sides
                                 touched. ``src_ops`` / ``dst_ops`` are subsets
                                 of ``["added", "removed"]``. Kept for
                                 back-compat; new callers should prefer
                                 ``classified_conflicts`` below.
        classified_conflicts   : v0.14.0 — list of ``ClassifiedConflict``
                                 dicts adding a ``category`` taxonomy
                                 (syntactic / semantic / temporal /
                                 unsupported_fragment), a per-class
                                 ``diagnosis`` string and an optional
                                 ``suggested_repair``. Populated in
                                 parallel with ``conflicting_invariants``
                                 so v0.8.x callers reading the legacy
                                 field continue to work.
    """

    src: str
    dst: str
    src_head: Optional[str]
    dst_head: Optional[str]
    common_ancestor: Optional[str]
    src_delta: Dict[str, Any]
    dst_delta: Dict[str, Any]
    conflicting_invariants: List[Dict[str, Any]] = field(default_factory=list)
    classified_conflicts: List[Dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "conflict": True,
            "src": self.src,
            "dst": self.dst,
            "src_head": self.src_head,
            "dst_head": self.dst_head,
            "common_ancestor": self.common_ancestor,
            "src_delta": dict(self.src_delta),
            "dst_delta": dict(self.dst_delta),
            "conflicting_invariants": [dict(e) for e in self.conflicting_invariants],
            "classified_conflicts": [dict(e) for e in self.classified_conflicts],
        }


# ── three-way merge helpers ──────────────────────────────────────────────────


def _touched_classes(delta: Dict[str, Any]) -> Dict[str, List[str]]:
    """Return {class_name: [ops...]} for a `{added, removed}` delta dict.

    An invariant class is "touched" on a side if it appears in either
    ``added`` or ``removed``. ``ops`` is an ordered subset of
    ``["added", "removed"]`` so reporting stays deterministic; a
    modification shows both.
    """
    by_class: Dict[str, List[str]] = {}
    for entry in delta.get("added", []):
        cls = entry.get("class_name") if isinstance(entry, dict) else None
        if not isinstance(cls, str):
            continue
        ops = by_class.setdefault(cls, [])
        if "added" not in ops:
            ops.append("added")
    for entry in delta.get("removed", []):
        cls = entry.get("class_name") if isinstance(entry, dict) else None
        if not isinstance(cls, str):
            continue
        ops = by_class.setdefault(cls, [])
        if "removed" not in ops:
            ops.append("removed")
    return by_class


def _find_conflicting_invariants(
    src_delta: Dict[str, Any],
    dst_delta: Dict[str, Any],
) -> List[Dict[str, Any]]:
    """Identify invariant classes that both sides touched.

    Two branches are "disjoint" (safe to auto three-way merge) when no
    invariant class appears on both sides' deltas. If BOTH sides add an
    invariant with identical ``(class_name, repr)`` it's idempotent and
    still safe; we detect and allow that exact case explicitly so real
    non-conflicts don't get blocked.

    The returned list is sorted by class name for determinism and is
    embedded verbatim in ``BranchMergeConflict.conflicting_invariants``.
    Empty list ⇒ branches are disjoint.
    """
    src_touched = _touched_classes(src_delta)
    dst_touched = _touched_classes(dst_delta)
    overlap_classes = sorted(set(src_touched) & set(dst_touched))
    if not overlap_classes:
        return []
    # Allow the case where the ONLY overlap is that both sides added an
    # identical invariant (same class_name + repr) and neither side removed
    # anything of that class. Under our merge semantics the result is
    # identical regardless of which side contributed it.
    src_added_keys = {
        (e.get("class_name"), json.dumps(e.get("repr"), sort_keys=True))
        for e in src_delta.get("added", [])
        if isinstance(e, dict)
    }
    dst_added_keys = {
        (e.get("class_name"), json.dumps(e.get("repr"), sort_keys=True))
        for e in dst_delta.get("added", [])
        if isinstance(e, dict)
    }
    truly_conflicting: List[Dict[str, Any]] = []
    for cls in overlap_classes:
        src_ops = src_touched.get(cls, [])
        dst_ops = dst_touched.get(cls, [])
        # Idempotent add on both sides with no removals → not a conflict.
        if (
            src_ops == ["added"]
            and dst_ops == ["added"]
            and any(k[0] == cls for k in src_added_keys & dst_added_keys)
            # Confirm every added entry for this class on both sides matches
            # an entry on the other side by (class_name, repr).
        ):
            src_for_cls = {k for k in src_added_keys if k[0] == cls}
            dst_for_cls = {k for k in dst_added_keys if k[0] == cls}
            if src_for_cls == dst_for_cls:
                continue
        truly_conflicting.append({
            "class_name": cls,
            "src_ops": list(src_ops),
            "dst_ops": list(dst_ops),
        })
    return truly_conflicting


# ── v0.14.0 classification integration ──────────────────────────────────────


def _classify_for_conflict(
    *,
    src_delta: Dict[str, Any],
    dst_delta: Dict[str, Any],
    ancestor_id: Optional[str],
    src: str,
    dst: str,
) -> List[Dict[str, Any]]:
    """Run ``merge_classifier.classify_conflict`` and return serialized results.

    Lazy import keeps ``adapter.merge_classifier`` free to depend on
    ``policy_revision`` helpers without a circular import at module load.
    Defensive: any classifier failure falls back to an empty list so a
    conflict still surfaces its legacy ``conflicting_invariants`` payload
    even if classification hits an edge case.

    ``prover_supports_v2`` defaults to True here because the log itself
    does not know the daemon's prover configuration. The daemon wires
    the real value when it builds the final payload (see the caller in
    ``CageDaemon._op_merge_branch``).
    """
    try:
        from adapter.merge_classifier import classify_conflict
    except Exception:  # noqa: BLE001 — importability issues must not block merges.
        return []
    try:
        classified = classify_conflict(
            src_delta=src_delta,
            dst_delta=dst_delta,
            src_branch=src,
            dst_branch=dst,
        )
    except Exception:  # noqa: BLE001 — classifier bugs must not block merges.
        return []
    return [c.to_dict() for c in classified]


# ── RevisionLog ──────────────────────────────────────────────────────────────


@dataclass
class RevisionLog:
    """Append-only DAG of PolicyRevisions organised into named branches.

    Optional disk backing: when `path` is provided, every `append()` writes
    a JSON line to the file. Branch creation / checkout / merge events are
    persisted as `_record_type = "branch" | "checkout" | "merge"` records in
    the same jsonl so the audit trail is a single document.

    Immutability note: PolicyRevision and Branch values are frozen. The log
    container is mutable because append-only operation must update the head
    pointers for each branch. Callers that need a snapshot use `list(log)`
    or `log.revisions`.

    Branching model (v0.7.0):
      * A branch is a named pointer at a `head_revision_id`.
      * `append(revision)` places the revision on the currently-active
        branch unless the revision itself declares a different `branch`.
      * `latest` returns the head of the active branch. Pre-v0.7 callers see
        the default branch "main" unchanged.
      * Merges are fast-forward only in V1. A non-FF merge returns a
        `BranchMergeConflict`; no 3-way reconciliation is attempted.
    """

    path: Optional[Path] = None
    _revisions: list = field(default_factory=list)
    _branches: Dict[str, Branch] = field(default_factory=dict)
    _active_branch: str = DEFAULT_BRANCH
    _revisions_by_id: Dict[str, PolicyRevision] = field(default_factory=dict)
    # v0.14.0 optional cross-revision compositional validator. When set,
    # ``append()`` and ``merge_branch()`` run ``validator.validate(pred,
    # new, branch)`` BEFORE persisting and refuse to admit on violations.
    # ``None`` preserves pre-v0.14 behaviour bit-identically.
    cross_revision_validator: Optional[Any] = None

    # ── query ──────────────────────────────────────────────────────────────

    @property
    def revisions(self) -> Tuple[PolicyRevision, ...]:
        """Immutable snapshot of the current chain (all branches, in
        append order). Equivalent to v0.6.x semantics when only `main`
        is active."""
        return tuple(self._revisions)

    def __len__(self) -> int:
        return len(self._revisions)

    def __iter__(self):
        return iter(self._revisions)

    @property
    def active_branch(self) -> str:
        """Name of the currently-active branch. Defaults to "main"."""
        return self._active_branch

    @property
    def latest(self) -> Optional[PolicyRevision]:
        """Head of the active branch, or None if the branch is empty.

        v0.6.x callers only ever used "main"; they continue to see linear
        semantics because every append goes to "main" until a caller
        explicitly opens a new branch.
        """
        head_id = self._head_id_for(self._active_branch)
        if head_id is None:
            return None
        return self._revisions_by_id.get(head_id)

    def head_of(self, branch_name: str) -> Optional[PolicyRevision]:
        """Return the head PolicyRevision of `branch_name`, or None."""
        head_id = self._head_id_for(branch_name)
        if head_id is None:
            return None
        return self._revisions_by_id.get(head_id)

    def _head_id_for(self, branch_name: str) -> Optional[str]:
        """Head revision id of branch `branch_name`.

        Resolution order:
          1. Explicit Branch record (from `create_branch` / `merge_branch`).
          2. For the default branch: fall back to the last revision tagged
             `branch == "main"` so v0.6.x logs with no Branch records still
             report a head.
          3. None if neither applies.
        """
        b = self._branches.get(branch_name)
        if b is not None:
            return b.head_revision_id
        if branch_name == DEFAULT_BRANCH:
            for r in reversed(self._revisions):
                if r.branch == DEFAULT_BRANCH:
                    return r.revision_id
        return None

    # ── branch operations ──────────────────────────────────────────────────

    def list_branches(self) -> Tuple[Branch, ...]:
        """Return all known branches. The default branch is always present
        so callers never see an empty list on a log with at least one
        revision on main."""
        # Ensure "main" is represented even when no explicit Branch record
        # was written (e.g. logs produced by v0.6.x).
        names: List[str] = list(self._branches.keys())
        if DEFAULT_BRANCH not in names:
            head = self._head_id_for(DEFAULT_BRANCH)
            main = Branch(
                name=DEFAULT_BRANCH,
                head_revision_id=head,
                created_at=0,
                created_by="",
            )
            return (main,) + tuple(
                self._branches[n] for n in sorted(names) if n != DEFAULT_BRANCH
            )
        return tuple(self._branches[n] for n in sorted(self._branches.keys()))

    def create_branch(
        self,
        name: str,
        from_revision_id: Optional[str] = None,
        created_by: str = "",
        created_at: Optional[int] = None,
    ) -> Branch:
        """Create a new branch pointing at `from_revision_id`.

        `from_revision_id` defaults to the current head of the active
        branch. Passing `None` with an empty log yields a genesis branch
        whose first append seeds the branch from scratch.

        Raises:
            RevisionLogError: if `name` already exists, is empty, or
              `from_revision_id` does not match any known revision.
        """
        if not isinstance(name, str) or not name:
            raise RevisionLogError(f"branch name must be a non-empty string, got {name!r}")
        if name in self._branches:
            raise RevisionLogError(f"branch {name!r} already exists")
        # Resolve the "from" revision. None -> current head of active branch.
        if from_revision_id is None:
            from_revision_id = self._head_id_for(self._active_branch)
        elif from_revision_id not in self._revisions_by_id:
            raise RevisionLogError(
                f"from_revision_id {from_revision_id!r} is not a known revision"
            )
        import time as _time
        branch = Branch(
            name=name,
            head_revision_id=from_revision_id,
            created_at=created_at if created_at is not None else int(_time.time()),
            created_by=created_by,
        )
        self._branches[name] = branch
        if self.path is not None:
            self._persist_record(branch.to_dict())
        return branch

    def checkout_branch(self, name: str) -> Branch:
        """Activate `name` as the branch that subsequent `append` calls
        populate. Persists a checkout record for the audit trail.

        Auto-promotes the default branch: `checkout_branch("main")` works
        on a log that has no explicit Branch record because the default
        branch is always implicitly present (so callers can switch off a
        feature branch back to main without a prior create_branch call).
        """
        if not isinstance(name, str) or not name:
            raise RevisionLogError(f"branch name must be a non-empty string, got {name!r}")
        if name not in self._branches:
            if name == DEFAULT_BRANCH:
                # Materialise a concrete Branch record for main so future
                # checkout/persistence has a stable handle.
                head = self._head_id_for(DEFAULT_BRANCH)
                import time as _time
                branch = Branch(
                    name=DEFAULT_BRANCH,
                    head_revision_id=head,
                    created_at=int(_time.time()),
                    created_by="",
                )
                self._branches[DEFAULT_BRANCH] = branch
                if self.path is not None:
                    self._persist_record(branch.to_dict())
            else:
                raise RevisionLogError(f"unknown branch {name!r}")
        self._active_branch = name
        if self.path is not None:
            self._persist_record({
                "_record_type": "checkout",
                "name": name,
            })
        return self._branches[name]

    def branch_ancestor(
        self, src: str, dst: str
    ) -> Optional[str]:
        """Return the revision_id of the lowest common ancestor of two
        branches' heads, or None if no ancestor exists.

        Walks predecessors from each head; runs in O(n) over the visited
        history. Used internally by `merge_branch` and exposed so callers
        (e.g. UIs) can render a diff even when a merge is not happening.
        """
        src_head = self._head_id_for(src)
        dst_head = self._head_id_for(dst)
        return self._lca(src_head, dst_head)

    def _parents_of(self, rev_id: Optional[str]) -> Tuple[str, ...]:
        """Return every parent revision_id of `rev_id`.

        Linear revisions have exactly one parent (``predecessor_revision_id``)
        or zero (genesis). Three-way merge commits (v0.8.0) carry BOTH
        ``predecessor_revision_id`` (the dst-side parent) and
        ``merge_parent_ids = (dst_parent, src_parent)``; chain walks must
        follow both edges so ancestry checks handle DAGs correctly.
        """
        if rev_id is None:
            return ()
        rev = self._revisions_by_id.get(rev_id)
        if rev is None:
            return ()
        if rev.merge_parent_ids is not None:
            # Merge commit: two parents. Keep deterministic ordering
            # (dst first, src second) to match how we build them.
            return tuple(rev.merge_parent_ids)
        if rev.predecessor_revision_id is None:
            return ()
        return (rev.predecessor_revision_id,)

    def _ancestors_of(self, rev_id: Optional[str]) -> set:
        """BFS over the parent DAG, collecting every ancestor (inclusive).

        Handles merge commits by following both parent links. Cycles are
        impossible in a content-addressed append-only store but the visited
        set makes the walk robust against corrupt data.
        """
        if rev_id is None:
            return set()
        seen: set = set()
        frontier: List[str] = [rev_id]
        while frontier:
            cur = frontier.pop()
            if cur in seen:
                continue
            seen.add(cur)
            for p in self._parents_of(cur):
                if p not in seen:
                    frontier.append(p)
        return seen

    def _lca(
        self, a_id: Optional[str], b_id: Optional[str]
    ) -> Optional[str]:
        """Lowest common ancestor of two revision ids across the parent DAG.

        The DAG may contain merge commits with two parents; we walk the
        full set of ancestors for `a_id`, then BFS from `b_id` and return
        the FIRST match, which is the nearest (lowest) ancestor in a
        breadth-first ordering. This matches git's ``merge-base`` semantics
        for the common linear-history case and remains correct when one or
        both branches already contain prior merge commits.
        """
        if a_id is None or b_id is None:
            return None
        a_ancestors = self._ancestors_of(a_id)
        if not a_ancestors:
            return None
        # BFS from b_id; the first ancestor we hit that's also in a_ancestors
        # is the lowest common ancestor.
        seen: set = set()
        frontier: List[str] = [b_id]
        while frontier:
            next_frontier: List[str] = []
            for cur in frontier:
                if cur in seen:
                    continue
                seen.add(cur)
                if cur in a_ancestors:
                    return cur
                for p in self._parents_of(cur):
                    if p not in seen:
                        next_frontier.append(p)
            frontier = next_frontier
        return None

    def _is_ancestor(self, ancestor_id: str, descendant_id: Optional[str]) -> bool:
        """True iff `ancestor_id` appears on the parent DAG walking from
        `descendant_id` (inclusive). Follows both edges of merge commits so
        three-way merge ancestry works."""
        return ancestor_id in self._ancestors_of(descendant_id)

    def merge_branch(
        self,
        src: str,
        dst: str,
        reviewer: str,
    ) -> "Branch | BranchMergeConflict":
        """Merge `src` into `dst`, preferring the cheapest strategy.

        Strategy ladder (v0.8.0):
          1. **Fast-forward** — `dst` is an ancestor of `src`. The dst
             branch's head simply advances to `src_head`; no new revision
             is fabricated. This path is unchanged from v0.7.0 so existing
             callers keep their byte-level audit trails.
          2. **Three-way merge** — `src` and `dst` diverged but their
             deltas vs the common ancestor touch disjoint invariant classes
             (no class appears in both sides' added/removed sets). The log
             builds a NEW merge-commit revision on `dst` whose invariants
             are the ancestor's plus src_added, minus src_removed, plus
             dst_added, minus dst_removed (dst already has its side
             applied; we just layer src on top). The commit carries
             ``merge_parent_ids=(dst_head, src_head)`` so downstream
             auditors can walk both histories.
          3. **Conflict** — any class appears in both sides' deltas.
             Returns a ``BranchMergeConflict`` with a populated
             ``conflicting_invariants`` list enumerating the offending
             classes. The dst head is NOT moved; the caller must reconcile.

        `reviewer` is recorded on the merge event for the audit trail.
        Empty reviewer strings are allowed but discouraged; tooling can
        enforce non-empty reviewers at the call site.
        """
        if src not in self._branches or dst not in self._branches:
            # Auto-materialise "main" if a caller merges to it without a
            # prior explicit create_branch (common case: "merge feature
            # into main" from an otherwise v0.6.x-style log).
            if src == DEFAULT_BRANCH and src not in self._branches:
                self.checkout_branch(DEFAULT_BRANCH)
            if dst == DEFAULT_BRANCH and dst not in self._branches:
                self.checkout_branch(DEFAULT_BRANCH)
            missing = [b for b in (src, dst) if b not in self._branches]
            if missing:
                raise RevisionLogError(f"unknown branch(es): {missing!r}")
        if src == dst:
            raise RevisionLogError("merge_branch: src and dst must differ")
        src_head = self._branches[src].head_revision_id
        dst_head = self._branches[dst].head_revision_id
        # Edge cases: src empty -> nothing to merge; dst empty -> trivially FF.
        if src_head is None:
            raise RevisionLogError(
                f"cannot merge empty branch {src!r} into {dst!r}"
            )
        if dst_head is None:
            # dst has no history yet; FF to src_head.
            new_branch = self._branches[dst].with_head(src_head)
            self._branches[dst] = new_branch
            if self.path is not None:
                self._persist_record({
                    "_record_type": "merge",
                    "merge_kind": "fast-forward",
                    "src": src, "dst": dst,
                    "reviewer": reviewer,
                    "new_head_revision_id": src_head,
                })
            return new_branch
        if src_head == dst_head:
            # Already up to date; return unchanged branch.
            return self._branches[dst]
        # Fast-forward if dst_head is an ancestor of src_head.
        if self._is_ancestor(dst_head, src_head):
            new_branch = self._branches[dst].with_head(src_head)
            self._branches[dst] = new_branch
            if self.path is not None:
                self._persist_record({
                    "_record_type": "merge",
                    "merge_kind": "fast-forward",
                    "src": src, "dst": dst,
                    "reviewer": reviewer,
                    "new_head_revision_id": src_head,
                })
            return new_branch
        # Non-FF: attempt a three-way merge.
        ancestor = self._lca(src_head, dst_head)
        src_delta = self._delta_vs(ancestor, src_head)
        dst_delta = self._delta_vs(ancestor, dst_head)
        conflicting = _find_conflicting_invariants(src_delta, dst_delta)
        if conflicting:
            # Overlapping -> hard conflict; dst head unchanged.
            # v0.14.0: enrich the payload with the semantic classification
            # so operator-facing tooling shows why the merge failed, not
            # just which classes overlapped.
            classified = _classify_for_conflict(
                src_delta=src_delta,
                dst_delta=dst_delta,
                ancestor_id=ancestor,
                src=src, dst=dst,
            )
            return BranchMergeConflict(
                src=src, dst=dst,
                src_head=src_head, dst_head=dst_head,
                common_ancestor=ancestor,
                src_delta=src_delta,
                dst_delta=dst_delta,
                conflicting_invariants=conflicting,
                classified_conflicts=classified,
            )
        # Disjoint -> auto 3-way merge.
        merged_revision = self._build_three_way_merge_revision(
            src=src, dst=dst,
            src_head=src_head, dst_head=dst_head,
            ancestor_id=ancestor,
            src_delta=src_delta,
            reviewer=reviewer,
        )
        # v0.14.0 cross-revision check: the merge commit's transition is
        # (dst_head -> merged_revision) on the dst branch. Refusing here
        # keeps the dst head pointing at its pre-merge state so operators
        # can reconcile without a rollback.
        if self.cross_revision_validator is not None:
            dst_head_rev = self._revisions_by_id.get(dst_head)
            result = self.cross_revision_validator.validate(
                dst_head_rev, merged_revision, dst,
            )
            if not result.valid:
                raise CrossRevisionRejected(
                    f"cross-revision validator rejected three-way merge "
                    f"into {dst!r}: {len(result.violations)} violation(s)",
                    result=result,
                )
        self._revisions.append(merged_revision)
        self._revisions_by_id[merged_revision.revision_id] = merged_revision
        # Advance dst's head pointer.
        new_branch = self._branches[dst].with_head(merged_revision.revision_id)
        self._branches[dst] = new_branch
        # Persist the merge commit AND the merge event. The revision row
        # is a normal untagged record so v0.7.0 readers see an extra linear
        # revision on dst; the merge record carries the parent tuple so
        # v0.8.0 readers can reconstruct the DAG exactly.
        if self.path is not None:
            self._persist_one(merged_revision)
            self._persist_record({
                "_record_type": "merge",
                "merge_kind": "three-way",
                "src": src, "dst": dst,
                "reviewer": reviewer,
                "new_head_revision_id": merged_revision.revision_id,
                "merged_revision_id": merged_revision.revision_id,
                "merge_parent_ids": list(merged_revision.merge_parent_ids or ()),
            })
        return new_branch

    def _build_three_way_merge_revision(
        self,
        *,
        src: str,
        dst: str,
        src_head: str,
        dst_head: str,
        ancestor_id: Optional[str],
        src_delta: Dict[str, Any],
        reviewer: str,
    ) -> PolicyRevision:
        """Fabricate the merge-commit revision for a three-way merge.

        Semantics: the merged invariant set = dst_head's invariants + whatever
        src added that's not already in dst - whatever src removed that's still
        in dst. Because we've already validated the deltas are disjoint at the
        class level, this apply-order is commutative in practice.
        """
        import time as _time

        dst_rev = self._revisions_by_id.get(dst_head)
        if dst_rev is None:
            # Shouldn't happen — dst_head came from our own branch pointer —
            # but fail loudly rather than silently synthesise nothing.
            raise RevisionLogError(
                f"three-way merge: dst_head {dst_head!r} not found in log"
            )
        # Start from dst's invariant set (keyed by (class, repr)).
        merged_map: Dict[Tuple[str, str], Invariant] = {
            (type(i).__name__, repr(i)): i for i in dst_rev.invariants
        }
        for ser in src_delta.get("added", []):
            inv = _rehydrate_invariant(ser)
            merged_map[(type(inv).__name__, repr(inv))] = inv
        for ser in src_delta.get("removed", []):
            # Key the removed entry the same way we stored it.
            merged_map.pop((ser["class_name"], repr(_rehydrate_invariant(ser))), None)
        merged_invariants = tuple(merged_map.values())
        # Revision id: content-addressed via a compact "merge:<dst>:<src>"
        # shape so merge commits are visibly distinguishable from the
        # "<config_hash>:<nonce>" shape used by admit-time revisions.
        now = int(_time.time())
        revision_id = f"merge:{dst_head}+{src_head}"
        # Delta for the merge revision: what it added/removed relative to
        # its predecessor (dst_head). By construction that's exactly
        # src_delta — dst is unchanged beyond layering src's changes.
        delta = {
            "added": list(src_delta.get("added", [])),
            "removed": list(src_delta.get("removed", [])),
        }
        depth = dst_rev.revision_depth + 1
        return PolicyRevision(
            revision_id=revision_id,
            invariants=merged_invariants,
            proof_backend="three-way-merge",
            proof_strength="inherited",
            prover_mode=dst_rev.prover_mode,
            compile_hash=None,
            fragment_version=dst_rev.fragment_version,
            tau_backend_version=dst_rev.tau_backend_version,
            admitted_at_unix=now,
            predecessor_revision_id=dst_head,
            delta=delta,
            revision_depth=depth,
            branch=dst,
            merge_parent_ids=(dst_head, src_head),
        )

    def _delta_vs(
        self,
        base_id: Optional[str],
        head_id: Optional[str],
    ) -> Dict[str, Any]:
        """Structured {added, removed} from base to head.

        Uses the same shape as PolicyRevision.delta so consumers can reuse
        existing rendering code. `None` base -> everything at head is
        "added"; `None` head -> everything at base is "removed".
        """
        base_rev = self._revisions_by_id.get(base_id) if base_id else None
        head_rev = self._revisions_by_id.get(head_id) if head_id else None
        base_invs = base_rev.invariants if base_rev is not None else ()
        head_invs = head_rev.invariants if head_rev is not None else ()
        base_set = {(type(i).__name__, repr(i)): i for i in base_invs}
        head_set = {(type(i).__name__, repr(i)): i for i in head_invs}
        added = [head_set[k] for k in head_set.keys() - base_set.keys()]
        removed = [base_set[k] for k in base_set.keys() - head_set.keys()]
        return {
            "added": [_serialize_invariant(i) for i in added],
            "removed": [_serialize_invariant(i) for i in removed],
        }

    # ── mutation ───────────────────────────────────────────────────────────

    def append(self, revision: PolicyRevision) -> None:
        """Append a revision and, if a `path` is configured, persist it.

        The revision lands on the branch named in `revision.branch` (default
        "main"). The branch's head pointer advances to the new revision.

        v0.14.0: when a ``cross_revision_validator`` is configured, we run
        ``validator.validate(predecessor_on_target_branch, revision, branch)``
        BEFORE any state mutates. A violation raises
        :class:`CrossRevisionRejected` (a subclass of :class:`RevisionLogError`)
        carrying the structured report, and the log stays untouched — so
        the daemon's registry and audit trail cannot diverge from the
        rejected revision.
        """
        branch_name = revision.branch or DEFAULT_BRANCH
        if self.cross_revision_validator is not None:
            predecessor = self.head_of(branch_name)
            result = self.cross_revision_validator.validate(
                predecessor, revision, branch_name,
            )
            if not result.valid:
                raise CrossRevisionRejected(
                    f"cross-revision validator rejected append on branch "
                    f"{branch_name!r}: {len(result.violations)} violation(s)",
                    result=result,
                )
        self._revisions.append(revision)
        self._revisions_by_id[revision.revision_id] = revision
        # Ensure the target branch exists so its head can advance.
        if branch_name not in self._branches:
            import time as _time
            # Materialise the branch lazily. For "main" this matches
            # v0.6.x-style logs where no explicit Branch record exists.
            self._branches[branch_name] = Branch(
                name=branch_name,
                head_revision_id=None,
                created_at=int(_time.time()),
                created_by="",
            )
        self._branches[branch_name] = self._branches[branch_name].with_head(
            revision.revision_id
        )
        if self.path is not None:
            self._persist_one(revision)

    # ── persistence ────────────────────────────────────────────────────────

    def _persist_one(self, revision: PolicyRevision) -> None:
        assert self.path is not None
        self.path.parent.mkdir(parents=True, exist_ok=True)
        line = json.dumps(revision.to_dict(), sort_keys=True) + "\n"
        with self.path.open("a", encoding="utf-8") as f:
            f.write(line)

    def _persist_record(self, record: Dict[str, Any]) -> None:
        """Append a non-revision record (branch/checkout/merge) to the log.
        Keeps branching events in-line with revisions so auditors have a
        single source of truth.
        """
        assert self.path is not None
        self.path.parent.mkdir(parents=True, exist_ok=True)
        line = json.dumps(record, sort_keys=True) + "\n"
        with self.path.open("a", encoding="utf-8") as f:
            f.write(line)

    def persist_all(self, path: Optional[Path] = None) -> None:
        """Write the full chain to disk. Useful for snapshotting; append() is
        the normal persistence path.

        Branch records are emitted after revisions so `load()` can rebuild
        head pointers from the final state."""
        target = path or self.path
        if target is None:
            raise RevisionLogError("persist_all() called with no path configured")
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("w", encoding="utf-8") as f:
            for r in self._revisions:
                f.write(json.dumps(r.to_dict(), sort_keys=True) + "\n")
            for b in self._branches.values():
                f.write(json.dumps(b.to_dict(), sort_keys=True) + "\n")
            if self._active_branch != DEFAULT_BRANCH:
                f.write(json.dumps(
                    {"_record_type": "checkout", "name": self._active_branch},
                    sort_keys=True,
                ) + "\n")

    @classmethod
    def load(cls, path: Path) -> "RevisionLog":
        """Rebuild a RevisionLog from a JSON-lines file.

        Missing file -> empty log bound to that path (future appends create
        the file). Malformed lines raise RevisionLogError; we never silently
        drop audit records.

        The jsonl may mix revision records (untagged, as in v0.6.x) and
        branching records (`_record_type` discriminator). Branch records
        replayed in order reconstruct the branch DAG; the last checkout
        record wins for `_active_branch`.
        """
        log = cls(path=path)
        if not path.exists():
            return log
        with path.open("r", encoding="utf-8") as f:
            for lineno, raw in enumerate(f, start=1):
                raw = raw.strip()
                if not raw:
                    continue
                try:
                    d = json.loads(raw)
                except json.JSONDecodeError as exc:
                    raise RevisionLogError(
                        f"{path}:{lineno}: malformed JSON line: {exc}"
                    ) from exc
                record_type = d.get("_record_type")
                if record_type is None:
                    # Revision record (v0.6.x compatible).
                    rev = PolicyRevision.from_dict(d)
                    log._revisions.append(rev)
                    log._revisions_by_id[rev.revision_id] = rev
                    # Advance the branch head on replay so appended
                    # revisions without explicit Branch records keep main
                    # pointing at the last admit.
                    branch_name = rev.branch or DEFAULT_BRANCH
                    existing = log._branches.get(branch_name)
                    if existing is None:
                        log._branches[branch_name] = Branch(
                            name=branch_name,
                            head_revision_id=rev.revision_id,
                            created_at=0,
                            created_by="",
                        )
                    else:
                        log._branches[branch_name] = existing.with_head(rev.revision_id)
                elif record_type == "branch":
                    b = Branch.from_dict(d)
                    log._branches[b.name] = b
                elif record_type == "checkout":
                    name = d.get("name")
                    if isinstance(name, str) and name:
                        log._active_branch = name
                elif record_type == "merge":
                    # Merge events advance the dst branch's head. We trust
                    # the recorded head so replay can reconstruct without
                    # re-running the ancestry check.
                    dst = d.get("dst")
                    new_head = d.get("new_head_revision_id")
                    if (
                        isinstance(dst, str)
                        and dst in log._branches
                        and isinstance(new_head, str)
                    ):
                        log._branches[dst] = log._branches[dst].with_head(new_head)
                else:
                    raise RevisionLogError(
                        f"{path}:{lineno}: unknown _record_type {record_type!r}"
                    )
        return log
