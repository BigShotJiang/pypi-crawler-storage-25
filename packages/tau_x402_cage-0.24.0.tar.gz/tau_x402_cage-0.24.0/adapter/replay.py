"""Policy replay / backtest (v0.10.0).

Operators ask: "if I change this policy, what payments from last month would
have been rejected instead of permitted?" Today the only way to know is to
redeploy the candidate policy and wait for new traffic. Replay re-admits
recent payments against a candidate policy in-memory and surfaces the diff
against the current policy's verdict.

Use cases (see docs/replay.md):

* **Backtest before merge** — before declaring a stricter rule, simulate it
  against the last N hours of permits so you know how many legitimate
  payments it would have rejected.
* **Post-incident forensics** — after a bad payment slipped through, test
  candidate invariants until one catches it without collateral damage.
* **Onboarding** — a new team inheriting the cage can point replay at
  historical traffic and understand what each rule contributes.

Design choices:

* **Pure.** Replay never mutates the daemon's registry or revision log. It
  operates on an ephemeral ``X402Registry`` built from the candidate
  invariants against a frozen history snapshot. Callers pass their own
  history list in; the daemon op layer does the snapshot read.
* **No prover consultation.** Per-payment verdicts use the same pure-Python
  ``X402Registry.check_payment`` as the hot path. Declare-time consistency
  for the candidate is a *separate* concern (use ``explain_policy``). The
  goal here is "what verdict would each historical intent have received",
  not "is the candidate policy self-consistent".
* **Fail-visible on exceptions.** If a candidate invariant's ``check_payment``
  raises (e.g. an unsupported fragment edge case at replay time), we record
  the entry as ``prover_inconclusive`` rather than silently defaulting to
  permit. Silent admits on errors is exactly the class of bug this whole
  project exists to prevent.
* **Cost guard.** Replay is O(history × invariants). The daemon op layer
  caps ``max_entries`` at 10_000 by default so an operator cannot wedge
  the daemon by replaying an unbounded history window.

Semantics of the "before" verdict:

  The history snapshot is taken against the *current* registry at the time
  the replay is requested. "Before" is reconstructed by running the current
  registry against each historical intent, in insertion order, using only
  the intents *preceding* the one under evaluation as accumulated history.
  This matches how the real hot path admits payments (RollingWindowCap /
  SpendingCap(per_window) look backwards at permits-so-far), and guarantees
  ``candidate == current`` yields ``unchanged == total`` — the regression
  guard the test battery exercises.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Iterable, Optional, Sequence

from adapter.invariants import Invariant, Violation
from adapter.payment_intent_matcher import PaymentIntent
from adapter.x402_registry import X402Registry


# Hard ceiling the daemon op layer enforces. Exposed as a module-level
# constant so both the op handler and the CLI render-path can reference a
# single source of truth when validating ``max_entries``.
DEFAULT_MAX_ENTRIES: int = 10_000


@dataclass(frozen=True)
class ReplayChange:
    """One historical intent whose verdict FLIPPED between current and candidate.

    Fields:
        intent:          Compact summary of the historical PaymentIntent
                         (amount, currency, provider, counterparty, rail,
                         timestamp_unix). Matches the shape emitted by
                         ``daemon.server._intent_summary`` so the web UI and
                         CLI can render it without a second lookup.
        before_verdict:  Verdict under the current registry.
        after_verdict:   Verdict under the candidate registry.
        reason:          The candidate's violation ``reason_text`` when
                         ``after_verdict == "reject"``; ``None`` when the
                         candidate permits (i.e. a new_permit).
        rule_id:         The candidate's rule_id on reject, or ``None``.
    """

    intent: dict[str, Any]
    before_verdict: str
    after_verdict: str
    reason: Optional[str] = None
    rule_id: Optional[str] = None

    def to_wire(self) -> dict[str, Any]:
        """JSON-safe dict for daemon-op responses."""
        return {
            "intent": dict(self.intent),
            "before_verdict": self.before_verdict,
            "after_verdict": self.after_verdict,
            "reason": self.reason,
            "rule_id": self.rule_id,
        }


@dataclass(frozen=True)
class ReplayResult:
    """Outcome of replaying a history window against a candidate registry.

    Counters:
        total:                 Number of historical intents considered.
        unchanged:             Verdicts identical under current + candidate.
        new_rejects:           Entries that were permitted by current and
                               rejected by candidate. Subset of ``changed``.
        new_permits:           Entries that were rejected by current and
                               permitted by candidate. Subset of ``changed``.
        prover_inconclusive:   Entries where candidate evaluation raised an
                               exception (e.g. unsupported fragment at replay
                               time). Counted separately so a candidate with
                               broken rules does not silently look like a
                               permit-all policy.

    ``changed`` carries the full per-entry diff; ``new_rejects`` and
    ``new_permits`` are conveniences derived from it for fast summary
    rendering.
    """

    total: int
    unchanged: int
    changed: tuple[ReplayChange, ...] = field(default_factory=tuple)
    new_rejects: int = 0
    new_permits: int = 0
    prover_inconclusive: int = 0

    def to_wire(self) -> dict[str, Any]:
        """JSON-safe dict for daemon-op responses."""
        return {
            "total": self.total,
            "unchanged": self.unchanged,
            "new_rejects": self.new_rejects,
            "new_permits": self.new_permits,
            "prover_inconclusive": self.prover_inconclusive,
            "changed": [c.to_wire() for c in self.changed],
        }


def _intent_summary(intent: PaymentIntent) -> dict[str, Any]:
    """Same shape as daemon.server._intent_summary.

    Re-implemented here to avoid a reverse dependency from ``adapter`` back
    into ``daemon`` (adapter is the inner module). Keep the two in sync: any
    field added to the daemon's summary should land here too.
    """
    return {
        "amount": str(intent.amount),
        "currency": intent.currency,
        "provider": intent.provider,
        "counterparty": intent.counterparty,
        "rail": intent.rail,
        "timestamp_unix": intent.timestamp_unix,
    }


def _evaluate(
    registry: X402Registry,
    intent: PaymentIntent,
    history: Sequence[PaymentIntent],
    rejects: Sequence[PaymentIntent],
) -> tuple[str, Optional[Violation], bool]:
    """Run one intent through a registry and return (verdict, violation, inconclusive).

    * ``verdict`` is ``"permit"`` | ``"reject"`` | ``"inconclusive"``.
    * ``violation`` is the first-firing ``Violation`` on reject, else ``None``.
    * ``inconclusive`` is ``True`` when an invariant raised during evaluation.

    Fail-visible on exceptions: a raising invariant marks the whole intent
    as inconclusive rather than defaulting to permit. The alternative —
    catching and ignoring — would make a buggy candidate silently look
    like a permit-all policy, which is exactly the class of bug this
    project exists to prevent.
    """
    try:
        violation = registry.check_payment(intent, history, rejects)
    except Exception:  # noqa: BLE001 — fail-visible on any invariant raising
        return "inconclusive", None, True
    if violation is None:
        return "permit", None, False
    return "reject", violation, False


def replay_against_candidate(
    history: Iterable[PaymentIntent],
    current_invariants: Sequence[Invariant],
    candidate_invariants: Sequence[Invariant],
) -> ReplayResult:
    """Re-admit ``history`` against ``candidate_invariants`` and diff vs ``current``.

    Args:
        history:               Historical PaymentIntents in OLDEST-first
                               insertion order. Caller is responsible for
                               snapshotting (so replay sees a frozen view).
        current_invariants:    The cage's currently-active invariant set. Used
                               to reconstruct the "before" verdict for each
                               historical intent.
        candidate_invariants:  The candidate invariant set under evaluation.

    Returns:
        A :class:`ReplayResult` with per-entry diffs.

    Behaviour for empty ``history``: returns a zeroed ``ReplayResult``. When
    ``candidate_invariants == current_invariants`` every entry lands in
    ``unchanged`` (regression guard exercised by ``tests/test_replay.py``).

    Ordering + accumulation semantics:

        For entry ``i`` we evaluate both registries against the slice
        ``history[:i]``. The daemon's hot path treats a permit as appending
        to permit-history and a reject as appending to reject-history; we
        model that by accumulating permits + rejects *under the current
        registry*. The candidate sees the SAME accumulated history — we do
        NOT let the candidate's what-if rejects pollute the history sent to
        subsequent entries. This keeps the replay deterministic and stops
        the candidate from "seeing" a modified past, which would conflate
        "what would have happened" with "what would have happened with
        perfect hindsight".
    """
    history_tuple: tuple[PaymentIntent, ...] = tuple(history)
    current = X402Registry.empty()
    for inv in current_invariants:
        current = current.declare(inv)
    candidate = X402Registry.empty()
    for inv in candidate_invariants:
        candidate = candidate.declare(inv)

    total = len(history_tuple)
    unchanged = 0
    new_rejects = 0
    new_permits = 0
    inconclusive = 0
    changed: list[ReplayChange] = []

    # Accumulated permit + reject history as observed by the CURRENT
    # registry. We replay the historical stream chronologically so rolling-
    # window invariants see the same growing context they would at runtime.
    accumulated_permits: list[PaymentIntent] = []
    accumulated_rejects: list[PaymentIntent] = []

    for intent in history_tuple:
        before_verdict, _before_violation, _ = _evaluate(
            current,
            intent,
            accumulated_permits,
            accumulated_rejects,
        )
        after_verdict, after_violation, after_inconclusive = _evaluate(
            candidate,
            intent,
            accumulated_permits,
            accumulated_rejects,
        )

        if after_inconclusive:
            inconclusive += 1
            # Inconclusive is a distinct outcome; don't count it as
            # unchanged even if before was also inconclusive. It lands in
            # `changed` with after_verdict="inconclusive" so operators see
            # which intents the candidate couldn't decide.
            if before_verdict != "inconclusive":
                changed.append(
                    ReplayChange(
                        intent=_intent_summary(intent),
                        before_verdict=before_verdict,
                        after_verdict="inconclusive",
                        reason=(
                            "candidate invariant raised during check_payment; "
                            "recorded as inconclusive rather than silently admitted"
                        ),
                        rule_id=None,
                    )
                )
        elif before_verdict == after_verdict:
            unchanged += 1
        else:
            if before_verdict == "permit" and after_verdict == "reject":
                new_rejects += 1
            elif before_verdict == "reject" and after_verdict == "permit":
                new_permits += 1
            changed.append(
                ReplayChange(
                    intent=_intent_summary(intent),
                    before_verdict=before_verdict,
                    after_verdict=after_verdict,
                    reason=(after_violation.reason_text if after_violation else None),
                    rule_id=(after_violation.rule_id if after_violation else None),
                )
            )

        # Advance the accumulator using the CURRENT registry's verdict. This
        # preserves the real history the cage observed; it's what the
        # candidate is being asked to re-judge, not what it would have
        # observed in a counterfactual universe.
        if before_verdict == "permit":
            accumulated_permits.append(intent)
        elif before_verdict == "reject":
            accumulated_rejects.append(intent)
        # before_verdict == "inconclusive" is impossible unless the CURRENT
        # registry itself raises; in that degenerate case we don't advance
        # either accumulator (it wasn't actually admitted).

    return ReplayResult(
        total=total,
        unchanged=unchanged,
        changed=tuple(changed),
        new_rejects=new_rejects,
        new_permits=new_permits,
        prover_inconclusive=inconclusive,
    )
