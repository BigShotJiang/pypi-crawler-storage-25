"""Signed decision bundles (v0.15.0).

A *decision bundle* packages everything an offline auditor needs to verify
"the whole story" behind a single verdict: the signed envelope itself, the
exact policy snapshot that issued it, the revision chain leading up to that
snapshot, and the proof artifacts (backend / strength / mode / compile_hash
plus optional witness) that admitted the policy.

The goal is a self-contained, tamper-evident artefact: hand an auditor one
JSONL file + a public key (or HMAC secret) and they can verify the verdict
without calling the daemon, without trusting our infrastructure, and
without round-tripping to any registry.

Wire format (v1, frozen)
------------------------

A bundle serialises to a JSONL file (one JSON object per line). Each record
carries an ``_record`` discriminator so the reader never has to guess at
shape:

  Line 1 — ``{"_record": "bundle_header", ...}``
    Bundle-level metadata: ``bundle_version``, ``bundle_id``,
    ``created_at_unix``, ``cage_version``, ``intent_hash``.
  Line 2 — ``{"_record": "envelope", ...}``
    The full :class:`SignedEnvelope` dict via ``to_json`` / ``from_json``.
  Line 3 — ``{"_record": "proof_artifacts", ...}``
    ``proof_backend``, ``proof_strength``, ``prover_mode``, ``compile_hash``
    (recomputed over ``policy_snapshot`` — see below), optional ``witness``.
  Lines 4..N — ``{"_record": "policy_snapshot_item", "index": i, ...}``
    One serialized invariant per line (``{class_name, repr}`` shape, same
    as ``policy_revision._serialize_invariant``). Index preserves order.
  Lines N+1..M — ``{"_record": "revision_chain_item", "index": i, ...}``
    One ``PolicyRevision.to_dict()`` per line, oldest-first. When the
    ``truncated`` header flag is True, the oldest revisions were dropped
    to fit ``chain_limit``.

Determinism guarantees
----------------------
* Every line is serialised via ``json.dumps(..., sort_keys=True,
  separators=(",", ":"))`` so byte-identical inputs produce byte-identical
  bundles.
* ``policy_snapshot`` is sorted by (class_name, canonical repr dict) before
  the compile_hash is computed, so the hash is invariant under set-level
  reordering. Per-line serialisation preserves that order too.
* ``created_at_unix`` is caller-parameterised so tests can compare two
  bundles for byte-equality.

Verifier contract (``verify_decision_bundle``)
----------------------------------------------
The verifier checks, in order:

1. **Envelope signature** — delegated to
   :func:`adapter.verdict_signer.verify`. Skipped ``now_unix`` (bundles are
   offline; TTL is not enforced at bundle time — callers who care about
   TTL can re-verify with a real clock).
2. **Revision binding** — ``envelope.policy_revision_id`` must match the
   head of ``revision_chain`` (the most-recent / last item). When both
   sides are None, the envelope is a legacy v1 shape with no provenance
   and the check is skipped.
3. **Policy-hash binding** — recompute ``compile_hash`` over
   ``policy_snapshot`` and compare byte-for-byte with the value stored in
   ``proof_artifacts``. Mismatch ⇒ the snapshot has been tampered with.

``VerifyResult`` carries structured per-check booleans so callers can tell
which layer failed, not just that "something broke".

Scope boundaries
----------------
* We do NOT re-run the prover. Bundles are about integrity + provenance,
  not soundness. The ``proof_artifacts`` field records which backend
  admitted the policy; an auditor who wants to re-run must fetch the
  compiled source separately.
* We do NOT enforce TTL in the verifier. A 30-second verdict is "expired"
  in the wire sense but an auditor reviewing an incident six months later
  still wants to verify its signature. Callers who want TTL enforcement
  can pass ``now_unix`` to the underlying ``verdict_signer.verify`` via
  the ``SignedEnvelope`` directly.
* Unlike ``audit_export.py`` (which signs a full log-level export), a
  decision bundle is the per-decision view. Both are stable surfaces;
  neither is derived from the other.

Format stability commitment: ``bundle_version="1"`` is FROZEN. Any
breaking wire change bumps to ``"2"`` and leaves v1 readers able to parse
every v1 bundle ever written. Additive fields are allowed inside existing
records as long as older readers ignore unknown keys.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

from adapter.policy_revision import (
    PolicyRevision,
    _rehydrate_invariant,
    _serialize_invariant,
)
from adapter.verdict_signer import (
    ALG_ED25519,
    ALG_HMAC_SHA256,
    SignatureError,
    SignedEnvelope,
    _canonical_mac_input,
)


#: Frozen bundle schema version. Once this lands on disk, v1 readers MUST
#: be able to parse every future v1 bundle. Breaking changes bump to "2".
BUNDLE_VERSION_V1 = "1"

#: Record-type discriminators for the JSONL wire format.
_RECORD_HEADER = "bundle_header"
_RECORD_ENVELOPE = "envelope"
_RECORD_ARTIFACTS = "proof_artifacts"
_RECORD_SNAPSHOT_ITEM = "policy_snapshot_item"
_RECORD_CHAIN_ITEM = "revision_chain_item"


class DecisionBundleError(ValueError):
    """Raised on malformed bundle input, serialisation, or parse failure.

    Distinct from :class:`SignatureError` — a ``DecisionBundleError`` means
    "the bundle itself is structurally broken"; a ``SignatureError`` means
    "the bundle parsed fine but a cryptographic check failed".
    """


def _canonical_dumps(obj: Dict[str, Any]) -> str:
    """Single source of truth for bundle line serialisation.

    ``sort_keys`` + compact separators makes the output byte-stable across
    Python versions, platforms, and call sites. Same in serialise and in
    hash so the compile_hash over the snapshot is reproducible.
    """
    return json.dumps(obj, sort_keys=True, separators=(",", ":"))


# ── policy-snapshot hashing ──────────────────────────────────────────────────


def compute_policy_snapshot_hash(snapshot: Sequence[Dict[str, Any]]) -> str:
    """SHA-256 over the canonical serialisation of ``snapshot``.

    The snapshot is sorted by (class_name, canonical repr) so set-level
    reordering does not change the hash. This is what lets
    ``verify_decision_bundle`` prove the snapshot hasn't been tampered
    with: any added, removed, or modified invariant perturbs the hash.

    Input:  iterable of ``{"class_name": ..., "repr": {...}}`` dicts as
            produced by :func:`adapter.policy_revision._serialize_invariant`.
    Output: 64-char lowercase hex digest.
    """
    canonical_items: List[str] = []
    for item in snapshot:
        if not isinstance(item, dict):
            raise DecisionBundleError(
                f"snapshot entry must be a dict, got {type(item).__name__}"
            )
        canonical_items.append(_canonical_dumps(item))
    canonical_items.sort()
    # A length prefix + separator keeps the hash unambiguous even if one
    # item's canonical form coincidentally starts with another's suffix.
    body = f"count={len(canonical_items)}|" + "\n".join(canonical_items)
    return hashlib.sha256(body.encode("utf-8")).hexdigest()


# ── DecisionBundle dataclass ─────────────────────────────────────────────────


@dataclass(frozen=True)
class DecisionBundle:
    """A signed, self-contained record of one cage verdict.

    Fields:
        bundle_version    : Frozen at ``"1"``. Breaking changes bump to ``"2"``.
        envelope          : The :class:`SignedEnvelope` the cage emitted for
                            the verdict. Signature verifies offline.
        policy_snapshot   : List of serialized invariants (``{class_name,
                            repr}`` shape) that were active when the verdict
                            was issued. Ordered to match
                            ``revision_chain[-1].invariants``.
        revision_chain    : Oldest-first list of the :class:`PolicyRevision`
                            records leading up to the verdict. Capped by
                            ``chain_limit`` (default 50) with the oldest
                            revisions dropped on overflow; ``truncated``
                            records the drop.
        proof_artifacts   : ``proof_backend`` / ``proof_strength`` /
                            ``prover_mode`` copied from the admitting
                            revision; ``compile_hash`` is recomputed over
                            ``policy_snapshot`` so verify can detect
                            tampering. ``witness`` is the optional
                            best-effort artefact from the prover token
                            (None on pattern admissions).
        created_at_unix   : Bundle-build timestamp. Parameterised so tests
                            can build byte-identical bundles.
        cage_version      : Human-readable cage version string stamped at
                            build time (e.g. ``"0.15.0"``).
        bundle_id         : UUID matching the verdict record's ``bundle_id``.
                            Lets callers fetch a bundle by id without having
                            to hash the intent.
        intent_hash       : Copy of ``envelope.intent_hash``. Promoted to
                            the top level so a JSONL reader can find the
                            bundle's identity without parsing the envelope
                            record.
        truncated         : True when ``chain_limit`` dropped revisions
                            from the front. Auditors see at a glance that
                            the chain is a window, not the full lineage.
        chain_total       : Length of the chain before truncation. Lets
                            the verifier distinguish "I see 50 of 50" from
                            "I see 50 of 247".
    """

    bundle_version: str
    envelope: SignedEnvelope
    policy_snapshot: Tuple[Dict[str, Any], ...]
    revision_chain: Tuple[PolicyRevision, ...]
    proof_artifacts: Dict[str, Any]
    created_at_unix: int
    cage_version: str
    bundle_id: str
    intent_hash: str
    truncated: bool = False
    chain_total: int = 0


@dataclass(frozen=True)
class VerifyResult:
    """Structured outcome of offline bundle verification.

    Fields:
        valid                : True iff every per-check field is True.
        reason               : Human-readable diagnosis on failure, None on
                               success. Never leaks key material.
        envelope_signature_ok: Signature on the envelope verifies against
                               the supplied key material.
        revision_binding_ok  : ``envelope.policy_revision_id`` equals the
                               chain head's ``revision_id`` (or both are
                               None on a legacy v1 envelope).
        compile_hash_ok      : Stored ``proof_artifacts.compile_hash``
                               equals the recomputation over the snapshot.
        bundle_version       : Declared version string from the bundle, or
                               None on a structurally-broken file.
        bundle_id            : UUID copied from the header for logging /
                               dedup.
    """

    valid: bool
    reason: Optional[str] = None
    envelope_signature_ok: bool = False
    revision_binding_ok: bool = False
    compile_hash_ok: bool = False
    bundle_version: Optional[str] = None
    bundle_id: Optional[str] = None


# ── construction ─────────────────────────────────────────────────────────────


def build_decision_bundle(
    envelope: SignedEnvelope,
    *,
    active_invariants: Iterable[Any],
    revision_log: Iterable[PolicyRevision],
    cage_version: str,
    bundle_id: str,
    created_at_unix: int,
    chain_limit: int = 50,
    witness: Optional[str] = None,
) -> DecisionBundle:
    """Assemble a :class:`DecisionBundle` from live daemon state.

    Pure function — takes the envelope + current state, returns a bundle
    without touching disk, the daemon lock, or any I/O.

    Args:
        envelope          : The signed envelope for this verdict. Copied
                            verbatim into the bundle; callers must have
                            already signed it.
        active_invariants : The invariants active when the verdict was
                            issued. Typically
                            ``registry.invariants`` or the ``.invariants``
                            tuple on the active ``PolicyRevision``.
                            Order is preserved.
        revision_log      : Oldest-first iterable of
                            :class:`PolicyRevision`. Typically
                            ``RevisionLog.revisions``. When longer than
                            ``chain_limit``, the oldest revisions are
                            dropped and ``truncated`` is set True.
        cage_version      : Human-readable cage version stamp.
        bundle_id         : UUID that links this bundle to the daemon's
                            verdict record.
        created_at_unix   : Timestamp to stamp into the header. Test-stable.
        chain_limit       : Max revisions to include. Bundles for deep
                            histories stay a manageable size.
        witness           : Optional witness string to attach under
                            ``proof_artifacts.witness``. Callers that have
                            a proof token / counterexample can surface it
                            here; None skips the field.

    Returns:
        A :class:`DecisionBundle` ready for :func:`bundle_to_jsonl`.

    Raises:
        DecisionBundleError: ``chain_limit <= 0``, or ``revision_log``
            contains a non-:class:`PolicyRevision` entry.
    """
    if chain_limit <= 0:
        raise DecisionBundleError(
            f"chain_limit must be > 0, got {chain_limit}"
        )
    # Snapshot the invariants in admission order so verifiers see the
    # same sequence the registry saw. Sorting happens inside
    # `compute_policy_snapshot_hash`, not here — we preserve the
    # authoring order on the wire for human auditors.
    snapshot: List[Dict[str, Any]] = []
    for inv in active_invariants:
        snapshot.append(_serialize_invariant(inv))
    # Walk the chain oldest-first, validate type, and truncate by dropping
    # from the front (oldest) so the head revision is always preserved —
    # the verifier binds the envelope to it.
    chain_list: List[PolicyRevision] = []
    for rev in revision_log:
        if not isinstance(rev, PolicyRevision):
            raise DecisionBundleError(
                f"revision_log entry must be PolicyRevision, got "
                f"{type(rev).__name__}"
            )
        chain_list.append(rev)
    chain_total = len(chain_list)
    truncated = False
    if chain_total > chain_limit:
        # Keep the most recent `chain_limit` revisions; drop the oldest.
        chain_list = chain_list[chain_total - chain_limit:]
        truncated = True
    compile_hash = compute_policy_snapshot_hash(snapshot)
    # Proof artifacts: pull from the head revision when available so
    # `backend / strength / mode` track the admission. `compile_hash`
    # is ALWAYS the recomputed snapshot hash, not the revision's
    # Tau-source hash — that's the invariant the verifier checks.
    head: Optional[PolicyRevision] = chain_list[-1] if chain_list else None
    artifacts: Dict[str, Any] = {
        "proof_backend": head.proof_backend if head else None,
        "proof_strength": head.proof_strength if head else None,
        "prover_mode": head.prover_mode if head else None,
        "compile_hash": compile_hash,
    }
    if witness is not None:
        artifacts["witness"] = witness
    return DecisionBundle(
        bundle_version=BUNDLE_VERSION_V1,
        envelope=envelope,
        policy_snapshot=tuple(snapshot),
        revision_chain=tuple(chain_list),
        proof_artifacts=artifacts,
        created_at_unix=int(created_at_unix),
        cage_version=str(cage_version),
        bundle_id=str(bundle_id),
        intent_hash=envelope.intent_hash,
        truncated=truncated,
        chain_total=chain_total,
    )


# ── JSONL (de)serialisation ─────────────────────────────────────────────────


def bundle_to_jsonl(bundle: DecisionBundle) -> bytes:
    """Serialise a :class:`DecisionBundle` to newline-delimited JSON bytes.

    Layout (one record per line, all newline-terminated):

        1. bundle_header
        2. envelope
        3. proof_artifacts
        4..N. policy_snapshot_item (index preserves order)
        N+1..M. revision_chain_item (index preserves oldest-first order)

    Every line is canonicalised via :func:`_canonical_dumps` so two bundles
    with byte-identical fields produce byte-identical output. The result is
    UTF-8 bytes suitable for writing with a binary-mode open (no locale
    re-encoding).
    """
    if not isinstance(bundle, DecisionBundle):
        raise DecisionBundleError(
            f"bundle_to_jsonl expects DecisionBundle, got {type(bundle).__name__}"
        )
    lines: List[str] = []
    header = {
        "_record": _RECORD_HEADER,
        "bundle_version": bundle.bundle_version,
        "bundle_id": bundle.bundle_id,
        "created_at_unix": bundle.created_at_unix,
        "cage_version": bundle.cage_version,
        "intent_hash": bundle.intent_hash,
        "truncated": bundle.truncated,
        "chain_total": bundle.chain_total,
    }
    lines.append(_canonical_dumps(header))
    # Envelope via to_json -> re-parse -> tag. We round-trip through
    # `from_json` bytes so the canonical representation of the envelope
    # matches whatever the signer itself produced; tampering at this layer
    # would be caught by signature verification later.
    envelope_payload = json.loads(bundle.envelope.to_json())
    envelope_record = {"_record": _RECORD_ENVELOPE, **envelope_payload}
    lines.append(_canonical_dumps(envelope_record))
    artifacts_record = {"_record": _RECORD_ARTIFACTS, **dict(bundle.proof_artifacts)}
    lines.append(_canonical_dumps(artifacts_record))
    for i, item in enumerate(bundle.policy_snapshot):
        record = {
            "_record": _RECORD_SNAPSHOT_ITEM,
            "index": i,
            "class_name": item.get("class_name"),
            "repr": item.get("repr"),
        }
        lines.append(_canonical_dumps(record))
    for i, rev in enumerate(bundle.revision_chain):
        record = {
            "_record": _RECORD_CHAIN_ITEM,
            "index": i,
            "revision": rev.to_dict(),
        }
        lines.append(_canonical_dumps(record))
    return ("\n".join(lines) + "\n").encode("utf-8")


def bundle_from_jsonl(data: bytes) -> DecisionBundle:
    """Parse a decision bundle from its JSONL bytes form.

    Inverse of :func:`bundle_to_jsonl`. Unknown record types raise
    :class:`DecisionBundleError` so a v1 reader never silently drops a
    future v2 record; breaking changes bump ``bundle_version``.

    Does NOT verify signatures or compile_hash — call
    :func:`verify_decision_bundle` for that. This keeps parsing cheap
    when a caller just wants to inspect the header (e.g. for routing).
    """
    if not isinstance(data, (bytes, bytearray)):
        raise DecisionBundleError(
            f"bundle_from_jsonl expects bytes, got {type(data).__name__}"
        )
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise DecisionBundleError(f"bundle bytes are not valid UTF-8: {exc}") from exc
    lines = [ln for ln in text.split("\n") if ln.strip()]
    if len(lines) < 3:
        raise DecisionBundleError(
            f"bundle must have at least header+envelope+artifacts, got {len(lines)} lines"
        )
    records: List[Dict[str, Any]] = []
    for lineno, raw in enumerate(lines, start=1):
        try:
            records.append(json.loads(raw))
        except json.JSONDecodeError as exc:
            raise DecisionBundleError(
                f"line {lineno}: malformed JSON: {exc}"
            ) from exc
    header = records[0]
    if header.get("_record") != _RECORD_HEADER:
        raise DecisionBundleError(
            f"first line must be {_RECORD_HEADER!r} record, got "
            f"{header.get('_record')!r}"
        )
    version = header.get("bundle_version")
    if version != BUNDLE_VERSION_V1:
        raise DecisionBundleError(
            f"unsupported bundle_version {version!r}; this reader understands "
            f"v{BUNDLE_VERSION_V1!r}"
        )
    envelope_record = records[1]
    if envelope_record.get("_record") != _RECORD_ENVELOPE:
        raise DecisionBundleError(
            f"second line must be {_RECORD_ENVELOPE!r} record, got "
            f"{envelope_record.get('_record')!r}"
        )
    artifacts_record = records[2]
    if artifacts_record.get("_record") != _RECORD_ARTIFACTS:
        raise DecisionBundleError(
            f"third line must be {_RECORD_ARTIFACTS!r} record, got "
            f"{artifacts_record.get('_record')!r}"
        )
    # Build the envelope from the record minus the discriminator. The
    # SignedEnvelope.from_json expects a JSON string, so canonicalise
    # and hand it over.
    env_payload = {k: v for k, v in envelope_record.items() if k != "_record"}
    try:
        envelope = SignedEnvelope.from_json(_canonical_dumps(env_payload))
    except SignatureError as exc:
        # SignatureError from `from_json` here means the envelope record
        # is malformed (missing fields / bad version); wrap in the
        # bundle error type so callers see a single exception surface
        # for "this file is broken".
        raise DecisionBundleError(
            f"envelope record is not a valid SignedEnvelope: {exc}"
        ) from exc
    artifacts = {k: v for k, v in artifacts_record.items() if k != "_record"}
    snapshot_items: List[Tuple[int, Dict[str, Any]]] = []
    chain_items: List[Tuple[int, Dict[str, Any]]] = []
    for rec in records[3:]:
        rtype = rec.get("_record")
        if rtype == _RECORD_SNAPSHOT_ITEM:
            idx = rec.get("index")
            if not isinstance(idx, int):
                raise DecisionBundleError(
                    f"snapshot item missing integer 'index': {rec!r}"
                )
            snapshot_items.append((idx, {
                "class_name": rec.get("class_name"),
                "repr": rec.get("repr"),
            }))
        elif rtype == _RECORD_CHAIN_ITEM:
            idx = rec.get("index")
            if not isinstance(idx, int):
                raise DecisionBundleError(
                    f"chain item missing integer 'index': {rec!r}"
                )
            revision_dict = rec.get("revision")
            if not isinstance(revision_dict, dict):
                raise DecisionBundleError(
                    f"chain item missing 'revision' dict: {rec!r}"
                )
            chain_items.append((idx, revision_dict))
        else:
            raise DecisionBundleError(
                f"unknown record type {rtype!r}"
            )
    # Restore order by the stored index; sort is stable so equal indices
    # survive (should never happen on a well-formed bundle, but this
    # preserves intent without crashing on duplicates).
    snapshot_items.sort(key=lambda t: t[0])
    chain_items.sort(key=lambda t: t[0])
    snapshot = tuple(item for _, item in snapshot_items)
    revisions = tuple(
        PolicyRevision.from_dict(d) for _, d in chain_items
    )
    bundle_id = header.get("bundle_id")
    if not isinstance(bundle_id, str):
        raise DecisionBundleError(
            f"header missing string 'bundle_id': {header!r}"
        )
    intent_hash = header.get("intent_hash")
    if not isinstance(intent_hash, str):
        raise DecisionBundleError(
            f"header missing string 'intent_hash': {header!r}"
        )
    created_at = header.get("created_at_unix")
    if not isinstance(created_at, int):
        raise DecisionBundleError(
            f"header missing integer 'created_at_unix': {header!r}"
        )
    cage_version = header.get("cage_version")
    if not isinstance(cage_version, str):
        raise DecisionBundleError(
            f"header missing string 'cage_version': {header!r}"
        )
    truncated = bool(header.get("truncated", False))
    chain_total = header.get("chain_total")
    if not isinstance(chain_total, int):
        chain_total = len(revisions)
    return DecisionBundle(
        bundle_version=version,
        envelope=envelope,
        policy_snapshot=snapshot,
        revision_chain=revisions,
        proof_artifacts=artifacts,
        created_at_unix=created_at,
        cage_version=cage_version,
        bundle_id=bundle_id,
        intent_hash=intent_hash,
        truncated=truncated,
        chain_total=chain_total,
    )


# ── verification ─────────────────────────────────────────────────────────────


def _fail(
    reason: str,
    *,
    bundle_version: Optional[str] = None,
    bundle_id: Optional[str] = None,
    envelope_signature_ok: bool = False,
    revision_binding_ok: bool = False,
    compile_hash_ok: bool = False,
) -> VerifyResult:
    """Build a VerifyResult for a failing check.

    Preserves the partial per-layer results so callers can tell WHICH
    check failed — a tampered snapshot (compile_hash_ok=False) looks
    different from a wrong key (envelope_signature_ok=False) in the
    returned object, even though both set ``valid=False``.
    """
    return VerifyResult(
        valid=False,
        reason=reason,
        envelope_signature_ok=envelope_signature_ok,
        revision_binding_ok=revision_binding_ok,
        compile_hash_ok=compile_hash_ok,
        bundle_version=bundle_version,
        bundle_id=bundle_id,
    )


def verify_decision_bundle(
    bundle: DecisionBundle,
    *,
    secret: Optional[bytes] = None,
    public_key: Optional[object] = None,
) -> VerifyResult:
    """Offline-verify a decision bundle.

    Runs three independent checks and returns a structured
    :class:`VerifyResult`:

    1. **Envelope signature** — via
       :func:`adapter.verdict_signer.verify`. Dispatch on envelope
       ``algorithm``: HMAC needs ``secret``, Ed25519 needs ``public_key``.
       Note we do NOT pass ``now_unix`` — the bundle is for offline
       audit, not TTL enforcement. Skipping expiry keeps
       year-later-auditor flows working.
    2. **Revision binding** — the envelope's
       ``policy_revision_id`` must equal the chain head's ``revision_id``.
       Legacy v1 envelopes (no provenance fields) skip this check.
    3. **Compile-hash binding** — recompute
       ``compute_policy_snapshot_hash(policy_snapshot)`` and compare with
       ``proof_artifacts["compile_hash"]``.

    Never raises on predictable failures. Callers that want to propagate
    a ``DecisionBundleError`` (e.g. malformed input) must do their own
    input validation before calling.
    """
    if not isinstance(bundle, DecisionBundle):
        return _fail(
            f"expected DecisionBundle, got {type(bundle).__name__}"
        )
    if bundle.bundle_version != BUNDLE_VERSION_V1:
        return _fail(
            f"unsupported bundle_version {bundle.bundle_version!r}; "
            f"this verifier understands v{BUNDLE_VERSION_V1!r}",
            bundle_version=bundle.bundle_version,
            bundle_id=bundle.bundle_id,
        )
    # --- envelope signature ---------------------------------------------------
    env = bundle.envelope
    algorithm = env.algorithm
    if algorithm == ALG_HMAC_SHA256 and secret is None:
        return _fail(
            "HMAC envelope verification requires 'secret' (got None)",
            bundle_version=bundle.bundle_version,
            bundle_id=bundle.bundle_id,
        )
    if algorithm == ALG_ED25519 and public_key is None:
        return _fail(
            "ed25519 envelope verification requires 'public_key' (got None)",
            bundle_version=bundle.bundle_version,
            bundle_id=bundle.bundle_id,
        )
    # We verify the MAC / signature ourselves rather than calling
    # ``verdict_signer.verify`` directly, because that function also
    # checks ``intent_hash`` against a supplied PaymentIntent and TTL
    # against the clock. Bundles are audited offline; we skip both and
    # focus on the signature-integrity question.
    try:
        payload = _canonical_mac_input(
            env.outcome,
            env.rule_id,
            env.witness,
            env.reason_text,
            env.issued_at_unix,
            env.ttl_seconds,
            env.intent_hash,
            version=env.version,
            policy_revision_id=env.policy_revision_id,
            proof_backend=env.proof_backend,
            proof_strength=env.proof_strength,
            prover_mode=env.prover_mode,
            compile_hash=env.compile_hash,
            algorithm=env.algorithm,
            without_system=env.without_system,
            mode=env.mode,
            shadow_would_reject=env.shadow_would_reject,
            shadow_rule_id=env.shadow_rule_id,
            shadow_reason_text=env.shadow_reason_text,
            risk_amount_projected=env.risk_amount_projected,
        )
    except Exception as exc:  # noqa: BLE001 — canonical-input bugs shouldn't crash verify
        return _fail(
            f"failed to rebuild canonical envelope payload: {exc}",
            bundle_version=bundle.bundle_version,
            bundle_id=bundle.bundle_id,
        )
    envelope_signature_ok = False
    if algorithm == ALG_HMAC_SHA256:
        import hmac as _hmac
        expected = _hmac.new(
            secret or b"", payload, hashlib.sha256
        ).hexdigest()
        envelope_signature_ok = _hmac.compare_digest(env.mac_hex, expected)
    elif algorithm == ALG_ED25519:
        try:
            from cryptography.exceptions import InvalidSignature
        except ImportError:  # pragma: no cover - dep gate
            return _fail(
                "ed25519 verification requires the 'cryptography' package",
                bundle_version=bundle.bundle_version,
                bundle_id=bundle.bundle_id,
            )
        try:
            signature = bytes.fromhex(env.mac_hex)
        except ValueError as exc:
            return _fail(
                f"ed25519 signature is not valid hex: {exc}",
                bundle_version=bundle.bundle_version,
                bundle_id=bundle.bundle_id,
            )
        try:
            public_key.verify(signature, payload)  # type: ignore[attr-defined]
            envelope_signature_ok = True
        except InvalidSignature:
            envelope_signature_ok = False
        except Exception as exc:  # noqa: BLE001 — defensive; wrong key type etc.
            return _fail(
                f"ed25519 public key rejected payload: {exc}",
                bundle_version=bundle.bundle_version,
                bundle_id=bundle.bundle_id,
            )
    else:
        return _fail(
            f"unsupported envelope algorithm: {algorithm!r}",
            bundle_version=bundle.bundle_version,
            bundle_id=bundle.bundle_id,
        )
    if not envelope_signature_ok:
        return _fail(
            "envelope signature verification failed — envelope tampered or "
            "wrong key material",
            bundle_version=bundle.bundle_version,
            bundle_id=bundle.bundle_id,
            envelope_signature_ok=False,
        )
    # --- revision binding -----------------------------------------------------
    chain_head_id = (
        bundle.revision_chain[-1].revision_id
        if bundle.revision_chain else None
    )
    env_rev_id = env.policy_revision_id
    # Legacy v1 envelopes carry no provenance. An empty chain + empty
    # envelope provenance is consistent; anything else is a mismatch.
    if env_rev_id is None and chain_head_id is None:
        revision_binding_ok = True
    elif env_rev_id is None or chain_head_id is None:
        return _fail(
            f"revision binding mismatch — envelope revision_id "
            f"{env_rev_id!r} does not match chain head {chain_head_id!r}",
            bundle_version=bundle.bundle_version,
            bundle_id=bundle.bundle_id,
            envelope_signature_ok=envelope_signature_ok,
            revision_binding_ok=False,
        )
    else:
        revision_binding_ok = env_rev_id == chain_head_id
    if not revision_binding_ok:
        return _fail(
            f"revision binding mismatch — envelope revision_id "
            f"{env_rev_id!r} does not match chain head {chain_head_id!r}",
            bundle_version=bundle.bundle_version,
            bundle_id=bundle.bundle_id,
            envelope_signature_ok=envelope_signature_ok,
            revision_binding_ok=False,
        )
    # --- compile hash binding -------------------------------------------------
    stored_hash = bundle.proof_artifacts.get("compile_hash")
    if not isinstance(stored_hash, str):
        return _fail(
            f"proof_artifacts missing string compile_hash "
            f"(got {type(stored_hash).__name__})",
            bundle_version=bundle.bundle_version,
            bundle_id=bundle.bundle_id,
            envelope_signature_ok=envelope_signature_ok,
            revision_binding_ok=revision_binding_ok,
        )
    try:
        recomputed_hash = compute_policy_snapshot_hash(bundle.policy_snapshot)
    except DecisionBundleError as exc:
        return _fail(
            f"failed to recompute compile_hash over snapshot: {exc}",
            bundle_version=bundle.bundle_version,
            bundle_id=bundle.bundle_id,
            envelope_signature_ok=envelope_signature_ok,
            revision_binding_ok=revision_binding_ok,
        )
    compile_hash_ok = stored_hash == recomputed_hash
    if not compile_hash_ok:
        return _fail(
            "compile_hash mismatch — policy_snapshot has been tampered "
            "with (stored and recomputed hashes differ)",
            bundle_version=bundle.bundle_version,
            bundle_id=bundle.bundle_id,
            envelope_signature_ok=envelope_signature_ok,
            revision_binding_ok=revision_binding_ok,
            compile_hash_ok=False,
        )
    return VerifyResult(
        valid=True,
        reason=None,
        envelope_signature_ok=True,
        revision_binding_ok=True,
        compile_hash_ok=True,
        bundle_version=bundle.bundle_version,
        bundle_id=bundle.bundle_id,
    )


# ── helper: rehydrate the snapshot into live Invariant objects ───────────────


def rehydrate_policy_snapshot(
    snapshot: Iterable[Dict[str, Any]],
) -> Tuple[Any, ...]:
    """Rebuild live ``Invariant`` objects from the serialized snapshot.

    Exposed so auditors doing policy-replay can feed a bundle's
    ``policy_snapshot`` directly into a fresh registry without touching
    internal helpers. Equivalent to
    ``adapter.policy_revision._rehydrate_invariant`` per-item, with
    structural validation on the input.
    """
    out: List[Any] = []
    for entry in snapshot:
        out.append(_rehydrate_invariant(dict(entry)))
    return tuple(out)
