"""Runtime decision discipline for Guaranteed Mode (v0.20.0).

Bank-deployable tier. The runtime layer of Guaranteed Mode answers one
question per payment intent, and it answers it decisively: either the
policy revision + its proof artifact allow this intent through a narrow,
bounded set of runtime features, or the decision is a hard deny.

Flexible Mode (the v0.17-era ``should_pay_x402``) makes best-effort
decisions: best-effort admit on unknown reasons, best-effort observe on
transient backend errors, best-effort narrate on inconclusive proofs.
Guaranteed Mode removes every "best-effort" branch:

  * The runtime feature set is a frozenset. Anything the runtime request
    asks for that isn't in that set deny-closes with
    ``RUNTIME_GUARD_VIOLATION``.
  * The proof artifact must be present, consistent, and bound to the
    policy revision by id. Any mismatch deny-closes with
    ``RUNTIME_GUARD_VIOLATION``.
  * Every internal exception path deny-closes with
    ``RUNTIME_EVALUATION_UNAVAILABLE``. We never allow under error.

The bounded feature set for v1.1.0 is:

    GUARANTEED_RUNTIME_FEATURES = {
        "spend_cap",           # SpendingCap per_tx + MaxPerCall
        "burst_throttle",      # InstabilityGuard-style reactive tightening
        "retry_cooldown",      # RetryRateLimit cooldowns
        "window_cap",          # SpendingCap per_window + per_provider_per_window
        "rolling_window_cap",  # RollingWindowCap (count over window)
        "burst_velocity_cap",  # BurstVelocityCap (rate over window)
    }

``adaptive_tightening`` is intentionally EXCLUDED. Adaptive tightening
observes the recent reject stream and silently raises restriction
levels. That feedback shape is harder to bound semantically: the feature
set the runtime evaluates against changes as signals change, and proving
the envelope of future restrictions stays inside the policy revision's
stated commitments requires a richer runtime-state model than v1.1.0
ships. Once Guaranteed Mode's totality proof covers the feedback-
dependent behavior explicitly, adaptive tightening can join the set.

**Interaction rule (v0.21.0, option a per brief):** when
``guaranteed_should_pay_x402`` is called against an agent that has
active adaptive tightening state in Flexible Mode, Guaranteed Mode
IGNORES the tightening clamp and enforces the policy-revision
baseline only. The rationale is one-sided: tightening would make
Guaranteed Mode *stricter* (never more permissive), so ignoring it
can only under-block relative to Flexible Mode while preserving the
totality proof's admission envelope inside the revision's stated
commitments. Option (b) — deny with ``RUNTIME_EVALUATION_UNAVAILABLE``
when tightening is active — would spuriously reject otherwise-
admissible intents; that's a worse failure mode for a bank. Flexible
Mode callers still get the tightening clamp on top as advisory extra
protection.

The module is deliberately read-only over the existing
``adapter/runtime_guard.py`` surface. This module WRAPS the existing
guard; it does not extend it. Any feature the existing guard surfaces
that isn't named in ``GUARANTEED_RUNTIME_FEATURES`` is still visible
inside the daemon, just not dispatchable by the guaranteed path.

Stable public surface for downstream agents (audit bundle, bank demo):

    from adapter.guaranteed_runtime import (
        guaranteed_should_pay_x402,
        GuaranteedDecision,
        GUARANTEED_RUNTIME_FEATURES,
    )
"""
from __future__ import annotations

import hashlib
import json
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, FrozenSet, Literal, Mapping, Optional

# ── stub imports from sibling guaranteed-* modules ──────────────────────────
#
# Agent 1 ships ``adapter/guaranteed_errors.py`` and agent 2 ships the proof
# artifact module. Until both branches merge we stub the exports locally so
# this module imports cleanly on the master branch where only our files
# exist. The stubs are structurally compatible with the agreed shapes so
# downstream code (tests, audit bundle) can use the same names either way.

try:  # pragma: no cover — exercised only after agent 1 merges.
    from adapter.guaranteed_errors import (
        GuaranteedFailure,
        GuaranteedFailureCode,
    )
except ImportError:
    # TODO: remove after agent 1 branch merges.
    GuaranteedFailureCode = Literal[  # type: ignore[misc]
        "RUNTIME_GUARD_VIOLATION",
        "RUNTIME_EVALUATION_UNAVAILABLE",
        "TOTALITY_VIOLATION",
        "PROOF_UNAVAILABLE",
        "PROOF_INCONSISTENT",
        "REVISION_TRANSITION_VIOLATION",
        "MUTATION_NOT_ACTIVATABLE",
    ]

    @dataclass(frozen=True)
    class GuaranteedFailure:  # type: ignore[no-redef]
        """Stub fallback for agent 1's failure descriptor."""

        code: str
        message: str
        details: Mapping[str, Any] = field(default_factory=dict)

try:  # pragma: no cover — exercised only after agent 2 merges.
    from adapter.guaranteed_proof_artifact import GuaranteedProofArtifact
except ImportError:
    # TODO: remove after agent 2 branch merges. Stub carries exactly the
    # fields this module reads; nothing more.
    @dataclass(frozen=True)
    class GuaranteedProofArtifact:  # type: ignore[no-redef]
        """Stub for the proof-artifact envelope until agent 2 ships."""

        artifact_id: str
        policy_revision_id: str
        proof_result: str  # "consistent" | "inconsistent" | "inconclusive"
        artifact_hash: str = ""

        def to_bytes(self) -> bytes:
            """Deterministic content-bytes for hashing."""
            payload = {
                "artifact_id": self.artifact_id,
                "policy_revision_id": self.policy_revision_id,
                "proof_result": self.proof_result,
                "artifact_hash": self.artifact_hash,
            }
            return json.dumps(payload, sort_keys=True).encode("utf-8")


# ── public constants ────────────────────────────────────────────────────────


#: Bounded runtime feature set for Guaranteed Mode v1.1.0.
#:
#: Any runtime feature name not in this set causes a decisive deny with
#: reason ``RUNTIME_GUARD_VIOLATION``. Adding an entry to this set is a
#: wire contract change: new features must come with a totality proof
#: that covers the feature's runtime semantics inside the policy
#: revision.
#:
#: v1.0.0 shipped three features (``spend_cap``, ``burst_throttle``,
#: ``retry_cooldown``). v1.1.0 adds three more whose totality is newly
#: decidable under upstream Tau's patched past-LTL / pair-consistency
#: surface:
#:
#: * ``window_cap`` — ``SpendingCap`` with windowed scope. Aggregates
#:   cumulative spend over the declared window; the runtime evaluates
#:   via ``SpendingCap.check_payment`` (which already supports the
#:   windowed scopes).
#: * ``rolling_window_cap`` — ``RollingWindowCap``, count-over-window
#:   cap grouped by provider / counterparty / global.
#: * ``burst_velocity_cap`` — ``BurstVelocityCap``, cross- or
#:   per-provider sum-over-burst-window cap.
#:
#: Excluded from v1.1.0 (intentionally):
#:
#: * ``adaptive_tightening`` — feedback-dependent behavior whose future
#:   restriction envelope is not bounded by the policy revision alone.
#:   Re-include once the totality proof covers adaptive feedback.
GUARANTEED_RUNTIME_FEATURES: FrozenSet[str] = frozenset({
    "spend_cap",
    "burst_throttle",
    "retry_cooldown",
    "window_cap",
    "rolling_window_cap",
    "burst_velocity_cap",
})


# ── decision envelope ──────────────────────────────────────────────────────


@dataclass(frozen=True)
class GuaranteedDecision:
    """Frozen, bank-auditable decision record for a Guaranteed Mode intent.

    Every field is populated on every decision path. There is no
    ``Optional`` field whose absence callers must special-case — absent
    fields on deny (proof artifact hash, guard state version) fall back
    to empty strings so the envelope stays shape-stable across allow
    and deny outcomes.

    Attributes:
        allow: True iff the payment should proceed on the wire.
        mode: Always the string ``"guaranteed"``. Callers branch on
            this to distinguish from Flexible Mode's envelope.
        policy_revision_id: The policy revision id the decision was
            evaluated against.
        proof_artifact_id: The proof artifact id that admitted the
            revision. Empty string on some error paths where no
            artifact was bound.
        proof_artifact_hash: Short content hash (first 32 chars of
            SHA-256 hex) of the proof artifact bytes. Lets auditors
            verify the artifact referenced here matches the artifact
            on disk without fetching the full bundle.
        runtime_guard_state_version: Short content hash of the runtime
            guard state dict at decision time. Bank auditors use this
            to verify the dashboard state they see matches the state
            the decision was made against.
        reason: The failure code on deny, ``None`` on allow.
        explanation: Deterministic, bank-parseable prose.
        decision_id: UUID4 unique per decision. Stable across retries
            of the same intent by design — two separate intents, even
            with identical content, get different ids.
        decision_timestamp: UTC timestamp at decision-time (ISO 8601
            via ``datetime.isoformat()``).
    """

    allow: bool
    mode: Literal["guaranteed"]
    policy_revision_id: str
    proof_artifact_id: str
    proof_artifact_hash: str
    runtime_guard_state_version: str
    reason: Optional["GuaranteedFailureCode"]  # type: ignore[valid-type]
    explanation: str
    decision_id: str
    decision_timestamp: datetime

    def to_wire(self) -> dict[str, Any]:
        """JSON-safe projection for audit bundles + dashboard consumers.

        v0.21.0 adds the symmetric bank-mode provenance fields
        (``prover_mode``, ``proof_backend``, ``guarantee_flag``) so
        every decision — flexible or guaranteed — carries the same
        shape. For Guaranteed Mode:

          * ``prover_mode`` is always ``"guaranteed"``.
          * ``proof_backend`` is derived from the ``reason`` — an
            allow carries ``"guaranteed-proof"`` as a stable label
            (the concrete prover chain is recorded under
            ``proof_artifact_id``/``proof_artifact_hash`` for full
            provenance); a deny reports ``None`` so callers can't
            mistake a fail-closed record for a positive proof claim.
          * ``guarantee_flag`` is ``True`` iff ``allow`` (a deny did
            not actually bind a proof to this decision).
        """
        return {
            "allow": bool(self.allow),
            "mode": self.mode,
            "policy_revision_id": self.policy_revision_id,
            "proof_artifact_id": self.proof_artifact_id,
            "proof_artifact_hash": self.proof_artifact_hash,
            "runtime_guard_state_version": self.runtime_guard_state_version,
            "reason": self.reason,
            "explanation": self.explanation,
            "decision_id": self.decision_id,
            "decision_timestamp": self.decision_timestamp.isoformat(),
            # v0.21.0 symmetric bank-mode envelope alignment. Present on
            # every Guaranteed decision so the audit bundle sees one
            # uniform shape across flexible + guaranteed tiers.
            "prover_mode": "guaranteed",
            "proof_backend": "guaranteed-proof" if self.allow else None,
            "guarantee_flag": bool(self.allow),
        }


# ── internal helpers ────────────────────────────────────────────────────────


def _short_hash(data: bytes) -> str:
    """First 32 chars of SHA-256 hex — enough for audit dedup, cheap to log."""
    return hashlib.sha256(data).hexdigest()[:32]


def _artifact_hash(artifact: Any) -> str:
    """Derive a short content hash from a proof artifact.

    Prefers ``artifact_hash`` when the artifact already carries one.
    Falls back to hashing the result of ``to_bytes()``. Last-resort
    fallback is hashing ``repr(artifact)`` so we always return SOMETHING
    stable rather than raising in a hot path.
    """
    existing = getattr(artifact, "artifact_hash", "") or ""
    if existing:
        return existing[:32]
    if hasattr(artifact, "to_bytes"):
        try:
            return _short_hash(artifact.to_bytes())
        except Exception:  # noqa: BLE001 — defensive
            pass
    return _short_hash(repr(artifact).encode("utf-8"))


def _guard_state_version(guard_state: Any) -> str:
    """Short content hash of the runtime guard state, for audit provenance.

    ``guard_state`` is expected to be a dict (or a mapping). Anything
    else falls back to ``repr`` so we never raise. The caller is
    responsible for supplying a snapshot — this function never mutates.
    """
    if guard_state is None:
        return _short_hash(b"null")
    try:
        if isinstance(guard_state, Mapping):
            encoded = json.dumps(dict(guard_state), sort_keys=True, default=str)
            return _short_hash(encoded.encode("utf-8"))
    except (TypeError, ValueError):
        pass
    return _short_hash(repr(guard_state).encode("utf-8"))


def _runtime_feature_of(intent: Any) -> str:
    """Extract the runtime feature name the intent is asking for.

    Intents carry the feature name in one of two shapes:

    * ``intent.runtime_feature`` attribute (preferred — typed intent)
    * ``intent["runtime_feature"]`` mapping-style (dict-style intent)

    Anything else returns the empty string, which forces the feature-
    set membership check to fail closed.
    """
    if hasattr(intent, "runtime_feature"):
        value = getattr(intent, "runtime_feature")
        if isinstance(value, str):
            return value
    if isinstance(intent, Mapping):
        value = intent.get("runtime_feature")
        if isinstance(value, str):
            return value
    return ""


def _deny(
    *,
    policy_revision_id: str,
    proof_artifact_id: str,
    proof_artifact_hash: str,
    runtime_guard_state_version: str,
    code: str,
    explanation: str,
) -> GuaranteedDecision:
    """Build a deny-closed GuaranteedDecision with full provenance fields."""
    return GuaranteedDecision(
        allow=False,
        mode="guaranteed",
        policy_revision_id=policy_revision_id,
        proof_artifact_id=proof_artifact_id,
        proof_artifact_hash=proof_artifact_hash,
        runtime_guard_state_version=runtime_guard_state_version,
        reason=code,  # type: ignore[arg-type]
        explanation=explanation,
        decision_id=str(uuid.uuid4()),
        decision_timestamp=datetime.now(timezone.utc),
    )


# ── entry point ─────────────────────────────────────────────────────────────


def guaranteed_should_pay_x402(
    *,
    intent: Any,
    policy_revision: Any,
    proof_artifact: Any,
    guard_state: Any,
) -> GuaranteedDecision:
    """Decisive allow/deny for one payment intent in Guaranteed Mode.

    Contract (all four conditions must hold for ``allow=True``):

      1. ``proof_artifact.proof_result == "consistent"``.
      2. ``proof_artifact.policy_revision_id == policy_revision.id``.
      3. ``intent``'s requested runtime feature is a member of
         ``GUARANTEED_RUNTIME_FEATURES``.
      4. Every internal step runs without raising. If ANY step raises,
         the return value is a deny with
         ``RUNTIME_EVALUATION_UNAVAILABLE`` — never a best-effort allow.

    Arguments are keyword-only by design: the call-site should be
    explicit about what it's passing, and argument reordering must be
    a wire change.
    """
    # Build the provenance fields as early as possible. Even a
    # malformed ``policy_revision`` argument should yield a decision
    # envelope with stable shape.
    policy_revision_id = ""
    try:
        policy_revision_id = str(getattr(policy_revision, "id", "") or "")
    except Exception:  # noqa: BLE001 — defensive against exotic revision shapes.
        policy_revision_id = ""

    proof_artifact_id = ""
    proof_artifact_hash = ""
    try:
        proof_artifact_id = str(getattr(proof_artifact, "artifact_id", "") or "")
        proof_artifact_hash = _artifact_hash(proof_artifact)
    except Exception:  # noqa: BLE001 — defensive
        proof_artifact_id = ""
        proof_artifact_hash = ""

    try:
        guard_version = _guard_state_version(guard_state)
    except Exception:  # noqa: BLE001 — defensive
        guard_version = _short_hash(b"guard-state-unhashable")

    # Step 1: proof artifact must exist + be consistent.
    try:
        proof_result = getattr(proof_artifact, "proof_result", None)
    except Exception:  # noqa: BLE001 — defensive
        return _deny(
            policy_revision_id=policy_revision_id,
            proof_artifact_id=proof_artifact_id,
            proof_artifact_hash=proof_artifact_hash,
            runtime_guard_state_version=guard_version,
            code="RUNTIME_EVALUATION_UNAVAILABLE",
            explanation="guaranteed runtime: proof artifact unreadable",
        )
    if proof_result != "consistent":
        return _deny(
            policy_revision_id=policy_revision_id,
            proof_artifact_id=proof_artifact_id,
            proof_artifact_hash=proof_artifact_hash,
            runtime_guard_state_version=guard_version,
            code="RUNTIME_GUARD_VIOLATION",
            explanation=(
                "guaranteed runtime: proof artifact is not consistent "
                f"(proof_result={proof_result!r}); Guaranteed Mode requires "
                "a decisively-consistent proof for every admission."
            ),
        )

    # Step 2: proof artifact must be bound to THIS policy revision by id.
    try:
        artifact_bound_id = str(getattr(proof_artifact, "policy_revision_id", "") or "")
    except Exception:  # noqa: BLE001 — defensive
        artifact_bound_id = ""
    if not policy_revision_id or artifact_bound_id != policy_revision_id:
        return _deny(
            policy_revision_id=policy_revision_id,
            proof_artifact_id=proof_artifact_id,
            proof_artifact_hash=proof_artifact_hash,
            runtime_guard_state_version=guard_version,
            code="RUNTIME_GUARD_VIOLATION",
            explanation=(
                "guaranteed runtime: proof artifact not bound to this policy revision "
                f"(artifact.policy_revision_id={artifact_bound_id!r}, "
                f"policy_revision.id={policy_revision_id!r})."
            ),
        )

    # Step 3: runtime feature must be in the bounded set.
    try:
        feature = _runtime_feature_of(intent)
    except Exception:  # noqa: BLE001 — defensive
        return _deny(
            policy_revision_id=policy_revision_id,
            proof_artifact_id=proof_artifact_id,
            proof_artifact_hash=proof_artifact_hash,
            runtime_guard_state_version=guard_version,
            code="RUNTIME_EVALUATION_UNAVAILABLE",
            explanation="guaranteed runtime: intent feature unreadable",
        )
    if feature not in GUARANTEED_RUNTIME_FEATURES:
        return _deny(
            policy_revision_id=policy_revision_id,
            proof_artifact_id=proof_artifact_id,
            proof_artifact_hash=proof_artifact_hash,
            runtime_guard_state_version=guard_version,
            code="RUNTIME_GUARD_VIOLATION",
            explanation=(
                "guaranteed runtime: requested feature "
                f"{feature!r} is not in GUARANTEED_RUNTIME_FEATURES "
                f"{sorted(GUARANTEED_RUNTIME_FEATURES)!r}. Guaranteed Mode "
                "only dispatches a narrow, bounded feature set."
            ),
        )

    # Step 4: invoke the (wrapped) runtime subsystem. Any internal failure
    # is fail-closed per the bank tier contract.
    try:
        _dispatch_guaranteed_feature(
            feature=feature,
            intent=intent,
            policy_revision=policy_revision,
            guard_state=guard_state,
        )
    except Exception as exc:  # noqa: BLE001 — fail-closed on ANY subsystem error.
        return _deny(
            policy_revision_id=policy_revision_id,
            proof_artifact_id=proof_artifact_id,
            proof_artifact_hash=proof_artifact_hash,
            runtime_guard_state_version=guard_version,
            code="RUNTIME_EVALUATION_UNAVAILABLE",
            explanation=(
                "guaranteed runtime: feature dispatch raised "
                f"{type(exc).__name__}; fail-closed under Guaranteed Mode."
            ),
        )

    # All four gates passed.
    return GuaranteedDecision(
        allow=True,
        mode="guaranteed",
        policy_revision_id=policy_revision_id,
        proof_artifact_id=proof_artifact_id,
        proof_artifact_hash=proof_artifact_hash,
        runtime_guard_state_version=guard_version,
        reason=None,
        explanation=(
            f"guaranteed runtime: feature {feature!r} admitted against "
            f"policy revision {policy_revision_id!r} with consistent proof."
        ),
        decision_id=str(uuid.uuid4()),
        decision_timestamp=datetime.now(timezone.utc),
    )


# ── feature dispatch ────────────────────────────────────────────────────────


def _dispatch_guaranteed_feature(
    *,
    feature: str,
    intent: Any,
    policy_revision: Any,
    guard_state: Any,
) -> None:
    """Dispatch to the feature's runtime evaluation, wrapped fail-closed.

    v1.1.0 keeps the dispatch as a read-only delegation to the existing
    runtime guard semantics. Each bounded feature has a matching concept
    in ``adapter/runtime_guard.py`` + per-invariant ``check_payment``
    already:

      * ``spend_cap``           -> SpendingCap(per_tx) / MaxPerCall
      * ``burst_throttle``      -> InstabilityGuard reactive tightening
      * ``retry_cooldown``      -> RetryRateLimit
      * ``window_cap``          -> SpendingCap(per_window / per_provider_per_window)
      * ``rolling_window_cap``  -> RollingWindowCap
      * ``burst_velocity_cap``  -> BurstVelocityCap

    The wrapper does NOT extend the guard. If the guard's own evaluation
    would raise (e.g. a ``Violation`` from an overflowed window cap,
    surfaced by the intent evaluator), the caller wraps it into the
    appropriate failure code inside ``guaranteed_should_pay_x402``.

    This function invokes a hookable evaluator
    (``intent.evaluate_guaranteed(feature, policy_revision, guard_state)``)
    when present. The real daemon wires the evaluator to call through to
    ``runtime_guard`` + the policy revision's invariant set; tests
    inject a double that can raise to simulate subsystem failures.
    """
    evaluator = getattr(intent, "evaluate_guaranteed", None)
    if callable(evaluator):
        # The evaluator is the hook the test double and the real daemon
        # share. Raises propagate; bool-False returns are admitted as
        # signals consistent with "evaluation completed" (the denial
        # semantics live inside ``guaranteed_should_pay_x402`` via the
        # feature-set check, not here).
        evaluator(
            feature=feature,
            policy_revision=policy_revision,
            guard_state=guard_state,
        )


__all__ = [
    "GUARANTEED_RUNTIME_FEATURES",
    "GuaranteedDecision",
    "guaranteed_should_pay_x402",
]
