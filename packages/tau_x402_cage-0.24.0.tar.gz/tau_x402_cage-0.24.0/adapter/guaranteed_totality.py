"""Totality gate for Guaranteed Mode (v0.19.0 Deliverable 3).

Where :mod:`adapter.guaranteed_language` answers *is this rule shape
admitted in the tier*, this module answers *does the full declared
policy encode as a closed, well-formed formula that the prover can
decide totally*?

It runs BEFORE the prover. A policy that fails totality never reaches
the Tau backend — the cage refuses with
:data:`adapter.guaranteed_errors.GuaranteedFailureCode.TAU_TOTALITY_FAILED`
(or with ``UNSUPPORTED_FOR_GUARANTEED_MODE`` when the underlying
reason is a rule shape that isn't in the tier at all).

Totality check stages (in order; first failure wins):

1. Every rule type is in
   :attr:`adapter.guaranteed_language.GuaranteedLanguage.SUPPORTED_RULE_TYPES`
   *including* scope-level restrictions (e.g. ``SpendingCap`` is admitted
   but only with ``scope == "per_tx"``).
2. Every composition operator in use (derived from the policy's
   ``composition_form`` metadata when present, defaulting to
   ``"conjunction"`` for bare invariant lists) is in
   ``GuaranteedLanguage.SUPPORTED_COMPOSITION``.
3. Every mutation / revision form in use (derived from
   ``policy.delta.mutation_forms`` when present; empty for static
   policies) is in ``GuaranteedLanguage.SUPPORTED_MUTATION_FORMS``.
4. For every supported invariant, :func:`adapter.tau_compiler.dry_run_encode`
   returns ``(True, ...)``; any failure (free variables, unbalanced
   parens, encoding exception) produces a structured reason.

Contract for other agents::

    from adapter.guaranteed_totality import validate_totality, TotalityReport
    report = validate_totality(loaded_policy)
    if not report.is_total:
        fail_with(report.reason_code, report.unsupported_nodes)

The ``policy`` argument is duck-typed: anything with an ``invariants``
iterable works (``adapter.policy_loader.LoadedPolicy``,
``adapter.policy_revision.PolicyRevision``), as does a bare sequence of
invariants. This keeps the gate decoupled from the specific policy
container in use.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable, Sequence, Tuple

from adapter.guaranteed_errors import GuaranteedFailureCode
from adapter.guaranteed_language import (
    GUARANTEED_LANGUAGE_VERSION,
    GuaranteedLanguage,
)
from adapter.invariants import Invariant
from adapter.tau_compiler import dry_run_encode

__all__ = ["TotalityReport", "validate_totality"]


@dataclass(frozen=True)
class TotalityReport:
    """Outcome of a totality check against the Guaranteed Language tier.

    Fields:
        is_total:          True iff every stage passed.
        reason_code:       The :class:`GuaranteedFailureCode` that wins
                           (first-failure-first ordering); ``None`` on
                           success.
        unsupported_nodes: Tuple of per-failure strings describing the
                           offending rule / operator / mutation form.
                           Empty tuple on success. Kept as a tuple (not
                           a list) so the dataclass remains immutable.
        language_version:  :data:`GUARANTEED_LANGUAGE_VERSION` captured
                           at check time. Audit records stamped with a
                           report from an older language version must
                           not be silently re-interpreted under a newer
                           one.
    """

    is_total: bool
    reason_code: str | None
    unsupported_nodes: Tuple[str, ...]
    language_version: str

    def to_dict(self) -> dict:
        """JSON-serializable representation for audit export."""
        return {
            "schema": "tau-x402-cage.guaranteed-totality.v1",
            "is_total": self.is_total,
            "reason_code": self.reason_code,
            "unsupported_nodes": list(self.unsupported_nodes),
            "language_version": self.language_version,
        }


def validate_totality(policy: Any) -> TotalityReport:
    """Check a policy's totality against the Guaranteed Language tier.

    See module docstring for the 4-stage pipeline. Always returns a
    :class:`TotalityReport` — never raises. Fail-closed: any unexpected
    error during encoding becomes a ``TAU_TOTALITY_FAILED`` report with
    a structured reason.

    Accepts any of:

    * :class:`adapter.policy_loader.LoadedPolicy`
    * :class:`adapter.policy_revision.PolicyRevision`
    * a bare ``Sequence[Invariant]``
    * any duck-typed object exposing ``.invariants`` (iterable) and,
      optionally, ``.composition_form`` and ``.mutation_forms`` fields.
    """
    # ── stage 0: normalize the input ───────────────────────────────
    invariants = _extract_invariants(policy)
    composition_forms = _extract_composition_forms(policy)
    mutation_forms = _extract_mutation_forms(policy)

    unsupported: list[str] = []

    # ── stage 1: rule-type + scope admission ───────────────────────
    for inv in invariants:
        if not isinstance(inv, Invariant):
            unsupported.append(
                f"non-Invariant object of type {type(inv).__name__} in policy"
            )
            continue
        ok, _ = GuaranteedLanguage.is_supported(inv)
        if not ok:
            unsupported.append(
                f"{type(inv).__name__}({_describe_scope(inv)}): "
                f"not in SUPPORTED_RULE_TYPES / SUPPORTED_SCOPES"
            )
    if unsupported:
        return TotalityReport(
            is_total=False,
            reason_code=GuaranteedFailureCode.UNSUPPORTED_FOR_GUARANTEED_MODE.value,
            unsupported_nodes=tuple(unsupported),
            language_version=GUARANTEED_LANGUAGE_VERSION,
        )

    # ── stage 2: composition operator admission ────────────────────
    for op in composition_forms:
        if not GuaranteedLanguage.is_composition_supported(op):
            unsupported.append(
                f"composition_op={op!r}: not in SUPPORTED_COMPOSITION"
            )
    if unsupported:
        return TotalityReport(
            is_total=False,
            reason_code=GuaranteedFailureCode.UNSUPPORTED_FOR_GUARANTEED_MODE.value,
            unsupported_nodes=tuple(unsupported),
            language_version=GUARANTEED_LANGUAGE_VERSION,
        )

    # ── stage 3: mutation-form admission ───────────────────────────
    for form in mutation_forms:
        if not GuaranteedLanguage.is_mutation_form_supported(form):
            unsupported.append(
                f"mutation_form={form!r}: not in SUPPORTED_MUTATION_FORMS"
            )
    if unsupported:
        return TotalityReport(
            is_total=False,
            reason_code=GuaranteedFailureCode.UNSUPPORTED_FOR_GUARANTEED_MODE.value,
            unsupported_nodes=tuple(unsupported),
            language_version=GUARANTEED_LANGUAGE_VERSION,
        )

    # ── stage 4: dry-run encoding (per-invariant) ──────────────────
    for inv in invariants:
        ok, detail = dry_run_encode(inv)
        if not ok:
            unsupported.append(detail)
    if unsupported:
        return TotalityReport(
            is_total=False,
            reason_code=GuaranteedFailureCode.TAU_TOTALITY_FAILED.value,
            unsupported_nodes=tuple(unsupported),
            language_version=GUARANTEED_LANGUAGE_VERSION,
        )

    # All stages passed.
    return TotalityReport(
        is_total=True,
        reason_code=None,
        unsupported_nodes=(),
        language_version=GUARANTEED_LANGUAGE_VERSION,
    )


# ── input normalization helpers ────────────────────────────────────────


def _extract_invariants(policy: Any) -> Tuple[Invariant, ...]:
    """Pull invariants out of a duck-typed policy object.

    Accepted shapes:
    * object with ``.invariants`` attribute (list / tuple / generator);
    * bare sequence of :class:`Invariant`.

    Never raises; returns ``()`` if nothing plausible is present. The
    stage-1 rule-type check catches non-Invariant items and surfaces
    them as structured failures, so we don't need to validate here.
    """
    if policy is None:
        return ()
    # Attribute access wins over sequence interpretation (a
    # ``LoadedPolicy`` dataclass is not iterable in the useful sense).
    if hasattr(policy, "invariants"):
        raw = getattr(policy, "invariants")
        try:
            return tuple(raw)
        except TypeError:
            return ()
    if isinstance(policy, (list, tuple)):
        return tuple(policy)
    # Fallback: iterable of invariants.
    try:
        return tuple(iter(policy))
    except TypeError:
        return ()


def _extract_composition_forms(policy: Any) -> Tuple[str, ...]:
    """Derive the composition operators referenced by ``policy``.

    * If the policy advertises ``composition_form`` (single string) or
      ``composition_forms`` (iterable), use that as ground truth.
    * Otherwise default to ``("conjunction",)`` iff the policy has
      invariants at all (conjunction is the implicit operator when a
      list of rules is loaded with no explicit composition).
    * Empty policies yield ``()`` (no composition to admit).
    """
    if policy is None:
        return ()
    if hasattr(policy, "composition_forms"):
        raw = getattr(policy, "composition_forms")
        if isinstance(raw, str):
            return (raw,)
        try:
            return tuple(str(x) for x in raw)
        except TypeError:
            return ()
    if hasattr(policy, "composition_form"):
        raw = getattr(policy, "composition_form")
        if isinstance(raw, str):
            return (raw,)
    # Default: conjunction if any invariants present, else empty.
    invariants = _extract_invariants(policy)
    if invariants:
        return ("conjunction",)
    return ()


def _extract_mutation_forms(policy: Any) -> Tuple[str, ...]:
    """Derive the mutation forms referenced by ``policy``.

    Static policies (no pending mutation) yield ``()`` and pass
    stage 3 vacuously. Mutation forms are surfaced through either
    ``mutation_forms`` (iterable) or the ``delta.mutation_forms`` path
    on revision objects.
    """
    if policy is None:
        return ()
    if hasattr(policy, "mutation_forms"):
        raw = getattr(policy, "mutation_forms")
        if isinstance(raw, str):
            return (raw,)
        try:
            return tuple(str(x) for x in raw)
        except TypeError:
            return ()
    # Policy revisions carry a ``delta`` dict; some callers keep the
    # mutation-form enumeration there for audit.
    delta = getattr(policy, "delta", None)
    if isinstance(delta, dict):
        raw = delta.get("mutation_forms")
        if isinstance(raw, str):
            return (raw,)
        if isinstance(raw, (list, tuple)):
            return tuple(str(x) for x in raw)
    return ()


def _describe_scope(inv: Invariant) -> str:
    """Short scope description for audit reasons. Intentionally tiny."""
    scope = getattr(inv, "scope", None)
    if scope is not None:
        return f"scope={scope}"
    return ""
