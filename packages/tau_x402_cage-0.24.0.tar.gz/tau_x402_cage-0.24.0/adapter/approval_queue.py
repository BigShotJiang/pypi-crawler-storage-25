"""Agent-proposes / human-approves queue for policy changes.

The queue is a thin, durable layer that sits between an automated agent and
the cage's invariant registry. When an agent wants to change the policy
(add an invariant, typically the output of a learned rule or a compliance
auto-suggestion) it `submit()`s a Proposal. A human reviewer then
`approve()`s or `reject()`s it; approval triggers the standard
`add_invariant` admission path through the daemon.

Design notes:
  * Immutable Proposal dataclass (frozen=True). Every status transition
    returns a new Proposal; the queue rewrites the in-memory dict and
    appends an audit line to the jsonl file.
  * JSON-lines persistence mirrors `adapter/policy_revision.py::RevisionLog`
    -- each append is one JSON line for cheap tailing; rehydration replays
    the file to reconstruct the latest state per proposal_id. Corrupted
    lines raise so audit integrity is never silently compromised.
  * Two-person integrity is enforced at the queue level: a reviewer MUST
    differ from the submitter by default. Callers may explicitly opt out
    for trusted flows (CI bots approving their own draft) but the default
    refuses.
  * Submitting and reviewing never call the prover. That's the daemon's
    job when an approval flips into an `add_invariant` op. Keeping the
    queue pure-Python lets tests exercise the state machine without
    spinning Tau / z3 processes.
"""

from __future__ import annotations

import json
import time
import uuid
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Any, Dict, Iterable, Iterator, List, Optional, Tuple

from adapter.invariants import Invariant
from adapter.policy_revision import (
    RevisionLogError,
    _rehydrate_invariant,
    _serialize_invariant,
)


#: Allowed proposal lifecycle states. Transitions: pending -> approved|rejected.
#: Approved / rejected are terminal; re-reviewing a terminal proposal raises.
ProposalStatus = str  # Literal["pending", "approved", "rejected"]

_STATUS_PENDING = "pending"
_STATUS_APPROVED = "approved"
_STATUS_REJECTED = "rejected"
_STATUSES = (_STATUS_PENDING, _STATUS_APPROVED, _STATUS_REJECTED)


class ApprovalQueueError(ValueError):
    """Raised for invalid proposal transitions or malformed queue entries."""


@dataclass(frozen=True)
class ReviewerVote:
    """One reviewer's approval recorded on a proposal.

    Multi-reviewer governance (v0.14.0) can require N distinct reviewers
    before a proposal admits. Each vote is immutable; the queue stores a
    tuple of them on the Proposal and checks the set cardinality against
    the policy's ``min_reviewers``.
    """

    reviewer_id: str
    approved_at_unix: int
    reason: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "reviewer_id": self.reviewer_id,
            "approved_at_unix": self.approved_at_unix,
            "reason": self.reason,
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "ReviewerVote":
        if not isinstance(d, dict):
            raise ApprovalQueueError(f"reviewer entry not a dict: {d!r}")
        rid = d.get("reviewer_id")
        ts = d.get("approved_at_unix")
        if not isinstance(rid, str) or not rid:
            raise ApprovalQueueError(
                f"reviewer entry missing non-empty 'reviewer_id': {d!r}"
            )
        if ts is None:
            raise ApprovalQueueError(
                f"reviewer entry missing 'approved_at_unix': {d!r}"
            )
        return cls(
            reviewer_id=rid,
            approved_at_unix=int(ts),
            reason=d.get("reason"),
        )


@dataclass(frozen=True)
class Proposal:
    """A single agent-submitted policy change awaiting human review.

    Fields:
        proposal_id        : uuid4 hex, unique across the queue.
        submitted_by       : free-form agent identifier (e.g. "planner-bot-v3").
        submitted_at       : epoch seconds the proposal was queued.
        invariants         : tuple of Invariant instances the agent wants
                             added to the registry on approval.
        diff_from_revision : optional revision_id the proposal was drafted
                             against, for later auditing of "did the live
                             registry move under us between propose and
                             approve?".
        status             : "pending" | "approved" | "rejected".
        reviewed_by        : human reviewer identifier of the final
                             transitioning vote; None while pending.
                             Backwards-compat with v0.7.0 single-reviewer
                             consumers.
        reviewed_at        : epoch seconds the review completed; None while
                             pending.
        reason             : free-form reviewer note; required on reject,
                             optional on approve.
        actor_id           : v0.14.0 — governance actor id recorded at
                             submit time. None for legacy callers that do
                             not wire the governance policy. Used by the
                             mutation-governance layer to gate `submit`.
        reviewers          : v0.14.0 — tuple of ReviewerVote recording
                             every approving reviewer. For single-reviewer
                             approvals this has exactly one entry; for
                             dual-approval policies it accumulates until
                             the governance policy's min_reviewers is met.
                             Old proposals on disk lack the field; load
                             reconstructs it from `reviewed_by` / `reviewed_at`
                             so rehydration never loses audit detail.
    """

    proposal_id: str
    submitted_by: str
    submitted_at: int
    invariants: Tuple[Invariant, ...]
    diff_from_revision: Optional[str] = None
    status: ProposalStatus = _STATUS_PENDING
    reviewed_by: Optional[str] = None
    reviewed_at: Optional[int] = None
    reason: Optional[str] = None
    actor_id: Optional[str] = None
    reviewers: Tuple[ReviewerVote, ...] = ()

    # ── serialization ──────────────────────────────────────────────────────

    def to_dict(self) -> Dict[str, Any]:
        """JSON-safe dict. Invariants go through the same `{class_name, repr}`
        shape `policy_revision` uses so a single rehydration taxonomy covers
        both audit surfaces.
        """
        return {
            "proposal_id": self.proposal_id,
            "submitted_by": self.submitted_by,
            "submitted_at": self.submitted_at,
            "invariants": [_serialize_invariant(inv) for inv in self.invariants],
            "diff_from_revision": self.diff_from_revision,
            "status": self.status,
            "reviewed_by": self.reviewed_by,
            "reviewed_at": self.reviewed_at,
            "reason": self.reason,
            "actor_id": self.actor_id,
            "reviewers": [r.to_dict() for r in self.reviewers],
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "Proposal":
        """Rebuild a Proposal from its JSON-safe dict.

        Missing fields are treated as fatal: we never silently default an
        audit record that might mislead a reviewer.

        Backwards compat (v0.14.0):
          * `actor_id` — absent on pre-v0.14 proposals; defaults to None.
          * `reviewers` — absent on pre-v0.14 proposals; reconstructed
            from `reviewed_by` + `reviewed_at` when the proposal is
            approved, otherwise an empty tuple.
        """
        required = {
            "proposal_id",
            "submitted_by",
            "submitted_at",
            "invariants",
            "status",
        }
        missing = required - d.keys()
        if missing:
            raise ApprovalQueueError(
                f"Proposal dict missing fields: {sorted(missing)}"
            )
        status = d["status"]
        if status not in _STATUSES:
            raise ApprovalQueueError(
                f"Proposal has unknown status {status!r}; expected {_STATUSES}"
            )
        invariants = tuple(_rehydrate_invariant(e) for e in d["invariants"])
        reviewed_by = d.get("reviewed_by")
        reviewed_at_raw = d.get("reviewed_at")
        reviewed_at = (
            int(reviewed_at_raw) if reviewed_at_raw is not None else None
        )
        reviewers_raw = d.get("reviewers")
        if reviewers_raw is None:
            # Pre-v0.14 on-disk record: reconstruct a single-entry
            # reviewers list from the scalar fields so downstream code can
            # rely on `reviewers` without branching on schema version.
            if (
                status == _STATUS_APPROVED
                and reviewed_by
                and reviewed_at is not None
            ):
                reviewers = (
                    ReviewerVote(
                        reviewer_id=reviewed_by,
                        approved_at_unix=reviewed_at,
                        reason=d.get("reason"),
                    ),
                )
            else:
                reviewers = ()
        else:
            if not isinstance(reviewers_raw, list):
                raise ApprovalQueueError(
                    f"Proposal 'reviewers' must be a list, got {type(reviewers_raw).__name__}"
                )
            reviewers = tuple(ReviewerVote.from_dict(r) for r in reviewers_raw)
        return cls(
            proposal_id=d["proposal_id"],
            submitted_by=d["submitted_by"],
            submitted_at=int(d["submitted_at"]),
            invariants=invariants,
            diff_from_revision=d.get("diff_from_revision"),
            status=status,
            reviewed_by=reviewed_by,
            reviewed_at=reviewed_at,
            reason=d.get("reason"),
            actor_id=d.get("actor_id"),
            reviewers=reviewers,
        )


# ── queue container ──────────────────────────────────────────────────────────


@dataclass
class ApprovalQueue:
    """Durable queue of Proposals.

    Persistence: if `path` is provided, every state change (submit, approve,
    reject) appends one JSON line. Rehydration replays the file in order,
    so later lines for a given `proposal_id` overwrite earlier ones -- the
    final state per proposal is whatever the last matching line says.

    Thread safety: the queue itself does not lock. The daemon holds its
    own `_registry_lock`; callers that share an ApprovalQueue across
    threads should arrange equivalent external synchronisation.
    """

    path: Optional[Path] = None
    _proposals: Dict[str, Proposal] = field(default_factory=dict)

    # ── load / construct ───────────────────────────────────────────────────

    @classmethod
    def load(cls, path: Path) -> "ApprovalQueue":
        """Rebuild an ApprovalQueue from a JSON-lines file.

        Missing file -> empty queue bound to that path. Malformed lines
        raise ApprovalQueueError (wrapping RevisionLogError for rehydration
        failures) so audit gaps never go unnoticed.
        """
        queue = cls(path=path)
        if not path.exists():
            return queue
        with path.open("r", encoding="utf-8") as f:
            for lineno, raw in enumerate(f, start=1):
                raw = raw.strip()
                if not raw:
                    continue
                try:
                    d = json.loads(raw)
                except json.JSONDecodeError as exc:
                    raise ApprovalQueueError(
                        f"{path}:{lineno}: malformed JSON line: {exc}"
                    ) from exc
                try:
                    proposal = Proposal.from_dict(d)
                except RevisionLogError as exc:
                    raise ApprovalQueueError(
                        f"{path}:{lineno}: cannot rehydrate invariant: {exc}"
                    ) from exc
                queue._proposals[proposal.proposal_id] = proposal
        return queue

    # ── query ──────────────────────────────────────────────────────────────

    def get(self, proposal_id: str) -> Optional[Proposal]:
        """Return the proposal with `proposal_id` or None if absent."""
        return self._proposals.get(proposal_id)

    def list(
        self, status_filter: Optional[ProposalStatus] = None
    ) -> Tuple[Proposal, ...]:
        """Return a tuple of proposals, optionally filtered by status.

        Sorted by submitted_at ascending then proposal_id for deterministic
        output -- useful in CLI output and tests.
        """
        if status_filter is not None and status_filter not in _STATUSES:
            raise ApprovalQueueError(
                f"status_filter must be one of {_STATUSES}, got {status_filter!r}"
            )
        items: Iterable[Proposal] = self._proposals.values()
        if status_filter is not None:
            items = (p for p in items if p.status == status_filter)
        return tuple(
            sorted(items, key=lambda p: (p.submitted_at, p.proposal_id))
        )

    def __len__(self) -> int:
        return len(self._proposals)

    def __iter__(self) -> Iterator[Proposal]:
        return iter(self.list())

    # ── mutation ───────────────────────────────────────────────────────────

    def submit(
        self,
        submitted_by: str,
        invariants: Iterable[Invariant],
        diff_from_revision: Optional[str] = None,
        now_unix: Optional[int] = None,
        proposal_id: Optional[str] = None,
        actor_id: Optional[str] = None,
    ) -> Proposal:
        """Queue a new pending proposal and persist it.

        Args:
            submitted_by       : agent identifier; must be non-empty.
            invariants         : the invariants to add on approval; must
                                 be a non-empty iterable of Invariant
                                 instances.
            diff_from_revision : optional revision_id for later auditing.
            now_unix           : override the submission timestamp (tests).
            proposal_id        : override the generated id (tests).
            actor_id           : v0.14.0 — governance actor id recorded
                                 on the Proposal for audit. The caller
                                 (daemon) is responsible for gating the
                                 submission via the governance policy
                                 BEFORE calling submit; the queue itself
                                 just records the value.

        Raises:
            ApprovalQueueError on an empty submitter, empty invariant set,
            or a proposal_id collision with an existing entry.
        """
        if not submitted_by or not submitted_by.strip():
            raise ApprovalQueueError("submitted_by must be a non-empty string")
        invariants_t = tuple(invariants)
        if not invariants_t:
            raise ApprovalQueueError("submit requires at least one invariant")
        for inv in invariants_t:
            if not isinstance(inv, Invariant):
                raise ApprovalQueueError(
                    f"submit invariants must be Invariant instances, got {type(inv).__name__}"
                )
        pid = proposal_id if proposal_id is not None else uuid.uuid4().hex
        if pid in self._proposals:
            raise ApprovalQueueError(f"proposal_id collision: {pid!r}")
        ts = int(now_unix) if now_unix is not None else int(time.time())
        proposal = Proposal(
            proposal_id=pid,
            submitted_by=submitted_by,
            submitted_at=ts,
            invariants=invariants_t,
            diff_from_revision=diff_from_revision,
            status=_STATUS_PENDING,
            actor_id=actor_id,
        )
        self._proposals[pid] = proposal
        self._persist(proposal)
        return proposal

    def approve(
        self,
        proposal_id: str,
        reviewer: str,
        reason: Optional[str] = None,
        now_unix: Optional[int] = None,
        allow_same_as_submitter: bool = False,
        min_reviewers: int = 1,
        reviewers_must_differ: bool = True,
    ) -> Proposal:
        """Record a reviewer's approval. Transitions to `approved` once
        the governance policy's reviewer threshold is met.

        v0.14.0 behaviour:

          * A single reviewer with ``min_reviewers=1`` → proposal flips
            to ``approved`` immediately (identical to v0.7.0).
          * ``min_reviewers > 1`` → the first approvals keep the proposal
            ``pending`` and accumulate ReviewerVotes. The proposal flips
            to ``approved`` on the call that satisfies the threshold.
          * ``reviewers_must_differ=True`` dedups by reviewer_id: the
            same reviewer approving twice doesn't advance the counter.

        Args:
            proposal_id             : the proposal to approve.
            reviewer                : reviewer identifier.
            reason                  : optional free-form note.
            now_unix                : override the review timestamp (tests).
            allow_same_as_submitter : opt-in bypass for the default
                                      reviewer-is-not-submitter guard.
            min_reviewers           : number of DISTINCT reviewers needed
                                      for admission (governance axis 2).
            reviewers_must_differ   : when True, a reviewer who has
                                      already approved this proposal gets
                                      rejected instead of silently
                                      counted again.

        Raises:
            ApprovalQueueError if the proposal is unknown, already
            terminal, the reviewer is empty, the reviewer equals
            submitter without opt-in, or (with ``reviewers_must_differ``)
            the reviewer already voted.
        """
        if min_reviewers < 1:
            raise ApprovalQueueError(
                f"min_reviewers must be >= 1, got {min_reviewers}"
            )
        if not reviewer or not reviewer.strip():
            raise ApprovalQueueError("reviewer must be a non-empty string")
        current = self._proposals.get(proposal_id)
        if current is None:
            raise ApprovalQueueError(f"unknown proposal_id: {proposal_id!r}")
        if current.status != _STATUS_PENDING:
            raise ApprovalQueueError(
                f"proposal {proposal_id!r} already {current.status}; "
                f"cannot approve"
            )
        if reviewer == current.submitted_by and not allow_same_as_submitter:
            raise ApprovalQueueError(
                f"two-person integrity: reviewer {reviewer!r} is also the "
                f"submitter; pass allow_same_as_submitter=True to override"
            )
        # Dup-reviewer guard: the governance policy asks for DISTINCT
        # reviewers. Silently ignoring a repeat vote would mislead the
        # operator; we fail loud instead.
        existing_ids = {v.reviewer_id for v in current.reviewers}
        if reviewers_must_differ and reviewer in existing_ids:
            raise ApprovalQueueError(
                f"reviewer {reviewer!r} has already approved "
                f"proposal {proposal_id!r}; reviewers_must_differ=True"
            )
        ts = int(now_unix) if now_unix is not None else int(time.time())
        new_vote = ReviewerVote(
            reviewer_id=reviewer, approved_at_unix=ts, reason=reason,
        )
        accumulated = current.reviewers + (new_vote,)
        # Count DISTINCT approving reviewers for the threshold check.
        distinct_count = len({v.reviewer_id for v in accumulated})
        threshold_met = distinct_count >= min_reviewers
        if threshold_met:
            updated = replace(
                current,
                status=_STATUS_APPROVED,
                reviewed_by=reviewer,
                reviewed_at=ts,
                reason=reason,
                reviewers=accumulated,
            )
        else:
            # Stay pending; just record the vote.
            updated = replace(current, reviewers=accumulated)
        self._proposals[proposal_id] = updated
        self._persist(updated)
        return updated

    def reject(
        self,
        proposal_id: str,
        reviewer: str,
        reason: str,
        now_unix: Optional[int] = None,
        allow_same_as_submitter: bool = False,
    ) -> Proposal:
        """Transition a pending proposal to rejected. `reason` is required."""
        if reason is None or not str(reason).strip():
            raise ApprovalQueueError("reject requires a non-empty reason")
        return self._transition(
            proposal_id=proposal_id,
            reviewer=reviewer,
            reason=reason,
            now_unix=now_unix,
            new_status=_STATUS_REJECTED,
            reason_required=True,
            allow_same_as_submitter=allow_same_as_submitter,
        )

    def _transition(
        self,
        *,
        proposal_id: str,
        reviewer: str,
        reason: Optional[str],
        now_unix: Optional[int],
        new_status: ProposalStatus,
        reason_required: bool,
        allow_same_as_submitter: bool,
    ) -> Proposal:
        if not reviewer or not reviewer.strip():
            raise ApprovalQueueError("reviewer must be a non-empty string")
        current = self._proposals.get(proposal_id)
        if current is None:
            raise ApprovalQueueError(f"unknown proposal_id: {proposal_id!r}")
        if current.status != _STATUS_PENDING:
            raise ApprovalQueueError(
                f"proposal {proposal_id!r} already {current.status}; "
                f"cannot transition to {new_status}"
            )
        if reviewer == current.submitted_by and not allow_same_as_submitter:
            raise ApprovalQueueError(
                f"two-person integrity: reviewer {reviewer!r} is also the "
                f"submitter; pass allow_same_as_submitter=True to override"
            )
        if reason_required and (reason is None or not str(reason).strip()):
            raise ApprovalQueueError(f"{new_status} requires a non-empty reason")
        ts = int(now_unix) if now_unix is not None else int(time.time())
        updated = replace(
            current,
            status=new_status,
            reviewed_by=reviewer,
            reviewed_at=ts,
            reason=reason,
        )
        self._proposals[proposal_id] = updated
        self._persist(updated)
        return updated

    # ── persistence ────────────────────────────────────────────────────────

    def _persist(self, proposal: Proposal) -> None:
        """Append one JSON line for this proposal (if `path` is configured)."""
        if self.path is None:
            return
        self.path.parent.mkdir(parents=True, exist_ok=True)
        line = json.dumps(proposal.to_dict(), sort_keys=True) + "\n"
        with self.path.open("a", encoding="utf-8") as f:
            f.write(line)


# ── helpers ──────────────────────────────────────────────────────────────────


def proposals_to_dicts(
    proposals: Iterable[Proposal],
) -> List[Dict[str, Any]]:
    """Convenience: serialize a sequence of proposals for wire transport."""
    return [p.to_dict() for p in proposals]
