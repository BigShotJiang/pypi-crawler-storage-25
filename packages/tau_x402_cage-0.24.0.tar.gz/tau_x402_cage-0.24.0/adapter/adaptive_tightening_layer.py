"""AdaptiveTighteningLayer — integration seam on top of RuntimeGuard.

Sits BEFORE the existing ``adapter/runtime_guard.py`` cap checks so the
clamped (tightened) limits are enforced as if they were the policy,
without rewriting the policy revision. The baseline guard is untouched
for the non-tightened path: when ``level == 0`` this layer is a no-op.

Separation of concerns:

* ``AdaptiveTightening`` (``adaptive_tightening.py``) owns the
  level-raising, decay, fingerprinting, and `adjusted_limit`
  semantics.
* ``RuntimeGuard`` (``runtime_guard.py``) owns cross-provider
  aggregation, EMA spend rate, retry-density, cooldown enumeration,
  and tightening-level labelling.
* This layer composes the two: it asks the tightening engine for the
  current state, derives adjusted limits against a caller-supplied
  baseline, and answers a single decision: does the adjusted limit
  block an intent that would have passed baseline?

The resulting reason code is ``ADAPTIVE_TIGHTENING_TRIGGERED`` (the
17th decision reason, added in ``decision_schema.py``) so callers can
distinguish adaptive-tightening denials from the existing
``RUNTIME_GUARD_VIOLATION`` category.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from typing import Any, Dict, Mapping, Optional

from adapter.adaptive_tightening import (
    AdaptiveTightening,
    TighteningState,
    estimate_prevented_risk,
)


# ── decision output ──────────────────────────────────────────────────────────


@dataclass(frozen=True)
class AdaptiveTighteningDecision:
    """Frozen decision record from :class:`AdaptiveTighteningLayer`.

    Attributes:
        allowed: True iff the layer permits the intent. Layered-on-top
            of baseline: a baseline-passing intent may still be denied
            here; a baseline-failing intent is never admitted by this
            layer (the caller must also check baseline).
        reason: One of ``"allowed"`` or
            ``"adaptive_tightening_triggered"``.
        tightening_level: Current level in ``[0, 1]``.
        trigger: Most recent trigger name, or ``None``.
        adjusted_limits: Concrete limits currently in force.
        prevented_risk: Populated on deny. ``None`` on allow.
        state: The full :class:`TighteningState` for callers that want
            the raw snapshot.
    """

    allowed: bool
    reason: str
    tightening_level: float
    trigger: Optional[str]
    adjusted_limits: Mapping[str, Any]
    prevented_risk: Optional[Mapping[str, Any]]
    state: TighteningState

    def to_wire(self) -> Dict[str, Any]:
        """JSON-safe projection matching the brief's canonical shape."""
        return {
            "allowed": bool(self.allowed),
            "reason": self.reason,
            "tightening_level": float(self.tightening_level),
            "adjusted_limits": {
                k: (str(v) if isinstance(v, Decimal) else v)
                for k, v in self.adjusted_limits.items()
            },
            "trigger": self.trigger,
            "prevented_risk": (
                dict(self.prevented_risk)
                if self.prevented_risk is not None
                else None
            ),
        }


# ── layer ────────────────────────────────────────────────────────────────────


class AdaptiveTighteningLayer:
    """Runtime-side gate that enforces adaptive clamps ahead of baseline caps.

    The layer is read-only against the tightening engine's state (it
    calls ``current_state`` but never ``observe`` inside ``check``).
    Upstream observers (the daemon's decision loop) feed ``observe``
    on each decision / retry / intent.

    Constructor takes the shared :class:`AdaptiveTightening` instance
    and a human-readable trigger-label map the explainer uses to turn
    internal trigger names into the phrasing in the brief
    ("retry_density" → "retry_density_exceeded", etc.).
    """

    _TRIGGER_LABELS: Mapping[str, str] = {
        "retry_density": "retry_density_exceeded",
        "denial_rate": "denial_rate_exceeded",
        "velocity_spike": "velocity_spike_detected",
        "identical_request": "identical_request_hammering",
    }

    def __init__(self, engine: AdaptiveTightening) -> None:
        self._engine = engine

    @property
    def engine(self) -> AdaptiveTightening:
        return self._engine

    def check(
        self,
        *,
        agent_id: str,
        policy_revision_id: str,
        intent: Mapping[str, Any],
        baseline_limits: Mapping[str, Any],
        baseline_velocity: Decimal | float | int = 0,
        now_unix: int,
        denial_window_seconds: int = 60,
    ) -> AdaptiveTighteningDecision:
        """Evaluate one intent against the adaptive tightening clamp.

        ``baseline_limits`` carries the policy's existing concrete caps
        (e.g. ``{"max_requests": 10, "cooldown_seconds": 30}``). The
        layer derives ``adjusted_limits`` against that baseline and
        applies the adjusted values to the intent. If any adjusted
        value would reject the intent, the layer denies with the
        adaptive-tightening reason.

        The layer is LAYERED: it returns ``allowed=True`` when
        ``level == 0`` and when the adjusted limits still admit the
        intent. It is the caller's responsibility to also run the
        baseline check; this layer never admits an intent the baseline
        would reject.

        Example (retry density deny):
            intent = {"amount": "100", "provider": "x", ..., "attempt_count": 4}
            baseline = {"max_requests": 10, "cooldown_seconds": 30}
            # level climbs to 0.7 after retry flood
            # adjusted = {"max_requests": 3, "cooldown_seconds": 51}
            # 4 attempts > 3 → deny with "adaptive_tightening_triggered"
        """
        state = self._engine.current_state(
            agent_id=agent_id,
            policy_revision_id=policy_revision_id,
            now_unix=now_unix,
            baseline_limits=baseline_limits,
        )
        if state.level <= 0:
            return AdaptiveTighteningDecision(
                allowed=True,
                reason="allowed",
                tightening_level=0.0,
                trigger=None,
                adjusted_limits={},
                prevented_risk=None,
                state=state,
            )

        adjusted = state.adjusted_limits
        # Apply each adjusted limit we recognise to the intent.
        violation_reason = _violates_adjusted_limits(intent, adjusted)
        if violation_reason is None:
            return AdaptiveTighteningDecision(
                allowed=True,
                reason="allowed",
                tightening_level=state.level,
                trigger=state.trigger,
                adjusted_limits=adjusted,
                prevented_risk=None,
                state=state,
            )

        trigger_label = self._TRIGGER_LABELS.get(
            state.trigger or "", state.trigger or "unknown"
        )
        prevented = estimate_prevented_risk(
            baseline_velocity=baseline_velocity,
            current_denial_window_s=denial_window_seconds,
            currency=str(intent.get("currency", "USDC")),
        )
        return AdaptiveTighteningDecision(
            allowed=False,
            reason="adaptive_tightening_triggered",
            tightening_level=state.level,
            trigger=trigger_label,
            adjusted_limits=adjusted,
            prevented_risk=prevented,
            state=state,
        )


# ── limit-violation helpers ─────────────────────────────────────────────────


def _violates_adjusted_limits(
    intent: Mapping[str, Any],
    adjusted: Mapping[str, Any],
) -> Optional[str]:
    """Return the first adjusted-limit key the intent violates, or None.

    The caller's intent carries whichever of the canonical attempt /
    spend fields are relevant:

      * ``attempt_count``: number of attempts this intent represents.
        Compared against ``max_requests`` / ``retry_allowance``.
      * ``amount``: spend for this intent. Compared against
        ``max_amount`` / ``max_per_call`` / ``spend_cap``.
      * ``gap_seconds``: seconds since previous attempt. Compared
        against ``cooldown_seconds`` / ``min_gap_seconds`` — gap must
        be at least as large as the adjusted cooldown.

    A missing intent field is treated as non-violating (we don't make
    up data). A missing adjusted key is ignored (nothing to compare).
    """
    attempt_count = intent.get("attempt_count")
    if attempt_count is not None:
        for key in ("max_requests", "retry_allowance"):
            cap = adjusted.get(key)
            if cap is not None and int(attempt_count) > int(cap):
                return key
    amount_raw = intent.get("amount")
    if amount_raw is not None:
        try:
            amount = Decimal(str(amount_raw))
        except Exception:  # noqa: BLE001 — defensive.
            amount = None
        if amount is not None:
            for key in ("max_amount", "max_per_call", "spend_cap", "cap"):
                cap = adjusted.get(key)
                if cap is None:
                    continue
                try:
                    cap_dec = Decimal(str(cap))
                except Exception:  # noqa: BLE001 — defensive.
                    continue
                if amount > cap_dec:
                    return key
    gap_raw = intent.get("gap_seconds")
    if gap_raw is not None:
        try:
            gap = int(gap_raw)
        except Exception:  # noqa: BLE001 — defensive.
            gap = None
        if gap is not None:
            for key in ("cooldown_seconds", "min_gap_seconds", "backoff_seconds"):
                cooldown = adjusted.get(key)
                if cooldown is None:
                    continue
                try:
                    cooldown_int = int(cooldown)
                except Exception:  # noqa: BLE001 — defensive.
                    continue
                if gap < cooldown_int:
                    return key
    return None


__all__ = [
    "AdaptiveTighteningDecision",
    "AdaptiveTighteningLayer",
]
