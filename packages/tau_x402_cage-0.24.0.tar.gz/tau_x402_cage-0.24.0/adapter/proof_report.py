"""Structured wire reports for admission rejections.

Distinct from `adapter.prover.{Contradiction, InconclusiveProof}`, which are
the INTERNAL prover result types. The dataclasses here are the OUTER WIRE
format returned to daemon clients in the `report` field of a rejection
response. They are:

  * richer           -- parse `Contradiction.left`/`right` into a structured
                        tuple of conflicting-invariant identifiers, and map
                        the free-text `reason` onto a concrete repair hint
                        where we can;
  * JSON-safe        -- ``to_dict()`` returns only primitive types so
                        ``json.dumps`` cannot raise;
  * audit-ready      -- every field is stable across patch versions so log
                        consumers can pattern-match on them.

This module is strictly additive to the wire contract. Clients that only
read the flat ``verdict`` / ``reason`` / ``witness`` / ``backend`` fields
continue to work unchanged; the ``report`` field is an optional richer
payload.

v0.8.0 adds ``PermitWitness`` — the structured wire type for SAT-side
witnesses emitted by fragment-v2 provers (z3). Parallel to the
``ContradictionReport`` family but describing a *permit* example rather
than a conflict.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from typing import Any, Optional


# ── contradiction (UNSAT) reports ────────────────────────────────────────────


@dataclass(frozen=True)
class ContradictionReport:
    """Structured wire report for a prover UNSAT decision.

    Fields:
        conflicting_invariants : Ordered pair of identifiers naming the
            invariants (or spec fragments) whose conjunction is unsat.
            Derived from ``Contradiction.left`` / ``Contradiction.right``;
            always length 2 for the current prover taxonomy but kept as a
            tuple so future N-ary contradictions can extend without a
            breaking schema change.
        unsat_explanation      : Human-readable prose that mirrors
            ``Contradiction.reason``. Safe to surface verbatim in a UI.
        suggested_repair       : Best-effort single-sentence repair hint
            derived from the reason text. ``None`` when no recognized
            pattern matches -- callers must not rely on non-``None`` being
            present.
        backend                : Name of the prover that produced the
            contradiction. Used by auditors to distinguish pattern-prover
            UNSAT from Tau SMT UNSAT.
    """

    conflicting_invariants: tuple[str, ...]
    unsat_explanation: str
    suggested_repair: Optional[str]
    backend: str

    def to_dict(self) -> dict:
        """Return a JSON-safe dict. Stable across patch versions."""
        return {
            "kind": "contradiction",
            "conflicting_invariants": list(self.conflicting_invariants),
            "unsat_explanation": self.unsat_explanation,
            "suggested_repair": self.suggested_repair,
            "backend": self.backend,
        }


# ── inconclusive (neither SAT nor UNSAT) reports ─────────────────────────────


@dataclass(frozen=True)
class InconclusiveReport:
    """Structured wire report for a prover indecision.

    Fields:
        category : Coarse reason class. One of
            ``"timeout" | "unavailable" | "compile_error" |
            "unsupported_fragment" | "parse_error" | "other"``.
            Mirrors ``InconclusiveProof.category`` verbatim.
        reason   : Human-readable explanation suitable for audit logs.
        backend  : Which prover produced the inconclusive result (e.g.
            ``"tau"``).
        details  : Optional structured metadata copied through from
            ``InconclusiveProof.details``. Always a dict on the wire
            (empty when no metadata is available) so consumers can index
            without guarding.
    """

    category: str
    reason: str
    backend: str
    details: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        """Return a JSON-safe dict. Stable across patch versions."""
        return {
            "kind": "inconclusive",
            "category": self.category,
            "reason": self.reason,
            "backend": self.backend,
            "details": dict(self.details),
        }


# ── permit (SAT) witness reports (v0.8.0) ────────────────────────────────────


def _wire_scalar(v: Any) -> Any:
    """Coerce a witness scalar into a JSON-safe primitive.

    ``Decimal`` values become strings (preserving the exact policy-native
    amount); booleans and ints pass through; everything else goes through
    ``str`` as a final safety net.
    """
    if isinstance(v, Decimal):
        return str(v)
    if isinstance(v, bool):
        return v
    if isinstance(v, int):
        return v
    if v is None:
        return None
    if isinstance(v, (list, tuple)):
        return [_wire_scalar(x) for x in v]
    if isinstance(v, dict):
        return {k: _wire_scalar(x) for k, x in v.items()}
    return str(v)


@dataclass(frozen=True)
class PermitWitness:
    """Structured wire report for a concrete SAT witness (v0.8.0).

    Returned alongside a ``ProofToken`` on the SAT path when a fragment-v2
    prover (z3) is the authoritative decision. Answers the operator's
    question "what *does* this policy allow?" with a specific trace of
    per-step amounts / events / reject+retry flags that jointly satisfy
    every invariant.

    Fields:
        unroll_steps   : Bounded-unrolling horizon used by the solver
            (Rule E1 in docs/semantic_fragment_v2.md). The trace is
            exactly this long.
        steps          : One dict per step ``t ∈ [0, unroll_steps)``.
            Every dict has a ``t`` key; optional keys appear only for
            invariant classes that touched the step:
              * ``amount``   (Decimal as str) — SpendingCap-bound amount
              * ``currency`` (str)            — SpendingCap currency
              * ``event``    (bool)           — RollingWindowCap event
              * ``reject``   (bool)           — RetryRateLimit reject
              * ``retry``    (bool)           — RetryRateLimit retry
        per_invariant  : Per-invariant concrete assignment summary for
            richer rendering (CLI tables, audit reports). One dict per
            invariant in the admitted policy, shape depends on
            ``witness_kind``. See
            ``adapter.z3_compiler.extract_witness`` for the full shape.
        backend        : Which fragment-v2 prover produced the witness
            (``"z3"`` or ``"z3-incremental"``).

    The wire form is strictly additive: callers that only render the
    flat ``proof_token`` field keep working unchanged.
    """

    unroll_steps: int
    steps: tuple[dict, ...]
    per_invariant: tuple[dict, ...]
    backend: str

    @classmethod
    def from_witness_dict(
        cls,
        witness: dict,
        *,
        backend: str,
    ) -> "PermitWitness":
        """Build a ``PermitWitness`` from the raw dict produced by
        ``adapter.z3_compiler.extract_witness``.

        Tuple-ifies the lists so the dataclass remains ``frozen=True`` and
        hashable; string-coerces decimals along the way.
        """
        steps = tuple(
            {k: _wire_scalar(v) for k, v in step.items()}
            for step in witness.get("steps", ())
        )
        per_inv = tuple(
            {k: _wire_scalar(v) for k, v in inv.items()}
            for inv in witness.get("per_invariant", ())
        )
        return cls(
            unroll_steps=int(witness.get("unroll_steps", 0)),
            steps=steps,
            per_invariant=per_inv,
            backend=backend,
        )

    def to_dict(self) -> dict:
        """Return a JSON-safe dict. Stable across patch versions."""
        return {
            "kind": "permit_witness",
            "unroll_steps": self.unroll_steps,
            "backend": self.backend,
            "steps": [dict(s) for s in self.steps],
            "per_invariant": [dict(p) for p in self.per_invariant],
        }
