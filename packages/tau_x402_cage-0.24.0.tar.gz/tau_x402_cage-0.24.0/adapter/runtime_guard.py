"""RuntimeGuard: unified cross-provider runtime-signal surface (v0.17.0).

SpendingCap, RetryRateLimit and InstabilityGuard each already expose one
facet of the cage's runtime observability. They do not, today, compose:
the dashboard (and the agent's own planner) has to stitch them together
by hand, and the per-provider analyses never see aggregate cross-provider
burn rates. `RuntimeGuard` is the unified surface the patch spec asks for
under the slogan "I need this if agents can spend money."

Conceptual split:

*   ``adapter/invariants.py`` owns per-payment DECIDE logic -- one intent
    in, verdict out.
*   ``adapter/runtime_guard.py`` (this module) owns aggregate OBSERVE logic
    over the rolling history the daemon already persists in its
    ``HistoryStore``. The guard is read-mostly: it never records new
    events itself; it consumes ``permit`` + ``reject`` streams and
    computes compact runtime signals on demand.

Three unifying moves beyond what the per-invariant checks do today:

1.  **Cross-provider aggregation.** Every EMA / burst / velocity metric
    sums across all providers in the window, not just the provider
    attached to one invariant. Agents burning down a shared USDC pool
    across multiple providers finally see one headline number.

2.  **Forward projection.** ``project_spend(velocity, horizon)`` runs the
    current spend rate forward at a capped horizon (<=300s). The output
    is what *would* be spent without enforcement -- not a prediction of
    what will be spent, an upper bound on the tail of the current burst.

3.  **Self-adjusting tightening levels.** The cage already tightens
    per-provider via ``InstabilityGuard``. We aggregate those per-
    provider active states into a single ``TighteningLevel`` so the
    admission path (and the UI) see one-number "how restricted are we
    right now" instead of a per-provider grid.

Revision-aware by construction: the history store is durable (Redis
backend in v0.8.0) and this module never caches any derived state. A
``policy.update_invariant`` op swaps the registry atomically on the
daemon side; the next call into ``RuntimeGuard`` reads the same history
against the new policy, so thresholds shift on the fly.

Threshold summary (documented here, referenced by TighteningLevel):

*   ``none``     — zero InstabilityGuards active across all providers.
*   ``mild``     — 1 or 2 providers currently tightened.
*   ``moderate`` — 3+ providers currently tightened simultaneously.
*   ``severe``   — any single provider has 5 or more rejects inside its
                   window (set by the InstabilityGuard itself).

See ``docs/runtime_guard.md`` for the full narrative.
"""
from __future__ import annotations

import math
import time
from dataclasses import dataclass, field
from decimal import Decimal
from typing import (
    Any,
    Dict,
    List,
    Literal,
    Mapping,
    Optional,
    Protocol,
    Sequence,
    Tuple,
    runtime_checkable,
)

from adapter.history_store import HistoryStore
from adapter.invariants import Invariant, RetryRateLimit
from adapter.payment_intent_matcher import PaymentIntent
from adapter.self_ref_policy import InstabilityGuard, MergeFailureCooldown


# Canonical upper bound on forward-projection horizons. Beyond this the
# straight EMA extrapolation stops being a defensible upper bound: the
# underlying process is not stationary over multi-minute horizons. We cap
# rather than raise so callers can safely pass ``horizon_seconds=10_000``
# and trust the returned value to stay bounded.
MAX_PROJECTION_HORIZON_SECONDS = 300

# Default windows for the unified API. These mirror the "burst + velocity"
# split the dashboard consumer asked for: short burst for retry-density,
# longer velocity for spend-rate.
DEFAULT_BURST_WINDOW_SECONDS = 10
DEFAULT_VELOCITY_WINDOW_SECONDS = 60
# When a guard is tightening in 3+ places at once we call the aggregate
# state ``moderate``; below that the aggregate is ``mild`` and zero means
# ``none``. A single provider hitting the severe-reject threshold below
# escalates the aggregate straight to ``severe`` regardless of count.
DEFAULT_TIGHTENING_THRESHOLD = 3
SEVERE_REJECT_THRESHOLD = 5

# Tightening-level taxonomy; enumerated as a Literal so typos fail at
# import time and downstream consumers can pattern-match on the string.
TighteningLevelLiteral = Literal["none", "mild", "moderate", "severe"]


# ── cross-revision runtime awareness (v0.21.0) ─────────────────────────────
#
# Agent A (in a sibling worktree) ships ``adapter/adaptive_tightening.py``.
# The real integration point is the ``AdaptiveTightening`` class's
# ``is_tightening_active(agent_id)`` method. Until that branch merges we
# depend only on this Protocol so the cross-revision runtime check can
# be wired and tested in isolation. After agent A merges, callers pass
# the real ``AdaptiveTightening`` instance in place of the stub.


@runtime_checkable
class TighteningStateSource(Protocol):
    """Abstract source of adaptive-tightening state per agent.

    Minimal surface — ``is_tightening_active(agent_id)`` is all the
    cross-revision runtime check needs today. Agent A's
    ``AdaptiveTightening`` class satisfies this Protocol structurally,
    so the wiring in the daemon is a straight swap when the two
    branches merge.

    Implementations MUST be side-effect free: the cross-revision check
    is called on every decision and mutating state would poison the
    audit trail.
    """

    def is_tightening_active(self, agent_id: str) -> bool:
        ...


class _NullTighteningStateSource:
    """Default-off implementation used when agent A hasn't merged yet.

    Always reports "no tightening active" so the cross-revision runtime
    check degrades to a pure revision-id surface (no false positives on
    transition warnings). This matches the brief's requirement: until
    agent A merges, ``limit_relaxation_during_active_tightening`` is
    not surfaced as a transition issue.
    """

    def is_tightening_active(self, agent_id: str) -> bool:
        del agent_id  # unused
        return False


NULL_TIGHTENING_STATE_SOURCE: TighteningStateSource = _NullTighteningStateSource()


# ── result dataclasses (all frozen, all immutable) ──────────────────────────


@dataclass(frozen=True)
class SpendVelocity:
    """Current spend rate + forward projection snapshot.

    Fields:
        rate_per_second: EMA-smoothed spend rate over the window, in the
            queried currency. Zero when the window is empty.
        projected_spend_next_n: keys are horizons in seconds (always
            <= ``MAX_PROJECTION_HORIZON_SECONDS``); values are what
            ``rate_per_second * horizon`` would add. Straight linear
            extrapolation; see ``project_spend`` for the math.
        total_in_window: gross sum of permitted amounts inside the
            window across every provider in the matched currency.
        cross_provider: True iff the total was aggregated across more
            than one provider in the window. Operators care because
            per-provider caps will ALL look fine when the issue is
            really a shared-pool burn problem.
        window_seconds: window the EMA was computed over. Always the
            caller's requested window, never the store's cap. Helpful
            for log lines and dashboard tooltips.
        currency: the currency the velocity was computed for. A caller
            who asked for USDC never gets ETH accidentally mixed in.
    """

    rate_per_second: Decimal
    projected_spend_next_n: Dict[int, Decimal]
    total_in_window: Decimal
    cross_provider: bool
    window_seconds: int
    currency: str

    def to_wire(self) -> Dict[str, Any]:
        """JSON-safe serialisation for daemon response envelopes."""
        return {
            "rate_per_second": str(self.rate_per_second),
            "projected_spend_next_n": {
                str(k): str(v) for k, v in sorted(self.projected_spend_next_n.items())
            },
            "total_in_window": str(self.total_in_window),
            "cross_provider": self.cross_provider,
            "window_seconds": self.window_seconds,
            "currency": self.currency,
        }


@dataclass(frozen=True)
class RetryDensity:
    """How many structurally-identical intents fired inside the burst window.

    The "identity" key is the ``(provider, counterparty, amount, currency)``
    tuple -- same as the key a RetryRateLimit would use. Dashboards
    surface this as "N repeated attempts in M seconds" so operators
    spot runaway agent retry loops before the spend cap fires.

    Fields:
        identical_attempts_in_burst: count of history entries matching
            the query tuple within the last ``burst_window_seconds``.
            Includes both permits and rejects (a retry loop is a retry
            loop either way).
        burst_window_seconds: window the count was taken over.
        density_score: bounded [0, 1] ratio showing how densely the
            attempts were packed. 0 means no attempts, 1 means the
            burst is saturated at >= 1 attempt per second on average.
    """

    identical_attempts_in_burst: int
    burst_window_seconds: int
    density_score: float

    def to_wire(self) -> Dict[str, Any]:
        return {
            "identical_attempts_in_burst": self.identical_attempts_in_burst,
            "burst_window_seconds": self.burst_window_seconds,
            "density_score": self.density_score,
        }


@dataclass(frozen=True)
class CooldownEntry:
    """One active cooldown attributed to a specific source invariant."""

    source: str
    expires_at_unix: int
    reason: str

    def to_wire(self) -> Dict[str, Any]:
        return {
            "source": self.source,
            "expires_at_unix": self.expires_at_unix,
            "reason": self.reason,
        }


@dataclass(frozen=True)
class CooldownState:
    """Aggregate cooldowns across every self-adjusting invariant.

    Field ``active_cooldowns`` is sorted by ``expires_at_unix`` ascending so
    the soonest-to-elapse item is first. Expired entries are pruned before
    return -- callers never see stale state.
    """

    active_cooldowns: Tuple[CooldownEntry, ...]

    def to_wire(self) -> Dict[str, Any]:
        return {
            "active_cooldowns": [e.to_wire() for e in self.active_cooldowns],
        }


@dataclass(frozen=True)
class TighteningLevel:
    """Aggregate tightening level across every InstabilityGuard.

    Exposes the reasoning used to pick the label so the dashboard can
    annotate the level with "why" -- operators should not have to guess
    whether ``moderate`` means "3 providers tightened" or "one provider
    went severe".
    """

    level: TighteningLevelLiteral
    providers_tightening: Tuple[str, ...]
    severe_provider: Optional[str]
    reason: str

    def to_wire(self) -> Dict[str, Any]:
        return {
            "level": self.level,
            "providers_tightening": list(self.providers_tightening),
            "severe_provider": self.severe_provider,
            "reason": self.reason,
        }


# ── the guard ───────────────────────────────────────────────────────────────


class RuntimeGuard:
    """Unified read-only surface over the daemon's runtime history.

    Holds a reference to the daemon's ``HistoryStore`` (never a copy) so
    snapshots are always fresh. Purely computed; no cache. Safe to
    construct cheaply on every call if the daemon prefers, though the
    daemon wires a single instance at startup to match the established
    pattern.

    The ``tightening_threshold`` argument is the number of simultaneously-
    active provider guards above which the aggregate level is labelled
    ``moderate``. Below it the level stays ``mild`` for count >= 1. The
    ``severe`` escalation is independent and triggered by a single
    provider accumulating ``SEVERE_REJECT_THRESHOLD`` rejects inside its
    declared window.
    """

    def __init__(
        self,
        history_store: HistoryStore,
        *,
        burst_window_seconds: int = DEFAULT_BURST_WINDOW_SECONDS,
        velocity_window_seconds: int = DEFAULT_VELOCITY_WINDOW_SECONDS,
        tightening_threshold: int = DEFAULT_TIGHTENING_THRESHOLD,
        merge_cooldown: Optional[MergeFailureCooldown] = None,
    ) -> None:
        if burst_window_seconds <= 0:
            raise ValueError(
                f"burst_window_seconds must be > 0, got {burst_window_seconds}"
            )
        if velocity_window_seconds <= 0:
            raise ValueError(
                f"velocity_window_seconds must be > 0, got {velocity_window_seconds}"
            )
        if tightening_threshold <= 0:
            raise ValueError(
                f"tightening_threshold must be > 0, got {tightening_threshold}"
            )
        self._history_store = history_store
        self._burst_window_seconds = int(burst_window_seconds)
        self._velocity_window_seconds = int(velocity_window_seconds)
        self._tightening_threshold = int(tightening_threshold)
        self._merge_cooldown = merge_cooldown

    # ── properties ──────────────────────────────────────────────────────────

    @property
    def burst_window_seconds(self) -> int:
        return self._burst_window_seconds

    @property
    def velocity_window_seconds(self) -> int:
        return self._velocity_window_seconds

    @property
    def tightening_threshold(self) -> int:
        return self._tightening_threshold

    # ── spend velocity ──────────────────────────────────────────────────────

    def spend_velocity(
        self,
        registry: Any,
        currency: str = "USDC",
        window_seconds: Optional[int] = None,
        now_unix: Optional[int] = None,
    ) -> SpendVelocity:
        """Compute current spend velocity + forward projections.

        ``registry`` is accepted as part of the API surface so future
        revisions can cross-reference active invariants without an API
        break, but the computation here depends only on the permit
        history. Any value (including ``None``) is accepted.

        EMA formula: we divide the sum of in-window amounts by the full
        window length, giving the time-averaged spend rate. This is the
        straightforward moving-average EMA at alpha=1/N; because history
        is bounded by the window cutoff the result is identical to the
        "decayed" EMA without the computational overhead.
        """
        window = int(window_seconds if window_seconds is not None else self._velocity_window_seconds)
        if window <= 0:
            raise ValueError(f"window_seconds must be > 0, got {window}")
        now = int(now_unix if now_unix is not None else time.time())
        cutoff = now - window
        raw = self._history_store.recent_oldest_first("permit")
        permits = [
            p for p in raw
            if isinstance(p, PaymentIntent)
            and p.currency == currency
            and p.timestamp_unix >= cutoff
        ]
        if not permits:
            return SpendVelocity(
                rate_per_second=Decimal("0"),
                projected_spend_next_n={60: Decimal("0"), 300: Decimal("0")},
                total_in_window=Decimal("0"),
                cross_provider=False,
                window_seconds=window,
                currency=currency,
            )
        total = sum((p.amount for p in permits), Decimal("0"))
        # Divide by the full window, not by the span of matched events.
        # A burst of $10 at t=0 followed by nothing for 60s is 10/60
        # per-second, not 10/0.
        rate = total / Decimal(window)
        providers = {p.provider for p in permits}
        cross_provider = len(providers) > 1
        projections = {
            60: self.project_spend(rate, horizon_seconds=60),
            300: self.project_spend(rate, horizon_seconds=300),
        }
        return SpendVelocity(
            rate_per_second=rate,
            projected_spend_next_n=projections,
            total_in_window=total,
            cross_provider=cross_provider,
            window_seconds=window,
            currency=currency,
        )

    def project_spend(
        self,
        current_velocity: Decimal,
        horizon_seconds: int,
    ) -> Decimal:
        """Forward-project spend over the requested horizon.

        Capped at ``MAX_PROJECTION_HORIZON_SECONDS`` (300s). Beyond that
        the straight linear extrapolation stops being a defensible upper
        bound; the cage would rather return a bounded value than a
        hallucinated one. See module docstring.

        ``current_velocity`` is the spend rate (units per second) in
        whatever currency the caller tracked; we never reason about
        currency here so the return unit matches the input.

        Negative velocities (never emitted by ``spend_velocity``) are
        clamped to zero: a "negative burn rate" is either a clock skew
        artifact or a test with a bad fixture, and either way the
        projection should not go negative.
        """
        if horizon_seconds < 0:
            raise ValueError(f"horizon_seconds must be >= 0, got {horizon_seconds}")
        if current_velocity < 0:
            return Decimal("0")
        capped = min(horizon_seconds, MAX_PROJECTION_HORIZON_SECONDS)
        return current_velocity * Decimal(capped)

    # ── retry density ───────────────────────────────────────────────────────

    def retry_density(
        self,
        registry: Any,
        intent_signature: Dict[str, Any],
        now_unix: Optional[int] = None,
    ) -> RetryDensity:
        """Count identical attempts in the burst window.

        ``intent_signature`` must carry ``provider``, ``counterparty``,
        ``amount`` (Decimal or str), and ``currency``. Missing keys
        short-circuit to an empty-density result so malformed queries
        never raise in the hot path (the daemon op surface will surface
        them as 4xx-shaped envelopes instead).

        Both permit and reject streams are scanned: a retry loop that
        hammers the rate limiter is still a retry loop even though the
        attempts never land in the permit stream.
        """
        needed = {"provider", "counterparty", "amount", "currency"}
        if not needed.issubset(intent_signature):
            return RetryDensity(
                identical_attempts_in_burst=0,
                burst_window_seconds=self._burst_window_seconds,
                density_score=0.0,
            )
        try:
            target_amount = Decimal(str(intent_signature["amount"]))
        except Exception:
            return RetryDensity(
                identical_attempts_in_burst=0,
                burst_window_seconds=self._burst_window_seconds,
                density_score=0.0,
            )
        target_provider = str(intent_signature["provider"])
        target_counterparty = str(intent_signature["counterparty"])
        target_currency = str(intent_signature["currency"])
        now = int(now_unix if now_unix is not None else time.time())
        cutoff = now - self._burst_window_seconds
        count = 0
        for kind in ("permit", "reject"):
            for row in self._history_store.recent_oldest_first(kind):
                if not isinstance(row, PaymentIntent):
                    continue
                if row.timestamp_unix < cutoff:
                    continue
                if (
                    row.provider == target_provider
                    and row.counterparty == target_counterparty
                    and row.currency == target_currency
                    and row.amount == target_amount
                ):
                    count += 1
        # Density: attempts per second over the window, clamped to [0, 1].
        # The cap at 1.0 keeps the dashboard gauge from pegging off-scale
        # during a legitimate-but-fast burst; raw count is available for
        # callers who want the un-clamped number.
        density = min(1.0, count / max(1, self._burst_window_seconds))
        return RetryDensity(
            identical_attempts_in_burst=count,
            burst_window_seconds=self._burst_window_seconds,
            density_score=density,
        )

    # ── cooldown state ──────────────────────────────────────────────────────

    def cooldown_state(
        self,
        registry: Any = None,
        now_unix: Optional[int] = None,
    ) -> CooldownState:
        """Aggregate active cooldowns across every cooldown source.

        Three sources contribute:

        *   ``RetryRateLimit`` — for each (provider, counterparty) pair
            with a recent reject inside ``min_gap_seconds``, one entry
            is emitted with source ``"RetryRateLimit"``.
        *   ``InstabilityGuard`` — for each provider whose guard is
            ``active_for(now)``, one entry with source
            ``"InstabilityGuard"``.
        *   ``MergeFailureCooldown`` — when wired on the daemon, each
            active per-branch cooldown emits one entry.

        Sorted by expiry ascending, pruned of expired rows on the way out.
        """
        now = int(now_unix if now_unix is not None else time.time())
        entries: List[CooldownEntry] = []

        rejects = self._pi_stream("reject")
        permits = self._pi_stream("permit")  # noqa: F841 -- future hooks

        if registry is not None:
            invariants = getattr(registry, "invariants", ())
            # RetryRateLimit cooldowns: each (provider, counterparty) pair with
            # a recent reject inside the rate-limit window contributes one
            # entry per matching invariant.
            for inv in invariants:
                if isinstance(inv, RetryRateLimit):
                    entries.extend(
                        self._retry_rate_cooldowns(inv, rejects, now)
                    )
                elif isinstance(inv, InstabilityGuard):
                    entry = self._instability_cooldown(inv, rejects, now)
                    if entry is not None:
                        entries.append(entry)

        if self._merge_cooldown is not None:
            for branch, expiry in self._merge_cooldown.active_cooldowns(now).items():
                entries.append(
                    CooldownEntry(
                        source="MergeFailureCooldown",
                        expires_at_unix=int(expiry),
                        reason=(
                            f"branch {branch!r} in cooldown after merge conflict"
                        ),
                    )
                )

        # Prune any entries that already elapsed (belt-and-suspenders —
        # the cooldown sources above already pre-filter) and sort by
        # expiry ascending so the soonest-elapse row is first.
        alive = tuple(
            sorted(
                (e for e in entries if e.expires_at_unix > now),
                key=lambda e: e.expires_at_unix,
            )
        )
        return CooldownState(active_cooldowns=alive)

    # ── tightening level ────────────────────────────────────────────────────

    def tightening_level(
        self,
        registry: Any,
        now_unix: Optional[int] = None,
    ) -> TighteningLevel:
        """Aggregate tightening state across every InstabilityGuard.

        Level rules (in priority order):

        1. If any provider has ``SEVERE_REJECT_THRESHOLD`` or more
           rejects inside its declared window, the level is ``severe``.
           The offending provider is named.
        2. Else if the count of simultaneously-active tightening
           providers is >= ``tightening_threshold``, the level is
           ``moderate``.
        3. Else if the count is >= 1, the level is ``mild``.
        4. Else ``none``.

        Providers counted must correspond to actual ``InstabilityGuard``
        invariants on the registry. An ``InstabilityGuard`` for a
        provider with no recent rejects is not "tightening".
        """
        now = int(now_unix if now_unix is not None else time.time())
        rejects = self._pi_stream("reject")
        guards: List[InstabilityGuard] = []
        if registry is not None:
            for inv in getattr(registry, "invariants", ()):
                if isinstance(inv, InstabilityGuard):
                    guards.append(inv)

        # Detect severe first so a single hot provider always wins.
        severe_provider: Optional[str] = None
        for g in guards:
            window_cutoff = now - g.window_seconds
            count = sum(
                1 for r in rejects
                if r.provider == g.provider and r.timestamp_unix >= window_cutoff
            )
            if count >= SEVERE_REJECT_THRESHOLD:
                severe_provider = g.provider
                break

        tightening_providers: List[str] = []
        for g in guards:
            if g.active_for(rejects, now) and g.provider not in tightening_providers:
                tightening_providers.append(g.provider)

        if severe_provider is not None:
            return TighteningLevel(
                level="severe",
                providers_tightening=tuple(tightening_providers),
                severe_provider=severe_provider,
                reason=(
                    f"{severe_provider} accumulated "
                    f">= {SEVERE_REJECT_THRESHOLD} rejects inside its window"
                ),
            )
        count = len(tightening_providers)
        if count >= self._tightening_threshold:
            return TighteningLevel(
                level="moderate",
                providers_tightening=tuple(tightening_providers),
                severe_provider=None,
                reason=(
                    f"{count} providers tightening simultaneously "
                    f"(threshold={self._tightening_threshold})"
                ),
            )
        if count >= 1:
            return TighteningLevel(
                level="mild",
                providers_tightening=tuple(tightening_providers),
                severe_provider=None,
                reason=f"{count} provider(s) tightening",
            )
        return TighteningLevel(
            level="none",
            providers_tightening=(),
            severe_provider=None,
            reason="no tightening active",
        )

    # ── aggregated snapshot ─────────────────────────────────────────────────

    def runtime_state(
        self,
        registry: Any,
        currency: str = "USDC",
        now_unix: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Compound view combining every signal into one wire payload.

        Used by the ``runtime_state`` daemon op; the UI panel consumes
        this to render a single dashboard tile with every signal stacked.
        """
        velocity = self.spend_velocity(
            registry, currency=currency, now_unix=now_unix
        )
        density_sig = self._top_identical_signature(now_unix=now_unix)
        density = (
            self.retry_density(registry, density_sig, now_unix=now_unix)
            if density_sig is not None
            else RetryDensity(
                identical_attempts_in_burst=0,
                burst_window_seconds=self._burst_window_seconds,
                density_score=0.0,
            )
        )
        cooldowns = self.cooldown_state(registry, now_unix=now_unix)
        level = self.tightening_level(registry, now_unix=now_unix)
        top = self._top_velocity_providers(currency=currency, now_unix=now_unix)
        return {
            "spend_velocity": velocity.to_wire(),
            "retry_density": density.to_wire(),
            "cooldown_state": cooldowns.to_wire(),
            "tightening_level": level.to_wire(),
            "top_velocity_providers": [
                {"provider": p, "total": str(t)} for p, t in top
            ],
            "active_cooldowns_count": len(cooldowns.active_cooldowns),
        }

    # ── helpers ─────────────────────────────────────────────────────────────

    def _pi_stream(self, kind: str) -> Tuple[PaymentIntent, ...]:
        """Return the PaymentIntent rows of the named stream.

        The store mixes PaymentIntent and verdict-summary dicts in the
        same list; this helper keeps the two apart so downstream code
        never has to repeat the isinstance check.
        """
        return tuple(
            r for r in self._history_store.recent_oldest_first(kind)
            if isinstance(r, PaymentIntent)
        )

    def _retry_rate_cooldowns(
        self,
        inv: RetryRateLimit,
        rejects: Sequence[PaymentIntent],
        now: int,
    ) -> List[CooldownEntry]:
        """Emit one cooldown entry per (provider, counterparty) with active back-off."""
        out: List[CooldownEntry] = []
        seen: Dict[Tuple[str, str], int] = {}
        for r in rejects:
            if (now - r.timestamp_unix) >= inv.min_gap_seconds:
                continue
            key = (r.provider, r.counterparty)
            existing = seen.get(key)
            if existing is None or r.timestamp_unix > existing:
                seen[key] = r.timestamp_unix
        for (provider, counterparty), last_ts in seen.items():
            expiry = last_ts + inv.min_gap_seconds
            if expiry <= now:
                continue
            out.append(
                CooldownEntry(
                    source="RetryRateLimit",
                    expires_at_unix=expiry,
                    reason=(
                        f"retry rate-limit for {provider}/{counterparty} "
                        f"(min_gap={inv.min_gap_seconds}s)"
                    ),
                )
            )
        return out

    def _instability_cooldown(
        self,
        inv: InstabilityGuard,
        rejects: Sequence[PaymentIntent],
        now: int,
    ) -> Optional[CooldownEntry]:
        """Return the cooldown entry for an InstabilityGuard, if active."""
        if not inv.active_for(rejects, now):
            return None
        window_cutoff = now - inv.window_seconds
        last_reject_ts = max(
            (
                r.timestamp_unix for r in rejects
                if r.provider == inv.provider
                and r.timestamp_unix >= window_cutoff
            ),
            default=now,
        )
        expiry = last_reject_ts + inv.recovery_seconds
        if expiry <= now:
            return None
        return CooldownEntry(
            source="InstabilityGuard",
            expires_at_unix=int(expiry),
            reason=(
                f"tightened to {inv.tighten_to} {inv.currency} for "
                f"{inv.provider} after repeated rejects"
            ),
        )

    def _top_velocity_providers(
        self,
        currency: str,
        now_unix: Optional[int] = None,
        limit: int = 3,
    ) -> Tuple[Tuple[str, Decimal], ...]:
        """Return the top-N providers by in-window spend.

        Used by ``runtime_state`` so the dashboard can say "you're
        burning through provider X" without a second query.
        """
        now = int(now_unix if now_unix is not None else time.time())
        cutoff = now - self._velocity_window_seconds
        totals: Dict[str, Decimal] = {}
        for p in self._pi_stream("permit"):
            if p.currency != currency:
                continue
            if p.timestamp_unix < cutoff:
                continue
            totals[p.provider] = totals.get(p.provider, Decimal("0")) + p.amount
        ordered = sorted(totals.items(), key=lambda kv: kv[1], reverse=True)
        return tuple(ordered[:limit])

    def _top_identical_signature(
        self,
        now_unix: Optional[int] = None,
    ) -> Optional[Dict[str, Any]]:
        """Find the most-hit (provider, counterparty, amount, currency) in the burst window.

        ``runtime_state`` asks for a single retry-density reading, so we
        surface the signature that would trigger the highest count
        today. Ties break toward the first key seen in insertion order
        (dict ordering preserves that on >=3.7).
        """
        now = int(now_unix if now_unix is not None else time.time())
        cutoff = now - self._burst_window_seconds
        counts: Dict[Tuple[str, str, str, str], int] = {}
        for kind in ("permit", "reject"):
            for row in self._pi_stream(kind):
                if row.timestamp_unix < cutoff:
                    continue
                key = (row.provider, row.counterparty, str(row.amount), row.currency)
                counts[key] = counts.get(key, 0) + 1
        if not counts:
            return None
        best_key, _ = max(counts.items(), key=lambda kv: kv[1])
        provider, counterparty, amount, currency = best_key
        return {
            "provider": provider,
            "counterparty": counterparty,
            "amount": amount,
            "currency": currency,
        }


__all__ = [
    "CooldownEntry",
    "CooldownState",
    "DEFAULT_BURST_WINDOW_SECONDS",
    "DEFAULT_TIGHTENING_THRESHOLD",
    "DEFAULT_VELOCITY_WINDOW_SECONDS",
    "MAX_PROJECTION_HORIZON_SECONDS",
    "RetryDensity",
    "RuntimeGuard",
    "SEVERE_REJECT_THRESHOLD",
    "SpendVelocity",
    "TighteningLevel",
]
