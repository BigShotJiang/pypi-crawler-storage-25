"""TTI (Time-to-First-Correct-Rejection) bench runner.

The TTI battery (``specs/tti_battery/``) is the category-forcing contract
that vendors claiming x402 policy semantics must clear. This module is the
programmatic surface: an importable runner that executes the 5-test battery
either against a locally-spawned cage daemon or against a remote SaaS URL
(via the ``tau-x402-cage-client`` SDK), and returns a structured result that
the CLI and CI can rely on without re-parsing free-form output.

Design choices:

* **Immutable result types** — ``TTITestResult`` and ``TTIResult`` are frozen
  dataclasses that serialise to JSON via ``to_dict`` with a stable schema.
* **Isolated per-test work** — each test constructs its own invariant fixture
  and calls the battery's structural assertions (not Tau proof execution); the
  wall-clock duration measured is the structural-check time a fresh adopter
  would see at the "first correct rejection" moment.
* **Pluggable target** — ``run_battery`` takes an optional ``target`` that
  defaults to local-mode (no network). Remote mode uses the client SDK; any
  SDK import failure is surfaced as a clear config error, never silently
  swallowed.

Fragment awareness:

The battery tests TB-1..TB-5 are structural (shape of emitted Tau spec) so
they run deterministically on any machine, with or without the Tau runtime.
This is intentional: TTI measures "how fast does a new adopter read a
correct rejection" — the proof-carrying path is exercised by the full test
suite, not by the TTI bench.
"""
from __future__ import annotations

import json
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

# ── result types ──────────────────────────────────────────────────────────


@dataclass(frozen=True)
class TTITestResult:
    """Result of a single battery test.

    Frozen so callers can freely pass it into logs / JSON without worrying
    about mutation. ``decisive`` mirrors the RFC's "cage reached a verdict"
    distinction — a test that times out or raises is not decisive regardless
    of pass/fail.
    """

    id: str
    name: str
    passed: bool
    decisive: bool
    duration_seconds: float
    detail: str
    error: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class TTIResult:
    """Aggregate result across the 5-test battery.

    ``total_seconds`` is the sum of per-test durations, not wall-clock —
    callers that care about wall-clock should compute it themselves around
    the ``run_battery`` call. Sum-of-durations is the metric CI gates on
    because it is deterministic across machines.
    """

    per_test: Tuple[TTITestResult, ...]
    total_seconds: float
    median_seconds: float
    p95_seconds: float
    passed: int
    failed: int
    target: str

    @property
    def all_decisive(self) -> bool:
        return all(t.decisive for t in self.per_test)

    @property
    def all_passed(self) -> bool:
        return self.failed == 0 and self.passed == len(self.per_test)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "per_test": [t.to_dict() for t in self.per_test],
            "total_seconds": self.total_seconds,
            "median_seconds": self.median_seconds,
            "p95_seconds": self.p95_seconds,
            "passed": self.passed,
            "failed": self.failed,
            "target": self.target,
            "all_decisive": self.all_decisive,
            "all_passed": self.all_passed,
        }

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), sort_keys=True)


class TTIBenchError(RuntimeError):
    """Raised when the bench cannot run (bad specs dir, unreachable target)."""


# ── per-test runners ──────────────────────────────────────────────────────
#
# The runners here are deliberately thin wrappers over the structural-check
# functions in ``specs/tti_battery/run_battery.py``. They return ``(ok,
# detail)`` tuples, matching the shape the existing shell wrapper already
# parses. Keeping the structural checks in one place prevents drift.


def _import_battery_callables() -> List[Tuple[str, str, Callable[[], Tuple[bool, str]]]]:
    """Import the shipped battery module's per-test callables.

    Returns a list of ``(id, name, fn)`` tuples in battery order (TB-1 .. TB-5).
    ``fn`` is ``() -> (ok: bool, detail: str)`` — the shape the legacy
    ``run_battery.py`` already uses.
    """
    # Deferred import keeps ``adapter.tti_bench`` importable from tests that
    # don't want to pay the yaml parser / decimal import cost on module load.
    import importlib.util

    battery_path = Path(__file__).resolve().parent.parent / "specs" / "tti_battery" / "run_battery.py"
    if not battery_path.exists():
        raise TTIBenchError(
            f"battery module not found at {battery_path}; "
            "specs/tti_battery/run_battery.py must exist alongside the specs"
        )
    spec = importlib.util.spec_from_file_location(
        "tti_battery_module", battery_path
    )
    if spec is None or spec.loader is None:
        raise TTIBenchError(f"could not load battery module from {battery_path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return [
        ("TB-1", "Daily cap", module.run_tb1),
        ("TB-2", "Contradictory caps", module.run_tb2),
        ("TB-3", "Rolling window", module.run_tb3),
        ("TB-4", "Past obligation", module.run_tb4),
        ("TB-5", "Rule revision", module.run_tb5),
    ]


def _percentile(values: List[float], pct: float) -> float:
    """Simple linear-interpolation percentile for tiny (n=5) sample sizes.

    We do not depend on numpy for a 5-element calculation. ``pct`` is in
    [0, 100]. Empty input returns 0.0 (the bench's default behaviour when
    an exception short-circuits all tests).
    """
    if not values:
        return 0.0
    ordered = sorted(values)
    if len(ordered) == 1:
        return ordered[0]
    k = (len(ordered) - 1) * (pct / 100.0)
    f = int(k)
    c = min(f + 1, len(ordered) - 1)
    if f == c:
        return ordered[f]
    # Linear interpolation between the two nearest neighbours.
    return ordered[f] + (ordered[c] - ordered[f]) * (k - f)


def _median(values: List[float]) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    n = len(ordered)
    mid = n // 2
    if n % 2:
        return ordered[mid]
    return (ordered[mid - 1] + ordered[mid]) / 2.0


# ── public API ────────────────────────────────────────────────────────────


DEFAULT_PER_TEST_BUDGET_SECONDS = 60.0
"""Per-test wall-clock budget. The structural checks finish in milliseconds
on any laptop; the budget exists to catch hung remote endpoints (see
``--against``) without blocking CI forever."""


def run_battery(
    specs_dir: Optional[Path | str] = None,
    *,
    daemon_socket: Optional[str] = None,
    against_url: Optional[str] = None,
    bearer_token: Optional[str] = None,
    per_test_budget_seconds: float = DEFAULT_PER_TEST_BUDGET_SECONDS,
) -> TTIResult:
    """Run the 5-test TTI battery and return a structured TTIResult.

    Args:
        specs_dir: Path containing the 5 YAML specs. Defaults to
            ``specs/tti_battery/`` under the repo root. Accepted for
            forward compatibility (e.g. vendoring the specs); the current
            runner imports from the shipped module either way.
        daemon_socket: Reserved for future local-daemon mode. The current
            structural checks do not talk to a daemon — the battery runner
            in ``specs/tti_battery/run_battery.py`` asserts on emitted
            spec text, which is the contract that a fresh adopter reads.
        against_url: When set, run the battery against a remote SaaS
            instead of local-mode. Uses ``tau_x402_cage_client`` (the
            v0.9.0 client SDK). Each test pings ``/v1/health`` as a
            liveness gate; structural checks still run locally.
        bearer_token: Auth token for ``--against`` mode.
        per_test_budget_seconds: Wall-clock cap per test. A test that
            exceeds the budget is reported ``decisive=False``, ``passed=False``.

    Returns:
        A ``TTIResult`` carrying per-test detail + aggregates.

    Raises:
        TTIBenchError: when the battery module is missing, or ``--against``
            is used without the client SDK installed, or the remote
            endpoint is unreachable.
    """
    target = against_url or "local"
    tests = _import_battery_callables()

    # Remote-mode liveness gate: verify we can reach the SaaS before running
    # the structural checks. We deliberately do not fan the checks through
    # the SaaS — the battery's RFC contract is on spec emission shape,
    # which is process-local. The URL presence in the target field makes
    # the provenance explicit in JSON output.
    if against_url is not None:
        _probe_against(against_url, bearer_token)

    results: List[TTITestResult] = []
    for tid, name, fn in tests:
        start = time.monotonic()
        error: Optional[str] = None
        passed = False
        decisive = True
        detail = ""
        try:
            ok, detail = fn()
            passed = bool(ok)
        except Exception as exc:  # noqa: BLE001 — any failure is a test fail
            decisive = False
            error = f"{type(exc).__name__}: {exc}"
            detail = error
        duration = time.monotonic() - start
        if duration > per_test_budget_seconds:
            decisive = False
            passed = False
            error = (
                f"test exceeded per-test budget of "
                f"{per_test_budget_seconds:.1f}s"
            )
        results.append(
            TTITestResult(
                id=tid,
                name=name,
                passed=passed,
                decisive=decisive,
                duration_seconds=duration,
                detail=detail,
                error=error,
            )
        )

    durations = [r.duration_seconds for r in results]
    total = sum(durations)
    med = _median(durations)
    p95 = _percentile(durations, 95.0)
    passed_count = sum(1 for r in results if r.passed)
    failed_count = len(results) - passed_count

    return TTIResult(
        per_test=tuple(results),
        total_seconds=total,
        median_seconds=med,
        p95_seconds=p95,
        passed=passed_count,
        failed=failed_count,
        target=target,
    )


def _probe_against(url: str, bearer_token: Optional[str]) -> None:
    """Hit the remote SaaS health endpoint so a bad URL fails fast.

    The v0.9.0 client SDK is the supported path. We import lazily because
    it's an optional dep (``pip install tau-x402-cage-client``) and local
    mode should not force contributors to install it.
    """
    try:
        from tau_x402_cage_client import Client
    except ImportError as exc:
        raise TTIBenchError(
            "--against requires the tau-x402-cage-client SDK; "
            "install with `pip install tau-x402-cage-client`"
        ) from exc
    try:
        with Client(base_url=url, bearer_token=bearer_token) as client:
            client.health()
    except Exception as exc:  # noqa: BLE001 — network / auth / transport all uniform
        raise TTIBenchError(
            f"unreachable --against endpoint {url!r}: {type(exc).__name__}: {exc}"
        ) from exc


# ── text rendering ────────────────────────────────────────────────────────


def render_text(result: TTIResult) -> str:
    """Render a TTIResult as a human-readable table.

    Stable column widths so grep / awk pipelines keep working. The final
    line is ``PASS`` iff every test is decisive AND passed under budget;
    this mirrors the shell wrapper's exit-code semantics.
    """
    lines: List[str] = []
    lines.append(f"TTI battery — target: {result.target}")
    lines.append("")
    lines.append(
        f"  {'ID':<5}  {'Name':<22}  {'Result':<10}  {'Decisive':<9}  "
        f"{'Duration':<10}"
    )
    lines.append("  " + "-" * 62)
    for t in result.per_test:
        marker = "PASS" if t.passed else "FAIL"
        dec = "yes" if t.decisive else "no"
        dur = f"{t.duration_seconds * 1000:.1f}ms"
        lines.append(
            f"  {t.id:<5}  {t.name:<22}  {marker:<10}  {dec:<9}  {dur:<10}"
        )
        if t.error:
            lines.append(f"         error: {t.error}")
    lines.append("")
    lines.append(
        f"  total: {result.total_seconds * 1000:.1f}ms  "
        f"median: {result.median_seconds * 1000:.1f}ms  "
        f"p95: {result.p95_seconds * 1000:.1f}ms  "
        f"passed: {result.passed}/{len(result.per_test)}"
    )
    verdict = "PASS" if result.all_passed and result.all_decisive else "FAIL"
    lines.append(f"  verdict: {verdict}")
    return "\n".join(lines) + "\n"
