"""Guaranteed Language tier for v0.20.0 (Deliverable 1).

The cage's **Flexible Mode** (shipped through v0.18.0) accepts the full
8-invariant taxonomy, hybrid SAT dispatch across Tau + z3 + Python pattern
prover, bounded unrolling, and three modes of proof strength. That is the
right tier for developers integrating an x402 agent today.

**Guaranteed Mode** is the narrower tier a bank's evaluator can stress.
It publishes exactly which rule types, composition operators, temporal
constructs and mutation forms are decidable *under proof, without
fallback, with no hidden bounding*. Anything outside that surface is
rejected at declare time with
:data:`adapter.guaranteed_errors.GuaranteedFailureCode.UNSUPPORTED_FOR_GUARANTEED_MODE`.
No downgrade. No hybrid assist. No partial acceptance.

Version discipline
------------------

The public ``GUARANTEED_LANGUAGE_VERSION`` semver is bumped whenever the
tier's surface changes. Major bump for a removal or semantics shift;
minor for additive expansion; patch for wording / doc corrections that
leave the surface identical. Every
:class:`adapter.guaranteed_totality.TotalityReport` and
:class:`adapter.guaranteed_errors.GuaranteedFailure` carries this
version string; downstream auditors should treat results stamped with
different versions as non-fungible.

v1.0.0 -> v1.1.0 transition
---------------------------

v1.0.0 shipped the three pure-Tau rule types that were provably total on
the un-patched upstream ``ltl`` branch: ``SpendingCap`` (``per_tx`` scope
only), ``MaxPerCall``, and ``ProviderAllowlist``. v1.1.0 widens the
surface on the presumption that upstream Tau has merged the three
outstanding patches that were pending in ``docs/upstream-fix-*.patch``:

* Bug 1 — ``solve_ltl_aba`` pair-consistency over-rejection fix.
* Bug 3 — past-LTL ``O`` / ``H`` operators first-class in the grammar.
* Bug 4 — ``&`` at wff level aliases ``&&``.

With those three patches the tier admits ``RetryRateLimit``,
``RollingWindowCap``, ``BurstVelocityCap``, the two windowed
``SpendingCap`` scopes, the past-LTL ``O`` / ``H`` modalities, and the
three windowed-tightening mutation forms.

v1.1.0 -> v1.2.0 transition
---------------------------

v1.2.0 expands the tier from 6 to 9 rule types by admitting three enum /
composition shapes that encode cleanly in pure ``bv`` BA without any
``nlang`` dependency, z3 fallback, or Python-semantics helper:

* ``JurisdictionRule`` (``enum_bv`` variant) — when declared with NO
  ``additional_invariants`` the rule becomes a flat allow-list over a
  fixed finite ``JurisdictionCode`` enumeration. Each code is hashed to
  a stable ``bv[16]`` slot at compile time. The richer nested-composition
  variant stays in Flexible Mode pending upstream ``nlang``.
* ``CounterpartyConstraint`` (``enum_bv`` variant) — when declared with a
  non-empty ``approved_ids`` AND an empty ``sanctioned_ids`` the rule is
  a pure counterparty allowlist, identical in shape to
  ``ProviderAllowlist``. The richer sanctions-negation / ``nlang``-valued
  variants stay in Flexible Mode. A mutation that GROWS the allowlist is
  a weakening move and is rejected in Guaranteed Mode because
  ``widen_allowlist`` is not in ``SUPPORTED_MUTATION_FORMS``.
* ``MutualExclusion`` (``rule_composition`` variant) — admits the
  existing two-group shape. The encoding is
  ``G(¬((group_a_member) ∧ (group_b_member)))`` which composes the two
  enum-bv predicates via Tau's conjunction / negation. No new BA, no
  inner-quantifier alternation.

All three variants emit closed ``bv``-BA bodies through
:func:`adapter.tau_compiler.dry_run_encode`. The tier therefore stays
under the same totality discipline: no ``nlang`` type bindings, no z3
sentinel, no unbounded pattern fallback.

Still excluded from v1.2.0:

* ``JurisdictionRule`` with nested ``additional_invariants`` — nested
  implication composition over potentially unbounded inner-rule depth.
  Held for a later tier.
* ``CounterpartyConstraint`` with non-empty ``sanctioned_ids`` — the
  inequality conjunction encodes cleanly in fragment v1 ``_sat_body`` but
  the intended ``nlang``-backed richer encoding is still pending upstream
  (``docs/tau-lang-bug-report-v2.md`` Bug 2). Keep Guaranteed Mode
  conservative — only the pure allowlist variant crosses the tier line.
* The ``nlang``-valued variants of Jurisdiction / Counterparty.

Contract for other agents
-------------------------

::

    from adapter.guaranteed_language import (
        GUARANTEED_LANGUAGE_VERSION,
        GuaranteedLanguage,
    )
    ok, code = GuaranteedLanguage.is_supported(invariant)
    if not ok:
        # reject with UNSUPPORTED_FOR_GUARANTEED_MODE
        ...
    surface = GuaranteedLanguage.describe()  # JSON-serializable dict
"""

from __future__ import annotations

from typing import Any, Optional, Tuple

from adapter.guaranteed_errors import GuaranteedFailureCode
from adapter.invariants import (
    BurstVelocityCap,
    CounterpartyConstraint,
    Invariant,
    JurisdictionRule,
    MaxPerCall,
    MutualExclusion,
    ProviderAllowlist,
    RetryRateLimit,
    RollingWindowCap,
    SpendingCap,
)

__all__ = [
    "GUARANTEED_LANGUAGE_VERSION",
    "GuaranteedLanguage",
    "assert_pure_bv_policy",
    "PureBvAssertionError",
]


#: Public semver for the Guaranteed Language tier. Bumped whenever the
#: class-level ``SUPPORTED_*`` sets change. Downstream audit records
#: pin on this.
#:
#: v1.1.0 (prior) added three rule types, two windowed scopes, two
#: past-LTL operators, and three mutation forms relative to v1.0.0.
#:
#: v1.2.0 (this release) combines TWO additive changes from parallel
#: agents:
#:   * Widens ``SUPPORTED_RULE_TYPES`` with three enum / composition
#:     rule types: ``JurisdictionRule``, ``CounterpartyConstraint``,
#:     ``MutualExclusion`` — all admitted via pure ``bv`` BA (no nlang
#:     dependency, no z3 fallback). New ``SUPPORTED_RULE_VARIANTS``
#:     classmap tags their admitted variants.
#:   * Introduces ``SUPPORTED_META_POLICIES`` for admitted meta-policies
#:     (``AdaptiveTighteningPolicy``, ``PeerAuthenticationPolicy``).
#:     Meta-policies flow through a distinct admission pipeline at
#:     ``adapter/meta_policy.py``.
#: No new temporal ops; no new mutation forms.
GUARANTEED_LANGUAGE_VERSION: str = "1.2.0"


class GuaranteedLanguage:
    """Static description of the Guaranteed-Mode language surface.

    Every member is a ``frozenset`` so callers cannot mutate the tier
    by assignment. The class is not meant to be instantiated; all
    methods are classmethods.

    If you are an agent working on ``adapter/guaranteed_prover.py`` or
    ``adapter/guaranteed_runtime.py``, do NOT widen these sets. Open a
    separate branch, bump :data:`GUARANTEED_LANGUAGE_VERSION`, and add
    regression tests before the class ships anything new.
    """

    # ── language surface ────────────────────────────────────────────

    #: Rule types admitted in Guaranteed Mode. Encoded as stable class
    #: names so the set round-trips through JSON audit export without
    #: pulling the invariant classes into the auditor's environment.
    #:
    #: v1.1.0 expansion: Retry/RollingWindow/BurstVelocity all become
    #: admissible once upstream Tau ships the pair-consistency fix plus
    #: past-LTL ``O`` / ``H`` grammar plus ``&`` chain alias.
    #:
    #: v1.2.0 expansion: ``JurisdictionRule``, ``CounterpartyConstraint``
    #: and ``MutualExclusion`` admit in their pure ``bv`` BA variants.
    #: See :attr:`SUPPORTED_RULE_VARIANTS` for exactly which shape of each
    #: class is admitted — the richer nested / sanctions / ``nlang``
    #: variants stay in Flexible Mode.
    SUPPORTED_RULE_TYPES: frozenset = frozenset(
        {
            "SpendingCap",  # per_tx, per_window, per_provider_per_window
            "MaxPerCall",
            "ProviderAllowlist",
            # Added in v1.1.0: depend on the three upstream Tau patches.
            "RetryRateLimit",
            "RollingWindowCap",
            "BurstVelocityCap",
            # Added in v1.2.0: pure ``bv`` BA enum / composition variants.
            # Variant-level admission is gated by SUPPORTED_RULE_VARIANTS.
            "JurisdictionRule",
            "CounterpartyConstraint",
            "MutualExclusion",
        }
    )

    #: Per-rule-class *variant* admission table (v1.2.0).
    #:
    #: Several invariant classes expose multiple shapes on the same
    #: constructor: e.g. ``CounterpartyConstraint`` admits a pure
    #: allowlist (``approved_ids`` non-empty, ``sanctioned_ids`` empty)
    #: and a sanctions-negation variant; ``JurisdictionRule`` admits a
    #: flat jurisdiction assertion and a nested-implication variant that
    #: threads ``additional_invariants``. Only the enum_bv / composition
    #: variants encode cleanly in pure ``bv`` BA without ``nlang`` or z3
    #: assistance, so Guaranteed Mode admits those alone.
    #:
    #: Shape: ``{rule_class_name: tuple[variant_tag, ...]}``. A rule
    #: class whose name is NOT in this dict admits every constructor-valid
    #: instance (classical pre-v1.2.0 behaviour). A rule class whose name
    #: IS in this dict must match at least one of the listed variant tags
    #: via :meth:`_classify_variant`; otherwise ``is_supported`` rejects
    #: with ``UNSUPPORTED_FOR_GUARANTEED_MODE``.
    #:
    #: Downstream audit exporters render this table through
    #: :meth:`describe` so evaluators see exactly which shape was
    #: admitted.
    SUPPORTED_RULE_VARIANTS: dict = {
        "JurisdictionRule": ("enum_bv",),
        "CounterpartyConstraint": ("enum_bv",),
        "MutualExclusion": ("rule_composition",),
    }

    #: Specific scope / shape restrictions per rule type. ``None`` means
    #: any scope the rule type defines is admitted; a tuple enumerates
    #: the allowed scopes. v1.1.0 widens ``SpendingCap`` to every scope
    #: it exposes (the windowed ones become provable once past-LTL and
    #: pair-consistency patches land).
    SUPPORTED_SCOPES: dict = {
        "SpendingCap": (
            "per_tx",
            "per_window",
            "per_provider_per_window",
        ),
        # MaxPerCall / ProviderAllowlist / RetryRateLimit /
        # RollingWindowCap / BurstVelocityCap have no ``scope`` parameter
        # on their constructor (window/group_by carry the windowing
        # signal); absence from this dict means "any constructor-valid
        # instance is admitted".
    }

    #: Composition operators admitted between rules. v1.1.0 still admits
    #: only conjunction (AND-of-rules). Disjunction, implication, nested
    #: temporal, and quantifier alternation remain in Flexible Mode.
    SUPPORTED_COMPOSITION: frozenset = frozenset({"conjunction"})

    #: Temporal constructs admitted. v1.0.0 was empty; v1.1.0 admits
    #: ``G`` (always), ``O`` (once — past existence), ``H`` (historically —
    #: past universality). These are exactly the modalities the three new
    #: rule types need, and which the upstream Tau patches make decidable.
    SUPPORTED_TEMPORAL: frozenset = frozenset({"G", "O", "H"})

    #: Mutation / revision forms admitted.
    #:
    #: * ``add_invariant`` — strictly tightens.
    #: * ``remove_invariant`` — governed by the mutation-safety rules
    #:   the governance agent owns; the LANGUAGE merely admits the
    #:   shape.
    #: * ``tighten_limit`` — e.g. lowering ``MaxPerCall.max_amount``
    #:   or ``SpendingCap.max_amount``.
    #: * ``tighten_window`` — lengthening a windowed cap's
    #:   ``window_seconds`` (longer window = more history contributes to
    #:   the aggregate = strictly stricter aggregate enforcement).
    #: * ``shorten_retry_cooldown`` — misnomer-adjacent but intentional:
    #:   in ``RetryRateLimit`` a LARGER ``min_gap_seconds`` is stricter,
    #:   but we keep the verb-first form consistent with "shorten the
    #:   window during which retries are permitted" — see tests for the
    #:   exact mapping.
    #: * ``tighten_burst_cap`` — lowering ``BurstVelocityCap.max_per_window``
    #:   or ``RollingWindowCap.max_count``.
    #:
    #: ``loosen_limit`` and ``replace_invariant`` (which can hide an
    #: add+remove pair) are still excluded.
    SUPPORTED_MUTATION_FORMS: frozenset = frozenset(
        {
            "add_invariant",
            "remove_invariant",
            "tighten_limit",
            "tighten_window",
            "shorten_retry_cooldown",
            "tighten_burst_cap",
        }
    )

    # ── v1.2.0 META-POLICY SURFACE (agent γ) ───────────────────────
    #
    # Meta-policies are policies about how the cage ITSELF behaves.
    # They ride a separate admission pipeline (``adapter/meta_policy.py``)
    # from regular payment-rule invariants, so they live in a dedicated
    # ``SUPPORTED_META_POLICIES`` frozenset. Widening this set requires
    # a language version bump just like widening ``SUPPORTED_RULE_TYPES``;
    # audit pipelines pin on both.
    #
    # v1.2.0 admits:
    #   * AdaptiveTighteningPolicy — tightening thresholds, per-trigger
    #     deltas, half_life as policy fields. Admitted under three
    #     properties: monotone non-weakening, decay monotonicity, and
    #     single-observation bound.
    #   * PeerAuthenticationPolicy — allowed_peer_uids, allowed_actor_claims,
    #     allowed_signing_keys. Admitted under non-empty-peer-set and
    #     claim-channel-coherence properties. Adding uids is weakening
    #     (requires approval); removing uids is tightening.
    SUPPORTED_META_POLICIES: frozenset = frozenset(
        {
            "AdaptiveTighteningPolicy",
            "PeerAuthenticationPolicy",
        }
    )
    # ── END v1.2.0 META-POLICY SURFACE ─────────────────────────────

    # ── public API ──────────────────────────────────────────────────

    @classmethod
    def is_supported(
        cls, invariant: Invariant
    ) -> Tuple[bool, Optional[GuaranteedFailureCode]]:
        """Return ``(ok, reason_code_if_not)`` for a single invariant.

        Fail-closed: any unknown type, invalid scope, or missing class
        name yields ``(False, UNSUPPORTED_FOR_GUARANTEED_MODE)``. The
        tuple shape is the stable contract; callers should NOT try to
        distinguish sub-reasons from the second element.

        The totality gate (``adapter.guaranteed_totality``) uses this
        to short-circuit before any prover is invoked.

        v1.2.0: meta-policies (``AdaptiveTighteningPolicy`` /
        ``PeerAuthenticationPolicy``) are ALSO admitted here, via a
        separate :attr:`SUPPORTED_META_POLICIES` set. The language tier
        admits the *type*; the ``admit_meta_policies`` pipeline in
        ``adapter/meta_policy.py`` decides the admission *properties*.
        """
        if not isinstance(invariant, Invariant):
            return False, GuaranteedFailureCode.UNSUPPORTED_FOR_GUARANTEED_MODE
        class_name = type(invariant).__name__
        if class_name in cls.SUPPORTED_META_POLICIES:
            # Meta-policy types pass the language-tier check; property
            # admission runs in adapter/meta_policy.py.
            return True, None
        if class_name not in cls.SUPPORTED_RULE_TYPES:
            return False, GuaranteedFailureCode.UNSUPPORTED_FOR_GUARANTEED_MODE
        # Scope-level restriction check (legacy; SpendingCap only today).
        scope_tuple = cls.SUPPORTED_SCOPES.get(class_name)
        if scope_tuple is not None:
            scope = cls._extract_scope(invariant)
            if scope is None or scope not in scope_tuple:
                return (
                    False,
                    GuaranteedFailureCode.UNSUPPORTED_FOR_GUARANTEED_MODE,
                )
        # Variant-level restriction check (v1.2.0). Classes in
        # SUPPORTED_RULE_VARIANTS must match one of the listed variant
        # tags; classes not in the dict admit every constructor-valid
        # instance.
        variant_tuple = cls.SUPPORTED_RULE_VARIANTS.get(class_name)
        if variant_tuple is not None:
            variant_tag = cls._classify_variant(invariant)
            if variant_tag is None or variant_tag not in variant_tuple:
                return (
                    False,
                    GuaranteedFailureCode.UNSUPPORTED_FOR_GUARANTEED_MODE,
                )
        return True, None

    @classmethod
    def is_meta_policy_supported(cls, class_name: str) -> bool:
        """Return True iff ``class_name`` is an admitted meta-policy type.

        Useful for the daemon and audit tooling to route per-type checks
        without introspecting an instance.
        """
        return class_name in cls.SUPPORTED_META_POLICIES

    @classmethod
    def is_composition_supported(cls, composition_op: str) -> bool:
        """Return True iff ``composition_op`` is in the admitted set.

        Composition ops are lowercase strings (``"conjunction"``,
        ``"disjunction"``, ``"implication"``, etc.). The totality gate
        calls this; the prover agent should as well.
        """
        return composition_op in cls.SUPPORTED_COMPOSITION

    @classmethod
    def is_temporal_supported(cls, temporal_op: str) -> bool:
        """Return True iff a temporal op is admitted.

        v1.1.0 admits ``G``, ``O`` and ``H``. Future / binary modalities
        (``F``, ``X``, ``U``, ``W``) still return False.
        """
        return temporal_op in cls.SUPPORTED_TEMPORAL

    @classmethod
    def is_mutation_form_supported(cls, mutation_form: str) -> bool:
        """Return True iff ``mutation_form`` is an admitted revision shape."""
        return mutation_form in cls.SUPPORTED_MUTATION_FORMS

    @classmethod
    def describe(cls) -> dict:
        """JSON-serializable snapshot of the entire tier surface.

        Downstream uses:
        * audit-export pipelines embed this in policy bundles so the
          evaluator sees what language was in force at admit time;
        * the MCP server exposes this as a resource so agents can
          query "what am I allowed to do in Guaranteed Mode?";
        * regression tests pin on the dict to detect silent expansion.

        The returned value is fresh each call (no aliasing) so mutation
        by a caller does not leak back.
        """
        return {
            "schema": "tau-x402-cage.guaranteed-language.v1",
            "language_version": GUARANTEED_LANGUAGE_VERSION,
            "supported_rule_types": sorted(cls.SUPPORTED_RULE_TYPES),
            "supported_rule_variants": {
                # Convert tuples to lists so the output is JSON-native.
                k: list(v) for k, v in sorted(cls.SUPPORTED_RULE_VARIANTS.items())
            },
            "supported_scopes": {
                # Convert tuples to lists so the output is JSON-native.
                k: list(v) for k, v in sorted(cls.SUPPORTED_SCOPES.items())
            },
            "supported_composition": sorted(cls.SUPPORTED_COMPOSITION),
            "supported_temporal": sorted(cls.SUPPORTED_TEMPORAL),
            "supported_mutation_forms": sorted(cls.SUPPORTED_MUTATION_FORMS),
            # v1.2.0: meta-policy surface. Separate from rule types so
            # audit pipelines can filter on it explicitly.
            "supported_meta_policies": sorted(cls.SUPPORTED_META_POLICIES),
            "excluded_rule_types_with_reason": dict(_EXCLUDED_RULES_REASON),
        }

    # ── helpers ─────────────────────────────────────────────────────

    @staticmethod
    def _extract_scope(invariant: Invariant) -> Optional[str]:
        """Pull the scope-like discriminator off an invariant instance.

        Currently only ``SpendingCap`` has a ``scope`` attribute; other
        supported rules return ``None`` (which callers ignore).
        """
        if isinstance(invariant, SpendingCap):
            return invariant.scope
        # Defensive: every other admitted rule type has no scope attr.
        # Absence from SUPPORTED_SCOPES means "no scope check"; returning
        # None here is purely a safety net for that caller path.
        if isinstance(
            invariant,
            (
                MaxPerCall,
                ProviderAllowlist,
                RetryRateLimit,
                RollingWindowCap,
                BurstVelocityCap,
                JurisdictionRule,
                CounterpartyConstraint,
                MutualExclusion,
            ),
        ):
            return None
        return None

    @staticmethod
    def _classify_variant(invariant: Invariant) -> Optional[str]:
        """Classify the variant of a v1.2.0 multi-shape invariant.

        Returns one of the variant tags listed in
        :attr:`SUPPORTED_RULE_VARIANTS` when the instance matches the
        pure ``bv`` BA shape; ``None`` otherwise (caller rejects). The
        classification is intentionally conservative: any deviation from
        the exact enum / composition pattern falls off the Guaranteed
        path.

        Current variant tags:

        * ``"enum_bv"`` for ``JurisdictionRule`` — matches iff
          ``additional_invariants`` is empty. The nested-implication
          variant (``additional_invariants != ()``) is a richer
          composition held for a later tier.
        * ``"enum_bv"`` for ``CounterpartyConstraint`` — matches iff
          ``approved_ids`` is non-empty AND ``sanctioned_ids`` is empty.
          The sanctions-negation variant and the eventual ``nlang``
          variant are both held for a later tier.
        * ``"rule_composition"`` for ``MutualExclusion`` — matches iff
          both groups are non-empty (constructor guarantees it). The
          encoding ``G(!(group_a_member & group_b_member))`` composes two
          enum-bv predicates via Tau's conjunction / negation.
        """
        if isinstance(invariant, JurisdictionRule):
            # enum_bv: a flat jurisdiction assertion, no nested
            # additional_invariants. Empty tuple matches the ``T`` body
            # the Flexible encoding falls back to.
            if not invariant.additional_invariants:
                return "enum_bv"
            return None
        if isinstance(invariant, CounterpartyConstraint):
            # enum_bv: pure allowlist shape, no sanctions-negation.
            if invariant.approved_ids and not invariant.sanctioned_ids:
                return "enum_bv"
            return None
        if isinstance(invariant, MutualExclusion):
            # rule_composition: the two-group shape the dataclass
            # enforces at construction time. Both groups non-empty is
            # a dataclass invariant.
            if invariant.group_a and invariant.group_b:
                return "rule_composition"
            return None
        return None


# ── documentation data (kept out of the class to avoid clutter) ────────

#: Why each non-admitted rule *variant* is excluded from v1.2.0. Surfaces
#: through ``GuaranteedLanguage.describe()`` so evaluators see the
#: exclusion reasoning without leaving the audit bundle.
#:
#: v1.2.0 moved the enum-bv variants of ``JurisdictionRule``,
#: ``CounterpartyConstraint`` and ``MutualExclusion`` into the tier. The
#: richer ``nlang`` / nested-composition variants of the same classes
#: stay out, tracked with variant-qualified keys so downstream audit
#: readers can tell "class excluded outright" apart from "one variant
#: admitted, another still held".
_EXCLUDED_RULES_REASON: dict = {
    "JurisdictionRule.nested_composition": (
        "The nested-implication variant (non-empty additional_invariants)"
        " composes inner invariants of arbitrary depth. v1.2.0 admits the"
        " flat enum_bv variant only; the nested composition waits on a"
        " first-class composed-body encoding in a later tier."
    ),
    "JurisdictionRule.nlang": (
        "Natural-language jurisdiction predicates still pending upstream"
        " nlang BA parser fix (docs/tau-lang-bug-report-v2.md Bug 2)."
    ),
    "CounterpartyConstraint.sanctions_negation": (
        "Mixed approved + sanctioned variant encodes cleanly in fragment"
        " v1 _sat_body but the intended nlang-backed richer encoding is"
        " still pending upstream. Guaranteed Mode admits the pure"
        " allowlist variant (approved_ids non-empty, sanctioned_ids"
        " empty) only."
    ),
    "CounterpartyConstraint.nlang": (
        "Natural-language counterparty predicates still pending upstream"
        " nlang BA parser fix (docs/tau-lang-bug-report-v2.md Bug 2)."
    ),
}


# ── purity assertion for v1.2.0 Guaranteed admission ───────────────────


class PureBvAssertionError(ValueError):
    """Raised when a policy compiled for Guaranteed Mode contains a
    construct outside the pure ``bv`` BA surface the tier promises.

    Carries the offending substring (``detail``) so audit pipelines can
    render a specific reason without having to re-scan the compiled
    source.
    """

    def __init__(self, message: str, detail: str = "") -> None:
        super().__init__(message)
        self.detail = detail


# Sentinels that would only appear in a non-Guaranteed compilation path.
# ``:nlang`` is the upstream natural-language BA type tag; fragment-v2 /
# z3 compiled sources never reach the Guaranteed prover but an audit
# evaluator still wants a defensive check that a mis-routed policy
# doesn't slip through. The list is intentionally narrow — more
# sentinels can be added without churning callers because the helper
# only scans and reports.
_FORBIDDEN_SENTINELS: tuple[str, ...] = (
    ":nlang",
    "{<",  # nlang literal opener, e.g. `{<hello>}:nlang`
    # z3 / fragment-v2 compiled forms use SMT-LIB style declarations
    # which don't appear in Tau bodies; if they ever do it's a routing
    # bug and the admission must fail closed.
    "(declare-fun",
    "(assert ",
)


def assert_pure_bv_policy(tau_source: str) -> None:
    """Raise :class:`PureBvAssertionError` when ``tau_source`` carries
    any construct outside the pure ``bv`` BA Guaranteed Mode promises.

    Specifically scans for:

    * ``:nlang`` type tags (``docs/tau-lang-bug-report-v2.md`` Bug 2 —
      out of scope for Guaranteed Mode until the upstream parser is
      fixed and a dedicated nlang tier ships).
    * Fragment-v2 / z3 SMT-LIB sentinels — policies compiled via
      ``adapter.z3_compiler`` never route to the Guaranteed prover, but
      a mis-routed admission would slip through silently without this
      check. Fail-closed.

    The helper is intentionally cheap: a handful of substring scans
    over the compiled body. It runs per-admission so overhead stays
    negligible. Callers that already filter upstream (e.g. the
    ``GuaranteedProver`` totality gate) can still run this as a final
    defensive check.

    Empty / None input is treated as a programming error:
    ``GuaranteedProver`` never calls this with missing compiled source.
    """
    if not isinstance(tau_source, str):
        raise PureBvAssertionError(
            "assert_pure_bv_policy requires a compiled tau_source string",
            detail=f"got {type(tau_source).__name__}",
        )
    if not tau_source.strip():
        raise PureBvAssertionError(
            "Guaranteed Mode requires a non-empty compiled body",
            detail="empty tau_source",
        )
    for sentinel in _FORBIDDEN_SENTINELS:
        if sentinel in tau_source:
            raise PureBvAssertionError(
                "Guaranteed Mode admits pure bv BA only; found forbidden"
                f" construct {sentinel!r} in compiled source",
                detail=sentinel,
            )
