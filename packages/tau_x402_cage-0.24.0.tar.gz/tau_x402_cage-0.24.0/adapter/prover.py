"""Consistency prover: the core of pointwise revision.

Every declare / retract goes through a `ConsistencyProver`. The prover answers
one question: "is the proposed new rule set mutually consistent?"

If yes, it returns a `ProofToken` that binds (config_hash, backend, nonce,
proof_strength) -- the token becomes part of the audit trail. If no, it
returns a `Contradiction` naming the pair (or spec) that conflicts.

Three backends are provided. The pattern prover is a cheap PRECHECK that runs
first in every strong-backend call; in `verified` and `strict` modes the
authoritative decisions come from Tau (fragment v1) or z3 (fragment v2).
Selection is per-daemon; the default is PythonPatternProver so a clean
`pip install tau-x402-cage` has zero runtime dependencies. Operators opt
into a stronger backend via the `CAGE_PROVER` environment variable or by
passing `prover=...` to CageDaemon().

    PythonPatternProver           (default; zero deps; proof_strength="pattern")
        Precheck that catches the common operational conflicts by
        pattern-matching invariant pairs. Not a complete logical prover;
        does NOT prove semantic consistency in the general case. In
        `verified` and `strict` modes it runs first and short-circuits on
        obvious contradictions before the authoritative backend is asked.
        See `_detect_conflict` for the currently-recognized patterns.

    TauConsistencyProver          (authoritative for fragment v1;
                                   proof_strength="complete" on a Tau decision,
                                   else falls through with
                                   proof_strength="pattern+tau-inconclusive" or
                                   "pattern+tau-unavailable")
        Invokes the Tau Language CLI's `sat` REPL on the composed fragment-v1
        spec. When Tau reaches a decision (sat or unsat) inside the
        configured timeout, the token records proof_strength="complete".
        When Tau times out, errors, or is unavailable, the prover delegates
        to PythonPatternProver and labels the result accordingly so auditors
        can see which revisions got full consistency checking and which
        fell back. Tau's published Python binding does not yet surface the
        `sat` decision procedure for non-temporal specs, so we shell out to
        the CLI; the adapter interface is stable and the swap to a native
        binding is drop-in when upstream exposes it.

    Z3ConsistencyProver           (authoritative for fragment v2; requires the
                                   `fragment-v2` extra; proof_strength="complete"
                                   on sat/unsat, InconclusiveProof on timeout)
        Decides the temporal-arithmetic fragment (SpendingCap per_window,
        RollingWindowCap, RetryRateLimit) via z3 with bounded unrolling.
        See docs/semantic_fragment_v2.md.

The adapter interface is stable across backends. Swapping proves:
    cage = CageDaemon(socket_path=...)                       # pattern
    cage = CageDaemon(socket_path=..., prover=TauConsistencyProver())  # fragment v1
    cage = CageDaemon(socket_path=..., prover=Z3ConsistencyProver())   # fragment v2
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import secrets
import shutil
import subprocess
import threading
import time
from dataclasses import dataclass, field
from decimal import Decimal
from typing import Iterable, Optional, Protocol, Sequence, Tuple

from adapter.invariants import (
    CounterpartyConstraint,
    Invariant,
    MaxPerCall,
    ProviderAllowlist,
    SpendingCap,
    compose,
)
from adapter.tau_compiler import (
    CompileError,
    CompiledTauPolicy,
    UnsupportedInvariantError,
    compile_policy,
)

logger = logging.getLogger(__name__)


# Per-instance cache for TauConsistencyProver.version_string. Keyed by
# ``id(instance)`` so we never mutate the frozen dataclass. Entries are
# small (one string each), so we accept the modest leak on the instance's
# lifetime; CPython's id is unique while the object is alive.
_TAU_VERSION_CACHE: dict[int, str] = {}


# ── witness helpers ──────────────────────────────────────────────────────────


def _witness_to_wire(witness: Optional[dict]) -> Optional[dict]:
    """Convert a witness dict (may contain ``Decimal``) to JSON-safe primitives.

    Witnesses from ``adapter.z3_compiler.extract_witness`` contain
    ``Decimal`` values for amounts so the caller can compare with
    invariant bounds without FP error. This helper stringifies those
    decimals so ``json.dumps`` can serialise the token without a custom
    encoder, while leaving ints/bools/None untouched.
    """
    if witness is None:
        return None

    def _coerce(v):
        if isinstance(v, Decimal):
            return str(v)
        if isinstance(v, dict):
            return {k: _coerce(sub) for k, sub in v.items()}
        if isinstance(v, (list, tuple)):
            return [_coerce(sub) for sub in v]
        return v

    return _coerce(witness)


# ── result types ─────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class ProofToken:
    """A proof that a rule set was verified consistent at a point in time.

    Fields:
        config_hash         : SHA-256 of the canonical invariant-set representation.
        issued_at_unix      : epoch seconds at token issuance.
        backend             : prover backend name ("python-pattern", "tau",
                              "chained:tau->pattern", etc.).
        proof_strength      : what kind of check produced the token:
            * "pattern"                    : pairwise pattern check only.
            * "complete"                   : Tau SMT reached a decision.
            * "pattern+tau-inconclusive"   : Tau couldn't decide; pattern passed.
            * "pattern+tau-unavailable"    : Tau binary missing; pattern passed.
        nonce               : random hex so repeat-proof-of-same-config still
                              produces unique tokens.
        predecessor_hash    : config_hash of the preceding revision, forming
                              an append-only chain.
        prover_mode         : "compat" | "verified" | "strict". Records the
                              daemon mode under which this proof was issued
                              so auditors can filter by admission policy.
        fragment_version    : which semantic fragment the Tau compiler targeted
                              ("v1", or None if Tau was not invoked).
        compile_hash        : SHA-256 of the Tau source fed to the prover
                              (None for pattern-only proofs).
        tau_backend_version : version string of the Tau runtime used, when
                              reachable (None for pattern-only or when the
                              binary's --version was not probed).
        witness             : v0.8.0 — concrete SAT witness produced by a
                              z3 backend on fragment v2. ``None`` for
                              UNSAT paths, non-z3 backends, and tokens
                              produced before a model was available.
                              Shape documented in
                              ``adapter.z3_compiler.extract_witness``.
    """

    config_hash: str
    issued_at_unix: int
    backend: str
    proof_strength: str
    nonce: str
    predecessor_hash: Optional[str] = None
    # Patch-1 provenance fields (v0.3.3+):
    prover_mode: Optional[str] = None
    fragment_version: Optional[str] = None
    compile_hash: Optional[str] = None
    tau_backend_version: Optional[str] = None
    # v0.8.0: optional SAT witness for fragment-v2 backends. Structured
    # dict carrying an `unroll_steps`-long trace that satisfies every
    # invariant in the policy. Kept optional for backward compat: every
    # pre-v0.8.0 token construction site omits it and deserialisers that
    # don't know about this field ignore it.
    witness: Optional[dict] = None

    def to_dict(self) -> dict:
        return {
            "config_hash": self.config_hash,
            "issued_at_unix": self.issued_at_unix,
            "backend": self.backend,
            "proof_strength": self.proof_strength,
            "nonce": self.nonce,
            "predecessor_hash": self.predecessor_hash,
            "prover_mode": self.prover_mode,
            "fragment_version": self.fragment_version,
            "compile_hash": self.compile_hash,
            "tau_backend_version": self.tau_backend_version,
            "witness": _witness_to_wire(self.witness),
        }


@dataclass(frozen=True)
class Contradiction:
    """Proof of UNSAT. Names the conflicting part and explains why in prose."""

    left: str
    right: str
    reason: str
    backend: str

    def to_dict(self) -> dict:
        return {
            "left": self.left,
            "right": self.right,
            "reason": self.reason,
            "backend": self.backend,
        }


@dataclass(frozen=True)
class InconclusiveProof:
    """A decisive-enough-to-record failure to prove.

    Distinct from Contradiction (which asserts UNSAT). An InconclusiveProof says
    the prover neither reached SAT nor UNSAT. Daemon admission treats these
    differently per prover_mode:

        compat   -> ignored; pattern prover's result is authoritative
        verified -> policy admitted with downgraded proof_strength
        strict   -> policy REJECTED (no silent admission)

    Fields:
        category : one of "timeout" | "unavailable" | "compile_error" |
                   "unsupported_fragment" | "parse_error" | "other".
        reason   : human-readable explanation for the audit log.
        backend  : which prover produced the inconclusive result.
        details  : optional structured metadata (timeout budget, binary path,
                   offending invariant class, etc.).
    """

    category: str
    reason: str
    backend: str
    details: Optional[dict] = None

    def to_dict(self) -> dict:
        return {
            "category": self.category,
            "reason": self.reason,
            "backend": self.backend,
            "details": self.details,
        }


# Type alias for the decisive/indecisive triple that every prover may return.
ProofResult = "ProofToken | Contradiction | InconclusiveProof"


# ── prover protocol ──────────────────────────────────────────────────────────


class ConsistencyProver(Protocol):
    """Any backend that can decide whether a rule set is mutually consistent."""

    backend: str

    def prove(
        self,
        invariants: Sequence[Invariant],
        predecessor_hash: Optional[str] = None,
    ) -> ProofToken | Contradiction: ...


# ── backend 1: Python pattern-based prover (default) ─────────────────────────


@dataclass(frozen=True)
class PythonPatternProver:
    """Pattern-based prover covering the operational conflicts most likely to
    matter in practice.

    Detects:
      C1. ProviderAllowlist ∩ CounterpartyConstraint.approved = ∅
          (with both sets non-empty). The conjunction has no model: nothing
          can ever satisfy both.
      C2. Two MaxPerCall rules with the same currency: the stricter one
          strictly dominates. Not a contradiction per se, but we flag when
          the loosest is strictly unreachable so operators can remove dead rules.
          (Emits Contradiction with reason "redundant_dominated" to surface it.)
      C3. Sanctioned counterparty that is also explicitly approved by a
          separate CounterpartyConstraint. Construction-time check exists,
          but cross-rule check catches split declarations.
      C4. ProviderAllowlist = ∅ after intersection with any
          CounterpartyConstraint-allowed provider set (catches multi-rule
          allowlist narrowing to nothing).
      C5. SpendingCap per_tx and MaxPerCall on same currency, with per_tx
          cap > MaxPerCall.max_amount: MaxPerCall would always fire first,
          SpendingCap's per_tx rule is dead.

    Not a complete logical prover. Issues ProofToken with
    proof_strength="pattern".
    """

    backend: str = "python-pattern"

    def prove(
        self,
        invariants: Sequence[Invariant],
        predecessor_hash: Optional[str] = None,
    ) -> ProofToken | Contradiction:
        invs = tuple(invariants)
        for i, left in enumerate(invs):
            for right in invs[i + 1:]:
                c = _detect_conflict(left, right, self.backend)
                if c is not None:
                    return c
        # Multi-rule (N-ary) checks beyond pairwise
        multi = _detect_multi_rule_conflict(invs, self.backend)
        if multi is not None:
            return multi
        config_hash = _hash_invariants(invs)
        return ProofToken(
            config_hash=config_hash,
            issued_at_unix=int(time.time()),
            backend=self.backend,
            proof_strength="pattern",
            nonce=secrets.token_hex(8),
            predecessor_hash=predecessor_hash,
        )


def _detect_conflict(left: Invariant, right: Invariant, backend: str) -> Optional[Contradiction]:
    """Return a Contradiction if (left, right) is provably unsat or pathological.

    BUGFIX (v0.3.3): prior versions flagged disjoint `ProviderAllowlist.providers`
    vs `CounterpartyConstraint.approved_ids` as a contradiction. That was
    semantically wrong: provider and counterparty are independent intent fields.
    An intent with provider="anthropic" and counterparty="vendor_a" satisfies
    both independently regardless of set disjointness. Removed.
    """

    # C3: cross-rule sanctioned/approved overlap
    if isinstance(left, CounterpartyConstraint) and isinstance(right, CounterpartyConstraint):
        overlap = (left.approved_ids & right.sanctioned_ids) | (
            right.approved_ids & left.sanctioned_ids
        )
        if overlap:
            return Contradiction(
                left=f"CounterpartyConstraint(approved={sorted(left.approved_ids)}, sanctioned={sorted(left.sanctioned_ids)})",
                right=f"CounterpartyConstraint(approved={sorted(right.approved_ids)}, sanctioned={sorted(right.sanctioned_ids)})",
                reason=(
                    f"Counterparty IDs appear as approved in one rule and "
                    f"sanctioned in another: {sorted(overlap)}. No intent can "
                    f"satisfy both."
                ),
                backend=backend,
            )

    # C2 / C5: dead-rule dominance -- same currency, one strictly dominates
    if (
        isinstance(left, MaxPerCall) and isinstance(right, MaxPerCall)
        and left.currency == right.currency
        and left.max_amount != right.max_amount
    ):
        tighter = min(left.max_amount, right.max_amount)
        looser = max(left.max_amount, right.max_amount)
        # Looser cap is literally unreachable; log but don't block.
        # (Uncomment the return below to enforce strict dead-code rejection.)
        logger.debug(
            "MaxPerCall dominance: tighter=%s, looser=%s (%s). "
            "The looser rule is dead code; retain only the tighter.",
            tighter, looser, left.currency,
        )

    return None


def _detect_multi_rule_conflict(
    invs: Sequence[Invariant], backend: str
) -> Optional[Contradiction]:
    """N-ary checks that can't be reduced to pairwise inspection."""
    # Collect all CounterpartyConstraint.approved sets and ProviderAllowlists.
    allowlists = [i.providers for i in invs if isinstance(i, ProviderAllowlist)]
    approved_sets = [
        i.approved_ids for i in invs
        if isinstance(i, CounterpartyConstraint) and i.approved_ids
    ]
    # If we have multiple allowlists, their intersection must be non-empty
    # (otherwise no provider is universally approved).
    if len(allowlists) > 1:
        common = set(allowlists[0])
        for a in allowlists[1:]:
            common &= a
        if not common:
            return Contradiction(
                left="ProviderAllowlist (multi)",
                right="ProviderAllowlist (multi)",
                reason=(
                    f"{len(allowlists)} ProviderAllowlist rules declared with "
                    "empty pairwise intersection; no provider satisfies all."
                ),
                backend=backend,
            )
    return None


# ── backend 2: Tau Language SMT prover (authoritative for fragment v1) ───────


class TauUnavailable(RuntimeError):
    """Raised when the Tau runtime is not usable in the current environment."""


@dataclass(frozen=True)
class TauConsistencyProver:
    """Authoritative consistency prover for fragment v1 (shipped).

    Invokes the Tau Language CLI's `sat` REPL on the composed fragment-v1
    spec. The fragment v1 admission path is the product surface users hit
    in `verified` and `strict` daemon modes - it is not aspirational.

    Semantics:
      * On a decisive Tau result within `timeout_seconds`, emits a ProofToken
        with proof_strength="complete".
      * On Tau timeout, unparseable spec, or Tau binary unavailable, falls
        through to PythonPatternProver and emits a token with
        proof_strength="pattern+tau-inconclusive" and backend
        "chained:tau->pattern". Operators filter audit logs by proof_strength
        when they need hard "complete" guarantees.

    Why CLI and not the Python binding? The published Tau Python binding
    exposes runtime interpretation (streams, steps) but does not surface the
    `sat` decision procedure for non-temporal specs. Until that lands, we
    shell out to the Tau CLI. The adapter interface is stable across
    backends, so the swap to a native binding is drop-in when upstream
    exposes it.

    Configuration:
      * env `TAU_BINARY`        : path to the Tau CLI (defaults to "tau" on PATH)
      * env `TAU_DYLD_PATH`     : DYLD_LIBRARY_PATH for Tau's cvc5 (macOS)
      * constructor `timeout_seconds` (default 10): hard wall-clock cap per proof
    """

    backend: str = "tau"
    timeout_seconds: float = 10.0
    fallback: ConsistencyProver = field(default_factory=PythonPatternProver)

    @staticmethod
    def is_available() -> bool:
        """Return True iff a Tau CLI is locatable in the current environment."""
        binary = os.environ.get("TAU_BINARY") or shutil.which("tau")
        return binary is not None and os.path.isfile(binary)

    @property
    def version_string(self) -> str:
        """Probe the Tau CLI for its version string (one-shot, best effort).

        Returns the first non-empty line of ``tau --version`` output, or
        the sentinel string ``"unknown"`` when the binary is missing or
        the probe errors for any reason. Cached per-instance so the
        subprocess cost is paid once. This property is read by
        Guaranteed Mode to stamp provenance on proof artifacts; it MUST
        NOT raise under any circumstance.
        """
        cached = _TAU_VERSION_CACHE.get(id(self))
        if cached is not None:
            return cached
        binary = os.environ.get("TAU_BINARY") or shutil.which("tau")
        if not binary:
            _TAU_VERSION_CACHE[id(self)] = "unknown"
            return "unknown"
        env = os.environ.copy()
        dyld_extra = os.environ.get("TAU_DYLD_PATH")
        if dyld_extra:
            env["DYLD_LIBRARY_PATH"] = dyld_extra
            env["LD_LIBRARY_PATH"] = dyld_extra
        try:
            result = subprocess.run(
                [binary, "--version"],
                env=env,
                capture_output=True,
                text=True,
                timeout=min(5.0, self.timeout_seconds),
            )
        except (subprocess.TimeoutExpired, OSError, Exception):  # noqa: BLE001
            version = "unknown"
        else:
            raw = (result.stdout or result.stderr or "").strip()
            version = next(
                (line.strip() for line in raw.splitlines() if line.strip()),
                "unknown",
            )
        _TAU_VERSION_CACHE[id(self)] = version
        return version

    def prove(
        self,
        invariants: Sequence[Invariant],
        predecessor_hash: Optional[str] = None,
    ) -> ProofToken | Contradiction:
        # Always pattern-check first: it's cheap and catches the clearly-broken
        # cases before we pay Tau's startup cost.
        pattern_result = self.fallback.prove(invariants, predecessor_hash)
        if isinstance(pattern_result, Contradiction):
            return pattern_result  # don't bother Tau if pattern already found UNSAT

        # Compile to the fragment-v1 non-temporal sat encoding. Anything
        # outside the fragment raises UnsupportedInvariantError here and we
        # surface it as a Contradiction-shaped rejection so strict-mode
        # daemons don't silently admit.
        try:
            compiled = compile_policy(invariants)
        except UnsupportedInvariantError as exc:
            return Contradiction(
                left=exc.invariant_name,
                right="fragment_v1",
                reason=str(exc),
                backend="tau-compile",
            )
        except CompileError as exc:
            return Contradiction(
                left="compile",
                right="fragment_v1",
                reason=f"compile failed: {exc}",
                backend="tau-compile",
            )

        # Try Tau. Any failure -> pattern_result with relabeled proof_strength.
        try:
            verdict, detail = self._ask_tau(compiled.tau_source)
        except TauUnavailable as exc:
            logger.info("Tau prover unavailable: %s; pattern fallback in effect", exc)
            return self._relabel(pattern_result, "chained:tau->pattern",
                                 "pattern+tau-unavailable")
        except subprocess.TimeoutExpired:
            logger.warning("Tau prover timed out after %ss; pattern fallback",
                           self.timeout_seconds)
            return self._relabel(pattern_result, "chained:tau->pattern",
                                 "pattern+tau-inconclusive")
        except Exception as exc:  # noqa: BLE001
            logger.warning("Tau prover errored (%s); pattern fallback",
                           type(exc).__name__)
            return self._relabel(pattern_result, "chained:tau->pattern",
                                 "pattern+tau-inconclusive")

        if verdict == "unsat":
            return Contradiction(
                left="composed_spec",
                right="composed_spec",
                reason=f"Tau SMT: {detail}",
                backend=self.backend,
            )
        if verdict == "sat":
            # Genuine complete proof: stamp provenance from the compiled spec.
            if isinstance(pattern_result, ProofToken):
                return ProofToken(
                    config_hash=pattern_result.config_hash,
                    issued_at_unix=pattern_result.issued_at_unix,
                    backend=self.backend,
                    proof_strength="complete",
                    nonce=pattern_result.nonce,
                    predecessor_hash=pattern_result.predecessor_hash,
                    prover_mode=None,  # daemon stamps per its mode
                    fragment_version=compiled.fragment_version,
                    compile_hash=compiled.compile_hash,
                    tau_backend_version=None,  # probed by daemon once per session
                )
        # "inconclusive" (Tau couldn't decide cleanly) -> fall through.
        return self._relabel(pattern_result, "chained:tau->pattern",
                             "pattern+tau-inconclusive")

    @staticmethod
    def _relabel(
        token: ProofToken | Contradiction,
        new_backend: str,
        new_strength: str,
    ) -> ProofToken | Contradiction:
        if isinstance(token, Contradiction):
            return token
        return ProofToken(
            config_hash=token.config_hash,
            issued_at_unix=token.issued_at_unix,
            backend=new_backend,
            proof_strength=new_strength,
            nonce=token.nonce,
            predecessor_hash=token.predecessor_hash,
        )

    def extract_bv_witness(
        self,
        formula: str,
        target_var: str,
        *,
        lower: int = 0,
        upper: int = 0xFFFFFFFFFFFFFFFF,
        max_probes: int = 48,
    ) -> Optional[int]:
        """Extract the maximum admissible bv value for ``target_var`` under ``formula``.

        Binary-searches for the largest ``N`` in ``[lower, upper]`` such that
        ``formula ∧ target_var = {N}:bv[64]`` is SAT according to the Tau
        ``sat`` REPL. Returns ``None`` on any of:

          * Tau unavailable in the environment.
          * Tau times out or errors on any probe (fail-closed; we don't
            pretend partial probes give a bound).
          * Tau returns ``inconclusive`` on every probe (the common case
            when the formula involves bv ``<=`` because Tau's current
            implementation does not treat that operator as numeric).

        When ``None`` is returned the caller must NOT publish the result
        as a proven upper bound. The prevented_risk dual-shape output
        maps ``None`` to ``proven_upper_bound_usd: null`` in that case.

        This method is intentionally conservative: it runs one extra
        probe per doubling of the search range (binary search), so at
        ``max_probes=48`` it can cover a full 64-bit range. Each probe
        takes one Tau subprocess call bounded by ``self.timeout_seconds``.

        Args:
            formula: the non-temporal Tau fragment-v1 body that the
                target variable must satisfy. Caller builds this from
                the active policy; see ``adapter.tau_compiler``.
            target_var: the variable name whose maximum value is sought.
                Must appear in ``formula`` for any probe to return SAT.
            lower: inclusive lower bound for the search (default 0).
            upper: inclusive upper bound for the search (default
                :math:`2^{64} - 1`). The caller usually tightens this
                to the known cap to keep probes meaningful.
            max_probes: hard cap on the number of Tau invocations.
                Prevents run-away search if a probe starts timing out.

        Returns:
            The largest admissible bv value as a Python ``int``, or
            ``None`` when the witness could not be established.
        """
        if upper < lower:
            return None
        # If Tau isn't even available, bail out immediately rather than
        # pay for probe logic that will all fail identically.
        if not self.is_available():
            return None

        binary = os.environ.get("TAU_BINARY") or shutil.which("tau")
        if not binary:
            return None

        # Probe 1: is ``lower`` admissible? If not, the whole range is
        # infeasible and there's nothing to witness.
        lo_verdict = self._probe_value(formula, target_var, lower)
        if lo_verdict == "inconclusive":
            # Tau can't decide even the lower bound — abandon the probe
            # and never pretend to have proved anything.
            return None
        if lo_verdict == "unsat":
            # The policy rejects every value in our search range.
            return lower if lower == 0 else None

        # Probe 2: is ``upper`` admissible? A ``sat`` answer is a direct
        # witness at the ceiling; a ``unsat`` answer means we binary-
        # search inside; ``inconclusive`` means Tau gave up.
        hi_verdict = self._probe_value(formula, target_var, upper)
        if hi_verdict == "sat":
            return upper
        if hi_verdict == "inconclusive":
            return None

        # Binary search between lower (sat) and upper (unsat). Invariant:
        # best is the largest N with a proven sat verdict.
        best = lower
        lo, hi = lower, upper
        probes = 0
        while lo <= hi and probes < max_probes:
            mid = (lo + hi) // 2
            if mid == best and lo == hi:
                break
            verdict = self._probe_value(formula, target_var, mid)
            probes += 1
            if verdict == "sat":
                best = mid
                lo = mid + 1
            elif verdict == "unsat":
                hi = mid - 1
            else:
                # Inconclusive probe: abandon the search rather than
                # report a bound we can't back with a Tau decision.
                return None
        return best

    def _probe_value(
        self,
        formula: str,
        target_var: str,
        value: int,
    ) -> str:
        """One Tau sat probe asking ``formula ∧ target_var = {value}``.

        Returns one of ``"sat"``, ``"unsat"``, ``"inconclusive"``. Any
        subprocess failure is folded into ``"inconclusive"`` so the
        search loop never has to catch exceptions.
        """
        value_clamped = max(0, int(value)) & 0xFFFFFFFFFFFFFFFF
        probe_formula = (
            f"({formula}) && {target_var}:bv[64] = "
            f"{{ {value_clamped} }}:bv[64]"
        )
        try:
            verdict, _detail = self._ask_tau(probe_formula)
        except (TauUnavailable, subprocess.TimeoutExpired):
            return "inconclusive"
        except Exception:  # noqa: BLE001 — fail-closed on probe failures.
            return "inconclusive"
        return verdict

    def _ask_tau(self, spec: str) -> tuple[str, str]:
        """Invoke the Tau CLI: return (verdict, detail).

        verdict in {"sat", "unsat", "inconclusive"}. detail is a human-readable
        string for audit logs. Raises TauUnavailable if the binary isn't found.
        """
        binary = os.environ.get("TAU_BINARY") or shutil.which("tau")
        if not binary:
            raise TauUnavailable("tau binary not on PATH; set TAU_BINARY to override")

        env = os.environ.copy()
        dyld_extra = os.environ.get("TAU_DYLD_PATH")
        if dyld_extra:
            env["DYLD_LIBRARY_PATH"] = dyld_extra
            env["LD_LIBRARY_PATH"] = dyld_extra

        # Spec body without the trailing period; `sat <body>.` is the REPL form.
        body = spec.rstrip().rstrip(".")
        repl_cmd = f"sat {body}."

        result = subprocess.run(
            [binary, "-e", repl_cmd, "-q"],
            env=env, capture_output=True, text=True,
            timeout=self.timeout_seconds,
        )
        raw = (result.stdout + "\n" + result.stderr).strip()
        # Tau emits ANSI color codes in REPL output (e.g. "\x1b[32m%1\x1b[0m: T").
        # Strip them before the T/F detection so terminal formatting doesn't
        # hide the decision.
        output = re.sub(r"\x1b\[[0-9;]*m", "", raw)
        if "Error" in output or "Syntax" in output:
            return "inconclusive", f"Tau could not parse spec: {output[:200]}"
        # Walk every non-empty line: the verdict appears on a line like "%1: T"
        # (first non-empty line in typical output), while the timing footer
        # "sat: N ms" is written to stderr and concatenated later. Checking
        # ALL lines rather than just the last avoids that ordering assumption.
        for line in output.splitlines():
            tail = line.strip()
            if not tail:
                continue
            if tail.endswith(": T") or tail == "T":
                return "sat", "Tau SAT reached decision"
            if tail.endswith(": F") or tail == "F":
                return "unsat", "Tau proved composed spec unsatisfiable"
        return "inconclusive", f"Tau output not parsed as T/F: {output[:200]}"


# ── helpers ──────────────────────────────────────────────────────────────────


def _hash_invariants(invs: Iterable[Invariant]) -> str:
    """Deterministic SHA-256 over the canonical invariant-set representation."""
    canonical = sorted((type(i).__name__, repr(i)) for i in invs)
    payload = json.dumps(canonical, sort_keys=True).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


# ── factory ──────────────────────────────────────────────────────────────────


# ── backend 3: z3 SMT prover (fragment v2) ───────────────────────────────────


@dataclass(frozen=True)
class Z3ConsistencyProver:
    """Decides fragment-v2 consistency (temporal-arithmetic invariants) via z3.

    Why this exists: Tau's `<=` on bv is not numeric comparison (see
    docs/semantic_fragment_v2_research.md). Fragment v2 (SpendingCap
    per_window, RollingWindowCap, RetryRateLimit) requires unsigned numeric
    comparison on bitvectors PLUS bounded temporal unrolling. z3's
    `ULE(BitVec, BitVec)` is the primitive we need; its Python API is
    directly callable and supports SMT-LIB serialisation for audit.

    Fragment routing (daemon responsibility):
      * v1 invariants -> TauConsistencyProver (set-algebraic consistency)
      * v2 invariants -> Z3ConsistencyProver (arithmetic-temporal consistency)

    A policy containing ONLY v2 invariants is handled entirely here. A
    MIXED policy (v1 + v2) requires the daemon to either compose them
    (future work) or route each class to its own prover and AND the
    results -- see docs/semantic_fragment_v2.md for the policy decision.
    """

    backend: str = "z3"
    timeout_seconds: float = 10.0
    unroll_steps: int = 10

    @staticmethod
    def is_available() -> bool:
        """True iff the z3-solver package is importable in this environment."""
        try:
            import z3  # noqa: F401
            return True
        except ImportError:
            return False

    def prove(
        self,
        invariants: Sequence[Invariant],
        predecessor_hash: Optional[str] = None,
    ) -> "ProofToken | Contradiction | InconclusiveProof":
        # Lazy import so `pip install tau-x402-cage` (no [v2] extra) still works.
        try:
            from adapter.z3_compiler import (
                Z3CompileError,
                Z3Unavailable,
                check_sat,
                compile_policy_v2,
                extract_witness,
            )
        except ImportError:
            return InconclusiveProof(
                category="unavailable",
                reason="adapter.z3_compiler not importable",
                backend=self.backend,
            )

        try:
            compiled, solver = compile_policy_v2(
                invariants, unroll_steps=self.unroll_steps,
            )
        except Z3Unavailable as exc:
            return InconclusiveProof(
                category="unavailable",
                reason=str(exc),
                backend=self.backend,
            )
        except Z3CompileError as exc:
            return Contradiction(
                left=str(exc),
                right="fragment_v2",
                reason=f"z3 compile failed: {exc}",
                backend="z3-compile",
            )

        try:
            verdict, detail = check_sat(
                solver, compiled, timeout_ms=int(self.timeout_seconds * 1000),
            )
        except Exception as exc:  # noqa: BLE001
            return InconclusiveProof(
                category="other",
                reason=f"z3 check_sat raised: {exc}",
                backend=self.backend,
            )

        if verdict == "sat":
            # v0.8.0: extract a concrete witness from the SAT model so the
            # caller can see a specific permit trace. Guarded because a
            # buggy z3 version could hand us an exception from model(); a
            # witness is auxiliary to the SAT verdict and must never block
            # admission on failure.
            witness: Optional[dict]
            try:
                witness = extract_witness(
                    solver,
                    summaries=compiled.invariant_summaries,
                    unroll_steps=compiled.unroll_steps,
                )
            except Exception as exc:  # noqa: BLE001
                logger.info("extract_witness failed (%s); token has witness=None",
                            type(exc).__name__)
                witness = None
            return ProofToken(
                config_hash=_hash_invariants(tuple(invariants)),
                issued_at_unix=int(time.time()),
                backend=self.backend,
                proof_strength="complete",
                nonce=secrets.token_hex(8),
                predecessor_hash=predecessor_hash,
                fragment_version=compiled.fragment_version,
                compile_hash=compiled.compile_hash,
                tau_backend_version=None,
                witness=witness,
            )
        if verdict == "unsat":
            return Contradiction(
                left="composed_v2_spec",
                right="composed_v2_spec",
                reason=f"z3: {detail}",
                backend=self.backend,
            )
        # unknown: timeout or undecidable
        return InconclusiveProof(
            category="timeout",
            reason=detail,
            backend=self.backend,
            details={"timeout_ms": int(self.timeout_seconds * 1000),
                     "unroll_steps": self.unroll_steps},
        )


# ── backend 3b: z3 incremental SMT prover (fragment v2, v0.7.0+) ─────────────


class IncrementalZ3Prover:
    """True incremental fragment-v2 prover via `z3.Solver.push()` / `pop()`.

    Unlike `Z3ConsistencyProver` (which rebuilds the problem on every
    proof), this prover keeps a LIVE `z3.Solver` across admissions. Each
    invariant added to the cage gets its own `push()`-ed frame; removing
    the invariant `pop()`s back to the frame before it. Updating is
    atomic pop+push.

    This is deliberately NOT a `@dataclass(frozen=True)` — the prover
    holds mutable state (`_solver`, `_frames`, counters) by design.

    Metrics (exposed via `metrics()`):
      * ``incremental_hits``  : add/remove/update ops served by push/pop.
      * ``full_resolves``     : full-composition fallbacks (e.g. first call,
                                or when a checkpoint reset required it).
      * ``push_depth``        : current depth of the frame stack.
      * ``total_invariants``  : number of active invariant frames.

    Frame accounting: each frame is a tuple ``(tag, summary)`` where
    ``tag`` is the stable per-invariant key from `z3_compiler.frame_tag`.
    The prover maintains a parallel Python list of frames alongside the
    z3 solver's internal scope stack so removals can find the right frame
    to pop (z3 only supports pop-to-depth, not pop-frame-by-tag; we
    replay every frame above the target after a targeted pop).

    Thread-safety: one `threading.Lock` serialises all mutation methods.
    The daemon already holds `_registry_lock` for the outer admission
    flow, so lock ordering is: daemon lock first, then prover lock.
    """

    backend: str = "z3-incremental"

    def __init__(
        self,
        timeout_seconds: float = 10.0,
        unroll_steps: int = 10,
    ) -> None:
        self.timeout_seconds = timeout_seconds
        self.unroll_steps = unroll_steps
        self._lock = threading.Lock()
        self._solver = None  # lazily constructed on first use
        # Frame stack mirrors the z3 solver's scope. Each entry:
        # {"tag": str, "repr_key": str, "constraints_count": int,
        #  "summary": dict}. len(self._frames) == solver.num_scopes().
        self._frames: list[dict] = []
        # Metrics
        self._incremental_hits: int = 0
        self._full_resolves: int = 0
        self._last_check_verdict: Optional[str] = None
        self._last_check_detail: Optional[str] = None

    # ── lifecycle ──────────────────────────────────────────────────────────

    @staticmethod
    def is_available() -> bool:
        try:
            import z3  # noqa: F401
            return True
        except ImportError:
            return False

    def _ensure_solver(self):
        """Lazily build the persistent z3 Solver on first use."""
        if self._solver is None:
            import z3 as z3mod
            self._solver = z3mod.Solver()
            self._solver.set("timeout", int(self.timeout_seconds * 1000))
        return self._solver

    # ── metrics ────────────────────────────────────────────────────────────

    def metrics(self) -> dict:
        """Snapshot the prover's push/pop counters and current depth.

        Safe to call from any thread; takes the internal lock.
        """
        with self._lock:
            return {
                "backend": self.backend,
                "incremental_hits": self._incremental_hits,
                "full_resolves": self._full_resolves,
                "push_depth": len(self._frames),
                "total_invariants": len(self._frames),
                "last_check_verdict": self._last_check_verdict,
                "unroll_steps": self.unroll_steps,
                "timeout_seconds": self.timeout_seconds,
            }

    def reset(self) -> None:
        """Tear down the live solver and all frames.

        Used by `branching_checkpoint()` callers to drop back to a prior
        state or to restart a session. After reset the prover is empty
        but still usable; the next `prove_delta` will run a full resolve
        over whatever set is pushed.
        """
        with self._lock:
            self._solver = None
            self._frames = []
            # counters are monotonic across the prover lifetime; only
            # `push_depth` and `total_invariants` go back to zero via the
            # frame list. incremental_hits/full_resolves are NOT reset --
            # they record cumulative ops for observability.
            self._last_check_verdict = None
            self._last_check_detail = None

    # ── incremental ops ────────────────────────────────────────────────────

    def _push_invariant(self, inv: "Invariant") -> dict:
        """Push one invariant onto the live solver as a new frame.

        Returns the frame dict so callers can inspect the tag/summary.
        Must be called under self._lock.
        """
        from adapter.z3_compiler import compile_invariant_v2, frame_tag
        constraints, summary = compile_invariant_v2(inv, self.unroll_steps)
        tag = frame_tag(inv)
        solver = self._ensure_solver()
        solver.push()
        for c in constraints:
            solver.add(c)
        frame = {
            "tag": tag,
            "repr_key": repr(inv),
            "class_name": type(inv).__name__,
            "constraints_count": len(constraints),
            "summary": summary,
            # Keep the instance so `remove_invariant` can replay frames
            # above a targeted pop. Frozen dataclasses are hashable and
            # repr-stable, so keeping a reference is safe.
            "_invariant": inv,
        }
        self._frames.append(frame)
        return frame

    def _pop_to_tag(self, tag: str) -> list[dict]:
        """Pop frames down to (but NOT including) the one with this tag.

        Returns the list of popped frames in original stack order (bottom
        to top) so callers can replay them if needed. Must be called
        under self._lock.

        Raises KeyError if no frame with that tag exists.
        """
        # Find the target frame from the top of the stack.
        target_idx = None
        for i in range(len(self._frames) - 1, -1, -1):
            if self._frames[i]["tag"] == tag:
                target_idx = i
                break
        if target_idx is None:
            raise KeyError(f"no frame with tag {tag!r} on the stack")
        # Frames ABOVE the target (indices target_idx+1 .. len-1) must be
        # replayed after we pop them. We pop the target plus those above it.
        above = list(self._frames[target_idx + 1:])
        # Number of pops = (len - target_idx) (target + everything above it)
        pops = len(self._frames) - target_idx
        solver = self._ensure_solver()
        for _ in range(pops):
            solver.pop()
        self._frames = self._frames[:target_idx]
        return above

    def add_invariant(self, inv: "Invariant") -> dict:
        """Push one invariant as a new frame. Returns the frame descriptor."""
        with self._lock:
            frame = self._push_invariant(inv)
            self._incremental_hits += 1
            return dict(frame)

    def remove_invariant(self, inv: "Invariant") -> None:
        """Pop the frame holding this invariant (re-pushing any frames above).

        Raises KeyError if the invariant isn't on the stack.
        """
        from adapter.z3_compiler import frame_tag
        tag = frame_tag(inv)
        with self._lock:
            above = self._pop_to_tag(tag)
            # Re-push the frames that were above the removed one. We have
            # their summaries but not the original z3 constraints -- we
            # re-emit them from the cached repr_key by reconstructing the
            # invariant. To avoid coupling to the invariant factory here,
            # we instead keep the constraints alongside each frame in a
            # slow path. For v0.7.0 we re-invoke compile on the repr...
            # but we don't have the invariant instance by repr. Simpler:
            # maintain the invariant instance in the frame too.
            for f in above:
                # Each `above` frame carries `_invariant` in v0.7.0.
                inv_ref = f.get("_invariant")
                if inv_ref is None:
                    # Should never happen: add_invariant always stores it.
                    raise RuntimeError(
                        f"frame {f['tag']} missing _invariant; cannot replay"
                    )
                self._push_invariant(inv_ref)
            self._incremental_hits += 1

    def update_invariant(self, old: "Invariant", new: "Invariant") -> None:
        """Atomic pop(old) + push(new). Metrics count as one incremental hit.

        If the old invariant is not on the stack, raises KeyError and the
        stack is left untouched.
        """
        from adapter.z3_compiler import frame_tag
        old_tag = frame_tag(old)
        with self._lock:
            above = self._pop_to_tag(old_tag)
            # Re-push frames that were above the removed one, then push new.
            for f in above:
                inv_ref = f.get("_invariant")
                if inv_ref is None:
                    raise RuntimeError(
                        f"frame {f['tag']} missing _invariant; cannot replay"
                    )
                self._push_invariant(inv_ref)
            self._push_invariant(new)
            # Net accounting: one logical op = one hit (old atomic swap).
            self._incremental_hits += 1

    # ── proof ops ──────────────────────────────────────────────────────────

    def check(self) -> Tuple[str, str]:
        """Run solver.check() against the current frame stack.

        Returns (verdict, detail) where verdict is "sat" | "unsat" |
        "unknown". Records the verdict for introspection via `metrics()`.
        """
        try:
            import z3
        except ImportError as exc:
            raise RuntimeError("z3 is required for IncrementalZ3Prover") from exc
        with self._lock:
            solver = self._ensure_solver()
            solver.set("timeout", int(self.timeout_seconds * 1000))
            status = solver.check()
            if status == z3.sat:
                self._last_check_verdict = "sat"
                detail = f"z3 SAT ({self.unroll_steps}-step unrolling, incremental)"
            elif status == z3.unsat:
                self._last_check_verdict = "unsat"
                detail = "z3 UNSAT (incremental)"
            else:
                self._last_check_verdict = "unknown"
                detail = f"z3 UNKNOWN (timeout or undecidable, incremental)"
            self._last_check_detail = detail
            return self._last_check_verdict, detail

    def prove_delta(
        self,
        added: Sequence["Invariant"] = (),
        removed: Sequence["Invariant"] = (),
        predecessor_hash: Optional[str] = None,
        full_current_set: Optional[Sequence["Invariant"]] = None,
    ) -> "ProofToken | Contradiction | InconclusiveProof":
        """Apply a delta to the live solver and check consistency.

        If any invariant in `added` or `removed` is outside fragment v2,
        returns a Contradiction. If z3 is unavailable, returns
        InconclusiveProof(category="unavailable").

        Mutation semantics:
            * Each ``removed`` invariant is popped via `remove_invariant`.
            * Each ``added`` invariant is pushed via `add_invariant`.
            * If `check()` returns UNSAT, the new frames are popped to
              leave the solver at the pre-delta state — no hidden state
              leaks on rejection.

        `full_current_set`, when provided, is used only for the
        `config_hash` field on the emitted ProofToken (to keep the audit
        trail byte-compatible with `Z3ConsistencyProver`).
        """
        # Fragment membership check first (fast-fail; no state mutation).
        try:
            from adapter.z3_compiler import Z3CompileError, Z3Unavailable, is_fragment_v2_invariant
        except ImportError:
            return InconclusiveProof(
                category="unavailable",
                reason="adapter.z3_compiler not importable",
                backend=self.backend,
            )
        for inv in list(added) + list(removed):
            if not is_fragment_v2_invariant(inv):
                return Contradiction(
                    left=type(inv).__name__,
                    right="fragment_v2",
                    reason=(
                        f"{type(inv).__name__} is not in fragment v2 "
                        "(IncrementalZ3Prover only decides v2)"
                    ),
                    backend="z3-compile",
                )

        # Snapshot prior depth so we can unwind on UNSAT.
        with self._lock:
            prior_depth = len(self._frames)

        try:
            for inv in removed:
                try:
                    self.remove_invariant(inv)
                except KeyError as exc:
                    return Contradiction(
                        left=type(inv).__name__,
                        right="frame_stack",
                        reason=f"cannot remove invariant not on the stack: {exc}",
                        backend=self.backend,
                    )
            for inv in added:
                self.add_invariant(inv)
        except Z3Unavailable as exc:
            return InconclusiveProof(
                category="unavailable",
                reason=str(exc),
                backend=self.backend,
            )
        except Z3CompileError as exc:
            # Already in inconsistent state: unwind anything we pushed for
            # `added` before re-raising as a Contradiction.
            with self._lock:
                while len(self._frames) > prior_depth:
                    self._solver.pop()
                    self._frames.pop()
            return Contradiction(
                left=str(exc),
                right="fragment_v2",
                reason=f"z3 compile failed: {exc}",
                backend="z3-compile",
            )

        try:
            verdict, detail = self.check()
        except Exception as exc:  # noqa: BLE001
            return InconclusiveProof(
                category="other",
                reason=f"z3 incremental check raised: {exc}",
                backend=self.backend,
            )

        if verdict == "unsat":
            # Unwind to pre-delta depth: pop the newly-added frames so
            # the prover state matches the registry state (which also
            # rejects the mutation).
            with self._lock:
                while len(self._frames) > prior_depth:
                    self._solver.pop()
                    self._frames.pop()
            return Contradiction(
                left="composed_v2_spec",
                right="composed_v2_spec",
                reason=f"z3 incremental: {detail}",
                backend=self.backend,
            )
        if verdict == "sat":
            cfg_hash = _hash_invariants(
                tuple(full_current_set) if full_current_set is not None else tuple(added)
            )
            # v0.8.0: pull a concrete witness off the live incremental
            # solver. Summaries are collected under the lock so the
            # extraction sees the same frame stack the solver decided.
            witness: Optional[dict] = None
            try:
                from adapter.z3_compiler import extract_witness
                with self._lock:
                    live_summaries = tuple(
                        f["summary"] for f in self._frames
                    )
                    solver_ref = self._solver
                if solver_ref is not None and live_summaries:
                    witness = extract_witness(
                        solver_ref,
                        summaries=live_summaries,
                        unroll_steps=self.unroll_steps,
                    )
            except Exception as exc:  # noqa: BLE001
                logger.info("extract_witness (incremental) failed (%s); "
                            "token has witness=None",
                            type(exc).__name__)
                witness = None
            return ProofToken(
                config_hash=cfg_hash,
                issued_at_unix=int(time.time()),
                backend=self.backend,
                proof_strength="complete",
                nonce=secrets.token_hex(8),
                predecessor_hash=predecessor_hash,
                fragment_version="v2",
                compile_hash=None,  # incremental: no single snapshot hash
                tau_backend_version=None,
                witness=witness,
            )
        # unknown: timeout or undecidable
        return InconclusiveProof(
            category="timeout",
            reason=detail,
            backend=self.backend,
            details={
                "timeout_ms": int(self.timeout_seconds * 1000),
                "unroll_steps": self.unroll_steps,
                "push_depth": len(self._frames),
            },
        )

    def prove(
        self,
        invariants: Sequence["Invariant"],
        predecessor_hash: Optional[str] = None,
    ) -> "ProofToken | Contradiction | InconclusiveProof":
        """Full-composition prove path (compatible with ConsistencyProver protocol).

        This is NOT the incremental path; it rebuilds the solver from
        scratch. Callers that want push/pop should use `prove_delta`.
        Every call to this method increments `full_resolves`.
        """
        with self._lock:
            self._full_resolves += 1
        # Reset and push every invariant fresh. Using `reset()` so the
        # counters other than full_resolves stay meaningful.
        self.reset()
        return self.prove_delta(
            added=tuple(invariants),
            removed=(),
            predecessor_hash=predecessor_hash,
            full_current_set=tuple(invariants),
        )

    # ── branching support (v0.7.0; simple linear checkpoints) ──────────────

    def branching_checkpoint(self) -> int:
        """Return an opaque checkpoint id for the current depth.

        Callers pass the returned value back to `reset_to_checkpoint()`
        to discard every frame pushed after it. This is intentionally
        lightweight; the full branching-revision graph lives in
        `adapter/policy_revision.py` and is owned by another agent.
        """
        with self._lock:
            return len(self._frames)

    def reset_to_checkpoint(self, checkpoint: int) -> None:
        """Pop frames back to the given checkpoint depth.

        Raises ValueError if the checkpoint is deeper than the current
        stack (i.e. the caller has already popped past it).
        """
        with self._lock:
            if checkpoint < 0 or checkpoint > len(self._frames):
                raise ValueError(
                    f"invalid checkpoint {checkpoint} "
                    f"(current depth {len(self._frames)})"
                )
            while len(self._frames) > checkpoint:
                self._solver.pop()
                self._frames.pop()


def prover_from_env() -> ConsistencyProver:
    """Build a prover from `CAGE_PROVER` env var.

    Values:
        "pattern"  (default) -> PythonPatternProver
        "tau"                -> TauConsistencyProver(fallback=PythonPatternProver)
        "auto"               -> TauConsistencyProver if Tau is available, else PythonPatternProver
    """
    choice = os.environ.get("CAGE_PROVER", "pattern").lower()
    if choice == "pattern":
        return PythonPatternProver()
    if choice == "tau":
        return TauConsistencyProver()
    if choice == "auto":
        if TauConsistencyProver.is_available():
            return TauConsistencyProver()
        return PythonPatternProver()
    logger.warning("Unknown CAGE_PROVER=%r; falling back to pattern", choice)
    return PythonPatternProver()
