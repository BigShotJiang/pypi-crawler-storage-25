"""Sign and verify cage verdicts for HTTP-402 wire transport.

Addresses security review findings C-01 (spoofable headers) and C-02 (replay).
Every verdict carries:
    - HMAC-SHA256 or Ed25519 signature over canonical payload + TTL + intent_hash
    - intent_hash cryptographically binding the verdict to one specific intent
    - issued_at + ttl_seconds for temporal validity

V1 envelopes are backwards-compatible: sign() called without a PolicyRevision
emits a v1 envelope with no provenance fields. When a PolicyRevision is
provided, sign() emits a v2 envelope that MAC-binds
(policy_revision_id, proof_backend, proof_strength, prover_mode,
compile_hash). Downstream verifiers can then correlate any envelope back to
the exact policy state that issued it, and any tampering with those fields
fails verification.

Two signing backends are supported:

* **HMAC-SHA256** (default). Symmetric, shared secret between cage and
  facilitator. Zero extra deps. Works fine inside a single trust boundary.
* **Ed25519** (v0.7.0+). Asymmetric; the cage holds the private key, any
  consumer can verify with just the published public key. Required for
  public-audit / cross-org deployments where distributing a shared secret
  to every verifier is infeasible. Requires the `signing-ed25519` extra.

The signature algorithm is part of the canonical signed payload, so an
attacker cannot downgrade an ed25519 envelope to look like an unverified
HMAC envelope without invalidating the signature.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import os
import stat
import threading
import time
import warnings
from dataclasses import dataclass
from typing import Literal, Optional, TYPE_CHECKING

from adapter.payment_intent_matcher import PaymentIntent

if TYPE_CHECKING:
    from adapter.policy_revision import PolicyRevision


class SignatureError(ValueError):
    """Raised when a verdict envelope fails signature verification."""


class VerdictExpired(ValueError):
    """Raised when a verdict's TTL has elapsed."""


class KeyMaterialError(ValueError):
    """Raised when ed25519 key material is missing, unreadable, or malformed."""


Outcome = Literal["permit", "reject"]

#: Wire version identifiers. "v1" envelopes have no provenance fields; "v2"
#: envelopes MAC-bind the PolicyRevision provenance. Parsers accept both.
WIRE_VERSION_V1 = "v1"
WIRE_VERSION_V2 = "v2"

#: Signature algorithm identifiers embedded in the canonical payload.
#: Binding the algorithm inside the MAC input blocks downgrade attacks.
ALG_HMAC_SHA256 = "hmac-sha256"
ALG_ED25519 = "ed25519"
SUPPORTED_ALGORITHMS = (ALG_HMAC_SHA256, ALG_ED25519)

#: Friendly human-facing MAC algorithm labels used on the wire (back-compat).
#: The algorithm identifier inside the canonical payload uses the lower-case
#: names above; `mac_alg` remains on the envelope for legacy v1 facilitators.
MAC_ALG_LABELS = {
    ALG_HMAC_SHA256: "HMAC-SHA256",
    ALG_ED25519: "Ed25519",
}

#: Top-level envelope keys the parser knows how to place. Strict parsing
#: (``SignedEnvelope.from_json(..., strict=True)``) rejects any wire key
#: outside this set so an auditor can tell a mutated envelope apart from
#: a legitimate forward-compatible one.
_KNOWN_ENVELOPE_FIELDS: frozenset[str] = frozenset(
    {
        # v1 core
        "outcome",
        "rule_id",
        "witness",
        "reason_text",
        "issued_at_unix",
        "ttl_seconds",
        "intent_hash",
        "mac_hex",
        "mac_alg",
        "algorithm",
        "version",
        # v2 provenance
        "policy_revision_id",
        "proof_backend",
        "proof_strength",
        "prover_mode",
        "compile_hash",
        # v0.13.0
        "without_system",
        "mode",
        "shadow_would_reject",
        "shadow_rule_id",
        "shadow_reason_text",
        # v0.17.0
        "risk_amount_projected",
    }
)


class ReplayCache:
    """One-time-use cache keyed by ``(intent_hash, mac_hex)``.

    Signature verification alone is stateless, so a captured envelope can
    be re-presented for the same intent until its TTL elapses. Passing a
    ``ReplayCache`` to :func:`verify` closes that window: the second
    attempt on the same envelope raises :class:`SignatureError`.

    In-memory + thread-safe. Entries self-expire at the envelope's
    ``issued_at_unix + ttl_seconds`` boundary, and expired rows are reaped
    lazily on :meth:`mark_seen` so the set stays bounded for steady-state
    traffic. Deployments needing cross-process or cross-host coverage
    should swap in a Redis-backed implementation that honours the same
    ``is_seen`` / ``mark_seen`` shape.
    """

    def __init__(self) -> None:
        self._seen: dict[tuple[str, str], int] = {}
        self._lock = threading.Lock()

    def is_seen(self, intent_hash: str, mac_hex: str) -> bool:
        with self._lock:
            return (intent_hash, mac_hex) in self._seen

    def mark_seen(
        self,
        intent_hash: str,
        mac_hex: str,
        *,
        expires_at_unix: int,
        now_unix: int,
    ) -> None:
        with self._lock:
            self._seen[(intent_hash, mac_hex)] = expires_at_unix
            stale = [k for k, exp in self._seen.items() if exp <= now_unix]
            for k in stale:
                del self._seen[k]

    def __len__(self) -> int:
        with self._lock:
            return len(self._seen)


@dataclass(frozen=True)
class Verdict:
    """What the cage daemon produces before wire serialization."""

    outcome: Outcome
    rule_id: Optional[str] = None        # set on reject; names the violating invariant
    witness: Optional[str] = None        # machine-readable witness (e.g. "cumulative=$1002, cap=$1000")
    reason_text: Optional[str] = None    # plain-English explanation, TTI-critical
    issued_at_unix: int = 0              # filled by signer
    ttl_seconds: int = 30                # default 30s TTL


@dataclass(frozen=True)
class SignedEnvelope:
    """Wire-serializable verdict envelope with signature + intent binding.

    v1 envelopes set `version="v1"` and leave provenance fields None. v2
    envelopes set `version="v2"` and populate the provenance fields; those
    values are inside the canonical signed input so tampering fails verify().

    The `algorithm` field identifies which signing backend produced `mac_hex`
    and is itself part of the canonical signed payload, which blocks
    downgrade attacks (an attacker cannot re-label an ed25519 envelope as
    HMAC and replace the signature).
    """

    outcome: Outcome
    rule_id: Optional[str]
    witness: Optional[str]
    reason_text: Optional[str]
    issued_at_unix: int
    ttl_seconds: int
    intent_hash: str       # hex SHA-256 of canonical PaymentIntent serialization
    mac_hex: str           # hex signature (HMAC-SHA256 or Ed25519) over canonical payload
    mac_alg: str = "HMAC-SHA256"
    # Signature algorithm identifier. Default "hmac-sha256" keeps v1 HMAC
    # envelopes byte-identical to pre-v0.7 wire shape for back-compat.
    algorithm: Literal["hmac-sha256", "ed25519"] = ALG_HMAC_SHA256
    # Wire version. Older deployments send / expect v1; v2 carries provenance.
    version: str = WIRE_VERSION_V1
    # v2 provenance fields (all None on v1 envelopes):
    policy_revision_id: Optional[str] = None
    proof_backend: Optional[str] = None
    proof_strength: Optional[str] = None
    prover_mode: Optional[str] = None
    compile_hash: Optional[str] = None
    # v2 safety-comparison field (v0.13.0): the counterfactual verdict the
    # empty-registry baseline would have produced. MAC-bound so the
    # comparison claim is as tamper-evident as the verdict itself.
    without_system: Optional[str] = None
    # v0.13.0 shadow/advisory mode. Daemon cage mode, ``enforce|shadow|advisory``.
    # MAC-bound on v2 envelopes so an auditor can prove which mode was
    # active when the verdict was issued.
    mode: Optional[str] = None
    # When the daemon is in shadow/advisory mode AND the full admission
    # check would have rejected, this flag is True and the shadow_rule_id /
    # shadow_reason_text fields carry the "would have been rejected for"
    # metadata. Wire outcome stays ``permit`` in this case.
    shadow_would_reject: Optional[bool] = None
    shadow_rule_id: Optional[str] = None
    shadow_reason_text: Optional[str] = None
    # v0.17.0 — forward-projected loss the cage expects to block if the
    # rule that fired keeps firing at the observed rate. MAC-bound so the
    # claim is as tamper-evident as ``without_system``. Decimal is
    # serialised as a string to preserve base-10 precision through JSON.
    risk_amount_projected: Optional[str] = None

    def to_json(self) -> str:
        """Serialize for HTTP response body. v1 drops provenance fields so
        on-wire payloads stay byte-identical to legacy cages; v2 includes them.
        """
        payload = {
            "outcome": self.outcome,
            "rule_id": self.rule_id,
            "witness": self.witness,
            "reason_text": self.reason_text,
            "issued_at_unix": self.issued_at_unix,
            "ttl_seconds": self.ttl_seconds,
            "intent_hash": self.intent_hash,
            "mac_hex": self.mac_hex,
            "mac_alg": self.mac_alg,
            "algorithm": self.algorithm,
            "version": self.version,
        }
        if self.version == WIRE_VERSION_V2:
            payload.update(
                {
                    "policy_revision_id": self.policy_revision_id,
                    "proof_backend": self.proof_backend,
                    "proof_strength": self.proof_strength,
                    "prover_mode": self.prover_mode,
                    "compile_hash": self.compile_hash,
                    "without_system": self.without_system,
                    "mode": self.mode,
                    "shadow_would_reject": self.shadow_would_reject,
                    "shadow_rule_id": self.shadow_rule_id,
                    "shadow_reason_text": self.shadow_reason_text,
                    "risk_amount_projected": self.risk_amount_projected,
                }
            )
        return json.dumps(payload, separators=(",", ":"), sort_keys=True)

    @classmethod
    def from_json(cls, payload: str, *, strict: bool = False) -> "SignedEnvelope":
        """Parse wire bytes back into an envelope. Does NOT verify, call verify().

        Accepts both v1 (no provenance fields) and v2 (with provenance). A
        missing `version` key is treated as v1 for backward compatibility
        with pre-v2 deployments that never wrote the field. A missing
        `algorithm` key defaults to `hmac-sha256` for pre-v0.7 envelopes.

        ``strict=True`` rejects surplus top-level fields, tightening the
        audit / forensics posture. The permissive default remains so
        forward-compatible wire ingestion (newer cages emitting fields an
        older reader doesn't know about) still works; gate strict mode on
        the ingestion path rather than the general parser.
        """
        try:
            d = json.loads(payload)
        except json.JSONDecodeError as exc:
            raise SignatureError(f"envelope is not valid JSON: {exc}") from exc
        required = {
            "outcome",
            "issued_at_unix",
            "ttl_seconds",
            "intent_hash",
            "mac_hex",
            "mac_alg",
        }
        missing = required - d.keys()
        if missing:
            raise SignatureError(f"envelope missing required fields: {sorted(missing)}")
        if strict:
            unknown = d.keys() - _KNOWN_ENVELOPE_FIELDS
            if unknown:
                raise SignatureError(
                    f"envelope has unknown top-level fields (strict mode): "
                    f"{sorted(unknown)}"
                )
        version = d.get("version", WIRE_VERSION_V1)
        if version not in (WIRE_VERSION_V1, WIRE_VERSION_V2):
            raise SignatureError(
                f"unsupported envelope version: {version!r}; expected v1 or v2"
            )
        algorithm = d.get("algorithm", ALG_HMAC_SHA256)
        if algorithm not in SUPPORTED_ALGORITHMS:
            raise SignatureError(
                f"unsupported signature algorithm: {algorithm!r}; "
                f"expected one of {list(SUPPORTED_ALGORITHMS)}"
            )
        return cls(
            outcome=d["outcome"],
            rule_id=d.get("rule_id"),
            witness=d.get("witness"),
            reason_text=d.get("reason_text"),
            issued_at_unix=int(d["issued_at_unix"]),
            ttl_seconds=int(d["ttl_seconds"]),
            intent_hash=d["intent_hash"],
            mac_hex=d["mac_hex"],
            mac_alg=d["mac_alg"],
            algorithm=algorithm,
            version=version,
            policy_revision_id=d.get("policy_revision_id"),
            proof_backend=d.get("proof_backend"),
            proof_strength=d.get("proof_strength"),
            prover_mode=d.get("prover_mode"),
            compile_hash=d.get("compile_hash"),
            without_system=d.get("without_system"),
            mode=d.get("mode"),
            shadow_would_reject=d.get("shadow_would_reject"),
            shadow_rule_id=d.get("shadow_rule_id"),
            shadow_reason_text=d.get("shadow_reason_text"),
            risk_amount_projected=d.get("risk_amount_projected"),
        )


def hash_intent(intent: PaymentIntent) -> str:
    """Deterministic SHA-256 over the canonical PaymentIntent serialization.

    Binding this hash into the envelope prevents replay of a valid `permit`
    against a different intent. Any change to amount, provider, counterparty,
    timestamp, metadata, or request_id produces a different hash.
    """
    canonical = json.dumps(
        {
            "amount": str(intent.amount),
            "currency": intent.currency,
            "provider": intent.provider,
            "counterparty": intent.counterparty,
            "rail": intent.rail,
            "timestamp_unix": intent.timestamp_unix,
            "metadata": dict(sorted(intent.metadata.items())),
            "request_id": intent.request_id,
        },
        separators=(",", ":"),
        sort_keys=True,
    )
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def _canonical_mac_input(
    outcome: str,
    rule_id: Optional[str],
    witness: Optional[str],
    reason_text: Optional[str],
    issued_at_unix: int,
    ttl_seconds: int,
    intent_hash: str,
    version: str = WIRE_VERSION_V1,
    policy_revision_id: Optional[str] = None,
    proof_backend: Optional[str] = None,
    proof_strength: Optional[str] = None,
    prover_mode: Optional[str] = None,
    compile_hash: Optional[str] = None,
    algorithm: str = ALG_HMAC_SHA256,
    without_system: Optional[str] = None,
    mode: Optional[str] = None,
    shadow_would_reject: Optional[bool] = None,
    shadow_rule_id: Optional[str] = None,
    shadow_reason_text: Optional[str] = None,
    risk_amount_projected: Optional[str] = None,
) -> bytes:
    """Build the exact byte string the signature covers. Same on sign + verify.

    v1: emits the legacy payload unchanged for HMAC envelopes. Byte-identical
        to pre-v2 cages so existing facilitators verify old envelopes without
        re-keying. Ed25519 envelopes always include `algorithm` in the
        payload (see below) since pre-v0.7 cages never emitted ed25519.
    v2: extends the payload with (version, policy_revision_id, proof_backend,
        proof_strength, prover_mode, compile_hash). All provenance fields are
        inside the canonical signed input; tampering with any of them fails
        verification (that's what binds provenance to the signed verdict).

    Algorithm binding: for any non-legacy algorithm (i.e. ed25519), the
    algorithm identifier is included in the canonical payload so that
    re-labelling an ed25519 envelope as HMAC and swapping in a forged MAC
    breaks signature verification. HMAC v1 envelopes keep the legacy
    payload byte-identical to pre-v0.7 wire bytes.
    """
    base = {
        "outcome": outcome,
        "rule_id": rule_id,
        "witness": witness,
        "reason_text": reason_text,
        "issued_at_unix": issued_at_unix,
        "ttl_seconds": ttl_seconds,
        "intent_hash": intent_hash,
    }
    if version == WIRE_VERSION_V2:
        base.update(
            {
                "version": version,
                "policy_revision_id": policy_revision_id,
                "proof_backend": proof_backend,
                "proof_strength": proof_strength,
                "prover_mode": prover_mode,
                "compile_hash": compile_hash,
            }
        )
        # v0.13.0 safety-comparison field — bound into v2 only when
        # populated so pre-0.13 v2 envelopes stay byte-identical.
        if without_system is not None:
            base["without_system"] = without_system
        # v0.13.0 shadow/advisory — only bound when mode is populated,
        # so pre-0.13 v2 envelopes (mode=None) verify byte-for-byte.
        if mode is not None:
            base["mode"] = mode
            base["shadow_would_reject"] = shadow_would_reject
            base["shadow_rule_id"] = shadow_rule_id
            base["shadow_reason_text"] = shadow_reason_text
        # v0.17.0 — forward-projected loss. Only bound when populated so
        # pre-0.17 v2 envelopes (risk_amount_projected=None) verify
        # byte-for-byte against their old canonical input.
        if risk_amount_projected is not None:
            base["risk_amount_projected"] = risk_amount_projected
    # Algorithm is bound into the canonical input for every non-legacy
    # algorithm. Legacy HMAC v1 envelopes stay byte-identical to pre-v0.7
    # wire bytes (no `algorithm` key in the payload) so existing
    # facilitators keep verifying without being re-keyed or re-deployed.
    if algorithm != ALG_HMAC_SHA256:
        base["algorithm"] = algorithm
    payload = json.dumps(base, separators=(",", ":"), sort_keys=True)
    return payload.encode("utf-8")


# ── Ed25519 signer ───────────────────────────────────────────────────────────


@dataclass(frozen=True)
class Ed25519Signer:
    """Asymmetric signer for cage verdicts using Ed25519.

    Holds the private key in-process; the matching public key is what
    verifiers consume. Construct via :meth:`from_env` (recommended) or
    :meth:`from_pem_files` for explicit paths.

    The signer is intentionally minimal: no key-derivation, no hardware
    token support, no rotation yet. When those land, they'll be additional
    factories on this class; the `sign_bytes` / `public_key_bytes`
    interface stays stable.
    """

    private_key: "object"  # cryptography.hazmat.primitives.asymmetric.ed25519.Ed25519PrivateKey
    public_key: "object"   # cryptography.hazmat.primitives.asymmetric.ed25519.Ed25519PublicKey

    @classmethod
    def from_env(cls, env: Optional[dict] = None, strict: bool = False) -> "Ed25519Signer":
        """Load the signer from environment variables.

        Env vars:
            TAU_CAGE_ED25519_PRIVATE_KEY: path to a PEM-encoded private key
            TAU_CAGE_ED25519_PUBLIC_KEY:  path to a PEM-encoded public key

        `strict=True` turns world-readable private-key file perms into a
        hard failure. Non-strict mode warns and continues (useful for
        ephemeral dev keys in /tmp). Production daemons should run strict.
        """
        e = env if env is not None else os.environ
        priv_path = e.get("TAU_CAGE_ED25519_PRIVATE_KEY")
        pub_path = e.get("TAU_CAGE_ED25519_PUBLIC_KEY")
        if not priv_path or not pub_path:
            raise KeyMaterialError(
                "ed25519 signing requires TAU_CAGE_ED25519_PRIVATE_KEY and "
                "TAU_CAGE_ED25519_PUBLIC_KEY env vars pointing to PEM key files"
            )
        return cls.from_pem_files(priv_path, pub_path, strict=strict)

    @classmethod
    def from_pem_files(
        cls, private_key_path: str, public_key_path: str, strict: bool = False
    ) -> "Ed25519Signer":
        """Load PEM key material from disk.

        Raises KeyMaterialError on missing files, unreadable files, or
        malformed PEM content. Private key file perms are checked; any
        world-readable bit is a hard failure under `strict=True`, otherwise
        a warning.
        """
        _check_private_key_perms(private_key_path, strict=strict)
        try:
            from cryptography.hazmat.primitives import serialization
        except ImportError as exc:  # pragma: no cover - dep gate
            raise KeyMaterialError(
                "ed25519 signing requires the 'cryptography' package. "
                "Install the signing-ed25519 extra: pip install 'tau-x402-cage[signing-ed25519]'"
            ) from exc
        try:
            with open(private_key_path, "rb") as f:
                priv_pem = f.read()
            with open(public_key_path, "rb") as f:
                pub_pem = f.read()
        except OSError as exc:
            raise KeyMaterialError(f"cannot read ed25519 key file: {exc}") from exc
        try:
            private_key = serialization.load_pem_private_key(priv_pem, password=None)
            public_key = serialization.load_pem_public_key(pub_pem)
        except (ValueError, TypeError) as exc:
            # Deliberately no key bytes in the message; PEM can be
            # malformed in many ways and the exception type is enough.
            raise KeyMaterialError(f"malformed PEM key material: {exc}") from exc
        # Type sanity: reject non-Ed25519 keys so a user accidentally
        # pointing at an RSA pem doesn't silently produce garbage signatures.
        from cryptography.hazmat.primitives.asymmetric.ed25519 import (
            Ed25519PrivateKey,
            Ed25519PublicKey,
        )
        if not isinstance(private_key, Ed25519PrivateKey):
            raise KeyMaterialError(
                f"private key at {private_key_path} is not Ed25519 "
                f"(got {type(private_key).__name__})"
            )
        if not isinstance(public_key, Ed25519PublicKey):
            raise KeyMaterialError(
                f"public key at {public_key_path} is not Ed25519 "
                f"(got {type(public_key).__name__})"
            )
        return cls(private_key=private_key, public_key=public_key)

    def sign_bytes(self, data: bytes) -> bytes:
        """Sign an arbitrary byte string with the private key."""
        return self.private_key.sign(data)  # type: ignore[attr-defined]

    def public_key_bytes(self) -> bytes:
        """Return the raw 32-byte Ed25519 public key."""
        from cryptography.hazmat.primitives import serialization
        return self.public_key.public_bytes(  # type: ignore[attr-defined]
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw,
        )


def _check_private_key_perms(path: str, strict: bool = False) -> None:
    """Verify the private key file isn't world-readable.

    `strict=True` raises KeyMaterialError on any world or group read bit.
    Otherwise emits a UserWarning so the operator sees the issue without
    the daemon refusing to start in dev.
    """
    try:
        st = os.stat(path)
    except FileNotFoundError as exc:
        raise KeyMaterialError(f"ed25519 private key not found: {path}") from exc
    except OSError as exc:
        raise KeyMaterialError(f"cannot stat private key {path}: {exc}") from exc
    # Mask out file-type bits; only the permission triplet matters here.
    mode = stat.S_IMODE(st.st_mode)
    bad_bits = mode & (stat.S_IRWXG | stat.S_IRWXO)
    if bad_bits:
        msg = (
            f"private key {path!r} has permissive mode {oct(mode)}; "
            f"chmod to 0600 (owner read/write only)"
        )
        if strict:
            raise KeyMaterialError(msg)
        warnings.warn(msg, UserWarning, stacklevel=3)


def load_ed25519_public_key(path: str) -> "object":
    """Load a PEM-encoded Ed25519 public key for verification.

    Separate from Ed25519Signer so pure-verifier callers (facilitators,
    audit tools) don't need the private key or the signer object graph.
    """
    try:
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    except ImportError as exc:  # pragma: no cover - dep gate
        raise KeyMaterialError(
            "ed25519 verification requires the 'cryptography' package"
        ) from exc
    try:
        with open(path, "rb") as f:
            pub_pem = f.read()
    except OSError as exc:
        raise KeyMaterialError(f"cannot read ed25519 public key {path}: {exc}") from exc
    try:
        key = serialization.load_pem_public_key(pub_pem)
    except (ValueError, TypeError) as exc:
        raise KeyMaterialError(f"malformed PEM public key: {exc}") from exc
    if not isinstance(key, Ed25519PublicKey):
        raise KeyMaterialError(
            f"public key at {path} is not Ed25519 (got {type(key).__name__})"
        )
    return key


def generate_ed25519_keypair(out_prefix: str) -> tuple[str, str]:
    """Generate a fresh Ed25519 keypair, write it to disk, return paths.

    Writes:
        <out_prefix>.pem  -> PEM-encoded private key, mode 0600
        <out_prefix>.pub  -> PEM-encoded public key, mode 0644

    Used by the `tau-x402-cage keygen-ed25519 --out <prefix>` CLI
    subcommand. The out_prefix must not already exist so we don't silently
    clobber a key in production; callers wanting rotation should write to
    a new path and flip env vars.
    """
    try:
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    except ImportError as exc:  # pragma: no cover - dep gate
        raise KeyMaterialError(
            "ed25519 keygen requires the 'cryptography' package. "
            "Install the signing-ed25519 extra."
        ) from exc
    priv_path = f"{out_prefix}.pem"
    pub_path = f"{out_prefix}.pub"
    if os.path.exists(priv_path) or os.path.exists(pub_path):
        raise KeyMaterialError(
            f"refusing to overwrite existing key files at {priv_path!r} / {pub_path!r}"
        )
    private_key = Ed25519PrivateKey.generate()
    public_key = private_key.public_key()
    priv_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    pub_pem = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )
    # Create the private key file with 0600 from the start to avoid a
    # race where a world-readable file exists even briefly.
    fd = os.open(priv_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(priv_pem)
    except BaseException:
        # If we failed mid-write, don't leave a partial private key around.
        try:
            os.unlink(priv_path)
        except FileNotFoundError:
            pass
        raise
    with open(pub_path, "wb") as f:
        f.write(pub_pem)
    os.chmod(pub_path, 0o644)
    return priv_path, pub_path


@dataclass(frozen=True)
class ShadowInfo:
    """Shadow/advisory-mode metadata captured at signing time (v0.13.0).

    Passed to :func:`sign` / :func:`sign_ed25519` when the daemon is in
    shadow or advisory mode so the MAC input binds the mode + the
    would-have-rejected metadata. When the wire outcome is ``permit``
    AND the full admission check would have rejected, ``would_reject``
    is True and ``rule_id`` / ``reason_text`` carry the reason. When the
    full check also permitted, ``would_reject`` is False and rule_id /
    reason_text are None.
    """

    mode: str
    would_reject: bool = False
    rule_id: Optional[str] = None
    reason_text: Optional[str] = None


def sign(
    verdict: Verdict,
    intent: PaymentIntent,
    secret: bytes,
    now_unix: Optional[int] = None,
    revision: Optional["PolicyRevision"] = None,
    without_system: Optional[str] = None,
    shadow: Optional[ShadowInfo] = None,
    risk_amount_projected: Optional[str] = None,
) -> SignedEnvelope:
    """Sign a verdict for a specific intent with HMAC-SHA256.

    See :func:`sign_ed25519` for the asymmetric equivalent. Never reuse an
    envelope for a different intent.

    Args:
        verdict:  what the cage decided
        intent:   the payment intent this verdict is about, binds via intent_hash
        secret:   shared HMAC secret (cage ↔ facilitator). 32+ bytes recommended.
        now_unix: override for test determinism. Defaults to time.time().
        revision: optional PolicyRevision. When supplied, sign() emits a v2
                  envelope that MAC-binds the revision's provenance fields so
                  downstream verifiers can correlate the verdict to the exact
                  admitted policy state. When None, emits a legacy v1 envelope
                  (unchanged from pre-provenance cages, backward-compatible).
        shadow:   optional ShadowInfo (v0.13.0). When supplied, promotes to a
                  v2 envelope (even if no revision was given) and MAC-binds
                  the ``mode`` + shadow metadata fields. Tampering with any
                  of them at the wire fails verify().

    The `revision` parameter is keyword-only in spirit -- existing 3-arg
    callers (saas/, adapter/x402_client.py::mediate) keep working unchanged.
    """
    if len(secret) < 16:
        raise SignatureError("HMAC secret must be at least 16 bytes")
    ts = int(now_unix if now_unix is not None else time.time())
    ih = hash_intent(intent)
    version, prov = _revision_provenance(revision)
    # Promote v1 → v2 when any new v0.13+ field is supplied.
    if (
        without_system is not None
        or shadow is not None
        or risk_amount_projected is not None
    ) and version == WIRE_VERSION_V1:
        version = WIRE_VERSION_V2

    mac_bytes = hmac.new(
        secret,
        _canonical_mac_input(
            verdict.outcome,
            verdict.rule_id,
            verdict.witness,
            verdict.reason_text,
            ts,
            verdict.ttl_seconds,
            ih,
            version=version,
            policy_revision_id=prov["revision_id"],
            proof_backend=prov["backend"],
            proof_strength=prov["strength"],
            prover_mode=prov["mode"],
            compile_hash=prov["compile_hash"],
            algorithm=ALG_HMAC_SHA256,
            without_system=without_system,
            mode=shadow.mode if shadow is not None else None,
            shadow_would_reject=(
                shadow.would_reject if shadow is not None else None
            ),
            shadow_rule_id=shadow.rule_id if shadow is not None else None,
            shadow_reason_text=(
                shadow.reason_text if shadow is not None else None
            ),
            risk_amount_projected=risk_amount_projected,
        ),
        hashlib.sha256,
    ).digest()
    return SignedEnvelope(
        outcome=verdict.outcome,
        rule_id=verdict.rule_id,
        witness=verdict.witness,
        reason_text=verdict.reason_text,
        issued_at_unix=ts,
        ttl_seconds=verdict.ttl_seconds,
        intent_hash=ih,
        mac_hex=mac_bytes.hex(),
        mac_alg=MAC_ALG_LABELS[ALG_HMAC_SHA256],
        algorithm=ALG_HMAC_SHA256,
        version=version,
        policy_revision_id=prov["revision_id"],
        proof_backend=prov["backend"],
        proof_strength=prov["strength"],
        prover_mode=prov["mode"],
        compile_hash=prov["compile_hash"],
        without_system=without_system,
        mode=shadow.mode if shadow is not None else None,
        shadow_would_reject=(
            shadow.would_reject if shadow is not None else None
        ),
        shadow_rule_id=shadow.rule_id if shadow is not None else None,
        shadow_reason_text=(
            shadow.reason_text if shadow is not None else None
        ),
        risk_amount_projected=risk_amount_projected,
    )


def sign_ed25519(
    verdict: Verdict,
    intent: PaymentIntent,
    signer: Ed25519Signer,
    now_unix: Optional[int] = None,
    revision: Optional["PolicyRevision"] = None,
    without_system: Optional[str] = None,
    shadow: Optional[ShadowInfo] = None,
    risk_amount_projected: Optional[str] = None,
) -> SignedEnvelope:
    """Sign a verdict with Ed25519. Same semantics as :func:`sign`.

    The signer holds the cage's private key; downstream verifiers use the
    matching public key. Algorithm is bound into the canonical payload so
    an attacker cannot re-label the envelope as HMAC.

    Emits an envelope with `algorithm="ed25519"`. Call
    :func:`verify` with the matching public key to check it (keyword
    argument `public_key=...`). Don't pass the public key as `secret`;
    verify dispatches on `env.algorithm`.
    """
    ts = int(now_unix if now_unix is not None else time.time())
    ih = hash_intent(intent)
    version, prov = _revision_provenance(revision)
    # Promote v1 → v2 when any new v0.13+ field is supplied.
    if (
        without_system is not None
        or shadow is not None
        or risk_amount_projected is not None
    ) and version == WIRE_VERSION_V1:
        version = WIRE_VERSION_V2

    payload = _canonical_mac_input(
        verdict.outcome,
        verdict.rule_id,
        verdict.witness,
        verdict.reason_text,
        ts,
        verdict.ttl_seconds,
        ih,
        version=version,
        policy_revision_id=prov["revision_id"],
        proof_backend=prov["backend"],
        proof_strength=prov["strength"],
        prover_mode=prov["mode"],
        compile_hash=prov["compile_hash"],
        algorithm=ALG_ED25519,
        without_system=without_system,
        mode=shadow.mode if shadow is not None else None,
        shadow_would_reject=(
            shadow.would_reject if shadow is not None else None
        ),
        shadow_rule_id=shadow.rule_id if shadow is not None else None,
        shadow_reason_text=(
            shadow.reason_text if shadow is not None else None
        ),
        risk_amount_projected=risk_amount_projected,
    )
    signature = signer.sign_bytes(payload)
    return SignedEnvelope(
        outcome=verdict.outcome,
        rule_id=verdict.rule_id,
        witness=verdict.witness,
        reason_text=verdict.reason_text,
        issued_at_unix=ts,
        ttl_seconds=verdict.ttl_seconds,
        intent_hash=ih,
        mac_hex=signature.hex(),
        mac_alg=MAC_ALG_LABELS[ALG_ED25519],
        algorithm=ALG_ED25519,
        version=version,
        policy_revision_id=prov["revision_id"],
        proof_backend=prov["backend"],
        proof_strength=prov["strength"],
        prover_mode=prov["mode"],
        compile_hash=prov["compile_hash"],
        without_system=without_system,
        mode=shadow.mode if shadow is not None else None,
        shadow_would_reject=(
            shadow.would_reject if shadow is not None else None
        ),
        shadow_rule_id=shadow.rule_id if shadow is not None else None,
        shadow_reason_text=(
            shadow.reason_text if shadow is not None else None
        ),
        risk_amount_projected=risk_amount_projected,
    )


def _revision_provenance(
    revision: Optional["PolicyRevision"],
) -> tuple[str, dict]:
    """Unpack a PolicyRevision into (wire_version, provenance dict).

    Extracted so the HMAC and ed25519 signers don't have to duplicate the
    v1/v2 dispatch. Returns the legacy v1 shape when no revision is given.
    """
    if revision is None:
        return (
            WIRE_VERSION_V1,
            {
                "revision_id": None,
                "backend": None,
                "strength": None,
                "mode": None,
                "compile_hash": None,
            },
        )
    return (
        WIRE_VERSION_V2,
        {
            "revision_id": revision.revision_id,
            "backend": revision.proof_backend,
            "strength": revision.proof_strength,
            "mode": revision.prover_mode,
            "compile_hash": revision.compile_hash,
        },
    )


def verify(
    env: SignedEnvelope,
    intent: PaymentIntent,
    secret: Optional[bytes] = None,
    now_unix: Optional[int] = None,
    *,
    public_key: Optional[object] = None,
    replay_cache: Optional[ReplayCache] = None,
) -> None:
    """Verify the envelope was issued for this intent, not expired, not tampered.

    Dispatches on `env.algorithm`:

    * ``hmac-sha256`` — requires the shared secret via the ``secret`` arg.
      Position-compatible with the pre-v0.7 three-arg call.
    * ``ed25519`` — requires the cage's public key (an Ed25519PublicKey, or
      the object returned by :func:`load_ed25519_public_key`) via the
      keyword-only ``public_key`` arg.

    ``replay_cache`` is optional and, when supplied, enforces one-time-use
    within the envelope's TTL window. The first successful verify marks
    ``(intent_hash, mac_hex)`` as seen; subsequent verifies of the same
    envelope raise :class:`SignatureError`. Leaving it ``None`` preserves
    the legacy stateless contract for callers that need retry semantics.

    Raises:
        SignatureError: intent mismatch, signature mismatch, wrong key
                        material, algorithm mismatch, unsupported alg, or
                        envelope already consumed (with ``replay_cache``).
        VerdictExpired: TTL has elapsed.
    """
    expected_ih = hash_intent(intent)
    # Check intent binding before signature, intent_hash mismatch is cheaper
    # to compute and leaks less about the secret than a timing-sensitive compare.
    if not hmac.compare_digest(env.intent_hash, expected_ih):
        raise SignatureError(
            "intent_hash mismatch, envelope was issued for a different intent (replay attempt?)"
        )
    payload = _canonical_mac_input(
        env.outcome,
        env.rule_id,
        env.witness,
        env.reason_text,
        env.issued_at_unix,
        env.ttl_seconds,
        env.intent_hash,
        version=env.version,
        policy_revision_id=env.policy_revision_id,
        proof_backend=env.proof_backend,
        proof_strength=env.proof_strength,
        prover_mode=env.prover_mode,
        compile_hash=env.compile_hash,
        algorithm=env.algorithm,
        without_system=env.without_system,
        mode=env.mode,
        shadow_would_reject=env.shadow_would_reject,
        shadow_rule_id=env.shadow_rule_id,
        shadow_reason_text=env.shadow_reason_text,
        risk_amount_projected=env.risk_amount_projected,
    )
    if env.algorithm == ALG_HMAC_SHA256:
        if secret is None:
            raise SignatureError(
                "HMAC envelope verification requires the shared 'secret' argument"
            )
        expected_mac = hmac.new(secret, payload, hashlib.sha256).hexdigest()
        if not hmac.compare_digest(env.mac_hex, expected_mac):
            raise SignatureError("MAC verification failed, envelope tampered or wrong secret")
    elif env.algorithm == ALG_ED25519:
        if public_key is None:
            raise SignatureError(
                "ed25519 envelope verification requires the 'public_key' keyword argument"
            )
        try:
            from cryptography.exceptions import InvalidSignature
        except ImportError as exc:  # pragma: no cover - dep gate
            raise SignatureError(
                "ed25519 verification requires the 'cryptography' package"
            ) from exc
        try:
            signature = bytes.fromhex(env.mac_hex)
        except ValueError as exc:
            raise SignatureError(f"ed25519 signature is not valid hex: {exc}") from exc
        try:
            public_key.verify(signature, payload)  # type: ignore[attr-defined]
        except InvalidSignature as exc:
            raise SignatureError(
                "ed25519 verification failed, envelope tampered or wrong public key"
            ) from exc
    else:
        raise SignatureError(
            f"unsupported envelope algorithm: {env.algorithm!r}; "
            f"expected one of {list(SUPPORTED_ALGORITHMS)}"
        )
    ts = int(now_unix if now_unix is not None else time.time())
    if ts > env.issued_at_unix + env.ttl_seconds:
        raise VerdictExpired(
            f"verdict issued at {env.issued_at_unix} with TTL {env.ttl_seconds}s; "
            f"now {ts} is past expiry {env.issued_at_unix + env.ttl_seconds}"
        )
    if replay_cache is not None:
        if replay_cache.is_seen(env.intent_hash, env.mac_hex):
            raise SignatureError(
                "envelope already consumed within TTL window (replay attempt)"
            )
        replay_cache.mark_seen(
            env.intent_hash,
            env.mac_hex,
            expires_at_unix=env.issued_at_unix + env.ttl_seconds,
            now_unix=ts,
        )
