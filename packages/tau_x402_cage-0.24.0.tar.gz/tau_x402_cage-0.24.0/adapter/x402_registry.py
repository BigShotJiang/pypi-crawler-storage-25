"""X402Registry: immutable container of declared x402 invariants.

Holds the eight x402 Invariant subclasses (SpendingCap, MaxPerCall,
ProviderAllowlist, RetryRateLimit, RollingWindowCap, JurisdictionRule,
MutualExclusion, CounterpartyConstraint) and evaluates a PaymentIntent
against all of them.

Every declare() / retract() returns a new registry; the daemon swaps the
reference atomically. Immutability keeps concurrent `check_payment` calls
correct while declare/retract runs.

Contradiction detection at declare time (H-01 from the security review) is
handled by the daemon's ConsistencyProver (Tau for fragment v1, z3 for
fragment v2); that path is separate from this registry's per-call check.

v0.21.0 adds :meth:`check_payment_composed` which returns every violation
plus near-threshold rules in a single pass. The legacy :meth:`check_payment`
keeps its first-violation semantics unchanged for backwards compatibility.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable, Optional

from adapter.composition import (
    DEFAULT_NEAR_THRESHOLD_FRACTION,
    CompositionResult,
    analyze_composition,
)
from adapter.invariants import Invariant, Violation
from adapter.payment_intent_matcher import PaymentIntent


@dataclass(frozen=True)
class X402Registry:
    """Immutable set of active x402 invariants."""

    invariants: tuple[Invariant, ...] = field(default_factory=tuple)

    @classmethod
    def empty(cls) -> "X402Registry":
        return cls(invariants=tuple())

    def declare(self, inv: Invariant) -> "X402Registry":
        if inv in self.invariants:
            return self
        return X402Registry(invariants=self.invariants + (inv,))

    def retract(self, inv: Invariant) -> "X402Registry":
        return X402Registry(invariants=tuple(i for i in self.invariants if i != inv))

    def check_payment(
        self,
        intent: PaymentIntent,
        history: Iterable[PaymentIntent],
        rejects: Iterable[PaymentIntent] = (),
    ) -> Optional[Violation]:
        """Evaluate intent against all active invariants in declaration order.

        Returns the FIRST violation found, or None if all invariants are satisfied.
        Declaration-order traversal means users see the earliest-added rule that
        fires first, which matches how policy-as-code is typically read.

        `rejects` is only consulted by RetryRateLimit; other invariants ignore it.
        """
        history_tuple = tuple(history)
        rejects_tuple = tuple(rejects)
        for inv in self.invariants:
            v = inv.check_payment(intent, history_tuple, rejects_tuple)
            if v is not None:
                return v
        return None

    def check_payment_composed(
        self,
        intent: PaymentIntent,
        history: Iterable[PaymentIntent],
        rejects: Iterable[PaymentIntent] = (),
        *,
        near_threshold_fraction: float = DEFAULT_NEAR_THRESHOLD_FRACTION,
    ) -> CompositionResult:
        """Evaluate every invariant; return all violations + near-thresholds.

        Complementary to :meth:`check_payment` — the fast path returns
        the first violation so the daemon's hot path stays shape-stable.
        This method runs the full sweep so the decision envelope can
        surface:

          * every rule_id that fired on this intent (supports the
            ``composed_constraint_violation`` envelope reason).
          * every rule within ``near_threshold_fraction`` of firing
            (supports the ``near_thresholds`` envelope field).

        Pure function: does not mutate the registry.
        """
        return analyze_composition(
            self,
            intent,
            history,
            rejects,
            near_threshold_fraction=near_threshold_fraction,
        )
