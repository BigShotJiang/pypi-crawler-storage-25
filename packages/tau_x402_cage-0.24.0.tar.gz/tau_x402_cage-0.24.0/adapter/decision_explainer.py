"""Per-decision explainer (v0.17.0).

Turns a stored verdict record into an operator-friendly narrative: a
one-line summary, a full paragraph, the rule that fired, the behaviour
that was witnessed, and a plain-English prescription for what would
unblock the payment next time.

Motivation
----------
Agents and operators don't want to read raw ``rule_id`` / ``witness``
pairs. They want to know, in English: *why* was this blocked, *what*
was observed, and *what* change would allow the payment if the caller
genuinely needs to spend. Surfacing that as a first-class daemon op
makes the fail-closed reject actionable rather than just an error.

Surface contract (stability commitment)
---------------------------------------
For a given ``rule_id``, the narrative **structure** is stable across
versions: the opening clause names the class, the middle clause names
the witnessed numbers, and the closing clause names the remedy. We may
tune phrasing / examples, but callers that pattern-match on the
structure (machine-readable field names, rule_id prefixes, integer
counts) keep working. Call this the "explainer-v1" contract.

Design choices
--------------
* **Pure function** — takes a verdict record + the ``Registry`` +
  optional ``history_store`` and returns a frozen dataclass. Never
  mutates state, never does I/O.
* **Class-aware describers** — each invariant class gets a dedicated
  describer keyed on the stable ``rule_id`` enum. Unknown / future
  rule_ids fall back to a conservative describer so new classes still
  render something useful.
* **Witness-driven** — every describer consumes the structured
  ``witness`` string the invariant emitted at rejection time. We parse
  it (rather than reaching back into the live registry) so the
  explainer works offline against a historical record.
* **Immutability** — the output dataclass is frozen. Internal buckets
  are owned locally; caller inputs are read-only.

Scope boundaries
----------------
* Not a merge-conflict renderer. That's ``conflict_renderer.py``.
* Not a policy linter or prover. Those are ``policy_linter.py`` /
  ``tau_compiler.py`` / ``z3_compiler.py``.
* Not a counterfactual (with vs without). That's ``safety_comparison.py``.
* Does not re-run the rule. If the witness is missing, the describer
  returns a best-effort fallback rather than re-invoking the invariant.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation
from typing import Any, Dict, Mapping, Optional, Sequence, Tuple


# ── output dataclass ─────────────────────────────────────────────────────────


@dataclass(frozen=True)
class DecisionExplanation:
    """Structured, operator-friendly explanation of a single cage verdict.

    Fields:
        summary              : One-line narrative suitable for a log
                               preview or a dashboard row.
        narrative            : Full paragraph: opens with what happened,
                               names the witnessed numbers, ends with
                               the remedy.
        machine_readable     : Structured dict mirroring the narrative
                               fields so downstream tooling (SaaS UI,
                               Slack bots, MCP agents) don't parse prose.
        rule_id              : The rule that fired (``None`` on permit).
        invariant_class      : Python class name that owns the rule_id
                               (stable across versions). ``None`` when
                               the rule_id is unattributed.
        witnessed_behavior   : What the cage saw, as a structured dict
                               (parsed from the stored witness string).
                               Keys stable per ``rule_id``.
        what_would_allow     : Plain-English prescription: the smallest
                               change the operator could make that
                               would admit a similar intent next time.
                               Never leaks secrets or per-customer data.
        retry_after_seconds  : For cooldown-style rules, the seconds
                               remaining until the block auto-lifts.
                               ``None`` when the rule is not time-bound.
        outcome              : ``"permit"`` / ``"reject"``. A permit
                               explanation records why nothing fired
                               (useful for dashboards' "silent" rows).
    """

    summary: str
    narrative: str
    machine_readable: Dict[str, Any] = field(default_factory=dict)
    rule_id: Optional[str] = None
    invariant_class: Optional[str] = None
    witnessed_behavior: Dict[str, Any] = field(default_factory=dict)
    what_would_allow: str = ""
    retry_after_seconds: Optional[int] = None
    outcome: str = "reject"

    def to_wire(self) -> Dict[str, Any]:
        """Serialise to a JSON-safe dict for daemon wire transport."""
        return {
            "summary": self.summary,
            "narrative": self.narrative,
            "machine_readable": dict(self.machine_readable),
            "rule_id": self.rule_id,
            "invariant_class": self.invariant_class,
            "witnessed_behavior": dict(self.witnessed_behavior),
            "what_would_allow": self.what_would_allow,
            "retry_after_seconds": self.retry_after_seconds,
            "outcome": self.outcome,
        }


# ── stable rule_id → invariant class map ─────────────────────────────────────


#: Single source of truth for "which Python class emits this rule_id".
#: Kept here and in ``safety_comparison._RULE_ID_TO_CLASS``; the two maps
#: cover overlapping keys on purpose so a new rule_id added in one
#: module doesn't silently orphan the other.
_RULE_ID_TO_CLASS: Dict[str, str] = {
    "max_per_call": "MaxPerCall",
    "spending_cap_per_tx": "SpendingCap",
    "spending_cap_per_window": "SpendingCap",
    "spending_cap_per_provider_per_window": "SpendingCap",
    "provider_allowlist": "ProviderAllowlist",
    "retry_rate_limit": "RetryRateLimit",
    "rolling_window_cap_provider": "RollingWindowCap",
    "rolling_window_cap_counterparty": "RollingWindowCap",
    "rolling_window_cap_global": "RollingWindowCap",
    "mutual_exclusion": "MutualExclusion",
    "counterparty_sanctioned": "CounterpartyConstraint",
    "counterparty_not_approved": "CounterpartyConstraint",
    "instability_guard": "InstabilityGuard",
    "burst_velocity_cap": "BurstVelocityCap",
    "cross_revision_violation": "CrossRevisionViolation",
    "governance_violation": "GovernanceViolation",
    "policy_inconclusive": "PolicyInconclusive",
    "cage_unavailable": "CageUnavailable",
    # v0.21.0 (agent A) — adaptive-tightening owns its own describer.
    "adaptive_tightening": "AdaptiveTightening",
    # v0.21.0 (agent B) — composed-violation pseudo rule_id for the
    # envelope where ``reason=="composed_constraint_violation"`` and no
    # single rule_id is authoritative.
    "composed_constraint_violation": "ComposedConstraintViolation",
    # v0.21.0 (agent B) — revision-transition-runtime pseudo rule_id for
    # cross-revision runtime warnings (not a rule-class violation).
    "revision_transition_violation": "RevisionTransitionRuntime",
}


def _resolve_invariant_class(rule_id: Optional[str]) -> Optional[str]:
    """Map a rule_id string to its owning Python class name.

    Uses the static map first; falls back to ``jurisdiction_<code>.*``
    prefix handling so nested JurisdictionRule ids resolve. Unknown
    rule_ids return ``None`` so callers can branch on "do we know this?"
    """
    if rule_id is None:
        return None
    if rule_id.startswith("jurisdiction_"):
        return "JurisdictionRule"
    return _RULE_ID_TO_CLASS.get(rule_id)


# ── witness parser ───────────────────────────────────────────────────────────


def _parse_witness(witness: Optional[str]) -> Dict[str, str]:
    """Parse the ``key=value,key=value`` shape that invariants emit.

    Witnesses are deliberately structured strings (not JSON) so the
    facilitator sees them verbatim in a response body. Here we turn
    them back into a dict for downstream describers. Missing / empty
    witnesses produce ``{}`` rather than raising — historical records
    may predate the structured witness convention.
    """
    if not witness:
        return {}
    parts = [p.strip() for p in witness.split(",") if p.strip()]
    out: Dict[str, str] = {}
    for p in parts:
        if "=" not in p:
            continue
        k, _, v = p.partition("=")
        out[k.strip()] = v.strip()
    return out


def _decimal_or_none(s: Optional[str]) -> Optional[Decimal]:
    """Best-effort Decimal parse. Returns ``None`` on failure / missing."""
    if s is None:
        return None
    try:
        return Decimal(str(s))
    except (InvalidOperation, TypeError, ValueError):
        return None


def _int_or_none(s: Optional[str]) -> Optional[int]:
    if s is None:
        return None
    # Strip trailing unit suffixes such as "42s" → 42.
    txt = str(s).rstrip("sS ")
    try:
        return int(txt)
    except (TypeError, ValueError):
        return None


def _is_number(value: Any) -> bool:
    """Return True iff ``value`` is coercible to float for near-threshold entries."""
    if isinstance(value, bool):
        return False
    if isinstance(value, (int, float)):
        return True
    try:
        float(value)
        return True
    except (TypeError, ValueError):
        return False


def _optional_str(value: Any) -> Optional[str]:
    """Coerce a record field to ``str`` if present, else ``None``."""
    if value is None:
        return None
    return str(value)


# ── per-class describers ─────────────────────────────────────────────────────


#: Default reason summary when the record predates v0.17 and has no
#: ``reason_text``. Every describer still gets a structured narrative.
_FALLBACK_REASON = "Blocked by cage policy."


def _describe_max_per_call(
    witness: Dict[str, str],
    reason_text: Optional[str],
    currency: str,
) -> tuple[str, str, Dict[str, Any], str]:
    intent_amt = witness.get("intent", "?")
    cap_amt = witness.get("cap", "?")
    summary = (
        f"Blocked: single-call amount {intent_amt} {currency} "
        f"exceeds cap {cap_amt} {currency}."
    )
    narrative = (
        f"The payment was blocked because a MaxPerCall invariant caps any "
        f"single payment at {cap_amt} {currency}, and this intent requested "
        f"{intent_amt} {currency}. The per-call ceiling is enforced on every "
        f"payment independently of rolling-window or cumulative caps."
    )
    machine = {
        "intent_amount": intent_amt,
        "cap_amount": cap_amt,
        "currency": currency,
    }
    remedy = (
        f"Raise the MaxPerCall cap above {intent_amt} {currency}, "
        f"or split the payment into smaller calls that each fit under "
        f"{cap_amt} {currency}."
    )
    return summary, narrative, machine, remedy


def _describe_spending_cap(
    rule_id: str,
    witness: Dict[str, str],
    reason_text: Optional[str],
    currency: str,
) -> tuple[str, str, Dict[str, Any], str]:
    scope = rule_id.replace("spending_cap_", "")
    if scope == "per_tx":
        # per_tx emits witness keys intent, cap
        intent_amt = witness.get("intent", "?")
        cap_amt = witness.get("cap", "?")
        summary = (
            f"Blocked: per-transaction spend cap {cap_amt} {currency} "
            f"exceeded (intent {intent_amt})."
        )
        narrative = (
            f"A SpendingCap(per_tx) invariant caps any single transaction at "
            f"{cap_amt} {currency}. This intent requested {intent_amt} {currency}, "
            f"which is above the ceiling. The cage rejected before the payment "
            f"left the agent's budget."
        )
        machine = {
            "scope": "per_tx",
            "intent_amount": intent_amt,
            "cap_amount": cap_amt,
            "currency": currency,
        }
        remedy = (
            f"Raise the SpendingCap(per_tx) above {intent_amt} {currency}, "
            f"or lower the intent amount."
        )
        return summary, narrative, machine, remedy
    # per_window or per_provider_per_window: witness carries cumulative, cap, window
    cumulative = witness.get("cumulative", "?")
    cap_amt = witness.get("cap", "?")
    window = witness.get("window", "?")
    window_label = "60s window"
    if window != "?":
        window_label = f"{window} window"
    scope_label = (
        "provider-scoped rolling-window"
        if scope == "per_provider_per_window"
        else "rolling-window"
    )
    summary = (
        f"Blocked: {cumulative} {currency} would exceed {scope_label} cap "
        f"{cap_amt} {currency} over the {window_label}."
    )
    narrative = (
        f"A SpendingCap({scope}) invariant caps cumulative spend at "
        f"{cap_amt} {currency} over the {window_label}. Including this intent, "
        f"cumulative spend would reach {cumulative} {currency}. The cage "
        f"rejected before the threshold was crossed."
    )
    machine = {
        "scope": scope,
        "cumulative": cumulative,
        "cap_amount": cap_amt,
        "window": window,
        "currency": currency,
    }
    remedy = (
        f"Wait for earlier payments to roll out of the {window_label}, "
        f"raise the SpendingCap({scope}) above {cumulative} {currency}, "
        f"or route the intent to a provider with remaining headroom."
    )
    return summary, narrative, machine, remedy


def _describe_retry_rate_limit(
    witness: Dict[str, str],
    reason_text: Optional[str],
) -> tuple[str, str, Dict[str, Any], str, Optional[int]]:
    # RetryRateLimit uses min_gap_seconds. Many operator-friendly variants
    # of the same intent (burst-threshold phrasing) live here because it's
    # the "cooldown" class every user reads first.
    gap = witness.get("gap")
    minimum = witness.get("min")
    # Retry phrasing — prefer the spec's shape if the witness carries
    # burst-threshold fields, else fall back to gap/min.
    call_count = _int_or_none(witness.get("call_count"))
    interval = _int_or_none(witness.get("interval_seconds"))
    threshold = _int_or_none(witness.get("burst_threshold"))
    window = _int_or_none(witness.get("window_seconds"))
    cooldown = _int_or_none(witness.get("cooldown_seconds"))
    endpoint = witness.get("endpoint") or witness.get("provider")
    # Prefer the "burst threshold" phrasing when we have the enriched
    # witness. Callers who only emit min_gap_seconds still get the gap/min
    # phrasing.
    if call_count is not None and threshold is not None and interval is not None:
        window_label = window or 30
        cooldown_label = cooldown or 0
        endpoint_phrase = f" to {endpoint}" if endpoint else ""
        summary = (
            f"Blocked: {call_count} paid calls{endpoint_phrase} in "
            f"{interval} seconds, exceeding burst threshold of {threshold}."
        )
        narrative = (
            f"Blocked because this agent attempted {call_count} paid "
            f"calls{endpoint_phrase} in {interval} seconds, exceeding the "
            f"current burst threshold of {threshold}."
        )
        if window is not None:
            narrative += (
                f" The RetryRateLimit invariant counts paid calls over a "
                f"{window_label}-second window."
            )
        if cooldown_label:
            narrative += (
                f" Cooldown remains active for {cooldown_label} seconds."
            )
        machine = {
            "call_count": call_count,
            "interval_seconds": interval,
            "burst_threshold": threshold,
            "window_seconds": window_label,
            "cooldown_seconds": cooldown_label,
            "endpoint": endpoint,
        }
        remedy = (
            f"Wait for the cooldown to expire "
            f"({cooldown_label} seconds), "
            f"or raise the RetryRateLimit burst threshold above {call_count}."
        )
        return summary, narrative, machine, remedy, cooldown_label
    # Minimum-gap phrasing (matches the current invariant's default witness).
    gap_str = gap or "?"
    min_str = minimum or "?"
    gap_i = _int_or_none(gap)
    min_i = _int_or_none(minimum)
    remaining: Optional[int] = None
    if gap_i is not None and min_i is not None and gap_i < min_i:
        remaining = min_i - gap_i
    summary = (
        f"Blocked: retry {gap_str}s after previous reject; "
        f"RetryRateLimit requires a {min_str}s gap."
    )
    narrative = (
        f"A RetryRateLimit invariant requires at least {min_str} seconds "
        f"between retries after a reject. This intent arrived {gap_str} "
        f"seconds after the last reject, so the cage held it off."
    )
    if remaining is not None:
        narrative += (
            f" Cooldown remains active for {remaining} seconds."
        )
    machine: Dict[str, Any] = {
        "gap_seconds": gap_i,
        "min_gap_seconds": min_i,
        "remaining_cooldown_seconds": remaining,
    }
    remedy = (
        f"Wait {remaining if remaining is not None else 'the remaining'} "
        f"seconds for the cooldown to expire, or relax the RetryRateLimit "
        f"min_gap_seconds if the upstream is idempotent."
    )
    return summary, narrative, machine, remedy, remaining


def _describe_provider_allowlist(
    witness: Dict[str, str],
    reason_text: Optional[str],
) -> tuple[str, str, Dict[str, Any], str]:
    provider = witness.get("provider", "?")
    # The allowlist is not directly encoded in the witness; surface it
    # from the reason_text when available, else leave "allowlist".
    allowlist_m = re.search(r"\[(.*?)\]", reason_text or "")
    allowlist = allowlist_m.group(1) if allowlist_m else "the approved set"
    summary = (
        f"Blocked: provider {provider!r} is not in the approved allowlist."
    )
    narrative = (
        f"A ProviderAllowlist invariant restricts outbound payments to an "
        f"approved set of upstream providers. The intent targeted "
        f"{provider!r}, which is not on the list ({allowlist}). The cage "
        f"rejected before the payment left the agent."
    )
    machine = {"provider": provider, "allowlist": allowlist}
    remedy = (
        f"Add {provider!r} to the ProviderAllowlist, or route the intent "
        f"to an already-approved provider."
    )
    return summary, narrative, machine, remedy


def _describe_mutual_exclusion(
    witness: Dict[str, str],
    reason_text: Optional[str],
) -> tuple[str, str, Dict[str, Any], str]:
    provider = witness.get("provider", "?")
    overlap = witness.get("overlap", "?")
    summary = (
        f"Blocked: provider {provider!r} sits in two mutually-exclusive "
        f"rule groups."
    )
    narrative = (
        f"A MutualExclusion invariant forbids providers from appearing in "
        f"both rule groups simultaneously. The intent's provider {provider!r} "
        f"is in the overlap set {overlap}, which cannot fire at the same "
        f"time as the sibling group."
    )
    machine = {"provider": provider, "overlap": overlap}
    remedy = (
        f"Move {provider!r} out of one of the mutually-exclusive groups, "
        f"or route the intent through a provider that is in exactly one "
        f"group."
    )
    return summary, narrative, machine, remedy


def _describe_counterparty(
    rule_id: str,
    witness: Dict[str, str],
    reason_text: Optional[str],
) -> tuple[str, str, Dict[str, Any], str]:
    counterparty = witness.get("counterparty", "?")
    if rule_id == "counterparty_sanctioned":
        summary = (
            f"Blocked: counterparty {counterparty!r} is on the sanctions list."
        )
        narrative = (
            f"A CounterpartyConstraint invariant marks {counterparty!r} as "
            f"sanctioned. The cage blocks any payment from or to sanctioned "
            f"counterparties at admission time."
        )
        remedy = (
            f"Remove {counterparty!r} from the sanctioned set only if the "
            f"compliance listing has changed; otherwise route the payment "
            f"via an unaffected counterparty."
        )
    else:
        summary = (
            f"Blocked: counterparty {counterparty!r} is not in the approved set."
        )
        narrative = (
            f"A CounterpartyConstraint invariant restricts payments to an "
            f"approved set of counterparties. The intent targeted "
            f"{counterparty!r}, which is not on the list."
        )
        remedy = (
            f"Add {counterparty!r} to the CounterpartyConstraint approved "
            f"set, or route the intent via an already-approved counterparty."
        )
    machine = {"counterparty": counterparty, "rule_id": rule_id}
    return summary, narrative, machine, remedy


def _describe_rolling_window(
    rule_id: str,
    witness: Dict[str, str],
    reason_text: Optional[str],
) -> tuple[str, str, Dict[str, Any], str]:
    count = witness.get("count", "?")
    cap = witness.get("cap", "?")
    window = witness.get("window", "?")
    group_by = rule_id.replace("rolling_window_cap_", "")
    summary = (
        f"Blocked: {count} {group_by}-scoped calls in the {window} window "
        f"exceeds cap {cap}."
    )
    narrative = (
        f"A RollingWindowCap invariant grouped by {group_by} caps calls at "
        f"{cap} per {window} window. The counter is now at {count}, so the "
        f"cage rejected before it crossed."
    )
    machine = {
        "group_by": group_by,
        "count": count,
        "cap": cap,
        "window": window,
    }
    remedy = (
        f"Raise the RollingWindowCap max_count, shorten the window, or "
        f"wait for earlier calls to roll out of the {window} interval."
    )
    return summary, narrative, machine, remedy


def _describe_instability_guard(
    witness: Dict[str, str],
    reason_text: Optional[str],
    currency: str,
) -> tuple[str, str, Dict[str, Any], str]:
    provider = witness.get("provider", "?")
    rejects = witness.get("recent_rejects", "?")
    threshold = witness.get("threshold", "?")
    tighten_to = witness.get("tighten_to", "?")
    intent_amt = witness.get("intent", "?")
    summary = (
        f"Blocked: InstabilityGuard active on {provider!r} after "
        f"{rejects} rejects in the last window; tightened cap "
        f"{tighten_to} {currency} < requested {intent_amt} {currency}."
    )
    narrative = (
        f"An InstabilityGuard invariant tightens the per-provider cap to "
        f"{tighten_to} {currency} after {threshold} rejects for {provider!r}. "
        f"The guard counted {rejects} recent rejects, so the cap is hot. This "
        f"intent requested {intent_amt} {currency}, above the tightened "
        f"ceiling, so it was blocked."
    )
    machine = {
        "provider": provider,
        "recent_rejects": rejects,
        "reject_threshold": threshold,
        "tighten_to": tighten_to,
        "intent_amount": intent_amt,
        "currency": currency,
    }
    remedy = (
        f"Let the provider stabilise: wait for the recovery_seconds window "
        f"to elapse without new rejects, lower the intent amount under "
        f"{tighten_to} {currency}, or raise tighten_to if operational "
        f"conditions have genuinely improved."
    )
    return summary, narrative, machine, remedy


def _describe_burst_velocity(
    witness: Dict[str, str],
    reason_text: Optional[str],
    currency: str,
) -> tuple[str, str, Dict[str, Any], str]:
    rate = witness.get("spend_rate", "?")
    cap = witness.get("cap_rate", "?")
    window = witness.get("window", "60")
    summary = (
        f"Blocked: cross-provider spend velocity {rate} {currency}/s over "
        f"{window}s exceeds cap {cap} {currency}/s."
    )
    narrative = (
        f"A BurstVelocityCap invariant watches cross-provider spend rate "
        f"over a rolling {window}-second window. The observed rate is "
        f"{rate} {currency}/s, which is above the {cap} {currency}/s "
        f"ceiling. The cage rejected to hold velocity under the cap."
    )
    machine = {
        "spend_rate": rate,
        "cap_rate": cap,
        "window_seconds": window,
        "currency": currency,
    }
    remedy = (
        f"Throttle outbound requests, extend the velocity window, or raise "
        f"the BurstVelocityCap cap_rate if the business owner has signed off."
    )
    return summary, narrative, machine, remedy


def _describe_cross_revision(
    witness: Dict[str, str],
    reason_text: Optional[str],
) -> tuple[str, str, Dict[str, Any], str]:
    rule = witness.get("rule", "?")
    old_value = witness.get("old_value", "?")
    new_value = witness.get("new_value", "?")
    branch = witness.get("branch", "main")
    summary = (
        f"Blocked: proposed mutation would weaken monitored limit "
        f"{rule} from {old_value} to {new_value} on branch {branch}."
    )
    narrative = (
        f"A CrossRevisionViolation fired because the pending mutation "
        f"would weaken the monitored limit {rule}: the active revision "
        f"has {old_value} and the candidate has {new_value}. Weakening "
        f"a monitored limit requires explicit governance approval; the "
        f"cage refused the mutation at declare time."
    )
    machine = {
        "rule": rule,
        "old_value": old_value,
        "new_value": new_value,
        "branch": branch,
    }
    remedy = (
        f"Keep the limit at or stricter than {old_value}, route the change "
        f"through the governance approval queue, or move the mutation to a "
        f"branch that isn't monitored."
    )
    return summary, narrative, machine, remedy


def _describe_governance_violation(
    witness: Dict[str, str],
    reason_text: Optional[str],
) -> tuple[str, str, Dict[str, Any], str]:
    actor = witness.get("actor", "?")
    cls = witness.get("class", "?")
    summary = (
        f"Blocked: actor {actor!r} is not authorized to propose {cls}."
    )
    narrative = (
        f"A GovernanceViolation fired at proposal-submit time because the "
        f"actor {actor!r} lacks the role required to propose changes to "
        f"{cls}. The proposal was rejected before entering the approval queue."
    )
    machine = {"actor": actor, "invariant_class": cls}
    remedy = (
        f"Have an authorized actor submit the proposal, or grant the "
        f"actor {actor!r} the role required for {cls} changes."
    )
    return summary, narrative, machine, remedy


def _describe_adaptive_tightening(
    witness: Dict[str, str],
    reason_text: Optional[str],
    currency: str,
) -> tuple[str, str, Dict[str, Any], str, Optional[int]]:
    """Describer for the 15th decision class (v0.21.0) — adaptive tightening.

    Witnesses carry:

        level=<0..1>, trigger=<trigger_label>,
        max_requests=<N>, cooldown_seconds=<N>,
        prevented_spend=<decimal>, half_life=<seconds>

    Any of these may be missing on older records; the describer falls
    back to ``?`` rather than raising.
    """
    level_raw = witness.get("level", "?")
    trigger = witness.get("trigger", "adaptive clamp")
    max_requests = witness.get("max_requests", "?")
    cooldown_seconds = witness.get("cooldown_seconds", "?")
    prevented_spend = witness.get("prevented_spend", "?")
    half_life = witness.get("half_life", "900")
    cooldown_int = _int_or_none(cooldown_seconds)
    # Pretty-print level to 1 d.p. when the witness was numeric.
    level_display = level_raw
    try:
        lvl_f = float(level_raw)
        level_display = f"{lvl_f:.1f}"
    except (TypeError, ValueError):
        pass
    trigger_phrase = trigger.replace("_", " ")
    summary = (
        f"Request blocked by adaptive tightening "
        f"(level {level_display}, trigger: {trigger_phrase})."
    )
    narrative = (
        f"Request blocked by adaptive tightening (level {level_display}, "
        f"trigger: {trigger_phrase}). Adjusted limit: max {max_requests} "
        f"requests per {cooldown_seconds}s cooldown. "
        f"Estimated spend blocked: {prevented_spend} {currency} in the "
        f"next 60s at current trajectory. "
        f"Baseline limits restore after ~{half_life}s of quiet."
    )
    machine: Dict[str, Any] = {
        "tightening_level": level_raw,
        "trigger": trigger,
        "adjusted_max_requests": max_requests,
        "adjusted_cooldown_seconds": cooldown_seconds,
        "prevented_spend": prevented_spend,
        "currency": currency,
        "half_life_seconds": half_life,
    }
    remedy = (
        "Wait for the adaptive clamp to decay toward baseline "
        f"(~{half_life}s half-life). Reduce retry rate, stop submitting "
        "identical intents, or slow spend velocity to drop the tightening "
        "level. The baseline policy is unchanged; only the transient "
        "clamp is blocking."
    )
    return summary, narrative, machine, remedy, cooldown_int


def _describe_composed_violation(
    witness: Dict[str, str],
    reason_text: Optional[str],
    violations: Sequence[str],
    near_thresholds: Mapping[str, float],
) -> tuple[str, str, Dict[str, Any], str]:
    """Render the ``composed_constraint_violation`` envelope case (v0.21.0).

    The describer lists every rule_id that fired on the same intent plus
    any invariants that were near-threshold at decision time. Callers
    that pattern-match on structure get stable keys:

      * ``machine_readable["violations"]`` — list of rule_ids.
      * ``machine_readable["near_thresholds"]`` — map of rule_id → float
        in ``[0.0, 1.0]``.
    """
    violation_list = list(violations)
    near_map = dict(near_thresholds)
    # Heading — "A AND B" phrasing when exactly two rules, comma-list
    # otherwise. Matches the brief's example output.
    if len(violation_list) == 2:
        joined = f"{violation_list[0]} AND {violation_list[1]}"
    elif len(violation_list) > 2:
        joined = ", ".join(violation_list[:-1]) + f" AND {violation_list[-1]}"
    elif len(violation_list) == 1:
        joined = violation_list[0]
    else:
        joined = "(no specific rules recorded)"
    summary = (
        f"Request blocked by composed constraint violation: {joined}."
    )
    narrative_parts = [
        f"Request blocked by composed constraint violation: {joined}.",
    ]
    if near_map:
        pretty = "; ".join(
            f"{rule} at {int(round(pct * 100))}% consumed"
            for rule, pct in sorted(near_map.items())
        )
        narrative_parts.append(
            f"Near-threshold invariants at decision time: {pretty}."
        )
    if reason_text:
        narrative_parts.append(str(reason_text))
    narrative = " ".join(p for p in narrative_parts if p)
    machine: Dict[str, Any] = {
        "violations": list(violation_list),
        "near_thresholds": {k: float(v) for k, v in near_map.items()},
    }
    if reason_text:
        machine["reason_text"] = str(reason_text)
    remedy = (
        "Relax or remove at least one of the conflicting rules, or "
        "reshape the intent so no more than one rule fires. Composed "
        "violations usually indicate a cumulative policy that a single "
        "rule was never designed to carry on its own."
    )
    return summary, narrative, machine, remedy


def _describe_revision_transition_runtime(
    witness: Dict[str, str],
    reason_text: Optional[str],
    previous_revision: Optional[str],
    current_revision: Optional[str],
    transition_issue: Mapping[str, Any],
) -> tuple[str, str, Dict[str, Any], str]:
    """Render the ``revision_transition_violation`` runtime case (v0.21.0).

    Different from :func:`_describe_cross_revision` above — that covers
    the declare-time ``CrossRevisionViolation`` thrown at mutation
    admission. This describer covers the RUNTIME observation: a policy
    transition landed that the runtime wants the caller to notice
    (canonical example: limit was relaxed while adaptive tightening
    was active).
    """
    kind = str(transition_issue.get("kind") or "unknown_transition_issue")
    details = transition_issue.get("details") or {}
    prev_label = previous_revision or "(unknown)"
    cur_label = current_revision or "(unknown)"
    pretty_kind = kind.replace("_", " ")
    summary = (
        f"Blocked: policy transition {prev_label} -> {cur_label} "
        f"flagged {pretty_kind}."
    )
    narrative_parts = [
        f"The active policy advanced from revision {prev_label} to "
        f"{cur_label}. The runtime flagged the transition as "
        f"{pretty_kind} and held the intent while operators review "
        "the evolution."
    ]
    if isinstance(details, Mapping):
        detail_pairs = [
            f"{k}={v}" for k, v in details.items()
            if isinstance(k, str) and v is not None
        ]
        if detail_pairs:
            narrative_parts.append("Transition details: " + ", ".join(detail_pairs) + ".")
    if reason_text:
        narrative_parts.append(str(reason_text))
    narrative = " ".join(narrative_parts)
    machine: Dict[str, Any] = {
        "previous_policy_revision": previous_revision,
        "current_policy_revision": current_revision,
        "transition_issue": {
            "kind": kind,
            "details": dict(details) if isinstance(details, Mapping) else {},
        },
    }
    remedy = (
        "Let the transition stabilise before retrying, revert the "
        "relaxation until adaptive tightening clears, or route the "
        "intent through the governance queue for explicit approval."
    )
    return summary, narrative, machine, remedy


def _describe_policy_inconclusive(
    witness: Dict[str, str],
    reason_text: Optional[str],
) -> tuple[str, str, Dict[str, Any], str]:
    elapsed = witness.get("elapsed_ms", "?")
    backend = witness.get("backend", "tau")
    summary = (
        f"Inconclusive: {backend} prover did not decide within {elapsed} ms; "
        f"strict mode rejects."
    )
    narrative = (
        f"The {backend} consistency prover could not decide the composed "
        f"policy within the configured timeout ({elapsed} ms). Strict-mode "
        f"cages reject inconclusive results so a silent unsat never reaches "
        f"production. Verified mode would have admitted the call with a "
        f"degraded strength stamp."
    )
    machine = {"elapsed_ms": elapsed, "backend": backend}
    remedy = (
        "Re-run in verified mode, raise the prover timeout, or simplify "
        "the candidate policy until the prover is decisive."
    )
    return summary, narrative, machine, remedy


# ── top-level dispatcher ─────────────────────────────────────────────────────


def _describe_permit(
    reason_text: Optional[str],
) -> tuple[str, str, Dict[str, Any], str]:
    summary = "Permitted: no declared invariant blocked this payment."
    narrative = (
        "The cage admitted the payment because every declared invariant "
        "was silent on this intent. A permit does not guarantee the payment "
        "settled upstream; it only records that no cage-side rule fired."
    )
    machine: Dict[str, Any] = {}
    remedy = ""
    return summary, narrative, machine, remedy


def _describe_fallback(
    rule_id: Optional[str],
    witness: Dict[str, str],
    reason_text: Optional[str],
) -> tuple[str, str, Dict[str, Any], str]:
    label = rule_id or "(unknown rule)"
    base = reason_text or _FALLBACK_REASON
    summary = f"Blocked by {label}: {base}"
    narrative = (
        f"The cage blocked this payment under rule {label!r}. "
        f"Reason: {base} The explainer does not have a dedicated describer "
        f"for this rule_id; the narrative will improve when a describer "
        f"lands, but the verdict itself is authoritative."
    )
    machine: Dict[str, Any] = {"rule_id": rule_id, "witness_parsed": witness}
    remedy = (
        f"Check the rule {label!r} in the active policy: relax the "
        f"parameters, remove the rule, or ask the cage operator for "
        f"guidance specific to this invariant class."
    )
    return summary, narrative, machine, remedy


def explain_decision(
    verdict_record: Mapping[str, Any],
    registry: Optional[Any] = None,
    history_store: Optional[Any] = None,
) -> DecisionExplanation:
    """Turn a stored verdict record into an operator-friendly explanation.

    Pure function: never mutates state, never does I/O, never calls the
    daemon. Pass the ``registry`` / ``history_store`` only if the caller
    wants the describer to enrich the narrative with live context (today
    the describers consume only what's in the record, but the signature
    is stable so future enrichment is additive).

    Args:
        verdict_record:
            The verdict-summary dict as stored in the cage's history store
            (``kind="verdict"``). Required keys: ``verdict``
            (``"permit"``|``"reject"``), ``rule_id``, ``reason_text``,
            plus the v0.15.0 bundle fields (``_bundle_witness``,
            ``_bundle_intent``) when present.
        registry:
            Reserved for future describers that want to look up the live
            invariant object (e.g. allowlist membership). Unused today.
        history_store:
            Reserved for future describers that want to reason over the
            reject history when explaining retry / cooldown rules.
            Unused today.

    Returns:
        A frozen :class:`DecisionExplanation` ready to serialise via
        ``to_wire()``.

    Raises:
        TypeError: if ``verdict_record`` is not a mapping.
    """
    del registry, history_store  # reserved; see docstring
    if not isinstance(verdict_record, Mapping):
        raise TypeError(
            f"verdict_record must be a mapping, got {type(verdict_record).__name__}"
        )
    outcome = verdict_record.get("verdict") or "unknown"
    rule_id = verdict_record.get("rule_id")
    reason_text = verdict_record.get("reason_text")
    # The full witness lives under `_bundle_witness`; fall back to a bare
    # `witness` key for historical records.
    witness_raw: Optional[str] = (
        verdict_record.get("_bundle_witness")
        or verdict_record.get("witness")
    )
    parsed_witness = _parse_witness(witness_raw)
    # Currency is recorded on the intent summary. Fall back to USDC so the
    # narrative reads sensibly on malformed records.
    intent_summary = verdict_record.get("intent") or {}
    currency = "USDC"
    if isinstance(intent_summary, Mapping):
        currency = str(intent_summary.get("currency") or "USDC")

    invariant_class = _resolve_invariant_class(rule_id)
    retry_after: Optional[int] = None

    if outcome == "permit":
        summary, narrative, machine, remedy = _describe_permit(reason_text)
        return DecisionExplanation(
            summary=summary,
            narrative=narrative,
            machine_readable=machine,
            rule_id=None,
            invariant_class=None,
            witnessed_behavior={},
            what_would_allow=remedy,
            retry_after_seconds=None,
            outcome="permit",
        )

    # Reject path — dispatch on rule_id.
    if rule_id == "max_per_call":
        summary, narrative, machine, remedy = _describe_max_per_call(
            parsed_witness, reason_text, currency
        )
    elif rule_id and rule_id.startswith("spending_cap_"):
        summary, narrative, machine, remedy = _describe_spending_cap(
            rule_id, parsed_witness, reason_text, currency
        )
    elif rule_id == "retry_rate_limit":
        (
            summary,
            narrative,
            machine,
            remedy,
            retry_after,
        ) = _describe_retry_rate_limit(parsed_witness, reason_text)
    elif rule_id == "provider_allowlist":
        summary, narrative, machine, remedy = _describe_provider_allowlist(
            parsed_witness, reason_text
        )
    elif rule_id == "mutual_exclusion":
        summary, narrative, machine, remedy = _describe_mutual_exclusion(
            parsed_witness, reason_text
        )
    elif rule_id in ("counterparty_sanctioned", "counterparty_not_approved"):
        summary, narrative, machine, remedy = _describe_counterparty(
            rule_id, parsed_witness, reason_text
        )
    elif rule_id and rule_id.startswith("rolling_window_cap_"):
        summary, narrative, machine, remedy = _describe_rolling_window(
            rule_id, parsed_witness, reason_text
        )
    elif rule_id == "instability_guard":
        summary, narrative, machine, remedy = _describe_instability_guard(
            parsed_witness, reason_text, currency
        )
    elif rule_id == "burst_velocity_cap":
        summary, narrative, machine, remedy = _describe_burst_velocity(
            parsed_witness, reason_text, currency
        )
    elif rule_id == "adaptive_tightening":
        (
            summary,
            narrative,
            machine,
            remedy,
            retry_after,
        ) = _describe_adaptive_tightening(parsed_witness, reason_text, currency)
    elif rule_id == "cross_revision_violation":
        summary, narrative, machine, remedy = _describe_cross_revision(
            parsed_witness, reason_text
        )
    elif rule_id == "governance_violation":
        summary, narrative, machine, remedy = _describe_governance_violation(
            parsed_witness, reason_text
        )
    elif rule_id == "policy_inconclusive":
        summary, narrative, machine, remedy = _describe_policy_inconclusive(
            parsed_witness, reason_text
        )
    elif rule_id == "composed_constraint_violation":
        # v0.21.0 — composed reject. Pulls the violation list + the
        # near-threshold map off the verdict record; both are optional
        # so a minimal caller still renders something coherent.
        violations_raw = verdict_record.get("violations") or []
        if not isinstance(violations_raw, (list, tuple)):
            violations_raw = []
        near_raw = verdict_record.get("near_thresholds") or {}
        if not isinstance(near_raw, Mapping):
            near_raw = {}
        summary, narrative, machine, remedy = _describe_composed_violation(
            parsed_witness,
            reason_text,
            [str(v) for v in violations_raw],
            {str(k): float(v) for k, v in near_raw.items() if _is_number(v)},
        )
    elif rule_id == "revision_transition_violation":
        # v0.21.0 runtime-side transition awareness. Distinct from the
        # declare-time CrossRevisionViolation describer above.
        issue_raw = verdict_record.get("revision_transition_issue") or {}
        if not isinstance(issue_raw, Mapping):
            issue_raw = {}
        summary, narrative, machine, remedy = _describe_revision_transition_runtime(
            parsed_witness,
            reason_text,
            _optional_str(verdict_record.get("previous_policy_revision")),
            _optional_str(verdict_record.get("current_policy_revision")),
            issue_raw,
        )
    elif rule_id and rule_id.startswith("jurisdiction_"):
        # JurisdictionRule wraps inner rule_ids. Fall through to the inner
        # describer so the narrative still mentions the jurisdiction
        # prefix, then prepend a jurisdiction note.
        _, _, inner = rule_id.partition(".")
        inner_explanation = explain_decision(
            {**verdict_record, "rule_id": inner or rule_id},
            registry=None,
        )
        summary = f"[jurisdiction] {inner_explanation.summary}"
        narrative = (
            f"A JurisdictionRule wrapper guarded the inner rule "
            f"{inner or rule_id!r}. "
            + inner_explanation.narrative
        )
        machine = {
            "jurisdiction_wrapped_rule": inner,
            **inner_explanation.machine_readable,
        }
        remedy = inner_explanation.what_would_allow
    else:
        summary, narrative, machine, remedy = _describe_fallback(
            rule_id, parsed_witness, reason_text
        )

    return DecisionExplanation(
        summary=summary,
        narrative=narrative,
        machine_readable=machine,
        rule_id=rule_id,
        invariant_class=invariant_class,
        witnessed_behavior=dict(parsed_witness),
        what_would_allow=remedy,
        retry_after_seconds=retry_after,
        outcome="reject",
    )


__all__ = [
    "DecisionExplanation",
    "explain_decision",
]
