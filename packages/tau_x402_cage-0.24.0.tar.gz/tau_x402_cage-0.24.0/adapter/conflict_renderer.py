"""Natural-language rendering of ``BranchMergeConflict`` payloads.

v0.11.0 addresses a UX gap introduced with three-way merge in v0.8.0: the
conflict payload is structured and machine-readable but not operator-friendly.
When a human is deciding whether to force-merge, retract-first, or escalate,
they want "branch ``shadow`` raised the per-call cap to 30 USDC, branch
``prod`` lowered it to 20 USDC" — not the raw ``{added, removed}`` dicts.

Design
  * **Class-aware phrasing** — each invariant class gets a dedicated
    ``describe_invariant`` phrasing function so SpendingCap reads as
    "SpendingCap(100 USDC, per_window, 3600s, provider=anthropic)", not a
    generic ``repr``-style dump. Unknown classes fall back to a conservative
    ``ClassName(key=value, ...)`` rendering so future invariant types still
    render even without a dedicated branch.
  * **Per-class paragraphs** — ``render_conflict_text`` emits one paragraph
    per conflicting invariant class. Each paragraph names the class, the
    operations each side applied (added/removed/modified), and the concrete
    invariants involved pulled from the side deltas.
  * **Pure, no I/O, no mutation** — takes a ``BranchMergeConflict`` (or its
    dict form) and returns a string. Safe to call from the CLI, the web UI,
    or a webhook payload renderer.
  * **Immutable inputs** — the ``BranchMergeConflict`` dataclass is frozen;
    we never reach into it to modify state. All intermediate collections are
    locally owned.

Extending
  * To add a new invariant class, register a phrasing function in
    ``_DESCRIBERS`` keyed by the class name the policy_revision serializer
    emits. See ``docs/conflict_rendering.md`` for the naming conventions.
"""

from __future__ import annotations

from typing import Any, Callable, Dict, List, Optional, Sequence, Union

from adapter.policy_revision import BranchMergeConflict


# ── invariant-class phrasing ────────────────────────────────────────────────


def _describe_spending_cap(repr_d: Dict[str, Any]) -> str:
    """SpendingCap — cumulative spend bound in a scope.

    Output shape:
        "SpendingCap(100 USDC, per_window, 3600s, provider=anthropic)"
        "SpendingCap(5 USDC, per_tx)"
    """
    amount = repr_d.get("max_amount", "?")
    currency = repr_d.get("currency", "USDC")
    scope = repr_d.get("scope", "per_window")
    window = repr_d.get("window_seconds")
    provider = repr_d.get("provider")
    parts: List[str] = [f"{amount} {currency}", str(scope)]
    if window is not None:
        parts.append(f"{window}s")
    if provider:
        parts.append(f"provider={provider}")
    return f"SpendingCap({', '.join(parts)})"


def _describe_max_per_call(repr_d: Dict[str, Any]) -> str:
    """MaxPerCall — single-call amount ceiling."""
    amount = repr_d.get("max_amount", "?")
    currency = repr_d.get("currency", "USDC")
    return f"MaxPerCall({amount} {currency})"


def _describe_provider_allowlist(repr_d: Dict[str, Any]) -> str:
    """ProviderAllowlist — the set of approved counterparties."""
    providers = repr_d.get("providers") or []
    if not providers:
        return "ProviderAllowlist(empty)"
    return "ProviderAllowlist({" + ", ".join(sorted(providers)) + "})"


def _describe_retry_rate_limit(repr_d: Dict[str, Any]) -> str:
    """RetryRateLimit — minimum gap between retries after a reject."""
    gap = repr_d.get("min_gap_seconds", "?")
    return f"RetryRateLimit(min_gap={gap}s)"


def _describe_rolling_window_cap(repr_d: Dict[str, Any]) -> str:
    """RollingWindowCap — count cap over a rolling window."""
    max_count = repr_d.get("max_count", "?")
    window = repr_d.get("window_seconds", "?")
    group_by = repr_d.get("group_by", "provider")
    return f"RollingWindowCap(max={max_count}, window={window}s, group_by={group_by})"


def _describe_mutual_exclusion(repr_d: Dict[str, Any]) -> str:
    """MutualExclusion — two provider groups that cannot both admit."""
    a = repr_d.get("group_a") or []
    b = repr_d.get("group_b") or []
    a_s = "{" + ", ".join(sorted(a)) + "}" if a else "{}"
    b_s = "{" + ", ".join(sorted(b)) + "}" if b else "{}"
    return f"MutualExclusion(group_a={a_s}, group_b={b_s})"


def _describe_jurisdiction_rule(repr_d: Dict[str, Any]) -> str:
    """JurisdictionRule — additional invariants gated on a jurisdiction."""
    jur = repr_d.get("jurisdiction", "?")
    sub_entries = repr_d.get("additional_invariants") or []
    if not sub_entries:
        return f"JurisdictionRule({jur}, no additional invariants)"
    sub_descs = [describe_invariant(sub) for sub in sub_entries]
    return f"JurisdictionRule({jur}, requires=[{'; '.join(sub_descs)}])"


def _describe_counterparty_constraint(repr_d: Dict[str, Any]) -> str:
    """CounterpartyConstraint — approved/sanctioned counterparty sets."""
    approved = repr_d.get("approved_ids") or []
    sanctioned = repr_d.get("sanctioned_ids") or []
    parts: List[str] = []
    if approved:
        parts.append("approved={" + ", ".join(sorted(approved)) + "}")
    if sanctioned:
        parts.append("sanctioned={" + ", ".join(sorted(sanctioned)) + "}")
    if not parts:
        return "CounterpartyConstraint(empty)"
    return "CounterpartyConstraint(" + ", ".join(parts) + ")"


#: Class-name -> phrasing function. Keyed by the ``class_name`` field the
#: policy_revision serializer emits. Unknown classes fall back to
#: ``_describe_fallback`` which uses a conservative key=value dump.
_DESCRIBERS: Dict[str, Callable[[Dict[str, Any]], str]] = {
    "SpendingCap": _describe_spending_cap,
    "MaxPerCall": _describe_max_per_call,
    "ProviderAllowlist": _describe_provider_allowlist,
    "RetryRateLimit": _describe_retry_rate_limit,
    "RollingWindowCap": _describe_rolling_window_cap,
    "MutualExclusion": _describe_mutual_exclusion,
    "JurisdictionRule": _describe_jurisdiction_rule,
    "CounterpartyConstraint": _describe_counterparty_constraint,
}


def _describe_fallback(class_name: str, repr_d: Dict[str, Any]) -> str:
    """Fallback for invariant classes the renderer does not know.

    Emits ``ClassName(key=value, ...)`` with deterministic key ordering so
    future invariant types still render even before a dedicated describer
    is registered. Better than raising: callers are usually on a hot path.
    """
    if not repr_d:
        return f"{class_name}()"
    pairs = ", ".join(f"{k}={repr_d[k]}" for k in sorted(repr_d.keys()))
    return f"{class_name}({pairs})"


def describe_invariant(inv_dict: Dict[str, Any]) -> str:
    """Describe a serialized invariant ``{class_name, repr}`` in one line.

    The input matches the shape emitted by
    ``policy_revision._serialize_invariant``: a dict with ``class_name``
    (the Python class name) and ``repr`` (the type-specific field bag).

    Raises
    ------
    TypeError
        if ``inv_dict`` is not a dict, or is missing ``class_name`` /
        ``repr`` keys, so callers don't silently render "unknown" when the
        upstream payload shape changes.
    """
    if not isinstance(inv_dict, dict):
        raise TypeError(
            f"describe_invariant expected a dict, got {type(inv_dict).__name__}"
        )
    class_name = inv_dict.get("class_name")
    repr_d = inv_dict.get("repr")
    if not isinstance(class_name, str):
        raise TypeError(
            f"describe_invariant: invariant entry missing 'class_name': {inv_dict!r}"
        )
    if not isinstance(repr_d, dict):
        raise TypeError(
            f"describe_invariant: invariant entry missing 'repr' dict: {inv_dict!r}"
        )
    describer = _DESCRIBERS.get(class_name)
    if describer is None:
        return _describe_fallback(class_name, repr_d)
    return describer(repr_d)


# ── delta → per-class breakdown ─────────────────────────────────────────────


def _invariants_by_class(
    entries: Sequence[Dict[str, Any]],
) -> Dict[str, List[Dict[str, Any]]]:
    """Group a delta's ``added`` / ``removed`` entries by class name.

    Defensive: skips non-dict entries and entries without a string
    ``class_name`` so corrupt deltas don't raise inside the CLI path.
    """
    by_class: Dict[str, List[Dict[str, Any]]] = {}
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        cls = entry.get("class_name")
        if not isinstance(cls, str):
            continue
        by_class.setdefault(cls, []).append(entry)
    return by_class


def _phrase_for_ops(
    branch_name: str,
    ops: Sequence[str],
    added: Sequence[Dict[str, Any]],
    removed: Sequence[Dict[str, Any]],
) -> str:
    """Human-readable fragment naming what a single side did to a class.

    Output shapes:
        "branch 'shadow' added SpendingCap(100 USDC, per_window)"
        "branch 'shadow' removed MaxPerCall(20 USDC)"
        "branch 'shadow' modified SpendingCap (removed 50 USDC, added 100 USDC)"

    The "modified" shape is used when both added and removed carry entries
    for the same class — i.e. the branch swapped one invariant for another.
    """
    has_added = "added" in ops and added
    has_removed = "removed" in ops and removed
    if has_added and has_removed:
        added_descs = "; ".join(describe_invariant(e) for e in added)
        removed_descs = "; ".join(describe_invariant(e) for e in removed)
        return (
            f"branch {branch_name!r} modified "
            f"(removed {removed_descs}; added {added_descs})"
        )
    if has_added:
        descs = "; ".join(describe_invariant(e) for e in added)
        return f"branch {branch_name!r} added {descs}"
    if has_removed:
        descs = "; ".join(describe_invariant(e) for e in removed)
        return f"branch {branch_name!r} removed {descs}"
    # Fallback: ops declared but no concrete entries — rare, but render a
    # neutral phrase so the top-level message still reads cleanly.
    op_text = " and ".join(ops) if ops else "touched"
    return f"branch {branch_name!r} {op_text}"


def _render_class_paragraph(
    class_entry: Dict[str, Any],
    src_branch: str,
    dst_branch: str,
    src_delta: Dict[str, Any],
    dst_delta: Dict[str, Any],
) -> str:
    """Render one paragraph for a single conflicting invariant class.

    ``class_entry`` is one element of ``conflicting_invariants`` and carries
    the class name plus the per-side operation lists.
    """
    class_name = class_entry.get("class_name", "<unknown>")
    src_ops = class_entry.get("src_ops") or []
    dst_ops = class_entry.get("dst_ops") or []

    src_added = _invariants_by_class(src_delta.get("added") or []).get(class_name, [])
    src_removed = _invariants_by_class(src_delta.get("removed") or []).get(class_name, [])
    dst_added = _invariants_by_class(dst_delta.get("added") or []).get(class_name, [])
    dst_removed = _invariants_by_class(dst_delta.get("removed") or []).get(class_name, [])

    src_phrase = _phrase_for_ops(src_branch, src_ops, src_added, src_removed)
    dst_phrase = _phrase_for_ops(dst_branch, dst_ops, dst_added, dst_removed)
    return f"{class_name}: {src_phrase}; {dst_phrase}."


# ── public API ──────────────────────────────────────────────────────────────


ConflictLike = Union[BranchMergeConflict, Dict[str, Any]]


def _conflict_to_dict(conflict: ConflictLike) -> Dict[str, Any]:
    """Normalize the input so callers can pass a dataclass or a raw dict.

    The daemon serializes ``BranchMergeConflict`` via ``to_dict`` before it
    ever hits the wire, so CLI callers naturally receive dicts. The library
    API accepts the dataclass directly for programmatic use.
    """
    if isinstance(conflict, BranchMergeConflict):
        return conflict.to_dict()
    if isinstance(conflict, dict):
        return conflict
    raise TypeError(
        f"render_conflict_text expected BranchMergeConflict or dict, "
        f"got {type(conflict).__name__}"
    )


def render_conflict_text(conflict: ConflictLike) -> str:
    """Render a ``BranchMergeConflict`` as operator-readable text.

    Output shape (two conflicting classes, v0.14.0 with classification):

        Merge conflict: branch 'shadow' into branch 'prod' cannot be auto-merged.
        Common ancestor: rev-abc123.

        [semantic] SpendingCap: both branches declared conflicting values ...
          Suggested repair: Decide which window ...

    Legacy callers pass payloads without ``classified_conflicts``; we fall
    back to the pre-v0.14.0 per-class paragraph render so v0.8.x wire
    formats still produce readable text.

    When neither ``classified_conflicts`` nor ``conflicting_invariants``
    is populated (shouldn't happen for real conflicts but defensive), we
    still emit the top-level wrapper so callers can tell we ran.
    """
    d = _conflict_to_dict(conflict)
    src_branch = d.get("src", "<src>")
    dst_branch = d.get("dst", "<dst>")
    header = render_branch_divergence(src_branch, dst_branch, d)
    # v0.14.0: prefer the richer ``classified_conflicts`` wire when present.
    classified = d.get("classified_conflicts") or []
    if classified:
        classified_paragraphs = [
            p for p in (
                _render_classified_paragraph(entry)
                for entry in classified
                if isinstance(entry, dict)
            ) if p
        ]
        if classified_paragraphs:
            return header + "\n\n" + "\n".join(classified_paragraphs)
    class_entries = d.get("conflicting_invariants") or []
    src_delta = d.get("src_delta") or {}
    dst_delta = d.get("dst_delta") or {}
    paragraphs: List[str] = []
    for entry in class_entries:
        if not isinstance(entry, dict):
            continue
        paragraphs.append(
            _render_class_paragraph(
                class_entry=entry,
                src_branch=src_branch,
                dst_branch=dst_branch,
                src_delta=src_delta,
                dst_delta=dst_delta,
            )
        )
    if not paragraphs:
        return header.rstrip()
    return header + "\n\n" + "\n".join(paragraphs)


def _render_classified_paragraph(entry: Dict[str, Any]) -> str:
    """Render one classified-conflict dict as a two-line paragraph.

    Shape:
        "[<category>] <diagnosis>"
        "  Suggested repair: <hint>"     (only when populated)

    Defensive: missing ``category`` / ``diagnosis`` still produce a
    non-empty string so the caller never silently drops an entry.
    """
    category = entry.get("category") or "conflict"
    diagnosis = entry.get("diagnosis")
    class_name = entry.get("class_name", "<unknown>")
    if not diagnosis:
        diagnosis = f"{class_name}: merge conflict"
    line = f"[{category}] {diagnosis}"
    repair = entry.get("suggested_repair")
    if isinstance(repair, str) and repair:
        return line + "\n  Suggested repair: " + repair
    return line


def render_branch_divergence(
    src_branch: str,
    dst_branch: str,
    conflict: ConflictLike,
) -> str:
    """Top-level wrapper sentence naming the two branches and the ancestor.

    Separated from the per-class body so templates (web UI, webhooks, CLI)
    can show the one-liner summary without re-rendering every class
    paragraph.
    """
    d = _conflict_to_dict(conflict)
    ancestor = d.get("common_ancestor")
    if ancestor is None:
        ancestor_text = "no common ancestor (orphan branches)"
    else:
        ancestor_text = f"common ancestor: {ancestor}"
    return (
        f"Merge conflict: branch {src_branch!r} into branch {dst_branch!r} "
        f"cannot be auto-merged. {ancestor_text}.\n"
    )


__all__ = [
    "describe_invariant",
    "render_branch_divergence",
    "render_conflict_text",
]
