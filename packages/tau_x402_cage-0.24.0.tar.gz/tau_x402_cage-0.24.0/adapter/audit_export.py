"""Signed audit export bundle.

Turns the cage's in-memory audit trail — revision log, approval queue, branch
graph, merge commits — into a deterministic, offline-verifiable artefact. A
regulator or compliance auditor can load `audit.jsonl`, verify the ed25519
signature with a published public key, and confirm that the log has not been
tampered with since export.

Wire format (v1):
    Line 1 — the canonical JSON of the unsigned bundle dict:
        {
            "bundle_version": "1",
            "exported_at_unix": <int>,
            "revisions":     [<PolicyRevision.to_dict()>, ...],
            "branches":      [<Branch.to_dict()>, ...],
            "proposals":     [<Proposal.to_dict()>, ...],
            "merge_commits": [<PolicyRevision.to_dict()>, ...],   # subset of revisions
        }
    Line 2 — the signature record:
        {
            "signature":  "<base64 of ed25519 signature over line 1 bytes>",
            "public_key": "<PEM-encoded SubjectPublicKeyInfo of the signing key>",
            "algorithm":  "ed25519"
        }

Determinism guarantees (what makes the bundle byte-stable):
  * We serialize with ``json.dumps(..., sort_keys=True, separators=(",", ":"))``
    so field order inside every object is fixed.
  * ``revisions``/``branches``/``proposals`` order comes straight from the
    input iterables. Callers that care about determinism for "same in-memory
    state → byte-identical bundle" must pass the same iteration each time;
    the helpers below pass ``log.revisions`` tuples and queue.list() which
    already have stable order.
  * ``exported_at_unix`` is parameterised on the caller; set it to a fixed
    value (the `now_unix` arg) when comparing two exports for equality.
  * Trailing newline on line 1 is part of the signed bytes. Line 2 has its
    own trailing newline. The signature covers line 1's bytes EXCLUDING the
    trailing newline so reformatting (editor adding/removing newline) does
    not invalidate a signature over otherwise-identical content.

Design decisions:
  * ``bundle_version: "1"`` is immutable. Future changes either bump the
    version or nest additional fields under a namespaced key. v1 readers
    MUST reject an unknown version string rather than best-effort parsing,
    to keep the attestation surface honest.
  * ``verify_bundle`` returns a structured ``VerifyResult`` instead of a
    bool. Callers can distinguish "file missing", "signature bad", "wrong
    key", "unknown version" without parsing error strings.
  * No cage import inside this module beyond the pure-data ``to_dict`` /
    ``from_dict`` helpers on ``PolicyRevision`` / ``Branch`` / ``Proposal``.
    A pure-stdlib + cryptography verifier can run offline.
  * We reuse the ed25519 helpers from ``verdict_signer.py`` (sign/verify
    primitives on ``Ed25519Signer`` and ``load_ed25519_public_key``) rather
    than rolling a parallel signing stack; keeps the audit surface aligned
    with the wire-signing surface.

Threat model — what the signed bundle proves:
  * **Integrity** of the revision log, approval queue, and branch graph AS
    EXPORTED. A third party with the cage's public key can confirm the
    file was produced by the keyholder and has not been mutated since.
  * **Non-repudiation** of the export event itself (the keyholder signed).
  * **Determinism** for reproducibility: two exports of the same in-memory
    state produce byte-identical bundles (modulo ``exported_at_unix``).

What it does NOT prove:
  * That the policy was correct. The prover tokens inside each revision
    record the admission decision that was made; an auditor still has to
    trust (or re-run) the prover.
  * That the bundle contains every decision ever made — the exporter only
    includes what the caller hands it. Integrate with the daemon's
    durable ``RevisionLog`` + ``ApprovalQueue`` to guarantee completeness.
  * That no off-log verdicts were issued. We snapshot the declared
    audit trail, not the wire-level verdict stream.

See ``docs/audit_export.md`` for the regulator-facing verification
procedure.
"""

from __future__ import annotations

import base64
import binascii
import json
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

from adapter.approval_queue import Proposal
from adapter.policy_revision import Branch, PolicyRevision


#: Frozen bundle schema version. Once this lands on disk, v1 readers must be
#: able to parse every future v1 export. Any breaking change bumps to "2".
BUNDLE_VERSION_V1 = "1"

#: Signature algorithm written into the sidecar record. Only ed25519 is
#: currently produced; a verifier that sees anything else should fail shut.
AUDIT_ALGORITHM = "ed25519"


class AuditExportError(ValueError):
    """Raised on malformed bundle / signature / key material."""


# ── canonical serialisation ──────────────────────────────────────────────────


def _canonical_dumps(obj: Dict[str, Any]) -> str:
    """Single source of truth for bundle serialisation.

    ``sort_keys`` + compact separators make the output byte-stable across
    Python versions and platforms; the same input dict always produces the
    same string, which is what makes the signature reproducible.
    """
    return json.dumps(obj, sort_keys=True, separators=(",", ":"))


# ── bundle construction ─────────────────────────────────────────────────────


def export_bundle(
    revision_log: Iterable[PolicyRevision],
    approval_queue: Iterable[Proposal],
    branches: Iterable[Branch],
    now_unix: Optional[int] = None,
) -> Dict[str, Any]:
    """Build a deterministic bundle dict from the three audit surfaces.

    Args:
        revision_log:   iterable of PolicyRevision records (linear or DAG).
                        ``RevisionLog.revisions`` satisfies this directly.
        approval_queue: iterable of Proposal records. Pass
                        ``queue.list()`` for a deterministic sorted order.
        branches:       iterable of Branch records. Pass
                        ``log.list_branches()``.
        now_unix:       override export timestamp (tests / reproducibility).
                        Defaults to ``int(time.time())``.

    Returns:
        A plain dict ready for ``_canonical_dumps`` or ``sign_bundle``.
        Empty inputs produce a valid empty bundle — the ``bundle_version``
        + ``exported_at_unix`` fields are always present.

    This function does NOT sign. Keep signing in a separate call so the
    daemon can export (cheap) without holding private key material.
    """
    revisions_list: List[Dict[str, Any]] = []
    merge_commits: List[Dict[str, Any]] = []
    for rev in revision_log:
        if not isinstance(rev, PolicyRevision):
            raise AuditExportError(
                f"revision_log entry must be PolicyRevision, got {type(rev).__name__}"
            )
        d = rev.to_dict()
        revisions_list.append(d)
        # Surface merge commits as a flat list so an auditor can walk the
        # DAG without scanning every revision for the merge_parent_ids key.
        if rev.merge_parent_ids is not None:
            merge_commits.append(d)

    branches_list: List[Dict[str, Any]] = []
    for b in branches:
        if not isinstance(b, Branch):
            raise AuditExportError(
                f"branches entry must be Branch, got {type(b).__name__}"
            )
        branches_list.append(b.to_dict())

    proposals_list: List[Dict[str, Any]] = []
    for p in approval_queue:
        if not isinstance(p, Proposal):
            raise AuditExportError(
                f"approval_queue entry must be Proposal, got {type(p).__name__}"
            )
        proposals_list.append(p.to_dict())

    ts = int(now_unix) if now_unix is not None else int(time.time())
    return {
        "bundle_version": BUNDLE_VERSION_V1,
        "exported_at_unix": ts,
        "revisions": revisions_list,
        "branches": branches_list,
        "proposals": proposals_list,
        "merge_commits": merge_commits,
    }


# ── signing ─────────────────────────────────────────────────────────────────


def _load_private_key(private_key_path: str) -> "object":
    """Load a PEM Ed25519 private key from disk.

    Split out so ``sign_bundle`` stays short and tests can patch this
    function. Raises ``AuditExportError`` (not KeyMaterialError) so callers
    see one error type across the audit surface.
    """
    try:
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    except ImportError as exc:  # pragma: no cover - dep gate
        raise AuditExportError(
            "audit signing requires the 'cryptography' package. "
            "Install the signing-ed25519 extra: pip install 'tau-x402-cage[signing-ed25519]'"
        ) from exc
    try:
        with open(private_key_path, "rb") as f:
            pem = f.read()
    except OSError as exc:
        raise AuditExportError(f"cannot read private key {private_key_path!r}: {exc}") from exc
    try:
        key = serialization.load_pem_private_key(pem, password=None)
    except (ValueError, TypeError) as exc:
        raise AuditExportError(f"malformed PEM private key: {exc}") from exc
    if not isinstance(key, Ed25519PrivateKey):
        raise AuditExportError(
            f"private key at {private_key_path!r} is not Ed25519 "
            f"(got {type(key).__name__})"
        )
    return key


def _public_pem_from_private(private_key: "object") -> bytes:
    """Derive the PEM-encoded public key from a loaded private key."""
    from cryptography.hazmat.primitives import serialization
    pub = private_key.public_key()  # type: ignore[attr-defined]
    return pub.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )


def sign_bundle(
    bundle: Dict[str, Any],
    private_key_path: str,
) -> bytes:
    """Sign a bundle dict with an Ed25519 private key; return JSONL bytes.

    Layout (two newline-terminated lines):
        line 1 = canonical bundle JSON
        line 2 = signature record JSON

    The signature covers line 1's bytes WITHOUT its trailing newline, so an
    editor that reformats trailing whitespace doesn't invalidate a valid
    signature over otherwise-identical content.

    Raises:
        AuditExportError — missing or malformed key material, or the bundle
        isn't a dict / doesn't round-trip through JSON. The caller should
        surface this at the CLI boundary, not catch silently.
    """
    if not isinstance(bundle, dict):
        raise AuditExportError(
            f"sign_bundle expected a dict, got {type(bundle).__name__}"
        )
    # Canonicalise first so we sign exactly what gets written. Any
    # non-JSON-serialisable field raises TypeError here rather than on
    # disk-read later.
    try:
        bundle_line = _canonical_dumps(bundle)
    except TypeError as exc:
        raise AuditExportError(f"bundle is not JSON-serialisable: {exc}") from exc

    private_key = _load_private_key(private_key_path)
    signature = private_key.sign(bundle_line.encode("utf-8"))  # type: ignore[attr-defined]
    pub_pem = _public_pem_from_private(private_key)

    sig_record = {
        "signature": base64.b64encode(signature).decode("ascii"),
        "public_key": pub_pem.decode("ascii"),
        "algorithm": AUDIT_ALGORITHM,
    }
    sig_line = _canonical_dumps(sig_record)
    # Two JSONL lines, each terminated by a newline. We emit bytes so the
    # caller can write the return value to a file opened in binary mode
    # without any locale-dependent re-encoding.
    return (bundle_line + "\n" + sig_line + "\n").encode("utf-8")


# ── verification ────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class VerifyResult:
    """Structured outcome of an offline bundle verification.

    Fields:
        valid             : True iff signature, version, and structure checks
                            all pass. False on any failure.
        bundle_version    : The declared bundle_version, or None if unknown.
        exported_at_unix  : The timestamp from the bundle, or None on error.
        revisions         : Count of revision records.
        branches          : Count of branch records.
        proposals         : Count of proposal records.
        merge_commits     : Count of merge-commit entries.
        reason            : Human-readable failure reason when ``valid`` is
                            False; None when valid.
    """

    valid: bool
    bundle_version: Optional[str]
    exported_at_unix: Optional[int]
    revisions: int
    branches: int
    proposals: int
    merge_commits: int
    reason: Optional[str] = None


def _load_public_key_pem(pem_bytes: bytes) -> "object":
    """Parse PEM bytes into an Ed25519PublicKey or raise AuditExportError."""
    try:
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    except ImportError as exc:  # pragma: no cover - dep gate
        raise AuditExportError(
            "audit verification requires the 'cryptography' package"
        ) from exc
    try:
        key = serialization.load_pem_public_key(pem_bytes)
    except (ValueError, TypeError) as exc:
        raise AuditExportError(f"malformed PEM public key: {exc}") from exc
    if not isinstance(key, Ed25519PublicKey):
        raise AuditExportError(
            f"public key is not Ed25519 (got {type(key).__name__})"
        )
    return key


def _fail(reason: str) -> VerifyResult:
    """Build a VerifyResult for a structural/signature failure.

    Keeps the ``reason`` text inside one place so the CLI can grep for
    specific diagnostics without string-matching duplicated error bodies.
    """
    return VerifyResult(
        valid=False,
        bundle_version=None,
        exported_at_unix=None,
        revisions=0,
        branches=0,
        proposals=0,
        merge_commits=0,
        reason=reason,
    )


def verify_bundle(path: str, public_key_path: str) -> VerifyResult:
    """Offline-verify a signed bundle file.

    Returns a ``VerifyResult`` describing the outcome. Never raises on
    predictable user errors (bad signature, wrong key, missing file, wrong
    version). Unexpected issues — a cryptography library import failure,
    for instance — still propagate as ``AuditExportError`` so the CLI can
    distinguish "bundle is invalid" from "can't even try to verify".
    """
    try:
        raw = Path(path).read_bytes()
    except FileNotFoundError:
        return _fail(f"audit bundle not found: {path}")
    except OSError as exc:
        return _fail(f"cannot read audit bundle {path!r}: {exc}")

    # Split on the FIRST newline. The bundle itself must not contain a
    # literal newline because _canonical_dumps uses compact separators and
    # the dict values are all JSON-escape-safe strings/numbers.
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError as exc:
        return _fail(f"audit bundle is not valid UTF-8: {exc}")
    if "\n" not in text:
        return _fail("audit bundle is not a two-line JSONL file")

    bundle_line, _, rest = text.partition("\n")
    sig_line = rest.rstrip("\n")
    if not sig_line or "\n" in sig_line.rstrip("\n"):
        return _fail("audit bundle must have exactly two JSONL lines")

    try:
        bundle = json.loads(bundle_line)
    except json.JSONDecodeError as exc:
        return _fail(f"bundle line is not valid JSON: {exc}")
    try:
        sig_record = json.loads(sig_line)
    except json.JSONDecodeError as exc:
        return _fail(f"signature line is not valid JSON: {exc}")

    if not isinstance(bundle, dict):
        return _fail("bundle is not a JSON object")
    version = bundle.get("bundle_version")
    if version != BUNDLE_VERSION_V1:
        return _fail(
            f"unsupported bundle_version {version!r}; this verifier understands v1"
        )

    # Algorithm + signature structural checks before we touch crypto.
    algorithm = sig_record.get("algorithm")
    if algorithm != AUDIT_ALGORITHM:
        return _fail(
            f"unsupported signature algorithm {algorithm!r}; expected {AUDIT_ALGORITHM!r}"
        )
    sig_b64 = sig_record.get("signature")
    if not isinstance(sig_b64, str) or not sig_b64:
        return _fail("signature record missing 'signature' field")
    try:
        signature = base64.b64decode(sig_b64, validate=True)
    except (ValueError, binascii.Error) as exc:
        return _fail(f"signature is not valid base64: {exc}")

    # Load the auditor's trusted public key — NOT the one embedded in the
    # file. The embedded public_key field is for human eyeballing; trust
    # comes from the caller-provided path. This is what lets a regulator
    # detect "attacker signed with their own key and rewrote the sidecar".
    try:
        pub_pem = Path(public_key_path).read_bytes()
    except FileNotFoundError:
        return _fail(f"public key not found: {public_key_path}")
    except OSError as exc:
        return _fail(f"cannot read public key {public_key_path!r}: {exc}")
    try:
        public_key = _load_public_key_pem(pub_pem)
    except AuditExportError as exc:
        return _fail(str(exc))

    try:
        from cryptography.exceptions import InvalidSignature
    except ImportError as exc:  # pragma: no cover - dep gate
        raise AuditExportError(
            "audit verification requires the 'cryptography' package"
        ) from exc

    try:
        public_key.verify(signature, bundle_line.encode("utf-8"))  # type: ignore[attr-defined]
    except InvalidSignature:
        return _fail(
            "signature verification failed — bundle tampered or wrong public key"
        )

    # Everything checks out. Surface counts so callers can dump a summary.
    revisions = bundle.get("revisions")
    branches = bundle.get("branches")
    proposals = bundle.get("proposals")
    merge_commits = bundle.get("merge_commits")
    exported_at = bundle.get("exported_at_unix")
    if not isinstance(revisions, list) or not isinstance(branches, list):
        return _fail("bundle revisions/branches are not lists")
    if not isinstance(proposals, list) or not isinstance(merge_commits, list):
        return _fail("bundle proposals/merge_commits are not lists")
    if not isinstance(exported_at, int):
        return _fail("bundle exported_at_unix is not an integer")
    return VerifyResult(
        valid=True,
        bundle_version=version,
        exported_at_unix=exported_at,
        revisions=len(revisions),
        branches=len(branches),
        proposals=len(proposals),
        merge_commits=len(merge_commits),
        reason=None,
    )
