"""Canonical decision schema for ``should_pay_x402`` — the primary primitive.

v0.17.0 promotes ``should_pay_x402`` to the main interface the product is
organised around. Every other MCP tool (``inspect_policy``,
``list_revisions``, ``safety_comparison``, ``guarantees`` …) is *support
data* for the one question an agent actually needs answered before it
spends money: "should I pay?".

This module defines:

* :class:`DecisionReason` — a small, stable enum of reasons the cage
  might return. Agents branch on this, not on raw rule_ids. The wire
  contract is frozen (adding a new reason is additive; renaming /
  removing one is a wire break).
* :class:`RiskPrevented` — the "what did rejecting this prevent" side
  channel populated on deny.
* :class:`PaymentDecision` — the single structured record the tool
  returns. Includes ``next_action`` so an agent has a canonical
  instruction without re-deriving policy logic.
* :func:`rule_id_to_reason` — deterministic mapping from existing
  internal rule_ids to the taxonomy. The mapping is intentionally
  exhaustive (every rule_id emitted by ``adapter/invariants.py``
  and ``adapter/self_ref_policy.py`` maps to a canonical reason)
  with a safe ``policy_inconclusive`` fallback for unknowns.
* :func:`next_action_for` — canonical next_action inference keyed off
  the reason + retry_after hint.

Design principles
-----------------
* **Agent-friendly, not SDK-friendly.** Every field is JSON-safe by
  construction: ``Decimal`` values are stringified by :meth:`to_wire`.
  Agents reading the tool result through structured content never hit
  a type-cast surprise.
* **Immutable dataclasses.** ``frozen=True`` everywhere so an accidental
  ``decision.allowed = True`` on the agent side fails loudly instead of
  silently mutating a shared decision record.
* **Fail-closed reason.** ``cage_unavailable`` is a first-class reason
  with ``allowed=False`` and ``next_action="abort"`` so a transport
  error never leaks as a permit.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from decimal import Decimal
from typing import Any, Final, Literal, Mapping, Optional, Sequence, Tuple


# ── taxonomy ────────────────────────────────────────────────────────────────


#: Canonical decision reason. The wire contract is stable: agents branch
#: on these identifiers, not on free-form text or on low-level rule_ids.
#: When adding a new reason: append to this Literal, update the mapping
#: below, add one test in ``tests/test_decision_schema.py``, bump the
#: module minor version.
DecisionReason = Literal[
    "allowed",
    "spend_cap_exceeded",
    "retry_loop_detected",
    "cooldown_active",
    "burst_velocity_exceeded",
    "adaptive_tightening_triggered",
    "provider_not_allowed",
    "counterparty_not_allowed",
    "jurisdiction_not_allowed",
    "mutual_exclusion",
    "instability_guard_tightened",
    "cross_revision_violation",
    "governance_violation",
    "policy_inconclusive",
    "approval_required",
    "cage_unavailable",
    # v0.21.0 — COMPOSED_CONSTRAINT_VIOLATION. Fires when two or more
    # invariants would have rejected the same intent. The single-rule
    # reasons above only name the FIRST violation; this reason names the
    # composition so callers see the interaction rather than the first
    # rule that happened to be traversed. See ``violations`` envelope
    # field for the full list of rule_ids that fired together.
    "composed_constraint_violation",
    # v0.21.0 — REVISION_TRANSITION_VIOLATION (runtime).
    # Reuses the existing guaranteed-mode failure code to avoid inflating
    # the taxonomy. Fires when the runtime observes a policy transition
    # whose shape the caller should surface (e.g. a limit was relaxed
    # while adaptive tightening was active). See ``revision_transition_issue``
    # envelope field for the structured issue descriptor.
    "revision_transition_violation",
]

#: Tuple form for runtime membership checks / typed iteration.
DECISION_REASONS: Final[tuple[str, ...]] = (
    "allowed",
    "spend_cap_exceeded",
    "retry_loop_detected",
    "cooldown_active",
    "burst_velocity_exceeded",
    "adaptive_tightening_triggered",
    "provider_not_allowed",
    "counterparty_not_allowed",
    "jurisdiction_not_allowed",
    "mutual_exclusion",
    "instability_guard_tightened",
    "cross_revision_violation",
    "governance_violation",
    "policy_inconclusive",
    "approval_required",
    "cage_unavailable",
    "composed_constraint_violation",
    "revision_transition_violation",
)

#: The mode the daemon was in when the decision was issued. Mirrors
#: :class:`adapter.cage_mode.CageMode` but as a plain Literal so agents
#: don't have to import the enum to branch on it.
CageModeLiteral = Literal["enforce", "shadow", "advisory"]

#: Decision-envelope mode. v0.19.0 introduces the ``"guaranteed"`` tier for
#: bank-deployable deployments; existing callers stay on ``"flexible"`` by
#: default so the wire shape is backward-compatible.
DecisionMode = Literal["flexible", "guaranteed"]

#: Structured failure codes emitted by Guaranteed Mode. Mirrors
#: ``adapter.guaranteed_errors.GuaranteedFailureCode``; duplicated here as a
#: plain Literal so this module does not require the guaranteed stack to be
#: importable.
GuaranteedFailureCodeLiteral = Literal[
    "RUNTIME_GUARD_VIOLATION",
    "RUNTIME_EVALUATION_UNAVAILABLE",
    "TOTALITY_VIOLATION",
    "PROOF_UNAVAILABLE",
    "PROOF_INCONSISTENT",
    "REVISION_TRANSITION_VIOLATION",
    "MUTATION_NOT_ACTIVATABLE",
]

#: Proof backend family. Collapses the ~5 internal prover strings into a
#: stable set the agent can reason over.
ProofMode = Literal["pattern", "tau", "z3", "hybrid"]


#: Stable source identifier for :class:`RiskPrevented.source`. ``source``
#: explains *which* machinery generated the estimate so downstream
#: consumers (dashboards, explainer agents) can caveat their phrasing.
RiskSource = Literal[
    "retry_density",
    "spend_velocity",
    "rule_composition",
]


#: Allowed ``next_action`` values. Kept tight so an agent's dispatch on
#: this field is safe to encode as a match/if-chain without a default.
NextAction = Literal[
    "proceed",
    "wait_for_cooldown",
    "request_approval",
    "adjust_policy",
    "retry_later",
    "abort",
]


# ── side-channel dataclasses ────────────────────────────────────────────────


@dataclass(frozen=True)
class RiskPrevented:
    """What the reject saved the caller from.

    Populated on deny by the daemon via the existing
    ``safety_comparison`` + ``risk_signals`` machinery. Fields are
    best-effort estimates: ``None`` means "we cannot estimate" rather
    than "zero".

    Attributes:
        estimated_extra_calls_blocked: approximate number of follow-on
            calls the reject prevented. For retry-loop detections this
            is the classic "agent would have burned N retries"
            estimate; for cooldown / burst it reflects the remaining
            window slots.
        estimated_extra_spend_blocked: approximate cash prevented.
            Denominated in ``currency``.
        currency: currency code for ``estimated_extra_spend_blocked``.
        source: which signal family produced the estimate.
            ``"rule_composition"`` means "we know the rule fired, we
            did not derive a density estimate"; agents should show
            this as "prevented" without a probabilistic gloss.
    """

    estimated_extra_calls_blocked: Optional[int] = None
    estimated_extra_spend_blocked: Optional[Decimal] = None
    currency: Optional[str] = None
    source: RiskSource = "rule_composition"

    def to_wire(self) -> dict[str, Any]:
        """JSON-safe serialisation. ``Decimal`` becomes a string."""
        return {
            "estimated_extra_calls_blocked": self.estimated_extra_calls_blocked,
            "estimated_extra_spend_blocked": (
                str(self.estimated_extra_spend_blocked)
                if self.estimated_extra_spend_blocked is not None
                else None
            ),
            "currency": self.currency,
            "source": self.source,
        }


# ── main decision record ────────────────────────────────────────────────────


@dataclass(frozen=True)
class PaymentDecision:
    """The structured record returned by ``should_pay_x402``.

    This is the wire contract between the cage and the agent. All fields
    are JSON-safe through :meth:`to_wire`. Agents call ``decision.allowed``
    to branch on permit / deny; they call ``decision.reason`` to get a
    structured reason; they call ``decision.next_action`` to get a
    canonical instruction.

    Attributes:
        allowed: true iff the payment should proceed on the wire. This
            is the same "wire outcome" as the v0.13 signed envelope
            produces — shadow/advisory mode can still have
            ``allowed=True`` even when ``risk_prevented`` is populated
            (because shadow never rejects on the wire).
        reason: canonical DecisionReason. ``"allowed"`` on permit,
            a deny reason otherwise.
        rule_id: low-level rule_id of the invariant that fired, when
            known. Preserved so auditors can cross-reference with the
            daemon's existing history / verdict stream. ``None`` on
            permit or on fail-closed.
        reason_text: plain-English explanation copied from the
            underlying violation. ``None`` on permit.
        retry_after_seconds: hint for ``retry_later`` /
            ``wait_for_cooldown`` next_actions. ``None`` when the
            reason carries no natural retry hint (e.g. spend cap).
        effective_policy_revision: the ``policy_revision_id`` under
            which this decision was made. Lets the agent pin its
            reasoning to a specific policy state.
        proof_mode: which prover admitted this decision
            (pattern / tau / z3 / hybrid). ``None`` in compat mode.
        proof_backend: raw backend string for debugging / metrics.
        proof_strength: the daemon's strength label
            (``"tau-sat"``, ``"pattern+tau-inconclusive"``, …).
        cage_mode: the daemon's operating mode at decision time.
            Always populated so the agent cannot forget to branch on
            shadow vs enforce.
        risk_prevented: populated on deny. ``None`` on permit and
            on ``cage_unavailable`` (we have no basis to estimate).
        next_action: canonical instruction the agent should follow.
            See :data:`NextAction` for the full set.
        signed_envelope: the v2 signed envelope (verbatim). Carried so
            an auditor can verify the decision offline without a second
            round-trip. Empty dict ``{}`` when no envelope was produced
            (fail-closed path).
    """

    allowed: bool
    reason: DecisionReason
    rule_id: Optional[str] = None
    reason_text: Optional[str] = None
    retry_after_seconds: Optional[int] = None
    effective_policy_revision: Optional[str] = None
    proof_mode: Optional[ProofMode] = None
    proof_backend: Optional[str] = None
    proof_strength: Optional[str] = None
    cage_mode: CageModeLiteral = "enforce"
    risk_prevented: Optional[RiskPrevented] = None
    next_action: NextAction = "proceed"
    signed_envelope: Mapping[str, Any] = field(default_factory=dict)
    # v0.19.0 Guaranteed Mode fields. Default ``mode="flexible"`` keeps
    # every pre-v0.19 callsite byte-identical on the wire: JSON consumers
    # that ignore unknown keys see no change; consumers that branch on
    # ``mode`` can opt into the ``"guaranteed"`` path explicitly.
    #
    # ``guaranteed_provenance`` is populated ONLY when ``mode == "guaranteed"``.
    # It carries the proof-artifact + runtime-guard-state provenance that
    # bank auditors require on every decision record.
    #
    # ``guaranteed_reason`` carries the structured failure code from the
    # guaranteed path. Independent of the existing 16-reason taxonomy
    # (which is preserved unchanged) so dashboards can render both
    # alongside each other.
    mode: DecisionMode = "flexible"
    guaranteed_provenance: Optional[Mapping[str, Any]] = None
    guaranteed_reason: Optional[GuaranteedFailureCodeLiteral] = None
    # ── v0.21.0 Adaptive Tightening fields (agent A) ────────────────────
    #
    # Default ``None`` keeps every pre-v0.21 callsite byte-identical on
    # the wire. Populated only when the adaptive-tightening layer fires
    # (Flexible Mode only — Guaranteed Mode ignores the tightening
    # clamp, so these stay ``None`` on guaranteed decisions).
    tightening_level: Optional[float] = None
    adjusted_limits: Optional[Mapping[str, Any]] = None
    trigger: Optional[str] = None
    prevented_risk: Optional[Mapping[str, Any]] = None
    # ── v0.23.0 adaptive-tightening visibility (agent hero-demo-visibility) ──
    #
    # Default ``None`` keeps pre-v0.23 callsites byte-identical on the wire.
    # Populated only when ``tightening_level`` is > 0 (i.e. the adaptive
    # tightening clamp is active). When inactive every new field stays
    # ``None`` so consumers that branch on presence do not need special
    # handling.
    #
    # ``decay_status``: {"halflife_seconds": int, "current_level": float,
    # "projected_level_at_plus_60s": float}. Surfaces the decay trajectory
    # so an agent knows how long the clamp will stay meaningful.
    #
    # ``tightening_next_action``: action the agent should take based on
    # which trigger fired. One of
    # ``"wait_for_cooldown" | "reduce_retry_rate"
    # | "stop_submitting_identical_intents" | "slow_spend_velocity"``.
    # Named to avoid shadowing the existing (broader) ``next_action``
    # field that every decision envelope already carries.
    #
    # ``human_explanation``: always-populated plain-English string
    # alongside the machine-readable envelope so a dashboard row can
    # render something useful without re-deriving the narrative from the
    # witness. Example: "The agent retried this paid request 7 times in
    # 9 seconds. The system tightened the active policy and blocked
    # further spend for 45 seconds."
    decay_status: Optional[Mapping[str, Any]] = None
    tightening_next_action: Optional[str] = None
    human_explanation: Optional[str] = None
    # ── v0.23.0 composed + revision-context surface (agent hero-demo-visibility) ──
    #
    # ``revision_context`` is a short, plain-English synthesised string
    # derived from the existing ``previous_policy_revision`` /
    # ``current_policy_revision`` / ``revision_transition_issue`` fields.
    # Populated only when a meaningful cross-revision transition is worth
    # calling out (default ``None`` keeps pre-v0.23 envelopes unchanged).
    # Example: "rev_13 tightened after repeated failures".
    revision_context: Optional[str] = None
    # ── v0.21.0 composition fields (agent B) ────────────────────────────
    #
    # ``violations`` lists every rule_id that fired on this intent when
    # the registry evaluated every active invariant (rather than
    # stopping at the first). On a composed reject the tuple has >= 2
    # entries and ``reason`` is ``"composed_constraint_violation"``.
    # ``near_thresholds`` records invariants within 20% of firing
    # (distance_to_violation >= 0.8). Keys are rule_ids; values are
    # floats in ``[0.0, 1.0]`` where 1.0 means "fires" and 0.0 means
    # "full headroom".
    violations: Optional[Sequence[str]] = None
    near_thresholds: Optional[Mapping[str, float]] = None
    # ── v0.21.0 cross-revision runtime awareness (agent B) ──────────────
    #
    # Surface the revision-context at decision time. ``None`` when the
    # registry has no revision log wired. ``revision_transition_issue``
    # is populated only when the runtime observed a policy evolution
    # the caller should warn about (canonical example:
    # ``limit_relaxation_during_active_tightening``).
    previous_policy_revision: Optional[str] = None
    current_policy_revision: Optional[str] = None
    revision_transition_issue: Optional[Mapping[str, Any]] = None
    # ── v0.21.0 bank-mode envelope alignment (agent B) ──────────────────
    #
    # Every decision carries symmetric prover-mode + guarantee-flag
    # provenance. ``prover_mode`` mirrors the existing ``mode`` field
    # (kept for back-compat); callers who branch on ``mode`` keep
    # working, callers who want the brief's field name read
    # ``prover_mode``. ``guarantee_flag`` is True iff the decision was
    # bound by a real proof artifact — never True on flexible decisions
    # even when they happened to be decisive.
    prover_mode: DecisionMode = "flexible"
    guarantee_flag: bool = False

    def to_wire(self) -> dict[str, Any]:
        """Serialise to a JSON-safe dict.

        This is what the daemon op + MCP tool both emit. We serialise
        by hand (rather than ``dataclasses.asdict``) so the nested
        ``RiskPrevented`` goes through its own ``to_wire`` and the
        ``signed_envelope`` passes through unchanged.
        """
        return {
            "allowed": bool(self.allowed),
            "reason": self.reason,
            "rule_id": self.rule_id,
            "reason_text": self.reason_text,
            "retry_after_seconds": self.retry_after_seconds,
            "effective_policy_revision": self.effective_policy_revision,
            "proof_mode": self.proof_mode,
            "proof_backend": self.proof_backend,
            "proof_strength": self.proof_strength,
            "cage_mode": self.cage_mode,
            "risk_prevented": (
                self.risk_prevented.to_wire()
                if self.risk_prevented is not None
                else None
            ),
            "next_action": self.next_action,
            "signed_envelope": dict(self.signed_envelope) if self.signed_envelope else {},
            "mode": self.mode,
            "guaranteed_provenance": (
                dict(self.guaranteed_provenance)
                if self.guaranteed_provenance is not None
                else None
            ),
            "guaranteed_reason": self.guaranteed_reason,
            # v0.21.0 adaptive-tightening fields (agent A)
            "tightening_level": self.tightening_level,
            "adjusted_limits": (
                dict(self.adjusted_limits)
                if self.adjusted_limits is not None
                else None
            ),
            "trigger": self.trigger,
            "prevented_risk": (
                dict(self.prevented_risk)
                if self.prevented_risk is not None
                else None
            ),
            # v0.21.0 composition fields (agent B)
            "violations": (
                list(self.violations) if self.violations is not None else None
            ),
            "near_thresholds": (
                dict(self.near_thresholds)
                if self.near_thresholds is not None
                else None
            ),
            # v0.21.0 cross-revision runtime awareness (agent B)
            "previous_policy_revision": self.previous_policy_revision,
            "current_policy_revision": self.current_policy_revision,
            "revision_transition_issue": (
                dict(self.revision_transition_issue)
                if self.revision_transition_issue is not None
                else None
            ),
            # v0.21.0 bank-mode envelope alignment (agent B)
            "prover_mode": self.prover_mode,
            "guarantee_flag": bool(self.guarantee_flag),
            # v0.23.0 adaptive-tightening visibility
            "decay_status": (
                dict(self.decay_status)
                if self.decay_status is not None
                else None
            ),
            "tightening_next_action": self.tightening_next_action,
            "human_explanation": self.human_explanation,
            "revision_context": self.revision_context,
        }

    @classmethod
    def from_wire(cls, payload: Mapping[str, Any]) -> "PaymentDecision":
        """Parse a wire dict back into a PaymentDecision.

        Defensive: tolerates missing fields (reason becomes
        ``policy_inconclusive``) and unknown literals (next_action falls
        back to ``abort``). The caller should treat ``from_wire`` on a
        malformed payload the same way it treats ``cage_unavailable``.
        """
        reason = payload.get("reason") or "policy_inconclusive"
        if reason not in DECISION_REASONS:
            reason = "policy_inconclusive"
        cage_mode = payload.get("cage_mode") or "enforce"
        if cage_mode not in ("enforce", "shadow", "advisory"):
            cage_mode = "enforce"
        next_action = payload.get("next_action") or "abort"
        if next_action not in (
            "proceed",
            "wait_for_cooldown",
            "request_approval",
            "adjust_policy",
            "retry_later",
            "abort",
        ):
            next_action = "abort"
        risk_raw = payload.get("risk_prevented")
        risk: Optional[RiskPrevented] = None
        if isinstance(risk_raw, Mapping):
            spend_raw = risk_raw.get("estimated_extra_spend_blocked")
            spend: Optional[Decimal]
            if spend_raw is None:
                spend = None
            else:
                try:
                    spend = Decimal(str(spend_raw))
                except Exception:  # noqa: BLE001 — defensive
                    spend = None
            source = risk_raw.get("source") or "rule_composition"
            if source not in ("retry_density", "spend_velocity", "rule_composition"):
                source = "rule_composition"
            risk = RiskPrevented(
                estimated_extra_calls_blocked=(
                    int(risk_raw["estimated_extra_calls_blocked"])
                    if risk_raw.get("estimated_extra_calls_blocked") is not None
                    else None
                ),
                estimated_extra_spend_blocked=spend,
                currency=risk_raw.get("currency"),
                source=source,  # type: ignore[arg-type]
            )
        proof_mode = payload.get("proof_mode")
        if proof_mode is not None and proof_mode not in ("pattern", "tau", "z3", "hybrid"):
            proof_mode = None
        mode = payload.get("mode") or "flexible"
        if mode not in ("flexible", "guaranteed"):
            mode = "flexible"
        guaranteed_provenance_raw = payload.get("guaranteed_provenance")
        guaranteed_provenance: Optional[Mapping[str, Any]]
        if isinstance(guaranteed_provenance_raw, Mapping):
            guaranteed_provenance = dict(guaranteed_provenance_raw)
        else:
            guaranteed_provenance = None
        guaranteed_reason = payload.get("guaranteed_reason")
        if guaranteed_reason is not None and guaranteed_reason not in (
            "RUNTIME_GUARD_VIOLATION",
            "RUNTIME_EVALUATION_UNAVAILABLE",
            "TOTALITY_VIOLATION",
            "PROOF_UNAVAILABLE",
            "PROOF_INCONSISTENT",
            "REVISION_TRANSITION_VIOLATION",
            "MUTATION_NOT_ACTIVATABLE",
        ):
            guaranteed_reason = None
        # v0.21.0 adaptive-tightening fields (agent A) — defensive parsing.
        tightening_level_raw = payload.get("tightening_level")
        tightening_level: Optional[float]
        if tightening_level_raw is None:
            tightening_level = None
        else:
            try:
                tightening_level = float(tightening_level_raw)
            except (TypeError, ValueError):
                tightening_level = None
        adjusted_limits_raw = payload.get("adjusted_limits")
        adjusted_limits: Optional[Mapping[str, Any]]
        if isinstance(adjusted_limits_raw, Mapping):
            adjusted_limits = dict(adjusted_limits_raw)
        else:
            adjusted_limits = None
        prevented_risk_raw = payload.get("prevented_risk")
        prevented_risk: Optional[Mapping[str, Any]]
        if isinstance(prevented_risk_raw, Mapping):
            prevented_risk = dict(prevented_risk_raw)
        else:
            prevented_risk = None
        trigger = payload.get("trigger")
        if trigger is not None and not isinstance(trigger, str):
            trigger = None
        # v0.21.0 composition fields (agent B) — defensive parsing; malformed
        # reads as ``None`` so pre-v0.21 envelopes round-trip unchanged.
        violations_raw = payload.get("violations")
        violations: Optional[Tuple[str, ...]] = None
        if isinstance(violations_raw, (list, tuple)):
            collected = tuple(str(v) for v in violations_raw)
            if collected:
                violations = collected
        near_thresholds_raw = payload.get("near_thresholds")
        near_thresholds: Optional[Mapping[str, float]] = None
        if isinstance(near_thresholds_raw, Mapping):
            parsed: dict[str, float] = {}
            for k, v in near_thresholds_raw.items():
                try:
                    parsed[str(k)] = float(v)
                except (TypeError, ValueError):
                    continue
            if parsed:
                near_thresholds = parsed
        revision_transition_issue_raw = payload.get("revision_transition_issue")
        revision_transition_issue: Optional[Mapping[str, Any]]
        if isinstance(revision_transition_issue_raw, Mapping):
            revision_transition_issue = dict(revision_transition_issue_raw)
        else:
            revision_transition_issue = None
        prover_mode_raw = payload.get("prover_mode") or mode
        if prover_mode_raw not in ("flexible", "guaranteed"):
            prover_mode_raw = "flexible"
        # v0.23.0 adaptive-tightening visibility — defensive parsing.
        # Unknown / malformed fields read as ``None`` so pre-v0.23 envelopes
        # round-trip unchanged.
        decay_status_raw = payload.get("decay_status")
        decay_status: Optional[Mapping[str, Any]]
        if isinstance(decay_status_raw, Mapping):
            decay_status = dict(decay_status_raw)
        else:
            decay_status = None
        tightening_next_action_raw = payload.get("tightening_next_action")
        if tightening_next_action_raw is not None and not isinstance(
            tightening_next_action_raw, str
        ):
            tightening_next_action_raw = None
        human_explanation_raw = payload.get("human_explanation")
        if human_explanation_raw is not None and not isinstance(
            human_explanation_raw, str
        ):
            human_explanation_raw = None
        revision_context_raw = payload.get("revision_context")
        if revision_context_raw is not None and not isinstance(
            revision_context_raw, str
        ):
            revision_context_raw = None
        return cls(
            allowed=bool(payload.get("allowed", False)),
            reason=reason,  # type: ignore[arg-type]
            rule_id=payload.get("rule_id"),
            reason_text=payload.get("reason_text"),
            retry_after_seconds=payload.get("retry_after_seconds"),
            effective_policy_revision=payload.get("effective_policy_revision"),
            proof_mode=proof_mode,  # type: ignore[arg-type]
            proof_backend=payload.get("proof_backend"),
            proof_strength=payload.get("proof_strength"),
            cage_mode=cage_mode,  # type: ignore[arg-type]
            risk_prevented=risk,
            next_action=next_action,  # type: ignore[arg-type]
            signed_envelope=dict(payload.get("signed_envelope") or {}),
            mode=mode,  # type: ignore[arg-type]
            guaranteed_provenance=guaranteed_provenance,
            guaranteed_reason=guaranteed_reason,  # type: ignore[arg-type]
            tightening_level=tightening_level,
            adjusted_limits=adjusted_limits,
            trigger=trigger,
            prevented_risk=prevented_risk,
            violations=violations,
            near_thresholds=near_thresholds,
            previous_policy_revision=payload.get("previous_policy_revision"),
            current_policy_revision=payload.get("current_policy_revision"),
            revision_transition_issue=revision_transition_issue,
            prover_mode=prover_mode_raw,  # type: ignore[arg-type]
            guarantee_flag=bool(payload.get("guarantee_flag", False)),
            # v0.23.0 adaptive-tightening visibility — see field docstrings.
            decay_status=decay_status,
            tightening_next_action=tightening_next_action_raw,
            human_explanation=human_explanation_raw,
            revision_context=revision_context_raw,
        )


# ── rule_id -> DecisionReason mapping ───────────────────────────────────────


#: Deterministic mapping from the existing internal rule_ids (emitted by
#: ``adapter/invariants.py`` and ``adapter/self_ref_policy.py``) to the
#: canonical DecisionReason taxonomy. The table is intentionally
#: exhaustive — every rule_id the daemon ever produces has exactly one
#: canonical reason. Unknown rule_ids fall through to
#: ``policy_inconclusive`` so new rules introduced upstream do not
#: silently leak as ``allowed`` on the agent side.
#:
#: Mapping rationale (one line per entry):
_RULE_ID_REASON: Final[dict[str, DecisionReason]] = {
    # Spending-cap family — all per-tx / per-window / per-provider-window
    # variants roll up to the same reason because the agent's response
    # is identical ("you're over budget; stop").
    "max_per_call": "spend_cap_exceeded",
    "spending_cap_per_tx": "spend_cap_exceeded",
    "spending_cap_per_window": "spend_cap_exceeded",
    "spending_cap_per_provider_per_window": "spend_cap_exceeded",
    # Retry-loop detection — cooldown timer carries the retry-after hint.
    "retry_rate_limit": "retry_loop_detected",
    # Rolling-window caps — burst-velocity is the agent's mental model
    # ("too many calls too fast"). Differentiated from spend-cap in the
    # dashboards because the remedy is different: throttle, not budget.
    "rolling_window_cap_provider": "burst_velocity_exceeded",
    "rolling_window_cap_counterparty": "burst_velocity_exceeded",
    "rolling_window_cap_global": "burst_velocity_exceeded",
    # Provider / counterparty allowlist and sanction checks.
    "provider_allowlist": "provider_not_allowed",
    "counterparty_sanctioned": "counterparty_not_allowed",
    "counterparty_not_approved": "counterparty_not_allowed",
    # Mutual exclusion — rule_rule contradiction surfaces as its own
    # canonical reason so composed policies can be diagnosed separately
    # from single-rule rejects.
    "mutual_exclusion": "mutual_exclusion",
    # Instability guard (self-ref): adaptive_tightening_triggered covers
    # the acting policy state; instability_guard_tightened covers the
    # individual guard firing on a single intent.
    "instability_guard": "instability_guard_tightened",
    # Cross-revision governance / validation — surfaced by the cross
    # revision validator machinery.
    "cross_revision_violation": "cross_revision_violation",
    "governance_violation": "governance_violation",
    # Fail-closed path — the cage is unreachable or returned a malformed
    # response; the client SDK stamps this rule_id.
    "cage_unavailable": "cage_unavailable",
    # Invalid / malformed request — auditor-visible bucket under
    # "policy_inconclusive" since the cage could not form an opinion.
    "invalid_payment_intent": "policy_inconclusive",
    "malformed_request": "policy_inconclusive",
}


def rule_id_to_reason(rule_id: Optional[str]) -> DecisionReason:
    """Map a low-level rule_id to the canonical DecisionReason taxonomy.

    * None → ``allowed`` (permit path emits a null rule_id).
    * Exact match in the mapping → the canonical reason.
    * JurisdictionRule's prefix ``jurisdiction_<code>.<inner>`` →
      ``jurisdiction_not_allowed`` (the prefix is load-bearing; we
      strip it and map the inner rule_id for auditors, but the
      canonical reason collapses to the jurisdiction bucket).
    * Unknown → ``policy_inconclusive``. Fail-closed on unknowns so a
      future rule_id never accidentally reads as ``allowed``.
    """
    if rule_id is None:
        return "allowed"
    # Jurisdiction-prefixed rule_ids collapse to the jurisdiction bucket
    # for the agent-facing taxonomy.
    if rule_id.startswith("jurisdiction_"):
        return "jurisdiction_not_allowed"
    return _RULE_ID_REASON.get(rule_id, "policy_inconclusive")


# ── next_action inference ───────────────────────────────────────────────────


def next_action_for(
    reason: DecisionReason,
    retry_after: Optional[int] = None,
) -> NextAction:
    """Canonical next_action for a given decision reason.

    The agent should follow this instruction unless it has local
    policy overriding it (e.g. "always prompt the human on cap hits").
    The mapping is stable wire contract like the reason enum itself.

    * ``allowed`` → ``proceed``.
    * Transient-backoff reasons (retry loop, cooldown, burst) →
      ``wait_for_cooldown`` if retry_after is known, else ``retry_later``.
    * Irrecoverable-without-policy-change reasons (cap exceeded,
      provider not allowed, counterparty not allowed, jurisdiction,
      mutual exclusion, instability guard tightened,
      cross-revision / governance violations) → ``adjust_policy``.
    * ``approval_required`` → ``request_approval``.
    * ``policy_inconclusive`` → ``abort`` (safer than retry on an
      inconclusive proof — an inconclusive cage has no opinion to
      exploit).
    * ``cage_unavailable`` → ``abort`` (fail-closed; the agent MUST
      not paper over the outage by retrying blindly).
    """
    if reason == "allowed":
        return "proceed"
    if reason == "approval_required":
        return "request_approval"
    if reason == "cage_unavailable":
        return "abort"
    if reason == "policy_inconclusive":
        return "abort"
    if reason in (
        "retry_loop_detected",
        "cooldown_active",
        "burst_velocity_exceeded",
        "adaptive_tightening_triggered",
    ):
        # Adaptive tightening is transient by construction (decays to
        # baseline). Route the agent to wait for the clamp to relax
        # rather than to mutate the policy — the baseline is already
        # admissive enough; the tightening is the transient clamp.
        if retry_after is not None and retry_after > 0:
            return "wait_for_cooldown"
        return "retry_later"
    # v0.21.0 composed + revision-transition reasons: both require a
    # policy-side change before the next call can succeed (either
    # untangle the rule composition, or let the transition warning
    # resolve). ``adjust_policy`` is correct for both — the agent
    # should route the decision to governance rather than silently
    # retry.
    if reason in ("composed_constraint_violation", "revision_transition_violation"):
        return "adjust_policy"
    # All remaining deny reasons require the policy to change before the
    # next call can succeed. "adjust_policy" tells the agent to propose a
    # policy change (via the governance queue) rather than retry.
    return "adjust_policy"


# ── v0.23.0 adaptive-tightening visibility helpers ──────────────────────────


#: Default adaptive-tightening half-life in seconds. Kept in sync with
#: ``adapter.adaptive_tightening.DEFAULT_HALF_LIFE_SECONDS`` without
#: importing that module so this file has no runtime dependency on the
#: tightening backend.
_DEFAULT_TIGHTENING_HALF_LIFE_S: Final[int] = 900


def decay_status_for(
    *,
    tightening_level: Optional[float],
    halflife_seconds: int = _DEFAULT_TIGHTENING_HALF_LIFE_S,
    projection_seconds: int = 60,
) -> Optional[dict[str, Any]]:
    """Compute the ``decay_status`` envelope block for a given level.

    Returns ``None`` when ``tightening_level`` is ``None`` or ``<= 0``
    so the envelope's "zero-break" property is preserved.

    ``projected_level_at_plus_60s`` uses the same exponential decay
    formula as :mod:`adapter.adaptive_tightening`:

        level(t) = level(t0) * 0.5 ** (dt / half_life)
    """
    if tightening_level is None:
        return None
    try:
        level = float(tightening_level)
    except (TypeError, ValueError):
        return None
    if level <= 0.0:
        return None
    hl = max(1, int(halflife_seconds))
    proj_s = max(0, int(projection_seconds))
    factor = 0.5 ** (proj_s / float(hl))
    projected = level * factor
    return {
        "halflife_seconds": hl,
        "current_level": level,
        "projected_level_at_plus_60s": projected,
    }


#: Canonical mapping from adaptive-tightening trigger name to the
#: action-oriented hint the agent should follow. Stable wire values so
#: downstream consumers can encode a match without a default.
_TIGHTENING_TRIGGER_ACTION: Final[dict[str, str]] = {
    "retry_density": "reduce_retry_rate",
    "retry_density_exceeded": "reduce_retry_rate",
    "identical_request": "stop_submitting_identical_intents",
    "identical_request_hammering": "stop_submitting_identical_intents",
    "velocity_spike": "slow_spend_velocity",
    "velocity_spike_detected": "slow_spend_velocity",
    "denial_rate": "wait_for_cooldown",
    "denial_rate_exceeded": "wait_for_cooldown",
}


def build_revision_context(
    *,
    previous_policy_revision: Optional[str],
    current_policy_revision: Optional[str],
    revision_transition_issue: Optional[Mapping[str, Any]] = None,
    tightening_level: Optional[float] = None,
    trigger: Optional[str] = None,
) -> Optional[str]:
    """Synthesise a plain-English cross-revision evolution string.

    The daemon already carries the raw ``previous_policy_revision`` /
    ``current_policy_revision`` pair and optional
    ``revision_transition_issue`` struct. This helper reads those fields
    and produces a short human string for ``revision_context``.

    Returns ``None`` when no meaningful transition is worth calling out
    (no revision change AND no tightening event). The caller should
    treat the absence of a string as "normal cross-revision state".

    Examples:

      * ``("rev_12", "rev_13", {"kind": "limit_relaxation_during_active_tightening"}, 0.7, None)``
        → ``"rev_13 tightened after repeated failures (limit relaxation
        during active tightening)"``
      * ``("rev_12", "rev_13", None, 0.7, "retry_density_exceeded")``
        → ``"rev_13 tightened after repeated failures"``
      * ``(None, None, None, 0.0, None)`` → ``None``
    """
    prev = previous_policy_revision
    cur = current_policy_revision
    has_transition = isinstance(revision_transition_issue, Mapping) and bool(
        revision_transition_issue
    )
    has_tightening = (
        tightening_level is not None and float(tightening_level) > 0.0
    )
    revisions_differ = prev and cur and prev != cur
    if not (has_transition or has_tightening or revisions_differ):
        return None
    # Pick the "anchor" revision: current if we have it, otherwise previous.
    anchor = cur or prev or "active revision"
    # Build the base phrase. Tightening after repeated failures is the
    # canonical case; fall back to a simpler transition note when there
    # is no tightening signal.
    if has_tightening:
        base = f"{anchor} tightened after repeated failures"
    elif revisions_differ:
        base = f"{prev} -> {cur} transition"
    else:
        base = f"{anchor} evolution"
    # Suffix with the structured transition kind, if present, so an
    # operator can see exactly which warning fired.
    if has_transition:
        assert isinstance(revision_transition_issue, Mapping)
        kind_raw = revision_transition_issue.get("kind")
        if isinstance(kind_raw, str) and kind_raw:
            pretty = kind_raw.replace("_", " ")
            if pretty not in base:
                base = f"{base} ({pretty})"
    return base


def tightening_next_action_for(trigger: Optional[str]) -> Optional[str]:
    """Derive the action suggestion from which trigger fired.

    Unknown / absent triggers fall back to ``"wait_for_cooldown"`` so the
    agent always has a safe default. ``None`` when the trigger is ``None``
    (i.e. tightening is inactive).
    """
    if trigger is None:
        return None
    return _TIGHTENING_TRIGGER_ACTION.get(trigger, "wait_for_cooldown")


__all__ = [
    "CageModeLiteral",
    "DECISION_REASONS",
    "DecisionMode",
    "DecisionReason",
    "GuaranteedFailureCodeLiteral",
    "NextAction",
    "PaymentDecision",
    "ProofMode",
    "RiskPrevented",
    "RiskSource",
    "build_revision_context",
    "decay_status_for",
    "next_action_for",
    "rule_id_to_reason",
    "tightening_next_action_for",
]
