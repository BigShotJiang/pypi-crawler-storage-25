"""Pre-declare policy linter (v0.10.0).

Offline static analysis for ``policy.yaml``. Runs the same fragment-v1 /
fragment-v2 / cross-fragment consistency checks the daemon performs at
declare time — but as a single-process, subsecond command you run from
CI or a pre-commit hook. No daemon required, no socket, no prover
background state.

Public surface
--------------

    lint_policy_file(path: Path) -> LintReport
    LintReport                                 (dataclass)
    LintFinding                                (dataclass)
    LintError                                  (exception — unrecoverable
                                                 errors that make a
                                                 LintReport impossible,
                                                 e.g. malformed YAML)

Why pre-declare
---------------

The Tau-flex pitch is "declare-time contradiction detection." Policy
files hit the linter before they ever touch a live daemon. Policies that
ship with a known-UNSAT fragment fail CI instead of discovering the
problem in production when the first ``check_payment`` lands on the
offending invariant pair.

Finding codes
-------------

``LINT001`` error    pattern-level contradiction
                     (cross-rule approved ∩ sanctioned overlap, multi-allowlist
                     empty intersection, or any other conflict
                     :class:`PythonPatternProver` flags).
``LINT002`` error    Tau-decidable contradiction (fragment-v1 UNSAT).
``LINT003`` error    z3 contradiction (fragment-v2 UNSAT).
``LINT004`` error    cross-fragment contradiction (v1 ProviderAllowlist
                     excludes a provider referenced by a v2 per-provider
                     SpendingCap, or similar shared-variable projection).
``LINT005`` warning  policy is decidable only under bounded unrolling
                     (N=10 default). Documents the horizon so operators
                     know the z3 verdict holds up to N window steps.
``LINT006`` warning  redundant invariant: one invariant is strictly
                     weaker than another (e.g. two ``MaxPerCall`` rules
                     on the same currency — the looser is dead code).
``LINT007`` info     policy is fragment-v1-only: Tau can fully decide
                     consistency (no bounded unrolling needed).

Exit semantics (see :mod:`daemon.cli` lint subcommand):

    0   no errors
    1   errors found (or warnings in --strict)
    2   file not found / YAML parse error / unknown invariant kind

The linter imports but never modifies :mod:`adapter.tau_compiler`,
:mod:`adapter.hybrid_prover`, :mod:`adapter.z3_compiler`, or
:mod:`adapter.policy_loader`. It reuses those modules as read-only
libraries so the lint verdict and the daemon admission verdict stay
byte-identical for the same policy bytes.
"""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Iterable, Optional, Sequence

from adapter.hybrid_prover import _cross_fragment_contradiction
from adapter.invariants import (
    CounterpartyConstraint,
    Invariant,
    MaxPerCall,
    ProviderAllowlist,
    RetryRateLimit,
    RollingWindowCap,
    SpendingCap,
)
from adapter.policy_loader import (
    LoadedPolicy,
    PolicyLoaderError,
    load_policy,
)
from adapter.prover import (
    Contradiction,
    InconclusiveProof,
    ProofToken,
    PythonPatternProver,
    TauConsistencyProver,
)
from adapter.tau_compiler import (
    UnsupportedInvariantError,
    compile_policy,
    fragment_members,
)
from adapter.z3_compiler import is_fragment_v2_invariant


SEVERITIES = ("error", "warning", "info")

# Default unrolling horizon for fragment v2. Mirrors
# ``IncrementalZ3Prover.unroll_steps`` / ``Z3ConsistencyProver.unroll_steps``
# so the linter verdict agrees with the daemon verdict byte-for-byte.
DEFAULT_UNROLL_STEPS = 10


class LintError(RuntimeError):
    """Unrecoverable error while linting (e.g. file missing, YAML broken).

    Callers surface this as exit code 2. It is NOT a finding — a finding
    presupposes we at least parsed a policy.
    """


# ── result types ─────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class LintFinding:
    """One issue the linter surfaced.

    Fields
    ------
    severity
        ``"error"`` | ``"warning"`` | ``"info"``. Errors fail CI by
        default; warnings fail CI only under ``--strict``; info is
        always advisory.
    code
        Stable short identifier (``"LINT001"``…``"LINT007"``). CI pipelines
        key on this to allow-list specific findings.
    message
        Human-readable one-line explanation.
    invariants
        Class names of the invariants involved. Two-element for pair
        conflicts; N-element for N-ary multi-rule conflicts; empty for
        policy-wide findings (e.g. LINT007 info).
    suggested_repair
        Optional hint for the operator (e.g. "drop the looser
        MaxPerCall"). ``None`` when no obvious repair exists.
    """

    severity: str
    code: str
    message: str
    invariants: tuple[str, ...] = field(default_factory=tuple)
    suggested_repair: Optional[str] = None

    def __post_init__(self) -> None:
        if self.severity not in SEVERITIES:
            raise ValueError(
                f"LintFinding.severity must be one of {SEVERITIES}, "
                f"got {self.severity!r}"
            )

    def to_dict(self) -> dict:
        return {
            "severity": self.severity,
            "code": self.code,
            "message": self.message,
            "invariants": list(self.invariants),
            "suggested_repair": self.suggested_repair,
        }


@dataclass(frozen=True)
class LintReport:
    """Structured output of a single ``lint_policy_file`` call.

    Attributes
    ----------
    findings
        Every :class:`LintFinding` the linter surfaced, in the order
        they were discovered (pattern-prover first, then Tau, then z3,
        then cross-fragment, then redundancy / info).
    summary
        Counts keyed by severity: ``{"errors": int, "warnings": int,
        "info": int}``.
    fragment_breakdown
        Number of invariants routed to each fragment:
        ``{"v1": int, "v2": int, "hybrid": int}`` where ``hybrid``
        counts the policy as a whole when it spans both fragments.
    decidable
        True iff the policy can be decided without bounded unrolling
        (i.e. every invariant lives in fragment v1). False whenever any
        v2 invariant is present; see LINT005 for the horizon caveat.
    source_path
        Absolute path to the policy file the report came from.
    """

    findings: tuple[LintFinding, ...]
    summary: dict
    fragment_breakdown: dict
    decidable: bool
    source_path: str

    def has_errors(self) -> bool:
        return self.summary.get("errors", 0) > 0

    def has_warnings(self) -> bool:
        return self.summary.get("warnings", 0) > 0

    def to_dict(self) -> dict:
        return {
            "findings": [f.to_dict() for f in self.findings],
            "summary": dict(self.summary),
            "fragment_breakdown": dict(self.fragment_breakdown),
            "decidable": self.decidable,
            "source_path": self.source_path,
        }

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), sort_keys=True, indent=2)

    def to_text(self) -> str:
        """Render as an aligned human-readable block (one finding per line).

        Format (greppable):

            <SEV> <code>: <message>
                involves: <ClassA>, <ClassB>
                repair:   <hint>
        """
        lines: list[str] = []
        lines.append(f"Policy lint: {self.source_path}")
        lines.append(
            f"  fragments: v1={self.fragment_breakdown.get('v1', 0)} "
            f"v2={self.fragment_breakdown.get('v2', 0)} "
            f"hybrid={self.fragment_breakdown.get('hybrid', 0)}  "
            f"decidable={self.decidable}"
        )
        lines.append(
            f"  summary:   errors={self.summary.get('errors', 0)} "
            f"warnings={self.summary.get('warnings', 0)} "
            f"info={self.summary.get('info', 0)}"
        )
        if not self.findings:
            lines.append("  (no findings)")
            return "\n".join(lines) + "\n"
        for f in self.findings:
            lines.append(f"{f.severity.upper():>7} {f.code}: {f.message}")
            if f.invariants:
                lines.append(f"          involves: {', '.join(f.invariants)}")
            if f.suggested_repair:
                lines.append(f"          repair:   {f.suggested_repair}")
        return "\n".join(lines) + "\n"


# ── entry point ──────────────────────────────────────────────────────────────


def lint_policy_file(path: Path | str) -> LintReport:
    """Load + lint a policy YAML file, returning a :class:`LintReport`.

    Loading errors (missing file, bad YAML, unknown invariant kind) are
    raised as :class:`LintError` so the CLI can surface them as exit
    code 2. Everything else — including contradictions — comes back as
    structured findings inside the returned report.
    """
    p = Path(path)
    try:
        loaded = load_policy(p)
    except PolicyLoaderError as exc:
        raise LintError(str(exc)) from exc

    return lint_policy(loaded)


def lint_policy(loaded: LoadedPolicy) -> LintReport:
    """Lint an already-parsed :class:`LoadedPolicy`.

    Factored out so tests (and :mod:`daemon.cli`) can feed a
    ``LoadedPolicy`` directly without round-tripping through disk. The
    findings order matches :func:`lint_policy_file`.
    """
    invariants = loaded.invariants
    findings: list[LintFinding] = []

    # 1. pattern-prover check — catches multi-rule approved/sanctioned
    #    clash, multi-allowlist empty intersection, and whatever else
    #    PythonPatternProver flags. Cheap, so run it first.
    pattern_findings = _check_pattern(invariants)
    findings.extend(pattern_findings)

    # 2. fragment routing. `v1_subset` feeds compile_policy; `v2_subset`
    #    feeds z3. The counts also determine LINT005 / LINT007.
    v1_subset = tuple(i for i in invariants if _is_v1_instance(i))
    v2_subset = tuple(i for i in invariants if is_fragment_v2_invariant(i))
    v1_count = len(v1_subset)
    v2_count = len(v2_subset)

    # 3. fragment v1 — Tau-decidable contradiction.
    if v1_subset:
        findings.extend(_check_fragment_v1(v1_subset))

    # 4. fragment v2 — z3 contradiction + bounded-unrolling warning.
    if v2_subset:
        findings.extend(_check_fragment_v2(v2_subset))

    # 5. cross-fragment projection. Only meaningful when BOTH fragments
    #    are populated — a single-fragment policy cannot have a cross
    #    contradiction by definition.
    if v1_subset and v2_subset:
        findings.extend(_check_cross_fragment(invariants))

    # 6. redundant invariant detection (LINT006 warning). Runs over the
    #    whole policy, independent of fragment.
    findings.extend(_check_redundancy(invariants))

    # 7. info: policy fits entirely in fragment v1.
    if v1_subset and not v2_subset and not _has_errors(findings):
        findings.append(LintFinding(
            severity="info",
            code="LINT007",
            message=(
                "Policy is fragment-v1-only: Tau can fully decide consistency "
                "without bounded unrolling."
            ),
        ))

    summary = _summary(findings)
    fragment_breakdown = {
        "v1": v1_count,
        "v2": v2_count,
        "hybrid": len(invariants) if (v1_subset and v2_subset) else 0,
    }
    return LintReport(
        findings=tuple(findings),
        summary=summary,
        fragment_breakdown=fragment_breakdown,
        decidable=(v2_count == 0),
        source_path=loaded.source_path,
    )


# ── per-check helpers ────────────────────────────────────────────────────────


def _check_pattern(invariants: Sequence[Invariant]) -> list[LintFinding]:
    """Run :class:`PythonPatternProver` and translate into LINT001 findings.

    The pattern prover never emits :class:`InconclusiveProof`, so the
    only interesting case is :class:`Contradiction`. A
    :class:`ProofToken` (pattern-SAT) means "no pattern-level clash" —
    we return an empty list.
    """
    prover = PythonPatternProver()
    result = prover.prove(invariants)
    if isinstance(result, Contradiction):
        return [_contradiction_to_finding(result, code="LINT001")]
    return []


def _check_fragment_v1(v1_subset: Sequence[Invariant]) -> list[LintFinding]:
    """Run the Tau decision procedure over the v1 subset; emit LINT002 on UNSAT.

    Tau may be unavailable in the linter environment (Tau CLI not on
    PATH, no DYLD setup, etc.). In that case :class:`TauConsistencyProver`
    falls through to the pattern prover and returns a
    ``proof_strength="pattern+tau-unavailable"`` token — which is NOT a
    contradiction, so we emit nothing. The LINT001 pattern check above
    already surfaced anything pattern-catchable, so the net loss is the
    Tau-only-catchable contradictions that are harder to surface without
    a live Tau. Those callers can still fail at daemon declare time.
    """
    prover = TauConsistencyProver()
    try:
        result = prover.prove(v1_subset)
    except Exception:  # noqa: BLE001
        # Defensive: the prover itself raised something unexpected. Treat
        # as "could not determine UNSAT" — we already have LINT001 for
        # pattern-level, so silently continue.
        return []
    if isinstance(result, Contradiction):
        # Skip if this is actually an UnsupportedInvariantError packaged
        # as Contradiction (right="fragment_v1"); that's a linter bug,
        # not a policy bug.
        if result.right == "fragment_v1":
            return []
        return [_contradiction_to_finding(result, code="LINT002")]
    return []


def _check_fragment_v2(v2_subset: Sequence[Invariant]) -> list[LintFinding]:
    """Compile the v2 subset to z3 and check SAT. Emits LINT003 + LINT005.

    Uses :func:`compile_policy_v2` + :func:`check_sat` directly so we
    can control the unroll horizon and surface timeouts as warnings.
    z3 unavailability collapses the v2 checks to "no finding" (the
    pattern prover still ran above, and LINT005 still fires to warn
    that the policy is only decidable under unrolling).
    """
    out: list[LintFinding] = []
    # LINT005 fires whenever v2 invariants are present, regardless of
    # whether z3 is installed — it's a property of the policy, not the
    # environment.
    out.append(LintFinding(
        severity="warning",
        code="LINT005",
        message=(
            f"Policy contains fragment-v2 invariants decidable only under "
            f"bounded unrolling (N={DEFAULT_UNROLL_STEPS} default). "
            f"z3 will explore up to {DEFAULT_UNROLL_STEPS} window steps; "
            f"a contradiction requiring more steps is not detected here."
        ),
        invariants=tuple(type(i).__name__ for i in v2_subset),
        suggested_repair=(
            "If your policy depends on horizons beyond N, raise "
            "unroll_steps in the daemon and document the horizon in your "
            "audit artifact."
        ),
    ))

    try:
        from adapter.z3_compiler import (
            Z3CompileError,
            Z3Unavailable,
            check_sat,
            compile_policy_v2,
        )
    except ImportError:
        return out

    try:
        compiled, solver = compile_policy_v2(
            v2_subset, unroll_steps=DEFAULT_UNROLL_STEPS,
        )
    except Z3Unavailable:
        return out
    except Z3CompileError as exc:
        out.append(LintFinding(
            severity="error",
            code="LINT003",
            message=f"z3 compile failed: {exc}",
            invariants=tuple(type(i).__name__ for i in v2_subset),
        ))
        return out

    try:
        verdict, detail = check_sat(solver, compiled, timeout_ms=10000)
    except Exception:  # noqa: BLE001
        return out

    if verdict == "unsat":
        out.append(LintFinding(
            severity="error",
            code="LINT003",
            message=f"Fragment-v2 (z3) proved the policy UNSAT: {detail}",
            invariants=tuple(type(i).__name__ for i in v2_subset),
            suggested_repair=(
                "Relax one of the temporal-arithmetic bounds "
                "(SpendingCap per_window, RollingWindowCap, or RetryRateLimit)."
            ),
        ))
    # "sat" or "unknown" -> no LINT003; LINT005 covers the unknown-via-timeout case.
    return out


def _check_cross_fragment(invariants: Sequence[Invariant]) -> list[LintFinding]:
    """Run the hybrid prover's shared-variable projection for LINT004.

    Reuses the same detector the daemon's
    :class:`adapter.hybrid_prover.HybridProver` invokes in step 4 of its
    admission flow. Keeps the lint verdict byte-identical to the daemon
    verdict for cross-fragment clashes.
    """
    xfrag = _cross_fragment_contradiction(invariants, backend="linter-projection")
    if xfrag is None:
        return []
    return [_contradiction_to_finding(xfrag, code="LINT004")]


def _check_redundancy(invariants: Sequence[Invariant]) -> list[LintFinding]:
    """Detect strictly-dominated invariants (LINT006).

    Currently covers:

      * Two or more :class:`MaxPerCall` rules on the same currency: the
        looser one is strictly unreachable because the tighter fires
        first. Same signal as :class:`PythonPatternProver`'s C2, but
        here we surface it as a warning rather than silently logging.

      * A :class:`SpendingCap` with ``scope="per_tx"`` whose cap is
        larger than a sibling :class:`MaxPerCall` on the same currency:
        MaxPerCall always fires first, the SpendingCap per_tx rule is
        dead (C5 from the pattern prover).

    Redundancy is surfaced as a WARNING, not an error: the policy is
    still satisfiable, just carrying dead code.
    """
    out: list[LintFinding] = []
    seen_keys: set[tuple] = set()

    # MaxPerCall dominance grouped by currency.
    mpc_by_currency: dict[str, list[MaxPerCall]] = {}
    for inv in invariants:
        if isinstance(inv, MaxPerCall):
            mpc_by_currency.setdefault(inv.currency, []).append(inv)
    for currency, rules in mpc_by_currency.items():
        if len(rules) < 2:
            continue
        tightest = min(rules, key=lambda r: r.max_amount)
        for r in rules:
            if r is tightest:
                continue
            if r.max_amount == tightest.max_amount:
                # Exact duplicate — also redundant, but emit once.
                key = ("MaxPerCall-dup", currency, str(r.max_amount))
                if key in seen_keys:
                    continue
                seen_keys.add(key)
                out.append(LintFinding(
                    severity="warning",
                    code="LINT006",
                    message=(
                        f"Duplicate MaxPerCall for currency {currency!r}: "
                        f"two rules with max_amount={r.max_amount}"
                    ),
                    invariants=("MaxPerCall", "MaxPerCall"),
                    suggested_repair="Remove one of the duplicate rules.",
                ))
                continue
            out.append(LintFinding(
                severity="warning",
                code="LINT006",
                message=(
                    f"Redundant MaxPerCall for currency {currency!r}: "
                    f"max_amount={r.max_amount} is strictly weaker than "
                    f"tighter rule max_amount={tightest.max_amount}."
                ),
                invariants=("MaxPerCall", "MaxPerCall"),
                suggested_repair=(
                    f"Drop the looser MaxPerCall(max_amount={r.max_amount}) — "
                    f"the tighter {tightest.max_amount} always fires first."
                ),
            ))

    # SpendingCap(per_tx) dominated by MaxPerCall on same currency.
    pertx_caps = [
        i for i in invariants
        if isinstance(i, SpendingCap) and i.scope == "per_tx"
    ]
    for cap in pertx_caps:
        for mpc in mpc_by_currency.get(cap.currency, []):
            if mpc.max_amount < cap.max_amount:
                out.append(LintFinding(
                    severity="warning",
                    code="LINT006",
                    message=(
                        f"Redundant SpendingCap(scope=per_tx, "
                        f"max_amount={cap.max_amount} {cap.currency}): "
                        f"MaxPerCall(max_amount={mpc.max_amount}) always "
                        f"fires first on same currency."
                    ),
                    invariants=("SpendingCap", "MaxPerCall"),
                    suggested_repair=(
                        "Drop the per_tx SpendingCap or tighten it below "
                        f"the MaxPerCall cap ({mpc.max_amount})."
                    ),
                ))
                break  # one finding per dominated cap is enough
    return out


# ── utility helpers ──────────────────────────────────────────────────────────


def _is_v1_instance(inv: Invariant) -> bool:
    """Classify an instance as fragment v1 (Tau-decided).

    Mirrors :func:`adapter.hybrid_prover._is_v1` — a class-level check
    plus a per-instance refinement for ``SpendingCap``. Inlined so we
    don't reach into a private module helper.
    """
    if type(inv) not in fragment_members("v1"):
        return False
    if isinstance(inv, SpendingCap) and inv.scope != "per_tx":
        return False
    return True


def _contradiction_to_finding(
    contradiction: Contradiction,
    *,
    code: str,
) -> LintFinding:
    """Map a prover :class:`Contradiction` onto a :class:`LintFinding`.

    The pattern prover's ``left`` / ``right`` fields contain class-name
    signatures like ``"CounterpartyConstraint(approved=[...], ...)``";
    the linter just carries the class names through.
    """
    left_cls = _class_from_label(contradiction.left)
    right_cls = _class_from_label(contradiction.right)
    involved = tuple(n for n in (left_cls, right_cls) if n)
    return LintFinding(
        severity="error",
        code=code,
        message=contradiction.reason,
        invariants=involved,
        suggested_repair=_repair_hint_for_code(code, contradiction),
    )


def _class_from_label(label: str) -> Optional[str]:
    """Extract a ``ClassName`` prefix from a Contradiction label, if present.

    Examples:
      ``"CounterpartyConstraint(approved=[...])"`` -> ``"CounterpartyConstraint"``
      ``"composed_spec"``                           -> ``None``
      ``"ProviderAllowlist (multi)"``               -> ``"ProviderAllowlist"``
    """
    for cls in (
        "ProviderAllowlist",
        "CounterpartyConstraint",
        "SpendingCap",
        "MaxPerCall",
        "RetryRateLimit",
        "RollingWindowCap",
        "MutualExclusion",
        "JurisdictionRule",
    ):
        if label.startswith(cls):
            return cls
    return None


def _repair_hint_for_code(code: str, contradiction: Contradiction) -> Optional[str]:
    """Suggest a repair given the finding code. Conservative — returns
    None rather than guess when the contradiction shape is unfamiliar."""
    if code == "LINT001":
        return (
            "Resolve the pattern-level clash by dropping one of the "
            "conflicting rules, or by separating the overlapping "
            "approved/sanctioned IDs."
        )
    if code == "LINT002":
        return (
            "Fragment v1 (Tau) proved the composed spec unsatisfiable. "
            "At least one pair of invariants has no joint model — narrow "
            "the set."
        )
    if code == "LINT004":
        return (
            "Either add the missing provider to the ProviderAllowlist, "
            "or remove the dead per-provider SpendingCap."
        )
    return None


def _has_errors(findings: Iterable[LintFinding]) -> bool:
    return any(f.severity == "error" for f in findings)


def _summary(findings: Iterable[LintFinding]) -> dict:
    counts = {"errors": 0, "warnings": 0, "info": 0}
    for f in findings:
        if f.severity == "error":
            counts["errors"] += 1
        elif f.severity == "warning":
            counts["warnings"] += 1
        else:
            counts["info"] += 1
    return counts
