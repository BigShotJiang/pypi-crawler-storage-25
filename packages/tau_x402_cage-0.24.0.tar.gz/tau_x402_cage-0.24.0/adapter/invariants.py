"""x402 invariant taxonomy.

Immutable dataclasses representing the eight invariant types (SpendingCap,
MaxPerCall, ProviderAllowlist, RetryRateLimit, RollingWindowCap,
JurisdictionRule, MutualExclusion, CounterpartyConstraint). Each emits a Tau
spec fragment via `to_tau_spec()` (temporal form) and, when it belongs to
semantic fragment v1, a non-temporal `_sat_body()` that composes into the
conjunction fed to the Tau CLI's `sat` REPL for declare-time consistency
checking. Semantic fragment v2 (temporal-arithmetic invariants) is decided
by z3 via adapter/z3_compiler.py instead.

Taxonomy reference: docs/x402-invariants.md.
Fragment definitions: docs/semantic_fragment_v1.md, docs/semantic_fragment_v2.md.
Plan: ../Tau-Safety-Cage/docs/plans/2026-04-18-001-feat-tau-x402-standards-capture-plan.v2.md

Fragment membership (see tau_compiler._FRAGMENT_V1 and z3_compiler._FRAGMENT_V2
for the authoritative sets):
  Fragment v1 (Tau-decided):  MaxPerCall, ProviderAllowlist, CounterpartyConstraint,
                              JurisdictionRule, SpendingCap(per_tx), MutualExclusion.
  Fragment v2 (z3-decided):   SpendingCap(per_window|per_provider_per_window),
                              RollingWindowCap, RetryRateLimit.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from typing import ClassVar, FrozenSet, Literal, Mapping, Optional, Sequence, Tuple

# Forward-declared so `check_payment` can annotate without importing at module load.
# `from __future__ import annotations` above makes this a pure type hint.
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from adapter.payment_intent_matcher import PaymentIntent


@dataclass(frozen=True)
class Violation:
    """A specific invariant violation. Daemon-side `check_payment` returns one or None."""

    rule_id: str
    reason_text: str
    witness: Optional[str] = None


class InvariantError(ValueError):
    """Raised when an invariant is constructed with invalid arguments."""


class ContradictionError(ValueError):
    """Raised when adding an invariant would make the composition unsatisfiable.

    The `witness` field names the pair of invariants whose conjunction
    is unsat (best-effort, for large rule sets the pairwise scan may
    surface one conflict among several).
    """

    def __init__(self, message: str, witness: Optional[Tuple[str, str]] = None):
        super().__init__(message)
        self.witness = witness


@dataclass(frozen=True)
class Invariant:
    """Base class. Subclasses implement `_body()`, the formula that sits
    inside a single top-level `G(...)`. `to_tau_spec()` wraps it for standalone
    use; `compose()` merges multiple bodies under one `G(...)` to satisfy
    Tau's prohibition on nested temporal quantifiers.

    Two Tau emission paths exist:
      * `_body()` + `to_tau_spec()` -- the TEMPORAL form (stream-typed,
        `[t]`-indexed, wrapped in `G(...)`). This is the long-term target
        for request-time reasoning. Tau's current REPL `sat` command does
        NOT decide specs in this form (see docs/semantic_fragment_v1.md).
      * `_sat_body()` + `to_sat_spec()` -- the NON-TEMPORAL consistency
        form. camelCase variable names, unified `:bv[64]` width, no `[t]`,
        no `G`. THIS is what the `sat` REPL command decides cleanly.
        Fragment v1 invariants all override `_sat_body()`; temporal-only
        invariants (per_window caps, rolling windows, past-LTL retries)
        keep the default NotImplementedError and are rejected in strict
        mode as `unsupported_fragment`.
    """

    def _body(self) -> str:
        raise NotImplementedError

    def _sat_body(self) -> str:
        """Non-temporal consistency-check body. See class docstring.

        Subclasses in semantic fragment v1 override this to emit a
        `sat`-decidable formula using camelCase `cageX` variables and
        `:bv[64]` uniform width. Subclasses outside v1 inherit the default
        NotImplementedError; the tau compiler translates that into an
        UnsupportedInvariantError.
        """
        raise NotImplementedError(
            f"{self.__class__.__name__} is not in semantic fragment v1; "
            f"no sat encoding is defined. See docs/semantic_fragment_v1.md."
        )

    def to_tau_spec(self) -> str:
        return f"G({self._body()})"

    def to_sat_spec(self) -> str:
        """Non-temporal standalone consistency-check spec."""
        return f"({self._sat_body()})"

    @property
    def name(self) -> str:
        return self.__class__.__name__

    def check_payment(
        self,
        intent: "PaymentIntent",
        history: Sequence["PaymentIntent"],
        rejects: Sequence["PaymentIntent"] = (),
    ) -> Optional[Violation]:
        """Python-side enforcement. Returns Violation if intent is rejected, None if clean.

        Rule-rule consistency is checked at declare time: fragment v1 invariants go
        through the Tau CLI's `sat` REPL via TauConsistencyProver; fragment v2
        invariants go through z3 via Z3ConsistencyProver. This method is the per-call
        fast path and runs in pure Python regardless of the declare-time backend.

        Args:
            intent:  the payment intent under evaluation
            history: previously PERMITTED intents in this session (oldest → newest)
            rejects: previously REJECTED intents (oldest → newest). Only
                     RetryRateLimit consults this. Other invariants ignore it.
        """
        raise NotImplementedError


# Scopes: informs how caps aggregate. "per_tx" resets on every payment; "per_window"
# accumulates across a rolling time window; "per_provider_per_window" groups by
# counterparty inside the window.
SpendingScope = Literal["per_tx", "per_window", "per_provider_per_window"]


@dataclass(frozen=True)
class SpendingCap(Invariant):
    """Cumulative spend must not exceed max_amount in the given scope.

    v0.17.0 adds ``cross_provider_cap``: an optional second ceiling applied
    to the sum across every provider in the same currency and window.
    Per-provider semantics are preserved when ``cross_provider_cap is None``
    so existing deployments see no behaviour change.
    """

    max_amount: Decimal
    currency: str = "USDC"
    scope: SpendingScope = "per_window"
    window_seconds: Optional[int] = None
    provider: Optional[str] = None
    # v0.17.0: optional cross-provider aggregate cap. When set, the cap
    # applies to sum-across-providers in the same currency/window (the
    # "shared pool" ceiling). Not supported for ``per_tx`` scope (which
    # has no window to aggregate over).
    cross_provider_cap: Optional[Decimal] = None

    def __post_init__(self) -> None:
        if self.max_amount <= 0:
            raise InvariantError(f"SpendingCap max_amount must be > 0, got {self.max_amount}")
        if self.scope in ("per_window", "per_provider_per_window") and self.window_seconds is None:
            raise InvariantError(f"SpendingCap with scope={self.scope} requires window_seconds")
        if self.scope == "per_provider_per_window" and self.provider is None:
            raise InvariantError("SpendingCap with scope=per_provider_per_window requires provider")
        if self.cross_provider_cap is not None:
            if self.cross_provider_cap <= 0:
                raise InvariantError(
                    f"SpendingCap cross_provider_cap must be > 0, "
                    f"got {self.cross_provider_cap}"
                )
            if self.scope == "per_tx":
                raise InvariantError(
                    "SpendingCap cross_provider_cap is only meaningful for "
                    "windowed scopes (per_window / per_provider_per_window); "
                    "per_tx has no window to aggregate over."
                )

    def _body(self) -> str:
        amt = _amount_to_bv(self.max_amount)
        if self.scope == "per_tx":
            return f"payment_amount[t]:bv[64] <= {amt}"
        if self.scope == "per_window":
            return f"cumulative_spend[t]:bv[64] <= {amt}"
        # per_provider_per_window
        return (
            f"provider[t]:bv[16] = {{ {_provider_hash(self.provider)} }}:bv[16]"
            f" -> cumulative_provider_spend[t]:bv[64] <= {amt}"
        )

    def _sat_body(self) -> str:
        # Only per_tx is in semantic fragment v1; per_window / per_provider_per_window
        # are temporal and the base class will raise UnsupportedInvariantError.
        if self.scope != "per_tx":
            return super()._sat_body()  # raises, carrying the class-name context
        amt = _amount_to_bv(self.max_amount)
        return f"cageAmt:bv[64] <= {amt}"

    def check_payment(self, intent, history, rejects=()):
        rule_id = f"spending_cap_{self.scope}"
        if self.scope == "per_tx":
            if intent.amount > self.max_amount:
                return Violation(
                    rule_id=rule_id,
                    reason_text=(
                        f"per-transaction cap {self.max_amount} {self.currency} exceeded "
                        f"(intent: {intent.amount})"
                    ),
                    witness=f"intent={intent.amount},cap={self.max_amount}",
                )
            return None
        window = self.window_seconds or 0
        cutoff = intent.timestamp_unix - window
        if self.scope == "per_provider_per_window":
            relevant = [
                p for p in history
                if p.provider == self.provider
                and p.currency == self.currency
                and p.timestamp_unix >= cutoff
            ]
        else:
            relevant = [
                p for p in history
                if p.currency == self.currency and p.timestamp_unix >= cutoff
            ]
        cumulative = sum((p.amount for p in relevant), Decimal("0")) + intent.amount
        if cumulative > self.max_amount:
            return Violation(
                rule_id=rule_id,
                reason_text=(
                    f"{self.scope} cap {self.max_amount} {self.currency} exceeded "
                    f"(cumulative: {cumulative})"
                ),
                witness=f"cumulative={cumulative},cap={self.max_amount},window={window}s",
            )
        # v0.17.0: if a cross-provider ceiling is set, also aggregate
        # across every provider in the window. Applies on top of the
        # existing per-provider check so operators can keep a generous
        # per-provider cap while capping the shared pool tightly.
        if self.cross_provider_cap is not None:
            all_in_window = [
                p for p in history
                if p.currency == self.currency and p.timestamp_unix >= cutoff
            ]
            cross_total = (
                sum((p.amount for p in all_in_window), Decimal("0")) + intent.amount
            )
            if cross_total > self.cross_provider_cap:
                return Violation(
                    rule_id=f"{rule_id}_cross_provider",
                    reason_text=(
                        f"cross-provider cap {self.cross_provider_cap} "
                        f"{self.currency} exceeded (cumulative across providers: "
                        f"{cross_total})"
                    ),
                    witness=(
                        f"cross_total={cross_total},"
                        f"cross_cap={self.cross_provider_cap},"
                        f"window={window}s"
                    ),
                )
        return None


@dataclass(frozen=True)
class MaxPerCall(Invariant):
    """No single payment may exceed max_amount."""

    max_amount: Decimal
    currency: str = "USDC"

    def __post_init__(self) -> None:
        if self.max_amount <= 0:
            raise InvariantError(f"MaxPerCall max_amount must be > 0, got {self.max_amount}")

    def _body(self) -> str:
        return f"payment_amount[t]:bv[64] <= {_amount_to_bv(self.max_amount)}"

    def _sat_body(self) -> str:
        return f"cageAmt:bv[64] <= {_amount_to_bv(self.max_amount)}"

    def check_payment(self, intent, history, rejects=()):
        if intent.currency != self.currency:
            return None
        if intent.amount > self.max_amount:
            return Violation(
                rule_id="max_per_call",
                reason_text=(
                    f"Single-call cap {self.max_amount} {self.currency} exceeded "
                    f"(intent: {intent.amount})"
                ),
                witness=f"intent={intent.amount},cap={self.max_amount}",
            )
        return None


@dataclass(frozen=True)
class ProviderAllowlist(Invariant):
    """Counterparty provider must be in the approved set."""

    providers: FrozenSet[str]

    def __post_init__(self) -> None:
        if not self.providers:
            raise InvariantError("ProviderAllowlist requires at least one approved provider")

    def _body(self) -> str:
        # Enum-encoded: each provider hashes to a bv[16] slot; OR of equalities.
        terms = [
            f"provider[t]:bv[16] = {{ {_provider_hash(p)} }}:bv[16]"
            for p in sorted(self.providers)
        ]
        return "(" + " || ".join(terms) + ")"

    def _sat_body(self) -> str:
        # Fragment v1 encoding: camelCase var + unified bv[64] width.
        # Provider hashes still derive from `_provider_hash` (16-bit range)
        # but are declared at bv[64] to match the composed formula's width.
        terms = [
            f"cageProvider:bv[64] = {{ {_provider_hash(p)} }}:bv[64]"
            for p in sorted(self.providers)
        ]
        return "(" + " || ".join(terms) + ")"

    def check_payment(self, intent, history, rejects=()):
        if intent.provider in self.providers:
            return None
        return Violation(
            rule_id="provider_allowlist",
            reason_text=(
                f"Provider {intent.provider!r} not in allowlist "
                f"({sorted(self.providers)})"
            ),
            witness=f"provider={intent.provider}",
        )


@dataclass(frozen=True)
class RetryRateLimit(Invariant):
    """After a rejection, no retry for at least min_gap_seconds.

    Uses the Bug-4-patched `&` at wff level for a readable chain of time-shifted
    equalities. On the patched parser, `&` and `&&` are equivalent at wff level.
    """

    min_gap_seconds: int

    def __post_init__(self) -> None:
        if self.min_gap_seconds <= 0:
            raise InvariantError(
                f"RetryRateLimit min_gap_seconds must be > 0, got {self.min_gap_seconds}"
            )
        if self.min_gap_seconds > 300:
            # Practical limit; generated Tau fragment explodes linearly.
            raise InvariantError(
                f"RetryRateLimit min_gap_seconds > 300 not supported in V1 "
                f"(generates {self.min_gap_seconds} chained predicates); got {self.min_gap_seconds}"
            )

    def _body(self) -> str:
        # retry → !O(recent reject). Uses the Bug-3-patched unary past-LTL `O`
        # and the Bug-4-patched `&` at wff level.
        return (
            f"retry[t] = 1 -> !O(reject[t] = 1 "
            f"& time_since_last_reject[t]:bv[16] < {{ {self.min_gap_seconds} }}:bv[16])"
        )

    def check_payment(self, intent, history, rejects=()):
        # V0.2 semantic: lock out retries AFTER a reject for the same
        # (provider, counterparty) pair. Permits alone never trigger this rule.
        cutoff = intent.timestamp_unix - self.min_gap_seconds
        recent_rejects = [
            r for r in rejects
            if r.provider == intent.provider
            and r.counterparty == intent.counterparty
            and r.timestamp_unix > cutoff
        ]
        if recent_rejects:
            gap = intent.timestamp_unix - recent_rejects[-1].timestamp_unix
            return Violation(
                rule_id="retry_rate_limit",
                reason_text=(
                    f"Retry gap {gap}s below required {self.min_gap_seconds}s after "
                    f"reject for {intent.provider}/{intent.counterparty}"
                ),
                witness=f"gap={gap}s,min={self.min_gap_seconds}s",
            )
        return None


@dataclass(frozen=True)
class BurstVelocityCap(Invariant):
    """Cross-provider burst velocity must stay under ``max_per_window``.

    v0.17.0 runtime-guard invariant. Where ``SpendingCap`` caps cumulative
    spend inside a window, ``BurstVelocityCap`` caps the EMA-smoothed
    *rate* of spend across every provider in the currency. Agents doing
    legitimate cumulative spend inside the window but spiking the rate
    (pipelining dozens of small payments in a one-second burst) fail this
    rule before the cumulative cap has a chance to catch them.

    Fragment v2: the rule reasons about a rolling window, decided by z3.
    The per-call enforcement sums over the runtime-guard's burst window
    directly so the hot path stays pure Python.

    Fields:
        max_per_window: upper bound on the sum of amounts across the
            window. Expressed in ``currency`` units (Decimal).
        window_seconds: length of the burst window. Typically 10s; the
            short window is what makes this "burst velocity" as opposed
            to a cumulative cap.
        currency: currency the cap applies to.
        cross_provider: when True (default) the sum aggregates across
            every provider; when False the cap applies per-provider in
            isolation. The v0.17.0 dashboard story is the cross-provider
            case; the per-provider variant is kept for parity.
    """

    max_per_window: Decimal
    window_seconds: int
    currency: str = "USDC"
    cross_provider: bool = True

    def __post_init__(self) -> None:
        if self.max_per_window <= 0:
            raise InvariantError(
                f"BurstVelocityCap max_per_window must be > 0, got {self.max_per_window}"
            )
        if self.window_seconds <= 0:
            raise InvariantError(
                f"BurstVelocityCap window_seconds must be > 0, got {self.window_seconds}"
            )

    def _body(self) -> str:
        # Temporal form, same shape as SpendingCap(per_window). The
        # runtime-guard check is what the hot path actually runs; this
        # body is here so the composed Tau emission covers the rule.
        amt = _amount_to_bv(self.max_per_window)
        return f"cumulative_spend[t]:bv[64] <= {amt}"

    def _sat_body(self) -> str:
        # Fragment v2 only; not in fragment v1.
        return super()._sat_body()

    def check_payment(self, intent, history, rejects=()):
        if intent.currency != self.currency:
            return None
        cutoff = intent.timestamp_unix - self.window_seconds
        if self.cross_provider:
            relevant = [
                p for p in history
                if p.currency == self.currency and p.timestamp_unix >= cutoff
            ]
        else:
            relevant = [
                p for p in history
                if p.currency == self.currency
                and p.provider == intent.provider
                and p.timestamp_unix >= cutoff
            ]
        total = sum((p.amount for p in relevant), Decimal("0")) + intent.amount
        if total > self.max_per_window:
            return Violation(
                rule_id="burst_velocity_exceeded",
                reason_text=(
                    f"burst velocity cap {self.max_per_window} {self.currency} "
                    f"over {self.window_seconds}s exceeded "
                    f"(total{'_cross_provider' if self.cross_provider else ''}"
                    f"={total})"
                ),
                witness=(
                    f"total={total},cap={self.max_per_window},"
                    f"window={self.window_seconds}s,"
                    f"cross_provider={self.cross_provider}"
                ),
            )
        return None


@dataclass(frozen=True)
class RollingWindowCap(Invariant):
    """Count of grouped events in a rolling window must not exceed max_count."""

    max_count: int
    window_seconds: int
    group_by: Literal["provider", "counterparty", "global"] = "provider"

    def __post_init__(self) -> None:
        if self.max_count <= 0:
            raise InvariantError(f"RollingWindowCap max_count must be > 0, got {self.max_count}")
        if self.window_seconds <= 0:
            raise InvariantError(
                f"RollingWindowCap window_seconds must be > 0, got {self.window_seconds}"
            )

    def _body(self) -> str:
        # Tau maintains a sliding counter stream; cage emits only the bound.
        counter = {
            "provider": "count_per_provider_in_window",
            "counterparty": "count_per_counterparty_in_window",
            "global": "count_in_window",
        }[self.group_by]
        bits = _count_bits(self.max_count)
        return f"{counter}[t]:bv[{bits}] <= {{ {self.max_count} }}:bv[{bits}]"

    def check_payment(self, intent, history, rejects=()):
        cutoff = intent.timestamp_unix - self.window_seconds
        if self.group_by == "provider":
            relevant = [p for p in history if p.provider == intent.provider and p.timestamp_unix >= cutoff]
            bucket = intent.provider
        elif self.group_by == "counterparty":
            relevant = [p for p in history if p.counterparty == intent.counterparty and p.timestamp_unix >= cutoff]
            bucket = intent.counterparty
        else:
            relevant = [p for p in history if p.timestamp_unix >= cutoff]
            bucket = "global"
        # +1 for the intent under consideration
        count = len(relevant) + 1
        if count > self.max_count:
            return Violation(
                rule_id=f"rolling_window_cap_{self.group_by}",
                reason_text=(
                    f"Rolling-window cap {self.max_count} over {self.window_seconds}s "
                    f"exceeded for {self.group_by}={bucket!r} (count={count})"
                ),
                witness=f"count={count},cap={self.max_count},window={self.window_seconds}s",
            )
        return None


# Enum-backed invariants: jurisdictions and counterparties are encoded as fixed
# enums in fragment v1. A richer nlang-based encoding is deferred until upstream
# Tau's `nlang` BA parser is fixed (tracked in docs/tau-lang-bug-report-v2.md).

Jurisdiction = Literal["EU", "UK", "US", "APAC", "OTHER"]


@dataclass(frozen=True)
class JurisdictionRule(Invariant):
    """If provider's jurisdiction is in the target set, require additional invariants.

    Fragment v1 (enum-backed): jurisdictions are encoded as fixed codes in
    `_JURISDICTION_CODES`. A richer nlang-based encoding is gated on the
    upstream `nlang` BA fix (see docs/tau-lang-bug-report-v2.md).
    """

    jurisdiction: Jurisdiction
    additional_invariants: Tuple[Invariant, ...] = field(default_factory=tuple)

    _JURISDICTION_CODES: ClassVar[dict] = {"EU": 1, "UK": 2, "US": 3, "APAC": 4, "OTHER": 5}

    def _body(self) -> str:
        code = self._JURISDICTION_CODES[self.jurisdiction]
        if not self.additional_invariants:
            return "T"  # no-op inside G
        # Inner invariants contribute their body-only forms (we're already under G)
        inner = " && ".join(inv._body() for inv in self.additional_invariants)
        return f"provider_jurisdiction[t]:bv[4] = {{ {code} }}:bv[4] -> ({inner})"

    def _sat_body(self) -> str:
        # Fragment v1 encoding: unified bv[64], camelCase, implication form.
        # Inner invariants must also be in fragment v1; their _sat_body emits
        # the same variable name conventions.
        code = self._JURISDICTION_CODES[self.jurisdiction]
        if not self.additional_invariants:
            return "T"
        inner = " && ".join(inv._sat_body() for inv in self.additional_invariants)
        return f"cageJur:bv[64] = {{ {code} }}:bv[64] -> ({inner})"

    def check_payment(self, intent, history, rejects=()):
        # Enum-partial: jurisdiction is expected in intent.metadata["jurisdiction"].
        # If the intent jurisdiction doesn't match, this rule is vacuous (no-op).
        intent_jur = intent.metadata.get("jurisdiction")
        if intent_jur != self.jurisdiction:
            return None
        for inv in self.additional_invariants:
            v = inv.check_payment(intent, history, rejects)
            if v is not None:
                return Violation(
                    rule_id=f"jurisdiction_{self.jurisdiction.lower()}.{v.rule_id}",
                    reason_text=f"[{self.jurisdiction}] {v.reason_text}",
                    witness=v.witness,
                )
        return None


@dataclass(frozen=True)
class MutualExclusion(Invariant):
    """Provider must not belong to both group_a and group_b simultaneously.

    Semantic fragment v1. Given a provider that is single-valued per intent,
    ``MutualExclusion`` on its own is trivially SAT because a provider value
    naturally sits in at most one "slot". The invariant earns its keep under
    COMPOSITION with ``ProviderAllowlist``:

      * ``ProviderAllowlist({a, b})`` ∧ ``MutualExclusion({a}, {b})``
        still SAT -- admits provider = a XOR provider = b.
      * ``ProviderAllowlist({a, b})`` ∧ ``MutualExclusion({a, b}, {a, b})``
        UNSAT -- every element of the allowlist is in both groups.

    The second case is the "only Tau catches this" class for MutualExclusion:
    a pairwise pattern prover would need a dedicated helper, while the SAT
    encoding falls out of the uniform bv[64] composition.
    """

    group_a: FrozenSet[str]
    group_b: FrozenSet[str]

    def __post_init__(self) -> None:
        if not self.group_a:
            raise InvariantError("MutualExclusion group_a must be non-empty")
        if not self.group_b:
            raise InvariantError("MutualExclusion group_b must be non-empty")

    def _body(self) -> str:
        # Temporal form, stream-typed provider[t]:bv[16]. Kept for
        # documentation / composition with other temporal invariants; the
        # sat-decidable form is _sat_body below.
        a_terms = [
            f"provider[t]:bv[16] = {{ {_provider_hash(p)} }}:bv[16]"
            for p in sorted(self.group_a)
        ]
        b_terms = [
            f"provider[t]:bv[16] = {{ {_provider_hash(p)} }}:bv[16]"
            for p in sorted(self.group_b)
        ]
        a_members = "(" + " || ".join(a_terms) + ")"
        b_members = "(" + " || ".join(b_terms) + ")"
        return f"!(({a_members}) && ({b_members}))"

    def _sat_body(self) -> str:
        # Fragment v1 encoding: camelCase + unified bv[64].
        a_terms = [
            f"cageProvider:bv[64] = {{ {_provider_hash(p)} }}:bv[64]"
            for p in sorted(self.group_a)
        ]
        b_terms = [
            f"cageProvider:bv[64] = {{ {_provider_hash(p)} }}:bv[64]"
            for p in sorted(self.group_b)
        ]
        a_members = "(" + " || ".join(a_terms) + ")"
        b_members = "(" + " || ".join(b_terms) + ")"
        return f"!(({a_members}) && ({b_members}))"

    def check_payment(self, intent, history, rejects=()):
        # A provider value is single-valued per intent, so "in both groups
        # simultaneously" reduces to: the intent's provider is a member of
        # both sets. That happens exactly when it is in the intersection.
        overlap = self.group_a & self.group_b
        if intent.provider in overlap:
            return Violation(
                rule_id="mutual_exclusion",
                reason_text=(
                    f"Provider {intent.provider!r} is in both mutually-exclusive "
                    f"groups (overlap: {sorted(overlap)})"
                ),
                witness=f"provider={intent.provider},overlap={sorted(overlap)}",
            )
        return None


@dataclass(frozen=True)
class CounterpartyConstraint(Invariant):
    """Counterparty must have required attestations and not be sanctioned.

    Fragment v1 (enum-backed): approved / sanctioned sets are hashed enums.
    A richer nlang-based encoding is gated on the upstream `nlang` BA fix
    (see docs/tau-lang-bug-report-v2.md).
    """

    approved_ids: FrozenSet[str] = field(default_factory=frozenset)
    sanctioned_ids: FrozenSet[str] = field(default_factory=frozenset)

    def __post_init__(self) -> None:
        overlap = self.approved_ids & self.sanctioned_ids
        if overlap:
            raise InvariantError(
                f"CounterpartyConstraint has overlap between approved and sanctioned: {overlap}"
            )

    def _body(self) -> str:
        parts = []
        if self.approved_ids:
            approved = " || ".join(
                f"counterparty[t]:bv[16] = {{ {_provider_hash(c)} }}:bv[16]"
                for c in sorted(self.approved_ids)
            )
            parts.append(f"({approved})")
        if self.sanctioned_ids:
            # Sanctioned check: counterparty must NOT equal any sanctioned id.
            # Expressed as conjunction of inequalities under the outer G.
            for c in sorted(self.sanctioned_ids):
                parts.append(f"counterparty[t]:bv[16] != {{ {_provider_hash(c)} }}:bv[16]")
        if not parts:
            return "T"
        return " && ".join(parts)

    def _sat_body(self) -> str:
        # Fragment v1 encoding: camelCase, unified bv[64].
        parts = []
        if self.approved_ids:
            approved = " || ".join(
                f"cageCounterparty:bv[64] = {{ {_provider_hash(c)} }}:bv[64]"
                for c in sorted(self.approved_ids)
            )
            parts.append(f"({approved})")
        if self.sanctioned_ids:
            for c in sorted(self.sanctioned_ids):
                parts.append(f"cageCounterparty:bv[64] != {{ {_provider_hash(c)} }}:bv[64]")
        if not parts:
            return "T"
        return " && ".join(parts)

    def check_payment(self, intent, history, rejects=()):
        if intent.counterparty in self.sanctioned_ids:
            return Violation(
                rule_id="counterparty_sanctioned",
                reason_text=f"Counterparty {intent.counterparty!r} is on sanctions list",
                witness=f"counterparty={intent.counterparty}",
            )
        if self.approved_ids and intent.counterparty not in self.approved_ids:
            return Violation(
                rule_id="counterparty_not_approved",
                reason_text=(
                    f"Counterparty {intent.counterparty!r} not in approved set "
                    f"({sorted(self.approved_ids)})"
                ),
                witness=f"counterparty={intent.counterparty}",
            )
        return None


# ── meta-policies ────────────────────────────────────────────────────────────
#
# Meta-policies are policies about how the cage itself behaves. Unlike
# regular invariants which describe admissible payment intents, meta-policies
# describe:
#   * how adaptive-tightening parameters are chosen (AdaptiveTighteningPolicy)
#   * who may submit mutation ops to the daemon (PeerAuthenticationPolicy)
#
# Meta-policies share the Invariant base class so they flow through the same
# PolicyRevision container, but they are admitted through a SEPARATE pipeline
# (``adapter/meta_policy.py::admit_meta_policies``) rather than the regular
# tau_compiler / z3_compiler paths. Their ``_body`` / ``_sat_body`` outputs
# are intentionally no-ops (``T``) because their admission properties are
# *structural* — bounded / monotone / non-empty — rather than per-intent
# propositional facts.
#
# Revisions carrying a meta-policy are gated in Guaranteed Mode via
# ``GuaranteedLanguage.SUPPORTED_META_POLICIES``. Mutations to meta-policies
# pass through ``NoWeakening``, which treats broader admission sets as
# weakening.


@dataclass(frozen=True)
class AdaptiveTighteningPolicy(Invariant):
    """Meta-policy declaring adaptive-tightening parameters.

    Lifts the Python-side ``AdaptiveTightening`` constants into first-class
    policy. Admitted via Tau at declare time: every adjusted_limit derived
    under these parameters is guaranteed <= baseline (NoWeakening
    preserved); decay is monotonic toward baseline; no single observation
    saturates the level in one step.

    This invariant's runtime effect is to parameterise the daemon's
    ``AdaptiveTightening`` instance. The RUNTIME implementation does not
    change — only its tuning is now subject to policy discipline.

    Fields use Decimal for thresholds so fixed-point scaling to ``bv[64]``
    is lossless. ``per_trigger_deltas`` keys must be a subset of the
    known triggers (``retry_density``, ``denial_rate``, ``velocity_spike``,
    ``identical_request``); values are in ``[0, 1]``.
    """

    retry_density_per_min_threshold: Decimal
    denial_rate_threshold: Decimal
    velocity_multiplier_threshold: Decimal
    identical_count_threshold: int
    identical_window_seconds: int
    decision_window_seconds: int
    half_life_seconds: int
    # Stored as a hashable sorted tuple so the dataclass stays frozen +
    # hashable. ``deltas()`` returns a dict view for ergonomic reads.
    per_trigger_deltas: Tuple[Tuple[str, Decimal], ...]

    _KNOWN_TRIGGERS: ClassVar[FrozenSet[str]] = frozenset({
        "retry_density",
        "denial_rate",
        "velocity_spike",
        "identical_request",
    })

    def __post_init__(self) -> None:
        # Fail fast at construction: these same checks show up in
        # meta-policy admission as Tau-level properties, but rejecting
        # outright here keeps malformed policies from ever reaching
        # the admission pipeline.
        if self.half_life_seconds <= 0:
            raise InvariantError(
                f"AdaptiveTighteningPolicy half_life_seconds must be > 0, "
                f"got {self.half_life_seconds}"
            )
        if self.identical_count_threshold <= 0:
            raise InvariantError(
                f"AdaptiveTighteningPolicy identical_count_threshold must be > 0, "
                f"got {self.identical_count_threshold}"
            )
        if self.identical_window_seconds <= 0:
            raise InvariantError(
                f"AdaptiveTighteningPolicy identical_window_seconds must be > 0, "
                f"got {self.identical_window_seconds}"
            )
        if self.decision_window_seconds <= 0:
            raise InvariantError(
                f"AdaptiveTighteningPolicy decision_window_seconds must be > 0, "
                f"got {self.decision_window_seconds}"
            )
        if self.retry_density_per_min_threshold <= 0:
            raise InvariantError(
                f"AdaptiveTighteningPolicy retry_density_per_min_threshold "
                f"must be > 0, got {self.retry_density_per_min_threshold}"
            )
        if not (Decimal("0") < self.denial_rate_threshold <= Decimal("1")):
            raise InvariantError(
                f"AdaptiveTighteningPolicy denial_rate_threshold must be in "
                f"(0, 1], got {self.denial_rate_threshold}"
            )
        if self.velocity_multiplier_threshold <= Decimal("1"):
            raise InvariantError(
                f"AdaptiveTighteningPolicy velocity_multiplier_threshold must "
                f"be > 1, got {self.velocity_multiplier_threshold}"
            )
        # per_trigger_deltas: accept a mapping OR a tuple of (key, value)
        # pairs. Normalise to a sorted tuple so the dataclass stays
        # hashable. Known keys only; values in [0, 1].
        if isinstance(self.per_trigger_deltas, Mapping):
            raw_pairs = tuple(self.per_trigger_deltas.items())
        else:
            raw_pairs = tuple(self.per_trigger_deltas)
        if not raw_pairs:
            raise InvariantError(
                "AdaptiveTighteningPolicy requires at least one per_trigger_delta"
            )
        seen_keys: set = set()
        normalised: list = []
        for pair in raw_pairs:
            if not (isinstance(pair, tuple) and len(pair) == 2):
                raise InvariantError(
                    f"AdaptiveTighteningPolicy per_trigger_deltas entries "
                    f"must be (str, Decimal) pairs, got {pair!r}"
                )
            trig, delta = pair
            if trig not in self._KNOWN_TRIGGERS:
                raise InvariantError(
                    f"AdaptiveTighteningPolicy per_trigger_deltas has unknown "
                    f"trigger: {trig!r}"
                )
            if trig in seen_keys:
                raise InvariantError(
                    f"AdaptiveTighteningPolicy per_trigger_deltas has "
                    f"duplicate key: {trig!r}"
                )
            seen_keys.add(trig)
            try:
                delta_dec = delta if isinstance(delta, Decimal) else Decimal(str(delta))
            except Exception as exc:  # noqa: BLE001 — fail closed on parse.
                raise InvariantError(
                    f"AdaptiveTighteningPolicy per_trigger_deltas[{trig!r}] "
                    f"not convertible to Decimal: {delta!r}"
                ) from exc
            if not (Decimal("0") <= delta_dec <= Decimal("1")):
                raise InvariantError(
                    f"AdaptiveTighteningPolicy per_trigger_deltas[{trig!r}] "
                    f"must be in [0, 1], got {delta_dec}"
                )
            normalised.append((trig, delta_dec))
        normalised.sort(key=lambda kv: kv[0])
        object.__setattr__(self, "per_trigger_deltas", tuple(normalised))

    def _body(self) -> str:
        # Meta-policies contribute T to the composed temporal spec because
        # their admission is structural, not per-intent propositional.
        return "T"

    def _sat_body(self) -> str:
        # Same rationale as _body: no per-intent propositional content.
        return "T"

    def deltas(self) -> dict:
        """Return the per-trigger deltas as a fresh dict."""
        return dict(self.per_trigger_deltas)

    def max_delta(self) -> Decimal:
        """Return the largest single-trigger delta (for saturation proofs).

        Part of the admitted ``single_observation_bound`` property:
        ``max(deltas.values())`` must be <= 1 so no single trigger can
        saturate the level in one step. Exposed so the meta-policy
        admission path can check the invariant symbolically without
        reaching into the tuple representation.
        """
        return max((delta for _, delta in self.per_trigger_deltas), default=Decimal("0"))


@dataclass(frozen=True)
class PeerAuthenticationPolicy(Invariant):
    """Meta-policy declaring who can submit mutation ops to the daemon.

    Every mutation op must carry kernel-verified peer credentials
    (``SO_PEERCRED`` on Linux / ``LOCAL_PEERCRED`` / ``getpeereid`` on
    macOS) whose uid is in ``allowed_peer_uids``, and an ``actor_id`` in
    ``allowed_actor_claims`` OR an ``actor_claim_signature`` verifying
    against an admitted ``allowed_signing_keys`` entry.

    Admission properties proven at declare time:
      * ``|allowed_peer_uids| > 0`` — policy cannot lock the daemon out
      * adding a uid to ``allowed_peer_uids`` is *weakening* (more peers
        can mutate); removing one is *tightening*. NoWeakening gates the
        former behind an approval token.

    ``allowed_signing_keys`` holds *key ids* (fingerprints / names), never
    secret key material. Signature verification is wired externally; this
    meta-policy only declares which key ids are admitted.
    """

    allowed_peer_uids: FrozenSet[int]
    allowed_actor_claims: FrozenSet[str] = field(default_factory=frozenset)
    allowed_signing_keys: FrozenSet[str] = field(default_factory=frozenset)
    require_peer_uid: bool = True
    require_signed_actor_claim: bool = False

    def __post_init__(self) -> None:
        if not self.allowed_peer_uids:
            raise InvariantError(
                "PeerAuthenticationPolicy allowed_peer_uids must be non-empty "
                "(a policy that locks the daemon out cannot be admitted)."
            )
        for uid in self.allowed_peer_uids:
            if not isinstance(uid, int) or uid < 0:
                raise InvariantError(
                    f"PeerAuthenticationPolicy allowed_peer_uids entries must "
                    f"be non-negative ints, got {uid!r}"
                )
        # Normalise set-like fields to frozensets so downstream code can
        # rely on hashability + immutability.
        object.__setattr__(
            self, "allowed_peer_uids", frozenset(self.allowed_peer_uids)
        )
        object.__setattr__(
            self, "allowed_actor_claims", frozenset(self.allowed_actor_claims)
        )
        object.__setattr__(
            self, "allowed_signing_keys", frozenset(self.allowed_signing_keys)
        )
        if self.require_signed_actor_claim and not self.allowed_signing_keys:
            raise InvariantError(
                "PeerAuthenticationPolicy require_signed_actor_claim=True "
                "requires at least one entry in allowed_signing_keys."
            )

    def _body(self) -> str:
        return "T"

    def _sat_body(self) -> str:
        return "T"

    def authorises_connection(self, peer_uid: Optional[int]) -> bool:
        """Return True iff a connection from ``peer_uid`` is admitted.

        ``peer_uid=None`` denotes "kernel did not return a credential";
        when ``require_peer_uid`` is True this is fail-closed.
        """
        if peer_uid is None:
            return not self.require_peer_uid
        return int(peer_uid) in self.allowed_peer_uids

    def authorises_actor(
        self,
        *,
        actor_id: Optional[str],
        actor_claim_signature_key_id: Optional[str],
    ) -> bool:
        """Return True iff a mutation actor is admitted.

        The caller supplies either an ``actor_id`` (claimed identity) or a
        signing-key id derived from a verified signature. At least one
        admission path must succeed.
        """
        if (
            actor_id is not None
            and actor_id in self.allowed_actor_claims
        ):
            return True
        if (
            actor_claim_signature_key_id is not None
            and actor_claim_signature_key_id in self.allowed_signing_keys
        ):
            return True
        # When a policy requires a signed claim, unsigned requests fail.
        # When it doesn't, an allowed_actor_claims-only match above would
        # already have returned True; arriving here means neither path hit.
        return False


# ── composition ──────────────────────────────────────────────────────────────


def compose(invariants: Sequence[Invariant]) -> str:
    """Conjunct a sequence of invariant bodies under a single top-level G.

    Tau rejects nested temporal quantifiers (`G(A) && G(B)`), so we collect
    each invariant's body-only form and wrap the conjunction in one `G(...)`.
    This matches how Tau's `flatten_always_conjuncts` normalizes internally,
    but applied at spec-emission time to pass the nesting check.
    """
    if not invariants:
        return "G(T)."
    bodies = [inv._body() for inv in invariants]
    if len(bodies) == 1:
        return f"G({bodies[0]})."
    return "G(" + " && ".join(f"({b})" for b in bodies) + ")."


def compose_for_sat(invariants: Sequence[Invariant]) -> str:
    """Conjunct non-temporal consistency-check bodies into a Tau `sat`-decidable spec.

    This is what the tau_compiler feeds to TauConsistencyProver. Each
    invariant must be in semantic fragment v1 (override `_sat_body`);
    subclasses outside v1 raise NotImplementedError here, which the
    compiler translates into `UnsupportedInvariantError` and the daemon
    rejects in strict mode as `unsupported_fragment`.

    Empirically verified (see docs/semantic_fragment_v1.md): Tau's REPL
    `sat` command decides these composed specs in under 15ms for the
    fragment-v1 invariant set on ~/.tau/ v8b155d36-patched.
    """
    if not invariants:
        return "T"
    bodies = [inv._sat_body() for inv in invariants]
    if len(bodies) == 1:
        return bodies[0]
    return " && ".join(f"({b})" for b in bodies)


# ── helpers ──────────────────────────────────────────────────────────────────


def _amount_to_bv(amount: Decimal) -> str:
    """Convert a Decimal amount to the cage's canonical bv[64] literal.

    Amounts are scaled to micro-units (10^-6), USDC uses 6 decimals.
    """
    micro = int(amount * Decimal("1_000_000"))
    if micro < 0 or micro >= (1 << 64):
        raise InvariantError(f"Amount {amount} out of bv[64] range")
    return f"{{ {micro} }}:bv[64]"


def _provider_hash(name: str) -> int:
    """Deterministic 16-bit hash for provider enum encoding.

    Uses a stable hash so the same provider produces the same bv value across
    cage instances. Not cryptographic, just enum encoding.
    """
    import hashlib

    h = hashlib.sha256(name.encode("utf-8")).digest()
    return int.from_bytes(h[:2], "big")


def _count_bits(max_count: int) -> int:
    """Return bv width sufficient for max_count (rounded to nearest power of 2, min 8)."""
    import math

    if max_count <= 0:
        return 8
    needed = max(8, math.ceil(math.log2(max_count + 1)))
    # Round to power of 2
    for width in (8, 16, 32, 64):
        if needed <= width:
            return width
    raise InvariantError(f"max_count {max_count} requires > 64 bits")
