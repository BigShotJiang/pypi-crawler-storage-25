"""Pure-Tau Guaranteed Mode prover (v0.19.0).

Deliverable 2.A + 2.B of the bank-deployable "Guaranteed Mode" track.

Semantics:
  * Tau is the sole semantic authority. This module never invokes z3, the
    pattern prover, or the hybrid prover. The constructor asserts the
    injected prover is a ``TauConsistencyProver`` and raises otherwise.
  * Fail-closed. Any unsupported construct, compile incompleteness, timeout,
    inconclusive Tau result, or backend unavailability becomes a
    ``GuaranteedFailure`` with a specific ``GuaranteedFailureCode``. There
    is no silent admission.
  * Every prove call produces exactly one persisted
    ``GuaranteedProofArtifact`` (successful or rejected). The success path
    returns a ``GuaranteedProofResult`` carrying the artifact and the
    ``consistent`` verdict; the reject path returns a ``GuaranteedFailure``.

Threading: ``GuaranteedProver`` is a thin orchestrator with no mutable state
beyond a lazy ``tau_backend_version`` cache, so instances are safe to share
across threads as long as the wrapped ``TauConsistencyProver`` is.
"""

from __future__ import annotations

import logging
import subprocess
import threading
import time
from dataclasses import dataclass
from typing import Any, Optional, Sequence

from adapter.invariants import Invariant
from adapter.prover import (
    Contradiction,
    InconclusiveProof,
    ProofToken,
    TauConsistencyProver,
    TauUnavailable,
)
from adapter.tau_compiler import (
    CompileError,
    CompiledTauPolicy,
    UnsupportedInvariantError,
    compile_policy,
)

# Agent 1 exports. We load the real modules when they land on master and
# fall back to in-tree stubs in the meantime so we can ship + test today.
# TODO: remove the stub fallbacks after agent 1 merges.
try:  # pragma: no cover - exercised by both branches
    from adapter.guaranteed_errors import (  # type: ignore[attr-defined]
        GuaranteedFailure,
        GuaranteedFailureCode,
    )
except ImportError:  # agent 1 branch not yet on master
    from adapter._guaranteed_stubs import (  # type: ignore[no-redef]
        GuaranteedFailure,
        GuaranteedFailureCode,
    )

try:  # pragma: no cover
    from adapter.guaranteed_language import (  # type: ignore[attr-defined]
        GuaranteedLanguage,
        PureBvAssertionError,
        assert_pure_bv_policy,
    )
except ImportError:
    from adapter._guaranteed_stubs import GuaranteedLanguage  # type: ignore[no-redef]

    # Stubs for the v1.2.0 purity check when agent 1 hasn't landed yet.
    class PureBvAssertionError(ValueError):  # type: ignore[no-redef]
        """Fallback stub. The real helper lives in guaranteed_language."""

        def __init__(self, message: str, detail: str = "") -> None:
            super().__init__(message)
            self.detail = detail

    def assert_pure_bv_policy(tau_source: str) -> None:  # type: ignore[no-redef]
        """Fallback stub — admits everything until the real helper lands."""
        return None

try:  # pragma: no cover
    from adapter.guaranteed_totality import validate_totality  # type: ignore[attr-defined]
except ImportError:
    from adapter._guaranteed_stubs import validate_totality  # type: ignore[no-redef]

from adapter.guaranteed_proof_artifact import (
    GuaranteedProofArtifact,
    GuaranteedProofResult,
    ProofArtifactStore,
    make_artifact_id,
    utc_now,
)


logger = logging.getLogger(__name__)


#: Default budget for a guaranteed proof. 10s mirrors the existing
#: ``TauConsistencyProver`` default so the two layers don't drift.
DEFAULT_BUDGET_MS = 10_000


# ── module-level invocation guard ────────────────────────────────────────────
#
# Test 3 (see tests/test_guaranteed_prover.py) asserts that no z3 imports or
# calls happen during a Guaranteed Mode prove. Rather than rely on mocks of
# third-party modules, we keep a tiny counter here that ``prove()`` checks
# BEFORE and AFTER; tests can read the raw value and patch the helper to get
# a decisive assert.


_Z3_CALL_COUNTER = {"count": 0}
_COUNTER_LOCK = threading.Lock()


def _record_z3_invocation() -> None:  # pragma: no cover - invariant never hit
    """Sentinel called by tests when they want to simulate z3 leakage.

    Production code never calls this. Tests monkeypatch
    ``adapter.guaranteed_prover._record_z3_invocation`` into places where
    they want to observe a violation. The counter is consulted by
    ``GuaranteedProver._sanity_no_z3_invoked``.
    """
    with _COUNTER_LOCK:
        _Z3_CALL_COUNTER["count"] += 1


def _reset_z3_counter() -> None:
    """Reset the invocation counter. Only the test suite calls this."""
    with _COUNTER_LOCK:
        _Z3_CALL_COUNTER["count"] = 0


# ── prover ───────────────────────────────────────────────────────────────────


class GuaranteedProver:
    """Pure-Tau prover for Guaranteed Mode.

    Construction is strict: the ``prover`` keyword MUST be a
    ``TauConsistencyProver``. Passing ``PythonPatternProver``,
    ``Z3ConsistencyProver``, ``HybridProver``, or any other instance raises
    ``AssertionError`` immediately. This enforces the "Tau is the sole
    semantic authority" contract at construction time, not at prove time,
    so misconfigurations fail loud.

    Instances may optionally own a ``ProofArtifactStore`` to persist every
    attempted proof. When omitted, artifacts are returned to the caller
    inside the ``GuaranteedProofResult``/``GuaranteedFailure`` payload but
    never written to disk -- that mode is for tests and dry runs.

    The prover is intentionally NOT a frozen dataclass because it carries
    a lazy ``tau_backend_version`` cache behind a lock.
    """

    def __init__(
        self,
        prover: TauConsistencyProver,
        *,
        artifact_store: Optional[ProofArtifactStore] = None,
        language: Any = GuaranteedLanguage,
    ) -> None:
        # STRICT: Only TauConsistencyProver is admissible. Anything else
        # (even a subclass intended to delegate to z3) violates the
        # "Tau or nothing" contract of Guaranteed Mode.
        assert isinstance(prover, TauConsistencyProver), (
            "GuaranteedProver requires a TauConsistencyProver instance; "
            f"got {type(prover).__name__}. Guaranteed Mode is Tau-only: "
            "the pattern / z3 / hybrid backends are inadmissible."
        )
        self._prover = prover
        self._artifact_store = artifact_store
        self._language = language
        self._version_lock = threading.Lock()
        self._cached_tau_version: Optional[str] = None

    # ── public surface ─────────────────────────────────────────────────────

    @property
    def tau_prover(self) -> TauConsistencyProver:
        return self._prover

    @property
    def artifact_store(self) -> Optional[ProofArtifactStore]:
        return self._artifact_store

    def prove(
        self,
        policy: Sequence[Invariant],
        *,
        policy_revision_id: Optional[str] = None,
        budget_ms: int = DEFAULT_BUDGET_MS,
    ) -> GuaranteedProofResult | GuaranteedFailure:
        """Attempt a Guaranteed Mode proof over ``policy``.

        Flow:
          1. Run ``validate_totality``. Non-total => ``TAU_TOTALITY_FAILED``.
          2. Compile to Tau fragment v1. Unsupported or compile error =>
             ``TAU_UNSUPPORTED_CONSTRUCT`` / ``TAU_COMPILE_INCOMPLETE``.
          3. Invoke the Tau prover with the COMPILED source.
          4. Any non-decisive outcome (timeout, inconclusive, unavailable)
             becomes a specific failure. Decisive sat/unsat is the only
             successful path.
          5. Persist the artifact (success or reject) iff an artifact store
             is configured.
        """
        if not isinstance(budget_ms, int) or budget_ms <= 0:
            raise ValueError(f"budget_ms must be a positive int, got {budget_ms!r}")
        # Defensive: empty policies are nonsense for Guaranteed Mode;
        # refuse rather than silently return consistent=True.
        policy_tuple = tuple(policy)

        started_at = time.monotonic()
        baseline_z3 = _Z3_CALL_COUNTER["count"]

        # ── 1. totality gate ────────────────────────────────────────────
        totality = validate_totality(policy_tuple)
        if not getattr(totality, "is_total", False):
            failure = GuaranteedFailure(
                code=GuaranteedFailureCode.TAU_TOTALITY_FAILED,
                message=(
                    "Totality check rejected the policy; one or more invariants "
                    "are non-total under the Guaranteed Mode language tier."
                ),
                context={
                    "reasons": list(getattr(totality, "reasons", ()) or ()),
                },
            )
            artifact = self._make_artifact(
                policy_revision_id=policy_revision_id or "unknown",
                compile_hash="",
                proof_result="rejected",
                totality_check_passed=False,
                budget_ms=budget_ms,
                failure=failure,
            )
            self._persist(artifact)
            self._sanity_no_z3_invoked(baseline_z3)
            return failure

        # ── 2. compile to Tau fragment v1 ───────────────────────────────
        compiled: Optional[CompiledTauPolicy] = None
        try:
            compiled = compile_policy(policy_tuple, fragment_version="v1")
        except UnsupportedInvariantError as exc:
            failure = GuaranteedFailure(
                code=GuaranteedFailureCode.TAU_UNSUPPORTED_CONSTRUCT,
                message=str(exc),
                context={
                    "invariant": exc.invariant_name,
                    "fragment_version": exc.fragment_version,
                },
            )
        except CompileError as exc:
            failure = GuaranteedFailure(
                code=GuaranteedFailureCode.TAU_COMPILE_INCOMPLETE,
                message=f"Tau compilation failed: {exc}",
                context={"error_type": type(exc).__name__},
            )
        else:
            failure = None
            # v1.2.0 purity assertion: even with a successful compile,
            # the tier refuses to admit a policy whose compiled source
            # carries an nlang tag or a fragment-v2 SMT-LIB sentinel.
            # This is a final defensive check — the variant-admission
            # gate already rejects the nlang / sanctions shapes, and
            # z3-compiled bodies never route here, so hitting this is
            # evidence of a routing bug the tier must fail closed on.
            try:
                assert_pure_bv_policy(compiled.tau_source)
            except PureBvAssertionError as exc:
                failure = GuaranteedFailure(
                    code=GuaranteedFailureCode.UNSUPPORTED_FOR_GUARANTEED_MODE,
                    message=str(exc),
                    context={
                        "detail": exc.detail,
                        "error_type": "PureBvAssertionError",
                    },
                )

        if failure is not None:
            artifact = self._make_artifact(
                policy_revision_id=policy_revision_id
                or (compiled.compile_hash if compiled is not None else "unknown"),
                compile_hash=compiled.compile_hash if compiled is not None else "",
                proof_result="rejected",
                totality_check_passed=True,
                budget_ms=budget_ms,
                failure=failure,
            )
            self._persist(artifact)
            self._sanity_no_z3_invoked(baseline_z3)
            return failure

        assert compiled is not None  # type-checker hint

        # Derive the revision id used in the artifact. Callers with a real
        # PolicyRevision supply ``policy_revision_id`` explicitly; ad-hoc
        # callers get the compile_hash as a stable content-addressed id.
        revision_id = policy_revision_id or compiled.compile_hash

        # ── 3-4. invoke Tau, map outcomes to Guaranteed Mode codes ──────
        # Honour the caller's budget by tightening the Tau prover's
        # per-proof timeout if it's stricter than our default. We never
        # loosen the prover's configured ceiling.
        budget_seconds = budget_ms / 1000.0
        invoke_budget = min(budget_seconds, float(self._prover.timeout_seconds))

        try:
            verdict = self._prover.prove(policy_tuple)
        except TauUnavailable as exc:
            failure = GuaranteedFailure(
                code=GuaranteedFailureCode.TAU_BACKEND_UNAVAILABLE,
                message=f"Tau backend unavailable: {exc}",
                context={"error_type": "TauUnavailable"},
            )
            return self._finalise_reject(
                revision_id=revision_id,
                compile_hash=compiled.compile_hash,
                budget_ms=budget_ms,
                failure=failure,
                baseline_z3=baseline_z3,
            )
        except subprocess.TimeoutExpired:
            failure = GuaranteedFailure(
                code=GuaranteedFailureCode.TAU_PROOF_TIMEOUT,
                message=(
                    f"Tau proof exceeded budget of {invoke_budget:.3f}s; "
                    "fail-closed under Guaranteed Mode."
                ),
                context={"budget_ms": budget_ms},
            )
            return self._finalise_reject(
                revision_id=revision_id,
                compile_hash=compiled.compile_hash,
                budget_ms=budget_ms,
                failure=failure,
                baseline_z3=baseline_z3,
            )
        except (FileNotFoundError, OSError) as exc:
            # Subprocess spawn failures (binary missing, permission denied,
            # too many open files, ...).
            failure = GuaranteedFailure(
                code=GuaranteedFailureCode.TAU_BACKEND_UNAVAILABLE,
                message=f"Could not spawn Tau backend: {exc}",
                context={"error_type": type(exc).__name__},
            )
            return self._finalise_reject(
                revision_id=revision_id,
                compile_hash=compiled.compile_hash,
                budget_ms=budget_ms,
                failure=failure,
                baseline_z3=baseline_z3,
            )
        except Exception as exc:  # noqa: BLE001
            # Any other unexpected error is a prover-internal failure; we
            # still fail closed, but we categorise it distinctly so
            # operators can alert on it.
            failure = GuaranteedFailure(
                code=GuaranteedFailureCode.TAU_PROVER_INTERNAL_ERROR,
                message=f"Tau prover raised {type(exc).__name__}: {exc}",
                context={"error_type": type(exc).__name__},
            )
            return self._finalise_reject(
                revision_id=revision_id,
                compile_hash=compiled.compile_hash,
                budget_ms=budget_ms,
                failure=failure,
                baseline_z3=baseline_z3,
            )

        # InconclusiveProof leaks through when Tau can't decide but the
        # adapter hasn't mapped it to a timeout/unavailable already.
        if isinstance(verdict, InconclusiveProof):
            failure = GuaranteedFailure(
                code=_inconclusive_code(verdict.category),
                message=f"Tau returned inconclusive proof: {verdict.reason}",
                context={
                    "category": verdict.category,
                    "backend": verdict.backend,
                    "extra": verdict.details or {},
                },
            )
            return self._finalise_reject(
                revision_id=revision_id,
                compile_hash=compiled.compile_hash,
                budget_ms=budget_ms,
                failure=failure,
                baseline_z3=baseline_z3,
            )

        # Tau's `_relabel` machinery hides inconclusive outcomes behind a
        # ProofToken whose proof_strength starts with "pattern+tau-". Those
        # are pattern-fallback admissions and are explicitly forbidden
        # under Guaranteed Mode.
        if isinstance(verdict, ProofToken):
            strength = verdict.proof_strength or ""
            if strength != "complete":
                failure = GuaranteedFailure(
                    code=_strength_to_code(strength),
                    message=(
                        "Tau could not produce a complete proof "
                        f"(strength={strength!r}). Guaranteed Mode admits "
                        "only 'complete' proofs."
                    ),
                    context={
                        "proof_strength": strength,
                        "backend": verdict.backend,
                    },
                )
                return self._finalise_reject(
                    revision_id=revision_id,
                    compile_hash=compiled.compile_hash,
                    budget_ms=budget_ms,
                    failure=failure,
                    baseline_z3=baseline_z3,
                )

            # Decisive SAT. Success.
            self._sanity_no_z3_invoked(baseline_z3)
            artifact = self._make_artifact(
                policy_revision_id=revision_id,
                compile_hash=compiled.compile_hash,
                proof_result="consistent",
                totality_check_passed=True,
                budget_ms=budget_ms,
                failure=None,
            )
            self._persist(artifact)
            return GuaranteedProofResult(
                artifact=artifact,
                consistent=True,
                witness=None,  # fragment v1 does not surface witnesses today
            )

        if isinstance(verdict, Contradiction):
            # Decisive UNSAT. Success: we proved the policy inconsistent.
            self._sanity_no_z3_invoked(baseline_z3)
            artifact = self._make_artifact(
                policy_revision_id=revision_id,
                compile_hash=compiled.compile_hash,
                proof_result="inconsistent",
                totality_check_passed=True,
                budget_ms=budget_ms,
                failure=None,
            )
            self._persist(artifact)
            return GuaranteedProofResult(
                artifact=artifact,
                consistent=False,
                witness=None,
            )

        # Unknown return type -- treat as internal error, fail closed.
        failure = GuaranteedFailure(
            code=GuaranteedFailureCode.TAU_PROVER_INTERNAL_ERROR,
            message=(
                "Tau prover returned an unexpected value of type "
                f"{type(verdict).__name__}. Guaranteed Mode refuses admission."
            ),
        )
        return self._finalise_reject(
            revision_id=revision_id,
            compile_hash=compiled.compile_hash,
            budget_ms=budget_ms,
            failure=failure,
            baseline_z3=baseline_z3,
        )

    # ── internals ──────────────────────────────────────────────────────────

    def _sanity_no_z3_invoked(self, baseline: int) -> None:
        """Assert z3 was not invoked during the preceding prove call.

        Lives here so tests can drive it directly as
        ``prover._sanity_no_z3_invoked(0)``. Raises ``AssertionError`` when
        the module-level counter moved.
        """
        delta = _Z3_CALL_COUNTER["count"] - baseline
        assert delta == 0, (
            f"z3 was invoked {delta} time(s) during a Guaranteed Mode "
            "prove; Tau must be the sole semantic authority."
        )

    def _tau_backend_version(self) -> str:
        if self._cached_tau_version is not None:
            return self._cached_tau_version
        with self._version_lock:
            if self._cached_tau_version is None:
                self._cached_tau_version = getattr(
                    self._prover, "version_string", "unknown"
                )
            return self._cached_tau_version

    def _language_tier_version(self) -> str:
        describe = getattr(self._language, "describe", None)
        if callable(describe):
            info = describe() or {}
            return str(info.get("version", "unknown"))
        return "unknown"

    def _make_artifact(
        self,
        *,
        policy_revision_id: str,
        compile_hash: str,
        proof_result: str,
        totality_check_passed: bool,
        budget_ms: int,
        failure: Optional[GuaranteedFailure],
    ) -> GuaranteedProofArtifact:
        return GuaranteedProofArtifact(
            artifact_id=make_artifact_id(),
            policy_revision_id=policy_revision_id,
            compile_hash=compile_hash,
            tau_backend_version=self._tau_backend_version(),
            language_tier_version=self._language_tier_version(),
            proof_result=proof_result,  # type: ignore[arg-type]
            totality_check_passed=totality_check_passed,
            prove_timestamp=utc_now(),
            prove_budget_ms=budget_ms,
            failure=failure,
        )

    def _persist(self, artifact: GuaranteedProofArtifact) -> None:
        store = self._artifact_store
        if store is None:
            return
        try:
            store.save(artifact)
        except OSError as exc:
            # Logging only -- a persistence failure must NOT flip a
            # decisive proof verdict. Guaranteed Mode's contract is that
            # the verdict surfaces; the durable audit trail is a separate
            # responsibility of the operator's storage layer.
            logger.warning(
                "failed to persist guaranteed proof artifact %s: %s",
                artifact.artifact_id, exc,
            )

    def _finalise_reject(
        self,
        *,
        revision_id: str,
        compile_hash: str,
        budget_ms: int,
        failure: GuaranteedFailure,
        baseline_z3: int,
    ) -> GuaranteedFailure:
        artifact = self._make_artifact(
            policy_revision_id=revision_id,
            compile_hash=compile_hash,
            proof_result="rejected",
            totality_check_passed=True,
            budget_ms=budget_ms,
            failure=failure,
        )
        self._persist(artifact)
        self._sanity_no_z3_invoked(baseline_z3)
        return failure


# ── helpers ────────────────────────────────────────────────────────────────


def _inconclusive_code(category: str) -> GuaranteedFailureCode:
    """Translate an ``InconclusiveProof`` category to a failure code."""
    mapping = {
        "timeout": GuaranteedFailureCode.TAU_PROOF_TIMEOUT,
        "unavailable": GuaranteedFailureCode.TAU_BACKEND_UNAVAILABLE,
        "compile_error": GuaranteedFailureCode.TAU_COMPILE_INCOMPLETE,
        "unsupported_fragment": GuaranteedFailureCode.TAU_UNSUPPORTED_CONSTRUCT,
        "parse_error": GuaranteedFailureCode.TAU_COMPILE_INCOMPLETE,
    }
    return mapping.get(category, GuaranteedFailureCode.TAU_PROOF_INCONCLUSIVE)


def _strength_to_code(strength: str) -> GuaranteedFailureCode:
    """Map a non-'complete' proof_strength back to a failure code."""
    if "tau-unavailable" in strength:
        return GuaranteedFailureCode.TAU_BACKEND_UNAVAILABLE
    if "tau-inconclusive" in strength:
        return GuaranteedFailureCode.TAU_PROOF_INCONCLUSIVE
    # Plain "pattern" (no Tau at all) is still inconclusive for Guaranteed
    # Mode because the pattern prover is not an authoritative decider.
    return GuaranteedFailureCode.TAU_PROOF_INCONCLUSIVE
