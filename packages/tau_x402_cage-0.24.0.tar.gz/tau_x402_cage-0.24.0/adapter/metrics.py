"""Prometheus metrics registry for tau-x402-cage (v0.9.0).

Single-registry module. Every counter / histogram / gauge the runtime emits
lives here so the SaaS ``/metrics`` route and the ``tau-x402-cage metrics``
CLI draw from one source of truth.

Design notes
------------

* **Optional dependency.** ``prometheus_client`` sits under the ``[metrics]``
  extra. Importing this module without it installed is an error, by design:
  if an operator asks for metrics, they want metrics. The SaaS route, the
  CLI subcommand, and the daemon instrumentation all call
  ``is_available()`` first and degrade gracefully (no-op bumps, 503 routes)
  when the dep is missing.

* **One registry per process.** We use a module-level
  ``CollectorRegistry`` rather than the default global one so tests can
  rebuild it between cases, and so a SaaS process that also runs the
  default python ``ProcessCollector`` does not get its counters mingled
  into ours.

* **Synchronous instrumentation only.** Every public API here is a
  plain method call that resolves in microseconds. No threads, no
  background scrapers — the x402 hot path still owes ``p95 < 10ms``.

* **Immutable label taxonomy.** Label values are drawn from tightly
  bounded enums so Prometheus cardinality stays predictable. ``verdict``
  is ``permit|reject|inconclusive``; ``backend`` is
  ``pattern|tau|z3|hybrid``; ``status`` is
  ``pending|approved|rejected``; ``stream`` is ``permit|reject|verdict``.
  We raise on unknown values rather than silently allow drift.
"""
from __future__ import annotations

from typing import Optional, Tuple

try:
    from prometheus_client import (
        CollectorRegistry,
        Counter,
        Gauge,
        Histogram,
        generate_latest,
    )
    from prometheus_client.exposition import CONTENT_TYPE_LATEST
    _PROMETHEUS_AVAILABLE = True
except ImportError:  # pragma: no cover - exercised only when extra absent
    CollectorRegistry = None  # type: ignore[assignment, misc]
    Counter = None  # type: ignore[assignment, misc]
    Gauge = None  # type: ignore[assignment, misc]
    Histogram = None  # type: ignore[assignment, misc]
    generate_latest = None  # type: ignore[assignment]
    CONTENT_TYPE_LATEST = "text/plain; version=0.0.4; charset=utf-8"
    _PROMETHEUS_AVAILABLE = False


VERDICT_LABELS: Tuple[str, ...] = ("permit", "reject", "inconclusive")
BACKEND_LABELS: Tuple[str, ...] = ("pattern", "tau", "z3", "hybrid")
PROPOSAL_STATUS_LABELS: Tuple[str, ...] = ("pending", "approved", "rejected")
STREAM_LABELS: Tuple[str, ...] = ("permit", "reject", "verdict")
RATE_LIMIT_REASONS: Tuple[str, ...] = ("qps", "quota")

# Histogram buckets tuned for the cage hot path: p95 < 10ms on permit,
# tail can stretch to seconds for a cold Tau compile. Powers-of-two-ish
# from 1ms to 30s covers both ends without wasting buckets.
_LATENCY_BUCKETS = (
    0.0005, 0.001, 0.0025, 0.005, 0.01, 0.025, 0.05, 0.1,
    0.25, 0.5, 1.0, 2.5, 5.0, 10.0, 30.0,
)


def is_available() -> bool:
    """Return True iff ``prometheus_client`` imported successfully."""
    return _PROMETHEUS_AVAILABLE


class _NullMetrics:
    """No-op stand-in used when prometheus_client is missing.

    Every public method on :class:`CageMetrics` has a matching no-op here
    so call sites never need an ``if metrics is not None`` guard. Exposes
    the same attribute names; tests assert behaviour via ``is_available()``.
    """

    backend: str = "null"

    def record_admission(self, verdict: str) -> None:  # noqa: D401 - trivial
        return None

    def observe_prover_latency(self, backend: str, seconds: float) -> None:
        return None

    def record_revision(self) -> None:
        return None

    def set_proposals(self, status: str, count: int) -> None:
        return None

    def set_history_size(self, stream: str, count: int) -> None:
        return None

    def set_branches_active(self, count: int) -> None:
        return None

    def set_z3_push_depth(self, depth: int) -> None:
        return None

    def record_rate_limit_rejected(self, tenant: str, reason: str) -> None:
        return None

    def record_shadow_would_reject(self, rule_id: str) -> None:
        return None

    def record_advisory_would_reject(self, rule_id: str, provider: str) -> None:
        return None

    def snapshot(self) -> dict:
        return {"available": False}

    def render_text(self) -> bytes:
        return b""

    def content_type(self) -> str:
        return CONTENT_TYPE_LATEST


class CageMetrics:
    """Prometheus counters / histograms / gauges for the cage.

    Construct once per process (typically in ``CageDaemon.__init__``) and
    pass the instance into call sites that need to bump counters. The
    module-level :func:`get_default` returns a lazily-built singleton for
    scripts that don't thread a :class:`CageMetrics` through their own
    factories (the SaaS ``/metrics`` route, the CLI subcommand).
    """

    # Metric name prefix. Prometheus conventions: application first, then
    # subsystem, then what the metric measures, then the unit.
    _PREFIX = "tau_x402"

    def __init__(self, registry: Optional["CollectorRegistry"] = None) -> None:
        if not _PROMETHEUS_AVAILABLE:
            raise RuntimeError(
                "CageMetrics requires prometheus_client; install with "
                "`pip install tau-x402-cage[metrics]`"
            )
        self._registry = registry if registry is not None else CollectorRegistry()

        self._admissions = Counter(
            f"{self._PREFIX}_admissions_total",
            "Total x402 admissions processed, labelled by verdict.",
            labelnames=("verdict",),
            registry=self._registry,
        )
        self._prover_latency = Histogram(
            f"{self._PREFIX}_prover_latency_seconds",
            "Wall-clock time spent in the admission prover chain, "
            "by backend.",
            labelnames=("backend",),
            buckets=_LATENCY_BUCKETS,
            registry=self._registry,
        )
        self._revisions = Counter(
            f"{self._PREFIX}_revisions_total",
            "Total policy revisions committed by the daemon.",
            registry=self._registry,
        )
        self._proposals = Gauge(
            f"{self._PREFIX}_proposals",
            "Number of proposals in the approval queue, by status.",
            labelnames=("status",),
            registry=self._registry,
        )
        self._history_size = Gauge(
            f"{self._PREFIX}_history_size",
            "Current size of each history stream.",
            labelnames=("stream",),
            registry=self._registry,
        )
        self._branches_active = Gauge(
            f"{self._PREFIX}_branches_active",
            "Number of branches currently tracked by the revision log.",
            registry=self._registry,
        )
        self._z3_push_depth = Gauge(
            f"{self._PREFIX}_z3_push_depth",
            "Depth of the IncrementalZ3Prover push/pop stack.",
            registry=self._registry,
        )
        self._rate_limit_rejected = Counter(
            f"{self._PREFIX}_rate_limit_rejected_total",
            "Total requests rejected by the SaaS rate limiter, by tenant and reason.",
            labelnames=("tenant", "reason"),
            registry=self._registry,
        )
        # v0.13.0 shadow/advisory counters. Two distinct surfaces so a
        # Grafana dashboard can differentiate "would have blocked in
        # shadow mode (zero-friction trial)" from "advisory guard caught
        # drift alongside enforce". The tenant label is intentionally
        # absent — shadow/advisory is a daemon-level mode, not per-tenant.
        self._shadow_would_reject = Counter(
            f"{self._PREFIX}_shadow_would_reject_total",
            (
                "Intents that would have been rejected in enforce mode "
                "but were permitted through shadow mode. Bumped per "
                "check_payment when the daemon is in shadow AND the "
                "would-have verdict is reject."
            ),
            labelnames=("rule_id",),
            registry=self._registry,
        )
        self._advisory_would_reject = Counter(
            f"{self._PREFIX}_advisory_would_reject_total",
            (
                "Intents that would have been rejected under an advisory "
                "rule guard. Bumped per check_payment when the daemon "
                "is in advisory mode AND the would-have verdict is "
                "reject. Separate from the shadow counter so dashboards "
                "distinguish trial-run from drift-detection deployments."
            ),
            labelnames=("rule_id", "provider"),
            registry=self._registry,
        )

        # Pre-create every label permutation so scraping returns zeros
        # rather than missing series on a freshly-booted daemon. This is
        # standard Prometheus hygiene — missing series cause PromQL
        # ``rate()`` queries to break on the first sample.
        for verdict in VERDICT_LABELS:
            self._admissions.labels(verdict=verdict)
        for backend in BACKEND_LABELS:
            self._prover_latency.labels(backend=backend)
        for status in PROPOSAL_STATUS_LABELS:
            self._proposals.labels(status=status).set(0)
        for stream in STREAM_LABELS:
            self._history_size.labels(stream=stream).set(0)
        self._branches_active.set(0)
        self._z3_push_depth.set(0)

    @property
    def registry(self) -> "CollectorRegistry":
        return self._registry

    # ── mutators ───────────────────────────────────────────────────────────

    def record_admission(self, verdict: str) -> None:
        """Bump the admission counter for ``verdict``.

        Unknown verdicts are silently coerced to ``inconclusive`` so a
        mis-instrumented call site never drops the data point (the worst
        observability failure mode is silence).
        """
        if verdict not in VERDICT_LABELS:
            verdict = "inconclusive"
        self._admissions.labels(verdict=verdict).inc()

    def observe_prover_latency(self, backend: str, seconds: float) -> None:
        """Record a prover wall-clock observation.

        ``backend`` must be one of :data:`BACKEND_LABELS`. We raise on
        unknown values to fail loud at instrumentation time — label drift
        is a recurring Prometheus footgun we refuse to paper over.
        """
        if backend not in BACKEND_LABELS:
            raise ValueError(
                f"backend must be one of {BACKEND_LABELS}, got {backend!r}"
            )
        if seconds < 0:
            # Clock skew or broken timer — bucket into the lowest bucket
            # rather than poison the histogram with a negative sample.
            seconds = 0.0
        self._prover_latency.labels(backend=backend).observe(seconds)

    def record_revision(self) -> None:
        """Bump the ``revisions_total`` counter. Called once per admitted revision."""
        self._revisions.inc()

    def set_proposals(self, status: str, count: int) -> None:
        """Set the current proposal count for ``status`` (pending / approved / rejected)."""
        if status not in PROPOSAL_STATUS_LABELS:
            raise ValueError(
                f"status must be one of {PROPOSAL_STATUS_LABELS}, got {status!r}"
            )
        self._proposals.labels(status=status).set(max(int(count), 0))

    def set_history_size(self, stream: str, count: int) -> None:
        """Set the current size of a history stream (permit / reject / verdict)."""
        if stream not in STREAM_LABELS:
            raise ValueError(
                f"stream must be one of {STREAM_LABELS}, got {stream!r}"
            )
        self._history_size.labels(stream=stream).set(max(int(count), 0))

    def set_branches_active(self, count: int) -> None:
        """Set the number of branches currently tracked."""
        self._branches_active.set(max(int(count), 0))

    def set_z3_push_depth(self, depth: int) -> None:
        """Set the current z3 push/pop stack depth.

        Wired to ``IncrementalZ3Prover.metrics()['push_depth']``. Zero when
        no incremental prover is configured.
        """
        self._z3_push_depth.set(max(int(depth), 0))

    def record_rate_limit_rejected(self, tenant: str, reason: str) -> None:
        """Bump the rate-limit rejection counter.

        ``reason`` is ``qps`` when the token bucket ran dry or ``quota``
        when the monthly allowance is exhausted. Unknown values are
        coerced to ``qps`` — we refuse to drop an observability data
        point over a mis-instrumented call site.
        """
        if reason not in RATE_LIMIT_REASONS:
            reason = "qps"
        self._rate_limit_rejected.labels(tenant=tenant, reason=reason).inc()

    def record_shadow_would_reject(self, rule_id: str) -> None:
        """Bump the shadow-mode would-have-rejected counter (v0.13.0).

        Labelled on ``rule_id`` only — shadow mode is about "try before
        you enforce", the operator wants per-rule granularity so they
        can see which rules fired in dry-run. Unknown rule_ids pass
        through verbatim: label cardinality is bounded by the declared
        policy, not by user input.
        """
        label = rule_id or "unknown"
        self._shadow_would_reject.labels(rule_id=label).inc()

    def record_advisory_would_reject(self, rule_id: str, provider: str) -> None:
        """Bump the advisory-mode would-have-rejected counter (v0.13.0).

        Labelled on ``(rule_id, provider)`` so an operator running
        advisory alongside enforce can see which provider traffic the
        would-be-rejected rule targets. Provider cardinality is bounded
        in practice by the ProviderAllowlist surface; we keep it because
        drift-detection is the advisory use case and the provider
        dimension is the single most common grouping in audit reports.
        """
        r_label = rule_id or "unknown"
        p_label = provider or "unknown"
        self._advisory_would_reject.labels(
            rule_id=r_label, provider=p_label
        ).inc()

    # ── readers ────────────────────────────────────────────────────────────

    def render_text(self) -> bytes:
        """Return the Prometheus text exposition as raw bytes."""
        return generate_latest(self._registry)

    def content_type(self) -> str:
        """Return the MIME type a Prometheus scraper expects."""
        return CONTENT_TYPE_LATEST

    def snapshot(self) -> dict:
        """Return a plain dict of current counter/gauge values.

        Useful for the CLI ``--format=json`` path and for unit tests that
        want to assert on observable state without reaching into the
        registry internals.
        """
        out: dict = {
            "available": True,
            "admissions_total": {},
            "revisions_total": self._sample_counter(self._revisions),
            "proposals": {},
            "history_size": {},
            "branches_active": self._sample_gauge(self._branches_active),
            "z3_push_depth": self._sample_gauge(self._z3_push_depth),
            "prover_latency_seconds_count": {},
            "prover_latency_seconds_sum": {},
            # v0.13.0 shadow/advisory counters — aggregate sums over all
            # rule_id / provider labels for a quick one-number snapshot.
            # The detailed per-rule breakdown lives in the Prometheus
            # text exposition (render_text()).
            "shadow_would_reject_total": self._sum_counter_children(
                self._shadow_would_reject
            ),
            "advisory_would_reject_total": self._sum_counter_children(
                self._advisory_would_reject
            ),
        }
        for verdict in VERDICT_LABELS:
            out["admissions_total"][verdict] = self._sample_counter(
                self._admissions.labels(verdict=verdict)
            )
        for status in PROPOSAL_STATUS_LABELS:
            out["proposals"][status] = self._sample_gauge(
                self._proposals.labels(status=status)
            )
        for stream in STREAM_LABELS:
            out["history_size"][stream] = self._sample_gauge(
                self._history_size.labels(stream=stream)
            )
        for backend in BACKEND_LABELS:
            sample = self._sample_histogram(
                self._prover_latency.labels(backend=backend)
            )
            out["prover_latency_seconds_count"][backend] = sample["count"]
            out["prover_latency_seconds_sum"][backend] = sample["sum"]
        return out

    @staticmethod
    def _sample_counter(child) -> float:
        """Pull the underlying float from a Counter child.

        prometheus_client stores values in an internal ``_value`` object
        with a ``.get()`` accessor. Using that private surface is ugly
        but the only stable way to sample a single child without walking
        the whole registry.
        """
        return float(child._value.get())  # type: ignore[attr-defined]

    @staticmethod
    def _sample_gauge(child) -> float:
        return float(child._value.get())  # type: ignore[attr-defined]

    @staticmethod
    def _sample_histogram(child) -> dict:
        count = float(child._sum.get())  # type: ignore[attr-defined]
        sample_count = sum(
            float(b.get())  # type: ignore[attr-defined]
            for b in child._buckets[-1:]  # type: ignore[attr-defined]
        )
        return {"sum": count, "count": sample_count}

    @staticmethod
    def _sum_counter_children(counter) -> float:
        """Sum across every labelled child of a multi-label Counter.

        Used for the snapshot surface where we want a single aggregate
        per counter family (e.g. "how many shadow rejects total across
        every rule_id"). The Prometheus text exposition keeps the full
        per-label breakdown — this helper is strictly for the JSON
        ``snapshot()`` convenience view.
        """
        try:
            children = counter._metrics.values()  # type: ignore[attr-defined]
        except AttributeError:
            return 0.0
        total = 0.0
        for child in children:
            try:
                total += float(child._value.get())  # type: ignore[attr-defined]
            except AttributeError:
                continue
        return total


# ── module-level default ─────────────────────────────────────────────────────

_DEFAULT: Optional[CageMetrics] = None


def get_default() -> "CageMetrics | _NullMetrics":
    """Return the module-level default metrics singleton.

    Lazy construction so importing this module does not attempt to build
    a registry when the extra is not installed. The null stand-in keeps
    call sites simple.
    """
    global _DEFAULT
    if _DEFAULT is not None:
        return _DEFAULT
    if not _PROMETHEUS_AVAILABLE:
        _DEFAULT = _NullMetrics()  # type: ignore[assignment]
        return _DEFAULT
    _DEFAULT = CageMetrics()
    return _DEFAULT


def reset_default() -> None:
    """Drop the module-level singleton. Tests use this between cases."""
    global _DEFAULT
    _DEFAULT = None
