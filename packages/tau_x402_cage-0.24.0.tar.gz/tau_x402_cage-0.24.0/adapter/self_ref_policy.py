"""Self-referential policy invariants.

v0.13.0 ships two invariants whose admission/enforcement depend on the cage's
OWN runtime state -- not on the current payment intent alone. This is the
genuine Tau-flex capability that hand-rolled policy engines (OPA, Cedar,
imperative if-trees) cannot express declaratively: rules that observe the
system they are running on.

Two behaviours are covered here:

* ``InstabilityGuard`` is an ``Invariant`` subclass whose per-call verdict
  depends on the rejection history the daemon has been accumulating. When
  the reject count for a given provider crosses ``reject_threshold`` inside
  ``window_seconds``, the guard "tightens" and any payment above
  ``tighten_to`` is rejected. After ``recovery_seconds`` of quiet (no new
  rejects for the provider), the guard loosens automatically. The hot path
  in ``check_payment`` reads ``rejects`` directly -- no mutable state on
  the invariant itself, so the dataclass stays frozen and thread-safe.

* ``MergeFailureCooldown`` is a daemon-level policy (NOT a per-payment
  invariant) that kicks in after a branch merge returns ``conflict``. A
  configurable cooldown window prevents the same merge being retried at
  high frequency while operators reconcile the branches. State is
  persisted to a sidecar JSON file alongside the revision log and
  rehydrated on daemon restart.

These two are the v0.13.0 self-referential beachhead. Full Tau-style
self-reference over specs (a rule that literally inspects the spec
composition that admitted it) is upstream-blocked; see
``docs/self_referential_policy.md``.
"""
from __future__ import annotations

import hashlib
import json
import threading
import time
from dataclasses import dataclass, field
from decimal import Decimal
from pathlib import Path
from typing import Any, Optional, Sequence, TYPE_CHECKING

from adapter.invariants import (
    Invariant,
    InvariantError,
    Violation,
    _amount_to_bv,
    _provider_hash,
)

if TYPE_CHECKING:  # pragma: no cover -- typing only
    from adapter.payment_intent_matcher import PaymentIntent


# ── InstabilityGuard ────────────────────────────────────────────────────────


@dataclass(frozen=True)
class InstabilityGuard(Invariant):
    """Tighten spend caps automatically after repeated rejections.

    Semantics (per call against provider ``P``):

      1. Count the payments in the ``rejects`` history that match ``P`` and
         whose timestamp is within the last ``window_seconds``.
      2. If that count is ``>= reject_threshold``, the guard is ACTIVE and
         any intent for ``P`` above ``tighten_to`` is rejected with
         ``rule_id="instability_guard"``.
      3. Otherwise the guard is QUIET. Payments within the normal caps
         pass; there is no independent cap above ``tighten_to``.
      4. ``recovery_seconds`` drives the deactivation boundary: a reject
         older than ``window_seconds`` -- and older than ``recovery_seconds``
         since the LAST reject -- no longer counts. This yields the
         "3 rejects tighten, then 5 minutes of quiet restores" shape the
         operators asked for.

    Invariant on the data: ``tighten_to <= max_amount_before`` (we cannot
    validate that against sibling invariants from inside ``_post_init__``,
    but we do validate self-consistency on the fields).

    Fragment membership: v2 (temporal + arithmetic). Fragment v1 cannot
    reason about rolling counters. We emit a bounded z3 encoding via
    ``compile_z3_body`` so declare-time composition with other v2
    invariants is decidable.
    """

    provider: str
    reject_threshold: int
    window_seconds: int
    tighten_to: Decimal
    recovery_seconds: int
    currency: str = "USDC"

    def __post_init__(self) -> None:
        if not isinstance(self.provider, str) or not self.provider:
            raise InvariantError("InstabilityGuard provider must be a non-empty string")
        if self.reject_threshold <= 0:
            raise InvariantError(
                f"InstabilityGuard reject_threshold must be > 0, "
                f"got {self.reject_threshold}"
            )
        if self.window_seconds <= 0:
            raise InvariantError(
                f"InstabilityGuard window_seconds must be > 0, "
                f"got {self.window_seconds}"
            )
        if self.recovery_seconds <= 0:
            raise InvariantError(
                f"InstabilityGuard recovery_seconds must be > 0, "
                f"got {self.recovery_seconds}"
            )
        if not isinstance(self.tighten_to, Decimal):
            raise InvariantError(
                "InstabilityGuard tighten_to must be a Decimal"
            )
        if self.tighten_to <= 0:
            raise InvariantError(
                f"InstabilityGuard tighten_to must be > 0, got {self.tighten_to}"
            )

    # Tau/temporal form. See docstring for fragment membership.
    def _body(self) -> str:
        """Emit a past-LTL Tau body describing "once threshold-in-window, cap".

        The body uses the Bug-3-patched ``O`` operator so a rolling-count
        guard composes with other temporal rules in the same outer ``G``.
        We emit a conservative shape: if the recent reject count for this
        provider exceeds the threshold, the payment amount must be
        bounded by ``tighten_to``.
        """
        tighten = _amount_to_bv(self.tighten_to)
        phash = _provider_hash(self.provider)
        # reject_count[t] is the rolling count of rejects for provider P within
        # the last window_seconds; Tau maintains it as a stream. We use the
        # Bug-3-patched O for past-LTL "has recently tightened".
        return (
            f"(provider[t]:bv[16] = {{ {phash} }}:bv[16]"
            f" && reject_count[t]:bv[16] >= {{ {self.reject_threshold} }}:bv[16])"
            f" -> payment_amount[t]:bv[64] <= {tighten}"
        )

    def _sat_body(self) -> str:
        # Not in fragment v1 -- this is a rolling-counter rule.
        return super()._sat_body()

    def compile_z3_body(self, unroll_steps: int = 10) -> tuple[list, dict]:
        """Emit z3 constraints for declare-time consistency checking.

        Returns (constraints, summary). Unlike the existing fragment-v2
        invariants, we do not register in ``_fragment_v2_classes`` because
        the dispatch there is locked down to the v0.7.0 fragment set. The
        daemon calls this method directly when it needs to prove composed
        consistency of an ``InstabilityGuard`` with the rest of the policy.

        The z3 encoding is a bounded unrolling: N per-step amounts bound
        by ``tighten_to`` when the per-step reject_count exceeds
        threshold. The amounts are otherwise free so the guard composes
        trivially with SpendingCap etc.
        """
        try:
            import z3 as z3mod
        except ImportError as exc:  # pragma: no cover -- compile path
            raise RuntimeError(
                "z3-solver is required to compile InstabilityGuard. "
                "Install with `pip install tau-x402-cage[fragment-v2]`."
            ) from exc
        max_micros = int(self.tighten_to * Decimal("1_000_000"))
        tag = f"instab_{hash(self) & 0xffff:04x}"
        step_amts = [
            z3mod.BitVec(f"{tag}_amt_{i}", 64) for i in range(unroll_steps)
        ]
        reject_counts = [
            z3mod.BitVec(f"{tag}_rej_{i}", 16) for i in range(unroll_steps)
        ]
        constraints = []
        threshold = z3mod.BitVecVal(self.reject_threshold, 16)
        cap = z3mod.BitVecVal(max_micros, 64)
        for i in range(unroll_steps):
            # ULE on the reject_count threshold via ULT negation: if
            # reject_count >= threshold, amount <= tighten_to.
            constraints.append(
                z3mod.Implies(
                    z3mod.UGE(reject_counts[i], threshold),
                    z3mod.ULE(step_amts[i], cap),
                )
            )
        summary = {
            "class": "InstabilityGuard",
            "provider": self.provider,
            "reject_threshold": self.reject_threshold,
            "window_seconds": self.window_seconds,
            "tighten_to_micros": max_micros,
            "recovery_seconds": self.recovery_seconds,
            "unroll_steps": unroll_steps,
            "tag": tag,
        }
        return constraints, summary

    # ── hot-path enforcement ────────────────────────────────────────────

    def check_payment(
        self,
        intent: "PaymentIntent",
        history: Sequence["PaymentIntent"],
        rejects: Sequence["PaymentIntent"] = (),
    ) -> Optional[Violation]:
        """Check whether the intent should be tightened.

        Reads ``rejects`` (the reject history for this cage) to decide
        whether the guard is ACTIVE for this provider. When ACTIVE and the
        intent amount exceeds ``tighten_to``, reject with a self-referential
        explanation. When QUIET, the guard does not participate in the
        verdict at all.
        """
        if intent.provider != self.provider:
            return None
        if intent.currency != self.currency:
            return None
        now = intent.timestamp_unix
        window_cutoff = now - self.window_seconds
        provider_rejects = [
            r for r in rejects
            if r.provider == self.provider
            and r.timestamp_unix >= window_cutoff
        ]
        if len(provider_rejects) < self.reject_threshold:
            return None
        # The guard is active unless recovery_seconds have passed since
        # the last in-window reject. If the most-recent reject is older
        # than recovery_seconds, we're in the recovery phase and let the
        # guard fade. This is what enables the "quiet period restores"
        # behaviour in the acceptance test.
        last_reject_ts = max(r.timestamp_unix for r in provider_rejects)
        if (now - last_reject_ts) >= self.recovery_seconds:
            return None
        # ACTIVE and tightened.
        if intent.amount <= self.tighten_to:
            return None
        return Violation(
            rule_id="instability_guard",
            reason_text=(
                f"Instability guard tightened to {self.tighten_to} "
                f"{self.currency} for provider {self.provider!r} after "
                f"{len(provider_rejects)} reject(s) in the last "
                f"{self.window_seconds}s (intent: {intent.amount})"
            ),
            witness=(
                f"provider={self.provider},"
                f"recent_rejects={len(provider_rejects)},"
                f"threshold={self.reject_threshold},"
                f"tighten_to={self.tighten_to},"
                f"intent={intent.amount}"
            ),
        )

    def active_for(
        self,
        rejects: Sequence["PaymentIntent"],
        now_unix: int,
    ) -> bool:
        """Return True iff the guard is currently tightening for this provider.

        Used by the ``self-ref status`` CLI surface so operators can see
        whether a guard is hot right now without having to drive a payment
        through the full hot path.
        """
        window_cutoff = now_unix - self.window_seconds
        provider_rejects = [
            r for r in rejects
            if r.provider == self.provider
            and r.timestamp_unix >= window_cutoff
        ]
        if len(provider_rejects) < self.reject_threshold:
            return False
        last_reject_ts = max(r.timestamp_unix for r in provider_rejects)
        return (now_unix - last_reject_ts) < self.recovery_seconds


# ── MergeFailureCooldown ────────────────────────────────────────────────────


class MergeFailureCooldownError(RuntimeError):
    """Raised when the cooldown sidecar file is malformed or unwritable."""


@dataclass
class MergeFailureCooldown:
    """Daemon-level cooldown after a failed branch merge.

    Not an ``Invariant`` (no per-payment check). Lives on the daemon and
    is consulted by ``_op_merge_branch`` before dispatching to
    ``RevisionLog.merge_branch``. When a merge returns ``conflict``, we
    record a cooldown expiry timestamp per ``dst`` branch; subsequent
    merge attempts targeting the same ``dst`` short-circuit with
    ``verdict="cooldown"`` until the timestamp elapses.

    Persistence: a single JSON sidecar at ``sidecar_path``. Simple shape
    so manual recovery / audit is straightforward:

        { "cooldowns": { "<dst_branch>": <expiry_unix> },
          "cooldown_seconds": N }

    Thread-safety: one internal lock protects reads and writes. The
    sidecar is rewritten on every state change; payloads are tiny so
    this never becomes a hot path.
    """

    cooldown_seconds: int
    sidecar_path: Optional[Path] = None
    _state: dict[str, int] = field(default_factory=dict)
    _lock: threading.Lock = field(default_factory=threading.Lock, repr=False)

    def __post_init__(self) -> None:
        if self.cooldown_seconds < 0:
            raise MergeFailureCooldownError(
                f"cooldown_seconds must be >= 0, got {self.cooldown_seconds}"
            )
        if self.sidecar_path is not None:
            self._load_from_disk()

    @property
    def enabled(self) -> bool:
        """True iff the cooldown feature is switched on.

        ``cooldown_seconds=0`` is the documented way to keep the feature
        compiled in but disabled per-deployment so rollouts can flip the
        behaviour via an env var without a daemon rebuild.
        """
        return self.cooldown_seconds > 0

    def status_for(
        self,
        dst: str,
        now_unix: Optional[int] = None,
    ) -> Optional[int]:
        """Return the cooldown expiry timestamp for ``dst``, or None.

        A ``None`` return means either the cooldown is not engaged for
        this branch or it has already elapsed (and we've garbage-collected
        the stale entry). ``now_unix`` defaults to ``time.time()``; tests
        freeze the clock by passing an explicit value.
        """
        if not self.enabled:
            return None
        with self._lock:
            expiry = self._state.get(dst)
            if expiry is None:
                return None
            now = int(now_unix if now_unix is not None else time.time())
            if now >= expiry:
                # Stale entry -- clean it up so the sidecar doesn't grow
                # unboundedly and so ``active_cooldowns()`` reports truth.
                del self._state[dst]
                self._persist_locked()
                return None
            return int(expiry)

    def trigger(
        self,
        dst: str,
        now_unix: Optional[int] = None,
    ) -> int:
        """Record a new cooldown for ``dst`` and return the expiry timestamp.

        Called by the daemon after a ``merge_branch`` op returns conflict.
        When the feature is disabled (``cooldown_seconds=0``) this is a
        no-op that returns ``0`` so callers don't have to guard.
        """
        if not self.enabled:
            return 0
        now = int(now_unix if now_unix is not None else time.time())
        expiry = now + int(self.cooldown_seconds)
        with self._lock:
            self._state[dst] = expiry
            self._persist_locked()
        return expiry

    def clear(self, dst: str) -> None:
        """Drop any cooldown entry for ``dst``. Used by admin tooling."""
        with self._lock:
            if dst in self._state:
                del self._state[dst]
                self._persist_locked()

    def active_cooldowns(
        self,
        now_unix: Optional[int] = None,
    ) -> dict[str, int]:
        """Return a snapshot of currently-active cooldowns (dst -> expiry).

        Stale entries are swept in the same pass so repeated calls always
        reflect truth. The return is a copy; callers may mutate it freely.
        """
        now = int(now_unix if now_unix is not None else time.time())
        with self._lock:
            stale = [k for k, v in self._state.items() if now >= v]
            if stale:
                for k in stale:
                    del self._state[k]
                self._persist_locked()
            return dict(self._state)

    # ── persistence ─────────────────────────────────────────────────────

    def _load_from_disk(self) -> None:
        """Rehydrate the cooldown map from sidecar. Missing file = empty."""
        assert self.sidecar_path is not None
        if not self.sidecar_path.exists():
            return
        try:
            raw = self.sidecar_path.read_text(encoding="utf-8")
        except OSError as exc:
            raise MergeFailureCooldownError(
                f"could not read {self.sidecar_path}: {exc}"
            ) from exc
        if not raw.strip():
            return
        try:
            d = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise MergeFailureCooldownError(
                f"{self.sidecar_path} is not valid JSON: {exc}"
            ) from exc
        if not isinstance(d, dict):
            raise MergeFailureCooldownError(
                f"{self.sidecar_path} must contain a JSON object, "
                f"got {type(d).__name__}"
            )
        cooldowns = d.get("cooldowns") or {}
        if not isinstance(cooldowns, dict):
            raise MergeFailureCooldownError(
                f"{self.sidecar_path}: 'cooldowns' must be an object"
            )
        clean: dict[str, int] = {}
        for k, v in cooldowns.items():
            if not isinstance(k, str) or not isinstance(v, (int, float)):
                raise MergeFailureCooldownError(
                    f"{self.sidecar_path}: cooldown entry {k!r} has "
                    f"invalid shape"
                )
            clean[k] = int(v)
        # No lock needed yet -- ctor is single-threaded by contract.
        self._state = clean

    def _persist_locked(self) -> None:
        """Write the current map to disk. Caller must hold self._lock."""
        if self.sidecar_path is None:
            return
        try:
            self.sidecar_path.parent.mkdir(parents=True, exist_ok=True)
            payload = {
                "cooldowns": dict(self._state),
                "cooldown_seconds": int(self.cooldown_seconds),
            }
            # Atomic rewrite: temp-file + rename so a crash mid-write
            # never produces a half-populated sidecar.
            tmp = self.sidecar_path.with_suffix(
                self.sidecar_path.suffix + ".tmp"
            )
            tmp.write_text(
                json.dumps(payload, sort_keys=True), encoding="utf-8"
            )
            tmp.replace(self.sidecar_path)
        except OSError as exc:  # pragma: no cover -- disk full etc.
            raise MergeFailureCooldownError(
                f"could not write {self.sidecar_path}: {exc}"
            ) from exc


# ── factory ─────────────────────────────────────────────────────────────────


def build_merge_failure_cooldown(
    *,
    cooldown_seconds: int,
    sidecar_path: Optional[Path],
) -> MergeFailureCooldown:
    """Factory used by the daemon CLI / constructor.

    Keeps sidecar path construction in one place so tests and production
    agree on where the JSON sidecar lands relative to the revision log.
    """
    return MergeFailureCooldown(
        cooldown_seconds=int(cooldown_seconds),
        sidecar_path=sidecar_path,
    )


# ── revision-log serializer registration ────────────────────────────────────


def _serialize_instability_guard(inv: "InstabilityGuard") -> dict:
    """Emit the JSON-safe dict shape `policy_revision._rehydrate_invariant`
    hands back to ``_construct_instability_guard``.
    """
    return {
        "provider": inv.provider,
        "reject_threshold": inv.reject_threshold,
        "window_seconds": inv.window_seconds,
        "tighten_to": str(inv.tighten_to),
        "recovery_seconds": inv.recovery_seconds,
        "currency": inv.currency,
    }


def _construct_instability_guard(d: dict) -> "InstabilityGuard":
    return InstabilityGuard(
        provider=str(d["provider"]),
        reject_threshold=int(d["reject_threshold"]),
        window_seconds=int(d["window_seconds"]),
        tighten_to=Decimal(str(d["tighten_to"])),
        recovery_seconds=int(d["recovery_seconds"]),
        currency=str(d.get("currency", "USDC")),
    )


def _register_with_revision_log() -> None:
    """Register InstabilityGuard with the revision-log serializer maps.

    Kept as a function so import-time ordering is clear: the registration
    runs after the class definition above. Idempotent -- repeated imports
    (tests reloading the module) simply overwrite the same key.
    """
    # Imported lazily to avoid a circular import with policy_revision,
    # which itself imports Invariant subclasses for its own typed
    # serializers.
    from adapter.policy_revision import (
        INVARIANT_CONSTRUCTORS,
        INVARIANT_SERIALIZERS,
    )
    INVARIANT_SERIALIZERS["InstabilityGuard"] = _serialize_instability_guard
    INVARIANT_CONSTRUCTORS["InstabilityGuard"] = _construct_instability_guard


_register_with_revision_log()


__all__ = [
    "InstabilityGuard",
    "MergeFailureCooldown",
    "MergeFailureCooldownError",
    "build_merge_failure_cooldown",
]
