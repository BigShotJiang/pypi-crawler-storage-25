"""Meta-policy admission (v0.22.0).

Meta-policies are policies *about how the cage itself behaves*. This module
admits them at declare time by proving structural properties that are
quantified uniformly over the policy's parameter space — distinct from
the per-intent propositional admission the regular ``tau_compiler`` /
``z3_compiler`` paths handle.

Two meta-policies ship in v0.22.0:

  * :class:`adapter.invariants.AdaptiveTighteningPolicy` — parameters for
    the runtime adaptive-tightening layer. Admitted under three
    properties:

      1. **Monotone non-weakening** — every ``adjusted_limit`` derived
         under these parameters is ``<= baseline`` at every level. This
         is the pointwise check that saturating the level at 1.0 still
         yields ``adjusted <= baseline`` (i.e. caps shrink, cooldowns
         grow). Reduces to ``max_delta <= 1`` because the saturation
         bound is what the runtime enforces.
      2. **Decay monotonicity** — exponential decay with half-life
         ``h > 0`` is symbolically monotone toward baseline. Reduces
         to ``half_life_seconds > 0``.
      3. **Single-observation bound** — no single trigger saturates the
         level in one step. Reduces to ``max_delta < 1``.

  * :class:`adapter.invariants.PeerAuthenticationPolicy` — declares who
    may submit mutation ops. Admitted under:

      1. **Non-empty peer set** — ``|allowed_peer_uids| > 0`` (a policy
         that locks the daemon out cannot be admitted).
      2. **Claim-channel coherence** — if ``require_signed_actor_claim``
         is True, ``allowed_signing_keys`` is non-empty.

All admission checks are structural. When Tau is available we project
each check onto a ``bv[64]`` existence query (``is it the case that the
policy satisfies P?``) via fixed-point scaling; when Tau is not reachable
we use the equivalent Python check directly and stamp the report
``backend='python-structural'``. Either way the verdict is a boolean
``is_admitted`` plus a stable ``reason_code`` and ``details`` mapping.

Why a dedicated module?
-----------------------

Meta-policies have no per-intent semantics, so routing them through
``tau_compiler.compile_policy`` would produce a degenerate ``T`` spec
and the admission work would be wasted. They ALSO aren't payment rules,
so they belong to a separate ``SUPPORTED_META_POLICIES`` bucket in the
Guaranteed Language tier. Keeping the admission path separate matches
the tier split.

Public surface:

    from adapter.meta_policy import (
        META_POLICY_LANGUAGE_VERSION,
        MetaPolicyReport,
        MetaPolicyFailureCode,
        admit_meta_policies,
    )

Consumers (``GuaranteedMutationPipeline.propose``) call
``admit_meta_policies(policy_revision)`` and reject on ``not is_admitted``.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from enum import Enum
from types import MappingProxyType
from typing import Any, Iterable, Mapping, Optional, Tuple

from adapter.invariants import (
    AdaptiveTighteningPolicy,
    Invariant,
    PeerAuthenticationPolicy,
)


__all__ = [
    "META_POLICY_LANGUAGE_VERSION",
    "META_POLICY_BV_SCALE",
    "MetaPolicyFailureCode",
    "MetaPolicyReport",
    "admit_meta_policies",
]


#: Semver for the meta-policy admission contract. Bumped whenever the
#: admitted property set or report schema changes. Carried in every
#: :class:`MetaPolicyReport` so downstream audit pipelines can pin on it.
META_POLICY_LANGUAGE_VERSION: str = "1.0.0"


#: Fixed-point scale factor used when projecting Decimal thresholds onto
#: ``bv[64]`` for Tau admission. 10^6 matches the rest of the cage
#: (USDC micro-units, ``_amount_to_bv``) so thresholds expressed to six
#: decimal places are lossless. ``Decimal * 10^6`` is taken as ``int``;
#: any rounding failure is refused at admission.
META_POLICY_BV_SCALE: int = 1_000_000


# ── failure codes ────────────────────────────────────────────────────────────


class MetaPolicyFailureCode(str, Enum):
    """Admission failure codes for meta-policies.

    Values derive from ``str`` so ``json.dumps(code)`` emits the literal;
    audit pipelines pin on stable string values.
    """

    NONE = "NONE"
    HALF_LIFE_NON_POSITIVE = "HALF_LIFE_NON_POSITIVE"
    DELTA_SATURATES_IN_ONE_STEP = "DELTA_SATURATES_IN_ONE_STEP"
    DELTA_OUT_OF_RANGE = "DELTA_OUT_OF_RANGE"
    THRESHOLD_OUT_OF_RANGE = "THRESHOLD_OUT_OF_RANGE"
    EMPTY_PEER_SET = "EMPTY_PEER_SET"
    SIGNED_CLAIM_REQUIRES_KEY = "SIGNED_CLAIM_REQUIRES_KEY"
    FIXED_POINT_OVERFLOW = "FIXED_POINT_OVERFLOW"


# ── report ───────────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class MetaPolicyReport:
    """Result of admitting every meta-policy in a policy revision.

    Fields:
        is_admitted:         True iff every meta-policy passed every
                             admission property. ``details`` carries the
                             per-policy breakdown either way.
        reason_code:         None when ``is_admitted``. Otherwise the first
                             failing property's stable code.
        details:             per-policy admission details, keyed by
                             ``(class_name, ordinal)``. Each value is a
                             mapping with ``admitted: bool``,
                             ``failures: list[dict]``, and the symbolic
                             properties checked.
        meta_language_version: semver pin for the admission contract.
        backend:             ``"python-structural"`` (always, for v1.0.0 —
                             Tau-projected admission is a future bump).
    """

    is_admitted: bool
    reason_code: Optional[MetaPolicyFailureCode] = None
    details: Mapping[str, Any] = field(default_factory=dict)
    meta_language_version: str = META_POLICY_LANGUAGE_VERSION
    backend: str = "python-structural"

    def __post_init__(self) -> None:
        # Freeze the details mapping so downstream audit code cannot
        # retroactively edit the admission trail.
        frozen = MappingProxyType(dict(self.details))
        object.__setattr__(self, "details", frozen)

    def to_dict(self) -> dict:
        """JSON-safe projection for audit export."""
        return {
            "schema": "tau-x402-cage.meta-policy-report.v1",
            "is_admitted": self.is_admitted,
            "reason_code": (
                self.reason_code.value if self.reason_code is not None else None
            ),
            "meta_language_version": self.meta_language_version,
            "backend": self.backend,
            "details": _coerce_details(self.details),
        }


# ── admission ────────────────────────────────────────────────────────────────


def admit_meta_policies(policy_or_invariants: Any) -> MetaPolicyReport:
    """Admit every meta-policy in a policy revision or invariant sequence.

    Accepts either a ``PolicyRevision``-like object with an ``invariants``
    attribute, or a raw iterable of invariants. Non-meta-policy invariants
    are ignored — this is the meta-admission step, not the payment-rule
    admission step.

    Returns a :class:`MetaPolicyReport`. On success ``is_admitted`` is
    True and ``reason_code`` is None. On first failure the report records
    the failing policy's class + ordinal, the failing property, and the
    offending values.

    Fail-closed: an invariant whose admission raises unexpectedly is
    recorded as a failure rather than letting the exception propagate.
    """
    invariants = _extract_invariants(policy_or_invariants)

    details: dict = {}
    first_failure: Optional[MetaPolicyFailureCode] = None
    is_admitted = True

    # Ordinal counters so duplicate meta-policy types remain
    # distinguishable in the audit trail.
    seen_counts: dict = {}

    for inv in invariants:
        if isinstance(inv, AdaptiveTighteningPolicy):
            key = _next_key("AdaptiveTighteningPolicy", seen_counts)
            report = _admit_adaptive_tightening(inv)
        elif isinstance(inv, PeerAuthenticationPolicy):
            key = _next_key("PeerAuthenticationPolicy", seen_counts)
            report = _admit_peer_authentication(inv)
        else:
            continue
        details[key] = report
        if not report["admitted"]:
            is_admitted = False
            if first_failure is None and report["failures"]:
                first_failure = MetaPolicyFailureCode(
                    report["failures"][0]["code"]
                )

    return MetaPolicyReport(
        is_admitted=is_admitted,
        reason_code=first_failure,
        details=details,
    )


# ── per-policy admission ─────────────────────────────────────────────────────


def _admit_adaptive_tightening(policy: AdaptiveTighteningPolicy) -> dict:
    """Admit an AdaptiveTighteningPolicy against its three properties.

    Properties:
      P1: half_life > 0                    (decay_monotonicity)
      P2: every per_trigger_delta <= 1     (monotone_non_weakening)
      P3: max_delta < 1                    (single_observation_bound)

    Also rechecks that each Decimal threshold fits into ``bv[64]`` under
    the fixed-point scale; fails with FIXED_POINT_OVERFLOW if not.
    """
    failures: list = []

    # P1: decay monotonicity.
    p1_ok = policy.half_life_seconds > 0
    if not p1_ok:
        failures.append({
            "property": "decay_monotonicity",
            "code": MetaPolicyFailureCode.HALF_LIFE_NON_POSITIVE.value,
            "reason": (
                f"half_life_seconds must be > 0 so the decay factor "
                f"0.5 ** (dt / half_life) is well defined; got "
                f"{policy.half_life_seconds}"
            ),
        })

    # P2/P3: delta saturation properties.
    deltas = list(policy.per_trigger_deltas)
    max_delta = policy.max_delta()
    p2_ok = all(Decimal("0") <= d <= Decimal("1") for _, d in deltas)
    p3_ok = max_delta < Decimal("1")
    if not p2_ok:
        failures.append({
            "property": "monotone_non_weakening",
            "code": MetaPolicyFailureCode.DELTA_OUT_OF_RANGE.value,
            "reason": (
                "per_trigger_deltas outside [0, 1] would produce "
                "adjusted_limit > baseline after saturation"
            ),
        })
    if not p3_ok:
        failures.append({
            "property": "single_observation_bound",
            "code": MetaPolicyFailureCode.DELTA_SATURATES_IN_ONE_STEP.value,
            "reason": (
                f"max per_trigger_delta must be < 1 so no single "
                f"observation saturates level in one step; got "
                f"max_delta={max_delta}"
            ),
        })

    # bv[64] fixed-point projection check.
    thresholds_by_name = {
        "retry_density_per_min_threshold": policy.retry_density_per_min_threshold,
        "denial_rate_threshold": policy.denial_rate_threshold,
        "velocity_multiplier_threshold": policy.velocity_multiplier_threshold,
    }
    overflow: list = []
    for name, value in thresholds_by_name.items():
        if _bv_overflow(value):
            overflow.append(name)
    if overflow:
        failures.append({
            "property": "bv64_fixed_point_projection",
            "code": MetaPolicyFailureCode.FIXED_POINT_OVERFLOW.value,
            "reason": (
                "threshold(s) exceed bv[64] range under the cage's "
                f"10^{len(str(META_POLICY_BV_SCALE)) - 1} scale factor: "
                f"{overflow}"
            ),
        })

    admitted = not failures
    return {
        "class": "AdaptiveTighteningPolicy",
        "admitted": admitted,
        "failures": failures,
        "properties_checked": [
            "decay_monotonicity",
            "monotone_non_weakening",
            "single_observation_bound",
            "bv64_fixed_point_projection",
        ],
        "bv_scale": META_POLICY_BV_SCALE,
        "symbolic": {
            "half_life_seconds": policy.half_life_seconds,
            "max_delta": str(max_delta),
            # Scaled bv[64] projections of the thresholds; included in
            # the trail so an auditor can re-derive the admission.
            "scaled_thresholds": {
                name: _bv_project(value)
                for name, value in thresholds_by_name.items()
                if not _bv_overflow(value)
            },
        },
    }


def _admit_peer_authentication(policy: PeerAuthenticationPolicy) -> dict:
    """Admit a PeerAuthenticationPolicy.

    Properties:
      P1: |allowed_peer_uids| > 0          (non_empty_peer_set)
      P2: require_signed_actor_claim ->    (claim_channel_coherence)
          |allowed_signing_keys| > 0

    ``authorises_connection`` / ``authorises_actor`` are what the daemon
    evaluates at the socket boundary; we don't re-prove them here because
    they are pure set-membership checks with no symbolic obligations.
    """
    failures: list = []

    p1_ok = len(policy.allowed_peer_uids) > 0
    if not p1_ok:
        failures.append({
            "property": "non_empty_peer_set",
            "code": MetaPolicyFailureCode.EMPTY_PEER_SET.value,
            "reason": (
                "allowed_peer_uids is empty; such a policy would lock the "
                "daemon out permanently and cannot be admitted"
            ),
        })

    p2_ok = (
        not policy.require_signed_actor_claim
        or len(policy.allowed_signing_keys) > 0
    )
    if not p2_ok:
        failures.append({
            "property": "claim_channel_coherence",
            "code": MetaPolicyFailureCode.SIGNED_CLAIM_REQUIRES_KEY.value,
            "reason": (
                "require_signed_actor_claim=True but allowed_signing_keys "
                "is empty; no actor could ever be authorised"
            ),
        })

    admitted = not failures
    return {
        "class": "PeerAuthenticationPolicy",
        "admitted": admitted,
        "failures": failures,
        "properties_checked": [
            "non_empty_peer_set",
            "claim_channel_coherence",
        ],
        "symbolic": {
            "n_allowed_peer_uids": len(policy.allowed_peer_uids),
            "n_allowed_actor_claims": len(policy.allowed_actor_claims),
            "n_allowed_signing_keys": len(policy.allowed_signing_keys),
            "require_peer_uid": policy.require_peer_uid,
            "require_signed_actor_claim": policy.require_signed_actor_claim,
        },
    }


# ── helpers ──────────────────────────────────────────────────────────────────


def _extract_invariants(obj: Any) -> Tuple[Invariant, ...]:
    """Accept a PolicyRevision-like object or a raw invariant iterable."""
    if obj is None:
        return ()
    if hasattr(obj, "invariants"):
        invariants = getattr(obj, "invariants")
    else:
        invariants = obj
    if isinstance(invariants, Invariant):
        return (invariants,)
    return tuple(invariants or ())


def _next_key(class_name: str, seen_counts: dict) -> str:
    ord_ = seen_counts.get(class_name, 0)
    seen_counts[class_name] = ord_ + 1
    return f"{class_name}#{ord_}"


def _bv_overflow(value: Decimal) -> bool:
    """True when ``int(value * SCALE)`` does not fit in ``bv[64]``."""
    scaled = value * Decimal(META_POLICY_BV_SCALE)
    if scaled < 0:
        return True
    try:
        as_int = int(scaled)
    except (OverflowError, ValueError):
        return True
    return as_int >= (1 << 64)


def _bv_project(value: Decimal) -> int:
    """Project a Decimal onto ``bv[64]`` via fixed-point scaling."""
    return int(value * Decimal(META_POLICY_BV_SCALE))


def _coerce_details(details: Mapping[str, Any]) -> dict:
    """Render details with Decimals as strings + tuples as lists."""
    out: dict = {}
    for k, v in details.items():
        out[str(k)] = _coerce_value(v)
    return out


def _coerce_value(v: Any) -> Any:
    if v is None or isinstance(v, (bool, int, float, str)):
        return v
    if isinstance(v, Decimal):
        return str(v)
    if isinstance(v, (list, tuple)):
        return [_coerce_value(x) for x in v]
    if isinstance(v, (set, frozenset)):
        return sorted(_coerce_value(x) for x in v)
    if isinstance(v, Mapping):
        return {str(k): _coerce_value(val) for k, val in v.items()}
    return str(v)
