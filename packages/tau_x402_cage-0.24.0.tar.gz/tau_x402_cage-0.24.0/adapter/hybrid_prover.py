"""Cross-fragment hybrid SAT prover (v0.8.0).

A policy can contain invariants from BOTH semantic fragment v1 (decided by
Tau — set-algebraic consistency) and semantic fragment v2 (decided by z3 —
temporal-arithmetic). Routing each invariant to its authoritative prover
in isolation misses cross-fragment interactions: for example, a v1
`ProviderAllowlist` that forbids provider ``B`` while a v2 `SpendingCap`
caps spend at provider ``B``. Neither fragment alone sees the clash;
declare-time admission would pass; the first ``check_payment`` would
quietly reject every intent routed to ``B``.

`HybridProver` composes the verdicts atomically. It runs the pattern
prover first (cheap precheck that catches a lot of the obvious cases),
then routes the v1 subset to Tau and the v2 subset to z3, and finally
performs a lightweight "shared-variable projection" that inspects
cross-fragment pairs for structural interactions the individual provers
cannot see by themselves.

Public surface::

    HybridProver(tau_prover, z3_prover, pattern_prover)
    HybridProver.prove_delta(added, removed, ...)
    HybridProver.prove(invariants, predecessor_hash=None)

Both methods return one of ``ProofToken`` | ``Contradiction`` |
``InconclusiveProof`` from :mod:`adapter.prover`. Short-circuit
semantics: the first decisive Contradiction wins — later fragment
provers are NOT consulted, so there is no wasted z3 / Tau call after a
pattern-level rejection.

See ``docs/hybrid_sat.md`` for the shape of the cross-fragment
interaction detector, what the shared-variable projection catches vs
misses, and complexity bounds.
"""
from __future__ import annotations

import hashlib
import secrets
import time
from dataclasses import dataclass, field
from decimal import Decimal
from typing import Optional, Sequence

from adapter.invariants import (
    Invariant,
    ProviderAllowlist,
    SpendingCap,
)
from adapter.prover import (
    ConsistencyProver,
    Contradiction,
    InconclusiveProof,
    ProofToken,
    PythonPatternProver,
    TauConsistencyProver,
)

# Expose a stable backend identifier for ProofToken.backend and the
# composed proof_strength field.
HYBRID_BACKEND = "hybrid"
HYBRID_BACKENDS_CHAIN = ("pattern", "tau", "z3-incremental")


# ── fragment routing helpers ─────────────────────────────────────────────────


def _is_v1(inv: Invariant) -> bool:
    """True iff ``inv`` is routed to Tau (semantic fragment v1).

    The authoritative definition lives in :mod:`adapter.tau_compiler` but
    we mirror it here to avoid a hard import for callers that only want
    fragment routing (keeps the module import cheap).
    """
    # Fragment registry is small and stable; inline the check rather than
    # reaching into tau_compiler._FRAGMENT_V1 (private by convention).
    from adapter.tau_compiler import fragment_members
    if type(inv) not in fragment_members("v1"):
        return False
    # SpendingCap straddles v1 (per_tx) and v2 (per_window variants); only
    # per_tx is decided by Tau.
    if isinstance(inv, SpendingCap) and inv.scope != "per_tx":
        return False
    return True


def _is_v2(inv: Invariant) -> bool:
    """True iff ``inv`` is routed to z3 (semantic fragment v2)."""
    from adapter.z3_compiler import is_fragment_v2_invariant
    return is_fragment_v2_invariant(inv)


# ── shared-variable projection ───────────────────────────────────────────────


@dataclass(frozen=True)
class _ProviderProjection:
    """Per-provider view across v1 and v2 invariants.

    ``v1_allowed``     -- providers explicitly listed in ProviderAllowlist.
    ``v2_capped``      -- providers with a v2 per_provider_per_window cap.

    Anything listed in ``v2_capped`` but not in ``v1_allowed`` (when at
    least one ProviderAllowlist is declared) is a cross-fragment clash:
    the v2 cap references a provider that the v1 allowlist forbids, so
    the cap is dead code and the composed policy over-constrains intents
    in a way neither fragment alone would reject.
    """

    v1_allowed: frozenset[str]
    v2_capped: frozenset[str]
    v1_has_allowlist: bool

    def cross_fragment_dead_caps(self) -> frozenset[str]:
        """Providers capped in v2 but excluded from every v1 allowlist.

        When NO v1 ProviderAllowlist is present, the v1 layer doesn't
        restrict providers, so no dead caps exist (`v1_has_allowlist` is
        False and we return an empty set). When a v1 allowlist IS
        present, every v2-capped provider outside it is dead code.
        """
        if not self.v1_has_allowlist:
            return frozenset()
        return self.v2_capped - self.v1_allowed


def _project_providers(invariants: Sequence[Invariant]) -> _ProviderProjection:
    """Compute the v1/v2 provider projection used by the clash detector."""
    v1_allowed: set[str] = set()
    v2_capped: set[str] = set()
    has_allowlist = False
    for inv in invariants:
        if isinstance(inv, ProviderAllowlist):
            has_allowlist = True
            v1_allowed |= set(inv.providers)
            continue
        if isinstance(inv, SpendingCap) and inv.scope == "per_provider_per_window":
            if inv.provider:
                v2_capped.add(inv.provider)
    return _ProviderProjection(
        v1_allowed=frozenset(v1_allowed),
        v2_capped=frozenset(v2_capped),
        v1_has_allowlist=has_allowlist,
    )


def _cross_fragment_contradiction(
    invariants: Sequence[Invariant],
    backend: str = "hybrid-projection",
) -> Optional[Contradiction]:
    """Detect cross-fragment interactions the individual provers miss.

    Returns a Contradiction if the v1 ProviderAllowlist and the v2
    per-provider SpendingCap reference disjoint provider sets; otherwise
    None. The check is ~O(|v1|·|v2|) over provider names, which is
    linear in the policy size and cheap compared to Tau/z3.

    Future extensions (see ``docs/hybrid_sat.md``) may add counterparty
    projections, jurisdiction projections, etc.; keep the shape of the
    return value stable so callers don't need to branch.
    """
    proj = _project_providers(invariants)
    dead = proj.cross_fragment_dead_caps()
    if not dead:
        return None
    dead_sorted = sorted(dead)
    allowlist_sorted = sorted(proj.v1_allowed)
    return Contradiction(
        left=f"ProviderAllowlist(providers={allowlist_sorted})",
        right=(
            "SpendingCap(scope=per_provider_per_window, "
            f"provider={dead_sorted[0]!r})"
            if len(dead_sorted) == 1
            else (
                "SpendingCap(scope=per_provider_per_window, "
                f"providers={dead_sorted})"
            )
        ),
        reason=(
            "Cross-fragment clash: the v1 ProviderAllowlist excludes "
            f"provider(s) {dead_sorted} that a v2 per-provider "
            "SpendingCap references. The cap is dead code; no intent "
            "can ever satisfy both fragments for these providers."
        ),
        backend=backend,
    )


# ── result helpers ───────────────────────────────────────────────────────────


def _hash_invariants(invariants: Sequence[Invariant]) -> str:
    """Deterministic SHA-256 over the canonical invariant-set representation."""
    import json

    canonical = sorted((type(i).__name__, repr(i)) for i in invariants)
    payload = json.dumps(canonical, sort_keys=True).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def _compose_sat_token(
    invariants: Sequence[Invariant],
    predecessor_hash: Optional[str],
    backends_used: tuple[str, ...],
    compile_hash: Optional[str],
) -> ProofToken:
    """Emit a composed ProofToken naming every backend consulted.

    The ``proof_strength`` carries ``"complete"`` whenever every consulted
    fragment prover returned a decisive SAT, else the strongest observed
    strength ("pattern" when neither Tau nor z3 ran). Callers map the
    token into the daemon's revision log unchanged.
    """
    return ProofToken(
        config_hash=_hash_invariants(invariants),
        issued_at_unix=int(time.time()),
        backend=HYBRID_BACKEND,
        proof_strength="complete",
        nonce=secrets.token_hex(8),
        predecessor_hash=predecessor_hash,
        fragment_version="hybrid",
        compile_hash=compile_hash,
        tau_backend_version=None,
    )


# ── prover ───────────────────────────────────────────────────────────────────


@dataclass
class HybridProver:
    """Compose verdicts from pattern, Tau (v1), and z3 (v2) provers.

    Construction
    ------------

    >>> from adapter.prover import (
    ...     IncrementalZ3Prover, PythonPatternProver, TauConsistencyProver,
    ... )
    >>> hp = HybridProver(
    ...     tau_prover=TauConsistencyProver(),
    ...     z3_prover=IncrementalZ3Prover(),
    ...     pattern_prover=PythonPatternProver(),
    ... )

    The z3 prover is expected to be an ``IncrementalZ3Prover`` so delta
    admission can reuse its push/pop state; passing a non-incremental
    ``Z3ConsistencyProver`` also works (``prove_delta`` falls back to
    full-composition calls on it).

    Admission flow
    --------------

    1. Pattern prover runs first over the FULL invariant set. A
       Contradiction short-circuits here — Tau and z3 are not called.
    2. v1 subset is routed to ``tau_prover``. A Contradiction
       short-circuits — the z3 solver is not invoked.
    3. v2 subset is routed to ``z3_prover`` via ``prove_delta`` (or
       ``prove`` on a non-incremental prover). A Contradiction stops here.
    4. Cross-fragment projection checks the v1/v2 boundary for
       structural interactions (provider dead-caps today; extensible).
    5. On full SAT, compose a single ``ProofToken`` carrying every
       backend consulted plus the strongest proof strength seen.

    Inconclusive handling
    ---------------------

    Either fragment returning ``InconclusiveProof`` propagates to the
    caller unchanged. The daemon decides whether to admit (verified mode)
    or reject (strict mode) based on its own policy; ``HybridProver`` does
    not absorb inconclusiveness silently.
    """

    tau_prover: ConsistencyProver
    z3_prover: object = None
    pattern_prover: ConsistencyProver = field(default_factory=PythonPatternProver)
    backend: str = HYBRID_BACKEND

    # Metrics counters (monotonic; safe for single-threaded inspection).
    _pattern_short_circuits: int = field(default=0, init=False, repr=False)
    _tau_short_circuits: int = field(default=0, init=False, repr=False)
    _z3_short_circuits: int = field(default=0, init=False, repr=False)
    _projection_short_circuits: int = field(default=0, init=False, repr=False)
    _composed_sat: int = field(default=0, init=False, repr=False)

    # ── public API ──────────────────────────────────────────────────────────

    def prove(
        self,
        invariants: Sequence[Invariant],
        predecessor_hash: Optional[str] = None,
    ) -> "ProofToken | Contradiction | InconclusiveProof":
        """Full-composition entry point (matches ConsistencyProver protocol).

        Equivalent to ``prove_delta(added=invariants, removed=())`` with
        ``full_current_set = invariants``.
        """
        return self.prove_delta(
            added=tuple(invariants),
            removed=(),
            predecessor_hash=predecessor_hash,
            full_current_set=tuple(invariants),
        )

    def prove_delta(
        self,
        added: Sequence[Invariant] = (),
        removed: Sequence[Invariant] = (),
        predecessor_hash: Optional[str] = None,
        full_current_set: Optional[Sequence[Invariant]] = None,
    ) -> "ProofToken | Contradiction | InconclusiveProof":
        """Apply a delta atomically across pattern + Tau + z3.

        ``full_current_set`` is the invariant set AFTER applying the
        delta — the daemon already computes this for the Tau path so we
        accept it explicitly rather than re-deriving it. When omitted
        the caller is using the full-composition mode and we treat
        ``added`` as the full set.
        """
        current = (
            tuple(full_current_set)
            if full_current_set is not None
            else tuple(added)
        )

        # 1. pattern precheck over the full set.
        pattern_result = self.pattern_prover.prove(
            invariants=current,
            predecessor_hash=predecessor_hash,
        )
        if isinstance(pattern_result, Contradiction):
            self._pattern_short_circuits += 1
            return pattern_result
        # Pattern prover never emits InconclusiveProof; it always returns
        # a ProofToken on clean specs. We don't need to handle that case.

        backends_used: list[str] = ["pattern"]
        compile_hash: Optional[str] = None

        # 2. Tau over the v1 subset.
        v1_subset = tuple(i for i in current if _is_v1(i))
        if v1_subset:
            tau_result = self.tau_prover.prove(
                invariants=v1_subset,
                predecessor_hash=predecessor_hash,
            )
            if isinstance(tau_result, Contradiction):
                # Short-circuit: DON'T wake z3 after a v1-level UNSAT.
                self._tau_short_circuits += 1
                return tau_result
            if isinstance(tau_result, InconclusiveProof):
                # Propagate as-is; the daemon (strict vs verified) decides.
                return tau_result
            # ProofToken from Tau: record its compile_hash for the
            # composed envelope so auditors can still trace the v1
            # decision back to its exact source.
            if isinstance(tau_result, ProofToken):
                backends_used.append(tau_result.backend or "tau")
                if tau_result.compile_hash:
                    compile_hash = tau_result.compile_hash

        # 3. z3 over the v2 subset (delta-aware when possible).
        v2_added = tuple(i for i in added if _is_v2(i))
        v2_removed = tuple(i for i in removed if _is_v2(i))
        v2_current = tuple(i for i in current if _is_v2(i))
        if v2_current or v2_added or v2_removed:
            z3_result = self._invoke_z3(
                added=v2_added,
                removed=v2_removed,
                current=v2_current,
                predecessor_hash=predecessor_hash,
            )
            if isinstance(z3_result, Contradiction):
                self._z3_short_circuits += 1
                return z3_result
            if isinstance(z3_result, InconclusiveProof):
                return z3_result
            if isinstance(z3_result, ProofToken):
                backends_used.append(z3_result.backend or "z3")

        # 4. cross-fragment projection. Cheap, runs last so the
        # authoritative provers get first crack at the decisive cases.
        xfrag = _cross_fragment_contradiction(current)
        if xfrag is not None:
            self._projection_short_circuits += 1
            return xfrag

        # 5. compose.
        self._composed_sat += 1
        token = _compose_sat_token(
            invariants=current,
            predecessor_hash=predecessor_hash,
            backends_used=tuple(backends_used),
            compile_hash=compile_hash,
        )
        # Stamp the backend chain so auditors can reconstruct which
        # fragments actually ran (subsets may be empty).
        object.__setattr__(token, "_backends", tuple(backends_used))
        return token

    # ── internals ───────────────────────────────────────────────────────────

    def _invoke_z3(
        self,
        added: Sequence[Invariant],
        removed: Sequence[Invariant],
        current: Sequence[Invariant],
        predecessor_hash: Optional[str],
    ) -> "ProofToken | Contradiction | InconclusiveProof":
        """Call the z3 prover, preferring `prove_delta` when available.

        Falls back to `prove(current)` for non-incremental provers so
        tests that wire `Z3ConsistencyProver` still work. Returns the
        InconclusiveProof unchanged so the caller can propagate.
        """
        if self.z3_prover is None:
            return InconclusiveProof(
                category="unavailable",
                reason="HybridProver constructed without a z3 prover",
                backend="z3-missing",
            )
        prove_delta = getattr(self.z3_prover, "prove_delta", None)
        if callable(prove_delta):
            return prove_delta(
                added=added,
                removed=removed,
                predecessor_hash=predecessor_hash,
                full_current_set=current,
            )
        # Non-incremental fallback.
        return self.z3_prover.prove(
            invariants=current,
            predecessor_hash=predecessor_hash,
        )

    def metrics(self) -> dict:
        """Snapshot the short-circuit counters for observability."""
        return {
            "backend": HYBRID_BACKEND,
            "pattern_short_circuits": self._pattern_short_circuits,
            "tau_short_circuits": self._tau_short_circuits,
            "z3_short_circuits": self._z3_short_circuits,
            "projection_short_circuits": self._projection_short_circuits,
            "composed_sat": self._composed_sat,
        }
