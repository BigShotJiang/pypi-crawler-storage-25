"""Policy narrator (v0.18.0).

Reverses the ``SUGGEST_PROMPT_TEMPLATE`` direction: given a sequence of
:class:`Invariant` objects, emits a plain-English description of what
the policy says. One sentence per rule, deterministic ordering.

This is the third leg of the NL round-trip loop:

    1. operator describes intent in English
       ``tau-x402-cage suggest --from-nl "..."``   emits LLM prompt
    2. LLM returns policy.yaml
       ``tau-x402-cage suggest --round-trip``      lints it (adapter/policy_linter)
    3. cage narrates the lint-clean policy back
       ``tau-x402-cage narrate <policy.yaml>``     uses this module

Surface
-------

    narrate_policy(invariants) -> str

    Empty policy -> ``"No rules declared."``
    One rule     -> single sentence.
    Many rules   -> one sentence per rule, joined with newlines.

Ordering
--------

Fragment v1 invariants come first, then fragment v2. Within each tier
the sentences sort by invariant class name alphabetically. This gives
a stable output the round-trip tests can diff against.

Design
------

* **Per-class narrators** — each invariant class has a dedicated
  ``_narrate_<class>`` function that takes the invariant and returns a
  single sentence. Mirrors :mod:`adapter.decision_explainer`'s describer
  pattern.
* **Pure function** — no I/O, no prover, no network. Feeds on the
  already-parsed ``Invariant`` dataclasses.
* **Immutable** — takes a ``Sequence[Invariant]`` and returns a ``str``.
  Never mutates the input.
* **Tier-aware** — relies on ``is_fragment_v2_invariant`` for v2
  classification so the ordering stays in lockstep with the
  cross-fragment linter.

Non-goals
---------

* Not a policy linter (that's :mod:`adapter.policy_linter`).
* Not a decision explainer (that's :mod:`adapter.decision_explainer`).
* Not a compiler (that's :mod:`adapter.tau_compiler` /
  :mod:`adapter.z3_compiler`).
"""
from __future__ import annotations

import json
from decimal import Decimal
from typing import Callable, Sequence

from adapter.invariants import (
    BurstVelocityCap,
    CounterpartyConstraint,
    Invariant,
    JurisdictionRule,
    MaxPerCall,
    MutualExclusion,
    ProviderAllowlist,
    RetryRateLimit,
    RollingWindowCap,
    SpendingCap,
)
from adapter.self_ref_policy import InstabilityGuard


#: Sentinel returned when the input is empty.
EMPTY_SENTENCE = "No rules declared."


# ── per-class narrators ──────────────────────────────────────────────────────


def _fmt_amount(amount: Decimal) -> str:
    """Format a Decimal as a plain-English money token (no trailing zeros)."""
    s = format(amount, "f")
    if "." in s:
        s = s.rstrip("0").rstrip(".")
    return s


def _fmt_set(items: Sequence[str]) -> str:
    """Render a sorted set like [a, b, c]."""
    return "[" + ", ".join(sorted(items)) + "]"


def _narrate_max_per_call(inv: MaxPerCall) -> str:
    return (
        f"No single payment exceeds {_fmt_amount(inv.max_amount)} "
        f"{inv.currency} (MaxPerCall)."
    )


def _narrate_spending_cap(inv: SpendingCap) -> str:
    amt = _fmt_amount(inv.max_amount)
    if inv.scope == "per_tx":
        return (
            f"No single transaction exceeds {amt} {inv.currency} "
            f"(SpendingCap, per_tx)."
        )
    window = inv.window_seconds or 0
    if inv.scope == "per_provider_per_window":
        provider = inv.provider or "the targeted provider"
        base = (
            f"Spend to {provider} capped at {amt} {inv.currency} in any "
            f"{window}-second window (SpendingCap, per_provider_per_window)."
        )
    else:
        base = (
            f"Cumulative spend capped at {amt} {inv.currency} in any "
            f"{window}-second window (SpendingCap, per_window)."
        )
    if inv.cross_provider_cap is not None:
        cross = _fmt_amount(inv.cross_provider_cap)
        base += (
            f" Cross-provider aggregate additionally capped at "
            f"{cross} {inv.currency} over the same window."
        )
    return base


def _narrate_provider_allowlist(inv: ProviderAllowlist) -> str:
    return (
        f"Providers limited to {_fmt_set(inv.providers)} (ProviderAllowlist)."
    )


def _narrate_retry_rate_limit(inv: RetryRateLimit) -> str:
    return (
        f"Retry-rate limited to one payment every {inv.min_gap_seconds} "
        f"seconds per provider+counterparty pair (RetryRateLimit)."
    )


def _narrate_burst_velocity_cap(inv: BurstVelocityCap) -> str:
    scope_label = (
        "summed across providers" if inv.cross_provider else "per provider"
    )
    tier = "cross-provider" if inv.cross_provider else "per-provider"
    return (
        f"Burst spend capped at {_fmt_amount(inv.max_per_window)} "
        f"{inv.currency} in any {inv.window_seconds}-second window, "
        f"{scope_label} (BurstVelocityCap, {tier})."
    )


def _narrate_rolling_window_cap(inv: RollingWindowCap) -> str:
    return (
        f"At most {inv.max_count} payments per {inv.group_by} in any "
        f"{inv.window_seconds}-second window (RollingWindowCap)."
    )


def _narrate_jurisdiction_rule(inv: JurisdictionRule) -> str:
    if not inv.additional_invariants:
        return (
            f"Declares jurisdiction {inv.jurisdiction} (JurisdictionRule, "
            f"no additional constraints)."
        )
    inner = "; ".join(
        _narrate_one(sub).rstrip(".")
        for sub in inv.additional_invariants
    )
    return (
        f"When jurisdiction is {inv.jurisdiction}, also enforce: {inner} "
        f"(JurisdictionRule)."
    )


def _narrate_mutual_exclusion(inv: MutualExclusion) -> str:
    return (
        f"Providers {_fmt_set(inv.group_a)} are mutually exclusive with "
        f"providers {_fmt_set(inv.group_b)} (MutualExclusion)."
    )


def _narrate_counterparty_constraint(inv: CounterpartyConstraint) -> str:
    parts: list[str] = []
    if inv.approved_ids:
        parts.append(f"approved set {_fmt_set(inv.approved_ids)}")
    if inv.sanctioned_ids:
        parts.append(f"sanctioned set {_fmt_set(inv.sanctioned_ids)}")
    if not parts:
        return (
            "Counterparty gate declared with no approved or sanctioned ids "
            "(CounterpartyConstraint, vacuous)."
        )
    return (
        f"Counterparty must satisfy "
        f"{' and '.join(parts)} (CounterpartyConstraint)."
    )


def _narrate_instability_guard(inv: InstabilityGuard) -> str:
    return (
        f"Payments to {inv.provider} are tightened to "
        f"{_fmt_amount(inv.tighten_to)} {inv.currency} after "
        f"{inv.reject_threshold} rejects in any "
        f"{inv.window_seconds}-second window, with "
        f"{inv.recovery_seconds}-second recovery (InstabilityGuard)."
    )


#: Dispatch table: class -> narrator. Keeps the per-class narrators
#: data-driven so adding a new invariant class is one edit, not N.
_NARRATORS: dict[type, Callable[[Invariant], str]] = {
    MaxPerCall: _narrate_max_per_call,
    SpendingCap: _narrate_spending_cap,
    ProviderAllowlist: _narrate_provider_allowlist,
    RetryRateLimit: _narrate_retry_rate_limit,
    BurstVelocityCap: _narrate_burst_velocity_cap,
    RollingWindowCap: _narrate_rolling_window_cap,
    JurisdictionRule: _narrate_jurisdiction_rule,
    MutualExclusion: _narrate_mutual_exclusion,
    CounterpartyConstraint: _narrate_counterparty_constraint,
    InstabilityGuard: _narrate_instability_guard,
}


def _narrate_one(inv: Invariant) -> str:
    """Dispatch a single invariant to its narrator.

    Uses ``type(inv)`` rather than ``isinstance`` so a subclass never
    silently borrows a sibling's sentence — adding an invariant class
    must surface in the dispatch table.
    """
    narrator = _NARRATORS.get(type(inv))
    if narrator is None:
        return (
            f"{inv.name} rule declared (no narrator registered; see "
            f"docs/policy_authoring.md)."
        )
    return narrator(inv)


# ── public surface ───────────────────────────────────────────────────────────


#: Fragment-tier ordering. v1 invariants narrate first so the operator
#: reads the simple "no-over-the-line" rules before the windowed /
#: temporal ones. Mirrors :mod:`adapter.policy_linter`'s fragment split.
_V2_CLASSES: tuple[type, ...] = (
    BurstVelocityCap,
    RollingWindowCap,
    RetryRateLimit,
    InstabilityGuard,
)


def _tier(inv: Invariant) -> int:
    """Return 0 for fragment v1, 1 for fragment v2 (for stable ordering).

    Kept local so we do not import ``z3_compiler`` — the narrator is
    pure string assembly and must run even when z3 is absent. The v2
    set is small and stable (four classes).
    """
    return 1 if isinstance(inv, _V2_CLASSES) else 0


def _order_key(inv: Invariant) -> tuple:
    """Sort key: (tier, class_name).

    SpendingCap spans both fragments: per_tx is v1, per_window* is v2.
    We treat the windowed case as v2 so the tier split reflects what the
    linter / prover sees.
    """
    if isinstance(inv, SpendingCap) and inv.scope != "per_tx":
        return (1, inv.name)
    return (_tier(inv), inv.name)


def narrate_policy(invariants: Sequence[Invariant]) -> str:
    """Produce a plain-English description of a list of invariants.

    Args:
        invariants: invariant instances (typically
            ``LoadedPolicy.invariants``).

    Returns:
        A string. Empty input yields :data:`EMPTY_SENTENCE`; one rule
        yields a single sentence; many rules yield one sentence per
        line in tier + alphabetical order.
    """
    if not invariants:
        return EMPTY_SENTENCE
    ordered = sorted(invariants, key=_order_key)
    return "\n".join(_narrate_one(inv) for inv in ordered)


def narrate_policy_markdown(invariants: Sequence[Invariant]) -> str:
    """Same as :func:`narrate_policy` but bulleted for Markdown contexts.

    Empty input still yields :data:`EMPTY_SENTENCE` (caller decides
    whether to wrap it).
    """
    if not invariants:
        return EMPTY_SENTENCE
    ordered = sorted(invariants, key=_order_key)
    return "\n".join(f"- {_narrate_one(inv)}" for inv in ordered)


def narrate_policy_json(invariants: Sequence[Invariant]) -> str:
    """Machine-readable JSON form: one object per rule.

    Each entry carries ``class``, ``tier`` (``"v1"`` / ``"v2"``), and
    ``sentence``. Kept here (rather than in the CLI) so the MCP tool
    and the CLI emit byte-identical JSON.
    """
    if not invariants:
        return json.dumps(
            {"sentences": [], "summary": EMPTY_SENTENCE},
            sort_keys=True,
            indent=2,
        )
    ordered = sorted(invariants, key=_order_key)
    entries = []
    for inv in ordered:
        tier = "v2" if _order_key(inv)[0] == 1 else "v1"
        entries.append({
            "class": inv.name,
            "tier": tier,
            "sentence": _narrate_one(inv),
        })
    summary = "\n".join(e["sentence"] for e in entries)
    return json.dumps(
        {"sentences": entries, "summary": summary},
        sort_keys=True,
        indent=2,
    )


__all__ = [
    "EMPTY_SENTENCE",
    "narrate_policy",
    "narrate_policy_markdown",
    "narrate_policy_json",
]
