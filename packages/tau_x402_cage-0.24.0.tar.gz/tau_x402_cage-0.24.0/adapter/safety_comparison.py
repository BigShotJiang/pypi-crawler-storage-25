"""Safety comparison mode: make the risk the cage prevents *visible*.

Motivation
----------
A permit/reject stream answers "what did the system do?" but not "what
would have happened without it?". Conversion to paid tiers, trust in the
system, and agent-discovery all hinge on answering the counterfactual.
This module computes that counterfactual in two shapes:

* :func:`compare_verdict` — per-intent comparison. Runs the intent through
  the active registry (the real verdict) AND through an empty registry
  (the "without_system" baseline). Reports the delta with the specific
  rule that fired and the cash amount that was prevented.
* :func:`aggregate_risk_prevented` — rolling-window rollup. Walks the
  daemon's permit/reject history and produces per-currency totals of
  risk prevented, top-N providers by risk, and top-N rules that fired.

Design
------
The baseline for the counterfactual is the **empty registry**: an agent
with zero declared invariants would permit everything. This is the
strongest claim we can make today and maps cleanly to "without the
cage". Richer baselines (per-tenant "without this rule", last month's
policy) are left as schema-allowed future extensions; every
``ComparisonReport`` field is populated defensively so adding a
baseline variant is additive.

Immutability
------------
Every result is a frozen dataclass. Inputs are treated as read-only
iterables; we never mutate caller-supplied stores.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation
from typing import Any, Dict, Iterable, Literal, Mapping, Optional, Sequence

from adapter.invariants import Invariant, Violation
from adapter.payment_intent_matcher import PaymentIntent
from adapter.x402_registry import X402Registry


# ── dataclasses ──────────────────────────────────────────────────────────────


Outcome = Literal["permit", "reject"]


@dataclass(frozen=True)
class ComparisonReport:
    """Delta between "with the cage" and "without the cage" for one intent.

    Attributes:
        with_system: what the active registry decided for this intent.
        without_system: what an empty registry would have decided. Today
            always ``"permit"`` — an empty registry never rejects. The
            schema allows future baselines ("without this rule",
            "previous policy version") to return ``"reject"`` too; the
            field is kept literal-typed so downstream consumers can
            start reasoning about it without a wire-format bump.
        risk_reason: plain-English description of the rule that fired
            on the "with system" side. ``None`` when no rule fired.
        risk_amount: cash amount that was prevented. This is the
            intent's own amount when the cage rejected; ``None``
            otherwise. Denominated in the intent's own currency —
            see ``risk_currency`` for the currency code.
        risk_currency: currency code of ``risk_amount``. ``None`` when
            ``risk_amount`` is ``None``.
        rule_id: rule_id of the invariant that fired, for wiring
            into structured downstream consumers.
        invariant_class: class name of the invariant that fired
            (e.g. ``"SpendingCap"``, ``"ProviderAllowlist"``).
        projected_spend_next_n_seconds: forward projection of spend
            under the empty-registry baseline, keyed by horizon
            (30, 60, 300 seconds). When :mod:`adapter.runtime_guard`
            is importable we delegate to its ``project_spend`` helper;
            otherwise we fall back to a straight linear extrapolation
            from the supplied recent history. Empty dict on permit
            / no-signal.
        estimated_loss_blocked: projected value the cage will prevent
            over the ``projected_spend_next_n_seconds[60]`` horizon
            IF this rule would keep firing. ``None`` on permit or when
            the projection is zero. Denominated in ``risk_currency``.
    """

    with_system: Outcome
    without_system: Outcome
    risk_reason: Optional[str] = None
    risk_amount: Optional[Decimal] = None
    risk_currency: Optional[str] = None
    rule_id: Optional[str] = None
    invariant_class: Optional[str] = None
    projected_spend_next_n_seconds: Mapping[int, Decimal] = field(
        default_factory=dict
    )
    estimated_loss_blocked: Optional[Decimal] = None

    def to_wire(self) -> dict[str, Any]:
        """Serialise to a JSON-safe dict for daemon wire transport."""
        return {
            "with_system": self.with_system,
            "without_system": self.without_system,
            "risk_reason": self.risk_reason,
            "risk_amount": (
                str(self.risk_amount) if self.risk_amount is not None else None
            ),
            "risk_currency": self.risk_currency,
            "rule_id": self.rule_id,
            "invariant_class": self.invariant_class,
            "projected_spend_next_n_seconds": {
                str(k): str(v)
                for k, v in sorted(self.projected_spend_next_n_seconds.items())
            },
            "estimated_loss_blocked": (
                str(self.estimated_loss_blocked)
                if self.estimated_loss_blocked is not None
                else None
            ),
        }


@dataclass(frozen=True)
class ProviderRisk:
    """Per-provider rollup for the risk-prevented dashboard."""

    provider: str
    count: int
    value_by_currency: Mapping[str, Decimal] = field(default_factory=dict)

    def to_wire(self) -> dict[str, Any]:
        return {
            "provider": self.provider,
            "count": self.count,
            "value_by_currency": {
                k: str(v) for k, v in self.value_by_currency.items()
            },
        }


@dataclass(frozen=True)
class RuleRisk:
    """Per-rule rollup for the risk-prevented dashboard."""

    rule_id: str
    count: int
    value_by_currency: Mapping[str, Decimal] = field(default_factory=dict)

    def to_wire(self) -> dict[str, Any]:
        return {
            "rule_id": self.rule_id,
            "count": self.count,
            "value_by_currency": {
                k: str(v) for k, v in self.value_by_currency.items()
            },
        }


@dataclass(frozen=True)
class RiskAggregate:
    """Aggregate view: risk prevented over a rolling time window.

    Attributes:
        window_seconds: the window used to compute the aggregate. ``0``
            means "all history".
        prevented_count: total number of rejects in the window.
        prevented_value_by_currency: sum of reject amounts by currency.
            Unlike ``prevented_count`` this is currency-aware because
            agents may route through multiple rails with different
            stablecoins; summing USDC and USDT would be wrong.
        top_providers: top-N providers ranked by cumulative prevented
            value (USD-equivalent not computed; we rank by count when
            currencies mix).
        top_rules: top-N rules by prevented count.
        now_unix: the reference timestamp used for window filtering,
            or ``None`` when ``window_seconds=0``.
    """

    window_seconds: int
    prevented_count: int
    prevented_value_by_currency: Mapping[str, Decimal]
    top_providers: tuple[ProviderRisk, ...]
    top_rules: tuple[RuleRisk, ...]
    now_unix: Optional[int] = None

    def to_wire(self) -> dict[str, Any]:
        return {
            "window_seconds": self.window_seconds,
            "prevented_count": self.prevented_count,
            "prevented_value_by_currency": {
                k: str(v) for k, v in self.prevented_value_by_currency.items()
            },
            "top_providers": [p.to_wire() for p in self.top_providers],
            "top_rules": [r.to_wire() for r in self.top_rules],
            "now_unix": self.now_unix,
        }


# ── core operations ──────────────────────────────────────────────────────────


def compare_verdict(
    intent: PaymentIntent,
    active_registry: X402Registry,
    history: Iterable[PaymentIntent] = (),
    rejects: Iterable[PaymentIntent] = (),
) -> ComparisonReport:
    """Compute the with-system / without-system counterfactual for one intent.

    The "with" side runs the intent through the active registry using
    the same logic ``_op_check_payment`` uses. The "without" side is
    the empty-registry baseline — currently always permit, because an
    empty X402Registry has no rules to fire.

    v0.17.0 extension: the report also carries a forward-projected view
    of spend under the empty-registry baseline. When
    :mod:`adapter.runtime_guard` is importable, its ``project_spend``
    helper is used; otherwise we fall back to a deterministic linear
    extrapolation from the most-recent 60s of history.

    Args:
        intent: the payment intent under evaluation.
        active_registry: the registry holding the tenant's declared rules.
        history: previously-permitted intents in this session. Needed
            so rolling-window / cumulative-spend rules evaluate
            correctly against the same history the daemon saw.
        rejects: previously-rejected intents. RetryRateLimit consults
            this; every other invariant ignores it.
    """
    history_tuple = tuple(history)
    rejects_tuple = tuple(rejects)
    violation: Optional[Violation] = active_registry.check_payment(
        intent, history_tuple, rejects_tuple
    )
    projections = _project_forward(intent, history_tuple)
    if violation is None:
        # Permit: no risk to block, but the projection still travels on
        # the report so dashboards can surface "at current velocity you
        # will spend X in the next N seconds" whether or not the cage
        # fired. Keep estimated_loss_blocked None — a permit blocks
        # nothing.
        return ComparisonReport(
            with_system="permit",
            without_system="permit",
            projected_spend_next_n_seconds=projections,
            estimated_loss_blocked=None,
        )
    # Reject: the cage prevented this spend. Record the whole intent
    # amount as the prevented value — that's the money that would have
    # moved under the empty-registry counterfactual.
    rule_id = violation.rule_id
    invariant_class = _find_invariant_class(active_registry, rule_id)
    # "Estimated loss blocked" on a reject is the 60s-projected spend
    # plus the current intent's amount — the intuition being "if this
    # rule keeps firing, here's what the cage will have prevented one
    # minute from now". Falls back to the intent amount alone when the
    # projection is empty.
    projected_60 = projections.get(60, Decimal("0"))
    loss_estimate = intent.amount + projected_60
    return ComparisonReport(
        with_system="reject",
        without_system="permit",
        risk_reason=violation.reason_text,
        risk_amount=intent.amount,
        risk_currency=intent.currency,
        rule_id=rule_id,
        invariant_class=invariant_class,
        projected_spend_next_n_seconds=projections,
        estimated_loss_blocked=loss_estimate,
    )


def _project_forward(
    intent: PaymentIntent,
    history: Sequence[PaymentIntent],
) -> Dict[int, Decimal]:
    """Project spend under the empty-registry baseline for 30 / 60 / 300s.

    Delegates to :mod:`adapter.runtime_guard` when available (that
    module owns the richer velocity / burst-aware model). Absent the
    module we fall back to a straight linear extrapolation: if the
    caller has been spending ``X`` over the last 60 seconds,
    ``project(N)`` is ``X * N / 60``.

    Returns a dict keyed by horizon in seconds (30, 60, 300). Empty
    dict when there's no recent history to extrapolate from — callers
    then read "no signal" rather than a fake zero.
    """
    # First try the dedicated helper so we inherit its burst-awareness
    # when the other agent lands it. Duck-typed on purpose: we don't
    # want a hard import cycle against a module this agent doesn't own.
    try:
        from adapter.runtime_guard import project_spend  # type: ignore[attr-defined]
    except Exception:  # noqa: BLE001 — any import failure falls back to linear
        project_spend = None  # type: ignore[assignment]
    if callable(project_spend):
        try:
            result = project_spend(intent, history, horizons=(30, 60, 300))
        except Exception:  # noqa: BLE001 — never let a helper crash the report
            result = None
        if isinstance(result, Mapping):
            out: Dict[int, Decimal] = {}
            for k, v in result.items():
                try:
                    out[int(k)] = Decimal(str(v))
                except (InvalidOperation, TypeError, ValueError):
                    continue
            if out:
                return out
    # Linear-extrapolation fallback. Walk the last 60s of *matching
    # currency* history. Zero history → empty projection.
    if not history:
        return {}
    window = 60
    cutoff = intent.timestamp_unix - window
    recent = [
        p for p in history
        if p.currency == intent.currency and p.timestamp_unix >= cutoff
    ]
    if not recent:
        return {h: Decimal("0") for h in (30, 60, 300)}
    total = sum((p.amount for p in recent), Decimal("0"))
    rate_per_second = total / Decimal(window)
    return {
        horizon: (rate_per_second * Decimal(horizon))
        for horizon in (30, 60, 300)
    }


def aggregate_risk_prevented(
    history: Sequence[PaymentIntent],
    rejects: Sequence[PaymentIntent],
    verdicts: Sequence[Mapping[str, Any]] = (),
    window_seconds: int = 0,
    now_unix: Optional[int] = None,
    top_n: int = 5,
) -> RiskAggregate:
    """Walk the daemon's history + verdict stream; return the rolled-up view.

    Args:
        history: permit stream (not used for risk rollup; kept in the
            signature so callers can pass the same pair the daemon
            holds without reshuffling. Future richer baselines may
            compare permit counts to reject counts.)
        rejects: reject stream — the ``PaymentIntent``\\ s the cage
            actually refused. These carry the intent amount and
            currency.
        verdicts: verdict-summary stream (``kind="verdict"`` in the
            history store). Each entry looks like ``{"verdict":
            "reject", "rule_id": "...", "intent": {"amount": "500",
            "currency": "USDC", "provider": "...", ...}}``. When
            supplied we rank rules + providers from this stream
            (richer than walking ``rejects`` alone because
            ``rule_id`` is only in the verdict record). When empty
            we fall back to the rejects stream for value + provider
            counts and leave rule ranking empty.
        window_seconds: filter to the most recent N seconds. ``0`` or
            ``None`` means all history. Filtering is by entry
            ``timestamp_unix`` relative to ``now_unix`` (defaults to
            max timestamp in history, matching the replay op's
            deterministic-window behaviour).
        now_unix: reference point for window filtering. Defaults to
            the newest ``timestamp_unix`` in the rejects stream.
        top_n: cap on ``top_providers`` / ``top_rules`` list size.

    Currency awareness: amounts are bucketed by currency because
    summing USDC + USDT would produce a nonsense total. The wire shape
    reflects this by returning a dict keyed by currency code.
    """
    del history  # reserved for future baselines; see docstring
    # Normalise the window filter. The rejects list is in oldest-first
    # order; we keep that convention and slice on timestamp.
    cutoff: Optional[int] = None
    if window_seconds and window_seconds > 0:
        if now_unix is None and rejects:
            now_unix = max(r.timestamp_unix for r in rejects)
        if now_unix is not None:
            cutoff = now_unix - window_seconds

    filtered_rejects: list[PaymentIntent] = []
    for r in rejects:
        if cutoff is not None and r.timestamp_unix < cutoff:
            continue
        filtered_rejects.append(r)

    # Prevented value (by currency) — summing across different tokens
    # is a semantic error so we bucket.
    prevented_value_by_currency: dict[str, Decimal] = {}
    provider_counts: dict[str, int] = {}
    provider_values: dict[str, dict[str, Decimal]] = {}
    for r in filtered_rejects:
        prevented_value_by_currency[r.currency] = (
            prevented_value_by_currency.get(r.currency, Decimal("0")) + r.amount
        )
        provider_counts[r.provider] = provider_counts.get(r.provider, 0) + 1
        bucket = provider_values.setdefault(r.provider, {})
        bucket[r.currency] = bucket.get(r.currency, Decimal("0")) + r.amount

    # Rule ranking lives in the verdict-summary stream (rule_id is not
    # on the PaymentIntent itself). Walk the filtered verdict stream
    # and bucket.
    rule_counts: dict[str, int] = {}
    rule_values: dict[str, dict[str, Decimal]] = {}
    for v in verdicts:
        if v.get("verdict") != "reject":
            continue
        intent_d = v.get("intent") or {}
        ts = intent_d.get("timestamp_unix")
        if cutoff is not None and ts is not None and int(ts) < cutoff:
            continue
        rule_id = v.get("rule_id") or "(unattributed)"
        try:
            amount = Decimal(str(intent_d.get("amount", "0")))
        except Exception:  # noqa: BLE001 — defensive against malformed stream rows
            amount = Decimal("0")
        currency = str(intent_d.get("currency", ""))
        rule_counts[rule_id] = rule_counts.get(rule_id, 0) + 1
        bucket = rule_values.setdefault(rule_id, {})
        if currency:
            bucket[currency] = bucket.get(currency, Decimal("0")) + amount

    top_providers = tuple(
        ProviderRisk(
            provider=name,
            count=count,
            value_by_currency=dict(provider_values.get(name, {})),
        )
        for name, count in sorted(
            provider_counts.items(),
            key=lambda item: (-item[1], item[0]),
        )[:top_n]
    )
    top_rules = tuple(
        RuleRisk(
            rule_id=rid,
            count=count,
            value_by_currency=dict(rule_values.get(rid, {})),
        )
        for rid, count in sorted(
            rule_counts.items(),
            key=lambda item: (-item[1], item[0]),
        )[:top_n]
    )

    return RiskAggregate(
        window_seconds=window_seconds,
        prevented_count=len(filtered_rejects),
        prevented_value_by_currency=prevented_value_by_currency,
        top_providers=top_providers,
        top_rules=top_rules,
        now_unix=now_unix,
    )


# ── helpers ─────────────────────────────────────────────────────────────────


_RULE_ID_TO_CLASS = {
    "max_per_call": "MaxPerCall",
    "spending_cap_per_tx": "SpendingCap",
    "spending_cap_per_window": "SpendingCap",
    "spending_cap_per_provider_per_window": "SpendingCap",
    "provider_allowlist": "ProviderAllowlist",
    "retry_rate_limit": "RetryRateLimit",
    "rolling_window_cap_provider": "RollingWindowCap",
    "rolling_window_cap_counterparty": "RollingWindowCap",
    "rolling_window_cap_global": "RollingWindowCap",
    "mutual_exclusion": "MutualExclusion",
    "counterparty_sanctioned": "CounterpartyConstraint",
    "counterparty_not_approved": "CounterpartyConstraint",
}


def _find_invariant_class(
    registry: X402Registry, rule_id: Optional[str]
) -> Optional[str]:
    """Map a rule_id to the invariant class name that emitted it.

    First tries the static map (rule_ids are stable enum-ish strings
    per invariant class). Falls back to an empty string so the wire
    shape still serialises. Also handles jurisdiction-prefixed ids
    of the shape ``jurisdiction_<code>.<inner_rule_id>``.
    """
    if rule_id is None:
        return None
    # JurisdictionRule wraps inner rule_ids. Strip the prefix for
    # class lookup.
    if rule_id.startswith("jurisdiction_"):
        return "JurisdictionRule"
    return _RULE_ID_TO_CLASS.get(rule_id)


# ── v0.23.0 tightening-effect block ──────────────────────────────────────────


#: Limit-name → human-readable rationale key. When a baseline differs
#: from the tightened value, the block names the trigger class-of-reason
#: in plain English so the compare output is grep-friendly.
_TIGHTENING_RATIONALE_BY_LIMIT: Mapping[str, str] = {
    "max_requests": "retry density > 10/min",
    "retry_allowance": "retry density > 10/min",
    "cooldown_seconds": "identical requests x 4",
    "min_gap_seconds": "identical requests x 4",
    "backoff_seconds": "identical requests x 4",
    "max_amount": "velocity 3x ema",
    "max_per_call": "velocity 3x ema",
    "spend_cap": "velocity 3x ema",
    "cap": "velocity 3x ema",
    "per_tx_cap": "velocity 3x ema",
}


def build_tightening_effect(
    *,
    baseline: Mapping[str, Any],
    tightened: Mapping[str, Any],
    trigger: Optional[str] = None,
) -> Optional[Dict[str, Any]]:
    """Compose the baseline-vs-tightened-vs-rationale block for ``compare``.

    Pure function. Returns ``None`` when ``tightened`` is empty (adaptive
    tightening is inactive) so downstream consumers can branch on
    presence. When active the returned shape matches the brief:

        {
            "baseline":  {"max_requests": 10, "cooldown_s": 6,  ...},
            "tightened": {"max_requests": 3,  "cooldown_s": 45, ...},
            "rationale": {"max_requests": "retry density > 10/min",
                          "cooldown_s": "identical requests x 4", ...}
        }

    The rationale is populated only for keys that actually differ
    between baseline and tightened. Unknown limit names pass through
    unchanged (no rationale attached) — we never fabricate phrasing.

    When ``trigger`` is supplied it overrides the per-key rationale for
    every differing key that doesn't have a dedicated phrase. This lets
    callers that know exactly which trigger fired attach the triggering
    reason to every clamp, rather than relying on the per-key map.
    """
    if not tightened:
        return None
    baseline_dict: Dict[str, Any] = {
        k: (str(v) if isinstance(v, Decimal) else v)
        for k, v in baseline.items()
    }
    tightened_dict: Dict[str, Any] = {
        k: (str(v) if isinstance(v, Decimal) else v)
        for k, v in tightened.items()
    }
    rationale: Dict[str, str] = {}
    for key, tight_value in tightened_dict.items():
        base_value = baseline_dict.get(key)
        if base_value == tight_value:
            continue
        phrase = _TIGHTENING_RATIONALE_BY_LIMIT.get(key)
        if phrase is None and trigger:
            # Fall back to the trigger label if we have one; this keeps
            # the rationale column populated without inventing phrasing.
            phrase = str(trigger).replace("_", " ")
        if phrase is None:
            continue
        rationale[key] = phrase
    return {
        "baseline": baseline_dict,
        "tightened": tightened_dict,
        "rationale": rationale,
    }
