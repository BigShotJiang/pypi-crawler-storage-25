"""Temporary stubs for agent 1's Guaranteed Mode exports.

TODO: remove after agent 1 merges ``adapter.guaranteed_errors``,
``adapter.guaranteed_language``, and ``adapter.guaranteed_totality`` onto
master. This module exists only so agent 2's (prover) worktree can build
and test against a stable surface before agent 1's branch lands.

The shapes here deliberately mirror the public contract we expect agent 1
to ship: ``GuaranteedFailureCode`` is an enum with the codes we actually
produce in ``adapter.guaranteed_prover``, ``GuaranteedFailure`` is an
immutable dataclass, and ``validate_totality`` returns a
``TotalityCheckResult`` with ``is_total`` / ``reasons``.

When agent 1's modules appear on master the ``try/except ImportError``
guards in ``adapter.guaranteed_prover`` and
``adapter.guaranteed_proof_artifact`` will prefer the real implementations
and leave these stubs untouched.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Mapping, Optional, Sequence


class GuaranteedFailureCode(str, Enum):
    """Why a Guaranteed Mode prove attempt was rejected.

    The enum values are strings so they serialise cleanly through JSON
    without a custom encoder. Every code here MUST map to exactly one
    failure path in ``adapter.guaranteed_prover.GuaranteedProver.prove``.
    """

    TAU_TOTALITY_FAILED = "TAU_TOTALITY_FAILED"
    TAU_UNSUPPORTED_CONSTRUCT = "TAU_UNSUPPORTED_CONSTRUCT"
    TAU_COMPILE_INCOMPLETE = "TAU_COMPILE_INCOMPLETE"
    TAU_PROOF_TIMEOUT = "TAU_PROOF_TIMEOUT"
    TAU_PROOF_INCONCLUSIVE = "TAU_PROOF_INCONCLUSIVE"
    TAU_BACKEND_UNAVAILABLE = "TAU_BACKEND_UNAVAILABLE"
    TAU_PROVER_INTERNAL_ERROR = "TAU_PROVER_INTERNAL_ERROR"


@dataclass(frozen=True)
class GuaranteedFailure:
    """Structured rejection payload emitted when prove cannot proceed.

    Immutable; mirror of the agent-1 type. Callers downstream treat a
    ``GuaranteedFailure`` as a decisive "no" -- there is no retry, no
    silent fallback.
    """

    code: GuaranteedFailureCode | str
    message: str
    details: Optional[Mapping[str, Any]] = None


@dataclass(frozen=True)
class TotalityCheckResult:
    """Return type of ``validate_totality``.

    Fields:
        is_total: ``True`` iff every invariant in the policy is total
            under the language-tier semantics.
        reasons: per-invariant explanations for why totality failed (empty
            tuple on success).
    """

    is_total: bool
    reasons: tuple[str, ...] = field(default_factory=tuple)


def validate_totality(policy: Sequence[Any]) -> TotalityCheckResult:
    """Stub totality gate. Always returns ``is_total=True``.

    Agent 1's real implementation rejects invariants whose guarded form
    is not total (e.g. ``SpendingCap(per_provider_per_window)`` with a
    missing window). The prover treats a ``False`` result as the hard
    gate before compilation.
    """

    return TotalityCheckResult(is_total=True, reasons=())


class _GuaranteedLanguageStub:
    """Minimal ``GuaranteedLanguage`` stand-in exposing ``describe()``.

    Carries a language-tier version so ``GuaranteedProofArtifact`` can
    stamp the tier on every artifact even before agent 1 ships the real
    class.
    """

    _VERSION = "stub-0.0.0"

    @classmethod
    def describe(cls) -> dict[str, Any]:
        return {
            "version": cls._VERSION,
            "fragment": "v1",
            "totality": "stub",
        }


GuaranteedLanguage = _GuaranteedLanguageStub
