"""Strict mutation contract with risk exposure (v0.13.0).

Core Principle 1 of the x402 safety layer: **correctness under mutation**.
Every admission / retraction / update must be proved or rejected, with no
unsafe intermediate state visible to callers. The previous ``_apply_revision``
path already honoured that invariant; this module promotes it to a
first-class, auditable function and attaches the risk metadata callers need
to decide whether to admit, queue, or escalate a proposed change.

Contract
--------

``apply_revision_delta_strict`` takes the current registry, a structured
``{added, removed}`` delta, and a bag of provers. It returns a frozen
``MutationResult`` with exactly one of two outcomes:

  * ``outcome == "admitted"``: the mutation was decisive (no contradiction,
    no inconclusive under strict mode). The ``proof_token`` field carries
    the admitting token; the registry returned to the caller is safe to
    swap in.
  * ``outcome == "rejected"``: the proof ladder either found a
    contradiction or returned inconclusive under strict mode. The caller
    MUST NOT mutate the registry; the old registry is the source of truth.

Either way the result carries:

  * ``mutation_risk``  -- "low" | "medium" | "high", per the classifier below.
  * ``affected_scope`` -- structured projection of which providers,
    counterparties, currencies, fragment classes, and rule classes the
    delta touches in the context of the current active set.
  * ``would_break_without_proof`` -- True iff the pattern prover on its
    own (no Tau, no z3) would have caught this. Reads as "what the prover
    caught that a typo-check would have missed". Always False on admit.

Risk taxonomy
-------------

  * **high**: the delta *would* break composition (contradiction under
    pattern), OR touches > 20% of active invariants, OR removes a rule
    that other rules reference through a shared variable.
  * **medium**: delta touches 5-20% of active invariants, OR prover
    returned InconclusiveProof under non-strict mode (caller can still
    admit but must observe the annotation), OR touches a fragment-v2
    temporal invariant.
  * **low**: purely additive, touches < 5% of active invariants, passes
    the pattern precheck, and (where applicable) passes the authoritative
    backend without drama.

The split is load-bearing for the "safety layer" positioning:
classification is made from the delta alone plus the cheap pattern
probe, so a caller can ask "what's the risk of admitting this" without
paying the Tau or z3 cost.

Refusal-to-mutate invariant (A2)
--------------------------------

If ``apply_revision_delta_strict`` returns ``outcome == "rejected"``,
the caller MUST NOT advance the registry. The daemon's ``_apply_revision``
wrappers delegate to this function and only swap the registry reference
inside the registry lock when ``outcome == "admitted"``. Every existing
strict-mode admission test covers the same invariant at the daemon
level; the tests in ``tests/test_mutation_safety.py`` cover it at this
module's boundary.
"""
from __future__ import annotations

from dataclasses import dataclass, field, replace
from decimal import Decimal
from typing import (
    Any,
    Iterable,
    Literal,
    Optional,
    Protocol,
    Sequence,
    Tuple,
)

from adapter.invariants import (
    CounterpartyConstraint,
    Invariant,
    JurisdictionRule,
    MaxPerCall,
    MutualExclusion,
    ProviderAllowlist,
    RetryRateLimit,
    RollingWindowCap,
    SpendingCap,
)
from adapter.proof_report import ContradictionReport, InconclusiveReport
from adapter.prover import (
    ConsistencyProver,
    Contradiction,
    InconclusiveProof,
    ProofToken,
    PythonPatternProver,
)
from adapter.x402_registry import X402Registry


# ── public types ─────────────────────────────────────────────────────────────


#: Literal alias for the risk taxonomy. Kept as a small set so the wire shape
#: is easy to pattern-match on in downstream consumers.
RiskLevel = Literal["low", "medium", "high"]


@dataclass(frozen=True)
class RevisionDelta:
    """Structured description of a proposed mutation.

    ``added`` are the invariants to be declared; ``removed`` are the ones to
    be retracted. An ``update`` op passes both sides populated. Order is
    preserved so downstream diff rendering is deterministic.
    """

    added: Tuple[Invariant, ...] = ()
    removed: Tuple[Invariant, ...] = ()

    @classmethod
    def from_mapping(cls, data: Any) -> "RevisionDelta":
        """Accept either a ``RevisionDelta`` or a plain mapping; normalise to a frozen value.

        Mapping keys ``added`` / ``removed`` accept any iterable of
        ``Invariant`` instances. The helper keeps daemon call sites light.
        """
        if isinstance(data, RevisionDelta):
            return data
        if data is None:
            return cls()
        added = tuple(data.get("added", ()) or ())
        removed = tuple(data.get("removed", ()) or ())
        return cls(added=added, removed=removed)


@dataclass(frozen=True)
class ProverChain:
    """Bag of provers threaded through ``apply_revision_delta_strict``.

    This is the minimum surface: a pattern prover (always cheap, always
    available) and optional Tau / z3 authoritative backends. The shape
    mirrors the daemon's existing ``_apply_revision`` chain so wiring the
    new central path up is a pure refactor — no prover is constructed
    inside this module.

    Fields:
        pattern  : the precheck. Required. If omitted we construct a
                   ``PythonPatternProver`` so callers that just want the
                   low-risk-classifier path don't have to reach for the
                   import.
        tau      : fragment-v1 authoritative prover (optional).
        z3       : fragment-v2 authoritative prover (optional).
        mode     : prover mode — "compat" | "verified" | "strict".
    """

    pattern: ConsistencyProver = field(default_factory=PythonPatternProver)
    tau: Optional[ConsistencyProver] = None
    z3: Optional[Any] = None  # IncrementalZ3Prover; avoid the import cost here
    mode: str = "strict"


@dataclass(frozen=True)
class MutationResult:
    """The atomic, auditable result of ``apply_revision_delta_strict``.

    Admitted outcomes carry ``proof_token``; rejected outcomes carry one of
    ``contradiction`` or ``inconclusive``. The other narrative fields are
    always populated so callers never branch on Optional to read risk.
    """

    outcome: Literal["admitted", "rejected"]
    mutation_risk: RiskLevel
    affected_scope: dict = field(default_factory=dict)
    would_break_without_proof: bool = False
    #: Only present on admit.
    revision_id: Optional[str] = None
    proof_token: Optional[ProofToken] = None
    #: The candidate registry, if admitted. None on reject (registry unchanged).
    candidate_registry: Optional[X402Registry] = None
    #: On reject: exactly one of these is populated.
    contradiction: Optional[ContradictionReport] = None
    inconclusive: Optional[InconclusiveReport] = None

    def to_dict(self) -> dict:
        """JSON-safe projection. Keeps the wire shape stable across patches."""
        d: dict[str, Any] = {
            "outcome": self.outcome,
            "mutation_risk": self.mutation_risk,
            "affected_scope": dict(self.affected_scope),
            "would_break_without_proof": self.would_break_without_proof,
        }
        if self.revision_id is not None:
            d["revision_id"] = self.revision_id
        if self.proof_token is not None:
            d["proof_token"] = self.proof_token.to_dict()
        if self.contradiction is not None:
            d["contradiction"] = self.contradiction.to_dict()
        if self.inconclusive is not None:
            d["inconclusive"] = self.inconclusive.to_dict()
        return d


# ── affected-scope projection ────────────────────────────────────────────────


def _providers_of(inv: Invariant) -> set[str]:
    """Every provider-id this invariant mentions. Used for scope projection."""
    names: set[str] = set()
    if isinstance(inv, ProviderAllowlist):
        names.update(inv.providers)
    elif isinstance(inv, MutualExclusion):
        names.update(inv.group_a)
        names.update(inv.group_b)
    elif isinstance(inv, SpendingCap):
        if inv.provider is not None:
            names.add(inv.provider)
    elif isinstance(inv, JurisdictionRule):
        for sub in inv.additional_invariants:
            names.update(_providers_of(sub))
    return names


def _counterparties_of(inv: Invariant) -> set[str]:
    """Every counterparty-id this invariant mentions."""
    names: set[str] = set()
    if isinstance(inv, CounterpartyConstraint):
        names.update(inv.approved_ids)
        names.update(inv.sanctioned_ids)
    elif isinstance(inv, JurisdictionRule):
        for sub in inv.additional_invariants:
            names.update(_counterparties_of(sub))
    return names


def _currencies_of(inv: Invariant) -> set[str]:
    """Every currency code this invariant mentions."""
    names: set[str] = set()
    if isinstance(inv, (MaxPerCall, SpendingCap)):
        names.add(inv.currency)
    elif isinstance(inv, JurisdictionRule):
        for sub in inv.additional_invariants:
            names.update(_currencies_of(sub))
    return names


def _rule_class_of(inv: Invariant) -> str:
    """The invariant class name — used for rule-class overlap accounting."""
    return type(inv).__name__


def _fragment_of(inv: Invariant) -> str:
    """Which semantic fragment this invariant belongs to.

    Fragment assignment mirrors ``adapter.z3_compiler.is_fragment_v2_invariant``
    but avoids importing z3 at the scope-projection layer. SpendingCap with
    scope != per_tx is v2; RollingWindowCap, RetryRateLimit are v2; everything
    else is v1.
    """
    if isinstance(inv, SpendingCap) and inv.scope != "per_tx":
        return "v2"
    if isinstance(inv, (RollingWindowCap, RetryRateLimit)):
        return "v2"
    if isinstance(inv, JurisdictionRule):
        # Mixed if any inner invariant is v2.
        if any(_fragment_of(sub) == "v2" for sub in inv.additional_invariants):
            return "v2"
        return "v1"
    return "v1"


def compute_affected_scope(
    delta: RevisionDelta,
    current_registry: X402Registry,
) -> dict:
    """Shared-variable projection for a delta against a current registry.

    Returns a structured dict listing:
      * ``providers``      -- providers referenced by the delta AND at least
                              one invariant already in ``current_registry``.
      * ``counterparties`` -- same idea for counterparty ids.
      * ``currencies``     -- currencies appearing on both sides.
      * ``rule_classes``   -- invariant class names the delta touches.
      * ``fragments``      -- {"v1", "v2"} subset the delta touches.
      * ``touched_count``  -- how many active invariants share at least one
                              provider/counterparty/currency/rule-class with
                              the delta. Used by ``classify_risk``.
      * ``active_count``   -- size of the current registry (denominator for
                              percentage calculations).

    The lists are sorted so downstream rendering stays deterministic.
    """
    active = current_registry.invariants
    active_count = len(active)

    # Scope contributions from the delta (both sides): a removal still
    # touches the shared variable, so we union ``added`` and ``removed``.
    delta_invs = tuple(delta.added) + tuple(delta.removed)

    delta_providers: set[str] = set()
    delta_counterparties: set[str] = set()
    delta_currencies: set[str] = set()
    delta_classes: set[str] = set()
    delta_fragments: set[str] = set()
    for inv in delta_invs:
        delta_providers.update(_providers_of(inv))
        delta_counterparties.update(_counterparties_of(inv))
        delta_currencies.update(_currencies_of(inv))
        delta_classes.add(_rule_class_of(inv))
        delta_fragments.add(_fragment_of(inv))

    # Now intersect against the active set so "scope" reflects genuine
    # interaction in the current registry, not just names the delta mentions
    # in isolation.
    active_providers: set[str] = set()
    active_counterparties: set[str] = set()
    active_currencies: set[str] = set()
    active_classes: set[str] = set()
    for inv in active:
        active_providers.update(_providers_of(inv))
        active_counterparties.update(_counterparties_of(inv))
        active_currencies.update(_currencies_of(inv))
        active_classes.add(_rule_class_of(inv))

    scope_providers = sorted(delta_providers & active_providers)
    scope_counterparties = sorted(delta_counterparties & active_counterparties)
    scope_currencies = sorted(delta_currencies & active_currencies)

    # Touched-count: how many active invariants share at least one
    # provider/counterparty/currency/rule-class with the delta. Conservative:
    # false positives make the risk classifier stricter, never looser.
    touched = 0
    for inv in active:
        if _rule_class_of(inv) in delta_classes:
            touched += 1
            continue
        if _providers_of(inv) & delta_providers:
            touched += 1
            continue
        if _counterparties_of(inv) & delta_counterparties:
            touched += 1
            continue
        if _currencies_of(inv) & delta_currencies:
            touched += 1

    return {
        "providers": scope_providers,
        "counterparties": scope_counterparties,
        "currencies": sorted(scope_currencies),
        "rule_classes": sorted(delta_classes),
        "fragments": sorted(delta_fragments),
        "touched_count": touched,
        "active_count": active_count,
    }


# ── "would break without proof" probe ────────────────────────────────────────


def would_break_without_proof(
    delta: RevisionDelta,
    current_registry: X402Registry,
    pattern_prover: Optional[ConsistencyProver] = None,
) -> bool:
    """Run the pattern prover against (current + delta.added - delta.removed).

    Pure observation: we do NOT admit, we do NOT mutate the registry. True
    iff the pattern prover returns a Contradiction for the union set. This
    is the "what the pattern-only check caught" signal surfaced to the
    caller on both admit and reject paths.

    The pattern prover is a cheap precheck — it catches the common
    operational conflicts (sanctioned+approved overlap, empty
    provider-allowlist intersection, dominated MaxPerCall) but is NOT a
    complete logical prover. A ``False`` here means *pattern-level* safe;
    it does not claim semantic safety. The full prover chain in
    ``apply_revision_delta_strict`` carries the authoritative decision.
    """
    prover = pattern_prover or PythonPatternProver()
    candidate = _apply_delta(current_registry, delta)
    result = prover.prove(invariants=candidate.invariants, predecessor_hash=None)
    return isinstance(result, Contradiction)


# ── risk classifier ──────────────────────────────────────────────────────────


def classify_risk(
    delta: RevisionDelta,
    affected_scope: dict,
    contradiction_or_inconclusive: Optional[
        ContradictionReport | InconclusiveReport
    ] = None,
    *,
    current_registry: Optional[X402Registry] = None,
) -> RiskLevel:
    """Bucket a delta into ``low`` | ``medium`` | ``high``.

    The rules match the spec in this module's header:

      * **high** when:
          - the decisive result was a contradiction involving a shared
            variable present in the active set (``affected_scope.touched_count
            > 0``), OR
          - the delta touches > 20% of active invariants, OR
          - the delta removes a rule whose class other active rules also
            instantiate (referenced removal).
      * **medium** when:
          - the delta touches 5-20% of active invariants, OR
          - the prover returned an InconclusiveProof under non-strict
            mode, OR
          - the delta touches a fragment-v2 temporal invariant.
      * **low** otherwise (purely additive, touches < 5%, passes pattern
        + tau + z3 without drama).

    ``contradiction_or_inconclusive`` is the wire-report form of the
    prover's verdict (already parsed from prover.Contradiction /
    prover.InconclusiveProof). Pass ``None`` for the pre-admission
    dry-run case where we just want "what risk would this delta carry
    if admitted".
    """
    active_count = max(affected_scope.get("active_count", 0), 0)
    touched = max(affected_scope.get("touched_count", 0), 0)

    # Proportion of active invariants the delta interacts with. Zero-active
    # means additions are definitionally low proportion (treat as 0% so we
    # don't divide-by-zero into medium/high incorrectly for the genesis
    # admission).
    if active_count == 0:
        touched_ratio = 0.0
    else:
        touched_ratio = touched / active_count

    # Rule 1 (high): a contradiction that names a shared variable.
    if isinstance(contradiction_or_inconclusive, ContradictionReport):
        if touched > 0:
            return "high"
        # Contradiction but disjoint from the active set (genesis or first
        # add) -- still high because we'd rather over-flag than admit
        # something the pattern prover marked unsat.
        return "high"

    # Rule 2 (high): > 20% of active invariants touched.
    if touched_ratio > 0.20:
        return "high"

    # Rule 3 (high): referenced removal. A delta removes an invariant whose
    # class another active invariant (NOT being removed in this same delta)
    # also instantiates. The remaining rule "references" the class we just
    # pulled, so depending on it going away could change downstream
    # composition.
    if delta.removed and current_registry is not None:
        active_classes: dict[str, int] = {}
        for inv in current_registry.invariants:
            active_classes[_rule_class_of(inv)] = (
                active_classes.get(_rule_class_of(inv), 0) + 1
            )
        removed_classes = {_rule_class_of(inv) for inv in delta.removed}
        for cls in removed_classes:
            # "Other rule references this class" means the class count
            # after the removal is still > 0. We use > 1 because the
            # removed one itself contributes 1 to the active count.
            if active_classes.get(cls, 0) > 1:
                return "high"

    # Rule 4 (medium): inconclusive under non-strict mode.
    if isinstance(contradiction_or_inconclusive, InconclusiveReport):
        return "medium"

    # Rule 5 (medium): delta touches 5-20% of active invariants.
    if touched_ratio >= 0.05:
        return "medium"

    # Rule 6 (medium): touches a fragment-v2 temporal invariant.
    if "v2" in affected_scope.get("fragments", ()):
        return "medium"

    # Default: low.
    return "low"


# ── internal helpers ─────────────────────────────────────────────────────────


def _apply_delta(reg: X402Registry, delta: RevisionDelta) -> X402Registry:
    """Apply ``delta.removed`` then ``delta.added`` to a registry.

    Order matters: remove-then-add mirrors ``_op_update_invariant``'s
    atomic retract+declare pair and keeps pair-consistency checks on the
    intermediate state honest.
    """
    new_reg = reg
    for inv in delta.removed:
        new_reg = new_reg.retract(inv)
    for inv in delta.added:
        new_reg = new_reg.declare(inv)
    return new_reg


def _suggested_repair_for(c: Contradiction) -> Optional[str]:
    """Map a Contradiction.reason to a single-sentence repair hint.

    Mirrors ``daemon.server._suggested_repair_for``; duplicated here so
    the mutation-safety module doesn't import back into daemon layers.
    Only exact-phrase keywords match (case-insensitive); unknown
    reasons return None so consumers can distinguish "no hint available"
    from "hint applies".
    """
    reason_lower = (c.reason or "").lower()
    if "sanctioned" in reason_lower and "approved" in reason_lower:
        return (
            "Remove the sanctioned id from the approved set, "
            "or vice versa; an id cannot be both."
        )
    if "empty pairwise intersection" in reason_lower or "disjoint" in reason_lower:
        return "Widen one of the sets so their intersection is non-empty."
    if "unsupported_fragment" in reason_lower or c.right == "fragment_v1":
        return (
            "Remove the out-of-fragment invariant, "
            "or switch the daemon to compat mode."
        )
    return None


def _contradiction_report(c: Contradiction) -> ContradictionReport:
    """Mirror of ``daemon.server._contradiction_to_report`` without the import cycle."""
    return ContradictionReport(
        conflicting_invariants=(c.left, c.right),
        unsat_explanation=c.reason,
        suggested_repair=_suggested_repair_for(c),
        backend=c.backend,
    )


def _inconclusive_report(i: InconclusiveProof) -> InconclusiveReport:
    """Mirror of ``daemon.server._inconclusive_to_report``."""
    return InconclusiveReport(
        category=i.category,
        reason=i.reason,
        backend=i.backend,
        details=dict(i.details) if i.details else {},
    )


def _stamp_mode(token: ProofToken, mode: str) -> ProofToken:
    """Return a new token with ``prover_mode`` set. ``dataclasses.replace``
    keeps every other field intact."""
    if token.prover_mode == mode:
        return token
    return replace(token, prover_mode=mode)


def _relabel_strength(token: ProofToken, new_strength: str) -> ProofToken:
    return replace(token, proof_strength=new_strength)


# ── central mutation entry point ─────────────────────────────────────────────


def apply_revision_delta_strict(
    current_registry: X402Registry,
    delta: Any,
    provers: ProverChain,
    predecessor_hash: Optional[str] = None,
) -> MutationResult:
    """Central, audited mutation path. All mutation ops route through here.

    Semantics:

      1. Compute the affected-scope projection BEFORE running any prover.
         That way rejected deltas still carry the risk metadata the caller
         needs to decide their next step (escalate, log, queue).
      2. Run the "would break without proof" probe — cheap, lets the
         response say "the pattern prover already caught this" even when
         Tau / z3 are the authoritative backends.
      3. Run the pattern prover as a precheck. Contradiction → reject,
         registry unchanged.
      4. Under ``verified`` / ``strict`` and when ``provers.tau`` is wired,
         call Tau. Contradiction → reject. Inconclusive → reject under
         strict, annotate and continue under verified.
      5. Under ``verified`` / ``strict`` / ``compat`` and when
         ``provers.z3`` is wired, call z3. Same behaviour as Tau but
         authoritative for fragment v2.
      6. On a decisive admit: return a ``MutationResult`` carrying a
         frozen ``ProofToken`` and the candidate registry. The caller is
         responsible for the CAS swap under its own lock.

    Refusal-to-mutate invariant (A2): every return path in this function
    EITHER returns ``outcome == "admitted"`` with a decisive token AND a
    non-None ``candidate_registry``, OR returns ``outcome == "rejected"``
    with ``candidate_registry = None``. Callers that honour the returned
    shape cannot advance the registry on a reject.
    """
    normalised_delta = (
        delta if isinstance(delta, RevisionDelta)
        else RevisionDelta.from_mapping(delta)
    )
    pattern = provers.pattern
    tau = provers.tau
    z3_prover = provers.z3
    mode = provers.mode

    candidate_reg = _apply_delta(current_registry, normalised_delta)

    # Step 1: projection (used for the response whether we admit or reject).
    scope = compute_affected_scope(normalised_delta, current_registry)

    # Step 2: the pre-admission pattern probe (single evaluation of the
    # pattern prover, reused below so we don't pay the N^2 pairwise cost
    # twice).
    pattern_result = pattern.prove(
        invariants=candidate_reg.invariants, predecessor_hash=predecessor_hash,
    )
    would_break = isinstance(pattern_result, Contradiction)

    if isinstance(pattern_result, Contradiction):
        report = _contradiction_report(pattern_result)
        return MutationResult(
            outcome="rejected",
            mutation_risk=classify_risk(
                normalised_delta, scope, report,
                current_registry=current_registry,
            ),
            affected_scope=scope,
            would_break_without_proof=True,
            contradiction=report,
        )

    # pattern_result is now a ProofToken (pattern strength). Hold onto it as
    # the default final_token; stronger backends overwrite it below.
    final_token: ProofToken = pattern_result  # type: ignore[assignment]

    # Step 3: Tau (fragment v1) — verified / strict only.
    tau_inconclusive_report: Optional[InconclusiveReport] = None
    if mode != "compat" and tau is not None:
        tau_result = tau.prove(
            invariants=candidate_reg.invariants, predecessor_hash=predecessor_hash,
        )
        if isinstance(tau_result, Contradiction):
            report = _contradiction_report(tau_result)
            return MutationResult(
                outcome="rejected",
                mutation_risk=classify_risk(
                    normalised_delta, scope, report,
                    current_registry=current_registry,
                ),
                affected_scope=scope,
                would_break_without_proof=would_break,
                contradiction=report,
            )
        if isinstance(tau_result, InconclusiveProof):
            if mode == "strict":
                report = _inconclusive_report(tau_result)
                return MutationResult(
                    outcome="rejected",
                    mutation_risk=classify_risk(
                        normalised_delta, scope, report,
                        current_registry=current_registry,
                    ),
                    affected_scope=scope,
                    would_break_without_proof=would_break,
                    inconclusive=report,
                )
            # verified mode: annotate strength, keep pattern token.
            tau_inconclusive_report = _inconclusive_report(tau_result)
            final_token = _relabel_strength(
                final_token, f"pattern+tau-{tau_result.category}",
            )
        elif isinstance(tau_result, ProofToken):
            final_token = tau_result

    # Step 4: z3 (fragment v2) — any mode, when wired and the delta touches v2.
    z3_inconclusive_report: Optional[InconclusiveReport] = None
    if z3_prover is not None:
        # Lazy import keeps the z3 dep optional for minimal installs.
        try:
            from adapter.z3_compiler import is_fragment_v2_invariant
        except ImportError:  # pragma: no cover — z3 extra missing entirely
            is_fragment_v2_invariant = None  # type: ignore[assignment]
        if is_fragment_v2_invariant is not None:
            v2_added = tuple(
                i for i in normalised_delta.added
                if is_fragment_v2_invariant(i)
            )
            v2_removed = tuple(
                i for i in normalised_delta.removed
                if is_fragment_v2_invariant(i)
            )
            if v2_added or v2_removed:
                v2_current = tuple(
                    i for i in candidate_reg.invariants
                    if is_fragment_v2_invariant(i)
                )
                z3_result = z3_prover.prove_delta(
                    added=v2_added,
                    removed=v2_removed,
                    predecessor_hash=predecessor_hash,
                    full_current_set=v2_current,
                )
                if isinstance(z3_result, Contradiction):
                    report = _contradiction_report(z3_result)
                    return MutationResult(
                        outcome="rejected",
                        mutation_risk=classify_risk(
                            normalised_delta, scope, report,
                            current_registry=current_registry,
                        ),
                        affected_scope=scope,
                        would_break_without_proof=would_break,
                        contradiction=report,
                    )
                if isinstance(z3_result, InconclusiveProof):
                    if mode == "strict":
                        report = _inconclusive_report(z3_result)
                        return MutationResult(
                            outcome="rejected",
                            mutation_risk=classify_risk(
                                normalised_delta, scope, report,
                                current_registry=current_registry,
                            ),
                            affected_scope=scope,
                            would_break_without_proof=would_break,
                            inconclusive=report,
                        )
                    z3_inconclusive_report = _inconclusive_report(z3_result)
                    final_token = _relabel_strength(
                        final_token, f"pattern+z3-{z3_result.category}",
                    )
                elif isinstance(z3_result, ProofToken):
                    # Prefer z3 token when pattern-only was the fallback.
                    if final_token.backend == "python-pattern":
                        final_token = z3_result

    # Step 5: stamp mode + build revision id so the caller can thread it
    # through the proof chain. ``revision_id`` format matches
    # ``PolicyRevision.from_proof_token`` for round-trip consistency.
    final_token = _stamp_mode(final_token, mode)
    revision_id = f"{final_token.config_hash}:{final_token.nonce}"

    # Pick the inconclusive-for-risk annotation: tau wins over z3 for
    # surfacing because most deployments are fragment-v1 heavy.
    inconclusive_for_risk: Optional[InconclusiveReport] = (
        tau_inconclusive_report or z3_inconclusive_report
    )
    risk = classify_risk(
        normalised_delta, scope, inconclusive_for_risk,
        current_registry=current_registry,
    )

    return MutationResult(
        outcome="admitted",
        mutation_risk=risk,
        affected_scope=scope,
        would_break_without_proof=False,
        revision_id=revision_id,
        proof_token=final_token,
        candidate_registry=candidate_reg,
    )


# ── dry-run report (CLI surface) ─────────────────────────────────────────────


@dataclass(frozen=True)
class MutationRiskReport:
    """Offline dry-run report for ``mutation-risk`` CLI.

    Never touches the daemon; pure projection from (current registry,
    candidate delta). Shape is stable for CI consumers.
    """

    mutation_risk: RiskLevel
    affected_scope: dict
    would_break_without_proof: bool
    contradiction: Optional[ContradictionReport] = None

    def to_dict(self) -> dict:
        d: dict[str, Any] = {
            "mutation_risk": self.mutation_risk,
            "affected_scope": dict(self.affected_scope),
            "would_break_without_proof": self.would_break_without_proof,
        }
        if self.contradiction is not None:
            d["contradiction"] = self.contradiction.to_dict()
        return d


def compute_mutation_risk_report(
    current_registry: X402Registry,
    delta: Any,
    pattern_prover: Optional[ConsistencyProver] = None,
) -> MutationRiskReport:
    """Build an offline ``MutationRiskReport`` without mutating anything.

    The CLI's ``mutation-risk`` subcommand calls this directly; the daemon
    does NOT need to be running. ``apply_revision_delta_strict`` gives the
    authoritative "would this admit?" answer when a daemon is available.
    This helper is the cheaper alternative for CI gates that just want to
    preflight a candidate policy.
    """
    normalised_delta = (
        delta if isinstance(delta, RevisionDelta)
        else RevisionDelta.from_mapping(delta)
    )
    prover = pattern_prover or PythonPatternProver()
    scope = compute_affected_scope(normalised_delta, current_registry)
    candidate = _apply_delta(current_registry, normalised_delta)
    result = prover.prove(
        invariants=candidate.invariants, predecessor_hash=None,
    )
    contradiction_report: Optional[ContradictionReport] = None
    would_break = False
    if isinstance(result, Contradiction):
        contradiction_report = _contradiction_report(result)
        would_break = True
    risk = classify_risk(
        normalised_delta, scope, contradiction_report,
        current_registry=current_registry,
    )
    return MutationRiskReport(
        mutation_risk=risk,
        affected_scope=scope,
        would_break_without_proof=would_break,
        contradiction=contradiction_report,
    )
