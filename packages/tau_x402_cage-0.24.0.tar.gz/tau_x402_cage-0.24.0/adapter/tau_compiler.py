"""Central compiler: normalized policy -> compiled Tau consistency-check query.

This module is the single path from a set of declared Invariants to the
Tau spec string that `TauConsistencyProver` feeds to the Tau CLI. It
enforces semantic fragment v1 (see docs/semantic_fragment_v1.md) by
reusing each invariant's `_sat_body()` method; anything outside v1
raises `UnsupportedInvariantError` here, which the daemon translates
into a strict-mode `unsupported_fragment` rejection.

Fragment v2 (temporal-arithmetic invariants: SpendingCap per_window,
RollingWindowCap, RetryRateLimit) is compiled by `adapter/z3_compiler.py`
and decided by z3, not Tau. See docs/semantic_fragment_v2.md.

Public surface:

    compile_policy(invariants, fragment_version="v1") -> CompiledTauPolicy
    CompiledTauPolicy       (dataclass)
    CompileError            (exception base)
    UnsupportedInvariantError

The compilation is deterministic: the same invariant tuple always
produces the same `tau_source` and `compile_hash`. That hash is what
gets persisted in `ProofToken` for audit.
"""
from __future__ import annotations

import hashlib
from dataclasses import dataclass
from typing import Sequence

from adapter.invariants import (
    BurstVelocityCap,
    CounterpartyConstraint,
    Invariant,
    JurisdictionRule,
    MaxPerCall,
    MutualExclusion,
    ProviderAllowlist,
    RetryRateLimit,
    RollingWindowCap,
    SpendingCap,
    _amount_to_bv,
    _count_bits,
    compose_for_sat,
)


# ── errors ───────────────────────────────────────────────────────────────────


class CompileError(ValueError):
    """Base for all compilation failures."""


class UnsupportedInvariantError(CompileError):
    """Raised when an invariant has no encoding in the requested fragment.

    Carries the offending invariant's class name so callers (and the daemon)
    can produce a structured rejection payload (`category="unsupported_fragment"`).
    """

    def __init__(self, invariant_name: str, fragment_version: str):
        super().__init__(
            f"{invariant_name} is not in semantic fragment {fragment_version}. "
            f"See docs/semantic_fragment_v1.md for the supported set."
        )
        self.invariant_name = invariant_name
        self.fragment_version = fragment_version


# ── fragment registry ────────────────────────────────────────────────────────

# Class-level registry of which invariants belong to each fragment version.
# Keeping this explicit (rather than `hasattr(inv, "_sat_body")`) forces
# intentional opt-in and makes the fragment contract testable as data.

_FRAGMENT_V1: frozenset[type] = frozenset({
    MaxPerCall,
    ProviderAllowlist,
    CounterpartyConstraint,
    JurisdictionRule,
    SpendingCap,  # per_tx only; per_window/per_provider_per_window raise at _sat_body
    MutualExclusion,
})

_FRAGMENT_REGISTRY: dict[str, frozenset[type]] = {
    "v1": _FRAGMENT_V1,
}


def fragment_members(fragment_version: str) -> frozenset[type]:
    if fragment_version not in _FRAGMENT_REGISTRY:
        raise CompileError(f"unknown fragment_version: {fragment_version!r}")
    return _FRAGMENT_REGISTRY[fragment_version]


# ── result type ──────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class CompiledTauPolicy:
    """Deterministic artifact of compiling an invariant set for consistency check.

    Fields:
        tau_source              : the exact string passed to Tau's `sat` REPL.
        fragment_version        : which fragment the compilation targeted.
        compile_hash            : SHA-256 of tau_source; goes into ProofToken.
        total_invariants        : count of invariants in the input.
        supported_invariants    : count that compiled successfully.
        invariant_summaries     : per-invariant audit metadata.
    """

    tau_source: str
    fragment_version: str
    compile_hash: str
    total_invariants: int
    supported_invariants: int
    invariant_summaries: tuple[dict, ...]


# ── compiler ─────────────────────────────────────────────────────────────────


def compile_policy(
    invariants: Sequence[Invariant],
    fragment_version: str = "v1",
) -> CompiledTauPolicy:
    """Compile an invariant set to a `sat`-decidable Tau source string.

    Fail-closed: if ANY invariant in `invariants` is outside the requested
    fragment, raises `UnsupportedInvariantError` immediately. Callers in
    strict mode must propagate this to the daemon as a rejection.
    """
    members = fragment_members(fragment_version)
    summaries: list[dict] = []

    for inv in invariants:
        if type(inv) not in members:
            raise UnsupportedInvariantError(
                invariant_name=type(inv).__name__,
                fragment_version=fragment_version,
            )
        # Per-invariant sub-fragment check (e.g. SpendingCap scope).
        # We call _sat_body once here to surface UnsupportedInvariantError
        # early if the specific instance is outside the fragment even though
        # its class is registered.
        try:
            body = inv._sat_body()
        except NotImplementedError as exc:
            raise UnsupportedInvariantError(
                invariant_name=f"{type(inv).__name__}({_scope_hint(inv)})",
                fragment_version=fragment_version,
            ) from exc
        summaries.append({
            "class": type(inv).__name__,
            "scope_hint": _scope_hint(inv),
            "sat_body": body,
            "repr_key": repr(inv),  # enables compile_delta cache hits
        })

    tau_source = compose_for_sat(invariants)
    compile_hash = hashlib.sha256(tau_source.encode("utf-8")).hexdigest()

    return CompiledTauPolicy(
        tau_source=tau_source,
        fragment_version=fragment_version,
        compile_hash=compile_hash,
        total_invariants=len(invariants),
        supported_invariants=len(summaries),
        invariant_summaries=tuple(summaries),
    )


# ── incremental compilation (Patch C) ────────────────────────────────────────


def compile_delta(
    previous_compiled: CompiledTauPolicy | None,
    added: Sequence[Invariant],
    removed: Sequence[Invariant],
    full_current_set: Sequence[Invariant],
    prover: str = "auto",
) -> CompiledTauPolicy:
    """Incrementally compile a mutation. Cached `_sat_body()` for unchanged
    invariants.

    Fragment v1 (Tau): the Tau REPL still re-runs SAT on the full formula
    (Tau limitation); the win here is compile-side caching plus the daemon's
    dependency-pruning fast-path.

    Fragment v2 (z3): `IncrementalZ3Prover.prove_delta(added, removed)` in
    `adapter/prover.py` is the preferred path. Delivered in v0.7.0 — the
    daemon routes v2 deltas to `prove_delta` when the configured backend
    is an IncrementalZ3Prover; z3's `Solver.push()` / `pop()` mean the
    unchanged constraints never re-enter the decision procedure.

    Hybrid (v0.8.0): when `prover="hybrid"`, the caller is expected to
    pass the delta to `adapter.hybrid_prover.HybridProver.prove_delta`
    for cross-fragment composed admission. `compile_delta` itself still
    returns the v1-only compiled artifact (for audit provenance); the
    caller combines it with the z3 subset on its own side. The kwarg
    exists so callers can pass the resolved routing through to tests
    and logs without a second argument channel.

    Fail-closed on out-of-fragment invariants, same as compile_policy().
    """
    if prover not in ("auto", "tau", "z3", "hybrid"):
        raise CompileError(
            f"prover must be one of auto|tau|z3|hybrid, got {prover!r}"
        )
    members = fragment_members("v1")
    cache: dict[tuple[str, str], dict] = {}
    cache_hits = 0
    cache_misses = 0
    if previous_compiled is not None:
        for summary in previous_compiled.invariant_summaries:
            key = (summary["class"], summary.get("repr_key", ""))
            if key[1]:
                cache[key] = summary

    # When routed through hybrid/z3, v2 invariants are filtered out before
    # Tau compilation; they're authoritatively decided by z3 on the parallel
    # path. `auto` and `tau` behave as before (fail-closed on v2).
    if prover in ("hybrid", "z3"):
        from adapter.z3_compiler import is_fragment_v2_invariant
        tau_eligible: Sequence[Invariant] = tuple(
            i for i in full_current_set if not is_fragment_v2_invariant(i)
        )
    else:
        tau_eligible = tuple(full_current_set)

    summaries: list[dict] = []
    for inv in tau_eligible:
        if type(inv) not in members:
            raise UnsupportedInvariantError(
                invariant_name=type(inv).__name__,
                fragment_version="v1",
            )
        cache_key = (type(inv).__name__, repr(inv))
        if cache_key in cache:
            cache_hits += 1
            summaries.append(dict(cache[cache_key]))
            continue
        cache_misses += 1
        try:
            body = inv._sat_body()
        except NotImplementedError as exc:
            raise UnsupportedInvariantError(
                invariant_name=f"{type(inv).__name__}({_scope_hint(inv)})",
                fragment_version="v1",
            ) from exc
        summaries.append({
            "class": type(inv).__name__,
            "scope_hint": _scope_hint(inv),
            "sat_body": body,
            "repr_key": repr(inv),
        })

    tau_source = compose_for_sat(tau_eligible)
    compile_hash = hashlib.sha256(tau_source.encode("utf-8")).hexdigest()

    compiled = CompiledTauPolicy(
        tau_source=tau_source,
        fragment_version="v1",
        compile_hash=compile_hash,
        total_invariants=len(full_current_set),
        supported_invariants=len(summaries),
        invariant_summaries=tuple(summaries),
    )
    object.__setattr__(compiled, "_delta_metrics", {
        "cache_hits": cache_hits,
        "cache_misses": cache_misses,
        "added_count": len(added),
        "removed_count": len(removed),
        "prover": prover,
    })
    return compiled


def _scope_hint(inv: Invariant) -> str:
    """Stable short string describing an invariant instance for audit summaries."""
    if isinstance(inv, SpendingCap):
        return f"scope={inv.scope}"
    if isinstance(inv, ProviderAllowlist):
        return f"providers_n={len(inv.providers)}"
    if isinstance(inv, CounterpartyConstraint):
        return f"approved_n={len(inv.approved_ids)},sanctioned_n={len(inv.sanctioned_ids)}"
    if isinstance(inv, JurisdictionRule):
        return f"jurisdiction={inv.jurisdiction}"
    if isinstance(inv, MaxPerCall):
        return f"max={inv.max_amount}"
    if isinstance(inv, MutualExclusion):
        return f"groups=({len(inv.group_a)},{len(inv.group_b)})"
    return ""


# ── totality dry-run (v0.19.0 Guaranteed Mode) ───────────────────────────────


def dry_run_encode(invariant: Invariant) -> tuple[bool, str]:
    """Check that an invariant produces a closed, well-formed body.

    Used exclusively by :func:`adapter.guaranteed_totality.validate_totality`
    to confirm each supported rule encodes without free variables, missing
    streams, or scope mismatches BEFORE any prover is invoked. Returns
    ``(ok, detail)``; when ``ok`` is False, ``detail`` is a short
    structured reason string (class name + what failed).

    This helper is intentionally narrow: a shape-level totality check,
    not a semantic proof. It does NOT invoke the Tau CLI — that's the
    prover agent's turf.

    v1.0.0 shape (still honoured for the three pure-fragment-v1 rule
    classes): invoke ``_sat_body()``, confirm the result is a non-empty
    string with balanced parentheses.

    v1.1.0 shape (for the three past-LTL / windowed additions): build
    a dedicated past-LTL encoding via :func:`_v11_encode` that uses the
    upstream-patched ``O`` / ``H`` operators and ``&`` chains. The
    check stays shallow — balanced parens, non-empty, no free-variable
    markers — but the generated string is a standalone Tau body a
    prover would accept, not a v1 ``_sat_body``.

    v1.2.0 shape (for the three enum / composition additions): build a
    closed ``G(...)``-wrapped body over pure ``bv`` BA via
    :func:`_v12_encode`. No ``nlang``, no z3 sentinel. The generator
    emits deterministic ``bv[16]`` enum slots hashed from stable source
    strings (country codes / counterparty ids) so audit logs can
    round-trip the compiled body.

    Fail-closed: any ``NotImplementedError`` / ``ValueError`` / arbitrary
    exception at encoding time yields ``(False, <stringified reason>)``.
    A crash becomes a rejection, never a false admit.
    """
    class_name = type(invariant).__name__

    # v1.2.0 enum / composition rule types get their dedicated encoder.
    # The check runs first so ``JurisdictionRule`` / ``CounterpartyConstraint``
    # / ``MutualExclusion`` never fall through to ``_sat_body`` (which
    # would admit richer variants outside Guaranteed Mode's bv-only
    # discipline).
    if _is_v12_enum_invariant(invariant):
        try:
            body = _v12_encode(invariant)
        except (ValueError, TypeError) as exc:
            return (
                False,
                f"{class_name}: v1.2 encoding raised {type(exc).__name__} ({exc})",
            )
        except Exception as exc:  # pragma: no cover — defensive
            return (
                False,
                f"{class_name}: unexpected {type(exc).__name__} ({exc})",
            )
        return _shape_check(class_name, body)

    # v1.1.0 rule types get the past-LTL encoding path; they do not have
    # a fragment-v1 ``_sat_body`` (and must not). Keep the narrow SpendingCap
    # per_tx path going through ``_sat_body`` so v1.0.0 behaviour is
    # unchanged.
    if _is_v11_past_ltl_invariant(invariant):
        try:
            body = _v11_encode(invariant)
        except (ValueError, TypeError) as exc:
            return (
                False,
                f"{class_name}: v1.1 encoding raised {type(exc).__name__} ({exc})",
            )
        except Exception as exc:  # pragma: no cover — defensive
            return (
                False,
                f"{class_name}: unexpected {type(exc).__name__} ({exc})",
            )
        return _shape_check(class_name, body)

    try:
        body = invariant._sat_body()
    except NotImplementedError as exc:
        return False, f"{class_name}: no fragment-v1 encoding ({exc})"
    except (ValueError, TypeError) as exc:
        return False, f"{class_name}: encoding raised {type(exc).__name__} ({exc})"
    except Exception as exc:  # pragma: no cover — defensive
        # Fail-closed on unexpected exceptions; Guaranteed Mode never
        # swallows errors silently.
        return False, f"{class_name}: unexpected {type(exc).__name__} ({exc})"
    return _shape_check(class_name, body)


def _shape_check(class_name: str, body: Any) -> tuple[bool, str]:
    """Shape-level totality check: non-empty string, balanced parens."""
    if not isinstance(body, str):
        return (
            False,
            f"{class_name}: encoding must return str, got {type(body).__name__}",
        )
    stripped = body.strip()
    if not stripped:
        return False, f"{class_name}: encoding returned empty string"
    if stripped.count("(") != stripped.count(")"):
        return (
            False,
            f"{class_name}: unbalanced parentheses in encoding ({stripped!r})",
        )
    return True, ""


# ── v1.1.0 past-LTL encodings ────────────────────────────────────────────────
#
# These helpers exist so ``dry_run_encode`` can confirm each of the three
# new rule types produces a syntactically closed Tau body without having
# to extend ``Invariant._sat_body()`` itself (which would widen the
# fragment v1 surface implicitly). The encodings mirror the shape the
# ``compile_policy`` temporal path would emit once upstream Tau merges
# bugs 1/3/4; they are NOT a semantic proof, just a smoke test that the
# generator doesn't emit garbage.


def _is_v11_past_ltl_invariant(invariant: Invariant) -> bool:
    """Return True iff the invariant should use the v1.1.0 encoding path."""
    if isinstance(invariant, (RetryRateLimit, RollingWindowCap, BurstVelocityCap)):
        return True
    if isinstance(invariant, SpendingCap) and invariant.scope in (
        "per_window",
        "per_provider_per_window",
    ):
        return True
    return False


def _v11_encode(invariant: Invariant) -> str:
    """Shallow, closed Tau encoding for a v1.1.0 rule type.

    The generator is intentionally a single pass with no quantifier
    alternation — Guaranteed Mode v1.1.0 admits conjunction of atomic
    rules only. Complex composition still lives in Flexible Mode.
    """
    if isinstance(invariant, RetryRateLimit):
        return _encode_retry_rate_limit(invariant)
    if isinstance(invariant, RollingWindowCap):
        return _encode_rolling_window_cap(invariant)
    if isinstance(invariant, BurstVelocityCap):
        return _encode_burst_velocity_cap(invariant)
    if isinstance(invariant, SpendingCap):
        # Windowed SpendingCap (per_window / per_provider_per_window).
        # Per_tx is handled by the fragment-v1 _sat_body path.
        return _encode_windowed_spending_cap(invariant)
    raise TypeError(
        f"_v11_encode called with non-v1.1.0 invariant type {type(invariant).__name__!r}"
    )


def _encode_retry_rate_limit(inv: RetryRateLimit) -> str:
    """``G(retry[t] -> !O(reject & time_since_last_reject < N))``.

    Uses the Bug-3-patched unary past-LTL ``O`` and the Bug-4-patched
    ``&`` at wff level. The encoding is close in shape to
    ``RetryRateLimit._body()`` but wrapped in its own ``G`` so the
    totality checker sees a standalone formula.
    """
    gap = int(inv.min_gap_seconds)
    return (
        "G(retry[t] = 1 -> !O(reject[t] = 1 "
        f"& time_since_last_reject[t]:bv[16] < {{ {gap} }}:bv[16]))"
    )


def _encode_rolling_window_cap(inv: RollingWindowCap) -> str:
    """``H(count_in_window <= max_count)``.

    ``H`` (historically) universally quantifies over the past: at every
    past moment the running counter never exceeded the declared ceiling.
    The counter stream name depends on ``group_by`` so per-provider /
    per-counterparty / global variants render to distinct bodies (the
    prover decides each independently).
    """
    counter = {
        "provider": "count_per_provider_in_window",
        "counterparty": "count_per_counterparty_in_window",
        "global": "count_in_window",
    }[inv.group_by]
    bits = _count_bits(inv.max_count)
    return (
        f"H({counter}[t]:bv[{bits}] <= {{ {int(inv.max_count)} }}:bv[{bits}])"
    )


def _encode_burst_velocity_cap(inv: BurstVelocityCap) -> str:
    """Past-LTL burst cap: sum-over-past-window stays below ``max_per_window``.

    The body uses the Bug-4-patched ``&`` to chain the cross-provider /
    per-provider discriminator onto the cap. Like ``RollingWindowCap``
    the formula is wrapped in ``H`` so past-universally the burst sum
    never crossed the ceiling.
    """
    amt = _amount_to_bv(inv.max_per_window)
    scope_marker = (
        "cross_provider_marker[t] = 1"
        if inv.cross_provider
        else "per_provider_marker[t] = 1"
    )
    return (
        "H(burst_sum[t]:bv[64] <= "
        f"{amt} & {scope_marker})"
    )


def _encode_windowed_spending_cap(inv: SpendingCap) -> str:
    """Past-LTL windowed cap: cumulative spend stays below ``max_amount``.

    For ``per_window`` the encoding reads "historically, cumulative spend
    has never exceeded the cap". For ``per_provider_per_window`` the
    encoding further conditions on the provider marker so the cap only
    binds inside the provider's slice — implication under ``H``.
    """
    amt = _amount_to_bv(inv.max_amount)
    if inv.scope == "per_window":
        return f"H(cumulative_spend[t]:bv[64] <= {amt})"
    # per_provider_per_window: H(provider_marker -> cumulative_provider_spend <= amt)
    return (
        f"H(provider_marker[t] = 1 -> "
        f"cumulative_provider_spend[t]:bv[64] <= {amt})"
    )


# ── v1.2.0 enum / composition encodings ──────────────────────────────────────
#
# Three additional rule types admit in Guaranteed Mode as of v1.2.0. The
# shared discipline: each encoding collapses to a closed ``G(...)`` body
# over pure ``bv`` BA (16-bit enum slots, deterministic hashes, Tau
# composition). No ``nlang`` type bindings. No z3 fragment-v2 sentinel.
# No pattern-fallback-style free variables.


def _is_v12_enum_invariant(invariant: Invariant) -> bool:
    """Return True iff the invariant should use the v1.2.0 enum encoder.

    The variant gating (``additional_invariants is empty`` for
    ``JurisdictionRule``, ``sanctioned_ids is empty`` for
    ``CounterpartyConstraint``) is intentionally mirrored in
    :meth:`adapter.guaranteed_language.GuaranteedLanguage._classify_variant`
    so the totality gate and the compiler always agree on what shape
    crosses the Guaranteed line.
    """
    if isinstance(invariant, JurisdictionRule):
        return not invariant.additional_invariants
    if isinstance(invariant, CounterpartyConstraint):
        return bool(invariant.approved_ids) and not invariant.sanctioned_ids
    if isinstance(invariant, MutualExclusion):
        return bool(invariant.group_a) and bool(invariant.group_b)
    return False


def _v12_encode(invariant: Invariant) -> str:
    """Shallow, closed Tau encoding for a v1.2.0 rule type.

    The generator is a single pass with no quantifier alternation —
    Guaranteed Mode admits only flat ``G(...)`` wrappers over pure
    ``bv`` BA predicates. Composition is expressed through conjunction /
    negation (``MutualExclusion``) not through nested temporal operators.
    """
    if isinstance(invariant, JurisdictionRule):
        return _encode_jurisdiction_enum_bv(invariant)
    if isinstance(invariant, CounterpartyConstraint):
        return _encode_counterparty_enum_bv(invariant)
    if isinstance(invariant, MutualExclusion):
        return _encode_mutual_exclusion_composition(invariant)
    raise TypeError(
        f"_v12_encode called with non-v1.2.0 invariant type {type(invariant).__name__!r}"
    )


def _encode_jurisdiction_enum_bv(inv: JurisdictionRule) -> str:
    """``G(intent_jurisdiction[t] ∈ {bv(code)})`` over a 16-bit bv slot.

    The fixed ``JurisdictionRule._JURISDICTION_CODES`` table supplies the
    stable bv value. A single-jurisdiction declaration renders as one
    equality; callers wanting an allow-list of multiple jurisdictions
    declare multiple ``JurisdictionRule`` instances and compose them via
    the outer ``compose`` conjunction, which the v1.2.0 tier already
    admits.
    """
    code = inv._JURISDICTION_CODES[inv.jurisdiction]
    return (
        f"G(intent_jurisdiction[t]:bv[16] = {{ {int(code)} }}:bv[16])"
    )


def _encode_counterparty_enum_bv(inv: CounterpartyConstraint) -> str:
    """``G(intent_counterparty[t] ∈ {bv(hash(id_1)), ...})``.

    Each approved counterparty id hashes deterministically into a 16-bit
    ``bv`` slot via :func:`_provider_hash` (a SHA-256-based enum encoder
    re-used across the taxonomy). The admitted variant requires
    ``sanctioned_ids`` to be empty; the compiler refuses the richer
    approved + sanctioned mixed shape under Guaranteed Mode so the
    generated body stays a single disjunctive allow-list.
    """
    from adapter.invariants import _provider_hash
    # Sorted by the underlying id so the generated body is deterministic
    # and two policies that differ only by iteration order compile to the
    # same SHA-256 compile_hash.
    terms = [
        f"intent_counterparty[t]:bv[16] = {{ {_provider_hash(c)} }}:bv[16]"
        for c in sorted(inv.approved_ids)
    ]
    return "G(" + " || ".join(terms) + ")"


def _encode_mutual_exclusion_composition(inv: MutualExclusion) -> str:
    """``G(¬((∨ group_a_member) ∧ (∨ group_b_member)))``.

    The encoding composes the two enum-bv allow-list predicates via
    Tau's conjunction and negation, matching the ``rule_composition``
    variant tag. No new BA is introduced — both inner predicates and
    the outer negation all reduce to ``bv`` equality and boolean
    operators.
    """
    from adapter.invariants import _provider_hash
    a_terms = [
        f"intent_provider[t]:bv[16] = {{ {_provider_hash(p)} }}:bv[16]"
        for p in sorted(inv.group_a)
    ]
    b_terms = [
        f"intent_provider[t]:bv[16] = {{ {_provider_hash(p)} }}:bv[16]"
        for p in sorted(inv.group_b)
    ]
    a_members = "(" + " || ".join(a_terms) + ")"
    b_members = "(" + " || ".join(b_terms) + ")"
    return f"G(!(({a_members}) && ({b_members})))"
