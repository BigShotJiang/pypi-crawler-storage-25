"""Guaranteed Mode mutation + merge pipeline (v0.19.0).

Deliverable 5 of the Guaranteed Mode spec. Every policy mutation in
Guaranteed Mode follows a strict two-phase flow:

  1. ``propose(current_revision, mutation)`` — validates totality,
     runs the guaranteed prover, and returns a proposal. The current
     revision is NEVER mutated, even transiently. On any failure the
     caller is left holding the old revision, unchanged by object
     identity.

  2. ``activate(proposal)`` — atomic swap to the candidate revision.
     Only runs when the proposal is activatable (totality + proof both
     decisive). An interruption between propose and activate leaves the
     caller with the old revision.

Merges follow a parallel discipline via ``guaranteed_merge``. Syntactic
(disjoint-delta) merges run the full totality + proof gate on the
merged candidate. Semantic, temporal, or unsupported-fragment conflicts
are rejected with ``REVISION_TRANSITION_VIOLATION``; Guaranteed Mode
never auto-resolves a semantic conflict.

Transition invariants are wired through the existing
``adapter/cross_revision.py`` machinery:

  * ``NoWeakening`` — production policy may not relax guarded limits
    without an approval token.
  * ``OverridesMustExpire`` — temporary overrides must have
    ``expires_at`` within ``MAX_OVERRIDE_DURATION_H`` hours.

``BranchRespectsCore`` is now wired in v0.22.0. The rule consumes the
new ``affected_scope["overrides"][rule_id] = (protection_classes,)``
provenance field on :class:`adapter.policy_revision.PolicyRevision`
and refuses any feature-branch mutation that drops or demotes a rule
tagged ``"core"``. Main-branch transitions still fall through to
``NoWeakening`` — the branch owner is the constituency that gets to
redefine what counts as ``"core"`` so rule-level provenance is feature-
branch-scoped by design.

Stable public surface for downstream agents (audit bundle, bank demo):

    from adapter.guaranteed_mutation import (
        GuaranteedMutationPipeline,
        GuaranteedMutationProposal,
        GuaranteedMergeResult,
        guaranteed_merge,
        MAX_OVERRIDE_DURATION_H,
    )
"""
from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Iterable, Literal, Mapping, Optional, Tuple

from adapter.cross_revision import (
    BranchRespectsCore,
    CrossRevisionValidator,
    NoWeakening,
    OverridesMustExpire,
    ValidationResult,
)

# ── stub imports from sibling guaranteed-* modules ──────────────────────────

try:  # pragma: no cover — exercised only after agent 1 merges.
    from adapter.guaranteed_errors import (
        GuaranteedFailure,
        GuaranteedFailureCode,
    )
except ImportError:
    # TODO: remove after agent 1 branch merges.
    GuaranteedFailureCode = Literal[  # type: ignore[misc]
        "RUNTIME_GUARD_VIOLATION",
        "RUNTIME_EVALUATION_UNAVAILABLE",
        "TOTALITY_VIOLATION",
        "PROOF_UNAVAILABLE",
        "PROOF_INCONSISTENT",
        "REVISION_TRANSITION_VIOLATION",
        "MUTATION_NOT_ACTIVATABLE",
    ]

    @dataclass(frozen=True)
    class GuaranteedFailure:  # type: ignore[no-redef]
        """Fallback failure descriptor until agent 1 ships the real type."""

        code: str
        message: str
        details: Mapping[str, Any] = field(default_factory=dict)


try:  # pragma: no cover — exercised only after agent 1 merges.
    from adapter.guaranteed_totality import TotalityReport, validate_totality
except ImportError:
    # TODO: remove after agent 1 branch merges.
    @dataclass(frozen=True)
    class TotalityReport:  # type: ignore[no-redef]
        """Fallback totality report until agent 1 ships the real type."""

        total: bool
        reason: str = ""
        details: Mapping[str, Any] = field(default_factory=dict)

    def validate_totality(candidate: Any) -> "TotalityReport":  # type: ignore[no-redef]
        """Stub validator: treats every candidate as total.

        The real ``validate_totality`` (agent 1) runs the Tau totality
        judgment over the candidate revision. This stub keeps the module
        importable and lets our tests drive totality outcomes through
        dependency injection (``GuaranteedMutationPipeline(totality_fn=...)``)
        rather than relying on the stub.
        """
        return TotalityReport(total=True, reason="stub: agent 1 not merged")


try:  # pragma: no cover — exercised only after agent 2 merges.
    from adapter.guaranteed_prover import (
        GuaranteedProofResult,
        GuaranteedProver,
    )
    from adapter.guaranteed_proof_artifact import GuaranteedProofArtifact
except ImportError:
    # TODO: remove after agent 2 branch merges.
    @dataclass(frozen=True)
    class GuaranteedProofResult:  # type: ignore[no-redef]
        """Fallback proof result shape until agent 2 ships the real type."""

        consistent: bool
        decisive: bool
        reason: str = ""
        artifact: Optional[Any] = None

    @dataclass(frozen=True)
    class GuaranteedProofArtifact:  # type: ignore[no-redef]
        """Fallback artifact until agent 2 ships the real type."""

        artifact_id: str
        policy_revision_id: str
        proof_result: str
        artifact_hash: str = ""

    class GuaranteedProver:  # type: ignore[no-redef]
        """Stub prover: treats every candidate as consistent + decisive.

        The real prover (agent 2) runs the strict prover chain with a
        mandatory decisive outcome. This stub keeps the module
        importable and lets tests inject outcomes by passing a custom
        prover via ``GuaranteedMutationPipeline(prover=...)``.
        """

        def prove(self, candidate: Any) -> GuaranteedProofResult:
            revision_id = str(getattr(candidate, "id", "") or "stub-revision")
            return GuaranteedProofResult(
                consistent=True,
                decisive=True,
                reason="stub: agent 2 not merged",
                artifact=GuaranteedProofArtifact(
                    artifact_id=str(uuid.uuid4()),
                    policy_revision_id=revision_id,
                    proof_result="consistent",
                ),
            )


# ── totality-report compat shim ─────────────────────────────────────────────
#
# Agent 1 shipped real ``TotalityReport`` with ``is_total / reason_code /
# unsupported_nodes / language_version``. Agent 3 (this module) and its tests
# predate the merge and construct/read reports with a ``total / reason``
# shape. These helpers bridge both shapes so the pipeline stays honest to
# the real schema when it produces reports internally, while still
# accepting duck-typed reports (``_FakeTotalityReport``) the tests inject
# through ``totality_fn=``.


def _is_total(report: Any) -> bool:
    """Read the total-bit from either the real or the test report shape."""
    sentinel = object()
    real = getattr(report, "is_total", sentinel)
    if real is not sentinel:
        return bool(real)
    return bool(getattr(report, "total", False))


def _totality_reason(report: Any) -> str:
    """Read a human reason from either report shape."""
    reason_code = getattr(report, "reason_code", None)
    if reason_code:
        nodes = getattr(report, "unsupported_nodes", ())
        return f"{reason_code}: {', '.join(nodes)}" if nodes else str(reason_code)
    return str(getattr(report, "reason", "") or "")


_AGENT3_TO_REAL_CODE = {
    "TOTALITY_VIOLATION": "TAU_TOTALITY_FAILED",
    "REVISION_TRANSITION_VIOLATION": "REVISION_TRANSITION_VIOLATION",
    "PROOF_UNAVAILABLE": "TAU_PROOF_INCONCLUSIVE",
    "PROOF_INCONSISTENT": "TAU_PROOF_INCONSISTENT",
    "MUTATION_NOT_ACTIVATABLE": "REVISION_TRANSITION_VIOLATION",
    "RUNTIME_GUARD_VIOLATION": "RUNTIME_GUARD_VIOLATION",
    "RUNTIME_EVALUATION_UNAVAILABLE": "RUNTIME_EVALUATION_UNAVAILABLE",
}


def _make_failure(
    *,
    code: str,
    message: str,
    details: Optional[Mapping[str, Any]] = None,
) -> GuaranteedFailure:
    """Construct a GuaranteedFailure in real-schema when available.

    Translates the agent-3 code vocabulary onto the real
    ``GuaranteedFailureCode`` enum (agent 1) and maps legacy ``details=``
    to the real ``context=`` parameter. Falls back to the stub schema
    only if the real enum isn't importable.
    """
    real_code = _AGENT3_TO_REAL_CODE.get(code, code)
    try:
        from adapter.guaranteed_errors import (
            GuaranteedFailureCode as _RealCode,
        )
        from adapter.guaranteed_language import GUARANTEED_LANGUAGE_VERSION
        enum_value = _RealCode(real_code)
        return GuaranteedFailure(  # type: ignore[call-arg]
            code=enum_value,
            message=message,
            context=dict(details or {}),
            language_version=GUARANTEED_LANGUAGE_VERSION,
        )
    except (ImportError, ValueError):
        # Stub-schema fallback (agent 1 not merged; tests kept running).
        return GuaranteedFailure(  # type: ignore[call-arg]
            code=code,
            message=message,
            details=dict(details or {}),
        )


class _DeferredProver:
    """Placeholder prover used when no real prover is injected.

    Only raises on ``prove()`` — instantiation succeeds. Tests that
    exercise earlier gates (transition invariants, merge classification)
    never reach the prover, so the pipeline still behaves correctly
    without an injected prover. Callers that DO reach the prover get a
    clear error telling them to inject one.
    """

    def prove(self, candidate: Any) -> Any:
        raise RuntimeError(
            "GuaranteedMutationPipeline has no prover injected. "
            "Pass prover=GuaranteedProver(TauConsistencyProver(...)) "
            "at construction time."
        )


def _default_prover() -> Any:
    """Build the real GuaranteedProver if its signature allows a zero-arg
    construction; otherwise fall back to the deferred sentinel.

    Agent 2's real ``GuaranteedProver(prover: TauConsistencyProver)``
    cannot be instantiated without a live Tau. The stub version from
    agent 3's era was zero-arg. Supporting both keeps transition tests
    and merge-classification tests working without requiring a Tau
    binary on the CI host.
    """
    try:
        return GuaranteedProver()  # agent-3 stub signature, if still active
    except TypeError:
        return _DeferredProver()


def _make_totality_report(*, total: bool, reason: str) -> TotalityReport:
    """Construct a TotalityReport that satisfies either schema.

    Prefers the real agent-1 schema (``is_total`` + ``reason_code`` +
    ``unsupported_nodes`` + ``language_version``). Falls back to the stub
    schema (``total`` + ``reason``) when the real type hasn't merged yet.
    """
    try:
        from adapter.guaranteed_language import GUARANTEED_LANGUAGE_VERSION
    except ImportError:
        GUARANTEED_LANGUAGE_VERSION = "0.0.0-stub"
    try:
        return TotalityReport(  # type: ignore[call-arg]
            is_total=total,
            reason_code=None if total else "TAU_TOTALITY_FAILED",
            unsupported_nodes=() if total else (reason,),
            language_version=GUARANTEED_LANGUAGE_VERSION,
        )
    except TypeError:
        # Stub schema fallback.
        return TotalityReport(total=total, reason=reason)  # type: ignore[call-arg]


# ── public constants ────────────────────────────────────────────────────────


#: Maximum allowable override duration in hours. Any policy revision that
#: introduces an override whose ``expires_at`` is more than this many hours
#: into the future is refused as ``REVISION_TRANSITION_VIOLATION``.
#:
#: 24h is the v1.0.0 policy: overnight bank change windows are the widest
#: legitimate use. Longer-lived overrides should be declared as regular
#: invariants with normal governance.
MAX_OVERRIDE_DURATION_H: int = 24
MAX_OVERRIDE_DURATION_SECONDS: int = MAX_OVERRIDE_DURATION_H * 60 * 60


# ── transition-invariant validator ──────────────────────────────────────────


def _default_transition_validator() -> CrossRevisionValidator:
    """Build the v0.22.0 transition invariant set.

    v1.0.0 shipped with ``NoWeakening`` + ``OverridesMustExpire``.
    v0.22.0 adds ``BranchRespectsCore`` so the rule-level
    ``affected_scope["overrides"][rule_id]`` provenance fencing is
    enforced at admission time.

    Role breakdown:

      * ``NoWeakening`` runs on the ``main`` branch (Guaranteed Mode
        treats main as the monitored production tier).
      * ``OverridesMustExpire`` bounds every TTL override at
        :data:`MAX_OVERRIDE_DURATION_SECONDS` (24h).
      * ``BranchRespectsCore`` fences feature-branch mutations against
        the ``"core"`` protection tag. The class-level
        ``protected_classes`` set is left empty — rule-level provenance
        is the intended path in v0.22.0, and tests that want the
        legacy class-level check can build their own validator.
    """
    return CrossRevisionValidator(
        invariants=(
            NoWeakening(),
            OverridesMustExpire(max_ttl_seconds=MAX_OVERRIDE_DURATION_SECONDS),
            BranchRespectsCore(
                core_branch_name="main",
                protected_classes=frozenset(),
            ),
        )
    )


# ── result dataclasses ──────────────────────────────────────────────────────


@dataclass(frozen=True)
class GuaranteedMutationProposal:
    """Outcome of ``GuaranteedMutationPipeline.propose``.

    ``activatable`` is the single boolean callers gate on. When True,
    ``failure`` is ``None`` and the proposal is safe to ``activate()``.
    When False, ``failure`` carries the structured reason.

    Attributes:
        candidate_revision: the proposed new revision. Never committed
            until ``activate()`` runs. On proposal failure the caller
            should still treat this as "what would have been proposed"
            and NOT swap it in.
        totality_report: the totality judgment. Populated on every
            proposal, pass or fail.
        proof_artifact: the proof artifact produced by the guaranteed
            prover. Bound to ``candidate_revision.id``.
        activatable: True iff every gate passed decisively.
        failure: structured failure descriptor on reject; ``None`` on
            success.
    """

    candidate_revision: Any
    totality_report: TotalityReport
    proof_artifact: Optional[GuaranteedProofArtifact]
    activatable: bool
    failure: Optional[GuaranteedFailure] = None
    proposal_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    proposal_timestamp: datetime = field(
        default_factory=lambda: datetime.now(timezone.utc)
    )


@dataclass(frozen=True)
class GuaranteedMergeResult:
    """Outcome of ``guaranteed_merge``.

    Mirrors ``GuaranteedMutationProposal`` for the merge path so audit
    tooling can consume the same shape. On reject, ``proposal`` is
    ``None`` and ``failure`` carries the reason. On success,
    ``proposal`` is populated and callers may drive through
    ``GuaranteedMutationPipeline.activate``.
    """

    accepted: bool
    proposal: Optional[GuaranteedMutationProposal] = None
    failure: Optional[GuaranteedFailure] = None
    conflicts: Tuple[Mapping[str, Any], ...] = ()
    merge_id: str = field(default_factory=lambda: str(uuid.uuid4()))


# ── pipeline ────────────────────────────────────────────────────────────────


class GuaranteedMutationPipeline:
    """Guarded propose → activate mutation flow for Guaranteed Mode.

    Pipelines are cheap to construct. A single pipeline carries no
    mutation state of its own; it delegates to injected totality and
    prover callables so tests can drive outcomes deterministically.
    The caller owns the active-revision reference and is responsible
    for CAS-ing it after ``activate()`` returns a new revision.

    Args:
        totality_fn: callable that returns a ``TotalityReport``. Defaults
            to the module-level ``validate_totality``.
        prover: a ``GuaranteedProver``-shaped object. Defaults to the
            module-level stub. Production wires the real prover from
            ``adapter/guaranteed_prover.py``.
        transition_validator: the v1.0.0 transition invariant set.
            Defaults to ``NoWeakening`` + ``OverridesMustExpire``.
        build_candidate_fn: optional function that takes (current_revision,
            mutation) and returns the candidate revision. When omitted
            we look for ``mutation.apply_to(current_revision)`` first
            and fall back to treating ``mutation`` itself as the
            candidate. Tests can inject a deterministic builder for
            predictable candidate ids.
    """

    def __init__(
        self,
        *,
        totality_fn: Any = None,
        prover: Any = None,
        transition_validator: Optional[CrossRevisionValidator] = None,
        build_candidate_fn: Any = None,
        approval_check: Any = None,
    ) -> None:
        self._totality_fn = totality_fn or validate_totality
        self._prover = prover if prover is not None else _default_prover()
        self._transition_validator = (
            transition_validator
            if transition_validator is not None
            else _default_transition_validator()
        )
        self._build_candidate_fn = build_candidate_fn
        # Approval check hook: called with the candidate + transition
        # violations. If it returns False (or raises) the transition is
        # treated as unapproved and the proposal rejects. Default allows
        # every transition that has no violations; violations always deny.
        self._approval_check = approval_check

    # ── propose ─────────────────────────────────────────────────────────

    def propose(
        self,
        current_revision: Any,
        mutation: Any,
        *,
        branch: str = "main",
    ) -> GuaranteedMutationProposal:
        """Build a proposal without mutating the caller's revision.

        Order of gates (each gate is fail-closed):

          1. Build the candidate revision. Candidate build failures are
             treated as ``TOTALITY_VIOLATION`` (the candidate shape is
             the totality domain).
          2. Transition invariants (``NoWeakening`` +
             ``OverridesMustExpire``). Violations → reject with
             ``REVISION_TRANSITION_VIOLATION``.
          3. Totality. Non-total candidates → reject with
             ``TOTALITY_VIOLATION``.
          4. Prover. Inconsistent or inconclusive results → reject with
             ``PROOF_INCONSISTENT`` or ``PROOF_UNAVAILABLE``.

        Returns a ``GuaranteedMutationProposal``. The caller's
        ``current_revision`` is untouched on every path.
        """
        # Gate 1: build candidate.
        try:
            candidate = self._build_candidate(current_revision, mutation)
        except Exception as exc:  # noqa: BLE001 — fail-closed on candidate build failure.
            return self._rejected_proposal(
                candidate_revision=current_revision,
                totality=_make_totality_report(
                    total=False,
                    reason=f"candidate build raised {type(exc).__name__}: {exc}",
                ),
                proof_artifact=None,
                failure=_make_failure(
                    code="TOTALITY_VIOLATION",
                    message=(
                        "guaranteed mutation: candidate build failed; "
                        f"{type(exc).__name__}: {exc}"
                    ),
                    details={"exception_type": type(exc).__name__},
                ),
            )

        # Gate 2: transition invariants.
        transition_result = self._validate_transition(
            old_revision=current_revision,
            new_revision=candidate,
            branch=branch,
        )
        if not transition_result.valid:
            return self._rejected_proposal(
                candidate_revision=candidate,
                totality=_make_totality_report(
                    total=False,
                    reason="transition invariant violation blocks totality check",
                ),
                proof_artifact=None,
                failure=_make_failure(
                    code="REVISION_TRANSITION_VIOLATION",
                    message=(
                        "guaranteed mutation: transition invariants refused "
                        "the mutation; current revision unchanged."
                    ),
                    details={
                        "violations": [
                            v.to_dict() for v in transition_result.violations
                        ],
                    },
                ),
            )

        # Gate 3: totality.
        try:
            totality = self._totality_fn(candidate)
        except Exception as exc:  # noqa: BLE001 — fail-closed on totality failures.
            return self._rejected_proposal(
                candidate_revision=candidate,
                totality=_make_totality_report(
                    total=False,
                    reason=f"totality validator raised {type(exc).__name__}: {exc}",
                ),
                proof_artifact=None,
                failure=_make_failure(
                    code="TOTALITY_VIOLATION",
                    message=(
                        "guaranteed mutation: totality validator failed; "
                        f"{type(exc).__name__}: {exc}"
                    ),
                    details={"exception_type": type(exc).__name__},
                ),
            )
        if not _is_total(totality):
            return self._rejected_proposal(
                candidate_revision=candidate,
                totality=totality,
                proof_artifact=None,
                failure=_make_failure(
                    code="TOTALITY_VIOLATION",
                    message=(
                        "guaranteed mutation: candidate revision is not total; "
                        f"reason={_totality_reason(totality) or 'unknown'}."
                    ),
                ),
            )

        # Gate 3.5: meta-policy admission (v0.22.0).
        # Meta-policies (AdaptiveTighteningPolicy, PeerAuthenticationPolicy)
        # carry structural admission properties that are not per-intent
        # propositional. Admitting them here, after totality but before
        # the payment-rule prover, keeps the prover's input confined to
        # ordinary invariants and surfaces a stable failure code for
        # meta-policy-specific problems (e.g. half_life <= 0).
        try:
            from adapter.meta_policy import admit_meta_policies as _admit_meta
            meta_report = _admit_meta(candidate)
        except Exception as exc:  # noqa: BLE001 — fail-closed on raise.
            return self._rejected_proposal(
                candidate_revision=candidate,
                totality=totality,
                proof_artifact=None,
                failure=_make_failure(
                    code="REVISION_TRANSITION_VIOLATION",
                    message=(
                        "guaranteed mutation: meta-policy admission raised "
                        f"{type(exc).__name__}: {exc}; current revision unchanged."
                    ),
                    details={"exception_type": type(exc).__name__},
                ),
            )
        if not meta_report.is_admitted:
            return self._rejected_proposal(
                candidate_revision=candidate,
                totality=totality,
                proof_artifact=None,
                failure=_make_failure(
                    code="REVISION_TRANSITION_VIOLATION",
                    message=(
                        "guaranteed mutation: meta-policy admission refused the "
                        "mutation; current revision unchanged."
                    ),
                    details={
                        "meta_policy_report": meta_report.to_dict(),
                        "meta_policy_reason_code": (
                            meta_report.reason_code.value
                            if meta_report.reason_code is not None else None
                        ),
                    },
                ),
            )

        # Gate 4: prover.
        try:
            proof_result = self._prover.prove(candidate)
        except Exception as exc:  # noqa: BLE001 — fail-closed on prover raise.
            return self._rejected_proposal(
                candidate_revision=candidate,
                totality=totality,
                proof_artifact=None,
                failure=_make_failure(
                    code="PROOF_UNAVAILABLE",
                    message=(
                        "guaranteed mutation: prover raised "
                        f"{type(exc).__name__}: {exc}; current revision unchanged."
                    ),
                    details={"exception_type": type(exc).__name__},
                ),
            )

        if not getattr(proof_result, "decisive", False):
            return self._rejected_proposal(
                candidate_revision=candidate,
                totality=totality,
                proof_artifact=None,
                failure=_make_failure(
                    code="PROOF_UNAVAILABLE",
                    message=(
                        "guaranteed mutation: prover returned an inconclusive "
                        "result; Guaranteed Mode requires a decisive proof."
                    ),
                    details={
                        "reason": getattr(proof_result, "reason", "") or "",
                    },
                ),
            )
        if not getattr(proof_result, "consistent", False):
            return self._rejected_proposal(
                candidate_revision=candidate,
                totality=totality,
                proof_artifact=None,
                failure=_make_failure(
                    code="PROOF_INCONSISTENT",
                    message=(
                        "guaranteed mutation: prover found the candidate revision "
                        "inconsistent; current revision unchanged."
                    ),
                    details={
                        "reason": getattr(proof_result, "reason", "") or "",
                    },
                ),
            )

        artifact = getattr(proof_result, "artifact", None)
        if artifact is None:
            return self._rejected_proposal(
                candidate_revision=candidate,
                totality=totality,
                proof_artifact=None,
                failure=_make_failure(
                    code="PROOF_UNAVAILABLE",
                    message=(
                        "guaranteed mutation: prover returned a decisive "
                        "result with no artifact attached."
                    ),
                ),
            )

        # All four gates passed. Proposal is activatable.
        return GuaranteedMutationProposal(
            candidate_revision=candidate,
            totality_report=totality,
            proof_artifact=artifact,
            activatable=True,
            failure=None,
        )

    # ── activate ─────────────────────────────────────────────────────────

    def activate(self, proposal: GuaranteedMutationProposal) -> Any:
        """Atomic swap — return the candidate as the new active revision.

        Raises a ``GuaranteedActivationError`` if the proposal isn't
        activatable. The error is intentionally non-recoverable: the
        caller must re-propose rather than retry activation on a known-
        bad proposal.

        Note: this method performs NO side effects on external storage.
        The caller owns the active-revision reference and is responsible
        for CAS-ing it in under whatever lock protects their pipeline.
        Returning the candidate here is the atomic step from this
        module's perspective — either the caller assigns the return
        value or it doesn't.
        """
        if not proposal.activatable:
            raise GuaranteedActivationError(
                "guaranteed mutation: cannot activate a non-activatable proposal; "
                "re-run propose() with a fresh mutation."
            )
        return proposal.candidate_revision

    # ── internals ────────────────────────────────────────────────────────

    def _build_candidate(self, current_revision: Any, mutation: Any) -> Any:
        """Build the candidate revision from (current, mutation).

        Resolution order:
          1. Injected ``build_candidate_fn``.
          2. ``mutation.apply_to(current_revision)`` when defined.
          3. ``mutation`` itself — treats the argument as an already-
             built candidate. Useful when the caller did the
             propose-prep up-front.

        We never mutate ``current_revision`` in any branch.
        """
        if self._build_candidate_fn is not None:
            return self._build_candidate_fn(current_revision, mutation)
        apply_to = getattr(mutation, "apply_to", None)
        if callable(apply_to):
            return apply_to(current_revision)
        return mutation

    def _validate_transition(
        self,
        *,
        old_revision: Any,
        new_revision: Any,
        branch: str,
    ) -> ValidationResult:
        """Run the transition invariants, then the optional approval check.

        The approval check is a post-validation hook: callers can plug
        in the existing ``mutation_governance`` actor-auth flow to
        supply the approval token NoWeakening demands for weakening
        transitions.
        """
        result = self._transition_validator.validate(
            old_revision=old_revision,
            new_revision=new_revision,
            branch=branch,
        )
        if not result.valid:
            return result
        if self._approval_check is not None:
            try:
                approved = bool(
                    self._approval_check(
                        old_revision=old_revision,
                        new_revision=new_revision,
                        branch=branch,
                    )
                )
            except Exception:  # noqa: BLE001 — fail-closed on approval errors.
                approved = False
            if not approved:
                # Fabricate a transition violation via the public surface;
                # we avoid a custom violation type so the wire shape stays
                # aligned with the rest of cross_revision.py.
                from adapter.cross_revision import CrossRevisionViolation

                return ValidationResult(
                    valid=False,
                    violations=(
                        CrossRevisionViolation(
                            invariant_name="GuaranteedApproval",
                            category="approval_required",
                            reason=(
                                "transition requires an approval token "
                                "that was not supplied."
                            ),
                        ),
                    ),
                )
        return result

    def _rejected_proposal(
        self,
        *,
        candidate_revision: Any,
        totality: TotalityReport,
        proof_artifact: Optional[GuaranteedProofArtifact],
        failure: GuaranteedFailure,
    ) -> GuaranteedMutationProposal:
        """Build a GuaranteedMutationProposal in the rejected shape."""
        return GuaranteedMutationProposal(
            candidate_revision=candidate_revision,
            totality_report=totality,
            proof_artifact=proof_artifact,
            activatable=False,
            failure=failure,
        )


# ── activation error ────────────────────────────────────────────────────────


class GuaranteedActivationError(RuntimeError):
    """Raised when activation is attempted on a non-activatable proposal."""


# ── merges ─────────────────────────────────────────────────────────────────


def guaranteed_merge(
    base: Any,
    branch_a: Any,
    branch_b: Any,
    *,
    pipeline: Optional[GuaranteedMutationPipeline] = None,
    classify_fn: Any = None,
    build_merge_fn: Any = None,
    target_branch: str = "main",
) -> GuaranteedMergeResult:
    """Three-way merge under Guaranteed Mode.

    Behaviour:

      1. Classify the deltas between ``base``/``branch_a`` and
         ``base``/``branch_b`` using ``merge_classifier.classify_conflict``
         (or the injected ``classify_fn``). Any
         ``semantic``/``temporal``/``unsupported_fragment`` classification
         rejects with ``REVISION_TRANSITION_VIOLATION``.
      2. On ``syntactic`` (disjoint-delta) classifications only, build
         the merge candidate via ``build_merge_fn`` (default: treats
         ``branch_b`` as the merged candidate; callers normally override).
      3. Run the merge candidate through
         ``GuaranteedMutationPipeline.propose`` so the full
         totality + proof gate fires on the merged revision. A rejection
         at that layer surfaces as the proposal's structured failure.

    Guaranteed Mode never auto-resolves a semantic conflict: operators
    must construct a manual resolution on the source branch and merge
    again.
    """
    pipe = pipeline or GuaranteedMutationPipeline()
    classify = classify_fn or _default_classify
    try:
        conflicts = classify(base=base, branch_a=branch_a, branch_b=branch_b)
    except Exception as exc:  # noqa: BLE001 — fail-closed on classifier error.
        return GuaranteedMergeResult(
            accepted=False,
            failure=_make_failure(
                code="REVISION_TRANSITION_VIOLATION",
                message=(
                    "guaranteed merge: conflict classifier raised "
                    f"{type(exc).__name__}: {exc}; treating as unresolved."
                ),
                details={"exception_type": type(exc).__name__},
            ),
        )

    blocking_categories = {"semantic", "temporal", "unsupported_fragment"}
    blocking = tuple(
        c for c in conflicts
        if _category_of(c) in blocking_categories
    )
    if blocking:
        return GuaranteedMergeResult(
            accepted=False,
            failure=_make_failure(
                code="REVISION_TRANSITION_VIOLATION",
                message=(
                    "guaranteed merge: non-syntactic conflicts block merge; "
                    "Guaranteed Mode does not auto-resolve semantic / "
                    "temporal / unsupported-fragment conflicts."
                ),
                details={
                    "conflict_categories": sorted(
                        {_category_of(c) for c in blocking}
                    ),
                },
            ),
            conflicts=tuple(_conflict_to_dict(c) for c in blocking),
        )

    # Syntactic-only merge: build the merge candidate then run it through
    # the guaranteed propose pipeline.
    try:
        merged = (
            build_merge_fn(base=base, branch_a=branch_a, branch_b=branch_b)
            if build_merge_fn is not None
            else _default_merge_builder(base=base, branch_a=branch_a, branch_b=branch_b)
        )
    except Exception as exc:  # noqa: BLE001 — fail-closed on merge-build error.
        return GuaranteedMergeResult(
            accepted=False,
            failure=_make_failure(
                code="REVISION_TRANSITION_VIOLATION",
                message=(
                    "guaranteed merge: merge-builder raised "
                    f"{type(exc).__name__}: {exc}."
                ),
                details={"exception_type": type(exc).__name__},
            ),
        )

    proposal = pipe.propose(base, merged, branch=target_branch)
    if not proposal.activatable:
        return GuaranteedMergeResult(
            accepted=False,
            failure=proposal.failure,
            proposal=proposal,
        )
    return GuaranteedMergeResult(accepted=True, proposal=proposal)


def _default_classify(
    *,
    base: Any,
    branch_a: Any,
    branch_b: Any,
) -> Iterable[Any]:
    """Lazy import wrapper over ``merge_classifier.classify_conflict``.

    Tests inject a custom ``classify_fn`` so this helper stays dumb; the
    real wire-up is handled at the integration layer.
    """
    try:
        from adapter.merge_classifier import classify_conflict
    except ImportError:
        return ()

    src_delta = _delta_between(base, branch_a)
    dst_delta = _delta_between(base, branch_b)
    return classify_conflict(src_delta=src_delta, dst_delta=dst_delta)


def _delta_between(base: Any, branch: Any) -> dict[str, list[Any]]:
    """Best-effort delta reconstruction between two revisions.

    If the branch carries a ``delta_against(base)`` method we use it;
    otherwise we return the empty delta. Production wires a real
    reconstruction through the revision log.
    """
    delta_fn = getattr(branch, "delta_against", None)
    if callable(delta_fn):
        try:
            result = delta_fn(base)
        except Exception:  # noqa: BLE001 — defensive
            return {"added": [], "removed": []}
        if isinstance(result, dict):
            return {
                "added": list(result.get("added") or []),
                "removed": list(result.get("removed") or []),
            }
    return {"added": [], "removed": []}


def _default_merge_builder(
    *,
    base: Any,
    branch_a: Any,
    branch_b: Any,
) -> Any:
    """Fallback merge builder: prefer ``branch_a.merge_with(branch_b, base=base)``.

    When the revision type carries no merge affordance we fall back to
    treating ``branch_b`` as the merged candidate. Tests override this
    default when they need precise control.
    """
    merge_fn = getattr(branch_a, "merge_with", None)
    if callable(merge_fn):
        return merge_fn(branch_b, base=base)
    return branch_b


def _category_of(conflict: Any) -> str:
    """Extract the category string from a classifier result.

    Accepts both the dataclass (``ClassifiedConflict.category``) and
    dict forms that tests sometimes inject.
    """
    if hasattr(conflict, "category"):
        value = getattr(conflict, "category")
        if isinstance(value, str):
            return value
    if isinstance(conflict, Mapping):
        value = conflict.get("category")
        if isinstance(value, str):
            return value
    return ""


def _conflict_to_dict(conflict: Any) -> Mapping[str, Any]:
    """Render a classifier result as a JSON-safe mapping."""
    if hasattr(conflict, "to_dict"):
        try:
            return conflict.to_dict()
        except Exception:  # noqa: BLE001 — defensive
            pass
    if isinstance(conflict, Mapping):
        return dict(conflict)
    return {"category": _category_of(conflict), "raw": repr(conflict)}


__all__ = [
    "GuaranteedActivationError",
    "GuaranteedMergeResult",
    "GuaranteedMutationPipeline",
    "GuaranteedMutationProposal",
    "MAX_OVERRIDE_DURATION_H",
    "MAX_OVERRIDE_DURATION_SECONDS",
    "guaranteed_merge",
]
