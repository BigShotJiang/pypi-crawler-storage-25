"""Failure semantics for Guaranteed Mode (v0.19.0 Deliverable 7).

Guaranteed Mode is the narrow, bank-deployable tier of the cage. Where
Flexible Mode tolerates fallbacks (pattern prover, bounded z3 unrolling,
hybrid dispatch), Guaranteed Mode fails closed with a SINGLE structured
explanation. No ambiguity. No "something went wrong." Every rejection
carries a code from :class:`GuaranteedFailureCode` plus a human-readable
message and a structured (immutable) context mapping.

Contract for other agents:

    from adapter.guaranteed_errors import (
        GuaranteedFailureCode,
        GuaranteedFailure,
        format_for_audit,
    )

The :class:`GuaranteedFailure` type is ``frozen=True`` + the ``context``
mapping is wrapped in :class:`types.MappingProxyType` so it cannot be
mutated after construction. Downstream agents (prover, runtime, audit)
MUST construct a fresh failure rather than mutating an existing one.

See docs/guaranteed_mode.md (written by the audit agent) for end-to-end
narrative on how these codes surface in the bank evaluation demo.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from types import MappingProxyType
from typing import Any, Mapping, Optional

__all__ = [
    "GuaranteedFailureCode",
    "GuaranteedFailure",
    "format_for_audit",
]


class GuaranteedFailureCode(str, Enum):
    """Exhaustive taxonomy of Guaranteed-Mode failure reasons.

    Deriving from ``str`` lets the enum values flow through JSON
    serialization transparently (``json.dumps(code)`` yields the string
    literal). This is important for audit export: an auditor reading a
    JSON trail should see stable string codes, not ``"<GuaranteedFailure
    Code.X: 'X'>"``.

    Codes are documented one line each. If a new failure class is needed
    add it here AND extend the regression tests in
    ``tests/test_guaranteed_errors.py``. Never widen the set silently.
    """

    #: The policy or mutation references a construct outside the
    #: guaranteed language tier (rule type, composition operator,
    #: temporal construct, or mutation form).
    UNSUPPORTED_FOR_GUARANTEED_MODE = "UNSUPPORTED_FOR_GUARANTEED_MODE"

    #: Every construct is individually supported but the policy as a
    #: whole fails the totality check (free variables, unbound streams,
    #: or the dry-run encoding raised).
    TAU_TOTALITY_FAILED = "TAU_TOTALITY_FAILED"

    #: The Tau prover ran but returned an inconclusive verdict
    #: (timeout, incomplete decision, or a hybrid fallback attempted).
    #: In Flexible Mode this would downgrade; in Guaranteed Mode it is
    #: fatal.
    TAU_PROOF_INCONCLUSIVE = "TAU_PROOF_INCONCLUSIVE"

    #: The Tau prover decisively proved the policy (or candidate revision)
    #: is unsatisfiable — every state would violate at least one invariant.
    #: This is a *decisive* outcome, distinct from
    #: ``TAU_PROOF_INCONCLUSIVE``. Guaranteed Mode rejects admission
    #: because a policy that admits nothing is operationally useless and
    #: almost always indicates a contradiction the author didn't intend.
    TAU_PROOF_INCONSISTENT = "TAU_PROOF_INCONSISTENT"

    #: The Tau prover hit the configured time budget without returning a
    #: decisive verdict. Distinct from ``TAU_PROOF_INCONCLUSIVE`` because
    #: a retry with a larger budget may succeed; audit tooling surfaces
    #: the budget that was in force when the refusal happened.
    TAU_PROOF_TIMEOUT = "TAU_PROOF_TIMEOUT"

    #: A rule or composition operator is syntactically valid but uses a
    #: construct Tau cannot decide (e.g., past-LTL operator on a branch
    #: without the upstream patch, or an unsupported fragment combinator).
    #: Distinct from ``UNSUPPORTED_FOR_GUARANTEED_MODE`` because the
    #: language tier accepted the rule type but a specific construct
    #: underneath it falls outside Tau's decidable fragment.
    TAU_UNSUPPORTED_CONSTRUCT = "TAU_UNSUPPORTED_CONSTRUCT"

    #: The Tau compiler ran but produced an incomplete or malformed
    #: encoding (free variables, unbound streams, parser rejection after
    #: encoding). Guaranteed Mode refuses to prove a formula whose
    #: encoding is not fully defined.
    TAU_COMPILE_INCOMPLETE = "TAU_COMPILE_INCOMPLETE"

    #: The Tau prover raised an internal error (segfault, assertion,
    #: unexpected return code). Distinct from
    #: ``TAU_BACKEND_UNAVAILABLE`` which covers the "prover didn't run"
    #: case; this code means the prover ran and crashed. Guaranteed Mode
    #: refuses rather than retry blindly.
    TAU_PROVER_INTERNAL_ERROR = "TAU_PROVER_INTERNAL_ERROR"

    #: The Tau runtime is not reachable (binary missing, library path
    #: misconfigured, daemon crashed). The cage refuses to substitute a
    #: different backend in Guaranteed Mode.
    TAU_BACKEND_UNAVAILABLE = "TAU_BACKEND_UNAVAILABLE"

    #: A decision needed runtime state (per-window aggregates, velocity
    #: projections) that the guaranteed runtime cannot compute under its
    #: closed-form discipline. Distinct from ``TAU_PROOF_INCONCLUSIVE``
    #: because it surfaces before the prover is invoked.
    RUNTIME_EVALUATION_UNAVAILABLE = "RUNTIME_EVALUATION_UNAVAILABLE"

    #: The runtime guard observed a payment that would violate a proven
    #: invariant. Rejection is the expected outcome, not a system error,
    #: but it is still emitted as a structured failure so downstream
    #: audit pipelines can trace the refusal.
    RUNTIME_GUARD_VIOLATION = "RUNTIME_GUARD_VIOLATION"

    #: A proposed revision transition (add / remove / tighten) failed
    #: the mutation discipline (would weaken a core guarantee, break a
    #: cross-revision invariant, or use an unsupported mutation form).
    REVISION_TRANSITION_VIOLATION = "REVISION_TRANSITION_VIOLATION"


@dataclass(frozen=True)
class GuaranteedFailure:
    """Single, explainable Guaranteed-Mode failure.

    Construction validates that ``context`` is a mapping; the dataclass
    is frozen, and ``context`` is frozen further via ``MappingProxyType``
    in ``__post_init__`` so auditors cannot mutate the trail after the
    fact.

    Fields:
        code:             entry in :class:`GuaranteedFailureCode`.
        message:          human-readable, actionable text. Never leaks
                          secrets; callers must scrub before construction.
        context:          structured detail (invariant name, dry-run
                          error, prover timeout value, etc.). Values must
                          be JSON-serializable; construction does a
                          best-effort stringify for non-serializable
                          items.
        language_version: Guaranteed-Language version active at failure
                          time (e.g. ``"1.0.0"``). Bound at call site so
                          later language bumps don't retroactively relabel
                          past audit records.
        backend_version:  Tau / z3 runtime version string when known.
                          ``None`` when the prover never ran (e.g. the
                          totality gate rejected first).
    """

    code: GuaranteedFailureCode
    message: str
    context: Mapping[str, Any] = field(default_factory=dict)
    language_version: str = ""
    backend_version: Optional[str] = None

    def __post_init__(self) -> None:
        # Input validation at boundary: every required field must be
        # concrete and non-empty. Guaranteed Mode's whole value prop is
        # explainability; a blank message violates the contract.
        if not isinstance(self.code, GuaranteedFailureCode):
            raise TypeError(
                f"GuaranteedFailure.code must be GuaranteedFailureCode, "
                f"got {type(self.code).__name__}"
            )
        if not isinstance(self.message, str) or not self.message.strip():
            raise ValueError(
                "GuaranteedFailure.message must be a non-empty string"
            )
        if not isinstance(self.language_version, str):
            raise TypeError(
                f"GuaranteedFailure.language_version must be str, "
                f"got {type(self.language_version).__name__}"
            )
        if self.backend_version is not None and not isinstance(
            self.backend_version, str
        ):
            raise TypeError(
                "GuaranteedFailure.backend_version must be str or None, "
                f"got {type(self.backend_version).__name__}"
            )
        if not isinstance(self.context, Mapping):
            raise TypeError(
                "GuaranteedFailure.context must be a Mapping, "
                f"got {type(self.context).__name__}"
            )
        # Freeze the context mapping so callers can't mutate it later.
        # dataclass(frozen=True) stops field rebinding, but a plain dict
        # would still accept ``failure.context["k"] = v``. The proxy
        # wrapper raises TypeError for any mutation attempt.
        frozen_context = MappingProxyType(dict(self.context))
        object.__setattr__(self, "context", frozen_context)


def format_for_audit(failure: GuaranteedFailure) -> dict:
    """Render a :class:`GuaranteedFailure` as a JSON-serializable dict.

    Shape is stable across releases; audit pipelines pin on it. The
    wrapping ``schema`` key is version-tagged so future changes (adding
    a field, renaming ``code`` to ``reason_code``) can migrate without
    breaking old log readers.
    """
    if not isinstance(failure, GuaranteedFailure):
        raise TypeError(
            f"format_for_audit requires a GuaranteedFailure, got "
            f"{type(failure).__name__}"
        )
    return {
        "schema": "tau-x402-cage.guaranteed-failure.v1",
        "code": failure.code.value,
        "message": failure.message,
        "context": _coerce_context_for_json(failure.context),
        "language_version": failure.language_version,
        "backend_version": failure.backend_version,
    }


def _coerce_context_for_json(ctx: Mapping[str, Any]) -> dict:
    """Best-effort render of context values as JSON-safe primitives.

    Downstream agents pass tuples / frozensets / Decimals into context;
    this helper normalizes those to lists / strings so the audit export
    stays ``json.dumps``-clean. Anything not handled falls through to
    ``repr()`` so we never raise during audit rendering.
    """
    out: dict = {}
    for k, v in ctx.items():
        out[str(k)] = _coerce_value(v)
    return out


def _coerce_value(v: Any) -> Any:
    if v is None or isinstance(v, (bool, int, float, str)):
        return v
    if isinstance(v, (list, tuple)):
        return [_coerce_value(x) for x in v]
    if isinstance(v, (set, frozenset)):
        return sorted(_coerce_value(x) for x in v)
    if isinstance(v, Mapping):
        return {str(k): _coerce_value(val) for k, val in v.items()}
    # Decimal, Path, custom types → str() keeps the trail readable.
    return str(v)
