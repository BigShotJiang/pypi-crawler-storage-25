"""Constraint-composition analysis for decision envelopes (v0.21.0).

Problem this module solves
--------------------------
Today, :class:`adapter.x402_registry.X402Registry.check_payment` returns
the FIRST violation it finds and stops traversing. That preserves the
hot-path's backwards-compatible shape, but it hides two things from the
decision envelope:

1. **Composed violations.** Two (or more) invariants may both reject the
   same intent. The agent sees only the first rule that happened to be
   declared; the interaction — the reason the policy as a whole is
   binding — never reaches the envelope.

2. **Near-threshold invariants.** An invariant can be at 95% of its cap
   (i.e. the intent is about to push it over) without actually firing.
   That signal is exactly what an agent needs to avoid the "I was
   allowed, then allowed, then blocked without warning" cliff.

This module adds an ALL-violations + near-threshold analysis path that
runs alongside the existing first-violation fast path. It does NOT
change the wire contract of ``check_payment``; callers that want the
composition view use :func:`analyze_composition` explicitly.

Design notes
------------
* **Pure function, immutable output.** Takes a registry + intent + history
  and returns a :class:`CompositionResult`. Never mutates state.
* **Best-effort per-class.** Each invariant type has its own closed-form
  distance-to-violation estimator (below). Classes with no natural
  gradient (e.g. allowlist membership) contribute 1.0 only when they
  fire; they never populate ``near_thresholds``.
* **Near-threshold fraction.** Default 0.8 — "within 20% of firing".
  Tunable via ``near_threshold_fraction``; must sit in ``(0.0, 1.0)``.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

from adapter.invariants import (
    BurstVelocityCap,
    Invariant,
    JurisdictionRule,
    MaxPerCall,
    MutualExclusion,
    ProviderAllowlist,
    RetryRateLimit,
    RollingWindowCap,
    SpendingCap,
    Violation,
)
from adapter.payment_intent_matcher import PaymentIntent


#: Default near-threshold fraction. An invariant with distance >= this
#: value (and that did not fire) is reported in ``near_thresholds``.
DEFAULT_NEAR_THRESHOLD_FRACTION = 0.8


@dataclass(frozen=True)
class CompositionResult:
    """Outcome of iterating every invariant over a single intent.

    Fields:
        violations:
            Every :class:`Violation` the registry's invariants emitted
            for this intent, in declaration order. Empty tuple when no
            rule fires.
        near_thresholds:
            Rule_ids (stable wire contract) -> distance-to-violation in
            ``[0.0, 1.0]``. Only invariants that did NOT fire and whose
            distance >= ``near_threshold_fraction`` are listed. Bounded
            at 1.0 — an invariant that would have fired with a margin
            reports 1.0, not a value > 1.0.
        first_violation:
            Shortcut to ``violations[0]`` for backwards compatibility
            with the existing check_payment return shape. ``None`` when
            no rule fired.
    """

    violations: Tuple[Violation, ...] = ()
    near_thresholds: Mapping[str, float] = field(default_factory=dict)

    @property
    def first_violation(self) -> Optional[Violation]:
        return self.violations[0] if self.violations else None

    @property
    def violation_rule_ids(self) -> Tuple[str, ...]:
        return tuple(v.rule_id for v in self.violations)

    @property
    def is_composed(self) -> bool:
        """True iff two or more invariants fired for the same intent."""
        return len(self.violations) >= 2


def analyze_composition(
    registry: Any,
    intent: PaymentIntent,
    history: Iterable[PaymentIntent],
    rejects: Iterable[PaymentIntent] = (),
    *,
    near_threshold_fraction: float = DEFAULT_NEAR_THRESHOLD_FRACTION,
) -> CompositionResult:
    """Evaluate every invariant; collect violations + near-threshold rules.

    Extends ``X402Registry.check_payment``'s first-violation semantics:
    the registry stops at the first violation; this function runs the
    full sweep so the caller can see the interaction.

    Args:
        registry:
            Any object exposing an iterable ``invariants`` attribute of
            :class:`Invariant` instances. Accepts the production
            :class:`adapter.x402_registry.X402Registry` plus any test
            double with the same surface.
        intent:
            The current payment intent under evaluation.
        history:
            Iterable of previously-permitted :class:`PaymentIntent`
            records in oldest-first order.
        rejects:
            Iterable of previously-rejected records in oldest-first
            order. Only ``RetryRateLimit`` consults this.
        near_threshold_fraction:
            Threshold for reporting "close but not firing" rules. Must
            be in ``(0.0, 1.0]``. Defaults to 0.8.

    Returns:
        :class:`CompositionResult` with all violations + the
        near-threshold map.
    """
    if not (0.0 < near_threshold_fraction <= 1.0):
        raise ValueError(
            f"near_threshold_fraction must be in (0.0, 1.0], "
            f"got {near_threshold_fraction!r}"
        )
    invariants_seq: Sequence[Invariant] = tuple(
        getattr(registry, "invariants", ()) or ()
    )
    history_tuple = tuple(history)
    rejects_tuple = tuple(rejects)

    violations: List[Violation] = []
    near: Dict[str, float] = {}
    for inv in invariants_seq:
        try:
            violation = inv.check_payment(intent, history_tuple, rejects_tuple)
        except Exception:  # noqa: BLE001 — composition must stay read-only
            # A broken invariant must not break the whole sweep. The
            # first-violation fast-path already has this behaviour
            # implicitly via exception propagation; here we skip the
            # broken invariant and keep analysing the rest so the
            # envelope still carries partial information.
            continue
        if violation is not None:
            violations.append(violation)
            continue
        # Rule did not fire — estimate distance-to-violation and record
        # if it crosses the near-threshold cutoff.
        distance = _distance_to_violation(inv, intent, history_tuple, rejects_tuple)
        if distance is not None and distance >= near_threshold_fraction:
            rule_id = _advisory_rule_id(inv)
            if rule_id is not None:
                near[rule_id] = round(float(distance), 4)
    return CompositionResult(
        violations=tuple(violations),
        near_thresholds=dict(near),
    )


# ── per-class distance estimators ──────────────────────────────────────────


def _distance_to_violation(
    inv: Invariant,
    intent: PaymentIntent,
    history: Sequence[PaymentIntent],
    rejects: Sequence[PaymentIntent],
) -> Optional[float]:
    """Return the invariant's headroom consumption in ``[0.0, 1.0]`` or None.

    Boolean-shaped invariants (allowlists, mutual exclusion) never
    return a meaningful near-threshold because there's no gradient:
    the rule fires or it doesn't. Those classes return ``None`` here
    so :func:`analyze_composition` skips them.

    The gradient classes return a value in ``[0.0, 1.0]`` where:
        * 0.0 = full headroom, 1.0 = at or past the cap.
        * The computation mirrors the class's own ``check_payment``
          threshold exactly, so a near-threshold reading of 1.0 means
          the rule is guaranteed to fire on a matching future intent.
    """
    if isinstance(inv, MaxPerCall):
        if intent.currency != inv.currency:
            return None
        return _ratio(intent.amount, inv.max_amount)
    if isinstance(inv, SpendingCap):
        if inv.scope == "per_tx":
            return _ratio(intent.amount, inv.max_amount)
        window = inv.window_seconds or 0
        cutoff = intent.timestamp_unix - window
        if inv.scope == "per_provider_per_window":
            relevant = [
                p for p in history
                if p.provider == inv.provider
                and p.currency == inv.currency
                and p.timestamp_unix >= cutoff
            ]
        else:
            relevant = [
                p for p in history
                if p.currency == inv.currency and p.timestamp_unix >= cutoff
            ]
        cumulative = sum((p.amount for p in relevant), Decimal("0")) + intent.amount
        return _ratio(cumulative, inv.max_amount)
    if isinstance(inv, RollingWindowCap):
        cutoff = intent.timestamp_unix - inv.window_seconds
        if inv.group_by == "provider":
            relevant = [
                p for p in history
                if p.provider == intent.provider and p.timestamp_unix >= cutoff
            ]
        elif inv.group_by == "counterparty":
            relevant = [
                p for p in history
                if p.counterparty == intent.counterparty
                and p.timestamp_unix >= cutoff
            ]
        else:
            relevant = [p for p in history if p.timestamp_unix >= cutoff]
        count = len(relevant) + 1
        if inv.max_count <= 0:
            return None
        return min(1.0, count / inv.max_count)
    if isinstance(inv, BurstVelocityCap):
        if intent.currency != inv.currency:
            return None
        cutoff = intent.timestamp_unix - inv.window_seconds
        if inv.cross_provider:
            relevant = [
                p for p in history
                if p.currency == inv.currency and p.timestamp_unix >= cutoff
            ]
        else:
            relevant = [
                p for p in history
                if p.currency == inv.currency
                and p.provider == intent.provider
                and p.timestamp_unix >= cutoff
            ]
        total = sum((p.amount for p in relevant), Decimal("0")) + intent.amount
        return _ratio(total, inv.max_per_window)
    if isinstance(inv, RetryRateLimit):
        # Measure "closeness" as (min_gap - actual_gap) / min_gap for
        # the most-recent matching reject. If no reject in window, full
        # headroom (0.0). If gap is tiny relative to the required gap,
        # near 1.0. Boolean fire happens when gap < min_gap; our
        # gradient is the complementary "how much of the cooldown did
        # we still need to wait".
        min_gap = inv.min_gap_seconds
        if min_gap <= 0:
            return None
        cutoff = intent.timestamp_unix - min_gap
        recent = [
            r for r in rejects
            if r.provider == intent.provider
            and r.counterparty == intent.counterparty
            and r.timestamp_unix > cutoff
        ]
        if recent:
            # The rule has already fired — return 1.0 so the caller can
            # still surface the RetryRateLimit as a near-threshold in
            # the contrived case where the first-violation path
            # rejected for an unrelated reason. In normal operation
            # :func:`analyze_composition` only calls this when the
            # rule DID NOT fire, so this branch is rare.
            return 1.0
        # Look one step back: how close WAS the most-recent reject to
        # being inside the window? Give a gradient when rejects exist
        # just outside the cooldown.
        outside = [
            r for r in rejects
            if r.provider == intent.provider
            and r.counterparty == intent.counterparty
        ]
        if not outside:
            return 0.0
        last_ts = max(r.timestamp_unix for r in outside)
        gap = intent.timestamp_unix - last_ts
        if gap >= min_gap:
            # Fully outside the window — gradient is how much of the
            # cooldown has been consumed; clamp so a reject 10x older
            # than the window reports ~0.0.
            consumed = min(1.0, min_gap / max(1, gap))
            return consumed
        return min(1.0, 1.0 - (gap / min_gap))
    # Boolean classes without a continuous gradient — no near-threshold
    # semantics. Mutual exclusion / allowlist / jurisdiction / sanctions
    # all fall here.
    if isinstance(inv, (ProviderAllowlist, MutualExclusion, JurisdictionRule)):
        return None
    # Unknown classes — return None so callers skip them rather than
    # guess. A future invariant class can opt-in by providing a
    # ``distance_to_violation`` method (see below).
    distance_fn = getattr(inv, "distance_to_violation", None)
    if callable(distance_fn):
        try:
            value = distance_fn(intent, history, rejects)
        except Exception:  # noqa: BLE001 — broken fn => skip
            return None
        if value is None:
            return None
        try:
            return min(1.0, max(0.0, float(value)))
        except (TypeError, ValueError):
            return None
    return None


def _ratio(numerator: Decimal, denominator: Decimal) -> Optional[float]:
    """Bounded ratio ``numerator / denominator`` as a float in ``[0.0, 1.0]``.

    Returns ``None`` if denominator is zero or negative.
    """
    if denominator is None or denominator <= 0:
        return None
    try:
        return min(1.0, max(0.0, float(numerator / denominator)))
    except (TypeError, ArithmeticError):
        return None


def _advisory_rule_id(inv: Invariant) -> Optional[str]:
    """Advisory rule_id used as a key in ``near_thresholds``.

    We emit the same rule_ids the invariant would have emitted from
    ``check_payment`` if it had fired, so wire consumers can
    cross-reference the entry with the canonical taxonomy. Returns
    ``None`` for invariant classes whose near-threshold is not
    meaningful (mirror the distance estimator's skip set).
    """
    if isinstance(inv, MaxPerCall):
        return "max_per_call"
    if isinstance(inv, SpendingCap):
        return f"spending_cap_{inv.scope}"
    if isinstance(inv, RollingWindowCap):
        return f"rolling_window_cap_{inv.group_by}"
    if isinstance(inv, BurstVelocityCap):
        return "burst_velocity_exceeded"
    if isinstance(inv, RetryRateLimit):
        return "retry_rate_limit"
    # Boolean / opaque rules have no advisory id.
    return None


__all__ = [
    "DEFAULT_NEAR_THRESHOLD_FRACTION",
    "CompositionResult",
    "analyze_composition",
]
