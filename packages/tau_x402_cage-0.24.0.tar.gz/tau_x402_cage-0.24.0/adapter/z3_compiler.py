"""Fragment v2 consistency compiler using z3.

Fragment v2 covers the temporal-arithmetic invariants that Tau cannot decide
today (see docs/semantic_fragment_v2_research.md -- Tau's `<=` on bv is not
numeric). z3 natively decides bitvector numeric comparisons, so we route
fragment-v2 consistency checks to it.

Supported invariants (v2):
  * SpendingCap(scope="per_window")
  * SpendingCap(scope="per_provider_per_window")
  * RollingWindowCap
  * RetryRateLimit

Each invariant contributes a non-temporal ENCODING of its window as a
bounded unrolling: N symbolic per-step amounts, the cap applies to their
sum under z3's numeric `BitVecRef.__le__` (which IS numeric unsigned
comparison).

This module is imported lazily from `adapter.prover.Z3ConsistencyProver`
so `pip install tau-x402-cage` without the `[v2]` extra still works; only
callers who opt into strict mode for fragment v2 pay the z3 dependency.

## Witness extraction (v0.8.0)

When z3 returns SAT, the solver has concrete assignments for every
declared symbolic variable. `extract_witness(solver, summaries)` walks
the model and reconstructs a human-readable trace: one dict per
unrolled step, carrying the amount / event-flag / reject-flag /
retry-flag values that satisfy the composed policy. Operators use the
trace to see "what does my policy allow?" by example, not only by
verdict. See docs/semantic_fragment_v2.md for the output shape.
"""
from __future__ import annotations

import hashlib
from dataclasses import dataclass
from decimal import Decimal
from typing import TYPE_CHECKING, Any, Iterable, Optional, Sequence

if TYPE_CHECKING:
    from adapter.invariants import Invariant


# ── errors ───────────────────────────────────────────────────────────────────


class Z3CompileError(ValueError):
    """Raised when a fragment-v2 invariant cannot be compiled to z3."""


class Z3Unavailable(RuntimeError):
    """Raised when the z3-solver package is not importable."""


# ── result type ──────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class CompiledZ3Policy:
    """Deterministic artifact of compiling fragment-v2 invariants for z3."""

    smt2_source: str                          # SMT-LIB 2 rendering of the composed spec
    fragment_version: str                     # "v2"
    compile_hash: str
    total_invariants: int
    invariant_summaries: tuple[dict, ...]
    unroll_steps: int                         # N steps the windows were unrolled over


# ── fragment registry ────────────────────────────────────────────────────────


def _fragment_v2_classes():
    """Lazily-resolved set of classes in fragment v2 (lazy so module import
    doesn't pull the full invariants.py transitive chain)."""
    from adapter.invariants import (
        BurstVelocityCap,
        RetryRateLimit,
        RollingWindowCap,
        SpendingCap,
    )
    return frozenset(
        {SpendingCap, RollingWindowCap, RetryRateLimit, BurstVelocityCap}
    )


def is_fragment_v2_invariant(inv: "Invariant") -> bool:
    """True iff inv is an instance of a fragment-v2 class.

    Note: SpendingCap(scope="per_tx") is fragment v1 (handled by Tau), not v2.
    The SpendingCap class is in both fragment sets; scope disambiguates.
    """
    from adapter.invariants import SpendingCap
    if type(inv) not in _fragment_v2_classes():
        return False
    if isinstance(inv, SpendingCap) and inv.scope == "per_tx":
        return False  # per_tx is fragment v1
    return True


# ── compiler ─────────────────────────────────────────────────────────────────


def compile_policy_v2(
    invariants: Sequence["Invariant"],
    unroll_steps: int = 10,
):
    """Compile fragment-v2 invariants into (CompiledZ3Policy, z3.Solver).

    Returns a tuple (compiled, solver). The caller uses `solver.check()`
    directly (avoids a from_string round-trip that drops declarations);
    `compiled.smt2_source` is the audit artifact embedding both
    declarations and assertions via `solver.to_smt2()`.

    Raises:
        Z3CompileError: if an invariant class is outside fragment v2.
        Z3Unavailable:  if the z3-solver package is not installed.
    """
    try:
        import z3  # noqa: F401 -- used below in the closure
    except ImportError as exc:
        raise Z3Unavailable(
            "z3-solver is required for fragment v2. Install with "
            "`pip install tau-x402-cage[v2]` or `pip install z3-solver`."
        ) from exc

    summaries: list[dict] = []
    # Build one z3 Solver and add all invariants; also render a parallel
    # SMT-LIB document for audit.
    import z3 as z3mod
    solver = z3mod.Solver()
    smt_assertions: list[str] = []

    for inv in invariants:
        if not is_fragment_v2_invariant(inv):
            raise Z3CompileError(
                f"{type(inv).__name__}({_scope_hint(inv)}) is not in fragment v2"
            )
        spec = _invariant_to_z3(inv, unroll_steps, z3mod)
        summaries.append(spec["summary"])
        for constraint in spec["constraints"]:
            solver.add(constraint)
            smt_assertions.append(f"(assert {constraint.sexpr()})")

    # Solver's own SMT-LIB rendering includes the needed declarations.
    smt2_source = solver.to_smt2()
    compile_hash = hashlib.sha256(smt2_source.encode("utf-8")).hexdigest()

    return CompiledZ3Policy(
        smt2_source=smt2_source,
        fragment_version="v2",
        compile_hash=compile_hash,
        total_invariants=len(invariants),
        invariant_summaries=tuple(summaries),
        unroll_steps=unroll_steps,
    ), solver


# ── per-invariant compilation (v0.7.0, for push/pop frames) ──────────────────


def compile_invariant_v2(
    inv: "Invariant",
    unroll_steps: int = 10,
):
    """Compile a SINGLE fragment-v2 invariant to (constraints, summary).

    Used by the incremental z3 backend (`IncrementalZ3Prover`) to push one
    frame per invariant onto a live `z3.Solver`. The per-invariant
    constraints are the same list as `_invariant_to_z3` returns; this is
    the stable public entry point for frame emission.

    Raises:
        Z3CompileError: if the invariant class is outside fragment v2.
        Z3Unavailable:  if the z3-solver package is not installed.

    Returns:
        Tuple (constraints, summary) where ``constraints`` is a list of
        z3 BoolRef assertions for this invariant alone and ``summary`` is
        the audit metadata dict. Callers are responsible for scoping the
        assertions onto a `push()`-ed frame so they can be `pop()`-ed.
    """
    try:
        import z3 as z3mod
    except ImportError as exc:
        raise Z3Unavailable(
            "z3-solver is required for fragment v2. Install with "
            "`pip install tau-x402-cage[fragment-v2]`."
        ) from exc
    if not is_fragment_v2_invariant(inv):
        raise Z3CompileError(
            f"{type(inv).__name__}({_scope_hint(inv)}) is not in fragment v2"
        )
    spec = _invariant_to_z3(inv, unroll_steps, z3mod)
    return spec["constraints"], spec["summary"]


def frame_tag(inv: "Invariant") -> str:
    """Deterministic per-invariant tag used as a push/pop frame key.

    The tag is stable for the lifetime of the invariant instance (hash()
    reflects the frozen-dataclass repr), so an `add_invariant(X)` followed
    later by `remove_invariant(X)` maps to the SAME tag and the prover
    knows which frame to pop.

    Format: ``<ClassName>::<16-hex>`` where the hex is the lower 64 bits of
    a SHA-256 of the invariant repr. Using a hash rather than raw repr
    keeps the tag bounded in length for log lines.
    """
    repr_bytes = repr(inv).encode("utf-8")
    digest = hashlib.sha256(repr_bytes).hexdigest()[:16]
    return f"{type(inv).__name__}::{digest}"


def check_sat(solver, compiled: CompiledZ3Policy, timeout_ms: int = 10000) -> tuple[str, str]:
    """Run the z3 decision procedure on the live solver and return
    ("sat" | "unsat" | "unknown", human-readable detail).
    """
    try:
        import z3
    except ImportError as exc:
        raise Z3Unavailable("z3-solver not installed") from exc
    solver.set("timeout", int(timeout_ms))
    status = solver.check()
    if status == z3.sat:
        return "sat", f"z3 returned SAT ({compiled.unroll_steps}-step unrolling)"
    if status == z3.unsat:
        return "unsat", f"z3 returned UNSAT"
    return "unknown", f"z3 returned UNKNOWN (timeout {timeout_ms}ms or undecidable)"


# ── per-invariant z3 emission ────────────────────────────────────────────────


def _invariant_to_z3(inv: "Invariant", unroll_steps: int, z3mod) -> dict:
    """Emit z3 constraints for one fragment-v2 invariant.

    Returns a dict with `constraints` (list of z3 BoolRef) and `summary`
    (metadata for audit).
    """
    from adapter.invariants import (
        BurstVelocityCap,
        RetryRateLimit,
        RollingWindowCap,
        SpendingCap,
    )

    if isinstance(inv, SpendingCap):
        return _spending_cap_to_z3(inv, unroll_steps, z3mod)
    if isinstance(inv, RollingWindowCap):
        return _rolling_window_to_z3(inv, unroll_steps, z3mod)
    if isinstance(inv, RetryRateLimit):
        return _retry_rate_to_z3(inv, unroll_steps, z3mod)
    if isinstance(inv, BurstVelocityCap):
        return _burst_velocity_to_z3(inv, unroll_steps, z3mod)
    raise Z3CompileError(f"no z3 encoding for {type(inv).__name__}")


def _spending_cap_to_z3(inv, N: int, z3mod) -> dict:
    """SpendingCap(per_window): sum of N symbolic amounts ≤ max_amount (in micros)."""
    max_micros = int(inv.max_amount * Decimal("1_000_000"))
    # Use unique variable names per invariant identity so multiple caps with
    # different bounds don't over-share unknowns.
    tag = f"spCap_{hash(inv) & 0xffff:04x}"
    step_amts = [z3mod.BitVec(f"{tag}_amt_{i}", 64) for i in range(N)]
    constraints = []
    # Each step amount is unsigned; by BitVec semantics that's already true.
    # The window cap: sum of all step amounts <= max_micros.
    total = step_amts[0]
    for a in step_amts[1:]:
        total = total + a
    constraints.append(z3mod.ULE(total, z3mod.BitVecVal(max_micros, 64)))
    return {
        "constraints": constraints,
        "summary": {
            "class": "SpendingCap",
            "scope": inv.scope,
            "max_micros": max_micros,
            "currency": getattr(inv, "currency", "USDC"),
            "provider": getattr(inv, "provider", None),
            "unroll_steps": N,
            "vars": [str(a) for a in step_amts],
            # Witness-extraction metadata (v0.8.0):
            "witness_kind": "spending_cap",
            "amount_vars": [str(a) for a in step_amts],
            "tag": tag,
        },
    }


def _rolling_window_to_z3(inv, N: int, z3mod) -> dict:
    """RollingWindowCap: at most `max_count` events in the window.

    Encoded as N symbolic boolean "event happened at step i" flags; the
    count is the number of trues; the count must be ≤ max_count.
    """
    tag = f"rollCap_{hash(inv) & 0xffff:04x}"
    event_flags = [z3mod.Bool(f"{tag}_e_{i}") for i in range(N)]
    count = z3mod.Sum(*[z3mod.If(f, 1, 0) for f in event_flags])
    constraints = [count <= inv.max_count]
    return {
        "constraints": constraints,
        "summary": {
            "class": "RollingWindowCap",
            "group_by": inv.group_by,
            "max_count": inv.max_count,
            "unroll_steps": N,
            # Witness-extraction metadata (v0.8.0):
            "witness_kind": "rolling_window_cap",
            "event_vars": [str(f) for f in event_flags],
            "tag": tag,
        },
    }


def _retry_rate_to_z3(inv, N: int, z3mod) -> dict:
    """RetryRateLimit: after a reject, the next N steps have no retry.

    Encoded as: reject_t[i] && retry_t[j] where j in (i, i+gap) is forbidden.
    We unroll for N steps with a 1-second grain approximation.
    """
    tag = f"retry_{hash(inv) & 0xffff:04x}"
    reject = [z3mod.Bool(f"{tag}_r_{i}") for i in range(N)]
    retry = [z3mod.Bool(f"{tag}_y_{i}") for i in range(N)]
    gap = inv.min_gap_seconds
    constraints = []
    for i in range(N):
        # A retry at step j is forbidden if there was a reject within the
        # prior `gap` steps.
        lookback = max(0, i - gap)
        for k in range(lookback, i):
            constraints.append(z3mod.Implies(reject[k], z3mod.Not(retry[i])))
    return {
        "constraints": constraints,
        "summary": {
            "class": "RetryRateLimit",
            "min_gap_seconds": gap,
            "unroll_steps": N,
            # Witness-extraction metadata (v0.8.0):
            "witness_kind": "retry_rate_limit",
            "reject_vars": [str(r) for r in reject],
            "retry_vars": [str(r) for r in retry],
            "tag": tag,
        },
    }


def _burst_velocity_to_z3(inv, N: int, z3mod) -> dict:
    """BurstVelocityCap: bounded unrolling of per-step amounts with a window cap.

    The encoding mirrors SpendingCap(per_window) but uses a different
    tag prefix so the amounts do not share names. That is important at
    compose time -- z3 would otherwise treat two BitVecs with the same
    tag as the same variable and falsely derive constraints between
    unrelated invariants.
    """
    max_micros = int(inv.max_per_window * Decimal("1_000_000"))
    tag = f"burstCap_{hash(inv) & 0xffff:04x}"
    step_amts = [z3mod.BitVec(f"{tag}_amt_{i}", 64) for i in range(N)]
    constraints = []
    total = step_amts[0]
    for a in step_amts[1:]:
        total = total + a
    constraints.append(z3mod.ULE(total, z3mod.BitVecVal(max_micros, 64)))
    return {
        "constraints": constraints,
        "summary": {
            "class": "BurstVelocityCap",
            "max_micros": max_micros,
            "currency": getattr(inv, "currency", "USDC"),
            "cross_provider": getattr(inv, "cross_provider", True),
            "window_seconds": inv.window_seconds,
            "unroll_steps": N,
            "vars": [str(a) for a in step_amts],
            "witness_kind": "burst_velocity_cap",
            "amount_vars": [str(a) for a in step_amts],
            "tag": tag,
        },
    }


def _scope_hint(inv) -> str:
    from adapter.invariants import (
        BurstVelocityCap,
        RetryRateLimit,
        RollingWindowCap,
        SpendingCap,
    )
    if isinstance(inv, SpendingCap):
        return f"scope={inv.scope}"
    if isinstance(inv, RollingWindowCap):
        return f"max_count={inv.max_count},window={inv.window_seconds}"
    if isinstance(inv, RetryRateLimit):
        return f"min_gap={inv.min_gap_seconds}"
    if isinstance(inv, BurstVelocityCap):
        return (
            f"max_per_window={inv.max_per_window},"
            f"window={inv.window_seconds},"
            f"cross_provider={inv.cross_provider}"
        )
    return ""


# ── witness extraction (v0.8.0) ──────────────────────────────────────────────


def _micros_to_decimal(micros: int) -> Decimal:
    """Convert bv64 micro-units back to a Decimal in the policy's currency.

    All fragment-v2 amounts are scaled by 1_000_000 at compile time (Rule E2
    in docs/semantic_fragment_v2.md); the inverse is simply division.
    ``Decimal`` preserves the exact integer-micro value without FP drift.
    """
    return Decimal(int(micros)) / Decimal("1_000_000")


def _coerce_z3_value(raw: Any, *, as_micros: bool) -> Any:
    """Turn a z3 model value into a JSON-safe Python primitive.

    z3 exposes numeric values via `as_long()` on ``BitVecNumRef`` and via
    ``is_true()`` on ``BoolRef``. ``as_long()`` is preferred over ``str()``
    because it sidesteps z3's sometimes-signed, sometimes-unsigned textual
    rendering of bitvector numerals.

    When `as_micros=True`, the value is treated as a bv64 micro-unit count
    and returned as a ``Decimal`` representing the policy-native amount.
    """
    try:
        import z3 as z3mod
    except ImportError as exc:
        raise Z3Unavailable("z3-solver not installed") from exc
    if raw is None:
        return None
    # Numeric bitvector: use as_long() for a clean unsigned int.
    if isinstance(raw, z3mod.BitVecNumRef):
        val = raw.as_long()
        return _micros_to_decimal(val) if as_micros else int(val)
    # Boolean literal.
    if isinstance(raw, z3mod.BoolRef):
        # `z3.is_true(raw)` returns False for both False and Unknown; be
        # explicit so partial models don't silently become False.
        if z3mod.is_true(raw):
            return True
        if z3mod.is_false(raw):
            return False
        return None
    # Integer literal (Sum over If expressions can simplify to IntNum).
    if isinstance(raw, z3mod.IntNumRef):
        return int(raw.as_long())
    # Fallback: lexical form. Keeps extract_witness robust to z3 version
    # drift without crashing when an unexpected term type appears.
    return str(raw)


def extract_witness(
    solver: Any,
    summaries: Sequence[dict] = (),
    *,
    unroll_steps: Optional[int] = None,
) -> dict:
    """Reconstruct a SAT witness from a z3 solver that has returned SAT.

    The solver MUST have returned ``sat`` from its last ``check()`` call.
    Calling ``solver.model()`` before a successful check raises a z3
    exception; callers are responsible for the ordering. If no model is
    available, an empty witness is returned (``{"unroll_steps": N,
    "steps": []}``) so wire-format consumers don't need to guard every
    field.

    Args:
        solver:        A z3 Solver in the SAT state.
        summaries:     Per-invariant summaries from
                       ``compile_invariant_v2`` / ``compile_policy_v2``.
                       Carries the ``witness_kind`` and variable-name
                       lists needed to walk the model without parsing
                       SMT-LIB declarations.
        unroll_steps:  Optional override; otherwise read from the first
                       summary. Fragment v2 uses a single N for the
                       whole policy so summaries must agree.

    Returns:
        A dict shaped::

            {
              "unroll_steps": N,
              "steps": [
                {"t": 0, "amount": Decimal("..."),     # SpendingCap
                          "event": True,                # RollingWindowCap
                          "reject": False,              # RetryRateLimit
                          "retry": True},               # RetryRateLimit
                ...
              ],
              "per_invariant": [
                {"class": "SpendingCap", "scope": "per_window",
                 "amounts": [Decimal, ...], "total": Decimal,
                 "cap": Decimal, "unit": "USDC"},
                ...
              ],
            }

        Per-step keys are only present when at least one invariant's
        encoding covers them; callers using ``.get(...)`` see ``None``
        on absent slots. ``per_invariant`` preserves the per-invariant
        concrete assignment for richer rendering (CLI tables, reports).

    Return shape is JSON-safe via ``Decimal`` in amounts (the caller is
    responsible for str-coercing Decimals before ``json.dumps`` — the
    ``PermitWitness`` wire type in ``adapter.proof_report`` handles this).
    """
    try:
        import z3 as z3mod  # noqa: F401
    except ImportError as exc:
        raise Z3Unavailable("z3-solver not installed") from exc

    summaries = tuple(summaries)
    if not summaries:
        # Nothing to walk. Return a shape-stable empty witness.
        return {
            "unroll_steps": unroll_steps or 0,
            "steps": [],
            "per_invariant": [],
        }

    # Determine N. Every fragment-v2 invariant contributes the same N by
    # contract, so the first summary wins; if callers pass an override we
    # honour it (useful for partial-witness inspection).
    if unroll_steps is None:
        unroll_steps = int(summaries[0].get("unroll_steps", 0))

    # z3.model() will raise z3.Z3Exception if no SAT model is available.
    # We catch and return an empty-steps witness so the caller can still
    # serialise the envelope without branching on exceptions.
    try:
        model = solver.model()
    except Exception:  # noqa: BLE001 -- z3.Z3Exception isn't always importable
        return {
            "unroll_steps": unroll_steps,
            "steps": [],
            "per_invariant": [],
        }

    # Build a name -> decl lookup from the model so we don't re-declare
    # constants (z3.BitVec(name, 64) is a fresh AST node each call; we
    # need the one the solver actually put in its context).
    name_to_decl = {d.name(): d for d in model.decls()}

    # Per-step accumulator. Each dict key is a semantic name; missing
    # keys mean "no invariant touches that aspect at step t."
    steps: list[dict] = [{"t": i} for i in range(unroll_steps)]
    per_invariant: list[dict] = []

    for summary in summaries:
        kind = summary.get("witness_kind")
        if kind == "spending_cap":
            per_invariant.append(
                _witness_spending_cap(model, name_to_decl, summary, steps)
            )
        elif kind == "rolling_window_cap":
            per_invariant.append(
                _witness_rolling_window_cap(model, name_to_decl, summary, steps)
            )
        elif kind == "retry_rate_limit":
            per_invariant.append(
                _witness_retry_rate_limit(model, name_to_decl, summary, steps)
            )
        # Unknown witness_kind: skip quietly; future invariant classes
        # can add their own branch without breaking this loop.

    return {
        "unroll_steps": unroll_steps,
        "steps": steps,
        "per_invariant": per_invariant,
    }


def _lookup_value(model: Any, decls: dict, var_name: str):
    """Return the model value for ``var_name`` or ``None`` if absent.

    Z3 models only carry declarations for variables the solver actually
    constrained. A variable that appears in an assertion but never in a
    simplified conflict may not have a concrete assignment — the caller
    treats ``None`` as "don't care" (common for unused symbolic slots).
    """
    decl = decls.get(var_name)
    if decl is None:
        return None
    return model[decl]


def _witness_spending_cap(
    model: Any, decls: dict, summary: dict, steps: list[dict]
) -> dict:
    """Populate per-step ``amount`` fields from a SpendingCap summary."""
    amount_vars: list[str] = list(summary.get("amount_vars") or [])
    cap_micros = int(summary.get("max_micros", 0))
    currency = summary.get("currency", "USDC")
    amounts: list[Decimal] = []
    total_micros = 0
    for t, var_name in enumerate(amount_vars):
        raw = _lookup_value(model, decls, var_name)
        dec = _coerce_z3_value(raw, as_micros=True)
        if dec is None:
            # Z3 left this slot unconstrained. Policy still SAT; treat
            # the amount as zero in the per-step table so callers can
            # render a clean row.
            dec = Decimal("0")
            total_micros += 0
        else:
            # `dec` is the amount in currency units; add its micro-repr to
            # the running total using integer arithmetic for exactness.
            total_micros += int(dec * Decimal("1_000_000"))
        amounts.append(dec)
        # A policy may have multiple SpendingCaps; later ones overwrite
        # the step-level amount. That's fine — the per_invariant section
        # preserves each cap's own trace for audit.
        if t < len(steps):
            steps[t]["amount"] = dec
            steps[t]["currency"] = currency
    return {
        "class": "SpendingCap",
        "scope": summary.get("scope"),
        "provider": summary.get("provider"),
        "currency": currency,
        "cap": _micros_to_decimal(cap_micros),
        "amounts": amounts,
        "total": _micros_to_decimal(total_micros),
    }


def _witness_rolling_window_cap(
    model: Any, decls: dict, summary: dict, steps: list[dict]
) -> dict:
    """Populate per-step ``event`` booleans from a RollingWindowCap summary."""
    event_vars: list[str] = list(summary.get("event_vars") or [])
    max_count = int(summary.get("max_count", 0))
    events: list[bool] = []
    true_count = 0
    for t, var_name in enumerate(event_vars):
        raw = _lookup_value(model, decls, var_name)
        val = _coerce_z3_value(raw, as_micros=False)
        # Treat unconstrained booleans as False in the concrete trace.
        present = bool(val) if val is not None else False
        events.append(present)
        if present:
            true_count += 1
        if t < len(steps):
            steps[t]["event"] = present
    return {
        "class": "RollingWindowCap",
        "group_by": summary.get("group_by"),
        "max_count": max_count,
        "events": events,
        "event_count": true_count,
    }


def _witness_retry_rate_limit(
    model: Any, decls: dict, summary: dict, steps: list[dict]
) -> dict:
    """Populate per-step ``reject`` / ``retry`` booleans from a RetryRateLimit summary."""
    reject_vars: list[str] = list(summary.get("reject_vars") or [])
    retry_vars: list[str] = list(summary.get("retry_vars") or [])
    rejects: list[bool] = []
    retries: list[bool] = []
    max_len = max(len(reject_vars), len(retry_vars))
    for t in range(max_len):
        rej = False
        ret = False
        if t < len(reject_vars):
            raw = _lookup_value(model, decls, reject_vars[t])
            val = _coerce_z3_value(raw, as_micros=False)
            rej = bool(val) if val is not None else False
        if t < len(retry_vars):
            raw = _lookup_value(model, decls, retry_vars[t])
            val = _coerce_z3_value(raw, as_micros=False)
            ret = bool(val) if val is not None else False
        rejects.append(rej)
        retries.append(ret)
        if t < len(steps):
            steps[t]["reject"] = rej
            steps[t]["retry"] = ret
    return {
        "class": "RetryRateLimit",
        "min_gap_seconds": summary.get("min_gap_seconds"),
        "rejects": rejects,
        "retries": retries,
    }
