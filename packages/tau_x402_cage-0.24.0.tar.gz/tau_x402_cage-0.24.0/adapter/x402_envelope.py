"""x402 wire envelope, maps SignedEnvelope to HTTP 402 response headers + body.

RFC-draft normative surface (see docs/rfc/2026-04-x402-formal-policy-semantics.md):
    Response headers on 402/403:
        X-Policy-Verdict: permit|reject
        X-Policy-Rule-Id: <rule_id>             (present on reject)
        X-Policy-Verdict-TTL: <seconds>
        X-Policy-Intent-Hash: <hex>
        X-Policy-MAC-Alg: HMAC-SHA256|Ed25519   (legacy human-readable label)
        X-Policy-Signature-Algorithm: hmac-sha256|ed25519   (canonical id; v0.7+)
        X-Policy-Version: v1|v2

    Additional headers on v2 envelopes (MAC-bound provenance):
        X-Policy-Revision-Id: <content-addressed revision id>
        X-Policy-Proof-Backend: tau|z3|python-pattern|chained:tau->pattern
        X-Policy-Proof-Strength: complete|pattern|pattern+tau-inconclusive|...
        X-Policy-Prover-Mode: compat|verified|strict

    Response body (application/json):
        serialized SignedEnvelope (see verdict_signer.py)

The facilitator MUST verify the signature against its shared secret
(HMAC) or the cage's published public key (Ed25519) and MUST reject any
request whose intent hash does not match the cage's verdict.
"""

from __future__ import annotations

from typing import Dict, Optional, Tuple

from adapter.verdict_signer import SignedEnvelope, WIRE_VERSION_V2


#: Header name for agent-proposes / human-approves responses. Set by
#: ``to_http_headers`` when a ``proposal_id`` is provided; consumed by the
#: facilitator (or SaaS frontend) to poll ``get_proposal`` until approved.
X_POLICY_PROPOSAL_ID_HEADER = "X-Policy-Proposal-Id"


def to_http_headers(
    env: SignedEnvelope,
    proposal_id: Optional[str] = None,
) -> Dict[str, str]:
    """Emit the X-Policy-* header set for this envelope.

    v2 envelopes also emit provenance headers (revision_id, proof_backend,
    proof_strength, prover_mode). v1 envelopes emit only the core set so
    old facilitators see unchanged wire bytes.

    When ``proposal_id`` is supplied (agent-proposes / human-approves flow,
    v0.7.0), an ``X-Policy-Proposal-Id`` header is appended. This is
    additive: consumers that never opt into the approval queue see no
    change. When ``proposal_id`` is None (the default), no proposal header
    is emitted.
    """
    headers: Dict[str, str] = {
        "X-Policy-Verdict": env.outcome,
        "X-Policy-Verdict-TTL": str(env.ttl_seconds),
        "X-Policy-Intent-Hash": env.intent_hash,
        "X-Policy-MAC-Alg": env.mac_alg,
        # New in v0.7.0. Canonical signature-algorithm identifier so
        # verifiers can dispatch on a stable lower-case token instead of
        # matching the legacy `X-Policy-MAC-Alg` human label. Additive;
        # existing verifiers that only read `X-Policy-MAC-Alg` keep working.
        "X-Policy-Signature-Algorithm": env.algorithm,
        "X-Policy-MAC": env.mac_hex,
        "X-Policy-Issued-At": str(env.issued_at_unix),
        "X-Policy-Version": env.version,
    }
    if env.rule_id:
        headers["X-Policy-Rule-Id"] = env.rule_id
    if env.version == WIRE_VERSION_V2:
        # Only populate each header when the corresponding field is set; an
        # empty string header is legal HTTP but harder to debug than a
        # missing header. `None` maps to "omit this header".
        if env.policy_revision_id is not None:
            headers["X-Policy-Revision-Id"] = env.policy_revision_id
        if env.proof_backend is not None:
            headers["X-Policy-Proof-Backend"] = env.proof_backend
        if env.proof_strength is not None:
            headers["X-Policy-Proof-Strength"] = env.proof_strength
        if env.prover_mode is not None:
            headers["X-Policy-Prover-Mode"] = env.prover_mode
        # v0.13.0 safety-comparison surface: the counterfactual verdict so
        # dashboards can render with/without comparisons without a second
        # round-trip. MAC-bound inside the envelope; header is a mirror.
        if env.without_system is not None:
            headers["X-Policy-Without-System"] = env.without_system
        # v0.13.0 shadow/advisory wire surface.
        if env.mode is not None:
            headers["X-Policy-Mode"] = env.mode
        if env.shadow_would_reject:
            headers["X-Policy-Shadow-Would-Reject"] = "true"
            if env.shadow_rule_id:
                headers["X-Policy-Shadow-Rule-Id"] = env.shadow_rule_id
    if proposal_id:
        headers[X_POLICY_PROPOSAL_ID_HEADER] = proposal_id
    return headers


def to_http_response(
    env: SignedEnvelope,
    proposal_id: Optional[str] = None,
) -> Tuple[int, Dict[str, str], bytes]:
    """Build the full (status, headers, body) tuple for an HTTP response.

    Status codes follow the RFC normative guidance:
        permit → 200 (or 402/retry in the pre-settlement flow)
        reject → 403 with the envelope body explaining why

    When ``proposal_id`` is supplied, the response carries the
    ``X-Policy-Proposal-Id`` header alongside the usual provenance. The
    body shape is unchanged.
    """
    status = 200 if env.outcome == "permit" else 403
    headers = to_http_headers(env, proposal_id=proposal_id)
    headers["Content-Type"] = "application/json"
    body = env.to_json().encode("utf-8")
    return status, headers, body


def from_http_response(headers: Dict[str, str], body: bytes) -> SignedEnvelope:
    """Parse an envelope out of an HTTP response received from the cage.

    The body is the authoritative source; headers are informational. `from_json`
    handles both v1 and v2 bodies. We intentionally do not cross-check headers
    vs. body here -- the facilitator's verify() step catches any mismatch by
    MAC'ing the body.
    """
    return SignedEnvelope.from_json(body.decode("utf-8"))
