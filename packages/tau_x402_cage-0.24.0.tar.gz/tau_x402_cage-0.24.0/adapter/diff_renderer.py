"""Policy-diff renderer — v0.11.0.

Today the ``diff_revisions`` op returns raw JSON. Operators reading it
have to mentally reconstruct what changed. ``adapter.diff_renderer``
closes that ergonomic gap with two pure functions:

  * ``render_revision_diff_text(delta)`` — dense side-by-side text table.
  * ``render_revision_diff_html(delta)`` — Jinja-friendly HTML partial
    that slots into the web UI's ``/ui/revisions/diff`` page.

The renderer never mutates state and never touches the daemon; it takes
a ``{added: [...], removed: [...]}`` dict and returns a string.

Input shape
-----------
Two shapes are accepted so callers don't have to translate:

  * The ``diff_revisions`` wire shape (CLI / web UI path)::

        {"added":   [{"class": <name>, "repr_key": <python-repr-str>}, ...],
         "removed": [{"class": <name>, "repr_key": <python-repr-str>}, ...]}

    Extra keys (``a``, ``b``, ``verdict``, ``backend_changed`` ...) are
    silently ignored so a full response dict can be passed straight in.

  * The on-disk ``PolicyRevision.delta`` shape::

        {"added":   [{"class_name": <name>, "repr": {...fields...}}, ...],
         "removed": [{"class_name": <name>, "repr": {...fields...}}, ...]}

    Useful for rendering a revision's delta directly from a persisted log
    without re-running the ``diff_revisions`` op.

Row ordering is deterministic: added first by class name, then removed
by class name. Within each group rows are sorted alphabetically.
"""

from __future__ import annotations

import html
import re
from typing import Any, Dict, Iterable, List, Mapping, Optional, Tuple


# ── taxonomy: which fields show up in each invariant's scope hint ────────────


#: Compact rendering of optional fields keeps the text table narrow.
#: Unknown classes fall back to the raw repr string.
_KEY_FIELDS: Dict[str, Tuple[str, ...]] = {
    "MaxPerCall": ("max_amount", "currency"),
    "SpendingCap": ("max_amount", "currency", "scope", "window_seconds", "provider"),
    "ProviderAllowlist": ("providers",),
    "RetryRateLimit": ("min_gap_seconds",),
    "RollingWindowCap": ("max_count", "window_seconds", "group_by"),
    "CounterpartyConstraint": ("approved_ids", "sanctioned_ids"),
    "MutualExclusion": ("group_a", "group_b"),
    "JurisdictionRule": ("jurisdiction",),
}


# ── input normalisation ──────────────────────────────────────────────────────


def _coerce_entry(entry: Mapping[str, Any]) -> Tuple[str, Dict[str, Any], str]:
    """Return ``(class_name, fields_dict, repr_key_str)``.

    Accepts both the wire shape (``class`` + ``repr_key``) and the on-disk
    shape (``class_name`` + ``repr`` dict). Missing or malformed entries
    return a generic ``"unknown"`` class; we never raise because rendering
    is best-effort and the CLI / UI must tolerate partial data.
    """
    cls = str(entry.get("class") or entry.get("class_name") or "unknown")
    repr_key = entry.get("repr_key")
    fields_d: Dict[str, Any]
    repr_str: str
    if isinstance(repr_key, str):
        repr_str = repr_key
        fields_d = _parse_repr_fields(repr_key)
    else:
        raw_repr = entry.get("repr")
        if isinstance(raw_repr, Mapping):
            fields_d = dict(raw_repr)
            repr_str = _fields_to_repr_str(cls, fields_d)
        else:
            fields_d = {}
            repr_str = str(raw_repr) if raw_repr is not None else ""
    return cls, fields_d, repr_str


def _fields_to_repr_str(cls: str, fields: Mapping[str, Any]) -> str:
    """Render an on-disk repr dict as ``Class(k=v, ...)`` so the row-level
    fallback matches the wire shape. Only used when callers pass
    ``{class_name, repr}`` without a ``repr_key`` string."""
    parts = [f"{k}={v!r}" for k, v in fields.items()]
    return f"{cls}(" + ", ".join(parts) + ")"


# Very small regex-based ``repr`` parser. Repr-strings we emit follow the
# dataclass default: ``Class(field=value, field=value, ...)``. Values may
# be strings, numbers, ``Decimal('...')``, ``frozenset({...})``, tuples,
# or nested calls. We don't need a real parser because the renderer only
# needs scope-hint-quality extraction, not round-trip fidelity.
_FIELD_RE = re.compile(
    r"""
    (?P<key>[A-Za-z_][A-Za-z0-9_]*)       # field name
    \s*=\s*
    (?P<val>
        Decimal\([^)]*\)                   # Decimal('…')
      | frozenset\(\{[^}]*\}\)             # frozenset({…})
      | '[^']*'                            # single-quoted string
      | "[^"]*"                             # double-quoted string
      | -?\d+(?:\.\d+)?                     # int or float
      | True | False | None
    )
    """,
    re.VERBOSE,
)


def _parse_repr_fields(repr_str: str) -> Dict[str, Any]:
    """Extract ``field=value`` pairs from a Python repr string.

    Returns the raw value strings (``"'USDC'"``, ``"Decimal('50')"`` etc.)
    so the renderer can show them verbatim. Non-matching reprs yield ``{}``;
    callers then fall back to the full repr string.
    """
    out: Dict[str, Any] = {}
    for m in _FIELD_RE.finditer(repr_str):
        out[m.group("key")] = m.group("val")
    return out


def _prettify_value(raw: Any) -> str:
    """Strip Python repr noise so a scope hint reads cleanly.

    ``"'USDC'"`` → ``USDC``, ``"Decimal('50')"`` → ``50``,
    ``"frozenset({'a'})"`` → ``{a}``. Always returns a short string.
    """
    s = str(raw)
    m = re.fullmatch(r"Decimal\('([^']+)'\)", s)
    if m:
        return m.group(1)
    m = re.fullmatch(r"frozenset\((\{[^}]*\})\)", s)
    if m:
        inner = m.group(1)
        # Strip the outer braces and inner quotes for compactness.
        body = inner[1:-1]
        body = re.sub(r"'([^']*)'", r"\1", body)
        return "{" + body + "}"
    if len(s) >= 2 and s[0] == s[-1] and s[0] in ("'", '"'):
        return s[1:-1]
    return s


def _scope_hint(cls: str, fields: Dict[str, Any], repr_str: str) -> str:
    """Compact ``key=value`` hint for the scope column.

    Optional fields (``window_seconds``, ``provider`` on ``SpendingCap``)
    are omitted when absent so the table stays narrow. Classes not in
    ``_KEY_FIELDS`` fall back to the raw repr string.
    """
    keys = _KEY_FIELDS.get(cls)
    if not keys or not fields:
        return repr_str
    parts: List[str] = []
    for k in keys:
        if k in fields:
            parts.append(f"{k}={_prettify_value(fields[k])}")
    if not parts:
        return repr_str
    return ", ".join(parts)


# ── row collection with stable ordering ──────────────────────────────────────


def _rows(delta: Mapping[str, Any]) -> List[Dict[str, str]]:
    """Turn ``{added, removed}`` into a flat list of render-ready rows.

    Each row is ``{marker, class, scope_hint, repr_key}``. Rows are
    ordered: all additions (alphabetical by class), then all removals
    (alphabetical by class).
    """
    added_entries = list(delta.get("added") or [])
    removed_entries = list(delta.get("removed") or [])

    def _coerce_and_collect(
        entries: Iterable[Mapping[str, Any]], marker: str
    ) -> List[Dict[str, str]]:
        rows: List[Dict[str, str]] = []
        for e in entries:
            if not isinstance(e, Mapping):
                continue
            cls, fields, repr_str = _coerce_entry(e)
            rows.append({
                "marker": marker,
                "class": cls,
                "scope_hint": _scope_hint(cls, fields, repr_str),
                "repr_key": repr_str,
            })
        rows.sort(key=lambda r: (r["class"], r["scope_hint"]))
        return rows

    return _coerce_and_collect(added_entries, "+") + _coerce_and_collect(
        removed_entries, "-"
    )


# ── public renderers ─────────────────────────────────────────────────────────


def render_revision_diff_text(delta: Mapping[str, Any]) -> str:
    """Dense text table describing what changed between two revisions.

    Empty deltas yield a single ``no changes`` line so scripts can grep
    for that sentinel. Otherwise the output is a 3-column fixed-width
    table (``+/-``, class, scope hint).
    """
    rows = _rows(delta)
    meta_line = _meta_line(delta)
    if not rows:
        if meta_line:
            return meta_line + "\nno changes\n"
        return "no changes\n"
    class_w = max(len(r["class"]) for r in rows)
    class_w = max(class_w, len("class"))
    header = f"  {'class':<{class_w}}  scope"
    sep = "  " + ("-" * class_w) + "  " + ("-" * 40)
    lines: List[str] = []
    if meta_line:
        lines.append(meta_line)
    lines.append(header)
    lines.append(sep)
    for r in rows:
        lines.append(
            f"{r['marker']} {r['class']:<{class_w}}  {r['scope_hint']}"
        )
    lines.append("")  # trailing newline for POSIX-friendly output
    return "\n".join(lines)


def _meta_line(delta: Mapping[str, Any]) -> str:
    """One-line summary if the caller handed us a full ``diff_revisions``
    response rather than just the delta. Silent when the metadata is missing."""
    a = delta.get("a") if isinstance(delta, Mapping) else None
    b = delta.get("b") if isinstance(delta, Mapping) else None
    if not isinstance(a, Mapping) or not isinstance(b, Mapping):
        return ""
    a_id = a.get("revision_id", "?")
    b_id = b.get("revision_id", "?")
    bc = " backend-changed" if delta.get("backend_changed") else ""
    mc = " mode-changed" if delta.get("mode_changed") else ""
    return f"diff {a_id} -> {b_id}{bc}{mc}"


def render_revision_diff_html(delta: Mapping[str, Any]) -> str:
    """Jinja-free HTML partial renderer.

    Returns a ``<table class="dense diff-table">…</table>`` block that
    fits inside the web UI's ``revision_diff.html`` page. Emits
    ``tr.added`` / ``tr.removed`` classes so the host template's CSS can
    colour rows without knowing the underlying row shape.
    """
    rows = _rows(delta)
    meta_line = _meta_line(delta)
    meta_html = f'<p class="diff-meta">{html.escape(meta_line)}</p>' if meta_line else ""
    if not rows:
        return meta_html + '<p class="empty">no changes</p>'
    body_rows: List[str] = []
    for r in rows:
        css = "added" if r["marker"] == "+" else "removed"
        body_rows.append(
            "<tr class=\"{css}\">"
            "<td class=\"marker\">{marker}</td>"
            "<td class=\"cls\">{cls}</td>"
            "<td class=\"scope\">{scope}</td>"
            "</tr>".format(
                css=css,
                marker=html.escape(r["marker"]),
                cls=html.escape(r["class"]),
                scope=html.escape(r["scope_hint"]),
            )
        )
    return (
        meta_html
        + '<table class="dense diff-table">'
        "<thead><tr><th>&plusmn;</th><th>class</th><th>scope</th></tr></thead>"
        "<tbody>" + "".join(body_rows) + "</tbody>"
        "</table>"
    )
