"""Risk-dashboard primitives: mutation-failure log + active-constraints view
(v0.15.0).

The risk dashboard surfaces four things the safety-layer spec asks for:

    1. prevented risk       — already served by /ui/safety
    2. active guarantees    — already served by /ui/guarantees
    3. mutation failures    — this module
    4. active constraints   — this module

This file is the read-only primitives for #3 and #4:

*   ``MutationFailureLog`` is an in-memory ring buffer the daemon appends to
    every time a mutation op (``add_invariant`` / ``remove_invariant`` /
    ``update_invariant`` / ``approve_proposal``) produces a rejection or
    error verdict. It is deliberately lightweight: no persistence, no wire
    hook, no webhook fan-out. The dashboard is the consumer.

*   ``active_constraints()`` is a pure function over an ``X402Registry``
    that returns a compact per-class summary: how many rules of each class
    are in force and the top-5 scope hints (``MaxPerCall(max=100 USDC)``
    etc.). The summaries reuse the same scope-hint language the daemon's
    ``inspect_policy`` op already ships, kept in sync via the shared
    ``_scope_hint`` helper at the bottom of this file.

Design notes:

*   Every dataclass is ``frozen=True`` so callers can snapshot and share
    references without mutation hazards. The ring buffer is the only
    mutable surface and it guards append/read under a single lock.
*   Top-5 scope hints is a hard cap rather than a quota per class — a
    deployment with 300 SpendingCaps still produces a 5-item summary
    list, not 300. Dashboards rendering this must never scroll a per-
    class panel.
*   Category strings are documented in the module docstring below and
    enumerated as a ``Literal`` so typos fail at import time.

See ``docs/safety_comparison.md`` (risk-signals section) for the narrative.
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Literal, Mapping, Optional, Sequence, Tuple

from adapter.invariants import (
    CounterpartyConstraint,
    Invariant,
    JurisdictionRule,
    MaxPerCall,
    MutualExclusion,
    ProviderAllowlist,
    RetryRateLimit,
    RollingWindowCap,
    SpendingCap,
)

# ── categories ──────────────────────────────────────────────────────────────

#: Category taxonomy for ``MutationFailureEntry.category``.
#:
#:  * ``cross_revision_violation`` — an append was rejected by a
#:    cross-revision compositional invariant (e.g. NoWeakening).
#:  * ``governance_violation`` — mutation-governance axes 1/3/4 said no
#:    (actor not authorized, temporal bounds exceeded, strict-mode
#:    required).
#:  * ``prover_contradiction`` — the declare-time prover chain returned
#:    a ``Contradiction``.
#:  * ``prover_inconclusive`` — strict mode + an ``InconclusiveProof``.
#:  * ``bad_invariant`` — the wire shape failed to build a valid
#:    invariant object (validation error).
MutationFailureCategory = Literal[
    "cross_revision_violation",
    "governance_violation",
    "prover_contradiction",
    "prover_inconclusive",
    "bad_invariant",
]

_ALLOWED_CATEGORIES: Tuple[MutationFailureCategory, ...] = (
    "cross_revision_violation",
    "governance_violation",
    "prover_contradiction",
    "prover_inconclusive",
    "bad_invariant",
)


# ── MutationFailureEntry ────────────────────────────────────────────────────


@dataclass(frozen=True)
class MutationFailureEntry:
    """One rejected mutation op recorded on the daemon's risk timeline.

    Fields:
        timestamp_unix: unix seconds when the rejection was recorded.
        op: the daemon op that failed (``add_invariant``,
            ``remove_invariant``, ``update_invariant``, or
            ``approve_proposal``).
        actor_id: governance actor id when present on the request,
            ``None`` for anonymous/legacy calls.
        category: the taxonomy label (see ``MutationFailureCategory``).
        reason: short human-readable message; already surfaced in the
            wire rejection envelope.
        mutation_risk: the strict-mutation-contract risk level when the
            daemon surfaced one (``low`` / ``medium`` / ``high``).
            ``None`` for early-fail categories like ``bad_invariant``
            that never reach the central mutation path.
        affected_scope: the strict-mutation-contract affected-scope dict
            if present, else an empty mapping.
    """

    timestamp_unix: int
    op: str
    actor_id: Optional[str]
    category: MutationFailureCategory
    reason: str
    mutation_risk: Optional[str] = None
    affected_scope: Mapping[str, Any] = field(default_factory=dict)

    def to_wire(self) -> Dict[str, Any]:
        """JSON-safe serialisation for the daemon op response."""
        return {
            "timestamp_unix": self.timestamp_unix,
            "op": self.op,
            "actor_id": self.actor_id,
            "category": self.category,
            "reason": self.reason,
            "mutation_risk": self.mutation_risk,
            "affected_scope": dict(self.affected_scope),
        }


# ── MutationFailureLog (in-memory ring buffer) ──────────────────────────────


class MutationFailureLog:
    """Bounded, thread-safe, in-memory ring buffer of mutation failures.

    The daemon holds one instance. Every mutation rejection path calls
    ``append(entry)``; the dashboard + CLI call ``recent()`` to read the
    tail.

    Capacity defaults to 500 — enough to render a day of operator-grade
    mutation churn without turning the daemon into a log shipper. The
    underlying store is a ``list`` guarded by a ``Lock``; we keep the
    implementation deliberately uncomplicated so the hot-path cost is
    one append plus a lock/unlock cycle.
    """

    def __init__(self, cap: int = 500) -> None:
        if not isinstance(cap, int) or cap < 1:
            raise ValueError(f"cap must be a positive int, got {cap!r}")
        self._cap = cap
        self._entries: List[MutationFailureEntry] = []
        self._lock = threading.Lock()

    @property
    def cap(self) -> int:
        return self._cap

    def __len__(self) -> int:
        with self._lock:
            return len(self._entries)

    def append(self, entry: MutationFailureEntry) -> None:
        """Record one rejection. Oldest entry is dropped once cap is hit."""
        if not isinstance(entry, MutationFailureEntry):
            raise TypeError(
                f"append() expects MutationFailureEntry, got {type(entry).__name__}"
            )
        with self._lock:
            self._entries.append(entry)
            overflow = len(self._entries) - self._cap
            if overflow > 0:
                # Drop oldest N so the buffer stays at cap. Using a slice
                # is O(n) but n is small (<= cap) and the alternative
                # (deque) loses the since-filter's indexability.
                del self._entries[:overflow]

    def recent(
        self,
        limit: int = 50,
        since_unix: Optional[int] = None,
        category: Optional[str] = None,
    ) -> Tuple[MutationFailureEntry, ...]:
        """Return the most recent entries, newest-first.

        Args:
            limit: maximum number of entries to return. Must be >= 1.
            since_unix: when set, only entries with
                ``timestamp_unix >= since_unix`` are returned.
            category: when set, only entries with matching ``category``
                are returned. Unknown categories return an empty tuple
                (silent filter; no exception).
        """
        if not isinstance(limit, int) or limit < 1:
            raise ValueError(f"limit must be >= 1, got {limit!r}")
        with self._lock:
            snapshot = tuple(self._entries)
        filtered: List[MutationFailureEntry] = []
        for e in reversed(snapshot):
            if since_unix is not None and e.timestamp_unix < since_unix:
                continue
            if category is not None and e.category != category:
                continue
            filtered.append(e)
            if len(filtered) >= limit:
                break
        return tuple(filtered)

    def clear(self) -> None:
        """Drop every recorded entry. Test support; not called by the daemon."""
        with self._lock:
            self._entries.clear()


# ── ActiveConstraint ────────────────────────────────────────────────────────


@dataclass(frozen=True)
class ActiveConstraint:
    """One row of the /ui/safety active-constraints panel.

    Fields:
        class_name: invariant class (``SpendingCap``, ``MaxPerCall`` …).
        count: number of instances of that class currently in force.
        summaries: top 5 human-readable scope hints across the group.
            Capped at 5 so the dashboard row stays scannable even on
            large policies.
        fragment: semantic fragment the class belongs to (``v1`` or
            ``v2``). Derived from the lazy fragment registry in
            ``adapter.z3_compiler``.
    """

    class_name: str
    count: int
    summaries: Tuple[str, ...]
    fragment: Literal["v1", "v2"]

    def to_wire(self) -> Dict[str, Any]:
        return {
            "class_name": self.class_name,
            "count": self.count,
            "summaries": list(self.summaries),
            "fragment": self.fragment,
        }


_TOP_SUMMARIES_PER_CLASS = 5


def active_constraints(registry: Any) -> Tuple[ActiveConstraint, ...]:
    """Enumerate the constraints the cage is currently enforcing.

    Groups the registry's invariants by class, tags each group with its
    fragment (``v1``/``v2``), and records the top 5 scope hints per class
    so the /ui/safety active-constraints panel can render one row per
    class without overflowing on a large deployment.

    Deterministic ordering: groups are sorted alphabetically by
    ``class_name`` so repeated calls return byte-identical wire payloads
    (important for snapshot tests and JSON-diff-based audit tooling).
    """
    if registry is None:
        return ()
    invariants = getattr(registry, "invariants", ())
    if not invariants:
        return ()
    grouped: Dict[str, List[Invariant]] = {}
    for inv in invariants:
        grouped.setdefault(type(inv).__name__, []).append(inv)

    result: List[ActiveConstraint] = []
    for class_name in sorted(grouped.keys()):
        members = grouped[class_name]
        summaries = tuple(
            _scope_hint(inv) for inv in members[:_TOP_SUMMARIES_PER_CLASS]
        )
        fragment = _classify_fragment(members[0])
        result.append(
            ActiveConstraint(
                class_name=class_name,
                count=len(members),
                summaries=summaries,
                fragment=fragment,
            )
        )
    return tuple(result)


# ── scope-hint helper ───────────────────────────────────────────────────────


def _scope_hint(inv: Any) -> str:
    """Return a compact one-line description of ``inv``'s scope.

    Mirrors ``daemon.server._scope_hint_for`` so the dashboard and
    ``inspect_policy`` speak the same language. Duplicated (rather than
    imported) to keep the daemon → adapter dependency direction
    unidirectional.
    """
    if isinstance(inv, MaxPerCall):
        return f"max={inv.max_amount} {inv.currency}"
    if isinstance(inv, SpendingCap):
        parts = [f"max={inv.max_amount} {inv.currency}", f"scope={inv.scope}"]
        if inv.window_seconds is not None:
            parts.append(f"window={inv.window_seconds}s")
        if inv.provider is not None:
            parts.append(f"provider={inv.provider}")
        return ", ".join(parts)
    if isinstance(inv, ProviderAllowlist):
        return f"providers={sorted(inv.providers)}"
    if isinstance(inv, RetryRateLimit):
        return f"min_gap={inv.min_gap_seconds}s"
    if isinstance(inv, RollingWindowCap):
        return (
            f"max_count={inv.max_count}, "
            f"window={inv.window_seconds}s, group_by={inv.group_by}"
        )
    if isinstance(inv, CounterpartyConstraint):
        approved = sorted(inv.approved_ids)
        sanctioned = sorted(inv.sanctioned_ids)
        return f"approved={approved}, sanctioned={sanctioned}"
    if isinstance(inv, MutualExclusion):
        return f"group_a={sorted(inv.group_a)}, group_b={sorted(inv.group_b)}"
    if isinstance(inv, JurisdictionRule):
        return (
            f"jurisdiction={inv.jurisdiction}, "
            f"inner={len(inv.additional_invariants)}"
        )
    return repr(inv)


def _classify_fragment(inv: Any) -> Literal["v1", "v2"]:
    """Best-effort fragment classification.

    Uses the ``is_fragment_v2_invariant`` helper so the result matches
    what the admission path actually routes. Anything that isn't v2 is
    labelled v1 — the cage only ships two fragments today.
    """
    try:
        from adapter.z3_compiler import is_fragment_v2_invariant
    except ImportError:  # pragma: no cover - z3 optional at import
        return "v1"
    return "v2" if is_fragment_v2_invariant(inv) else "v1"


# ── helper for classifying daemon-side rejections ───────────────────────────


def classify_rejection(verdict: Mapping[str, Any]) -> Optional[MutationFailureCategory]:
    """Map a rejection payload onto a MutationFailureCategory.

    Looks at the ``category`` field first (the daemon already tags
    cross-revision and governance paths) and falls back to ``verdict``
    for the prover taxonomy. Returns ``None`` if the payload is a
    success or an untracked category so callers can skip the log
    append cleanly.
    """
    if not isinstance(verdict, Mapping):
        return None
    cat = verdict.get("category")
    if cat == "cross_revision_violation":
        return "cross_revision_violation"
    if cat == "governance_violation":
        return "governance_violation"
    if cat == "bad_invariant":
        return "bad_invariant"
    v = verdict.get("verdict")
    if v == "contradiction":
        return "prover_contradiction"
    if v == "inconclusive":
        return "prover_inconclusive"
    return None
