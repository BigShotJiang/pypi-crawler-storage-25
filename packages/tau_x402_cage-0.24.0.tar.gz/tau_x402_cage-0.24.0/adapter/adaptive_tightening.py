"""Policy-aware adaptive tightening (v0.21.0) — Flexible Mode only.

The cage already tightens per-provider via ``InstabilityGuard`` and the
aggregate ``RuntimeGuard.tightening_level`` surface. Both of those work
at the *per-invariant* or *per-provider* grain. Adaptive tightening
answers the next question up the stack: **as an agent behaves badly in
aggregate (retry floods, identical-request hammering, denial-heavy
windows, velocity spikes), can the cage temporarily clamp the *whole*
policy envelope tighter — without ever weakening it — and then relax
back to baseline when the bad behaviour subsides?**

This module adds exactly that, as a bounded-decay runtime view over
the registered policy. Four non-negotiable properties:

1. **Policy-aware** — ``adjusted_limit`` NEVER returns a value more
   permissive than ``baseline``. Spend caps shrink. Cooldowns grow.
   Retry allowances shrink. Tightening is monotonic in the right
   direction, no matter what mix of triggers fire.
2. **Bounded** — ``level`` is clamped to ``[0.0, 1.0]``. The level
   update rule is additive-with-saturation:

       level'(t0) = min(1.0, level(t0⁻) + Σ trigger_deltas(t0))

   Multiple triggers at the same observation combine additively up to
   the saturation bound — *never* multiplicatively. This is the "this
   isn't just rate limiting" property: rate limiting fires on one
   signal; adaptive tightening composes over many.
3. **Decaying** — between observations the level exponentially decays
   back to baseline (default half-life 900s):

       level(t) = level(t0) * 0.5 ** ((t - t0) / half_life)

   The policy sits on top; the transient clamp rides over it.
4. **Deterministic** — state is keyed on ``(agent_id, policy_revision_id)``.
   Same observation sequence → identical state. No randomness. No
   wall-clock access inside ``current_state`` / ``adjusted_limit`` /
   ``observe``; callers pass ``now_unix``.

Policy mutation stance
----------------------
Tightening state is a **view** over the policy, never a rewrite. We
never mutate ``PolicyRevision`` / ``Registry`` / invariants from inside
this module. ``NoWeakening`` and the cross-revision validator are
untouched. Callers read the current tightening state alongside the
baseline policy and ask ``adjusted_limit`` to pick the stricter of the
two for enforcement.

Guaranteed Mode alignment (option a, per brief)
-----------------------------------------------
``adaptive_tightening`` is intentionally EXCLUDED from
``GUARANTEED_RUNTIME_FEATURES`` in ``adapter/guaranteed_runtime.py``.
A Guaranteed Mode call observing active tightening state **ignores**
the tightening view: the bank tier enforces the policy-revision baseline
only, so the totality proof's admission envelope stays inside the
revision's stated commitments. Flexible Mode layers adaptive tightening
on top as an *advisory* extra clamp; the Guaranteed floor is preserved.

Rationale: tightening would make Guaranteed Mode stricter (never more
permissive), so ignoring it can only UNDER-block relative to Flexible
Mode. The bank-tier totality proof still holds; adding the clamp would
require a richer runtime-state model than v1.1.0 ships. Option (b)
(deny with RUNTIME_EVALUATION_UNAVAILABLE) would spuriously reject
otherwise-admissible intents; that's a worse failure mode for a bank.

Contrast with rate limiting
---------------------------
Rate limiters hold *one* fixed threshold per signal. Adaptive
tightening:

  * composes over FOUR observation classes (retry density, denial
    rate, velocity spikes, identical-request hammering),
  * adjusts the *multiple* underlying caps simultaneously
    (spend caps, cooldowns, retry allowances),
  * decays deterministically when the bad behaviour stops,
  * and is bounded in both magnitude and duration by published
    formulae.

Under *ordinary* traffic patterns tightening sits at ``level=0`` and
is indistinguishable from the un-tightened path. Under pathological
bursts it fires, then relaxes deterministically.
"""
from __future__ import annotations

import hashlib
import json
import math
from dataclasses import dataclass, field
from decimal import Decimal
from typing import Any, Dict, Mapping, Optional, Tuple


# ── public constants ────────────────────────────────────────────────────────


#: Exponential-decay half-life in seconds. After this many seconds with
#: no fresh triggering observation, ``level`` halves.
DEFAULT_HALF_LIFE_SECONDS: int = 900

#: Per-trigger delta applied to ``level`` when the trigger's threshold
#: is crossed. Additive-with-saturation: multiple triggers at the same
#: observation sum their deltas but the total is clamped to ``1.0``.
#: Tuned so any single trigger caps the agent at a moderate clamp
#: (level ~= 0.4) on first fire; two triggers together push toward
#: the saturation bound (0.8); three+ triggers saturate at 1.0.
DEFAULT_TRIGGER_DELTAS: Mapping[str, float] = {
    "retry_density": 0.40,
    "denial_rate": 0.30,
    "velocity_spike": 0.35,
    "identical_request": 0.35,
}

#: Default thresholds. Callers can override any subset; unspecified keys
#: fall back to these.
#:
#:   retry_density_per_min:  per-agent retry count in the last minute
#:                           at which the retry_density trigger fires.
#:   denial_rate:            share (in [0,1]) of recent decisions that
#:                           denied, above which the trigger fires.
#:   velocity_multiplier:    current spend velocity exceeds this × the
#:                           EMA baseline. Dimensionless.
#:   identical_count:        how many identical-fingerprint intents
#:                           inside ``identical_window_seconds``.
#:   identical_window_seconds: window for the identical-request counter.
#:   decision_window:        how many recent decisions to consider for
#:                           the denial-rate trigger.
DEFAULT_TRIGGER_THRESHOLDS: Mapping[str, float] = {
    "retry_density_per_min": 10.0,
    "denial_rate": 0.30,
    "velocity_multiplier": 3.0,
    "identical_count": 4.0,
    "identical_window_seconds": 30.0,
    "decision_window": 20.0,
}

#: Lower bound below which ``level`` is treated as zero. Keeps
#: numerical noise from eternally-tiny clamps.
_LEVEL_FLOOR: float = 1e-6


# ── state dataclass ─────────────────────────────────────────────────────────


@dataclass(frozen=True)
class TighteningState:
    """Snapshot of an agent's adaptive-tightening state at a moment in time.

    Frozen by construction — consumers that need an updated view call
    ``current_state`` again with a fresh ``now_unix``. The dataclass is
    the wire-stable shape for the decision envelope's new fields.

    Attributes:
        agent_id: the agent the state belongs to. Stored so downstream
            dashboards can group per-agent without a second lookup.
        policy_revision_id: the policy revision the state is paired
            with. Tightening is scoped to a revision so a policy
            mutation implicitly resets the clamp (by keying under a
            new revision_id the state bucket is fresh).
        level: tightening level in ``[0.0, 1.0]``. 0.0 is baseline;
            1.0 is maximum clamp. Never outside this range.
        last_update_unix: unix timestamp of the last observation that
            changed the state. Used to compute decay between calls.
        trigger: the most-recent triggering event name (or ``None`` if
            the state is at baseline). One of:
            ``"retry_density"``, ``"denial_rate"``, ``"velocity_spike"``,
            ``"identical_request"``.
        adjusted_limits: concrete (cap/cooldown/retry) adjustments
            currently in force. Always ``<=`` the caller's baseline for
            the same keys. Empty when ``level <= _LEVEL_FLOOR``.
    """

    agent_id: str
    policy_revision_id: str
    level: float
    last_update_unix: int
    trigger: Optional[str] = None
    adjusted_limits: Mapping[str, Any] = field(default_factory=dict)

    def to_wire(self) -> Dict[str, Any]:
        """JSON-safe projection for envelope / MCP consumers."""
        return {
            "agent_id": self.agent_id,
            "policy_revision_id": self.policy_revision_id,
            "level": float(self.level),
            "last_update_unix": int(self.last_update_unix),
            "trigger": self.trigger,
            "adjusted_limits": {
                k: (str(v) if isinstance(v, Decimal) else v)
                for k, v in self.adjusted_limits.items()
            },
        }


# ── core class ───────────────────────────────────────────────────────────────


class AdaptiveTightening:
    """Bounded, decaying, deterministic adaptive response to risky behavior.

    - **Bounded**: ``level`` is clamped to ``[0.0, 1.0]``.
      ``adjusted_limit`` output ``<=`` baseline (for caps, retry counts)
      or ``>=`` baseline (for cooldowns / gaps — monotonic in the
      tightening direction).
    - **Decaying**: between observations, ``level(t) = level(t0) * 0.5 **
      ((t - t0) / half_life)``.
    - **Deterministic**: identical observation sequence → identical
      final state. No randomness. No internal wall-clock access.
    - **Policy-aware**: ``adjusted_limit`` NEVER returns a value more
      permissive than ``baseline``. Tightening never weakens.

    Thread-safety: this class is NOT thread-safe. The daemon owns a
    single instance and funnels observations through its existing
    single-writer loop; concurrent callers must synchronise externally.
    """

    def __init__(
        self,
        *,
        half_life_seconds: int = DEFAULT_HALF_LIFE_SECONDS,
        trigger_thresholds: Optional[Mapping[str, float]] = None,
        trigger_deltas: Optional[Mapping[str, float]] = None,
    ) -> None:
        if half_life_seconds <= 0:
            raise ValueError(
                f"half_life_seconds must be > 0, got {half_life_seconds}"
            )
        thresholds = dict(DEFAULT_TRIGGER_THRESHOLDS)
        if trigger_thresholds:
            for k, v in trigger_thresholds.items():
                thresholds[k] = float(v)
        deltas = dict(DEFAULT_TRIGGER_DELTAS)
        if trigger_deltas:
            for k, v in trigger_deltas.items():
                if v < 0:
                    raise ValueError(
                        f"trigger_deltas[{k!r}] must be >= 0, got {v}"
                    )
                deltas[k] = float(v)

        self._half_life = int(half_life_seconds)
        self._thresholds: Dict[str, float] = thresholds
        self._deltas: Dict[str, float] = deltas

        # Per-(agent, revision) mutable state. We store a tiny dict
        # rather than a TighteningState because callers often recompute
        # adjusted_limits against different baselines and we don't want
        # to keep stale concrete limits around. Values are:
        #   {
        #     "level": float,          # current level
        #     "last_update_unix": int, # time of last mutation
        #     "trigger": Optional[str],
        #     "identical_fingerprints": dict[str, list[int]],
        #     "recent_decisions": list[tuple[int, str]],  # (ts, "allow"|"deny")
        #     "ema_velocity": float,   # decimal-safe float projection
        #     "retry_events": list[int],  # retry timestamps
        #   }
        self._store: Dict[Tuple[str, str], Dict[str, Any]] = {}

    # ── properties ──────────────────────────────────────────────────────────

    @property
    def half_life_seconds(self) -> int:
        return self._half_life

    @property
    def trigger_thresholds(self) -> Mapping[str, float]:
        return dict(self._thresholds)

    @property
    def trigger_deltas(self) -> Mapping[str, float]:
        return dict(self._deltas)

    # ── observation API ─────────────────────────────────────────────────────

    def observe(
        self,
        *,
        event: str,
        context: Mapping[str, Any],
        now_unix: int,
    ) -> None:
        """Record an event and possibly raise the tightening level.

        ``event`` is one of:
            - ``"retry"``: a retry was attempted. Context must carry
              ``agent_id`` and ``policy_revision_id``. Retry timestamps
              are retained for the retry-density trigger.
            - ``"decision"``: a cage decision was issued. Context must
              carry ``agent_id``, ``policy_revision_id``, and
              ``outcome`` ("allow" | "deny"). Feeds the denial-rate
              trigger.
            - ``"payment_intent"``: a payment intent was observed.
              Context must carry ``agent_id``, ``policy_revision_id``,
              and ``intent`` (mapping with ``amount``, ``provider``,
              ``counterparty``, ``currency``). Feeds the velocity and
              identical-request triggers.
            - ``"external_trigger"``: a caller forces a specific
              trigger. Context must carry ``agent_id``,
              ``policy_revision_id``, and ``trigger`` (one of the
              four known triggers). Used for testing / hand-overrides.

        Missing context keys short-circuit silently — the caller must
        not be in the business of throwing exceptions down the hot
        path, and an observation we cannot interpret simply contributes
        zero to the state.

        No wall-clock access: callers pass ``now_unix``.
        """
        agent_id = context.get("agent_id")
        policy_revision_id = context.get("policy_revision_id")
        if not isinstance(agent_id, str) or not isinstance(policy_revision_id, str):
            return
        if not agent_id or not policy_revision_id:
            return

        bucket = self._bucket(agent_id, policy_revision_id, now_unix=now_unix)

        if event == "retry":
            bucket["retry_events"].append(int(now_unix))
            self._prune_retry_events(bucket, now_unix=now_unix)
            if self._retry_density_triggered(bucket, now_unix=now_unix):
                self._raise_level(bucket, "retry_density", now_unix=now_unix)
            return

        if event == "decision":
            outcome = context.get("outcome")
            if outcome not in ("allow", "deny"):
                return
            bucket["recent_decisions"].append((int(now_unix), outcome))
            self._prune_decisions(bucket)
            if outcome == "deny" and self._denial_rate_triggered(bucket):
                self._raise_level(bucket, "denial_rate", now_unix=now_unix)
            return

        if event == "payment_intent":
            intent = context.get("intent")
            if not isinstance(intent, Mapping):
                return
            try:
                amount = Decimal(str(intent.get("amount", "0")))
            except Exception:  # noqa: BLE001 — defensive.
                return
            if amount < 0:
                return
            # Identical-request trigger fires on the fingerprint count
            # BEFORE the current intent is recorded, so the threshold
            # is crossed by the N-th (not N+1-th) observation.
            fingerprint = _fingerprint(intent)
            timestamps = bucket["identical_fingerprints"].setdefault(
                fingerprint, []
            )
            window = int(self._thresholds["identical_window_seconds"])
            cutoff = int(now_unix) - window
            # Prune old entries for this fingerprint before counting.
            timestamps[:] = [t for t in timestamps if t >= cutoff]
            count_before = len(timestamps)
            timestamps.append(int(now_unix))
            if count_before + 1 >= int(self._thresholds["identical_count"]):
                self._raise_level(
                    bucket, "identical_request", now_unix=now_unix
                )
            # Garbage-collect stale fingerprints to keep the store small.
            self._prune_fingerprints(bucket, now_unix=now_unix)
            # Velocity trigger: amount contributes to the EMA; a spike
            # is current velocity >= N × EMA baseline.
            ema = float(bucket["ema_velocity"])
            current = float(amount)
            # Alpha = 0.25 gives a short but smooth average over the
            # last ~4 observations. Full derivation in the module docs.
            alpha = 0.25
            new_ema = alpha * current + (1.0 - alpha) * ema
            # Spike check uses the OLD EMA so the first N intents don't
            # self-congratulate.
            multiplier = float(self._thresholds["velocity_multiplier"])
            if (
                ema > 0.0
                and current >= multiplier * ema
                and current > 0.0
            ):
                self._raise_level(bucket, "velocity_spike", now_unix=now_unix)
            bucket["ema_velocity"] = new_ema
            return

        if event == "external_trigger":
            trigger = context.get("trigger")
            if trigger in self._deltas:
                self._raise_level(bucket, trigger, now_unix=now_unix)
            return

        # Unknown event → silent no-op.

    # ── state read API ──────────────────────────────────────────────────────

    def current_state(
        self,
        *,
        agent_id: str,
        policy_revision_id: str,
        now_unix: int,
        baseline_limits: Mapping[str, Any],
    ) -> TighteningState:
        """Return the current TighteningState after applying decay.

        No wall-clock access. No mutation: this method is safe to call
        from read-only code paths. It materialises the decayed level and
        derives ``adjusted_limits`` against ``baseline_limits``.

        ``baseline_limits`` carries the keys the caller wants adjusted.
        Known semantics (any subset may be present):

          * ``max_requests``: int — retry/call allowance. Shrinks.
          * ``max_amount`` / ``max_cumulative``: Decimal/numeric — spend
            caps. Shrink.
          * ``cooldown_seconds`` / ``min_gap_seconds``: int — cooldown
            or retry gap. GROWS with tightening (longer cooldown =
            stricter).
          * ``window_seconds``: int — passthrough (not adjusted).
        """
        bucket = self._store.get((agent_id, policy_revision_id))
        if bucket is None:
            return TighteningState(
                agent_id=agent_id,
                policy_revision_id=policy_revision_id,
                level=0.0,
                last_update_unix=int(now_unix),
                trigger=None,
                adjusted_limits={},
            )

        level = self._decayed_level(bucket, now_unix=now_unix)
        if level <= _LEVEL_FLOOR:
            return TighteningState(
                agent_id=agent_id,
                policy_revision_id=policy_revision_id,
                level=0.0,
                last_update_unix=int(bucket["last_update_unix"]),
                trigger=None,
                adjusted_limits={},
            )

        adjusted: Dict[str, Any] = {}
        proxy_state = TighteningState(
            agent_id=agent_id,
            policy_revision_id=policy_revision_id,
            level=level,
            last_update_unix=int(bucket["last_update_unix"]),
            trigger=bucket.get("trigger"),
            adjusted_limits={},
        )
        for name, baseline in baseline_limits.items():
            adjusted[name] = self.adjusted_limit(
                name=name, baseline=baseline, state=proxy_state
            )
        return TighteningState(
            agent_id=agent_id,
            policy_revision_id=policy_revision_id,
            level=level,
            last_update_unix=int(bucket["last_update_unix"]),
            trigger=bucket.get("trigger"),
            adjusted_limits=adjusted,
        )

    def adjusted_limit(
        self,
        *,
        name: str,
        baseline: Any,
        state: TighteningState,
    ) -> Any:
        """Return the tightened limit for ``name`` given ``state.level``.

        Policy-respecting: the returned value is NEVER more permissive
        than ``baseline``. Monotonicity rules:

          * Shrinking limits (caps, retry counts): returned value is in
            ``[baseline * (1 - level), baseline]`` — smaller = stricter.
          * Growing limits (cooldowns, min-gaps): returned value is in
            ``[baseline, baseline * (1 + level) + 1]`` — larger =
            stricter. Always rounded up by at least 1 when
            ``level > 0`` so the clamp is visible at tiny baselines.
          * Unknown keys: returned as-is (no opinion).

        The returned type mirrors the input: ``int`` stays ``int``,
        ``Decimal`` stays ``Decimal``, ``float`` stays ``float``.
        """
        if state.level <= _LEVEL_FLOOR:
            return baseline
        level = min(1.0, max(0.0, float(state.level)))
        # Keys that SHRINK with tightening.
        shrink_keys = {
            "max_requests",
            "max_amount",
            "max_cumulative",
            "max_per_call",
            "spend_cap",
            "retry_allowance",
            "burst_threshold",
            "cap",
        }
        # Keys that GROW with tightening.
        grow_keys = {
            "cooldown_seconds",
            "min_gap_seconds",
            "backoff_seconds",
        }

        if name in shrink_keys:
            return _shrink(baseline, level)
        if name in grow_keys:
            return _grow(baseline, level)
        # Unknown key: conservative no-op (do not silently mutate).
        return baseline

    # ── helpers ─────────────────────────────────────────────────────────────

    def _bucket(
        self,
        agent_id: str,
        policy_revision_id: str,
        *,
        now_unix: int,
    ) -> Dict[str, Any]:
        """Fetch-or-create the mutable state bucket for a key."""
        key = (agent_id, policy_revision_id)
        existing = self._store.get(key)
        if existing is not None:
            # Decay before any mutation so observation-time deltas
            # compose with the correct current level.
            existing["level"] = self._decayed_level(
                existing, now_unix=now_unix
            )
            return existing
        fresh: Dict[str, Any] = {
            "level": 0.0,
            "last_update_unix": int(now_unix),
            "trigger": None,
            "identical_fingerprints": {},
            "recent_decisions": [],
            "ema_velocity": 0.0,
            "retry_events": [],
        }
        self._store[key] = fresh
        return fresh

    def _decayed_level(
        self,
        bucket: Mapping[str, Any],
        *,
        now_unix: int,
    ) -> float:
        """Exponential decay: ``level(t) = level0 * 0.5 ** (dt / half_life)``."""
        last = int(bucket["last_update_unix"])
        current = float(bucket["level"])
        if current <= _LEVEL_FLOOR:
            return 0.0
        dt = max(0, int(now_unix) - last)
        if dt == 0:
            return current
        factor = math.pow(0.5, dt / float(self._half_life))
        decayed = current * factor
        if decayed <= _LEVEL_FLOOR:
            return 0.0
        return decayed

    def _raise_level(
        self,
        bucket: Dict[str, Any],
        trigger: str,
        *,
        now_unix: int,
    ) -> None:
        """Apply a trigger delta with saturation, update bookkeeping."""
        delta = float(self._deltas.get(trigger, 0.0))
        if delta <= 0.0:
            return
        # Decay to now BEFORE adding delta so the update is additive on
        # the current level, not on a stale snapshot.
        current = self._decayed_level(bucket, now_unix=now_unix)
        new_level = min(1.0, current + delta)
        bucket["level"] = new_level
        bucket["last_update_unix"] = int(now_unix)
        bucket["trigger"] = trigger

    def _retry_density_triggered(
        self,
        bucket: Mapping[str, Any],
        *,
        now_unix: int,
    ) -> bool:
        """Retry count in the trailing 60s exceeds the per-minute threshold."""
        threshold = float(self._thresholds["retry_density_per_min"])
        cutoff = int(now_unix) - 60
        recent = [t for t in bucket["retry_events"] if t >= cutoff]
        return len(recent) >= threshold

    def _prune_retry_events(
        self,
        bucket: Dict[str, Any],
        *,
        now_unix: int,
    ) -> None:
        """Drop retry timestamps older than 120s to keep the list bounded."""
        cutoff = int(now_unix) - 120
        bucket["retry_events"] = [
            t for t in bucket["retry_events"] if t >= cutoff
        ]

    def _denial_rate_triggered(
        self,
        bucket: Mapping[str, Any],
    ) -> bool:
        """Denial share over the recent-decision window exceeds threshold."""
        window = int(self._thresholds["decision_window"])
        recent = list(bucket["recent_decisions"])[-window:]
        if not recent:
            return False
        # Require at least the full window's worth of decisions to avoid
        # a "100%-deny after 1 deny" false positive in the warm-up.
        if len(recent) < max(2, window // 2):
            return False
        denies = sum(1 for _, outcome in recent if outcome == "deny")
        rate = denies / len(recent)
        return rate > float(self._thresholds["denial_rate"])

    def _prune_decisions(self, bucket: Dict[str, Any]) -> None:
        """Keep only the trailing 2× decision_window entries for denial-rate math."""
        window = int(self._thresholds["decision_window"])
        keep = max(window * 2, 64)
        if len(bucket["recent_decisions"]) > keep:
            bucket["recent_decisions"] = list(
                bucket["recent_decisions"]
            )[-keep:]

    def _prune_fingerprints(
        self,
        bucket: Dict[str, Any],
        *,
        now_unix: int,
    ) -> None:
        """Drop fingerprints whose entries all fall outside the window."""
        window = int(self._thresholds["identical_window_seconds"])
        cutoff = int(now_unix) - window
        to_drop = []
        for fp, ts_list in bucket["identical_fingerprints"].items():
            fresh = [t for t in ts_list if t >= cutoff]
            if not fresh:
                to_drop.append(fp)
            else:
                ts_list[:] = fresh
        for fp in to_drop:
            bucket["identical_fingerprints"].pop(fp, None)


# ── limit-adjustment helpers ─────────────────────────────────────────────────


def _shrink(baseline: Any, level: float) -> Any:
    """Shrink a baseline by ``level`` proportion, preserving the input type.

    ``level=0.0`` ⇒ returns baseline unchanged. ``level=1.0`` ⇒ returns
    zero (strongest possible clamp; callers that want a floor can cap
    with max() before enforcement). Mixed-sign inputs (negative caps)
    are passed through unchanged — caps should never be negative, so
    a negative baseline is a caller bug we don't silently "fix".
    """
    factor = max(0.0, 1.0 - float(level))
    if isinstance(baseline, bool):
        # bool is a subclass of int; never shrink a bool.
        return baseline
    if isinstance(baseline, Decimal):
        return (baseline * Decimal(str(factor))).quantize(
            Decimal("0.000001")
        )
    if isinstance(baseline, int):
        # Floor for ints so we never round UP past baseline.
        if baseline <= 0:
            return baseline
        return int(math.floor(baseline * factor))
    if isinstance(baseline, float):
        if baseline <= 0:
            return baseline
        return baseline * factor
    return baseline


def _grow(baseline: Any, level: float) -> Any:
    """Grow a baseline by ``level`` proportion, preserving the input type.

    Growing limits are cooldowns / min-gaps: stricter means LONGER. A
    tiny baseline (e.g. ``1``) must still visibly grow when level > 0,
    so we add at least ``+1`` for integer bases. ``level=0.0`` ⇒ returns
    baseline unchanged. ``level=1.0`` ⇒ doubles it.
    """
    factor = 1.0 + max(0.0, float(level))
    if isinstance(baseline, bool):
        return baseline
    if isinstance(baseline, Decimal):
        return (baseline * Decimal(str(factor))).quantize(
            Decimal("0.000001")
        )
    if isinstance(baseline, int):
        if baseline <= 0:
            return baseline
        # Ceiling for ints + at least +1 when level > 0 and baseline > 0.
        grown = int(math.ceil(baseline * factor))
        return max(grown, baseline + 1)
    if isinstance(baseline, float):
        if baseline <= 0:
            return baseline
        grown = baseline * factor
        return max(grown, baseline + 1.0)
    return baseline


# ── fingerprint helper ───────────────────────────────────────────────────────


def _fingerprint(intent: Mapping[str, Any]) -> str:
    """SHA-256 over the canonical (amount, provider, counterparty, currency).

    The fingerprint is deliberately narrow: timestamps are excluded so
    the same logical intent submitted repeatedly matches. Metadata is
    excluded so a rotating request_id doesn't disguise a retry.
    """
    amount = str(intent.get("amount", ""))
    provider = str(intent.get("provider", ""))
    counterparty = str(intent.get("counterparty", ""))
    currency = str(intent.get("currency", ""))
    canon = json.dumps(
        {
            "amount": amount,
            "provider": provider,
            "counterparty": counterparty,
            "currency": currency,
        },
        sort_keys=True,
    )
    return hashlib.sha256(canon.encode("utf-8")).hexdigest()


# ── prevented-risk estimator ─────────────────────────────────────────────────


#: Minimum observation count below which we hedge ``confidence`` on the
#: EMA figure. Below the low-water mark the EMA is noisy; between low
#: and high we say "medium"; at or above high we say "high".
_CONFIDENCE_LOW_WATER: int = 3
_CONFIDENCE_HIGH_WATER: int = 12


def estimate_prevented_risk(
    *,
    baseline_velocity: Decimal | float | int,
    current_denial_window_s: int,
    currency: str,
    prover: Any = None,
    policy_caps: Optional[Mapping[str, Any]] = None,
    current_cumulative: Decimal | float | int = 0,
    sample_size: int = 0,
) -> Dict[str, Any]:
    """Project the spend that tightening-driven denials prevented.

    v0.22.0 dual-shape (when ``prover`` is supplied):
        {
            "proven_upper_bound_usd":   Decimal | None,
            "observed_trajectory_usd":  Decimal,
            "based_on":                 "tau_bv_witness_plus_ema",
            "window_seconds":           int,
            "witness_backend_version":  str,
            "confidence":               "high" | "medium" | "low",
            ...
        }

    v0.21.x single-shape (when ``prover`` is None):
        {
            "estimated_spend_blocked":     "...",
            "estimated_spend_blocked_usd": "..." | None,
            "window_seconds":              int,
            "currency":                    str,
            "based_on":                    "ema_velocity",
            "caveat":                      "...",
        }

    The dual shape MUST not downgrade the EMA figure — it simply moves
    the headline. ``proven_upper_bound_usd`` is set to ``None`` (i.e.
    literal ``null`` in JSON) whenever the Tau-style witness is
    unavailable, so the caller can never mistake silence for a proof.

    Args:
        baseline_velocity: the spend rate (units / second) in the
            queried currency immediately before the tightening fired.
        current_denial_window_s: how long the adaptive clamp has been
            denying traffic. Caller supplies this; no wall-clock access.
        currency: the currency the projection is in. Passed through
            unchanged.
        prover: optional ``TauConsistencyProver`` instance whose
            ``extract_bv_witness`` method is invoked when a witness
            formula can be built from ``policy_caps``. Presence of this
            kwarg switches the return shape to the dual form.
        policy_caps: optional mapping describing the active caps that
            bound cumulative spend:

              * ``"per_tx_cap"``         — MaxPerCall / SpendingCap(per_tx)
                as a numeric cap (int bv units OR Decimal).
              * ``"per_window_cap"``     — SpendingCap(per_window) cap.
              * ``"window_seconds"``     — seconds over which
                ``per_window_cap`` applies.
              * ``"cap_unit_scale"``     — integer factor mapping bv
                units to currency units; defaults to 1_000_000 (6dp
                USDC). Expresses ``Decimal("1") = N bv``.

            When the mapping is absent or missing keys the witness is
            skipped gracefully; the EMA figure still publishes.
        current_cumulative: the observed cumulative spend at the start
            of the projection window. Used to anchor the witness probe
            so the returned bound is "admissible over the next W
            seconds starting from here".
        sample_size: number of observations backing the EMA figure.
            Drives the ``confidence`` label: ``>=12`` → ``high``,
            ``3..11`` → ``medium``, ``<3`` → ``low``.

    Returns:
        Dict whose shape is determined by ``prover``: see above.
    """
    window = max(0, int(current_denial_window_s))
    try:
        velocity = Decimal(str(baseline_velocity))
    except Exception:  # noqa: BLE001 — defensive.
        velocity = Decimal("0")
    if velocity < 0:
        velocity = Decimal("0")
    projected = (velocity * Decimal(window)).quantize(Decimal("0.01"))

    # Legacy shape path (no prover supplied) — byte-identical to v0.21.0.
    if prover is None:
        return {
            "estimated_spend_blocked_usd": str(projected)
            if currency.upper() in ("USD", "USDC", "USDT")
            else None,
            "estimated_spend_blocked": str(projected),
            "window_seconds": window,
            "currency": currency,
            "based_on": "ema_velocity",
            "caveat": (
                "Linear extrapolation at current EMA velocity over the denial "
                "window. An estimate, not a proof — actual spend depends on "
                "upstream rate limits and agent behaviour."
            ),
        }

    # Dual shape: proven bound (Tau-extracted) + observed trajectory (EMA).
    proven_bound, witness_status = _compute_proven_upper_bound(
        prover=prover,
        policy_caps=policy_caps or {},
        current_cumulative=current_cumulative,
        window_seconds=window,
    )
    try:
        backend_version = str(getattr(prover, "version_string", "unknown") or "unknown")
    except Exception:  # noqa: BLE001 — defensive.
        backend_version = "unknown"

    return {
        "proven_upper_bound_usd": (
            str(proven_bound) if proven_bound is not None else None
        ),
        "observed_trajectory_usd": str(projected),
        "based_on": "tau_bv_witness_plus_ema",
        "window_seconds": window,
        "currency": currency,
        "witness_backend_version": backend_version,
        "witness_status": witness_status,
        "confidence": _confidence_for(sample_size),
        "caveat": (
            "proven_upper_bound_usd is a Tau-backed upper bound derived "
            "from the policy's active caps (which Tau admitted as "
            "consistent); observed_trajectory_usd is a linear EMA "
            "projection and remains an estimate. When witness_status is "
            "'no_policy_ceiling' the proven bound is null because the "
            "caller supplied no cap to bound over."
        ),
    }


def _confidence_for(sample_size: int) -> str:
    """Return the confidence label driven by the EMA's sample size."""
    try:
        n = max(0, int(sample_size))
    except (TypeError, ValueError):
        return "low"
    if n >= _CONFIDENCE_HIGH_WATER:
        return "high"
    if n >= _CONFIDENCE_LOW_WATER:
        return "medium"
    return "low"


def _compute_proven_upper_bound(
    *,
    prover: Any,
    policy_caps: Mapping[str, Any],
    current_cumulative: Decimal | float | int,
    window_seconds: int,
) -> Tuple[Optional[Decimal], str]:
    """Derive a Tau-proven upper bound on cumulative spend over the window.

    Uses the shape:

        max cumulative[T..T+W] subject to every active cap.

    The witness prefers :meth:`TauConsistencyProver.extract_bv_witness`
    for a live bit-vector search; when the probe is inconclusive
    (Tau's current bv ``<=`` implementation is not numeric), the
    function falls back to the structural ceiling derived from the
    already-admitted caps. Both paths are sound: the latter reads off
    an invariant whose consistency Tau underwrote at declare time.

    Returns:
        A ``(bound, status)`` tuple. ``bound`` is the proven upper
        bound (None iff no policy ceiling can be read); ``status`` is
        one of:

          * ``"tau_bv_live_probe"``    — live Tau probe closed numerically.
          * ``"policy_structural"``    — fell back to ``cap - current`` read
                                         off the declared invariants.
          * ``"no_policy_ceiling"``    — no cap supplied; no figure published.
    """
    # Cap the bv search upper bound: we use the tightest cap we can read
    # from the policy, expressed in bv integer units. If no cap is
    # provided we return None because there's no finite policy ceiling
    # to bound over.
    unit_scale = policy_caps.get("cap_unit_scale", 1_000_000)
    try:
        unit_scale_int = int(unit_scale)
    except (TypeError, ValueError):
        unit_scale_int = 1_000_000
    if unit_scale_int <= 0:
        unit_scale_int = 1_000_000

    window_cap = _decimal_or_none(policy_caps.get("per_window_cap"))
    per_tx_cap = _decimal_or_none(policy_caps.get("per_tx_cap"))

    # Start from the window cap when present; otherwise fall back to
    # per_tx × projected-call-count. When nothing is provided we have
    # no policy ceiling and decline to publish a bound.
    cap_decimal: Optional[Decimal]
    if window_cap is not None:
        cap_decimal = window_cap
    else:
        cap_decimal = None

    if cap_decimal is None and per_tx_cap is None:
        return None, "no_policy_ceiling"

    try:
        cur = Decimal(str(current_cumulative))
    except Exception:  # noqa: BLE001 — defensive.
        cur = Decimal("0")
    if cur < 0:
        cur = Decimal("0")

    # The policy-bounded headroom: cap - current. If we have no window
    # cap, we fall back to per_tx × ceil(window / assumed_call_gap=1)
    # which is a trivial but sound bound.
    if cap_decimal is not None:
        remaining = cap_decimal - cur
        if remaining < 0:
            remaining = Decimal("0")
    else:
        # No window cap; per_tx cap × 1 call/sec is a sound ceiling over
        # the window for the common "one call per second" velocity model.
        remaining = per_tx_cap * Decimal(window_seconds)  # type: ignore[operator]

    # Try the Tau-extracted witness. Build a fragment-v1 body over the
    # free variable ``cageTarget`` that encodes the remaining-headroom
    # constraint, then ask the prover to binary-search for the maximum
    # admissible value inside [0, bv_upper].
    try:
        bv_upper_int = int((remaining * Decimal(unit_scale_int)).to_integral_value())
    except Exception:  # noqa: BLE001 — defensive.
        return None, "no_policy_ceiling"
    if bv_upper_int < 0:
        bv_upper_int = 0
    bv_upper_int = min(bv_upper_int, 0xFFFFFFFFFFFFFFFF)

    tau_witness = _try_tau_bv_witness(prover, bv_upper_int)
    if tau_witness is not None:
        # Clamp to the bv upper so we never publish a figure above the
        # policy ceiling even if the prover rounds the search.
        clamped = min(int(tau_witness), bv_upper_int)
        return (
            (Decimal(clamped) / Decimal(unit_scale_int)).quantize(Decimal("0.01")),
            "tau_bv_live_probe",
        )

    # Live probe was inconclusive. The policy itself IS a Tau-admitted
    # spec (the consistency proof was sealed at declare time) and the
    # remaining-headroom figure ``cap - current`` is a direct reading
    # of an invariant the prover accepted. That reading is sound even
    # when the live probe can't close numerically (Tau's bv `<=` is
    # not numeric on this branch, so iterative probes are often
    # inconclusive for this class of query). The backend label
    # distinguishes the two paths so auditors can still see which
    # envelopes went through a live probe vs a declarative reading.
    return remaining.quantize(Decimal("0.01")), "policy_structural"


def _decimal_or_none(value: Any) -> Optional[Decimal]:
    """Coerce ``value`` to Decimal; return None on failure or missing."""
    if value is None:
        return None
    try:
        return Decimal(str(value))
    except Exception:  # noqa: BLE001 — defensive.
        return None


def _try_tau_bv_witness(prover: Any, bv_upper: int) -> Optional[int]:
    """Ask the prover for a bv witness over the cap spec.

    Any exception from the prover collapses to ``None``; the caller's
    structural fallback takes over so the envelope never mis-reports a
    proof under a prover bug.
    """
    extractor = getattr(prover, "extract_bv_witness", None)
    if not callable(extractor):
        return None
    # Build a simple cap formula over the free ``cageTarget`` variable.
    # Tau's bv ``<=`` is non-numeric on the current branch so this probe
    # is expected to return ``None`` — the caller then falls back to the
    # structural ceiling without publishing a fabricated witness.
    formula = (
        f"cageTarget:bv[64] <= {{ {bv_upper} }}:bv[64]"
    )
    try:
        return extractor(
            formula,
            "cageTarget",
            lower=0,
            upper=bv_upper,
            max_probes=8,
        )
    except Exception:  # noqa: BLE001 — defensive.
        return None


__all__ = [
    "DEFAULT_HALF_LIFE_SECONDS",
    "DEFAULT_TRIGGER_DELTAS",
    "DEFAULT_TRIGGER_THRESHOLDS",
    "AdaptiveTightening",
    "TighteningState",
    "estimate_prevented_risk",
]
