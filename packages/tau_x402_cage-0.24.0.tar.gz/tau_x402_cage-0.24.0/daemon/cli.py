"""Daemon entry point.

Commands:
    tau-x402-cage                               # run daemon with empty policy
    tau-x402-cage --policy policy.yaml          # pre-load declared invariants
    tau-x402-cage init                          # scaffold policy.yaml + compose
    tau-x402-cage init --force                  # overwrite existing files
    tau-x402-cage inspect                       # show active policy snapshot
    tau-x402-cage explain [--policy file.yaml]  # explain SAT/UNSAT status
    tau-x402-cage lint <policy.yaml>            # offline pre-declare linter (v0.10.0)
    tau-x402-cage suggest ...                   # English -> LLM prompt -> YAML
    tau-x402-cage suggest --round-trip <policy.yaml  # lint + narrate loop (v0.18.0)
    tau-x402-cage narrate <policy.yaml>         # plain-English policy summary (v0.18.0)
    tau-x402-cage keygen-ed25519 --out <prefix> # write ed25519 keypair (PEM)
    tau-x402-cage audit-export --out <path> --private-key <pem>
                                                # export + sign audit bundle (v0.9.0)
    tau-x402-cage audit-verify <path> --public-key <pem>
                                                # offline-verify a bundle (v0.9.0)
    tau-x402-cage branch list                   # list all branches
    tau-x402-cage branch create NAME [--from R] # open a new branch
    tau-x402-cage branch checkout NAME          # activate a branch
    tau-x402-cage branch merge SRC --into DST --reviewer NAME
                                                # fast-forward SRC into DST
    tau-x402-cage prover-metrics                # show prover push/pop counters
    tau-x402-cage bench [--json] [--against URL]
                                                # run the 5-test TTI battery (v0.10.0)
"""
from __future__ import annotations

import argparse
import json
import os
import socket
import sys
from pathlib import Path
from typing import Any, Optional

from adapter.cage_mode import CageMode, parse_mode
from adapter.history_store import HistoryStoreError, build_history_store
from adapter.self_ref_policy import (
    MergeFailureCooldownError,
    build_merge_failure_cooldown,
)
from adapter.policy_loader import (
    SUGGEST_PROMPT_TEMPLATE,
    PolicyLoaderError,
    load_policy,
    write_starter_compose,
    write_starter_policy,
)
from adapter.prover import prover_from_env
from adapter.webhook_sink import (
    WebhookConfigError,
    WebhookSink,
    canonicalize_verdict,
    compute_signature,
    load_webhook_config,
)
from daemon.server import CageDaemon
from daemon.signal_handlers import install as install_signal_handlers


DEFAULT_SOCKET = "/tmp/tau-x402-cage.sock"


def _cmd_quickstart(args: argparse.Namespace) -> int:
    """One-command scaffold: policy + .env + docker-compose + MCP snippet.

    Fails closed (refuses to clobber) unless ``--force`` is passed. The
    .env file holds a fresh HMAC secret, so accidental overwrite would
    silently invalidate every previously-signed verdict.
    """
    from daemon.quickstart import (
        QuickstartError,
        format_next_steps,
        scaffold,
    )

    try:
        result = scaffold(
            Path(args.dir),
            force=args.force,
            mcp_config_out=(
                Path(args.mcp_config_out) if args.mcp_config_out else None
            ),
        )
    except QuickstartError as exc:
        sys.stderr.write(f"tau-x402-cage quickstart: {exc}\n")
        return 2
    except OSError as exc:
        sys.stderr.write(
            f"tau-x402-cage quickstart: could not write scaffold: {exc}\n"
        )
        return 2

    sys.stdout.write(format_next_steps(result))
    sys.stdout.flush()
    return 0


def _cmd_init(args: argparse.Namespace) -> int:
    policy_path = Path(args.policy_path)
    compose_path = Path(args.compose_path)

    if args.force:
        if policy_path.exists():
            policy_path.unlink()
        if compose_path.exists():
            compose_path.unlink()
    try:
        write_starter_policy(policy_path)
        write_starter_compose(compose_path)
    except PolicyLoaderError as exc:
        sys.stderr.write(f"tau-x402-cage init: {exc}\n")
        sys.stderr.write("  pass --force to overwrite, or pick a different --policy-path\n")
        return 2
    sys.stdout.write(
        f"Wrote {policy_path} and {compose_path}.\n"
        f"Next steps:\n"
        f"  1. Edit {policy_path} to match your rules.\n"
        f"  2. tau-x402-cage --policy {policy_path}\n"
        f"  3. (optional) docker compose -f {compose_path} up\n"
    )
    return 0


def _cmd_lint(args: argparse.Namespace) -> int:
    """Offline pre-declare policy linter (v0.10.0).

    Exit codes:
        0 — no errors (no findings, or warnings-only without ``--strict``)
        1 — errors found (or warnings under ``--strict``)
        2 — file missing / YAML parse error / unknown invariant kind
    """
    try:
        from adapter.policy_linter import LintError, lint_policy_file
    except ImportError as exc:
        sys.stderr.write(f"tau-x402-cage lint: {exc}\n")
        return 2
    try:
        report = lint_policy_file(Path(args.policy_path))
    except LintError as exc:
        sys.stderr.write(f"tau-x402-cage lint: {exc}\n")
        return 2
    fmt = getattr(args, "fmt", "text")
    if fmt == "json":
        sys.stdout.write(report.to_json() + "\n")
    else:
        sys.stdout.write(report.to_text())
    sys.stdout.flush()
    if report.has_errors():
        return 1
    if getattr(args, "strict", False) and report.has_warnings():
        return 1
    return 0


def _send_op(socket_path: str, request: dict[str, Any], timeout: float = 5.0) -> dict[str, Any]:
    """Send one JSON request to the daemon over UDS and return the parsed reply.

    Minimal helper used by the inspect / explain subcommands. Keeps its own
    imports local so the run path (which doesn't need socket) stays cheap.
    """
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.settimeout(timeout)
    s.connect(socket_path)
    try:
        s.sendall((json.dumps(request) + "\n").encode("utf-8"))
        f = s.makefile("r")
        line = f.readline()
    finally:
        s.close()
    if not line:
        raise RuntimeError("empty response from daemon")
    return json.loads(line)


def _load_candidate_invariants(policy_path: Path) -> list[dict[str, Any]]:
    """Parse a policy YAML file and return declare-style dicts.

    Each returned dict carries a ``kind`` field and the matching keyword
    arguments for that invariant class, ready to feed to the daemon's
    ``explain_policy`` op in candidate mode.
    """
    loaded = load_policy(policy_path)
    entries: list[dict[str, Any]] = []
    for inv in loaded.invariants:
        entries.append(_invariant_to_entry(inv))
    return entries


def _invariant_to_entry(inv: Any) -> dict[str, Any]:
    """Round-trip an Invariant into the daemon's declare-style wire dict."""
    from adapter.invariants import (
        CounterpartyConstraint,
        MaxPerCall,
        MutualExclusion,
        ProviderAllowlist,
        RetryRateLimit,
        RollingWindowCap,
        SpendingCap,
    )

    if isinstance(inv, MaxPerCall):
        return {
            "kind": "max_per_call",
            "max_amount": str(inv.max_amount),
            "currency": inv.currency,
        }
    if isinstance(inv, SpendingCap):
        entry: dict[str, Any] = {
            "kind": "spending_cap",
            "max_amount": str(inv.max_amount),
            "currency": inv.currency,
            "scope": inv.scope,
        }
        if inv.window_seconds is not None:
            entry["window_seconds"] = inv.window_seconds
        if inv.provider is not None:
            entry["provider"] = inv.provider
        return entry
    if isinstance(inv, ProviderAllowlist):
        return {"kind": "provider_allowlist", "providers": sorted(inv.providers)}
    if isinstance(inv, RetryRateLimit):
        return {"kind": "retry_rate_limit", "min_gap_seconds": inv.min_gap_seconds}
    if isinstance(inv, RollingWindowCap):
        return {
            "kind": "rolling_window_cap",
            "max_count": inv.max_count,
            "window_seconds": inv.window_seconds,
            "group_by": inv.group_by,
        }
    if isinstance(inv, CounterpartyConstraint):
        return {
            "kind": "counterparty_constraint",
            "approved_ids": sorted(inv.approved_ids),
            "sanctioned_ids": sorted(inv.sanctioned_ids),
        }
    if isinstance(inv, MutualExclusion):
        return {
            "kind": "mutual_exclusion",
            "group_a": sorted(inv.group_a),
            "group_b": sorted(inv.group_b),
        }
    raise PolicyLoaderError(
        f"invariant class {type(inv).__name__!r} not supported by explain --policy"
    )


def _cmd_inspect(args: argparse.Namespace) -> int:
    """Connect to a running daemon and print its active-policy snapshot."""
    try:
        resp = _send_op(args.socket, {"op": "inspect_policy"})
    except (OSError, RuntimeError, json.JSONDecodeError) as exc:
        sys.stderr.write(
            f"tau-x402-cage inspect: failed to reach daemon at {args.socket}: {exc}\n"
        )
        return 2
    _render_inspect(resp, sys.stdout)
    return 0


def _cmd_diff(args: argparse.Namespace) -> int:
    """Print the delta between two revisions from the daemon's log.

    Thin shim over the ``diff_revisions`` op (shipped in v0.6.0) wired to
    the v0.11.0 ``adapter.diff_renderer``. Exit codes mirror the rest of
    the CLI: 0 success, 1 "revision missing / daemon said no", 2 transport
    error / bad args.
    """
    from adapter.diff_renderer import render_revision_diff_text

    try:
        resp = _send_op(args.socket, {
            "op": "diff_revisions", "a": args.revision_a, "b": args.revision_b,
        })
    except (OSError, RuntimeError, json.JSONDecodeError) as exc:
        sys.stderr.write(
            f"tau-x402-cage diff: failed to reach daemon at {args.socket}: {exc}\n"
        )
        return 2
    fmt = getattr(args, "fmt", "text")
    if resp.get("verdict") != "ok":
        # Daemon-level error -> exit 1, print the daemon's own reason so
        # operators can grep for the category.
        category = resp.get("category", "error")
        reason = resp.get("reason", "(no reason given)")
        sys.stderr.write(
            f"tau-x402-cage diff: {category}: {reason}\n"
        )
        return 1
    if fmt == "json":
        sys.stdout.write(json.dumps(resp) + "\n")
    else:
        sys.stdout.write(render_revision_diff_text(resp))
    sys.stdout.flush()
    return 0


def _render_inspect(resp: dict[str, Any], out) -> None:
    """Render an inspect_policy response in a readable, machine-parseable form.

    Keeps one fact per line so grep-based tooling stays useful; also flushes
    the stream at the end so callers piping to a file see complete output
    even on abrupt exit.

    v0.19.0 product switch: when the daemon runs in Guaranteed Mode the
    leading block shows the bank-deployable tier summary
    (``Mode``/``Proof backend``/``Fallback``/``Totality gate``/
    ``Language tier``/``Active rules``). In Flexible Mode the same keys
    render the hybrid chain so operators can eyeball the surface without
    parsing the JSON shape.
    """
    # v0.19.0 public-surface block: first fact per line, fixed-width
    # labels so the output stays table-like under grep / cut.
    mode = resp.get("mode") or ("guaranteed" if resp.get("prover_mode") == "guaranteed" else "flexible")
    public_backend = resp.get("proof_backend_public") or resp.get("proof_backend") or "unknown"
    fallback = resp.get("fallback") or ("none" if mode == "guaranteed" else "pattern")
    totality_gate = resp.get("totality_gate") or (
        "enforced" if mode == "guaranteed" else "not enforced (Flexible Mode)"
    )
    language_tier = resp.get("language_tier") or ("n/a" if mode == "flexible" else "unknown")
    active = int(resp.get("active_invariants") or 0)
    if mode == "guaranteed":
        active_line = f"{active} / {active} admitted"
    else:
        active_line = str(active)

    out.write("Active policy snapshot\n")
    out.write(f"  Mode:            {mode}\n")
    out.write(f"  Proof backend:   {public_backend}\n")
    out.write(f"  Fallback:        {fallback}\n")
    out.write(f"  Totality gate:   {totality_gate}\n")
    out.write(f"  Language tier:   {language_tier}\n")
    out.write(f"  Active rules:    {active_line}\n")

    # Legacy additive fields — preserved for tooling that pins on them.
    out.write(f"  prover_mode:        {resp.get('prover_mode')}\n")
    out.write(f"  active_revision_id: {resp.get('active_revision_id')}\n")
    out.write(f"  active_invariants:  {resp.get('active_invariants')}\n")
    out.write(f"  proof_backend:      {resp.get('proof_backend')}\n")
    out.write(f"  proof_strength:     {resp.get('proof_strength')}\n")
    out.write(f"  fragment_version:   {resp.get('fragment_version')}\n")
    out.write(f"  compile_hash:       {resp.get('compile_hash')}\n")
    out.write(f"  admitted_at_unix:   {resp.get('admitted_at_unix')}\n")
    invs = resp.get("invariants") or []
    if invs:
        out.write("  invariants:\n")
        for entry in invs:
            out.write(f"    - {entry.get('class')}: {entry.get('scope_hint')}\n")
    else:
        out.write("  invariants:         (none)\n")
    out.flush()


def _cmd_explain(args: argparse.Namespace) -> int:
    """Connect to the daemon and explain the active or a candidate policy."""
    request: dict[str, Any] = {"op": "explain_policy"}
    if args.policy:
        try:
            request["invariants"] = _load_candidate_invariants(Path(args.policy))
        except PolicyLoaderError as exc:
            sys.stderr.write(f"tau-x402-cage explain: {exc}\n")
            return 2
    try:
        resp = _send_op(args.socket, request)
    except (OSError, RuntimeError, json.JSONDecodeError) as exc:
        sys.stderr.write(
            f"tau-x402-cage explain: failed to reach daemon at {args.socket}: {exc}\n"
        )
        return 2
    _render_explain(resp, sys.stdout)
    return 0


def _render_explain(resp: dict[str, Any], out) -> None:
    """Render an explain_policy response in a human-friendly form.

    SAT prints backend/strength/compile_hash so auditors can tell a pattern
    proof from a Tau-complete proof at a glance. UNSAT prints the pair of
    conflicting invariants + the repair hint when one is available.
    INCONCLUSIVE prints the category so operators know whether to widen a
    budget, fix an out-of-fragment rule, or install Tau.

    v0.8.0: when the SAT response includes a ``witness`` dict (z3
    fragment-v2 backend), render a compact table showing a concrete
    permit trace so operators can see what the policy allows by example.
    """
    verdict = resp.get("verdict")
    if verdict == "sat":
        token = resp.get("proof_token") or {}
        backend = token.get("backend", "unknown")
        strength = token.get("proof_strength", "unknown")
        compile_hash = token.get("compile_hash") or "-"
        out.write(
            f"Policy admissible. Backend: {backend}. Strength: {strength}. "
            f"Compile hash: {compile_hash}\n"
        )
        witness = resp.get("witness")
        if witness:
            _render_witness(witness, out)
    elif verdict == "unsat":
        report = resp.get("report") or {}
        conflicts = report.get("conflicting_invariants") or []
        reason = report.get("unsat_explanation", "(no explanation)")
        repair = report.get("suggested_repair")
        out.write(
            f"Contradiction. Conflicting invariants: {conflicts}. Reason: {reason}\n"
        )
        if repair:
            out.write(f"Suggested repair: {repair}\n")
    elif verdict == "inconclusive":
        report = resp.get("report") or {}
        category = report.get("category", "unknown")
        reason = report.get("reason", "(no reason)")
        out.write(f"Inconclusive. Category: {category}. Reason: {reason}\n")
    else:
        out.write(f"Unexpected verdict: {verdict!r}. Raw response: {resp}\n")
    out.flush()


def _render_witness(witness: dict[str, Any], out) -> None:
    """Render a SAT witness as a compact per-step table.

    Columns shown depend on which invariant classes contributed to the
    witness. One row per ``t`` in ``[0, unroll_steps)``; absent columns
    are printed as ``-`` so every row stays the same width.
    """
    steps = witness.get("steps") or []
    if not steps:
        out.write("  witness: (empty trace)\n")
        return
    unroll = witness.get("unroll_steps", len(steps))
    backend = witness.get("backend", "z3")
    # Work out which columns to print from the union of keys across rows.
    has_amount = any("amount" in s for s in steps)
    has_event = any("event" in s for s in steps)
    has_reject = any("reject" in s for s in steps)
    has_retry = any("retry" in s for s in steps)
    out.write(
        f"  witness: concrete permit example "
        f"({unroll} steps, backend={backend})\n"
    )
    # Header row.
    cols: list[str] = ["t"]
    if has_amount:
        cols.append("amount")
    if has_event:
        cols.append("event")
    if has_reject:
        cols.append("reject")
    if has_retry:
        cols.append("retry")
    out.write("    " + "  ".join(f"{c:>8}" for c in cols) + "\n")
    for step in steps:
        row = [str(step.get("t", "?"))]
        if has_amount:
            row.append(str(step.get("amount", "-")))
        if has_event:
            row.append(str(step.get("event", "-")))
        if has_reject:
            row.append(str(step.get("reject", "-")))
        if has_retry:
            row.append(str(step.get("retry", "-")))
        out.write("    " + "  ".join(f"{c:>8}" for c in row) + "\n")
    # Per-invariant summary (amounts totals + cap, event counts etc.).
    per_inv = witness.get("per_invariant") or []
    if per_inv:
        out.write("  per-invariant:\n")
        for p in per_inv:
            cls = p.get("class", "?")
            if cls == "SpendingCap":
                out.write(
                    f"    - SpendingCap(scope={p.get('scope')}): "
                    f"total={p.get('total')} {p.get('currency', '')} "
                    f"<= cap={p.get('cap')}\n"
                )
            elif cls == "RollingWindowCap":
                out.write(
                    f"    - RollingWindowCap(group_by={p.get('group_by')}): "
                    f"events={p.get('event_count')} "
                    f"<= max_count={p.get('max_count')}\n"
                )
            elif cls == "RetryRateLimit":
                out.write(
                    f"    - RetryRateLimit(min_gap={p.get('min_gap_seconds')}s)\n"
                )
            else:
                out.write(f"    - {cls}\n")


def _cmd_branch(args: argparse.Namespace) -> int:
    """Dispatch `tau-x402-cage branch <subcommand>` against a live daemon."""
    action = getattr(args, "branch_action", None)
    if action == "list":
        return _branch_list(args)
    if action == "create":
        return _branch_create(args)
    if action == "checkout":
        return _branch_checkout(args)
    if action == "merge":
        return _branch_merge(args)
    sys.stderr.write(
        "tau-x402-cage branch: specify one of: list | create | checkout | merge\n"
    )
    return 2


def _branch_list(args: argparse.Namespace) -> int:
    try:
        resp = _send_op(args.socket, {"op": "list_branches"})
    except (OSError, RuntimeError, json.JSONDecodeError) as exc:
        sys.stderr.write(
            f"tau-x402-cage branch list: failed to reach daemon at {args.socket}: {exc}\n"
        )
        return 2
    if resp.get("verdict") != "ok":
        sys.stderr.write(f"tau-x402-cage branch list: {resp}\n")
        return 2
    active = resp.get("active_branch", "main")
    sys.stdout.write(f"Active branch: {active}\n")
    for b in resp.get("branches", []):
        marker = "*" if b.get("name") == active else " "
        head = b.get("head_revision_id") or "(empty)"
        created_by = b.get("created_by", "") or "-"
        sys.stdout.write(
            f"  {marker} {b.get('name')}  head={head}  created_by={created_by}\n"
        )
    sys.stdout.flush()
    return 0


def _branch_create(args: argparse.Namespace) -> int:
    payload: dict[str, Any] = {"op": "create_branch", "name": args.name}
    if args.from_revision:
        payload["from_revision_id"] = args.from_revision
    if args.created_by:
        payload["created_by"] = args.created_by
    try:
        resp = _send_op(args.socket, payload)
    except (OSError, RuntimeError, json.JSONDecodeError) as exc:
        sys.stderr.write(
            f"tau-x402-cage branch create: failed to reach daemon at {args.socket}: {exc}\n"
        )
        return 2
    if resp.get("verdict") != "ok":
        sys.stderr.write(f"tau-x402-cage branch create: {resp.get('reason', resp)}\n")
        return 2
    b = resp.get("branch", {})
    sys.stdout.write(
        f"Created branch {b.get('name')!r} at head={b.get('head_revision_id') or '(empty)'}\n"
    )
    return 0


def _branch_checkout(args: argparse.Namespace) -> int:
    try:
        resp = _send_op(args.socket, {"op": "checkout_branch", "name": args.name})
    except (OSError, RuntimeError, json.JSONDecodeError) as exc:
        sys.stderr.write(
            f"tau-x402-cage branch checkout: failed to reach daemon at {args.socket}: {exc}\n"
        )
        return 2
    if resp.get("verdict") != "ok":
        sys.stderr.write(f"tau-x402-cage branch checkout: {resp.get('reason', resp)}\n")
        return 2
    b = resp.get("branch", {})
    sys.stdout.write(
        f"Switched to branch {b.get('name')!r}. "
        f"Active invariants: {resp.get('active_invariants', 0)}\n"
    )
    return 0


def _branch_merge(args: argparse.Namespace) -> int:
    payload = {
        "op": "merge_branch",
        "src": args.src,
        "dst": args.into,
        "reviewer": args.reviewer,
    }
    try:
        resp = _send_op(args.socket, payload)
    except (OSError, RuntimeError, json.JSONDecodeError) as exc:
        sys.stderr.write(
            f"tau-x402-cage branch merge: failed to reach daemon at {args.socket}: {exc}\n"
        )
        return 2
    verdict = resp.get("verdict")
    json_mode = getattr(args, "json", False)
    if verdict == "merged":
        if json_mode:
            sys.stdout.write(json.dumps(resp) + "\n")
            sys.stdout.flush()
            return 0
        b = resp.get("branch", {})
        sys.stdout.write(
            f"Fast-forwarded {args.src!r} into {args.into!r}. "
            f"New head: {b.get('head_revision_id')}\n"
        )
        return 0
    if verdict == "conflict":
        if json_mode:
            # Preserve the raw payload on stdout for tooling; --json keeps
            # the full dict shape so downstream scripts can diff branches
            # programmatically.
            sys.stdout.write(json.dumps(resp) + "\n")
            sys.stdout.flush()
            return 1
        # Default: operator-readable NL rendering via adapter.conflict_renderer.
        from adapter.conflict_renderer import render_conflict_text
        rendered = render_conflict_text(resp)
        sys.stderr.write(rendered + "\n")
        sys.stderr.write(
            "(auto-merge blocked; reconcile manually or retry after retracting "
            "overlapping invariants.)\n"
        )
        return 1
    sys.stderr.write(f"tau-x402-cage branch merge: {resp.get('reason', resp)}\n")
    return 2
def _cmd_propose(args: argparse.Namespace) -> int:
    """Submit a policy proposal to a running daemon.

    Reads invariants from a policy YAML file, reuses the same loader the
    daemon uses on startup, and posts them as a single Proposal via the
    daemon's ``propose_invariant`` op. The daemon replies with the
    generated ``proposal_id`` which we print to stdout (one line) so
    shell callers can pipe it into a subsequent ``approve`` / ``reject``.
    """
    try:
        entries = _load_candidate_invariants(Path(args.policy))
    except PolicyLoaderError as exc:
        sys.stderr.write(f"tau-x402-cage propose: {exc}\n")
        return 2
    if not entries:
        sys.stderr.write(
            "tau-x402-cage propose: policy file has no invariants to propose\n"
        )
        return 2
    request: dict[str, Any] = {
        "op": "propose_invariant",
        "submitted_by": args.submitted_by,
        "invariants": entries,
    }
    try:
        resp = _send_op(args.socket, request)
    except (OSError, RuntimeError, json.JSONDecodeError) as exc:
        sys.stderr.write(
            f"tau-x402-cage propose: failed to reach daemon at {args.socket}: {exc}\n"
        )
        return 2
    if resp.get("verdict") == "pending_approval":
        pid = resp.get("proposal_id", "?")
        sys.stdout.write(f"proposal_id: {pid}\n")
        sys.stdout.write(
            f"status: pending  submitted_by: {args.submitted_by}\n"
        )
        sys.stdout.flush()
        return 0
    sys.stderr.write(f"tau-x402-cage propose: unexpected response: {resp}\n")
    return 1


def _cmd_proposals(args: argparse.Namespace) -> int:
    """List queued proposals (optionally filtered by status)."""
    request: dict[str, Any] = {"op": "list_proposals"}
    if args.status:
        request["status"] = args.status
    try:
        resp = _send_op(args.socket, request)
    except (OSError, RuntimeError, json.JSONDecodeError) as exc:
        sys.stderr.write(
            f"tau-x402-cage proposals: failed to reach daemon at {args.socket}: {exc}\n"
        )
        return 2
    if resp.get("verdict") != "ok":
        sys.stderr.write(f"tau-x402-cage proposals: {resp}\n")
        return 1
    _render_proposals(resp, sys.stdout)
    return 0


def _render_proposals(resp: dict[str, Any], out) -> None:
    """Render a list_proposals response, one proposal per block."""
    proposals = resp.get("proposals") or []
    if not proposals:
        out.write("No proposals.\n")
        out.flush()
        return
    out.write(f"{len(proposals)} proposal(s):\n")
    for p in proposals:
        out.write("\n")
        out.write(f"  proposal_id:  {p.get('proposal_id')}\n")
        out.write(f"  status:       {p.get('status')}\n")
        out.write(f"  submitted_by: {p.get('submitted_by')}\n")
        out.write(f"  submitted_at: {p.get('submitted_at')}\n")
        if p.get("reviewed_by"):
            out.write(f"  reviewed_by:  {p.get('reviewed_by')}\n")
            out.write(f"  reviewed_at:  {p.get('reviewed_at')}\n")
            if p.get("reason"):
                out.write(f"  reason:       {p.get('reason')}\n")
        invs = p.get("invariants") or []
        if invs:
            out.write("  invariants:\n")
            for entry in invs:
                out.write(f"    - {entry.get('class_name')}\n")
    out.flush()


def _cmd_approve(args: argparse.Namespace) -> int:
    """Approve a pending proposal by id."""
    request: dict[str, Any] = {
        "op": "approve_proposal",
        "proposal_id": args.proposal_id,
        "reviewer": args.reviewer,
    }
    if args.reason:
        request["reason"] = args.reason
    if args.allow_same_as_submitter:
        request["allow_same_as_submitter"] = True
    try:
        resp = _send_op(args.socket, request)
    except (OSError, RuntimeError, json.JSONDecodeError) as exc:
        sys.stderr.write(
            f"tau-x402-cage approve: failed to reach daemon at {args.socket}: {exc}\n"
        )
        return 2
    verdict = resp.get("verdict")
    if verdict == "approved":
        admission = resp.get("admission") or {}
        admission_verdict = admission.get("verdict")
        sys.stdout.write(
            f"approved proposal {args.proposal_id}; "
            f"admission verdict: {admission_verdict}\n"
        )
        if admission_verdict == "updated":
            sys.stdout.write(
                f"  revision_id: {admission.get('revision_id')}\n"
                f"  active_invariants: {admission.get('active_invariants')}\n"
            )
        else:
            sys.stdout.write(
                f"  admission report: {admission.get('reason') or admission}\n"
            )
        sys.stdout.flush()
        return 0 if admission_verdict == "updated" else 1
    # v0.14.0: governance may require N > 1 reviewers before admission.
    # A pending_more_approvals envelope means this approval was
    # RECORDED successfully; we just don't have enough votes yet.
    if verdict == "pending_more_approvals":
        recorded = resp.get("reviewers_recorded")
        required = resp.get("reviewers_required")
        sys.stdout.write(
            f"approval recorded for {args.proposal_id}; "
            f"{recorded}/{required} reviewers so far\n"
        )
        sys.stdout.flush()
        return 0
    sys.stderr.write(f"tau-x402-cage approve: {resp}\n")
    return 1


def _cmd_reject(args: argparse.Namespace) -> int:
    """Reject a pending proposal by id. Requires --reason."""
    request: dict[str, Any] = {
        "op": "reject_proposal",
        "proposal_id": args.proposal_id,
        "reviewer": args.reviewer,
        "reason": args.reason,
    }
    if args.allow_same_as_submitter:
        request["allow_same_as_submitter"] = True
    try:
        resp = _send_op(args.socket, request)
    except (OSError, RuntimeError, json.JSONDecodeError) as exc:
        sys.stderr.write(
            f"tau-x402-cage reject: failed to reach daemon at {args.socket}: {exc}\n"
        )
        return 2
    if resp.get("verdict") == "rejected":
        sys.stdout.write(f"rejected proposal {args.proposal_id}\n")
        sys.stdout.flush()
        return 0
    sys.stderr.write(f"tau-x402-cage reject: {resp}\n")
    return 1


def _cmd_governance(args: argparse.Namespace) -> int:
    """Dispatch the `tau-x402-cage governance ...` subcommands (v0.14.0)."""
    action = getattr(args, "governance_action", None)
    if action == "status":
        return _governance_status(args)
    if action == "check":
        return _governance_check(args)
    sys.stderr.write(
        "tau-x402-cage governance: expected one of "
        "'status', 'check'. See --help.\n"
    )
    return 2


def _governance_status(args: argparse.Namespace) -> int:
    """Print a summary of the loaded governance policy.

    Reads `TAU_CAGE_GOVERNANCE_YAML` from the environment (or `--path`),
    loads the policy, and prints it. Intended as a smoke test operators
    run before restarting the daemon to make sure the YAML parses.
    """
    from adapter.mutation_governance import (
        GovernanceLoadError,
        load_governance_from_env,
        load_governance_from_path,
    )

    try:
        if args.path:
            policy = load_governance_from_path(Path(args.path))
        else:
            policy = load_governance_from_env(os.environ)
            if policy is None:
                sys.stderr.write(
                    "tau-x402-cage governance status: "
                    "no TAU_CAGE_GOVERNANCE_YAML set and no --path given\n"
                )
                return 2
    except GovernanceLoadError as exc:
        sys.stderr.write(f"tau-x402-cage governance status: {exc}\n")
        return 2
    if args.fmt == "json":
        sys.stdout.write(json.dumps(policy.to_dict(), sort_keys=True) + "\n")
    else:
        sys.stdout.write(policy.summary() + "\n")
    sys.stdout.flush()
    return 0


def _governance_check(args: argparse.Namespace) -> int:
    """Dry-run a governance decision without touching the daemon.

    Loads the governance policy (env or --path), parses the invariant
    YAML, and prints the outcome of ``check_propose`` +
    ``check_temporal_bounds`` + ``check_prover_mode`` for the given
    actor. Exit 0 when the propose clears every axis, 1 when blocked,
    2 on config errors.
    """
    from adapter.mutation_governance import (
        GovernanceLoadError,
        load_governance_from_env,
        load_governance_from_path,
    )

    try:
        if args.path:
            policy = load_governance_from_path(Path(args.path))
        else:
            policy = load_governance_from_env(os.environ)
            if policy is None:
                sys.stderr.write(
                    "tau-x402-cage governance check: "
                    "no TAU_CAGE_GOVERNANCE_YAML set and no --path given\n"
                )
                return 2
    except GovernanceLoadError as exc:
        sys.stderr.write(f"tau-x402-cage governance check: {exc}\n")
        return 2
    # Parse the invariant file using the same loader the daemon uses.
    try:
        entries = _load_candidate_invariants(Path(args.invariant))
    except PolicyLoaderError as exc:
        sys.stderr.write(f"tau-x402-cage governance check: {exc}\n")
        return 2
    if not entries:
        sys.stderr.write(
            "tau-x402-cage governance check: invariant file declares no rules\n"
        )
        return 2
    # Rehydrate the first invariant only — the check is per-rule.
    from adapter.policy_loader import load_policy

    loaded = load_policy(Path(args.invariant))
    if not loaded.invariants:
        sys.stderr.write(
            "tau-x402-cage governance check: invariant file has no invariants\n"
        )
        return 2
    inv = loaded.invariants[0]
    class_name = type(inv).__name__
    propose_verdict = policy.check_propose(args.actor, inv)
    bounds_ok, bounds_reason = policy.check_temporal_bounds(inv)
    mode = args.prover_mode or os.environ.get("CAGE_PROVER_MODE") or "compat"
    mode_ok = policy.check_prover_mode(class_name, mode)
    req = policy.get_requirement(class_name)
    result = {
        "actor": args.actor,
        "invariant_class": class_name,
        "prover_mode": mode,
        "check_propose": {
            "allowed": propose_verdict.allowed,
            "reason": propose_verdict.reason,
            "required_reviewers": propose_verdict.required_reviewers,
        },
        "check_prover_mode": {
            "allowed": mode_ok,
            "required_mode": "strict" if not mode_ok else None,
        },
        "check_temporal_bounds": {
            "allowed": bounds_ok,
            "reason": bounds_reason,
        },
        "approval_requirement": {
            "min_reviewers": req.min_reviewers,
            "reviewers_must_differ": req.reviewers_must_differ,
            "reviewer_must_differ_from_submitter": (
                req.reviewer_must_differ_from_submitter
            ),
        },
    }
    if args.fmt == "json":
        sys.stdout.write(json.dumps(result, sort_keys=True) + "\n")
    else:
        sys.stdout.write(
            f"governance check actor={args.actor} class={class_name} "
            f"mode={mode}\n"
        )
        p = result["check_propose"]
        sys.stdout.write(
            f"  propose:        {'allow' if p['allowed'] else 'DENY'} "
            f"(required_reviewers={p['required_reviewers']})\n"
        )
        if p["reason"]:
            sys.stdout.write(f"    reason: {p['reason']}\n")
        m = result["check_prover_mode"]
        sys.stdout.write(
            f"  prover_mode:    {'allow' if m['allowed'] else 'DENY'}"
        )
        if m.get("required_mode"):
            sys.stdout.write(f" (requires {m['required_mode']})\n")
        else:
            sys.stdout.write("\n")
        t = result["check_temporal_bounds"]
        sys.stdout.write(
            f"  temporal:       {'allow' if t['allowed'] else 'DENY'}\n"
        )
        if t["reason"]:
            sys.stdout.write(f"    reason: {t['reason']}\n")
    sys.stdout.flush()
    all_ok = (
        propose_verdict.allowed and mode_ok and bounds_ok
    )
    return 0 if all_ok else 1


def _cmd_shadow_summary(args: argparse.Namespace) -> int:
    """Render the daemon's shadow/advisory would-have-rejected report (v0.13.0).

    Connects to a running daemon over UDS and calls ``op=shadow_summary``.
    The daemon walks its verdict history for shadow-tagged rows and
    returns aggregates; this CLI renders them as text (default) or
    emits the raw JSON payload for scripting.
    """
    window_s = _parse_window_argument(getattr(args, "window", None))
    if window_s is None and getattr(args, "window", None):
        sys.stderr.write(
            f"tau-x402-cage shadow-summary: cannot parse --window={args.window!r}; "
            "expected formats like 24h, 7d, 3600s, or an integer number of seconds\n"
        )
        return 2
    payload: dict[str, Any] = {"op": "shadow_summary"}
    if window_s is not None:
        payload["window_seconds"] = window_s
    try:
        resp = _send_op(args.socket, payload)
    except (OSError, RuntimeError, json.JSONDecodeError) as exc:
        sys.stderr.write(
            f"tau-x402-cage shadow-summary: failed to reach daemon at "
            f"{args.socket}: {exc}\n"
        )
        return 2
    if resp.get("verdict") != "ok":
        sys.stderr.write(
            f"tau-x402-cage shadow-summary: daemon error: "
            f"{resp.get('reason') or resp}\n"
        )
        return 1
    fmt = getattr(args, "fmt", "text")
    if fmt == "json":
        sys.stdout.write(json.dumps(resp, indent=2) + "\n")
    else:
        _render_shadow_summary(resp, sys.stdout)
    sys.stdout.flush()
    return 0


def _parse_window_argument(raw: Optional[str]) -> Optional[int]:
    """Parse ``--window 24h`` into an int seconds value, or return None.

    Supported suffixes: ``s``, ``m``, ``h``, ``d``. Bare integers are
    interpreted as seconds. Empty / missing returns None (= no window
    filter, aggregate everything in the store).
    """
    if raw is None or raw == "":
        return None
    s = str(raw).strip().lower()
    if s.isdigit():
        return int(s)
    multipliers = {"s": 1, "m": 60, "h": 3600, "d": 86400}
    unit = s[-1]
    if unit in multipliers and s[:-1].isdigit():
        return int(s[:-1]) * multipliers[unit]
    return None


def _render_shadow_summary(resp: dict[str, Any], out) -> None:
    """Render a shadow_summary response as a human-readable report.

    Layout:
      * Header: current mode + window
      * Total shadow-rejected count
      * Per-rule breakdown (rule_id, count, sample reason)
      * Per-provider breakdown
      * Aggregate "would have blocked" value by currency
      * Footnote pointing the operator at how to flip to enforce
    """
    mode = resp.get("mode", "unknown")
    window = resp.get("window_seconds")
    total = resp.get("total_shadow_rejected", 0)
    out.write("Shadow summary\n")
    out.write(f"  current mode:              {mode}\n")
    out.write(
        f"  window:                    {_window_repr(window)}\n"
    )
    out.write(f"  total shadow-rejected:     {total}\n")
    by_rule = resp.get("by_rule") or []
    if by_rule:
        out.write("\n  By rule:\n")
        for entry in by_rule:
            reason = entry.get("sample_reason") or "-"
            out.write(
                f"    {entry.get('rule_id', 'unknown'):30s} "
                f"count={entry.get('count', 0)}   {reason}\n"
            )
    by_provider = resp.get("by_provider") or []
    if by_provider:
        out.write("\n  Top providers:\n")
        for entry in by_provider[:10]:
            out.write(
                f"    {entry.get('provider', 'unknown'):30s} "
                f"count={entry.get('count', 0)}\n"
            )
    value = resp.get("aggregate_would_block_value") or {}
    if value:
        out.write("\n  Would-have-blocked value:\n")
        for currency, amt in value.items():
            out.write(f"    {currency}: {amt}\n")
    if total == 0:
        out.write(
            "\n  No shadow-tagged rejects in the window. Either the "
            "daemon isn't in shadow/advisory mode, or your rules are "
            "permissive for current traffic — consider flipping to "
            "enforce mode.\n"
        )
    else:
        out.write(
            "\n  Next step: review the per-rule breakdown above. "
            "Restart with --mode enforce (or TAU_CAGE_MODE=enforce) "
            "to start rejecting the same traffic on the wire.\n"
        )
    out.flush()


def _window_repr(window_seconds: Any) -> str:
    """Render a window_seconds value as a human-readable string."""
    if window_seconds is None:
        return "all history"
    try:
        seconds = int(window_seconds)
    except (TypeError, ValueError):
        return str(window_seconds)
    if seconds % 86400 == 0:
        return f"last {seconds // 86400}d"
    if seconds % 3600 == 0:
        return f"last {seconds // 3600}h"
    if seconds % 60 == 0:
        return f"last {seconds // 60}m"
    return f"last {seconds}s"


def _cmd_prover_metrics(args: argparse.Namespace) -> int:
    """Connect to a running daemon and print its prover metrics (v0.7.0)."""
    try:
        resp = _send_op(args.socket, {"op": "prover_metrics"})
    except (OSError, RuntimeError, json.JSONDecodeError) as exc:
        sys.stderr.write(
            f"tau-x402-cage prover-metrics: failed to reach daemon at "
            f"{args.socket}: {exc}\n"
        )
        return 2
    _render_prover_metrics(resp, sys.stdout)
    return 0


def _render_prover_metrics(resp: dict[str, Any], out) -> None:
    """Render a prover_metrics response in a readable, greppable form.

    One fact per line; sub-sections for pattern, tau, and z3-incremental
    provers when present. Missing backends are simply omitted rather than
    printed as "None" so `grep` stays useful.
    """
    out.write("Prover metrics snapshot\n")
    out.write(f"  prover_mode:        {resp.get('prover_mode')}\n")
    pattern = resp.get("pattern_prover") or {}
    out.write(f"  pattern_backend:    {pattern.get('backend', 'unknown')}\n")
    tau = resp.get("tau_prover")
    if tau is not None:
        out.write(f"  tau_backend:        {tau.get('backend', 'unknown')}\n")
    z3m = resp.get("z3_incremental_prover")
    if z3m is not None:
        out.write("  z3_incremental:\n")
        out.write(f"    backend:          {z3m.get('backend')}\n")
        out.write(f"    incremental_hits: {z3m.get('incremental_hits')}\n")
        out.write(f"    full_resolves:    {z3m.get('full_resolves')}\n")
        out.write(f"    push_depth:       {z3m.get('push_depth')}\n")
        out.write(f"    total_invariants: {z3m.get('total_invariants')}\n")
        out.write(f"    last_verdict:     {z3m.get('last_check_verdict')}\n")
        out.write(f"    unroll_steps:     {z3m.get('unroll_steps')}\n")
    else:
        out.write("  z3_incremental:     (not wired)\n")
    out.flush()


def _cmd_metrics(args: argparse.Namespace) -> int:
    """Dump the Prometheus metrics registry from the local process (v0.9.0).

    This is a process-local view — the CLI does not talk to a running
    daemon here. The default module-level :class:`CageMetrics` is the
    single source of truth across the daemon, SaaS, and CLI inside one
    process; when the CLI runs in a separate process (the common case
    with a running daemon), it shows its own zeroed registry. For a live
    counter dump, scrape ``/metrics`` on the SaaS instead.
    """
    try:
        from adapter.metrics import get_default, is_available
    except ImportError as exc:
        sys.stderr.write(f"tau-x402-cage metrics: {exc}\n")
        return 2
    if not is_available():
        sys.stderr.write(
            "tau-x402-cage metrics: prometheus_client not installed; "
            "install with `pip install tau-x402-cage[metrics]`\n"
        )
        return 2
    metrics = get_default()
    fmt = getattr(args, "fmt", "text")
    if fmt == "json":
        sys.stdout.write(json.dumps(metrics.snapshot(), sort_keys=True) + "\n")
    else:
        sys.stdout.buffer.write(metrics.render_text())
        sys.stdout.buffer.write(b"\n")
    sys.stdout.flush()
    return 0


def _cmd_suggest(args: argparse.Namespace) -> int:
    """Authoring loop for policy.yaml.

    Three modes wired on one subcommand:

    1. default (positional ``request``) — emit the LLM prompt that
       translates ``request`` into policy.yaml. Offline by design: no
       API keys, no network. (v0.2.0 behaviour, preserved.)
    2. ``--from-nl <description>`` — same prompt, but the description
       comes from a flag so shell quoting is cleaner for multi-word
       phrases and interactive flows.
    3. ``--round-trip`` — read YAML from stdin, lint it via
       ``adapter.policy_linter``, and narrate the lint-clean policy
       back to the operator in plain English. On lint errors, print
       the report and exit 1; on unloadable YAML, exit 2.

    Modes 1 and 3 are composable: an operator can pipe mode-1's prompt
    into an LLM, pipe the model's YAML back into mode 3, and read a
    narrated description without ever touching the daemon.
    """
    round_trip = bool(getattr(args, "round_trip", False))
    from_nl: str = (getattr(args, "from_nl", None) or "").strip()

    if round_trip:
        return _cmd_suggest_round_trip()

    request = from_nl or (" ".join(args.request) if args.request else "")
    if not request:
        sys.stderr.write(
            "tau-x402-cage suggest: provide a plain-English policy description\n"
            "  example: tau-x402-cage suggest 'cap daily at $500, only anthropic'\n"
            "  example: tau-x402-cage suggest --from-nl 'max $50/day to anthropic'\n"
            "  example: tau-x402-cage suggest --round-trip < policy.yaml\n"
        )
        return 2
    sys.stdout.write(
        "Paste this prompt into Claude, ChatGPT, or any LLM; pipe the\n"
        "response into a policy.yaml file, then run:\n"
        "  tau-x402-cage suggest --round-trip < policy.yaml\n"
        "to lint and narrate the result.\n"
        "\n"
        "--- BEGIN PROMPT ---\n"
    )
    sys.stdout.write(SUGGEST_PROMPT_TEMPLATE.format(user_request=request))
    sys.stdout.write("--- END PROMPT ---\n")
    return 0


def _cmd_suggest_round_trip() -> int:
    """Read YAML from stdin, lint it, narrate it on success.

    On success: print the English description to stdout, exit 0.
    On lint errors: print the lint report to stdout, exit 1.
    On unloadable YAML / unknown kinds: print the error, exit 1 (we
    surface as a lint failure rather than exit 2 because the round-trip
    caller already knows the file is under construction).
    """
    from adapter.policy_linter import LintError, lint_policy
    from adapter.policy_loader import PolicyLoaderError, load_policy
    from adapter.policy_narrator import narrate_policy

    # Read YAML from stdin. If stdin is empty the operator got the
    # invocation wrong — surface it rather than narrating "No rules".
    yaml_text = sys.stdin.read()
    if not yaml_text.strip():
        sys.stderr.write(
            "tau-x402-cage suggest --round-trip: stdin is empty. "
            "Pipe the LLM's YAML response into this command.\n"
        )
        return 2

    # Load + lint in-memory (no tempfile). load_policy accepts a Path,
    # so we stage the bytes under a tmp file that lives only for the
    # call. Policy loader needs a real file because it records
    # ``source_path`` on the LoadedPolicy.
    import tempfile
    tmp = tempfile.NamedTemporaryFile(
        mode="w", encoding="utf-8", suffix=".yaml", delete=False,
    )
    try:
        tmp.write(yaml_text)
        tmp.flush()
        tmp.close()
        try:
            loaded = load_policy(Path(tmp.name))
        except PolicyLoaderError as exc:
            sys.stdout.write(f"lint failed: {exc}\n")
            return 1
        try:
            report = lint_policy(loaded)
        except LintError as exc:
            sys.stdout.write(f"lint failed: {exc}\n")
            return 1
    finally:
        try:
            os.unlink(tmp.name)
        except OSError:
            pass

    if report.has_errors():
        sys.stdout.write(report.to_text())
        return 1

    # Lint-clean: narrate.
    sys.stdout.write("Policy narration:\n\n")
    sys.stdout.write(narrate_policy(loaded.invariants))
    sys.stdout.write("\n")
    return 0


def _cmd_narrate(args: argparse.Namespace) -> int:
    """Standalone narrator. Load a policy YAML and emit English.

    Output format selectable via ``--format``:

    * ``plain`` (default) — one sentence per rule, newline-separated.
    * ``markdown`` — same sentences as a bulleted list.
    * ``json`` — structured output (class, tier, sentence + summary).

    Exit codes:
        0 — narration printed.
        2 — file missing / unloadable YAML / unknown invariant kind.
    """
    from adapter.policy_loader import PolicyLoaderError, load_policy
    from adapter.policy_narrator import (
        narrate_policy,
        narrate_policy_json,
        narrate_policy_markdown,
    )

    try:
        loaded = load_policy(Path(args.policy_path))
    except PolicyLoaderError as exc:
        sys.stderr.write(f"tau-x402-cage narrate: {exc}\n")
        return 2
    except OSError as exc:
        sys.stderr.write(f"tau-x402-cage narrate: {exc}\n")
        return 2

    fmt = getattr(args, "fmt", "plain")
    if fmt == "json":
        sys.stdout.write(narrate_policy_json(loaded.invariants) + "\n")
    elif fmt == "markdown":
        sys.stdout.write(narrate_policy_markdown(loaded.invariants) + "\n")
    else:
        sys.stdout.write(narrate_policy(loaded.invariants) + "\n")
    sys.stdout.flush()
    return 0


class _CliConfigError(ValueError):
    """Raised by _resolve_run_config when CLI/env/policy inputs are malformed."""


def _resolve_run_config(args: argparse.Namespace, env: dict[str, str]):
    """Resolve (mode, tau_timeout_ms, semantic_fragment, loaded) from inputs.

    Resolution order for each value (highest priority first):
      CLI flag > env var > policy.yaml `cage:` block > built-in default.

    Args:
        args: argparse namespace from the top-level parser.
        env:  env mapping (pass os.environ in production; a dict in tests).

    Returns:
        (mode, tau_timeout_ms, semantic_fragment, loaded) where `loaded` is
        the parsed LoadedPolicy (or None if --policy wasn't given).

    Raises:
        _CliConfigError: on invalid env vars or validation failures. The
        message is suitable for printing directly to stderr.
    """
    mode: str = "compat"
    tau_timeout_ms: int = 10000
    semantic_fragment: str = "v1"
    loaded = None

    # 1. policy.yaml cage: block (lowest precedence after defaults).
    if args.policy:
        try:
            loaded = load_policy(args.policy)
        except PolicyLoaderError as exc:
            raise _CliConfigError(f"policy load failed: {exc}") from exc
        # ``resolved_prover_mode`` folds the brief's ``flexible`` alias onto
        # the internal ``compat`` wire name; ``guaranteed`` rides through
        # unchanged. We use the resolved form for the admission pipeline.
        mode = loaded.cage_config.resolved_prover_mode
        tau_timeout_ms = loaded.cage_config.tau_timeout_ms
        semantic_fragment = loaded.cage_config.semantic_fragment

    # 2. env vars override policy.yaml.
    env_mode = env.get("CAGE_PROVER_MODE")
    if env_mode:
        mode = env_mode
    env_timeout = env.get("CAGE_TAU_TIMEOUT_MS")
    if env_timeout:
        try:
            tau_timeout_ms = int(env_timeout)
        except ValueError as exc:
            raise _CliConfigError(
                f"CAGE_TAU_TIMEOUT_MS must be an integer (ms), got {env_timeout!r}"
            ) from exc
    env_fragment = env.get("CAGE_SEMANTIC_FRAGMENT")
    if env_fragment:
        semantic_fragment = env_fragment

    # 3. CLI flags override env vars (highest precedence).
    if args.prover_mode:
        mode = args.prover_mode
    if args.tau_timeout_ms is not None:
        tau_timeout_ms = args.tau_timeout_ms
    if args.semantic_fragment is not None:
        semantic_fragment = args.semantic_fragment

    # Fold the brief's ``flexible`` alias onto ``compat`` for any path
    # (env var, CLI flag) that could supply it. Keeps the downstream
    # server contract unchanged.
    if mode == "flexible":
        mode = "compat"

    # 4. final validation of resolved values.
    if mode not in ("compat", "verified", "strict", "guaranteed"):
        raise _CliConfigError(
            f"prover_mode must be compat|verified|strict|flexible|guaranteed, "
            f"got {mode!r}"
        )
    if not isinstance(tau_timeout_ms, int) or tau_timeout_ms <= 0:
        raise _CliConfigError(
            f"tau_timeout_ms must be a positive integer (ms), got {tau_timeout_ms!r}"
        )
    if semantic_fragment != "v1":
        raise _CliConfigError(
            f"semantic_fragment must be 'v1' in this release, got {semantic_fragment!r}"
        )
    return mode, tau_timeout_ms, semantic_fragment, loaded


def _cmd_audit_export(args: argparse.Namespace) -> int:
    """Fetch the unsigned audit bundle, sign with ed25519, write JSONL.

    Signs client-side so the daemon never handles the private key. The CLI
    reads the PEM-encoded private key from disk, signs the canonical bundle
    bytes, and writes a two-line JSONL (bundle + signature sidecar).
    """
    try:
        from adapter.audit_export import AuditExportError, sign_bundle
    except ImportError as exc:
        sys.stderr.write(f"tau-x402-cage audit-export: {exc}\n")
        return 2
    try:
        resp = _send_op(args.socket, {"op": "export_audit"})
    except (OSError, RuntimeError, json.JSONDecodeError) as exc:
        sys.stderr.write(
            f"tau-x402-cage audit-export: failed to reach daemon at {args.socket}: {exc}\n"
        )
        return 2
    if resp.get("verdict") != "ok":
        sys.stderr.write(
            f"tau-x402-cage audit-export: daemon refused op: "
            f"{resp.get('reason') or resp}\n"
        )
        return 2
    bundle = resp.get("bundle")
    if not isinstance(bundle, dict):
        sys.stderr.write(
            "tau-x402-cage audit-export: daemon returned no bundle\n"
        )
        return 2
    try:
        jsonl_bytes = sign_bundle(bundle, args.private_key)
    except AuditExportError as exc:
        sys.stderr.write(f"tau-x402-cage audit-export: {exc}\n")
        return 2
    try:
        out_path = Path(args.out)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_bytes(jsonl_bytes)
    except OSError as exc:
        sys.stderr.write(f"tau-x402-cage audit-export: cannot write {args.out!r}: {exc}\n")
        return 2
    sys.stdout.write(
        f"Wrote signed audit bundle: {args.out}\n"
        f"  revisions:     {len(bundle.get('revisions') or [])}\n"
        f"  branches:      {len(bundle.get('branches') or [])}\n"
        f"  proposals:     {len(bundle.get('proposals') or [])}\n"
        f"  merge_commits: {len(bundle.get('merge_commits') or [])}\n"
        f"Verify offline: tau-x402-cage audit-verify {args.out} --public-key <pem>\n"
    )
    return 0


def _cmd_audit_verify(args: argparse.Namespace) -> int:
    """Offline-verify a signed audit bundle. Exit 0 on valid, 1 otherwise."""
    try:
        from adapter.audit_export import AuditExportError, verify_bundle
    except ImportError as exc:
        sys.stderr.write(f"tau-x402-cage audit-verify: {exc}\n")
        return 2
    try:
        result = verify_bundle(args.path, args.public_key)
    except AuditExportError as exc:
        sys.stderr.write(f"tau-x402-cage audit-verify: {exc}\n")
        return 2
    if result.valid:
        sys.stdout.write(
            f"OK: audit bundle {args.path} is valid\n"
            f"  bundle_version:   {result.bundle_version}\n"
            f"  exported_at_unix: {result.exported_at_unix}\n"
            f"  revisions:        {result.revisions}\n"
            f"  branches:         {result.branches}\n"
            f"  proposals:        {result.proposals}\n"
            f"  merge_commits:    {result.merge_commits}\n"
        )
        return 0
    sys.stderr.write(
        f"INVALID: audit bundle {args.path} failed verification\n"
        f"  reason: {result.reason}\n"
    )
    return 1


def _cmd_bundle(args: argparse.Namespace) -> int:
    """Fetch a signed decision bundle from the daemon and write it to disk.

    The positional argument accepts either an ``intent_hash`` (hex) or a
    ``bundle_id`` (UUID); the daemon looks up the matching verdict record,
    re-signs the envelope with the daemon's HMAC secret, assembles the
    bundle, and returns the canonical JSONL.
    """
    lookup = args.lookup
    payload: dict[str, Any] = {"op": "build_decision_bundle"}
    # Heuristic: a 64-char hex string is an intent_hash; anything shorter
    # (typically a 36-char UUID) is a bundle_id. Callers that care can
    # force via --bundle-id / --intent-hash.
    if getattr(args, "bundle_id", False):
        payload["bundle_id"] = lookup
    elif getattr(args, "intent_hash", False):
        payload["intent_hash"] = lookup
    elif len(lookup) == 64 and all(c in "0123456789abcdef" for c in lookup.lower()):
        payload["intent_hash"] = lookup
    else:
        payload["bundle_id"] = lookup
    if getattr(args, "chain_limit", None) is not None:
        payload["chain_limit"] = int(args.chain_limit)
    try:
        resp = _send_op(args.socket, payload, timeout=10.0)
    except (OSError, RuntimeError, json.JSONDecodeError) as exc:
        sys.stderr.write(
            f"tau-x402-cage bundle: failed to reach daemon at {args.socket}: {exc}\n"
        )
        return 2
    if resp.get("verdict") != "ok":
        sys.stderr.write(
            f"tau-x402-cage bundle: daemon refused op: "
            f"{resp.get('reason') or resp}\n"
        )
        return 2
    jsonl = resp.get("bundle_jsonl")
    if not isinstance(jsonl, str):
        sys.stderr.write(
            "tau-x402-cage bundle: daemon returned no bundle_jsonl\n"
        )
        return 2
    try:
        out_path = Path(args.out)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_bytes(jsonl.encode("utf-8"))
    except OSError as exc:
        sys.stderr.write(f"tau-x402-cage bundle: cannot write {args.out!r}: {exc}\n")
        return 2
    sys.stdout.write(
        f"Wrote decision bundle: {args.out}\n"
        f"  bundle_id:   {resp.get('bundle_id')}\n"
        f"  intent_hash: {resp.get('intent_hash')}\n"
        f"  chain_total: {resp.get('chain_total')}\n"
        f"  truncated:   {resp.get('truncated')}\n"
        f"Verify offline: tau-x402-cage bundle-verify {args.out} "
        f"--public-key <pem> | --secret <hex>\n"
    )
    return 0


def _cmd_bundle_verify(args: argparse.Namespace) -> int:
    """Offline-verify a signed decision bundle. Exit 0 valid / 1 invalid / 2 transport."""
    try:
        from adapter.decision_bundle import (
            DecisionBundleError,
            bundle_from_jsonl,
            verify_decision_bundle,
        )
    except ImportError as exc:
        sys.stderr.write(f"tau-x402-cage bundle-verify: {exc}\n")
        return 2
    try:
        data = Path(args.path).read_bytes()
    except FileNotFoundError:
        sys.stderr.write(f"tau-x402-cage bundle-verify: bundle not found: {args.path}\n")
        return 2
    except OSError as exc:
        sys.stderr.write(
            f"tau-x402-cage bundle-verify: cannot read {args.path!r}: {exc}\n"
        )
        return 2
    try:
        bundle = bundle_from_jsonl(data)
    except DecisionBundleError as exc:
        sys.stderr.write(
            f"tau-x402-cage bundle-verify: malformed bundle: {exc}\n"
        )
        return 2
    secret: Optional[bytes] = None
    public_key = None
    if args.secret is not None:
        try:
            secret = bytes.fromhex(args.secret.strip())
        except ValueError as exc:
            sys.stderr.write(
                f"tau-x402-cage bundle-verify: --secret must be hex: {exc}\n"
            )
            return 2
    if args.public_key is not None:
        try:
            from adapter.verdict_signer import (
                KeyMaterialError,
                load_ed25519_public_key,
            )
        except ImportError as exc:
            sys.stderr.write(f"tau-x402-cage bundle-verify: {exc}\n")
            return 2
        try:
            public_key = load_ed25519_public_key(args.public_key)
        except KeyMaterialError as exc:
            sys.stderr.write(f"tau-x402-cage bundle-verify: {exc}\n")
            return 2
    if secret is None and public_key is None:
        sys.stderr.write(
            "tau-x402-cage bundle-verify: supply --secret or --public-key\n"
        )
        return 2
    result = verify_decision_bundle(bundle, secret=secret, public_key=public_key)
    if result.valid:
        sys.stdout.write(
            f"OK: decision bundle {args.path} is valid\n"
            f"  bundle_version:       {result.bundle_version}\n"
            f"  bundle_id:            {result.bundle_id}\n"
            f"  envelope_signature:   {result.envelope_signature_ok}\n"
            f"  revision_binding:     {result.revision_binding_ok}\n"
            f"  compile_hash:         {result.compile_hash_ok}\n"
        )
        return 0
    sys.stderr.write(
        f"INVALID: decision bundle {args.path} failed verification\n"
        f"  reason:               {result.reason}\n"
        f"  envelope_signature:   {result.envelope_signature_ok}\n"
        f"  revision_binding:     {result.revision_binding_ok}\n"
        f"  compile_hash:         {result.compile_hash_ok}\n"
    )
    return 1


def _cmd_keygen_ed25519(args: argparse.Namespace) -> int:
    """Write a fresh Ed25519 keypair to <out>.pem / <out>.pub.

    The private key is created with mode 0600 so a world-readable PEM never
    exists on disk, even briefly. Public key is written mode 0644. Refuses
    to overwrite an existing file on either path; use a new --out prefix
    for key rotation.
    """
    try:
        from adapter.verdict_signer import (
            KeyMaterialError,
            generate_ed25519_keypair,
        )
    except ImportError as exc:
        sys.stderr.write(f"tau-x402-cage keygen-ed25519: {exc}\n")
        return 2
    try:
        priv_path, pub_path = generate_ed25519_keypair(args.out)
    except KeyMaterialError as exc:
        sys.stderr.write(f"tau-x402-cage keygen-ed25519: {exc}\n")
        return 2
    sys.stdout.write(
        f"Wrote ed25519 keypair:\n"
        f"  private: {priv_path} (mode 0600)\n"
        f"  public:  {pub_path}\n"
        f"Export to run the daemon in ed25519 mode:\n"
        f"  export TAU_CAGE_ED25519_PRIVATE_KEY={priv_path}\n"
        f"  export TAU_CAGE_ED25519_PUBLIC_KEY={pub_path}\n"
        f"  export TAU_CAGE_SIGNING_ALGORITHM=ed25519\n"
    )
    return 0


def _cmd_replay(args: argparse.Namespace) -> int:
    """Run a policy replay / backtest against a live daemon (v0.10.0).

    Loads the candidate policy from YAML, sends a ``replay_policy`` op
    with the optional ``window_seconds`` / ``max_entries`` knobs, and
    renders a summary table + top-10 changed entries.
    """
    try:
        entries = _load_candidate_invariants(Path(args.candidate))
    except PolicyLoaderError as exc:
        sys.stderr.write(f"tau-x402-cage replay: {exc}\n")
        return 2
    request: dict[str, Any] = {
        "op": "replay_policy",
        "invariants": entries,
    }
    if args.window is not None:
        request["window_seconds"] = args.window
    if args.limit is not None:
        request["max_entries"] = args.limit
    try:
        resp = _send_op(args.socket, request, timeout=30.0)
    except (OSError, RuntimeError, json.JSONDecodeError) as exc:
        sys.stderr.write(
            f"tau-x402-cage replay: failed to reach daemon at {args.socket}: {exc}\n"
        )
        return 2
    if resp.get("verdict") != "ok":
        sys.stderr.write(
            f"tau-x402-cage replay: {resp.get('reason') or resp}\n"
        )
        return 2
    _render_replay(resp, sys.stdout)
    return 0


def _render_replay(resp: dict[str, Any], out) -> None:
    """Render a replay_policy response: summary table + top-10 changed.

    One fact per line in the summary so `grep` stays useful. The per-entry
    table is a fixed-width column layout (amount, provider, before→after,
    rule_id) truncated at ten rows; the wire response carries the full list
    for tools that need more.
    """
    total = resp.get("total", 0)
    unchanged = resp.get("unchanged", 0)
    new_rejects = resp.get("new_rejects", 0)
    new_permits = resp.get("new_permits", 0)
    inconclusive = resp.get("prover_inconclusive", 0)
    window = resp.get("window_seconds")
    max_entries = resp.get("max_entries")
    history_available = resp.get("history_available", 0)
    out.write("Policy replay / backtest\n")
    out.write(f"  history_available:  {history_available}\n")
    out.write(f"  replayed:           {total}\n")
    out.write(f"  window_seconds:     {window if window is not None else '(all)'}\n")
    out.write(f"  max_entries:        {max_entries}\n")
    out.write(f"  unchanged:          {unchanged}\n")
    out.write(f"  new_rejects:        {new_rejects}\n")
    out.write(f"  new_permits:        {new_permits}\n")
    out.write(f"  prover_inconclusive: {inconclusive}\n")
    changed = resp.get("changed") or []
    if not changed:
        out.write("  changed: (none)\n")
        out.flush()
        return
    shown = min(len(changed), 10)
    out.write(f"  top {shown} changed (of {len(changed)}):\n")
    # Column widths tuned for 100-char lines; longer values truncate with
    # an ellipsis so columns stay aligned.
    out.write(
        "    "
        f"{'ts':>10}  {'amount':>10}  {'provider':<18}  "
        f"{'before':<8}  {'after':<8}  {'rule_id':<28}\n"
    )
    for c in changed[:10]:
        intent = c.get("intent") or {}
        ts = intent.get("timestamp_unix", "-")
        amount = str(intent.get("amount", "-"))
        provider = str(intent.get("provider", "-"))
        before = c.get("before_verdict", "-")
        after = c.get("after_verdict", "-")
        rule_id = str(c.get("rule_id") or "-")
        out.write(
            "    "
            f"{str(ts):>10}  {amount:>10}  {_truncate(provider, 18):<18}  "
            f"{before:<8}  {after:<8}  {_truncate(rule_id, 28):<28}\n"
        )
    out.flush()


def _truncate(s: str, n: int) -> str:
    """Truncate a string to ``n`` characters with an ellipsis if it overflows."""
    if len(s) <= n:
        return s
    if n <= 1:
        return s[:n]
    return s[: n - 1] + "…"


def _cmd_bench(args: argparse.Namespace) -> int:
    """Run the 5-test TTI conformance battery and report pass/fail.

    Local mode (default) runs the battery in-process; ``--against`` hits a
    remote SaaS for the liveness probe. ``--json`` emits the full TTIResult
    as machine-parseable JSON on stdout.

    ``--check`` + ``--max-seconds`` turn this into a regression guard: exit
    non-zero when the bench's total-seconds exceeds the budget, even if
    every test is decisive. Useful for CI gates that want a soft budget
    knob on top of the hard "all-decisive" contract.
    """
    try:
        from adapter.tti_bench import (
            DEFAULT_PER_TEST_BUDGET_SECONDS,
            TTIBenchError,
            render_text,
            run_battery,
        )
    except ImportError as exc:
        sys.stderr.write(f"tau-x402-cage bench: {exc}\n")
        return 2

    specs_dir = Path(args.specs) if args.specs else None
    per_test_budget = args.per_test_budget_seconds or DEFAULT_PER_TEST_BUDGET_SECONDS
    try:
        result = run_battery(
            specs_dir=specs_dir,
            against_url=args.against,
            bearer_token=args.bearer_token,
            per_test_budget_seconds=per_test_budget,
        )
    except TTIBenchError as exc:
        sys.stderr.write(f"tau-x402-cage bench: {exc}\n")
        return 2

    if args.json:
        sys.stdout.write(result.to_json() + "\n")
    else:
        sys.stdout.write(render_text(result))
    sys.stdout.flush()

    # Exit-code policy (stable for CI):
    #   0  → all decisive AND all passed AND (no --check OR under budget)
    #   1  → at least one test failed, or --check budget exceeded
    #   2  → config / import / transport error (handled above)
    if not (result.all_passed and result.all_decisive):
        return 1
    if args.check and args.max_seconds is not None:
        if result.total_seconds > args.max_seconds:
            sys.stderr.write(
                f"tau-x402-cage bench: regression — total_seconds "
                f"{result.total_seconds:.3f} > max_seconds {args.max_seconds}\n"
            )
            return 1
    return 0


def _cmd_mutation_risk(args: argparse.Namespace) -> int:
    """Offline dry-run for the strict mutation contract (v0.13.0).

    Loads candidate invariants from YAML, fetches the daemon's active
    policy, derives the ``{added, removed}`` delta, and prints the
    ``mutation_risk`` / ``affected_scope`` / ``would_break_without_proof``
    report without touching the daemon's registry. Useful as a CI gate
    on candidate policies before they're declared.

    Exit codes:
      0 — report printed (any risk bucket).
      2 — YAML parse error, daemon unreachable, or malformed response.
    """
    try:
        candidate_entries = _load_candidate_invariants(Path(args.candidate))
    except PolicyLoaderError as exc:
        sys.stderr.write(f"tau-x402-cage mutation-risk: {exc}\n")
        return 2

    # Fetch the active policy from the daemon so the delta is diff-based.
    try:
        active_resp = _send_op(args.socket, {"op": "inspect_policy"}, timeout=5.0)
    except (OSError, RuntimeError, json.JSONDecodeError) as exc:
        sys.stderr.write(
            f"tau-x402-cage mutation-risk: failed to reach daemon at "
            f"{args.socket}: {exc}\n"
        )
        return 2
    if active_resp.get("verdict") != "ok":
        sys.stderr.write(
            f"tau-x402-cage mutation-risk: {active_resp.get('reason') or active_resp}\n"
        )
        return 2

    # Build registries from the two invariant lists. Both reuse the
    # daemon's payload builder via a throwaway CageDaemon instance; this
    # is the one place the CLI has to evaluate payload→Invariant outside
    # the daemon process.
    from adapter.mutation_safety import (
        RevisionDelta, compute_mutation_risk_report,
    )
    from adapter.x402_registry import X402Registry

    # The inspect_policy response carries structured invariant summaries;
    # we re-parse via the policy_loader rehydration path to get live
    # Invariant instances.
    try:
        candidate_inv_list = _payload_list_to_invariants(candidate_entries)
        active_inv_list = _active_policy_to_invariants(active_resp)
    except (PolicyLoaderError, ValueError, TypeError) as exc:
        sys.stderr.write(f"tau-x402-cage mutation-risk: {exc}\n")
        return 2

    current_registry = X402Registry.empty()
    for inv in active_inv_list:
        current_registry = current_registry.declare(inv)

    # Delta: what's in candidate but not active = added; in active but
    # not candidate = removed. Identity via (class, repr) keys.
    def _key(inv):
        return (type(inv).__name__, repr(inv))
    active_map = {_key(i): i for i in active_inv_list}
    candidate_map = {_key(i): i for i in candidate_inv_list}
    added = tuple(candidate_map[k] for k in candidate_map.keys() - active_map.keys())
    removed = tuple(active_map[k] for k in active_map.keys() - candidate_map.keys())
    delta = RevisionDelta(added=added, removed=removed)

    report = compute_mutation_risk_report(current_registry, delta)
    if args.fmt == "json":
        sys.stdout.write(json.dumps(report.to_dict(), indent=2, sort_keys=True) + "\n")
    else:
        _render_mutation_risk_text(report, sys.stdout)
    sys.stdout.flush()
    return 0


def _payload_list_to_invariants(entries: list[dict]) -> list:
    """Rehydrate a list of payload dicts into Invariant instances.

    Uses ``daemon.server.CageDaemon._build_x402_invariant`` semantics so
    the mapping stays in sync with the wire taxonomy. Kept local to the
    CLI so the daemon doesn't have to ship a payload-building helper.
    """
    from decimal import Decimal, InvalidOperation
    from adapter.invariants import (
        CounterpartyConstraint, MaxPerCall, MutualExclusion, ProviderAllowlist,
        RetryRateLimit, RollingWindowCap, SpendingCap,
    )

    out: list = []
    for entry in entries:
        kind = entry.get("kind")
        try:
            if kind == "spending_cap":
                out.append(SpendingCap(
                    max_amount=Decimal(str(entry["max_amount"])),
                    currency=entry.get("currency", "USDC"),
                    scope=entry.get("scope", "per_window"),
                    window_seconds=entry.get("window_seconds"),
                    provider=entry.get("provider"),
                ))
            elif kind == "max_per_call":
                out.append(MaxPerCall(
                    max_amount=Decimal(str(entry["max_amount"])),
                    currency=entry.get("currency", "USDC"),
                ))
            elif kind == "provider_allowlist":
                out.append(ProviderAllowlist(
                    providers=frozenset(entry.get("providers", [])),
                ))
            elif kind == "retry_rate_limit":
                out.append(RetryRateLimit(
                    min_gap_seconds=int(entry["min_gap_seconds"]),
                ))
            elif kind == "rolling_window_cap":
                out.append(RollingWindowCap(
                    max_count=int(entry["max_count"]),
                    window_seconds=int(entry["window_seconds"]),
                    group_by=entry.get("group_by", "provider"),
                ))
            elif kind == "counterparty_constraint":
                out.append(CounterpartyConstraint(
                    approved_ids=frozenset(entry.get("approved_ids", [])),
                    sanctioned_ids=frozenset(entry.get("sanctioned_ids", [])),
                ))
            elif kind == "mutual_exclusion":
                out.append(MutualExclusion(
                    group_a=frozenset(entry.get("group_a", [])),
                    group_b=frozenset(entry.get("group_b", [])),
                ))
            else:
                raise ValueError(f"unknown invariant kind: {kind!r}")
        except (KeyError, InvalidOperation) as exc:
            raise ValueError(f"bad invariant entry: {exc}") from exc
    return out


def _active_policy_to_invariants(inspect_resp: dict) -> list:
    """Convert ``inspect_policy`` response's invariant summaries into Invariant instances.

    The inspect response surfaces invariants as dicts with ``class_name``
    + ``repr_entry`` fields (same shape as ``_serialize_invariant``). We
    rehydrate via the constructor registry in ``adapter.policy_revision``
    so the mapping stays authoritative.
    """
    from adapter.policy_revision import _rehydrate_invariant
    # inspect_policy returns entries under "invariants". Each entry carries
    # {"class_name", "repr_entry"} on newer daemons; older ones use "repr".
    entries = inspect_resp.get("invariants") or []
    out: list = []
    for e in entries:
        if "class_name" in e and "repr_entry" in e:
            out.append(_rehydrate_invariant({
                "class_name": e["class_name"],
                "repr": e["repr_entry"],
            }))
        elif "class_name" in e and "repr" in e:
            out.append(_rehydrate_invariant({
                "class_name": e["class_name"],
                "repr": e["repr"],
            }))
        # Silently skip entries that don't carry enough to rehydrate; the
        # dry-run stays best-effort so a slightly stale inspect shape
        # doesn't block CI callers.
    return out


def _render_mutation_risk_text(report, out) -> None:
    """Render a MutationRiskReport as a compact, scannable text block."""
    out.write("Mutation risk (dry-run)\n")
    out.write(f"  risk:                       {report.mutation_risk}\n")
    out.write(
        f"  would_break_without_proof:  {str(report.would_break_without_proof).lower()}\n"
    )
    scope = report.affected_scope
    out.write(
        f"  active_count / touched:     "
        f"{scope.get('active_count', 0)} / {scope.get('touched_count', 0)}\n"
    )
    providers = scope.get("providers") or []
    counterparties = scope.get("counterparties") or []
    currencies = scope.get("currencies") or []
    rule_classes = scope.get("rule_classes") or []
    fragments = scope.get("fragments") or []
    out.write(f"  providers:                  {providers}\n")
    out.write(f"  counterparties:             {counterparties}\n")
    out.write(f"  currencies:                 {currencies}\n")
    out.write(f"  rule_classes:               {rule_classes}\n")
    out.write(f"  fragments:                  {fragments}\n")
    if report.contradiction is not None:
        out.write("  contradiction:\n")
        out.write(f"    reason: {report.contradiction.unsat_explanation}\n")
        if report.contradiction.suggested_repair:
            out.write(f"    repair: {report.contradiction.suggested_repair}\n")
    out.flush()


def _cmd_cross_revision(args: argparse.Namespace) -> int:
    """Dry-run cross-revision compositional invariants (v0.14.0).

    Reads a candidate policy from ``--candidate``, fetches the daemon's
    currently-active revision, builds a synthetic next revision on the
    requested branch, and runs the validator wired into the daemon's
    env defaults. Prints the structured result.

    Exit codes:
      0 — all cross-revision invariants clean.
      1 — at least one violation (suitable as a CI gate).
      2 — bad candidate, daemon unreachable, or malformed response.
    """
    try:
        candidate_entries = _load_candidate_invariants(Path(args.candidate))
    except PolicyLoaderError as exc:
        sys.stderr.write(f"tau-x402-cage cross-revision: {exc}\n")
        return 2

    try:
        active_resp = _send_op(
            args.socket, {"op": "active_revision"}, timeout=5.0,
        )
    except (OSError, RuntimeError, json.JSONDecodeError) as exc:
        sys.stderr.write(
            f"tau-x402-cage cross-revision: failed to reach daemon at "
            f"{args.socket}: {exc}\n"
        )
        return 2
    if active_resp.get("verdict") != "ok":
        sys.stderr.write(
            f"tau-x402-cage cross-revision: {active_resp.get('reason') or active_resp}\n"
        )
        return 2

    try:
        candidate_inv_list = _payload_list_to_invariants(candidate_entries)
    except (PolicyLoaderError, ValueError, TypeError) as exc:
        sys.stderr.write(f"tau-x402-cage cross-revision: {exc}\n")
        return 2

    # Rehydrate the active revision. Shape varies slightly across daemon
    # versions; we handle the newer ``active_revision`` response that
    # surfaces invariants under ``revision.invariants``.
    from adapter.policy_revision import (
        PolicyRevision as _PolicyRevision,
        _rehydrate_invariant as _rehydrate,
    )
    rev_dict = active_resp.get("revision") or active_resp.get("active")
    old_revision: Optional[_PolicyRevision] = None
    if isinstance(rev_dict, dict):
        try:
            old_revision = _PolicyRevision.from_dict(rev_dict)
        except Exception:  # noqa: BLE001 - fall back to best-effort below
            old_revision = None
    old_invariants = tuple(old_revision.invariants) if old_revision else ()

    # Build a synthetic candidate revision that mimics what append()
    # would see: branch tag, content-addressed id, admitted-at now.
    import hashlib
    import time as _time
    cand_tuple = tuple(candidate_inv_list)
    cand_blob = repr([(type(i).__name__, repr(i)) for i in cand_tuple]).encode()
    config_hash = hashlib.sha256(cand_blob).hexdigest()[:16]
    now = int(_time.time())
    delta_added = [
        {"class_name": type(i).__name__, "repr": repr(i)}
        for i in cand_tuple
        if (type(i).__name__, repr(i))
        not in {(type(x).__name__, repr(x)) for x in old_invariants}
    ]
    delta_removed = [
        {"class_name": type(i).__name__, "repr": repr(i)}
        for i in old_invariants
        if (type(i).__name__, repr(i))
        not in {(type(x).__name__, repr(x)) for x in cand_tuple}
    ]
    candidate_revision = _PolicyRevision(
        revision_id=f"{config_hash}:dryrun",
        invariants=cand_tuple,
        proof_backend="dry-run",
        proof_strength="dry-run",
        prover_mode="dry-run",
        compile_hash=None,
        fragment_version=None,
        tau_backend_version=None,
        admitted_at_unix=now,
        predecessor_revision_id=(
            old_revision.revision_id if old_revision is not None else None
        ),
        delta={"added": delta_added, "removed": delta_removed},
        revision_depth=(old_revision.revision_depth + 1) if old_revision else 0,
        branch=args.branch,
    )

    # Build the validator from env so the CLI honours the same config
    # the daemon is running with.
    from adapter.cross_revision import build_validator_from_env
    validator = build_validator_from_env(dict(os.environ))
    if validator is None:
        sys.stderr.write(
            "tau-x402-cage cross-revision: no cross-revision invariants "
            "enabled via env. Set one or more of "
            "TAU_CAGE_CROSS_REVISION_NO_WEAKENING, "
            "TAU_CAGE_CROSS_REVISION_OVERRIDE_TTL, "
            "TAU_CAGE_CROSS_REVISION_CORE_BRANCH.\n"
        )
        return 2

    result = validator.validate(old_revision, candidate_revision, args.branch)
    if args.fmt == "json":
        sys.stdout.write(json.dumps(result.to_dict(), indent=2) + "\n")
    else:
        _render_cross_revision_text(result, sys.stdout, args.branch)
    sys.stdout.flush()
    return 0 if result.valid else 1


def _render_cross_revision_text(result, out, branch: str) -> None:
    """Render a :class:`ValidationResult` as human-readable lines."""
    if result.valid:
        out.write(
            f"Cross-revision check: CLEAN on branch {branch!r} "
            "(no violations).\n"
        )
        return
    out.write(
        f"Cross-revision check: REJECTED on branch {branch!r} "
        f"({len(result.violations)} violation(s))\n"
    )
    for v in result.violations:
        out.write(f"  - {v.invariant_name} [{v.category}]\n")
        out.write(f"      reason: {v.reason}\n")
        if v.old_value is not None:
            out.write(f"      old:    {v.old_value}\n")
        if v.new_value is not None:
            out.write(f"      new:    {v.new_value}\n")
    out.flush()


def _cmd_webhook_test(args: argparse.Namespace) -> int:
    """Send a synthetic verdict to ``--url`` signed with ``--secret``.

    Prints the canonical body + signature + headers so operators can
    paste them into a fixture when wiring a new receiver. The target
    receives a real HTTP POST; we treat any 2xx as success.
    """
    secret_raw: str = args.secret
    try:
        secret = bytes.fromhex(secret_raw) if _is_hex(secret_raw) else secret_raw.encode("utf-8")
    except ValueError as exc:
        sys.stderr.write(f"tau-x402-cage webhook-test: bad --secret: {exc}\n")
        return 2
    if len(secret) < 16:
        sys.stderr.write(
            "tau-x402-cage webhook-test: --secret must decode to >=16 bytes; "
            f"got {len(secret)}\n"
        )
        return 2
    sink = WebhookSink(url=args.url, secret=secret, name="cli-test")
    verdict = {
        "verdict": args.verdict,
        "rule_id": args.rule_id,
        "reason_text": "Synthetic verdict from `tau-x402-cage webhook-test`",
        "intent": {
            "amount": "1.00",
            "currency": "USDC",
            "provider": "test-provider",
            "counterparty": "test-counterparty",
            "rail": "x402",
            "timestamp_unix": 0,
        },
        "revision_id": None,
    }
    body = canonicalize_verdict(verdict)
    import time as _time
    ts = str(int(_time.time()))
    sig = compute_signature(secret, ts, body)
    sys.stdout.write(
        f"POST {args.url}\n"
        f"X-Cage-Signature: sha256={sig}\n"
        f"X-Cage-Timestamp: {ts}\n"
        f"Body (canonical, {len(body)} bytes):\n"
        f"  {body.decode('utf-8')}\n"
    )
    if args.dry_run:
        return 0
    sink.start()
    try:
        sink.emit(verdict)
        # Give the worker a moment to deliver before we tear down.
        import time as _t
        deadline = _t.monotonic() + max(args.timeout_s + 1.0, 5.0)
        while _t.monotonic() < deadline:
            snap = sink.metrics_snapshot()
            if snap["delivered"] or snap["failed"]:
                break
            _t.sleep(0.05)
    finally:
        sink.stop()
    snap = sink.metrics_snapshot()
    if snap["delivered"]:
        sys.stdout.write("Delivered: 2xx response received.\n")
        return 0
    sys.stderr.write(
        f"Delivery failed: delivered={snap['delivered']} failed={snap['failed']} "
        f"dropped={snap['dropped']}\n"
    )
    return 1


def _is_hex(s: str) -> bool:
    """True iff ``s`` is even-length and contains only hex digits."""
    if not s or len(s) % 2 != 0:
        return False
    try:
        bytes.fromhex(s)
        return True
    except ValueError:
        return False


def _load_webhook_sinks_from_env(
    env: dict[str, str],
    metrics: Any,
) -> list[WebhookSink]:
    """Load webhook sinks from ``TAU_CAGE_WEBHOOKS_YAML`` if set.

    Returns an empty list if the env var is unset. Raises
    ``WebhookConfigError`` on any parse / validation failure so the
    daemon CLI can surface a readable message and refuse to start
    (fail-closed, same pattern as v0.8.0 Redis).
    """
    path = env.get("TAU_CAGE_WEBHOOKS_YAML")
    if not path:
        return []
    configs = load_webhook_config(path)
    return [WebhookSink.from_config(cfg, metrics=metrics) for cfg in configs]


def _cmd_self_ref(args: argparse.Namespace) -> int:
    """Dispatch `tau-x402-cage self-ref <subcommand>` against a live daemon."""
    action = getattr(args, "self_ref_action", None)
    if action == "status":
        return _self_ref_status(args)
    sys.stderr.write(
        "tau-x402-cage self-ref: specify one of: status\n"
    )
    return 2


def _self_ref_status(args: argparse.Namespace) -> int:
    """Print the active instability guards + merge cooldown status.

    Human-readable table by default; ``--format json`` emits the raw daemon
    response for pipelines / incident scripts. Useful during an
    operational incident to see which providers are currently throttled
    and whether a merge into a given branch would short-circuit.
    """
    try:
        resp = _send_op(args.socket, {"op": "self_ref_status"})
    except (OSError, RuntimeError, json.JSONDecodeError) as exc:
        sys.stderr.write(
            f"tau-x402-cage self-ref status: failed to reach daemon "
            f"at {args.socket}: {exc}\n"
        )
        return 2
    if resp.get("verdict") != "ok":
        sys.stderr.write(f"tau-x402-cage self-ref status: {resp}\n")
        return 1
    fmt = getattr(args, "fmt", "text")
    if fmt == "json":
        sys.stdout.write(json.dumps(resp) + "\n")
        sys.stdout.flush()
        return 0
    # Text rendering: two sections. Compact, scannable, under 80 cols.
    out = sys.stdout
    guards = resp.get("instability_guards") or []
    if not guards:
        out.write("Instability guards: none\n")
    else:
        out.write(f"Instability guards ({len(guards)}):\n")
        header = (
            f"  {'provider':<20} {'active':<7} {'rej/thr':<9} "
            f"{'window':<8} {'tighten_to':<12} {'recover':<8}"
        )
        out.write(header + "\n")
        for g in guards:
            active_str = "ACTIVE" if g.get("active") else "quiet"
            rej_thr = f"{g.get('recent_rejects')}/{g.get('reject_threshold')}"
            tighten = f"{g.get('tighten_to')} {g.get('currency')}"
            out.write(
                f"  {g.get('provider', '?'):<20} {active_str:<7} "
                f"{rej_thr:<9} "
                f"{str(g.get('window_seconds'))+'s':<8} "
                f"{tighten:<12} "
                f"{str(g.get('recovery_seconds'))+'s':<8}\n"
            )
    cooldown = resp.get("merge_cooldown") or {}
    if not cooldown.get("enabled"):
        out.write("Merge cooldown: disabled\n")
    else:
        active = cooldown.get("active") or {}
        out.write(
            f"Merge cooldown: enabled (cooldown_seconds="
            f"{cooldown.get('cooldown_seconds')})\n"
        )
        if not active:
            out.write("  No branch in cooldown.\n")
        else:
            now = int(resp.get("now_unix") or 0)
            out.write(f"  {'branch':<24} {'expires_in':<10}\n")
            for branch, expiry in sorted(active.items()):
                remaining = max(0, int(expiry) - now)
                out.write(
                    f"  {branch:<24} {str(remaining)+'s':<10}\n"
                )
    out.flush()
    return 0


def _cmd_mutation_failures(args: argparse.Namespace) -> int:
    """Print recent mutation failures from the risk-dashboard log (v0.15.0).

    Supports ``--since`` (same window spec as ``risk-prevented``),
    ``--category`` (one of the five MutationFailureCategory values),
    ``--limit``, and ``--format text|json``. The text renderer prints
    one entry per line with iso-like timestamp, op, category, and reason
    so an operator can diff the timeline across mutations quickly.
    """
    since_unix: Optional[int] = None
    if getattr(args, "since", None):
        try:
            seconds = _parse_window(args.since)
        except ValueError as exc:
            sys.stderr.write(f"tau-x402-cage mutation-failures: {exc}\n")
            return 2
        if seconds > 0:
            import time as _time
            since_unix = int(_time.time()) - seconds
    try:
        op_payload: dict[str, Any] = {
            "op": "mutation_failures",
            "limit": int(args.limit),
        }
        if since_unix is not None:
            op_payload["since_unix"] = since_unix
        if getattr(args, "category", None):
            op_payload["category"] = args.category
        resp = _send_op(args.socket, op_payload)
    except (OSError, RuntimeError, json.JSONDecodeError) as exc:
        sys.stderr.write(
            f"tau-x402-cage mutation-failures: failed to reach daemon "
            f"at {args.socket}: {exc}\n"
        )
        return 2
    if resp.get("verdict") != "ok":
        category = resp.get("category", "error")
        reason = resp.get("reason", "(no reason)")
        sys.stderr.write(
            f"tau-x402-cage mutation-failures: {category}: {reason}\n"
        )
        return 1
    fmt = getattr(args, "fmt", "text")
    if fmt == "json":
        sys.stdout.write(json.dumps(resp) + "\n")
        sys.stdout.flush()
        return 0
    entries = resp.get("entries") or []
    out = sys.stdout
    out.write(f"Recent mutation failures ({len(entries)} of max {resp.get('cap')}):\n")
    if not entries:
        out.write("  (none)\n")
        out.flush()
        return 0
    for e in entries:
        ts = e.get("timestamp_unix") or 0
        # Render as unix + ISO-ish for quick grep; no timezone lib needed.
        from datetime import datetime, timezone
        iso = datetime.fromtimestamp(ts, tz=timezone.utc).isoformat(
            timespec="seconds"
        )
        out.write(
            f"  [{iso}] op={e.get('op')}  "
            f"category={e.get('category')}  "
            f"actor={e.get('actor_id') or '-'}\n"
        )
        reason = e.get("reason") or ""
        if reason:
            out.write(f"    reason: {reason}\n")
        risk = e.get("mutation_risk")
        if risk:
            out.write(f"    mutation_risk: {risk}\n")
    out.flush()
    return 0


def _cmd_constraints(args: argparse.Namespace) -> int:
    """Print the active constraints, grouped by class (v0.15.0).

    One line per class with count + fragment + top-5 scope summaries.
    ``--format json`` emits the raw daemon wire shape.
    """
    try:
        resp = _send_op(args.socket, {"op": "active_constraints"})
    except (OSError, RuntimeError, json.JSONDecodeError) as exc:
        sys.stderr.write(
            f"tau-x402-cage constraints: failed to reach daemon "
            f"at {args.socket}: {exc}\n"
        )
        return 2
    if resp.get("verdict") != "ok":
        category = resp.get("category", "error")
        reason = resp.get("reason", "(no reason)")
        sys.stderr.write(f"tau-x402-cage constraints: {category}: {reason}\n")
        return 1
    fmt = getattr(args, "fmt", "text")
    if fmt == "json":
        sys.stdout.write(json.dumps(resp) + "\n")
        sys.stdout.flush()
        return 0
    constraints = resp.get("constraints") or []
    total = resp.get("total", 0)
    out = sys.stdout
    out.write(
        f"Active constraints ({len(constraints)} classes, {total} rules):\n"
    )
    if not constraints:
        out.write("  (none)\n")
        out.flush()
        return 0
    for c in constraints:
        out.write(
            f"  {c.get('class_name')}  "
            f"count={c.get('count')}  "
            f"fragment={c.get('fragment')}\n"
        )
        for s in c.get("summaries") or []:
            out.write(f"    - {s}\n")
    out.flush()
    return 0


def _cmd_guarantees(args: argparse.Namespace) -> int:
    """Print the guarantees the cage currently delivers (v0.14.0).

    Three render modes:
      * ``--format text`` (default) — operator-readable three-column view.
      * ``--format json`` — the raw daemon response, for pipelines.
      * ``--only-lost`` — flip the list to show *inactive* guarantees and
        the plain-English "lost if disabled" description next to each.

    The text renderer is deliberately terse: one guarantee per block, each
    with id / summary / provided_by / evidence. An auditor reading this
    should be able to answer "what does the cage claim?" in a single
    scan.
    """
    try:
        resp = _send_op(args.socket, {"op": "guarantees"})
    except (OSError, RuntimeError, json.JSONDecodeError) as exc:
        sys.stderr.write(
            f"tau-x402-cage guarantees: failed to reach daemon "
            f"at {args.socket}: {exc}\n"
        )
        return 2
    if resp.get("verdict") != "ok":
        sys.stderr.write(f"tau-x402-cage guarantees: {resp}\n")
        return 1
    fmt = getattr(args, "fmt", "text")
    if fmt == "json":
        sys.stdout.write(json.dumps(resp) + "\n")
        sys.stdout.flush()
        return 0

    guarantees = resp.get("guarantees") or []
    only_lost = bool(getattr(args, "only_lost", False))
    if only_lost:
        selected = [g for g in guarantees if not g.get("active")]
        header = f"Inactive guarantees ({len(selected)}):"
    else:
        selected = [g for g in guarantees if g.get("active")]
        header = f"Active guarantees ({len(selected)}):"

    out = sys.stdout
    out.write(header + "\n")
    if not selected:
        out.write("  (none)\n")
        out.flush()
        return 0
    out.write("\n")
    # Group by category for a skim-readable report.
    by_category: dict[str, list[dict]] = {}
    for g in selected:
        by_category.setdefault(g.get("category", "other"), []).append(g)
    for category, items in by_category.items():
        out.write(f"[{category}]\n")
        for g in items:
            out.write(f"  {g.get('id'):<12} {g.get('summary', '')}\n")
            if only_lost:
                reason = g.get("inactive_reason") or "(unknown reason)"
                out.write(f"    off because: {reason}\n")
                out.write(
                    f"    lost: {g.get('lost_if_disabled', '')}\n"
                )
            else:
                out.write(
                    f"    provided by: {g.get('provided_by', '')}\n"
                )
                out.write(
                    f"    lost if disabled: {g.get('lost_if_disabled', '')}\n"
                )
        out.write("\n")
    out.flush()
    return 0


def _default_policy_path() -> Path:
    """Return the packaged default-policy YAML path.

    v0.21.0 front-door shipping default: a conservative safe-defaults
    policy with a deny-by-default provider allowlist. Lives next to
    this module so ``pip install`` ships it in the wheel without an
    explicit package_data entry (setuptools picks up *.yaml next to
    ``.py`` under the daemon package).
    """
    return Path(__file__).resolve().parent / "default_policy.yaml"


def _load_default_policy_without_allowlist(policy_path: Path):
    """Load the default policy + drop the provider_allowlist rule.

    Used by ``tau-x402 run --open-allowlist`` to strip the deny-by-
    default allowlist without having to duplicate the YAML. Raises
    the policy loader's native error on parse failures so the CLI
    surfaces a clean message at the boundary.
    """
    from adapter.invariants import ProviderAllowlist
    from adapter.policy_loader import load_policy

    loaded = load_policy(policy_path)
    kept = [inv for inv in loaded.invariants if not isinstance(inv, ProviderAllowlist)]
    # Rebuild an immutable copy with the filtered list. LoadedPolicy is
    # dataclass-like but we avoid reaching into its ctor shape; return
    # (kept_invariants, source_path) instead and let the caller declare
    # them into the daemon the same way _cmd_run does.
    return kept, loaded.source_path


def _cmd_demo_hero(args: argparse.Namespace) -> int:
    """Run the hero retry-loop demo as a subprocess and stream its output.

    v0.23.0 Priority 3. Convenience wrapper over
    ``python3 demos/hero_retry_loop.py`` so the demo can be invoked via a
    single command without operators knowing the path. The existing
    Python entry point still works and is the canonical implementation;
    this subcommand just shells out to it so flag semantics (``--quiet``,
    ``--json``, default TTY narration) stay in exactly one place.

    Exit codes:
      0  demo completed successfully (reject count >= 1)
      1  demo ran but produced no rejects (policy wiring regression)
      2  transport error (script missing, Python unavailable, timeout)
    """
    mode = getattr(args, "demo_action", None)
    if mode != "hero":
        sys.stderr.write(
            "tau-x402 demo: unknown sub-action "
            f"{mode!r}; try `tau-x402 demo hero`\n"
        )
        return 2
    # Resolve the demo script path relative to the installed package root.
    # The script ships alongside the daemon + adapter trees so the import
    # root is predictable: two levels up from this file.
    repo_root = Path(__file__).resolve().parent.parent
    script_path = repo_root / "demos" / "hero_retry_loop.py"
    if not script_path.is_file():
        sys.stderr.write(
            f"tau-x402 demo hero: demo script not found at {script_path}\n"
            "  reinstall tau-x402-cage with the demos/ tree, or invoke\n"
            "  the demo directly if you have a checkout.\n"
        )
        return 2
    # Forward the three flags the underlying demo already honours. The
    # CLI preserves the demo's own contract so ``tau-x402 demo hero
    # --json`` is identical to ``python3 demos/hero_retry_loop.py --json``.
    forward: list[str] = []
    if getattr(args, "quiet", False):
        forward.append("--quiet")
    if getattr(args, "fmt", None) == "json":
        forward.append("--json")
    # Run in a child interpreter so the demo's stdout streams straight
    # through. Inherit the parent's environment so DYLD_LIBRARY_PATH etc.
    # reach the child — the Tau binding ships as a native extension.
    env = os.environ.copy()
    # Ensure the repo root is importable inside the child so the demo's
    # `from adapter...` imports resolve when the package is run out of a
    # checkout rather than a pip install.
    existing_pp = env.get("PYTHONPATH", "")
    env["PYTHONPATH"] = (
        str(repo_root) + (os.pathsep + existing_pp if existing_pp else "")
    )
    import subprocess  # local: avoid top-level import for startup speed
    try:
        result = subprocess.run(
            [sys.executable, str(script_path), *forward],
            env=env,
            timeout=60,
        )
    except FileNotFoundError as exc:
        sys.stderr.write(
            f"tau-x402 demo hero: could not launch python interpreter: {exc}\n"
        )
        return 2
    except subprocess.TimeoutExpired:
        sys.stderr.write(
            "tau-x402 demo hero: timed out after 60s; rerun with --quiet\n"
        )
        return 2
    return int(result.returncode)


def _cmd_front_door_run(args: argparse.Namespace) -> int:
    """Front-door boot path: ``tau-x402 run`` with safe defaults.

    Equivalent to ``tau-x402 --policy <default> --mode enforce`` plus
    a banner centered on authorisation + the MCP tool surface. Advanced
    internals (fragment version, prover chain, semantic fragment tier)
    are hidden behind ``--verbose`` and ``tau-x402 inspect`` to keep
    first-run ergonomics about the decision layer, not about formal
    methods.

    On ``--dry-run`` we print the banner + exit 0 without binding the
    socket. Useful for CI smoke tests + the test suite that exercises
    the argparse + startup sequence without a real daemon.
    """
    default_path = _default_policy_path()
    if not default_path.exists():
        sys.stderr.write(
            f"tau-x402 run: default policy missing: {default_path}\n"
            "  reinstall tau-x402-cage or pass --policy explicitly\n"
        )
        return 2

    # Resolve the policy source: user-supplied > default YAML.
    explicit_policy = getattr(args, "policy", None)
    open_allowlist = bool(getattr(args, "open_allowlist", False))
    verbose = bool(getattr(args, "verbose", False))

    invariants_to_load = None
    policy_source = explicit_policy
    if not explicit_policy:
        if open_allowlist:
            try:
                invariants_to_load, source_path = _load_default_policy_without_allowlist(
                    default_path,
                )
            except Exception as exc:  # PolicyLoaderError or filesystem error
                sys.stderr.write(
                    f"tau-x402 run: failed to load default policy "
                    f"({default_path}): {exc}\n"
                )
                return 2
            policy_source = str(source_path) + " (open-allowlist)"
        else:
            policy_source = str(default_path)
            # Let the existing _cmd_run load the YAML; we don't need to
            # pre-parse when the allowlist stays intact.
            args.policy = str(default_path)

    # Default to enforce mode unless the user explicitly overrode --mode
    # or TAU_CAGE_MODE on the environment. Front-door intent is "safe on
    # arrival" which means enforce + deny-by-default.
    if getattr(args, "mode", None) is None and "TAU_CAGE_MODE" not in os.environ:
        args.mode = "enforce"

    # Adaptive tightening — import-guarded. Surfaced as a single line
    # ("active" / "unavailable") at default verbosity; --verbose reveals
    # the underlying module name.
    try:
        from adapter import adaptive_tightening  # type: ignore # noqa: F401
        adaptive_available = True
    except Exception:
        adaptive_available = False

    # Advisory mode — near_thresholds surface landed in v0.21.0 via
    # ``adapter.composition.check_payment_composed`` on the registry.
    try:
        from adapter import composition  # type: ignore # noqa: F401
        advisory_available = True
    except Exception:
        advisory_available = False

    # Default banner: lead with authorisation + MCP tool. No mention of
    # fragments, prover_chain, or semantic_fragment until --verbose.
    socket_path = getattr(args, "socket", DEFAULT_SOCKET) or DEFAULT_SOCKET
    # Operator-facing label for the adaptive-tightening subsystem.
    # "active" / "unavailable" is the human-readable form; the line
    # below keeps the v0.21.0 `enabled` / `stub` vocabulary for
    # back-compat with scripts that grep it.
    runtime_guard_label = "active" if adaptive_available else "unavailable"
    adaptive_status_token = "enabled" if adaptive_available else "stub"
    flexible_mode = args.mode or "enforce"
    # Surface the decision-layer mode in user-facing terms: "guaranteed"
    # when the runtime is in strict Guaranteed Mode, otherwise the
    # default Flexible tier. CAGE_PROVER_MODE=strict is our shorthand.
    guaranteed = os.environ.get("CAGE_PROVER_MODE", "").lower() == "strict"
    mode_label = "guaranteed" if guaranteed else "flexible (default)"
    sys.stderr.write(
        "tau-x402: authorising payment decisions for your agent\n"
        f"  - policy:        {policy_source}\n"
        f"  - mode:          {mode_label}\n"
        f"  - runtime guard: {runtime_guard_label} "
        "(adaptive tightening on)\n"
        f"  - MCP tool:      should_pay_x402 ready at {socket_path}\n"
    )
    # Keep the older banner phrasing as a hint-level line so tests +
    # scripts that grep for the v0.21.0 strings still work. Dropping it
    # would be a silent back-compat break; keeping it doesn't cost the
    # reader anything since it lands after the headline block.
    sys.stderr.write(
        "tau-x402 run: booting front-door profile\n"
        f"tau-x402 run:   policy            = {policy_source}\n"
        f"tau-x402 run:   mode              = {flexible_mode}\n"
        f"tau-x402 run:   open-allowlist    = {open_allowlist}\n"
        f"tau-x402 run:   adaptive-tightening = "
        f"{adaptive_status_token}\n"
    )

    if verbose:
        # Advanced/operator-only details; intentionally hidden at
        # default verbosity so the first-run surface stays decision-
        # focused. ``tau-x402 inspect`` covers the same ground once
        # the daemon is up.
        adaptive_detail = (
            "enabled (adapter.adaptive_tightening available)"
            if adaptive_available
            else "stub (adapter.adaptive_tightening unavailable)"
        )
        advisory_detail = (
            "enabled (near_thresholds via adapter.composition)"
            if advisory_available
            else "unavailable (adapter.composition not importable)"
        )
        sys.stderr.write(
            f"tau-x402 run:   adaptive-tightening (detail) = {adaptive_detail}\n"
            f"tau-x402 run:   advisory-mode                = {advisory_detail}\n"
            "tau-x402 run:   comparison-mode              = on "
            "(see `tau-x402 risk-prevented` + `tau-x402 compare`)\n"
            f"tau-x402 run:   semantic-fragment            = "
            f"{getattr(args, 'semantic_fragment', None) or 'v1 (default)'}\n"
            f"tau-x402 run:   prover-chain                 = "
            f"{getattr(args, 'prover_chain', None) or 'hybrid (default)'}\n"
            f"tau-x402 run:   prover-mode                  = "
            f"{getattr(args, 'prover_mode', None) or 'compat (default)'}\n"
        )
    sys.stderr.flush()

    if getattr(args, "dry_run", False):
        sys.stderr.write("tau-x402 run: --dry-run set; skipping socket bind\n")
        sys.stderr.flush()
        return 0

    # If --open-allowlist was set we pre-parsed the policy to strip the
    # allowlist; bypass the standard args.policy path and declare the
    # filtered invariants directly after the daemon comes up. We do this
    # by clearing args.policy (so _cmd_run skips YAML loading) and
    # stashing the invariants where the run code can see them.
    if invariants_to_load is not None:
        args.policy = None
        args._preloaded_invariants = invariants_to_load  # type: ignore[attr-defined]

    return _cmd_run(args)


def _cmd_run(args: argparse.Namespace) -> int:
    install_signal_handlers()

    prover = prover_from_env()

    try:
        mode, tau_timeout_ms, semantic_fragment, loaded = _resolve_run_config(
            args, dict(os.environ)
        )
    except _CliConfigError as exc:
        sys.stderr.write(f"tau-x402-cage: {exc}\n")
        return 2

    # v0.13.0 cage mode. CLI --mode overrides TAU_CAGE_MODE env var;
    # default is enforce (pre-v0.13 behaviour). parse_mode fails loudly
    # on typos so an operator who thought they were in shadow cannot
    # silently run in enforce.
    raw_cage_mode = (
        getattr(args, "mode", None)
        or os.environ.get("TAU_CAGE_MODE")
    )
    try:
        cage_mode = parse_mode(raw_cage_mode)
    except ValueError as exc:
        sys.stderr.write(f"tau-x402-cage: {exc}\n")
        return 2
    if cage_mode is not CageMode.ENFORCE:
        sys.stderr.write(
            f"tau-x402-cage: cage mode = {cage_mode.value.upper()} — "
            "rejecting intents will be PERMITTED on the wire and tagged "
            "shadow_would_reject=true. Run 'tau-x402-cage shadow-summary' "
            "to read what would have been blocked.\n"
        )
    else:
        sys.stderr.write("tau-x402-cage: cage mode = enforce\n")

    # Signing backend preflight: fail closed at startup if the operator
    # picked ed25519 but the key files aren't readable. Better to crash
    # here than to emit an envelope with no signature at first request.
    signing_algorithm = os.environ.get("TAU_CAGE_SIGNING_ALGORITHM", "hmac-sha256")
    if signing_algorithm not in ("hmac-sha256", "ed25519"):
        sys.stderr.write(
            f"tau-x402-cage: TAU_CAGE_SIGNING_ALGORITHM must be hmac-sha256 or ed25519, "
            f"got {signing_algorithm!r}\n"
        )
        return 2
    if signing_algorithm == "ed25519":
        try:
            from adapter.verdict_signer import Ed25519Signer, KeyMaterialError
        except ImportError as exc:
            sys.stderr.write(f"tau-x402-cage: {exc}\n")
            return 2
        # `strict=True` because we're in production daemon mode; dev
        # experimenters keep the default HMAC path until they run keygen.
        try:
            Ed25519Signer.from_env(strict=True)
        except KeyMaterialError as exc:
            sys.stderr.write(
                f"tau-x402-cage: ed25519 signing requested but key material unavailable: {exc}\n"
                f"  generate a keypair: tau-x402-cage keygen-ed25519 --out <prefix>\n"
                f"  or unset TAU_CAGE_SIGNING_ALGORITHM to fall back to HMAC\n"
            )
            return 2
        sys.stderr.write(
            "tau-x402-cage: signing backend = ed25519 (asymmetric, public-verifiable)\n"
        )
    else:
        sys.stderr.write("tau-x402-cage: signing backend = hmac-sha256 (shared secret)\n")

    # v0.8.0: select the history backend (memory by default, redis when
    # explicitly requested). We construct it here rather than inside
    # CageDaemon so startup errors (e.g. Redis unreachable) surface at
    # the CLI boundary with a readable message instead of mid-daemon.
    history_backend = (
        args.history_backend
        or os.environ.get("TAU_CAGE_HISTORY_BACKEND")
        or "memory"
    )
    redis_url = (
        args.redis_url
        or os.environ.get("TAU_CAGE_HISTORY_REDIS_URL")
    )
    key_prefix = (
        args.history_key_prefix
        or os.environ.get("TAU_CAGE_HISTORY_KEY_PREFIX")
        or "tau-x402-cage:"
    )
    history_cap = (
        args.history_cap
        or int(os.environ.get("TAU_CAGE_HISTORY_CAP", "10000"))
    )
    try:
        history_store = build_history_store(
            backend=history_backend,
            redis_url=redis_url,
            key_prefix=key_prefix,
            cap=history_cap,
        )
    except HistoryStoreError as exc:
        sys.stderr.write(f"tau-x402-cage: history store init failed: {exc}\n")
        return 2
    sys.stderr.write(
        f"tau-x402-cage: history backend = {history_backend}"
        + (f" (url={redis_url})" if history_backend == "redis" else "")
        + f", cap = {history_cap}\n"
    )

    # v0.13.0: merge-failure cooldown (self-referential policy). When
    # TAU_CAGE_MERGE_COOLDOWN_SECONDS is unset or 0, the feature is
    # compiled in but dormant; operators flip it on via env so rollouts
    # don't require a daemon rebuild.
    cooldown_seconds = int(
        os.environ.get("TAU_CAGE_MERGE_COOLDOWN_SECONDS", "0")
    )
    cooldown_sidecar: Path | None = None
    revision_log_path_env = os.environ.get("TAU_CAGE_REVISION_LOG_PATH")
    if revision_log_path_env:
        cooldown_sidecar = (
            Path(revision_log_path_env).with_name("_merge_cooldown.json")
        )
    try:
        merge_cooldown = build_merge_failure_cooldown(
            cooldown_seconds=cooldown_seconds,
            sidecar_path=cooldown_sidecar,
        )
    except MergeFailureCooldownError as exc:
        sys.stderr.write(
            f"tau-x402-cage: merge-failure cooldown init failed: {exc}\n"
        )
        return 2
    if cooldown_seconds > 0:
        sys.stderr.write(
            f"tau-x402-cage: merge cooldown enabled "
            f"(cooldown_seconds={cooldown_seconds}, "
            f"sidecar={cooldown_sidecar})\n"
        )

    # v0.14.0 cross-revision compositional invariants. Env-driven so a
    # rollout doesn't require a daemon rebuild. Fail closed at startup if
    # the env vars are malformed, same pattern as merge-cooldown.
    try:
        from adapter.cross_revision import build_validator_from_env
        cross_revision_validator = build_validator_from_env(dict(os.environ))
    except ValueError as exc:
        sys.stderr.write(
            f"tau-x402-cage: cross-revision validator config invalid: {exc}\n"
        )
        return 2
    if cross_revision_validator is not None:
        sys.stderr.write(
            f"tau-x402-cage: cross-revision validator enabled "
            f"({len(cross_revision_validator)} invariant(s))\n"
        )

    # v0.14.0: policy-over-policy mutation governance. Activation is
    # env-only (TAU_CAGE_GOVERNANCE_YAML); absent => dormant.
    try:
        from adapter.mutation_governance import (
            GovernanceLoadError,
            load_governance_from_env,
        )
        governance_policy = load_governance_from_env(os.environ)
    except GovernanceLoadError as exc:
        sys.stderr.write(
            f"tau-x402-cage: governance policy init failed: {exc}\n"
        )
        return 2
    if governance_policy is not None:
        sys.stderr.write(
            f"tau-x402-cage: governance enabled "
            f"(actors={len(governance_policy.actors)}, "
            f"approval_rules={len(governance_policy.approval_requirements)}, "
            f"strict_required={len(governance_policy.strict_mode_required_for)})\n"
        )

    hybrid_prover = None
    z3_incremental_prover = None
    chain = getattr(args, "prover_chain", None)
    if chain == "hybrid":
        try:
            from adapter.hybrid_prover import HybridProver
            from adapter.prover import IncrementalZ3Prover, TauConsistencyProver
        except ImportError as exc:
            sys.stderr.write(f"tau-x402-cage: --prover-chain=hybrid unavailable: {exc}\n")
            return 2
        z3_incremental_prover = IncrementalZ3Prover(timeout_seconds=tau_timeout_ms / 1000.0)
        hybrid_prover = HybridProver(
            tau_prover=TauConsistencyProver(timeout_seconds=tau_timeout_ms / 1000.0),
            z3_prover=z3_incremental_prover,
            pattern_prover=prover,
        )
    elif chain == "z3":
        try:
            from adapter.prover import IncrementalZ3Prover
        except ImportError as exc:
            sys.stderr.write(f"tau-x402-cage: --prover-chain=z3 unavailable: {exc}\n")
            return 2
        z3_incremental_prover = IncrementalZ3Prover(timeout_seconds=tau_timeout_ms / 1000.0)

    # v0.10.0: load webhook sinks from TAU_CAGE_WEBHOOKS_YAML before we
    # construct the daemon so startup fails closed if the config is bad.
    try:
        webhook_sinks = _load_webhook_sinks_from_env(dict(os.environ), metrics=None)
    except WebhookConfigError as exc:
        sys.stderr.write(f"tau-x402-cage: webhook config invalid: {exc}\n")
        return 2
    if webhook_sinks:
        sys.stderr.write(
            f"tau-x402-cage: {len(webhook_sinks)} webhook sink(s) configured: "
            + ", ".join(s.name for s in webhook_sinks) + "\n"
        )

    # v0.11.0: activate multi-node revision sync when TAU_CAGE_REVISION_SYNC_REDIS_URL
    # is set. Env-only activation (no new CLI flag): the adapter is an
    # HA wiring concern, not a per-invocation knob. Preflight fail-closed
    # matches the v0.8.0 history-store pattern so a misconfigured
    # environment surfaces at the CLI boundary.
    revision_sync = None
    sync_url = os.environ.get("TAU_CAGE_REVISION_SYNC_REDIS_URL")
    if sync_url:
        try:
            from adapter.revision_sync import (
                RevisionSyncError,
                SyncConfig,
                build_revision_sync,
            )
        except ImportError as exc:
            sys.stderr.write(f"tau-x402-cage: revision-sync unavailable: {exc}\n")
            return 2
        sync_channel = (
            os.environ.get("TAU_CAGE_REVISION_SYNC_CHANNEL")
            or "tau-x402-cage:revision-sync"
        )
        sync_client_id = os.environ.get("TAU_CAGE_REVISION_SYNC_CLIENT_ID") or ""
        # The daemon ctor has not run yet, so we can't inject its registry
        # lock. That's fine: the adapter rebinds to the daemon's lock
        # inside __init__ once the daemon owns it.
        # We pass a throwaway log so `build_revision_sync` can construct
        # the subscriber; the daemon swaps the real log in immediately.
        # We avoid doing this by deferring subscriber construction: pass
        # the daemon's eventual log instead. To keep the wiring simple,
        # we build the adapter AFTER the daemon so we can pass the real
        # log. Preflight happens at adapter build time.
        sync_config = SyncConfig(
            url=sync_url,
            channel=sync_channel,
            client_id=sync_client_id,
        )
        # Stash config so we can build the adapter once the daemon's
        # RevisionLog exists.
        sys.stderr.write(
            f"tau-x402-cage: revision-sync enabled (channel={sync_channel}, "
            f"url={sync_url})\n"
        )
    else:
        sync_config = None

    # v0.11.0: build the revision-sync adapter now that we can see the
    # daemon's RevisionLog. Preflight happens here; a Redis outage
    # surfaces as a CLI error before we ever bind the UDS.
    # v0.15.0: pull HMAC secret from env so the daemon can sign decision
    # bundles on demand. Same convention as SaaS / gRPC surfaces
    # (TAU_X402_HMAC_SECRET, 32+ hex chars). Absent => bundles refuse
    # to sign with a clean error at op time.
    hmac_secret_bytes: Optional[bytes] = None
    hmac_secret_hex = os.environ.get("TAU_X402_HMAC_SECRET")
    if hmac_secret_hex:
        try:
            hmac_secret_bytes = bytes.fromhex(hmac_secret_hex.strip())
        except ValueError as exc:
            sys.stderr.write(
                f"tau-x402-cage: HMAC secret must be hex-encoded: {exc}\n"
            )
            return 2
        if len(hmac_secret_bytes) < 16:
            sys.stderr.write(
                "tau-x402-cage: HMAC secret must be >= 16 bytes (32+ hex chars)\n"
            )
            return 2
    if sync_config is not None:
        # Import guarded above; safe to re-import for the factory.
        from adapter.revision_sync import RevisionSyncError, build_revision_sync
        # Construct an interim daemon just to get a log? No -- we build
        # the daemon first WITHOUT the adapter, then attach.
        daemon_without_sync = CageDaemon(
            socket_path=args.socket,
            initial_spec=args.initial_spec,
            prover=prover,
            prover_mode=mode,
            tau_timeout_ms=tau_timeout_ms,
            history_store=history_store,
            z3_incremental_prover=z3_incremental_prover,
            hybrid_prover=hybrid_prover,
            webhook_sinks=webhook_sinks,
            hmac_secret=hmac_secret_bytes,
            merge_cooldown=merge_cooldown,

            cage_mode=cage_mode,
            cross_revision_validator=cross_revision_validator,
            governance_policy=governance_policy,
        )
        try:
            revision_sync = build_revision_sync(
                config=sync_config,
                log=daemon_without_sync._policy_revisions,
                registry_lock=daemon_without_sync._registry_lock,
                preflight=True,
            )
        except RevisionSyncError as exc:
            sys.stderr.write(f"tau-x402-cage: revision-sync init failed: {exc}\n")
            daemon_without_sync.shutdown()
            return 2
        daemon_without_sync._revision_sync = revision_sync
        daemon = daemon_without_sync
    else:
        daemon = CageDaemon(
            socket_path=args.socket,
            initial_spec=args.initial_spec,
            prover=prover,
            prover_mode=mode,
            tau_timeout_ms=tau_timeout_ms,
            history_store=history_store,
            z3_incremental_prover=z3_incremental_prover,
            hybrid_prover=hybrid_prover,
            webhook_sinks=webhook_sinks,
            hmac_secret=hmac_secret_bytes,
            merge_cooldown=merge_cooldown,

            cage_mode=cage_mode,
            cross_revision_validator=cross_revision_validator,
            governance_policy=governance_policy,
        )
    sys.stderr.write(
        f"tau-x402-cage: prover backend = {getattr(prover, 'backend', 'unknown')}, "
        f"mode = {mode}, tau_timeout_ms = {tau_timeout_ms}, "
        f"semantic_fragment = {semantic_fragment}, "
        f"prover_chain = {chain or 'legacy'}\n"
    )

    if loaded is not None:
        for inv in loaded.invariants:
            daemon._x402_registry = daemon._x402_registry.declare(inv)
        sys.stderr.write(
            f"tau-x402-cage: loaded {len(loaded.invariants)} invariants from {loaded.source_path}\n"
        )

    # v0.21.0 front-door: ``tau-x402 run --open-allowlist`` pre-parses
    # the default policy and strips the provider_allowlist rule. The
    # pre-parsed list rides on args so we declare it after the daemon
    # comes up, mirroring the standard ``loaded`` path.
    preloaded = getattr(args, "_preloaded_invariants", None)
    if preloaded:
        for inv in preloaded:
            daemon._x402_registry = daemon._x402_registry.declare(inv)
        sys.stderr.write(
            f"tau-x402-cage: declared {len(preloaded)} invariants from "
            f"front-door default policy (open-allowlist)\n"
        )

    sys.stderr.write(f"tau-x402-cage: serving on {args.socket}\n")
    sys.stderr.flush()
    try:
        daemon.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        daemon.shutdown()
    return 0


_WINDOW_UNITS = {"s": 1, "m": 60, "h": 3600, "d": 86400}


def _parse_window(spec: str) -> int:
    """Parse a window spec like ``"24h"``, ``"3600"``, ``"7d"`` into seconds.

    Raises ``ValueError`` on anything unparseable so the caller can surface
    a clean error. Leading/trailing whitespace is tolerated; ``0`` / ``"0"``
    / ``"all"`` all mean "all history" (returned as 0).
    """
    s = (spec or "").strip().lower()
    if not s or s in ("0", "all"):
        return 0
    if s[-1] in _WINDOW_UNITS:
        value_part = s[:-1]
        unit = _WINDOW_UNITS[s[-1]]
    else:
        value_part = s
        unit = 1
    try:
        value = int(value_part)
    except ValueError as exc:
        raise ValueError(
            f"unrecognised window {spec!r}; expected e.g. 24h, 3600, 7d, 0"
        ) from exc
    if value < 0:
        raise ValueError(f"window must be >= 0, got {value}")
    return value * unit


def _cmd_explain_decision(args: argparse.Namespace) -> int:
    """Fetch a plain-English explanation of a prior verdict from the daemon.

    The positional argument is either an ``intent_hash`` (64 hex chars)
    or a ``bundle_id`` (UUID). The daemon looks it up in its verdict
    ring buffer and returns a :class:`DecisionExplanation` dict. On
    success exit 0 and render either the narrative or the JSON; exit
    1 on daemon error, 2 on transport error.
    """
    lookup = args.lookup
    payload: dict[str, Any] = {"op": "explain_decision"}
    if getattr(args, "bundle_id", False):
        payload["bundle_id"] = lookup
    elif getattr(args, "intent_hash", False):
        payload["intent_hash"] = lookup
    elif len(lookup) == 64 and all(c in "0123456789abcdef" for c in lookup.lower()):
        payload["intent_hash"] = lookup
    else:
        payload["bundle_id"] = lookup
    try:
        resp = _send_op(args.socket, payload, timeout=5.0)
    except (OSError, RuntimeError, json.JSONDecodeError) as exc:
        sys.stderr.write(
            f"tau-x402-cage explain-decision: failed to reach daemon at "
            f"{args.socket}: {exc}\n"
        )
        return 2
    if resp.get("verdict") != "ok":
        category = resp.get("category", "error")
        reason = resp.get("reason", "(no reason)")
        sys.stderr.write(
            f"tau-x402-cage explain-decision: {category}: {reason}\n"
        )
        return 1
    explanation = resp.get("explanation") or {}
    fmt = getattr(args, "fmt", "text")
    if fmt == "json":
        sys.stdout.write(json.dumps(explanation) + "\n")
    else:
        _render_explanation(resp, explanation, sys.stdout)
    sys.stdout.flush()
    return 0


def _render_explanation(
    resp: dict[str, Any], explanation: dict[str, Any], out
) -> None:
    """Pretty-print a DecisionExplanation. One fact per line, grep-friendly."""
    out.write("Decision explanation\n")
    bundle_id = resp.get("bundle_id")
    intent_hash = resp.get("intent_hash")
    if bundle_id:
        out.write(f"  bundle_id:       {bundle_id}\n")
    if intent_hash:
        out.write(f"  intent_hash:     {intent_hash}\n")
    out.write(f"  outcome:         {explanation.get('outcome', '-') or '-'}\n")
    out.write(f"  rule_id:         {explanation.get('rule_id') or '-'}\n")
    out.write(
        f"  invariant_class: {explanation.get('invariant_class') or '-'}\n"
    )
    retry_after = explanation.get("retry_after_seconds")
    if retry_after is not None:
        out.write(f"  retry_after:     {retry_after}s\n")
    out.write(f"\n  {explanation.get('summary', '')}\n\n")
    narrative = explanation.get("narrative")
    if narrative:
        out.write(f"  {narrative}\n\n")
    remedy = explanation.get("what_would_allow")
    if remedy:
        out.write(f"  What would allow this: {remedy}\n")


def _cmd_compare(args: argparse.Namespace) -> int:
    """Run compare_verdict against the running daemon for one intent.

    Reads the intent JSON from ``--intent``, sends the
    ``safety_comparison`` op, and renders the report. Exit codes match
    the rest of the CLI: 0 success, 1 daemon said no, 2 transport/bad-args.
    """
    path = Path(args.intent)
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        sys.stderr.write(f"tau-x402-cage compare: intent file not found: {path}\n")
        return 2
    except (OSError, json.JSONDecodeError) as exc:
        sys.stderr.write(f"tau-x402-cage compare: could not read intent: {exc}\n")
        return 2
    if not isinstance(payload, dict):
        sys.stderr.write(
            f"tau-x402-cage compare: intent JSON must be an object; got {type(payload).__name__}\n"
        )
        return 2
    try:
        resp = _send_op(args.socket, {"op": "safety_comparison", "intent": payload})
    except (OSError, RuntimeError, json.JSONDecodeError) as exc:
        sys.stderr.write(
            f"tau-x402-cage compare: failed to reach daemon at {args.socket}: {exc}\n"
        )
        return 2
    if resp.get("verdict") != "ok":
        category = resp.get("category", "error")
        reason = resp.get("reason", "(no reason)")
        sys.stderr.write(f"tau-x402-cage compare: {category}: {reason}\n")
        return 1
    report = resp.get("report") or {}
    fmt = getattr(args, "fmt", "text")
    if fmt == "json":
        sys.stdout.write(json.dumps(report) + "\n")
    else:
        _render_comparison(report, sys.stdout)
    sys.stdout.flush()
    return 0


def _render_comparison(report: dict[str, Any], out) -> None:
    """Pretty-print a ComparisonReport. One fact per line, grep-friendly.

    v0.23.0: when ``tightening_effect`` is present in the report, render
    a baseline-vs-tightened-vs-rationale table alongside the existing
    with-system / without-system view. The block is opt-in on the wire
    so pre-v0.23 daemons + reports render unchanged.
    """
    out.write("Safety comparison\n")
    out.write(f"  with_system:     {report.get('with_system')}\n")
    out.write(f"  without_system:  {report.get('without_system')}\n")
    risk_amount = report.get("risk_amount")
    risk_currency = report.get("risk_currency")
    if risk_amount is not None:
        ccy = f" {risk_currency}" if risk_currency else ""
        out.write(f"  risk_prevented:  {risk_amount}{ccy}\n")
    else:
        out.write("  risk_prevented:  (none)\n")
    out.write(f"  rule_id:         {report.get('rule_id') or '-'}\n")
    out.write(f"  invariant_class: {report.get('invariant_class') or '-'}\n")
    reason = report.get("risk_reason")
    if reason:
        out.write(f"  reason:          {reason}\n")
    effect = report.get("tightening_effect")
    if isinstance(effect, dict) and effect.get("tightened"):
        _render_tightening_effect(effect, out)


def _render_tightening_effect(effect: dict[str, Any], out) -> None:
    """Render the v0.23.0 baseline / tightened / why columns.

    Layout:

                     baseline        tightened       why
        max_requests       10               3        retry density > 10/min
        cooldown_s          6              45        identical requests x 4
        per_tx_cap     $1000             $700        velocity 3x ema

    Stays within 72 columns so standard terminal tailing works. Falls
    back to a compact one-line-per-key layout when a column width would
    blow out the line.
    """
    baseline = effect.get("baseline") or {}
    tightened = effect.get("tightened") or {}
    rationale = effect.get("rationale") or {}
    if not tightened:
        return
    keys = [k for k in tightened.keys() if tightened.get(k) != baseline.get(k)]
    if not keys:
        return
    # Compute column widths, honouring the brief's 16-char first column.
    name_w = max(16, max(len(str(k)) for k in keys))
    base_w = max(8, max(len(str(baseline.get(k, "-"))) for k in keys))
    tight_w = max(8, max(len(str(tightened.get(k, "-"))) for k in keys))
    out.write("\n  tightening_effect (adaptive clamp active):\n")
    header = (
        f"    {'':<{name_w}}  "
        f"{'baseline':>{base_w}}  "
        f"{'tightened':>{tight_w}}  "
        f"why\n"
    )
    out.write(header)
    for key in keys:
        base_val = baseline.get(key, "-")
        tight_val = tightened.get(key, "-")
        why = rationale.get(key, "")
        out.write(
            f"    {str(key):<{name_w}}  "
            f"{str(base_val):>{base_w}}  "
            f"{str(tight_val):>{tight_w}}  "
            f"{why}\n"
        )


def _cmd_risk_prevented(args: argparse.Namespace) -> int:
    """Aggregate view of risk prevented over a rolling window."""
    try:
        window_seconds = _parse_window(args.window)
    except ValueError as exc:
        sys.stderr.write(f"tau-x402-cage risk-prevented: {exc}\n")
        return 2
    try:
        resp = _send_op(
            args.socket,
            {
                "op": "risk_aggregate",
                "window_seconds": window_seconds,
                "top_n": int(args.top_n),
            },
        )
    except (OSError, RuntimeError, json.JSONDecodeError) as exc:
        sys.stderr.write(
            f"tau-x402-cage risk-prevented: failed to reach daemon at {args.socket}: {exc}\n"
        )
        return 2
    if resp.get("verdict") != "ok":
        category = resp.get("category", "error")
        reason = resp.get("reason", "(no reason)")
        sys.stderr.write(f"tau-x402-cage risk-prevented: {category}: {reason}\n")
        return 1
    agg = resp.get("aggregate") or {}
    fmt = getattr(args, "fmt", "text")
    if fmt == "json":
        sys.stdout.write(json.dumps(agg) + "\n")
    else:
        _render_risk_aggregate(agg, sys.stdout)
    sys.stdout.flush()
    return 0


def _render_risk_aggregate(agg: dict[str, Any], out) -> None:
    """Render a RiskAggregate dict in a human-scan-friendly form."""
    window = agg.get("window_seconds", 0)
    window_label = "all history" if not window else f"last {window}s"
    out.write(f"Risk prevented — window: {window_label}\n")
    out.write(f"  prevented_count: {agg.get('prevented_count', 0)}\n")
    values = agg.get("prevented_value_by_currency") or {}
    if values:
        out.write("  prevented_value_by_currency:\n")
        for ccy, amt in sorted(values.items()):
            out.write(f"    {ccy}: {amt}\n")
    else:
        out.write("  prevented_value_by_currency: (none)\n")
    providers = agg.get("top_providers") or []
    if providers:
        out.write("  top_providers:\n")
        for p in providers:
            out.write(
                f"    - {p.get('provider')}: count={p.get('count')}, "
                f"value={p.get('value_by_currency') or {}}\n"
            )
    rules = agg.get("top_rules") or []
    if rules:
        out.write("  top_rules:\n")
        for r in rules:
            out.write(
                f"    - {r.get('rule_id')}: count={r.get('count')}, "
                f"value={r.get('value_by_currency') or {}}\n"
            )


def _build_parser() -> argparse.ArgumentParser:
    """Build the top-level argparse parser. Factored out so tests can reach it."""
    parser = argparse.ArgumentParser(prog="tau-x402-cage")
    subparsers = parser.add_subparsers(dest="subcommand")

    # Run (default when no subcommand given)
    parser.add_argument("--socket", default="/tmp/tau-x402-cage.sock",
                        help="UDS path the daemon listens on")
    parser.add_argument("--policy", default=None,
                        help="Path to a YAML policy file declaring initial invariants")
    parser.add_argument("--prover-mode", default=None,
                        choices=["compat", "verified", "strict", "flexible", "guaranteed"],
                        help="Admission policy: "
                             "compat|verified|strict|flexible|guaranteed. "
                             "'flexible' is an alias for 'compat'; 'guaranteed' "
                             "routes every admission through GuaranteedProver "
                             "(pure Tau, totality-gated, no fallbacks). "
                             "Overrides policy.yaml cage: block and CAGE_PROVER_MODE env. "
                             "Default: compat.")
    parser.add_argument("--tau-timeout-ms", default=None, type=int,
                        help="Hard wall-clock cap per Tau proof, in milliseconds. "
                             "Overrides policy.yaml cage: block and CAGE_TAU_TIMEOUT_MS env. "
                             "Default: 10000 (10s).")
    parser.add_argument("--semantic-fragment", default=None,
                        help="Tau semantic fragment version (only 'v1' is supported in "
                             "this release). Overrides policy.yaml cage: block and "
                             "CAGE_SEMANTIC_FRAGMENT env. Default: v1.")
    parser.add_argument("--initial-spec", default="u[t] = i[t].",
                        help=argparse.SUPPRESS)
    parser.add_argument("--history-backend", default=None,
                        choices=["memory", "redis"],
                        help="History store backend. 'memory' (default) is "
                             "process-local; 'redis' is durable + shareable "
                             "across replicas. Overrides TAU_CAGE_HISTORY_BACKEND env.")
    parser.add_argument("--redis-url", default=None,
                        help="Redis URL for --history-backend=redis "
                             "(e.g. redis://localhost:6379/0). "
                             "Overrides TAU_CAGE_HISTORY_REDIS_URL env.")
    parser.add_argument("--history-key-prefix", default=None,
                        help="Key namespace prefix for Redis history store. "
                             "Default: tau-x402-cage:")
    parser.add_argument("--history-cap", default=None, type=int,
                        help="Ring buffer cap (per stream). Default: 10000.")
    parser.add_argument("--prover-chain", default=None,
                        choices=["pattern", "tau", "z3", "hybrid"],
                        help="Which prover chain to run per admission. "
                             "'pattern' | 'tau' | 'z3' preserve the legacy paths; "
                             "'hybrid' routes the delta through HybridProver to "
                             "compose v1 + v2 + cross-fragment projection in one call. "
                             "Default: None (legacy behaviour).")
    parser.add_argument("--mode", default=None,
                        choices=[m.value for m in CageMode],
                        help="Daemon cage mode: enforce|shadow|advisory. "
                             "'enforce' is the default — rejecting intents "
                             "return 403 / reject envelope. 'shadow' short-"
                             "circuits rejects to signed permits tagged with "
                             "shadow_would_reject=true, so operators can run "
                             "the cage in production without blocking traffic. "
                             "'advisory' is identical on the wire to shadow "
                             "but emits a separate Prometheus counter, for "
                             "running advisory rules alongside enforce. "
                             "Overrides TAU_CAGE_MODE env.")

    # init
    init_p = subparsers.add_parser(
        "init",
        help="Create an editable starter policy (plus docker-compose).",
        description=(
            "Create an editable starter policy.yaml and docker-compose "
            "scaffold. Use this when you want to hand-author a policy "
            "from scratch; for a first-run bootstrap with a fresh HMAC "
            "secret, use `tau-x402 quickstart` instead."
        ),
    )
    init_p.add_argument("--policy-path", default="policy.yaml")
    init_p.add_argument("--compose-path", default="docker-compose.yaml")
    init_p.add_argument("--force", action="store_true",
                        help="overwrite existing files")

    # quickstart (v0.17.0) — one-command scaffold for end-to-end bring-up.
    # Distinguished from `init` by: fresh HMAC secret, shadow-mode-by-default
    # compose, MCP config snippet for Claude Desktop, safer default caps.
    quickstart_p = subparsers.add_parser(
        "quickstart",
        help="Scaffold policy.yaml + .env for a first-run setup "
             "(adds docker-compose and a Claude Desktop MCP snippet).",
        description=(
            "Scaffold policy.yaml + .env for a first-run setup. Writes "
            "a safe-defaults policy, a fresh HMAC secret, a shadow-mode "
            "docker-compose, and a Claude Desktop MCP config snippet "
            "into the target directory."
        ),
    )
    quickstart_p.add_argument(
        "--dir", default="~/.tau-x402-cage",
        help="Target directory for the scaffold. Created if missing. "
             "Default: ~/.tau-x402-cage",
    )
    quickstart_p.add_argument(
        "--mcp-config-out", default=None,
        help="Optional path to write the Claude Desktop MCP config JSON. "
             "Relative paths resolve against --dir. Default: print to stdout "
             "only (do not write).",
    )
    quickstart_p.add_argument(
        "--force", action="store_true",
        help="Overwrite existing policy.yaml / .env / docker-compose.yaml / "
             "MCP config in the target directory. Off by default because the "
             ".env file holds an HMAC secret.",
    )

    # lint (v0.10.0) — offline pre-declare policy linter.
    lint_p = subparsers.add_parser(
        "lint",
        help="Check a policy file for contradictions before declaring "
             "(offline; no daemon required).",
        description=(
            "Check a policy file for contradictions before declaring "
            "it to a running cage. Runs the offline pre-declare "
            "consistency check on the YAML; no daemon required."
        ),
    )
    lint_p.add_argument(
        "policy_path",
        help="Path to a policy.yaml file to lint.",
    )
    lint_p.add_argument(
        "--format", dest="fmt", default="text",
        choices=["text", "json"],
        help="Output format. 'text' is human-readable; 'json' emits a "
             "schema-stable structured report suitable for CI pipelines. "
             "Default: text.",
    )
    lint_p.add_argument(
        "--strict", action="store_true",
        help="Treat warnings as errors (exit 1 when any warning is "
             "emitted, even if no errors were found).",
    )

    # suggest
    suggest_p = subparsers.add_parser(
        "suggest",
        help="authoring loop: English -> LLM prompt -> YAML -> lint -> English",
        description=(
            "Three modes on one subcommand:\n"
            "  1. default (positional `request`) emits an LLM prompt to "
            "translate English into policy.yaml.\n"
            "  2. --from-nl <description> is the same prompt with the "
            "description supplied via flag (friendlier for long phrases).\n"
            "  3. --round-trip reads YAML on stdin, runs the linter, and "
            "narrates the lint-clean policy back as English."
        ),
    )
    suggest_p.add_argument("request", nargs="*",
                           help="plain-English policy description")
    suggest_p.add_argument(
        "--from-nl", dest="from_nl", default=None,
        help="Plain-English policy description (alternative to positional "
             "`request`; wins when both are given).",
    )
    suggest_p.add_argument(
        "--round-trip", dest="round_trip", action="store_true",
        help="Read YAML on stdin, lint it, narrate the lint-clean policy "
             "back in plain English. Exit 1 if the linter reports errors.",
    )

    # narrate (v0.18.0) — standalone plain-English description of a policy.yaml.
    narrate_p = subparsers.add_parser(
        "narrate",
        help="print a plain-English description of a policy.yaml (v0.18.0)",
    )
    narrate_p.add_argument(
        "policy_path",
        help="Path to a policy.yaml file to narrate.",
    )
    narrate_p.add_argument(
        "--format", dest="fmt", default="plain",
        choices=["plain", "markdown", "json"],
        help="Output format. 'plain' (default) = newline-separated sentences; "
             "'markdown' = bulleted list; 'json' = structured sentences.",
    )

    # inspect
    inspect_p = subparsers.add_parser(
        "inspect",
        help="Inspect the active policy and prover mode on the live daemon.",
        description=(
            "Inspect the active policy and prover mode on the live "
            "daemon. Prints a snapshot of the admitted rules and the "
            "current revision identifier."
        ),
    )
    inspect_p.add_argument("--socket", default=DEFAULT_SOCKET,
                           help="UDS path the daemon listens on")

    # explain
    explain_p = subparsers.add_parser(
        "explain",
        help="Explain why the active or a candidate policy admits or "
             "rejects (contradiction detection at declare time).",
        description=(
            "Explain why the active or a candidate policy is admitted "
            "or rejected. Runs the declare-time consistency check "
            "against the live daemon and reports the outcome with "
            "the conflicting rule pair when a contradiction is found."
        ),
    )
    explain_p.add_argument("--socket", default=DEFAULT_SOCKET,
                           help="UDS path the daemon listens on")
    explain_p.add_argument("--policy", default=None,
                           help="Path to a YAML policy; run candidate mode "
                                "against these invariants instead of the "
                                "active registry.")

    # diff (v0.11.0) — pretty-print a revision-pair delta.
    diff_p = subparsers.add_parser(
        "diff",
        help="pretty-print the delta between two revisions (v0.11.0)",
    )
    diff_p.add_argument("revision_a", help="first revision id (the 'before' side)")
    diff_p.add_argument("revision_b", help="second revision id (the 'after' side)")
    diff_p.add_argument(
        "--format", dest="fmt", default="text",
        choices=["text", "json"],
        help="Output format. 'text' (default) renders a side-by-side table "
             "via adapter.diff_renderer; 'json' emits the raw daemon response.",
    )
    diff_p.add_argument("--socket", default=DEFAULT_SOCKET,
                        help="UDS path the daemon listens on")

    # keygen-ed25519
    keygen_p = subparsers.add_parser(
        "keygen-ed25519",
        help="generate an Ed25519 keypair for asymmetric verdict signing",
    )
    keygen_p.add_argument(
        "--out", required=True,
        help="Output prefix; writes <prefix>.pem (private, 0600) and "
             "<prefix>.pub (public, 0644). Refuses to overwrite.",
    )

    # audit-export (v0.9.0)
    audit_export_p = subparsers.add_parser(
        "audit-export",
        help="Export a signed audit bundle (revisions + branches + proposals).",
        description=(
            "Export a signed audit bundle containing revisions, "
            "branches, and proposals. The bundle is offline-verifiable "
            "and designed for hand-off to compliance reviewers."
        ),
    )
    audit_export_p.add_argument(
        "--socket", default=DEFAULT_SOCKET,
        help="UDS path the daemon listens on",
    )
    audit_export_p.add_argument(
        "--out", required=True,
        help="Output path for the signed JSONL bundle (two lines: bundle + signature)",
    )
    audit_export_p.add_argument(
        "--private-key", required=True,
        help="Path to PEM-encoded Ed25519 private key used to sign the bundle",
    )

    # audit-verify (v0.9.0)
    audit_verify_p = subparsers.add_parser(
        "audit-verify",
        help="offline-verify a signed audit bundle; exits 0 if valid, 1 otherwise",
    )
    audit_verify_p.add_argument("path", help="Path to the signed JSONL bundle")
    audit_verify_p.add_argument(
        "--public-key", required=True,
        help="Path to PEM-encoded Ed25519 public key used to verify",
    )

    # bundle (v0.15.0) -- per-verdict decision bundle
    bundle_p = subparsers.add_parser(
        "bundle",
        help="fetch a signed decision bundle for a single verdict (v0.15.0)",
    )
    bundle_p.add_argument(
        "lookup",
        help="Either the intent_hash (64-char hex) or the bundle_id (UUID). "
             "Disambiguate with --bundle-id / --intent-hash when needed.",
    )
    bundle_p.add_argument(
        "--out", required=True,
        help="Output path for the signed JSONL bundle",
    )
    bundle_p.add_argument(
        "--bundle-id", dest="bundle_id", action="store_true",
        help="Force the positional argument to be interpreted as a bundle_id",
    )
    bundle_p.add_argument(
        "--intent-hash", dest="intent_hash", action="store_true",
        help="Force the positional argument to be interpreted as an intent_hash",
    )
    bundle_p.add_argument(
        "--chain-limit", dest="chain_limit", type=int, default=None,
        help="Cap the revision chain length in the bundle (default 50)",
    )
    bundle_p.add_argument(
        "--socket", default=DEFAULT_SOCKET,
        help=f"Path to the daemon UDS (default: {DEFAULT_SOCKET})",
    )

    # bundle-verify (v0.15.0) -- offline-verify a decision bundle
    bundle_verify_p = subparsers.add_parser(
        "bundle-verify",
        help="offline-verify a signed decision bundle; exits 0 valid / 1 invalid / 2 transport",
    )
    bundle_verify_p.add_argument("path", help="Path to the signed JSONL bundle")
    bundle_verify_p.add_argument(
        "--public-key", default=None,
        help="Path to PEM-encoded Ed25519 public key (for ed25519 envelopes)",
    )
    bundle_verify_p.add_argument(
        "--secret", default=None,
        help="Hex-encoded HMAC secret (for hmac-sha256 envelopes)",
    )

    # branch (v0.7.0) -- manage branching revision graphs.
    branch_p = subparsers.add_parser(
        "branch",
        help="manage branching revision graphs (list | create | checkout | merge)",
    )
    branch_sub = branch_p.add_subparsers(dest="branch_action")

    b_list = branch_sub.add_parser("list", help="list all branches")
    b_list.add_argument("--socket", default=DEFAULT_SOCKET,
                        help="UDS path the daemon listens on")

    b_create = branch_sub.add_parser(
        "create", help="open a new branch off an existing revision",
    )
    b_create.add_argument("name", help="branch name")
    b_create.add_argument("--from", dest="from_revision", default=None,
                          help="revision_id to branch from "
                               "(default: current head of active branch)")
    b_create.add_argument("--created-by", default="",
                          help="operator/service id recorded on the branch")
    b_create.add_argument("--socket", default=DEFAULT_SOCKET,
                          help="UDS path the daemon listens on")

    b_check = branch_sub.add_parser("checkout", help="activate a branch")
    b_check.add_argument("name", help="branch name to activate")
    b_check.add_argument("--socket", default=DEFAULT_SOCKET,
                         help="UDS path the daemon listens on")

    b_merge = branch_sub.add_parser(
        "merge", help="fast-forward or three-way merge SRC into DST",
    )
    b_merge.add_argument("src", help="source branch name")
    b_merge.add_argument("--into", dest="into", required=True,
                         help="destination branch name")
    b_merge.add_argument("--reviewer", required=True,
                         help="reviewer id recorded on the merge event")
    b_merge.add_argument("--socket", default=DEFAULT_SOCKET,
                         help="UDS path the daemon listens on")
    b_merge.add_argument("--json", action="store_true",
                         help="emit raw JSON response on stdout instead of "
                              "rendering natural-language conflict text "
                              "(v0.11.0)")
    # propose (v0.7.0 agent-proposes / human-approves queue)
    propose_p = subparsers.add_parser(
        "propose",
        help="submit a policy YAML as a pending proposal for human review",
    )
    propose_p.add_argument("--socket", default=DEFAULT_SOCKET,
                           help="UDS path the daemon listens on")
    propose_p.add_argument("--from", dest="policy", required=True,
                           help="Path to a YAML policy whose invariants form the proposal")
    propose_p.add_argument("--submitted-by", required=True,
                           help="Agent identifier for audit trail")

    # proposals
    proposals_p = subparsers.add_parser(
        "proposals",
        help="list queued policy proposals",
    )
    proposals_p.add_argument("--socket", default=DEFAULT_SOCKET,
                             help="UDS path the daemon listens on")
    proposals_p.add_argument("--status", default=None,
                             choices=["pending", "approved", "rejected"],
                             help="Filter by status (default: all)")

    # approve
    approve_p = subparsers.add_parser(
        "approve",
        help="approve a pending policy proposal by id",
    )
    approve_p.add_argument("--socket", default=DEFAULT_SOCKET,
                           help="UDS path the daemon listens on")
    approve_p.add_argument("proposal_id", help="The proposal to approve")
    approve_p.add_argument("--reviewer", required=True,
                           help="Human reviewer identifier")
    approve_p.add_argument("--reason", default=None,
                           help="Optional free-form approval note")
    approve_p.add_argument("--allow-same-as-submitter", action="store_true",
                           help="Bypass the two-person integrity guard")

    # reject
    reject_p = subparsers.add_parser(
        "reject",
        help="reject a pending policy proposal by id",
    )
    reject_p.add_argument("--socket", default=DEFAULT_SOCKET,
                          help="UDS path the daemon listens on")
    reject_p.add_argument("proposal_id", help="The proposal to reject")
    reject_p.add_argument("--reviewer", required=True,
                          help="Human reviewer identifier")
    reject_p.add_argument("--reason", required=True,
                          help="Free-form rejection reason (required)")
    reject_p.add_argument("--allow-same-as-submitter", action="store_true",
                          help="Bypass the two-person integrity guard")

    # governance (v0.14.0) — policy-over-policy inspection + dry-run.
    gov_p = subparsers.add_parser(
        "governance",
        help="inspect mutation-governance policy and dry-run propose "
             "decisions (v0.14.0)",
    )
    gov_sub = gov_p.add_subparsers(dest="governance_action")

    gov_status = gov_sub.add_parser(
        "status",
        help="print the currently loaded governance policy summary",
    )
    gov_status.add_argument(
        "--path", default=None,
        help="Path to a governance YAML (default: TAU_CAGE_GOVERNANCE_YAML env)",
    )
    gov_status.add_argument(
        "--format", dest="fmt", default="text",
        choices=["text", "json"],
        help="Output format (default: text).",
    )

    gov_check = gov_sub.add_parser(
        "check",
        help="dry-run a propose decision for an actor + invariant pair",
    )
    gov_check.add_argument(
        "--actor", required=True,
        help="Governance actor id (mutation_actors.id from the YAML)",
    )
    gov_check.add_argument(
        "--invariant", required=True,
        help="Path to a policy YAML containing the invariant to check. "
             "Only the first invariant in the file is evaluated.",
    )
    gov_check.add_argument(
        "--path", default=None,
        help="Path to a governance YAML (default: TAU_CAGE_GOVERNANCE_YAML env)",
    )
    gov_check.add_argument(
        "--prover-mode", default=None,
        choices=["compat", "verified", "strict"],
        help="Simulate the daemon running in this prover mode. "
             "Default: CAGE_PROVER_MODE env, falling back to 'compat'.",
    )
    gov_check.add_argument(
        "--format", dest="fmt", default="text",
        choices=["text", "json"],
        help="Output format (default: text).",
    )

    # prover-metrics (v0.7.0)
    metrics_p = subparsers.add_parser(
        "prover-metrics",
        help="show prover push/pop counters from a running daemon",
    )
    metrics_p.add_argument("--socket", default=DEFAULT_SOCKET,
                           help="UDS path the daemon listens on")

    # shadow-summary (v0.13.0) — report on would-have-rejected intents.
    shadow_p = subparsers.add_parser(
        "shadow-summary",
        help="summarise shadow/advisory-mode would-have-rejected intents "
             "from a running daemon (v0.13.0)",
    )
    shadow_p.add_argument("--socket", default=DEFAULT_SOCKET,
                          help="UDS path the daemon listens on")
    shadow_p.add_argument(
        "--window", default=None,
        help="Only aggregate shadow rejects within this time window "
             "relative to the newest entry (e.g. 24h, 7d, 3600s). "
             "Default: aggregate the full ring buffer.",
    )
    shadow_p.add_argument(
        "--format", dest="fmt", default="text",
        choices=["text", "json"],
        help="Output format. 'text' is human-readable; 'json' emits the "
             "raw daemon response for scripting. Default: text.",
    )

    # replay (v0.10.0) — policy replay / backtest against history.
    replay_p = subparsers.add_parser(
        "replay",
        help="re-admit recent payments against a candidate policy (v0.10.0)",
    )
    replay_p.add_argument("--socket", default=DEFAULT_SOCKET,
                          help="UDS path the daemon listens on")
    replay_p.add_argument("--candidate", required=True,
                          help="Path to a YAML policy whose invariants form "
                               "the candidate set to backtest")
    replay_p.add_argument("--window", default=None, type=int,
                          help="Only replay intents within this many seconds "
                               "of the newest history entry (default: all)")
    replay_p.add_argument("--limit", default=None, type=int,
                          help="Hard cap on entries replayed (newest-N). "
                               "Default 10000; larger values are clamped.")

    # bench (v0.10.0) — TTI conformance battery runner.
    bench_p = subparsers.add_parser(
        "bench",
        help="run the 5-test TTI conformance battery and report pass/fail",
    )
    bench_p.add_argument(
        "--specs", default=None,
        help="Path to a directory containing the 5 YAML specs "
             "(default: the shipped specs/tti_battery/).",
    )
    bench_p.add_argument(
        "--against", default=None,
        help="Run against a remote SaaS URL (uses the v0.9.0 client SDK). "
             "Default: local mode, no network.",
    )
    bench_p.add_argument(
        "--bearer-token", default=None,
        help="Bearer token for --against authentication.",
    )
    bench_p.add_argument(
        "--json", action="store_true",
        help="Emit the full TTIResult as machine-parseable JSON.",
    )
    bench_p.add_argument(
        "--per-test-budget-seconds", default=None, type=float,
        help="Wall-clock budget per test (default: 60s). A test that "
             "exceeds is reported decisive=false.",
    )
    bench_p.add_argument(
        "--check", action="store_true",
        help="Regression-gate mode; combine with --max-seconds.",
    )
    bench_p.add_argument(
        "--max-seconds", default=None, type=float,
        help="Hard ceiling on total_seconds when --check is set. "
             "Exceeding this exits non-zero even if every test is decisive.",
    )

    # metrics (v0.9.0) — Prometheus counter dump, text or json.
    prom_p = subparsers.add_parser(
        "metrics",
        help="dump Prometheus counters (text or json)",
    )
    prom_p.add_argument(
        "--format", dest="fmt", default="text",
        choices=["text", "json"],
        help="Output format. 'text' is the Prometheus exposition format; "
             "'json' is a compact snapshot of every counter + gauge.",
    )

    # self-ref (v0.13.0) -- inspect self-referential policy state.
    self_ref_p = subparsers.add_parser(
        "self-ref",
        help="inspect self-referential policy state "
             "(instability guards, merge-failure cooldown) (v0.13.0)",
    )
    self_ref_sub = self_ref_p.add_subparsers(dest="self_ref_action")
    sr_status = self_ref_sub.add_parser(
        "status",
        help="show active instability guards + merge cooldown status",
    )
    sr_status.add_argument("--socket", default=DEFAULT_SOCKET,
                           help="UDS path the daemon listens on")
    sr_status.add_argument(
        "--format", dest="fmt", default="text",
        choices=["text", "json"],
        help="Output format (default: text).",
    )

    # mutation-risk (v0.13.0) — offline dry-run for the strict mutation contract.
    mr_p = subparsers.add_parser(
        "mutation-risk",
        help="offline dry-run; report mutation_risk / affected_scope / "
             "would_break_without_proof for a candidate policy vs the "
             "active registry, without mutating anything",
    )
    mr_p.add_argument(
        "--candidate", required=True,
        help="Path to a YAML policy whose invariants form the candidate "
             "delta. The delta is derived by diffing candidate against "
             "the daemon's active registry.",
    )
    mr_p.add_argument("--socket", default=DEFAULT_SOCKET,
                      help="UDS path the daemon listens on")
    mr_p.add_argument(
        "--format", dest="fmt", default="text",
        choices=["text", "json"],
        help="Output format. 'text' is human-readable; 'json' emits a "
             "stable dict for CI pipelines. Default: text.",
    )

    # webhook-test (v0.10.0) — one-shot synthetic verdict for integration setup.
    wh_p = subparsers.add_parser(
        "webhook-test",
        help="send a synthetic verdict to a webhook endpoint and print the signature",
    )
    wh_p.add_argument("--url", required=True, help="Target webhook URL (http(s)://...)")
    wh_p.add_argument(
        "--secret", required=True,
        help="Shared HMAC secret. Either raw utf-8 text (>=16 bytes) or hex-encoded.",
    )
    wh_p.add_argument(
        "--verdict", default="reject", choices=["permit", "reject"],
        help="Verdict type for the synthetic payload (default: reject)",
    )
    wh_p.add_argument(
        "--rule-id", default="spending_cap_per_tx",
        help="rule_id field on the synthetic verdict (default: spending_cap_per_tx)",
    )
    wh_p.add_argument(
        "--timeout-s", type=float, default=3.0,
        help="Per-request HTTP timeout (default: 3.0)",
    )
    wh_p.add_argument(
        "--dry-run", action="store_true",
        help="Print the canonical body + headers but do not POST",
    )

    # v0.17.0: per-decision explainer.
    explain_dec_p = subparsers.add_parser(
        "explain-decision",
        help="Explain why a payment was allowed or denied "
             "(decision + rule + what would change the answer).",
        description=(
            "Explain why a payment was allowed or denied. Given an "
            "intent hash or bundle id, returns the decision, the rule "
            "that fired, and what would change the answer next time."
        ),
    )
    explain_dec_p.add_argument(
        "lookup",
        help=(
            "Intent hash (64-char hex) or bundle_id (UUID) of the verdict. "
            "Ambiguous inputs default to bundle_id; force via --bundle-id / "
            "--intent-hash."
        ),
    )
    # Mutually-exclusive force flags so callers can override the auto-guess.
    explain_dec_p.add_argument(
        "--bundle-id", dest="bundle_id", action="store_true",
        help="Treat the positional argument as a bundle_id (UUID).",
    )
    explain_dec_p.add_argument(
        "--intent-hash", dest="intent_hash", action="store_true",
        help="Treat the positional argument as an intent_hash (hex).",
    )
    explain_dec_p.add_argument(
        "--format", dest="fmt", default="text",
        choices=["text", "json"],
        help="Output format (default: text).",
    )
    explain_dec_p.add_argument(
        "--socket", default=DEFAULT_SOCKET,
        help=f"Path to the daemon UDS (default: {DEFAULT_SOCKET})",
    )

    # v0.13.0: safety-comparison subcommands.
    compare_p = subparsers.add_parser(
        "compare",
        help="Show prevented spend compared to running without the cage "
             "(with-system vs. without-system counterfactual for one intent).",
        description=(
            "Show prevented spend compared to running without the "
            "cage. Takes one payment intent and emits the "
            "counterfactual: what the cage decided vs what an "
            "un-caged path would have done."
        ),
    )
    compare_p.add_argument(
        "--intent", required=True,
        help="Path to a JSON file containing the PaymentIntent shape "
             "(amount, currency, provider, counterparty, rail, "
             "timestamp_unix, metadata, request_id).",
    )
    compare_p.add_argument(
        "--format", dest="fmt", default="text",
        choices=["text", "json"],
        help="Output format (default: text).",
    )
    compare_p.add_argument(
        "--socket", default=DEFAULT_SOCKET,
        help=f"Path to the daemon UDS (default: {DEFAULT_SOCKET})",
    )

    risk_p = subparsers.add_parser(
        "risk-prevented",
        help="Show runtime risk counters (aggregate view of risk the cage "
             "prevented over a rolling window).",
        description=(
            "Show runtime risk counters. Aggregates the risk the cage "
            "prevented over a rolling window: per-currency totals, "
            "top providers, top rules that fired."
        ),
    )
    risk_p.add_argument(
        "--window", default="24h",
        help="Window as <N>[s|m|h|d] or raw seconds (e.g. 24h, 3600, 7d). "
             "Default: 24h. Use 0 for all history.",
    )
    risk_p.add_argument(
        "--top-n", type=int, default=5,
        help="How many providers / rules to surface in the top-N lists.",
    )
    risk_p.add_argument(
        "--format", dest="fmt", default="text",
        choices=["text", "json"],
        help="Output format (default: text).",
    )
    risk_p.add_argument(
        "--socket", default=DEFAULT_SOCKET,
        help=f"Path to the daemon UDS (default: {DEFAULT_SOCKET})",
    )

    # v0.15.0 — risk-dashboard mutation-failure timeline.
    mf_p = subparsers.add_parser(
        "mutation-failures",
        help="show recent mutation-failure entries (contradictions, "
             "governance / cross-revision violations) from the daemon's "
             "risk-dashboard ring buffer",
    )
    mf_p.add_argument(
        "--since", default=None,
        help="Only show entries from the last <N>[s|m|h|d] or raw seconds "
             "(e.g. 24h, 3600, 7d). Default: all retained entries.",
    )
    mf_p.add_argument(
        "--category", default=None,
        choices=[
            "cross_revision_violation",
            "governance_violation",
            "prover_contradiction",
            "prover_inconclusive",
            "bad_invariant",
        ],
        help="Filter by failure category.",
    )
    mf_p.add_argument(
        "--limit", default=50, type=int,
        help="Max entries to return (default: 50).",
    )
    mf_p.add_argument(
        "--format", dest="fmt", default="text",
        choices=["text", "json"],
        help="Output format (default: text).",
    )
    mf_p.add_argument(
        "--socket", default=DEFAULT_SOCKET,
        help=f"Path to the daemon UDS (default: {DEFAULT_SOCKET})",
    )

    # v0.15.0 — risk-dashboard active-constraints view.
    constraints_p = subparsers.add_parser(
        "constraints",
        help="show the constraints the cage is currently enforcing, "
             "grouped by class",
    )
    constraints_p.add_argument(
        "--format", dest="fmt", default="text",
        choices=["text", "json"],
        help="Output format (default: text).",
    )
    constraints_p.add_argument(
        "--socket", default=DEFAULT_SOCKET,
        help=f"Path to the daemon UDS (default: {DEFAULT_SOCKET})",
    )

    # v0.14.0 — explicit guarantees surface.
    guarantees_p = subparsers.add_parser(
        "guarantees",
        help="list what the cage guarantees right now (and what's lost if "
             "disabled)",
    )
    guarantees_p.add_argument(
        "--format", dest="fmt", default="text",
        choices=["text", "json"],
        help="Output format (default: text).",
    )
    guarantees_p.add_argument(
        "--only-lost", dest="only_lost", action="store_true",
        help="Invert the list: show inactive guarantees and the plain-English "
             "description of what is lost if the cage is disabled.",
    )
    guarantees_p.add_argument(
        "--socket", default=DEFAULT_SOCKET,
        help=f"Path to the daemon UDS (default: {DEFAULT_SOCKET})",
    )

    # cross-revision (v0.14.0) — dry-run a candidate vs the active revision.
    cr_p = subparsers.add_parser(
        "cross-revision",
        help="dry-run cross-revision compositional invariants against a "
             "candidate policy; exit 1 on violations, 0 on clean.",
    )
    cr_p.add_argument(
        "--candidate", required=True,
        help="Path to a YAML policy whose invariants are the candidate new "
             "revision. The daemon's active revision is fetched as the old "
             "side of the transition.",
    )
    cr_p.add_argument(
        "--branch", default="main",
        help="Branch the candidate would land on (default: main).",
    )
    cr_p.add_argument(
        "--socket", default=DEFAULT_SOCKET,
        help=f"Path to the daemon UDS (default: {DEFAULT_SOCKET})",
    )
    cr_p.add_argument(
        "--format", dest="fmt", default="text",
        choices=["text", "json"],
        help="Output format (default: text).",
    )

    # guaranteed (v0.19.0) — audit + evidence commands for Guaranteed Mode.
    # Delegated to daemon.guaranteed_cli so the bank-deployable tier's
    # surface stays isolated from the general CLI growth.
    try:
        from daemon import guaranteed_cli
        guaranteed_cli.register_subparser(subparsers)
    except ImportError:
        # Guaranteed module not present in this build; skip wiring.
        pass

    # v0.23.0 demo wrapper: ``tau-x402 demo hero`` — one-command hero demo.
    # Convenience wrapper over ``python3 demos/hero_retry_loop.py`` so
    # the existing entry point stays canonical. All demo-level flags are
    # forwarded; we do NOT duplicate the demo's narration / argparse
    # surface here.
    demo_p = subparsers.add_parser(
        "demo",
        help=(
            "one-command demo runner. ``tau-x402 demo hero`` wraps "
            "``python3 demos/hero_retry_loop.py`` (v0.23.0)."
        ),
    )
    demo_sub = demo_p.add_subparsers(dest="demo_action")
    hero_demo_p = demo_sub.add_parser(
        "hero",
        help=(
            "run the hero retry-loop demo: 7 paid calls in 9s, adaptive "
            "tightening contains them, prevented_loss JSON at the end."
        ),
    )
    hero_demo_p.add_argument(
        "--quiet", action="store_true",
        help=(
            "Suppress preamble + per-call narration; emit the "
            "prevented_loss JSON block only. Trivial to scrape from CI."
        ),
    )
    hero_demo_p.add_argument(
        "--json", dest="fmt", action="store_const", const="json",
        help=(
            "Emit the full machine-readable transcript to stdout (pure "
            "JSON, no narration). Useful for piping into jq."
        ),
    )

    # v0.21.0 front-door: ``tau-x402 run`` — one-command boot with safe
    # defaults. Distinguished from the bare daemon invocation (no
    # subcommand) by (a) preloading the packaged default safe policy,
    # (b) defaulting to enforce mode, (c) banner describing which
    # subsystems are live vs stubbed.
    run_p = subparsers.add_parser(
        "run",
        help=(
            "Authorise x402 payments for your agent. Boots the decision "
            "daemon + MCP tool with safe defaults (deny-by-default policy, "
            "runtime guard on, comparison counters on)."
        ),
        description=(
            "Authorise x402 payments for your agent. Boots the decision "
            "daemon + MCP tool should_pay_x402 with safe defaults: "
            "deny-by-default policy, runtime guard on (adaptive "
            "tightening), comparison counters on, advisory signals on. "
            "Zero config on the happy path; advanced details (fragment, "
            "prover chain, semantic fragment tier) live behind --verbose."
        ),
    )
    run_p.add_argument(
        "--socket", default=DEFAULT_SOCKET,
        help=f"UDS path the daemon listens on (default: {DEFAULT_SOCKET})",
    )
    run_p.add_argument(
        "--policy", default=None,
        help=(
            "Path to an explicit policy.yaml. When omitted, the packaged "
            "default safe-defaults policy is loaded."
        ),
    )
    run_p.add_argument(
        "--open-allowlist", action="store_true", dest="open_allowlist",
        help=(
            "Strip the deny-by-default provider_allowlist from the packaged "
            "default policy so any provider is permitted. NOT recommended "
            "beyond first-run bring-up; combine with TAU_CAGE_MODE=shadow."
        ),
    )
    run_p.add_argument(
        "--mode", default=None,
        choices=[m.value for m in CageMode],
        help=(
            "Cage mode: enforce (default) | shadow | advisory. "
            "Overrides TAU_CAGE_MODE."
        ),
    )
    run_p.add_argument(
        "--verbose", "-v", action="store_true", dest="verbose",
        help=(
            "Show advanced boot details (adaptive-tightening module, "
            "advisory surface, semantic fragment, prover chain, prover "
            "mode). Hidden by default so the first-run banner stays "
            "focused on the decision layer."
        ),
    )
    run_p.add_argument(
        "--dry-run", action="store_true", dest="dry_run",
        help=(
            "Boot + print the front-door banner + exit 0 without binding "
            "the socket. Useful for CI smoke tests."
        ),
    )
    # Pass-through args so ``tau-x402 run`` is also a full daemon
    # invocation when the operator wants to tune the prover / history /
    # initial spec without reaching for the subcommand-less form.
    # v0.19.0 product switch: ``--prover-mode guaranteed`` activates the
    # bank-deployable tier on the ``run`` front door. ``flexible`` is a
    # brief-shaped alias for the legacy ``compat``.
    run_p.add_argument("--prover-mode", default=None,
                       choices=["compat", "verified", "strict", "flexible", "guaranteed"],
                       help=(
                           "Admission policy: compat|verified|strict|flexible|guaranteed. "
                           "Takes precedence over policy.yaml cage: block."
                       ))
    run_p.add_argument("--tau-timeout-ms", default=None, type=int,
                       help=argparse.SUPPRESS)
    run_p.add_argument("--semantic-fragment", default=None,
                       help=argparse.SUPPRESS)
    run_p.add_argument("--initial-spec", default="u[t] = i[t].",
                       help=argparse.SUPPRESS)
    run_p.add_argument("--history-backend", default=None,
                       choices=["memory", "redis"],
                       help=argparse.SUPPRESS)
    run_p.add_argument("--redis-url", default=None, help=argparse.SUPPRESS)
    run_p.add_argument("--history-key-prefix", default=None,
                       help=argparse.SUPPRESS)
    run_p.add_argument("--history-cap", default=None, type=int,
                       help=argparse.SUPPRESS)
    run_p.add_argument("--prover-chain", default=None,
                       choices=["pattern", "tau", "z3", "hybrid"],
                       help=argparse.SUPPRESS)

    return parser


def main() -> int:
    parser = _build_parser()
    args = parser.parse_args()

    if args.subcommand == "init":
        return _cmd_init(args)
    if args.subcommand == "quickstart":
        return _cmd_quickstart(args)
    if args.subcommand == "lint":
        return _cmd_lint(args)
    if args.subcommand == "suggest":
        return _cmd_suggest(args)
    if args.subcommand == "narrate":
        return _cmd_narrate(args)
    if args.subcommand == "inspect":
        return _cmd_inspect(args)
    if args.subcommand == "explain":
        return _cmd_explain(args)
    if args.subcommand == "diff":
        return _cmd_diff(args)
    if args.subcommand == "keygen-ed25519":
        return _cmd_keygen_ed25519(args)
    if args.subcommand == "audit-export":
        return _cmd_audit_export(args)
    if args.subcommand == "audit-verify":
        return _cmd_audit_verify(args)
    if args.subcommand == "bundle":
        return _cmd_bundle(args)
    if args.subcommand == "bundle-verify":
        return _cmd_bundle_verify(args)
    if args.subcommand == "branch":
        return _cmd_branch(args)
    if args.subcommand == "propose":
        return _cmd_propose(args)
    if args.subcommand == "proposals":
        return _cmd_proposals(args)
    if args.subcommand == "approve":
        return _cmd_approve(args)
    if args.subcommand == "reject":
        return _cmd_reject(args)
    if args.subcommand == "governance":
        return _cmd_governance(args)
    if args.subcommand == "prover-metrics":
        return _cmd_prover_metrics(args)
    if args.subcommand == "shadow-summary":
        return _cmd_shadow_summary(args)
    if args.subcommand == "metrics":
        return _cmd_metrics(args)
    if args.subcommand == "replay":
        return _cmd_replay(args)
    if args.subcommand == "bench":
        return _cmd_bench(args)
    if args.subcommand == "webhook-test":
        return _cmd_webhook_test(args)
    if args.subcommand == "self-ref":
        return _cmd_self_ref(args)
    if args.subcommand == "mutation-risk":
        return _cmd_mutation_risk(args)
    if args.subcommand == "explain-decision":
        return _cmd_explain_decision(args)
    if args.subcommand == "compare":
        return _cmd_compare(args)
    if args.subcommand == "risk-prevented":
        return _cmd_risk_prevented(args)
    if args.subcommand == "guarantees":
        return _cmd_guarantees(args)
    if args.subcommand == "mutation-failures":
        return _cmd_mutation_failures(args)
    if args.subcommand == "constraints":
        return _cmd_constraints(args)
    if args.subcommand == "cross-revision":
        return _cmd_cross_revision(args)
    if args.subcommand == "guaranteed":
        from daemon import guaranteed_cli
        return guaranteed_cli.dispatch(args)
    if args.subcommand == "run":
        return _cmd_front_door_run(args)
    if args.subcommand == "demo":
        return _cmd_demo_hero(args)
    return _cmd_run(args)


if __name__ == "__main__":
    raise SystemExit(main())
