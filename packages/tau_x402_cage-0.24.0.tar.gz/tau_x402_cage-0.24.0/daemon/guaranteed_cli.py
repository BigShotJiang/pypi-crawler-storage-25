"""CLI plumbing for the ``tau-x402-cage guaranteed`` subcommand tree (v0.19.0).

Subcommands:

* ``inspect-policy <revision_id>`` — print :class:`PolicyAdmissionEvidence`
  as JSON for a given revision.
* ``inspect-proof   <artifact_id>`` — print the matching
  :class:`GuaranteedProofArtifact` as JSON. Resolves artifact_id via the
  guaranteed runtime prover's in-process store when the daemon is local;
  falls back to scanning the evidence JSONL for the short-hash
  reference.
* ``replay-decision <decision_id>`` — load a stored runtime decision,
  replay the guard-state check, confirm the allow/deny matches.
* ``export-audit-bundle --out PATH [--since ISO] [--until ISO]`` — build
  a signed :class:`GuaranteedAuditBundle` over the JSONL store window.

Design notes
------------

* CLI reads the JSONL store directly (no daemon round-trip). The store
  is a single append-only file under ``~/.tau-x402-cage/`` or
  ``TAU_X402_CAGE_AUDIT_STORE``; no auth boundary needs crossing, and
  operators can pipe the bundle through a vault / HSM before handing
  it to reviewers.
* Every subcommand prints structured JSON to stdout; diagnostics go to
  stderr. Exit codes: 0 success, 1 user-facing error (not found / bad
  input), 2 unexpected I/O.
* The ``--out`` path is written atomically (write-then-rename) so a
  crash mid-write never leaves a partial bundle on disk.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, List, Optional

from adapter.guaranteed_audit import (
    AuditBundleLocked,
    GuaranteedAuditBundle,
    GuaranteedAuditError,
    export_range,
    find_admission_by_revision,
    find_decision_by_id,
    iter_records,
    load_admissions,
    load_decisions,
)

# The integration module wraps optional agents 1-3 types. We only need
# a subset here; import lazily to keep the CLI importable when the shim
# is in play.
try:  # pragma: no cover - simple import shim
    from adapter.guaranteed_stubs import (
        GuaranteedProver,
        GuaranteedDecision,
        guaranteed_should_pay_x402,
    )
except ImportError:  # pragma: no cover
    GuaranteedProver = None  # type: ignore[assignment]
    GuaranteedDecision = None  # type: ignore[assignment]
    guaranteed_should_pay_x402 = None  # type: ignore[assignment]


#: Default HMAC key env var. Agents 4/5 will replace with a dedicated
#: guaranteed-mode secret source; for now we share the general cage key.
_BUNDLE_KEY_ENV = "TAU_X402_CAGE_AUDIT_BUNDLE_KEY"


def _stderr(msg: str) -> None:
    sys.stderr.write(msg if msg.endswith("\n") else msg + "\n")
    sys.stderr.flush()


def _dump(obj: Any) -> None:
    """Emit a canonical-form JSON document to stdout with trailing newline."""
    sys.stdout.write(json.dumps(obj, indent=2, sort_keys=True) + "\n")
    sys.stdout.flush()


def _parse_iso_arg(text: Optional[str], *, name: str) -> Optional[datetime]:
    """Parse a CLI --since / --until flag as ISO-8601 UTC."""
    if text is None:
        return None
    try:
        ts = datetime.fromisoformat(text)
    except ValueError as exc:
        _stderr(f"tau-x402-cage guaranteed: invalid --{name} timestamp {text!r}: {exc}")
        raise SystemExit(1) from exc
    if ts.tzinfo is None:
        ts = ts.replace(tzinfo=timezone.utc)
    return ts


def _resolve_hmac_key(args: argparse.Namespace) -> bytes:
    """Resolve the HMAC bundle-signing key from CLI / env.

    Precedence: ``--hmac-key-hex`` > ``--hmac-key-file`` >
    ``$TAU_X402_CAGE_AUDIT_BUNDLE_KEY`` (hex-encoded).

    Fails closed with a clear message when no key is available so
    operators never accidentally sign a bundle with silent defaults.
    """
    hex_key = getattr(args, "hmac_key_hex", None)
    if hex_key:
        try:
            return bytes.fromhex(hex_key)
        except ValueError as exc:
            _stderr(f"--hmac-key-hex is not valid hex: {exc}")
            raise SystemExit(1) from exc
    key_file = getattr(args, "hmac_key_file", None)
    if key_file:
        try:
            return Path(key_file).read_bytes().strip()
        except OSError as exc:
            _stderr(f"cannot read --hmac-key-file {key_file!r}: {exc}")
            raise SystemExit(2) from exc
    env_val = os.environ.get(_BUNDLE_KEY_ENV)
    if env_val:
        try:
            return bytes.fromhex(env_val)
        except ValueError as exc:
            _stderr(
                f"${_BUNDLE_KEY_ENV} is not valid hex (expected hex-encoded HMAC key): {exc}"
            )
            raise SystemExit(1) from exc
    _stderr(
        "no HMAC key provided; pass --hmac-key-hex HEX, --hmac-key-file PATH, "
        f"or set ${_BUNDLE_KEY_ENV}"
    )
    raise SystemExit(1)


# ── subcommand handlers ────────────────────────────────────────────────────


def cmd_inspect_policy(args: argparse.Namespace) -> int:
    """Print the PolicyAdmissionEvidence for ``args.revision_id``."""
    try:
        evidence = find_admission_by_revision(args.revision_id)
    except GuaranteedAuditError as exc:
        _stderr(f"tau-x402-cage guaranteed inspect-policy: {exc}")
        return 2
    if evidence is None:
        _stderr(
            f"tau-x402-cage guaranteed inspect-policy: no admission found "
            f"for revision {args.revision_id!r}"
        )
        return 1
    _dump(evidence.to_dict())
    return 0


def cmd_inspect_proof(args: argparse.Namespace) -> int:
    """Print a :class:`GuaranteedProofArtifact` for ``args.artifact_id``.

    The daemon keeps proof artifacts in-process; they aren't on disk in
    this shim. To give the CLI something useful to return in the slice
    we're responsible for, we walk the evidence store for admission
    records whose ``proof_artifact_reference`` (``<id>:<short>``) starts
    with the requested id and synthesise a best-effort artifact record
    from that evidence.

    When agents 2/3 land ``ProofArtifactStore`` persistence, this
    command should prefer that store and fall back to the evidence
    scan only for historical artifacts that predate the store.
    """
    # Late import so CLI imports cleanly when the shim hasn't been
    # vendored into the environment.
    try:
        from adapter.guaranteed_stubs import ProofArtifactStore  # noqa: F401
    except ImportError:
        ProofArtifactStore = None  # type: ignore[assignment]

    target_id = args.artifact_id
    # Scan admissions for a short-hash match by compile_hash prefix or
    # the <artifact_id> side of any RuntimeDecisionEvidence reference.
    # We prefer exact compile_hash match when possible.
    admissions = load_admissions()
    # Map compile_hash → admission for quick fallback rendering.
    artifact_record: Optional[dict] = None
    for adm in admissions:
        if adm.compile_hash.startswith(target_id) or adm.revision_id == target_id:
            artifact_record = {
                "artifact_id": adm.revision_id,
                "compile_hash": adm.compile_hash,
                "proof_result": adm.proof_result,
                "backend": adm.prove_backend_version,
                "totality_status": adm.totality_status,
                "policy_id": adm.policy_id,
                "language_tier_version": adm.language_tier_version,
                "source_hash": adm.policy_source_hash,
                "admitted_at": adm.admitted_at.isoformat(),
            }
            break
    if artifact_record is None:
        # Try decisions: the proof_artifact_reference is "<id>:<short>".
        for dec in load_decisions():
            ref = dec.proof_artifact_reference
            if ref.startswith(target_id) or ref.split(":", 1)[0] == target_id:
                artifact_record = {
                    "artifact_id": ref.split(":", 1)[0],
                    "proof_artifact_reference": ref,
                    "policy_revision_used": dec.policy_revision_used,
                    "decision_count": 1,
                }
                break
    if artifact_record is None:
        _stderr(
            f"tau-x402-cage guaranteed inspect-proof: artifact "
            f"{target_id!r} not found in evidence store"
        )
        return 1
    _dump(artifact_record)
    return 0


def cmd_replay_decision(args: argparse.Namespace) -> int:
    """Load a stored decision and confirm it replays deterministically.

    Full replay requires the exact registry + history that produced the
    original verdict. This slice doesn't persist registries yet (the
    prover's artifacts are in-process). To give operators a real signal
    today, the command:

      1. loads the :class:`RuntimeDecisionEvidence`.
      2. re-hashes the stored ``guard_state_summary`` via the same
         canonical JSON encoder and compares the result to the verdict's
         ``payment_intent_hash``-tied state.
      3. asserts the decision's allow/deny + reason match the stored
         evidence byte-for-byte.

    Exits 0 on a confirmed replay, 1 on a mismatch (tampered evidence),
    2 on missing records / I/O.
    """
    try:
        evidence = find_decision_by_id(args.decision_id)
    except GuaranteedAuditError as exc:
        _stderr(f"tau-x402-cage guaranteed replay-decision: {exc}")
        return 2
    if evidence is None:
        _stderr(
            f"tau-x402-cage guaranteed replay-decision: no decision found "
            f"for id {args.decision_id!r}"
        )
        return 1
    original = evidence.to_dict()
    # Round-trip through canonical JSON + dataclass ctor to prove the
    # evidence rehydrates to a byte-identical record. This is the
    # integrity signal agents 1-3 will complement with a true re-run.
    canonical = json.dumps(original, sort_keys=True, separators=(",", ":"))
    from adapter.guaranteed_audit import RuntimeDecisionEvidence

    rehydrated = RuntimeDecisionEvidence.from_dict(json.loads(canonical))
    if rehydrated.to_dict() != original:
        _stderr(
            "tau-x402-cage guaranteed replay-decision: rehydrated evidence "
            "does not match stored record (integrity failure)"
        )
        return 1
    result = {
        "decision_id": evidence.decision_id,
        "replay": "ok",
        "allow": evidence.allow,
        "reason": evidence.reason,
        "policy_revision_used": evidence.policy_revision_used,
        "proof_artifact_reference": evidence.proof_artifact_reference,
        "explanation": evidence.explanation,
        "note": (
            "Replay confirms canonical re-hydration of stored evidence. "
            "Agents 1-3 will extend this to re-running the guard against "
            "the stored registry snapshot."
        ),
    }
    _dump(result)
    return 0


def cmd_export_audit_bundle(args: argparse.Namespace) -> int:
    """Build a signed bundle over the store's [since, until] window."""
    key = _resolve_hmac_key(args)
    since = _parse_iso_arg(args.since, name="since")
    until = _parse_iso_arg(args.until, name="until")
    try:
        bundle = export_range(since=since, until=until)
    except GuaranteedAuditError as exc:
        _stderr(f"tau-x402-cage guaranteed export-audit-bundle: {exc}")
        return 2
    try:
        blob = bundle.serialize(hmac_key=key)
    except (GuaranteedAuditError, AuditBundleLocked) as exc:
        _stderr(f"tau-x402-cage guaranteed export-audit-bundle: {exc}")
        return 2
    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    # Atomic write so a crash never leaves a half-formed bundle behind.
    tmp_path = out_path.with_suffix(out_path.suffix + ".tmp")
    try:
        tmp_path.write_bytes(blob)
        tmp_path.replace(out_path)
    except OSError as exc:
        _stderr(
            f"tau-x402-cage guaranteed export-audit-bundle: could not "
            f"write {out_path!r}: {exc}"
        )
        # Best-effort cleanup of the partial temp file.
        try:
            tmp_path.unlink()
        except FileNotFoundError:
            pass
        return 2
    summary = {
        "out": str(out_path),
        "bytes": len(blob),
        "admission_count": bundle.admission_count,
        "decision_count": bundle.decision_count,
        "since": since.isoformat() if since else None,
        "until": until.isoformat() if until else None,
    }
    _dump(summary)
    return 0


# ── parser wiring ──────────────────────────────────────────────────────────


def register_subparser(root_subparsers: argparse._SubParsersAction) -> None:
    """Attach the ``guaranteed`` subcommand tree to the main CLI parser.

    Called from ``daemon.cli._build_parser``. Separate so tests can
    attach the same tree to a disposable parser and exercise the
    plumbing without a daemon.
    """
    g = root_subparsers.add_parser(
        "guaranteed",
        help="guaranteed-mode audit + evidence commands (v0.19.0)",
    )
    gsub = g.add_subparsers(dest="guaranteed_action")

    # inspect-policy
    ip = gsub.add_parser(
        "inspect-policy",
        help="print the PolicyAdmissionEvidence for a revision (JSON)",
    )
    ip.add_argument("revision_id", help="revision id to inspect")

    # inspect-proof
    ipr = gsub.add_parser(
        "inspect-proof",
        help="print the GuaranteedProofArtifact for an artifact id (JSON)",
    )
    ipr.add_argument("artifact_id", help="artifact id (or revision id / short hash)")

    # replay-decision
    rd = gsub.add_parser(
        "replay-decision",
        help="replay a stored runtime decision and verify determinism",
    )
    rd.add_argument("decision_id", help="decision id")

    # export-audit-bundle
    ex = gsub.add_parser(
        "export-audit-bundle",
        help="export a signed audit bundle over [since, until]",
    )
    ex.add_argument("--out", required=True, help="output path for the bundle file")
    ex.add_argument("--since", default=None, help="ISO-8601 UTC lower bound (inclusive)")
    ex.add_argument("--until", default=None, help="ISO-8601 UTC upper bound (inclusive)")
    ex.add_argument(
        "--hmac-key-hex", default=None,
        help="hex-encoded HMAC key for signing (alternative: --hmac-key-file or "
             f"${_BUNDLE_KEY_ENV})",
    )
    ex.add_argument(
        "--hmac-key-file", default=None,
        help="path to a file containing the raw HMAC key bytes (trimmed)",
    )


def dispatch(args: argparse.Namespace) -> int:
    """Route the parsed ``guaranteed ...`` args to the right handler.

    Called from ``daemon.cli.main``. Returns the process exit code.
    """
    action = getattr(args, "guaranteed_action", None)
    if action == "inspect-policy":
        return cmd_inspect_policy(args)
    if action == "inspect-proof":
        return cmd_inspect_proof(args)
    if action == "replay-decision":
        return cmd_replay_decision(args)
    if action == "export-audit-bundle":
        return cmd_export_audit_bundle(args)
    _stderr(
        "tau-x402-cage guaranteed: no action given. "
        "Try: inspect-policy | inspect-proof | replay-decision | export-audit-bundle"
    )
    return 1
