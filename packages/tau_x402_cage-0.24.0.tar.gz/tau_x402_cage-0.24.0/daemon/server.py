"""CageDaemon: UDS server wrapping the cage state.

JSON-over-newline framing on a Unix domain socket. One request per line, one
response per line. Designed for low-latency local IPC from the x402 client
mediator and the PreToolUse hook.

Hot path (op=check_payment): reconstruct PaymentIntent from the request →
X402Registry.check_payment against the active invariant set → verdict JSON.
Admin path (op=declare_x402 / op=retract_x402): registry mutation gated by
the configured ConsistencyProver (pattern precheck, then Tau for fragment v1
or z3 for fragment v2 in `verified`/`strict` modes).

Thread model: ThreadingUnixStreamServer fans out connections. Registry
mutations and history updates go through a daemon-level lock
(`self._registry_lock`) to serialise declare/retract against in-flight
check_payment reads.
"""
from __future__ import annotations

import json
import logging
import os
import socket
import socketserver
import threading
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any, Mapping, Optional

import time

from adapter.approval_queue import (
    ApprovalQueue,
    ApprovalQueueError,
    Proposal,
)
from adapter.cage_mode import CageMode, DEFAULT_MODE, is_non_enforcing
from adapter.mutation_governance import (
    GovernancePolicy,
    GovernanceVerdict,
)
from adapter.history_store import (
    HistoryStore,
    InMemoryHistoryStore,
)
from adapter.metrics import CageMetrics, _NullMetrics, get_default as _default_metrics
from adapter.mutation_safety import (
    MutationResult,
    ProverChain,
    RevisionDelta,
    apply_revision_delta_strict,
)
from adapter.invariants import (
    AdaptiveTighteningPolicy,
    BurstVelocityCap,
    CounterpartyConstraint,
    Invariant,
    JurisdictionRule,
    MaxPerCall,
    MutualExclusion,
    PeerAuthenticationPolicy,
    ProviderAllowlist,
    RetryRateLimit,
    RollingWindowCap,
    SpendingCap,
)
from adapter.peer_credentials import (
    PeerCredentials,
    lookup_peer_credentials,
)
from adapter.self_ref_policy import (
    InstabilityGuard,
    MergeFailureCooldown,
)
from adapter.runtime_guard import RuntimeGuard
from adapter.payment_intent_matcher import InvalidPaymentIntent, PaymentIntent
from adapter.policy_revision import (
    Branch,
    BranchMergeConflict,
    CrossRevisionRejected,
    DEFAULT_BRANCH,
    PolicyRevision,
    RevisionLog,
    RevisionLogError,
)
from adapter.cross_revision import (
    CrossRevisionValidator,
)
from adapter.revision_sync import RevisionSyncAdapter
from adapter.hybrid_prover import HybridProver
from adapter.proof_report import ContradictionReport, InconclusiveReport
from adapter.risk_signals import (
    MutationFailureEntry,
    MutationFailureLog,
    active_constraints as _active_constraints,
    classify_rejection as _classify_rejection,
)
from adapter.prover import (
    ConsistencyProver,
    Contradiction,
    InconclusiveProof,
    IncrementalZ3Prover,
    ProofToken,
    PythonPatternProver,
    TauConsistencyProver,
)
from adapter.verdict_signer import Verdict, hash_intent, sign
from adapter.webhook_sink import WebhookSink
from adapter.x402_registry import X402Registry
from adapter.history_store import _intent_to_json as _history_intent_to_json
from adapter.history_store import _intent_from_json as _history_intent_from_json

logger = logging.getLogger(__name__)


def _redact_path(p: str) -> str:
    """Redact a path for log lines so declared paths don't leak to /tmp logs."""
    return "[protected]"


def _classify_backend_label(backend: str) -> str:
    """Map a prover backend name onto one of the canonical metric labels.

    Prometheus cardinality discipline: we collapse the ~6 prover-backend
    strings the runtime emits (``python-pattern``, ``tau``, ``z3``,
    ``z3-incremental``, ``hybrid-composite`` etc.) onto the four stable
    labels the metric surfaces as. Unknown backends map to ``pattern`` —
    the cheapest bucket, which is the safest default for surprise data.
    """
    lowered = (backend or "").lower()
    if "hybrid" in lowered:
        return "hybrid"
    if "z3" in lowered:
        return "z3"
    if "tau" in lowered:
        return "tau"
    return "pattern"


def _relabel_strength(token: ProofToken, new_strength: str) -> ProofToken:
    """Return a new ProofToken with an updated proof_strength field."""
    return ProofToken(
        config_hash=token.config_hash,
        issued_at_unix=token.issued_at_unix,
        backend=token.backend,
        proof_strength=new_strength,
        nonce=token.nonce,
        predecessor_hash=token.predecessor_hash,
        prover_mode=token.prover_mode,
        fragment_version=token.fragment_version,
        compile_hash=token.compile_hash,
        tau_backend_version=token.tau_backend_version,
        witness=token.witness,
    )


def _with_mode(token: ProofToken, prover_mode: str) -> ProofToken:
    """Return a new ProofToken stamped with the admitting daemon's mode."""
    return ProofToken(
        config_hash=token.config_hash,
        issued_at_unix=token.issued_at_unix,
        backend=token.backend,
        proof_strength=token.proof_strength,
        nonce=token.nonce,
        predecessor_hash=token.predecessor_hash,
        prover_mode=prover_mode,
        fragment_version=token.fragment_version,
        compile_hash=token.compile_hash,
        tau_backend_version=token.tau_backend_version,
        witness=token.witness,
    )


def _conflicting_invariants_from(c: Contradiction) -> tuple[str, ...]:
    """Parse ``Contradiction.left`` / ``.right`` into a pair of identifiers.

    The current prover taxonomy uses free-form strings for ``left`` / ``right``
    (e.g. ``"CounterpartyConstraint(approved=[...], ...)"`` or
    ``"ProviderAllowlist (multi)"``). We preserve them verbatim and expose
    them as a tuple so downstream callers see a stable shape regardless of
    which backend produced the contradiction.
    """
    return (c.left, c.right)


def _suggested_repair_for(c: Contradiction) -> Optional[str]:
    """Map a ``Contradiction.reason`` to a concrete, single-sentence repair hint.

    Only exact-phrase keywords are matched (case-insensitive). Unknown
    reasons return ``None`` so consumers can distinguish "no hint available"
    from "hint applies".
    """
    reason_lower = (c.reason or "").lower()
    # The sanctioned/approved clash (pattern prover C3): surfaced as
    # "Counterparty IDs appear as approved in one rule and sanctioned in another".
    if "sanctioned" in reason_lower and "approved" in reason_lower:
        return (
            "Remove the sanctioned id from the approved set, "
            "or vice versa; an id cannot be both."
        )
    # Multi-ProviderAllowlist empty intersection (pattern prover, N-ary).
    if "empty pairwise intersection" in reason_lower or "disjoint" in reason_lower:
        return "Widen one of the sets so their intersection is non-empty."
    # Compiler rejected an invariant outside fragment v1.
    if "unsupported_fragment" in reason_lower or c.right == "fragment_v1":
        return (
            "Remove the out-of-fragment invariant, "
            "or switch the daemon to compat mode."
        )
    return None


def _contradiction_to_report(c: Contradiction) -> ContradictionReport:
    """Build a structured wire report from a prover Contradiction."""
    return ContradictionReport(
        conflicting_invariants=_conflicting_invariants_from(c),
        unsat_explanation=c.reason,
        suggested_repair=_suggested_repair_for(c),
        backend=c.backend,
    )


def _inconclusive_to_report(i: InconclusiveProof) -> InconclusiveReport:
    """Build a structured wire report from a prover InconclusiveProof.

    Pass-through on ``category``, ``reason``, ``backend``; ``details`` is
    normalised to an empty dict when absent so the wire shape is stable.
    """
    return InconclusiveReport(
        category=i.category,
        reason=i.reason,
        backend=i.backend,
        details=dict(i.details) if i.details else {},
    )


def _scope_hint_for(inv: Any) -> str:
    """Build a short, human-readable hint describing an invariant's scope.

    The hint is intentionally compact (one line, <80 chars) so `inspect`
    output stays scannable even for long rule sets. Format is
    ``key=value[, key=value ...]``; unknown invariant classes fall back to
    ``repr(inv)`` so nothing goes un-labelled.
    """
    if isinstance(inv, MaxPerCall):
        return f"max={inv.max_amount} {inv.currency}"
    if isinstance(inv, SpendingCap):
        parts = [f"max={inv.max_amount} {inv.currency}", f"scope={inv.scope}"]
        if inv.window_seconds is not None:
            parts.append(f"window={inv.window_seconds}s")
        if inv.provider is not None:
            parts.append(f"provider={inv.provider}")
        return ", ".join(parts)
    if isinstance(inv, ProviderAllowlist):
        return f"providers={sorted(inv.providers)}"
    if isinstance(inv, RetryRateLimit):
        return f"min_gap={inv.min_gap_seconds}s"
    if isinstance(inv, RollingWindowCap):
        return (
            f"max_count={inv.max_count}, "
            f"window={inv.window_seconds}s, group_by={inv.group_by}"
        )
    if isinstance(inv, CounterpartyConstraint):
        approved = sorted(inv.approved_ids)
        sanctioned = sorted(inv.sanctioned_ids)
        return f"approved={approved}, sanctioned={sanctioned}"
    if isinstance(inv, MutualExclusion):
        return f"group_a={sorted(inv.group_a)}, group_b={sorted(inv.group_b)}"
    if isinstance(inv, JurisdictionRule):
        return (
            f"jurisdiction={inv.jurisdiction}, "
            f"inner={len(inv.additional_invariants)}"
        )
    return repr(inv)


def _guaranteed_classify_variant(inv: Any) -> str | None:
    """Best-effort variant-tag classifier for a Guaranteed-Mode reject envelope.

    The Guaranteed language tier admits some rule classes only in specific
    shapes (e.g. ``JurisdictionRule`` with empty ``additional_invariants``).
    When a rule is rejected, auditors need to see which variant was
    attempted so they can distinguish ``enum_bv`` from the richer
    ``nested_composition`` / ``sanctions_negation`` / ``nlang`` variants.

    Returns ``None`` for rule types that have no variant dimension (e.g.
    ``MaxPerCall`` has a single shape) or for invariants outside the
    variant-qualified set.
    """
    try:
        from adapter.guaranteed_language import GuaranteedLanguage
    except ImportError:
        return None
    # Try the tier's own classifier first (returns the admitted tag or None).
    try:
        tag = GuaranteedLanguage._classify_variant(inv)
    except Exception:  # noqa: BLE001 - best effort
        tag = None
    if tag is not None:
        return tag
    # Fall back to naming the non-admitted variant so the audit envelope
    # still distinguishes the failure. Matches the taxonomy in
    # ``_EXCLUDED_RULES_REASON`` so audit tooling can join on the tag.
    if isinstance(inv, JurisdictionRule) and inv.additional_invariants:
        return "nested_composition"
    if isinstance(inv, CounterpartyConstraint):
        if inv.sanctioned_ids and inv.approved_ids:
            return "sanctions_negation"
        if inv.sanctioned_ids and not inv.approved_ids:
            return "sanctions_negation"
    return None


def _guaranteed_failure_target(
    invariants: tuple[Any, ...], failure: Any
) -> tuple[str, str | None]:
    """Derive (rule_name, variant) for a GuaranteedFailure envelope.

    Scans ``invariants`` to find the first rule the language tier does
    not admit; falls back to ``(policy)`` when totality fails for a
    policy-scope reason rather than a specific rule. The variant tag is
    produced via :func:`_guaranteed_classify_variant`.
    """
    try:
        from adapter.guaranteed_language import GuaranteedLanguage
    except ImportError:
        return ("(policy)", None)
    for inv in invariants:
        try:
            ok, _ = GuaranteedLanguage.is_supported(inv)
        except Exception:  # noqa: BLE001
            continue
        if not ok:
            return (type(inv).__name__, _guaranteed_classify_variant(inv))
    # No rule-level unsupported — attribute to the whole policy.
    return ("(policy)", None)


def _intent_summary(intent: PaymentIntent) -> dict[str, Any]:
    """Compact, JSON-safe summary of a PaymentIntent for inspection surfaces.

    Deliberately omits `metadata` and `request_id` so the web UI never leaks
    free-form per-request fields that may carry PII. Auditors wanting the
    full record must query the signed verdict envelope from the facilitator.
    """
    return {
        "amount": str(intent.amount),
        "currency": intent.currency,
        "provider": intent.provider,
        "counterparty": intent.counterparty,
        "rail": intent.rail,
        "timestamp_unix": intent.timestamp_unix,
    }


def _reconstruct_intent(d: dict[str, Any]) -> PaymentIntent:
    """Turn the wire dict sent by x402_client.UdsDaemonClient into a PaymentIntent.

    Every string field flows through PaymentIntent.__post_init__ which
    enforces the safe-token schema (H-07), so untrusted input is validated
    here before touching any invariant logic.
    """
    return PaymentIntent(
        amount=Decimal(str(d["amount"])),
        currency=str(d.get("currency", "USDC")),
        provider=str(d.get("provider", "")),
        counterparty=str(d.get("counterparty", "")),
        rail=str(d.get("rail", "x402")),
        timestamp_unix=int(d.get("timestamp_unix", 0)),
        metadata={str(k): str(v) for k, v in (d.get("metadata") or {}).items()},
        request_id=str(d["request_id"]) if d.get("request_id") is not None else None,
    )


class _CageRequestHandler(socketserver.StreamRequestHandler):
    """Per-connection handler. Reads one JSON line, writes one JSON line.

    v0.22.0: looks up kernel-verified peer credentials via
    ``adapter.peer_credentials.lookup_peer_credentials`` and threads them
    through to :meth:`CageDaemon.dispatch` so mutation-op gating can
    honour the active ``PeerAuthenticationPolicy``. ``None`` creds are
    passed through; the daemon's auth gate decides whether that is
    admissible.
    """

    def handle(self) -> None:
        daemon: "CageDaemon" = self.server.cage  # type: ignore[attr-defined]
        peer = lookup_peer_credentials(self.request)
        try:
            raw = self.rfile.readline()
        except OSError:
            return
        if not raw:
            return
        try:
            payload = json.loads(raw.decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            self._respond({"verdict": "error", "category": "protocol",
                           "reason": "malformed JSON"})
            return
        response = daemon.dispatch(payload, peer=peer)
        self._respond(response)

    def _respond(self, response: dict[str, Any]) -> None:
        # Escape literal newlines in any string values so framing stays safe.
        line = json.dumps(response, ensure_ascii=False).replace("\n", "\\n") + "\n"
        try:
            self.wfile.write(line.encode("utf-8"))
        except OSError:
            pass


class _ThreadingUnixServer(socketserver.ThreadingMixIn, socketserver.UnixStreamServer):
    daemon_threads = True
    allow_reuse_address = True


class CageDaemon:
    """Holds the cage state (registry + interpreter) behind a UDS server."""

    # Admission mode semantics -- see docs/semantic_fragment_v1.md.
    #   "compat"   : Python pattern prover only; Tau is not consulted.
    #                Backwards-compatible with v0.3.2 behavior.
    #   "verified" : pattern prechecks; Tau runs; inconclusive still admits
    #                (with "pattern+tau-inconclusive" proof strength).
    #   "strict"   : pattern prechecks; Tau runs; inconclusive/timeout/
    #                unavailable/unsupported_fragment -> REJECT. No silent
    #                downgrade. Only Tau-SAT proofs admit.
    #   "guaranteed" (v0.19.0): bank-deployable tier. Every admission goes
    #                through GuaranteedProver (totality gate + pure Tau).
    #                Anything outside the Guaranteed language tier is
    #                rejected with the canonical
    #                ``unsupported_for_guaranteed_mode`` envelope. No
    #                fallbacks (no pattern, no z3, no hybrid).
    _ALLOWED_MODES = ("compat", "verified", "strict", "guaranteed")

    def __init__(
        self,
        socket_path: str,
        initial_spec: str = "u[t] = i[t].",
        prover: ConsistencyProver | None = None,
        prover_mode: str = "compat",
        tau_prover: ConsistencyProver | None = None,
        tau_timeout_ms: int = 10000,
        revision_log_path: Path | None = None,
        hmac_secret: bytes | None = None,
        approval_queue_path: Path | None = None,
        require_human_approval: bool = False,
        z3_incremental_prover: IncrementalZ3Prover | None = None,
        history_store: HistoryStore | None = None,
        hybrid_prover: HybridProver | None = None,
        metrics: "CageMetrics | _NullMetrics | None" = None,
        webhook_sinks: list[WebhookSink] | None = None,
        revision_sync: RevisionSyncAdapter | None = None,
        merge_cooldown: MergeFailureCooldown | None = None,
        cage_mode: CageMode | str = DEFAULT_MODE,
        cross_revision_validator: CrossRevisionValidator | None = None,
        governance_policy: GovernancePolicy | None = None,
        mutation_failure_log: MutationFailureLog | None = None,
    ) -> None:
        # `initial_spec` is retained for signature compatibility with older
        # callers but is unused: the x402 hot path is pure-Python enforcement
        # via X402Registry.check_payment, and declare-time consistency is
        # vetted by the ConsistencyProver (Tau for fragment v1, z3 for v2).
        del initial_spec
        if prover_mode not in self._ALLOWED_MODES:
            raise ValueError(
                f"prover_mode must be one of {self._ALLOWED_MODES}, got {prover_mode!r}"
            )
        if not isinstance(tau_timeout_ms, int) or tau_timeout_ms <= 0:
            raise ValueError(
                f"tau_timeout_ms must be a positive int (ms), got {tau_timeout_ms!r}"
            )
        self.socket_path = socket_path
        self._tau_timeout_ms = tau_timeout_ms
        self._x402_registry = X402Registry.empty()
        # v0.8.0: history lives behind HistoryStore so the daemon can be
        # pointed at Redis for durable, replica-shared state. Default is
        # in-memory — identical semantics to pre-v0.8.0 tuples.
        self._history_cap = 10_000  # bound memory; oldest trimmed
        self._history_store: HistoryStore = (
            history_store if history_store is not None
            else InMemoryHistoryStore(cap=self._history_cap)
        )
        # Pattern prover is always available (fast precheck, used by all modes).
        self._pattern_prover: ConsistencyProver = prover or PythonPatternProver()
        # Tau prover is optional and only consulted in verified/strict/
        # guaranteed modes. When auto-constructing we thread the configured
        # timeout_seconds through; callers that pass their own tau_prover
        # control its timeout themselves.
        self._tau_prover: ConsistencyProver | None = (
            tau_prover if tau_prover is not None
            else (
                TauConsistencyProver(timeout_seconds=tau_timeout_ms / 1000.0)
                if prover_mode != "compat" else None
            )
        )
        self._prover_mode = prover_mode
        # v0.19.0: Guaranteed Mode wires a :class:`GuaranteedProver` over the
        # Tau prover and runs it AHEAD of the standard admission chain. The
        # strict contract (``TauConsistencyProver`` only) is enforced by the
        # GuaranteedProver constructor, so misconfiguration fails loud here.
        # Lazy-imported to keep ``tau-x402-cage run --prover-mode compat``
        # working on environments that lack the Tau binding.
        self._guaranteed_prover: Any = None
        if prover_mode == "guaranteed":
            from adapter.guaranteed_prover import GuaranteedProver as _GProver
            if not isinstance(self._tau_prover, TauConsistencyProver):
                raise ValueError(
                    "prover_mode='guaranteed' requires a TauConsistencyProver "
                    f"(got {type(self._tau_prover).__name__!r}); Guaranteed "
                    "Mode is Tau-only."
                )
            self._guaranteed_prover = _GProver(prover=self._tau_prover)
        self._revision_log: tuple[ProofToken, ...] = ()
        self._registry_lock = threading.Lock()
        self._server: _ThreadingUnixServer | None = None
        # Patch 7: durable PolicyRevision chain. Persisted to disk if
        # `revision_log_path` is provided; otherwise in-memory only.
        self._revision_log_path = revision_log_path
        self._policy_revisions: RevisionLog = self._load_or_init_revision_log(
            revision_log_path
        )
        # v0.14.0: attach the optional cross-revision validator so every
        # ``append()`` / ``merge_branch()`` on the log runs it. Stashed
        # on the log rather than the daemon so tests that drive the log
        # directly get the same behaviour.
        self._cross_revision_validator: CrossRevisionValidator | None = (
            cross_revision_validator
        )
        self._policy_revisions.cross_revision_validator = (
            cross_revision_validator
        )
        # Replay any persisted revisions into the active registry so the
        # daemon resumes with the last-admitted policy in effect.
        self._replay_revisions()
        # Patch 8: optional HMAC secret for signing verdicts with provenance.
        # When set, `check_payment` returns v2 envelope provenance in its
        # JSON reply for clients that want to sign on the daemon side.
        self._hmac_secret = hmac_secret
        # v0.7.0: agent-proposes / human-approves queue. When
        # `require_human_approval=True`, new add_invariant ops become
        # pending Proposals and return a 202-like envelope instead of
        # flowing straight into the admission path.
        self._approval_queue_path = approval_queue_path
        self._approval_queue: ApprovalQueue = (
            ApprovalQueue.load(approval_queue_path)
            if approval_queue_path is not None
            else ApprovalQueue()
        )
        self._require_human_approval = bool(require_human_approval)
        # v0.7.0: optional incremental z3 prover for fragment v2 push/pop.
        # When wired, delta ops (add/remove/update_invariant) route their
        # fragment-v2 subset through `prove_delta` before admission.
        # Pattern + Tau (for v1 rules) still run as before; the z3
        # prover is a parallel authoritative check for v2 rules only.
        self._z3_incremental_prover: IncrementalZ3Prover | None = (
            z3_incremental_prover
        )
        # v0.8.0: optional hybrid prover for cross-fragment composed SAT.
        # When wired, `_apply_revision` routes the entire delta through
        # `HybridProver.prove_delta` and skips the pattern/Tau/z3 chain
        # below (the hybrid prover composes those internally). When
        # absent, the legacy chain applies unchanged.
        self._hybrid_prover: HybridProver | None = hybrid_prover
        # v0.9.0: Prometheus metrics. When `metrics` is None we fall back
        # to the module-level default (a real CageMetrics if the
        # prometheus_client extra is installed, a no-op stand-in
        # otherwise), so call sites never need a None-guard.
        self._metrics: "CageMetrics | _NullMetrics" = (
            metrics if metrics is not None else _default_metrics()
        )
        # v0.10.0: webhook sinks for verdict fan-out. Each sink runs its own
        # worker thread; the hot path emits into them fire-and-forget. We
        # keep the list as a tuple internally so mutation attempts fail
        # loudly instead of silently drifting from the started workers.
        sinks = list(webhook_sinks) if webhook_sinks else []
        for sink in sinks:
            # Best-effort: wire the daemon's metrics registry into the sink
            # if the sink was constructed without one. Keeps every sink
            # visible on the same Prometheus scrape.
            if getattr(sink, "_metrics", None) is None:
                sink._metrics = self._metrics  # type: ignore[attr-defined]
        self._webhook_sinks: tuple[WebhookSink, ...] = tuple(sinks)
        # v0.11.0: multi-node revision sync over Redis pub/sub. When wired,
        # every local mutation publishes a record to the shared channel and
        # the subscriber thread replays remote mutations into the local
        # log. The daemon never blocks on publish; subscriber startup is
        # handled in `serve_forever` so tests that inject an adapter can
        # still drive `dispatch` directly without touching the UDS server.
        # v0.13.0: self-referential merge-failure cooldown. When wired,
        # ``merge_branch`` ops short-circuit while the cooldown is active.
        # Disabled state (``cooldown_seconds=0`` or ``None``) leaves the
        # daemon at pre-v0.13.0 merge semantics.
        self._merge_cooldown: MergeFailureCooldown | None = merge_cooldown
        self._revision_sync: RevisionSyncAdapter | None = revision_sync
        if self._revision_sync is not None:
            # Thread our registry lock into the subscriber so remote apply
            # events serialise against the same hot-path mutations as
            # local ops. The subscriber was likely constructed with its
            # own default lock; we rebind to ours for coherency.
            self._revision_sync.subscriber._lock = self._registry_lock
        # v0.13.0: cage mode (enforce / shadow / advisory). Normalise
        # strings to the enum here so every downstream call can rely
        # on the exact type. Unknown strings raise at construction time
        # — a silent fallback to enforce would hide a config typo that
        # the operator thought put them in shadow.
        if isinstance(cage_mode, CageMode):
            self._cage_mode: CageMode = cage_mode
        else:
            # Re-use the CLI parser for consistent error messages.
            from adapter.cage_mode import parse_mode
            self._cage_mode = parse_mode(str(cage_mode))
        # v0.14.0: optional policy-over-policy governance. When wired, every
        # propose / approve / add / remove / update op routes through the
        # four check_* axes below. Absent (None) leaves the daemon at
        # pre-v0.14.0 semantics (single-reviewer, any actor, any window).
        self._governance: GovernancePolicy | None = governance_policy
        # v0.15.0: risk-dashboard mutation-failure log. Default to a fresh
        # in-memory ring buffer so the daemon always has a log to append
        # to; operators who don't care about the dashboard pay only the
        # append cost (one lock + list mutation) per rejected mutation.
        self._mutation_failure_log: MutationFailureLog = (
            mutation_failure_log
            if mutation_failure_log is not None
            else MutationFailureLog()
        )
        # v0.17.0: unified runtime-guard over the same history store. Pure
        # read-mostly surface; no extra state. Wired with the merge cooldown
        # so cooldown_state() sees every cooldown source in one pass.
        self._runtime_guard: RuntimeGuard = RuntimeGuard(
            self._history_store,
            merge_cooldown=self._merge_cooldown,
        )
        self._unlink_existing_socket()

    @property
    def cage_mode(self) -> CageMode:
        """Current operating mode. Read-only after construction."""
        return self._cage_mode

    @property
    def governance_policy(self) -> GovernancePolicy | None:
        """The loaded policy-over-policy, or None when governance is disabled."""
        return self._governance

    def _load_or_init_revision_log(
        self, path: Path | None
    ) -> RevisionLog:
        """Load a persisted RevisionLog from disk, or construct an empty one.

        Missing file, no configured path, or empty file -> empty log. A
        corrupted file raises RevisionLogError from load(); we propagate
        because silently dropping audit records would be worse than crashing.
        """
        if path is None:
            return RevisionLog(path=None)
        return RevisionLog.load(path)

    def _replay_revisions(self) -> None:
        """Rebuild `_x402_registry` from the persisted revision chain.

        On daemon startup, the latest revision's invariant set wins. We
        replay rather than just snapshot-loading so any future auditor
        tooling can observe the chain as admitted, not a flattened view.
        """
        latest = self._policy_revisions.latest
        if latest is None:
            return
        # Rebuild the registry by declaring each invariant in the latest
        # revision; order is preserved so declaration-order semantics in
        # check_payment stay stable across restart.
        reg = X402Registry.empty()
        for inv in latest.invariants:
            reg = reg.declare(inv)
        self._x402_registry = reg

    def _unlink_existing_socket(self) -> None:
        try:
            os.unlink(self.socket_path)
        except FileNotFoundError:
            pass

    def serve_forever(self) -> None:
        # Tighten socket file permissions: owner-only.
        old_umask = os.umask(0o177)
        try:
            self._server = _ThreadingUnixServer(self.socket_path, _CageRequestHandler)
        finally:
            os.umask(old_umask)
        self._server.cage = self  # type: ignore[attr-defined]
        # Spin up webhook workers alongside the UDS server so the very
        # first check_payment already has delivery threads draining.
        self.start_webhook_sinks()
        # v0.11.0: spin up the revision-sync subscriber after webhooks so
        # any remote mutations buffered while we were booting get applied
        # before the first check_payment.
        self.start_revision_sync()
        self._server.serve_forever()

    def shutdown(self) -> None:
        if self._server is not None:
            self._server.shutdown()
            self._server.server_close()
        self.stop_webhook_sinks()
        self.stop_revision_sync()
        self._unlink_existing_socket()

    # ── v0.11.0 revision-sync lifecycle ────────────────────────────────────

    def start_revision_sync(self) -> None:
        """Start the revision-sync subscriber thread. Idempotent.

        Safe to call even when no sync adapter is wired; does nothing.
        """
        if self._revision_sync is None:
            return
        try:
            self._revision_sync.start()
        except Exception:  # noqa: BLE001 -- never block serve_forever startup
            logger.exception("revision_sync: subscriber failed to start")

    def stop_revision_sync(self) -> None:
        """Signal the revision-sync subscriber to exit. Bounded wait."""
        if self._revision_sync is None:
            return
        try:
            self._revision_sync.stop()
        except Exception:  # noqa: BLE001 -- never block shutdown
            logger.exception("revision_sync: subscriber failed to stop cleanly")

    # ── v0.10.0 webhook lifecycle ──────────────────────────────────────────

    def start_webhook_sinks(self) -> None:
        """Start each configured webhook worker. Idempotent."""
        for sink in self._webhook_sinks:
            sink.start()

    def stop_webhook_sinks(self) -> None:
        """Signal every webhook worker to exit. Best-effort, bounded wait."""
        for sink in self._webhook_sinks:
            try:
                sink.stop()
            except Exception:  # pragma: no cover - defensive, never fail shutdown
                logger.exception("webhook sink %s: shutdown raised", sink.name)

    @property
    def webhook_sinks(self) -> tuple[WebhookSink, ...]:
        return self._webhook_sinks

    def _emit_verdict_to_webhooks(self, verdict: dict[str, Any]) -> None:
        """Fan out a verdict to every configured sink. Never blocks.

        Called AFTER the response to the caller is already constructed so
        a slow or broken sink cannot add latency to the hot path. Any
        exception in a sink gets logged and swallowed — webhooks are
        opt-in observability, never a reason to reject an admission.
        """
        if not self._webhook_sinks:
            return
        for sink in self._webhook_sinks:
            try:
                sink.emit(verdict)
            except Exception:  # pragma: no cover - defensive
                logger.exception(
                    "webhook sink %s: emit raised for verdict", sink.name
                )

    # ── op dispatch ─────────────────────────────────────────────────────────

    #: Mutation / admin ops that go through the peer-auth gate. Read-only
    #: ops (status, health, inspect, check_payment, etc.) are excluded so
    #: clients without a credential slot can still query the cage — the
    #: auth gate exists to protect writes, not reads.
    _MUTATION_OPS: frozenset = frozenset({
        "declare_x402",
        "retract_x402",
        "add_invariant",
        "remove_invariant",
        "update_invariant",
        "propose_invariant",
        "approve_proposal",
        "reject_proposal",
        "create_branch",
        "checkout_branch",
        "merge_branch",
    })

    def dispatch(
        self,
        payload: dict[str, Any],
        *,
        peer: Optional[PeerCredentials] = None,
    ) -> dict[str, Any]:
        op = payload.get("op")
        # v0.22.0: peer-authentication gate. Runs before op dispatch so
        # mutation ops never touch the policy registry from an unauthenticated
        # peer. Read-only ops pass through unchanged.
        auth_error = self._check_peer_auth(op, payload, peer)
        if auth_error is not None:
            return auth_error
        if op == "status":
            return {"verdict": "ok"}
        if op == "health":
            return self._op_health()
        if op == "check_payment":
            return self._op_check_payment(payload)
        # v0.17.0: canonical decision primitive. Agent-friendly structured
        # response; runs the same pipeline as ``check_payment`` but emits
        # a :class:`PaymentDecision` shape.
        if op == "should_pay_x402":
            return self._op_should_pay_x402(payload)
        if op == "declare_x402":
            return self._op_declare_x402(payload)
        if op == "retract_x402":
            return self._op_retract_x402(payload)
        # v0.6.0 pointwise-revision mutation ops (Patch E):
        # v0.15.0 wraps the mutation rejects in the risk-dashboard log so
        # the /ui/safety "mutation failures" panel has a source of truth.
        if op == "add_invariant":
            resp = self._op_add_invariant(payload)
            self._record_mutation_failure(op=op, payload=payload, response=resp)
            return resp
        if op == "remove_invariant":
            resp = self._op_remove_invariant(payload)
            self._record_mutation_failure(op=op, payload=payload, response=resp)
            return resp
        if op == "update_invariant":
            resp = self._op_update_invariant(payload)
            self._record_mutation_failure(op=op, payload=payload, response=resp)
            return resp
        if op == "diff_revisions":
            return self._op_diff_revisions(payload)
        if op == "active_x402":
            return self._op_active_x402()
        if op == "revision_log":
            return self._op_revision_log()
        if op == "inspect_policy":
            return self._op_inspect_policy()
        if op == "explain_policy":
            return self._op_explain_policy(payload)
        # v0.18.0 NL round-trip: YAML-in, English-out.
        if op == "narrate_policy":
            return self._op_narrate_policy(payload)
        if op == "active_revision":
            return self._op_active_revision()
        # v0.7.0 branching revision graph ops.
        if op == "create_branch":
            return self._op_create_branch(payload)
        if op == "checkout_branch":
            return self._op_checkout_branch(payload)
        if op == "list_branches":
            return self._op_list_branches()
        if op == "merge_branch":
            return self._op_merge_branch(payload)
        if op == "current_branch":
            return self._op_current_branch()
        # v0.7.0 agent-proposes / human-approves queue:
        if op == "propose_invariant":
            resp = self._op_propose_invariant(payload)
            self._record_mutation_failure(op=op, payload=payload, response=resp)
            return resp
        if op == "approve_proposal":
            resp = self._op_approve_proposal(payload)
            # Approve wraps the admission verdict in an envelope; peek at
            # the nested payload so contradictions/inconclusives hit the
            # same dashboard bucket as direct add_invariant rejections.
            nested = resp.get("admission") if isinstance(resp, dict) else None
            if isinstance(nested, Mapping):
                self._record_mutation_failure(
                    op=op, payload=payload, response=nested,
                )
            self._record_mutation_failure(op=op, payload=payload, response=resp)
            return resp
        if op == "reject_proposal":
            return self._op_reject_proposal(payload)
        if op == "list_proposals":
            return self._op_list_proposals(payload)
        if op == "get_proposal":
            return self._op_get_proposal(payload)
        if op == "prover_metrics":
            return self._op_prover_metrics()
        if op == "recent_verdicts":
            return self._op_recent_verdicts(payload)
        if op == "shadow_summary":
            return self._op_shadow_summary(payload)
        # v0.9.0 signed audit export.
        if op == "export_audit":
            return self._op_export_audit()
        # v0.15.0 signed decision bundles — per-verdict audit artefact.
        if op == "build_decision_bundle":
            return self._op_build_decision_bundle(payload)
        # v0.17.0 per-decision explainer.
        if op == "explain_decision":
            return self._op_explain_decision(payload)
        # v0.10.0 policy replay / backtest.
        if op == "replay_policy":
            return self._op_replay_policy(payload)
        # v0.13.0 self-referential policy surface.
        if op == "self_ref_status":
            return self._op_self_ref_status()
        # v0.13.0 safety-comparison ops.
        if op == "safety_comparison":
            return self._op_safety_comparison(payload)
        if op == "risk_aggregate":
            return self._op_risk_aggregate(payload)
        # v0.14.0 explicit guarantees surface.
        if op == "guarantees":
            return self._op_guarantees()
        # v0.15.0 risk-dashboard read ops.
        if op == "mutation_failures":
            return self._op_mutation_failures(payload)
        if op == "active_constraints":
            return self._op_active_constraints()
        # v0.17.0 runtime-guard surface.
        if op == "runtime_state":
            return self._op_runtime_state(payload)
        return {"verdict": "error", "category": "unknown_op", "reason": f"op={op!r}"}

    # ── peer authentication (v0.22.0) ───────────────────────────────────────

    def _active_peer_auth_policy(self) -> Optional[PeerAuthenticationPolicy]:
        """Return the currently-admitted PeerAuthenticationPolicy, or None.

        Reads under the registry lock so a concurrent mutation cannot
        race the lookup. The policy lives alongside payment-rule
        invariants in ``self._x402_registry.invariants``.
        """
        with self._registry_lock:
            for inv in self._x402_registry.invariants:
                if isinstance(inv, PeerAuthenticationPolicy):
                    return inv
        return None

    def _active_actor_claim_signature_key_id(
        self,
        payload: Mapping[str, Any],
    ) -> Optional[str]:
        """Extract the signing-key id from a payload, if present.

        The wire contract: clients may attach ``actor_claim_signature_key_id``
        alongside ``actor_id`` when they have signed the actor claim. This
        daemon does not verify the signature itself — it only checks that
        the declared key id is in the admitted ``allowed_signing_keys``.
        Verification belongs behind a separate signed-envelope surface.
        """
        key_id = payload.get("actor_claim_signature_key_id")
        if isinstance(key_id, str) and key_id:
            return key_id
        return None

    def _check_peer_auth(
        self,
        op: Any,
        payload: Mapping[str, Any],
        peer: Optional[PeerCredentials],
    ) -> Optional[dict[str, Any]]:
        """Enforce the active PeerAuthenticationPolicy on mutation ops.

        Returns ``None`` when the op is permitted, or a structured error
        response when rejected. When no PeerAuthenticationPolicy is
        active, every op passes (pre-v0.22.0 behaviour is preserved so
        existing deployments are not broken by the upgrade).
        """
        if op not in self._MUTATION_OPS:
            return None
        policy = self._active_peer_auth_policy()
        if policy is None:
            return None
        # Kernel-verified uid check.
        peer_uid = peer.uid if peer is not None else None
        if not policy.authorises_connection(peer_uid):
            return {
                "verdict": "error",
                "category": "peer_auth_denied",
                "reason": (
                    "Peer uid not admitted by PeerAuthenticationPolicy."
                    if peer_uid is not None else
                    "Kernel-verified peer credentials required; none available."
                ),
                "peer_uid": peer_uid,
                "peer_source": peer.source if peer is not None else None,
            }
        # Actor-claim check: required if the policy asks for it, optional
        # otherwise. The policy's ``authorises_actor`` returns True when
        # either actor_id or a valid signing-key id matches.
        actor_id = payload.get("actor_id")
        if not isinstance(actor_id, str):
            actor_id = None
        key_id = self._active_actor_claim_signature_key_id(payload)
        actor_ok = policy.authorises_actor(
            actor_id=actor_id,
            actor_claim_signature_key_id=key_id,
        )
        if policy.require_signed_actor_claim and not (
            key_id is not None and key_id in policy.allowed_signing_keys
        ):
            return {
                "verdict": "error",
                "category": "peer_auth_denied",
                "reason": (
                    "PeerAuthenticationPolicy requires a signed actor "
                    "claim; actor_claim_signature_key_id missing or not "
                    "in allowed_signing_keys."
                ),
                "peer_uid": peer_uid,
                "peer_source": peer.source if peer is not None else None,
            }
        # When either path needs to be present (actor_id or key_id), enforce.
        if (
            policy.allowed_actor_claims or policy.allowed_signing_keys
        ) and not actor_ok:
            return {
                "verdict": "error",
                "category": "peer_auth_denied",
                "reason": (
                    "Actor claim not admitted: provide an actor_id in "
                    "allowed_actor_claims or an actor_claim_signature_key_id "
                    "in allowed_signing_keys."
                ),
                "peer_uid": peer_uid,
                "peer_source": peer.source if peer is not None else None,
            }
        return None

    def peer_evidence(
        self,
        peer: Optional[PeerCredentials],
    ) -> dict[str, Any]:
        """JSON-safe summary of peer creds for evidence records.

        Used by audit / decision-bundle paths that want to stamp
        ``peer_uid`` + ``peer_pid`` onto a record. Callers may pass
        ``None`` without special-casing; the return shape is stable.
        """
        if peer is None:
            return {
                "peer_uid": None,
                "peer_gid": None,
                "peer_pid": None,
                "peer_source": None,
            }
        return {
            "peer_uid": peer.uid,
            "peer_gid": peer.gid,
            "peer_pid": peer.pid,
            "peer_source": peer.source,
        }

    # ── health / status ─────────────────────────────────────────────────────

    def _op_health(self) -> dict[str, Any]:
        """Liveness + readiness snapshot suitable for load balancers."""
        with self._registry_lock:
            invariants_active = len(self._x402_registry.invariants)
            revisions = len(self._revision_log)
        history_size = self._history_store.count("permit")
        rejects_size = self._history_store.count("reject")
        resp: dict[str, Any] = {
            "verdict": "ok",
            "ready": True,
            "prover_backend": getattr(self._pattern_prover, "backend", "unknown"),
            "prover_mode": self._prover_mode,
            "tau_available": TauConsistencyProver.is_available(),
            "invariants_active": invariants_active,
            "revision_log_length": revisions,
            "payment_history_length": history_size,
            "reject_history_length": rejects_size,
            "history_backend": getattr(self._history_store, "backend", "unknown"),
        }
        # v0.11.0: surface revision-sync freshness so load balancers can
        # drop a replica whose subscriber has gone silent.
        if self._revision_sync is not None:
            resp["revision_sync"] = self._revision_sync.health()
        # v0.13.0: self-referential policy state so operators can tell at
        # a glance which providers are currently tightened and whether a
        # branch merge is in cooldown.
        resp["self_ref"] = self._self_ref_snapshot()
        return resp

    def _self_ref_snapshot(self) -> dict[str, Any]:
        """Compute the self-referential state summary for health + status.

        Returns:
          {
            "instability_active_providers": ["providerA", ...],
            "merge_cooldown_expires_unix": int | null,
          }

        The provider list reports every ``InstabilityGuard`` whose
        ``active_for`` returns True against the current reject history;
        the cooldown timestamp is the earliest active expiry across all
        branches (None when no cooldown is engaged). ``None`` renders as
        JSON null so clients can distinguish "feature off" from
        "currently quiet".
        """
        rejects = self._history_store.recent_oldest_first("reject")
        # Filter to PaymentIntent-shaped rows only; verdict-summary dicts
        # don't carry the fields InstabilityGuard inspects.
        from adapter.payment_intent_matcher import PaymentIntent as _PI
        reject_intents = tuple(
            r for r in rejects if isinstance(r, _PI)
        )
        now = int(time.time())
        with self._registry_lock:
            invariants = self._x402_registry.invariants
        active_providers: list[str] = []
        seen: set[str] = set()
        for inv in invariants:
            if not isinstance(inv, InstabilityGuard):
                continue
            if inv.provider in seen:
                continue
            if inv.active_for(reject_intents, now):
                active_providers.append(inv.provider)
                seen.add(inv.provider)
        cooldown_expiry: Optional[int] = None
        if self._merge_cooldown is not None:
            active_cooldowns = self._merge_cooldown.active_cooldowns(now)
            if active_cooldowns:
                cooldown_expiry = min(active_cooldowns.values())
        return {
            "instability_active_providers": active_providers,
            "merge_cooldown_expires_unix": cooldown_expiry,
        }

    def _op_self_ref_status(self) -> dict[str, Any]:
        """Detailed self-ref state for the ``self-ref status`` CLI.

        Unlike ``_self_ref_snapshot``, this surfaces per-guard config and
        the per-branch cooldown map so operators can diagnose a live
        incident. Shape:

          { "verdict": "ok",
            "now_unix": 170..,
            "instability_guards": [
                {"provider": "...", "active": True, "recent_rejects": N,
                 "reject_threshold": 3, "window_seconds": 60,
                 "tighten_to": "5", "currency": "USDC",
                 "recovery_seconds": 300},
                ...
            ],
            "merge_cooldown": {
                "enabled": bool, "cooldown_seconds": N,
                "active": {"<branch>": <expiry_unix>, ...}
            } }
        """
        now = int(time.time())
        rejects = self._history_store.recent_oldest_first("reject")
        from adapter.payment_intent_matcher import PaymentIntent as _PI
        reject_intents = tuple(
            r for r in rejects if isinstance(r, _PI)
        )
        with self._registry_lock:
            invariants = self._x402_registry.invariants
        guards = []
        for inv in invariants:
            if not isinstance(inv, InstabilityGuard):
                continue
            window_cutoff = now - inv.window_seconds
            provider_rejects = [
                r for r in reject_intents
                if r.provider == inv.provider
                and r.timestamp_unix >= window_cutoff
            ]
            guards.append({
                "provider": inv.provider,
                "active": inv.active_for(reject_intents, now),
                "recent_rejects": len(provider_rejects),
                "reject_threshold": inv.reject_threshold,
                "window_seconds": inv.window_seconds,
                "tighten_to": str(inv.tighten_to),
                "currency": inv.currency,
                "recovery_seconds": inv.recovery_seconds,
            })
        merge_info: dict[str, Any] = {
            "enabled": False,
            "cooldown_seconds": 0,
            "active": {},
        }
        if self._merge_cooldown is not None:
            merge_info["enabled"] = self._merge_cooldown.enabled
            merge_info["cooldown_seconds"] = self._merge_cooldown.cooldown_seconds
            merge_info["active"] = {
                k: int(v)
                for k, v in self._merge_cooldown.active_cooldowns(now).items()
            }
        return {
            "verdict": "ok",
            "now_unix": now,
            "instability_guards": guards,
            "merge_cooldown": merge_info,
        }

    # ── x402 payment path ──────────────────────────────────────────────────

    def _op_check_payment(self, payload: dict[str, Any]) -> dict[str, Any]:
        intent_dict = payload.get("intent")
        if not isinstance(intent_dict, dict):
            self._metrics.record_admission("reject")
            return {
                "verdict": "reject",
                "rule_id": "malformed_request",
                "reason_text": "check_payment requires an 'intent' object",
                "ttl_seconds": 5,
            }
        try:
            intent = _reconstruct_intent(intent_dict)
        except (InvalidPaymentIntent, ValueError, InvalidOperation, TypeError) as exc:
            self._metrics.record_admission("reject")
            return {
                "verdict": "reject",
                "rule_id": "invalid_payment_intent",
                "reason_text": f"Intent rejected at reconstruction: {exc}",
                "ttl_seconds": 5,
            }
        with self._registry_lock:
            registry = self._x402_registry
            # Patch 8: snapshot the active revision so the response can carry
            # MAC-bindable provenance. Grab under the same lock as the
            # registry read so verdict + revision are a coherent snapshot.
            active_revision = self._policy_revisions.latest
        # History reads are served from the store; an InMemoryHistoryStore's
        # snapshot is a plain tuple, and RedisHistoryStore's LRANGE is
        # atomic per-call. Either way, RollingWindowCap / RetryRateLimit
        # need oldest-first order.
        history = self._history_store.recent_oldest_first("permit")
        rejects = self._history_store.recent_oldest_first("reject")
        _t0 = time.perf_counter()
        violation = registry.check_payment(intent, history, rejects)
        # The hot path is pattern-only — it runs X402Registry.check_payment
        # in pure Python, never the Tau/z3 decision procedures. Record
        # under the ``pattern`` backend label so the histogram separates
        # hot-path latency from admission-time prover work below.
        self._metrics.observe_prover_latency(
            "pattern", max(time.perf_counter() - _t0, 0.0)
        )
        # v0.13.0 safety-comparison: the counterfactual is always "permit"
        # under the empty-registry baseline. Emitted on every response so
        # dashboards see the delta without a second round-trip; MAC-bound
        # inside the v2 envelope so the claim is tamper-evident.
        without_system = "permit"
        if violation is None:
            self._metrics.record_admission("permit")
            self._metrics.set_history_size(
                "permit", self._history_store.count("permit") + 1,
            )
            self._metrics.set_history_size(
                "verdict", self._history_store.count("verdict") + 1,
            )
            self._history_store.append(intent, kind="permit")
            # Patch 7 (v0.15.0): stamp a bundle_id + intent_hash onto every
            # verdict record so a decision bundle can later be assembled
            # from the stored state without re-scanning the full intent.
            # The full intent is stashed under ``_bundle_intent`` so the
            # bundle op can reconstruct the signed envelope byte-for-byte.
            import uuid as _uuid
            bundle_id = str(_uuid.uuid4())
            intent_hash_str = hash_intent(intent)
            verdict_record = {
                "verdict": "permit",
                "rule_id": None,
                "reason_text": None,
                "intent": _intent_summary(intent),
                "revision_id": (
                    active_revision.revision_id if active_revision else None
                ),
                "without_system": without_system,
                "mode": self._cage_mode.value,
                "bundle_id": bundle_id,
                "intent_hash": intent_hash_str,
                "_bundle_intent": _history_intent_to_json(intent),
                "_bundle_ttl_seconds": 30,
                "_bundle_issued_at_unix": int(time.time()),
                "_bundle_witness": None,
            }
            self._history_store.append(verdict_record, kind="verdict")
            response = self._build_check_payment_response(
                outcome="permit",
                rule_id=None,
                witness=None,
                reason_text=None,
                ttl_seconds=30,
                revision=active_revision,
                without_system=without_system,
            )
            # Webhook fan-out happens AFTER the response is composed so
            # any sink latency is off the hot path.
            self._emit_verdict_to_webhooks(verdict_record)
            return response
        # Violation path. In enforce mode the wire verdict is reject; in
        # shadow/advisory we short-circuit to a tagged permit below so
        # traffic keeps flowing. The full pattern check ran either way,
        # so we always have the rule_id + reason to report.
        if is_non_enforcing(self._cage_mode):
            return self._handle_shadow_rejection(
                intent=intent,
                violation=violation,
                active_revision=active_revision,
            )
        # Record rejects so RetryRateLimit can see them on subsequent calls.
        self._metrics.record_admission("reject")
        self._metrics.set_history_size(
            "reject", self._history_store.count("reject") + 1,
        )
        self._metrics.set_history_size(
            "verdict", self._history_store.count("verdict") + 1,
        )
        self._history_store.append(intent, kind="reject")
        import uuid as _uuid
        bundle_id = str(_uuid.uuid4())
        intent_hash_str = hash_intent(intent)
        verdict_record = {
            "verdict": "reject",
            "rule_id": violation.rule_id,
            "reason_text": violation.reason_text,
            "intent": _intent_summary(intent),
            "revision_id": (
                active_revision.revision_id if active_revision else None
            ),
            "without_system": without_system,
            "mode": self._cage_mode.value,
            # v0.15.0 decision-bundle fields (see permit path above).
            "bundle_id": bundle_id,
            "intent_hash": intent_hash_str,
            "_bundle_intent": _history_intent_to_json(intent),
            "_bundle_ttl_seconds": 30,
            "_bundle_issued_at_unix": int(time.time()),
            "_bundle_witness": violation.witness,
        }
        self._history_store.append(verdict_record, kind="verdict")
        response = self._build_check_payment_response(
            outcome="reject",
            rule_id=violation.rule_id,
            witness=violation.witness,
            reason_text=violation.reason_text,
            ttl_seconds=30,
            revision=active_revision,
            without_system=without_system,
        )
        # Webhook fan-out AFTER the response is composed so any sink
        # latency is off the hot path.
        self._emit_verdict_to_webhooks(verdict_record)
        return response

    def _handle_shadow_rejection(
        self,
        *,
        intent: PaymentIntent,
        violation: Any,
        active_revision: PolicyRevision | None,
    ) -> dict[str, Any]:
        """Shadow/advisory path: wire verdict is permit, but tag the would-reject.

        The admission pipeline already ran (same `registry.check_payment`
        call as enforce mode) so we have the full reject metadata. In
        shadow/advisory we:

        * Record a `permit` against the rolling-window history so
          RollingWindowCap / RetryRateLimit reflect what actually
          happened on the wire. Sending the intent to the `reject`
          stream would poison the rate-limit accounting — in enforce
          mode the next retry would back off, but the caller was
          actually permitted through so they have every right to
          retry.
        * Record a shadow-tagged verdict-summary row so the
          ``shadow-summary`` CLI + web UI can walk the would-have-
          rejected intents.
        * Bump the shadow/advisory counters (separate Prometheus
          surfaces per mode).
        * Build a permit response carrying shadow_would_reject +
          shadow_rule_id + shadow_reason_text so downstream signers
          can MAC-bind them into the v2 envelope.
        """
        provider = getattr(intent, "provider", "unknown") or "unknown"
        rule_id = violation.rule_id or "unknown"
        # Track the admission as a permit on the wire (matches what the
        # caller sees). The shadow-reject observability is on a
        # dedicated counter below.
        self._metrics.record_admission("permit")
        self._metrics.set_history_size(
            "permit", self._history_store.count("permit") + 1,
        )
        self._metrics.set_history_size(
            "verdict", self._history_store.count("verdict") + 1,
        )
        self._history_store.append(intent, kind="permit")
        # Bump the appropriate would-reject counter. Shadow and
        # advisory emit different Prometheus series so dashboards
        # distinguish trial-run from drift-detection.
        if self._cage_mode is CageMode.SHADOW:
            self._metrics.record_shadow_would_reject(rule_id)
        else:
            self._metrics.record_advisory_would_reject(rule_id, provider)
        # Shadow-tagged verdict-summary row. Wire outcome is permit;
        # shadow_rejected=True flags it for the summary CLI.
        import uuid as _uuid
        bundle_id = str(_uuid.uuid4())
        intent_hash_str = hash_intent(intent)
        verdict_record: dict[str, Any] = {
            "verdict": "permit",
            "rule_id": None,
            "reason_text": None,
            "intent": _intent_summary(intent),
            "revision_id": (
                active_revision.revision_id if active_revision else None
            ),
            "mode": self._cage_mode.value,
            # v0.15.0 decision-bundle fields.
            "bundle_id": bundle_id,
            "intent_hash": intent_hash_str,
            "_bundle_intent": _history_intent_to_json(intent),
            "_bundle_ttl_seconds": 30,
            "_bundle_issued_at_unix": int(time.time()),
            "_bundle_witness": violation.witness,
            # v0.13.0 shadow fields on the verdict-summary row so
            # HistoryStore.recent(..., shadow_only=True) can find it
            # and the ``shadow-summary`` CLI can build reports.
            "shadow_rejected": True,
            "shadow_rule_id": rule_id,
            "shadow_reason_text": violation.reason_text,
            "shadow_witness": violation.witness,
            "shadow_provider": provider,
            "shadow_amount": str(getattr(intent, "amount", "") or ""),
            "shadow_currency": getattr(intent, "currency", "") or "",
            "shadow_timestamp_unix": int(
                getattr(intent, "timestamp_unix", 0) or 0
            ),
        }
        self._history_store.append(verdict_record, kind="verdict")
        response = self._build_check_payment_response(
            outcome="permit",
            rule_id=None,
            witness=None,
            reason_text=None,
            ttl_seconds=30,
            revision=active_revision,
        )
        # Surface the shadow tags on the wire so mediate() / x402_client
        # can rebuild ShadowInfo and MAC-bind them into the envelope.
        response["shadow_would_reject"] = True
        response["shadow_rule_id"] = rule_id
        response["shadow_reason_text"] = violation.reason_text
        response["mode"] = self._cage_mode.value
        self._emit_verdict_to_webhooks(verdict_record)
        return response

    # ── v0.17.0 should_pay_x402: canonical decision primitive ────────────

    def _op_should_pay_x402(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Canonical decision layer. Runs ``check_payment`` internally.

        Shape::

            { "op": "should_pay_x402",
              "intent": { ... PaymentIntent wire shape ... } }

        Returns a :class:`PaymentDecision` wire dict, always. On
        malformed intent, emits a ``cage_unavailable``/``policy_inconclusive``
        record with ``allowed=False`` so the caller never gets a silent
        permit through this path.

        This op is read-only in the same sense as ``check_payment``:
        it appends to history + records metrics (because it IS a
        ``check_payment`` under the hood), but it never mutates the
        registry, revision log, or approval queue.
        """
        from adapter.decision_schema import (
            PaymentDecision,
            RiskPrevented,
            next_action_for,
            rule_id_to_reason,
        )

        # Run the existing admission pipeline. We dispatch directly to
        # ``_op_check_payment`` so semantics stay identical (history
        # append, shadow/advisory handling, webhook fan-out).
        raw = self._op_check_payment(payload)

        # Error envelopes from the existing op: malformed request,
        # invalid payment intent, etc. Map onto a fail-closed decision
        # with reason ``policy_inconclusive`` — we cannot form an
        # opinion on an unparseable intent.
        raw_verdict = raw.get("verdict")
        if raw_verdict not in ("permit", "reject"):
            reason = rule_id_to_reason(str(raw.get("rule_id") or "malformed_request"))
            decision = PaymentDecision(
                allowed=False,
                reason=reason,
                rule_id=raw.get("rule_id"),
                reason_text=str(
                    raw.get("reason_text")
                    or raw.get("reason")
                    or "invalid request"
                ),
                cage_mode=self._cage_mode.value,  # type: ignore[arg-type]
                next_action=next_action_for(reason, None),
                signed_envelope={},
            )
            return {"verdict": "ok", "decision": decision.to_wire()}

        # Reconstruct the intent for signing + risk estimation. Safe to
        # re-parse because ``_op_check_payment`` already validated it.
        intent_dict = payload.get("intent") or {}
        try:
            intent = _reconstruct_intent(intent_dict)
        except (InvalidPaymentIntent, ValueError, InvalidOperation, TypeError) as exc:
            reason = rule_id_to_reason("invalid_payment_intent")
            decision = PaymentDecision(
                allowed=False,
                reason=reason,
                rule_id="invalid_payment_intent",
                reason_text=f"Intent rejected at reconstruction: {exc}",
                cage_mode=self._cage_mode.value,  # type: ignore[arg-type]
                next_action=next_action_for(reason, None),
                signed_envelope={},
            )
            return {"verdict": "ok", "decision": decision.to_wire()}

        allowed = raw_verdict == "permit"
        wire_rule_id = raw.get("rule_id")
        reason_text = raw.get("reason_text")
        shadow_would_reject = bool(raw.get("shadow_would_reject"))
        shadow_rule_id = raw.get("shadow_rule_id")
        shadow_reason_text = raw.get("shadow_reason_text")

        # In shadow/advisory, the wire outcome is always permit but the
        # agent should still see the shadow-reject metadata. We surface
        # it on the decision as ``risk_prevented`` + use the shadow
        # rule_id to infer the reason taxonomy. The reason stays
        # ``allowed`` because the wire outcome IS allowed; the field
        # that tells the agent "the cage WOULD have rejected" is
        # ``risk_prevented``.
        if allowed and shadow_would_reject and shadow_rule_id:
            reason = "allowed"
            effective_rule_id = shadow_rule_id
            shadow_reason_canonical = rule_id_to_reason(str(shadow_rule_id))
        elif allowed:
            reason = "allowed"
            effective_rule_id = None
            shadow_reason_canonical = None
        else:
            reason = rule_id_to_reason(
                str(wire_rule_id) if wire_rule_id is not None else None
            )
            effective_rule_id = wire_rule_id
            shadow_reason_canonical = None

        # Compute retry_after_seconds for transient-backoff denies.
        # RetryRateLimit stores the gap in the witness; parse it out
        # when present. For other reasons we leave it None — the agent
        # is not given a false retry hint.
        retry_after = self._compute_retry_after(
            wire_rule_id=str(wire_rule_id) if wire_rule_id else None,
            witness=raw.get("witness"),
            intent=intent,
        )

        # Compute risk_prevented: populated on deny or on
        # shadow-would-reject. Uses the safety_comparison machinery to
        # keep the "with system vs without" counterfactual consistent
        # with the existing dashboards.
        risk_prevented: Optional[Any] = None
        if (not allowed) or shadow_would_reject:
            risk_prevented = self._risk_prevented_for_intent(
                intent=intent,
                wire_rule_id=str(effective_rule_id) if effective_rule_id else None,
            )

        # Proof_mode collapses the revision's proof_backend into the
        # canonical {pattern, tau, z3, hybrid} set the agent reasons over.
        proof_mode: Optional[str] = None
        proof_backend = raw.get("proof_backend")
        proof_strength = raw.get("proof_strength")
        policy_revision_id = raw.get("policy_revision_id")
        if proof_backend:
            proof_mode = _classify_backend_label(str(proof_backend))

        # Sign the envelope so the decision is offline-verifiable.
        # When no HMAC secret is configured (dev mode), we emit an
        # empty envelope — this matches the existing behaviour where
        # the daemon does not sign on the hot path. The x402_client /
        # saas layer handles signing for production deployments.
        signed_envelope: dict[str, Any] = {}
        try:
            signed_envelope = self._build_signed_envelope_for_decision(
                intent=intent,
                raw=raw,
            )
        except Exception:  # noqa: BLE001 — envelope is optional on this path
            logger.exception("should_pay_x402: signed envelope build raised")
            signed_envelope = {}

        # Reason chosen above; choose next_action from it + retry hint.
        # Shadow/advisory with would-reject still returns proceed on the
        # wire (the cage permitted) but the agent SHOULD read
        # risk_prevented to decide whether to honour the permit.
        next_action = next_action_for(reason, retry_after)  # type: ignore[arg-type]

        # If we are in a non-enforcing mode and the shadow metadata
        # indicates a would-reject, override next_action to surface
        # the shadow reason's natural action. This keeps shadow useful
        # as a dry-run without flipping the wire outcome.
        if allowed and shadow_would_reject and shadow_reason_canonical:
            next_action = next_action_for(
                shadow_reason_canonical, retry_after,
            )
            # Don't change ``reason`` itself — it stays "allowed" to
            # preserve wire truth — but next_action carries the action
            # the operator likely wants (e.g. ``adjust_policy``).

        from adapter.decision_schema import PaymentDecision  # noqa: F811 (rebind for clarity)

        decision = PaymentDecision(
            allowed=allowed,
            reason=reason,  # type: ignore[arg-type]
            rule_id=effective_rule_id if effective_rule_id is not None else None,
            reason_text=(
                reason_text if reason_text is not None else shadow_reason_text
            ),
            retry_after_seconds=retry_after,
            effective_policy_revision=(
                str(policy_revision_id) if policy_revision_id else None
            ),
            proof_mode=proof_mode,  # type: ignore[arg-type]
            proof_backend=str(proof_backend) if proof_backend else None,
            proof_strength=str(proof_strength) if proof_strength else None,
            cage_mode=self._cage_mode.value,  # type: ignore[arg-type]
            risk_prevented=risk_prevented,
            next_action=next_action,
            signed_envelope=signed_envelope,
        )
        return {"verdict": "ok", "decision": decision.to_wire()}

    # ── should_pay_x402 helpers ─────────────────────────────────────────

    def _compute_retry_after(
        self,
        *,
        wire_rule_id: str | None,
        witness: str | None,
        intent: "PaymentIntent",
    ) -> int | None:
        """Derive retry_after_seconds for transient-backoff denies.

        For ``retry_rate_limit`` we parse the ``witness`` ("gap=Xs,min=Ys")
        to compute the remaining wait. For ``rolling_window_cap_*`` we
        report the wait to fall out of the oldest filtered window. For
        other rule_ids we return ``None`` — no natural retry hint.
        """
        if wire_rule_id is None:
            return None
        # RetryRateLimit exposes gap/min in the witness; remaining wait
        # is ``min - gap``. Bounded non-negative.
        if wire_rule_id == "retry_rate_limit" and witness:
            try:
                parts = dict(
                    token.split("=", 1)
                    for token in witness.split(",")
                    if "=" in token
                )
                gap = int(str(parts.get("gap", "0")).rstrip("s") or "0")
                mn = int(str(parts.get("min", "0")).rstrip("s") or "0")
                remaining = max(mn - gap, 0)
                return remaining if remaining > 0 else None
            except (ValueError, AttributeError):
                return None
        # RollingWindowCap: we can estimate retry-after as "time until
        # the oldest in-window event falls out". Walk the relevant
        # history and compute it. Cheap because the history cap is
        # bounded (10k default) and we break on the first match.
        if wire_rule_id.startswith("rolling_window_cap_"):
            try:
                return self._retry_after_for_rolling_cap(
                    wire_rule_id, intent,
                )
            except Exception:  # noqa: BLE001 — defensive
                return None
        return None

    def _retry_after_for_rolling_cap(
        self,
        wire_rule_id: str,
        intent: "PaymentIntent",
    ) -> int | None:
        """Best-effort retry-after for rolling-window-cap rejects.

        Reads the matching ``RollingWindowCap`` off the active registry,
        walks the permit history oldest-first for the earliest entry
        in the current window, and returns seconds-until-it-falls-out.
        Returns None when no matching invariant is wired.
        """
        with self._registry_lock:
            invariants = tuple(self._x402_registry.invariants)
        group = wire_rule_id[len("rolling_window_cap_"):]
        for inv in invariants:
            if not isinstance(inv, RollingWindowCap):
                continue
            if inv.group_by != group:
                continue
            window = int(inv.window_seconds)
            history = self._history_store.recent_oldest_first("permit")
            # Filter to the same group the invariant bucketed by.
            if group == "provider":
                relevant = [
                    p for p in history
                    if getattr(p, "provider", None) == intent.provider
                    and intent.timestamp_unix - p.timestamp_unix < window
                ]
            elif group == "counterparty":
                relevant = [
                    p for p in history
                    if getattr(p, "counterparty", None) == intent.counterparty
                    and intent.timestamp_unix - p.timestamp_unix < window
                ]
            else:
                relevant = [
                    p for p in history
                    if intent.timestamp_unix - p.timestamp_unix < window
                ]
            if not relevant:
                return None
            oldest = min(p.timestamp_unix for p in relevant)
            remaining = oldest + window - intent.timestamp_unix
            return remaining if remaining > 0 else None
        return None

    def _risk_prevented_for_intent(
        self,
        *,
        intent: "PaymentIntent",
        wire_rule_id: str | None,
    ) -> Any:
        """Populate :class:`RiskPrevented` for a deny / shadow-would-reject.

        Uses the ``safety_comparison`` machinery so the numbers match
        the existing dashboards. Returns ``None`` when the machinery
        cannot form an estimate (never raises — risk_prevented is
        optional).
        """
        from adapter.decision_schema import RiskPrevented
        from adapter.safety_comparison import compare_verdict

        try:
            with self._registry_lock:
                registry = self._x402_registry
            history = self._history_store.recent_oldest_first("permit")
            rejects = self._history_store.recent_oldest_first("reject")
            history_pi = tuple(
                h for h in history if isinstance(h, PaymentIntent)
            )
            rejects_pi = tuple(
                r for r in rejects if isinstance(r, PaymentIntent)
            )
            report = compare_verdict(intent, registry, history_pi, rejects_pi)
        except Exception:  # noqa: BLE001 — defensive, never fail the decision
            logger.exception("should_pay_x402: risk_prevented compute failed")
            return None

        # The comparison baseline ("without system") is always permit
        # today, so any with_system=reject report carries the intent's
        # own amount as the prevented value. We also attribute a
        # source based on the rule family so the agent can branch on
        # density estimates vs pure rule_composition claims.
        source = "rule_composition"
        if wire_rule_id == "retry_rate_limit":
            source = "retry_density"
        elif wire_rule_id and wire_rule_id.startswith("spending_cap"):
            source = "spend_velocity"
        elif wire_rule_id == "max_per_call":
            source = "spend_velocity"

        risk_amount = report.risk_amount
        risk_currency = report.risk_currency
        if risk_amount is None:
            # Fall back to the intent's own amount — conservative but
            # correct: a reject prevents exactly this intent's spend.
            risk_amount = intent.amount
            risk_currency = intent.currency
        return RiskPrevented(
            estimated_extra_calls_blocked=None,
            estimated_extra_spend_blocked=risk_amount,
            currency=risk_currency,
            source=source,  # type: ignore[arg-type]
        )

    def _build_signed_envelope_for_decision(
        self,
        *,
        intent: "PaymentIntent",
        raw: Mapping[str, Any],
    ) -> dict[str, Any]:
        """Build an offline-verifiable v2 envelope for the decision.

        When no HMAC secret is configured, returns an empty dict —
        signing is optional on this path; the x402_client wraps the
        daemon for production deployments. When a secret IS wired,
        we reproduce the same v2 envelope the mediator would have
        signed so the agent can verify the decision offline without
        a second round-trip.
        """
        if self._hmac_secret is None:
            return {}
        from adapter.verdict_signer import ShadowInfo, sign

        outcome = raw.get("verdict")
        if outcome not in ("permit", "reject"):
            return {}
        verdict = Verdict(
            outcome=outcome,
            rule_id=raw.get("rule_id"),
            witness=raw.get("witness"),
            reason_text=raw.get("reason_text"),
            ttl_seconds=int(raw.get("ttl_seconds", 30)),
        )
        # Reconstruct a minimal PolicyRevision from the response fields
        # (same shape the client SDK uses).
        rev_id = raw.get("policy_revision_id")
        revision: Optional[PolicyRevision] = None
        if rev_id:
            revision = PolicyRevision(
                revision_id=str(rev_id),
                invariants=tuple(),
                proof_backend=str(raw.get("proof_backend") or "unknown"),
                proof_strength=str(raw.get("proof_strength") or "unknown"),
                prover_mode=str(raw.get("prover_mode") or "compat"),
                compile_hash=(
                    str(raw["compile_hash"])
                    if raw.get("compile_hash") is not None
                    else None
                ),
                fragment_version=None,
                tau_backend_version=None,
                admitted_at_unix=0,
                predecessor_revision_id=None,
            )
        shadow: Optional[ShadowInfo] = None
        mode = raw.get("mode")
        if mode:
            shadow = ShadowInfo(
                mode=str(mode),
                would_reject=bool(raw.get("shadow_would_reject", False)),
                rule_id=(
                    str(raw["shadow_rule_id"])
                    if raw.get("shadow_rule_id") is not None
                    else None
                ),
                reason_text=(
                    str(raw["shadow_reason_text"])
                    if raw.get("shadow_reason_text") is not None
                    else None
                ),
            )
        without_system = raw.get("without_system")
        env = sign(
            verdict,
            intent,
            self._hmac_secret,
            revision=revision,
            without_system=(
                without_system
                if without_system in ("permit", "reject")
                else None
            ),
            shadow=shadow,
        )
        return json.loads(env.to_json())

    def _build_check_payment_response(
        self,
        *,
        outcome: str,
        rule_id: str | None,
        witness: str | None,
        reason_text: str | None,
        ttl_seconds: int,
        revision: PolicyRevision | None,
        without_system: str | None = None,
    ) -> dict[str, Any]:
        """Compose the check_payment response, folding in v2 provenance.

        Backward-compat: when no PolicyRevision is active (fresh daemon or
        pattern-only v1-unaware caller) we emit the legacy flat shape. When
        a revision IS active, we also surface its provenance fields so the
        x402_client can opt into v2 envelope signing without another round-trip.

        v0.13.0 also surfaces ``without_system`` — the counterfactual
        verdict under the empty-registry baseline (the "without the cage"
        view). Always populated so dashboards see the comparison on every
        /v1/check response; MAC-bound inside the v2 envelope so the claim
        is tamper-evident.
        """
        resp: dict[str, Any] = {
            "verdict": outcome,
            "rule_id": rule_id,
            "witness": witness,
            "reason_text": reason_text,
            "ttl_seconds": ttl_seconds,
        }
        if revision is not None:
            resp["policy_revision_id"] = revision.revision_id
            resp["proof_backend"] = revision.proof_backend
            resp["proof_strength"] = revision.proof_strength
            resp["prover_mode"] = revision.prover_mode
            resp["compile_hash"] = revision.compile_hash
        if without_system is not None:
            resp["without_system"] = without_system
        # v0.13.0: always surface the cage mode so the client SDK can
        # MAC-bind it, and an auditor can read which mode issued any
        # verdict from the signed envelope.
        resp["mode"] = self._cage_mode.value
        return resp

    def _op_declare_x402(self, payload: dict[str, Any]) -> dict[str, Any]:
        inv = self._build_x402_invariant(payload)
        if inv is None:
            return {"verdict": "error", "category": "bad_invariant"}
        # v0.14.0: declare-time governance gates (strict-mode requirement
        # + temporal bounds) fire before the prover chain so misconfigured
        # rules never reach admission.
        declare_error = self._governance_check_declare(
            inv, mode=self._prover_mode,
        )
        if declare_error is not None:
            return declare_error
        return self._apply_revision(
            lambda reg: reg.declare(inv),
            kind=payload.get("kind"),
            op_name="updated",
            delta_added=(inv,),
            delta_removed=(),
        )

    def _op_retract_x402(self, payload: dict[str, Any]) -> dict[str, Any]:
        inv = self._build_x402_invariant(payload)
        if inv is None:
            return {"verdict": "error", "category": "bad_invariant"}
        return self._apply_revision(
            lambda reg: reg.retract(inv),
            kind=payload.get("kind"),
            op_name="retracted",
            delta_added=(),
            delta_removed=(inv,),
        )

    # ── v0.6.0 pointwise-revision mutation ops (Patch E) ───────────────────

    def _op_add_invariant(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Semantic alias of declare_x402 with delta semantics.

        Payload:
          { "op": "add_invariant",
            "invariant": { "kind": "...", ... },
            "actor_id":  "<optional governance id>" }

        When the daemon is configured with `require_human_approval=True`,
        this op flips into the agent-proposes path: we queue a Proposal
        and return a 202-like envelope carrying `proposal_id`. A human
        reviewer then calls `approve_proposal` to complete the admission.

        v0.14.0: when a governance policy is loaded, the invariant is
        checked against axes 3+4 (prover-mode requirement + temporal
        bounds) BEFORE admission. If the payload carries an ``actor_id``
        the authorization gate (axis 1) also runs, and a violation short-
        circuits whether or not `require_human_approval` is set.
        """
        entry = payload.get("invariant") or {}
        inv = self._build_x402_invariant(entry)
        if inv is None:
            return {"verdict": "error", "category": "bad_invariant"}
        # Governance axis 1 — actor authorization. Only enforced when the
        # caller opted in by sending an actor_id; legacy callers without
        # the field keep working unchanged.
        actor_id = payload.get("actor_id")
        if actor_id is not None:
            actor_id = str(actor_id).strip() or None
        if actor_id is not None:
            verdict = self._governance_check_propose(actor_id, inv)
            if verdict is not None and not verdict.allowed:
                return {
                    "verdict": "error",
                    "category": "governance_violation",
                    "reason": verdict.reason,
                }
        # Governance axes 3+4 — strict-mode requirement + temporal bounds.
        declare_error = self._governance_check_declare(
            inv, mode=self._prover_mode,
        )
        if declare_error is not None:
            return declare_error
        if self._require_human_approval:
            submitted_by = str(
                payload.get("submitted_by") or entry.get("submitted_by") or "agent"
            )
            with self._registry_lock:
                active = self._policy_revisions.latest
                diff_from = active.revision_id if active is not None else None
            try:
                proposal = self._approval_queue.submit(
                    submitted_by=submitted_by,
                    invariants=(inv,),
                    diff_from_revision=diff_from,
                    actor_id=actor_id,
                )
            except ApprovalQueueError as exc:
                return {
                    "verdict": "error",
                    "category": "bad_proposal",
                    "reason": str(exc),
                }
            self._update_proposal_gauges()
            # Surface the governance threshold so the caller doesn't have
            # to re-derive it to know when admission will unlock.
            required_reviewers = 1
            if self._governance is not None:
                required_reviewers = self._governance.get_requirement(
                    type(inv).__name__
                ).min_reviewers
            return {
                "verdict": "pending_approval",
                "status_code": 202,
                "proposal_id": proposal.proposal_id,
                "submitted_by": proposal.submitted_by,
                "submitted_at": proposal.submitted_at,
                "diff_from_revision": proposal.diff_from_revision,
                "kind": entry.get("kind"),
                "required_reviewers": required_reviewers,
            }
        return self._apply_revision(
            lambda reg: reg.declare(inv),
            kind=entry.get("kind"),
            op_name="updated",
            delta_added=(inv,),
            delta_removed=(),
        )

    def _op_remove_invariant(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Remove an invariant. Alias of retract_x402 with delta framing."""
        entry = payload.get("invariant") or {}
        inv = self._build_x402_invariant(entry)
        if inv is None:
            return {"verdict": "error", "category": "bad_invariant"}
        return self._apply_revision(
            lambda reg: reg.retract(inv),
            kind=entry.get("kind"),
            op_name="retracted",
            delta_added=(),
            delta_removed=(inv,),
        )

    def _op_update_invariant(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Atomic retract+declare pair.

        Payload:
          { "op": "update_invariant",
            "old": { "kind": "...", ... },   # invariant to remove
            "new": { "kind": "...", ... } }  # invariant to add
        Applied as a single revision: both the removal and the addition
        must compose consistently with the rest of the registry for the
        mutation to be admitted. If either the intermediate (after
        removal) or the final (after addition) state would fail admission
        under strict mode, the whole update is rejected and the registry
        stays at the pre-update state.
        """
        old = payload.get("old") or {}
        new = payload.get("new") or {}
        old_inv = self._build_x402_invariant(old)
        new_inv = self._build_x402_invariant(new)
        if old_inv is None or new_inv is None:
            return {"verdict": "error", "category": "bad_invariant"}
        # v0.14.0 governance axes 3+4 apply to the NEW invariant only:
        # retraction of old can't violate strict-mode / temporal bounds
        # (we're removing, not declaring) while the new invariant is what
        # ends up admitted.
        declare_error = self._governance_check_declare(
            new_inv, mode=self._prover_mode,
        )
        if declare_error is not None:
            return declare_error
        return self._apply_revision(
            lambda reg: reg.retract(old_inv).declare(new_inv),
            kind=new.get("kind"),
            op_name="updated",
            delta_added=(new_inv,),
            delta_removed=(old_inv,),
        )

    def _op_diff_revisions(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Compute the delta between two revisions from the persisted log.

        Payload:
          { "op": "diff_revisions",
            "a": "<revision_id>",
            "b": "<revision_id>" }
        Returns:
          { "verdict": "ok",
            "a": {...}, "b": {...},
            "added": [serialized invariants only in b],
            "removed": [serialized invariants only in a],
            "backend_changed": bool,
            "mode_changed": bool }
        """
        a_id = payload.get("a")
        b_id = payload.get("b")
        if not a_id or not b_id:
            return {"verdict": "error", "category": "bad_payload",
                    "reason": "diff_revisions requires 'a' and 'b' revision IDs"}
        with self._registry_lock:
            log = tuple(self._policy_revisions)
        by_id = {r.revision_id: r for r in log}
        a = by_id.get(a_id)
        b = by_id.get(b_id)
        if a is None or b is None:
            return {"verdict": "error", "category": "unknown_revision",
                    "reason": f"revision(s) not found: "
                              f"{'a' if a is None else ''} {'b' if b is None else ''}".strip()}
        from adapter.policy_revision import _serialize_invariant
        a_set = {(_serialize_invariant(inv)["class_name"],
                  repr(inv)) for inv in a.invariants}
        b_set = {(_serialize_invariant(inv)["class_name"],
                  repr(inv)) for inv in b.invariants}
        only_a = a_set - b_set
        only_b = b_set - a_set
        return {
            "verdict": "ok",
            "a": {"revision_id": a.revision_id, "depth": a.revision_depth,
                  "backend": a.proof_backend, "mode": a.prover_mode},
            "b": {"revision_id": b.revision_id, "depth": b.revision_depth,
                  "backend": b.proof_backend, "mode": b.prover_mode},
            "added": [{"class": c, "repr_key": r} for c, r in sorted(only_b)],
            "removed": [{"class": c, "repr_key": r} for c, r in sorted(only_a)],
            "backend_changed": a.proof_backend != b.proof_backend,
            "mode_changed": a.prover_mode != b.prover_mode,
        }

    def _apply_revision(
        self,
        mutate: Any,
        kind: str | None,
        op_name: str,
        delta_added: tuple[Invariant, ...] = (),
        delta_removed: tuple[Invariant, ...] = (),
    ) -> dict[str, Any]:
        """Thin wrapper around ``apply_revision_delta_strict``.

        v0.13.0 moved the admission ladder into
        ``adapter.mutation_safety.apply_revision_delta_strict`` so every
        mutation op routes through one audited entry point that emits the
        strict-mutation-contract metadata (``mutation_risk``,
        ``affected_scope``, ``would_break_without_proof``). The chain of
        pattern → Tau → z3 + mode-specific strict-rejection semantics is
        unchanged; it now lives in one place and is covered by the
        ``tests/test_mutation_safety.py`` acceptance suite.

        The hybrid prover path is still its own method so cross-fragment
        composition stays consistent with v0.8.0 wiring (hybrid prover
        owns its own pattern+Tau+z3 composition and does not fit cleanly
        onto the separate-prover ProverChain shape).
        """
        _apply_t0 = time.perf_counter()
        with self._registry_lock:
            old_reg = self._x402_registry
            predecessor = (
                self._revision_log[-1].config_hash if self._revision_log else None
            )
        candidate_reg = mutate(old_reg)

        # v0.19.0 Guaranteed Mode: when the daemon is configured with
        # ``prover_mode="guaranteed"``, every admission goes through
        # GuaranteedProver (totality gate + pure Tau) BEFORE the standard
        # chain. Anything that falls outside the Guaranteed language tier
        # surfaces as the canonical brief envelope shape. Success threads
        # through to the standard chain so the audit trail / revision log /
        # metrics stay identical to Flexible Mode — Guaranteed Mode is a
        # *stricter* admission, not a different persistence pipeline.
        if self._guaranteed_prover is not None:
            gm_reject = self._guaranteed_admission_check(
                candidate_reg=candidate_reg,
                old_reg=old_reg,
                kind=kind,
            )
            if gm_reject is not None:
                return gm_reject

        # v0.8.0 hybrid path: delegates to the hybrid prover in one call.
        if self._hybrid_prover is not None:
            return self._apply_revision_hybrid(
                candidate_reg=candidate_reg,
                old_reg=old_reg,
                predecessor=predecessor,
                kind=kind,
                op_name=op_name,
                delta_added=delta_added,
                delta_removed=delta_removed,
            )

        # v0.13.0 central mutation contract: every non-hybrid mutation op
        # goes through one audited entry point. Registry CAS / revision
        # logging stays in this method so the daemon owns the lock +
        # audit-trail commit; the strict function is a pure function of
        # (current_registry, delta, provers).
        chain = ProverChain(
            pattern=self._pattern_prover,
            tau=self._tau_prover if self._prover_mode != "compat" else None,
            z3=self._z3_incremental_prover,
            mode=self._prover_mode,
        )
        delta = RevisionDelta(added=tuple(delta_added), removed=tuple(delta_removed))
        safety = apply_revision_delta_strict(
            current_registry=old_reg, delta=delta, provers=chain,
            predecessor_hash=predecessor,
        )
        if safety.outcome == "rejected":
            if safety.contradiction is not None:
                left = safety.contradiction.conflicting_invariants[0] \
                    if safety.contradiction.conflicting_invariants else ""
                right = safety.contradiction.conflicting_invariants[1] \
                    if len(safety.contradiction.conflicting_invariants) > 1 else ""
                return self._reject_payload(
                    verdict="contradiction",
                    kind=kind,
                    reason=safety.contradiction.unsat_explanation,
                    witness={"left": left, "right": right},
                    backend=safety.contradiction.backend,
                    active=len(old_reg.invariants),
                    report=safety.contradiction,
                    mutation_risk=safety.mutation_risk,
                    affected_scope=safety.affected_scope,
                    would_break_without_proof=safety.would_break_without_proof,
                )
            if safety.inconclusive is not None:
                return self._reject_payload(
                    verdict="inconclusive",
                    kind=kind,
                    reason=safety.inconclusive.reason,
                    witness={
                        "category": safety.inconclusive.category,
                        "backend": safety.inconclusive.backend,
                    },
                    backend=safety.inconclusive.backend,
                    active=len(old_reg.invariants),
                    extra={"category": safety.inconclusive.category},
                    report=safety.inconclusive,
                    mutation_risk=safety.mutation_risk,
                    affected_scope=safety.affected_scope,
                    would_break_without_proof=safety.would_break_without_proof,
                )
            # Shouldn't happen — a rejected MutationResult always carries
            # exactly one of contradiction / inconclusive. Fail loudly
            # rather than silently admitting.
            return self._reject_payload(
                verdict="error", kind=kind,
                reason="mutation rejected without structured report",
                witness={}, backend="unknown",
                active=len(old_reg.invariants),
                mutation_risk=safety.mutation_risk,
                affected_scope=safety.affected_scope,
                would_break_without_proof=safety.would_break_without_proof,
            )

        # Admitted. Thread the token through the existing CAS + revision
        # log commit so audit trail semantics match v0.12.x.
        assert safety.candidate_registry is not None
        assert safety.proof_token is not None
        final_token = safety.proof_token
        candidate_reg = safety.candidate_registry

        # Step: registry CAS + audit-log commit. Registry reference only
        # flips here; safety.candidate_registry is the frozen result of
        # the atomic admission path above.
        with self._registry_lock:
            current_predecessor = (
                self._revision_log[-1].config_hash if self._revision_log else None
            )
            if current_predecessor != predecessor:
                return {
                    "verdict": "conflict",
                    "reason": "concurrent revision committed first; retry",
                    "active_invariants": len(self._x402_registry.invariants),
                }
            from adapter.policy_revision import _serialize_invariant
            prev = self._policy_revisions.latest
            predecessor_revision_id = prev.revision_id if prev is not None else None
            prev_invs = prev.invariants if prev is not None else ()
            old_set = {(type(i).__name__, repr(i)): i for i in prev_invs}
            new_set = {(type(i).__name__, repr(i)): i for i in candidate_reg.invariants}
            added_invs = [new_set[k] for k in new_set.keys() - old_set.keys()]
            removed_invs = [old_set[k] for k in old_set.keys() - new_set.keys()]
            delta_payload = {
                "added": [_serialize_invariant(i) for i in added_invs],
                "removed": [_serialize_invariant(i) for i in removed_invs],
            }
            depth = (prev.revision_depth + 1) if prev is not None else 0
            from dataclasses import replace
            active_branch = self._policy_revisions.active_branch
            revision = replace(
                PolicyRevision.from_proof_token(
                    token=final_token,
                    invariants=candidate_reg.invariants,
                    predecessor_revision_id=predecessor_revision_id,
                ),
                delta=delta_payload,
                revision_depth=depth,
                branch=active_branch,
                mutation_risk=safety.mutation_risk,
                affected_scope=dict(safety.affected_scope),
            )
            # v0.14.0: append FIRST so a cross-revision violation can bail
            # out before we mutate the active registry or revision log.
            # ``append`` raises :class:`CrossRevisionRejected` on violation
            # and leaves the log untouched.
            try:
                self._policy_revisions.append(revision)
            except CrossRevisionRejected as exc:
                return self._reject_payload(
                    verdict="reject",
                    kind=kind,
                    reason=str(exc),
                    witness={"violations": [
                        v.to_dict() for v in exc.result.violations
                    ]},
                    backend="cross-revision-validator",
                    active=len(old_reg.invariants),
                    extra={
                        "category": "cross_revision_violation",
                        "violations": [
                            v.to_dict() for v in exc.result.violations
                        ],
                    },
                    mutation_risk=safety.mutation_risk,
                    affected_scope=safety.affected_scope,
                    would_break_without_proof=safety.would_break_without_proof,
                )
            self._x402_registry = candidate_reg
            self._revision_log = self._revision_log + (final_token,)
        self._metrics.record_revision()
        self._metrics.observe_prover_latency(
            _classify_backend_label(final_token.backend),
            max(time.perf_counter() - _apply_t0, 0.0),
        )
        self._update_proposal_gauges()
        self._update_branch_gauges()
        self._update_z3_gauges()
        self._publish_revision_to_sync(revision)
        return {
            "verdict": op_name,
            "kind": kind,
            "active_invariants": len(candidate_reg.invariants),
            "proof_token": final_token.to_dict(),
            "revision_id": revision.revision_id,
            "revision_depth": revision.revision_depth,
            "delta": revision.delta,
            # v0.13.0 strict mutation contract metadata.
            "mutation_risk": safety.mutation_risk,
            "affected_scope": dict(safety.affected_scope),
            "would_break_without_proof": safety.would_break_without_proof,
        }

    def _publish_revision_to_sync(self, revision: PolicyRevision) -> None:
        """Fan a newly-admitted PolicyRevision out to the sync channel.

        Safe to call when no sync adapter is wired (no-op). Publisher
        internals already swallow wire errors, but we wrap once more
        here so any *bug* in the adapter can't wedge the hot path.
        """
        if self._revision_sync is None:
            return
        try:
            self._revision_sync.publish_revision(revision)
        except Exception:  # noqa: BLE001 -- fail-open contract
            logger.exception("revision_sync: publish_revision raised")

    def _apply_revision_hybrid(
        self,
        *,
        candidate_reg: Any,
        old_reg: Any,
        predecessor: str | None,
        kind: str | None,
        op_name: str,
        delta_added: tuple[Invariant, ...],
        delta_removed: tuple[Invariant, ...],
    ) -> dict[str, Any]:
        _hybrid_t0 = time.perf_counter()
        """Admission path when a ``HybridProver`` is wired (v0.8.0).

        The hybrid prover composes pattern + Tau(v1) + z3(v2) plus the
        cross-fragment projection in one call. Behaviour mirrors
        ``_apply_revision``:

          * Contradiction (any fragment) → REJECT, registry unchanged.
          * InconclusiveProof → REJECT under strict mode, annotated
            admission otherwise.
          * ProofToken → admit under the registry-lock-guarded CAS.
        """
        assert self._hybrid_prover is not None
        # v0.19.0 Guaranteed Mode: hybrid admissions also ride the
        # GuaranteedProver pre-gate when configured, so the "only Tau,
        # no fallbacks" contract holds even when a hybrid prover is wired.
        if self._guaranteed_prover is not None:
            gm_reject = self._guaranteed_admission_check(
                candidate_reg=candidate_reg,
                old_reg=old_reg,
                kind=kind,
            )
            if gm_reject is not None:
                return gm_reject
        # v0.13.0: compute the mutation-safety projection up-front so
        # every return path carries the strict-mutation-contract fields,
        # including the hybrid-prover-specific contradictions and
        # inconclusive cases.
        from adapter.mutation_safety import (
            RevisionDelta as _RevisionDelta,
            compute_affected_scope as _compute_affected_scope,
            classify_risk as _classify_risk,
            would_break_without_proof as _would_break_without_proof,
        )
        _delta_value = _RevisionDelta(
            added=tuple(delta_added), removed=tuple(delta_removed),
        )
        _scope_hybrid = _compute_affected_scope(_delta_value, old_reg)
        _would_break_hybrid = _would_break_without_proof(
            _delta_value, old_reg, self._pattern_prover,
        )
        result = self._hybrid_prover.prove_delta(
            added=tuple(delta_added),
            removed=tuple(delta_removed),
            predecessor_hash=predecessor,
            full_current_set=candidate_reg.invariants,
        )
        if isinstance(result, Contradiction):
            return self._reject_payload(
                verdict="contradiction",
                kind=kind,
                reason=result.reason,
                witness={"left": result.left, "right": result.right},
                backend=result.backend,
                active=len(old_reg.invariants),
                report=_contradiction_to_report(result),
                mutation_risk=_classify_risk(
                    _delta_value, _scope_hybrid,
                    _contradiction_to_report(result),
                    current_registry=old_reg,
                ),
                affected_scope=_scope_hybrid,
                would_break_without_proof=_would_break_hybrid,
            )
        if isinstance(result, InconclusiveProof):
            if self._prover_mode == "strict":
                return self._reject_payload(
                    verdict="inconclusive",
                    kind=kind,
                    reason=result.reason,
                    witness={"category": result.category, "backend": result.backend},
                    backend=result.backend,
                    active=len(old_reg.invariants),
                    extra={"category": result.category},
                    report=_inconclusive_to_report(result),
                    mutation_risk=_classify_risk(
                        _delta_value, _scope_hybrid,
                        _inconclusive_to_report(result),
                        current_registry=old_reg,
                    ),
                    affected_scope=_scope_hybrid,
                    would_break_without_proof=_would_break_hybrid,
                )
            # non-strict: synthesise a pattern token carrying the
            # inconclusive annotation so the admission flow can proceed.
            fallback = self._pattern_prover.prove(
                invariants=candidate_reg.invariants,
                predecessor_hash=predecessor,
            )
            if isinstance(fallback, Contradiction):
                return self._reject_payload(
                    verdict="contradiction",
                    kind=kind,
                    reason=fallback.reason,
                    witness={"left": fallback.left, "right": fallback.right},
                    backend=fallback.backend,
                    active=len(old_reg.invariants),
                    report=_contradiction_to_report(fallback),
                    mutation_risk=_classify_risk(
                        _delta_value, _scope_hybrid,
                        _contradiction_to_report(fallback),
                        current_registry=old_reg,
                    ),
                    affected_scope=_scope_hybrid,
                    would_break_without_proof=_would_break_hybrid,
                )
            final_token = _relabel_strength(
                fallback,  # type: ignore[arg-type]
                f"hybrid+{result.category}",
            )
        else:
            final_token = result

        if final_token.prover_mode != self._prover_mode:
            final_token = _with_mode(final_token, self._prover_mode)

        with self._registry_lock:
            current_predecessor = (
                self._revision_log[-1].config_hash if self._revision_log else None
            )
            if current_predecessor != predecessor:
                return {
                    "verdict": "conflict",
                    "reason": "concurrent revision committed first; retry",
                    "active_invariants": len(self._x402_registry.invariants),
                }
            from adapter.policy_revision import _serialize_invariant
            prev = self._policy_revisions.latest
            predecessor_revision_id = prev.revision_id if prev is not None else None
            prev_invs = prev.invariants if prev is not None else ()
            old_set = {(type(i).__name__, repr(i)): i for i in prev_invs}
            new_set = {(type(i).__name__, repr(i)): i for i in candidate_reg.invariants}
            added = [new_set[k] for k in new_set.keys() - old_set.keys()]
            removed = [old_set[k] for k in old_set.keys() - new_set.keys()]
            delta = {
                "added": [_serialize_invariant(i) for i in added],
                "removed": [_serialize_invariant(i) for i in removed],
            }
            depth = (prev.revision_depth + 1) if prev is not None else 0
            from dataclasses import replace
            active_branch = self._policy_revisions.active_branch
            _risk_hybrid = _classify_risk(
                _delta_value, _scope_hybrid, None, current_registry=old_reg,
            )
            revision = replace(
                PolicyRevision.from_proof_token(
                    token=final_token,
                    invariants=candidate_reg.invariants,
                    predecessor_revision_id=predecessor_revision_id,
                ),
                delta=delta,
                revision_depth=depth,
                branch=active_branch,
                mutation_risk=_risk_hybrid,
                affected_scope=dict(_scope_hybrid),
            )
            # v0.14.0: cross-revision admission must run BEFORE the
            # registry + token log mutate. See the legacy-path comment.
            try:
                self._policy_revisions.append(revision)
            except CrossRevisionRejected as exc:
                return self._reject_payload(
                    verdict="reject",
                    kind=kind,
                    reason=str(exc),
                    witness={"violations": [
                        v.to_dict() for v in exc.result.violations
                    ]},
                    backend="cross-revision-validator",
                    active=len(old_reg.invariants),
                    extra={
                        "category": "cross_revision_violation",
                        "violations": [
                            v.to_dict() for v in exc.result.violations
                        ],
                    },
                    mutation_risk=_risk_hybrid,
                    affected_scope=_scope_hybrid,
                    would_break_without_proof=_would_break_hybrid,
                )
            self._x402_registry = candidate_reg
            self._revision_log = self._revision_log + (final_token,)
        self._metrics.record_revision()
        self._metrics.observe_prover_latency(
            "hybrid", max(time.perf_counter() - _hybrid_t0, 0.0),
        )
        self._update_proposal_gauges()
        self._update_branch_gauges()
        self._update_z3_gauges()
        # v0.11.0: fan-out mirror of the legacy path above.
        self._publish_revision_to_sync(revision)
        return {
            "verdict": op_name,
            "kind": kind,
            "active_invariants": len(candidate_reg.invariants),
            "proof_token": final_token.to_dict(),
            "revision_id": revision.revision_id,
            "revision_depth": revision.revision_depth,
            "delta": revision.delta,
            # v0.13.0 strict mutation contract metadata.
            "mutation_risk": _risk_hybrid,
            "affected_scope": dict(_scope_hybrid),
            "would_break_without_proof": _would_break_hybrid,
        }

    def _record_mutation_failure(
        self,
        *,
        op: str,
        payload: Mapping[str, Any],
        response: Mapping[str, Any],
    ) -> None:
        """Append a ``MutationFailureEntry`` to the risk-dashboard ring buffer.

        Safe to call with a ``response`` that represents a success —
        ``classify_rejection`` returns ``None`` for success or untracked
        categories and the append is skipped. Actor id is read from the
        original payload (the daemon's governance surface already lifts
        it off the wire before strict-mutation-contract checks run).
        """
        category = _classify_rejection(response)
        if category is None:
            return
        actor_id = payload.get("actor_id") if isinstance(payload, Mapping) else None
        if actor_id is not None:
            actor_id_str: str | None = str(actor_id).strip() or None
        else:
            actor_id_str = None
        reason = str(response.get("reason") or response.get("category") or "")
        mutation_risk = response.get("mutation_risk")
        if mutation_risk is not None:
            mutation_risk = str(mutation_risk)
        affected_scope = response.get("affected_scope") or {}
        if not isinstance(affected_scope, Mapping):
            affected_scope = {}
        entry = MutationFailureEntry(
            timestamp_unix=int(time.time()),
            op=str(op),
            actor_id=actor_id_str,
            category=category,
            reason=reason,
            mutation_risk=mutation_risk,
            affected_scope=dict(affected_scope),
        )
        try:
            self._mutation_failure_log.append(entry)
        except Exception:  # noqa: BLE001 - dashboard must never wedge ops
            logger.exception("mutation_failure_log: append raised; dropped entry")

    def _guaranteed_admission_check(
        self,
        *,
        candidate_reg: Any,
        old_reg: Any,
        kind: str | None,
    ) -> dict[str, Any] | None:
        """Run the Guaranteed-Mode gate over a candidate registry.

        Returns ``None`` when the policy is admissible under the Guaranteed
        language tier (caller proceeds with the standard admission chain)
        or a reject payload shaped per the v0.19.0 product-switch brief:

            {
              "allowed": False,
              "reason": "unsupported_for_guaranteed_mode",
              "details": {
                "unsupported_rule": "<class_name>",
                "unsupported_variant": "<variant_tag_or_null>",
                "language_tier_version": "<semver>"
              },
              ... (standard reject envelope fields)
            }

        ``allowed``/``reason``/``details`` are the brief's canonical shape;
        the remaining fields come from :meth:`_reject_payload` so callers
        that read ``verdict``/``witness``/``active_invariants``/etc. keep
        working.

        Any non-``UNSUPPORTED_FOR_GUARANTEED_MODE`` GuaranteedFailure (e.g.
        totality failure, Tau timeout, prover internal error) is also
        rejected, but the envelope's ``reason`` reflects the actual
        failure code so auditors can distinguish categories.
        """
        assert self._guaranteed_prover is not None
        from adapter.guaranteed_errors import (
            GuaranteedFailure,
            GuaranteedFailureCode,
        )
        from adapter.guaranteed_language import GuaranteedLanguage

        language_tier_version = str(
            GuaranteedLanguage.describe().get("language_version", "unknown")
        )

        invariants = tuple(candidate_reg.invariants)

        # Up-front language-tier screen. Failing fast here lets us surface
        # the specific rule + variant tag without invoking Tau — which is
        # what the brief's envelope shape depends on.
        for inv in invariants:
            ok, code = GuaranteedLanguage.is_supported(inv)
            if not ok:
                variant = _guaranteed_classify_variant(inv)
                return self._guaranteed_reject(
                    rule_name=type(inv).__name__,
                    variant=variant,
                    language_tier_version=language_tier_version,
                    reason_code=(code or GuaranteedFailureCode.UNSUPPORTED_FOR_GUARANTEED_MODE),
                    message=(
                        f"{type(inv).__name__} is not admissible under the "
                        f"Guaranteed language tier v{language_tier_version}"
                    ),
                    kind=kind,
                    old_reg=old_reg,
                )

        # Full GuaranteedProver run — totality + Tau. Any decisive fail is
        # a reject; a consistent result threads through to the standard
        # chain (which then runs its own pattern/Tau/z3 ladder and emits
        # the audit record).
        try:
            result = self._guaranteed_prover.prove(invariants)
        except Exception as exc:  # noqa: BLE001
            # Prover blew up before returning a structured failure. Fail
            # closed with an internal-error reason rather than admitting.
            logger.exception("guaranteed_prover.prove raised")
            return self._guaranteed_reject(
                rule_name="(policy)",
                variant=None,
                language_tier_version=language_tier_version,
                reason_code=GuaranteedFailureCode.TAU_PROVER_INTERNAL_ERROR,
                message=f"Guaranteed prover raised {type(exc).__name__}: {exc}",
                kind=kind,
                old_reg=old_reg,
            )
        if isinstance(result, GuaranteedFailure):
            # Find the first unsupported invariant in the policy so the
            # envelope can name it concretely even when the failure
            # originated from totality / compile stages.
            rule_name, variant = _guaranteed_failure_target(invariants, result)
            return self._guaranteed_reject(
                rule_name=rule_name,
                variant=variant,
                language_tier_version=language_tier_version,
                reason_code=result.code,
                message=result.message,
                kind=kind,
                old_reg=old_reg,
                failure_context=dict(result.context) if result.context else None,
            )
        # GuaranteedProofResult - admissible. Thread through.
        return None

    def _guaranteed_reject(
        self,
        *,
        rule_name: str,
        variant: str | None,
        language_tier_version: str,
        reason_code: Any,
        message: str,
        kind: str | None,
        old_reg: Any,
        failure_context: dict | None = None,
    ) -> dict[str, Any]:
        """Build the brief's canonical guaranteed-mode rejection envelope.

        Wraps :meth:`_reject_payload` so downstream consumers that read
        the v0.13.x rejection shape still see ``verdict``/``witness``/
        ``active_invariants``. The brief's top-level fields (``allowed``,
        ``reason``, ``details``) are layered on top.
        """
        from adapter.guaranteed_errors import GuaranteedFailureCode

        # The canonical ``reason`` name is the lowercase
        # ``unsupported_for_guaranteed_mode`` variant from the brief;
        # other failure codes report their own lower-case code (matches
        # the audit-export expectation).
        if reason_code is GuaranteedFailureCode.UNSUPPORTED_FOR_GUARANTEED_MODE:
            brief_reason = "unsupported_for_guaranteed_mode"
        else:
            brief_reason = reason_code.value.lower()

        details: dict[str, Any] = {
            "unsupported_rule": rule_name,
            "unsupported_variant": variant,
            "language_tier_version": language_tier_version,
        }
        if failure_context:
            details["failure_context"] = failure_context
        # Build the underlying envelope first (keeps metrics / legacy
        # reader paths working) then layer on the brief's ``allowed`` /
        # ``reason`` / ``details`` on top. We do NOT call ``_reject_payload``
        # in order to avoid double-counting the admission histogram as a
        # generic "reject"; Guaranteed-Mode refusals are a distinct class
        # and counted through the admission metrics already.
        payload: dict[str, Any] = {
            "verdict": "reject",
            "kind": kind,
            "reason": brief_reason,
            "witness": {},
            "backend": "guaranteed-mode",
            "active_invariants": len(old_reg.invariants),
            "prover_mode": self._prover_mode,
            "allowed": False,
            "details": details,
            "category": "unsupported_for_guaranteed_mode"
            if reason_code is GuaranteedFailureCode.UNSUPPORTED_FOR_GUARANTEED_MODE
            else reason_code.value.lower(),
            "message": message,
        }
        self._metrics.record_admission("reject")
        return payload

    def _reject_payload(
        self,
        *,
        verdict: str,
        kind: str | None,
        reason: str,
        witness: dict,
        backend: str,
        active: int,
        extra: dict | None = None,
        report: ContradictionReport | InconclusiveReport | None = None,
        mutation_risk: str | None = None,
        affected_scope: dict | None = None,
        would_break_without_proof: bool | None = None,
    ) -> dict[str, Any]:
        """Build a rejection payload.

        Additive-schema guarantee: callers that only read the flat
        ``verdict`` / ``reason`` / ``witness`` / ``backend`` / ``kind`` /
        ``active_invariants`` / ``prover_mode`` fields continue to work
        unchanged. When ``report`` is supplied it is serialised under the
        ``report`` key as an additional richer representation.

        v0.13.0: strict-mutation-contract metadata (``mutation_risk``,
        ``affected_scope``, ``would_break_without_proof``) is surfaced on
        every rejection routed through the central mutation path. Older
        callers that ignore these keys continue to work.
        """
        payload = {
            "verdict": verdict,
            "kind": kind,
            "reason": reason,
            "witness": witness,
            "backend": backend,
            "active_invariants": active,
            "prover_mode": self._prover_mode,
        }
        if extra:
            payload.update(extra)
        if report is not None:
            payload["report"] = report.to_dict()
        if mutation_risk is not None:
            payload["mutation_risk"] = mutation_risk
        if affected_scope is not None:
            payload["affected_scope"] = dict(affected_scope)
        if would_break_without_proof is not None:
            payload["would_break_without_proof"] = would_break_without_proof
        # v0.9.0: admission rejections at declare-time count toward the
        # admission histogram too. ``inconclusive`` is its own label so
        # SREs can alert on a rising inconclusive rate (indicates Tau
        # timing out rather than a genuine contradiction).
        if verdict == "inconclusive":
            self._metrics.record_admission("inconclusive")
        else:
            self._metrics.record_admission("reject")
        return payload

    def _op_revision_log(self) -> dict[str, Any]:
        """Return the ordered audit trail of proof tokens for this session."""
        with self._registry_lock:
            log = self._revision_log
        return {
            "verdict": "ok",
            "length": len(log),
            "revisions": [t.to_dict() for t in log],
        }

    def _op_recent_verdicts(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Return the most recent verdicts (permit + reject interleaved).

        Paginated via ``limit`` (default 50, max 500) and ``offset`` (from the
        *newest* end, default 0). The snapshot is taken under the registry
        lock so counts and entries stay coherent across interleaved mutations.
        Entries are the compact summary produced by ``_intent_summary`` — no
        raw metadata, no request ids.
        """
        limit_raw = payload.get("limit", 50)
        offset_raw = payload.get("offset", 0)
        try:
            limit = int(limit_raw)
            offset = int(offset_raw)
        except (TypeError, ValueError):
            return {
                "verdict": "error",
                "category": "bad_pagination",
                "reason": "limit/offset must be integers",
            }
        if limit < 1 or limit > 500:
            return {
                "verdict": "error",
                "category": "bad_pagination",
                "reason": "limit must be between 1 and 500",
            }
        if offset < 0:
            return {
                "verdict": "error",
                "category": "bad_pagination",
                "reason": "offset must be >= 0",
            }
        # v0.8.0: the store exposes newest-first windowed reads directly so
        # we don't have to pull the whole ring buffer here (matters for the
        # Redis backend where 10k rows is a noticeable LRANGE).
        total = self._history_store.count("verdict")
        window = self._history_store.recent(
            kind="verdict", limit=limit, offset=offset,
        )
        return {
            "verdict": "ok",
            "total": total,
            "limit": limit,
            "offset": offset,
            "entries": [dict(e) for e in window],
        }

    # ── v0.13.0 shadow / advisory summary ───────────────────────────────────

    def _op_shadow_summary(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Aggregate shadow-tagged verdict rows into an operator-readable report.

        Payload:
            { "op": "shadow_summary",
              "window_seconds": 86400,   # optional; default None = all time
              "limit": 1000              # optional; default 1000, max 10_000
            }

        Returns:
            {
                "verdict": "ok",
                "mode": <current cage mode>,
                "window_seconds": <echoed>,
                "total_shadow_rejected": int,
                "by_rule": [ {rule_id, count, sample_reason} ],
                "by_provider": [ {provider, count} ],
                "aggregate_would_block_value": {currency: str(total)},
                "entries": [ <newest-first shadow-tagged verdict rows> ],
            }

        Non-mutating; reads only from the HistoryStore's verdict stream.
        An operator running in shadow/advisory uses this to decide
        whether the rules are safe enough to flip to enforce.
        """
        window_raw = payload.get("window_seconds")
        limit_raw = payload.get("limit", 1000)
        try:
            limit = int(limit_raw)
        except (TypeError, ValueError):
            return {
                "verdict": "error",
                "category": "bad_pagination",
                "reason": "limit must be an integer",
            }
        if limit < 1 or limit > 10_000:
            return {
                "verdict": "error",
                "category": "bad_pagination",
                "reason": "limit must be between 1 and 10000",
            }
        window_seconds: int | None
        if window_raw is None:
            window_seconds = None
        else:
            try:
                window_seconds = int(window_raw)
            except (TypeError, ValueError):
                return {
                    "verdict": "error",
                    "category": "bad_pagination",
                    "reason": "window_seconds must be an integer",
                }
            if window_seconds < 0:
                return {
                    "verdict": "error",
                    "category": "bad_pagination",
                    "reason": "window_seconds must be >= 0",
                }
        # Fetch newest-first shadow-tagged rows; the store's shadow_only
        # flag does the filtering so Redis backends don't drag the full
        # ring buffer through JSON decoding twice.
        rows = self._history_store.recent(
            kind="verdict", limit=limit, offset=0, shadow_only=True,
        )
        # Filter by window. Each row carries shadow_timestamp_unix (the
        # intent timestamp at the moment of the would-be reject).
        if window_seconds is not None and rows:
            newest_ts = max(
                int(r.get("shadow_timestamp_unix", 0) or 0)
                for r in rows if isinstance(r, dict)
            )
            cutoff = max(newest_ts - window_seconds, 0)
            rows = [
                r for r in rows
                if int(
                    r.get("shadow_timestamp_unix", 0) or 0
                ) >= cutoff
            ]
        # Aggregate by rule_id, by provider, and across currency groups.
        by_rule: dict[str, dict[str, Any]] = {}
        by_provider: dict[str, int] = {}
        by_currency: dict[str, Decimal] = {}
        for row in rows:
            if not isinstance(row, dict):
                continue
            rule_id = str(row.get("shadow_rule_id") or "unknown")
            bucket = by_rule.setdefault(
                rule_id, {"rule_id": rule_id, "count": 0, "sample_reason": None},
            )
            bucket["count"] += 1
            if bucket["sample_reason"] is None and row.get("shadow_reason_text"):
                bucket["sample_reason"] = str(row["shadow_reason_text"])
            provider = str(row.get("shadow_provider") or "unknown")
            by_provider[provider] = by_provider.get(provider, 0) + 1
            amount_str = str(row.get("shadow_amount") or "") or "0"
            currency = str(row.get("shadow_currency") or "") or "UNKNOWN"
            try:
                by_currency[currency] = by_currency.get(currency, Decimal("0")) + Decimal(amount_str)
            except (InvalidOperation, ValueError):
                # Malformed amount — skip aggregation but keep the row.
                continue
        return {
            "verdict": "ok",
            "mode": self._cage_mode.value,
            "window_seconds": window_seconds,
            "total_shadow_rejected": len(rows),
            "by_rule": sorted(
                by_rule.values(),
                key=lambda r: r["count"],
                reverse=True,
            ),
            "by_provider": sorted(
                (
                    {"provider": p, "count": c}
                    for p, c in by_provider.items()
                ),
                key=lambda r: r["count"],
                reverse=True,
            ),
            "aggregate_would_block_value": {
                c: str(v) for c, v in by_currency.items()
            },
            "entries": [dict(r) for r in rows],
        }

    # ── v0.10.0 policy replay / backtest ────────────────────────────────────

    def _op_replay_policy(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Re-admit recent history against a candidate policy, in-memory.

        Payload::

            { "op": "replay_policy",
              "invariants": [ {...}, ... ],   # candidate set (declare-style)
              "window_seconds": 86400,         # optional; filters history by timestamp
              "max_entries": 1000              # optional; default 10_000, hard cap 10_000
            }

        Behaviour:
          * Reads the ``permit`` + ``reject`` streams as a frozen snapshot.
          * Filters by ``window_seconds`` (counting from the newest entry's
            timestamp, not wall-clock — replay is deterministic regardless
            of when it's called).
          * Caps entries at ``max_entries`` (keeps NEWEST).
          * Reconstructs an ephemeral ``X402Registry`` from the candidate
            and runs ``adapter.replay.replay_against_candidate`` against
            the current registry.

        Daemon state is NEVER mutated. The call is a pure read of the
        history store plus one in-process evaluation loop.
        """
        from adapter.replay import (
            DEFAULT_MAX_ENTRIES,
            replay_against_candidate,
        )

        raw_invariants = payload.get("invariants")
        if not isinstance(raw_invariants, list):
            return {
                "verdict": "error",
                "category": "bad_payload",
                "reason": "replay_policy requires an 'invariants' list",
            }

        # Build candidate invariants up-front. A single malformed entry
        # aborts the whole replay — partial candidate policies are a
        # correctness hazard (the remaining rules would decide against an
        # incomplete policy). Report the offending index so the caller can
        # fix the config without guessing.
        candidate: list[Invariant] = []
        for idx, entry in enumerate(raw_invariants):
            if not isinstance(entry, dict):
                return {
                    "verdict": "error",
                    "category": "bad_invariant",
                    "reason": f"entry #{idx} is not a mapping",
                }
            inv = self._build_x402_invariant(entry)
            if inv is None:
                return {
                    "verdict": "error",
                    "category": "bad_invariant",
                    "reason": f"entry #{idx} could not be built: {entry!r}",
                }
            candidate.append(inv)

        # Parse + validate the cost-guard knobs. max_entries is hard-capped
        # at DEFAULT_MAX_ENTRIES (10_000) regardless of what the caller
        # asks for — a runaway replay would scale linearly in both history
        # size AND candidate size, so we refuse to go past the ring-buffer
        # cap.
        try:
            max_entries = int(payload.get("max_entries", DEFAULT_MAX_ENTRIES))
        except (TypeError, ValueError):
            return {
                "verdict": "error",
                "category": "bad_payload",
                "reason": "max_entries must be an integer",
            }
        if max_entries < 1:
            return {
                "verdict": "error",
                "category": "bad_payload",
                "reason": "max_entries must be >= 1",
            }
        if max_entries > DEFAULT_MAX_ENTRIES:
            max_entries = DEFAULT_MAX_ENTRIES

        window_raw = payload.get("window_seconds")
        window_seconds: Optional[int] = None
        if window_raw is not None:
            try:
                window_seconds = int(window_raw)
            except (TypeError, ValueError):
                return {
                    "verdict": "error",
                    "category": "bad_payload",
                    "reason": "window_seconds must be an integer",
                }
            if window_seconds < 0:
                return {
                    "verdict": "error",
                    "category": "bad_payload",
                    "reason": "window_seconds must be >= 0",
                }

        # Snapshot the current registry and history under the registry lock
        # so declare / check_payment mutations happening in parallel can't
        # slide the "before" ground truth out from under us. The snapshot
        # is a tuple so the lock can be released before the O(N × M) loop.
        with self._registry_lock:
            current_invariants = tuple(self._x402_registry.invariants)
        # History reads are already atomic per-call on both backends.
        history_all = list(
            self._history_store.recent_oldest_first("permit")
        )
        # The permit stream is the only one replay re-admits. Rejects don't
        # get a "what would the candidate do with this" replay because
        # re-admitting a reject and re-rejecting it adds no information;
        # operators who want retroactive-reject-review should use audit-
        # export + offline analysis.
        history_payments = [
            h for h in history_all if isinstance(h, PaymentIntent)
        ]

        # Filter by window_seconds relative to the newest entry's timestamp
        # so replay is deterministic across re-runs. Wall-clock filtering
        # would produce different windows on every call even against a
        # frozen history.
        if window_seconds is not None and history_payments:
            newest_ts = history_payments[-1].timestamp_unix
            cutoff = newest_ts - window_seconds
            history_payments = [
                p for p in history_payments if p.timestamp_unix >= cutoff
            ]

        # Apply the newest-N cap. The history is oldest-first, so "newest N"
        # is the tail slice.
        if len(history_payments) > max_entries:
            history_payments = history_payments[-max_entries:]

        result = replay_against_candidate(
            history=history_payments,
            current_invariants=current_invariants,
            candidate_invariants=tuple(candidate),
        )

        # Wire envelope: ``verdict: "ok"`` at the top level matches other
        # read-only ops (recent_verdicts, inspect_policy, prover_metrics);
        # the ReplayResult rides inside so callers can ignore the envelope
        # when they only want the structured diff.
        wire = result.to_wire()
        wire["verdict"] = "ok"
        wire["window_seconds"] = window_seconds
        wire["max_entries"] = max_entries
        wire["history_available"] = self._history_store.count("permit")
        return wire

    # ── v0.13.0 safety-comparison ops ──────────────────────────────────────

    def _op_safety_comparison(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Run compare_verdict against the active registry for one intent.

        Payload::

            { "op": "safety_comparison",
              "intent": { ... PaymentIntent wire shape ... } }

        Returns the :class:`ComparisonReport` wire dict. Never mutates
        state — this is a pure read, suitable for dashboards and SaaS
        "what would happen if..." previews.
        """
        from adapter.safety_comparison import compare_verdict

        intent_dict = payload.get("intent")
        if not isinstance(intent_dict, dict):
            return {
                "verdict": "error",
                "category": "bad_payload",
                "reason": "safety_comparison requires an 'intent' object",
            }
        try:
            intent = _reconstruct_intent(intent_dict)
        except (InvalidPaymentIntent, ValueError, InvalidOperation, TypeError) as exc:
            return {
                "verdict": "error",
                "category": "invalid_payment_intent",
                "reason": f"Intent rejected at reconstruction: {exc}",
            }
        with self._registry_lock:
            registry = self._x402_registry
        history = self._history_store.recent_oldest_first("permit")
        rejects = self._history_store.recent_oldest_first("reject")
        # Filter the histories down to PaymentIntents only — the verdict
        # stream is stored alongside but compare_verdict reasons over
        # PaymentIntent objects. Redis-backed stores can return dicts on
        # degraded rows; be defensive rather than assume shape.
        history_pi = tuple(h for h in history if isinstance(h, PaymentIntent))
        rejects_pi = tuple(r for r in rejects if isinstance(r, PaymentIntent))
        report = compare_verdict(intent, registry, history_pi, rejects_pi)
        return {
            "verdict": "ok",
            "report": report.to_wire(),
        }

    def _op_risk_aggregate(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Aggregate the risk the cage prevented over a rolling window.

        Payload::

            { "op": "risk_aggregate",
              "window_seconds": 86400,   # optional, 0 = all history
              "top_n": 5                 # optional, default 5 }

        Returns the :class:`RiskAggregate` wire dict. Pure read; never
        mutates state. Uses the same snapshot semantics as
        ``replay_policy`` (window filtering is relative to the newest
        entry's timestamp, not wall-clock, so repeated calls against a
        frozen store are deterministic).
        """
        from adapter.safety_comparison import aggregate_risk_prevented

        try:
            window_seconds = int(payload.get("window_seconds", 0) or 0)
        except (TypeError, ValueError):
            return {
                "verdict": "error",
                "category": "bad_payload",
                "reason": "window_seconds must be an integer",
            }
        if window_seconds < 0:
            return {
                "verdict": "error",
                "category": "bad_payload",
                "reason": "window_seconds must be >= 0",
            }
        try:
            top_n = int(payload.get("top_n", 5))
        except (TypeError, ValueError):
            return {
                "verdict": "error",
                "category": "bad_payload",
                "reason": "top_n must be an integer",
            }
        if top_n < 1:
            top_n = 5

        history_raw = self._history_store.recent_oldest_first("permit")
        rejects_raw = self._history_store.recent_oldest_first("reject")
        verdicts_raw = self._history_store.recent_oldest_first("verdict")
        history = tuple(h for h in history_raw if isinstance(h, PaymentIntent))
        rejects = tuple(r for r in rejects_raw if isinstance(r, PaymentIntent))
        verdicts = tuple(v for v in verdicts_raw if isinstance(v, dict))
        agg = aggregate_risk_prevented(
            history=history,
            rejects=rejects,
            verdicts=verdicts,
            window_seconds=window_seconds,
            top_n=top_n,
        )
        return {
            "verdict": "ok",
            "aggregate": agg.to_wire(),
        }

    # ── guarantees surface (v0.14.0) ─────────────────────────────────────────

    def _op_guarantees(self) -> dict[str, Any]:
        """Enumerate the guarantees the cage currently delivers.

        Payload::

            { "op": "guarantees" }

        Returns::

            { "verdict": "ok",
              "guarantees": [ {Guarantee.to_wire()}, ... ],
              "active_count": int,
              "inactive_count": int }

        Pure read; never mutates state. Builds a fresh list on every call so
        toggling an env var (e.g. signing algorithm) flips the right guarantee
        to active=False on the next request without a daemon restart.
        """
        from adapter.guarantees import enumerate_guarantees, split_by_status

        with self._registry_lock:
            registry_snapshot = self._x402_registry
        # Build the daemon-config snapshot from live wiring. The helpers in
        # `adapter.guarantees` are careful to tolerate missing keys so this
        # dict can grow without breaking older callers.
        daemon_config: dict[str, Any] = {
            "signing_algorithm": os.environ.get(
                "TAU_CAGE_SIGNING_ALGORITHM", "hmac-sha256",
            ),
            "envelope_version": "v2" if self._hmac_secret else "v1",
            "hybrid_prover_wired": self._hybrid_prover is not None,
            "z3_prover_wired": (
                self._z3_incremental_prover is not None
                or self._hybrid_prover is not None
            ),
            "approval_queue_configured": self._approval_queue_path is not None,
            "require_human_approval": bool(self._require_human_approval),
            # The cross-revision validator + mutation-governance modules are
            # shipped by sibling patches; we read-probe their config via the
            # daemon state when present. Absent => both features report as
            # inactive, which is exactly what we want on a baseline daemon.
            "mutation_governance": getattr(
                self, "_mutation_governance_config", {},
            ),
            "cross_revision_rules": getattr(
                self, "_cross_revision_rules", (),
            ),
        }
        guarantees = enumerate_guarantees(
            registry=registry_snapshot,
            daemon_config=daemon_config,
            history_store=self._history_store,
        )
        active, inactive = split_by_status(guarantees)
        return {
            "verdict": "ok",
            "guarantees": [g.to_wire() for g in guarantees],
            "active_count": len(active),
            "inactive_count": len(inactive),
        }

    # ── v0.15.0 risk-dashboard read ops ────────────────────────────────────

    def _op_mutation_failures(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Return the recent mutation-failure timeline.

        Payload::

            { "op": "mutation_failures",
              "limit":        50,         # optional, default 50
              "since_unix":   1700000000, # optional
              "category":     "..."       # optional }

        Returns::

            { "verdict": "ok",
              "entries": [ MutationFailureEntry.to_wire(), ... ],
              "count": int,
              "cap": int }

        Pure read; never mutates the log.
        """
        try:
            limit = int(payload.get("limit", 50))
        except (TypeError, ValueError):
            return {
                "verdict": "error",
                "category": "bad_payload",
                "reason": "limit must be an integer",
            }
        if limit < 1:
            return {
                "verdict": "error",
                "category": "bad_payload",
                "reason": "limit must be >= 1",
            }
        since_raw = payload.get("since_unix")
        since_unix: int | None
        if since_raw is None:
            since_unix = None
        else:
            try:
                since_unix = int(since_raw)
            except (TypeError, ValueError):
                return {
                    "verdict": "error",
                    "category": "bad_payload",
                    "reason": "since_unix must be an integer",
                }
        category = payload.get("category")
        if category is not None:
            category = str(category)
        entries = self._mutation_failure_log.recent(
            limit=limit, since_unix=since_unix, category=category,
        )
        return {
            "verdict": "ok",
            "entries": [e.to_wire() for e in entries],
            "count": len(entries),
            "cap": self._mutation_failure_log.cap,
        }

    def _op_active_constraints(self) -> dict[str, Any]:
        """Return the constraints currently in force, grouped by class.

        Payload:
            { "op": "active_constraints" }

        Returns:
            { "verdict": "ok",
              "constraints": [ ActiveConstraint.to_wire(), ... ],
              "total": int }

        Pure read; snapshots the registry under the daemon lock so a
        concurrent mutation cannot race the summary.
        """
        with self._registry_lock:
            registry = self._x402_registry
        constraints = _active_constraints(registry)
        return {
            "verdict": "ok",
            "constraints": [c.to_wire() for c in constraints],
            "total": sum(c.count for c in constraints),
        }

    def _op_runtime_state(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Return the unified runtime-guard signals (v0.17.0).

        Payload:
            { "op": "runtime_state",
              "currency": "USDC"  (optional; default USDC)
            }

        Returns:
            { "verdict": "ok",
              "spend_velocity":    SpendVelocity.to_wire(),
              "retry_density":     RetryDensity.to_wire(),
              "cooldown_state":    CooldownState.to_wire(),
              "tightening_level":  TighteningLevel.to_wire(),
              "top_velocity_providers": [{"provider": p, "total": t}, ...],
              "active_cooldowns_count": int,
            }

        Pure read. Snapshots the registry under the daemon lock; the
        history reads are served by the store's own thread-safe path.
        """
        currency = str(payload.get("currency", "USDC")) if isinstance(payload, dict) else "USDC"
        with self._registry_lock:
            registry = self._x402_registry
        state = self._runtime_guard.runtime_state(registry, currency=currency)
        return {"verdict": "ok", **state}

    # ── inspect / explain ───────────────────────────────────────────────────

    def _op_inspect_policy(self) -> dict[str, Any]:
        """Return a read-only snapshot of the active policy.

        Does NOT run a prover. Does NOT mutate any state. Reads the current
        registry + revision log under the registry lock, then builds the
        wire shape documented on the daemon protocol.

        Resilient to a fresh daemon (no declares yet): returns ``None`` for
        every revision-derived field so callers can distinguish "empty
        policy" from "field is missing".
        """
        with self._registry_lock:
            invs = self._x402_registry.invariants
            log = self._revision_log

        active_revision_id = log[-1].config_hash if log else None
        most_recent = log[-1] if log else None
        invariants_dump = [
            {"class": type(inv).__name__, "scope_hint": _scope_hint_for(inv)}
            for inv in invs
        ]

        proof_backend: Optional[str] = None
        proof_strength: Optional[str] = None
        fragment_version: Optional[str] = None
        compile_hash: Optional[str] = None
        admitted_at_unix: Optional[int] = None
        if most_recent is not None:
            proof_backend = most_recent.backend
            proof_strength = most_recent.proof_strength
            fragment_version = most_recent.fragment_version
            compile_hash = most_recent.compile_hash
            admitted_at_unix = most_recent.issued_at_unix

        # v0.19.0 product-switch brief fields. These give operators a
        # single-glance "is this daemon in Guaranteed Mode?" answer without
        # having to reason about the internal ``prover_mode`` taxonomy.
        is_guaranteed = self._prover_mode == "guaranteed"
        if is_guaranteed:
            # Pull the live Tau backend version so evaluators can pin on
            # the exact binary that produced an admission.
            tau_version: Optional[str] = None
            if self._tau_prover is not None:
                tau_version = getattr(self._tau_prover, "version_string", None)
            public_mode = "guaranteed"
            public_backend = (
                f"tau-{tau_version}" if tau_version else "tau"
            )
            public_fallback = "none"
            public_totality_gate = "enforced"
            try:
                from adapter.guaranteed_language import GuaranteedLanguage
                public_language_tier = str(
                    GuaranteedLanguage.describe().get(
                        "language_version", "unknown"
                    )
                )
            except ImportError:
                public_language_tier = "unknown"
        else:
            public_mode = "flexible"
            chain_bits = ["tau"] if self._tau_prover is not None else []
            if self._z3_incremental_prover is not None:
                chain_bits.append("z3")
            chain_bits.append("pattern")
            public_backend = " + ".join(chain_bits)
            public_fallback = "pattern"
            public_totality_gate = "not enforced (Flexible Mode)"
            public_language_tier = "n/a"

        return {
            "verdict": "ok",
            "active_revision_id": active_revision_id,
            "active_invariants": len(invs),
            "invariants": invariants_dump,
            "prover_mode": self._prover_mode,
            "proof_backend": proof_backend,
            "proof_strength": proof_strength,
            "fragment_version": fragment_version,
            "compile_hash": compile_hash,
            "admitted_at_unix": admitted_at_unix,
            # Stable public-surface fields (v0.19.0 product switch).
            "mode": public_mode,
            "proof_backend_public": public_backend,
            "fallback": public_fallback,
            "totality_gate": public_totality_gate,
            "language_tier": public_language_tier,
        }

    def _op_explain_policy(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Explain why a policy is (un)satisfiable without admitting it.

        Two modes:
          * **Active** (no ``invariants`` key): run the configured prover
            chain against the currently-active registry. Useful to confirm
            the live policy remains SAT after the fact.
          * **Candidate** (``invariants: [...]`` provided): reconstruct a
            fresh invariant list from the payload and run the prover chain
            against it WITHOUT admitting. Useful for dry-run / preview from
            a UI or CI step.

        The output shape mirrors the rejection payloads the daemon already
        returns for declare/retract so consumers can reuse the same
        rendering code, with the addition of the verdict being set to
        ``sat`` on a successful ProofToken. v0.8.0 adds a ``witness`` key
        carrying a concrete permit trace when the policy contains
        fragment-v2 invariants and z3 is available.
        """
        invariants_list = payload.get("invariants")
        if invariants_list is None:
            with self._registry_lock:
                invariants = self._x402_registry.invariants
        else:
            if not isinstance(invariants_list, list):
                return {
                    "verdict": "error",
                    "category": "bad_invariants",
                    "reason": "'invariants' must be a list of declare-style entries",
                }
            built: list[Any] = []
            for idx, entry in enumerate(invariants_list):
                if not isinstance(entry, dict):
                    return {
                        "verdict": "error",
                        "category": "bad_invariants",
                        "reason": f"entry #{idx} is not a mapping: {entry!r}",
                    }
                inv = self._build_x402_invariant(entry)
                if inv is None:
                    return {
                        "verdict": "error",
                        "category": "bad_invariants",
                        "reason": f"entry #{idx} could not be built: {entry!r}",
                    }
                built.append(inv)
            invariants = tuple(built)

        # Run pattern prover first (always), then optionally Tau per mode.
        pattern_result = self._pattern_prover.prove(
            invariants=invariants, predecessor_hash=None,
        )
        if isinstance(pattern_result, Contradiction):
            return {
                "verdict": "unsat",
                "report": _contradiction_to_report(pattern_result).to_dict(),
                "proof_token": None,
                "witness": None,
            }

        # Pattern passed. Consult Tau in non-compat modes when available.
        if self._prover_mode != "compat" and self._tau_prover is not None:
            tau_result = self._tau_prover.prove(
                invariants=invariants, predecessor_hash=None,
            )
            if isinstance(tau_result, Contradiction):
                return {
                    "verdict": "unsat",
                    "report": _contradiction_to_report(tau_result).to_dict(),
                    "proof_token": None,
                    "witness": None,
                }
            if isinstance(tau_result, InconclusiveProof):
                if self._prover_mode == "strict":
                    return {
                        "verdict": "inconclusive",
                        "report": _inconclusive_to_report(tau_result).to_dict(),
                        "proof_token": None,
                        "witness": None,
                    }
                # verified: keep pattern token but annotate strength
                final = _relabel_strength(
                    pattern_result,  # type: ignore[arg-type]
                    f"pattern+tau-{tau_result.category}",
                )
                final = _with_mode(final, self._prover_mode)
                # Surface a z3 witness alongside the Tau-annotated proof
                # when the policy has fragment-v2 content and z3 is
                # available.
                witness_payload = self._maybe_witness_for(invariants)
                resp: dict[str, Any] = {
                    "verdict": "sat",
                    "report": _inconclusive_to_report(tau_result).to_dict(),
                    "proof_token": final.to_dict(),
                    "witness": witness_payload,
                }
                return resp
            if isinstance(tau_result, ProofToken):
                final = _with_mode(tau_result, self._prover_mode)
                witness_payload = self._maybe_witness_for(invariants)
                return {
                    "verdict": "sat",
                    "report": None,
                    "proof_token": final.to_dict(),
                    "witness": witness_payload,
                }

        # Pattern-only path (compat mode or no Tau prover wired up).
        final_token: ProofToken = pattern_result  # type: ignore[assignment]
        if final_token.prover_mode != self._prover_mode:
            final_token = _with_mode(final_token, self._prover_mode)
        witness_payload = self._maybe_witness_for(invariants)
        return {
            "verdict": "sat",
            "report": None,
            "proof_token": final_token.to_dict(),
            "witness": witness_payload,
        }

    def _maybe_witness_for(
        self,
        invariants: tuple[Invariant, ...],
    ) -> Optional[dict]:
        """Run a z3 witness extraction over the fragment-v2 subset if present.

        Returns ``None`` when:
          * the policy has no fragment-v2 invariants; or
          * z3 is not installed; or
          * the extraction raises.

        Never raises. Witness generation is strictly auxiliary to the
        admission verdict — failing here must not affect the outer
        explain response's ``verdict`` field.
        """
        try:
            from adapter.z3_compiler import (
                Z3CompileError,
                Z3Unavailable,
                check_sat,
                compile_policy_v2,
                extract_witness,
                is_fragment_v2_invariant,
            )
        except ImportError:
            return None
        v2_subset = tuple(i for i in invariants if is_fragment_v2_invariant(i))
        if not v2_subset:
            return None
        try:
            compiled, solver = compile_policy_v2(v2_subset)
        except (Z3Unavailable, Z3CompileError):
            return None
        try:
            verdict, _detail = check_sat(solver, compiled, timeout_ms=5000)
        except Exception:  # noqa: BLE001
            return None
        if verdict != "sat":
            return None
        try:
            witness = extract_witness(
                solver,
                summaries=compiled.invariant_summaries,
                unroll_steps=compiled.unroll_steps,
            )
        except Exception:  # noqa: BLE001
            return None
        # Decimal-safe wire form:
        from adapter.proof_report import PermitWitness
        return PermitWitness.from_witness_dict(witness, backend="z3").to_dict()

    def _op_narrate_policy(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Plain-English summary of a supplied policy.yaml (v0.18.0).

        The closing leg of the NL authoring round-trip: the operator
        hands us a policy.yaml string (typically produced by feeding
        ``tau-x402-cage suggest`` into an LLM); we parse it through the
        same loader the run path uses and emit a per-rule English
        description via :func:`adapter.policy_narrator.narrate_policy`.

        Purely local — no prover invocation, no SaaS hop. Wire shape:

            {
              "verdict": "ok" | "error",
              "sentences": [ {class, tier, sentence}, ... ],
              "summary":  "<newline-joined plain English>",
              "plain":    same as summary,
              "markdown": "- sentence 1\\n- sentence 2\\n...",
              "error":    null | <reason string>,
            }

        Errors (unloadable YAML, unknown invariant kind) come back with
        ``verdict="error"`` and an explanatory ``error`` key so callers
        can render the failure without a second round-trip.
        """
        import tempfile as _tempfile
        from pathlib import Path as _Path

        from adapter.policy_loader import PolicyLoaderError, load_policy
        from adapter.policy_narrator import (
            _narrate_one,
            _order_key,
            narrate_policy,
            narrate_policy_markdown,
        )

        policy_yaml = payload.get("policy_yaml")
        if not isinstance(policy_yaml, str) or not policy_yaml.strip():
            return {
                "verdict": "error",
                "sentences": [],
                "summary": "",
                "plain": "",
                "markdown": "",
                "error": "policy_yaml must be a non-empty string",
            }

        tmp = _tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", suffix=".yaml", delete=False,
        )
        try:
            tmp.write(policy_yaml)
            tmp.flush()
            tmp.close()
            try:
                loaded = load_policy(_Path(tmp.name))
            except PolicyLoaderError as exc:
                return {
                    "verdict": "error",
                    "sentences": [],
                    "summary": "",
                    "plain": "",
                    "markdown": "",
                    "error": str(exc),
                }
        finally:
            try:
                import os as _os
                _os.unlink(tmp.name)
            except OSError:
                pass

        ordered = sorted(loaded.invariants, key=_order_key)
        sentences = [
            {
                "class": inv.name,
                "tier": "v2" if _order_key(inv)[0] == 1 else "v1",
                "sentence": _narrate_one(inv),
            }
            for inv in ordered
        ]
        summary_plain = narrate_policy(loaded.invariants)
        summary_md = narrate_policy_markdown(loaded.invariants)
        return {
            "verdict": "ok",
            "sentences": sentences,
            "summary": summary_plain,
            "plain": summary_plain,
            "markdown": summary_md,
            "error": None,
        }

    def _op_active_revision(self) -> dict[str, Any]:
        """Return the currently-active PolicyRevision as JSON.

        The active revision is the latest admitted PolicyRevision; an empty
        chain returns `revision: None` so callers can treat "no policy yet"
        as a distinct state.
        """
        with self._registry_lock:
            latest = self._policy_revisions.latest
        if latest is None:
            return {"verdict": "ok", "revision": None}
        return {"verdict": "ok", "revision": latest.to_dict()}

    def _op_prover_metrics(self) -> dict[str, Any]:
        """Expose prover counters for observability (v0.7.0).

        Always includes the pattern prover's backend name. When an
        `IncrementalZ3Prover` is wired, includes its push/pop counters
        (incremental_hits, full_resolves, push_depth). When only the
        tau prover is wired, includes its backend name so ops tooling
        can tell which path is lit.

        The response shape is additive: missing backends simply omit
        their sub-dict, so consumers can feature-detect.
        """
        resp: dict[str, Any] = {
            "verdict": "ok",
            "prover_mode": self._prover_mode,
            "pattern_prover": {
                "backend": getattr(self._pattern_prover, "backend", "unknown"),
            },
        }
        if self._tau_prover is not None:
            resp["tau_prover"] = {
                "backend": getattr(self._tau_prover, "backend", "unknown"),
            }
        if self._z3_incremental_prover is not None:
            resp["z3_incremental_prover"] = self._z3_incremental_prover.metrics()
        if self._hybrid_prover is not None:
            resp["hybrid_prover"] = self._hybrid_prover.metrics()
        return resp

    def _op_active_x402(self) -> dict[str, Any]:
        with self._registry_lock:
            invs = self._x402_registry.invariants
        history_len = self._history_store.count("permit")
        return {
            "verdict": "ok",
            "active_invariants": len(invs),
            "kinds": [inv.name for inv in invs],
            "history_len": history_len,
        }

    # ── v0.7.0 branching revision graph ops ────────────────────────────────

    def _op_create_branch(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Open a new branch off an existing revision.

        Payload:
          { "op": "create_branch",
            "name": "<branch_name>",
            "from_revision_id": "<revision_id>" | null,
            "created_by": "<operator>" }   # optional
        """
        name = payload.get("name")
        if not isinstance(name, str) or not name:
            return {"verdict": "error", "category": "bad_payload",
                    "reason": "create_branch requires a non-empty 'name'"}
        from_rev = payload.get("from_revision_id")
        created_by = str(payload.get("created_by", "") or "")
        with self._registry_lock:
            try:
                branch = self._policy_revisions.create_branch(
                    name=name,
                    from_revision_id=from_rev,
                    created_by=created_by,
                )
            except RevisionLogError as exc:
                return {"verdict": "error", "category": "branch_error",
                        "reason": str(exc)}
        # v0.11.0: fan-out so peers see the new branch handle.
        if self._revision_sync is not None:
            try:
                self._revision_sync.publish_branch_create(branch)
            except Exception:  # noqa: BLE001 -- fail-open
                logger.exception("revision_sync: publish_branch_create raised")
        return {"verdict": "ok", "branch": branch.to_dict()}

    def _op_checkout_branch(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Activate an existing branch.

        Payload:
          { "op": "checkout_branch", "name": "<branch_name>" }

        Swaps `_x402_registry` to the new branch's head invariant set so
        `check_payment` immediately applies that branch's rules.
        """
        name = payload.get("name")
        if not isinstance(name, str) or not name:
            return {"verdict": "error", "category": "bad_payload",
                    "reason": "checkout_branch requires a non-empty 'name'"}
        with self._registry_lock:
            try:
                branch = self._policy_revisions.checkout_branch(name)
            except RevisionLogError as exc:
                return {"verdict": "error", "category": "branch_error",
                        "reason": str(exc)}
            # Swap the live registry to the branch's head invariants so
            # the hot path picks up the switch without a daemon restart.
            head = self._policy_revisions.latest
            reg = X402Registry.empty()
            if head is not None:
                for inv in head.invariants:
                    reg = reg.declare(inv)
            self._x402_registry = reg
            active_invariants = len(reg.invariants)
        # v0.11.0: fan-out the active-branch swap so replicas track HEAD.
        if self._revision_sync is not None:
            try:
                self._revision_sync.publish_branch_checkout(name)
            except Exception:  # noqa: BLE001 -- fail-open
                logger.exception("revision_sync: publish_branch_checkout raised")
        return {
            "verdict": "ok",
            "branch": branch.to_dict(),
            "active_invariants": active_invariants,
        }

    def _op_list_branches(self) -> dict[str, Any]:
        """Return the full branch list for this daemon."""
        with self._registry_lock:
            branches = self._policy_revisions.list_branches()
            active = self._policy_revisions.active_branch
        return {
            "verdict": "ok",
            "active_branch": active,
            "branches": [b.to_dict() for b in branches],
        }

    def _op_merge_branch(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Merge `src` into `dst` using the cheapest available strategy.

        v0.8.0 extends the v0.7.0 FF-only op to try a three-way merge when
        the branches diverged on disjoint invariant classes. The response
        always carries ``merge_kind ∈ {fast-forward, three-way, conflict}``
        so callers can distinguish which path was taken.

        Payload:
          { "op": "merge_branch",
            "src": "<branch_name>",
            "dst": "<branch_name>",
            "reviewer": "<operator>" }
        """
        src = payload.get("src")
        dst = payload.get("dst")
        reviewer = payload.get("reviewer")
        if not isinstance(src, str) or not src:
            return {"verdict": "error", "category": "bad_payload",
                    "reason": "merge_branch requires 'src'"}
        if not isinstance(dst, str) or not dst:
            return {"verdict": "error", "category": "bad_payload",
                    "reason": "merge_branch requires 'dst'"}
        if not isinstance(reviewer, str) or not reviewer:
            return {"verdict": "error", "category": "bad_payload",
                    "reason": "merge_branch requires a non-empty 'reviewer'"}
        # v0.13.0: self-referential cooldown short-circuit. If a previous
        # conflict on the same dst triggered a cooldown that is still
        # active, we never run the 3-way merge -- the daemon's own
        # rejection history is the gating rule. retry_after_s is the
        # operator's hint for when to try again.
        if self._merge_cooldown is not None and self._merge_cooldown.enabled:
            now = int(time.time())
            expiry = self._merge_cooldown.status_for(dst, now)
            if expiry is not None:
                return {
                    "verdict": "cooldown",
                    "merge_kind": "cooldown",
                    "dst": dst,
                    "src": src,
                    "expires_unix": int(expiry),
                    "retry_after_s": max(0, int(expiry) - now),
                    "reason": (
                        f"merge into {dst!r} is in cooldown after a recent "
                        f"conflict; retry in {max(0, int(expiry) - now)}s"
                    ),
                }
        with self._registry_lock:
            # Snapshot dst head BEFORE the merge so we can classify the
            # kind after. FF keeps the head as an existing revision id;
            # three-way inserts a new merge commit (head != src_head).
            dst_head_before = None
            try:
                b = self._policy_revisions.head_of(dst)
                dst_head_before = b.revision_id if b is not None else None
            except Exception:
                dst_head_before = None
            src_head_before = None
            try:
                b = self._policy_revisions.head_of(src)
                src_head_before = b.revision_id if b is not None else None
            except Exception:
                src_head_before = None
            try:
                result = self._policy_revisions.merge_branch(
                    src=src, dst=dst, reviewer=reviewer,
                )
            except RevisionLogError as exc:
                return {"verdict": "error", "category": "branch_error",
                        "reason": str(exc)}
            if isinstance(result, BranchMergeConflict):
                conflict_resp: dict[str, Any] = {
                    "verdict": "conflict",
                    "merge_kind": "conflict",
                    **result.to_dict(),
                }
                # v0.14.0: re-run semantic classification with the daemon's
                # real prover configuration. The log-level classifier
                # defaults ``prover_supports_v2=True`` because it doesn't
                # know what provers the daemon was started with; here we
                # override with the live answer so
                # ``unsupported_fragment`` lights up correctly on a
                # fragment-v1-only deployment.
                try:
                    from adapter.merge_classifier import classify_conflict
                    prover_supports_v2 = (
                        self._hybrid_prover is not None
                        or self._z3_incremental_prover is not None
                    )
                    reclassified = classify_conflict(
                        src_delta=result.src_delta,
                        dst_delta=result.dst_delta,
                        src_branch=src,
                        dst_branch=dst,
                        prover_supports_v2=prover_supports_v2,
                    )
                    conflict_resp["classified_conflicts"] = [
                        c.to_dict() for c in reclassified
                    ]
                except Exception:  # noqa: BLE001 — classifier failure must not block merges.
                    logger.exception("merge_classifier: reclassification failed")
                # v0.13.0: self-referential cooldown -- the daemon
                # observes its own failure and starts a cooldown clock.
                # Subsequent merges into the same dst will cooldown-fail
                # until the clock elapses.
                if (
                    self._merge_cooldown is not None
                    and self._merge_cooldown.enabled
                ):
                    expiry = self._merge_cooldown.trigger(dst)
                    conflict_resp["cooldown_triggered"] = True
                    conflict_resp["cooldown_expires_unix"] = int(expiry)
                    conflict_resp["cooldown_retry_after_s"] = (
                        self._merge_cooldown.cooldown_seconds
                    )
                return conflict_resp
            # FF or three-way succeeded. Classify by peeking at the new
            # head: three-way merges carry ``merge_parent_ids``; FFs
            # re-use an existing revision id that has none.
            new_head_rev = self._policy_revisions.head_of(dst)
            merge_kind = "fast-forward"
            if new_head_rev is not None and new_head_rev.merge_parent_ids is not None:
                merge_kind = "three-way"
            # If dst is the active branch, swap the live registry to the
            # new head so subsequent check_payment calls see the merged policy.
            active_invariants: Optional[int] = None
            if self._policy_revisions.active_branch == dst:
                head = self._policy_revisions.latest
                reg = X402Registry.empty()
                if head is not None:
                    for inv in head.invariants:
                        reg = reg.declare(inv)
                self._x402_registry = reg
                active_invariants = len(reg.invariants)
        resp: dict[str, Any] = {
            "verdict": "merged",
            "merge_kind": merge_kind,
            "branch": result.to_dict(),
        }
        if merge_kind == "three-way" and new_head_rev is not None:
            resp["merged_revision_id"] = new_head_rev.revision_id
            if new_head_rev.merge_parent_ids is not None:
                resp["merge_parent_ids"] = list(new_head_rev.merge_parent_ids)
        if active_invariants is not None:
            resp["active_invariants"] = active_invariants
        # v0.11.0: fan-out the merge event + (if three-way) the merge
        # revision so replicas reconstruct the DAG identically.
        if self._revision_sync is not None:
            try:
                merge_rev_for_sync = (
                    new_head_rev if merge_kind == "three-way" else None
                )
                self._revision_sync.publish_branch_merge(
                    src=src,
                    dst=dst,
                    merge_kind=merge_kind,
                    new_head_revision_id=(
                        new_head_rev.revision_id if new_head_rev is not None else None
                    ),
                    reviewer=reviewer,
                    merge_revision=merge_rev_for_sync,
                )
            except Exception:  # noqa: BLE001 -- fail-open
                logger.exception("revision_sync: publish_branch_merge raised")
        return resp

    def _op_current_branch(self) -> dict[str, Any]:
        """Return the name of the currently active branch."""
        with self._registry_lock:
            active = self._policy_revisions.active_branch
            head = self._policy_revisions.latest
        return {
            "verdict": "ok",
            "active_branch": active,
            "head_revision_id": head.revision_id if head is not None else None,
        }

    # ── v0.7.0 approval queue ops ──────────────────────────────────────────

    # ── v0.14.0 mutation-governance helpers ────────────────────────────────

    def _governance_check_propose(
        self, actor_id: str | None, invariant: Invariant,
    ) -> GovernanceVerdict | None:
        """Run the mutation-governance check for a single invariant.

        Returns the GovernanceVerdict when governance is wired, None otherwise
        (caller treats None as "allow, defaults"). Keeping the None path
        preserves pre-v0.14.0 behaviour for deployments without a governance
        YAML.
        """
        if self._governance is None:
            return None
        return self._governance.check_propose(actor_id, invariant)

    def _governance_check_declare(
        self, invariant: Invariant, *, mode: str,
    ) -> dict[str, Any] | None:
        """Apply all declare-time governance gates to `invariant`.

        Returns None when the invariant clears every gate. Otherwise
        returns a ``verdict=error`` envelope that the caller should relay
        back to the client verbatim. The three gates are:

          1. check_prover_mode — temporal rules may require strict mode.
          2. check_temporal_bounds — window inside the configured bounds.
          3. actor/class authorization — already enforced at submit time
             for the propose/approve path; add_invariant / update_invariant
             re-run it here only when the payload explicitly supplies an
             ``actor_id`` (otherwise treated as anonymous / legacy).
        """
        if self._governance is None:
            return None
        class_name = type(invariant).__name__
        if not self._governance.check_prover_mode(class_name, mode):
            return {
                "verdict": "error",
                "category": "governance_violation",
                "reason": (
                    f"{class_name} requires prover_mode='strict' per governance "
                    f"policy; daemon is running in {mode!r}"
                ),
            }
        ok, reason = self._governance.check_temporal_bounds(invariant)
        if not ok:
            return {
                "verdict": "error",
                "category": "governance_violation",
                "reason": reason,
            }
        return None

    def _op_propose_invariant(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Queue a policy change for human review.

        Payload:
          { "op": "propose_invariant",
            "submitted_by": "<agent-id>",
            "invariants": [{ "kind": "...", ... }, ...] }

        Accepts EITHER a single ``invariant`` entry OR a list under
        ``invariants`` so simple agents don't need to wrap a single rule.
        Unlike ``add_invariant``, propose never touches the prover chain:
        declare-time consistency is only checked when the proposal is
        approved and flows into ``add_invariant``.
        """
        submitted_by = str(payload.get("submitted_by") or "").strip()
        if not submitted_by:
            return {
                "verdict": "error",
                "category": "bad_proposal",
                "reason": "propose_invariant requires a non-empty 'submitted_by'",
            }
        # v0.14.0: actor_id is the governance identity (may equal
        # submitted_by or be a separate service account). Optional for
        # back-compat; when absent and governance is loaded the submit is
        # treated as anonymous and clears governance-axis-1.
        actor_id = payload.get("actor_id")
        if actor_id is not None:
            actor_id = str(actor_id).strip() or None
        entries = payload.get("invariants")
        if entries is None:
            single = payload.get("invariant")
            entries = [single] if single is not None else []
        if not isinstance(entries, list) or not entries:
            return {
                "verdict": "error",
                "category": "bad_proposal",
                "reason": "propose_invariant requires a non-empty 'invariants' list",
            }
        built: list[Invariant] = []
        for idx, entry in enumerate(entries):
            if not isinstance(entry, dict):
                return {
                    "verdict": "error",
                    "category": "bad_invariant",
                    "reason": f"entry #{idx} is not a mapping: {entry!r}",
                }
            inv = self._build_x402_invariant(entry)
            if inv is None:
                return {
                    "verdict": "error",
                    "category": "bad_invariant",
                    "reason": f"entry #{idx} could not be built",
                }
            built.append(inv)
        # v0.14.0 governance axis 1: actor must be authorized to propose
        # every invariant in the bundle. Fail on the first violation so
        # the reason names the specific class that tripped the rule.
        required_reviewers = 1
        for inv in built:
            verdict = self._governance_check_propose(actor_id, inv)
            if verdict is None:
                continue
            if not verdict.allowed:
                return {
                    "verdict": "error",
                    "category": "governance_violation",
                    "reason": verdict.reason,
                }
            # Multiple invariants in one proposal: the highest required
            # reviewer count across the bundle wins (fail-closed).
            required_reviewers = max(required_reviewers, verdict.required_reviewers)
        # v0.14.0 governance axes 3+4 run at declare time; surface them
        # as bad_proposal so the agent can see the mismatch immediately
        # rather than waiting for the human reviewer to hit it on approve.
        for inv in built:
            declare_error = self._governance_check_declare(
                inv, mode=self._prover_mode,
            )
            if declare_error is not None:
                return declare_error
        with self._registry_lock:
            active = self._policy_revisions.latest
            diff_from = (
                payload.get("diff_from_revision")
                or (active.revision_id if active is not None else None)
            )
        try:
            proposal = self._approval_queue.submit(
                submitted_by=submitted_by,
                invariants=built,
                diff_from_revision=diff_from,
                actor_id=actor_id,
            )
        except ApprovalQueueError as exc:
            return {
                "verdict": "error",
                "category": "bad_proposal",
                "reason": str(exc),
            }
        self._update_proposal_gauges()
        return {
            "verdict": "pending_approval",
            "status_code": 202,
            "proposal": proposal.to_dict(),
            "proposal_id": proposal.proposal_id,
            "required_reviewers": required_reviewers,
        }

    def _op_approve_proposal(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Approve a pending proposal and apply its invariants atomically.

        Payload:
          { "op": "approve_proposal",
            "proposal_id": "<uuid>",
            "reviewer": "<human-id>",
            "reason": "<optional>",
            "allow_same_as_submitter": false }

        Approval is a two-step operation:
          1. Mark the proposal `approved` in the queue (durable).
          2. Run each invariant through `_apply_revision` (prover chain).
        If step 2 fails (contradiction / strict-mode inconclusive), the
        queue state is preserved (approved) but the cage registry is NOT
        mutated. The response carries the rejection envelope from the
        prover so operators can diagnose the clash. No attempt is made
        to "un-approve" the proposal; audit integrity requires the
        reviewer's approval to remain on record even when admission fails.
        """
        proposal_id = str(payload.get("proposal_id") or "").strip()
        reviewer = str(payload.get("reviewer") or "").strip()
        reason = payload.get("reason")
        allow_same = bool(payload.get("allow_same_as_submitter", False))
        if not proposal_id:
            return {
                "verdict": "error",
                "category": "bad_proposal",
                "reason": "approve_proposal requires 'proposal_id'",
            }
        if not reviewer:
            return {
                "verdict": "error",
                "category": "bad_proposal",
                "reason": "approve_proposal requires 'reviewer'",
            }
        # v0.14.0 governance axis 2: derive the per-proposal reviewer
        # requirement from the first invariant's class. The queue's
        # approve() re-derives it per invariant when necessary, but the
        # top-of-bundle class is the one that tripped the highest
        # min_reviewers during propose-time — safe to reuse here.
        current = self._approval_queue.get(proposal_id)
        if current is None:
            return {
                "verdict": "error",
                "category": "bad_proposal",
                "reason": f"unknown proposal_id: {proposal_id!r}",
            }
        min_reviewers = 1
        reviewers_must_differ = True
        if self._governance is not None and current.invariants:
            # The bundle must clear the strictest requirement across its
            # invariants; computing max keeps fail-closed semantics.
            for inv in current.invariants:
                req = self._governance.get_requirement(type(inv).__name__)
                if req.min_reviewers > min_reviewers:
                    min_reviewers = req.min_reviewers
                # reviewers_must_differ stays True if ANY class demands
                # distinct reviewers; the feature is designed to dedup.
                reviewers_must_differ = (
                    reviewers_must_differ and req.reviewers_must_differ
                )
        try:
            approved = self._approval_queue.approve(
                proposal_id=proposal_id,
                reviewer=reviewer,
                reason=reason,
                allow_same_as_submitter=allow_same,
                min_reviewers=min_reviewers,
                reviewers_must_differ=reviewers_must_differ,
            )
        except ApprovalQueueError as exc:
            return {
                "verdict": "error",
                "category": "bad_proposal",
                "reason": str(exc),
            }
        self._update_proposal_gauges()
        # If the proposal is still pending (threshold not yet met), return
        # a dedicated envelope so operators and CI can tell at a glance how
        # many more approvals are outstanding.
        if approved.status != "approved":
            distinct_reviewers = len({v.reviewer_id for v in approved.reviewers})
            return {
                "verdict": "pending_more_approvals",
                "status_code": 202,
                "proposal": approved.to_dict(),
                "reviewers_recorded": distinct_reviewers,
                "reviewers_required": min_reviewers,
            }
        # Threshold met: apply each invariant via the standard admission
        # path. Multiple invariants in one proposal are admitted as a
        # single revision by composing retract/declare under one
        # `_apply_revision` call.
        invariants = approved.invariants

        def mutate(reg):
            for inv in invariants:
                reg = reg.declare(inv)
            return reg

        admission = self._apply_revision(
            mutate,
            kind=type(invariants[0]).__name__ if invariants else None,
            op_name="updated",
            delta_added=tuple(invariants),
            delta_removed=(),
        )
        return {
            "verdict": "approved",
            "proposal": approved.to_dict(),
            "admission": admission,
        }

    def _op_reject_proposal(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Reject a pending proposal. Rejection is terminal and requires a reason.

        Payload:
          { "op": "reject_proposal",
            "proposal_id": "<uuid>",
            "reviewer": "<human-id>",
            "reason": "<required>",
            "allow_same_as_submitter": false }
        """
        proposal_id = str(payload.get("proposal_id") or "").strip()
        reviewer = str(payload.get("reviewer") or "").strip()
        reason = payload.get("reason")
        allow_same = bool(payload.get("allow_same_as_submitter", False))
        if not proposal_id:
            return {
                "verdict": "error",
                "category": "bad_proposal",
                "reason": "reject_proposal requires 'proposal_id'",
            }
        if not reviewer:
            return {
                "verdict": "error",
                "category": "bad_proposal",
                "reason": "reject_proposal requires 'reviewer'",
            }
        if reason is None or not str(reason).strip():
            return {
                "verdict": "error",
                "category": "bad_proposal",
                "reason": "reject_proposal requires a non-empty 'reason'",
            }
        try:
            rejected = self._approval_queue.reject(
                proposal_id=proposal_id,
                reviewer=reviewer,
                reason=str(reason),
                allow_same_as_submitter=allow_same,
            )
        except ApprovalQueueError as exc:
            return {
                "verdict": "error",
                "category": "bad_proposal",
                "reason": str(exc),
            }
        self._update_proposal_gauges()
        return {"verdict": "rejected", "proposal": rejected.to_dict()}

    def _op_list_proposals(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Return proposals, optionally filtered by status.

        Payload:
          { "op": "list_proposals",
            "status": "pending" | "approved" | "rejected" | null }
        """
        status_filter = payload.get("status")
        try:
            proposals = self._approval_queue.list(status_filter=status_filter)
        except ApprovalQueueError as exc:
            return {
                "verdict": "error",
                "category": "bad_proposal",
                "reason": str(exc),
            }
        return {
            "verdict": "ok",
            "count": len(proposals),
            "proposals": [p.to_dict() for p in proposals],
        }

    def _op_get_proposal(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Return a single proposal by id.

        Payload:
          { "op": "get_proposal", "proposal_id": "<uuid>" }
        """
        proposal_id = str(payload.get("proposal_id") or "").strip()
        if not proposal_id:
            return {
                "verdict": "error",
                "category": "bad_proposal",
                "reason": "get_proposal requires 'proposal_id'",
            }
        proposal = self._approval_queue.get(proposal_id)
        if proposal is None:
            return {
                "verdict": "error",
                "category": "unknown_proposal",
                "reason": f"no proposal with id {proposal_id!r}",
            }
        return {"verdict": "ok", "proposal": proposal.to_dict()}

    # ── v0.9.0 signed audit export ─────────────────────────────────────────

    def _op_export_audit(self) -> dict[str, Any]:
        """Emit the unsigned audit bundle for offline signing + verification.

        The daemon has no business holding the private key, so signing
        happens at the CLI boundary (``tau-x402-cage audit-export``). This
        op snapshots the three audit surfaces — revision log, approval
        queue, branch graph — and hands them back to the caller. The CLI
        runs ``adapter.audit_export.sign_bundle`` on the result.

        Snapshot is taken under the registry lock so the revision chain
        and branch heads match the approval queue at the same instant.
        """
        from adapter.audit_export import export_bundle

        with self._registry_lock:
            revisions = self._policy_revisions.revisions
            branches = self._policy_revisions.list_branches()
            proposals = self._approval_queue.list()
        bundle = export_bundle(
            revision_log=revisions,
            approval_queue=proposals,
            branches=branches,
        )
        return {"verdict": "ok", "bundle": bundle}

    # ── v0.15.0 signed decision bundles ────────────────────────────────────

    def _op_build_decision_bundle(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Assemble a signed decision bundle for one verdict.

        Payload:
            { "op": "build_decision_bundle",
              "bundle_id": "<uuid>"          # primary key, or
              "intent_hash": "<hex>"         # fallback lookup
              "chain_limit": 50              # optional (default 50)
            }

        Returns:
            { "verdict": "ok",
              "bundle_jsonl": "<UTF-8 JSONL bytes as str>",
              "bundle_id": "<uuid>",
              "intent_hash": "<hex>" }
            or the usual error envelope on lookup failure / missing signer.

        The daemon looks up the stored verdict record by bundle_id (or
        intent_hash), reconstructs the full PaymentIntent, re-signs the
        verdict with the daemon's HMAC secret, assembles the bundle via
        the pure :func:`adapter.decision_bundle.build_decision_bundle`,
        and returns the canonical JSONL. The re-sign is deterministic —
        same record + same secret produces byte-identical envelopes — so
        the bundle is reproducible as long as the verdict record survives
        in the history store.
        """
        from adapter.decision_bundle import (
            build_decision_bundle,
            bundle_to_jsonl,
        )

        bundle_id_filter = payload.get("bundle_id")
        intent_hash_filter = payload.get("intent_hash")
        if not bundle_id_filter and not intent_hash_filter:
            return {
                "verdict": "error",
                "category": "bad_payload",
                "reason": "build_decision_bundle requires 'bundle_id' or 'intent_hash'",
            }
        chain_limit_raw = payload.get("chain_limit", 50)
        try:
            chain_limit = int(chain_limit_raw)
        except (TypeError, ValueError):
            return {
                "verdict": "error",
                "category": "bad_payload",
                "reason": "chain_limit must be an integer",
            }
        if chain_limit <= 0:
            return {
                "verdict": "error",
                "category": "bad_payload",
                "reason": "chain_limit must be > 0",
            }
        if self._hmac_secret is None:
            return {
                "verdict": "error",
                "category": "signer_unavailable",
                "reason": (
                    "daemon has no HMAC secret configured; bundle signing "
                    "requires TAU_X402_HMAC_SECRET"
                ),
            }
        # Walk the verdict history (newest-first) for the matching record.
        # The ring buffer default cap is 10k so this stays cheap; callers
        # who need faster lookup should query by bundle_id.
        verdict_rows = self._history_store.recent_oldest_first("verdict")
        match: Optional[dict[str, Any]] = None
        for row in verdict_rows:
            if not isinstance(row, dict):
                continue
            if bundle_id_filter and row.get("bundle_id") == bundle_id_filter:
                match = row
                break
            if (
                intent_hash_filter
                and not bundle_id_filter
                and row.get("intent_hash") == intent_hash_filter
            ):
                match = row
                # Don't break — keep scanning so the freshest match wins
                # if the same intent was evaluated more than once. The
                # oldest-first walk means the last hit is the newest.
        if match is None:
            return {
                "verdict": "error",
                "category": "unknown_verdict",
                "reason": (
                    f"no verdict record with "
                    f"{'bundle_id=' + repr(bundle_id_filter) if bundle_id_filter else 'intent_hash=' + repr(intent_hash_filter)}"
                ),
            }
        intent_json = match.get("_bundle_intent")
        if not isinstance(intent_json, dict):
            return {
                "verdict": "error",
                "category": "record_incomplete",
                "reason": (
                    "verdict record is missing '_bundle_intent' — this "
                    "daemon may have emitted the record before v0.15.0"
                ),
            }
        try:
            intent = _history_intent_from_json(intent_json)
        except (KeyError, ValueError, InvalidOperation, TypeError) as exc:
            return {
                "verdict": "error",
                "category": "record_corrupt",
                "reason": f"cannot reconstruct PaymentIntent: {exc}",
            }
        # Re-sign the verdict with the daemon's HMAC secret. Same fields
        # in, same MAC out, so the envelope byte-matches what the
        # original verdict response carried.
        revision_id = match.get("revision_id")
        with self._registry_lock:
            # Look up the revision by id so the bundle carries the exact
            # admitting revision, not whatever is head right now.
            active_revision: Optional[PolicyRevision] = None
            if revision_id is not None:
                active_revision = self._policy_revisions._revisions_by_id.get(
                    revision_id
                )
            revisions_snapshot = self._policy_revisions.revisions
        # Reconstruct the Verdict from the recorded outcome + metadata.
        verdict_outcome = match.get("verdict")
        if verdict_outcome not in ("permit", "reject"):
            return {
                "verdict": "error",
                "category": "record_corrupt",
                "reason": f"unexpected verdict outcome {verdict_outcome!r}",
            }
        issued_at = match.get("_bundle_issued_at_unix")
        ttl_seconds = match.get("_bundle_ttl_seconds", 30)
        witness = match.get("_bundle_witness")
        verdict = Verdict(
            outcome=verdict_outcome,
            rule_id=match.get("rule_id"),
            witness=witness,
            reason_text=match.get("reason_text"),
            issued_at_unix=int(issued_at) if issued_at is not None else 0,
            ttl_seconds=int(ttl_seconds),
        )
        envelope = sign(
            verdict,
            intent,
            self._hmac_secret,
            now_unix=verdict.issued_at_unix,
            revision=active_revision,
            without_system=match.get("without_system"),
        )
        # Which revisions to include: the active revision plus all its
        # ancestors in the log, oldest-first. For a linear log this is
        # the full ``revisions`` tuple; for a branched log the op falls
        # back to the linear list and the chain_limit truncates the
        # oldest. Good enough for audit — bundles are a per-decision
        # view, not a full DAG walk.
        if active_revision is None:
            chain_iter: list[PolicyRevision] = []
        else:
            chain_iter = [r for r in revisions_snapshot]
            # Ensure the head of the chain is the admitting revision.
            if chain_iter and chain_iter[-1].revision_id != active_revision.revision_id:
                # If the head isn't the admitting revision (e.g. a branch
                # has moved on), truncate at the admitting revision so
                # the bundle's head matches the envelope's provenance.
                idx = None
                for i, r in enumerate(chain_iter):
                    if r.revision_id == active_revision.revision_id:
                        idx = i
                        break
                if idx is not None:
                    chain_iter = chain_iter[:idx + 1]
                else:
                    # Revision not found in linear list; fall back to just
                    # the admitting revision on its own.
                    chain_iter = [active_revision]
        invariants = (
            tuple(active_revision.invariants) if active_revision is not None
            else tuple(self._x402_registry.invariants)
        )
        bundle_id = match.get("bundle_id") or ""
        try:
            from saas.app import APP_VERSION as _CAGE_VERSION
        except Exception:  # noqa: BLE001 — saas is optional
            _CAGE_VERSION = "0.15.0"
        bundle = build_decision_bundle(
            envelope,
            active_invariants=invariants,
            revision_log=chain_iter,
            cage_version=_CAGE_VERSION,
            bundle_id=bundle_id,
            created_at_unix=int(time.time()),
            chain_limit=chain_limit,
            witness=witness,
        )
        jsonl_bytes = bundle_to_jsonl(bundle)
        return {
            "verdict": "ok",
            "bundle_id": bundle_id,
            "intent_hash": envelope.intent_hash,
            "bundle_jsonl": jsonl_bytes.decode("utf-8"),
            "truncated": bundle.truncated,
            "chain_total": bundle.chain_total,
        }

    def _op_explain_decision(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Return a human-readable explanation for a stored verdict.

        Payload::

            { "op": "explain_decision",
              "bundle_id": "<uuid>"         # primary key, OR
              "intent_hash": "<hex>"        # fallback lookup
            }

        Returns::

            { "verdict": "ok",
              "bundle_id": "<uuid>",
              "intent_hash": "<hex>",
              "explanation": {DecisionExplanation.to_wire()} }

        Pure read — never mutates state or re-runs the rule. Looks up the
        verdict record by bundle_id (or intent_hash) in the history ring,
        then delegates to :func:`adapter.decision_explainer.explain_decision`.
        """
        from adapter.decision_explainer import explain_decision

        bundle_id_filter = payload.get("bundle_id")
        intent_hash_filter = payload.get("intent_hash")
        if not bundle_id_filter and not intent_hash_filter:
            return {
                "verdict": "error",
                "category": "bad_payload",
                "reason": (
                    "explain_decision requires 'bundle_id' or 'intent_hash'"
                ),
            }
        verdict_rows = self._history_store.recent_oldest_first("verdict")
        match: Optional[dict[str, Any]] = None
        for row in verdict_rows:
            if not isinstance(row, dict):
                continue
            if bundle_id_filter and row.get("bundle_id") == bundle_id_filter:
                match = row
                break
            if (
                intent_hash_filter
                and not bundle_id_filter
                and row.get("intent_hash") == intent_hash_filter
            ):
                # Keep scanning so the freshest match wins when the same
                # intent was evaluated more than once.
                match = row
        if match is None:
            lookup_repr = (
                f"bundle_id={bundle_id_filter!r}"
                if bundle_id_filter
                else f"intent_hash={intent_hash_filter!r}"
            )
            return {
                "verdict": "error",
                "category": "unknown_verdict",
                "reason": f"no verdict record with {lookup_repr}",
            }
        try:
            with self._registry_lock:
                registry = self._x402_registry
            explanation = explain_decision(
                match,
                registry=registry,
                history_store=self._history_store,
            )
        except TypeError as exc:  # defensive: malformed record
            return {
                "verdict": "error",
                "category": "record_corrupt",
                "reason": f"cannot explain decision: {exc}",
            }
        return {
            "verdict": "ok",
            "bundle_id": match.get("bundle_id"),
            "intent_hash": match.get("intent_hash"),
            "explanation": explanation.to_wire(),
        }

    # ── v0.9.0 metrics gauge refresh helpers ──────────────────────────────

    def _update_proposal_gauges(self) -> None:
        """Refresh the ``tau_x402_proposals{status=...}`` gauges.

        Called after any mutation that could change the queue shape
        (add/approve/reject/propose). Cheap — iterates the queue once
        and sets three gauge samples.
        """
        try:
            proposals = self._approval_queue.list()
        except Exception:  # pragma: no cover - defensive
            return
        counts = {"pending": 0, "approved": 0, "rejected": 0}
        for p in proposals:
            status = getattr(p, "status", None)
            if status in counts:
                counts[status] += 1
        for status, value in counts.items():
            self._metrics.set_proposals(status, value)

    def _update_branch_gauges(self) -> None:
        """Refresh ``tau_x402_branches_active`` after a branch mutation."""
        try:
            branches = self._policy_revisions.list_branches()
        except Exception:  # pragma: no cover - defensive
            return
        self._metrics.set_branches_active(len(branches))

    def _update_z3_gauges(self) -> None:
        """Refresh ``tau_x402_z3_push_depth`` from the incremental prover."""
        prover = self._z3_incremental_prover
        if prover is None:
            return
        try:
            m = prover.metrics()
        except Exception:  # pragma: no cover - defensive
            return
        depth = m.get("push_depth", 0)
        self._metrics.set_z3_push_depth(depth)

    def _build_x402_invariant(self, payload: dict[str, Any]):
        kind = payload.get("kind")
        try:
            if kind == "spending_cap":
                cpc_raw = payload.get("cross_provider_cap")
                cross_cap = (
                    Decimal(str(cpc_raw)) if cpc_raw is not None else None
                )
                return SpendingCap(
                    max_amount=Decimal(str(payload["max_amount"])),
                    currency=payload.get("currency", "USDC"),
                    scope=payload.get("scope", "per_window"),
                    window_seconds=payload.get("window_seconds"),
                    provider=payload.get("provider"),
                    cross_provider_cap=cross_cap,
                )
            if kind == "max_per_call":
                return MaxPerCall(
                    max_amount=Decimal(str(payload["max_amount"])),
                    currency=payload.get("currency", "USDC"),
                )
            if kind == "provider_allowlist":
                providers = payload.get("providers", [])
                if not isinstance(providers, list):
                    return None
                return ProviderAllowlist(providers=frozenset(providers))
            if kind == "retry_rate_limit":
                return RetryRateLimit(min_gap_seconds=int(payload["min_gap_seconds"]))
            if kind == "rolling_window_cap":
                return RollingWindowCap(
                    max_count=int(payload["max_count"]),
                    window_seconds=int(payload["window_seconds"]),
                    group_by=payload.get("group_by", "provider"),
                )
            if kind == "counterparty_constraint":
                approved = frozenset(payload.get("approved_ids", []))
                sanctioned = frozenset(payload.get("sanctioned_ids", []))
                return CounterpartyConstraint(
                    approved_ids=approved, sanctioned_ids=sanctioned
                )
            if kind == "mutual_exclusion":
                group_a = payload.get("group_a", [])
                group_b = payload.get("group_b", [])
                if not isinstance(group_a, list) or not isinstance(group_b, list):
                    return None
                return MutualExclusion(
                    group_a=frozenset(group_a),
                    group_b=frozenset(group_b),
                )
            if kind == "instability_guard":
                # v0.13.0 self-referential invariant: semantics live in
                # adapter.self_ref_policy.InstabilityGuard. See
                # docs/self_referential_policy.md for field meanings.
                return InstabilityGuard(
                    provider=str(payload["provider"]),
                    reject_threshold=int(payload["reject_threshold"]),
                    window_seconds=int(payload["window_seconds"]),
                    tighten_to=Decimal(str(payload["tighten_to"])),
                    recovery_seconds=int(payload["recovery_seconds"]),
                    currency=payload.get("currency", "USDC"),
                )
            if kind == "burst_velocity_cap":
                # v0.17.0 runtime-guard invariant; see
                # docs/runtime_guard.md for field meanings.
                return BurstVelocityCap(
                    max_per_window=Decimal(str(payload["max_per_window"])),
                    window_seconds=int(payload["window_seconds"]),
                    currency=payload.get("currency", "USDC"),
                    cross_provider=bool(payload.get("cross_provider", True)),
                )
        except (KeyError, ValueError, InvalidOperation, TypeError) as exc:
            logger.warning("bad x402 invariant payload: %s", exc)
            return None
        return None

