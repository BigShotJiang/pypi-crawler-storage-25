"""Daemon-side peer-auth integration (v0.22.0).

Drives ``CageDaemon.dispatch`` directly with mocked peer credentials so
the tests do not require a second process to authenticate against. Real
``SO_PEERCRED`` / ``LOCAL_PEERCRED`` integration happens when the daemon
runs under its UDS server — that's exercised by other tests already.
The point of this module is to pin the *gate's* behaviour: which ops
check peer creds, what rejections look like, what evidence gets stamped.
"""
from __future__ import annotations

import os
import tempfile
from decimal import Decimal
from typing import Any, Optional

import pytest

from adapter.invariants import (
    PeerAuthenticationPolicy,
    SpendingCap,
)
from adapter.peer_credentials import PeerCredentials
from daemon.server import CageDaemon


# ── fixtures ────────────────────────────────────────────────────────────────


@pytest.fixture
def daemon(tmp_path) -> CageDaemon:
    """Stand up a CageDaemon without starting the UDS server.

    We only drive ``dispatch`` directly; no socket ever opens. This keeps
    the tests fast and deterministic.
    """
    # Unused socket path — the daemon never calls ``serve_forever``.
    sock = os.path.join(tempfile.gettempdir(), f"peer-auth-{os.getpid()}.sock")
    return CageDaemon(socket_path=sock, revision_log_path=tmp_path / "rev.jsonl")


def _install_peer_policy(daemon: CageDaemon, policy: PeerAuthenticationPolicy) -> None:
    """Shortcut: stuff a PeerAuthenticationPolicy into the active registry.

    We do this without going through ``declare_x402`` because admission
    would run the full prover chain; we only want to unit-test the
    peer-auth gate.
    """
    from adapter.x402_registry import X402Registry

    daemon._x402_registry = X402Registry(
        invariants=(*daemon._x402_registry.invariants, policy),
    )


# ── basic gate semantics ────────────────────────────────────────────────────


def test_mutation_allowed_when_no_policy_active(daemon: CageDaemon):
    """Preserves pre-v0.22.0 behaviour: no policy ⇒ no auth gate."""
    resp = daemon.dispatch(
        {"op": "declare_x402", "invariants": []},
        peer=None,
    )
    # The op-specific path will either accept or reject, but NOT with a
    # peer_auth_denied category.
    assert resp.get("category") != "peer_auth_denied"


def test_read_only_op_bypasses_peer_auth(daemon: CageDaemon):
    """Health / status / check_payment never hit the auth gate."""
    _install_peer_policy(daemon, PeerAuthenticationPolicy(
        allowed_peer_uids=frozenset({501}),
    ))
    # Even with NO peer info, a status op succeeds.
    resp = daemon.dispatch({"op": "status"}, peer=None)
    assert resp.get("verdict") == "ok"
    # And a health op works equally well.
    resp = daemon.dispatch({"op": "health"}, peer=None)
    assert resp.get("verdict") == "ok"


def test_mutation_rejected_when_peer_cred_missing(daemon: CageDaemon):
    """require_peer_uid=True + peer=None ⇒ explicit rejection."""
    _install_peer_policy(daemon, PeerAuthenticationPolicy(
        allowed_peer_uids=frozenset({501}),
        require_peer_uid=True,
    ))
    resp = daemon.dispatch(
        {"op": "declare_x402", "invariants": []},
        peer=None,
    )
    assert resp["verdict"] == "error"
    assert resp["category"] == "peer_auth_denied"
    assert "peer credentials required" in resp["reason"].lower()
    assert resp["peer_uid"] is None


def test_mutation_rejected_for_unknown_uid(daemon: CageDaemon):
    _install_peer_policy(daemon, PeerAuthenticationPolicy(
        allowed_peer_uids=frozenset({501}),
    ))
    peer = PeerCredentials(uid=999, source="SO_PEERCRED")
    resp = daemon.dispatch(
        {"op": "declare_x402", "invariants": []},
        peer=peer,
    )
    assert resp["verdict"] == "error"
    assert resp["category"] == "peer_auth_denied"
    assert resp["peer_uid"] == 999
    assert "not admitted" in resp["reason"].lower()


def test_mutation_allowed_for_admitted_uid(daemon: CageDaemon):
    """Peer with an allowed uid + no claim requirement passes the gate."""
    _install_peer_policy(daemon, PeerAuthenticationPolicy(
        allowed_peer_uids=frozenset({501}),
    ))
    peer = PeerCredentials(uid=501, gid=20, pid=1234, source="SO_PEERCRED")
    # We expect the gate to pass; the op itself may still reject for
    # its own reasons (malformed invariants, etc) — but NOT for auth.
    resp = daemon.dispatch(
        {"op": "declare_x402", "invariants": []},
        peer=peer,
    )
    assert resp.get("category") != "peer_auth_denied"


def test_mutation_rejected_when_actor_claim_required_but_missing(
    daemon: CageDaemon,
):
    _install_peer_policy(daemon, PeerAuthenticationPolicy(
        allowed_peer_uids=frozenset({501}),
        allowed_actor_claims=frozenset({"ops-team"}),
    ))
    peer = PeerCredentials(uid=501, source="SO_PEERCRED")
    # No actor_id in payload → should be rejected (set is non-empty).
    resp = daemon.dispatch(
        {"op": "declare_x402", "invariants": []},
        peer=peer,
    )
    assert resp["verdict"] == "error"
    assert resp["category"] == "peer_auth_denied"


def test_mutation_allowed_with_valid_actor_id(daemon: CageDaemon):
    _install_peer_policy(daemon, PeerAuthenticationPolicy(
        allowed_peer_uids=frozenset({501}),
        allowed_actor_claims=frozenset({"ops-team"}),
    ))
    peer = PeerCredentials(uid=501, source="SO_PEERCRED")
    resp = daemon.dispatch(
        {
            "op": "declare_x402",
            "invariants": [],
            "actor_id": "ops-team",
        },
        peer=peer,
    )
    assert resp.get("category") != "peer_auth_denied"


def test_mutation_rejected_when_signed_claim_required_but_unsigned(
    daemon: CageDaemon,
):
    _install_peer_policy(daemon, PeerAuthenticationPolicy(
        allowed_peer_uids=frozenset({501}),
        allowed_signing_keys=frozenset({"key-abc"}),
        require_signed_actor_claim=True,
    ))
    peer = PeerCredentials(uid=501, source="SO_PEERCRED")
    resp = daemon.dispatch(
        {
            "op": "declare_x402",
            "invariants": [],
            "actor_id": "ops-team",  # plain claim is insufficient.
        },
        peer=peer,
    )
    assert resp["verdict"] == "error"
    assert resp["category"] == "peer_auth_denied"


def test_mutation_allowed_with_signed_claim(daemon: CageDaemon):
    _install_peer_policy(daemon, PeerAuthenticationPolicy(
        allowed_peer_uids=frozenset({501}),
        allowed_signing_keys=frozenset({"key-abc"}),
        require_signed_actor_claim=True,
    ))
    peer = PeerCredentials(uid=501, source="SO_PEERCRED")
    resp = daemon.dispatch(
        {
            "op": "declare_x402",
            "invariants": [],
            "actor_claim_signature_key_id": "key-abc",
        },
        peer=peer,
    )
    assert resp.get("category") != "peer_auth_denied"


# ── peer evidence stamping ──────────────────────────────────────────────────


def test_peer_evidence_is_jsonable(daemon: CageDaemon):
    """The daemon exposes a structured peer-evidence projection."""
    import json

    peer = PeerCredentials(
        uid=501, gid=20, pid=1234, source="SO_PEERCRED",
    )
    evidence = daemon.peer_evidence(peer)
    # Round-trip through JSON — no custom types bleed through.
    blob = json.dumps(evidence)
    restored = json.loads(blob)
    assert restored == {
        "peer_uid": 501,
        "peer_gid": 20,
        "peer_pid": 1234,
        "peer_source": "SO_PEERCRED",
    }


def test_peer_evidence_handles_none(daemon: CageDaemon):
    """None peer cleanly projects to an all-None evidence block."""
    evidence = daemon.peer_evidence(None)
    assert evidence == {
        "peer_uid": None,
        "peer_gid": None,
        "peer_pid": None,
        "peer_source": None,
    }


# ── which ops are gated ────────────────────────────────────────────────────


def test_every_mutation_op_is_gated(daemon: CageDaemon):
    """Every member of _MUTATION_OPS fails auth when creds missing."""
    _install_peer_policy(daemon, PeerAuthenticationPolicy(
        allowed_peer_uids=frozenset({501}),
    ))
    for op in CageDaemon._MUTATION_OPS:
        resp = daemon.dispatch({"op": op}, peer=None)
        assert resp["category"] == "peer_auth_denied", (
            f"op={op} was not gated; got {resp!r}"
        )
