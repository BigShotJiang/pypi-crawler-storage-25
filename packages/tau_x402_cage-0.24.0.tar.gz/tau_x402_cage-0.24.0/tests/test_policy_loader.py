"""Tests for the YAML policy loader + `init` scaffolding."""
from __future__ import annotations

from decimal import Decimal
from pathlib import Path

import pytest

from adapter.invariants import (
    CounterpartyConstraint,
    MaxPerCall,
    ProviderAllowlist,
    RetryRateLimit,
    RollingWindowCap,
    SpendingCap,
)
from adapter.policy_loader import (
    CageConfig,
    PolicyLoaderError,
    load_policy,
    write_starter_compose,
    write_starter_policy,
)


def _write(tmp_path: Path, content: str, name: str = "policy.yaml") -> Path:
    p = tmp_path / name
    p.write_text(content, encoding="utf-8")
    return p


class TestStarterPolicy:
    def test_init_writes_parseable_policy(self, tmp_path: Path) -> None:
        out = tmp_path / "policy.yaml"
        write_starter_policy(out)
        loaded = load_policy(out)
        # Starter includes all six clean invariant kinds
        kinds = {type(i).__name__ for i in loaded.invariants}
        assert "MaxPerCall" in kinds
        assert "SpendingCap" in kinds
        assert "ProviderAllowlist" in kinds
        assert "RetryRateLimit" in kinds
        assert "RollingWindowCap" in kinds

    def test_init_refuses_overwrite(self, tmp_path: Path) -> None:
        out = tmp_path / "policy.yaml"
        write_starter_policy(out)
        with pytest.raises(PolicyLoaderError, match="refusing to overwrite"):
            write_starter_policy(out)

    def test_starter_compose_written(self, tmp_path: Path) -> None:
        out = tmp_path / "docker-compose.yaml"
        write_starter_compose(out)
        text = out.read_text()
        assert "ghcr.io/jme-tau/tau-x402-cage" in text
        assert "/tmp/tau-x402-cage.sock" in text


class TestLoadPolicy:
    def test_basic_mixed_invariants(self, tmp_path: Path) -> None:
        p = _write(tmp_path, """\
version: 1
policy:
  - kind: max_per_call
    max_amount: "50"
  - kind: spending_cap
    max_amount: "1000"
    scope: per_window
    window_seconds: 3600
  - kind: provider_allowlist
    providers:
      - anthropic
      - openai
""")
        loaded = load_policy(p)
        assert len(loaded.invariants) == 3
        mpc, cap, allow = loaded.invariants
        assert isinstance(mpc, MaxPerCall)
        assert mpc.max_amount == Decimal("50")
        assert isinstance(cap, SpendingCap)
        assert cap.window_seconds == 3600
        assert isinstance(allow, ProviderAllowlist)
        assert allow.providers == frozenset({"anthropic", "openai"})

    def test_retry_and_rolling_and_counterparty(self, tmp_path: Path) -> None:
        p = _write(tmp_path, """\
version: 1
policy:
  - kind: retry_rate_limit
    min_gap_seconds: 45
  - kind: rolling_window_cap
    max_count: 10
    window_seconds: 60
    group_by: counterparty
  - kind: counterparty_constraint
    approved_ids:
      - vendor_a
    sanctioned_ids: []
""")
        loaded = load_policy(p)
        rl, win, cp = loaded.invariants
        assert isinstance(rl, RetryRateLimit) and rl.min_gap_seconds == 45
        assert isinstance(win, RollingWindowCap) and win.group_by == "counterparty"
        assert isinstance(cp, CounterpartyConstraint)
        assert cp.approved_ids == frozenset({"vendor_a"})

    def test_missing_file(self) -> None:
        with pytest.raises(PolicyLoaderError, match="not found"):
            load_policy("/tmp/does-not-exist-x402.yaml")

    def test_wrong_version(self, tmp_path: Path) -> None:
        p = _write(tmp_path, "version: 2\npolicy: []\n")
        with pytest.raises(PolicyLoaderError, match="version"):
            load_policy(p)

    def test_unknown_kind_points_to_offending_entry(self, tmp_path: Path) -> None:
        p = _write(tmp_path, """\
version: 1
policy:
  - kind: not_a_real_kind
    max_amount: "1"
""")
        with pytest.raises(PolicyLoaderError, match="unknown invariant kind"):
            load_policy(p)

    def test_malformed_entry_surfaces_index(self, tmp_path: Path) -> None:
        p = _write(tmp_path, """\
version: 1
policy:
  - kind: max_per_call
    max_amount: not-a-decimal
""")
        with pytest.raises(PolicyLoaderError, match="entry #0"):
            load_policy(p)

    def test_policy_must_be_list(self, tmp_path: Path) -> None:
        p = _write(tmp_path, "version: 1\npolicy:\n  kind: max_per_call\n")
        with pytest.raises(PolicyLoaderError, match="'policy' must be a list"):
            load_policy(p)


class TestCageBlock:
    def test_missing_cage_block_defaults_compat(self, tmp_path: Path) -> None:
        p = _write(tmp_path, "version: 1\npolicy:\n  - kind: max_per_call\n    max_amount: \"10\"\n")
        loaded = load_policy(p)
        assert loaded.cage_config.prover_mode == "compat"
        assert loaded.cage_config.fail_closed_on_inconclusive is True
        assert loaded.cage_config.semantic_fragment == "v1"

    def test_explicit_strict_mode(self, tmp_path: Path) -> None:
        p = _write(tmp_path, """\
cage:
  prover_mode: strict
  fail_closed_on_inconclusive: true
  semantic_fragment: v1
version: 1
policy:
  - kind: max_per_call
    max_amount: "10"
""")
        loaded = load_policy(p)
        assert loaded.cage_config.prover_mode == "strict"

    def test_invalid_mode_rejected(self, tmp_path: Path) -> None:
        p = _write(tmp_path, """\
cage:
  prover_mode: bogus
version: 1
policy: []
""")
        with pytest.raises(PolicyLoaderError, match="prover_mode"):
            load_policy(p)

    def test_strict_requires_fail_closed(self, tmp_path: Path) -> None:
        p = _write(tmp_path, """\
cage:
  prover_mode: strict
  fail_closed_on_inconclusive: false
version: 1
policy: []
""")
        with pytest.raises(PolicyLoaderError, match="fail_closed_on_inconclusive"):
            load_policy(p)

    def test_unknown_semantic_fragment_rejected(self, tmp_path: Path) -> None:
        p = _write(tmp_path, """\
cage:
  semantic_fragment: v99
version: 1
policy: []
""")
        with pytest.raises(PolicyLoaderError, match="semantic_fragment"):
            load_policy(p)

    def test_cage_block_standalone_default_valid(self) -> None:
        cfg = CageConfig()
        validated = cfg.validated()
        assert validated.prover_mode == "compat"


class TestTauTimeoutMs:
    def test_default_is_10000(self, tmp_path: Path) -> None:
        p = _write(tmp_path, "version: 1\npolicy: []\n")
        loaded = load_policy(p)
        assert loaded.cage_config.tau_timeout_ms == 10000

    def test_parsed_from_cage_block(self, tmp_path: Path) -> None:
        p = _write(tmp_path, """\
cage:
  tau_timeout_ms: 2500
version: 1
policy: []
""")
        loaded = load_policy(p)
        assert loaded.cage_config.tau_timeout_ms == 2500

    def test_zero_rejected(self, tmp_path: Path) -> None:
        p = _write(tmp_path, """\
cage:
  tau_timeout_ms: 0
version: 1
policy: []
""")
        with pytest.raises(PolicyLoaderError, match="tau_timeout_ms"):
            load_policy(p)

    def test_negative_rejected(self, tmp_path: Path) -> None:
        p = _write(tmp_path, """\
cage:
  tau_timeout_ms: -1
version: 1
policy: []
""")
        with pytest.raises(PolicyLoaderError, match="tau_timeout_ms"):
            load_policy(p)

    def test_non_integer_rejected(self, tmp_path: Path) -> None:
        p = _write(tmp_path, """\
cage:
  tau_timeout_ms: "abc"
version: 1
policy: []
""")
        with pytest.raises(PolicyLoaderError, match="tau_timeout_ms"):
            load_policy(p)

    def test_standalone_default_tau_timeout_is_10000(self) -> None:
        cfg = CageConfig()
        assert cfg.tau_timeout_ms == 10000
        assert cfg.validated().tau_timeout_ms == 10000

    def test_standalone_invalid_tau_timeout_rejected(self) -> None:
        with pytest.raises(PolicyLoaderError, match="tau_timeout_ms"):
            CageConfig(tau_timeout_ms=0).validated()
        with pytest.raises(PolicyLoaderError, match="tau_timeout_ms"):
            CageConfig(tau_timeout_ms=-5).validated()
