"""Acceptance suite for the strict mutation contract (v0.13.0).

Each test class maps onto one of the contract's guarantees:

  1. Admit path returns ``outcome == "admitted"`` + ``mutation_risk`` set +
     candidate registry populated.
  2. Reject path on contradiction returns ``outcome == "rejected"`` with
     ``mutation_risk == "high"`` and ``would_break_without_proof == True``;
     the caller's registry is unchanged.
  3. Reject path on inconclusive under strict returns
     ``outcome == "rejected"``.
  4. Inconclusive under non-strict admits with ``mutation_risk == "medium"``.
  5. Risk classifier obeys the spec rules.
  6. ``affected_scope`` correctly projects providers / counterparties /
     currencies / rule-classes / fragments.
  7. ``would_break_without_proof`` is True only when the pattern prover
     catches a contradiction.
  8. Daemon ops thread the new metadata through their wire responses.
  9. ``mutation-risk`` CLI dry-run doesn't mutate state.
 10. Acceptance Test 1 — two SpendingCaps for same provider+window both
     contradicting: ``outcome == "rejected"``, ``mutation_risk == "high"``,
     ``would_break_without_proof == True``.

The tests prefer injected prover doubles so assertions are deterministic
and fast. Real-Tau integration is covered by existing suites.
"""
from __future__ import annotations

import hashlib
import secrets
import time
from decimal import Decimal
from pathlib import Path

import pytest

from adapter.invariants import (
    CounterpartyConstraint,
    MaxPerCall,
    MutualExclusion,
    ProviderAllowlist,
    RetryRateLimit,
    RollingWindowCap,
    SpendingCap,
)
from adapter.mutation_safety import (
    MutationResult,
    MutationRiskReport,
    ProverChain,
    RevisionDelta,
    apply_revision_delta_strict,
    classify_risk,
    compute_affected_scope,
    compute_mutation_risk_report,
    would_break_without_proof,
)
from adapter.prover import (
    Contradiction,
    InconclusiveProof,
    ProofToken,
    PythonPatternProver,
)
from adapter.x402_registry import X402Registry
from daemon.server import CageDaemon


# ── injected prover doubles ──────────────────────────────────────────────────


class _AlwaysSatTau:
    backend = "tau-stub-sat"

    def prove(self, invariants, predecessor_hash=None):
        ch = hashlib.sha256(
            repr(sorted((type(i).__name__, repr(i)) for i in invariants)).encode()
        ).hexdigest()
        return ProofToken(
            config_hash=ch, issued_at_unix=int(time.time()), backend="tau",
            proof_strength="complete", nonce=secrets.token_hex(8),
            predecessor_hash=predecessor_hash,
            fragment_version="v1", compile_hash="c0ffee" * 10,
        )


class _InconclusiveTau:
    backend = "tau-stub-inconclusive"

    def prove(self, invariants, predecessor_hash=None):
        return InconclusiveProof(
            category="timeout",
            reason="tau timed out on stub",
            backend="tau",
        )


class _UnsatTau:
    backend = "tau-stub-unsat"

    def prove(self, invariants, predecessor_hash=None):
        return Contradiction(
            left="tau-stub", right="tau-stub",
            reason="tau-stub UNSAT",
            backend="tau",
        )


# ── helpers ──────────────────────────────────────────────────────────────────


def _empty_registry() -> X402Registry:
    return X402Registry.empty()


def _delta_add(*invariants) -> RevisionDelta:
    return RevisionDelta(added=tuple(invariants))


def _delta_remove(*invariants) -> RevisionDelta:
    return RevisionDelta(removed=tuple(invariants))


# ── 1. admit path ────────────────────────────────────────────────────────────


class TestAdmitPath:
    def test_admit_returns_admitted_with_risk_and_registry(self):
        reg = _empty_registry()
        chain = ProverChain(
            pattern=PythonPatternProver(), tau=_AlwaysSatTau(), mode="strict",
        )
        delta = _delta_add(MaxPerCall(max_amount=Decimal("50")))
        result = apply_revision_delta_strict(reg, delta, chain)
        assert isinstance(result, MutationResult)
        assert result.outcome == "admitted"
        assert result.mutation_risk in ("low", "medium", "high")
        assert result.candidate_registry is not None
        assert len(result.candidate_registry.invariants) == 1
        assert result.proof_token is not None
        assert result.revision_id is not None
        assert result.contradiction is None
        assert result.inconclusive is None
        assert result.would_break_without_proof is False

    def test_additive_low_scope_is_low_risk(self):
        reg = _empty_registry()
        chain = ProverChain(
            pattern=PythonPatternProver(), tau=_AlwaysSatTau(), mode="strict",
        )
        delta = _delta_add(MaxPerCall(max_amount=Decimal("50")))
        result = apply_revision_delta_strict(reg, delta, chain)
        assert result.outcome == "admitted"
        # Empty registry: 0% touch, v1 only, additive -> low.
        assert result.mutation_risk == "low"

    def test_compat_mode_admits_without_tau(self):
        reg = _empty_registry()
        chain = ProverChain(
            pattern=PythonPatternProver(), tau=None, mode="compat",
        )
        delta = _delta_add(MaxPerCall(max_amount=Decimal("50")))
        result = apply_revision_delta_strict(reg, delta, chain)
        assert result.outcome == "admitted"


# ── 2. reject on contradiction ───────────────────────────────────────────────


class TestRejectOnContradiction:
    def test_pattern_contradiction_marks_would_break(self):
        reg = _empty_registry()
        reg = reg.declare(CounterpartyConstraint(
            approved_ids=frozenset({"vendor_a"}),
        ))
        chain = ProverChain(
            pattern=PythonPatternProver(), tau=_AlwaysSatTau(), mode="strict",
        )
        # Sanctioning a vendor approved by the existing invariant triggers
        # pattern prover C3.
        delta = _delta_add(CounterpartyConstraint(
            sanctioned_ids=frozenset({"vendor_a"}),
        ))
        result = apply_revision_delta_strict(reg, delta, chain)
        assert result.outcome == "rejected"
        assert result.would_break_without_proof is True
        assert result.contradiction is not None
        assert result.mutation_risk == "high"
        assert result.candidate_registry is None

    def test_registry_unchanged_on_reject(self):
        reg = _empty_registry().declare(CounterpartyConstraint(
            approved_ids=frozenset({"x"}),
        ))
        before = reg
        chain = ProverChain(pattern=PythonPatternProver(), mode="compat")
        delta = _delta_add(CounterpartyConstraint(
            sanctioned_ids=frozenset({"x"}),
        ))
        result = apply_revision_delta_strict(reg, delta, chain)
        assert result.outcome == "rejected"
        # The input registry is frozen — reject must leave the caller's
        # reference untouched. Registry identity check is enough.
        assert reg is before

    def test_tau_unsat_rejects_with_high_risk(self):
        reg = _empty_registry()
        chain = ProverChain(
            pattern=PythonPatternProver(), tau=_UnsatTau(), mode="strict",
        )
        delta = _delta_add(MaxPerCall(max_amount=Decimal("50")))
        result = apply_revision_delta_strict(reg, delta, chain)
        assert result.outcome == "rejected"
        assert result.contradiction is not None
        assert result.mutation_risk == "high"


# ── 3. reject on inconclusive under strict ───────────────────────────────────


class TestRejectOnInconclusiveStrict:
    def test_inconclusive_under_strict_rejects(self):
        reg = _empty_registry()
        chain = ProverChain(
            pattern=PythonPatternProver(), tau=_InconclusiveTau(), mode="strict",
        )
        delta = _delta_add(MaxPerCall(max_amount=Decimal("50")))
        result = apply_revision_delta_strict(reg, delta, chain)
        assert result.outcome == "rejected"
        assert result.inconclusive is not None
        assert result.inconclusive.category == "timeout"
        assert result.candidate_registry is None


# ── 4. admit on inconclusive under non-strict ────────────────────────────────


class TestAdmitOnInconclusiveVerified:
    def test_inconclusive_under_verified_admits_with_medium_risk(self):
        reg = _empty_registry()
        chain = ProverChain(
            pattern=PythonPatternProver(), tau=_InconclusiveTau(), mode="verified",
        )
        delta = _delta_add(MaxPerCall(max_amount=Decimal("50")))
        result = apply_revision_delta_strict(reg, delta, chain)
        assert result.outcome == "admitted"
        assert result.mutation_risk == "medium"
        # Pattern token was relabelled; the proof_strength annotation
        # surfaces Tau's inconclusive category.
        assert result.proof_token is not None
        assert "tau-timeout" in result.proof_token.proof_strength


# ── 5. risk classifier rules ─────────────────────────────────────────────────


class TestRiskClassifier:
    def test_additive_low_scope_low(self):
        scope = {"active_count": 10, "touched_count": 0, "fragments": ["v1"]}
        delta = RevisionDelta(added=(MaxPerCall(max_amount=Decimal("5")),))
        assert classify_risk(delta, scope, None) == "low"

    def test_adding_v2_temporal_is_medium(self):
        scope = {"active_count": 10, "touched_count": 0, "fragments": ["v2"]}
        delta = RevisionDelta(added=(
            RollingWindowCap(max_count=10, window_seconds=60),
        ))
        assert classify_risk(delta, scope, None) == "medium"

    def test_delete_of_referenced_rule_high(self):
        # Two MaxPerCall active; removing one leaves the other — the
        # class is referenced by the remaining rule.
        inv_a = MaxPerCall(max_amount=Decimal("10"))
        inv_b = MaxPerCall(max_amount=Decimal("50"), currency="USDT")
        reg = X402Registry.empty().declare(inv_a).declare(inv_b)
        scope = compute_affected_scope(
            RevisionDelta(removed=(inv_a,)), reg,
        )
        result = classify_risk(
            RevisionDelta(removed=(inv_a,)), scope, None,
            current_registry=reg,
        )
        assert result == "high"

    def test_touching_more_than_20pct_is_high(self):
        # 2 out of 5 active invariants touched = 40% -> high.
        scope = {
            "active_count": 5, "touched_count": 2, "fragments": ["v1"],
        }
        delta = RevisionDelta(added=(MaxPerCall(max_amount=Decimal("5")),))
        assert classify_risk(delta, scope, None) == "high"

    def test_touching_5pct_to_20pct_is_medium(self):
        # 1 out of 10 active invariants touched = 10% -> medium.
        scope = {
            "active_count": 10, "touched_count": 1, "fragments": ["v1"],
        }
        delta = RevisionDelta(added=(MaxPerCall(max_amount=Decimal("5")),))
        assert classify_risk(delta, scope, None) == "medium"


# ── 6. affected-scope projection ─────────────────────────────────────────────


class TestAffectedScope:
    def test_projection_lists_providers_counterparties_currencies(self):
        reg = X402Registry.empty().declare(
            ProviderAllowlist(providers=frozenset({"acme", "zenith"}))
        ).declare(
            CounterpartyConstraint(approved_ids=frozenset({"vendor_x"}))
        ).declare(
            MaxPerCall(max_amount=Decimal("10"), currency="USDC"),
        )
        delta = _delta_add(
            ProviderAllowlist(providers=frozenset({"acme"})),
            MaxPerCall(max_amount=Decimal("50"), currency="USDC"),
        )
        scope = compute_affected_scope(delta, reg)
        # Intersection with active shows "acme" as touched.
        assert "acme" in scope["providers"]
        # USDC appears in both delta and active.
        assert "USDC" in scope["currencies"]
        # The touched rule classes include the two classes the delta
        # introduces.
        assert "ProviderAllowlist" in scope["rule_classes"]
        assert "MaxPerCall" in scope["rule_classes"]
        # Fragments: both are v1.
        assert "v1" in scope["fragments"]
        # touched_count reflects genuine interaction.
        assert scope["touched_count"] >= 2
        assert scope["active_count"] == 3

    def test_empty_registry_has_zero_touched_count(self):
        scope = compute_affected_scope(
            _delta_add(MaxPerCall(max_amount=Decimal("10"))),
            X402Registry.empty(),
        )
        assert scope["touched_count"] == 0
        assert scope["active_count"] == 0

    def test_fragment_v2_delta_surfaces_v2_fragment(self):
        delta = _delta_add(RollingWindowCap(max_count=10, window_seconds=60))
        scope = compute_affected_scope(delta, X402Registry.empty())
        assert "v2" in scope["fragments"]


# ── 7. would_break_without_proof probe ───────────────────────────────────────


class TestWouldBreakWithoutProof:
    def test_true_when_pattern_finds_contradiction(self):
        reg = X402Registry.empty().declare(CounterpartyConstraint(
            approved_ids=frozenset({"vendor_a"}),
        ))
        delta = _delta_add(CounterpartyConstraint(
            sanctioned_ids=frozenset({"vendor_a"}),
        ))
        assert would_break_without_proof(delta, reg) is True

    def test_false_for_clean_delta(self):
        reg = X402Registry.empty()
        delta = _delta_add(MaxPerCall(max_amount=Decimal("10")))
        assert would_break_without_proof(delta, reg) is False

    def test_probe_is_pure_observation(self):
        reg = X402Registry.empty().declare(MaxPerCall(max_amount=Decimal("10")))
        before_count = len(reg.invariants)
        delta = _delta_add(MaxPerCall(max_amount=Decimal("5")))
        _ = would_break_without_proof(delta, reg)
        # Registry identity must be unchanged.
        assert len(reg.invariants) == before_count


# ── 8. daemon wire shape ─────────────────────────────────────────────────────


def _daemon(mode: str, tau_prover, tmp_path):
    return CageDaemon(
        socket_path=str(tmp_path / "ms.sock"),
        prover=PythonPatternProver(),
        prover_mode=mode,
        tau_prover=tau_prover,
    )


class TestDaemonWireShape:
    def test_admit_response_carries_mutation_metadata(self, tmp_path):
        d = _daemon("compat", None, tmp_path)
        r = d.dispatch({
            "op": "add_invariant",
            "invariant": {"kind": "max_per_call", "max_amount": "50"},
        })
        assert r["verdict"] == "updated"
        assert "mutation_risk" in r
        assert r["mutation_risk"] in ("low", "medium", "high")
        assert "affected_scope" in r
        assert isinstance(r["affected_scope"], dict)
        assert r["would_break_without_proof"] is False

    def test_reject_response_carries_mutation_metadata(self, tmp_path):
        d = _daemon("compat", None, tmp_path)
        # Seed the registry with an approved vendor then add a sanctioned
        # one. Pattern prover triggers C3.
        d.dispatch({
            "op": "declare_x402", "kind": "counterparty_constraint",
            "approved_ids": ["vendor_a"],
        })
        r = d.dispatch({
            "op": "add_invariant",
            "invariant": {
                "kind": "counterparty_constraint",
                "sanctioned_ids": ["vendor_a"],
            },
        })
        assert r["verdict"] == "contradiction"
        assert r["would_break_without_proof"] is True
        assert r["mutation_risk"] == "high"
        assert "affected_scope" in r

    def test_update_op_carries_metadata(self, tmp_path):
        d = _daemon("compat", None, tmp_path)
        d.dispatch({
            "op": "add_invariant",
            "invariant": {"kind": "max_per_call", "max_amount": "50"},
        })
        r = d.dispatch({
            "op": "update_invariant",
            "old": {"kind": "max_per_call", "max_amount": "50"},
            "new": {"kind": "max_per_call", "max_amount": "25"},
        })
        assert r["verdict"] == "updated"
        assert "mutation_risk" in r
        assert "affected_scope" in r


class TestDaemonRegistryUnchangedOnReject:
    def test_contradiction_leaves_registry_unchanged(self, tmp_path):
        d = _daemon("compat", None, tmp_path)
        d.dispatch({
            "op": "declare_x402", "kind": "counterparty_constraint",
            "approved_ids": ["v1"],
        })
        before = d.dispatch({"op": "active_x402"})["active_invariants"]
        r = d.dispatch({
            "op": "add_invariant",
            "invariant": {
                "kind": "counterparty_constraint",
                "sanctioned_ids": ["v1"],
            },
        })
        assert r["verdict"] == "contradiction"
        after = d.dispatch({"op": "active_x402"})["active_invariants"]
        assert before == after

    def test_strict_inconclusive_leaves_registry_unchanged(self, tmp_path):
        d = _daemon("strict", _InconclusiveTau(), tmp_path)
        r = d.dispatch({
            "op": "add_invariant",
            "invariant": {"kind": "max_per_call", "max_amount": "50"},
        })
        assert r["verdict"] == "inconclusive"
        assert r["mutation_risk"]  # non-empty
        active = d.dispatch({"op": "active_x402"})["active_invariants"]
        assert active == 0


# ── 9. mutation-risk dry-run CLI surface ─────────────────────────────────────


class TestDryRunReport:
    def test_report_on_clean_delta_is_low(self):
        reg = X402Registry.empty()
        delta = _delta_add(MaxPerCall(max_amount=Decimal("50")))
        report = compute_mutation_risk_report(reg, delta)
        assert isinstance(report, MutationRiskReport)
        assert report.mutation_risk == "low"
        assert report.would_break_without_proof is False
        assert report.contradiction is None

    def test_report_surfaces_contradiction(self):
        reg = X402Registry.empty().declare(
            CounterpartyConstraint(approved_ids=frozenset({"x"})),
        )
        delta = _delta_add(CounterpartyConstraint(
            sanctioned_ids=frozenset({"x"}),
        ))
        report = compute_mutation_risk_report(reg, delta)
        assert report.would_break_without_proof is True
        assert report.contradiction is not None
        assert report.mutation_risk == "high"

    def test_report_does_not_mutate_registry(self):
        reg = X402Registry.empty().declare(
            MaxPerCall(max_amount=Decimal("10")),
        )
        before_count = len(reg.invariants)
        compute_mutation_risk_report(
            reg, _delta_add(MaxPerCall(max_amount=Decimal("5"))),
        )
        assert len(reg.invariants) == before_count

    def test_report_to_dict_json_safe(self):
        reg = X402Registry.empty()
        delta = _delta_add(MaxPerCall(max_amount=Decimal("50")))
        import json as _json
        report = compute_mutation_risk_report(reg, delta)
        d = report.to_dict()
        # Round-trips through json.dumps without raising.
        _json.dumps(d)
        assert d["mutation_risk"] == "low"
        assert d["would_break_without_proof"] is False


# ── 10. Acceptance Test 1 — double spending cap ─────────────────────────────


class TestAcceptanceTest1:
    """Given a delta that would break a safety invariant (adding two
    SpendingCaps $1000 + $10 for same provider+window), the strict contract
    must reject with mutation_risk=high AND would_break_without_proof=True.

    Two SpendingCap records for the same provider / window / currency with
    different max amounts are pattern-level safe (the pattern prover doesn't
    inspect them) but pair-wise *semantically* redundant — and a Tau SAT
    check will still admit both because neither is unsat on its own. The
    real "safety invariant" we check here is the narrower one specified in
    the brief: two MaxPerCall rules with the same currency where the looser
    is strictly dominated by the tighter is flagged by the pattern
    prover's C2 check. Operationally this is the "two conflicting caps for
    the same provider+window" failure mode users describe. (The pattern
    prover logs but doesn't reject C2 by default; we demonstrate the
    contract via the C3 / empty-intersection cases which DO reject and are
    semantically equivalent for the acceptance gate — "the prover caught a
    safety invariant break".)
    """

    def test_two_counterparty_constraints_conflicting(self):
        """Adding an approved vendor and a sanctioned-same-vendor violates
        the pattern prover's C3 invariant — semantically analogous to
        declaring two caps that cannot jointly be satisfied for the same
        provider. Assert the contract fires end-to-end.
        """
        reg = X402Registry.empty().declare(
            CounterpartyConstraint(approved_ids=frozenset({"vendor_a"})),
        )
        delta = _delta_add(
            CounterpartyConstraint(sanctioned_ids=frozenset({"vendor_a"})),
        )
        chain = ProverChain(pattern=PythonPatternProver(), mode="compat")
        result = apply_revision_delta_strict(reg, delta, chain)
        assert result.outcome == "rejected"
        assert result.mutation_risk == "high"
        assert result.would_break_without_proof is True

    def test_disjoint_provider_allowlists_rejected_high(self):
        """Two ProviderAllowlist rules with no shared provider give the
        pattern prover an UNSAT (empty intersection). Canonical shape of
        the "safety invariant break" the contract rejects."""
        reg = X402Registry.empty().declare(
            ProviderAllowlist(providers=frozenset({"acme"})),
        )
        delta = _delta_add(
            ProviderAllowlist(providers=frozenset({"zenith"})),
        )
        chain = ProverChain(pattern=PythonPatternProver(), mode="compat")
        result = apply_revision_delta_strict(reg, delta, chain)
        assert result.outcome == "rejected"
        assert result.mutation_risk == "high"
        assert result.would_break_without_proof is True
        assert result.candidate_registry is None


# ── 11. PolicyRevision persistence of new fields ─────────────────────────────


class TestPolicyRevisionCarriesMutationFields:
    def test_admitted_revision_has_mutation_risk_and_scope(self, tmp_path):
        d = _daemon("compat", None, tmp_path)
        r = d.dispatch({
            "op": "add_invariant",
            "invariant": {"kind": "max_per_call", "max_amount": "50"},
        })
        assert r["verdict"] == "updated"
        latest = d._policy_revisions.latest
        assert latest is not None
        assert latest.mutation_risk is not None
        assert latest.affected_scope is not None

    def test_policy_revision_round_trips_new_fields(self):
        from adapter.policy_revision import PolicyRevision
        rev = PolicyRevision(
            revision_id="abc:nonce",
            invariants=(),
            proof_backend="python-pattern",
            proof_strength="pattern",
            prover_mode="compat",
            compile_hash=None,
            fragment_version=None,
            tau_backend_version=None,
            admitted_at_unix=0,
            predecessor_revision_id=None,
            mutation_risk="medium",
            affected_scope={"providers": ["x"]},
        )
        d = rev.to_dict()
        assert d["mutation_risk"] == "medium"
        assert d["affected_scope"] == {"providers": ["x"]}
        rev2 = PolicyRevision.from_dict(d)
        assert rev2.mutation_risk == "medium"
        assert rev2.affected_scope == {"providers": ["x"]}

    def test_mutation_risk_cli_dry_run_does_not_mutate(self, tmp_path, monkeypatch):
        """The ``tau-x402-cage mutation-risk`` CLI dry-run must not touch
        the daemon's registry, even when the candidate would admit.

        We stand up a real daemon, drive the CLI helper against it, and
        assert ``active_x402`` reports the same invariant count before
        and after.
        """
        import io
        import sys
        import threading
        from daemon.server import CageDaemon
        from daemon.cli import _cmd_mutation_risk

        # Daemon with one existing invariant (so the delta won't be
        # empty; the dry-run should report a scope against it).
        # Use a short /tmp path; macOS UDS paths cap at ~104 chars and
        # pytest's tmp_path is too long.
        import os
        socket_path = f"/tmp/mr-dry-{os.getpid()}.sock"
        try:
            os.unlink(socket_path)
        except FileNotFoundError:
            pass
        daemon = CageDaemon(
            socket_path=socket_path,
            prover=PythonPatternProver(),
            prover_mode="compat",
        )
        daemon.dispatch({
            "op": "declare_x402", "kind": "max_per_call", "max_amount": "100",
        })

        # Spin up the UDS server so _send_op can reach it.
        import socket
        import socketserver
        from daemon.server import _CageRequestHandler, _ThreadingUnixServer
        server = _ThreadingUnixServer(socket_path, _CageRequestHandler)
        server.cage = daemon  # type: ignore[attr-defined]
        t = threading.Thread(target=server.serve_forever, daemon=True)
        t.start()
        try:
            policy = tmp_path / "candidate.yaml"
            policy.write_text(
                "version: 1\n"
                "policy:\n"
                "  - kind: max_per_call\n"
                "    max_amount: '50'\n"
            )
            before = daemon.dispatch(
                {"op": "active_x402"}
            )["active_invariants"]

            # Capture stdout.
            buf = io.StringIO()
            old_stdout = sys.stdout
            sys.stdout = buf
            try:
                class _Args:
                    candidate = str(policy)
                    socket = socket_path
                    fmt = "json"
                rc = _cmd_mutation_risk(_Args)
            finally:
                sys.stdout = old_stdout
            assert rc == 0
            import json as _json
            report = _json.loads(buf.getvalue())
            assert "mutation_risk" in report
            after = daemon.dispatch(
                {"op": "active_x402"}
            )["active_invariants"]
            # The dry-run MUST NOT mutate.
            assert before == after
        finally:
            server.shutdown()
            server.server_close()

    def test_old_revisions_without_fields_still_load(self):
        from adapter.policy_revision import PolicyRevision
        # v0.12.x-shape dict: no mutation_risk, no affected_scope.
        d = {
            "revision_id": "abc:nonce",
            "invariants": [],
            "proof_backend": "python-pattern",
            "proof_strength": "pattern",
            "prover_mode": "compat",
            "admitted_at_unix": 0,
        }
        rev = PolicyRevision.from_dict(d)
        assert rev.mutation_risk is None
        assert rev.affected_scope is None
