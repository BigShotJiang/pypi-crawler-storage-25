"""Tests for v0.22.0 BranchRespectsCore wire-up into Guaranteed Mode.

Covers:
  * Rule-level ``affected_scope["overrides"][rule_id] = ("core", ...)``
    provenance on feature branches.
  * Default transition validator now carries BranchRespectsCore.
  * Merge-path union of overrides across predecessor + branch.
  * Back-compat: legacy OverridesMustExpire shape still works
    alongside v0.22.0 tuple-valued overrides in the same map.
  * Main-branch transitions are free to mutate (rule-level check
    scoped to feature branches, per the brief).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from typing import Any, Iterable, Mapping, Optional

import pytest

from adapter.cross_revision import (
    CORE_PROTECTION_TAG,
    BranchRespectsCore,
    CrossRevisionValidator,
    NoWeakening,
    OverridesMustExpire,
    _rule_level_overrides,
)
from adapter.guaranteed_mutation import (
    GuaranteedMutationPipeline,
    MAX_OVERRIDE_DURATION_SECONDS,
    _default_transition_validator,
)
from adapter.invariants import SpendingCap
from adapter.policy_revision import PolicyRevision


# ── helpers ──────────────────────────────────────────────────────────────────


def _rev(
    *,
    revision_id: str,
    invariants: tuple = (),
    predecessor: Optional[str] = None,
    depth: int = 0,
    branch: str = "main",
    affected_scope: Optional[dict] = None,
    merge_parent_ids: Optional[tuple] = None,
    admitted_at_unix: int = 1_713_000_000,
    proof_backend: str = "python-pattern",
) -> PolicyRevision:
    return PolicyRevision(
        revision_id=revision_id,
        invariants=invariants,
        proof_backend=proof_backend,
        proof_strength="pattern",
        prover_mode="compat",
        compile_hash=None,
        fragment_version=None,
        tau_backend_version=None,
        admitted_at_unix=admitted_at_unix,
        predecessor_revision_id=predecessor,
        delta={},
        revision_depth=depth,
        branch=branch,
        merge_parent_ids=merge_parent_ids,
        affected_scope=affected_scope,
    )


@dataclass(frozen=True)
class _StaticCandidateMutation:
    """Minimal ``mutation`` surface for GuaranteedMutationPipeline tests.

    The pipeline reads ``apply_to(current_revision)`` so this class
    presents a deterministic candidate without dragging in the full
    revision_runtime machinery.
    """
    candidate: PolicyRevision

    def apply_to(self, current_revision: PolicyRevision) -> PolicyRevision:
        return self.candidate


@dataclass(frozen=True)
class _FakeProofArtifact:
    """Minimum-shape artifact surfaced by our test prover."""
    artifact_id: str
    policy_revision_id: str
    proof_result: str = "consistent"
    artifact_hash: str = ""


@dataclass(frozen=True)
class _FakeProofResult:
    """Stand-in for GuaranteedProofResult (duck-typed against the pipeline)."""
    consistent: bool
    decisive: bool
    reason: str = ""
    artifact: Optional[_FakeProofArtifact] = None


class _DecisiveTestProver:
    """Test prover that always returns consistent + decisive.

    The pipeline's real prover needs a Tau binding at construction
    time; for our tests we only want to exercise the transition
    validator so we inject a short-circuit prover that presents a
    well-formed proof artifact.
    """

    def prove(self, candidate: Any) -> _FakeProofResult:
        rev_id = getattr(candidate, "revision_id", "test")
        return _FakeProofResult(
            consistent=True,
            decisive=True,
            reason="decisive test stub",
            artifact=_FakeProofArtifact(
                artifact_id="test-artifact",
                policy_revision_id=str(rev_id),
                proof_result="consistent",
            ),
        )


# ── 1. Feature-branch mutation of a core-protected rule rejects ────────────


class TestRuleLevelFeatureBranchFencing:
    def test_feature_branch_drops_core_rule_rejected(self) -> None:
        rule = BranchRespectsCore(core_branch_name="main")
        old = _rev(
            revision_id="r0",
            branch="feature",
            affected_scope={
                "overrides": {
                    "spending_cap_global": ("core",),
                },
            },
        )
        new = _rev(
            revision_id="r1",
            predecessor="r0",
            depth=1,
            branch="feature",
            affected_scope={"overrides": {}},
        )
        violations = rule.validate_transition(old, new, "feature")
        assert len(violations) == 1
        assert violations[0].category == "feature_branch_mutated_core_rule"
        assert "spending_cap_global" in violations[0].reason

    def test_feature_branch_demotes_core_rule_rejected(self) -> None:
        rule = BranchRespectsCore(core_branch_name="main")
        old = _rev(
            revision_id="r0",
            branch="feature",
            affected_scope={
                "overrides": {
                    "critical_rule": ("core", "audit"),
                },
            },
        )
        new = _rev(
            revision_id="r1",
            predecessor="r0",
            depth=1,
            branch="feature",
            affected_scope={
                "overrides": {
                    "critical_rule": ("audit",),  # dropped "core"
                },
            },
        )
        violations = rule.validate_transition(old, new, "feature")
        assert len(violations) == 1
        assert "demotes core-protected rule" in violations[0].reason

    def test_feature_branch_preserves_core_rule_allowed(self) -> None:
        """A feature-branch mutation that leaves the core tag intact passes."""
        rule = BranchRespectsCore(core_branch_name="main")
        old = _rev(
            revision_id="r0",
            branch="feature",
            affected_scope={
                "overrides": {"rule_a": ("core",)},
            },
        )
        new = _rev(
            revision_id="r1",
            predecessor="r0",
            depth=1,
            branch="feature",
            affected_scope={
                "overrides": {
                    "rule_a": ("core",),
                    "rule_b": ("audit",),  # new unprotected rule; fine
                },
            },
        )
        violations = rule.validate_transition(old, new, "feature")
        assert violations == ()

    def test_non_protected_rule_mutated_freely(self) -> None:
        """Mutating a rule without any core-protection tag is always fine."""
        rule = BranchRespectsCore(core_branch_name="main")
        old = _rev(
            revision_id="r0",
            branch="feature",
            affected_scope={
                "overrides": {"rule_a": ("audit",)},
            },
        )
        new = _rev(
            revision_id="r1",
            predecessor="r0",
            depth=1,
            branch="feature",
            affected_scope={"overrides": {}},
        )
        assert rule.validate_transition(old, new, "feature") == ()


# ── 2. Main-branch mutations pass through rule-level check ─────────────────


class TestMainBranchFreedom:
    def test_main_branch_can_drop_core_rule(self) -> None:
        """Rule-level fencing is feature-branch-scoped; main may mutate.

        Per the brief: "Protected rule can still be mutated on the main
        branch (feature branches are the restricted domain)."
        """
        rule = BranchRespectsCore(core_branch_name="main")
        old = _rev(
            revision_id="r0",
            branch="main",
            affected_scope={"overrides": {"rule_a": ("core",)}},
        )
        new = _rev(
            revision_id="r1",
            predecessor="r0",
            depth=1,
            branch="main",
            affected_scope={"overrides": {}},
        )
        assert rule.validate_transition(old, new, "main") == ()


# ── 3. Back-compat with empty overrides (no-op) ────────────────────────────


class TestBackCompatEmptyOverrides:
    def test_policies_without_overrides_pass(self) -> None:
        """Policies that don't declare protection classes are no-op'd."""
        rule = BranchRespectsCore(core_branch_name="main")
        old = _rev(
            revision_id="r0",
            branch="feature",
            affected_scope=None,
        )
        new = _rev(
            revision_id="r1",
            predecessor="r0",
            depth=1,
            branch="feature",
            affected_scope={},
        )
        assert rule.validate_transition(old, new, "feature") == ()

    def test_legacy_index_shape_ignored_by_rule_level(self) -> None:
        """TTL-override shape (dict values) doesn't conflict with core-protection."""
        rule = BranchRespectsCore(core_branch_name="main")
        old = _rev(
            revision_id="r0",
            branch="feature",
            affected_scope={
                "overrides": {
                    "0": {"expires_at_unix": 123},  # legacy shape
                    "rule_a": ("core",),           # v0.22.0 shape
                },
            },
        )
        new = _rev(
            revision_id="r1",
            predecessor="r0",
            depth=1,
            branch="feature",
            affected_scope={
                "overrides": {
                    "0": {"expires_at_unix": 456},
                    "rule_a": ("core",),
                },
            },
        )
        # Only the v0.22.0 rule matters to BranchRespectsCore; it's preserved.
        assert rule.validate_transition(old, new, "feature") == ()


# ── 4. _rule_level_overrides helper ────────────────────────────────────────


class TestExtractor:
    def test_extractor_filters_to_protected(self) -> None:
        rev = _rev(
            revision_id="r0",
            branch="feature",
            affected_scope={
                "overrides": {
                    "rule_protected": ("core", "audit"),
                    "rule_unprotected": ("audit",),
                    "ignore_legacy": {"expires_at_unix": 123},
                },
            },
        )
        overrides = _rule_level_overrides(rev, frozenset({CORE_PROTECTION_TAG}))
        assert set(overrides) == {"rule_protected"}
        assert overrides["rule_protected"] == frozenset({"core", "audit"})

    def test_extractor_accepts_lists(self) -> None:
        """Lists are accepted alongside tuples; both serialise to the same set."""
        rev = _rev(
            revision_id="r0",
            branch="feature",
            affected_scope={"overrides": {"rule_a": ["core"]}},
        )
        overrides = _rule_level_overrides(rev, frozenset({CORE_PROTECTION_TAG}))
        assert overrides["rule_a"] == frozenset({"core"})

    def test_extractor_handles_missing_scope(self) -> None:
        rev = _rev(revision_id="r0", affected_scope=None)
        assert _rule_level_overrides(rev, frozenset({CORE_PROTECTION_TAG})) == {}


# ── 5. Default transition validator carries BranchRespectsCore ─────────────


class TestDefaultTransitionValidator:
    def test_default_validator_includes_all_three(self) -> None:
        validator = _default_transition_validator()
        names = {type(i).__name__ for i in validator.invariants}
        assert names == {
            "NoWeakening",
            "OverridesMustExpire",
            "BranchRespectsCore",
        }

    def test_default_validator_fires_rule_level_check(self) -> None:
        """The pipeline's default validator picks up protection violations."""
        old = _rev(
            revision_id="r0",
            branch="feature",
            affected_scope={"overrides": {"rule_a": ("core",)}},
        )
        new = _rev(
            revision_id="r1",
            predecessor="r0",
            depth=1,
            branch="feature",
            affected_scope={"overrides": {}},
        )
        validator = _default_transition_validator()
        result = validator.validate(old, new, "feature")
        assert not result.valid
        categories = {v.category for v in result.violations}
        assert "feature_branch_mutated_core_rule" in categories


# ── 6. Integration with GuaranteedMutationPipeline.propose ─────────────────


class TestPipelineIntegration:
    def test_pipeline_rejects_feature_branch_core_mutation(self) -> None:
        """propose() on a feature-branch mutation that drops core rejects."""
        old = _rev(
            revision_id="r0",
            branch="feature",
            affected_scope={"overrides": {"rule_a": ("core",)}},
        )
        new = _rev(
            revision_id="r1",
            predecessor="r0",
            depth=1,
            branch="feature",
            affected_scope={"overrides": {}},
        )
        pipe = GuaranteedMutationPipeline(prover=_DecisiveTestProver())
        proposal = pipe.propose(
            current_revision=old,
            mutation=_StaticCandidateMutation(candidate=new),
            branch="feature",
        )
        assert not proposal.activatable
        assert proposal.failure is not None
        # Failure code in the real schema is REVISION_TRANSITION_VIOLATION
        failure_code = getattr(proposal.failure, "code", None)
        code_value = (
            failure_code.value if hasattr(failure_code, "value")
            else str(failure_code)
        )
        assert "REVISION_TRANSITION_VIOLATION" in code_value

    def test_pipeline_accepts_feature_branch_safe_mutation(self) -> None:
        """propose() on a feature-branch mutation that preserves core passes."""
        old = _rev(
            revision_id="r0",
            branch="feature",
            affected_scope={"overrides": {"rule_a": ("core",)}},
        )
        new = _rev(
            revision_id="r1",
            predecessor="r0",
            depth=1,
            branch="feature",
            affected_scope={"overrides": {"rule_a": ("core",)}},
        )
        pipe = GuaranteedMutationPipeline(prover=_DecisiveTestProver())
        proposal = pipe.propose(
            current_revision=old,
            mutation=_StaticCandidateMutation(candidate=new),
            branch="feature",
        )
        assert proposal.activatable, (
            f"Expected activatable proposal; got failure: "
            f"{proposal.failure!r}"
        )


# ── 7. Merge path unions overrides across predecessor + branch ─────────────


class TestMergeOverridesUnion:
    def test_merge_union_preserves_core_rules(self) -> None:
        """Merge commit whose resulting overrides map preserves the union.

        Merges into main bypass the rule-level check (main-branch
        mutations are free to rewrite). The union semantics live in the
        builder above the cross_revision layer; here we assert the
        BranchRespectsCore rule itself admits a union'd merge commit.
        """
        rule = BranchRespectsCore(core_branch_name="main")
        # Predecessor on main carries the core rule.
        old_main = _rev(
            revision_id="main_0",
            branch="main",
            affected_scope={"overrides": {"rule_a": ("core",)}},
        )
        # Merge commit on main unions predecessor + branch overrides.
        merged = _rev(
            revision_id="merge_1",
            predecessor="main_0",
            depth=1,
            branch="main",
            merge_parent_ids=("main_0", "feature_head"),
            proof_backend="three-way-merge",
            affected_scope={
                "overrides": {
                    "rule_a": ("core",),        # from main
                    "rule_b": ("core", "new"),  # from feature
                },
            },
        )
        # Main-branch domain: rule-level check is a no-op; class-level
        # check has no protected_classes so it also no-ops. Merge admits.
        assert rule.validate_transition(old_main, merged, "main") == ()

    def test_merge_to_main_that_drops_core_rule_still_ok_on_main(self) -> None:
        """Merge into main may rewrite overrides (main is the owner constituency)."""
        rule = BranchRespectsCore(core_branch_name="main")
        old_main = _rev(
            revision_id="main_0",
            branch="main",
            affected_scope={"overrides": {"rule_a": ("core",)}},
        )
        merged = _rev(
            revision_id="merge_1",
            predecessor="main_0",
            depth=1,
            branch="main",
            merge_parent_ids=("main_0", "feature_head"),
            proof_backend="three-way-merge",
            affected_scope={"overrides": {}},
        )
        # Rule-level check doesn't fire on main. Class-level check also
        # doesn't fire because protected_classes is empty. So no violation.
        assert rule.validate_transition(old_main, merged, "main") == ()


# ── 8. Legacy class-level behaviour preserved ──────────────────────────────


class TestLegacyClassLevelBehaviour:
    def test_legacy_merge_drop_still_rejected_when_classes_configured(self) -> None:
        """Callers who still use the class-level surface get identical behaviour."""
        rule = BranchRespectsCore(
            core_branch_name="main",
            protected_classes=frozenset({"SpendingCap"}),
        )
        old = _rev(
            revision_id="r0",
            branch="main",
            invariants=(SpendingCap(Decimal("10"), scope="per_tx"),),
        )
        new = _rev(
            revision_id="merge_1",
            predecessor="r0",
            depth=1,
            branch="main",
            merge_parent_ids=("r0", "feat_head"),
            proof_backend="three-way-merge",
            invariants=(),
        )
        violations = rule.validate_transition(old, new, "main")
        assert len(violations) == 1
        assert violations[0].category == "merge_dropped_protected_class"


# ── 9. Determinism + serialisation ─────────────────────────────────────────


class TestDeterminism:
    def test_overrides_round_trip_via_to_dict_from_dict(self) -> None:
        rev = _rev(
            revision_id="r0:nonce",
            branch="feature",
            affected_scope={
                "overrides": {"rule_a": ("core",)},
            },
        )
        d = rev.to_dict()
        rebuilt = PolicyRevision.from_dict(d)
        # Overrides survive the JSON round-trip. Lists are acceptable
        # after deserialisation because JSON doesn't preserve tuple
        # identity; _rule_level_overrides accepts either.
        overrides = _rule_level_overrides(rebuilt, frozenset({CORE_PROTECTION_TAG}))
        assert overrides["rule_a"] == frozenset({"core"})
