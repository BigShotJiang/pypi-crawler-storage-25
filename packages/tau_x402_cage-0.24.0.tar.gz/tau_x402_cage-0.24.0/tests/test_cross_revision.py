"""Tests for cross-revision compositional invariants (v0.14.0).

Covers the three shipped invariants (NoWeakening, OverridesMustExpire,
BranchRespectsCore), the validator container, env-driven wiring, daemon
integration (add_invariant that weakens a monitored limit is rejected),
CLI dry-run, and rehydration (cross-revision-rejected mutations are NOT
persisted to the revision log).
"""

from __future__ import annotations

import json
import os
import socket
import tempfile
import threading
import time
from decimal import Decimal
from pathlib import Path
from typing import Iterator

import pytest

from adapter.cross_revision import (
    BranchRespectsCore,
    CrossRevisionInvariant,
    CrossRevisionValidator,
    CrossRevisionViolation,
    NoWeakening,
    OverridesMustExpire,
    ValidationResult,
    build_validator_from_env,
)
from adapter.invariants import (
    CounterpartyConstraint,
    MaxPerCall,
    ProviderAllowlist,
    RetryRateLimit,
    SpendingCap,
)
from adapter.policy_revision import (
    CrossRevisionRejected,
    PolicyRevision,
    RevisionLog,
    RevisionLogError,
)
from daemon.server import CageDaemon


# ── helpers ──────────────────────────────────────────────────────────────────


def _revision(
    invariants: tuple,
    *,
    revision_id: str,
    predecessor: str | None = None,
    depth: int = 0,
    branch: str = "main",
    affected_scope: dict | None = None,
    admitted_at_unix: int = 1_713_000_000,
    merge_parent_ids: tuple[str, str] | None = None,
    proof_backend: str = "python-pattern",
) -> PolicyRevision:
    """Tiny factory so tests stay focused on the field that matters."""
    return PolicyRevision(
        revision_id=revision_id,
        invariants=invariants,
        proof_backend=proof_backend,
        proof_strength="pattern",
        prover_mode="compat",
        compile_hash=None,
        fragment_version=None,
        tau_backend_version=None,
        admitted_at_unix=admitted_at_unix,
        predecessor_revision_id=predecessor,
        delta={},
        revision_depth=depth,
        branch=branch,
        merge_parent_ids=merge_parent_ids,
        affected_scope=affected_scope,
    )


# ── NoWeakening ─────────────────────────────────────────────────────────────


class TestNoWeakening:
    def test_raising_spending_cap_on_main_is_rejected(self):
        rule = NoWeakening()
        old = _revision(
            (SpendingCap(Decimal("10"), scope="per_tx"),),
            revision_id="r0",
        )
        new = _revision(
            (SpendingCap(Decimal("100"), scope="per_tx"),),
            revision_id="r1",
            predecessor="r0",
            depth=1,
        )
        violations = rule.validate_transition(old, new, "main")
        assert len(violations) == 1
        v = violations[0]
        assert v.invariant_name == "NoWeakening"
        assert v.category == "weakened_spending_cap"
        assert "10" in v.reason and "100" in v.reason

    def test_lowering_spending_cap_is_clean(self):
        rule = NoWeakening()
        old = _revision(
            (SpendingCap(Decimal("100"), scope="per_tx"),),
            revision_id="r0",
        )
        new = _revision(
            (SpendingCap(Decimal("10"), scope="per_tx"),),
            revision_id="r1",
            predecessor="r0",
            depth=1,
        )
        assert rule.validate_transition(old, new, "main") == ()

    def test_new_cap_with_no_predecessor_is_clean(self):
        rule = NoWeakening()
        old = _revision((), revision_id="r0")
        new = _revision(
            (SpendingCap(Decimal("50"), scope="per_tx"),),
            revision_id="r1",
            predecessor="r0",
            depth=1,
        )
        assert rule.validate_transition(old, new, "main") == ()

    def test_removing_spending_cap_is_rejected_as_weakening(self):
        rule = NoWeakening()
        old = _revision(
            (SpendingCap(Decimal("100"), scope="per_tx"),),
            revision_id="r0",
        )
        new = _revision((), revision_id="r1", predecessor="r0", depth=1)
        violations = rule.validate_transition(old, new, "main")
        assert len(violations) == 1
        assert violations[0].category == "removed_spending_cap"

    def test_feature_branch_can_weaken_freely(self):
        rule = NoWeakening()
        old = _revision(
            (SpendingCap(Decimal("10"), scope="per_tx"),),
            revision_id="r0",
            branch="feature",
        )
        new = _revision(
            (SpendingCap(Decimal("100"), scope="per_tx"),),
            revision_id="r1",
            predecessor="r0",
            depth=1,
            branch="feature",
        )
        assert rule.validate_transition(old, new, "feature") == ()

    def test_max_per_call_raised_is_rejected(self):
        rule = NoWeakening()
        old = _revision(
            (MaxPerCall(Decimal("5")),),
            revision_id="r0",
        )
        new = _revision(
            (MaxPerCall(Decimal("50")),),
            revision_id="r1",
            predecessor="r0",
            depth=1,
        )
        violations = rule.validate_transition(old, new, "main")
        assert any(v.category == "weakened_max_per_call" for v in violations)

    def test_provider_allowlist_widened_is_rejected(self):
        rule = NoWeakening()
        old = _revision(
            (ProviderAllowlist(frozenset({"stripe"})),),
            revision_id="r0",
        )
        new = _revision(
            (ProviderAllowlist(frozenset({"stripe", "paypal"})),),
            revision_id="r1",
            predecessor="r0",
            depth=1,
        )
        violations = rule.validate_transition(old, new, "main")
        assert any(
            v.category == "weakened_provider_allowlist" for v in violations
        )

    def test_provider_allowlist_narrowed_is_clean(self):
        rule = NoWeakening()
        old = _revision(
            (ProviderAllowlist(frozenset({"stripe", "paypal"})),),
            revision_id="r0",
        )
        new = _revision(
            (ProviderAllowlist(frozenset({"stripe"})),),
            revision_id="r1",
            predecessor="r0",
            depth=1,
        )
        assert rule.validate_transition(old, new, "main") == ()

    def test_unmonitored_class_is_ignored(self):
        """A class outside the monitored set passes without comparison.

        v1.1.0: RetryRateLimit + RollingWindowCap + BurstVelocityCap are
        now members of the default monitored set. We use a pinned
        ``monitored_classes={"SpendingCap"}`` to keep the scenario
        honest: the NoWeakening rule still ignores any class it wasn't
        asked to monitor.
        """
        rule = NoWeakening(monitored_classes=frozenset({"SpendingCap"}))
        old = _revision(
            (RetryRateLimit(min_gap_seconds=30),),
            revision_id="r0",
        )
        new = _revision(
            (RetryRateLimit(min_gap_seconds=5),),
            revision_id="r1",
            predecessor="r0",
            depth=1,
        )
        assert rule.validate_transition(old, new, "main") == ()


# ── OverridesMustExpire ─────────────────────────────────────────────────────


class TestOverridesMustExpire:
    def _rev_with_override(
        self,
        invariants: tuple,
        *,
        revision_id: str,
        expires_at_unix: int | None,
        now: int = 1_713_000_000,
    ):
        # Index 0 is the override.
        overrides_meta = {"0": {"expires_at_unix": expires_at_unix}} if invariants else {}
        return _revision(
            invariants,
            revision_id=revision_id,
            admitted_at_unix=now,
            affected_scope={"overrides": overrides_meta},
        )

    def test_override_within_ttl_is_clean(self):
        rule = OverridesMustExpire(max_ttl_seconds=86400)
        now = 1_713_000_000
        new = self._rev_with_override(
            (SpendingCap(Decimal("100"), scope="per_tx"),),
            revision_id="r1",
            expires_at_unix=now + 3600,
            now=now,
        )
        violations = rule.validate_transition(None, new, "main")
        assert violations == ()

    def test_override_beyond_ttl_is_rejected(self):
        rule = OverridesMustExpire(max_ttl_seconds=86400)
        now = 1_713_000_000
        new = self._rev_with_override(
            (SpendingCap(Decimal("100"), scope="per_tx"),),
            revision_id="r1",
            expires_at_unix=now + 172800,  # 48h > 24h cap
            now=now,
        )
        violations = rule.validate_transition(None, new, "main")
        assert len(violations) == 1
        assert violations[0].category == "override_ttl_too_long"

    def test_invariant_without_override_marker_is_ignored(self):
        rule = OverridesMustExpire(max_ttl_seconds=86400)
        # No affected_scope override marker at all -> not an override.
        new = _revision(
            (SpendingCap(Decimal("100"), scope="per_tx"),),
            revision_id="r1",
        )
        assert rule.validate_transition(None, new, "main") == ()

    def test_override_without_expires_at_is_rejected(self):
        rule = OverridesMustExpire(max_ttl_seconds=86400)
        new = self._rev_with_override(
            (SpendingCap(Decimal("100"), scope="per_tx"),),
            revision_id="r1",
            expires_at_unix=None,
        )
        violations = rule.validate_transition(None, new, "main")
        assert len(violations) == 1
        assert violations[0].category == "override_missing_expires_at"


# ── BranchRespectsCore ──────────────────────────────────────────────────────


class TestBranchRespectsCore:
    def test_merge_removing_protected_class_is_rejected(self):
        rule = BranchRespectsCore(
            core_branch_name="main",
            protected_classes=frozenset({"SpendingCap", "ProviderAllowlist"}),
        )
        old = _revision(
            (SpendingCap(Decimal("10"), scope="per_tx"),),
            revision_id="main_head",
            branch="main",
        )
        new = _revision(
            (),  # merge commit dropped the SpendingCap
            revision_id="merge:main_head+feat_head",
            predecessor="main_head",
            depth=1,
            branch="main",
            merge_parent_ids=("main_head", "feat_head"),
            proof_backend="three-way-merge",
        )
        violations = rule.validate_transition(old, new, "main")
        assert len(violations) == 1
        assert violations[0].category == "merge_dropped_protected_class"

    def test_merge_into_feature_branch_is_ignored(self):
        rule = BranchRespectsCore(
            core_branch_name="main",
            protected_classes=frozenset({"SpendingCap"}),
        )
        old = _revision(
            (SpendingCap(Decimal("10"), scope="per_tx"),),
            revision_id="feat_head",
            branch="feature",
        )
        new = _revision(
            (),
            revision_id="merge:feat+bar",
            predecessor="feat_head",
            depth=1,
            branch="feature",
            merge_parent_ids=("feat_head", "bar_head"),
            proof_backend="three-way-merge",
        )
        assert rule.validate_transition(old, new, "feature") == ()

    def test_non_merge_revision_is_ignored(self):
        rule = BranchRespectsCore(
            core_branch_name="main",
            protected_classes=frozenset({"SpendingCap"}),
        )
        old = _revision(
            (SpendingCap(Decimal("10"), scope="per_tx"),),
            revision_id="r0",
            branch="main",
        )
        # Ordinary linear revision that happens to drop SpendingCap —
        # this is NoWeakening's job, not BranchRespectsCore's.
        new = _revision(
            (),
            revision_id="r1",
            predecessor="r0",
            depth=1,
            branch="main",
            merge_parent_ids=None,
        )
        assert rule.validate_transition(old, new, "main") == ()


# ── validator container ─────────────────────────────────────────────────────


class TestCrossRevisionValidator:
    def test_empty_validator_accepts_every_transition(self):
        v = CrossRevisionValidator()
        assert not v
        result = v.validate(None, _revision((), revision_id="r0"), "main")
        assert result.valid
        assert result.violations == ()

    def test_composed_validator_collects_all_violations(self):
        v = CrossRevisionValidator(invariants=(
            NoWeakening(),
            BranchRespectsCore(
                core_branch_name="main",
                protected_classes=frozenset({"SpendingCap"}),
            ),
        ))
        old = _revision(
            (SpendingCap(Decimal("10"), scope="per_tx"),),
            revision_id="r0",
            branch="main",
        )
        new = _revision(
            (SpendingCap(Decimal("100"), scope="per_tx"),),
            revision_id="merge:r0+feat",
            predecessor="r0",
            depth=1,
            branch="main",
            merge_parent_ids=("r0", "feat"),
            proof_backend="three-way-merge",
        )
        # NoWeakening fires (raised cap), BranchRespectsCore doesn't (class present).
        result = v.validate(old, new, "main")
        assert not result.valid
        assert any(x.category == "weakened_spending_cap" for x in result.violations)

    def test_accepts_tuple_or_list(self):
        v = CrossRevisionValidator(invariants=[NoWeakening()])
        assert len(v) == 1


# ── env-driven wiring ───────────────────────────────────────────────────────


class TestBuildFromEnv:
    def test_no_env_returns_none(self):
        assert build_validator_from_env({}) is None

    def test_all_three_rules(self):
        env = {
            "TAU_CAGE_CROSS_REVISION_NO_WEAKENING": "1",
            "TAU_CAGE_CROSS_REVISION_OVERRIDE_TTL": "86400",
            "TAU_CAGE_CROSS_REVISION_CORE_BRANCH": "main",
        }
        v = build_validator_from_env(env)
        assert v is not None
        assert len(v) == 3
        names = {type(i).__name__ for i in v.invariants}
        assert names == {"NoWeakening", "OverridesMustExpire", "BranchRespectsCore"}

    def test_bad_ttl_raises_value_error(self):
        with pytest.raises(ValueError):
            build_validator_from_env({
                "TAU_CAGE_CROSS_REVISION_OVERRIDE_TTL": "not-a-number",
            })


# ── RevisionLog.append integration ──────────────────────────────────────────


class TestRevisionLogAppend:
    def test_default_behavior_preserved_without_validator(self):
        """No validator ⇒ pre-v0.14 behaviour bit-identical."""
        log = RevisionLog()
        assert log.cross_revision_validator is None
        rev = _revision(
            (SpendingCap(Decimal("10"), scope="per_tx"),),
            revision_id="r0",
        )
        log.append(rev)
        assert log.latest is rev

    def test_validator_rejection_blocks_append(self):
        log = RevisionLog(cross_revision_validator=CrossRevisionValidator(
            invariants=(NoWeakening(),),
        ))
        r0 = _revision(
            (SpendingCap(Decimal("10"), scope="per_tx"),),
            revision_id="r0",
        )
        log.append(r0)
        r1 = _revision(
            (SpendingCap(Decimal("100"), scope="per_tx"),),
            revision_id="r1",
            predecessor="r0",
            depth=1,
        )
        with pytest.raises(CrossRevisionRejected) as excinfo:
            log.append(r1)
        # Structured violations preserved.
        assert len(excinfo.value.result.violations) == 1
        # Log state unchanged — r0 still head.
        assert log.latest is r0
        assert len(log) == 1

    def test_cross_revision_rejected_subclass_of_revision_log_error(self):
        """Existing call sites can still catch RevisionLogError."""
        log = RevisionLog(cross_revision_validator=CrossRevisionValidator(
            invariants=(NoWeakening(),),
        ))
        r0 = _revision(
            (SpendingCap(Decimal("10"), scope="per_tx"),),
            revision_id="r0",
        )
        log.append(r0)
        r1 = _revision(
            (SpendingCap(Decimal("100"), scope="per_tx"),),
            revision_id="r1",
            predecessor="r0",
            depth=1,
        )
        with pytest.raises(RevisionLogError):
            log.append(r1)


# ── daemon integration ──────────────────────────────────────────────────────


@pytest.fixture
def daemon_with_no_weakening() -> Iterator[str]:
    fd, path = tempfile.mkstemp(prefix="xrev-", suffix=".sock", dir="/tmp")
    os.close(fd)
    os.unlink(path)
    validator = CrossRevisionValidator(invariants=(NoWeakening(),))
    d = CageDaemon(
        socket_path=path,
        cross_revision_validator=validator,
    )
    t = threading.Thread(target=d.serve_forever, daemon=True)
    t.start()
    for _ in range(50):
        if os.path.exists(path):
            break
        time.sleep(0.01)
    try:
        yield path
    finally:
        d.shutdown()
        t.join(timeout=1.0)


def _send(path: str, req: dict) -> dict:
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.settimeout(5.0)
    s.connect(path)
    try:
        s.sendall((json.dumps(req) + "\n").encode("utf-8"))
        f = s.makefile("r")
        return json.loads(f.readline())
    finally:
        s.close()


class TestDaemonIntegration:
    def test_weakening_mutation_is_rejected(self, daemon_with_no_weakening: str):
        sock = daemon_with_no_weakening
        # Install the first SpendingCap on main.
        r0 = _send(sock, {
            "op": "add_invariant",
            "invariant": {"kind": "max_per_call", "max_amount": "10"},
        })
        assert r0["verdict"] == "updated", r0
        # Try to weaken via update_invariant.
        r1 = _send(sock, {
            "op": "update_invariant",
            "old": {"kind": "max_per_call", "max_amount": "10"},
            "new": {"kind": "max_per_call", "max_amount": "100"},
        })
        assert r1["verdict"] == "reject", r1
        assert r1.get("category") == "cross_revision_violation", r1
        assert "violations" in r1
        assert len(r1["violations"]) >= 1
        # Registry unchanged — active still has the tight cap.
        active = _send(sock, {"op": "active_x402"})
        assert active["active_invariants"] == 1

    def test_rejected_mutation_not_persisted_to_revision_log(
        self, daemon_with_no_weakening: str,
    ):
        sock = daemon_with_no_weakening
        r0 = _send(sock, {
            "op": "add_invariant",
            "invariant": {"kind": "max_per_call", "max_amount": "10"},
        })
        assert r0["verdict"] == "updated"
        log_before = _send(sock, {"op": "revision_log"})
        length_before = log_before["length"]
        # Weakening attempt:
        r1 = _send(sock, {
            "op": "update_invariant",
            "old": {"kind": "max_per_call", "max_amount": "10"},
            "new": {"kind": "max_per_call", "max_amount": "50"},
        })
        assert r1["verdict"] == "reject"
        log_after = _send(sock, {"op": "revision_log"})
        # No new revision was appended.
        assert log_after["length"] == length_before


# ── rehydration: rejected mutations stay off disk ───────────────────────────


class TestRehydration:
    def test_rejected_revision_not_in_persisted_log(self, tmp_path):
        log_path = tmp_path / "revisions.jsonl"
        log = RevisionLog(
            path=log_path,
            cross_revision_validator=CrossRevisionValidator(
                invariants=(NoWeakening(),),
            ),
        )
        r0 = _revision(
            (SpendingCap(Decimal("10"), scope="per_tx"),),
            revision_id="r0",
        )
        log.append(r0)
        r1_bad = _revision(
            (SpendingCap(Decimal("100"), scope="per_tx"),),
            revision_id="r1",
            predecessor="r0",
            depth=1,
        )
        with pytest.raises(CrossRevisionRejected):
            log.append(r1_bad)

        # Re-load: only r0 should be present.
        log2 = RevisionLog.load(log_path)
        assert len(log2) == 1
        assert log2.latest.revision_id == "r0"


# ── CLI dry-run ─────────────────────────────────────────────────────────────


class TestCLIDryRun:
    def test_cli_dry_run_matches_daemon_admission(
        self, daemon_with_no_weakening: str, tmp_path, monkeypatch,
    ) -> None:
        """``cross-revision`` CLI verdict must match daemon admission.

        Seeds the daemon with a tight MaxPerCall, writes a candidate
        YAML that weakens it, and verifies both:
          * CLI exits non-zero with a violation reported.
          * The daemon would reject an equivalent add_invariant.
        """
        sock = daemon_with_no_weakening
        r0 = _send(sock, {
            "op": "add_invariant",
            "invariant": {"kind": "max_per_call", "max_amount": "10"},
        })
        assert r0["verdict"] == "updated", r0

        candidate_path = tmp_path / "candidate.yaml"
        candidate_path.write_text(
            "version: 1\n"
            "policy:\n"
            "  - kind: max_per_call\n"
            "    max_amount: \"100\"\n"
            "    currency: USDC\n",
            encoding="utf-8",
        )

        # Invoke the CLI entry point directly.
        monkeypatch.setenv("TAU_CAGE_CROSS_REVISION_NO_WEAKENING", "1")
        monkeypatch.delenv("TAU_CAGE_CROSS_REVISION_OVERRIDE_TTL", raising=False)
        monkeypatch.delenv("TAU_CAGE_CROSS_REVISION_CORE_BRANCH", raising=False)

        from daemon.cli import main as cli_main
        monkeypatch.setattr(
            "sys.argv",
            ["tau-x402-cage", "cross-revision",
             "--candidate", str(candidate_path),
             "--socket", sock,
             "--format", "json"],
        )
        import io
        import sys as _sys
        buf = io.StringIO()
        monkeypatch.setattr(_sys, "stdout", buf)
        rc = cli_main()
        assert rc == 1, f"expected violation exit (1), got rc={rc}"
        report = json.loads(buf.getvalue())
        assert report["valid"] is False
        assert any(
            v["category"] == "weakened_max_per_call"
            for v in report["violations"]
        )

    def test_cli_clean_candidate_exits_zero(
        self, daemon_with_no_weakening: str, tmp_path, monkeypatch,
    ) -> None:
        sock = daemon_with_no_weakening
        _send(sock, {
            "op": "add_invariant",
            "invariant": {"kind": "max_per_call", "max_amount": "100"},
        })
        candidate_path = tmp_path / "candidate.yaml"
        candidate_path.write_text(
            # Tightening: 100 -> 10 is clean.
            "version: 1\n"
            "policy:\n"
            "  - kind: max_per_call\n"
            "    max_amount: \"10\"\n"
            "    currency: USDC\n",
            encoding="utf-8",
        )
        monkeypatch.setenv("TAU_CAGE_CROSS_REVISION_NO_WEAKENING", "1")
        monkeypatch.delenv("TAU_CAGE_CROSS_REVISION_OVERRIDE_TTL", raising=False)
        monkeypatch.delenv("TAU_CAGE_CROSS_REVISION_CORE_BRANCH", raising=False)

        from daemon.cli import main as cli_main
        monkeypatch.setattr(
            "sys.argv",
            ["tau-x402-cage", "cross-revision",
             "--candidate", str(candidate_path),
             "--socket", sock,
             "--format", "json"],
        )
        import io
        import sys as _sys
        buf = io.StringIO()
        monkeypatch.setattr(_sys, "stdout", buf)
        rc = cli_main()
        assert rc == 0, f"expected clean exit (0), got rc={rc}"
        report = json.loads(buf.getvalue())
        assert report["valid"] is True
        assert report["violations"] == []


# ── three-way merge integration ─────────────────────────────────────────────


class TestMergeBranch:
    def test_merge_into_main_removing_protected_class_is_rejected(self):
        """Three-way merge into main that drops a protected class raises."""
        validator = CrossRevisionValidator(invariants=(
            BranchRespectsCore(
                core_branch_name="main",
                protected_classes=frozenset({"SpendingCap"}),
            ),
        ))
        log = RevisionLog(cross_revision_validator=validator)
        # Seed main with a SpendingCap.
        r0 = _revision(
            (SpendingCap(Decimal("10"), scope="per_tx"),),
            revision_id="r0",
            branch="main",
        )
        log.append(r0)
        # Feature branch off r0: add a different class.
        log.create_branch("feature")
        log.checkout_branch("feature")
        # Evolve feature: remove SpendingCap, add RetryRateLimit.
        r1 = _revision(
            (RetryRateLimit(min_gap_seconds=5),),
            revision_id="r1",
            predecessor="r0",
            depth=1,
            branch="feature",
        )
        log.append(r1)
        # Advance main on its own line (linear evolution, adds another class
        # but keeps SpendingCap) so a 3-way merge is needed rather than FF.
        log.checkout_branch("main")
        r2 = _revision(
            (
                SpendingCap(Decimal("10"), scope="per_tx"),
                ProviderAllowlist(frozenset({"stripe"})),
            ),
            revision_id="r2",
            predecessor="r0",
            depth=1,
            branch="main",
        )
        log.append(r2)
        # Now merging feature into main drops SpendingCap —
        # BranchRespectsCore should reject.
        with pytest.raises(CrossRevisionRejected) as excinfo:
            log.merge_branch("feature", "main", reviewer="alice")
        assert any(
            v.category == "merge_dropped_protected_class"
            for v in excinfo.value.result.violations
        )
