"""Unit tests for the daemon's ``recent_verdicts`` op (v0.7.0).

The op is the spine of the web UI's /ui/verdicts page but is also useful
as a CLI / scripting surface. Covered here: pagination, cap, ordering,
and that both permit + reject verdicts land in the ring buffer.
"""

from __future__ import annotations

from decimal import Decimal

import pytest

from daemon.server import CageDaemon


@pytest.fixture
def daemon() -> CageDaemon:
    # Fresh daemon, no socket started — we drive via `.dispatch()` directly.
    return CageDaemon(socket_path="/tmp/recent-verdicts-unused.sock")


def _intent(amount: str = "10.00") -> dict:
    return {
        "amount": amount,
        "currency": "USDC",
        "provider": "anthropic",
        "counterparty": "vendor_x",
        "rail": "x402",
        "timestamp_unix": 1_700_000_000,
    }


def _declare_max_per_call(daemon: CageDaemon, cap: str = "100.00") -> None:
    resp = daemon.dispatch(
        {"op": "declare_x402", "kind": "max_per_call", "max_amount": cap}
    )
    assert resp["verdict"] == "updated", resp


class TestRecentVerdicts:
    def test_empty_on_fresh_daemon(self, daemon: CageDaemon) -> None:
        r = daemon.dispatch({"op": "recent_verdicts"})
        assert r["verdict"] == "ok"
        assert r["total"] == 0
        assert r["entries"] == []

    def test_records_permit_and_reject(self, daemon: CageDaemon) -> None:
        _declare_max_per_call(daemon, "100.00")
        # Permit under cap
        p = daemon.dispatch({"op": "check_payment", "intent": _intent("50.00")})
        assert p["verdict"] == "permit"
        # Reject over cap
        r = daemon.dispatch({"op": "check_payment", "intent": _intent("500.00")})
        assert r["verdict"] == "reject"

        rv = daemon.dispatch({"op": "recent_verdicts"})
        assert rv["total"] == 2
        verdicts = [e["verdict"] for e in rv["entries"]]
        # Newest-first slice
        assert verdicts == ["reject", "permit"]
        reject_entry = rv["entries"][0]
        assert reject_entry["rule_id"] == "max_per_call"
        assert reject_entry["intent"]["amount"] == "500.00"

    def test_pagination(self, daemon: CageDaemon) -> None:
        _declare_max_per_call(daemon, "100.00")
        for i in range(5):
            daemon.dispatch(
                {"op": "check_payment", "intent": _intent(str(10 + i))}
            )
        # limit=2 from newest = the last 2 permits (amounts 14 and 13)
        page = daemon.dispatch(
            {"op": "recent_verdicts", "limit": 2, "offset": 0}
        )
        assert page["total"] == 5
        amounts = [e["intent"]["amount"] for e in page["entries"]]
        assert amounts == ["14", "13"]
        # offset=2 slides window
        page2 = daemon.dispatch(
            {"op": "recent_verdicts", "limit": 2, "offset": 2}
        )
        amounts2 = [e["intent"]["amount"] for e in page2["entries"]]
        assert amounts2 == ["12", "11"]

    def test_bad_pagination_rejected(self, daemon: CageDaemon) -> None:
        for bad in (
            {"limit": 0},
            {"limit": 1_000_000},
            {"offset": -1},
            {"limit": "nope"},
        ):
            r = daemon.dispatch({"op": "recent_verdicts", **bad})
            assert r["verdict"] == "error"
            assert r["category"] == "bad_pagination"

    def test_metadata_redacted_from_summary(self, daemon: CageDaemon) -> None:
        """The summary surface must never leak request_id or metadata."""
        _declare_max_per_call(daemon, "100.00")
        intent = _intent("10.00")
        intent["metadata"] = {"x_api_key_hash": "deadbeef"}
        intent["request_id"] = "req_abc"
        daemon.dispatch({"op": "check_payment", "intent": intent})
        rv = daemon.dispatch({"op": "recent_verdicts"})
        entry = rv["entries"][0]
        assert "metadata" not in entry["intent"]
        assert "request_id" not in entry["intent"]
