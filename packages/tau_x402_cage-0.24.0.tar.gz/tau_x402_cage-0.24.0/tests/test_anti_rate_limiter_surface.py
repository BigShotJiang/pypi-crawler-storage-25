"""Tests for the v0.23.0 "not just rate limiting" surface (Priority 7).

The brief asks for a synthesised ``revision_context`` string derived
from the existing ``previous_policy_revision`` /
``current_policy_revision`` / ``revision_transition_issue`` fields so
composed violations read as policy-state evolution rather than a
single-rule rate-limiter fire.

Tests cover:

* Pure helper ``build_revision_context`` (returns a human string or None).
* ``PaymentDecision`` round-trip preserves ``revision_context``.
* At least one realistic composed scenario produces a decision whose
  envelope names the cross-revision evolution in plain English (brief
  Test 7).
"""
from __future__ import annotations

import json

import pytest

from adapter.decision_schema import (
    PaymentDecision,
    build_revision_context,
)


class TestBuildRevisionContext:
    """The helper turns raw revision fields into a human string."""

    def test_none_when_no_signal(self) -> None:
        assert (
            build_revision_context(
                previous_policy_revision=None,
                current_policy_revision=None,
                revision_transition_issue=None,
                tightening_level=0.0,
                trigger=None,
            )
            is None
        )

    def test_tightening_after_repeated_failures(self) -> None:
        """The canonical brief example phrasing."""
        ctx = build_revision_context(
            previous_policy_revision="rev_12",
            current_policy_revision="rev_13",
            revision_transition_issue=None,
            tightening_level=0.7,
            trigger="retry_density_exceeded",
        )
        assert ctx is not None
        # Brief example: "rev_13 tightened after repeated failures".
        assert "rev_13" in ctx
        assert "tightened" in ctx
        assert "repeated failures" in ctx

    def test_transition_kind_suffixed_when_present(self) -> None:
        ctx = build_revision_context(
            previous_policy_revision="rev_12",
            current_policy_revision="rev_13",
            revision_transition_issue={
                "kind": "limit_relaxation_during_active_tightening",
                "details": {},
            },
            tightening_level=0.7,
            trigger="retry_density_exceeded",
        )
        assert ctx is not None
        assert "rev_13" in ctx
        assert "limit relaxation during active tightening" in ctx

    def test_simple_transition_note_when_no_tightening(self) -> None:
        """Plain revision transition without tightening still surfaces."""
        ctx = build_revision_context(
            previous_policy_revision="rev_12",
            current_policy_revision="rev_13",
            revision_transition_issue=None,
            tightening_level=0.0,
            trigger=None,
        )
        assert ctx is not None
        assert "rev_12" in ctx
        assert "rev_13" in ctx


class TestPaymentDecisionRevisionContext:
    """Brief Test 7 — a realistic scenario names the cross-revision evolution."""

    def test_realistic_composed_scenario(self) -> None:
        """An envelope with composed violations + revision transition.

        The decision represents a point where adaptive tightening is
        active AND the policy advanced to a new revision. The
        ``revision_context`` string must name the evolution in plain
        English (brief shape: "rev_13 tightened after repeated
        failures").
        """
        revision_context = build_revision_context(
            previous_policy_revision="rev_12",
            current_policy_revision="rev_13",
            revision_transition_issue=None,
            tightening_level=0.7,
            trigger="retry_density_exceeded",
        )
        decision = PaymentDecision(
            allowed=False,
            reason="composed_constraint_violation",
            violations=(
                "adaptive_tightening_active",
                "spend_velocity_exceeded",
            ),
            previous_policy_revision="rev_12",
            current_policy_revision="rev_13",
            tightening_level=0.7,
            trigger="retry_density_exceeded",
            revision_context=revision_context,
        )
        wire = decision.to_wire()
        assert wire["revision_context"] is not None
        assert "rev_13" in wire["revision_context"]
        assert "tightened" in wire["revision_context"]
        assert "repeated failures" in wire["revision_context"]

    def test_composed_violations_serialise_correctly(self) -> None:
        """The brief's composed-violations list shape round-trips cleanly."""
        decision = PaymentDecision(
            allowed=False,
            reason="composed_constraint_violation",
            violations=(
                "adaptive_tightening_active",
                "spend_velocity_exceeded",
            ),
            revision_context="rev_13 tightened after repeated failures",
        )
        wire = decision.to_wire()
        js = json.dumps(wire, sort_keys=True)
        parsed = PaymentDecision.from_wire(json.loads(js))
        assert parsed.violations == (
            "adaptive_tightening_active",
            "spend_velocity_exceeded",
        )
        assert parsed.revision_context == "rev_13 tightened after repeated failures"

    def test_revision_context_optional_when_no_transition(self) -> None:
        """Zero-break: inactive decisions carry ``None`` on the field."""
        decision = PaymentDecision(allowed=True, reason="allowed")
        wire = decision.to_wire()
        assert wire["revision_context"] is None

    def test_revision_context_from_wire_defensive(self) -> None:
        """Malformed payloads never raise."""
        payload = {
            "allowed": False,
            "reason": "composed_constraint_violation",
            "revision_context": ["not", "a", "string"],  # wrong type
        }
        parsed = PaymentDecision.from_wire(payload)
        assert parsed.revision_context is None
