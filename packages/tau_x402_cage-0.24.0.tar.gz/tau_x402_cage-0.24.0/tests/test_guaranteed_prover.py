"""Tests for Guaranteed Mode (v0.19.0): pure-Tau prover + proof artifact.

Deliverable 2 test battery. These tests encode the Guaranteed Mode contract:

* The prover refuses anything other than a ``TauConsistencyProver`` (strict
  construction gate).
* ``z3`` and the pattern prover are NEVER invoked during prove.
* Every non-decisive Tau outcome fails closed with a specific
  ``GuaranteedFailureCode``.
* A multi-rule global contradiction (no pair unsat, conjunction unsat) is
  detected via the Tau backend and emits a decisive ``inconsistent`` result.
* Artifacts round-trip through ``ProofArtifactStore.save`` /
  ``load`` with stable ``compile_hash`` and are immutable after creation.
"""

from __future__ import annotations

import dataclasses
import json
import os
import subprocess
from dataclasses import FrozenInstanceError
from decimal import Decimal
from pathlib import Path
from unittest.mock import patch

import pytest

from adapter.invariants import (
    MaxPerCall,
    ProviderAllowlist,
    SpendingCap,
)
from adapter.prover import (
    Contradiction,
    InconclusiveProof,
    ProofToken,
    PythonPatternProver,
    TauConsistencyProver,
    TauUnavailable,
)
from adapter.guaranteed_proof_artifact import (
    ARTIFACT_STORE_ENV_VAR,
    GuaranteedProofArtifact,
    GuaranteedProofResult,
    ProofArtifactStore,
    make_artifact_id,
    utc_now,
)
from adapter.guaranteed_prover import (
    DEFAULT_BUDGET_MS,
    GuaranteedProver,
    _reset_z3_counter,
)

try:
    from adapter.guaranteed_errors import (  # type: ignore[attr-defined]
        GuaranteedFailure,
        GuaranteedFailureCode,
    )
except ImportError:
    from adapter._guaranteed_stubs import (  # type: ignore[no-redef]
        GuaranteedFailure,
        GuaranteedFailureCode,
    )


# ── helpers ────────────────────────────────────────────────────────────────


def _make_prover(tmp_path: Path, tau: TauConsistencyProver | None = None) -> GuaranteedProver:
    tau = tau or TauConsistencyProver()
    store = ProofArtifactStore(path=tmp_path / "proofs.jsonl")
    return GuaranteedProver(prover=tau, artifact_store=store)


def _supported_policy() -> tuple:
    return (
        MaxPerCall(max_amount=Decimal("50")),
        ProviderAllowlist(providers=frozenset({"anthropic", "openai"})),
    )


def _fake_sat_token() -> ProofToken:
    return ProofToken(
        config_hash="deadbeef",
        issued_at_unix=0,
        backend="tau",
        proof_strength="complete",
        nonce="abc",
        predecessor_hash=None,
        fragment_version="v1",
        compile_hash="feedface",
        tau_backend_version=None,
    )


def _fake_unsat() -> Contradiction:
    return Contradiction(
        left="composed_spec",
        right="composed_spec",
        reason="Tau proved composed spec unsatisfiable",
        backend="tau",
    )


# ── construction gate ──────────────────────────────────────────────────────


class TestConstructionGate:
    """Guaranteed Mode refuses any prover that isn't TauConsistencyProver."""

    def test_accepts_tau_prover(self) -> None:
        tau = TauConsistencyProver()
        gp = GuaranteedProver(prover=tau)
        assert gp.tau_prover is tau

    def test_rejects_python_pattern_prover(self) -> None:
        with pytest.raises(AssertionError, match="TauConsistencyProver"):
            GuaranteedProver(prover=PythonPatternProver())  # type: ignore[arg-type]

    def test_rejects_none(self) -> None:
        with pytest.raises(AssertionError):
            GuaranteedProver(prover=None)  # type: ignore[arg-type]

    def test_rejects_arbitrary_object(self) -> None:
        class FakeProver:
            backend = "fake"

            def prove(self, invariants, predecessor_hash=None):  # noqa: D401
                return _fake_sat_token()

        with pytest.raises(AssertionError):
            GuaranteedProver(prover=FakeProver())  # type: ignore[arg-type]


# ── test 3: pure-Tau path; z3 never touched ────────────────────────────────


class TestPureTauPath:
    """No z3 import, no z3 call, no pattern prover authority during prove."""

    def setup_method(self) -> None:
        _reset_z3_counter()

    def test_z3_never_invoked_on_supported_policy(self, tmp_path) -> None:
        tau = TauConsistencyProver()
        gp = _make_prover(tmp_path, tau)

        # Patch both z3 entry points we care about. Any invocation raises,
        # which would surface through the exception path.
        with patch("adapter.prover.Z3ConsistencyProver") as fake_z3_cls, \
             patch("adapter.tau_compiler.compile_policy",
                   wraps=__import__("adapter.tau_compiler",
                                    fromlist=["compile_policy"]).compile_policy), \
             patch.object(TauConsistencyProver, "prove",
                          return_value=_fake_sat_token()):
            result = gp.prove(_supported_policy())

        assert isinstance(result, GuaranteedProofResult)
        assert result.consistent is True
        fake_z3_cls.assert_not_called()

    def test_sanity_no_z3_invoked_assertion_fires_on_leak(self, tmp_path) -> None:
        tau = TauConsistencyProver()
        gp = _make_prover(tmp_path, tau)

        # Simulate z3 leakage: bump the counter directly. The sanity check
        # must then raise AssertionError.
        from adapter import guaranteed_prover as gp_mod
        gp_mod._reset_z3_counter()
        baseline = 0
        gp_mod._Z3_CALL_COUNTER["count"] = 1
        try:
            with pytest.raises(AssertionError, match="z3 was invoked"):
                gp._sanity_no_z3_invoked(baseline)
        finally:
            gp_mod._reset_z3_counter()


# ── test 4: fail-closed proofs ─────────────────────────────────────────────


class TestFailClosed:
    """Every non-decisive Tau outcome must produce a specific failure code."""

    def setup_method(self) -> None:
        _reset_z3_counter()

    def test_tau_timeout_maps_to_timeout_code(self, tmp_path) -> None:
        tau = TauConsistencyProver()
        gp = _make_prover(tmp_path, tau)

        def _raise_timeout(*_args, **_kwargs):
            raise subprocess.TimeoutExpired(cmd="tau", timeout=10)

        with patch.object(TauConsistencyProver, "prove", side_effect=_raise_timeout):
            failure = gp.prove(_supported_policy())

        assert isinstance(failure, GuaranteedFailure)
        assert failure.code == GuaranteedFailureCode.TAU_PROOF_TIMEOUT

    def test_inconclusive_proof_maps_to_inconclusive_code(self, tmp_path) -> None:
        tau = TauConsistencyProver()
        gp = _make_prover(tmp_path, tau)
        incon = InconclusiveProof(
            category="other",
            reason="Tau returned uninterpretable output",
            backend="tau",
        )

        with patch.object(TauConsistencyProver, "prove", return_value=incon):
            failure = gp.prove(_supported_policy())

        assert isinstance(failure, GuaranteedFailure)
        assert failure.code == GuaranteedFailureCode.TAU_PROOF_INCONCLUSIVE

    def test_backend_unavailable_on_filenotfound(self, tmp_path) -> None:
        tau = TauConsistencyProver()
        gp = _make_prover(tmp_path, tau)

        with patch.object(TauConsistencyProver, "prove",
                          side_effect=FileNotFoundError("tau")):
            failure = gp.prove(_supported_policy())

        assert isinstance(failure, GuaranteedFailure)
        assert failure.code == GuaranteedFailureCode.TAU_BACKEND_UNAVAILABLE

    def test_backend_unavailable_on_tau_unavailable_raise(self, tmp_path) -> None:
        tau = TauConsistencyProver()
        gp = _make_prover(tmp_path, tau)

        with patch.object(TauConsistencyProver, "prove",
                          side_effect=TauUnavailable("no binary")):
            failure = gp.prove(_supported_policy())

        assert isinstance(failure, GuaranteedFailure)
        assert failure.code == GuaranteedFailureCode.TAU_BACKEND_UNAVAILABLE

    def test_pattern_fallback_token_is_rejected(self, tmp_path) -> None:
        """A ProofToken with proof_strength != 'complete' must be rejected.

        The real TauConsistencyProver emits these when Tau silently falls
        back to the pattern prover. Guaranteed Mode treats them as
        inconclusive.
        """
        tau = TauConsistencyProver()
        gp = _make_prover(tmp_path, tau)
        fallback_token = ProofToken(
            config_hash="d",
            issued_at_unix=0,
            backend="chained:tau->pattern",
            proof_strength="pattern+tau-unavailable",
            nonce="n",
        )
        with patch.object(TauConsistencyProver, "prove", return_value=fallback_token):
            failure = gp.prove(_supported_policy())

        assert isinstance(failure, GuaranteedFailure)
        assert failure.code == GuaranteedFailureCode.TAU_BACKEND_UNAVAILABLE

    def test_unsupported_invariant_rejects(self, tmp_path) -> None:
        """Fragment-v2 construct must short-circuit with UNSUPPORTED."""
        tau = TauConsistencyProver()
        gp = _make_prover(tmp_path, tau)
        # SpendingCap with per_window scope is fragment v2 (not in v1).
        policy = (
            SpendingCap(
                max_amount=Decimal("100"),
                scope="per_window",
                window_seconds=60,
            ),
        )
        with patch.object(TauConsistencyProver, "prove", side_effect=AssertionError(
            "Tau must NOT be invoked on unsupported constructs"
        )):
            failure = gp.prove(policy)

        assert isinstance(failure, GuaranteedFailure)
        # Post-agent-1 merge: language-tier totality gate catches
        # fragment-v2 constructs before the compile step; both codes are
        # honest descriptions of an unsupported construct, but the
        # earlier gate wins in a fail-closed pipeline.
        assert failure.code in (
            GuaranteedFailureCode.TAU_UNSUPPORTED_CONSTRUCT,
            GuaranteedFailureCode.TAU_TOTALITY_FAILED,
        )

    def test_totality_failure_short_circuits(self, tmp_path) -> None:
        """A non-total policy must reject before Tau is invoked."""
        tau = TauConsistencyProver()
        gp = _make_prover(tmp_path, tau)

        from adapter._guaranteed_stubs import TotalityCheckResult

        def _fail_total(_policy):
            return TotalityCheckResult(
                is_total=False,
                reasons=("totality_fail_for_test",),
            )

        with patch("adapter.guaranteed_prover.validate_totality",
                   side_effect=_fail_total), \
             patch.object(TauConsistencyProver, "prove", side_effect=AssertionError(
                 "Tau must NOT be invoked when totality fails"
             )):
            failure = gp.prove(_supported_policy())

        assert isinstance(failure, GuaranteedFailure)
        assert failure.code == GuaranteedFailureCode.TAU_TOTALITY_FAILED
        # Real schema uses ``context``; the stub schema used ``details``.
        detail_map = getattr(failure, "context", None) or getattr(failure, "details", None)
        assert detail_map
        assert "totality_fail_for_test" in (detail_map.get("reasons") or [])


# ── test 9: global contradiction (no pairwise conflict) ────────────────────


class TestGlobalContradiction:
    """A multi-rule policy whose conjunction is unsat must come back as
    ``consistent=False`` with a decisive artifact, not a ``rejected``.
    """

    def setup_method(self) -> None:
        _reset_z3_counter()

    def test_conjunction_unsat_yields_consistent_false(self, tmp_path) -> None:
        """Simulate Tau returning UNSAT on the conjunction.

        We don't rely on the real Tau binary here: the contract we verify
        is that a Contradiction verdict from the injected prover becomes
        ``GuaranteedProofResult(consistent=False)``, NOT a
        ``GuaranteedFailure``.
        """
        tau = TauConsistencyProver()
        gp = _make_prover(tmp_path, tau)

        # Three rules, each individually satisfiable; the conjunction is
        # only unsat if we look at all three together.
        policy = (
            ProviderAllowlist(providers=frozenset({"anthropic"})),
            ProviderAllowlist(providers=frozenset({"openai"})),
            ProviderAllowlist(providers=frozenset({"google"})),
        )

        with patch.object(TauConsistencyProver, "prove", return_value=_fake_unsat()):
            result = gp.prove(policy)

        assert isinstance(result, GuaranteedProofResult)
        assert result.consistent is False  # DECISIVE, not rejected
        assert result.artifact.proof_result == "inconsistent"
        assert result.artifact.totality_check_passed is True


# ── artifact persistence + immutability ────────────────────────────────────


class TestArtifactStore:
    """Round-trip artifacts through the store with stable compile_hash."""

    def test_save_and_load_roundtrip(self, tmp_path) -> None:
        store = ProofArtifactStore(path=tmp_path / "proofs.jsonl")
        art = GuaranteedProofArtifact(
            artifact_id=make_artifact_id(),
            policy_revision_id="rev-1",
            compile_hash="c0ffee",
            tau_backend_version="1.2.3",
            language_tier_version="0.1.0",
            proof_result="consistent",
            totality_check_passed=True,
            prove_timestamp=utc_now(),
            prove_budget_ms=10_000,
        )
        store.save(art)
        loaded = store.load(art.artifact_id)
        assert loaded is not None
        assert loaded.artifact_id == art.artifact_id
        assert loaded.compile_hash == art.compile_hash
        assert loaded.tau_backend_version == art.tau_backend_version
        assert loaded.proof_result == "consistent"

    def test_list_for_revision(self, tmp_path) -> None:
        store = ProofArtifactStore(path=tmp_path / "proofs.jsonl")
        for i in range(3):
            store.save(GuaranteedProofArtifact(
                artifact_id=make_artifact_id(),
                policy_revision_id="rev-A",
                compile_hash="abc",
                tau_backend_version="1.0",
                language_tier_version="0.1",
                proof_result="consistent",
                totality_check_passed=True,
                prove_timestamp=utc_now(),
                prove_budget_ms=1000,
            ))
        store.save(GuaranteedProofArtifact(
            artifact_id=make_artifact_id(),
            policy_revision_id="rev-B",
            compile_hash="def",
            tau_backend_version="1.0",
            language_tier_version="0.1",
            proof_result="consistent",
            totality_check_passed=True,
            prove_timestamp=utc_now(),
            prove_budget_ms=1000,
        ))
        assert len(store.list_for_revision("rev-A")) == 3
        assert len(store.list_for_revision("rev-B")) == 1
        assert store.load("does-not-exist") is None

    def test_compile_hash_stable_across_persist_load(self, tmp_path) -> None:
        """Round-tripping through JSON does not perturb compile_hash."""
        store = ProofArtifactStore(path=tmp_path / "proofs.jsonl")
        art = GuaranteedProofArtifact(
            artifact_id=make_artifact_id(),
            policy_revision_id="rev-1",
            compile_hash="a" * 64,
            tau_backend_version="1.2.3",
            language_tier_version="0.1.0",
            proof_result="consistent",
            totality_check_passed=True,
            prove_timestamp=utc_now(),
            prove_budget_ms=10_000,
        )
        store.save(art)
        loaded = store.load(art.artifact_id)
        assert loaded is not None
        assert loaded.compile_hash == art.compile_hash
        # Canonical dict is byte-stable across two save/load cycles.
        assert loaded.to_canonical_dict() == art.to_canonical_dict()

    def test_artifact_is_frozen(self) -> None:
        art = GuaranteedProofArtifact(
            artifact_id="x",
            policy_revision_id="r",
            compile_hash="c",
            tau_backend_version="1",
            language_tier_version="0",
            proof_result="consistent",
            totality_check_passed=True,
            prove_timestamp=utc_now(),
            prove_budget_ms=10,
        )
        with pytest.raises(FrozenInstanceError):
            art.proof_result = "inconsistent"  # type: ignore[misc]

    def test_result_is_frozen(self) -> None:
        art = GuaranteedProofArtifact(
            artifact_id="x",
            policy_revision_id="r",
            compile_hash="c",
            tau_backend_version="1",
            language_tier_version="0",
            proof_result="consistent",
            totality_check_passed=True,
            prove_timestamp=utc_now(),
            prove_budget_ms=10,
        )
        result = GuaranteedProofResult(artifact=art, consistent=True)
        with pytest.raises(FrozenInstanceError):
            result.consistent = False  # type: ignore[misc]

    def test_env_var_override(self, tmp_path, monkeypatch) -> None:
        """The store honours ``TAU_X402_CAGE_PROOF_STORE`` when no path is passed."""
        target = tmp_path / "env-store.jsonl"
        monkeypatch.setenv(ARTIFACT_STORE_ENV_VAR, str(target))
        store = ProofArtifactStore()
        assert store.path == target
        store.save(GuaranteedProofArtifact(
            artifact_id="a",
            policy_revision_id="r",
            compile_hash="c",
            tau_backend_version="1",
            language_tier_version="0",
            proof_result="consistent",
            totality_check_passed=True,
            prove_timestamp=utc_now(),
            prove_budget_ms=10,
        ))
        assert target.exists()

    def test_save_rejects_non_artifact(self, tmp_path) -> None:
        store = ProofArtifactStore(path=tmp_path / "proofs.jsonl")
        with pytest.raises(TypeError):
            store.save({"not": "an artifact"})  # type: ignore[arg-type]


# ── persistence through the prover ─────────────────────────────────────────


class TestProverPersistence:
    """The prover writes artifacts for both success and reject paths."""

    def setup_method(self) -> None:
        _reset_z3_counter()

    def test_success_path_persists_consistent_artifact(self, tmp_path) -> None:
        tau = TauConsistencyProver()
        store = ProofArtifactStore(path=tmp_path / "proofs.jsonl")
        gp = GuaranteedProver(prover=tau, artifact_store=store)

        with patch.object(TauConsistencyProver, "prove", return_value=_fake_sat_token()):
            result = gp.prove(_supported_policy(), policy_revision_id="rev-ok")

        assert isinstance(result, GuaranteedProofResult)
        loaded = store.list_for_revision("rev-ok")
        assert len(loaded) == 1
        assert loaded[0].proof_result == "consistent"
        assert loaded[0].compile_hash  # non-empty
        assert loaded[0].totality_check_passed is True
        assert loaded[0].failure is None

    def test_reject_path_persists_rejected_artifact(self, tmp_path) -> None:
        tau = TauConsistencyProver()
        store = ProofArtifactStore(path=tmp_path / "proofs.jsonl")
        gp = GuaranteedProver(prover=tau, artifact_store=store)

        def _raise_timeout(*_a, **_kw):
            raise subprocess.TimeoutExpired(cmd="tau", timeout=10)

        with patch.object(TauConsistencyProver, "prove", side_effect=_raise_timeout):
            failure = gp.prove(_supported_policy(), policy_revision_id="rev-fail")

        assert isinstance(failure, GuaranteedFailure)
        loaded = store.list_for_revision("rev-fail")
        assert len(loaded) == 1
        assert loaded[0].proof_result == "rejected"
        assert loaded[0].failure is not None
        assert loaded[0].failure.code in (
            GuaranteedFailureCode.TAU_PROOF_TIMEOUT,
            "TAU_PROOF_TIMEOUT",
        )

    def test_budget_ms_must_be_positive(self, tmp_path) -> None:
        gp = _make_prover(tmp_path)
        with pytest.raises(ValueError):
            gp.prove(_supported_policy(), budget_ms=0)
        with pytest.raises(ValueError):
            gp.prove(_supported_policy(), budget_ms=-100)


# ── TauConsistencyProver.version_string ────────────────────────────────────


class TestVersionString:
    """The property must never raise and must return a string."""

    def test_version_string_returns_string(self) -> None:
        tau = TauConsistencyProver()
        v = tau.version_string
        assert isinstance(v, str)
        assert v  # non-empty

    def test_version_string_is_cached(self) -> None:
        tau = TauConsistencyProver()
        v1 = tau.version_string
        v2 = tau.version_string
        assert v1 == v2


# ── failure code serialisation ─────────────────────────────────────────────


class TestFailureSerialisation:
    """Artifacts carry the failure code through JSON without corruption."""

    def test_failure_roundtrips(self, tmp_path) -> None:
        store = ProofArtifactStore(path=tmp_path / "proofs.jsonl")
        failure = GuaranteedFailure(
            code=GuaranteedFailureCode.TAU_PROOF_TIMEOUT,
            message="Tau exceeded budget of 10s",
            context={"budget_ms": 10_000, "reason": "slow CI"},
        )
        art = GuaranteedProofArtifact(
            artifact_id=make_artifact_id(),
            policy_revision_id="rev-x",
            compile_hash="c0ffee",
            tau_backend_version="1.0",
            language_tier_version="0.1",
            proof_result="rejected",
            totality_check_passed=True,
            prove_timestamp=utc_now(),
            prove_budget_ms=10_000,
            failure=failure,
        )
        store.save(art)
        loaded = store.load(art.artifact_id)
        assert loaded is not None
        assert loaded.failure is not None
        # Code value preserved whether the canonical form is an enum or a
        # plain string (the stub path uses str).
        loaded_code = getattr(loaded.failure.code, "name", loaded.failure.code)
        assert loaded_code == "TAU_PROOF_TIMEOUT"
        assert loaded.failure.message == "Tau exceeded budget of 10s"
