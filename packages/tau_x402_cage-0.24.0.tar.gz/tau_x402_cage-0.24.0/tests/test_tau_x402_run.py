"""Tests for the v0.21.0 front-door: ``tau-x402 run`` + ``tau-x402`` alias.

The front door ships three things the tests here exercise:

  1. A new ``tau-x402`` script alias in pyproject.toml pointing at the
     same entry point as ``tau-x402-cage``.
  2. A new ``run`` subcommand that boots with safe defaults (packaged
     default policy, enforce mode, adaptive-tightening banner).
  3. A packaged ``daemon/default_policy.yaml`` that loads and validates
     through the existing policy loader.

We avoid spinning up a real daemon (which would need cvc5 + a UDS
socket) by using ``--dry-run``, which exits 0 after printing the
front-door banner to stderr.
"""
from __future__ import annotations

import os
import re
import subprocess
import sys
from pathlib import Path

import pytest

from adapter.policy_loader import load_policy
from daemon.cli import _build_parser, _default_policy_path


REPO_ROOT = Path(__file__).resolve().parent.parent


def _run_cli(*argv: str, timeout: float = 30.0) -> subprocess.CompletedProcess:
    """Invoke ``python -m daemon.cli`` with PYTHONPATH pointed at the repo."""
    env = dict(os.environ)
    env["PYTHONPATH"] = (
        str(REPO_ROOT) + os.pathsep + env.get("PYTHONPATH", "")
    )
    return subprocess.run(
        [sys.executable, "-m", "daemon.cli", *argv],
        capture_output=True,
        text=True,
        env=env,
        timeout=timeout,
    )


# ── entry point wiring ───────────────────────────────────────────────────────


class TestEntryPoints:
    """``tau-x402`` alias must share the same entry point as ``tau-x402-cage``."""

    def test_pyproject_declares_both_scripts(self) -> None:
        text = (REPO_ROOT / "pyproject.toml").read_text(encoding="utf-8")
        # Both script names must land on the same Python callable so
        # existing callers keep working unchanged.
        assert 'tau-x402 = "daemon.cli:main"' in text, (
            "tau-x402 script alias missing from pyproject.toml"
        )
        assert 'tau-x402-cage = "daemon.cli:main"' in text, (
            "tau-x402-cage script alias removed or renamed"
        )


# ── argparse surface ─────────────────────────────────────────────────────────


class TestRunSubparser:
    """The ``run`` subcommand must register with expected flags."""

    def test_run_subcommand_parses(self) -> None:
        parser = _build_parser()
        args = parser.parse_args(["run"])
        assert args.subcommand == "run"
        # Default state: open_allowlist off, dry_run off, no explicit policy.
        assert args.open_allowlist is False
        assert args.dry_run is False
        assert args.policy is None

    def test_run_accepts_open_allowlist_flag(self) -> None:
        parser = _build_parser()
        args = parser.parse_args(["run", "--open-allowlist"])
        assert args.open_allowlist is True

    def test_run_accepts_dry_run_flag(self) -> None:
        parser = _build_parser()
        args = parser.parse_args(["run", "--dry-run"])
        assert args.dry_run is True

    def test_run_accepts_mode_override(self) -> None:
        parser = _build_parser()
        args = parser.parse_args(["run", "--mode", "shadow"])
        assert args.mode == "shadow"


# ── default policy YAML ──────────────────────────────────────────────────────


class TestDefaultPolicy:
    """The packaged default policy must ship + load cleanly."""

    def test_default_policy_path_exists(self) -> None:
        path = _default_policy_path()
        assert path.exists(), (
            f"front-door default policy missing at {path}; the packaged YAML "
            "must ship next to daemon/cli.py"
        )
        assert path.name == "default_policy.yaml"

    def test_default_policy_parses_and_validates(self) -> None:
        loaded = load_policy(_default_policy_path())
        # Safe-defaults shape: at minimum max_per_call + spending_cap +
        # provider_allowlist + retry_rate_limit. The exact count may
        # grow over time but these four classes must stay present.
        class_names = {type(inv).__name__ for inv in loaded.invariants}
        for expected in (
            "MaxPerCall", "SpendingCap", "ProviderAllowlist", "RetryRateLimit",
        ):
            assert expected in class_names, (
                f"default policy missing {expected}; front-door safety "
                f"depends on all four classes being on by default"
            )

    def test_default_policy_deny_by_default_allowlist(self) -> None:
        """The allowlist must contain only a placeholder, not a real provider.

        This is what makes the default policy deny-by-default: every real
        provider name will mismatch the placeholder and reject loudly.
        """
        loaded = load_policy(_default_policy_path())
        from adapter.invariants import ProviderAllowlist

        allowlists = [
            inv for inv in loaded.invariants if isinstance(inv, ProviderAllowlist)
        ]
        assert allowlists, "default policy must ship with a ProviderAllowlist"
        providers = sorted(next(iter(allowlists)).providers)
        # Placeholder marker — any real provider will not match.
        assert providers == ["__placeholder__"], (
            f"default allowlist must contain only the placeholder marker; "
            f"got {providers}"
        )

    def test_default_policy_yaml_documents_override_flag(self) -> None:
        """The YAML must name --open-allowlist so operators can find it."""
        text = _default_policy_path().read_text(encoding="utf-8")
        assert "--open-allowlist" in text


# ── CLI end-to-end ───────────────────────────────────────────────────────────


class TestCliEndToEnd:
    def test_tau_x402_version_works_via_help(self) -> None:
        """``--help`` is the CLI's cheap health-check; ``--version`` is not
        wired yet. Both must exit 0 without touching the network or fs."""
        out = _run_cli("--help")
        assert out.returncode == 0, f"stderr={out.stderr}"
        assert "tau-x402-cage" in out.stdout

    def test_tau_x402_run_help_works(self) -> None:
        out = _run_cli("run", "--help")
        assert out.returncode == 0, f"stderr={out.stderr}"
        # Help text must name the one-command-boot intent + the override flag.
        assert "run" in out.stdout
        assert "--open-allowlist" in out.stdout
        assert "--dry-run" in out.stdout

    def test_tau_x402_run_dry_run_boots_cleanly(self) -> None:
        """The dry-run path must print the boot banner + exit 0 without
        binding the UDS socket."""
        out = _run_cli("run", "--dry-run")
        assert out.returncode == 0, (
            f"stderr={out.stderr}\nstdout={out.stdout}"
        )
        # Banner lines land on stderr by design (stdout stays reserved
        # for JSON-emitting ops).
        stderr = out.stderr
        assert "booting front-door profile" in stderr
        assert "policy" in stderr
        assert "mode" in stderr
        assert "adaptive-tightening" in stderr
        # The stub branch must be reflected in the banner so we don't
        # mislead operators about which subsystems are live.
        assert re.search(
            r"adaptive-tightening\s*=\s*(stub|enabled)", stderr
        ), stderr

    def test_tau_x402_run_dry_run_with_open_allowlist(self) -> None:
        """--open-allowlist must surface in the banner line by line."""
        out = _run_cli("run", "--dry-run", "--open-allowlist")
        assert out.returncode == 0, f"stderr={out.stderr}"
        assert "open-allowlist    = True" in out.stderr

    def test_existing_tau_x402_cage_alias_still_works(self) -> None:
        """Back-compat: the old ``quickstart`` subcommand (wired to the
        ``tau-x402-cage`` script) must still parse + execute. We call it
        via ``-m daemon.cli`` which is what both script aliases resolve
        to after pyproject.toml installation, so this proves the
        entry-point back-compat without actually running ``pip install``.
        """
        import tempfile

        with tempfile.TemporaryDirectory() as tmp:
            out = _run_cli("quickstart", "--dir", tmp)
            assert out.returncode == 0, (
                f"stderr={out.stderr}\nstdout={out.stdout}"
            )
            assert "Scaffolded tau-x402-cage quickstart" in out.stdout
