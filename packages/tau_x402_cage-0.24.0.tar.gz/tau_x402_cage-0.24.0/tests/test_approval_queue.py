"""Tests for adapter/approval_queue.py.

Covers:
  * submit/approve/reject state transitions
  * JSON-lines persistence + rehydration
  * approve triggers revision mutation via daemon wiring
  * reject leaves registry untouched
  * two-person integrity: reviewer != submitter by default
"""

from __future__ import annotations

import json
from decimal import Decimal
from pathlib import Path

import pytest

from adapter.approval_queue import (
    ApprovalQueue,
    ApprovalQueueError,
    Proposal,
)
from adapter.invariants import (
    MaxPerCall,
    ProviderAllowlist,
)


# ── Proposal dataclass round-trip ────────────────────────────────────────────


class TestProposalSerialization:
    def test_to_dict_from_dict_round_trip(self) -> None:
        p = Proposal(
            proposal_id="p1",
            submitted_by="agent-a",
            submitted_at=1_713_000_000,
            invariants=(MaxPerCall(max_amount=Decimal("50")),),
            diff_from_revision="prev-rev",
            status="pending",
        )
        d = p.to_dict()
        rebuilt = Proposal.from_dict(json.loads(json.dumps(d)))
        assert rebuilt == p

    def test_from_dict_rejects_missing_fields(self) -> None:
        with pytest.raises(ApprovalQueueError, match="missing fields"):
            Proposal.from_dict({"proposal_id": "x"})

    def test_from_dict_rejects_unknown_status(self) -> None:
        d = {
            "proposal_id": "x",
            "submitted_by": "a",
            "submitted_at": 1,
            "invariants": [],
            "status": "not_real_status",
        }
        with pytest.raises(ApprovalQueueError, match="unknown status"):
            Proposal.from_dict(d)


# ── submit / approve / reject ────────────────────────────────────────────────


class TestSubmit:
    def test_submit_creates_pending_proposal(self) -> None:
        q = ApprovalQueue()
        p = q.submit(
            submitted_by="agent-a",
            invariants=[MaxPerCall(max_amount=Decimal("10"))],
            now_unix=100,
        )
        assert p.status == "pending"
        assert p.submitted_by == "agent-a"
        assert p.submitted_at == 100
        assert p.reviewed_by is None
        assert p.reviewed_at is None
        assert q.get(p.proposal_id) is p
        assert len(q) == 1

    def test_submit_rejects_empty_submitter(self) -> None:
        q = ApprovalQueue()
        with pytest.raises(ApprovalQueueError, match="submitted_by"):
            q.submit(
                submitted_by="",
                invariants=[MaxPerCall(max_amount=Decimal("1"))],
            )

    def test_submit_rejects_empty_invariants(self) -> None:
        q = ApprovalQueue()
        with pytest.raises(ApprovalQueueError, match="at least one invariant"):
            q.submit(submitted_by="a", invariants=[])

    def test_submit_rejects_non_invariant(self) -> None:
        q = ApprovalQueue()
        with pytest.raises(ApprovalQueueError, match="Invariant instances"):
            q.submit(submitted_by="a", invariants=["not an invariant"])  # type: ignore[list-item]

    def test_submit_detects_proposal_id_collision(self) -> None:
        q = ApprovalQueue()
        q.submit(
            submitted_by="a",
            invariants=[MaxPerCall(max_amount=Decimal("1"))],
            proposal_id="fixed-id",
        )
        with pytest.raises(ApprovalQueueError, match="collision"):
            q.submit(
                submitted_by="b",
                invariants=[MaxPerCall(max_amount=Decimal("2"))],
                proposal_id="fixed-id",
            )


class TestApprove:
    def test_approve_transitions_to_approved(self) -> None:
        q = ApprovalQueue()
        p = q.submit(
            submitted_by="agent-a",
            invariants=[MaxPerCall(max_amount=Decimal("10"))],
            now_unix=100,
        )
        approved = q.approve(
            proposal_id=p.proposal_id,
            reviewer="alice",
            reason="looks good",
            now_unix=200,
        )
        assert approved.status == "approved"
        assert approved.reviewed_by == "alice"
        assert approved.reviewed_at == 200
        assert approved.reason == "looks good"
        assert q.get(p.proposal_id).status == "approved"  # type: ignore[union-attr]

    def test_approve_rejects_same_submitter_by_default(self) -> None:
        q = ApprovalQueue()
        p = q.submit(
            submitted_by="alice",
            invariants=[MaxPerCall(max_amount=Decimal("10"))],
        )
        with pytest.raises(ApprovalQueueError, match="two-person integrity"):
            q.approve(proposal_id=p.proposal_id, reviewer="alice")

    def test_approve_allows_same_submitter_with_flag(self) -> None:
        q = ApprovalQueue()
        p = q.submit(
            submitted_by="alice",
            invariants=[MaxPerCall(max_amount=Decimal("10"))],
        )
        approved = q.approve(
            proposal_id=p.proposal_id,
            reviewer="alice",
            allow_same_as_submitter=True,
        )
        assert approved.status == "approved"

    def test_approve_rejects_unknown_proposal(self) -> None:
        q = ApprovalQueue()
        with pytest.raises(ApprovalQueueError, match="unknown proposal_id"):
            q.approve(proposal_id="nope", reviewer="alice")

    def test_approve_rejects_terminal_proposal(self) -> None:
        q = ApprovalQueue()
        p = q.submit(
            submitted_by="agent",
            invariants=[MaxPerCall(max_amount=Decimal("10"))],
        )
        q.approve(proposal_id=p.proposal_id, reviewer="alice")
        with pytest.raises(ApprovalQueueError, match="already approved"):
            q.approve(proposal_id=p.proposal_id, reviewer="bob")

    def test_approve_rejects_empty_reviewer(self) -> None:
        q = ApprovalQueue()
        p = q.submit(
            submitted_by="agent",
            invariants=[MaxPerCall(max_amount=Decimal("10"))],
        )
        with pytest.raises(ApprovalQueueError, match="reviewer"):
            q.approve(proposal_id=p.proposal_id, reviewer="")


class TestReject:
    def test_reject_transitions_to_rejected(self) -> None:
        q = ApprovalQueue()
        p = q.submit(
            submitted_by="agent-a",
            invariants=[MaxPerCall(max_amount=Decimal("10"))],
        )
        rejected = q.reject(
            proposal_id=p.proposal_id,
            reviewer="alice",
            reason="too permissive",
            now_unix=300,
        )
        assert rejected.status == "rejected"
        assert rejected.reviewed_by == "alice"
        assert rejected.reason == "too permissive"

    def test_reject_requires_reason(self) -> None:
        q = ApprovalQueue()
        p = q.submit(
            submitted_by="agent",
            invariants=[MaxPerCall(max_amount=Decimal("10"))],
        )
        with pytest.raises(ApprovalQueueError, match="reason"):
            q.reject(proposal_id=p.proposal_id, reviewer="alice", reason="")

    def test_reject_rejects_terminal_proposal(self) -> None:
        q = ApprovalQueue()
        p = q.submit(
            submitted_by="agent",
            invariants=[MaxPerCall(max_amount=Decimal("10"))],
        )
        q.reject(proposal_id=p.proposal_id, reviewer="alice", reason="no")
        with pytest.raises(ApprovalQueueError, match="already rejected"):
            q.reject(proposal_id=p.proposal_id, reviewer="bob", reason="still no")


# ── list / filter ────────────────────────────────────────────────────────────


class TestListProposals:
    def test_list_returns_all_by_default(self) -> None:
        q = ApprovalQueue()
        q.submit(
            submitted_by="a",
            invariants=[MaxPerCall(max_amount=Decimal("1"))],
            now_unix=1,
        )
        q.submit(
            submitted_by="b",
            invariants=[MaxPerCall(max_amount=Decimal("2"))],
            now_unix=2,
        )
        assert len(q.list()) == 2

    def test_list_filter_pending(self) -> None:
        q = ApprovalQueue()
        p1 = q.submit(
            submitted_by="a",
            invariants=[MaxPerCall(max_amount=Decimal("1"))],
        )
        p2 = q.submit(
            submitted_by="b",
            invariants=[MaxPerCall(max_amount=Decimal("2"))],
        )
        q.approve(p1.proposal_id, reviewer="alice")
        pending = q.list(status_filter="pending")
        assert len(pending) == 1
        assert pending[0].proposal_id == p2.proposal_id

    def test_list_filter_rejects_unknown_status(self) -> None:
        q = ApprovalQueue()
        with pytest.raises(ApprovalQueueError, match="status_filter"):
            q.list(status_filter="archived")


# ── persistence ──────────────────────────────────────────────────────────────


class TestPersistence:
    def test_submit_persists_line(self, tmp_path: Path) -> None:
        p = tmp_path / "proposals.jsonl"
        q = ApprovalQueue(path=p)
        q.submit(
            submitted_by="agent",
            invariants=[MaxPerCall(max_amount=Decimal("5"))],
        )
        assert p.exists()
        lines = p.read_text(encoding="utf-8").splitlines()
        assert len(lines) == 1

    def test_transitions_append_audit_lines(self, tmp_path: Path) -> None:
        p = tmp_path / "proposals.jsonl"
        q = ApprovalQueue(path=p)
        sub = q.submit(
            submitted_by="agent",
            invariants=[MaxPerCall(max_amount=Decimal("5"))],
        )
        q.approve(sub.proposal_id, reviewer="alice", reason="ok")
        # Submit line + approve line = 2 lines
        lines = p.read_text(encoding="utf-8").splitlines()
        assert len(lines) == 2

    def test_load_rehydrates_final_state(self, tmp_path: Path) -> None:
        p = tmp_path / "proposals.jsonl"
        q = ApprovalQueue(path=p)
        sub = q.submit(
            submitted_by="agent-x",
            invariants=[ProviderAllowlist(providers=frozenset({"anthropic"}))],
        )
        q.approve(sub.proposal_id, reviewer="alice", reason="ok")
        # Restart: load from disk, later line wins
        reloaded = ApprovalQueue.load(p)
        assert len(reloaded) == 1
        got = reloaded.get(sub.proposal_id)
        assert got is not None
        assert got.status == "approved"
        assert got.reviewed_by == "alice"

    def test_load_missing_file_returns_empty(self, tmp_path: Path) -> None:
        p = tmp_path / "not_here.jsonl"
        q = ApprovalQueue.load(p)
        assert len(q) == 0
        assert q.path == p

    def test_load_rejects_corrupted_line(self, tmp_path: Path) -> None:
        p = tmp_path / "proposals.jsonl"
        p.write_text("{not valid json\n", encoding="utf-8")
        with pytest.raises(ApprovalQueueError, match="malformed JSON"):
            ApprovalQueue.load(p)


# ── reviewer != submitter default (two-person integrity) ─────────────────────


class TestTwoPersonIntegrity:
    def test_reject_also_guards_same_submitter(self) -> None:
        q = ApprovalQueue()
        p = q.submit(
            submitted_by="alice",
            invariants=[MaxPerCall(max_amount=Decimal("10"))],
        )
        with pytest.raises(ApprovalQueueError, match="two-person integrity"):
            q.reject(
                proposal_id=p.proposal_id,
                reviewer="alice",
                reason="self-veto",
            )


# ── approve triggers revision mutation via daemon wiring ─────────────────────


class TestApproveTriggersMutation:
    """Exercise the queue against a real CageDaemon so the approve path ends
    up mutating the X402Registry exactly as `add_invariant` would.
    """

    def test_approve_adds_to_registry(self, tmp_path: Path) -> None:
        # Compat mode + pattern prover keeps this test fast & dependency-light
        from daemon.server import CageDaemon

        sock = str(tmp_path / "d.sock")
        log_path = tmp_path / "rev.jsonl"
        q_path = tmp_path / "props.jsonl"
        d = CageDaemon(
            socket_path=sock,
            revision_log_path=log_path,
            approval_queue_path=q_path,
        )

        # Submit a proposal directly against the daemon's queue
        resp = d.dispatch(
            {
                "op": "propose_invariant",
                "submitted_by": "agent-a",
                "invariants": [
                    {"kind": "max_per_call", "max_amount": "25"},
                ],
            }
        )
        assert resp["verdict"] == "pending_approval"
        pid = resp["proposal_id"]

        # Registry is untouched while proposal is pending
        assert len(d._x402_registry.invariants) == 0

        # Approve → registry gains the invariant
        approve_resp = d.dispatch(
            {
                "op": "approve_proposal",
                "proposal_id": pid,
                "reviewer": "alice",
                "reason": "first rule",
            }
        )
        assert approve_resp["verdict"] == "approved"
        assert approve_resp["admission"]["verdict"] == "updated"
        assert len(d._x402_registry.invariants) == 1

    def test_reject_does_not_mutate_registry(self, tmp_path: Path) -> None:
        from daemon.server import CageDaemon

        sock = str(tmp_path / "d.sock")
        log_path = tmp_path / "rev.jsonl"
        q_path = tmp_path / "props.jsonl"
        d = CageDaemon(
            socket_path=sock,
            revision_log_path=log_path,
            approval_queue_path=q_path,
        )
        resp = d.dispatch(
            {
                "op": "propose_invariant",
                "submitted_by": "agent-a",
                "invariants": [{"kind": "max_per_call", "max_amount": "25"}],
            }
        )
        pid = resp["proposal_id"]
        reject_resp = d.dispatch(
            {
                "op": "reject_proposal",
                "proposal_id": pid,
                "reviewer": "alice",
                "reason": "too permissive",
            }
        )
        assert reject_resp["verdict"] == "rejected"
        assert len(d._x402_registry.invariants) == 0
