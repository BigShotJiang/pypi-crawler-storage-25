"""Tests for the read-only web UI (v0.7.0).

The UI never mutates daemon state; these tests stub the daemon reader so
coverage focuses on routing, auth, templating, and pagination. An
end-to-end test against a real daemon lives in
``saas/tests/test_saas_app.py``.
"""

from __future__ import annotations

import os
from typing import Any, Dict, List, Mapping
from unittest.mock import patch

import pytest

pytest.importorskip("fastapi")
pytest.importorskip("jinja2")

from fastapi import FastAPI
from fastapi.testclient import TestClient

from saas.web_ui.routes import build_router, mount_static_on


TOKEN = "sk_test_web_ui_0123456789"


class StubReader:
    """Minimal DaemonReader for tests. Returns canned responses per op."""

    def __init__(self, responses: Mapping[str, Dict[str, Any]]) -> None:
        self._responses = dict(responses)
        self.calls: List[Dict[str, Any]] = []

    def request(self, payload: Mapping[str, object]) -> Dict[str, Any]:
        self.calls.append(dict(payload))
        op = payload.get("op")
        if op not in self._responses:
            return {"verdict": "error", "category": "unknown_op"}
        return dict(self._responses[op])


def _base_responses() -> Dict[str, Dict[str, Any]]:
    return {
        "health": {
            "verdict": "ok",
            "ready": True,
            "prover_backend": "python-pattern",
            "prover_mode": "compat",
            "tau_available": False,
            "invariants_active": 2,
            "revision_log_length": 3,
            "payment_history_length": 11,
            "reject_history_length": 4,
        },
        "inspect_policy": {
            "verdict": "ok",
            "active_revision_id": "abc123:nonce99",
            "active_invariants": 2,
            "invariants": [
                {"class": "MaxPerCall", "scope_hint": "max=100 USDC"},
                {"class": "ProviderAllowlist",
                 "scope_hint": "providers=['anthropic']"},
            ],
            "prover_mode": "compat",
            "proof_backend": "python-pattern",
            "proof_strength": "pattern",
            "fragment_version": "v1",
            "compile_hash": None,
            "admitted_at_unix": 1_700_000_000,
        },
        "active_revision": {"verdict": "ok", "revision": None},
        "revision_log": {
            "verdict": "ok",
            "length": 2,
            "revisions": [
                {
                    "config_hash": "abc123",
                    "revision_id": "abc123:nonce0",
                    "backend": "python-pattern",
                    "proof_strength": "pattern",
                    "prover_mode": "compat",
                    "nonce": "nonce0",
                    "issued_at_unix": 1_700_000_000,
                    "predecessor_hash": None,
                    "fragment_version": "v1",
                },
                {
                    "config_hash": "def456",
                    "revision_id": "def456:nonce1",
                    "backend": "python-pattern",
                    "proof_strength": "pattern",
                    "prover_mode": "compat",
                    "nonce": "nonce1",
                    "issued_at_unix": 1_700_000_100,
                    "predecessor_hash": "abc123",
                    "fragment_version": "v1",
                },
            ],
        },
        "recent_verdicts": {
            "verdict": "ok",
            "total": 2,
            "limit": 50,
            "offset": 0,
            "entries": [
                {
                    "verdict": "permit",
                    "rule_id": None,
                    "reason_text": None,
                    "intent": {
                        "amount": "10.00",
                        "currency": "USDC",
                        "provider": "anthropic",
                        "counterparty": "vendor_x",
                        "rail": "x402",
                        "timestamp_unix": 1_700_000_200,
                    },
                    "revision_id": "abc123:nonce0",
                },
                {
                    "verdict": "reject",
                    "rule_id": "max_per_call",
                    "reason_text": "amount > cap",
                    "intent": {
                        "amount": "500.00",
                        "currency": "USDC",
                        "provider": "anthropic",
                        "counterparty": "vendor_y",
                        "rail": "x402",
                        "timestamp_unix": 1_700_000_300,
                    },
                    "revision_id": "abc123:nonce0",
                },
            ],
        },
    }


@pytest.fixture
def reader() -> StubReader:
    return StubReader(_base_responses())


@pytest.fixture
def app(reader: StubReader) -> FastAPI:
    a = FastAPI()
    router = build_router(reader=reader, token=TOKEN)
    a.include_router(router, prefix="/ui")
    mount_static_on(a)
    return a


@pytest.fixture
def client(app: FastAPI) -> TestClient:
    return TestClient(app)


def _authed_get(client: TestClient, path: str) -> Any:
    return client.get(path, headers={"Authorization": f"Bearer {TOKEN}"})


# ── auth surface ─────────────────────────────────────────────────────────────


class TestAuth:
    def test_missing_token_returns_403(self, client: TestClient) -> None:
        r = client.get("/ui/")
        assert r.status_code == 403
        assert "missing Bearer token" in r.json()["detail"]

    def test_wrong_token_returns_403(self, client: TestClient) -> None:
        r = client.get("/ui/", headers={"Authorization": "Bearer nope"})
        assert r.status_code == 403
        assert "invalid token" in r.json()["detail"]

    def test_non_bearer_scheme_returns_403(self, client: TestClient) -> None:
        r = client.get("/ui/", headers={"Authorization": "Basic xxx"})
        assert r.status_code == 403

    def test_fail_closed_when_token_unset(self, reader: StubReader) -> None:
        """With TAU_CAGE_WEB_UI_TOKEN unset and no explicit token, every
        request must be rejected — failing open would be catastrophic."""
        a = FastAPI()
        with patch.dict(os.environ, {}, clear=False):
            os.environ.pop("TAU_CAGE_WEB_UI_TOKEN", None)
            router = build_router(reader=reader, token=None)
            a.include_router(router, prefix="/ui")
        c = TestClient(a)
        # Even with a plausible token the client supplies, server rejects.
        r = c.get("/ui/", headers={"Authorization": f"Bearer {TOKEN}"})
        assert r.status_code == 403
        assert "not provisioned" in r.json()["detail"]

    def test_mount_is_404_when_feature_flag_unset(self) -> None:
        """When ``TAU_CAGE_WEB_UI_ENABLED`` is not set on the hosting app
        factory, the UI is never mounted and every /ui/* path 404s."""
        from saas.app import SaasConfig, create_app
        from saas.billing import NullBillingReporter

        with patch.dict(os.environ, {}, clear=False):
            os.environ.pop("TAU_CAGE_WEB_UI_ENABLED", None)
            cfg = SaasConfig(
                api_keys={"acme": "sk_test"},
                socket_path="/tmp/does-not-exist.sock",
                hmac_secret=b"\x00" * 32,
                billing=NullBillingReporter(),
            )
            saas_app = create_app(cfg)
        c = TestClient(saas_app)
        r = c.get("/ui/")
        assert r.status_code == 404


# ── route availability ───────────────────────────────────────────────────────


class TestRoutes:
    def test_landing_ok(self, client: TestClient) -> None:
        r = _authed_get(client, "/ui/")
        assert r.status_code == 200
        assert "text/html" in r.headers["content-type"]
        # Question-led H1 is part of the Tau Net house style.
        assert "What is the cage enforcing right now?" in r.text

    def test_policy_ok(self, client: TestClient) -> None:
        r = _authed_get(client, "/ui/policy")
        assert r.status_code == 200
        assert "Which invariants would fire right now?" in r.text
        assert "MaxPerCall" in r.text
        assert "ProviderAllowlist" in r.text

    def test_revisions_ok(self, client: TestClient) -> None:
        r = _authed_get(client, "/ui/revisions")
        assert r.status_code == 200
        assert "How has the policy changed over time?" in r.text
        assert "abc123" in r.text
        assert "def456" in r.text

    def test_revision_detail_hit(self, client: TestClient) -> None:
        r = _authed_get(client, "/ui/revisions/abc123")
        assert r.status_code == 200
        assert "What did this revision admit?" in r.text
        assert "abc123" in r.text

    def test_revision_detail_miss_renders_not_found(
        self, client: TestClient
    ) -> None:
        r = _authed_get(client, "/ui/revisions/not-a-real-hash")
        assert r.status_code == 200
        # Render is a soft 200 with an error banner, not a hard 404,
        # because the route is valid even for ids we've never seen.
        assert "not found in the daemon" in r.text

    def test_verdicts_ok(self, client: TestClient) -> None:
        r = _authed_get(client, "/ui/verdicts")
        assert r.status_code == 200
        assert "What did the cage decide most recently?" in r.text
        assert "permit" in r.text
        assert "reject" in r.text
        assert "max_per_call" in r.text

    def test_health_ok(self, client: TestClient) -> None:
        r = _authed_get(client, "/ui/health")
        assert r.status_code == 200
        assert "Is the cage daemon healthy?" in r.text
        assert "python-pattern" in r.text

    def test_static_js_served(self, client: TestClient) -> None:
        r = client.get("/ui/static/app.js")
        assert r.status_code == 200
        assert "javascript" in r.headers["content-type"].lower() \
            or "js" in r.headers["content-type"].lower()


# ── pagination ───────────────────────────────────────────────────────────────


class TestPagination:
    def test_verdicts_forwards_limit_offset(
        self, client: TestClient, reader: StubReader
    ) -> None:
        r = _authed_get(client, "/ui/verdicts?limit=25&offset=5")
        assert r.status_code == 200
        # Find the recent_verdicts call the reader saw.
        rv_calls = [c for c in reader.calls if c.get("op") == "recent_verdicts"]
        assert rv_calls, "web UI should have queried recent_verdicts"
        assert rv_calls[-1]["limit"] == 25
        assert rv_calls[-1]["offset"] == 5

    def test_verdicts_rejects_over_max(self, client: TestClient) -> None:
        r = _authed_get(client, "/ui/verdicts?limit=9999")
        # FastAPI's Query(ge=, le=) validation rejects before reaching
        # the daemon.
        assert r.status_code == 422

    def test_revisions_rejects_negative_offset(self, client: TestClient) -> None:
        r = _authed_get(client, "/ui/revisions?offset=-1")
        assert r.status_code == 422


# ── read-only invariant ──────────────────────────────────────────────────────


class TestReadOnly:
    @pytest.mark.parametrize(
        "path",
        [
            "/ui/",
            "/ui/policy",
            "/ui/revisions",
            "/ui/revisions/abc123",
            "/ui/verdicts",
            "/ui/health",
        ],
    )
    def test_post_rejected(self, client: TestClient, path: str) -> None:
        r = client.post(path, headers={"Authorization": f"Bearer {TOKEN}"})
        assert r.status_code == 405

    @pytest.mark.parametrize(
        "path",
        [
            "/ui/",
            "/ui/policy",
            "/ui/revisions",
            "/ui/verdicts",
            "/ui/health",
        ],
    )
    def test_delete_rejected(self, client: TestClient, path: str) -> None:
        r = client.delete(path, headers={"Authorization": f"Bearer {TOKEN}"})
        assert r.status_code == 405

    def test_no_mutation_ops_queried(
        self, client: TestClient, reader: StubReader
    ) -> None:
        """Exercise every GET route; ensure the daemon only sees read ops."""
        for path in (
            "/ui/",
            "/ui/policy",
            "/ui/revisions",
            "/ui/verdicts",
            "/ui/health",
            "/ui/revisions/abc123",
        ):
            r = _authed_get(client, path)
            assert r.status_code == 200, path
        allowed_read_ops = {
            "health",
            "inspect_policy",
            "active_revision",
            "revision_log",
            "recent_verdicts",
        }
        used_ops = {c.get("op") for c in reader.calls}
        assert used_ops.issubset(allowed_read_ops), (
            f"UI must be read-only; saw unexpected ops: "
            f"{used_ops - allowed_read_ops}"
        )


# ── v0.17.0: runtime-state panel on /ui/safety ───────────────────────────────


class TestRuntimeGuardPanel:
    """The runtime-guard panel is gated on the daemon exposing a
    ``runtime_state`` op. When present the panel renders values; when
    absent (older daemons, or the runtime-guard agent not shipped) the
    panel falls back to a graceful unavailable notice."""

    def _safety_reader(
        self, runtime_state_response: Dict[str, Any] | None,
    ) -> StubReader:
        base = _base_responses()
        # /ui/safety also reads these; give them sensible empty shapes.
        base["risk_aggregate"] = {"verdict": "ok", "aggregate": {}}
        base["active_constraints"] = {"verdict": "ok", "constraints": []}
        base["mutation_failures"] = {"verdict": "ok", "entries": []}
        if runtime_state_response is not None:
            base["runtime_state"] = runtime_state_response
        # When runtime_state_response is None we leave the op absent so
        # the StubReader returns the "unknown_op" error envelope.
        return StubReader(base)

    def _client_from(self, reader: StubReader) -> TestClient:
        a = FastAPI()
        router = build_router(reader=reader, token=TOKEN)
        a.include_router(router, prefix="/ui")
        mount_static_on(a)
        return TestClient(a)

    def test_panel_dom_id_present(self) -> None:
        """The runtime-guard panel must render under a stable DOM id so
        operator tooling (curl + grep, bookmarklets) can find it."""
        reader = self._safety_reader(None)
        client = self._client_from(reader)
        r = _authed_get(client, "/ui/safety")
        assert r.status_code == 200
        assert 'id="runtime-guard-state"' in r.text

    def test_panel_renders_unavailable_when_op_missing(self) -> None:
        """Older daemons don't expose runtime_state; the panel must not
        500 and must surface a plain-English unavailable notice."""
        reader = self._safety_reader(None)
        client = self._client_from(reader)
        r = _authed_get(client, "/ui/safety")
        assert r.status_code == 200
        assert "Runtime guard state unavailable" in r.text

    def test_panel_renders_values_when_op_succeeds(self) -> None:
        runtime_response = {
            "verdict": "ok",
            "tightening_level": "moderate",
            "spend_velocity": {
                "rate_per_second": "1.23",
                "window_total": "12.34",
                "currency": "USDC",
            },
            "retry_density": [
                {
                    "provider": "anthropic",
                    "counterparty": "vendor_expensive_ai",
                    "endpoint": "/api/expensive-ai-query",
                    "count": 11,
                },
                {
                    "provider": "openai",
                    "counterparty": "vendor_image_gen",
                    "endpoint": "/api/image",
                    "count": 3,
                },
            ],
            "active_cooldowns": [
                {"source": "retry_rate_limit", "expires_in_seconds": 17},
            ],
        }
        reader = self._safety_reader(runtime_response)
        client = self._client_from(reader)
        r = _authed_get(client, "/ui/safety")
        assert r.status_code == 200
        # Tightening level surfaces in its exact form.
        assert "moderate" in r.text
        # Velocity numeric is present.
        assert "1.23" in r.text
        # One of the top retry tuples is rendered.
        assert "vendor_expensive_ai" in r.text
        # Active cooldown source surfaces.
        assert "retry_rate_limit" in r.text

    def test_panel_shows_error_banner_on_daemon_unreachable(self) -> None:
        """If the runtime_state call itself raised (not just unknown op),
        the template still renders, with a distinct error banner."""
        # Daemon reader that throws on runtime_state specifically.
        class PartlyDeadReader:
            def __init__(self) -> None:
                self.calls: List[Dict[str, Any]] = []

            def request(self, payload: Mapping[str, object]) -> Dict[str, Any]:
                self.calls.append(dict(payload))
                if payload.get("op") == "runtime_state":
                    raise FileNotFoundError("runtime socket gone")
                # Return OK base responses for the other ops on /ui/safety.
                op = payload.get("op")
                base = _base_responses()
                base["risk_aggregate"] = {"verdict": "ok", "aggregate": {}}
                base["active_constraints"] = {
                    "verdict": "ok", "constraints": [],
                }
                base["mutation_failures"] = {"verdict": "ok", "entries": []}
                return dict(base.get(op, {"verdict": "ok"}))

        reader = PartlyDeadReader()
        a = FastAPI()
        router = build_router(reader=reader, token=TOKEN)
        a.include_router(router, prefix="/ui")
        mount_static_on(a)
        client = TestClient(a)
        r = _authed_get(client, "/ui/safety")
        assert r.status_code == 200
        # Both the global "daemon unreachable" banner (from other panels)
        # and the runtime-guard panel's own error handling are acceptable;
        # the point is the page still renders.
        assert "runtime-guard-state" in r.text


# ── resilience ───────────────────────────────────────────────────────────────


class TestResilience:
    def test_daemon_unreachable_renders_error_banner(self) -> None:
        class DeadReader:
            calls: List[Any] = []

            def request(self, payload: Mapping[str, object]) -> Dict[str, Any]:
                raise FileNotFoundError("socket missing")

        a = FastAPI()
        router = build_router(reader=DeadReader(), token=TOKEN)
        a.include_router(router, prefix="/ui")
        mount_static_on(a)
        c = TestClient(a)
        r = c.get("/ui/", headers={"Authorization": f"Bearer {TOKEN}"})
        # Page renders 200 with a visible error banner rather than 500,
        # so an on-call engineer sees a readable failure mode.
        assert r.status_code == 200
        assert "Daemon unreachable" in r.text
