"""End-to-end daemon tests for the approval queue wiring.

Spins up a real CageDaemon over UDS and drives it through the full
agent-proposes / human-approves lifecycle:
  * propose_invariant → pending proposal id
  * list_proposals / get_proposal → query surface
  * approve_proposal → registry mutates + admission envelope
  * reject_proposal → registry unchanged
  * require_human_approval=True flips add_invariant into propose path
"""

from __future__ import annotations

import json
import os
import socket
import tempfile
import threading
import time
from pathlib import Path
from typing import Iterator

import pytest

from daemon.server import CageDaemon


# ── helpers ──────────────────────────────────────────────────────────────────


def _send(path: str, req: dict, timeout: float = 2.0) -> dict:
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.settimeout(timeout)
    s.connect(path)
    try:
        s.sendall((json.dumps(req) + "\n").encode("utf-8"))
        f = s.makefile("r")
        return json.loads(f.readline())
    finally:
        s.close()


@pytest.fixture
def daemon_with_queue(tmp_path: Path) -> Iterator[tuple[str, Path, Path]]:
    """CageDaemon with a persistent revision log and approval queue."""
    fd, sock = tempfile.mkstemp(prefix="daemon-approval-", suffix=".sock", dir="/tmp")
    os.close(fd)
    os.unlink(sock)
    log_path = tmp_path / "rev.jsonl"
    q_path = tmp_path / "proposals.jsonl"
    d = CageDaemon(
        socket_path=sock,
        revision_log_path=log_path,
        approval_queue_path=q_path,
    )
    t = threading.Thread(target=d.serve_forever, daemon=True)
    t.start()
    for _ in range(50):
        if os.path.exists(sock):
            break
        time.sleep(0.01)
    try:
        yield sock, log_path, q_path
    finally:
        d.shutdown()
        t.join(timeout=1.0)


@pytest.fixture
def daemon_require_approval(tmp_path: Path) -> Iterator[tuple[str, Path, Path]]:
    """CageDaemon that forces add_invariant into propose path."""
    fd, sock = tempfile.mkstemp(prefix="daemon-req-approval-", suffix=".sock", dir="/tmp")
    os.close(fd)
    os.unlink(sock)
    log_path = tmp_path / "rev.jsonl"
    q_path = tmp_path / "proposals.jsonl"
    d = CageDaemon(
        socket_path=sock,
        revision_log_path=log_path,
        approval_queue_path=q_path,
        require_human_approval=True,
    )
    t = threading.Thread(target=d.serve_forever, daemon=True)
    t.start()
    for _ in range(50):
        if os.path.exists(sock):
            break
        time.sleep(0.01)
    try:
        yield sock, log_path, q_path
    finally:
        d.shutdown()
        t.join(timeout=1.0)


# ── propose_invariant ────────────────────────────────────────────────────────


class TestDaemonPropose:
    def test_propose_returns_pending_with_id(self, daemon_with_queue) -> None:
        sock, _, _ = daemon_with_queue
        resp = _send(sock, {
            "op": "propose_invariant",
            "submitted_by": "bot-a",
            "invariants": [{"kind": "max_per_call", "max_amount": "100"}],
        })
        assert resp["verdict"] == "pending_approval"
        assert resp["status_code"] == 202
        assert "proposal_id" in resp
        assert resp["proposal"]["submitted_by"] == "bot-a"
        assert resp["proposal"]["status"] == "pending"

    def test_propose_persists_to_disk(self, daemon_with_queue) -> None:
        sock, _, q_path = daemon_with_queue
        resp = _send(sock, {
            "op": "propose_invariant",
            "submitted_by": "bot-a",
            "invariants": [{"kind": "max_per_call", "max_amount": "100"}],
        })
        assert q_path.exists()
        lines = q_path.read_text(encoding="utf-8").splitlines()
        assert len(lines) == 1
        saved = json.loads(lines[0])
        assert saved["proposal_id"] == resp["proposal_id"]
        assert saved["status"] == "pending"

    def test_propose_rejects_empty_submitted_by(self, daemon_with_queue) -> None:
        sock, _, _ = daemon_with_queue
        resp = _send(sock, {
            "op": "propose_invariant",
            "submitted_by": "",
            "invariants": [{"kind": "max_per_call", "max_amount": "100"}],
        })
        assert resp["verdict"] == "error"
        assert resp["category"] == "bad_proposal"

    def test_propose_rejects_empty_invariants(self, daemon_with_queue) -> None:
        sock, _, _ = daemon_with_queue
        resp = _send(sock, {
            "op": "propose_invariant",
            "submitted_by": "bot",
            "invariants": [],
        })
        assert resp["verdict"] == "error"

    def test_propose_rejects_bad_invariant(self, daemon_with_queue) -> None:
        sock, _, _ = daemon_with_queue
        resp = _send(sock, {
            "op": "propose_invariant",
            "submitted_by": "bot",
            "invariants": [{"kind": "no_such_kind"}],
        })
        assert resp["verdict"] == "error"
        assert resp["category"] in ("bad_invariant", "bad_proposal")

    def test_registry_untouched_while_pending(self, daemon_with_queue) -> None:
        sock, _, _ = daemon_with_queue
        _send(sock, {
            "op": "propose_invariant",
            "submitted_by": "bot",
            "invariants": [{"kind": "max_per_call", "max_amount": "100"}],
        })
        active = _send(sock, {"op": "active_x402"})
        assert active["active_invariants"] == 0


# ── approve_proposal ─────────────────────────────────────────────────────────


class TestDaemonApprove:
    def test_approve_mutates_registry(self, daemon_with_queue) -> None:
        sock, _, _ = daemon_with_queue
        propose = _send(sock, {
            "op": "propose_invariant",
            "submitted_by": "bot",
            "invariants": [{"kind": "max_per_call", "max_amount": "50"}],
        })
        pid = propose["proposal_id"]
        resp = _send(sock, {
            "op": "approve_proposal",
            "proposal_id": pid,
            "reviewer": "alice",
            "reason": "sensible cap",
        })
        assert resp["verdict"] == "approved"
        assert resp["admission"]["verdict"] == "updated"
        active = _send(sock, {"op": "active_x402"})
        assert active["active_invariants"] == 1

    def test_approve_unknown_proposal(self, daemon_with_queue) -> None:
        sock, _, _ = daemon_with_queue
        resp = _send(sock, {
            "op": "approve_proposal",
            "proposal_id": "no-such-id",
            "reviewer": "alice",
        })
        assert resp["verdict"] == "error"

    def test_approve_requires_reviewer(self, daemon_with_queue) -> None:
        sock, _, _ = daemon_with_queue
        propose = _send(sock, {
            "op": "propose_invariant",
            "submitted_by": "bot",
            "invariants": [{"kind": "max_per_call", "max_amount": "50"}],
        })
        resp = _send(sock, {
            "op": "approve_proposal",
            "proposal_id": propose["proposal_id"],
            "reviewer": "",
        })
        assert resp["verdict"] == "error"

    def test_approve_blocks_self_approval(self, daemon_with_queue) -> None:
        sock, _, _ = daemon_with_queue
        propose = _send(sock, {
            "op": "propose_invariant",
            "submitted_by": "alice",
            "invariants": [{"kind": "max_per_call", "max_amount": "50"}],
        })
        resp = _send(sock, {
            "op": "approve_proposal",
            "proposal_id": propose["proposal_id"],
            "reviewer": "alice",
        })
        assert resp["verdict"] == "error"
        assert "two-person" in resp["reason"]

    def test_approve_allows_self_with_flag(self, daemon_with_queue) -> None:
        sock, _, _ = daemon_with_queue
        propose = _send(sock, {
            "op": "propose_invariant",
            "submitted_by": "alice",
            "invariants": [{"kind": "max_per_call", "max_amount": "50"}],
        })
        resp = _send(sock, {
            "op": "approve_proposal",
            "proposal_id": propose["proposal_id"],
            "reviewer": "alice",
            "allow_same_as_submitter": True,
        })
        assert resp["verdict"] == "approved"


# ── reject_proposal ──────────────────────────────────────────────────────────


class TestDaemonReject:
    def test_reject_leaves_registry_unchanged(self, daemon_with_queue) -> None:
        sock, _, _ = daemon_with_queue
        propose = _send(sock, {
            "op": "propose_invariant",
            "submitted_by": "bot",
            "invariants": [{"kind": "max_per_call", "max_amount": "50"}],
        })
        resp = _send(sock, {
            "op": "reject_proposal",
            "proposal_id": propose["proposal_id"],
            "reviewer": "alice",
            "reason": "too loose",
        })
        assert resp["verdict"] == "rejected"
        active = _send(sock, {"op": "active_x402"})
        assert active["active_invariants"] == 0

    def test_reject_requires_reason(self, daemon_with_queue) -> None:
        sock, _, _ = daemon_with_queue
        propose = _send(sock, {
            "op": "propose_invariant",
            "submitted_by": "bot",
            "invariants": [{"kind": "max_per_call", "max_amount": "50"}],
        })
        resp = _send(sock, {
            "op": "reject_proposal",
            "proposal_id": propose["proposal_id"],
            "reviewer": "alice",
        })
        assert resp["verdict"] == "error"


# ── list / get ───────────────────────────────────────────────────────────────


class TestDaemonListAndGet:
    def test_list_returns_all(self, daemon_with_queue) -> None:
        sock, _, _ = daemon_with_queue
        for i in range(3):
            _send(sock, {
                "op": "propose_invariant",
                "submitted_by": f"bot-{i}",
                "invariants": [{"kind": "max_per_call", "max_amount": str(i + 1)}],
            })
        resp = _send(sock, {"op": "list_proposals"})
        assert resp["verdict"] == "ok"
        assert resp["count"] == 3
        assert len(resp["proposals"]) == 3

    def test_list_filter_pending_excludes_approved(self, daemon_with_queue) -> None:
        sock, _, _ = daemon_with_queue
        p1 = _send(sock, {
            "op": "propose_invariant",
            "submitted_by": "bot-1",
            "invariants": [{"kind": "max_per_call", "max_amount": "10"}],
        })
        _send(sock, {
            "op": "propose_invariant",
            "submitted_by": "bot-2",
            "invariants": [{"kind": "max_per_call", "max_amount": "20"}],
        })
        _send(sock, {
            "op": "approve_proposal",
            "proposal_id": p1["proposal_id"],
            "reviewer": "alice",
        })
        pending = _send(sock, {"op": "list_proposals", "status": "pending"})
        assert pending["count"] == 1

    def test_get_returns_proposal(self, daemon_with_queue) -> None:
        sock, _, _ = daemon_with_queue
        propose = _send(sock, {
            "op": "propose_invariant",
            "submitted_by": "bot",
            "invariants": [{"kind": "max_per_call", "max_amount": "10"}],
        })
        resp = _send(sock, {"op": "get_proposal", "proposal_id": propose["proposal_id"]})
        assert resp["verdict"] == "ok"
        assert resp["proposal"]["proposal_id"] == propose["proposal_id"]

    def test_get_unknown_proposal(self, daemon_with_queue) -> None:
        sock, _, _ = daemon_with_queue
        resp = _send(sock, {"op": "get_proposal", "proposal_id": "nope"})
        assert resp["verdict"] == "error"
        assert resp["category"] == "unknown_proposal"


# ── require_human_approval flag ──────────────────────────────────────────────


class TestRequireHumanApproval:
    def test_add_invariant_becomes_proposal(self, daemon_require_approval) -> None:
        sock, _, q_path = daemon_require_approval
        resp = _send(sock, {
            "op": "add_invariant",
            "invariant": {"kind": "max_per_call", "max_amount": "50"},
            "submitted_by": "agent-x",
        })
        assert resp["verdict"] == "pending_approval"
        assert resp["status_code"] == 202
        assert "proposal_id" in resp
        # Registry still empty
        active = _send(sock, {"op": "active_x402"})
        assert active["active_invariants"] == 0
        # Proposal persisted to jsonl
        assert q_path.exists()


# ── end-to-end: propose → approve → check ────────────────────────────────────


class TestEndToEnd:
    def test_full_lifecycle_propose_approve_check(self, daemon_with_queue) -> None:
        sock, _, _ = daemon_with_queue
        # 1. Agent proposes
        propose = _send(sock, {
            "op": "propose_invariant",
            "submitted_by": "risk-bot",
            "invariants": [{"kind": "max_per_call", "max_amount": "5"}],
        })
        pid = propose["proposal_id"]
        # 2. Human approves
        approve = _send(sock, {
            "op": "approve_proposal",
            "proposal_id": pid,
            "reviewer": "alice",
            "reason": "ok",
        })
        assert approve["verdict"] == "approved"
        # 3. Payment over the cap is now rejected
        check = _send(sock, {
            "op": "check_payment",
            "intent": {
                "amount": "10",
                "currency": "USDC",
                "provider": "anthropic",
                "counterparty": "vendor_a",
                "rail": "x402",
                "timestamp_unix": 1_713_000_000,
                "request_id": "req-1",
            },
        })
        assert check["verdict"] == "reject"

    def test_rehydration_across_restart(self, tmp_path: Path) -> None:
        """Proposals survive a daemon restart."""
        fd, sock = tempfile.mkstemp(prefix="rehydrate-", suffix=".sock", dir="/tmp")
        os.close(fd)
        os.unlink(sock)
        log_path = tmp_path / "rev.jsonl"
        q_path = tmp_path / "proposals.jsonl"

        # Boot 1: propose
        d1 = CageDaemon(
            socket_path=sock,
            revision_log_path=log_path,
            approval_queue_path=q_path,
        )
        t1 = threading.Thread(target=d1.serve_forever, daemon=True)
        t1.start()
        for _ in range(50):
            if os.path.exists(sock):
                break
            time.sleep(0.01)
        resp = _send(sock, {
            "op": "propose_invariant",
            "submitted_by": "bot",
            "invariants": [{"kind": "max_per_call", "max_amount": "5"}],
        })
        pid = resp["proposal_id"]
        d1.shutdown()
        t1.join(timeout=1.0)

        # Boot 2: same paths — verify the pending proposal is still there
        d2 = CageDaemon(
            socket_path=sock,
            revision_log_path=log_path,
            approval_queue_path=q_path,
        )
        t2 = threading.Thread(target=d2.serve_forever, daemon=True)
        t2.start()
        for _ in range(50):
            if os.path.exists(sock):
                break
            time.sleep(0.01)
        try:
            got = _send(sock, {"op": "get_proposal", "proposal_id": pid})
            assert got["verdict"] == "ok"
            assert got["proposal"]["status"] == "pending"
        finally:
            d2.shutdown()
            t2.join(timeout=1.0)
