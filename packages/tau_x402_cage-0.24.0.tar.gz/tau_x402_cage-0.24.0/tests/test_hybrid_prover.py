"""Tests for the v0.8.0 cross-fragment hybrid SAT prover.

Acceptance criteria (from the v0.8.0 brief):
  (a) v1-only policy: HybridProver matches Tau verdict.
  (b) v2-only policy: HybridProver matches z3 verdict.
  (c) mixed policy without cross-interaction: composed SAT.
  (d) mixed policy WITH cross-interaction: structured contradiction
      surfaced by the shared-variable projection.
  (e) delta admission preserves the hybrid path.
  (f) contradiction in v1 short-circuits z3 (no wasted solver call).

Style mirrors tests/test_z3_incremental.py.
"""
from __future__ import annotations

from decimal import Decimal

import pytest

from adapter.invariants import (
    CounterpartyConstraint,
    MaxPerCall,
    MutualExclusion,
    ProviderAllowlist,
    RetryRateLimit,
    RollingWindowCap,
    SpendingCap,
)

# Skip the whole module if z3 isn't importable — HybridProver routes v2
# rules to z3 and testing without it would mask the composition shape.
z3 = pytest.importorskip("z3", reason="z3-solver not installed")

from adapter.hybrid_prover import HYBRID_BACKEND, HybridProver
from adapter.prover import (
    Contradiction,
    InconclusiveProof,
    IncrementalZ3Prover,
    ProofToken,
    PythonPatternProver,
    TauConsistencyProver,
    Z3ConsistencyProver,
)
from daemon.server import CageDaemon


# ── stub Tau prover ──────────────────────────────────────────────────────────


class _StubTau:
    """Deterministic in-process stand-in for TauConsistencyProver.

    The real Tau prover needs the Tau CLI on PATH and the cvc5 dylib,
    neither of which are guaranteed in CI. This stub emits a
    ProofToken(proof_strength="complete", backend="tau") on an SAT
    verdict and a Contradiction on an UNSAT verdict, so the hybrid
    composition shape can be exercised without the real binary.
    """

    backend: str = "tau"

    def __init__(self, verdict: str = "sat", call_log: list | None = None) -> None:
        self._verdict = verdict
        self.call_log = call_log if call_log is not None else []

    def prove(self, invariants, predecessor_hash=None):
        self.call_log.append(tuple(invariants))
        if self._verdict == "sat":
            return ProofToken(
                config_hash="tau-stub-hash",
                issued_at_unix=0,
                backend="tau",
                proof_strength="complete",
                nonce="stub",
                predecessor_hash=predecessor_hash,
                fragment_version="v1",
                compile_hash="stub-compile",
                tau_backend_version="stub-1.0",
            )
        if self._verdict == "unsat":
            return Contradiction(
                left="tau-stub-left",
                right="tau-stub-right",
                reason="tau stub UNSAT",
                backend="tau",
            )
        return InconclusiveProof(
            category=self._verdict,
            reason=f"tau stub {self._verdict}",
            backend="tau",
        )


# ── (a) v1-only parity with Tau ──────────────────────────────────────────────


class TestAcceptanceA_V1OnlyMatchesTau:
    """Hybrid prover MUST agree with Tau when only v1 invariants are present."""

    def test_v1_only_sat_matches_tau_sat(self) -> None:
        policy = (
            MaxPerCall(max_amount=Decimal("50")),
            ProviderAllowlist(providers=frozenset({"anthropic", "openai"})),
        )
        tau_log: list = []
        hp = HybridProver(
            tau_prover=_StubTau("sat", call_log=tau_log),
            z3_prover=IncrementalZ3Prover(),
            pattern_prover=PythonPatternProver(),
        )
        r = hp.prove(policy)
        assert isinstance(r, ProofToken), r
        assert r.backend == HYBRID_BACKEND
        assert r.proof_strength == "complete"
        assert r.fragment_version == "hybrid"
        # Tau was consulted exactly once, with the v1 subset.
        assert len(tau_log) == 1
        assert set(tau_log[0]) == set(policy)

    def test_v1_only_unsat_matches_tau_unsat(self) -> None:
        policy = (
            MaxPerCall(max_amount=Decimal("50")),
            ProviderAllowlist(providers=frozenset({"anthropic"})),
        )
        hp = HybridProver(
            tau_prover=_StubTau("unsat"),
            z3_prover=IncrementalZ3Prover(),
            pattern_prover=PythonPatternProver(),
        )
        r = hp.prove(policy)
        assert isinstance(r, Contradiction)
        assert r.backend == "tau"
        assert "tau stub UNSAT" in r.reason


# ── (b) v2-only parity with z3 ───────────────────────────────────────────────


class TestAcceptanceB_V2OnlyMatchesZ3:
    """Hybrid prover MUST agree with z3 when only v2 invariants are present."""

    def test_v2_only_sat_matches_z3_sat(self) -> None:
        policy = (
            SpendingCap(max_amount=Decimal("1000"), scope="per_window",
                        window_seconds=86400),
            RollingWindowCap(max_count=10, window_seconds=60,
                             group_by="provider"),
            RetryRateLimit(min_gap_seconds=5),
        )
        z3_baseline = Z3ConsistencyProver()
        baseline = z3_baseline.prove(policy)
        assert isinstance(baseline, ProofToken)

        hp = HybridProver(
            tau_prover=_StubTau("sat"),
            z3_prover=IncrementalZ3Prover(),
            pattern_prover=PythonPatternProver(),
        )
        r = hp.prove(policy)
        assert isinstance(r, ProofToken), r
        assert r.backend == HYBRID_BACKEND
        assert r.proof_strength == "complete"

    def test_v2_invariant_rejected_cleanly_matches_z3_reject(self) -> None:
        # A RetryRateLimit with an enormous gap is still SAT (unbounded).
        # Use the fragment-guard behaviour: pass a v1-only rule to the
        # z3 prover alone and observe the Contradiction.
        inc = IncrementalZ3Prover()
        r = inc.prove_delta(added=[MaxPerCall(max_amount=Decimal("10"))])
        assert isinstance(r, Contradiction)
        # The hybrid prover routes v1 to Tau so it does NOT see this
        # Contradiction; the test here is just confirming the z3 side's
        # baseline reject shape the hybrid prover depends on.


# ── (c) mixed policy without cross-interaction ───────────────────────────────


class TestAcceptanceC_MixedWithoutInteraction:
    """Mixed v1 + v2 with no cross-variable references composes to SAT."""

    def test_mixed_sat_composed_ok(self) -> None:
        policy = (
            MaxPerCall(max_amount=Decimal("50")),
            ProviderAllowlist(providers=frozenset({"anthropic", "openai"})),
            SpendingCap(max_amount=Decimal("1000"), scope="per_window",
                        window_seconds=86400),
            RetryRateLimit(min_gap_seconds=5),
        )
        hp = HybridProver(
            tau_prover=_StubTau("sat"),
            z3_prover=IncrementalZ3Prover(),
            pattern_prover=PythonPatternProver(),
        )
        r = hp.prove(policy)
        assert isinstance(r, ProofToken), r
        # Backend chain: pattern + tau + z3-incremental.
        backends = getattr(r, "_backends", ())
        assert "pattern" in backends
        assert any("tau" in b for b in backends)
        assert any("z3" in b for b in backends)

    def test_metrics_composed_sat_increments(self) -> None:
        hp = HybridProver(
            tau_prover=_StubTau("sat"),
            z3_prover=IncrementalZ3Prover(),
            pattern_prover=PythonPatternProver(),
        )
        assert hp.metrics()["composed_sat"] == 0
        hp.prove((
            MaxPerCall(max_amount=Decimal("50")),
            SpendingCap(max_amount=Decimal("100"), scope="per_window",
                        window_seconds=60),
        ))
        assert hp.metrics()["composed_sat"] == 1


# ── (d) mixed policy WITH cross-interaction ──────────────────────────────────


class TestAcceptanceD_CrossFragmentClashDetected:
    """The distinguishing test: the v1 allowlist excludes a provider that
    the v2 per-provider SpendingCap caps. Neither fragment sees the
    clash alone; the hybrid projection surfaces it.
    """

    def test_allowlist_excludes_v2_capped_provider(self) -> None:
        policy = (
            ProviderAllowlist(providers=frozenset({"anthropic"})),
            SpendingCap(
                max_amount=Decimal("500"),
                scope="per_provider_per_window",
                window_seconds=3600,
                provider="openai",  # NOT in the v1 allowlist
            ),
        )
        hp = HybridProver(
            tau_prover=_StubTau("sat"),
            z3_prover=IncrementalZ3Prover(),
            pattern_prover=PythonPatternProver(),
        )
        r = hp.prove(policy)
        assert isinstance(r, Contradiction), r
        assert r.backend == "hybrid-projection"
        assert "openai" in r.reason
        assert "cross-fragment" in r.reason.lower()

    def test_allowlist_covers_v2_capped_provider_sat(self) -> None:
        """Same shape, but now the allowlist DOES include the capped
        provider — hybrid prover must NOT flag a contradiction."""
        policy = (
            ProviderAllowlist(providers=frozenset({"anthropic", "openai"})),
            SpendingCap(
                max_amount=Decimal("500"),
                scope="per_provider_per_window",
                window_seconds=3600,
                provider="openai",
            ),
        )
        hp = HybridProver(
            tau_prover=_StubTau("sat"),
            z3_prover=IncrementalZ3Prover(),
            pattern_prover=PythonPatternProver(),
        )
        r = hp.prove(policy)
        assert isinstance(r, ProofToken), r

    def test_no_allowlist_no_cross_check(self) -> None:
        """Without a ProviderAllowlist the projection has no reference
        set and cannot flag a clash; the v2 cap is admissible alone."""
        policy = (
            SpendingCap(
                max_amount=Decimal("500"),
                scope="per_provider_per_window",
                window_seconds=3600,
                provider="openai",
            ),
        )
        hp = HybridProver(
            tau_prover=_StubTau("sat"),
            z3_prover=IncrementalZ3Prover(),
            pattern_prover=PythonPatternProver(),
        )
        r = hp.prove(policy)
        assert isinstance(r, ProofToken), r


# ── (e) delta admission preserves hybrid path ────────────────────────────────


class TestAcceptanceE_DeltaAdmission:
    """prove_delta preserves the cross-fragment check and the short-circuit
    semantics on incremental calls."""

    def test_delta_add_v1_then_v2_clash_detected(self) -> None:
        hp = HybridProver(
            tau_prover=_StubTau("sat"),
            z3_prover=IncrementalZ3Prover(),
            pattern_prover=PythonPatternProver(),
        )
        # 1. Add a v1 allowlist (no v2 rules yet).
        pa = ProviderAllowlist(providers=frozenset({"anthropic"}))
        r1 = hp.prove_delta(
            added=(pa,),
            removed=(),
            full_current_set=(pa,),
        )
        assert isinstance(r1, ProofToken), r1

        # 2. Add a v2 cap referencing a forbidden provider.
        sc = SpendingCap(
            max_amount=Decimal("500"),
            scope="per_provider_per_window",
            window_seconds=3600,
            provider="openai",
        )
        r2 = hp.prove_delta(
            added=(sc,),
            removed=(),
            full_current_set=(pa, sc),
        )
        assert isinstance(r2, Contradiction), r2
        assert r2.backend == "hybrid-projection"

    def test_delta_add_v2_only_routed_to_z3(self) -> None:
        hp = HybridProver(
            tau_prover=_StubTau("sat"),
            z3_prover=IncrementalZ3Prover(),
            pattern_prover=PythonPatternProver(),
        )
        sc = SpendingCap(max_amount=Decimal("100"), scope="per_window",
                         window_seconds=60)
        r = hp.prove_delta(
            added=(sc,),
            removed=(),
            full_current_set=(sc,),
        )
        assert isinstance(r, ProofToken), r


# ── (f) short-circuit on v1 contradiction ────────────────────────────────────


class TestAcceptanceF_ShortCircuit:
    """A Contradiction surfaced by the Tau (v1) prover short-circuits the
    composition: z3 MUST NOT be invoked on the v2 subset."""

    def test_tau_unsat_does_not_invoke_z3(self) -> None:
        policy = (
            ProviderAllowlist(providers=frozenset({"anthropic"})),
            SpendingCap(max_amount=Decimal("100"), scope="per_window",
                        window_seconds=60),
        )
        z3 = IncrementalZ3Prover()
        hp = HybridProver(
            tau_prover=_StubTau("unsat"),
            z3_prover=z3,
            pattern_prover=PythonPatternProver(),
        )
        r = hp.prove(policy)
        assert isinstance(r, Contradiction)
        assert r.backend == "tau"
        # z3 solver must not have been touched: push_depth == 0 and
        # incremental_hits == 0 because no v2 delta was applied.
        assert z3.metrics()["push_depth"] == 0
        assert z3.metrics()["incremental_hits"] == 0
        assert hp.metrics()["tau_short_circuits"] == 1

    def test_pattern_unsat_short_circuits_everything(self) -> None:
        """Pattern prover finding a C3 (counterparty sanctioned+approved)
        stops even before Tau runs."""
        policy = (
            CounterpartyConstraint(
                approved_ids=frozenset({"acme"}),
                sanctioned_ids=frozenset({"badco"}),
            ),
            CounterpartyConstraint(
                approved_ids=frozenset({"badco"}),
                sanctioned_ids=frozenset({"acme"}),
            ),
        )
        tau_log: list = []
        hp = HybridProver(
            tau_prover=_StubTau("sat", call_log=tau_log),
            z3_prover=IncrementalZ3Prover(),
            pattern_prover=PythonPatternProver(),
        )
        r = hp.prove(policy)
        assert isinstance(r, Contradiction)
        assert r.backend == "python-pattern"
        # Tau must not have been consulted: pattern beat it to the UNSAT.
        assert len(tau_log) == 0
        assert hp.metrics()["pattern_short_circuits"] == 1


# ── daemon integration ───────────────────────────────────────────────────────


def _hybrid_daemon(tmp_path) -> CageDaemon:
    z3 = IncrementalZ3Prover(timeout_seconds=5)
    hp = HybridProver(
        tau_prover=_StubTau("sat"),
        z3_prover=z3,
        pattern_prover=PythonPatternProver(),
    )
    return CageDaemon(
        socket_path=str(tmp_path / "hybrid.sock"),
        prover=PythonPatternProver(),
        prover_mode="compat",
        z3_incremental_prover=z3,
        hybrid_prover=hp,
    )


class TestDaemonIntegration:
    def test_mixed_delta_clash_rejected_via_hybrid(self, tmp_path) -> None:
        d = _hybrid_daemon(tmp_path)
        # Admit the allowlist first.
        r1 = d.dispatch({
            "op": "add_invariant",
            "invariant": {
                "kind": "provider_allowlist",
                "providers": ["anthropic"],
            },
        })
        assert r1["verdict"] == "updated", r1
        # Now try to add a per-provider cap on a forbidden provider.
        r2 = d.dispatch({
            "op": "add_invariant",
            "invariant": {
                "kind": "spending_cap",
                "max_amount": "500",
                "scope": "per_provider_per_window",
                "window_seconds": 3600,
                "provider": "openai",
            },
        })
        assert r2["verdict"] == "contradiction", r2
        assert "hybrid" in r2["backend"]

    def test_hybrid_metrics_exposed_via_prover_metrics_op(self, tmp_path) -> None:
        d = _hybrid_daemon(tmp_path)
        resp = d.dispatch({"op": "prover_metrics"})
        assert resp["verdict"] == "ok"
        assert "hybrid_prover" in resp
        assert resp["hybrid_prover"]["backend"] == HYBRID_BACKEND

    def test_hybrid_path_admits_clean_mixed_policy(self, tmp_path) -> None:
        d = _hybrid_daemon(tmp_path)
        r1 = d.dispatch({
            "op": "add_invariant",
            "invariant": {"kind": "max_per_call", "max_amount": "50"},
        })
        assert r1["verdict"] == "updated", r1
        r2 = d.dispatch({
            "op": "add_invariant",
            "invariant": {
                "kind": "spending_cap",
                "max_amount": "1000",
                "scope": "per_window",
                "window_seconds": 86400,
            },
        })
        assert r2["verdict"] == "updated", r2
