"""Tests for shadow / advisory mode (v0.13.0).

Covers the full adoption arc:

1. ``enforce`` (default) — rejecting policy returns a reject envelope. Pre-
   v0.13 behaviour, unchanged.
2. ``shadow`` — rejecting policy returns a permit envelope tagged with
   ``shadow_would_reject=true``. Wire outcome is always permit.
3. ``advisory`` — identical wire behaviour to shadow, but bumps a separate
   Prometheus counter (distinguishes "trial deployment" from
   "drift-detection alongside enforce").
4. MAC binding — tampering with the ``mode`` field in a v2 envelope
   breaks signature verification.
5. Metrics — shadow + advisory counters tick only when we're in the
   matching mode.
6. History store — shadow-tagged rows are retrievable via the new
   ``shadow_only=True`` flag.
7. CLI end-to-end — ``shadow-summary`` hits a running daemon and
   renders per-rule / per-provider aggregates.
8. Env rehydration — the mode is picked up from ``TAU_CAGE_MODE`` on
   daemon restart.
9. Adoption test — operator runs a day in shadow, sees the summary,
   flips to enforce, the same rules fire as rejects.
"""
from __future__ import annotations

import io
import json
import os
import socket as _socket
import tempfile
import threading
import time
from decimal import Decimal
from typing import Iterator

import pytest

from adapter.cage_mode import CageMode, DEFAULT_MODE, parse_mode
from adapter.history_store import InMemoryHistoryStore
from adapter.invariants import MaxPerCall, ProviderAllowlist, SpendingCap
from adapter.metrics import CageMetrics, is_available as metrics_available
from adapter.payment_intent_matcher import PaymentIntent
from adapter.verdict_signer import (
    ShadowInfo,
    SignatureError,
    SignedEnvelope,
    Verdict,
    WIRE_VERSION_V2,
    sign,
    verify,
)
from adapter.x402_envelope import to_http_headers, to_http_response
from adapter.x402_client import UdsDaemonClient, _shadow_from_response, mediate
from daemon.server import CageDaemon


SECRET = b"shadow-mode-test-secret-at-least-16-bytes"


def _short_sock_path() -> str:
    fd, path = tempfile.mkstemp(prefix="x402-shadow-", suffix=".sock", dir="/tmp")
    os.close(fd)
    os.unlink(path)
    return path


def _make_intent(amount: str = "50", provider: str = "anthropic") -> PaymentIntent:
    return PaymentIntent(
        amount=Decimal(amount),
        currency="USDC",
        provider=provider,
        counterparty="vendor_x",
        rail="x402",
        timestamp_unix=1_700_000_000,
    )


def _send(path: str, request: dict) -> dict:
    s = _socket.socket(_socket.AF_UNIX, _socket.SOCK_STREAM)
    s.settimeout(3.0)
    s.connect(path)
    try:
        s.sendall((json.dumps(request) + "\n").encode("utf-8"))
        f = s.makefile("r")
        line = f.readline()
    finally:
        s.close()
    return json.loads(line)


@pytest.fixture
def daemon_factory() -> Iterator:
    """Factory: build a daemon in the requested mode and yield (daemon, sock_path).

    Each call creates a fresh daemon with a short socket path so macOS's
    104-char UDS limit is respected. The factory tracks every daemon so
    the teardown can cleanly shut them all down.
    """
    spawned: list[tuple[CageDaemon, str, threading.Thread]] = []

    def build(mode: CageMode | str = DEFAULT_MODE) -> tuple[CageDaemon, str]:
        path = _short_sock_path()
        d = CageDaemon(socket_path=path, cage_mode=mode)
        t = threading.Thread(target=d.serve_forever, daemon=True)
        t.start()
        for _ in range(100):
            if os.path.exists(path):
                break
            time.sleep(0.01)
        spawned.append((d, path, t))
        return d, path

    try:
        yield build
    finally:
        for d, _, t in spawned:
            try:
                d.shutdown()
            except Exception:
                pass
            t.join(timeout=1.0)


# ── CageMode parsing ─────────────────────────────────────────────────────────


class TestCageModeParse:
    def test_default_is_enforce(self) -> None:
        assert parse_mode(None) is CageMode.ENFORCE
        assert parse_mode("") is CageMode.ENFORCE
        assert DEFAULT_MODE is CageMode.ENFORCE

    def test_accepts_each_canonical_mode(self) -> None:
        assert parse_mode("enforce") is CageMode.ENFORCE
        assert parse_mode("shadow") is CageMode.SHADOW
        assert parse_mode("advisory") is CageMode.ADVISORY

    def test_case_insensitive_and_trims_whitespace(self) -> None:
        assert parse_mode("  SHADOW  ") is CageMode.SHADOW
        assert parse_mode("Advisory") is CageMode.ADVISORY

    def test_unknown_mode_raises(self) -> None:
        with pytest.raises(ValueError, match="unknown cage mode"):
            parse_mode("shaddow")
        with pytest.raises(ValueError, match="unknown cage mode"):
            parse_mode("off")


# ── Enforce mode (default) — pre-v0.13 behaviour unchanged ───────────────────


class TestEnforceMode:
    def test_rejecting_policy_returns_reject(self, daemon_factory) -> None:
        _, path = daemon_factory(CageMode.ENFORCE)
        _send(path, {
            "op": "declare_x402",
            "kind": "max_per_call",
            "max_amount": "10.00",
            "currency": "USDC",
        })
        resp = _send(path, {
            "op": "check_payment",
            "intent": {
                "amount": "50.00", "currency": "USDC",
                "provider": "anthropic", "counterparty": "v",
                "rail": "x402", "timestamp_unix": 1_700_000_000,
                "metadata": {}, "request_id": None,
            },
        })
        assert resp["verdict"] == "reject"
        assert resp["rule_id"] == "max_per_call"
        # mode is surfaced on every v0.13+ response even in enforce.
        assert resp["mode"] == "enforce"
        # No shadow tag on enforce rejects.
        assert resp.get("shadow_would_reject") is not True

    def test_permitting_policy_returns_permit(self, daemon_factory) -> None:
        _, path = daemon_factory(CageMode.ENFORCE)
        resp = _send(path, {
            "op": "check_payment",
            "intent": {
                "amount": "5.00", "currency": "USDC",
                "provider": "anthropic", "counterparty": "v",
                "rail": "x402", "timestamp_unix": 1_700_000_000,
                "metadata": {}, "request_id": None,
            },
        })
        assert resp["verdict"] == "permit"
        assert resp["mode"] == "enforce"


# ── Shadow mode — wire is always permit ──────────────────────────────────────


class TestShadowMode:
    def test_rejecting_policy_returns_tagged_permit(self, daemon_factory) -> None:
        _, path = daemon_factory(CageMode.SHADOW)
        _send(path, {
            "op": "declare_x402",
            "kind": "max_per_call",
            "max_amount": "10.00",
            "currency": "USDC",
        })
        resp = _send(path, {
            "op": "check_payment",
            "intent": {
                "amount": "50.00", "currency": "USDC",
                "provider": "anthropic", "counterparty": "v",
                "rail": "x402", "timestamp_unix": 1_700_000_000,
                "metadata": {}, "request_id": None,
            },
        })
        # Wire verdict is permit — shadow mode must never reject.
        assert resp["verdict"] == "permit"
        # Shadow tag is present + rule_id populated.
        assert resp["shadow_would_reject"] is True
        assert resp["shadow_rule_id"] == "max_per_call"
        assert resp["shadow_reason_text"]
        assert resp["mode"] == "shadow"

    def test_permitting_policy_identical_to_enforce(self, daemon_factory) -> None:
        _, path = daemon_factory(CageMode.SHADOW)
        resp = _send(path, {
            "op": "check_payment",
            "intent": {
                "amount": "5.00", "currency": "USDC",
                "provider": "anthropic", "counterparty": "v",
                "rail": "x402", "timestamp_unix": 1_700_000_000,
                "metadata": {}, "request_id": None,
            },
        })
        assert resp["verdict"] == "permit"
        # When the full check also permitted, no shadow tag.
        assert resp.get("shadow_would_reject") is not True
        assert resp["mode"] == "shadow"


# ── Advisory mode — same wire as shadow, separate metric surface ────────────


class TestAdvisoryMode:
    def test_rejecting_policy_returns_permit_like_shadow(self, daemon_factory) -> None:
        _, path = daemon_factory(CageMode.ADVISORY)
        _send(path, {
            "op": "declare_x402",
            "kind": "max_per_call",
            "max_amount": "10.00",
            "currency": "USDC",
        })
        resp = _send(path, {
            "op": "check_payment",
            "intent": {
                "amount": "50.00", "currency": "USDC",
                "provider": "anthropic", "counterparty": "v",
                "rail": "x402", "timestamp_unix": 1_700_000_000,
                "metadata": {}, "request_id": None,
            },
        })
        assert resp["verdict"] == "permit"
        assert resp["shadow_would_reject"] is True
        assert resp["shadow_rule_id"] == "max_per_call"
        assert resp["mode"] == "advisory"


# ── v2 envelope: mode is MAC-bound ───────────────────────────────────────────


class TestModeIsMacBound:
    def test_signing_with_shadow_info_promotes_to_v2(self) -> None:
        intent = _make_intent()
        verdict = Verdict(outcome="permit", ttl_seconds=30)
        env = sign(
            verdict, intent, SECRET,
            shadow=ShadowInfo(mode="shadow"),
        )
        assert env.version == WIRE_VERSION_V2
        assert env.mode == "shadow"
        # No would-reject on a pure permit.
        assert env.shadow_would_reject is False
        # Verify should succeed end-to-end.
        verify(env, intent, SECRET)

    def test_shadow_reject_envelope_round_trips(self) -> None:
        intent = _make_intent()
        verdict = Verdict(outcome="permit", ttl_seconds=30)
        env = sign(
            verdict, intent, SECRET,
            shadow=ShadowInfo(
                mode="shadow",
                would_reject=True,
                rule_id="max_per_call",
                reason_text="50 > 10",
            ),
        )
        wire = env.to_json()
        reconstructed = SignedEnvelope.from_json(wire)
        assert reconstructed.mode == "shadow"
        assert reconstructed.shadow_would_reject is True
        assert reconstructed.shadow_rule_id == "max_per_call"
        verify(reconstructed, intent, SECRET)

    def test_tampering_mode_field_breaks_verify(self) -> None:
        intent = _make_intent()
        verdict = Verdict(outcome="permit", ttl_seconds=30)
        env = sign(
            verdict, intent, SECRET,
            shadow=ShadowInfo(mode="shadow"),
        )
        # An attacker flips the mode to "enforce" to make it look like
        # the system authoritatively permitted this transfer. The MAC
        # catches it.
        tampered = SignedEnvelope(
            **{**env.__dict__, "mode": "enforce"},
        )
        with pytest.raises(SignatureError):
            verify(tampered, intent, SECRET)

    def test_tampering_shadow_would_reject_breaks_verify(self) -> None:
        intent = _make_intent()
        verdict = Verdict(outcome="permit", ttl_seconds=30)
        env = sign(
            verdict, intent, SECRET,
            shadow=ShadowInfo(
                mode="shadow",
                would_reject=True,
                rule_id="max_per_call",
                reason_text="over cap",
            ),
        )
        tampered = SignedEnvelope(
            **{**env.__dict__, "shadow_would_reject": False},
        )
        with pytest.raises(SignatureError):
            verify(tampered, intent, SECRET)


# ── HTTP headers ─────────────────────────────────────────────────────────────


class TestHttpHeaders:
    def test_mode_header_on_v2_envelope(self) -> None:
        intent = _make_intent()
        verdict = Verdict(outcome="permit", ttl_seconds=30)
        env = sign(
            verdict, intent, SECRET,
            shadow=ShadowInfo(mode="shadow"),
        )
        headers = to_http_headers(env)
        assert headers["X-Policy-Mode"] == "shadow"
        assert headers["X-Policy-Version"] == "v2"

    def test_shadow_would_reject_header_on_reject(self) -> None:
        intent = _make_intent()
        verdict = Verdict(outcome="permit", ttl_seconds=30)
        env = sign(
            verdict, intent, SECRET,
            shadow=ShadowInfo(
                mode="shadow",
                would_reject=True,
                rule_id="max_per_call",
            ),
        )
        headers = to_http_headers(env)
        assert headers["X-Policy-Shadow-Would-Reject"] == "true"
        assert headers["X-Policy-Shadow-Rule-Id"] == "max_per_call"

    def test_mediate_emits_200_in_shadow_mode_on_reject(self, daemon_factory) -> None:
        _, path = daemon_factory(CageMode.SHADOW)
        _send(path, {
            "op": "declare_x402",
            "kind": "max_per_call",
            "max_amount": "10.00",
            "currency": "USDC",
        })
        # Use a real UdsDaemonClient through mediate() so we cover the
        # wire end-to-end, including ShadowInfo rehydration.
        from adapter.x402_client import UdsDaemonClient
        client = UdsDaemonClient(socket_path=path)
        headers = {"Content-Type": "application/json"}
        body = json.dumps({
            "amount": "50.00",
            "currency": "USDC",
            "provider": "anthropic",
            "counterparty": "vendor_x",
            "timestamp": 1_700_000_000,
        }).encode("utf-8")
        status, resp_headers, _ = mediate(
            headers, body, SECRET, daemon=client,
        )
        # Shadow mode never returns 403; always 200.
        assert status == 200
        assert resp_headers["X-Policy-Verdict"] == "permit"
        assert resp_headers["X-Policy-Mode"] == "shadow"
        assert resp_headers["X-Policy-Shadow-Would-Reject"] == "true"
        assert resp_headers["X-Policy-Shadow-Rule-Id"] == "max_per_call"

    def test_enforce_mode_still_returns_403(self, daemon_factory) -> None:
        _, path = daemon_factory(CageMode.ENFORCE)
        _send(path, {
            "op": "declare_x402",
            "kind": "max_per_call",
            "max_amount": "10.00",
            "currency": "USDC",
        })
        from adapter.x402_client import UdsDaemonClient
        client = UdsDaemonClient(socket_path=path)
        headers = {"Content-Type": "application/json"}
        body = json.dumps({
            "amount": "50.00",
            "currency": "USDC",
            "provider": "anthropic",
            "counterparty": "vendor_x",
            "timestamp": 1_700_000_000,
        }).encode("utf-8")
        status, _, _ = mediate(headers, body, SECRET, daemon=client)
        assert status == 403


# ── Metrics ──────────────────────────────────────────────────────────────────


@pytest.mark.skipif(not metrics_available(), reason="prometheus_client not installed")
class TestMetrics:
    def test_shadow_counter_bumps_in_shadow_mode(self, daemon_factory) -> None:
        metrics = CageMetrics()
        # Build a daemon with the injected metrics so we can assert on counters.
        path = _short_sock_path()
        d = CageDaemon(
            socket_path=path,
            cage_mode=CageMode.SHADOW,
            metrics=metrics,
        )
        t = threading.Thread(target=d.serve_forever, daemon=True)
        t.start()
        for _ in range(100):
            if os.path.exists(path):
                break
            time.sleep(0.01)
        try:
            _send(path, {
                "op": "declare_x402",
                "kind": "max_per_call",
                "max_amount": "10.00",
                "currency": "USDC",
            })
            _send(path, {
                "op": "check_payment",
                "intent": {
                    "amount": "50.00", "currency": "USDC",
                    "provider": "anthropic", "counterparty": "v",
                    "rail": "x402", "timestamp_unix": 1_700_000_000,
                    "metadata": {}, "request_id": None,
                },
            })
            snap = metrics.snapshot()
            assert snap["shadow_would_reject_total"] >= 1.0
            # Advisory counter untouched in shadow mode.
            assert snap["advisory_would_reject_total"] == 0.0
            # Wire verdict is permit so the permit counter bumped.
            assert snap["admissions_total"]["permit"] >= 1.0
            # Reject counter does NOT bump in shadow — we turned a would-
            # be reject into a wire permit.
            assert snap["admissions_total"]["reject"] == 0.0
        finally:
            d.shutdown()
            t.join(timeout=1.0)

    def test_advisory_counter_bumps_in_advisory_mode(self, daemon_factory) -> None:
        metrics = CageMetrics()
        path = _short_sock_path()
        d = CageDaemon(
            socket_path=path,
            cage_mode=CageMode.ADVISORY,
            metrics=metrics,
        )
        t = threading.Thread(target=d.serve_forever, daemon=True)
        t.start()
        for _ in range(100):
            if os.path.exists(path):
                break
            time.sleep(0.01)
        try:
            _send(path, {
                "op": "declare_x402",
                "kind": "max_per_call",
                "max_amount": "10.00",
                "currency": "USDC",
            })
            _send(path, {
                "op": "check_payment",
                "intent": {
                    "amount": "50.00", "currency": "USDC",
                    "provider": "anthropic", "counterparty": "v",
                    "rail": "x402", "timestamp_unix": 1_700_000_000,
                    "metadata": {}, "request_id": None,
                },
            })
            snap = metrics.snapshot()
            assert snap["advisory_would_reject_total"] >= 1.0
            assert snap["shadow_would_reject_total"] == 0.0
        finally:
            d.shutdown()
            t.join(timeout=1.0)

    def test_enforce_does_not_bump_shadow_or_advisory(self, daemon_factory) -> None:
        metrics = CageMetrics()
        path = _short_sock_path()
        d = CageDaemon(
            socket_path=path,
            cage_mode=CageMode.ENFORCE,
            metrics=metrics,
        )
        t = threading.Thread(target=d.serve_forever, daemon=True)
        t.start()
        for _ in range(100):
            if os.path.exists(path):
                break
            time.sleep(0.01)
        try:
            _send(path, {
                "op": "declare_x402",
                "kind": "max_per_call",
                "max_amount": "10.00",
                "currency": "USDC",
            })
            _send(path, {
                "op": "check_payment",
                "intent": {
                    "amount": "50.00", "currency": "USDC",
                    "provider": "anthropic", "counterparty": "v",
                    "rail": "x402", "timestamp_unix": 1_700_000_000,
                    "metadata": {}, "request_id": None,
                },
            })
            snap = metrics.snapshot()
            assert snap["shadow_would_reject_total"] == 0.0
            assert snap["advisory_would_reject_total"] == 0.0
            # Enforce does bump the reject counter.
            assert snap["admissions_total"]["reject"] >= 1.0
        finally:
            d.shutdown()
            t.join(timeout=1.0)


# ── History store: shadow_only filter ────────────────────────────────────────


class TestHistoryStoreShadowOnly:
    def test_shadow_only_filters_rows(self) -> None:
        store = InMemoryHistoryStore(cap=100)
        # Regular permit verdict row — not shadow.
        store.append(
            {"verdict": "permit", "rule_id": None},
            kind="verdict",
        )
        # Shadow-tagged verdict row.
        store.append(
            {
                "verdict": "permit",
                "shadow_rejected": True,
                "shadow_rule_id": "max_per_call",
                "shadow_reason_text": "50 > 10",
            },
            kind="verdict",
        )
        # A PaymentIntent on the permit stream (no shadow tag possible).
        store.append(_make_intent(), kind="permit")

        all_verdicts = store.recent(kind="verdict", limit=10)
        assert len(all_verdicts) == 2

        shadow = store.recent(kind="verdict", limit=10, shadow_only=True)
        assert len(shadow) == 1
        assert shadow[0]["shadow_rule_id"] == "max_per_call"

    def test_shadow_only_respects_limit(self) -> None:
        store = InMemoryHistoryStore(cap=100)
        for i in range(5):
            store.append(
                {
                    "verdict": "permit",
                    "shadow_rejected": True,
                    "shadow_rule_id": f"rule_{i}",
                },
                kind="verdict",
            )
        got = store.recent(kind="verdict", limit=3, shadow_only=True)
        assert len(got) == 3
        # Newest-first ordering preserved.
        assert got[0]["shadow_rule_id"] == "rule_4"


# ── Daemon op: shadow_summary ────────────────────────────────────────────────


class TestShadowSummaryOp:
    def test_summary_aggregates_shadow_rejects(self, daemon_factory) -> None:
        _, path = daemon_factory(CageMode.SHADOW)
        _send(path, {
            "op": "declare_x402",
            "kind": "max_per_call",
            "max_amount": "10.00",
            "currency": "USDC",
        })
        # Send three would-reject intents, mixed providers.
        for provider in ("anthropic", "openai", "anthropic"):
            _send(path, {
                "op": "check_payment",
                "intent": {
                    "amount": "50.00", "currency": "USDC",
                    "provider": provider, "counterparty": "v",
                    "rail": "x402", "timestamp_unix": 1_700_000_000,
                    "metadata": {}, "request_id": None,
                },
            })
        resp = _send(path, {"op": "shadow_summary"})
        assert resp["verdict"] == "ok"
        assert resp["mode"] == "shadow"
        assert resp["total_shadow_rejected"] == 3
        assert resp["by_rule"][0]["rule_id"] == "max_per_call"
        assert resp["by_rule"][0]["count"] == 3
        providers = {e["provider"]: e["count"] for e in resp["by_provider"]}
        assert providers["anthropic"] == 2
        assert providers["openai"] == 1
        # Aggregate: 3 * 50 USDC = 150.
        assert Decimal(resp["aggregate_would_block_value"]["USDC"]) == Decimal("150")

    def test_summary_on_empty_history(self, daemon_factory) -> None:
        _, path = daemon_factory(CageMode.SHADOW)
        resp = _send(path, {"op": "shadow_summary"})
        assert resp["verdict"] == "ok"
        assert resp["total_shadow_rejected"] == 0
        assert resp["by_rule"] == []


# ── CLI: shadow-summary ──────────────────────────────────────────────────────


class TestShadowSummaryCLI:
    def test_cli_renders_text_report(self, daemon_factory, capsys) -> None:
        _, path = daemon_factory(CageMode.SHADOW)
        _send(path, {
            "op": "declare_x402",
            "kind": "max_per_call",
            "max_amount": "10.00",
            "currency": "USDC",
        })
        _send(path, {
            "op": "check_payment",
            "intent": {
                "amount": "50.00", "currency": "USDC",
                "provider": "anthropic", "counterparty": "v",
                "rail": "x402", "timestamp_unix": 1_700_000_000,
                "metadata": {}, "request_id": None,
            },
        })
        from daemon.cli import _build_parser, main
        parser = _build_parser()
        args = parser.parse_args(
            ["shadow-summary", "--socket", path, "--format", "text"],
        )
        # Run _cmd_shadow_summary manually so we can use capsys.
        from daemon.cli import _cmd_shadow_summary
        rc = _cmd_shadow_summary(args)
        captured = capsys.readouterr()
        assert rc == 0
        assert "Shadow summary" in captured.out
        assert "current mode:" in captured.out
        assert "shadow" in captured.out
        assert "max_per_call" in captured.out

    def test_cli_json_format(self, daemon_factory, capsys) -> None:
        _, path = daemon_factory(CageMode.SHADOW)
        from daemon.cli import _build_parser, _cmd_shadow_summary
        parser = _build_parser()
        args = parser.parse_args(
            ["shadow-summary", "--socket", path, "--format", "json"],
        )
        rc = _cmd_shadow_summary(args)
        captured = capsys.readouterr()
        assert rc == 0
        parsed = json.loads(captured.out)
        assert parsed["verdict"] == "ok"
        assert parsed["mode"] == "shadow"

    def test_cli_bad_window_exits_2(self, daemon_factory, capsys) -> None:
        _, path = daemon_factory(CageMode.SHADOW)
        from daemon.cli import _build_parser, _cmd_shadow_summary
        parser = _build_parser()
        args = parser.parse_args(
            ["shadow-summary", "--socket", path, "--window", "not-a-window"],
        )
        rc = _cmd_shadow_summary(args)
        assert rc == 2


# ── Env rehydration ──────────────────────────────────────────────────────────


class TestEnvRehydration:
    def test_env_var_picks_up_shadow_mode(self, monkeypatch) -> None:
        monkeypatch.setenv("TAU_CAGE_MODE", "shadow")
        # Simulate the CLI path without actually running a daemon. We
        # exercise parse_mode + the resolution pattern from _cmd_run
        # directly so the test is fast and doesn't bind a socket.
        raw = os.environ.get("TAU_CAGE_MODE")
        assert parse_mode(raw) is CageMode.SHADOW

    def test_env_var_default_is_enforce(self, monkeypatch) -> None:
        monkeypatch.delenv("TAU_CAGE_MODE", raising=False)
        raw = os.environ.get("TAU_CAGE_MODE")
        assert parse_mode(raw) is CageMode.ENFORCE

    def test_cli_flag_overrides_env_var(self, monkeypatch) -> None:
        """CLI --mode wins over TAU_CAGE_MODE env var.

        Mirrors the precedence logic in ``_cmd_run``: ``args.mode`` is
        consulted before the env var, so operators can override the
        deployment default for a one-off invocation.
        """
        monkeypatch.setenv("TAU_CAGE_MODE", "shadow")
        # Emulate the precedence: CLI flag first, then env.
        cli_value = "advisory"
        resolved = cli_value or os.environ.get("TAU_CAGE_MODE")
        assert parse_mode(resolved) is CageMode.ADVISORY


# ── End-to-end adoption story ────────────────────────────────────────────────


class TestAdoptionStory:
    def test_run_day_in_shadow_then_flip_to_enforce(self, daemon_factory) -> None:
        """An operator runs in shadow, reads the summary, flips to enforce.

        This is the load-bearing adoption test: the same rules that
        fired in shadow must fire in enforce after the flip. The
        summary report is what bridges the two — the operator reads
        which rules caught traffic, gains confidence, and flips.
        """
        # Day 1: shadow mode. Declare a rule. Fire traffic that should
        # have been rejected.
        _, shadow_path = daemon_factory(CageMode.SHADOW)
        _send(shadow_path, {
            "op": "declare_x402",
            "kind": "max_per_call",
            "max_amount": "10.00",
            "currency": "USDC",
        })
        shadow_resp = _send(shadow_path, {
            "op": "check_payment",
            "intent": {
                "amount": "50.00", "currency": "USDC",
                "provider": "anthropic", "counterparty": "v",
                "rail": "x402", "timestamp_unix": 1_700_000_000,
                "metadata": {}, "request_id": None,
            },
        })
        # In shadow, this came through as a tagged permit.
        assert shadow_resp["verdict"] == "permit"
        assert shadow_resp["shadow_would_reject"] is True
        assert shadow_resp["shadow_rule_id"] == "max_per_call"

        # Operator reads the summary — it tells them what would have been blocked.
        summary = _send(shadow_path, {"op": "shadow_summary"})
        assert summary["total_shadow_rejected"] == 1
        assert summary["by_rule"][0]["rule_id"] == "max_per_call"

        # Day 2: operator flips the daemon to enforce with the same policy.
        _, enforce_path = daemon_factory(CageMode.ENFORCE)
        _send(enforce_path, {
            "op": "declare_x402",
            "kind": "max_per_call",
            "max_amount": "10.00",
            "currency": "USDC",
        })
        enforce_resp = _send(enforce_path, {
            "op": "check_payment",
            "intent": {
                "amount": "50.00", "currency": "USDC",
                "provider": "anthropic", "counterparty": "v",
                "rail": "x402", "timestamp_unix": 1_700_000_000,
                "metadata": {}, "request_id": None,
            },
        })
        # Same intent that was shadow-rejected now hard-rejects on the
        # wire. This is the decisive cross-run assertion: shadow was a
        # faithful preview of enforce.
        assert enforce_resp["verdict"] == "reject"
        assert enforce_resp["rule_id"] == "max_per_call"


# ── ShadowInfo rehydration from response ─────────────────────────────────────


class TestShadowInfoRehydration:
    def test_missing_mode_yields_none(self) -> None:
        response: dict = {"verdict": "permit", "rule_id": None}
        assert _shadow_from_response(response) is None

    def test_pure_permit_shadow_info(self) -> None:
        response = {"verdict": "permit", "mode": "shadow"}
        info = _shadow_from_response(response)
        assert info is not None
        assert info.mode == "shadow"
        assert info.would_reject is False

    def test_would_reject_rebuilds_full_shadow_info(self) -> None:
        response = {
            "verdict": "permit",
            "mode": "advisory",
            "shadow_would_reject": True,
            "shadow_rule_id": "max_per_call",
            "shadow_reason_text": "50 > 10",
        }
        info = _shadow_from_response(response)
        assert info is not None
        assert info.mode == "advisory"
        assert info.would_reject is True
        assert info.rule_id == "max_per_call"
        assert info.reason_text == "50 > 10"
