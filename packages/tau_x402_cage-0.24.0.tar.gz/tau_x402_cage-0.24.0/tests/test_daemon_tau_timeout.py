"""Tests that CageDaemon threads tau_timeout_ms through to TauConsistencyProver.

Patch 6 contract: the daemon accepts `tau_timeout_ms` (int, milliseconds,
default 10000) and passes `timeout_seconds=tau_timeout_ms/1000.0` when it
auto-constructs a TauConsistencyProver. When the caller supplies their own
tau_prover, we do NOT override its timeout -- the caller owns it.
"""
from __future__ import annotations

from pathlib import Path

import pytest

from adapter.prover import PythonPatternProver, TauConsistencyProver
from daemon.server import CageDaemon


def _daemon(tmp_path: Path, **kwargs) -> CageDaemon:
    sock = str(tmp_path / "tto.sock")
    return CageDaemon(socket_path=sock, prover=PythonPatternProver(), **kwargs)


class TestTauTimeoutWiring:
    def test_default_tau_timeout_is_10_seconds(self, tmp_path: Path) -> None:
        d = _daemon(tmp_path, prover_mode="verified")
        assert isinstance(d._tau_prover, TauConsistencyProver)
        assert d._tau_prover.timeout_seconds == pytest.approx(10.0)

    def test_explicit_timeout_converts_ms_to_seconds(self, tmp_path: Path) -> None:
        d = _daemon(tmp_path, prover_mode="strict", tau_timeout_ms=2500)
        assert isinstance(d._tau_prover, TauConsistencyProver)
        assert d._tau_prover.timeout_seconds == pytest.approx(2.5)

    def test_one_ms_rounds_down_to_sub_second(self, tmp_path: Path) -> None:
        d = _daemon(tmp_path, prover_mode="verified", tau_timeout_ms=1)
        assert isinstance(d._tau_prover, TauConsistencyProver)
        assert d._tau_prover.timeout_seconds == pytest.approx(0.001)

    def test_compat_mode_never_constructs_tau_prover(self, tmp_path: Path) -> None:
        d = _daemon(tmp_path, prover_mode="compat", tau_timeout_ms=500)
        # tau_timeout_ms is ignored at construction time in compat mode
        assert d._tau_prover is None
        # But the daemon still stores the value for introspection / future resume
        assert d._tau_timeout_ms == 500

    def test_caller_supplied_tau_prover_is_not_rewrapped(self, tmp_path: Path) -> None:
        """If the caller injects their own prover (tests, mocks), leave it alone."""
        injected = TauConsistencyProver(timeout_seconds=99.0)
        d = _daemon(
            tmp_path,
            prover_mode="strict",
            tau_prover=injected,
            tau_timeout_ms=100,   # should be ignored for the caller-supplied prover
        )
        assert d._tau_prover is injected
        assert injected.timeout_seconds == 99.0

    def test_zero_timeout_rejected(self, tmp_path: Path) -> None:
        with pytest.raises(ValueError, match="tau_timeout_ms"):
            _daemon(tmp_path, prover_mode="verified", tau_timeout_ms=0)

    def test_negative_timeout_rejected(self, tmp_path: Path) -> None:
        with pytest.raises(ValueError, match="tau_timeout_ms"):
            _daemon(tmp_path, prover_mode="verified", tau_timeout_ms=-100)

    def test_non_int_timeout_rejected(self, tmp_path: Path) -> None:
        with pytest.raises(ValueError, match="tau_timeout_ms"):
            _daemon(tmp_path, prover_mode="verified", tau_timeout_ms=1.5)  # type: ignore[arg-type]
