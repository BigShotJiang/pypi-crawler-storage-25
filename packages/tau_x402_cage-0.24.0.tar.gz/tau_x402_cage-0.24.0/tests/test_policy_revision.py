"""Tests for adapter/policy_revision.py and daemon persistence wiring.

Coverage plan:
  * round-trip: build a revision, persist, reload, verify identical state
  * chain integrity: each revision's predecessor_revision_id matches the prior
  * strict-mode inconclusive does NOT replace active policy (regression guard)
  * invariant rehydration preserves class + fields for all 8 invariant types
  * daemon reload of a persisted log restores _x402_registry to the last
    admitted invariant set
"""

from __future__ import annotations

import json
import os
import socket
import tempfile
import threading
import time
from decimal import Decimal
from pathlib import Path
from typing import Iterator

import pytest

from adapter.invariants import (
    CounterpartyConstraint,
    JurisdictionRule,
    MaxPerCall,
    MutualExclusion,
    ProviderAllowlist,
    RetryRateLimit,
    RollingWindowCap,
    SpendingCap,
)
from adapter.policy_revision import (
    INVARIANT_CONSTRUCTORS,
    INVARIANT_SERIALIZERS,
    PolicyRevision,
    RevisionLog,
    RevisionLogError,
)
from adapter.prover import ProofToken
from daemon.server import CageDaemon


# ── helpers ──────────────────────────────────────────────────────────────────


def _make_token(
    config_hash: str = "abc123",
    nonce: str = "nonce0",
    predecessor: str | None = None,
) -> ProofToken:
    return ProofToken(
        config_hash=config_hash,
        issued_at_unix=1_713_000_000,
        backend="python-pattern",
        proof_strength="pattern",
        nonce=nonce,
        predecessor_hash=predecessor,
        prover_mode="compat",
        fragment_version=None,
        compile_hash=None,
        tau_backend_version=None,
    )


def _send(path: str, req: dict) -> dict:
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.settimeout(2.0)
    s.connect(path)
    try:
        s.sendall((json.dumps(req) + "\n").encode("utf-8"))
        f = s.makefile("r")
        return json.loads(f.readline())
    finally:
        s.close()


# ── PolicyRevision round-trip ────────────────────────────────────────────────


class TestPolicyRevisionRoundTrip:
    def test_to_dict_from_dict_round_trip(self) -> None:
        rev = PolicyRevision(
            revision_id="hash:nonce",
            invariants=(MaxPerCall(max_amount=Decimal("50")),),
            proof_backend="python-pattern",
            proof_strength="pattern",
            prover_mode="compat",
            compile_hash=None,
            fragment_version=None,
            tau_backend_version=None,
            admitted_at_unix=1_713_000_000,
            predecessor_revision_id=None,
        )
        d = rev.to_dict()
        # round-trip through JSON to emulate on-disk encoding
        rebuilt = PolicyRevision.from_dict(json.loads(json.dumps(d)))
        assert rebuilt == rev

    def test_from_proof_token_carries_provenance(self) -> None:
        token = ProofToken(
            config_hash="cfg_abc",
            issued_at_unix=1_713_111_111,
            backend="tau",
            proof_strength="complete",
            nonce="deadbeef",
            predecessor_hash=None,
            prover_mode="strict",
            fragment_version="v1",
            compile_hash="c" * 64,
            tau_backend_version="v8b155d36",
        )
        rev = PolicyRevision.from_proof_token(
            token=token,
            invariants=(MaxPerCall(max_amount=Decimal("10")),),
            predecessor_revision_id=None,
        )
        assert rev.revision_id == "cfg_abc:deadbeef"
        assert rev.proof_backend == "tau"
        assert rev.proof_strength == "complete"
        assert rev.prover_mode == "strict"
        assert rev.compile_hash == "c" * 64
        assert rev.fragment_version == "v1"
        assert rev.tau_backend_version == "v8b155d36"
        assert rev.admitted_at_unix == 1_713_111_111

    def test_from_dict_rejects_missing_fields(self) -> None:
        with pytest.raises(RevisionLogError, match="missing fields"):
            PolicyRevision.from_dict({"revision_id": "x"})


# ── invariant (de)serialization for all 8 types ──────────────────────────────


class TestInvariantRehydration:
    """Every registered invariant type round-trips class + field identity."""

    @pytest.mark.parametrize("inv", [
        SpendingCap(max_amount=Decimal("100"), scope="per_tx"),
        SpendingCap(max_amount=Decimal("500"), scope="per_window", window_seconds=3600),
        SpendingCap(
            max_amount=Decimal("50"),
            scope="per_provider_per_window",
            window_seconds=60,
            provider="anthropic",
        ),
        MaxPerCall(max_amount=Decimal("25")),
        MaxPerCall(max_amount=Decimal("1"), currency="USDT"),
        ProviderAllowlist(providers=frozenset({"anthropic", "openai"})),
        RetryRateLimit(min_gap_seconds=30),
        RollingWindowCap(max_count=5, window_seconds=60, group_by="provider"),
        RollingWindowCap(max_count=10, window_seconds=3600, group_by="global"),
        CounterpartyConstraint(
            approved_ids=frozenset({"vendor_a"}),
            sanctioned_ids=frozenset({"bad_vendor"}),
        ),
        MutualExclusion(
            group_a=frozenset({"a1", "a2"}),
            group_b=frozenset({"b1"}),
        ),
        JurisdictionRule(jurisdiction="EU"),
        JurisdictionRule(
            jurisdiction="US",
            additional_invariants=(MaxPerCall(max_amount=Decimal("1")),),
        ),
    ])
    def test_invariant_round_trip(self, inv) -> None:
        rev = PolicyRevision(
            revision_id="r",
            invariants=(inv,),
            proof_backend="python-pattern",
            proof_strength="pattern",
            prover_mode="compat",
            compile_hash=None,
            fragment_version=None,
            tau_backend_version=None,
            admitted_at_unix=1,
            predecessor_revision_id=None,
        )
        rebuilt = PolicyRevision.from_dict(rev.to_dict())
        # Class identity + field equality via frozen-dataclass __eq__
        assert type(rebuilt.invariants[0]) is type(inv)
        assert rebuilt.invariants[0] == inv

    def test_constructor_registry_covers_all_eight(self) -> None:
        """Guards against a new invariant type being added without a
        corresponding (de)serialization entry."""
        expected_core = {
            "SpendingCap", "MaxPerCall", "ProviderAllowlist", "RetryRateLimit",
            "RollingWindowCap", "CounterpartyConstraint", "MutualExclusion",
            "JurisdictionRule",
        }
        # v0.13.0 adds InstabilityGuard as a self-referential invariant.
        # Register by import so this assertion picks it up.
        import adapter.self_ref_policy  # noqa: F401
        expected = expected_core | {"InstabilityGuard"}
        assert set(INVARIANT_SERIALIZERS) == expected
        assert set(INVARIANT_CONSTRUCTORS) == expected


# ── RevisionLog persistence ──────────────────────────────────────────────────


class TestRevisionLogPersistence:
    def test_empty_log_load_from_missing_file(self, tmp_path) -> None:
        p = tmp_path / "rev.jsonl"
        log = RevisionLog.load(p)
        assert len(log) == 0
        assert log.latest is None

    def test_append_persists_to_disk(self, tmp_path) -> None:
        p = tmp_path / "rev.jsonl"
        log = RevisionLog(path=p)
        rev = PolicyRevision.from_proof_token(
            _make_token(),
            invariants=(MaxPerCall(max_amount=Decimal("5")),),
            predecessor_revision_id=None,
        )
        log.append(rev)
        assert p.exists()
        lines = p.read_text(encoding="utf-8").splitlines()
        assert len(lines) == 1
        loaded = RevisionLog.load(p)
        assert len(loaded) == 1
        assert loaded.revisions[0] == rev

    def test_chain_integrity_across_restart(self, tmp_path) -> None:
        p = tmp_path / "rev.jsonl"
        log = RevisionLog(path=p)
        r1 = PolicyRevision.from_proof_token(
            _make_token(config_hash="h1", nonce="n1"),
            invariants=(MaxPerCall(max_amount=Decimal("5")),),
            predecessor_revision_id=None,
        )
        log.append(r1)
        r2 = PolicyRevision.from_proof_token(
            _make_token(config_hash="h2", nonce="n2", predecessor="h1"),
            invariants=(
                MaxPerCall(max_amount=Decimal("5")),
                RetryRateLimit(min_gap_seconds=10),
            ),
            predecessor_revision_id=r1.revision_id,
        )
        log.append(r2)
        reloaded = RevisionLog.load(p)
        assert len(reloaded) == 2
        assert reloaded.revisions[0].revision_id == r1.revision_id
        assert reloaded.revisions[1].predecessor_revision_id == r1.revision_id

    def test_corrupted_line_raises(self, tmp_path) -> None:
        p = tmp_path / "rev.jsonl"
        p.write_text("{not valid json\n", encoding="utf-8")
        with pytest.raises(RevisionLogError, match="malformed JSON"):
            RevisionLog.load(p)

    def test_persist_all_overwrites(self, tmp_path) -> None:
        p = tmp_path / "rev.jsonl"
        log = RevisionLog()
        rev = PolicyRevision.from_proof_token(
            _make_token(),
            invariants=(MaxPerCall(max_amount=Decimal("5")),),
            predecessor_revision_id=None,
        )
        log._revisions.append(rev)
        log.persist_all(p)
        loaded = RevisionLog.load(p)
        assert len(loaded) == 1


# ── Daemon ↔ RevisionLog integration ─────────────────────────────────────────


@pytest.fixture
def persistent_daemon(tmp_path) -> Iterator[tuple[str, Path]]:
    """CageDaemon that persists its revisions to `tmp_path/revisions.jsonl`."""
    fd, sock = tempfile.mkstemp(prefix="rev-persist-", suffix=".sock", dir="/tmp")
    os.close(fd)
    os.unlink(sock)
    log_path = tmp_path / "revisions.jsonl"
    d = CageDaemon(socket_path=sock, revision_log_path=log_path)
    t = threading.Thread(target=d.serve_forever, daemon=True)
    t.start()
    for _ in range(50):
        if os.path.exists(sock):
            break
        time.sleep(0.01)
    try:
        yield sock, log_path
    finally:
        d.shutdown()
        t.join(timeout=1.0)


class TestDaemonPersistence:
    def test_declare_writes_policy_revision_to_disk(
        self, persistent_daemon
    ) -> None:
        sock, log_path = persistent_daemon
        r = _send(sock, {
            "op": "declare_x402", "kind": "max_per_call", "max_amount": "50",
        })
        assert r["verdict"] == "updated"
        assert log_path.exists()
        lines = log_path.read_text().splitlines()
        assert len(lines) == 1
        first = json.loads(lines[0])
        # revision_id = f"{config_hash}:{nonce}" derived from the ProofToken
        assert first["revision_id"].startswith(r["proof_token"]["config_hash"])
        assert first["revision_id"].endswith(r["proof_token"]["nonce"])
        assert first["invariants"][0]["class_name"] == "MaxPerCall"

    def test_active_revision_op_returns_latest(self, persistent_daemon) -> None:
        sock, _ = persistent_daemon
        resp = _send(sock, {"op": "active_revision"})
        assert resp["revision"] is None
        _send(sock, {
            "op": "declare_x402", "kind": "max_per_call", "max_amount": "25",
        })
        resp = _send(sock, {"op": "active_revision"})
        assert resp["revision"] is not None
        assert resp["revision"]["proof_backend"] == "python-pattern"

    def test_chain_integrity_in_persisted_log(self, persistent_daemon) -> None:
        sock, log_path = persistent_daemon
        _send(sock, {"op": "declare_x402", "kind": "max_per_call", "max_amount": "25"})
        _send(sock, {"op": "declare_x402", "kind": "retry_rate_limit", "min_gap_seconds": 5})
        lines = log_path.read_text().splitlines()
        assert len(lines) == 2
        r1 = json.loads(lines[0])
        r2 = json.loads(lines[1])
        assert r1["predecessor_revision_id"] is None
        assert r2["predecessor_revision_id"] == r1["revision_id"]


class TestDaemonReloadsOnStartup:
    def test_reloaded_registry_matches_last_admitted(self, tmp_path) -> None:
        log_path = tmp_path / "revs.jsonl"
        fd, sock1 = tempfile.mkstemp(prefix="reload-", suffix=".sock", dir="/tmp")
        os.close(fd)
        os.unlink(sock1)

        # Seed the log with two admitted revisions via a short-lived daemon.
        d1 = CageDaemon(socket_path=sock1, revision_log_path=log_path)
        t1 = threading.Thread(target=d1.serve_forever, daemon=True)
        t1.start()
        for _ in range(50):
            if os.path.exists(sock1):
                break
            time.sleep(0.01)
        try:
            _send(sock1, {"op": "declare_x402", "kind": "max_per_call", "max_amount": "10"})
            _send(sock1, {"op": "declare_x402", "kind": "retry_rate_limit", "min_gap_seconds": 5})
        finally:
            d1.shutdown()
            t1.join(timeout=1.0)

        # New daemon on a fresh socket reads the same log.
        fd, sock2 = tempfile.mkstemp(prefix="reload2-", suffix=".sock", dir="/tmp")
        os.close(fd)
        os.unlink(sock2)
        d2 = CageDaemon(socket_path=sock2, revision_log_path=log_path)
        t2 = threading.Thread(target=d2.serve_forever, daemon=True)
        t2.start()
        for _ in range(50):
            if os.path.exists(sock2):
                break
            time.sleep(0.01)
        try:
            active = _send(sock2, {"op": "active_x402"})
            assert active["active_invariants"] == 2
            assert sorted(active["kinds"]) == ["MaxPerCall", "RetryRateLimit"]
            active_rev = _send(sock2, {"op": "active_revision"})
            assert active_rev["revision"] is not None
        finally:
            d2.shutdown()
            t2.join(timeout=1.0)


# ── strict-mode inconclusive guard ───────────────────────────────────────────


class TestStrictModeInconclusiveDoesNotPersist:
    """Regression guard: strict-mode rejections (inconclusive) must NOT
    append to the persisted PolicyRevision chain. Only decisively-admitted
    revisions enter the audit trail."""

    def test_inconclusive_does_not_create_revision(self, tmp_path) -> None:
        from adapter.prover import InconclusiveProof, PythonPatternProver

        class _InconclusiveTau:
            backend = "tau-stub-inconclusive"

            def prove(self, invariants, predecessor_hash=None):
                return InconclusiveProof(
                    category="timeout",
                    reason="Tau exceeded budget",
                    backend="tau",
                )

        log_path = tmp_path / "revs.jsonl"
        sock = str(tmp_path / "strict.sock")
        d = CageDaemon(
            socket_path=sock,
            prover=PythonPatternProver(),
            prover_mode="strict",
            tau_prover=_InconclusiveTau(),
            revision_log_path=log_path,
        )
        resp = d.dispatch({
            "op": "declare_x402", "kind": "max_per_call", "max_amount": "50",
        })
        assert resp["verdict"] == "inconclusive"
        # No persisted line: rejected revisions never touch disk.
        assert not log_path.exists() or log_path.read_text().strip() == ""
        active = d.dispatch({"op": "active_revision"})
        assert active["revision"] is None
