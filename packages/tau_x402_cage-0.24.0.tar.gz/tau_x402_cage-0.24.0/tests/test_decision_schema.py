"""Tests for the canonical decision schema (``adapter/decision_schema.py``).

Covers:

* ``rule_id_to_reason`` maps every shipped rule_id correctly.
* Unknown rule_ids fall back to ``policy_inconclusive``.
* ``PaymentDecision.to_wire()`` / ``from_wire()`` round-trip cleanly.
* ``next_action_for`` returns the expected canonical action for each
  DecisionReason.
* Fail-closed defaults: an empty PaymentDecision deny still emits a
  valid structured shape.
"""
from __future__ import annotations

import json
from decimal import Decimal

import pytest

from adapter.decision_schema import (
    DECISION_REASONS,
    PaymentDecision,
    RiskPrevented,
    next_action_for,
    rule_id_to_reason,
)


# ── rule_id_to_reason ───────────────────────────────────────────────────────


class TestRuleIdMapping:
    """Every rule_id emitted by the cage maps to a canonical DecisionReason."""

    @pytest.mark.parametrize(
        "rule_id, expected",
        [
            # SpendingCap + MaxPerCall — all collapse to spend_cap_exceeded.
            ("max_per_call", "spend_cap_exceeded"),
            ("spending_cap_per_tx", "spend_cap_exceeded"),
            ("spending_cap_per_window", "spend_cap_exceeded"),
            ("spending_cap_per_provider_per_window", "spend_cap_exceeded"),
            # RetryRateLimit.
            ("retry_rate_limit", "retry_loop_detected"),
            # RollingWindowCap — all three group_by variants.
            ("rolling_window_cap_provider", "burst_velocity_exceeded"),
            ("rolling_window_cap_counterparty", "burst_velocity_exceeded"),
            ("rolling_window_cap_global", "burst_velocity_exceeded"),
            # Provider / counterparty lists.
            ("provider_allowlist", "provider_not_allowed"),
            ("counterparty_sanctioned", "counterparty_not_allowed"),
            ("counterparty_not_approved", "counterparty_not_allowed"),
            # MutualExclusion.
            ("mutual_exclusion", "mutual_exclusion"),
            # InstabilityGuard (self-ref).
            ("instability_guard", "instability_guard_tightened"),
            # Cross-revision + governance.
            ("cross_revision_violation", "cross_revision_violation"),
            ("governance_violation", "governance_violation"),
            # Fail-closed.
            ("cage_unavailable", "cage_unavailable"),
            # Malformed / invalid — policy_inconclusive bucket.
            ("invalid_payment_intent", "policy_inconclusive"),
            ("malformed_request", "policy_inconclusive"),
        ],
    )
    def test_every_known_rule_id_maps(
        self, rule_id: str, expected: str
    ) -> None:
        assert rule_id_to_reason(rule_id) == expected

    def test_none_rule_id_maps_to_allowed(self) -> None:
        assert rule_id_to_reason(None) == "allowed"

    def test_unknown_rule_id_is_policy_inconclusive(self) -> None:
        """Unknown rule_ids must fall through to ``policy_inconclusive``.

        Important: they MUST NOT default to ``allowed``. A new rule_id
        added upstream without updating the mapping must fail closed on
        the agent side, not accidentally permit.
        """
        assert rule_id_to_reason("some_future_rule") == "policy_inconclusive"
        assert rule_id_to_reason("") == "policy_inconclusive"

    def test_jurisdiction_prefix_maps_to_jurisdiction_bucket(self) -> None:
        """Jurisdiction-prefixed rule_ids collapse to ``jurisdiction_not_allowed``."""
        assert (
            rule_id_to_reason("jurisdiction_eu.max_per_call")
            == "jurisdiction_not_allowed"
        )
        assert (
            rule_id_to_reason("jurisdiction_us.spending_cap_per_window")
            == "jurisdiction_not_allowed"
        )

    def test_every_reason_is_in_the_taxonomy(self) -> None:
        """Sanity: DECISION_REASONS tuple covers the whole Literal surface."""
        # Hard-coded expected set — drift guard. When the taxonomy grows
        # this test needs an explicit bump, preventing silent wire breaks.
        expected = {
            "allowed",
            "spend_cap_exceeded",
            "retry_loop_detected",
            "cooldown_active",
            "burst_velocity_exceeded",
            "adaptive_tightening_triggered",
            "provider_not_allowed",
            "counterparty_not_allowed",
            "jurisdiction_not_allowed",
            "mutual_exclusion",
            "instability_guard_tightened",
            "cross_revision_violation",
            "governance_violation",
            "policy_inconclusive",
            "approval_required",
            "cage_unavailable",
            # v0.21.0 additions.
            "composed_constraint_violation",
            "revision_transition_violation",
        }
        assert set(DECISION_REASONS) == expected


# ── next_action_for ─────────────────────────────────────────────────────────


class TestNextAction:
    def test_allowed_proceeds(self) -> None:
        assert next_action_for("allowed") == "proceed"

    def test_approval_required_requests_approval(self) -> None:
        assert next_action_for("approval_required") == "request_approval"

    def test_cage_unavailable_aborts(self) -> None:
        assert next_action_for("cage_unavailable") == "abort"
        # Even with retry_after, unavailable ALWAYS aborts. The agent
        # must not paper over a cage outage with a retry loop.
        assert next_action_for("cage_unavailable", retry_after=5) == "abort"

    def test_policy_inconclusive_aborts(self) -> None:
        assert next_action_for("policy_inconclusive") == "abort"

    def test_retry_loop_with_retry_after_waits_for_cooldown(self) -> None:
        assert (
            next_action_for("retry_loop_detected", retry_after=5)
            == "wait_for_cooldown"
        )

    def test_retry_loop_without_retry_after_retries_later(self) -> None:
        assert next_action_for("retry_loop_detected") == "retry_later"
        assert next_action_for("retry_loop_detected", retry_after=0) == "retry_later"

    def test_burst_velocity_with_hint_waits(self) -> None:
        assert (
            next_action_for("burst_velocity_exceeded", retry_after=10)
            == "wait_for_cooldown"
        )

    def test_cooldown_active_waits(self) -> None:
        assert (
            next_action_for("cooldown_active", retry_after=60)
            == "wait_for_cooldown"
        )

    @pytest.mark.parametrize(
        "reason",
        [
            "spend_cap_exceeded",
            "provider_not_allowed",
            "counterparty_not_allowed",
            "jurisdiction_not_allowed",
            "mutual_exclusion",
            "instability_guard_tightened",
            "cross_revision_violation",
            "governance_violation",
        ],
    )
    def test_non_transient_denies_adjust_policy(self, reason: str) -> None:
        assert next_action_for(reason) == "adjust_policy"  # type: ignore[arg-type]

    def test_adaptive_tightening_transient_routes_to_cooldown(self) -> None:
        # v0.21.0: adaptive_tightening_triggered is TRANSIENT by
        # construction — the clamp decays to baseline with a 900s
        # half-life. Route the agent to wait, not to mutate policy.
        assert (
            next_action_for("adaptive_tightening_triggered", retry_after=30)
            == "wait_for_cooldown"
        )
        assert (
            next_action_for("adaptive_tightening_triggered")
            == "retry_later"
        )


# ── PaymentDecision round-trip ──────────────────────────────────────────────


class TestPaymentDecisionRoundTrip:
    def test_allowed_decision_round_trip(self) -> None:
        d = PaymentDecision(
            allowed=True,
            reason="allowed",
            next_action="proceed",
            cage_mode="enforce",
        )
        wire = d.to_wire()
        assert wire["allowed"] is True
        assert wire["reason"] == "allowed"
        # JSON-serialisable.
        reloaded = json.loads(json.dumps(wire))
        assert reloaded == wire
        # Round trip back through from_wire.
        d2 = PaymentDecision.from_wire(reloaded)
        assert d2 == d

    def test_deny_with_risk_prevented_round_trip(self) -> None:
        risk = RiskPrevented(
            estimated_extra_calls_blocked=3,
            estimated_extra_spend_blocked=Decimal("120.50"),
            currency="USDC",
            source="retry_density",
        )
        d = PaymentDecision(
            allowed=False,
            reason="retry_loop_detected",
            rule_id="retry_rate_limit",
            reason_text="Retry gap 2s below required 5s",
            retry_after_seconds=3,
            proof_mode="pattern",
            proof_backend="python-pattern",
            proof_strength="pattern-only",
            cage_mode="enforce",
            risk_prevented=risk,
            next_action="wait_for_cooldown",
            signed_envelope={"outcome": "reject", "mac_hex": "deadbeef"},
        )
        wire = d.to_wire()
        # Decimal must serialise as a string.
        assert wire["risk_prevented"]["estimated_extra_spend_blocked"] == "120.50"
        # Full JSON round trip.
        reloaded = json.loads(json.dumps(wire))
        assert reloaded == wire
        d2 = PaymentDecision.from_wire(reloaded)
        assert d2.allowed is False
        assert d2.reason == "retry_loop_detected"
        assert d2.retry_after_seconds == 3
        assert d2.risk_prevented is not None
        assert d2.risk_prevented.estimated_extra_spend_blocked == Decimal("120.50")
        assert d2.risk_prevented.currency == "USDC"
        assert d2.risk_prevented.source == "retry_density"

    def test_from_wire_tolerates_missing_fields(self) -> None:
        """An empty dict should not crash; defaults to fail-closed shape."""
        d = PaymentDecision.from_wire({})
        assert d.allowed is False
        # Unknown reason defaults to policy_inconclusive.
        assert d.reason == "policy_inconclusive"
        # Unknown next_action defaults to abort (fail-closed).
        assert d.next_action == "abort"
        assert d.cage_mode == "enforce"
        assert d.signed_envelope == {}

    def test_from_wire_rejects_unknown_literals_safely(self) -> None:
        """Unknown enum values fall back to safe defaults, never crash."""
        d = PaymentDecision.from_wire(
            {
                "allowed": False,
                "reason": "some_future_reason",
                "next_action": "some_future_action",
                "cage_mode": "weird_mode",
                "proof_mode": "gibberish",
            }
        )
        assert d.reason == "policy_inconclusive"
        assert d.next_action == "abort"
        assert d.cage_mode == "enforce"
        assert d.proof_mode is None

    def test_signed_envelope_is_preserved_verbatim(self) -> None:
        env = {
            "outcome": "permit",
            "rule_id": None,
            "intent_hash": "abc123",
            "mac_hex": "deadbeef",
            "mac_alg": "HMAC-SHA256",
        }
        d = PaymentDecision(
            allowed=True,
            reason="allowed",
            signed_envelope=env,
        )
        assert d.to_wire()["signed_envelope"] == env


# ── RiskPrevented ────────────────────────────────────────────────────────────


class TestRiskPrevented:
    def test_to_wire_serialises_decimal(self) -> None:
        r = RiskPrevented(
            estimated_extra_calls_blocked=5,
            estimated_extra_spend_blocked=Decimal("99.99"),
            currency="USDC",
            source="spend_velocity",
        )
        w = r.to_wire()
        assert w["estimated_extra_spend_blocked"] == "99.99"
        assert w["source"] == "spend_velocity"

    def test_to_wire_handles_none(self) -> None:
        r = RiskPrevented()
        w = r.to_wire()
        assert w["estimated_extra_calls_blocked"] is None
        assert w["estimated_extra_spend_blocked"] is None
        assert w["currency"] is None
        # Default source is rule_composition.
        assert w["source"] == "rule_composition"


# ── immutability ────────────────────────────────────────────────────────────


class TestImmutability:
    def test_payment_decision_is_frozen(self) -> None:
        d = PaymentDecision(allowed=True, reason="allowed")
        with pytest.raises(Exception):  # FrozenInstanceError subclasses Exception
            d.allowed = False  # type: ignore[misc]

    def test_risk_prevented_is_frozen(self) -> None:
        r = RiskPrevented()
        with pytest.raises(Exception):
            r.currency = "USD"  # type: ignore[misc]
