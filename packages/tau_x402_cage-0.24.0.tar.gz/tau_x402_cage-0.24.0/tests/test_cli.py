"""Tests for the CLI entry point.

Covers the `init` subcommand (file scaffolding) and the run path argument
parsing. The run path's serve loop isn't tested here (it would spin up a
real daemon) -- that's covered by tests/test_daemon_check_payment.py.
"""
from __future__ import annotations

import io
import json
import os
import socket
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path
from typing import Iterator

import pytest

from daemon import cli


def _run_cli(args: list[str], cwd: Path | None = None) -> subprocess.CompletedProcess:
    """Invoke the installed tau-x402-cage entry point in a subprocess.

    Subprocess runs with a cwd outside the repo (pytest tmp_path), so
    propagate the repo root via PYTHONPATH so `python -m daemon.cli`
    resolves when the package hasn't been `pip install -e .`'d.
    """
    env = os.environ.copy()
    repo_root = str(Path(__file__).resolve().parent.parent)
    env["PYTHONPATH"] = os.pathsep.join(
        [repo_root, env.get("PYTHONPATH", "")]
    ).rstrip(os.pathsep)
    return subprocess.run(
        [sys.executable, "-m", "daemon.cli", *args],
        cwd=cwd, capture_output=True, text=True, timeout=10, env=env,
    )


class TestInitSubcommand:
    def test_init_writes_both_files(self, tmp_path: Path) -> None:
        result = _run_cli(["init"], cwd=tmp_path)
        assert result.returncode == 0, result.stderr
        assert (tmp_path / "policy.yaml").exists()
        assert (tmp_path / "docker-compose.yaml").exists()

    def test_init_refuses_overwrite(self, tmp_path: Path) -> None:
        (tmp_path / "policy.yaml").write_text("existing: true\n")
        result = _run_cli(["init"], cwd=tmp_path)
        assert result.returncode == 2
        assert "refusing to overwrite" in result.stderr.lower()

    def test_init_force_overwrites(self, tmp_path: Path) -> None:
        (tmp_path / "policy.yaml").write_text("existing: true\n")
        result = _run_cli(["init", "--force"], cwd=tmp_path)
        assert result.returncode == 0
        # Force replaces the placeholder with the real starter
        assert "version: 1" in (tmp_path / "policy.yaml").read_text()

    def test_init_next_steps_in_stdout(self, tmp_path: Path) -> None:
        result = _run_cli(["init"], cwd=tmp_path)
        assert "Next steps" in result.stdout
        assert "--policy" in result.stdout

    def test_init_custom_paths(self, tmp_path: Path) -> None:
        result = _run_cli(
            ["init", "--policy-path", str(tmp_path / "my.yaml"),
             "--compose-path", str(tmp_path / "my-compose.yaml")],
            cwd=tmp_path,
        )
        assert result.returncode == 0
        assert (tmp_path / "my.yaml").exists()
        assert (tmp_path / "my-compose.yaml").exists()


class TestRunPath:
    """The main `_cmd_run` path; tested without hitting serve_forever."""

    def test_bad_policy_path_exits_2(self, tmp_path: Path) -> None:
        result = _run_cli(
            ["--socket", str(tmp_path / "dead.sock"),
             "--policy", str(tmp_path / "nonexistent.yaml")],
        )
        assert result.returncode == 2
        assert "policy load failed" in result.stderr

    def test_help_lists_init_and_flags(self) -> None:
        result = _run_cli(["--help"])
        assert result.returncode == 0
        assert "init" in result.stdout
        assert "--socket" in result.stdout
        assert "--policy" in result.stdout


class TestSuggestSubcommand:
    def test_suggest_prints_prompt(self) -> None:
        result = _run_cli(["suggest", "cap", "daily", "at", "$500"])
        assert result.returncode == 0
        assert "BEGIN PROMPT" in result.stdout
        assert "END PROMPT" in result.stdout
        assert "version: 1" in result.stdout  # schema reference
        assert "spending_cap" in result.stdout
        assert "cap daily at $500" in result.stdout  # user request echoed

    def test_suggest_without_request_errors(self) -> None:
        result = _run_cli(["suggest"])
        assert result.returncode == 2
        assert "plain-English" in result.stderr


class TestMainReturnValues:
    """Direct invocation of cli.main with monkeypatched argv."""

    def test_main_init_success(self, tmp_path: Path, monkeypatch) -> None:
        monkeypatch.chdir(tmp_path)
        monkeypatch.setattr(sys, "argv", ["tau-x402-cage", "init"])
        rc = cli.main()
        assert rc == 0
        assert (tmp_path / "policy.yaml").exists()

    def test_main_init_refuses_when_exists(self, tmp_path: Path, monkeypatch) -> None:
        (tmp_path / "policy.yaml").write_text("x: 1\n")
        monkeypatch.chdir(tmp_path)
        monkeypatch.setattr(sys, "argv", ["tau-x402-cage", "init"])
        rc = cli.main()
        assert rc == 2


class TestResolveRunConfig:
    """Resolution order: CLI flag > env var > policy.yaml cage: block > default."""

    def _parse(self, argv: list[str]):
        return cli._build_parser().parse_args(argv)

    def _policy(self, tmp_path: Path, body: str) -> Path:
        p = tmp_path / "p.yaml"
        p.write_text(body, encoding="utf-8")
        return p

    # ---- defaults ----

    def test_defaults_when_nothing_set(self) -> None:
        args = self._parse([])
        mode, timeout, fragment, loaded = cli._resolve_run_config(args, {})
        assert mode == "compat"
        assert timeout == 10000
        assert fragment == "v1"
        assert loaded is None

    # ---- policy.yaml is consulted ----

    def test_policy_file_provides_values(self, tmp_path: Path) -> None:
        p = self._policy(tmp_path, """\
cage:
  prover_mode: verified
  tau_timeout_ms: 3000
  semantic_fragment: v1
version: 1
policy: []
""")
        args = self._parse(["--policy", str(p)])
        mode, timeout, fragment, loaded = cli._resolve_run_config(args, {})
        assert mode == "verified"
        assert timeout == 3000
        assert fragment == "v1"
        assert loaded is not None

    # ---- env overrides policy.yaml ----

    def test_env_overrides_policy_for_all_three(self, tmp_path: Path) -> None:
        p = self._policy(tmp_path, """\
cage:
  prover_mode: verified
  tau_timeout_ms: 3000
  semantic_fragment: v1
version: 1
policy: []
""")
        args = self._parse(["--policy", str(p)])
        env = {
            "CAGE_PROVER_MODE": "compat",
            "CAGE_TAU_TIMEOUT_MS": "7500",
            "CAGE_SEMANTIC_FRAGMENT": "v1",
        }
        mode, timeout, fragment, _ = cli._resolve_run_config(args, env)
        assert mode == "compat"
        assert timeout == 7500
        assert fragment == "v1"

    def test_env_alone_no_policy(self) -> None:
        args = self._parse([])
        env = {"CAGE_TAU_TIMEOUT_MS": "250"}
        _, timeout, _, _ = cli._resolve_run_config(args, env)
        assert timeout == 250

    # ---- CLI overrides env ----

    def test_cli_flag_beats_env_for_tau_timeout(self) -> None:
        args = self._parse(["--tau-timeout-ms", "500"])
        env = {"CAGE_TAU_TIMEOUT_MS": "9999"}
        _, timeout, _, _ = cli._resolve_run_config(args, env)
        assert timeout == 500

    def test_cli_flag_beats_env_for_semantic_fragment(self) -> None:
        args = self._parse(["--semantic-fragment", "v1"])
        env = {"CAGE_SEMANTIC_FRAGMENT": "v99"}
        _, _, fragment, _ = cli._resolve_run_config(args, env)
        assert fragment == "v1"

    def test_cli_flag_beats_policy_and_env_full_stack(self, tmp_path: Path) -> None:
        p = self._policy(tmp_path, """\
cage:
  prover_mode: verified
  tau_timeout_ms: 3000
version: 1
policy: []
""")
        args = self._parse([
            "--policy", str(p),
            "--prover-mode", "strict",
            "--tau-timeout-ms", "1234",
        ])
        env = {"CAGE_PROVER_MODE": "compat", "CAGE_TAU_TIMEOUT_MS": "9999"}
        mode, timeout, fragment, _ = cli._resolve_run_config(args, env)
        assert mode == "strict"
        assert timeout == 1234
        assert fragment == "v1"

    # ---- validation errors ----

    def test_bad_env_timeout_raises(self) -> None:
        args = self._parse([])
        with pytest.raises(cli._CliConfigError, match="CAGE_TAU_TIMEOUT_MS"):
            cli._resolve_run_config(args, {"CAGE_TAU_TIMEOUT_MS": "abc"})

    def test_negative_cli_timeout_raises(self) -> None:
        args = self._parse(["--tau-timeout-ms", "-1"])
        with pytest.raises(cli._CliConfigError, match="tau_timeout_ms"):
            cli._resolve_run_config(args, {})

    def test_zero_cli_timeout_raises(self) -> None:
        args = self._parse(["--tau-timeout-ms", "0"])
        with pytest.raises(cli._CliConfigError, match="tau_timeout_ms"):
            cli._resolve_run_config(args, {})

    def test_unknown_semantic_fragment_raises(self) -> None:
        args = self._parse(["--semantic-fragment", "v99"])
        with pytest.raises(cli._CliConfigError, match="semantic_fragment"):
            cli._resolve_run_config(args, {})

    def test_unknown_fragment_from_env_raises(self) -> None:
        args = self._parse([])
        with pytest.raises(cli._CliConfigError, match="semantic_fragment"):
            cli._resolve_run_config(args, {"CAGE_SEMANTIC_FRAGMENT": "v42"})

    def test_bogus_env_prover_mode_raises(self) -> None:
        args = self._parse([])
        with pytest.raises(cli._CliConfigError, match="prover_mode"):
            cli._resolve_run_config(args, {"CAGE_PROVER_MODE": "nonsense"})

    def test_missing_policy_file_raises(self, tmp_path: Path) -> None:
        args = self._parse(["--policy", str(tmp_path / "does-not-exist.yaml")])
        with pytest.raises(cli._CliConfigError, match="policy load failed"):
            cli._resolve_run_config(args, {})


class TestRunFlagsIntegration:
    """End-to-end smoke: CLI surfaces the new flags."""

    def test_help_lists_new_flags(self) -> None:
        result = _run_cli(["--help"])
        assert result.returncode == 0
        assert "--tau-timeout-ms" in result.stdout
        assert "--semantic-fragment" in result.stdout

    def test_bad_env_timeout_exits_2(self, tmp_path: Path) -> None:
        env = {**os.environ, "CAGE_TAU_TIMEOUT_MS": "not-a-number"}
        result = subprocess.run(
            [sys.executable, "-m", "daemon.cli",
             "--socket", str(tmp_path / "x.sock")],
            env=env, capture_output=True, text=True, timeout=10,
        )
        assert result.returncode == 2
        assert "CAGE_TAU_TIMEOUT_MS" in result.stderr

    def test_bad_cli_timeout_exits_2(self, tmp_path: Path) -> None:
        result = _run_cli([
            "--socket", str(tmp_path / "x.sock"),
            "--tau-timeout-ms", "-10",
        ])
        assert result.returncode == 2
        assert "tau_timeout_ms" in result.stderr

    def test_bad_cli_fragment_exits_2(self, tmp_path: Path) -> None:
        result = _run_cli([
            "--socket", str(tmp_path / "x.sock"),
            "--semantic-fragment", "v42",
        ])
        assert result.returncode == 2
        assert "semantic_fragment" in result.stderr


# ── inspect + explain subcommands ────────────────────────────────────────────


class TestInspectExplainHelp:
    def test_inspect_help_mentions_subcommand(self) -> None:
        r = _run_cli(["--help"])
        assert r.returncode == 0
        assert "inspect" in r.stdout

    def test_inspect_own_help(self) -> None:
        r = _run_cli(["inspect", "--help"])
        assert r.returncode == 0
        assert "--socket" in r.stdout

    def test_explain_help_mentions_subcommand(self) -> None:
        r = _run_cli(["--help"])
        assert r.returncode == 0
        assert "explain" in r.stdout

    def test_explain_own_help_lists_policy_flag(self) -> None:
        r = _run_cli(["explain", "--help"])
        assert r.returncode == 0
        assert "--policy" in r.stdout
        assert "--socket" in r.stdout


class TestInspectExplainUnreachableDaemon:
    """With no daemon running, the client should fail cleanly with rc=2."""

    def test_inspect_unreachable_exits_2(self, tmp_path: Path) -> None:
        r = _run_cli(["inspect", "--socket", str(tmp_path / "nope.sock")])
        assert r.returncode == 2
        assert "failed to reach daemon" in r.stderr

    def test_explain_unreachable_exits_2(self, tmp_path: Path) -> None:
        r = _run_cli(["explain", "--socket", str(tmp_path / "nope.sock")])
        assert r.returncode == 2
        assert "failed to reach daemon" in r.stderr

    def test_explain_with_missing_policy_exits_2(self, tmp_path: Path) -> None:
        r = _run_cli([
            "explain",
            "--socket", str(tmp_path / "nope.sock"),
            "--policy", str(tmp_path / "missing.yaml"),
        ])
        assert r.returncode == 2


class TestInspectExplainRendering:
    """Unit-test the renderers directly (no daemon needed)."""

    def test_render_inspect_empty(self) -> None:
        buf = io.StringIO()
        cli._render_inspect({
            "verdict": "ok",
            "active_revision_id": None,
            "active_invariants": 0,
            "invariants": [],
            "prover_mode": "compat",
            "proof_backend": None,
            "proof_strength": None,
            "fragment_version": None,
            "compile_hash": None,
            "admitted_at_unix": None,
        }, buf)
        out = buf.getvalue()
        assert "Active policy snapshot" in out
        assert "(none)" in out
        assert "compat" in out

    def test_render_inspect_with_invariants(self) -> None:
        buf = io.StringIO()
        cli._render_inspect({
            "verdict": "ok",
            "active_revision_id": "abc123",
            "active_invariants": 1,
            "invariants": [{"class": "MaxPerCall", "scope_hint": "max=50"}],
            "prover_mode": "strict",
            "proof_backend": "tau",
            "proof_strength": "complete",
            "fragment_version": "v1",
            "compile_hash": "deadbeef",
            "admitted_at_unix": 1_700_000_000,
        }, buf)
        out = buf.getvalue()
        assert "MaxPerCall" in out
        assert "max=50" in out
        assert "strict" in out
        assert "tau" in out

    def test_render_explain_sat(self) -> None:
        buf = io.StringIO()
        cli._render_explain({
            "verdict": "sat",
            "report": None,
            "proof_token": {
                "backend": "tau",
                "proof_strength": "complete",
                "compile_hash": "abc",
            },
        }, buf)
        out = buf.getvalue()
        assert "admissible" in out
        assert "tau" in out
        assert "complete" in out

    def test_render_explain_unsat_with_repair(self) -> None:
        buf = io.StringIO()
        cli._render_explain({
            "verdict": "unsat",
            "report": {
                "kind": "contradiction",
                "conflicting_invariants": ["L", "R"],
                "unsat_explanation": "they clash",
                "suggested_repair": "fix it",
                "backend": "python-pattern",
            },
            "proof_token": None,
        }, buf)
        out = buf.getvalue()
        assert "Contradiction" in out
        assert "['L', 'R']" in out
        assert "fix it" in out

    def test_render_explain_inconclusive(self) -> None:
        buf = io.StringIO()
        cli._render_explain({
            "verdict": "inconclusive",
            "report": {
                "kind": "inconclusive",
                "category": "timeout",
                "reason": "Tau exceeded budget",
                "backend": "tau",
                "details": {},
            },
            "proof_token": None,
        }, buf)
        out = buf.getvalue()
        assert "Inconclusive" in out
        assert "timeout" in out

    def test_render_explain_unknown_verdict(self) -> None:
        buf = io.StringIO()
        cli._render_explain({"verdict": "???"}, buf)
        assert "Unexpected verdict" in buf.getvalue()


class TestInvariantRoundTrip:
    """``_invariant_to_entry`` round-trips every fragment-v1 invariant."""

    def test_max_per_call(self) -> None:
        from decimal import Decimal

        from adapter.invariants import MaxPerCall
        out = cli._invariant_to_entry(MaxPerCall(max_amount=Decimal("5")))
        assert out == {"kind": "max_per_call", "max_amount": "5", "currency": "USDC"}

    def test_spending_cap_per_window(self) -> None:
        from decimal import Decimal

        from adapter.invariants import SpendingCap
        out = cli._invariant_to_entry(SpendingCap(
            max_amount=Decimal("100"), scope="per_window", window_seconds=60,
        ))
        assert out["kind"] == "spending_cap"
        assert out["window_seconds"] == 60
        assert out["scope"] == "per_window"

    def test_provider_allowlist(self) -> None:
        from adapter.invariants import ProviderAllowlist
        out = cli._invariant_to_entry(
            ProviderAllowlist(providers=frozenset({"b", "a"}))
        )
        assert out == {"kind": "provider_allowlist", "providers": ["a", "b"]}

    def test_retry_rate_limit(self) -> None:
        from adapter.invariants import RetryRateLimit
        out = cli._invariant_to_entry(RetryRateLimit(min_gap_seconds=7))
        assert out == {"kind": "retry_rate_limit", "min_gap_seconds": 7}

    def test_rolling_window_cap(self) -> None:
        from adapter.invariants import RollingWindowCap
        out = cli._invariant_to_entry(
            RollingWindowCap(max_count=10, window_seconds=60, group_by="global")
        )
        assert out["kind"] == "rolling_window_cap"
        assert out["group_by"] == "global"

    def test_counterparty_constraint(self) -> None:
        from adapter.invariants import CounterpartyConstraint
        out = cli._invariant_to_entry(
            CounterpartyConstraint(
                approved_ids=frozenset({"x", "y"}),
                sanctioned_ids=frozenset({"bad"}),
            )
        )
        assert out["kind"] == "counterparty_constraint"
        assert out["approved_ids"] == ["x", "y"]
        assert out["sanctioned_ids"] == ["bad"]

    def test_mutual_exclusion(self) -> None:
        from adapter.invariants import MutualExclusion
        out = cli._invariant_to_entry(
            MutualExclusion(
                group_a=frozenset({"a", "b"}),
                group_b=frozenset({"c"}),
            )
        )
        assert out["kind"] == "mutual_exclusion"
        assert out["group_a"] == ["a", "b"]


class TestInspectSubprocessSmoke:
    """Spin up a real daemon subprocess and run `inspect` against it.

    Covers the end-to-end wiring: socket connection, JSON framing,
    rendering. Uses a short /tmp path to dodge macOS's ~104-char UDS limit.
    """

    @pytest.fixture
    def live_daemon(self) -> Iterator[str]:
        fd, path = tempfile.mkstemp(prefix="cli-", suffix=".sock", dir="/tmp")
        os.close(fd)
        os.unlink(path)
        from daemon.server import CageDaemon
        d = CageDaemon(socket_path=path)
        t = threading.Thread(target=d.serve_forever, daemon=True)
        t.start()
        for _ in range(50):
            if os.path.exists(path):
                break
            time.sleep(0.01)
        try:
            yield path
        finally:
            d.shutdown()
            t.join(timeout=1.0)

    def test_inspect_runs_against_live_daemon(self, live_daemon: str) -> None:
        r = _run_cli(["inspect", "--socket", live_daemon])
        assert r.returncode == 0, r.stderr
        assert "Active policy snapshot" in r.stdout
        assert "prover_mode" in r.stdout
        assert "active_invariants:  0" in r.stdout

    def test_explain_runs_against_live_daemon(self, live_daemon: str) -> None:
        r = _run_cli(["explain", "--socket", live_daemon])
        assert r.returncode == 0, r.stderr
        assert "admissible" in r.stdout

    def test_explain_with_policy_file(self, live_daemon: str, tmp_path: Path) -> None:
        policy = tmp_path / "p.yaml"
        policy.write_text(
            "version: 1\n"
            "policy:\n"
            "  - kind: max_per_call\n"
            "    max_amount: \"10\"\n",
            encoding="utf-8",
        )
        r = _run_cli(["explain", "--socket", live_daemon, "--policy", str(policy)])
        assert r.returncode == 0, r.stderr
        assert "admissible" in r.stdout


class TestProverMetricsCli:
    """End-to-end coverage for the v0.7.0 `prover-metrics` subcommand."""

    def test_prover_metrics_help_mentions_subcommand(self) -> None:
        r = _run_cli(["--help"])
        assert r.returncode == 0
        assert "prover-metrics" in r.stdout

    def test_prover_metrics_own_help(self) -> None:
        r = _run_cli(["prover-metrics", "--help"])
        assert r.returncode == 0
        assert "--socket" in r.stdout

    def test_prover_metrics_unreachable_exits_2(self, tmp_path: Path) -> None:
        r = _run_cli(["prover-metrics", "--socket", str(tmp_path / "nope.sock")])
        assert r.returncode == 2
        assert "failed to reach daemon" in r.stderr

    def test_prover_metrics_runs_against_live_daemon(self) -> None:
        fd, path = tempfile.mkstemp(prefix="cli-m-", suffix=".sock", dir="/tmp")
        os.close(fd)
        os.unlink(path)
        from daemon.server import CageDaemon
        d = CageDaemon(socket_path=path)
        t = threading.Thread(target=d.serve_forever, daemon=True)
        t.start()
        for _ in range(50):
            if os.path.exists(path):
                break
            time.sleep(0.01)
        try:
            r = _run_cli(["prover-metrics", "--socket", path])
            assert r.returncode == 0, r.stderr
            assert "Prover metrics snapshot" in r.stdout
            assert "pattern_backend:" in r.stdout
            # No z3 prover wired -> the "not wired" label appears.
            assert "not wired" in r.stdout
        finally:
            d.shutdown()
            t.join(timeout=1.0)
