"""Activation-path tests for Guaranteed Mode (v0.19.0 product switch).

Covers the three surfaces the brief promises as load-bearing:

1. YAML ``cage.prover_mode: guaranteed`` activates the Guaranteed tier
   end-to-end (daemon wires a ``GuaranteedProver``, ``inspect_policy``
   reports the bank-deployable surface, unsupported rules reject with
   the canonical envelope shape).
2. ``tau-x402 run --prover-mode guaranteed`` takes precedence over a
   YAML ``flexible`` directive.
3. A typo in ``cage.prover_mode`` is a ``PolicyYamlError`` (we reuse
   :class:`PolicyLoaderError` — the YAML error is its subclass here).

Kept socket-free; every test drives ``CageDaemon.dispatch`` directly
(matches the style in tests/test_inspect_explain.py + test_daemon_*.py).
"""

from __future__ import annotations

from decimal import Decimal
from pathlib import Path

import pytest

from adapter.invariants import (
    JurisdictionRule,
    MaxPerCall,
    SpendingCap,
)
from adapter.policy_loader import (
    CageConfig,
    PolicyLoaderError,
    load_policy,
)
from adapter.prover import PythonPatternProver, TauConsistencyProver
from daemon import cli as cli_module
from daemon.server import CageDaemon


# ── YAML parser ─────────────────────────────────────────────────────────────


class TestYamlParsing:
    """The ``cage.prover_mode`` field accepts the full brief vocabulary
    (``compat``/``verified``/``strict``/``flexible``/``guaranteed``) and
    surfaces typos as :class:`PolicyLoaderError`.
    """

    def _write_policy(self, tmp_path: Path, mode: str | None) -> Path:
        body = (
            "version: 1\n"
            "policy:\n"
            "  - kind: max_per_call\n"
            '    max_amount: "50"\n'
            "    currency: USDC\n"
        )
        if mode is not None:
            body += "cage:\n"
            body += f"  prover_mode: {mode}\n"
        p = tmp_path / "policy.yaml"
        p.write_text(body)
        return p

    def test_yaml_guaranteed_mode_activates_guaranteed(self, tmp_path: Path) -> None:
        """Test 1 (brief): YAML activates Guaranteed; inspect reflects it."""
        p = self._write_policy(tmp_path, "guaranteed")
        loaded = load_policy(p)
        assert loaded.cage_config.prover_mode == "guaranteed"
        assert loaded.cage_config.is_guaranteed is True
        assert loaded.cage_config.resolved_prover_mode == "guaranteed"

    def test_yaml_flexible_aliases_to_compat(self, tmp_path: Path) -> None:
        p = self._write_policy(tmp_path, "flexible")
        loaded = load_policy(p)
        # ``flexible`` spelling is preserved for audit …
        assert loaded.cage_config.prover_mode == "flexible"
        # … but the wire-level mode the daemon sees is ``compat``.
        assert loaded.cage_config.resolved_prover_mode == "compat"
        assert loaded.cage_config.is_guaranteed is False

    def test_yaml_banana_raises_loader_error(self, tmp_path: Path) -> None:
        """YAML ``prover_mode: banana`` -> PolicyLoaderError (the YAML
        error channel the public API promises)."""
        p = self._write_policy(tmp_path, "banana")
        with pytest.raises(PolicyLoaderError) as exc:
            load_policy(p)
        assert "prover_mode" in str(exc.value)
        assert "banana" in str(exc.value)

    def test_yaml_no_cage_block_defaults_to_compat(self, tmp_path: Path) -> None:
        p = self._write_policy(tmp_path, None)
        loaded = load_policy(p)
        assert loaded.cage_config.prover_mode == "compat"
        assert loaded.cage_config.is_guaranteed is False

    def test_cageconfig_direct_rejects_unknown_mode(self) -> None:
        with pytest.raises(PolicyLoaderError):
            CageConfig(prover_mode="banana").validated()


# ── CLI precedence ──────────────────────────────────────────────────────────


class TestCliPrecedence:
    """The run path resolves ``--prover-mode`` > env > YAML > default."""

    def _write_policy(self, tmp_path: Path, mode: str) -> Path:
        body = (
            "version: 1\n"
            "policy:\n"
            "  - kind: max_per_call\n"
            '    max_amount: "50"\n'
            "    currency: USDC\n"
            "cage:\n"
            f"  prover_mode: {mode}\n"
        )
        p = tmp_path / "policy.yaml"
        p.write_text(body)
        return p

    def _args(self, **overrides):
        import argparse
        a = argparse.Namespace(
            policy=None,
            prover_mode=None,
            tau_timeout_ms=None,
            semantic_fragment=None,
        )
        for k, v in overrides.items():
            setattr(a, k, v)
        return a

    def test_cli_flag_overrides_yaml_flexible(self, tmp_path: Path) -> None:
        """CLI ``--prover-mode guaranteed`` beats YAML ``flexible``."""
        p = self._write_policy(tmp_path, "flexible")
        args = self._args(policy=str(p), prover_mode="guaranteed")
        mode, _ts, _frag, _loaded = cli_module._resolve_run_config(args, env={})
        assert mode == "guaranteed"

    def test_yaml_guaranteed_without_cli_override(self, tmp_path: Path) -> None:
        p = self._write_policy(tmp_path, "guaranteed")
        args = self._args(policy=str(p))
        mode, _, _, _ = cli_module._resolve_run_config(args, env={})
        assert mode == "guaranteed"

    def test_cli_flexible_is_folded_to_compat(self, tmp_path: Path) -> None:
        """``--prover-mode flexible`` lands on the ``compat`` wire name."""
        args = self._args(prover_mode="flexible")
        mode, _, _, _ = cli_module._resolve_run_config(args, env={})
        assert mode == "compat"

    def test_env_var_overrides_yaml(self, tmp_path: Path) -> None:
        p = self._write_policy(tmp_path, "flexible")
        args = self._args(policy=str(p))
        mode, _, _, _ = cli_module._resolve_run_config(
            args, env={"CAGE_PROVER_MODE": "guaranteed"},
        )
        assert mode == "guaranteed"

    def test_argparse_accepts_guaranteed_on_run_subcommand(self) -> None:
        parser = cli_module._build_parser()
        ns = parser.parse_args(["run", "--prover-mode", "guaranteed", "--dry-run"])
        assert ns.prover_mode == "guaranteed"

    def test_argparse_accepts_flexible_on_run_subcommand(self) -> None:
        parser = cli_module._build_parser()
        ns = parser.parse_args(["run", "--prover-mode", "flexible", "--dry-run"])
        assert ns.prover_mode == "flexible"


# ── Daemon wiring + inspect surface ─────────────────────────────────────────


def _guaranteed_daemon(tmp_path: Path) -> CageDaemon:
    """Construct a daemon in Guaranteed Mode.

    Tests that drive admission through the daemon need the real
    ``TauConsistencyProver`` because ``GuaranteedProver`` is strict about
    its prover type. We don't exercise a live Tau process here — the
    Guaranteed admission gate rejects at the language-tier screen
    (pre-Tau), which is the surface the brief's envelope targets.
    """
    return CageDaemon(
        socket_path=str(tmp_path / "gm.sock"),
        prover=PythonPatternProver(),
        prover_mode="guaranteed",
        tau_prover=TauConsistencyProver(timeout_seconds=5.0),
    )


def _flexible_daemon(tmp_path: Path) -> CageDaemon:
    return CageDaemon(
        socket_path=str(tmp_path / "fx.sock"),
        prover=PythonPatternProver(),
        prover_mode="compat",
    )


class TestInspectSurface:
    """Inspect output carries the brief's public-surface fields."""

    def test_inspect_reports_guaranteed_mode(self, tmp_path: Path) -> None:
        d = _guaranteed_daemon(tmp_path)
        r = d.dispatch({"op": "inspect_policy"})
        assert r["mode"] == "guaranteed"
        assert r["fallback"] == "none"
        assert r["totality_gate"] == "enforced"
        assert r["language_tier"] == "1.2.0"
        assert r["proof_backend_public"].startswith("tau")

    def test_inspect_reports_flexible_mode(self, tmp_path: Path) -> None:
        d = _flexible_daemon(tmp_path)
        r = d.dispatch({"op": "inspect_policy"})
        assert r["mode"] == "flexible"
        assert r["fallback"] == "pattern"
        assert r["totality_gate"] == "not enforced (Flexible Mode)"
        assert r["language_tier"] == "n/a"

    def test_inspect_keeps_legacy_schema(self, tmp_path: Path) -> None:
        """Existing callers read ``prover_mode`` / ``active_invariants`` /
        ``proof_backend`` — the new fields must not displace these."""
        d = _guaranteed_daemon(tmp_path)
        r = d.dispatch({"op": "inspect_policy"})
        for legacy in (
            "prover_mode",
            "active_revision_id",
            "active_invariants",
            "proof_backend",
            "proof_strength",
            "fragment_version",
            "compile_hash",
            "admitted_at_unix",
            "invariants",
        ):
            assert legacy in r, f"legacy field missing: {legacy}"

    def test_render_inspect_shows_brief_block_for_guaranteed(self, tmp_path: Path) -> None:
        import io
        d = _guaranteed_daemon(tmp_path)
        r = d.dispatch({"op": "inspect_policy"})
        buf = io.StringIO()
        cli_module._render_inspect(r, buf)
        text = buf.getvalue()
        assert "Mode:" in text
        assert "guaranteed" in text
        assert "Fallback:" in text
        assert "none" in text
        assert "Totality gate:" in text
        assert "enforced" in text
        assert "Language tier:" in text
        assert "1.2.0" in text


# ── Unsupported-rule rejection envelope ─────────────────────────────────────


class TestUnsupportedRuleEnvelope:
    """Unsupported rules under Guaranteed Mode return the brief's shape."""

    def _nested_jurisdiction_rule(self) -> JurisdictionRule:
        """JurisdictionRule with non-empty additional_invariants — v1.2.0
        only admits the flat enum_bv variant, so this rejects."""
        return JurisdictionRule(
            jurisdiction="US",
            additional_invariants=(
                MaxPerCall(max_amount=Decimal("50"), currency="USDC"),
            ),
        )

    def test_nested_jurisdiction_rejects_under_guaranteed(self, tmp_path: Path) -> None:
        d = _guaranteed_daemon(tmp_path)
        inv = self._nested_jurisdiction_rule()
        result = d._apply_revision(
            mutate=lambda reg: reg.declare(inv),
            kind="jurisdiction_rule",
            op_name="declare",
            delta_added=(inv,),
        )
        assert result["allowed"] is False
        assert result["reason"] == "unsupported_for_guaranteed_mode"
        details = result["details"]
        assert details["unsupported_rule"] == "JurisdictionRule"
        assert details["unsupported_variant"] == "nested_composition"
        assert details["language_tier_version"] == "1.2.0"
        # Standard envelope fields still present for v0.13.x readers.
        assert result["verdict"] == "reject"
        assert result["prover_mode"] == "guaranteed"

    def test_nested_jurisdiction_admits_under_flexible(self, tmp_path: Path) -> None:
        d = _flexible_daemon(tmp_path)
        inv = self._nested_jurisdiction_rule()
        result = d._apply_revision(
            mutate=lambda reg: reg.declare(inv),
            kind="jurisdiction_rule",
            op_name="declare",
            delta_added=(inv,),
        )
        assert result["verdict"] == "declare"
        assert result["active_invariants"] == 1

    def test_supported_spending_cap_passes_guaranteed_gate(self, tmp_path: Path) -> None:
        """Smoke: a tier-admitted rule reaches the standard chain (the
        GuaranteedProver doesn't short-circuit admission). We don't invoke
        Tau here — the regular chain drops through; we just need a
        verdict that isn't the language-tier reject."""
        d = _guaranteed_daemon(tmp_path)
        inv = SpendingCap(
            max_amount=Decimal("1000"),
            currency="USDC",
            scope="per_tx",
        )
        # The gate admits; whether Tau also admits depends on environment.
        # Assert at minimum that the response is NOT the brief envelope.
        result = d._apply_revision(
            mutate=lambda reg: reg.declare(inv),
            kind="spending_cap",
            op_name="declare",
            delta_added=(inv,),
        )
        assert result.get("reason") != "unsupported_for_guaranteed_mode"
