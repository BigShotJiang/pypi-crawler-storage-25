"""Tests for adapter.tau_compiler and the _sat_body encoding rules.

Covers:
  * every fragment-v1 invariant compiles successfully
  * compile_hash is deterministic over invariant order
  * out-of-fragment invariants raise UnsupportedInvariantError
  * SpendingCap per_window/per_provider_per_window are correctly
    rejected even though the class is in the registry
  * camelCase + unified bv[64] encoding rules are actually emitted
"""
from __future__ import annotations

from decimal import Decimal

import pytest

from adapter.invariants import (
    CounterpartyConstraint,
    JurisdictionRule,
    MaxPerCall,
    ProviderAllowlist,
    RetryRateLimit,
    RollingWindowCap,
    SpendingCap,
)
from adapter.tau_compiler import (
    CompileError,
    CompiledTauPolicy,
    UnsupportedInvariantError,
    compile_policy,
    fragment_members,
)


class TestFragmentRegistry:
    def test_v1_contains_six_classes(self) -> None:
        assert len(fragment_members("v1")) == 6

    def test_unknown_fragment_raises(self) -> None:
        with pytest.raises(CompileError, match="unknown fragment"):
            fragment_members("v99")


class TestCompileFragmentV1:
    def test_single_max_per_call(self) -> None:
        compiled = compile_policy([MaxPerCall(max_amount=Decimal("50"))])
        assert isinstance(compiled, CompiledTauPolicy)
        assert compiled.fragment_version == "v1"
        assert compiled.total_invariants == 1
        assert compiled.supported_invariants == 1
        assert "cageAmt:bv[64]" in compiled.tau_source
        assert "G(" not in compiled.tau_source  # rule E3: no G wrapper
        assert "[t]" not in compiled.tau_source  # rule E3: no stream index
        assert "_" not in compiled.tau_source  # rule E1: no underscores (besides compile_hash metadata)

    def test_all_five_v1_types_compose(self) -> None:
        invariants = [
            MaxPerCall(max_amount=Decimal("50")),
            ProviderAllowlist(providers=frozenset({"anthropic", "openai"})),
            CounterpartyConstraint(approved_ids=frozenset({"vendor_a"})),
            JurisdictionRule(
                jurisdiction="EU",
                additional_invariants=(MaxPerCall(max_amount=Decimal("10")),),
            ),
            SpendingCap(max_amount=Decimal("100"), scope="per_tx"),
        ]
        compiled = compile_policy(invariants)
        assert compiled.supported_invariants == 5
        for var in ("cageAmt", "cageProvider", "cageCounterparty", "cageJur"):
            assert var in compiled.tau_source
        # Unified width (rule E2): no bv[4], no bv[16] in the spec
        assert ":bv[4]" not in compiled.tau_source
        assert ":bv[16]" not in compiled.tau_source
        assert ":bv[64]" in compiled.tau_source

    def test_compile_hash_stable_within_run(self) -> None:
        invs = [MaxPerCall(max_amount=Decimal("50"))]
        a = compile_policy(invs)
        b = compile_policy(invs)
        assert a.compile_hash == b.compile_hash

    def test_compile_hash_changes_with_amount(self) -> None:
        a = compile_policy([MaxPerCall(max_amount=Decimal("50"))])
        b = compile_policy([MaxPerCall(max_amount=Decimal("51"))])
        assert a.compile_hash != b.compile_hash

    def test_empty_policy_compiles_to_T(self) -> None:
        compiled = compile_policy([])
        assert compiled.tau_source == "T"
        assert compiled.total_invariants == 0

    def test_invariant_summaries_populated(self) -> None:
        compiled = compile_policy([
            MaxPerCall(max_amount=Decimal("10")),
            ProviderAllowlist(providers=frozenset({"a"})),
        ])
        assert len(compiled.invariant_summaries) == 2
        assert compiled.invariant_summaries[0]["class"] == "MaxPerCall"
        assert "max=10" in compiled.invariant_summaries[0]["scope_hint"]


class TestOutOfFragmentRejection:
    def test_retry_rate_limit_rejected(self) -> None:
        with pytest.raises(UnsupportedInvariantError, match="RetryRateLimit"):
            compile_policy([RetryRateLimit(min_gap_seconds=30)])

    def test_rolling_window_cap_rejected(self) -> None:
        with pytest.raises(UnsupportedInvariantError, match="RollingWindowCap"):
            compile_policy([
                RollingWindowCap(max_count=10, window_seconds=60, group_by="provider")
            ])

    def test_spending_cap_per_window_rejected_despite_class_registered(self) -> None:
        """SpendingCap is in the registry, but only per_tx is in fragment v1."""
        inv = SpendingCap(
            max_amount=Decimal("100"), scope="per_window", window_seconds=3600,
        )
        with pytest.raises(UnsupportedInvariantError, match="SpendingCap"):
            compile_policy([inv])

    def test_spending_cap_per_tx_admitted(self) -> None:
        inv = SpendingCap(max_amount=Decimal("100"), scope="per_tx")
        compiled = compile_policy([inv])
        assert compiled.supported_invariants == 1
        assert "cageAmt:bv[64]" in compiled.tau_source

    def test_unsupported_exception_carries_class_name(self) -> None:
        try:
            compile_policy([RetryRateLimit(min_gap_seconds=30)])
        except UnsupportedInvariantError as exc:
            assert exc.invariant_name == "RetryRateLimit"
            assert exc.fragment_version == "v1"

    def test_mixed_policy_fails_on_first_unsupported(self) -> None:
        invs = [
            MaxPerCall(max_amount=Decimal("10")),      # OK
            RetryRateLimit(min_gap_seconds=30),        # BAD
            ProviderAllowlist(providers=frozenset({"a"})),
        ]
        with pytest.raises(UnsupportedInvariantError, match="RetryRateLimit"):
            compile_policy(invs)
