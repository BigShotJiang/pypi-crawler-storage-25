"""Tests for the v0.14.0 explicit guarantees surface.

Coverage:
    * ``enumerate_guarantees`` catalog completeness + per-toggle activation.
    * Daemon op round-trip matches direct enumeration.
    * CLI ``guarantees`` + ``--only-lost`` variants.
    * Web UI ``/ui/guarantees`` three-column render.
    * ``evidence`` dicts are JSON-safe by construction.
"""
from __future__ import annotations

import json
import os
import socket
import subprocess
import sys
import tempfile
import threading
import time
from decimal import Decimal
from pathlib import Path
from typing import Any, Dict, Iterator, Mapping

import pytest

from adapter.guarantees import (
    Guarantee,
    _safe_evidence,
    enumerate_guarantees,
    split_by_status,
)
from adapter.invariants import (
    MaxPerCall,
    ProviderAllowlist,
    RetryRateLimit,
    RollingWindowCap,
    SpendingCap,
)
from adapter.self_ref_policy import InstabilityGuard
from adapter.x402_registry import X402Registry
from daemon.server import CageDaemon


# ── helpers ─────────────────────────────────────────────────────────────────


def _fully_configured_registry() -> X402Registry:
    """Registry that trips every temporal guarantee to active."""
    return X402Registry(
        invariants=(
            MaxPerCall(max_amount=Decimal("100"), currency="USDC"),
            ProviderAllowlist(providers=frozenset({"anthropic"})),
            RetryRateLimit(min_gap_seconds=5),
            RollingWindowCap(
                max_count=10, window_seconds=60, group_by="provider",
            ),
            InstabilityGuard(
                provider="anthropic",
                reject_threshold=3,
                window_seconds=60,
                tighten_to=Decimal("5"),
                recovery_seconds=300,
                currency="USDC",
            ),
        ),
    )


def _full_config() -> Dict[str, Any]:
    """daemon_config snapshot with every togglable guarantee ON."""
    return {
        "signing_algorithm": "ed25519",
        "envelope_version": "v2",
        "hybrid_prover_wired": True,
        "z3_prover_wired": True,
        "approval_queue_configured": True,
        "require_human_approval": True,
        "mutation_governance": {"min_reviewers": 2},
        "cross_revision_rules": ("NoWeakening",),
    }


def _full_env() -> Dict[str, str]:
    """Env snapshot with metrics token configured."""
    return {
        "TAU_CAGE_SIGNING_ALGORITHM": "ed25519",
        "TAU_X402_METRICS_TOKEN": "sk_metrics_test_0123456789",
    }


# ── enumerate_guarantees unit tests ─────────────────────────────────────────


class TestEnumerateFullCatalog:
    def test_full_configuration_yields_at_least_fifteen_guarantees(self) -> None:
        registry = _fully_configured_registry()
        guarantees = enumerate_guarantees(
            registry=registry,
            daemon_config=_full_config(),
            env=_full_env(),
        )
        assert len(guarantees) >= 15

    def test_every_catalog_id_is_unique(self) -> None:
        registry = _fully_configured_registry()
        guarantees = enumerate_guarantees(
            registry=registry,
            daemon_config=_full_config(),
            env=_full_env(),
        )
        ids = [g.id for g in guarantees]
        assert len(ids) == len(set(ids))

    def test_every_shipped_id_is_present(self) -> None:
        registry = _fully_configured_registry()
        guarantees = enumerate_guarantees(
            registry=registry,
            daemon_config=_full_config(),
            env=_full_env(),
        )
        ids = {g.id for g in guarantees}
        required = {
            "G-SIG-01", "G-SIG-02",
            "G-PROV-01", "G-PROV-02",
            "G-DEC-01", "G-DEC-02", "G-DEC-03",
            "G-TMP-01", "G-TMP-02", "G-TMP-03",
            "G-GOV-01", "G-GOV-02",
            "G-OBS-01", "G-OBS-02", "G-OBS-03",
        }
        assert required.issubset(ids)

    def test_every_guarantee_has_populated_required_fields(self) -> None:
        """No None / empty summary / empty lost_if_disabled is allowed."""
        registry = _fully_configured_registry()
        guarantees = enumerate_guarantees(
            registry=registry,
            daemon_config=_full_config(),
            env=_full_env(),
        )
        for g in guarantees:
            assert isinstance(g.id, str) and g.id, g
            assert isinstance(g.summary, str) and g.summary, g
            assert isinstance(g.category, str) and g.category, g
            assert isinstance(g.provided_by, str) and g.provided_by, g
            assert isinstance(g.lost_if_disabled, str), g
            assert g.lost_if_disabled, f"{g.id} has empty lost_if_disabled"
            assert isinstance(g.evidence, Mapping), g

    def test_category_order_is_stable(self) -> None:
        guarantees = enumerate_guarantees(
            registry=_fully_configured_registry(),
            daemon_config=_full_config(),
            env=_full_env(),
        )
        categories_seen = []
        for g in guarantees:
            if not categories_seen or categories_seen[-1] != g.category:
                categories_seen.append(g.category)
        # Each category block should appear at most once (stable sort).
        assert len(categories_seen) == len(set(categories_seen))


class TestPerTogglesActivation:
    def test_hmac_algorithm_disables_g_sig_02(self) -> None:
        config = _full_config()
        config["signing_algorithm"] = "hmac-sha256"
        guarantees = enumerate_guarantees(
            registry=_fully_configured_registry(),
            daemon_config=config,
            env={"TAU_CAGE_SIGNING_ALGORITHM": "hmac-sha256",
                 "TAU_X402_METRICS_TOKEN": "sk_m"},
        )
        by_id = {g.id: g for g in guarantees}
        assert by_id["G-SIG-02"].active is False
        assert "ed25519" in by_id["G-SIG-02"].inactive_reason
        # G-SIG-01 should still be active — MAC binding is always on.
        assert by_id["G-SIG-01"].active is True

    def test_no_instability_guard_disables_g_tmp_03(self) -> None:
        registry = X402Registry(invariants=(
            MaxPerCall(max_amount=Decimal("100"), currency="USDC"),
            # No InstabilityGuard here
        ))
        guarantees = enumerate_guarantees(
            registry=registry,
            daemon_config=_full_config(),
            env=_full_env(),
        )
        by_id = {g.id: g for g in guarantees}
        assert by_id["G-TMP-03"].active is False
        assert "InstabilityGuard" in by_id["G-TMP-03"].inactive_reason

    def test_no_approval_queue_disables_g_gov_01(self) -> None:
        config = _full_config()
        config["approval_queue_configured"] = False
        guarantees = enumerate_guarantees(
            registry=_fully_configured_registry(),
            daemon_config=config,
            env=_full_env(),
        )
        by_id = {g.id: g for g in guarantees}
        assert by_id["G-GOV-01"].active is False
        assert "approval queue" in by_id["G-GOV-01"].inactive_reason

    def test_min_reviewers_below_2_disables_g_gov_01(self) -> None:
        config = _full_config()
        config["mutation_governance"] = {"min_reviewers": 1}
        guarantees = enumerate_guarantees(
            registry=_fully_configured_registry(),
            daemon_config=config,
            env=_full_env(),
        )
        by_id = {g.id: g for g in guarantees}
        assert by_id["G-GOV-01"].active is False
        assert "min_reviewers" in by_id["G-GOV-01"].inactive_reason

    def test_no_hybrid_prover_disables_g_dec_03(self) -> None:
        config = _full_config()
        config["hybrid_prover_wired"] = False
        guarantees = enumerate_guarantees(
            registry=_fully_configured_registry(),
            daemon_config=config,
            env=_full_env(),
        )
        by_id = {g.id: g for g in guarantees}
        assert by_id["G-DEC-03"].active is False

    def test_no_cross_revision_rule_disables_g_gov_02(self) -> None:
        config = _full_config()
        config["cross_revision_rules"] = ()
        guarantees = enumerate_guarantees(
            registry=_fully_configured_registry(),
            daemon_config=config,
            env=_full_env(),
        )
        by_id = {g.id: g for g in guarantees}
        assert by_id["G-GOV-02"].active is False
        assert "NoWeakening" in by_id["G-GOV-02"].inactive_reason

    def test_no_metrics_token_disables_g_obs_03(self) -> None:
        guarantees = enumerate_guarantees(
            registry=_fully_configured_registry(),
            daemon_config=_full_config(),
            env={"TAU_CAGE_SIGNING_ALGORITHM": "ed25519"},
        )
        by_id = {g.id: g for g in guarantees}
        assert by_id["G-OBS-03"].active is False
        assert "TAU_X402_METRICS_TOKEN" in by_id["G-OBS-03"].inactive_reason

    def test_empty_registry_disables_all_temporal_guarantees(self) -> None:
        guarantees = enumerate_guarantees(
            registry=X402Registry.empty(),
            daemon_config=_full_config(),
            env=_full_env(),
        )
        by_id = {g.id: g for g in guarantees}
        assert by_id["G-TMP-01"].active is False
        assert by_id["G-TMP-02"].active is False
        assert by_id["G-TMP-03"].active is False

    def test_v1_envelope_disables_g_prov_01(self) -> None:
        config = _full_config()
        config["envelope_version"] = "v1"
        guarantees = enumerate_guarantees(
            registry=_fully_configured_registry(),
            daemon_config=config,
            env=_full_env(),
        )
        by_id = {g.id: g for g in guarantees}
        assert by_id["G-PROV-01"].active is False


# ── JSON safety ─────────────────────────────────────────────────────────────


class TestEvidenceJsonSafe:
    def test_every_evidence_dict_round_trips_through_json(self) -> None:
        guarantees = enumerate_guarantees(
            registry=_fully_configured_registry(),
            daemon_config=_full_config(),
            env=_full_env(),
        )
        for g in guarantees:
            wire = g.to_wire()
            # json.dumps raises if anything is non-serialisable.
            serialised = json.dumps(wire)
            parsed = json.loads(serialised)
            assert parsed["id"] == g.id

    def test_safe_evidence_stringifies_bytes_and_decimal(self) -> None:
        ev = _safe_evidence(
            raw=b"\x00\x01",
            amt=Decimal("12.34"),
            ok=True,
            count=3,
            nested={"inner": b"bytes"},
        )
        serialised = json.dumps(ev)
        parsed = json.loads(serialised)
        assert isinstance(parsed["raw"], str)
        assert parsed["amt"] == "12.34"
        assert parsed["ok"] is True
        assert parsed["count"] == 3
        assert isinstance(parsed["nested"]["inner"], str)


# ── split_by_status ─────────────────────────────────────────────────────────


class TestSplitByStatus:
    def test_partition_preserves_order(self) -> None:
        guarantees = enumerate_guarantees(
            registry=_fully_configured_registry(),
            daemon_config=_full_config(),
            env=_full_env(),
        )
        active, inactive = split_by_status(guarantees)
        assert len(active) + len(inactive) == len(guarantees)
        # Full config: zero inactive expected (every toggle flipped on).
        assert inactive == []

    def test_partition_under_minimal_config(self) -> None:
        guarantees = enumerate_guarantees(
            registry=X402Registry.empty(),
            daemon_config={},
            env={},
        )
        active, inactive = split_by_status(guarantees)
        # Always-on guarantees: G-SIG-01, G-PROV-02, G-DEC-01, G-OBS-01, G-OBS-02.
        # G-PROV-01 is active iff envelope_version=="v2" (default here).
        assert len(active) >= 5
        assert len(inactive) >= 1


# ── daemon op round-trip ────────────────────────────────────────────────────


@pytest.fixture
def daemon() -> Iterator[tuple[CageDaemon, str]]:
    fd, path = tempfile.mkstemp(prefix="guarantees-", suffix=".sock", dir="/tmp")
    os.close(fd)
    os.unlink(path)
    d = CageDaemon(socket_path=path)
    t = threading.Thread(target=d.serve_forever, daemon=True)
    t.start()
    for _ in range(50):
        if os.path.exists(path):
            break
        time.sleep(0.01)
    try:
        yield d, path
    finally:
        d.shutdown()
        t.join(timeout=1.0)


def _send(path: str, request: dict) -> dict:
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.settimeout(2.0)
    s.connect(path)
    try:
        s.sendall((json.dumps(request) + "\n").encode("utf-8"))
        f = s.makefile("r")
        line = f.readline()
    finally:
        s.close()
    return json.loads(line)


class TestDaemonGuaranteesOp:
    def test_op_returns_ok_with_list(self, daemon) -> None:
        _, path = daemon
        r = _send(path, {"op": "guarantees"})
        assert r["verdict"] == "ok"
        assert isinstance(r["guarantees"], list)
        assert len(r["guarantees"]) >= 15
        assert "active_count" in r
        assert "inactive_count" in r
        assert r["active_count"] + r["inactive_count"] == len(r["guarantees"])

    def test_op_returns_wire_shape_per_entry(self, daemon) -> None:
        _, path = daemon
        r = _send(path, {"op": "guarantees"})
        for g in r["guarantees"]:
            for field in (
                "id", "summary", "category", "provided_by",
                "lost_if_disabled", "active", "evidence", "inactive_reason",
            ):
                assert field in g, f"{g.get('id')} missing {field}"

    def test_op_round_trip_matches_direct_enumerate(self, daemon) -> None:
        """Daemon op should return the same ids as a direct call."""
        d, path = daemon
        r = _send(path, {"op": "guarantees"})
        op_ids = {g["id"] for g in r["guarantees"]}
        direct = enumerate_guarantees(
            registry=X402Registry.empty(),
            daemon_config={},
        )
        direct_ids = {g.id for g in direct}
        # Intersection: the daemon's config differs slightly from a bare
        # `{}`, but every shipped id MUST be present in both.
        required = {
            "G-SIG-01", "G-SIG-02",
            "G-PROV-01", "G-PROV-02",
            "G-DEC-01", "G-DEC-02", "G-DEC-03",
            "G-TMP-01", "G-TMP-02", "G-TMP-03",
            "G-GOV-01", "G-GOV-02",
            "G-OBS-01", "G-OBS-02", "G-OBS-03",
        }
        assert required.issubset(op_ids)
        assert required.issubset(direct_ids)

    def test_op_response_is_json_roundtrippable(self, daemon) -> None:
        _, path = daemon
        r = _send(path, {"op": "guarantees"})
        serialised = json.dumps(r)
        parsed = json.loads(serialised)
        assert parsed == r

    def test_op_does_not_mutate_state(self, daemon) -> None:
        """Guarantees op is read-only; calling it twice yields the same shape."""
        _, path = daemon
        r1 = _send(path, {"op": "guarantees"})
        r2 = _send(path, {"op": "guarantees"})
        assert [g["id"] for g in r1["guarantees"]] == [
            g["id"] for g in r2["guarantees"]
        ]


# ── CLI ─────────────────────────────────────────────────────────────────────


class TestCLI:
    def test_cli_text_prints_active_set(self, daemon) -> None:
        _, path = daemon
        cp = subprocess.run(
            [
                sys.executable, "-m", "daemon.cli", "guarantees",
                "--socket", path,
            ],
            capture_output=True, text=True, timeout=10,
        )
        assert cp.returncode == 0, cp.stderr
        assert "Active guarantees" in cp.stdout
        # Known always-on ids must appear in the output.
        assert "G-SIG-01" in cp.stdout
        assert "G-OBS-01" in cp.stdout

    def test_cli_json_format_emits_raw_response(self, daemon) -> None:
        _, path = daemon
        cp = subprocess.run(
            [
                sys.executable, "-m", "daemon.cli", "guarantees",
                "--socket", path, "--format", "json",
            ],
            capture_output=True, text=True, timeout=10,
        )
        assert cp.returncode == 0, cp.stderr
        data = json.loads(cp.stdout)
        assert data["verdict"] == "ok"
        assert isinstance(data["guarantees"], list)

    def test_cli_only_lost_inverts_the_list(self, daemon) -> None:
        _, path = daemon
        cp = subprocess.run(
            [
                sys.executable, "-m", "daemon.cli", "guarantees",
                "--socket", path, "--only-lost",
            ],
            capture_output=True, text=True, timeout=10,
        )
        assert cp.returncode == 0, cp.stderr
        assert "Inactive guarantees" in cp.stdout
        # An empty-registry daemon has no temporal guarantees active; the
        # --only-lost output should include at least one of them.
        assert (
            "G-TMP-01" in cp.stdout
            or "G-TMP-02" in cp.stdout
            or "G-TMP-03" in cp.stdout
        )
        # Lost-if-disabled narrative should be surfaced in only-lost mode.
        assert "lost:" in cp.stdout or "off because:" in cp.stdout


# ── Web UI ──────────────────────────────────────────────────────────────────


class TestWebUI:
    def _stub(self, responses: Dict[str, Dict[str, Any]]):
        from tests.test_web_ui import StubReader
        return StubReader(responses)

    def _build(self, responses: Dict[str, Dict[str, Any]]):
        pytest.importorskip("fastapi")
        pytest.importorskip("jinja2")
        from fastapi import FastAPI
        from fastapi.testclient import TestClient
        from saas.web_ui.routes import build_router, mount_static_on

        token = "sk_test_guarantees_ui"
        app = FastAPI()
        app.include_router(
            build_router(reader=self._stub(responses), token=token),
            prefix="/ui",
        )
        mount_static_on(app)
        return TestClient(app), token

    def _canned_response(self) -> Dict[str, Any]:
        return {
            "verdict": "ok",
            "active_count": 2,
            "inactive_count": 1,
            "guarantees": [
                {
                    "id": "G-SIG-01", "category": "signature",
                    "summary": "Every verdict is MAC-bound to the intent.",
                    "provided_by": "adapter/verdict_signer.py",
                    "lost_if_disabled": "Facilitator cannot prove origin.",
                    "active": True, "evidence": {"signing_algorithm": "ed25519"},
                    "inactive_reason": "",
                },
                {
                    "id": "G-DEC-01", "category": "decidability",
                    "summary": "Declare-time contradiction detection.",
                    "provided_by": "adapter/tau_compiler.py",
                    "lost_if_disabled": "Inconsistent rules admitted.",
                    "active": True, "evidence": {"fragment": "v1"},
                    "inactive_reason": "",
                },
                {
                    "id": "G-TMP-03", "category": "temporal",
                    "summary": "InstabilityGuard live.",
                    "provided_by": "adapter/self_ref_policy.py::InstabilityGuard",
                    "lost_if_disabled": "Providers that reject keep getting full-amount attempts.",
                    "active": False, "evidence": {},
                    "inactive_reason": "no InstabilityGuard declared",
                },
            ],
        }

    def test_route_returns_200_with_three_columns(self) -> None:
        client, token = self._build({"guarantees": self._canned_response()})
        r = client.get("/ui/guarantees",
                       headers={"Authorization": f"Bearer {token}"})
        assert r.status_code == 200
        body = r.text
        # Three column headings.
        assert "What you get" in body
        assert "What's off" in body
        assert "What you lose if the cage is disabled" in body
        # Guarantee ids render in all three columns (the third lists every
        # entry, so G-SIG-01 should appear at least twice: active + loss).
        assert body.count("G-SIG-01") >= 2
        assert "G-TMP-03" in body
        # Inactive reason renders in the middle column.
        assert "no InstabilityGuard declared" in body

    def test_route_403_without_token(self) -> None:
        client, _ = self._build({"guarantees": self._canned_response()})
        r = client.get("/ui/guarantees")
        assert r.status_code == 403

    def test_empty_catalog_falls_back_to_empty_state(self) -> None:
        client, token = self._build({"guarantees": {
            "verdict": "error", "category": "daemon_unreachable",
            "reason": "connection refused",
        }})
        r = client.get("/ui/guarantees",
                       headers={"Authorization": f"Bearer {token}"})
        # 200 with a banner, per soft-error convention on the dashboard.
        assert r.status_code == 200
        assert "Daemon unreachable" in r.text
