"""Tests for v0.23.0 adaptive-tightening visibility in PaymentDecision.

The brief adds four envelope fields on top of the pre-existing
v0.21.0 tightening fields:

  * ``decay_status``           — {"halflife_seconds", "current_level",
                                    "projected_level_at_plus_60s"}
  * ``tightening_next_action`` — action-oriented hint derived from the
                                    trigger that fired.
  * ``human_explanation``      — plain-English string alongside the
                                    machine-readable envelope.
  * ``revision_context``       — synthesised cross-revision evolution
                                    line.

All four are optional; defaults ``None`` preserve pre-v0.23
envelope wire shape byte-identically.
"""
from __future__ import annotations

import json

import pytest

from adapter.decision_schema import (
    PaymentDecision,
    build_revision_context,
    decay_status_for,
    tightening_next_action_for,
)


class TestDecayStatus:
    """decay_status round-trips + computes the decay projection."""

    def test_none_when_inactive(self) -> None:
        assert decay_status_for(tightening_level=None) is None
        assert decay_status_for(tightening_level=0.0) is None

    def test_populated_when_active(self) -> None:
        status = decay_status_for(
            tightening_level=0.7,
            halflife_seconds=900,
            projection_seconds=60,
        )
        assert status is not None
        assert set(status.keys()) == {
            "halflife_seconds",
            "current_level",
            "projected_level_at_plus_60s",
        }
        assert status["halflife_seconds"] == 900
        assert status["current_level"] == pytest.approx(0.7)
        # After 60s the decay factor is 0.5^(60/900) ~= 0.9555; so the
        # projected level is slightly below 0.7.
        assert status["projected_level_at_plus_60s"] < 0.7
        assert status["projected_level_at_plus_60s"] > 0.6

    def test_projected_level_strictly_decreasing(self) -> None:
        """Test the brief's monotonicity property directly.

        ``projected_level_at_plus_60s`` is a strictly-decreasing
        function of time-since-last-trigger. We model that by passing a
        steadily-decayed ``current_level`` and confirming the projection
        also decreases.
        """
        samples = []
        for elapsed_s in (0, 30, 60, 120, 300, 600, 900):
            # Simulate decay of the CURRENT level as the observation
            # ages. halflife=900s, so level(t) = level0 * 0.5 ^ (t/900).
            decay = 0.5 ** (elapsed_s / 900.0)
            status = decay_status_for(
                tightening_level=0.9 * decay,
                halflife_seconds=900,
                projection_seconds=60,
            )
            assert status is not None
            samples.append(status["projected_level_at_plus_60s"])
        # Strictly monotone decreasing in elapsed-time.
        for a, b in zip(samples, samples[1:]):
            assert a > b, (
                f"projected_level_at_plus_60s is not strictly decreasing: "
                f"{samples}"
            )


class TestTighteningNextAction:
    """tightening_next_action hint derivation."""

    def test_none_when_no_trigger(self) -> None:
        assert tightening_next_action_for(None) is None

    def test_retry_density_maps_to_reduce_retry_rate(self) -> None:
        assert (
            tightening_next_action_for("retry_density")
            == "reduce_retry_rate"
        )
        assert (
            tightening_next_action_for("retry_density_exceeded")
            == "reduce_retry_rate"
        )

    def test_identical_request_maps_to_stop_submitting(self) -> None:
        assert (
            tightening_next_action_for("identical_request")
            == "stop_submitting_identical_intents"
        )
        assert (
            tightening_next_action_for("identical_request_hammering")
            == "stop_submitting_identical_intents"
        )

    def test_velocity_spike_maps_to_slow_spend(self) -> None:
        assert (
            tightening_next_action_for("velocity_spike")
            == "slow_spend_velocity"
        )

    def test_unknown_trigger_falls_back_to_wait_for_cooldown(self) -> None:
        # Fail-safe: unknown triggers still give a safe, non-policy-
        # mutating suggestion.
        assert (
            tightening_next_action_for("never_heard_of_this_one")
            == "wait_for_cooldown"
        )


class TestPaymentDecisionVisibilityFields:
    """Brief Test 3 — every new field populates correctly after a trigger."""

    def _active_decision(self) -> PaymentDecision:
        """Build a PaymentDecision that represents an active clamp."""
        decay = decay_status_for(tightening_level=0.7)
        return PaymentDecision(
            allowed=False,
            reason="adaptive_tightening_triggered",
            tightening_level=0.7,
            adjusted_limits={"max_requests": 3, "cooldown_seconds": 45},
            trigger="retry_density_exceeded",
            prevented_risk={"estimated_spend_blocked_usd": "1200"},
            next_action="wait_for_cooldown",
            decay_status=decay,
            tightening_next_action="reduce_retry_rate",
            human_explanation=(
                "The agent retried this paid request 7 times in 9 seconds. "
                "The system tightened the active policy and blocked further "
                "spend for 45 seconds."
            ),
        )

    def test_all_fields_populated_when_active(self) -> None:
        """Brief Test 3: every tightening-visibility field is present."""
        decision = self._active_decision()
        wire = decision.to_wire()
        for key in (
            "tightening_level",
            "adjusted_limits",
            "trigger",
            "prevented_risk",
            "decay_status",
            "tightening_next_action",
            "human_explanation",
        ):
            assert wire[key] is not None, f"{key} must be populated on active tightening"
        assert wire["tightening_level"] == 0.7
        assert wire["trigger"] == "retry_density_exceeded"
        assert wire["tightening_next_action"] == "reduce_retry_rate"
        assert "retried" in wire["human_explanation"]

    def test_fields_none_when_inactive(self) -> None:
        """Zero-break: a vanilla permit carries ``None`` on every new field."""
        decision = PaymentDecision(allowed=True, reason="allowed")
        wire = decision.to_wire()
        for key in (
            "tightening_level",
            "adjusted_limits",
            "trigger",
            "prevented_risk",
            "decay_status",
            "tightening_next_action",
            "human_explanation",
            "revision_context",
        ):
            assert wire[key] is None, f"{key} must be None on inactive decision"

    def test_wire_round_trip(self) -> None:
        """All new fields survive JSON round-trip unchanged."""
        decision = self._active_decision()
        wire = decision.to_wire()
        js = json.dumps(wire, sort_keys=True)
        parsed = PaymentDecision.from_wire(json.loads(js))
        assert parsed.decay_status is not None
        assert parsed.decay_status["halflife_seconds"] == 900
        assert parsed.tightening_next_action == "reduce_retry_rate"
        assert parsed.human_explanation is not None
        # Byte-identical re-serialisation.
        assert parsed.to_wire() == decision.to_wire()

    def test_from_wire_tolerates_missing_new_fields(self) -> None:
        """Pre-v0.23 wire payloads (no new fields) parse without error."""
        legacy_payload = {
            "allowed": False,
            "reason": "adaptive_tightening_triggered",
            "tightening_level": 0.5,
            "trigger": "velocity_spike",
        }
        parsed = PaymentDecision.from_wire(legacy_payload)
        assert parsed.tightening_level == pytest.approx(0.5)
        assert parsed.decay_status is None
        assert parsed.tightening_next_action is None
        assert parsed.human_explanation is None
        assert parsed.revision_context is None

    def test_from_wire_rejects_non_string_human_explanation(self) -> None:
        """Defensive parsing: bogus types drop to None, never raise."""
        payload = {
            "allowed": False,
            "reason": "adaptive_tightening_triggered",
            "human_explanation": 12345,  # intentionally wrong type
        }
        parsed = PaymentDecision.from_wire(payload)
        assert parsed.human_explanation is None

    def test_from_wire_rejects_non_mapping_decay_status(self) -> None:
        payload = {
            "allowed": False,
            "reason": "adaptive_tightening_triggered",
            "decay_status": "not-a-mapping",
        }
        parsed = PaymentDecision.from_wire(payload)
        assert parsed.decay_status is None
