"""Tests for verdict_signer.py, HMAC signing + intent binding + TTL + replay.

These tests are load-bearing for security findings C-01 and C-02: the whole
pilot story depends on verdicts being authenticatable and replay-resistant.
Patch 8 extends the coverage with v2 envelope provenance binding.
"""

from __future__ import annotations

from decimal import Decimal

import pytest

from adapter.invariants import MaxPerCall
from adapter.payment_intent_matcher import PaymentIntent
from adapter.policy_revision import PolicyRevision
from adapter.verdict_signer import (
    SignatureError,
    SignedEnvelope,
    Verdict,
    VerdictExpired,
    WIRE_VERSION_V1,
    WIRE_VERSION_V2,
    hash_intent,
    sign,
    verify,
)


SECRET = b"test-secret-at-least-16-bytes-long-yes"
OTHER_SECRET = b"different-secret-but-also-16-plus-bytes"


def make_intent(**overrides) -> PaymentIntent:
    base = dict(
        amount=Decimal("50"),
        currency="USDC",
        provider="anthropic",
        counterparty="vendor_x",
        rail="x402",
        timestamp_unix=1713456789,
    )
    base.update(overrides)
    return PaymentIntent(**base)


# ── hash_intent ──────────────────────────────────────────────────────────────


class TestHashIntent:
    def test_deterministic(self) -> None:
        i = make_intent()
        assert hash_intent(i) == hash_intent(i)

    def test_changes_with_amount(self) -> None:
        a = make_intent(amount=Decimal("10"))
        b = make_intent(amount=Decimal("20"))
        assert hash_intent(a) != hash_intent(b)

    def test_changes_with_provider(self) -> None:
        a = make_intent(provider="anthropic")
        b = make_intent(provider="openai")
        assert hash_intent(a) != hash_intent(b)

    def test_metadata_ordering_does_not_matter(self) -> None:
        # sorted internally → same hash regardless of dict insertion order
        a = make_intent(timestamp_unix=1)
        # PaymentIntent metadata is a plain mapping at construction time; post-init
        # it's stored as-is. hash_intent sorts keys internally, so any dict that
        # compares equal produces the same hash.
        i1 = PaymentIntent(**{**{f.name: getattr(a, f.name) for f in a.__dataclass_fields__.values() if f.name != "metadata"}, "metadata": {"x": "1", "y": "2"}})
        i2 = PaymentIntent(**{**{f.name: getattr(a, f.name) for f in a.__dataclass_fields__.values() if f.name != "metadata"}, "metadata": {"y": "2", "x": "1"}})
        assert hash_intent(i1) == hash_intent(i2)


# ── sign / verify round-trip ─────────────────────────────────────────────────


class TestSignVerify:
    def test_round_trip_permit(self) -> None:
        intent = make_intent()
        env = sign(Verdict(outcome="permit"), intent, SECRET, now_unix=1000)
        verify(env, intent, SECRET, now_unix=1000)  # should not raise

    def test_round_trip_reject_with_fields(self) -> None:
        intent = make_intent()
        v = Verdict(
            outcome="reject",
            rule_id="spending_cap_daily",
            witness="cumulative=$1002, cap=$1000",
            reason_text="Daily spending cap of $1000 exceeded.",
        )
        env = sign(v, intent, SECRET, now_unix=2000)
        verify(env, intent, SECRET, now_unix=2000)
        assert env.rule_id == "spending_cap_daily"

    def test_short_secret_rejected(self) -> None:
        with pytest.raises(SignatureError, match="16 bytes"):
            sign(Verdict(outcome="permit"), make_intent(), b"short", now_unix=1)


class TestSecurityProperties:
    """Load-bearing: these tests prove C-01 (no spoof) and C-02 (no replay)."""

    def test_wrong_secret_fails_verify(self) -> None:
        intent = make_intent()
        env = sign(Verdict(outcome="permit"), intent, SECRET, now_unix=1)
        with pytest.raises(SignatureError, match="MAC verification"):
            verify(env, intent, OTHER_SECRET, now_unix=1)

    def test_tampered_outcome_fails_verify(self) -> None:
        """An attacker who flips permit→reject without the secret fails verify."""
        intent = make_intent()
        env = sign(Verdict(outcome="reject", rule_id="r1"), intent, SECRET, now_unix=1)
        # Tampered envelope: flip outcome to permit while keeping original MAC
        tampered = SignedEnvelope(
            outcome="permit",
            rule_id=env.rule_id,
            witness=env.witness,
            reason_text=env.reason_text,
            issued_at_unix=env.issued_at_unix,
            ttl_seconds=env.ttl_seconds,
            intent_hash=env.intent_hash,
            mac_hex=env.mac_hex,
        )
        with pytest.raises(SignatureError, match="MAC verification"):
            verify(tampered, intent, SECRET, now_unix=1)

    def test_replay_against_different_intent_fails(self) -> None:
        """C-02: a permit for intent A cannot be replayed against intent B."""
        intent_a = make_intent(amount=Decimal("10"))
        intent_b = make_intent(amount=Decimal("10000"))
        env = sign(Verdict(outcome="permit"), intent_a, SECRET, now_unix=1)
        # Replay attempt: present env for intent_b (different amount) within TTL
        with pytest.raises(SignatureError, match="intent_hash mismatch"):
            verify(env, intent_b, SECRET, now_unix=1)

    def test_expired_verdict_rejected(self) -> None:
        intent = make_intent()
        env = sign(
            Verdict(outcome="permit", ttl_seconds=30),
            intent,
            SECRET,
            now_unix=1000,
        )
        # Past TTL: 1000 + 30 + 1 = 1031
        with pytest.raises(VerdictExpired):
            verify(env, intent, SECRET, now_unix=1031)

    def test_within_ttl_accepted(self) -> None:
        intent = make_intent()
        env = sign(
            Verdict(outcome="permit", ttl_seconds=30),
            intent,
            SECRET,
            now_unix=1000,
        )
        verify(env, intent, SECRET, now_unix=1029)  # 29s < 30s, still valid


# ── wire serialization ──────────────────────────────────────────────────────


class TestWireSerialization:
    def test_round_trip_via_json(self) -> None:
        intent = make_intent()
        env = sign(
            Verdict(outcome="reject", rule_id="r1", reason_text="blocked"),
            intent,
            SECRET,
            now_unix=1,
        )
        wire = env.to_json()
        parsed = SignedEnvelope.from_json(wire)
        assert parsed == env
        # Verify still works after a round-trip through JSON
        verify(parsed, intent, SECRET, now_unix=1)

    def test_malformed_wire_rejected(self) -> None:
        with pytest.raises(SignatureError, match="valid JSON"):
            SignedEnvelope.from_json("not-json")

    def test_missing_fields_rejected(self) -> None:
        with pytest.raises(SignatureError, match="missing required"):
            SignedEnvelope.from_json('{"outcome":"permit"}')


# ── Patch 8: v2 envelopes with MAC-bound provenance ─────────────────────────


def _revision(
    revision_id: str = "cfg_abc:nonce0",
    proof_backend: str = "tau",
    proof_strength: str = "complete",
    prover_mode: str = "strict",
    compile_hash: str | None = "c" * 64,
) -> PolicyRevision:
    return PolicyRevision(
        revision_id=revision_id,
        invariants=(MaxPerCall(max_amount=Decimal("5")),),
        proof_backend=proof_backend,
        proof_strength=proof_strength,
        prover_mode=prover_mode,
        compile_hash=compile_hash,
        fragment_version="v1",
        tau_backend_version="v8b155d36",
        admitted_at_unix=1,
        predecessor_revision_id=None,
    )


class TestV1BackwardCompatibility:
    def test_sign_without_revision_emits_v1(self) -> None:
        intent = make_intent()
        env = sign(Verdict(outcome="permit"), intent, SECRET, now_unix=1)
        assert env.version == WIRE_VERSION_V1
        assert env.policy_revision_id is None
        assert env.proof_backend is None

    def test_three_arg_signature_still_works(self) -> None:
        """Protects existing `saas/` and `mediate()` callers that never pass
        a revision -- their call site is exactly `sign(v, i, s)`."""
        intent = make_intent()
        env = sign(Verdict(outcome="permit"), intent, SECRET)  # no now_unix, no revision
        assert env.version == WIRE_VERSION_V1
        # round-trips cleanly
        parsed = SignedEnvelope.from_json(env.to_json())
        assert parsed == env

    def test_v1_envelope_from_legacy_payload_without_version_field(self) -> None:
        """A pre-v2 envelope (no `version` key) parses cleanly as v1."""
        intent = make_intent()
        env = sign(Verdict(outcome="permit"), intent, SECRET, now_unix=1000)
        # Strip the version field to simulate a legacy writer.
        import json as _json
        d = _json.loads(env.to_json())
        d.pop("version", None)
        parsed = SignedEnvelope.from_json(_json.dumps(d))
        assert parsed.version == WIRE_VERSION_V1
        verify(parsed, intent, SECRET, now_unix=1000)


class TestV2Provenance:
    def test_sign_with_revision_emits_v2(self) -> None:
        intent = make_intent()
        rev = _revision()
        env = sign(Verdict(outcome="permit"), intent, SECRET, now_unix=1, revision=rev)
        assert env.version == WIRE_VERSION_V2
        assert env.policy_revision_id == rev.revision_id
        assert env.proof_backend == "tau"
        assert env.proof_strength == "complete"
        assert env.prover_mode == "strict"
        assert env.compile_hash == "c" * 64

    def test_v2_round_trip_via_json(self) -> None:
        intent = make_intent()
        rev = _revision()
        env = sign(
            Verdict(outcome="reject", rule_id="spending_cap_daily"),
            intent, SECRET, now_unix=2000, revision=rev,
        )
        parsed = SignedEnvelope.from_json(env.to_json())
        assert parsed == env
        verify(parsed, intent, SECRET, now_unix=2000)

    def test_tampered_revision_id_fails_mac(self) -> None:
        """C-02 extension: provenance is MAC-bound. Tampering any
        provenance field must invalidate the envelope."""
        intent = make_intent()
        rev = _revision()
        env = sign(Verdict(outcome="permit"), intent, SECRET, now_unix=1, revision=rev)
        tampered = SignedEnvelope(
            outcome=env.outcome,
            rule_id=env.rule_id,
            witness=env.witness,
            reason_text=env.reason_text,
            issued_at_unix=env.issued_at_unix,
            ttl_seconds=env.ttl_seconds,
            intent_hash=env.intent_hash,
            mac_hex=env.mac_hex,
            version=env.version,
            policy_revision_id="attacker-forged-id",  # flipped
            proof_backend=env.proof_backend,
            proof_strength=env.proof_strength,
            prover_mode=env.prover_mode,
            compile_hash=env.compile_hash,
        )
        with pytest.raises(SignatureError, match="MAC verification"):
            verify(tampered, intent, SECRET, now_unix=1)

    def test_tampered_proof_strength_fails_mac(self) -> None:
        """An attacker can't downgrade a `pattern` envelope to look like
        `complete` without knowing the secret."""
        intent = make_intent()
        rev = _revision(proof_strength="pattern")
        env = sign(Verdict(outcome="permit"), intent, SECRET, now_unix=1, revision=rev)
        tampered = SignedEnvelope(
            outcome=env.outcome,
            rule_id=env.rule_id,
            witness=env.witness,
            reason_text=env.reason_text,
            issued_at_unix=env.issued_at_unix,
            ttl_seconds=env.ttl_seconds,
            intent_hash=env.intent_hash,
            mac_hex=env.mac_hex,
            version=env.version,
            policy_revision_id=env.policy_revision_id,
            proof_backend=env.proof_backend,
            proof_strength="complete",  # flipped to look stronger
            prover_mode=env.prover_mode,
            compile_hash=env.compile_hash,
        )
        with pytest.raises(SignatureError, match="MAC verification"):
            verify(tampered, intent, SECRET, now_unix=1)

    def test_tampered_prover_mode_fails_mac(self) -> None:
        intent = make_intent()
        rev = _revision(prover_mode="compat")
        env = sign(Verdict(outcome="permit"), intent, SECRET, now_unix=1, revision=rev)
        tampered = SignedEnvelope(
            outcome=env.outcome, rule_id=env.rule_id, witness=env.witness,
            reason_text=env.reason_text, issued_at_unix=env.issued_at_unix,
            ttl_seconds=env.ttl_seconds, intent_hash=env.intent_hash,
            mac_hex=env.mac_hex, version=env.version,
            policy_revision_id=env.policy_revision_id,
            proof_backend=env.proof_backend,
            proof_strength=env.proof_strength,
            prover_mode="strict",  # pretend the cage was in strict mode
            compile_hash=env.compile_hash,
        )
        with pytest.raises(SignatureError, match="MAC verification"):
            verify(tampered, intent, SECRET, now_unix=1)

    def test_v1_and_v2_envelopes_have_different_macs(self) -> None:
        """v2 adds provenance to the MAC input; the MAC must differ from v1
        for the same (verdict, intent)."""
        intent = make_intent()
        rev = _revision()
        v1_env = sign(Verdict(outcome="permit"), intent, SECRET, now_unix=1)
        v2_env = sign(Verdict(outcome="permit"), intent, SECRET, now_unix=1, revision=rev)
        assert v1_env.mac_hex != v2_env.mac_hex


class TestUnsupportedVersion:
    def test_unsupported_version_rejected(self) -> None:
        """Envelopes with a version we don't understand are rejected at parse."""
        bogus = (
            '{"outcome":"permit","issued_at_unix":1,"ttl_seconds":30,'
            '"intent_hash":"x","mac_hex":"y","mac_alg":"HMAC-SHA256","version":"v99"}'
        )
        with pytest.raises(SignatureError, match="unsupported envelope version"):
            SignedEnvelope.from_json(bogus)
