"""Tests for the v0.13.0 safety-comparison mode.

Coverage:
    * ``compare_verdict`` on permit + the three common reject classes.
    * ``aggregate_risk_prevented`` over a mixed history, currency-aware.
    * Daemon op wiring (``safety_comparison`` + ``risk_aggregate``).
    * Envelope header + MAC-bound field round-trip (sign → verify → tamper).
    * CLI ``compare`` and ``risk-prevented`` end-to-end.
    * Web UI ``/ui/safety`` smoke.
    * Acceptance Test 5: SpendingCap($100) + $500 intent → risk_amount=$500.
"""
from __future__ import annotations

import json
import os
import socket
import subprocess
import sys
import tempfile
import threading
import time
from decimal import Decimal
from pathlib import Path
from typing import Iterator

import pytest

from adapter.invariants import (
    MaxPerCall,
    ProviderAllowlist,
    SpendingCap,
)
from adapter.payment_intent_matcher import PaymentIntent
from adapter.safety_comparison import (
    ComparisonReport,
    ProviderRisk,
    RiskAggregate,
    RuleRisk,
    aggregate_risk_prevented,
    compare_verdict,
)
from adapter.verdict_signer import (
    SignatureError,
    SignedEnvelope,
    Verdict,
    sign,
    verify,
)
from adapter.x402_envelope import to_http_headers
from adapter.x402_registry import X402Registry
from daemon.server import CageDaemon


SECRET = b"safety-comparison-test-secret-at-least-16-bytes"


def _intent(
    amount: str = "50.00",
    currency: str = "USDC",
    provider: str = "anthropic",
    counterparty: str = "vendor_a",
    timestamp_unix: int = 1_700_000_000,
) -> PaymentIntent:
    return PaymentIntent(
        amount=Decimal(amount),
        currency=currency,
        provider=provider,
        counterparty=counterparty,
        rail="x402",
        timestamp_unix=timestamp_unix,
    )


# ── compare_verdict ──────────────────────────────────────────────────────────


class TestCompareVerdict:
    def test_permit_on_empty_registry_is_permit_permit(self) -> None:
        report = compare_verdict(_intent(), X402Registry.empty())
        assert report.with_system == "permit"
        assert report.without_system == "permit"
        assert report.risk_reason is None
        assert report.risk_amount is None
        assert report.rule_id is None
        assert report.invariant_class is None

    def test_permit_under_active_registry_is_permit_permit(self) -> None:
        """Intent within limits: both sides permit, risk_reason None."""
        reg = X402Registry.empty().declare(
            SpendingCap(max_amount=Decimal("100"), scope="per_tx")
        )
        report = compare_verdict(_intent(amount="50.00"), reg)
        assert report.with_system == "permit"
        assert report.without_system == "permit"
        assert report.risk_reason is None

    def test_reject_spending_cap_carries_intent_amount(self) -> None:
        """Reject: risk_amount equals the intent amount that would have moved."""
        reg = X402Registry.empty().declare(
            SpendingCap(max_amount=Decimal("100"), scope="per_tx")
        )
        report = compare_verdict(_intent(amount="500.00"), reg)
        assert report.with_system == "reject"
        assert report.without_system == "permit"
        assert report.risk_amount == Decimal("500.00")
        assert report.risk_currency == "USDC"
        assert report.rule_id == "spending_cap_per_tx"
        assert report.invariant_class == "SpendingCap"
        assert "per-transaction cap" in report.risk_reason

    def test_reject_provider_allowlist_names_class(self) -> None:
        reg = X402Registry.empty().declare(
            ProviderAllowlist(providers=frozenset({"trusted-provider"}))
        )
        report = compare_verdict(_intent(provider="anthropic"), reg)
        assert report.with_system == "reject"
        assert report.without_system == "permit"
        assert report.rule_id == "provider_allowlist"
        assert report.invariant_class == "ProviderAllowlist"

    def test_reject_max_per_call_maps_class(self) -> None:
        reg = X402Registry.empty().declare(
            MaxPerCall(max_amount=Decimal("10"))
        )
        report = compare_verdict(_intent(amount="50.00"), reg)
        assert report.with_system == "reject"
        assert report.rule_id == "max_per_call"
        assert report.invariant_class == "MaxPerCall"

    def test_to_wire_serializes_decimal_as_string(self) -> None:
        reg = X402Registry.empty().declare(MaxPerCall(max_amount=Decimal("10")))
        report = compare_verdict(_intent(amount="50.00"), reg)
        wire = report.to_wire()
        assert wire["with_system"] == "reject"
        assert wire["without_system"] == "permit"
        assert wire["risk_amount"] == "50.00"
        assert wire["risk_currency"] == "USDC"
        assert isinstance(wire["risk_amount"], str)


# ── aggregate_risk_prevented ────────────────────────────────────────────────


class TestAggregateRiskPrevented:
    def test_sums_by_currency_and_ranks_providers(self) -> None:
        """Mixed-currency rejects: sum per-currency, rank providers by count."""
        rejects = (
            _intent(amount="500", currency="USDC", provider="p1", timestamp_unix=100),
            _intent(amount="300", currency="USDC", provider="p1", timestamp_unix=110),
            _intent(amount="100", currency="USDT", provider="p2", timestamp_unix=120),
        )
        verdicts = (
            {
                "verdict": "reject", "rule_id": "max_per_call",
                "intent": {"amount": "500", "currency": "USDC",
                           "provider": "p1", "timestamp_unix": 100},
            },
            {
                "verdict": "reject", "rule_id": "max_per_call",
                "intent": {"amount": "300", "currency": "USDC",
                           "provider": "p1", "timestamp_unix": 110},
            },
            {
                "verdict": "reject", "rule_id": "provider_allowlist",
                "intent": {"amount": "100", "currency": "USDT",
                           "provider": "p2", "timestamp_unix": 120},
            },
        )
        agg = aggregate_risk_prevented(
            history=(), rejects=rejects, verdicts=verdicts,
            window_seconds=0,
        )
        assert agg.prevented_count == 3
        assert agg.prevented_value_by_currency["USDC"] == Decimal("800")
        assert agg.prevented_value_by_currency["USDT"] == Decimal("100")
        # p1 has 2 rejects, so it comes first
        assert agg.top_providers[0].provider == "p1"
        assert agg.top_providers[0].count == 2
        # rules ranking from the verdict stream
        rule_ids = {r.rule_id for r in agg.top_rules}
        assert "max_per_call" in rule_ids
        assert "provider_allowlist" in rule_ids

    def test_window_filter_excludes_old_entries(self) -> None:
        """Entries older than window are dropped."""
        rejects = (
            _intent(amount="100", timestamp_unix=100),
            _intent(amount="200", timestamp_unix=1000),
        )
        agg = aggregate_risk_prevented(
            history=(), rejects=rejects, verdicts=(),
            window_seconds=500, now_unix=1000,
        )
        # Only the newer entry (timestamp 1000) falls inside the window
        assert agg.prevented_count == 1
        assert agg.prevented_value_by_currency["USDC"] == Decimal("200")

    def test_top_n_caps_list_size(self) -> None:
        rejects = tuple(
            _intent(amount="1", provider=f"p{i}", counterparty=f"cp{i}",
                    timestamp_unix=100 + i)
            for i in range(10)
        )
        agg = aggregate_risk_prevented(
            history=(), rejects=rejects, verdicts=(), top_n=3,
        )
        assert len(agg.top_providers) == 3

    def test_empty_rejects_returns_zeroes(self) -> None:
        agg = aggregate_risk_prevented(history=(), rejects=(), verdicts=())
        assert agg.prevented_count == 0
        assert agg.prevented_value_by_currency == {}
        assert agg.top_providers == ()
        assert agg.top_rules == ()

    def test_to_wire_is_json_safe(self) -> None:
        rejects = (_intent(amount="10"),)
        agg = aggregate_risk_prevented(history=(), rejects=rejects, verdicts=())
        wire = agg.to_wire()
        # JSON round-trip must succeed
        json.dumps(wire)
        assert wire["prevented_value_by_currency"]["USDC"] == "10"


# ── daemon op wiring ────────────────────────────────────────────────────────


@pytest.fixture
def daemon() -> Iterator[tuple[CageDaemon, str]]:
    fd, path = tempfile.mkstemp(prefix="safety-", suffix=".sock", dir="/tmp")
    os.close(fd)
    os.unlink(path)
    d = CageDaemon(socket_path=path)
    t = threading.Thread(target=d.serve_forever, daemon=True)
    t.start()
    for _ in range(50):
        if os.path.exists(path):
            break
        time.sleep(0.01)
    try:
        yield d, path
    finally:
        d.shutdown()
        t.join(timeout=1.0)


def _send(path: str, request: dict) -> dict:
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.settimeout(2.0)
    s.connect(path)
    try:
        s.sendall((json.dumps(request) + "\n").encode("utf-8"))
        f = s.makefile("r")
        line = f.readline()
    finally:
        s.close()
    return json.loads(line)


class TestDaemonSafetyComparison:
    def test_safety_comparison_op_round_trip_permit(self, daemon) -> None:
        _, path = daemon
        # No invariants: permit, permit.
        r = _send(path, {
            "op": "safety_comparison",
            "intent": {
                "amount": "10", "currency": "USDC",
                "provider": "anthropic", "counterparty": "v",
                "rail": "x402", "timestamp_unix": 1_700_000_000,
                "metadata": {}, "request_id": None,
            },
        })
        assert r["verdict"] == "ok"
        report = r["report"]
        assert report["with_system"] == "permit"
        assert report["without_system"] == "permit"

    def test_safety_comparison_op_round_trip_reject(self, daemon) -> None:
        _, path = daemon
        _send(path, {
            "op": "declare_x402", "kind": "spending_cap",
            "max_amount": "100", "scope": "per_tx",
        })
        r = _send(path, {
            "op": "safety_comparison",
            "intent": {
                "amount": "500", "currency": "USDC",
                "provider": "anthropic", "counterparty": "v",
                "rail": "x402", "timestamp_unix": 1_700_000_000,
                "metadata": {}, "request_id": None,
            },
        })
        assert r["verdict"] == "ok"
        report = r["report"]
        assert report["with_system"] == "reject"
        assert report["without_system"] == "permit"
        assert report["risk_amount"] == "500"
        assert report["rule_id"] == "spending_cap_per_tx"
        assert report["invariant_class"] == "SpendingCap"

    def test_safety_comparison_missing_intent_returns_error(self, daemon) -> None:
        _, path = daemon
        r = _send(path, {"op": "safety_comparison"})
        assert r["verdict"] == "error"
        assert r["category"] == "bad_payload"

    def test_risk_aggregate_op_round_trip(self, daemon) -> None:
        _, path = daemon
        _send(path, {
            "op": "declare_x402", "kind": "spending_cap",
            "max_amount": "100", "scope": "per_tx",
        })
        # Drive a couple of rejects through.
        for amt in ("200", "300"):
            _send(path, {
                "op": "check_payment",
                "intent": {
                    "amount": amt, "currency": "USDC",
                    "provider": "anthropic", "counterparty": "v",
                    "rail": "x402", "timestamp_unix": 1_700_000_000,
                    "metadata": {}, "request_id": None,
                },
            })
        r = _send(path, {"op": "risk_aggregate", "window_seconds": 0})
        assert r["verdict"] == "ok"
        agg = r["aggregate"]
        assert agg["prevented_count"] == 2
        assert agg["prevented_value_by_currency"]["USDC"] == "500"

    def test_check_payment_response_includes_without_system(self, daemon) -> None:
        """The /v1/check hot path returns without_system on every response."""
        _, path = daemon
        _send(path, {
            "op": "declare_x402", "kind": "spending_cap",
            "max_amount": "100", "scope": "per_tx",
        })
        # Reject path
        r = _send(path, {
            "op": "check_payment",
            "intent": {
                "amount": "500", "currency": "USDC",
                "provider": "anthropic", "counterparty": "v",
                "rail": "x402", "timestamp_unix": 1_700_000_000,
                "metadata": {}, "request_id": None,
            },
        })
        assert r["verdict"] == "reject"
        assert r["without_system"] == "permit"
        # Permit path
        r2 = _send(path, {
            "op": "check_payment",
            "intent": {
                "amount": "50", "currency": "USDC",
                "provider": "anthropic", "counterparty": "v",
                "rail": "x402", "timestamp_unix": 1_700_000_001,
                "metadata": {}, "request_id": None,
            },
        })
        assert r2["verdict"] == "permit"
        assert r2["without_system"] == "permit"


# ── envelope header + MAC-bound field ───────────────────────────────────────


class TestEnvelopeWithoutSystem:
    def _env(self, without_system: str = "permit") -> tuple[SignedEnvelope, PaymentIntent]:
        intent = _intent(amount="500")
        v = Verdict(
            outcome="reject",
            rule_id="spending_cap_per_tx",
            reason_text="cap exceeded",
            ttl_seconds=30,
        )
        env = sign(v, intent, SECRET, now_unix=1_700_000_000,
                   without_system=without_system)
        return env, intent

    def test_header_x_policy_without_system_present(self) -> None:
        env, _ = self._env("permit")
        headers = to_http_headers(env)
        assert headers["X-Policy-Without-System"] == "permit"

    def test_envelope_round_trip_preserves_without_system(self) -> None:
        env, intent = self._env("permit")
        wire = env.to_json()
        parsed = SignedEnvelope.from_json(wire)
        assert parsed.without_system == "permit"
        # MAC verifies clean.
        verify(parsed, intent, SECRET, now_unix=1_700_000_000)

    def test_signing_without_system_promotes_to_v2(self) -> None:
        env, _ = self._env("permit")
        assert env.version == "v2"

    def test_tamper_of_without_system_breaks_verify(self) -> None:
        """Critical: the MAC must cover without_system or the claim is a lie."""
        env, intent = self._env("permit")
        # Flip the claim on a copy while keeping the same MAC.
        import dataclasses
        tampered = dataclasses.replace(env, without_system="reject")
        with pytest.raises(SignatureError):
            verify(tampered, intent, SECRET, now_unix=1_700_000_000)

    def test_v1_envelope_unchanged_when_without_system_absent(self) -> None:
        """Back-compat: sign() without the comparison arg stays v1."""
        intent = _intent(amount="500")
        v = Verdict(outcome="reject", rule_id="max_per_call", ttl_seconds=30)
        env = sign(v, intent, SECRET, now_unix=1_700_000_000)
        assert env.version == "v1"
        assert env.without_system is None
        headers = to_http_headers(env)
        assert "X-Policy-Without-System" not in headers


# ── CLI end-to-end ──────────────────────────────────────────────────────────


class TestCLICompare:
    def test_compare_rejects_intent_over_cap(self, daemon, tmp_path: Path) -> None:
        _, path = daemon
        _send(path, {
            "op": "declare_x402", "kind": "spending_cap",
            "max_amount": "100", "scope": "per_tx",
        })
        intent_path = tmp_path / "intent.json"
        intent_path.write_text(json.dumps({
            "amount": "500", "currency": "USDC",
            "provider": "anthropic", "counterparty": "v",
            "rail": "x402", "timestamp_unix": 1_700_000_000,
            "metadata": {}, "request_id": None,
        }))
        cp = subprocess.run(
            [
                sys.executable, "-m", "daemon.cli", "compare",
                "--intent", str(intent_path),
                "--socket", path,
                "--format", "json",
            ],
            capture_output=True, text=True, timeout=10,
        )
        assert cp.returncode == 0, cp.stderr
        report = json.loads(cp.stdout)
        assert report["with_system"] == "reject"
        assert report["without_system"] == "permit"
        assert report["risk_amount"] == "500"

    def test_compare_text_format_prints_key_fields(self, daemon, tmp_path: Path) -> None:
        _, path = daemon
        intent_path = tmp_path / "intent.json"
        intent_path.write_text(json.dumps({
            "amount": "10", "currency": "USDC",
            "provider": "anthropic", "counterparty": "v",
            "rail": "x402", "timestamp_unix": 1_700_000_000,
        }))
        cp = subprocess.run(
            [
                sys.executable, "-m", "daemon.cli", "compare",
                "--intent", str(intent_path),
                "--socket", path,
            ],
            capture_output=True, text=True, timeout=10,
        )
        assert cp.returncode == 0, cp.stderr
        assert "with_system:" in cp.stdout
        assert "without_system:" in cp.stdout


class TestCLIRiskPrevented:
    def test_risk_prevented_returns_valid_json(self, daemon) -> None:
        _, path = daemon
        _send(path, {
            "op": "declare_x402", "kind": "max_per_call", "max_amount": "10",
        })
        _send(path, {
            "op": "check_payment",
            "intent": {
                "amount": "50", "currency": "USDC",
                "provider": "anthropic", "counterparty": "v",
                "rail": "x402", "timestamp_unix": 1_700_000_000,
                "metadata": {}, "request_id": None,
            },
        })
        cp = subprocess.run(
            [
                sys.executable, "-m", "daemon.cli", "risk-prevented",
                "--window", "3600", "--format", "json",
                "--socket", path,
            ],
            capture_output=True, text=True, timeout=10,
        )
        assert cp.returncode == 0, cp.stderr
        data = json.loads(cp.stdout)
        assert data["prevented_count"] >= 1
        assert "prevented_value_by_currency" in data

    def test_window_spec_parses_units(self, daemon) -> None:
        """``24h`` / ``7d`` / ``3600s`` / raw int all work."""
        from daemon.cli import _parse_window
        assert _parse_window("24h") == 86400
        assert _parse_window("3600") == 3600
        assert _parse_window("7d") == 7 * 86400
        assert _parse_window("5m") == 300
        assert _parse_window("0") == 0


# ── Web UI ───────────────────────────────────────────────────────────────────


class TestWebUI:
    def test_safety_route_returns_html_with_sections(self) -> None:
        pytest.importorskip("fastapi")
        pytest.importorskip("jinja2")
        from fastapi import FastAPI
        from fastapi.testclient import TestClient
        from saas.web_ui.routes import build_router, mount_static_on
        from tests.test_web_ui import StubReader

        token = "sk_test_safety_ui"
        reader = StubReader({
            "risk_aggregate": {
                "verdict": "ok",
                "aggregate": {
                    "window_seconds": 86400,
                    "prevented_count": 3,
                    "prevented_value_by_currency": {"USDC": "1500.00"},
                    "top_providers": [
                        {"provider": "p1", "count": 2,
                         "value_by_currency": {"USDC": "1000.00"}},
                    ],
                    "top_rules": [
                        {"rule_id": "spending_cap_per_tx", "count": 3,
                         "value_by_currency": {"USDC": "1500.00"}},
                    ],
                    "now_unix": 1_700_000_000,
                },
            },
        })
        app = FastAPI()
        app.include_router(
            build_router(reader=reader, token=token), prefix="/ui",
        )
        mount_static_on(app)
        client = TestClient(app)
        r = client.get("/ui/safety",
                       headers={"Authorization": f"Bearer {token}"})
        assert r.status_code == 200
        body = r.text
        assert "What would have spent without us" in body
        assert "Top providers by prevented risk" in body
        assert "Top rules by firing count" in body
        assert "p1" in body
        assert "spending_cap_per_tx" in body
        assert "1500.00" in body


# ── Acceptance Test 5 ───────────────────────────────────────────────────────


class TestAcceptanceTest5:
    def test_spending_cap_100_and_500_intent_returns_expected_report(
        self, daemon, tmp_path: Path,
    ) -> None:
        """From the spec:
        set up a policy with SpendingCap($100); submit a $500 intent;
        run `compare`; get
        {with_system: reject, without_system: permit, risk_amount: $500}.
        """
        _, path = daemon
        # Policy: SpendingCap($100) per-transaction.
        r = _send(path, {
            "op": "declare_x402", "kind": "spending_cap",
            "max_amount": "100", "scope": "per_tx",
        })
        # The declare path returns "updated" on successful admission;
        # "error" is the only bad shape we need to guard against here.
        assert r["verdict"] != "error"

        # Intent: $500.
        intent_path = tmp_path / "intent.json"
        intent_path.write_text(json.dumps({
            "amount": "500", "currency": "USDC",
            "provider": "anthropic", "counterparty": "v",
            "rail": "x402", "timestamp_unix": 1_700_000_000,
            "metadata": {}, "request_id": None,
        }))

        # Run compare via the CLI so the acceptance test exercises the
        # full wire path (CLI → UDS → daemon op → response).
        cp = subprocess.run(
            [
                sys.executable, "-m", "daemon.cli", "compare",
                "--intent", str(intent_path),
                "--socket", path,
                "--format", "json",
            ],
            capture_output=True, text=True, timeout=10,
        )
        assert cp.returncode == 0, cp.stderr
        report = json.loads(cp.stdout)
        assert report["with_system"] == "reject"
        assert report["without_system"] == "permit"
        assert report["risk_amount"] == "500"
        assert report["risk_currency"] == "USDC"
