"""Integration tests for the ``should_pay_x402`` daemon op (v0.17.0).

Spin up a real CageDaemon on a short UDS path, drive it via
JSON-over-UDS, assert the PaymentDecision wire shape.
"""
from __future__ import annotations

import json
import os
import socket
import tempfile
import threading
import time
from decimal import Decimal
from typing import Iterator

import pytest

from adapter.cage_mode import CageMode
from adapter.decision_schema import PaymentDecision
from daemon.server import CageDaemon


BASE_TS = 1_700_000_000


@pytest.fixture
def daemon() -> Iterator[tuple[CageDaemon, str]]:
    fd, path = tempfile.mkstemp(prefix="x402-should-", suffix=".sock", dir="/tmp")
    os.close(fd)
    os.unlink(path)

    d = CageDaemon(socket_path=path)
    t = threading.Thread(target=d.serve_forever, daemon=True)
    t.start()
    for _ in range(100):
        if os.path.exists(path):
            break
        time.sleep(0.01)
    try:
        yield d, path
    finally:
        d.shutdown()
        t.join(timeout=1.0)


@pytest.fixture
def shadow_daemon() -> Iterator[tuple[CageDaemon, str]]:
    fd, path = tempfile.mkstemp(prefix="x402-shadow-", suffix=".sock", dir="/tmp")
    os.close(fd)
    os.unlink(path)

    d = CageDaemon(socket_path=path, cage_mode=CageMode.SHADOW)
    t = threading.Thread(target=d.serve_forever, daemon=True)
    t.start()
    for _ in range(100):
        if os.path.exists(path):
            break
        time.sleep(0.01)
    try:
        yield d, path
    finally:
        d.shutdown()
        t.join(timeout=1.0)


def _send(path: str, request: dict) -> dict:
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.settimeout(2.0)
    s.connect(path)
    try:
        s.sendall((json.dumps(request) + "\n").encode("utf-8"))
        f = s.makefile("r")
        line = f.readline()
    finally:
        s.close()
    return json.loads(line)


def _intent(
    amount: str = "50",
    provider: str = "anthropic",
    counterparty: str = "vendor_x",
    timestamp_unix: int = BASE_TS,
) -> dict:
    return {
        "amount": amount,
        "currency": "USDC",
        "provider": provider,
        "counterparty": counterparty,
        "rail": "x402",
        "timestamp_unix": timestamp_unix,
        "metadata": {},
        "request_id": None,
    }


# ── permit path ─────────────────────────────────────────────────────────────


class TestPermitPath:
    def test_empty_registry_permits(self, daemon) -> None:
        _, path = daemon
        r = _send(path, {"op": "should_pay_x402", "intent": _intent()})
        assert r["verdict"] == "ok"
        d = r["decision"]
        assert d["allowed"] is True
        assert d["reason"] == "allowed"
        assert d["rule_id"] is None
        assert d["next_action"] == "proceed"
        assert d["cage_mode"] == "enforce"
        assert d["risk_prevented"] is None

    def test_permit_under_cap(self, daemon) -> None:
        _, path = daemon
        _send(path, {"op": "declare_x402", "kind": "max_per_call", "max_amount": "100"})
        r = _send(path, {"op": "should_pay_x402", "intent": _intent(amount="50")})
        d = r["decision"]
        assert d["allowed"] is True
        assert d["reason"] == "allowed"
        assert d["next_action"] == "proceed"

    def test_permit_is_payment_decision_shape(self, daemon) -> None:
        """The decision dict must round-trip through PaymentDecision.from_wire."""
        _, path = daemon
        r = _send(path, {"op": "should_pay_x402", "intent": _intent()})
        pd = PaymentDecision.from_wire(r["decision"])
        assert pd.allowed is True
        assert pd.reason == "allowed"


# ── deny paths ──────────────────────────────────────────────────────────────


class TestSpendingCapDeny:
    def test_max_per_call_deny(self, daemon) -> None:
        _, path = daemon
        _send(path, {"op": "declare_x402", "kind": "max_per_call", "max_amount": "10"})
        r = _send(path, {"op": "should_pay_x402", "intent": _intent(amount="50")})
        assert r["verdict"] == "ok"
        d = r["decision"]
        assert d["allowed"] is False
        assert d["reason"] == "spend_cap_exceeded"
        assert d["rule_id"] == "max_per_call"
        # retry_after_seconds is None for cap exceed (no natural retry hint).
        assert d["retry_after_seconds"] is None
        assert d["next_action"] == "adjust_policy"
        # risk_prevented is populated on deny.
        assert d["risk_prevented"] is not None
        assert d["risk_prevented"]["estimated_extra_spend_blocked"] == "50"
        assert d["risk_prevented"]["currency"] == "USDC"
        assert d["risk_prevented"]["source"] == "spend_velocity"


class TestRetryRateLimitDeny:
    def test_retry_rate_limit_populates_retry_after(self, daemon) -> None:
        _, path = daemon
        # Declare an allowlist so the first call rejects, seeding the
        # retry history. Then within the gap window, attempt the same
        # pair and expect retry_rate_limit to fire with a retry_after.
        _send(
            path,
            {
                "op": "declare_x402",
                "kind": "provider_allowlist",
                "providers": ["allowed_only"],
            },
        )
        _send(
            path,
            {
                "op": "declare_x402",
                "kind": "retry_rate_limit",
                "min_gap_seconds": 10,
            },
        )
        # First call rejects via provider_allowlist (seeds rejects stream).
        r1 = _send(
            path,
            {
                "op": "should_pay_x402",
                "intent": _intent(
                    provider="sketchy", counterparty="v", timestamp_unix=BASE_TS,
                ),
            },
        )
        assert r1["decision"]["reason"] == "provider_not_allowed"
        # Second call 3s later — retry gap below 10s — should now trip
        # retry_rate_limit on the (provider=sketchy, counterparty=v) pair.
        r2 = _send(
            path,
            {
                "op": "should_pay_x402",
                "intent": _intent(
                    provider="sketchy", counterparty="v",
                    timestamp_unix=BASE_TS + 3,
                ),
            },
        )
        d = r2["decision"]
        assert d["allowed"] is False
        assert d["reason"] in ("retry_loop_detected", "provider_not_allowed")
        if d["reason"] == "retry_loop_detected":
            assert d["rule_id"] == "retry_rate_limit"
            # 10s gap - 3s since first reject = 7 seconds remaining.
            assert d["retry_after_seconds"] == 7
            assert d["next_action"] == "wait_for_cooldown"


class TestInstabilityGuardDeny:
    def test_instability_guard_tightened(self, daemon) -> None:
        _, path = daemon
        # Seed three rejects so the guard activates.
        _send(
            path,
            {
                "op": "declare_x402",
                "kind": "provider_allowlist",
                "providers": ["good_only"],
            },
        )
        _send(
            path,
            {
                "op": "declare_x402",
                "kind": "instability_guard",
                "provider": "risky",
                "reject_threshold": 2,
                "window_seconds": 300,
                "tighten_to": "10",
                "recovery_seconds": 120,
                "currency": "USDC",
            },
        )
        # Two rejects against 'risky' to arm the guard.
        for i in range(2):
            _send(
                path,
                {
                    "op": "should_pay_x402",
                    "intent": _intent(
                        provider="risky", counterparty="v",
                        timestamp_unix=BASE_TS + i,
                    ),
                },
            )
        # Now a 'risky' payment for more than tighten_to=10 should be
        # tightened via the guard.
        r = _send(
            path,
            {
                "op": "should_pay_x402",
                "intent": _intent(
                    amount="100",
                    provider="risky",
                    counterparty="v",
                    timestamp_unix=BASE_TS + 3,
                ),
            },
        )
        d = r["decision"]
        assert d["allowed"] is False
        # Might be provider_allowlist OR instability_guard_tightened
        # depending on order — the guard runs after the allowlist.
        assert d["reason"] in (
            "instability_guard_tightened",
            "provider_not_allowed",
        )


# ── shadow mode ─────────────────────────────────────────────────────────────


class TestShadowMode:
    def test_shadow_deny_permits_on_wire_but_populates_risk_prevented(
        self, shadow_daemon,
    ) -> None:
        _, path = shadow_daemon
        _send(path, {"op": "declare_x402", "kind": "max_per_call", "max_amount": "10"})
        r = _send(path, {"op": "should_pay_x402", "intent": _intent(amount="50")})
        d = r["decision"]
        # Wire allowed stays true in shadow.
        assert d["allowed"] is True
        # reason stays "allowed" (wire truth); but next_action reflects
        # the shadow-reject's underlying action.
        assert d["reason"] == "allowed"
        assert d["cage_mode"] == "shadow"
        # The underlying rule_id the daemon would have rejected on is
        # surfaced so the agent can read it.
        assert d["rule_id"] == "max_per_call"
        # Risk prevented captures the shadow-would-reject amount.
        assert d["risk_prevented"] is not None
        assert d["risk_prevented"]["estimated_extra_spend_blocked"] == "50"
        # next_action should be the shadow-reject's action, not proceed.
        assert d["next_action"] in ("adjust_policy", "proceed")


# ── malformed / fail-closed ─────────────────────────────────────────────────


class TestFailClosed:
    def test_malformed_intent_returns_fail_closed_decision(self, daemon) -> None:
        _, path = daemon
        r = _send(path, {"op": "should_pay_x402", "intent": "not a dict"})
        assert r["verdict"] == "ok"
        d = r["decision"]
        assert d["allowed"] is False
        # Malformed → policy_inconclusive (no opinion formed).
        assert d["reason"] == "policy_inconclusive"
        assert d["next_action"] == "abort"

    def test_invalid_payment_intent_returns_fail_closed_decision(self, daemon) -> None:
        _, path = daemon
        r = _send(
            path,
            {
                "op": "should_pay_x402",
                "intent": {
                    "amount": "1",
                    "currency": "USDC",
                    "provider": "has spaces",  # fails safe-token schema
                    "counterparty": "v",
                    "rail": "x402",
                    "timestamp_unix": BASE_TS,
                    "metadata": {},
                    "request_id": None,
                },
            },
        )
        assert r["verdict"] == "ok"
        d = r["decision"]
        assert d["allowed"] is False
        assert d["reason"] == "policy_inconclusive"
        assert d["next_action"] == "abort"


# ── round-trip via client SDK shape ─────────────────────────────────────────


class TestClientSdkRoundTrip:
    def test_full_response_is_json_serialisable(self, daemon) -> None:
        _, path = daemon
        _send(path, {"op": "declare_x402", "kind": "max_per_call", "max_amount": "10"})
        r = _send(path, {"op": "should_pay_x402", "intent": _intent(amount="50")})
        # Full re-serialisation round trip — guards against unicode /
        # Decimal leaks in the wire shape.
        assert json.loads(json.dumps(r)) == r

    def test_payment_decision_from_wire_round_trip(self, daemon) -> None:
        _, path = daemon
        _send(path, {"op": "declare_x402", "kind": "max_per_call", "max_amount": "10"})
        r = _send(path, {"op": "should_pay_x402", "intent": _intent(amount="50")})
        pd = PaymentDecision.from_wire(r["decision"])
        assert pd.allowed is False
        assert pd.reason == "spend_cap_exceeded"
        assert pd.rule_id == "max_per_call"
        assert pd.next_action == "adjust_policy"
        assert pd.risk_prevented is not None
        assert pd.risk_prevented.estimated_extra_spend_blocked == Decimal("50")
