"""Tests for v0.21.0 bank-mode envelope alignment (Part C of the brief).

Covers:

* Every :class:`PaymentDecision` (Flexible Mode) carries
  ``prover_mode`` (default ``"flexible"``), ``proof_backend`` (already
  existed, now always present in ``to_wire``), and ``guarantee_flag``
  (default ``False``).
* Every :class:`GuaranteedDecision` (Guaranteed Mode) carries the same
  three fields with the guaranteed-mode defaults: ``prover_mode ==
  "guaranteed"``, ``guarantee_flag == True`` iff the decision allowed,
  ``proof_backend`` populated on allow.
* Back-compat on the ``mode`` field of PaymentDecision — the new
  ``prover_mode`` is additive, not a rename.
* The ``from_wire`` parser defaults ``prover_mode`` to the value of
  ``mode`` when ``prover_mode`` is missing from a legacy payload.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone

from adapter.decision_schema import PaymentDecision
from adapter.guaranteed_runtime import GuaranteedDecision


class TestFlexibleEnvelope:
    def test_default_paymentdecision_has_flexible_provenance(self) -> None:
        d = PaymentDecision(allowed=True, reason="allowed")
        wire = d.to_wire()
        assert wire["prover_mode"] == "flexible"
        assert wire["guarantee_flag"] is False
        # proof_backend is optional on flexible decisions — defaults to None.
        assert wire["proof_backend"] is None

    def test_explicit_prover_mode_overrides_default(self) -> None:
        d = PaymentDecision(
            allowed=True,
            reason="allowed",
            prover_mode="guaranteed",
            proof_backend="tau-0.8",
            guarantee_flag=True,
        )
        wire = d.to_wire()
        assert wire["prover_mode"] == "guaranteed"
        assert wire["proof_backend"] == "tau-0.8"
        assert wire["guarantee_flag"] is True

    def test_mode_field_preserved_for_backcompat(self) -> None:
        """``mode`` is still a thing — the new ``prover_mode`` is additive."""
        d = PaymentDecision(allowed=True, reason="allowed")
        wire = d.to_wire()
        assert "mode" in wire
        assert wire["mode"] == "flexible"
        assert "prover_mode" in wire

    def test_from_wire_defaults_prover_mode_to_mode(self) -> None:
        """Legacy payload missing ``prover_mode`` reads back safely."""
        legacy = {
            "allowed": True,
            "reason": "allowed",
            "mode": "flexible",
            # prover_mode absent
        }
        restored = PaymentDecision.from_wire(legacy)
        assert restored.prover_mode == "flexible"
        assert restored.guarantee_flag is False


class TestGuaranteedEnvelope:
    """Guaranteed Mode's decision envelope carries symmetric provenance."""

    def _build_allow(self) -> GuaranteedDecision:
        return GuaranteedDecision(
            allow=True,
            mode="guaranteed",
            policy_revision_id="rev_1",
            proof_artifact_id="artifact_1",
            proof_artifact_hash="abcd" * 8,
            runtime_guard_state_version="efef" * 8,
            reason=None,
            explanation="ok",
            decision_id="id-1",
            decision_timestamp=datetime(2026, 4, 19, tzinfo=timezone.utc),
        )

    def _build_deny(self) -> GuaranteedDecision:
        return GuaranteedDecision(
            allow=False,
            mode="guaranteed",
            policy_revision_id="rev_1",
            proof_artifact_id="artifact_1",
            proof_artifact_hash="abcd" * 8,
            runtime_guard_state_version="efef" * 8,
            reason="RUNTIME_GUARD_VIOLATION",
            explanation="denied",
            decision_id="id-2",
            decision_timestamp=datetime(2026, 4, 19, tzinfo=timezone.utc),
        )

    def test_allow_wire_carries_prover_mode(self) -> None:
        wire = self._build_allow().to_wire()
        assert wire["prover_mode"] == "guaranteed"
        assert wire["guarantee_flag"] is True
        assert wire["proof_backend"] == "guaranteed-proof"

    def test_deny_wire_omits_guarantee_flag(self) -> None:
        """A deny has no bound proof → guarantee_flag is False."""
        wire = self._build_deny().to_wire()
        assert wire["prover_mode"] == "guaranteed"
        assert wire["guarantee_flag"] is False
        assert wire["proof_backend"] is None

    def test_guaranteed_and_flexible_share_provenance_keys(self) -> None:
        """A dashboard consuming both tiers sees the same three keys."""
        flex = PaymentDecision(allowed=True, reason="allowed").to_wire()
        guar = self._build_allow().to_wire()
        for key in ("prover_mode", "proof_backend", "guarantee_flag"):
            assert key in flex, f"flexible missing {key}"
            assert key in guar, f"guaranteed missing {key}"
