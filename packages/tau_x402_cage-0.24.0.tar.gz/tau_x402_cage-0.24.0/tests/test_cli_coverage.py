"""CLI direct-invocation tests to close coverage.

The existing ``test_cli.py`` relies on subprocess execution which bypasses
coverage instrumentation. These tests call ``daemon.cli`` functions
directly with synthetic ``argparse.Namespace`` objects so coverage counts
the CLI dispatch paths.

Focus is on subcommands whose "daemon unreachable" branch is deterministic
(every subcommand that calls ``_send_op`` returns 2 on socket errors) plus
the pure-offline paths (``lint``, ``keygen-ed25519``, ``audit-verify``
error branches).
"""
from __future__ import annotations

import argparse
import io
import json
import os
import sys
from pathlib import Path
from typing import Any

import pytest

from daemon import cli


# ── helpers ──────────────────────────────────────────────────────────────────


def _ns(**kwargs: Any) -> argparse.Namespace:
    return argparse.Namespace(**kwargs)


@pytest.fixture
def unreachable_socket(tmp_path: Path) -> str:
    """A socket path that will never resolve — triggers ConnectionRefused."""
    return str(tmp_path / "nope.sock")


# ── subcommand dispatch: daemon-unreachable paths ────────────────────────────


class TestDaemonUnreachableExit2:
    """Every daemon-talking subcommand exits 2 when no daemon is listening."""

    def test_inspect(self, unreachable_socket: str) -> None:
        rc = cli._cmd_inspect(_ns(socket=unreachable_socket))
        assert rc == 2

    def test_explain_no_policy(self, unreachable_socket: str) -> None:
        rc = cli._cmd_explain(_ns(socket=unreachable_socket, policy=None))
        assert rc == 2

    def test_explain_with_missing_policy(
        self, unreachable_socket: str, tmp_path: Path
    ) -> None:
        rc = cli._cmd_explain(
            _ns(socket=unreachable_socket, policy=str(tmp_path / "nope.yaml"))
        )
        assert rc == 2

    def test_diff(self, unreachable_socket: str) -> None:
        rc = cli._cmd_diff(
            _ns(socket=unreachable_socket, revision_a="r1", revision_b="r2", fmt="text")
        )
        assert rc == 2

    def test_branch_list(self, unreachable_socket: str) -> None:
        rc = cli._branch_list(_ns(socket=unreachable_socket))
        assert rc == 2

    def test_branch_create(self, unreachable_socket: str) -> None:
        rc = cli._branch_create(
            _ns(socket=unreachable_socket, name="feature/x",
                from_revision=None, created_by=None)
        )
        assert rc == 2

    def test_branch_checkout(self, unreachable_socket: str) -> None:
        rc = cli._branch_checkout(_ns(socket=unreachable_socket, name="main"))
        assert rc == 2

    def test_branch_merge(self, unreachable_socket: str) -> None:
        rc = cli._branch_merge(
            _ns(socket=unreachable_socket, src="b", into="main",
                reviewer="r", json=False)
        )
        assert rc == 2

    def test_branch_missing_action(self, unreachable_socket: str) -> None:
        rc = cli._cmd_branch(_ns(socket=unreachable_socket, branch_action=None))
        assert rc == 2

    def test_propose_with_missing_policy(
        self, unreachable_socket: str, tmp_path: Path
    ) -> None:
        rc = cli._cmd_propose(
            _ns(socket=unreachable_socket, policy=str(tmp_path / "nope.yaml"),
                submitted_by="alice")
        )
        assert rc == 2

    def test_propose_empty_policy(
        self, unreachable_socket: str, tmp_path: Path
    ) -> None:
        p = tmp_path / "empty.yaml"
        p.write_text("version: 1\npolicy: []\n")
        rc = cli._cmd_propose(
            _ns(socket=unreachable_socket, policy=str(p), submitted_by="alice")
        )
        assert rc == 2

    def test_proposals_unreachable(self, unreachable_socket: str) -> None:
        rc = cli._cmd_proposals(_ns(socket=unreachable_socket, status=None))
        assert rc == 2

    def test_approve_unreachable(self, unreachable_socket: str) -> None:
        rc = cli._cmd_approve(_ns(
            socket=unreachable_socket,
            proposal_id="p1",
            reviewer="bob",
            reason=None,
            allow_same_as_submitter=False,
        ))
        assert rc == 2

    def test_reject_unreachable(self, unreachable_socket: str) -> None:
        rc = cli._cmd_reject(_ns(
            socket=unreachable_socket,
            proposal_id="p1",
            reviewer="bob",
            reason="no",
            allow_same_as_submitter=False,
        ))
        assert rc == 2

    def test_governance_missing_action(self) -> None:
        rc = cli._cmd_governance(_ns(governance_action=None))
        assert rc == 2

    def test_governance_status_no_config(self, monkeypatch) -> None:
        monkeypatch.delenv("TAU_CAGE_GOVERNANCE_YAML", raising=False)
        rc = cli._governance_status(_ns(path=None, fmt="text"))
        assert rc == 2

    def test_shadow_summary_unreachable(self, unreachable_socket: str) -> None:
        rc = cli._cmd_shadow_summary(_ns(
            socket=unreachable_socket, window=None, fmt="text",
        ))
        assert rc == 2

    def test_shadow_summary_bad_window(self, unreachable_socket: str) -> None:
        rc = cli._cmd_shadow_summary(_ns(
            socket=unreachable_socket, window="abc", fmt="text",
        ))
        assert rc == 2


# ── _parse_window_argument ───────────────────────────────────────────────────


class TestWindowArgumentParsing:
    def test_none_returns_none(self) -> None:
        assert cli._parse_window_argument(None) is None

    def test_empty_returns_none(self) -> None:
        assert cli._parse_window_argument("") is None

    def test_bare_integer(self) -> None:
        assert cli._parse_window_argument("3600") == 3600

    def test_seconds_suffix(self) -> None:
        assert cli._parse_window_argument("120s") == 120

    def test_minutes_suffix(self) -> None:
        assert cli._parse_window_argument("5m") == 300

    def test_hours_suffix(self) -> None:
        assert cli._parse_window_argument("2h") == 7200

    def test_days_suffix(self) -> None:
        assert cli._parse_window_argument("3d") == 3 * 86400

    def test_bogus_suffix(self) -> None:
        assert cli._parse_window_argument("5x") is None

    def test_non_digits(self) -> None:
        assert cli._parse_window_argument("abch") is None


# ── _render_inspect / _render_explain / _render_proposals ────────────────────


class TestRenderers:
    def test_render_inspect_empty(self) -> None:
        buf = io.StringIO()
        cli._render_inspect(
            {
                "prover_mode": "compat",
                "active_revision_id": None,
                "active_invariants": 0,
                "proof_backend": None,
                "proof_strength": None,
                "fragment_version": None,
                "compile_hash": None,
                "admitted_at_unix": None,
                "invariants": [],
            },
            buf,
        )
        text = buf.getvalue()
        assert "Active policy snapshot" in text
        assert "(none)" in text

    def test_render_inspect_with_items(self) -> None:
        buf = io.StringIO()
        cli._render_inspect(
            {
                "prover_mode": "verified",
                "active_revision_id": "rev1",
                "active_invariants": 1,
                "proof_backend": "pattern",
                "proof_strength": "pattern",
                "fragment_version": "v1",
                "compile_hash": "abc",
                "admitted_at_unix": 1,
                "invariants": [{"class": "MaxPerCall", "scope_hint": "x"}],
            },
            buf,
        )
        text = buf.getvalue()
        assert "MaxPerCall" in text

    def test_render_explain_sat(self) -> None:
        buf = io.StringIO()
        cli._render_explain(
            {
                "verdict": "sat",
                "proof_token": {
                    "backend": "pattern",
                    "proof_strength": "pattern",
                    "compile_hash": "abc",
                },
                "witness": None,
            },
            buf,
        )
        text = buf.getvalue()
        assert "admissible" in text

    def test_render_explain_sat_with_witness(self) -> None:
        buf = io.StringIO()
        cli._render_explain(
            {
                "verdict": "sat",
                "proof_token": {
                    "backend": "z3", "proof_strength": "verified", "compile_hash": "c",
                },
                "witness": {
                    "steps": [
                        {"t": 0, "amount": 10, "event": "x"},
                        {"t": 1, "amount": 5},
                    ],
                    "unroll_steps": 2,
                    "backend": "z3",
                    "per_invariant": [
                        {
                            "class": "SpendingCap", "scope": "per_window",
                            "total": 15, "cap": 100, "currency": "USDC",
                        },
                        {
                            "class": "RollingWindowCap", "group_by": "provider",
                            "event_count": 2, "max_count": 100,
                        },
                    ],
                },
            },
            buf,
        )
        text = buf.getvalue()
        assert "witness" in text
        assert "SpendingCap" in text
        assert "RollingWindowCap" in text

    def test_render_explain_sat_empty_witness(self) -> None:
        buf = io.StringIO()
        cli._render_explain(
            {
                "verdict": "sat",
                "proof_token": {"backend": "z3", "proof_strength": "v", "compile_hash": ""},
                "witness": {"steps": []},
            },
            buf,
        )
        assert "empty trace" in buf.getvalue()

    def test_render_explain_unsat(self) -> None:
        buf = io.StringIO()
        cli._render_explain(
            {
                "verdict": "unsat",
                "report": {
                    "conflicting_invariants": ["a", "b"],
                    "unsat_explanation": "inconsistent",
                    "suggested_repair": "loosen a",
                },
            },
            buf,
        )
        text = buf.getvalue()
        assert "Contradiction" in text
        assert "Suggested repair" in text

    def test_render_explain_inconclusive(self) -> None:
        buf = io.StringIO()
        cli._render_explain(
            {
                "verdict": "inconclusive",
                "report": {"category": "out-of-fragment", "reason": "no tau"},
            },
            buf,
        )
        assert "Inconclusive" in buf.getvalue()

    def test_render_explain_unexpected_verdict(self) -> None:
        buf = io.StringIO()
        cli._render_explain({"verdict": "weird"}, buf)
        assert "Unexpected" in buf.getvalue()

    def test_render_proposals_empty(self) -> None:
        buf = io.StringIO()
        cli._render_proposals({"proposals": []}, buf)
        assert "No proposals" in buf.getvalue()

    def test_render_proposals_with_items(self) -> None:
        buf = io.StringIO()
        cli._render_proposals(
            {
                "proposals": [
                    {
                        "proposal_id": "p1",
                        "status": "pending",
                        "submitted_by": "alice",
                        "submitted_at": 123,
                        "invariants": [{"class_name": "MaxPerCall"}],
                    },
                    {
                        "proposal_id": "p2",
                        "status": "approved",
                        "submitted_by": "bob",
                        "submitted_at": 124,
                        "reviewed_by": "carol",
                        "reviewed_at": 125,
                        "reason": "ok",
                        "invariants": [],
                    },
                ]
            },
            buf,
        )
        text = buf.getvalue()
        assert "p1" in text
        assert "p2" in text
        assert "MaxPerCall" in text


# ── _load_candidate_invariants coverage ──────────────────────────────────────


class TestInvariantEntryEncoding:
    def test_max_per_call(self, tmp_path: Path) -> None:
        p = tmp_path / "policy.yaml"
        p.write_text(
            'version: 1\n'
            'policy:\n'
            '  - kind: max_per_call\n'
            '    max_amount: "50"\n'
            '    currency: USDC\n'
        )
        entries = cli._load_candidate_invariants(p)
        assert entries == [
            {"kind": "max_per_call", "max_amount": "50", "currency": "USDC"},
        ]

    def test_spending_cap_full(self, tmp_path: Path) -> None:
        p = tmp_path / "policy.yaml"
        p.write_text(
            'version: 1\n'
            'policy:\n'
            '  - kind: spending_cap\n'
            '    max_amount: "1000"\n'
            '    currency: USDC\n'
            '    scope: per_window\n'
            '    window_seconds: 3600\n'
        )
        entries = cli._load_candidate_invariants(p)
        assert entries[0]["kind"] == "spending_cap"
        assert entries[0]["window_seconds"] == 3600

    def test_provider_allowlist(self, tmp_path: Path) -> None:
        p = tmp_path / "policy.yaml"
        p.write_text(
            'version: 1\n'
            'policy:\n'
            '  - kind: provider_allowlist\n'
            '    providers: [anthropic, openai]\n'
        )
        entries = cli._load_candidate_invariants(p)
        assert entries[0]["kind"] == "provider_allowlist"
        assert set(entries[0]["providers"]) == {"anthropic", "openai"}

    def test_retry_rate_limit(self, tmp_path: Path) -> None:
        p = tmp_path / "policy.yaml"
        p.write_text(
            'version: 1\n'
            'policy:\n'
            '  - kind: retry_rate_limit\n'
            '    min_gap_seconds: 30\n'
        )
        entries = cli._load_candidate_invariants(p)
        assert entries[0] == {"kind": "retry_rate_limit", "min_gap_seconds": 30}

    def test_rolling_window_cap(self, tmp_path: Path) -> None:
        p = tmp_path / "policy.yaml"
        p.write_text(
            'version: 1\n'
            'policy:\n'
            '  - kind: rolling_window_cap\n'
            '    max_count: 100\n'
            '    window_seconds: 3600\n'
            '    group_by: provider\n'
        )
        entries = cli._load_candidate_invariants(p)
        assert entries[0]["kind"] == "rolling_window_cap"
        assert entries[0]["max_count"] == 100

    def test_counterparty_constraint(self, tmp_path: Path) -> None:
        p = tmp_path / "policy.yaml"
        p.write_text(
            'version: 1\n'
            'policy:\n'
            '  - kind: counterparty_constraint\n'
            '    approved_ids: [vendor_a]\n'
            '    sanctioned_ids: [ofac_01]\n'
        )
        entries = cli._load_candidate_invariants(p)
        assert entries[0]["kind"] == "counterparty_constraint"
        assert entries[0]["approved_ids"] == ["vendor_a"]


# ── _cmd_lint ────────────────────────────────────────────────────────────────


class TestLintCommand:
    def test_lint_missing_file(self, tmp_path: Path) -> None:
        rc = cli._cmd_lint(_ns(
            policy_path=str(tmp_path / "nope.yaml"),
            fmt="text", strict=False,
        ))
        assert rc == 2

    def test_lint_happy_path(self, tmp_path: Path) -> None:
        p = tmp_path / "policy.yaml"
        p.write_text(
            'version: 1\npolicy:\n  - kind: max_per_call\n    max_amount: "50"\n'
        )
        rc = cli._cmd_lint(_ns(
            policy_path=str(p), fmt="text", strict=False,
        ))
        assert rc == 0

    def test_lint_json_format(self, tmp_path: Path, capsys) -> None:
        p = tmp_path / "policy.yaml"
        p.write_text(
            'version: 1\npolicy:\n  - kind: max_per_call\n    max_amount: "50"\n'
        )
        rc = cli._cmd_lint(_ns(
            policy_path=str(p), fmt="json", strict=False,
        ))
        assert rc == 0
        out = capsys.readouterr().out
        # JSON output should parse.
        json.loads(out)


# ── _cmd_init ────────────────────────────────────────────────────────────────


class TestInitCommand:
    def test_init_writes_files(self, tmp_path: Path) -> None:
        policy = tmp_path / "policy.yaml"
        compose = tmp_path / "docker-compose.yaml"
        rc = cli._cmd_init(_ns(
            policy_path=str(policy),
            compose_path=str(compose),
            force=False,
        ))
        assert rc == 0
        assert policy.exists()
        assert compose.exists()

    def test_init_refuses_overwrite(self, tmp_path: Path) -> None:
        policy = tmp_path / "policy.yaml"
        compose = tmp_path / "docker-compose.yaml"
        policy.write_text("existing")
        compose.write_text("existing")
        rc = cli._cmd_init(_ns(
            policy_path=str(policy),
            compose_path=str(compose),
            force=False,
        ))
        assert rc == 2

    def test_init_force_overwrites(self, tmp_path: Path) -> None:
        policy = tmp_path / "policy.yaml"
        compose = tmp_path / "docker-compose.yaml"
        policy.write_text("existing")
        compose.write_text("existing")
        rc = cli._cmd_init(_ns(
            policy_path=str(policy),
            compose_path=str(compose),
            force=True,
        ))
        assert rc == 0


# ── _cmd_quickstart error branches ───────────────────────────────────────────


class TestQuickstartCommand:
    def test_quickstart_refuses_existing_dir(self, tmp_path: Path) -> None:
        # Create a non-empty dir; quickstart should refuse without --force.
        (tmp_path / "policy.yaml").write_text("existing")
        rc = cli._cmd_quickstart(_ns(
            dir=str(tmp_path),
            force=False,
            mcp_config_out=None,
        ))
        assert rc == 2

    def test_quickstart_force_overwrites(self, tmp_path: Path) -> None:
        (tmp_path / "policy.yaml").write_text("old")
        rc = cli._cmd_quickstart(_ns(
            dir=str(tmp_path),
            force=True,
            mcp_config_out=None,
        ))
        # Quickstart succeeds — just make sure it runs.
        assert rc in (0, 2)  # different flows may return 2 for missing prereqs
