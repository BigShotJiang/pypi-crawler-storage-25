"""Tests for the ed25519 signing backend added in v0.7.0.

Scope:
    * sign_ed25519 → verify round-trip
    * tampered envelopes fail
    * wrong public key fails
    * algorithm is part of the canonical payload (downgrade attack fails)
    * keygen-ed25519 CLI produces a valid keypair
    * daemon refuses to start in ed25519 mode without key material

These tests are the load-bearing security contract for cross-org
deployments where distributing a shared HMAC secret to every verifier
isn't feasible.
"""

from __future__ import annotations

import os
import subprocess
import sys
from decimal import Decimal
from pathlib import Path

import pytest

# Skip the entire module if `cryptography` isn't installed. The signing
# backend is an optional extra; users on the HMAC-only path shouldn't be
# forced to pull in cryptography just to run the base test suite.
pytest.importorskip("cryptography")

from adapter.payment_intent_matcher import PaymentIntent
from adapter.verdict_signer import (
    ALG_ED25519,
    ALG_HMAC_SHA256,
    Ed25519Signer,
    KeyMaterialError,
    SignatureError,
    SignedEnvelope,
    Verdict,
    VerdictExpired,
    generate_ed25519_keypair,
    load_ed25519_public_key,
    sign,
    sign_ed25519,
    verify,
)


HMAC_SECRET = b"hmac-secret-at-least-16-bytes-long-yes"


def make_intent(**overrides) -> PaymentIntent:
    base = dict(
        amount=Decimal("50"),
        currency="USDC",
        provider="anthropic",
        counterparty="vendor_x",
        rail="x402",
        timestamp_unix=1713456789,
    )
    base.update(overrides)
    return PaymentIntent(**base)


@pytest.fixture
def keypair(tmp_path: Path) -> tuple[str, str]:
    """Generate a throwaway ed25519 keypair in a test-scoped tmp dir."""
    prefix = str(tmp_path / "cage")
    priv_path, pub_path = generate_ed25519_keypair(prefix)
    return priv_path, pub_path


@pytest.fixture
def signer(keypair) -> Ed25519Signer:
    priv, pub = keypair
    return Ed25519Signer.from_pem_files(priv, pub, strict=True)


# ── keygen + key-loading ────────────────────────────────────────────────────


class TestKeygen:
    def test_keygen_produces_valid_keypair(self, tmp_path: Path) -> None:
        prefix = str(tmp_path / "cage")
        priv, pub = generate_ed25519_keypair(prefix)
        assert Path(priv).exists()
        assert Path(pub).exists()
        # Keys are loadable and match up: signing with the private key
        # and verifying with the public key must round-trip.
        s = Ed25519Signer.from_pem_files(priv, pub, strict=True)
        intent = make_intent()
        env = sign_ed25519(Verdict(outcome="permit"), intent, s, now_unix=1)
        verify(env, intent, public_key=s.public_key, now_unix=1)

    def test_keygen_private_key_is_0600(self, tmp_path: Path) -> None:
        """Private key must be mode 0600 the instant it exists on disk.

        We check with stat; any group or world bit is a test failure.
        """
        prefix = str(tmp_path / "cage")
        priv, _ = generate_ed25519_keypair(prefix)
        import stat as st_mod
        mode = st_mod.S_IMODE(os.stat(priv).st_mode)
        assert mode == 0o600, f"private key mode is {oct(mode)}, want 0o600"

    def test_keygen_refuses_to_overwrite(self, tmp_path: Path) -> None:
        prefix = str(tmp_path / "cage")
        generate_ed25519_keypair(prefix)
        with pytest.raises(KeyMaterialError, match="refusing to overwrite"):
            generate_ed25519_keypair(prefix)

    def test_load_public_key_independently(self, keypair) -> None:
        """A pure verifier can load just the public key."""
        _, pub = keypair
        key = load_ed25519_public_key(pub)
        # Must be a usable public key object (has .verify).
        assert hasattr(key, "verify")


class TestKeyPermissionsStrict:
    def test_world_readable_private_key_fails_strict(self, tmp_path: Path) -> None:
        """Strict mode refuses to load a world-readable private key."""
        prefix = str(tmp_path / "cage")
        priv, pub = generate_ed25519_keypair(prefix)
        os.chmod(priv, 0o644)  # world-readable
        with pytest.raises(KeyMaterialError, match="permissive mode"):
            Ed25519Signer.from_pem_files(priv, pub, strict=True)

    def test_world_readable_private_key_warns_non_strict(
        self, tmp_path: Path, recwarn
    ) -> None:
        prefix = str(tmp_path / "cage")
        priv, pub = generate_ed25519_keypair(prefix)
        os.chmod(priv, 0o644)
        Ed25519Signer.from_pem_files(priv, pub, strict=False)
        assert any("permissive mode" in str(w.message) for w in recwarn)


class TestMalformedKeyMaterial:
    def test_missing_private_key_fails(self, tmp_path: Path) -> None:
        with pytest.raises(KeyMaterialError):
            Ed25519Signer.from_pem_files(
                str(tmp_path / "no-such.pem"),
                str(tmp_path / "no-such.pub"),
            )

    def test_malformed_pem_fails(self, tmp_path: Path) -> None:
        priv = tmp_path / "bad.pem"
        pub = tmp_path / "bad.pub"
        priv.write_bytes(b"not-a-pem")
        pub.write_bytes(b"not-a-pem-either")
        priv.chmod(0o600)
        with pytest.raises(KeyMaterialError, match="malformed PEM"):
            Ed25519Signer.from_pem_files(str(priv), str(pub), strict=True)

    def test_from_env_requires_both_paths(self, monkeypatch) -> None:
        monkeypatch.delenv("TAU_CAGE_ED25519_PRIVATE_KEY", raising=False)
        monkeypatch.delenv("TAU_CAGE_ED25519_PUBLIC_KEY", raising=False)
        with pytest.raises(KeyMaterialError, match="TAU_CAGE_ED25519"):
            Ed25519Signer.from_env()


# ── sign / verify round-trip ────────────────────────────────────────────────


class TestSignVerifyRoundTrip:
    def test_round_trip_permit(self, signer: Ed25519Signer) -> None:
        intent = make_intent()
        env = sign_ed25519(Verdict(outcome="permit"), intent, signer, now_unix=1000)
        assert env.algorithm == ALG_ED25519
        verify(env, intent, public_key=signer.public_key, now_unix=1000)

    def test_round_trip_reject(self, signer: Ed25519Signer) -> None:
        intent = make_intent()
        env = sign_ed25519(
            Verdict(
                outcome="reject",
                rule_id="spending_cap_daily",
                witness="cumulative=$1002, cap=$1000",
                reason_text="cap exceeded",
            ),
            intent,
            signer,
            now_unix=2000,
        )
        verify(env, intent, public_key=signer.public_key, now_unix=2000)
        assert env.rule_id == "spending_cap_daily"

    def test_expired_envelope_rejected(self, signer: Ed25519Signer) -> None:
        intent = make_intent()
        env = sign_ed25519(
            Verdict(outcome="permit", ttl_seconds=30),
            intent, signer, now_unix=1000,
        )
        with pytest.raises(VerdictExpired):
            verify(env, intent, public_key=signer.public_key, now_unix=1031)

    def test_round_trip_via_json(self, signer: Ed25519Signer) -> None:
        intent = make_intent()
        env = sign_ed25519(
            Verdict(outcome="permit"), intent, signer, now_unix=1,
        )
        wire = env.to_json()
        parsed = SignedEnvelope.from_json(wire)
        assert parsed == env
        assert parsed.algorithm == ALG_ED25519
        verify(parsed, intent, public_key=signer.public_key, now_unix=1)


# ── security properties ────────────────────────────────────────────────────


class TestSecurityProperties:
    def test_tampered_outcome_fails_verify(self, signer: Ed25519Signer) -> None:
        intent = make_intent()
        env = sign_ed25519(
            Verdict(outcome="reject", rule_id="r1"),
            intent, signer, now_unix=1,
        )
        tampered = SignedEnvelope(
            outcome="permit",  # attacker flips to permit
            rule_id=env.rule_id,
            witness=env.witness,
            reason_text=env.reason_text,
            issued_at_unix=env.issued_at_unix,
            ttl_seconds=env.ttl_seconds,
            intent_hash=env.intent_hash,
            mac_hex=env.mac_hex,
            mac_alg=env.mac_alg,
            algorithm=env.algorithm,
            version=env.version,
        )
        with pytest.raises(SignatureError, match="ed25519 verification failed"):
            verify(tampered, intent, public_key=signer.public_key, now_unix=1)

    def test_tampered_issued_at_fails_verify(self, signer: Ed25519Signer) -> None:
        """Sliding the issued-at forward to dodge a TTL expiry fails the
        signature check."""
        intent = make_intent()
        env = sign_ed25519(
            Verdict(outcome="permit", ttl_seconds=30),
            intent, signer, now_unix=1000,
        )
        # Attacker shifts issued_at forward by an hour to evade expiry.
        tampered = SignedEnvelope(
            outcome=env.outcome,
            rule_id=env.rule_id,
            witness=env.witness,
            reason_text=env.reason_text,
            issued_at_unix=env.issued_at_unix + 3600,
            ttl_seconds=env.ttl_seconds,
            intent_hash=env.intent_hash,
            mac_hex=env.mac_hex,
            mac_alg=env.mac_alg,
            algorithm=env.algorithm,
            version=env.version,
        )
        with pytest.raises(SignatureError, match="ed25519 verification failed"):
            verify(tampered, intent, public_key=signer.public_key, now_unix=4000)

    def test_wrong_public_key_fails_verify(
        self, signer: Ed25519Signer, tmp_path: Path
    ) -> None:
        """An envelope signed by cage A must NOT verify against cage B's key."""
        intent = make_intent()
        env = sign_ed25519(Verdict(outcome="permit"), intent, signer, now_unix=1)

        # A second keypair (a different cage / rotated key)
        other_prefix = str(tmp_path / "other")
        _, other_pub_path = generate_ed25519_keypair(other_prefix)
        other_pub = load_ed25519_public_key(other_pub_path)

        with pytest.raises(SignatureError, match="ed25519 verification failed"):
            verify(env, intent, public_key=other_pub, now_unix=1)

    def test_replay_against_different_intent_fails(
        self, signer: Ed25519Signer
    ) -> None:
        """A permit for intent A cannot be replayed against intent B."""
        intent_a = make_intent(amount=Decimal("10"))
        intent_b = make_intent(amount=Decimal("10000"))
        env = sign_ed25519(
            Verdict(outcome="permit"), intent_a, signer, now_unix=1,
        )
        with pytest.raises(SignatureError, match="intent_hash mismatch"):
            verify(env, intent_b, public_key=signer.public_key, now_unix=1)


class TestAlgorithmBinding:
    """Algorithm is part of the canonical payload so downgrade fails."""

    def test_algorithm_in_canonical_payload(self, signer: Ed25519Signer) -> None:
        """The ed25519 canonical payload must include the algorithm key."""
        from adapter.verdict_signer import _canonical_mac_input
        hmac_payload = _canonical_mac_input(
            "permit", None, None, None, 1, 30, "h",
            algorithm=ALG_HMAC_SHA256,
        )
        ed_payload = _canonical_mac_input(
            "permit", None, None, None, 1, 30, "h",
            algorithm=ALG_ED25519,
        )
        # HMAC v1 stays byte-identical to pre-v0.7 (no algorithm key).
        assert b'"algorithm"' not in hmac_payload
        # Ed25519 binds the algorithm in.
        assert b'"algorithm":"ed25519"' in ed_payload
        # The two payloads differ; an ed25519 signature over one doesn't
        # authenticate the other.
        assert hmac_payload != ed_payload

    def test_algorithm_downgrade_attack_fails(self, signer: Ed25519Signer) -> None:
        """An attacker who re-labels an ed25519 envelope as HMAC with a
        freshly-forged HMAC cannot trick an ed25519-only verifier."""
        intent = make_intent()
        env = sign_ed25519(
            Verdict(outcome="permit"), intent, signer, now_unix=1,
        )
        # Forge: flip the algorithm label to hmac-sha256. The `mac_hex`
        # is still the ed25519 signature bytes, but an ed25519 verifier
        # dispatches on env.algorithm and an HMAC verifier would call
        # this 'wrong MAC'. Either way, it fails.
        downgraded = SignedEnvelope(
            outcome=env.outcome,
            rule_id=env.rule_id,
            witness=env.witness,
            reason_text=env.reason_text,
            issued_at_unix=env.issued_at_unix,
            ttl_seconds=env.ttl_seconds,
            intent_hash=env.intent_hash,
            mac_hex=env.mac_hex,
            mac_alg="HMAC-SHA256",
            algorithm=ALG_HMAC_SHA256,  # downgraded
            version=env.version,
        )
        # HMAC verifier path: signature is the ed25519 bytes which are not
        # a valid HMAC of the payload under any secret the defender holds.
        with pytest.raises(SignatureError, match="MAC verification failed"):
            verify(downgraded, intent, HMAC_SECRET, now_unix=1)

    def test_unsupported_algorithm_rejected(self, signer: Ed25519Signer) -> None:
        """Parser rejects an envelope whose algorithm we don't understand."""
        bogus = (
            '{"outcome":"permit","issued_at_unix":1,"ttl_seconds":30,'
            '"intent_hash":"x","mac_hex":"y","mac_alg":"HMAC-SHA256",'
            '"algorithm":"rsa-7000"}'
        )
        with pytest.raises(SignatureError, match="unsupported signature algorithm"):
            SignedEnvelope.from_json(bogus)

    def test_missing_algorithm_defaults_to_hmac(self, signer: Ed25519Signer) -> None:
        """A pre-v0.7 envelope with no algorithm key parses as hmac-sha256."""
        intent = make_intent()
        env = sign(Verdict(outcome="permit"), intent, HMAC_SECRET, now_unix=1)
        import json as _json
        d = _json.loads(env.to_json())
        d.pop("algorithm", None)
        parsed = SignedEnvelope.from_json(_json.dumps(d))
        assert parsed.algorithm == ALG_HMAC_SHA256
        # Still verifies under its HMAC secret.
        verify(parsed, intent, HMAC_SECRET, now_unix=1)


# ── dispatch ────────────────────────────────────────────────────────────────


class TestVerifyDispatch:
    def test_verify_ed25519_without_public_key_errors(self, signer) -> None:
        intent = make_intent()
        env = sign_ed25519(Verdict(outcome="permit"), intent, signer, now_unix=1)
        with pytest.raises(SignatureError, match="public_key"):
            verify(env, intent, now_unix=1)

    def test_verify_hmac_envelope_with_ed25519_key_errors(self, signer) -> None:
        """Mixing up the key type for HMAC verification produces a
        SignatureError, not a confusing AttributeError."""
        intent = make_intent()
        env = sign(Verdict(outcome="permit"), intent, HMAC_SECRET, now_unix=1)
        # HMAC envelope verified without a secret: must surface cleanly.
        with pytest.raises(SignatureError, match="secret"):
            verify(env, intent, now_unix=1)

    def test_ed25519_envelope_has_ed25519_mac_alg(self, signer) -> None:
        intent = make_intent()
        env = sign_ed25519(Verdict(outcome="permit"), intent, signer, now_unix=1)
        # Legacy MAC-Alg header label is "Ed25519"; algorithm is "ed25519".
        assert env.mac_alg == "Ed25519"
        assert env.algorithm == ALG_ED25519


# ── CLI keygen-ed25519 ──────────────────────────────────────────────────────


class TestCliKeygen:
    def test_keygen_cli_produces_valid_keypair(self, tmp_path: Path) -> None:
        prefix = str(tmp_path / "cage")
        result = subprocess.run(
            [sys.executable, "-m", "daemon.cli", "keygen-ed25519", "--out", prefix],
            capture_output=True,
            text=True,
            cwd=str(Path(__file__).resolve().parent.parent),
        )
        assert result.returncode == 0, result.stderr
        priv = Path(prefix + ".pem")
        pub = Path(prefix + ".pub")
        assert priv.exists()
        assert pub.exists()
        # Keys must be usable for a sign→verify round-trip.
        signer = Ed25519Signer.from_pem_files(str(priv), str(pub), strict=True)
        intent = make_intent()
        env = sign_ed25519(Verdict(outcome="permit"), intent, signer, now_unix=1)
        verify(env, intent, public_key=signer.public_key, now_unix=1)

    def test_keygen_cli_refuses_to_overwrite(self, tmp_path: Path) -> None:
        prefix = str(tmp_path / "cage")
        generate_ed25519_keypair(prefix)
        result = subprocess.run(
            [sys.executable, "-m", "daemon.cli", "keygen-ed25519", "--out", prefix],
            capture_output=True,
            text=True,
            cwd=str(Path(__file__).resolve().parent.parent),
        )
        assert result.returncode != 0
        assert "overwrite" in result.stderr


# ── daemon startup preflight ────────────────────────────────────────────────


class TestDaemonSigningPreflight:
    """The daemon must fail closed when ed25519 mode is selected but the
    operator forgot to supply key material. Failing closed at startup is
    better than silently sending unsigned envelopes at first request."""

    def test_daemon_fails_closed_without_keys(
        self, tmp_path: Path, monkeypatch
    ) -> None:
        socket_path = str(tmp_path / "short.sock")
        env = os.environ.copy()
        env["TAU_CAGE_SIGNING_ALGORITHM"] = "ed25519"
        env.pop("TAU_CAGE_ED25519_PRIVATE_KEY", None)
        env.pop("TAU_CAGE_ED25519_PUBLIC_KEY", None)
        result = subprocess.run(
            [sys.executable, "-m", "daemon.cli", "--socket", socket_path],
            capture_output=True,
            text=True,
            env=env,
            timeout=10,
            cwd=str(Path(__file__).resolve().parent.parent),
        )
        assert result.returncode != 0
        # The error must mention ed25519 so the operator knows which env
        # var to set; don't assert on specific wording beyond that.
        combined = (result.stderr + result.stdout).lower()
        assert "ed25519" in combined

    def test_daemon_rejects_unknown_algorithm(self, tmp_path: Path) -> None:
        socket_path = str(tmp_path / "short2.sock")
        env = os.environ.copy()
        env["TAU_CAGE_SIGNING_ALGORITHM"] = "not-a-real-alg"
        result = subprocess.run(
            [sys.executable, "-m", "daemon.cli", "--socket", socket_path],
            capture_output=True,
            text=True,
            env=env,
            timeout=10,
            cwd=str(Path(__file__).resolve().parent.parent),
        )
        assert result.returncode != 0
        assert "TAU_CAGE_SIGNING_ALGORITHM" in result.stderr or \
               "not-a-real-alg" in result.stderr
