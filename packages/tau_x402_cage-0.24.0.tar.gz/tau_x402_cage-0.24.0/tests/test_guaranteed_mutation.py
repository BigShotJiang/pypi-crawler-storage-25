"""Acceptance tests for Guaranteed Mode mutation + merge discipline (v0.19.0).

Covers Deliverables 5.A, 5.B, 5.C of the Guaranteed Mode spec:

  * ``propose(current, mutation)`` never mutates the current revision,
    even transiently.
  * Weakening a NoWeakening-guarded limit without approval is rejected;
    ``current_revision`` is unchanged by object identity + id.
  * Totality failure rejects; active revision unchanged.
  * Inconclusive prover rejects; active revision unchanged.
  * Two-step ``propose(); activate()`` swaps atomically.
  * Interrupting between propose and activate leaves state consistent.
  * Semantic / temporal merge conflicts reject with
    ``REVISION_TRANSITION_VIOLATION``.
  * Override without ``expires_at`` rejects.
  * Override with ``expires_at`` > ``MAX_OVERRIDE_DURATION_H`` rejects.

Tests run against injected totality + prover doubles so outcomes stay
deterministic.
"""
from __future__ import annotations

from dataclasses import dataclass, field, replace
from decimal import Decimal
from typing import Any, Mapping, Optional, Tuple

import pytest

from adapter.cross_revision import (
    CrossRevisionValidator,
    NoWeakening,
    OverridesMustExpire,
)
from adapter.guaranteed_mutation import (
    GuaranteedActivationError,
    GuaranteedMergeResult,
    GuaranteedMutationPipeline,
    GuaranteedMutationProposal,
    MAX_OVERRIDE_DURATION_H,
    MAX_OVERRIDE_DURATION_SECONDS,
    guaranteed_merge,
)
from adapter.invariants import SpendingCap
from adapter.policy_revision import PolicyRevision


# ── test doubles ────────────────────────────────────────────────────────────


def _revision(
    invariants: Tuple[Any, ...],
    *,
    revision_id: str,
    predecessor: Optional[str] = None,
    depth: int = 0,
    branch: str = "main",
    affected_scope: Optional[dict] = None,
    admitted_at_unix: int = 1_713_000_000,
) -> PolicyRevision:
    """Construct a real PolicyRevision for transition-invariant tests."""
    return PolicyRevision(
        revision_id=revision_id,
        invariants=invariants,
        proof_backend="python-pattern",
        proof_strength="pattern",
        prover_mode="compat",
        compile_hash=None,
        fragment_version=None,
        tau_backend_version=None,
        admitted_at_unix=admitted_at_unix,
        predecessor_revision_id=predecessor,
        delta={},
        revision_depth=depth,
        branch=branch,
        affected_scope=affected_scope,
    )


@dataclass(frozen=True)
class _FakeProofArtifact:
    """Stand-in matching the agent 2 artifact shape."""

    artifact_id: str
    policy_revision_id: str
    proof_result: str = "consistent"
    artifact_hash: str = ""


@dataclass(frozen=True)
class _FakeProofResult:
    """Stand-in for ``GuaranteedProofResult`` used to drive prover outcomes."""

    consistent: bool
    decisive: bool
    reason: str = ""
    artifact: Optional[_FakeProofArtifact] = None


class _DecisiveProver:
    """Prover double that always returns decisive + consistent."""

    def __init__(self) -> None:
        self.calls = 0

    def prove(self, candidate: Any) -> _FakeProofResult:
        self.calls += 1
        rev_id = getattr(candidate, "revision_id", None) or getattr(candidate, "id", "")
        return _FakeProofResult(
            consistent=True,
            decisive=True,
            reason="decisive stub",
            artifact=_FakeProofArtifact(
                artifact_id=f"artifact-{self.calls}",
                policy_revision_id=str(rev_id),
                proof_result="consistent",
            ),
        )


class _InconclusiveProver:
    """Prover double that returns decisive=False."""

    def prove(self, candidate: Any) -> _FakeProofResult:
        return _FakeProofResult(consistent=False, decisive=False, reason="inconclusive")


class _InconsistentProver:
    """Prover double that returns decisive=True but consistent=False."""

    def prove(self, candidate: Any) -> _FakeProofResult:
        return _FakeProofResult(consistent=False, decisive=True, reason="unsat")


@dataclass(frozen=True)
class _FakeTotalityReport:
    total: bool
    reason: str = ""
    details: Mapping[str, Any] = field(default_factory=dict)


def _total_ok(_candidate: Any) -> _FakeTotalityReport:
    return _FakeTotalityReport(total=True)


def _total_fail(_candidate: Any) -> _FakeTotalityReport:
    return _FakeTotalityReport(total=False, reason="candidate is non-total")


# ── helper: build a pipeline with injected doubles ──────────────────────────


def _pipeline(
    *,
    prover: Any = None,
    totality_fn: Any = None,
    transition_validator: Optional[CrossRevisionValidator] = None,
) -> GuaranteedMutationPipeline:
    return GuaranteedMutationPipeline(
        totality_fn=totality_fn or _total_ok,
        prover=prover or _DecisiveProver(),
        transition_validator=transition_validator,
    )


# ── Test 6: guaranteed mutation safety (weakening without approval) ────────


class TestNoWeakeningBlocksUnapproved:
    def test_weakening_spending_cap_without_approval_rejects(self):
        """Weakening a cap on main without an approval token must fail.

        ``propose`` returns ``activatable=False`` with
        ``REVISION_TRANSITION_VIOLATION``. The current_revision's object
        identity AND revision_id are unchanged after the call.
        """
        old = _revision(
            (SpendingCap(Decimal("10"), scope="per_tx"),),
            revision_id="r0",
        )
        new = _revision(
            (SpendingCap(Decimal("100"), scope="per_tx"),),
            revision_id="r1",
            predecessor="r0",
            depth=1,
        )

        pipe = _pipeline()

        original_identity = id(old)
        original_id = old.revision_id
        proposal = pipe.propose(old, new)

        assert proposal.activatable is False
        assert proposal.failure is not None
        assert proposal.failure.code == "REVISION_TRANSITION_VIOLATION"
        # Current revision unchanged by object identity + id.
        assert id(old) == original_identity
        assert old.revision_id == original_id

    def test_tightening_spending_cap_is_activatable(self):
        """Counter-example: strengthening a cap passes NoWeakening."""
        old = _revision(
            (SpendingCap(Decimal("100"), scope="per_tx"),),
            revision_id="r0",
        )
        new = _revision(
            (SpendingCap(Decimal("10"), scope="per_tx"),),
            revision_id="r1",
            predecessor="r0",
            depth=1,
        )

        pipe = _pipeline()
        proposal = pipe.propose(old, new)

        assert proposal.activatable is True, (
            f"tightening rejected: {proposal.failure}"
        )
        assert proposal.failure is None


# ── totality failure ────────────────────────────────────────────────────────


class TestTotalityFailureRejects:
    def test_non_total_candidate_rejects(self):
        old = _revision(
            (SpendingCap(Decimal("10"), scope="per_tx"),),
            revision_id="r0",
        )
        new = _revision(
            (SpendingCap(Decimal("5"), scope="per_tx"),),
            revision_id="r1",
            predecessor="r0",
        )

        pipe = _pipeline(totality_fn=_total_fail)

        identity_before = id(old)
        proposal = pipe.propose(old, new)

        assert proposal.activatable is False
        assert proposal.failure is not None
        assert proposal.failure.code == "TAU_TOTALITY_FAILED"
        assert id(old) == identity_before


# ── inconclusive / inconsistent prover ──────────────────────────────────────


class TestProverInconclusiveRejects:
    def test_inconclusive_prover_rejects(self):
        old = _revision(
            (SpendingCap(Decimal("10"), scope="per_tx"),),
            revision_id="r0",
        )
        new = _revision(
            (SpendingCap(Decimal("5"), scope="per_tx"),),
            revision_id="r1",
            predecessor="r0",
        )

        pipe = _pipeline(prover=_InconclusiveProver())

        proposal = pipe.propose(old, new)

        assert proposal.activatable is False
        assert proposal.failure is not None
        assert proposal.failure.code == "TAU_PROOF_INCONCLUSIVE"
        assert old.revision_id == "r0"  # unchanged

    def test_inconsistent_prover_rejects(self):
        old = _revision(
            (SpendingCap(Decimal("10"), scope="per_tx"),),
            revision_id="r0",
        )
        new = _revision(
            (SpendingCap(Decimal("5"), scope="per_tx"),),
            revision_id="r1",
            predecessor="r0",
        )

        pipe = _pipeline(prover=_InconsistentProver())

        proposal = pipe.propose(old, new)

        assert proposal.activatable is False
        assert proposal.failure is not None
        assert proposal.failure.code == "TAU_PROOF_INCONSISTENT"


# ── atomic activate ─────────────────────────────────────────────────────────


class TestProposeActivateAtomicity:
    def test_propose_then_activate_returns_candidate(self):
        old = _revision(
            (SpendingCap(Decimal("100"), scope="per_tx"),),
            revision_id="r0",
        )
        new = _revision(
            (SpendingCap(Decimal("10"), scope="per_tx"),),
            revision_id="r1",
            predecessor="r0",
        )

        pipe = _pipeline()
        proposal = pipe.propose(old, new)

        assert proposal.activatable is True
        activated = pipe.activate(proposal)
        assert activated is new
        assert activated.revision_id == "r1"

    def test_cannot_activate_non_activatable_proposal(self):
        old = _revision(
            (SpendingCap(Decimal("10"), scope="per_tx"),),
            revision_id="r0",
        )
        new = _revision(
            (SpendingCap(Decimal("100"), scope="per_tx"),),
            revision_id="r1",
            predecessor="r0",
        )

        pipe = _pipeline()
        proposal = pipe.propose(old, new)

        assert proposal.activatable is False
        with pytest.raises(GuaranteedActivationError):
            pipe.activate(proposal)

    def test_propose_without_activate_leaves_state_consistent(self):
        """If the caller drops the proposal, the old revision is intact."""
        old = _revision(
            (SpendingCap(Decimal("100"), scope="per_tx"),),
            revision_id="r0",
        )
        new = _revision(
            (SpendingCap(Decimal("10"), scope="per_tx"),),
            revision_id="r1",
            predecessor="r0",
        )

        pipe = _pipeline()
        identity_before = id(old)
        proposal = pipe.propose(old, new)
        # Caller simulates a crash here: never invokes activate.
        del proposal

        assert id(old) == identity_before
        assert old.revision_id == "r0"
        assert old.invariants[0].max_amount == Decimal("100")


# ── semantic merge conflict ─────────────────────────────────────────────────


class TestSemanticMergeRejects:
    def test_semantic_conflict_rejects_with_revision_transition_violation(self):
        """A semantic conflict between two branches must not auto-resolve."""
        base = _revision((), revision_id="base")
        branch_a = _revision((), revision_id="a")
        branch_b = _revision((), revision_id="b")

        def fake_classify(**_kwargs: Any):
            return [
                {
                    "class_name": "SpendingCap",
                    "category": "semantic",
                    "diagnosis": "incompatible caps",
                }
            ]

        result = guaranteed_merge(
            base,
            branch_a,
            branch_b,
            classify_fn=fake_classify,
        )

        assert isinstance(result, GuaranteedMergeResult)
        assert result.accepted is False
        assert result.failure is not None
        assert result.failure.code == "REVISION_TRANSITION_VIOLATION"
        assert any(
            c.get("category") == "semantic" for c in result.conflicts
        )

    def test_temporal_conflict_rejects(self):
        base = _revision((), revision_id="base")
        branch_a = _revision((), revision_id="a")
        branch_b = _revision((), revision_id="b")

        def fake_classify(**_kwargs: Any):
            return [{"class_name": "RollingWindowCap", "category": "temporal"}]

        result = guaranteed_merge(
            base,
            branch_a,
            branch_b,
            classify_fn=fake_classify,
        )

        assert result.accepted is False
        assert result.failure.code == "REVISION_TRANSITION_VIOLATION"

    def test_unsupported_fragment_rejects(self):
        base = _revision((), revision_id="base")
        branch_a = _revision((), revision_id="a")
        branch_b = _revision((), revision_id="b")

        def fake_classify(**_kwargs: Any):
            return [{"class_name": "Fragmented", "category": "unsupported_fragment"}]

        result = guaranteed_merge(
            base,
            branch_a,
            branch_b,
            classify_fn=fake_classify,
        )

        assert result.accepted is False
        assert result.failure.code == "REVISION_TRANSITION_VIOLATION"

    def test_syntactic_only_merge_runs_proposal_pipeline(self):
        """Disjoint syntactic merges pass classification and run propose()."""
        base = _revision(
            (SpendingCap(Decimal("100"), scope="per_tx"),),
            revision_id="base",
        )
        branch_a = _revision(
            (SpendingCap(Decimal("50"), scope="per_tx"),),
            revision_id="a",
        )
        branch_b = _revision(
            (SpendingCap(Decimal("30"), scope="per_tx"),),
            revision_id="b",
        )

        # Syntactic-only conflict list (empty).
        def fake_classify(**_kwargs: Any):
            return []

        # Merge builder: pretend we merged into a tighter cap than base.
        merged = _revision(
            (SpendingCap(Decimal("25"), scope="per_tx"),),
            revision_id="merged-1",
            predecessor="base",
        )

        def fake_builder(*, base, branch_a, branch_b):
            return merged

        pipe = _pipeline()
        result = guaranteed_merge(
            base,
            branch_a,
            branch_b,
            pipeline=pipe,
            classify_fn=fake_classify,
            build_merge_fn=fake_builder,
        )

        assert result.accepted is True, f"syntactic merge rejected: {result.failure}"
        assert result.proposal is not None
        assert result.proposal.activatable is True


# ── override discipline (OverridesMustExpire + MAX_OVERRIDE_DURATION_H) ─────


class TestOverrideDiscipline:
    def _revision_with_override(
        self,
        *,
        revision_id: str,
        predecessor: str,
        override_entry: dict,
        admitted_at_unix: int = 1_713_000_000,
    ) -> PolicyRevision:
        """Build a revision carrying one override at index 0."""
        return _revision(
            (SpendingCap(Decimal("10"), scope="per_tx"),),
            revision_id=revision_id,
            predecessor=predecessor,
            depth=1,
            affected_scope={"overrides": {"0": override_entry}},
            admitted_at_unix=admitted_at_unix,
        )

    def test_override_without_expires_at_rejects(self):
        old = _revision(
            (SpendingCap(Decimal("10"), scope="per_tx"),),
            revision_id="r0",
        )
        new = self._revision_with_override(
            revision_id="r1",
            predecessor="r0",
            override_entry={},  # no expires_at_unix
        )

        pipe = _pipeline()
        proposal = pipe.propose(old, new)

        assert proposal.activatable is False
        assert proposal.failure is not None
        assert proposal.failure.code == "REVISION_TRANSITION_VIOLATION"
        violations = proposal.failure.context.get("violations") or []
        assert any(
            v.get("category") == "override_missing_expires_at"
            for v in violations
        )

    def test_override_longer_than_max_duration_rejects(self):
        admitted_at = 1_713_000_000
        # Expiry is 1 second past MAX_OVERRIDE_DURATION_H.
        expires_at = admitted_at + MAX_OVERRIDE_DURATION_SECONDS + 1

        old = _revision(
            (SpendingCap(Decimal("10"), scope="per_tx"),),
            revision_id="r0",
            admitted_at_unix=admitted_at,
        )
        new = self._revision_with_override(
            revision_id="r1",
            predecessor="r0",
            admitted_at_unix=admitted_at,
            override_entry={"expires_at_unix": expires_at},
        )

        pipe = _pipeline()
        proposal = pipe.propose(old, new)

        assert proposal.activatable is False
        assert proposal.failure is not None
        assert proposal.failure.code == "REVISION_TRANSITION_VIOLATION"
        violations = proposal.failure.context.get("violations") or []
        assert any(
            v.get("category") == "override_ttl_too_long"
            for v in violations
        )

    def test_override_within_max_duration_allowed(self):
        admitted_at = 1_713_000_000
        # Expiry is exactly at the boundary — allowed.
        expires_at = admitted_at + MAX_OVERRIDE_DURATION_SECONDS

        old = _revision(
            (SpendingCap(Decimal("100"), scope="per_tx"),),
            revision_id="r0",
            admitted_at_unix=admitted_at,
        )
        new = self._revision_with_override(
            revision_id="r1",
            predecessor="r0",
            admitted_at_unix=admitted_at,
            override_entry={"expires_at_unix": expires_at},
        )
        # Tighten simultaneously so NoWeakening is happy.
        new = replace(
            new,
            invariants=(SpendingCap(Decimal("50"), scope="per_tx"),),
        )

        pipe = _pipeline()
        proposal = pipe.propose(old, new)

        assert proposal.activatable is True, (
            f"override at max duration rejected: {proposal.failure}"
        )


# ── public API sanity ───────────────────────────────────────────────────────


class TestPublicAPIStable:
    def test_max_override_duration_h_is_24(self):
        assert MAX_OVERRIDE_DURATION_H == 24
        assert MAX_OVERRIDE_DURATION_SECONDS == 24 * 60 * 60

    def test_proposal_is_frozen(self):
        """GuaranteedMutationProposal is a frozen dataclass."""
        from dataclasses import FrozenInstanceError

        old = _revision(
            (SpendingCap(Decimal("100"), scope="per_tx"),),
            revision_id="r0",
        )
        new = _revision(
            (SpendingCap(Decimal("10"), scope="per_tx"),),
            revision_id="r1",
            predecessor="r0",
        )
        pipe = _pipeline()
        proposal = pipe.propose(old, new)

        with pytest.raises((FrozenInstanceError, AttributeError)):
            proposal.activatable = not proposal.activatable  # type: ignore[misc]
