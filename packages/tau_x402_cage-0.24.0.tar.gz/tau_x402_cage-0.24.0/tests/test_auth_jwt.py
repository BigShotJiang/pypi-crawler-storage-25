"""Tests for ``saas/auth_jwt.py`` — JWT/OIDC auth via JWKS.

Gated on PyJWT + FastAPI availability so the suite stays green on
minimal CI runners without the ``[auth-jwt]`` or ``[saas]`` extras.
"""
from __future__ import annotations

import json
import os
import tempfile
import threading
import time
from typing import Any, Dict, Iterator, List, Mapping, Optional

import pytest

jwt = pytest.importorskip("jwt")  # PyJWT — test module guard
pytest.importorskip("cryptography")


from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ec, rsa

from saas.auth_jwt import (
    ALLOWED_ALGORITHMS,
    JwksCache,
    JwtClaimError,
    JwtConfig,
    JwtError,
    JwtExpiredError,
    JwtInvalidError,
    JwtKeyFetchError,
    JwtVerifier,
)


# ── test fixtures: real RSA + EC keypairs ────────────────────────────────────


def _make_rsa_jwk(kid: str = "test-rsa-1") -> Dict[str, Any]:
    """Create a real RSA keypair and return {private_pem, jwk_public}."""
    priv = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    priv_pem = priv.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    pub = priv.public_key()
    pub_pem = pub.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )
    # Build the public JWK by hand using cryptography's numbers.
    numbers = pub.public_numbers()
    def _b64url_uint(n: int) -> str:
        import base64
        b = n.to_bytes((n.bit_length() + 7) // 8, "big")
        return base64.urlsafe_b64encode(b).rstrip(b"=").decode()
    jwk = {
        "kty": "RSA",
        "kid": kid,
        "alg": "RS256",
        "use": "sig",
        "n": _b64url_uint(numbers.n),
        "e": _b64url_uint(numbers.e),
    }
    return {"priv_pem": priv_pem, "pub_pem": pub_pem, "jwk": jwk}


def _make_ec_jwk(kid: str = "test-ec-1") -> Dict[str, Any]:
    """Create a real EC P-256 keypair and return {private_pem, jwk_public}."""
    priv = ec.generate_private_key(ec.SECP256R1())
    priv_pem = priv.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    pub = priv.public_key()
    numbers = pub.public_numbers()
    import base64
    def _b64url_uint(n: int, size: int = 32) -> str:
        b = n.to_bytes(size, "big")
        return base64.urlsafe_b64encode(b).rstrip(b"=").decode()
    jwk = {
        "kty": "EC",
        "kid": kid,
        "alg": "ES256",
        "crv": "P-256",
        "use": "sig",
        "x": _b64url_uint(numbers.x),
        "y": _b64url_uint(numbers.y),
    }
    return {"priv_pem": priv_pem, "jwk": jwk}


def _make_token(
    priv_pem: bytes,
    alg: str,
    kid: str,
    *,
    iss: str = "https://idp.test/",
    aud: str = "cage-test",
    sub: str = "user-abc",
    extra_claims: Optional[Mapping[str, Any]] = None,
    exp_offset: int = 3600,
    nbf_offset: int = -10,
    iat_offset: int = -10,
) -> str:
    """Mint a signed JWT. Offsets are seconds from now."""
    now = int(time.time())
    claims: Dict[str, Any] = {
        "iss": iss,
        "aud": aud,
        "sub": sub,
        "iat": now + iat_offset,
        "nbf": now + nbf_offset,
        "exp": now + exp_offset,
    }
    if extra_claims:
        claims.update(extra_claims)
    return jwt.encode(claims, priv_pem, algorithm=alg, headers={"kid": kid})


class FakeJwksCache(JwksCache):
    """A JwksCache that serves an in-memory JWK document instead of HTTP.

    We subclass the real cache so the refresh / miss / fail-open logic
    is exercised by the tests — only the HTTP fetch is stubbed.
    """

    def __init__(self, document: Dict[str, Any], *, url: str = "https://test/.well-known/jwks.json") -> None:
        super().__init__(jwks_url=url, ttl_s=3600)
        self._document = document
        self.fetch_count = 0
        self.fetch_should_fail = False
        self.fetch_error: Optional[Exception] = None

    def _fetch_jwks(self) -> Dict[str, Any]:
        self.fetch_count += 1
        if self.fetch_should_fail:
            err = self.fetch_error or OSError("simulated JWKS endpoint outage")
            raise err
        return self._document

    def set_document(self, document: Dict[str, Any]) -> None:
        self._document = document


# ── configuration ────────────────────────────────────────────────────────────


class TestJwtConfigFromEnv:
    def test_all_unset_returns_none(self) -> None:
        assert JwtConfig.from_env(env={}) is None

    def test_partial_config_raises(self) -> None:
        with pytest.raises(RuntimeError, match="partially configured"):
            JwtConfig.from_env(env={"TAU_X402_JWT_JWKS_URL": "https://x/.well-known/jwks.json"})

    def test_http_jwks_rejected(self) -> None:
        with pytest.raises(RuntimeError, match="https://"):
            JwtConfig.from_env(env={
                "TAU_X402_JWT_JWKS_URL": "http://idp.test/.well-known/jwks.json",
                "TAU_X402_JWT_ISSUER": "http://idp.test/",
                "TAU_X402_JWT_AUDIENCE": "cage",
            })

    def test_full_config_parses(self) -> None:
        cfg = JwtConfig.from_env(env={
            "TAU_X402_JWT_JWKS_URL": "https://idp.test/.well-known/jwks.json",
            "TAU_X402_JWT_ISSUER": "https://idp.test/",
            "TAU_X402_JWT_AUDIENCE": "cage-aud",
            "TAU_X402_JWT_TENANT_CLAIM": "email",
        })
        assert cfg is not None
        assert cfg.jwks_url == "https://idp.test/.well-known/jwks.json"
        assert cfg.issuer == "https://idp.test/"
        assert cfg.audience == "cage-aud"
        assert cfg.tenant_claim == "email"


# ── happy-path verification ──────────────────────────────────────────────────


class TestVerifyHappyPath:
    def test_rs256_token_verifies(self) -> None:
        kp = _make_rsa_jwk("rsa-k1")
        cache = FakeJwksCache({"keys": [kp["jwk"]]})
        cfg = JwtConfig(
            jwks_url=cache._jwks_url,
            issuer="https://idp.test/",
            audience="cage-test",
        )
        v = JwtVerifier(cfg, jwks_cache=cache)
        token = _make_token(kp["priv_pem"], "RS256", "rsa-k1")
        claims = v.verify(token)
        assert claims["sub"] == "user-abc"
        assert claims["iss"] == "https://idp.test/"

    def test_es256_token_verifies(self) -> None:
        kp = _make_ec_jwk("ec-k1")
        cache = FakeJwksCache({"keys": [kp["jwk"]]})
        cfg = JwtConfig(
            jwks_url=cache._jwks_url,
            issuer="https://idp.test/",
            audience="cage-test",
        )
        v = JwtVerifier(cfg, jwks_cache=cache)
        token = _make_token(kp["priv_pem"], "ES256", "ec-k1")
        claims = v.verify(token)
        assert claims["sub"] == "user-abc"


# ── claim checks ─────────────────────────────────────────────────────────────


class TestClaimChecks:
    def _setup(self, *, audience: str = "cage-test") -> tuple[JwtVerifier, Dict[str, Any], FakeJwksCache]:
        kp = _make_rsa_jwk("kp1")
        cache = FakeJwksCache({"keys": [kp["jwk"]]})
        cfg = JwtConfig(
            jwks_url=cache._jwks_url,
            issuer="https://idp.test/",
            audience=audience,
        )
        return JwtVerifier(cfg, jwks_cache=cache), kp, cache

    def test_wrong_issuer_raises_claim_error(self) -> None:
        v, kp, _ = self._setup()
        bad = _make_token(kp["priv_pem"], "RS256", "kp1", iss="https://evil.example/")
        with pytest.raises(JwtClaimError):
            v.verify(bad)

    def test_wrong_audience_raises_claim_error(self) -> None:
        v, kp, _ = self._setup()
        bad = _make_token(kp["priv_pem"], "RS256", "kp1", aud="different-aud")
        with pytest.raises(JwtClaimError):
            v.verify(bad)

    def test_expired_token_raises_expired_error(self) -> None:
        v, kp, _ = self._setup()
        # exp in the past and outside the 10s skew window.
        bad = _make_token(kp["priv_pem"], "RS256", "kp1", exp_offset=-60)
        with pytest.raises(JwtExpiredError):
            v.verify(bad)

    def test_nbf_future_raises_expired_error(self) -> None:
        v, kp, _ = self._setup()
        bad = _make_token(kp["priv_pem"], "RS256", "kp1", nbf_offset=3600, iat_offset=0)
        with pytest.raises(JwtExpiredError):
            v.verify(bad)

    def test_expired_within_skew_is_accepted(self) -> None:
        v, kp, _ = self._setup()
        # exp 5s in the past — inside default 10s skew.
        tok = _make_token(kp["priv_pem"], "RS256", "kp1", exp_offset=-5)
        claims = v.verify(tok)
        assert claims["sub"] == "user-abc"


# ── tampering / signature ────────────────────────────────────────────────────


class TestSignatureChecks:
    def test_tampered_signature_raises_invalid(self) -> None:
        kp = _make_rsa_jwk("kp1")
        cache = FakeJwksCache({"keys": [kp["jwk"]]})
        cfg = JwtConfig(jwks_url=cache._jwks_url, issuer="https://idp.test/", audience="cage-test")
        v = JwtVerifier(cfg, jwks_cache=cache)
        token = _make_token(kp["priv_pem"], "RS256", "kp1")
        # Flip a byte in the signature segment.
        header, payload, sig = token.split(".")
        bad = ".".join([header, payload, sig[:-4] + "AAAA"])
        with pytest.raises(JwtInvalidError):
            v.verify(bad)

    def test_hs256_rejected_by_allowlist(self) -> None:
        cache = FakeJwksCache({"keys": []})
        cfg = JwtConfig(jwks_url=cache._jwks_url, issuer="https://idp.test/", audience="cage-test")
        v = JwtVerifier(cfg, jwks_cache=cache)
        # Mint an HS256 token — this is the classic "alg=HS256 with the
        # public key as secret" attack. Must be rejected at the header
        # check before the key lookup.
        now = int(time.time())
        bad = jwt.encode(
            {"iss": "https://idp.test/", "aud": "cage-test", "sub": "u", "exp": now + 3600},
            key="some-shared-secret",
            algorithm="HS256",
            headers={"kid": "kp1"},
        )
        with pytest.raises(JwtInvalidError, match="allowlist"):
            v.verify(bad)

    def test_alg_none_rejected(self) -> None:
        cache = FakeJwksCache({"keys": []})
        cfg = JwtConfig(jwks_url=cache._jwks_url, issuer="https://idp.test/", audience="cage-test")
        v = JwtVerifier(cfg, jwks_cache=cache)
        # PyJWT refuses alg=none unless explicitly allowed; we also
        # reject at the allowlist check.
        with pytest.raises(JwtInvalidError):
            v.verify("eyJhbGciOiJub25lIn0.e30.")  # header: {"alg":"none"}, empty payload


# ── JWKS cache behaviour ─────────────────────────────────────────────────────


class TestJwksCacheBehavior:
    def test_unknown_kid_triggers_refresh(self) -> None:
        kp1 = _make_rsa_jwk("kp1")
        kp2 = _make_rsa_jwk("kp2")
        # Start with only kp1 in the JWKS doc. Refresh will add kp2.
        cache = FakeJwksCache({"keys": [kp1["jwk"]]})
        cache.prewarm()
        assert cache.fetch_count == 1
        cfg = JwtConfig(jwks_url=cache._jwks_url, issuer="https://idp.test/", audience="cage-test")
        v = JwtVerifier(cfg, jwks_cache=cache)

        # Rotate: new JWKS doc contains both.
        cache.set_document({"keys": [kp1["jwk"], kp2["jwk"]]})
        token_with_kp2 = _make_token(kp2["priv_pem"], "RS256", "kp2")
        claims = v.verify(token_with_kp2)
        assert claims["sub"] == "user-abc"
        # Exactly one extra fetch triggered by the kid miss.
        assert cache.fetch_count == 2

    def test_unknown_kid_after_refresh_raises_key_fetch(self) -> None:
        kp_good = _make_rsa_jwk("kp1")
        kp_evil = _make_rsa_jwk("evil")
        cache = FakeJwksCache({"keys": [kp_good["jwk"]]})
        cfg = JwtConfig(jwks_url=cache._jwks_url, issuer="https://idp.test/", audience="cage-test")
        v = JwtVerifier(cfg, jwks_cache=cache)

        # Evil signs a token with a kid the IdP never published.
        token = _make_token(kp_evil["priv_pem"], "RS256", "evil")
        with pytest.raises(JwtKeyFetchError):
            v.verify(token)

    def test_jwks_unreachable_preserves_last_good_cache(self) -> None:
        kp = _make_rsa_jwk("kp1")
        cache = FakeJwksCache({"keys": [kp["jwk"]]})
        cache.prewarm()
        cfg = JwtConfig(jwks_url=cache._jwks_url, issuer="https://idp.test/", audience="cage-test")
        v = JwtVerifier(cfg, jwks_cache=cache)

        # Endpoint goes down. A token with a known kid still verifies
        # (fail-open on refresh — we don't needlessly refresh for hits).
        cache.fetch_should_fail = True
        token = _make_token(kp["priv_pem"], "RS256", "kp1")
        claims = v.verify(token)
        assert claims["sub"] == "user-abc"

    def test_first_fetch_failure_fails_closed(self) -> None:
        cache = FakeJwksCache({"keys": []})
        cache.fetch_should_fail = True
        with pytest.raises(JwtKeyFetchError):
            cache.prewarm()

    def test_unknown_kid_with_failed_refresh_raises(self) -> None:
        kp = _make_rsa_jwk("kp1")
        cache = FakeJwksCache({"keys": [kp["jwk"]]})
        cache.prewarm()
        cfg = JwtConfig(jwks_url=cache._jwks_url, issuer="https://idp.test/", audience="cage-test")
        v = JwtVerifier(cfg, jwks_cache=cache)
        # Endpoint goes down AND the token carries a kid we never saw.
        cache.fetch_should_fail = True
        evil = _make_rsa_jwk("unknown")
        token = _make_token(evil["priv_pem"], "RS256", "unknown")
        with pytest.raises(JwtKeyFetchError):
            v.verify(token)


# ── tenant mapping ───────────────────────────────────────────────────────────


class TestTenantMapping:
    def _verifier(self, tenant_claim: str = "sub") -> tuple[JwtVerifier, Dict[str, Any]]:
        kp = _make_rsa_jwk("kp1")
        cache = FakeJwksCache({"keys": [kp["jwk"]]})
        cfg = JwtConfig(
            jwks_url=cache._jwks_url,
            issuer="https://idp.test/",
            audience="cage-test",
            tenant_claim=tenant_claim,
        )
        return JwtVerifier(cfg, jwks_cache=cache), kp

    def test_tenant_from_sub(self) -> None:
        v, kp = self._verifier("sub")
        token = _make_token(kp["priv_pem"], "RS256", "kp1", sub="tenant-42")
        claims = v.verify(token)
        assert v.tenant_from_claims(claims) == "tenant-42"

    def test_tenant_from_email(self) -> None:
        v, kp = self._verifier("email")
        token = _make_token(
            kp["priv_pem"], "RS256", "kp1",
            extra_claims={"email": "ops@acme.example"},
        )
        claims = v.verify(token)
        assert v.tenant_from_claims(claims) == "ops@acme.example"

    def test_tenant_from_custom_claim(self) -> None:
        v, kp = self._verifier("https://cage.example/tenant_id")
        token = _make_token(
            kp["priv_pem"], "RS256", "kp1",
            extra_claims={"https://cage.example/tenant_id": "acme-inc"},
        )
        claims = v.verify(token)
        assert v.tenant_from_claims(claims) == "acme-inc"

    def test_missing_tenant_claim_raises(self) -> None:
        v, kp = self._verifier("tenant_id")
        token = _make_token(kp["priv_pem"], "RS256", "kp1")
        claims = v.verify(token)
        with pytest.raises(JwtClaimError, match="missing"):
            v.tenant_from_claims(claims)

    def test_non_string_tenant_claim_raises(self) -> None:
        v, kp = self._verifier("tenant_id")
        token = _make_token(
            kp["priv_pem"], "RS256", "kp1",
            extra_claims={"tenant_id": 42},
        )
        claims = v.verify(token)
        with pytest.raises(JwtClaimError, match="non-empty string"):
            v.tenant_from_claims(claims)


# ── SaaS integration ─────────────────────────────────────────────────────────


try:
    from fastapi.testclient import TestClient  # noqa: E402 — guarded
    from daemon.server import CageDaemon  # noqa: E402 — guarded
    from saas.app import SaasConfig, create_app  # noqa: E402 — guarded
    from saas.billing import NullBillingReporter  # noqa: E402 — guarded
    _SAAS_IMPORTS_OK = True
except Exception:
    _SAAS_IMPORTS_OK = False


SECRET_HEX = "a" * 64


@pytest.fixture
def daemon_socket() -> Iterator[str]:
    """Minimal CageDaemon running on a short UDS path, with one invariant seeded."""
    if not _SAAS_IMPORTS_OK:
        pytest.skip("saas dependencies not available")
    fd, path = tempfile.mkstemp(prefix="saas-jwt-", suffix=".sock", dir="/tmp")
    os.close(fd)
    os.unlink(path)

    d = CageDaemon(socket_path=path)
    t = threading.Thread(target=d.serve_forever, daemon=True)
    t.start()
    for _ in range(50):
        if os.path.exists(path):
            break
        time.sleep(0.01)
    import socket as _socket
    s = _socket.socket(_socket.AF_UNIX, _socket.SOCK_STREAM)
    s.connect(path)
    s.sendall((json.dumps({
        "op": "declare_x402",
        "kind": "max_per_call",
        "max_amount": "100.00",
    }) + "\n").encode())
    s.recv(1024)
    s.close()
    try:
        yield path
    finally:
        d.shutdown()
        t.join(timeout=1.0)


@pytest.mark.skipif(not _SAAS_IMPORTS_OK, reason="saas deps missing")
class TestSaasAuthIntegration:
    """_authed_tenant precedence: JWT first when configured, bearer fallback."""

    def _build_client(
        self,
        daemon_socket: str,
        *,
        enable_jwt: bool,
        api_keys: Optional[Dict[str, str]] = None,
        extra_cache_keys: Optional[List[Dict[str, Any]]] = None,
    ) -> tuple[TestClient, Optional[Dict[str, Any]]]:
        """Return (client, rsa_keypair_or_None). When enable_jwt=True we
        install a JwtVerifier backed by FakeJwksCache via monkeypatching
        the verifier post-construction."""
        api_keys = api_keys if api_keys is not None else {"acme": "sk_test_acme_123"}
        jwt_cfg = None
        rsa_kp = None
        fake_cache = None
        if enable_jwt:
            rsa_kp = _make_rsa_jwk("saas-kp-1")
            keys = [rsa_kp["jwk"]]
            if extra_cache_keys:
                keys.extend(extra_cache_keys)
            fake_cache = FakeJwksCache({"keys": keys})
            jwt_cfg = JwtConfig(
                jwks_url=fake_cache._jwks_url,
                issuer="https://idp.test/",
                audience="cage-saas",
            )
        cfg = SaasConfig(
            api_keys=api_keys,
            socket_path=daemon_socket,
            hmac_secret=bytes.fromhex(SECRET_HEX),
            billing=NullBillingReporter(),
            jwt=jwt_cfg,
        )
        # Monkey-patch JwtVerifier to use the fake cache. The create_app
        # factory builds its own verifier; we swap the cache in by
        # patching saas.auth_jwt.JwksCache.__init__ to return our fake
        # via a subclass. Simpler: patch at import site.
        if enable_jwt:
            import saas.auth_jwt as auth_jwt_mod
            original_verifier_init = auth_jwt_mod.JwtVerifier.__init__

            def _patched_init(self, config, *, jwks_cache=None):  # type: ignore[no-untyped-def]
                original_verifier_init(self, config, jwks_cache=fake_cache)

            auth_jwt_mod.JwtVerifier.__init__ = _patched_init  # type: ignore[method-assign]
            try:
                client = TestClient(create_app(cfg))
            finally:
                auth_jwt_mod.JwtVerifier.__init__ = original_verifier_init  # type: ignore[method-assign]
        else:
            client = TestClient(create_app(cfg))
        return client, rsa_kp

    def test_api_keys_only_still_works(self, daemon_socket: str) -> None:
        """Regression: with JWT unconfigured, existing bearer flow is unchanged."""
        client, _ = self._build_client(daemon_socket, enable_jwt=False)
        r = client.get("/v1/health")
        assert r.status_code == 200

        r = client.post(
            "/v1/check",
            headers={"Authorization": "Bearer sk_test_acme_123"},
            json={"amount": "50", "provider": "a", "counterparty": "b", "timestamp": 1700000000, "currency": "USDC"},
        )
        assert r.status_code == 200
        assert r.headers["X-Policy-Verdict"] == "permit"

    def test_jwt_preferred_when_configured(self, daemon_socket: str) -> None:
        client, kp = self._build_client(daemon_socket, enable_jwt=True)
        token = _make_token(
            kp["priv_pem"], "RS256", "saas-kp-1",
            iss="https://idp.test/", aud="cage-saas", sub="tenant-from-jwt",
        )
        r = client.post(
            "/v1/check",
            headers={"Authorization": f"Bearer {token}"},
            json={"amount": "50", "provider": "a", "counterparty": "b", "timestamp": 1700000000, "currency": "USDC"},
        )
        assert r.status_code == 200, r.text

        # Usage is recorded under the JWT-derived tenant id, not the static key.
        r2 = client.get("/v1/usage", headers={"Authorization": f"Bearer {token}"})
        assert r2.status_code == 200
        body = r2.json()
        assert body["tenant"] == "tenant-from-jwt"
        assert body["counters"]["permit"] >= 1

    def test_api_key_fallback_with_jwt_configured(self, daemon_socket: str) -> None:
        """A non-JWT token still works if it matches the API-key map."""
        client, _ = self._build_client(daemon_socket, enable_jwt=True)
        r = client.post(
            "/v1/check",
            headers={"Authorization": "Bearer sk_test_acme_123"},
            json={"amount": "50", "provider": "a", "counterparty": "b", "timestamp": 1700000000, "currency": "USDC"},
        )
        assert r.status_code == 200, r.text

    def test_neither_match_returns_401(self, daemon_socket: str) -> None:
        client, _ = self._build_client(daemon_socket, enable_jwt=True)
        r = client.post(
            "/v1/check",
            headers={"Authorization": "Bearer totally_not_a_jwt_and_not_an_api_key"},
            json={"amount": "50", "provider": "a", "counterparty": "b", "timestamp": 1700000000, "currency": "USDC"},
        )
        assert r.status_code == 401

    def test_health_endpoint_no_auth(self, daemon_socket: str) -> None:
        client, _ = self._build_client(daemon_socket, enable_jwt=True)
        r = client.get("/v1/health")
        assert r.status_code == 200
        assert r.json()["status"] == "ok"


# ── misc ─────────────────────────────────────────────────────────────────────


class TestAllowlist:
    def test_allowlist_exactly_rs256_es256(self) -> None:
        assert ALLOWED_ALGORITHMS == ("RS256", "ES256")
