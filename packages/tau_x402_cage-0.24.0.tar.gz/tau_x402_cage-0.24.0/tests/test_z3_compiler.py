"""Tests for the fragment-v2 z3 compiler + Z3ConsistencyProver."""
from __future__ import annotations

from decimal import Decimal

import pytest

from adapter.invariants import (
    CounterpartyConstraint,
    MaxPerCall,
    ProviderAllowlist,
    RetryRateLimit,
    RollingWindowCap,
    SpendingCap,
)

# Skip the whole module if z3 isn't importable.
z3 = pytest.importorskip("z3", reason="z3-solver not installed")

from adapter.prover import (
    Contradiction,
    InconclusiveProof,
    ProofToken,
    Z3ConsistencyProver,
)
from adapter.z3_compiler import (
    Z3CompileError,
    compile_policy_v2,
    is_fragment_v2_invariant,
)


class TestFragmentV2Membership:
    def test_spending_cap_per_window_is_v2(self) -> None:
        assert is_fragment_v2_invariant(
            SpendingCap(max_amount=Decimal("1000"), scope="per_window", window_seconds=3600)
        )

    def test_spending_cap_per_tx_is_NOT_v2(self) -> None:
        """per_tx is handled by Tau (fragment v1)."""
        assert not is_fragment_v2_invariant(
            SpendingCap(max_amount=Decimal("50"), scope="per_tx")
        )

    def test_rolling_window_cap_is_v2(self) -> None:
        assert is_fragment_v2_invariant(
            RollingWindowCap(max_count=10, window_seconds=60, group_by="provider")
        )

    def test_retry_rate_limit_is_v2(self) -> None:
        assert is_fragment_v2_invariant(RetryRateLimit(min_gap_seconds=30))

    def test_v1_invariants_are_NOT_v2(self) -> None:
        for inv in [
            MaxPerCall(max_amount=Decimal("50")),
            ProviderAllowlist(providers=frozenset({"a"})),
            CounterpartyConstraint(approved_ids=frozenset({"v"})),
        ]:
            assert not is_fragment_v2_invariant(inv)


class TestCompile:
    def test_single_spending_cap_compiles(self) -> None:
        inv = SpendingCap(max_amount=Decimal("1000"), scope="per_window", window_seconds=86400)
        compiled, solver = compile_policy_v2([inv])
        assert compiled.fragment_version == "v2"
        assert compiled.total_invariants == 1
        assert compiled.compile_hash
        assert "(declare-fun" in compiled.smt2_source  # declarations present

    def test_rolling_plus_retry_compiles(self) -> None:
        invs = [
            RollingWindowCap(max_count=10, window_seconds=60, group_by="provider"),
            RetryRateLimit(min_gap_seconds=2),
        ]
        compiled, solver = compile_policy_v2(invs)
        assert compiled.total_invariants == 2

    def test_v1_invariant_rejected(self) -> None:
        with pytest.raises(Z3CompileError, match="not in fragment v2"):
            compile_policy_v2([MaxPerCall(max_amount=Decimal("50"))])

    def test_spending_cap_per_tx_rejected(self) -> None:
        with pytest.raises(Z3CompileError, match="per_tx"):
            compile_policy_v2([SpendingCap(max_amount=Decimal("50"), scope="per_tx")])


class TestZ3Prover:
    def test_single_cap_decides_sat(self) -> None:
        p = Z3ConsistencyProver(timeout_seconds=5, unroll_steps=10)
        result = p.prove([
            SpendingCap(max_amount=Decimal("1000"), scope="per_window", window_seconds=86400),
        ])
        assert isinstance(result, ProofToken)
        assert result.proof_strength == "complete"
        assert result.backend == "z3"
        assert result.fragment_version == "v2"
        assert result.compile_hash

    def test_composed_v2_policy_decides_sat(self) -> None:
        p = Z3ConsistencyProver()
        rules = [
            SpendingCap(max_amount=Decimal("1000"), scope="per_window", window_seconds=86400),
            SpendingCap(max_amount=Decimal("500"), scope="per_window", window_seconds=86400),
            RollingWindowCap(max_count=100, window_seconds=3600, group_by="provider"),
            RetryRateLimit(min_gap_seconds=30),
        ]
        result = p.prove(rules)
        assert isinstance(result, ProofToken)
        assert result.proof_strength == "complete"

    def test_out_of_fragment_contradiction(self) -> None:
        """MaxPerCall is v1, not v2. The z3 prover rejects it cleanly."""
        p = Z3ConsistencyProver()
        result = p.prove([MaxPerCall(max_amount=Decimal("50"))])
        assert isinstance(result, Contradiction)
        assert "fragment v2" in result.reason

    def test_is_available_returns_true_when_z3_installed(self) -> None:
        assert Z3ConsistencyProver.is_available() is True


class TestZ3Unavailable:
    """Run when z3 is NOT installed -- we simulate this via monkeypatch."""

    def test_import_failure_yields_inconclusive(self, monkeypatch) -> None:
        """Temporarily hide the z3 module to exercise the unavailable path."""
        import sys
        real_z3 = sys.modules.pop("z3", None)
        monkeypatch.setitem(sys.modules, "z3", None)
        try:
            p = Z3ConsistencyProver()
            result = p.prove([
                SpendingCap(max_amount=Decimal("100"), scope="per_window", window_seconds=60),
            ])
            assert isinstance(result, InconclusiveProof)
            assert result.category == "unavailable"
        finally:
            if real_z3 is not None:
                sys.modules["z3"] = real_z3
