"""Tests for structured admission rejection reports (Patch 10).

Covers:
  1. ContradictionReport / InconclusiveReport construction and ``to_dict``.
  2. Daemon helpers ``_contradiction_to_report`` / ``_inconclusive_to_report``
     translate prover results correctly.
  3. End-to-end: daemon rejections carry a ``report`` field in the wire
     response while every flat field (``verdict`` / ``reason`` / ``witness``
     / ``backend`` / ``kind`` / ``active_invariants`` / ``prover_mode``)
     remains present and unchanged.
"""
from __future__ import annotations

import json
import os
import socket
import tempfile
import threading
import time
from typing import Iterator

import pytest

from adapter.proof_report import ContradictionReport, InconclusiveReport
from adapter.prover import (
    ConsistencyProver,
    Contradiction,
    InconclusiveProof,
    ProofToken,
    PythonPatternProver,
)
from daemon.server import (
    CageDaemon,
    _contradiction_to_report,
    _inconclusive_to_report,
)


# ── unit: dataclass construction and to_dict stability ──────────────────────


class TestContradictionReport:
    def test_all_fields_populated(self) -> None:
        r = ContradictionReport(
            conflicting_invariants=("A", "B"),
            unsat_explanation="no model",
            suggested_repair="remove one",
            backend="tau",
        )
        assert r.conflicting_invariants == ("A", "B")
        assert r.unsat_explanation == "no model"
        assert r.suggested_repair == "remove one"
        assert r.backend == "tau"

    def test_to_dict_shape_and_types(self) -> None:
        r = ContradictionReport(
            conflicting_invariants=("A", "B"),
            unsat_explanation="x",
            suggested_repair=None,
            backend="python-pattern",
        )
        d = r.to_dict()
        assert d == {
            "kind": "contradiction",
            "conflicting_invariants": ["A", "B"],
            "unsat_explanation": "x",
            "suggested_repair": None,
            "backend": "python-pattern",
        }
        # JSON-safe
        assert json.loads(json.dumps(d)) == d

    def test_to_dict_is_stable_across_calls(self) -> None:
        r = ContradictionReport(
            conflicting_invariants=("L", "R"),
            unsat_explanation="e",
            suggested_repair="s",
            backend="b",
        )
        assert r.to_dict() == r.to_dict()

    def test_frozen_dataclass_cannot_mutate(self) -> None:
        r = ContradictionReport(
            conflicting_invariants=("A", "B"),
            unsat_explanation="e",
            suggested_repair=None,
            backend="b",
        )
        with pytest.raises(Exception):  # FrozenInstanceError
            r.backend = "other"  # type: ignore[misc]


class TestInconclusiveReport:
    def test_defaults_details_to_empty_dict(self) -> None:
        r = InconclusiveReport(category="timeout", reason="r", backend="tau")
        assert r.details == {}

    def test_to_dict_shape_and_types(self) -> None:
        r = InconclusiveReport(
            category="timeout",
            reason="Tau exceeded 10s budget",
            backend="tau",
            details={"budget_s": 10},
        )
        d = r.to_dict()
        assert d == {
            "kind": "inconclusive",
            "category": "timeout",
            "reason": "Tau exceeded 10s budget",
            "backend": "tau",
            "details": {"budget_s": 10},
        }
        assert json.loads(json.dumps(d)) == d

    def test_to_dict_copies_details_snapshot(self) -> None:
        details = {"k": 1}
        r = InconclusiveReport(
            category="other", reason="r", backend="b", details=details,
        )
        d = r.to_dict()
        details["k"] = 99  # mutate source
        assert d["details"] == {"k": 1}  # snapshot unchanged


# ── unit: daemon translation helpers ────────────────────────────────────────


class TestContradictionToReport:
    def test_populates_conflicting_invariants_from_left_right(self) -> None:
        c = Contradiction(left="L", right="R", reason="x", backend="tau")
        rep = _contradiction_to_report(c)
        assert rep.conflicting_invariants == ("L", "R")
        assert rep.unsat_explanation == "x"
        assert rep.backend == "tau"

    def test_sanctioned_reason_produces_sanctioned_repair_hint(self) -> None:
        c = Contradiction(
            left="CounterpartyConstraint(approved=['x'], sanctioned=[])",
            right="CounterpartyConstraint(approved=[], sanctioned=['x'])",
            reason=(
                "Counterparty IDs appear as approved in one rule and "
                "sanctioned in another: ['x']. No intent can satisfy both."
            ),
            backend="python-pattern",
        )
        rep = _contradiction_to_report(c)
        assert rep.suggested_repair is not None
        assert "sanctioned" in rep.suggested_repair.lower()

    def test_disjoint_reason_produces_widen_repair_hint(self) -> None:
        c = Contradiction(
            left="ProviderAllowlist (multi)",
            right="ProviderAllowlist (multi)",
            reason=(
                "2 ProviderAllowlist rules declared with empty pairwise "
                "intersection; no provider satisfies all."
            ),
            backend="python-pattern",
        )
        rep = _contradiction_to_report(c)
        assert rep.suggested_repair is not None
        assert "intersect" in rep.suggested_repair.lower()

    def test_unsupported_fragment_produces_fragment_repair_hint(self) -> None:
        c = Contradiction(
            left="RollingWindowCap",
            right="fragment_v1",
            reason="RollingWindowCap is outside fragment v1",
            backend="tau-compile",
        )
        rep = _contradiction_to_report(c)
        assert rep.suggested_repair is not None
        assert "compat" in rep.suggested_repair.lower()

    def test_unknown_reason_returns_none_repair(self) -> None:
        c = Contradiction(
            left="composed_spec",
            right="composed_spec",
            reason="Tau SMT: some novel shape",
            backend="tau",
        )
        rep = _contradiction_to_report(c)
        assert rep.suggested_repair is None


class TestInconclusiveToReport:
    def test_all_fields_pass_through(self) -> None:
        inc = InconclusiveProof(
            category="timeout",
            reason="deadline 10s",
            backend="tau",
            details={"budget_s": 10},
        )
        rep = _inconclusive_to_report(inc)
        assert rep.category == "timeout"
        assert rep.reason == "deadline 10s"
        assert rep.backend == "tau"
        assert rep.details == {"budget_s": 10}

    def test_none_details_becomes_empty_dict(self) -> None:
        inc = InconclusiveProof(
            category="unavailable", reason="no binary", backend="tau",
        )
        assert inc.details is None
        rep = _inconclusive_to_report(inc)
        assert rep.details == {}


# ── end-to-end via daemon ───────────────────────────────────────────────────


@pytest.fixture
def daemon() -> Iterator[str]:
    """Spin up a CageDaemon over a UDS for the duration of the test."""
    fd, path = tempfile.mkstemp(prefix="report-", suffix=".sock", dir="/tmp")
    os.close(fd)
    os.unlink(path)
    d = CageDaemon(socket_path=path)
    t = threading.Thread(target=d.serve_forever, daemon=True)
    t.start()
    for _ in range(50):
        if os.path.exists(path):
            break
        time.sleep(0.01)
    try:
        yield path
    finally:
        d.shutdown()
        t.join(timeout=1.0)


def _send(path: str, req: dict) -> dict:
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.settimeout(2.0)
    s.connect(path)
    try:
        s.sendall((json.dumps(req) + "\n").encode("utf-8"))
        f = s.makefile("r")
        return json.loads(f.readline())
    finally:
        s.close()


class TestContradictionEndToEnd:
    """Conflicting declare pair -> response has a structured ``report``."""

    def _declare_conflicting_pair(self, daemon: str) -> dict:
        _send(daemon, {
            "op": "declare_x402",
            "kind": "counterparty_constraint",
            "approved_ids": ["vendor_a"],
            "sanctioned_ids": [],
        })
        return _send(daemon, {
            "op": "declare_x402",
            "kind": "counterparty_constraint",
            "approved_ids": [],
            "sanctioned_ids": ["vendor_a"],
        })

    def test_flat_fields_preserved(self, daemon: str) -> None:
        """Every existing wire field must be present unchanged."""
        r = self._declare_conflicting_pair(daemon)
        assert r["verdict"] == "contradiction"
        assert r["kind"] == "counterparty_constraint"
        assert "reason" in r
        assert "witness" in r
        assert r["witness"].keys() == {"left", "right"}
        assert r["backend"] == "python-pattern"
        assert r["active_invariants"] == 1  # first declare still stands
        assert r["prover_mode"] == "compat"

    def test_report_field_present_with_expected_shape(self, daemon: str) -> None:
        r = self._declare_conflicting_pair(daemon)
        assert "report" in r
        rep = r["report"]
        assert rep["kind"] == "contradiction"
        assert isinstance(rep["conflicting_invariants"], list)
        assert len(rep["conflicting_invariants"]) == 2
        assert rep["unsat_explanation"] == r["reason"]  # mirrors flat field
        assert rep["backend"] == r["backend"]
        assert rep["suggested_repair"] is not None
        assert "sanctioned" in rep["suggested_repair"].lower()


# ── inconclusive end-to-end via injected prover ─────────────────────────────


class _InconclusiveTauStub:
    """Stand-in Tau prover that always returns a timeout inconclusive."""

    backend = "tau-stub-inconclusive"

    def prove(
        self,
        invariants,
        predecessor_hash: str | None = None,
    ) -> ProofToken | Contradiction | InconclusiveProof:
        return InconclusiveProof(
            category="timeout",
            reason="Tau exceeded 10s budget (stub)",
            backend="tau",
            details={"budget_s": 10},
        )


class TestInconclusiveEndToEnd:
    """Strict mode + inconclusive Tau -> response has a structured ``report``."""

    def test_strict_mode_inconclusive_response_has_report(self, tmp_path) -> None:
        sock = str(tmp_path / "inc.sock")
        d = CageDaemon(
            socket_path=sock,
            prover=PythonPatternProver(),
            prover_mode="strict",
            tau_prover=_InconclusiveTauStub(),
        )
        resp = d.dispatch({
            "op": "declare_x402", "kind": "max_per_call", "max_amount": "50",
        })
        # Flat fields unchanged
        assert resp["verdict"] == "inconclusive"
        assert resp["category"] == "timeout"  # existing flat extra
        assert resp["prover_mode"] == "strict"
        assert resp["backend"] == "tau"
        # Report field
        assert "report" in resp
        rep = resp["report"]
        assert rep["kind"] == "inconclusive"
        assert rep["category"] == "timeout"
        assert rep["backend"] == "tau"
        assert rep["reason"] == "Tau exceeded 10s budget (stub)"
        assert rep["details"] == {"budget_s": 10}
