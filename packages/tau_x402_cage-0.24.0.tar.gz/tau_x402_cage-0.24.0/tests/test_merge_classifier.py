"""Tests for adapter/merge_classifier.py (v0.14.0).

Covers:
  * ``classify_conflict`` for every category in the taxonomy:
      - semantic (SpendingCap $100 vs $50 same provider)
      - temporal (RetryRateLimit gap mismatch, RollingWindowCap max mismatch)
      - unsupported_fragment (v2 invariant into fragment-v1 deployment)
      - syntactic (defensive — identical repr on both sides)
  * Multiple overlapping classes: one ``ClassifiedConflict`` per class.
  * Category precedence (unsupported_fragment > temporal > semantic).
  * ``diagnose`` produces a non-empty string naming the class.
  * ``BranchMergeConflict`` produced by ``RevisionLog.merge_branch``
    carries a populated ``classified_conflicts`` list.
  * End-to-end daemon round-trip surfaces ``classified_conflicts``.
  * ``conflict_renderer.render_conflict_text`` renders classified output
    when present and falls back to legacy rendering otherwise.
"""

from __future__ import annotations

import json
import os
import socket
import tempfile
import threading
import time
from decimal import Decimal
from pathlib import Path
from typing import Any, Dict, Iterator

import pytest

from adapter.conflict_renderer import render_conflict_text
from adapter.invariants import (
    MaxPerCall,
    ProviderAllowlist,
    RetryRateLimit,
    RollingWindowCap,
    SpendingCap,
)
from adapter.merge_classifier import (
    ClassifiedConflict,
    classify_conflict,
    diagnose,
)
from adapter.policy_revision import (
    BranchMergeConflict,
    PolicyRevision,
    RevisionLog,
)
from adapter.prover import ProofToken
from daemon.server import CageDaemon


# ── helpers ─────────────────────────────────────────────────────────────────


def _spending_cap_entry(
    amount: str = "100",
    scope: str = "per_tx",
    window_seconds: int | None = None,
    provider: str | None = None,
) -> Dict[str, Any]:
    repr_d: Dict[str, Any] = {
        "max_amount": amount,
        "currency": "USDC",
        "scope": scope,
    }
    if window_seconds is not None:
        repr_d["window_seconds"] = window_seconds
    if provider is not None:
        repr_d["provider"] = provider
    return {"class_name": "SpendingCap", "repr": repr_d}


def _max_per_call_entry(amount: str = "20") -> Dict[str, Any]:
    return {
        "class_name": "MaxPerCall",
        "repr": {"max_amount": amount, "currency": "USDC"},
    }


def _retry_entry(gap: int) -> Dict[str, Any]:
    return {"class_name": "RetryRateLimit", "repr": {"min_gap_seconds": gap}}


def _rolling_entry(max_count: int, window: int = 60, group_by: str = "provider") -> Dict[str, Any]:
    return {
        "class_name": "RollingWindowCap",
        "repr": {
            "max_count": max_count,
            "window_seconds": window,
            "group_by": group_by,
        },
    }


def _allowlist_entry(*providers: str) -> Dict[str, Any]:
    return {"class_name": "ProviderAllowlist", "repr": {"providers": sorted(providers)}}


# ── pure classifier tests ───────────────────────────────────────────────────


class TestSemantic:
    """Same class, different values, non-temporal → ``semantic``."""

    def test_spending_cap_per_tx_100_vs_50_is_semantic(self) -> None:
        # Per-tx is fragment v1 — non-temporal — so it must classify as
        # semantic, not temporal.
        src = {"added": [_spending_cap_entry(amount="100", scope="per_tx")], "removed": []}
        dst = {"added": [_spending_cap_entry(amount="50", scope="per_tx")], "removed": []}
        result = classify_conflict(src, dst)
        assert len(result) == 1
        entry = result[0]
        assert entry.class_name == "SpendingCap"
        assert entry.category == "semantic"
        # Diagnosis names both amounts so operators can see them inline.
        assert "100" in entry.diagnosis
        assert "50" in entry.diagnosis

    def test_max_per_call_different_amounts(self) -> None:
        src = {"added": [_max_per_call_entry("10")], "removed": []}
        dst = {"added": [_max_per_call_entry("20")], "removed": []}
        result = classify_conflict(src, dst, src_branch="shadow", dst_branch="prod")
        assert len(result) == 1
        assert result[0].category == "semantic"
        assert "10" in result[0].diagnosis
        assert "20" in result[0].diagnosis
        # Semantic has no auto-repair hint.
        assert result[0].suggested_repair is None


class TestTemporal:
    """Rate-limit / rolling-window / per-window cap conflicts are temporal."""

    def test_retry_rate_limit_30_vs_60_is_temporal(self) -> None:
        src = {"added": [_retry_entry(30)], "removed": []}
        dst = {"added": [_retry_entry(60)], "removed": []}
        result = classify_conflict(src, dst)
        assert len(result) == 1
        assert result[0].class_name == "RetryRateLimit"
        assert result[0].category == "temporal"
        assert "time window" in result[0].diagnosis.lower()

    def test_rolling_window_cap_different_max_count_is_temporal(self) -> None:
        src = {"added": [_rolling_entry(max_count=10)], "removed": []}
        dst = {"added": [_rolling_entry(max_count=20)], "removed": []}
        result = classify_conflict(src, dst)
        assert len(result) == 1
        assert result[0].class_name == "RollingWindowCap"
        assert result[0].category == "temporal"

    def test_spending_cap_per_window_is_temporal(self) -> None:
        # scope="per_window" makes the cap fragment v2 — temporal.
        src = {
            "added": [_spending_cap_entry(amount="100", scope="per_window", window_seconds=3600)],
            "removed": [],
        }
        dst = {
            "added": [_spending_cap_entry(amount="50", scope="per_window", window_seconds=3600)],
            "removed": [],
        }
        result = classify_conflict(src, dst)
        assert len(result) == 1
        assert result[0].category == "temporal"


class TestUnsupportedFragment:
    """v2 invariant merged into fragment-v1-only deployment."""

    def test_v2_invariant_against_v1_only_prover(self) -> None:
        src = {"added": [_retry_entry(30)], "removed": []}
        dst = {"added": [_retry_entry(60)], "removed": []}
        result = classify_conflict(src, dst, prover_supports_v2=False)
        assert len(result) == 1
        assert result[0].category == "unsupported_fragment"
        assert "fragment" in result[0].diagnosis.lower()
        # Must name z3 / upgrade as the repair path.
        assert result[0].suggested_repair is not None
        assert "z3" in result[0].suggested_repair.lower()

    def test_v1_only_conflict_is_still_semantic_when_prover_is_v1(self) -> None:
        # Two MaxPerCall invariants — both v1 — should NOT classify as
        # unsupported even on a v1-only prover.
        src = {"added": [_max_per_call_entry("10")], "removed": []}
        dst = {"added": [_max_per_call_entry("20")], "removed": []}
        result = classify_conflict(src, dst, prover_supports_v2=False)
        assert len(result) == 1
        assert result[0].category == "semantic"


class TestSyntactic:
    """Defensive: identical repr on both sides still lands in the taxonomy."""

    def test_identical_invariants_on_both_sides_detected(self) -> None:
        entry = _max_per_call_entry("10")
        src = {"added": [entry], "removed": []}
        dst = {"added": [entry], "removed": []}
        result = classify_conflict(src, dst)
        assert len(result) == 1
        assert result[0].category == "syntactic"
        assert result[0].suggested_repair is not None


class TestMultipleOverlappingClasses:
    def test_one_entry_per_class(self) -> None:
        src = {
            "added": [
                _max_per_call_entry("10"),
                _spending_cap_entry(amount="100", scope="per_tx"),
            ],
            "removed": [],
        }
        dst = {
            "added": [
                _max_per_call_entry("20"),
                _spending_cap_entry(amount="50", scope="per_tx"),
            ],
            "removed": [],
        }
        result = classify_conflict(src, dst)
        assert len(result) == 2
        classes = sorted(c.class_name for c in result)
        assert classes == ["MaxPerCall", "SpendingCap"]
        for entry in result:
            assert entry.category == "semantic"

    def test_mixed_categories_on_same_conflict(self) -> None:
        # RetryRateLimit → temporal, MaxPerCall → semantic. Both appear.
        src = {
            "added": [_max_per_call_entry("10"), _retry_entry(30)],
            "removed": [],
        }
        dst = {
            "added": [_max_per_call_entry("20"), _retry_entry(60)],
            "removed": [],
        }
        result = classify_conflict(src, dst)
        by_class = {c.class_name: c for c in result}
        assert by_class["MaxPerCall"].category == "semantic"
        assert by_class["RetryRateLimit"].category == "temporal"


class TestDiagnose:
    def test_diagnose_returns_non_empty_for_every_category(self) -> None:
        for cat in ("syntactic", "semantic", "temporal", "unsupported_fragment"):
            c = ClassifiedConflict(
                class_name="MaxPerCall",
                category=cat,  # type: ignore[arg-type]
                src_inv=_max_per_call_entry("10"),
                dst_inv=_max_per_call_entry("20"),
            )
            diag = diagnose(c)
            assert diag
            assert "MaxPerCall" in diag


class TestDictShape:
    def test_to_dict_round_trip_has_all_keys(self) -> None:
        c = ClassifiedConflict(
            class_name="SpendingCap",
            category="semantic",
            src_inv=_spending_cap_entry(),
            dst_inv=_spending_cap_entry(amount="50"),
            diagnosis="test",
            suggested_repair="retract",
        )
        d = c.to_dict()
        assert d["class_name"] == "SpendingCap"
        assert d["category"] == "semantic"
        assert d["src_inv"] is not None
        assert d["dst_inv"] is not None
        assert d["diagnosis"] == "test"
        assert d["suggested_repair"] == "retract"


class TestEmptyAndMalformedInputs:
    def test_disjoint_classes_return_empty_list(self) -> None:
        src = {"added": [_max_per_call_entry("10")], "removed": []}
        dst = {"added": [_retry_entry(30)], "removed": []}
        # No overlapping classes — empty list.
        assert classify_conflict(src, dst) == []

    def test_malformed_entries_are_ignored(self) -> None:
        src = {"added": ["not a dict", {"no_class_name": True}], "removed": []}
        dst = {"added": [_max_per_call_entry()], "removed": []}
        # Nothing overlaps → empty.
        assert classify_conflict(src, dst) == []


# ── RevisionLog integration ─────────────────────────────────────────────────


def _token(config_hash: str, nonce: str, predecessor: str | None = None) -> ProofToken:
    return ProofToken(
        config_hash=config_hash,
        issued_at_unix=1_713_000_000,
        backend="python-pattern",
        proof_strength="pattern",
        nonce=nonce,
        predecessor_hash=predecessor,
        prover_mode="compat",
        fragment_version=None,
        compile_hash=None,
        tau_backend_version=None,
    )


def _rev(
    cfg: str,
    nonce: str,
    invariants: tuple,
    predecessor: str | None = None,
    branch: str = "main",
    depth: int = 0,
) -> PolicyRevision:
    from dataclasses import replace
    base = PolicyRevision.from_proof_token(
        token=_token(cfg, nonce, predecessor),
        invariants=invariants,
        predecessor_revision_id=predecessor,
    )
    return replace(base, branch=branch, revision_depth=depth)


class TestRevisionLogIntegration:
    def test_merge_branch_conflict_populates_classified_conflicts(self) -> None:
        log = RevisionLog()
        r1 = _rev("h1", "n1", invariants=())
        log.append(r1)
        log.create_branch("shadow", from_revision_id=r1.revision_id)
        # Main: MaxPerCall($10). Shadow: MaxPerCall($20). Same class,
        # genuinely different values → semantic.
        r2 = _rev(
            "h2", "n2",
            invariants=(MaxPerCall(max_amount=Decimal("10")),),
            predecessor=r1.revision_id, branch="main", depth=1,
        )
        log.append(r2)
        log.checkout_branch("shadow")
        r3 = _rev(
            "h3", "n3",
            invariants=(MaxPerCall(max_amount=Decimal("20")),),
            predecessor=r1.revision_id, branch="shadow", depth=1,
        )
        log.append(r3)
        result = log.merge_branch("shadow", "main", reviewer="ops")
        assert isinstance(result, BranchMergeConflict)
        # Legacy field still populated.
        assert result.conflicting_invariants
        # v0.14.0 new field: classified, one per class.
        assert result.classified_conflicts
        assert len(result.classified_conflicts) == 1
        entry = result.classified_conflicts[0]
        assert entry["class_name"] == "MaxPerCall"
        assert entry["category"] == "semantic"
        assert "10" in entry["diagnosis"]
        assert "20" in entry["diagnosis"]

    def test_temporal_conflict_via_retry_rate_limit(self) -> None:
        log = RevisionLog()
        r1 = _rev("h1", "n1", invariants=())
        log.append(r1)
        log.create_branch("shadow", from_revision_id=r1.revision_id)
        r2 = _rev(
            "h2", "n2",
            invariants=(RetryRateLimit(min_gap_seconds=30),),
            predecessor=r1.revision_id, branch="main", depth=1,
        )
        log.append(r2)
        log.checkout_branch("shadow")
        r3 = _rev(
            "h3", "n3",
            invariants=(RetryRateLimit(min_gap_seconds=60),),
            predecessor=r1.revision_id, branch="shadow", depth=1,
        )
        log.append(r3)
        result = log.merge_branch("shadow", "main", reviewer="ops")
        assert isinstance(result, BranchMergeConflict)
        assert len(result.classified_conflicts) == 1
        assert result.classified_conflicts[0]["category"] == "temporal"

    def test_to_dict_round_trip_preserves_classified_conflicts(self) -> None:
        log = RevisionLog()
        r1 = _rev("h1", "n1", invariants=())
        log.append(r1)
        log.create_branch("shadow", from_revision_id=r1.revision_id)
        r2 = _rev(
            "h2", "n2",
            invariants=(MaxPerCall(max_amount=Decimal("10")),),
            predecessor=r1.revision_id, branch="main", depth=1,
        )
        log.append(r2)
        log.checkout_branch("shadow")
        r3 = _rev(
            "h3", "n3",
            invariants=(MaxPerCall(max_amount=Decimal("20")),),
            predecessor=r1.revision_id, branch="shadow", depth=1,
        )
        log.append(r3)
        result = log.merge_branch("shadow", "main", reviewer="ops")
        d = result.to_dict()
        assert "classified_conflicts" in d
        assert isinstance(d["classified_conflicts"], list)
        assert len(d["classified_conflicts"]) == 1


# ── daemon end-to-end ───────────────────────────────────────────────────────


def _send(path: str, req: dict) -> dict:
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.settimeout(2.0)
    s.connect(path)
    try:
        s.sendall((json.dumps(req) + "\n").encode("utf-8"))
        f = s.makefile("r")
        return json.loads(f.readline())
    finally:
        s.close()


@pytest.fixture
def daemon_sock(tmp_path) -> Iterator[tuple[str, Path, CageDaemon]]:
    fd, sock = tempfile.mkstemp(prefix="mcls-", suffix=".sock", dir="/tmp")
    os.close(fd)
    os.unlink(sock)
    log_path = tmp_path / "revisions.jsonl"
    daemon = CageDaemon(socket_path=sock, revision_log_path=log_path)
    t = threading.Thread(target=daemon.serve_forever, daemon=True)
    t.start()
    for _ in range(200):
        if os.path.exists(sock):
            try:
                s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
                s.settimeout(0.1)
                s.connect(sock)
                s.close()
                break
            except (ConnectionRefusedError, OSError):
                pass
        time.sleep(0.02)
    try:
        yield sock, log_path, daemon
    finally:
        daemon.shutdown()
        t.join(timeout=1.0)
        if os.path.exists(sock):
            try:
                os.unlink(sock)
            except OSError:
                pass


class TestDaemonEndToEnd:
    def test_daemon_conflict_includes_classified_conflicts(self, daemon_sock) -> None:
        sock, _, _ = daemon_sock
        _send(sock, {"op": "declare_x402", "kind": "max_per_call", "max_amount": "50"})
        _send(sock, {"op": "create_branch", "name": "shadow"})
        _send(sock, {"op": "retract_x402", "kind": "max_per_call", "max_amount": "50"})
        _send(sock, {"op": "declare_x402", "kind": "max_per_call", "max_amount": "40"})
        _send(sock, {"op": "checkout_branch", "name": "shadow"})
        _send(sock, {"op": "retract_x402", "kind": "max_per_call", "max_amount": "50"})
        _send(sock, {"op": "declare_x402", "kind": "max_per_call", "max_amount": "30"})
        r = _send(sock, {"op": "merge_branch",
                         "src": "shadow", "dst": "main", "reviewer": "ops"})
        assert r["verdict"] == "conflict"
        # Legacy field still present.
        assert r["conflicting_invariants"]
        # v0.14.0 new field surfaces on the wire.
        assert r["classified_conflicts"]
        classified = r["classified_conflicts"]
        assert len(classified) == 1
        entry = classified[0]
        assert entry["class_name"] == "MaxPerCall"
        assert entry["category"] == "semantic"


# ── renderer integration ────────────────────────────────────────────────────


class TestRendererWithClassified:
    def test_renderer_uses_classified_when_present(self) -> None:
        conflict = BranchMergeConflict(
            src="shadow", dst="prod",
            src_head="s1", dst_head="d1", common_ancestor="rev-0",
            src_delta={"added": [_max_per_call_entry("10")], "removed": []},
            dst_delta={"added": [_max_per_call_entry("20")], "removed": []},
            conflicting_invariants=[{
                "class_name": "MaxPerCall",
                "src_ops": ["added"], "dst_ops": ["added"],
            }],
            classified_conflicts=[{
                "class_name": "MaxPerCall",
                "category": "semantic",
                "src_inv": _max_per_call_entry("10"),
                "dst_inv": _max_per_call_entry("20"),
                "diagnosis": "MaxPerCall: both branches declared conflicting values (10 vs 20)",
                "suggested_repair": None,
            }],
        )
        out = render_conflict_text(conflict)
        assert "[semantic]" in out
        assert "MaxPerCall" in out
        assert "conflicting values" in out

    def test_renderer_falls_back_to_legacy_when_classified_missing(self) -> None:
        conflict = BranchMergeConflict(
            src="shadow", dst="prod",
            src_head="s1", dst_head="d1", common_ancestor="rev-0",
            src_delta={"added": [_max_per_call_entry("10")], "removed": []},
            dst_delta={"added": [_max_per_call_entry("20")], "removed": []},
            conflicting_invariants=[{
                "class_name": "MaxPerCall",
                "src_ops": ["added"], "dst_ops": ["added"],
            }],
            classified_conflicts=[],
        )
        out = render_conflict_text(conflict)
        # No classified header, but legacy rendering still produces class name.
        assert "[semantic]" not in out
        assert "MaxPerCall" in out
        assert "shadow" in out

    def test_renderer_prints_repair_hint_when_present(self) -> None:
        conflict_dict = {
            "src": "shadow", "dst": "prod",
            "src_head": "s1", "dst_head": "d1", "common_ancestor": "rev-0",
            "src_delta": {"added": [_retry_entry(30)], "removed": []},
            "dst_delta": {"added": [_retry_entry(60)], "removed": []},
            "conflicting_invariants": [{
                "class_name": "RetryRateLimit",
                "src_ops": ["added"], "dst_ops": ["added"],
            }],
            "classified_conflicts": [{
                "class_name": "RetryRateLimit",
                "category": "temporal",
                "src_inv": _retry_entry(30),
                "dst_inv": _retry_entry(60),
                "diagnosis": "RetryRateLimit gap mismatch",
                "suggested_repair": "Decide which window applies.",
            }],
        }
        out = render_conflict_text(conflict_dict)
        assert "[temporal]" in out
        assert "Suggested repair:" in out
        assert "Decide which window" in out
