"""Tests for the v0.7.0 incremental z3 push/pop backend.

Acceptance criteria (from the v0.7.0 brief):
  (a) adding N invariants incrementally vs full-composition gives
      identical verdicts on a representative battery;
  (b) the incremental_hits counter increments on add/remove/update;
  (c) removal pops back to the correct frame;
  (d) update = pop+push atomically (one hit per logical op);
  (e) branching: can reset to an earlier checkpoint.

Style mirrors `tests/test_pointwise_revision_moat.py`.
"""
from __future__ import annotations

from decimal import Decimal
from pathlib import Path
from typing import Any

import pytest

from adapter.invariants import (
    MaxPerCall,
    ProviderAllowlist,
    RetryRateLimit,
    RollingWindowCap,
    SpendingCap,
)

# Skip the whole module if z3 isn't importable.
z3 = pytest.importorskip("z3", reason="z3-solver not installed")

from adapter.prover import (
    Contradiction,
    InconclusiveProof,
    IncrementalZ3Prover,
    ProofToken,
    PythonPatternProver,
    Z3ConsistencyProver,
)
from adapter.z3_compiler import compile_invariant_v2, frame_tag
from daemon.server import CageDaemon


# ── canonical v2 battery used by parity tests ────────────────────────────────


def _battery() -> list:
    """Representative fragment-v2 battery for parity checks.

    Each entry is an invariant that fragment v2 decides on its own.
    The set is deliberately heterogeneous: mixes SpendingCap (per_window
    and per_provider_per_window), RollingWindowCap, and RetryRateLimit so
    the test exercises every v2 emission path.
    """
    return [
        SpendingCap(max_amount=Decimal("1000"), scope="per_window", window_seconds=86400),
        SpendingCap(max_amount=Decimal("200"), scope="per_provider_per_window",
                    window_seconds=3600, provider="anthropic"),
        RollingWindowCap(max_count=100, window_seconds=3600, group_by="provider"),
        RetryRateLimit(min_gap_seconds=30),
    ]


# ── (a) parity with full-composition prover ──────────────────────────────────


class TestAcceptanceA_ParityWithFullCompose:
    def test_incremental_matches_full_on_full_battery(self) -> None:
        """N invariants added one-by-one through push/pop must yield the
        same verdict as the non-incremental full-composition prover."""
        battery = _battery()
        full = Z3ConsistencyProver()
        full_result = full.prove(battery)
        assert isinstance(full_result, ProofToken)
        assert full_result.proof_strength == "complete"

        inc = IncrementalZ3Prover()
        last = None
        for inv in battery:
            last = inc.prove_delta(added=[inv])
        assert isinstance(last, ProofToken)
        assert last.proof_strength == "complete"
        assert last.backend == "z3-incremental"
        assert last.fragment_version == "v2"

    def test_incremental_matches_full_on_subsets(self) -> None:
        """Every prefix of the battery must decide SAT under both paths."""
        battery = _battery()
        full = Z3ConsistencyProver()
        inc = IncrementalZ3Prover()
        for k in range(1, len(battery) + 1):
            prefix = battery[:k]
            full_r = full.prove(prefix)
            # Reset the incremental prover for each prefix so we compare
            # apples-to-apples; the add-then-check sequence is what we
            # compare in the sister test above.
            inc.reset()
            inc_r = None
            for inv in prefix:
                inc_r = inc.prove_delta(added=[inv])
            assert type(full_r) is type(inc_r), (
                f"prefix k={k}: types differ "
                f"(full={type(full_r).__name__} vs inc={type(inc_r).__name__})"
            )

    def test_single_invariant_sat(self) -> None:
        inc = IncrementalZ3Prover()
        result = inc.prove_delta(added=[
            SpendingCap(max_amount=Decimal("500"), scope="per_window",
                        window_seconds=3600),
        ])
        assert isinstance(result, ProofToken)
        assert result.backend == "z3-incremental"


# ── (b) incremental_hits counter increments ──────────────────────────────────


class TestAcceptanceB_HitsCounter:
    def test_add_increments_hits(self) -> None:
        inc = IncrementalZ3Prover()
        assert inc.metrics()["incremental_hits"] == 0
        inc.prove_delta(added=[
            SpendingCap(max_amount=Decimal("100"), scope="per_window",
                        window_seconds=60),
        ])
        assert inc.metrics()["incremental_hits"] == 1

    def test_remove_increments_hits(self) -> None:
        inc = IncrementalZ3Prover()
        sc = SpendingCap(max_amount=Decimal("100"), scope="per_window",
                         window_seconds=60)
        inc.prove_delta(added=[sc])
        inc.prove_delta(removed=[sc])
        assert inc.metrics()["incremental_hits"] == 2

    def test_update_counts_as_one_hit(self) -> None:
        inc = IncrementalZ3Prover()
        sc_old = SpendingCap(max_amount=Decimal("100"), scope="per_window",
                             window_seconds=60)
        sc_new = SpendingCap(max_amount=Decimal("200"), scope="per_window",
                             window_seconds=60)
        inc.prove_delta(added=[sc_old])
        # update as separate pop+push: two physical ops, but the
        # update_invariant helper gives one logical op credit.
        inc.update_invariant(sc_old, sc_new)
        # metrics: add was 1 hit, update adds 1 more (atomic swap).
        m = inc.metrics()
        assert m["incremental_hits"] == 2
        assert m["push_depth"] == 1  # net one frame

    def test_full_resolve_counter_increments_on_prove(self) -> None:
        """Calling `prove(invariants)` (not prove_delta) counts as a full
        resolve because it resets the solver and re-pushes from scratch."""
        inc = IncrementalZ3Prover()
        inc.prove([
            SpendingCap(max_amount=Decimal("50"), scope="per_window",
                        window_seconds=60),
        ])
        assert inc.metrics()["full_resolves"] == 1

    def test_push_depth_tracks_stack(self) -> None:
        inc = IncrementalZ3Prover()
        assert inc.metrics()["push_depth"] == 0
        for inv in _battery():
            inc.prove_delta(added=[inv])
        assert inc.metrics()["push_depth"] == len(_battery())


# ── (c) removal pops to correct frame ────────────────────────────────────────


class TestAcceptanceC_RemovalPopsCorrectly:
    def test_remove_middle_frame_rebuilds_stack(self) -> None:
        inc = IncrementalZ3Prover()
        sc1 = SpendingCap(max_amount=Decimal("100"), scope="per_window",
                          window_seconds=60)
        sc2 = SpendingCap(max_amount=Decimal("200"), scope="per_window",
                          window_seconds=120)
        sc3 = SpendingCap(max_amount=Decimal("300"), scope="per_window",
                          window_seconds=180)
        for inv in [sc1, sc2, sc3]:
            inc.prove_delta(added=[inv])
        assert inc.metrics()["push_depth"] == 3
        # Remove the middle frame: stack must contract to 2 and the
        # remaining frames must be sc1 + sc3 (in original add order).
        inc.remove_invariant(sc2)
        assert inc.metrics()["push_depth"] == 2
        remaining_tags = [f["tag"] for f in inc._frames]
        assert remaining_tags == [frame_tag(sc1), frame_tag(sc3)]

    def test_remove_unknown_raises(self) -> None:
        inc = IncrementalZ3Prover()
        sc = SpendingCap(max_amount=Decimal("100"), scope="per_window",
                         window_seconds=60)
        with pytest.raises(KeyError):
            inc.remove_invariant(sc)

    def test_prove_delta_remove_unknown_returns_contradiction(self) -> None:
        inc = IncrementalZ3Prover()
        sc = SpendingCap(max_amount=Decimal("100"), scope="per_window",
                         window_seconds=60)
        r = inc.prove_delta(removed=[sc])
        assert isinstance(r, Contradiction)
        assert "cannot remove" in r.reason.lower() or "not on the stack" in r.reason.lower()


# ── (d) update is atomic pop + push ──────────────────────────────────────────


class TestAcceptanceD_UpdateAtomic:
    def test_update_swaps_in_place(self) -> None:
        inc = IncrementalZ3Prover()
        sc_old = SpendingCap(max_amount=Decimal("100"), scope="per_window",
                             window_seconds=60)
        sc_new = SpendingCap(max_amount=Decimal("200"), scope="per_window",
                             window_seconds=60)
        inc.prove_delta(added=[sc_old])
        inc.update_invariant(sc_old, sc_new)
        assert inc.metrics()["push_depth"] == 1
        # The remaining frame's repr_key must be the NEW invariant's.
        remaining_repr = inc._frames[0]["repr_key"]
        assert remaining_repr == repr(sc_new)

    def test_update_then_check_still_sat(self) -> None:
        """After an update, a fresh check must still yield SAT for a
        trivially satisfiable replacement."""
        inc = IncrementalZ3Prover()
        sc_old = SpendingCap(max_amount=Decimal("100"), scope="per_window",
                             window_seconds=60)
        sc_new = SpendingCap(max_amount=Decimal("500"), scope="per_window",
                             window_seconds=60)
        inc.prove_delta(added=[sc_old])
        inc.update_invariant(sc_old, sc_new)
        verdict, _ = inc.check()
        assert verdict == "sat"

    def test_update_missing_old_does_not_corrupt_stack(self) -> None:
        inc = IncrementalZ3Prover()
        sc_present = SpendingCap(max_amount=Decimal("100"), scope="per_window",
                                 window_seconds=60)
        sc_absent = SpendingCap(max_amount=Decimal("999"), scope="per_window",
                                window_seconds=60)
        sc_new = SpendingCap(max_amount=Decimal("200"), scope="per_window",
                             window_seconds=60)
        inc.prove_delta(added=[sc_present])
        pre_depth = inc.metrics()["push_depth"]
        with pytest.raises(KeyError):
            inc.update_invariant(sc_absent, sc_new)
        # Stack unchanged: a failed update must not leave the solver in
        # a half-applied state.
        assert inc.metrics()["push_depth"] == pre_depth


# ── (e) branching: reset to checkpoint ───────────────────────────────────────


class TestAcceptanceE_BranchingCheckpoint:
    def test_checkpoint_then_reset_drops_later_frames(self) -> None:
        inc = IncrementalZ3Prover()
        sc1 = SpendingCap(max_amount=Decimal("10"), scope="per_window",
                          window_seconds=60)
        sc2 = SpendingCap(max_amount=Decimal("20"), scope="per_window",
                          window_seconds=60)
        sc3 = SpendingCap(max_amount=Decimal("30"), scope="per_window",
                          window_seconds=60)
        inc.prove_delta(added=[sc1])
        checkpoint = inc.branching_checkpoint()
        assert checkpoint == 1
        inc.prove_delta(added=[sc2])
        inc.prove_delta(added=[sc3])
        assert inc.metrics()["push_depth"] == 3
        inc.reset_to_checkpoint(checkpoint)
        assert inc.metrics()["push_depth"] == 1
        # Solver still live and decides the truncated set.
        verdict, _ = inc.check()
        assert verdict == "sat"

    def test_invalid_checkpoint_raises(self) -> None:
        inc = IncrementalZ3Prover()
        with pytest.raises(ValueError):
            inc.reset_to_checkpoint(5)  # deeper than current (0) depth

    def test_reset_full(self) -> None:
        """`reset()` clears the stack but preserves the monotonic counters."""
        inc = IncrementalZ3Prover()
        inc.prove_delta(added=[
            SpendingCap(max_amount=Decimal("10"), scope="per_window",
                        window_seconds=60),
        ])
        hits_before = inc.metrics()["incremental_hits"]
        inc.reset()
        m = inc.metrics()
        assert m["push_depth"] == 0
        # Cumulative counters stay: reset clears state but not history.
        assert m["incremental_hits"] == hits_before


# ── fragment guard ───────────────────────────────────────────────────────────


class TestFragmentGuard:
    def test_v1_invariant_rejected_cleanly(self) -> None:
        inc = IncrementalZ3Prover()
        r = inc.prove_delta(added=[MaxPerCall(max_amount=Decimal("50"))])
        assert isinstance(r, Contradiction)
        assert "fragment v2" in r.reason.lower()

    def test_v1_invariant_does_not_corrupt_stack(self) -> None:
        """A rejected v1 invariant must not leave any frames pushed."""
        inc = IncrementalZ3Prover()
        inc.prove_delta(added=[
            SpendingCap(max_amount=Decimal("10"), scope="per_window",
                        window_seconds=60),
        ])
        depth_before = inc.metrics()["push_depth"]
        r = inc.prove_delta(added=[MaxPerCall(max_amount=Decimal("50"))])
        assert isinstance(r, Contradiction)
        assert inc.metrics()["push_depth"] == depth_before


# ── daemon wiring (v0.7.0 integration) ───────────────────────────────────────


def _daemon_with_z3_incremental(tmp_path) -> CageDaemon:
    """Daemon wired with an incremental z3 prover, compat mode (pattern only
    for v1 + z3 push/pop for v2)."""
    return CageDaemon(
        socket_path=str(tmp_path / "inc.sock"),
        prover=PythonPatternProver(),
        prover_mode="compat",
        z3_incremental_prover=IncrementalZ3Prover(timeout_seconds=5),
    )


class TestDaemonIntegration:
    def test_add_v2_invariant_routes_through_incremental(self, tmp_path) -> None:
        d = _daemon_with_z3_incremental(tmp_path)
        r = d.dispatch({
            "op": "add_invariant",
            "invariant": {
                "kind": "spending_cap",
                "max_amount": "1000",
                "scope": "per_window",
                "window_seconds": 86400,
            },
        })
        assert r["verdict"] == "updated"
        # The z3 prover must have seen at least one incremental hit.
        metrics = d.dispatch({"op": "prover_metrics"})
        assert metrics["verdict"] == "ok"
        assert metrics["z3_incremental_prover"]["incremental_hits"] >= 1
        assert metrics["z3_incremental_prover"]["push_depth"] == 1

    def test_prover_metrics_op_absent_z3_prover(self, tmp_path) -> None:
        """When no incremental prover is wired, prover_metrics op still
        works and omits the z3 section."""
        d = CageDaemon(
            socket_path=str(tmp_path / "p.sock"),
            prover_mode="compat",
        )
        r = d.dispatch({"op": "prover_metrics"})
        assert r["verdict"] == "ok"
        assert "pattern_prover" in r
        assert "z3_incremental_prover" not in r

    def test_v1_invariant_not_routed_to_z3(self, tmp_path) -> None:
        """A fragment-v1 add (MaxPerCall) must NOT touch the z3 prover."""
        d = _daemon_with_z3_incremental(tmp_path)
        r = d.dispatch({
            "op": "add_invariant",
            "invariant": {"kind": "max_per_call", "max_amount": "50"},
        })
        assert r["verdict"] == "updated"
        metrics = d.dispatch({"op": "prover_metrics"})
        # z3 stack untouched: v1 rules don't flow through push/pop.
        assert metrics["z3_incremental_prover"]["push_depth"] == 0

    def test_remove_v2_invariant_pops_frame(self, tmp_path) -> None:
        d = _daemon_with_z3_incremental(tmp_path)
        add = {
            "op": "add_invariant",
            "invariant": {
                "kind": "spending_cap",
                "max_amount": "500",
                "scope": "per_window",
                "window_seconds": 3600,
            },
        }
        d.dispatch(add)
        rem = {
            "op": "remove_invariant",
            "invariant": {
                "kind": "spending_cap",
                "max_amount": "500",
                "scope": "per_window",
                "window_seconds": 3600,
            },
        }
        r = d.dispatch(rem)
        assert r["verdict"] == "retracted"
        metrics = d.dispatch({"op": "prover_metrics"})
        assert metrics["z3_incremental_prover"]["push_depth"] == 0

    def test_update_v2_invariant_swaps_frame(self, tmp_path) -> None:
        d = _daemon_with_z3_incremental(tmp_path)
        d.dispatch({
            "op": "add_invariant",
            "invariant": {
                "kind": "spending_cap",
                "max_amount": "100",
                "scope": "per_window",
                "window_seconds": 60,
            },
        })
        r = d.dispatch({
            "op": "update_invariant",
            "old": {
                "kind": "spending_cap",
                "max_amount": "100",
                "scope": "per_window",
                "window_seconds": 60,
            },
            "new": {
                "kind": "spending_cap",
                "max_amount": "200",
                "scope": "per_window",
                "window_seconds": 60,
            },
        })
        assert r["verdict"] == "updated"
        metrics = d.dispatch({"op": "prover_metrics"})
        # Net one frame: update swapped in place.
        assert metrics["z3_incremental_prover"]["push_depth"] == 1


# ── performance-ish sanity (not a real benchmark) ────────────────────────────


class TestIncrementalIsFastOnBattery:
    def test_incremental_decides_full_battery_under_timeout(self) -> None:
        """End-to-end: adding every v2 invariant in the battery must
        decide SAT inside the prover's default timeout."""
        inc = IncrementalZ3Prover(timeout_seconds=5)
        last = None
        for inv in _battery():
            last = inc.prove_delta(added=[inv])
        assert isinstance(last, ProofToken), (
            f"final verdict was {type(last).__name__}: "
            f"{getattr(last, 'reason', getattr(last, 'category', '?'))}"
        )
