"""Tests for adapter/mutation_governance.py and its daemon wiring.

Covers the four axes of policy-over-policy:
  1. actor authorization (``check_propose``)
  2. approval requirements (``check_approve`` + ApprovalQueue integration)
  3. strict-mode requirement (``check_prover_mode``)
  4. temporal bounds (``check_temporal_bounds``)

Plus: YAML round-trip, env-var fail-closed startup, daemon integration,
and the acceptance scenario where a payroll agent's attempt to change the
provider allowlist is blocked at submit time.
"""
from __future__ import annotations

import os
import socket
import tempfile
import threading
import time
from decimal import Decimal
from pathlib import Path
from typing import Iterator

import pytest

from adapter.approval_queue import ApprovalQueue, ApprovalQueueError, ReviewerVote
from adapter.invariants import (
    CounterpartyConstraint,
    MaxPerCall,
    ProviderAllowlist,
    RetryRateLimit,
    RollingWindowCap,
    SpendingCap,
)
from adapter.mutation_governance import (
    ApprovalRequirement,
    GovernanceLoadError,
    GovernancePolicy,
    MutationActor,
    TemporalRulePolicy,
    load_governance_from_dict,
    load_governance_from_env,
    load_governance_from_path,
)


# Shared fixture policy used across several tests so the assertions stay
# consistent with the enterprise example in docs/mutation_governance.md.
_POLICY_YAML_DICT = {
    "governance": {
        "version": 1,
        "mutation_actors": [
            {
                "id": "agent-payroll",
                "can_propose": ["SpendingCap", "MaxPerCall"],
            },
            {
                "id": "agent-treasury",
                "can_propose": ["ProviderAllowlist", "CounterpartyConstraint"],
            },
            {
                "id": "compliance-bot",
                "can_propose": "*",
            },
        ],
        "approval_requirements": {
            "SpendingCap": {
                "min_reviewers": 1,
                "reviewer_must_differ_from_submitter": True,
            },
            "ProviderAllowlist": {
                "min_reviewers": 2,
                "reviewers_must_differ": True,
            },
        },
        "strict_mode_required_for": [
            "RetryRateLimit",
            "RollingWindowCap",
            "InstabilityGuard",
        ],
        "temporal_rule_policy": {
            "max_window_seconds": 86400,
            "min_window_seconds": 60,
        },
    }
}


@pytest.fixture
def policy() -> GovernancePolicy:
    return load_governance_from_dict(_POLICY_YAML_DICT)


# ── axis 1: check_propose ────────────────────────────────────────────────────


class TestCheckPropose:
    def test_unknown_actor_rejected(self, policy: GovernancePolicy) -> None:
        v = policy.check_propose("ghost-agent", MaxPerCall(max_amount=Decimal("10")))
        assert v.allowed is False
        assert v.reason is not None
        assert "ghost-agent" in v.reason
        assert "not authorized" in v.reason

    def test_wildcard_actor_always_approved(self, policy: GovernancePolicy) -> None:
        v1 = policy.check_propose(
            "compliance-bot", ProviderAllowlist(providers=frozenset({"anthropic"}))
        )
        v2 = policy.check_propose(
            "compliance-bot", MaxPerCall(max_amount=Decimal("50"))
        )
        v3 = policy.check_propose(
            "compliance-bot", RetryRateLimit(min_gap_seconds=60)
        )
        assert v1.allowed and v2.allowed and v3.allowed

    def test_specific_classes_allow(self, policy: GovernancePolicy) -> None:
        v = policy.check_propose(
            "agent-payroll", MaxPerCall(max_amount=Decimal("10"))
        )
        assert v.allowed
        assert v.reason is None

    def test_specific_classes_reject_other(self, policy: GovernancePolicy) -> None:
        # agent-payroll may NOT touch ProviderAllowlist
        v = policy.check_propose(
            "agent-payroll",
            ProviderAllowlist(providers=frozenset({"anthropic"})),
        )
        assert v.allowed is False
        assert "agent-payroll" in v.reason
        assert "ProviderAllowlist" in v.reason

    def test_empty_actor_treated_as_anonymous_allow(
        self, policy: GovernancePolicy
    ) -> None:
        # When the caller doesn't pass actor_id at all, axis 1 is bypassed
        # (other axes still run). This preserves pre-v0.14 call sites that
        # don't wire governance identity.
        v = policy.check_propose(None, MaxPerCall(max_amount=Decimal("10")))
        assert v.allowed
        v2 = policy.check_propose("", MaxPerCall(max_amount=Decimal("10")))
        assert v2.allowed

    def test_required_reviewers_surfaces_through_verdict(
        self, policy: GovernancePolicy
    ) -> None:
        v = policy.check_propose(
            "agent-treasury",
            ProviderAllowlist(providers=frozenset({"openai", "anthropic"})),
        )
        assert v.allowed
        assert v.required_reviewers == 2


# ── axis 2: check_approve ────────────────────────────────────────────────────


class TestCheckApprove:
    def test_single_reviewer_policy_one_approval(
        self, policy: GovernancePolicy
    ) -> None:
        # SpendingCap requires 1 reviewer.
        assert policy.check_approve("SpendingCap", ["alice"]) is True

    def test_dual_reviewer_one_approval_rejected(
        self, policy: GovernancePolicy
    ) -> None:
        assert policy.check_approve("ProviderAllowlist", ["alice"]) is False

    def test_dual_reviewer_two_distinct_approvals(
        self, policy: GovernancePolicy
    ) -> None:
        assert policy.check_approve("ProviderAllowlist", ["alice", "bob"]) is True

    def test_dual_reviewer_same_reviewer_twice(
        self, policy: GovernancePolicy
    ) -> None:
        # reviewers_must_differ=True → duplicate collapsed to 1 distinct
        assert policy.check_approve("ProviderAllowlist", ["alice", "alice"]) is False

    def test_default_requirement_is_single_reviewer(
        self, policy: GovernancePolicy
    ) -> None:
        # Class with no explicit entry falls back to the built-in default
        # (min_reviewers=1, must_differ=True).
        assert policy.check_approve("MaxPerCall", ["alice"]) is True


# ── axis 3: check_prover_mode ────────────────────────────────────────────────


class TestCheckProverMode:
    def test_temporal_class_under_compat_rejected(
        self, policy: GovernancePolicy
    ) -> None:
        assert policy.check_prover_mode("RetryRateLimit", "compat") is False

    def test_temporal_class_under_verified_rejected(
        self, policy: GovernancePolicy
    ) -> None:
        assert policy.check_prover_mode("RollingWindowCap", "verified") is False

    def test_temporal_class_under_strict_allowed(
        self, policy: GovernancePolicy
    ) -> None:
        assert policy.check_prover_mode("RetryRateLimit", "strict") is True
        assert policy.check_prover_mode("RollingWindowCap", "strict") is True
        assert policy.check_prover_mode("InstabilityGuard", "strict") is True

    def test_non_temporal_class_always_allowed(
        self, policy: GovernancePolicy
    ) -> None:
        assert policy.check_prover_mode("MaxPerCall", "compat") is True
        assert policy.check_prover_mode("ProviderAllowlist", "verified") is True


# ── axis 4: check_temporal_bounds ────────────────────────────────────────────


class TestCheckTemporalBounds:
    def test_spending_cap_per_window_in_bounds(
        self, policy: GovernancePolicy
    ) -> None:
        inv = SpendingCap(
            max_amount=Decimal("1000"),
            currency="USDC",
            scope="per_window",
            window_seconds=3600,
        )
        ok, reason = policy.check_temporal_bounds(inv)
        assert ok and reason is None

    def test_spending_cap_exceeds_max(self, policy: GovernancePolicy) -> None:
        inv = SpendingCap(
            max_amount=Decimal("1000"),
            currency="USDC",
            scope="per_window",
            window_seconds=604800,  # 7 days
        )
        ok, reason = policy.check_temporal_bounds(inv)
        assert ok is False
        assert reason is not None
        assert "86400" in reason
        assert "SpendingCap" in reason

    def test_rolling_window_below_min(self, policy: GovernancePolicy) -> None:
        inv = RollingWindowCap(
            max_count=10, window_seconds=30, group_by="provider"
        )
        ok, reason = policy.check_temporal_bounds(inv)
        assert ok is False
        assert reason is not None
        assert "60" in reason

    def test_retry_rate_limit_window_checked(
        self, policy: GovernancePolicy
    ) -> None:
        # min_gap_seconds doubles as the window for governance purposes.
        ok, _reason = policy.check_temporal_bounds(
            RetryRateLimit(min_gap_seconds=30)
        )
        assert ok is False

    def test_non_temporal_invariant_passes(
        self, policy: GovernancePolicy
    ) -> None:
        ok, reason = policy.check_temporal_bounds(
            MaxPerCall(max_amount=Decimal("50"))
        )
        assert ok and reason is None

    def test_spending_cap_per_tx_has_no_window_so_passes(
        self, policy: GovernancePolicy
    ) -> None:
        inv = SpendingCap(
            max_amount=Decimal("50"), currency="USDC", scope="per_tx"
        )
        ok, reason = policy.check_temporal_bounds(inv)
        assert ok and reason is None


# ── YAML round-trip ──────────────────────────────────────────────────────────


class TestYamlRoundTrip:
    def test_dict_to_policy_to_dict(self, policy: GovernancePolicy) -> None:
        out = policy.to_dict()
        rebuilt = load_governance_from_dict(out)
        assert rebuilt == policy

    def test_yaml_file_round_trip(self, tmp_path: Path) -> None:
        yaml = pytest.importorskip("yaml")
        raw = yaml.safe_dump(_POLICY_YAML_DICT)
        path = tmp_path / "gov.yaml"
        path.write_text(raw, encoding="utf-8")
        loaded = load_governance_from_path(path)
        dumped = yaml.safe_dump(loaded.to_dict())
        loaded2 = load_governance_from_dict(yaml.safe_load(dumped))
        assert loaded == loaded2

    def test_flat_shape_tolerated(self) -> None:
        # Operators who hand-write short files often skip the top-level
        # `governance:` key. We accept the flat shape silently when any
        # of the four axis keys are present.
        flat = {
            "mutation_actors": [
                {"id": "a", "can_propose": "*"},
            ],
        }
        p = load_governance_from_dict(flat)
        assert len(p.actors) == 1
        assert p.actors[0].id == "a"
        assert p.actors[0].can_propose_wildcard


# ── load_governance_from_env + fail-closed startup ───────────────────────────


class TestLoadGovernanceFromEnv:
    def test_unset_env_returns_none(self) -> None:
        assert load_governance_from_env({}) is None

    def test_empty_string_env_returns_none(self) -> None:
        assert load_governance_from_env({"TAU_CAGE_GOVERNANCE_YAML": ""}) is None

    def test_missing_yaml_path_raises(self, tmp_path: Path) -> None:
        missing = tmp_path / "nope.yaml"
        with pytest.raises(GovernanceLoadError, match="not found"):
            load_governance_from_env(
                {"TAU_CAGE_GOVERNANCE_YAML": str(missing)}
            )

    def test_loads_yaml_from_env(self, tmp_path: Path) -> None:
        yaml = pytest.importorskip("yaml")
        path = tmp_path / "gov.yaml"
        path.write_text(yaml.safe_dump(_POLICY_YAML_DICT), encoding="utf-8")
        p = load_governance_from_env({"TAU_CAGE_GOVERNANCE_YAML": str(path)})
        assert p is not None
        assert any(a.id == "agent-payroll" for a in p.actors)

    def test_empty_yaml_file_raises(self, tmp_path: Path) -> None:
        path = tmp_path / "empty.yaml"
        path.write_text("", encoding="utf-8")
        with pytest.raises(GovernanceLoadError):
            load_governance_from_path(path)

    def test_unknown_version_raises(self, tmp_path: Path) -> None:
        yaml = pytest.importorskip("yaml")
        path = tmp_path / "gov.yaml"
        path.write_text(
            yaml.safe_dump({"governance": {"version": 999}}), encoding="utf-8"
        )
        with pytest.raises(GovernanceLoadError, match="version"):
            load_governance_from_path(path)

    def test_duplicate_actor_id_raises(self) -> None:
        data = {
            "governance": {
                "version": 1,
                "mutation_actors": [
                    {"id": "dupe", "can_propose": "*"},
                    {"id": "dupe", "can_propose": ["MaxPerCall"]},
                ],
            }
        }
        with pytest.raises(GovernanceLoadError, match="duplicate"):
            load_governance_from_dict(data)

    def test_invalid_can_propose_shape_raises(self) -> None:
        data = {
            "governance": {
                "version": 1,
                "mutation_actors": [
                    {"id": "bad", "can_propose": 42},
                ],
            }
        }
        with pytest.raises(GovernanceLoadError):
            load_governance_from_dict(data)


# ── approval queue integration ───────────────────────────────────────────────


class TestApprovalQueueDualApproval:
    """The queue itself enforces the governance-provided thresholds."""

    def test_single_reviewer_still_works(self) -> None:
        q = ApprovalQueue()
        p = q.submit(
            submitted_by="agent",
            invariants=[MaxPerCall(max_amount=Decimal("10"))],
        )
        out = q.approve(
            proposal_id=p.proposal_id, reviewer="alice", min_reviewers=1
        )
        assert out.status == "approved"
        assert len(out.reviewers) == 1

    def test_dual_reviewer_stays_pending_on_first_approval(self) -> None:
        q = ApprovalQueue()
        p = q.submit(
            submitted_by="agent",
            invariants=[ProviderAllowlist(providers=frozenset({"anthropic"}))],
        )
        first = q.approve(
            proposal_id=p.proposal_id, reviewer="alice", min_reviewers=2
        )
        assert first.status == "pending"
        assert len(first.reviewers) == 1

    def test_dual_reviewer_admits_on_second_distinct_approval(self) -> None:
        q = ApprovalQueue()
        p = q.submit(
            submitted_by="agent",
            invariants=[ProviderAllowlist(providers=frozenset({"anthropic"}))],
        )
        q.approve(p.proposal_id, reviewer="alice", min_reviewers=2)
        second = q.approve(p.proposal_id, reviewer="bob", min_reviewers=2)
        assert second.status == "approved"
        assert {r.reviewer_id for r in second.reviewers} == {"alice", "bob"}

    def test_dual_reviewer_same_reviewer_twice_rejected(self) -> None:
        q = ApprovalQueue()
        p = q.submit(
            submitted_by="agent",
            invariants=[ProviderAllowlist(providers=frozenset({"anthropic"}))],
        )
        q.approve(p.proposal_id, reviewer="alice", min_reviewers=2)
        with pytest.raises(ApprovalQueueError, match="already approved"):
            q.approve(
                p.proposal_id,
                reviewer="alice",
                min_reviewers=2,
                reviewers_must_differ=True,
            )

    def test_backcompat_load_of_old_proposal_has_reviewers_from_scalars(
        self, tmp_path: Path
    ) -> None:
        # Hand-craft a pre-v0.14 JSONL line missing `actor_id` and
        # `reviewers`. from_dict should rebuild the reviewers tuple from
        # `reviewed_by` + `reviewed_at`.
        import json
        from adapter.policy_revision import _serialize_invariant

        line = {
            "proposal_id": "old1",
            "submitted_by": "agent",
            "submitted_at": 100,
            "invariants": [
                _serialize_invariant(MaxPerCall(max_amount=Decimal("50")))
            ],
            "diff_from_revision": None,
            "status": "approved",
            "reviewed_by": "alice",
            "reviewed_at": 200,
            "reason": "ok",
        }
        path = tmp_path / "old.jsonl"
        path.write_text(json.dumps(line) + "\n", encoding="utf-8")
        q = ApprovalQueue.load(path)
        p = q.get("old1")
        assert p is not None
        assert p.status == "approved"
        assert len(p.reviewers) == 1
        assert p.reviewers[0].reviewer_id == "alice"
        assert p.reviewers[0].approved_at_unix == 200


# ── daemon integration ──────────────────────────────────────────────────────


def _send(path: str, req: dict, timeout: float = 2.0) -> dict:
    import json
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.settimeout(timeout)
    s.connect(path)
    try:
        s.sendall((json.dumps(req) + "\n").encode("utf-8"))
        f = s.makefile("r")
        return json.loads(f.readline())
    finally:
        s.close()


@pytest.fixture
def daemon_with_gov(
    tmp_path: Path, policy: GovernancePolicy
) -> Iterator[tuple[str, Path]]:
    from daemon.server import CageDaemon

    fd, sock = tempfile.mkstemp(
        prefix="daemon-gov-", suffix=".sock", dir="/tmp"
    )
    os.close(fd)
    os.unlink(sock)
    q_path = tmp_path / "proposals.jsonl"
    d = CageDaemon(
        socket_path=sock,
        approval_queue_path=q_path,
        governance_policy=policy,
    )
    t = threading.Thread(target=d.serve_forever, daemon=True)
    t.start()
    for _ in range(50):
        if os.path.exists(sock):
            break
        time.sleep(0.01)
    try:
        yield sock, q_path
    finally:
        d.shutdown()
        t.join(timeout=1.0)


@pytest.fixture
def daemon_strict_gov(
    tmp_path: Path, policy: GovernancePolicy
) -> Iterator[str]:
    from daemon.server import CageDaemon

    fd, sock = tempfile.mkstemp(
        prefix="daemon-strict-gov-", suffix=".sock", dir="/tmp"
    )
    os.close(fd)
    os.unlink(sock)
    d = CageDaemon(
        socket_path=sock,
        approval_queue_path=tmp_path / "proposals.jsonl",
        governance_policy=policy,
        prover_mode="strict",
    )
    t = threading.Thread(target=d.serve_forever, daemon=True)
    t.start()
    for _ in range(50):
        if os.path.exists(sock):
            break
        time.sleep(0.01)
    try:
        yield sock
    finally:
        d.shutdown()
        t.join(timeout=1.0)


class TestDaemonGovernanceIntegration:
    def test_propose_from_disallowed_actor_violates(
        self, daemon_with_gov
    ) -> None:
        sock, _q = daemon_with_gov
        resp = _send(
            sock,
            {
                "op": "propose_invariant",
                "submitted_by": "agent-payroll",
                "actor_id": "agent-payroll",
                "invariants": [
                    {
                        "kind": "provider_allowlist",
                        "providers": ["anthropic", "openai"],
                    }
                ],
            },
        )
        assert resp["verdict"] == "error"
        assert resp["category"] == "governance_violation"
        assert "agent-payroll" in resp["reason"]
        assert "ProviderAllowlist" in resp["reason"]

    def test_propose_from_allowed_actor_succeeds(self, daemon_with_gov) -> None:
        sock, _q = daemon_with_gov
        resp = _send(
            sock,
            {
                "op": "propose_invariant",
                "submitted_by": "agent-payroll",
                "actor_id": "agent-payroll",
                "invariants": [
                    {"kind": "max_per_call", "max_amount": "50"},
                ],
            },
        )
        assert resp["verdict"] == "pending_approval"
        assert resp["required_reviewers"] == 1

    def test_propose_from_wildcard_actor_across_classes(
        self, daemon_with_gov
    ) -> None:
        sock, _q = daemon_with_gov
        resp = _send(
            sock,
            {
                "op": "propose_invariant",
                "submitted_by": "compliance-bot",
                "actor_id": "compliance-bot",
                "invariants": [
                    {"kind": "provider_allowlist", "providers": ["openai"]},
                ],
            },
        )
        assert resp["verdict"] == "pending_approval"

    def test_propose_temporal_rule_beyond_bounds_rejected(
        self, daemon_with_gov
    ) -> None:
        # SpendingCap with per_window=604800 (7 days) exceeds the 86400 max
        sock, _q = daemon_with_gov
        resp = _send(
            sock,
            {
                "op": "propose_invariant",
                "submitted_by": "compliance-bot",
                "actor_id": "compliance-bot",
                "invariants": [
                    {
                        "kind": "spending_cap",
                        "max_amount": "1000",
                        "scope": "per_window",
                        "window_seconds": 604800,
                    }
                ],
            },
        )
        assert resp["verdict"] == "error"
        assert resp["category"] == "governance_violation"
        assert "86400" in resp["reason"]

    def test_first_approval_on_dual_class_stays_pending(
        self, daemon_with_gov
    ) -> None:
        sock, _q = daemon_with_gov
        propose = _send(
            sock,
            {
                "op": "propose_invariant",
                "submitted_by": "agent-treasury",
                "actor_id": "agent-treasury",
                "invariants": [
                    {"kind": "provider_allowlist", "providers": ["anthropic"]}
                ],
            },
        )
        pid = propose["proposal_id"]
        first = _send(
            sock,
            {
                "op": "approve_proposal",
                "proposal_id": pid,
                "reviewer": "alice",
                "reason": "first of two",
            },
        )
        assert first["verdict"] == "pending_more_approvals"
        assert first["reviewers_recorded"] == 1
        assert first["reviewers_required"] == 2

    def test_second_distinct_approval_admits(self, daemon_with_gov) -> None:
        sock, _q = daemon_with_gov
        propose = _send(
            sock,
            {
                "op": "propose_invariant",
                "submitted_by": "agent-treasury",
                "actor_id": "agent-treasury",
                "invariants": [
                    {"kind": "provider_allowlist", "providers": ["anthropic"]}
                ],
            },
        )
        pid = propose["proposal_id"]
        _send(
            sock,
            {
                "op": "approve_proposal",
                "proposal_id": pid,
                "reviewer": "alice",
                "reason": "first",
            },
        )
        second = _send(
            sock,
            {
                "op": "approve_proposal",
                "proposal_id": pid,
                "reviewer": "bob",
                "reason": "second",
            },
        )
        assert second["verdict"] == "approved"
        assert second["admission"]["verdict"] == "updated"

    def test_second_approval_same_reviewer_rejected(
        self, daemon_with_gov
    ) -> None:
        sock, _q = daemon_with_gov
        propose = _send(
            sock,
            {
                "op": "propose_invariant",
                "submitted_by": "agent-treasury",
                "actor_id": "agent-treasury",
                "invariants": [
                    {"kind": "provider_allowlist", "providers": ["anthropic"]}
                ],
            },
        )
        pid = propose["proposal_id"]
        _send(
            sock,
            {
                "op": "approve_proposal",
                "proposal_id": pid,
                "reviewer": "alice",
                "reason": "first",
            },
        )
        duplicate = _send(
            sock,
            {
                "op": "approve_proposal",
                "proposal_id": pid,
                "reviewer": "alice",
                "reason": "again",
            },
        )
        assert duplicate["verdict"] == "error"
        assert "already approved" in duplicate["reason"]

    def test_strict_mode_required_class_under_compat_rejected_at_declare(
        self, daemon_with_gov
    ) -> None:
        # retry_rate_limit is in strict_mode_required_for; daemon is compat
        sock, _q = daemon_with_gov
        resp = _send(
            sock,
            {
                "op": "propose_invariant",
                "submitted_by": "compliance-bot",
                "actor_id": "compliance-bot",
                "invariants": [
                    {"kind": "retry_rate_limit", "min_gap_seconds": 60}
                ],
            },
        )
        assert resp["verdict"] == "error"
        assert resp["category"] == "governance_violation"
        assert "strict" in resp["reason"]


# ── acceptance: payroll can't touch provider allowlist ──────────────────────


class TestAcceptance:
    def test_payroll_actor_blocked_from_provider_allowlist(
        self, daemon_with_gov
    ) -> None:
        """Acceptance scenario from the patch brief: an agent-payroll
        attempting to mutate the provider allowlist is blocked at
        submit time with a message naming both the actor and the class.
        """
        sock, _q = daemon_with_gov
        resp = _send(
            sock,
            {
                "op": "propose_invariant",
                "submitted_by": "agent-payroll",
                "actor_id": "agent-payroll",
                "invariants": [
                    {
                        "kind": "provider_allowlist",
                        "providers": ["ransomware-as-a-service"],
                    }
                ],
            },
        )
        assert resp["verdict"] == "error"
        assert resp["category"] == "governance_violation"
        assert "agent-payroll" in resp["reason"]
        assert "ProviderAllowlist" in resp["reason"]
        assert "not authorized" in resp["reason"]


# ── summary / serialization smoke ───────────────────────────────────────────


class TestSummary:
    def test_summary_contains_each_axis(self, policy: GovernancePolicy) -> None:
        s = policy.summary()
        assert "Governance policy v1" in s
        assert "mutation_actors" in s
        assert "approval_requirements" in s
        assert "strict_mode_required_for" in s
        assert "temporal_rule_policy" in s
        assert "agent-payroll" in s
        assert "ProviderAllowlist" in s
