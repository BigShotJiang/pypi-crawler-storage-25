"""Tests for the v0.22.0 Tau-proven prevented_risk witness.

Covers the dual-shape output of :func:`estimate_prevented_risk` when a
prover is supplied, the witness extraction contract on
:class:`TauConsistencyProver`, and the honest fallback when Tau can't
close the bv probe. Twelve tests — one per bullet in the brief plus a
couple of determinism / structural-fallback sanity checks.
"""

from __future__ import annotations

from decimal import Decimal
from typing import Any, Optional

import pytest

from adapter.adaptive_tightening import estimate_prevented_risk
from adapter.prover import TauConsistencyProver


# ── fakes ──────────────────────────────────────────────────────────────────


class _DecisiveProver:
    """Stand-in prover whose ``extract_bv_witness`` always returns a fixed value.

    Models the happy path where Tau's bv probe closes numerically — we
    can't exercise that on the current ltl branch (bv ``<=`` isn't
    numeric), so we simulate it deterministically.
    """

    version_string = "tau-fake-0.0.0"

    def __init__(self, witness_value: int) -> None:
        self._value = witness_value
        self.calls: list[tuple[str, str, int, int]] = []

    def is_available(self) -> bool:
        return True

    def extract_bv_witness(
        self,
        formula: str,
        target_var: str,
        *,
        lower: int = 0,
        upper: int = 0xFFFFFFFFFFFFFFFF,
        max_probes: int = 48,
    ) -> Optional[int]:
        self.calls.append((formula, target_var, lower, upper))
        if self._value < lower or self._value > upper:
            return upper  # clamp to legal search range
        return self._value


class _InconclusiveProver:
    """Prover that always returns None from the witness extraction.

    Models Tau timing out / returning inconclusive on the bv `<=`
    search — the realistic failure mode on the current ltl branch.
    """

    version_string = "tau-inconclusive-0.0.0"
    calls: int = 0

    def is_available(self) -> bool:
        return True

    def extract_bv_witness(
        self,
        formula: str,
        target_var: str,
        *,
        lower: int = 0,
        upper: int = 0xFFFFFFFFFFFFFFFF,
        max_probes: int = 48,
    ) -> Optional[int]:
        self.calls += 1
        return None


class _RaisingProver:
    version_string = "tau-buggy-0.0.0"

    def is_available(self) -> bool:
        return True

    def extract_bv_witness(self, *a: Any, **kw: Any) -> Optional[int]:
        raise RuntimeError("simulated prover crash")


class _UnavailableProver:
    version_string = "unknown"

    def is_available(self) -> bool:
        return False

    def extract_bv_witness(self, *a: Any, **kw: Any) -> Optional[int]:
        return None


# ── 1. Dual shape is triggered by presence of prover ───────────────────────


def test_legacy_shape_when_prover_omitted() -> None:
    """No prover kwarg → byte-identical v0.21.0 output."""
    est = estimate_prevented_risk(
        baseline_velocity=Decimal("40"),
        current_denial_window_s=60,
        currency="USDC",
    )
    assert "proven_upper_bound_usd" not in est
    assert est["based_on"] == "ema_velocity"
    assert est["estimated_spend_blocked"] == "2400.00"


def test_dual_shape_when_prover_supplied() -> None:
    """Passing a prover flips the return shape to the dual form."""
    est = estimate_prevented_risk(
        baseline_velocity=Decimal("40"),
        current_denial_window_s=60,
        currency="USDC",
        prover=_DecisiveProver(witness_value=700_000_000),
        policy_caps={"per_window_cap": Decimal("1000")},
        current_cumulative=Decimal("300"),
    )
    assert est["based_on"] == "tau_bv_witness_plus_ema"
    assert "proven_upper_bound_usd" in est
    assert "observed_trajectory_usd" in est
    # Dual shape carries both figures.
    assert est["observed_trajectory_usd"] == "2400.00"


# ── 2. Basic bound: cap=1000, cumulative=300 ⇒ bound ≤ 700 ─────────────────


def test_live_probe_produces_capped_bound() -> None:
    """Witness_value is clamped to ``cap - current`` headroom."""
    est = estimate_prevented_risk(
        baseline_velocity=Decimal("10"),
        current_denial_window_s=30,
        currency="USDC",
        prover=_DecisiveProver(witness_value=650_000_000),
        policy_caps={"per_window_cap": Decimal("1000")},
        current_cumulative=Decimal("300"),
    )
    # 650 bv-millions = 650 USDC (scale 1e6)
    assert est["proven_upper_bound_usd"] == "650.00"
    assert est["witness_status"] == "tau_bv_live_probe"


def test_witness_clamped_to_bv_upper() -> None:
    """Prover over-shoots; we clamp to the policy ceiling, never above."""
    est = estimate_prevented_risk(
        baseline_velocity=0,
        current_denial_window_s=10,
        currency="USDC",
        prover=_DecisiveProver(witness_value=99_000_000_000),  # > cap
        policy_caps={"per_window_cap": Decimal("1000")},
        current_cumulative=Decimal("300"),
    )
    # bv_upper = (1000 - 300) * 1e6 = 700e6; witness must clamp there.
    assert Decimal(est["proven_upper_bound_usd"]) == Decimal("700.00")


# ── 3. Inconclusive → structural fallback ──────────────────────────────────


def test_inconclusive_falls_back_to_structural() -> None:
    """When Tau can't close, we publish the cap-minus-cumulative reading.

    The policy was admitted consistent by Tau at declare time; the
    structural bound is a sound reading of that admission. We label
    it transparently via ``witness_status`` so auditors see the path.
    """
    prover = _InconclusiveProver()
    est = estimate_prevented_risk(
        baseline_velocity=Decimal("40"),
        current_denial_window_s=60,
        currency="USDC",
        prover=prover,
        policy_caps={"per_window_cap": Decimal("1000")},
        current_cumulative=Decimal("300"),
    )
    assert est["witness_status"] == "policy_structural"
    assert est["proven_upper_bound_usd"] == "700.00"
    assert est["observed_trajectory_usd"] == "2400.00"
    assert prover.calls == 1


def test_raising_prover_falls_back_cleanly() -> None:
    """A prover exception is swallowed and the structural path fires."""
    est = estimate_prevented_risk(
        baseline_velocity=Decimal("5"),
        current_denial_window_s=10,
        currency="USDC",
        prover=_RaisingProver(),
        policy_caps={"per_window_cap": Decimal("500")},
        current_cumulative=Decimal("100"),
    )
    assert est["witness_status"] == "policy_structural"
    assert est["proven_upper_bound_usd"] == "400.00"


# ── 4. Backend version surfaces ────────────────────────────────────────────


def test_witness_backend_version_surfaces() -> None:
    """``witness_backend_version`` is pulled off the prover instance."""
    est = estimate_prevented_risk(
        baseline_velocity=Decimal("10"),
        current_denial_window_s=30,
        currency="USDC",
        prover=_DecisiveProver(witness_value=1_000_000),
        policy_caps={"per_window_cap": Decimal("10")},
        current_cumulative=Decimal("1"),
    )
    assert est["witness_backend_version"] == "tau-fake-0.0.0"


# ── 5. Determinism ─────────────────────────────────────────────────────────


def test_determinism_same_inputs_same_output() -> None:
    """Two identical calls produce byte-identical outputs (no nondeterminism)."""
    kwargs = dict(
        baseline_velocity=Decimal("20"),
        current_denial_window_s=45,
        currency="USDC",
        prover=_DecisiveProver(witness_value=400_000_000),
        policy_caps={"per_window_cap": Decimal("500")},
        current_cumulative=Decimal("100"),
    )
    a = estimate_prevented_risk(**kwargs)  # type: ignore[arg-type]
    b = estimate_prevented_risk(**kwargs)  # type: ignore[arg-type]
    assert a == b


# ── 6. Edge cases ──────────────────────────────────────────────────────────


def test_empty_policy_produces_null_bound() -> None:
    """No cap supplied → ``proven_upper_bound_usd`` is null.

    The brief's "never lies about having a proof" clause: if the caller
    gave us no policy ceiling, we have nothing sound to publish.
    """
    est = estimate_prevented_risk(
        baseline_velocity=Decimal("40"),
        current_denial_window_s=60,
        currency="USDC",
        prover=_DecisiveProver(witness_value=100),
        policy_caps={},
        current_cumulative=Decimal("0"),
    )
    assert est["proven_upper_bound_usd"] is None
    assert est["witness_status"] == "no_policy_ceiling"
    assert est["observed_trajectory_usd"] == "2400.00"


def test_zero_window_produces_zero_trajectory() -> None:
    """window=0 → observed trajectory is exactly zero; bound still honours cap."""
    est = estimate_prevented_risk(
        baseline_velocity=Decimal("40"),
        current_denial_window_s=0,
        currency="USDC",
        prover=_DecisiveProver(witness_value=500_000_000),
        policy_caps={"per_window_cap": Decimal("1000")},
        current_cumulative=Decimal("300"),
    )
    assert est["observed_trajectory_usd"] == "0.00"
    assert Decimal(est["proven_upper_bound_usd"]) == Decimal("500.00")


# ── 7. Confidence labelling ────────────────────────────────────────────────


def test_confidence_scales_with_sample_size() -> None:
    """0 → low; 5 → medium; 20 → high."""
    base = dict(
        baseline_velocity=Decimal("10"),
        current_denial_window_s=10,
        currency="USDC",
        prover=_DecisiveProver(witness_value=1_000_000),
        policy_caps={"per_window_cap": Decimal("10")},
        current_cumulative=Decimal("1"),
    )
    assert estimate_prevented_risk(sample_size=0, **base)["confidence"] == "low"  # type: ignore[arg-type]
    assert estimate_prevented_risk(sample_size=5, **base)["confidence"] == "medium"  # type: ignore[arg-type]
    assert estimate_prevented_risk(sample_size=20, **base)["confidence"] == "high"  # type: ignore[arg-type]


# ── 8. TauConsistencyProver.extract_bv_witness interface ──────────────────


def test_extract_bv_witness_returns_none_when_tau_unavailable(monkeypatch: Any) -> None:
    """No tau binary on PATH → return None; never synthesises a bound."""
    prover = TauConsistencyProver()
    # Ensure is_available() is False: strip env + PATH temporarily.
    monkeypatch.delenv("TAU_BINARY", raising=False)
    monkeypatch.setenv("PATH", "")
    result = prover.extract_bv_witness(
        formula="cageTarget:bv[64] <= { 1000 }:bv[64]",
        target_var="cageTarget",
        upper=1000,
    )
    assert result is None


def test_extract_bv_witness_handles_empty_range() -> None:
    """upper < lower is a degenerate query; return None cleanly."""
    prover = TauConsistencyProver()
    assert prover.extract_bv_witness(
        formula="cageTarget:bv[64] <= { 10 }:bv[64]",
        target_var="cageTarget",
        lower=100,
        upper=50,
    ) is None
