"""Tests for adapter.guaranteed_totality (v0.19.0 Deliverable 3)."""
from __future__ import annotations

import dataclasses
import json
from decimal import Decimal
from types import SimpleNamespace

import pytest

from adapter.guaranteed_errors import GuaranteedFailureCode
from adapter.guaranteed_language import GUARANTEED_LANGUAGE_VERSION
from adapter.guaranteed_totality import TotalityReport, validate_totality
from adapter.invariants import (
    CounterpartyConstraint,
    JurisdictionRule,
    MaxPerCall,
    ProviderAllowlist,
    RollingWindowCap,
    SpendingCap,
)


# ── helpers ────────────────────────────────────────────────────────────


def _mk_policy(invariants, **extra):
    """Build a duck-typed policy-like object for the totality gate."""
    return SimpleNamespace(invariants=tuple(invariants), **extra)


# ── happy path ─────────────────────────────────────────────────────────


def test_totality_passes_on_all_supported_rules():
    policy = _mk_policy(
        [
            MaxPerCall(max_amount=Decimal("50")),
            ProviderAllowlist(providers=frozenset({"anthropic", "openai"})),
            SpendingCap(max_amount=Decimal("25"), scope="per_tx"),
        ]
    )
    report = validate_totality(policy)
    assert report.is_total is True
    assert report.reason_code is None
    assert report.unsupported_nodes == ()
    assert report.language_version == GUARANTEED_LANGUAGE_VERSION


def test_empty_policy_is_vacuously_total():
    """A policy with no invariants has no rule to fail. Consistent with
    the ``conjunction-of-nothing = true`` reading."""
    report = validate_totality(_mk_policy([]))
    assert report.is_total is True
    assert report.reason_code is None


def test_accepts_bare_sequence_of_invariants():
    """Duck-typing: a bare list also works."""
    report = validate_totality(
        [
            MaxPerCall(max_amount=Decimal("50")),
            ProviderAllowlist(providers=frozenset({"a"})),
        ]
    )
    assert report.is_total is True


# ── stage 1: rule-type admission ───────────────────────────────────────


def test_partially_representable_policy_is_rejected_as_non_total():
    """Test 2 from the brief: one rule is in v1.2.0, another is not
    (the nested-composition JurisdictionRule variant). Must reject as
    non-total with a structured reason."""
    policy = _mk_policy(
        [
            MaxPerCall(max_amount=Decimal("50")),  # supported
            # Nested-composition variant: still excluded in v1.2.0.
            JurisdictionRule(
                jurisdiction="EU",
                additional_invariants=(MaxPerCall(max_amount=Decimal("1")),),
            ),
        ]
    )
    report = validate_totality(policy)
    assert report.is_total is False
    assert report.reason_code == (
        GuaranteedFailureCode.UNSUPPORTED_FOR_GUARANTEED_MODE.value
    )
    assert len(report.unsupported_nodes) == 1
    assert "JurisdictionRule" in report.unsupported_nodes[0]


def test_multiple_unsupported_rules_all_surface():
    # v1.2.0 admits enum_bv variants of Jurisdiction / Counterparty; the
    # richer nested-composition and sanctions-negation variants stay out.
    # Two unsupported-variant instances both surface.
    policy = _mk_policy(
        [
            JurisdictionRule(
                jurisdiction="EU",
                additional_invariants=(MaxPerCall(max_amount=Decimal("1")),),
            ),
            CounterpartyConstraint(
                approved_ids=frozenset({"a"}),
                sanctioned_ids=frozenset({"evil-inc"}),
            ),
        ]
    )
    report = validate_totality(policy)
    assert report.is_total is False
    assert report.reason_code == (
        GuaranteedFailureCode.UNSUPPORTED_FOR_GUARANTEED_MODE.value
    )
    assert len(report.unsupported_nodes) == 2


def test_spending_cap_windowed_scope_admitted_in_v1_1():
    """v1.1.0: SpendingCap per_window encodes under past-LTL H."""
    policy = _mk_policy(
        [
            SpendingCap(
                max_amount=Decimal("100"),
                scope="per_window",
                window_seconds=86400,
            )
        ]
    )
    report = validate_totality(policy)
    assert report.is_total is True
    assert report.reason_code is None


def test_non_invariant_objects_are_rejected():
    policy = _mk_policy(["not a real invariant"])  # type: ignore[list-item]
    report = validate_totality(policy)
    assert report.is_total is False
    assert report.reason_code == (
        GuaranteedFailureCode.UNSUPPORTED_FOR_GUARANTEED_MODE.value
    )


# ── stage 2: composition admission ─────────────────────────────────────


def test_unsupported_composition_is_rejected():
    """Policy advertising a disjunctive composition is not total in v1."""
    policy = _mk_policy(
        [MaxPerCall(max_amount=Decimal("50"))],
        composition_form="disjunction",
    )
    report = validate_totality(policy)
    assert report.is_total is False
    assert report.reason_code == (
        GuaranteedFailureCode.UNSUPPORTED_FOR_GUARANTEED_MODE.value
    )
    assert any("disjunction" in n for n in report.unsupported_nodes)


def test_explicit_conjunction_composition_is_admitted():
    policy = _mk_policy(
        [MaxPerCall(max_amount=Decimal("50"))],
        composition_form="conjunction",
    )
    report = validate_totality(policy)
    assert report.is_total is True


# ── stage 3: mutation-form admission ───────────────────────────────────


def test_unsupported_mutation_form_is_rejected():
    policy = _mk_policy(
        [MaxPerCall(max_amount=Decimal("50"))],
        mutation_forms=["loosen_limit"],
    )
    report = validate_totality(policy)
    assert report.is_total is False
    assert report.reason_code == (
        GuaranteedFailureCode.UNSUPPORTED_FOR_GUARANTEED_MODE.value
    )


def test_supported_mutation_forms_pass():
    policy = _mk_policy(
        [MaxPerCall(max_amount=Decimal("50"))],
        mutation_forms=["add_invariant", "tighten_limit"],
    )
    report = validate_totality(policy)
    assert report.is_total is True


# ── stage 4: dry-run encoding failures ─────────────────────────────────


class _BrokenInvariant(MaxPerCall):
    """Fake invariant whose ``_sat_body`` raises a bare exception.

    Used to confirm the totality gate never crashes — it converts an
    encoding exception into a structured ``is_total=False`` report.
    """

    def _sat_body(self) -> str:
        raise RuntimeError("synthetic encoding failure")


def test_dry_run_encode_exception_yields_structured_reason():
    """Test: exception in dry_run_encode → is_total=False with
    structured reason, not a crash."""
    # The class of _BrokenInvariant is "_BrokenInvariant", which isn't
    # in SUPPORTED_RULE_TYPES, so it actually fails at stage 1. Inject
    # into GuaranteedLanguage.SUPPORTED_RULE_TYPES via a pytest monkey-
    # patch isn't clean; instead we test the stage-4 path directly by
    # temporarily patching the tier to include our class name.
    import adapter.guaranteed_language as gl

    original = gl.GuaranteedLanguage.SUPPORTED_RULE_TYPES
    try:
        gl.GuaranteedLanguage.SUPPORTED_RULE_TYPES = frozenset(
            original | {"_BrokenInvariant"}
        )
        policy = _mk_policy([_BrokenInvariant(max_amount=Decimal("50"))])
        report = validate_totality(policy)
    finally:
        gl.GuaranteedLanguage.SUPPORTED_RULE_TYPES = original

    assert report.is_total is False
    assert report.reason_code == (
        GuaranteedFailureCode.TAU_TOTALITY_FAILED.value
    )
    assert any("synthetic encoding failure" in n for n in report.unsupported_nodes)


# ── immutability / shape of the report ─────────────────────────────────


def test_totality_report_is_frozen():
    """dataclass(frozen=True) means any mutation raises."""
    report = validate_totality(_mk_policy([MaxPerCall(max_amount=Decimal("50"))]))
    with pytest.raises(dataclasses.FrozenInstanceError):
        report.is_total = False  # type: ignore[misc]
    with pytest.raises(dataclasses.FrozenInstanceError):
        report.reason_code = "HACKED"  # type: ignore[misc]


def test_unsupported_nodes_is_a_tuple():
    """The unsupported_nodes collection must be immutable."""
    report = validate_totality(_mk_policy([JurisdictionRule(jurisdiction="EU")]))
    assert isinstance(report.unsupported_nodes, tuple)


def test_report_exposes_language_version():
    report = validate_totality(_mk_policy([]))
    assert report.language_version == GUARANTEED_LANGUAGE_VERSION


def test_report_to_dict_is_json_serializable():
    report = validate_totality(
        _mk_policy([MaxPerCall(max_amount=Decimal("50"))])
    )
    blob = json.dumps(report.to_dict())
    assert GUARANTEED_LANGUAGE_VERSION in blob


def test_never_raises_on_malformed_policy():
    """Totality gate must never crash; returns a report or report."""
    for bad in (None, 42, object()):
        report = validate_totality(bad)
        assert isinstance(report, TotalityReport)
        # Any bad input either has no invariants (vacuously total) or is
        # treated as an empty sequence; either way, no exception escapes.
