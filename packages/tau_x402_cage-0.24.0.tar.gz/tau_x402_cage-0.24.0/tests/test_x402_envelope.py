"""Tests for x402_envelope.py, HTTP header mapping + status code routing."""

from __future__ import annotations

from decimal import Decimal

from adapter.invariants import MaxPerCall
from adapter.payment_intent_matcher import PaymentIntent
from adapter.policy_revision import PolicyRevision
from adapter.verdict_signer import Verdict, sign
from adapter.x402_envelope import from_http_response, to_http_headers, to_http_response


SECRET = b"test-secret-at-least-16-bytes-long-yes"


def _env(outcome="permit", rule_id=None):
    intent = PaymentIntent(
        amount=Decimal("10"),
        currency="USDC",
        provider="anthropic",
        counterparty="vendor_x",
        rail="x402",
        timestamp_unix=1713456789,
    )
    return sign(Verdict(outcome=outcome, rule_id=rule_id), intent, SECRET, now_unix=1)


class TestHeaders:
    def test_permit_headers_include_core_fields(self) -> None:
        h = to_http_headers(_env("permit"))
        assert h["X-Policy-Verdict"] == "permit"
        assert "X-Policy-Verdict-TTL" in h
        assert "X-Policy-Intent-Hash" in h
        assert "X-Policy-MAC" in h
        assert h["X-Policy-MAC-Alg"] == "HMAC-SHA256"
        assert "X-Policy-Rule-Id" not in h  # not present on permit

    def test_reject_headers_include_rule_id(self) -> None:
        h = to_http_headers(_env("reject", rule_id="spending_cap_daily"))
        assert h["X-Policy-Verdict"] == "reject"
        assert h["X-Policy-Rule-Id"] == "spending_cap_daily"


class TestResponse:
    def test_permit_returns_200(self) -> None:
        status, _, _ = to_http_response(_env("permit"))
        assert status == 200

    def test_reject_returns_403(self) -> None:
        status, _, _ = to_http_response(_env("reject", rule_id="r"))
        assert status == 403

    def test_content_type_is_json(self) -> None:
        _, headers, _ = to_http_response(_env("permit"))
        assert headers["Content-Type"] == "application/json"


class TestRoundTrip:
    def test_response_body_parses_back(self) -> None:
        env = _env("reject", rule_id="r1")
        _, headers, body = to_http_response(env)
        parsed = from_http_response(headers, body)
        assert parsed == env


# ── Patch 8: v2 provenance headers ──────────────────────────────────────────


def _env_v2(outcome="permit", rule_id=None):
    intent = PaymentIntent(
        amount=Decimal("10"),
        currency="USDC",
        provider="anthropic",
        counterparty="vendor_x",
        rail="x402",
        timestamp_unix=1713456789,
    )
    rev = PolicyRevision(
        revision_id="cfg_abc:nonce0",
        invariants=(MaxPerCall(max_amount=Decimal("5")),),
        proof_backend="tau",
        proof_strength="complete",
        prover_mode="strict",
        compile_hash="c" * 64,
        fragment_version="v1",
        tau_backend_version="v8b155d36",
        admitted_at_unix=1,
        predecessor_revision_id=None,
    )
    return sign(
        Verdict(outcome=outcome, rule_id=rule_id),
        intent, SECRET, now_unix=1, revision=rev,
    )


class TestV2Headers:
    def test_v2_envelope_emits_provenance_headers(self) -> None:
        h = to_http_headers(_env_v2("permit"))
        assert h["X-Policy-Version"] == "v2"
        assert h["X-Policy-Revision-Id"] == "cfg_abc:nonce0"
        assert h["X-Policy-Proof-Backend"] == "tau"
        assert h["X-Policy-Proof-Strength"] == "complete"
        assert h["X-Policy-Prover-Mode"] == "strict"

    def test_v1_envelope_omits_provenance_headers(self) -> None:
        """v1 envelopes must not leak provenance keys -- otherwise facilitators
        can't treat the absence as 'pre-v2 cage'."""
        h = to_http_headers(_env("permit"))
        assert h["X-Policy-Version"] == "v1"
        assert "X-Policy-Revision-Id" not in h
        assert "X-Policy-Proof-Backend" not in h
        assert "X-Policy-Proof-Strength" not in h
        assert "X-Policy-Prover-Mode" not in h

    def test_v2_body_round_trips_through_http(self) -> None:
        env = _env_v2("reject", rule_id="r1")
        _, headers, body = to_http_response(env)
        parsed = from_http_response(headers, body)
        assert parsed == env
        assert parsed.version == "v2"
        assert parsed.policy_revision_id == "cfg_abc:nonce0"
