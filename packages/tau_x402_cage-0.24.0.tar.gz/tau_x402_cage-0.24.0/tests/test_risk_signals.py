"""Tests for the v0.15.0 risk-dashboard primitives.

Coverage:
    * ``MutationFailureLog`` ring buffer, since-filter, category-filter.
    * ``active_constraints`` grouping + top-5 summary cap + fragment tag.
    * Daemon integration: every mutation reject path writes one entry.
    * Daemon ops: ``mutation_failures`` + ``active_constraints`` round-trip.
    * CLI ``mutation-failures`` and ``constraints`` end-to-end.
    * Web UI ``/ui/safety`` now embeds both new sections.
"""
from __future__ import annotations

import json
import os
import socket
import subprocess
import sys
import tempfile
import threading
import time
from decimal import Decimal
from typing import Any, Dict, Iterator, Mapping

import pytest

from adapter.invariants import (
    CounterpartyConstraint,
    MaxPerCall,
    ProviderAllowlist,
    RetryRateLimit,
    RollingWindowCap,
    SpendingCap,
)
from adapter.risk_signals import (
    ActiveConstraint,
    MutationFailureEntry,
    MutationFailureLog,
    active_constraints,
    classify_rejection,
)
from adapter.x402_registry import X402Registry
from daemon.server import CageDaemon


# ── MutationFailureLog unit tests ───────────────────────────────────────────


def _entry(
    ts: int = 1_700_000_000,
    op: str = "add_invariant",
    category: str = "prover_contradiction",
    reason: str = "clash",
    actor_id: str | None = None,
    mutation_risk: str | None = None,
) -> MutationFailureEntry:
    return MutationFailureEntry(
        timestamp_unix=ts,
        op=op,
        actor_id=actor_id,
        category=category,  # type: ignore[arg-type]
        reason=reason,
        mutation_risk=mutation_risk,
        affected_scope={},
    )


class TestRingBuffer:
    def test_ring_buffer_evicts_oldest_when_cap_hit(self) -> None:
        log = MutationFailureLog(cap=3)
        for i in range(5):
            log.append(_entry(ts=1_700_000_000 + i, reason=f"r{i}"))
        assert len(log) == 3
        recent = log.recent(limit=10)
        # Newest-first order + oldest two dropped.
        reasons = [e.reason for e in recent]
        assert reasons == ["r4", "r3", "r2"]

    def test_default_cap_is_500(self) -> None:
        log = MutationFailureLog()
        assert log.cap == 500

    def test_invalid_cap_raises(self) -> None:
        with pytest.raises(ValueError):
            MutationFailureLog(cap=0)
        with pytest.raises(ValueError):
            MutationFailureLog(cap=-1)

    def test_append_rejects_wrong_type(self) -> None:
        log = MutationFailureLog()
        with pytest.raises(TypeError):
            log.append("not an entry")  # type: ignore[arg-type]


class TestSinceFilter:
    def test_since_filter_returns_only_entries_after_timestamp(self) -> None:
        log = MutationFailureLog(cap=10)
        log.append(_entry(ts=1_000, reason="old"))
        log.append(_entry(ts=2_000, reason="mid"))
        log.append(_entry(ts=3_000, reason="new"))
        recent = log.recent(limit=10, since_unix=2_000)
        reasons = {e.reason for e in recent}
        assert reasons == {"mid", "new"}

    def test_since_filter_none_returns_all(self) -> None:
        log = MutationFailureLog(cap=10)
        log.append(_entry(ts=100))
        log.append(_entry(ts=200))
        assert len(log.recent(limit=10, since_unix=None)) == 2

    def test_since_filter_excludes_equal_below(self) -> None:
        log = MutationFailureLog(cap=10)
        log.append(_entry(ts=999, reason="below"))
        log.append(_entry(ts=1000, reason="equal"))
        log.append(_entry(ts=1001, reason="above"))
        recent = log.recent(limit=10, since_unix=1000)
        reasons = {e.reason for e in recent}
        assert reasons == {"equal", "above"}


class TestCategoryFilter:
    def test_category_filter_returns_only_matching(self) -> None:
        log = MutationFailureLog(cap=10)
        log.append(_entry(category="prover_contradiction", reason="c1"))
        log.append(_entry(category="governance_violation", reason="g1"))
        log.append(_entry(category="prover_contradiction", reason="c2"))
        recent = log.recent(limit=10, category="prover_contradiction")
        assert len(recent) == 2
        assert {e.reason for e in recent} == {"c1", "c2"}

    def test_unknown_category_returns_empty(self) -> None:
        log = MutationFailureLog(cap=10)
        log.append(_entry(category="prover_contradiction"))
        recent = log.recent(limit=10, category="no_such_category")
        assert recent == ()

    def test_combined_since_and_category(self) -> None:
        log = MutationFailureLog(cap=10)
        log.append(_entry(ts=100, category="prover_contradiction", reason="a"))
        log.append(_entry(ts=200, category="governance_violation", reason="b"))
        log.append(_entry(ts=300, category="prover_contradiction", reason="c"))
        recent = log.recent(
            limit=10, since_unix=150, category="prover_contradiction",
        )
        assert [e.reason for e in recent] == ["c"]


class TestLimitValidation:
    def test_limit_zero_raises(self) -> None:
        log = MutationFailureLog()
        with pytest.raises(ValueError):
            log.recent(limit=0)

    def test_limit_caps_output(self) -> None:
        log = MutationFailureLog(cap=10)
        for i in range(5):
            log.append(_entry(ts=i))
        assert len(log.recent(limit=3)) == 3


# ── active_constraints ──────────────────────────────────────────────────────


class TestActiveConstraints:
    def test_empty_registry_returns_empty_tuple(self) -> None:
        assert active_constraints(X402Registry.empty()) == ()

    def test_none_registry_returns_empty_tuple(self) -> None:
        assert active_constraints(None) == ()

    def test_single_class_yields_one_entry(self) -> None:
        reg = X402Registry(invariants=(
            MaxPerCall(max_amount=Decimal("100"), currency="USDC"),
        ))
        out = active_constraints(reg)
        assert len(out) == 1
        assert out[0].class_name == "MaxPerCall"
        assert out[0].count == 1
        assert out[0].fragment == "v1"
        assert "max=100" in out[0].summaries[0]

    def test_mixed_v1_v2_registry_correct_fragment_tagging(self) -> None:
        reg = X402Registry(invariants=(
            MaxPerCall(max_amount=Decimal("50"), currency="USDC"),
            ProviderAllowlist(providers=frozenset({"anthropic"})),
            RetryRateLimit(min_gap_seconds=5),
            RollingWindowCap(
                max_count=10, window_seconds=60, group_by="provider",
            ),
        ))
        out = active_constraints(reg)
        by_class = {c.class_name: c for c in out}
        assert by_class["MaxPerCall"].fragment == "v1"
        assert by_class["ProviderAllowlist"].fragment == "v1"
        # RetryRateLimit and RollingWindowCap are fragment v2.
        assert by_class["RetryRateLimit"].fragment == "v2"
        assert by_class["RollingWindowCap"].fragment == "v2"

    def test_ten_spending_caps_produce_one_entry_with_top_five_summaries(
        self,
    ) -> None:
        invs = tuple(
            SpendingCap(
                max_amount=Decimal(i + 1), currency="USDC", scope="per_tx",
            )
            for i in range(10)
        )
        reg = X402Registry(invariants=invs)
        out = active_constraints(reg)
        assert len(out) == 1
        assert out[0].class_name == "SpendingCap"
        assert out[0].count == 10
        assert len(out[0].summaries) == 5

    def test_deterministic_alphabetical_ordering(self) -> None:
        """Two separate builds should produce byte-identical wire."""
        reg = X402Registry(invariants=(
            MaxPerCall(max_amount=Decimal("10"), currency="USDC"),
            ProviderAllowlist(providers=frozenset({"x"})),
            CounterpartyConstraint(
                approved_ids=frozenset({"a"}),
                sanctioned_ids=frozenset({"b"}),
            ),
        ))
        out1 = active_constraints(reg)
        out2 = active_constraints(reg)
        names = [c.class_name for c in out1]
        assert names == sorted(names)
        assert [c.to_wire() for c in out1] == [c.to_wire() for c in out2]

    def test_spending_cap_per_tx_is_fragment_v1(self) -> None:
        # SpendingCap scope=per_tx is in fragment v1 via scope disambiguation.
        reg = X402Registry(invariants=(
            SpendingCap(
                max_amount=Decimal("100"), currency="USDC", scope="per_tx",
            ),
        ))
        out = active_constraints(reg)
        assert out[0].fragment == "v1"

    def test_spending_cap_per_window_is_fragment_v2(self) -> None:
        reg = X402Registry(invariants=(
            SpendingCap(
                max_amount=Decimal("100"), currency="USDC",
                scope="per_window", window_seconds=60,
            ),
        ))
        out = active_constraints(reg)
        assert out[0].fragment == "v2"


# ── classify_rejection ──────────────────────────────────────────────────────


class TestClassifyRejection:
    def test_cross_revision_category(self) -> None:
        assert classify_rejection(
            {"verdict": "reject", "category": "cross_revision_violation"},
        ) == "cross_revision_violation"

    def test_governance_category(self) -> None:
        assert classify_rejection(
            {"verdict": "error", "category": "governance_violation"},
        ) == "governance_violation"

    def test_contradiction_verdict(self) -> None:
        assert classify_rejection({"verdict": "contradiction"}) == "prover_contradiction"

    def test_inconclusive_verdict(self) -> None:
        assert classify_rejection({"verdict": "inconclusive"}) == "prover_inconclusive"

    def test_bad_invariant(self) -> None:
        assert classify_rejection(
            {"verdict": "error", "category": "bad_invariant"},
        ) == "bad_invariant"

    def test_success_returns_none(self) -> None:
        assert classify_rejection({"verdict": "updated"}) is None

    def test_non_mapping_returns_none(self) -> None:
        assert classify_rejection(None) is None  # type: ignore[arg-type]
        assert classify_rejection("not a mapping") is None  # type: ignore[arg-type]


# ── Daemon integration ─────────────────────────────────────────────────────


@pytest.fixture
def daemon() -> Iterator[tuple[CageDaemon, str]]:
    fd, path = tempfile.mkstemp(prefix="risksig-", suffix=".sock", dir="/tmp")
    os.close(fd)
    os.unlink(path)
    d = CageDaemon(socket_path=path)
    t = threading.Thread(target=d.serve_forever, daemon=True)
    t.start()
    for _ in range(50):
        if os.path.exists(path):
            break
        time.sleep(0.01)
    try:
        yield d, path
    finally:
        d.shutdown()
        t.join(timeout=1.0)


def _send(path: str, request: dict) -> dict:
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.settimeout(2.0)
    s.connect(path)
    try:
        s.sendall((json.dumps(request) + "\n").encode("utf-8"))
        f = s.makefile("r")
        line = f.readline()
    finally:
        s.close()
    return json.loads(line)


class TestDaemonIntegration:
    def test_successful_mutation_adds_no_entry(self, daemon) -> None:
        d, path = daemon
        before = len(d._mutation_failure_log)
        resp = _send(path, {
            "op": "add_invariant",
            "invariant": {
                "kind": "max_per_call",
                "max_amount": "100", "currency": "USDC",
            },
        })
        assert resp["verdict"] == "updated"
        after = len(d._mutation_failure_log)
        assert after == before

    def test_bad_invariant_records_entry(self, daemon) -> None:
        d, path = daemon
        resp = _send(path, {
            "op": "add_invariant",
            "invariant": {"kind": "this_kind_does_not_exist"},
        })
        assert resp["verdict"] == "error"
        assert resp["category"] == "bad_invariant"
        entries = d._mutation_failure_log.recent(limit=5)
        assert len(entries) >= 1
        assert entries[0].category == "bad_invariant"
        assert entries[0].op == "add_invariant"

    def test_prover_contradiction_records_entry(self, daemon) -> None:
        """Two mutually-exclusive ProviderAllowlists should clash."""
        d, path = daemon
        r1 = _send(path, {
            "op": "add_invariant",
            "invariant": {
                "kind": "provider_allowlist",
                "providers": ["anthropic"],
            },
        })
        assert r1["verdict"] == "updated"
        r2 = _send(path, {
            "op": "add_invariant",
            "invariant": {
                "kind": "provider_allowlist",
                "providers": ["stripe"],
            },
        })
        # Two disjoint allowlists should contradiction out.
        assert r2["verdict"] in ("contradiction", "inconclusive")
        entries = d._mutation_failure_log.recent(limit=5)
        assert len(entries) >= 1
        assert entries[0].category in (
            "prover_contradiction", "prover_inconclusive",
        )

    def test_cross_revision_violation_records_entry(self, daemon) -> None:
        """When a CrossRevisionValidator rejects an append, record it."""
        d, _ = daemon
        # Simulate a rejection payload flowing through the dispatch path.
        # The simplest way to verify the integration point is to call the
        # recorder with a synthetic cross-revision-violation envelope —
        # the wiring has been smoke-tested above; here we verify the
        # taxonomy mapping for the specific category.
        d._record_mutation_failure(
            op="add_invariant",
            payload={"actor_id": "alice"},
            response={
                "verdict": "reject",
                "category": "cross_revision_violation",
                "reason": "NoWeakening would widen the provider allowlist",
                "mutation_risk": "high",
            },
        )
        entries = d._mutation_failure_log.recent(limit=1)
        assert len(entries) == 1
        assert entries[0].category == "cross_revision_violation"
        assert entries[0].actor_id == "alice"
        assert entries[0].mutation_risk == "high"

    def test_governance_violation_records_entry(self, daemon) -> None:
        d, _ = daemon
        d._record_mutation_failure(
            op="add_invariant",
            payload={"actor_id": "bob"},
            response={
                "verdict": "error",
                "category": "governance_violation",
                "reason": "actor not authorized for MaxPerCall",
            },
        )
        entries = d._mutation_failure_log.recent(limit=1)
        assert len(entries) == 1
        assert entries[0].category == "governance_violation"
        assert entries[0].actor_id == "bob"


class TestDaemonMutationFailuresOp:
    def test_op_round_trip_empty(self, daemon) -> None:
        _, path = daemon
        r = _send(path, {"op": "mutation_failures"})
        assert r["verdict"] == "ok"
        assert r["entries"] == []
        assert r["count"] == 0
        assert r["cap"] == 500

    def test_op_round_trip_after_failure(self, daemon) -> None:
        _, path = daemon
        _send(path, {
            "op": "add_invariant",
            "invariant": {"kind": "bogus_kind"},
        })
        r = _send(path, {"op": "mutation_failures"})
        assert r["verdict"] == "ok"
        assert len(r["entries"]) >= 1
        assert r["entries"][0]["category"] == "bad_invariant"

    def test_op_honours_limit(self, daemon) -> None:
        _, path = daemon
        for _ in range(5):
            _send(path, {
                "op": "add_invariant",
                "invariant": {"kind": "bogus_kind"},
            })
        r = _send(path, {"op": "mutation_failures", "limit": 2})
        assert r["verdict"] == "ok"
        assert len(r["entries"]) == 2

    def test_op_honours_category(self, daemon) -> None:
        _, path = daemon
        _send(path, {
            "op": "add_invariant",
            "invariant": {"kind": "bogus_kind"},
        })
        r = _send(path, {
            "op": "mutation_failures",
            "category": "governance_violation",
        })
        assert r["verdict"] == "ok"
        # No governance failures recorded — should be empty.
        assert r["entries"] == []

    def test_bad_limit_returns_error(self, daemon) -> None:
        _, path = daemon
        r = _send(path, {"op": "mutation_failures", "limit": 0})
        assert r["verdict"] == "error"
        assert r["category"] == "bad_payload"

    def test_bad_since_unix_returns_error(self, daemon) -> None:
        _, path = daemon
        r = _send(path, {"op": "mutation_failures", "since_unix": "not-an-int"})
        assert r["verdict"] == "error"
        assert r["category"] == "bad_payload"


class TestDaemonActiveConstraintsOp:
    def test_op_round_trip_empty(self, daemon) -> None:
        _, path = daemon
        r = _send(path, {"op": "active_constraints"})
        assert r["verdict"] == "ok"
        assert r["constraints"] == []
        assert r["total"] == 0

    def test_op_round_trip_populated(self, daemon) -> None:
        _, path = daemon
        _send(path, {
            "op": "add_invariant",
            "invariant": {
                "kind": "max_per_call",
                "max_amount": "100", "currency": "USDC",
            },
        })
        _send(path, {
            "op": "add_invariant",
            "invariant": {
                "kind": "provider_allowlist",
                "providers": ["anthropic"],
            },
        })
        r = _send(path, {"op": "active_constraints"})
        assert r["verdict"] == "ok"
        by_class = {c["class_name"]: c for c in r["constraints"]}
        assert "MaxPerCall" in by_class
        assert "ProviderAllowlist" in by_class
        assert by_class["MaxPerCall"]["fragment"] == "v1"
        assert by_class["MaxPerCall"]["count"] == 1
        assert r["total"] == 2

    def test_op_is_pure_read(self, daemon) -> None:
        _, path = daemon
        r1 = _send(path, {"op": "active_constraints"})
        r2 = _send(path, {"op": "active_constraints"})
        assert r1 == r2


# ── CLI ─────────────────────────────────────────────────────────────────────


class TestCLI:
    def test_mutation_failures_text_renders_entries(self, daemon) -> None:
        _, path = daemon
        _send(path, {
            "op": "add_invariant",
            "invariant": {"kind": "bogus_kind"},
        })
        cp = subprocess.run(
            [
                sys.executable, "-m", "daemon.cli", "mutation-failures",
                "--socket", path,
            ],
            capture_output=True, text=True, timeout=10,
        )
        assert cp.returncode == 0, cp.stderr
        assert "bad_invariant" in cp.stdout

    def test_mutation_failures_json_format(self, daemon) -> None:
        _, path = daemon
        cp = subprocess.run(
            [
                sys.executable, "-m", "daemon.cli", "mutation-failures",
                "--socket", path, "--format", "json",
            ],
            capture_output=True, text=True, timeout=10,
        )
        assert cp.returncode == 0, cp.stderr
        data = json.loads(cp.stdout)
        assert data["verdict"] == "ok"
        assert isinstance(data["entries"], list)

    def test_mutation_failures_category_filter(self, daemon) -> None:
        _, path = daemon
        cp = subprocess.run(
            [
                sys.executable, "-m", "daemon.cli", "mutation-failures",
                "--socket", path, "--category", "governance_violation",
                "--format", "json",
            ],
            capture_output=True, text=True, timeout=10,
        )
        assert cp.returncode == 0, cp.stderr
        data = json.loads(cp.stdout)
        assert data["entries"] == []

    def test_mutation_failures_since_window(self, daemon) -> None:
        _, path = daemon
        cp = subprocess.run(
            [
                sys.executable, "-m", "daemon.cli", "mutation-failures",
                "--socket", path, "--since", "24h", "--format", "json",
            ],
            capture_output=True, text=True, timeout=10,
        )
        assert cp.returncode == 0, cp.stderr

    def test_constraints_text_renders_empty(self, daemon) -> None:
        _, path = daemon
        cp = subprocess.run(
            [
                sys.executable, "-m", "daemon.cli", "constraints",
                "--socket", path,
            ],
            capture_output=True, text=True, timeout=10,
        )
        assert cp.returncode == 0, cp.stderr
        assert "Active constraints" in cp.stdout
        assert "0 classes" in cp.stdout

    def test_constraints_text_renders_populated(self, daemon) -> None:
        _, path = daemon
        _send(path, {
            "op": "add_invariant",
            "invariant": {
                "kind": "max_per_call",
                "max_amount": "100", "currency": "USDC",
            },
        })
        cp = subprocess.run(
            [
                sys.executable, "-m", "daemon.cli", "constraints",
                "--socket", path,
            ],
            capture_output=True, text=True, timeout=10,
        )
        assert cp.returncode == 0, cp.stderr
        assert "MaxPerCall" in cp.stdout
        assert "fragment=v1" in cp.stdout

    def test_constraints_json_format(self, daemon) -> None:
        _, path = daemon
        cp = subprocess.run(
            [
                sys.executable, "-m", "daemon.cli", "constraints",
                "--socket", path, "--format", "json",
            ],
            capture_output=True, text=True, timeout=10,
        )
        assert cp.returncode == 0, cp.stderr
        data = json.loads(cp.stdout)
        assert data["verdict"] == "ok"


# ── Web UI ──────────────────────────────────────────────────────────────────


class TestWebUI:
    def _build(self, responses: Dict[str, Dict[str, Any]]):
        pytest.importorskip("fastapi")
        pytest.importorskip("jinja2")
        from fastapi import FastAPI
        from fastapi.testclient import TestClient
        from saas.web_ui.routes import build_router, mount_static_on
        from tests.test_web_ui import StubReader

        token = "sk_test_risksig_ui"
        app = FastAPI()
        app.include_router(
            build_router(reader=StubReader(responses), token=token),
            prefix="/ui",
        )
        mount_static_on(app)
        return TestClient(app), token

    def _canned_responses(self) -> Dict[str, Dict[str, Any]]:
        return {
            "risk_aggregate": {
                "verdict": "ok",
                "aggregate": {
                    "window_seconds": 86400,
                    "prevented_count": 2,
                    "prevented_value_by_currency": {"USDC": "200.00"},
                    "top_providers": [],
                    "top_rules": [],
                    "now_unix": 1_700_000_000,
                },
            },
            "active_constraints": {
                "verdict": "ok",
                "total": 2,
                "constraints": [
                    {
                        "class_name": "MaxPerCall",
                        "count": 1,
                        "fragment": "v1",
                        "summaries": ["max=100 USDC"],
                    },
                    {
                        "class_name": "RollingWindowCap",
                        "count": 1,
                        "fragment": "v2",
                        "summaries": [
                            "max_count=10, window=60s, group_by=provider",
                        ],
                    },
                ],
            },
            "mutation_failures": {
                "verdict": "ok",
                "cap": 500,
                "count": 1,
                "entries": [
                    {
                        "timestamp_unix": 1_700_000_000,
                        "op": "add_invariant",
                        "actor_id": "alice",
                        "category": "prover_contradiction",
                        "reason": "counterparty clash",
                        "mutation_risk": "high",
                        "affected_scope": {},
                    },
                ],
            },
        }

    def test_safety_html_includes_both_new_sections(self) -> None:
        client, token = self._build(self._canned_responses())
        r = client.get(
            "/ui/safety",
            headers={"Authorization": f"Bearer {token}"},
        )
        assert r.status_code == 200
        body = r.text
        # DOM section ids present.
        assert 'id="active-constraints"' in body
        assert 'id="mutation-failures"' in body
        # Active-constraints panel shows both classes.
        assert "MaxPerCall" in body
        assert "RollingWindowCap" in body
        assert "max=100 USDC" in body
        # Mutation-failures panel shows the one recorded entry.
        assert "add_invariant" in body
        assert "prover_contradiction" in body
        assert "counterparty clash" in body

    def test_safety_route_rejects_post(self) -> None:
        client, token = self._build(self._canned_responses())
        r = client.post(
            "/ui/safety",
            headers={"Authorization": f"Bearer {token}"},
        )
        assert r.status_code == 405

    def test_safety_renders_banners_on_op_error(self) -> None:
        responses = self._canned_responses()
        responses["active_constraints"] = {
            "verdict": "error",
            "category": "daemon_unreachable",
            "reason": "FileNotFoundError",
        }
        responses["mutation_failures"] = {
            "verdict": "error",
            "category": "daemon_unreachable",
            "reason": "FileNotFoundError",
        }
        client, token = self._build(responses)
        r = client.get(
            "/ui/safety",
            headers={"Authorization": f"Bearer {token}"},
        )
        assert r.status_code == 200
        body = r.text
        assert "Daemon unreachable" in body

    def test_safety_renders_empty_sections_gracefully(self) -> None:
        responses = self._canned_responses()
        responses["active_constraints"] = {
            "verdict": "ok", "total": 0, "constraints": [],
        }
        responses["mutation_failures"] = {
            "verdict": "ok", "cap": 500, "count": 0, "entries": [],
        }
        client, token = self._build(responses)
        r = client.get(
            "/ui/safety",
            headers={"Authorization": f"Bearer {token}"},
        )
        assert r.status_code == 200
        body = r.text
        assert "No constraints declared" in body
        assert "No mutation failures recorded" in body
