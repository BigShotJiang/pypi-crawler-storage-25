"""Tests for adapter.guaranteed_errors (v0.19.0 Deliverable 7)."""
from __future__ import annotations

import dataclasses
import json
from decimal import Decimal
from types import MappingProxyType

import pytest

from adapter.guaranteed_errors import (
    GuaranteedFailure,
    GuaranteedFailureCode,
    format_for_audit,
)


# ── enum surface ───────────────────────────────────────────────────────


def test_every_failure_code_has_stable_string_value():
    """Codes inherit from str so JSON-dumping is transparent. Every
    code's .value must equal its name (SCREAMING_SNAKE_CASE)."""
    for code in GuaranteedFailureCode:
        assert code.value == code.name
        assert isinstance(code.value, str)


def test_taxonomy_contains_required_codes():
    """Regression: the spec names these minimum codes."""
    names = {c.name for c in GuaranteedFailureCode}
    required = {
        "UNSUPPORTED_FOR_GUARANTEED_MODE",
        "TAU_TOTALITY_FAILED",
        "TAU_PROOF_INCONCLUSIVE",
        "TAU_BACKEND_UNAVAILABLE",
        "RUNTIME_EVALUATION_UNAVAILABLE",
        "RUNTIME_GUARD_VIOLATION",
        "REVISION_TRANSITION_VIOLATION",
    }
    assert required <= names


def test_code_is_str_enum():
    """Passing a code where a string is expected should work. This is
    the property we rely on in JSON serialization."""
    code = GuaranteedFailureCode.TAU_TOTALITY_FAILED
    assert isinstance(code, str)
    assert code == "TAU_TOTALITY_FAILED"


# ── GuaranteedFailure construction ─────────────────────────────────────


def test_failure_roundtrips_through_format_for_audit_to_json():
    for code in GuaranteedFailureCode:
        failure = GuaranteedFailure(
            code=code,
            message=f"test message for {code.value}",
            context={"rule": "SpendingCap", "amount": Decimal("100")},
            language_version="1.0.0",
            backend_version="tau-ltl-8b155d36",
        )
        payload = format_for_audit(failure)
        blob = json.dumps(payload)
        assert code.value in blob
        # The JSON round-trip keeps the same schema and code.
        restored = json.loads(blob)
        assert restored["code"] == code.value
        assert restored["schema"] == "tau-x402-cage.guaranteed-failure.v1"
        assert restored["language_version"] == "1.0.0"


def test_failure_is_frozen_and_rejects_mutation():
    """dataclass(frozen=True) — any attribute assignment raises."""
    failure = GuaranteedFailure(
        code=GuaranteedFailureCode.UNSUPPORTED_FOR_GUARANTEED_MODE,
        message="oops",
        context={"foo": "bar"},
        language_version="1.0.0",
    )
    with pytest.raises(dataclasses.FrozenInstanceError):
        failure.message = "new message"  # type: ignore[misc]
    with pytest.raises(dataclasses.FrozenInstanceError):
        failure.code = GuaranteedFailureCode.TAU_TOTALITY_FAILED  # type: ignore[misc]


def test_failure_context_is_mapping_proxy_and_cannot_be_mutated():
    """Even with frozen=True, a plain-dict context could be mutated via
    the reference. Wrapping in MappingProxyType closes that hole."""
    failure = GuaranteedFailure(
        code=GuaranteedFailureCode.TAU_TOTALITY_FAILED,
        message="oops",
        context={"foo": "bar"},
        language_version="1.0.0",
    )
    assert isinstance(failure.context, MappingProxyType)
    with pytest.raises(TypeError):
        failure.context["baz"] = "qux"  # type: ignore[index]


def test_failure_context_caller_mutation_does_not_leak():
    """If the caller mutates the dict they passed in, the failure's
    context must stay unchanged (defensive copy)."""
    ctx = {"k": "v"}
    failure = GuaranteedFailure(
        code=GuaranteedFailureCode.TAU_TOTALITY_FAILED,
        message="oops",
        context=ctx,
        language_version="1.0.0",
    )
    ctx["k"] = "MUTATED"
    assert failure.context["k"] == "v"


# ── input validation on construction ───────────────────────────────────


def test_failure_rejects_non_enum_code():
    with pytest.raises(TypeError):
        GuaranteedFailure(
            code="UNSUPPORTED_FOR_GUARANTEED_MODE",  # type: ignore[arg-type]
            message="oops",
            language_version="1.0.0",
        )


def test_failure_rejects_empty_message():
    with pytest.raises(ValueError):
        GuaranteedFailure(
            code=GuaranteedFailureCode.TAU_TOTALITY_FAILED,
            message="",
            language_version="1.0.0",
        )


def test_failure_rejects_whitespace_only_message():
    with pytest.raises(ValueError):
        GuaranteedFailure(
            code=GuaranteedFailureCode.TAU_TOTALITY_FAILED,
            message="   \n",
            language_version="1.0.0",
        )


def test_failure_rejects_non_string_backend_version():
    with pytest.raises(TypeError):
        GuaranteedFailure(
            code=GuaranteedFailureCode.TAU_BACKEND_UNAVAILABLE,
            message="oops",
            language_version="1.0.0",
            backend_version=123,  # type: ignore[arg-type]
        )


def test_failure_rejects_non_mapping_context():
    with pytest.raises(TypeError):
        GuaranteedFailure(
            code=GuaranteedFailureCode.TAU_TOTALITY_FAILED,
            message="oops",
            context=["not", "a", "mapping"],  # type: ignore[arg-type]
            language_version="1.0.0",
        )


def test_failure_allows_none_backend_version():
    """backend_version=None is valid (totality gate rejects before the
    prover runs, so there's no backend to report)."""
    failure = GuaranteedFailure(
        code=GuaranteedFailureCode.TAU_TOTALITY_FAILED,
        message="totality check failed",
        language_version="1.0.0",
        backend_version=None,
    )
    assert failure.backend_version is None


# ── format_for_audit edge cases ────────────────────────────────────────


def test_format_for_audit_rejects_non_failure():
    with pytest.raises(TypeError):
        format_for_audit("not a failure")  # type: ignore[arg-type]


def test_format_for_audit_coerces_decimal_and_tuple():
    """Non-JSON-native types in the context get stringified / listified
    so the audit blob stays JSON-clean."""
    failure = GuaranteedFailure(
        code=GuaranteedFailureCode.RUNTIME_GUARD_VIOLATION,
        message="velocity exceeded",
        context={
            "amount": Decimal("42.50"),
            "providers": ("openai", "anthropic"),
            "nested": {"sanctioned": frozenset({"ofac_01"})},
        },
        language_version="1.0.0",
    )
    payload = format_for_audit(failure)
    blob = json.dumps(payload)
    # Decimal is stringified.
    assert "42.50" in blob
    # Tuples become lists (order preserved).
    assert payload["context"]["providers"] == ["openai", "anthropic"]
    # Nested frozensets become sorted lists.
    assert payload["context"]["nested"]["sanctioned"] == ["ofac_01"]


def test_format_for_audit_schema_is_stable():
    """Pin on the schema key so downstream consumers can version-gate."""
    failure = GuaranteedFailure(
        code=GuaranteedFailureCode.TAU_PROOF_INCONCLUSIVE,
        message="tau timed out",
        language_version="1.0.0",
    )
    payload = format_for_audit(failure)
    assert payload["schema"] == "tau-x402-cage.guaranteed-failure.v1"
    # Required keys present, no extras.
    expected = {
        "schema",
        "code",
        "message",
        "context",
        "language_version",
        "backend_version",
    }
    assert set(payload.keys()) == expected


def test_format_for_audit_preserves_empty_context():
    failure = GuaranteedFailure(
        code=GuaranteedFailureCode.TAU_TOTALITY_FAILED,
        message="oops",
        language_version="1.0.0",
    )
    payload = format_for_audit(failure)
    assert payload["context"] == {}
