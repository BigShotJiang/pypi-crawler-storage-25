"""v1.2.0 tests for MutualExclusion admission in Guaranteed Mode.

Covers:
* admit the two-group ``rule_composition`` variant,
* totality round-trip in composed policies,
* dry-run encoding composes two enum-bv predicates via conjunction +
  negation under a single ``G(...)``, no new BA.
"""
from __future__ import annotations

from decimal import Decimal
from types import SimpleNamespace

import pytest

from adapter.guaranteed_errors import GuaranteedFailureCode
from adapter.guaranteed_language import (
    GUARANTEED_LANGUAGE_VERSION,
    GuaranteedLanguage,
)
from adapter.guaranteed_totality import validate_totality
from adapter.invariants import (
    MaxPerCall,
    MutualExclusion,
    ProviderAllowlist,
)
from adapter.tau_compiler import _v12_encode, dry_run_encode


# ── admission ──────────────────────────────────────────────────────────


def test_mutual_exclusion_two_group_admits():
    ok, code = GuaranteedLanguage.is_supported(
        MutualExclusion(
            group_a=frozenset({"openai"}),
            group_b=frozenset({"anthropic"}),
        )
    )
    assert ok is True
    assert code is None


def test_mutual_exclusion_multi_group_admits():
    ok, code = GuaranteedLanguage.is_supported(
        MutualExclusion(
            group_a=frozenset({"openai", "mistral"}),
            group_b=frozenset({"anthropic", "cohere"}),
        )
    )
    assert ok is True
    assert code is None


# ── totality ───────────────────────────────────────────────────────────


def _mk_policy(invariants):
    return SimpleNamespace(invariants=tuple(invariants))


def test_totality_mutual_exclusion_alone_passes():
    report = validate_totality(
        _mk_policy(
            [
                MutualExclusion(
                    group_a=frozenset({"openai"}),
                    group_b=frozenset({"anthropic"}),
                )
            ]
        )
    )
    assert report.is_total is True
    assert report.reason_code is None
    assert report.language_version == GUARANTEED_LANGUAGE_VERSION


def test_totality_mutual_exclusion_composed_with_allowlist_passes():
    """The classic "mutex + allowlist" policy: admit providers from
    either group but never both simultaneously."""
    report = validate_totality(
        _mk_policy(
            [
                ProviderAllowlist(
                    providers=frozenset({"openai", "anthropic"})
                ),
                MutualExclusion(
                    group_a=frozenset({"openai"}),
                    group_b=frozenset({"anthropic"}),
                ),
                MaxPerCall(max_amount=Decimal("50")),
            ]
        )
    )
    assert report.is_total is True


# ── dry-run encoding shape ─────────────────────────────────────────────


def test_dry_run_encode_mutual_exclusion_ok():
    ok, detail = dry_run_encode(
        MutualExclusion(
            group_a=frozenset({"openai"}),
            group_b=frozenset({"anthropic"}),
        )
    )
    assert ok is True
    assert detail == ""


def test_v12_encoded_body_wraps_in_G_and_negation():
    body = _v12_encode(
        MutualExclusion(
            group_a=frozenset({"openai"}),
            group_b=frozenset({"anthropic"}),
        )
    )
    assert body.startswith("G(")
    assert body.endswith(")")
    # The composition pattern is ``G(!(A && B))``.
    assert "!(" in body
    assert "&&" in body
    assert body.count("(") == body.count(")")


def test_v12_encoded_body_has_bv16_enum_slots_for_both_groups():
    body = _v12_encode(
        MutualExclusion(
            group_a=frozenset({"openai", "mistral"}),
            group_b=frozenset({"anthropic"}),
        )
    )
    # Two bv[16] slots from group_a + one from group_b = at least 3.
    assert body.count(":bv[16]") >= 3
    assert "intent_provider" in body


def test_v12_encoded_body_deterministic_over_set_order():
    a = _v12_encode(
        MutualExclusion(
            group_a=frozenset({"openai", "mistral"}),
            group_b=frozenset({"anthropic", "cohere"}),
        )
    )
    b = _v12_encode(
        MutualExclusion(
            group_a=frozenset({"mistral", "openai"}),
            group_b=frozenset({"cohere", "anthropic"}),
        )
    )
    assert a == b


def test_v12_encoded_body_no_nlang_no_smt_sentinels():
    body = _v12_encode(
        MutualExclusion(
            group_a=frozenset({"openai", "mistral"}),
            group_b=frozenset({"anthropic"}),
        )
    )
    assert ":nlang" not in body
    assert "{<" not in body
    assert "(declare-fun" not in body
    assert "(assert " not in body


def test_non_composed_policy_passes():
    """A regular allowlist-only policy (no mutual exclusion) still
    passes totality; this guards against the composed encoder
    accidentally polluting other admissions."""
    report = validate_totality(
        _mk_policy(
            [
                ProviderAllowlist(
                    providers=frozenset({"openai", "anthropic"})
                ),
                MaxPerCall(max_amount=Decimal("50")),
            ]
        )
    )
    assert report.is_total is True
