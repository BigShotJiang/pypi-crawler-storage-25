"""Tests for the TTI bench subcommand (v0.10.0).

The battery's structural checks run deterministically without a live
daemon, so these tests do not spin up real network endpoints. Remote-mode
(``--against``) is covered by injecting a stubbed ``Client`` into
``sys.modules["tau_x402_cage_client"]`` so the import path in
``tti_bench._probe_against`` resolves to a fake that we control.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import types
from pathlib import Path
from typing import Any, Dict

import pytest

from adapter import tti_bench


# ── helpers ──────────────────────────────────────────────────────────────


def _run_cli(args: list[str]) -> subprocess.CompletedProcess:
    """Invoke `python -m daemon.cli` with PYTHONPATH set to repo root."""
    env = os.environ.copy()
    repo_root = str(Path(__file__).resolve().parent.parent)
    env["PYTHONPATH"] = os.pathsep.join(
        [repo_root, env.get("PYTHONPATH", "")]
    ).rstrip(os.pathsep)
    return subprocess.run(
        [sys.executable, "-m", "daemon.cli", *args],
        capture_output=True, text=True, timeout=30, env=env,
    )


# ── TTIResult / TTITestResult dataclasses ────────────────────────────────


class TestResultTypes:
    def test_tti_test_result_is_frozen(self) -> None:
        r = tti_bench.TTITestResult(
            id="TB-1", name="Daily cap", passed=True,
            decisive=True, duration_seconds=0.001, detail="ok",
        )
        with pytest.raises((AttributeError, Exception)):
            r.passed = False  # type: ignore[misc]

    def test_to_dict_round_trips_basics(self) -> None:
        r = tti_bench.TTITestResult(
            id="TB-2", name="X", passed=False, decisive=True,
            duration_seconds=0.002, detail="detail", error="E",
        )
        d = r.to_dict()
        assert d["id"] == "TB-2"
        assert d["passed"] is False
        assert d["error"] == "E"

    def test_tti_result_all_passed_flag(self) -> None:
        per = tuple(
            tti_bench.TTITestResult(
                id=f"TB-{i}", name=str(i), passed=True, decisive=True,
                duration_seconds=0.001, detail="ok",
            )
            for i in range(1, 6)
        )
        r = tti_bench.TTIResult(
            per_test=per, total_seconds=0.005, median_seconds=0.001,
            p95_seconds=0.001, passed=5, failed=0, target="local",
        )
        assert r.all_passed is True
        assert r.all_decisive is True
        payload = json.loads(r.to_json())
        assert payload["all_passed"] is True
        assert payload["target"] == "local"
        assert len(payload["per_test"]) == 5


# ── Local-mode battery ───────────────────────────────────────────────────


class TestLocalBattery:
    def test_battery_runs_all_five_tests(self) -> None:
        result = tti_bench.run_battery()
        assert len(result.per_test) == 5
        ids = [t.id for t in result.per_test]
        assert ids == ["TB-1", "TB-2", "TB-3", "TB-4", "TB-5"]

    def test_battery_all_pass_in_local_mode(self) -> None:
        """The shipped battery MUST all pass; a regression here blocks TTI."""
        result = tti_bench.run_battery()
        assert result.all_passed is True, [
            (t.id, t.passed, t.error) for t in result.per_test
        ]
        assert result.all_decisive is True
        assert result.failed == 0
        assert result.passed == 5

    def test_battery_reports_stable_aggregates(self) -> None:
        result = tti_bench.run_battery()
        assert result.total_seconds >= 0.0
        assert result.median_seconds >= 0.0
        assert result.p95_seconds >= 0.0
        # p95 must be >= median for a non-trivial 5-element set.
        assert result.p95_seconds + 1e-9 >= result.median_seconds

    def test_battery_target_label_is_local_by_default(self) -> None:
        result = tti_bench.run_battery()
        assert result.target == "local"

    def test_json_schema_stable(self) -> None:
        """Top-level keys and per-test shape are part of the public contract."""
        payload = json.loads(tti_bench.run_battery().to_json())
        expected_top = {
            "per_test", "total_seconds", "median_seconds", "p95_seconds",
            "passed", "failed", "target", "all_decisive", "all_passed",
        }
        assert set(payload.keys()) == expected_top
        expected_per = {
            "id", "name", "passed", "decisive",
            "duration_seconds", "detail", "error",
        }
        for t in payload["per_test"]:
            assert set(t.keys()) == expected_per


# ── --against remote mode ────────────────────────────────────────────────


class TestAgainstRemote:
    def test_against_requires_client_sdk(
        self, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        # Simulate the SDK being absent by blocking the import.
        import builtins as _b

        real_import = _b.__import__

        def _block(name: str, *args: Any, **kwargs: Any) -> Any:
            if name == "tau_x402_cage_client":
                raise ImportError("pretend SDK missing")
            return real_import(name, *args, **kwargs)

        monkeypatch.setattr(_b, "__import__", _block)
        with pytest.raises(tti_bench.TTIBenchError) as exc:
            tti_bench.run_battery(against_url="https://example.com")
        assert "tau-x402-cage-client" in str(exc.value)

    def test_against_calls_sdk_health(
        self, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """The client SDK's health() must be called before tests run."""
        calls: Dict[str, Any] = {"health_url": None, "token": None}

        class _FakeClient:
            def __init__(self, base_url: str, bearer_token: str | None = None) -> None:
                calls["health_url"] = base_url
                calls["token"] = bearer_token

            def __enter__(self) -> "_FakeClient":
                return self

            def __exit__(self, *a: Any) -> None:
                return None

            def health(self) -> dict:
                return {"status": "ok"}

        fake_module = types.ModuleType("tau_x402_cage_client")
        fake_module.Client = _FakeClient  # type: ignore[attr-defined]
        monkeypatch.setitem(sys.modules, "tau_x402_cage_client", fake_module)

        result = tti_bench.run_battery(
            against_url="https://cage.example.com",
            bearer_token="tok_xyz",
        )
        assert calls["health_url"] == "https://cage.example.com"
        assert calls["token"] == "tok_xyz"
        assert result.target == "https://cage.example.com"
        assert result.all_passed is True

    def test_against_unreachable_endpoint_raises(
        self, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        class _DeadClient:
            def __init__(self, **kwargs: Any) -> None:
                pass

            def __enter__(self) -> "_DeadClient":
                return self

            def __exit__(self, *a: Any) -> None:
                return None

            def health(self) -> dict:
                raise ConnectionError("boom")

        fake_module = types.ModuleType("tau_x402_cage_client")
        fake_module.Client = _DeadClient  # type: ignore[attr-defined]
        monkeypatch.setitem(sys.modules, "tau_x402_cage_client", fake_module)
        with pytest.raises(tti_bench.TTIBenchError) as exc:
            tti_bench.run_battery(against_url="https://dead.example.com")
        assert "unreachable" in str(exc.value)


# ── Failure-mode handling ────────────────────────────────────────────────


class TestFailureModes:
    def test_test_exceeding_budget_reported_not_decisive(
        self, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        import time as _time

        def _slow() -> tuple[bool, str]:
            _time.sleep(0.02)
            return True, "ok"

        def _fake_callables() -> list[tuple[str, str, Any]]:
            return [
                ("TB-1", "Daily cap", _slow),
                ("TB-2", "Contradictory caps", lambda: (True, "ok")),
                ("TB-3", "Rolling window", lambda: (True, "ok")),
                ("TB-4", "Past obligation", lambda: (True, "ok")),
                ("TB-5", "Rule revision", lambda: (True, "ok")),
            ]

        monkeypatch.setattr(tti_bench, "_import_battery_callables", _fake_callables)
        result = tti_bench.run_battery(per_test_budget_seconds=0.001)
        tb1 = next(t for t in result.per_test if t.id == "TB-1")
        assert tb1.decisive is False
        assert tb1.passed is False
        assert tb1.error and "budget" in tb1.error

    def test_test_raising_is_reported_not_decisive(
        self, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        def _boom() -> tuple[bool, str]:
            raise RuntimeError("kaboom")

        def _fake_callables() -> list[tuple[str, str, Any]]:
            return [
                ("TB-1", "Daily cap", _boom),
                ("TB-2", "Contradictory caps", lambda: (True, "ok")),
                ("TB-3", "Rolling window", lambda: (True, "ok")),
                ("TB-4", "Past obligation", lambda: (True, "ok")),
                ("TB-5", "Rule revision", lambda: (True, "ok")),
            ]

        monkeypatch.setattr(tti_bench, "_import_battery_callables", _fake_callables)
        result = tti_bench.run_battery()
        tb1 = next(t for t in result.per_test if t.id == "TB-1")
        assert tb1.decisive is False
        assert tb1.passed is False
        assert tb1.error and "RuntimeError" in tb1.error
        assert result.failed == 1


# ── CLI surface ──────────────────────────────────────────────────────────


class TestBenchCLI:
    def test_cli_bench_prints_human_table(self) -> None:
        result = _run_cli(["bench"])
        assert result.returncode == 0, result.stderr
        assert "TTI battery" in result.stdout
        assert "TB-1" in result.stdout
        assert "TB-5" in result.stdout
        assert "verdict:" in result.stdout

    def test_cli_bench_json_is_parseable(self) -> None:
        result = _run_cli(["bench", "--json"])
        assert result.returncode == 0, result.stderr
        payload = json.loads(result.stdout.strip())
        assert payload["all_passed"] is True
        assert len(payload["per_test"]) == 5

    def test_cli_bench_check_budget_pass(self) -> None:
        """Under-budget total_seconds must pass when --check is set."""
        result = _run_cli(["bench", "--check", "--max-seconds", "600"])
        assert result.returncode == 0, result.stderr

    def test_cli_bench_check_budget_fail(self) -> None:
        """Zero budget always fails --check."""
        result = _run_cli(["bench", "--check", "--max-seconds", "0"])
        assert result.returncode == 1
        assert "regression" in result.stderr

    def test_cli_bench_in_help(self) -> None:
        result = _run_cli(["--help"])
        assert result.returncode == 0
        assert "bench" in result.stdout


# ── Percentile helpers ───────────────────────────────────────────────────


class TestPercentileHelpers:
    def test_percentile_empty_returns_zero(self) -> None:
        assert tti_bench._percentile([], 95.0) == 0.0

    def test_percentile_single_value(self) -> None:
        assert tti_bench._percentile([0.5], 95.0) == 0.5

    def test_percentile_linear_interp_two_values(self) -> None:
        # With [0.0, 1.0], the 50th percentile is 0.5 via linear interpolation.
        assert abs(tti_bench._percentile([0.0, 1.0], 50.0) - 0.5) < 1e-9

    def test_median_even_count(self) -> None:
        assert abs(tti_bench._median([1.0, 2.0, 3.0, 4.0]) - 2.5) < 1e-9

    def test_median_odd_count(self) -> None:
        assert tti_bench._median([1.0, 2.0, 3.0]) == 2.0

    def test_median_empty(self) -> None:
        assert tti_bench._median([]) == 0.0
