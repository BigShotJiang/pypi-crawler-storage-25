"""Tests for validate_totality with the v1.1.0 language surface (v0.20.0).

Every new rule class must pass dry-run encoding, compose cleanly with
existing v1 rules, and fail-close cleanly on malformed or out-of-tier
shapes. The totality gate MUST NOT crash — any exception during
``dry_run_encode`` becomes a structured ``TAU_TOTALITY_FAILED`` report.
"""
from __future__ import annotations

from decimal import Decimal
from types import SimpleNamespace

import pytest

from adapter.guaranteed_errors import GuaranteedFailureCode
from adapter.guaranteed_language import GUARANTEED_LANGUAGE_VERSION
from adapter.guaranteed_totality import TotalityReport, validate_totality
from adapter.invariants import (
    BurstVelocityCap,
    InvariantError,
    MaxPerCall,
    ProviderAllowlist,
    RetryRateLimit,
    RollingWindowCap,
    SpendingCap,
)


# ── helpers ────────────────────────────────────────────────────────────


def _mk_policy(invariants, **extra):
    return SimpleNamespace(invariants=tuple(invariants), **extra)


# ── each new rule type passes totality on its own ─────────────────────


def test_totality_passes_retry_rate_limit_alone():
    policy = _mk_policy([RetryRateLimit(min_gap_seconds=30)])
    report = validate_totality(policy)
    assert report.is_total is True
    assert report.reason_code is None
    assert report.language_version == GUARANTEED_LANGUAGE_VERSION


def test_totality_passes_rolling_window_cap_alone():
    policy = _mk_policy(
        [RollingWindowCap(max_count=10, window_seconds=60, group_by="provider")]
    )
    report = validate_totality(policy)
    assert report.is_total is True


def test_totality_passes_burst_velocity_cap_alone():
    policy = _mk_policy(
        [BurstVelocityCap(max_per_window=Decimal("100"), window_seconds=10)]
    )
    report = validate_totality(policy)
    assert report.is_total is True


def test_totality_passes_spending_cap_per_window_v1_1():
    policy = _mk_policy(
        [
            SpendingCap(
                max_amount=Decimal("500"),
                scope="per_window",
                window_seconds=86400,
            )
        ]
    )
    report = validate_totality(policy)
    assert report.is_total is True


def test_totality_passes_spending_cap_per_provider_per_window_v1_1():
    policy = _mk_policy(
        [
            SpendingCap(
                max_amount=Decimal("200"),
                scope="per_provider_per_window",
                window_seconds=86400,
                provider="openai",
            )
        ]
    )
    report = validate_totality(policy)
    assert report.is_total is True


# ── mixed composition (old + new rules together) ───────────────────────


def test_totality_passes_mixed_composition_old_and_new():
    """A realistic policy mixing v1.0.0 and v1.1.0 rules stays total."""
    policy = _mk_policy(
        [
            MaxPerCall(max_amount=Decimal("50")),
            ProviderAllowlist(providers=frozenset({"anthropic", "openai"})),
            SpendingCap(max_amount=Decimal("25"), scope="per_tx"),
            RetryRateLimit(min_gap_seconds=30),
            RollingWindowCap(max_count=10, window_seconds=60),
            BurstVelocityCap(max_per_window=Decimal("100"), window_seconds=10),
            SpendingCap(
                max_amount=Decimal("1000"),
                scope="per_window",
                window_seconds=86400,
            ),
        ]
    )
    report = validate_totality(policy)
    assert report.is_total is True
    assert report.reason_code is None


# ── malformed input fails cleanly (never crashes) ──────────────────────


def test_retry_rate_limit_with_invalid_gap_raises_at_construction():
    """RetryRateLimit construction rejects zero / negative gaps;
    totality never sees an invalid instance because construction fails
    first. This test exists to pin that contract."""
    with pytest.raises(InvariantError):
        RetryRateLimit(min_gap_seconds=0)
    with pytest.raises(InvariantError):
        RetryRateLimit(min_gap_seconds=-5)


def test_rolling_window_cap_with_negative_max_raises_at_construction():
    with pytest.raises(InvariantError):
        RollingWindowCap(max_count=-1, window_seconds=60)
    with pytest.raises(InvariantError):
        RollingWindowCap(max_count=10, window_seconds=0)


def test_burst_velocity_cap_with_non_positive_fields_raises():
    with pytest.raises(InvariantError):
        BurstVelocityCap(max_per_window=Decimal("0"), window_seconds=10)
    with pytest.raises(InvariantError):
        BurstVelocityCap(max_per_window=Decimal("100"), window_seconds=-1)


def test_totality_on_broken_dry_run_is_fail_closed():
    """If ``_v11_encode`` raises for a v1.1.0 invariant, the totality
    gate converts it into a structured failure, never a crash.

    We monkeypatch the encoder directly; a ``RetryRateLimit`` instance
    already passes the rule-type admission stage, so the failure flows
    through as ``TAU_TOTALITY_FAILED`` (stage 4 encoding failure).
    """
    import adapter.tau_compiler as tc

    original = tc._v11_encode

    def _broken(inv):
        raise ValueError("synthetic encoding failure for v1.1.0 test")

    try:
        tc._v11_encode = _broken
        policy = _mk_policy([RetryRateLimit(min_gap_seconds=30)])
        report = validate_totality(policy)
    finally:
        tc._v11_encode = original

    assert report.is_total is False
    assert report.reason_code == (
        GuaranteedFailureCode.TAU_TOTALITY_FAILED.value
    )
    assert any(
        "synthetic encoding failure" in node for node in report.unsupported_nodes
    )


# ── mutation forms flow through stage 3 ────────────────────────────────


def test_new_mutation_form_tighten_window_accepted():
    policy = _mk_policy(
        [RollingWindowCap(max_count=10, window_seconds=60)],
        mutation_forms=["tighten_window"],
    )
    report = validate_totality(policy)
    assert report.is_total is True


def test_new_mutation_form_shorten_retry_cooldown_accepted():
    policy = _mk_policy(
        [RetryRateLimit(min_gap_seconds=30)],
        mutation_forms=["shorten_retry_cooldown"],
    )
    report = validate_totality(policy)
    assert report.is_total is True


def test_new_mutation_form_tighten_burst_cap_accepted():
    policy = _mk_policy(
        [BurstVelocityCap(max_per_window=Decimal("100"), window_seconds=10)],
        mutation_forms=["tighten_burst_cap"],
    )
    report = validate_totality(policy)
    assert report.is_total is True


def test_report_shape_is_stable_across_new_rule_types():
    report = validate_totality(_mk_policy([RetryRateLimit(min_gap_seconds=30)]))
    assert isinstance(report, TotalityReport)
    assert isinstance(report.unsupported_nodes, tuple)
    assert report.language_version == GUARANTEED_LANGUAGE_VERSION
