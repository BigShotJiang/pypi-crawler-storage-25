"""Canonical envelope tests for Guaranteed-Mode rejections (v0.19.0).

The product-switch brief pins the rejection envelope to this exact shape:

    {
      "allowed": False,
      "reason": "unsupported_for_guaranteed_mode",
      "details": {
        "unsupported_rule": "<rule_type>",
        "unsupported_variant": "<variant_name_or_null>",
        "language_tier_version": "1.2.0"
      }
    }

These tests pin the shape so a later refactor cannot silently drift. We
drive the gate directly through ``CageDaemon._guaranteed_reject`` and
``_guaranteed_admission_check`` where feasible so the tests don't depend
on a live Tau process.
"""

from __future__ import annotations

from decimal import Decimal
from pathlib import Path

import pytest

from adapter.guaranteed_errors import (
    GuaranteedFailure,
    GuaranteedFailureCode,
)
from adapter.guaranteed_language import (
    GUARANTEED_LANGUAGE_VERSION,
    GuaranteedLanguage,
)
from adapter.invariants import (
    CounterpartyConstraint,
    JurisdictionRule,
    MaxPerCall,
    ProviderAllowlist,
    SpendingCap,
)
from adapter.prover import PythonPatternProver, TauConsistencyProver
from daemon.server import (
    CageDaemon,
    _guaranteed_classify_variant,
    _guaranteed_failure_target,
)


def _daemon(tmp_path: Path) -> CageDaemon:
    return CageDaemon(
        socket_path=str(tmp_path / "envelope.sock"),
        prover=PythonPatternProver(),
        prover_mode="guaranteed",
        tau_prover=TauConsistencyProver(timeout_seconds=5.0),
    )


class TestEnvelopeShape:
    """Every brief-required field is present on the canonical envelope."""

    def test_envelope_has_allowed_false(self, tmp_path: Path) -> None:
        d = _daemon(tmp_path)
        inv = JurisdictionRule(
            jurisdiction="US",
            additional_invariants=(
                MaxPerCall(max_amount=Decimal("50"), currency="USDC"),
            ),
        )
        r = d._apply_revision(
            mutate=lambda reg: reg.declare(inv),
            kind="jurisdiction_rule",
            op_name="declare",
            delta_added=(inv,),
        )
        assert r["allowed"] is False

    def test_envelope_reason_is_unsupported_for_guaranteed_mode(
        self, tmp_path: Path
    ) -> None:
        d = _daemon(tmp_path)
        inv = JurisdictionRule(
            jurisdiction="EU",
            additional_invariants=(
                MaxPerCall(max_amount=Decimal("10"), currency="USDC"),
            ),
        )
        r = d._apply_revision(
            mutate=lambda reg: reg.declare(inv),
            kind="jurisdiction_rule",
            op_name="declare",
            delta_added=(inv,),
        )
        assert r["reason"] == "unsupported_for_guaranteed_mode"

    def test_envelope_details_names_rule_type(self, tmp_path: Path) -> None:
        d = _daemon(tmp_path)
        inv = JurisdictionRule(
            jurisdiction="US",
            additional_invariants=(
                MaxPerCall(max_amount=Decimal("50"), currency="USDC"),
            ),
        )
        r = d._apply_revision(
            mutate=lambda reg: reg.declare(inv),
            kind="jurisdiction_rule",
            op_name="declare",
            delta_added=(inv,),
        )
        assert r["details"]["unsupported_rule"] == "JurisdictionRule"

    def test_envelope_details_carries_variant_tag(self, tmp_path: Path) -> None:
        """Test 2 variant slot (brief): nested-composition variant names it."""
        d = _daemon(tmp_path)
        inv = JurisdictionRule(
            jurisdiction="US",
            additional_invariants=(
                MaxPerCall(max_amount=Decimal("50"), currency="USDC"),
            ),
        )
        r = d._apply_revision(
            mutate=lambda reg: reg.declare(inv),
            kind="jurisdiction_rule",
            op_name="declare",
            delta_added=(inv,),
        )
        assert r["details"]["unsupported_variant"] == "nested_composition"

    def test_envelope_language_tier_version_pinned_to_1_2_0(
        self, tmp_path: Path
    ) -> None:
        """Test 2 (brief): ``details.language_tier_version`` is always
        ``1.2.0`` on this branch (the :data:`GUARANTEED_LANGUAGE_VERSION`
        constant pins it)."""
        d = _daemon(tmp_path)
        inv = JurisdictionRule(
            jurisdiction="OTHER",
            additional_invariants=(
                MaxPerCall(max_amount=Decimal("1"), currency="USDC"),
            ),
        )
        r = d._apply_revision(
            mutate=lambda reg: reg.declare(inv),
            kind="jurisdiction_rule",
            op_name="declare",
            delta_added=(inv,),
        )
        assert r["details"]["language_tier_version"] == "1.2.0"
        # Paranoia: also check that the language tier module agrees.
        assert GUARANTEED_LANGUAGE_VERSION == "1.2.0"


# ── variant classifier ─────────────────────────────────────────────────────


class TestVariantClassifier:
    """`_guaranteed_classify_variant` names the shape of each rule class.

    These tests pin the taxonomy the envelope advertises so auditors can
    reason about which shape a rejection referred to.
    """

    def test_enum_bv_counterparty_classifies_as_enum_bv(self) -> None:
        """``approved_ids`` non-empty, ``sanctioned_ids`` empty -> enum_bv."""
        inv = CounterpartyConstraint(
            approved_ids=frozenset({"vendor_a"}),
            sanctioned_ids=frozenset(),
        )
        assert _guaranteed_classify_variant(inv) == "enum_bv"

    def test_sanctions_variant_classifies_as_sanctions_negation(self) -> None:
        """Pure sanctions variant (no approvals) -> sanctions_negation.

        The tier admits only the pure allowlist shape; any sanctioned
        constraint falls off."""
        inv = CounterpartyConstraint(
            approved_ids=frozenset(),
            sanctioned_ids=frozenset({"ofac_01"}),
        )
        assert _guaranteed_classify_variant(inv) == "sanctions_negation"

    def test_mixed_approved_plus_sanctioned_classifies_as_sanctions_negation(
        self,
    ) -> None:
        inv = CounterpartyConstraint(
            approved_ids=frozenset({"vendor_a"}),
            sanctioned_ids=frozenset({"ofac_01"}),
        )
        assert _guaranteed_classify_variant(inv) == "sanctions_negation"

    def test_flat_jurisdiction_classifies_as_enum_bv(self) -> None:
        inv = JurisdictionRule(jurisdiction="EU", additional_invariants=())
        assert _guaranteed_classify_variant(inv) == "enum_bv"

    def test_nested_jurisdiction_classifies_as_nested_composition(self) -> None:
        inv = JurisdictionRule(
            jurisdiction="US",
            additional_invariants=(
                MaxPerCall(max_amount=Decimal("50"), currency="USDC"),
            ),
        )
        assert _guaranteed_classify_variant(inv) == "nested_composition"


# ── failure-code coverage ──────────────────────────────────────────────────


class TestEachFailureCodeSurfacesEnvelope:
    """Every ``GuaranteedFailureCode`` routes through the envelope helper
    and surfaces a brief-shaped ``reason`` field.

    We don't need to run the Tau prover for these assertions — we drive
    :meth:`CageDaemon._guaranteed_reject` directly with synthetic failure
    codes. This is the "Test 2 (brief): every code surfaces the correct
    reason string" case from the brief.
    """

    def test_unsupported_for_guaranteed_mode_maps_to_canonical_reason(
        self, tmp_path: Path
    ) -> None:
        d = _daemon(tmp_path)
        envelope = d._guaranteed_reject(
            rule_name="JurisdictionRule",
            variant="nested_composition",
            language_tier_version="1.2.0",
            reason_code=GuaranteedFailureCode.UNSUPPORTED_FOR_GUARANTEED_MODE,
            message="stub",
            kind="declare",
            old_reg=d._x402_registry,
        )
        assert envelope["reason"] == "unsupported_for_guaranteed_mode"
        assert envelope["allowed"] is False
        assert envelope["details"]["unsupported_rule"] == "JurisdictionRule"
        assert envelope["details"]["unsupported_variant"] == "nested_composition"
        assert envelope["details"]["language_tier_version"] == "1.2.0"

    def test_every_failure_code_produces_allowed_false_envelope(
        self, tmp_path: Path
    ) -> None:
        """All codes in ``GuaranteedFailureCode`` must route through the
        helper without KeyErrors and produce ``allowed: False``."""
        d = _daemon(tmp_path)
        for code in GuaranteedFailureCode:
            env = d._guaranteed_reject(
                rule_name="(policy)",
                variant=None,
                language_tier_version="1.2.0",
                reason_code=code,
                message=f"stub-for-{code.value}",
                kind="declare",
                old_reg=d._x402_registry,
            )
            assert env["allowed"] is False, code
            assert "details" in env, code
            # The ``reason`` field is the lowercase brief code for the
            # canonical UNSUPPORTED failure and the lowercased enum
            # value for every other path.
            if code is GuaranteedFailureCode.UNSUPPORTED_FOR_GUARANTEED_MODE:
                assert env["reason"] == "unsupported_for_guaranteed_mode", code
            else:
                assert env["reason"] == code.value.lower(), code
            # `details.language_tier_version` is pinned on every code.
            assert env["details"]["language_tier_version"] == "1.2.0", code

    def test_totality_failure_carries_policy_scoped_reject(
        self, tmp_path: Path
    ) -> None:
        """A ``TAU_TOTALITY_FAILED`` code should name ``(policy)`` when we
        can't attribute it to a single rule, and the variant slot should
        be ``None``."""
        d = _daemon(tmp_path)
        env = d._guaranteed_reject(
            rule_name="(policy)",
            variant=None,
            language_tier_version="1.2.0",
            reason_code=GuaranteedFailureCode.TAU_TOTALITY_FAILED,
            message="totality check rejected the policy",
            kind="declare",
            old_reg=d._x402_registry,
        )
        assert env["details"]["unsupported_rule"] == "(policy)"
        assert env["details"]["unsupported_variant"] is None
        assert env["reason"] == "tau_totality_failed"


# ── unsupported routing from failure target helper ────────────────────────


class TestFailureTargetHelper:
    """`_guaranteed_failure_target` picks the first unsupported invariant."""

    def test_identifies_first_unsupported_rule(self) -> None:
        # Mixed policy: one admissible rule, one unsupported.
        admissible = MaxPerCall(max_amount=Decimal("50"), currency="USDC")
        unsupported = JurisdictionRule(
            jurisdiction="US",
            additional_invariants=(
                MaxPerCall(max_amount=Decimal("5"), currency="USDC"),
            ),
        )
        # Fake failure object — helper doesn't actually read its fields,
        # only uses the invariants list.
        failure = GuaranteedFailure(
            code=GuaranteedFailureCode.UNSUPPORTED_FOR_GUARANTEED_MODE,
            message="stub",
        )
        name, variant = _guaranteed_failure_target(
            (admissible, unsupported), failure
        )
        assert name == "JurisdictionRule"
        assert variant == "nested_composition"

    def test_falls_back_to_policy_when_all_admissible(self) -> None:
        admissible = ProviderAllowlist(providers=frozenset({"anthropic"}))
        failure = GuaranteedFailure(
            code=GuaranteedFailureCode.TAU_TOTALITY_FAILED,
            message="stub",
        )
        name, variant = _guaranteed_failure_target((admissible,), failure)
        assert name == "(policy)"
        assert variant is None
