"""Tests for the meta-policy tier (v0.22.0).

Covers:
  * invariant-level construction validation for ``AdaptiveTighteningPolicy``
    and ``PeerAuthenticationPolicy``.
  * ``admit_meta_policies`` happy path and property-by-property failures.
  * NoWeakening semantics for both meta-policies.
  * ``GuaranteedLanguage`` v1.2.0 surface: SUPPORTED_META_POLICIES,
    ``is_supported`` admits meta-policies, ``describe`` exposes the set.
  * ``GuaranteedMutationPipeline`` rejects a mutation that introduces a
    malformed meta-policy with ``REVISION_TRANSITION_VIOLATION``.
  * ``GuaranteedMutationPipeline`` accepts a mutation that introduces a
    valid meta-policy.
  * Runtime tie: the Tau-admitted parameters drive a runtime
    ``AdaptiveTightening`` instance.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field, replace
from decimal import Decimal
from typing import Any, Mapping, Optional, Tuple

import pytest

from adapter.adaptive_tightening import AdaptiveTightening
from adapter.cross_revision import (
    CrossRevisionValidator,
    NoWeakening,
)
from adapter.guaranteed_errors import GuaranteedFailureCode
from adapter.guaranteed_language import (
    GUARANTEED_LANGUAGE_VERSION,
    GuaranteedLanguage,
)
from adapter.guaranteed_mutation import (
    GuaranteedMutationPipeline,
)
from adapter.invariants import (
    AdaptiveTighteningPolicy,
    InvariantError,
    MaxPerCall,
    PeerAuthenticationPolicy,
    SpendingCap,
)
from adapter.meta_policy import (
    META_POLICY_BV_SCALE,
    META_POLICY_LANGUAGE_VERSION,
    MetaPolicyFailureCode,
    MetaPolicyReport,
    admit_meta_policies,
)
from adapter.policy_revision import PolicyRevision


# ── helpers ─────────────────────────────────────────────────────────────────


def _valid_adaptive(**over: Any) -> AdaptiveTighteningPolicy:
    """Build a valid AdaptiveTighteningPolicy with overridable fields."""
    kwargs: dict = dict(
        retry_density_per_min_threshold=Decimal("10"),
        denial_rate_threshold=Decimal("0.3"),
        velocity_multiplier_threshold=Decimal("3"),
        identical_count_threshold=4,
        identical_window_seconds=30,
        decision_window_seconds=20,
        half_life_seconds=900,
        per_trigger_deltas={
            "retry_density": Decimal("0.4"),
            "denial_rate": Decimal("0.3"),
            "velocity_spike": Decimal("0.35"),
            "identical_request": Decimal("0.35"),
        },
    )
    kwargs.update(over)
    return AdaptiveTighteningPolicy(**kwargs)


def _valid_peer(**over: Any) -> PeerAuthenticationPolicy:
    kwargs: dict = dict(
        allowed_peer_uids=frozenset({501, 502}),
        allowed_actor_claims=frozenset({"ops-team"}),
        allowed_signing_keys=frozenset({"key-abc"}),
        require_peer_uid=True,
        require_signed_actor_claim=False,
    )
    kwargs.update(over)
    return PeerAuthenticationPolicy(**kwargs)


def _revision(
    invariants: Tuple[Any, ...],
    *,
    revision_id: str = "rev-test",
    predecessor: Optional[str] = None,
    branch: str = "main",
) -> PolicyRevision:
    return PolicyRevision(
        revision_id=revision_id,
        invariants=invariants,
        proof_backend="python-pattern",
        proof_strength="pattern",
        prover_mode="compat",
        compile_hash=None,
        fragment_version=None,
        tau_backend_version=None,
        admitted_at_unix=1_713_000_000,
        predecessor_revision_id=predecessor,
        delta={},
        revision_depth=0,
        branch=branch,
        affected_scope=None,
    )


# ── 1. Invariant construction ───────────────────────────────────────────────


def test_valid_adaptive_policy_builds():
    p = _valid_adaptive()
    assert p.half_life_seconds == 900
    assert p.max_delta() == Decimal("0.4")
    # Frozen dataclass — hashable.
    assert hash(p) == hash(_valid_adaptive())


def test_adaptive_policy_rejects_non_positive_half_life():
    with pytest.raises(InvariantError, match="half_life_seconds must be > 0"):
        _valid_adaptive(half_life_seconds=0)
    with pytest.raises(InvariantError, match="half_life_seconds must be > 0"):
        _valid_adaptive(half_life_seconds=-10)


def test_adaptive_policy_rejects_delta_above_one():
    with pytest.raises(InvariantError, match="must be in \\[0, 1\\]"):
        _valid_adaptive(per_trigger_deltas={
            "retry_density": Decimal("1.5"),
        })


def test_adaptive_policy_rejects_unknown_trigger():
    with pytest.raises(InvariantError, match="unknown trigger"):
        _valid_adaptive(per_trigger_deltas={
            "bogus_trigger": Decimal("0.3"),
        })


def test_adaptive_policy_rejects_empty_deltas():
    with pytest.raises(InvariantError, match="at least one per_trigger_delta"):
        _valid_adaptive(per_trigger_deltas={})


def test_adaptive_policy_rejects_denial_rate_out_of_range():
    with pytest.raises(InvariantError, match="denial_rate_threshold"):
        _valid_adaptive(denial_rate_threshold=Decimal("1.5"))
    with pytest.raises(InvariantError, match="denial_rate_threshold"):
        _valid_adaptive(denial_rate_threshold=Decimal("0"))


def test_adaptive_policy_rejects_velocity_multiplier_not_strict_gt_one():
    with pytest.raises(InvariantError, match="velocity_multiplier_threshold"):
        _valid_adaptive(velocity_multiplier_threshold=Decimal("1"))


def test_peer_policy_rejects_empty_uid_set():
    with pytest.raises(InvariantError, match="allowed_peer_uids must be non-empty"):
        PeerAuthenticationPolicy(allowed_peer_uids=frozenset())


def test_peer_policy_rejects_negative_uid():
    with pytest.raises(InvariantError, match="non-negative"):
        PeerAuthenticationPolicy(allowed_peer_uids=frozenset({-1}))


def test_peer_policy_require_signed_claim_needs_keys():
    with pytest.raises(InvariantError, match="require_signed_actor_claim"):
        PeerAuthenticationPolicy(
            allowed_peer_uids=frozenset({501}),
            allowed_signing_keys=frozenset(),
            require_signed_actor_claim=True,
        )


def test_peer_policy_authorises_connection_by_uid():
    p = _valid_peer()
    assert p.authorises_connection(501) is True
    assert p.authorises_connection(502) is True
    assert p.authorises_connection(999) is False
    # None + require_peer_uid=True → reject.
    assert p.authorises_connection(None) is False


def test_peer_policy_authorises_actor_via_claim_or_signing_key():
    p = _valid_peer()
    assert p.authorises_actor(actor_id="ops-team", actor_claim_signature_key_id=None) is True
    assert p.authorises_actor(actor_id=None, actor_claim_signature_key_id="key-abc") is True
    assert p.authorises_actor(actor_id="unknown", actor_claim_signature_key_id=None) is False


# ── 2. admit_meta_policies ──────────────────────────────────────────────────


def test_admit_accepts_valid_adaptive_policy():
    rev = _revision((_valid_adaptive(),))
    report = admit_meta_policies(rev)
    assert report.is_admitted is True
    assert report.reason_code is None
    assert "AdaptiveTighteningPolicy#0" in report.details


def test_admit_accepts_valid_peer_policy():
    rev = _revision((_valid_peer(),))
    report = admit_meta_policies(rev)
    assert report.is_admitted is True
    assert report.reason_code is None


def test_admit_accepts_raw_invariant_sequence():
    report = admit_meta_policies([_valid_adaptive(), _valid_peer()])
    assert report.is_admitted is True


def test_admit_ignores_non_meta_invariants():
    # Regular payment-rule invariants don't participate in meta-admission;
    # they should just be skipped (admission succeeds with an empty detail
    # block for them).
    rev = _revision((
        MaxPerCall(max_amount=Decimal("1")),
        SpendingCap(max_amount=Decimal("10"), scope="per_tx"),
    ))
    report = admit_meta_policies(rev)
    assert report.is_admitted is True
    assert report.details == {}


def test_admit_rejects_delta_saturating_in_one_step():
    # max_delta >= 1 fails the single_observation_bound property. We have
    # to bypass the invariant's own upper-bound check by handing it
    # exactly 1.0 — which is in [0,1] at construction but fails the
    # STRICT-< admission property.
    policy = _valid_adaptive(per_trigger_deltas={
        "retry_density": Decimal("1"),
    })
    report = admit_meta_policies([policy])
    assert report.is_admitted is False
    assert report.reason_code is MetaPolicyFailureCode.DELTA_SATURATES_IN_ONE_STEP


def test_admit_report_round_trips_through_json():
    rev = _revision((_valid_adaptive(), _valid_peer()))
    report = admit_meta_policies(rev)
    blob = json.dumps(report.to_dict())
    restored = json.loads(blob)
    assert restored["is_admitted"] is True
    assert restored["meta_language_version"] == META_POLICY_LANGUAGE_VERSION
    assert "AdaptiveTighteningPolicy#0" in restored["details"]


def test_admit_bv_scale_matches_cage_micro_unit_convention():
    # The cage elsewhere uses 10^6 micro-unit scaling (USDC micro-units).
    # Our meta-policy fixed-point scale must match so thresholds declared
    # in USDC-style Decimals project losslessly into bv[64].
    assert META_POLICY_BV_SCALE == 1_000_000


def test_admit_records_bv_projections_in_detail():
    rev = _revision((_valid_adaptive(),))
    report = admit_meta_policies(rev)
    detail = report.details["AdaptiveTighteningPolicy#0"]
    assert detail["admitted"] is True
    scaled = detail["symbolic"]["scaled_thresholds"]
    # Decimal('0.3') * 10^6 == 300000
    assert scaled["denial_rate_threshold"] == 300_000


def test_admit_rejects_empty_peer_set_via_policy_proxy():
    # PeerAuthenticationPolicy refuses empty uid set at construction, so
    # we hand admit_meta_policies a stub object that exposes the same
    # attribute contract but with an empty set — the admission path still
    # flags it. This keeps the empty-set property checked end-to-end.
    @dataclass(frozen=True)
    class _StubEmpty(PeerAuthenticationPolicy):
        # inherits fields; override allowed_peer_uids in the admitted proxy
        pass

    # The construction guard runs first; build a valid policy then simulate
    # an empty uid set via the admission pipeline directly.
    policy = _valid_peer()
    object.__setattr__(policy, "allowed_peer_uids", frozenset())
    report = admit_meta_policies([policy])
    assert report.is_admitted is False
    assert report.reason_code is MetaPolicyFailureCode.EMPTY_PEER_SET


# ── 3. NoWeakening semantics ────────────────────────────────────────────────


def test_no_weakening_raising_threshold_is_weakening():
    old = _revision((_valid_adaptive(),), revision_id="r1")
    weaker = _valid_adaptive(
        retry_density_per_min_threshold=Decimal("50"),  # raised → fires less
    )
    new = _revision(
        (weaker,), revision_id="r2", predecessor="r1",
    )
    result = NoWeakening().validate_transition(old, new, branch="main")
    assert len(result) >= 1
    assert any(
        v.category == "weakened_adaptive_tightening_threshold" for v in result
    )


def test_no_weakening_lowering_threshold_passes():
    old = _revision((_valid_adaptive(),), revision_id="r1")
    stricter = _valid_adaptive(
        retry_density_per_min_threshold=Decimal("5"),  # lowered → fires more
    )
    new = _revision(
        (stricter,), revision_id="r2", predecessor="r1",
    )
    result = NoWeakening().validate_transition(old, new, branch="main")
    assert result == ()


def test_no_weakening_shorter_half_life_is_weakening():
    old = _revision((_valid_adaptive(half_life_seconds=1800),), revision_id="r1")
    new = _revision(
        (_valid_adaptive(half_life_seconds=600),),
        revision_id="r2",
        predecessor="r1",
    )
    result = NoWeakening().validate_transition(old, new, branch="main")
    assert any(
        v.category == "weakened_adaptive_tightening_half_life" for v in result
    )


def test_no_weakening_removing_adaptive_policy_is_weakening():
    old = _revision((_valid_adaptive(),), revision_id="r1")
    new = _revision((), revision_id="r2", predecessor="r1")
    result = NoWeakening().validate_transition(old, new, branch="main")
    assert any(
        v.category == "removed_adaptive_tightening_policy" for v in result
    )


def test_no_weakening_adding_peer_uid_is_weakening():
    old = _revision((_valid_peer(allowed_peer_uids=frozenset({501})),), revision_id="r1")
    new = _revision(
        (_valid_peer(allowed_peer_uids=frozenset({501, 502})),),
        revision_id="r2",
        predecessor="r1",
    )
    result = NoWeakening().validate_transition(old, new, branch="main")
    assert any(
        v.category == "weakened_peer_authentication_uids" for v in result
    )


def test_no_weakening_removing_peer_uid_passes():
    old = _revision(
        (_valid_peer(allowed_peer_uids=frozenset({501, 502})),), revision_id="r1",
    )
    new = _revision(
        (_valid_peer(allowed_peer_uids=frozenset({501})),),
        revision_id="r2",
        predecessor="r1",
    )
    result = NoWeakening().validate_transition(old, new, branch="main")
    assert result == ()


def test_no_weakening_dropping_require_peer_uid_is_weakening():
    old = _revision(
        (_valid_peer(require_peer_uid=True),), revision_id="r1",
    )
    new = _revision(
        (_valid_peer(require_peer_uid=False),),
        revision_id="r2",
        predecessor="r1",
    )
    result = NoWeakening().validate_transition(old, new, branch="main")
    assert any(
        v.category == "weakened_peer_authentication_require_peer_uid"
        for v in result
    )


def test_no_weakening_feature_branch_does_not_fire():
    """NoWeakening only runs on the monitored branch."""
    old = _revision((_valid_peer(),), revision_id="r1", branch="feature/x")
    widened = _valid_peer(allowed_peer_uids=frozenset({501, 502, 999}))
    new = _revision(
        (widened,), revision_id="r2", predecessor="r1", branch="feature/x",
    )
    result = NoWeakening().validate_transition(old, new, branch="feature/x")
    assert result == ()


# ── 4. GuaranteedLanguage v1.2.0 surface ────────────────────────────────────


def test_language_version_bumped_to_1_2_0():
    assert GUARANTEED_LANGUAGE_VERSION == "1.2.0"


def test_supported_meta_policies_has_both_entries():
    assert GuaranteedLanguage.SUPPORTED_META_POLICIES == frozenset({
        "AdaptiveTighteningPolicy",
        "PeerAuthenticationPolicy",
    })


def test_supported_meta_policies_is_frozen():
    assert isinstance(GuaranteedLanguage.SUPPORTED_META_POLICIES, frozenset)


def test_is_supported_admits_adaptive_tightening_policy():
    ok, code = GuaranteedLanguage.is_supported(_valid_adaptive())
    assert ok is True
    assert code is None


def test_is_supported_admits_peer_authentication_policy():
    ok, code = GuaranteedLanguage.is_supported(_valid_peer())
    assert ok is True
    assert code is None


def test_describe_exposes_meta_policies():
    surface = GuaranteedLanguage.describe()
    assert "AdaptiveTighteningPolicy" in surface["supported_meta_policies"]
    assert "PeerAuthenticationPolicy" in surface["supported_meta_policies"]


def test_is_meta_policy_supported_helper():
    assert GuaranteedLanguage.is_meta_policy_supported("AdaptiveTighteningPolicy")
    assert GuaranteedLanguage.is_meta_policy_supported("PeerAuthenticationPolicy")
    assert not GuaranteedLanguage.is_meta_policy_supported("NotAPolicy")


# ── 5. GuaranteedMutationPipeline gate ──────────────────────────────────────


@dataclass(frozen=True)
class _FakeProofArtifact:
    artifact_id: str
    policy_revision_id: str
    proof_result: str = "consistent"
    artifact_hash: str = ""


@dataclass(frozen=True)
class _FakeProofResult:
    consistent: bool
    decisive: bool
    reason: str = ""
    artifact: Optional[_FakeProofArtifact] = None


class _DecisiveProver:
    def __init__(self) -> None:
        self.calls = 0

    def prove(self, candidate: Any) -> _FakeProofResult:
        self.calls += 1
        rev_id = getattr(candidate, "revision_id", "stub")
        return _FakeProofResult(
            consistent=True,
            decisive=True,
            artifact=_FakeProofArtifact(
                artifact_id=f"artifact-{self.calls}",
                policy_revision_id=str(rev_id),
            ),
        )


def _candidate_from_invariants(current, mutation):
    """Mutation in the test is itself the candidate revision."""
    return mutation


def test_pipeline_rejects_invalid_meta_policy_via_admission():
    """A mutation that introduces a malformed meta-policy rejects."""
    # An AdaptiveTighteningPolicy with delta=1.0 passes construction but
    # fails admission (single_observation_bound).
    bad = _valid_adaptive(per_trigger_deltas={"retry_density": Decimal("1")})
    old_rev = _revision((), revision_id="r0")
    new_rev = _revision((bad,), revision_id="r1", predecessor="r0")

    pipeline = GuaranteedMutationPipeline(
        totality_fn=lambda _: _TotalityOk(),
        prover=_DecisiveProver(),
        transition_validator=CrossRevisionValidator(invariants=()),
        build_candidate_fn=_candidate_from_invariants,
    )
    proposal = pipeline.propose(old_rev, new_rev)
    assert proposal.activatable is False
    assert proposal.failure is not None
    # The real GuaranteedFailureCode is an enum, but stub schemas also
    # accept string codes; compare on the .value for stability.
    code_value = getattr(
        proposal.failure.code, "value", proposal.failure.code,
    )
    assert code_value == "REVISION_TRANSITION_VIOLATION"
    # The detail trail carries the meta-policy report.
    details = getattr(proposal.failure, "context", None) or getattr(
        proposal.failure, "details", {}
    )
    assert "meta_policy_report" in details


def test_pipeline_accepts_valid_meta_policies():
    new_rev = _revision(
        (_valid_adaptive(), _valid_peer()),
        revision_id="r1",
        predecessor=None,
    )
    pipeline = GuaranteedMutationPipeline(
        totality_fn=lambda _: _TotalityOk(),
        prover=_DecisiveProver(),
        transition_validator=CrossRevisionValidator(invariants=()),
        build_candidate_fn=_candidate_from_invariants,
    )
    proposal = pipeline.propose(None, new_rev)
    assert proposal.activatable is True
    assert proposal.failure is None


@dataclass(frozen=True)
class _TotalityOk:
    """Satisfies both schemas: has is_total + total."""
    is_total: bool = True
    total: bool = True
    reason: str = ""
    reason_code: Optional[str] = None
    unsupported_nodes: Tuple = ()
    language_version: str = GUARANTEED_LANGUAGE_VERSION


# ── 6. Runtime tie — AdaptiveTightening takes the admitted parameters ──────


def test_admitted_policy_drives_runtime_adaptive_tightening():
    """Construct an AdaptiveTightening from an admitted policy and verify
    the runtime instance honours every parameter on the policy.
    """
    policy = _valid_adaptive(
        half_life_seconds=300,
        per_trigger_deltas={
            "retry_density": Decimal("0.5"),
            "velocity_spike": Decimal("0.25"),
        },
    )
    # Admission must pass.
    report = admit_meta_policies([policy])
    assert report.is_admitted is True

    # Build the runtime from the admitted parameters. ``AdaptiveTightening``
    # accepts thresholds and deltas as mappings of floats; we project the
    # policy's Decimals into floats at the boundary.
    thresholds = {
        "retry_density_per_min": float(policy.retry_density_per_min_threshold),
        "denial_rate": float(policy.denial_rate_threshold),
        "velocity_multiplier": float(policy.velocity_multiplier_threshold),
        "identical_count": float(policy.identical_count_threshold),
        "identical_window_seconds": float(policy.identical_window_seconds),
        "decision_window": float(policy.decision_window_seconds),
    }
    deltas = {k: float(v) for k, v in policy.per_trigger_deltas}
    runtime = AdaptiveTightening(
        half_life_seconds=policy.half_life_seconds,
        trigger_thresholds=thresholds,
        trigger_deltas=deltas,
    )
    assert runtime.half_life_seconds == 300
    assert runtime.trigger_deltas["retry_density"] == pytest.approx(0.5)
    assert runtime.trigger_deltas["velocity_spike"] == pytest.approx(0.25)
    assert runtime.trigger_thresholds["velocity_multiplier"] == pytest.approx(3.0)
