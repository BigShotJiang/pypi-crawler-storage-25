"""Coverage-gated tests for the thin client SDK, re-run inside the main suite.

The authoritative client tests live in ``client/tests/test_client.py`` and
exercise the sub-package without pulling cage deps. Those tests cannot be
collected by the main ``tests/`` suite because both packages register a
``tests`` package with an empty ``__init__.py`` and pytest rejects the
duplicate module name.

This file mirrors the same coverage surface so the ``--cov=client`` gate
in CI sees the client code exercised without needing to collect the
out-of-tree ``client/tests/`` directory. Additions are strictly tests —
the client source is unchanged.
"""
from __future__ import annotations

import hashlib
import hmac
import time
from typing import Any, Callable, Dict, Optional

import httpx
import pytest

from tau_x402_cage_client import (
    AsyncClient,
    CageError,
    Client,
    PolicyRejected,
    SignatureError,
    VerdictVerifier,
)
from tau_x402_cage_client.verify import (
    ALG_ED25519,
    ALG_HMAC_SHA256,
    WIRE_VERSION_V1,
    WIRE_VERSION_V2,
    _canonical_mac_input,
    _hash_intent_canonical,
)


HMAC_SECRET = b"this-is-a-test-secret-long-enough-for-hmac"
OTHER_SECRET = b"a-different-secret-also-long-enough-xxxxx"


def _make_intent() -> Dict[str, Any]:
    return {
        "amount": "50",
        "currency": "USDC",
        "provider": "anthropic",
        "counterparty": "vendor_x",
        "rail": "x402",
        "timestamp_unix": 1713456789,
        "metadata": {},
        "request_id": None,
    }


def _hmac_envelope(
    *,
    outcome: str = "permit",
    rule_id: Optional[str] = None,
    reason_text: Optional[str] = None,
    intent: Optional[Dict[str, Any]] = None,
    issued_at_unix: int = 1713456789,
    ttl_seconds: int = 30,
    secret: bytes = HMAC_SECRET,
    version: str = WIRE_VERSION_V1,
) -> Dict[str, Any]:
    intent = intent or _make_intent()
    intent_hash = _hash_intent_canonical(intent)
    payload = _canonical_mac_input(
        outcome,
        rule_id,
        None,
        reason_text,
        issued_at_unix,
        ttl_seconds,
        intent_hash,
        version=version,
        algorithm=ALG_HMAC_SHA256,
    )
    mac_hex = hmac.new(secret, payload, hashlib.sha256).hexdigest()
    return {
        "outcome": outcome,
        "rule_id": rule_id,
        "witness": None,
        "reason_text": reason_text,
        "issued_at_unix": issued_at_unix,
        "ttl_seconds": ttl_seconds,
        "intent_hash": intent_hash,
        "mac_hex": mac_hex,
        "mac_alg": "HMAC-SHA256",
        "algorithm": ALG_HMAC_SHA256,
        "version": version,
    }


def _mock_transport(handler: Callable[[httpx.Request], httpx.Response]) -> httpx.MockTransport:
    return httpx.MockTransport(handler)


class TestCheckPaymentCoverage:
    def test_permit_round_trip(self) -> None:
        env = _hmac_envelope(outcome="permit")

        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "POST"
            assert request.url.path == "/v1/check"
            return httpx.Response(200, json=env)

        with Client(
            base_url="https://example",
            bearer_token="test-token",
            transport=_mock_transport(handler),
        ) as client:
            result = client.check_payment(
                headers={"content-type": "application/json"},
                body=b'{"amount": "50"}',
            )
        assert result["outcome"] == "permit"

    def test_reject_returns_envelope_by_default(self) -> None:
        env = _hmac_envelope(
            outcome="reject", rule_id="max_per_call", reason_text="cap"
        )

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(402, json=env)

        with Client(
            base_url="https://example",
            bearer_token="t",
            transport=_mock_transport(handler),
        ) as client:
            result = client.check_payment(headers={}, body=b"{}")
        assert result["outcome"] == "reject"

    def test_reject_raises_when_opted_in(self) -> None:
        env = _hmac_envelope(outcome="reject", rule_id="spending_cap")

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(402, json=env)

        with Client(
            base_url="https://example",
            bearer_token="t",
            transport=_mock_transport(handler),
        ) as client:
            with pytest.raises(PolicyRejected) as excinfo:
                client.check_payment(headers={}, body=b"{}", raise_on_reject=True)
        assert excinfo.value.rule_id == "spending_cap"

    def test_http_503_raises_cage_error(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(503, json={"detail": "unreachable"})

        with Client(
            base_url="https://example",
            bearer_token="t",
            transport=_mock_transport(handler),
        ) as client:
            with pytest.raises(CageError) as excinfo:
                client.check_payment(headers={}, body=b"{}")
        assert excinfo.value.status_code == 503

    def test_http_402_without_envelope_raises(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(402, text="not json")

        with Client(
            base_url="https://example",
            bearer_token="t",
            transport=_mock_transport(handler),
        ) as client:
            with pytest.raises(CageError):
                client.check_payment(headers={}, body=b"{}")

    def test_non_json_response_raises_cage_error(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text="<html>oops</html>")

        with Client(
            base_url="https://example",
            bearer_token="t",
            transport=_mock_transport(handler),
        ) as client:
            with pytest.raises(CageError):
                client.check_payment(headers={}, body=b"{}")

    def test_hop_headers_are_stripped(self) -> None:
        seen: Dict[str, str] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            seen.update(dict(request.headers))
            return httpx.Response(200, json=_hmac_envelope())

        with Client(
            base_url="https://example",
            bearer_token="t",
            transport=_mock_transport(handler),
        ) as client:
            client.check_payment(
                headers={
                    "Host": "payer.example",
                    "Content-Length": "999",
                    "Authorization": "Bearer user",
                    "X-402-Intent": "keep",
                },
                body=b"{}",
            )
        assert seen.get("authorization") == "Bearer t"
        assert seen.get("x-402-intent") == "keep"


class TestReadOnlyEndpointsCoverage:
    def test_health(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.url.path == "/v1/health"
            return httpx.Response(200, json={"status": "ok"})

        with Client(
            base_url="https://example",
            bearer_token="t",
            transport=_mock_transport(handler),
        ) as client:
            assert client.health()["status"] == "ok"

    def test_inspect_policy(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, json={"revision_id": "r1", "invariants": []})

        with Client(
            base_url="https://example",
            bearer_token="t",
            transport=_mock_transport(handler),
        ) as client:
            assert client.inspect_policy()["revision_id"] == "r1"

    def test_list_revisions_with_limit(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.url.params.get("limit") == "5"
            return httpx.Response(200, json={"revisions": []})

        with Client(
            base_url="https://example",
            bearer_token="t",
            transport=_mock_transport(handler),
        ) as client:
            client.list_revisions(limit=5)

    def test_list_revisions_no_limit(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, json={"revisions": []})

        with Client(
            base_url="https://example",
            bearer_token="t",
            transport=_mock_transport(handler),
        ) as client:
            client.list_revisions()

    def test_list_proposals_with_status_filter(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.url.params.get("status") == "pending"
            return httpx.Response(200, json={"proposals": []})

        with Client(
            base_url="https://example",
            bearer_token="t",
            transport=_mock_transport(handler),
        ) as client:
            client.list_proposals(status="pending")

    def test_list_proposals_no_status(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, json={"proposals": []})

        with Client(
            base_url="https://example",
            bearer_token="t",
            transport=_mock_transport(handler),
        ) as client:
            client.list_proposals()

    def test_401_maps_to_cage_error(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(401, json={"detail": "invalid"})

        with Client(
            base_url="https://example",
            bearer_token="bad",
            transport=_mock_transport(handler),
        ) as client:
            with pytest.raises(CageError) as excinfo:
                client.inspect_policy()
        assert excinfo.value.status_code == 401

    def test_500_maps_to_cage_error(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(500, json={"detail": "boom"})

        with Client(
            base_url="https://example",
            bearer_token="t",
            transport=_mock_transport(handler),
        ) as client:
            with pytest.raises(CageError):
                client.inspect_policy()

    def test_429_maps_to_cage_error(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(429, json={"detail": "rate limited"})

        with Client(
            base_url="https://example",
            bearer_token="t",
            transport=_mock_transport(handler),
        ) as client:
            with pytest.raises(CageError) as excinfo:
                client.inspect_policy()
        assert excinfo.value.status_code == 429

    def test_http_402_with_envelope_returned(self) -> None:
        env = _hmac_envelope(outcome="permit")

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(402, json=env)

        with Client(
            base_url="https://example",
            bearer_token="t",
            transport=_mock_transport(handler),
        ) as client:
            # Read-only (not check_payment) on 402 should still map to error.
            with pytest.raises(CageError):
                client.inspect_policy()


class TestAsyncClientCoverage:
    @pytest.mark.asyncio
    async def test_async_check_payment(self) -> None:
        env = _hmac_envelope(outcome="permit")

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, json=env)

        async with AsyncClient(
            base_url="https://example",
            bearer_token="t",
            transport=httpx.MockTransport(handler),
        ) as client:
            result = await client.check_payment(headers={}, body=b"{}")
        assert result["outcome"] == "permit"

    @pytest.mark.asyncio
    async def test_async_health(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, json={"status": "ok"})

        async with AsyncClient(
            base_url="https://example",
            bearer_token="t",
            transport=httpx.MockTransport(handler),
        ) as client:
            res = await client.health()
        assert res["status"] == "ok"

    @pytest.mark.asyncio
    async def test_async_reject_raises(self) -> None:
        env = _hmac_envelope(outcome="reject", rule_id="cap")

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(402, json=env)

        async with AsyncClient(
            base_url="https://example",
            bearer_token="t",
            transport=httpx.MockTransport(handler),
        ) as client:
            with pytest.raises(PolicyRejected):
                await client.check_payment(headers={}, body=b"{}", raise_on_reject=True)

    @pytest.mark.asyncio
    async def test_async_inspect_policy(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, json={"revision_id": "r"})

        async with AsyncClient(
            base_url="https://example",
            bearer_token="t",
            transport=httpx.MockTransport(handler),
        ) as client:
            p = await client.inspect_policy()
        assert p["revision_id"] == "r"

    @pytest.mark.asyncio
    async def test_async_list_revisions(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, json={"revisions": []})

        async with AsyncClient(
            base_url="https://example",
            bearer_token="t",
            transport=httpx.MockTransport(handler),
        ) as client:
            await client.list_revisions(limit=3)

    @pytest.mark.asyncio
    async def test_async_list_proposals(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, json={"proposals": []})

        async with AsyncClient(
            base_url="https://example",
            bearer_token="t",
            transport=httpx.MockTransport(handler),
        ) as client:
            await client.list_proposals(status="approved")


class TestVerifierHmacCoverage:
    def test_valid_hmac_round_trip(self) -> None:
        intent = _make_intent()
        env = _hmac_envelope(intent=intent, issued_at_unix=int(time.time()))
        VerdictVerifier(hmac_secret=HMAC_SECRET).verify(env, intent=intent)

    def test_tampered_envelope_fails(self) -> None:
        intent = _make_intent()
        env = _hmac_envelope(intent=intent, issued_at_unix=int(time.time()))
        env["outcome"] = "reject"
        with pytest.raises(SignatureError, match="MAC verification failed"):
            VerdictVerifier(hmac_secret=HMAC_SECRET).verify(env, intent=intent)

    def test_wrong_secret_fails(self) -> None:
        intent = _make_intent()
        env = _hmac_envelope(intent=intent, issued_at_unix=int(time.time()))
        with pytest.raises(SignatureError, match="MAC verification failed"):
            VerdictVerifier(hmac_secret=OTHER_SECRET).verify(env, intent=intent)

    def test_intent_hash_mismatch_detected(self) -> None:
        intent = _make_intent()
        env = _hmac_envelope(intent=intent, issued_at_unix=int(time.time()))
        different = dict(intent)
        different["amount"] = "999"
        with pytest.raises(SignatureError, match="intent_hash mismatch"):
            VerdictVerifier(hmac_secret=HMAC_SECRET).verify(env, intent=different)

    def test_expired_rejected(self) -> None:
        env = _hmac_envelope(issued_at_unix=int(time.time()) - 3600)
        with pytest.raises(SignatureError, match="expired"):
            VerdictVerifier(hmac_secret=HMAC_SECRET).verify(env)

    def test_skip_ttl_bypass(self) -> None:
        env = _hmac_envelope(issued_at_unix=int(time.time()) - 3600)
        VerdictVerifier(hmac_secret=HMAC_SECRET).verify(env, skip_ttl=True)

    def test_missing_required_field(self) -> None:
        env = _hmac_envelope()
        del env["mac_hex"]
        with pytest.raises(SignatureError, match="missing required fields"):
            VerdictVerifier(hmac_secret=HMAC_SECRET).verify(env)

    def test_unsupported_algorithm(self) -> None:
        env = _hmac_envelope()
        env["algorithm"] = "rsa-4096"
        with pytest.raises(SignatureError, match="unsupported signature algorithm"):
            VerdictVerifier(hmac_secret=HMAC_SECRET).verify(env)

    def test_v2_envelope_provenance_bound(self) -> None:
        intent = _make_intent()
        intent_hash = _hash_intent_canonical(intent)
        ts = int(time.time())
        payload = _canonical_mac_input(
            "permit", None, None, None, ts, 30, intent_hash,
            version=WIRE_VERSION_V2,
            policy_revision_id="rev_abc",
            proof_backend="pattern",
            proof_strength="pattern",
            prover_mode="compat",
            compile_hash="h",
            algorithm=ALG_HMAC_SHA256,
        )
        mac = hmac.new(HMAC_SECRET, payload, hashlib.sha256).hexdigest()
        env = {
            "outcome": "permit", "rule_id": None, "witness": None,
            "reason_text": None, "issued_at_unix": ts, "ttl_seconds": 30,
            "intent_hash": intent_hash, "mac_hex": mac,
            "mac_alg": "HMAC-SHA256", "algorithm": ALG_HMAC_SHA256,
            "version": WIRE_VERSION_V2, "policy_revision_id": "rev_abc",
            "proof_backend": "pattern", "proof_strength": "pattern",
            "prover_mode": "compat", "compile_hash": "h",
        }
        VerdictVerifier(hmac_secret=HMAC_SECRET).verify(env, intent=intent)


class TestVerifierEd25519Coverage:
    @staticmethod
    def _keypair() -> Any:
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
        private = Ed25519PrivateKey.generate()
        pub = private.public_key().public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        )
        return private, pub

    def _ed_env(self, private: Any, *, intent: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        intent = intent or _make_intent()
        intent_hash = _hash_intent_canonical(intent)
        ts = int(time.time())
        payload = _canonical_mac_input(
            "permit", None, None, None, ts, 30, intent_hash,
            version=WIRE_VERSION_V1, algorithm=ALG_ED25519,
        )
        signature = private.sign(payload)
        return {
            "outcome": "permit", "rule_id": None, "witness": None,
            "reason_text": None, "issued_at_unix": ts, "ttl_seconds": 30,
            "intent_hash": intent_hash, "mac_hex": signature.hex(),
            "mac_alg": "Ed25519", "algorithm": ALG_ED25519,
            "version": WIRE_VERSION_V1,
        }

    def test_valid_ed25519(self) -> None:
        private, pub = self._keypair()
        intent = _make_intent()
        env = self._ed_env(private, intent=intent)
        VerdictVerifier(ed25519_public_key_pem=pub).verify(env, intent=intent)

    def test_tampered_ed25519(self) -> None:
        private, pub = self._keypair()
        intent = _make_intent()
        env = self._ed_env(private, intent=intent)
        env["outcome"] = "reject"
        with pytest.raises(SignatureError, match="ed25519"):
            VerdictVerifier(ed25519_public_key_pem=pub).verify(env, intent=intent)

    def test_pem_as_str_accepted(self) -> None:
        private, pub = self._keypair()
        intent = _make_intent()
        env = self._ed_env(private, intent=intent)
        VerdictVerifier(ed25519_public_key_pem=pub.decode("utf-8")).verify(env, intent=intent)

    def test_ed25519_needs_pem(self) -> None:
        private, _pub = self._keypair()
        env = self._ed_env(private)
        with pytest.raises(SignatureError, match="ed25519"):
            VerdictVerifier(hmac_secret=HMAC_SECRET).verify(env)


class TestVerifierConstructionCoverage:
    def test_requires_key_material(self) -> None:
        with pytest.raises(ValueError, match="hmac_secret or ed25519"):
            VerdictVerifier()

    def test_short_hmac_secret_rejected(self) -> None:
        with pytest.raises(ValueError, match="at least 16 bytes"):
            VerdictVerifier(hmac_secret=b"shorty")
