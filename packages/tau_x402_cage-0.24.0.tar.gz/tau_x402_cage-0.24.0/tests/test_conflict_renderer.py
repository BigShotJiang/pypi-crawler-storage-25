"""Tests for adapter/conflict_renderer.py (v0.11.0).

Covers:
  * ``describe_invariant`` class-specific phrasing for every invariant type
    the policy_revision serializer knows about (8 classes).
  * ``render_conflict_text`` single-class conflicts (add/add, add/remove,
    modify/modify).
  * ``render_conflict_text`` multi-class conflicts: one paragraph per class.
  * ``render_branch_divergence`` top-level wrapper.
  * Unknown classes fall back to key=value dump without raising.
  * CLI ``branch merge`` conflict path uses the renderer end-to-end.
  * ``--json`` flag preserves raw dict output.
"""

from __future__ import annotations

import io
import json
import socket
import threading
from decimal import Decimal
from typing import Any, Dict
from unittest import mock

import pytest

from adapter.conflict_renderer import (
    describe_invariant,
    render_branch_divergence,
    render_conflict_text,
)
from adapter.policy_revision import BranchMergeConflict


# ── helpers ──────────────────────────────────────────────────────────────────


def _spending_cap_entry(
    amount: str = "100",
    currency: str = "USDC",
    scope: str = "per_window",
    window_seconds: int | None = 3600,
    provider: str | None = None,
) -> Dict[str, Any]:
    repr_d: Dict[str, Any] = {
        "max_amount": amount,
        "currency": currency,
        "scope": scope,
    }
    if window_seconds is not None:
        repr_d["window_seconds"] = window_seconds
    if provider is not None:
        repr_d["provider"] = provider
    return {"class_name": "SpendingCap", "repr": repr_d}


def _max_per_call_entry(amount: str = "20", currency: str = "USDC") -> Dict[str, Any]:
    return {
        "class_name": "MaxPerCall",
        "repr": {"max_amount": amount, "currency": currency},
    }


def _allowlist_entry(*providers: str) -> Dict[str, Any]:
    return {
        "class_name": "ProviderAllowlist",
        "repr": {"providers": sorted(providers)},
    }


def _retry_entry(gap: int) -> Dict[str, Any]:
    return {
        "class_name": "RetryRateLimit",
        "repr": {"min_gap_seconds": gap},
    }


def _rolling_entry(
    max_count: int, window: int, group_by: str = "provider"
) -> Dict[str, Any]:
    return {
        "class_name": "RollingWindowCap",
        "repr": {
            "max_count": max_count,
            "window_seconds": window,
            "group_by": group_by,
        },
    }


def _mutual_exclusion_entry(a: list[str], b: list[str]) -> Dict[str, Any]:
    return {
        "class_name": "MutualExclusion",
        "repr": {"group_a": sorted(a), "group_b": sorted(b)},
    }


def _jurisdiction_entry(
    jur: str, additional: list[Dict[str, Any]] | None = None
) -> Dict[str, Any]:
    return {
        "class_name": "JurisdictionRule",
        "repr": {
            "jurisdiction": jur,
            "additional_invariants": list(additional or []),
        },
    }


def _counterparty_entry(
    approved: list[str] | None = None, sanctioned: list[str] | None = None
) -> Dict[str, Any]:
    return {
        "class_name": "CounterpartyConstraint",
        "repr": {
            "approved_ids": sorted(approved or []),
            "sanctioned_ids": sorted(sanctioned or []),
        },
    }


# ── describe_invariant: one test per class ──────────────────────────────────


class TestDescribeInvariantPerClass:
    def test_spending_cap_per_window_with_provider(self) -> None:
        out = describe_invariant(
            _spending_cap_entry(
                amount="100",
                currency="USDC",
                scope="per_window",
                window_seconds=3600,
                provider="anthropic",
            )
        )
        assert "SpendingCap" in out
        assert "100 USDC" in out
        assert "per_window" in out
        assert "3600s" in out
        assert "anthropic" in out

    def test_spending_cap_per_tx_no_window(self) -> None:
        out = describe_invariant(
            _spending_cap_entry(
                amount="5", scope="per_tx", window_seconds=None
            )
        )
        assert "SpendingCap" in out
        assert "5 USDC" in out
        assert "per_tx" in out
        # No window → no '0s' noise.
        assert "0s" not in out

    def test_max_per_call(self) -> None:
        out = describe_invariant(_max_per_call_entry("20"))
        assert out == "MaxPerCall(20 USDC)"

    def test_provider_allowlist(self) -> None:
        out = describe_invariant(_allowlist_entry("anthropic", "openai"))
        assert "ProviderAllowlist" in out
        assert "anthropic" in out
        assert "openai" in out

    def test_provider_allowlist_empty(self) -> None:
        out = describe_invariant(
            {"class_name": "ProviderAllowlist", "repr": {"providers": []}}
        )
        assert "empty" in out

    def test_retry_rate_limit(self) -> None:
        out = describe_invariant(_retry_entry(5))
        assert "RetryRateLimit" in out
        assert "5s" in out

    def test_rolling_window_cap(self) -> None:
        out = describe_invariant(_rolling_entry(10, 60, "provider"))
        assert "RollingWindowCap" in out
        assert "max=10" in out
        assert "window=60s" in out
        assert "group_by=provider" in out

    def test_mutual_exclusion(self) -> None:
        out = describe_invariant(
            _mutual_exclusion_entry(["a", "b"], ["c", "d"])
        )
        assert "MutualExclusion" in out
        assert "a" in out and "b" in out
        assert "c" in out and "d" in out

    def test_jurisdiction_rule_no_subs(self) -> None:
        out = describe_invariant(_jurisdiction_entry("EU"))
        assert "JurisdictionRule" in out
        assert "EU" in out
        assert "no additional" in out

    def test_jurisdiction_rule_with_subs(self) -> None:
        sub = _max_per_call_entry("10")
        out = describe_invariant(_jurisdiction_entry("UK", [sub]))
        assert "JurisdictionRule" in out
        assert "UK" in out
        # Nested describer runs too.
        assert "MaxPerCall(10 USDC)" in out

    def test_counterparty_constraint_approved_only(self) -> None:
        out = describe_invariant(_counterparty_entry(approved=["acme"]))
        assert "CounterpartyConstraint" in out
        assert "approved" in out
        assert "acme" in out

    def test_counterparty_constraint_sanctioned_only(self) -> None:
        out = describe_invariant(_counterparty_entry(sanctioned=["blocked"]))
        assert "CounterpartyConstraint" in out
        assert "sanctioned" in out
        assert "blocked" in out

    def test_counterparty_constraint_empty(self) -> None:
        out = describe_invariant(_counterparty_entry())
        assert out == "CounterpartyConstraint(empty)"


class TestDescribeInvariantFallback:
    def test_unknown_class_falls_back_to_key_value(self) -> None:
        out = describe_invariant(
            {"class_name": "FutureInvariant", "repr": {"foo": 1, "bar": "x"}}
        )
        # Deterministic key order so the output is stable.
        assert out == "FutureInvariant(bar=x, foo=1)"

    def test_unknown_class_no_repr_keys(self) -> None:
        out = describe_invariant({"class_name": "Empty", "repr": {}})
        assert out == "Empty()"

    def test_missing_class_name_raises(self) -> None:
        with pytest.raises(TypeError):
            describe_invariant({"repr": {}})

    def test_missing_repr_raises(self) -> None:
        with pytest.raises(TypeError):
            describe_invariant({"class_name": "X"})

    def test_non_dict_input_raises(self) -> None:
        with pytest.raises(TypeError):
            describe_invariant("SpendingCap(100)")  # type: ignore[arg-type]


# ── render_branch_divergence ────────────────────────────────────────────────


class TestRenderBranchDivergence:
    def test_names_both_branches(self) -> None:
        conflict = BranchMergeConflict(
            src="shadow", dst="prod",
            src_head="s1", dst_head="d1",
            common_ancestor="rev-0",
            src_delta={"added": [], "removed": []},
            dst_delta={"added": [], "removed": []},
            conflicting_invariants=[],
        )
        out = render_branch_divergence("shadow", "prod", conflict)
        assert "shadow" in out
        assert "prod" in out
        assert "rev-0" in out

    def test_no_common_ancestor(self) -> None:
        conflict = BranchMergeConflict(
            src="a", dst="b",
            src_head="s1", dst_head="d1",
            common_ancestor=None,
            src_delta={"added": [], "removed": []},
            dst_delta={"added": [], "removed": []},
            conflicting_invariants=[],
        )
        out = render_branch_divergence("a", "b", conflict)
        assert "no common ancestor" in out


# ── render_conflict_text — single-class conflicts ───────────────────────────


class TestRenderConflictTextSingleClass:
    def test_both_sides_modify_spending_cap(self) -> None:
        """Both branches swap one SpendingCap for another of the same class."""
        src_delta = {
            "added": [_spending_cap_entry(amount="100", window_seconds=3600)],
            "removed": [_spending_cap_entry(amount="50", window_seconds=3600)],
        }
        dst_delta = {
            "added": [_spending_cap_entry(amount="200", window_seconds=3600)],
            "removed": [_spending_cap_entry(amount="50", window_seconds=3600)],
        }
        conflict = BranchMergeConflict(
            src="shadow", dst="prod",
            src_head="s1", dst_head="d1", common_ancestor="rev-0",
            src_delta=src_delta, dst_delta=dst_delta,
            conflicting_invariants=[{
                "class_name": "SpendingCap",
                "src_ops": ["added", "removed"],
                "dst_ops": ["added", "removed"],
            }],
        )
        out = render_conflict_text(conflict)
        assert "SpendingCap" in out
        assert "shadow" in out
        assert "prod" in out
        assert "100 USDC" in out
        assert "200 USDC" in out
        assert "50 USDC" in out
        assert "modified" in out

    def test_added_on_both_sides_disjoint_values(self) -> None:
        """Both sides added SpendingCap with different params → still conflict."""
        src_delta = {
            "added": [_spending_cap_entry(amount="100", provider="anthropic")],
            "removed": [],
        }
        dst_delta = {
            "added": [_spending_cap_entry(amount="200", provider="openai")],
            "removed": [],
        }
        conflict = BranchMergeConflict(
            src="shadow", dst="prod",
            src_head="s1", dst_head="d1", common_ancestor="rev-0",
            src_delta=src_delta, dst_delta=dst_delta,
            conflicting_invariants=[{
                "class_name": "SpendingCap",
                "src_ops": ["added"],
                "dst_ops": ["added"],
            }],
        )
        out = render_conflict_text(conflict)
        assert "SpendingCap" in out
        assert "added" in out
        assert "anthropic" in out
        assert "openai" in out

    def test_removed_on_one_side(self) -> None:
        """One side removes, other side adds — classic clash."""
        src_delta = {
            "added": [],
            "removed": [_spending_cap_entry(amount="50")],
        }
        dst_delta = {
            "added": [_spending_cap_entry(amount="100")],
            "removed": [],
        }
        conflict = BranchMergeConflict(
            src="shadow", dst="prod",
            src_head="s1", dst_head="d1", common_ancestor="rev-0",
            src_delta=src_delta, dst_delta=dst_delta,
            conflicting_invariants=[{
                "class_name": "SpendingCap",
                "src_ops": ["removed"],
                "dst_ops": ["added"],
            }],
        )
        out = render_conflict_text(conflict)
        assert "removed" in out
        assert "added" in out
        assert "shadow" in out
        assert "prod" in out


# ── multi-class conflicts ───────────────────────────────────────────────────


class TestRenderConflictTextMultiClass:
    def test_two_classes_render_as_two_paragraphs(self) -> None:
        src_delta = {
            "added": [
                _spending_cap_entry(amount="100"),
                _max_per_call_entry("10"),
            ],
            "removed": [],
        }
        dst_delta = {
            "added": [
                _spending_cap_entry(amount="200"),
                _max_per_call_entry("30"),
            ],
            "removed": [],
        }
        conflict = BranchMergeConflict(
            src="shadow", dst="prod",
            src_head="s1", dst_head="d1", common_ancestor="rev-0",
            src_delta=src_delta, dst_delta=dst_delta,
            conflicting_invariants=[
                {"class_name": "MaxPerCall", "src_ops": ["added"], "dst_ops": ["added"]},
                {"class_name": "SpendingCap", "src_ops": ["added"], "dst_ops": ["added"]},
            ],
        )
        out = render_conflict_text(conflict)
        # Both class headers appear.
        assert "SpendingCap" in out
        assert "MaxPerCall" in out
        # Each on its own line ⇒ the text has at least two newline-separated
        # class paragraphs after the header.
        parts = [p for p in out.split("\n") if p.strip()]
        assert any("SpendingCap" in p for p in parts)
        assert any("MaxPerCall" in p for p in parts)


# ── every invariant class round-trips through the full renderer ─────────────


class TestEveryClassRenders:
    @pytest.mark.parametrize(
        "entry, expected_label",
        [
            (_spending_cap_entry(), "SpendingCap"),
            (_max_per_call_entry(), "MaxPerCall"),
            (_allowlist_entry("x"), "ProviderAllowlist"),
            (_retry_entry(5), "RetryRateLimit"),
            (_rolling_entry(10, 60), "RollingWindowCap"),
            (_mutual_exclusion_entry(["a"], ["b"]), "MutualExclusion"),
            (_jurisdiction_entry("EU"), "JurisdictionRule"),
            (_counterparty_entry(approved=["c"]), "CounterpartyConstraint"),
        ],
    )
    def test_each_class_surfaces_in_rendered_conflict(
        self, entry: Dict[str, Any], expected_label: str
    ) -> None:
        conflict = BranchMergeConflict(
            src="src_b", dst="dst_b",
            src_head="s", dst_head="d", common_ancestor="rev-0",
            src_delta={"added": [entry], "removed": []},
            dst_delta={"added": [entry], "removed": []},
            conflicting_invariants=[{
                "class_name": expected_label,
                "src_ops": ["added"],
                "dst_ops": ["added"],
            }],
        )
        out = render_conflict_text(conflict)
        assert expected_label in out
        assert "src_b" in out
        assert "dst_b" in out


# ── accepts raw dict (what the daemon wire returns) ──────────────────────────


class TestAcceptsRawDict:
    def test_raw_dict_renders_like_dataclass(self) -> None:
        conflict = BranchMergeConflict(
            src="shadow", dst="prod",
            src_head="s1", dst_head="d1", common_ancestor="rev-0",
            src_delta={"added": [_max_per_call_entry("10")], "removed": []},
            dst_delta={"added": [_max_per_call_entry("20")], "removed": []},
            conflicting_invariants=[{
                "class_name": "MaxPerCall",
                "src_ops": ["added"],
                "dst_ops": ["added"],
            }],
        )
        dc_out = render_conflict_text(conflict)
        dict_out = render_conflict_text(conflict.to_dict())
        assert dc_out == dict_out

    def test_invalid_input_raises(self) -> None:
        with pytest.raises(TypeError):
            render_conflict_text(42)  # type: ignore[arg-type]


# ── CLI end-to-end: _branch_merge renders via conflict_renderer ─────────────


class TestCLIConflictPath:
    """The CLI conflict branch feeds the raw response into render_conflict_text.

    Rather than spin a real daemon (covered in test_three_way_merge.py), we
    mock ``_send_op`` so we exercise the renderer wiring deterministically.
    """

    def _fake_conflict_response(self) -> Dict[str, Any]:
        return {
            "verdict": "conflict",
            "merge_kind": "conflict",
            "src": "shadow",
            "dst": "prod",
            "src_head": "s1",
            "dst_head": "d1",
            "common_ancestor": "rev-0",
            "src_delta": {
                "added": [_max_per_call_entry("10")],
                "removed": [],
            },
            "dst_delta": {
                "added": [_max_per_call_entry("20")],
                "removed": [],
            },
            "conflicting_invariants": [
                {"class_name": "MaxPerCall",
                 "src_ops": ["added"], "dst_ops": ["added"]},
            ],
        }

    def _make_args(self, json_flag: bool = False) -> Any:
        from argparse import Namespace
        return Namespace(
            src="shadow",
            into="prod",
            reviewer="ops",
            socket="/tmp/whatever.sock",
            json=json_flag,
        )

    def test_cli_renders_conflict_in_natural_language(self, capsys) -> None:
        from daemon import cli

        args = self._make_args(json_flag=False)
        with mock.patch.object(cli, "_send_op", return_value=self._fake_conflict_response()):
            rc = cli._branch_merge(args)
        assert rc == 1
        err = capsys.readouterr().err
        # Must surface the NL rendering, not a raw dict dump.
        assert "MaxPerCall" in err
        assert "shadow" in err
        assert "prod" in err
        # The raw dict repr should NOT be the full payload. We allow the
        # dict key names to appear incidentally, but a line like
        # {'added': [...], 'removed': []} is a regression.
        assert "'added':" not in err

    def test_cli_json_flag_preserves_raw_dict(self, capsys) -> None:
        from daemon import cli

        args = self._make_args(json_flag=True)
        payload = self._fake_conflict_response()
        with mock.patch.object(cli, "_send_op", return_value=payload):
            rc = cli._branch_merge(args)
        assert rc == 1
        captured = capsys.readouterr()
        # --json emits the raw response on stdout as JSON; parsing it round
        # trips byte-for-byte.
        reparsed = json.loads(captured.out)
        assert reparsed == payload

    def test_cli_merged_verdict_unchanged(self, capsys) -> None:
        """The success path (verdict=merged) is not touched by the
        renderer; keep the v0.10.x behaviour intact."""
        from daemon import cli

        args = self._make_args(json_flag=False)
        merged_resp = {
            "verdict": "merged",
            "merge_kind": "fast-forward",
            "branch": {"name": "prod", "head_revision_id": "s1",
                       "created_at": 0, "created_by": ""},
        }
        with mock.patch.object(cli, "_send_op", return_value=merged_resp):
            rc = cli._branch_merge(args)
        assert rc == 0
        out = capsys.readouterr().out
        assert "Fast-forwarded" in out
