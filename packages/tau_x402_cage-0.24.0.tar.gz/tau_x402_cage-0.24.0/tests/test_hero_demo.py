"""Tests for the v0.17.0 hero demo (demos/hero_retry_loop.py).

The demo imports must be cheap; we exercise the simulate-and-check path
directly rather than spinning up a real daemon so CI stays fast.
"""
from __future__ import annotations

import json
import sys
from decimal import Decimal
from pathlib import Path
from typing import Any

import pytest

# The demos package isn't on sys.path by default; bolt the module path
# onto the import machinery so tests can `import demos.hero_retry_loop`.
ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

demo = pytest.importorskip("demos.hero_retry_loop")


# ── import / construction ────────────────────────────────────────────────────


class TestModule:
    def test_module_imports_cleanly(self) -> None:
        """The module must load without side-effects that would block CI."""
        assert hasattr(demo, "run_simulation")
        assert hasattr(demo, "write_transcript")

    def test_build_registry_is_non_empty(self) -> None:
        registry = demo.build_quickstart_registry()
        assert registry.invariants, "hero policy must have at least one rule"


# ── simulation correctness ───────────────────────────────────────────────────


class TestSimulation:
    def test_seven_at_fifty_produces_more_than_three_rejects(self) -> None:
        """The core narrative: 7 calls at $50 in 9s -> at least 4 rejects.

        If this ever drops below 4 the README + GIF are stale and the
        demo narrative ("first few permit, rest reject") breaks.
        """
        transcript = demo.run_simulation()
        assert transcript.summary.reject_count >= 4, (
            f"expected >=4 rejects under hero policy, got "
            f"{transcript.summary.reject_count}"
        )
        assert transcript.summary.permit_count >= 1, (
            "at least one call must permit to demonstrate the permit->reject "
            "transition"
        )

    def test_first_few_permit(self) -> None:
        """The narrative requires at least one permit BEFORE any reject."""
        transcript = demo.run_simulation()
        first_reject_idx = next(
            (i for i, c in enumerate(transcript.calls) if c.verdict == "reject"),
            None,
        )
        assert first_reject_idx is not None and first_reject_idx >= 1, (
            "demo must show at least one permit before the first reject"
        )

    def test_blocked_amount_matches_reject_count(self) -> None:
        transcript = demo.run_simulation()
        # 7 calls at $50 each, so every reject is worth exactly $50.
        expected = Decimal("50") * transcript.summary.reject_count
        assert Decimal(transcript.summary.amount_blocked_usd) == expected

    def test_attempted_total_matches_calls(self) -> None:
        transcript = demo.run_simulation()
        total = transcript.summary.total_calls
        attempted = Decimal(transcript.summary.amount_attempted_usd)
        assert attempted == Decimal("50") * total

    def test_first_reject_explanation_is_populated(self) -> None:
        transcript = demo.run_simulation()
        assert transcript.first_reject_explanation, (
            "explain_decision (or the fallback) must return a narrative"
        )


# ── transcript schema stability ──────────────────────────────────────────────


class TestTranscriptSchema:
    def test_transcript_serialises_to_json(self) -> None:
        transcript = demo.run_simulation()
        data = transcript.to_dict()
        text = json.dumps(data)
        reparsed = json.loads(text)
        assert reparsed == data

    def test_required_top_level_keys(self) -> None:
        transcript = demo.run_simulation()
        d = transcript.to_dict()
        for key in ("version", "scenario", "policy", "calls",
                    "first_reject_explanation", "summary", "notes"):
            assert key in d, f"transcript missing key {key!r}"

    def test_summary_schema(self) -> None:
        transcript = demo.run_simulation()
        s = transcript.summary.to_dict()
        for key in ("total_calls", "permit_count", "reject_count",
                    "amount_attempted_usd", "amount_blocked_usd",
                    "projected_spend_next_30s_usd"):
            assert key in s, f"summary missing key {key!r}"

    def test_call_schema(self) -> None:
        transcript = demo.run_simulation()
        assert transcript.calls, "at least one call must be in the transcript"
        for c in transcript.calls:
            d = c.to_dict()
            for key in ("call_index", "timestamp_unix", "amount_usd",
                        "verdict", "rule_id", "reason"):
                assert key in d, f"call entry missing key {key!r}"
            assert d["verdict"] in ("permit", "reject")


# ── transcript file writer ───────────────────────────────────────────────────


class TestTranscriptWriter:
    def test_write_creates_parent_dirs(self, tmp_path: Path) -> None:
        transcript = demo.run_simulation()
        out = tmp_path / "nested" / "dir" / "t.json"
        written = demo.write_transcript(transcript, path=out)
        assert written == out and out.exists()
        reparsed = json.loads(out.read_text())
        assert reparsed == transcript.to_dict()


# ── CLI entrypoint ───────────────────────────────────────────────────────────


class TestMainEntrypoint:
    def test_smoke_mode_returns_zero(self, tmp_path: Path) -> None:
        transcript_path = tmp_path / "hero.json"
        rc = demo.main(["--smoke", "--transcript", str(transcript_path)])
        assert rc == 0

    def test_json_mode_prints_parsable_output(
        self, tmp_path: Path, capsys: Any
    ) -> None:
        transcript_path = tmp_path / "hero.json"
        rc = demo.main([
            "--smoke", "--json", "--transcript", str(transcript_path),
        ])
        assert rc == 0
        captured = capsys.readouterr()
        # stdout must be valid JSON in --json mode.
        data = json.loads(captured.out)
        assert data["scenario"] == "hero_retry_loop"
