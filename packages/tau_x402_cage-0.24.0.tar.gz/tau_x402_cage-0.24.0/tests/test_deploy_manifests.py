"""Deployment-manifest integrity tests.

These tests gate on `docker` and `helm` being available on PATH. When the
tool is missing they skip cleanly so the suite stays green on minimal CI
runners.

What they check:
  * `docker compose config` parses `deploy/compose/docker-compose.yaml`
  * `helm lint` accepts the chart at `deploy/helm/tau-x402-cage`
  * `.env.example` covers every env var referenced in the runtime code
    (`daemon/server.py`, `saas/app.py`, `saas/web_ui/routes.py`) — the
    regression guard that stops a new env var from landing without a
    deployment-config entry.
"""
from __future__ import annotations

import ast
import re
import shutil
import subprocess
from pathlib import Path

import pytest


REPO_ROOT = Path(__file__).resolve().parent.parent
DEPLOY = REPO_ROOT / "deploy"
COMPOSE_FILE = DEPLOY / "compose" / "docker-compose.yaml"
ENV_EXAMPLE = DEPLOY / "compose" / ".env.example"
HELM_CHART = DEPLOY / "helm" / "tau-x402-cage"

# Source files whose env var references must be covered by .env.example.
ENV_SOURCES = [
    REPO_ROOT / "daemon" / "server.py",
    REPO_ROOT / "saas" / "app.py",
    REPO_ROOT / "saas" / "web_ui" / "routes.py",
]

# Env vars that are intentionally off-limits for `.env.example` coverage.
# We audit additional env vars used elsewhere (daemon/cli.py, billing.py,
# adapter/*) by grepping all source files below.
ENV_SOURCES_FULL = [
    REPO_ROOT / "daemon" / "server.py",
    REPO_ROOT / "daemon" / "cli.py",
    REPO_ROOT / "saas" / "app.py",
    REPO_ROOT / "saas" / "billing.py",
    REPO_ROOT / "saas" / "web_ui" / "routes.py",
    REPO_ROOT / "adapter" / "prover.py",
    REPO_ROOT / "adapter" / "verdict_signer.py",
]

# Env vars that belong to the harness (tests / dev-loop) and should not be
# promoted into `.env.example`.
EXCLUDE_ENV_VARS: frozenset[str] = frozenset(
    {
        # generic shell / test-runner knobs
        "PATH",
        "HOME",
        "PYTHONPATH",
        # macOS cvc5 lookup used by tests only
        "DYLD_LIBRARY_PATH",
    }
)

# Pattern catches `os.environ.get("FOO", ...)`, `os.environ["FOO"]`,
# `os.getenv("FOO", ...)`, and `env.get("FOO", ...)`.
ENV_VAR_RE = re.compile(
    r"""(?:
            os\.environ(?:\.get)?\[?
          | os\.getenv\(
          | \benv(?:iron)?\.get\(
        )
        \s*["']
        ([A-Z][A-Z0-9_]*)
        ["']
    """,
    re.VERBOSE,
)


def _which(tool: str) -> str | None:
    """Return the path to `tool` on PATH, or None."""
    return shutil.which(tool)


def _docker_compose_available() -> bool:
    """True iff `docker compose version` succeeds.

    Docker Engine without the compose plugin exits non-zero on
    `docker compose`. We skip those environments instead of failing.
    """
    docker = _which("docker")
    if docker is None:
        return False
    try:
        result = subprocess.run(
            [docker, "compose", "version"],
            capture_output=True,
            timeout=10,
            check=False,
        )
    except (subprocess.TimeoutExpired, OSError):
        return False
    return result.returncode == 0


# ── docker compose ──────────────────────────────────────────────────────────


class TestComposeManifest:
    """`docker compose config` must parse the compose file without error."""

    @pytest.mark.skipif(
        not _docker_compose_available(),
        reason="docker compose plugin not available on PATH",
    )
    def test_docker_compose_config_parses(self, tmp_path: Path) -> None:
        """`docker compose config` must exit zero. We stub the required
        secrets so the compose parser does not refuse because of missing
        env-var substitutions."""
        env_stub = tmp_path / ".env"
        env_stub.write_text(
            "\n".join(
                [
                    "TAU_X402_SOCKET=/run/tau-x402-cage.sock",
                    'TAU_X402_API_KEYS={"dev":"sk_dev"}',
                    "TAU_X402_HMAC_SECRET=" + ("a" * 64),
                    "TAU_CAGE_WEB_UI_ENABLED=0",
                    "TAU_CAGE_WEB_UI_TOKEN=" + ("b" * 48),
                    "TAU_CAGE_SIGNING_ALGORITHM=hmac-sha256",
                    "TAU_CAGE_ED25519_PRIVATE_KEY=",
                    "TAU_CAGE_ED25519_PUBLIC_KEY=",
                    "CAGE_PROVER=pattern",
                    "CAGE_PROVER_MODE=compat",
                    "CAGE_TAU_TIMEOUT_MS=10000",
                    "CAGE_SEMANTIC_FRAGMENT=v1",
                    "TAU_BINARY=",
                    "TAU_DYLD_PATH=",
                    "STRIPE_API_KEY=",
                    "STRIPE_METER_EVENT_NAME=tau_x402_check",
                    "",
                ]
            )
        )
        result = subprocess.run(
            [
                _which("docker"),
                "compose",
                "--env-file",
                str(env_stub),
                "-f",
                str(COMPOSE_FILE),
                "config",
            ],
            capture_output=True,
            text=True,
            timeout=30,
            check=False,
        )
        assert result.returncode == 0, (
            "docker compose config failed.\n"
            f"stderr: {result.stderr}\nstdout: {result.stdout}"
        )

    def test_compose_file_is_yaml(self) -> None:
        """`docker compose` is optional; we also check the raw YAML parses
        so even minimal CI runners catch a broken compose file."""
        yaml = pytest.importorskip("yaml")
        with COMPOSE_FILE.open() as fh:
            doc = yaml.safe_load(fh)
        services = doc.get("services", {})
        assert set(services) == {"cage-daemon", "cage-saas", "cage-redis"}


# ── helm chart ──────────────────────────────────────────────────────────────


class TestHelmChart:
    """`helm lint` must accept the chart."""

    @pytest.mark.skipif(
        _which("helm") is None, reason="helm not installed on PATH"
    )
    def test_helm_lint(self) -> None:
        result = subprocess.run(
            [_which("helm"), "lint", str(HELM_CHART)],
            capture_output=True,
            text=True,
            timeout=30,
            check=False,
        )
        assert result.returncode == 0, (
            "helm lint failed.\n"
            f"stderr: {result.stderr}\nstdout: {result.stdout}"
        )

    @pytest.mark.skipif(
        _which("helm") is None, reason="helm not installed on PATH"
    )
    def test_helm_template_renders(self) -> None:
        """`helm template` with the existingSecret path must render a
        non-empty manifest."""
        result = subprocess.run(
            [
                _which("helm"),
                "template",
                "cage",
                str(HELM_CHART),
                "--set",
                "secrets.existingSecret=test-secret",
            ],
            capture_output=True,
            text=True,
            timeout=30,
            check=False,
        )
        assert result.returncode == 0, (
            f"helm template failed: {result.stderr}"
        )
        # A Deployment and a Service at minimum.
        assert "kind: Deployment" in result.stdout
        assert "kind: Service" in result.stdout
        assert "kind: ConfigMap" in result.stdout

    def test_chart_yaml_structure(self) -> None:
        """Chart.yaml always parses, with or without helm installed."""
        yaml = pytest.importorskip("yaml")
        chart = yaml.safe_load((HELM_CHART / "Chart.yaml").read_text())
        assert chart["name"] == "tau-x402-cage"
        assert chart["apiVersion"] == "v2"
        # We bump `version` in lockstep with the pyproject version.
        assert chart["version"] == "0.8.0"


# ── env-var coverage ────────────────────────────────────────────────────────


def _extract_env_vars(source_path: Path) -> set[str]:
    """Return every env var name referenced by the file, case-insensitively
    matching common patterns. Falls back to AST-assisted regex."""
    text = source_path.read_text()
    vars_found = set(ENV_VAR_RE.findall(text))
    # Also catch `os.environ["FOO"]` bracket-access via a direct regex so
    # the caller does not depend on a single-pass engine.
    for match in re.finditer(
        r'os\.environ\[\s*["\']([A-Z][A-Z0-9_]*)["\']\s*\]', text
    ):
        vars_found.add(match.group(1))
    return vars_found


def _parse_env_example(env_path: Path) -> set[str]:
    """Return the KEY set of an .env file, ignoring comments and blanks."""
    keys: set[str] = set()
    for raw_line in env_path.read_text().splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            continue
        key = line.split("=", 1)[0].strip()
        if re.match(r"^[A-Z][A-Z0-9_]*$", key):
            keys.add(key)
    return keys


class TestEnvExampleCoverage:
    """Every env var used across the runtime surface must be documented in
    `deploy/compose/.env.example`."""

    def test_env_example_covers_core_surface(self) -> None:
        """Primary surface: the three files called out in the v0.8.0 spec."""
        referenced: set[str] = set()
        for src in ENV_SOURCES:
            referenced |= _extract_env_vars(src)
        referenced -= EXCLUDE_ENV_VARS

        documented = _parse_env_example(ENV_EXAMPLE)
        missing = referenced - documented
        assert not missing, (
            "env vars referenced in runtime code but not documented in "
            f"{ENV_EXAMPLE.relative_to(REPO_ROOT)}: {sorted(missing)}"
        )

    def test_env_example_covers_full_surface(self) -> None:
        """Extended surface: the full set of daemon/saas/adapter env vars
        documented in deployment `.env.example`. Guards against a new env
        var landing in cli.py or billing.py without a deploy-config entry."""
        referenced: set[str] = set()
        for src in ENV_SOURCES_FULL:
            referenced |= _extract_env_vars(src)
        referenced -= EXCLUDE_ENV_VARS

        documented = _parse_env_example(ENV_EXAMPLE)
        missing = referenced - documented
        assert not missing, (
            "env vars referenced across daemon/saas/adapter but missing "
            f"from {ENV_EXAMPLE.relative_to(REPO_ROOT)}: {sorted(missing)}"
        )

    def test_env_example_keys_are_unique(self) -> None:
        """Duplicate KEY entries silently shadow each other. Reject them."""
        seen: list[str] = []
        for raw_line in ENV_EXAMPLE.read_text().splitlines():
            line = raw_line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            seen.append(line.split("=", 1)[0].strip())
        duplicates = {k for k in seen if seen.count(k) > 1}
        assert not duplicates, f"duplicate env keys in .env.example: {sorted(duplicates)}"
