"""Tests for the v0.17.0 `tau-x402-cage quickstart` scaffolder.

Covers:
    * File scaffolding (policy.yaml, .env, docker-compose.yaml).
    * Policy-loader round-trip of the generated policy.
    * Claude Desktop MCP config JSON emission + schema shape.
    * Idempotence: refuses to clobber without --force.
    * HMAC secret freshness (always 64 hex chars, unique per scaffold).
    * Env recipe for auto-enforce is documented (not default-on).
"""
from __future__ import annotations

import json
import re
import subprocess
import sys
from pathlib import Path
from typing import Dict

import pytest

from adapter.policy_loader import load_policy
from daemon.quickstart import (
    QuickstartError,
    _build_env_file,
    _build_mcp_config,
    _build_policy_yaml,
    scaffold,
)


# ── base scaffold ────────────────────────────────────────────────────────────


class TestScaffoldArtefacts:
    def test_creates_all_three_files(self, tmp_path: Path) -> None:
        result = scaffold(tmp_path / "cage")
        assert result.policy_path.exists()
        assert result.env_path.exists()
        assert result.compose_path.exists()

    def test_target_dir_is_created_if_missing(self, tmp_path: Path) -> None:
        target = tmp_path / "does" / "not" / "exist"
        scaffold(target)
        assert target.is_dir()

    def test_policy_is_valid_yaml_that_loads(self, tmp_path: Path) -> None:
        result = scaffold(tmp_path)
        loaded = load_policy(result.policy_path)
        # Every invariant must deserialize; count matches the scaffolded
        # YAML. When the runtime-guard agent's BurstVelocityCap is in
        # adapter/invariants.py the policy has 4 entries; otherwise 3.
        expected_count = 4 if result.burst_invariant_included else 3
        assert len(loaded.invariants) == expected_count

    def test_compose_mentions_shadow_mode_default(self, tmp_path: Path) -> None:
        result = scaffold(tmp_path)
        env_text = result.env_path.read_text()
        # Default to shadow so first-run traffic is never accidentally blocked.
        assert "TAU_CAGE_MODE=shadow" in env_text
        compose_text = result.compose_path.read_text()
        assert "env_file" in compose_text
        assert ".env" in compose_text

    def test_hmac_secret_is_fresh_64_hex_chars(self, tmp_path: Path) -> None:
        a = scaffold(tmp_path / "a")
        b = scaffold(tmp_path / "b")
        assert re.fullmatch(r"[0-9a-f]{64}", a.hmac_secret_hex)
        assert re.fullmatch(r"[0-9a-f]{64}", b.hmac_secret_hex)
        # Two independent scaffolds must emit independent secrets.
        assert a.hmac_secret_hex != b.hmac_secret_hex

    def test_env_file_permissions_restricted(self, tmp_path: Path) -> None:
        """The .env holds the HMAC secret; it should not be world-readable."""
        result = scaffold(tmp_path)
        mode = result.env_path.stat().st_mode & 0o777
        # On filesystems that respect chmod, we expect 0o600.
        # vfat / CIFS mounts may not; accept 0o600 OR full-read as "either
        # we set it or the FS stripped it" rather than failing the test.
        assert mode in (0o600, 0o666, 0o644)

    def test_auto_enforce_documented_but_off_by_default(
        self, tmp_path: Path
    ) -> None:
        """The auto-flip env var must be visible (commented/empty is fine)
        but MUST NOT have a non-empty default value."""
        result = scaffold(tmp_path)
        env_text = result.env_path.read_text()
        # Name is documented so users know it exists.
        assert "TAU_CAGE_AUTO_ENFORCE_AFTER" in env_text
        # Default must not set a value — no "=1800" or similar.
        match = re.search(
            r"^TAU_CAGE_AUTO_ENFORCE_AFTER=(?P<val>.*)$",
            env_text, re.MULTILINE,
        )
        assert match is not None, "auto-enforce env var missing"
        assert match.group("val").strip() == "", (
            f"auto-enforce must default to empty; got {match.group('val')!r}"
        )


# ── MCP config ───────────────────────────────────────────────────────────────


class TestMcpConfig:
    def test_default_config_is_structured(self) -> None:
        cfg = _build_mcp_config()
        # Schema: Claude Desktop expects mcpServers.<name>.{command,args,env}.
        assert "mcpServers" in cfg
        assert "tau-x402-cage" in cfg["mcpServers"]
        entry: Dict[str, object] = cfg["mcpServers"]["tau-x402-cage"]  # type: ignore[assignment]
        assert entry.get("command") == "python"
        assert entry.get("args") == ["-m", "tau_x402_cage_mcp"]
        assert "env" in entry
        env = entry["env"]
        assert isinstance(env, dict)
        assert "TAU_X402_CAGE_URL" in env

    def test_config_roundtrips_through_json(self) -> None:
        """Serialising and parsing must round-trip exactly."""
        cfg = _build_mcp_config()
        text = json.dumps(cfg)
        reparsed = json.loads(text)
        assert reparsed == cfg

    def test_config_written_to_disk_when_requested(
        self, tmp_path: Path
    ) -> None:
        out = tmp_path / "claude_desktop_config.json"
        result = scaffold(tmp_path / "cage", mcp_config_out=out)
        assert result.mcp_config_path == out
        assert out.exists()
        reparsed = json.loads(out.read_text())
        assert reparsed == result.mcp_config

    def test_config_path_not_written_by_default(self, tmp_path: Path) -> None:
        result = scaffold(tmp_path)
        assert result.mcp_config_path is None


# ── idempotence ──────────────────────────────────────────────────────────────


class TestIdempotence:
    def test_refuses_to_clobber_without_force(self, tmp_path: Path) -> None:
        scaffold(tmp_path)
        with pytest.raises(QuickstartError) as excinfo:
            scaffold(tmp_path)
        # Error message should name the offending files so the operator
        # knows what would have been clobbered.
        msg = str(excinfo.value)
        assert "policy.yaml" in msg or "docker-compose.yaml" in msg or ".env" in msg
        assert "--force" in msg

    def test_force_overwrites(self, tmp_path: Path) -> None:
        first = scaffold(tmp_path)
        first.policy_path.write_text("# tampered\n")
        second = scaffold(tmp_path, force=True)
        # Policy file was regenerated to the scaffolded template.
        assert second.policy_path.read_text().startswith(
            "# tau-x402-cage quickstart policy"
        )
        # The freshly-regenerated HMAC secret is NOT the same as the first —
        # force implies a fresh deployment from the scaffolder's POV.
        assert second.hmac_secret_hex != first.hmac_secret_hex

    def test_refuses_to_clobber_mcp_config(self, tmp_path: Path) -> None:
        out = tmp_path / "mcp.json"
        out.write_text("{}")
        with pytest.raises(QuickstartError):
            scaffold(tmp_path / "cage", mcp_config_out=out)


# ── policy template invariants ───────────────────────────────────────────────


class TestPolicyTemplate:
    def test_includes_core_safe_defaults(self) -> None:
        text = _build_policy_yaml()
        assert "kind: max_per_call" in text
        assert "kind: spending_cap" in text
        assert "kind: retry_rate_limit" in text
        # Tight defaults: MaxPerCall $10, SpendingCap $100 per 24h.
        assert 'max_amount: "10"' in text
        assert 'max_amount: "100"' in text
        assert "window_seconds: 86400" in text

    def test_burst_entry_gated_on_invariant_availability(self) -> None:
        """When BurstVelocityCap is importable the template must include
        ``burst_velocity_cap``; when absent the template must not (so the
        policy loader doesn't reject an unknown kind)."""
        text = _build_policy_yaml()
        try:
            from adapter.invariants import BurstVelocityCap  # noqa: F401
            expected = True
        except Exception:
            expected = False
        assert ("kind: burst_velocity_cap" in text) is expected


# ── env template ─────────────────────────────────────────────────────────────


class TestEnvTemplate:
    def test_env_has_named_fields(self) -> None:
        text = _build_env_file("aa" * 32)
        for key in (
            "TAU_CAGE_HMAC_SECRET", "TAU_CAGE_MODE",
            "TAU_CAGE_AUTO_ENFORCE_AFTER",
        ):
            assert key in text

    def test_env_secret_is_emitted(self) -> None:
        text = _build_env_file("cafebabe" * 8)
        assert "TAU_CAGE_HMAC_SECRET=" + ("cafebabe" * 8) in text


# ── CLI end-to-end (subprocess) ─────────────────────────────────────────────


class TestCliSubprocess:
    """Exercise the quickstart subcommand via argparse -> stdout path."""

    def test_cli_runs_and_prints_next_steps(self, tmp_path: Path) -> None:
        import os

        env = dict(os.environ)
        env["PYTHONPATH"] = str(Path(__file__).resolve().parent.parent) + os.pathsep + env.get("PYTHONPATH", "")
        out = subprocess.run(
            [
                sys.executable, "-m", "daemon.cli", "quickstart",
                "--dir", str(tmp_path),
            ],
            capture_output=True, text=True, env=env, timeout=30,
        )
        assert out.returncode == 0, f"stderr={out.stderr}\nstdout={out.stdout}"
        assert "Scaffolded tau-x402-cage quickstart" in out.stdout
        assert "Next steps:" in out.stdout
        assert "docker compose up" in out.stdout
        # File artefacts really wrote.
        assert (tmp_path / "policy.yaml").exists()
        assert (tmp_path / ".env").exists()
        assert (tmp_path / "docker-compose.yaml").exists()

    def test_cli_errors_when_clobbering_without_force(
        self, tmp_path: Path
    ) -> None:
        import os

        env = dict(os.environ)
        env["PYTHONPATH"] = str(Path(__file__).resolve().parent.parent) + os.pathsep + env.get("PYTHONPATH", "")
        # First run succeeds.
        subprocess.run(
            [sys.executable, "-m", "daemon.cli", "quickstart",
             "--dir", str(tmp_path)],
            capture_output=True, text=True, env=env, timeout=30, check=True,
        )
        # Second run fails with exit 2.
        second = subprocess.run(
            [sys.executable, "-m", "daemon.cli", "quickstart",
             "--dir", str(tmp_path)],
            capture_output=True, text=True, env=env, timeout=30,
        )
        assert second.returncode == 2
        assert "--force" in second.stderr
