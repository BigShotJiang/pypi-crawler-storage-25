"""Tests for the policy narrator (v0.18.0).

Covers the pure narrator module, the CLI ``narrate`` subcommand, the
round-trip flags on ``suggest``, and the MCP tool dispatch.
"""
from __future__ import annotations

import io
import json
import os
import subprocess
import sys
from decimal import Decimal
from pathlib import Path

import pytest

from adapter.invariants import (
    BurstVelocityCap,
    CounterpartyConstraint,
    JurisdictionRule,
    MaxPerCall,
    MutualExclusion,
    ProviderAllowlist,
    RetryRateLimit,
    RollingWindowCap,
    SpendingCap,
)
from adapter.policy_loader import load_policy
from adapter.policy_narrator import (
    EMPTY_SENTENCE,
    _NARRATORS,
    _order_key,
    narrate_policy,
    narrate_policy_json,
    narrate_policy_markdown,
)
from adapter.self_ref_policy import InstabilityGuard


def _run_cli(args: list[str], cwd: Path | None = None) -> subprocess.CompletedProcess:
    """Subprocess helper that invokes the CLI with PYTHONPATH wired."""
    env = os.environ.copy()
    repo_root = str(Path(__file__).resolve().parent.parent)
    env["PYTHONPATH"] = os.pathsep.join(
        [repo_root, env.get("PYTHONPATH", "")]
    ).rstrip(os.pathsep)
    return subprocess.run(
        [sys.executable, "-m", "daemon.cli", *args],
        cwd=cwd, capture_output=True, text=True, timeout=20, env=env,
    )


def _run_cli_stdin(
    args: list[str],
    stdin: str,
    cwd: Path | None = None,
) -> subprocess.CompletedProcess:
    """Invoke the CLI with piped stdin."""
    env = os.environ.copy()
    repo_root = str(Path(__file__).resolve().parent.parent)
    env["PYTHONPATH"] = os.pathsep.join(
        [repo_root, env.get("PYTHONPATH", "")]
    ).rstrip(os.pathsep)
    return subprocess.run(
        [sys.executable, "-m", "daemon.cli", *args],
        cwd=cwd, input=stdin, capture_output=True, text=True, timeout=20, env=env,
    )


# ── per-class narrators ──────────────────────────────────────────────────────


class TestPerClassNarrators:
    """Every invariant class must have a registered narrator and a
    non-empty sentence that mentions the class name."""

    def test_every_invariant_class_has_narrator(self) -> None:
        expected = {
            MaxPerCall, SpendingCap, ProviderAllowlist, RetryRateLimit,
            BurstVelocityCap, RollingWindowCap, JurisdictionRule,
            MutualExclusion, CounterpartyConstraint, InstabilityGuard,
        }
        missing = expected - set(_NARRATORS.keys())
        assert not missing, f"missing narrator(s): {missing}"

    def test_max_per_call_sentence(self) -> None:
        inv = MaxPerCall(max_amount=Decimal("50"), currency="USDC")
        sentence = narrate_policy([inv])
        assert "50 USDC" in sentence
        assert "MaxPerCall" in sentence

    def test_spending_cap_per_tx(self) -> None:
        inv = SpendingCap(max_amount=Decimal("25"), scope="per_tx")
        sentence = narrate_policy([inv])
        assert "25 USDC" in sentence
        assert "SpendingCap" in sentence
        assert "per_tx" in sentence

    def test_spending_cap_per_window(self) -> None:
        inv = SpendingCap(
            max_amount=Decimal("500"),
            scope="per_window",
            window_seconds=3600,
        )
        sentence = narrate_policy([inv])
        assert "500 USDC" in sentence
        assert "3600" in sentence
        assert "SpendingCap" in sentence

    def test_spending_cap_per_provider_per_window(self) -> None:
        inv = SpendingCap(
            max_amount=Decimal("300"),
            scope="per_provider_per_window",
            window_seconds=60,
            provider="anthropic",
        )
        sentence = narrate_policy([inv])
        assert "anthropic" in sentence
        assert "300" in sentence
        assert "60-second" in sentence

    def test_spending_cap_cross_provider_cap(self) -> None:
        inv = SpendingCap(
            max_amount=Decimal("500"),
            scope="per_window",
            window_seconds=60,
            cross_provider_cap=Decimal("300"),
        )
        sentence = narrate_policy([inv])
        assert "500" in sentence
        assert "300" in sentence
        assert "Cross-provider" in sentence

    def test_provider_allowlist(self) -> None:
        inv = ProviderAllowlist(providers=frozenset(["openai", "anthropic"]))
        sentence = narrate_policy([inv])
        # Sorted order
        assert "[anthropic, openai]" in sentence
        assert "ProviderAllowlist" in sentence

    def test_retry_rate_limit(self) -> None:
        inv = RetryRateLimit(min_gap_seconds=30)
        sentence = narrate_policy([inv])
        assert "30" in sentence
        assert "provider+counterparty" in sentence
        assert "RetryRateLimit" in sentence

    def test_burst_velocity_cap_cross_provider(self) -> None:
        inv = BurstVelocityCap(
            max_per_window=Decimal("300"),
            window_seconds=60,
            cross_provider=True,
        )
        sentence = narrate_policy([inv])
        assert "300" in sentence
        assert "60-second" in sentence
        assert "summed across providers" in sentence
        assert "BurstVelocityCap" in sentence

    def test_burst_velocity_cap_per_provider(self) -> None:
        inv = BurstVelocityCap(
            max_per_window=Decimal("100"),
            window_seconds=10,
            cross_provider=False,
        )
        sentence = narrate_policy([inv])
        assert "per provider" in sentence

    def test_rolling_window_cap(self) -> None:
        inv = RollingWindowCap(max_count=100, window_seconds=3600, group_by="provider")
        sentence = narrate_policy([inv])
        assert "100" in sentence
        assert "3600" in sentence
        assert "RollingWindowCap" in sentence

    def test_jurisdiction_rule_empty(self) -> None:
        inv = JurisdictionRule(jurisdiction="EU", additional_invariants=())
        sentence = narrate_policy([inv])
        assert "EU" in sentence
        assert "JurisdictionRule" in sentence

    def test_jurisdiction_rule_with_inner(self) -> None:
        inner = MaxPerCall(max_amount=Decimal("10"), currency="USDC")
        inv = JurisdictionRule(
            jurisdiction="UK", additional_invariants=(inner,),
        )
        sentence = narrate_policy([inv])
        assert "UK" in sentence
        assert "MaxPerCall" in sentence
        assert "10 USDC" in sentence

    def test_mutual_exclusion(self) -> None:
        inv = MutualExclusion(
            group_a=frozenset(["a", "b"]),
            group_b=frozenset(["c", "d"]),
        )
        sentence = narrate_policy([inv])
        assert "[a, b]" in sentence
        assert "[c, d]" in sentence
        assert "MutualExclusion" in sentence

    def test_counterparty_constraint_with_approved(self) -> None:
        inv = CounterpartyConstraint(
            approved_ids=frozenset(["vendor_a"]),
            sanctioned_ids=frozenset(),
        )
        sentence = narrate_policy([inv])
        assert "vendor_a" in sentence
        assert "approved" in sentence
        assert "CounterpartyConstraint" in sentence

    def test_counterparty_constraint_with_sanctioned(self) -> None:
        inv = CounterpartyConstraint(
            approved_ids=frozenset(),
            sanctioned_ids=frozenset(["ofac_01"]),
        )
        sentence = narrate_policy([inv])
        assert "ofac_01" in sentence
        assert "sanctioned" in sentence

    def test_counterparty_constraint_vacuous(self) -> None:
        inv = CounterpartyConstraint(
            approved_ids=frozenset(),
            sanctioned_ids=frozenset(),
        )
        sentence = narrate_policy([inv])
        assert "vacuous" in sentence.lower() or "no approved" in sentence

    def test_instability_guard(self) -> None:
        inv = InstabilityGuard(
            provider="anthropic",
            reject_threshold=3,
            window_seconds=60,
            tighten_to=Decimal("5"),
            recovery_seconds=300,
        )
        sentence = narrate_policy([inv])
        assert "anthropic" in sentence
        assert "3 rejects" in sentence
        assert "60-second" in sentence
        assert "5 USDC" in sentence
        assert "InstabilityGuard" in sentence


# ── empty & single-rule policies ─────────────────────────────────────────────


class TestEmptyAndSingle:
    def test_empty_policy(self) -> None:
        assert narrate_policy([]) == EMPTY_SENTENCE

    def test_empty_markdown(self) -> None:
        assert narrate_policy_markdown([]) == EMPTY_SENTENCE

    def test_empty_json(self) -> None:
        parsed = json.loads(narrate_policy_json([]))
        assert parsed["sentences"] == []
        assert parsed["summary"] == EMPTY_SENTENCE

    def test_single_rule_one_sentence(self) -> None:
        inv = MaxPerCall(max_amount=Decimal("50"))
        result = narrate_policy([inv])
        # exactly one line (no newlines)
        assert "\n" not in result
        assert result.endswith(".")


# ── multi-rule ordering ──────────────────────────────────────────────────────


class TestMultiRuleOrdering:
    def test_multi_rule_separated_by_newlines(self) -> None:
        invs = [
            MaxPerCall(max_amount=Decimal("50")),
            ProviderAllowlist(providers=frozenset(["openai"])),
        ]
        result = narrate_policy(invs)
        assert result.count("\n") == 1

    def test_stable_ordering_v1_first_then_v2(self) -> None:
        # Deliberately pass v2 before v1; output must reorder.
        invs = [
            RetryRateLimit(min_gap_seconds=30),  # v2
            MaxPerCall(max_amount=Decimal("50")),  # v1
        ]
        result = narrate_policy(invs)
        lines = result.split("\n")
        assert "MaxPerCall" in lines[0]
        assert "RetryRateLimit" in lines[1]

    def test_alphabetical_within_tier(self) -> None:
        # Two v1 invariants — narrator must alphabetize by class name.
        invs = [
            ProviderAllowlist(providers=frozenset(["x"])),  # starts P
            MaxPerCall(max_amount=Decimal("1")),            # starts M
        ]
        result = narrate_policy(invs)
        lines = result.split("\n")
        assert "MaxPerCall" in lines[0]
        assert "ProviderAllowlist" in lines[1]

    def test_spending_cap_per_tx_tiered_as_v1(self) -> None:
        # per_tx belongs to v1 (see tau_compiler); per_window is v2.
        per_tx = SpendingCap(max_amount=Decimal("25"), scope="per_tx")
        per_window = SpendingCap(
            max_amount=Decimal("500"),
            scope="per_window",
            window_seconds=86400,
        )
        tier_tx = _order_key(per_tx)[0]
        tier_window = _order_key(per_window)[0]
        assert tier_tx == 0
        assert tier_window == 1


# ── round-trip from the shipped starter policy ────────────────────────────────


class TestStarterRoundTrip:
    """Load the starter policy via the loader, narrate it, check every
    kind appears in the output."""

    def test_round_trip_starter(self, tmp_path: Path) -> None:
        # Use the CLI to scaffold a starter so we exercise the loader
        # and narrator against the exact bytes that ship.
        result = _run_cli(["init"], cwd=tmp_path)
        assert result.returncode == 0, result.stderr
        policy_path = tmp_path / "policy.yaml"
        loaded = load_policy(policy_path)
        text = narrate_policy(loaded.invariants)
        assert text != EMPTY_SENTENCE
        # Every invariant kind named in the starter must show up.
        assert "MaxPerCall" in text
        assert "SpendingCap" in text
        assert "ProviderAllowlist" in text
        assert "RetryRateLimit" in text
        assert "RollingWindowCap" in text
        # CounterpartyConstraint appears but with vacuous signal
        assert "CounterpartyConstraint" in text


# ── CLI: narrate subcommand ──────────────────────────────────────────────────


class TestNarrateSubcommand:
    def test_narrate_plain(self, tmp_path: Path) -> None:
        policy = tmp_path / "policy.yaml"
        policy.write_text(
            "version: 1\n"
            "policy:\n"
            "  - kind: max_per_call\n"
            "    max_amount: \"50\"\n"
        )
        result = _run_cli(["narrate", str(policy)])
        assert result.returncode == 0, result.stderr
        assert "MaxPerCall" in result.stdout
        assert "50 USDC" in result.stdout

    def test_narrate_markdown_bullets(self, tmp_path: Path) -> None:
        policy = tmp_path / "policy.yaml"
        policy.write_text(
            "version: 1\n"
            "policy:\n"
            "  - kind: max_per_call\n"
            "    max_amount: \"50\"\n"
        )
        result = _run_cli(["narrate", str(policy), "--format", "markdown"])
        assert result.returncode == 0
        assert result.stdout.lstrip().startswith("-")

    def test_narrate_json(self, tmp_path: Path) -> None:
        policy = tmp_path / "policy.yaml"
        policy.write_text(
            "version: 1\n"
            "policy:\n"
            "  - kind: max_per_call\n"
            "    max_amount: \"50\"\n"
        )
        result = _run_cli(["narrate", str(policy), "--format", "json"])
        assert result.returncode == 0
        parsed = json.loads(result.stdout)
        assert "sentences" in parsed
        assert len(parsed["sentences"]) == 1
        assert parsed["sentences"][0]["class"] == "MaxPerCall"
        assert parsed["sentences"][0]["tier"] == "v1"

    def test_narrate_missing_file_exits_2(self, tmp_path: Path) -> None:
        result = _run_cli(["narrate", str(tmp_path / "nope.yaml")])
        assert result.returncode == 2
        assert "narrate" in result.stderr


# ── CLI: suggest --from-nl ──────────────────────────────────────────────────


class TestSuggestFromNl:
    def test_from_nl_flag_embeds_description(self) -> None:
        result = _run_cli([
            "suggest", "--from-nl", "max $50 per day to anthropic",
        ])
        assert result.returncode == 0, result.stderr
        assert "BEGIN PROMPT" in result.stdout
        assert "max $50 per day to anthropic" in result.stdout


# ── CLI: suggest --round-trip ───────────────────────────────────────────────


class TestSuggestRoundTrip:
    def test_round_trip_valid_yaml_narrates(self) -> None:
        yaml_in = (
            "version: 1\n"
            "policy:\n"
            "  - kind: max_per_call\n"
            "    max_amount: \"50\"\n"
        )
        result = _run_cli_stdin(["suggest", "--round-trip"], stdin=yaml_in)
        assert result.returncode == 0, result.stderr
        assert "MaxPerCall" in result.stdout

    def test_round_trip_invalid_yaml_exits_1(self) -> None:
        bad = "not: valid: :policy:\n"
        result = _run_cli_stdin(["suggest", "--round-trip"], stdin=bad)
        assert result.returncode == 1

    def test_round_trip_unknown_kind_exits_1(self) -> None:
        yaml_in = (
            "version: 1\n"
            "policy:\n"
            "  - kind: does_not_exist\n"
            "    foo: bar\n"
        )
        result = _run_cli_stdin(["suggest", "--round-trip"], stdin=yaml_in)
        assert result.returncode == 1


# ── MCP tool wiring (light probe; full wire tests live under mcp/tests/) ─────


class TestMcpToolDispatch:
    """Adapter-side sanity: narrate_policy_json emits the same shape
    the MCP tool returns to callers (class, tier, sentence). Full
    httpx + dispatch coverage lives in mcp/tests/test_narrate_policy_tool.py.
    """

    def test_narrate_policy_json_shape(self) -> None:
        out = narrate_policy_json([
            MaxPerCall(max_amount=Decimal("50")),
        ])
        parsed = json.loads(out)
        assert parsed["sentences"][0]["class"] == "MaxPerCall"
        assert parsed["sentences"][0]["tier"] == "v1"
        assert "sentence" in parsed["sentences"][0]
        assert "summary" in parsed


# ── daemon-side narrate_policy op ────────────────────────────────────────────


class TestDaemonNarratePolicyOp:
    """The daemon exposes `narrate_policy` as a wire op so the MCP tool
    and any other runtime can route through one endpoint."""

    def test_op_happy_path(self) -> None:
        from daemon.server import CageDaemon
        from adapter.x402_registry import X402Registry

        daemon = CageDaemon.__new__(CageDaemon)  # bypass full wiring
        # _op_narrate_policy needs nothing from instance state —
        # confirm by calling it unbound through the descriptor.
        payload = {"policy_yaml": (
            "version: 1\n"
            "policy:\n"
            "  - kind: max_per_call\n"
            "    max_amount: \"50\"\n"
        )}
        resp = CageDaemon._op_narrate_policy(daemon, payload)
        assert resp["verdict"] == "ok"
        assert resp["error"] is None
        assert len(resp["sentences"]) == 1
        assert resp["sentences"][0]["class"] == "MaxPerCall"
        assert "50 USDC" in resp["summary"]
        assert resp["markdown"].lstrip().startswith("-")

    def test_op_empty_yaml_errors(self) -> None:
        from daemon.server import CageDaemon

        daemon = CageDaemon.__new__(CageDaemon)
        resp = CageDaemon._op_narrate_policy(daemon, {"policy_yaml": ""})
        assert resp["verdict"] == "error"
        assert resp["sentences"] == []
        assert resp["error"]

    def test_op_unknown_kind_errors(self) -> None:
        from daemon.server import CageDaemon

        daemon = CageDaemon.__new__(CageDaemon)
        payload = {"policy_yaml": (
            "version: 1\n"
            "policy:\n"
            "  - kind: does_not_exist\n"
            "    foo: bar\n"
        )}
        resp = CageDaemon._op_narrate_policy(daemon, payload)
        assert resp["verdict"] == "error"
        assert resp["error"]
