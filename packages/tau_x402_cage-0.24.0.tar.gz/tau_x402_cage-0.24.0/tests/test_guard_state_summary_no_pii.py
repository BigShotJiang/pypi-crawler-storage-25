"""Regression test: guard_state_summary must never admit raw PII / NPI.

Load-bearing for SOC 2 C1.1 (Confidentiality) and NYDFS Part 500
§500.13 (nonpublic information retention). The regulatory mapping
matrix (docs/regulatory-mapping.md rows 35, 46) claims the cage's
runtime-decision evidence stores COUNTERS / CAPS / VELOCITIES only,
not raw counterparty PII or payer account data.

This test pins that contract. If a future change adds a field to
guard_state_summary that smuggles in a cardholder name, PAN, email
address, or the full allowlist membership list, it fails here.

The contract being enforced:
  1. Every top-level key matches an approved schema pattern.
  2. No value looks like a credit-card PAN (12-19 consecutive digits).
  3. No value looks like an email address (contains ``@`` + domain).
  4. ProviderAllowlist data is reduced to a count, not the member list.
  5. Intent provider is allowed (merchant identifier, card-rail-safe).
"""
from __future__ import annotations

import json
import re
from decimal import Decimal
from types import MappingProxyType

import pytest

from adapter.guaranteed_stubs import (
    _summarise_guard_state,
    GuaranteedDecision,
)
from adapter.guaranteed_audit import (
    RuntimeDecisionEvidence,
    _freeze_mapping,
)
from adapter.invariants import (
    MaxPerCall,
    ProviderAllowlist,
    SpendingCap,
)
from adapter.payment_intent_matcher import PaymentIntent
from adapter.x402_registry import X402Registry


# Approved top-level key patterns. New additions must be reviewed
# against SOC 2 C1.1 + NYDFS §500.13 before landing.
_APPROVED_KEY_PATTERNS = (
    re.compile(r"^intent_(amount|currency|provider)$"),
    re.compile(r"^history_size$"),
    re.compile(r"^(SpendingCap|MaxPerCall|ProviderAllowlist|"
               r"RetryRateLimit|RollingWindowCap|BurstVelocityCap|"
               r"MutualExclusion|JurisdictionRule|CounterpartyConstraint)"
               r"_[a-zA-Z0-9_]+$"),
)


# Obvious PII-shape regexes. A match is a structural bug, not a false
# positive — the guard state legitimately never needs these shapes.
_PAN_REGEX = re.compile(r"\b\d{12,19}\b")
_EMAIL_REGEX = re.compile(r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}")
_SSN_REGEX = re.compile(r"\b\d{3}-\d{2}-\d{4}\b")


def _intent(*, amount: str = "40", provider: str = "aws.amazon.com",
            currency: str = "USDC",
            counterparty: str = "acme.inc.vendor") -> PaymentIntent:
    """Build a PaymentIntent with a PII-heavy counterparty by default.

    ``counterparty`` is a real field on PaymentIntent and CAN carry
    business-sensitive identifiers. The regression contract is that
    _summarise_guard_state must NEVER include it in the evidence
    record — that's the core SOC 2 C1.1 / NYDFS §500.13 claim.
    """
    return PaymentIntent(
        amount=Decimal(amount),
        currency=currency,
        provider=provider,
        counterparty=counterparty,
        rail="x402",
        timestamp_unix=1_713_000_000,
    )


def _realistic_registry() -> X402Registry:
    return X402Registry(invariants=(
        SpendingCap(
            max_amount=Decimal("100"),
            currency="USDC",
            scope="per_tx",
        ),
        MaxPerCall(max_amount=Decimal("50"), currency="USDC"),
        ProviderAllowlist(providers=frozenset({
            "stripe.com", "aws.amazon.com", "openai.com",
            "anthropic.com", "github.com",
        })),
    ))


class TestKeySchema:
    def test_every_key_matches_approved_pattern(self) -> None:
        reg = _realistic_registry()
        summary = _summarise_guard_state(reg, history=[], intent=_intent())
        for key in summary:
            assert any(p.match(key) for p in _APPROVED_KEY_PATTERNS), (
                f"guard_state_summary key {key!r} does not match any "
                f"approved schema pattern. If this is a legitimate "
                f"new field, add its pattern to _APPROVED_KEY_PATTERNS "
                f"and review against SOC 2 C1.1 + NYDFS §500.13."
            )

    def test_no_provider_list_leaks_as_values(self) -> None:
        """ProviderAllowlist must serialise as a count, not members."""
        reg = _realistic_registry()
        summary = _summarise_guard_state(reg, history=[], intent=_intent())
        rendered = json.dumps(summary, sort_keys=True)
        for domain in ("stripe.com", "openai.com", "github.com"):
            # intent_provider is allowed to equal a domain; other
            # occurrences would mean we leaked the membership list.
            occurrences = rendered.count(domain)
            assert occurrences <= 1, (
                f"domain {domain!r} appears {occurrences} times in "
                f"guard_state_summary; only intent_provider may carry "
                f"it. Allowlist members must be summarised as a count."
            )


class TestPIIShapes:
    @pytest.mark.parametrize("intent_kwargs", [
        {"amount": "123456789012", "provider": "stripe.com"},
        {"amount": "40", "provider": "acme.example.com"},
    ])
    def test_no_pan_like_value(self, intent_kwargs: dict) -> None:
        """Canonical-JSON of the summary must not contain a PAN-shape."""
        reg = _realistic_registry()
        intent = _intent(**intent_kwargs)
        summary = _summarise_guard_state(reg, history=[], intent=intent)
        rendered = json.dumps(summary, sort_keys=True)
        match = _PAN_REGEX.search(rendered)
        # An 'intent_amount' of 123456789012 is a 12-digit number. That's
        # a legitimate amount string, not a PAN — we assert it only
        # appears inside the intent_amount value, never elsewhere.
        if match is not None:
            assert '"intent_amount"' in rendered, (
                f"guard_state_summary contains a PAN-shaped value "
                f"{match.group(0)!r} outside of intent_amount: "
                f"{rendered}"
            )

    def test_no_email_value(self) -> None:
        reg = _realistic_registry()
        summary = _summarise_guard_state(reg, history=[], intent=_intent())
        rendered = json.dumps(summary, sort_keys=True)
        assert _EMAIL_REGEX.search(rendered) is None, (
            f"guard_state_summary contains an email-shape: {rendered}"
        )

    def test_no_ssn_value(self) -> None:
        reg = _realistic_registry()
        summary = _summarise_guard_state(reg, history=[], intent=_intent())
        rendered = json.dumps(summary, sort_keys=True)
        assert _SSN_REGEX.search(rendered) is None, (
            f"guard_state_summary contains an SSN-shape: {rendered}"
        )


class TestEvidenceFreeze:
    def test_runtime_evidence_freezes_summary(self) -> None:
        """RuntimeDecisionEvidence wraps the summary in MappingProxyType.

        A live mutable reference could be exploited post-stamp to inject
        PII. The _freeze_mapping helper rejects non-JSON-serialisable
        values and deep-copies nested containers.
        """
        reg = _realistic_registry()
        summary = _summarise_guard_state(reg, history=[], intent=_intent())
        frozen = _freeze_mapping(summary)
        assert isinstance(frozen, MappingProxyType)
        with pytest.raises(TypeError):
            frozen["new_key"] = "pwned"  # type: ignore[index]

    def test_freeze_rejects_non_json_values(self) -> None:
        """A caller cannot smuggle in a non-serialisable object."""

        class Opaque:
            pass

        with pytest.raises((TypeError, ValueError)):
            _freeze_mapping({"opaque": Opaque()})


class TestCounterpartyNeverLeaks:
    """The headline SOC 2 C1.1 / NYDFS §500.13 claim.

    PaymentIntent carries a ``counterparty`` field that CAN be a
    business-sensitive identifier (vendor account id, merchant name,
    routing string). The guard_state_summary contract is that this
    field must never appear in the evidence record under any intent,
    even a pathologically identifying one.
    """

    def test_counterparty_string_never_appears_in_summary(self) -> None:
        reg = _realistic_registry()
        sensitive = "Dr-Jane-Smith-SSN-123-45-6789-Account-9876543210"
        # The counterparty field validates via _SAFE_TOKEN_RE, which
        # rejects spaces/special chars. Use an underscore-joined form
        # that passes validation but is still uniquely identifiable.
        safe_but_unique = sensitive.replace(" ", "_")
        try:
            intent = _intent(counterparty=safe_but_unique)
        except Exception:
            # If PaymentIntent validation rejects this, the token is
            # even tighter than we assumed — still need the contract.
            intent = _intent(counterparty="acme_vendor_internal_id_42")
            safe_but_unique = "acme_vendor_internal_id_42"
        summary = _summarise_guard_state(reg, history=[], intent=intent)
        rendered = json.dumps(summary, sort_keys=True)
        assert safe_but_unique not in rendered, (
            f"counterparty {safe_but_unique!r} leaked into "
            f"guard_state_summary: {rendered}"
        )
        # Also assert the field name itself is absent from keys.
        assert "counterparty" not in summary, (
            f"guard_state_summary has a 'counterparty' key: {summary}"
        )


class TestAuditContractDocumented:
    """Living documentation: the approved-key list IS the contract.

    If this list drifts from the regulatory-mapping claim in rows
    35 (NYDFS §500.13) and 46 (SOC 2 C1.1 / C1.2), one of the two
    needs updating. Pinning here protects the claim.
    """

    def test_approved_patterns_cover_current_production_keys(self) -> None:
        reg = _realistic_registry()
        summary = _summarise_guard_state(reg, history=[], intent=_intent())
        assert summary, "summary unexpectedly empty"
        # The pattern list must match every key actually emitted today.
        # This is redundant with TestKeySchema but intentional — it
        # fails loudly if the helper ever emits zero keys.
        for key in summary:
            assert any(p.match(key) for p in _APPROVED_KEY_PATTERNS), key
