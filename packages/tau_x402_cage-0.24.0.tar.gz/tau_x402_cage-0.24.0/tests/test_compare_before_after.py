"""Tests for the v0.23.0 compare before/after surface.

Covers:

* ``build_tightening_effect`` pure helper — composes the baseline /
  tightened / rationale block from raw inputs.
* ``_render_tightening_effect`` CLI rendering — surfaces the
  baseline-vs-tightened-vs-why columns when the report carries a
  non-empty ``tightening_effect`` block.
* Monotonicity: baseline limits are never stricter-or-equal than
  tightened for shrink-keys; baseline is never more-or-equal than
  tightened for grow-keys.
"""
from __future__ import annotations

import io
import json
from decimal import Decimal

import pytest

from adapter.safety_comparison import build_tightening_effect
from daemon.cli import _render_comparison, _render_tightening_effect


class TestBuildTighteningEffect:
    """Pure helper shape + content."""

    def test_returns_none_when_inactive(self) -> None:
        """Empty tightened map => no block emitted (wire is clean)."""
        assert (
            build_tightening_effect(baseline={"max_requests": 10}, tightened={})
            is None
        )

    def test_returns_block_with_three_keys(self) -> None:
        effect = build_tightening_effect(
            baseline={"max_requests": 10, "cooldown_seconds": 6},
            tightened={"max_requests": 3, "cooldown_seconds": 45},
        )
        assert effect is not None
        assert set(effect.keys()) == {"baseline", "tightened", "rationale"}
        assert effect["baseline"] == {"max_requests": 10, "cooldown_seconds": 6}
        assert effect["tightened"] == {"max_requests": 3, "cooldown_seconds": 45}

    def test_rationale_populated_for_differing_keys(self) -> None:
        effect = build_tightening_effect(
            baseline={"max_requests": 10, "cooldown_seconds": 6},
            tightened={"max_requests": 3, "cooldown_seconds": 45},
        )
        assert effect is not None
        # Each differing key gets a plain-English reason.
        assert "retry density" in effect["rationale"]["max_requests"].lower()
        assert "identical" in effect["rationale"]["cooldown_seconds"].lower()

    def test_rationale_empty_when_values_match(self) -> None:
        """Keys that baseline==tightened never get a rationale."""
        effect = build_tightening_effect(
            baseline={"max_requests": 10},
            tightened={"max_requests": 10},
        )
        # tightened is non-empty, so we do emit a block, but the
        # rationale dict has no entries (no diffs).
        assert effect is not None
        assert effect["rationale"] == {}

    def test_decimal_values_stringify(self) -> None:
        """Decimals serialise as strings so the block is JSON-safe."""
        effect = build_tightening_effect(
            baseline={"per_tx_cap": Decimal("1000")},
            tightened={"per_tx_cap": Decimal("700")},
        )
        assert effect is not None
        assert effect["baseline"]["per_tx_cap"] == "1000"
        assert effect["tightened"]["per_tx_cap"] == "700"
        # JSON-safe end-to-end.
        json.dumps(effect)

    def test_trigger_override_fills_unknown_keys(self) -> None:
        """Unknown limit names fall back to the trigger phrase."""
        effect = build_tightening_effect(
            baseline={"my_custom_key": 100},
            tightened={"my_custom_key": 50},
            trigger="retry_density_exceeded",
        )
        assert effect is not None
        assert "retry density exceeded" in effect["rationale"]["my_custom_key"]


class TestMonotonicity:
    """Brief constraint: baseline limits never stricter than tightened.

    * Shrink-keys (caps, retry counts): ``baseline >= tightened``.
    * Grow-keys (cooldowns, min_gap): ``baseline <= tightened``.
    """

    def test_shrink_keys_baseline_not_less_than_tightened(self) -> None:
        effect = build_tightening_effect(
            baseline={
                "max_requests": 10,
                "max_amount": Decimal("1000"),
                "spend_cap": Decimal("500"),
            },
            tightened={
                "max_requests": 3,
                "max_amount": Decimal("700"),
                "spend_cap": Decimal("200"),
            },
        )
        assert effect is not None
        assert int(effect["baseline"]["max_requests"]) >= int(
            effect["tightened"]["max_requests"]
        )
        assert Decimal(effect["baseline"]["max_amount"]) >= Decimal(
            effect["tightened"]["max_amount"]
        )
        assert Decimal(effect["baseline"]["spend_cap"]) >= Decimal(
            effect["tightened"]["spend_cap"]
        )

    def test_grow_keys_baseline_not_greater_than_tightened(self) -> None:
        effect = build_tightening_effect(
            baseline={"cooldown_seconds": 6, "min_gap_seconds": 30},
            tightened={"cooldown_seconds": 45, "min_gap_seconds": 90},
        )
        assert effect is not None
        assert int(effect["baseline"]["cooldown_seconds"]) <= int(
            effect["tightened"]["cooldown_seconds"]
        )
        assert int(effect["baseline"]["min_gap_seconds"]) <= int(
            effect["tightened"]["min_gap_seconds"]
        )


class TestCompareCliRendering:
    """Brief Test 4 — compare with tightening active shows three columns."""

    def test_render_tightening_effect_writes_expected_rows(self) -> None:
        buf = io.StringIO()
        effect = {
            "baseline": {
                "max_requests": 10,
                "cooldown_seconds": 6,
                "per_tx_cap": "1000",
            },
            "tightened": {
                "max_requests": 3,
                "cooldown_seconds": 45,
                "per_tx_cap": "700",
            },
            "rationale": {
                "max_requests": "retry density > 10/min",
                "cooldown_seconds": "identical requests x 4",
                "per_tx_cap": "velocity 3x ema",
            },
        }
        _render_tightening_effect(effect, buf)
        rendered = buf.getvalue()
        # Header shows all three columns.
        assert "baseline" in rendered
        assert "tightened" in rendered
        assert "why" in rendered
        # One row per differing key.
        assert "max_requests" in rendered
        assert "cooldown_seconds" in rendered
        assert "per_tx_cap" in rendered
        # Rationale text surfaces verbatim.
        assert "retry density > 10/min" in rendered
        assert "identical requests x 4" in rendered
        assert "velocity 3x ema" in rendered

    def test_render_comparison_includes_effect_when_present(self) -> None:
        """End-to-end: _render_comparison renders tightening_effect when it's in the report."""
        buf = io.StringIO()
        report = {
            "with_system": "reject",
            "without_system": "permit",
            "risk_amount": "50",
            "risk_currency": "USDC",
            "rule_id": "adaptive_tightening",
            "invariant_class": "AdaptiveTightening",
            "tightening_effect": {
                "baseline": {"max_requests": 10, "cooldown_seconds": 6},
                "tightened": {"max_requests": 3, "cooldown_seconds": 45},
                "rationale": {
                    "max_requests": "retry density > 10/min",
                    "cooldown_seconds": "identical requests x 4",
                },
            },
        }
        _render_comparison(report, buf)
        rendered = buf.getvalue()
        # Baseline compare content is still there.
        assert "Safety comparison" in rendered
        # Plus the new tightening block.
        assert "tightening_effect" in rendered
        assert "retry density > 10/min" in rendered

    def test_render_comparison_stays_quiet_when_effect_absent(self) -> None:
        """Back-compat: pre-v0.23 reports render unchanged."""
        buf = io.StringIO()
        report = {
            "with_system": "reject",
            "without_system": "permit",
            "risk_amount": "50",
            "risk_currency": "USDC",
            "rule_id": "max_per_call",
        }
        _render_comparison(report, buf)
        rendered = buf.getvalue()
        assert "tightening_effect" not in rendered

    def test_render_comparison_stays_quiet_when_effect_empty(self) -> None:
        """Empty tightened dict => no baseline/tightened/why table."""
        buf = io.StringIO()
        report = {
            "with_system": "permit",
            "without_system": "permit",
            "tightening_effect": {
                "baseline": {"max_requests": 10},
                "tightened": {},
                "rationale": {},
            },
        }
        _render_comparison(report, buf)
        rendered = buf.getvalue()
        assert "tightening_effect" not in rendered
