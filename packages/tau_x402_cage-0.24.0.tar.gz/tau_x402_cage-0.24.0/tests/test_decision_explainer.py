"""Tests for the v0.17.0 per-decision explainer + forward-projected comparison.

Coverage:
    * Every invariant class gets a dedicated, non-generic describer.
    * ``what_would_allow`` returns sensible copy for each class.
    * ``retry_after_seconds`` populated from RetryRateLimit cooldown state.
    * Daemon op round-trip by ``bundle_id`` and by ``intent_hash``.
    * Unknown bundle_id/hash → structured error, not exception.
    * CLI ``explain-decision`` text + json output.
    * MCP tool wiring: ``explain_decision`` invocation returns structured
      content.
    * Forward projection: steady velocity, zero velocity, reject scenario.
    * Envelope MAC-binding of ``risk_amount_projected``: tamper → verify
      fails.
    * Spec example: "7 paid calls in 9 seconds, exceeding burst threshold
      of 5, cooldown 42s" renders verbatim.
"""

from __future__ import annotations

import dataclasses
import json
import os
import socket
import subprocess
import sys
import tempfile
import threading
import time
from decimal import Decimal
from pathlib import Path
from typing import Iterator

import pytest

from adapter.decision_explainer import (
    DecisionExplanation,
    explain_decision,
)
from adapter.payment_intent_matcher import PaymentIntent
from adapter.safety_comparison import (
    ComparisonReport,
    compare_verdict,
)
from adapter.verdict_signer import (
    SignatureError,
    SignedEnvelope,
    Verdict,
    sign,
    verify,
)
from adapter.x402_registry import X402Registry
from adapter.invariants import SpendingCap
from daemon.server import CageDaemon


SECRET = b"decision-explainer-test-secret-at-least-16-bytes"


def _intent(
    amount: str = "50.00",
    currency: str = "USDC",
    provider: str = "anthropic",
    counterparty: str = "vendor_a",
    timestamp_unix: int = 1_700_000_000,
) -> PaymentIntent:
    return PaymentIntent(
        amount=Decimal(amount),
        currency=currency,
        provider=provider,
        counterparty=counterparty,
        rail="x402",
        timestamp_unix=timestamp_unix,
    )


def _record(
    *,
    verdict: str = "reject",
    rule_id: str | None = "spending_cap_per_tx",
    reason_text: str | None = "cap exceeded",
    witness: str | None = "intent=500,cap=100",
    intent_currency: str = "USDC",
    bundle_id: str = "00000000-0000-0000-0000-000000000001",
    intent_hash: str = "ih1234",
) -> dict:
    return {
        "verdict": verdict,
        "rule_id": rule_id,
        "reason_text": reason_text,
        "_bundle_witness": witness,
        "intent": {
            "amount": "500",
            "currency": intent_currency,
            "provider": "anthropic",
            "counterparty": "vendor_a",
            "rail": "x402",
            "timestamp_unix": 1_700_000_000,
        },
        "bundle_id": bundle_id,
        "intent_hash": intent_hash,
    }


# ── per-class describers ────────────────────────────────────────────────────


class TestInvariantDescribers:
    def test_max_per_call_describer(self) -> None:
        exp = explain_decision(_record(
            rule_id="max_per_call",
            witness="intent=500,cap=100",
            reason_text="single-call cap exceeded",
        ))
        assert exp.invariant_class == "MaxPerCall"
        assert "MaxPerCall" in exp.narrative
        assert "500" in exp.narrative and "100" in exp.narrative
        assert "Raise the MaxPerCall cap" in exp.what_would_allow

    def test_spending_cap_per_tx_describer(self) -> None:
        exp = explain_decision(_record(
            rule_id="spending_cap_per_tx",
            witness="intent=500,cap=100",
        ))
        assert exp.invariant_class == "SpendingCap"
        assert "per_tx" in exp.narrative or "per-transaction" in exp.narrative
        assert "SpendingCap(per_tx)" in exp.what_would_allow

    def test_spending_cap_per_window_describer(self) -> None:
        exp = explain_decision(_record(
            rule_id="spending_cap_per_window",
            witness="cumulative=1002,cap=1000,window=60s",
        ))
        assert exp.invariant_class == "SpendingCap"
        assert "1002" in exp.narrative
        assert "60s" in exp.narrative
        assert "roll out" in exp.what_would_allow

    def test_spending_cap_per_provider_per_window_describer(self) -> None:
        exp = explain_decision(_record(
            rule_id="spending_cap_per_provider_per_window",
            witness="cumulative=75,cap=50,window=60s",
        ))
        assert exp.invariant_class == "SpendingCap"
        assert "provider-scoped" in exp.summary
        assert "per_provider_per_window" in exp.narrative

    def test_retry_rate_limit_describer_minimum_gap(self) -> None:
        exp = explain_decision(_record(
            rule_id="retry_rate_limit",
            witness="gap=3s,min=10s",
        ))
        assert exp.invariant_class == "RetryRateLimit"
        assert exp.retry_after_seconds == 7
        assert "RetryRateLimit" in exp.narrative
        assert "Wait" in exp.what_would_allow

    def test_retry_rate_limit_describer_burst_threshold_spec_example(self) -> None:
        """Spec example: '7 paid calls in 9 seconds, exceeding burst
        threshold of 5, cooldown 42s' — must render verbatim."""
        exp = explain_decision(_record(
            rule_id="retry_rate_limit",
            witness=(
                "call_count=7,interval_seconds=9,burst_threshold=5,"
                "window_seconds=30,cooldown_seconds=42,endpoint=/charge"
            ),
            reason_text="burst threshold exceeded",
        ))
        # Verbatim narrative check against the spec's target phrasing.
        assert (
            "Blocked because this agent attempted 7 paid calls to "
            "/charge in 9 seconds, exceeding the current burst "
            "threshold of 5."
        ) in exp.narrative
        assert "Cooldown remains active for 42 seconds." in exp.narrative
        assert exp.retry_after_seconds == 42
        assert exp.invariant_class == "RetryRateLimit"

    def test_provider_allowlist_describer(self) -> None:
        exp = explain_decision(_record(
            rule_id="provider_allowlist",
            witness="provider=unknown",
            reason_text=(
                "Provider 'unknown' not in allowlist "
                "(['anthropic', 'openai'])"
            ),
        ))
        assert exp.invariant_class == "ProviderAllowlist"
        assert "'unknown'" in exp.narrative or "unknown" in exp.narrative
        assert "Add" in exp.what_would_allow

    def test_mutual_exclusion_describer(self) -> None:
        exp = explain_decision(_record(
            rule_id="mutual_exclusion",
            witness="provider=dualgroup,overlap=['dualgroup']",
        ))
        assert exp.invariant_class == "MutualExclusion"
        assert "MutualExclusion" in exp.narrative
        assert "Move" in exp.what_would_allow

    def test_counterparty_sanctioned_describer(self) -> None:
        exp = explain_decision(_record(
            rule_id="counterparty_sanctioned",
            witness="counterparty=baduser",
        ))
        assert exp.invariant_class == "CounterpartyConstraint"
        assert "sanction" in exp.narrative.lower()

    def test_counterparty_not_approved_describer(self) -> None:
        exp = explain_decision(_record(
            rule_id="counterparty_not_approved",
            witness="counterparty=stranger",
        ))
        assert exp.invariant_class == "CounterpartyConstraint"
        assert "approved" in exp.narrative

    def test_rolling_window_cap_describer(self) -> None:
        exp = explain_decision(_record(
            rule_id="rolling_window_cap_provider",
            witness="count=11,cap=10,window=60s",
        ))
        assert exp.invariant_class == "RollingWindowCap"
        assert "provider" in exp.narrative
        assert "RollingWindowCap" in exp.what_would_allow

    def test_instability_guard_describer(self) -> None:
        exp = explain_decision(_record(
            rule_id="instability_guard",
            witness=(
                "provider=flaky,recent_rejects=3,threshold=3,"
                "tighten_to=5,intent=10"
            ),
        ))
        assert exp.invariant_class == "InstabilityGuard"
        assert "guard active" in exp.summary.lower() or "InstabilityGuard active" in exp.summary
        assert "3 rejects" in exp.summary or "3 reject" in exp.summary

    def test_burst_velocity_cap_describer(self) -> None:
        exp = explain_decision(_record(
            rule_id="burst_velocity_cap",
            witness="spend_rate=25,cap_rate=10,window=60",
        ))
        assert exp.invariant_class == "BurstVelocityCap"
        assert "velocity" in exp.narrative
        assert "Throttle" in exp.what_would_allow

    def test_cross_revision_violation_describer(self) -> None:
        exp = explain_decision(_record(
            rule_id="cross_revision_violation",
            witness="rule=per_tx_cap,old_value=10,new_value=20,branch=main",
        ))
        assert exp.invariant_class == "CrossRevisionViolation"
        assert "weaken" in exp.narrative
        assert "main" in exp.summary

    def test_governance_violation_describer(self) -> None:
        exp = explain_decision(_record(
            rule_id="governance_violation",
            witness="actor=alice,class=SpendingCap",
        ))
        assert exp.invariant_class == "GovernanceViolation"
        assert "not authorized" in exp.summary
        assert "authorized actor" in exp.what_would_allow

    def test_policy_inconclusive_describer(self) -> None:
        exp = explain_decision(_record(
            rule_id="policy_inconclusive",
            witness="elapsed_ms=5000,backend=tau",
        ))
        assert exp.invariant_class == "PolicyInconclusive"
        assert "Inconclusive" in exp.summary
        # Narrative uses "Strict-mode" (hyphenated, capitalised at sentence start).
        assert "strict-mode" in exp.narrative.lower()

    def test_unknown_rule_id_falls_back(self) -> None:
        """Unknown rule_ids must still render something useful."""
        exp = explain_decision(_record(
            rule_id="future_invariant_we_dont_know",
            witness="foo=bar",
            reason_text="some structured reason",
        ))
        assert exp.invariant_class is None
        assert "future_invariant_we_dont_know" in exp.narrative
        # The fallback still carries a remedy hint.
        assert exp.what_would_allow

    def test_permit_explanation(self) -> None:
        exp = explain_decision(_record(
            verdict="permit",
            rule_id=None,
            reason_text=None,
            witness=None,
        ))
        assert exp.outcome == "permit"
        assert exp.rule_id is None
        assert "Permitted" in exp.summary

    def test_jurisdiction_prefix_resolves_to_jurisdiction_class(self) -> None:
        exp = explain_decision(_record(
            rule_id="jurisdiction_eu.spending_cap_per_tx",
            witness="intent=500,cap=100",
        ))
        assert exp.invariant_class == "JurisdictionRule"
        assert "[jurisdiction]" in exp.summary


# ── what_would_allow sensible copy per class ────────────────────────────────


class TestWhatWouldAllow:
    """Each invariant class must return prescriptive, actionable copy."""

    def test_every_class_has_actionable_remedy(self) -> None:
        rule_ids = [
            "max_per_call",
            "spending_cap_per_tx",
            "spending_cap_per_window",
            "provider_allowlist",
            "retry_rate_limit",
            "rolling_window_cap_provider",
            "mutual_exclusion",
            "counterparty_sanctioned",
            "counterparty_not_approved",
            "instability_guard",
            "burst_velocity_cap",
            "cross_revision_violation",
            "governance_violation",
            "policy_inconclusive",
        ]
        for rule in rule_ids:
            witness = "intent=10,cap=5,cumulative=6,count=2,window=60s"  # broad
            exp = explain_decision(_record(rule_id=rule, witness=witness))
            assert exp.what_would_allow, f"{rule} has empty remedy"
            # A sensible remedy says SOMETHING about what the operator can do.
            lowered = exp.what_would_allow.lower()
            assert any(
                kw in lowered
                for kw in (
                    "wait", "raise", "add", "move", "remove",
                    "route", "verified mode", "authorized", "throttle",
                    "lower", "keep the limit",
                )
            ), f"{rule} remedy lacks action verb: {exp.what_would_allow!r}"


# ── retry_after_seconds from cooldown state ─────────────────────────────────


class TestRetryAfterSeconds:
    def test_retry_rate_limit_populates_remaining_cooldown(self) -> None:
        """Classic min-gap witness: remaining = min - gap."""
        exp = explain_decision(_record(
            rule_id="retry_rate_limit",
            witness="gap=5s,min=30s",
        ))
        assert exp.retry_after_seconds == 25

    def test_burst_threshold_witness_populates_cooldown(self) -> None:
        exp = explain_decision(_record(
            rule_id="retry_rate_limit",
            witness="call_count=7,interval_seconds=9,burst_threshold=5,cooldown_seconds=42",
        ))
        assert exp.retry_after_seconds == 42

    def test_non_cooldown_rule_has_none(self) -> None:
        exp = explain_decision(_record(
            rule_id="max_per_call",
            witness="intent=500,cap=100",
        ))
        assert exp.retry_after_seconds is None


# ── daemon op round-trip ────────────────────────────────────────────────────


@pytest.fixture
def daemon() -> Iterator[tuple[CageDaemon, str]]:
    fd, path = tempfile.mkstemp(prefix="expl-", suffix=".sock", dir="/tmp")
    os.close(fd)
    os.unlink(path)
    d = CageDaemon(socket_path=path)
    t = threading.Thread(target=d.serve_forever, daemon=True)
    t.start()
    for _ in range(50):
        if os.path.exists(path):
            break
        time.sleep(0.01)
    try:
        yield d, path
    finally:
        d.shutdown()
        t.join(timeout=1.0)


def _send(path: str, request: dict) -> dict:
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.settimeout(2.0)
    s.connect(path)
    try:
        s.sendall((json.dumps(request) + "\n").encode("utf-8"))
        f = s.makefile("r")
        line = f.readline()
    finally:
        s.close()
    return json.loads(line)


class TestDaemonExplainDecision:
    def _reject_and_lookup(self, path: str) -> dict:
        """Drive one reject through the daemon and return the stored
        verdict row (which carries bundle_id / intent_hash)."""
        _send(path, {
            "op": "declare_x402", "kind": "spending_cap",
            "max_amount": "100", "scope": "per_tx",
        })
        r = _send(path, {
            "op": "check_payment",
            "intent": {
                "amount": "500", "currency": "USDC",
                "provider": "anthropic", "counterparty": "v",
                "rail": "x402", "timestamp_unix": 1_700_000_000,
                "metadata": {}, "request_id": None,
            },
        })
        assert r["verdict"] == "reject"
        # Walk the recent verdict ring for the matching row so we can
        # pull bundle_id + intent_hash.
        rv = _send(path, {"op": "recent_verdicts", "limit": 5})
        assert rv["verdict"] == "ok"
        entries = rv["entries"]
        assert entries, "no verdicts recorded"
        # recent_verdicts returns newest-first, so entry 0 is our reject.
        return entries[0]

    def test_explain_by_intent_hash(self, daemon) -> None:
        _, path = daemon
        row = self._reject_and_lookup(path)
        intent_hash = row["intent_hash"]
        resp = _send(path, {
            "op": "explain_decision",
            "intent_hash": intent_hash,
        })
        assert resp["verdict"] == "ok"
        assert resp["intent_hash"] == intent_hash
        explanation = resp["explanation"]
        assert explanation["outcome"] == "reject"
        assert explanation["rule_id"] == "spending_cap_per_tx"
        assert explanation["invariant_class"] == "SpendingCap"
        assert explanation["what_would_allow"]

    def test_explain_by_bundle_id(self, daemon) -> None:
        _, path = daemon
        row = self._reject_and_lookup(path)
        bundle_id = row["bundle_id"]
        resp = _send(path, {
            "op": "explain_decision",
            "bundle_id": bundle_id,
        })
        assert resp["verdict"] == "ok"
        assert resp["bundle_id"] == bundle_id
        assert "narrative" in resp["explanation"]

    def test_explain_unknown_bundle_returns_structured_error(self, daemon) -> None:
        _, path = daemon
        resp = _send(path, {
            "op": "explain_decision",
            "bundle_id": "00000000-0000-0000-0000-000000000000",
        })
        assert resp["verdict"] == "error"
        assert resp["category"] == "unknown_verdict"
        assert "reason" in resp

    def test_explain_unknown_intent_hash_returns_structured_error(
        self, daemon,
    ) -> None:
        _, path = daemon
        resp = _send(path, {
            "op": "explain_decision",
            "intent_hash": "deadbeef" * 8,
        })
        assert resp["verdict"] == "error"
        assert resp["category"] == "unknown_verdict"

    def test_explain_missing_identifier_returns_structured_error(
        self, daemon,
    ) -> None:
        _, path = daemon
        resp = _send(path, {"op": "explain_decision"})
        assert resp["verdict"] == "error"
        assert resp["category"] == "bad_payload"


# ── CLI ─────────────────────────────────────────────────────────────────────


class TestCLIExplainDecision:
    def _reject_and_lookup(self, path: str) -> dict:
        _send(path, {
            "op": "declare_x402", "kind": "spending_cap",
            "max_amount": "100", "scope": "per_tx",
        })
        _send(path, {
            "op": "check_payment",
            "intent": {
                "amount": "500", "currency": "USDC",
                "provider": "anthropic", "counterparty": "v",
                "rail": "x402", "timestamp_unix": 1_700_000_000,
                "metadata": {}, "request_id": None,
            },
        })
        rv = _send(path, {"op": "recent_verdicts", "limit": 5})
        return rv["entries"][0]

    def test_text_output_renders_narrative(self, daemon) -> None:
        _, path = daemon
        row = self._reject_and_lookup(path)
        cp = subprocess.run(
            [
                sys.executable, "-m", "daemon.cli", "explain-decision",
                row["intent_hash"],
                "--socket", path,
            ],
            capture_output=True, text=True, timeout=10,
        )
        assert cp.returncode == 0, cp.stderr
        assert "Decision explanation" in cp.stdout
        assert "spending_cap_per_tx" in cp.stdout
        assert "SpendingCap" in cp.stdout
        assert "What would allow" in cp.stdout

    def test_json_output_is_schema_stable(self, daemon) -> None:
        _, path = daemon
        row = self._reject_and_lookup(path)
        cp = subprocess.run(
            [
                sys.executable, "-m", "daemon.cli", "explain-decision",
                row["bundle_id"], "--bundle-id",
                "--socket", path,
                "--format", "json",
            ],
            capture_output=True, text=True, timeout=10,
        )
        assert cp.returncode == 0, cp.stderr
        parsed = json.loads(cp.stdout)
        # Schema stability: these keys are the v1 surface.
        for k in (
            "summary",
            "narrative",
            "machine_readable",
            "rule_id",
            "invariant_class",
            "witnessed_behavior",
            "what_would_allow",
            "retry_after_seconds",
            "outcome",
        ):
            assert k in parsed, f"missing schema key {k!r}"
        assert parsed["rule_id"] == "spending_cap_per_tx"


# ── MCP tool wiring (module import — full MCP tool test lives in mcp/tests/) ─


class TestMCPWiring:
    """Cage-side smoke test: the MCP package's dispatch table, schemas,
    and descriptions all carry the new tool. Full MCP dispatch tests
    live in ``mcp/tests/test_explain_decision.py``; these checks run on
    whichever ``tau_x402_cage_mcp`` is importable (pip-installed from the
    worktree)."""

    def test_schemas_module_has_explain_decision_entry(self) -> None:
        """Schemas and descriptions are the stable source of truth.
        We check this module's own copy to avoid coupling to a separately
        installed MCP package version."""
        from importlib import util as _util
        spec = _util.spec_from_file_location(
            "_local_schemas",
            Path(__file__).parent.parent
            / "mcp" / "tau_x402_cage_mcp" / "schemas.py",
        )
        assert spec is not None and spec.loader is not None
        module = _util.module_from_spec(spec)
        spec.loader.exec_module(module)
        assert "explain_decision" in module.TOOL_INPUT_SCHEMAS
        assert "explain_decision" in module.TOOL_DESCRIPTIONS
        desc = module.TOOL_DESCRIPTIONS["explain_decision"]
        # Description should mention the lookup shape so LLMs know how
        # to call it.
        assert "intent_hash" in desc or "bundle_id" in desc
        # Input schema accepts either lookup key.
        schema = module.TOOL_INPUT_SCHEMAS["explain_decision"]
        props = schema.get("properties", {})
        assert "intent_hash" in props
        assert "bundle_id" in props


# ── Forward projection ──────────────────────────────────────────────────────


class TestForwardProjection:
    def _history(
        self,
        rate_per_sec: Decimal,
        duration_sec: int,
        currency: str = "USDC",
        now: int = 1_700_000_060,
    ) -> tuple[PaymentIntent, ...]:
        """Build a synthetic history spending `rate_per_sec` over the
        previous `duration_sec` seconds, one payment per second."""
        return tuple(
            PaymentIntent(
                amount=rate_per_sec,
                currency=currency,
                provider="anthropic",
                counterparty="v",
                rail="x402",
                timestamp_unix=now - i,
            )
            for i in range(1, duration_sec + 1)
        )

    def test_steady_velocity_linear_projection(self) -> None:
        """$1/s over last 60s → project 30/60/300 = 30/60/300 USDC."""
        history = self._history(
            rate_per_sec=Decimal("1"), duration_sec=60,
        )
        intent = _intent(
            amount="50",
            timestamp_unix=1_700_000_060,
        )
        report = compare_verdict(intent, X402Registry.empty(), history=history)
        proj = report.projected_spend_next_n_seconds
        assert proj[30] == Decimal("30")
        assert proj[60] == Decimal("60")
        assert proj[300] == Decimal("300")

    def test_zero_velocity_zero_projection(self) -> None:
        """Empty history → empty dict (no signal)."""
        intent = _intent(amount="50", timestamp_unix=1_700_000_060)
        report = compare_verdict(intent, X402Registry.empty(), history=())
        # Empty projection is the "no signal" shape.
        assert report.projected_spend_next_n_seconds == {}

    def test_zero_spend_over_window_returns_zero_projection(self) -> None:
        """History exists but all older than the 60s window → zero row."""
        intent = _intent(
            amount="50",
            timestamp_unix=1_700_001_000,  # far ahead of history
        )
        history = self._history(
            rate_per_sec=Decimal("1"),
            duration_sec=60,
            now=1_700_000_060,  # history ~940s old
        )
        report = compare_verdict(intent, X402Registry.empty(), history=history)
        proj = report.projected_spend_next_n_seconds
        # All history is outside the 60s window → zero baseline.
        assert proj[30] == Decimal("0")
        assert proj[60] == Decimal("0")
        assert proj[300] == Decimal("0")

    def test_reject_scenario_estimated_loss_blocked_is_intent_plus_projection(
        self,
    ) -> None:
        """On reject, estimated_loss_blocked = intent.amount + projected(60)."""
        registry = X402Registry.empty()
        cap = SpendingCap(
            max_amount=Decimal("100"),
            scope="per_tx",
            currency="USDC",
        )
        registry = registry.declare(cap)
        history = self._history(
            rate_per_sec=Decimal("1"), duration_sec=60,
        )
        intent = _intent(
            amount="500",  # above cap
            timestamp_unix=1_700_000_060,
        )
        report = compare_verdict(intent, registry, history=history)
        assert report.with_system == "reject"
        assert report.estimated_loss_blocked == Decimal("560")  # 500 + 60

    def test_permit_has_none_estimated_loss(self) -> None:
        intent = _intent(amount="50", timestamp_unix=1_700_000_060)
        history = self._history(
            rate_per_sec=Decimal("1"), duration_sec=60,
        )
        report = compare_verdict(intent, X402Registry.empty(), history=history)
        assert report.with_system == "permit"
        assert report.estimated_loss_blocked is None

    def test_to_wire_includes_projection_and_loss(self) -> None:
        """ComparisonReport.to_wire must include the new fields."""
        report = ComparisonReport(
            with_system="reject",
            without_system="permit",
            risk_amount=Decimal("500"),
            risk_currency="USDC",
            rule_id="spending_cap_per_tx",
            invariant_class="SpendingCap",
            projected_spend_next_n_seconds={
                30: Decimal("30"),
                60: Decimal("60"),
                300: Decimal("300"),
            },
            estimated_loss_blocked=Decimal("560"),
        )
        wire = report.to_wire()
        assert wire["projected_spend_next_n_seconds"]["60"] == "60"
        assert wire["estimated_loss_blocked"] == "560"

    def test_backward_compat_existing_callers_work(self) -> None:
        """ComparisonReport still defaults cleanly without new fields."""
        report = ComparisonReport(with_system="permit", without_system="permit")
        wire = report.to_wire()
        # New fields are present but empty / None — additive shape.
        assert wire["projected_spend_next_n_seconds"] == {}
        assert wire["estimated_loss_blocked"] is None


# ── Envelope MAC-binding of risk_amount_projected ───────────────────────────


class TestEnvelopeRiskAmountProjected:
    def _signed(self, projected: str | None = "560.00") -> tuple[
        SignedEnvelope, PaymentIntent,
    ]:
        intent = _intent(amount="500")
        v = Verdict(
            outcome="reject",
            rule_id="spending_cap_per_tx",
            reason_text="cap exceeded",
            ttl_seconds=30,
        )
        env = sign(
            v, intent, SECRET,
            now_unix=1_700_000_000,
            without_system="permit",
            risk_amount_projected=projected,
        )
        return env, intent

    def test_round_trip_preserves_risk_amount_projected(self) -> None:
        env, intent = self._signed("560.00")
        wire = env.to_json()
        parsed = SignedEnvelope.from_json(wire)
        assert parsed.risk_amount_projected == "560.00"
        # Signature still verifies.
        verify(parsed, intent, SECRET, now_unix=1_700_000_000)

    def test_promotes_to_v2(self) -> None:
        env, _ = self._signed("560.00")
        assert env.version == "v2"

    def test_tamper_breaks_verify(self) -> None:
        """Critical: MAC must cover risk_amount_projected."""
        env, intent = self._signed("100.00")
        tampered = dataclasses.replace(env, risk_amount_projected="999999.00")
        with pytest.raises(SignatureError):
            verify(tampered, intent, SECRET, now_unix=1_700_000_000)

    def test_v1_envelope_unchanged_when_projected_absent(self) -> None:
        """Back-compat: sign() without risk_amount_projected stays v1 on HMAC-only."""
        intent = _intent(amount="500")
        v = Verdict(outcome="reject", rule_id="max_per_call", ttl_seconds=30)
        env = sign(v, intent, SECRET, now_unix=1_700_000_000)
        assert env.version == "v1"
        assert env.risk_amount_projected is None


# ── DecisionExplanation dataclass shape ─────────────────────────────────────


class TestDecisionExplanationShape:
    def test_to_wire_is_json_safe(self) -> None:
        exp = DecisionExplanation(
            summary="s",
            narrative="n",
            rule_id="max_per_call",
            invariant_class="MaxPerCall",
            witnessed_behavior={"intent": "500", "cap": "100"},
            what_would_allow="Raise cap.",
            retry_after_seconds=42,
            outcome="reject",
        )
        wire = exp.to_wire()
        # JSON round-trip must succeed (no Decimal / dataclass leaks).
        json.dumps(wire)
        assert wire["retry_after_seconds"] == 42

    def test_dataclass_is_frozen(self) -> None:
        exp = DecisionExplanation(summary="s", narrative="n")
        with pytest.raises(dataclasses.FrozenInstanceError):
            exp.summary = "other"  # type: ignore[misc]

    def test_non_mapping_input_raises_type_error(self) -> None:
        with pytest.raises(TypeError):
            explain_decision("not a dict")  # type: ignore[arg-type]
