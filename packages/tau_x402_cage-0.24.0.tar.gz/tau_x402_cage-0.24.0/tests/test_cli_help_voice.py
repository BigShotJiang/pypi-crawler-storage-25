"""Tests for CLI subcommand help-text voice (v0.23.0).

The v0.23.0 front-door pass rewrote subcommand one-liners so the
first thing an operator sees on ``tau-x402 <cmd> --help`` is an
action verb, not a noun-phrase about internals.

These tests pin:

  1. ``run`` leads with "Authorise" (or an equivalent action verb).
  2. Each of the core subcommands follows the voice guide (leads
     with a capital-letter action verb).
  3. Help output lines stay under 120 chars where possible — our
     argparse defaults already wrap, but we catch the odd long line.
"""
from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

import pytest


REPO_ROOT = Path(__file__).resolve().parent.parent


def _run_cli(*argv: str, timeout: float = 30.0) -> subprocess.CompletedProcess:
    """Invoke ``python -m daemon.cli`` with PYTHONPATH pointed at the repo."""
    env = dict(os.environ)
    env["PYTHONPATH"] = str(REPO_ROOT) + os.pathsep + env.get("PYTHONPATH", "")
    return subprocess.run(
        [sys.executable, "-m", "daemon.cli", *argv],
        capture_output=True,
        text=True,
        env=env,
        timeout=timeout,
    )


# Sub-commands that must lead with action language. Each entry maps
# the subcommand to the set of action words where at least one must
# appear in the --help top-line.
_ACTION_VOICE_EXPECTATIONS = {
    "run": ("Authorise", "Authorize"),
    "quickstart": ("Scaffold",),
    "init": ("Create",),
    "lint": ("Check",),
    "compare": ("Show",),
    "risk-prevented": ("Show",),
    "inspect": ("Inspect",),
    "explain": ("Explain",),
    "explain-decision": ("Explain",),
    "audit-export": ("Export",),
}


# ── each subcommand leads with an action verb ───────────────────────────────


class TestHelpLeadsWithAction:
    """Per-subcommand help must open with a capitalised action verb.

    We read ``tau-x402 <cmd> --help`` and check the first non-usage
    paragraph begins with one of the expected verbs. This is a
    presentation contract, not a semantic one — it ensures operators
    scanning ``--help`` see the verb first.
    """

    @pytest.mark.parametrize("cmd, verbs", list(_ACTION_VOICE_EXPECTATIONS.items()))
    def test_help_leads_with_action_verb(
        self, cmd: str, verbs: tuple[str, ...]
    ) -> None:
        out = _run_cli(cmd, "--help")
        assert out.returncode == 0, (
            f"help exit for {cmd}: stderr={out.stderr!r}"
        )
        # argparse puts the help one-liner at the top of the help
        # block. We search the first ~600 chars — enough to catch the
        # description, more than enough to avoid matching deep in the
        # per-flag detail where "show" could appear for benign reasons.
        opening = out.stdout[:600]
        found = any(v in opening for v in verbs)
        assert found, (
            f"help for {cmd!r} does not lead with any of {verbs!r}:\n"
            + opening
        )


# ── top-level `run --help` follows the decision-layer voice ─────────────────


class TestRunHelpVoice:
    """The first-run subcommand gets extra scrutiny because it's the
    one operators will ``--help`` first."""

    def test_run_help_mentions_decision_or_authorise(self) -> None:
        out = _run_cli("run", "--help")
        assert out.returncode == 0
        opening = out.stdout[:600].lower()
        assert "authorise" in opening or "authorize" in opening, (
            "run --help top-line should name the action (authorise):\n"
            + out.stdout[:600]
        )

    def test_run_help_centers_agent_not_fragments(self) -> None:
        """The top-line should not lead with 'fragment' or
        'prover_chain' — those are internals."""
        out = _run_cli("run", "--help")
        opening = out.stdout[:400].lower()
        # The opening should name the target (your agent) rather than
        # leading with "fragment" or "prover".
        assert "agent" in opening, (
            "run --help top-line should mention 'agent':\n"
            + out.stdout[:400]
        )
        # These tokens may appear deeper in --help (e.g. --prover-mode
        # flag description). We only check the first 200 chars for the
        # leading-term contract.
        lead = out.stdout[:200].lower()
        assert "fragment" not in lead
        assert "prover_chain" not in lead


# ── help output respects reasonable line lengths ────────────────────────────


class TestHelpLineLengths:
    """Help output should not contain absurdly long lines (>120 chars).

    argparse wraps automatically based on ``COLUMNS``. We set
    COLUMNS=120 for the test and then verify no line exceeds that,
    modulo one small safety margin.
    """

    @pytest.mark.parametrize("cmd", [
        "run", "quickstart", "init", "lint", "inspect",
        "explain", "compare", "risk-prevented",
    ])
    def test_help_lines_reasonable(self, cmd: str) -> None:
        env = dict(os.environ)
        env["PYTHONPATH"] = (
            str(REPO_ROOT) + os.pathsep + env.get("PYTHONPATH", "")
        )
        env["COLUMNS"] = "120"
        result = subprocess.run(
            [sys.executable, "-m", "daemon.cli", cmd, "--help"],
            capture_output=True, text=True, env=env, timeout=20.0,
        )
        assert result.returncode == 0, (
            f"{cmd} --help failed: stderr={result.stderr!r}"
        )
        long_lines = [
            line for line in result.stdout.splitlines()
            if len(line) > 140  # a little slack past 120 for argparse wrap
        ]
        assert not long_lines, (
            f"{cmd} --help has lines > 140 chars:\n"
            + "\n".join(long_lines)
        )
