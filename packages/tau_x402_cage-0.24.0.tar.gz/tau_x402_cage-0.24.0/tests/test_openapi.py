"""OpenAPI 3.1 schema regression tests for the SaaS FastAPI surface.

Procurement reviewers ask for an API spec. FastAPI generates one from
our Pydantic response models for free — but only if we keep the models
wired up correctly. These tests lock in:

* ``/openapi.json`` returns a valid OpenAPI 3.1 document.
* Every route carries a tag.
* Every non-internal route has a declared ``response_model`` (catch
  untyped ``Dict[str, Any]`` leaks before they ship).
* Non-public routes document their auth requirement via responses.
* The committed snapshot at ``docs/api/openapi.json`` matches the live
  schema — run ``python scripts/regen-openapi.py`` to refresh.

All tests skip gracefully when ``fastapi`` isn't installed.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

try:
    from fastapi.testclient import TestClient
except ImportError:
    pytest.skip("fastapi not installed; skipping openapi tests", allow_module_level=True)

from saas.app import SaasConfig, create_app
from saas.billing import NullBillingReporter


REPO_ROOT = Path(__file__).resolve().parent.parent
COMMITTED_SCHEMA = REPO_ROOT / "docs" / "api" / "openapi.json"

#: Paths that are intentionally public (no bearer auth required). Everything
#: else must document an auth-failure response shape in the OpenAPI spec.
PUBLIC_PATHS = {"/v1/health"}


@pytest.fixture
def app():
    cfg = SaasConfig(
        api_keys={"t": "sk_test_openapi"},
        socket_path="/tmp/nonexistent-openapi.sock",
        hmac_secret=bytes(32),
        billing=NullBillingReporter(),
    )
    return create_app(cfg)


@pytest.fixture
def client(app) -> TestClient:
    return TestClient(app)


class TestSchemaShape:
    def test_openapi_json_returns_valid_31_schema(self, client: TestClient) -> None:
        r = client.get("/openapi.json")
        assert r.status_code == 200
        schema = r.json()

        # OpenAPI 3.1 declaration
        assert schema["openapi"].startswith("3.1"), f"expected 3.1.x, got {schema['openapi']}"

        # Required top-level keys
        assert "info" in schema
        assert "paths" in schema
        assert "components" in schema
        assert "schemas" in schema["components"]

        # Info block carries version + description
        info = schema["info"]
        assert info["title"] == "tau-x402-cage SaaS"
        assert info["version"]  # non-empty
        assert info.get("description")  # non-empty

    def test_openapi_tags_registered(self, client: TestClient) -> None:
        schema = client.get("/openapi.json").json()
        tag_names = {t["name"] for t in schema.get("tags", [])}
        assert {"Payment", "Policy", "Revision", "Proposal", "Ops"}.issubset(tag_names)

    def test_swagger_ui_mounted_at_docs(self, client: TestClient) -> None:
        r = client.get("/docs")
        # FastAPI serves a small HTML shim that loads Swagger UI from a CDN.
        assert r.status_code == 200
        assert "swagger" in r.text.lower()


class TestRouteAnnotations:
    def test_every_route_has_a_tag(self, client: TestClient) -> None:
        schema = client.get("/openapi.json").json()
        untagged = []
        for path, ops in schema["paths"].items():
            for method, spec in ops.items():
                if method not in {"get", "post", "put", "delete", "patch"}:
                    continue
                if not spec.get("tags"):
                    untagged.append(f"{method.upper()} {path}")
        assert not untagged, f"routes without tags: {untagged}"

    def test_every_route_has_response_model(self, client: TestClient) -> None:
        """Each documented response must point at a component schema or a
        concrete inline schema — never an empty object (which is what
        ``Dict[str, Any]`` would produce)."""
        schema = client.get("/openapi.json").json()
        offenders = []
        for path, ops in schema["paths"].items():
            for method, spec in ops.items():
                if method not in {"get", "post", "put", "delete", "patch"}:
                    continue
                responses = spec.get("responses", {})
                ok_resp = responses.get("200") or responses.get("201")
                if not ok_resp:
                    offenders.append(f"{method.upper()} {path}: no 2xx response declared")
                    continue
                content = ok_resp.get("content", {}).get("application/json", {})
                schema_entry = content.get("schema", {})
                if not schema_entry:
                    offenders.append(f"{method.upper()} {path}: 2xx has no schema")
                    continue
                # Accept either a $ref (component schema) or an explicit
                # non-empty object schema. Reject bare `{}` or `additionalProperties: true`
                # without properties (those are Dict[str, Any] leaks).
                is_ref = "$ref" in schema_entry
                has_type = bool(schema_entry.get("type") or schema_entry.get("anyOf")
                                or schema_entry.get("oneOf") or schema_entry.get("allOf"))
                if not (is_ref or has_type):
                    offenders.append(
                        f"{method.upper()} {path}: 2xx schema is untyped ({schema_entry!r})"
                    )
        assert not offenders, f"untyped responses: {offenders}"

    def test_auth_required_routes_document_401(self, client: TestClient) -> None:
        """Non-public routes must document a 401 response so clients know
        the bearer-token contract from the spec alone."""
        schema = client.get("/openapi.json").json()
        missing_401 = []
        for path, ops in schema["paths"].items():
            if path in PUBLIC_PATHS:
                continue
            for method, spec in ops.items():
                if method not in {"get", "post", "put", "delete", "patch"}:
                    continue
                responses = spec.get("responses", {})
                if "401" not in responses:
                    missing_401.append(f"{method.upper()} {path}")
        assert not missing_401, (
            f"non-public routes missing documented 401: {missing_401}"
        )


class TestWebUIExcluded:
    def test_web_ui_routes_not_in_schema(self, monkeypatch, tmp_path) -> None:
        """When the web UI is enabled, its HTML routes must not appear in
        ``/openapi.json`` — they're HTML endpoints, not part of the API
        surface a procurement reviewer should see."""
        monkeypatch.setenv("TAU_CAGE_WEB_UI_ENABLED", "1")
        monkeypatch.setenv("TAU_CAGE_WEB_UI_TOKEN", "test-token")
        cfg = SaasConfig(
            api_keys={"t": "sk_test"},
            socket_path=str(tmp_path / "stub.sock"),
            hmac_secret=bytes(32),
            billing=NullBillingReporter(),
        )
        app = create_app(cfg)
        c = TestClient(app)
        schema = c.get("/openapi.json").json()
        leaked = [p for p in schema["paths"] if p.startswith("/ui")]
        assert not leaked, f"web UI routes leaked into OpenAPI schema: {leaked}"


class TestCommittedSnapshot:
    def test_committed_openapi_matches_live(self, client: TestClient) -> None:
        """``docs/api/openapi.json`` must track the live schema. Refresh
        with ``python scripts/regen-openapi.py`` when routes change."""
        assert COMMITTED_SCHEMA.exists(), (
            f"committed schema missing at {COMMITTED_SCHEMA}; "
            "run `python scripts/regen-openapi.py`"
        )
        live = client.get("/openapi.json").json()
        committed = json.loads(COMMITTED_SCHEMA.read_text(encoding="utf-8"))
        # Compare structurally; both sides serialize to the same dict.
        assert live == committed, (
            "docs/api/openapi.json is stale. "
            "Run `python scripts/regen-openapi.py`."
        )


class TestSchemaComponents:
    def test_core_response_models_present(self, client: TestClient) -> None:
        schema = client.get("/openapi.json").json()
        components = schema["components"]["schemas"]
        for name in (
            "CheckPaymentRequest",
            "CheckPaymentResponse",
            "HealthResponse",
            "MetricsResponse",
            "ErrorEnvelope",
        ):
            assert name in components, f"missing schema component: {name}"

    def test_check_payment_request_fields(self, client: TestClient) -> None:
        schema = client.get("/openapi.json").json()
        props = schema["components"]["schemas"]["CheckPaymentRequest"]["properties"]
        # amount / provider / counterparty are the three fields every caller
        # sends. If these disappear from the schema something is wrong.
        assert {"amount", "provider", "counterparty"}.issubset(props.keys())
