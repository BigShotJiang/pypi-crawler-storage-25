"""Integration tests for the ``inspect_policy`` and ``explain_policy`` ops.

Drives ``CageDaemon.dispatch`` directly (no socket): the ops are pure
JSON-in / JSON-out so the socket path is uninteresting here. Socket
smoke-testing lives in ``tests/test_cli.py``.
"""
from __future__ import annotations

import pytest

from adapter.prover import (
    Contradiction,
    InconclusiveProof,
    ProofToken,
    PythonPatternProver,
)
from daemon.server import CageDaemon


# ── stub provers reused across the strict-mode class ─────────────────────────


class _SatTauProver:
    """Returns a complete ProofToken regardless of input."""

    backend = "tau-stub-sat"

    def prove(self, invariants, predecessor_hash=None):
        import hashlib
        import secrets
        import time
        ch = hashlib.sha256(
            repr(sorted((type(i).__name__, repr(i)) for i in invariants)).encode()
        ).hexdigest()
        return ProofToken(
            config_hash=ch,
            issued_at_unix=int(time.time()),
            backend="tau",
            proof_strength="complete",
            nonce=secrets.token_hex(8),
            predecessor_hash=predecessor_hash,
            fragment_version="v1",
            compile_hash="deadbeef" * 8,
        )


class _InconclusiveTauProver:
    backend = "tau-stub-inconclusive"

    def prove(self, invariants, predecessor_hash=None):
        return InconclusiveProof(
            category="timeout",
            reason="Tau exceeded budget (stub)",
            backend="tau",
        )


def _new_daemon(tmp_path, mode="compat", tau_prover=None) -> CageDaemon:
    sock = str(tmp_path / "inspect.sock")
    return CageDaemon(
        socket_path=sock,
        prover=PythonPatternProver(),
        prover_mode=mode,
        tau_prover=tau_prover,
    )


# ── inspect_policy ───────────────────────────────────────────────────────────


class TestInspectPolicy:
    def test_empty_registry_defaults(self, tmp_path) -> None:
        d = _new_daemon(tmp_path)
        r = d.dispatch({"op": "inspect_policy"})
        assert r["verdict"] == "ok"
        assert r["active_revision_id"] is None
        assert r["active_invariants"] == 0
        assert r["invariants"] == []
        assert r["prover_mode"] == "compat"
        assert r["proof_backend"] is None
        assert r["proof_strength"] is None
        assert r["fragment_version"] is None
        assert r["compile_hash"] is None
        assert r["admitted_at_unix"] is None

    def test_two_declares_show_up(self, tmp_path) -> None:
        d = _new_daemon(tmp_path)
        d.dispatch(
            {"op": "declare_x402", "kind": "max_per_call", "max_amount": "50"}
        )
        d.dispatch(
            {"op": "declare_x402", "kind": "retry_rate_limit", "min_gap_seconds": 30}
        )
        r = d.dispatch({"op": "inspect_policy"})
        assert r["verdict"] == "ok"
        assert r["active_invariants"] == 2
        classes = [i["class"] for i in r["invariants"]]
        assert classes == ["MaxPerCall", "RetryRateLimit"]
        # scope_hint present and non-trivial
        for entry in r["invariants"]:
            assert entry["scope_hint"]
            assert isinstance(entry["scope_hint"], str)
        # Provenance fields populated by most-recent revision
        assert r["active_revision_id"]
        assert r["proof_backend"] == "python-pattern"
        assert r["proof_strength"] == "pattern"
        assert r["admitted_at_unix"]

    def test_inspect_does_not_mutate(self, tmp_path) -> None:
        d = _new_daemon(tmp_path)
        d.dispatch({"op": "declare_x402", "kind": "max_per_call", "max_amount": "10"})
        before = d.dispatch({"op": "revision_log"})["length"]
        d.dispatch({"op": "inspect_policy"})
        d.dispatch({"op": "inspect_policy"})
        after = d.dispatch({"op": "revision_log"})["length"]
        assert before == after


# ── explain_policy: active mode ──────────────────────────────────────────────


class TestExplainActive:
    def test_empty_policy_is_sat(self, tmp_path) -> None:
        d = _new_daemon(tmp_path)
        r = d.dispatch({"op": "explain_policy"})
        assert r["verdict"] == "sat"
        assert r["report"] is None
        assert r["proof_token"] is not None
        assert r["proof_token"]["backend"] == "python-pattern"

    def test_consistent_policy_is_sat(self, tmp_path) -> None:
        d = _new_daemon(tmp_path)
        d.dispatch({"op": "declare_x402", "kind": "max_per_call", "max_amount": "50"})
        d.dispatch(
            {"op": "declare_x402", "kind": "provider_allowlist",
             "providers": ["anthropic", "openai"]}
        )
        r = d.dispatch({"op": "explain_policy"})
        assert r["verdict"] == "sat"
        assert r["proof_token"]["proof_strength"] == "pattern"

    def test_contradictory_active_policy_is_unsat(self, tmp_path) -> None:
        """Two ProviderAllowlists whose intersection is empty: multi-rule UNSAT.

        We can't introduce a contradictory invariant via declare (that path
        rejects at declare-time), so we poke the registry directly -- the
        ``explain_policy`` op must still surface the contradiction.
        """
        from adapter.invariants import ProviderAllowlist
        from adapter.x402_registry import X402Registry
        d = _new_daemon(tmp_path)
        bad_reg = X402Registry.empty()
        bad_reg = bad_reg.declare(ProviderAllowlist(providers=frozenset({"anthropic"})))
        bad_reg = bad_reg.declare(ProviderAllowlist(providers=frozenset({"openai"})))
        d._x402_registry = bad_reg

        r = d.dispatch({"op": "explain_policy"})
        assert r["verdict"] == "unsat"
        assert r["report"] is not None
        assert "empty" in r["report"]["unsat_explanation"].lower() or "disjoint" in r["report"]["unsat_explanation"].lower()
        assert r["proof_token"] is None


# ── explain_policy: candidate mode ───────────────────────────────────────────


class TestExplainCandidate:
    def test_candidate_does_not_affect_active_registry(self, tmp_path) -> None:
        d = _new_daemon(tmp_path)
        d.dispatch({"op": "declare_x402", "kind": "max_per_call", "max_amount": "10"})
        before = d.dispatch({"op": "inspect_policy"})
        r = d.dispatch({
            "op": "explain_policy",
            "invariants": [
                {"kind": "max_per_call", "max_amount": "999"},
                {"kind": "provider_allowlist", "providers": ["zzz"]},
            ],
        })
        assert r["verdict"] == "sat"
        after = d.dispatch({"op": "inspect_policy"})
        # Live registry untouched
        assert before["active_revision_id"] == after["active_revision_id"]
        assert before["active_invariants"] == after["active_invariants"]

    def test_candidate_contradiction_reports_unsat(self, tmp_path) -> None:
        r = _new_daemon(tmp_path).dispatch({
            "op": "explain_policy",
            "invariants": [
                {"kind": "counterparty_constraint",
                 "approved_ids": ["vendor_a"], "sanctioned_ids": []},
                {"kind": "counterparty_constraint",
                 "approved_ids": [], "sanctioned_ids": ["vendor_a"]},
            ],
        })
        assert r["verdict"] == "unsat"
        assert r["report"]["kind"] == "contradiction"
        # Repair hint for sanctioned/approved clash
        assert r["report"]["suggested_repair"]

    def test_candidate_empty_list_is_sat(self, tmp_path) -> None:
        r = _new_daemon(tmp_path).dispatch({
            "op": "explain_policy",
            "invariants": [],
        })
        assert r["verdict"] == "sat"

    def test_candidate_rejects_non_list(self, tmp_path) -> None:
        r = _new_daemon(tmp_path).dispatch({
            "op": "explain_policy",
            "invariants": "not a list",
        })
        assert r["verdict"] == "error"
        assert r["category"] == "bad_invariants"

    def test_candidate_rejects_unknown_kind(self, tmp_path) -> None:
        r = _new_daemon(tmp_path).dispatch({
            "op": "explain_policy",
            "invariants": [{"kind": "nonexistent", "x": 1}],
        })
        assert r["verdict"] == "error"
        assert r["category"] == "bad_invariants"

    def test_candidate_rejects_non_mapping_entry(self, tmp_path) -> None:
        r = _new_daemon(tmp_path).dispatch({
            "op": "explain_policy",
            "invariants": [42],
        })
        assert r["verdict"] == "error"
        assert r["category"] == "bad_invariants"


# ── explain_policy: strict-mode + inconclusive Tau ───────────────────────────


class TestExplainStrictInconclusive:
    def test_strict_mode_tau_inconclusive_returns_inconclusive(self, tmp_path) -> None:
        d = _new_daemon(
            tmp_path, mode="strict", tau_prover=_InconclusiveTauProver(),
        )
        r = d.dispatch({
            "op": "explain_policy",
            "invariants": [{"kind": "max_per_call", "max_amount": "50"}],
        })
        assert r["verdict"] == "inconclusive"
        assert r["report"]["category"] == "timeout"
        assert r["proof_token"] is None

    def test_verified_mode_tau_inconclusive_still_admits(self, tmp_path) -> None:
        d = _new_daemon(
            tmp_path, mode="verified", tau_prover=_InconclusiveTauProver(),
        )
        r = d.dispatch({
            "op": "explain_policy",
            "invariants": [{"kind": "max_per_call", "max_amount": "50"}],
        })
        assert r["verdict"] == "sat"
        # Verified mode still surfaces the Tau inconclusive report
        assert r["report"] is not None
        assert r["report"]["category"] == "timeout"
        assert "tau-timeout" in r["proof_token"]["proof_strength"]

    def test_strict_mode_tau_sat_stamps_complete(self, tmp_path) -> None:
        d = _new_daemon(tmp_path, mode="strict", tau_prover=_SatTauProver())
        r = d.dispatch({
            "op": "explain_policy",
            "invariants": [{"kind": "max_per_call", "max_amount": "50"}],
        })
        assert r["verdict"] == "sat"
        assert r["proof_token"]["proof_strength"] == "complete"
        assert r["proof_token"]["prover_mode"] == "strict"


# ── inspect_policy post-Tau-SAT ──────────────────────────────────────────────


class TestInspectAfterTauAdmit:
    def test_inspect_surfaces_tau_provenance(self, tmp_path) -> None:
        d = _new_daemon(tmp_path, mode="strict", tau_prover=_SatTauProver())
        d.dispatch({"op": "declare_x402", "kind": "max_per_call", "max_amount": "50"})
        r = d.dispatch({"op": "inspect_policy"})
        assert r["proof_backend"] == "tau"
        assert r["proof_strength"] == "complete"
        assert r["fragment_version"] == "v1"
        assert r["compile_hash"]
