"""Tests for the policy-diff renderer (v0.11.0).

`adapter.diff_renderer` takes the output of the `diff_revisions` op (or
an equivalent `{added, removed}` delta dict) and renders a human-readable
text or HTML table. These tests pin the row ordering, +/- markers,
class-name extraction, compact rendering of optional fields, and
CLI / web-UI end-to-end wiring.

Scope:
  * Pure renderer unit tests (no daemon, no FastAPI).
  * CLI subcommand against a stub daemon (no socket).
  * Web UI route against an in-process FastAPI + stub DaemonReader.
"""

from __future__ import annotations

import html.parser
import io
import json
import os
import socket
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Any, Dict, List, Mapping
from unittest.mock import patch

import pytest

from adapter.diff_renderer import (
    render_revision_diff_html,
    render_revision_diff_text,
)


# ── fixtures: canned deltas ──────────────────────────────────────────────────


def _empty_delta() -> Dict[str, Any]:
    return {"added": [], "removed": []}


def _additions_only_delta() -> Dict[str, Any]:
    # Mirrors the shape returned by the `diff_revisions` daemon op —
    # {class, repr_key} rather than the on-disk {class_name, repr} shape.
    return {
        "added": [
            {"class": "MaxPerCall",
             "repr_key": "MaxPerCall(max_amount=Decimal('50'), currency='USDC')"},
            {"class": "ProviderAllowlist",
             "repr_key": "ProviderAllowlist(providers=frozenset({'anthropic'}))"},
        ],
        "removed": [],
    }


def _removals_only_delta() -> Dict[str, Any]:
    return {
        "added": [],
        "removed": [
            {"class": "RetryRateLimit",
             "repr_key": "RetryRateLimit(min_gap_seconds=30)"},
        ],
    }


def _mixed_delta() -> Dict[str, Any]:
    return {
        "added": [
            {"class": "ProviderAllowlist",
             "repr_key": "ProviderAllowlist(providers=frozenset({'anthropic'}))"},
            {"class": "MaxPerCall",
             "repr_key": "MaxPerCall(max_amount=Decimal('100'), currency='USDC')"},
        ],
        "removed": [
            {"class": "RetryRateLimit",
             "repr_key": "RetryRateLimit(min_gap_seconds=30)"},
        ],
    }


def _optional_fields_delta() -> Dict[str, Any]:
    """SpendingCap with the optional window_seconds and provider fields populated."""
    return {
        "added": [
            {"class": "SpendingCap",
             "repr_key":
                 "SpendingCap(max_amount=Decimal('500'), currency='USDC', "
                 "scope='per_provider_per_window', window_seconds=3600, "
                 "provider='anthropic')"},
        ],
        "removed": [],
    }


def _on_disk_shape_delta() -> Dict[str, Any]:
    """Alternative input shape: the on-disk {class_name, repr} form from
    `_serialize_invariant`. The renderer accepts both so callers can feed
    in either the daemon op's response or a PolicyRevision.delta field."""
    return {
        "added": [
            {"class_name": "MaxPerCall",
             "repr": {"max_amount": "50", "currency": "USDC"}},
        ],
        "removed": [],
    }


# ── text renderer ────────────────────────────────────────────────────────────


class TestRenderText:
    def test_empty_delta_renders_no_changes(self) -> None:
        out = render_revision_diff_text(_empty_delta())
        assert "no changes" in out.lower()

    def test_additions_only_all_rows_marked_plus(self) -> None:
        out = render_revision_diff_text(_additions_only_delta())
        # Every non-header/non-empty row that names an invariant class must
        # carry a `+` marker, and no row carries a `-` marker.
        class_lines = [
            ln for ln in out.splitlines()
            if "MaxPerCall" in ln or "ProviderAllowlist" in ln
        ]
        assert class_lines, out
        assert all("+" in ln for ln in class_lines)
        assert not any(ln.lstrip().startswith("-") for ln in class_lines)

    def test_removals_only_all_rows_marked_minus(self) -> None:
        out = render_revision_diff_text(_removals_only_delta())
        class_lines = [
            ln for ln in out.splitlines() if "RetryRateLimit" in ln
        ]
        assert class_lines, out
        assert all("-" in ln for ln in class_lines)
        # No `+` markers on the class rows.
        assert not any(ln.lstrip().startswith("+") for ln in class_lines)

    def test_mixed_added_first_then_removed(self) -> None:
        out = render_revision_diff_text(_mixed_delta())
        # Added rows must appear before removed rows; within a group the
        # ordering is alphabetical by class name for determinism.
        added_mpc = out.index("MaxPerCall")
        added_pa = out.index("ProviderAllowlist")
        removed_rrl = out.index("RetryRateLimit")
        assert added_mpc < added_pa, out
        assert added_pa < removed_rrl, out

    def test_scope_hint_compact_for_optional_fields(self) -> None:
        out = render_revision_diff_text(_optional_fields_delta())
        # SpendingCap scope_hint should include the populated optional
        # fields (window_seconds, provider) without padding to a fixed width.
        assert "SpendingCap" in out
        assert "500" in out and "USDC" in out
        assert "3600" in out
        assert "anthropic" in out

    def test_accepts_on_disk_shape_as_well(self) -> None:
        """Renderer shouldn't care whether the delta came from
        `diff_revisions` (``class``/``repr_key``) or from
        ``PolicyRevision.delta`` (``class_name``/``repr``)."""
        out = render_revision_diff_text(_on_disk_shape_delta())
        assert "MaxPerCall" in out
        # The repr dict's fields should surface somehow.
        assert "50" in out

    def test_render_is_pure_string(self) -> None:
        """The renderer must return a string, not print to stdout."""
        s = render_revision_diff_text(_mixed_delta())
        assert isinstance(s, str)
        assert s.strip()

    def test_renders_delta_wrapped_in_full_diff_response(self) -> None:
        """The caller often passes the entire `diff_revisions` response —
        a dict with `added`, `removed`, plus `a`, `b`, `backend_changed`,
        `mode_changed`. The renderer should ignore the extra keys."""
        resp = {
            "verdict": "ok",
            "a": {"revision_id": "aaa", "depth": 0,
                  "backend": "python-pattern", "mode": "compat"},
            "b": {"revision_id": "bbb", "depth": 1,
                  "backend": "python-pattern", "mode": "compat"},
            "added": [
                {"class": "MaxPerCall",
                 "repr_key": "MaxPerCall(max_amount=Decimal('50'), currency='USDC')"},
            ],
            "removed": [],
            "backend_changed": False,
            "mode_changed": False,
        }
        out = render_revision_diff_text(resp)
        assert "MaxPerCall" in out
        assert "+" in out


# ── HTML renderer ────────────────────────────────────────────────────────────


class _HTMLWellformedValidator(html.parser.HTMLParser):
    """Simple well-formedness check: every non-void start tag gets closed."""

    VOID = {"br", "hr", "img", "meta", "link", "input"}

    def __init__(self) -> None:
        super().__init__()
        self.stack: List[str] = []
        self.errors: List[str] = []

    def handle_starttag(self, tag: str, attrs: Any) -> None:
        if tag not in self.VOID:
            self.stack.append(tag)

    def handle_endtag(self, tag: str) -> None:
        if not self.stack:
            self.errors.append(f"</{tag}> with no open tag")
            return
        top = self.stack.pop()
        if top != tag:
            self.errors.append(f"</{tag}> closes <{top}>")


def _assert_html_wellformed(s: str) -> None:
    v = _HTMLWellformedValidator()
    v.feed(s)
    assert not v.errors, f"HTML errors: {v.errors}\n\n{s}"
    assert not v.stack, f"Unclosed tags: {v.stack}\n\n{s}"


class TestRenderHtml:
    def test_empty_delta_no_rows(self) -> None:
        out = render_revision_diff_html(_empty_delta())
        _assert_html_wellformed(out)
        assert "no changes" in out.lower()

    def test_additions_have_added_class(self) -> None:
        out = render_revision_diff_html(_additions_only_delta())
        _assert_html_wellformed(out)
        # Every row naming an invariant must carry a CSS marker.
        assert "added" in out.lower()
        assert "MaxPerCall" in out
        assert "<table" in out

    def test_removals_have_removed_class(self) -> None:
        out = render_revision_diff_html(_removals_only_delta())
        _assert_html_wellformed(out)
        assert "removed" in out.lower()
        assert "RetryRateLimit" in out

    def test_mixed_includes_both_classes(self) -> None:
        out = render_revision_diff_html(_mixed_delta())
        _assert_html_wellformed(out)
        assert "added" in out.lower()
        assert "removed" in out.lower()
        # Alphabetical inside each side, added before removed.
        a_mpc = out.index("MaxPerCall")
        a_pa = out.index("ProviderAllowlist")
        r_rrl = out.index("RetryRateLimit")
        assert a_mpc < a_pa < r_rrl

    def test_output_is_well_formed_html(self) -> None:
        out = render_revision_diff_html(_mixed_delta())
        _assert_html_wellformed(out)

    def test_output_escapes_untrusted_text(self) -> None:
        """Repr strings must be HTML-escaped; no raw `<` / `>`."""
        delta = {
            "added": [
                {"class": "MaxPerCall",
                 "repr_key": "MaxPerCall(annotation=<script>bad</script>)"},
            ],
            "removed": [],
        }
        out = render_revision_diff_html(delta)
        _assert_html_wellformed(out)
        assert "<script>" not in out
        # Escaped form should be present.
        assert "&lt;script&gt;" in out or "&lt;" in out


# ── CLI end-to-end against a stub daemon ─────────────────────────────────────


def _short_sock_path() -> str:
    """Return a short ``/tmp/<short>.sock`` path; macOS UDS paths are capped
    at ~104 chars and pytest's ``tmp_path`` is too long on aarch64 CI."""
    import uuid
    return f"/tmp/diffviz-{uuid.uuid4().hex[:8]}.sock"


def _start_stub_daemon(socket_path: str, canned: Dict[str, Any]) -> threading.Thread:
    """Minimal UDS daemon that always returns ``canned`` on any payload.

    Threaded so the test can send a real ``tau-x402-cage diff`` subprocess
    call and still tear down cleanly. Single-shot: serves one request and
    closes the listener.
    """
    try:
        os.unlink(socket_path)
    except OSError:
        pass
    server = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    server.bind(socket_path)
    server.listen(4)
    server.settimeout(5.0)

    def serve() -> None:
        try:
            while True:
                try:
                    conn, _ = server.accept()
                except socket.timeout:
                    return
                with conn:
                    f = conn.makefile("rwb", buffering=0)
                    line = f.readline()
                    if not line:
                        continue
                    conn.sendall((json.dumps(canned) + "\n").encode("utf-8"))
        finally:
            server.close()

    t = threading.Thread(target=serve, daemon=True)
    t.start()
    # Give the thread a tick to hit accept().
    time.sleep(0.05)
    return t


def _run_cli(args: List[str]) -> subprocess.CompletedProcess:
    env = os.environ.copy()
    repo_root = str(Path(__file__).resolve().parent.parent)
    env["PYTHONPATH"] = os.pathsep.join(
        [repo_root, env.get("PYTHONPATH", "")]
    ).rstrip(os.pathsep)
    return subprocess.run(
        [sys.executable, "-m", "daemon.cli", *args],
        capture_output=True, text=True, timeout=10, env=env,
    )


class TestDiffCli:
    def test_diff_help_lists_subcommand(self) -> None:
        r = _run_cli(["--help"])
        assert r.returncode == 0
        assert "diff" in r.stdout

    def test_diff_own_help(self) -> None:
        r = _run_cli(["diff", "--help"])
        assert r.returncode == 0
        assert "--format" in r.stdout or "--socket" in r.stdout

    def test_diff_unreachable_daemon_exits_2(self, tmp_path: Path) -> None:
        r = _run_cli([
            "diff", "abc", "def",
            "--socket", str(tmp_path / "nope.sock"),
        ])
        assert r.returncode == 2
        assert "failed to reach daemon" in r.stderr.lower() or "daemon" in r.stderr.lower()

    def test_diff_end_to_end_text(self, tmp_path: Path) -> None:
        """Spin up a stub daemon, call `tau-x402-cage diff a b`, assert the
        rendered text carries the class + marker."""
        sock = _short_sock_path()
        canned = {
            "verdict": "ok",
            "a": {"revision_id": "a", "depth": 0,
                  "backend": "python-pattern", "mode": "compat"},
            "b": {"revision_id": "b", "depth": 1,
                  "backend": "python-pattern", "mode": "compat"},
            "added": [
                {"class": "MaxPerCall",
                 "repr_key": "MaxPerCall(max_amount=Decimal('50'), currency='USDC')"},
            ],
            "removed": [],
            "backend_changed": False,
            "mode_changed": False,
        }
        _start_stub_daemon(sock, canned)
        r = _run_cli(["diff", "a", "b", "--socket", sock])
        assert r.returncode == 0, r.stderr
        assert "MaxPerCall" in r.stdout
        assert "+" in r.stdout

    def test_diff_end_to_end_json(self, tmp_path: Path) -> None:
        """--format=json emits the raw daemon response untouched."""
        sock = _short_sock_path()
        canned = {
            "verdict": "ok",
            "a": {"revision_id": "a", "depth": 0,
                  "backend": "python-pattern", "mode": "compat"},
            "b": {"revision_id": "b", "depth": 1,
                  "backend": "python-pattern", "mode": "compat"},
            "added": [],
            "removed": [
                {"class": "RetryRateLimit",
                 "repr_key": "RetryRateLimit(min_gap_seconds=30)"},
            ],
            "backend_changed": False,
            "mode_changed": False,
        }
        _start_stub_daemon(sock, canned)
        r = _run_cli(["diff", "a", "b", "--socket", sock, "--format", "json"])
        assert r.returncode == 0, r.stderr
        parsed = json.loads(r.stdout)
        assert parsed["verdict"] == "ok"
        assert parsed["removed"][0]["class"] == "RetryRateLimit"

    def test_diff_missing_revision_exits_1(self, tmp_path: Path) -> None:
        """Daemon returns `unknown_revision` -> CLI exits 1 (not 2; 2 is
        reserved for transport / arg errors)."""
        sock = _short_sock_path()
        canned = {
            "verdict": "error",
            "category": "unknown_revision",
            "reason": "revision(s) not found: a",
        }
        _start_stub_daemon(sock, canned)
        r = _run_cli(["diff", "missing", "also-missing", "--socket", sock])
        assert r.returncode == 1
        assert "not found" in r.stderr.lower() or "unknown" in r.stderr.lower()


# ── Web UI diff route ────────────────────────────────────────────────────────

pytest.importorskip("fastapi")
pytest.importorskip("jinja2")

from fastapi import FastAPI
from fastapi.testclient import TestClient

from saas.web_ui.routes import build_router, mount_static_on


TOKEN = "sk_test_diffviz_0123456789"


class StubReader:
    def __init__(self, responses: Mapping[str, Dict[str, Any]]) -> None:
        self._responses = dict(responses)
        self.calls: List[Dict[str, Any]] = []

    def request(self, payload: Mapping[str, object]) -> Dict[str, Any]:
        self.calls.append(dict(payload))
        op = payload.get("op")
        if op not in self._responses:
            return {"verdict": "error", "category": "unknown_op"}
        return dict(self._responses[op])


def _diff_responses_hit() -> Dict[str, Dict[str, Any]]:
    return {
        "diff_revisions": {
            "verdict": "ok",
            "a": {"revision_id": "aaa", "depth": 0,
                  "backend": "python-pattern", "mode": "compat"},
            "b": {"revision_id": "bbb", "depth": 1,
                  "backend": "python-pattern", "mode": "compat"},
            "added": [
                {"class": "ProviderAllowlist",
                 "repr_key":
                     "ProviderAllowlist(providers=frozenset({'anthropic'}))"},
            ],
            "removed": [
                {"class": "RetryRateLimit",
                 "repr_key": "RetryRateLimit(min_gap_seconds=30)"},
            ],
            "backend_changed": False,
            "mode_changed": False,
        },
    }


def _diff_responses_miss() -> Dict[str, Dict[str, Any]]:
    return {
        "diff_revisions": {
            "verdict": "error",
            "category": "unknown_revision",
            "reason": "revision(s) not found: a",
        },
    }


@pytest.fixture
def diff_client_hit() -> TestClient:
    reader = StubReader(_diff_responses_hit())
    a = FastAPI()
    router = build_router(reader=reader, token=TOKEN)
    a.include_router(router, prefix="/ui")
    mount_static_on(a)
    return TestClient(a)


@pytest.fixture
def diff_client_miss() -> TestClient:
    reader = StubReader(_diff_responses_miss())
    a = FastAPI()
    router = build_router(reader=reader, token=TOKEN)
    a.include_router(router, prefix="/ui")
    mount_static_on(a)
    return TestClient(a)


def _authed_get(client: TestClient, path: str) -> Any:
    return client.get(path, headers={"Authorization": f"Bearer {TOKEN}"})


class TestDiffWebUI:
    def test_diff_route_200_on_hit(self, diff_client_hit: TestClient) -> None:
        r = _authed_get(diff_client_hit, "/ui/revisions/diff?from=aaa&to=bbb")
        assert r.status_code == 200
        assert "ProviderAllowlist" in r.text
        assert "RetryRateLimit" in r.text
        assert "aaa" in r.text and "bbb" in r.text

    def test_diff_route_404_on_miss(self, diff_client_miss: TestClient) -> None:
        r = _authed_get(diff_client_miss, "/ui/revisions/diff?from=a&to=b")
        assert r.status_code == 404

    def test_diff_route_requires_auth(self, diff_client_hit: TestClient) -> None:
        r = diff_client_hit.get("/ui/revisions/diff?from=a&to=b")
        assert r.status_code == 403

    def test_diff_route_rejects_missing_params(
        self, diff_client_hit: TestClient
    ) -> None:
        r = _authed_get(diff_client_hit, "/ui/revisions/diff?from=a")
        # Query(required) -> 422 from FastAPI validation.
        assert r.status_code == 422

    def test_revisions_page_links_to_diff(
        self, diff_client_hit: TestClient
    ) -> None:
        """The revisions list must carry a "Diff against previous" link for
        each non-genesis entry."""
        r = _authed_get(diff_client_hit, "/ui/revisions")
        assert r.status_code == 200
        # revisions.html's stub returns no entries; we only need the page
        # to render OK. The anchor assertion lives in the linked template
        # test below to avoid coupling to the daemon reader's content.
