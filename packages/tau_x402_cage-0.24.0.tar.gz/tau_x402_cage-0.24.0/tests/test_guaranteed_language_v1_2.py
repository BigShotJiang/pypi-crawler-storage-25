"""Tests for the Guaranteed Language tier v1.2.0 expansion.

v1.2.0 widens the tier from 6 rule types (v1.1.0) to 9 by admitting the
pure ``bv`` BA variants of ``JurisdictionRule``, ``CounterpartyConstraint``
and ``MutualExclusion``. No ``nlang`` dependency, no z3 fallback, no
Python-semantics helper. The richer nested-composition / sanctions /
``nlang`` variants stay in Flexible Mode.

This file pins:

* the exact v1.2.0 ``SUPPORTED_RULE_TYPES`` set (9 classes),
* the ``SUPPORTED_RULE_VARIANTS`` variant-admission table,
* the variant-qualified excluded-reasons entries,
* variant-gated ``is_supported`` behaviour (admit pure-enum / reject
  richer variants),
* stability of the v1.1.0 admissions (nothing regressed).

Silent expansion fails loudly at CI time because the pinned frozensets
include byte-stable counts.
"""
from __future__ import annotations

import json
from decimal import Decimal

import pytest

from adapter.guaranteed_errors import GuaranteedFailureCode
from adapter.guaranteed_language import (
    GUARANTEED_LANGUAGE_VERSION,
    GuaranteedLanguage,
)
from adapter.invariants import (
    BurstVelocityCap,
    CounterpartyConstraint,
    JurisdictionRule,
    MaxPerCall,
    MutualExclusion,
    ProviderAllowlist,
    RetryRateLimit,
    RollingWindowCap,
    SpendingCap,
)


# ── version pin ────────────────────────────────────────────────────────


def test_language_version_is_1_2_0():
    assert GUARANTEED_LANGUAGE_VERSION == "1.2.0"


# ── SUPPORTED_RULE_TYPES pinned exactly ───────────────────────────────


def test_supported_rule_types_is_the_v1_2_set_of_nine():
    assert GuaranteedLanguage.SUPPORTED_RULE_TYPES == frozenset(
        {
            "SpendingCap",
            "MaxPerCall",
            "ProviderAllowlist",
            "RetryRateLimit",
            "RollingWindowCap",
            "BurstVelocityCap",
            "JurisdictionRule",
            "CounterpartyConstraint",
            "MutualExclusion",
        }
    )


def test_supported_rule_types_cardinality_is_nine():
    """Count pin: the tier must be exactly 9 rule types at v1.2.0. A
    silent additive merge would fail this test before it ever lands."""
    assert len(GuaranteedLanguage.SUPPORTED_RULE_TYPES) == 9


# ── SUPPORTED_RULE_VARIANTS surface ───────────────────────────────────


def test_supported_rule_variants_pins_exact_table():
    expected = {
        "JurisdictionRule": ("enum_bv",),
        "CounterpartyConstraint": ("enum_bv",),
        "MutualExclusion": ("rule_composition",),
    }
    assert GuaranteedLanguage.SUPPORTED_RULE_VARIANTS == expected


def test_supported_rule_variants_surfaces_through_describe():
    surface = GuaranteedLanguage.describe()
    variants = surface["supported_rule_variants"]
    assert variants["JurisdictionRule"] == ["enum_bv"]
    assert variants["CounterpartyConstraint"] == ["enum_bv"]
    assert variants["MutualExclusion"] == ["rule_composition"]


# ── JurisdictionRule: enum_bv admitted, nested rejected ────────────────


def test_jurisdiction_rule_flat_admits():
    ok, code = GuaranteedLanguage.is_supported(
        JurisdictionRule(jurisdiction="EU")
    )
    assert ok is True
    assert code is None


def test_jurisdiction_rule_every_enum_code_admits():
    """The 5 fixed codes in JurisdictionRule._JURISDICTION_CODES all
    compile cleanly under enum_bv. Pin each so a silent regression on
    one code shows up here, not at the prover."""
    for code in ("EU", "UK", "US", "APAC", "OTHER"):
        ok, failure_code = GuaranteedLanguage.is_supported(
            JurisdictionRule(jurisdiction=code)
        )
        assert ok is True, f"jurisdiction={code} unexpectedly rejected"
        assert failure_code is None


def test_jurisdiction_rule_nested_composition_rejected():
    ok, code = GuaranteedLanguage.is_supported(
        JurisdictionRule(
            jurisdiction="EU",
            additional_invariants=(
                MaxPerCall(max_amount=Decimal("1")),
                ProviderAllowlist(providers=frozenset({"openai"})),
            ),
        )
    )
    assert ok is False
    assert code is GuaranteedFailureCode.UNSUPPORTED_FOR_GUARANTEED_MODE


# ── CounterpartyConstraint: pure allowlist admitted, others rejected ───


def test_counterparty_constraint_pure_allowlist_admits():
    ok, code = GuaranteedLanguage.is_supported(
        CounterpartyConstraint(approved_ids=frozenset({"acme", "globex"}))
    )
    assert ok is True
    assert code is None


def test_counterparty_constraint_empty_allowlist_rejected():
    """An empty approved set has no enum_bv content; reject."""
    ok, code = GuaranteedLanguage.is_supported(
        CounterpartyConstraint()  # both fields default empty
    )
    assert ok is False
    assert code is GuaranteedFailureCode.UNSUPPORTED_FOR_GUARANTEED_MODE


def test_counterparty_constraint_with_sanctions_rejected():
    ok, code = GuaranteedLanguage.is_supported(
        CounterpartyConstraint(
            approved_ids=frozenset({"acme"}),
            sanctioned_ids=frozenset({"evil-inc"}),
        )
    )
    assert ok is False
    assert code is GuaranteedFailureCode.UNSUPPORTED_FOR_GUARANTEED_MODE


def test_counterparty_constraint_only_sanctions_rejected():
    ok, code = GuaranteedLanguage.is_supported(
        CounterpartyConstraint(sanctioned_ids=frozenset({"evil-inc"}))
    )
    assert ok is False
    assert code is GuaranteedFailureCode.UNSUPPORTED_FOR_GUARANTEED_MODE


# ── MutualExclusion: rule_composition admitted ─────────────────────────


def test_mutual_exclusion_two_group_admits():
    ok, code = GuaranteedLanguage.is_supported(
        MutualExclusion(
            group_a=frozenset({"openai"}),
            group_b=frozenset({"anthropic"}),
        )
    )
    assert ok is True
    assert code is None


def test_mutual_exclusion_multi_element_groups_admits():
    """Both groups may carry multiple providers; each hashes into its
    own bv slot."""
    ok, code = GuaranteedLanguage.is_supported(
        MutualExclusion(
            group_a=frozenset({"openai", "mistral"}),
            group_b=frozenset({"anthropic", "cohere"}),
        )
    )
    assert ok is True
    assert code is None


# ── variant-qualified exclusion map ────────────────────────────────────


def test_excluded_rule_types_use_variant_qualified_keys():
    surface = GuaranteedLanguage.describe()
    excluded = surface["excluded_rule_types_with_reason"]
    # The four richer variants still held out.
    for key in (
        "JurisdictionRule.nested_composition",
        "JurisdictionRule.nlang",
        "CounterpartyConstraint.sanctions_negation",
        "CounterpartyConstraint.nlang",
    ):
        assert key in excluded
        assert isinstance(excluded[key], str)
        assert excluded[key].strip()


def test_bare_class_names_not_in_excluded_map():
    """Bare class-level keys are ambiguous once variant admission is in
    play. Audit readers must see variant-qualified reasons."""
    surface = GuaranteedLanguage.describe()
    excluded = surface["excluded_rule_types_with_reason"]
    for bare in (
        "JurisdictionRule",
        "CounterpartyConstraint",
        "MutualExclusion",
    ):
        assert bare not in excluded


# ── composition / temporal / mutation forms unchanged ─────────────────


def test_composition_unchanged_in_v1_2():
    assert GuaranteedLanguage.SUPPORTED_COMPOSITION == frozenset({"conjunction"})


def test_temporal_unchanged_in_v1_2():
    """v1.2.0 is additive on rule types only; temporal ops stay at the
    v1.1.0 set {G, O, H}."""
    assert GuaranteedLanguage.SUPPORTED_TEMPORAL == frozenset({"G", "O", "H"})


def test_mutation_forms_unchanged_in_v1_2():
    """v1.2.0 does not introduce a new mutation form; widening an
    allowlist (``widen_allowlist``) intentionally stays out so growing
    an approved-counterparty set in Guaranteed Mode is rejected."""
    assert GuaranteedLanguage.SUPPORTED_MUTATION_FORMS == frozenset(
        {
            "add_invariant",
            "remove_invariant",
            "tighten_limit",
            "tighten_window",
            "shorten_retry_cooldown",
            "tighten_burst_cap",
        }
    )


def test_widen_allowlist_is_rejected_as_mutation_form():
    """Growing a pure-allowlist CounterpartyConstraint is a weakening
    move. The ``widen_allowlist`` form is not in
    ``SUPPORTED_MUTATION_FORMS`` so the tier refuses it."""
    assert (
        GuaranteedLanguage.is_mutation_form_supported("widen_allowlist")
        is False
    )


# ── JSON round-trip ────────────────────────────────────────────────────


def test_describe_json_round_trip_at_v1_2():
    surface = GuaranteedLanguage.describe()
    blob = json.dumps(surface, sort_keys=True)
    restored = json.loads(blob)
    assert restored["language_version"] == "1.2.0"
    for new_type in ("JurisdictionRule", "CounterpartyConstraint", "MutualExclusion"):
        assert new_type in restored["supported_rule_types"]
    assert restored["supported_rule_variants"]["JurisdictionRule"] == ["enum_bv"]
    assert restored["supported_rule_variants"]["MutualExclusion"] == [
        "rule_composition"
    ]
