"""Tests for the v0.12.0 per-tenant rate limiter + monthly quotas.

Structured by backend and surface:

* ``TestInMemoryRateLimiter`` — algorithm correctness (burst, refill,
  quota rollover, overrides).
* ``TestRedisRateLimiter`` — same semantics under ``fakeredis``, plus
  concurrent-access atomicity.
* ``TestFactory`` — env-var wiring, preflight, override parsing.
* ``TestSaasMiddleware`` — end-to-end against the FastAPI app (429 on
  ceiling, 429 on quota exhaustion, headers emitted on every response).

All tests skip gracefully when the optional deps are missing.
"""
from __future__ import annotations

import itertools
import json
import threading
import time
from typing import Iterator, List

import pytest

fakeredis = pytest.importorskip("fakeredis")

from saas.rate_limit import (  # noqa: E402
    AcquireResult,
    InMemoryRateLimiter,
    QuotaStatus,
    RateLimitConfig,
    RateLimitError,
    RedisRateLimiter,
    _month_key,
    _month_reset_at,
    _parse_overrides,
    build_rate_limiter,
)


# ── helpers ──────────────────────────────────────────────────────────────────


class FrozenClock:
    """Mutable clock the tests advance by hand.

    Using a mutable object rather than ``monkeypatch.setattr(time, ...)``
    keeps the test state explicit and lets us inject the same clock into
    both backends.
    """

    def __init__(self, start: float) -> None:
        self._now = float(start)

    def __call__(self) -> float:
        return self._now

    def advance(self, seconds: float) -> None:
        self._now += float(seconds)


def _make_fakeredis():
    """Return a decode_responses=True fake Redis client."""
    return fakeredis.FakeStrictRedis(decode_responses=True)


DEFAULT_CFG = RateLimitConfig(qps=10.0, burst=20, monthly_quota=1000)


# ── RateLimitConfig ──────────────────────────────────────────────────────────


class TestRateLimitConfig:
    def test_rejects_non_positive_qps(self) -> None:
        with pytest.raises(ValueError):
            RateLimitConfig(qps=0.0, burst=1, monthly_quota=1)

    def test_rejects_non_positive_burst(self) -> None:
        with pytest.raises(ValueError):
            RateLimitConfig(qps=1.0, burst=0, monthly_quota=1)

    def test_rejects_negative_quota(self) -> None:
        with pytest.raises(ValueError):
            RateLimitConfig(qps=1.0, burst=1, monthly_quota=-1)

    def test_frozen(self) -> None:
        cfg = RateLimitConfig(qps=1.0, burst=1, monthly_quota=1)
        with pytest.raises(Exception):
            cfg.qps = 2.0  # type: ignore[misc]


# ── in-memory token bucket ───────────────────────────────────────────────────


class TestInMemoryRateLimiter:
    def test_allows_up_to_burst_then_rejects(self) -> None:
        clock = FrozenClock(1_700_000_000)
        rl = InMemoryRateLimiter(DEFAULT_CFG, clock=clock)

        permits: List[bool] = []
        for _ in range(DEFAULT_CFG.burst):
            permits.append(rl.try_acquire("t").allowed)
        # All 20 of the burst tokens should be consumable without waiting.
        assert all(permits)

        # 21st call — bucket is empty.
        after_burst = rl.try_acquire("t")
        assert after_burst.allowed is False
        assert after_burst.reason == "qps"
        assert after_burst.retry_after_s > 0
        assert after_burst.remaining == 0

    def test_refills_at_qps_rate(self) -> None:
        clock = FrozenClock(1_700_000_000)
        rl = InMemoryRateLimiter(DEFAULT_CFG, clock=clock)

        for _ in range(DEFAULT_CFG.burst):
            rl.try_acquire("t")
        assert rl.try_acquire("t").allowed is False

        # After 0.5s at 10 qps, 5 tokens should have accrued.
        clock.advance(0.5)
        permitted = sum(1 for _ in range(10) if rl.try_acquire("t").allowed)
        assert permitted == 5

    def test_monthly_quota_blocks_even_with_tokens(self) -> None:
        clock = FrozenClock(1_700_000_000)
        cfg = RateLimitConfig(qps=1000.0, burst=1000, monthly_quota=3)
        rl = InMemoryRateLimiter(cfg, clock=clock)

        assert rl.try_acquire("t").allowed
        assert rl.try_acquire("t").allowed
        assert rl.try_acquire("t").allowed
        blocked = rl.try_acquire("t")
        assert not blocked.allowed
        assert blocked.reason == "quota"
        assert blocked.quota_remaining == 0

    def test_monthly_quota_rolls_over(self) -> None:
        # Start mid-month, burn the whole quota, then advance past the
        # month boundary and assert the counter reset.
        clock = FrozenClock(_month_reset_at(1_700_000_000) - 3600)  # 1h before rollover
        cfg = RateLimitConfig(qps=1000.0, burst=1000, monthly_quota=2)
        rl = InMemoryRateLimiter(cfg, clock=clock)

        assert rl.try_acquire("t").allowed
        assert rl.try_acquire("t").allowed
        assert not rl.try_acquire("t").allowed  # exhausted

        clock.advance(3700)  # tick past rollover
        result = rl.try_acquire("t")
        assert result.allowed
        assert result.quota_remaining == cfg.monthly_quota - 1

    def test_per_tenant_overrides_applied(self) -> None:
        clock = FrozenClock(1_700_000_000)
        overrides = {"acme": RateLimitConfig(qps=1.0, burst=2, monthly_quota=100)}
        rl = InMemoryRateLimiter(DEFAULT_CFG, overrides=overrides, clock=clock)

        # acme only gets 2 burst tokens.
        assert rl.try_acquire("acme").allowed
        assert rl.try_acquire("acme").allowed
        assert not rl.try_acquire("acme").allowed

        # default tenant keeps the full 20-token burst.
        for _ in range(20):
            assert rl.try_acquire("other").allowed

    def test_tenants_isolated(self) -> None:
        clock = FrozenClock(1_700_000_000)
        cfg = RateLimitConfig(qps=1.0, burst=2, monthly_quota=100)
        rl = InMemoryRateLimiter(cfg, clock=clock)

        assert rl.try_acquire("a").allowed
        assert rl.try_acquire("a").allowed
        # Tenant b is untouched.
        assert rl.try_acquire("b").allowed
        assert rl.try_acquire("b").allowed
        assert not rl.try_acquire("a").allowed
        assert not rl.try_acquire("b").allowed

    def test_monthly_quota_status_read_only(self) -> None:
        clock = FrozenClock(1_700_000_000)
        rl = InMemoryRateLimiter(DEFAULT_CFG, clock=clock)

        status_before = rl.monthly_quota_status("t")
        assert status_before.allowed
        assert status_before.remaining == DEFAULT_CFG.monthly_quota
        assert status_before.limit == DEFAULT_CFG.monthly_quota

        rl.try_acquire("t")
        status_after = rl.monthly_quota_status("t")
        # monthly_quota_status does not mutate; count went up only from acquire.
        assert status_after.remaining == DEFAULT_CFG.monthly_quota - 1

    def test_acquire_result_headers_populated(self) -> None:
        clock = FrozenClock(1_700_000_000)
        rl = InMemoryRateLimiter(DEFAULT_CFG, clock=clock)
        result = rl.try_acquire("t")
        assert result.limit == DEFAULT_CFG.burst
        assert result.quota_limit == DEFAULT_CFG.monthly_quota
        assert result.reset_at_unix >= int(clock())
        assert result.quota_reset_at_unix > clock()


# ── Redis token bucket via fakeredis ─────────────────────────────────────────


class TestRedisRateLimiter:
    def test_allows_up_to_burst_then_rejects(self) -> None:
        clock = FrozenClock(1_700_000_000)
        client = _make_fakeredis()
        rl = RedisRateLimiter(
            url="", default_config=DEFAULT_CFG, redis_client=client, clock=clock
        )

        permits = [rl.try_acquire("t").allowed for _ in range(DEFAULT_CFG.burst)]
        assert all(permits)
        blocked = rl.try_acquire("t")
        assert not blocked.allowed
        assert blocked.reason == "qps"

    def test_monthly_quota_exhaustion(self) -> None:
        clock = FrozenClock(1_700_000_000)
        client = _make_fakeredis()
        cfg = RateLimitConfig(qps=1000.0, burst=1000, monthly_quota=2)
        rl = RedisRateLimiter(
            url="", default_config=cfg, redis_client=client, clock=clock
        )

        assert rl.try_acquire("t").allowed
        assert rl.try_acquire("t").allowed
        blocked = rl.try_acquire("t")
        assert not blocked.allowed
        assert blocked.reason == "quota"

    def test_preflight_fail_closed_on_unreachable_redis(self) -> None:
        class DeadClient:
            def ping(self) -> bool:
                raise ConnectionError("nope")

            def register_script(self, _):  # pragma: no cover - not reached
                raise AssertionError("unreachable")

        with pytest.raises(RateLimitError, match="unreachable"):
            RedisRateLimiter(
                url="redis://dead",
                default_config=DEFAULT_CFG,
                redis_client=DeadClient(),
            )

    def test_concurrent_acquire_atomic(self) -> None:
        """Two threads hammer the same tenant; Redis INCR must not
        double-count. 2 workers × 50 acquires against a 60-token budget
        leaves exactly 40 rejects."""
        clock = FrozenClock(1_700_000_000)
        client = _make_fakeredis()
        # Bucket size 60; quota unlimited (10 000 is functionally infinite here).
        cfg = RateLimitConfig(qps=1.0, burst=60, monthly_quota=10_000)
        rl = RedisRateLimiter(
            url="", default_config=cfg, redis_client=client, clock=clock
        )

        outcomes: List[bool] = []
        lock = threading.Lock()

        def worker() -> None:
            for _ in range(50):
                r = rl.try_acquire("t")
                with lock:
                    outcomes.append(r.allowed)

        t1 = threading.Thread(target=worker)
        t2 = threading.Thread(target=worker)
        t1.start()
        t2.start()
        t1.join()
        t2.join()

        # Clock is frozen so no tokens refill; burst=60 caps the permits.
        permits = sum(1 for o in outcomes if o)
        assert permits == 60, (
            f"expected exactly 60 permits from a 60-token bucket, got {permits}"
        )

    def test_monthly_key_rolls(self) -> None:
        # fakeredis clock is frozen; month rollover is computed from the
        # injected ``clock`` reading, which drives the Redis key path.
        clock = FrozenClock(_month_reset_at(1_700_000_000) - 3600)
        client = _make_fakeredis()
        cfg = RateLimitConfig(qps=1000.0, burst=1000, monthly_quota=1)
        rl = RedisRateLimiter(
            url="", default_config=cfg, redis_client=client, clock=clock
        )

        assert rl.try_acquire("t").allowed
        assert not rl.try_acquire("t").allowed
        clock.advance(3700)
        # Next month uses a different counter key — fresh quota.
        assert rl.try_acquire("t").allowed


# ── factory ──────────────────────────────────────────────────────────────────


class TestFactory:
    def test_default_backend_is_memory(self) -> None:
        rl = build_rate_limiter(env={})
        assert isinstance(rl, InMemoryRateLimiter)

    def test_redis_backend_requires_url_or_client(self) -> None:
        with pytest.raises(RateLimitError, match="REDIS_URL"):
            build_rate_limiter(env={"TAU_X402_RATE_LIMIT_BACKEND": "redis"})

    def test_redis_backend_with_injected_client(self) -> None:
        rl = build_rate_limiter(
            env={"TAU_X402_RATE_LIMIT_BACKEND": "redis"},
            redis_client=_make_fakeredis(),
        )
        assert isinstance(rl, RedisRateLimiter)

    def test_unknown_backend_raises(self) -> None:
        with pytest.raises(RateLimitError, match="memory.*redis"):
            build_rate_limiter(env={"TAU_X402_RATE_LIMIT_BACKEND": "sqlite"})

    def test_env_values_round_trip(self) -> None:
        rl = build_rate_limiter(
            env={
                "TAU_X402_RATE_LIMIT_QPS": "7",
                "TAU_X402_RATE_LIMIT_BURST": "15",
                "TAU_X402_MONTHLY_QUOTA": "42",
            }
        )
        assert isinstance(rl, InMemoryRateLimiter)
        status = rl.monthly_quota_status("t")
        assert status.limit == 42

    def test_overrides_parsed(self) -> None:
        overrides_json = json.dumps(
            {"acme": {"qps": 100, "burst": 200, "monthly_quota": 99999}}
        )
        rl = build_rate_limiter(
            env={"TAU_X402_RATE_LIMIT_OVERRIDES": overrides_json}
        )
        status = rl.monthly_quota_status("acme")
        assert status.limit == 99999

    def test_overrides_invalid_json_raises(self) -> None:
        with pytest.raises(RateLimitError, match="valid JSON"):
            build_rate_limiter(
                env={"TAU_X402_RATE_LIMIT_OVERRIDES": "{not json"}
            )

    def test_overrides_non_object_raises(self) -> None:
        with pytest.raises(RateLimitError):
            build_rate_limiter(
                env={"TAU_X402_RATE_LIMIT_OVERRIDES": "[1,2,3]"}
            )

    def test_overrides_partial_inherit_defaults(self) -> None:
        # burst-only override inherits qps + quota from default.
        overrides_json = json.dumps({"acme": {"burst": 5}})
        rl = build_rate_limiter(
            env={
                "TAU_X402_RATE_LIMIT_QPS": "7",
                "TAU_X402_RATE_LIMIT_BURST": "15",
                "TAU_X402_MONTHLY_QUOTA": "42",
                "TAU_X402_RATE_LIMIT_OVERRIDES": overrides_json,
            }
        )
        # acme: burst=5 (override), qps=7, monthly_quota=42.
        status = rl.monthly_quota_status("acme")
        assert status.limit == 42  # inherited


class TestParseOverrides:
    def test_empty_object(self) -> None:
        assert _parse_overrides("{}", DEFAULT_CFG) == {}

    def test_full_override(self) -> None:
        out = _parse_overrides(
            '{"a":{"qps":1,"burst":2,"monthly_quota":3}}', DEFAULT_CFG
        )
        assert out["a"].qps == 1.0
        assert out["a"].burst == 2
        assert out["a"].monthly_quota == 3


# ── SaaS middleware integration ──────────────────────────────────────────────


fastapi_testclient = pytest.importorskip("fastapi.testclient")
TestClient = fastapi_testclient.TestClient

from saas.app import SaasConfig, create_app  # noqa: E402
from saas.billing import NullBillingReporter  # noqa: E402


def _make_app_with(rl):
    cfg = SaasConfig(
        api_keys={"tenant-a": "sk_test_a", "tenant-b": "sk_test_b"},
        socket_path="/tmp/nonexistent-rate-limit-test.sock",
        hmac_secret=bytes(32),
        billing=NullBillingReporter(),
        rate_limiter=rl,
    )
    return create_app(cfg)


class TestSaasMiddleware:
    def test_health_exempt(self) -> None:
        cfg = RateLimitConfig(qps=1.0, burst=1, monthly_quota=1)
        rl = InMemoryRateLimiter(cfg)
        app = _make_app_with(rl)
        client = TestClient(app)
        # Hammer /v1/health 10x — no 429.
        for _ in range(10):
            r = client.get("/v1/health")
            assert r.status_code == 200

    def test_usage_endpoint_returns_headers_on_permit(self) -> None:
        # /v1/usage is the cheap authenticated endpoint we use for the
        # middleware integration checks; /v1/check requires a live UDS
        # daemon.
        cfg = RateLimitConfig(qps=10.0, burst=20, monthly_quota=1000)
        rl = InMemoryRateLimiter(cfg)
        app = _make_app_with(rl)
        client = TestClient(app)
        r = client.get("/v1/usage", headers={"Authorization": "Bearer sk_test_a"})
        assert r.status_code == 200
        assert "X-RateLimit-Limit" in r.headers
        assert r.headers["X-RateLimit-Limit"] == "20"
        assert "X-RateLimit-Remaining" in r.headers
        assert "X-RateLimit-Reset-At" in r.headers
        assert "X-RateLimit-Quota-Limit" in r.headers
        assert "X-RateLimit-Quota-Remaining" in r.headers

    def test_qps_ceiling_returns_429(self) -> None:
        cfg = RateLimitConfig(qps=10.0, burst=2, monthly_quota=1000)
        rl = InMemoryRateLimiter(cfg)
        app = _make_app_with(rl)
        client = TestClient(app)
        headers = {"Authorization": "Bearer sk_test_a"}

        assert client.get("/v1/usage", headers=headers).status_code == 200
        assert client.get("/v1/usage", headers=headers).status_code == 200
        r = client.get("/v1/usage", headers=headers)
        assert r.status_code == 429
        assert "Retry-After" in r.headers
        assert int(r.headers["Retry-After"]) >= 1
        assert "X-RateLimit-Remaining" in r.headers
        assert r.headers["X-RateLimit-Remaining"] == "0"
        assert r.json()["detail"] == "rate limit exceeded"

    def test_quota_exhaustion_returns_429_with_flag(self) -> None:
        cfg = RateLimitConfig(qps=1000.0, burst=1000, monthly_quota=2)
        rl = InMemoryRateLimiter(cfg)
        app = _make_app_with(rl)
        client = TestClient(app)
        headers = {"Authorization": "Bearer sk_test_a"}

        assert client.get("/v1/usage", headers=headers).status_code == 200
        assert client.get("/v1/usage", headers=headers).status_code == 200
        r = client.get("/v1/usage", headers=headers)
        assert r.status_code == 429
        assert r.headers.get("X-RateLimit-Quota-Exhausted") == "monthly"
        assert r.json()["detail"] == "monthly quota exhausted"

    def test_tenants_isolated_in_middleware(self) -> None:
        cfg = RateLimitConfig(qps=10.0, burst=1, monthly_quota=1000)
        rl = InMemoryRateLimiter(cfg)
        app = _make_app_with(rl)
        client = TestClient(app)

        # Tenant A burns its 1 token, hits 429. Tenant B still permitted.
        assert client.get(
            "/v1/usage", headers={"Authorization": "Bearer sk_test_a"}
        ).status_code == 200
        assert client.get(
            "/v1/usage", headers={"Authorization": "Bearer sk_test_a"}
        ).status_code == 429
        assert client.get(
            "/v1/usage", headers={"Authorization": "Bearer sk_test_b"}
        ).status_code == 200

    def test_missing_auth_flows_to_401(self) -> None:
        # No Authorization header: middleware skips limiting; auth dep 401s.
        cfg = RateLimitConfig(qps=1.0, burst=1, monthly_quota=1)
        rl = InMemoryRateLimiter(cfg)
        app = _make_app_with(rl)
        client = TestClient(app)

        r = client.get("/v1/usage")
        assert r.status_code == 401
        # No rate-limit header budget was burned.
        assert "X-RateLimit-Remaining" not in r.headers

    def test_invalid_bearer_flows_to_401(self) -> None:
        cfg = RateLimitConfig(qps=1.0, burst=1, monthly_quota=1)
        rl = InMemoryRateLimiter(cfg)
        app = _make_app_with(rl)
        client = TestClient(app)

        r = client.get(
            "/v1/usage", headers={"Authorization": "Bearer sk_unknown"}
        )
        assert r.status_code == 401

    def test_metrics_counter_bumped_on_reject(self) -> None:
        from adapter.metrics import get_default, is_available, reset_default

        # Only assert when prometheus_client is installed; test skips cleanly
        # otherwise so minimal CI stays green.
        if not is_available():
            pytest.skip("prometheus_client not installed")

        # Reset BEFORE create_app so the app captures the fresh singleton.
        reset_default()
        metrics = get_default()

        cfg = RateLimitConfig(qps=1.0, burst=1, monthly_quota=1000)
        rl = InMemoryRateLimiter(cfg)
        app = _make_app_with(rl)
        client = TestClient(app)
        headers = {"Authorization": "Bearer sk_test_a"}

        assert client.get("/v1/usage", headers=headers).status_code == 200
        assert client.get("/v1/usage", headers=headers).status_code == 429
        text = metrics.render_text().decode("utf-8")
        assert "tau_x402_rate_limit_rejected_total" in text
        assert 'reason="qps"' in text
        # Restore the module-level default so later tests see a clean
        # slate rather than our label cardinality.
        reset_default()

    def test_redis_rate_limiter_end_to_end(self) -> None:
        # Wire a RedisRateLimiter into the app with fakeredis.
        client_r = _make_fakeredis()
        cfg = RateLimitConfig(qps=10.0, burst=2, monthly_quota=1000)
        rl = RedisRateLimiter(
            url="", default_config=cfg, redis_client=client_r
        )
        app = _make_app_with(rl)
        http_client = TestClient(app)
        headers = {"Authorization": "Bearer sk_test_a"}
        assert http_client.get("/v1/usage", headers=headers).status_code == 200
        assert http_client.get("/v1/usage", headers=headers).status_code == 200
        r = http_client.get("/v1/usage", headers=headers)
        assert r.status_code == 429
