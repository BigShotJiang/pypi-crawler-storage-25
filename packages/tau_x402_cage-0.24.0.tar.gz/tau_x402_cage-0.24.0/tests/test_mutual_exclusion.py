"""Tests for the MutualExclusion invariant (fragment v1, patch 9).

Covers:
  * construction / validation (both groups non-empty)
  * check_payment direct-violation path
  * _sat_body encoding obeys fragment v1 rules (camelCase, bv[64] only)
  * compile_policy integration: MutualExclusion composes with ProviderAllowlist
  * mocked-Tau SAT on a disjoint-groups composition
  * real-Tau (optional): ProviderAllowlist(A) ∧ MutualExclusion(A, A) → UNSAT
"""
from __future__ import annotations

import subprocess
from decimal import Decimal
from unittest.mock import patch

import pytest

from adapter.invariants import (
    InvariantError,
    MutualExclusion,
    ProviderAllowlist,
    Violation,
    compose_for_sat,
)
from adapter.payment_intent_matcher import PaymentIntent
from adapter.prover import (
    Contradiction,
    ProofToken,
    TauConsistencyProver,
)
from adapter.tau_compiler import (
    UnsupportedInvariantError,
    compile_policy,
    fragment_members,
)


def _intent(provider: str, amount: str = "1") -> PaymentIntent:
    return PaymentIntent(
        amount=Decimal(amount),
        currency="USDC",
        provider=provider,
        counterparty="vendor_a",
        rail="x402",
        timestamp_unix=1_700_000_000,
    )


# ── construction / validation ────────────────────────────────────────────────


class TestConstruction:
    def test_empty_group_a_rejected(self) -> None:
        with pytest.raises(InvariantError, match="group_a"):
            MutualExclusion(group_a=frozenset(), group_b=frozenset({"a"}))

    def test_empty_group_b_rejected(self) -> None:
        with pytest.raises(InvariantError, match="group_b"):
            MutualExclusion(group_a=frozenset({"a"}), group_b=frozenset())

    def test_immutability(self) -> None:
        m = MutualExclusion(group_a=frozenset({"a"}), group_b=frozenset({"b"}))
        with pytest.raises(AttributeError):
            m.group_a = frozenset({"x"})  # type: ignore[misc]

    def test_deterministic_body_over_set_order(self) -> None:
        a = MutualExclusion(
            group_a=frozenset({"x", "y"}),
            group_b=frozenset({"p", "q"}),
        )
        b = MutualExclusion(
            group_a=frozenset({"y", "x"}),
            group_b=frozenset({"q", "p"}),
        )
        assert a._sat_body() == b._sat_body()


# ── check_payment ────────────────────────────────────────────────────────────


class TestCheckPayment:
    def test_disjoint_groups_admit_any_member(self) -> None:
        inv = MutualExclusion(
            group_a=frozenset({"anthropic"}),
            group_b=frozenset({"openai"}),
        )
        assert inv.check_payment(_intent("anthropic"), history=[]) is None
        assert inv.check_payment(_intent("openai"), history=[]) is None

    def test_provider_outside_both_groups_is_admitted(self) -> None:
        # MutualExclusion is only concerned with providers that sit in BOTH
        # groups. A provider in neither is trivially fine here.
        inv = MutualExclusion(
            group_a=frozenset({"anthropic"}),
            group_b=frozenset({"openai"}),
        )
        assert inv.check_payment(_intent("replicate"), history=[]) is None

    def test_overlap_provider_violates(self) -> None:
        inv = MutualExclusion(
            group_a=frozenset({"anthropic", "openai"}),
            group_b=frozenset({"openai", "replicate"}),
        )
        v = inv.check_payment(_intent("openai"), history=[])
        assert isinstance(v, Violation)
        assert v.rule_id == "mutual_exclusion"
        assert "openai" in v.witness


# ── fragment v1 encoding rules ───────────────────────────────────────────────


class TestSatBodyEncoding:
    def test_uses_cageprovider_and_bv64(self) -> None:
        body = MutualExclusion(
            group_a=frozenset({"a"}),
            group_b=frozenset({"b"}),
        )._sat_body()
        # Rule E1: camelCase, no underscores in cage-emitted identifiers
        assert "cageProvider" in body
        # Rule E2: unified bv[64]
        assert ":bv[64]" in body
        assert ":bv[16]" not in body
        # Rule E3: no temporal indices
        assert "[t]" not in body
        # Structural: negated AND of two disjunctions
        assert body.startswith("!((")
        assert " && " in body

    def test_compile_policy_accepts_mutual_exclusion(self) -> None:
        inv = MutualExclusion(group_a=frozenset({"a"}), group_b=frozenset({"b"}))
        compiled = compile_policy([inv])
        assert compiled.supported_invariants == 1
        assert "cageProvider" in compiled.tau_source
        assert compiled.invariant_summaries[0]["class"] == "MutualExclusion"
        assert compiled.invariant_summaries[0]["scope_hint"] == "groups=(1,1)"

    def test_fragment_v1_registry_contains_class(self) -> None:
        assert MutualExclusion in fragment_members("v1")


# ── composition with ProviderAllowlist ───────────────────────────────────────


class TestComposition:
    def test_compose_with_provider_allowlist_compiles(self) -> None:
        invs = [
            ProviderAllowlist(providers=frozenset({"a", "b"})),
            MutualExclusion(group_a=frozenset({"a"}), group_b=frozenset({"b"})),
        ]
        compiled = compile_policy(invs)
        assert compiled.supported_invariants == 2
        # Two distinct conjuncts
        assert "cageProvider" in compiled.tau_source
        assert " && " in compiled.tau_source

    def test_pathological_composition_text(self) -> None:
        """ProviderAllowlist({a,b}) ∧ MutualExclusion({a,b}, {a,b}) produces
        a formula whose conjunction is unsatisfiable. (Tau decides; we
        only check textual shape here — the real-Tau test below decides.)
        """
        invs = [
            ProviderAllowlist(providers=frozenset({"a", "b"})),
            MutualExclusion(
                group_a=frozenset({"a", "b"}),
                group_b=frozenset({"a", "b"}),
            ),
        ]
        src = compose_for_sat(invs)
        # Two conjuncts, both referencing cageProvider:bv[64]
        assert src.count("cageProvider:bv[64]") >= 4
        assert " && " in src


# ── mocked-Tau decisiveness (no real binary required) ────────────────────────


class TestMockedTau:
    def test_disjoint_groups_decide_sat(self, tmp_path, monkeypatch) -> None:
        fake = tmp_path / "tau"
        fake.write_text("#!/bin/sh\necho T\n")
        fake.chmod(0o755)
        monkeypatch.setenv("TAU_BINARY", str(fake))
        with patch("adapter.prover.subprocess.run") as mock_run:
            mock_run.return_value = subprocess.CompletedProcess(
                args=[], returncode=0, stdout="sat: 5 ms\n%1: T\n", stderr="",
            )
            result = TauConsistencyProver(timeout_seconds=1.0).prove(
                [
                    ProviderAllowlist(providers=frozenset({"a", "b"})),
                    MutualExclusion(
                        group_a=frozenset({"a"}),
                        group_b=frozenset({"b"}),
                    ),
                ]
            )
        assert isinstance(result, ProofToken)
        assert result.proof_strength == "complete"

    def test_pathological_composition_decides_unsat(
        self, tmp_path, monkeypatch
    ) -> None:
        fake = tmp_path / "tau"
        fake.write_text("#!/bin/sh\necho F\n")
        fake.chmod(0o755)
        monkeypatch.setenv("TAU_BINARY", str(fake))
        with patch("adapter.prover.subprocess.run") as mock_run:
            mock_run.return_value = subprocess.CompletedProcess(
                args=[], returncode=0, stdout="sat: 9 ms\n%1: F\n", stderr="",
            )
            result = TauConsistencyProver(timeout_seconds=1.0).prove(
                [
                    ProviderAllowlist(providers=frozenset({"a", "b"})),
                    MutualExclusion(
                        group_a=frozenset({"a", "b"}),
                        group_b=frozenset({"a", "b"}),
                    ),
                ]
            )
        assert isinstance(result, Contradiction)


# ── real-Tau integration (skips when binary unavailable) ─────────────────────


pytestmark_real_tau = pytest.mark.skipif(
    not TauConsistencyProver.is_available(),
    reason="Tau binary not available (set TAU_BINARY or put `tau` on PATH)",
)


@pytestmark_real_tau
class TestRealTau:
    def test_mutual_exclusion_alone_decides_sat(self) -> None:
        result = TauConsistencyProver(timeout_seconds=5.0).prove(
            [
                MutualExclusion(
                    group_a=frozenset({"a"}),
                    group_b=frozenset({"b"}),
                )
            ]
        )
        assert isinstance(result, ProofToken)
        assert result.proof_strength == "complete"

    def test_disjoint_composition_decides_sat(self) -> None:
        """ProviderAllowlist({a,b}) ∧ MutualExclusion({a}, {b}) is SAT —
        there is at least one model (either provider = a or provider = b).
        """
        result = TauConsistencyProver(timeout_seconds=5.0).prove(
            [
                ProviderAllowlist(providers=frozenset({"a", "b"})),
                MutualExclusion(
                    group_a=frozenset({"a"}),
                    group_b=frozenset({"b"}),
                ),
            ]
        )
        assert isinstance(result, ProofToken)
        assert result.proof_strength == "complete"

    def test_pathological_composition_decides_unsat(self) -> None:
        """ProviderAllowlist({a,b}) ∧ MutualExclusion({a,b}, {a,b}) is UNSAT:
        every provider in the allowlist is simultaneously in both exclusion
        groups, so the formula is unsatisfiable.
        """
        result = TauConsistencyProver(timeout_seconds=5.0).prove(
            [
                ProviderAllowlist(providers=frozenset({"a", "b"})),
                MutualExclusion(
                    group_a=frozenset({"a", "b"}),
                    group_b=frozenset({"a", "b"}),
                ),
            ]
        )
        assert isinstance(result, Contradiction)

    def test_decides_under_15ms(self) -> None:
        """Regression gate: single-invariant MutualExclusion decides fast."""
        import time
        start = time.monotonic()
        result = TauConsistencyProver(timeout_seconds=1.0).prove(
            [
                MutualExclusion(
                    group_a=frozenset({"a"}),
                    group_b=frozenset({"b"}),
                )
            ]
        )
        elapsed_ms = (time.monotonic() - start) * 1000
        assert isinstance(result, ProofToken)
        assert elapsed_ms < 500  # loose bound; fragment-v1 gate is 100ms


# ── daemon payload coverage ──────────────────────────────────────────────────


class TestDaemonBuildInvariant:
    def test_daemon_builds_mutual_exclusion(self) -> None:
        from daemon.server import CageDaemon
        # Use a throwaway socket path; the build method does not bind.
        d = CageDaemon(socket_path="/tmp/_mx_test.sock")
        try:
            inv = d._build_x402_invariant({
                "kind": "mutual_exclusion",
                "group_a": ["anthropic", "openai"],
                "group_b": ["replicate"],
            })
        finally:
            d.shutdown()
        assert isinstance(inv, MutualExclusion)
        assert inv.group_a == frozenset({"anthropic", "openai"})
        assert inv.group_b == frozenset({"replicate"})

    def test_daemon_rejects_non_list_groups(self) -> None:
        from daemon.server import CageDaemon
        d = CageDaemon(socket_path="/tmp/_mx_test2.sock")
        try:
            inv = d._build_x402_invariant({
                "kind": "mutual_exclusion",
                "group_a": "not-a-list",
                "group_b": ["replicate"],
            })
        finally:
            d.shutdown()
        assert inv is None
