"""Tests for the corporate-card procurement-agent demo.

Runs the demo as a subprocess with --quiet, asserts exit 0, parses the
summary JSON, and verifies the seven expected state transitions held.
Completes in well under 60s on a developer laptop (the demo itself runs
in ~0.1s; subprocess spin-up dominates).
"""
from __future__ import annotations

import json
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Tuple

import pytest

ROOT = Path(__file__).resolve().parent.parent
DEMO = ROOT / "demos" / "corporate_card_demo.py"


def _run_demo(args: List[str]) -> Tuple[int, str, str, float]:
    start = time.monotonic()
    proc = subprocess.run(
        [sys.executable, str(DEMO)] + args,
        capture_output=True, text=True, timeout=60,
    )
    return proc.returncode, proc.stdout, proc.stderr, time.monotonic() - start


class TestCorporateCardDemo:
    def test_demo_file_exists(self) -> None:
        assert DEMO.is_file(), f"demo script missing at {DEMO}"

    def test_quiet_run_exits_0(self) -> None:
        rc, out, err, elapsed = _run_demo(["--quiet"])
        assert rc == 0, f"rc={rc} stderr={err!r}"
        # Task spec says <45s; allow headroom for subprocess spin-up on
        # slower CI hosts while keeping the regression tight.
        assert elapsed < 45.0, f"demo took {elapsed:.2f}s, must be < 45s"

    def test_quiet_run_emits_structured_summary(self) -> None:
        rc, out, err, _ = _run_demo(["--quiet"])
        assert rc == 0, err
        # The last stdout line is the JSON summary.
        lines = [line for line in out.splitlines() if line.strip()]
        summary = json.loads(lines[-1])
        assert summary["demo"] == "corporate_card_v0.21.0"
        assert len(summary["steps"]) == 7

    def test_all_seven_step_state_transitions(self) -> None:
        rc, out, err, _ = _run_demo(["--quiet"])
        assert rc == 0, err
        lines = [line for line in out.splitlines() if line.strip()]
        summary: Dict[str, Any] = json.loads(lines[-1])
        by_idx = {s["index"]: s for s in summary["steps"]}
        expected = {
            1: "ok",         # admission
            2: "ok",         # routine payment allowed
            3: "blocked",    # Knight-Capital retry loop
            4: "blocked",    # Milkie-Way runaway loop
            5: "rejected",   # weakening mutation
            6: "blocked",    # lookalike spoof
            7: "ok",         # audit bundle verified
        }
        for idx, want in expected.items():
            got = by_idx[idx]["status"]
            assert got == want, f"step {idx} expected {want!r}, got {got!r}"

    def test_final_bundle_verifies(self) -> None:
        from adapter.guaranteed_audit import GuaranteedAuditBundle

        rc, out, err, _ = _run_demo(["--quiet"])
        assert rc == 0, err
        lines = [line for line in out.splitlines() if line.strip()]
        summary = json.loads(lines[-1])
        bundle_path = Path(summary["bundle"]["out_path"])
        assert bundle_path.exists(), f"bundle not written at {bundle_path}"
        # The demo uses a fixed key so we can reload + verify it here.
        from demos.corporate_card_demo import _DEMO_HMAC_KEY
        assert GuaranteedAuditBundle.verify(
            bundle_path.read_bytes(), _DEMO_HMAC_KEY,
        )
        # And tamper verification was already asserted inside the demo; the
        # summary carries the positive result from that check.
        assert summary["bundle"]["verified"] is True
        assert summary["bundle"]["verify_after_tamper"] is False

    def test_narrative_mode_prints_scenarios(self) -> None:
        rc, out, err, _ = _run_demo([])
        assert rc == 0, err
        for fragment in (
            "SCENARIO 1",
            "SCENARIO 3: Knight-Capital",
            "SCENARIO 4: Milkie-Way",
            "SCENARIO 7",
            "FINAL SUMMARY",
        ):
            assert fragment in out, f"missing narrative fragment {fragment!r}"

    def test_admission_evidence_shape(self) -> None:
        """Step 1 should carry the language + prover versions + totality."""
        rc, out, err, _ = _run_demo(["--quiet"])
        assert rc == 0, err
        lines = [line for line in out.splitlines() if line.strip()]
        summary = json.loads(lines[-1])
        admission = next(s for s in summary["steps"] if s["index"] == 1)
        assert admission["body"]["proof_result"] == "proven"
        assert admission["body"]["language_tier_version"]
        assert admission["body"]["tau_backend_version"]
        assert admission["body"]["invariant_count"] == 8
        assert admission["body"]["policy_id"] == "procurebot-7"

    def test_audit_bundle_size_reasonable(self) -> None:
        """Bundle should contain >= 1 admission + >= 3 decisions."""
        rc, out, err, _ = _run_demo(["--quiet"])
        assert rc == 0, err
        lines = [line for line in out.splitlines() if line.strip()]
        summary = json.loads(lines[-1])
        bundle = summary["bundle"]
        assert bundle["admission_count"] >= 1
        # S2 (allowed), S3 (retry blocks), S4 (one blocked), S6 (spoof blocked)
        assert bundle["decision_count"] >= 3
        assert bundle["bytes"] > 500, f"bundle bytes={bundle['bytes']} suspiciously small"

    def test_scenario_3_surfaces_adaptive_tightening(self) -> None:
        """v0.21.0: scenario 3 must carry tightening level + trigger + adjusted limits.

        Tolerates either adaptive_tightening_triggered or a retry-rate
        reason, per the brief — what must hold is that the tightening
        snapshot is populated and the reason mentions one of the two
        mechanisms.
        """
        rc, out, err, _ = _run_demo(["--quiet"])
        assert rc == 0, err
        lines = [line for line in out.splitlines() if line.strip()]
        summary = json.loads(lines[-1])
        s3 = next(s for s in summary["steps"] if s["index"] == 3)
        body = s3["body"]
        assert "tightening_level" in body, body
        assert "trigger" in body, body
        assert "adjusted_limits" in body, body
        assert "reason" in body, body
        reason = (body.get("reason") or "").lower()
        assert (
            "tightening" in reason
            or "retry" in reason
            or "rate_limit" in reason
        ), f"unexpected reason {body['reason']!r}"

    def test_scenario_4_surfaces_composed_violation_and_prevented_risk(
        self,
    ) -> None:
        """v0.21.0: scenario 4 must carry the composed violations + prevented_risk."""
        rc, out, err, _ = _run_demo(["--quiet"])
        assert rc == 0, err
        lines = [line for line in out.splitlines() if line.strip()]
        summary = json.loads(lines[-1])
        s4 = next(s for s in summary["steps"] if s["index"] == 4)
        body = s4["body"]
        violations = body.get("violations") or []
        assert isinstance(violations, list), f"violations not a list: {violations!r}"
        assert len(violations) >= 2, (
            f"expected composed violation (>=2 rules), got {violations!r}"
        )
        prevented = body.get("prevented_risk") or {}
        assert "estimated_spend_blocked_usd" in prevented, prevented
        # Field must parse as a positive number so downstream dashboards
        # can chart it without defensive coercion.
        try:
            blocked = float(prevented["estimated_spend_blocked_usd"])
        except (TypeError, ValueError) as exc:
            raise AssertionError(
                f"estimated_spend_blocked_usd not numeric: "
                f"{prevented['estimated_spend_blocked_usd']!r} ({exc})"
            )
        assert blocked > 0, f"prevented spend must be > 0, got {blocked}"
        # v0.22.0: the headline is now the dual shape (tau_bv_witness_plus_ema)
        # when the prover is injected into the demo. v0.21.x single-shape
        # (ema_velocity) remains valid for callers without a prover plumbed
        # in — so the test accepts either.
        assert prevented.get("based_on") in (
            "ema_velocity",
            "tau_bv_witness_plus_ema",
        ), prevented
        assert body.get("actual_spend"), body
        assert body.get("projected_spend_if_unblocked"), body
