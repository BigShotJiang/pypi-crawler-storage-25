"""Tests for adapter/history_store.py (v0.8.0).

Covers:
* InMemoryHistoryStore round-trip (append, recent, count, clear)
* Ring-buffer cap enforcement (>10_000 trims oldest)
* RedisHistoryStore round-trip via fakeredis
* Fail-closed startup when Redis is unreachable
* ``recent_verdicts`` op routing through the new store
* PaymentIntent encode/decode preserves field values across JSON round-trip
"""
from __future__ import annotations

from decimal import Decimal
from typing import Any

import pytest

from adapter.history_store import (
    HistoryStoreError,
    InMemoryHistoryStore,
    RedisHistoryStore,
    _decode,
    _encode,
    build_history_store,
)
from adapter.payment_intent_matcher import PaymentIntent
from daemon.server import CageDaemon


# ── shared fixtures ─────────────────────────────────────────────────────────


def _intent(
    amount: str = "10.00",
    *,
    provider: str = "anthropic",
    counterparty: str = "vendor_x",
    timestamp_unix: int = 1_700_000_000,
    request_id: str | None = None,
    metadata: dict[str, str] | None = None,
) -> PaymentIntent:
    return PaymentIntent(
        amount=Decimal(amount),
        currency="USDC",
        provider=provider,
        counterparty=counterparty,
        rail="x402",
        timestamp_unix=timestamp_unix,
        metadata=metadata or {},
        request_id=request_id,
    )


@pytest.fixture
def fake_redis_client():
    """Return a fakeredis client that quacks like redis.Redis(decode_responses=True).

    fakeredis >=2 ships a ``FakeRedis`` that implements LPUSH/LTRIM/LRANGE,
    which is sufficient for our HistoryStore contract.
    """
    try:
        import fakeredis  # type: ignore[import-untyped]
    except ImportError:
        pytest.skip("fakeredis not installed; pip install fakeredis to run")
    return fakeredis.FakeRedis(decode_responses=True)


# ── InMemoryHistoryStore ────────────────────────────────────────────────────


class TestInMemoryHistoryStore:
    def test_append_and_count(self) -> None:
        s = InMemoryHistoryStore()
        assert s.count("permit") == 0
        s.append(_intent("10"), kind="permit")
        s.append(_intent("20"), kind="permit")
        assert s.count("permit") == 2
        assert s.count("reject") == 0

    def test_recent_is_newest_first(self) -> None:
        s = InMemoryHistoryStore()
        for i in range(3):
            s.append(_intent(str(10 + i)), kind="permit")
        got = s.recent("permit", limit=10, offset=0)
        amounts = [item.amount for item in got]
        assert amounts == [Decimal("12"), Decimal("11"), Decimal("10")]

    def test_recent_oldest_first(self) -> None:
        s = InMemoryHistoryStore()
        for i in range(3):
            s.append(_intent(str(10 + i)), kind="permit")
        got = s.recent_oldest_first("permit")
        amounts = [item.amount for item in got]
        assert amounts == [Decimal("10"), Decimal("11"), Decimal("12")]

    def test_pagination_offset_limit(self) -> None:
        s = InMemoryHistoryStore()
        for i in range(5):
            s.append(_intent(str(10 + i)), kind="permit")
        page1 = s.recent("permit", limit=2, offset=0)
        assert [it.amount for it in page1] == [Decimal("14"), Decimal("13")]
        page2 = s.recent("permit", limit=2, offset=2)
        assert [it.amount for it in page2] == [Decimal("12"), Decimal("11")]

    def test_cap_trims_oldest(self) -> None:
        s = InMemoryHistoryStore(cap=3)
        for i in range(5):
            s.append(_intent(str(10 + i)), kind="permit")
        assert s.count("permit") == 3
        # Oldest (10, 11) were trimmed; newest three remain.
        got = s.recent_oldest_first("permit")
        amounts = [it.amount for it in got]
        assert amounts == [Decimal("12"), Decimal("13"), Decimal("14")]

    def test_cap_10000_trims_oldest(self) -> None:
        """The production cap is 10_000. Make sure trimming holds at that scale."""
        s = InMemoryHistoryStore(cap=10_000)
        for i in range(10_500):
            s.append(_intent(str(1 + i)), kind="permit")
        assert s.count("permit") == 10_000
        # Oldest surviving should be intent #501 (first 500 were trimmed).
        oldest = s.recent_oldest_first("permit")[0]
        assert oldest.amount == Decimal("501")
        # Newest should be 10500.
        newest = s.recent("permit", limit=1)[0]
        assert newest.amount == Decimal("10500")

    def test_clear_drops_all_streams(self) -> None:
        s = InMemoryHistoryStore()
        s.append(_intent("10"), kind="permit")
        s.append(_intent("20"), kind="reject")
        s.append({"verdict": "permit", "rule_id": None}, kind="verdict")
        s.clear()
        assert s.count("permit") == 0
        assert s.count("reject") == 0
        assert s.count("verdict") == 0

    def test_kind_validation_rejects_unknown(self) -> None:
        s = InMemoryHistoryStore()
        with pytest.raises(ValueError):
            s.append(_intent("10"), kind="bogus")
        with pytest.raises(ValueError):
            s.recent("bogus")
        with pytest.raises(ValueError):
            s.count("bogus")

    def test_cap_must_be_positive(self) -> None:
        with pytest.raises(ValueError):
            InMemoryHistoryStore(cap=0)
        with pytest.raises(ValueError):
            InMemoryHistoryStore(cap=-1)

    def test_verdict_dicts_stored_alongside_intents(self) -> None:
        s = InMemoryHistoryStore()
        s.append(_intent("10"), kind="permit")
        s.append({"verdict": "permit", "rule_id": None, "intent": {"amount": "10"}},
                 kind="verdict")
        assert s.count("permit") == 1
        assert s.count("verdict") == 1
        verdicts = s.recent("verdict")
        assert isinstance(verdicts[0], dict)
        assert verdicts[0]["verdict"] == "permit"


# ── encode/decode helpers ───────────────────────────────────────────────────


class TestEncodeDecode:
    def test_intent_round_trip_preserves_fields(self) -> None:
        original = _intent(
            "42.5",
            provider="anthropic",
            counterparty="vendor_y",
            timestamp_unix=1_700_000_123,
            request_id="req_abc",
            metadata={"trace_id": "t1"},
        )
        round_tripped = _decode(_encode(original))
        assert isinstance(round_tripped, PaymentIntent)
        assert round_tripped.amount == Decimal("42.5")
        assert round_tripped.provider == "anthropic"
        assert round_tripped.counterparty == "vendor_y"
        assert round_tripped.timestamp_unix == 1_700_000_123
        assert round_tripped.request_id == "req_abc"
        assert round_tripped.metadata == {"trace_id": "t1"}

    def test_verdict_dict_round_trip(self) -> None:
        original = {
            "verdict": "reject",
            "rule_id": "max_per_call",
            "reason_text": "over cap",
            "intent": {"amount": "500", "currency": "USDC"},
            "revision_id": "abc123",
        }
        round_tripped = _decode(_encode(original))
        assert isinstance(round_tripped, dict)
        # Internal tag must not leak to the caller.
        assert "_tag" not in round_tripped
        assert round_tripped == original

    def test_unknown_tag_raises(self) -> None:
        import json
        blob = json.dumps({"_tag": "bogus", "x": 1})
        with pytest.raises(ValueError):
            _decode(blob)


# ── RedisHistoryStore (fakeredis) ───────────────────────────────────────────


class TestRedisHistoryStore:
    def test_append_recent_count_round_trip(self, fake_redis_client) -> None:
        s = RedisHistoryStore(
            url="redis://fake",
            redis_client=fake_redis_client,
            cap=100,
        )
        assert s.backend == "redis"
        assert s.count("permit") == 0
        s.append(_intent("10"), kind="permit")
        s.append(_intent("20"), kind="permit")
        s.append(_intent("30"), kind="permit")
        assert s.count("permit") == 3
        # Newest-first
        page = s.recent("permit", limit=10)
        amounts = [it.amount for it in page]
        assert amounts == [Decimal("30"), Decimal("20"), Decimal("10")]
        # Oldest-first for invariant evaluators
        oldest = s.recent_oldest_first("permit")
        amounts_o = [it.amount for it in oldest]
        assert amounts_o == [Decimal("10"), Decimal("20"), Decimal("30")]

    def test_ring_cap_trims_via_ltrim(self, fake_redis_client) -> None:
        """LPUSH+LTRIM must keep only the newest `cap` entries."""
        s = RedisHistoryStore(
            url="redis://fake", redis_client=fake_redis_client, cap=3,
        )
        for i in range(5):
            s.append(_intent(str(10 + i)), kind="permit")
        assert s.count("permit") == 3
        # Oldest (10, 11) should be gone.
        oldest = s.recent_oldest_first("permit")
        amounts = [it.amount for it in oldest]
        assert amounts == [Decimal("12"), Decimal("13"), Decimal("14")]

    def test_clear_only_deletes_namespaced_keys(self, fake_redis_client) -> None:
        """clear() must not touch unrelated keys in the same DB."""
        s = RedisHistoryStore(
            url="redis://fake",
            redis_client=fake_redis_client,
            cap=10,
            key_prefix="tau-x402-cage:",
        )
        s.append(_intent("10"), kind="permit")
        # Stash an unrelated key directly on the client.
        fake_redis_client.set("unrelated:key", "should-survive")
        s.clear()
        assert s.count("permit") == 0
        assert fake_redis_client.get("unrelated:key") == "should-survive"

    def test_separate_streams_isolated(self, fake_redis_client) -> None:
        s = RedisHistoryStore(
            url="redis://fake", redis_client=fake_redis_client, cap=10,
        )
        s.append(_intent("10"), kind="permit")
        s.append(_intent("20"), kind="reject")
        s.append({"verdict": "permit"}, kind="verdict")
        assert s.count("permit") == 1
        assert s.count("reject") == 1
        assert s.count("verdict") == 1

    def test_key_prefix_namespaces(self, fake_redis_client) -> None:
        s = RedisHistoryStore(
            url="redis://fake",
            redis_client=fake_redis_client,
            cap=10,
            key_prefix="acme:cage:",
        )
        s.append(_intent("10"), kind="permit")
        # Direct key inspection to confirm namespacing.
        assert fake_redis_client.llen("acme:cage:history:permit") == 1
        assert fake_redis_client.llen("tau-x402-cage:history:permit") == 0

    def test_preflight_fails_closed_on_unreachable(self) -> None:
        """RedisHistoryStore must raise HistoryStoreError when PING fails."""
        class BrokenClient:
            def ping(self):
                raise ConnectionError("nope")
        with pytest.raises(HistoryStoreError) as exc:
            RedisHistoryStore(url="redis://fake", redis_client=BrokenClient())
        assert "unreachable" in str(exc.value).lower()

    def test_preflight_fails_on_falsy_ping(self) -> None:
        """A falsy PING response (e.g. shadowbanned) still fails closed."""
        class FalsyClient:
            def ping(self):
                return False
        with pytest.raises(HistoryStoreError):
            RedisHistoryStore(url="redis://fake", redis_client=FalsyClient())

    def test_cap_must_be_positive(self, fake_redis_client) -> None:
        with pytest.raises(ValueError):
            RedisHistoryStore(
                url="redis://fake", redis_client=fake_redis_client, cap=0,
            )


# ── build_history_store factory ─────────────────────────────────────────────


class TestBuildHistoryStore:
    def test_memory_backend(self) -> None:
        s = build_history_store("memory", cap=50)
        assert isinstance(s, InMemoryHistoryStore)
        assert s.backend == "memory"

    def test_redis_backend_requires_url(self) -> None:
        with pytest.raises(HistoryStoreError) as exc:
            build_history_store("redis")
        assert "redis-url" in str(exc.value).lower() or "redis_url" in str(exc.value).lower()

    def test_redis_backend_with_injected_client(self, fake_redis_client) -> None:
        s = build_history_store(
            "redis",
            redis_url="redis://fake",
            redis_client=fake_redis_client,
            cap=100,
        )
        assert isinstance(s, RedisHistoryStore)

    def test_unknown_backend_raises(self) -> None:
        with pytest.raises(HistoryStoreError) as exc:
            build_history_store("postgres")
        assert "postgres" in str(exc.value)


# ── Daemon integration: recent_verdicts + check_payment round-trips ─────────


class TestDaemonWithStore:
    def test_default_daemon_uses_in_memory_store(self) -> None:
        daemon = CageDaemon(socket_path="/tmp/test-daemon-default.sock")
        assert isinstance(daemon._history_store, InMemoryHistoryStore)

    def test_injected_store_survives_daemon_lifecycle(
        self, fake_redis_client,
    ) -> None:
        """A Redis store handed in at construction is actually used."""
        store = RedisHistoryStore(
            url="redis://fake", redis_client=fake_redis_client, cap=100,
        )
        daemon = CageDaemon(
            socket_path="/tmp/test-daemon-redis.sock",
            history_store=store,
        )
        # Declare MaxPerCall + run a permit.
        resp = daemon.dispatch({
            "op": "declare_x402", "kind": "max_per_call", "max_amount": "100.00",
        })
        assert resp["verdict"] == "updated", resp
        intent_dict = {
            "amount": "50",
            "currency": "USDC",
            "provider": "anthropic",
            "counterparty": "vendor_x",
            "rail": "x402",
            "timestamp_unix": 1_700_000_000,
        }
        permit = daemon.dispatch({"op": "check_payment", "intent": intent_dict})
        assert permit["verdict"] == "permit"
        # History written to the Redis-backed store.
        assert store.count("permit") == 1
        assert store.count("verdict") == 1

    def test_recent_verdicts_op_routes_through_store(
        self, fake_redis_client,
    ) -> None:
        """The web-ui ``recent_verdicts`` op must read from the injected store."""
        store = RedisHistoryStore(
            url="redis://fake", redis_client=fake_redis_client, cap=100,
        )
        daemon = CageDaemon(
            socket_path="/tmp/test-daemon-recent.sock",
            history_store=store,
        )
        daemon.dispatch({
            "op": "declare_x402", "kind": "max_per_call", "max_amount": "100.00",
        })
        # 2 permits + 1 reject
        base = {
            "currency": "USDC",
            "provider": "anthropic",
            "counterparty": "vendor_x",
            "rail": "x402",
            "timestamp_unix": 1_700_000_000,
        }
        daemon.dispatch({"op": "check_payment", "intent": {"amount": "10", **base}})
        daemon.dispatch({"op": "check_payment", "intent": {"amount": "20", **base}})
        daemon.dispatch({"op": "check_payment", "intent": {"amount": "999", **base}})

        rv = daemon.dispatch({"op": "recent_verdicts"})
        assert rv["verdict"] == "ok"
        assert rv["total"] == 3
        verdicts = [e["verdict"] for e in rv["entries"]]
        # Newest-first: reject, permit, permit
        assert verdicts == ["reject", "permit", "permit"]
        assert rv["entries"][0]["rule_id"] == "max_per_call"

    def test_rolling_window_cap_uses_store_order(self, fake_redis_client) -> None:
        """RollingWindowCap must see history in oldest-first order to count correctly."""
        store = RedisHistoryStore(
            url="redis://fake", redis_client=fake_redis_client, cap=100,
        )
        daemon = CageDaemon(
            socket_path="/tmp/test-daemon-rwc.sock",
            history_store=store,
        )
        # Declare a rolling window cap of 2 requests per 3600s.
        resp = daemon.dispatch({
            "op": "declare_x402", "kind": "rolling_window_cap",
            "max_count": 2, "window_seconds": 3600, "group_by": "provider",
        })
        assert resp["verdict"] == "updated", resp
        base = {
            "currency": "USDC",
            "provider": "anthropic",
            "counterparty": "vendor_x",
            "rail": "x402",
        }
        # First 2 permits in window.
        r1 = daemon.dispatch({"op": "check_payment", "intent": {
            "amount": "10", "timestamp_unix": 1_700_000_000, **base,
        }})
        r2 = daemon.dispatch({"op": "check_payment", "intent": {
            "amount": "10", "timestamp_unix": 1_700_000_100, **base,
        }})
        r3 = daemon.dispatch({"op": "check_payment", "intent": {
            "amount": "10", "timestamp_unix": 1_700_000_200, **base,
        }})
        assert r1["verdict"] == "permit"
        assert r2["verdict"] == "permit"
        assert r3["verdict"] == "reject"
        assert r3["rule_id"].startswith("rolling_window_cap")


# ── Fail-closed semantics via build_history_store ───────────────────────────


class TestFailClosedStartup:
    def test_unreachable_redis_prevents_daemon_start(self) -> None:
        """An operator-configured Redis URL that's down must surface a
        HistoryStoreError at build time. Silent in-memory fallback is NOT
        acceptable because it would produce replicas with divergent
        rolling-window state, leading to incorrect RetryRateLimit verdicts.
        """
        # redis:// URL pointed at a port nothing is listening on; we pass
        # the URL through to redis-py and let its PING preflight fail.
        with pytest.raises(HistoryStoreError) as exc:
            build_history_store(
                "redis",
                redis_url="redis://127.0.0.1:1/0",  # deliberately bogus
                cap=10,
            )
        msg = str(exc.value).lower()
        # Must mention "unreachable" and hint at the escape hatch.
        assert "unreachable" in msg or "could not" in msg
