"""Tests for v0.21.0 Policy-Aware Adaptive Tightening.

Coverage (target: 25+ tests):

* Bounds — ``level`` never exceeds 1.0, ``adjusted_limits`` never
  weaken baseline for any canonical limit name.
* Decay — exponential half-life decay, baseline restoration after
  quiet periods.
* Determinism — identical observation sequence → identical state
  across independent engines.
* Monotonicity — repeated trigger firings drive ``level`` toward 1.0
  without overshoot.
* Each trigger individually — retry_density, denial_rate,
  velocity_spike, identical_request.
* Composite — two triggers combine ADDITIVELY with saturation, not
  multiplicatively.
* Integration with ``AdaptiveTighteningLayer`` — an intent that
  passes baseline is blocked by the tightened clamp.
* Integration with ``PaymentDecision`` — the v0.21.0 envelope carries
  the 4 new optional fields and round-trips cleanly.
* Guaranteed Mode alignment — ``guaranteed_should_pay_x402`` ignores
  adaptive tightening per option (a).
* MCP surface — new fields survive JSON round-trip through the tool.
* Policy respect — every canonical limit is tightened, never weakened.
* Explainer — the 15th describer produces the brief's phrasing.
"""
from __future__ import annotations

import json
from decimal import Decimal

import pytest

from adapter.adaptive_tightening import (
    DEFAULT_HALF_LIFE_SECONDS,
    DEFAULT_TRIGGER_DELTAS,
    DEFAULT_TRIGGER_THRESHOLDS,
    AdaptiveTightening,
    TighteningState,
    estimate_prevented_risk,
)
from adapter.adaptive_tightening_layer import (
    AdaptiveTighteningDecision,
    AdaptiveTighteningLayer,
)
from adapter.decision_explainer import explain_decision
from adapter.decision_schema import (
    DECISION_REASONS,
    PaymentDecision,
    next_action_for,
    rule_id_to_reason,
)


AGENT = "agent-1"
REV = "rev-42"
T0 = 1_700_000_000
INTENT = {
    "amount": "50",
    "provider": "anthropic",
    "counterparty": "cust-1",
    "currency": "USDC",
}


def _force_level(
    engine: AdaptiveTightening,
    *,
    agent_id: str = AGENT,
    revision_id: str = REV,
    triggers: int = 1,
    now_unix: int = T0,
    trigger: str = "retry_density",
) -> None:
    for _ in range(triggers):
        engine.observe(
            event="external_trigger",
            context={
                "agent_id": agent_id,
                "policy_revision_id": revision_id,
                "trigger": trigger,
            },
            now_unix=now_unix,
        )


# ── 1. Bounds ────────────────────────────────────────────────────────────────


class TestBounds:
    def test_level_never_exceeds_one(self) -> None:
        engine = AdaptiveTightening()
        _force_level(engine, triggers=100, now_unix=T0)
        state = engine.current_state(
            agent_id=AGENT,
            policy_revision_id=REV,
            now_unix=T0,
            baseline_limits={"max_requests": 10},
        )
        assert state.level <= 1.0
        assert state.level > 0.0

    def test_adjusted_caps_never_exceed_baseline(self) -> None:
        engine = AdaptiveTightening()
        _force_level(engine, triggers=10, now_unix=T0)
        baseline = {
            "max_requests": 10,
            "max_amount": Decimal("100"),
            "max_per_call": Decimal("50"),
            "spend_cap": Decimal("500"),
            "retry_allowance": 20,
            "cap": 30,
        }
        state = engine.current_state(
            agent_id=AGENT,
            policy_revision_id=REV,
            now_unix=T0,
            baseline_limits=baseline,
        )
        for name, base in baseline.items():
            adjusted = state.adjusted_limits[name]
            if isinstance(base, Decimal):
                assert Decimal(str(adjusted)) <= base, f"{name} widened"
            else:
                assert adjusted <= base, f"{name} widened"

    def test_adjusted_cooldowns_never_shrink(self) -> None:
        engine = AdaptiveTightening()
        _force_level(engine, triggers=10, now_unix=T0)
        baseline = {
            "cooldown_seconds": 30,
            "min_gap_seconds": 5,
            "backoff_seconds": 10,
        }
        state = engine.current_state(
            agent_id=AGENT,
            policy_revision_id=REV,
            now_unix=T0,
            baseline_limits=baseline,
        )
        for name, base in baseline.items():
            assert state.adjusted_limits[name] >= base, f"{name} shrank"

    def test_level_zero_returns_baseline(self) -> None:
        engine = AdaptiveTightening()
        state = engine.current_state(
            agent_id=AGENT,
            policy_revision_id=REV,
            now_unix=T0,
            baseline_limits={"max_requests": 10, "cooldown_seconds": 30},
        )
        assert state.level == 0.0
        assert state.trigger is None
        # No adjusted limits emitted when level is zero.
        assert state.adjusted_limits == {}


# ── 2. Decay ────────────────────────────────────────────────────────────────


class TestDecay:
    def test_one_half_life_decay_halves_level(self) -> None:
        engine = AdaptiveTightening(half_life_seconds=100)
        _force_level(engine, triggers=2, now_unix=T0)  # ~0.8
        state_now = engine.current_state(
            agent_id=AGENT,
            policy_revision_id=REV,
            now_unix=T0,
            baseline_limits={"max_requests": 10},
        )
        level_now = state_now.level
        state_halflife = engine.current_state(
            agent_id=AGENT,
            policy_revision_id=REV,
            now_unix=T0 + 100,
            baseline_limits={"max_requests": 10},
        )
        assert state_halflife.level == pytest.approx(level_now * 0.5, rel=1e-6)

    def test_decay_to_baseline_after_long_quiet(self) -> None:
        engine = AdaptiveTightening(half_life_seconds=60)
        _force_level(engine, triggers=3, now_unix=T0)
        # After 20 half-lives (1200s), level should be well below floor.
        state = engine.current_state(
            agent_id=AGENT,
            policy_revision_id=REV,
            now_unix=T0 + 1200,
            baseline_limits={"max_requests": 10},
        )
        assert state.level == 0.0
        assert state.trigger is None
        assert state.adjusted_limits == {}

    def test_decay_is_continuous(self) -> None:
        """Decay between observations is monotone non-increasing."""
        engine = AdaptiveTightening(half_life_seconds=100)
        _force_level(engine, triggers=3, now_unix=T0)
        levels = [
            engine.current_state(
                agent_id=AGENT,
                policy_revision_id=REV,
                now_unix=T0 + t,
                baseline_limits={"max_requests": 10},
            ).level
            for t in (0, 25, 50, 75, 100, 200)
        ]
        for a, b in zip(levels, levels[1:]):
            assert b <= a + 1e-9, f"level increased during idle: {a} -> {b}"


# ── 3. Determinism ──────────────────────────────────────────────────────────


class TestDeterminism:
    def test_same_sequence_same_final_state(self) -> None:
        engine_a = AdaptiveTightening()
        engine_b = AdaptiveTightening()

        events = [
            ("retry", {"agent_id": AGENT, "policy_revision_id": REV}, T0 + i)
            for i in range(12)
        ] + [
            (
                "decision",
                {
                    "agent_id": AGENT,
                    "policy_revision_id": REV,
                    "outcome": "deny",
                },
                T0 + 20 + i,
            )
            for i in range(5)
        ]
        for e, ctx, t in events:
            engine_a.observe(event=e, context=ctx, now_unix=t)
            engine_b.observe(event=e, context=ctx, now_unix=t)

        s_a = engine_a.current_state(
            agent_id=AGENT,
            policy_revision_id=REV,
            now_unix=T0 + 30,
            baseline_limits={"max_requests": 10, "cooldown_seconds": 30},
        )
        s_b = engine_b.current_state(
            agent_id=AGENT,
            policy_revision_id=REV,
            now_unix=T0 + 30,
            baseline_limits={"max_requests": 10, "cooldown_seconds": 30},
        )
        assert s_a.level == s_b.level
        assert s_a.trigger == s_b.trigger
        assert s_a.adjusted_limits == s_b.adjusted_limits

    def test_no_randomness_in_state(self) -> None:
        """Repeated identical observations produce identical states."""
        for _ in range(3):
            engine = AdaptiveTightening()
            _force_level(engine, triggers=2, now_unix=T0)
            s = engine.current_state(
                agent_id=AGENT,
                policy_revision_id=REV,
                now_unix=T0,
                baseline_limits={"max_requests": 10},
            )
            assert s.level == pytest.approx(0.8, abs=1e-9)


# ── 4. Monotonicity ─────────────────────────────────────────────────────────


class TestMonotonicity:
    def test_repeated_same_trigger_saturates_at_one(self) -> None:
        engine = AdaptiveTightening()
        levels = []
        for i in range(1, 6):
            _force_level(engine, triggers=1, now_unix=T0 + i)
            s = engine.current_state(
                agent_id=AGENT,
                policy_revision_id=REV,
                now_unix=T0 + i,
                baseline_limits={"max_requests": 10},
            )
            levels.append(s.level)
        # Monotone non-decreasing when same-timestamp triggers.
        for a, b in zip(levels, levels[1:]):
            assert b >= a - 1e-9, f"level decreased on new trigger: {a} -> {b}"
        assert levels[-1] == pytest.approx(1.0, abs=1e-9)

    def test_saturation_is_stable(self) -> None:
        """Once saturated, more triggers do not push past 1.0."""
        engine = AdaptiveTightening()
        _force_level(engine, triggers=50, now_unix=T0)
        s = engine.current_state(
            agent_id=AGENT,
            policy_revision_id=REV,
            now_unix=T0,
            baseline_limits={"max_requests": 10},
        )
        assert s.level == pytest.approx(1.0, abs=1e-9)


# ── 5. Per-trigger coverage ─────────────────────────────────────────────────


class TestTriggers:
    def test_retry_density_trigger(self) -> None:
        engine = AdaptiveTightening()
        # 10 retries in <60s crosses the threshold on the 10th.
        for i in range(10):
            engine.observe(
                event="retry",
                context={"agent_id": AGENT, "policy_revision_id": REV},
                now_unix=T0 + i,
            )
        s = engine.current_state(
            agent_id=AGENT,
            policy_revision_id=REV,
            now_unix=T0 + 10,
            baseline_limits={"max_requests": 10},
        )
        assert s.level > 0
        assert s.trigger == "retry_density"

    def test_denial_rate_trigger(self) -> None:
        engine = AdaptiveTightening()
        # 20 decisions, most denies → trigger fires.
        for i in range(20):
            outcome = "deny" if i >= 4 else "allow"
            engine.observe(
                event="decision",
                context={
                    "agent_id": AGENT,
                    "policy_revision_id": REV,
                    "outcome": outcome,
                },
                now_unix=T0 + i,
            )
        s = engine.current_state(
            agent_id=AGENT,
            policy_revision_id=REV,
            now_unix=T0 + 20,
            baseline_limits={"max_requests": 10},
        )
        assert s.level > 0
        assert s.trigger == "denial_rate"

    def test_denial_rate_does_not_fire_on_small_sample(self) -> None:
        engine = AdaptiveTightening()
        engine.observe(
            event="decision",
            context={
                "agent_id": AGENT,
                "policy_revision_id": REV,
                "outcome": "deny",
            },
            now_unix=T0,
        )
        s = engine.current_state(
            agent_id=AGENT,
            policy_revision_id=REV,
            now_unix=T0,
            baseline_limits={"max_requests": 10},
        )
        # One deny → warm-up guard keeps level at baseline.
        assert s.level == 0.0

    def test_velocity_spike_trigger(self) -> None:
        engine = AdaptiveTightening()
        # Feed modest amounts to establish EMA, then a 4× spike.
        for _ in range(6):
            engine.observe(
                event="payment_intent",
                context={
                    "agent_id": AGENT,
                    "policy_revision_id": REV,
                    "intent": {
                        "amount": "10",
                        "provider": "p",
                        "counterparty": "c",
                        "currency": "USDC",
                    },
                },
                now_unix=T0,
            )
        engine.observe(
            event="payment_intent",
            context={
                "agent_id": AGENT,
                "policy_revision_id": REV,
                "intent": {
                    "amount": "400",
                    "provider": "p",
                    "counterparty": "c",
                    "currency": "USDC",
                },
            },
            now_unix=T0 + 1,
        )
        s = engine.current_state(
            agent_id=AGENT,
            policy_revision_id=REV,
            now_unix=T0 + 1,
            baseline_limits={"max_requests": 10},
        )
        assert s.level > 0
        assert s.trigger == "velocity_spike"

    def test_identical_request_trigger(self) -> None:
        engine = AdaptiveTightening()
        # Fire 4 identical intents inside the 30s window.
        for i in range(4):
            engine.observe(
                event="payment_intent",
                context={
                    "agent_id": AGENT,
                    "policy_revision_id": REV,
                    "intent": INTENT,
                },
                now_unix=T0 + i,
            )
        s = engine.current_state(
            agent_id=AGENT,
            policy_revision_id=REV,
            now_unix=T0 + 4,
            baseline_limits={"max_requests": 10},
        )
        assert s.level > 0
        assert s.trigger == "identical_request"

    def test_identical_request_respects_window(self) -> None:
        # Use a custom short threshold + disable velocity_spike contribution
        # so only the identical-request trigger is measured.
        engine = AdaptiveTightening(
            trigger_deltas={
                "retry_density": 0.4,
                "denial_rate": 0.3,
                "velocity_spike": 0.0,  # silence this channel for the test.
                "identical_request": 0.4,
            },
        )
        # 4 intents spaced 15s apart = span 45s > 30s window. With the
        # pruning rule, the older ones fall out of the window before
        # the 4th fires so the fingerprint count never hits threshold.
        for i in range(4):
            engine.observe(
                event="payment_intent",
                context={
                    "agent_id": AGENT,
                    "policy_revision_id": REV,
                    "intent": INTENT,
                },
                now_unix=T0 + i * 15,
            )
        s = engine.current_state(
            agent_id=AGENT,
            policy_revision_id=REV,
            now_unix=T0 + 45,
            baseline_limits={"max_requests": 10},
        )
        assert s.level == 0.0


# ── 6. Composite additive behaviour ─────────────────────────────────────────


class TestComposite:
    def test_two_triggers_combine_additively(self) -> None:
        engine = AdaptiveTightening()
        _force_level(engine, triggers=1, now_unix=T0, trigger="retry_density")
        _force_level(engine, triggers=1, now_unix=T0, trigger="denial_rate")
        s = engine.current_state(
            agent_id=AGENT,
            policy_revision_id=REV,
            now_unix=T0,
            baseline_limits={"max_requests": 10},
        )
        expected = min(
            1.0,
            DEFAULT_TRIGGER_DELTAS["retry_density"]
            + DEFAULT_TRIGGER_DELTAS["denial_rate"],
        )
        assert s.level == pytest.approx(expected, abs=1e-9)

    def test_not_multiplicative(self) -> None:
        """Two triggers must SUM (with saturation), never MULTIPLY."""
        engine = AdaptiveTightening()
        _force_level(engine, triggers=1, now_unix=T0, trigger="retry_density")
        _force_level(engine, triggers=1, now_unix=T0, trigger="denial_rate")
        s = engine.current_state(
            agent_id=AGENT,
            policy_revision_id=REV,
            now_unix=T0,
            baseline_limits={"max_requests": 10},
        )
        product = (
            DEFAULT_TRIGGER_DELTAS["retry_density"]
            * DEFAULT_TRIGGER_DELTAS["denial_rate"]
        )
        # Additive level (~0.7) should be well above the multiplicative (~0.12).
        assert s.level > product + 0.3

    def test_three_triggers_saturate(self) -> None:
        engine = AdaptiveTightening()
        for trig in ("retry_density", "denial_rate", "velocity_spike"):
            _force_level(engine, triggers=1, now_unix=T0, trigger=trig)
        s = engine.current_state(
            agent_id=AGENT,
            policy_revision_id=REV,
            now_unix=T0,
            baseline_limits={"max_requests": 10},
        )
        assert s.level == pytest.approx(1.0, abs=1e-9)


# ── 7. Policy respect (no weakening) ────────────────────────────────────────


class TestPolicyRespect:
    @pytest.mark.parametrize(
        "name, baseline",
        [
            ("max_requests", 10),
            ("max_amount", Decimal("500")),
            ("max_per_call", Decimal("50")),
            ("spend_cap", Decimal("1000")),
            ("retry_allowance", 20),
            ("cooldown_seconds", 30),
            ("min_gap_seconds", 5),
            ("backoff_seconds", 2),
        ],
    )
    def test_limit_never_weakens(self, name: str, baseline) -> None:
        engine = AdaptiveTightening()
        _force_level(engine, triggers=10, now_unix=T0)
        state = engine.current_state(
            agent_id=AGENT,
            policy_revision_id=REV,
            now_unix=T0,
            baseline_limits={name: baseline},
        )
        adjusted = state.adjusted_limits[name]
        if name in ("cooldown_seconds", "min_gap_seconds", "backoff_seconds"):
            assert adjusted >= baseline, f"{name} shrank baseline"
        else:
            if isinstance(baseline, Decimal):
                assert Decimal(str(adjusted)) <= baseline, (
                    f"{name} widened baseline"
                )
            else:
                assert adjusted <= baseline, f"{name} widened baseline"

    def test_unknown_key_is_passthrough(self) -> None:
        engine = AdaptiveTightening()
        _force_level(engine, triggers=3, now_unix=T0)
        state = engine.current_state(
            agent_id=AGENT,
            policy_revision_id=REV,
            now_unix=T0,
            baseline_limits={"custom_key": 42},
        )
        assert state.adjusted_limits["custom_key"] == 42

    def test_different_revision_isolates_state(self) -> None:
        engine = AdaptiveTightening()
        _force_level(engine, triggers=3, now_unix=T0)
        # Fresh revision → fresh bucket → baseline.
        state = engine.current_state(
            agent_id=AGENT,
            policy_revision_id="other-revision",
            now_unix=T0,
            baseline_limits={"max_requests": 10},
        )
        assert state.level == 0.0


# ── 8. Integration with the layer ──────────────────────────────────────────


class TestLayerIntegration:
    def test_layer_allows_at_baseline(self) -> None:
        engine = AdaptiveTightening()
        layer = AdaptiveTighteningLayer(engine)
        decision = layer.check(
            agent_id=AGENT,
            policy_revision_id=REV,
            intent={**INTENT, "attempt_count": 3},
            baseline_limits={"max_requests": 10},
            now_unix=T0,
        )
        assert decision.allowed is True
        assert decision.reason == "allowed"
        assert decision.tightening_level == 0.0

    def test_layer_blocks_tightened_retry_overflow(self) -> None:
        engine = AdaptiveTightening()
        layer = AdaptiveTighteningLayer(engine)
        _force_level(engine, triggers=2, now_unix=T0)
        decision = layer.check(
            agent_id=AGENT,
            policy_revision_id=REV,
            intent={**INTENT, "attempt_count": 5},
            baseline_limits={"max_requests": 10, "cooldown_seconds": 30},
            baseline_velocity=Decimal("20"),
            now_unix=T0,
        )
        # level ~0.8 → max_requests shrinks to <10 (around 1-2). 5 > that.
        assert decision.allowed is False
        assert decision.reason == "adaptive_tightening_triggered"
        assert decision.tightening_level > 0
        assert decision.adjusted_limits["max_requests"] < 10
        assert decision.prevented_risk is not None
        assert decision.prevented_risk["based_on"] == "ema_velocity"

    def test_layer_admits_tightened_but_still_under_limit(self) -> None:
        engine = AdaptiveTightening()
        layer = AdaptiveTighteningLayer(engine)
        _force_level(engine, triggers=1, now_unix=T0)  # ~0.4
        decision = layer.check(
            agent_id=AGENT,
            policy_revision_id=REV,
            intent={**INTENT, "attempt_count": 1},
            baseline_limits={"max_requests": 100},
            now_unix=T0,
        )
        assert decision.allowed is True
        assert decision.tightening_level > 0

    def test_layer_wire_matches_brief_shape(self) -> None:
        engine = AdaptiveTightening()
        layer = AdaptiveTighteningLayer(engine)
        # Drive level high enough that max_requests=1 clamp blocks 4.
        _force_level(engine, triggers=2, now_unix=T0)
        decision = layer.check(
            agent_id=AGENT,
            policy_revision_id=REV,
            intent={**INTENT, "attempt_count": 4},
            baseline_limits={"max_requests": 10, "cooldown_seconds": 30},
            baseline_velocity=Decimal("20"),
            now_unix=T0,
            denial_window_seconds=60,
        )
        wire = decision.to_wire()
        assert wire["allowed"] is False
        assert wire["reason"] == "adaptive_tightening_triggered"
        assert 0 <= wire["tightening_level"] <= 1
        assert "max_requests" in wire["adjusted_limits"]
        assert "cooldown_seconds" in wire["adjusted_limits"]
        assert wire["trigger"] is not None
        assert "estimated_spend_blocked" in wire["prevented_risk"]


# ── 9. Decision schema integration ─────────────────────────────────────────


class TestSchemaIntegration:
    def test_adaptive_tightening_reason_in_taxonomy(self) -> None:
        assert "adaptive_tightening_triggered" in DECISION_REASONS

    def test_next_action_routes_to_cooldown(self) -> None:
        assert (
            next_action_for("adaptive_tightening_triggered", retry_after=45)
            == "wait_for_cooldown"
        )
        assert (
            next_action_for("adaptive_tightening_triggered", retry_after=None)
            == "retry_later"
        )

    def test_payment_decision_envelope_matches_brief(self) -> None:
        """Exact MCP wire shape from the brief round-trips cleanly."""
        decision = PaymentDecision(
            allowed=False,
            reason="adaptive_tightening_triggered",
            tightening_level=0.7,
            adjusted_limits={"max_requests": 3, "cooldown_seconds": 45},
            trigger="retry_density_exceeded",
            prevented_risk={"estimated_spend_blocked_usd": "1200"},
            next_action="wait_for_cooldown",
        )
        wire = decision.to_wire()
        assert wire["allowed"] is False
        assert wire["reason"] == "adaptive_tightening_triggered"
        assert wire["tightening_level"] == 0.7
        assert wire["adjusted_limits"] == {
            "max_requests": 3,
            "cooldown_seconds": 45,
        }
        assert wire["trigger"] == "retry_density_exceeded"
        assert wire["prevented_risk"] == {
            "estimated_spend_blocked_usd": "1200"
        }

    def test_payment_decision_envelope_round_trip(self) -> None:
        payload = {
            "allowed": False,
            "reason": "adaptive_tightening_triggered",
            "tightening_level": 0.7,
            "adjusted_limits": {"max_requests": 3, "cooldown_seconds": 45},
            "trigger": "retry_density_exceeded",
            "prevented_risk": {"estimated_spend_blocked_usd": "1200"},
        }
        parsed = PaymentDecision.from_wire(payload)
        assert parsed.reason == "adaptive_tightening_triggered"
        assert parsed.tightening_level == pytest.approx(0.7)
        assert parsed.adjusted_limits == {
            "max_requests": 3,
            "cooldown_seconds": 45,
        }
        assert parsed.trigger == "retry_density_exceeded"
        # Round-trip to JSON survives untouched.
        js = json.dumps(parsed.to_wire(), sort_keys=True)
        re_parsed = PaymentDecision.from_wire(json.loads(js))
        assert re_parsed.to_wire() == parsed.to_wire()

    def test_rule_id_to_reason_adaptive_tightening(self) -> None:
        # Unknown or new rule_id "adaptive_tightening" falls back to
        # policy_inconclusive (the explainer has its own describer, but
        # the rule_id->reason map is intentionally conservative).
        reason = rule_id_to_reason("adaptive_tightening")
        assert reason in ("policy_inconclusive", "adaptive_tightening_triggered")

    def test_backward_compat_default_fields_none(self) -> None:
        d = PaymentDecision(allowed=True, reason="allowed")
        wire = d.to_wire()
        assert wire["tightening_level"] is None
        assert wire["adjusted_limits"] is None
        assert wire["trigger"] is None
        assert wire["prevented_risk"] is None


# ── 10. Guaranteed Mode alignment (option a) ───────────────────────────────


class TestGuaranteedModeIgnoresTightening:
    def test_adaptive_tightening_not_in_guaranteed_features(self) -> None:
        from adapter.guaranteed_runtime import GUARANTEED_RUNTIME_FEATURES

        assert "adaptive_tightening" not in GUARANTEED_RUNTIME_FEATURES

    def test_guaranteed_ignores_active_tightening(self) -> None:
        """Option (a): Guaranteed Mode enforces the baseline only.

        Flexible Mode applies the adaptive clamp on top; Guaranteed Mode
        ignores the tightening state. This test verifies the stance:
        calling ``guaranteed_should_pay_x402`` with an intent that would
        be blocked by the Flexible-Mode adaptive clamp is STILL admitted
        by Guaranteed Mode when the proof artifact and bounded feature
        set are satisfied. Tightening never weakens Guaranteed Mode; it
        is ignored because it would add constraints that aren't in the
        totality proof's envelope.
        """
        from dataclasses import dataclass, field

        from adapter.guaranteed_runtime import (
            GUARANTEED_RUNTIME_FEATURES,
            guaranteed_should_pay_x402,
        )

        @dataclass(frozen=True)
        class FakeRevision:
            id: str = "rev-42"

        @dataclass(frozen=True)
        class FakeArtifact:
            artifact_id: str = "art-1"
            policy_revision_id: str = "rev-42"
            proof_result: str = "consistent"

            def to_bytes(self) -> bytes:
                return b"artifact-bytes"

        class FakeIntent:
            runtime_feature = "spend_cap"

        # Guaranteed call — the Flexible-Mode engine is independent and
        # carries active tightening; Guaranteed path must not observe it.
        engine = AdaptiveTightening()
        _force_level(engine, triggers=10, now_unix=T0)

        decision = guaranteed_should_pay_x402(
            intent=FakeIntent(),
            policy_revision=FakeRevision(),
            proof_artifact=FakeArtifact(),
            guard_state={"foo": "bar"},
        )
        assert decision.allow is True
        assert decision.mode == "guaranteed"


# ── 11. MCP round-trip ─────────────────────────────────────────────────────


class TestMcpRoundTrip:
    def test_mcp_decision_payload_survives_json(self) -> None:
        """The canonical brief payload round-trips through JSON unchanged."""
        payload = {
            "allowed": False,
            "reason": "adaptive_tightening_triggered",
            "tightening_level": 0.7,
            "adjusted_limits": {"max_requests": 3, "cooldown_seconds": 45},
            "trigger": "retry_density_exceeded",
            "prevented_risk": {"estimated_spend_blocked_usd": 1200},
        }
        js = json.dumps(payload, sort_keys=True)
        back = json.loads(js)
        assert back == payload
        # And the schema's from_wire accepts the same payload.
        parsed = PaymentDecision.from_wire(payload)
        assert parsed.reason == "adaptive_tightening_triggered"


# ── 12. Explainer ──────────────────────────────────────────────────────────


class TestExplainer:
    def test_15th_describer_fires_on_adaptive_tightening(self) -> None:
        record = {
            "verdict": "reject",
            "rule_id": "adaptive_tightening",
            "reason_text": "adaptive tightening blocked retry flood",
            "_bundle_witness": (
                "level=0.7, trigger=retry_density, max_requests=3, "
                "cooldown_seconds=45, prevented_spend=1200, half_life=900"
            ),
            "intent": {"currency": "USDC"},
        }
        explanation = explain_decision(record)
        assert explanation.outcome == "reject"
        assert explanation.rule_id == "adaptive_tightening"
        assert explanation.invariant_class == "AdaptiveTightening"
        narrative = explanation.narrative
        # Brief's exact phrasing cues:
        assert "adaptive tightening" in narrative.lower()
        assert "level 0.7" in narrative
        assert "trigger: retry density" in narrative.lower()
        assert "max 3 requests" in narrative
        assert "45s cooldown" in narrative
        assert "estimated spend blocked" in narrative.lower()
        assert "1200" in narrative
        assert "baseline" in narrative.lower()
        # Machine-readable dict carries the structured fields.
        assert explanation.machine_readable["tightening_level"] == "0.7"
        assert explanation.machine_readable["trigger"] == "retry_density"


# ── 13. Prevented-risk estimator ──────────────────────────────────────────


class TestPreventedRisk:
    def test_basic_projection(self) -> None:
        est = estimate_prevented_risk(
            baseline_velocity=Decimal("20"),
            current_denial_window_s=60,
            currency="USDC",
        )
        assert est["estimated_spend_blocked"] == "1200.00"
        assert est["estimated_spend_blocked_usd"] == "1200.00"
        assert est["window_seconds"] == 60
        assert est["currency"] == "USDC"
        assert est["based_on"] == "ema_velocity"
        assert "estimate" in est["caveat"].lower()

    def test_non_usd_currency_has_null_usd_field(self) -> None:
        est = estimate_prevented_risk(
            baseline_velocity=Decimal("5"),
            current_denial_window_s=10,
            currency="EUR",
        )
        assert est["estimated_spend_blocked_usd"] is None
        assert est["estimated_spend_blocked"] == "50.00"

    def test_negative_velocity_floored(self) -> None:
        est = estimate_prevented_risk(
            baseline_velocity=-10.0,
            current_denial_window_s=60,
            currency="USD",
        )
        assert est["estimated_spend_blocked"] == "0.00"
