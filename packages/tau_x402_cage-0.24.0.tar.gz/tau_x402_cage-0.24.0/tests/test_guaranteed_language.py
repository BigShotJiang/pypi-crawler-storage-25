"""Tests for adapter.guaranteed_language (v0.19.0 Deliverable 1)."""
from __future__ import annotations

import json
from decimal import Decimal

import pytest

from adapter.guaranteed_errors import GuaranteedFailureCode
from adapter.guaranteed_language import (
    GUARANTEED_LANGUAGE_VERSION,
    GuaranteedLanguage,
)
from adapter.invariants import (
    CounterpartyConstraint,
    JurisdictionRule,
    MaxPerCall,
    MutualExclusion,
    ProviderAllowlist,
    RetryRateLimit,
    RollingWindowCap,
    SpendingCap,
)


# ── shipped surface ────────────────────────────────────────────────────


def test_language_version_is_stable_semver():
    # v1.2.0 covers BOTH changes: 9 rule types (agent β) + the new
    # SUPPORTED_META_POLICIES meta-policy tier (agent γ). Bump here
    # when the tier widens again.
    assert GUARANTEED_LANGUAGE_VERSION == "1.2.0"
    # Shape check: dotted 3-segment semver.
    parts = GUARANTEED_LANGUAGE_VERSION.split(".")
    assert len(parts) == 3
    assert all(p.isdigit() for p in parts)


def test_v1_supported_rule_types_is_the_narrow_starter_set():
    """v1.2.0 admits the v1.1.0 set plus three enum / composition rule
    types over pure bv BA."""
    assert GuaranteedLanguage.SUPPORTED_RULE_TYPES == frozenset(
        {
            "SpendingCap",
            "MaxPerCall",
            "ProviderAllowlist",
            "RetryRateLimit",
            "RollingWindowCap",
            "BurstVelocityCap",
            "JurisdictionRule",
            "CounterpartyConstraint",
            "MutualExclusion",
        }
    )


def test_sets_are_all_frozen():
    """Every SUPPORTED_* collection is frozenset so callers cannot
    silently widen the tier via mutation."""
    assert isinstance(GuaranteedLanguage.SUPPORTED_RULE_TYPES, frozenset)
    assert isinstance(GuaranteedLanguage.SUPPORTED_COMPOSITION, frozenset)
    assert isinstance(GuaranteedLanguage.SUPPORTED_TEMPORAL, frozenset)
    assert isinstance(GuaranteedLanguage.SUPPORTED_MUTATION_FORMS, frozenset)


def test_v1_has_past_ltl_temporal_ops():
    # v1.1.0: G, O, H are admitted (past-LTL unlocks once upstream Tau
    # ships bugs 1/3/4 patches). Future modalities still excluded.
    assert GuaranteedLanguage.SUPPORTED_TEMPORAL == frozenset({"G", "O", "H"})


def test_v1_composition_is_conjunction_only():
    assert GuaranteedLanguage.SUPPORTED_COMPOSITION == frozenset({"conjunction"})


def test_v1_mutation_forms():
    assert GuaranteedLanguage.SUPPORTED_MUTATION_FORMS == frozenset(
        {
            "add_invariant",
            "remove_invariant",
            "tighten_limit",
            "tighten_window",
            "shorten_retry_cooldown",
            "tighten_burst_cap",
        }
    )


# ── is_supported() for every invariant type ────────────────────────────


def test_is_supported_admits_max_per_call():
    ok, code = GuaranteedLanguage.is_supported(MaxPerCall(max_amount=Decimal("50")))
    assert ok is True
    assert code is None


def test_is_supported_admits_provider_allowlist():
    ok, code = GuaranteedLanguage.is_supported(
        ProviderAllowlist(providers=frozenset({"anthropic", "openai"}))
    )
    assert ok is True
    assert code is None


def test_is_supported_admits_spending_cap_per_tx():
    ok, code = GuaranteedLanguage.is_supported(
        SpendingCap(max_amount=Decimal("25"), scope="per_tx")
    )
    assert ok is True
    assert code is None


def test_is_supported_admits_spending_cap_per_window():
    """v1.1.0: windowed scopes admit once upstream Tau patches land."""
    inv = SpendingCap(
        max_amount=Decimal("100"),
        scope="per_window",
        window_seconds=86400,
    )
    ok, code = GuaranteedLanguage.is_supported(inv)
    assert ok is True
    assert code is None


def test_is_supported_admits_spending_cap_per_provider_per_window():
    inv = SpendingCap(
        max_amount=Decimal("100"),
        scope="per_provider_per_window",
        window_seconds=86400,
        provider="openai",
    )
    ok, code = GuaranteedLanguage.is_supported(inv)
    assert ok is True
    assert code is None


def test_is_supported_admits_retry_rate_limit():
    """v1.1.0: RetryRateLimit admits once the past-LTL patch is upstream."""
    ok, code = GuaranteedLanguage.is_supported(RetryRateLimit(min_gap_seconds=30))
    assert ok is True
    assert code is None


def test_is_supported_admits_rolling_window_cap():
    ok, code = GuaranteedLanguage.is_supported(
        RollingWindowCap(max_count=10, window_seconds=60)
    )
    assert ok is True
    assert code is None


def test_is_supported_admits_jurisdiction_rule_enum_bv_variant():
    """v1.2.0: JurisdictionRule with no additional_invariants is the
    enum_bv variant and admits in Guaranteed Mode."""
    ok, code = GuaranteedLanguage.is_supported(
        JurisdictionRule(jurisdiction="EU")
    )
    assert ok is True
    assert code is None


def test_is_supported_rejects_jurisdiction_rule_nested_variant():
    """v1.2.0: the nested-composition variant stays out."""
    ok, code = GuaranteedLanguage.is_supported(
        JurisdictionRule(
            jurisdiction="EU",
            additional_invariants=(MaxPerCall(max_amount=Decimal("1")),),
        )
    )
    assert ok is False
    assert code is GuaranteedFailureCode.UNSUPPORTED_FOR_GUARANTEED_MODE


def test_is_supported_admits_counterparty_allowlist_variant():
    """v1.2.0: pure-allowlist CounterpartyConstraint admits."""
    ok, code = GuaranteedLanguage.is_supported(
        CounterpartyConstraint(approved_ids=frozenset({"a"}))
    )
    assert ok is True
    assert code is None


def test_is_supported_rejects_counterparty_sanctions_variant():
    """v1.2.0: sanctions-negation CounterpartyConstraint stays out."""
    ok, code = GuaranteedLanguage.is_supported(
        CounterpartyConstraint(
            approved_ids=frozenset({"a"}),
            sanctioned_ids=frozenset({"evil-inc"}),
        )
    )
    assert ok is False
    assert code is GuaranteedFailureCode.UNSUPPORTED_FOR_GUARANTEED_MODE


def test_is_supported_admits_mutual_exclusion_rule_composition_variant():
    """v1.2.0: the two-group MutualExclusion admits via bv composition."""
    ok, code = GuaranteedLanguage.is_supported(
        MutualExclusion(group_a=frozenset({"a"}), group_b=frozenset({"b"}))
    )
    assert ok is True
    assert code is None


def test_is_supported_rejects_non_invariant():
    """Defensive: passing a non-Invariant object fails closed."""
    ok, code = GuaranteedLanguage.is_supported("not an invariant")  # type: ignore[arg-type]
    assert ok is False
    assert code is GuaranteedFailureCode.UNSUPPORTED_FOR_GUARANTEED_MODE

    ok, code = GuaranteedLanguage.is_supported(None)  # type: ignore[arg-type]
    assert ok is False
    assert code is GuaranteedFailureCode.UNSUPPORTED_FOR_GUARANTEED_MODE


# ── composition / temporal / mutation form predicates ──────────────────


def test_is_composition_supported():
    assert GuaranteedLanguage.is_composition_supported("conjunction") is True
    assert GuaranteedLanguage.is_composition_supported("disjunction") is False
    assert GuaranteedLanguage.is_composition_supported("implication") is False
    assert GuaranteedLanguage.is_composition_supported("") is False


def test_is_temporal_supported_v1_1():
    # v1.1.0 admits G (always), O (once — past existence), H (historically —
    # past universality). Future / binary modalities stay out.
    for op in ("G", "O", "H"):
        assert GuaranteedLanguage.is_temporal_supported(op) is True
    for op in ("F", "X", "U", "W"):
        assert GuaranteedLanguage.is_temporal_supported(op) is False


def test_is_mutation_form_supported():
    assert GuaranteedLanguage.is_mutation_form_supported("add_invariant") is True
    assert GuaranteedLanguage.is_mutation_form_supported("remove_invariant") is True
    assert GuaranteedLanguage.is_mutation_form_supported("tighten_limit") is True
    # v1.1.0 adds three windowed-tightening forms.
    assert GuaranteedLanguage.is_mutation_form_supported("tighten_window") is True
    assert (
        GuaranteedLanguage.is_mutation_form_supported("shorten_retry_cooldown")
        is True
    )
    assert GuaranteedLanguage.is_mutation_form_supported("tighten_burst_cap") is True
    # Weakening forms still rejected.
    assert GuaranteedLanguage.is_mutation_form_supported("loosen_limit") is False
    assert GuaranteedLanguage.is_mutation_form_supported("replace_invariant") is False


# ── describe() surface ─────────────────────────────────────────────────


def test_describe_is_json_serializable():
    surface = GuaranteedLanguage.describe()
    blob = json.dumps(surface)
    assert GUARANTEED_LANGUAGE_VERSION in blob


def test_describe_contains_language_version():
    surface = GuaranteedLanguage.describe()
    assert surface["language_version"] == GUARANTEED_LANGUAGE_VERSION


def test_describe_is_stable_across_calls():
    """Deterministic: two calls return equal dicts. Auditors diff on it."""
    a = GuaranteedLanguage.describe()
    b = GuaranteedLanguage.describe()
    assert a == b
    assert json.dumps(a, sort_keys=True) == json.dumps(b, sort_keys=True)


def test_describe_returns_fresh_objects_no_aliasing():
    """Mutating a returned dict must not leak back into the class."""
    a = GuaranteedLanguage.describe()
    a["supported_rule_types"].append("HACKED")
    b = GuaranteedLanguage.describe()
    assert "HACKED" not in b["supported_rule_types"]


def test_describe_surfaces_exclusion_reasons():
    """v1.2.0 moves the three enum / composition classes into the tier
    in their pure-bv variants; the richer variants stay excluded and
    appear in the map with variant-qualified keys so audit readers can
    see which shape of a class was held out vs admitted."""
    surface = GuaranteedLanguage.describe()
    excluded = surface["excluded_rule_types_with_reason"]
    # v1.2.0 variant-level holdouts:
    assert "JurisdictionRule.nested_composition" in excluded
    assert "JurisdictionRule.nlang" in excluded
    assert "CounterpartyConstraint.sanctions_negation" in excluded
    assert "CounterpartyConstraint.nlang" in excluded
    # Each reason string should be non-empty.
    for reason in excluded.values():
        assert isinstance(reason, str)
        assert reason.strip()
    # The past-LTL holdouts and the bare class-level keys are no longer
    # in the map — they moved into SUPPORTED_RULE_TYPES at v1.1.0 / v1.2.0.
    for admitted_bare_key in (
        "RetryRateLimit",
        "RollingWindowCap",
        "BurstVelocityCap",
        "JurisdictionRule",
        "CounterpartyConstraint",
        "MutualExclusion",
    ):
        assert admitted_bare_key not in excluded


def test_describe_exposes_scopes_dict():
    surface = GuaranteedLanguage.describe()
    assert surface["supported_scopes"]["SpendingCap"] == [
        "per_tx",
        "per_window",
        "per_provider_per_window",
    ]


# ── order-independence (Test 8 from the brief, this slice) ─────────────


def test_is_supported_is_order_independent():
    """Equivalent rule sets in different order yield the same validation
    outcome per-rule. Since is_supported is pure (invariant-in,
    bool-out), this is a sanity check that no hidden state leaks."""
    rules_a = [
        MaxPerCall(max_amount=Decimal("50")),
        ProviderAllowlist(providers=frozenset({"a", "b"})),
        SpendingCap(max_amount=Decimal("25"), scope="per_tx"),
    ]
    rules_b = list(reversed(rules_a))

    results_a = [GuaranteedLanguage.is_supported(r) for r in rules_a]
    results_b = [GuaranteedLanguage.is_supported(r) for r in rules_b]

    # Every individual rule is admitted regardless of position.
    for ok, code in results_a + results_b:
        assert ok is True
        assert code is None

    # Aggregated admission is order-independent.
    all_admitted_a = all(ok for ok, _ in results_a)
    all_admitted_b = all(ok for ok, _ in results_b)
    assert all_admitted_a == all_admitted_b is True


def test_describe_lists_are_sorted_for_determinism():
    """Auditors want byte-stable output. Every list-valued field is
    returned sorted."""
    surface = GuaranteedLanguage.describe()
    assert surface["supported_rule_types"] == sorted(
        surface["supported_rule_types"]
    )
    assert surface["supported_composition"] == sorted(
        surface["supported_composition"]
    )
    assert surface["supported_mutation_forms"] == sorted(
        surface["supported_mutation_forms"]
    )
