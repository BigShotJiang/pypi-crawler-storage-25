"""Decisive acceptance-gate tests for strict mode.

These tests enforce the Patch 13 acceptance criteria from the v0.3.3 brief:

1. strict mode rejects if Tau is unavailable, even when pattern passes
2. strict mode rejects on Tau inconclusive
3. strict mode admits only on Tau SAT
4. admitted strict-mode token carries prover_mode=strict + complete proof
5. an unsupported_fragment invariant is rejected with a specific category
6. verified mode admits on Tau inconclusive with downgraded proof_strength

The tests exercise the daemon directly (no socket) by instantiating
CageDaemon with injected provers, keeping them fast and deterministic.
"""
from __future__ import annotations

from decimal import Decimal
from unittest.mock import patch

import pytest

from adapter.invariants import (
    CounterpartyConstraint,
    MaxPerCall,
    ProviderAllowlist,
    RetryRateLimit,
)
from adapter.prover import (
    ConsistencyProver,
    Contradiction,
    InconclusiveProof,
    ProofToken,
    PythonPatternProver,
)
from daemon.server import CageDaemon


# ── injectable prover doubles ────────────────────────────────────────────────


class _SatTauProver:
    """Stand-in TauConsistencyProver that always returns a complete ProofToken."""
    backend = "tau-stub-sat"

    def prove(self, invariants, predecessor_hash=None):
        import secrets, time, hashlib
        config_hash = hashlib.sha256(repr(sorted((type(i).__name__, repr(i)) for i in invariants)).encode()).hexdigest()
        return ProofToken(
            config_hash=config_hash,
            issued_at_unix=int(time.time()),
            backend="tau",
            proof_strength="complete",
            nonce=secrets.token_hex(8),
            predecessor_hash=predecessor_hash,
            fragment_version="v1",
            compile_hash="deadbeef" * 8,
        )


class _UnsatTauProver:
    backend = "tau-stub-unsat"

    def prove(self, invariants, predecessor_hash=None):
        return Contradiction(
            left="tau-stub",
            right="tau-stub",
            reason="Tau proved spec unsatisfiable (stub)",
            backend="tau",
        )


class _InconclusiveTauProver:
    backend = "tau-stub-inconclusive"

    def prove(self, invariants, predecessor_hash=None):
        return InconclusiveProof(
            category="timeout",
            reason="Tau exceeded 10s budget on stub",
            backend="tau",
        )


class _UnavailableTauProver:
    backend = "tau-stub-unavailable"

    def prove(self, invariants, predecessor_hash=None):
        return InconclusiveProof(
            category="unavailable",
            reason="Tau binary not on PATH (stub)",
            backend="tau",
        )


# ── fixtures ─────────────────────────────────────────────────────────────────


def _daemon(mode: str, tau_prover: ConsistencyProver | None, tmp_path):
    """CageDaemon without serving; we drive _apply_revision via op dispatch."""
    sock = str(tmp_path / "strict.sock")
    return CageDaemon(
        socket_path=sock,
        prover=PythonPatternProver(),
        prover_mode=mode,
        tau_prover=tau_prover,
    )


# ── strict mode acceptance tests ─────────────────────────────────────────────


class TestStrictModeRejectsWhenTauInconclusive:
    def test_inconclusive_blocks_admission(self, tmp_path) -> None:
        d = _daemon("strict", _InconclusiveTauProver(), tmp_path)
        resp = d.dispatch({
            "op": "declare_x402", "kind": "max_per_call", "max_amount": "50",
        })
        assert resp["verdict"] == "inconclusive"
        assert resp["category"] == "timeout"
        assert resp["prover_mode"] == "strict"

    def test_unavailable_blocks_admission(self, tmp_path) -> None:
        d = _daemon("strict", _UnavailableTauProver(), tmp_path)
        resp = d.dispatch({
            "op": "declare_x402", "kind": "max_per_call", "max_amount": "50",
        })
        assert resp["verdict"] == "inconclusive"
        assert resp["category"] == "unavailable"

    def test_registry_unchanged_after_inconclusive_rejection(self, tmp_path) -> None:
        d = _daemon("strict", _InconclusiveTauProver(), tmp_path)
        d.dispatch({"op": "declare_x402", "kind": "max_per_call", "max_amount": "50"})
        active = d.dispatch({"op": "active_x402"})
        assert active["active_invariants"] == 0


class TestStrictModeAdmitsOnlyOnTauSat:
    def test_sat_admits_with_complete_proof(self, tmp_path) -> None:
        d = _daemon("strict", _SatTauProver(), tmp_path)
        resp = d.dispatch({
            "op": "declare_x402", "kind": "max_per_call", "max_amount": "50",
        })
        assert resp["verdict"] == "updated"
        token = resp["proof_token"]
        assert token["proof_strength"] == "complete"
        assert token["prover_mode"] == "strict"
        assert token["fragment_version"] == "v1"
        assert token["compile_hash"]  # non-empty

    def test_unsat_rejects(self, tmp_path) -> None:
        d = _daemon("strict", _UnsatTauProver(), tmp_path)
        resp = d.dispatch({
            "op": "declare_x402", "kind": "max_per_call", "max_amount": "50",
        })
        assert resp["verdict"] == "contradiction"


class TestVerifiedModeAdmitsOnInconclusive:
    def test_inconclusive_admits_with_downgraded_strength(self, tmp_path) -> None:
        d = _daemon("verified", _InconclusiveTauProver(), tmp_path)
        resp = d.dispatch({
            "op": "declare_x402", "kind": "max_per_call", "max_amount": "50",
        })
        assert resp["verdict"] == "updated"
        token = resp["proof_token"]
        # verified mode records Tau's inconclusive category in the strength label
        assert "tau-timeout" in token["proof_strength"]
        assert token["prover_mode"] == "verified"


class TestCompatModePreservedBehavior:
    def test_compat_mode_does_not_call_tau_at_all(self, tmp_path) -> None:
        """In compat mode the daemon ignores Tau entirely -- v0.3.2 behavior."""
        # Inject a Tau prover that would FAIL if called.
        class _ShouldNotRun:
            backend = "should-not-run"
            def prove(self, *a, **kw):
                raise AssertionError("compat mode must not call Tau")
        d = _daemon("compat", _ShouldNotRun(), tmp_path)
        resp = d.dispatch({
            "op": "declare_x402", "kind": "max_per_call", "max_amount": "50",
        })
        assert resp["verdict"] == "updated"
        assert resp["proof_token"]["proof_strength"] == "pattern"
        assert resp["proof_token"]["prover_mode"] == "compat"


class TestHealthReportsMode:
    def test_health_shows_prover_mode(self, tmp_path) -> None:
        d = _daemon("strict", _SatTauProver(), tmp_path)
        h = d.dispatch({"op": "health"})
        assert h["prover_mode"] == "strict"
        assert "tau_available" in h
