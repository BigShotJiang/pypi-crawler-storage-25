"""Tests for the v0.23.0 ``tau-x402 demo hero`` subcommand.

This is the convenience wrapper that forwards to ``python3
demos/hero_retry_loop.py``. The tests guard three contracts:

1. The brief's canonical JSON shape round-trips (Test 5 from the
   brief).
2. Every supported flag combination (``--quiet``, ``--json``, default)
   produces the expected stream shape.
3. Back-compat with the existing direct-Python entry point so we
   never break a user that was already invoking
   ``python demos/hero_retry_loop.py``.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from pathlib import Path

import pytest


ROOT = Path(__file__).resolve().parent.parent


def _env() -> dict[str, str]:
    """Propagate parent environment + DYLD_LIBRARY_PATH for the subprocess."""
    env = os.environ.copy()
    repo_root = str(ROOT)
    env["PYTHONPATH"] = os.pathsep.join(
        [repo_root, env.get("PYTHONPATH", "")]
    ).rstrip(os.pathsep)
    return env


def _run_cli(args: list[str], timeout: float = 45.0) -> subprocess.CompletedProcess:
    """Invoke ``python -m daemon.cli`` as a subprocess.

    We shell out rather than calling the Python entry point in-process
    because the demo subcommand itself spawns a subprocess; in-process
    calls would clobber stdout semantics.
    """
    return subprocess.run(
        [sys.executable, "-m", "daemon.cli", *args],
        env=_env(),
        capture_output=True,
        text=True,
        timeout=timeout,
    )


class TestDemoHeroQuiet:
    """Brief Test 5 — the quiet JSON contract is load-bearing.

    The brief's example JSON MUST match byte-for-byte (up to whitespace).
    ``blocked`` is ``true``, ``reason`` names the adaptive trigger,
    ``without_system_estimate`` + ``with_system`` carry spend figures,
    and ``prevented_loss`` is the simple difference.
    """

    def test_exit_code_zero(self) -> None:
        result = _run_cli(["demo", "hero", "--quiet"])
        assert result.returncode == 0, result.stderr

    def test_runtime_under_30s(self) -> None:
        start = time.monotonic()
        result = _run_cli(["demo", "hero", "--quiet"])
        elapsed = time.monotonic() - start
        assert result.returncode == 0, result.stderr
        assert elapsed < 30, f"quiet demo took {elapsed:.1f}s (gate: 30s)"

    def test_json_shape_matches_brief(self) -> None:
        result = _run_cli(["demo", "hero", "--quiet"])
        assert result.returncode == 0, result.stderr
        payload = json.loads(result.stdout)
        # Exact keys from the brief.
        assert set(payload.keys()) == {
            "blocked",
            "reason",
            "without_system_estimate",
            "with_system",
            "prevented_loss",
        }
        assert payload["blocked"] is True
        assert payload["reason"] == "adaptive_tightening_triggered"
        # without_system_estimate: {"projected_spend": <int>}
        assert set(payload["without_system_estimate"].keys()) == {
            "projected_spend"
        }
        assert isinstance(payload["without_system_estimate"]["projected_spend"], int)
        # with_system: {"actual_spend": <int>}
        assert set(payload["with_system"].keys()) == {"actual_spend"}
        assert isinstance(payload["with_system"]["actual_spend"], int)
        # prevented_loss is a non-negative int equal to the delta.
        assert isinstance(payload["prevented_loss"], int)
        assert payload["prevented_loss"] >= 0
        expected = (
            payload["without_system_estimate"]["projected_spend"]
            - payload["with_system"]["actual_spend"]
        )
        assert payload["prevented_loss"] == max(expected, 0)

    def test_quiet_emits_only_json_no_narration(self) -> None:
        """``--quiet`` must emit pure JSON. No preamble, no call log."""
        result = _run_cli(["demo", "hero", "--quiet"])
        stdout = result.stdout.strip()
        # Parses cleanly as JSON — no extra narration prefixed.
        parsed = json.loads(stdout)
        assert parsed["blocked"] is True


class TestDemoHeroDefault:
    """Default (no flag) mode — human-readable narration + final JSON.

    The narration is stderr/stdout-split in the underlying demo; the
    important contract is that both appear somewhere on stdout.
    """

    def test_default_prints_narration_and_json(self) -> None:
        result = _run_cli(["demo", "hero"])
        assert result.returncode == 0, result.stderr
        out = result.stdout
        # Narration markers (see demos/hero_retry_loop.py::_format_tty).
        assert "tau-x402-cage hero demo" in out
        # Prevented-loss block renders as formatted JSON inside the TTY view.
        assert '"prevented_loss"' in out
        assert '"adaptive_tightening_triggered"' in out


class TestDemoHeroJson:
    """``--json`` — full machine-readable transcript (not the brief shape).

    Distinguish from ``--quiet``: ``--json`` emits the full transcript
    with policy, per-call records, summary, etc. ``--quiet`` emits only
    the prevented_loss block.
    """

    def test_json_is_pure_json_no_narration(self) -> None:
        result = _run_cli(["demo", "hero", "--json"])
        assert result.returncode == 0, result.stderr
        # Parses as JSON end-to-end.
        payload = json.loads(result.stdout)
        # Transcript carries the richer shape.
        assert payload["scenario"] == "hero_retry_loop"
        assert "calls" in payload
        assert "policy" in payload
        assert "summary" in payload
        # No narration preface leaked onto stdout.
        assert not result.stdout.lstrip().startswith("=")

    def test_json_transcript_contains_prevented_loss(self) -> None:
        result = _run_cli(["demo", "hero", "--json"])
        payload = json.loads(result.stdout)
        pl = payload["summary"]["prevented_loss"]
        assert pl["blocked"] is True
        assert pl["reason"] == "adaptive_tightening_triggered"


class TestDemoHeroBackCompat:
    """The pre-existing Python entry point must keep working unchanged."""

    def test_python_entry_point_still_works(self) -> None:
        """``python3 demos/hero_retry_loop.py --quiet`` must not regress."""
        script = ROOT / "demos" / "hero_retry_loop.py"
        assert script.is_file(), (
            f"demo script missing at {script}; subcommand wraps it"
        )
        result = subprocess.run(
            [sys.executable, str(script), "--quiet"],
            env=_env(),
            capture_output=True,
            text=True,
            timeout=45,
        )
        assert result.returncode == 0, result.stderr
        payload = json.loads(result.stdout)
        assert payload["blocked"] is True

    def test_subcommand_forwards_unknown_action(self) -> None:
        """``tau-x402 demo banana`` must not silently run the hero demo."""
        result = _run_cli(["demo", "banana"])
        # Argparse rejects the unknown sub-action (exit 2) OR our handler
        # reports the unknown sub-action (exit 2). Either is acceptable.
        assert result.returncode != 0
