"""Tests for multi-node revision sync over Redis pub/sub (v0.11.0).

Gated on ``importorskip("fakeredis")`` so the suite stays importable when
the dev extras are not installed; fakeredis 2.x implements the PUBLISH /
SUBSCRIBE surface this module needs.

Covers:

* Publisher -> Subscriber round-trip delivers a revision record.
* Idempotent re-delivery doesn't double-append.
* Loop prevention: publisher's own records are ignored by its own subscriber.
* Subscriber applies branch create -> ``list_branches()`` on B shows it.
* Subscriber applies merge_branch -> head-of-dst on B matches.
* Preflight fail-closed on unreachable Redis.
* Fail-open on publish: subscriber failure doesn't block local mutation.
* Clean shutdown (start + stop + no orphan threads).
"""
from __future__ import annotations

import threading
import time
from decimal import Decimal
from typing import Any

import pytest

# Gate the whole module; fakeredis is a dev-extra dep.
fakeredis = pytest.importorskip("fakeredis")

from adapter.invariants import MaxPerCall, ProviderAllowlist
from adapter.policy_revision import (
    Branch,
    PolicyRevision,
    RevisionLog,
)
from adapter.prover import ProofToken
from adapter.revision_sync import (
    KIND_BRANCH_CREATE,
    KIND_BRANCH_MERGE,
    KIND_REVISION,
    RevisionSyncAdapter,
    RevisionSyncError,
    RevisionSyncPublisher,
    RevisionSyncSubscriber,
    SyncConfig,
    build_revision_sync,
)


# ── shared fixtures ─────────────────────────────────────────────────────────


@pytest.fixture
def fake_server():
    """A fakeredis FakeServer so publisher and subscriber share one Redis.

    fakeredis only fans pub/sub messages between clients that share a
    FakeServer instance; a bare ``FakeRedis()`` gives each client its own
    private server, so subscribers would never see the publisher's
    messages.
    """
    return fakeredis.FakeServer()


@pytest.fixture
def make_client(fake_server):
    """Factory that returns FakeRedis clients sharing the same fake_server."""

    def _factory():
        return fakeredis.FakeRedis(
            server=fake_server,
            decode_responses=True,
        )

    return _factory


def _token(config_hash: str, nonce: str) -> ProofToken:
    return ProofToken(
        config_hash=config_hash,
        issued_at_unix=1_713_000_000,
        backend="python-pattern",
        proof_strength="pattern",
        nonce=nonce,
        predecessor_hash=None,
        prover_mode="compat",
        fragment_version=None,
        compile_hash=None,
        tau_backend_version=None,
    )


def _rev(cfg: str, nonce: str, branch: str = "main") -> PolicyRevision:
    from dataclasses import replace
    inv = MaxPerCall(max_amount=Decimal("10.00"), currency="USDC")
    base = PolicyRevision.from_proof_token(
        token=_token(cfg, nonce),
        invariants=(inv,),
        predecessor_revision_id=None,
    )
    return replace(base, branch=branch)


def _wait_for(predicate, timeout=2.0, interval=0.01):
    """Busy-wait a predicate with a timeout so assertions don't flake on
    subscriber scheduling latency."""
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if predicate():
            return True
        time.sleep(interval)
    return False


# ── Publisher -> Subscriber round-trip ──────────────────────────────────────


class TestRoundTrip:
    def test_revision_record_propagates(self, make_client):
        pub_log = RevisionLog()
        sub_log = RevisionLog()
        channel = "tau-x402-cage:test-channel-1"
        pub_cfg = SyncConfig(url="redis://fake", channel=channel, client_id="pub-1")
        sub_cfg = SyncConfig(url="redis://fake", channel=channel, client_id="sub-1")
        pub = RevisionSyncPublisher(pub_cfg, redis_client=make_client())
        sub = RevisionSyncSubscriber(
            sub_cfg,
            sub_log,
            registry_lock=threading.Lock(),
            redis_client=make_client(),
        )
        sub.start()
        try:
            assert _wait_for(sub.connected, timeout=1.0), (
                "subscriber never reported connected"
            )
            rev = _rev("hash-abc", "nonce-1")
            pub_log.append(rev)
            pub.publish_revision(rev)
            assert _wait_for(
                lambda: len(sub_log.revisions) == 1, timeout=2.0
            ), f"expected 1 revision on subscriber, got {len(sub_log.revisions)}"
            applied = sub_log.revisions[0]
            assert applied.revision_id == rev.revision_id
            assert applied.invariants == rev.invariants
        finally:
            sub.stop(timeout=1.0)
            pub.close()


# ── Idempotency ─────────────────────────────────────────────────────────────


class TestIdempotency:
    def test_re_delivery_doesnt_double_append(self, make_client):
        channel = "tau-x402-cage:test-channel-idempotent"
        pub_cfg = SyncConfig(url="redis://fake", channel=channel, client_id="pub-idem")
        sub_cfg = SyncConfig(url="redis://fake", channel=channel, client_id="sub-idem")
        pub = RevisionSyncPublisher(pub_cfg, redis_client=make_client())
        sub_log = RevisionLog()
        sub = RevisionSyncSubscriber(
            sub_cfg,
            sub_log,
            redis_client=make_client(),
        )
        sub.start()
        try:
            assert _wait_for(sub.connected, timeout=1.0)
            rev = _rev("hash-dup", "nonce-dup")
            pub.publish_revision(rev)
            pub.publish_revision(rev)
            pub.publish_revision(rev)
            # Give the subscriber a moment to process all three.
            assert _wait_for(
                lambda: len(sub_log.revisions) >= 1, timeout=2.0
            )
            # Pause a bit so any duplicates would land.
            time.sleep(0.3)
            assert len(sub_log.revisions) == 1, (
                f"expected exactly 1 revision, got {len(sub_log.revisions)}"
            )
        finally:
            sub.stop(timeout=1.0)
            pub.close()


# ── Loop prevention ─────────────────────────────────────────────────────────


class TestLoopPrevention:
    def test_publisher_own_records_ignored_by_own_subscriber(self, make_client):
        """A single replica publishing + subscribing on the same channel
        must not apply its own revisions a second time via the wire."""
        channel = "tau-x402-cage:test-loop"
        shared_cfg = SyncConfig(url="redis://fake", channel=channel, client_id="solo-1")
        log = RevisionLog()
        pub = RevisionSyncPublisher(shared_cfg, redis_client=make_client())
        sub = RevisionSyncSubscriber(
            shared_cfg,
            log,
            redis_client=make_client(),
            own_client_id=shared_cfg.resolved_client_id(),
        )
        sub.start()
        try:
            assert _wait_for(sub.connected, timeout=1.0)
            # Simulate a local mutation: append to the log AND publish.
            rev = _rev("hash-loop", "nonce-loop")
            log.append(rev)
            pub.publish_revision(rev)
            # Wait beyond pubsub roundtrip time; subscriber should see the
            # message and filter it (no duplicate append).
            time.sleep(0.4)
            assert len(log.revisions) == 1, (
                f"expected 1 revision (no loop), got {len(log.revisions)}"
            )
        finally:
            sub.stop(timeout=1.0)
            pub.close()

    def test_different_client_id_not_filtered(self, make_client):
        """Sanity: messages from a DIFFERENT client id DO apply locally
        (this guards against accidentally filtering legitimate peer
        messages because of a string coincidence)."""
        channel = "tau-x402-cage:test-loop-negative"
        pub_cfg = SyncConfig(url="redis://fake", channel=channel, client_id="peer-A")
        sub_cfg = SyncConfig(url="redis://fake", channel=channel, client_id="peer-B")
        pub = RevisionSyncPublisher(pub_cfg, redis_client=make_client())
        sub_log = RevisionLog()
        sub = RevisionSyncSubscriber(
            sub_cfg,
            sub_log,
            redis_client=make_client(),
        )
        sub.start()
        try:
            assert _wait_for(sub.connected, timeout=1.0)
            pub.publish_revision(_rev("h1", "n1"))
            assert _wait_for(
                lambda: len(sub_log.revisions) == 1, timeout=2.0
            )
        finally:
            sub.stop(timeout=1.0)
            pub.close()


# ── Branch create propagation ───────────────────────────────────────────────


class TestBranchCreatePropagation:
    def test_branch_create_propagates(self, make_client):
        channel = "tau-x402-cage:test-branch-create"
        pub_cfg = SyncConfig(url="redis://fake", channel=channel, client_id="a-create")
        sub_cfg = SyncConfig(url="redis://fake", channel=channel, client_id="b-create")
        pub = RevisionSyncPublisher(pub_cfg, redis_client=make_client())
        sub_log = RevisionLog()
        sub = RevisionSyncSubscriber(
            sub_cfg,
            sub_log,
            redis_client=make_client(),
        )
        sub.start()
        try:
            assert _wait_for(sub.connected, timeout=1.0)
            branch = Branch(
                name="feature-x",
                head_revision_id=None,
                created_at=1_713_000_000,
                created_by="ops@example",
            )
            pub.publish_branch_create(branch)
            assert _wait_for(
                lambda: any(b.name == "feature-x" for b in sub_log.list_branches()),
                timeout=2.0,
            )
            names = [b.name for b in sub_log.list_branches()]
            assert "feature-x" in names
        finally:
            sub.stop(timeout=1.0)
            pub.close()


# ── Branch merge propagation ────────────────────────────────────────────────


class TestBranchMergePropagation:
    def test_fast_forward_merge_updates_head(self, make_client):
        channel = "tau-x402-cage:test-ff-merge"
        pub_cfg = SyncConfig(url="redis://fake", channel=channel, client_id="a-ff")
        sub_cfg = SyncConfig(url="redis://fake", channel=channel, client_id="b-ff")
        pub = RevisionSyncPublisher(pub_cfg, redis_client=make_client())
        sub_log = RevisionLog()
        sub = RevisionSyncSubscriber(
            sub_cfg,
            sub_log,
            redis_client=make_client(),
        )
        # Prime subscriber with a matching branch so the merge can land.
        sub_log._branches["dst-branch"] = Branch(
            name="dst-branch",
            head_revision_id="old-head-rev",
            created_at=0,
            created_by="",
        )
        sub.start()
        try:
            assert _wait_for(sub.connected, timeout=1.0)
            pub.publish_branch_merge(
                src="src-branch",
                dst="dst-branch",
                merge_kind="fast-forward",
                new_head_revision_id="new-head-rev",
                reviewer="reviewer@example",
            )
            assert _wait_for(
                lambda: sub_log._branches["dst-branch"].head_revision_id
                == "new-head-rev",
                timeout=2.0,
            )
        finally:
            sub.stop(timeout=1.0)
            pub.close()

    def test_three_way_merge_carries_revision(self, make_client):
        """A three-way merge publishes both the new merge commit AND
        advances the dst head pointer. Subscribers must end up with the
        new revision in the log and the branch head pointing at it."""
        from dataclasses import replace

        channel = "tau-x402-cage:test-threeway"
        pub_cfg = SyncConfig(url="redis://fake", channel=channel, client_id="a-3w")
        sub_cfg = SyncConfig(url="redis://fake", channel=channel, client_id="b-3w")
        pub = RevisionSyncPublisher(pub_cfg, redis_client=make_client())
        sub_log = RevisionLog()
        sub_log._branches["dst"] = Branch(
            name="dst", head_revision_id="old", created_at=0, created_by=""
        )
        sub = RevisionSyncSubscriber(
            sub_cfg,
            sub_log,
            redis_client=make_client(),
        )
        sub.start()
        try:
            assert _wait_for(sub.connected, timeout=1.0)
            merge_rev = replace(
                _rev("merge-hash", "merge-nonce", branch="dst"),
                merge_parent_ids=("old", "src-head"),
            )
            pub.publish_branch_merge(
                src="src",
                dst="dst",
                merge_kind="three-way",
                new_head_revision_id=merge_rev.revision_id,
                reviewer="rev@example",
                merge_revision=merge_rev,
            )
            assert _wait_for(
                lambda: merge_rev.revision_id in sub_log._revisions_by_id,
                timeout=2.0,
            )
            assert (
                sub_log._branches["dst"].head_revision_id == merge_rev.revision_id
            )
        finally:
            sub.stop(timeout=1.0)
            pub.close()


# ── Preflight ───────────────────────────────────────────────────────────────


class TestPreflightFailClosed:
    def test_preflight_fails_on_unreachable_redis(self):
        """With a real-looking URL but no reachable server, preflight
        must raise ``RevisionSyncError`` so the CLI surfaces it."""
        cfg = SyncConfig(
            url="redis://127.0.0.1:1/0",  # port 1 = reserved, nothing listens
            channel="nowhere",
        )
        log = RevisionLog()
        with pytest.raises(RevisionSyncError):
            build_revision_sync(
                config=cfg,
                log=log,
                preflight=True,
            )

    def test_preflight_skip_with_injected_client(self, make_client):
        """Tests + in-process callers can inject a fakeredis and skip
        preflight. Build must succeed end-to-end."""
        cfg = SyncConfig(
            url="redis://fake",
            channel="test-preflight-skip",
        )
        log = RevisionLog()
        adapter = build_revision_sync(
            config=cfg,
            log=log,
            redis_client=make_client(),
            preflight=False,
        )
        assert isinstance(adapter, RevisionSyncAdapter)
        # Health snapshot should be syntactically valid even before start.
        h = adapter.health()
        assert "connected" in h
        assert "subscriber_lag_ms" in h
        adapter.stop(timeout=0.5)


# ── Fail-open on publish ────────────────────────────────────────────────────


class TestFailOpenPublish:
    def test_publish_failure_does_not_raise(self):
        """A broken Redis client must not propagate its exception back
        through the publisher; the local mutation is already committed
        and we'd corrupt the audit trail otherwise."""

        class BrokenRedis:
            def publish(self, *args, **kwargs):
                raise ConnectionError("simulated redis outage")

            def close(self):
                pass

        cfg = SyncConfig(url="redis://fake", channel="test-fail-open", client_id="x")
        pub = RevisionSyncPublisher(cfg, redis_client=BrokenRedis())
        # MUST not raise.
        pub.publish_revision(_rev("h", "n"))
        pub.publish_branch_create(
            Branch(name="b", head_revision_id=None, created_at=0, created_by="")
        )
        pub.publish_branch_checkout("b")
        pub.publish_branch_merge(
            src="s",
            dst="d",
            merge_kind="fast-forward",
            new_head_revision_id="x",
            reviewer="r",
        )
        pub.close()


# ── Clean shutdown ──────────────────────────────────────────────────────────


class TestShutdown:
    def test_start_stop_no_orphan_threads(self, make_client):
        """After stop() returns the subscriber thread must not still be
        alive, and connected() must flip false."""
        cfg = SyncConfig(url="redis://fake", channel="test-shutdown", client_id="s")
        log = RevisionLog()
        sub = RevisionSyncSubscriber(
            cfg,
            log,
            redis_client=make_client(),
        )
        threads_before = [t for t in threading.enumerate() if "revision-sync" in t.name]
        assert len(threads_before) == 0
        sub.start()
        assert _wait_for(sub.connected, timeout=1.0)
        sub.stop(timeout=2.0)
        # Give the thread a moment to observe the event.
        assert _wait_for(lambda: not sub.connected(), timeout=1.0)
        threads_after = [t for t in threading.enumerate() if "revision-sync" in t.name]
        # Either no thread, or one that's finished.
        for t in threads_after:
            assert not t.is_alive(), f"subscriber thread {t.name} still alive"

    def test_stop_is_idempotent(self, make_client):
        cfg = SyncConfig(url="redis://fake", channel="test-idem-stop", client_id="s2")
        sub = RevisionSyncSubscriber(
            cfg,
            RevisionLog(),
            redis_client=make_client(),
        )
        sub.start()
        assert _wait_for(sub.connected, timeout=1.0)
        sub.stop(timeout=1.0)
        sub.stop(timeout=1.0)  # must not raise


# ── End-to-end via daemon ───────────────────────────────────────────────────


class TestDaemonIntegration:
    def test_daemon_publishes_on_declare(self, make_client):
        """When a daemon is wired with a sync adapter, an admitted
        invariant must produce a revision record that the subscriber
        delivers to a second log."""
        from daemon.server import CageDaemon
        from adapter.x402_registry import X402Registry

        channel = "tau-x402-cage:test-daemon-publish"
        pub_client = make_client()
        sub_client = make_client()

        # Subscriber is attached to a fresh log on "node B".
        sub_cfg = SyncConfig(url="redis://fake", channel=channel, client_id="node-B")
        sub_log = RevisionLog()
        sub = RevisionSyncSubscriber(
            sub_cfg,
            sub_log,
            redis_client=sub_client,
        )
        sub.start()

        # Publisher on node A is the daemon's.
        pub_cfg = SyncConfig(url="redis://fake", channel=channel, client_id="node-A")
        pub = RevisionSyncPublisher(pub_cfg, redis_client=pub_client)
        daemon_log = RevisionLog()
        adapter = RevisionSyncAdapter(
            publisher=pub,
            subscriber=RevisionSyncSubscriber(
                pub_cfg,
                daemon_log,  # this subscriber is not started; we only need the publisher
                redis_client=make_client(),
            ),
        )

        daemon = CageDaemon(
            socket_path="/tmp/tau-x402-sync-test.sock",
            prover_mode="compat",
            revision_sync=adapter,
        )
        try:
            assert _wait_for(sub.connected, timeout=1.0)
            resp = daemon.dispatch({
                "op": "declare_x402",
                "kind": "max_per_call",
                "max_amount": "10.00",
                "currency": "USDC",
            })
            assert resp["verdict"] == "updated", resp
            # Revision should fan out to node B.
            assert _wait_for(
                lambda: len(sub_log.revisions) == 1, timeout=2.0
            ), f"node B never saw revision; sub_log={len(sub_log.revisions)}"
        finally:
            sub.stop(timeout=1.0)
            daemon.shutdown()

    def test_daemon_branch_create_propagates(self, make_client):
        from daemon.server import CageDaemon

        channel = "tau-x402-cage:test-daemon-branch"
        sub_cfg = SyncConfig(url="redis://fake", channel=channel, client_id="node-B2")
        sub_log = RevisionLog()
        sub = RevisionSyncSubscriber(
            sub_cfg,
            sub_log,
            redis_client=make_client(),
        )
        sub.start()

        pub_cfg = SyncConfig(url="redis://fake", channel=channel, client_id="node-A2")
        adapter = RevisionSyncAdapter(
            publisher=RevisionSyncPublisher(pub_cfg, redis_client=make_client()),
            subscriber=RevisionSyncSubscriber(
                pub_cfg,
                RevisionLog(),
                redis_client=make_client(),
            ),
        )
        daemon = CageDaemon(
            socket_path="/tmp/tau-x402-sync-branch-test.sock",
            prover_mode="compat",
            revision_sync=adapter,
        )
        try:
            assert _wait_for(sub.connected, timeout=1.0)
            # Seed a revision so create_branch has something to anchor to.
            resp = daemon.dispatch({
                "op": "declare_x402",
                "kind": "max_per_call",
                "max_amount": "10.00",
                "currency": "USDC",
            })
            assert resp["verdict"] == "updated"
            # Now create a branch.
            br = daemon.dispatch({
                "op": "create_branch",
                "name": "shadow",
                "created_by": "ops",
            })
            assert br["verdict"] == "ok", br
            # Subscriber log should eventually carry a branch named "shadow".
            assert _wait_for(
                lambda: any(b.name == "shadow" for b in sub_log.list_branches()),
                timeout=2.0,
            ), f"branch not replicated; sub branches={[b.name for b in sub_log.list_branches()]}"
        finally:
            sub.stop(timeout=1.0)
            daemon.shutdown()

    def test_health_exposes_revision_sync_fields(self, make_client):
        """The health op's new ``revision_sync`` key must report
        connected + subscriber_lag_ms when a sync adapter is wired."""
        from daemon.server import CageDaemon

        cfg = SyncConfig(url="redis://fake", channel="test-health", client_id="h")
        adapter = RevisionSyncAdapter(
            publisher=RevisionSyncPublisher(cfg, redis_client=make_client()),
            subscriber=RevisionSyncSubscriber(
                cfg,
                RevisionLog(),
                redis_client=make_client(),
            ),
        )
        daemon = CageDaemon(
            socket_path="/tmp/tau-x402-sync-health.sock",
            prover_mode="compat",
            revision_sync=adapter,
        )
        try:
            adapter.start()
            h = daemon.dispatch({"op": "health"})
            assert "revision_sync" in h
            assert "connected" in h["revision_sync"]
            assert "subscriber_lag_ms" in h["revision_sync"]
            assert h["revision_sync"]["channel"] == "test-health"
        finally:
            adapter.stop(timeout=1.0)
            daemon.shutdown()

    def test_daemon_mutation_not_blocked_by_broken_publisher(self):
        """A broken publisher must not prevent the local declare from
        completing. Fail-open guarantee."""
        from daemon.server import CageDaemon

        class BrokenRedis:
            def publish(self, *args, **kwargs):
                raise ConnectionError("simulated outage")

            def close(self):
                pass

            def pubsub(self, *args, **kwargs):
                # Subscriber never actually runs here, so give it a
                # no-op shim that at least accepts close().
                class _PS:
                    def subscribe(self, *a, **k):
                        raise ConnectionError("no")

                    def close(self):
                        pass

                    def get_message(self, **k):
                        return None

                return _PS()

        cfg = SyncConfig(url="redis://fake", channel="test-daemon-broken", client_id="broken")
        adapter = RevisionSyncAdapter(
            publisher=RevisionSyncPublisher(cfg, redis_client=BrokenRedis()),
            subscriber=RevisionSyncSubscriber(
                cfg,
                RevisionLog(),
                redis_client=BrokenRedis(),
            ),
        )
        daemon = CageDaemon(
            socket_path="/tmp/tau-x402-sync-brokenpub.sock",
            prover_mode="compat",
            revision_sync=adapter,
        )
        try:
            resp = daemon.dispatch({
                "op": "declare_x402",
                "kind": "max_per_call",
                "max_amount": "10.00",
                "currency": "USDC",
            })
            assert resp["verdict"] == "updated", (
                f"broken publisher blocked local mutation: {resp}"
            )
        finally:
            daemon.shutdown()
