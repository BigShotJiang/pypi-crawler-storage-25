"""Tests for v0.21.0 composed-constraint-violation envelope path.

Covers:

* :func:`adapter.composition.analyze_composition` returns every
  violation rather than stopping at the first one.
* Near-threshold rules (within 20% of firing, not firing) are
  surfaced in ``near_thresholds`` with bounded floats.
* The envelope's ``reason`` promotes to
  ``composed_constraint_violation`` when 2+ rules fire, and
  ``violations`` carries the full list.
* The :mod:`adapter.decision_explainer` describer renders a
  composed-violation narrative with the rules named in the summary.
"""
from __future__ import annotations

from decimal import Decimal

import pytest

from adapter.composition import (
    DEFAULT_NEAR_THRESHOLD_FRACTION,
    CompositionResult,
    analyze_composition,
)
from adapter.decision_explainer import explain_decision
from adapter.decision_schema import (
    DECISION_REASONS,
    PaymentDecision,
    next_action_for,
)
from adapter.invariants import (
    BurstVelocityCap,
    MaxPerCall,
    ProviderAllowlist,
    RetryRateLimit,
    RollingWindowCap,
    SpendingCap,
)
from adapter.payment_intent_matcher import PaymentIntent
from adapter.x402_registry import X402Registry


# ── fixtures ────────────────────────────────────────────────────────────────


def _intent(
    amount: str = "50",
    provider: str = "provider-a",
    counterparty: str = "tenant-1",
    currency: str = "USDC",
    ts: int = 1_000_000,
) -> PaymentIntent:
    return PaymentIntent(
        amount=Decimal(amount),
        currency=currency,
        provider=provider,
        counterparty=counterparty,
        rail="x402",
        timestamp_unix=ts,
    )


# ── taxonomy + envelope plumbing ────────────────────────────────────────────


class TestComposedReasonTaxonomy:
    """The new reason is part of the stable wire contract."""

    def test_composed_reason_in_decision_reasons(self) -> None:
        assert "composed_constraint_violation" in DECISION_REASONS

    def test_next_action_for_composed_is_adjust_policy(self) -> None:
        # Composed violations require a policy change, never a silent retry.
        assert next_action_for("composed_constraint_violation") == "adjust_policy"


# ── analyze_composition: two+ rules fire ────────────────────────────────────


class TestAnalyzeCompositionTwoRulesFire:
    """Both rules fire on the same intent — violations tuple contains both."""

    def test_collects_both_violations(self) -> None:
        # Intent of 200 USDC against MaxPerCall(100) and RollingWindowCap(1,
        # window=60). History has one prior permit in the window so the
        # count cap is also violated.
        registry = X402Registry(invariants=(
            MaxPerCall(max_amount=Decimal("100")),
            RollingWindowCap(max_count=1, window_seconds=60, group_by="provider"),
        ))
        history = (
            _intent(amount="10", ts=999_990),
        )
        result = analyze_composition(registry, _intent(amount="200"), history)
        assert len(result.violations) == 2
        rule_ids = result.violation_rule_ids
        assert "max_per_call" in rule_ids
        assert "rolling_window_cap_provider" in rule_ids
        assert result.is_composed is True
        assert result.first_violation is not None

    def test_registry_check_payment_composed_returns_all(self) -> None:
        registry = X402Registry(invariants=(
            MaxPerCall(max_amount=Decimal("100")),
            RollingWindowCap(max_count=1, window_seconds=60, group_by="provider"),
        ))
        history = (_intent(amount="10", ts=999_990),)
        result = registry.check_payment_composed(_intent(amount="200"), history)
        assert isinstance(result, CompositionResult)
        assert result.is_composed is True

    def test_legacy_check_payment_unchanged(self) -> None:
        """``check_payment`` still returns ONLY the first violation."""
        registry = X402Registry(invariants=(
            MaxPerCall(max_amount=Decimal("100")),
            RollingWindowCap(max_count=1, window_seconds=60, group_by="provider"),
        ))
        history = (_intent(amount="10", ts=999_990),)
        v = registry.check_payment(_intent(amount="200"), history)
        assert v is not None
        assert v.rule_id == "max_per_call"  # declaration-order first


# ── analyze_composition: one rule fires + another near-threshold ────────────


class TestNearThresholds:
    """A single violation plus a near-threshold headroom reading."""

    def test_near_threshold_surfaces(self) -> None:
        # SpendingCap(per_window=200) over 60s and MaxPerCall(130). Intent
        # of 120 on an empty window: cumulative = 120/200 = 0.6 (below
        # 0.8 cutoff so NOT near-threshold); MaxPerCall = 120/130 ~= 0.923
        # (above cutoff so IS near-threshold). Neither fires.
        registry = X402Registry(invariants=(
            SpendingCap(max_amount=Decimal("200"), scope="per_window", window_seconds=60),
            MaxPerCall(max_amount=Decimal("130")),
        ))
        result = analyze_composition(registry, _intent(amount="120"), ())
        assert len(result.violations) == 0
        assert "max_per_call" in result.near_thresholds
        assert 0.85 <= result.near_thresholds["max_per_call"] <= 1.0
        # SpendingCap is below cutoff so NOT listed.
        assert "spending_cap_per_window" not in result.near_thresholds

    def test_near_threshold_excludes_firing_rules(self) -> None:
        """When a rule fires it shouldn't also appear in near_thresholds."""
        registry = X402Registry(invariants=(
            MaxPerCall(max_amount=Decimal("100")),
        ))
        result = analyze_composition(registry, _intent(amount="200"), ())
        assert len(result.violations) == 1
        assert "max_per_call" not in result.near_thresholds

    def test_boolean_rules_never_near_threshold(self) -> None:
        """ProviderAllowlist has no gradient — never in near_thresholds."""
        registry = X402Registry(invariants=(
            ProviderAllowlist(providers=frozenset({"provider-a"})),
        ))
        result = analyze_composition(registry, _intent(), ())
        # Didn't fire (provider allowed); no entry in near_thresholds.
        assert not result.near_thresholds

    def test_near_threshold_fraction_tunable(self) -> None:
        registry = X402Registry(invariants=(
            MaxPerCall(max_amount=Decimal("1000")),
        ))
        # 50 / 1000 = 0.05 — well under any cutoff.
        result = analyze_composition(
            registry, _intent(amount="50"), (), near_threshold_fraction=0.5,
        )
        assert not result.near_thresholds
        # Raise near-threshold to 0.04 so 0.05 >= 0.04 triggers.
        result2 = analyze_composition(
            registry, _intent(amount="50"), (), near_threshold_fraction=0.04,
        )
        assert "max_per_call" in result2.near_thresholds

    def test_near_threshold_fraction_bounds_validated(self) -> None:
        registry = X402Registry(invariants=())
        with pytest.raises(ValueError):
            analyze_composition(registry, _intent(), (), near_threshold_fraction=0.0)
        with pytest.raises(ValueError):
            analyze_composition(registry, _intent(), (), near_threshold_fraction=1.1)


# ── envelope shape: reason + violations ─────────────────────────────────────


class TestEnvelopeShape:
    """PaymentDecision's new fields serialise cleanly through ``to_wire``."""

    def test_composed_envelope_serialises(self) -> None:
        d = PaymentDecision(
            allowed=False,
            reason="composed_constraint_violation",
            rule_id="max_per_call",
            reason_text="two rules fired",
            violations=("max_per_call", "rolling_window_cap_provider"),
            near_thresholds={"burst_velocity_exceeded": 0.95},
            next_action="adjust_policy",
        )
        wire = d.to_wire()
        assert wire["reason"] == "composed_constraint_violation"
        assert wire["violations"] == ["max_per_call", "rolling_window_cap_provider"]
        assert wire["near_thresholds"] == {"burst_velocity_exceeded": 0.95}
        # Back-compat: legacy fields still present.
        assert wire["rule_id"] == "max_per_call"

    def test_envelope_roundtrips_through_from_wire(self) -> None:
        d = PaymentDecision(
            allowed=False,
            reason="composed_constraint_violation",
            violations=("max_per_call", "retry_rate_limit"),
            near_thresholds={"rolling_window_cap_global": 0.85},
        )
        restored = PaymentDecision.from_wire(d.to_wire())
        assert restored.reason == "composed_constraint_violation"
        assert list(restored.violations or ()) == [
            "max_per_call",
            "retry_rate_limit",
        ]
        assert restored.near_thresholds == {"rolling_window_cap_global": 0.85}

    def test_envelope_null_composed_fields_default_to_none(self) -> None:
        """Legacy (single-violation) decisions DON'T carry composed fields."""
        d = PaymentDecision(
            allowed=False,
            reason="spend_cap_exceeded",
            rule_id="max_per_call",
        )
        wire = d.to_wire()
        assert wire["violations"] is None
        assert wire["near_thresholds"] is None


# ── explainer describer ─────────────────────────────────────────────────────


class TestComposedViolationExplainer:
    """The new describer renders a summary/narrative for composed cases."""

    def test_describer_names_all_rules(self) -> None:
        record = {
            "verdict": "reject",
            "rule_id": "composed_constraint_violation",
            "reason_text": None,
            "violations": ["spend_velocity_exceeded", "retry_limit_near_threshold"],
            "near_thresholds": {
                "SpendingCap.per_window": 0.92,
                "RetryRateLimit": 1.0,
            },
        }
        explanation = explain_decision(record)
        # Matches brief: "Request blocked by composed constraint
        # violation: spend_velocity_exceeded AND retry_limit_near_threshold."
        assert "composed constraint violation" in explanation.summary.lower()
        assert "spend_velocity_exceeded" in explanation.summary
        assert "retry_limit_near_threshold" in explanation.summary
        assert "AND" in explanation.summary
        # Machine-readable payload carries the structured data.
        assert "violations" in explanation.machine_readable
        assert "near_thresholds" in explanation.machine_readable
        assert set(explanation.machine_readable["violations"]) == {
            "spend_velocity_exceeded",
            "retry_limit_near_threshold",
        }
        # Narrative mentions the near-threshold percentages.
        assert "92%" in explanation.narrative
        assert "SpendingCap.per_window" in explanation.narrative

    def test_describer_handles_no_near_thresholds(self) -> None:
        record = {
            "verdict": "reject",
            "rule_id": "composed_constraint_violation",
            "violations": ["max_per_call", "provider_allowlist"],
        }
        explanation = explain_decision(record)
        assert "max_per_call" in explanation.summary
        assert "provider_allowlist" in explanation.summary
        assert explanation.machine_readable["near_thresholds"] == {}

    def test_describer_single_rule_fallback(self) -> None:
        """Degenerate: one rule in violations — still renders cleanly."""
        record = {
            "verdict": "reject",
            "rule_id": "composed_constraint_violation",
            "violations": ["max_per_call"],
        }
        explanation = explain_decision(record)
        assert "max_per_call" in explanation.summary
